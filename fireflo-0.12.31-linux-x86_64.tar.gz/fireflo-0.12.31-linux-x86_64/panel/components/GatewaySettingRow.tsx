"use client";
import { useId, useState, type ReactNode } from "react";
import { X } from "lucide-react";
import { Segmented } from "@/components/ui/segmented";
import { Switch } from "@/components/ui/switch";
import { SettingControl } from "@/components/SettingControl";
import type { GatewaySettingField } from "@/lib/gateway-setting-fields";
import {
  describeValue,
  effectiveValue,
  listItems,
  rowState,
  shortOptionLabel,
  splitHint,
  storedText,
  type RowState,
  type RunningValue,
  type StoredValue,
} from "@/lib/gateway-setting-state";
import type { StatusVerdict } from "@/lib/config-key-registry";
import { cn } from "@/lib/utils";

/** The anchor a "use <successor>" link jumps to. Shared with the key table so both can be a target. */
export function settingAnchor(key: string): string {
  return `gw-key-${key}`;
}

/**
 * "Deprecated: use X" or "Retired — has no effect", with X a jump to the successor's row when it has
 * one on the page. Rendered by the curated rows and the key table alike, so the sentence is decided
 * once (in `statusVerdict`) and only linked here.
 */
export function StatusNotice({ status, className }: { status: StatusVerdict; className?: string }) {
  if (!status.notice) {
    return null;
  }
  const tone = status.status === "retired" ? "text-muted-foreground" : "text-warning";
  const successor = status.replacedBy;
  const at = successor ? status.notice.indexOf(successor) : -1;
  const before = at >= 0 ? status.notice.slice(0, at) : status.notice;
  const after = at >= 0 && successor ? status.notice.slice(at + successor.length) : "";
  return (
    <p className={cn("text-xs", tone, className)} data-key-status={status.status}>
      {before}
      {successor && at >= 0 && (
        <a
          href={`#${settingAnchor(successor)}`}
          className="font-mono underline underline-offset-2"
          onClick={(e) => {
            const target = document.getElementById(settingAnchor(successor));
            if (target) {
              e.preventDefault();
              target.scrollIntoView({ behavior: "smooth", block: "center" });
            }
          }}
        >
          {successor}
        </a>
      )}
      {after}
    </p>
  );
}

/**
 * One gateway setting: what it is, where its value comes from, and the control that changes it.
 *
 * <p>The chip under the label is the row's whole status in words -- the default, set, unsaved,
 * saved but not yet running, switched off, or set on the host -- so the control never has to carry
 * a third "not set" state of its own. A switch or a choice shows the value in effect; the chip says
 * whether that value is the default.
 *
 * <p>A retired key (`app_config_key.status`, gateway V1.88.0) is shown greyed with its control
 * disabled: the gateway no longer reads it, so an editor would promise an effect it cannot have. A
 * deprecated one keeps its editor and names the key to use instead.
 */
export function GatewaySettingRow({
  field,
  stored,
  draft,
  running,
  busy,
  invalid,
  status,
  onDraft,
}: {
  field: GatewaySettingField;
  stored: StoredValue | undefined;
  draft: string | undefined;
  running: RunningValue | undefined;
  busy: boolean;
  /** Why the staged value cannot be saved, when it cannot. */
  invalid?: string;
  /** What the registry says about the key's standing; absent reads as current. */
  status?: StatusVerdict;
  /** Stage a value. `stored` lets the parent drop an edit that returns to what is stored. */
  onDraft: (key: string, value: string, stored: string) => void;
}) {
  const id = useId();
  const [open, setOpen] = useState(false);
  const state = rowState({ stored, draft, codedDefault: field.codedDefault, running, startup: field.startup });
  const storedValue = stored?.value ?? "";
  const shown = effectiveValue({ stored, draft, codedDefault: field.codedDefault });
  const { lead, more } = splitHint(field.hint);
  const retired = status?.status === "retired";
  //a retired key is the one thing not worth editing: the gateway no longer reads it at all. A value
  //the host supplies is still overridden by what is saved here (see rowState)
  const locked = retired;
  const set = (v: string) => onDraft(field.key, v, storedValue);

  return (
    <div
      id={settingAnchor(field.key)}
      className={cn(
        "grid scroll-mt-4 gap-2 px-4 py-3.5 md:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)] md:items-start md:gap-6 md:px-5",
        state.kind === "unsaved" && "bg-info-soft/40",
        state.kind === "pending" && "bg-warning-soft/50",
        invalid && "bg-destructive-soft/40",
        retired && "opacity-60"
      )}
      data-setting={field.key}
      data-key-status={status?.status !== "current" ? status?.status : undefined}
    >
      <div className="min-w-0">
        <div id={`${id}-label`} className="text-sm font-medium">
          {field.label}
        </div>
        {lead && (
          <p id={`${id}-hint`} className="mt-0.5 text-xs text-muted-foreground">
            {lead}
            {more && (
              <>
                {" "}
                <button
                  type="button"
                  className="text-primary underline-offset-2 hover:underline"
                  aria-expanded={open}
                  onClick={() => setOpen((o) => !o)}
                >
                  {open ? "Less" : "More"}
                </button>
              </>
            )}
          </p>
        )}
        {open && more && <p className="mt-1 text-xs text-muted-foreground">{more}</p>}
        <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1">
          <code className="break-all font-mono text-xs text-muted-foreground">{field.key}</code>
          <StateChip state={state} field={field} />
          {state.kind === "unsaved" && (
            <button type="button" className="text-xs text-primary hover:underline" disabled={busy}
              onClick={() => set(storedValue)}>
              Undo
            </button>
          )}
          {(state.kind === "set" || state.kind === "pending") && storedValue !== "" && (
            //a cleared key is deleted, so the gateway falls back to its own default again
            <button type="button" className="text-xs text-primary hover:underline" disabled={busy}
              onClick={() => set("")}>
              Reset to default
            </button>
          )}
        </div>
        {invalid && <p className="mt-1 text-sm text-destructive">{invalid}</p>}
        {status && <StatusNotice status={status} className="mt-1" />}
      </div>

      <div className="min-w-0 md:flex md:justify-end md:[&>*]:w-full md:[&>*]:max-w-sm">
        <Control
          field={field}
          shown={shown}
          text={storedText({ stored, draft })}
          disabled={busy || locked}
          invalid={!!invalid}
          labelledBy={`${id}-label`}
          onChange={set}
        />
      </div>
    </div>
  );
}

function StateChip({ state, field }: { state: RowState; field: GatewaySettingField }) {
  const kind = field.widget.kind;
  const def = field.codedDefault;
  const chip = (cls: string, text: ReactNode) => (
    <span className={cn("rounded-full px-2 py-px text-2xs font-medium", cls)}>{text}</span>
  );
  switch (state.kind) {
    case "default": {
      //a text box shows nothing when unset, so the chip carries the value the gateway uses
      const textual = kind !== "boolean" && kind !== "enum";
      const value = textual && def !== null ? ` · ${def === "" ? "none" : def}` : "";
      if (state.host !== undefined) {
        return chip("bg-info-soft text-info", `Default from the host · ${describeValue(state.host, kind) || "none"}`);
      }
      return chip("bg-muted text-muted-foreground", `Default${value}`);
    }
    case "set":
      return chip(
        "bg-primary-soft text-foreground",
        def === null ? "Set" : `Set · default is ${describeValue(def, kind) || "none"}`
      );
    case "unsaved":
      return chip("bg-info-soft text-info", `Unsaved · was ${describeValue(state.was, kind)}`);
    case "pending":
      return chip(
        "bg-warning-soft text-warning",
        state.startup
          ? `Saved · running ${describeValue(state.running, kind)} until a restart`
          : `Saved · the gateway still runs ${describeValue(state.running, kind)}`
      );
    case "disabled":
      return chip("bg-muted text-foreground", "Stored but switched off · the default applies");
  }
}

function Control({
  field,
  shown,
  text,
  disabled,
  invalid,
  labelledBy,
  onChange,
}: {
  field: GatewaySettingField;
  /** The value in effect: what a switch or a choice shows selected. */
  shown: string;
  /** What a text box holds: never the default, which is its placeholder instead. */
  text: string;
  disabled: boolean;
  invalid: boolean;
  labelledBy: string;
  onChange: (value: string) => void;
}) {
  const w = field.widget;

  if (w.kind === "boolean") {
    return (
      <Switch
        checked={shown === "true"}
        disabled={disabled}
        aria-labelledby={labelledBy}
        onChange={(next) => onChange(next ? "true" : "false")}
      />
    );
  }

  if (w.kind === "enum" && w.options.length <= 3) {
    return (
      <Segmented
        label={field.label}
        options={w.options.map((o) => ({ value: o.value, label: shortOptionLabel(o.label), title: o.label }))}
        value={shown}
        disabled={disabled}
        onChange={onChange}
      />
    );
  }

  if (w.kind === "number") {
    const unit = field.suffix ?? (w.unit ? w.unit : undefined);
    return (
      <div className={cn(
        "flex h-10 items-center overflow-hidden rounded-md border bg-card",
        invalid ? "border-destructive" : "border-input"
      )}>
        <input
          type="text"
          inputMode="numeric"
          aria-labelledby={labelledBy}
          aria-invalid={invalid || undefined}
          value={text}
          disabled={disabled}
          placeholder={field.unsetLabel ?? field.codedDefault ?? "not set"}
          onChange={(e) => onChange(e.target.value)}
          className="h-full w-28 bg-transparent px-3 text-right text-sm tabular-nums outline-none disabled:opacity-50"
        />
        {unit && (
          <span className="flex h-full items-center border-l border-border bg-muted/60 px-3 text-sm text-muted-foreground">
            {unit}
          </span>
        )}
      </div>
    );
  }

  if (w.kind === "list") {
    return <ListControl field={field} value={text} disabled={disabled} labelledBy={labelledBy} onChange={onChange} />;
  }

  //anything the row has no compact form for keeps the shared control
  return (
    <div className="w-72 max-w-full">
      <SettingControl widget={w} codedDefault={field.codedDefault} value={text} disabled={disabled} onChange={onChange} />
    </div>
  );
}

/** A comma-joined list as removable chips, added to by Enter or a comma. */
function ListControl({
  field,
  value,
  disabled,
  labelledBy,
  onChange,
}: {
  field: GatewaySettingField;
  value: string;
  disabled: boolean;
  labelledBy: string;
  onChange: (value: string) => void;
}) {
  const [entry, setEntry] = useState("");
  const items = listItems(value);
  const placeholder = field.widget.kind === "list" ? field.widget.itemPlaceholder : undefined;

  function add() {
    const fresh = listItems(entry).filter((v) => !items.includes(v));
    if (fresh.length) {
      onChange([...items, ...fresh].join(","));
    }
    setEntry("");
  }

  return (
    <div className="flex min-h-10 w-80 max-w-full flex-wrap items-center gap-1.5 rounded-md border border-input bg-card px-2 py-1.5">
      {items.map((item) => (
        <span key={item} className="inline-flex items-center gap-0.5 rounded bg-muted py-0.5 pl-2 pr-0.5 font-mono text-xs">
          {item}
          <button
            type="button"
            aria-label={`Remove ${item}`}
            disabled={disabled}
            onClick={() => onChange(items.filter((i) => i !== item).join(","))}
            className="rounded p-1 text-muted-foreground hover:text-foreground"
          >
            <X className="h-3 w-3" aria-hidden="true" />
          </button>
        </span>
      ))}
      <input
        type="text"
        aria-labelledby={labelledBy}
        value={entry}
        disabled={disabled}
        placeholder={items.length ? "Add another" : placeholder ? `Add, e.g. ${placeholder}` : "Add"}
        onChange={(e) => {
          //a comma typed or pasted ends an item, as it would in the stored value
          if (e.target.value.includes(",")) {
            setEntry(e.target.value);
            const fresh = listItems(e.target.value).filter((v) => !items.includes(v));
            if (fresh.length) onChange([...items, ...fresh].join(","));
            setEntry("");
          } else {
            setEntry(e.target.value);
          }
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            add();
          } else if (e.key === "Backspace" && entry === "" && items.length) {
            onChange(items.slice(0, -1).join(","));
          }
        }}
        onBlur={add}
        className="min-w-24 flex-1 bg-transparent text-sm outline-none"
      />
    </div>
  );
}
