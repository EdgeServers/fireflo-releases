"use client";
import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { SettingsRow, SettingsRows } from "@/components/ui/settings-row";
import { Textarea } from "@/components/ui/textarea";
import { TlvPairsEditor } from "@/components/TlvPairsEditor";
import { RegistrationScopeNotes } from "@/components/RegistrationScopeNotes";
import { formatTlvCsv, parseTlvCsv, tlvCsvProblem, type TlvPair } from "@/lib/tlv-string";
import type { TlvDefinition } from "@/lib/tlv-catalogue";
import { WarningCard } from "./FormNotices";
import {
  MAX_VARIABLE,
  VARIABLE,
  hasRepeatingSegments,
  previewTemplate,
  loginOptions,
  productOptions,
  validateTemplate,
  type ApprovedTemplate,
  type TemplateInput,
} from "@/lib/whitelist-types";

/**
 * The editor for one approved message body.
 *
 * <p><strong>The preview is the point of this form.</strong> A template is matched literally, and an
 * operator cannot tell by looking whether they have written a placeholder or ordinary text —
 * `{code}` has no `#` in it and is not a placeholder at all. The account is fail-closed, so "matches
 * nothing" means the customer stops sending. Showing the operator a message their template accepts
 * is the only way that mistake becomes visible at the moment it is made.
 *
 * <p>The preview is built by the same scanner the gateway's matcher uses — same three placeholders
 * (`{#var#}`, `{#num#}`, `{#alp#}`), same whitespace folding, and a sample per gap that satisfies
 * that gap's own type. So it cannot describe behaviour the gateway will not produce.
 *
 * <p><strong>The preview shows the FOLDED text</strong>, which is deliberately not always what was
 * typed. The stored template keeps whatever was pasted, because the DLT registration has to be
 * auditable against it, but matching folds every run of whitespace to one space — so an operator who
 * pasted a body full of non-breaking spaces out of a PDF sees here what will actually be compared.
 */
export function TemplateForm({
  accountId,
  editing,
  products,
  logins,
  definitions,
  suggested,
  busy,
  onSave,
  onCancel,
}: {
  accountId: string;
  editing: ApprovedTemplate | null;
  /** The catalogue plus orphans, from the one `useProducts` call the section makes. */
  products: string[];
  /** This account's enabled logins, so an approval can be scoped to one of them. */
  logins: string[];
  /** Operator-defined TLV names, from the section's one `useTlvDefinitions` call. */
  definitions: readonly TlvDefinition[];
  suggested: Record<number, boolean>;
  busy: boolean;
  onSave: (input: TemplateInput) => Promise<string | null>;
  onCancel: () => void;
}) {
  const [name, setName] = useState(editing?.name ?? "");
  const [body, setBody] = useState(editing?.body ?? "");
  const [product, setProduct] = useState(editing?.product ?? "");
  const [systemId, setSystemId] = useState(editing?.systemId ?? "");
  const [pairs, setPairs] = useState<TlvPair[]>(() => parseTlvCsv(editing?.tlvs));
  //see HeaderForm: a new row starts approved because an operator adding one has decided; an
  //existing row starts where it is, so a customer's request opens unticked
  const [approved, setApproved] = useState(
    editing ? editing.status === "APPROVED" && editing.enabled : true
  );
  const [error, setError] = useState("");

  const tlvs = formatTlvCsv(pairs);
  const tlvProblem = tlvCsvProblem(tlvs);
  const invalid = useMemo(() => (body.trim() ? validateTemplate(body) : null), [body]);
  const preview = useMemo(() => (body.trim() && !invalid ? previewTemplate(body) : ""), [body, invalid]);
  const repeating = useMemo(
    () => Boolean(body.trim() && !invalid && hasRepeatingSegments(body)),
    [body, invalid]
  );

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const refusal = validateTemplate(body) ?? tlvCsvProblem(tlvs);
    if (refusal) {
      setError(refusal);
      return;
    }
    const failure = await onSave({
      id: editing?.id ?? null,
      accountId,
      product: product.trim(),
      systemId: systemId.trim() || null,
      name: name.trim() || null,
      body: body.trim(),
      tlvs,
      enabled: approved,
      approved,
    });
    setError(failure ?? "");
  }

  return (
    <form onSubmit={submit} className="space-y-3">
      <SettingsRows>
        <SettingsRow label="Name" htmlFor="tpl-name" help="For people reading this list. Not matched against anything.">
          <Input id="tpl-name" value={name} onChange={(e) => setName(e.target.value)}
            placeholder="OTP login" />
        </SettingsRow>
        <SettingsRow label="Approved" labelId="tpl-approved" help="Switched off, it is withdrawn; it stays approved.">
          <div className="flex items-center gap-3 md:justify-end">
            <span className="text-sm text-muted-foreground">{approved ? "Approved and in service" : "Not approved"}</span>
            <Switch checked={approved} onChange={setApproved} aria-labelledby="tpl-approved" />
          </div>
        </SettingsRow>
        <SettingsRow label="Product" htmlFor="tpl-product" help="Narrows it to one product’s traffic.">
          <Select id="tpl-product" value={product} onChange={(e) => setProduct(e.target.value)}>
            <option value="">Every product</option>
            {productOptions(products, product).map((p) => (
              <option key={p} value={p}>{p}</option>
            ))}
          </Select>
        </SettingsRow>
        <SettingsRow label="Login" htmlFor="tpl-login" help="Which of this account’s logins may send it.">
          <Select id="tpl-login" value={systemId} onChange={(e) => setSystemId(e.target.value)}>
            <option value="">Every login on the account</option>
            {loginOptions(logins, systemId).map((l) => (
              <option key={l} value={l}>{l}</option>
            ))}
          </Select>
        </SettingsRow>
        <SettingsRow
          label="Approved wording"
          htmlFor="tpl-body"
          help={<>Write <code className="font-mono">{VARIABLE}</code> wherever a value changes — exactly that,
            lower case and no spaces. Each one stands for 1 to {MAX_VARIABLE} characters.</>}
          wide
        >
          <Textarea
            id="tpl-body"
            value={body}
            onChange={(e) => setBody(e.target.value)}
            rows={4}
            className="font-mono"
            placeholder={`Your OTP is ${VARIABLE}, valid 10 minutes`}
          />
        </SettingsRow>
      </SettingsRows>

      {invalid && (
        <p className="text-sm text-destructive">{invalid}</p>
      )}

      {preview && (
        <Card className="border-foreground/40">
          <CardContent className="py-3">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">This accepts</p>
            <p className="mt-1 break-words font-mono text-sm">{preview}</p>
            <p className="mt-1.5 text-xs text-muted-foreground">
              …and nothing else. Anything the customer sends that differs outside the variables is
              refused.
            </p>
          </CardContent>
        </Card>
      )}

      {repeating && (
        <WarningCard warnings={[
          "Some wording in this template repeats. Matching takes the first place it finds each "
          + "piece, so an unusual message could be refused even though it looks like it should be "
          + "accepted. It never causes the opposite \u2014 nothing unapproved gets through \u2014 "
          + "but it is worth rewording if you can.",
        ]} />
      )}

      <SettingsRows>
        <SettingsRow
          label={<>TLVs to stamp <span className="font-normal text-muted-foreground">name_tag = value</span></>}
          help={<>Written onto every message that matches, <strong>replacing</strong> what the customer sent
            for the same tag — so the gateway carries the approved value rather than the claimed one.
            Needs <code className="mx-1 font-mono">whitelist.tlvs.mode</code> on the server the traffic
            arrives through.</>}
          wide
        >
          {/*the placeholder used to read tmid_0x1401, which is the wrong name for that tag: the
             catalogue has 0x1401 as tmplid and 0x1402 as tmid. A placeholder is where somebody learns
             the convention, so it was teaching the mistake*/}
          <TlvPairsEditor
            pairs={pairs}
            onChange={setPairs}
            definitions={definitions}
            suggested={suggested}
            addLabel="Add a stamp"
            valuePlaceholder="1207162389765432100"
            disabled={busy}
          />
        </SettingsRow>
      </SettingsRows>

      <RegistrationScopeNotes
        noun="template"
        name={name.trim() || "this wording"}
        accountId={accountId}
        systemId={systemId.trim()}
        product={product.trim()}
        logins={logins}
      />


      {error && <p className="text-sm text-destructive">{error}</p>}

      <div className="flex gap-2">
        <Button type="submit" size="sm" disabled={busy || Boolean(invalid) || Boolean(tlvProblem) || !body.trim()}>
          {busy ? "Saving…" : editing ? "Save" : "Approve"}
        </Button>
        <Button type="button" size="sm" variant="ghost" onClick={onCancel}>Cancel</Button>
      </div>
    </form>
  );
}

