"use client";
import { useEffect, useMemo, useState } from "react";
import { CartesianGrid, Line, LineChart, ReferenceArea, XAxis, YAxis } from "recharts";
import { EyeOff, X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { EmptyState } from "@/components/ui/empty-state";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { Badge } from "@/components/ui/badge";
import { StatTile } from "@/components/ui/stat-tile";
import { RangePicker } from "./RangePicker";
import { RuntimeSummary } from "./RuntimeSummary";
import { FailureRingCard, VendorRingCard } from "./DashboardRings";
import { useControlData, type Range } from "./useControlData";
import { count, money, percent } from "@/lib/format";
import { FINAL_STATE_LABELS, labelFor } from "@/lib/labels";
import type { FailureRow } from "@/lib/metrics-queries";
import {
  FAILURE_DISMISS_KEY,
  dismiss,
  failureKey,
  isDismissed,
  prune,
  readDismissals,
  restore,
  type Dismissals,
} from "@/lib/failure-dismissals";

interface Overview {
  totals: {
    messages: number; delivered: number; failed: number; pending: number;
    revenue: number; cost: number; margin: number; deliveryRate: number | null;
  };
  traffic: { bucket: string; submitted: number; delivered: number; failed: number; expired: number; pending: number }[];
  failures: FailureRow[];
  /** The same breakdown per account, for the failures ring. Absent from a panel route before 0.12.34.2. */
  failuresByAccount?: FailureRow[];
  /** The start of the window the failure breakdown covers: today, or the last 24 h, whichever is longer. */
  failuresSince?: string;
  /** When the panel last read the database for this range. The figures are a snapshot of then. */
  asOf?: string;
  /** Sections showing a previous reading because their last read failed. */
  stale?: { traffic: boolean; revenue: boolean; failures: boolean };
  /** Buckets from this instant on are still receiving receipts, so their outcome is not final. */
  settlingFrom?: string;
}

/** `HH:MM:SS` in the browser's zone, on a 24-hour clock. */
function asOfTime(iso: string): string {
  return new Date(iso).toLocaleTimeString(undefined, { hourCycle: "h23", hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

/**
 * The first bucket whose span ends after `settlingFrom`, so the chart can shade it and everything
 * after it as still settling. A bucket is an hour on the 24h range and a billing day otherwise.
 */
function firstSettlingBucket(traffic: Overview["traffic"], settlingFrom: string | undefined, range: Range): string | null {
  if (!settlingFrom) return null;
  const from = new Date(settlingFrom).getTime();
  const width = range === "24h" ? 3_600_000 : 86_400_000;
  return traffic.find((b) => new Date(b.bucket).getTime() + width > from)?.bucket ?? null;
}

//theme tokens rather than fixed hex, so the chart follows dark mode
const chartConfig = {
  submitted: { label: "Submitted", color: "var(--color-muted-foreground)" },
  delivered: { label: "Delivered", color: "var(--color-chart-1)" },
  failed: { label: "Failed", color: "var(--color-destructive)" },
} satisfies ChartConfig;

export function OverviewClient() {
  const [range, setRange] = useState<Range>("24h");
  const { data, error, loading } = useControlData<Overview>("overview", range);
  const t = data?.totals;
  const staleSections = data?.stale
    ? (Object.entries(data.stale) as [string, boolean][]).filter(([, v]) => v).map(([k]) => k)
    : [];
  const settlingFrom = firstSettlingBucket(data?.traffic ?? [], data?.settlingFrom, range);

  const [dismissals, setDismissals] = useState<Dismissals>({});
  const [showDismissed, setShowDismissed] = useState(false);

  //read after mount, never in a lazy initialiser: localStorage does not exist while the page is
  //rendered on the server, and React 19 throws on the resulting mismatch rather than patching it up
  useEffect(() => {
    const stored = prune(readDismissals(window.localStorage.getItem(FAILURE_DISMISS_KEY)), new Date());
    setDismissals(stored);
    window.localStorage.setItem(FAILURE_DISMISS_KEY, JSON.stringify(stored));
  }, []);

  function write(next: Dismissals) {
    setDismissals(next);
    window.localStorage.setItem(FAILURE_DISMISS_KEY, JSON.stringify(next));
  }

  //split rather than filtered, so the card can say how many it is holding back. A count of hidden
  //failures is the difference between a quiet period and a card nobody can trust
  const { shown, hidden } = useMemo(() => {
    const all = data?.failures ?? [];
    return {
      shown: all.filter((f) => !isDismissed(f, dismissals)),
      hidden: all.filter((f) => isDismissed(f, dismissals)),
    };
  }, [data?.failures, dismissals]);

  return (
    <>
      <PageHeader
        title="Overview"
        description="Traffic, delivery and margin across every account for the chosen period, and why messages failed."
        actions={<RangePicker value={range} onChange={setRange} />}
      />

      {/* the figures are a snapshot the server rebuilds on its own; the time says when it last
          read the database, and a section whose last read failed says so rather than looking
          current. Rendered only once data has arrived, so the server never paints a clock */}
      {data?.asOf && (
        <p className="-mt-2 flex flex-wrap items-center gap-2 text-xs text-muted-foreground" data-testid="overview-as-of">
          <span>
            as of <span className="tabular-nums" suppressHydrationWarning>{asOfTime(data.asOf)}</span>
          </span>
          {staleSections.length > 0 && (
            <Badge variant="warning" title={`The last read of ${staleSections.join(", ")} failed; showing the previous reading.`}>
              stale: {staleSections.join(", ")}
            </Badge>
          )}
        </p>
      )}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatTile label="Messages" value={count(t?.messages ?? 0)} loading={loading} error={error} />
        <StatTile
          label="Delivery rate"
          value={percent(t?.deliveryRate ?? null)}
          hint={t ? `${count(t.delivered)} delivered, ${count(t.failed)} failed` : undefined}
          loading={loading}
          error={error}
          tone="positive"
        />
        <StatTile
          label="In flight"
          value={count(t?.pending ?? 0)}
          hint="Awaiting a delivery receipt"
          loading={loading}
          error={error}
        />
        <StatTile
          label="Margin"
          value={money(t?.margin ?? 0)}
          hint={t ? `${money(t.revenue)} billed − ${money(t.cost)} cost` : undefined}
          loading={loading}
          error={error}
          tone={(t?.margin ?? 0) < 0 ? "negative" : "positive"}
        />
      </div>

      <Card>
        <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-2 space-y-0">
          <CardTitle>Traffic</CardTitle>
          <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
            {Object.entries(chartConfig).map(([key, cfg]) => (
              <span key={key} className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full" style={{ backgroundColor: cfg.color }} />
                {cfg.label}
              </span>
            ))}
            {settlingFrom && (
              //the shaded part of the chart: messages there may still get a receipt, so delivered
              //and failed are not final yet. The gateway closes the rest at its expiry deadline
              <span className="flex items-center gap-1.5" title="Messages in the shaded hours may still receive a receipt; delivered and failed are not final there.">
                <span className="h-2 w-3 rounded-sm bg-muted-foreground/20" />
                Settling
              </span>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex h-64 animate-pulse items-center justify-center text-sm text-muted-foreground">
              Loading…
            </div>
          ) : error ? (
            <div className="flex h-64 items-center justify-center text-sm text-destructive">{error}</div>
          ) : !data?.traffic.length ? (
            <EmptyState className="flex h-64 items-center justify-center">No traffic in this period</EmptyState>
          ) : (
            <ChartContainer config={chartConfig} className="h-64 w-full">
              <LineChart data={data.traffic} margin={{ top: 8, right: 16, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--color-border)" />
                <XAxis
                  dataKey="bucket"
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                  tickFormatter={(v: string) => v.slice(range === "24h" ? 11 : 5, range === "24h" ? 16 : 10)}
                  interval="preserveStartEnd"
                />
                <YAxis
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                  width={40}
                  allowDecimals={false}
                />
                {settlingFrom && (
                  <ReferenceArea
                    x1={settlingFrom}
                    x2={data.traffic[data.traffic.length - 1].bucket}
                    fill="var(--color-muted-foreground)"
                    fillOpacity={0.08}
                    strokeOpacity={0}
                  />
                )}
                <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
                <Line dataKey="submitted" stroke={chartConfig.submitted.color} strokeWidth={2} dot={false} strokeOpacity={0.6} />
                <Line dataKey="delivered" stroke={chartConfig.delivered.color} strokeWidth={2} dot={false} />
                <Line dataKey="failed" stroke={chartConfig.failed.color} strokeWidth={2} dot={false} />
              </LineChart>
            </ChartContainer>
          )}
        </CardContent>
      </Card>

      {/* two columns: why messages failed (accounts, then reasons) and what each vendor sent
          (vendors, then delivered / failed / pending). The reasons list with its dismiss controls
          is the failures card's table, shown on request */}
      <div className="grid gap-4 md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <FailureRingCard
          rows={data?.failuresByAccount ?? data?.failures ?? []}
          since={data?.failuresSince}
          loading={loading}
          reasonsTable={
            <>
                {!shown.length ? (
                  <p className="py-6 text-center text-sm text-muted-foreground">
                    {loading
                      ? "Loading…"
                      : hidden.length
                        //never "no failures" while some are merely hidden -- that would report a clean
                        //period on the strength of the operator's own filing
                        ? "Every failure in this period has been dismissed."
                        : "No failures in this period"}
                  </p>
                ) : (
                  <div className="space-y-2">
                    {shown.map((f) => (
                      <FailureLine
                        key={failureKey(f)}
                        failure={f}
                        action="dismiss"
                        onAct={() => write(dismiss(dismissals, f, new Date()))}
                      />
                    ))}
                  </div>
                )}

                {hidden.length > 0 && (
                  <div className="mt-3 border-t border-border pt-3">
                    <button
                      type="button"
                      className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground"
                      onClick={() => setShowDismissed((v) => !v)}
                      aria-expanded={showDismissed}
                    >
                      <EyeOff className="h-3 w-3" />
                      {hidden.length} dismissed
                      <span className="underline underline-offset-2">
                        {showDismissed ? "hide" : "show"}
                      </span>
                    </button>
                    {showDismissed && (
                      <div className="mt-2 space-y-2">
                        {hidden.map((f) => (
                          <FailureLine
                            key={failureKey(f)}
                            failure={f}
                            action="restore"
                            onAct={() => write(restore(dismissals, f))}
                          />
                        ))}
                        <p className="text-xs text-muted-foreground">
                          A dismissed failure comes back on its own the next time it happens. Dismissing
                          hides what you have already dealt with, not what starts again.
                        </p>
                      </div>
                    )}
                  </div>
                )}
            </>
          }
        />
        <VendorRingCard range={range} />
      </div>
      <RuntimeSummary />
    </>
  );
}

/**
 * One failure kind, with the control that files it away.
 *
 * <p>Shared by the visible list and the dismissed one so the two cannot drift into looking like
 * different things — a restored row must be recognisably the row that was dismissed.
 */
function FailureLine({ failure, action, onAct }: {
  failure: FailureRow;
  action: "dismiss" | "restore";
  onAct: () => void;
}) {
  const name = labelFor(FINAL_STATE_LABELS, failure.finalState);
  const dismissing = action === "dismiss";
  return (
    <div
      className={"flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border px-3 py-2 text-sm"
        + (dismissing ? "" : " opacity-60")}
    >
      <div className="flex flex-wrap items-center gap-2">
        <Badge variant="destructive">{name}</Badge>
        {/* the numeric state is kept alongside the name because EXPIRED, REJECTD and UNDELIV all
            bill as failures but mean different things -- and the number is what a vendor's own
            documentation is indexed by */}
        {failure.dlrState !== null && (
          <span className="text-sm text-muted-foreground">receipt state {failure.dlrState}</span>
        )}
        {failure.errCode && (
          <span className="text-sm text-muted-foreground">vendor error {failure.errCode}</span>
        )}
      </div>
      <div className="flex items-center gap-3">
        <span className="tabular-nums">{count(failure.messages)}</span>
        <button
          type="button"
          className="text-muted-foreground hover:text-foreground"
          onClick={onAct}
          //the label names the failure, because a row of identical "Dismiss" buttons tells a screen
          //reader nothing about which one is under the cursor
          aria-label={`${dismissing ? "Dismiss" : "Restore"} ${name}${failure.errCode ? ` ${failure.errCode}` : ""}`}
          title={dismissing ? "Dismiss until it happens again" : "Show this again"}
        >
          {dismissing ? <X className="h-3.5 w-3.5" /> : <span className="text-xs underline">restore</span>}
        </button>
      </div>
    </div>
  );
}
