"use client";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Cell, Pie, PieChart, Tooltip } from "recharts";
import { AlertTriangle, Server } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, type ChartConfig } from "@/components/ui/chart";
import { useControlData, type Range } from "./useControlData";
import type { VendorRow } from "./VendorTraffic";
import { count, percent } from "@/lib/format";
import { FINAL_STATE_LABELS, labelFor } from "@/lib/labels";
import { byAccount, byReason, reasonKey, type FailureCell } from "@/lib/failure-groups";

/**
 * The dashboard's two ring charts, side by side: why messages failed (accounts inside, their failure
 * reasons outside) and what each vendor sent (vendors inside, delivered / failed / pending outside).
 *
 * <p>The outer ring is drawn in the same order as the inner one and from the same start angle, so each
 * account's (or vendor's) reasons sit directly outside its own slice. Colours are fixed hues rather
 * than theme tokens on purpose: a reason keeps one colour wherever it appears, across both themes.
 */

/** Failure reasons, by their rank in the period: the biggest reason is always the first colour. */
const REASON_COLOURS = ["#2a78d6", "#eb6834", "#008300", "#e34948", "#6250d6"];
const REST_COLOUR = "#9a988f";
/** The inner rings: accounts on the left, vendors on the right. */
const SLICE_COLOURS = ["#6250d6", "#e87ba4", "#1baf7a", "#c98500", "#2a78d6", "#eb6834"];
const OTHER_COLOUR = "#b4b2a9";
const FAILED_COLOUR = "#e34948";
const PENDING_COLOUR = "#c9c7bd";

/** Whether each card's table is open. Closed until asked for; the choice is remembered per browser. */
const FAILURE_TABLE_KEY = "fireflo.overview.failureTable";
const VENDOR_TABLE_KEY = "fireflo.overview.vendorTable";

/** A Show table / Hide table switch, closed by default and remembered under `key`. */
function useTableToggle(key: string): [boolean, () => void] {
  const [open, setOpen] = useState(false);
  //read after mount: localStorage does not exist while the page renders on the server
  useEffect(() => {
    try {
      setOpen(window.localStorage.getItem(key) === "1");
    } catch {
      //private window or blocked storage: closed stands
    }
  }, [key]);
  const toggle = () => setOpen((was) => {
    try {
      window.localStorage.setItem(key, was ? "0" : "1");
    } catch {
      //remembered for this page only
    }
    return !was;
  });
  return [open, toggle];
}

function TableToggle({ open, onToggle }: { open: boolean; onToggle: () => void }) {
  return (
    <Button variant="outline" size="sm" className="h-7" onClick={onToggle} aria-pressed={open}>
      {open ? "Hide table" : "Show table"}
    </Button>
  );
}

//a ChartContainer needs a config; the rings colour their own cells, so it carries nothing
const NO_CONFIG = {} satisfies ChartConfig;

interface RingDatum {
  name: string;
  value: number;
  fill: string;
  opacity?: number;
}

function reasonName(row: Pick<FailureCell, "finalState" | "dlrState" | "errCode">): string {
  const state = labelFor(FINAL_STATE_LABELS, row.finalState);
  return row.errCode ? `${state} · error ${row.errCode}` : row.dlrState !== null ? `${state} · receipt ${row.dlrState}` : state;
}

function RingTooltip({ active, payload }: { active?: boolean; payload?: { payload: RingDatum }[] }) {
  if (!active || !payload?.length) {
    return null;
  }
  const d = payload[0].payload;
  return (
    <div className="rounded-md border border-border bg-popover px-2.5 py-1.5 text-xs shadow-sm">
      <span className="font-medium">{d.name}</span>
      <span className="ml-2 tabular-nums text-muted-foreground">{count(d.value)}</span>
    </div>
  );
}

/** Two concentric rings, the outer one aligned slice by slice to the inner. */
function Rings({ inner, outer, label }: { inner: RingDatum[]; outer: RingDatum[]; label: string }) {
  return (
    <ChartContainer config={NO_CONFIG} className="mx-auto aspect-square h-48 w-48" role="img" aria-label={label}>
      <PieChart>
        <Tooltip content={<RingTooltip />} />
        <Pie data={inner} dataKey="value" nameKey="name" innerRadius={30} outerRadius={60} startAngle={90} endAngle={-270}
          stroke="var(--color-card)" strokeWidth={2} isAnimationActive={false}>
          {inner.map((d, i) => <Cell key={i} fill={d.fill} />)}
        </Pie>
        <Pie data={outer} dataKey="value" nameKey="name" innerRadius={64} outerRadius={86} startAngle={90} endAngle={-270}
          stroke="var(--color-card)" strokeWidth={1} isAnimationActive={false}>
          {outer.map((d, i) => <Cell key={i} fill={d.fill} fillOpacity={d.opacity ?? 1} />)}
        </Pie>
      </PieChart>
    </ChartContainer>
  );
}

function Swatch({ colour, opacity }: { colour: string; opacity?: number }) {
  return <span className="inline-block h-2.5 w-2.5 shrink-0 rounded-sm" style={{ background: colour, opacity }} aria-hidden="true" />;
}

/**
 * Why messages failed: the failures of the period by account, each account split by reason. The
 * tables are on demand -- "Show table" opens a per-account summary and the reasons list with its
 * dismiss controls, which the caller renders and passes as `reasonsTable`.
 */
export function FailureRingCard({
  rows,
  since,
  loading,
  reasonsTable,
}: {
  rows: FailureCell[];
  since?: string;
  loading: boolean;
  reasonsTable: ReactNode;
}) {
  const [table, toggle] = useTableToggle(FAILURE_TABLE_KEY);

  const { slices, reasons, total, inner, outer } = useMemo(() => {
    const reasonsRanked = byReason(rows);
    const colourOf = new Map(reasonsRanked.map((r, i) => [reasonKey(r), REASON_COLOURS[i] ?? REST_COLOUR]));
    const accountSlices = byAccount(rows, 4);
    return {
      slices: accountSlices,
      reasons: reasonsRanked,
      total: reasonsRanked.reduce((n, r) => n + r.messages, 0),
      inner: accountSlices.map((s, i): RingDatum => ({
        name: s.account ?? (s.accounts > 1 ? `Other (${s.accounts} accounts)` : "No account"),
        value: s.messages,
        fill: s.account === null ? OTHER_COLOUR : SLICE_COLOURS[i % SLICE_COLOURS.length],
      })),
      outer: accountSlices.flatMap((s) => s.reasons.map((r): RingDatum => ({
        name: `${s.account ?? "Other"} · ${reasonName(r.row)}`,
        value: r.messages,
        fill: colourOf.get(r.key) ?? REST_COLOUR,
      }))),
    };
  }, [rows]);

  return (
    <Card className="min-w-0">
      <CardHeader className="flex-row flex-wrap items-start gap-2 space-y-0">
        <div className="min-w-0 flex-1 space-y-1.5">
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            Why messages failed
          </CardTitle>
          <CardDescription>
            {since ? <>Since {new Date(since).toLocaleString()}</> : "The last 24 hours"}
            {total > 0 && <> · {count(total)} failed across {slices.reduce((n, s) => n + s.accounts, 0)} account{slices.reduce((n, s) => n + s.accounts, 0) === 1 ? "" : "s"}</>}
          </CardDescription>
        </div>
        <TableToggle open={table} onToggle={toggle} />
      </CardHeader>
      <CardContent className="space-y-3">
        {total === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">{loading ? "Loading…" : "No failures in this period"}</p>
        ) : (
          <>
            <Rings inner={inner} outer={outer} label={`Failed messages by account, then by reason: ${inner.map((d) => `${d.name} ${d.value}`).join(", ")}`} />
            <div className="flex flex-wrap justify-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
              {reasons.slice(0, REASON_COLOURS.length).map((r, i) => (
                <span key={reasonKey(r)} className="flex items-center gap-1.5"><Swatch colour={REASON_COLOURS[i]} />{reasonName(r)}</span>
              ))}
              {reasons.length > REASON_COLOURS.length && (
                <span className="flex items-center gap-1.5"><Swatch colour={REST_COLOUR} />{reasons.length - REASON_COLOURS.length} more</span>
              )}
            </div>
            {table && <table className="w-full text-xs">
              <thead>
                <tr className="text-muted-foreground"><th className="py-1 text-left font-normal">Account</th><th className="py-1 text-right font-normal">Failed</th><th className="py-1 pl-3 text-left font-normal">Top reason</th></tr>
              </thead>
              <tbody>
                {slices.map((s, i) => (
                  <tr key={s.account ?? "other"} className="border-t border-border">
                    <td className="py-1.5"><span className="flex items-center gap-1.5"><Swatch colour={inner[i].fill} /><span className="truncate font-mono">{inner[i].name}</span></span></td>
                    <td className="py-1.5 text-right tabular-nums">{count(s.messages)}</td>
                    <td className="py-1.5 pl-3 text-muted-foreground [overflow-wrap:anywhere]">{s.reasons[0] ? reasonName(s.reasons[0].row) : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>}
          </>
        )}
        {table && <div className="border-t border-border pt-3">{reasonsTable}</div>}
      </CardContent>
    </Card>
  );
}

/** What each vendor sent in the period, each vendor split into delivered, failed and still pending. */
export function VendorRingCard({ range }: { range: Range }) {
  const { data, loading, error } = useControlData<VendorRow[]>("vendors", range);
  const [table, toggle] = useTableToggle(VENDOR_TABLE_KEY);
  const { vendors, sent, inner, outer } = useMemo(() => {
    const rows = (data ?? []).filter((v) => v.messages > 0).sort((a, b) => b.messages - a.messages);
    const shown = rows.length > 6 ? rows.slice(0, 5) : rows;
    const rest = rows.slice(shown.length);
    const merged = rest.length
      ? [...shown, rest.reduce<VendorRow>((acc, v) => ({
        ...acc,
        messages: acc.messages + v.messages, delivered: acc.delivered + v.delivered,
        failed: acc.failed + v.failed, pending: acc.pending + v.pending,
      }), { ...rest[0], vendor: `Other (${rest.length})`, messages: 0, delivered: 0, failed: 0, pending: 0 })]
      : shown;
    const colour = (i: number) => (i < shown.length ? SLICE_COLOURS[i % SLICE_COLOURS.length] : OTHER_COLOUR);
    return {
      vendors: merged.map((v, i) => ({ ...v, colour: colour(i) })),
      sent: rows.reduce((n, v) => n + v.messages, 0),
      inner: merged.map((v, i): RingDatum => ({ name: v.vendor ?? "No vendor", value: v.messages, fill: colour(i) })),
      //the outcomes are credited to one attempt per message, so they can sum to a little less than
      //the messages handed over; the outer ring is drawn from the outcomes, which is what it shows
      outer: merged.flatMap((v, i) => [
        { name: `${v.vendor ?? "No vendor"} · delivered`, value: v.delivered, fill: colour(i), opacity: 0.45 },
        { name: `${v.vendor ?? "No vendor"} · failed`, value: v.failed, fill: FAILED_COLOUR },
        { name: `${v.vendor ?? "No vendor"} · pending`, value: v.pending, fill: PENDING_COLOUR },
      ].filter((d) => d.value > 0)),
    };
  }, [data]);

  return (
    <Card className="min-w-0">
      <CardHeader className="flex-row flex-wrap items-start gap-2 space-y-0">
        <div className="min-w-0 flex-1 space-y-1.5">
          <CardTitle className="flex items-center gap-2">
            <Server className="h-4 w-4 text-muted-foreground" />
            Sent by vendor
          </CardTitle>
          <CardDescription>
            {sent > 0 ? `${count(sent)} messages handed to vendors in this period` : "Messages handed to each vendor in this period"}
          </CardDescription>
        </div>
        <TableToggle open={table} onToggle={toggle} />
      </CardHeader>
      <CardContent className="space-y-3">
        {error ? (
          <p className="py-6 text-center text-sm text-destructive">{error}</p>
        ) : sent === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">{loading ? "Loading…" : "Nothing sent in this period"}</p>
        ) : (
          <>
            <Rings inner={inner} outer={outer} label={`Messages by vendor: ${inner.map((d) => `${d.name} ${d.value}`).join(", ")}`} />
            <div className="flex flex-wrap justify-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
              <span>Outer ring:</span>
              <span className="flex items-center gap-1.5"><Swatch colour={SLICE_COLOURS[0]} opacity={0.45} />delivered (vendor&apos;s colour)</span>
              <span className="flex items-center gap-1.5"><Swatch colour={FAILED_COLOUR} />failed</span>
              <span className="flex items-center gap-1.5"><Swatch colour={PENDING_COLOUR} />pending</span>
            </div>
            {table && <table className="w-full text-xs">
              <thead>
                <tr className="text-muted-foreground"><th className="py-1 text-left font-normal">Vendor</th><th className="py-1 text-right font-normal">Sent</th><th className="py-1 text-right font-normal">Delivered</th><th className="py-1 text-right font-normal">Failed</th></tr>
              </thead>
              <tbody>
                {vendors.map((v) => {
                  const settled = v.delivered + v.failed;
                  return (
                    <tr key={v.vendor ?? "none"} className="border-t border-border">
                      <td className="py-1.5"><span className="flex items-center gap-1.5"><Swatch colour={v.colour} /><span className="truncate font-mono">{v.vendor ?? "No vendor"}</span></span></td>
                      <td className="py-1.5 text-right tabular-nums">{count(v.messages)}</td>
                      <td className="py-1.5 text-right tabular-nums">{count(v.delivered)}</td>
                      <td className={"py-1.5 text-right tabular-nums" + (v.failed > 0 ? " text-destructive" : "")}>
                        {count(v.failed)}{settled > 0 && v.failed > 0 ? ` · ${percent(v.failed / settled)}` : ""}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>}
          </>
        )}
      </CardContent>
    </Card>
  );
}
