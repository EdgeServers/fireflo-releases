/**
 * The home page's failures tile from the gateway's hourly failure summary, with only the minutes past
 * its watermark read from the records.
 *
 * <p>Database-free so the text can be asserted without a connection; `failureBreakdown` in
 * `metrics-queries.ts` runs it.
 *
 * <h2>Why it exists</h2>
 *
 * <p>The tile grouped the window's failed messages by final state, receipt state and error code, and
 * found them with a DISTINCT ON over every message in the window and a receipt lookup per message. On
 * a staging gateway with 1.2 million records in the window that took 27 seconds, past the panel's
 * 10-second statement timeout, every minute -- the tile sat marked "stale: failures". From gateway
 * V1.98.0 `usage_failure_hourly` holds exactly that grouping per UTC hour.
 *
 * <h2>The window</h2>
 *
 * <pre>
 *   hours in [first_hour, seam)          summary   whole hours, plus the partial hour the watermark
 *                                                  sits in, filled up to the watermark
 *   [since, LEAST(first_hour, seam))     records   only when the summary began after the window did
 *   [seam, until)                        records   what the summary has not reached yet
 * </pre>
 *
 * <p><b>`first_hour` is the UTC hour `since` falls in</b>, not the next one: the tile's "last day" is
 * already approximate (local midnight or 24 hours back, whichever is earlier), and reading the opening
 * part-hour from the records would mean up to an hour of them -- millions of rows at volume, the very
 * read this replaces. So the window starts at the top of that hour, and `since` reports it. It never
 * precedes the summary's first row: before that the records are read, slower but right.
 *
 * <p>The record edges are driven from the non-delivered receipts, as the gateway's rollup is: only a
 * message with one can have a failed outcome. A receipt follows its submit, so `final_at >= edge_lo`
 * keeps every receipt of the messages the edges cover.
 *
 * <p>$1 since, $2 until, $3 the billing zone (as FAILURE_WINDOW_SINCE takes them), $4 the summary's
 * watermark.
 *
 * <p>Grouped by account as well as by outcome, for the dashboard's failures-by-account ring: the
 * summary keys on the account already, and the records carry it. The reasons list sums the accounts
 * back together (`byReason` in `metrics-queries.ts`).
 */

import { representativeKeys } from "./cdr-grain.ts";
import { FAILURE_WINDOW_SINCE } from "./usage-summary-sql.ts";

/**
 * The window's bounds as CTEs `base`, `cut0` and `cut`: shared by the breakdown and by
 * {@link failureWindowStartSql}, so the start the tile shows is the start it read from.
 */
const CUT = `
  base AS (
      SELECT ${FAILURE_WINDOW_SINCE} AS since, $2::timestamptz AS until
  ),
  cut0 AS (
      SELECT b.since, b.until,
             LEAST(GREATEST($4::timestamptz, b.since), b.until) AS seam,
             --the hour since falls in, and never before the summary's first row; GREATEST ignores
             --the NULL of an empty summary
             GREATEST(date_trunc('hour', b.since AT TIME ZONE 'UTC') AT TIME ZONE 'UTC',
                      (SELECT min(hour) FROM usage_hourly)) AS first_hour
        FROM base b
  ),
  cut AS (
      SELECT c.*,
             --LEAST ignores a NULL first_hour, which leaves the whole window to the records
             LEAST(c.since, c.first_hour) AS shown_since,
             CASE WHEN c.since < LEAST(c.first_hour, c.seam) THEN c.since ELSE c.seam END AS edge_lo
        FROM cut0 c
  )`;

/** The start of the window the breakdown reads, as `since`. Same binds. */
export function failureWindowStartSql(): string {
  return `WITH ${CUT}
  SELECT shown_since AS since FROM cut`;
}

export function failureBreakdownHourlySql(vendorAttempt: boolean): string {
  return `
  WITH ${CUT},
  bad AS (
      SELECT DISTINCT f.gateway_msg_id
        FROM cdr_final f, cut
       WHERE f.part_no = 1 AND f.final_at >= cut.edge_lo AND f.final_state <> 'DELIVERED'
  ),
  edge_msgs AS (
      SELECT DISTINCT ON (c.gateway_msg_id) c.gateway_msg_id, c.submitted_at, c.account_id
        FROM cdr_submit c JOIN bad USING (gateway_msg_id), cut
       WHERE c.part_no = 1
         AND ((c.submitted_at >= cut.since AND c.submitted_at < LEAST(cut.first_hour, cut.seam))
           OR (c.submitted_at >= cut.seam AND c.submitted_at < cut.until))
       ORDER BY c.gateway_msg_id, ${representativeKeys("c", vendorAttempt)}
  ),
  edge_outcomes AS (
      SELECT DISTINCT ON (f.gateway_msg_id) f.gateway_msg_id, f.final_state, f.dlr_state, f.err_code
        FROM cdr_final f JOIN bad USING (gateway_msg_id), cut
       WHERE f.part_no = 1 AND f.final_at >= cut.edge_lo
       --the outcome rule of OUTCOME_LATERAL and the gateway's rollup. Change one, change all
       ORDER BY f.gateway_msg_id, (f.final_state = 'EXPIRED'), f.final_at
  ),
  merged AS (
      SELECT o.final_state, o.dlr_state, o.err_code, m.account_id,
             COUNT(*) AS messages, MAX(m.submitted_at) AS last_seen
        FROM edge_msgs m JOIN edge_outcomes o USING (gateway_msg_id)
       WHERE o.final_state <> 'DELIVERED'
       GROUP BY 1, 2, 3, 4
      UNION ALL
      SELECT h.final_state, NULLIF(h.dlr_state, -1), NULLIF(h.err_code, ''), h.account_id,
             SUM(h.messages), MAX(h.last_seen)
        FROM usage_failure_hourly h, cut
       WHERE h.hour >= cut.first_hour AND h.hour < cut.seam
       GROUP BY 1, 2, 3, 4
  )
  SELECT final_state, dlr_state, err_code, account_id,
         SUM(messages)  AS messages,
         MAX(last_seen) AS last_seen
    FROM merged
   GROUP BY 1, 2, 3, 4
   ORDER BY 5 DESC`;
}
