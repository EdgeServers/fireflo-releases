/**
 * EP-05 SMPP Client — Submit Outcomes, Retry & Recovery
 * US-05.03 In-flight reclaim when a vendor's channel dies (0.11)
 *
 * The headline 0.11 fix (18d449c). Vendor A holds every submit for 300 ms with a window of 200, so
 * a burst of 400 leaves ~200 in flight; SIGKILL on EdgeSmsc A kills the channel without an unbind;
 * the gateway must reclaim every in-flight submit, record a 0xFE attempt for each, and deliver them
 * through vendor B — exactly once. Before the fix the trace of each of those ended at
 * message.submitted and the message was in no table.
 */
import { expect, test } from "../../fixtures";
import { edgeA, edgeB } from "../../fixtures/edgesmsc";
import { awaitGatewayAdopts, ops } from "../../fixtures/gateway";
import { VENDORS } from "../../fixtures/gateway-rig";
import { gatewayLog } from "../../fixtures/trace";
import { bindA } from "../../support/flows/gateway";
import { tc } from "../../support/tc";
import { LOAD } from "../../support/tags";

const RECLAIM = /message\.vendor\.inflight\.reclaimed vendor:(\S+) inflight=(\d+) returned=(\d+) orphaned=(\d+)/;

/** Point the MESSAGE table at the failover group for the test, and back afterwards. */
async function routeViaFailover(db: import("../../fixtures").Db, seed: import("../../fixtures").Seed) {
  const rule = await db.one<{ id: string; target: string }>("SELECT id::text, target FROM app_route_rule WHERE table_name = 'MESSAGE' ORDER BY seq LIMIT 1");
  await db.q("UPDATE app_route_rule SET target = 'qa-failover' WHERE id = $1", [rule.id]);
  seed.cleanup(async () => { await db.q("UPDATE app_route_rule SET target = $1 WHERE id = $2", [rule.target, rule.id]); await ops().reload().catch(() => undefined); });
  await awaitGatewayAdopts(async () => {
    const r = await ops().explain({ to: "61400009999", from: "QATEST", type: "0" });
    return r.text.includes("qa-failover") || r.text.includes(VENDORS.a);
  });
}

interface Run { accepted: number; ids: string[]; reclaim: RegExpMatchArray & { input: string } }

/** The shared scenario: burst through vendor A, kill it with a full window, wait for the reclaim line. */
async function killWithFullWindow(db: import("../../fixtures").Db, seed: import("../../fixtures").Seed, n = 400): Promise<Run> {
  await routeViaFailover(db, seed);
  const a = edgeA();
  const b = edgeB();
  await a.baseline(); await b.baseline();
  await a.delay(300);
  const mark = gatewayLog.mark();
  const esme = await bindA();
  try {
    const burst = esme.submitMany(n, {}, { window: 300 });
    await expect.poll(async () => (await a.stats()).pdus, { timeout: 60_000 }).toBeGreaterThanOrEqual(150);
    await a.kill9();
    const reclaim = await gatewayLog.waitFor(RECLAIM, mark, 60_000);
    const run = await burst;
    seed.cleanup(async () => { await a.restart(); await a.baseline(); });
    return { accepted: run.accepted, ids: run.ids, reclaim };
  } finally {
    await esme.unbind();
  }
}

test.describe("SC-05.03.01 SIGKILL with a full window", () => {
  test(...tc("TC-05.03.01-P01", "Reclaim line names the count", { requires: ["gateway", "edgesmsc", "trace"], tags: [LOAD] }), async ({ db, seed, tcx }) => {
    test.setTimeout(240_000);
    const run = await killWithFullWindow(db, seed);
    const [, vendor, inflight, returned, orphaned] = run.reclaim;
    expect(vendor).toContain(VENDORS.a);
    expect(Number(inflight)).toBeGreaterThan(0);
    expect(Number(returned)).toBe(Number(inflight));
    expect(Number(orphaned)).toBe(0);
    tcx.note(run.reclaim[0]);
  });

  test(...tc("TC-05.03.01-P02", "Every reclaimed message has a 0xFE attempt row", { requires: ["gateway", "edgesmsc", "trace"], tags: [LOAD] }), async ({ db, seed, tcx }) => {
    test.setTimeout(240_000);
    const since = new Date();
    const run = await killWithFullWindow(db, seed);
    const returned = Number(run.reclaim[3]);
    await expect.poll(() => db.count("cdr_submit", "submit_status = 254 AND vendor LIKE $1 AND accepted_at >= $2", [`%${VENDORS.a}`, since]), { timeout: 60_000 }).toBe(returned);
    const unbilled = await db.count("cdr_submit", "submit_status = 254 AND vendor LIKE $1 AND accepted_at >= $2 AND price IS NOT NULL", [`%${VENDORS.a}`, since]);
    expect(unbilled, "a reclaimed attempt is never billed").toBe(0);
    tcx.note(`returned ${returned}; cdr_submit rows with submit_status 0xFE on ${VENDORS.a}: ${returned}, none priced`);
  });

  test(...tc("TC-05.03.01-P03", "Trace no longer stops at message.submitted", { requires: ["gateway", "edgesmsc", "trace"], tags: [LOAD] }), async ({ db, seed, tcx }) => {
    test.setTimeout(240_000);
    await seed.config("message.trace.mode", "all");
    const mark = gatewayLog.mark();
    const run = await killWithFullWindow(db, seed);
    const reclaimed = await db.q<{ gateway_msg_id: string }>("SELECT gateway_msg_id FROM cdr_submit WHERE submit_status = 254 AND vendor LIKE $1 ORDER BY id DESC LIMIT 5", [`%${VENDORS.a}`]);
    expect(reclaimed.length).toBeGreaterThan(0);
    const id = reclaimed[0].gateway_msg_id;
    await expect.poll(() => gatewayLog.traceOf(id, mark).some((l) => /message\.submit\.response|message\.delivery\.retry|message\.routed/.test(l) && !/^.*message\.submitted/.test(l) === false ? true : /message\.submit\.response|message\.delivery\.retry/.test(l)), { timeout: 90_000 }).toBe(true);
    const events = gatewayLog.traceOf(id, mark).map((l) => /message\.[a-z.]+/.exec(l)?.[0]).filter(Boolean) as string[];
    const lastSubmitted = events.lastIndexOf("message.submitted");
    expect(events.slice(lastSubmitted + 1).length, "events after the reclaimed submit").toBeGreaterThan(0);
    tcx.note(`${id.slice(0, 8)}…: ${events.join(" → ")} (run accepted ${run.accepted})`);
  });

  test(...tc("TC-05.03.01-P04", "No message is in no table", { requires: ["gateway", "edgesmsc", "trace"], tags: [LOAD] }), async ({ db, seed, tcx }) => {
    test.setTimeout(300_000);
    const run = await killWithFullWindow(db, seed);
    await expect.poll(async () => {
      const ok = await db.count("cdr_submit", "gateway_msg_id = ANY($1) AND submit_status = 0", [run.ids]);
      const rejected = await db.count("cdr_rejected", "gateway_msg_id = ANY($1)", [run.ids]);
      return ok + rejected;
    }, { timeout: 180_000 }).toBe(run.accepted);
    const ok = await db.count("cdr_submit", "gateway_msg_id = ANY($1) AND submit_status = 0", [run.ids]);
    const rejected = await db.count("cdr_rejected", "gateway_msg_id = ANY($1)", [run.ids]);
    expect(run.accepted - (ok + rejected)).toBe(0);
    tcx.note(`accepted ${run.accepted} − (OK ${ok} + rejected ${rejected}) = 0`);
  });

  test(...tc("TC-05.03.01-N01", "Orphaned stays 0", { requires: ["gateway", "edgesmsc", "trace"], tags: [LOAD] }), async ({ db, seed, tcx }) => {
    test.setTimeout(240_000);
    const mark = gatewayLog.mark();
    await killWithFullWindow(db, seed);
    await new Promise((r) => setTimeout(r, 3000));
    const lines = gatewayLog.grep(RECLAIM, mark);
    expect(lines.length).toBeGreaterThan(0);
    for (const l of lines) expect(RECLAIM.exec(l)![4], l).toBe("0");
    tcx.note(`${lines.length} reclaim line(s), all orphaned=0`);
  });

  test(...tc("TC-05.03.01-N02", "No duplicate delivery from a double channel-close", { requires: ["gateway", "edgesmsc", "trace"], tags: [LOAD] }), async ({ db, seed, tcx }) => {
    test.setTimeout(300_000);
    const b = edgeB();
    const run = await killWithFullWindow(db, seed);
    const returned = Number(run.reclaim[3]);
    await expect.poll(async () => (await b.stats()).distinct, { timeout: 180_000 }).toBeGreaterThanOrEqual(returned);
    const stats = await b.stats();
    expect(stats.submitsPerMessage).toBeCloseTo(1, 2);
    tcx.note(`vendor B: distinct ${stats.distinct} (reclaimed ${returned}), pdus ${stats.pdus}, submits/message ${stats.submitsPerMessage}`);
  });

  test(...tc("TC-05.03.01-N03", "Reclaim does not fire for a graceful vendor stop", { requires: ["gateway", "edgesmsc", "trace"] }), async ({ seed, tcx }) => {
    test.setTimeout(120_000);
    const a = edgeA();
    await a.baseline();
    const mark = gatewayLog.mark();
    await a.control("quit");
    seed.cleanup(async () => { await a.restart(); await a.baseline(); });
    await new Promise((r) => setTimeout(r, 8000));
    const lines = gatewayLog.grep(RECLAIM, mark);
    for (const l of lines) expect(Number(RECLAIM.exec(l)![2]), l).toBe(0);
    tcx.note(`graceful quit with nothing in flight: ${lines.length === 0 ? "no reclaim line" : lines.map((l) => RECLAIM.exec(l)![0]).join("; ")}`);
  });
});

test.describe("SC-05.03.02 Reclaim on scale-down and on enquire_link failure", () => {
  test(...tc.manual("TC-05.03.02-P01", "Scale-down reclaims the closed sessions' windows", "connections.transceivers is a startup key; run with 3 sessions, then restart to 1 under load and read the reclaim lines"));

  test(...tc("TC-05.03.02-P02", "Enquire-link teardown reclaims", { requires: ["gateway", "edgesmsc", "trace"], tags: [LOAD] }), async ({ db, seed, tcx }) => {
    test.setTimeout(300_000);
    await routeViaFailover(db, seed);
    const a = edgeA();
    await a.baseline();
    await a.delay(400);
    const mark = gatewayLog.mark();
    const esme = await bindA();
    try {
      const burst = esme.submitMany(60, {}, { window: 60 });
      await expect.poll(async () => (await a.stats()).pdus, { timeout: 60_000 }).toBeGreaterThanOrEqual(30);
      // the vendor stops answering everything, enquire_link included; two intervals later the gateway tears the session down
      await a.hang(true);
      const reclaim = await gatewayLog.waitFor(RECLAIM, mark, 120_000);
      await a.hang(false);
      await a.delay(0);
      const run = await burst;
      const b = edgeB();
      await expect.poll(async () => (await a.stats()).distinct + (await b.stats()).distinct, { timeout: 120_000 }).toBeGreaterThanOrEqual(run.accepted);
      tcx.note(`${reclaim[0]}; after hang off everything delivered (${run.accepted})`);
    } finally {
      await esme.unbind();
      await a.baseline();
    }
  });
});
