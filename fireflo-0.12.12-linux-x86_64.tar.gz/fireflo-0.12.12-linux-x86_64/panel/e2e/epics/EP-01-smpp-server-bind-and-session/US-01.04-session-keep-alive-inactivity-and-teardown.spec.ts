/**
 * EP-01 SMPP Server — Bind & Session
 * US-01.04 Session keep-alive, inactivity and teardown
 */
import { expect, test } from "../../fixtures";
import { ops } from "../../fixtures/gateway";
import { VENDORS } from "../../fixtures/gateway-rig";
import { BASELINE } from "../../fixtures/seed";
import { connectEsme } from "../../fixtures/smpp";
import { sessionsOf, waitSessions } from "../../support/flows/gateway";
import { tc } from "../../support/tc";
import { SLOW } from "../../support/tags";

const LISTENER = "smpp";
const A = BASELINE.logins.a;

test.describe("SC-01.04.01 Idle session survives", () => {
  test(...tc("TC-01.04.01-P01", "Idle 3 minutes then submit", { requires: ["gateway", "edgesmsc"], tags: [SLOW] }), async ({ tcx }) => {
    test.setTimeout(300_000);
    const esme = await connectEsme({ ...A, enquireLinkMs: 30_000 });
    try {
      await waitSessions(LISTENER, A.systemId, 1);
      await new Promise((r) => setTimeout(r, 200_000));
      const still = await sessionsOf(LISTENER, A.systemId);
      expect(still.length, "still bound after 200 s idle").toBe(1);
      const r = await esme.submit();
      expect(r.status).toBe(0);
      tcx.note(`bound_seconds ${still[0].bound_seconds}; submit_sm_resp 0x00 after 200 s idle`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc.manual("TC-01.04.01-N01", "Unresponsive client is dropped after maxInactivityTime", "srv.maxInactivityTime is a startup key (600 s in this rig) and SIGSTOP of a client process is not scriptable in-process; run by hand with a small value"));
});

test.describe("SC-01.04.02 Graceful unbind and operator disconnect", () => {
  test(...tc("TC-01.04.02-P01", "unbind is acknowledged", { requires: ["gateway"] }), async ({ tcx }) => {
    const esme = await connectEsme(A);
    await waitSessions(LISTENER, A.systemId, 1);
    const resp = await new Promise<import("smpp").Pdu>((resolve) => esme.session.unbind({}, resolve));
    expect(resp.command_status).toBe(0);
    esme.session.close();
    await waitSessions(LISTENER, A.systemId, 0, 5_000);
    tcx.note("unbind_resp 0x00; session gone from /ops/health within 2 s");
  });

  test(...tc("TC-01.04.02-P02", "Operator disconnects a listener session", { requires: ["gateway"] }), async ({ page, tcx }) => {
    const esme = await connectEsme(A);
    const [s] = await waitSessions(LISTENER, A.systemId, 1);
    let closed = false;
    esme.session.on("close", () => { closed = true; });
    await page.goto("/cp/servers");
    const row = page.locator("tr, li, div").filter({ hasText: A.systemId }).filter({ has: page.getByRole("button", { name: /Disconnect/ }) }).first();
    await row.getByRole("button", { name: /Disconnect/ }).first().click();
    const confirm = page.getByRole("button", { name: /^(Disconnect|Confirm|Yes)/ }).last();
    if (await confirm.isVisible().catch(() => false)) await confirm.click();
    await expect.poll(() => closed, { timeout: 15_000 }).toBe(true);
    await waitSessions(LISTENER, A.systemId, 0, 10_000);
    tcx.note(`session ${s.session_id} disconnected from /cp/servers; ESME saw the socket close`);
  });

  test(...tc("TC-01.04.02-N01", "Disconnect of a vendor session is refused by type", { requires: ["gateway"] }), async ({ tcx }) => {
    const list = await ops().sessions(VENDORS.a);
    const body = list.body as { data?: { sessions?: { session_id?: number }[] } } & { sessions?: { session_id?: number }[] };
    const id = body.sessions?.[0]?.session_id ?? body.data?.sessions?.[0]?.session_id ?? 1;
    const res = await ops().disconnect(VENDORS.a, String(id));
    expect(res.status, `POST disconnect on a vendor → ${res.status} ${res.text.slice(0, 120)}`).toBeGreaterThanOrEqual(400);
    tcx.note(`${res.status}: ${res.text.slice(0, 120)}`);
  });
});
