/**
 * EP-01 SMPP Server — Bind & Session
 * US-01.02 Connection ceilings per IP and per account
 *
 * The rig's listener has srv.maxConnectionsPerIP = 4 and conf.maxConnectionsPerUser.default = 4.
 * The metric is fireflo_smpp_bind_refused_total{reason=…} on /q/metrics; the anti-vacuity half
 * (P02) reads it BEFORE the refusal so the increment in N01 is a change and not a stale value.
 */
import { expect, test } from "../../fixtures";
import { awaitGatewayAdopts } from "../../fixtures/gateway";
import { BASELINE } from "../../fixtures/seed";
import { bindAttempt, connectEsme } from "../../fixtures/smpp";
import type { Esme } from "../../fixtures/smpp";
import { authFailedLog } from "../../fixtures/trace";
import { BIND_REFUSED_METRIC, metric, waitSessions } from "../../support/flows/gateway";
import { tc } from "../../support/tc";

const LISTENER = "smpp";
const A = BASELINE.logins.a;

async function bindN(n: number, extra: Partial<Parameters<typeof connectEsme>[0]> = {}): Promise<Esme[]> {
  const out: Esme[] = [];
  for (let i = 0; i < n; i++) out.push(await connectEsme({ ...A, ...extra }));
  return out;
}
async function closeAll(esmes: Esme[]) { for (const e of esmes) if (e.bound) await e.unbind(); }

test.describe("SC-01.02.01 Per-IP ceiling", () => {
  test(...tc("TC-01.02.01-P01", "Exactly N binds succeed", { requires: ["gateway"] }), async ({ tcx }) => {
    const four = await bindN(4);
    try {
      expect(four.map((e) => e.bindStatus)).toEqual([0, 0, 0, 0]);
      const s = await waitSessions(LISTENER, A.systemId, 4);
      tcx.note(`4 binds from 127.0.0.1 all ESME_ROK; /ops/health lists ${s.length}`);
    } finally {
      await closeAll(four);
    }
  });

  test(...tc("TC-01.02.01-P02", "Counter reads zero when nothing was refused", { requires: ["gateway"] }), async ({ tcx }) => {
    const four = await bindN(4);
    try {
      const before = await metric(BIND_REFUSED_METRIC, { reason: "ip-limit" });
      tcx.note(`with 4 bound, ${BIND_REFUSED_METRIC}{reason="ip-limit"} = ${before ?? "absent"}`);
      expect(before ?? 0, "nothing refused yet in this run").toBe(0);
    } finally {
      await closeAll(four);
    }
  });

  test(...tc("TC-01.02.01-N01", "The (N+1)th bind is refused 0x040D and counted", { requires: ["gateway", "trace"] }), async ({ tcx }) => {
    const four = await bindN(4);
    try {
      await waitSessions(LISTENER, A.systemId, 4);
      const before = (await metric(BIND_REFUSED_METRIC, { reason: "ip-limit" })) ?? 0;
      const mark = authFailedLog.mark();
      const fifth = await bindAttempt(A);
      expect(fifth.status).toBe(0x040d);
      await expect.poll(async () => (await metric(BIND_REFUSED_METRIC, { reason: "ip-limit" })) ?? 0).toBe(before + 1);
      await new Promise((r) => setTimeout(r, 500));
      expect(authFailedLog.count(/auth\.refused/, mark), "capacity is not a credential failure: no auth.refused line").toBe(0);
      tcx.note(`5th bind 0x040D; ip-limit ${before} → ${before + 1}; auth-failed.log unchanged`);
    } finally {
      await closeAll(four);
    }
  });

  test(...tc("TC-01.02.01-N02", "Closing one session frees a slot", { requires: ["gateway"] }), async ({ tcx }) => {
    const four = await bindN(4);
    try {
      await waitSessions(LISTENER, A.systemId, 4);
      await four[0].unbind();
      await waitSessions(LISTENER, A.systemId, 3);
      const again = await connectEsme(A);
      expect(again.bindStatus).toBe(0);
      four[0] = again;
      tcx.note("after one unbind the next bind is ESME_ROK");
    } finally {
      await closeAll(four);
    }
  });

  test(...tc("TC-01.02.01-N03", "A session killed by SIGKILL on the client frees its slot", { requires: ["gateway"] }), async ({ tcx }) => {
    const four = await bindN(4);
    try {
      await waitSessions(LISTENER, A.systemId, 4);
      // an abrupt socket death — what the listener sees when a client is SIGKILLed
      four[0].session.socket.destroy();
      four[0].bound = false;
      await waitSessions(LISTENER, A.systemId, 3, 30_000);
      const again = await connectEsme(A);
      expect(again.bindStatus).toBe(0);
      four[0] = again;
      tcx.note("socket destroyed without unbind; slot released and the next bind is ESME_ROK");
    } finally {
      await closeAll(four);
    }
  });
});

test.describe("SC-01.02.02 Per-account ceiling across IPs", () => {
  test(...tc("TC-01.02.02-P01", "Account limit counts across IPs", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    const account = await seed.account({ label: "QA limit 2" });
    const login = await seed.credential({ accountId: account, product: BASELINE.product });
    await db.q("INSERT INTO app_worker_property (worker_name, key, value) VALUES ($1, $2, '2') ON CONFLICT (worker_name, key) DO UPDATE SET value = '2'", [LISTENER, `conf.maxConnectionsPerUser.${account}`]);
    seed.cleanup(async () => { await db.q("DELETE FROM app_worker_property WHERE worker_name = $1 AND key = $2", [LISTENER, `conf.maxConnectionsPerUser.${account}`]); });
    await awaitGatewayAdopts(async () => (await bindAttempt(login)).status === 0);
    const before = (await metric(BIND_REFUSED_METRIC, { reason: "account-limit" })) ?? 0;
    const a1 = await connectEsme(login);
    const a2 = await connectEsme(login);
    try {
      expect([a1.bindStatus, a2.bindStatus]).toEqual([0, 0]);
      const third = await bindAttempt({ ...login, localAddress: "127.0.0.2" });
      expect(third.status).toBe(0x040e);
      await expect.poll(async () => (await metric(BIND_REFUSED_METRIC, { reason: "account-limit" })) ?? 0).toBe(before + 1);
      tcx.note(`2 from 127.0.0.1 bound; 3rd from 127.0.0.2 → 0x040E; account-limit ${before} → ${before + 1}`);
    } finally {
      await a1.unbind(); await a2.unbind();
    }
  });

  test(...tc("TC-01.02.02-N01", "Per-account override beats the default", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    const account = await seed.account({ label: "QA limit 5" });
    const login = await seed.credential({ accountId: account, product: BASELINE.product });
    await db.q("INSERT INTO app_worker_property (worker_name, key, value) VALUES ($1, $2, '5') ON CONFLICT (worker_name, key) DO UPDATE SET value = '5'", [LISTENER, `conf.maxConnectionsPerUser.${account}`]);
    seed.cleanup(async () => { await db.q("DELETE FROM app_worker_property WHERE worker_name = $1 AND key = $2", [LISTENER, `conf.maxConnectionsPerUser.${account}`]); });
    await awaitGatewayAdopts(async () => (await bindAttempt(login)).status === 0);
    // the per-IP ceiling is 4, so the five come from two addresses
    const bound: Esme[] = [];
    try {
      for (let i = 0; i < 5; i++) bound.push(await connectEsme({ ...login, localAddress: i < 3 ? "127.0.0.1" : "127.0.0.2" }));
      expect(bound.map((e) => e.bindStatus)).toEqual([0, 0, 0, 0, 0]);
      const sixth = await bindAttempt({ ...login, localAddress: "127.0.0.3" });
      expect(sixth.status).toBe(0x040e);
      tcx.note(`override 5: five bound across 127.0.0.1/.2, sixth from .3 → 0x040E (default would have stopped at 4)`);
    } finally {
      await closeAll(bound);
    }
  });
});
