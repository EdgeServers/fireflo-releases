/**
 * EP-01 SMPP Server — Bind & Session
 * US-01.05 TLS and PROXY-protocol listeners
 *
 * TLS needs a keystore and a restart, so its cases stay manual. The second listener (smpp2) answers
 * the PROXY protocol on E2E_SMPP_PROXY_PORT, which is what SC-01.05.02 drives.
 */
import { expect, test } from "../../fixtures";
import { BASELINE } from "../../fixtures/seed";
import { bindAttempt } from "../../fixtures/smpp";
import { authFailedLog } from "../../fixtures/trace";
import { tc } from "../../support/tc";

const A = BASELINE.logins.a;

test.describe("SC-01.05.01 TLS bind", () => {
  test(...tc.manual("TC-01.05.01-P01", "TLS bind succeeds", "needs a keystore on the host and a restart with srv.tls.* set"));
  test(...tc.manual("TC-01.05.01-N01", "Plaintext to the TLS port is refused", "needs the TLS listener of TC-01.05.01-P01"));
  test(...tc.manual("TC-01.05.01-N02", "Wrong keystore password fails to start the TLS listener and says so", "needs a restart with a deliberately wrong srv.tls.keystore.password"));
});

test.describe("SC-01.05.02 PROXY protocol peer address", () => {
  test(...tc("TC-01.05.02-P01", "Recorded IP is the client behind the proxy", { requires: ["gateway", "trace"] }), async ({ env, tcx }) => {
    const mark = authFailedLog.mark();
    const withHeader = await bindAttempt({ systemId: A.systemId, password: "wrong", port: env.smppProxyPort, proxyHeader: `PROXY TCP4 203.0.113.9 127.0.0.1 40000 ${env.smppProxyPort}` });
    const line = await authFailedLog.waitFor(/auth\.refused surface=smpp reason=badPassword identity="[^"]+" ip=(\S+)/, mark);
    expect(line[1], "the address the header named, not the proxy's").toBe("203.0.113.9");
    // and without the header on the same port the address recorded is NOT 203.0.113.9
    const mark2 = authFailedLog.mark();
    const bare = await bindAttempt({ systemId: A.systemId, password: "wrong", port: env.smppProxyPort });
    await new Promise((r) => setTimeout(r, 1500));
    const bareLines = authFailedLog.grep(/auth\.refused/, mark2);
    for (const l of bareLines) expect(l).not.toContain("ip=203.0.113.9");
    tcx.note(`with header: 0x${withHeader.status.toString(16)} ip=203.0.113.9; without: 0x${bare.status.toString(16)} (${bareLines.length} line(s), none naming 203.0.113.9)`);
  });

  test(...tc("TC-01.05.02-N01", "PROXY header on the non-proxy port is rejected", { requires: ["gateway"] }), async ({ env, tcx }) => {
    const r = await bindAttempt({ ...A, port: env.smppPort2, proxyHeader: `PROXY TCP4 203.0.113.9 127.0.0.1 40000 ${env.smppPort2}` });
    expect(r.status, "a PROXY line on the plain port is not a bind").not.toBe(0);
    tcx.note(`plain port answered ${r.status === -1 ? `no bind (${r.error})` : `0x${r.status.toString(16)}`}`);
  });
});
