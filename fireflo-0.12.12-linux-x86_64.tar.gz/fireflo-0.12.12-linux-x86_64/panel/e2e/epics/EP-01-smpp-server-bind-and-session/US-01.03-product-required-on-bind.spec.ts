/**
 * EP-01 SMPP Server — Bind & Session
 * US-01.03 Product required on bind
 *
 * `conf.product.required` on the listener, flipped through app_worker_property and adopted on the
 * poll; system_type carries the product name on bind.
 */
import { expect, test } from "../../fixtures";
import { awaitGatewayAdopts } from "../../fixtures/gateway";
import { BASELINE } from "../../fixtures/seed";
import { bindAttempt, connectEsme } from "../../fixtures/smpp";
import { BIND_REFUSED_METRIC, metric, sendAndRecord } from "../../support/flows/gateway";
import { tc } from "../../support/tc";

const LISTENER = "smpp";
const A = BASELINE.logins.a;

async function setRequired(db: import("../../fixtures").Db, seed: import("../../fixtures").Seed, on: boolean) {
  await db.q("INSERT INTO app_worker_property (worker_name, key, value) VALUES ($1, 'conf.product.required', $2) ON CONFLICT (worker_name, key) DO UPDATE SET value = EXCLUDED.value", [LISTENER, String(on)]);
  seed.cleanup(async () => { await db.q("DELETE FROM app_worker_property WHERE worker_name = $1 AND key = 'conf.product.required'", [LISTENER]); });
  // adopted when a bind with a bogus product starts (or stops) being refused
  await awaitGatewayAdopts(async () => ((await bindAttempt({ ...A, systemType: "qa-bogus-product" })).status === 0) !== on);
}

test.describe("SC-01.03.01 Product enforcement on and off", () => {
  test(...tc("TC-01.03.01-P01", "Known product binds", { requires: ["gateway", "edgesmsc"] }), async ({ db, seed, tcx }) => {
    await setRequired(db, seed, true);
    const esme = await connectEsme({ ...A, systemType: BASELINE.product });
    try {
      expect(esme.bindStatus).toBe(0);
      const { messageId } = await sendAndRecord(esme, db);
      const row = await db.one<{ product: string }>("SELECT product FROM cdr_submit WHERE gateway_msg_id = $1", [messageId]);
      expect(row.product).toBe(BASELINE.product);
      tcx.note(`bind with system_type=${BASELINE.product} ESME_ROK; cdr_submit.product=${row.product}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-01.03.01-P02", "Enforcement off accepts anything", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    await setRequired(db, seed, false);
    const r = await bindAttempt({ ...A, systemType: "qa-bogus-product" });
    expect(r.status).toBe(0);
    tcx.note("required=false: system_type=qa-bogus-product binds ESME_ROK");
  });

  test(...tc("TC-01.03.01-N01", "Unknown product refused 0x040F", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    await setRequired(db, seed, true);
    const before = (await metric(BIND_REFUSED_METRIC, { reason: "product" })) ?? 0;
    const r = await bindAttempt({ ...A, systemType: "qa-bogus-product" });
    expect(r.status).toBe(0x040f);
    await expect.poll(async () => (await metric(BIND_REFUSED_METRIC, { reason: "product" })) ?? 0).toBe(before + 1);
    tcx.note(`0x040F; product refusals ${before} → ${before + 1}`);
  });

  test(...tc("TC-01.03.01-N02", "Empty system_type refused when required", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    await setRequired(db, seed, true);
    const r = await bindAttempt({ ...A, systemType: "" });
    expect(r.status).toBe(0x040f);
    tcx.note("required=true: empty system_type → 0x040F");
  });
});
