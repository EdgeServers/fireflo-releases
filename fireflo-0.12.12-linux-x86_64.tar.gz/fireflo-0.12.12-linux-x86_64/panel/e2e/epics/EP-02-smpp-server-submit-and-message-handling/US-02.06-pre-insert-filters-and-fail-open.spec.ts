/**
 * EP-02 SMPP Server — Submit & Message Handling
 * US-02.06 Pre-insert filters and fail-open
 *
 * A filter is an app_filter row with conditions, attached to the listener through
 * `filters.beforeInsertMessage`. The throwing-filter cases need a filter that fails at match time;
 * nothing in the product provokes that on demand, so they stay manual.
 */
import { expect, test } from "../../fixtures";
import { edgeA } from "../../fixtures/edgesmsc";
import { awaitGatewayAdopts } from "../../fixtures/gateway";
import { BASELINE } from "../../fixtures/seed";
import { bindA } from "../../support/flows/gateway";
import { balanceOf, rejectedFor, setWorkerProperty } from "../../support/flows/submit";
import { tc } from "../../support/tc";

const LISTENER = "smpp";
const A = BASELINE.accounts.a;

async function dropFilter(db: import("../../fixtures").Db, seed: import("../../fixtures").Seed, name: string, prefix: string) {
  await db.q("INSERT INTO app_filter (name, label, enabled) VALUES ($1, 'QA drop', true) ON CONFLICT (name) DO NOTHING", [name]);
  await db.q("INSERT INTO app_filter_condition (filter_name, seq, field, operator, value, negate) VALUES ($1, 1, 'to', 'startsWith', $2, false) ON CONFLICT DO NOTHING", [name, prefix]);
  seed.cleanup(async () => { await db.q("DELETE FROM app_filter WHERE name = $1", [name]); });
  const restore = await setWorkerProperty(db, LISTENER, "filters.beforeInsertMessage", name);
  seed.cleanup(restore);
  await awaitGatewayAdopts(async () => true);
}

test.describe("SC-02.06.01 Filter drop and filter failure", () => {
  test(...tc("TC-02.06.01-P01", "Non-matching message passes the filter", { requires: ["gateway", "edgesmsc"] }), async ({ db, seed, tcx }) => {
    await dropFilter(db, seed, seed.name("drop99"), "99");
    const esme = await bindA();
    try {
      const r = await esme.submit({ dest: "919876543210" });
      expect(r.status).toBe(0);
      await db.waitForRow("SELECT 1 FROM cdr_submit WHERE gateway_msg_id = $1", [r.messageId]);
      tcx.note("to 91…: 0x00 and a cdr_submit row");
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-02.06.01-N01", "Matching message is dropped and recorded", { requires: ["gateway", "edgesmsc"] }), async ({ db, seed, tcx }) => {
    await dropFilter(db, seed, seed.name("drop99"), "99");
    const edge = edgeA();
    await edge.baseline();
    const esme = await bindA();
    try {
      const before = await balanceOf(db, A);
      const since = new Date();
      const r = await esme.submit({ dest: "990000000001", registeredDelivery: 1 });
      const rej = await db.waitForRow<{ reason: string; receipt: string | null }>(
        "SELECT reason, receipt FROM cdr_rejected WHERE rejected_at >= $1 AND system_id = $2 ORDER BY id DESC LIMIT 1", [since, BASELINE.logins.a.systemId], { timeoutMs: 20_000 });
      expect(rej.reason).toBe("filtered");
      await expect.poll(async () => (await balanceOf(db, A)).total, { timeout: 20_000 }).toBe(before.total);
      await new Promise((x) => setTimeout(x, 1500));
      expect((await edge.stats()).pdus).toBe(0);
      const receipt = r.status === 0 ? await esme.waitReceipt(() => true, 20_000).catch(() => null) : null;
      tcx.note(`submit_sm_resp 0x${r.status.toString(16)}; cdr_rejected reason=${rej.reason} receipt=${rej.receipt}; refunded; vendor pdus 0; customer receipt ${receipt ? receipt.fields.stat + "/" + receipt.fields.err : "none"}`);
      const rejected = await rejectedFor(db, { since, reason: "filtered", systemId: BASELINE.logins.a.systemId });
      expect(rejected.length).toBe(1);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc.manual("TC-02.06.01-N02", "Throwing filter fails open by default", "needs a filter that throws at match time; nothing in the product provokes that on demand"));
  test(...tc.manual("TC-02.06.01-N03", "Throwing filter fails closed when configured", "needs a filter that throws at match time; nothing in the product provokes that on demand"));
});
