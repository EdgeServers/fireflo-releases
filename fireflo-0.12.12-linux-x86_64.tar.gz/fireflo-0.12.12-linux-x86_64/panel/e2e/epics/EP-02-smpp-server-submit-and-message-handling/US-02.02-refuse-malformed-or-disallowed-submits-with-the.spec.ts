/**
 * EP-02 SMPP Server — Submit & Message Handling
 * US-02.02 Refuse malformed or disallowed submits with the right code and no charge
 */
import { expect, test } from "../../fixtures";
import { BASELINE } from "../../fixtures/seed";
import { bindA, sessionsOf } from "../../support/flows/gateway";
import { balanceOf, rejectedFor, setWorkerProperty, unknownCommandPdu } from "../../support/flows/submit";
import { tc } from "../../support/tc";

const LISTENER = "smpp";
const A = BASELINE.accounts.a;

test.describe("SC-02.02.01 Address and length faults", () => {
  test(...tc("TC-02.02.01-N01", "Empty source address -> 0x0A", { requires: ["gateway"] }), async ({ db, tcx }) => {
    const esme = await bindA();
    try {
      const before = await balanceOf(db, A);
      const rows = await db.count("cdr_submit", "account_id = $1", [A]);
      const r = await esme.submit({ source: "" });
      expect(r.status).toBe(0x0a);
      expect(await db.count("cdr_submit", "account_id = $1", [A])).toBe(rows);
      expect(await balanceOf(db, A)).toEqual(before);
      tcx.note("0x0A; no cdr_submit; balance identical");
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-02.02.01-N02", "Empty destination -> 0x0B", { requires: ["gateway"] }), async ({ tcx }) => {
    const esme = await bindA();
    try {
      const r = await esme.submit({ dest: "" });
      expect(r.status).toBe(0x0b);
      tcx.note("0x0B");
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-02.02.01-N03", "Destination failing ptrn.valid.receiver -> 0x0B", { requires: ["gateway"] }), async ({ db, tcx }) => {
    const restore = await setWorkerProperty(db, LISTENER, "ptrn.valid.receiver", "^91[0-9]{10}$");
    const esme = await bindA();
    try {
      const since = new Date();
      const r = await esme.submit({ dest: "447700900123" });
      expect(r.status).toBe(0x0b);
      const rej = await rejectedFor(db, { since, systemId: BASELINE.logins.a.systemId });
      tcx.note(`0x0B; cdr_rejected: ${rej.map((x) => `${x.reason}/${(x.detail ?? "").slice(0, 60)}`).join("; ") || "none"}`);
    } finally {
      await esme.unbind();
      await restore();
    }
  });

  test(...tc("TC-02.02.01-N04", "short_message > 254 without payload TLV -> 0x01", { requires: ["gateway"] }), async ({ tcx }) => {
    const esme = await bindA();
    try {
      const r = await esme.submit({ text: "x".repeat(255) }).catch((e) => ({ status: -1, messageId: null, pdu: null as never, error: String(e) }));
      // the codec may refuse to encode 255 octets at all; either way the gateway never accepts it
      expect(r.status === 0x01 || r.status === -1).toBe(true);
      tcx.note(r.status === -1 ? `client codec refused to encode 255 octets (${(r as { error?: string }).error})` : "ESME_RINVMSGLEN 0x01");
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-02.02.01-N05", "Invalid schedule_delivery_time -> 0x61", { requires: ["gateway"] }), async ({ tcx }) => {
    const esme = await bindA();
    try {
      const pdu = await new Promise<import("smpp").Pdu>((resolve, reject) => {
        const t = setTimeout(() => reject(new Error("no submit_sm_resp")), 15_000);
        esme.session.submit_sm({ source_addr: "QATEST", destination_addr: "61400000001", short_message: "qa", schedule_delivery_time: "garbage" }, (p) => { clearTimeout(t); resolve(p); });
      });
      expect(pdu.command_status).toBe(0x61);
      tcx.note(`0x${pdu.command_status.toString(16)}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-02.02.01-P01", "Valid E.164 destination passes the pattern", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const restore = await setWorkerProperty(db, LISTENER, "ptrn.valid.receiver", "^91[0-9]{10}$");
    const esme = await bindA();
    try {
      const r = await esme.submit({ dest: "919876543210" });
      expect(r.status).toBe(0);
      tcx.note("919876543210 → 0x00 under ^91[0-9]{10}$");
    } finally {
      await esme.unbind();
      await restore();
    }
  });
});

test.describe("SC-02.02.02 DCS and charset faults", () => {
  test(...tc("TC-02.02.02-N01", "Unknown DCS -> 0x040B RINVDCS", { requires: ["gateway"] }), async ({ db, tcx }) => {
    const esme = await bindA();
    try {
      const since = new Date();
      const r = await esme.submit({ dcs: 0x0c, text: "qa" });
      expect(r.status).toBe(0x040b);
      const rej = await rejectedFor(db, { since, systemId: BASELINE.logins.a.systemId });
      tcx.note(`0x040B; cdr_rejected: ${rej.map((x) => `${x.reason}/${(x.detail ?? "").slice(0, 60)}`).join("; ") || "none"}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-02.02.02-P01", "Mapped DCS accepted", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const esme = await bindA();
    try {
      const body = Buffer.from("Ünïcödé", "utf16le").swap16();
      const r = await esme.submit({ dcs: 8, text: body });
      expect(r.status).toBe(0);
      const row = await db.waitForRow<{ dcs: number; msg_type: number }>("SELECT dcs, msg_type FROM cdr_submit WHERE gateway_msg_id = $1", [r.messageId]);
      expect(Number(row.dcs)).toBe(8);
      tcx.note(`0x00; cdr_submit dcs=${row.dcs} msg_type=${row.msg_type}`);
    } finally {
      await esme.unbind();
    }
  });
});

test.describe("SC-02.02.03 Generic NACK for an unknown command", () => {
  test(...tc("TC-02.02.03-N01", "Unknown command_id -> generic_nack INVCMDID", { requires: ["gateway"] }), async ({ tcx }) => {
    const esme = await bindA();
    try {
      const nack = new Promise<import("smpp").Pdu>((resolve) => esme.session.on("generic_nack", resolve));
      esme.session.socket.write(unknownCommandPdu(0x7777, 4242));
      const pdu = await Promise.race([nack, new Promise<never>((_r, rej) => setTimeout(() => rej(new Error("no generic_nack")), 10_000))]);
      expect(pdu.command_status).toBe(0x03);
      expect(pdu.sequence_number).toBe(4242);
      expect((await sessionsOf("smpp", BASELINE.logins.a.systemId)).length, "still bound").toBe(1);
      const ok = await esme.submit();
      expect(ok.status).toBe(0);
      tcx.note("generic_nack 0x03 with the request's sequence; session bound; next submit 0x00");
    } finally {
      await esme.unbind();
    }
  });

  test(...tc.manual("TC-02.02.03-N02", "A flood of unknown commands does not grow memory unbounded", "the oracle is a heap histogram (jcmd GC.class_histogram) on the gateway process; the behavioural half runs under TC-02.02.03-N01"));
});
