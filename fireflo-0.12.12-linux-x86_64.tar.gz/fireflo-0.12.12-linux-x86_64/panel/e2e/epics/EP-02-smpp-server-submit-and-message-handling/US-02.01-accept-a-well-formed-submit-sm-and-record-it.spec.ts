/**
 * EP-02 SMPP Server — Submit & Message Handling
 * US-02.01 Accept a well-formed submit_sm and record it
 */
import { expect, test } from "../../fixtures";
import { edgeA } from "../../fixtures/edgesmsc";
import { VENDORS } from "../../fixtures/gateway-rig";
import { BASELINE } from "../../fixtures/seed";
import { gatewayLog } from "../../fixtures/trace";
import { bindA, sendAndRecord } from "../../support/flows/gateway";
import { tc } from "../../support/tc";

test.describe("SC-02.01.01 Single-segment GSM message end to end", () => {
  test(...tc("TC-02.01.01-P01", "Ack carries the gateway id", { requires: ["gateway", "edgesmsc"] }), async ({ tcx }) => {
    const esme = await bindA();
    try {
      const r = await esme.submit({ text: "qa single segment" });
      expect(r.status).toBe(0);
      expect(r.messageId ?? "").toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/);
      tcx.note(`submit_sm_resp 0x00 message_id=${r.messageId}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-02.01.01-P02", "Exactly one cdr_submit row", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const esme = await bindA();
    try {
      const { messageId } = await sendAndRecord(esme, db);
      const rows = await db.q<{ ingress: string; in_gateway: string; account_id: string; system_id: string; vendor: string }>(
        "SELECT ingress, in_gateway, account_id, system_id, vendor FROM cdr_submit WHERE gateway_msg_id = $1", [messageId]);
      expect(rows.length).toBe(1);
      expect(rows[0]).toMatchObject({ ingress: "smpp", in_gateway: "smppserver.smpp", account_id: BASELINE.accounts.a, system_id: BASELINE.logins.a.systemId });
      expect(rows[0].vendor).toContain(VENDORS.a);
      tcx.note(`1 row: ${JSON.stringify(rows[0])}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-02.01.01-P03", "Exactly one vendor submit", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const edge = edgeA();
    await edge.baseline();
    const esme = await bindA();
    try {
      await sendAndRecord(esme, db);
      await expect.poll(async () => (await edge.stats()).pdus, { timeout: 15_000 }).toBe(1);
      const one = await edge.stats();
      expect(one.distinct).toBe(1);
      // the anti-vacuity half: a second message makes it 2, so `stats` is counting
      await sendAndRecord(esme, db);
      await expect.poll(async () => (await edge.stats()).pdus, { timeout: 15_000 }).toBe(2);
      const two = await edge.stats();
      expect(two.submitsPerMessage).toBeCloseTo(1, 2);
      tcx.note(`EdgeSmsc pdus 1 → 2, distinct ${two.distinct}, submitsPerMessage ${two.submitsPerMessage}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-02.01.01-P04", "Trace shows the necessary events", { requires: ["gateway", "edgesmsc", "trace"] }), async ({ db, seed, tcx }) => {
    // the rig runs smsg.diagnostics=problems → trace `necessary`; pin it explicitly for this case
    await seed.config("message.trace.mode", "necessary");
    const mark = gatewayLog.mark();
    const esme = await bindA();
    try {
      const { messageId } = await sendAndRecord(esme, db);
      await gatewayLog.waitFor(new RegExp(`message\\.submitted.*${messageId}|${messageId}.*message\\.submitted`), mark);
      const lines = gatewayLog.traceOf(messageId, mark);
      expect(lines.some((l) => l.includes("message.accepted"))).toBe(true);
      expect(lines.some((l) => l.includes("message.submitted"))).toBe(true);
      expect(lines.some((l) => l.includes("message.routed")), "message.routed is an `all`-level event").toBe(false);
      tcx.note(`${lines.length} trace lines for ${messageId}: ${lines.map((l) => /message\.[a-z.]+/.exec(l)?.[0]).filter(Boolean).join(", ")}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-02.01.01-N01", "Second identical submit is a second message, not deduplicated", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const edge = edgeA();
    await edge.baseline();
    const esme = await bindA();
    try {
      const a = await sendAndRecord(esme, db, { text: "same body", dest: "61400000123" });
      const b = await sendAndRecord(esme, db, { text: "same body", dest: "61400000123" });
      expect(a.messageId).not.toBe(b.messageId);
      expect(await db.count("cdr_submit", "gateway_msg_id = ANY($1)", [[a.messageId, b.messageId]])).toBe(2);
      await expect.poll(async () => (await edge.stats()).pdus, { timeout: 15_000 }).toBe(2);
      tcx.note(`ids ${a.messageId.slice(0, 8)}… and ${b.messageId.slice(0, 8)}…; 2 rows; EdgeSmsc pdus=2`);
    } finally {
      await esme.unbind();
    }
  });
});
