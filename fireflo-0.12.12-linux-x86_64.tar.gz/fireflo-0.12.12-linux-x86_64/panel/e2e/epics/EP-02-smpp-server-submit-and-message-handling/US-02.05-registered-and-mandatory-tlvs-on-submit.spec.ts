/**
 * EP-02 SMPP Server — Submit & Message Handling
 * US-02.05 Registered and mandatory TLVs on submit
 */
import { expect, test } from "../../fixtures";
import { BASELINE } from "../../fixtures/seed";
import { gatewayLog } from "../../fixtures/trace";
import { bindA } from "../../support/flows/gateway";
import { balanceOf, rejectedFor, setWorkerProperty, tlv } from "../../support/flows/submit";
import { tc } from "../../support/tc";

const LISTENER = "smpp";
const A = BASELINE.accounts.a;

test.describe("SC-02.05.01 Mandatory TLV enforcement", () => {
  test(...tc("TC-02.05.01-P01", "Submit with the mandatory TLV is accepted and recorded", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const restoreReg = await setWorkerProperty(db, LISTENER, "registered.tlvs.submit", "peid_0x1400");
    const restoreMan = await setWorkerProperty(db, LISTENER, "mandatory.tlvs.submit", "peid_0x1400");
    const peid = tlv("peid", 0x1400);
    const esme = await bindA();
    try {
      const r = await esme.submit({ tlvs: { [peid]: "PEID123" } });
      expect(r.status).toBe(0);
      const row = await db.waitForRow<{ tlvs_received: string | null }>("SELECT tlvs_received FROM cdr_submit WHERE gateway_msg_id = $1", [r.messageId]);
      expect(row.tlvs_received ?? "").toMatch(/1400/i);
      tcx.note(`0x00; tlvs_received=${row.tlvs_received}`);
    } finally {
      await esme.unbind();
      await restoreMan(); await restoreReg();
    }
  });

  test(...tc("TC-02.05.01-N01", "Missing mandatory TLV -> 0xC3, unbilled", { requires: ["gateway"] }), async ({ db, tcx }) => {
    const restoreReg = await setWorkerProperty(db, LISTENER, "registered.tlvs.submit", "peid_0x1400");
    const restoreMan = await setWorkerProperty(db, LISTENER, "mandatory.tlvs.submit", "peid_0x1400");
    const esme = await bindA();
    try {
      const before = await balanceOf(db, A);
      const since = new Date();
      const r = await esme.submit();
      expect(r.status).toBe(0xc3);
      await new Promise((x) => setTimeout(x, 1500));
      expect(await balanceOf(db, A)).toEqual(before);
      const rej = await rejectedFor(db, { since, systemId: BASELINE.logins.a.systemId });
      tcx.note(`0xC3; balance unchanged; cdr_rejected ${rej.map((x) => `${x.reason}/${(x.detail ?? "").slice(0, 60)}`).join("; ") || "none"}`);
    } finally {
      await esme.unbind();
      await restoreMan(); await restoreReg();
    }
  });

  test(...tc("TC-02.05.01-N02", "Unregistered TLV is dropped, not refused", { requires: ["gateway", "edgesmsc", "trace"] }), async ({ db, tcx }) => {
    const restoreReg = await setWorkerProperty(db, LISTENER, "registered.tlvs.submit", "peid_0x1400");
    const other = tlv("qatlv1499", 0x1499);
    const mark = gatewayLog.mark();
    const esme = await bindA();
    try {
      const r = await esme.submit({ tlvs: { [other]: "dropme" } });
      expect(r.status).toBe(0);
      const row = await db.waitForRow<{ tlvs_received: string | null }>("SELECT tlvs_received FROM cdr_submit WHERE gateway_msg_id = $1", [r.messageId]);
      expect(row.tlvs_received ?? "").not.toMatch(/1499/i);
      const dropped = await gatewayLog.waitFor(/message\.tlv\.dropped.*1499/i, mark);
      tcx.note(`0x00; tlvs_received=${row.tlvs_received ?? "∅"}; ${dropped.input.slice(dropped.input.indexOf("message.tlv"), dropped.input.indexOf("message.tlv") + 80)}`);
    } finally {
      await esme.unbind();
      await restoreReg();
    }
  });

  test(...tc("TC-02.05.01-P02", "Hex and decimal tag grammar are equivalent", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const restoreReg = await setWorkerProperty(db, LISTENER, "registered.tlvs.submit", "peid_5120");
    const restoreMan = await setWorkerProperty(db, LISTENER, "mandatory.tlvs.submit", "peid_5120");
    const peid = tlv("peid", 0x1400);
    const esme = await bindA();
    try {
      const without = await esme.submit();
      const withTlv = await esme.submit({ tlvs: { [peid]: "PEID123" } });
      expect(without.status, "decimal 5120 is 0x1400: missing → 0xC3").toBe(0xc3);
      expect(withTlv.status).toBe(0);
      tcx.note("peid_5120 behaves as peid_0x1400: 0xC3 without, 0x00 with");
    } finally {
      await esme.unbind();
      await restoreMan(); await restoreReg();
    }
  });
});
