/**
 * EP-02 SMPP Server — Submit & Message Handling
 * US-02.07 Queue-full backpressure at ingress
 *
 * smsg.queue.capacity is 2000 in this rig. EdgeSmsc holds every submit for 400 ms so the vendor
 * queue fills; refusals must be 0x14 (ESME_RMSGQFUL) and unbilled; on recovery the backlog drains
 * exactly once.
 */
import { expect, test } from "../../fixtures";
import { edgeA } from "../../fixtures/edgesmsc";
import { awaitGatewayAdopts } from "../../fixtures/gateway";
import { BASELINE } from "../../fixtures/seed";
import { bindAttempt, connectEsme } from "../../fixtures/smpp";
import { metric } from "../../support/flows/gateway";
import { balanceOf } from "../../support/flows/submit";
import { tc } from "../../support/tc";
import { LOAD } from "../../support/tags";

async function bigAccount(db: import("../../fixtures").Db, seed: import("../../fixtures").Seed) {
  const account = await seed.account({ label: "QA backpressure" });
  await seed.balance({ accountId: account, balance: 1_000_000_000 });
  const login = await seed.credential({ accountId: account, product: BASELINE.product });
  await awaitGatewayAdopts(async () => (await bindAttempt(login)).status === 0);
  return { account, login };
}

test.describe("SC-02.07.01 Fill and drain", () => {
  test(...tc("TC-02.07.01-P01", "Backlog drains exactly once after recovery", { requires: ["gateway", "edgesmsc"], tags: [LOAD] }), async ({ db, seed, env, tcx }) => {
    test.setTimeout(300_000);
    const { account, login } = await bigAccount(db, seed);
    const edge = edgeA();
    await edge.baseline();
    await edge.delay(400);
    const esme = await connectEsme(login);
    try {
      const n = Math.max(500, Math.round(6000 * env.loadScale));
      const fill = await esme.submitMany(n, {}, { window: 300 });
      const refused = fill.refused.get(0x14) ?? 0;
      await edge.delay(0);
      await db.waitForCount("cdr_submit", "account_id = $1", [account], fill.accepted, { timeoutMs: 120_000 });
      await expect.poll(async () => (await edge.stats()).distinct, { timeout: 120_000 }).toBe(fill.accepted);
      const stats = await edge.stats();
      expect(stats.submitsPerMessage).toBeCloseTo(1, 2);
      expect(await db.count("cdr_submit", "account_id = $1", [account])).toBe(fill.accepted);
      tcx.note(`offered ${n}: accepted ${fill.accepted}, refused 0x14 ${refused}; after drain vendor distinct ${stats.distinct}, submits/message ${stats.submitsPerMessage}, cdr rows ${fill.accepted}`);
    } finally {
      await esme.unbind();
      await edge.baseline();
    }
  });

  test(...tc("TC-02.07.01-N01", "Refusals are 0x14 and unbilled", { requires: ["gateway", "edgesmsc"], tags: [LOAD] }), async ({ db, seed, env, tcx }) => {
    test.setTimeout(300_000);
    const { account, login } = await bigAccount(db, seed);
    const edge = edgeA();
    await edge.baseline();
    await edge.delay(400);
    const before = await balanceOf(db, account);
    const esme = await connectEsme(login);
    try {
      const n = Math.max(500, Math.round(6000 * env.loadScale));
      const fill = await esme.submitMany(n, {}, { window: 300 });
      const other = [...fill.refused].filter(([k]) => k !== 0x14);
      expect(other, "every refusal is ESME_RMSGQFUL").toEqual([]);
      expect(fill.refused.get(0x14) ?? 0).toBeGreaterThan(0);
      await edge.delay(0);
      await db.waitForCount("cdr_submit", "account_id = $1", [account], fill.accepted, { timeoutMs: 120_000 });
      await new Promise((x) => setTimeout(x, 2000));
      const after = await balanceOf(db, account);
      expect(before.total - after.total, "charged for accepted messages only").toBe(fill.accepted * BASELINE.price);
      tcx.note(`accepted ${fill.accepted}, 0x14 ${fill.refused.get(0x14)}; balance −${before.total - after.total} = ${fill.accepted}×${BASELINE.price}`);
    } finally {
      await esme.unbind();
      await edge.baseline();
    }
  });

  test(...tc("TC-02.07.01-N02", "Age metric rises before depth alerts would", { requires: ["gateway", "edgesmsc"], tags: [LOAD] }), async ({ db, seed, env, tcx }) => {
    test.setTimeout(300_000);
    const { login } = await bigAccount(db, seed);
    const edge = edgeA();
    await edge.baseline();
    await edge.delay(400);
    const esme = await connectEsme(login);
    try {
      const idle = (await metric("fireflo_queues_oldest_wait_seconds")) ?? 0;
      const n = Math.max(300, Math.round(3000 * env.loadScale));
      const filling = esme.submitMany(n, {}, { window: 200 });
      let peak = 0;
      for (let i = 0; i < 20; i++) {
        await new Promise((x) => setTimeout(x, 500));
        peak = Math.max(peak, (await metric("fireflo_queues_oldest_wait_seconds")) ?? 0);
      }
      await filling;
      await edge.delay(0);
      expect(peak, "the oldest-wait gauge climbs while the vendor is slow").toBeGreaterThan(idle + 0.3);
      tcx.note(`fireflo_queues_oldest_wait_seconds idle ${idle} → peak ${peak.toFixed(2)} during the fill`);
    } finally {
      await esme.unbind();
      await edge.baseline();
    }
  });
});
