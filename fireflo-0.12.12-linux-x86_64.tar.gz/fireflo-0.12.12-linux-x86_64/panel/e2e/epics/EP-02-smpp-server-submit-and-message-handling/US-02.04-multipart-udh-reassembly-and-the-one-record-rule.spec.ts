/**
 * EP-02 SMPP Server — Submit & Message Handling
 * US-02.04 Multipart (UDH) reassembly and the one-record rule
 */
import { expect, test } from "../../fixtures";
import { edgeA } from "../../fixtures/edgesmsc";
import { BASELINE } from "../../fixtures/seed";
import type { Esme } from "../../fixtures/smpp";
import { bindA } from "../../support/flows/gateway";
import { balanceOf, rejectedFor, setWorkerProperty, tlv, ucs2Segments } from "../../support/flows/submit";
import { tc } from "../../support/tc";

const LISTENER = "smpp";
const A = BASELINE.accounts.a;
const LONG = "Ünïcödé ".repeat(30); // 240 UCS-2 characters → 3 segments of 67

async function sendParts(esme: Esme, parts: { udh: Buffer; text: Buffer }[], extra: Record<string, unknown> = {}) {
  const out: { status: number; messageId: string | null }[] = [];
  for (const p of parts) out.push(await esme.submit({ udh: p.udh, text: p.text, dcs: 8, registeredDelivery: 1, ...(extra as object) }));
  return out;
}

test.describe("SC-02.04.01 3-part UCS-2 message", () => {
  test(...tc("TC-02.04.01-P01", "All three segments acked", { requires: ["gateway", "edgesmsc"] }), async ({ tcx }) => {
    const esme = await bindA();
    try {
      const acks = await sendParts(esme, ucs2Segments(LONG, 3));
      expect(acks.map((a) => a.status)).toEqual([0, 0, 0]);
      expect(acks.every((a) => !!a.messageId)).toBe(true);
      tcx.note(`ids ${acks.map((a) => a.messageId?.slice(0, 8)).join(", ")}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-02.04.01-P02", "One cdr_submit money row", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const esme = await bindA();
    try {
      const acks = await sendParts(esme, ucs2Segments(LONG, 3));
      const ids = acks.map((a) => a.messageId!);
      const row = await db.waitForRow<{ gateway_msg_id: string; part_no: number; price: string | null; reassembled_parts: string[] | null }>(
        "SELECT gateway_msg_id, part_no, price::text, reassembled_parts FROM cdr_submit WHERE gateway_msg_id = ANY($1) OR reassembled_parts && $1::text[] ORDER BY id LIMIT 1", [ids], { timeoutMs: 30_000 });
      await new Promise((r) => setTimeout(r, 1500));
      const priced = await db.count("cdr_submit", "(gateway_msg_id = ANY($1) OR reassembled_parts && $1::text[]) AND price IS NOT NULL", [ids]);
      expect(priced, "one money row per message, not per segment").toBe(1);
      expect(row.reassembled_parts?.length ?? 0).toBe(3);
      tcx.note(`row ${row.gateway_msg_id.slice(0, 8)} part_no=${row.part_no} price=${row.price} reassembled_parts=${row.reassembled_parts?.length}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-02.04.01-P03", "Three submits at the vendor, one receipt to the customer", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const edge = edgeA();
    await edge.baseline();
    const esme = await bindA();
    try {
      const acks = await sendParts(esme, ucs2Segments(LONG, 3));
      const ids = acks.map((a) => a.messageId!);
      await expect.poll(async () => (await edge.stats()).pdus, { timeout: 30_000 }).toBe(3);
      await db.waitForRow("SELECT 1 FROM cdr_final WHERE gateway_msg_id = ANY($1)", [ids], { timeoutMs: 30_000 });
      await new Promise((r) => setTimeout(r, 3000));
      const receipts = esme.receipts.filter((x) => ids.some((id) => x.text.includes(id) || x.receiptedMessageId === id));
      expect(receipts.length, "conf.dlr.multipart default: one receipt for the message").toBe(1);
      tcx.note(`EdgeSmsc pdus=3; ESME received ${receipts.length} deliver_sm`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-02.04.01-P04", "dlr.multipart=all yields one receipt per segment", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const restore = await setWorkerProperty(db, LISTENER, "conf.dlr.multipart", "all");
    const edge = edgeA();
    await edge.baseline();
    const esme = await bindA();
    try {
      const acks = await sendParts(esme, ucs2Segments(LONG, 3));
      const ids = acks.map((a) => a.messageId!);
      await expect.poll(() => esme.receipts.filter((x) => ids.some((id) => x.text.includes(id) || x.receiptedMessageId === id)).length, { timeout: 40_000 }).toBe(3);
      tcx.note("three receipts, one per segment id");
    } finally {
      await esme.unbind();
      await restore();
    }
  });

  test(...tc("TC-02.04.01-N01", "Missing segment times out and refunds", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const restore = await setWorkerProperty(db, LISTENER, "reassembling.timeoutMillis", "4000");
    const edge = edgeA();
    await edge.baseline();
    const esme = await bindA();
    try {
      const before = await balanceOf(db, A);
      const since = new Date();
      const parts = ucs2Segments(LONG, 3);
      const acks = await sendParts(esme, [parts[0], parts[2]]);
      expect(acks.map((a) => a.status)).toEqual([0, 0]);
      // the money is reserved/charged while the message is being assembled…
      await new Promise((r) => setTimeout(r, 800));
      const during = await balanceOf(db, A);
      // …and returned once the timeout gives up on the missing segment
      await expect.poll(async () => (await balanceOf(db, A)).total, { timeout: 30_000 }).toBe(before.total);
      await new Promise((r) => setTimeout(r, 1500));
      expect((await edge.stats()).pdus, "nothing reached the vendor").toBe(0);
      const rej = await rejectedFor(db, { since, systemId: BASELINE.logins.a.systemId });
      tcx.note(`balance ${before.total} → during ${during.total} → after ${(await balanceOf(db, A)).total}; vendor pdus 0; cdr_rejected ${rej.map((r) => r.reason).join(",") || "none"}`);
    } finally {
      await esme.unbind();
      await restore();
    }
  });

  test(...tc("TC-02.04.01-N02", "Segments from two different senders never merge", { requires: ["gateway", "edgesmsc"] }), async ({ db, seed, tcx }) => {
    const restore = await setWorkerProperty(db, LISTENER, "reassembling.timeoutMillis", "4000");
    const edge = edgeA();
    await edge.baseline();
    const other = await seed.account({ label: "QA other sender" });
    await seed.balance({ accountId: other, balance: 1_000_000 });
    const otherLogin = await seed.credential({ accountId: other, product: BASELINE.product });
    const a = await bindA();
    const { connectEsme } = await import("../../fixtures/smpp");
    const { awaitGatewayAdopts } = await import("../../fixtures/gateway");
    await awaitGatewayAdopts(async () => (await import("../../fixtures/smpp")).bindAttempt(otherLogin).then((r) => r.status === 0));
    const b = await connectEsme(otherLogin);
    try {
      const ref = 77;
      const pa = ucs2Segments(LONG, 2, ref);
      const pb = ucs2Segments(LONG, 2, ref);
      // part 1 of 2 from each, same reference number — nothing must complete
      await sendParts(a, [pa[0]]);
      await sendParts(b, [pb[0]]);
      await new Promise((r) => setTimeout(r, 7000));
      expect((await edge.stats()).pdus, "no reassembly completed across senders").toBe(0);
      tcx.note("part 1/2 from two accounts with the same ref: vendor pdus 0 after the timeout");
    } finally {
      await a.unbind(); await b.unbind();
      await restore();
    }
  });

  test(...tc("TC-02.04.01-N03", "Mandatory TLV supplied on part 1 only still passes", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const restoreMandatory = await setWorkerProperty(db, LISTENER, "mandatory.tlvs.submit", "peid_0x1400");
    const restoreRegistered = await setWorkerProperty(db, LISTENER, "registered.tlvs.submit", "peid_0x1400");
    const peid = tlv("peid", 0x1400);
    const esme = await bindA();
    try {
      const parts = ucs2Segments(LONG, 2);
      const first = await esme.submit({ udh: parts[0].udh, text: parts[0].text, dcs: 8, tlvs: { [peid]: "PEID123" } });
      const second = await esme.submit({ udh: parts[1].udh, text: parts[1].text, dcs: 8 });
      expect([first.status, second.status], "the check runs on the reassembled message (0.10 regression)").toEqual([0, 0]);
      const row = await db.waitForRow<{ tlvs_received: string | null }>("SELECT tlvs_received FROM cdr_submit WHERE gateway_msg_id = ANY($1) OR reassembled_parts && $1::text[] LIMIT 1", [[first.messageId, second.messageId]], { timeoutMs: 30_000 });
      expect(row.tlvs_received ?? "").toMatch(/1400/i);
      tcx.note(`both parts 0x00; tlvs_received ${row.tlvs_received}`);
    } finally {
      await esme.unbind();
      await restoreRegistered(); await restoreMandatory();
    }
  });
});
