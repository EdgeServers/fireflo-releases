"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { TlvPairsEditor } from "@/components/TlvPairsEditor";
import { RegistrationScopeNotes } from "@/components/RegistrationScopeNotes";
import { formatTlvCsv, parseTlvCsv, tlvCsvProblem, type TlvPair } from "@/lib/tlv-string";
import type { TlvDefinition } from "@/lib/tlv-catalogue";
import {
  loginOptions, productOptions, validateHeader,
  type ApprovedHeader, type HeaderInput,
} from "@/lib/whitelist-types";

/**
 * The editor for one approved sender ID.
 *
 * <p>Two rows and then the stamps: <em>Sender ID · Approved</em>, <em>Product · Login</em>, TLVs
 * across the full width. The two scoping controls sit together because they are one decision —
 * which traffic this covers — and the stamps get the width because a 19-digit entity id in a
 * half-column is unreadable.
 */
export function HeaderForm({
  accountId,
  editing,
  products,
  logins,
  definitions,
  suggested,
  busy,
  onSave,
  onCancel,
}: {
  accountId: string;
  editing: ApprovedHeader | null;
  /** The catalogue plus orphans, from the one `useProducts` call the section makes. */
  products: string[];
  /** This account's enabled logins, so an approval can be scoped to one of them. */
  logins: string[];
  /** Operator-defined TLV names, from the section's one `useTlvDefinitions` call. */
  definitions: readonly TlvDefinition[];
  suggested: Record<number, boolean>;
  busy: boolean;
  onSave: (input: HeaderInput) => Promise<string | null>;
  onCancel: () => void;
}) {
  const [header, setHeader] = useState(editing?.header ?? "");
  const [pairs, setPairs] = useState<TlvPair[]>(() => parseTlvCsv(editing?.tlvs));
  const [product, setProduct] = useState(editing?.product ?? "");
  const [systemId, setSystemId] = useState(editing?.systemId ?? "");
  //a new row starts approved -- an operator adding one has decided. An existing row starts wherever
  //it is, so opening a customer's request shows it unticked and ticking it is the approval
  const [approved, setApproved] = useState(
    editing ? editing.status === "APPROVED" && editing.enabled : true
  );
  const [error, setError] = useState("");

  const tlvs = formatTlvCsv(pairs);
  const invalid = header.trim() ? validateHeader(header) : null;
  const tlvProblem = tlvCsvProblem(tlvs);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const refusal = validateHeader(header) ?? tlvCsvProblem(tlvs);
    if (refusal) {
      setError(refusal);
      return;
    }
    const failure = await onSave({
      id: editing?.id ?? null,
      accountId,
      product: product.trim(),
      systemId: systemId.trim() || null,
      header: header.trim(),
      tlvs,
      enabled: approved,
      approved,
    });
    setError(failure ?? "");
  }

  return (
    <form onSubmit={submit} className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <Label htmlFor="hdr-value" className="mb-1.5 block">Sender ID</Label>
          <Input id="hdr-value" value={header} onChange={(e) => setHeader(e.target.value)}
            className="font-mono" placeholder="ACMEIN" />
          <p className="mt-1 text-xs text-muted-foreground">
            Case-insensitive, so this also allows <code className="font-mono">acmein</code>.
          </p>
        </div>
        <div>
          <Label className="mb-1.5 block">Approved</Label>
          {/*this writes `status` and records the reviewer, not just `enabled`. It was called
             Approved once while writing only `enabled`, which meant ticking it on a request left
             the row PENDING and inert -- the label is back, so the write had to be made true*/}
          <label className="flex h-9 items-center gap-2 rounded-md border border-input bg-muted/40 px-3 text-sm">
            <input type="checkbox" checked={approved} onChange={(e) => setApproved(e.target.checked)}
              className="h-3.5 w-3.5 rounded border-input accent-primary" />
            <span>{approved ? "Approved and in service" : "Not approved"}</span>
          </label>
          <p className="mt-1 text-xs text-muted-foreground">
            Unticking withdraws it; it stays approved.
          </p>
        </div>

        <div>
          <Label htmlFor="hdr-product" className="mb-1.5 block">Product</Label>
          <Select id="hdr-product" value={product} onChange={(e) => setProduct(e.target.value)}>
            <option value="">Every product</option>
            {productOptions(products, product).map((p) => (
              <option key={p} value={p}>{p}</option>
            ))}
          </Select>
          <p className="mt-1 text-xs text-muted-foreground">
            Narrows it to one product&rsquo;s traffic.
          </p>
        </div>
        <div>
          <Label htmlFor="hdr-login" className="mb-1.5 block">Login</Label>
          <Select id="hdr-login" value={systemId} onChange={(e) => setSystemId(e.target.value)}>
            <option value="">Every login on the account</option>
            {loginOptions(logins, systemId).map((l) => (
              <option key={l} value={l}>{l}</option>
            ))}
          </Select>
          <p className="mt-1 text-xs text-muted-foreground">
            Which of this account&rsquo;s logins may send from it.
          </p>
        </div>
      </div>

      <div>
        <Label className="mb-1.5 block">
          TLVs to stamp <span className="font-normal text-muted-foreground">name_tag = value</span>
        </Label>
        <TlvPairsEditor
          pairs={pairs}
          onChange={setPairs}
          definitions={definitions}
          suggested={suggested}
          addLabel="Add a stamp"
          valuePlaceholder="1101234567890123456"
          disabled={busy}
        />
        <p className="mt-1 text-xs text-muted-foreground">
          Written onto every message from this sender ID, <strong>replacing</strong> what the customer
          sent for the same tag — so the value here is the approval. Needs{" "}
          <code className="font-mono">whitelist.tlvs.mode</code> set on the server the traffic arrives
          through.
        </p>
      </div>

      <RegistrationScopeNotes
        noun="sender ID"
        name={header.trim() || "this sender ID"}
        accountId={accountId}
        systemId={systemId.trim()}
        product={product.trim()}
        logins={logins}
      />

      {(invalid || tlvProblem || error) && (
        <p className="text-sm text-destructive">{invalid ?? tlvProblem ?? error}</p>
      )}

      <div className="flex gap-2">
        <Button type="submit" size="sm"
          disabled={busy || Boolean(invalid) || Boolean(tlvProblem) || !header.trim()}>
          {busy ? "Saving…" : "Save"}
        </Button>
        <Button type="button" size="sm" variant="ghost" onClick={onCancel}>Cancel</Button>
      </div>
    </form>
  );
}
