"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import type { Headline, RuntimeSnapshot } from "@/lib/runtime-metrics";

const REFRESH_MS = 10_000;

/** ~5 minutes at the poll interval — enough for a sparkline, small enough to forget about. */
const HISTORY = 30;

export interface HistoryPoint {
  at: number;
  heapUsed: number;
  processCpu: number | null;
  threadsLive: number | null;
  /** requests per second since the previous sample, null on the first one */
  httpRate: number | null;
  workerQueued: number | null;
}

/**
 * The gateway's runtime metrics, polled.
 *
 * <p>Modelled on {@link useHealth} rather than `useControlData`: a fixed endpoint with no range, a
 * short interval, a pause while the tab is hidden, and — importantly — **the last snapshot is kept
 * when a poll fails**. Blanking the page on one failed request would make a working gateway look
 * like it had disappeared.
 *
 * <p>It also keeps a small rolling history, which is the only way to draw a trend or turn a
 * cumulative counter into a rate: the exposition format carries totals, not rates. That history
 * starts when the page opens and is gone when it closes, so anything drawn from it must say so.
 */
export function useRuntimeMetrics() {
  const [snapshot, setSnapshot] = useState<RuntimeSnapshot | null>(null);
  const [history, setHistory] = useState<HistoryPoint[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const previous = useRef<{ at: number; requests: number } | null>(null);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/control/metrics", { cache: "no-store" });
      const json = await res.json();
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      const next = json.data as RuntimeSnapshot;
      setSnapshot(next);
      setError("");
      setHistory((old) => append(old, next.headline, previous));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not reach the gateway");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    let alive = true;
    const run = () => {
      if (alive) void load();
    };
    run();
    let timer: ReturnType<typeof setInterval> | null = setInterval(run, REFRESH_MS);
    const onVisibility = () => {
      if (document.hidden) {
        if (timer) clearInterval(timer);
        timer = null;
      } else if (!timer) {
        run();
        timer = setInterval(run, REFRESH_MS);
      }
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      alive = false;
      if (timer) clearInterval(timer);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [load]);

  return { snapshot, history, error, loading, reload: load };
}

function append(
  old: HistoryPoint[],
  headline: Headline,
  previous: React.RefObject<{ at: number; requests: number } | null>
): HistoryPoint[] {
  const at = Date.now();
  const last = previous.current;
  //null on the first sample, and after a restart: the counter resets, and a negative delta is not a
  //quantity of traffic. Dropping the window is better than drawing a spike that never happened
  let httpRate: number | null = null;
  if (last && headline.httpRequests >= last.requests && at > last.at) {
    httpRate = ((headline.httpRequests - last.requests) * 1000) / (at - last.at);
  }
  previous.current = { at, requests: headline.httpRequests };

  return [
    ...old,
    {
      at,
      heapUsed: headline.heapUsed,
      processCpu: headline.processCpu,
      threadsLive: headline.threadsLive,
      httpRate,
      workerQueued: headline.workerQueued,
    },
  ].slice(-HISTORY);
}
