"use client";
import { ratio } from "@/lib/format";

/**
 * A labelled fill bar for a value against a ceiling.
 *
 * <p>"30.6 MB of 3.8 GB" is two numbers a reader has to divide. The bar does the division, which is
 * the whole question being asked of heap, of open files, and of worker-pool saturation.
 *
 * <p>Colours by pressure rather than by category: a bar is only worth noticing when it is filling
 * up, so amber past 75% and red past 90%. Below that it stays in the group's own colour and does
 * not compete for attention.
 */
export function MetricBar({
  label,
  value,
  max,
  rendered,
  color = "var(--color-chart-1)",
}: {
  label: string;
  value: number;
  max: number;
  /** the pair as text, already formatted — this component never decides units */
  rendered: string;
  color?: string;
}) {
  const usable = max > 0 && Number.isFinite(max) && Number.isFinite(value);
  const fraction = usable ? Math.min(1, Math.max(0, value / max)) : 0;
  const fill =
    fraction >= 0.9
      ? "var(--color-destructive)"
      : fraction >= 0.75
        ? "hsl(38 92% 50%)"
        : color;

  return (
    <div className="space-y-1">
      <div className="flex items-baseline justify-between gap-3 text-sm">
        <span className="truncate text-muted-foreground">{label}</span>
        <span className="shrink-0 tabular-nums">
          {rendered}
          {usable && <span className="ml-1.5 text-muted-foreground">{ratio(fraction)}</span>}
        </span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
        {usable && (
          <div
            className="h-full rounded-full transition-[width] duration-500"
            style={{ width: `${fraction * 100}%`, backgroundColor: fill }}
          />
        )}
      </div>
    </div>
  );
}
