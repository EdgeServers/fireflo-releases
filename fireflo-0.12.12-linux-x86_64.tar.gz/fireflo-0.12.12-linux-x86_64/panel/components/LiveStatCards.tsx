"use client";
import { cn } from "@/lib/utils";
import { Sparkline } from "./Sparkline";
import type { StatTone } from "@/lib/worker-verdict";

/**
 * The live numbers as small tinted cards.
 *
 * <p><strong>The tint is a reading, not decoration.</strong> Most of these sit plain, because most
 * of them are counters and a counter has no opinion — "sent this session" is not good news or bad
 * news, it is a number. Colour is spent only where it changes what someone would do: no binds on a
 * vendor, sessions that cannot transmit, a queue that is being held, throughput stalled against a
 * backlog.
 *
 * <p>That restraint is what keeps the red meaningful. Four red cards beside a vendor that is merely
 * idle would train the eye to skip the one that means it has stopped carrying traffic.
 *
 * <p>Every tinted card carries a `note` saying why, so the colour is a signpost rather than a code
 * to memorise — and so the card still works for anyone who cannot separate red from green.
 */
export function LiveStatCards({
  stats,
}: {
  stats: readonly {
    label: string;
    value: string | number;
    tone: StatTone;
    note?: string;
    /**
     * Recent readings of this figure, oldest first, for a trend line under the number.
     *
     * <p>Only worth supplying for a rate. A count that only climbs draws the same line on every
     * card and teaches nothing; a throughput that was busy a minute ago and is zero now is the
     * one case where the number alone is actively misleading.
     */
    history?: readonly (number | null)[];
  }[];
}) {
  if (!stats.length) {
    return null;
  }
  return (
    <dl className="grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-4">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className={cn("rounded-lg border px-3 py-2", TONE_CLASSES[stat.tone])}
        >
          <dt className="text-xs text-muted-foreground">{stat.label}</dt>
          <dd className="text-xl font-semibold tabular-nums leading-tight">{stat.value}</dd>
          {/* `currentColor`, so the line takes the tile's tone rather than introducing a seventh
              colour: a stalled vendor's trend is drawn in the same red as the number above it */}
          {stat.history && stat.history.length > 1 && (
            <Sparkline values={[...stat.history]} color="currentColor" className="mt-1 h-4 w-full" />
          )}
          {stat.note && <p className="mt-0.5 text-xs opacity-80">{stat.note}</p>}
        </div>
      ))}
    </dl>
  );
}

/**
 * Tints matched to the badges rather than invented.
 *
 * <p>`good` is the same emerald as a `success` badge and `bad` the same destructive red, so a card
 * and the verdict beside it never disagree about what a colour means.
 */
const TONE_CLASSES: Record<StatTone, string> = {
  good: "border-emerald-500/20 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300",
  warn: "border-amber-500/25 bg-amber-500/10 text-amber-700 dark:text-amber-300",
  bad: "border-destructive/25 bg-destructive/10 text-destructive",
  plain: "border-border bg-muted/30",
};
