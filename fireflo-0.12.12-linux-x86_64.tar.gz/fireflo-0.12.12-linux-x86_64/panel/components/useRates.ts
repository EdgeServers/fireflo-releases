"use client";
import { useCallback, useEffect, useState } from "react";
import type { KnownScopes, RateRule, RateRuleInput, ScopeSummary } from "@/lib/rate-types";
import { surface } from "@/lib/panel-surface";

const EMPTY_KNOWN: KnownScopes = { vendors: [], accounts: [] };

/**
 * Loading and editing pricing.
 *
 * <p>Two levels, because the list and one scope's rules are different queries: `scopes` is the
 * summary every page needs, `rules` is loaded on demand for whichever scope is being edited.
 *
 * <p>Unlike `useWorkers` there is no immediate gateway push. There is no `/ops` verb that reloads
 * rates on demand, so a saved change lands on the gateway's next configuration poll — within
 * `smsg.config.db.poll.seconds`, thirty by default. The forms say so rather than implying it is
 * instant.
 */
export function useRates() {
  const [scopes, setScopes] = useState<ScopeSummary[]>([]);
  const [known, setKnown] = useState<KnownScopes>(EMPTY_KNOWN);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");

  const load = useCallback(async () => {
    //nothing at all on a surface that may not show pricing -- see lib/panel-surface.ts. The guard is
    //here rather than at the six call sites because a hook cannot be called conditionally, and
    //because "do not ask for prices" is one rule that should live in one place. Not a request that
    //404s: an empty answer is the correct one, and a failed request would leave `error` set and
    //paint a red card on a page that is working exactly as intended
    if (!surface().pricing) {
      setLoading(false);
      return;
    }
    try {
      const res = await fetch("/api/control/rates", { cache: "no-store" });
      const json = await res.json();
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        setScopes([]);
      } else {
        setScopes(json.data.scopes as ScopeSummary[]);
        setKnown(json.data.known as KnownScopes);
        setError("");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  /** One scope's rules, for the editor. Returns null and sets `error` when it cannot be read. */
  const loadScope = useCallback(async (scope: string): Promise<RateRule[] | null> => {
    try {
      const res = await fetch(`/api/control/rates/${encodeURIComponent(scope)}`, { cache: "no-store" });
      const json = await res.json();
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return null;
      }
      setError("");
      return json.data.rules as RateRule[];
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
      return null;
    }
  }, []);

  /**
   * Writes a whole scope.
   *
   * @param isNew whether this creates the scope. Only decides what an empty rule list means: on a
   *     new scope it writes nothing at all, so the server refuses it rather than answering 200 to a
   *     save that stored nothing — which is what "Add pricing does nothing" turned out to be
   * @returns the server's message when it refused, or null on success. Returned rather than only
   *     stored, because the form has to keep the operator's unsaved work on screen beside it.
   */
  const saveScope = useCallback(
    async (
      scope: string,
      rules: RateRuleInput[],
      scopeConfirmed: boolean,
      isNew = false
    ): Promise<string | null> => {
      setBusy(scope);
      try {
        const res = await fetch(`/api/control/rates/${encodeURIComponent(scope)}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ rules, scopeConfirmed, isNew }),
        });
        const json = await res.json().catch(() => null);
        if (!res.ok) {
          return json?.error ?? `Request failed (${res.status})`;
        }
        await load();
        return null;
      } catch (err) {
        return err instanceof Error ? err.message : "Request failed";
      } finally {
        setBusy("");
      }
    },
    [load]
  );

  const setRuleEnabled = useCallback(
    async (scope: string, id: number, enabled: boolean) => {
      setBusy(`${scope}:${id}`);
      try {
        const res = await fetch(
          `/api/control/rates/${encodeURIComponent(scope)}/rules/${id}`,
          {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ enabled }),
          }
        );
        if (!res.ok) {
          const json = await res.json().catch(() => null);
          setError(json?.error ?? `Request failed (${res.status})`);
          return false;
        }
        setError("");
        await load();
        return true;
      } finally {
        setBusy("");
      }
    },
    [load]
  );

  const removeScope = useCallback(
    async (scope: string) => {
      setBusy(scope);
      try {
        const res = await fetch(`/api/control/rates/${encodeURIComponent(scope)}`, { method: "DELETE" });
        if (!res.ok) {
          const json = await res.json().catch(() => null);
          setError(json?.error ?? `Request failed (${res.status})`);
          return false;
        }
        setError("");
        await load();
        return true;
      } finally {
        setBusy("");
      }
    },
    [load]
  );

  return {
    scopes, known, error, loading, busy,
    load, loadScope, saveScope, setRuleEnabled, removeScope, setError,
  };
}
