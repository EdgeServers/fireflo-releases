"use client";
import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Download, Plus, Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { PageHeader } from "@/components/ui/page-header";
import { Rail, RailCard, RailNote, railItemClass } from "@/components/ui/rail";
import { Select } from "@/components/ui/select";
import { HealthStrip } from "./CardBits";
import { GatewayIgnores } from "./GatewayIgnores";
import { PricingExportDialog, PricingImportDialog } from "./PricingTransfer";
import { useFilters } from "./useFilters";
import { useProductCatalogue } from "./useProducts";
import { useRates } from "./useRates";
import type { Filter } from "@/lib/filter-types";
import {
  DEFAULT_SCOPE,
  scopeKind,
  type KnownScopes,
  type ProductScopeSummary,
  type RateRule,
  type RateRuleInput,
  type ScopeSummary,
} from "@/lib/rate-types";
import { cn } from "@/lib/utils";
import { TesterButton } from "./TesterModal";

/**
 * Everything the Pricing section reads, loaded once in its layout.
 *
 * <p>The left column lists what can be priced -- the default, the accounts with pricing of their
 * own, every vendor -- and the right is the open one. Accounts that pay the default are not listed:
 * a deployment has hundreds, and a column of "Default" rows buried the ones that say something. The
 * find box reaches any of them.
 */
export interface PricingData {
  scopes: ScopeSummary[];
  known: KnownScopes;
  loading: boolean;
  error: string;
  busy: string;
  catalogue: string[];
  filters: Filter[];
  reload: () => Promise<void>;
  loadScope: (scope: string) => Promise<RateRule[] | null>;
  saveScope: (scope: string, rules: RateRuleInput[], confirmed: boolean, isNew?: boolean) => Promise<string | null>;
  removeScope: (scope: string) => Promise<boolean>;
  /**
   * The product the section is narrowed to (`?product=`), or null for all of them. The products
   * list's "Pricing" opens this section narrowed, in place of a page of its own.
   */
  product: string | null;
  /** Each scope's prices for `product`, its everything-else prices included. Null when not narrowed or loading. */
  productScopes: ProductScopeSummary[] | null;
}

const Ctx = createContext<PricingData | null>(null);

export function usePricingData(): PricingData {
  const value = useContext(Ctx);
  if (!value) {
    throw new Error("usePricingData is used outside the Pricing layout.");
  }
  return value;
}

/**
 * One scope's page. `?new=1` opens a new price on arrival; `&product=` narrows the page to that
 * product and fills it into a new price.
 */
export function scopeHref(scope: string, opts: { new?: boolean; product?: string | null } = {}): string {
  const q = new URLSearchParams();
  if (opts.new) q.set("new", "1");
  if (opts.product) q.set("product", opts.product);
  const tail = q.size ? `?${q}` : "";
  return `/cp/pricing/scope/${encodeURIComponent(scope)}${tail}`;
}

export function scopeTitle(scope: string): string {
  return scope === DEFAULT_SCOPE ? "Everyone" : scope;
}

export function PricingShell({ children }: { children: ReactNode }) {
  const rates = useRates();
  const catalogue = useProductCatalogue();
  const { filters } = useFilters();
  const [dialog, setDialog] = useState<"add" | "export" | "import" | null>(null);
  const pathname = usePathname();
  const router = useRouter();
  const product = useSearchParams().get("product") || null;
  const productScopes = useProductScopes(product);
  const openScope = pathname.startsWith("/cp/pricing/scope/")
    ? decodeURIComponent(pathname.slice("/cp/pricing/scope/".length))
    : null;

  const data: PricingData = {
    scopes: rates.scopes,
    known: rates.known,
    loading: rates.loading,
    error: rates.error,
    busy: rates.busy,
    catalogue,
    filters,
    reload: async () => {
      await Promise.all([rates.load(), productScopes.reload()]);
    },
    loadScope: rates.loadScope,
    //a save or a delete changes the per-product counts as well as the scope list
    saveScope: async (...args) => {
      const failure = await rates.saveScope(...args);
      if (!failure) void productScopes.reload();
      return failure;
    },
    removeScope: async (scope) => {
      const ok = await rates.removeScope(scope);
      if (ok) void productScopes.reload();
      return ok;
    },
    product,
    productScopes: productScopes.scopes,
  };

  return (
    <Ctx.Provider value={data}>
      <PageHeader
        title="Pricing"
        description="What vendors charge us and what accounts pay. Within a scope and a product, the first matching price wins."
        actions={
          <>
            <TesterButton tab="pricing" />
            <Button variant="outline" className="gap-2" onClick={() => setDialog("export")}>
              <Download className="h-4 w-4" aria-hidden="true" /> Export
            </Button>
            <Button variant="outline" className="gap-2" onClick={() => setDialog("import")}>
              <Upload className="h-4 w-4" aria-hidden="true" /> Import
            </Button>
            <Button className="gap-2" onClick={() => setDialog("add")}>
              <Plus className="h-4 w-4" aria-hidden="true" /> Add pricing
            </Button>
          </>
        }
      />
      {/* nothing below matters if the gateway is not reading any of it */}
      <GatewayIgnores domain="rates" />
      {rates.error && <HealthStrip tone="destructive">{rates.error}</HealthStrip>}
      <div className="flex flex-wrap items-start gap-6">
        <PricingNav data={data} active={openScope} />
        <div className="flex min-w-0 flex-[999_1_560px] flex-col gap-5">
          {product && (
            <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
              <span className="inline-flex items-center gap-2 rounded-full bg-primary-soft py-1 pl-3 pr-1 text-sm font-semibold text-primary">
                Product <span className="font-mono">{product}</span>
                <button type="button" aria-label="Show every product" title="Show every product"
                  onClick={() => router.push(pathname)}
                  className="grid h-5 w-5 place-items-center rounded-full bg-card text-muted-foreground hover:text-foreground">
                  <X className="h-3 w-3" aria-hidden="true" />
                </button>
              </span>
              <span className="text-sm text-muted-foreground">Counts, chips and cards cover {product} only.</span>
              <Link href={`/cp/cdrs?product=${encodeURIComponent(product)}`} className="ml-auto text-sm text-primary hover:underline">
                Messages sent under {product} →
              </Link>
            </div>
          )}
          {children}
        </div>
      </div>
      {dialog === "add" && <AddPricingDialog known={rates.known} onClose={() => setDialog(null)} />}
      {dialog === "export" && <PricingExportDialog scope={openScope} scopes={rates.scopes} onClose={() => setDialog(null)} />}
      {dialog === "import" && (
        <PricingImportDialog
          onClose={() => setDialog(null)}
          onApplied={async () => {
            await rates.load();
          }}
        />
      )}
    </Ctx.Provider>
  );
}

/**
 * One product's per-scope counts, for the narrowed rail and overview. One request, counts only --
 * the same summary the product page used, so it holds at thousands of accounts.
 */
function useProductScopes(product: string | null) {
  const [scopes, setScopes] = useState<ProductScopeSummary[] | null>(null);
  const reload = useCallback(async () => {
    if (!product) {
      setScopes(null);
      return;
    }
    try {
      const res = await fetch(`/api/control/products/${encodeURIComponent(product)}/pricing`, { cache: "no-store" });
      const json = await res.json();
      setScopes(res.ok ? (json.data.scopes as ProductScopeSummary[]) : []);
    } catch {
      setScopes([]);
    }
  }, [product]);
  useEffect(() => {
    //eslint-disable-next-line react-hooks/set-state-in-effect -- loading the narrowed product's counts
    setScopes(null);
    void reload();
  }, [reload]);
  return { scopes, reload };
}

function PricingNav({ data, active }: { data: PricingData; active: string | null }) {
  const router = useRouter();
  const pathname = usePathname();
  const { product } = data;
  //the address with the product swapped: the open page stays open, narrowed or not
  const narrowTo = (next: string) => router.push(next ? `${pathname}?product=${encodeURIComponent(next)}` : pathname);
  const [find, setFind] = useState("");
  const q = find.trim().toLowerCase();
  const byScope = new Map(data.scopes.map((s) => [s.scope, s]));
  const byProduct = new Map((data.productScopes ?? []).map((s) => [s.scope, s]));
  const kind = (s: string) => scopeKind(s, data.known);

  //narrowed, an account "has its own" price only for that product -- everything-else prices count
  const pricedAccounts = product
    ? (data.productScopes ?? []).filter((s) => kind(s.scope) === "price").map((s) => s.scope)
    : data.scopes.filter((s) => kind(s.scope) === "price").map((s) => s.scope);
  //searching reaches every account the panel knows, priced or not
  const accounts = q ? data.known.accounts.filter((a) => a.toLowerCase().includes(q)) : pricedAccounts;
  const unpriced = data.known.accounts.length - pricedAccounts.length;
  const vendors = data.known.vendors.filter((v) => !q || v.toLowerCase().includes(q));
  const unknown = data.scopes.filter((s) => kind(s.scope) === "unknown").map((s) => s.scope)
    .filter((s) => !q || s.toLowerCase().includes(q));
  const shownAccounts = accounts.slice(0, 50);

  const count = (s: string) => (product ? byProduct.get(s)?.rules : byScope.get(s)?.rules) ?? 0;
  const rulesChip = (s: string) => {
    const n = count(s);
    //narrowed, a scope reached only by a price for every product says so rather than "1 rule"
    if (product && byProduct.get(s)?.specificToProduct === false) return <Chip>Any product</Chip>;
    return <Chip tone="ok">{n} {n === 1 ? "rule" : "rules"}</Chip>;
  };
  const counting = data.loading || (!!product && data.productScopes === null);
  const overviewHref = product ? `/cp/pricing?product=${encodeURIComponent(product)}` : "/cp/pricing";

  const row = (scope: string, chip: ReactNode, sub?: string) => (
    <Link
      key={scope}
      href={scopeHref(scope, { product })}
      aria-current={active === scope ? "page" : undefined}
      className={railItemClass(active === scope)}
    >
      <span className="flex min-w-0 flex-col">
        <span className={cn("truncate", scope !== DEFAULT_SCOPE && "font-mono")}>{scopeTitle(scope)}</span>
        {sub && <span className="text-xs font-normal text-muted-foreground">{sub}</span>}
      </span>
      <span className="ml-auto shrink-0">{chip}</span>
    </Link>
  );

  return (
    <>
      {/* a select on a phone; accounts that pay the default are reached through Add pricing there */}
      <div className="flex w-full flex-wrap gap-3 lg:hidden">
      <label className="flex min-w-40 flex-1 flex-col gap-1 text-xs text-muted-foreground">
        Product
        <Select
          aria-label="Product"
          value={product ?? ""}
          onChange={(e) => narrowTo(e.target.value)}
        >
          <option value="">All products</option>
          {data.catalogue.map((p) => <option key={p} value={p}>{p}</option>)}
          {product && !data.catalogue.includes(product) && <option value={product}>{product}</option>}
        </Select>
      </label>
      <label className="flex min-w-40 flex-[2] flex-col gap-1 text-xs text-muted-foreground">
        Show
        <Select
          aria-label="Pricing to show"
          value={active === null ? "" : active}
          onChange={(e) => router.push(e.target.value === "" ? overviewHref : scopeHref(e.target.value, { product }))}
        >
          <option value="">Overview</option>
          <option value={DEFAULT_SCOPE}>Everyone · the default</option>
          <optgroup label="Accounts with their own pricing">
            {pricedAccounts.map((a) => <option key={a} value={a}>{a} · {count(a)} rules</option>)}
            {active !== null && kind(active) === "price" && !pricedAccounts.includes(active) && (
              <option value={active}>{active} · pays the default</option>
            )}
          </optgroup>
          <optgroup label="Vendors">
            {data.known.vendors.map((v) => <option key={v} value={v}>{v} · {count(v) ? `${count(v)} rules` : "no cost"}</option>)}
          </optgroup>
          {unknown.length > 0 && (
            <optgroup label="Matches nothing">
              {unknown.map((u) => <option key={u} value={u}>{u}</option>)}
            </optgroup>
          )}
        </Select>
      </label>
      </div>

      {/* where to start, then accounts and vendors each in their own card. The search sits between,
          outside both, because it filters both */}
      <Rail label="Pricing">
        <RailCard>
          <label className="flex flex-col gap-1 px-1.5 pb-1 pt-0.5 text-xs text-muted-foreground">
            Product
            <Select
          aria-label="Product"
          value={product ?? ""}
          onChange={(e) => narrowTo(e.target.value)}
        >
          <option value="">All products</option>
          {data.catalogue.map((p) => <option key={p} value={p}>{p}</option>)}
          {product && !data.catalogue.includes(product) && <option value={product}>{product}</option>}
        </Select>
          </label>
        </RailCard>

        <RailCard>
          <Link href={overviewHref} aria-current={active === null ? "page" : undefined} className={railItemClass(active === null)}>
            Overview
          </Link>
          {row(DEFAULT_SCOPE, count(DEFAULT_SCOPE) ? rulesChip(DEFAULT_SCOPE) : <Chip tone="warn">Not set</Chip>, "every account without its own")}
        </RailCard>

        <Input
          aria-label="Find an account or vendor"
          placeholder="Find an account or vendor"
          value={find}
          onChange={(e) => setFind(e.target.value)}
        />

        <RailCard title="Accounts" what={product ? `what they pay for ${product}` : "what they pay us"} count={counting ? null : accounts.length}>
          {counting && <RailNote>Loading…</RailNote>}
          {shownAccounts.map((a) => row(a, count(a) ? rulesChip(a) : <Chip>Default</Chip>))}
          {accounts.length > shownAccounts.length && <RailNote>{accounts.length - shownAccounts.length} more. Narrow the search.</RailNote>}
          {!counting && !accounts.length && (
            <RailNote>{q ? "No account matches." : product ? `No account has its own price for ${product}.` : "No account has pricing of its own yet."}</RailNote>
          )}
          {!q && !counting && unpriced > 0 && (
            <RailNote>
              {unpriced} more {unpriced === 1 ? "account pays" : "accounts pay"} the default{product ? ` for ${product}` : ""}. Search to find one.
            </RailNote>
          )}
        </RailCard>

        <RailCard title="Vendors" what={product ? `what ${product} costs us` : "what they charge us"} count={data.loading ? null : vendors.length}>
          {vendors.map((v) => row(v, count(v) ? rulesChip(v) : <Chip tone="bad">No cost</Chip>))}
          {!data.loading && !vendors.length && <RailNote>{q ? "No vendor matches." : "No vendors configured."}</RailNote>}
        </RailCard>

        {unknown.length > 0 && (
          <RailCard title="Matches nothing" what="pricing for a name not in use" count={unknown.length}>
            {unknown.map((u) => row(u, <Chip tone="bad">Unknown</Chip>))}
          </RailCard>
        )}
      </Rail>
    </>
  );
}

function Chip({ tone = "muted", children }: { tone?: "ok" | "warn" | "bad" | "muted"; children: ReactNode }) {
  return (
    <span className={cn(
      "rounded-full px-2 py-px text-2xs font-medium",
      tone === "ok" && "bg-primary-soft text-primary",
      tone === "warn" && "bg-warning-soft text-warning",
      tone === "bad" && "bg-destructive-soft text-destructive",
      tone === "muted" && "border border-border text-muted-foreground"
    )}>
      {children}
    </span>
  );
}

/**
 * Who to price: an account, a vendor, or everyone. Only names the panel knows are offered; the scope
 * used to be free text, and a typo there made pricing that loads and matches nothing.
 */
function AddPricingDialog({ known, onClose }: { known: KnownScopes; onClose: () => void }) {
  const router = useRouter();
  const [kind, setKind] = useState<"account" | "vendor" | "default">("account");
  const list = kind === "account" ? known.accounts : known.vendors;
  const [who, setWho] = useState("");
  const chosen = kind === "default" ? DEFAULT_SCOPE : who || list[0] || "";

  const options = [
    { id: "account" as const, title: "An account", hint: "What a customer pays us" },
    { id: "vendor" as const, title: "A vendor", hint: "What a carrier charges us" },
    { id: "default" as const, title: "Everyone", hint: "Every account without its own" },
  ];

  return (
    <Dialog open onClose={onClose} title="Add pricing">
      <div className="space-y-4">
        <div className="grid gap-2 sm:grid-cols-3">
          {options.map((o) => (
            <button key={o.id} type="button" aria-pressed={kind === o.id}
              onClick={() => { setKind(o.id); setWho(""); }}
              className={cn(
                "rounded-lg border p-3 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                kind === o.id ? "border-primary bg-primary-soft/50 ring-1 ring-primary" : "border-border hover:border-muted-foreground/40"
              )}>
              <span className="block font-semibold">{o.title}</span>
              <span className="block text-sm text-muted-foreground">{o.hint}</span>
            </button>
          ))}
        </div>
        {kind !== "default" && (
          list.length ? (
            <label className="block space-y-1.5 text-xs font-semibold">
              {kind === "account" ? "Account" : "Vendor"}
              <Select value={chosen} onChange={(e) => setWho(e.target.value)}>
                {list.map((x) => <option key={x} value={x}>{x}</option>)}
              </Select>
            </label>
          ) : (
            <p className="text-sm text-muted-foreground">
              {kind === "account" ? "No accounts yet. Add one on the Accounts page first." : "No vendors yet. Add one on the Vendors page first."}
            </p>
          )
        )}
        <div className="flex flex-wrap justify-end gap-2 border-t border-border pt-4">
          <Button type="button" variant="ghost" className="mr-auto" onClick={onClose}>Cancel</Button>
          <Button type="button" disabled={!chosen} onClick={() => { onClose(); router.push(scopeHref(chosen, { new: true })); }}>
            Continue
          </Button>
        </div>
      </div>
    </Dialog>
  );
}
