"use client";
import { HealthLink } from "./HealthLink";
import { ThemeToggle } from "./ThemeToggle";

/**
 * The bar above every operator page: gateway health and the theme switch, nothing else.
 *
 * <p>It used to carry the page's title and a subtitle, which every page then repeated a few pixels
 * lower in its own heading -- the same name twice, and two different sentences describing it. The
 * page heading is the one that stays: it sits with the page's content and its actions.
 */
export function DesktopHeader() {
  return (
    <header className="hidden h-[52px] shrink-0 items-center gap-3 border-b bg-card px-5 md:flex">
      <div className="ml-auto flex items-center gap-1">
        <HealthLink />
        <ThemeToggle />
      </div>
    </header>
  );
}
