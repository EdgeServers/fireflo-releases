"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { HeartPulse } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Live health, as an icon in the header rather than a row in the sidebar.
 *
 * <p>It is the one page you want from wherever you already are — "is the gateway up" is a question
 * that interrupts whatever you were doing — so it belongs with the always-visible controls rather
 * than in a list you have to read. The sidebar is for places you navigate to on purpose.
 *
 * <p>Rendered in both headers, because the sidebar is a drawer below `lg` and dropping the link from
 * it would otherwise put live health two taps away on a phone instead of nought.
 *
 * <p>Styled to match {@link ThemeToggle} — same ghost icon button, same size — since they now sit
 * next to each other and a mismatch would read as one of them being a different kind of thing.
 */
export function HealthLink() {
  const pathname = usePathname();
  const active = pathname.startsWith("/cp/health");

  return (
    <Link
      href="/cp/health"
      aria-label="Live health"
      aria-current={active ? "page" : undefined}
      title="Live health"
      className={cn(
        //44px on a touch screen, back to 36 on a pointer -- the same rule the ui primitives use
        "inline-flex h-11 w-11 items-center justify-center rounded-md transition-colors md:h-9 md:w-9",
        "hover:bg-accent hover:text-accent-foreground",
        active ? "bg-accent text-foreground" : "text-muted-foreground"
      )}
    >
      <HeartPulse className="h-4 w-4" />
    </Link>
  );
}
