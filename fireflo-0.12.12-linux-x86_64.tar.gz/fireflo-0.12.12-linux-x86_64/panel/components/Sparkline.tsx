"use client";

/**
 * A trend line small enough to sit inside a tile.
 *
 * <p>Hand-rolled SVG rather than recharts. Six of these poll every ten seconds, and a full chart
 * runtime per tile — with its own ResponsiveContainer and observers — costs far more than a
 * `<polyline>` for a picture with no axes, no legend and no tooltip.
 *
 * <p>Scaled to its own minimum and maximum, so it shows *shape* and never magnitude. That is the
 * right trade for a tile whose number is printed right above it, but it does mean a flat-looking
 * line is flat only relative to itself.
 */
export function Sparkline({
  values,
  color = "var(--color-primary)",
  className = "h-8 w-full",
}: {
  values: (number | null)[];
  color?: string;
  className?: string;
}) {
  const points = values.filter((v): v is number => v != null && Number.isFinite(v));
  //two points is the minimum that can describe a direction; one is just a dot claiming a trend
  if (points.length < 2) {
    return <div className={className} aria-hidden />;
  }

  const min = Math.min(...points);
  const max = Math.max(...points);
  //a flat series would otherwise divide by zero and collapse to the top edge
  const span = max - min || 1;
  const step = 100 / (points.length - 1);

  const path = points
    .map((v, i) => `${(i * step).toFixed(2)},${(100 - ((v - min) / span) * 100).toFixed(2)}`)
    .join(" ");

  return (
    <svg
      className={className}
      viewBox="0 0 100 100"
      preserveAspectRatio="none"
      role="img"
      aria-label="Recent trend"
    >
      <polyline
        points={path}
        fill="none"
        stroke={color}
        strokeWidth="2.5"
        strokeLinejoin="round"
        strokeLinecap="round"
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  );
}
