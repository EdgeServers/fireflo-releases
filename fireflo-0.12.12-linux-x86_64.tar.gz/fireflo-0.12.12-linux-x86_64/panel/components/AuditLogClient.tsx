"use client";
import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { TBody, TD, TH, THead, TR, Table, TableEmpty } from "@/components/ui/table";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import type { CustomerAuditRow, OperatorAuditRow } from "@/lib/audit-log";

type Row = OperatorAuditRow | CustomerAuditRow;

const OPERATOR_EVENTS = [
  "signin", "signin_failed", "signout", "download", "export_deleted", "capture_started",
  "gateway_setting_set", "gateway_setting_cleared", "routing_recreated", "ip_unbanned",
  "user_created", "user_updated", "user_password_set", "password_changed",
  "link_requested", "link_denied", "link_redeemed", "link_rejected", "connection_instructions_sent",
  "preprocessor_code_saved", "preprocessor_code_restored",
];
const CUSTOMER_EVENTS = [
  "link_requested", "link_denied", "link_redeemed", "link_rejected", "password_signin",
  "password_signin_failed", "password_set", "portal_access", "cross_account_access", "playground_call",
  "credential_rotated", "child_created", "child_updated", "child_suspended", "child_resumed",
  "child_login_created", "child_login_toggled", "child_credit_changed", "child_user_created", "child_user_toggled",
];
const FAILURES = new Set(["signin_failed", "link_denied", "link_rejected", "password_signin_failed"]);

/**
 * One of the two access logs, as a table with the filters that answer the usual questions.
 *
 * <p>"Who was refused last night", "what did this operator do on Tuesday", "who has been signing in
 * to this account". The operator log is admin-only through its route; the customer log is any
 * operator's. Pages are cursor-paged, so "Load more" is one indexed read however old the log is.
 */
export function AuditLogClient({
  surface = "operator",
  userId = null,
  accountId = null,
  onClearUser,
}: {
  surface?: "operator" | "portal";
  userId?: number | null;
  accountId?: string | null;
  onClearUser?: () => void;
}) {
  const [rows, setRows] = useState<Row[]>([]);
  const [next, setNext] = useState<{ occurredAt: string; id: number } | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [event, setEvent] = useState("");
  const [actor, setActor] = useState("");
  const [failures, setFailures] = useState(false);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const query = useCallback(
    (before: { occurredAt: string; id: number } | null) => {
      const p = new URLSearchParams();
      if (userId) p.set("user", String(userId));
      if (accountId) p.set("account", accountId);
      if (event) p.set("event", event);
      if (actor) p.set("actor", actor);
      if (failures) p.set("failures", "1");
      if (from) p.set("from", new Date(from).toISOString());
      if (to) p.set("to", new Date(new Date(to).getTime() + 86_400_000).toISOString());
      if (before) p.set("before", `${before.occurredAt},${before.id}`);
      p.set("limit", "100");
      return `/api/control/audit/${surface}?${p.toString()}`;
    },
    [surface, userId, accountId, event, actor, failures, from, to]
  );

  const load = useCallback(
    async (before: { occurredAt: string; id: number } | null) => {
      setLoading(true);
      try {
        const res = await fetch(query(before), { cache: "no-store" });
        const json = await res.json().catch(() => null);
        if (!res.ok) {
          setError(json?.error ?? `Request failed (${res.status})`);
          return;
        }
        setError("");
        setRows((prev) => (before ? [...prev, ...json.data.rows] : json.data.rows));
        setNext(json.data.next);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Request failed");
      } finally {
        setLoading(false);
      }
    },
    [query]
  );

  useEffect(() => {
    void load(null);
  }, [load]);

  const events = surface === "operator" ? OPERATOR_EVENTS : CUSTOMER_EVENTS;

  return (
    <div className="space-y-3">
      <Card>
        <CardContent className="grid gap-3 py-4 sm:grid-cols-2 lg:grid-cols-5">
          <Field label="Event" htmlFor="audit-event">
            <Select id="audit-event" value={event} onChange={(e) => setEvent(e.target.value)}>
              <option value="">Any</option>
              {events.map((e) => (
                <option key={e} value={e}>
                  {e}
                </option>
              ))}
            </Select>
          </Field>
          <Field label={surface === "operator" ? "Actor" : "Email"} htmlFor="audit-actor">
            <Input id="audit-actor" value={actor} placeholder="contains…" onChange={(e) => setActor(e.target.value)} />
          </Field>
          <Field label="From" htmlFor="audit-from">
            <Input id="audit-from" type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </Field>
          <Field label="To" htmlFor="audit-to">
            <Input id="audit-to" type="date" value={to} onChange={(e) => setTo(e.target.value)} />
          </Field>
          <div className="flex flex-col justify-end gap-2">
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={failures}
                onChange={(e) => setFailures(e.target.checked)}
                className="h-4 w-4 rounded border-input accent-primary"
              />
              Failures only
            </label>
            {userId && onClearUser && (
              <Button variant="outline" size="sm" onClick={onClearUser}>
                Show everyone
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {error && (
        <Card>
          <CardContent className="py-4 text-sm text-destructive">{error}</CardContent>
        </Card>
      )}

      <Table>
        <THead>
          <tr>
            <TH>When</TH>
            <TH>Event</TH>
            <TH>{surface === "operator" ? "Actor" : "Who"}</TH>
            <TH>From</TH>
            <TH>Detail</TH>
          </tr>
        </THead>
        <TBody>
          {rows.map((r) => (
            <TR key={r.id}>
              <TD className="whitespace-nowrap tabular-nums">{new Date(r.occurredAt).toLocaleString()}</TD>
              <TD>
                <span className={FAILURES.has(r.event) ? "font-semibold text-destructive" : "font-medium"}>{r.event}</span>
              </TD>
              <TD primary>
                {"actor" in r ? r.actor ?? "—" : [r.email, r.accountId].filter(Boolean).join(" · ") || "—"}
              </TD>
              <TD muted>
                <span className="tabular-nums text-foreground">{r.ip ?? "—"}</span>
                {r.userAgent && (
                  <span className="block max-w-[14rem] truncate text-xs" title={r.userAgent}>
                    {r.userAgent}
                  </span>
                )}
              </TD>
              <TD muted>{r.detail ? describe(r.detail) : ""}</TD>
            </TR>
          ))}
          {!rows.length && (
            <TableEmpty colSpan={5}>{loading ? "Reading…" : "Nothing recorded for these filters."}</TableEmpty>
          )}
        </TBody>
      </Table>

      {next && (
        <div className="flex justify-center">
          <Button variant="outline" disabled={loading} onClick={() => void load(next)}>
            {loading ? "Reading…" : "Load more"}
          </Button>
        </div>
      )}
    </div>
  );
}

function describe(detail: Record<string, unknown>): string {
  return Object.entries(detail)
    .map(([k, v]) => `${k}: ${typeof v === "object" ? JSON.stringify(v) : String(v)}`)
    .join(" · ");
}
