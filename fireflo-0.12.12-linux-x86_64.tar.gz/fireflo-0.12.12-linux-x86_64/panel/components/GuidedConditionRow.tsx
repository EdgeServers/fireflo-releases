"use client";
import { useEffect, useState } from "react";
import { Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Segmented } from "@/components/ui/segmented";
import { Select } from "@/components/ui/select";
import { GUIDED_KINDS, type GuidedField, type MatchMode } from "@/lib/filter-guide";

/**
 * One guided condition: how to compare, the value, and "except". Shared by the filter wizard and the
 * routing rule editor, so a destination prefix is entered the same way in both.
 */

export interface GuidedOptions {
  products: { value: string; label: string }[];
  logins: { value: string; label: string }[];
  accounts: { value: string; label: string }[];
}

/**
 * The catalogue lists the value controls choose from. A failed fetch leaves its list empty, and that
 * control falls back to a text box.
 */
export function useGuidedOptions(): GuidedOptions {
  const [options, setOptions] = useState<GuidedOptions>({ products: [], logins: [], accounts: [] });
  useEffect(() => {
    let live = true;
    const get = (url: string) => fetch(url, { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).catch(() => null);
    void Promise.all([
      get("/api/control/products"),
      get("/api/control/credentials"),
      get("/api/control/accounts/catalogue"),
    ]).then(([p, c, a]) => {
      if (!live) return;
      setOptions({
        products: ((p?.data?.products ?? []) as { name: string; label: string | null }[])
          .map((x) => ({ value: x.name, label: x.label ? `${x.name} — ${x.label}` : x.name })),
        logins: ((c?.data?.credentials ?? []) as { systemId: string | null; type: string }[])
          .filter((x) => x.systemId)
          .map((x) => ({ value: x.systemId!, label: `${x.systemId} (${x.type})` })),
        accounts: ((a?.data?.accounts ?? []) as { id: string; label: string | null }[])
          .map((x) => ({ value: x.id, label: x.label ? `${x.id} — ${x.label}` : x.id })),
      });
    });
    return () => {
      live = false;
    };
  }, []);
  return options;
}

/** One guided field's controls: how to compare, the value, and "except". */
export function GuidedConditionRow({
  field,
  options,
  onChange,
  onRemove,
}: {
  field: GuidedField;
  options: GuidedOptions;
  onChange: (patch: Partial<GuidedField>) => void;
  onRemove: () => void;
}) {
  const meta = GUIDED_KINDS.find((k) => k.id === field.kind)!;
  const id = `fw-${field.kind}`;
  const value = field.values[0] ?? "";
  const list = field.kind === "product" ? options.products : field.kind === "login" ? options.logins : field.kind === "account" ? options.accounts : null;
  const numberish = field.kind === "destination" || field.kind === "sender";

  return (
    <div className="space-y-2 rounded-lg border border-border p-4">
      <div className="flex flex-wrap items-center gap-3">
        <span id={`${id}-label`} className="font-semibold">{meta.label}</span>
        {numberish && (
          <Segmented<MatchMode>
            label={`How to compare the ${meta.label.toLowerCase()}`}
            value={field.mode}
            onChange={(mode) => onChange({ mode, values: mode === "prefixes" ? field.values : [field.values[0] ?? ""] })}
            options={[
              { value: "prefix", label: "Starts with" },
              { value: "exact", label: "Is exactly" },
              { value: "prefixes", label: "Any of these prefixes" },
            ]}
          />
        )}
        <button type="button" aria-label={`Stop matching on ${meta.label.toLowerCase()}`} onClick={onRemove}
          className="ml-auto rounded p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground">
          <X className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {numberish && field.mode === "prefixes" ? (
          <>
            {field.values.map((v, i) => (
              <span key={i} className="flex items-center gap-1">
                <Input aria-label={`Prefix ${i + 1}`} className="w-36 font-mono" value={v} placeholder={field.kind === "destination" ? "+91" : "ACME"}
                  onChange={(e) => onChange({ values: field.values.map((x, n) => (n === i ? e.target.value : x)) })} />
                {field.values.length > 1 && (
                  <button type="button" aria-label={`Remove prefix ${v || i + 1}`} className="rounded p-1 text-muted-foreground hover:text-foreground"
                    onClick={() => onChange({ values: field.values.filter((_, n) => n !== i) })}>
                    <X className="h-3.5 w-3.5" aria-hidden="true" />
                  </button>
                )}
              </span>
            ))}
            <Button type="button" variant="ghost" size="sm" className="gap-1" onClick={() => onChange({ values: [...field.values, ""] })}>
              <Plus className="h-3.5 w-3.5" aria-hidden="true" /> Another prefix
            </Button>
          </>
        ) : list && list.length > 0 ? (
          <Select aria-labelledby={`${id}-label`} value={value} onChange={(e) => onChange({ values: [e.target.value] })} className="w-80 max-w-full">
            <option value="">Choose…</option>
            {list.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            {value && !list.some((o) => o.value === value) && <option value={value}>{value} (not in the catalogue)</option>}
          </Select>
        ) : (
          <Input aria-labelledby={`${id}-label`} className="w-80 max-w-full font-mono" value={value}
            inputMode={field.kind === "network" ? "numeric" : undefined}
            placeholder={{ destination: "+91", sender: "ACME", network: "405", text: "OTP", product: "transactional", login: "acme1", account: "acme" }[field.kind]}
            onChange={(e) => onChange({ values: [e.target.value] })} />
        )}
        {field.kind === "text" && <span className="text-sm text-muted-foreground">anywhere in the text</span>}
      </div>

      <label className="flex items-center gap-2 text-sm">
        <Checkbox checked={field.except} onChange={(e) => onChange({ except: e.target.checked })} />
        <span>{field.kind === "text" ? "Except when the text contains this" : field.mode === "prefixes" ? "Except these" : "Except this"}</span>
      </label>
    </div>
  );
}
