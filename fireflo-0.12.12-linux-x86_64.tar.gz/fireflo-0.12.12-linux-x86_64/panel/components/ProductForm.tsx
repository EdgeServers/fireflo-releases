"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ErrorCard, WarningCard } from "@/components/FormNotices";
import {
  PRODUCT_SLUG_MAX,
  type ProductInput,
  productWarnings,
  slugify,
  validateProduct,
} from "@/lib/product-types";

/**
 * Creating or describing one product.
 *
 * <p>The name is disabled on an existing product, and unlike the worker form that is not only about
 * key stability: this value is compared by every rate rule, every credential and every historical
 * call record, none of which is a foreign key that could follow a rename.
 */
export function ProductForm({
  initial,
  isNew,
  onSaved,
  onCancel,
}: {
  initial: ProductInput;
  isNew: boolean;
  onSaved: () => Promise<void>;
  onCancel: () => void;
}) {
  const [label, setLabel] = useState(initial.label ?? "");
  const [description, setDescription] = useState(initial.description ?? "");
  const [enabled, setEnabled] = useState(initial.enabled);
  const [whitelistEnabled, setWhitelistEnabled] = useState(initial.whitelistEnabled);
  const [override, setOverride] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  //on create the code follows the display name until the operator takes it over; on edit it is
  //simply what it already is, and cannot change
  const name = isNew ? (override ?? slugify(label)) : initial.name;
  const input: ProductInput = { name, label, description, enabled, whitelistEnabled };
  const warnings = productWarnings(input, isNew);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const invalid = validateProduct(input, isNew);
    if (invalid) {
      setError(invalid);
      return;
    }
    setSaving(true);
    setError("");
    try {
      const res = await fetch(
        isNew ? "/api/control/products" : `/api/control/products/${encodeURIComponent(name)}`,
        {
          method: isNew ? "POST" : "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(input),
        }
      );
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      //the server reserves the code, so it may not be the one previewed -- say so rather than
      //letting the operator find out from the list
      if (isNew && json?.data?.name && json.data.name !== name) {
        setError("");
        alert(`'${name}' was already taken, so this product's code is '${json.data.name}'.`);
      }
      await onSaved();
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">{isNew ? "New product" : `Editing ${initial.name}`}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="label" className="mb-1.5 block">Display name</Label>
              <Input
                id="label"
                value={label}
                onChange={(e) => setLabel(e.target.value)}
                placeholder="Premium AU mobile"
                autoFocus={isNew}
              />
              <p className="mt-1 text-xs text-muted-foreground">
                For this panel only. The code customers send is derived from it.
              </p>
            </div>

            <div>
              <Label htmlFor="code" className="mb-1.5 block">Code</Label>
              <Input
                id="code"
                value={name}
                onChange={(e) => setOverride(e.target.value)}
                //derived on create until overridden; on edit it is the identity and cannot move
                readOnly={isNew && override === null}
                disabled={!isNew}
                placeholder={isNew ? "from the display name" : undefined}
                className="font-mono"
              />
              {isNew ? (
                <p className="mt-1 text-xs text-muted-foreground">
                  What a customer sends as <code>system_type</code>, up to {PRODUCT_SLUG_MAX}{" "}
                  characters.{" "}
                  {override === null ? (
                    <button
                      type="button"
                      onClick={() => setOverride(name)}
                      className="text-primary underline-offset-2 hover:underline"
                    >
                      Choose it yourself
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setOverride(null)}
                      className="text-primary underline-offset-2 hover:underline"
                    >
                      Go back to deriving it
                    </button>
                  )}{" "}
                  It cannot be changed afterwards — every rule, credential and past call record
                  compares against this exact string and none of them would follow a rename.
                </p>
              ) : (
                <p className="mt-1 text-xs text-muted-foreground">
                  Fixed. To move to a different code: create it, re-point the rules, then delete this
                  one.
                </p>
              )}
            </div>
          </div>

          <div>
            <Label htmlFor="description" className="mb-1.5 block">What the customer is buying</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              placeholder="Sender ID preserved, direct routes only, delivery receipts within 30s."
            />
          </div>

          <label className="flex items-start gap-2 text-sm">
            <input
              type="checkbox"
              checked={enabled}
              onChange={(e) => setEnabled(e.target.checked)}
              className="mt-0.5 h-4 w-4 rounded border-input accent-primary"
            />
            <span>
              Listed
              {/* the opposite of what enabled means on a vendor, so it has to be said here */}
              <span className="block text-xs text-muted-foreground">
                Mostly this panel&rsquo;s lists: unlisting a product does not stop its rate rules
                pricing traffic. It does end any whitelist exemption below, which puts that
                traffic back under checking.
              </span>
            </span>
          </label>

          <label className="flex items-start gap-2 text-sm">
            <input
              type="checkbox"
              checked={whitelistEnabled}
              onChange={(e) => setWhitelistEnabled(e.target.checked)}
              className="mt-0.5 h-4 w-4 rounded border-input accent-primary"
            />
            <span>
              Check sender IDs and content
              {/* the one field here the gateway acts on, so it is the one worth spelling out */}
              <span className="block text-xs text-muted-foreground">
                On, every account sending under this product is held to its approved sender IDs and
                content templates. Off exempts all of them at once, whatever their own settings say
                &mdash; for traffic where a registered sender ID is not the point, such as one-time
                passwords on a shortcode. Traffic with no product, or naming a product that does not
                exist here, is always checked.
              </span>
            </span>
          </label>
        </CardContent>
      </Card>

      <WarningCard warnings={warnings} />
      <ErrorCard error={error} />

      <div className="flex items-center gap-3">
        <Button type="submit" disabled={saving || !name.trim()}>
          {saving ? "Saving…" : isNew ? "Create product" : "Save changes"}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
      </div>
    </form>
  );
}
