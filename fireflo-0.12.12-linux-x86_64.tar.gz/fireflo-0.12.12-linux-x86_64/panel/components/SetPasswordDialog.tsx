"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { ErrorNote } from "@/components/FormNotices";
import { PasswordFields } from "@/components/PasswordFields";

/**
 * An admin sets another user's password. The new value is typed twice and handed over out of band.
 */
export function SetPasswordDialog({
  email,
  open,
  onClose,
  onSubmit,
}: {
  email: string;
  open: boolean;
  onClose: () => void;
  onSubmit: (password: string) => Promise<string | null>;
}) {
  const [password, setPassword] = useState("");
  const [ready, setReady] = useState(false);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");
    const failed = await onSubmit(password);
    setSaving(false);
    if (failed) {
      setError(failed);
      return;
    }
    setPassword("");
    onClose();
  }

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title={`Set password for ${email}`}
      description="Their current sessions stay signed in; only the next sign-in needs the new one."
    >
      <form onSubmit={submit} className="space-y-4">
        <PasswordFields
          value={password}
          email={email}
          autoFocus
          onChange={(pw, ok) => {
            setPassword(pw);
            setReady(ok);
          }}
        />
        {error && <ErrorNote error={error} />}
        <div className="flex gap-2">
          <Button type="submit" disabled={!ready || saving}>
            {saving ? "Saving…" : "Set password"}
          </Button>
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
        </div>
      </form>
    </Dialog>
  );
}
