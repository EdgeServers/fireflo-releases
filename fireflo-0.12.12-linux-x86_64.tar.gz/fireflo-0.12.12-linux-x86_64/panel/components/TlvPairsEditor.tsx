"use client";
import { Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { TlvTokenInput } from "@/components/TlvTokenInput";
import { duplicateTlvKeys, tlvPairProblem, type TlvPair } from "@/lib/tlv-string";
import type { TlvDefinition } from "@/lib/tlv-catalogue";

/**
 * Rows of `name_tag` = value, the one editor for every TLV the operator can type.
 *
 * <p>Lifted out of `CredentialForm` so the whitelist cards do not grow a second one. Two editors for
 * one format is how the panel ends up disagreeing with itself about what a valid tag is — the
 * per-row amber "no tag here" line comes from `TlvTokenInput` and the catalogue, and it is the only
 * thing standing between an operator and a stamp like `PEID=…` that the gateway silently discards.
 *
 * <p>Credentials store these as jsonb and the whitelist tables store them as a comma-joined string;
 * both arrive here as pairs, and `lib/tlv-string` does the string half.
 */
export function TlvPairsEditor({
  pairs,
  onChange,
  definitions = [],
  suggested = {},
  addLabel = "Add a TLV",
  valuePlaceholder = "a literal, MESSAGE:field, or hex:…",
  disabled = false,
}: {
  pairs: readonly TlvPair[];
  onChange: (pairs: TlvPair[]) => void;
  definitions?: readonly TlvDefinition[];
  suggested?: Record<number, boolean>;
  addLabel?: string;
  valuePlaceholder?: string;
  disabled?: boolean;
}) {
  const duplicates = new Set(duplicateTlvKeys(pairs).map((k) => k.toLowerCase()));
  const replace = (i: number, patch: Partial<TlvPair>) =>
    onChange(pairs.map((p, n) => (n === i ? { ...p, ...patch } : p)));

  return (
    <div className="space-y-2">
      {pairs.map((pair, i) => {
        const problem = tlvPairProblem(pair);
        const duplicate = duplicates.has(pair.key.trim().toLowerCase());
        return (
          <div key={i} className="space-y-1">
            {/* one line, always. These were two fixed `w-64` fields -- 16rem each, so a row needed
                well over 500px before the remove button and wrapped in any dialog. It was worse
                when this was written: the panel then set a 21px root, which made each field 336px
                and the row ~700px. `min-w-0` is the load-bearing half either way: a flex child
                defaults to `min-width: auto` and refuses to shrink below its content without it */}
            <div className="flex items-start gap-2">
              <TlvTokenInput
                value={pair.key}
                onChange={(key) => replace(i, { key })}
                definitions={definitions}
                suggested={suggested}
                ariaLabel="TLV token"
                className="min-w-0 flex-1"
              />
              <Input
                value={pair.value}
                onChange={(e) => replace(i, { value: e.target.value })}
                placeholder={valuePlaceholder}
                className="min-w-0 flex-1 font-mono"
                aria-label="TLV value"
                disabled={disabled}
              />
              <Button type="button" variant="ghost" size="icon" className="h-8 w-8"
                aria-label="Remove this TLV" disabled={disabled}
                onClick={() => onChange(pairs.filter((_, n) => n !== i))}>
                <X className="h-3.5 w-3.5" />
              </Button>
            </div>
            {problem && <p className="text-xs text-destructive">{problem}</p>}
            {!problem && duplicate && (
              <p className="text-xs text-amber-600 dark:text-amber-500">
                This name is used twice. The gateway keeps the first and drops the rest without
                logging it.
              </p>
            )}
          </div>
        );
      })}
      <Button type="button" variant="ghost" size="sm" className="gap-1.5" disabled={disabled}
        onClick={() => onChange([...pairs, { key: "", value: "" }])}>
        <Plus className="h-3.5 w-3.5" />
        {addLabel}
      </Button>
      <p className="text-xs text-muted-foreground">
        The tag is whatever follows the last underscore, decimal unless written{" "}
        <code>0x</code> — so <code>tlv_0100</code> is tag 100, not 64.
      </p>
    </div>
  );
}
