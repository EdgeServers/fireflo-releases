"use client";
import { useMemo, useState } from "react";
import Link from "next/link";
import { Bar, CartesianGrid, ComposedChart, Line, XAxis, YAxis } from "recharts";
import { CheckCircle2, Send, TriangleAlert, Percent } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { PageHeader } from "@/components/ui/page-header";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import { ErrorCard } from "./FormNotices";
import { RangePicker } from "./RangePicker";
import { StatCard } from "./StatCard";
import { useControlData, type Range } from "./useControlData";
import type { UsageDay } from "@/lib/metrics-queries";
import { toAccountRows, toSeries, usageTotals } from "@/lib/usage-summary";
import { count, money, percent } from "@/lib/format";

/**
 * How much traffic went out, whether it arrived, and who sent it.
 *
 * <p>Volume and delivery lead; money is the last column rather than the headline. The question this
 * page answers is operational — "is the platform carrying what it should, and is it landing" — and
 * `/cp/revenue` already answers the commercial one.
 *
 * <p>The account table is the drill-down. Each row links to that account, whose own Overview tab
 * asks the same question scoped to one customer.
 */
const ANIMATION = { isAnimationActive: false } as const;

/**
 * Delivered, failed, and the rate over the top.
 *
 * <p>Deliberately the same three colours the customer portal uses for the same three facts. An
 * operator and a customer looking at the same delivery problem should not have to learn two charts.
 */
const chartConfig = {
  delivered: { label: "Delivered", color: "var(--color-chart-1)" },
  failed: { label: "Failed", color: "var(--color-destructive)" },
  rate: { label: "Delivery rate", color: "var(--color-chart-2)" },
} satisfies ChartConfig;

export function UsageClient({ currency }: { currency: string }) {
  //7 days rather than the 24h every other control page defaults to. A day is the unit a usage
  //question is asked in, and one day of hourly buckets cannot show a weekday-to-weekend shape
  const [range, setRange] = useState<Range>("7d");
  const { data, error, loading } = useControlData<UsageDay[]>("usage", range);
  const rows = useMemo(() => data ?? [], [data]);
  const series = useMemo(() => toSeries(rows), [rows]);
  const accounts = useMemo(() => toAccountRows(rows), [rows]);
  const totals = useMemo(() => usageTotals(rows), [rows]);

  return (
    <>
      <PageHeader
        title="Usage"
        description="How much traffic went out, whether it arrived, and who sent it."
        actions={<RangePicker value={range} onChange={setRange} />}
      />

      <ErrorCard error={error} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard title="Sent" value={count(totals.submitted)} icon={Send} loading={loading} />
        <StatCard title="Delivered" value={count(totals.delivered)} icon={CheckCircle2}
          tone="positive" loading={loading} />
        <StatCard title="Failed" value={count(totals.failed)} icon={TriangleAlert}
          tone={totals.failed > 0 ? "negative" : "default"} loading={loading} />
        <StatCard
          title="Delivery rate"
          value={percent(totals.rate === null ? null : totals.rate / 100)}
          icon={Percent}
          loading={loading}
          hint={totals.pending > 0 ? `${count(totals.pending)} still awaiting a receipt` : undefined}
        />
      </div>

      <Card>
        <CardHeader bar>
          <CardTitle>Traffic</CardTitle>
          <p className="text-xs text-muted-foreground">
            Bars: messages that settled, per day · Line: delivery rate. Messages still awaiting a
            receipt are counted above but not drawn, so today does not read as a spike.
          </p>
        </CardHeader>
        <CardContent>
          {loading && !data ? (
            <div className="h-64" />
          ) : (
            <ChartContainer config={chartConfig} className="h-64 w-full">
              <ComposedChart data={series} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--color-border)" />
                <XAxis
                  dataKey="day"
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                  tickFormatter={(v: string) => (v.length > 10 ? v.slice(11, 16) : v.slice(5))}
                  interval="preserveStartEnd"
                />
                <YAxis
                  yAxisId="volume"
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                  width={44}
                  allowDecimals={false}
                />
                {/* its own axis, fixed at 0-100. Sharing the volume axis would flatten the rate into
                    the baseline the moment a day passed a hundred messages */}
                <YAxis
                  yAxisId="rate"
                  orientation="right"
                  domain={[0, 100]}
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                  width={38}
                  tickFormatter={(v: number) => `${v}%`}
                />
                <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
                {/* {@link ANIMATION} — a Bar with the default animation draws nothing at all until a
                    frame is painted, so a background tab renders an empty pair of axes */}
                <Bar {...ANIMATION} yAxisId="volume" dataKey="delivered" stackId="v"
                  fill={chartConfig.delivered.color} radius={[0, 0, 2, 2]} />
                <Bar {...ANIMATION} yAxisId="volume" dataKey="failed" stackId="v"
                  fill={chartConfig.failed.color} radius={[2, 2, 0, 0]} />
                {/* connectNulls={false}: a day with nothing settled has no rate, and joining across
                    it would draw a line through a gap that never happened */}
                <Line yAxisId="rate" dataKey="rate" stroke={chartConfig.rate.color} strokeWidth={2}
                  dot={false} connectNulls={false} />
              </ComposedChart>
            </ChartContainer>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader bar>
          <CardTitle>By account</CardTitle>
          <p className="text-xs text-muted-foreground">
            Heaviest sender first. Open one to see the same figures for that customer alone.
          </p>
        </CardHeader>
        <CardContent>
          {accounts.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              {loading ? "Loading…" : "No traffic in this window."}
            </p>
          ) : (
            <TableInCard className="tabular-nums">
              <THead>
                <tr>
                  <TH>Account</TH>
                  <TH align="right">Sent</TH>
                  <TH align="right">Delivered</TH>
                  <TH align="right">Failed</TH>
                  <TH align="right">Pending</TH>
                  <TH align="right">Rate</TH>
                  <TH align="right">Billed</TH>
                </tr>
              </THead>
              <TBody>
                {/* a React key must be a string, so the unattributed row needs one value no
                    account id can be. An id reaches us from the wire as well as from the
                    catalogue, so a space or a word is not safe -- only a NUL is.

                    Written as the escape \u0000, which is source TEXT. Putting the byte itself
                    here is what made this whole file binary to grep, and hid it from every
                    search in the repo. */}
                {accounts.map((a) => (
                  <TR key={a.accountId === null ? "\u0000" : a.accountId}>
                    <TD>
                      {a.accountId ? (
                        <Link href={`/cp/accounts/${encodeURIComponent(a.accountId)}`}
                          className="font-mono text-primary hover:underline">
                          {a.accountId}
                        </Link>
                      ) : (
                        //not an account called "", and not an error: traffic that named none
                        <span className="text-muted-foreground">no account</span>
                      )}
                    </TD>
                    <TD align="right">{count(a.submitted)}</TD>
                    <TD align="right">{count(a.delivered)}</TD>
                    <TD align="right">
                      {a.failed > 0 ? (
                        <span className="text-destructive">{count(a.failed)}</span>
                      ) : (
                        count(0)
                      )}
                    </TD>
                    <TD align="right" muted>
                      {count(a.pending)}
                    </TD>
                    <TD align="right">
                      {percent(a.rate === null ? null : a.rate / 100)}
                    </TD>
                    <TD align="right">{money(a.price, currency)}</TD>
                  </TR>
                ))}
              </TBody>
            </TableInCard>
          )}
        </CardContent>
      </Card>
    </>
  );
}
