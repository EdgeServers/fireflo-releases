"use client";

import { useEffect, useState } from "react";
import { AlertTriangle } from "lucide-react";
import { HealthStrip } from "@/components/CardBits";
import { ErrorCodeEditor } from "@/components/ErrorCodeEditor";
import { GLOBAL_LIST_KEY, GLOBAL_PASSTHROUGH_KEY, useErrorCodes } from "@/components/ErrorCodesShell";
import { SaveBar } from "@/components/SaveBar";
import { SettingsSection } from "@/components/SettingsSection";
import { Switch } from "@/components/ui/switch";
import { errorCodeProblem, formatErrorCodes, type ErrorCodePair } from "@/lib/error-codes";

/**
 * The Every vendor error-code list -- the one each vendor inherits until it sets its own.
 *
 * <h2>Which vendors replace it is in the column beside it</h2>
 *
 * <p>The one cross-vendor fact this list raises is who is not using it. That used to be a card at
 * the foot of this page; it is now the section's left column, where every list is one click away
 * and each vendor says "Inherits" or "Own list".
 *
 * <h2>The gateway resolves this with no Java change</h2>
 *
 * <p>{@code FireFloConfigurationHandler.get} rewrites an unresolved
 * {@code outSms.instance.<vendor>.<prop>} to {@code outSms.default.<prop>}, so both keys written
 * here already reach every vendor that sets nothing itself. It does NOT union the two maps: a vendor
 * with a list of its own loses every entry below.
 *
 * <h2>Staged, like the Gateway page</h2>
 *
 * <p>The list and the passthrough answer both wait for Save. The passthrough used to save on click,
 * which made it the one control on the page that changed every vendor's receipts with no moment to
 * review it.
 */
export function ErrorCodesClient() {
  const data = useErrorCodes();
  const [pairs, setPairs] = useState<ErrorCodePair[]>([]);
  const [passthrough, setPassthrough] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  //a staged edit is discarded by going back to what the layout loaded
  const reset = () => {
    setPairs(data.globalPairs.map((p) => ({ ...p })));
    setPassthrough(data.globalPassthrough);
  };
  //adopt what was loaded, and again after every save reloads it
  useEffect(() => {
    //eslint-disable-next-line react-hooks/set-state-in-effect -- copying the layout's data into an editable draft
    setPairs(data.globalPairs.map((p) => ({ ...p })));
    setPassthrough(data.globalPassthrough);
  }, [data.globalPairs, data.globalPassthrough]);

  if (data.loading) {
    return <p className="text-sm text-muted-foreground">Loading…</p>;
  }

  const listChanged = formatErrorCodes(pairs) !== formatErrorCodes(data.globalPairs);
  const passChanged = passthrough !== data.globalPassthrough;
  const dirty = (listChanged ? 1 : 0) + (passChanged ? 1 : 0);
  const blocked = pairs.some((p) => errorCodeProblem(p) !== null);
  const inheriting = data.vendors.filter((v) => v.own === null).length;

  async function put(key: string, value: string): Promise<boolean> {
    const res = await fetch("/api/control/gateway-settings", {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ key, value }),
    });
    if (!res.ok) {
      const body = await res.json().catch(() => null);
      setError(body?.error ?? "That could not be saved.");
      return false;
    }
    return true;
  }

  async function save() {
    setSaving(true);
    setError(null);
    try {
      if (listChanged && !(await put(GLOBAL_LIST_KEY, formatErrorCodes(pairs)))) return;
      //an empty value rather than "false": `setGatewaySetting` deletes the row for an empty value,
      //and absent is what "the gateway's own default" means
      if (passChanged && !(await put(GLOBAL_PASSTHROUGH_KEY, passthrough ? "true" : ""))) return;
    } finally {
      setSaving(false);
      await data.reload();
    }
  }

  return (
    <>
      {(error || data.error) && <HealthStrip tone="destructive">{error ?? data.error}</HealthStrip>}

      <SettingsSection
        id="every-vendor"
        title="Every vendor"
        description={
          <>
            {data.vendors.length > 0
              ? `Used by ${inheriting} of ${data.vendors.length} ${data.vendors.length === 1 ? "vendor" : "vendors"}. `
              : ""}
            A vendor&apos;s own list <strong>replaces</strong> this one; it does not add to it.
          </>
        }
        bodyClassName="px-5 py-4"
      >
        <ErrorCodeEditor pairs={pairs} onChange={setPairs} disabled={saving} />
      </SettingsSection>

      <SettingsSection id="unmapped" title="Codes nobody mapped" bodyClassName="px-5 py-4 space-y-3">
        <div className="flex items-center gap-6">
          <div className="min-w-0 flex-1">
            <div id="ec-pass-label" className="font-semibold">Send them as the carrier sent them</div>
            <p className="text-sm text-muted-foreground">
              Off, a code not listed above reaches the customer as 018.
            </p>
            <span
              className={
                passChanged
                  ? "mt-1 inline-block rounded-full bg-primary px-2 py-px text-2xs font-medium text-primary-foreground"
                  : data.globalPassthroughSet
                    ? "mt-1 inline-block rounded-full bg-primary-soft px-2 py-px text-2xs font-medium text-primary"
                    : "mt-1 inline-block rounded-full bg-muted px-2 py-px text-2xs font-medium text-muted-foreground"
              }
            >
              {passChanged
                ? `Unsaved · was ${data.globalPassthrough ? "on" : "off"}`
                : data.globalPassthroughSet ? "Set · default is off" : "Default"}
            </span>
          </div>
          <Switch
            checked={passthrough}
            disabled={saving}
            aria-labelledby="ec-pass-label"
            onChange={setPassthrough}
          />
        </div>

        {/* the gateway defaults this off so that an upgrade changes nothing, and this control can
            undo that for the whole deployment in one click. Amber rather than a refusal: it is a
            legitimate thing to want, and the operator is the one who knows their carriers */}
        {passthrough && (
          <p className="flex items-start gap-2 text-sm text-amber-700 dark:text-amber-400">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
            <span>
              This changes the <code className="font-mono">err:</code> value on receipts from every
              vendor that has not set its own answer, including carriers whose codes nobody here has
              checked. A customer with logic built on seeing 018 will see something else.
            </span>
          </p>
        )}
      </SettingsSection>

      <SaveBar
        count={dirty}
        saving={saving}
        blocked={blocked}
        message="Nothing has reached the gateway yet. Vendors that inherit this list pick it up at the next poll."
        blockedMessage="Fix the highlighted mapping before saving."
        onDiscard={reset}
        onSave={() => void save()}
        inset
      />
    </>
  );
}
