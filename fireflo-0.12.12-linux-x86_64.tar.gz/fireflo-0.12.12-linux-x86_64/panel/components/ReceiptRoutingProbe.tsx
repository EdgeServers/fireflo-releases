"use client";

import { useCallback, useEffect, useState } from "react";
import { AlertTriangle, ShieldAlert } from "lucide-react";
import { receiptRoutingProblem, type RoutingExplanation } from "@/lib/routing-types";
import { trafficKey, type Worker } from "@/lib/worker-types";

/**
 * Asks the gateway where a delivery receipt from each listener actually goes.
 *
 * <h2>The question the presence check cannot ask</h2>
 *
 * <p>`missingDlrReturnRules` answers "is a return rule present". A live incident passed that check
 * twice while failing in two different ways, because the real question is "where does a receipt
 * land".
 *
 * <p>A box gained a second listener. The shipped default carries one return rule naming the FIRST
 * listener, so receipts for the second were routed to the wrong one and parked unreachable — a rule
 * was present and matching, so nothing read as missing. Repairing it by hand then left
 * `type == 18` matching a rule that targeted the **vendor**, and receipts were submitted upstream as
 * outbound messages and accepted: billed traffic, and an Appendix B receipt possibly delivered to a
 * handset as text.
 *
 * <p>Rules are first-match in `seq` order and a receipt is an ordinary message to the matcher — its
 * addresses are merely reversed — so any business rule above the return rule swallows it. Position
 * is what makes the rule work, and position is invisible to a presence check.
 *
 * <p>So this asks {@code /ops/routing/explain}, which is the gateway's own matcher rather than this
 * panel's reading of the table. It runs after a routing change and on load.
 */
export function ReceiptRoutingProbe({
  servers,
  reloadKey,
}: {
  servers: readonly Worker[];
  /**
   * Changes whenever the tables change, so the probe re-runs. Derived from rule ORDER as well as
   * membership: reordering is the edit that turns a working return rule into a swallowed one, and a
   * key that only counted rules would miss exactly that.
   */
  reloadKey: string;
}) {
  const [findings, setFindings] = useState<{ target: string; severity: string; message: string }[]>([]);
  const [checked, setChecked] = useState(false);

  const probe = useCallback(async () => {
    const live = servers.filter((s) => s.enabled !== false);
    if (live.length === 0) {
      setFindings([]);
      setChecked(true);
      return;
    }
    const out: { target: string; severity: string; message: string }[] = [];
    for (const server of live) {
      const target = trafficKey(server);
      try {
        const params = new URLSearchParams({ type: "18", ingateway: target });
        const res = await fetch(`/api/control/routing/explain?${params}`, { cache: "no-store" });
        const body = await res.json();
        if (!res.ok) {
          //an unreachable gateway is not a routing finding. Reporting it as one would send an
          //operator to the routing table for a problem that is not there
          continue;
        }
        const answer = (body?.data as RoutingExplanation | null) ?? null;
        const matched = answer?.matchedIndex ?? null;
        //matchedIndex is 1-based, the routing page's own numbering, so it is looked up by `index` and
        //never used as an array position: that read the rule BELOW the match, which reported a
        //correct table as sending receipts to the wrong listener, or to nowhere for the last rule
        const rule = matched === null ? null : (answer?.rules?.find((r) => r.index === matched)?.target ?? null);
        const verdict = receiptRoutingProblem(target, rule);
        if (verdict.severity !== "none") {
          out.push({ target, ...verdict });
        }
      } catch {
        //same reasoning: a failed probe is silence, never a false accusation about the table
      }
    }
    setFindings(out);
    setChecked(true);
  }, [servers, reloadKey]);

  useEffect(() => {
    void probe();
  }, [probe]);

  if (!checked || findings.length === 0) {
    return null;
  }

  return (
    <div className="space-y-2">
      {findings.map((f) => {
        const danger = f.severity === "danger";
        return (
          <p
            key={f.target}
            className={
              danger
                ? "flex items-start gap-2 rounded-md border border-destructive/50 bg-destructive/5 px-3 py-2 text-sm"
                : "flex items-start gap-2 rounded-md border border-amber-500/40 bg-amber-500/5 px-3 py-2 text-sm"
            }
          >
            {danger ? (
              <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
            ) : (
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
            )}
            <span>{f.message}</span>
          </p>
        );
      })}
    </div>
  );
}
