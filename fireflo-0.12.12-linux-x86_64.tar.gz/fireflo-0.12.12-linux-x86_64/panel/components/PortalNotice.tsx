"use client";
import { useEffect, useState } from "react";

/**
 * A red line in the customer portal while the platform is not applying changes.
 *
 * <h2>What it deliberately does not say</h2>
 *
 * <p>Not "licence". Not the platform's name. Not whose fault it is. This portal is white-labelled —
 * `portalBrand` exists so a reseller's customers believe their provider runs it — and a bar reading
 * "the FireFlo licence has expired" would undo that in one sentence, to an audience who cannot act
 * on it and did not ask.
 *
 * <p>So it says the one thing that is both true and useful to a customer: a change they make now
 * may not take effect yet, and their provider is who to ask. That is exactly the observable
 * consequence of a frozen gateway from where they are standing.
 *
 * <h2>Only while actually frozen</h2>
 *
 * <p>Keyed on the gateway having stopped adopting configuration, not on the licence merely being
 * unverified. A new install inside its setup window works normally, and warning a customer about a
 * state that is not affecting them is how a notice becomes wallpaper.
 *
 * <p>Renders nothing while loading and nothing when unrestricted.
 */
export function PortalNotice() {
  const [restricted, setRestricted] = useState(false);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/mis/platform-status", { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : null))
      .then((json: { data?: { restricted?: boolean } } | null) => {
        if (!cancelled && json?.data?.restricted) {
          setRestricted(true);
        }
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, []);

  if (!restricted) {
    return null;
  }

  return (
    <div
      role="status"
      className="border-b border-destructive/40 bg-destructive/10 px-4 py-2 text-sm text-destructive"
    >
      <strong className="font-medium">Changes are not being applied at the moment.</strong>{" "}
      <span className="opacity-90">
        You can still see your messages and balance, and sending is unaffected. Anything you add or
        edit may not take effect until this clears — please contact your provider.
      </span>
    </div>
  );
}
