"use client";
import { useCallback, useEffect, useState } from "react";
import type { Worker, WorkerType } from "@/lib/worker-types";
import {
  ENABLE_ACTIONS,
  PAUSE_ACTIONS,
  SUSPEND_ACTIONS,
  type WorkerAction,
} from "@/lib/worker-actions";

/**
 * Loading and editing one kind of connection.
 *
 * <p>Shared by the vendor and server pages, which differ in what they show rather than in what they
 * do — both list, add, edit, enable and delete the same way, against the same endpoint with a
 * different `type`.
 */
export function useWorkers(type: WorkerType) {
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [error, setError] = useState("");
  //which worker the current error belongs to, so it can be shown on that card rather than only in a
  //banner at the top of a long list -- where a failed action on the eighth vendor is off screen and
  //reads as the button having done nothing
  const [errorFor, setErrorFor] = useState("");
  const [notice, setNotice] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");
  //which action is in flight, so the button that was pressed can say so. Without it every control on
  //the card greys out together and the one actually clicked gives no feedback at all
  const [busyLabel, setBusyLabel] = useState("");

  const load = useCallback(async () => {
    try {
      const res = await fetch(`/api/control/workers?type=${type}`, { cache: "no-store" });
      const json = await res.json();
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        setWorkers([]);
      } else {
        setWorkers(json.data as Worker[]);
        setError("");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setLoading(false);
    }
  }, [type]);

  useEffect(() => {
    load();
  }, [load]);

  /**
   * Asks the gateway to apply one control immediately.
   *
   * <p>A failure here is reported as a <strong>notice, not an error</strong>. The database write has
   * already succeeded and is the record; all that is lost is the immediacy. Calling it an error
   * would have someone pressing Disable again on a vendor that is already stopping.
   */
  const push = useCallback(async (name: string, action: WorkerAction) => {
    try {
      const res = await fetch(
        `/api/control/workers/${encodeURIComponent(name)}/${action}`,
        { method: "POST" }
      );
      if (res.status === 402) {
        //a lapsed licence is the one failure where the thirty-second promise below would be a
        //lie: the gateway's config poll refuses to adopt ANY change while unlicensed, so the
        //stored row waits for the licence, not for the poll. Finding 00's incident was exactly
        //this -- buttons that "did nothing" on a frozen 0.8.x gateway
        const json = await res.json().catch(() => null);
        setNotice(
          "Saved, but NOT applied: the gateway's licence is not current, and a lapsed gateway "
            + "adopts no configuration changes — this one included. It is stored and will take "
            + "effect once the licence is renewed on /cp/verify."
            + (json?.error ? ` (${json.error})` : "")
        );
      } else if (!res.ok) {
        const json = await res.json().catch(() => null);
        setNotice(
          `Saved, but the gateway did not confirm — it will pick this up within 30 seconds.`
            + (json?.error ? ` (${json.error})` : "")
        );
      } else {
        return true;
      }
    } catch {
      setNotice("Saved, but the gateway could not be reached — it will pick this up within 30 seconds.");
    }
    return false;
  }, []);

  /**
   * Writes the change, then tells the gateway to apply it now.
   *
   * <p>That order is the point. The database write is the durable intent: it survives a restart, and
   * the gateway's own poll applies it within thirty seconds even if the action never lands. The
   * action only removes the wait. Reversed, a restart between the two would lose a change the panel
   * had already reported as saved.
   *
   * @param action the verb to push afterwards, or null for writes that are configuration rather
   *     than control -- a delete, or a full save -- which go through Apply now instead
   */
  const act = useCallback(
    async (
      name: string,
      run: () => Promise<Response>,
      action: WorkerAction | null = null,
      label = ""
    ) => {
      setBusy(name);
      setBusyLabel(label);
      setNotice("");
      setErrorFor("");
      try {
        const res = await run();
        const json = await res.json().catch(() => null);
        if (!res.ok) {
          setError(json?.error ?? `Request failed (${res.status})`);
          setErrorFor(name);
          return;
        }
        setError("");
        if (action) {
          const confirmed = await push(name, action);
          if (confirmed) {
            //the half that was missing (Audit F12): a click that worked looked identical to a
            //click that silently did nothing. The card re-renders either way; this line says the
            //gateway itself confirmed the change is live now, not merely stored
            setNotice(`${label || "Change"} applied — the gateway confirmed it took effect immediately.`);
          }
        }
        await load();
      } catch (err) {
        setError(err instanceof Error ? err.message : "Request failed");
        setErrorFor(name);
      } finally {
        setBusy("");
        setBusyLabel("");
      }
    },
    [load, push]
  );

  const setEnabled = useCallback(
    (name: string, enabled: boolean) =>
      act(
        name,
        () =>
          fetch(`/api/control/workers/${encodeURIComponent(name)}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ enabled }),
          }),
        enabled ? ENABLE_ACTIONS.on : ENABLE_ACTIONS.off,
        enabled ? "Enable" : "Disable"
      ),
    [act]
  );

  /**
   * Writes one setting — `suspend` or `pause` — without touching the rest.
   *
   * <p>Boolean rather than string at this level because both controls are on/off, and an empty
   * value is what removes the setting: the gateway reads `""` as a real value and would skip its
   * own default.
   */
  const setProperty = useCallback(
    (name: string, key: string, on: boolean, label = "") => {
      const verbs = key === "pause" ? PAUSE_ACTIONS : SUSPEND_ACTIONS;
      return act(
        name,
        () =>
          fetch(`/api/control/workers/${encodeURIComponent(name)}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ property: { key, value: on ? "true" : "" } }),
          }),
        on ? verbs.on : verbs.off,
        label
      );
    },
    [act]
  );

  /**
   * Bounces a worker: the gateway's `restart` verb is disable-then-enable, sessions torn down
   * and re-dialled. A pure action — nothing is stored, so there is no PATCH half and no
   * thirty-second promise to make.
   */
  const restart = useCallback(async (name: string) => {
    setBusy(name);
    setBusyLabel("Restart");
    setNotice("");
    setErrorFor("");
    try {
      const res = await fetch(`/api/control/workers/${encodeURIComponent(name)}/restart`, {
        method: "POST",
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        setErrorFor(name);
      } else {
        setError("");
        setNotice(`${name} restarted — its sessions were dropped and re-dialled.`);
      }
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
      setErrorFor(name);
    } finally {
      setBusy("");
      setBusyLabel("");
    }
  }, [load]);

  const remove = useCallback(
    (name: string) =>
      act(name, () =>
        fetch(`/api/control/workers/${encodeURIComponent(name)}`, { method: "DELETE" })
      ),
    [act]
  );

  /** Asks the gateway to re-read now rather than at its next poll. */
  const applyNow = useCallback(async () => {
    setBusy("__reload");
    setNotice("");
    try {
      const res = await fetch("/api/control/reload", { method: "POST" });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
      } else {
        setError("");
        setNotice(`Gateway reloaded — settings came from ${json?.data?.reloaded?.properties ?? "?"}.`);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setBusy("");
    }
  }, []);

  return {
    workers,
    error,
    errorFor,
    notice,
    loading,
    busy,
    busyLabel,
    load,
    setEnabled,
    setProperty,
    restart,
    remove,
    applyNow,
  };
}
