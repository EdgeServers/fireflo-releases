"use client";
import { ChevronDown, ChevronRight } from "lucide-react";

/**
 * A collapsible group of fields, with a count of how many are set.
 *
 * <p>Not in `ui/`: the "3 set" badge and the rules about when a section opens itself are product
 * knowledge, and `ui/` here is style only.
 *
 * <p><strong>Deliberately not `<details>`.</strong> `HealthClient` uses one and is right to — it
 * re-renders from a five-second poll and wants the DOM to own the open state. A form re-renders on
 * every keystroke, and `<details>` would fight the parent for control of `open` each time.
 *
 * <p>The count matters more than it looks: a collapsed section that hides configuration someone
 * already set is how a form quietly loses settings. `WorkerFields` also opens any section holding a
 * stored value, so the badge is a reminder rather than the only signal.
 */
export function DisclosureSection({
  title,
  set,
  open,
  onToggle,
  note,
  id,
  children,
}: {
  title: string;
  /** The element id, so a link can scroll to the section. */
  id?: string;
  /** How many fields in this section currently hold a value. */
  set: number;
  open: boolean;
  onToggle: () => void;
  note?: string;
  children: React.ReactNode;
}) {
  return (
    <div id={id} className="scroll-mt-4 rounded-xl border border-border bg-card">
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={open}
        className="flex w-full items-center gap-2 px-4 py-3 text-left text-base font-medium hover:bg-accent/50"
      >
        {open ? (
          <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" />
        ) : (
          <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
        )}
        <span className="flex-1">{title}</span>
        {set > 0 && <span className="text-xs font-normal text-muted-foreground">{set} set</span>}
      </button>
      {open && (
        <div className="space-y-4 border-t border-border px-4 py-3">
          {note && <p className="text-xs text-muted-foreground">{note}</p>}
          {children}
        </div>
      )}
    </div>
  );
}
