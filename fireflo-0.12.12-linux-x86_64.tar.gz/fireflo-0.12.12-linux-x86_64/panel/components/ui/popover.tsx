"use client";
import * as React from "react";
import { createPortal } from "react-dom";
import { Info } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * A short explanation, out of the way until it is wanted.
 *
 * <p>Written for the Refused page's summary cards, where the explanatory sentence under each reason
 * was four times the height of the count it explained. Four reasons filled the viewport, and the
 * counts — the thing an operator is comparing — ended up too far apart to compare. The words are
 * still worth having; they are just not worth having all of them, all of the time.
 *
 * <p><strong>Not a {@link Dialog}, and deliberately missing most of what one does.</strong> No focus
 * trap, no scroll lock, no backdrop: this is a hint beside a control, and a hint that captures the
 * keyboard and freezes the page is worse than no hint. What it keeps from the dialog is the part
 * that is about correctness rather than ceremony — Escape closes, an outside click closes, and it
 * renders through a portal.
 *
 * <p>The portal is not optional. `position: fixed` resolves against the nearest ancestor with a
 * transform, filter or backdrop-filter, and the dashboard shell has several; a panel positioned
 * inside a card would be placed relative to that card on some pages and the viewport on others.
 * Rendering to `document.body` and measuring the trigger makes one rule that holds everywhere.
 *
 * <p>The trigger is a real button rather than a `title=` attribute. `title` never appears on a touch
 * device at all, and on a desktop it appears after a delay long enough that most people have moved
 * the pointer on.
 */
export function InfoPopover({
  label,
  children,
  className,
}: {
  /** What this explains, for a screen reader: "Why: Never routed". */
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  const [open, setOpen] = React.useState(false);
  const [at, setAt] = React.useState<{ top: number; left: number } | null>(null);
  const trigger = React.useRef<HTMLButtonElement>(null);
  const panel = React.useRef<HTMLDivElement>(null);
  const id = React.useId();

  const place = React.useCallback(() => {
    const box = trigger.current?.getBoundingClientRect();
    if (box) {
      //below the trigger and left-aligned to it, then clamped so a card at the right edge of the
      //grid does not open its hint off-screen
      setAt({ top: box.bottom + 6, left: Math.min(box.left, window.innerWidth - 296) });
    }
  }, []);

  function toggle(event: React.MouseEvent) {
    //the card behind this is itself a button that applies a filter. Without this, reading why a
    //reason means what it means also filters the page to it
    event.stopPropagation();
    event.preventDefault();
    place();
    setOpen((v) => !v);
  }

  React.useEffect(() => {
    if (!open) {
      return;
    }

    function onKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setOpen(false);
        trigger.current?.focus();
      }
    }
    function onPointerDown(event: PointerEvent) {
      const target = event.target as Node;
      if (!panel.current?.contains(target) && !trigger.current?.contains(target)) {
        setOpen(false);
      }
    }
    //closed rather than followed on scroll or resize: a hint anchored to a control that has moved
    //is a floating box pointing at nothing, and re-measuring on every scroll frame is a cost this
    //does not need to pay
    function onMove() {
      setOpen(false);
    }

    document.addEventListener("keydown", onKeyDown);
    document.addEventListener("pointerdown", onPointerDown);
    window.addEventListener("scroll", onMove, true);
    window.addEventListener("resize", onMove);
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("scroll", onMove, true);
      window.removeEventListener("resize", onMove);
    };
  }, [open]);

  return (
    <>
      <button
        ref={trigger}
        type="button"
        onClick={toggle}
        aria-expanded={open}
        aria-describedby={open ? id : undefined}
        aria-label={`What ${label} means`}
        className={cn(
          "shrink-0 rounded-full p-0.5 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground",
          open && "bg-accent text-foreground",
          className
        )}
      >
        <Info className="h-3.5 w-3.5" />
      </button>
      {open && at && typeof document !== "undefined"
        && createPortal(
          <div
            ref={panel}
            id={id}
            role="tooltip"
            style={{ top: at.top, left: at.left }}
            className="fixed z-[70] w-72 rounded-lg border border-border bg-popover p-3 text-sm text-popover-foreground shadow-lg"
          >
            {children}
          </div>,
          document.body
        )}
    </>
  );
}
