import * as React from "react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

/**
 * The left-hand rail beside a page's content: Pricing, Gateway, Error codes, Filters.
 *
 * <p>Cards rather than one long column of links under uppercase micro-headings. Each card is one
 * kind of thing -- accounts, vendors, sections, statuses -- with its title, what it is and how many
 * on one line, so the groups read as groups. One component so the four rails cannot drift apart
 * again: they had four slightly different active styles.
 *
 * <p>Desktop only. On a phone each page shows a select instead, where a column of cards would push
 * the content a screen down.
 */
export function Rail({ label, className, children }: { label: string; className?: string; children: React.ReactNode }) {
  return (
    <nav aria-label={label} className={cn("hidden flex-[0_0_280px] flex-col gap-3 text-sm lg:sticky lg:top-4 lg:flex", className)}>
      {children}
    </nav>
  );
}

/**
 * One group. `title` is optional: the first card of a rail is often just "where to start" -- an
 * overview, a default -- and needs no heading.
 */
export function RailCard({
  title,
  what,
  count,
  children,
}: {
  title?: string;
  /** What this kind of thing is, in a few words: "what they pay us". */
  what?: string;
  /** How many are listed. Omitted while loading, when a 0 would be a claim. */
  count?: number | null;
  children: React.ReactNode;
}) {
  return (
    <Card className="overflow-hidden">
      {title && (
        <div className="flex items-baseline gap-2 border-b border-border px-3.5 py-2.5">
          <span className="font-medium">{title}</span>
          {what && <span className="text-xs text-muted-foreground">{what}</span>}
          {count != null && <span className="ml-auto text-xs tabular-nums text-muted-foreground">{count}</span>}
        </div>
      )}
      <div className="flex flex-col gap-0.5 p-1.5">{children}</div>
    </Card>
  );
}

/**
 * The classes for one row, a link or a button: the open one on the soft primary tint with its name
 * in primary, the rest quiet until hovered.
 */
export function railItemClass(active: boolean, className?: string): string {
  return cn(
    "flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-left",
    active ? "bg-primary-soft font-semibold text-primary" : "text-foreground hover:bg-muted",
    className
  );
}

/** A line of explanation inside a card, under its rows. */
export function RailNote({ children }: { children: React.ReactNode }) {
  return <p className="px-2.5 py-1.5 text-xs font-normal text-muted-foreground">{children}</p>;
}
