"use client";
import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * An on/off switch: a real `<button role="switch">`, so it is reachable by Tab, toggled by Space,
 * and announced with its state.
 *
 * <p>For a setting that is genuinely two-valued. A setting that can also be "not set" shows the
 * value in effect -- the default when nothing is stored -- and says which it is beside the switch;
 * the third state belongs in words, not in a tri-state control nobody reads correctly.
 */
export function Switch({
  checked,
  onChange,
  disabled,
  id,
  className,
  ...aria
}: {
  checked: boolean;
  onChange: (next: boolean) => void;
  disabled?: boolean;
  id?: string;
  className?: string;
  "aria-label"?: string;
  "aria-labelledby"?: string;
  "aria-describedby"?: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      id={id}
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={cn(
        "relative inline-flex h-[26px] w-11 shrink-0 items-center rounded-full transition-colors",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        "disabled:cursor-not-allowed disabled:opacity-50",
        checked ? "bg-primary" : "bg-slate-300 dark:bg-slate-600",
        className
      )}
      {...aria}
    >
      <span
        aria-hidden="true"
        className={cn(
          "inline-block h-5 w-5 rounded-full bg-white shadow transition-transform",
          checked ? "translate-x-[21px]" : "translate-x-[3px]"
        )}
      />
    </button>
  );
}
