"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { CartesianGrid, Line, LineChart, XAxis, YAxis } from "recharts";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { AccountTypeahead, type AccountOption } from "./AccountTypeahead";
import { CardActions } from "./CardBits";
import { useAccounts } from "./useAccounts";
import { count } from "@/lib/format";
import { KIND, type WorkerType } from "@/lib/worker-types";
import type { QueueHistory } from "@/lib/queue-history";

/** Mirrors `LIVE_WINDOW_MS` / `LIVE_BUCKET_SECONDS` in `lib/metrics-queries.ts`, which is server-only. */
const WINDOW_MS = 15 * 60_000;
const BUCKET_MS = 10_000;
const REFRESH_MS = 10_000;

interface LiveRow {
  t: number;
  key: string;
  mt: number;
  dlr: number;
}

interface Point {
  t: number;
  mt: number;
  dlr: number;
  queued: number | null;
}

const chartConfig = {
  mt: { label: "MT/s", color: "var(--color-chart-2)" },
  dlr: { label: "DLR/s", color: "var(--color-chart-1)" },
  queued: { label: "Queued", color: "var(--color-chart-3)" },
} satisfies ChartConfig;

function clock(t: number): string {
  return new Date(t).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

/**
 * MT, DLR and queued messages over the last fifteen minutes, on the Vendors and Servers pages.
 *
 * <p>Two sources on one time axis. MT and DLR come from the call records, so they cover the whole
 * window the moment the page opens. Queue depth is never stored anywhere -- it exists only in the
 * health snapshot -- so its line is the polls this page has seen (`useHealth`'s `queueHistory`),
 * and it starts where the page was opened rather than pretending to know what came before.
 *
 * <p>Rates on the left axis, a count on the right: MT/s and DLR/s are comparable to the gateway's
 * TPS, a queue is a number of messages, and drawn on one axis a backlog of thousands flattens the
 * two rates into the floor.
 *
 * @param kind vendors chart per vendor (keys are full worker names, as `trafficKey`); servers chart
 *     per account, whose queue cannot be split by account
 * @param vendorKeys every configured vendor's full name, so the picker lists an idle one too
 */
export function LiveTrafficChart({
  kind,
  queueHistory,
  vendorKeys = [],
}: {
  kind: WorkerType;
  queueHistory: QueueHistory;
  vendorKeys?: string[];
}) {
  const isVendor = kind === KIND.vendor;
  const [rows, setRows] = useState<LiveRow[] | null>(null);
  //when the rows were read, taken in the fetch callback: reading the clock during render is impure,
  //and the window's right edge has to move with the data anyway
  const [readAt, setReadAt] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [picked, setPicked] = useState("");

  const load = useCallback(async () => {
    try {
      const res = await fetch(`/api/control/traffic-live?kind=${isVendor ? "vendor" : "server"}`, { cache: "no-store" });
      const body = await res.json();
      if (!res.ok) {
        setError(body?.error ?? `Request failed (${res.status})`);
      } else {
        setError(null);
        setRows(body.data as LiveRow[]);
        setReadAt(Date.now());
      }
    } catch {
      setError("Could not reach the panel's API.");
    }
  }, [isVendor]);

  useEffect(() => {
    let timer: ReturnType<typeof setInterval> | null = null;
    const start = () => {
      void load();
      timer = setInterval(load, REFRESH_MS);
    };
    //a hidden tab polling the call records every ten seconds is load nobody is looking at
    const onVisibility = () => {
      if (document.hidden) {
        if (timer) clearInterval(timer);
        timer = null;
      } else if (!timer) {
        start();
      }
    };
    start();
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      if (timer) clearInterval(timer);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [load]);

  const options = useMemo(() => {
    const keys = new Set(isVendor ? vendorKeys : []);
    for (const r of rows ?? []) {
      keys.add(r.key);
    }
    return [...keys].sort((a, b) => a.localeCompare(b));
  }, [rows, vendorKeys, isVendor]);

  //a queue belongs to a server worker, and several accounts share one -- so with an account picked
  //there is no honest queue figure to draw, and a zero line would claim one
  const queueShown = isVendor || picked === "";

  const points = useMemo<Point[]>(() => {
    //the right edge is the newest thing known -- the last read or the last health poll, whichever
    //came later -- so the queue line is never cut off by a traffic read a few seconds older
    const now = Math.max(readAt, queueHistory.at(-1)?.t ?? 0);
    if (now === 0) {
      return [];
    }
    const first = Math.floor((now - WINDOW_MS) / BUCKET_MS) * BUCKET_MS;
    const byBucket = new Map<number, Point>();
    for (let t = first; t <= now; t += BUCKET_MS) {
      byBucket.set(t, { t, mt: 0, dlr: 0, queued: null });
    }
    for (const r of rows ?? []) {
      if (picked && r.key !== picked) {
        continue;
      }
      const p = byBucket.get(Math.floor(r.t / BUCKET_MS) * BUCKET_MS);
      if (p) {
        p.mt += r.mt;
        p.dlr += r.dlr;
      }
    }
    if (queueShown) {
      const prefix = `${kind}.`;
      for (const sample of queueHistory) {
        const p = byBucket.get(Math.floor(sample.t / BUCKET_MS) * BUCKET_MS);
        if (!p) {
          continue;
        }
        //the latest poll in a bucket wins; polls and buckets are both ten seconds, so this is rare
        p.queued = picked
          ? sample.depth[picked] ?? 0
          : Object.entries(sample.depth).reduce((sum, [name, d]) => (name.startsWith(prefix) ? sum + d : sum), 0);
      }
    }
    return [...byBucket.values()].map((p) => ({
      ...p,
      mt: Math.round((p.mt / (BUCKET_MS / 1000)) * 10) / 10,
      dlr: Math.round((p.dlr / (BUCKET_MS / 1000)) * 10) / 10,
    }));
  }, [rows, readAt, picked, queueHistory, queueShown, kind]);

  //the newest bucket is still filling, so the footer quotes the one before it rather than a rate
  //that reads half of what is really flowing
  const settled = points.length > 1 ? points[points.length - 2] : points[0];
  const lastQueue = [...points].reverse().find((p) => p.queued != null)?.queued ?? null;
  const quiet = rows !== null && !points.some((p) => p.mt > 0 || p.dlr > 0);
  const label = (key: string) => (isVendor ? key.replace(/^smppclient\./, "") : key);

  return (
    <Card>
      <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
        <span className="text-base font-medium">Traffic · last 15 minutes</span>
        <CardActions>
          <div className="flex items-center gap-3 text-xs text-muted-foreground" aria-hidden>
            {(Object.keys(chartConfig) as (keyof typeof chartConfig)[])
              .filter((k) => k !== "queued" || queueShown)
              .map((k) => (
                <span key={k} className="flex items-center gap-1.5">
                  <span className="h-0.5 w-3 rounded" style={{ backgroundColor: chartConfig[k].color }} />
                  {chartConfig[k].label}
                </span>
              ))}
          </div>
          {isVendor ? (
            <select
              value={picked}
              onChange={(e) => setPicked(e.target.value)}
              aria-label="Show one vendor"
              className="h-11 rounded-md border border-border bg-background px-3 text-sm focus:border-primary focus:outline-none md:h-9"
            >
              <option value="">All vendors</option>
              {options.map((k) => (
                <option key={k} value={k}>
                  {label(k)}
                </option>
              ))}
            </select>
          ) : (
            <AccountPicker value={picked} onChange={setPicked} active={options} />
          )}
        </CardActions>
      </CardHeader>
      <CardContent className="pt-3">
        {error ? (
          <div className="flex h-56 items-center justify-center text-sm text-destructive">{error}</div>
        ) : (
          <div className="relative">
            <ChartContainer config={chartConfig} className="h-56 w-full">
              <LineChart data={points} margin={{ top: 8, right: 4, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--color-border)" />
                <XAxis
                  dataKey="t"
                  type="number"
                  scale="time"
                  domain={["dataMin", "dataMax"]}
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                  tickFormatter={(t: number) => clock(t).slice(0, 5)}
                  minTickGap={40}
                />
                <YAxis
                  yAxisId="rate"
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                  width={40}
                  allowDecimals={false}
                />
                {queueShown && (
                  <YAxis
                    yAxisId="queue"
                    orientation="right"
                    tickLine={false}
                    axisLine={false}
                    tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                    width={48}
                    allowDecimals={false}
                  />
                )}
                <ChartTooltip
                  labelFormatter={(t) => clock(Number(t))}
                  content={<ChartTooltipContent indicator="dot" />}
                />
                <Line yAxisId="rate" dataKey="mt" stroke={chartConfig.mt.color} strokeWidth={2} dot={false} isAnimationActive={false} />
                <Line yAxisId="rate" dataKey="dlr" stroke={chartConfig.dlr.color} strokeWidth={2} dot={false} isAnimationActive={false} />
                {queueShown && (
                  <Line
                    yAxisId="queue"
                    dataKey="queued"
                    stroke={chartConfig.queued.color}
                    strokeWidth={2}
                    strokeDasharray="5 3"
                    dot={false}
                    connectNulls={false}
                    isAnimationActive={false}
                  />
                )}
              </LineChart>
            </ChartContainer>
            {quiet && (
              <p className="pointer-events-none absolute inset-x-0 top-1/3 text-center text-sm text-muted-foreground">
                No messages in the last 15 minutes
              </p>
            )}
          </div>
        )}
      </CardContent>
      <CardFooter className="border-t border-border pt-3 text-sm text-muted-foreground">
        <span>
          MT <span className="tabular-nums text-foreground">{settled ? count(settled.mt) : "—"}</span>/s ·
          DLR <span className="tabular-nums text-foreground">{settled ? count(settled.dlr) : "—"}</span>/s
          {queueShown && (
            <>
              {" "}·{" "}
              <span className="tabular-nums text-foreground">{lastQueue == null ? "—" : count(lastQueue)}</span>{" "}
              queued
            </>
          )}
        </span>
        <span className="ml-auto text-xs">
          {queueShown
            ? "Queued counts from when this page was opened; it is not stored anywhere earlier."
            : "Queues belong to a server, not an account, so there is no queue line for one account."}
        </span>
      </CardFooter>
    </Card>
  );
}

/**
 * The Servers chart's account filter: a typeahead over the account catalogue, plus any account that
 * sent in the window without being catalogued -- a chart that could not be narrowed to an account
 * that is visibly sending would be the wrong way round.
 *
 * <p>A component of its own so the catalogue is only fetched on the page that needs it.
 */
function AccountPicker({ value, onChange, active }: { value: string; onChange: (id: string) => void; active: string[] }) {
  const { accounts } = useAccounts();
  const options = useMemo<AccountOption[]>(() => {
    const sending = new Set(active);
    const byId = new Map<string, AccountOption>();
    for (const a of accounts) {
      byId.set(a.id, { id: a.id, label: a.label, note: sending.has(a.id) ? "sending now" : null });
    }
    for (const id of active) {
      if (!byId.has(id)) {
        byId.set(id, { id, note: "sending now" });
      }
    }
    //the ones sending in the window first: they are the ones a live chart is usually asked about
    return [...byId.values()].sort(
      (a, b) => Number(!sending.has(a.id)) - Number(!sending.has(b.id)) || a.id.localeCompare(b.id)
    );
  }, [accounts, active]);
  return <AccountTypeahead value={value} onChange={onChange} options={options} />;
}
