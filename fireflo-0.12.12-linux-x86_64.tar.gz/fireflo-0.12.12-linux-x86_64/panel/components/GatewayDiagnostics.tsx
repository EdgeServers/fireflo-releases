"use client";
import { cn } from "@/lib/utils";

/**
 * How much the gateway says about itself, as one control.
 *
 * <h2>Why this card exists</h2>
 *
 * <p>Answering "why did this customer stop getting delivery receipts" used to mean knowing that
 * `message.trace.mode` exists, that it is global rather than per-instance, that this panel could not
 * set it at all, and that `smsg.cdr.events` is a different key with a different vocabulary. Three
 * names for one idea, and a psql session on a live gateway to reach one of them.
 *
 * <h2>What the level does not touch, and why that is on screen</h2>
 *
 * <p>`smsg.cdr.body` and `print.msgs` store customer message text, phone numbers and bind
 * passwords. No level here switches either on, and the card says so — an operator raising a
 * diagnostic level to chase a receipt must not discover afterwards that they began retaining
 * message content.
 */
const LEVELS = [
  {
    value: "off",
    label: "Off",
    blurb: "Errors only. Nothing about individual messages.",
    cost: "No write volume. Also no way to answer a support question without changing this first.",
  },
  {
    value: "problems",
    label: "Problems",
    blurb:
      "Lifecycle milestones, plus a durable record of anything that did not go as the customer "
      + "asked — a receipt withheld, held, or that failed to send, and callbacks that did not "
      + "succeed.",
    cost: "Near-zero on a healthy gateway: these rows appear when something goes wrong.",
  },
  {
    value: "verbose",
    label: "Verbose",
    blurb: "Every routing decision, submit response and enqueue, and an event row per receipt.",
    cost: "Real log and database volume on a busy gateway. For one customer for one afternoon.",
  },
] as const;

export function GatewayDiagnostics({
  level,
  overrides,
  onChange,
  busy = false,
  unsaved = false,
}: {
  /** The level in effect on this page: a staged one, else the stored `smsg.diagnostics`, else "". */
  level: string;
  /**
   * Keys set explicitly, which therefore beat the level. Shown because a level that appears to be
   * in force while a key quietly outranks it is the one failure this design introduces.
   */
  overrides: { key: string; value: string }[];
  /** Stages a level. "" clears it, so each key goes back to its own default. */
  onChange: (level: string) => void;
  busy?: boolean;
  /** The level shown is staged and not yet saved. */
  unsaved?: boolean;
}) {
  const current = LEVELS.find((l) => l.value === level);

  return (
    <div className="space-y-3">
      <div role="radiogroup" aria-label="Diagnostics level" className="grid gap-2.5 md:grid-cols-3">
        {LEVELS.map((l) => {
          const selected = level === l.value;
          return (
            <button
              key={l.value}
              type="button"
              role="radio"
              aria-checked={selected}
              disabled={busy}
              onClick={() => onChange(l.value)}
              className={cn(
                "flex flex-col gap-1 rounded-lg border p-3 text-left transition-colors",
                "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                selected
                  ? "border-primary bg-primary-soft/50 ring-1 ring-primary"
                  : "border-border bg-card hover:border-muted-foreground/40"
              )}
            >
              <span className="flex flex-wrap items-center gap-2 font-semibold">
                {l.label}
                {l.value === "problems" && (
                  <span className="rounded-full bg-primary-soft px-2 py-px text-2xs font-semibold text-primary">
                    Recommended
                  </span>
                )}
              </span>
              <span className="text-sm text-muted-foreground">{l.blurb}</span>
              <span className="text-xs text-muted-foreground">{l.cost}</span>
            </button>
          );
        })}
      </div>

      <p className="flex flex-wrap items-center gap-x-2 gap-y-1 text-sm text-muted-foreground">
        {current ? (
          <>
            <span>
              {unsaved ? "Unsaved. " : ""}The level supplies the default for{" "}
              <code className="font-mono">message.trace.mode</code> and{" "}
              <code className="font-mono">smsg.cdr.events</code>.
            </span>
            <button type="button" className="text-primary hover:underline" disabled={busy} onClick={() => onChange("")}>
              Clear the level
            </button>
          </>
        ) : (
          <span>
            {unsaved ? "Unsaved. " : ""}No level is set, so each key keeps its own default. Choosing one
            sets the default for <code className="font-mono">message.trace.mode</code> and{" "}
            <code className="font-mono">smsg.cdr.events</code>.
          </span>
        )}
      </p>

      {/* the failure this design introduces: a level that reads as in force while a key outranks
          it. Saying which key, rather than only that one exists, is what makes it actionable */}
      {overrides.length > 0 && (
        <p className="rounded-md border border-amber-500/40 bg-amber-500/5 px-3 py-2 text-sm">
          {overrides.length === 1 ? "One key is" : `${overrides.length} keys are`} set explicitly and
          therefore {overrides.length === 1 ? "overrides" : "override"} the level:{" "}
          {overrides.map((o, i) => (
            <span key={o.key}>
              {i > 0 && ", "}
              <code className="font-mono">{o.key}</code> = {o.value || "(empty)"}
            </span>
          ))}
          . Clear {overrides.length === 1 ? "it" : "them"} to let the level decide.
        </p>
      )}

      {level === "verbose" && (
        <p className="rounded-md border border-amber-500/40 bg-amber-500/5 px-3 py-2 text-sm">
          Verbose logs every routing decision and writes an event row per receipt. Put it back to{" "}
          <strong>Problems</strong> once you have what you came for.
        </p>
      )}

      <p className="text-xs text-muted-foreground">
        Message content is <strong>not</strong> part of this.{" "}
        <code className="font-mono">smsg.cdr.body</code> and{" "}
        <code className="font-mono">print.msgs</code> store message text, destination numbers and
        bind passwords, and no level here switches either on.
      </p>
    </div>
  );
}
