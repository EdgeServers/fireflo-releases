"use client";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { signOut, useSession } from "next-auth/react";
import { ChangePasswordDialog } from "@/components/ChangePasswordDialog";
import { isAdminSession } from "@/lib/roles";
import {
  Activity, Antenna, ChartColumn, Coins, Cpu, FileText, Filter, KeyRound, Languages, Layers, ListTree, LogOut,
  MailCheck, Server, Shield, Signature, ShieldX, Stethoscope, Tags, Users, Wallet, X,
  ScrollText, SlidersHorizontal, type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { APP_VERSION, FireFloMark } from "./FireFloMark";
import { NavGroupHeading, NavLink } from "./NavRail";
import { ThemeToggle } from "./ThemeToggle";

/**
 * Where the operator panel lives.
 *
 * <p>One constant for the overview's href and for the active-state special case below, because the
 * two only work if they agree: the rule is "the href that prefixes every other one is matched
 * exactly", and it stops being true the moment either is edited alone.
 *
 * <p>The customer portal has the root. This panel is the deliberate destination.
 */
const CP_ROOT = "/cp";

interface SidebarProps {
  /** Present only in the mobile drawer, where the sidebar needs its own dismiss. */
  onClose?: () => void;
  /** Icon-only rail. Never true in the drawer — a drawer you opened on purpose should show names. */
  collapsed?: boolean;
}

/**
 * The nav: Overview on its own, then four groups — what carries traffic, what shapes it, what it is
 * allowed to be, and what it did.
 *
 * <p><strong>Not everything with a page gets a row.</strong> Routing and Products are reached from
 * the page they belong to — Routing from Vendors, because a routing table's only job is choosing
 * which vendor a message goes to; Products from Servers, because a product is what a customer's
 * bind asks for by `system_type`. Both still answer by URL. A nav that lists every page is a nav
 * nobody reads, and these two were only ever opened on the way to or from the page above them.
 *
 * <p>Live health and Runtime are absent for the same reason, one step further: health moved into
 * the header because it is wanted from wherever you already are.
 *
 * <p>Messages leads the Gateway group and Queues sits with the reports, which is a swap of where
 * both used to be. The order follows how often a page is opened rather than how the data is
 * arranged: "what is my traffic doing" is the first question of most days, and a queue is only
 * looked at once Messages and Refused have both come up empty.
 */
interface NavItem {
  href: string;
  label: string;
  icon: LucideIcon;
  /** Shown to admins only. The route and its API refuse everyone else regardless. */
  adminOnly?: boolean;
}

const gatewayLinks: NavItem[] = [
  //first, because it is the page an operator opens most: "what is my traffic doing" is asked far
  //more often than any question about how the gateway is configured
  { href: "/cp/cdrs", label: "Messages", icon: ListTree },
  { href: "/cp/vendors", label: "Vendors", icon: Antenna },
  { href: "/cp/servers", label: "Servers", icon: Server },
  { href: "/cp/accounts", label: "Accounts", icon: Users },
  { href: "/cp/pricing", label: "Pricing", icon: Coins },
  //a row rather than a header icon, unlike Live health: this is read rather than glanced at, and it
  //is where you go when a page says the gateway is ignoring something and you want to see what it
  //is reading instead.
  //
  //Labelled "Logs" rather than "Diagnostics" because the log pane is what anybody opens it for. The
  //route stays /cp/diagnostics so no bookmark or documentation link breaks, and the page keeps its
  //other two cards -- knowingly, since the row no longer names them. Worth its own slice later.
  { href: "/cp/diagnostics", label: "Logs", icon: Stethoscope },
  //last in the group: it is the page you open when something is already wrong, not part of the
  //daily read. Under Gateway rather than Configuration because refusals are traffic, not settings
  { href: "/cp/security", label: "Security", icon: Shield },
];

/** The reusable pieces rules are built from, rather than rules themselves. */
const configurationLinks: NavItem[] = [
  //first in the group because it sits above everything else in it: these are the values a vendor or
  //listener inherits when it has none of its own, plus the REST ingress's own settings. Filed here
  //rather than under Gateway because it is configuration you write, not traffic you read
  { href: "/cp/gateway", label: "Gateway", icon: SlidersHorizontal },
  //directly under Gateway because it is the same shape of question -- a value every vendor inherits
  //unless it sets its own -- and its global tier is literally an `outSms.default.*` key
  { href: "/cp/error-codes", label: "Error codes", icon: Languages },
  { href: "/cp/filters", label: "Filters", icon: Filter },
  //beside Filters because they work as a pair: a filter picks the messages, a preprocessor is the
  //program a routing rule hands them to
  { href: "/cp/preprocessors", label: "Preprocessors", icon: Cpu },
  { href: "/cp/tlvs", label: "TLVs", icon: Tags },
];

/**
 * Approvals rather than plumbing: what a customer is permitted to send. The only catalogues here
 * that can refuse traffic, which is what keeps them out of Configurations.
 */
const assetLinks: NavItem[] = [
  { href: "/cp/assets/headers", label: "Headers", icon: Signature },
  { href: "/cp/assets/templates", label: "Templates", icon: FileText },
];

/** What already happened. Read, never written. */
const reportLinks: NavItem[] = [
  //a refusal is something that happened to traffic, and the question "why is nothing arriving"
  //starts here when Messages is empty
  { href: "/cp/rejected", label: "Refused", icon: ShieldX },
  //who signed in and who was refused, both doors. A report rather than a tab on Users, because it
  //is read far more often than users are changed
  { href: "/cp/access-log", label: "Access log", icon: ScrollText },
  //what is queued has not happened yet, so this is the exception in a group of things that have.
  //It sits here because the question it answers -- "accepted, but where is it?" -- is asked
  //immediately after Messages and Refused have both come up empty
  { href: "/cp/queues", label: "Queues", icon: Layers },
  //a report about the vendors rather than about the traffic: whether each one tells us what
  //happened, and how long it takes. It belongs here and not on Vendors because the only useful
  //reading is the comparison -- one vendor's reporting rate means nothing on its own
  { href: "/cp/receipts", label: "Receipts", icon: MailCheck },
  //volume and delivery, where Revenue below it is the same traffic counted in money. Usage leads
  //because "is it landing" is asked far more often than "what did it earn", and the answer to the
  //second is not worth reading until the first is healthy
  { href: "/cp/usage", label: "Usage", icon: ChartColumn },
  { href: "/cp/revenue", label: "Revenue", icon: Wallet },
];

/**
 * The dashboard, which belongs to no group.
 *
 * <p>Above the headings rather than inside one: it is the home page, and every group below it
 * answers a narrower question than it does. Filing it under Gateway made it read as one operational
 * page among several rather than the place you land.
 */
const overviewLink = { href: CP_ROOT, label: "Overview", icon: Activity };

/** Ordered by how often an operator needs them, not by how the data is arranged. */
const GROUPS = [
  { label: "Gateway", links: gatewayLinks },
  { label: "Configuration", links: configurationLinks },
  { label: "Assets", links: assetLinks },
  { label: "Reports", links: reportLinks },
];

/**
 * Which row is lit.
 *
 * <p>The special case is not about the string "/cp" — it is about the ONE href that is a prefix of
 * every other one. When the panel lived at the root that was "/"; without moving the case with it,
 * `startsWith("/cp")` matches every operator route and Overview stays lit alongside whichever page
 * is really open — two rows highlighted, two `aria-current="page"` for a screen reader.
 *
 * <p>Prefix everywhere else, so a detail page keeps its section lit. The portal matches exactly
 * instead, which is why `NavRail` takes this as a boolean rather than deciding it.
 */
function isActive(href: string, pathname: string): boolean {
  return href === CP_ROOT ? pathname === CP_ROOT : pathname.startsWith(href);
}

export function Sidebar({ onClose, collapsed = false }: SidebarProps) {
  const pathname = usePathname();
  const { data: session } = useSession();
  const operator = session?.user?.name ?? "";
  const role = session?.user?.role ?? null;
  const admin = isAdminSession(session);
  const [changingPassword, setChangingPassword] = useState(false);

  return (
    <aside
      className={cn(
        "flex h-full flex-col border-r border-border bg-card transition-[width] duration-200",
        //220px, the sample's rail, which the longest label ("Configuration", 96px) clears with room
        //to spare. Was 13rem, sized to the longest label rather than to habit -- 208px at the default
        //root. This used to warn that the app's root was 18px and so the real width was 234px; the
        //root override is gone, so rem and the Tailwind scale finally agree and the arithmetic is
        //the obvious one again. Down from 16rem.
        //
        //"Configuration" is the widest entry at 96px, and after the icon, the gap and both paddings
        //there are 148px of room for it. Every label clears it with room to spare, so nothing
        //truncates; the rest was empty card. The tables are what the panel is for, and each pixel
        //spent here is one they do not get.
        //
        //The same value sizes the mobile drawer, which is the other reason not to go back up: at
        //375px the old width covered three quarters of the screen.
        collapsed ? "w-16" : "w-[220px]"
      )}
    >
      {/* the brand row: mark, name, and the version as a small pill at the right edge -- the place
          the sample puts its plan badge. The operator moved to the footer, with the sign-out */}
      <div
        className={cn(
          "flex h-[52px] items-center border-b border-border",
          collapsed ? "justify-center px-0" : "justify-between px-3"
        )}
      >
        {collapsed ? (
          <FireFloMark className="h-5 w-5" />
        ) : (
          <div className="flex min-w-0 flex-1 items-center gap-2 px-2">
            <FireFloMark className="h-5 w-5" />
            <span className="truncate text-sm font-bold tracking-tight">FireFlo</span>
            {APP_VERSION && (
              <span className="ml-auto rounded-full bg-primary-soft px-1.5 py-0.5 text-2xs font-semibold tabular-nums text-primary">
                {APP_VERSION}
              </span>
            )}
          </div>
        )}
        {onClose && (
          <button
            onClick={onClose}
            className="-mr-1.5 shrink-0 rounded-md p-3 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground md:hidden"
            aria-label="Close menu"
          >
            <X className="h-5 w-5" />
          </button>
        )}
      </div>

      <nav className={cn("flex-1 overflow-y-auto py-2", collapsed ? "px-2" : "px-3")}>
        <div className="space-y-0.5">
          <NavLink
            {...overviewLink}
            collapsed={collapsed}
            active={isActive(overviewLink.href, pathname)}
          />
        </div>
        {GROUPS.map((group) => (
          <div key={group.label} className="mt-3 space-y-0.5">
            <NavGroupHeading label={group.label} collapsed={collapsed} />
            {group.links.filter((link) => admin || !link.adminOnly).map((link) => (
              <NavLink
                key={link.href}
                {...link}
                collapsed={collapsed}
                active={isActive(link.href, pathname)}
              />
            ))}
          </div>
        ))}
      </nav>

      <div className={cn("border-t border-border py-3", collapsed ? "px-2" : "px-3")}>
        {/* who is signed in: initials on the soft accent, name, role -- the sample's footer block */}
        {!collapsed && operator && (
          <div className="mb-2 flex items-center gap-2 px-1">
            <span className="grid h-[26px] w-[26px] shrink-0 place-items-center rounded-full bg-primary-soft text-2xs font-bold text-primary">
              {initials(operator)}
            </span>
            <div className="min-w-0 leading-tight">
              <p className="truncate text-xs font-semibold">{operator}</p>
              <p className="text-2xs capitalize text-muted-foreground">{role ?? "operator"}</p>
            </div>
          </div>
        )}
        <div className={cn("flex items-center gap-1", collapsed ? "flex-col" : "justify-between")}>
          <ThemeToggle />
          <button
            onClick={() => setChangingPassword(true)}
            title="Change password"
            aria-label="Change password"
            className={cn(
              "flex items-center rounded-md text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground",
              collapsed ? "h-8 w-8 justify-center" : "h-8 w-8 justify-center"
            )}
          >
            <KeyRound className="h-4 w-4" />
          </button>
          <button
            onClick={() => signOut({ callbackUrl: "/cp/login" })}
            title={collapsed ? "Sign out" : undefined}
            aria-label={collapsed ? "Sign out" : undefined}
            className={cn(
              "flex items-center whitespace-nowrap rounded-md text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground",
              //px-2, not px-3: the key icon beside it took the room the wider padding needed
              collapsed ? "h-8 w-8 justify-center" : "h-11 gap-2 px-2 md:h-8"
            )}
          >
            <LogOut className="h-4 w-4" />
            {!collapsed && "Sign out"}
          </button>
        </div>
      </div>

      <ChangePasswordDialog email={operator} open={changingPassword} onClose={() => setChangingPassword(false)} />
    </aside>
  );
}

/** "ops@example.com" → "OP", "Jane Doe" → "JD": the two letters that stand for a person in a circle. */
function initials(name: string): string {
  const local = name.split("@")[0] ?? name;
  const parts = local.split(/[\s._-]+/).filter(Boolean);
  const letters = parts.length >= 2 ? parts[0][0] + parts[1][0] : local.slice(0, 2);
  return letters.toUpperCase();
}
