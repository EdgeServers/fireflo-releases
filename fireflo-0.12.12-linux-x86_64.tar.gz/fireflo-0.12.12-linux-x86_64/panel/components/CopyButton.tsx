"use client";
import { useEffect, useState } from "react";
import { Check, Copy } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Copies a string, and says that it did.
 *
 * <p>The confirmation is the whole component. `navigator.clipboard.writeText` succeeds silently, so
 * without a visible change the only way to know whether a click registered is to paste somewhere and
 * look — which people do, and then click twice more.
 *
 * <p>Falls back to nothing rather than to a hidden textarea and `execCommand`. The clipboard API
 * needs a secure context, and a panel served over plain HTTP has bigger problems than a copy button;
 * the code is on screen and selectable either way.
 */
export function CopyButton({
  value,
  className,
  label = "Copy",
}: {
  value: string;
  className?: string;
  /** What is being copied, for the accessible name — "Copy request", "Copy your login". */
  label?: string;
}) {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!copied) {
      return;
    }
    const timer = setTimeout(() => setCopied(false), 1_600);
    return () => clearTimeout(timer);
  }, [copied]);

  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(value);
          setCopied(true);
        } catch {
          //no clipboard, no confirmation. Saying "copied" when nothing was is worse than saying
          //nothing, because the paste that follows is somebody else's text
          setCopied(false);
        }
      }}
      className={cn(
        "inline-flex items-center gap-1 rounded px-1.5 py-1 text-xs transition-colors",
        copied
          ? "text-emerald-600 dark:text-emerald-400"
          : "text-muted-foreground hover:bg-accent hover:text-foreground",
        className
      )}
    >
      {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
      {copied ? "Copied" : null}
    </button>
  );
}
