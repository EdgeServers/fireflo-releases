"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";

/**
 * An action that asks first, in the page rather than in a browser dialog.
 *
 * <p>Replaces `window.confirm`. Three reasons that was the wrong control: it is unstyled and
 * unthemed, so it looks like the page has been hijacked; browsers suppress it in some contexts and
 * the click then does nothing at all, silently; and it renders one line of plain text, which is not
 * enough room to say what deleting a vendor actually costs.
 *
 * <p>The idle state is a <strong>ghost</strong> button, not a solid red one. A permanent red button
 * in every card header competes for attention with the thing that should be loudest on the page,
 * which is a vendor that has actually stopped working. It turns red once armed, where the colour is
 * about the decision in front of you rather than decoration.
 *
 * <p>{@link tone} exists because not everything worth confirming is destructive, and colouring an
 * additive bulk write in the same red as a delete teaches operators to read red as "a dialog
 * appeared" rather than as "something is about to be lost".
 */
export function DangerAction({
  label,
  confirmLabel,
  consequence,
  extra,
  busy,
  tone = "destructive",
  disabled,
  onConfirm,
}: {
  /** What the idle button says, and its accessible name. */
  label: string;
  /** What the armed button says — a verb plus its object, never a bare "OK". */
  confirmLabel: string;
  /** What is lost, or what is about to happen. Shown only once armed, where it will be read. */
  consequence: string;
  /**
   * An option that belongs to the decision, shown between the consequence and the confirm button.
   *
   * <p>For a choice that changes what confirming means — not for more explanation, which belongs in
   * `consequence`. It renders only while armed, so nothing here can be set without the sentence
   * above it having been on screen.
   */
  extra?: React.ReactNode;
  busy?: boolean;
  /**
   * Not yet answerable — an incomplete form, a row still loading.
   *
   * <p>Separate from `busy` on purpose: busy says "this is happening and says so", disabled says
   * "there is nothing to confirm yet". Sharing one flag would put "Working…" on a button whose form
   * is merely half-filled.
   */
  disabled?: boolean;
  /**
   * `destructive` (the default) for anything that loses data or stops traffic. `caution` for a
   * change that is surprising, bulk, or hard to reverse by hand but takes nothing away — the amber
   * of `Confirm`, so the two read as the same class of decision.
   */
  tone?: "destructive" | "caution";
  onConfirm: () => void;
  }) {
  const [armed, setArmed] = useState(false);
  const danger = tone === "destructive";

  if (!armed) {
    return (
      <Button
        variant="ghost"
        size="sm"
        aria-label={label}
        disabled={busy || disabled}
        className={
          danger
            ? "text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
            : "text-muted-foreground hover:bg-amber-500/10 hover:text-amber-600 dark:hover:text-amber-400"
        }
        onClick={() => setArmed(true)}
      >
        {label}
      </Button>
    );
  }

  return (
    <span
      className={
        "flex flex-wrap items-center gap-2 rounded-md border px-2 py-1 "
        + (danger ? "border-destructive/40 bg-destructive/5" : "border-amber-500/40 bg-amber-500/5")
      }
    >
      <span
        className={
          "text-sm " + (danger ? "text-destructive" : "text-amber-700 dark:text-amber-400")
        }
      >
        {consequence}
      </span>
      {extra}
      <Button
        variant={danger ? "destructive" : "default"}
        size="sm"
        disabled={busy || disabled}
        //deliberately stays armed: the parent unmounts this whole card on success, and on failure
        //the confirm row must remain so the error beside it has something to belong to
        onClick={onConfirm}
      >
        {busy ? "Working…" : confirmLabel}
      </Button>
      <Button variant="ghost" size="sm" disabled={busy} onClick={() => setArmed(false)}>
        Cancel
      </Button>
    </span>
  );
}
