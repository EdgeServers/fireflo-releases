"use client";
import { useCallback, useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Segmented } from "@/components/ui/segmented";
import { cn } from "@/lib/utils";
import {
  BROKER_DEFAULTS,
  type BrokerForm,
  type BrokerProvider,
  type BrokerView,
  brokerProblem,
  buildAmqpUri,
} from "@/lib/broker-config";

/** What the gateway's /ops/queue/test answers. */
interface BrokerTestReport {
  connected: boolean;
  detail?: string;
  steps: { name: string; ok?: boolean; ms: number; detail?: string }[];
}

const PROVIDERS = [
  { value: "memory", label: "In-process only", title: "REST submissions go straight to the router queue" },
  { value: "rabbitmq", label: "RabbitMQ", title: "REST submissions wait on a RabbitMQ queue" },
] as const;

/**
 * The broker's settings on the Queues page: what is saved, and for an admin, an editor with a test.
 *
 * <p>The password never comes to the browser. The form says whether one is stored, and sends a new
 * one only when it is being changed; the server builds the URI, for saving and for testing alike.
 *
 * <p>The gateway connects to the broker once, at startup. A save is therefore not in force until a
 * restart, which `restartNeeded` -- read from the gateway, not guessed here -- says.
 */
export function BrokerSettings({ restartNeeded, onSaved }: { restartNeeded: boolean; onSaved: () => void }) {
  const [view, setView] = useState<(BrokerView & { canEdit: boolean }) | null>(null);
  const [unavailable, setUnavailable] = useState<string | null>(null);
  const [form, setForm] = useState<BrokerForm | null>(null);
  const [changingPassword, setChangingPassword] = useState(false);
  const [testing, setTesting] = useState(false);
  const [report, setReport] = useState<BrokerTestReport | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  //set by a save: the gateway reads app_config on its next poll, seconds away, and until then
  //restartNeeded still says no -- so the note shows from the save rather than from the poll
  const [justSaved, setJustSaved] = useState(false);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/control/queues/broker", { cache: "no-store" });
      const body = await res.json();
      if (!res.ok) {
        setUnavailable(body?.error ?? "Could not read the broker settings.");
      } else if (!body.data) {
        setUnavailable(body.reason ?? "The broker settings cannot be read here.");
      } else {
        setView(body.data);
      }
    } catch {
      setUnavailable("Could not reach the panel's API.");
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (unavailable) {
    return <p className="text-sm text-muted-foreground">{unavailable}</p>;
  }
  if (!view) {
    return null;
  }

  function edit() {
    setForm({ ...view!.form, password: null });
    setChangingPassword(!view!.passwordSet);
    setReport(null);
    setError(null);
  }

  function set<K extends keyof BrokerForm>(key: K, value: BrokerForm[K]) {
    setForm((f) => (f ? { ...f, [key]: value } : f));
    //a result describes the settings it was run with; once they change it describes nothing
    setReport(null);
  }

  if (!form) {
    const saved = view.form;
    return (
      <div className="space-y-2">
        <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 rounded-md border border-border px-3 py-2 text-sm">
          <dt className="text-muted-foreground">Queued on</dt>
          <dd>{saved.provider === "rabbitmq" ? "RabbitMQ" : "In process only"}</dd>
          {saved.provider === "rabbitmq" && (
            <>
              <dt className="text-muted-foreground">Address</dt>
              <dd className="break-all font-mono">{displayUri(saved, view.passwordSet)}</dd>
              <dt className="text-muted-foreground">Queue</dt>
              <dd className="font-mono">{saved.queue || BROKER_DEFAULTS.queue}</dd>
            </>
          )}
        </dl>
        {(restartNeeded || justSaved) && (
          <p className="text-sm text-amber-600 dark:text-amber-400">
            These are the saved settings. The gateway connects to the broker when it starts, so they
            apply at its next restart; until then it runs on the ones it started with.
          </p>
        )}
        {view.canEdit && (
          <Button type="button" variant="outline" size="sm" onClick={edit}>
            Edit broker
          </Button>
        )}
      </div>
    );
  }

  const problem = brokerProblem(
    changingPassword ? form : { ...form, password: null },
    view.passwordSet && !changingPassword
  );
  const sent: BrokerForm = { ...form, password: changingPassword ? form.password ?? "" : null };

  async function test() {
    setTesting(true);
    setError(null);
    setReport(null);
    try {
      const res = await fetch("/api/control/queues/broker/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(sent),
      });
      const body = await res.json();
      if (!res.ok) {
        setError(body?.error ?? `The test could not run (${res.status}).`);
      } else {
        setReport(body.data as BrokerTestReport);
      }
    } catch {
      setError("Could not reach the panel's API.");
    } finally {
      setTesting(false);
    }
  }

  async function save() {
    setSaving(true);
    setError(null);
    try {
      const res = await fetch("/api/control/queues/broker", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(sent),
      });
      const body = await res.json();
      if (!res.ok) {
        setError(body?.error ?? `Could not save (${res.status}).`);
        return;
      }
      setForm(null);
      setJustSaved(true);
      await load();
      onSaved();
    } catch {
      setError("Could not reach the panel's API.");
    } finally {
      setSaving(false);
    }
  }

  const rabbit = form.provider === "rabbitmq";

  return (
    <div className="space-y-4">
      <div className="space-y-1.5">
        <span className="block text-xs font-semibold">Queue REST submissions on</span>
        <Segmented<BrokerProvider>
          label="Queue REST submissions on"
          options={PROVIDERS}
          value={form.provider}
          onChange={(v) => set("provider", v)}
        />
        <p className="text-xs text-muted-foreground">
          SMPP always queues in process, so a broker outage never stops SMPP.
          {!rabbit && " The broker address below is kept, so switching back does not lose it."}
        </p>
      </div>

      {rabbit && (
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Host" htmlFor="broker-host">
            <Input id="broker-host" value={form.host} onChange={(e) => set("host", e.target.value)} placeholder="rabbit.internal" />
          </Field>
          <Field label="Port" htmlFor="broker-port" hint={`Blank is ${form.tls ? "5671" : "5672"}.`}>
            <Input id="broker-port" inputMode="numeric" value={form.port} onChange={(e) => set("port", e.target.value)} placeholder={form.tls ? "5671" : "5672"} />
          </Field>
          <Field
            label="Virtual host"
            htmlFor="broker-vhost"
            hint={<>As <code>rabbitmqctl list_vhosts</code> prints it. <code>/fireflo</code> and <code>fireflo</code> are different vhosts.</>}
          >
            <Input id="broker-vhost" value={form.vhost} onChange={(e) => set("vhost", e.target.value)} placeholder="/" />
          </Field>
          <Field label="Queue" htmlFor="broker-queue" hint="Created by the gateway when it starts, if it does not exist.">
            <Input id="broker-queue" value={form.queue} onChange={(e) => set("queue", e.target.value)} placeholder={BROKER_DEFAULTS.queue} />
          </Field>
          <Field label="User name" htmlFor="broker-user">
            <Input id="broker-user" autoComplete="off" value={form.user} onChange={(e) => set("user", e.target.value)} placeholder="fireflo" />
          </Field>
          <Field label="Password" htmlFor="broker-password">
            {changingPassword ? (
              <div className="flex gap-2">
                <Input
                  id="broker-password"
                  type="password"
                  autoComplete="new-password"
                  value={form.password ?? ""}
                  onChange={(e) => set("password", e.target.value)}
                />
                {view.passwordSet && (
                  <Button type="button" variant="ghost" size="sm" onClick={() => { setChangingPassword(false); set("password", null); }}>
                    Keep stored
                  </Button>
                )}
              </div>
            ) : (
              <div className="flex gap-2">
                <span className="flex-1 rounded-md border border-dashed border-input px-3 py-2 text-sm text-muted-foreground">
                  Keep the stored password
                </span>
                <Button type="button" variant="outline" size="sm" onClick={() => { setChangingPassword(true); set("password", ""); }}>
                  Change
                </Button>
              </div>
            )}
          </Field>
          <label className="flex items-center gap-2 text-sm sm:col-span-2">
            <Checkbox checked={form.tls} onChange={(e) => set("tls", e.target.checked)} />
            Connect over TLS (amqps)
          </label>
          <div className="sm:col-span-2">
            <span className="mb-1.5 block text-xs font-semibold">Address the gateway will use</span>
            <p className="break-all rounded-md bg-muted px-3 py-2 font-mono text-sm">
              {displayUri(form, changingPassword ? Boolean(form.password) : view.passwordSet)}
            </p>
          </div>
          <details className="rounded-md border border-border px-3 py-2 sm:col-span-2">
            <summary className="cursor-pointer text-sm font-medium">Tuning</summary>
            <div className="mt-3 grid gap-4 sm:grid-cols-2">
              <Field label="Prefetch" htmlFor="broker-prefetch" hint="Messages the consumer holds unacknowledged.">
                <Input id="broker-prefetch" inputMode="numeric" value={form.prefetch} onChange={(e) => set("prefetch", e.target.value)} placeholder={BROKER_DEFAULTS.prefetch} />
              </Field>
              <Field label="Publish channels" htmlFor="broker-channels">
                <Input id="broker-channels" inputMode="numeric" value={form.channels} onChange={(e) => set("channels", e.target.value)} placeholder={BROKER_DEFAULTS.channels} />
              </Field>
              <Field label="High-water mark" htmlFor="broker-highwater" hint="The consumer pauses while the router queue holds more than this. Applies without a restart.">
                <Input id="broker-highwater" inputMode="numeric" value={form.highwater} onChange={(e) => set("highwater", e.target.value)} placeholder={BROKER_DEFAULTS.highwater} />
              </Field>
              <Field label="Publish confirm timeout" htmlFor="broker-confirm" hint="Milliseconds. Applies without a restart.">
                <Input id="broker-confirm" inputMode="numeric" value={form.confirmMs} onChange={(e) => set("confirmMs", e.target.value)} placeholder={BROKER_DEFAULTS.confirmMs} />
              </Field>
            </div>
          </details>
        </div>
      )}

      {report && <TestResult report={report} />}
      {(error || problem) && <p className="text-sm text-destructive">{error ?? problem}</p>}

      <div className="flex flex-wrap items-center gap-2 border-t border-border pt-3">
        {rabbit && (
          <Button type="button" variant="outline" size="sm" disabled={testing || !!problem} onClick={test}>
            {testing && <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />}
            Test connection
          </Button>
        )}
        <span className="flex-1" />
        <Button type="button" variant="ghost" size="sm" disabled={saving} onClick={() => setForm(null)}>
          Cancel
        </Button>
        <Button type="button" size="sm" disabled={saving || !!problem} onClick={save}>
          {saving && <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />}
          Save
        </Button>
      </div>
      <p className="text-xs text-muted-foreground">
        The test runs from the gateway with what is in this form, saved or not, and changes nothing on
        the broker. Saving after a failed test is allowed: a broker down for maintenance is still the
        right address. Saved settings apply when the gateway next restarts.
      </p>
    </div>
  );
}

function TestResult({ report }: { report: BrokerTestReport }) {
  const total = report.steps.reduce((sum, s) => sum + s.ms, 0);
  return (
    <div className="overflow-hidden rounded-md border border-border text-sm">
      <div className={cn("flex items-center gap-2 bg-muted px-3 py-2 font-medium", report.connected ? "text-green-700 dark:text-green-400" : "text-destructive")}>
        {report.connected ? `✓ Connected from the gateway in ${total} ms` : `✕ ${report.detail ?? "Could not connect from the gateway"}`}
      </div>
      {report.steps.map((step) => (
        <div key={step.name} className="grid grid-cols-[1.25rem_1fr_auto] gap-2 border-t border-border px-3 py-1.5">
          <span className={step.ok === true ? "text-green-700 dark:text-green-400" : step.ok === false ? "text-destructive" : "text-muted-foreground"}>
            {step.ok === true ? "✓" : step.ok === false ? "✕" : "–"}
          </span>
          <span className={cn(step.ok === undefined && "text-muted-foreground")}>
            {step.name}
            {step.ok === undefined && " — not checked"}
            {step.detail && <span className="block text-xs text-muted-foreground">{step.detail}</span>}
          </span>
          <span className="font-mono text-xs text-muted-foreground">{step.ok !== undefined ? `${step.ms} ms` : ""}</span>
        </div>
      ))}
    </div>
  );
}

/** The URI as the form describes it, with a dot mask where a password is or will be. */
function displayUri(form: BrokerForm, hasPassword: boolean): string {
  if (!form.host.trim()) {
    return "(no host yet)";
  }
  return buildAmqpUri({
    tls: form.tls,
    host: form.host.trim(),
    port: form.port.trim(),
    vhost: form.vhost,
    user: form.user.trim(),
    password: form.user.trim() && hasPassword ? "PASSWORD" : "",
  }).replace(":PASSWORD@", ":••••@");
}
