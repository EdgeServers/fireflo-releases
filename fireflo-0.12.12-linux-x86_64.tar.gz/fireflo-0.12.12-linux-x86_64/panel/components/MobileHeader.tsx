"use client";
import { Menu } from "lucide-react";
import { HealthLink } from "./HealthLink";
import { ThemeToggle } from "./ThemeToggle";
import { FireFloMark } from "./FireFloMark";

interface MobileHeaderProps {
  onMenuClick: () => void;
}

export function MobileHeader({ onMenuClick }: MobileHeaderProps) {
  return (
    <header className="flex items-center justify-between border-b border-border bg-card px-4 py-3 md:hidden">
      <button
        onClick={onMenuClick}
        //-ml-1.5 keeps the icon optically aligned with the content below while the padding grows:
        //this is the most-tapped control on a phone and 41px was under the 44 a thumb needs
        className="-ml-1.5 rounded-md p-3 text-muted-foreground hover:bg-accent hover:text-foreground transition-colors"
        aria-label="Open menu"
      >
        <Menu className="h-5 w-5" />
      </button>

      {/* the brand, not the page name: the page's own heading is directly below, and the bar
          naming it too was the same title twice */}
      <div className="flex items-center gap-1.5">
        <FireFloMark className="h-5 w-5" />
        <span className="text-sm font-semibold tracking-tight">FireFlo</span>
      </div>

      <div className="flex items-center gap-1">
        <HealthLink />
        <ThemeToggle />
      </div>
    </header>
  );
}
