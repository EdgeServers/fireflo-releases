"use client";
import { useState } from "react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { ErrorCard, ErrorNote } from "./FormNotices";
import { RangePicker } from "./RangePicker";
import { useControlData, type Range } from "./useControlData";
import { count, money, percent } from "@/lib/format";
import { formatTimestamp } from "@/lib/datetime";
import { accountHref, surface } from "@/lib/panel-surface";
import { EmptyState } from "@/components/ui/empty-state";
import { Table, TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";

interface AccountRow {
  accountId: string | null;
  systemId: string | null;
  product: string | null;
  messages: number;
  delivered: number;
  failed: number;
  pending: number;
  billed: number;
  cost: number;
  deliveryRate: number | null;
  lastSeen: string | null;
  balance: number | null;
  currency: string | null;
  idle: boolean;
}

interface AccountsView {
  creditEnforced: boolean;
  accounts: AccountRow[];
}


/**
 * An account id from traffic, as a way into the account.
 *
 * <p>Null is a real value here and not a gap in the data: a login with no account field bills by its
 * system id, and traffic that predates the account being set has nothing to point at. Those stay
 * plain text rather than linking to a page for an account that does not exist.
 */
function AccountLink({ id }: { id: string | null }) {
  if (!id) {
    return <>—</>;
  }
  return (
    <Link href={accountHref(id)} className="hover:underline">
      {id}
    </Link>
  );
}

export function AccountsClient({
  account,
  chrome = true,
  range: controlledRange,
  onRangeChange,
}: {
  account?: string;
  /**
   * Whether to render this component's own heading, description, range picker and empty-state box.
   *
   * <p>False when a card around it already supplies them. Named for the one thing it does rather
   * than for the caller's situation -- "embedded" would invite it to mean denser, or narrower, or
   * read-only, and then nobody could say what setting it does.
   */
  chrome?: boolean;
  /** Controlled range, so the card's header can own the picker. Uncontrolled when absent. */
  range?: Range;
  onRangeChange?: (range: Range) => void;
} = {}) {
  const [ownRange, setOwnRange] = useState<Range>("24h");
  const range = controlledRange ?? ownRange;
  const setRange = onRangeChange ?? setOwnRange;
  const { data, error, loading } = useControlData<AccountsView>("accounts", range);
  //what this surface may show about what an account is charged -- see lib/panel-surface.ts. Here it
  //is one column: `cost` is what the operator paid a vendor, so billed minus cost is the margin.
  //The portal's own route does not send it either, so this is the second lock rather than the first
  const { pricing } = surface();
  const all = data?.accounts ?? [];
  //scoped when mounted on one account's page. Still several rows there: traffic splits by system id
  //and product, which is how the money splits, and folding those together would hide the case where
  //one login of two is failing
  const rows = account ? all.filter((r) => r.accountId === account) : all;

  //bordered on its own page, borderless inside the account card
  const Wrap = chrome ? Table : TableInCard;

  const nothing = loading
    ? "Loading…"
    : account
      ? "Nothing sent in this period"
      : "No accounts sent in this period";

  return (
    <div className={chrome ? "space-y-5" : "space-y-3"}>
      {chrome && (
        <div className="flex flex-wrap items-center gap-2">
          <p className="min-w-0 flex-1 text-sm text-muted-foreground">
            Derived from traffic, so this is who actually sent — not who is provisioned. Configured
            credentials appear too when the gateway keeps them in the database.
          </p>
          <RangePicker value={range} onChange={setRange} />
        </div>
      )}

      {error && (chrome ? <ErrorCard error={error} /> : <ErrorNote error={error} />)}

      {!error && !rows.length && (
        chrome ? (
          <EmptyState>
            {nothing}
          </EmptyState>
        ) : (
          <p className="py-4 text-sm text-muted-foreground">{nothing}</p>
        )
      )}

      {!!rows.length && (
        <>
          {/* one table, always. The card stack this replaced was gated on md: and, inside a
              col-span-3 column, its `overflow-hidden` sibling clipped a nine-column table with no
              scrollbar -- three columns were simply unreachable. A card in a column is also worse
              than a scrolling table, because it dropped System ID, Product and Last seen entirely */}
          <Wrap>
            <THead>
              <TR>
                <TH>Account</TH>
                <TH>System ID</TH>
                <TH>Product</TH>
                <TH align="right">Messages</TH>
                <TH align="right">Delivery</TH>
                <TH align="right">Billed</TH>
                {pricing && <TH align="right">Cost</TH>}
                <TH align="right">Credit</TH>
                <TH align="right">Last seen</TH>
              </TR>
            </THead>
            <TBody>
              {rows.map((r, i) => (
                <TR key={`${r.accountId}-${r.systemId}-${r.product}-${i}`}>
                  <TD className="font-medium">
                    <AccountLink id={r.accountId} />
                    {r.idle && (
                      <Badge variant="outline" className="ml-2">
                        idle
                      </Badge>
                    )}
                  </TD>
                  <TD muted>{r.systemId ?? "—"}</TD>
                  <TD muted>{r.product ?? "—"}</TD>
                  <TD num>{count(r.messages)}</TD>
                  <TD align="right">
                    <RateBadge rate={r.deliveryRate} />
                  </TD>
                  <TD num className="font-mono">{money(r.billed)}</TD>
                  {pricing && (
                    <TD num muted className="font-mono">
                      {money(r.cost)}
                    </TD>
                  )}
                  <TD num className="font-mono">
                    <Credit value={r.balance} currency={r.currency} enforced={data?.creditEnforced ?? false} />
                  </TD>
                  <TD align="right" muted suppressHydrationWarning>
                    {formatTimestamp(r.lastSeen) || "—"}
                  </TD>
                </TR>
              ))}
            </TBody>
          </Wrap>

          {!data?.creditEnforced && (
            <p className="text-sm text-muted-foreground">
              Prepaid credit is not enforced on this gateway — no account has a balance, so there is
              nothing to count against. That is not the same as every account being at zero.
            </p>
          )}
        </>
      )}
    </div>
  );
}

function Credit({
  value,
  currency,
  enforced,
}: {
  value: number | null;
  currency: string | null;
  enforced: boolean;
}) {
  //"not enforced" and "out of credit" are different states and must not render the same
  if (!enforced) return <span className="text-muted-foreground">—</span>;
  if (value === null) return <span className="text-muted-foreground">no balance</span>;
  return <span className={value <= 0 ? "text-destructive" : ""}>{money(value, currency ?? "")}</span>;
}

function RateBadge({ rate }: { rate: number | null }) {
  if (rate === null) return <Badge variant="outline">—</Badge>;
  const variant = rate >= 0.9 ? "success" : rate >= 0.7 ? "outline" : "destructive";
  return <Badge variant={variant}>{percent(rate)}</Badge>;
}
