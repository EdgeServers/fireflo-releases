"use client";
import { useMemo, useState } from "react";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Segmented } from "@/components/ui/segmented";
import { Select } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { ConditionEditor } from "./ConditionEditor";
import { FilterPicker } from "./FilterPicker";
import { ErrorNote, WarningNote } from "./FormNotices";
import { GuidedConditionRow, useGuidedOptions } from "./GuidedConditionRow";
import { productOptions } from "./RateRuleFields";
import { blankGuided, fromConditions, GUIDED_KINDS, toConditions, type GuidedField, type GuidedKind } from "@/lib/filter-guide";
import type { Filter } from "@/lib/filter-types";
import { describePriceWhen } from "@/lib/pricing-guide";
import { conditionWarnings, validateRule, type ConditionInput, type RateRuleInput, type ScopeKind } from "@/lib/rate-types";

/**
 * One price, in words: how much, for which product, when, and whether it is in use.
 *
 * <p>The conditions are the guided fields the filter wizard and the routing editor use, minus
 * product, which a price states on its own. A price the guided fields cannot express opens in the raw
 * condition editor. Done stages the price into the scope; nothing is saved until the Save bar.
 */
export function PriceRuleDialog({
  rule,
  position,
  scopeTitle,
  kind,
  rules,
  catalogue,
  filters,
  onDone,
  onDelete,
  onClose,
}: {
  rule: RateRuleInput;
  /** Its place among its product's prices, or null for a new one. */
  position: number | null;
  scopeTitle: string;
  kind: ScopeKind;
  /** The scope's other prices, so a product only they use stays offered. */
  rules: RateRuleInput[];
  catalogue: string[];
  filters: Filter[];
  onDone: (rule: RateRuleInput) => void;
  onDelete: (() => void) | null;
  onClose: () => void;
}) {
  const options = useGuidedOptions();
  const guidedStart = fromConditions(rule.conditions);
  const [amount, setAmount] = useState(rule.amount);
  const [product, setProduct] = useState(rule.product ?? "");
  const [only, setOnly] = useState(rule.conditions.length > 0 || rule.filters.length > 0);
  const [fields, setFields] = useState<GuidedField[]>(guidedStart?.length ? guidedStart : [blankGuided("destination")]);
  const [advanced, setAdvanced] = useState(guidedStart === null);
  const [raw, setRaw] = useState<ConditionInput[]>(rule.conditions.map((c) => ({ ...c })));
  const [chosenFilters, setChosenFilters] = useState<string[]>(rule.filters);
  const [currency, setCurrency] = useState(rule.currency ?? "");
  const [label, setLabel] = useState(rule.label ?? "");
  const [enabled, setEnabled] = useState(rule.enabled);
  const [error, setError] = useState("");

  const conditions = useMemo(() => (!only ? [] : advanced ? raw : toConditions(fields)), [only, advanced, raw, fields]);
  const result: RateRuleInput = {
    ...rule,
    amount: amount.trim(),
    product: product || null,
    conditions,
    filters: only ? chosenFilters : [],
    currency: currency.trim() || null,
    label: label.trim() || null,
    enabled,
  };
  const backToGuided = advanced ? fromConditions(raw) : null;
  const picked = new Set(fields.map((f) => f.kind));
  const verb = kind === "cost" ? "charges us" : kind === "default" ? "every account without its own pays" : "pays";
  const warnings = [
    ...conditionWarnings(conditions),
    only && !conditions.length && !chosenFilters.length ? "Only when… is chosen but nothing is filled in, so this price applies to everything else." : null,
    /^0(\.0{1,4})?$/.test(result.amount) ? "This price is zero: it charges nothing." : null,
  ].filter((w): w is string => w != null);

  function update(k: GuidedKind, patch: Partial<GuidedField>) {
    setFields((cur) => cur.map((f) => (f.kind === k ? { ...f, ...patch } : f)));
  }

  function done() {
    const invalid = validateRule(result, "this price");
    if (invalid) {
      setError(invalid);
      return;
    }
    onDone(result);
  }

  return (
    <Dialog open onClose={onClose} title={`${position === null ? "New price" : `Price ${position}`} for ${scopeTitle}`} className="max-w-2xl">
      <div className="space-y-5">
        <Row label={kind === "cost" ? "Cost" : "Price"} htmlFor="pr-amount">
          <div className="flex flex-wrap items-center gap-2">
            <Input id="pr-amount" className="w-36 tabular-nums" inputMode="decimal" placeholder="0.0450" autoFocus
              value={amount} onChange={(e) => setAmount(e.target.value)} />
            <span className="text-sm text-muted-foreground">per message, up to 4 decimal places</span>
          </div>
        </Row>

        <Row label="Product" htmlFor="pr-product">
          <Select id="pr-product" className="max-w-xs" value={product} onChange={(e) => setProduct(e.target.value)}>
            <option value="">Any product</option>
            {productOptions(catalogue, rules, rule.product).map((p) => <option key={p} value={p}>{p}</option>)}
          </Select>
        </Row>

        <Row label="When">
          <Segmented<"every" | "only">
            label="When this price applies"
            value={only ? "only" : "every"}
            onChange={(v) => setOnly(v === "only")}
            options={[{ value: "every", label: "Everything else" }, { value: "only", label: "Only when…" }]}
          />
          {only && (
            <div className="mt-3 space-y-3">
              {advanced ? (
                <div className="space-y-2">
                  <ConditionEditor conditions={raw} onChange={setRaw} filterCount={chosenFilters.length} />
                  <p className="text-xs text-muted-foreground">
                    The gateway&apos;s own fields and operators. Every condition must hold.{" "}
                    {backToGuided && (
                      <button type="button" className="text-primary hover:underline"
                        onClick={() => { setFields(backToGuided.length ? backToGuided : [blankGuided("destination")]); setAdvanced(false); }}>
                        Back to the guided fields
                      </button>
                    )}
                  </p>
                </div>
              ) : (
                <>
                  {fields.map((f) => (
                    <GuidedConditionRow key={f.kind} field={f} options={options} onChange={(p) => update(f.kind, p)}
                      onRemove={() => setFields((cur) => cur.filter((x) => x.kind !== f.kind))} />
                  ))}
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm">
                    <Select aria-label="Add a condition" value="" className="w-auto"
                      onChange={(e) => {
                        const k = e.target.value as GuidedKind;
                        if (k) setFields((cur) => [...cur, blankGuided(k)]);
                      }}>
                      <option value="">+ Add a condition</option>
                      {GUIDED_KINDS.filter((k) => k.id !== "product" && !picked.has(k.id)).map((k) => <option key={k.id} value={k.id}>{k.label}</option>)}
                    </Select>
                    <button type="button" className="text-muted-foreground hover:text-foreground hover:underline"
                      onClick={() => { setRaw(conditions.map((c) => ({ ...c }))); setAdvanced(true); }}>
                      Edit as conditions
                    </button>
                  </div>
                </>
              )}
              <FilterPicker chosen={chosenFilters} library={filters} onChange={setChosenFilters} />
            </div>
          )}
        </Row>

        <Row label="Note" htmlFor="pr-note">
          <Input id="pr-note" value={label} placeholder="What this price is for" onChange={(e) => setLabel(e.target.value)} />
        </Row>

        <Row label="Currency" htmlFor="pr-currency">
          <div className="flex flex-wrap items-center gap-2">
            <Input id="pr-currency" className="w-24 font-mono uppercase" maxLength={3} placeholder="—" value={currency}
              onChange={(e) => setCurrency(e.target.value.toUpperCase())} />
            <span className="text-xs text-muted-foreground">Leave empty for the gateway&apos;s default. Amounts are never converted.</span>
          </div>
        </Row>

        <Row label="Active" labelId="pr-active">
          <div className="flex items-center gap-3">
            <Switch checked={enabled} onChange={setEnabled} aria-labelledby="pr-active" />
            <span className="text-sm text-muted-foreground">{enabled ? "The gateway uses this price." : "Retired: kept in place, never matched."}</span>
          </div>
        </Row>

        <div className="rounded-lg border border-border bg-muted/40 px-4 py-3 text-sm">
          <span className="text-muted-foreground">Reads: </span>
          <span className="font-medium">
            {describePriceWhen(result)}{result.product ? ` on ${result.product}` : ""}, {scopeTitle} {verb}{" "}
            <span className="font-mono">{result.amount || "…"}</span>{result.currency ? ` ${result.currency}` : ""} per message.
          </span>
        </div>

        <WarningNote warnings={warnings} />
        <ErrorNote error={error} />

        <div className="flex flex-wrap items-center gap-2 border-t border-border pt-4">
          {onDelete && (
            <Button type="button" variant="ghost" className="gap-1.5 text-destructive" onClick={onDelete}>
              <Trash2 className="h-4 w-4" aria-hidden="true" /> Remove price
            </Button>
          )}
          <span className="mr-auto" />
          <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
          <Button type="button" disabled={!result.amount} onClick={done}>Done</Button>
        </div>
      </div>
    </Dialog>
  );
}

/** A label beside its control on a wide screen, above it on a phone. */
function Row({ label, htmlFor, labelId, children }: { label: string; htmlFor?: string; labelId?: string; children: React.ReactNode }) {
  return (
    <div className="grid gap-1.5 sm:grid-cols-[110px_minmax(0,1fr)] sm:gap-4">
      {htmlFor
        ? <label htmlFor={htmlFor} className="text-sm font-semibold sm:pt-2">{label}</label>
        : <div id={labelId} className="text-sm font-semibold sm:pt-2">{label}</div>}
      <div className="min-w-0">{children}</div>
    </div>
  );
}
