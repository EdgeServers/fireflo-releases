"use client";
import { useState } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { KeyRound, Plus, ShieldCheck, UserRound } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClasses } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { TBody, TD, TH, THead, TR, Table, TableEmpty } from "@/components/ui/table";
import { PageHeader } from "@/components/ui/page-header";
import { SetPasswordDialog } from "@/components/SetPasswordDialog";
import { UserForm } from "@/components/UserForm";
import { useUsers } from "@/components/useUsers";
import { ADMIN_ROLE, CUSTOMER_ROLE, OPERATOR_ROLE } from "@/lib/roles";
import type { PublicUser } from "@/lib/user-types";

/**
 * Who may sign in, and what they did.
 *
 * <p>Admin-only: the page's server component checks the session and the API answers 404 to anyone
 * else, so an operator never sees this and the nav item is not rendered for them. What they DID is
 * the Access log report; each row here links into it.
 */
export function UsersClient() {
  const { users, error, loading, busy, load, create, patch, setPassword } = useUsers();
  const { data: session } = useSession();
  const me = session?.user?.userId ? Number(session.user.userId) : null;
  const [creating, setCreating] = useState(false);
  const [resetting, setResetting] = useState<PublicUser | null>(null);

  const panel = users.filter((u) => u.role !== CUSTOMER_ROLE);
  const customers = users.filter((u) => u.role === CUSTOMER_ROLE);

  return (
    <>
      <PageHeader
        title="Users"
        description="Who may sign in to this panel and to the customer portal, and what they did."
        actions={
          !creating ? (
            <Button onClick={() => setCreating(true)} className="gap-2">
              <Plus className="h-4 w-4" />
              Add user
            </Button>
          ) : undefined
        }
      />

      {creating && (
        <UserForm
          onCreate={create}
          onDone={() => {
            setCreating(false);
            void load();
          }}
          onCancel={() => setCreating(false)}
        />
      )}

      {error && (
        <Card>
          <CardContent className="py-4 text-sm text-destructive">{error}</CardContent>
        </Card>
      )}

      <Section title="Panel" hint="Admins manage users; operators run the gateway.">
        {panel.length === 0 && !loading && (
          <Empty>
            No admin or operator in the database yet. Sign-in is using OPERATOR_PASSWORD from panel.env, which goes
            away next release — add an admin here or with <code>fireflo user add</code>.
          </Empty>
        )}
        {panel.map((u) => (
          <UserRow
            key={u.id}
            user={u}
            isMe={u.id === me}
            busy={busy === u.id}
            onToggle={() => patch(u.id, { enabled: !u.enabled })}
            onRole={(role) => patch(u.id, { role })}
            onPassword={() => setResetting(u)}
            logHref={`/cp/access-log?user=${u.id}`}
          />
        ))}
      </Section>

      <Section title="Customers" hint="People who sign in to the portal. One account may have several.">
        {customers.length === 0 && !loading && <Empty>No customer users. Adding an email to an account creates one.</Empty>}
        {customers.map((u) => (
          <UserRow
            key={u.id}
            user={u}
            isMe={false}
            busy={busy === u.id}
            onToggle={() => patch(u.id, { enabled: !u.enabled })}
            onPassword={() => setResetting(u)}
            logHref={`/cp/access-log?user=${u.id}`}
          />
        ))}
      </Section>

      {resetting && (
        <SetPasswordDialog
          email={resetting.email}
          open
          onClose={() => setResetting(null)}
          onSubmit={(pw) => setPassword(resetting.id, pw)}
        />
      )}
    </>
  );
}

function Section({ title, hint, children }: { title: string; hint: string; children: React.ReactNode }) {
  return (
    <section className="space-y-2">
      <div>
        <h2 className="text-base font-medium">{title}</h2>
        <p className="text-xs text-muted-foreground">{hint}</p>
      </div>
      <Table>
        <THead>
          <tr>
            <TH>User</TH>
            <TH>Role</TH>
            <TH>Last sign-in</TH>
            <TH align="right">Actions</TH>
          </tr>
        </THead>
        <TBody>{children}</TBody>
      </Table>
    </section>
  );
}

function Empty({ children }: { children: React.ReactNode }) {
  return <TableEmpty colSpan={4}>{children}</TableEmpty>;
}

export function UserRow({
  user,
  isMe,
  busy,
  onToggle,
  onRole,
  onPassword,
  logHref,
}: {
  user: PublicUser;
  isMe: boolean;
  busy: boolean;
  onToggle: () => void;
  onRole?: (role: "admin" | "operator") => void;
  onPassword: () => void;
  logHref?: string;
}) {
  const Icon = user.role === ADMIN_ROLE ? ShieldCheck : UserRound;
  return (
    <TR className={!user.enabled ? "opacity-60" : undefined}>
      <TD primary>
        <span className="flex items-center gap-2.5">
          <Icon className="h-4 w-4 shrink-0 text-muted-foreground" />
          <span className="min-w-0">
            <span className="block truncate">{user.email}</span>
            {user.accountId && (
              <Link
                href={`/cp/accounts/${encodeURIComponent(user.accountId)}`}
                className="block text-xs font-normal text-muted-foreground underline-offset-2 hover:underline"
              >
                {user.accountId}
              </Link>
            )}
          </span>
        </span>
      </TD>
      <TD>
        <span className="flex flex-wrap gap-1">
          <Badge variant="outline" className="capitalize">{user.role}</Badge>
          {isMe && <Badge>you</Badge>}
          {!user.enabled && <Badge variant="destructive">disabled</Badge>}
          {!user.hasPassword && <Badge variant="warning">link only</Badge>}
        </span>
      </TD>
      <TD muted className="whitespace-nowrap">
        {user.lastLoginAt ? new Date(user.lastLoginAt).toLocaleString() : "Never"}
      </TD>
      <TD align="right">
        <span className="flex flex-wrap justify-end gap-1">
          {onRole && !isMe && (
            <Button variant="outline" size="sm" disabled={busy} onClick={() => onRole(user.role === ADMIN_ROLE ? OPERATOR_ROLE : ADMIN_ROLE)}>
              {user.role === ADMIN_ROLE ? "Make operator" : "Make admin"}
            </Button>
          )}
          <Button variant="outline" size="sm" disabled={busy} onClick={onPassword}>
            <KeyRound className="h-3.5 w-3.5" />
            {user.hasPassword ? "Reset password" : "Set password"}
          </Button>
          {logHref && (
            <Link href={logHref} className={buttonClasses({ variant: "ghost", size: "sm" })}>
              History
            </Link>
          )}
          {!isMe && (
            <Button variant={user.enabled ? "ghost" : "outline"} size="sm" disabled={busy} onClick={onToggle}>
              {user.enabled ? "Disable" : "Enable"}
            </Button>
          )}
        </span>
      </TD>
    </TR>
  );
}
