"use client";

import { Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  duplicateCarrierCodes,
  errorCodeProblem,
  formatErrorCodes,
  type ErrorCodePair,
} from "@/lib/error-codes";

/**
 * The `dlr.errcodes` pairs, as a table rather than as a CSV string.
 *
 * <h2>What this replaces, and why</h2>
 *
 * <p>One free-text field holding `630_16,1000_1` — a grammar with an underscore inside the pair and
 * a comma between pairs, explained nowhere on screen. The gateway skips a malformed entry with a
 * WARN at startup and keeps the rest, so a typo has never broken anything loudly; it just meant
 * every receipt for that code carried the wrong value, discoverable only from a support ticket.
 * Two columns make the grammar structural, and {@link errorCodeProblem} moves the refusal to the
 * keystroke.
 *
 * <h2>Both sides are free text, and only one of those is obvious</h2>
 *
 * <p>The left is a carrier's private numbering, which no catalogue can enumerate — the original
 * decision to avoid a catalogue-shaped widget was right about that half and is kept.
 *
 * <p>The right is our own vocabulary, so a named dropdown would read far better than a bare `16`.
 * It is deliberately not one: the list lives in `SmppServerUtil` on the gateway, and mirroring it
 * here would be a hand-kept copy of a Java constant, free to drift, with nothing failing when it
 * did. Validated as a number instead — exactly what the gateway validates, no more.
 *
 * <p>The stored string is rendered under the table. It is what the gateway will actually read, and
 * showing it is what stops the format being folklore.
 */
export function ErrorCodeEditor({
  pairs,
  onChange,
  disabled = false,
}: {
  pairs: ErrorCodePair[];
  onChange: (next: ErrorCodePair[]) => void;
  disabled?: boolean;
}) {
  const duplicates = duplicateCarrierCodes(pairs);
  const stored = formatErrorCodes(pairs);

  function update(index: number, patch: Partial<ErrorCodePair>) {
    onChange(pairs.map((pair, i) => (i === index ? { ...pair, ...patch } : pair)));
  }

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-[minmax(0,1fr)_minmax(0,1fr)_2rem] gap-2 text-xs text-muted-foreground">
        <span>Carrier sends</span>
        <span>Customer receives</span>
        <span />
      </div>

      {pairs.map((pair, index) => {
        const problem = errorCodeProblem(pair);
        const duplicated = pair.carrier.trim() && duplicates.includes(pair.carrier.trim());
        return (
          <div key={index} className="space-y-1">
            <div className="grid grid-cols-[minmax(0,1fr)_minmax(0,1fr)_2rem] items-start gap-2">
              <Input
                value={pair.carrier}
                onChange={(e) => update(index, { carrier: e.target.value })}
                placeholder="630"
                aria-label="Code the carrier sends"
                className="min-w-0 font-mono"
                disabled={disabled}
              />
              <Input
                value={pair.ours}
                onChange={(e) => update(index, { ours: e.target.value })}
                placeholder="16"
                inputMode="numeric"
                aria-label="Code the customer receives"
                className="min-w-0 font-mono"
                disabled={disabled}
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="h-9 w-8"
                aria-label="Remove this mapping"
                disabled={disabled}
                onClick={() => onChange(pairs.filter((_, i) => i !== index))}
              >
                <X className="h-3.5 w-3.5" />
              </Button>
            </div>
            {problem && <p className="text-xs text-destructive">{problem}</p>}
            {/* not an error: the gateway keeps the last one, so this is a value being silently
                discarded rather than a refusal. Amber matches how the panel warns elsewhere */}
            {!problem && duplicated && (
              <p className="text-xs text-amber-600 dark:text-amber-400">
                {pair.carrier.trim()} is mapped more than once. The gateway keeps the last one.
              </p>
            )}
          </div>
        );
      })}

      <Button
        type="button"
        variant="ghost"
        size="sm"
        className="gap-1.5"
        disabled={disabled}
        onClick={() => onChange([...pairs, { carrier: "", ours: "" }])}
      >
        <Plus className="h-3.5 w-3.5" />
        Add a mapping
      </Button>

      <p className="text-xs text-muted-foreground">
        {stored ? (
          <>
            Stored as <code className="font-mono">{stored}</code>
          </>
        ) : (
          "Nothing mapped. Codes reach the customer unchanged, or as 018 — see below."
        )}
      </p>
    </div>
  );
}
