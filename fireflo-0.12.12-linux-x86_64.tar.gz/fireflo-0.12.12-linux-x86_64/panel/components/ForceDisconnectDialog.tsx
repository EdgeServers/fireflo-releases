"use client";
import { useEffect, useState } from "react";
import { Ban, Unplug } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { HealthStrip } from "./CardBits";
import {
  bindSummary,
  HOLD_CHOICES,
  holdRemaining,
  holdTarget,
  KIND_LABEL,
  previewSentence,
  targetProblem,
  type BindHold,
  type DisconnectKind,
  type MatchedSession,
} from "@/lib/force-disconnect";
import { cn } from "@/lib/utils";

/**
 * Force disconnect by IP, account or login -- the one dialog behind the listener page, the
 * account's Logins card and the Security page.
 *
 * <p>Shows who would be dropped before anything happens (the gateway's exact match, across every
 * listener or the one named), then asks what happens next: let them reconnect, or keep them out for
 * a while. Without a hold a client with a reconnect loop is back in seconds, which is said plainly
 * rather than discovered.
 */
export function ForceDisconnectDialog({
  initialKind = "ip",
  initialValue = "",
  initialValues = {},
  kinds = ["ip", "account", "system_id"],
  listener,
  onClose,
  onDone,
}: {
  initialKind?: DisconnectKind;
  initialValue?: string;
  /** Starting values for the other targets, so switching to one is already filled in. */
  initialValues?: Partial<Record<DisconnectKind, string>>;
  /** Which targets to offer; the Logins card offers the login and its account. */
  kinds?: DisconnectKind[];
  /** Limit to one listener (its name), or every listener when absent. */
  listener?: string;
  onClose: () => void;
  /** After a successful disconnect, so the opener can refresh what it shows. */
  onDone?: () => void;
}) {
  const [kind, setKind] = useState<DisconnectKind>(initialKind);
  const [values, setValues] = useState<Partial<Record<DisconnectKind, string>>>({ ...initialValues, [initialKind]: initialValue });
  const value = values[kind] ?? "";
  const [holdId, setHoldId] = useState("none");
  const [reason, setReason] = useState("");
  const [preview, setPreview] = useState<{ rows: MatchedSession[]; error?: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<{ dropped: number; hold: BindHold | null; scope: string | null } | null>(null);

  const problem = targetProblem(kind, value);
  const hold = HOLD_CHOICES.find((c) => c.id === holdId)!;

  //the preview, debounced: who this would drop right now
  useEffect(() => {
    if (problem) {
      //eslint-disable-next-line react-hooks/set-state-in-effect -- clearing a preview for an unusable target
      setPreview(null);
      return;
    }
    let live = true;
    const timer = window.setTimeout(() => {
      const q = new URLSearchParams({ kind, value: value.trim() });
      if (listener) q.set("listener", listener);
      fetch(`/api/control/sessions/match?${q}`, { cache: "no-store" })
        .then(async (res) => {
          const json = await res.json().catch(() => null);
          if (!live) return;
          setPreview(res.ok ? { rows: (json?.data ?? []) as MatchedSession[] } : { rows: [], error: json?.error ?? `The gateway answered ${res.status}` });
        })
        .catch(() => live && setPreview({ rows: [], error: "The gateway could not be reached." }));
    }, 300);
    return () => {
      live = false;
      window.clearTimeout(timer);
    };
  }, [kind, value, listener, problem]);

  async function run() {
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/control/sessions/disconnect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind, value: value.trim(), listener, hold: hold.hold ?? undefined, reason }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `The gateway answered ${res.status}`);
        return;
      }
      setResult({ dropped: (json?.data?.dropped ?? []).length, hold: json?.data?.hold ?? null, scope: json?.data?.hold_scope ?? null });
      onDone?.();
    } catch {
      setError("The gateway could not be reached. Nothing was disconnected.");
    } finally {
      setBusy(false);
    }
  }

  const count = preview?.rows.length ?? 0;
  const keepsOut = hold.hold !== null;

  return (
    <Dialog open onClose={onClose} title="Force disconnect"
      description={listener ? `Sessions on ${listener}.` : "Sessions on every listener."}>
      {result ? (
        <div className="space-y-4">
          <p className="text-sm">
            {result.dropped
              ? `Dropped ${result.dropped} ${result.dropped === 1 ? "session" : "sessions"}.`
              : "Nothing was bound like that, so nothing was dropped."}
          </p>
          {result.hold ? (
            <HealthStrip>
              {holdTarget(result.hold)} is held out {holdRemaining(result.hold.until)}
              {result.scope ? ` (${result.scope})` : ""}. Lift it on the Security page.
            </HealthStrip>
          ) : (
            <p className="text-sm text-muted-foreground">They may bind again straight away.</p>
          )}
          <div className="flex justify-end border-t border-border pt-4">
            <Button type="button" onClick={onClose}>Done</Button>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {kinds.length > 1 && (
            <div className="grid gap-2 sm:grid-cols-3">
              {kinds.map((k) => (
                <button key={k} type="button" aria-pressed={kind === k} onClick={() => setKind(k)}
                  className={cn(
                    "rounded-lg border px-3 py-2 text-left text-sm font-semibold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                    kind === k ? "border-primary bg-primary-soft/50 ring-1 ring-primary" : "border-border hover:border-muted-foreground/40"
                  )}>
                  {KIND_LABEL[k]}
                </button>
              ))}
            </div>
          )}
          <label className="block space-y-1.5 text-xs font-semibold">
            {KIND_LABEL[kind]}
            <Input value={value} autoFocus spellCheck={false} className="font-mono"
              placeholder={kind === "ip" ? "203.0.113.7" : kind === "account" ? "acme" : "acme-smpp"}
              onChange={(e) => setValues((v) => ({ ...v, [kind]: e.target.value }))} />
            <span className="block font-normal text-muted-foreground">Matched exactly: {kind === "ip" ? "this address" : `this ${kind === "account" ? "account" : "login"}`} and nothing that merely starts with it.</span>
          </label>

          <div className={cn("rounded-lg border px-3 py-2.5 text-sm", count ? "border-warning/50 bg-warning-soft/40" : "border-border")}>
            {problem ? <span className="text-muted-foreground">{problem}</span>
              : preview === null ? <span className="text-muted-foreground">Looking…</span>
                : preview.error ? <span className="text-destructive">{preview.error}</span>
                  : (
                    <>
                      <span className="font-medium">{previewSentence(preview.rows)}</span>
                      {count > 0 && <span className="block text-xs text-muted-foreground">{bindSummary(preview.rows)}</span>}
                    </>
                  )}
          </div>

          <fieldset className="space-y-1.5">
            <legend className="text-xs font-semibold">Then</legend>
            {HOLD_CHOICES.map((c) => (
              <label key={c.id} className="flex items-center gap-2 text-sm">
                <input type="radio" name="hold" checked={holdId === c.id} onChange={() => setHoldId(c.id)} />
                {c.label}
              </label>
            ))}
            <p className="text-xs text-muted-foreground">
              {keepsOut
                ? "New binds are refused on every node while the hold lasts, and logged as “held out” — which fail2ban ignores."
                : "A client with a reconnect loop will be back within seconds."}
            </p>
          </fieldset>

          {keepsOut && (
            <label className="block space-y-1.5 text-xs font-semibold">
              Reason <span className="font-normal text-muted-foreground">(optional, shown with the hold)</span>
              <Input value={reason} maxLength={300} onChange={(e) => setReason(e.target.value)} placeholder="Flooding with bad PDUs" />
            </label>
          )}

          {error && <HealthStrip tone="destructive">{error}</HealthStrip>}

          <div className="flex flex-wrap justify-end gap-2 border-t border-border pt-4">
            <Button type="button" variant="ghost" className="mr-auto" onClick={onClose}>Cancel</Button>
            <Button type="button" variant="destructive" className="gap-2" disabled={busy || !!problem || (!count && !keepsOut)}
              onClick={() => void run()}>
              {keepsOut ? <Ban className="h-4 w-4" aria-hidden /> : <Unplug className="h-4 w-4" aria-hidden />}
              {busy ? "Working…"
                : count ? `Disconnect ${count} ${count === 1 ? "session" : "sessions"}${keepsOut ? " and hold out" : ""}`
                  : keepsOut ? "Hold out" : "Nothing to disconnect"}
            </Button>
          </div>
        </div>
      )}
    </Dialog>
  );
}

/**
 * The holds in force, with Lift -- the Security page's card.
 */
export function BindHoldsCard({ refreshKey = 0 }: { refreshKey?: number }) {
  const [holds, setHolds] = useState<BindHold[] | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState<number | null>(null);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let live = true;
    fetch("/api/control/bind-holds", { cache: "no-store" })
      .then(async (res) => {
        const json = await res.json().catch(() => null);
        if (!live) return;
        if (res.ok) {
          setHolds((json?.data ?? []) as BindHold[]);
          setError("");
        } else {
          setHolds([]);
          setError(json?.error ?? `The gateway answered ${res.status}`);
        }
      })
      .catch(() => live && setError("The gateway could not be reached."));
    return () => {
      live = false;
    };
  }, [refreshKey, tick]);

  async function lift(id: number) {
    setBusy(id);
    const res = await fetch(`/api/control/bind-holds/${id}`, { method: "DELETE" }).catch(() => null);
    setBusy(null);
    if (!res?.ok) {
      const json = await res?.json().catch(() => null);
      setError(json?.error ?? "The hold could not be lifted.");
    }
    setTick((t) => t + 1);
  }

  return (
    <div className="space-y-2">
      {error && <p className="text-xs text-destructive">{error}</p>}
      {holds === null ? <p className="text-sm text-muted-foreground">Reading…</p>
        : !holds.length ? <p className="text-sm text-muted-foreground">Nobody is held out.</p>
          : (
            <ul className="divide-y divide-border">
              {holds.map((h) => (
                <li key={h.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 py-2 text-sm">
                  <span className="min-w-0">
                    <span className="block font-mono font-medium">{holdTarget(h)}</span>
                    <span className="block text-xs text-muted-foreground">
                      {holdRemaining(h.until)}{h.listener ? ` · ${h.listener}` : " · every listener"}
                      {h.created_by ? ` · by ${h.created_by}` : ""}{h.reason ? ` · ${h.reason}` : ""}
                    </span>
                  </span>
                  <Button variant="outline" size="sm" className="ml-auto" disabled={busy === h.id} onClick={() => void lift(h.id)}>
                    {busy === h.id ? "Lifting…" : "Lift"}
                  </Button>
                </li>
              ))}
            </ul>
          )}
    </div>
  );
}
