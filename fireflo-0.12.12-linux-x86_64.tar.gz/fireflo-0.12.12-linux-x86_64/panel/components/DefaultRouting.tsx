"use client";
import { useState } from "react";
import { ArrowRightLeft, CornerUpLeft, CornerUpRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { HealthStrip } from "./CardBits";
import { DangerAction } from "./DangerAction";
import { ReceiptRoutingProbe } from "./ReceiptRoutingProbe";
import {
  buildMoRouteRuleDraft,
  defaultRoutingPlan,
  missingDlrReturnRules,
  returnReceiptsPerListener,
  missingMoRouteRules,
  missingMtTypes,
  DEFAULT_TABLE_NAME,
  type RouteRule,
  type RouteTable,
} from "@/lib/routing-types";
import { isOn, trafficKey, type Worker } from "@/lib/worker-types";

/**
 * The rules the gateway needs to work at all, as distinct from the business rules an operator
 * writes below them.
 *
 * <p>Three lanes, and they are not equally decidable. A delivery receipt has exactly one correct
 * target — its own listener — so a missing rule is fully determined and this adds it in one click.
 * Where inbound messages and ordinary outbound traffic should go are business decisions, so those
 * lanes are reported here but only written once an operator has picked a target.
 *
 * <p>The Recreate action at the foot covers all three at once. It exists for the case the per-row
 * buttons cannot reach: if the `default` table itself is gone, there is nothing for a single rule
 * to be added to, and the gateway refuses its whole routing configuration until the table is back.
 */
export function DefaultRouting({
  tables,
  servers,
  vendors,
  writable,
  onApplied,
  onStartMoRule,
}: {
  tables: readonly RouteTable[];
  servers: readonly Worker[];
  vendors: readonly Worker[];
  /**
   * `undefined` while health is unread; `false` when the gateway is routing from a file, in which
   * case a write here would be stored and ignored — the same distinction `GatewayIgnores` already
   * renders for the tables below, applied to the buttons rather than to a banner.
   */
  writable: boolean | undefined;
  /** Reloads the table list, so a satisfied gap disappears from this section on its own. */
  onApplied: () => void;
  /** Opens the rule editor on the `default` table with the MO draft appended, unsaved. */
  onStartMoRule: (draft: RouteRule) => void;
}) {
  const dlrGaps = missingDlrReturnRules(tables, servers);
  //rule ORDER, not just membership: moving a return rule below a business rule is the edit that
  //breaks it, and it changes no counts at all
  const probeKey = tables
    .map((t) => `${t.name}:${t.rules.map((r) => `${r.enabled ? "" : "!"}${r.target}`).join(",")}`)
    .join("|");
  const moGaps = missingMoRouteRules(tables, vendors);
  const dlrGapNames = new Set(dlrGaps.map((g) => g.workerFullName));
  //listeners whose receipt rule exists but has no listener condition: with two or more listeners it
  //takes every listener's receipts, which reads differently from having no rule at all
  const unqualified = new Set(returnReceiptsPerListener(
    tables.find((t) => t.name === DEFAULT_TABLE_NAME)?.rules ?? [], servers).narrowed);
  const moGapNames = new Set(moGaps.map((g) => g.workerFullName));

  const defaultTable = tables.find((t) => t.name === DEFAULT_TABLE_NAME);
  const uncoveredTypes = missingMtTypes(defaultTable);

  if (!servers.length && !vendors.length) {
    return null;
  }

  return (
    <Card>
      <CardHeader className="flex flex-row flex-wrap items-baseline gap-2 space-y-0 border-b border-border">
        <CardTitle>Default routing</CardTitle>
        <CardDescription>
          The rules the gateway needs to work at all, checked against the tables below.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3 pt-3">
        {/* the gateway's own matcher, not this panel's reading of the table. A rule can be present,
            match, and still send the receipt somewhere useless -- or to a vendor, where it leaves
            as billed traffic. Only the matcher sees position */}
        <ReceiptRoutingProbe servers={servers} reloadKey={probeKey} />

        {!defaultTable && (
          <HealthStrip tone="destructive">
            There is no <code className="font-mono">{DEFAULT_TABLE_NAME}</code> routing table. The
            gateway refuses a routing configuration without one — it keeps running on the last copy
            it read and routes nothing at all once restarted. Rebuild it below.
          </HealthStrip>
        )}

        <div>
          <p className="mb-1 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">
            Delivery receipts — one rule returns each listener&apos;s receipts to it
          </p>
          <ul className="divide-y divide-border">
            {servers.map((server) => {
              const fullName = trafficKey(server);
              return (
                <DlrRow
                  key={fullName}
                  workerName={server.name}
                  workerFullName={fullName}
                  unqualified={unqualified.has(fullName)}
                  missing={dlrGapNames.has(fullName)}
                  writable={writable}
                  onApplied={onApplied}
                />
              );
            })}
          </ul>
        </div>

        <div>
          <p className="mb-1 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">
            Inbound messages from vendors — the target is a business decision, not automatic
          </p>
          <ul className="divide-y divide-border">
            {vendors.map((vendor) => {
              const fullName = trafficKey(vendor);
              return (
                <MoRow
                  key={fullName}
                  workerFullName={fullName}
                  routed={isOn(vendor, "mo.route")}
                  missing={moGapNames.has(fullName)}
                  onStartMoRule={() => onStartMoRule(buildMoRouteRuleDraft({
                    kind: "mo-route", workerName: vendor.name, workerFullName: fullName,
                  }))}
                />
              );
            })}
          </ul>
        </div>

        <div>
          <p className="mb-1 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">
            Outbound messages — one rule per content type, in the entry-point table
          </p>
          <MtRow uncovered={uncoveredTypes} hasTable={!!defaultTable} />
        </div>

      </CardContent>
    </Card>
  );
}

function DlrRow({
  workerName, workerFullName, missing, unqualified = false, writable, onApplied,
}: {
  workerName: string;
  workerFullName: string;
  missing: boolean;
  /** Its rule exists with no listener condition, and so takes every listener's receipts. */
  unqualified?: boolean;
  writable: boolean | undefined;
  onApplied: () => void;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function apply() {
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/control/delivery-check/apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind: "addSystemReturnRule", workerName, workerFullName }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      onApplied();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <li className="flex flex-wrap items-center gap-3 py-2">
      <CornerUpLeft className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden="true" />
      <span className="min-w-0 flex-1">
        <span className="font-mono text-sm">{workerFullName}</span>
        {missing && unqualified ? (
          <span className="block text-xs text-muted-foreground">
            Its receipt rule has no listener condition, so with more than one listener it takes every
            listener&apos;s receipts — clients on the others never get theirs. Fixing it narrows the rule.
          </span>
        ) : missing ? (
          <span className="block text-xs text-muted-foreground">
            Receipts have no way back to this listener — they burn twenty routing attempts and drop.
          </span>
        ) : (
          <span className="block text-xs text-muted-foreground">Returns to this listener. Locked — created with the listener.</span>
        )}
      </span>
      {missing ? (
        writable === false ? (
          <span className="text-xs text-muted-foreground">
            Add <code className="font-mono">{workerFullName}:type:==:18</code> to routingTable.conf
          </span>
        ) : (
          <DangerAction
            label="Add rule"
            confirmLabel="Add the receipt-return rule"
            consequence={`Delivery receipts arriving on ${workerFullName} will route back to it.`}
            tone="caution"
            busy={busy}
            onConfirm={apply}
          />
        )
      ) : (
        <Badge variant="success">OK</Badge>
      )}
      {error && <span className="w-full text-sm text-destructive">{error}</span>}
    </li>
  );
}

function MoRow({
  workerFullName, routed, missing, onStartMoRule,
}: {
  workerFullName: string;
  routed: boolean;
  missing: boolean;
  onStartMoRule: () => void;
}) {
  return (
    <li className="flex flex-wrap items-center gap-3 py-2">
      <CornerUpRight
        className={`h-4 w-4 shrink-0 ${routed ? "text-muted-foreground" : "text-muted-foreground/50"}`}
        aria-hidden="true"
      />
      <span className="min-w-0 flex-1">
        <span className="font-mono text-sm">{workerFullName}</span>
        <span className="block text-xs text-muted-foreground">
          {!routed
            ? "Inbound routing is switched off for this vendor."
            : missing
              ? "Inbound routing is on, and no rule matches it yet."
              : "Has a rule for its inbound messages."}
        </span>
      </span>
      {!routed ? (
        <span className="text-xs text-muted-foreground">Off</span>
      ) : missing ? (
        <Button variant="outline" size="sm" onClick={onStartMoRule}>Start rule</Button>
      ) : (
        <Badge variant="success">OK</Badge>
      )}
    </li>
  );
}

/**
 * The outbound lane, as one row rather than one per type.
 *
 * <p>No per-type button: the five rules share a target, so offering them separately would invite a
 * table where text goes to one vendor and Unicode to another by accident.
 */
function MtRow({ uncovered, hasTable }: { uncovered: readonly string[]; hasTable: boolean }) {
  return (
    <div className="flex flex-wrap items-center gap-3 py-2">
      <ArrowRightLeft className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden="true" />
      <span className="min-w-0 flex-1">
        <span className="font-mono text-sm">{DEFAULT_TABLE_NAME}</span>
        <span className="block text-xs text-muted-foreground">
          {!uncovered.length
            ? "Every outbound message type has a rule."
            : !hasTable
              ? "No entry-point table, so no outbound message is routed at all."
              : `No rule for message ${uncovered.length === 1 ? "type" : "types"} `
                + `${uncovered.join(", ")} — a message of that type is dropped after 20 attempts.`}
        </span>
      </span>
      {uncovered.length
        ? <Badge variant="outline">{uncovered.length} uncovered</Badge>
        : <Badge variant="success">OK</Badge>}
    </div>
  );
}

/**
 * Rebuilds all three lanes in one write.
 *
 * <p>The two targets are asked for here rather than guessed because neither can be derived: which
 * table or vendor ordinary outbound traffic chains to, and which listener owns inbound MOs, are
 * business decisions. Receipts need no question — each has exactly one correct listener.
 *
 * <p>The preview is the plan itself, computed by the same pure function the server re-runs against
 * a freshly-read table set. So what is listed is what will happen, and neither side is reading the
 * other's summary of it.
 */
export function RecreateAction({
  tables, servers, vendors, writable, onApplied,
}: {
  tables: readonly RouteTable[];
  servers: readonly Worker[];
  vendors: readonly Worker[];
  writable: boolean | undefined;
  onApplied: () => void;
}) {
  //a group is a legal target and the server accepts one -- it is left out of the picker only
  //because this card does not fetch the group list, and the full editor can still name it
  const chainTargets = tables.map((t) => t.name).filter((n) => n !== DEFAULT_TABLE_NAME);
  const vendorTargets = vendors.map((v) => v.name);
  const listenerTargets = servers.map(trafficKey);

  const [mtTarget, setMtTarget] = useState(
    chainTargets[0] ?? (vendorTargets.length === 1 ? vendorTargets[0] : ""));
  const [moTarget, setMoTarget] = useState(
    listenerTargets.length === 1 ? listenerTargets[0] : "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState("");

  const plan = defaultRoutingPlan(tables, servers, vendors, { mtTarget, moTarget });

  async function apply() {
    setBusy(true);
    setError("");
    setDone("");
    try {
      const res = await fetch("/api/control/delivery-check/apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind: "recreateDefaultRouting", mtTarget, moTarget }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      setDone(json?.data?.applied ?? "Done.");
      onApplied();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setBusy(false);
    }
  }

  if (writable === false) {
    return (
      <p className="border-t border-border pt-4 text-xs text-muted-foreground">
        The gateway is routing from a file, so nothing here can rebuild it. The shipped
        <code className="mx-1 font-mono">conf/routingTable.conf</code> carries the three lanes as a
        worked example.
      </p>
    );
  }

  return (
    <div className="space-y-2 border-t border-border pt-4">
      <DangerAction
        label="Recreate default routing"
        confirmLabel="Rebuild default routing"
        consequence={
          plan.changes.length
            ? "Adds only the rules that are missing and never edits, retargets or deletes one you "
              + "wrote. It does move rules: receipts and inbound above outbound, any catch-all last."
            : "Nothing is missing — there is nothing for this to write."
        }
        tone="caution"
        busy={busy}
        disabled={!plan.changes.length}
        extra={(
          <div className="space-y-3">
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="dr-mt">Outbound messages go to</Label>
                <Select id="dr-mt" value={mtTarget} onChange={(e) => setMtTarget(e.target.value)}>
                  <option value="">— leave the outbound lane alone</option>
                  {chainTargets.map((n) => (
                    <option key={`t-${n}`} value={n}>{n} (routing table)</option>
                  ))}
                  {vendorTargets.map((n) => (
                    <option key={`v-${n}`} value={n}>{n} (vendor)</option>
                  ))}
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="dr-mo">Inbound messages go to</Label>
                <Select id="dr-mo" value={moTarget} onChange={(e) => setMoTarget(e.target.value)}>
                  <option value="">— leave the inbound lane alone</option>
                  {listenerTargets.map((n) => (
                    <option key={n} value={n}>{n} (listener)</option>
                  ))}
                </Select>
              </div>
            </div>
            <div>
              <p className="mb-1 text-xs font-medium text-muted-foreground">What this will do</p>
              <ul className="list-disc space-y-1 pl-5 text-xs text-muted-foreground">
                {plan.changes.map((c) => <li key={c}>{c}</li>)}
                {!plan.changes.length && <li>Nothing — default routing is already complete.</li>}
              </ul>
            </div>
          </div>
        )}
        onConfirm={apply}
      />
      {error && <p className="text-sm text-destructive">{error}</p>}
      {done && <p className="text-sm text-muted-foreground">{done}</p>}
    </div>
  );
}
