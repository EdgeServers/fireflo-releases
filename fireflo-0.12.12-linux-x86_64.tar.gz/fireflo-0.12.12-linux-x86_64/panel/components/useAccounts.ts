"use client";
import { useCallback, useEffect, useState } from "react";
import type { AccountInput, AccountSummary, OrphanAccount } from "@/lib/account-types";
import { surface } from "@/lib/panel-surface";

/**
 * The account catalogue, and the ids in use that are not in it.
 *
 * <p>Shaped like `useProducts`, minus the gateway push: nothing reads `app_account`, so a change
 * here is complete the moment the row is written and there is no "within thirty seconds" to explain.
 * That is also the thing the UI must not let anyone forget — disabling an account changes this
 * panel's lists and nothing about whether the customer can send.
 */
export function useAccounts() {
  const [accounts, setAccounts] = useState<AccountSummary[]>([]);
  const [orphans, setOrphans] = useState<OrphanAccount[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");

  const load = useCallback(async () => {
    try {
      const res = await fetch(`${surface().apiBase}/accounts/catalogue`, { cache: "no-store" });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      setAccounts(json.data.accounts as AccountSummary[]);
      setOrphans(json.data.orphans as OrphanAccount[]);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const save = useCallback(
    async (input: AccountInput): Promise<boolean> => {
      setBusy(input.id);
      try {
        const res = await fetch(`${surface().apiBase}/accounts/catalogue`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(input),
        });
        const json = await res.json().catch(() => null);
        if (!res.ok) {
          setError(json?.error ?? `Request failed (${res.status})`);
          return false;
        }
        setError("");
        await load();
        return true;
      } finally {
        setBusy("");
      }
    },
    [load]
  );

  const remove = useCallback(
    async (id: string) => {
      setBusy(id);
      try {
        const res = await fetch(
          `${surface().apiBase}/accounts/catalogue/${encodeURIComponent(id)}`,
          { method: "DELETE" }
        );
        if (!res.ok) {
          const json = await res.json().catch(() => null);
          setError(json?.error ?? `Request failed (${res.status})`);
          return;
        }
        setError("");
        await load();
      } finally {
        setBusy("");
      }
    },
    [load]
  );

  return { accounts, orphans, error, loading, busy, load, save, remove };
}
