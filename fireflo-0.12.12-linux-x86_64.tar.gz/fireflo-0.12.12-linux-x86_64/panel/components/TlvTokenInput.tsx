"use client";
import { useId } from "react";
import { Input } from "@/components/ui/input";
import {
  type TlvDefinition,
  resolveTlv,
  tlvSuggestions,
  tlvTag,
} from "@/lib/tlv-catalogue";

/**
 * A `<name>_<tag>` TLV token, with what the tag means shown beside it.
 *
 * <p><strong>An input with a datalist, never a select.</strong> The gateway accepts any tag from
 * 0x0000 to 0xFFFF, so a dropdown would make an undefined tag unenterable and turn a naming aid into
 * a whitelist. The suggestions only put text into the field; nothing here reads the catalogue to
 * decide whether a value is allowed.
 *
 * <p>Two states that look alike and are not:
 *
 * <ul>
 *   <li><strong>Unparseable</strong> — warned about, because `TlvUtil.parseDeclarations` logs it and
 *       skips it, so the setting silently does nothing. Still saveable.</li>
 *   <li><strong>Parseable but unnamed</strong> — not a problem at all. No red, no `aria-invalid`,
 *       nothing blocking. Most tags mean nothing to anyone and a vendor using one is doing something
 *       entirely legal.</li>
 * </ul>
 *
 * <p>The operator's own token is never rewritten. `peid_0x1400` is what the gateway echoes in its
 * logs, so the catalogue name goes <em>beside</em> it rather than replacing it — otherwise the panel
 * and the log would disagree about the same setting.
 */
export function TlvTokenInput({
  value,
  onChange,
  definitions = [],
  suggested = {},
  placeholder = "name_0x1400",
  ariaLabel,
  className,
}: {
  value: string;
  onChange: (value: string) => void;
  /** Operator-defined names. Empty until the definitions table exists. */
  definitions?: readonly TlvDefinition[];
  /** Which tags to offer. A tag with no entry is offered; an empty map is the whole catalogue. */
  suggested?: Record<number, boolean>;
  placeholder?: string;
  ariaLabel?: string;
  className?: string;
}) {
  //one datalist per instance: a module-global id would be duplicated across every TLV row on the
  //page, and duplicate ids are invalid HTML that browsers resolve unpredictably
  const listId = useId();
  const suggestions = tlvSuggestions(definitions, suggested);

  const trimmed = value.trim();
  const tag = tlvTag(trimmed);
  const resolved = resolveTlv(tag, definitions);

  return (
    <div className={className}>
      <Input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        aria-label={ariaLabel}
        list={listId}
        className="font-mono"
        autoComplete="off"
      />
      <datalist id={listId}>
        {suggestions.map((token) => (
          <option key={token} value={token} />
        ))}
      </datalist>
      <TlvHint token={trimmed} tag={tag} resolved={resolved} />
    </div>
  );
}

/**
 * What is known about the tag in a token, in one line.
 *
 * <p>Exported because the message detail view wants the same resolution without an input around it.
 */
export function TlvHint({
  token,
  tag,
  resolved,
}: {
  token: string;
  tag: number | null;
  resolved: ReturnType<typeof resolveTlv>;
}) {
  if (!token) {
    return null;
  }

  if (tag == null) {
    return (
      <p className="mt-1 text-sm text-amber-600 dark:text-amber-400">
        No tag here — the gateway reads the digits after the last underscore, in decimal unless
        written <code>0x</code>. It will log this and skip it, so the setting would do nothing.
      </p>
    );
  }

  const hex = `0x${tag.toString(16).toUpperCase().padStart(4, "0")}`;

  if (!resolved) {
    return (
      <p className="mt-1 text-xs text-muted-foreground">
        {hex} · {tag} — not in the catalogue, which is fine. The gateway takes any tag; only the
        number reaches the wire.
      </p>
    );
  }

  return (
    <div className="mt-1 space-y-0.5 text-sm">
      <p className="flex flex-wrap items-center gap-1.5">
        <span className="text-muted-foreground">{hex} · {tag}</span>
        <span className="font-medium">{resolved.label}</span>
        <TlvSourceChip provenance={resolved.provenance} />
      </p>
      {resolved.shadows && (
        <p className="text-amber-600 dark:text-amber-400">
          Renamed here — {resolved.shadows.provenance === "spec" ? "the SMPP spec" : "convention"}{" "}
          calls this <code>{resolved.shadows.name}</code>.
        </p>
      )}
      {resolved.note && <p className="text-muted-foreground">{resolved.note}</p>}
    </div>
  );
}

/** Where a name came from — the difference between the spec, an agreement and a colleague. */
export function TlvSourceChip({ provenance }: { provenance: "spec" | "convention" | "operator" }) {
  const style =
    provenance === "spec"
      ? "border-border text-muted-foreground"
      : provenance === "convention"
        ? "border-amber-500/40 text-amber-600 dark:text-amber-400"
        : "border-primary/30 text-primary";
  const text =
    provenance === "spec" ? "SMPP spec" : provenance === "convention" ? "Convention" : "Defined here";
  return (
    <span className={`rounded-full border px-1.5 py-0.5 text-2xs font-medium ${style}`}>
      {text}
    </span>
  );
}
