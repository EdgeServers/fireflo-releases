"use client";
import Link from "next/link";
import { ArrowRight, Cpu, Gauge, Layers, Network, Timer, Waves } from "lucide-react";
import { Card, CardContent, CardTitle } from "@/components/ui/card";
import { HealthStrip } from "./CardBits";
import { Sparkline } from "./Sparkline";
import { useRuntimeMetrics, type HistoryPoint } from "./useRuntimeMetrics";
import { bytes, count, duration, latency, ratio } from "@/lib/format";

/**
 * How hard the gateway process is working, on the overview page.
 *
 * <p><strong>Not SMS traffic.</strong> The messages, delivery and margin numbers above answer the
 * business question; this answers whether the software carrying them has the room to keep going.
 *
 * <p>Six tiles, and the detail is a click away — the full set of readings below the revenue figures
 * would bury them. Note "Internal tasks" is the gateway's own background work and NOT vendor
 * connections; the word "worker" is deliberately avoided here because it means an SMPP connection
 * everywhere else in this panel.
 */
export function RuntimeSummary() {
  const { snapshot, history, error, loading } = useRuntimeMetrics();
  const h = snapshot?.headline;

  return (
    <section className="space-y-3">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <div>
          <CardTitle>Gateway health</CardTitle>
          <p className="text-sm text-muted-foreground">
            Whether the software has the room to keep working. Message throughput is above.
          </p>
        </div>
        <Link
          href="/cp/metrics"
          className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
        >
          Runtime detail <ArrowRight className="h-3 w-3" />
        </Link>
      </div>

      {error && !snapshot ? (
        <HealthStrip tone="destructive">{error}</HealthStrip>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
          <Tile
            label="Memory"
            icon={Layers}
            value={h ? bytes(h.heapUsed) : "—"}
            hint={h ? `of ${bytes(h.heapMax)} · ${ratio(h.heapUsed / h.heapMax)}` : undefined}
            loading={loading}
            series={history.map((p) => p.heapUsed)}
            color="var(--color-chart-1)"
          />
          <Tile
            label="Processor"
            icon={Cpu}
            value={h ? ratio(h.processCpu) : "—"}
            hint={h ? `whole machine ${ratio(h.systemCpu)}` : undefined}
            loading={loading}
            series={history.map((p) => p.processCpu)}
            color="var(--color-chart-2)"
          />
          <Tile
            label="Tasks running"
            icon={Waves}
            value={h?.threadsLive != null ? count(h.threadsLive) : "—"}
            hint={h ? `most ever ${count(h.threadsPeak ?? 0)}` : undefined}
            loading={loading}
            series={history.map((p) => p.threadsLive)}
            color="var(--color-chart-3)"
          />
          <Tile
            label="API requests"
            icon={Network}
            value={rate(history)}
            //mean since the process started, not a live figure -- a summary carries a running
            //total, so it cannot describe the last minute
            hint={h ? `typically ${latency(h.httpMeanLatency)}` : undefined}
            loading={loading}
            series={history.map((p) => p.httpRate)}
            color="var(--color-chart-4)"
          />
          <Tile
            label="Internal tasks"
            icon={Gauge}
            value={h?.workerActive != null ? `${count(h.workerActive)} busy` : "—"}
            hint={h ? `${count(h.workerQueued ?? 0)} waiting · not vendor connections` : undefined}
            loading={loading}
            series={history.map((p) => p.workerQueued)}
            color="var(--color-chart-5)"
          />
          <Tile
            label="Uptime"
            icon={Timer}
            value={h?.uptimeSeconds != null ? duration(h.uptimeSeconds) : "—"}
            hint={h ? `${count(h.gcPauseCount)} cleanup pauses` : undefined}
            loading={loading}
            series={[]}
            color="var(--color-chart-6)"
          />
        </div>
      )}

      {error && snapshot && (
        //the last good snapshot is still on screen, so this is a footnote rather than a failure
        <p className="text-sm text-muted-foreground">Last poll failed: {error}</p>
      )}
    </section>
  );
}

/** @returns requests per second over the last poll, or a dash until two samples exist */
function rate(history: HistoryPoint[]): string {
  const latest = history[history.length - 1]?.httpRate;
  return latest == null ? "—" : `${latest < 10 ? latest.toFixed(1) : latest.toFixed(0)}/s`;
}

function Tile({
  label,
  icon: Icon,
  value,
  hint,
  loading,
  series,
  color,
}: {
  label: string;
  icon: React.ElementType;
  value: string;
  hint?: string;
  loading: boolean;
  series: (number | null)[];
  color: string;
}) {
  return (
    <Card className="min-w-0">
      <CardContent className="space-y-2 py-4">
        <div className="flex items-center justify-between gap-2">
          <span className="text-sm font-medium text-muted-foreground">{label}</span>
          <Icon className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
        </div>
        {loading ? (
          <div className="h-7 w-20 animate-pulse rounded bg-muted" />
        ) : (
          <p className="text-2xl font-semibold tabular-nums">{value}</p>
        )}
        {hint && <p className="truncate text-sm text-muted-foreground">{hint}</p>}
        <Sparkline values={series} color={color} className="h-6 w-full" />
      </CardContent>
    </Card>
  );
}
