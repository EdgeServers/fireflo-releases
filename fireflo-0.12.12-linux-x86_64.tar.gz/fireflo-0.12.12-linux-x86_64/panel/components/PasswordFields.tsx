"use client";
import { useId, useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { MIN_LENGTH, assessPassword } from "@/lib/password-policy";

/**
 * A new password, typed twice, with a meter that says what the server will say.
 *
 * <p>Every place a password is set uses this -- an admin creating or resetting a user, an operator
 * changing their own, and the portal's set-password page -- so the rule lives once, in
 * `lib/password-policy.ts`, and the meter here runs the identical function the API route runs. A
 * meter that calls a password strong and a server that then refuses it is worse than no meter.
 *
 * <p>Controlled: the parent owns the value, because it is the parent that submits. {@link ready}
 * is the one bit the parent needs for its button: both fields agree and the policy accepts.
 */
export function PasswordFields({
  value,
  onChange,
  email,
  autoFocus,
  labels = { password: "New password", confirm: "Confirm new password" },
  autoComplete = "new-password",
}: {
  value: string;
  onChange: (password: string, ready: boolean) => void;
  /** Judged against, so the address is not accepted as its own password. */
  email?: string | null;
  autoFocus?: boolean;
  labels?: { password: string; confirm: string };
  autoComplete?: "new-password" | "off";
}) {
  const [confirm, setConfirm] = useState("");
  const [visible, setVisible] = useState(false);
  const id = useId();

  const verdict = assessPassword(value, email);
  const matches = confirm.length > 0 && confirm === value;
  const mismatch = confirm.length > 0 && confirm !== value;

  function update(next: string, nextConfirm: string) {
    const v = assessPassword(next, email);
    onChange(next, v.acceptable && nextConfirm === next && next.length > 0);
  }

  return (
    <div className="space-y-3">
      <div className="space-y-1.5">
        <Label htmlFor={`${id}-pw`}>{labels.password}</Label>
        <div className="relative">
          <Input
            id={`${id}-pw`}
            name="new-password"
            type={visible ? "text" : "password"}
            value={value}
            autoFocus={autoFocus}
            autoComplete={autoComplete}
            onChange={(e) => {
              update(e.target.value, confirm);
            }}
            className="pr-9"
          />
          <button
            type="button"
            onClick={() => setVisible((v) => !v)}
            tabIndex={-1}
            aria-label={visible ? "Hide password" : "Show password"}
            aria-pressed={visible}
            className="absolute inset-y-0 right-0 flex w-9 items-center justify-center rounded-r-md text-muted-foreground transition-colors hover:text-foreground"
          >
            {visible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>
        <Meter score={verdict.score} label={verdict.label} empty={value.length === 0} />
        <p className="text-xs text-muted-foreground">
          {value.length === 0
            ? `At least ${MIN_LENGTH} characters. A few unrelated words beat a short jumble.`
            : verdict.warnings[0] ?? (verdict.acceptable ? "Fine." : `At least ${MIN_LENGTH} characters.`)}
        </p>
      </div>

      <div className="space-y-1.5">
        <Label htmlFor={`${id}-confirm`}>{labels.confirm}</Label>
        <Input
          id={`${id}-confirm`}
          name="confirm-password"
          type={visible ? "text" : "password"}
          value={confirm}
          autoComplete={autoComplete}
          aria-invalid={mismatch || undefined}
          onChange={(e) => {
            setConfirm(e.target.value);
            update(value, e.target.value);
          }}
          className={cn(mismatch && "border-destructive focus-visible:ring-destructive")}
        />
        {mismatch && <p className="text-xs text-destructive">The two do not match.</p>}
        {matches && verdict.acceptable && <p className="text-xs text-muted-foreground">Matches.</p>}
      </div>
    </div>
  );
}

const TONES = ["bg-destructive", "bg-destructive", "bg-amber-500", "bg-emerald-500", "bg-emerald-600"];

function Meter({ score, label, empty }: { score: number; label: string; empty: boolean }) {
  return (
    <div className="flex items-center gap-2" aria-live="polite">
      <div className="flex flex-1 gap-1" role="meter" aria-valuemin={0} aria-valuemax={4} aria-valuenow={empty ? 0 : score} aria-label="Password strength">
        {[1, 2, 3, 4].map((n) => (
          <span
            key={n}
            className={cn("h-1.5 flex-1 rounded-full bg-muted transition-colors", !empty && n <= Math.max(1, score) && TONES[score])}
          />
        ))}
      </div>
      <span className="w-16 text-right text-xs text-muted-foreground">{empty ? "" : label}</span>
    </div>
  );
}
