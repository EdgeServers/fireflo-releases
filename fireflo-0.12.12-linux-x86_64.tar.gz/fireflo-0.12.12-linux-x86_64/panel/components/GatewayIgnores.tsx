"use client";
import { Card, CardContent } from "@/components/ui/card";
import { useHealth } from "./useHealth";
import {
  readsRatesFromDatabase,
  readsRoutingFromDatabase,
  readsWorkersFromDatabase,
  whitelistActive,
  whitelistEnabled,
} from "@/lib/health-types";

/**
 * "Nothing on this page is in use."
 *
 * <p>The gateway reads configuration from either files or the database, and the panel always writes
 * the database. So a page can be editing rows the gateway has never read — stored, valid and
 * ignored — and nothing about the page says so. That is how a demo vendor imported from an example
 * file came to be listed as a customer for weeks: the rate table the panel showed was not the rate
 * table the gateway was pricing from.
 *
 * <p><strong>One switch now, not four.</strong> `FIREFLO_CONFIG_SOURCE` moves every domain together,
 * so these notices no longer appear one at a time — but they are still written per domain, because
 * "the gateway is pricing from rates.conf" is what the reader of this page needs to know, not
 * "configuration is file-sourced".
 *
 * <p>The switch is a bootstrap setting the gateway reads before it opens the database, so the panel
 * cannot query it. It can only be reported, and `/ops/health` reports it.
 *
 * <p><strong>Renders nothing on `undefined`.</strong> Health that could not be read is not evidence
 * of anything, and a warning that appears when the gateway is merely unreachable is a warning
 * everybody learns to scroll past — which would cost more than it saves on the day it is true.
 */
export function GatewayIgnores({ domain }: { domain: "rates" | "workers" | "whitelist" | "routing" }) {
  const { health } = useHealth();

  if (domain === "whitelist") {
    return <WhitelistNotice health={health} />;
  }

  const reading = domain === "rates"
    ? readsRatesFromDatabase(health)
    : domain === "routing"
      ? readsRoutingFromDatabase(health)
      : readsWorkersFromDatabase(health);
  if (reading !== false) {
    return null;
  }

  return (
    <Card className="border-amber-500/40">
      <CardContent className="py-3 text-sm">
        {domain === "routing" ? (
          <>
            {/* the one domain where "stored and ignored" is the safer half: an incomplete routing
                table in use means messages with nowhere to go */}
            <strong>Nothing on this page is in use.</strong> The gateway is routing from its
            <code className="mx-1 text-sm">routingTable.conf</code> file, not the database — these
            tables are stored, valid and ignored. Before restarting it with
            <code className="mx-1 text-sm">FIREFLO_CONFIG_SOURCE=db</code>, check these tables
            against that file: routing decides where every message goes, and a table that is merely
            close sends traffic to the wrong vendor without erroring.
          </>
        ) : domain === "rates" ? (
          <>
            <strong>Nothing on this page is in use.</strong> The gateway is pricing from its
            <code className="mx-1 text-sm">rates.conf</code> file, not the database — these rules are
            stored, valid and ignored. Restart it with
            <code className="mx-1 text-sm">FIREFLO_CONFIG_SOURCE=db</code> to use them — which moves
            logins, routing and vendor settings to the database at the same time.
          </>
        ) : (
          <>
            <strong>Nothing on this page is in use.</strong> The gateway is reading its workers from
            <code className="mx-1 text-sm">smsg.properties</code>, not the database — these settings
            are stored, valid and ignored. Restart it with
            <code className="mx-1 text-sm">FIREFLO_CONFIG_SOURCE=db</code> to use them — which moves
            logins, routing and pricing to the database at the same time.
          </>
        )}
      </CardContent>
    </Card>
  );
}

/**
 * Whitelisting has two ways of being inert, and they need different fixes.
 *
 * <p>Off is a choice: the tables are populated and nothing is checked. Loaded-never is an outage of
 * a kind that looks like nothing at all — the gateway was told to enforce, cannot read the tables,
 * and therefore allows everything. The second is the more alarming and the less visible.
 */
function WhitelistNotice({ health }: { health: Parameters<typeof whitelistEnabled>[0] }) {
  const enabled = whitelistEnabled(health);
  const active = whitelistActive(health);

  if (enabled === undefined) {
    return null;
  }
  if (enabled === false) {
    //`smsg.whitelist.enabled` is a PROPERTY, not an environment variable, so how it is set and
    //whether a restart is needed both depend on where properties come from. This said "Restart it"
    //unconditionally, which is wrong in database mode -- the gateway re-reads the key every
    //configuration poll -- and told operators to take an outage they did not need
    const fromDatabase = readsWorkersFromDatabase(health);
    return (
      <Card className="border-amber-500/40">
        <CardContent className="py-3 text-sm">
          <strong>Nothing here is being enforced.</strong> Sender ID and content whitelisting is
          switched off on the gateway, so every approval below is recorded and ignored. Set
          <code className="mx-1 text-sm">smsg.whitelist.enabled=true</code>
          {fromDatabase === true
            ? " in the gateway's configuration table; it takes effect within one poll, without a restart."
            : fromDatabase === false
              ? " in smsg.properties and restart the gateway."
              : " on the gateway — in smsg.properties with a restart, or in its configuration table if it reads configuration from the database."}
          <span className="mt-1 block text-sm text-muted-foreground">
            {/* the reason this is a safe button to press, and worth saying: operators hesitate over
                a switch that sounds like it starts refusing traffic everywhere at once */}
            Switching it on checks nothing by itself. Only accounts that carry a policy are enforced.
          </span>
        </CardContent>
      </Card>
    );
  }
  if (active === false) {
    return (
      <Card className="border-destructive">
        <CardContent className="py-3 text-sm text-destructive">
          <strong>Whitelisting is switched on but has never loaded.</strong> The gateway cannot read
          the approval tables, so it is allowing everything rather than refusing it — which is the
          safe direction, and means nothing below is in force. Check its database connection and its
          log.
        </CardContent>
      </Card>
    );
  }
  return null;
}
