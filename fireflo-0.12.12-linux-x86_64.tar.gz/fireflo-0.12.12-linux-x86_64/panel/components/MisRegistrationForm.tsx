"use client";
import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DangerAction } from "./DangerAction";
import { TlvPairsEditor } from "./TlvPairsEditor";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useApiAccess } from "./useApiAccess";
import { formatTlvCsv, parseTlvCsv, tlvCsvProblem, type TlvPair } from "@/lib/tlv-string";
import type { RegistrationKind } from "./MisRegistrationsClient";
import {
  hasRepeatingSegments,
  previewTemplate,
  validateHeader,
  validateTemplate,
  VARIABLE,
} from "@/lib/whitelist-types";
import type { ApprovedHeader, ApprovedTemplate } from "@/lib/whitelist-types";

type Row = (ApprovedHeader | ApprovedTemplate) & { header?: string; body?: string };

/**
 * Asking for a sender ID or some wording, and changing one already asked for.
 *
 * <p>Validates with the same functions the operator's forms use, which are the same rejections the
 * gateway makes when it loads the row — so wording that could never match is refused here rather
 * than approved and then silently skipped at load.
 *
 * <h2>Stamps are proposed, not set</h2>
 *
 * <p>Under DLT the stamped TLVs carry the registered entity and template ids, and the gateway writes
 * them over whatever the client claimed — that overwrite <em>is</em> the approval. So this form
 * writes `requestedTlvs`, a column nothing on the message path reads, and an operator either moves
 * it across or clears it. A customer who could write the served column could assert somebody else's
 * registration while sending approved wording, which is the exact thing approval exists to prevent.
 *
 * <p>The upside, and the reason to say it on screen: proposing costs nothing. It changes nothing the
 * gateway serves, so an approved registration keeps working while the operator considers it.
 *
 * <h2>The warning</h2>
 *
 * <p>Editing the wording or the note of something approved sends it back for approval, so it stops
 * being usable until an operator acts. A new request costs nothing and is saved with an ordinary
 * button; an edit to a live registration arms first, and says what it costs — including the case
 * where it is the last one and the account will not be able to send at all.
 *
 * <p><strong>Changing only the proposed stamps does not arm the warning</strong>, because it does not
 * suspend anything. The form works that out the same way the route does — by comparing against the
 * row it was opened on — so the two cannot disagree about what a save is about to cost.
 */
export function MisRegistrationForm({
  kind,
  row,
  scope,
  approvedCount,
  onCancel,
  onSaved,
}: {
  kind: RegistrationKind;
  /** Null for a new request. */
  row: Row | null;
  /**
   * Every account this session may see: itself first, then its children.
   *
   * <p>Longer than one only for a reseller that holds somebody. When it is, a new request may be
   * made **on a child's behalf** — the route puts the named account through `assertInScope` before
   * it is used for anything, so this select is a convenience over a check that happens server-side
   * either way.
   *
   * <p>Only on a new request. Moving an existing registration between accounts is not an edit, it
   * is a different registration: the approval, the login it is bound to and the stamps an operator
   * decided all belong to the account it was asked for.
   */
  scope: string[];
  /** How many of this account's registrations are live, for the strength of the warning. */
  approvedCount: number;
  onCancel: () => void;
  onSaved: (message: string) => void | Promise<void>;
}) {
  const senders = kind === "senders";
  const [value, setValue] = useState(senders ? (row?.header ?? "") : (row?.body ?? ""));
  const [name, setName] = useState(
    !senders && row && "name" in row ? ((row as ApprovedTemplate).name ?? "") : ""
  );
  const [requestNote, setRequestNote] = useState(row?.requestNote ?? "");
  //seeded from the proposal if one is outstanding, otherwise from what is already approved -- a
  //customer asking to change a stamp starts from the value in use rather than from an empty box
  const [tlvPairs, setTlvPairs] = useState<TlvPair[]>(
    () => parseTlvCsv(row?.requestedTlvs ?? row?.tlvs)
  );
  const [systemId, setSystemId] = useState(row?.systemId ?? "");
  //the session's own account is first in `scope`, so this defaults to "for myself"
  const [account, setAccount] = useState(row?.accountId ?? scope[0] ?? "");
  const self = scope[0] ?? "";
  //a reseller with children, making a NEW request. An edit keeps the account it was asked for
  const canChooseAccount = !row && scope.length > 1;
  const forChild = account !== "" && account !== self;
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  //the same list the API pages use, so the portal asks for its logins once and in one shape
  const { access } = useApiAccess();
  const logins = (access?.rotatable ?? []).map((l) => l.systemId);

  const invalid = useMemo(
    () => (value.trim() ? (senders ? validateHeader(value) : validateTemplate(value)) : null),
    [value, senders]
  );
  const preview = useMemo(
    () => (!senders && value.trim() && !invalid ? previewTemplate(value) : null),
    [value, senders, invalid]
  );
  const repeating = useMemo(
    () => (!senders && value.trim() && !invalid ? hasRepeatingSegments(value) : false),
    [value, senders, invalid]
  );

  const requestedTlvs = formatTlvCsv(tlvPairs);
  const tlvProblem = tlvCsvProblem(requestedTlvs);

  //the route's rule, applied here so the warning matches what the save will actually do: only the
  //wording and the note suspend a row. A proposal changes nothing that is served
  const original = senders ? (row?.header ?? "") : (row?.body ?? "");
  const changesWhatIsServed =
    value.trim() !== original
    || (requestNote.trim() || null) !== (row?.requestNote ?? null)
    || (!senders && (name.trim() || null) !== ((row as ApprovedTemplate | null)?.name ?? null))
    //the login IS what is served against, so changing it changes what the gateway matches -- the
    //same reason the wording suspends, and not at all the same as a TLV proposal
    || (systemId.trim() || null) !== (row?.systemId ?? null);

  //live means approved AND not withdrawn: editing something already out of service costs nothing
  const wasLive = row?.status === "APPROVED" && row.enabled && changesWhatIsServed;
  const lastOne = wasLive && approvedCount <= 1;

  async function save() {
    setBusy(true);
    setError("");
    try {
      const payload = senders
        ? { header: value.trim(), requestNote, requestedTlvs, systemId, accountId: account }
        : { body: value.trim(), name, requestNote, requestedTlvs, systemId, accountId: account };
      const res = await fetch(
        row ? `/api/mis/${kind}/${row.id}` : `/api/mis/${kind}`,
        {
          method: row ? "PUT" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? "That did not save.");
        return;
      }
      await onSaved(json?.data?.message ?? "Sent for approval.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "That did not save.");
    } finally {
      setBusy(false);
    }
  }

  const consequence = lastOne
    ? "This stops being usable until an operator approves the change — and it is your only one in "
      + "use, so nothing will be accepted from this account until then."
    : "This stops being usable until an operator approves the change.";

  return (
    <div className="space-y-3">
      {senders ? (
        <div>
          <Label htmlFor="mis-header" className="mb-1 block text-xs">Sender ID</Label>
          <Input id="mis-header" value={value} onChange={(e) => setValue(e.target.value)}
            className="h-8 font-mono" placeholder="ACMEIN" />
        </div>
      ) : (
        <>
          <div>
            <Label htmlFor="mis-name" className="mb-1 block text-xs">Name</Label>
            <Input id="mis-name" value={name} onChange={(e) => setName(e.target.value)}
              className="h-8" placeholder="Order shipped" />
            <p className="mt-1 text-xs text-muted-foreground">
              For you and your operator to recognise it. Not matched against anything.
            </p>
          </div>
          <div>
            <Label htmlFor="mis-body" className="mb-1 block text-xs">Wording</Label>
            <Textarea
              id="mis-body"
              rows={4}
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder={`Dear ${VARIABLE}, your order has shipped.`}
            />
            <p className="mt-1 text-xs text-muted-foreground">
              Put <code className="text-xs">{VARIABLE}</code> where the message changes — a name, a
              code, an order number. Everything else has to match exactly.
            </p>
          </div>
        </>
      )}

      {/* the preview is the point of this form: it shows what will actually be accepted */}
      {preview && (
        <div className="rounded-md border border-border bg-muted/40 p-3 text-sm">
          <p className="text-2xs font-semibold uppercase tracking-wide text-muted-foreground">This accepts</p>
          <p className="mt-1">{preview}</p>
        </div>
      )}
      {repeating && (
        <p className="text-sm text-amber-600 dark:text-amber-400">
          This wording repeats itself around the changing part, which can make it match less than you
          expect. Worth checking with your operator.
        </p>
      )}

      <div>
        <Label htmlFor="mis-note" className="mb-1 block text-xs">
          Note for your operator
        </Label>
        <Input id="mis-note" value={requestNote} onChange={(e) => setRequestNote(e.target.value)}
          className="h-8" placeholder="Registration reference, if you have one" />
        <p className="mt-1 text-xs text-muted-foreground">
          If this is registered with a regulator, put the reference here. Your operator sets the
          value the gateway sends — you do not need to.
        </p>
      </div>

      {canChooseAccount && (
        <div>
          <Label htmlFor="mis-account" className="mb-1 block text-xs">Who this is for</Label>
          <Select
            id="mis-account"
            value={account}
            onChange={(e) => {
              //a login picked before switching account is one of YOUR logins, and the route scopes
              //the registration to the subject's own -- carrying it across would send a value the
              //server has to refuse. Cleared here rather than ignored at save, so the form and the
              //request never disagree about what was asked for
              setAccount(e.target.value);
              setSystemId("");
            }}
            className="h-8"
          >
            {scope.map((a) => (
              <option key={a} value={a}>{a === self ? `${a} (you)` : a}</option>
            ))}
          </Select>
          <p className="mt-1 text-xs text-muted-foreground">
            {forChild
              ? "It is registered against their account, and your operator approves it before they "
                + "can send with it."
              : "Your own account. Pick one of your customers to ask on their behalf."}
          </p>
        </div>
      )}

      {/*offered only when there is a choice to make. One login is every account's ordinary shape,
         and a select with one option beside "all of them" is a decision nobody needs to take.

         Never for a child: this list is THIS account's logins, and the route scopes the registration
         to the subject's own -- so offering one of yours here would produce a refusal you could not
         act on. A child's registration covers all of its logins, which is the right default anyway*/}
      {!forChild && logins.length > 1 && (
        <div>
          <Label htmlFor="mis-login" className="mb-1 block text-xs">Which login</Label>
          <Select id="mis-login" value={systemId} onChange={(e) => setSystemId(e.target.value)}
            className="h-8">
            <option value="">All my logins</option>
            {logins.map((l) => <option key={l} value={l}>{l}</option>)}
          </Select>
          <p className="mt-1 text-xs text-muted-foreground">
            Leave this on <strong>All my logins</strong> unless you know you want otherwise. Bound to
            one, this registration does nothing for the others — and a login with nothing approved
            for it can send nothing at all.
          </p>
        </div>
      )}

      <div>
        <Label className="mb-1 block text-xs">Stamps to ask for</Label>
        <p className="mb-2 text-xs text-muted-foreground">
          The values your operator attaches to every message on this registration — under DLT, your
          entity and template ids. <strong>Asking is free:</strong> nothing here reaches a message
          until your operator accepts it, so an approved registration keeps working meanwhile.
        </p>
        <TlvPairsEditor
          pairs={tlvPairs}
          onChange={setTlvPairs}
          addLabel="Add a stamp"
          valuePlaceholder="1401778070000018542"
          disabled={busy}
        />
        {row?.requestedTlvs && (
          <p className="mt-1 text-xs text-muted-foreground">
            You have already asked for this and your operator has not answered yet. Saving replaces
            what they will see.
          </p>
        )}
      </div>

      {invalid && <p className="text-sm text-destructive">{invalid}</p>}
      {tlvProblem && <p className="text-sm text-destructive">{tlvProblem}</p>}
      {error && <p className="text-sm text-destructive">{error}</p>}

      <div className="flex flex-wrap items-center gap-2 pt-1">
        {wasLive ? (
          <DangerAction
            label="Save and send for approval"
            confirmLabel="Send for approval"
            tone="caution"
            consequence={consequence}
            busy={busy}
            disabled={Boolean(invalid) || Boolean(tlvProblem) || !value.trim()}
            onConfirm={save}
          />
        ) : (
          <Button
            size="sm"
            disabled={busy || Boolean(invalid) || Boolean(tlvProblem) || !value.trim()}
            onClick={save}
          >
            {/*a proposal-only save is not "sending for approval" -- nothing goes out of service and
               nothing is waiting on the operator before the registration works again*/}
            {busy ? "Saving…" : row && !changesWhatIsServed ? "Save" : "Send for approval"}
          </Button>
        )}
        <Button size="sm" variant="ghost" onClick={onCancel} disabled={busy}>
          Cancel
        </Button>
      </div>
    </div>
  );
}
