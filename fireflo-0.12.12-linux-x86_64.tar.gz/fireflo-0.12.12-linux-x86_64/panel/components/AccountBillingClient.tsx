"use client";
import { useEffect, useMemo, useState } from "react";
import { Bar, BarChart, CartesianGrid, Cell, XAxis, YAxis } from "recharts";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { Segmented } from "@/components/ui/segmented";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { RechargeLog } from "./AccountContextCard";
import { CreditActions } from "./CreditActions";
import { ReconcileCard } from "./ReconcileCard";
import { useAccountContext } from "./useAccountContext";
import type { LedgerEntry } from "@/lib/account-context-types";
import { count, money } from "@/lib/format";
import { mtProducts, mtSeries, type MtUsage } from "@/lib/mt-usage";
import { surface } from "@/lib/panel-surface";

const ANIMATION = { isAnimationActive: false } as const;

const chartConfig = {
  mtParts: { label: "MT parts", color: "var(--color-chart-1)" },
} satisfies ChartConfig;

const WINDOWS = [
  { value: "7", label: "7 days" },
  { value: "30", label: "30 days" },
  { value: "90", label: "90 days" },
] as const;

/**
 * What this account holds, what it has sent, and whether the money adds up.
 *
 * <p>One card across the top answers the two questions somebody opens this tab with — how much is
 * left, and how much has gone out — side by side: the balance on the left with the actions that
 * change it, MT parts on the right. Usage over time and the reconciliation share the row beneath,
 * and the ledger runs the full width at the bottom.
 */
export function AccountBillingClient({ id }: { id: string }) {
  const { context, loading, reload } = useAccountContext(id);
  const usage = useMtUsage(id);
  const balance = context?.balance ?? null;
  const currency = balance?.currency ?? "";

  return (
    <div className="space-y-4">
      <Card className="grid overflow-hidden md:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
        <section className="min-w-0 p-5 max-sm:p-4">
          {loading && !context ? (
            <p className="text-muted-foreground">Loading…</p>
          ) : balance ? (
            <BalanceHalf balance={balance} ledger={context?.ledger?.entries ?? []} usage={usage.data} />
          ) : context?.balanceMissing ? (
            <>
              <p className="text-xs font-medium text-muted-foreground">Balance</p>
              <p className="mt-1 text-sm text-amber-600 dark:text-amber-400">
                No balance row — not zero, absent. A top-up before the row exists is left pending
                rather than credited.
              </p>
            </>
          ) : (
            <p className="text-xs text-muted-foreground">The balance could not be read.</p>
          )}
          {context && (
            <div className="mt-4">
              <CreditActions
                accountId={id}
                hasRow={!context.balanceMissing && context.balance !== null}
                currency={balance?.currency ?? null}
                //the chain, not the bare gateway key: under a reseller this resolves to the
                //parent's own code, which is what stops a child being asked -- see chooseCurrency
                inheritedCurrency={context.currencyForNewBalance}
                //a reseller moves its own balance rather than issuing credit -- see CreditActions.
                //The portal's balance route refuses `topUp` by name regardless, so this decides what
                //the interface offers rather than what the server permits
                funding={surface().pricing ? "recharge" : "transfer"}
                //true for an operator; for a reseller it is that reseller's own billing mode.
                //Postpaid is a credit line and a prepaid reseller has none to pass down
                mayGrantPostpaid={context.mayGrantPostpaid}
                postpaidHeadroom={context.postpaidHeadroom}
                enabled={balance?.enabled ?? true}
                billingMode={balance?.billingMode ?? "PREPAID"}
                creditLimit={balance?.creditLimit ?? 0}
                onDone={reload}
              />
            </div>
          )}
        </section>
        <section className="min-w-0 border-t border-border p-5 max-sm:p-4 md:border-l md:border-t-0">
          <MtHalf usage={usage.data} error={usage.error} />
        </section>
      </Card>

      <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
        <MtUsageCard usage={usage.data} error={usage.error} currency={currency} />
        {context && (
          <Card>
            <CardHeader bar>
              <CardTitle>Does the credit add up?</CardTitle>
              <CardDescription>Over the account&apos;s lifetime.</CardDescription>
            </CardHeader>
            <CardContent>
              <ReconcileCard accountId={id} currency={currency} />
            </CardContent>
          </Card>
        )}
      </div>

      {context && (
        <Card>
          <CardHeader bar>
            <CardTitle>Money in and out</CardTitle>
            <CardDescription>
              Recharges and transfers. The gateway applies them on its next poll; its own credit
              reservations are counted but not listed.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <RechargeLog
              ledger={context.ledger}
              balanceMissing={context.balanceMissing}
              currency={currency}
            />
          </CardContent>
        </Card>
      )}
    </div>
  );
}

/** The account's MT usage, refetched when the account changes. */
function useMtUsage(account: string): { data: MtUsage | null; error: string } {
  const [state, setState] = useState<{ account: string; data: MtUsage | null; error: string }>(
    { account, data: null, error: "" });

  useEffect(() => {
    const controller = new AbortController();
    void (async () => {
      try {
        const res = await fetch(`${surface().apiBase}/accounts/${encodeURIComponent(account)}/usage`,
          { cache: "no-store", signal: controller.signal });
        const json = await res.json().catch(() => null);
        setState(res.ok
          ? { account, data: json?.data ?? null, error: "" }
          : { account, data: null, error: json?.error ?? `Usage could not be read (${res.status}).` });
      } catch (err) {
        if (!controller.signal.aborted) {
          setState({ account, data: null, error: err instanceof Error ? err.message : "Usage could not be read." });
        }
      }
    })();
    return () => controller.abort();
  }, [account]);

  //a reply for another account is never shown under this one's name
  return state.account === account ? state : { data: null, error: "" };
}

function BalanceHalf({
  balance,
  ledger,
  usage,
}: {
  balance: NonNullable<NonNullable<ReturnType<typeof useAccountContext>["context"]>["balance"]>;
  ledger: LedgerEntry[];
  usage: MtUsage | null;
}) {
  const currency = balance.currency ?? "";
  const postpaid = balance.billingMode === "POSTPAID";
  const lastTopUp = ledger
    .filter((e) => e.applied && e.delta > 0)
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))[0];

  return (
    <>
      {/* a div: Badge renders one, and a div inside a <p> is invalid HTML and a hydration error */}
      <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
        {postpaid ? "Credit limit" : "Available"}
        <Badge variant={postpaid ? "outline" : "success"}>{postpaid ? "Postpaid" : "Prepaid"}</Badge>
        {!balance.enabled && <Badge variant="destructive">Credit off</Badge>}
      </div>
      <p className="mt-1 text-3xl font-bold tracking-tight tabular-nums">
        {money(postpaid ? balance.creditLimit : balance.balance)}
        {currency && <span className="ml-1.5 text-base font-medium tracking-normal text-muted-foreground">{currency}</span>}
      </p>
      <div className="mt-4 grid grid-cols-3 gap-3">
        {postpaid ? (
          <Figure label="Spent, lifetime" value={usage ? money(usage.lifetime.price) : "—"} />
        ) : (
          //not a hold that shrinks as messages go out -- it is what has been moved out of balance,
          //so it only ever grows until an operator releases it
          <Figure label="Reserved" value={money(balance.reserved)} />
        )}
        <Figure label="Spent this month" value={usage ? money(usage.month.price) : "—"} />
        <Figure
          label={lastTopUp ? `Last top-up, ${shortDate(lastTopUp.createdAt)}` : "Last top-up"}
          value={lastTopUp ? money(lastTopUp.delta) : "—"}
        />
      </div>
    </>
  );
}

function MtHalf({ usage, error }: { usage: MtUsage | null; error: string }) {
  if (error) {
    return <p className="text-sm text-muted-foreground">{error}</p>;
  }
  return (
    <>
      <p className="text-xs font-medium text-muted-foreground">
        MT parts sent <span className="font-normal">· lifetime</span>
      </p>
      <p className="mt-1 text-3xl font-bold tracking-tight tabular-nums">
        {usage ? count(usage.lifetime.mtParts) : "—"}
      </p>
      <p className="text-xs text-muted-foreground">
        {!usage
          ? "Loading…"
          : usage.lifetime.messages
            ? `from ${count(usage.lifetime.messages)} messages`
            : "No messages yet"}
      </p>
      <div className="mt-4 grid grid-cols-3 gap-3">
        <Figure label="This month" value={usage ? count(usage.month.mtParts) : "—"} />
        <Figure label="Last 7 days" value={usage ? count(usage.week.mtParts) : "—"} />
        <Figure label="Today, so far" value={usage ? count(usage.todaySoFar.mtParts) : "—"} />
      </div>
      <p className="mt-4 text-xs text-muted-foreground">
        One part is one SMS segment handed to a vendor: a message split into three counts three.
        Messages every vendor refused count nothing.
      </p>
      {usage && usage.uncountedDays > 0 && (
        <p className="mt-2 text-xs text-amber-600 dark:text-amber-400">
          {count(usage.uncountedDays)} {usage.uncountedDays === 1 ? "day was" : "days were"} summarised
          before parts were counted and {usage.uncountedDays === 1 ? "is" : "are"} left out.
          Run <code>fireflo usage rollup --catch-up</code> to fill any whose call records are still
          kept.
        </p>
      )}
    </>
  );
}

function MtUsageCard({ usage, error, currency }: { usage: MtUsage | null; error: string; currency: string }) {
  const [window, setWindow] = useState<(typeof WINDOWS)[number]["value"]>("30");
  const days = Number(window);
  const series = useMemo(() => (usage ? mtSeries(usage.recent, usage.today, days) : []), [usage, days]);
  const products = useMemo(() => (usage ? mtProducts(usage.recent, usage.today, days) : []), [usage, days]);
  const total = products.reduce(
    (t, p) => ({ messages: t.messages + p.messages, mtParts: t.mtParts + p.mtParts, price: t.price + p.price }),
    { messages: 0, mtParts: 0, price: 0 });

  return (
    <Card className="min-w-0">
      <CardHeader bar className="flex-row flex-wrap items-start justify-between gap-2 space-y-0">
        <div className="space-y-1.5">
          <CardTitle>MT usage</CardTitle>
          <CardDescription>Parts sent per day, in the billing time zone. Today is still counting.</CardDescription>
        </div>
        <Segmented label="Window" options={WINDOWS} value={window} onChange={setWindow} />
      </CardHeader>
      <CardContent>
        {error ? (
          <p className="text-sm text-muted-foreground">{error}</p>
        ) : !usage ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : usage.lifetime.messages === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">
            No messages sent yet. MT parts appear here from the first one.
          </p>
        ) : (
          <div className="space-y-4">
            <ChartContainer config={chartConfig} className="h-40 w-full">
              <BarChart data={series} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--color-border)" />
                <XAxis dataKey="day" tickLine={false} axisLine={false}
                  tick={{ fontSize: 12, fill: "var(--color-muted-foreground)" }}
                  tickFormatter={shortDay} interval="preserveStartEnd" minTickGap={24} />
                <YAxis tickLine={false} axisLine={false} width={52} allowDecimals={false}
                  tick={{ fontSize: 12, fill: "var(--color-muted-foreground)" }}
                  tickFormatter={(v: number) => count(v)} />
                <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
                <Bar {...ANIMATION} dataKey="mtParts" fill={chartConfig.mtParts.color} radius={2}>
                  {/* today is partial, and drawn paler so it does not read as a drop */}
                  {series.map((d) => (
                    <Cell key={d.day} fillOpacity={d.day === usage.today ? 0.4 : 1} />
                  ))}
                </Bar>
              </BarChart>
            </ChartContainer>

            <TableInCard>
              <THead>
                <TR>
                  <TH>Product</TH>
                  <TH align="right">Messages</TH>
                  <TH align="right">MT parts</TH>
                  <TH align="right">Charged{currency ? ` (${currency})` : ""}</TH>
                </TR>
              </THead>
              <TBody>
                {products.map((p) => (
                  <TR key={p.product}>
                    <TD primary>{p.product || <span className="text-muted-foreground">no product</span>}</TD>
                    <TD num>{count(p.messages)}</TD>
                    <TD num>{p.counted ? count(p.mtParts) : `${count(p.mtParts)}+`}</TD>
                    <TD num>{money(p.price)}</TD>
                  </TR>
                ))}
                <TR className="font-semibold">
                  <TD>{days} days</TD>
                  <TD num>{count(total.messages)}</TD>
                  <TD num>{count(total.mtParts)}</TD>
                  <TD num>{money(total.price)}</TD>
                </TR>
              </TBody>
            </TableInCard>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function Figure({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <p className="text-base font-semibold tabular-nums">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}

/** `2026-10-07` → `7 Oct`. Parsed as UTC so the browser's zone cannot move the day. */
function shortDay(day: string): string {
  return new Date(`${day}T00:00:00Z`).toLocaleDateString(undefined, { day: "numeric", month: "short", timeZone: "UTC" });
}

function shortDate(at: string): string {
  return new Date(at).toLocaleDateString(undefined, { day: "numeric", month: "short" });
}
