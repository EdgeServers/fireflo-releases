"use client";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { HealthStrip } from "./CardBits";
import { DefaultRouting, RecreateAction } from "./DefaultRouting";
import { tableHref, useRoutingData } from "./RoutingShell";
import { reachability, sendsInto } from "@/lib/routing-guide";
import { DEFAULT_TABLE_NAME } from "@/lib/routing-types";

/**
 * Start here: how a message travels through the tables, and the rules the gateway needs to work at
 * all.
 *
 * <p>Routing is a graph -- `default` sends into `MESSAGE`, which sends into `cheapest` -- so the
 * chain is drawn as each reached table and the tables it sends into, in the order a message meets
 * them, rather than as a tree that would repeat branches. A table nothing reaches is named, because
 * its rules read fine and route nothing.
 */
export function RoutingOverview() {
  const data = useRoutingData();
  const names = data.tables.map((t) => t.name);
  const { reached, unreached } = reachability(data.tables);
  const entry = data.tables.find((t) => t.name === DEFAULT_TABLE_NAME);

  return (
    <>
      <section className="min-w-0 rounded-xl border border-border bg-card shadow-sm">
        <header className="border-b border-border px-4 py-3 sm:px-5">
          <h2 className="text-base font-medium">How a message travels</h2>
          <p className="text-sm text-muted-foreground">Every message starts at default and follows the rules that send it into another table.</p>
        </header>
        {data.loading ? (
          <p className="px-4 py-4 text-sm text-muted-foreground sm:px-5">Loading…</p>
        ) : (
          <ul className="divide-y divide-border">
            {reached.map((name) => {
              const table = data.tables.find((t) => t.name === name)!;
              const into = sendsInto(table, names);
              const direct = table.rules.filter((r) => r.enabled && !names.includes(r.target.trim())).length;
              return (
                <li key={name} className="flex flex-wrap items-center gap-2 px-4 py-3 text-sm sm:px-5">
                  <Link href={tableHref(name)} className="rounded-md border border-border bg-muted px-2 py-0.5 font-mono font-semibold hover:border-primary">
                    {name}
                  </Link>
                  {!table.enabled && <span className="text-xs text-warning">switched off</span>}
                  {into.map((n) => (
                    <span key={n} className="flex items-center gap-2">
                      <ArrowRight className="h-3.5 w-3.5 text-muted-foreground" aria-hidden="true" />
                      <Link href={tableHref(n)} className="font-mono text-primary hover:underline">{n}</Link>
                    </span>
                  ))}
                  <span className="ml-auto text-xs text-muted-foreground">
                    {direct} {direct === 1 ? "rule sends" : "rules send"} to a vendor or listener
                  </span>
                </li>
              );
            })}
          </ul>
        )}
        {unreached.length > 0 && (
          <div className="px-4 pb-4 sm:px-5">
            <HealthStrip>
              Nothing sends into {unreached.join(", ")}, so {unreached.length === 1 ? "its rules route" : "their rules route"} nothing.
            </HealthStrip>
          </div>
        )}
        {entry && entry.rules.length === 0 && (
          <div className="px-4 pb-4 sm:px-5">
            <HealthStrip tone="destructive">The entry-point table <code>default</code> has no rules, so nothing is routed.</HealthStrip>
          </div>
        )}
      </section>

      <DefaultRouting
        tables={data.tables}
        servers={data.servers}
        vendors={data.clients}
        writable={data.writable}
        onApplied={data.load}
        onStartMoRule={(draft) => data.startRule(DEFAULT_TABLE_NAME, draft)}
      />

      <section className="min-w-0 space-y-3 rounded-xl border border-border bg-card px-4 py-4 shadow-sm sm:px-5">
        <div>
          <h2 className="text-base font-medium">Rebuild default routing</h2>
          <p className="text-sm text-muted-foreground">
            Writes the system rules into the default table in one step, for when they are missing or the table is gone.
          </p>
        </div>
        <RecreateAction tables={data.tables} servers={data.servers} vendors={data.clients} writable={data.writable} onApplied={data.load} />
      </section>
    </>
  );
}
