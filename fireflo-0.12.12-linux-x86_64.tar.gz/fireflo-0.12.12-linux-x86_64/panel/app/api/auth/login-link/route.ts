import { NextRequest, NextResponse } from "next/server";
import { logAuthFailure, logOperatorEvent } from "@/lib/access-log";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { isConfigWritable } from "@/lib/config-db";
import { issueLoginToken, recentTokenCount } from "@/lib/login-token";
import { describeMailError, mailerConfigured, sendLoginLink } from "@/lib/mailer";
import { limiter } from "@/lib/rate-limit";
import { normaliseEmail } from "@/lib/user-types";

/**
 * POST /api/auth/login-link — an operator or admin asks for a one-time sign-in link.
 *
 * <p>The operator twin of `/api/mis/login-link`, with the same shape and the same discipline: one
 * neutral answer whether or not the name is ours, a per-address budget, a per-peer budget, and the
 * reasons recorded where the caller cannot see them. The link goes to the address that IS the login
 * (`app_user.email`), so an operator created as a bare name gets `name@control.local` and no mail --
 * that is the neutral answer too, and the admin who made them can give them a real address.
 *
 * <p>Base URL is `AUTH_URL`, which the operator panel already requires behind a proxy, and the link
 * lands on `/cp/link`, which spends the token through this instance's own callback.
 */

const MAX_PER_WINDOW = 5;
const WINDOW_MINUTES = 15;
const perOrigin = limiter(20, WINDOW_MINUTES * 60_000);

const SAME_ANSWER = {
  message: "If that is an operator's address, a sign-in link is on its way. It expires in 15 minutes.",
};
const NO_MAIL = {
  error: "Sign-in by email is not set up on this panel. Ask an admin, or use your password.",
};

let warnedFallback = false;

/**
 * `AUTH_URL`, which an installed panel must set anyway; without it, the origin this request arrived
 * on. That fallback is the bound address rather than the proxied one -- right for `npm run dev`,
 * wrong behind a proxy -- which is why it is said once in the log rather than relied on quietly.
 */
function baseUrl(req: NextRequest): string | null {
  const raw = process.env.AUTH_URL?.trim().replace(/\/+$/, "");
  const candidate = raw || new URL(req.url).origin;
  if (!raw && !warnedFallback) {
    warnedFallback = true;
    console.warn(`control-panel: AUTH_URL is not set; sign-in links are built on ${candidate}, the address this process bound.`);
  }
  try {
    const parsed = new URL(candidate);
    return parsed.protocol === "http:" || parsed.protocol === "https:" ? candidate : null;
  } catch {
    return null;
  }
}

function devLinkPrinting(): boolean {
  return process.env.FIREFLO_DEV_LOGIN_LINK?.trim() === "true";
}

const CALLER_FAULT = new Set(["unknown_address", "rate_limited"]);

export async function POST(req: NextRequest): Promise<NextResponse> {
  const ip = clientIp(req);
  if (!perOrigin.allow(ip ?? "unknown")) {
    return NextResponse.json({ error: "Too many sign-in requests from this address. Try again shortly." }, { status: 429 });
  }

  let typed = "";
  try {
    const body = (await req.json()) as { username?: unknown };
    typed = typeof body.username === "string" ? body.username.trim() : "";
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const email = normaliseEmail(typed);
  if (!email || email.length > 320) {
    return NextResponse.json({ error: "Enter your username or email address." }, { status: 400 });
  }

  const userAgent = clientUserAgent(req);
  const record = (event: "link_requested" | "link_denied", reason?: string, extra?: Record<string, unknown>) => {
    void logOperatorEvent({ event, actor: typed, userId: null, ip, userAgent, detail: reason ? { reason, ...extra } : extra });
    if (event === "link_denied" && reason && CALLER_FAULT.has(reason)) {
      void logAuthFailure({ surface: "panel", reason, triedAs: typed, ip });
    }
  };

  if (!isConfigWritable()) {
    //no user table to look in: the env-fallback operator has no address and gets no link
    record("link_denied", "not_configured");
    return NextResponse.json(NO_MAIL, { status: 503 });
  }

  try {
    const canMail = mailerConfigured();
    if (!canMail && !devLinkPrinting()) {
      console.error("control-panel: an operator sign-in link was requested but SMTP is not configured.");
      record("link_denied", "smtp_unconfigured");
      return NextResponse.json(NO_MAIL, { status: 503 });
    }
    const base = baseUrl(req);
    if (!base) {
      console.error("control-panel: a sign-in link was requested but neither AUTH_URL nor the request origin is an absolute http(s) URL. Nothing was sent.");
      record("link_denied", "base_url_unusable");
      return NextResponse.json(SAME_ANSWER);
    }
    if ((await recentTokenCount(email, WINDOW_MINUTES)) >= MAX_PER_WINDOW) {
      console.warn(`control-panel: rate limited sign-in link requests for ${email} from ${ip ?? "unknown"}`);
      record("link_denied", "rate_limited");
      return NextResponse.json(SAME_ANSWER);
    }
    const issued = await issueLoginToken(email, ip, "operator");
    if (!issued) {
      console.info(`control-panel: sign-in link requested for an unknown or disabled operator, from ${ip ?? "unknown"}`);
      record("link_denied", "unknown_address");
      return NextResponse.json(SAME_ANSWER);
    }

    const url = `${base}/cp/link?token=${encodeURIComponent(issued.token)}`;
    if (devLinkPrinting()) {
      console.warn(
        `\n${"=".repeat(78)}\n` +
          `FIREFLO_DEV_LOGIN_LINK is on. This link signs in as ${issued.email} (operator panel) for 15\n` +
          `minutes, once. Treat it as a password. It must never be enabled on a production panel.\n\n` +
          `  ${url}\n${"=".repeat(78)}\n`
      );
    }
    if (canMail) {
      await sendLoginLink(issued.email, url, "the FireFlo control panel");
    }
    void logOperatorEvent({ event: "link_requested", actor: issued.email, userId: issued.userId, ip, userAgent });
    return NextResponse.json(SAME_ANSWER);
  } catch (err) {
    const detail = describeMailError(err);
    console.error(`control-panel: could not send a sign-in link (${Object.entries(detail).map(([k, v]) => `${k}=${v}`).join(" ")})`, err);
    record("link_denied", "send_failed", detail);
    return NextResponse.json(SAME_ANSWER);
  }
}
