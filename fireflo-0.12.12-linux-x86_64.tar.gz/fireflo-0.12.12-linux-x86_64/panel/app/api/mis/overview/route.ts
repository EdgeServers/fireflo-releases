import { NextRequest, NextResponse } from "next/server";
import { isConfigured } from "@/lib/metrics-db";
import { overviewFor } from "@/lib/mis-overview";
import { NotCustomerError, requireCustomer, scopeFor } from "@/lib/require-customer";

/**
 * Everything the portal's landing page draws, in one response.
 *
 * <p>One request rather than four. Tiles, series and outcomes all describe the same window, and
 * fetching them separately gives four chances to paint a half-drawn page and four opportunities for
 * the range to disagree with itself — a donut summing to a different total than the bars above it is
 * the kind of thing that costs an afternoon to explain to a customer.
 *
 * <p>The accounts come from the session, never the request. A reseller sees its children because
 * `scopeFor` says so, and there is no parameter here that could widen that.
 */

/** Whole days, because the chart's x-axis is days. A week is the shortest window worth a bar chart. */
const RANGES: Record<string, number> = { "7d": 7, "14d": 14, "30d": 30, "90d": 90 };
const DEFAULT_RANGE = "14d";

export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    await requireCustomer();
  } catch (err) {
    if (err instanceof NotCustomerError) {
      //404 rather than 401, matching every other portal route: an unauthenticated caller learns
      //nothing about which endpoints exist
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const session = await requireCustomer();
  const scope = await scopeFor(session);

  if (!isConfigured()) {
    return NextResponse.json(
      { error: "Traffic history is not available on this deployment." },
      { status: 503 }
    );
  }

  const asked = req.nextUrl.searchParams.get("range") ?? DEFAULT_RANGE;
  const days = RANGES[asked] ?? RANGES[DEFAULT_RANGE];

  //whole days, aligned to midnight, so the first and last bars are not stubs of a partial day at one
  //end only. `until` is the start of tomorrow, so today is included and complete as it fills in
  const until = new Date();
  until.setHours(24, 0, 0, 0);
  const since = new Date(until);
  since.setDate(since.getDate() - days);

  try {
    const overview = await overviewFor(scope, session.accountId, since, until);
    return NextResponse.json({
      data: {
        ...overview,
        range: asked in RANGES ? asked : DEFAULT_RANGE,
        //echoed so the page can say what it is showing rather than assuming the client and server
        //agree about where a day starts, which they do not when they are in different zones
        since: since.toISOString(),
        until: until.toISOString(),
      },
    });
  } catch (err) {
    //logged, not swallowed: the customer gets a sentence, but a 502 with no trace anywhere is how a
    //missing column on one deployment becomes an afternoon of guessing
    console.error("mis/overview failed", err);
    //a dashboard that 500s teaches somebody to stop opening it. The page renders the message
    return NextResponse.json(
      { error: "Traffic could not be read just now." },
      { status: 502 }
    );
  }
}
