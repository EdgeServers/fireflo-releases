import { NextRequest, NextResponse } from "next/server";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { recordCustomerAccess } from "@/lib/customer-access-log";
import { verifyPassword } from "@/lib/password-hash";
import { passwordProblem } from "@/lib/password-policy";
import { NotCustomerError, requireCustomer } from "@/lib/require-customer";
import { lockoutKey, signinLockout } from "@/lib/signin-lockout";
import { customerLogin, setOwnPassword } from "@/lib/users";

/**
 * GET / PUT /api/mis/password
 *
 * <p>A customer's own portal password. Always the signed-in person's, by the id in their session,
 * never an address from the request -- there is nothing here a customer could point at somebody else.
 *
 * <p>Setting the first one needs only the session: signing in by emailed link already proved the
 * person controls the address. Changing one needs the current password as well, so a session left
 * open on a shared machine cannot be used to take the login over; wrong guesses count towards the
 * same ten-per-quarter-hour lockout as sign-in does.
 */
const lockout = signinLockout();

function notFound(): NextResponse {
  return NextResponse.json({ error: "Not found" }, { status: 404 });
}

export async function GET(): Promise<NextResponse> {
  try {
    const session = await requireCustomer();
    const login = await customerLogin(session.userId);
    if (!login) {
      return notFound();
    }
    return NextResponse.json({ data: { email: login.email, hasPassword: login.passwordHash != null } });
  } catch (err) {
    if (err instanceof NotCustomerError) {
      return notFound();
    }
    throw err;
  }
}

export async function PUT(req: NextRequest): Promise<NextResponse> {
  let session;
  try {
    session = await requireCustomer();
  } catch (err) {
    if (err instanceof NotCustomerError) {
      return notFound();
    }
    throw err;
  }
  const body = (await req.json().catch(() => null)) as { current?: unknown; password?: unknown } | null;
  const current = typeof body?.current === "string" ? body.current : "";
  const password = typeof body?.password === "string" ? body.password : "";

  const login = await customerLogin(session.userId);
  if (!login) {
    return notFound();
  }
  const ip = clientIp(req);
  const userAgent = clientUserAgent(req);
  const key = lockoutKey(ip, login.email);

  if (login.passwordHash) {
    if (lockout.lockedOut(key)) {
      return NextResponse.json({ error: "Too many wrong attempts. Try again in a quarter of an hour." }, { status: 429 });
    }
    if (!(await verifyPassword(current, login.passwordHash))) {
      lockout.noteFailure(key);
      return NextResponse.json({ error: "Your current password is not right." }, { status: 400 });
    }
    lockout.clear(key);
  }
  const weak = passwordProblem(password, login.email);
  if (weak) {
    return NextResponse.json({ error: weak }, { status: 400 });
  }
  if (!(await setOwnPassword(session.userId, password))) {
    return notFound();
  }
  void recordCustomerAccess({
    event: "password_set",
    accountId: session.accountId,
    userId: session.userId,
    email: login.email,
    ip,
    userAgent,
    detail: { changed: login.passwordHash != null },
  });
  return NextResponse.json({ data: { email: login.email, hasPassword: true } });
}
