import { NextRequest, NextResponse } from "next/server";
import { isConfigured } from "@/lib/metrics-db";
import { NotCustomerError, requireCustomer, scopeFor } from "@/lib/require-customer";
import { customPeriod, monthPeriod, periodTooLong, type BillingPeriod } from "@/lib/billing-period";
import { platformCurrency } from "@/lib/platform-currency";
import { statementDetail, type StatementCursor } from "@/lib/statement-queries";
import { csv } from "@/lib/csv";
import { MONEY_SCALE } from "@/lib/format";

/**
 * The customer's statement as a file.
 *
 * <h2>Not the operator's export, and not its column list</h2>
 *
 * <p>`lib/statement-export.ts` is the operator's: a fixed header array and a job store on local
 * disk with a retention sweep. Reusing it here would mean reusing the component whose column list
 * is the thing being protected — the same reasoning `app/api/mis/messages/export` sets out. This
 * streams instead, with its own header list, bounded by the 92-day window and a row cap.
 *
 * <p>The header list below is the whole security surface of this route. It contains no `cost`, no
 * `margin` and no `vendor`, and it is a literal rather than anything derived, so adding a column
 * has to be a deliberate edit to this line.
 */
const HEADERS = [
  "submitted_at",
  "message_id",
  "product",
  "to",
  "from",
  "parts",
  "outcome",
  "billed",
  "price",
  "price_scaled",
] as const;

/** Rows per query: inside the pool's 10s statement_timeout, large enough not to thrash. */
const BATCH = 5_000;

/**
 * The most rows one download may contain.
 *
 * <p>At 92 days a customer sending steadily will not reach it, and one who does is asking for
 * something a spreadsheet cannot open.
 */
const MAX_ROWS = 100_000;

function decimal(scaled: number): string {
  //characters, not division: (1155 / 10000).toFixed(4) is not reliably exact across every value
  const places = String(MONEY_SCALE).length - 1;
  const negative = scaled < 0;
  const digits = String(Math.abs(scaled)).padStart(places + 1, "0");
  return `${negative ? "-" : ""}${digits.slice(0, digits.length - places)}.`
    + digits.slice(digits.length - places);
}

export async function GET(req: NextRequest): Promise<NextResponse | Response> {
  let session;
  try {
    session = await requireCustomer();
  } catch (err) {
    if (err instanceof NotCustomerError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  if (!isConfigured()) {
    return NextResponse.json({ error: "Statements are not available." }, { status: 503 });
  }

  const period = readPeriod(req.nextUrl.searchParams);
  if (typeof period === "string") {
    return NextResponse.json({ error: period }, { status: 400 });
  }

  //from the session, never the request. There is no account parameter and there must not be one
  const scope = await scopeFor(session);
  const currency = (await platformCurrency()) ?? "";

  const stream = rowStream(scope, period);
  const safe = period.label.replace(/[^A-Za-z0-9._-]/g, "_");
  return new Response(stream, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      //derived from a validated period label, never from raw input
      "Content-Disposition": `attachment; filename="statement-${safe}.csv"`,
      "Cache-Control": "private, no-store",
      "X-Currency": currency,
    },
  });
}

/**
 * Streams the detail, one account at a time, keyset-paged.
 *
 * <p>Streamed rather than assembled: a quarter of a busy account's traffic held in the process heap
 * for the length of a download is the failure this shape avoids, and batching keeps each query
 * inside the pool's timeout rather than monopolising a shared connection.
 */
function rowStream(scope: string[], period: BillingPeriod): ReadableStream<Uint8Array> {
  const encoder = new TextEncoder();
  let index = 0;
  let cursor: StatementCursor | null = null;
  let written = 0;
  let done = false;

  return new ReadableStream({
    start(controller) {
      controller.enqueue(encoder.encode(HEADERS.join(",") + "\n"));
    },
    async pull(controller) {
      if (done || index >= scope.length) {
        controller.close();
        return;
      }
      try {
        const page = await statementDetail(scope[index], period, cursor, BATCH);
        if (page.rows.length) {
          const text = page.rows
            .map((r) =>
              [
                r.submittedAt, r.gatewayMsgId, r.product, r.to, r.from, r.parts, r.outcome,
                r.price !== null,
                r.price === null ? null : decimal(r.price),
                r.price,
              ].map(csv).join(",") + "\n")
            .join("");
          controller.enqueue(encoder.encode(text));
          written += page.rows.length;
        }
        cursor = page.nextCursor;
        if (!cursor) {
          //this account is exhausted; move to the next one in the scope
          index += 1;
        }
        if (written >= MAX_ROWS) {
          //the headers went out with the first byte, so there is no status code left to fail with.
          //A file that simply ends is indistinguishable from a complete one, and the person reading
          //it is the one who would be misled
          controller.enqueue(encoder.encode(
            `# stopped at ${MAX_ROWS} rows. Ask for a shorter period.\n`));
          done = true;
        }
      } catch {
        controller.enqueue(encoder.encode("# the statement could not be completed\n"));
        done = true;
      }
    },
  });
}

function readPeriod(params: URLSearchParams): BillingPeriod | string {
  const month = params.get("month");
  if (month) {
    const period = monthPeriod(month);
    if (!period) {
      return `'${month}' is not a month. Use YYYY-MM.`;
    }
    return periodTooLong(period) ?? period;
  }
  const period = customPeriod(params.get("from") ?? "", params.get("to") ?? "");
  if (typeof period === "string") {
    return period;
  }
  return periodTooLong(period) ?? period;
}
