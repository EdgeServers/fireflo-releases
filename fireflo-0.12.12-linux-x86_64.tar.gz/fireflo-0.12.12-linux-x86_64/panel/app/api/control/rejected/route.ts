import { NextRequest, NextResponse } from "next/server";
import { guardCdrRoute, queryFailed } from "@/lib/cdr-guard";
import {
  isRejectedFilterError,
  parseRejectedFilters,
  type RejectedCursor,
  type RejectedPage,
} from "@/lib/rejected-request";
import { listRejected, summariseRejected } from "@/lib/rejected";

/**
 * One page of refusals, plus a count per reason.
 *
 * <p>Guarded like `/cdrs` rather than like a configuration route: this reads reporting data and
 * writes nothing, and it carries the same information sensitivity — customer traffic, and the first
 * 160 characters of refused bodies.
 *
 * <p><strong>The summary is computed only on the first page, and only with the reason filter
 * dropped.</strong> Two separate decisions, both about what the reason cards are for. Recomputing it
 * per page would double the database work and let the counts shift under someone who is only turning
 * pages; computing it with `reason` applied would collapse the grid to the single card already
 * selected, which is the comparison those cards exist to make.
 */
const DEFAULT_PAGE = 50;
const MAX_PAGE = 200;

export async function GET(req: NextRequest): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }

  const params = new URL(req.url).searchParams;
  const filters = parseRejectedFilters(params);
  if (isRejectedFilterError(filters)) {
    //400 rather than a silent fallback: a filter that was ignored still labels the results
    return NextResponse.json({ error: filters.error }, { status: 400 });
  }

  const cursorTs = params.get("cursorTs");
  const cursorId = params.get("cursorId");
  if ((cursorTs == null) !== (cursorId == null)) {
    return NextResponse.json(
      { error: "A cursor needs both cursorTs and cursorId; one alone would skip rows." },
      { status: 400 }
    );
  }
  //the id half must be an integer -- it is bound as ::bigint and a stray value would be a query
  //error surfacing as a 500 when it is plainly a bad request
  if (cursorId != null && !/^\d+$/.test(cursorId)) {
    return NextResponse.json({ error: "cursorId must be a whole number." }, { status: 400 });
  }
  const cursor: RejectedCursor | null =
    cursorTs != null && cursorId != null ? { rejectedAt: cursorTs, id: cursorId } : null;

  const limit = Number(params.get("limit") ?? DEFAULT_PAGE);
  if (!Number.isFinite(limit) || limit < 1) {
    return NextResponse.json({ error: "limit must be a positive number." }, { status: 400 });
  }
  //the browser cap is enforced here, not in listRejected: the export worker is the other caller and
  //it legitimately asks for far more
  const size = Math.min(limit, MAX_PAGE);

  try {
    const { rows, nextCursor } = await listRejected(filters, { limit: size, cursor });
    const page: RejectedPage = { rows, nextCursor };

    if (!cursor) {
      const { summary, total } = await summariseRejected({ ...filters, reason: null });
      page.summary = summary;
      page.total = total;
      if (filters.reason) {
        //read off the summary rather than counted again: the reader wants "50 shown of 318 with
        //this reason", and that number is already in the row we just filtered out of the grid
        page.matching = summary.find((s) => s.reason === filters.reason)?.count ?? 0;
      }
    }
    return NextResponse.json({ data: page });
  } catch (err) {
    return queryFailed("rejected messages", err);
  }
}
