import { NextRequest, NextResponse } from "next/server";
import { callOps } from "@/lib/gateway-ops";
import { NotOperatorError, requireAdmin } from "@/lib/require-operator";

/**
 * DELETE /api/control/tps-peaks?scope=smppclient.x
 *
 * <p>Forgets one throughput peak -- a worker's, or a total (`all:vendors`, `all:servers`) -- so the
 * next measured traffic sets a new one. Admins only: it deletes a record. A scope is required here,
 * so a stray request cannot clear every peak at once; the gateway's own endpoint can.
 */
export async function DELETE(req: NextRequest): Promise<NextResponse> {
  try {
    await requireAdmin();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const scope = req.nextUrl.searchParams.get("scope")?.trim();
  if (!scope || scope.length > 200) {
    return NextResponse.json({ error: "Name the peak to reset." }, { status: 400 });
  }
  return callOps({
    path: `/ops/tps-peaks?scope=${encodeURIComponent(scope)}`,
    method: "DELETE",
    auth: "admin",
  });
}
