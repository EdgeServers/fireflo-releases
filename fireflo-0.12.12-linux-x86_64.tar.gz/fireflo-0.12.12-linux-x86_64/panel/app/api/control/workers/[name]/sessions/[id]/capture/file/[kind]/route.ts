import { NextRequest, NextResponse } from "next/server";
import { auditedDownload } from "@/lib/access-log";
import { callOpsDownload } from "@/lib/gateway-ops";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET /api/control/workers/{name}/sessions/{id}/capture/file/{txt|pcap}
 *
 * <p>The two artefacts of a finished capture, streamed through under a filename this route builds.
 * Separate from the JSON route beside it because the answer is a file: `callOps` would parse it as
 * JSON and hand back an empty payload.
 *
 * <p><strong>`kind` is matched against a fixed pair, not interpolated.</strong> It reaches both a URL
 * path and a filename, so anything outside {@link EXTENSIONS} is refused rather than passed along.
 *
 * <p>Both files contain message content and destination numbers, which is why they are behind the
 * operator check and the gateway's admin token, and why the response says `no-store`.
 */
type Params = { params: Promise<{ name: string; id: string; kind: string }> };

const EXTENSIONS: Record<string, string> = {
  txt: "text/plain; charset=utf-8",
  pcap: "application/vnd.tcpdump.pcap",
};

export async function GET(req: NextRequest, { params }: Params): Promise<NextResponse | Response> {
  let operator: string;
  try {
    operator = (await requireOperator()).name;
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const { name, id, kind } = await params;
  const contentType = EXTENSIONS[kind];
  if (!contentType) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  if (!/^\d+$/.test(id)) {
    return NextResponse.json({ error: `'${id}' is not a session id.` }, { status: 400 });
  }

  //audited here rather than inside callOpsDownload: that helper has neither a request nor a session,
  //and this file carries decoded message bodies and destination numbers, so who took a copy is worth
  //a line even though taking one changes nothing
  return auditedDownload(
    req,
    { kind: "capture", actor: operator, subject: `${name}#${id}.${kind}` },
    () =>
      callOpsDownload({
        path: `/ops/workers/${encodeURIComponent(name)}/sessions/${id}/capture.${kind}`,
        filename: `fireflo-capture-${name}-${id}.${kind}`,
        contentType,
        auth: "admin",
      })
  );
}
