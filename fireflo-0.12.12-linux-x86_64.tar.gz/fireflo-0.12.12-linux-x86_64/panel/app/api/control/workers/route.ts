import { NextRequest, NextResponse } from "next/server";
import { isConfigWritable } from "@/lib/config-db";
import { callOps } from "@/lib/gateway-ops";
import { describePortProblem, parsePortRange } from "@/lib/port-range";
import { listListenerPorts, listWorkers, saveWorker } from "@/lib/workers";
import { type WorkerInput, type WorkerType, validate } from "@/lib/worker-types";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * Vendor and server configuration.
 *
 * <p>The only writing endpoint in this panel. Everything else reads. It touches `app_worker` and
 * `app_worker_property` and nothing else, through a connection that is deliberately a different one
 * from the read-only metrics pool.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  const refused = await guard();
  if (refused) {
    return refused;
  }
  //?type lets the vendor and server pages each ask for their own kind, rather than fetching
  //everything and filtering in the browser
  const requested = new URL(req.url).searchParams.get("type");
  if (requested && requested !== "smppclient" && requested !== "smppserver") {
    return NextResponse.json({ error: `Unknown type '${requested}'.` }, { status: 400 });
  }

  try {
    return NextResponse.json({ data: await listWorkers((requested as WorkerType) ?? undefined) });
  } catch (err) {
    return failed(err);
  }
}

export async function POST(req: NextRequest): Promise<NextResponse> {
  const refused = await guard();
  if (refused) {
    return refused;
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const input = parse(body);
  if (typeof input === "string") {
    return NextResponse.json({ error: input }, { status: 400 });
  }
  const invalid = validate(input);
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }
  const badPort = await refuseListenerPort(input);
  if (badPort) {
    return NextResponse.json({ error: badPort }, { status: 400 });
  }

  try {
    await saveWorker(input);
    return NextResponse.json({ data: { name: input.name } });
  } catch (err) {
    return failed(err);
  }
}

/**
 * Refuses a listener port the gateway would refuse to bind.
 *
 * <p>Checked here as well as in the form, because the form is a convenience and this is the door.
 * The failure it prevents is a quiet one: the save succeeds, the listener is written, and it then
 * never starts — with the reason only in the gateway's log, long after whoever saved it moved on.
 *
 * <p>A gateway that cannot be reached declares no band, so nothing is refused. That is deliberate:
 * the management port being down is not a reason to stop somebody configuring a listener.
 *
 * @returns the refusal, or null when the port is usable or there is no port to check
 */
async function refuseListenerPort(input: WorkerInput): Promise<string | null> {
  if (input.type !== "smppserver") {
    return null;
  }
  const declared = input.properties.find((p) => p.key.trim() === "srv.port");
  if (!declared) {
    return null;
  }
  const port = Number(declared.value.trim());
  //0 is "this listener does not start", which is a legitimate thing to save
  if (!Number.isInteger(port) || port === 0) {
    return null;
  }

  let rangeText: string | null = null;
  try {
    const response = await callOps({ path: "/ops/health", timeoutMs: 5_000 });
    if (response.ok) {
      const body = (await response.json()) as { data?: { smpp_port_range?: string | null } };
      rangeText = body?.data?.smpp_port_range ?? null;
    }
  } catch {
    return null;
  }

  const used = (await listListenerPorts())
    //editing a listener must not collide with the port it already holds
    .filter((u) => u.name !== input.name)
    .map((u) => u.port);
  return describePortProblem(port, parsePortRange(rangeText), used);
}

/** 404 rather than 403 for a non-operator: a 403 confirms the endpoint exists. */
async function guard(): Promise<NextResponse | null> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  if (!isConfigWritable()) {
    return NextResponse.json(
      {
        error: "CONFIG_DATABASE_URL is not set, so editing is switched off. "
          + "It needs a database user that may write to app_worker and app_worker_property.",
      },
      { status: 503 }
    );
  }
  return null;
}

/**
 * Turns an unknown body into a WorkerInput, or returns why it could not.
 *
 * <p>Hand-written because the panel has no validation library, and because the failure needs to name
 * the field rather than produce a schema dump.
 */
export function parse(body: unknown): WorkerInput | string {
  if (!body || typeof body !== "object") {
    return "Expected an object.";
  }
  const raw = body as Record<string, unknown>;
  if (typeof raw.name !== "string") {
    return "A name is required.";
  }
  if (raw.type !== "smppclient" && raw.type !== "smppserver") {
    return "Unknown connection type.";
  }

  const properties: { key: string; value: string }[] = [];
  if (raw.properties !== undefined) {
    if (!Array.isArray(raw.properties)) {
      return "Settings must be an array of {key, value}.";
    }
    for (const entry of raw.properties) {
      if (!entry || typeof entry !== "object") {
        return "Each setting must be an object with a key and a value.";
      }
      const property = entry as Record<string, unknown>;
      if (typeof property.key !== "string") {
        return "Each setting needs a key.";
      }
      properties.push({
        key: property.key,
        value: typeof property.value === "string" ? property.value : String(property.value ?? ""),
      });
    }
  }

  return {
    name: raw.name.trim(),
    type: raw.type,
    //absent means enabled: creating something that is switched off would surprise more people than
    //it helps
    enabled: raw.enabled === undefined ? true : raw.enabled === true,
    label: typeof raw.label === "string" ? raw.label : null,
    properties,
  };
}

function failed(err: unknown): NextResponse {
  const message = err instanceof Error ? err.message : "Unknown error";
  console.error("workers:", message);
  //the message can name a missing table or a permission failure, which is what an operator needs
  //and nobody else can reach
  return NextResponse.json({ error: message }, { status: 500 });
}
