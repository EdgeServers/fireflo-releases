import { NextRequest, NextResponse } from "next/server";
import { callOps } from "@/lib/gateway-ops";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET /api/control/gateway-config-resolved
 *
 * <p>Every configuration value the running gateway has actually adopted, with the secrets blanked
 * before they left that process.
 *
 * <p><strong>The sibling of `gateway-settings`, and the opposite question.</strong> That route reads
 * `app_config` and answers "what have we written". This one asks the gateway and answers "what is in
 * force". They disagree more often than anyone would like: a row saved with `enabled = false`, a
 * gateway that has not polled since the edit, a value coming from an environment variable that no
 * database row can override, or file mode, where nothing written in the panel is being read at all.
 *
 * <p>Nothing here re-derives redaction. The gateway masks by the key's own name — the same
 * `SensitiveLogSanitizer` rule it uses for logs and for `/ops/config` — and the whole point of
 * masking at the source is that the secret never crosses the network for this process to handle.
 *
 * <p>404 rather than 403 on a failed operator check, matching the four diagnostics proxies beside
 * it: an endpoint that answers "forbidden" has confirmed it exists.
 */
export async function GET(_request: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  //admin, matching /ops/config/:name. The values are masked, but the key names alone describe the
  //shape of a deployment. Reuses GATEWAY_OPS_ADMIN_TOKEN -- no new token, no new grant
  return callOps({ path: "/ops/config/resolved", auth: "admin", timeoutMs: 10_000 });
}
