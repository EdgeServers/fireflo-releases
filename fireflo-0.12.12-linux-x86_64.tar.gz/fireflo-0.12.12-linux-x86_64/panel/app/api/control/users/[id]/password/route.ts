import { NextRequest, NextResponse } from "next/server";
import { logOperatorEvent } from "@/lib/access-log";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { configFailed, guardAdminWrite } from "@/lib/config-guard";
import { passwordProblem } from "@/lib/password-policy";
import { requireAdmin } from "@/lib/require-operator";
import { getUserById, setPassword } from "@/lib/users";

type Params = { params: Promise<{ id: string }> };

/**
 * An admin sets somebody's password.
 *
 * <p>For a new operator's first password and for a reset. The admin types it (with the same
 * confirm-and-meter form every password here uses) and hands it over out of band; nothing stores
 * or displays it afterwards. Existing sessions for that user stay valid -- the JWT is not re-checked
 * -- which is said in the response so nobody assumes a reset is a sign-out.
 */
export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardAdminWrite("app_user");
  if (refused) {
    return refused;
  }
  const admin = await requireAdmin();
  const id = Number((await params).id);
  if (!Number.isInteger(id) || id < 1) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const password = (body as { password?: unknown })?.password;
  if (typeof password !== "string") {
    return NextResponse.json({ error: "Send a password." }, { status: 400 });
  }

  try {
    const target = await getUserById(id);
    if (!target) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    const weak = passwordProblem(password, target.email);
    if (weak) {
      return NextResponse.json({ error: weak }, { status: 400 });
    }
    await setPassword(id, password);
    void logOperatorEvent({
      event: "user_password_set",
      actor: admin.name,
      userId: admin.userId,
      ip: clientIp(req),
      userAgent: clientUserAgent(req),
      detail: { subject: target.email },
    });
    return NextResponse.json({
      data: { ok: true, note: "Their existing sessions stay signed in until they sign out." },
    });
  } catch (err) {
    return configFailed("users", err);
  }
}
