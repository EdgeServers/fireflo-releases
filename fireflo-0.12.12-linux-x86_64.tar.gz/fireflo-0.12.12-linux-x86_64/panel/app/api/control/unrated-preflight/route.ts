import { NextRequest, NextResponse } from "next/server";
import { callOpsText } from "@/lib/gateway-ops";
import { isConfigured } from "@/lib/metrics-db";
import { unratedTraffic } from "@/lib/metrics-queries";
import { byName, first, parseMetrics } from "@/lib/prometheus";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import type { UnratedPreflight } from "@/lib/unrated-preflight";
import { refusesUnrated } from "@/lib/unrated-refuse-setting";

/**
 * What `smsg.rating.unrated.refuse` would refuse if it were switched on now.
 *
 * <p>Read before flipping that switch. It is one boolean with a blast radius nobody can see from the
 * settings page: traffic that is delivered today becomes `0x418` over SMPP and `403` over REST, per
 * message, from the gateway's next configuration poll. On a platform that has been running unpriced
 * traffic — which is the platform that most needs the flag — that is an outage on a timer.
 *
 * <p>Two numbers from two places, deliberately. The CDR groups say **who** and **what**, which is
 * what the fix needs; the gateway's own `fireflo_rating_unrated` gauge says what it counted as it
 * happened, and it disagreeing with the records is itself worth seeing.
 *
 * <p>Both degrade rather than fail: the metrics database is optional and the gateway may be
 * unreachable, and a pre-flight that 500s teaches the operator to switch the flag on without one.
 */

/** A day. Long enough to catch a nightly batch, short enough for the index to matter. */
const DEFAULT_HOURS = 24;

/** A week. Past this the question is no longer "what is happening now". */
const MAX_HOURS = 24 * 7;

export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const asked = Number(req.nextUrl.searchParams.get("hours") ?? DEFAULT_HOURS);
  const hours = Number.isFinite(asked) && asked > 0 ? Math.min(asked, MAX_HOURS) : DEFAULT_HOURS;

  if (!isConfigured()) {
    return NextResponse.json(
      { error: "The call records are not configured here, so there is nothing to count. Set "
        + "METRICS_DATABASE_URL, or read the gateway's fireflo_rating_unrated gauge directly." },
      { status: 503 }
    );
  }

  const [traffic, gauge, refusing] = await Promise.all([
    unratedTraffic(hours),
    readGauge(),
    readSetting(),
  ]);

  const preflight: UnratedPreflight = { ...traffic, hours, gauge };
  //the flag's stored value travels beside the pre-flight rather than inside it: the count is a fact
  //about traffic and this is a fact about configuration, and only one of them is null when the
  //config database is absent
  return NextResponse.json({ data: { ...preflight, refusing } });
}

/** The stored flag, or null when it is unset or unreadable. Never guessed at as false. */
async function readSetting(): Promise<boolean | null> {
  try {
    return await refusesUnrated();
  } catch {
    return null;
  }
}

/**
 * The gateway's running count of unrated messages, or null when it could not be asked.
 *
 * <p>Null rather than zero, and the difference matters on this particular page: zero reads as "there
 * is nothing to worry about", which is exactly the wrong thing to tell somebody about to switch on a
 * refusal.
 */
async function readGauge(): Promise<number | null> {
  try {
    const result = await callOpsText({ path: "/q/metrics", timeoutMs: 5_000 });
    if ("failed" in result) {
      return null;
    }
    return first(byName(parseMetrics(result.text)).get("fireflo_rating_unrated"));
  } catch {
    return null;
  }
}
