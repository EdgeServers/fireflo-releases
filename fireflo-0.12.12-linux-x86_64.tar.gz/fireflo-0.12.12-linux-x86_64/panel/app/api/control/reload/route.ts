import { NextResponse } from "next/server";
import { callOps } from "@/lib/gateway-ops";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * POST /api/control/reload
 *
 * <p>Asks the gateway to re-read its configuration now rather than at its next poll.
 *
 * <p>Still useful now that the controls push their own changes: this covers a full save, a delete,
 * and anything edited outside the panel, none of which map to a single action.
 */
export async function POST(): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  //the admin token: reload applies whatever configuration has been written, so the gateway counts
  //it as changing what it is doing rather than as a read
  return callOps({ path: "/ops/reload", method: "POST", auth: "admin" });
}
