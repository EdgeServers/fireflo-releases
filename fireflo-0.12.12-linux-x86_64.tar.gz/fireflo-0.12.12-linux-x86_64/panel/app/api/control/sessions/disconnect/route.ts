import { NextRequest, NextResponse } from "next/server";
import { callOps } from "@/lib/gateway-ops";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

const KINDS = ["ip", "account", "system_id"];

/**
 * POST /api/control/sessions/disconnect  { kind, value, listener?, hold?, reason? }
 *
 * <p>Drops every session of an IP, an account or a login, on every listener or one, and with
 * `hold` (seconds, or "forever") refuses that client's binds for a while on every node. The admin
 * token: it ends connections customers are sending on. The operator's address goes along as who
 * made the hold.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  let operator;
  try {
    operator = await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) return NextResponse.json({ error: "Not found" }, { status: 404 });
    throw err;
  }
  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  const kind = typeof body?.kind === "string" ? body.kind : "";
  const value = typeof body?.value === "string" ? body.value.trim() : "";
  if (!KINDS.includes(kind) || !value) {
    return NextResponse.json({ error: "Name an ip, an account or a system_id." }, { status: 400 });
  }
  const q = new URLSearchParams({ [kind]: value, by: operator.name });
  if (typeof body?.listener === "string" && body.listener) q.set("listener", body.listener);
  if (typeof body?.hold === "string" && /^(\d+|forever)$/.test(body.hold)) q.set("hold", body.hold);
  if (typeof body?.reason === "string" && body.reason.trim()) q.set("reason", body.reason.trim().slice(0, 300));
  return callOps({
    path: `/ops/sessions/disconnect?${q}`,
    method: "POST",
    auth: "admin",
    //each session waits up to five seconds for the customer's unbind_resp
    timeoutMs: 30_000,
  });
}
