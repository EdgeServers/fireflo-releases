import { NextRequest, NextResponse } from "next/server";
import { callOps } from "@/lib/gateway-ops";
import { logOperatorEvent } from "@/lib/access-log";
import { requestContext } from "@/lib/request-context";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET  /api/control/license  — what state this gateway's licence is in.
 * POST /api/control/license  — activate, revalidate, or the two offline halves.
 *
 * <p>A proxy and nothing more. Every decision — verifying the signature, deciding the verdict,
 * refusing a licence issued to another install — happens in the gateway, which is compiled. This
 * route carries a key one way and a state object the other.
 *
 * <p><strong>It re-derives nothing</strong>, matching `app/api/control/diagnostics/route.ts`: the
 * whole point of deciding at the source is that this process has nothing to decide and no rule to
 * keep in step. If it started forming its own opinion about a licence, there would be two answers
 * to one question and no way to tell which a screen was showing.
 *
 * <p>The gateway answers these three routes even when unlicensed — they are the way out of that
 * state — so this keeps working on exactly the installs that need it.
 */

interface Body {
  action?: unknown;
  licenseKey?: unknown;
  license?: unknown;
}

export async function GET(): Promise<NextResponse> {
  const refused = await gate();
  if (refused) {
    return refused;
  }
  return callOps({ path: "/ops/license", passErrors: true });
}

export async function POST(req: NextRequest): Promise<NextResponse> {
  const refused = await gate();
  if (refused) {
    return refused;
  }

  let body: Body;
  try {
    body = (await req.json()) as Body;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const action = typeof body.action === "string" ? body.action : "";
  const { name: operator } = await requireOperator();
  const ctx = await requestContext();

  //audited before the call rather than after, and recorded whatever the gateway then answers.
  //"who tried to change the licence on this box" is the question asked after a licence changes
  //unexpectedly, and an audit line written only on success cannot answer it
  const note = (what: string) =>
    void logOperatorEvent({
      event: "signin",
      actor: operator,
      ip: ctx.ip,
      userAgent: ctx.userAgent,
      //never the key itself. It is a bearer credential, and an access log is exactly the sort of
      //file that gets copied into a ticket
      detail: { license: what },
    });

  switch (action) {
    case "activate": {
      const key = typeof body.licenseKey === "string" ? body.licenseKey.trim() : "";
      if (!key) {
        return NextResponse.json({ error: "Enter a licence key." }, { status: 400 });
      }
      note("activate");
      return callOps({
        path: "/ops/license/activate",
        method: "POST",
        auth: "admin",
        body: { licenseKey: key },
        passErrors: true,
      });
    }
    case "revalidate":
      note("revalidate");
      return callOps({
        path: "/ops/license/revalidate",
        method: "POST",
        auth: "admin",
        passErrors: true,
      });

    case "offline-request": {
      const key = typeof body.licenseKey === "string" ? body.licenseKey.trim() : "";
      return callOps({
        path: "/ops/license/offline",
        method: "POST",
        auth: "admin",
        body: { licenseKey: key },
        passErrors: true,
      });
    }
    case "offline-apply": {
      const license = typeof body.license === "string" ? body.license.trim() : "";
      if (!license) {
        return NextResponse.json({ error: "Paste the signed licence." }, { status: 400 });
      }
      note("offline-apply");
      return callOps({
        path: "/ops/license/offline",
        method: "POST",
        auth: "admin",
        body: { license },
        passErrors: true,
      });
    }
    case "release":
      //"release-local", not "release". Months later this line is read beside the licence server's
      //own ipHistory entry, which also says released -- two acts, in two systems, and the panel's
      //log should be unambiguous about which one it actually witnessed
      note("release-local");
      return callOps({
        path: "/ops/license/release",
        method: "POST",
        auth: "admin",
        passErrors: true,
      });

    default:
      return NextResponse.json(
        {
          error:
            `'${action}' is not an action. Use activate, revalidate, offline-request, `
            + "offline-apply or release.",
        },
        { status: 400 }
      );
  }
}

/** 404 rather than 403, exactly as every other control route does. */
async function gate(): Promise<NextResponse | null> {
  try {
    await requireOperator();
    return null;
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
}
