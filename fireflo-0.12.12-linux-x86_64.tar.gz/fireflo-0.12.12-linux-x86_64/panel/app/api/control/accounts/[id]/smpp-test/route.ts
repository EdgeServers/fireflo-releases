import { openOrExplain } from "@/lib/secret-box";
import { NextRequest, NextResponse } from "next/server";
import { configQuery } from "@/lib/config-db";
import { SmppTestRefused, openSession } from "@/lib/smpp-test";
import { adminOr404, gatewayHost } from "@/lib/smpp-test-route";
import type { BindKind } from "@/lib/smpp-test-types";

type Params = { params: Promise<{ id: string }> };

const BIND_KINDS: readonly BindKind[] = ["trx", "tx", "rx"];

/**
 * POST /api/control/accounts/{id}/smpp-test
 *
 * <p>Binds a test session. Either `credentialId` -- an SMPP login on this account, whose stored
 * password is read here and never sent to the browser -- or `systemId` and `password` typed. Plus
 * the server (`host` optional, else the gateway's) and the bind fields. Admins only.
 *
 * <p>A refused bind answers 200 with `bound: false` and the status: refusing is what the tool is
 * for testing, not a failure of the request.
 */
export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const admin = await adminOr404();
  if (typeof admin !== "string") {
    return admin;
  }
  const { id: accountId } = await params;
  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const int = (v: unknown, fallback: number, max: number): number | null => {
    if (v === undefined || v === null || v === "") {
      return fallback;
    }
    const n = Number(v);
    return Number.isInteger(n) && n >= 0 && n <= max ? n : null;
  };
  const port = int(body.port, -1, 65535);
  if (port === null || port < 1) {
    return NextResponse.json({ error: "Choose a server, or a port from 1 to 65535." }, { status: 400 });
  }
  const typedHost = typeof body.host === "string" ? body.host.trim() : "";
  if (typedHost && !/^[A-Za-z0-9.\-:\[\]]{1,253}$/.test(typedHost)) {
    return NextResponse.json({ error: `'${typedHost}' is not a host name or address.` }, { status: 400 });
  }
  const bindType = BIND_KINDS.includes(body.bindType as BindKind) ? (body.bindType as BindKind) : "trx";
  const addrTon = int(body.addrTon, 0, 255);
  const addrNpi = int(body.addrNpi, 0, 255);
  const version = int(body.interfaceVersion, 0x34, 255);
  if (addrTon === null || addrNpi === null || version === null) {
    return NextResponse.json({ error: "addr_ton, addr_npi and the interface version are numbers from 0 to 255." }, { status: 400 });
  }

  let systemId: string;
  let password: string;
  let systemType = typeof body.systemType === "string" ? body.systemType : "";
  if (body.credentialId !== undefined && body.credentialId !== null && body.credentialId !== "") {
    const credentialId = Number(body.credentialId);
    //the login must be an SMPP login billing to this account: its own account, or the system id
    //standing in for one, exactly as the gateway resolves it
    const rows = await configQuery<{ system_id: string; password: string | null; product: string | null }>(
      `SELECT system_id, password, product FROM app_credential
        WHERE id = $1 AND type = 'SMPP' AND (account_id = $2 OR (account_id IS NULL AND system_id = $2))`,
      [credentialId, accountId]
    );
    if (!rows.length) {
      return NextResponse.json({ error: "That login is not an SMPP login on this account." }, { status: 404 });
    }
    systemId = rows[0].system_id;
    //sealed at rest when FIREFLO_SECRETS_KEY is set; a password this panel cannot open cannot bind
    const opened = openOrExplain(rows[0].password);
    if (opened.problem) {
      return NextResponse.json({ error: opened.problem }, { status: 400 });
    }
    password = opened.value ?? "";
    if (!systemType && rows[0].product) {
      systemType = rows[0].product;
    }
  } else {
    systemId = typeof body.systemId === "string" ? body.systemId : "";
    password = typeof body.password === "string" ? body.password : "";
    if (!systemId.trim()) {
      return NextResponse.json({ error: "Enter a system ID, or choose an existing login." }, { status: 400 });
    }
  }
  //no length checks against SMPP 3.4's field sizes: the gateway accepts longer system ids and
  //passwords, logins exist that use them, and a test tool stricter than the server it tests would
  //refuse the very bind somebody is trying to reproduce
  if (systemId.length > 64 || password.length > 64 || systemType.length > 64) {
    return NextResponse.json({ error: "System ID, password and system type are at most 64 characters here." }, { status: 400 });
  }

  try {
    const result = await openSession({
      operator: admin,
      accountId,
      host: typedHost || gatewayHost(),
      port,
      bindType,
      systemId,
      password,
      systemType,
      addrTon,
      addrNpi,
      addressRange: typeof body.addressRange === "string" ? body.addressRange : "",
      interfaceVersion: version,
    });
    return NextResponse.json({ data: result });
  } catch (err) {
    if (err instanceof SmppTestRefused) {
      return NextResponse.json({ error: err.message }, { status: 409 });
    }
    throw err;
  }
}
