import { controlRoute } from "@/lib/control-route";
import { failureBreakdown, totals, trafficOverTime } from "@/lib/metrics-queries";

/** Headline figures, the traffic series and the failure breakdown in one round trip. */
export const GET = controlRoute(async (range) => {
  const [summary, traffic, failures] = await Promise.all([
    totals(range),
    trafficOverTime(range),
    failureBreakdown(range),
  ]);
  return { totals: summary, traffic, failures };
});
