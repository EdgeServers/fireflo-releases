import { NextRequest, NextResponse } from "next/server";
import { callOps } from "@/lib/gateway-ops";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

type Params = { params: Promise<{ id: string }> };

/**
 * DELETE /api/control/bind-holds/{id}
 *
 * <p>Lifts a hold: the client may bind again at once on this node, and on the others within ten
 * seconds. The admin token; the operator's address is recorded as who lifted it.
 */
export async function DELETE(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  let operator;
  try {
    operator = await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) return NextResponse.json({ error: "Not found" }, { status: 404 });
    throw err;
  }
  const { id } = await params;
  if (!/^-?\d+$/.test(id)) return NextResponse.json({ error: "A hold id is a number." }, { status: 400 });
  return callOps({
    path: `/ops/bind-holds/${id}?by=${encodeURIComponent(operator.name)}`,
    method: "DELETE",
    auth: "admin",
    timeoutMs: 10_000,
  });
}
