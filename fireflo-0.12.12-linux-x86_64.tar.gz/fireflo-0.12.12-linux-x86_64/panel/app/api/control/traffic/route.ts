import { controlRoute } from "@/lib/control-route";
import { trafficOverTime } from "@/lib/metrics-queries";

export const GET = controlRoute(trafficOverTime);
