import { controlRoute } from "@/lib/control-route";
import { revenueByAccount } from "@/lib/metrics-queries";

export const GET = controlRoute(revenueByAccount);
