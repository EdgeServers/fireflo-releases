import { NextRequest, NextResponse } from "next/server";
import { logOperatorEvent } from "@/lib/access-log";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { callOps } from "@/lib/gateway-ops";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { WATCH_MAX_SECONDS, isIpLiteral } from "@/lib/client-watch";

/**
 * POST /api/control/security/watch
 *
 * <p>Starts watching one client address on one SMPP listener port, for the Security page: every PDU
 * it sends and is sent, including binds that are refused. `{ip, port, seconds}`.
 *
 * <p>The admin token, as for a capture, and for the same reason: what a watch shows is decoded PDUs,
 * which include bind passwords and message bodies. The gateway enforces it; this only matches.
 *
 * <p>The query is rebuilt from validated values rather than forwarded, so nothing but an address, a
 * port and a number can reach the gateway through it.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  let operator: string;
  try {
    ({ name: operator } = await requireOperator());
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  const ip = typeof body?.ip === "string" ? body.ip.trim() : "";
  const port = Number(body?.port);
  const seconds = Number(body?.seconds);
  if (!isIpLiteral(ip)) {
    return NextResponse.json({ error: "Enter the client's IPv4 or IPv6 address." }, { status: 400 });
  }
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    return NextResponse.json({ error: "Enter the listener port, 1 to 65535." }, { status: 400 });
  }
  const query = new URLSearchParams({ ip, port: String(port) });
  if (Number.isFinite(seconds) && seconds > 0) {
    query.set("seconds", String(Math.min(Math.floor(seconds), WATCH_MAX_SECONDS)));
  }

  const started = await callOps({ path: `/ops/watches?${query}`, method: "POST", auth: "admin", passErrors: true });
  if (started.ok) {
    //recorded as a capture, which is what it is -- a recording of a named client's traffic -- so the
    //audit table's list of event names needs no new entry
    void logOperatorEvent({
      event: "capture_started",
      actor: operator,
      ip: clientIp(req),
      userAgent: clientUserAgent(req),
      detail: { watch: true, client: ip, port, seconds: query.get("seconds") },
    });
  }
  return started;
}
