import { NextRequest, NextResponse } from "next/server";
import { logOperatorEvent } from "@/lib/access-log";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { verifyPassword } from "@/lib/password-hash";
import { passwordProblem } from "@/lib/password-policy";
import { requireOperator } from "@/lib/require-operator";
import { findLoginUser, setPassword } from "@/lib/users";

/**
 * The signed-in operator or admin changes their own password.
 *
 * <p>The current password is required, and for a reason beyond ceremony: the session is a cookie,
 * and a cookie left in a browser somebody else sits down at must not be enough to take the account
 * over by setting a new password. The env-fallback operator has no row and is told to run
 * `fireflo-panel-install passwd` instead.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite("app_user");
  if (refused) {
    return refused;
  }
  const me = await requireOperator();
  if (me.userId === null) {
    return NextResponse.json(
      { error: "This operator account lives in panel.env, not the database. Use fireflo-panel-install passwd." },
      { status: 400 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const { current, next } = (body ?? {}) as { current?: unknown; next?: unknown };
  if (typeof current !== "string" || typeof next !== "string") {
    return NextResponse.json({ error: "Send the current password and the new one." }, { status: 400 });
  }

  try {
    const user = await findLoginUser(me.name, "operator");
    if (!user || user.id !== me.userId || !(await verifyPassword(current, user.passwordHash))) {
      //one message for an unknown row and a wrong password, as at sign-in
      return NextResponse.json({ error: "The current password is wrong." }, { status: 400 });
    }
    const weak = passwordProblem(next, user.email);
    if (weak) {
      return NextResponse.json({ error: weak }, { status: 400 });
    }
    if (current === next) {
      return NextResponse.json({ error: "That is the current password." }, { status: 400 });
    }
    await setPassword(user.id, next);
    void logOperatorEvent({
      event: "password_changed",
      actor: me.name,
      userId: me.userId,
      ip: clientIp(req),
      userAgent: clientUserAgent(req),
    });
    return NextResponse.json({ data: { ok: true } });
  } catch (err) {
    return configFailed("password", err);
  }
}
