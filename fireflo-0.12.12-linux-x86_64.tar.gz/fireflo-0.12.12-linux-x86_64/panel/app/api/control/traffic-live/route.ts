import { controlRoute } from "@/lib/control-route";
import { liveTraffic } from "@/lib/metrics-queries";

/**
 * GET /api/control/traffic-live?kind=vendor|server
 *
 * <p>MT and DLR for the last fifteen minutes in ten-second buckets, per vendor or per account, for
 * the live chart on the Vendors and Servers pages. `range` is ignored: the window is fixed, because
 * the chart's queue line comes from live health polls and cannot reach further back than the page
 * has been open.
 */
export const GET = controlRoute((_range, params) =>
  liveTraffic(params.get("kind") === "server" ? "server" : "vendor")
);
