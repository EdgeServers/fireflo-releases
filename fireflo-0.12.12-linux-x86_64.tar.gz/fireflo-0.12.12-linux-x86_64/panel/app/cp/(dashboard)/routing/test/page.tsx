import { DeliveryCheck } from "@/components/DeliveryCheck";
import { RoutingTester } from "@/components/RoutingTester";

/**
 * Test and check, in one card: which rule one message would hit, and whether a customer's messages
 * and receipts get where they need to. Side by side on a wide screen, the tester above on a phone.
 */
export default function RoutingTestPage() {
  return (
    <section className="grid min-w-0 divide-y divide-border rounded-xl border border-border bg-card shadow-sm xl:grid-cols-2 xl:divide-x xl:divide-y-0">
      <RoutingTester bare />
      <DeliveryCheck bare />
    </section>
  );
}
