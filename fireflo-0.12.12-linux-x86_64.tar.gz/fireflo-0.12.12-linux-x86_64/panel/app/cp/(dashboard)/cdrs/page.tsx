import { CdrsClient } from "@/components/CdrsClient";

export default function CdrsPage() {
  return <CdrsClient />;
}
