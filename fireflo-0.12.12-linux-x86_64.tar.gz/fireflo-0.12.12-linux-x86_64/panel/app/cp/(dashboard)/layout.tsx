import { redirect } from "next/navigation";
import { SessionProvider } from "next-auth/react";
import { auth } from "@/lib/auth";
import { isOperatorSession } from "@/lib/roles";
import { DashboardShell } from "@/components/DashboardShell";
import { LicenseBanner } from "@/components/LicenseBanner";
import { PlatformScale } from "@/components/PlatformScale";
import { PanelSurface } from "@/components/PanelSurface";
import { OPERATOR_SURFACE } from "@/lib/panel-surface";
import { platformDecimals } from "@/lib/platform-decimals";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  //the gate for pages; every API route repeats it for itself rather than trusting this.
  //
  //the same predicate as requireOperator, deliberately: this asked only whether a session existed,
  //which let a non-operator render the whole shell while every request inside it answered 404 --
  //a page that looks like it works and does nothing, which is worse than being sent to the login
  const session = await auth();
  if (!isOperatorSession(session)) {
    redirect("/cp/login");
  }
  const scale = await platformDecimals();
  return (
    <>
      <PlatformScale scale={scale} />
      {/* the operator surface is already `panel-surface`'s default, so this changes nothing today.
          Declared anyway: the account components are shared with the customer portal now, and a
          default that is only correct because nobody set it is one navigation away from being
          wrong */}
      <PanelSurface surface={OPERATOR_SURFACE} />
      {/* a signal, never a gate: no redirect, and it renders nothing on an active licence.
          Enforcement is in the gateway's compiled artefact -- see lib/license-state.ts */}
      <LicenseBanner />
      {/* the only subtree that reads the session client-side (Sidebar, UsersClient). The login page
          and the customer portal sit outside it on purpose -- see app/layout.tsx */}
      <SessionProvider>
        <DashboardShell>{children}</DashboardShell>
      </SessionProvider>
    </>
  );
}
