import { notFound, redirect } from "next/navigation";
import { misAuth } from "@/lib/mis-auth";
import { CUSTOMER_ROLE } from "@/lib/roles";
import { NotCustomerError, requireCustomer } from "@/lib/require-customer";
import { MisShell } from "@/components/MisShell";
import { PlatformScale } from "@/components/PlatformScale";
import { PanelSurface } from "@/components/PanelSurface";
import { RESELLER_SURFACE } from "@/lib/panel-surface";
import { portalBrand, portalCopyright } from "@/lib/brand";
import { platformDecimals } from "@/lib/platform-decimals";

/**
 * Overrides the root layout's "Control Panel — FireFlo SMS/SMPP Gateway" for everything below here.
 *
 * <p>That title was wrong for this segment twice over: a customer is not in a control panel, and on
 * a white-labelled portal the platform's name is the one thing not to put in their browser tab.
 */
export function generateMetadata() {
  return { title: portalBrand() };
}

/**
 * The gate for the portal's pages.
 *
 * <p>Checks the role, not merely that a session exists — the same rule the operator layout uses and
 * for the same reason. This one also rejects an *operator* session: signing in on one side must not
 * put you inside the other, in either direction.
 *
 * <p>Every portal API route re-checks for itself through `requireCustomer`. A layout gate stops a
 * page rendering; it does nothing about a fetch.
 *
 * <p><strong>Two checks, two answers.</strong> No customer session at all is sent to the sign-in page,
 * as before. A session whose account or user has since been disabled gets a 404, from the same
 * `requireCustomer` the API routes use. This gate used to read the session only, so a disabled
 * account kept the whole portal frame -- nav, balance, page titles -- with a 200, and only the panels
 * inside it failed, one fetch at a time. Not a redirect to sign-in: a link would sign them straight
 * back into a frame that cannot load anything, and the 404 matches what every route under it answers.
 *
 * <p>It runs on a full page load, not on a client-side navigation, which reuses this layout without
 * running it again. That is why the API routes are the boundary and this is the courtesy: the next
 * fetch after a disable is refused whichever way the customer arrived.
 */
export default async function PortalLayout({ children }: { children: React.ReactNode }) {
  const session = await misAuth();
  const user = session?.user as { role?: string | null; accountId?: string } | undefined;
  if (!user?.accountId || user.role !== CUSTOMER_ROLE) {
    redirect("/");
  }
  try {
    await requireCustomer();
  } catch (err) {
    if (err instanceof NotCustomerError) {
      notFound();
    }
    throw err;
  }
  //read here rather than per page: it is one platform-wide value, and every page below renders
  //amounts. See PlatformScale for why this is not a context
  const scale = await platformDecimals();
  return (
    <>
      <PlatformScale scale={scale} />
      {/* the account screens below /accounts are the operator panel's own components. This is what
          points them at the portal's API namespace and its links, and switches off everything that
          would show a customer what its own children are charged — see lib/panel-surface.ts */}
      <PanelSurface surface={RESELLER_SURFACE} />
      <MisShell brand={portalBrand()} copyright={portalCopyright()}>
        {children}
      </MisShell>
    </>
  );
}
