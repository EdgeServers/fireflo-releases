# FireFlo SMS/SMPP Gateway

[![Built with Quarkus](https://img.shields.io/badge/Built%20with-Quarkus-blueviolet.svg)](https://quarkus.io/)
[![Site](https://img.shields.io/badge/Website-FireFlo.au-orange)](https://fireflo.au)

**FireFlo** is a headless SMS gateway engineered for high-throughput delivery. Designed to sit seamlessly between your internal applications (CRMs, websites, IoT platforms) and your SMS connectivity (vendors, SMPP providers), it puts you firmly in control of your messaging infrastructure.

Eliminate vendor lock-in, manage your own routing logic, and scale your messaging horizontally across any on-premise or cloud environment.

FireFlo is commercial software, licensed per deployment, created and maintained by
[Remotiq](https://fireflo.au). Talk to us about licensing, or write to
[support@fireflo.au](mailto:support@fireflo.au) if you already run it.

---

## 🚀 Why FireFlo?

* **Modern Stack:** A practical, container-native Kannel replacement built on **Java & Quarkus**.
* **Total Control:** Manage connections, adjust routing on the fly, and dictate fail-over rules.
* **Protocol Agnostic:** Bridge the gap between modern HTTP webhooks and legacy SMPP infrastructure.
* **High Throughput:** Designed for low latency and massive scale.

---
## 🏢 Backed by Remotiq

**FireFlo** is created and maintained by **[Remotiq](https://fireflo.au)**.

---
## 🛠 Core Capabilities

| Feature | Description |
| :--- | :--- |
| **SMPP Server & Client** | Full TX/RX/TRX bind support for downstream clients and upstream vendors, including TLS/SSL options. |
| **REST & SMPP Bridging** | A Jasmin-shaped JSON REST API for outbound SMS, plus SMPP-to-HTTP webhooks for inbound MO traffic. |
| **Advanced Routing** | Route by destination, sender ID, content, account, or message attributes with fallback routing chains. |
| **Granular TPS Control** | Protect links with Transactions-Per-Second limits per worker or SMPP server account defaults. |
| **Retry & Queue Control** | Retry and re-enqueue messages when `submit_sm` to an SMPP provider fails, with priority-aware queue support. |
| **Delivery Receipts** | Correlate provider message IDs, normalize DLR statuses, and propagate callbacks to originating systems. |
| **Rating & Billing** | Regex rate tables per vendor and per customer, least-cost routing, call detail records with both sides of the trade, and optional prepaid credit. |
| **Operations & Observability** | Docker/native images, hot-reloaded configuration, operational logs, Swagger/OpenAPI, and Prometheus `/q/metrics`. |

---

## 🔄 How It Works

1.  **Request:** Your application sends a message to FireFlo via **HTTP** or **SMPP**.
2.  **Logic:** FireFlo applies routing rules based on destination, sender ID, account, message attributes, and priority.
3.  **Delivery:** FireFlo delivers via one or more **SMPP** connections to upstream providers.
4.  **Verification:** Asynchronous Delivery Receipts (DLRs) are received and normalized.
5.  **Callback:** FireFlo forwards the status back to your system via **HTTP Webhooks**.

---

## 📦 Quick Start

### Prerequisites
* Docker installed on your host machine.
* Create three empty directories in your current working folder: `./conf`, `./data`, and `./logs`.
* Before starting the container, FireFlo requires its configuration inside `./conf` — the binds, the authentication, the routing and the pricing.

The quickest way to get these is to copy the tracked example set and fill in the secrets:

```bash
cp -r conf.example conf
chmod 600 conf/credentials.yml conf/fireflo.env
# then replace every REPLACE_WITH_* value
```

`conf/` is gitignored, so your real credentials never enter version control.

That is a complete, working, **file-based** install — no database needed. `conf/fireflo.env` sets
`FIREFLO_CONFIG_SOURCE=file`, and the four files below are the whole configuration. Source it and
start:

```bash
set -a; . conf/fireflo.env; set +a
```

**Prefer to run from PostgreSQL instead**, so the control panel can edit all of this? Two commands,
and no config files at all:

```bash
fireflo db migrate    # create the schema
fireflo bootstrap     # a default routing table, one listener, one login
```

`bootstrap` prints a generated password once. Then set `FIREFLO_CONFIG_SOURCE=db` and start. It
refuses to run against a database that already has a configuration, so it cannot overwrite anything.
See [Configuration reference](https://docs.fireflo.au/reference/config/logging) for both paths in full.

The four files are described below:
#### 1. credentials.yml
- Setting smpp and http credentials on fireflo

> ⚠️ Replace both passwords before starting the container. Generate a distinct
> secret per credential, e.g. `openssl rand -base64 32`. See
> [Authentication & Security](https://docs.fireflo.au/developers/authentication) for rotation and IP-restriction guidance.

```yml
credentials:
  - type: SMPP
    systemId: "fireflo-smpp-user"
    password: "REPLACE_WITH_A_UNIQUE_STRONG_SECRET"
  - type: HTTP
    systemId: "fireflo-http-user"
    password: "REPLACE_WITH_A_UNIQUE_STRONG_SECRET"
```
#### 2. smsg.properties
- Setting a smpp client connection and the smpp server.
```properties
# sample smpp client worker
outSms.instance.testRoute.enable = true
outSms.instance.testRoute.type = smppclient
outSms.instance.testRoute.username = upstream-system-id
outSms.instance.testRoute.password = upstream-password
outSms.instance.testRoute.host = smpp.test.com
outSms.instance.testRoute.port = 2775
outSms.instance.testRoute.tps = 0
outSms.instance.testRoute.connections.transceivers = 1

# smpp server
outSms.instance.smpp.enable = true
outSms.instance.smpp.type = smppserver
outSms.instance.smpp.tps = 0
outSms.instance.smpp.srv.port = 27777
outSms.instance.smpp.conf.maxPending.default = 1000
outSms.instance.smpp.srv.maxConnections = 1000
outSms.instance.smpp.srv.maxConnectionsPerIP = 4
outSms.instance.smpp.conf.maxConnectionsPerUser.default = 4
outSms.instance.smpp.conf.maxRate.default = 0
```
#### 3. routingTable.conf
- Routing configuration for sending all traffic by default through the SMPP client named `testRoute`

```conf
[default]
MESSAGE:type:==:0
MESSAGE:type:==:11
MESSAGE:type:==:14
MESSAGE:type:==:17
MESSAGE:type:==:10
smppserver.smpp:type:==:18

[MESSAGE]
testRoute::default:
```

#### 4. rates.conf
- What each vendor costs and what each account is charged, rule by rule

Each section is a **scope**: a vendor name is a cost, an account id is a price. Within a section the
first matching rule wins, so put the specific ones above the catch-all. The amount comes first, then
the field, the operator and the value.

```conf
[vendor1]
0.0450:to:matches:^61[45][0-9]{8}$
0.0620:to:matches:^61[0-9]{9}$
0.0900::default:

[acct-1001]
0.0600:to:matches:^61[45][0-9]{8}$
0.1200::default:
```

A scope with no matching rule leaves the message unpriced rather than free — it shows in the call
record, which is the point. See [Rating, CDR and prepaid credit](https://docs.fireflo.au/platform/billing/prepaid-credit).

### Running with Docker
FireFlo publishes two Docker image variants:

| Image | Runtime |
| :--- | :--- |
| `edgeservers/fireflo:latest` | JVM image based on Eclipse Temurin 25 JRE. |
| `edgeservers/fireflo:latest-native` | Native executable image. |

Run the following command to start the default JVM image in the background:

```bash
docker run -d --name fireflo \
  -e QUARKUS_LOG_FILE_ENABLE=true \
  -e QUARKUS_LOG_CONSOLE_ENABLE=false \
  -e QUARKUS_LOG_FILE_PATH=/work/logs/smsg.log \
  -e QUARKUS_LOG_FILE_SMPPCLIENT_PATH=/work/logs/smppclient.log \
  -e QUARKUS_LOG_FILE_SMPPSERVER_PATH=/work/logs/smppserver.log \
  -e QUARKUS_HTTP_ACCESS_LOG_DIRECTORY=/work/logs \
  -p 8080:8080 \
  -p 27777:27777 \
  -v ./conf:/work/conf \
  -v ./data:/work/data \
  -v ./logs:/work/logs \
  edgeservers/fireflo:latest
```

To run the native image instead, use `edgeservers/fireflo:latest-native`.

## 💬 Documentation & Support

Everything is on **[docs.fireflo.au](https://docs.fireflo.au)** — installing and running it, the
REST and SMPP interfaces, routing, rating and prepaid credit, and the operator's control panel.

Start here:

| | |
| :--- | :--- |
| [Getting FireFlo](https://docs.fireflo.au/platform/install/getting-fireflo) | Verifying a release and installing it |
| [Control panel](https://docs.fireflo.au/platform/install/control-panel) | Installing the panel beside the gateway |
| [REST API](https://docs.fireflo.au/reference/api/overview) | Every endpoint, with the response envelope |
| [Sending a message](https://docs.fireflo.au/developers/send/one-message) | The first call to make |
| [Delivery receipts](https://docs.fireflo.au/developers/receive/delivery-receipts) | How outcomes come back |
| [Least-cost routing](https://docs.fireflo.au/platform/routing/least-cost) | Choosing between vendors on price |
| [Prepaid credit](https://docs.fireflo.au/platform/billing/prepaid-credit) | Rating, call records and the money identity |
| [Diagnostics](https://docs.fireflo.au/platform/operations/diagnostics) | What to turn on when something is wrong |

When FireFlo is running, API discovery is at `/swagger-ui` and `/openapi.json`.

## Support

**[support@fireflo.au](mailto:support@fireflo.au)** — for questions, for a licence, and for anything
that looks like a bug.

Tell us the version (`fireflo version`, or the `MANIFEST` beside the binary) and what you saw. If it
is a delivery problem, the message id from the call record is usually enough to find it.
