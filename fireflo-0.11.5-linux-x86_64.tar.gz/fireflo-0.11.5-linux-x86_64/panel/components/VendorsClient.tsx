"use client";
import { useState } from "react";
import Link from "next/link";
import { Antenna, Plus, RefreshCw, Waypoints } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClasses } from "@/components/ui/button";
import { PageHeader } from "@/components/ui/page-header";
import { HealthStrip } from "./CardBits";
import { RangePicker } from "./RangePicker";
import { WorkerForm } from "./WorkerForm";
import { VendorCard } from "./VendorCard";
import { VendorTraffic, type VendorRow } from "./VendorTraffic";
import { TrafficControlLegend } from "./WorkerCard";
import { WorkerSummary } from "./WorkerSummary";
import { useWorkers } from "./useWorkers";
import { useHealth } from "./useHealth";
import { useControlData, type Range } from "./useControlData";
import { readsWorkersFromDatabase } from "@/lib/health-types";
import { SEVERITY, needsAttention, verdictFor } from "@/lib/worker-verdict";
import { KIND, trafficKey, type Worker } from "@/lib/worker-types";
import { EmptyState } from "@/components/ui/empty-state";

/**
 * Vendors: the connections out to whoever carries our traffic.
 *
 * <p>Settings and traffic on one page, because they are two views of the same thing and having them
 * in separate menus meant answering "is this vendor working" in two places.
 *
 * <p>Vendors with traffic but no stored settings are shown too. With the gateway reading its
 * configuration from `smsg.properties` rather than the database that is <em>every</em> vendor, and
 * dropping them for having no row here would hide real spend.
 *
 * <p><strong>Ordered by how much attention each one needs</strong>, not alphabetically. A list is
 * scanned from the top, and a vendor that has stopped carrying traffic is the reason anyone opened
 * the page; leaving it in name order puts it wherever the alphabet happens to put it.
 */
export function VendorsClient() {
  const [range, setRange] = useState<Range>("24h");
  const [editing, setEditing] = useState<Worker | "new" | null>(null);
  const {
    workers, error, errorFor, notice, loading, busy,
    load, setEnabled, applyNow,
  } = useWorkers(KIND.vendor);
  const { data: traffic, error: trafficError } = useControlData<VendorRow[]>("vendors", range);
  const { health, error: healthError, byFullName } = useHealth();
  const fromDatabase = readsWorkersFromDatabase(health);

  //call detail records store the FULL worker name, so this is the only correct join key -- see
  //trafficKey, which exists because matching on the bare name silently reads zero for everything
  const byVendor = new Map((traffic ?? []).map((row) => [row.vendor ?? "", row]));
  const configured = new Set(workers.map((w) => trafficKey(w)));
  const unconfigured = (traffic ?? []).filter((row) => !configured.has(row.vendor ?? ""));

  const sorted = [...workers].sort((a, b) => severity(a) - severity(b) || a.name.localeCompare(b.name));
  const attention = sorted.filter((w) => needsAttention(verdictFor(w, byFullName, KIND.vendor))).length;

  function severity(worker: Worker): number {
    return SEVERITY[verdictFor(worker, byFullName, KIND.vendor).tone];
  }

  if (editing) {
    return (
      <WorkerForm
        type={KIND.vendor}
        worker={editing === "new" ? null : editing}
        onCancel={() => setEditing(null)}
        onSaved={async () => {
          setEditing(null);
          await load();
        }}
      />
    );
  }

  return (
    <>
      <PageHeader
        title="Vendors"
        description="Settings here, live connection state from the gateway, and traffic for the period."
        actions={
          <>
            <RangePicker value={range} onChange={setRange} />
            {/* routing lives here rather than in the nav: a routing table's whole job is choosing
                which of these vendors a message goes to, so it is only ever read next to them */}
            {/* no "Error codes" button here, deliberately. One sat beside Routing and went to the
                GLOBAL list, while each vendor card's footer carries a link to that vendor's own --
                two controls, one label, different destinations, and from a collapsed list only the
                global one was visible. The global list is reached from Configuration in the sidebar;
                a vendor's own is reached from that vendor */}
            <Link href="/cp/routing" className={buttonClasses({ variant: "outline" })}>
              <Waypoints className="h-4 w-4" />
              Routing
            </Link>
            <Button variant="outline" onClick={applyNow} disabled={busy === "__reload"}>
              <RefreshCw className="mr-1.5 h-4 w-4" />
              {busy === "__reload" ? "Reloading…" : "Apply now"}
            </Button>
            <Button onClick={() => setEditing("new")}>
              <Plus className="mr-1.5 h-4 w-4" />
              Add vendor
            </Button>
          </>
        }
      />

      {attention > 0 && (
        <HealthStrip>
          {attention === 1 ? "One vendor needs" : `${attention} vendors need`} attention — listed
          first.
        </HealthStrip>
      )}

      {fromDatabase === false && (
        <HealthStrip tone="destructive">
          <strong>Nothing on this page is loaded by the gateway.</strong> It is reading its workers
          from <code>smsg.properties</code>, not the database. These rows are stored, valid and
          ignored; start the gateway with <code>FIREFLO_CONFIG_SOURCE=db</code> to use them.
        </HealthStrip>
      )}

      {/* only what belongs to the page. An error from an action is rendered on the card that
          caused it, where the button is -- a banner up here is off screen by the eighth vendor */}
      {((error && !errorFor) || trafficError) && (
        <Card>
          <CardContent className="py-4 text-sm text-destructive">{error || trafficError}</CardContent>
        </Card>
      )}
      {healthError && (
        <Card>
          <CardContent className="py-4 text-sm text-muted-foreground">
            Live state unavailable: {healthError} — settings below are still current.
          </CardContent>
        </Card>
      )}
      {notice && (
        <Card>
          <CardContent className="py-4 text-sm text-muted-foreground">{notice}</CardContent>
        </Card>
      )}

      {!errorFor && !error && !workers.length && !unconfigured.length && (
        <EmptyState>
          {loading ? "Loading…" : "No vendors yet"}
        </EmptyState>
      )}

      <WorkerSummary
        workers={workers}
        byFullName={byFullName}
        type={KIND.vendor}
        loading={loading}
      />

      {/* a grid of short cards. Sorted by severity so the one that stopped is first; everything a
          card does not show is on the vendor's own page, one click away */}
      <div className="grid gap-4 xl:grid-cols-2">
        {sorted.map((vendor) => {
          const verdict = verdictFor(vendor, byFullName, KIND.vendor);
          const row = byVendor.get(trafficKey(vendor));
          return (
            <div key={vendor.name} className="min-w-0 space-y-2">
              <VendorCard
                worker={vendor}
                live={byFullName.get(trafficKey(vendor))}
                verdict={verdict}
                sent={row ? Number(row.attempts ?? 0) : null}
                busy={busy === vendor.name}
                onEdit={() => setEditing(vendor)}
                onToggleEnabled={(enabled) => setEnabled(vendor.name, enabled)}
                onTest={verdict.tone === "destructive" ? () => { window.location.assign(`/cp/vendors/${encodeURIComponent(vendor.name)}#test`); } : undefined}
              />
              {errorFor === vendor.name && error && (
                <p className="text-xs text-destructive">{error}</p>
              )}
            </div>
          );
        })}

        {unconfigured.map((row) => (
          <Card key={row.vendor ?? "unrouted"} className="min-w-0 border-border/60">
            <CardHeader>
              <CardTitle className="flex flex-wrap items-center gap-2">
                <Antenna className="h-4 w-4 text-muted-foreground" />
                {row.vendor ?? "Never routed"}
                <Badge variant="outline">no stored settings</Badge>
              </CardTitle>
              <CardDescription>
                {row.vendor
                  ? "Carrying traffic but configured outside the database — most likely in smsg.properties. Nothing here can be edited or controlled."
                  : "Messages that never reached a vendor at all."}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <VendorTraffic row={row} />
            </CardContent>
          </Card>
        ))}
      </div>

      {!!workers.length && <TrafficControlLegend type={KIND.vendor} />}
    </>
  );
}
