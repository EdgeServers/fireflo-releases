"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { Tabs } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { StatCard } from "./StatCard";
import { Antenna, Wallet } from "lucide-react";
import { AdvancedToggle } from "./AdvancedToggle";
import { CardActions, Figures, HealthStrip } from "./CardBits";
import { RateRuleLines } from "./RateRuleLines";
import { DangerAction } from "./DangerAction";
import { useAdvanced } from "@/hooks/useAdvanced";
import { ScopeForm } from "./ScopeForm";
import { useProductCatalogue } from "./useProducts";
import { useRates } from "./useRates";
import { GatewayIgnores } from "./GatewayIgnores";
import { UnratedPreflight } from "./UnratedPreflight";
import { useHealth } from "./useHealth";
import { readsRatesFromDatabase } from "@/lib/health-types";
import { type RateRule, type RateRuleInput, type ScopeKind, type ScopeSummary, scopeKind } from "@/lib/rate-types";
import { EmptyState } from "@/components/ui/empty-state";

type Editing = { scope: string; rules: RateRuleInput[]; isNew: boolean } | null;

/** One empty row, so a form asking for a price opens with somewhere to type one. */
const BLANK_RULE: RateRuleInput = {
  id: null,
  amount: "",
  product: null,
  currency: null,
  label: null,
  enabled: true,
  conditions: [],
  filters: [],
};

/**
 * Pricing: what we pay each vendor, and what each account pays us.
 *
 * <p>Those are the same table. `app_rate_rule.scope` is one column holding either a vendor instance
 * name or an account id, and nothing in the schema distinguishes them — the gateway tells them apart
 * only by which lookup asks. So this page groups them, because a list that mixed them would be a
 * list where our costs and our revenue looked identical.
 *
 * <p>The third group is the one that matters: a scope matching neither. Those rules load fine and
 * match nothing, which for a cost scope means every message through that vendor has an unknown cost
 * and a margin that looks wonderful. It is styled to be impossible to scroll past.
 */
export function PricingClient() {
  const { scopes, known, error, loading, busy, loadScope, saveScope, removeScope } = useRates();
  const { health } = useHealth();
  const [editing, setEditing] = useState<Editing>(null);
  const [expanded, setExpanded] = useState<Record<string, RateRule[]>>({});
  const [tab, setTab] = useState<"cost" | "price" | "default">("price");
  const [advanced, setAdvanced] = useAdvanced("pricing");

  //the shared hook rather than a fetch of its own, which offered `app_product` rows only. A product
  //named by a login or a rule without a catalogue row -- the normal state of anything imported, and
  //the likeliest thing to be pricing -- was missing from the dropdown while plainly in use elsewhere
  const catalogue = useProductCatalogue();

  const expand = useCallback(
    async (scope: string) => {
      if (expanded[scope]) {
        setExpanded((e) => {
          const next = { ...e };
          delete next[scope];
          return next;
        });
        return;
      }
      const rules = await loadScope(scope);
      if (rules) {
        setExpanded((e) => ({ ...e, [scope]: rules }));
      }
    },
    [expanded, loadScope]
  );

  //`?scope=&product=` opens this page on the thing that sent you here. The product page links in
  //with both, because a link that lands you on a list which hides its sell-side section when empty
  //-- exactly when you need it -- is how "Add pricing" became a button that appeared to do nothing
  const opened = useRef(false);
  useEffect(() => {
    if (opened.current) {
      return;
    }
    opened.current = true;
    const params = new URLSearchParams(window.location.search);
    const scope = params.get("scope");
    if (!scope) {
      return;
    }
    const product = params.get("product");
    void (async () => {
      //an existing scope is opened for editing rather than recreated: a create would replace it,
      //and this URL can be bookmarked long after the scope was set up
      const rules = await loadScope(scope);
      setEditing(
        rules?.length
          ? { scope, rules, isNew: false }
          : { scope, isNew: true, rules: [{ ...BLANK_RULE, product }] }
      );
    })();
  }, [loadScope]);

  async function edit(scope: string) {
    const rules = await loadScope(scope);
    if (rules) {
      setEditing({ scope, rules, isNew: false });
    }
  }

  const fromDatabase = readsRatesFromDatabase(health);
  const nothingStored = fromDatabase === true && !scopes.length;

  if (editing) {
    return (
      <ScopeForm
        scope={editing.scope}
        initial={editing.rules}
        known={known}
        catalogue={catalogue}
        isNew={editing.isNew}
        onSave={async (scope, rules, confirmed) => {
          const failure = await saveScope(scope, rules, confirmed, editing.isNew);
          if (!failure) {
            setEditing(null);
            setExpanded({});
          }
          return failure;
        }}
        onCancel={() => setEditing(null)}
      />
    );
  }

  const byKind = (kind: ScopeKind) => scopes.filter((s) => scopeKind(s.scope, known) === kind);
  const cost = byKind("cost");
  const price = byKind("price");
  const dflt = byKind("default");
  const unknown = byKind("unknown");
  const pricedAccounts = new Set(price.map((s) => s.scope));
  const unpricedAccounts = known.accounts.filter((a) => !pricedAccounts.has(a));
  const pricedVendors = new Set(cost.map((s) => s.scope));

  const tabs = [
    { id: "cost" as const, label: `Cost · what vendors charge us · ${cost.length}` },
    { id: "price" as const, label: `Price · what accounts pay · ${price.length}` },
    { id: "default" as const, label: `Default · what everyone pays${dflt.length ? "" : " · none"}` },
  ];
  const shown = tab === "cost" ? cost : tab === "price" ? price : dflt;
  const consequence = (s: ScopeSummary, kind: ScopeKind) =>
    `All ${s.rules} rule(s) for '${s.scope}' go. `
    + (kind === "cost"
      ? "Messages through it will have no recorded cost, so margin on them becomes unknown."
      : "Messages for it will have no price.");

  return (
    <>
      <PageHeader
        title="Pricing"
        description="The first rule that matches wins, within a scope and a product."
        actions={
          <>
            <AdvancedToggle on={advanced} onChange={setAdvanced} />
            <Button
              //with a row in it. Opening empty let a save through that stored nothing at all and
              //answered 200 -- the list came back unchanged and the button looked broken
              onClick={() => setEditing({ scope: "", rules: [{ ...BLANK_RULE }], isNew: true })}
              className="gap-2"
            >
              <Plus className="h-4 w-4" />
              Add pricing
            </Button>
          </>
        }
      />

      {/* ordered deliberately: nothing below matters if the gateway is not reading any of it */}
      <GatewayIgnores domain="rates" />
      <UnratedPreflight />

      {nothingStored && (
        <HealthStrip tone="destructive">
          <strong>The gateway is reading pricing from this database, and there is none.</strong>{" "}
          Every message is accepted with no price and no cost. Import the file with{" "}
          <code>scripts/fireflo import rates</code>, or add pricing here, now.
        </HealthStrip>
      )}
      {error && <HealthStrip tone="destructive">{error}</HealthStrip>}

      <div className="grid gap-4 sm:grid-cols-2">
        <StatCard
          title="Vendors priced"
          value={`${known.vendors.filter((v) => pricedVendors.has(v)).length} of ${known.vendors.length}`}
          hint={known.vendors.every((v) => pricedVendors.has(v)) ? "Every vendor has a cost" : "A vendor without a cost makes its margin look better than it is"}
          icon={Antenna}
          loading={loading}
          tone={known.vendors.every((v) => pricedVendors.has(v)) ? "default" : "negative"}
        />
        <StatCard
          title="Accounts priced"
          value={`${pricedAccounts.size} of ${known.accounts.length}`}
          hint={unpricedAccounts.length ? `${unpricedAccounts.length} fall${unpricedAccounts.length === 1 ? "s" : ""} back to the default` : "Every account has its own pricing"}
          icon={Wallet}
          loading={loading}
        />
      </div>

      {!!unknown.length && (
        <HealthStrip tone="destructive">
          {unknown.length === 1 ? "1 scope prices" : `${unknown.length} scopes price`} something that is neither a
          configured vendor nor an account that has sent:{" "}
          {unknown.map((s) => <code key={s.scope} className="mr-1">{s.scope}</code>)}
          Their rules load and match nothing. {advanced ? "" : "Switch on Advanced to edit or delete them."}
        </HealthStrip>
      )}

      {!scopes.length && !nothingStored && (
        <EmptyState>
          {loading ? "Loading…" : "No pricing stored yet"}
        </EmptyState>
      )}

      <Tabs label="Pricing" items={tabs} active={tab} onSelect={setTab} />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {shown.map((s) => (
          <ScopeCard
            key={s.scope}
            summary={s}
            kind={tab}
            rules={expanded[s.scope]}
            busy={busy === s.scope}
            advanced={advanced}
            onToggle={() => expand(s.scope)}
            onEdit={() => edit(s.scope)}
            removeConsequence={consequence(s, tab)}
            onRemove={() => removeScope(s.scope)}
          />
        ))}
        {tab === "price" && unpricedAccounts.map((a) => (
          <Card key={`unpriced-${a}`} className="min-w-0 border-dashed opacity-80">
            <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0">
              <span className="text-sm font-medium">{a}</span>
              <Badge variant="warning">Default</Badge>
              <CardActions>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setEditing({ scope: a, rules: [{ ...BLANK_RULE }], isNew: true })}
                >
                  Price this account
                </Button>
              </CardActions>
            </CardHeader>
            <CardContent className="text-xs text-muted-foreground">
              No pricing of its own. Pays what everyone pays{dflt.length ? "" : " — and nothing is set there either"}.
            </CardContent>
          </Card>
        ))}
        {tab === "default" && !dflt.length && (
          <Card className="min-w-0 border-dashed md:col-span-2 xl:col-span-3">
            <CardContent className="flex flex-wrap items-center gap-3 py-4 text-sm text-muted-foreground">
              Nothing is set for accounts without pricing of their own.
              <Button variant="outline" size="sm" onClick={() => setEditing({ scope: "*", rules: [{ ...BLANK_RULE }], isNew: true })}>
                Set what everyone pays
              </Button>
            </CardContent>
          </Card>
        )}
        {advanced && tab === "price" && unknown.map((s) => (
          <ScopeCard
            key={`unknown-${s.scope}`}
            summary={s}
            kind="unknown"
            rules={expanded[s.scope]}
            busy={busy === s.scope}
            advanced={advanced}
            onToggle={() => expand(s.scope)}
            onEdit={() => edit(s.scope)}
            removeConsequence={consequence(s, "unknown")}
            onRemove={() => removeScope(s.scope)}
          />
        ))}
      </div>
    </>
  );
}

function ScopeCard({
  summary,
  kind,
  rules,
  busy,
  advanced,
  onToggle,
  onEdit,
  onRemove,
  removeConsequence,
}: {
  summary: ScopeSummary;
  kind: ScopeKind;
  rules: RateRule[] | undefined;
  busy: boolean;
  advanced: boolean;
  onToggle: () => void;
  onEdit: () => void;
  onRemove: () => void;
  /** What deleting this scope costs, in the caller's words -- cost and price lose different things. */
  removeConsequence: string;
}) {
  const amounts = (rules ?? []).map((r) => Number(r.amount)).filter((n) => Number.isFinite(n));
  const range = amounts.length
    ? amounts.length === 1 || Math.min(...amounts) === Math.max(...amounts)
      ? String(Math.min(...amounts))
      : `${Math.min(...amounts)} – ${Math.max(...amounts)}`
    : null;
  const href = kind === "cost" ? `/cp/vendors/${encodeURIComponent(summary.scope)}` : kind === "price" ? `/cp/accounts/${encodeURIComponent(summary.scope)}` : null;
  return (
    <Card className={cn("min-w-0", kind === "unknown" && "border-destructive")}>
      <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
        {/* where a scope is edited scope-complete: the vendor page for a cost scope, the account for
            a price one. An unknown scope has neither, and not linking is more honest than a guess */}
        {href ? (
          <Link href={href} className="text-sm font-medium hover:underline">
            {kind === "default" ? "Everyone" : summary.scope}
          </Link>
        ) : (
          <span className="text-sm font-medium">{summary.scope}</span>
        )}
        {kind === "unknown" && <Badge variant="destructive">unknown scope</Badge>}
        <CardActions>
          <Button variant="outline" size="sm" onClick={onEdit}>Edit</Button>
          <Button variant="ghost" size="sm" onClick={onToggle}>{rules ? "Hide rules" : "Show rules"}</Button>
          {advanced && (
            <DangerAction
              label="Delete"
              confirmLabel="Delete these rules"
              consequence={removeConsequence}
              busy={busy}
              onConfirm={onRemove}
            />
          )}
        </CardActions>
      </CardHeader>
      <CardContent className="space-y-3 pt-3">
        <div className="flex flex-wrap gap-1">
          {summary.products.length
            ? summary.products.map((p) => <Badge key={p} variant="outline">{p}</Badge>)
            : <Badge variant="outline">any product</Badge>}
        </div>
        <Figures
          figures={[
            { value: summary.rules, label: summary.rules === 1 ? "rule" : "rules" },
            ...(summary.enabled < summary.rules ? [{ value: summary.rules - summary.enabled, label: "retired", tone: "warning" as const }] : []),
            ...(range ? [{ value: <span className="font-mono">{range}</span>, label: "per message" }] : []),
          ]}
        />
        {rules && (
          <div className="border-t border-dashed border-border pt-3">
            <RateRuleLines rules={rules} />
          </div>
        )}
      </CardContent>
    </Card>
  );
}
