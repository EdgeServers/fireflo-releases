"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from "recharts";
import { CheckCircle2, Receipt, Send, TriangleAlert } from "lucide-react";
import {
  ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig,
} from "@/components/ui/chart";
import { StatCard } from "./StatCard";
import { count, money } from "@/lib/format";
import { recentMonths } from "@/lib/billing-period";
import { creditNoteMessage, type ClosedPeriod, type Restatement } from "@/lib/period-close";
import type { UsageDay } from "@/lib/metrics-queries";
import type { StatementSummary } from "@/lib/statement-queries";

/** See `UsageClient` — a Bar draws nothing at all until a frame is painted. */
const ANIMATION = { isAnimationActive: false } as const;

const chartConfig = {
  price: { label: "Billed", color: "var(--color-chart-1)" },
} satisfies ChartConfig;

/** What the route returns on top of the summary itself. */
interface StatementPayload extends StatementSummary {
  /** The same window at day grain, from the query `/cp/usage` uses. */
  days: UsageDay[];
  closed: ClosedPeriod[];
  closedAs: ClosedPeriod | null;
  restatement: Restatement | null;
}

interface ExportJob {
  id: string;
  status: string;
  rows?: number;
  error?: string | null;
}

/**
 * One account's bill for one period, with the CSV and the close action beside it.
 *
 * <p>The three things live on one screen because they are one decision: an operator reads the
 * figure, downloads it if somebody has asked for it, and closes the period once they believe it.
 * Closing on a different screen from the number being closed is how the wrong month gets invoiced.
 *
 * <p>The period picker offers recent months and an arbitrary window. A month is the normal case and
 * is one click; the custom range exists because a customer query is rarely about a whole month.
 */
export function StatementClient({ id, currency }: { id: string; currency: string }) {
  //the month in progress is offered, and labelled -- an operator watching a postpaid account's
  //accrual wants exactly that, and it is the picker's job to say it has not finished
  const months = useMemo(() => recentMonths(new Date(), 13), []);
  const thisMonth = months[0];

  const [month, setMonth] = useState(months[1] ?? thisMonth);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [custom, setCustom] = useState(false);

  const [data, setData] = useState<StatementPayload | null>(null);
  const [jobs, setJobs] = useState<ExportJob[]>([]);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);

  const query = useMemo(
    () => (custom ? `from=${from}&to=${to}` : `month=${month}`),
    [custom, from, to, month]
  );
  const base = `/api/control/accounts/${encodeURIComponent(id)}/statement`;

  const load = useCallback(async () => {
    if (custom && (!from || !to)) {
      return;
    }
    setBusy(true);
    setError("");
    try {
      const res = await fetch(`${base}?${query}`, { cache: "no-store" });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Could not read the statement (${res.status}).`);
        setData(null);
        return;
      }
      setData(json?.data ?? null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not read the statement.");
    } finally {
      setBusy(false);
    }
  }, [base, query, custom, from, to]);

  const loadJobs = useCallback(async () => {
    try {
      const res = await fetch(`${base}?exports=1`, { cache: "no-store" });
      const json = await res.json().catch(() => null);
      setJobs(Array.isArray(json?.data) ? json.data : []);
    } catch {
      //the file list is a convenience beside the figure, never a reason to fail the page
    }
  }, [base]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    void loadJobs();
  }, [loadJobs]);

  async function requestCsv() {
    setBusy(true);
    setNotice("");
    try {
      const res = await fetch(`${base}?${query}`, { method: "POST" });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? "Could not prepare the file.");
        return;
      }
      setNotice("Preparing the file. It appears below when it is ready.");
      await loadJobs();
    } finally {
      setBusy(false);
    }
  }

  async function close() {
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const res = await fetch(`${base}?${query}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? "Could not close the period.");
        return;
      }
      setNotice(json?.notice ?? "Closed.");
      await load();
    } finally {
      setBusy(false);
    }
  }

  const label = data?.label ?? (custom ? `${from}..${to}` : month);
  const isClosed = Boolean(data?.closedAs);
  //the month in progress cannot be closed, and saying why beats a disabled button with no reason
  const unfinished = !custom && month === thisMonth;

  return (
    <>
      {/* a control row, not a Card. This is a tab now, and wrapping a period picker in its own
          titled card put a heading over three inputs and pushed the figure below the fold */}
      <div className="flex flex-wrap items-end gap-3">
        {!custom ? (
          <div className="space-y-1">
            <Label htmlFor="stmt-month" className="text-sm">Month</Label>
            <select
              id="stmt-month"
              className="h-11 rounded-md border border-input bg-background px-2 text-sm md:h-7"
              value={month}
              onChange={(e) => setMonth(e.target.value)}
            >
              {months.map((m) => (
                <option key={m} value={m}>
                  {m}
                  {m === thisMonth ? " (in progress)" : ""}
                </option>
              ))}
            </select>
          </div>
        ) : (
          <>
            <div className="space-y-1">
              <Label htmlFor="stmt-from" className="text-sm">From</Label>
              <Input id="stmt-from" type="date" className="h-7 w-40 text-sm"
                value={from} onChange={(e) => setFrom(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label htmlFor="stmt-to" className="text-sm">To</Label>
              <Input id="stmt-to" type="date" className="h-7 w-40 text-sm"
                value={to} onChange={(e) => setTo(e.target.value)} />
            </div>
          </>
        )}
        <Button size="sm" variant="ghost" className="h-7"
          onClick={() => { setCustom(!custom); setData(null); }}>
          {custom ? "Use a month" : "Use a date range"}
        </Button>
        {data && (
          <div className="ml-auto flex flex-wrap items-center gap-2">
            <Button size="sm" variant="ghost" className="h-7" disabled={busy}
              onClick={() => void requestCsv()}>
              Download CSV
            </Button>
            {!isClosed && !unfinished && (
              <Button size="sm" className="h-7" disabled={busy} onClick={() => void close()}>
                Close this period
              </Button>
            )}
          </div>
        )}
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}

      {data && (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard title="Amount" value={money(data.totalAmount, currency)} icon={Receipt}
            hint={isClosed ? `${label} · closed` : label} />
          <StatCard title="Submitted" value={count(data.totalSubmitted)} icon={Send} />
          <StatCard title="Delivered" value={count(data.totalDelivered)} icon={CheckCircle2}
            tone="positive" />
          {/* only when there is some. A tile reading zero teaches an operator to ignore the tile */}
          {data.totalUnrated > 0 && (
            <StatCard title="Sent, not billed" value={count(data.totalUnrated)} icon={TriangleAlert}
              tone="negative" hint="No price applied. Sent all the same." />
          )}
        </div>
      )}

      {/*
        The chart is 31 bars; given the full width of a desktop it just grows fat bars and says
        nothing more. Two columns put the space to work instead -- the same shape the Overview and
        Settings tabs use, so the account page stays consistent with itself.

        `minmax(0,1fr)`, never a bare `1fr`: a recharts container measures its parent, and a bare
        track's automatic minimum is its content, so chart and column chase each other outward and
        take the page with them. MisOverviewClient records the same trap.

        `items-start` because all three cards are guarded separately -- a fresh account has no
        prepared files and no closed periods, and the chart must not stretch to fill their absence.
      */}
      <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_20rem]">
        {/* each cell is a wrapper that always exists. A bare `{cond && <Card/>}` renders nothing at
            all when the guard is false -- not an empty cell, no cell -- so on an account with no
            traffic yet the rail would slide into the wide left track */}
        <div className="min-w-0">
        {data && data.days.length > 0 && (
          <Card>
            <CardHeader bar>
              <CardTitle>Billed per day</CardTitle>
              <CardDescription>
                The same window the total above covers, day by day. A month that is one large day and
                nothing else is usually a bulk send somebody did not expect to be billed for.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer config={chartConfig} className="h-40 w-full">
                <BarChart data={data.days} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--color-border)" />
                  <XAxis dataKey="day" tickLine={false} axisLine={false}
                    tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                    tickFormatter={(v: string) => v.slice(8)} interval="preserveStartEnd" />
                  <YAxis tickLine={false} axisLine={false} width={52}
                    tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                    //the axis divides by the scale exactly once, here. The values stay scaled
                    //integers everywhere else, which is what stops a rounding step creeping in
                    tickFormatter={(v: number) => (v / 10_000).toFixed(0)} />
                  <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
                  <Bar {...ANIMATION} dataKey="price" fill={chartConfig.price.color} radius={2} />
                </BarChart>
              </ChartContainer>
            </CardContent>
          </Card>
        )}
        </div>
        <div className="min-w-0 space-y-4">
          {jobs.length > 0 && (
            <Card>
              <CardHeader bar>
                <CardTitle>Prepared files</CardTitle>
              </CardHeader>
              <CardContent className="space-y-1.5">
                {jobs.map((job) => (
                  <div key={job.id} className="flex flex-wrap items-center gap-2 text-sm">
                    <span className="text-muted-foreground">{job.status}</span>
                    {job.rows != null && <span className="tabular-nums">{job.rows.toLocaleString()} rows</span>}
                    {job.status === "ready" && (
                      <a className="text-primary hover:underline" href={`${base}/${job.id}`}>Download</a>
                    )}
                    {job.error && <span className="text-destructive">{job.error}</span>}
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
          {data && data.closed.length > 0 && (
            <Card>
              <CardHeader bar>
                <CardTitle>Closed periods</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-1 text-sm">
                  {data.closed.map((c) => (
                    <li key={c.label} className="flex flex-wrap items-baseline gap-2">
                      <button
                        type="button"
                        className="underline underline-offset-2 hover:text-foreground"
                        onClick={() => { setCustom(false); setMonth(c.label); }}
                      >
                        {c.label}
                      </button>
                      <span className="font-mono tabular-nums">{money(c.invoiced, currency)}</span>
                      {c.note && <span className="text-muted-foreground">{c.note}</span>}
                    </li>
                  ))}
                </ul>
                <p className="mt-2 text-xs text-muted-foreground">
                  A closed period is never reissued. Anything landing against one afterwards shows as a
                  credit note on the period that follows it.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {data && (
        <Card>
          <CardHeader bar>
            <CardTitle>
              {label}
              {isClosed && <span className="ml-2 text-xs font-normal text-muted-foreground">closed</span>}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">

            {unfinished && (
              <p className="text-xs text-muted-foreground">
                This month has not finished, so it cannot be closed. The figure moves as traffic
                arrives.
              </p>
            )}

            {data.restatement && (
              //the whole reason a closed period is stored rather than recomputed
              <p className="text-sm text-amber-600 dark:text-amber-400">
                {creditNoteMessage(data.restatement, (s) => money(s, currency))}
              </p>
            )}

            {data.lines.length > 0 ? (
              <TableInCard>
                <THead>
                  <TR>
                    <TH>Product</TH>
                    <TH>Submitted</TH>
                    <TH>Delivered</TH>
                    <TH>Failed</TH>
                    <TH>Expired</TH>
                    <TH>Pending</TH>
                    <TH>Not billed</TH>
                    <TH>Amount</TH>
                  </TR>
                </THead>
                <TBody className="tabular-nums">
                  {data.lines.map((l) => (
                    <TR key={l.product || "(none)"}>
                      <TD>{l.product || <span className="text-muted-foreground">no product</span>}</TD>
                      <TD>{l.submitted.toLocaleString()}</TD>
                      <TD>{l.delivered.toLocaleString()}</TD>
                      <TD>{l.failed.toLocaleString()}</TD>
                      <TD>{l.expired.toLocaleString()}</TD>
                      <TD>{l.pending.toLocaleString()}</TD>
                      <TD>{l.unrated.toLocaleString()}</TD>
                      <TD className="font-mono">{money(l.amount, currency)}</TD>
                    </TR>
                  ))}
                </TBody>
              </TableInCard>
            ) : (
              <p className="text-sm text-muted-foreground">No traffic in this period.</p>
            )}

            <p className="text-xs text-muted-foreground">
              Billed on <strong>submitted</strong>, on a half-open window, so a message belongs to
              exactly one period. Delivery figures keep moving as receipts arrive; the amount does
              not.
            </p>
            {notice && <p className="text-xs text-amber-600 dark:text-amber-400">{notice}</p>}
          </CardContent>
        </Card>
      )}
    </>
  );
}
