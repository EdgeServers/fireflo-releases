"use client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

/**
 * One headline figure.
 *
 * <p>The three-state ladder — skeleton, error, value — is the sibling panel's idiom, kept because a
 * dashboard that renders 0 while it is still loading is worse than one that renders nothing.
 */
export function StatCard({
  title,
  value,
  hint,
  icon: Icon,
  loading,
  error,
  tone = "default",
}: {
  title: string;
  value: string;
  hint?: string;
  icon: React.ElementType;
  loading?: boolean;
  error?: string;
  tone?: "default" | "positive" | "negative";
}) {
  const toneClass =
    tone === "positive" ? "text-primary" : tone === "negative" ? "text-destructive" : "";

  return (
    <Card className="min-w-0">
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle className="text-muted-foreground">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-8 w-24 animate-pulse rounded bg-muted" />
        ) : error ? (
          <p className="text-sm text-destructive">{error}</p>
        ) : (
          <>
            <p className={`text-2xl font-semibold tabular-nums ${toneClass}`}>{value}</p>
            {hint && <p className="mt-0.5 text-xs text-muted-foreground">{hint}</p>}
          </>
        )}
      </CardContent>
    </Card>
  );
}
