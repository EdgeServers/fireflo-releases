"use client";
import { useState } from "react";
import Link from "next/link";
import { AlertTriangle, ArrowRight, Stethoscope } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ErrorNote } from "./FormNotices";
import { ConfirmDialog } from "./ConfirmDialog";
import { Select } from "@/components/ui/select";
import type { ApplyAction } from "@/lib/delivery-diagnosis";
import { SEVERITY_LABEL, type Finding, type Severity } from "@/lib/delivery-diagnosis";
import { diagnosisSummary } from "@/lib/delivery-diagnosis";

/**
 * One button that answers "why is nothing being delivered?".
 *
 * <p><strong>It lives on the routing page and is not a routing check.</strong> That is deliberate
 * and it is also the thing most likely to be misread, so the description says so before anybody
 * clicks: the commonest answer is a whitelist refusal or an empty balance, both of which happen
 * long before a route table is consulted. Somebody standing on this page because messages are
 * failing is exactly the person who needs to be told to look elsewhere.
 *
 * <p>Runs on demand rather than on load, following `TestConnection`: it fans out to both databases
 * and the gateway's management port, which is not something to do on every page render.
 */
export function DeliveryCheck({ accountId, bare = false }: { accountId?: string; bare?: boolean }) {
  const [findings, setFindings] = useState<Finding[] | null>(null);
  const [skipped, setSkipped] = useState<string[]>([]);
  const [boundVendors, setBoundVendors] = useState<string[]>([]);
  const [error, setError] = useState("");
  const [running, setRunning] = useState(false);
  //one dialog for the whole report: two confirmations open at once is not a state worth reaching
  const [pending, setPending] = useState<Finding | null>(null);
  const [target, setTarget] = useState("");
  const [applying, setApplying] = useState(false);
  const [applyError, setApplyError] = useState("");
  const [applied, setApplied] = useState("");

  async function run() {
    setRunning(true);
    setError("");
    try {
      const query = accountId ? `?account=${encodeURIComponent(accountId)}` : "";
      const res = await fetch(`/api/control/delivery-check${query}`, { method: "POST" });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      setFindings(json.data.findings as Finding[]);
      setSkipped((json.data.skipped as string[]) ?? []);
      setBoundVendors((json.data.boundVendors as string[]) ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "The check could not run.");
    } finally {
      setRunning(false);
    }
  }

  async function apply() {
    if (!pending?.apply) {
      return;
    }
    setApplying(true);
    setApplyError("");
    try {
      const body: ApplyAction & { target?: string } = pending.apply.kind === "addCatchAll"
        ? { ...pending.apply, target }
        : pending.apply;
      const res = await fetch("/api/control/delivery-check/apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setApplyError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      setApplied(json.data.applied as string);
      setPending(null);
      setTarget("");
      //re-run rather than crossing the finding out: the fix may have revealed the next one, and a
      //report showing a state that no longer exists is how somebody fixes the same thing twice
      await run();
    } catch (err) {
      setApplyError(err instanceof Error ? err.message : "The fix could not be applied.");
    } finally {
      setApplying(false);
    }
  }

  const summary = findings ? diagnosisSummary(findings) : null;

  //bare: no card of its own, for a page that sets it beside another tool inside one card
  const Frame = bare ? "div" : Card;
  return (
    <Frame className="min-w-0">
      <CardHeader className="space-y-1.5 pb-3">
        <CardTitle className="flex items-center gap-2 text-base font-medium">
          <Stethoscope className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
          Delivery check
        </CardTitle>
        <CardDescription>
          {accountId
            ? `Walks the whole path a message from ${accountId} takes — a sample of what was
               refused in the last 24 hours, then approvals, TLVs, pricing, credit, routing and
               vendors.`
            : `Walks the whole path a message takes, not just routing: a sample of what was refused
               in the last 24 hours, then approvals, TLVs, pricing, credit, routing and vendors.`}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <Button size="sm" variant="outline" disabled={running} onClick={run}>
          {running ? "Checking…" : findings ? "Check again" : "Check delivery"}
        </Button>

        <ErrorNote error={error} />
        {applied && (
          <p className="rounded-md border border-emerald-500/40 bg-emerald-500/5 p-3 text-base">
            {applied}
          </p>
        )}

        {findings && !findings.length && (
          <p className="text-base text-muted-foreground">
            Nothing here is stopping messages. This cannot see what a client actually sends, or
            whether a route condition matches real traffic — so it is not a clean bill of health,
            only the absence of the faults it knows how to look for.
          </p>
        )}

        {findings && findings.length > 0 && (
          <div className="space-y-3">
            <p className="text-base font-medium">{summary}</p>
            {findings.map((f) => (
              <FindingNote
                key={f.key}
                finding={f}
                onApply={() => { setApplyError(""); setApplied(""); setPending(f); }}
              />
            ))}
          </div>
        )}

        {findings && skipped.length > 0 && (
          //not an error, and not silence either: a check that looked at six things out of eight and
          //said "nothing wrong" would be worse than no check at all
          <p className="text-xs text-muted-foreground">
            Not checked: {skipped.join("; ")}.
          </p>
        )}
      </CardContent>

      <ConfirmDialog
        open={Boolean(pending)}
        title={pending ? applyTitle(pending) : ""}
        consequence={pending ? applyConsequence(pending) : ""}
        confirmLabel="Apply"
        tone="primary"
        busy={applying}
        error={applyError}
        onConfirm={apply}
        onCancel={() => { setPending(null); setTarget(""); setApplyError(""); }}
      >
        {pending?.apply?.kind === "addCatchAll" && (
          <div className="mt-3">
            <label className="mb-1.5 block text-sm text-muted-foreground" htmlFor="dc-target">
              Send unmatched traffic to
            </label>
            <Select id="dc-target" value={target} onChange={(e) => setTarget(e.target.value)}>
              <option value="">Choose a vendor…</option>
              {boundVendors.map((v) => <option key={v} value={v}>{v}</option>)}
            </Select>
            <p className="mt-1 text-xs text-muted-foreground">
              {boundVendors.length
                ? "Only vendors the gateway is currently connected to are offered — a catch-all "
                  + "pointing at one that is not bound is the same outage with an extra step. "
                  + "Anything matching no other rule goes here and is billed at whatever rate "
                  + "matches; the panel will not choose that for you."
                : "No vendor is currently connected, so there is nothing safe to point this at. "
                  + "Get one bound first — or, if live state could not be read, add the rule from "
                  + "the routing table instead."}
            </p>
          </div>
        )}
      </ConfirmDialog>
    </Frame>
  );
}

function applyTitle(f: Finding): string {
  switch (f.apply?.kind) {
    case "moveCatchAllLast": return "Move the catch-all last";
    case "addCatchAll": return "Add a catch-all";
    case "enableWorker": return `Switch ${f.apply.worker} back on`;
    case "reportMode": return "Set this account to REPORT";
    default: return "Apply this fix";
  }
}

/** Named consequences, in the specific. "Are you sure?" is a question nobody has answered no to. */
function applyConsequence(f: Finding): string {
  switch (f.apply?.kind) {
    case "moveCatchAllLast":
      return `The catch-all in '${f.apply.table}' moves to the end, so the rules below it start `
        + "matching again. Traffic they were written for stops going to the catch-all's target. "
        + "This reaches the gateway on its next configuration poll.";
    case "addCatchAll":
      return `A rule with no conditions is added to the end of '${f.apply.table}'. Every message `
        + "that matches no other rule then goes to the vendor you pick — which is what stops them "
        + "being dropped, and also means traffic you have not thought about will be sent and billed.";
    case "enableWorker":
      return `${f.apply.worker} is switched back on and the gateway will start dialling it within `
        + "one configuration poll. Reversible from the Vendors page.";
    case "reportMode":
      return `${f.apply.accountId} STOPS ENFORCING ${f.apply.which === "header" ? "sender IDs" : "content"}`
        + " and starts logging what it would have refused instead. Traffic flows immediately, "
        + "including anything unapproved. Put it back to ENFORCE once the approvals are in.";
    default:
      return "";
  }
}

const TONE: Record<Severity, string> = {
  stopping: "border-destructive/40 bg-destructive/5",
  degrading: "border-amber-500/40 bg-amber-500/5",
  latent: "border-border bg-muted/30",
};

function FindingNote({ finding, onApply }: { finding: Finding; onApply: () => void }) {
  return (
    <div className={`rounded-md border p-3 ${TONE[finding.severity]}`}>
      <p className="flex items-start gap-2 text-base font-medium">
        {finding.severity !== "latent" && (
          <AlertTriangle
            className={`mt-0.5 h-4 w-4 shrink-0 ${
              finding.severity === "stopping" ? "text-destructive" : "text-amber-500"
            }`}
            aria-hidden="true"
          />
        )}
        <span>{finding.headline}</span>
      </p>
      <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{finding.detail}</p>
      <p className="mt-1.5 text-sm leading-relaxed">
        <span className="font-medium">Fix: </span>
        {finding.fix}
      </p>
      {finding.evidence && (
        <p className="mt-1.5 text-xs text-muted-foreground">{finding.evidence}</p>
      )}
      {/*the rule is published so the verdict can be argued with by somebody who knows this
         deployment better than the panel does*/}
      <p className="mt-1.5 text-xs text-muted-foreground">
        {SEVERITY_LABEL[finding.severity]} — {finding.rule}
      </p>
      {finding.apply && (
        <Button size="sm" variant="outline" className="mt-2 mr-2 h-7" onClick={onApply}>
          {applyTitle(finding)}
        </Button>
      )}
      {finding.href && (
        <Link href={finding.href} className="mt-1.5 inline-flex items-center text-sm text-primary hover:underline">
          Go and fix it
          <ArrowRight className="ml-1 h-3 w-3" aria-hidden="true" />
        </Link>
      )}
    </div>
  );
}
