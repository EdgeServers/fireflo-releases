"use client";
import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { AlertTriangle, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { PageHeader } from "@/components/ui/page-header";
import { Segmented } from "@/components/ui/segmented";
import { Select } from "@/components/ui/select";
import { ErrorCard, ErrorNote } from "./FormNotices";
import { GatewayIgnores } from "./GatewayIgnores";
import { useFilters } from "./useFilters";
import { useHealth } from "./useHealth";
import { useRouting } from "./useRouting";
import { useRuntimeMetrics } from "./useRuntimeMetrics";
import { useWorkers } from "./useWorkers";
import type { Filter } from "@/lib/filter-types";
import type { RouteGroup } from "@/lib/group-types";
import { readsRoutingFromDatabase } from "@/lib/health-types";
import {
  DEFAULT_TABLE_NAME,
  routeTableWarnings,
  validateRouteTable,
  type RouteRule,
  type RouteTable,
  type RouteTableInput,
  type TargetFunction,
} from "@/lib/routing-types";
import type { RuntimeSnapshot } from "@/lib/runtime-metrics";
import type { Worker } from "@/lib/worker-types";
import { cn } from "@/lib/utils";

/**
 * Everything the Routing section reads, loaded once in its layout.
 *
 * <p>The left column lists the routing tables and the tools that used to be tabs; the right is the
 * open one. Living in the layout keeps the column mounted while an operator moves between tables,
 * and lets a table page, the tester and the overview share one copy of the tables, vendors, groups
 * and filters instead of each fetching its own.
 */
export interface RoutingData {
  tables: RouteTable[];
  loading: boolean;
  error: string;
  busy: string;
  load: () => Promise<void>;
  save: (input: RouteTableInput) => Promise<string | null>;
  remove: (name: string) => Promise<string | null>;
  /** Outbound vendors. */
  clients: Worker[];
  /** Listeners: where a receipt or an inbound message is handed back. */
  servers: Worker[];
  workers: Worker[];
  groups: RouteGroup[];
  filters: Filter[];
  metrics: RuntimeSnapshot | null;
  /** `undefined` while health is unread; `false` when the gateway routes from a file. */
  writable: boolean | undefined;
  /**
   * A rule to open in the editor when `table` is next shown, unsaved. How "Start rule" on the
   * overview lands on the `default` table with its draft already in the editor.
   */
  pending: { table: string; rule: RouteRule } | null;
  startRule: (table: string, rule: RouteRule) => void;
  takePending: (table: string) => RouteRule | null;
}

const Ctx = createContext<RoutingData | null>(null);

export function useRoutingData(): RoutingData {
  const value = useContext(Ctx);
  if (!value) {
    throw new Error("useRoutingData is used outside the Routing layout.");
  }
  return value;
}

/** Where each part of the section lives. Tables sit under `tables/` so no table name can shadow a tool. */
export function tableHref(name: string): string {
  return `/cp/routing/tables/${encodeURIComponent(name)}`;
}

const TOOLS = [
  { href: "/cp/routing", label: "Start here" },
  { href: "/cp/routing/groups", label: "Vendor groups" },
  { href: "/cp/routing/test", label: "Test and check" },
] as const;

export function RoutingShell({ children }: { children: ReactNode }) {
  const routing = useRouting();
  const { snapshot: metrics } = useRuntimeMetrics();
  const { workers: clients } = useWorkers("smppclient");
  const { workers: servers } = useWorkers("smppserver");
  const { filters } = useFilters();
  const { health } = useHealth();
  const [groups, setGroups] = useState<RouteGroup[]>([]);
  const [pending, setPending] = useState<RoutingData["pending"]>(null);
  const [creating, setCreating] = useState(false);
  const router = useRouter();

  //the group list is small and only names targets here; GroupsClient keeps its own for editing
  useEffect(() => {
    let live = true;
    fetch("/api/control/groups", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((body) => {
        if (live && body?.data?.groups) setGroups(body.data.groups as RouteGroup[]);
      })
      .catch(() => {});
    return () => {
      live = false;
    };
  }, []);

  const startRule = useCallback((table: string, rule: RouteRule) => {
    setPending({ table, rule });
    router.push(tableHref(table));
  }, [router]);

  const takePending = useCallback((table: string) => {
    if (pending?.table !== table) return null;
    setPending(null);
    return pending.rule;
  }, [pending]);

  const data: RoutingData = {
    tables: routing.tables,
    loading: routing.loading,
    error: routing.error,
    busy: routing.busy,
    load: routing.load,
    save: routing.save,
    remove: routing.remove,
    clients,
    servers,
    workers: [...clients, ...servers],
    groups,
    filters,
    metrics,
    writable: readsRoutingFromDatabase(health),
    pending,
    startRule,
    takePending,
  };

  return (
    <Ctx.Provider value={data}>
      <PageHeader
        title="Routing"
        description="Which vendor each message goes to. Rules are tried top to bottom, and the first match wins."
        actions={
          <Button className="gap-2 lg:hidden" onClick={() => setCreating(true)}>
            <Plus className="h-4 w-4" aria-hidden="true" /> New table
          </Button>
        }
      />
      <ErrorCard error={routing.error} />
      <GatewayIgnores domain="routing" />
      <div className="flex flex-wrap items-start gap-6">
        <RoutingNav data={data} onNew={() => setCreating(true)} />
        <div className="flex min-w-0 flex-[999_1_560px] flex-col gap-5">{children}</div>
      </div>
      {creating && (
        <NewTableDialog
          tables={routing.tables}
          onClose={() => setCreating(false)}
          onCreate={async (input) => {
            const failure = await routing.save(input);
            if (!failure) {
              setCreating(false);
              router.push(tableHref(input.name));
            }
            return failure;
          }}
        />
      )}
    </Ctx.Provider>
  );
}

function RoutingNav({ data, onNew }: { data: RoutingData; onNew: () => void }) {
  const pathname = usePathname();
  const router = useRouter();
  const tableNames = data.tables.map((t) => t.name);
  const groupNames = data.groups.map((g) => g.name);
  const activeTable = pathname.startsWith("/cp/routing/tables/")
    ? decodeURIComponent(pathname.slice("/cp/routing/tables/".length))
    : null;
  const activeTool = activeTable === null ? pathname : null;
  //the entry point first, then the rest as the database orders them
  const ordered = [
    ...data.tables.filter((t) => t.name === DEFAULT_TABLE_NAME),
    ...data.tables.filter((t) => t.name !== DEFAULT_TABLE_NAME),
  ];

  return (
    <>
      {/* a select on a phone, where a column of links would push the table below the fold */}
      <label className="flex w-full flex-col gap-1 text-xs text-muted-foreground lg:hidden">
        Show
        <Select
          aria-label="Routing table or tool"
          value={activeTable !== null ? tableHref(activeTable) : pathname}
          onChange={(e) => router.push(e.target.value)}
        >
          <optgroup label="Routing tables">
            {ordered.map((t) => (
              <option key={t.name} value={tableHref(t.name)}>
                {t.name} · {t.rules.length} {t.rules.length === 1 ? "rule" : "rules"}
                {t.name === DEFAULT_TABLE_NAME ? " · entry point" : ""}
                {t.targetFunction === "LCR" ? " · cheapest" : ""}
              </option>
            ))}
          </optgroup>
          <optgroup label="Tools">
            {TOOLS.map((t) => <option key={t.href} value={t.href}>{t.label}</option>)}
          </optgroup>
        </Select>
      </label>

      <nav aria-label="Routing" className="hidden flex-[0_0_240px] flex-col gap-1 text-sm lg:sticky lg:top-4 lg:flex">
        <div className="px-3 pb-1 text-2xs font-bold uppercase tracking-wider text-muted-foreground">
          Routing tables
        </div>
        {data.loading && <p className="px-3 text-muted-foreground">Loading…</p>}
        {ordered.map((t) => {
          const active = activeTable === t.name;
          const warn = routeTableWarnings(t, tableNames, data.workers, data.groups).length > 0;
          return (
            <Link
              key={t.name}
              href={tableHref(t.name)}
              aria-current={active ? "page" : undefined}
              className={cn(
                "flex items-center gap-2 rounded-lg px-3 py-2",
                active ? "border border-border bg-card font-semibold shadow-sm" : "text-muted-foreground hover:bg-muted hover:text-foreground",
                !t.enabled && "opacity-60"
              )}
            >
              <span className="min-w-0 truncate font-mono text-xs text-foreground">{t.name}</span>
              {t.name === DEFAULT_TABLE_NAME && (
                <span className="shrink-0 rounded-full bg-primary-soft px-2 py-px text-2xs font-medium text-primary">Entry</span>
              )}
              {t.targetFunction === "LCR" && (
                <span className="shrink-0 rounded-full border border-border px-2 py-px text-2xs font-medium text-muted-foreground">LCR</span>
              )}
              {!t.enabled && (
                <span className="shrink-0 rounded-full bg-muted px-2 py-px text-2xs font-medium text-muted-foreground">Off</span>
              )}
              <span className="ml-auto flex shrink-0 items-center gap-1 pl-1 tabular-nums text-muted-foreground">
                {warn && <AlertTriangle className="h-3.5 w-3.5 text-warning" aria-label="Has warnings" />}
                {t.rules.length}
              </span>
            </Link>
          );
        })}
        {!data.loading && !data.tables.length && <p className="px-3 text-muted-foreground">No routing tables yet.</p>}
        <button type="button" onClick={onNew}
          className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-left font-semibold text-primary hover:bg-muted">
          <Plus className="h-3.5 w-3.5" aria-hidden="true" /> New table
        </button>

        <div className="px-3 pb-1 pt-4 text-2xs font-bold uppercase tracking-wider text-muted-foreground">
          Tools
        </div>
        {TOOLS.map((tool) => {
          const active = activeTool === tool.href;
          return (
            <Link
              key={tool.href}
              href={tool.href}
              aria-current={active ? "page" : undefined}
              className={cn(
                "flex items-center rounded-lg px-3 py-2",
                active ? "border border-border bg-card font-semibold text-foreground shadow-sm" : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              {tool.label}
              {tool.href === "/cp/routing/groups" && groupNames.length > 0 && (
                <span className="ml-auto tabular-nums text-muted-foreground">{groupNames.length}</span>
              )}
            </Link>
          );
        })}
      </nav>
    </>
  );
}

const FUNCTION_OPTIONS = [
  { value: "NORMAL" as const, label: "In order", title: "The first matching rule wins." },
  { value: "LCR" as const, label: "Cheapest vendor", title: "Every matching vendor competes, and the cheapest rate wins." },
];

/** A new table: a name, how it chooses, what it is for. It starts empty and opens for rules. */
function NewTableDialog({
  tables,
  onClose,
  onCreate,
}: {
  tables: RouteTable[];
  onClose: () => void;
  onCreate: (input: RouteTableInput) => Promise<string | null>;
}) {
  const [name, setName] = useState("");
  const [targetFunction, setTargetFunction] = useState<TargetFunction>("NORMAL");
  const [label, setLabel] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const taken = tables.some((t) => t.name === name.trim());

  async function submit() {
    const input: RouteTableInput = { name, targetFunction, label, enabled: true, rules: [] };
    const invalid = validateRouteTable(input) ?? (taken ? `A table named ${name.trim()} already exists.` : null);
    if (invalid) {
      setError(invalid);
      return;
    }
    setSaving(true);
    setError("");
    const failure = await onCreate(input);
    setSaving(false);
    if (failure) setError(failure);
  }

  return (
    <Dialog open onClose={onClose} title="New routing table">
      <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); void submit(); }}>
        <Field label="Name" htmlFor="nt-name" hint="Rules send into it by this name. Matched exactly, and fixed once created.">
          <Input id="nt-name" className="font-mono" value={name} placeholder="india_routes" autoFocus
            onChange={(e) => setName(e.target.value)} aria-invalid={taken || undefined} />
        </Field>
        <div className="space-y-1.5">
          <div id="nt-fn" className="text-sm font-medium">How it chooses</div>
          <Segmented<TargetFunction> label="How it chooses" value={targetFunction} onChange={setTargetFunction} options={FUNCTION_OPTIONS} fill />
          <p className="text-xs text-muted-foreground">
            {targetFunction === "NORMAL"
              ? "Rules are tried top to bottom and the first match wins."
              : "Every matching vendor is a candidate and the cheapest rate wins. Order does not matter."}
          </p>
        </div>
        <Field label="Description" htmlFor="nt-label" hint="Optional. What this table is for.">
          <Input id="nt-label" value={label} onChange={(e) => setLabel(e.target.value)} />
        </Field>
        <ErrorNote error={error} />
        <div className="flex flex-wrap justify-end gap-2 border-t border-border pt-4">
          <Button type="button" variant="ghost" className="mr-auto" onClick={onClose}>Cancel</Button>
          <Button type="submit" disabled={saving || !name.trim() || taken}>{saving ? "Creating…" : "Create table"}</Button>
        </div>
      </form>
    </Dialog>
  );
}
