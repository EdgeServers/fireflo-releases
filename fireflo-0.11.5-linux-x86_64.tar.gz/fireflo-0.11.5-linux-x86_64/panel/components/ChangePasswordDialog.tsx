"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ErrorNote } from "@/components/FormNotices";
import { PasswordFields } from "@/components/PasswordFields";

/**
 * The signed-in operator changes their own password.
 *
 * <p>The current one is asked for first, so a cookie left in somebody else's browser is not enough
 * to take the account over -- see `/api/control/me/password`.
 */
export function ChangePasswordDialog({
  email,
  open,
  onClose,
}: {
  email: string;
  open: boolean;
  onClose: () => void;
}) {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [ready, setReady] = useState(false);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      const res = await fetch("/api/control/me/password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ current, next }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      setDone(true);
      setCurrent("");
      setNext("");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onClose={onClose} title="Change your password" description={email}>
      {done ? (
        <div className="space-y-4">
          <p className="text-base">Changed. Use the new password next time you sign in.</p>
          <Button onClick={onClose}>Close</Button>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="current-password">Current password</Label>
            <Input
              id="current-password"
              name="current-password"
              type="password"
              value={current}
              autoFocus
              autoComplete="current-password"
              onChange={(e) => setCurrent(e.target.value)}
            />
          </div>
          <PasswordFields
            value={next}
            email={email}
            onChange={(pw, ok) => {
              setNext(pw);
              setReady(ok);
            }}
          />
          {error && <ErrorNote error={error} />}
          <div className="flex gap-2">
            <Button type="submit" disabled={!ready || !current || saving}>
              {saving ? "Saving…" : "Change password"}
            </Button>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </form>
      )}
    </Dialog>
  );
}
