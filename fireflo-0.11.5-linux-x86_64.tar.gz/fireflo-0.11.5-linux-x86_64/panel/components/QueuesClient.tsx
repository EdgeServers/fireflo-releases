"use client";
import { useCallback, useEffect, useState } from "react";
import { Layers, Loader2, RefreshCw, Search, Server, TriangleAlert } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { count } from "@/lib/format";
import {
  diagnose,
  kindHint,
  kindLabel,
  type QueueDump,
  type QueueEntry,
  type QueueSnapshot,
} from "@/lib/queues-types";
import { formatClockTime } from "@/lib/datetime";

/** How often the page re-reads, when it is left to run. */
const REFRESH_MS = 5_000;

/**
 * What is waiting inside the gateway, queue by queue.
 *
 * <p>Live health already reports the depth of each queue. Depth alone is where a diagnosis stops:
 * four thousand messages waiting on a vendor reads the same whether it is one customer's misfired
 * batch or every account on the box, and whether they are first attempts or fifth. This page answers
 * both.
 *
 * <p>The broker queue leads, because it is the one an operator cannot see any other way. Everything
 * else in the gateway is in this process and reported directly; RabbitMQ holds REST submissions
 * outside it, and a backlog there shows up on Live health as a *flat* router queue — the consumer
 * has stopped pulling — which reads like calm rather than like a queue nobody is draining.
 */
export function QueuesClient() {
  const [dump, setDump] = useState<QueueDump | null>(null);
  const [limit, setLimit] = useState(20);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [live, setLive] = useState(true);
  //filtering happens here rather than at the gateway. The dump is already bounded by the limit, and
  //re-fetching per keystroke would walk every live queue again to answer a question about text
  //already in hand
  const [search, setSearch] = useState("");
  const [retriesOnly, setRetriesOnly] = useState(false);
  const [only, setOnly] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const res = await fetch(`/api/control/queues?limit=${limit}`, { cache: "no-store" });
      const body = await res.json();
      if (!res.ok) {
        setError(body?.error ?? "Could not load the queues.");
        setDump(null);
      } else {
        setError(null);
        setDump(body.data as QueueDump);
      }
    } catch {
      setError("Could not reach the panel's API.");
    } finally {
      setLoading(false);
    }
  }, [limit]);

  useEffect(() => {
    load();
    if (!live) {
      return;
    }
    const timer = setInterval(load, REFRESH_MS);
    return () => clearInterval(timer);
  }, [load, live]);

  const broker = dump?.queues.find((q) => q.kind === "broker") ?? null;
  const allInProcess = dump?.queues.filter((q) => q.kind !== "broker") ?? [];
  const total = allInProcess.reduce((sum, q) => sum + Math.max(0, q.depth), 0);

  const named = only ? allInProcess.filter((q) => q.name === only) : allInProcess;
  //filtered queues keep their real depth and get a filtered entry list. Rewriting depth to the
  //number of matches would answer a different question -- "how many of these are Acme's" is not
  //"how deep is this queue", and conflating them is how a filtered view gets mistaken for calm
  const inProcess = named.map((q) => ({ ...q, entries: q.entries.filter(matches) }));
  const filtering = search.trim().length > 0 || retriesOnly;
  const shown = inProcess.reduce((sum, q) => sum + q.entries.length, 0);

  function matches(entry: QueueEntry): boolean {
    if (retriesOnly && entry.retries === 0) {
      return false;
    }
    const term = search.trim().toLowerCase();
    if (!term) {
      return true;
    }
    return [entry.account, entry.product, entry.from, entry.to, entry.serial, entry.target, entry.ingress]
      .some((field) => field?.toLowerCase().includes(term));
  }

  return (
    <>
      <PageHeader
        title="Queues"
        description="Messages the gateway has accepted and not yet sent. Nothing here is charged twice or lost — but a queue that only grows is a customer waiting."
      />
      <Card>
        <CardContent className="space-y-3 py-4">
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative w-full sm:w-72">
              <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Account, sender, number, product, vendor…"
                aria-label="Search queued messages"
                className="w-full rounded-md border border-border bg-background h-11 pl-8 md:h-9 pr-3 text-sm focus:border-primary focus:outline-none"
              />
            </div>
            <button
              onClick={() => setRetriesOnly((v) => !v)}
              className={`rounded-md border px-3 py-1.5 text-sm transition-colors ${
                retriesOnly
                  ? "border-destructive bg-destructive/10 font-semibold text-destructive"
                  : "border-border text-muted-foreground hover:bg-accent"
              }`}
            >
              Retries only
            </button>
            {allInProcess.length > 1 && (
              <select
                value={only ?? ""}
                onChange={(e) => setOnly(e.target.value || null)}
                aria-label="Limit to one queue"
                className="h-11 w-full rounded-md border border-border bg-background px-3 text-sm focus:border-primary focus:outline-none sm:w-auto md:h-9"
              >
                <option value="">Every queue</option>
                {allInProcess.map((q) => (
                  <option key={`${q.kind}:${q.name}`} value={q.name}>
                    {q.name} · {kindLabel(q.kind)}
                  </option>
                ))}
              </select>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {[20, 50, 100, 500].map((n) => (
              <button
                key={n}
                onClick={() => setLimit(n)}
                className={`rounded-md border px-3 py-1.5 text-sm transition-colors ${
                  limit === n
                    ? "border-primary bg-primary/10 font-semibold text-primary"
                    : "border-border text-muted-foreground hover:bg-accent"
                }`}
              >
                Show {n}
              </button>
            ))}
            <button
              onClick={() => setLive((v) => !v)}
              className={`ml-auto rounded-md border px-3 py-1.5 text-sm transition-colors ${
                live
                  ? "border-primary bg-primary/10 font-semibold text-primary"
                  : "border-border text-muted-foreground hover:bg-accent"
              }`}
            >
              {live ? "Live" : "Paused"}
            </button>
            <button
              onClick={load}
              className="rounded-md border border-border px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-accent"
            >
              <RefreshCw className="mr-1 inline h-3.5 w-3.5" />
              Refresh
            </button>
          </div>

          {loading && !dump && (
            <p className="text-sm text-muted-foreground">
              <Loader2 className="mr-2 inline h-4 w-4 animate-spin" />
              Reading the gateway&apos;s queues…
            </p>
          )}

          {error && (
            <p className="flex items-start gap-2 text-sm text-destructive">
              <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" />
              {error}
            </p>
          )}

          {dump && (
            <p className="text-sm text-muted-foreground">
              {count(total)} waiting in {allInProcess.length} in-process queue
              {allInProcess.length === 1 ? "" : "s"} · read at{" "}
              {formatClockTime(dump.observed_at)}
              {/* the filter runs over what was dumped, not over the whole queue. Saying so stops
                  "3 matches" being read as "only 3 of this customer's messages are waiting" */}
              {filtering &&
                ` · ${count(shown)} match${shown === 1 ? "" : "es"} among the ${count(
                  dump.limit_per_queue
                )} listed per queue`}
            </p>
          )}
        </CardContent>
      </Card>

      <BrokerCard broker={broker} loaded={dump !== null} />

      {inProcess.map((queue) => (
        <QueueCard
          key={`${queue.kind}:${queue.name}`}
          queue={queue}
          filtering={filtering}
        />
      ))}

      {dump && inProcess.length === 0 && !error && (
        <Card>
          <CardContent className="py-4 text-sm text-muted-foreground">
            No in-process queues. Every message that arrived has already been handed to a vendor —
            which is what a healthy gateway looks like at rest.
          </CardContent>
        </Card>
      )}
    </>
  );
}

/**
 * The RabbitMQ queue REST submissions pass through.
 *
 * <p>Rendered even when there is no broker, and that is the point. "Not configured" and "configured
 * and not answering" are different facts with different responses, and both of them look like an
 * absent card if absence is used to mean either.
 */
function BrokerCard({ broker, loaded }: { broker: QueueSnapshot | null; loaded: boolean }) {
  if (!loaded) {
    return null;
  }

  if (!broker) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Server className="h-4 w-4 text-muted-foreground" />
            Message broker
          </CardTitle>
          <CardDescription>
            No broker configured. REST submissions go straight into the router queue below, which is
            the default and needs no external service. A broker buys durability for scheduled work
            and back pressure against very large batches.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  //depth is -1 when the sampler could not reach the broker. Never render that as a number: a
  //stranded queue displayed as "0 waiting" turns an incident into a clean dashboard
  const unreachable = broker.depth < 0;
  const consumers = broker.consumers ?? 0;
  const unattended = !unreachable && broker.depth > 0 && consumers === 0;

  return (
    <Card className={unreachable || unattended ? "border-destructive/50" : undefined}>
      <CardHeader>
        <CardTitle className="flex flex-wrap items-center gap-2">
          <Server className="h-4 w-4 text-muted-foreground" />
          Message broker
          <Badge variant="outline" className="font-mono text-sm">
            {broker.name}
          </Badge>
          {unreachable && <Badge variant="destructive">Not answering</Badge>}
          {unattended && <Badge variant="destructive">Nothing draining it</Badge>}
        </CardTitle>
        <CardDescription>
          Where REST submissions wait before they reach the router. A backlog here shows on Live
          health as a <em>flat</em> router queue, because the consumer stops pulling once the
          in-process queue passes its highwater mark.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap gap-6">
          <div>
            <div className="font-mono text-2xl font-semibold tabular-nums">
              {unreachable ? "unknown" : count(broker.depth)}
            </div>
            <div className="text-sm text-muted-foreground">Waiting on the broker</div>
          </div>
          <div>
            <div className="font-mono text-2xl font-semibold tabular-nums">
              {unreachable ? "—" : count(consumers)}
            </div>
            <div className="text-sm text-muted-foreground">
              Consumer{consumers === 1 ? "" : "s"} attached
            </div>
          </div>
        </div>

        {unreachable && (
          <p className="text-sm text-destructive">
            The gateway is configured to use this broker and cannot reach it. Publishes are falling
            back to the in-process queue, and whatever is already on the broker is stranded until it
            answers. The depth is unknown, not zero.
          </p>
        )}
        {unattended && (
          <p className="text-sm text-destructive">
            Messages are queued and no consumer is attached. This is not slowness — nothing is
            reading them. Check that the gateway started its consumer, and that this is the queue
            name it is consuming.
          </p>
        )}
        {broker.note && !unreachable && !unattended && (
          <p className="text-sm text-muted-foreground">{broker.note}</p>
        )}
      </CardContent>
    </Card>
  );
}

/**
 * One in-process queue: the header carries the reading, the table carries the evidence.
 */
function QueueCard({ queue, filtering }: { queue: QueueSnapshot; filtering?: boolean }) {
  //the reading describes the queue, so it is computed before any filter narrows it. A verdict of
  //"mostly retries" drawn from a retries-only view would be circular
  const verdict = filtering ? null : diagnose(queue);
  const truncated = queue.depth > queue.returned;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex flex-wrap items-center gap-2">
          <Layers className="h-4 w-4 text-muted-foreground" />
          <span className="font-mono">{queue.name}</span>
          <Badge variant="outline">{kindLabel(queue.kind)}</Badge>
          <span className="ml-auto font-mono text-xl font-semibold">{count(queue.depth)}</span>
        </CardTitle>
        <CardDescription>
          {kindHint(queue.kind)}
          {/* the two numbers answer different questions, so never collapse them into one */}
          {truncated && ` Showing the first ${count(queue.returned)} of ${count(queue.depth)}.`}
          {!queue.ordered && queue.entries.length > 0 && " Not listed in send order."}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {verdict && <p className="text-sm">{verdict}</p>}
        {queue.note && <p className="text-sm text-muted-foreground">{queue.note}</p>}

        {queue.entries.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            {filtering
              ? `Nothing here matches. ${queue.depth > 0 ? `${count(queue.depth)} waiting in total.` : "This queue is empty."}`
              : "Empty."}
          </p>
        ) : (
          <TableInCard>
            <THead>
              <TR>
                <TH>Queued</TH>
                <TH>Account</TH>
                <TH>Product</TH>
                <TH>From</TH>
                <TH>To</TH>
                <TH>Size</TH>
                <TH>Tries</TH>
                <TH>Via</TH>
                <TH>Next</TH>
              </TR>
            </THead>
            <TBody>
              {queue.entries.map((e, i) => (
                <TR key={`${e.serial ?? e.msg_id}-${i}`}>
                  <TD muted className="whitespace-nowrap font-mono">
                    {formatClockTime(e.queued_at) || "—"}
                  </TD>
                  <TD className="font-mono">{e.account || "—"}</TD>
                  <TD className="font-mono">{e.product || "—"}</TD>
                  <TD className="font-mono">{e.from || "—"}</TD>
                  <TD className="font-mono">{e.to || "—"}</TD>
                  {/* characters and encoding, never the text. The gateway does not return it */}
                  <TD muted className="whitespace-nowrap">
                    {e.body_chars} char{e.body_chars === 1 ? "" : "s"} · {e.encoding}
                    {e.parts > 1 ? ` · ${e.parts} parts` : ""}
                  </TD>
                  <TD>
                    {e.retries > 0 ? (
                      <Badge variant="destructive">{e.retries}</Badge>
                    ) : (
                      <span className="text-muted-foreground">first</span>
                    )}
                  </TD>
                  <TD muted>{e.ingress || "—"}</TD>
                  <TD muted>
                    {queue.kind === "delayed" && e.ready_in_ms != null
                      ? e.ready_in_ms <= 0
                        ? "due now"
                        : `in ${Math.round(e.ready_in_ms / 1000)}s`
                      : e.target || "—"}
                  </TD>
                </TR>
              ))}
            </TBody>
          </TableInCard>
        )}

        <p className="text-sm text-muted-foreground">
          Message text is deliberately not shown. It is not kept in call records either — operating
          the gateway never needs it, so the size and encoding stand in for it.
        </p>
      </CardContent>
    </Card>
  );
}
