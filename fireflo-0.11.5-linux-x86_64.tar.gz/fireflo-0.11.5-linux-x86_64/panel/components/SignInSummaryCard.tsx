"use client";
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import type { SignInSummary } from "@/lib/audit-log";

/**
 * Sign-ins and refusals per day from the two database logs, for the Security page.
 *
 * <p>Sits beside the cards built from the refusal files and fail2ban. Those are what gets an
 * address banned; this is what people read. Both are shown so the moments they disagree -- a file
 * that stopped being written, a database the panel could not reach -- are visible rather than
 * silent.
 */
export function SignInSummaryCard({ days = 7 }: { days?: number }) {
  const [rows, setRows] = useState<SignInSummary[] | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`/api/control/audit/signins?days=${days}`, { cache: "no-store" });
        const json = await res.json().catch(() => null);
        if (cancelled) return;
        if (!res.ok) {
          setError(json?.error ?? `Request failed (${res.status})`);
          return;
        }
        setRows(json.data.rows as SignInSummary[]);
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : "Request failed");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [days]);

  const totals = (rows ?? []).reduce(
    (acc, r) => {
      acc[r.surface].succeeded += r.succeeded;
      acc[r.surface].failed += r.failed;
      return acc;
    },
    { panel: { succeeded: 0, failed: 0 }, portal: { succeeded: 0, failed: 0 } }
  );

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium">Sign-ins, last {days} days</CardTitle>
        <p className="text-sm text-muted-foreground">
          From the database logs, both doors. Each refusal here is also in the file fail2ban watches.
        </p>
      </CardHeader>
      <CardContent className="space-y-3">
        {error && <p className="text-base text-destructive">{error}</p>}
        {!error && (
          <div className="grid gap-3 sm:grid-cols-2">
            <Totals title="Operator panel" {...totals.panel} />
            <Totals title="Customer portal" {...totals.portal} />
          </div>
        )}
        {!!rows?.length && (
          <TableInCard>
            <THead>
              <tr>
                <TH className="pl-0">Day</TH>
                <TH>Door</TH>
                <TH align="right">Signed in</TH>
                <TH align="right" className="pr-0">Refused</TH>
              </tr>
            </THead>
            <TBody>
              {rows.map((r) => (
                <TR key={`${r.day}-${r.surface}`}>
                  <TD className="pl-0 tabular-nums">{r.day}</TD>
                  <TD muted>{r.surface === "panel" ? "Operator panel" : "Customer portal"}</TD>
                  <TD num>{r.succeeded}</TD>
                  <TD num className={`pr-0 ${r.failed ? "font-semibold text-destructive" : ""}`}>{r.failed}</TD>
                </TR>
              ))}
            </TBody>
          </TableInCard>
        )}
        {rows && !rows.length && <p className="text-base text-muted-foreground">No sign-ins recorded in this window.</p>}
      </CardContent>
    </Card>
  );
}

function Totals({ title, succeeded, failed }: { title: string; succeeded: number; failed: number }) {
  return (
    <div className="rounded-lg border border-border p-3">
      <p className="text-sm text-muted-foreground">{title}</p>
      <p className="text-base">
        <span className="font-medium tabular-nums">{succeeded}</span> signed in ·{" "}
        <span className={`font-medium tabular-nums ${failed ? "text-destructive" : ""}`}>{failed}</span> refused
      </p>
    </div>
  );
}
