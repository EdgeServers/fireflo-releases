"use client";
import { useEffect, useState } from "react";
import { signIn } from "next-auth/react";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { APP_VERSION, FireFloMark } from "@/components/FireFloMark";
import { signInErrorMessage } from "@/lib/sign-in-error";

/** Where the remembered username is kept. Not the password — see the note on `submit`. */
const REMEMBERED = "fireflo-control.remembered-operator";

export function LoginForm() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [visible, setVisible] = useState(false);
  const [remember, setRemember] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  //password, or a one-time link emailed to the address on the account. The link is also how a new
  //operator sets a first password and how a forgotten one is replaced, so it sits on this page
  const [mode, setMode] = useState<"password" | "link">("password");
  const [sent, setSent] = useState("");

  //read after hydration rather than in a lazy initialiser: localStorage does not exist during the
  //server render, and seeding state from it would make the first client render disagree with the
  //HTML that was sent
  useEffect(() => {
    const stored = window.localStorage.getItem(REMEMBERED);
    if (stored) {
      setUsername(stored);
      setRemember(true);
    }
  }, []);

  /**
   * Signs in, then leaves via a real navigation.
   *
   * <p>The navigation is the point, and it is why this is `window.location` rather than
   * `router.push`. Browsers only offer to save a password when they see a form submitted and the
   * page then go somewhere; a client-side route change looks like nothing happened, so Chrome and
   * Firefox stay silent and the credential is never saved. One full page load on sign-in is the
   * price of the browser's password manager working at all.
   *
   * <p>Which is also why nothing here writes the password anywhere itself. Keeping it in
   * `localStorage` would put a plaintext operator credential somewhere every script on the page can
   * read, surviving sign-out, for the sake of saving a paste. The password manager is the thing
   * built for this — it is encrypted at rest, it is scoped to the origin, and it is under the
   * operator's control rather than this form's.
   */
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await signIn("operator", { username, password, redirect: false });
      if (res?.error) {
        //a wrong username and a wrong password read the same; a cookie the browser dropped, or a
        //server fault, does not -- see lib/sign-in-error.ts
        setError(signInErrorMessage(res.error, window.location));
        return;
      }
      if (remember) {
        window.localStorage.setItem(REMEMBERED, username);
      } else {
        window.localStorage.removeItem(REMEMBERED);
      }
      window.location.assign("/cp");
    } finally {
      setLoading(false);
    }
  }

  /** Asks for a one-time link. The answer is the same whether or not the name is ours. */
  async function requestLink(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/login-link", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username }),
      });
      const json = (await res.json().catch(() => null)) as { message?: string; error?: string } | null;
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      setSent(json?.message ?? "If that is an operator's address, a sign-in link is on its way.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <div className="w-full max-w-[400px]">
        <Card className="shadow-sm">
          <CardContent className="space-y-6 p-8">
            {/* the brand row and the welcome, as the sample lays them out: a small mark and the
                name, then a 24px heading with one quiet sentence under it */}
            <div className="flex items-center gap-2 text-[15px] font-bold tracking-tight">
              <FireFloMark className="h-[22px] w-[22px]" />
              FireFlo
            </div>
            <div className="space-y-1">
              <h1 className="text-2xl font-bold tracking-tight">Welcome back</h1>
              <p className="text-sm text-muted-foreground">
                {mode === "password"
                  ? "Sign in to your control panel."
                  : "A one-time link goes to the email address on your operator account. It works once and expires after 15 minutes."}
              </p>
            </div>

            <form onSubmit={mode === "password" ? submit : requestLink} className="space-y-3.5">
              <div className="space-y-1.5">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  type="text"
                  //a bare name or a full address: the server gives a bare name @control.local, which is
                  //what the installer's --operator NAME becomes, so "operator" keeps working as typed
                  placeholder="operator or you@example.com"
                  //password managers key off `name` as much as `autoComplete`; without it the pair is
                  //saved as an anonymous credential that never autofills again
                  name="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  autoComplete="username"
                  autoFocus
                />
              </div>

              {mode === "password" && (
                <div className="space-y-1.5">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      name="password"
                      type={visible ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      autoComplete="current-password"
                      className="pr-9"
                    />
                    <button
                      type="button"
                      onClick={() => setVisible((v) => !v)}
                      //not in the tab order: tabbing from the password field should reach Sign in, and
                      //revealing a password is a deliberate act rather than something to land on
                      tabIndex={-1}
                      aria-label={visible ? "Hide password" : "Show password"}
                      aria-pressed={visible}
                      className="absolute inset-y-0 right-0 flex w-9 items-center justify-center rounded-r-md text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                    >
                      {visible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
              )}

              {mode === "password" && (
                <label className="flex items-start gap-2 text-xs text-muted-foreground">
                  <input
                    type="checkbox"
                    checked={remember}
                    onChange={(e) => setRemember(e.target.checked)}
                    className="mt-0.5 h-3.5 w-3.5 rounded border-input accent-primary"
                  />
                  <span>
                    Remember me on this device
                    {/* said out loud so nobody assumes the password is being kept here too */}
                    <span className="block text-2xs">
                      Keeps the username. Let your browser save the password.
                    </span>
                  </span>
                </label>
              )}

              {error && <p className="text-sm text-destructive">{error}</p>}
              {sent && mode === "link" ? (
                <p className="rounded-md border border-border bg-muted/50 p-3 text-sm">{sent}</p>
              ) : (
                <Button
                  type="submit"
                  className="w-full"
                  disabled={loading || (mode === "password" ? !password : !username.trim())}
                >
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {mode === "password" ? "Sign in" : "Email me a sign-in link"}
                </Button>
              )}
            </form>

            {/* the sample's "or" rule and a second, outlined way in beneath it. Ours is the one-time
                link, which is also how a first password gets set and a forgotten one replaced */}
            <div className="flex items-center gap-2.5 text-2xs text-muted-foreground">
              <span className="h-px flex-1 bg-border" />
              or
              <span className="h-px flex-1 bg-border" />
            </div>
            <Button
              type="button"
              variant="outline"
              className="w-full"
              onClick={() => {
                setMode(mode === "password" ? "link" : "password");
                setError("");
                setSent("");
              }}
            >
              {mode === "password" ? "Use a one-time link instead" : "Use a password instead"}
            </Button>
          </CardContent>
        </Card>
        <p className="mt-4 text-center text-2xs text-muted-foreground">
          Operator access. This is not a gateway messaging credential.
          {APP_VERSION && <span className="tabular-nums"> · v{APP_VERSION}</span>}
        </p>
      </div>
    </div>
  );
}
