"use client";
import { type ReactNode, useMemo, useState } from "react";
import { Plus, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CardSection } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { TableInCard, TBody, TD, TR } from "@/components/ui/table";
import { SettingControl } from "@/components/SettingControl";
import { denialMessage, judgeGatewayKey } from "@/lib/gateway-key-policy";
import { BUILTIN_REGISTRY, type ConfigKeyRegistry } from "@/lib/config-key-registry";
import { settingLabel } from "@/lib/labels";
import type { SettingWidget } from "@/lib/setting-fields";

/**
 * One catalogued key's widget, carried alongside a row so the table can render it in place of a
 * bare text box. Absent on an uncatalogued key — there is nothing to render but the string.
 */
export interface KeyField {
  label: string;
  hint?: string;
  widget: SettingWidget;
  codedDefault: string | null;
}

export interface KeyRow {
  key: string;
  value: string | null;
  enabled: boolean;
  /**
   * Whether the policy lets this key be written.
   *
   * <p>False for the broker and sink wiring, which is shown and locked. Those keys change where
   * messages and records go while traffic is running, and an operator needs to see them far more
   * often than they need to change them -- so they are here, greyed, rather than absent and
   * mysterious.
   */
  writable: boolean;
  field?: KeyField;
}

/**
 * A table of gateway configuration keys under one or more prefixes — some with a catalogue entry
 * and their own typed widget, some with none and a plain string.
 *
 * <p>Two instances render this today. **Worker defaults** owns the whole `outSms.default.*` prefix:
 * a curated key there (say, TLV stamp mode) renders with its real dropdown; an uncurated one renders
 * as a plain key/value row, in the same list, because both are equally something an operator set and
 * needs to see. **Any other key** owns everything else that reaches this page — `smsg.*` with no
 * catalogue entry — and never resolves a `field`, so every row there is plain text, as it always was.
 *
 * <p>Those two domains are kept disjoint by `ownCuratedPrefix`: a curated key typed into the free-form
 * Add box is normally refused ("already has a field on this page") because two editors for one value
 * is how they come to disagree. That refusal lifts only when the key both is curated *and* falls under
 * this instance's own prefix — a curated `outSms.default.*` key belongs here on the Worker defaults
 * instance, but a curated `smsg.*` key does not, and is still refused there exactly as it is on the
 * Any-other-key instance.
 */
export function GatewayKeyTable({
  title,
  description,
  emptyLabel,
  rows,
  drafts,
  busy,
  onDraft,
  onRemove,
  ownCuratedPrefix,
  resolveField,
  picker,
  registry = BUILTIN_REGISTRY,
}: {
  title: string;
  description: string;
  emptyLabel: string;
  /** Rows already in `app_config`, in whatever order the caller sorted them. */
  rows: readonly KeyRow[];
  /** Edits staged on the page but not yet written, by key. */
  drafts: Record<string, string>;
  busy: boolean;
  onDraft: (key: string, value: string, stored: string) => void;
  /**
   * The delete button on every row calls this rather than `onDraft(key, "", stored)` directly, because
   * a key that came from a picker rather than the free-form box may need more than a blanked draft to
   * actually disappear -- see `GatewaySettingsClient`'s `removeWorkerKey`, which also resets its own
   * pending-pick state before staging the clear.
   */
  onRemove: (key: string, stored: string) => void;
  /** When set, a curated key under this prefix is accepted here instead of refused. */
  ownCuratedPrefix?: string;
  /** Populate `field` for a freshly typed key, so it renders with its widget rather than plain text. */
  resolveField?: (key: string) => KeyField | undefined;
  /** The "Set another default" convenience — a fully-formed control, rendered as its own section. */
  picker?: ReactNode;
  /** app_config_key as the page loaded it; the built-in copy when absent. */
  registry?: ConfigKeyRegistry;
}) {
  const [newKey, setNewKey] = useState("");
  const [newValue, setNewValue] = useState("");
  const [refusal, setRefusal] = useState("");

  //judged as it is typed so the refusal appears before Add is pressed, and Add can say why it is
  //not going to work rather than only that it did not
  const verdict = useMemo(
    () => (newKey.trim() === "" ? null : judgeGatewayKey(newKey, registry)),
    [newKey, registry]
  );
  const blocked = verdict !== null && !verdict.allowed;

  //keys staged for creation: they have no stored row yet, so they would otherwise vanish between
  //pressing Add and pressing Save
  const known = new Set(rows.map((r) => r.key));
  const added: KeyRow[] = Object.keys(drafts)
    .filter((k) => !known.has(k))
    .sort()
    .map((k) => ({ key: k, value: null, enabled: true, writable: true, field: resolveField?.(k) }));

  function add() {
    const key = newKey.trim();
    if (!key) {
      return;
    }
    const judged = judgeGatewayKey(key, registry);
    if (!judged.allowed) {
      setRefusal(denialMessage(key, judged.reason));
      return;
    }
    //a curated key belongs to its own instance's prefix -- outSms.default.* here on Worker defaults,
    //everything else refused, exactly as Any-other-key refuses every curated key with no prefix of
    //its own
    const ownsIt = ownCuratedPrefix !== undefined && key.startsWith(ownCuratedPrefix);
    if (judged.curated && !ownsIt) {
      setRefusal(
        `${settingLabel(key).label} already has a field on this page. Set it there rather than here.`
      );
      return;
    }
    if (rows.some((r) => r.key === key)) {
      setRefusal(`${key} is already in the list below.`);
      return;
    }
    setRefusal("");
    //staged like every other edit on this tab, so Add does not quietly become the one control that
    //writes to the gateway on its own
    onDraft(key, newValue, "");
    setNewKey("");
    setNewValue("");
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm text-muted-foreground">{description}</p>

        {rows.length === 0 && added.length === 0 ? (
          <p className="text-sm text-muted-foreground">{emptyLabel}</p>
        ) : (
          <TableInCard>
            <TBody>
              {[...rows, ...added].map((row) => (
                <KeyTableRow
                  key={row.key}
                  row={row}
                  pending={drafts[row.key]}
                  busy={busy}
                  onDraft={onDraft}
                  onRemove={onRemove}
                />
              ))}
            </TBody>
          </TableInCard>
        )}

        <CardSection title="Add a key">
          <div className="flex flex-wrap items-start gap-2">
            {/* min-w-0 because a flex child defaults to min-width:auto and will not shrink below
                its content, which for a long key name pushes the row past the card */}
            <Input
              aria-label="Key"
              className="min-w-0 flex-1 font-mono"
              placeholder="smsg.whitelist.max.variable"
              value={newKey}
              onChange={(e) => {
                setNewKey(e.target.value);
                setRefusal("");
              }}
              //Enter would otherwise submit whatever form this card ends up inside
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  add();
                }
              }}
            />
            <Input
              aria-label="Value"
              className="min-w-0 flex-1 font-mono"
              placeholder="value"
              value={newValue}
              onChange={(e) => setNewValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  add();
                }
              }}
            />
            <Button type="button" variant="outline" className="gap-1.5" onClick={add}>
              <Plus className="h-4 w-4" aria-hidden="true" />
              Add
            </Button>
          </div>

          {/* the live verdict while typing, then the sharper message once Add is pressed. Amber
              rather than red: nothing has gone wrong, the panel is declining */}
          {(refusal || blocked) && (
            <p className="text-xs text-amber-600 dark:text-amber-400">
              {refusal || (verdict && !verdict.allowed
                ? denialMessage(newKey, verdict.reason)
                : "")}
            </p>
          )}
        </CardSection>

        {picker && <CardSection title="Set another default">{picker}</CardSection>}
      </CardContent>
    </Card>
  );
}

/**
 * One stored key, editable in place.
 *
 * <p>A curated row (`row.field` set) gets its humanised label, its typed widget and its hint — the
 * one place on this page a raw key is demoted to a subordinate, muted string beside the label that
 * actually explains it. An uncurated row has no English name to show instead, so the raw key stays
 * the label: `settingLabel` would humanise it into something that looks authoritative and is not.
 */
function KeyTableRow({
  row,
  pending,
  busy,
  onDraft,
  onRemove,
}: {
  row: KeyRow;
  pending: string | undefined;
  busy: boolean;
  onDraft: (key: string, value: string, stored: string) => void;
  onRemove: (key: string, stored: string) => void;
}) {
  const stored = row.value ?? "";
  const shown = pending ?? stored;
  const edited = pending !== undefined;

  if (row.field) {
    const { label, hint, widget, codedDefault } = row.field;
    return (
      <TR>
        <TD className="align-top">
          <label htmlFor={row.key} className="text-sm font-medium">
            {label}
          </label>
          <div className="mt-1 flex flex-wrap items-center gap-1">
            <code className="font-mono text-2xs text-muted-foreground">{row.key}</code>
            {edited && <Badge variant="outline">Unsaved</Badge>}
            {!row.enabled && <Badge variant="outline">Saved but switched off</Badge>}
          </div>
        </TD>
        <TD className="w-1/2 align-top">
          <SettingControl
            id={row.key}
            widget={widget}
            codedDefault={codedDefault}
            value={shown}
            disabled={busy}
            onChange={(v) => onDraft(row.key, v, stored)}
          />
          {hint && <p className="mt-1 text-sm text-muted-foreground">{hint}</p>}
        </TD>
        <TD className="w-9 align-top">
          {row.writable && (
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-9 w-9"
              disabled={busy}
              aria-label={`Clear ${row.key}`}
              onClick={() => onRemove(row.key, stored)}
            >
              <X className="h-4 w-4" aria-hidden="true" />
            </Button>
          )}
        </TD>
      </TR>
    );
  }

  return (
    <TR>
      <TD className="align-top">
        <code className="font-mono text-xs break-all">{row.key}</code>
        {(edited || !row.enabled) && (
          <div className="mt-1 flex flex-wrap gap-1">
            {edited && <Badge variant="outline">Unsaved</Badge>}
            {/* present in the table and doing nothing: DbConfigPoller selects WHERE enabled */}
            {!row.enabled && <Badge variant="outline">Saved but switched off</Badge>}
          </div>
        )}
      </TD>
      <TD className="w-1/2 align-top">
        <Input
          aria-label={`Value for ${row.key}`}
          className="font-mono"
          value={shown}
          disabled={busy || !row.writable}
          onChange={(e) => onDraft(row.key, e.target.value, stored)}
        />
        {!row.writable && (
          <p className="mt-1 text-xs text-muted-foreground">
            Shown, not editable — this one is changed on the host.
          </p>
        )}
      </TD>
      <TD className="w-9 align-top">
        {row.writable && (
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="h-9 w-9"
            disabled={busy}
            aria-label={`Clear ${row.key}`}
            //an empty value deletes the row rather than storing '', so the key steps out of the way
            //and whatever is below it in the chain answers again. Staged, so a mis-click is undone
            //by Discard rather than by remembering what was there
            onClick={() => onRemove(row.key, stored)}
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </Button>
        )}
      </TD>
    </TR>
  );
}
