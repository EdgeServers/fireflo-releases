"use client";
import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, Copy, Pencil, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";
import { SearchInput } from "./SearchInput";
import { DangerAction } from "./DangerAction";
import { ErrorCard } from "./FormNotices";
import { FilterWizard, type WizardMode } from "./FilterWizard";
import { GatewayIgnores } from "./GatewayIgnores";
import { useFilters } from "./useFilters";
import { describeConditions, duplicateMap, FILTER_TOPICS, filterTopics, type FilterTopic } from "@/lib/filter-guide";
import { type Filter, usedByTotal } from "@/lib/filter-types";
import { cn } from "@/lib/utils";

/**
 * Named condition sets, defined once and referenced by rules.
 *
 * <p>Two columns. The left groups filters by what they match -- destination, sender, product and
 * login, account, message content -- and by state: unused, off or empty, and duplicates. A filter
 * matching on two topics sits under both. The right lists the group as cards: the filter read as a
 * sentence, and badges for where it is used.
 *
 * <p><strong>Usage is the point of every card.</strong> Disabling a filter skips every rule using
 * it, and deleting one is refused while any rule does, so each card says how many routing and
 * pricing rules reference it, and the badge opens into which.
 *
 * <p>New, Edit and Copy all open the guided dialog, `FilterWizard`.
 */

type Group = "all" | FilterTopic | "unused" | "inert" | "duplicates";

const STATUS_GROUPS: { id: Group; label: string }[] = [
  { id: "unused", label: "Unused" },
  { id: "inert", label: "Off or empty" },
  { id: "duplicates", label: "Duplicates" },
];

/** Off, or with no conditions: the gateway skips every rule that uses it either way. */
const inert = (f: Filter) => !f.enabled || f.conditions.length === 0;

export function FiltersClient() {
  const { filters, error, loading, busy, save, remove } = useFilters();
  const [wizard, setWizard] = useState<WizardMode | null>(null);
  const [removeError, setRemoveError] = useState("");
  const [group, setGroup] = useState<Group>("all");
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState<string | null>(null);
  const [highlight, setHighlight] = useState<string | null>(null);

  const twins = useMemo(() => duplicateMap(filters), [filters]);
  const topics = useMemo(() => new Map(filters.map((f) => [f.name, filterTopics(f.conditions)])), [filters]);

  const inGroup = (f: Filter, g: Group) =>
    g === "all" ? true
      : g === "unused" ? usedByTotal(f) === 0
        : g === "inert" ? inert(f)
          : g === "duplicates" ? twins.has(f.name)
            : (topics.get(f.name) ?? []).includes(g);
  const count = (g: Group) => filters.filter((f) => inGroup(f, g)).length;

  const needle = query.trim().toLowerCase();
  const shown = filters.filter((f) => inGroup(f, group) && (
    !needle
    || f.name.toLowerCase().includes(needle)
    || (f.label ?? "").toLowerCase().includes(needle)
    || describeConditions(f.conditions).toLowerCase().includes(needle)
  ));

  //"Use <name> instead" from the dialog: show that filter, and make it easy to spot
  useEffect(() => {
    if (!highlight) return;
    document.getElementById(`filter-${highlight}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
    const t = setTimeout(() => setHighlight(null), 2500);
    return () => clearTimeout(t);
  }, [highlight]);

  const groupLabel = group === "all" ? "All filters"
    : FILTER_TOPICS.find((t) => t.id === group)?.label ?? STATUS_GROUPS.find((s) => s.id === group)?.label ?? "";

  const groups: { id: Group; label: string }[] = [{ id: "all", label: "All" }, ...FILTER_TOPICS.map((t) => ({ id: t.id as Group, label: t.label }))];

  return (
    <>
      <ErrorCard error={error || removeError} />
      {/* a filter on a rate rule is inert while the gateway prices from its file */}
      <GatewayIgnores domain="rates" />

      <div className="flex flex-wrap items-start gap-6">
        {/* a select on a phone, where a column of links would push the filters below the fold */}
        <label className="flex w-full flex-col gap-1 text-xs text-muted-foreground lg:hidden">
          Show
          <Select aria-label="Filter group" value={group} onChange={(e) => setGroup(e.target.value as Group)}>
            {[...groups, ...STATUS_GROUPS].map((g) => (
              <option key={g.id} value={g.id}>{g.label} ({count(g.id)})</option>
            ))}
          </Select>
        </label>

        <nav aria-label="Filter groups" className="hidden flex-[0_0_230px] flex-col gap-0.5 text-sm lg:sticky lg:top-4 lg:flex">
          {groups.map((g) => <GroupLink key={g.id} label={g.label} count={count(g.id)} active={group === g.id} onClick={() => setGroup(g.id)} />)}
          <div className="px-3 pb-1 pt-4 text-2xs font-bold uppercase tracking-wider text-muted-foreground">Status</div>
          {STATUS_GROUPS.map((g) => (
            <GroupLink key={g.id} label={g.label} count={count(g.id)} active={group === g.id} onClick={() => setGroup(g.id)}
              tone={g.id !== "unused" && count(g.id) > 0 ? "warning" : undefined} />
          ))}
          <p className="mt-3 px-3 text-xs text-muted-foreground">
            A filter matching on two things sits under both.
          </p>
        </nav>

        <div className="flex min-w-0 flex-[999_1_560px] flex-col gap-4">
          <div className="flex flex-wrap items-center gap-2.5">
            <h2 className="mr-auto text-base font-semibold">
              {groupLabel} <span className="font-normal text-muted-foreground">· {shown.length}</span>
            </h2>
            <div className="min-w-0 flex-[1_1_220px] sm:max-w-xs">
              <SearchInput value={query} onChange={setQuery} placeholder="Find a filter" ariaLabel="Find a filter" className="w-full" />
            </div>
            <Button size="sm" className="gap-2" onClick={() => setWizard({ kind: "new" })}>
              <Plus className="h-4 w-4" aria-hidden="true" /> New filter
            </Button>
          </div>

          {shown.length === 0 ? (
            <div className="rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted-foreground">
              {loading ? "Loading…"
                : filters.length === 0 ? "No filters yet. A filter names a clause once, so routing and pricing rules can reuse it instead of retyping it."
                  : needle ? "No filter in this group matches that."
                    : "No filter in this group."}
            </div>
          ) : (
            <ul className="overflow-hidden rounded-xl border border-border bg-card">
              {shown.map((f) => (
                <FilterCard
                  key={f.name}
                  filter={f}
                  twins={twins.get(f.name) ?? []}
                  open={open === f.name}
                  highlighted={highlight === f.name}
                  busy={busy === f.name}
                  onToggleUses={() => setOpen((o) => (o === f.name ? null : f.name))}
                  onEdit={() => setWizard({ kind: "edit", filter: f })}
                  onCopy={() => setWizard({ kind: "copy", filter: f })}
                  onDelete={async () => setRemoveError((await remove(f.name)) ?? "")}
                  onShowTwin={(name) => { setGroup("all"); setQuery(""); setHighlight(name); }}
                />
              ))}
            </ul>
          )}

          <p className="text-sm text-muted-foreground">
            A filter narrows the rule using it: every condition must hold on top of the rule&apos;s own.
            Switching a filter off does not loosen it. Every rule using it is <strong>skipped</strong>,
            and that traffic falls through to whatever prices or routes it next.
          </p>
        </div>
      </div>

      {wizard && (
        <FilterWizard
          mode={wizard}
          filters={filters}
          onClose={() => setWizard(null)}
          onShow={(name) => {
            setWizard(null);
            setGroup("all");
            setQuery("");
            setHighlight(name);
          }}
          onSave={async (input) => {
            const failure = await save(input);
            if (!failure) {
              setWizard(null);
              setHighlight(input.name.trim());
            }
            return failure;
          }}
        />
      )}
    </>
  );
}

function GroupLink({ label, count, active, onClick, tone }: {
  label: string; count: number; active: boolean; onClick: () => void; tone?: "warning";
}) {
  return (
    <button type="button" aria-current={active ? "true" : undefined} onClick={onClick}
      className={cn(
        "flex items-center rounded-lg px-3 py-2 text-left",
        active ? "border border-border bg-card font-semibold text-foreground shadow-sm" : "text-muted-foreground hover:bg-muted hover:text-foreground"
      )}>
      {label}
      <span className={cn("ml-auto pl-2 tabular-nums", tone === "warning" ? "font-medium text-amber-600 dark:text-amber-400" : "text-muted-foreground")}>
        {count}
      </span>
    </button>
  );
}

const chip = "inline-flex items-center gap-1 rounded-full px-2 py-px text-2xs font-medium";

function FilterCard({
  filter: f, twins, open, highlighted, busy, onToggleUses, onEdit, onCopy, onDelete, onShowTwin,
}: {
  filter: Filter;
  twins: string[];
  open: boolean;
  highlighted: boolean;
  busy: boolean;
  onToggleUses: () => void;
  onEdit: () => void;
  onCopy: () => void;
  onDelete: () => Promise<void>;
  onShowTwin: (name: string) => void;
}) {
  const uses = usedByTotal(f);
  const sentence = describeConditions(f.conditions);
  const usesId = `filter-${f.name}-uses`;

  return (
    <li id={`filter-${f.name}`}
      className={cn("border-b border-border/60 px-5 py-4 last:border-b-0 transition-colors", highlighted && "bg-primary-soft/60")}>
      <div className="flex flex-wrap items-start gap-x-4 gap-y-2">
        <div className="min-w-0 flex-[1_1_320px] space-y-1">
          <div className="flex flex-wrap items-center gap-1.5">
            <button type="button" onClick={onEdit} className="mr-1 font-mono text-sm font-semibold text-foreground hover:underline">
              {f.name}
            </button>
            {/* where it is used: the number every change to a filter is proportional to */}
            {f.usedBy.routes > 0 && (
              <button type="button" aria-expanded={open} aria-controls={usesId} onClick={onToggleUses}
                className={cn(chip, "bg-sky-100 text-sky-900 hover:bg-sky-200 dark:bg-sky-950 dark:text-sky-200")}>
                Routing · {f.usedBy.routes}
              </button>
            )}
            {f.usedBy.rates > 0 && (
              <button type="button" aria-expanded={open} aria-controls={usesId} onClick={onToggleUses}
                className={cn(chip, "bg-primary-soft text-primary hover:brightness-95")}>
                Pricing · {f.usedBy.rates}
              </button>
            )}
            {uses === 0 && <span className={cn(chip, "bg-muted text-muted-foreground")}>Unused</span>}
            {inert(f) && (
              <span className={cn(chip, "bg-warning-soft text-warning")}>
                {!f.enabled ? "Off" : "No conditions"}
                {uses > 0 ? ` · ${uses} rule${uses === 1 ? "" : "s"} skipped` : ""}
              </span>
            )}
            {twins.map((t) => (
              <button key={t} type="button" onClick={() => onShowTwin(t)}
                className={cn(chip, "bg-warning-soft text-warning hover:brightness-95")}>
                <AlertTriangle className="h-3 w-3" aria-hidden="true" /> Same as {t}
              </button>
            ))}
          </div>
          {f.label && <p className="text-sm text-muted-foreground">{f.label}</p>}
          <p className="text-sm">{sentence || <span className="text-muted-foreground">No conditions yet.</span>}</p>
        </div>

        <div className="flex shrink-0 items-center gap-1">
          <Button type="button" variant="ghost" size="sm" className="gap-1.5" onClick={onEdit}>
            <Pencil className="h-3.5 w-3.5" aria-hidden="true" /> Edit
          </Button>
          <Button type="button" variant="ghost" size="sm" className="gap-1.5" onClick={onCopy}>
            <Copy className="h-3.5 w-3.5" aria-hidden="true" /> Copy
          </Button>
          <DangerAction
            label="Delete"
            confirmLabel="Delete this filter"
            busy={busy}
            consequence={
              uses > 0
                ? `${uses} rule${uses === 1 ? "" : "s"} reference '${f.name}', so this will be refused. Detach it from them first.`
                : `Nothing references '${f.name}', so nothing changes for any rule.`
            }
            onConfirm={onDelete}
          />
        </div>
      </div>

      {open && uses > 0 && (
        <ul id={usesId} className="mt-3 space-y-1 rounded-lg bg-muted/50 px-3 py-2 text-sm">
          {f.usedIn.map((u, i) => (
            <li key={i} className="flex items-center gap-2">
              <span className={cn(chip, u.kind === "routing" ? "bg-sky-100 text-sky-900 dark:bg-sky-950 dark:text-sky-200" : "bg-primary-soft text-primary")}>
                {u.kind === "routing" ? "Routing" : "Pricing"}
              </span>
              <span className="font-mono text-xs">{u.label}</span>
            </li>
          ))}
        </ul>
      )}
    </li>
  );
}
