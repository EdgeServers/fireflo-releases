"use client";
import { useState } from "react";
import { AlertTriangle, KeyRound, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";
import { HealthStrip } from "@/components/CardBits";
import { CodeBlock } from "./CodeBlock";
import type { RotatableLogin } from "@/lib/playground-rules";

/**
 * Replaces a login's API password or key, and shows the new value once.
 *
 * <p>Lives beside Authentication on the reference page, which is where a customer reads "the
 * password is the one you were issued" and is therefore where they look when they want a different
 * one. It is not in the playground: that page is for trying calls, and a control that invalidates
 * the credential you are typing into the box above it would be a trap.
 *
 * <p><strong>Two confirmations, not one, because the two rotations are not the same act.</strong>
 * A password rotation replaces a secret. An API-key rotation replaces the customer's *username* —
 * the key is the Basic username whenever it is set — so their old one stops existing rather than
 * stops working, and both halves of their configuration have to change at once. The second warning
 * says so in those words.
 *
 * <p><strong>The new value is shown once and is not retrievable.</strong> Nothing stores it; leaving
 * this page loses it. That is the same promise the rest of the panel makes about secrets, and the
 * copy button is there because a customer who cannot copy it will screenshot it instead.
 */
export function MisRotateSecret({ logins }: { logins: RotatableLogin[] }) {
  const [chosenId, setChosenId] = useState("");
  const [secret, setSecret] = useState<"password" | "apiKey">("password");
  const [arming, setArming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [issued, setIssued] = useState<null | {
    value: string; login: string; changesUsername: boolean; seconds: number;
  }>(null);

  if (!logins.length) {
    return null;
  }

  const login = logins.find((l) => l.id === chosenId) ?? logins[0];
  const canRotate = secret === "password" ? login.hasPassword : login.hasApiKey;

  async function rotate() {
    setBusy(true);
    setError("");
    try {
      const res = await fetch(`/api/mis/logins/${encodeURIComponent(login.id)}/rotate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ secret }),
      });
      const json = await res.json();
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      setIssued({
        value: json.data.secret,
        login: json.data.login,
        changesUsername: json.data.changesUsername,
        seconds: json.data.propagationSeconds,
      });
      setArming(false);
    } catch {
      setError("Could not reach the panel. Nothing was changed.");
    } finally {
      setBusy(false);
    }
  }

  if (issued) {
    return (
      <div className="space-y-3 rounded-lg border border-emerald-500/40 bg-emerald-500/5 p-3">
        <p className="text-sm font-medium">
          New {issued.changesUsername ? "API key" : "password"} for {issued.login}
        </p>
        <CodeBlock code={issued.value} copyLabel="Copy the new secret" />
        <p className="text-xs leading-relaxed text-muted-foreground">
          {/* the single most likely support call, said before it happens rather than after */}
          <strong>Wait about {issued.seconds} seconds before switching.</strong> The gateway reloads
          credentials on a timer, so right now your <em>old</em> one still works and this new one
          does not yet.
        </p>
        {issued.changesUsername && (
          <HealthStrip tone="warning">
            This was your username as well as your key. Change both halves of your configuration —
            the old username no longer exists.
          </HealthStrip>
        )}
        <p className="text-xs text-muted-foreground">
          This is the only time it is shown. Nothing here can give it to you again.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2 rounded-lg border border-border p-3">
      <div className="flex flex-wrap items-center gap-2">
        <KeyRound className="h-4 w-4 shrink-0 text-muted-foreground" />
        <Select value={login.id} onChange={(e) => { setChosenId(e.target.value); setArming(false); }}
          className="h-8 w-full text-base sm:w-auto sm:min-w-[10rem]">
          {logins.map((l) => <option key={l.id} value={l.id}>{l.systemId}</option>)}
        </Select>
        <Select value={secret}
          onChange={(e) => { setSecret(e.target.value as "password" | "apiKey"); setArming(false); }}
          className="h-8 w-full text-base sm:w-auto">
          <option value="password">Password</option>
          <option value="apiKey">API key</option>
        </Select>
        {!arming && (
          <Button variant="outline" size="sm" disabled={!canRotate} onClick={() => setArming(true)}>
            Rotate
          </Button>
        )}
      </div>

      {!canRotate && (
        <p className="text-xs text-muted-foreground">
          {secret === "password"
            ? "This login has no password to replace. Ask your operator to set one."
            : "This login has no API key. Adding one would change the username it authenticates "
              + "with, so your operator has to do it."}
        </p>
      )}

      {arming && (
        <div className="space-y-2 rounded-md border border-amber-500/40 bg-amber-500/5 p-2.5">
          <p className="flex items-start gap-2 text-sm leading-relaxed">
            <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-500" />
            <span>
              {secret === "apiKey" && login.keyIsUsername ? (
                <>
                  This key is the <strong>username</strong> {login.systemId} authenticates with.
                  Rotating it means the old username stops existing, so anything still using it
                  fails until you change both halves of your configuration. There is no grace
                  period.
                </>
              ) : (
                <>
                  Anything still using the current {secret === "apiKey" ? "key" : "password"} for{" "}
                  <strong>{login.systemId}</strong> will stop working once the change reaches the
                  gateway, about half a minute from now.
                </>
              )}
            </span>
          </p>
          <div className="flex flex-wrap items-center gap-2">
            <Button size="sm" onClick={rotate} disabled={busy}>
              {busy ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : null}
              Rotate it
            </Button>
            <Button variant="outline" size="sm" onClick={() => setArming(false)} disabled={busy}>
              Cancel
            </Button>
          </div>
        </div>
      )}

      {error && <HealthStrip tone="destructive">{error}</HealthStrip>}
    </div>
  );
}
