"use client";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import {
  Activity, BookOpen, ChevronLeft, ChevronRight, FileText, LogOut, Menu, MessageSquare, Signature,
  Terminal, Receipt, Users, X } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { FireFloMark, FireFloWordmark } from "./FireFloMark";
import { NavGroupHeading, NavLink } from "./NavRail";
import { ThemeToggle } from "./ThemeToggle";
import { moneyFromBigintString, moneyScale } from "@/lib/format";
import { PortalNotice } from "@/components/PortalNotice";

/**
 * The portal frame: who you are and what you have left on the left, your messages on the right.
 *
 * <p>Deliberately not `DashboardShell`. That one carries the operator nav, the health link and the
 * runtime badges, and reusing it would mean a customer's markup was one conditional away from an
 * operator's. What the two *do* share is the nav row itself, from `NavRail` — see the note there
 * about why the active-link rule stayed with each caller.
 */

export interface MisSummary {
  accountId: string;
  label: string | null;
  resells: boolean;
  children: { id: string; label: string | null }[];
  balance: { balance: string; currency: string | null } | null;
}

/**
 * The landing page, which belongs to no group.
 *
 * <p>Above the headings for the same reason as the operator panel's: it is where you arrive, and
 * every group below it answers a narrower question than it does.
 */
const overviewLink = { href: "/overview", label: "Overview", icon: Activity };

/**
 * What a customer can reach, in two groups.
 *
 * <p>Messages first inside its group: it is what they signed in for. The registrations sit below it
 * because they are visited when something is wrong or being set up, not daily.
 *
 * <p><strong>The two developer tools moved here from the header.</strong> They were icons beside the
 * theme toggle on the argument that folding them into a flat list of three would make "Templates"
 * and "REST API" look like the same kind of thing. That argument was about the flat list, and the
 * flat list is gone: a heading says outright that these two are a different kind of thing, which is
 * what the header placement was standing in for. Two unlabelled icons in the corner were also the
 * least discoverable part of the portal.
 */
interface NavGroup {
  label: string;
  /** Shown only to an account that holds others. Absent means everyone sees it. */
  resellerOnly?: true;
  links: { href: string; label: string; icon: typeof Activity }[];
}

const GROUPS: NavGroup[] = [
  {
    label: "Customers",
    /**
     * Only for an account that holds others — see the `resells` filter where GROUPS is rendered.
     *
     * <p>Its own group, above Messaging, because managing customers is not a messaging task: a
     * reseller opening the portal to onboard somebody and a reseller opening it to check whether a
     * message went out are two different visits.
     */
    resellerOnly: true,
    links: [{ href: "/accounts", label: "Accounts", icon: Users }],
  },
  {
    label: "Messaging",
    links: [
      { href: "/messages", label: "Messages", icon: MessageSquare },
      { href: "/senders", label: "Sender IDs", icon: Signature },
      { href: "/templates", label: "Templates", icon: FileText },
    ],
  },
  {
    label: "Billing",
    links: [
      //its own group rather than under Messaging: a customer arriving to check an invoice is doing
      //something different from one checking whether a message went out
      { href: "/statement", label: "Statement", icon: Receipt },
    ],
  },
  {
    label: "Developer",
    links: [
      { href: "/playground", label: "API playground", icon: Terminal },
      { href: "/api-docs", label: "REST API reference", icon: BookOpen },
    ],
  },
];

/**
 * Remembered per browser, like the operator rail and the column choosers.
 *
 * <p>Its own key rather than the operator's: this is a different app with a different session, and
 * one person who is both should not have one choice decide the other.
 */
const COLLAPSED_KEY = "fireflo.mis.sidebar.collapsed";

export function MisShell({
  children,
  brand = "FireFlo",
  copyright = "",
}: {
  children: React.ReactNode;
  /** Resolved on the server by the portal layout — see `lib/brand.ts`. */
  brand?: string;
  /**
   * The footer notice, already resolved — see `portalCopyright`.
   *
   * <p>A finished string rather than the pieces, because whether it names the platform depends on
   * whether this portal is white-labelled, and that rule belongs beside the brand it reads. Empty
   * renders no footer, so a caller that has not been updated shows nothing rather than a wrong
   * notice.
   */
  copyright?: string;
}) {
  const [summary, setSummary] = useState<MisSummary | null>(null);
  const [collapsed, setCollapsed] = useState(false);
  //below lg the nav is behind a Menu button. It used to stack above every page as a block of eight
  //rows plus the account card, which put the page itself about 770px down a 390px phone -- below the
  //first screen on every route. The balance did not move with it: a one-line strip stays in view
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = usePathname();

  //closed when a link is followed, during render rather than in an effect -- see the same rule in
  //DashboardShell, where an effect left the menu open over the new page for a frame
  const [seenPathname, setSeenPathname] = useState(pathname);
  if (seenPathname !== pathname) {
    setSeenPathname(pathname);
    setMenuOpen(false);
  }
  //the platform's declared decimal places, set by PlatformScale in the layout above this
  const scale = moneyScale();

  useEffect(() => {
    fetch("/api/mis/summary", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => setSummary(j?.data ?? null))
      .catch(() => setSummary(null));
  }, []);

  useEffect(() => {
    //read after mount, not during render: localStorage and matchMedia do not exist on the server
    //and React 19 throws on the mismatch. The cost is one frame of the expanded rail, which is why
    //the width transitions rather than jumping
    const stored = window.localStorage.getItem(COLLAPSED_KEY);
    //defaults to expanded at every width now. It used to collapse itself below lg, back when
    //collapsing hid the labels only from lg up; the shared NavLink drops them at every size, and
    //below lg the aside is a stacked block that saves nothing by narrowing -- so the old default
    //would have cost a phone its labels to reclaim width it was not short of
    setCollapsed(stored === "1");
  }, []);

  function toggleCollapsed() {
    //the write is outside the updater deliberately: an updater must be a pure function of its
    //argument, and React may call it more than once
    const next = !collapsed;
    window.localStorage.setItem(COLLAPSED_KEY, next ? "1" : "0");
    setCollapsed(next);
  }

  return (
    <div className="min-h-dvh bg-background">
      <header className="flex items-center justify-between border-b border-border px-4 py-3">
        <div className="flex items-center gap-2">
          <FireFloMark />
          <FireFloWordmark name={brand} />
        </div>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setMenuOpen((open) => !open)}
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            aria-expanded={menuOpen}
            aria-controls="mis-nav"
            className="rounded-md p-3 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground lg:hidden"
          >
            {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
          <ThemeToggle />
          <button
            onClick={signOut}
            className="flex min-h-11 items-center gap-2 rounded-lg px-3 py-3 text-sm text-muted-foreground transition-colors hover:bg-accent hover:text-foreground md:min-h-0 md:py-2"
          >
            <LogOut className="h-4 w-4" />
            {/* icon-only on a phone, where the label wrapped onto two lines beside the menu button */}
            <span className="max-sm:sr-only">Sign out</span>
          </button>
        </div>
      </header>

      {/* on a phone: the menu when it is open, then the balance strip, then the page. The balance
          still comes before the page -- it is the thing you opened this for -- but as one line */}
      <div className="mx-auto flex max-w-[100rem] flex-col gap-4 p-4 md:p-6 lg:flex-row lg:gap-6">
        {/* collapse applies from lg up only. Below that the aside already stacks above the
            content, and a rail there would cover the thing it indexes */}
        <aside className={
          //gap rather than space-y: on a phone most of this column is display:none, and space-y
          //still gave the visible strip a margin for its hidden sibling -- 32px where 16 was meant
          "relative flex w-full shrink-0 flex-col gap-4 transition-[width] duration-200 "
          + (collapsed ? "lg:w-16" : "lg:w-72")
        }>
          <button
            type="button"
            onClick={toggleCollapsed}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            aria-expanded={!collapsed}
            title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            className="absolute -right-3 top-2 z-30 hidden h-6 w-6 items-center justify-center rounded-full border border-border bg-card text-muted-foreground shadow-sm transition-colors hover:bg-accent hover:text-foreground lg:flex"
          >
            {collapsed
              ? <ChevronRight className="h-3.5 w-3.5" />
              : <ChevronLeft className="h-3.5 w-3.5" />}
          </button>

          {/* a card, unlike the operator's, which is a full-height column against the window edge.
              Here the nav is one block in a stack that also holds the balance, and an unboxed list
              beside a boxed card reads as though it belongs to the card below it */}
          <Card id="mis-nav" className={menuOpen ? undefined : "max-lg:hidden"}>
            <CardContent className={collapsed ? "px-2 py-2" : "px-3 py-2"}>
              <nav>
                <NavLink
                  {...overviewLink}
                  collapsed={collapsed}
                  //exact throughout the portal, unlike the operator panel's prefix rule: every page
                  //here is a leaf with nothing below it, so a prefix match would only ever be a way
                  //to light the wrong row. See the note in NavRail about why the rule is the
                  //caller's to make
                  active={pathname === overviewLink.href}
                />
                {GROUPS.filter((g) => !g.resellerOnly || summary?.resells).map((group) => (
                  <div key={group.label} className="mt-2">
                    <NavGroupHeading label={group.label} collapsed={collapsed} />
                    {/* one column at every width. It was two across below lg, to halve how far the
                        nav pushed the page down a phone; behind the Menu button it pushes nothing,
                        and two columns were cutting "REST API reference" to "REST API refer…" */}
                    <div className="grid gap-0.5">
                      {group.links.map((link) => (
                        <NavLink
                          key={link.href}
                          {...link}
                          collapsed={collapsed}
                          //exact everywhere except Accounts, which is the portal's only link with
                          //pages beneath it -- an exact rule there leaves the rail unlit from the
                          //moment somebody opens one of their customers. See the note above about
                          //why the rule stayed with each caller rather than moving into NavRail
                          active={link.href === "/accounts"
                            ? pathname.startsWith("/accounts")
                            : pathname === link.href}
                        />
                      ))}
                    </div>
                  </div>
                ))}
              </nav>
            </CardContent>
          </Card>

          {/* the account card goes, but the balance does not: this file's own note says the
              balance is the thing you opened the portal for, and a rail that hides it is following
              the letter of "collapsible" against the point of the page */}
          {collapsed && summary?.balance && (
            <p className="hidden text-center text-xs tabular-nums text-muted-foreground lg:block"
              title={`Balance ${moneyFromBigintString(summary.balance.balance, scale)} ${summary.balance.currency ?? ""}`}>
              {moneyFromBigintString(summary.balance.balance, 0)}
            </p>
          )}

          {/* the phone's balance: one line, always in view, where the account card used to be */}
          <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1 rounded-xl border border-border bg-card px-3 py-2.5 text-sm lg:hidden">
            <span className="min-w-0 truncate font-medium">{summary?.label ?? summary?.accountId ?? "…"}</span>
            <span className="ml-auto tabular-nums">
              {summary?.balance ? (
                <>
                  <span className="text-2xs font-semibold uppercase tracking-wide text-muted-foreground">Balance </span>
                  <span className="font-semibold">{moneyFromBigintString(summary.balance.balance, scale)}</span>{" "}
                  <span className="text-muted-foreground">{summary.balance.currency ?? ""}</span>
                </>
              ) : (
                <span className="text-muted-foreground">Not on prepaid credit</span>
              )}
            </span>
          </div>

          <div className={cn("space-y-4 max-lg:hidden", collapsed && "lg:hidden")}>
          <Card>
            <CardContent className="space-y-3 py-4">
              <div>
                <p className="text-base font-medium">{summary?.label ?? summary?.accountId ?? "…"}</p>
                <p className="font-mono text-xs text-muted-foreground">{summary?.accountId}</p>
              </div>

              <div className="border-t border-border pt-3">
                <p className="text-2xs font-semibold uppercase tracking-wide text-muted-foreground">Balance</p>
                {summary?.balance ? (
                  <p className="text-2xl font-semibold tabular-nums">
                    {moneyFromBigintString(summary.balance.balance, scale)}{" "}
                    <span className="text-sm font-normal text-muted-foreground">
                      {summary.balance.currency ?? ""}
                    </span>
                  </p>
                ) : (
                  /* no row and zero are different states, and saying "0.0000" for the first is a
                     confident lie about an account that simply has no prepaid credit set up */
                  <p className="text-sm text-muted-foreground">Not on prepaid credit</p>
                )}
              </div>

              {summary?.resells && (
                <div className="border-t border-border pt-3">
                  <p className="text-2xs font-semibold uppercase tracking-wide text-muted-foreground">
                    Your accounts
                  </p>
                  {summary.children.length ? (
                    <ul className="mt-1 space-y-0.5">
                      {summary.children.map((c) => (
                        <li key={c.id} className="truncate text-sm">
                          {c.label ?? c.id}
                          {c.label && (
                            <span className="ml-1 font-mono text-xs text-muted-foreground">
                              {c.id}
                            </span>
                          )}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="mt-1 text-sm text-muted-foreground">None yet.</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          </div>
        </aside>

        <main className="min-w-0 flex-1 space-y-5">
          {/* above the page content rather than in the chrome: a customer reads down from here, and
              a notice tucked beside the navigation is one nobody sees. Says nothing about licensing
              or the platform's name -- see PortalNotice */}
          <PortalNotice />
          {children}
          {/* no version here, unlike the operator side: a customer has no use for it, and on a
              white-labelled portal a version string is a fingerprint that identifies the platform
              underneath — which is the one thing this surface is built not to do */}
          {copyright && (
            <footer className="border-t border-border pt-4 text-xs text-muted-foreground">
              {copyright}
            </footer>
          )}
        </main>
      </div>
    </div>
  );
}

/**
 * Ends the session properly: a CSRF-protected POST, not a link.
 *
 * <p>`signOut` from `next-auth/react` is bound to the operator instance's base path and would ask
 * the wrong endpoint. A plain `<a href>` to the signout route is a GET, which NextAuth answers with
 * a confirmation page rather than by clearing anything -- so the customer would appear signed out,
 * still hold a valid cookie, and be signed back in by the next page load.
 */
async function signOut() {
  const { csrfToken } = await (await fetch("/api/mis/auth/csrf")).json();
  await fetch("/api/mis/auth/signout", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ csrfToken, callbackUrl: "/" }),
  });
  window.location.href = "/";
}
