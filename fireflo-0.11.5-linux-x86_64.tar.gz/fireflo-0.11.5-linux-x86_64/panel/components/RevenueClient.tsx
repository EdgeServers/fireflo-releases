"use client";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { TBody, TD, TH, THead, TR, Table } from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { RangePicker } from "./RangePicker";
import { useControlData, type Range } from "./useControlData";
import { count, money, percent } from "@/lib/format";
import { EmptyState } from "@/components/ui/empty-state";

interface RevenueRow {
  accountId: string | null;
  product: string | null;
  messages: number;
  revenue: number;
  cost: number;
  margin: number;
  pendingRevenue: number;
}

export function RevenueClient() {
  const [range, setRange] = useState<Range>("24h");
  const { data, error, loading } = useControlData<RevenueRow[]>("revenue", range);
  const rows = data ?? [];

  const revenue = rows.reduce((a, r) => a + r.revenue, 0);
  const cost = rows.reduce((a, r) => a + r.cost, 0);
  const pending = rows.reduce((a, r) => a + r.pendingRevenue, 0);
  const margin = revenue - cost;

  return (
    <>
      <PageHeader
        title="Revenue"
        description="Revenue counts each message once; cost counts every vendor attempt."
        actions={<RangePicker value={range} onChange={setRange} />}
      />

      {error && (
        <Card>
          <CardContent className="py-4 text-sm text-destructive">{error}</CardContent>
        </Card>
      )}

      {!error && !!rows.length && (
        <Card>
          <CardHeader>
            <CardTitle>Total</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-4">
            <Summary label="Billed" value={money(revenue)} />
            <Summary label="Vendor cost" value={money(cost)} />
            <Summary
              label="Margin"
              value={money(margin)}
              hint={revenue > 0 ? percent(margin / revenue) : undefined}
              tone={margin < 0 ? "negative" : "positive"}
            />
            {/* not an error: billed traffic with no outcome yet. The gateway's sweeper closes it
                as EXPIRED after 48h, so anything older than that means the sweeper is not running */}
            <Summary label="In flight" value={money(pending)} hint="Billed, outcome unknown" />
          </CardContent>
        </Card>
      )}

      {!error && !rows.length && (
        <EmptyState>
          {loading ? "Loading…" : "No billed traffic in this period"}
        </EmptyState>
      )}

      {!!rows.length && (
        <>
          <Table className="hidden md:block">
            <THead>
              <tr>
                <TH>Account</TH>
                <TH>Product</TH>
                <TH align="right">Messages</TH>
                <TH align="right">Billed</TH>
                <TH align="right">Cost</TH>
                <TH align="right">Margin</TH>
                <TH align="right">In flight</TH>
              </tr>
            </THead>
            <TBody>
              {rows.map((r, i) => (
                <TR key={`${r.accountId}-${r.product}-${i}`}>
                  <TD primary>{r.accountId ?? "—"}</TD>
                  <TD muted>{r.product ?? "—"}</TD>
                  <TD num>{count(r.messages)}</TD>
                  <TD num className="font-mono">{money(r.revenue)}</TD>
                  <TD num className="font-mono">{money(r.cost)}</TD>
                  <TD num className={cn("font-mono", r.margin < 0 ? "text-destructive" : "text-primary")}>
                    {money(r.margin)}
                  </TD>
                  <TD num muted className="font-mono">
                    {money(r.pendingRevenue)}
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>

          <div className="flex flex-col gap-3 md:hidden">
            {rows.map((r, i) => (
              <Card key={`${r.accountId}-${r.product}-${i}`}>
                <CardHeader>
                  <CardTitle>
                    {r.accountId ?? "—"}
                    {r.product && (
                      <span className="ml-2 text-sm font-normal text-muted-foreground">{r.product}</span>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                  <span className="text-muted-foreground">Messages</span>
                  <span className="text-right tabular-nums">{count(r.messages)}</span>
                  <span className="text-muted-foreground">Billed</span>
                  <span className="text-right tabular-nums">{money(r.revenue)}</span>
                  <span className="text-muted-foreground">Cost</span>
                  <span className="text-right tabular-nums">{money(r.cost)}</span>
                  <span className="text-muted-foreground">Margin</span>
                  <span
                    className={`text-right tabular-nums ${r.margin < 0 ? "text-destructive" : "text-primary"}`}
                  >
                    {money(r.margin)}
                  </span>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      )}
    </>
  );
}

function Summary({
  label,
  value,
  hint,
  tone = "default",
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: "default" | "positive" | "negative";
}) {
  const toneClass =
    tone === "positive" ? "text-primary" : tone === "negative" ? "text-destructive" : "";
  return (
    <div className="min-w-0">
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className={`font-mono text-2xl font-semibold tabular-nums ${toneClass}`}>{value}</p>
      {hint && <p className="text-sm text-muted-foreground">{hint}</p>}
    </div>
  );
}
