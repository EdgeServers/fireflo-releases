"use client";
import Link from "next/link";
import { Languages } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClasses } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { CardActions, Figures, HealthStrip } from "./CardBits";
import type { HealthWorker } from "@/lib/health-types";
import type { WorkerVerdict } from "@/lib/worker-verdict";
import { type Worker, trafficKey } from "@/lib/worker-types";
import { formatTimestamp } from "@/lib/datetime";

/**
 * One vendor on the list: is it up, is it moving, and the actions you take from a list.
 *
 * <p>Everything else -- bind settings, cost rates, the traffic breakdown, sessions -- is on the
 * vendor's own page. The accordion this replaced put all of it in one card, so an operator
 * checking whether a vendor was connected scrolled through its settings to find out.
 */
export function VendorCard({
  worker,
  live,
  verdict,
  sent,
  busy,
  onEdit,
  onToggleEnabled,
  onTest,
}: {
  worker: Worker;
  live: HealthWorker | undefined;
  verdict: WorkerVerdict;
  /** Messages through it in the chosen period, from the call records. */
  sent: number | null;
  busy: boolean;
  onEdit: () => void;
  onToggleEnabled: (enabled: boolean) => void;
  /** Present only when the verdict says it is not connected. */
  onTest?: () => void;
}) {
  const host = [prop(worker, "host"), prop(worker, "port")].filter(Boolean).join(":");
  const queued = live ? (live.queue_depth ?? 0) + (live.retry_queue_depth ?? 0) : null;
  const bad = verdict.tone === "destructive";
  const settings = [
    worker.label,
    prop(worker, "connections.transceivers") && `transceiver ×${prop(worker, "connections.transceivers")}`,
    prop(worker, "windowSize") && `window ${prop(worker, "windowSize")}`,
  ].filter(Boolean).join(" · ");

  return (
    <Card className={bad ? "border-destructive" : !worker.enabled ? "opacity-70" : undefined}>
      <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
        <span
          aria-hidden
          className={`h-2 w-2 shrink-0 rounded-full ${bad ? "bg-destructive" : verdict.tone === "success" ? "bg-success" : verdict.tone === "warning" ? "bg-warning" : "bg-border"}`}
        />
        <Link href={`/cp/vendors/${encodeURIComponent(worker.name)}`} className="text-sm font-medium hover:underline">
          {worker.name}
        </Link>
        {host && <span className="font-mono text-xs text-muted-foreground">{host}</span>}
        <Badge variant={verdict.tone}>{verdict.label}</Badge>
        <CardActions>
          <Link href={`/cp/error-codes/${encodeURIComponent(worker.name)}`} className={buttonClasses({ variant: "outline", size: "sm" })}>
            <Languages className="h-3.5 w-3.5" />
            Error codes
          </Link>
          {onTest && (
            <Button variant="outline" size="sm" onClick={onTest}>Test connection</Button>
          )}
          <Button variant="outline" size="sm" onClick={onEdit}>Edit</Button>
          <Button variant="ghost" size="sm" disabled={busy} onClick={() => onToggleEnabled(!worker.enabled)}>
            {worker.enabled ? "Disable" : "Enable"}
          </Button>
        </CardActions>
      </CardHeader>
      <CardContent className="space-y-3 pt-3">
        <Figures
          figures={[
            { value: live?.bound ?? "—", label: "binds", tone: live && (live.bound ?? 0) === 0 && worker.enabled ? "destructive" : "default" },
            { value: queued ?? "—", label: "queued", tone: queued ? "warning" : "default" },
            { value: live?.tps_limit != null ? `≤${live.tps_limit}` : "—", label: "tps limit" },
            { value: sent == null ? "—" : sent.toLocaleString(), label: "sent in period" },
          ]}
        />
        {live?.last_error && (
          <HealthStrip tone="destructive">
            <span className="line-clamp-2">{live.last_error}</span>
            {live.last_error_at && <span className="ml-2 opacity-80">{formatTimestamp(live.last_error_at)}</span>}
          </HealthStrip>
        )}
        <div className="flex items-center gap-2 text-xs">
          <span className="min-w-0 flex-1 truncate text-muted-foreground">{settings || "No stored settings"}</span>
          <Link href={`/cp/vendors/${encodeURIComponent(worker.name)}`} className="font-semibold text-primary hover:underline">
            Open vendor →
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}

function prop(worker: Worker, key: string): string {
  return worker.properties.find((p) => p.key === key)?.value ?? "";
}

export { trafficKey };
