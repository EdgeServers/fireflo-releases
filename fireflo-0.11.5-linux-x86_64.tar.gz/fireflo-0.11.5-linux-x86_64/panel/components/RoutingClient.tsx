"use client";
import { useState } from "react";
import { ArrowRight, Plus, Power, PowerOff } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { EmptyState } from "@/components/ui/empty-state";
import { PageHeader } from "@/components/ui/page-header";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { Tabs } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { AdvancedToggle } from "./AdvancedToggle";
import { CardActions, Figures, HealthStrip } from "./CardBits";
import { DangerAction } from "./DangerAction";
import { DefaultRouting, RecreateAction } from "./DefaultRouting";
import { DeliveryCheck } from "./DeliveryCheck";
import { ErrorCard } from "./FormNotices";
import { GatewayIgnores } from "./GatewayIgnores";
import { GroupsClient } from "./GroupsClient";
import { RouteTableForm } from "./RouteTableForm";
import { RoutingTester } from "./RoutingTester";
import { useAdvanced } from "@/hooks/useAdvanced";
import { useHealth } from "./useHealth";
import { useRouting } from "./useRouting";
import { useRuntimeMetrics } from "./useRuntimeMetrics";
import { useWorkers } from "./useWorkers";
import { readsRoutingFromDatabase } from "@/lib/health-types";
import {
  RULE_DIRECTION_LABEL,
  TARGET_FUNCTION_MEANING,
  ruleDirection,
  type RouteRule,
  type RouteTable,
  routeTableWarnings,
  targetKind,
} from "@/lib/routing-types";
import type { RuntimeSnapshot } from "@/lib/runtime-metrics";

/**
 * Reads one rule's traffic counter out of the metrics snapshot, using the exact key
 * {@code AbstractRoutingManager.recordRuleMatch} builds on the gateway: the rule's own label when
 * it has one, else {@code table:seq} with {@code seq} 1-based -- the same "Order" column every rule
 * row already shows.
 *
 * @returns null when there is no snapshot yet, or the rule has never matched -- both render as
 *     nothing rather than "0", so a metrics fetch that has not landed does not look like dead traffic
 */
function ruleMatchCount(
  metrics: RuntimeSnapshot | null,
  tableName: string,
  rule: RouteRule,
  index: number
): number | null {
  if (!metrics) {
    return null;
  }
  const key = rule.label ?? `${tableName}:${index + 1}`;
  return metrics.routingRuleMatches[tableName]?.[key] ?? null;
}

/**
 * Where messages go: the routing tables, and the rules that chain them together.
 *
 * <p>The last configuration domain the panel could not edit. `app_route_table` and `app_route_rule`
 * have been readable since V1.4.0 and were filled by `fireflo import routing`, but with no editor
 * the only safe source was the file. This page is what made `FIREFLO_CONFIG_SOURCE=db` a reasonable
 * thing to set rather than a one-way door.
 *
 * <p><strong>Tables are listed rather than nested.</strong> Routing is a graph — `default` chains
 * into `MESSAGE`, which chains into `cheapest` — and drawing it as a tree would either repeat
 * subtrees or pick an arbitrary root. A flat list with each rule's target labelled as table or
 * worker lets the reader follow the chain without the page claiming a shape the data does not have.
 */
/**
 * What deleting a routing table costs.
 *
 * <p>Names the tables that chain INTO it as well as the rules inside it. Since gateway V1.58.0 a
 * table other tables still jump to cannot be deleted at all -- the server refuses and names them --
 * so this says so up front instead of promising a delete that will not happen.
 */
function describeTableRemoval(table: RouteTable, tables: RouteTable[]): string {
  const into = tables
    .flatMap((t) => t.rules.map((r) => ({ from: t.name, target: r.target })))
    .filter((r) => r.target === table.name && r.from !== table.name);
  const chained = [...new Set(into.map((r) => r.from))];

  return `Its ${table.rules.length} rule(s) go with it.`
    + (chained.length
      ? ` ${into.length} rule(s) in ${chained.join(", ")} chain into it, so this will be refused until they`
        + " point somewhere else."
      : "");
}

export function RoutingClient() {
  const { tables, error, loading, busy, load, save, remove, toggleRule } = useRouting();
  //a live counter since the gateway last restarted, not a durable history -- see the "since
  //restart" label on each count. Polled independently of the routing tables themselves, which come
  //from app_route_table and change on an edit, not on traffic
  const { snapshot: metrics } = useRuntimeMetrics();
  //both kinds: a vendor is an outbound target, a listener is where a delivery receipt goes back
  const { workers: clients } = useWorkers("smppclient");
  const { workers: servers } = useWorkers("smppserver");
  const workers = [...clients, ...servers];
  const { health } = useHealth();
  const writable = readsRoutingFromDatabase(health);
  const [editing, setEditing] = useState<RouteTable | "new" | null>(null);
  const [removeError, setRemoveError] = useState("");
  const [tab, setTab] = useState<"tables" | "groups" | "test" | "delivery">("tables");
  const [showAll, setShowAll] = useState<Record<string, boolean>>({});
  const [advanced, setAdvanced] = useAdvanced("routing");

  const tableNames = tables.map((t) => t.name);

  //"Start rule" hands the operator a table already carrying the draft, unsaved -- the same edit
  //flow as clicking Edit, just with one more row already in the form for them to point somewhere
  function startMoRule(draft: RouteRule) {
    const target = tables.find((t) => t.name === "default");
    if (!target) {
      setRemoveError("There is no 'default' routing table to add the rule to. Create one first.");
      return;
    }
    setEditing({ ...target, rules: [...target.rules, draft] });
  }

  if (editing !== null) {
    return (
      <div className="space-y-5">
        <ErrorCard error={error} />
        <RouteTableForm
          key={editing === "new" ? "new" : editing.name}
          initial={editing === "new" ? null : editing}
          tableNames={tableNames}
          workers={workers}
          onSave={async (input) => {
            const failure = await save(input);
            if (!failure) {
              setEditing(null);
            }
            return failure;
          }}
          onCancel={() => setEditing(null)}
        />
      </div>
    );
  }

  const entryCount = tables.find((t) => t.name === "default")?.rules.length ?? 0;

  return (
    <div className="space-y-5">
      <PageHeader
        title="Routing"
        description="Which vendor each message goes to, and why. Rules are tried in order; the first match wins."
        actions={
          <>
            <AdvancedToggle on={advanced} onChange={setAdvanced} />
            <RecreateAction
              tables={tables}
              servers={servers}
              vendors={clients}
              writable={writable}
              onApplied={load}
            />
            <Button onClick={() => setEditing("new")} className="gap-2">
              <Plus className="h-4 w-4" />
              New routing table
            </Button>
          </>
        }
      />

      <ErrorCard error={error || removeError} />
      <GatewayIgnores domain="routing" />

      <DefaultRouting
        tables={tables}
        servers={servers}
        vendors={clients}
        writable={writable}
        onApplied={load}
        onStartMoRule={startMoRule}
      />

      {/* the three tools that used to share a rail with the tables. Tabs rather than a rail: the
          tables are the page, and groups, the tester and the delivery check are each reached for
          on purpose, once the tables look right */}
      <Tabs
        label="Routing"
        items={[
          { id: "tables", label: `Tables · ${tables.length}` },
          { id: "groups", label: "Vendor groups" },
          { id: "test", label: "Test a message" },
          { id: "delivery", label: "Delivery check" },
        ]}
        active={tab}
        onSelect={setTab}
      />

      {tab === "groups" && <GroupsClient />}
      {tab === "test" && <RoutingTester />}
      {tab === "delivery" && <DeliveryCheck />}

      {tab === "tables" && (
        <div className="grid gap-4 xl:grid-cols-2">
          {tables.map((table) => {
            const warnings = routeTableWarnings(table, tableNames, workers);
            const chainedFrom = [...new Set(
              tables.filter((t) => t.name !== table.name && t.rules.some((r) => r.target === table.name)).map((t) => t.name)
            )];
            const toTables = table.rules.filter((r) => targetKind(r.target, tableNames, workers) === "table").length;
            const toWorkers = table.rules.length - toTables;
            const matched = table.rules.reduce((n, r, i) => n + (ruleMatchCount(metrics, table.name, r, i) ?? 0), 0);
            const open = !!showAll[table.name];
            const rules = open ? table.rules : table.rules.slice(0, 3);
            return (
              <Card key={table.name} className={cn("min-w-0", !table.enabled && "opacity-70")}>
                <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
                  <span className="font-mono text-sm font-medium">{table.name}</span>
                  {table.name === "default" && <Badge>Entry point</Badge>}
                  <Badge variant="outline">{table.targetFunction}</Badge>
                  {!table.enabled && <Badge variant="destructive">disabled</Badge>}
                  <CardActions>
                    <Button variant="outline" size="sm" onClick={() => setEditing(table)}>Edit</Button>
                    {advanced && (
                      <DangerAction
                        label="Delete"
                        confirmLabel="Delete this table"
                        busy={busy === table.name}
                        consequence={describeTableRemoval(table, tables)}
                        onConfirm={async () => setRemoveError((await remove(table.name)) ?? "")}
                      />
                    )}
                  </CardActions>
                </CardHeader>
                <CardContent className="space-y-3 pt-3">
                  {(table.label?.trim() || TARGET_FUNCTION_MEANING[table.targetFunction]) && (
                    <p className="text-xs text-muted-foreground">
                      {table.label?.trim() || TARGET_FUNCTION_MEANING[table.targetFunction]}
                    </p>
                  )}
                  <Figures
                    figures={[
                      { value: table.rules.length, label: table.rules.length === 1 ? "rule" : "rules" },
                      { value: toTables, label: "→ tables" },
                      { value: toWorkers, label: "→ vendors / listeners" },
                      { value: chainedFrom.length ? chainedFrom.join(", ") : table.name === "default" ? "entry" : "—", label: "chains here" },
                      { value: metrics ? matched.toLocaleString() : "—", label: "matched since restart" },
                    ]}
                  />
                  {warnings.map((w) => <HealthStrip key={w}>{w}</HealthStrip>)}

                  {!table.rules.length ? (
                    <p className="text-sm text-muted-foreground">No rules, so this table routes nothing.</p>
                  ) : (
                    <TableInCard>
                      <THead>
                        <TR>
                          <TH>{table.targetFunction === "NORMAL" ? "#" : ""}</TH>
                          <TH>Sends to</TH>
                          <TH>When</TH>
                          {advanced && <TH>Filters</TH>}
                          <TH align="right">Sent</TH>
                          <TH><span className="sr-only">On</span></TH>
                        </TR>
                      </THead>
                      <TBody>
                        {rules.map((rule, i) => {
                          const kind = targetKind(rule.target, tableNames, workers);
                          const direction = ruleDirection(rule);
                          const count = ruleMatchCount(metrics, table.name, rule, i);
                          return (
                            <TR key={rule.id ?? i} className={cn(!rule.enabled && "opacity-60")}>
                              <TD className="text-xs text-muted-foreground">
                                {table.targetFunction === "NORMAL" ? i + 1 : "·"}
                              </TD>
                              <TD>
                                <span className="flex flex-wrap items-center gap-1.5">
                                  <span className="font-mono text-xs font-semibold">{rule.target}</span>
                                  {kind === "table" && <ArrowRight className="h-3 w-3 text-muted-foreground" aria-label="another table" />}
                                  {kind === "unknown" && <Badge variant="warning">not recognised</Badge>}
                                  {kind === "disabled" && <Badge variant="warning">vendor switched off</Badge>}
                                  {direction !== "outbound" && (
                                    <Badge variant={direction === "receipt" ? "default" : "outline"}>
                                      {RULE_DIRECTION_LABEL[direction]}
                                    </Badge>
                                  )}
                                  {rule.copied && <Badge variant="outline">copy</Badge>}
                                </span>
                                {rule.label && <span className="block text-xs text-muted-foreground">{rule.label}</span>}
                              </TD>
                              <TD className="font-mono text-xs text-muted-foreground">
                                {rule.conditions.length
                                  ? (advanced ? rule.conditions : rule.conditions.slice(0, 1)).map((c, n) => (
                                    <span key={n} className="block whitespace-nowrap">
                                      {c.field} {c.negate ? "not " : ""}{c.operator} {c.value}
                                    </span>
                                  ))
                                  : <span className="font-sans">anything</span>}
                                {!advanced && rule.conditions.length > 1 && (
                                  <span className="block font-sans">+{rule.conditions.length - 1} more</span>
                                )}
                              </TD>
                              {advanced && (
                                <TD className="font-mono text-xs text-muted-foreground">
                                  {rule.filters.length ? rule.filters.join(", ") : "—"}
                                </TD>
                              )}
                              <TD num className="text-xs text-muted-foreground">
                                {count === null ? "—" : count.toLocaleString()}
                              </TD>
                              <TD align="right" className="py-1">
                                {rule.id != null && (
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className={`h-7 w-7 px-0 ${rule.enabled ? "text-muted-foreground" : ""}`}
                                    disabled={busy === `${table.name}:${rule.id}`}
                                    title={rule.enabled ? "Disable this rule" : "Enable this rule"}
                                    onClick={async () => {
                                      const failure = await toggleRule(table.name, rule.id!, !rule.enabled);
                                      if (failure) {
                                        setRemoveError(failure);
                                      }
                                    }}
                                  >
                                    {rule.enabled
                                      ? <Power className="h-3.5 w-3.5" />
                                      : <PowerOff className="h-3.5 w-3.5 text-warning" />}
                                  </Button>
                                )}
                              </TD>
                            </TR>
                          );
                        })}
                      </TBody>
                    </TableInCard>
                  )}
                  {table.rules.length > 3 && (
                    <button
                      type="button"
                      className="text-xs font-semibold text-primary hover:underline"
                      onClick={() => setShowAll((m) => ({ ...m, [table.name]: !open }))}
                    >
                      {open ? "Show fewer" : `Show all ${table.rules.length} rules →`}
                    </button>
                  )}
                </CardContent>
              </Card>
            );
          })}

          {!tables.length && !loading && (
            <EmptyState className="min-w-0 xl:col-span-2">
              No routing tables. The gateway would have nowhere to send anything.
            </EmptyState>
          )}
        </div>
      )}
      {tab === "tables" && entryCount === 0 && tables.length > 0 && (
        <HealthStrip tone="destructive">The entry-point table <code>default</code> has no rules, so nothing is routed.</HealthStrip>
      )}
    </div>
  );
}
