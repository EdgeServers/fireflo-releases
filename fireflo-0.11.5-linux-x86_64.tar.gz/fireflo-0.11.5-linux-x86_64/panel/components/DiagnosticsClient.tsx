"use client";
import { useCallback, useEffect, useState } from "react";
import { Download, FileText, RefreshCw, ScrollText } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClasses } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { PageHeader } from "@/components/ui/page-header";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { HealthStrip } from "./CardBits";
import {
  CONFIG_NAMES,
  LOG_NAMES,
  describeState,
  type ConfigName,
  type GatewayConfigView,
  type GatewayFileCatalog,
  type GatewayLogTail,
  type LogName,
} from "@/lib/gateway-files-types";

/**
 * The gateway's own files, read over its management API.
 *
 * <p>Everything here comes from the machine running the gateway rather than from the database, and
 * that is the point: the rest of the panel shows what has been *written* for the gateway, and in
 * file mode that can differ from what it is *reading* indefinitely with nothing to say so.
 *
 * <p><strong>The notes the gateway sends back are rendered, not summarised.</strong> They carry the
 * distinctions that make an empty result interpretable — a log that is not being written at all, a
 * filter that searched only the last megabyte, a configuration file the gateway is ignoring. Showing
 * an empty pane without them would answer "nothing here" to three questions with different answers.
 */
export function DiagnosticsClient() {
  return (
    <>
      <PageHeader
        title="Logs"
        description="Read from the machine running the gateway. Secrets are blanked before they leave that process, so nothing on this page can show you a password or a token."
      />

      {/* the width goes where it is read. Logs and Configuration are both a `max-h-[32rem]` pane of
          wrapped text, and narrowing either makes it unreadable; Files is eight fixed rows that
          never needed a full-width table. `xl` because those two panes wrap badly in two thirds of
          1024px, and the page owns the grid rather than any child owning its own split */}
      <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_20rem]">
        <div className="min-w-0 space-y-4">
          <Logs />
          <Configuration />
        </div>
        <Catalogue />
      </div>
    </>
  );
}

function Catalogue() {
  const [data, setData] = useState<GatewayFileCatalog | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let alive = true;
    fetch("/api/control/gateway-files", { cache: "no-store" })
      .then(async (res) => {
        const json = await res.json();
        if (!alive) return;
        if (!res.ok) setError(json?.error ?? `Request failed (${res.status})`);
        else setData(json.data as GatewayFileCatalog);
      })
      .catch((err) => {
        if (alive) setError(err instanceof Error ? err.message : "Request failed");
      });
    return () => {
      alive = false;
    };
  }, []);

  return (
    <Card className="min-w-0">
      <CardHeader className="flex-row flex-wrap items-center justify-between gap-2 space-y-0">
        <CardTitle className="flex items-center gap-2">
          <FileText className="size-4" /> Files
        </CardTitle>
        <a
          href="/api/control/diagnostics"
          download
          className={buttonClasses({ variant: "outline", size: "sm" })}
        >
          <Download className="size-4" /> Download bundle
        </a>
      </CardHeader>
      <CardContent>
        {error && <p className="text-sm text-destructive">{error}</p>}
        {!error && !data && <p className="text-sm text-muted-foreground">Loading…</p>}
        {/* a row list rather than the four-column table this was. In a 20rem column the path cell —
            `break-all` on an absolute path — took more height than the other three columns
            together and pushed the state badge out of alignment. Same eight files, same fields,
            stacked instead of ranged */}
        {data && (
          <ul className="space-y-2">
            {data.files.map((file) => (
              <li key={file.name} className="border-b border-border pb-2 last:border-0 last:pb-0">
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate text-sm font-medium">{file.name}</span>
                  <Badge variant={file.state === "present" ? "default" : "outline"}>
                    {describeState(file.state, file.kind)}
                  </Badge>
                </div>
                <p className="mt-0.5 break-all font-mono text-xs text-muted-foreground">
                  {file.path}
                  {file.size_bytes != null && (
                    <span className="ml-1.5 tabular-nums">· {bytes(file.size_bytes)}</span>
                  )}
                </p>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

function Logs() {
  const [name, setName] = useState<LogName>("main");
  const [lines, setLines] = useState("200");
  const [contains, setContains] = useState("");
  const [data, setData] = useState<GatewayLogTail | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const query = new URLSearchParams();
      if (/^\d+$/.test(lines)) query.set("lines", lines);
      if (contains.trim()) query.set("contains", contains.trim());
      const res = await fetch(`/api/control/gateway-logs/${name}?${query}`, { cache: "no-store" });
      const json = await res.json();
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        setData(null);
      } else {
        setData(json.data as GatewayLogTail);
        setError("");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setLoading(false);
    }
  }, [name, lines, contains]);

  //on the chosen log changing, but NOT on every keystroke in the two inputs -- a filter that
  //re-queried per character would re-read the window on the gateway for each one
  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [name]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ScrollText className="size-4" /> Logs
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <form
          className="flex flex-wrap items-end gap-3"
          onSubmit={(event) => {
            event.preventDefault();
            void load();
          }}
        >
          <label className="w-full space-y-1 text-sm text-muted-foreground sm:w-auto">
            <span className="block">Log</span>
            <Select value={name} onChange={(e) => setName(e.target.value as LogName)}>
              {LOG_NAMES.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </Select>
          </label>
          <label className="space-y-1 text-sm text-muted-foreground">
            <span className="block">Lines</span>
            <Input
              className="w-24"
              value={lines}
              inputMode="numeric"
              onChange={(e) => setLines(e.target.value)}
            />
          </label>
          <label className="w-full min-w-0 flex-1 space-y-1 text-sm text-muted-foreground sm:w-auto sm:min-w-48">
            <span className="block">Containing</span>
            <Input
              value={contains}
              placeholder="e.g. ERROR"
              onChange={(e) => setContains(e.target.value)}
            />
          </label>
          <Button type="submit" variant="outline" disabled={loading}>
            <RefreshCw className={loading ? "size-4 animate-spin" : "size-4"} /> Refresh
          </Button>
        </form>

        {error && <p className="text-sm text-destructive">{error}</p>}

        {data && (
          <>
            <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
              <Badge variant={data.state === "present" ? "default" : "outline"}>
                {describeState(data.state, "log")}
              </Badge>
              <span className="font-mono break-all">{data.path}</span>
              {data.size_bytes != null && <span>· {bytes(data.size_bytes)}</span>}
              <span>· {data.returned_lines} shown</span>
            </div>

            {data.note && (
              //the sentence that stops an empty pane from being read as a fact about the gateway
              <HealthStrip tone="warning">{data.note}</HealthStrip>
            )}

            {data.lines.length > 0 && (
              <pre className="max-h-[32rem] overflow-auto rounded-md bg-muted p-3 font-mono text-sm leading-relaxed">
                {data.lines.join("\n")}
              </pre>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}

function Configuration() {
  const [name, setName] = useState<ConfigName>("properties");
  const [data, setData] = useState<GatewayConfigView | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let alive = true;
    setData(null);
    fetch(`/api/control/gateway-config/${name}`, { cache: "no-store" })
      .then(async (res) => {
        const json = await res.json();
        if (!alive) return;
        if (!res.ok) setError(json?.error ?? `Request failed (${res.status})`);
        else {
          setData(json.data as GatewayConfigView);
          setError("");
        }
      })
      .catch((err) => {
        if (alive) setError(err instanceof Error ? err.message : "Request failed");
      });
    return () => {
      alive = false;
    };
  }, [name]);

  return (
    <Card>
      <CardHeader className="flex-row flex-wrap items-center justify-between gap-2 space-y-0">
        <CardTitle className="flex items-center gap-2">
          <FileText className="size-4" /> Configuration in force
        </CardTitle>
        <Select
          className="w-full sm:w-48"
          value={name}
          onChange={(e) => setName(e.target.value as ConfigName)}
        >
          {CONFIG_NAMES.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </Select>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && <p className="text-sm text-destructive">{error}</p>}
        {!error && !data && <p className="text-sm text-muted-foreground">Loading…</p>}

        {data && (
          <>
            <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
              <Badge variant={data.state === "present" ? "default" : "outline"}>
                {describeState(data.state, "config")}
              </Badge>
              <Badge variant="outline">
                {data.source === "database" ? "From database" : "From file"}
              </Badge>
              <span className="font-mono break-all">{data.path}</span>
            </div>

            {data.note && (
              <p className="rounded-md border border-border bg-muted/40 p-3 text-sm">{data.note}</p>
            )}

            {data.content && (
              <pre className="max-h-[32rem] overflow-auto rounded-md bg-muted p-3 font-mono text-sm leading-relaxed">
                {data.content}
              </pre>
            )}

            {data.credentials && (
              <TableInCard>
                <THead>
                  <TR>
                    <TH>Type</TH>
                    <TH>System ID</TH>
                    <TH>Account</TH>
                    <TH>Product</TH>
                    <TH>Secret</TH>
                    <TH>Allowed IPs</TH>
                  </TR>
                </THead>
                <TBody>
                  {data.credentials.map((credential, index) => (
                    <TR key={`${credential.type}-${credential.system_id}-${index}`}>
                      <TD>{credential.type ?? "—"}</TD>
                      <TD className="font-mono">{credential.system_id ?? "—"}</TD>
                      <TD>{credential.account_id ?? "—"}</TD>
                      <TD>{credential.product ?? "—"}</TD>
                      <TD>
                        <Badge variant={credential.secret === "set" ? "default" : "outline"}>
                          {credential.secret}
                        </Badge>
                      </TD>
                      <TD muted>
                        {credential.allowed_ips.length === 0
                          ? "any address"
                          : credential.allowed_ips.join(", ")}
                      </TD>
                    </TR>
                  ))}
                </TBody>
              </TableInCard>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}

function bytes(value: number): string {
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  if (value < 1024 * 1024 * 1024) return `${(value / (1024 * 1024)).toFixed(1)} MB`;
  return `${(value / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}
