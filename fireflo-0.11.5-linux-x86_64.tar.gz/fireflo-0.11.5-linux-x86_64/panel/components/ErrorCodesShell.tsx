"use client";
import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Select } from "@/components/ui/select";
import { workerDefaultKey } from "@/lib/gateway-key-policy";
import { parseErrorCodes, type ErrorCodePair } from "@/lib/error-codes";
import type { Worker } from "@/lib/worker-types";
import { cn } from "@/lib/utils";

/**
 * Both tiers of `dlr.errcodes`, read once for the whole Error codes section.
 *
 * <p>The left column lists the Every vendor list and each SMPP vendor; the right is whichever list
 * is open. Lives in the section's layout, so it stays mounted when an operator moves between lists
 * and the column does not reload on every click. Each editor calls {@link ErrorCodesData.reload}
 * after a save so the column's "Own list" and "Inherits" chips follow.
 */

export const GLOBAL_LIST_KEY = workerDefaultKey("dlr.errcodes");
export const GLOBAL_PASSTHROUGH_KEY = workerDefaultKey("dlr.errcodes.passthrough");

export interface VendorCodes {
  name: string;
  /** The vendor's own `dlr.errcodes`, or null when it inherits the Every vendor list. */
  own: string | null;
  /** How many mappings its own list holds. */
  count: number;
  /** Its own `dlr.errcodes.passthrough`, or null when it follows the Every vendor answer. */
  passthrough: boolean | null;
}

export interface ErrorCodesData {
  loading: boolean;
  error: string | null;
  /** The stored Every vendor list, as written. "" when nothing is stored. */
  globalStored: string;
  globalPairs: ErrorCodePair[];
  /** True only when the Every vendor answer is stored as on; absent is the gateway's default, off. */
  globalPassthrough: boolean;
  /** Whether a passthrough answer is stored for every vendor at all. */
  globalPassthroughSet: boolean;
  vendors: VendorCodes[];
  reload: () => Promise<void>;
}

const Ctx = createContext<ErrorCodesData | null>(null);

export function useErrorCodes(): ErrorCodesData {
  const value = useContext(Ctx);
  if (!value) {
    throw new Error("useErrorCodes is used outside the Error codes layout.");
  }
  return value;
}

const truthy = (v: string | null | undefined) => (v ?? "").trim().toLowerCase() === "true";

export function ErrorCodesShell({ children }: { children: ReactNode }) {
  const [state, setState] = useState<Omit<ErrorCodesData, "reload">>({
    loading: true,
    error: null,
    globalStored: "",
    globalPairs: [],
    globalPassthrough: false,
    globalPassthroughSet: false,
    vendors: [],
  });

  const reload = useCallback(async () => {
    try {
      const [settingsRes, workersRes] = await Promise.all([
        fetch("/api/control/gateway-settings", { cache: "no-store" }),
        fetch("/api/control/workers?type=smppclient", { cache: "no-store" }),
      ]);
      const settings = await settingsRes.json();
      const workers = await workersRes.json();
      if (!settingsRes.ok) throw new Error(settings?.error ?? "Could not read settings.");
      if (!workersRes.ok) throw new Error(workers?.error ?? "Could not read vendors.");

      const globalStored = settings?.data?.[GLOBAL_LIST_KEY]?.value ?? "";
      const passthroughRaw = settings?.data?.[GLOBAL_PASSTHROUGH_KEY]?.value ?? null;
      const vendors = ((workers?.data ?? []) as Worker[])
        .map((w) => {
          //`setWorkerProperty` deletes the row for an empty value, so an absent property IS
          //"inherits" -- kept as null so a list of its own that happens to be empty is not mistaken
          //for none
          const own = w.properties.find((p) => p.key === "dlr.errcodes")?.value ?? null;
          const pass = w.properties.find((p) => p.key === "dlr.errcodes.passthrough")?.value ?? null;
          return {
            name: w.name,
            own,
            count: parseErrorCodes(own).length,
            passthrough: pass === null ? null : truthy(pass),
          };
        })
        .sort((a, b) => a.name.localeCompare(b.name));

      setState({
        loading: false,
        error: null,
        globalStored,
        globalPairs: parseErrorCodes(globalStored),
        globalPassthrough: truthy(passthroughRaw),
        globalPassthroughSet: passthroughRaw !== null && passthroughRaw.trim() !== "",
        vendors,
      });
    } catch (err) {
      setState((prev) => ({
        ...prev,
        loading: false,
        error: err instanceof Error ? err.message : "Could not load error codes.",
      }));
    }
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  const data: ErrorCodesData = { ...state, reload };

  return (
    <Ctx.Provider value={data}>
      <div className="flex flex-wrap items-start gap-6">
        <ErrorCodeLists data={data} />
        <div className="flex min-w-0 flex-[999_1_560px] flex-col gap-5">{children}</div>
      </div>
    </Ctx.Provider>
  );
}

/** The href for a list: the Every vendor list, or one vendor's. */
export function listHref(vendor: string | null): string {
  return vendor === null ? "/cp/error-codes" : `/cp/error-codes/${encodeURIComponent(vendor)}`;
}

function ErrorCodeLists({ data }: { data: ErrorCodesData }) {
  const pathname = usePathname();
  const router = useRouter();
  const activeVendor = pathname.startsWith("/cp/error-codes/")
    ? decodeURIComponent(pathname.slice("/cp/error-codes/".length))
    : null;
  const inheriting = data.vendors.filter((v) => v.own === null).length;

  return (
    <>
      {/* a select on a phone, where a column of links would push the editor below the fold */}
      <label className="flex w-full flex-col gap-1 text-xs text-muted-foreground lg:hidden">
        List
        <Select
          aria-label="Error code list"
          value={activeVendor ?? ""}
          onChange={(e) => router.push(listHref(e.target.value === "" ? null : e.target.value))}
        >
          <option value="">Every vendor</option>
          {data.vendors.map((v) => (
            <option key={v.name} value={v.name}>
              {v.name} — {v.own === null ? "inherits" : `own list, ${v.count}`}
            </option>
          ))}
        </Select>
      </label>

      <nav aria-label="Error code lists" className="hidden flex-[0_0_240px] flex-col gap-1 text-sm lg:sticky lg:top-4 lg:flex">
        <Link
          href={listHref(null)}
          aria-current={activeVendor === null ? "page" : undefined}
          className={cn(
            "flex flex-col rounded-lg px-3 py-2",
            activeVendor === null ? "border border-border bg-card shadow-sm" : "hover:bg-muted"
          )}
        >
          <span className="flex items-center font-semibold text-foreground">
            Every vendor
            <span className="ml-auto pl-2 font-medium tabular-nums text-muted-foreground">
              {data.globalPairs.length}
            </span>
          </span>
          {data.vendors.length > 0 && (
            <span className="text-xs text-muted-foreground">
              used by {inheriting} of {data.vendors.length}
            </span>
          )}
        </Link>

        <div className="px-3 pb-1 pt-4 text-2xs font-bold uppercase tracking-wider text-muted-foreground">
          Vendors
        </div>
        {data.loading && <p className="px-3 text-muted-foreground">Loading…</p>}
        {!data.loading && data.vendors.length === 0 && (
          <p className="px-3 text-muted-foreground">No SMPP vendors yet.</p>
        )}
        {data.vendors.map((v) => {
          const active = activeVendor === v.name;
          return (
            <Link
              key={v.name}
              href={listHref(v.name)}
              aria-current={active ? "page" : undefined}
              className={cn(
                "flex items-center gap-2 rounded-lg px-3 py-2",
                active ? "border border-border bg-card font-semibold shadow-sm" : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              <span className="min-w-0 truncate font-mono text-xs text-foreground">{v.name}</span>
              <span
                className={cn(
                  "ml-auto shrink-0 rounded-full px-2 py-px text-2xs font-medium",
                  v.own === null ? "bg-muted text-muted-foreground" : "bg-primary-soft text-primary"
                )}
              >
                {v.own === null ? "Inherits" : `Own list · ${v.count}`}
              </span>
            </Link>
          );
        })}
        <p className="mt-3 px-3 text-xs text-muted-foreground">
          Inherits means the vendor uses the Every vendor list. A list of its own replaces it.
        </p>
      </nav>
    </>
  );
}
