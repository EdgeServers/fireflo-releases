"use client";
import { Fragment, useState } from "react";
import { ArrowDown, ArrowUp, ChevronDown, ChevronRight, Pencil, Trash2 } from "lucide-react";
import { Pager } from "@/components/Pager";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { ConfirmDialog, useConfirm } from "@/components/ConfirmDialog";
import { WarningNote } from "@/components/FormNotices";
import { usePaging } from "@/components/usePaging";
import { WhitelistReview, pendingFirst } from "@/components/WhitelistReview";
import { parseTlvCsv } from "@/lib/tlv-string";
import type { ApprovalStatus } from "@/lib/whitelist-types";
import { cn } from "@/lib/utils";

/**
 * Table-shaped rather than card-shaped.
 *
 * <p>Was five, when a row was a stack of prose and five filled a card. A table row is one line, so
 * five left more chrome than content. Both lists page at the same size or the page looks broken.
 */
export const PAGE_SIZE = 12;

/**
 * One column of a registration table.
 *
 * <p>Supplied by the caller rather than derived here: a sender ID and a template have different
 * things worth a column, and a union type would put both sets in one place and leave half of them
 * empty on every row.
 */
export interface ListColumn<T> {
  id: string;
  header: string;
  /** A CSS width. Fixed on everything except the one column that should absorb the slack. */
  width?: string;
  align?: "right";
  cell: (row: T) => React.ReactNode;
  /** Absent means the column cannot be sorted — a badge or a stamp list, usually. */
  sortBy?: (row: T) => string | number | boolean | null;
}

/**
 * The row shape both registrations share. Everything the list itself reads.
 *
 * <p>`ApprovedHeader` and `ApprovedTemplate` both satisfy it; the parts they differ by arrive as
 * render props rather than as a union, so adding a third registration would not mean editing this.
 */
export interface RegistrationRow {
  id: number;
  product: string;
  status: ApprovalStatus;
  enabled: boolean;
  tlvs: string | null;
  requestNote: string | null;
  /** The login this is for, or null for every login on the account. */
  systemId: string | null;
}

/**
 * One account's registrations, as a table whose rows open.
 *
 * <p><strong>This was deliberately not a table once</strong>, and the reason was sound at the time:
 * the columns held four things of wildly different widths, only the first had content worth lining
 * up, and spreading them across a card left the withdraw control an entire width from the row it
 * deleted.
 *
 * <p>What changed is the data. The approval workflow added status, who requested it, who reviewed
 * it and which login it belongs to — five columns that genuinely compare across rows, which is the
 * thing a table is for and the thing this list did not have. Sorting by status to find what is
 * waiting is now a real question, and a stack of prose rows cannot answer it.
 *
 * <p>The old objection is answered rather than ignored: <strong>the actions live in a fixed column
 * at the right</strong>, not spread across the width, and the row still opens rather than
 * truncating. Nothing is cut off when it is open, so a 19-digit entity ID and a full template body
 * both have the width they need.
 *
 * <p><strong>Rows with a problem open themselves</strong>, and only those. An operator should not
 * have to click each row to discover which one is misconfigured — but auto-opening healthy rows, or
 * every pending request, would just be the old wall of detail with extra steps. Manual toggling
 * overrides the automatic choice for as long as the page is open.
 */
export function RegistrationList<T extends RegistrationRow>({
  rows,
  query,
  noun,
  busy,
  haystack,
  nameOf,
  columns,
  renderDetail,
  gapsOf,
  deleteTitle,
  deleteConfirmLabel,
  deleteConsequence,
  emptyMessage,
  onEdit,
  onDelete,
  onReview,
}: {
  rows: readonly T[];
  query: string;
  /** Plural, for the pager's count. */
  noun: string;
  /** The busy key from `useWhitelist`, compared against the row id. */
  busy: string;
  haystack: (row: T) => string;
  /** Plain text, for the buttons' accessible names. */
  nameOf: (row: T) => string;
  /** The always-visible part, one entry per column. */
  columns: readonly ListColumn<T>[];
  /** The part behind the disclosure. Null for a row with nothing more to say. */
  renderDetail: (row: T) => React.ReactNode | null;
  /** What this row will fail to deliver, in sentences. Drives the marker and the auto-open. */
  gapsOf: (row: T) => readonly string[];
  deleteTitle: string;
  deleteConfirmLabel: string;
  deleteConsequence: (row: T) => string;
  emptyMessage: React.ReactNode;
  onEdit: (row: T) => void;
  onDelete: (row: T) => Promise<string | null> | void;
  onReview: (row: T, status: "APPROVED" | "REJECTED", note?: string) => void;
}) {
  const needle = query.trim().toLowerCase();
  const matching = needle
    ? rows.filter((row) => haystack(row).toLowerCase().includes(needle))
    : [...rows];
  //pending first by default, because "what is waiting on me" is the question this list is opened
  //with. A clicked header overrides it -- an explicit sort must not be quietly re-sorted
  const [sort, setSort] = useState<{ id: string; dir: "asc" | "desc" } | null>(null);
  const sorted = sort ? bySort(matching, columns, sort) : pendingFirst(matching);
  const ordered = sorted;
  const { page, pages, shown, setPage } = usePaging(ordered, PAGE_SIZE);

  //only what the operator has toggled by hand. Absent means "use the automatic choice", which is
  //what lets a row that gains a problem open itself without fighting an earlier click
  const [toggled, setToggled] = useState<Record<number, boolean>>({});
  const confirm = useConfirm<T>();
  const [failure, setFailure] = useState("");

  //a gap every row has is a fact about the account or the vendor, not about any one row. Repeating
  //it per row opens the whole list and buries the rows that are individually wrong -- so it is
  //hoisted here and said once. Computed over the whole filtered list rather than the page, or
  //turning to page two would change what counts as shared.
  const everyRowsGaps = ordered.map(gapsOf);
  const shared = ordered.length > 1
    ? everyRowsGaps[0].filter((gap) => everyRowsGaps.every((gaps) => gaps.includes(gap)))
    : [];

  if (!rows.length) {
    return <p className="text-xs text-muted-foreground">{emptyMessage}</p>;
  }
  if (!ordered.length) {
    return (
      <p className="text-xs text-muted-foreground">
        Nothing matches “{query.trim()}”. {rows.length} {noun} in total.
      </p>
    );
  }

  return (
    <>
      {shared.length > 0 && (
        <div className="mb-3">
          <WarningNote warnings={[...shared]} />
        </div>
      )}

      <TableInCard>
        <THead>
          <TR>
            {/* the chevron owns a fixed column so every row's first cell starts on one edge */}
            <TH className="w-6" />
            {columns.map((column) => {
              const active = sort?.id === column.id;
              return (
                <TH
                  key={column.id}
                  style={column.width ? { width: column.width } : undefined}
                  align={column.align === "right" ? "right" : undefined}
                  aria-sort={active ? (sort!.dir === "asc" ? "ascending" : "descending") : "none"}
                >
                  {column.sortBy ? (
                    <button
                      type="button"
                      className="inline-flex items-center gap-1 hover:text-foreground"
                      onClick={() => {
                        setSort((s) =>
                          s?.id === column.id
                            ? { id: column.id, dir: s.dir === "asc" ? "desc" : "asc" }
                            : { id: column.id, dir: "asc" });
                        setPage(0);
                      }}
                    >
                      {column.header}
                      {active && (sort!.dir === "asc"
                        ? <ArrowUp className="h-3 w-3" aria-hidden="true" />
                        : <ArrowDown className="h-3 w-3" aria-hidden="true" />)}
                    </button>
                  ) : column.header}
                </TH>
              );
            })}
            <TH className="w-12" />
            {/* the actions column, fixed and at the right. The old list refused to be a table
                partly because a table put the withdraw control a full width from its row; a
                column that never moves is the answer to that, not the absence of a table */}
            <TH align="right" className="w-20">Actions</TH>
          </TR>
        </THead>
        <TBody>
          {shown.map((row) => {
            //what is wrong with THIS row, once what is wrong with all of them has been said above
            const gaps = gapsOf(row).filter((gap) => !shared.includes(gap));
            const detail = renderDetail(row);
            const openable = Boolean(detail) || gaps.length > 0;
            const open = toggled[row.id] ?? (openable && gaps.length > 0);
            const tint = gaps.length ? "bg-amber-500/[0.06]" : undefined;

            return (
              <Fragment key={row.id}>
                {/* the summary row loses its rule while open, so the detail reads as part of it */}
                <TR className={cn(tint, open && "border-0")}>
                  <TD className="align-top">
                    <button
                      type="button"
                      className="text-muted-foreground hover:text-foreground disabled:opacity-0"
                      disabled={!openable}
                      aria-expanded={open}
                      aria-label={`${open ? "Hide" : "Show"} details for ${nameOf(row)}`}
                      onClick={() => setToggled((prev) => ({ ...prev, [row.id]: !open }))}
                    >
                      {open
                        ? <ChevronDown className="h-3.5 w-3.5" />
                        : <ChevronRight className="h-3.5 w-3.5" />}
                    </button>
                  </TD>
                  {columns.map((column, i) => (
                    <TD
                      key={column.id}
                      align={column.align === "right" ? "right" : undefined}
                      className="align-top"
                    >
                      {/*the first cell edits, the affordance this list has always used and the
                         reason Edit is an icon rather than a column of its own*/}
                      {i === 0 ? (
                        <button type="button" className="text-left hover:underline"
                          onClick={() => onEdit(row)}>
                          {column.cell(row)}
                        </button>
                      ) : column.cell(row)}
                    </TD>
                  ))}
                  <TD className="align-top">
                    {gaps.length > 0 && (
                      <span className="whitespace-nowrap text-xs text-amber-600 dark:text-amber-500">
                        {gaps.length} {gaps.length === 1 ? "issue" : "issues"}
                      </span>
                    )}
                  </TD>
                  <TD align="right" className="align-top">
                    <span className="inline-flex items-center gap-2 text-muted-foreground">
                      <button type="button" className="hover:text-foreground"
                        aria-label={`Edit ${nameOf(row)}`} title="Edit"
                        onClick={() => onEdit(row)}>
                        <Pencil className="h-3.5 w-3.5" />
                      </button>
                      {/*the dialog is what actually guards this; the icon only has to be reachable
                         from the row it belongs to, which is the whole point of the fixed column*/}
                      <button type="button" className="hover:text-destructive"
                        aria-label={`Withdraw ${nameOf(row)}`} title="Withdraw"
                        onClick={() => { setFailure(""); confirm.ask(row); }}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </span>
                  </TD>
                </TR>

                {open && (
                  <TR className={cn(tint, "hover:bg-transparent")}>
                    <TD />
                    <TD colSpan={columns.length + 2} className="pt-0">
                      <div className="space-y-2">
                        {detail}

                        {gaps.length > 0 && (
                          <div className="space-y-1">
                            {gaps.map((gap, i) => (
                              <p key={i} className="text-xs leading-relaxed text-amber-600 dark:text-amber-500">
                                {gap}
                              </p>
                            ))}
                          </div>
                        )}

                        <div className="flex flex-wrap items-center gap-x-3.5 gap-y-2 pt-0.5">
                          <WhitelistReview
                            status={row.status}
                            busy={busy === String(row.id)}
                            onDecide={(status, note) => onReview(row, status, note)}
                          />
                        </div>
                      </div>
                    </TD>
                  </TR>
                )}
              </Fragment>
            );
          })}
        </TBody>
      </TableInCard>

      <Pager page={page} pages={pages} total={ordered.length} noun={noun} onPage={setPage} />

      <ConfirmDialog
        open={confirm.pending !== null}
        title={deleteTitle}
        consequence={confirm.pending ? deleteConsequence(confirm.pending) : ""}
        confirmLabel={deleteConfirmLabel}
        busy={Boolean(confirm.pending) && busy === String(confirm.pending?.id)}
        error={failure}
        onConfirm={async () => {
          const row = confirm.pending;
          if (!row) {
            return;
          }
          const problem = await onDelete(row);
          if (problem) {
            setFailure(problem);
            return;
          }
          confirm.dismiss();
        }}
        onCancel={() => { setFailure(""); confirm.dismiss(); }}
      />
    </>
  );
}

/**
 * What the customer has asked the stamps to become, and the two answers to it.
 *
 * <p>Rendered as current-versus-proposed rather than as the proposal alone, because the decision is
 * a comparison: an operator is agreeing that this customer may assert this registration id, and the
 * useful question is what changes. A row with nothing in `tlvs` says so in words rather than showing
 * an empty column.
 *
 * <p><strong>Accepting puts the value on the wire</strong> at the next configuration poll. That is
 * the one thing on this card that changes what a carrier receives, so it says so above the button
 * rather than in a tooltip. Dismissing clears the request and leaves the stamps exactly as they are;
 * it is not a rejection of the registration, and the wording avoids the word.
 */
export function TlvProposal({
  current,
  proposed,
  busy,
  error,
  onDecide,
}: {
  current: string | null;
  proposed: string;
  busy: boolean;
  error?: string;
  onDecide: (accept: boolean) => void;
}) {
  return (
    <div className="space-y-1.5 rounded-md border border-primary/40 bg-primary/[0.04] p-2.5">
      <p className="text-xs uppercase tracking-wide text-muted-foreground">
        The customer has asked for these stamps
      </p>
      <div className="space-y-1">
        <div>
          <span className="text-xs text-muted-foreground">now </span>
          {current ? <StampList tlvs={current} /> : (
            <span className="text-xs text-muted-foreground">nothing — this stamps no TLVs</span>
          )}
        </div>
        <div>
          <span className="text-xs text-muted-foreground">asked </span>
          <StampList tlvs={proposed} />
        </div>
      </div>
      <p className="text-xs leading-relaxed text-muted-foreground">
        Accepting sends these on every message using this registration, from the next configuration
        poll. Nothing has changed yet — the gateway has never read what is above.
      </p>
      <div className="flex flex-wrap items-center gap-x-3.5 gap-y-1 pt-0.5">
        <button type="button" disabled={busy}
          className="text-xs text-primary hover:underline disabled:opacity-50"
          onClick={() => onDecide(true)}>
          Accept these stamps
        </button>
        <button type="button" disabled={busy}
          className="text-xs text-muted-foreground hover:underline disabled:opacity-50"
          onClick={() => onDecide(false)}>
          Dismiss the request
        </button>
      </div>
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}

/**
 * Which login a registration is for, or nothing at all when it is for every one of them.
 *
 * <p>Rendered only where it says something. On an account whose rows are all account-wide -- which
 * is every account until somebody scopes one -- this is silent, because a badge repeating "all" on
 * every row is a column with one value in it.
 *
 * <p>The caller decides that, not this: it has the whole list and can see whether any row is bound.
 */
export function LoginBadge({ systemId }: { systemId: string | null }) {
  if (!systemId) {
    return (
      <span className="text-xs text-muted-foreground" title="Applies to every login on the account">
        all logins
      </span>
    );
  }
  return (
    <span className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs text-foreground/80"
      title={`Only messages from ${systemId}`}>
      {systemId}
    </span>
  );
}

/**
 * The stamps a registration attaches, one `name = value` per line.
 *
 * <p>Rendered as pairs rather than as the stored comma-joined string, because that string is what an
 * operator has to read character by character to notice that `PEID=…` — no underscore, so no tag —
 * is being discarded by the gateway. Split, they line up.
 */
export function StampList({ tlvs }: { tlvs: string | null }) {
  const pairs = parseTlvCsv(tlvs);
  if (!pairs.length) {
    return null;
  }
  return (
    <span className="flex flex-wrap gap-x-4 gap-y-0.5">
      {pairs.map((pair, i) => (
        <span key={i} className="font-mono text-xs text-muted-foreground">
          {pair.key} <span className="text-muted-foreground/60">=</span>{" "}
          <span className="text-foreground/80">{pair.value || "—"}</span>
        </span>
      ))}
    </span>
  );
}

/**
 * Orders rows by a clicked column.
 *
 * <p>Its own function rather than `sortRows` from `lib/table-columns`: that one reads a `from`
 * accessor off a `TableColumn`, and these columns carry a `cell` that returns JSX. Sorting on
 * rendered output would order by markup.
 *
 * <p>Nulls last in both directions, matching `sortRows` — `systemId` is null on most rows and a
 * naive compare would file every "all logins" row at one end and call that an ordering.
 */
function bySort<T>(
  rows: readonly T[],
  columns: readonly ListColumn<T>[],
  sort: { id: string; dir: "asc" | "desc" }
): T[] {
  const column = columns.find((c) => c.id === sort.id);
  if (!column?.sortBy) {
    return [...rows];
  }
  const read = column.sortBy;
  const sign = sort.dir === "asc" ? 1 : -1;
  return [...rows].sort((a, b) => {
    const left = read(a);
    const right = read(b);
    if (left === null && right === null) return 0;
    if (left === null) return 1;
    if (right === null) return -1;
    if (typeof left === "number" && typeof right === "number") return (left - right) * sign;
    return String(left).localeCompare(String(right), undefined, { numeric: true }) * sign;
  });
}
