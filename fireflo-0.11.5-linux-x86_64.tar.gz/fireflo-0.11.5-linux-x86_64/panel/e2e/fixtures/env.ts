/**
 * The suite's environment, read once from e2e/.env.e2e (then the process environment, which wins).
 *
 * Everything the rig needs is a value here so that a fixture never reads `process.env` directly;
 * the capability list is what `tc()` consults to turn a missing piece of rig into a Blocked result
 * rather than a failure that reads as a product defect.
 */
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";

export type Capability =
  | "gateway"   // a gateway answers /ops (mode A or a configured E2E_GATEWAY_OPS_URL)
  | "edgesmsc"  // the suite spawned EdgeSmsc A/B and can kill/control them (mode A only)
  | "trace"     // the gateway's smsg.log and auth-failed.log are readable
  | "cli"       // scripts/fireflo from E2E_GATEWAY_REPO can be run against the e2e database
  | "restart"   // the suite may stop and restart the gateway with different config (mode A only)
  | "variants"  // `next start` variants of the panel with different env can be started
  | "smtp";     // the local SMTP sinks are up (always in-process, so always true once setup ran)

export interface E2EEnv {
  root: string;               // fireflo-control-panel/
  runDir: string;             // e2e/.run
  databaseUrl: string;
  panelPort: number;
  panelUrl: string;
  operator: { username: string; password: string };
  authSecret: string;
  tester: string;
  startGateway: boolean;
  gatewayRepo: string | null;
  gatewayBin: string | null;
  gatewayOpsUrl: string;
  gatewayApiUrl: string;
  smppHost: string;
  smppPort: number;
  smppPort2: number;
  smppProxyPort: number;
  opsReadToken: string;
  opsAdminToken: string;
  edgeA: { port: number; control: number };
  edgeB: { port: number; control: number };
  smtpTlsPort: number;
  smtpPlainPort: number;
  panelVariants: boolean;
  loadScale: number;
  gatewayLog: string | null;
}

function loadDotEnv(file: string): Record<string, string> {
  if (!existsSync(file)) return {};
  const out: Record<string, string> = {};
  for (const raw of readFileSync(file, "utf8").split("\n")) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    const eq = line.indexOf("=");
    if (eq < 0) continue;
    out[line.slice(0, eq).trim()] = line.slice(eq + 1).trim().replace(/^"(.*)"$/, "$1");
  }
  return out;
}

let cached: E2EEnv | null = null;

export function e2eEnv(): E2EEnv {
  if (cached) return cached;
  const root = path.resolve(__dirname, "..", "..");
  const file = loadDotEnv(path.join(root, "e2e", ".env.e2e"));
  const get = (k: string, dflt?: string): string => {
    const v = process.env[k] ?? file[k] ?? dflt;
    if (v === undefined) throw new Error(`e2e: ${k} is not set (copy e2e/.env.e2e.example to e2e/.env.e2e)`);
    return v;
  };
  const num = (k: string, dflt: string) => Number.parseInt(get(k, dflt), 10);
  const databaseUrl = get("E2E_DATABASE_URL");
  const dbName = new URL(databaseUrl).pathname.replace(/^\//, "");
  if (!/e2e/i.test(dbName)) {
    throw new Error(`e2e: refusing E2E_DATABASE_URL — database '${dbName}' does not contain "e2e" and setup truncates every table`);
  }
  const startGateway = get("E2E_START_GATEWAY", "1") === "1";
  const opsPort = num("E2E_GATEWAY_OPS_PORT", "9100");
  const httpPort = num("E2E_GATEWAY_HTTP_PORT", "8100");
  const panelPort = num("E2E_PANEL_PORT", "3100");
  const repo = get("E2E_GATEWAY_REPO", "");
  const bin = get("E2E_GATEWAY_BIN", "");
  cached = {
    root,
    runDir: path.join(root, "e2e", ".run"),
    databaseUrl,
    panelPort,
    // `localhost`, not 127.0.0.1: `next dev` serves its client bundles and HMR socket only to its own
    // origin (allowedDevOrigins), and a page reached by IP is served as HTML that never hydrates
    panelUrl: `http://localhost:${panelPort}`,
    operator: { username: get("E2E_OPERATOR_USERNAME", "qa-operator@control.local"), password: get("E2E_OPERATOR_PASSWORD") },
    authSecret: get("E2E_AUTH_SECRET"),
    tester: get("E2E_TESTER", "playwright"),
    startGateway,
    gatewayRepo: repo ? path.resolve(root, repo) : null,
    gatewayBin: bin ? path.resolve(root, bin) : null,
    gatewayOpsUrl: startGateway ? `http://127.0.0.1:${opsPort}` : get("E2E_GATEWAY_OPS_URL", ""),
    gatewayApiUrl: startGateway ? `http://127.0.0.1:${httpPort}` : get("E2E_GATEWAY_API_URL", ""),
    smppHost: startGateway ? "127.0.0.1" : get("E2E_SMPP_HOST", "127.0.0.1"),
    smppPort: num("E2E_SMPP_PORT", "27800"),
    smppPort2: num("E2E_SMPP_PORT_2", "27801"),
    smppProxyPort: num("E2E_SMPP_PROXY_PORT", "27802"),
    opsReadToken: get("E2E_OPS_READ_TOKEN", "e2e-read-token"),
    opsAdminToken: get("E2E_OPS_ADMIN_TOKEN", "e2e-admin-token"),
    edgeA: { port: num("E2E_EDGE_A_PORT", "28800"), control: num("E2E_EDGE_A_CONTROL", "29800") },
    edgeB: { port: num("E2E_EDGE_B_PORT", "28801"), control: num("E2E_EDGE_B_CONTROL", "29801") },
    smtpTlsPort: num("E2E_SMTP_TLS_PORT", "4465"),
    smtpPlainPort: num("E2E_SMTP_PLAIN_PORT", "4587"),
    panelVariants: get("E2E_PANEL_VARIANTS", "1") === "1",
    loadScale: Number.parseFloat(get("E2E_LOAD_SCALE", "0.1")),
    gatewayLog: startGateway ? null : get("E2E_GATEWAY_LOG", "") || null,
  };
  return cached;
}

/**
 * What this run can do. Read from the environment, not from a probe, so a test's skip reason is
 * stable across the run and the catalog check can print the blocked count before anything starts.
 */
export function capabilities(env: E2EEnv = e2eEnv()): Set<Capability> {
  const caps = new Set<Capability>(["smtp"]);
  // what setup actually managed to start is in state.json; a gateway configured but down, or a
  // variant build that failed, must read as Blocked rather than as a run of connection errors
  let gatewayUp = false;
  let panelBuilt = false;
  try {
    const f = path.join(env.runDir, "state.json");
    if (existsSync(f)) {
      const s = JSON.parse(readFileSync(f, "utf8")) as { gatewayUp?: boolean; panelBuilt?: boolean };
      gatewayUp = !!s.gatewayUp;
      panelBuilt = !!s.panelBuilt;
    }
  } catch { /* no state yet: a listing */ }
  if (gatewayUp) caps.add("gateway");
  if (env.startGateway && gatewayUp) { caps.add("edgesmsc"); caps.add("trace"); caps.add("restart"); }
  if (!env.startGateway && env.gatewayLog) caps.add("trace");
  if (env.gatewayRepo) caps.add("cli");
  if (env.panelVariants && panelBuilt) caps.add("variants");
  return caps;
}
