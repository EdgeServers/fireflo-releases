/**
 * EP-23 Customer Portal — Reseller
 * US-23.02 Credit transfers and billing from the portal
 *
 * A transfer is a ledger row the gateway's poll applies; the panel never moves money. The cases
 * that wait for the poll need the gateway; the refusals and the currency rules do not.
 */
import { randomUUID } from "node:crypto";
import { expect, test } from "../../fixtures";
import { BASELINE } from "../../fixtures/seed";
import { tc } from "../../support/tc";

async function freshPair(db: import("../../fixtures").Db, seed: import("../../fixtures").Seed) {
  // a reseller of the test's own so balances start from a known figure
  const reseller = await seed.account({ label: "QA reseller", resells: true, email: `${seed.prefix}r-${Date.now().toString(36)}@fireflo.test` });
  const child = await seed.account({ label: "QA child", parentAccountId: reseller, email: `${seed.prefix}c-${Date.now().toString(36)}@fireflo.test` });
  await seed.balance({ accountId: reseller, balance: 10_000_000 }); // 1000.0000
  await seed.balance({ accountId: child, balance: 0 });
  seed.cleanup(async () => { await db.q("DELETE FROM balance_ledger WHERE account_id = ANY($1) OR counterparty_account_id = ANY($1)", [[reseller, child]]).catch(() => undefined); });
  return { reseller, child };
}

// in the order asked for. It used to sort by account id, and seeded ids are random, so whether the
// child or the reseller came first was a coin toss -- every expectation below lists the child first
const balances = (db: import("../../fixtures").Db, ids: string[]) =>
  db.q<{ account_id: string; balance: string; reserved: string }>("SELECT account_id, balance::text, reserved::text FROM account_balance WHERE account_id = ANY($1) ORDER BY array_position($1::text[], account_id)", [ids]);

test.describe("SC-23.02.01 Transfer down and up", () => {
  test(...tc("TC-23.02.01-P01", "Down applies on the poll", { requires: ["gateway"] }), async ({ portalApi, db, seed, tcx }) => {
    const { reseller, child } = await freshPair(db, seed);
    const api = await portalApi(reseller);
    const res = await api.post("/api/mis/transfer", { data: { accountId: child, amount: "250.0000", direction: "down", ref: `xfer:${randomUUID()}` } });
    expect(res.status(), await res.text()).toBe(200);
    const row = await db.one<{ applied: boolean; delta: string }>("SELECT applied, delta::text FROM balance_ledger WHERE entry_type = 'TRANSFER' AND account_id = $1 AND counterparty_account_id = $2 ORDER BY id DESC LIMIT 1", [reseller, child]);
    expect(row.delta).toBe("2500000");
    await db.waitForRow("SELECT 1 FROM balance_ledger WHERE entry_type = 'TRANSFER' AND account_id = $1 AND counterparty_account_id = $2 AND applied", [reseller, child], { timeoutMs: 45_000 });
    const after = await balances(db, [child, reseller]);
    expect(after.map((b) => Number(b.balance) + Number(b.reserved))).toEqual([2_500_000, 7_500_000]);
    tcx.note(`queued (applied=${row.applied}) then applied: R 750.0000 / child 250.0000`);
  });

  test(...tc("TC-23.02.01-P02", "Up reverses", { requires: ["gateway"] }), async ({ portalApi, db, seed, tcx }) => {
    const { reseller, child } = await freshPair(db, seed);
    await seed.balance({ accountId: child, balance: 2_500_000 });
    const api = await portalApi(reseller);
    const res = await api.post("/api/mis/transfer", { data: { accountId: child, amount: "100.0000", direction: "up", ref: `xfer:${randomUUID()}` } });
    expect(res.status(), await res.text()).toBe(200);
    await db.waitForRow("SELECT 1 FROM balance_ledger WHERE entry_type = 'TRANSFER' AND account_id = $1 AND counterparty_account_id = $2 AND applied", [child, reseller], { timeoutMs: 45_000 });
    const after = await balances(db, [child, reseller]);
    expect(after.map((b) => Number(b.balance) + Number(b.reserved))).toEqual([1_500_000, 11_000_000]);
    tcx.note("child 150.0000 / R 1100.0000 after the pull");
  });

  test(...tc("TC-23.02.01-N01", "Insufficient stays pending", { requires: ["gateway"] }), async ({ portalApi, db, seed, tcx }) => {
    const { reseller, child } = await freshPair(db, seed);
    const api = await portalApi(reseller);
    const res = await api.post("/api/mis/transfer", { data: { accountId: child, amount: "5000.0000", direction: "down", ref: `xfer:${randomUUID()}` } });
    expect(res.status(), await res.text()).toBe(200);
    await new Promise((r) => setTimeout(r, 8000)); // more than two recharge polls
    const row = await db.one<{ applied: boolean }>("SELECT applied FROM balance_ledger WHERE entry_type = 'TRANSFER' AND account_id = $1 AND counterparty_account_id = $2 ORDER BY id DESC LIMIT 1", [reseller, child]);
    expect(row.applied, "left pending, never applied").toBe(false);
    const after = await balances(db, [child, reseller]);
    expect(after.map((b) => Number(b.balance) + Number(b.reserved))).toEqual([0, 10_000_000]);
    tcx.note("5000.0000 against 1000.0000: row pending, both balances unchanged");
  });

  test(...tc("TC-23.02.01-N02", "RECHARGE path is refused on the portal"), async ({ portalApi, db, seed, tcx }) => {
    const { reseller, child } = await freshPair(db, seed);
    const api = await portalApi(reseller);
    const before = await db.count("balance_ledger", "account_id = $1", [child]);
    const res = await api.post(`/api/mis/accounts/${child}/balance`, { data: { action: "topUp", amount: "100.0000" } });
    expect(res.status()).toBe(400);
    expect(await res.text()).toMatch(/transfer/i);
    expect(await db.count("balance_ledger", "account_id = $1", [child])).toBe(before);
    tcx.note(`topUp → ${res.status()} naming the transfer; no ledger row`);
  });

  test(...tc("TC-23.02.01-P03", "Currency inherited from parent when gateway is silent"), async ({ portalApi, db, seed, tcx }) => {
    // Since gateway V1.60.0 a platform holds one currency, so the parent cannot be in a second one to
    // make the inheritance visible (this used to give it NZD beside the baseline's AUD balances, which
    // the database now refuses). The context says where the currency came from instead: "parent".
    await seed.config("smsg.rates.currency", null);
    const reseller = await seed.account({ label: "QA currency reseller", resells: true, email: `${seed.prefix}cur-${Date.now().toString(36)}@fireflo.test` });
    const child = await seed.account({ label: "QA currency child", parentAccountId: reseller });
    await seed.balance({ accountId: reseller, balance: 1_000_000, currency: BASELINE.currency });
    seed.cleanup(async () => { await db.q("DELETE FROM account_balance WHERE account_id = $1", [child]); });
    const api = await portalApi(reseller);
    const ctx = await api.get(`/api/mis/accounts/${child}/context`);
    expect(ctx.status()).toBe(200);
    const body = await ctx.json() as { data?: { currencyForNewBalance?: { code: string | null; from: string | null } } };
    expect(body.data?.currencyForNewBalance).toEqual({ code: BASELINE.currency, from: "parent" });
    const res = await api.post(`/api/mis/accounts/${child}/balance`, { data: { action: "open" } });
    expect(res.status(), await res.text()).toBe(200);
    const row = await db.one<{ currency: string }>("SELECT currency FROM account_balance WHERE account_id = $1", [child]);
    expect(row.currency).toBe(BASELINE.currency);
    tcx.note(`gateway currency unset → context offers ${BASELINE.currency} from parent; opened balance is ${BASELINE.currency}`);
  });

  test(...tc("TC-23.02.01-N03", "Body currency is ignored"), async ({ portalApi, db, seed, tcx }) => {
    const { reseller } = await freshPair(db, seed);
    const child = await seed.account({ label: "QA XXX child", parentAccountId: reseller });
    seed.cleanup(async () => { await db.q("DELETE FROM account_balance WHERE account_id = $1", [child]); });
    const api = await portalApi(reseller);
    const res = await api.post(`/api/mis/accounts/${child}/balance`, { data: { action: "open", currency: "XXX" } });
    const row = await db.maybe<{ currency: string }>("SELECT currency FROM account_balance WHERE account_id = $1", [child]);
    expect(row?.currency ?? null, "XXX is never written").not.toBe("XXX");
    if (row) expect(row.currency).toBe(BASELINE.currency);
    tcx.note(`open with currency XXX → ${res.status()}; row ${row ? `currency ${row.currency}` : "not opened"}`);
  });
});
