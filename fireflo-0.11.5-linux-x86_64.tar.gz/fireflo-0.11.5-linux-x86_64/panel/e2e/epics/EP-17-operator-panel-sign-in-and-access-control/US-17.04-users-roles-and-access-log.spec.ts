/**
 * EP-17 Operator Panel — Sign-in & Access Control
 * US-17.04 Users, roles and the access log
 */
import { expect, test } from "../../fixtures";
import { freshRequestContext, operatorSignIn } from "../../fixtures/auth";
import { panelLog } from "../../support/panel-logs";
import { BASELINE } from "../../fixtures/seed";
import { mailbox } from "../../fixtures/sinks";
import { tc } from "../../support/tc";

const STRONG = "Tr0ub4dor&3x-horse-staple";
const STRONGER = "correct horse battery staple 2026";

async function adminId(operatorApi: Parameters<typeof test>[1] extends never ? never : { get: (url: string) => Promise<{ json: () => Promise<unknown> }> }, email: string): Promise<number> {
  const res = await operatorApi.get("/api/control/users");
  const json = (await res.json()) as { data: { users: { id: number; email: string }[] } };
  const me = json.data.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (!me) throw new Error(`the signed-in admin ${email} is not in the user list`);
  return me.id;
}

test.describe("SC-17.04.01 Admin manages users", () => {
  test(...tc("TC-17.04.01-P01", "Admin creates an operator who can run the gateway but not see users"), async ({ operatorApi, env, db, tcx }) => {
    const email = `qa-op-${Date.now().toString(36)}@fireflo.test`;
    const created = await operatorApi.post("/api/control/users", { data: { email, role: "operator", password: STRONG } });
    expect(created.status(), await created.text()).toBe(200);
    const row = await db.one<{ role: string; account_id: string | null; password_hash: string }>(
      "SELECT role, account_id, password_hash FROM app_user WHERE lower(email) = lower($1)", [email]);
    expect(row.role).toBe("operator");
    expect(row.account_id).toBeNull();
    expect(row.password_hash, "stored as a PBKDF2 string, never the password").toMatch(/^\$pbkdf2-sha256\$\d+\$/);
    expect(row.password_hash).not.toContain(STRONG);

    const ctx = await freshRequestContext();
    const signedIn = await operatorSignIn(ctx, { username: email, password: STRONG });
    expect(signedIn.signedIn, "the new operator signs in").toBe(true);
    // the catalogue, not /health: health asks the gateway, which the suite may be running without
    const reach = await ctx.get("/api/control/accounts/catalogue");
    expect(reach.status(), "an operator reaches the control routes").toBe(200);
    const users = await ctx.get("/api/control/users");
    expect(users.status(), "but the user list answers 404, as to an anonymous caller").toBe(404);
    const page = await ctx.get("/cp/users");
    expect(page.status(), "and the page is a 404 too").toBe(404);
    await ctx.dispose();

    const audit = await db.one<{ n: string }>(
      "SELECT count(*) AS n FROM app_operator_access_log WHERE event = 'user_created' AND detail->>'subject' = $1 AND actor = $2",
      [email, env.operator.username]);
    expect(Number(audit.n), "user_created is in the database log, naming the admin and the subject").toBe(1);
    tcx.note(`${email} created by ${env.operator.username}; health 200, users 404`);
  });

  test(...tc("TC-17.04.01-P02", "Admin resets a password; the old one stops working at the next sign-in"), async ({ operatorApi, db, tcx }) => {
    const email = `qa-reset-${Date.now().toString(36)}@fireflo.test`;
    const created = await operatorApi.post("/api/control/users", { data: { email, role: "operator", password: STRONG } });
    const { data: { user } } = (await created.json()) as { data: { user: { id: number } } };
    const reset = await operatorApi.post(`/api/control/users/${user.id}/password`, { data: { password: STRONGER } });
    expect(reset.status(), await reset.text()).toBe(200);

    const ctx = await freshRequestContext();
    expect((await operatorSignIn(ctx, { username: email, password: STRONG })).signedIn, "old password refused").toBe(false);
    expect((await operatorSignIn(ctx, { username: email, password: STRONGER })).signedIn, "new password accepted").toBe(true);
    await ctx.dispose();

    const rows = await db.q<{ event: string }>(
      "SELECT event FROM app_operator_access_log WHERE (detail->>'subject' = $1) OR (actor = $1) ORDER BY id", [email]);
    const events = rows.map((r) => r.event);
    expect(events).toContain("user_password_set");
    expect(events).toContain("signin_failed");
    expect(events).toContain("signin");
    tcx.note(`events for ${email}: ${events.join(", ")}`);
  });

  test(...tc("TC-17.04.01-P03", "A disabled operator's next request is refused although the cookie is valid"), async ({ operatorApi, tcx }) => {
    const email = `qa-disable-${Date.now().toString(36)}@fireflo.test`;
    const created = await operatorApi.post("/api/control/users", { data: { email, role: "operator", password: STRONG } });
    const { data: { user } } = (await created.json()) as { data: { user: { id: number } } };
    const ctx = await freshRequestContext();
    expect((await operatorSignIn(ctx, { username: email, password: STRONG })).signedIn).toBe(true);
    expect((await ctx.get("/api/control/accounts/catalogue")).status()).toBe(200);

    const patched = await operatorApi.patch(`/api/control/users/${user.id}`, { data: { enabled: false } });
    expect(patched.status(), await patched.text()).toBe(200);
    expect((await ctx.get("/api/control/accounts/catalogue")).status(), "same cookie, next request, 404").toBe(404);
    expect((await operatorSignIn(await freshRequestContext(), { username: email, password: STRONG })).signedIn, "and cannot sign in again").toBe(false);
    await ctx.dispose();
    tcx.note(`${email} disabled mid-session; next call 404`);
  });

  test(...tc("TC-17.04.01-N01", "A weak password is refused by the server with the policy's sentence"), async ({ operatorApi, tcx }) => {
    const email = `qa-weak-${Date.now().toString(36)}@fireflo.test`;
    for (const weak of ["short1!", "password1234", email]) {
      const res = await operatorApi.post("/api/control/users", { data: { email, role: "operator", password: weak } });
      expect(res.status(), weak).toBe(400);
      const { error } = (await res.json()) as { error: string };
      expect(error, weak).toMatch(/at least 12|too easy to guess/);
    }
    tcx.note("7 chars, a top-list password and the user's own address all refused");
  });

  test(...tc("TC-17.04.01-N02", "The last enabled admin cannot be disabled or demoted, nor an admin demote themself"), async ({ operatorApi, env, db, tcx }) => {
    const me = await adminId(operatorApi, env.operator.username);
    const admins = await db.one<{ n: string }>("SELECT count(*) AS n FROM app_user WHERE role = 'admin' AND enabled");
    const self = await operatorApi.patch(`/api/control/users/${me}`, { data: { role: "operator" } });
    expect(self.status(), "self-demotion").toBe(400);
    const off = await operatorApi.patch(`/api/control/users/${me}`, { data: { enabled: false } });
    expect(off.status(), "self-disable").toBe(400);
    const still = await db.one<{ role: string; enabled: boolean }>("SELECT role, enabled FROM app_user WHERE id = $1", [me]);
    expect(still).toEqual({ role: "admin", enabled: true });
    tcx.note(`${admins.n} enabled admin(s); both refusals 400, row unchanged`);
  });

  test(...tc("TC-17.04.01-P04", "An operator changes their own password with the current one; a wrong current is refused"), async ({ operatorApi, tcx }) => {
    const email = `qa-self-${Date.now().toString(36)}@fireflo.test`;
    await operatorApi.post("/api/control/users", { data: { email, role: "operator", password: STRONG } });
    const ctx = await freshRequestContext();
    expect((await operatorSignIn(ctx, { username: email, password: STRONG })).signedIn).toBe(true);
    const wrong = await ctx.post("/api/control/me/password", { data: { current: "not-it-not-it-1", next: STRONGER } });
    expect(wrong.status()).toBe(400);
    const ok = await ctx.post("/api/control/me/password", { data: { current: STRONG, next: STRONGER } });
    expect(ok.status(), await ok.text()).toBe(200);
    await ctx.dispose();
    expect((await operatorSignIn(await freshRequestContext(), { username: email, password: STRONGER })).signedIn).toBe(true);
    tcx.note("wrong current 400; change 200; new password signs in");
  });
});

test.describe("SC-17.04.02 Failed sign-ins and access are visible in the panel", () => {
  test(...tc("TC-17.04.02-P01", "A refused sign-in is a row in the database log and a line in the fail2ban file"), async ({ operatorApi, env, db, tcx }) => {
    const triedAs = `qa-audit-${Date.now().toString(36)}@fireflo.test`;
    const since = panelLog.mark();
    const ctx = await freshRequestContext();
    expect((await operatorSignIn(ctx, { username: triedAs, password: "whatever-it-is-1" })).signedIn).toBe(false);
    await ctx.dispose();

    await expect.poll(async () => Number((await db.one<{ n: string }>(
      "SELECT count(*) AS n FROM app_operator_access_log WHERE event = 'signin_failed' AND actor = $1", [triedAs])).n)).toBe(1);
    await panelLog.waitOperator(since, (l) => l.event === "signin_failed" && l.actor === triedAs);
    expect(panelLog.authFailed(since).filter((l) => l.triedAs === triedAs).length, "fail2ban still sees it").toBe(1);

    const viaApi = await operatorApi.get(`/api/control/audit/operator?failures=1&actor=${encodeURIComponent(triedAs)}`);
    expect(viaApi.status()).toBe(200);
    const { data } = (await viaApi.json()) as { data: { rows: { event: string; actor: string; ip: string | null }[] } };
    expect(data.rows.length).toBe(1);
    expect(data.rows[0]).toMatchObject({ event: "signin_failed", actor: triedAs });
    expect(data.rows[0].ip, "the row names the peer address").toBeTruthy();

    const summary = await operatorApi.get("/api/control/audit/signins?days=1");
    const { data: s } = (await summary.json()) as { data: { rows: { surface: string; failed: number }[] } };
    expect(s.rows.some((r) => r.surface === "panel" && r.failed >= 1), "the Security card counts it").toBe(true);
    tcx.note(`${triedAs}: 1 db row, 1 auth-failed line, visible via /audit/operator and /audit/signins; admin ${env.operator.username}`);
  });

  test(...tc("TC-17.04.02-P02", "A customer's link activity appears on the account's access log, with the user it belongs to"), async ({ operatorApi, db, tcx }) => {
    const account = BASELINE.accounts.portal;
    const user = await db.one<{ id: string }>("SELECT id FROM app_user WHERE account_id = $1 AND role = 'customer' ORDER BY id LIMIT 1", [account]);
    await db.q(
      "INSERT INTO app_customer_access_log (event, account_id, user_id, email, ip) VALUES ('link_requested', $1, $2, 'qa@fireflo.test', '127.0.0.1')",
      [account, Number(user.id)]);
    const res = await operatorApi.get(`/api/control/audit/portal?account=${account}&event=link_requested&limit=5`);
    expect(res.status()).toBe(200);
    const { data } = (await res.json()) as { data: { rows: { accountId: string; userId: number | null; event: string }[] } };
    expect(data.rows.length).toBeGreaterThan(0);
    expect(data.rows[0]).toMatchObject({ accountId: account, event: "link_requested", userId: Number(user.id) });
    tcx.note(`portal log for ${account}: ${data.rows.length} link_requested row(s), user ${user.id}`);
  });

  test(...tc("TC-17.04.02-N01", "An operator may read the portal log but not the operator log"), async ({ operatorApi, tcx }) => {
    const email = `qa-reader-${Date.now().toString(36)}@fireflo.test`;
    await operatorApi.post("/api/control/users", { data: { email, role: "operator", password: STRONG } });
    const ctx = await freshRequestContext();
    expect((await operatorSignIn(ctx, { username: email, password: STRONG })).signedIn).toBe(true);
    expect((await ctx.get("/api/control/audit/portal?limit=1")).status(), "customers' log: support work").toBe(200);
    expect((await ctx.get("/api/control/audit/operator?limit=1")).status(), "operators' log: admin only").toBe(404);
    await ctx.dispose();
    tcx.note("portal 200, operator 404 for a plain operator");
  });
});

test.describe("SC-17.04.03 One-time link for operators", () => {
  test(...tc("TC-17.04.03-P01", "An operator signs in by emailed link; a customer's link does not open the panel"), async ({ operatorApi, anonPage, anonContext, db, tcx }) => {
    const email = `qa-link-${Date.now().toString(36)}@fireflo.test`;
    await operatorApi.post("/api/control/users", { data: { email, role: "operator", password: STRONG } });

    const since = mailbox.mark();
    const ask = await anonContext.request.post("/api/auth/login-link", { data: { username: email } });
    expect(ask.status()).toBe(200);
    const link = await mailbox.signInLink(since, email);
    expect(link, "the link lands on the operator panel's own page").toMatch(/\/cp\/link\?token=/);

    // the same neutral answer for a name that is nobody's, and nothing in the inbox for it
    const nobody = `qa-nobody-${Date.now().toString(36)}@fireflo.test`;
    const askNobody = await anonContext.request.post("/api/auth/login-link", { data: { username: nobody } });
    expect(await askNobody.json()).toEqual(await ask.json());

    await anonPage.goto(link);
    await anonPage.getByRole("button", { name: "Sign in" }).click();
    await anonPage.waitForURL(/\/cp(\/|$|\?)/, { timeout: 15_000 });
    await expect(anonPage).not.toHaveURL(/\/cp\/login|\/cp\/link/);
    const session = (await (await anonContext.request.get("/api/auth/session")).json()) as { user?: { name?: string; role?: string } };
    expect(session.user?.name).toBe(email);
    expect(session.user?.role).toBe("operator");

    // once only
    const again = await anonContext.request.post("/api/auth/callback/magic-link", {
      form: { csrfToken: (await (await anonContext.request.get("/api/auth/csrf")).json()).csrfToken, token: new URL(link).searchParams.get("token")!, redirect: "false" },
      headers: { "X-Auth-Return-Redirect": "1" },
    });
    expect(((await again.json()) as { url?: string }).url ?? "").toMatch(/error=/);

    // a customer's token is not an operator's: issued for the portal, refused at this door, and left unspent
    const customerToken = await (await import("../../fixtures/auth")).issueLoginTokenFor(db, BASELINE.accounts.portal);
    const cross = await anonContext.request.post("/api/auth/callback/magic-link", {
      form: { csrfToken: (await (await anonContext.request.get("/api/auth/csrf")).json()).csrfToken, token: customerToken, redirect: "false" },
      headers: { "X-Auth-Return-Redirect": "1" },
    });
    expect(((await cross.json()) as { url?: string }).url ?? "").toMatch(/error=/);
    const hash = (await import("node:crypto")).createHash("sha256").update(customerToken).digest("hex");
    expect((await db.one<{ used_at: string | null }>("SELECT used_at FROM app_login_token WHERE token_hash = $1", [hash])).used_at, "left unspent for the portal").toBeNull();

    const events = (await db.q<{ event: string }>("SELECT event FROM app_operator_access_log WHERE actor = $1 ORDER BY id", [email])).map((r) => r.event);
    expect(events).toContain("link_requested");
    expect(events).toContain("link_redeemed");
    tcx.note(`${email}: link mailed, redeemed once, replay refused, customer token refused and unspent; events ${events.join(",")}`);
  });
});
