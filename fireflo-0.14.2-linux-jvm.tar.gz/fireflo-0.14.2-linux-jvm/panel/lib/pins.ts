/**
 * The pages an operator pins to the top bar, like bookmarks.
 *
 * <p>Kept in this browser's `localStorage` (per operator, per browser; nothing on the server). At
 * most {@link MAX_PINS}: the bar has room for four tabs beside the jump box. A pin is a path only --
 * the operator's choice: filters are the Messages page's own memory, not the pin's.
 *
 * <p>Pure, so the rules are tested without a browser: what survives a mangled entry, which pin a
 * fifth one replaces, and that only operator pages can be pinned.
 */

export interface Pin {
  href: string;
  label: string;
  /** When it was pinned, ms since the epoch; the defaults carry 0, so they are the first to go. */
  pinnedAt: number;
}

export const PINS_KEY = "fireflo.pins";
export const MAX_PINS = 4;
const MAX_LABEL = 40;

/** The bar before anyone pins anything: the four pages an operator opens most. */
export const DEFAULT_PINS: Pin[] = [
  { href: "/cp/cdrs", label: "Messages", pinnedAt: 0 },
  { href: "/cp/vendors", label: "Vendors", pinnedAt: 0 },
  { href: "/cp/servers", label: "Servers", pinnedAt: 0 },
  { href: "/cp/accounts", label: "Accounts", pinnedAt: 0 },
];

/** An operator page's path, without query or fragment; anything else is not pinnable. */
export function pinnablePath(href: string): string | null {
  const path = href.split(/[?#]/)[0];
  return /^\/cp(\/[\w.~%-]+)*\/?$/.test(path) && !path.startsWith("//") ? path.replace(/\/$/, "") || null : null;
}

function cleanLabel(label: string): string {
  const text = label.replace(/\s+/g, " ").trim();
  return text.length > MAX_LABEL ? `${text.slice(0, MAX_LABEL - 1)}…` : text;
}

/**
 * What `localStorage` holds, made safe: no entry means the defaults; a mangled one, or one that
 * names pages outside the operator panel, is cut down to what is valid rather than trusted.
 */
export function readPins(raw: string | null): Pin[] {
  if (raw == null) {
    return DEFAULT_PINS;
  }
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      return DEFAULT_PINS;
    }
    const pins: Pin[] = [];
    for (const item of parsed) {
      if (!item || typeof item !== "object") {
        continue;
      }
      const { href, label, pinnedAt } = item as Record<string, unknown>;
      const path = typeof href === "string" ? pinnablePath(href) : null;
      const text = typeof label === "string" ? cleanLabel(label) : "";
      if (!path || !text || pins.some((p) => p.href === path)) {
        continue;
      }
      pins.push({ href: path, label: text, pinnedAt: typeof pinnedAt === "number" && Number.isFinite(pinnedAt) ? pinnedAt : 0 });
    }
    return pins.slice(0, MAX_PINS);
  } catch {
    return DEFAULT_PINS;
  }
}

/**
 * Pin or unpin a page. A page already pinned is unpinned; a fifth one replaces the pin made longest
 * ago (the defaults first), and says which so the bar's change is never silent.
 */
export function togglePin(
  pins: Pin[],
  page: { href: string; label: string },
  now: number
): { pins: Pin[]; dropped: Pin | null } {
  const path = pinnablePath(page.href);
  const label = cleanLabel(page.label);
  if (!path || !label) {
    return { pins, dropped: null };
  }
  if (pins.some((p) => p.href === path)) {
    return { pins: pins.filter((p) => p.href !== path), dropped: null };
  }
  let kept = pins;
  let dropped: Pin | null = null;
  if (pins.length >= MAX_PINS) {
    dropped = pins.reduce((oldest, p) => (p.pinnedAt < oldest.pinnedAt ? p : oldest));
    kept = pins.filter((p) => p !== dropped);
  }
  return { pins: [...kept, { href: path, label, pinnedAt: now }], dropped };
}

/** Whether `pathname` is the pinned page itself (a pin is a page, not a section). */
export function isPinnedPath(pins: Pin[], pathname: string): boolean {
  const path = pinnablePath(pathname);
  return !!path && pins.some((p) => p.href === path);
}
