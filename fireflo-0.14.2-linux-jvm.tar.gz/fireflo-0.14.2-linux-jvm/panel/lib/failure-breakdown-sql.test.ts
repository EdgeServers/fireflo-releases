import { strict as assert } from "node:assert";
import { test } from "node:test";

import { failureBreakdownHourlySql, failureWindowStartSql } from "./failure-breakdown-sql.ts";

const sql = failureBreakdownHourlySql(true);

test("whole hours come from the summary, only the edges from the records", () => {
  //the timeout this exists for was a read of every message in the window
  assert.match(sql, /FROM usage_failure_hourly h, cut\s+WHERE h\.hour >= cut\.first_hour AND h\.hour < cut\.seam/);
  assert.match(sql, /c\.submitted_at >= cut\.seam AND c\.submitted_at < cut\.until/);
});

test("the edges are driven from the non-delivered receipts, never from every message", () => {
  assert.match(sql, /f\.final_at >= cut\.edge_lo AND f\.final_state <> 'DELIVERED'/);
  assert.match(sql, /FROM cdr_submit c JOIN bad USING \(gateway_msg_id\)/);
  assert.doesNotMatch(sql, /JOIN LATERAL/, "a per-message lookup is what timed out");
});

test("the window starts at the top of the hour since falls in, and never before the summary", () => {
  assert.match(sql, /GREATEST\(date_trunc\('hour', b\.since AT TIME ZONE 'UTC'\) AT TIME ZONE 'UTC',\s+\(SELECT min\(hour\) FROM usage_failure_hourly\)\) AS first_hour/);
  assert.match(failureWindowStartSql(), /SELECT shown_since AS since FROM cut/);
});

test("the watermark is clamped into the window, so a stale or future one cannot double count", () => {
  assert.match(sql, /LEAST\(GREATEST\(\$3::timestamptz, b\.since\), b\.until\) AS seam/);
});

test("the summary's sentinels read back as no receipt state and no error code", () => {
  assert.match(sql, /NULLIF\(h\.dlr_state, -1\), NULLIF\(h\.err_code, ''\)/);
});

test("a real receipt outranks a swept EXPIRED, as everywhere else", () => {
  assert.match(sql, /ORDER BY f\.gateway_msg_id, \(f\.final_state = 'EXPIRED'\), f\.final_at/);
});

test("failures are kept per account, from the records and from the summary alike", () => {
  assert.match(sql, /SELECT DISTINCT ON \(c\.gateway_msg_id\) c\.gateway_msg_id, c\.submitted_at, c\.account_id/);
  assert.match(sql, /NULLIF\(h\.err_code, ''\), h\.account_id/);
  assert.match(sql, /GROUP BY 1, 2, 3, 4\s+ORDER BY 5 DESC/);
});

test("with the summary the window is the whole range, not the last day", () => {
  assert.match(sql, /SELECT \$1::timestamptz AS since, \$2::timestamptz AS until/);
  assert.doesNotMatch(sql, /interval '24 hours'/);
});

test("a range reaching back before the summary starts where the summary does, and never reads the gap", () => {
  //a month of non-delivered receipts took 31 s on .101 when the summary began mid-range
  assert.match(sql, /c\.first_hour AS shown_since/);
  assert.match(sql, /c\.seam AS edge_lo/);
  assert.doesNotMatch(sql, /c\.submitted_at >= cut\.since/);
});
