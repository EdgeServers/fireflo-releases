import { test } from "node:test";
import assert from "node:assert/strict";
import { resolveAudience } from "./stats-audience.ts";

class Refused extends Error {}

const yes = async () => "session";
const no = async () => {
  throw new Refused();
};
const isRefusal = (err: unknown) => err instanceof Refused;

test("a customer alias answers a portal session even with an operator session beside it", async () => {
  assert.equal(await resolveAudience("customer", yes, yes, isRefusal), "customer");
});

test("an operator alias answers an operator session even with a portal session beside it", async () => {
  assert.equal(await resolveAudience("operator", yes, yes, isRefusal), "operator");
});

test("an alias does not widen to the other audience", async () => {
  assert.equal(await resolveAudience("customer", yes, no, isRefusal), null);
  assert.equal(await resolveAudience("operator", no, yes, isRefusal), null);
});

test("the unscoped route tries the operator first, then the customer", async () => {
  assert.equal(await resolveAudience(undefined, yes, yes, isRefusal), "operator");
  assert.equal(await resolveAudience(undefined, no, yes, isRefusal), "customer");
  assert.equal(await resolveAudience(undefined, no, no, isRefusal), null);
});

test("a customer-only alias never asks for the operator session", async () => {
  let asked = false;
  const operator = async () => {
    asked = true;
    return "session";
  };
  await resolveAudience("customer", operator, yes, isRefusal);
  assert.equal(asked, false);
});

test("a failure that is not a refusal is thrown, not read as no session", async () => {
  const broken = async () => {
    throw new Error("database down");
  };
  await assert.rejects(resolveAudience(undefined, broken, yes, isRefusal), /database down/);
  await assert.rejects(resolveAudience("customer", yes, broken, isRefusal), /database down/);
});
