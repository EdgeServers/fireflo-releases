import { test } from "node:test";
import assert from "node:assert/strict";
import { StatsCache, StillReadingError, statsKey, ttlFor } from "./stats-cache.ts";

function clock(start = 0) {
  let t = start;
  return { now: () => t, advance: (ms: number) => { t += ms; } };
}

test("an answer is kept for its period's time; past it the old one is served while a new one is read", async () => {
  const c = clock();
  const cache = new StatsCache(64, c.now);
  let runs = 0;
  const run = async () => ++runs;
  assert.equal((await cache.get("k", ttlFor("30d"), run)).value, 1);
  c.advance(4 * 60_000);
  assert.equal((await cache.get("k", ttlFor("30d"), run)).value, 1, "a month view is kept 5 min");
  assert.equal(runs, 1);
  c.advance(2 * 60_000);
  //expired: answered at once with what is kept, while the fresh read runs behind it
  assert.equal((await cache.get("k", ttlFor("30d"), run)).value, 1);
  await new Promise((r) => setImmediate(r));
  assert.equal(runs, 2);
  assert.equal((await cache.get("k", ttlFor("30d"), run)).value, 2);
  assert.equal(ttlFor("1h"), 30_000);
  assert.equal(ttlFor("24h"), 60_000);
});

test("callers arriving while a read runs share it: two tabs, one statement", async () => {
  const cache = new StatsCache();
  let runs = 0;
  let release!: () => void;
  const gate = new Promise<void>((r) => { release = r; });
  const run = async () => { runs++; await gate; return "answer"; };
  const a = cache.get("k", 30_000, run);
  const b = cache.get("k", 30_000, run);
  release();
  assert.deepEqual([(await a).value, (await b).value], ["answer", "answer"]);
  assert.equal(runs, 1);
});

test("a refresh that fails leaves the last good answer, marked stale; a first read that fails is the caller's", async () => {
  const c = clock();
  const cache = new StatsCache(64, c.now);
  await cache.get("k", 30_000, async () => "good");
  c.advance(60_000);
  const timeout = async () => { throw new Error("canceling statement due to statement timeout"); };
  assert.equal((await cache.get("k", 30_000, timeout)).value, "good");
  await new Promise((r) => setImmediate(r));
  const served = await cache.get("k", 30_000, timeout);
  assert.equal(served.value, "good");
  assert.equal(served.at, 0);
  assert.match(served.stale!.reason, /statement timeout/);
  await assert.rejects(cache.get("other", 30_000, async () => { throw new Error("boom"); }), /boom/);
});

test("a first read past the wait says it is still reading, and fills the cache when it lands", async () => {
  const cache = new StatsCache();
  let release!: () => void;
  const gate = new Promise<void>((r) => { release = r; });
  const slow = async () => { await gate; return "month"; };
  await assert.rejects(cache.get("k", 60_000, slow, { waitMs: 5 }), StillReadingError);
  release();
  await new Promise((r) => setTimeout(r, 5));
  assert.equal((await cache.get("k", 60_000, slow, { waitMs: 5 })).value, "month");
});

test("at most three reads at once; the fourth waits its turn", async () => {
  const cache = new StatsCache(64, Date.now, 3);
  let active = 0;
  let peak = 0;
  const run = async () => {
    active++;
    peak = Math.max(peak, active);
    await new Promise((r) => setTimeout(r, 5));
    active--;
    return 1;
  };
  await Promise.all(["a", "b", "c", "d", "e"].map((k) => cache.get(k, 60_000, run)));
  assert.equal(peak, 3);
});

test("bounded: the least recently used goes first", async () => {
  const cache = new StatsCache(2);
  let runs = 0;
  const run = async () => ++runs;
  await cache.get("a", 60_000, run);
  await cache.get("b", 60_000, run);
  await cache.get("a", 60_000, run); //a is now the most recent
  await cache.get("c", 60_000, run); //drops b
  const before = runs;
  await cache.get("a", 60_000, run);
  assert.equal(runs, before, "a was kept");
  await cache.get("b", 60_000, run);
  assert.equal(runs, before + 1, "b was dropped and read again");
});

test("keys: a customer's scope is part of it, the order of parameters is not", () => {
  const p = (q: string) => new URLSearchParams(q);
  assert.equal(
    statsKey({ who: "operator", metric: "usage", range: "7d", params: p("b=2&a=1&range=7d") }),
    statsKey({ who: "operator", metric: "usage", range: "7d", params: p("a=1&b=2&fresh=1") })
  );
  assert.notEqual(
    statsKey({ who: "customer", metric: "accounts", range: "7d", params: p(""), scope: ["acme"] }),
    statsKey({ who: "customer", metric: "accounts", range: "7d", params: p(""), scope: ["globex"] })
  );
});
