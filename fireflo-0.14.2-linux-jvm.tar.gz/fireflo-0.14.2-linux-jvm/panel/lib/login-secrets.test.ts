import { strict as assert } from "node:assert";
import { test } from "node:test";

import { SMPP_PASSWORD_MAX, SMPP_SYSTEM_ID_MAX, smppPassword, smppSystemId } from "./login-secrets.ts";

test("a generated system id is 8 lower-case letters or digits", () => {
  for (let i = 0; i < 200; i++) {
    assert.match(smppSystemId(), /^[a-z0-9]{8}$/);
  }
});

test("a generated password fits the SMPP field: 8 characters, none easily misread", () => {
  for (let i = 0; i < 200; i++) {
    const password = smppPassword();
    assert.equal(password.length, SMPP_PASSWORD_MAX);
    assert.doesNotMatch(password, /[0O1lI]/);
  }
});

test("the protocol's limits are 15 and 8", () => {
  //16 and 9 octets on the wire, each with its terminator
  assert.equal(SMPP_SYSTEM_ID_MAX, 15);
  assert.equal(SMPP_PASSWORD_MAX, 8);
});

test("generated values differ", () => {
  assert.notEqual(smppSystemId(), smppSystemId());
  assert.notEqual(smppPassword(), smppPassword());
});
