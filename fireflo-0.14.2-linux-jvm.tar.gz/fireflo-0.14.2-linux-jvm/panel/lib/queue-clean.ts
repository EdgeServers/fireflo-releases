/**
 * Cleaning a gateway queue from the panel: the selector, the request the gateway is sent, how its
 * answer is read, the confirmation an operator must type, and when the batch loop stops.
 *
 * <p>Pure and client-safe — no `pg`, no server import — so the dialog, the proxy route and the tests
 * share one copy. The gateway call itself is in `housekeeping-ops.ts`.
 *
 * <p><strong>Every field name the gateway's housekeeping field speaks is spelled here and nowhere
 * else</strong> (`housekeeping(store, input)`, admin token): the request in
 * {@link housekeepingBody}, the answer in {@link readHousekeepingResult}. A rename on that side is a
 * change to this file.
 *
 * <p>What a clean does is the gateway's, identical whichever surface ran it: each matched message is
 * archived first (one committed transaction), then ended — refunded if charged, a failed receipt
 * where the customer asked for one, recorded as REJECTED with reason `operatorPurge`. Receipts and
 * callback retries carry no money and are archived and removed. Nothing is restorable.
 */

/** The stores the endpoint takes, as path segments, and the sub-stores each holds. */
export const CLEAN_STORES = {
  worker: ["pending", "retry", "held", "parked"],
  routing: ["router", "retry", "failed"],
  receipts: [],
  callbacks: [],
} as const satisfies Record<string, readonly string[]>;

export type CleanStore = keyof typeof CLEAN_STORES;

export function isCleanStore(value: unknown): value is CleanStore {
  return typeof value === "string" && Object.prototype.hasOwnProperty.call(CLEAN_STORES, value);
}

export const SUB_STORE_LABEL: Record<string, string> = {
  pending: "Waiting to send",
  retry: "Scheduled retries",
  held: "Held (stopped sending)",
  parked: "Parked inbound (listener)",
  router: "Waiting to be routed",
  failed: "Failed routing",
};

/** The most one call may archive. The gateway's own cap; the dialog loops in batches of this. */
export const BATCH_LIMIT = 10_000;

/** What the operator chose. Strings, as the form holds them. */
export interface CleanSelector {
  store: CleanStore;
  subStore: string;
  /** A vendor (`smppclient.<n>`) or a listener (`smppserver.<n>`). */
  worker: string;
  account: string;
  systemId: string;
  /** `90s`, `30m`, `2h`, `3d`, or empty for any age. */
  olderThan: string;
  /** Explicitly every account and every worker — the gateway refuses an unscoped clean without it. */
  all: boolean;
}

export const EMPTY_SELECTOR: CleanSelector = {
  store: "worker",
  subStore: "",
  worker: "",
  account: "",
  systemId: "",
  olderThan: "",
  all: false,
};

const UNITS: Record<string, number> = { s: 1, m: 60, h: 3_600, d: 86_400 };

/**
 * `2h` → 7200. Empty is "any age" (null). Anything else is a sentence, because a typo silently read
 * as "any age" would archive the newest messages along with the old.
 */
export function parseOlderThan(text: string): number | null | { error: string } {
  const t = text.trim().toLowerCase();
  if (!t) {
    return null;
  }
  const m = /^(\d+)\s*([smhd])$/.exec(t);
  if (!m) {
    return { error: "Older than takes a number and a unit: 90s, 30m, 2h or 3d." };
  }
  const seconds = Number(m[1]) * UNITS[m[2]];
  if (!Number.isSafeInteger(seconds) || seconds <= 0) {
    return { error: "Older than must be more than zero." };
  }
  return seconds;
}

/** The sentence that stops a selector being sent, or null when it may go. */
export function selectorProblem(sel: CleanSelector): string | null {
  if (!isCleanStore(sel.store)) {
    return "Choose what to clean.";
  }
  const subs: readonly string[] = CLEAN_STORES[sel.store];
  if (sel.subStore && !subs.includes(sel.subStore)) {
    return `'${sel.subStore}' is not part of ${sel.store}.`;
  }
  const older = parseOlderThan(sel.olderThan);
  if (older && typeof older === "object") {
    return older.error;
  }
  for (const [label, value] of [["Vendor or listener", sel.worker], ["Account", sel.account], ["System id", sel.systemId]] as const) {
    if (/\s/.test(value.trim())) {
      return `${label}: no spaces — the gateway matches exactly what you enter.`;
    }
  }
  const scoped = !!(sel.worker.trim() || sel.account.trim() || sel.systemId.trim());
  if (sel.store === "receipts" && !sel.systemId.trim() && !sel.account.trim()) {
    return "Unpushed receipts are cleaned per login or per account: enter a system id or an account.";
  }
  if ((sel.store === "worker" || sel.store === "routing") && !scoped && !sel.all) {
    return "Name a vendor, listener, account or login — or tick Every account to clean the whole store.";
  }
  return null;
}

/** The request body the gateway takes. Empty selector fields are left out, never sent as "". */
export interface HousekeepingRequest {
  subStore?: string;
  worker?: string;
  account?: string;
  systemId?: string;
  olderThanSeconds?: number;
  limit: number;
  dryRun: boolean;
  all?: boolean;
  note?: string;
  actor?: string;
}

export function housekeepingBody(
  sel: CleanSelector,
  opts: { dryRun: boolean; limit?: number; note?: string; actor?: string }
): HousekeepingRequest {
  const body: HousekeepingRequest = {
    limit: Math.min(Math.max(1, Math.floor(opts.limit ?? BATCH_LIMIT)), BATCH_LIMIT),
    dryRun: opts.dryRun,
  };
  if (sel.subStore) body.subStore = sel.subStore;
  if (sel.worker.trim()) body.worker = sel.worker.trim();
  if (sel.account.trim()) body.account = sel.account.trim();
  if (sel.systemId.trim()) body.systemId = sel.systemId.trim();
  const older = parseOlderThan(sel.olderThan);
  if (typeof older === "number") body.olderThanSeconds = older;
  if (sel.all) body.all = true;
  if (opts.note?.trim()) body.note = opts.note.trim();
  if (opts.actor) body.actor = opts.actor;
  return body;
}

/** One matched entry from the answer's `sample`, read tolerantly (see {@link readHousekeepingResult}). */
export interface CleanSample {
  serial: string | null;
  account: string | null;
  worker: string | null;
  subStore: string | null;
  systemId: string | null;
  from: string | null;
  to: string | null;
  queuedAt: string | null;
  retries: number | null;
  parts: number | null;
  price: string | null;
}

export interface HousekeepingResult {
  batchId: string | null;
  dryRun: boolean;
  matched: number;
  archived: number;
  refunded: number;
  receiptsSent: number;
  failed: unknown[];
  /** Matches per worker and per account. */
  byWorker: Record<string, number>;
  byAccount: Record<string, number>;
  /**
   * The money a run refunds or would refund, as the gateway states it, or null when the answer does
   * not carry one. Never computed here from a sample: a partial sum presented as the total is worse
   * than none.
   */
  refundTotal: string | null;
  sample: CleanSample[];
  more: boolean;
}

type Raw = Record<string, unknown>;

const str = (v: unknown): string | null => (v == null || v === "" ? null : String(v));
const int = (v: unknown): number => (typeof v === "number" ? v : Number(v ?? 0)) || 0;
const pick = (r: Raw, ...keys: string[]): unknown => {
  for (const k of keys) {
    if (r[k] !== undefined && r[k] !== null) return r[k];
  }
  return undefined;
};

/**
 * A count map that may come as `{acme: 3}` or `{acme: {count: 3, refund: "0.03"}}`; the refunds of
 * the second shape are summed into `refund` when every entry has one.
 */
function readCounts(v: unknown): { counts: Record<string, number>; refund: number | null } {
  const counts: Record<string, number> = {};
  let refund: number | null = 0;
  if (v && typeof v === "object" && !Array.isArray(v)) {
    for (const [key, value] of Object.entries(v as Raw)) {
      if (value && typeof value === "object") {
        const o = value as Raw;
        counts[key] = int(pick(o, "count", "matched", "messages", "n"));
        const r = pick(o, "refund", "refundTotal", "amount");
        refund = refund != null && r != null && Number.isFinite(Number(r)) ? refund + Number(r) : null;
      } else {
        counts[key] = int(value);
        refund = null;
      }
    }
  }
  return { counts, refund: Object.keys(counts).length ? refund : null };
}

function readSample(v: unknown): CleanSample {
  const r = (v && typeof v === "object" ? v : {}) as Raw;
  const retries = pick(r, "retries");
  const parts = pick(r, "parts");
  return {
    serial: str(pick(r, "serial", "gatewayMsgId", "gateway_msg_id", "msg_id", "msgId")),
    account: str(pick(r, "account", "accountId", "account_id")),
    worker: str(pick(r, "worker", "target")),
    subStore: str(pick(r, "subStore", "sub_store")),
    systemId: str(pick(r, "systemId", "system_id")),
    from: str(pick(r, "from", "sourceAddr", "source_addr")),
    to: str(pick(r, "to", "destAddr", "dest_addr")),
    queuedAt: str(pick(r, "queuedAt", "queued_at", "createdAt", "created_at")),
    retries: retries == null ? null : int(retries),
    parts: parts == null ? null : int(parts),
    price: str(pick(r, "price")),
  };
}

/**
 * The gateway's answer, as the panel uses it. Tolerant of what the plan leaves open — the shape of a
 * sample entry, whether per-account entries carry refunds — and strict about what it fixes: the
 * counts are numbers, `more` is a boolean, `failed` is a list.
 */
export function readHousekeepingResult(raw: unknown): HousekeepingResult {
  const r = (raw && typeof raw === "object" ? raw : {}) as Raw;
  const byWorker = readCounts(r.byWorker);
  const byAccount = readCounts(r.byAccount);
  const stated = pick(r, "refundTotal", "refundAmount", "refundedAmount");
  const refundTotal = stated != null ? String(stated) : byAccount.refund != null ? trimNumber(byAccount.refund) : null;
  return {
    batchId: str(r.batchId),
    dryRun: r.dryRun === true,
    matched: int(r.matched),
    archived: int(r.archived),
    refunded: int(r.refunded),
    receiptsSent: int(r.receiptsSent),
    failed: Array.isArray(r.failed) ? r.failed : [],
    byWorker: byWorker.counts,
    byAccount: byAccount.counts,
    refundTotal,
    sample: Array.isArray(r.sample) ? r.sample.map(readSample) : [],
    more: r.more === true,
  };
}

function trimNumber(n: number): string {
  return Number.isInteger(n) ? String(n) : n.toFixed(4).replace(/0+$/, "").replace(/\.$/, "");
}

/** Whether a store holds money: worker and routing queues hold messages; receipts and callbacks do not. */
export function holdsMessages(store: CleanStore): boolean {
  return store === "worker" || store === "routing";
}

/** The noun for what a store holds, singular or plural. */
export function noun(store: CleanStore, n: number): string {
  const one = n === 1;
  if (store === "receipts") return one ? "receipt" : "receipts";
  if (store === "callbacks") return one ? "callback retry" : "callback retries";
  return one ? "message" : "messages";
}

/** The one-line dry-run reading above the table: `12 match · 3 accounts · refund 0.12`. */
export function matchSummary(store: CleanStore, dry: HousekeepingResult): string {
  const accounts = Object.keys(dry.byAccount).length;
  const parts = [`${dry.matched.toLocaleString()} match`, `${accounts} account${accounts === 1 ? "" : "s"}`];
  if (holdsMessages(store)) {
    parts.push(dry.refundTotal != null ? `refund ${dry.refundTotal}` : "refund total not reported");
  }
  return parts.join(" · ");
}

/** What the operator types to confirm. The number is the count they are agreeing to, nothing else. */
export function confirmationPhrase(n: number): string {
  return `CLEAN ${n}`;
}

/** Whether the typed text confirms exactly `n`. Surrounding spaces forgiven; case and number are not. */
export function confirms(typed: string, n: number): boolean {
  return n > 0 && typed.trim() === confirmationPhrase(n);
}

/** The consequence, restated in the dialog before anything happens. */
export function confirmationSentence(store: CleanStore, n: number, dry: HousekeepingResult): string {
  const accounts = Object.keys(dry.byAccount).length;
  const what = `${n.toLocaleString()} ${noun(store, n)}`;
  if (!holdsMessages(store)) {
    return (
      `Archive and remove ${what}? They carry no money and are recorded in the archive, `
      + "then removed from the gateway. This cannot be undone."
    );
  }
  const refund = dry.refundTotal != null ? `refunds ${dry.refundTotal}` : "refunds whatever was charged";
  return (
    `Archive and end ${what}? This ${refund} to ${accounts} account${accounts === 1 ? "" : "s"}; `
    + "sends a failed receipt where one was asked for; records each as REJECTED (operatorPurge); "
    + "and cannot be undone."
  );
}

/** Why the batch loop stopped. */
export type StopReason =
  /** The gateway said nothing more matches. */
  | "finished"
  /** As many as were confirmed have been archived; more may match now, and need a new confirmation. */
  | "confirmed-reached"
  /** A batch archived nothing: stop rather than ask again forever. */
  | "no-progress"
  /** The gateway reported entries it could not archive or close out. */
  | "failed"
  /** The operator pressed Stop; the batch in flight finished first. */
  | "cancelled";

export interface LoopState {
  /** The count the operator typed. The loop never archives more than this. */
  confirmed: number;
  archived: number;
  refunded: number;
  receiptsSent: number;
  failed: unknown[];
  batchIds: string[];
  calls: number;
  stopped: StopReason | null;
}

export function startLoop(confirmed: number): LoopState {
  return { confirmed, archived: 0, refunded: 0, receiptsSent: 0, failed: [], batchIds: [], calls: 0, stopped: null };
}

/** The next batch's limit: the gateway's cap, or what is left of the confirmed count if smaller. */
export function nextLimit(state: LoopState): number {
  return Math.max(0, Math.min(BATCH_LIMIT, state.confirmed - state.archived));
}

/**
 * Folds one executed batch into the running totals and decides whether to go on.
 *
 * <p>The order of the checks is the policy: failures stop first (somebody should look before more
 * is ended), then the confirmed count, then the gateway's own `more`, then a batch that made no
 * progress — which would otherwise be asked again forever.
 */
export function applyBatch(state: LoopState, result: HousekeepingResult): LoopState {
  const next: LoopState = {
    ...state,
    archived: state.archived + result.archived,
    refunded: state.refunded + result.refunded,
    receiptsSent: state.receiptsSent + result.receiptsSent,
    failed: [...state.failed, ...result.failed],
    batchIds: result.batchId ? [...state.batchIds, result.batchId] : state.batchIds,
    calls: state.calls + 1,
    stopped: null,
  };
  if (result.failed.length > 0) {
    next.stopped = "failed";
  } else if (next.archived >= next.confirmed) {
    next.stopped = "confirmed-reached";
  } else if (!result.more) {
    next.stopped = "finished";
  } else if (result.archived === 0) {
    next.stopped = "no-progress";
  }
  return next;
}

/**
 * Before the first batch: the count is read again. If it moved since the operator confirmed, the
 * dialog shows the new number and asks again rather than archiving what was not agreed to.
 */
export function recheck(confirmed: number, fresh: HousekeepingResult): { ok: true } | { ok: false; matched: number } {
  return fresh.matched === confirmed ? { ok: true } : { ok: false, matched: fresh.matched };
}

export function stopSentence(state: LoopState, store: CleanStore): string {
  const done = `${state.archived.toLocaleString()} ${noun(store, state.archived)} archived`;
  switch (state.stopped) {
    case "finished":
      return `${done}. Nothing more matches.`;
    case "confirmed-reached":
      return `${done} — the number confirmed. If more match now, check again and confirm the new number.`;
    case "no-progress":
      return `${done}. The last batch archived nothing, so the run stopped; check again before retrying.`;
    case "failed":
      return `${done}. The gateway reported ${state.failed.length} it could not archive; the run stopped so you can look.`;
    case "cancelled":
      return `${done}. Stopped at your request after the batch in flight.`;
    default:
      return done;
  }
}

/** Where a batch's entries are on Reports → Archives. */
export function batchHref(batchId: string): string {
  return `/cp/archives?tab=entries&range=all&batch=${encodeURIComponent(batchId)}`;
}
