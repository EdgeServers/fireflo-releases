/**
 * The gateway's GraphQL operator API: one place that knows the URL, the two tokens, the envelope
 * and what each refusal means.
 *
 * <p>Gateway 0.13 replaced the REST `/ops/*` family on its management port (9000 by default) with
 * one endpoint, `POST {GATEWAY_OPS_URL}/graphql`. The transport is small and fixed:
 *
 * <ul>
 *   <li>request: `{ query, operationName?, variables? }`, bearer token in `Authorization`;</li>
 *   <li>HTTP 200 once authenticated, body `{ data, errors? }`;</li>
 *   <li>HTTP 404 `{"message":"Not found"}` for a wrong or missing token, a caller outside the ops
 *       allow-list -- and for a 0.12.x gateway, which has no `/graphql` at all;</li>
 *   <li>a field refused for the token's level, or gated by a lapsed licence, answers 200 with
 *       `errors[0] = { message, path: [field], extensions: { code, status } }` and `data: null`
 *       (the root fields are non-null, so the whole `data` goes).</li>
 * </ul>
 *
 * <p>The codes: NOT_FOUND 404, BAD_REQUEST 400, CONFLICT 409, LICENCE_LAPSED 402,
 * LICENCE_REFUSED 402, INTERNAL 500.
 *
 * <h2>Why this file imports nothing from Next</h2>
 *
 * <p>`lib/*.test.ts` run under plain `node --test`, which resolves `next/server` strictly and does
 * not find it. Everything that can be unit tested -- the envelope, the error mapping, the 404
 * probe, the file decode -- lives here and answers plain values; `lib/gateway-graphql.ts` is the
 * thin layer that turns those into `NextResponse`s for the routes. Server-only all the same: the
 * tokens come from the process environment and must never reach a browser.
 */

import { opsUrlResolver } from "./gateway-ops-urls.ts";

/**
 * `admin` for anything that changes what the gateway is doing, `read` for everything else.
 *
 * <p>The two secrets grant disjoint sets: the admin token does not imply read. A field asked with
 * the wrong one answers NOT_FOUND inside the envelope rather than HTTP 404, which is how a wrong
 * token level is told apart from a wrong token.
 */
export type GqlAuth = "read" | "admin";

export interface GqlCall {
  /** The whole document, from `lib/gateway-queries.ts`. One root field per document. */
  query: string;
  variables?: Record<string, unknown>;
  /** Only needed when the document holds more than one operation, which none of ours do. */
  operationName?: string;
  auth?: GqlAuth;
  timeoutMs?: number;
  /**
   * Forward the gateway's own status and sentence instead of flattening it to a 502.
   *
   * <p>Off by default, and that default is right for nearly everything: a refusal is normally a
   * fault in the request this panel built, and an operator is better served by "could not reach
   * the gateway" than by a protocol complaint they cannot act on.
   *
   * <p>Licensing is the exception. A 402 there is a <strong>product outcome</strong> addressed to
   * the operator -- "that licence key is not one we issued", "this licence belongs to a different
   * installation" -- and flattening it would throw away the only part of the answer that tells them
   * what to do next.
   */
  passErrors?: boolean;
}

/** What went wrong, in the gateway's own terms. Thrown by {@link gqlData}. */
export class GatewayError extends Error {
  /** The HTTP status this would carry if the route forwarded it: 402 for a licence, 503 for no token. */
  readonly status: number;
  /** The gateway's code (`LICENCE_LAPSED`, `NOT_FOUND`, ...) or one of this panel's own. */
  readonly code: string;

  constructor(status: number, code: string, message: string) {
    super(message);
    this.name = "GatewayError";
    this.status = status;
    this.code = code;
  }
}

/** The outcome of one call, before anything is turned into an HTTP response. */
export type GqlFailure = { ok: false; status: number; code: string; error: string };
export type GqlOutcome<T> = { ok: true; data: T } | GqlFailure;

/** How the gateway carries a download inside JSON. */
export interface FileResult {
  filename: string;
  contentType: string;
  bytesBase64: string;
  size: number;
}

export const READ_TOKEN_HELP =
  "GATEWAY_OPS_URL and GATEWAY_OPS_TOKEN must both be set to reach the gateway's operational port.";

export const ADMIN_TOKEN_HELP =
  "GATEWAY_OPS_URL and GATEWAY_OPS_ADMIN_TOKEN must both be set to control the gateway. The admin "
  + "token is deliberately separate from the read-only one, and must match smsg.ops.admin.token.";

export const BASE_URL_HELP =
  "The panel does not know the gateway's main port, so it cannot read the gateway's metrics: since "
  + "gateway 0.13 /q/metrics is served there, behind the ops read token. Add "
  + "GATEWAY_BASE_URL=http://127.0.0.1:<the gateway's QUARKUS_HTTP_PORT> to the panel's panel.env "
  + "and restart the panel, or run fireflo-panel-install update, which writes it.";

/** The sentence for a management port that answers 404 to /graphql but 200 to /ops/health. */
export const GATEWAY_TOO_OLD =
  "This gateway is 0.12.x and answers /ops only; the panel 0.13 needs gateway 0.13 or newer.";

/** This panel's own codes, for an outcome the gateway never produced. */
export const PANEL_CODES = {
  notConfigured: "NOT_CONFIGURED",
  unreachable: "UNREACHABLE",
  tooOld: "GATEWAY_TOO_OLD",
  refused: "REFUSED",
  badEnvelope: "BAD_ENVELOPE",
} as const;

interface Target {
  base: string;
  token: string;
}

/**
 * The ops base URL and the right token, or the 503 explaining which is missing.
 *
 * <p>The base is `GATEWAY_OPS_URL`, unless `GATEWAY_OPS_URLS` lists a cluster's nodes: then the
 * first that answers a health query, cached 30 s, with `GATEWAY_OPS_URL` as the last resort -- see
 * `lib/gateway-ops-urls.ts`. The tokens are the same for every node (db config mode keeps them in
 * app_config), so only the URL is per node.
 */
export async function resolveOps(auth: GqlAuth): Promise<Target | { failed: GqlFailure }> {
  const base = (await opsUrlResolver().resolve())?.trim().replace(/\/$/, "");
  const token =
    auth === "admin"
      ? process.env.GATEWAY_OPS_ADMIN_TOKEN?.trim()
      : process.env.GATEWAY_OPS_TOKEN?.trim();
  if (!base || !token) {
    return {
      failed: {
        ok: false,
        status: 503,
        code: PANEL_CODES.notConfigured,
        error: auth === "admin" ? ADMIN_TOKEN_HELP : READ_TOKEN_HELP,
      },
    };
  }
  return { base, token };
}

/**
 * The gateway's MAIN port and the read token, for `/q/metrics`.
 *
 * <p>Before 0.13 the metrics were on the management port beside `/ops`, and `GATEWAY_OPS_URL`
 * reached both. 0.13 moved them to the gateway's main (message) port behind the ops read token, so
 * the panel now needs that port's origin too. `GATEWAY_BASE_URL` is the one new variable; the
 * token stays `GATEWAY_OPS_TOKEN`, because it is the same secret the gateway checks.
 *
 * <p>`GATEWAY_API_URL` is the fallback: it is the customer REST address, which is the same main
 * port, and panels that serve the API playground already set it. Panels installed before
 * fireflo-panel-install wrote `GATEWAY_BASE_URL` (0.13.3.3) had neither variable for metrics.
 */
export function resolveMain(): Target | { failed: GqlFailure } {
  const base = (process.env.GATEWAY_BASE_URL?.trim() || process.env.GATEWAY_API_URL?.trim())?.replace(/\/$/, "");
  const token = process.env.GATEWAY_OPS_TOKEN?.trim();
  if (!base || !token) {
    return {
      failed: { ok: false, status: 503, code: PANEL_CODES.notConfigured, error: BASE_URL_HELP },
    };
  }
  return { base, token };
}

interface Envelope {
  data?: Record<string, unknown> | null;
  errors?: {
    message?: unknown;
    path?: unknown;
    extensions?: { code?: unknown; status?: unknown } | null;
  }[];
}

/**
 * Runs one document and answers the single root field's value.
 *
 * <p>The value, not the `data` object: every document in `lib/gateway-queries.ts` asks for one
 * root field, and a route returning `{ data: health }` today keeps returning exactly that. A
 * document with several root fields gets the whole object back, which is the honest answer.
 */
export async function executeGql<T>({
  query,
  variables,
  operationName,
  auth = "read",
  timeoutMs = 10_000,
  passErrors = false,
}: GqlCall): Promise<GqlOutcome<T>> {
  const target = await resolveOps(auth);
  if ("failed" in target) {
    return target.failed;
  }
  const { base, token } = target;

  let res: Response;
  let json: Envelope | null;
  try {
    res = await fetch(`${base}/graphql`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify(
        variables === undefined
          ? { query, operationName }
          : { query, operationName, variables }
      ),
      signal: AbortSignal.timeout(timeoutMs),
      cache: "no-store",
    });
    json = (await res.json().catch(() => null)) as Envelope | null;
  } catch (err) {
    //a cluster node that stopped answering: forget it, so the next call re-probes and moves on.
    //This call is not retried on another node -- a timed-out mutation may have been applied
    opsUrlResolver().invalidate(base);
    return unreachable(err);
  }

  if (res.status === 404) {
    //a 404 here is a wrong token, an address outside the allow-list, or a gateway from before
    ///graphql existed. Only the last can be told apart, and it is the one an operator mid-upgrade
    //most needs named: a 0.12.x gateway still answers /ops/health with the same read token
    const tooOld = await answersOldOps(base);
    return {
      ok: false,
      status: 502,
      code: tooOld ? PANEL_CODES.tooOld : PANEL_CODES.refused,
      error: tooOld ? GATEWAY_TOO_OLD : describe404(auth, sentenceOf(json)),
    };
  }
  if (!res.ok) {
    return {
      ok: false,
      status: 502,
      code: PANEL_CODES.refused,
      error: sentenceOf(json) ?? `Gateway returned ${res.status}`,
    };
  }

  const first = json?.errors?.[0];
  if (first) {
    const code = typeof first.extensions?.code === "string" ? first.extensions.code : "INTERNAL";
    const status =
      typeof first.extensions?.status === "number" && first.extensions.status >= 400
        ? first.extensions.status
        : 500;
    const message = typeof first.message === "string" && first.message ? first.message : code;
    if (passErrors) {
      //the gateway's sentence, at the gateway's status. See passErrors
      return { ok: false, status, code, error: message };
    }
    return { ok: false, status: 502, code, error: describeError(code, message, auth) };
  }

  if (json?.data === undefined) {
    return {
      ok: false,
      status: 502,
      code: PANEL_CODES.badEnvelope,
      error: "The gateway answered /graphql with something that is not a GraphQL envelope.",
    };
  }
  return { ok: true, data: rootValue(json.data) as T };
}

/**
 * The root field's value for lib callers, or a {@link GatewayError}.
 *
 * <p>The error always carries the gateway's own status and code, whatever `passErrors` says: a lib
 * caller is deciding what to do, not what to show, and needs the real answer.
 */
export async function gqlData<T>(call: GqlCall): Promise<T> {
  const outcome = await executeGql<T>({ ...call, passErrors: true });
  if (!outcome.ok) {
    throw new GatewayError(outcome.status, outcome.code, outcome.error);
  }
  return outcome.data;
}

/**
 * Turns a `FileResult` into bytes and the headers a download needs.
 *
 * <p>The filename is sanitised here rather than trusted: it lands in a `Content-Disposition` header
 * and then in a save dialog, so even the gateway's own name goes through the same filter a
 * caller-supplied one would.
 */
export function decodeFileResult(file: FileResult): {
  bytes: Uint8Array;
  filename: string;
  contentType: string;
} {
  const bytes = Buffer.from(file.bytesBase64 ?? "", "base64");
  const filename = (file.filename || "download").replace(/[^A-Za-z0-9._-]/g, "-");
  const contentType = /^[\w.+-]+\/[\w.+-]+/.test(file.contentType ?? "")
    ? file.contentType
    : "application/octet-stream";
  return { bytes: new Uint8Array(bytes), filename, contentType };
}

/**
 * `GET {GATEWAY_BASE_URL}/q/metrics` with the read token: a text body, not JSON.
 *
 * <p>Its own path because the envelope helpers parse JSON and would turn Prometheus exposition into
 * an empty payload with no error anywhere to explain it.
 */
export async function fetchMetricsText(
  timeoutMs = 10_000
): Promise<{ text: string } | { failed: GqlFailure }> {
  const target = resolveMain();
  if ("failed" in target) {
    return target;
  }
  const { base, token } = target;
  try {
    const res = await fetch(`${base}/q/metrics`, {
      headers: { Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(timeoutMs),
      cache: "no-store",
    });
    if (!res.ok) {
      return {
        failed: {
          ok: false,
          status: 502,
          code: PANEL_CODES.refused,
          error:
            res.status === 404
              ? "The gateway's main port refused /q/metrics. Either GATEWAY_BASE_URL is not the "
                + "gateway's main port, or smsg.ops.token there does not match GATEWAY_OPS_TOKEN."
              : `Gateway returned ${res.status}`,
        },
      };
    }
    return { text: await res.text() };
  } catch (err) {
    return { failed: unreachable(err) };
  }
}

/** Shallow `camelCase` keys to `snake_case`, for routes keeping a REST-era response shape. */
export function snakeCaseKeys<T extends Record<string, unknown>>(value: T): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [key, v] of Object.entries(value)) {
    out[key.replace(/[A-Z]/g, (c) => `_${c.toLowerCase()}`)] = v;
  }
  return out;
}

/**
 * {@link snakeCaseKeys} through every nested object and array, for a typed result whose children
 * are typed too (a `SessionPage` of `Session`s, a `WatchReport` of `WatchEvent`s). Scalars and
 * arrays of scalars pass through; null stays null.
 */
export function snakeCaseKeysDeep(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value.map(snakeCaseKeysDeep);
  }
  if (value === null || typeof value !== "object") {
    return value;
  }
  const out: Record<string, unknown> = {};
  for (const [key, v] of Object.entries(value as Record<string, unknown>)) {
    out[key.replace(/[A-Z]/g, (c) => `_${c.toLowerCase()}`)] = snakeCaseKeysDeep(v);
  }
  return out;
}

function rootValue(data: Record<string, unknown> | null): unknown {
  if (data === null || typeof data !== "object") {
    return null;
  }
  const keys = Object.keys(data);
  return keys.length === 1 ? data[keys[0]] : data;
}

function sentenceOf(json: unknown): string | null {
  const row = json as { error?: unknown; message?: unknown } | null;
  if (typeof row?.error === "string" && row.error) {
    return row.error;
  }
  if (typeof row?.message === "string" && row.message) {
    return row.message;
  }
  return null;
}

function unreachable(err: unknown): GqlFailure {
  return {
    ok: false,
    status: 502,
    code: PANEL_CODES.unreachable,
    error: err instanceof Error ? `Could not reach the gateway: ${err.message}` : "Unreachable",
  };
}

let probe: Promise<boolean> | null = null;

/**
 * Whether the management port still answers the REST `/ops/health`, which only a 0.12.x gateway
 * does. One probe at a time per process: a burst of calls against an old gateway must not become a
 * burst of probes.
 */
async function answersOldOps(base: string): Promise<boolean> {
  if (probe) {
    return probe;
  }
  const token = process.env.GATEWAY_OPS_TOKEN?.trim() ?? "";
  probe = (async () => {
    try {
      const res = await fetch(`${base}/ops/health`, {
        headers: { Authorization: `Bearer ${token}` },
        signal: AbortSignal.timeout(3_000),
        cache: "no-store",
      });
      return res.status === 200;
    } catch {
      return false;
    }
  })();
  try {
    return await probe;
  } finally {
    probe = null;
  }
}

/**
 * A 404 from the management port is ambiguous on purpose -- a wrong token and a caller outside the
 * allow-list look identical -- so this says all of it rather than guessing one.
 */
export function describe404(auth: GqlAuth, message: string | null): string {
  const setting = auth === "admin" ? "smsg.ops.admin.token" : "smsg.ops.token";
  const variable = auth === "admin" ? "GATEWAY_OPS_ADMIN_TOKEN" : "GATEWAY_OPS_TOKEN";
  const detail = message && message !== "Not found" ? ` ${message}` : "";
  return (
    `The gateway refused.${detail} Either ${setting} is unset there or does not match ${variable}, `
    + "or this panel's address is not on the gateway's ops allow-list."
  );
}

/** The sentence for an error inside the envelope, when the route is not forwarding it as-is. */
function describeError(code: string, message: string, auth: GqlAuth): string {
  if (code === "NOT_FOUND") {
    //a field refused for the token's level answers NOT_FOUND inside the envelope, so the token
    //sentence is the useful one. The gateway's message is kept when it says more than the code
    return describe404(auth, message);
  }
  if (code === "LICENCE_LAPSED" || code === "LICENCE_REFUSED") {
    return `${message} (the gateway's licence is not current; see Licence).`;
  }
  return message;
}
