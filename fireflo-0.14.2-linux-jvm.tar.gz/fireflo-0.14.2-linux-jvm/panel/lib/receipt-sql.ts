/**
 * The two statements behind the Receipts page, kept pure so their shape can be tested without a
 * database.
 *
 * <h2>Why two, and why neither reads every message</h2>
 *
 * <p>The page used to be one statement: every message in the range, and for each one a LATERAL
 * lookup of its receipt and another of its first progress receipt, across every monthly partition,
 * then three percentiles sorted over the lot. On .101 the 7-day view covered 1.16 million messages
 * and took 58.5 s against the metrics pool's 10 s `statement_timeout`; a set-based rewrite still
 * took 16.6 s for 7 days and 85 s for 30. So the page now asks two questions separately:
 *
 * <ul>
 *   <li><b>How many</b> -- sent, reported, expired, still open, delivered, per vendor -- exactly,
 *       from the gateway's `usage_hourly` summary plus the two edges of the range the summary does
 *       not cover, the same seam as {@code vendorPerformanceHourlySql}. Whole hours cost one row
 *       per vendor per hour however much traffic they carried</li>
 *   <li><b>How quickly</b> -- the timing percentiles and the progress figures -- over the messages
 *       themselves, in one set-based pass, but over a deterministic sample when the range holds
 *       more than {@link SAMPLE_TARGET} messages: every message whose id hashes to 0 modulo the
 *       divisor. A median over a hundred thousand messages does not move when the other million
 *       are added, and the sample is the same on every load, so the figures do not flicker</li>
 * </ul>
 *
 * <p>The sample is by message, never by attempt: every attempt of a sampled message is read, so
 * the representative attempt (the one a receipt is credited to) is chosen exactly as everywhere
 * else.
 */

import { attemptRows, partOne, representativeKeys } from "./cdr-grain.ts";
import { OUTCOME_LATERAL } from "./usage-summary-sql.ts";

/** Messages the timing statement reads at most; above this it samples. */
export const SAMPLE_TARGET = 20_000;

/**
 * Keep one message in this many. 1 means read them all.
 *
 * @param messages the range's message count, from the counts statement
 */
export function sampleDivisor(messages: number): number {
  if (!Number.isFinite(messages) || messages <= SAMPLE_TARGET) {
    return 1;
  }
  return Math.ceil(messages / SAMPLE_TARGET);
}

/**
 * Per-vendor counts for `[$1, $2)`: `$3` the summary's watermark, `$4` the instant before which
 * every message is settled (`now - smsg.cdr.deadline.hours`).
 *
 * <p>Modelled on `vendorPerformanceHourlySql`, with EXPIRED kept apart from the failures: on this
 * page it is the sweeper giving up, not the vendor answering, so it must not count as reported.
 * `cdr_final.final_state` is one of DELIVERED, FAILED, REJECTED, DROPPED and EXPIRED (V1.87.0), so
 * reported = delivered + failed.
 *
 * <p><b>Pending in a settled hour is expired.</b> `usage_hourly.pending_at_rollup` is what was
 * still open when the hour was rolled up, and the summary does not revisit it, so an hour rolled
 * up before its receipts arrived keeps them "open" for ever. An hour that ended before `$4` can
 * hold nothing open -- the sweeper has closed every message in it -- so its pending is counted as
 * expired. Measured on .101 over 7 days this matched the per-message read exactly (11,387 expired,
 * 0 open). The one thing it cannot see is a real receipt that arrived after the rollup AND after
 * the deadline, which the sweeper's EXPIRED already outranks for every other reader too.
 */
export function receiptCountsHourlySql(vendorAttempt: boolean): string {
  return `
  WITH cut AS (
      SELECT $1::timestamptz AS since,
             $2::timestamptz AS until,
             LEAST(GREATEST($3::timestamptz, $1::timestamptz), $2::timestamptz) AS seam,
             GREATEST(date_trunc('hour', $1::timestamptz AT TIME ZONE 'UTC') AT TIME ZONE 'UTC',
                      (SELECT min(hour) FROM usage_hourly)) AS first_hour
  ),
  edge AS (
      SELECT c.*
        FROM cdr_submit c
       WHERE ${partOne("c")}
         AND c.submitted_at >= (SELECT since FROM cut)
         AND c.submitted_at < (SELECT LEAST(first_hour, seam) FROM cut)
      UNION ALL
      SELECT c.*
        FROM cdr_submit c
       WHERE ${partOne("c")}
         AND c.submitted_at >= (SELECT seam FROM cut)
         AND c.submitted_at < (SELECT until FROM cut)
  ),
  edge_attempts AS (
      SELECT COALESCE(vendor, '') AS vendor, COUNT(*) AS attempts
        FROM edge
       GROUP BY 1
  ),
  edge_carried AS (
      SELECT DISTINCT ON (gateway_msg_id) gateway_msg_id, part_no, vendor
        FROM edge
       ORDER BY gateway_msg_id, ${representativeKeys("", vendorAttempt)}
  ),
  edge_outcomes AS (
      SELECT COALESCE(s.vendor, '') AS vendor,
             COUNT(*) AS messages,
             COUNT(*) FILTER (WHERE o.final_state = 'DELIVERED') AS delivered,
             COUNT(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED')) AS failed,
             COUNT(*) FILTER (WHERE o.final_state = 'EXPIRED') AS expired,
             COUNT(*) FILTER (WHERE o.final_state IS NULL) AS pending
        FROM edge_carried s${OUTCOME_LATERAL}
       GROUP BY 1
  ),
  rolled AS (
      SELECT h.vendor,
             SUM(h.attempts) AS attempts,
             SUM(h.submitted) AS messages,
             SUM(h.delivered) AS delivered,
             SUM(h.failed) AS failed,
             SUM(h.expired + CASE WHEN h.hour + interval '1 hour' <= $4::timestamptz
                                  THEN h.pending_at_rollup ELSE 0 END) AS expired,
             SUM(CASE WHEN h.hour + interval '1 hour' <= $4::timestamptz
                      THEN 0 ELSE h.pending_at_rollup END) AS pending
        FROM usage_hourly h, cut
       WHERE h.hour >= cut.first_hour AND h.hour < cut.seam
       GROUP BY 1
  ),
  merged AS (
      SELECT vendor, attempts, 0 AS messages, 0 AS delivered, 0 AS failed, 0 AS expired, 0 AS pending FROM edge_attempts
      UNION ALL
      SELECT vendor, 0, messages, delivered, failed, expired, pending FROM edge_outcomes
      UNION ALL
      SELECT vendor, attempts, messages, delivered, failed, expired, pending FROM rolled
  )
  SELECT NULLIF(vendor, '') AS vendor,
         SUM(attempts)  AS attempts,
         SUM(messages)  AS messages,
         SUM(delivered) AS delivered,
         SUM(failed)    AS failed,
         SUM(expired)   AS expired,
         SUM(pending)   AS pending
    FROM merged
   GROUP BY 1
  HAVING SUM(attempts) > 0 OR SUM(messages) > 0
   ORDER BY SUM(attempts) DESC`;
}

/**
 * Per-vendor timings and progress over `[$1, $2)`, reading one message in `$3`.
 *
 * <p>The sampled messages first (`s`: the representative attempts whose id hashes to 0 modulo the
 * divisor), then <b>each one's receipt looked up by its id</b> -- `idx_cdr_final_msg_part` and
 * `idx_cdr_interim_msg_part` -- rather than the window's receipts scanned for them. The scan was
 * every `cdr_final` row since `$1`: 3.7 million for 30 days on .101, 2.3 s cached and past the 10 s
 * limit from disk, and hopeless at ten million. The lookups cost the sample, about
 * {@link SAMPLE_TARGET} of them, however large the window. `final_at >= $1` and `received_at >= $1`
 * stay in the lookups: a receipt is never older than its submission, and they prune the monthly
 * partitions each lookup visits.
 *
 * <p>The receipt is chosen by the real-receipt-before-EXPIRED rule of {@code OUTCOME_LATERAL}.
 *
 * @param progress whether this gateway has `cdr_interim`; without it the progress columns are null
 */
export function receiptTimingsSql(progress: boolean, vendorAttempt: boolean): string {
  const window = "s.submitted_at >= $1 AND s.submitted_at < $2"
    + " AND ($3::int = 1 OR abs(hashtext(s.gateway_msg_id)) % $3::int = 0)";
  return `
  WITH s AS MATERIALIZED (
      SELECT s.gateway_msg_id, s.vendor, s.submitted_at
        FROM ${attemptRows(window, { vendorAttempt })}
       WHERE s.represents
  )
  SELECT s.vendor,
         count(*) AS sampled,
         percentile_cont(0.5) WITHIN GROUP (
           ORDER BY EXTRACT(EPOCH FROM (o.reported_at - s.submitted_at))) AS median_outcome,
         percentile_cont(0.9) WITHIN GROUP (
           ORDER BY EXTRACT(EPOCH FROM (o.reported_at - s.submitted_at))) AS p90_outcome,
         ${progress ? `COALESCE(sum(p.progress_count), 0)              AS progress_receipts,
         count(*) FILTER (WHERE p.received_at IS NOT NULL)  AS with_progress,
         --LEAST ignores nulls: the earlier of the two when both exist, whichever exists when one does
         percentile_cont(0.5) WITHIN GROUP (
           ORDER BY EXTRACT(EPOCH FROM (
             LEAST(p.received_at, o.reported_at) - s.submitted_at)))  AS median_first_sign` : `NULL::bigint AS progress_receipts,
         NULL::bigint AS with_progress,
         --with no interim table the first sign IS the outcome
         percentile_cont(0.5) WITHIN GROUP (
           ORDER BY EXTRACT(EPOCH FROM (o.reported_at - s.submitted_at))) AS median_first_sign`}
    FROM s
    --one indexed lookup per sampled message: its earliest real receipt
    LEFT JOIN LATERAL (
      SELECT CASE WHEN f.final_state <> 'EXPIRED' THEN f.final_at END AS reported_at
        FROM cdr_final f
       WHERE f.gateway_msg_id = s.gateway_msg_id AND f.part_no = 1 AND f.final_at >= $1
       --SAME RULE AS OUTCOME_LATERAL (usage-summary-sql.ts) AND UsageRollup.java: a real receipt
       --outranks a swept EXPIRED, whichever landed first. EXPIRED's final_at is our own sweeper at
       --the deadline, so it is never a reporting time
       ORDER BY (f.final_state = 'EXPIRED'), f.final_at
       LIMIT 1
    ) o ON TRUE${progress ? `
    LEFT JOIN LATERAL (
      SELECT min(i.received_at) AS received_at, count(*) AS progress_count
        FROM cdr_interim i
       WHERE i.gateway_msg_id = s.gateway_msg_id AND i.part_no = 1 AND i.received_at >= $1
    ) p ON TRUE` : ""}
   GROUP BY s.vendor`;
}
