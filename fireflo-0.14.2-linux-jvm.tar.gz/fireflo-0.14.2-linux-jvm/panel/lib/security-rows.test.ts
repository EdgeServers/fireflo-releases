import { test } from "node:test";
import assert from "node:assert/strict";
import type { RefusalSummaryRow } from "./ban-rules.ts";
import type { BindHold } from "./force-disconnect.ts";
import type { BlockedAddress, SecurityEvent } from "./security-events.ts";
import {
  addressRowsFrom,
  attemptsFrom,
  listenerOptions,
  portLabel,
  reasonOptions,
  surfaceOfLedgerRow,
} from "./security-rows.ts";

const EVENTS: SecurityEvent[] = [
  { at: "2026-10-22T09:00:00", surface: "smpp", reason: "badPassword", triedAs: "acme", ip: "203.0.113.9", listener: "smppserver.main", port: 22775 },
  { at: "2026-10-22T09:01:00", surface: "smpp", reason: "badPassword", triedAs: "acme", ip: "::ffff:203.0.113.9", listener: "smppserver.main", port: 22775 },
  { at: "2026-10-22T09:02:00", surface: "smpp", reason: "unknownIdentity", triedAs: "nobody", ip: "203.0.113.9", listener: "smppserver.main", port: 22775 },
  { at: "2026-10-23T10:00:00Z", surface: "panel", reason: "bad_credentials", triedAs: "admin", ip: "203.0.113.9" },
  { at: "2026-10-22T08:00:00", surface: "rest", reason: "missingCredential", triedAs: null, ip: "198.51.100.4" },
  { at: "2026-10-22T07:00:00Z", surface: "portal", reason: "unknown_address", triedAs: "x@y", ip: "192.0.2.7" },
];

const LEDGER: RefusalSummaryRow[] = [
  {
    listener: "smppserver.main",
    port: 22775,
    total: 20,
    byReason: [{ reason: "badPassword", count: 18 }, { reason: "unknownIdentity", count: 2 }],
    byAddress: [
      { ip: "203.0.113.9", count: 20, byReason: [{ reason: "badPassword", count: 18 }, { reason: "unknownIdentity", count: 2 }], identities: ["acme", "2vcqm382"], firstAt: "2026-10-20T03:00:00Z", lastAt: "2026-10-22T09:05:00Z", heldOut: false },
    ],
  },
  {
    listener: "smppserver.internal",
    port: 22777,
    total: 3,
    byReason: [{ reason: "ipLimit", count: 3 }],
    byAddress: [
      { ip: "10.0.0.7", count: 3, byReason: [{ reason: "ipLimit", count: 3 }], identities: ["acme-bulk"], firstAt: "2026-10-22T06:00:00Z", lastAt: "2026-10-22T06:30:00Z", heldOut: true },
    ],
  },
  {
    listener: null,
    port: 8081,
    total: 1,
    byReason: [{ reason: "missingCredential", count: 1 }],
    byAddress: [
      { ip: "198.51.100.4", count: 1, byReason: [{ reason: "missingCredential", count: 1 }], identities: [], firstAt: "2026-10-22T08:00:00Z", lastAt: "2026-10-22T08:00:00Z", heldOut: false },
    ],
  },
];

const BLOCKED: BlockedAddress[] = [
  { ip: "::ffff:198.51.100.4", jail: "fireflo-gateway", since: "2026-10-22T08:01:00Z", failures: 6, until: null },
];

const HOLDS: BindHold[] = [
  { id: 4, kind: "ip", value: "192.0.2.7", listener: null, until: null, reason: "flood", created_by: "anshu", created_at: "2026-10-22T07:30:00Z" },
  { id: 5, kind: "account", value: "acme", listener: null, until: null, reason: null, created_by: null, created_at: null },
];

test("one row per address merges the tail, the ledger, the ban and the hold, busiest first", () => {
  const rows = addressRowsFrom(EVENTS, LEDGER, BLOCKED, HOLDS);
  assert.deepEqual(rows.map((r) => r.ip), ["203.0.113.9", "10.0.0.7", "198.51.100.4", "192.0.2.7"]);

  const busy = rows[0];
  //the tail saw 4 (both spellings of the address are one row), the ledger 20: the larger wins
  assert.equal(busy.attempts, 20);
  assert.deepEqual(busy.bySurface, { smpp: 3, rest: 0, panel: 1, portal: 0 });
  assert.deepEqual(busy.ports, [{ listener: "smppserver.main", port: 22775, count: 20 }]);
  //reasons from both sources, the panel's included, each at the larger count
  assert.deepEqual(busy.reasons, [
    { reason: "badPassword", count: 18 },
    { reason: "unknownIdentity", count: 2 },
    { reason: "bad_credentials", count: 1 },
  ]);
  //names the tail counted first, then the ledger's identities it did not have
  assert.deepEqual(busy.triedAs, ["acme", "nobody", "admin", "2vcqm382"]);
  assert.equal(busy.firstAt, "2026-10-20T03:00:00Z");
  assert.equal(busy.lastAt, "2026-10-23T10:00:00Z");
  assert.equal(busy.heldOut, false);
  assert.equal(busy.blocked, null);
  assert.equal(busy.canWatch, true);

  //held out by the ledger's own flag, with no hold row to lift
  const held = rows[1];
  assert.equal(held.heldOut, true);
  assert.equal(held.hold, null);
  assert.deepEqual(held.ports, [{ listener: "smppserver.internal", port: 22777, count: 3 }]);

  //blocked, matched across the ::ffff: spelling
  const rest = rows[2];
  assert.equal(rest.blocked?.jail, "fireflo-gateway");
  assert.equal(rest.attempts, 1);
  assert.deepEqual(rest.ports, [{ listener: null, port: 8081, count: 1 }]);

  //held out by an operator's hold on the address, which the row carries so it can be lifted
  const portal = rows[3];
  assert.equal(portal.heldOut, true);
  assert.equal(portal.hold?.id, 4);
});

test("Watch is offered only where there was SMPP traffic", () => {
  const rows = addressRowsFrom(EVENTS, LEDGER, [], []);
  const by = Object.fromEntries(rows.map((r) => [r.ip, r.canWatch]));
  assert.equal(by["203.0.113.9"], true);
  assert.equal(by["10.0.0.7"], true);
  assert.equal(by["198.51.100.4"], false);
  assert.equal(by["192.0.2.7"], false);
});

test("without a ledger the rows come from the tail alone, ports from 0.13 log lines", () => {
  const rows = addressRowsFrom(EVENTS, null, [], []);
  assert.equal(rows[0].ip, "203.0.113.9");
  assert.equal(rows[0].attempts, 4);
  assert.deepEqual(rows[0].ports, [{ listener: "smppserver.main", port: 22775, count: 3 }]);
  assert.deepEqual(rows[0].reasons, [
    { reason: "badPassword", count: 2 },
    { reason: "bad_credentials", count: 1 },
    { reason: "unknownIdentity", count: 1 },
  ]);
  assert.deepEqual(rows.find((r) => r.ip === "198.51.100.4")?.ports, []);
});

test("the surface filter narrows both sources", () => {
  const panel = addressRowsFrom(EVENTS, LEDGER, [], [], { surface: "panel" });
  assert.deepEqual(panel.map((r) => [r.ip, r.attempts]), [["203.0.113.9", 1]]);
  assert.deepEqual(panel[0].ports, []);

  const rest = addressRowsFrom(EVENTS, LEDGER, [], [], { surface: "rest" });
  assert.deepEqual(rest.map((r) => r.ip), ["198.51.100.4"]);

  const smpp = addressRowsFrom(EVENTS, LEDGER, [], [], { surface: "smpp" });
  assert.deepEqual(smpp.map((r) => r.ip), ["203.0.113.9", "10.0.0.7"]);
  assert.equal(smpp[0].bySurface.panel, 0);
});

test("the listener filter keeps one fold, and the reason filter counts that reason alone", () => {
  const internal = addressRowsFrom(EVENTS, LEDGER, [], [], { listener: "smppserver.internal" });
  assert.deepEqual(internal.map((r) => r.ip), ["10.0.0.7"]);

  const unknown = addressRowsFrom(EVENTS, LEDGER, [], [], { reason: "unknownIdentity" });
  assert.deepEqual(unknown.map((r) => [r.ip, r.attempts]), [["203.0.113.9", 2]]);
  assert.deepEqual(unknown[0].reasons, [{ reason: "unknownIdentity", count: 2 }]);

  assert.deepEqual(addressRowsFrom(EVENTS, LEDGER, [], [], { reason: "nope" }), []);
});

test("every attempt is the tail, filtered the same way", () => {
  assert.equal(attemptsFrom(EVENTS).length, 6);
  assert.equal(attemptsFrom(EVENTS, { surface: "smpp" }).length, 3);
  assert.equal(attemptsFrom(EVENTS, { listener: "smppserver.main" }).length, 3);
  assert.equal(attemptsFrom(EVENTS, { reason: "badPassword" }).length, 2);
  assert.equal(attemptsFrom(EVENTS, { surface: "smpp", reason: "unknownIdentity" }).length, 1);
});

test("filter options come from both sources", () => {
  assert.deepEqual(reasonOptions(EVENTS, LEDGER), [
    { reason: "badPassword", count: 18 },
    { reason: "ipLimit", count: 3 },
    { reason: "unknownIdentity", count: 2 },
    { reason: "bad_credentials", count: 1 },
    { reason: "missingCredential", count: 1 },
    { reason: "unknown_address", count: 1 },
  ]);
  assert.deepEqual(listenerOptions(EVENTS, LEDGER).map((l) => l.listener), ["smppserver.main", "smppserver.internal"]);
  //an older ledger-less gateway still names the listeners its 0.13 log lines carry
  assert.deepEqual(listenerOptions(EVENTS, null).map((l) => [l.listener, l.port]), [["smppserver.main", 22775]]);
});

test("a ledger row with no listener is the REST surface, and labels say so", () => {
  assert.equal(surfaceOfLedgerRow({ listener: null }), "rest");
  assert.equal(surfaceOfLedgerRow({ listener: "smppserver.main" }), "smpp");
  assert.equal(portLabel({ listener: "smppserver.main", port: 22775 }), "smppserver.main :22775");
  assert.equal(portLabel({ listener: null, port: 8081 }), "rest :8081");
  assert.equal(portLabel({ listener: null, port: null }), "rest");
});
