import { strict as assert } from "node:assert";
import { test } from "node:test";

import { platformOf } from "./platform-ref.ts";

test("an omni: ref reads as OMNI; another platform keeps its own name", () => {
  assert.equal(platformOf("omni:7f3k2m9q1z0a/public/42"), "OMNI");
  assert.equal(platformOf("acme:tenant/9"), "acme");
});

test("an account made in the panel has no platform", () => {
  assert.equal(platformOf(null), null);
  assert.equal(platformOf(undefined), null);
  assert.equal(platformOf(""), null);
});
