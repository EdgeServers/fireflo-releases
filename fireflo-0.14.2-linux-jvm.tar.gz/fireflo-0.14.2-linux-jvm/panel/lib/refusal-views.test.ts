import { test } from "node:test";
import assert from "node:assert/strict";
import type { BanRule } from "./ban-rules.ts";
import { BAN_DURATIONS, blankRule, isNonBannable, listenerLabel } from "./refusal-views.ts";

test("a reason a rule leaves out by default is marked as such", () => {
  assert.ok(isNonBannable("ipLimit"));
  assert.ok(isNonBannable("heldOut"));
  assert.ok(!isNonBannable("badPassword"));
});

test("listener labels", () => {
  assert.equal(listenerLabel({ listener: "smppserver.main", port: 2775 }), "smppserver.main :2775");
  assert.equal(listenerLabel({ listener: null, port: 2775 }), ":2775");
  assert.equal(listenerLabel({ listener: null, port: null }), "unnamed");
});

test("the ban durations start with the jail's own, and are whole seconds", () => {
  assert.equal(BAN_DURATIONS[0].value, "");
  for (const d of BAN_DURATIONS.slice(1)) {
    assert.ok(Number.isInteger(Number(d.value)) && Number(d.value) > 0, d.label);
  }
});

test("a blank rule takes an id nobody holds and starts safe", () => {
  const existing: BanRule[] = [
    { id: "rule-1", name: "", listener: "any", reasons: [], threshold: 1, windowMinutes: 1, banSeconds: 60, jail: "j", enabled: true, dryRun: false },
    { id: "rule-3", name: "", listener: "any", reasons: [], threshold: 1, windowMinutes: 1, banSeconds: 60, jail: "j", enabled: true, dryRun: false },
  ];
  const fresh = blankRule(existing, "fireflo-gateway");
  assert.equal(fresh.id, "rule-4");
  assert.equal(fresh.enabled, false);
  assert.equal(fresh.dryRun, true);
  assert.equal(fresh.jail, "fireflo-gateway");
  assert.equal(blankRule([existing[1]], "j").id, "rule-2");
});
