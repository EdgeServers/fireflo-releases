/* Database-free and import-free, so a client component and a node test can both use it. */
/**
 * The platform a ref names, as the list shows it: `omni:<install>/…` reads "OMNI".
 */
export function platformOf(ref: string | null | undefined): string | null {
  if (!ref) {
    return null;
  }
  const platform = ref.split(":")[0];
  return platform.toLowerCase() === "omni" ? "OMNI" : platform;
}
