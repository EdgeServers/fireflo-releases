import { strict as assert } from "node:assert";
import { test } from "node:test";
import { formatSeconds } from "./page-timing.ts";

test("seconds read with two decimals under ten and one above", () => {
  assert.equal(formatSeconds(0.4213), "0.42");
  assert.equal(formatSeconds(1.0789), "1.08");
  assert.equal(formatSeconds(0), "0.00");
  assert.equal(formatSeconds(12.44), "12.4");
});
