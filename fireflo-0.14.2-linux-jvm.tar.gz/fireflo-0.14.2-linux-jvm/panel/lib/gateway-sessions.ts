import { GatewayError, gqlData } from "@/lib/gateway-graphql";
import { SESSIONS_DISCONNECT } from "@/lib/gateway-queries";

/**
 * Ending the connections a login is already holding.
 *
 * <p>Server-only. Exists because `enabled = false` on a credential is a statement about future
 * binds and nothing else: a customer already bound keeps submitting on that session until it drops
 * of its own accord. An operator switching a login off in a hurry means both, and until now got only
 * one of them, silently.
 *
 * <p><strong>Best effort by design.</strong> The stored change is the durable intent and has already
 * happened by the time this runs; the gateway would apply it on its next configuration poll anyway.
 * So an unreachable gateway is worth reporting and never worth failing the write for.
 */

/** What happened to the live sessions, in words a caller can show without interpreting. */
export interface BindTeardown {
  dropped: number;
  /** Present when the sessions could not be reached — the stored change still stands. */
  problem?: string;
}

/**
 * Drops every bind currently held by one SMPP login, across every listener.
 *
 * <p>One call to the gateway's force disconnect, which matches the system ID exactly on every
 * listener at once. This used to list each listener's sessions page by page and disconnect them one
 * at a time, filtering a substring search back down to the login by hand -- the gateway now does
 * the exact match itself, in one walk of the live sessions.
 */
export async function disconnectBindsFor(systemId: string): Promise<BindTeardown> {
  if (!systemId) {
    return { dropped: 0 };
  }
  try {
    const result = await gqlData<{ dropped?: unknown[] } | null>({
      query: SESSIONS_DISCONNECT,
      variables: { target: { system_id: systemId }, reason: "login disabled" },
      auth: "admin",
      //each session waits up to five seconds for the customer's unbind_resp
      timeoutMs: 30_000,
    });
    return { dropped: result?.dropped?.length ?? 0 };
  } catch (err) {
    if (err instanceof GatewayError) {
      return { dropped: 0, problem: err.message || `the gateway refused (${err.status})` };
    }
    return { dropped: 0, problem: err instanceof Error ? err.message : "the gateway is unreachable" };
  }
}
