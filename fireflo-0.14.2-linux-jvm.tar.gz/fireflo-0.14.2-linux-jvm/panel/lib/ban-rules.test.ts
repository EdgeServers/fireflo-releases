import { test } from "node:test";
import assert from "node:assert/strict";
import {
  type BanRule,
  NON_BANNABLE_REASONS,
  type RefusalSummaryRow,
  decisionSentence,
  decisionsFor,
  effectiveReasons,
  evaluateRules,
  normaliseRule,
} from "./ban-rules.ts";

/**
 * What a ban rule may decide from the refusal ledger.
 *
 * <p>The cases that matter most are the ones where a rule must NOT ban: a customer's fleet over
 * its connection cap, an address an operator is already holding out, a count that reaches the
 * threshold only by adding reasons the rule does not count.
 */

const JAILS = ["fireflo-gateway", "fireflo-panel"];

function rule(over: Partial<BanRule> = {}): BanRule {
  return {
    id: "r1",
    name: "Scanners on main",
    listener: "any",
    reasons: [],
    threshold: 10,
    windowMinutes: 10,
    banSeconds: 3600,
    jail: "fireflo-gateway",
    enabled: true,
    dryRun: false,
    ...over,
  };
}

function address(ip: string, byReason: Record<string, number>, heldOut = false) {
  const rows = Object.entries(byReason).map(([reason, count]) => ({ reason, count }));
  return {
    ip,
    count: rows.reduce((n, r) => n + r.count, 0),
    byReason: rows,
    identities: ["acme"],
    firstAt: "2026-10-22T09:00:00Z",
    lastAt: "2026-10-22T09:09:00Z",
    heldOut,
  };
}

function row(listener: string | null, ...addresses: ReturnType<typeof address>[]): RefusalSummaryRow {
  return {
    listener,
    port: 22775,
    total: addresses.reduce((n, a) => n + a.count, 0),
    byReason: [],
    byAddress: addresses,
  };
}

test("an address at the threshold is banned, one below it is not", () => {
  const rows = [row("main", address("1.1.1.1", { badPassword: 10 }), address("2.2.2.2", { badPassword: 9 }))];
  const out = decisionsFor(rule(), rows);
  assert.deepEqual(out.map((d) => d.ip), ["1.1.1.1"]);
  assert.equal(out[0].count, 10);
  assert.equal(out[0].jail, "fireflo-gateway");
  assert.equal(decisionSentence(out[0]), "1.1.1.1: 10 refusals in 10 min (badPassword 10), threshold 10");
});

test("a rule with no reasons counts everything except the gateway's non-bannable set", () => {
  const counting = effectiveReasons(rule());
  for (const r of NON_BANNABLE_REASONS) {
    assert.equal(counting.has(r), false, r);
  }
  assert.ok(counting.has("badPassword"));
  assert.ok(counting.has("backoff"), "a client retrying too fast after a refusal IS a guess");

  //a customer's fleet over its cap: 50 ipLimit refusals and two bad passwords is not a scanner
  const rows = [row("main", address("3.3.3.3", { ipLimit: 50, badPassword: 2 }))];
  assert.deepEqual(decisionsFor(rule(), rows), []);
});

test("a rule that names a reason counts only that reason", () => {
  const rows = [row("main", address("4.4.4.4", { unknownIdentity: 6, badPassword: 6 }))];
  assert.deepEqual(decisionsFor(rule({ reasons: ["badPassword"] }), rows), [], "6 < 10 on its own");
  assert.equal(decisionsFor(rule({ reasons: ["badPassword", "unknownIdentity"] }), rows).length, 1);
  //an operator naming a non-bannable reason explicitly is honoured: their choice, their listener
  assert.equal(decisionsFor(rule({ reasons: ["ipLimit"], threshold: 1 }), [row("main", address("5.5.5.5", { ipLimit: 1 }))]).length, 1);
});

test("a rule on one listener reads that fold alone; a rule on any sums across listeners", () => {
  const rows = [
    row("main", address("6.6.6.6", { badPassword: 6 })),
    row("edge", address("6.6.6.6", { badPassword: 6 })),
  ];
  assert.deepEqual(decisionsFor(rule({ listener: "main" }), rows), []);
  assert.deepEqual(decisionsFor(rule({ listener: "other" }), rows), []);
  const any = decisionsFor(rule({ listener: "any" }), rows);
  assert.equal(any.length, 1);
  assert.equal(any[0].count, 12);
  assert.equal(any[0].listener, null);
  assert.equal(decisionsFor(rule({ listener: "main", threshold: 6 }), rows)[0]?.listener, "main");
});

test("an address an operator is already holding out is never banned on top", () => {
  const rows = [row("main", address("7.7.7.7", { badPassword: 100 }, true))];
  assert.deepEqual(decisionsFor(rule(), rows), []);
});

test("a disabled rule decides nothing", () => {
  const rows = [row("main", address("8.8.8.8", { badPassword: 100 }))];
  assert.deepEqual(decisionsFor(rule({ enabled: false }), rows), []);
});

test("the first live rule to name an address wins, and a dry run never shadows a live rule", () => {
  const rows = [row("main", address("9.9.9.9", { badPassword: 20 }))];
  const byWindow = new Map([[10, rows]]);
  const out = evaluateRules(
    [rule({ id: "try", dryRun: true, threshold: 5 }), rule({ id: "live", threshold: 10 }), rule({ id: "dup", threshold: 15 })],
    byWindow
  );
  assert.equal(out.length, 1, "one ban per address and jail");
  assert.equal(out[0].ruleId, "live");
  assert.equal(out[0].dryRun, false);
});

test("the same address into two jails is two decisions", () => {
  const rows = [row("main", address("10.10.10.10", { badPassword: 20 }))];
  const out = evaluateRules([rule({ id: "a" }), rule({ id: "b", jail: "fireflo-panel" })], new Map([[10, rows]]));
  assert.deepEqual(out.map((d) => d.jail), ["fireflo-gateway", "fireflo-panel"]);
});

test("a rule whose window was not fetched decides nothing rather than reading another window", () => {
  const rows = [row("main", address("11.11.11.11", { badPassword: 20 }))];
  assert.deepEqual(evaluateRules([rule({ windowMinutes: 60 })], new Map([[10, rows]])), []);
});

test("normalising a rule keeps the known fields, defaults the safe way and refuses nonsense", () => {
  const ok = normaliseRule({ id: "scan", threshold: "10", windowMinutes: 10, banSeconds: 3600, extra: 1 }, JAILS);
  assert.ok(!("error" in ok));
  assert.equal(ok.name, "scan", "the id stands in for a missing name");
  assert.equal(ok.listener, "any");
  assert.equal(ok.jail, "fireflo-gateway");
  assert.equal(ok.enabled, false, "off until switched on");
  assert.equal(ok.dryRun, true, "dry run until switched off");
  assert.equal("extra" in ok, false);

  for (const bad of [
    { id: "bad id" },
    { id: "x", threshold: 0, windowMinutes: 10, banSeconds: 3600 },
    { id: "x", threshold: 10, windowMinutes: 10_000, banSeconds: 3600 },
    { id: "x", threshold: 10, windowMinutes: 10, banSeconds: 1 },
    { id: "x", threshold: 10, windowMinutes: 10, banSeconds: 3600, jail: "sshd" },
    { id: "x", threshold: 10, windowMinutes: 10, banSeconds: 3600, listener: "a b" },
    { id: "x", threshold: 10, windowMinutes: 10, banSeconds: 3600, reasons: ["bad password"] },
  ]) {
    const out = normaliseRule(bad, JAILS);
    assert.ok("error" in out, JSON.stringify(bad));
  }
});
