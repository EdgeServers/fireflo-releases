import { test } from "node:test";
import assert from "node:assert/strict";
import { LatestWins } from "./latest-wins.ts";

test("only the newest request's answer lands", () => {
  const gate = new LatestWins();
  const sevenDays = gate.begin();
  const oneHour = gate.begin(); //switched back before 7d answered
  assert.equal(gate.isCurrent(sevenDays), false, "the late 7d answer is dropped");
  assert.equal(gate.isCurrent(oneHour), true);
});
