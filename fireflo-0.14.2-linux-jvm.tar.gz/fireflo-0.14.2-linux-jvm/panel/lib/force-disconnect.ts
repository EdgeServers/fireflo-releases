/**
 * Force disconnect and hold-outs: the choices, the wording and the checks, apart from React so
 * they can be tested.
 *
 * <p>The gateway matches every target exactly -- `acme` never drops `acme2` -- across every listener
 * unless one is named. A disconnect alone lets a client straight back in; a hold refuses its binds
 * for a while, on every node.
 */

export type DisconnectKind = "ip" | "account" | "system_id";

export const KIND_LABEL: Record<DisconnectKind, string> = {
  ip: "IP address",
  account: "Account",
  system_id: "Login (system ID)",
};

/** What to do after disconnecting. `hold` is what the gateway takes: seconds, or `forever`. */
export interface HoldChoice {
  id: string;
  label: string;
  hold: string | null;
}

export const HOLD_CHOICES: HoldChoice[] = [
  { id: "none", label: "Allow them to reconnect", hold: null },
  { id: "15m", label: "Keep them out for 15 minutes", hold: "900" },
  { id: "1h", label: "Keep them out for 1 hour", hold: "3600" },
  { id: "24h", label: "Keep them out for 24 hours", hold: "86400" },
  { id: "forever", label: "Keep them out until lifted", hold: "forever" },
];

/** One session the gateway would drop, as `sessionMatch` lists it. */
export interface MatchedSession {
  listener: string;
  session_id: number | null;
  bind_type: string | null;
  system_id: string | null;
  account: string | null;
  host: string | null;
  bound_seconds: number | null;
}

/** A hold in force, as `bindHolds` lists it (camelCase on the wire; the route converts). */
export interface BindHold {
  id: number;
  kind: "ip" | "account" | "login";
  value: string;
  listener: string | null;
  until: string | null;
  reason: string | null;
  created_by: string | null;
  created_at: string | null;
}

/** Why a target cannot be sent, or null when it can. */
export function targetProblem(kind: DisconnectKind, value: string): string | null {
  const v = value.trim();
  if (!v) return `Enter the ${KIND_LABEL[kind].toLowerCase()} to disconnect.`;
  if (/\s/.test(v)) return "No spaces: the gateway matches exactly what you enter.";
  if (kind === "ip" && !/^[0-9a-fA-F:.]+$/.test(v)) return "That is not an IP address.";
  return null;
}

const BIND: Record<string, string> = { TRANSMITTER: "TX", RECEIVER: "RX", TRANSCEIVER: "TRX" };

/** "Drops 3 sessions: 2 as acme from 10.0.0.4, 1 as acme from 10.0.0.9." */
export function previewSentence(rows: readonly MatchedSession[]): string {
  if (!rows.length) return "Nothing is bound like that right now.";
  const groups = new Map<string, number>();
  for (const r of rows) {
    const key = `${r.system_id ?? "?"} from ${r.host ?? "?"}`;
    groups.set(key, (groups.get(key) ?? 0) + 1);
  }
  const parts = [...groups].map(([key, n]) => `${n} as ${key}`);
  return `Drops ${rows.length} ${rows.length === 1 ? "session" : "sessions"}: ${parts.join(", ")}.`;
}

/** "TX 1 · RX 1 · TRX 1" for the sessions to be dropped. */
export function bindSummary(rows: readonly MatchedSession[]): string {
  const counts = new Map<string, number>();
  for (const r of rows) {
    const k = BIND[r.bind_type ?? ""] ?? "binding";
    counts.set(k, (counts.get(k) ?? 0) + 1);
  }
  return [...counts].map(([k, n]) => `${k} ${n}`).join(" · ");
}

const HOLD_KIND: Record<BindHold["kind"], string> = { ip: "IP", account: "Account", login: "Login" };

/** "IP 10.0.0.4" */
export function holdTarget(h: Pick<BindHold, "kind" | "value">): string {
  return `${HOLD_KIND[h.kind]} ${h.value}`;
}

/** "until lifted", "for 12 more minutes", "for 3 more hours", "until 15 Oct" */
export function holdRemaining(until: string | null, now: number = Date.now()): string {
  if (!until) return "until lifted";
  const ms = new Date(until).getTime() - now;
  if (ms <= 0) return "expired";
  const minutes = Math.ceil(ms / 60_000);
  if (minutes < 60) return `for ${minutes} more ${minutes === 1 ? "minute" : "minutes"}`;
  const hours = Math.round(minutes / 60);
  if (hours < 48) return `for ${hours} more ${hours === 1 ? "hour" : "hours"}`;
  return `until ${new Date(until).toLocaleDateString(undefined, { day: "numeric", month: "short" })}`;
}
