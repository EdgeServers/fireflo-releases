import { strict as assert } from "node:assert";
import { test } from "node:test";
import {
  BROKER_DEFAULTS,
  BROKER_KEYS,
  BROKER_SECRET_KEYS,
  ENV_LOCKED_KEYS,
  type BrokerForm,
  bootstrapForGateway,
  brokerProblem,
  envLockProblem,
  formFromStored,
  isEnvLocked,
  isSecretBrokerKey,
  parseBootstrap,
  parseBrokerForm,
  withEnvLock,
  writesForForm,
} from "./broker-config.ts";
import { providerSourceOf } from "./health-types.ts";

test("the keys are the gateway's own names, so a rename on either side is a failing test", () => {
  //KafkaBackboneConfig and ClusterConfig in the gateway read exactly these
  assert.deepEqual(Object.values(BROKER_KEYS).sort(), [
    "smsg.cluster.heartbeat.seconds",
    "smsg.cluster.lease.renew.seconds",
    "smsg.cluster.lease.ttl.seconds",
    "smsg.cluster.node.timeout.seconds",
    "smsg.cluster.rebalance.grace.seconds",
    "smsg.kafka.bootstrap.servers",
    "smsg.kafka.compression",
    "smsg.kafka.group.prefix",
    "smsg.kafka.ingress.lag.highwater",
    "smsg.kafka.partitions.retry",
    "smsg.kafka.partitions.router",
    "smsg.kafka.partitions.vendor",
    "smsg.kafka.produce.block.ms",
    "smsg.kafka.produce.timeout.ms",
    "smsg.kafka.replication.factor",
    "smsg.kafka.retention.hours",
    "smsg.kafka.router.inflight",
    "smsg.kafka.sasl.mechanism",
    "smsg.kafka.sasl.password",
    "smsg.kafka.sasl.username",
    "smsg.kafka.security.protocol",
    "smsg.kafka.ssl.keystore.password",
    "smsg.kafka.ssl.keystore.path",
    "smsg.kafka.ssl.truststore.password",
    "smsg.kafka.ssl.truststore.path",
    "smsg.kafka.topic.prefix",
    "smsg.kafka.topics.create",
    "smsg.kafka.vendor.inflight",
    "smsg.kafka.vendor.settle",
    "smsg.queue.provider",
  ]);
  assert.deepEqual([...BROKER_SECRET_KEYS].sort(), [
    "smsg.kafka.sasl.password",
    "smsg.kafka.ssl.keystore.password",
    "smsg.kafka.ssl.truststore.password",
  ]);
  assert.equal(isSecretBrokerKey("smsg.kafka.sasl.password"), true);
  assert.equal(isSecretBrokerKey("smsg.kafka.sasl.username"), false);
});

test("the defaults are the gateway's", () => {
  assert.equal(BROKER_DEFAULTS.securityProtocol, "PLAINTEXT");
  assert.equal(BROKER_DEFAULTS.saslMechanism, "SCRAM-SHA-512");
  assert.equal(BROKER_DEFAULTS.topicPrefix, "fireflo.");
  assert.equal(BROKER_DEFAULTS.groupPrefix, "fireflo-");
  assert.equal(BROKER_DEFAULTS.partitionsRouter, "24");
  assert.equal(BROKER_DEFAULTS.partitionsVendor, "6");
  assert.equal(BROKER_DEFAULTS.partitionsRetry, "6");
  assert.equal(BROKER_DEFAULTS.replicationFactor, "-1");
  assert.equal(BROKER_DEFAULTS.retentionHours, "168");
  assert.equal(BROKER_DEFAULTS.compression, "lz4");
  assert.equal(BROKER_DEFAULTS.produceTimeoutMs, "5000");
  assert.equal(BROKER_DEFAULTS.produceBlockMs, "500");
  assert.equal(BROKER_DEFAULTS.routerInflight, "1000");
  assert.equal(BROKER_DEFAULTS.vendorInflight, "200");
  assert.equal(BROKER_DEFAULTS.vendorSettle, "on-submit");
  assert.equal(BROKER_DEFAULTS.ingressLagHighwater, "100000");
  assert.equal(BROKER_DEFAULTS.clusterHeartbeat, "5");
  assert.equal(BROKER_DEFAULTS.clusterNodeTimeout, "30");
  assert.equal(BROKER_DEFAULTS.clusterLeaseTtl, "30");
  assert.equal(BROKER_DEFAULTS.clusterLeaseRenew, "10");
  assert.equal(BROKER_DEFAULTS.clusterRebalanceGrace, "60");
});

test("a bootstrap list is read one per line or comma separated, each with a port", () => {
  assert.deepEqual(parseBootstrap("kafka1:9092\nkafka2:9092"), ["kafka1:9092", "kafka2:9092"]);
  assert.deepEqual(parseBootstrap(" kafka1:9092, kafka2:9093 ,\n"), ["kafka1:9092", "kafka2:9093"]);
  assert.deepEqual(parseBootstrap("[2001:db8::1]:9092"), ["[2001:db8::1]:9092"]);
  assert.deepEqual(parseBootstrap("10.0.0.5:9092\n10.0.0.5:9092"), ["10.0.0.5:9092"], "duplicates collapse");
  assert.match(parseBootstrap("") as string, /at least one/);
  assert.match(parseBootstrap("kafka1") as string, /needs a port/);
  assert.match(parseBootstrap("[::1]") as string, /needs a port/);
  assert.match(parseBootstrap("kafka1:99999") as string, /1 to 65535/);
  assert.match(parseBootstrap("bad host:9092") as string, /not a host name/);
  assert.equal(bootstrapForGateway("a:1\nb:2"), "a:1,b:2");
});

const stored = new Map([
  ["smsg.queue.provider", "Kafka"],
  ["smsg.kafka.bootstrap.servers", "kafka1:9092,kafka2:9092"],
  ["smsg.kafka.security.protocol", "SASL_SSL"],
  ["smsg.kafka.sasl.username", "fireflo"],
  ["smsg.kafka.sasl.password", "s3cret"],
  ["smsg.kafka.ssl.truststore.path", "/etc/fireflo/truststore.p12"],
  ["smsg.kafka.topics.create", "false"],
  ["smsg.kafka.partitions.router", "48"],
]);

test("the stored settings become a form with no secret in it", () => {
  const { form, secretsSet } = formFromStored(stored);
  assert.equal(form.provider, "kafka");
  assert.equal(form.bootstrap, "kafka1:9092\nkafka2:9092", "one per line for the textarea");
  assert.equal(form.securityProtocol, "SASL_SSL");
  assert.equal(form.saslMechanism, "SCRAM-SHA-512", "the default where nothing is stored");
  assert.equal(form.saslPassword, null);
  assert.equal(form.truststorePassword, null);
  assert.equal(form.topicsCreate, false);
  assert.equal(form.partitionsRouter, "48");
  assert.equal(form.partitionsVendor, "", "blank is the default");
  assert.deepEqual(secretsSet, { saslPassword: true, truststorePassword: false, keystorePassword: false });
  assert.ok(!JSON.stringify(form).includes("s3cret"));
});

test("a kept secret is not written, a new one is, and the bootstrap goes back to one line", () => {
  const { form } = formFromStored(stored);
  const kept = writesForForm(form);
  assert.equal(kept.has("smsg.kafka.sasl.password"), false, "null keeps the stored value untouched");
  assert.equal(kept.get("smsg.kafka.bootstrap.servers"), "kafka1:9092,kafka2:9092");
  assert.equal(kept.get("smsg.kafka.topics.create"), "false");
  assert.equal(kept.get("smsg.kafka.partitions.vendor"), "", "blank deletes the row");
  const changed = writesForForm({ ...form, saslPassword: "n3w", topicsCreate: true });
  assert.equal(changed.get("smsg.kafka.sasl.password"), "n3w");
  assert.equal(changed.get("smsg.kafka.topics.create"), "", "the default is not written");
  //SASL and TLS fields are cleared when the protocol stops using them
  const plain = writesForForm({ ...form, securityProtocol: "PLAINTEXT" });
  assert.equal(plain.get("smsg.kafka.sasl.username"), "");
  assert.equal(plain.get("smsg.kafka.ssl.truststore.path"), "");
});

test("under the in-process provider only the provider is written, so the address survives", () => {
  const { form } = formFromStored(stored);
  assert.deepEqual([...writesForForm({ ...form, provider: "memory" })], [["smsg.queue.provider", "memory"]]);
});

test("the form is checked only when Kafka is in use", () => {
  const { form, secretsSet } = formFromStored(stored);
  const bad: BrokerForm = { ...form, bootstrap: "" };
  assert.match(brokerProblem(bad, secretsSet) ?? "", /bootstrap/);
  assert.equal(brokerProblem({ ...bad, provider: "memory" }, secretsSet), null);
  assert.match(brokerProblem({ ...form, saslUsername: "" }, secretsSet) ?? "", /user name/);
  assert.match(brokerProblem(form, { ...secretsSet, saslPassword: false }) ?? "", /SASL password/);
  assert.equal(brokerProblem({ ...form, saslPassword: "typed" }, { ...secretsSet, saslPassword: false }), null);
  assert.match(brokerProblem({ ...form, keystorePassword: "x" }, secretsSet) ?? "", /keystore path/);
  assert.match(brokerProblem({ ...form, partitionsRouter: "0" }, secretsSet) ?? "", /Router partitions/);
  assert.match(brokerProblem({ ...form, replicationFactor: "0" }, secretsSet) ?? "", /replication factor/);
  assert.equal(brokerProblem({ ...form, replicationFactor: "-1" }, secretsSet), null);
  assert.match(brokerProblem({ ...form, topicPrefix: "fire flo" }, secretsSet) ?? "", /topic prefix/);
  assert.match(brokerProblem({ ...form, clusterNodeTimeout: "5" }, secretsSet) ?? "", /node timeout/);
  assert.match(brokerProblem({ ...form, clusterLeaseRenew: "30" }, secretsSet) ?? "", /renewed before it expires/);
  //PLAINTEXT asks for no credentials at all
  assert.equal(brokerProblem({ ...form, securityProtocol: "PLAINTEXT", saslUsername: "" }, { saslPassword: false, truststorePassword: false, keystorePassword: false }), null);
  assert.equal(brokerProblem(form, secretsSet), null);
});

test("a request body becomes a form, with absent secrets read as kept", () => {
  const form = parseBrokerForm({ provider: "kafka", bootstrap: "k:9092", securityProtocol: "SSL", compression: "gzip", topicsCreate: false });
  assert.ok(typeof form !== "string");
  assert.equal(form.securityProtocol, "SSL");
  assert.equal(form.compression, "gzip");
  assert.equal(form.topicsCreate, false);
  assert.equal(form.saslPassword, null);
  assert.equal(form.vendorSettle, "on-submit", "an unknown or absent choice is the default");
  assert.match(parseBrokerForm({ provider: "rabbitmq" }) as string, /memory or kafka/);
  assert.match(parseBrokerForm(null) as string, /JSON/);
});

test("fireflo.env locks the provider and the bootstrap, and nothing else", () => {
  assert.deepEqual([...ENV_LOCKED_KEYS].sort(), ["smsg.kafka.bootstrap.servers", "smsg.queue.provider"]);
  assert.equal(isEnvLocked("env"), true);
  assert.equal(isEnvLocked("stored"), false);
  assert.equal(isEnvLocked("default"), false);
  assert.equal(isEnvLocked(null), false);
  assert.equal(isEnvLocked(undefined), false);

  const { form } = formFromStored(stored);
  const all = writesForForm(form);
  const locked = writesForForm(form, { envLocked: true });
  assert.equal(locked.has("smsg.queue.provider"), false);
  assert.equal(locked.has("smsg.kafka.bootstrap.servers"), false);
  //every other key is written exactly as it is unlocked
  for (const [key, value] of all) {
    if (!ENV_LOCKED_KEYS.includes(key)) {
      assert.equal(locked.get(key), value, key);
    }
  }
  assert.equal(locked.size, all.size - 2);
});

test("under env the form shows what the gateway runs on, and a change to either locked key is refused", () => {
  const view = formFromStored(new Map([["smsg.queue.provider", "memory"], ["smsg.kafka.bootstrap.servers", "old:9092"]]));
  const backbone = { provider: "kafka", bootstrap: "127.0.0.1:9092", connected: true, source: "env" };
  const effective = withEnvLock(view, providerSourceOf(backbone), backbone);
  assert.equal(effective.providerSource, "env");
  assert.equal(effective.form.provider, "kafka", "the env provider, not the stored row");
  assert.equal(effective.form.bootstrap, "127.0.0.1:9092");

  const form = effective.form;
  assert.equal(envLockProblem(form, effective.form, "env"), null, "unchanged goes through");
  assert.equal(envLockProblem({ ...form, bootstrap: " 127.0.0.1:9092 \n" }, effective.form, "env"), null, "compared as the gateway reads it");
  assert.equal(envLockProblem({ ...form, partitionsRouter: "48", compression: "gzip" }, effective.form, "env"), null, "other keys are free");
  assert.match(envLockProblem({ ...form, provider: "memory" }, effective.form, "env") ?? "", /FIREFLO_QUEUE_PROVIDER.*fireflo\.env/);
  assert.match(envLockProblem({ ...form, bootstrap: "kafka9:9092" }, effective.form, "env") ?? "", /FIREFLO_KAFKA_BOOTSTRAP/);

  //the in-process provider from env: health has no bootstrap, so the stored one stands in
  const memory = withEnvLock(view, "env", { provider: "memory", bootstrap: null });
  assert.equal(memory.form.provider, "memory");
  assert.equal(memory.form.bootstrap, "old:9092");
  assert.equal(envLockProblem({ ...memory.form, bootstrap: "" }, memory.form, "env"), null, "memory does not read the bootstrap");
});

test("an absent or unknown source unlocks, and stored keeps today's behaviour", () => {
  const view = formFromStored(stored);
  //a 0.14.0 or 0.14.1 gateway: no source field at all
  assert.equal(providerSourceOf({ provider: "kafka" }), null);
  assert.equal(providerSourceOf(null), null);
  assert.equal(providerSourceOf({ source: "something-new" }), null);
  assert.equal(providerSourceOf({ source: "ENV" }), "env");
  for (const source of [null, undefined, "stored", "default"] as const) {
    const effective = withEnvLock(view, source, { provider: "memory", bootstrap: "elsewhere:9092" });
    assert.deepEqual(effective.form, view.form, `${source}: the stored form, untouched by health`);
    assert.equal(effective.providerSource, source ?? null);
    assert.equal(envLockProblem({ ...view.form, provider: "memory" }, effective.form, source), null);
    assert.equal(envLockProblem({ ...view.form, bootstrap: "kafka9:9092" }, effective.form, source), null);
  }
  assert.deepEqual([...writesForForm(view.form, { envLocked: false })], [...writesForForm(view.form)]);
});
