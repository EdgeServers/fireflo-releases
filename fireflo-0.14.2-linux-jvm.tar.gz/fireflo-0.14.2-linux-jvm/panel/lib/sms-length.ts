/**
 * How long a message is on the wire: characters, the encoding it needs, and how many SMS it takes.
 *
 * <p>GSM 03.38's default alphabet when every character is in it -- the extension characters
 * (`^{}\[~]|€` and form feed) take two septets each -- and UCS-2 otherwise. One message holds 160
 * septets or 70 UCS-2 units; a concatenated one gives up room for its header, 153 and 67 a part.
 * Characters outside the Basic Multilingual Plane (most emoji) are two UCS-2 units, as the handset
 * counts them.
 */

const GSM_BASIC =
  "@£$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !\"#¤%&'()*+,-./0123456789:;<=>?" +
  "¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà";
const GSM_EXTENSION = "^{}\\[~]|€\f";

const BASIC = new Set(GSM_BASIC);
const EXTENSION = new Set(GSM_EXTENSION);

export interface SmsLength {
  /** What the reader counts: characters as typed. */
  chars: number;
  encoding: "GSM-7" | "Unicode";
  /** Septets for GSM-7, UCS-2 units for Unicode. */
  units: number;
  parts: number;
}

export function smsLength(text: string): SmsLength {
  const chars = [...text];
  let septets = 0;
  let gsm = true;
  for (const c of chars) {
    if (BASIC.has(c)) {
      septets += 1;
    } else if (EXTENSION.has(c)) {
      septets += 2;
    } else {
      gsm = false;
      break;
    }
  }
  if (gsm) {
    return { chars: chars.length, encoding: "GSM-7", units: septets, parts: partsOf(septets, 160, 153) };
  }
  //String length is UTF-16 code units, which is what UCS-2 on the wire counts
  return { chars: chars.length, encoding: "Unicode", units: text.length, parts: partsOf(text.length, 70, 67) };
}

function partsOf(units: number, single: number, each: number): number {
  if (units === 0) return 0;
  return units <= single ? 1 : Math.ceil(units / each);
}
