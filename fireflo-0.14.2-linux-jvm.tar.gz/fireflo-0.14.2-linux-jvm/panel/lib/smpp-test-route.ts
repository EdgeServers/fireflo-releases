import { NextResponse } from "next/server";
import { configQuery } from "@/lib/config-db";
import { NotOperatorError, requireAdmin } from "@/lib/require-operator";
import { allowedSmppHosts, hostOfUrl, parseAllowedHostsEnv } from "@/lib/smpp-test-hosts";

/**
 * The guard every SMPP test route shares: an admin, or a 404 that does not say the route exists.
 *
 * @returns the admin's name, or the response to send instead
 */
export async function adminOr404(): Promise<string | NextResponse> {
  try {
    return (await requireAdmin()).name;
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
}

/** Where the gateway's listeners are: SMPP_TEST_HOST, else the management (GraphQL) URL's host, else this host. */
export function gatewayHost(): string {
  const explicit = process.env.SMPP_TEST_HOST?.trim();
  if (explicit) {
    return explicit;
  }
  try {
    const ops = process.env.GATEWAY_OPS_URL?.trim();
    if (ops) {
      return new URL(ops).hostname;
    }
  } catch {
    //not a URL; fall through
  }
  return "127.0.0.1";
}

/**
 * Every host the test tool may bind to (CP-S8): the gateway's own, as the panel already knows it
 * from its URLs and the listeners' settings, plus `SMPP_TEST_ALLOWED_HOSTS`. Membership is decided
 * in lib/smpp-test-hosts.ts; this only gathers the candidates.
 *
 * <p>Read per request rather than cached: a listener's `srv.public.host` can change in the panel,
 * and this tool is used right after such a change to see whether it worked.
 */
export async function allowedTestHosts(): Promise<Set<string>> {
  const env = process.env;
  const candidates: (string | null | undefined)[] = [
    gatewayHost(),
    env.SMPP_TEST_HOST,
    hostOfUrl(env.GATEWAY_OPS_URL),
    hostOfUrl(env.GATEWAY_API_URL),
    env.FIREFLO_PUBLIC_HOST,
    ...parseAllowedHostsEnv(env.SMPP_TEST_ALLOWED_HOSTS),
  ];
  try {
    const rows = await configQuery<{ value: string | null }>(
      `SELECT p.value FROM app_worker_property p
         JOIN app_worker w ON w.name = p.worker_name
        WHERE w.type = 'smppserver' AND p.key IN ('srv.host', 'srv.public.host')`
    );
    for (const r of rows) {
      //a wildcard bind is not a host anyone dials; the gateway host above already covers "here"
      if (r.value && !/^(0\.0\.0\.0|::|\[::\]|\*)$/.test(r.value.trim())) {
        candidates.push(r.value);
      }
    }
  } catch (err) {
    //no config connection, or no such table: the env-derived list still stands
    console.warn("smpp-test: could not read the listeners' hosts; only the configured hosts are allowed", err);
  }
  return allowedSmppHosts(candidates);
}

export const SESSION_ID = /^[0-9a-f]{16}$/;
