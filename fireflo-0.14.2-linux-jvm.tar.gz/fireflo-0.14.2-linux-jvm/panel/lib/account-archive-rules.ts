/**
 * When an account may be archived, and when a login, sender ID or template may move to another
 * account -- the decisions alone, with no database import, so they can be tested and so the routes
 * and the server functions say the same sentence.
 *
 * <p>Archived (gateway V1.100.0) means retired, not paused: `enabled = false` plus `archived_at`,
 * its logins switched off, hidden from the everyday lists and read-only until an admin unarchives
 * it. Its balance and history stay where they are.
 */

/** What is known about an account when deciding whether it may be archived. */
export interface ArchiveFacts {
  exists: boolean;
  archived: boolean;
  /** Accounts beneath it (a reseller's customers) that are not archived themselves. */
  activeChildren: number;
}

/**
 * Why the account cannot be archived, or null.
 *
 * <p>Credit the gateway is holding for the account (`account_balance.reserved`) is NOT a reason:
 * that is a block pre-authorised for speed and held until the gateway restarts, not money for
 * messages in flight. Archiving returns it to the balance instead (the gateway's `creditRelease` mutation).
 */
export function archiveRefusal(id: string, facts: ArchiveFacts): string | null {
  if (!facts.exists) {
    return `There is no account '${id}'.`;
  }
  if (facts.archived) {
    return `'${id}' is already archived.`;
  }
  if (facts.activeChildren > 0) {
    return `'${id}' still has ${facts.activeChildren} active customer account${facts.activeChildren === 1 ? "" : "s"} `
      + "of its own. Archive them, or move them to another reseller, first.";
  }
  return null;
}

/** Why the account cannot be unarchived, or null. */
export function unarchiveRefusal(id: string, facts: Pick<ArchiveFacts, "exists" | "archived">): string | null {
  if (!facts.exists) {
    return `There is no account '${id}'.`;
  }
  return facts.archived ? null : `'${id}' is not archived.`;
}

/** The sentence every write to an archived account is refused with. */
export function archivedReadOnly(id: string): string {
  return `'${id}' is archived, so it is read-only. Unarchive it first.`;
}

/** Either side of a move, as far as the decision needs to know. */
export interface MoveSide {
  id: string;
  exists: boolean;
  archived: boolean;
}

/** Why something cannot move from one account to the other at all, or null. */
export function moveRefusal(what: string, from: MoveSide, to: MoveSide): string | null {
  if (!to.id.trim()) {
    return "Choose the account to move it to.";
  }
  if (from.id === to.id) {
    return `This ${what} already belongs to '${to.id}'.`;
  }
  if (!to.exists) {
    return `There is no account '${to.id}'.`;
  }
  if (to.archived) {
    return `'${to.id}' is archived; nothing can be moved to it.`;
  }
  if (from.archived) {
    return archivedReadOnly(from.id);
  }
  return null;
}

/** A sender ID or template that names one login, shown when that login cannot move alone. */
export interface ScopedRow {
  kind: "sender ID" | "template";
  id: number;
  name: string;
}

/**
 * Why a login cannot move while rows on its old account are scoped to it, or null.
 *
 * <p>A login moves alone: a sender ID or template narrowed to its system ID stays on the old
 * account, where it would name a login that is no longer there. So the move waits until each one
 * is moved too (after the login) or has its login cleared.
 */
export function scopedRowsRefusal(systemId: string, rows: readonly ScopedRow[]): string | null {
  if (!rows.length) {
    return null;
  }
  const shown = rows.slice(0, 5).map((r) => `${r.kind} ${r.name}`).join(", ");
  const more = rows.length > 5 ? ` and ${rows.length - 5} more` : "";
  return `${rows.length} sender ID${rows.length === 1 ? "" : "s"}/template${rows.length === 1 ? "" : "s"} on this `
    + `account ${rows.length === 1 ? "is" : "are"} scoped to the login '${systemId}': ${shown}${more}. `
    + "Clear the login on them (so they cover the whole account), or delete them, before moving it. "
    + "Once cleared, they can be moved to the new account too, on their own.";
}

/**
 * Why a sender ID or template scoped to a login cannot move to `to`, or null.
 *
 * <p>The row may only name a login the target account owns -- the same rule `loginOutsideAccount`
 * applies when one is written. Move the login first, or clear the row's login.
 */
export function scopedLoginRefusal(systemId: string | null, loginOnTarget: boolean, to: string): string | null {
  if (!systemId?.trim() || loginOnTarget) {
    return null;
  }
  return `It is scoped to the login '${systemId.trim()}', which does not belong to '${to}'. `
    + "Clear the login on this row first, so it covers the whole account, then move it.";
}
