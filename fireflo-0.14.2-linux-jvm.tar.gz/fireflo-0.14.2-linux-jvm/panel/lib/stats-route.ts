import { NextRequest, NextResponse } from "next/server";
import { ServiceUnavailableError } from "@/lib/control-route";
import { isConfigured, withStatementTimeout } from "@/lib/metrics-db";
import { NotCustomerError, requireCustomer, requireReseller, scopeFor, type CustomerSession } from "@/lib/require-customer";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { resolveAudience } from "@/lib/stats-audience";
import { READERS } from "@/lib/stats-registry";
import { StatsCache, StillReadingError, statsKey, ttlFor } from "@/lib/stats-cache";
import { METRICS, audienceFor, isMetric, pickRange, type MetricSpec, type Who } from "@/lib/stats-metrics";

//loose on purpose: the same handler serves /api/stats/[metric] and the aliases, which have no segment
type Params = { params: Promise<object> };

const NOT_FOUND = () => NextResponse.json({ error: "Not found" }, { status: 404 });

/** One per panel process, shared by every request: see stats-cache.ts. */
const CACHE = new StatsCache(64);

/** How long a heavy read may run, in the background past the page's wait. */
const HEAVY_STATEMENT_MS = 60_000;
/** How long a page waits for a first heavy read before it is told to wait and ask again. */
const WAIT_MS = 8_000;
/** When the page asks again. */
const RETRY_AFTER_S = 15;

/**
 * The one route behind every stat and chart: `GET /api/stats/<metric>?range=…`, for the operator
 * panel and the customer portal alike.
 *
 * <ol>
 *   <li><b>Who.</b> An alias resolves only its own audience; the unscoped route tries an operator
 *       session first, then a customer one. Neither is a 404, before the metric is even looked up,
 *       so an anonymous caller learns nothing about which exist.</li>
 *   <li><b>Which reader.</b> The metric's reader for that audience (`stats-registry.ts`). An unknown
 *       metric and one this caller has no reader for answer the same 404.</li>
 *   <li><b>Which period.</b> Checked against the reader's own list (`stats-metrics.ts`); anything
 *       else is its default -- a query-string typo reads as the default, not as an error.</li>
 *   <li><b>The answer.</b> `{ metric, range, asOf, data }`, never cached by a shared proxy. A failure
 *       tells an operator what went wrong; a customer gets a sentence.</li>
 * </ol>
 *
 * @param fixed the metric, for an old per-metric URL kept as an alias (`/api/control/vendors`)
 * @param only the one audience an old alias served: `/api/mis/…` was the portal's, `/api/control/…`
 *     the operator's, and an alias does not widen that
 */
export function statsRoute(fixed?: string, only?: Who) {
  return async function GET(req: NextRequest, ctx: Params): Promise<NextResponse> {
    let session: CustomerSession | null = null;
    //an alias resolves only its own audience, so an operator session in the same browser does not
    //hide a portal one (stats-audience.ts)
    const who: Who | null = await resolveAudience(
      only,
      requireOperator,
      async () => {
        session = await requireCustomer();
      },
      (err) => err instanceof NotOperatorError || err instanceof NotCustomerError
    );
    if (!who) {
      return NOT_FOUND();
    }

    const metric = fixed ?? ((ctx ? ((await ctx.params) as { metric?: string }).metric : undefined) ?? "");
    const audience = audienceFor(metric, who);
    if (!audience || !isMetric(metric)) {
      return NOT_FOUND();
    }
    const readers = READERS[metric];

    let scope: string[] = [];
    if (who === "customer") {
      try {
        const spec: MetricSpec = METRICS[metric];
        //a per-account table is a reseller's view: a plain customer has one account and the
        //overview already shows it
        session = spec.customer?.resellersOnly ? await requireReseller() : session!;
        scope = await scopeFor(session);
      } catch (err) {
        if (err instanceof NotCustomerError) {
          return NOT_FOUND();
        }
        throw err;
      }
    }

    if (!isConfigured()) {
      return NextResponse.json(
        {
          error: who === "operator"
            ? "METRICS_DATABASE_URL is not set; this panel has no data source."
            : "Traffic is not available on this deployment.",
        },
        { status: 503 }
      );
    }

    const params = new URL(req.url).searchParams;
    const range = pickRange(audience, params.get("range"));
    const read = () => (who === "operator"
      ? readers.operator!({ range, params })
      : readers.customer!({ range, params, session: session!, scope }));
    try {
      const spec: MetricSpec = METRICS[metric];
      //the heavy ones are kept and shared (stats-cache.ts): every tab polling Receipts at 30 days
      //would otherwise each re-read millions of records. A customer's key carries their scope
      //a heavy read may run on for HEAVY_STATEMENT_MS in the background; the page waits WAIT_MS and
      //is otherwise told "still reading" (202) -- its "taking a breath" card -- and asks again
      const answer = spec.heavy
        ? await CACHE.get(
            statsKey({ who, metric, range, params, scope: who === "customer" ? scope : undefined }),
            ttlFor(range),
            () => withStatementTimeout(HEAVY_STATEMENT_MS, read),
            { waitMs: WAIT_MS }
          )
        : { value: await read(), at: Date.now() };
      return NextResponse.json(
        {
          metric,
          range,
          asOf: new Date(answer.at).toISOString(),
          //an older answer, because the latest read failed: the page says so rather than blanking
          ...(answer.stale ? { stale: { at: new Date(answer.at).toISOString(), reason: answer.stale.reason } } : {}),
          data: answer.value,
        },
        { headers: { "Cache-Control": "private, no-store", ...readers.headers } }
      );
    } catch (err) {
      if (err instanceof StillReadingError) {
        return NextResponse.json(
          { metric, range, busy: true, retryAfter: RETRY_AFTER_S },
          { status: 202, headers: { "Cache-Control": "private, no-store", "Retry-After": String(RETRY_AFTER_S) } }
        );
      }
      if (err instanceof ServiceUnavailableError || (err instanceof Error && err.name === "WarmingUpError")) {
        return NextResponse.json({ error: err.message }, { status: 503 });
      }
      console.error(`stats ${metric} (${who}) failed`, err);
      return who === "operator"
        //what an operator needs to see -- a missing table, a permission -- and no one else reaches
        ? NextResponse.json({ error: err instanceof Error ? err.message : "Query failed" }, { status: 500 })
        : NextResponse.json({ error: "Traffic could not be read just now." }, { status: 502 });
    }
  };
}
