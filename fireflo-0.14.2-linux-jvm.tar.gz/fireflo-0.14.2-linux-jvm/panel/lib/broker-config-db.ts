import { configQuery, inTransaction } from "@/lib/config-db";
import { BROKER_KEYS, type BrokerForm, type BrokerView, formFromStored, writesForForm } from "@/lib/broker-config";

/**
 * The backbone settings in `app_config`. Server-only: this holds the stored secrets.
 */

/** Every backbone key as stored, enabled rows only -- the ones the gateway reads. */
export async function readBrokerStored(): Promise<Map<string, string>> {
  const rows = await configQuery<{ key: string; value: string | null }>(
    "SELECT key, value FROM app_config WHERE enabled AND key = ANY($1)",
    [Object.values(BROKER_KEYS)]
  );
  return new Map(rows.map((r) => [r.key, r.value ?? ""]));
}

export async function readBroker(): Promise<BrokerView> {
  return formFromStored(await readBrokerStored());
}

/**
 * Writes the form, all keys in one transaction.
 *
 * <p>A blank field deletes its row, so the gateway's default applies -- as everywhere else in the
 * panel. A kept secret is not written at all. Under the in-process provider only the provider is
 * written: the Kafka settings are left as they are, so switching the backbone off and on again does
 * not lose them (`writesForForm`). With `envLocked`, the provider and bootstrap rows are not
 * touched: fireflo.env decides them.
 *
 * @returns each key that changed, from and to; the caller masks the secrets before logging
 */
export async function saveBroker(
  form: BrokerForm,
  { envLocked = false }: { envLocked?: boolean } = {}
): Promise<{ key: string; from: string | null; to: string | null }[]> {
  const stored = await readBrokerStored();
  const wanted = writesForForm(form, { envLocked });

  const changes: { key: string; from: string | null; to: string | null }[] = [];
  await inTransaction(async (client) => {
    for (const [key, value] of wanted) {
      const from = stored.get(key) ?? null;
      const to = value === "" ? null : value;
      if (from === to) {
        continue;
      }
      if (to === null) {
        await client.query("DELETE FROM app_config WHERE key = $1", [key]);
      } else {
        await client.query(
          `INSERT INTO app_config (key, value, enabled, updated_at)
                VALUES ($1, $2, true, now())
           ON CONFLICT (key) DO UPDATE
                SET value = EXCLUDED.value, enabled = true, updated_at = now()`,
          [key, to]
        );
      }
      changes.push({ key, from, to });
    }
  });
  return changes;
}
