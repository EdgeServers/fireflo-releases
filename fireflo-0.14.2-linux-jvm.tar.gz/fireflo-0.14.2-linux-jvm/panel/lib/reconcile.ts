/**
 * Does an account's credit add up, and if not, what is the likely cause.
 *
 * <p>Database-free: the two identities, the attribution and the wording, so the operator page and
 * `fireflo verify` say the same thing about the same account.
 *
 * <h2>TWO identities, not one</h2>
 *
 * <p>The obvious equation — `credited − consumed = balance + reserved` — is <strong>wrong</strong>,
 * and it is wrong in the direction that reports a false discrepancy on every account. It was written
 * that way in the design and the data refuted it immediately.
 *
 * <p>Credit is reserved in blocks (`balance -= n, reserved += n`) and spent from an in-memory
 * counter. Until gateway V1.95.0 the spent part was never written back, so `reserved` was a
 * lifetime-consumed counter — and the gateway's reclaim on start returned all of it to `balance`,
 * spending included. From V1.95.0 the gateway settles its spending out of `reserved` into `spent`
 * every few seconds (`reserved -= n, spent += n`), so `reserved` is the hold it reads as and `spent`
 * is the lifetime total. Every movement the database sees leaves the three-column sum unchanged:
 *
 * <pre>
 *   MONEY:       Σ(RECHARGE + TRANSFER, signed by direction)  =  balance + reserved + spent
 *   CONSUMPTION: reserved + spent  −  consumed   =  credit reserved but not yet spent  (≥ 0)
 * </pre>
 *
 * <p>On a schema before V1.95.0 `spent` reads as 0 and these are the old identities exactly.
 *
 * <p>Verified against real data before this was written: the money identity holds to the unit on
 * every account on the deployment, while the naive equation was out by exactly the consumption on
 * all of them.
 *
 * <p><strong>"Signed by direction" was missing, and the identity failed by construction without
 * it.</strong> A transfer is ONE ledger row naming two accounts — the payer in `account_id`, the
 * payee in `counterparty_account_id`, `delta` always positive. `CREDITED_SQL` read only the first
 * half, so a transfer of X counted +X for the payer whose balance had gone down by X, and nothing
 * at all for the payee whose balance had gone up. The claim above was therefore true only of
 * accounts that had never transferred — which, when resellers arrived, stopped being most of them.
 * A reseller funding a child was shown "credit the account has and nobody put in", about money
 * they had themselves just sent. See `reconcile-sql.ts`, which carries the arithmetic.
 *
 * <p><strong>`RESERVE`, `RELEASE` and `SPEND` are excluded from the money side.</strong> They move an
 * amount between columns of the same row, so they net to zero against `balance + reserved + spent`. `BILL` is
 * excluded too: a closed period records what was invoiced and moves nothing.
 *
 * <h2>Lifetime, never a period</h2>
 *
 * <p>Credit is a running total. Any shorter window needs an opening balance that nothing records,
 * and a wrong opening figure invents a discrepancy every time it is run.
 */

/** Everything the identities need, all scaled by 10,000. */
export interface ReconcileInput {
  accountId: string;
  /** Σ RECHARGE + TRANSFER, applied only. Pending entries have not moved money yet. */
  credited: number;
  /** usage_daily for rolled-up days plus cdr_submit for the live tail. Never both for one day. */
  consumed: number;
  balance: number;
  reserved: number;
  /** `account_balance.spent`: credit settled out of reserved as spent (gateway V1.95.0). 0 before it. */
  spent: number;
  /** Σ RECHARGE + TRANSFER still unapplied. A known, benign reason for a money gap. */
  pendingCredit: number;
  /** Messages sent with no price. They consumed nothing, and that is worth naming. */
  unratedMessages: number;
  /** Days with traffic and no rollup. Consumption is still counted, from the live tail. */
  daysMissingRollup: number;
}

export interface Attribution {
  /** Machine-readable, for `fireflo verify`'s concern() vocabulary. */
  code: "pendingCredit" | "creditMinted" | "creditLost" | "chargedWithoutReserving"
    | "heldUnspent" | "missingRollup" | "unrated";
  amount: number | null;
  message: string;
}

export interface Reconciliation {
  accountId: string;
  /** credited − (balance + reserved + spent). Zero on a healthy account, to the unit. */
  moneyDrift: number;
  /** reserved + spent − consumed. Non-negative on a healthy account: credit reserved and not yet spent. */
  heldUnspent: number;
  attributions: Attribution[];
  /**
   * The part nobody can explain, and the only figure worth alerting on.
   *
   * <p>Equal to {@link #moneyDrift}. It once had the pending credit subtracted from it, on the
   * reasoning that a raw difference is unactionable — but a pending entry is absent from both
   * sides of the identity and never contributed a difference to begin with, so the subtraction
   * only ever manufactured one. Kept as its own field because it is what the page alerts on, and
   * because a later cause we CAN name belongs here rather than in the raw drift.
   */
  residual: number;
  balanced: boolean;
}

/** One ten-thousandth is the smallest representable amount. Below it there is nothing to explain. */
const MATERIAL = 1;

/**
 * Runs both identities and names what it can.
 *
 * <p><strong>Nothing here writes anything, and nothing ever should.</strong> The residual is by
 * definition the part nobody could explain — posting an adjusting entry for it hides the cause and
 * makes the next drift start from a number nobody can audit. An automatic write to a balance column
 * is how a reconciliation tool becomes the thing that loses the money.
 */
export function reconcile(input: ReconcileInput, money: (scaled: number) => string): Reconciliation {
  const moneyDrift = input.credited - (input.balance + input.reserved + input.spent);
  const heldUnspent = input.reserved + input.spent - input.consumed;
  const attributions: Attribution[] = [];

  if (input.pendingCredit > 0) {
    attributions.push({
      code: "pendingCredit",
      amount: input.pendingCredit,
      message: `${money(input.pendingCredit)} of credit has not been applied yet. The gateway `
        + "credits it on its next poll, within thirty seconds.",
    });
  } else if (input.pendingCredit < 0) {
    //a transfer OUT of this account that the poll has not taken yet. Money on its way to somebody
    //else is not the same event as money on its way in, and reporting it with the sentence above
    //would tell a reseller that credit is arriving when it is leaving
    attributions.push({
      code: "pendingCredit",
      amount: input.pendingCredit,
      //deliberately does not restate the figure: the card renders `amount` in front of every
      //message, and `amount` is the signed contribution, so a magnitude here would read as a
      //contradiction of the minus sign beside it
      message: "Transfers out of this account have not been applied yet. The gateway debits them "
        + "on its next poll, within thirty seconds.",
    });
  }

  //THE RESIDUAL IS THE DRIFT. This used to subtract pendingCredit, and that was double counting:
  //`credited` is applied-only -- CREDITED_SQL splits the two with a FILTER -- and so is
  //`balance + reserved`, because a pending entry is by definition one the gateway has not applied
  //to the balance. A pending top-up is therefore absent from BOTH sides and cancels itself; the
  //drift is already zero before anything is subtracted. Subtracting it again turned every pending
  //top-up of P into a residual of -P and reported it as creditMinted -- permanently, on exactly
  //the uncreditable entry applyPendingRecharges deliberately leaves pending.
  //
  //The unit test that covered this passed an input the query layer cannot produce: `credited`
  //INCLUDING the pending amount. That is the only shape in which the subtraction is correct, and
  //nothing constructs it. Both cases now use figures reconcileAccount could actually return.
  //
  //Pending is an attribution, not a term. It says why a drift MIGHT appear -- when the poll runs
  //between the two reads -- and naming it is the whole of its job.
  const residual = moneyDrift;

  //the money identity is exact. Any residual at all is credit that appeared or vanished, and the
  //two directions are different problems, so they get different words
  if (residual > MATERIAL) {
    attributions.push({
      code: "creditLost",
      amount: residual,
      message: `${money(residual)} was credited and is in none of balance, reserved or spent. Credit `
        + "that entered the ledger and left the account without being spent.",
    });
  } else if (residual < -MATERIAL) {
    attributions.push({
      code: "creditMinted",
      amount: -residual,
      message: `${money(-residual)} is held that no RECHARGE or TRANSFER accounts for. Credit the `
        + "account has and nobody put in — the more serious direction of the two.",
    });
  }

  if (heldUnspent < -MATERIAL) {
    //messages charged against reservations that do not exist. On a deployment where prepaid credit
    //has never been switched on this is expected and not a fault; anywhere else it is a lost write
    attributions.push({
      code: "chargedWithoutReserving",
      amount: -heldUnspent,
      message: `${money(-heldUnspent)} of traffic was charged against credit that was never `
        + "reserved. Expected if smsg.balance.enabled has been off; otherwise a RESERVE write was "
        + "lost, and the consumption is real while the reservation is not.",
    });
  } else if (heldUnspent > MATERIAL) {
    attributions.push({
      code: "heldUnspent",
      amount: heldUnspent,
      message: `${money(heldUnspent)} is reserved and not yet spent. Normal on an account that is `
        + "sending; on an idle one it is credit stranded by an unclean stop, and "
        + "the gateway's creditRelease mutation returns it. Not lost either way — balance + reserved + spent "
        + "is conserved.",
    });
  }

  if (input.daysMissingRollup > 0) {
    attributions.push({
      code: "missingRollup",
      amount: null,
      //"not fully" rather than "no": a day counts here when any one product's line is missing,
      //which is the same grain CONSUMED_SQL takes its tail at
      message: `${input.daysMissingRollup} day(s) of traffic are not fully covered by a `
        + "usage_daily rollup. Their "
        + "consumption is still counted here, from the call records — but those records are what "
        + "the purge deletes. Run 'fireflo usage rollup --catch-up'.",
    });
  }

  if (input.unratedMessages > 0) {
    attributions.push({
      code: "unrated",
      amount: null,
      message: `${input.unratedMessages.toLocaleString()} message(s) went out with no price. They `
        + "consumed no credit, so they change neither identity — but they were sent, and on a "
        + "postpaid account they are revenue nobody invoiced.",
    });
  }

  return {
    accountId: input.accountId,
    moneyDrift,
    heldUnspent,
    attributions,
    residual,
    //the money identity is the one that must hold exactly. heldUnspent being positive is normal,
    //and being negative is reported but is a property of the traffic rather than of the ledger
    balanced: Math.abs(residual) < MATERIAL,
  };
}

/**
 * Whether the consumption side can be trusted for a period older than the retention window.
 *
 * <p>A day with traffic and no rollup is fine <em>today</em> — the call records are still there and
 * the tail counts them. It stops being fine the moment the purge runs, which is exactly what the
 * purge interlock refuses to let happen.
 */
export function consumptionIsDurable(input: ReconcileInput): boolean {
  return input.daysMissingRollup === 0;
}
