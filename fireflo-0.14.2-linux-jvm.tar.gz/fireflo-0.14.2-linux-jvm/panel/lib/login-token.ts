import { createHash, randomBytes, timingSafeEqual } from "crypto";
import { configQuery } from "@/lib/config-db";
import { passwordStamp } from "@/lib/session-freshness";

/**
 * One-time sign-in links for the customer portal.
 *
 * <p>Server-only: importing this pulls `pg`.
 *
 * <h2>The token is never stored</h2>
 *
 * <p>Only its SHA-256 goes into `app_login_token`. A database that leaks is bad; a database that
 * leaks a working sign-in link for every account at once is a different order of bad, and hashing
 * costs nothing here because the token is high-entropy random rather than a password — there is
 * nothing to brute-force and so no reason to reach for a slow KDF.
 *
 * <h2>Redemption is one statement</h2>
 *
 * <p>`UPDATE … WHERE used_at IS NULL AND expires_at > now() RETURNING …`. Reading the row
 * and then marking it spent would let two clicks on the same link both pass the read — which is not
 * hypothetical, because mail clients and link scanners fetch URLs, sometimes twice, before a human
 * ever sees them.
 *
 * <h2>The account comes from the user, not the token</h2>
 *
 * <p>`app_login_token.account_id` is no longer written or read. A token belongs to a user, and the
 * user row already says which account they are on, so the column restated `app_user.account_id` and
 * could only ever disagree with it. It stays in the schema, unused, until a later migration drops it
 * -- dropping it in the same release would break a panel that is one update behind its gateway.
 */

/** How long a link works for. Long enough to walk to a laptop, short enough to be worthless later. */
const TTL_MINUTES = 15;

/**
 * 32 bytes of `randomBytes`, base64url.
 *
 * <p>Not `Math.random`, and not a uuid: this is the entire credential for the duration, so it wants
 * a CSPRNG and enough width that guessing is not a strategy.
 */
function mintToken(): string {
  return randomBytes(32).toString("base64url");
}

function hash(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

/**
 * Issues a link for an account, without saying whether that account exists.
 *
 * <p>The caller passes an email; this resolves it and returns the token only when it matched. The
 * *caller* must answer identically either way — see the route. Returning null rather than throwing
 * is what makes the identical answer easy to write and hard to get wrong.
 *
 * @returns the raw token to put in the link, or null when no enabled customer user on an enabled
 *     account has that address
 */
/**
 * Which door a link is for. Encoded in SQL on both issue and redeem, so a customer's link can never
 * sign an operator in and an operator's can never open a portal, whatever the caller does with it.
 */
export type LinkSurface = "portal" | "operator";

export async function issueLoginToken(email: string, ip: string | null, surface: LinkSurface): Promise<
  { token: string; accountId: string | null; userId: number; email: string } | null
> {
  const trimmed = email.trim();
  if (!trimmed) {
    return null;
  }

  //the person, not the account: since V1.52.0 the address that may sign in is an app_user row, and
  //an account may have several. lower(email) is what `uq_app_user_email` indexes, so this matches
  //the way uniqueness is defined rather than a way that merely usually agrees with it. On the
  //portal both the user and the account must be enabled -- a suspended account's people cannot
  //ask for a link; on the operator side there is no account, and the role decides
  const found = surface === "portal"
    ? await configQuery<{ id: string; account_id: string | null; email: string }>(
      `SELECT u.id, u.account_id, u.email FROM app_user u
         JOIN app_account a ON a.id = u.account_id
        WHERE lower(u.email) = lower($1) AND u.enabled AND a.enabled AND u.role = 'customer'
        LIMIT 1`,
      [trimmed]
    )
    : await configQuery<{ id: string; account_id: string | null; email: string }>(
      `SELECT id, account_id, email FROM app_user
        WHERE lower(email) = lower($1) AND enabled AND account_id IS NULL AND role IN ('admin', 'operator')
        LIMIT 1`,
      [trimmed]
    );
  if (!found.length) {
    return null;
  }

  const token = mintToken();
  await configQuery(
    `INSERT INTO app_login_token (token_hash, user_id, expires_at, requested_ip)
     VALUES ($1, $2, now() + ($3 || ' minutes')::interval, $4)`,
    [hash(token), Number(found[0].id), String(TTL_MINUTES), ip]
  );
  return { token, accountId: found[0].account_id, userId: Number(found[0].id), email: found[0].email };
}

/**
 * Spends a token, once.
 *
 * <p>The `WHERE` clause carries every condition: unspent, unexpired, and the hash matching. A row
 * comes back only if all three held at the instant of the write, so there is no window between
 * deciding and spending.
 *
 * @returns the user and account the link was for, or null when the token is unknown, expired or
 *     already used
 */
export async function redeemLoginToken(
  token: string,
  surface: LinkSurface
): Promise<{ accountId: string | null; userId: number; email: string; role: string; passwordChangedAt: number | null } | null> {
  if (!token || typeof token !== "string") {
    return null;
  }
  //the door is part of the WHERE, so a token issued for the other one is simply not found -- and
  //stays unspent, which costs nothing because it cannot be used here either way
  const rows = await configQuery<{ account_id: string | null; user_id: string; email: string; role: string; password_changed_at: Date | string | null }>(
    `UPDATE app_login_token t
        SET used_at = now()
       FROM app_user u
      WHERE u.id = t.user_id AND t.token_hash = $1 AND t.used_at IS NULL AND t.expires_at > now()
        AND u.enabled
        AND ${surface === "portal"
          //the account must still be enabled at redeem, not only at issue: a link asked for a minute
          //before the account was suspended or archived would otherwise still open the portal
          ? "u.role = 'customer' AND u.account_id IS NOT NULL"
            + " AND EXISTS (SELECT 1 FROM app_account a WHERE a.id = u.account_id AND a.enabled)"
          : "u.role IN ('admin', 'operator') AND u.account_id IS NULL"}
      RETURNING u.account_id, t.user_id, u.email, u.role, u.password_changed_at`,
    [hash(token)]
  );
  return rows.length
    ? {
      accountId: rows[0].account_id,
      userId: Number(rows[0].user_id),
      email: rows[0].email,
      role: rows[0].role,
      passwordChangedAt: passwordStamp(rows[0].password_changed_at),
    }
    : null;
}

/**
 * How many links this address has been sent recently.
 *
 * <p>Counted against the *user row*, not the email string, so asking under three spellings of the
 * same address does not buy three times the budget.
 */
export async function recentTokenCount(email: string, withinMinutes: number): Promise<number> {
  const rows = await configQuery<{ n: string }>(
    `SELECT count(*) AS n
       FROM app_login_token t
       JOIN app_user u ON u.id = t.user_id
      WHERE lower(u.email) = lower($1)
        AND t.created_at > now() - ($2 || ' minutes')::interval`,
    [email.trim(), String(withinMinutes)]
  );
  return Number(rows[0]?.n ?? 0);
}

/**
 * Constant-time compare, for anything that ends up comparing tokens outside the database.
 *
 * <p>Nothing uses it today — redemption compares hashes inside PostgreSQL. It exists so that the
 * next person to need one does not reach for `===`.
 */
export function tokensEqual(a: string, b: string): boolean {
  const left = Buffer.from(a, "utf8");
  const right = Buffer.from(b, "utf8");
  return left.length === right.length && timingSafeEqual(left, right);
}
