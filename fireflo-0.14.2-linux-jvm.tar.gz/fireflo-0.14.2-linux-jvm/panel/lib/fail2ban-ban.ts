import { execFile } from "node:child_process";
import { stat } from "node:fs/promises";
import { promisify } from "node:util";
import { auditConfigChange, type AuditActor } from "@/lib/config-audit";
import { FIREFLO_JAILS, fail2banAvailable, fail2banWrapper } from "@/lib/security-sources";

const run = promisify(execFile);

/**
 * Blocking one address in fail2ban from the panel: the ban route and the ban rules share this.
 *
 * <p><strong>This is the one thing in the panel that can cut somebody off at the host.</strong>
 * Unban existed first and was deliberately the only privileged verb; `ban` was added to the
 * gateway's `fireflo-fail2ban` wrapper for the refusal ledger, and this module is the only caller.
 * What holds the line is the wrapper, not this file: it takes one literal address into one of
 * FireFlo's own jails and nothing else, and fail2ban itself checks a manual ban against the jail's
 * ignore list. The checks here exist so a typo answers a sentence rather than an exit code, and so
 * nothing shaped like an argument reaches a process.
 *
 * <p>`execFile`, never `exec`: arguments go as an array to a named binary, so there is no shell to
 * interpret them -- a semicolon in the address is an address that fails validation, not a command.
 *
 * <p>Server-only, and only ever meaningful on the gateway host: fail2ban is where the refusals are
 * logged, and the panel reaches it through sudo on the same box.
 */

/** The jail a ban lands in unless the caller says otherwise: the gateway's own. */
export const DEFAULT_JAIL = "fireflo-gateway";

/**
 * A literal IPv4 or IPv6 address and nothing else.
 *
 * <p>Not a hostname, not a range, not a CIDR. fail2ban would accept some of those, and
 * "ban 0.0.0.0/0" is not a thing a browser should be able to ask for.
 */
export const LITERAL_ADDRESS = /^[0-9a-fA-F.:]{2,45}$/;

export function isLiteralAddress(ip: string): boolean {
  return LITERAL_ADDRESS.test(ip) && /[.:]/.test(ip);
}

export function isFirefloJail(jail: string): jail is (typeof FIREFLO_JAILS)[number] {
  return (FIREFLO_JAILS as readonly string[]).includes(jail);
}

/** The gateway's `fireflo-ignore`, which answers whether an address must never be banned. */
export function ignoreCommand(): string {
  return process.env.FIREFLO_IGNORE_COMMAND?.trim() || "/usr/local/sbin/fireflo-ignore";
}

export interface IgnoreVerdict {
  /** True when the host's never-ban list covers this address. */
  ignored: boolean;
  /** False when the list could not be asked, in which case `ignored` is false and `note` says why. */
  checked: boolean;
  note: string | null;
}

/**
 * Asks the host's never-ban list, the way fail2ban itself does.
 *
 * <p>Runs the gateway's `fireflo-ignore <ip>` rather than reading `/etc/fireflo/fail2ban-ignore.conf`
 * here: that script is what fail2ban's `ignorecommand` runs, it understands CIDR and the `::ffff:`
 * mapped form, and two readers of one file drift. No sudo -- it only reads. Exit 0 is "ignore it",
 * 1 is "a ban is allowed", and a missing script is "could not check", which the caller treats as
 * allowed with a note: the wrapper's own `ban` goes through fail2ban, which consults the list again.
 */
export async function ignoreListed(ip: string): Promise<IgnoreVerdict> {
  const command = ignoreCommand();
  try {
    const info = await stat(/*turbopackIgnore: true*/ command);
    if (!info.isFile()) {
      throw new Error("not a file");
    }
  } catch {
    return {
      ignored: false,
      checked: false,
      note: `${command} is not on this host, so the never-ban list was not consulted here; fail2ban consults it itself.`,
    };
  }
  try {
    await run(command, [ip], { timeout: 5_000 });
    return { ignored: true, checked: true, note: null };
  } catch (err) {
    const code = (err as { code?: unknown }).code;
    if (code === 1) {
      return { ignored: false, checked: true, note: null };
    }
    return {
      ignored: false,
      checked: false,
      note: `${command} did not answer (${err instanceof Error ? err.message : String(err)}); fail2ban consults the list itself.`,
    };
  }
}

export interface BanRequest {
  jail: string;
  ip: string;
  /** Asked for, recorded, and -- today -- ignored by the wrapper, which says so. See `banSeconds`. */
  seconds?: number | null;
  /** Who, for the audit line. Null for a rule run, which has no operator behind it. */
  actor: AuditActor | null;
  /** `operator` for the button, or the rule id for the runner. Goes in the audit detail. */
  source: string;
}

export type BanResult =
  | { ok: true; note: string | null }
  | { ok: false; status: number; error: string };

/** The sentence for a host without the wrapper, which is also the sentence for "panel not on the gateway host". */
export function banNotAvailableSentence(jail: string, ip: string): string {
  return (
    `Banning from the panel is not set up on this host: ${fail2banWrapper()} is not there. The panel `
    + "must run on the gateway host, installed with --with-fail2ban, for fail2ban to be reachable. "
    + `Block it on that host instead: sudo fail2ban-client set ${jail} banip ${ip}`
  );
}

/**
 * Blocks one address, after the same checks whichever caller asked.
 *
 * <p>Audited BEFORE the call and kept whatever the outcome: a ban that failed half way is exactly
 * the one somebody needs to find afterwards. The audit event is `config_changed` in the `fail2ban`
 * domain rather than a new event name, because `app_operator_access_log.event` is CHECK-constrained
 * and a new name is a gateway migration; the file log would keep an unknown name, the database row
 * would not.
 *
 * <p>Does <strong>not</strong> consult the never-ban list or the live ban list: the route and the
 * runner do, so each can word the refusal for its own caller. fail2ban consults the ignore list
 * again regardless (0.10+ reports an ignored address rather than blocking it).
 */
export async function banAddress({ jail, ip, seconds, actor, source }: BanRequest): Promise<BanResult> {
  if (!isFirefloJail(jail)) {
    return { ok: false, status: 400, error: `Not a FireFlo jail. Expected one of: ${FIREFLO_JAILS.join(", ")}` };
  }
  if (!isLiteralAddress(ip)) {
    return {
      ok: false,
      status: 400,
      error: "That is not a literal address. Only a single IPv4 or IPv6 address can be blocked here.",
    };
  }
  const span = seconds == null ? null : Math.floor(seconds);
  if (span !== null && (!Number.isFinite(span) || span <= 0)) {
    return { ok: false, status: 400, error: "seconds must be a whole number of seconds, or left out." };
  }
  if (!(await fail2banAvailable())) {
    return { ok: false, status: 501, error: banNotAvailableSentence(jail, ip) };
  }

  await auditConfigChange(
    {
      domain: "fail2ban",
      name: ip,
      action: "action:ban",
      after: { jail, seconds: span, source },
    },
    actor
  );

  const args = ["-n", fail2banWrapper(), "ban", jail, ip];
  if (span !== null) {
    args.push(String(span));
  }
  try {
    //sudo -n: the grant is NOPASSWD for this one path, so a host where that rule is missing fails
    //at once rather than blocking on a prompt nobody can answer
    const { stderr } = await run("sudo", args, { timeout: 10_000 });
    //the wrapper says on stderr when it ignored the duration; worth passing on rather than
    //letting an operator believe a one-hour ban is a one-day one
    const note = stderr?.trim() ? stderr.trim().replace(/^note:\s*/, "") : null;
    return { ok: true, note };
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    return {
      ok: false,
      status: 502,
      error:
        `The ban did not complete: ${detail}. If this says "a password is required", the sudo rule `
        + `for ${fail2banWrapper()} is missing -- reinstall with --with-fail2ban, or block it on the `
        + `host: sudo fail2ban-client set ${jail} banip ${ip}`,
    };
  }
}
