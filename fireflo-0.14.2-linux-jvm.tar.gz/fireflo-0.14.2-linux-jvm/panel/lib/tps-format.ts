/**
 * A rate in messages per second, as the panel shows it: at most two decimal places.
 *
 * <p>The gateway reports its measured rates as a mean over a window, so they arrive with every digit
 * a division leaves (12.333333333333334 tps). Two places say everything a rate can usefully say, and
 * a whole number stays whole. No imports, so any module -- client, server or test -- can use it.
 */
export function formatTps(rate: number): string {
  return rate.toLocaleString(undefined, { maximumFractionDigits: 2 });
}
