import { test } from "node:test";
import assert from "node:assert/strict";
import {
  ACCOUNT_SYNC,
  GRAPHQL_OPS,
  KAFKA_BACKBONE,
  NODE_IDENTITY,
  QUEUE_PEEK,
  REFUSAL_LEDGER,
  SESSION_RECEIPTS,
  SEND_AS_ACCOUNT,
  SLOW_QUERY_LOG,
  TOPIC_LAG,
  VENDOR_LEASES,
  apiLevelSentence,
  capabilityNames,
  hasCapability,
} from "./capabilities.ts";
import type { Health } from "./health-types.ts";

const base = { observed_at: "", router_queue: 0, awaiting_receipt: 0, dlr_store_persistent: true, cdr: null, workers: [] };

test("a capability is a named true in the api map, and nothing else", () => {
  const health: Health = { ...base, api: { reload_adopted: true, send_client_ref: false } };
  assert.equal(hasCapability(health, "reload_adopted"), true);
  assert.equal(hasCapability(health, "send_client_ref"), false, "false is false");
  assert.equal(hasCapability(health, "never_heard_of"), false);
});

test("an older gateway, or no health at all, has no capabilities", () => {
  assert.equal(hasCapability({ ...base }, "reload_adopted"), false);
  assert.equal(hasCapability(null, "reload_adopted"), false);
  assert.equal(hasCapability(undefined, "reload_adopted"), false);
  assert.deepEqual(capabilityNames({ ...base }), []);
  assert.equal(apiLevelSentence({ ...base }), null, "no map is not an empty map");
});

test("the sentence lists the true names, sorted", () => {
  const health: Health = { ...base, api: { send_client_ref: true, config_key_status: true, schema_version: false } };
  assert.deepEqual(capabilityNames(health), ["config_key_status", "send_client_ref"]);
  assert.equal(apiLevelSentence(health), "This gateway answers API level config_key_status, send_client_ref.");
  assert.match(apiLevelSentence({ ...base, api: {} }) ?? "", /no capabilities declared/);
});

test("the 0.13 names are the gateway's own, so a rename on either side is a failing test", () => {
  //ApiCapabilitiesTest in the gateway asserts the same six keys
  assert.deepEqual(
    [GRAPHQL_OPS, SEND_AS_ACCOUNT, ACCOUNT_SYNC, SLOW_QUERY_LOG, REFUSAL_LEDGER, SESSION_RECEIPTS],
    ["graphql_ops", "send_as_account", "account_sync", "slow_query_log", "refusal_ledger", "session_receipts"]
  );
  const health: Health = { ...base, api: { graphql_ops: true, refusal_ledger: true } };
  assert.equal(hasCapability(health, GRAPHQL_OPS), true);
  assert.equal(hasCapability(health, SLOW_QUERY_LOG), false);
});

test("the 0.14 names are the gateway's own: the Kafka backbone and the cluster", () => {
  assert.deepEqual(
    [KAFKA_BACKBONE, NODE_IDENTITY, VENDOR_LEASES, QUEUE_PEEK, TOPIC_LAG],
    ["kafka_backbone", "node_identity", "vendor_leases", "queue_peek", "topic_lag"]
  );
  const health: Health = { ...base, api: { graphql_ops: true, kafka_backbone: true, node_identity: true } };
  assert.equal(hasCapability(health, KAFKA_BACKBONE), true);
  assert.equal(hasCapability(health, NODE_IDENTITY), true);
  assert.equal(hasCapability(health, VENDOR_LEASES), false, "a 0.14 gateway built without leases says so");
  //a 0.13 gateway has none of them, and the Nodes page and broker card say so rather than guessing
  assert.equal(hasCapability({ ...base, api: { graphql_ops: true } }, KAFKA_BACKBONE), false);
});
