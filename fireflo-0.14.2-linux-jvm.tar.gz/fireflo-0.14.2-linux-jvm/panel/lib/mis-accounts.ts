import { BILLING_KEY } from "@/lib/billing-key";
import { configQuery, inTransaction } from "@/lib/config-db";
import { ensureCustomerUser } from "@/lib/users";
import { disconnectBindsFor } from "@/lib/gateway-sessions";
import type { AccountSummary } from "@/lib/account-types";
import type { ChildAccountWrite } from "@/lib/mis-account-rules";

/**
 * The accounts a reseller holds beneath it, and the only writes it may make to them.
 *
 * <p>Server-only. Deliberately <strong>not</strong> `lib/accounts.ts`, which is the operator's
 * whole-row editor — a customer path that could reach `saveAccount` could reach `resells`,
 * `parent_account_id` and any id at all with it. Separate module, separate rules, mirroring why
 * `lib/mis-credentials.ts` is separate from `lib/credentials.ts` and `lib/mis-whitelist.ts` from
 * `lib/whitelist.ts`.
 *
 * <p>The field narrowing lives in `lib/mis-account-rules.ts`, which has no database import and is
 * where the tests are. This file is the query and the transaction.
 *
 * <h2>The one join that must never appear here</h2>
 *
 * <p><strong>`account_balance`.</strong> `lib/accounts.ts` gives the reason at length: it is the
 * gateway's hot path, reserved and debited per message, and a `LEFT JOIN` from a list would put a
 * scan across it in contention with the money path on every page load. A reseller with fifty
 * children would do exactly that. The portal reads one balance for one account through
 * `getBalance`, on demand, and this list carries none.
 *
 * <h2>Why the rows come back as `AccountSummary`</h2>
 *
 * <p>Because the portal renders the operator's own account components — see `lib/panel-surface.ts`.
 * They read `AccountSummary`, so this returns it, and the two fields a reseller has no business
 * seeing come back as zero rather than as a number: see the notes on each below.
 */

interface ChildRow {
  id: string;
  label: string | null;
  description: string | null;
  enabled: boolean;
  email: string | null;
  updated_at: Date | null;
  credential_count: number;
  collides: boolean;
}

/**
 * Every account beneath this reseller.
 *
 * <p>The credential count is computed through {@link BILLING_KEY} rather than from `account_id`
 * alone, for the reason that module exists: a login with a blank account bills to its system id, so
 * it belongs to that account even though the column is null. Counting the column raw would show a
 * child zero logins when it has three — and on this surface that number is what tells a reseller
 * whether the customer it just created can send at all.
 */
export async function listChildren(resellerId: string): Promise<AccountSummary[]> {
  const rows = await configQuery<ChildRow>(
    `SELECT a.id, a.label, a.description, a.enabled, a.email, a.updated_at,
            COALESCE(c.creds, 0)::int AS credential_count,
            EXISTS (SELECT 1 FROM app_worker w
                     WHERE w.type = 'smppclient' AND w.name = a.id) AS collides
       FROM app_account a
       LEFT JOIN (SELECT ${BILLING_KEY} AS acct, count(*) AS creds
                    FROM app_credential GROUP BY 1) c ON c.acct = a.id
      WHERE a.parent_account_id = $1
      ORDER BY a.id`,
    [resellerId]
  );
  return rows.map((row) => ({
    id: row.id,
    label: row.label,
    description: row.description,
    enabled: row.enabled,
    email: row.email,
    //both pinned by the schema for anything under a reseller: a CHECK stops a child reselling, so
    //it can hold nothing and there is no count to take
    resells: false,
    childCount: 0,
    parentAccountId: resellerId,
    updatedAt: row.updated_at ? new Date(row.updated_at).toISOString() : null,
    credentialCount: Number(row.credential_count ?? 0),
    //not queried, not returned. `app_rate_rule` is the price this reseller's customer is charged,
    //and even the COUNT of rules is a fact about pricing -- a child with rules of its own is a
    //child on a custom tariff, which is exactly what a reseller is not shown. The column that
    //would render it is filtered out of the reseller's catalogue too; this is the second lock
    ruleCount: 0,
    collidesWithVendor: row.collides,
  }));
}

/**
 * One child, or null. The caller has already proved it is this reseller's through `assertInScope`;
 * the `parent_account_id` predicate here is the second lock, not the first.
 */
export async function getChild(
  resellerId: string,
  id: string
): Promise<AccountSummary | null> {
  const all = await listChildren(resellerId);
  return all.find((a) => a.id === id) ?? null;
}

/**
 * Every id already spoken for, accounts and vendors together.
 *
 * <p>Both, because `app_rate_rule.scope` holds them in one column — an account sharing a vendor's
 * name makes the rate scope ambiguous, which is the condition `listAccounts` surfaces as
 * `collidesWithVendor`. Reported to the reseller before the row exists rather than after.
 *
 * <p>Returns every account id on the platform, which is more than this reseller may see. That is
 * safe and deliberate: the list never leaves the server. `childIdProblem` answers "is this taken",
 * which is one bit, and it is the same bit the primary key would answer by refusing the insert.
 */
export async function takenAccountIds(): Promise<string[]> {
  const rows = await configQuery<{ id: string }>(
    `SELECT id FROM app_account
      UNION
     SELECT name AS id FROM app_worker WHERE type = 'smppclient'`
  );
  return rows.map((r) => r.id);
}

/**
 * Creates one account beneath this reseller.
 *
 * <p><strong>`parent_account_id` and `resells` are literals here, not parameters.</strong> They are
 * the two fields that decide where the account sits in the tree, and writing them as constants means
 * no request body can reach them however this function is later called. The database would refuse a
 * bad tree anyway — a composite foreign key forces a parent to be a reseller and a CHECK caps it at
 * two levels — but that refusal protects the *shape* of the tree, not against a reseller naming
 * somebody else as the parent.
 *
 * <p>Insert, not upsert. `saveAccount` is an upsert because an operator adopting an orphan and
 * renaming an account are the same write; neither is a thing a reseller does, and an upsert here
 * would let a create silently take over an existing account.
 */
export async function createChild(
  resellerId: string,
  input: ChildAccountWrite
): Promise<void> {
  await configQuery(
    `INSERT INTO app_account (id, label, description, email, enabled, resells,
                              parent_account_id, updated_at)
     VALUES ($1, $2, $3, $4, $5, FALSE, $6, now())`,
    [input.id, input.label, input.description, input.email, input.enabled, resellerId]
  );
  //the address is also the child's first portal login. After the row: app_user.account_id is a
  //foreign key to it
  await ensureCustomerUser(input.id, input.email);
}

/**
 * Renames one child, and nothing else.
 *
 * <p>The `SET` list is the whole boundary: `resells`, `parent_account_id` and `id` are not in it, so
 * they cannot move. The `WHERE` carries the parent as well as the id — belt and braces over
 * `assertInScope`, and the thing that makes a stale id from a page open across a reparenting a
 * no-op rather than a write to somebody else's row.
 */
export async function updateChild(
  resellerId: string,
  input: ChildAccountWrite,
  /**
   * Which of label, description and email the request carried. One it did not carry keeps its
   * stored value: a label-only save (the Settings tab's "Name this account" form, which could show
   * while the catalogue was loading) used to blank the child's email and description. Absent means
   * every field is written, as before.
   */
  present: { label: boolean; description: boolean; email: boolean } = { label: true, description: true, email: true }
): Promise<boolean> {
  const rows = await configQuery<{ id: string; email: string | null }>(
    `UPDATE app_account
        SET label = CASE WHEN $6 THEN $3 ELSE label END,
            description = CASE WHEN $7 THEN $4 ELSE description END,
            email = CASE WHEN $8 THEN $5 ELSE email END,
            updated_at = now()
      WHERE id = $1 AND parent_account_id = $2
      RETURNING id, email`,
    [input.id, resellerId, input.label, input.description, input.email, present.label, present.description, present.email]
  );
  if (rows.length) {
    //the email now on the row, which is the stored one when this request did not carry it
    await ensureCustomerUser(input.id, rows[0].email);
  }
  return rows.length > 0;
}

/** What a suspend actually did, in terms the interface can show without interpreting. */
export interface SuspendResult {
  /** Logins switched off. Zero is a real answer: a child may have none yet. */
  logins: number;
  /** Live binds dropped. Absent detail when the gateway could not be reached. */
  dropped: number;
  /** Set when the binds could not be reached — the stored change still stands. */
  problem?: string;
}

/**
 * Stops a child sending, in the order that makes each step true.
 *
 * <p><strong>`app_account.enabled` alone is not enough.</strong> Since gateway 0.9.13 it withholds
 * logins that name the account -- but only within one configuration poll, only for logins whose
 * `account_id` names it (not those billing here by the system-id fallback), and never for a bind
 * already open. A reseller who flipped that flag and believed traffic had stopped at once would
 * have been told less than the truth -- which is why suspending is three steps and not one.
 *
 * <ol>
 *   <li>Disable the logins. Selected by {@link BILLING_KEY}, never by `account_id` raw, or a login
 *       billing to this account by the system-id fallback is missed and keeps sending.</li>
 *   <li>Drop the binds those logins are already holding. `enabled = false` is a statement about
 *       future binds only — see `lib/gateway-sessions.ts`. Best effort: an unreachable gateway is
 *       reported, never a reason to fail a write that has already landed.</li>
 *   <li>Unlist the account. Last, because it is the part that changes nothing operational.</li>
 * </ol>
 *
 * <p>The caller must repeat the propagation window: the gateway reloads credentials on
 * `smsg.config.db.poll.seconds` (30 by default), so a disabled login may still bind for up to that
 * long. Dropping the binds is what closes most of that gap; it does not close all of it.
 */
export async function suspendChild(
  resellerId: string,
  id: string
): Promise<SuspendResult> {
  const disabled = await inTransaction(async (client) => {
    //re-proved inside the transaction rather than trusted from the caller's earlier check: between
    //assertInScope and here an operator may have moved this account to another reseller
    const owned = await client.query<{ id: string }>(
      "SELECT id FROM app_account WHERE id = $1 AND parent_account_id = $2 FOR UPDATE",
      [id, resellerId]
    );
    if (!owned.rows.length) {
      return null;
    }
    const logins = await client.query<{ system_id: string | null; type: string }>(
      `UPDATE app_credential
          SET enabled = FALSE, updated_at = now()
        WHERE enabled AND ${BILLING_KEY} = $1
        RETURNING system_id, type`,
      [id]
    );
    await client.query(
      "UPDATE app_account SET enabled = FALSE, updated_at = now() WHERE id = $1",
      [id]
    );
    return logins.rows;
  });

  if (disabled === null) {
    return { logins: 0, dropped: 0, problem: "That account is no longer yours to suspend." };
  }

  let dropped = 0;
  let problem: string | undefined;
  //SMPP only: an HTTP login holds no session to drop, and asking about one would be a round trip
  //to the gateway per credential for an answer that is always zero
  for (const login of disabled.filter((l) => l.type === "SMPP" && l.system_id)) {
    const teardown = await disconnectBindsFor(login.system_id as string);
    dropped += teardown.dropped;
    problem ??= teardown.problem;
  }
  return { logins: disabled.length, dropped, problem };
}

/**
 * Lists the account again and re-enables its logins.
 *
 * <p>The mirror of suspend, minus the binds — those are not restored, the customer reconnects. Only
 * logins this reseller's suspend switched off could be re-enabled, but nothing records which those
 * were, so this re-enables every login billing to the child. That is the honest reading of "resume":
 * a login an operator disabled for its own reasons is a login an operator should not have left
 * indistinguishable from a suspended one, and the alternative — a per-login "who disabled this"
 * column — is a schema change for a case that has not happened.
 */
export async function resumeChild(resellerId: string, id: string): Promise<number> {
  return inTransaction(async (client) => {
    const owned = await client.query<{ id: string }>(
      "SELECT id FROM app_account WHERE id = $1 AND parent_account_id = $2 FOR UPDATE",
      [id, resellerId]
    );
    if (!owned.rows.length) {
      return 0;
    }
    const logins = await client.query(
      `UPDATE app_credential
          SET enabled = TRUE, updated_at = now()
        WHERE NOT enabled AND ${BILLING_KEY} = $1`,
      [id]
    );
    await client.query(
      "UPDATE app_account SET enabled = TRUE, updated_at = now() WHERE id = $1",
      [id]
    );
    return logins.rowCount ?? 0;
  });
}

/**
 * How much postpaid credit this reseller may still commit, and to whom it has already committed it.
 *
 * <p><strong>Aggregate, not per child.</strong> A cap of "each child's limit must fit under mine" is
 * one grant away from useless: a reseller with a 10,000 line could put five children on 10,000 each
 * and have underwritten 50,000. A limit is a promise that somebody covers the usage, and there is
 * only one balance behind all of these promises, so the sum is the thing that has to fit.
 *
 * <p>The target child's own current limit is <strong>excluded</strong>, because the write replaces
 * it rather than adding to it. Counting it would make re-saving an unchanged limit fail, which is
 * the classic off-by-one in a rule like this.
 *
 * <p>Only `POSTPAID` children are counted. A prepaid child's `credit_limit` is zero by the database's
 * own `ck_account_balance_limit`, so including them would be harmless — and excluding them says what
 * is meant, which is that only a credit line consumes a credit line.
 *
 * @param exclude the child about to be written, whose existing limit is being replaced
 */
export async function postpaidHeadroom(
  resellerId: string,
  exclude: string
): Promise<{ own: number; committed: number; headroom: number }> {
  const rows = await configQuery<{ own: string | null; committed: string }>(
    `SELECT (SELECT credit_limit FROM account_balance
              WHERE account_id = $1 AND billing_mode = 'POSTPAID')::text AS own,
            COALESCE(SUM(b.credit_limit), 0)::text AS committed
       FROM app_account a
       JOIN account_balance b ON b.account_id = a.id
      WHERE a.parent_account_id = $1
        AND b.billing_mode = 'POSTPAID'
        AND a.id <> $2`,
    [resellerId, exclude]
  );
  const own = Number(rows[0]?.own ?? 0);
  const committed = Number(rows[0]?.committed ?? 0);
  //never negative: an operator can lower a reseller's own limit below what it has already granted,
  //and the honest reading of that is "no room left", not "room owed back"
  return { own, committed, headroom: Math.max(0, own - committed) };
}
