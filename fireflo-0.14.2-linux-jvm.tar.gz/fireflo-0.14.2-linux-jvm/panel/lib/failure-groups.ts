/**
 * The dashboard's two failure views from one per-account breakdown: the reasons list (accounts summed
 * back together, so dismissals keep their key) and the failures-by-account ring.
 *
 * <p>No database import, so it is unit tested and usable from a client component.
 */

export interface FailureCell {
  finalState: string;
  dlrState: number | null;
  errCode: string | null;
  account?: string | null;
  messages: number;
  lastSeen: string;
}

/** The same failure kind as `failureKey` in `failure-dismissals.ts`. */
export function reasonKey(row: Pick<FailureCell, "finalState" | "dlrState" | "errCode">): string {
  return `${row.finalState}|${row.dlrState ?? ""}|${row.errCode ?? ""}`;
}

/** One row per failure kind, the accounts summed, newest `lastSeen` kept; largest first. */
export function byReason<T extends FailureCell>(rows: readonly T[]): T[] {
  const kinds = new Map<string, T>();
  for (const row of rows) {
    const key = reasonKey(row);
    const seen = kinds.get(key);
    if (!seen) {
      kinds.set(key, { ...row, account: undefined });
      continue;
    }
    seen.messages += row.messages;
    if (row.lastSeen > seen.lastSeen) {
      seen.lastSeen = row.lastSeen;
    }
  }
  return [...kinds.values()].sort((a, b) => b.messages - a.messages);
}

/** One account's slice of the inner ring, with its reasons for the outer ring, largest first. */
export interface AccountFailures {
  /** The account id, or null for the folded "Other" slice. */
  account: string | null;
  /** How many accounts the slice stands for: 1, or the number folded into "Other". */
  accounts: number;
  messages: number;
  reasons: { key: string; row: FailureCell; messages: number }[];
}

/**
 * The failures-by-account ring: the `top` accounts with the most failures, the rest folded into one
 * "Other" slice so the ring stays readable. Each slice carries its reasons for the outer ring.
 */
export function byAccount(rows: readonly FailureCell[], top = 4): AccountFailures[] {
  const accounts = new Map<string, FailureCell[]>();
  for (const row of rows) {
    const id = row.account ?? "";
    const list = accounts.get(id);
    if (list) {
      list.push(row);
    } else {
      accounts.set(id, [row]);
    }
  }
  const slices = [...accounts.entries()]
    .map(([id, list]) => ({ id, list, messages: list.reduce((n, r) => n + r.messages, 0) }))
    .sort((a, b) => b.messages - a.messages || a.id.localeCompare(b.id));
  const shown = slices.length > top + 1 ? slices.slice(0, top) : slices;
  const rest = slices.slice(shown.length);
  const slice = (id: string | null, list: FailureCell[], count: number): AccountFailures => ({
    account: id,
    accounts: count,
    messages: list.reduce((n, r) => n + r.messages, 0),
    reasons: byReason(list).map((row) => ({ key: reasonKey(row), row, messages: row.messages })),
  });
  const out = shown.map((s) => slice(s.id || null, s.list, 1));
  if (rest.length) {
    out.push(slice(null, rest.flatMap((s) => s.list), rest.length));
  }
  return out;
}
