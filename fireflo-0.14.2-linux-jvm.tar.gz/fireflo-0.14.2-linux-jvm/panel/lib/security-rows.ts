import type { RefusalSummaryRow } from "./ban-rules.ts";
import type { BindHold } from "./force-disconnect.ts";
import type { BlockedAddress, SecurityEvent, SecuritySurface } from "./security-events.ts";
import { displayIp } from "./security-grouping.ts";

/**
 * The Security page's one row per address, merged from everything the page knows about it.
 *
 * <p>Two sources describe the same refusals. The log tail (`events`) is parsed lines from the
 * gateway's refusal log and the panel's own, and covers every surface -- SMPP, REST, the operator
 * panel, the customer portal. The ledger (`refusalSummary`, gateway 0.13+) is the gateway's own
 * fold of its refusals by listener and address, with the hold beside each row, and it is what a ban
 * rule evaluates. Shown as two tables they disagreed in small ways -- the tail is capped at a few
 * thousand lines, the ledger does not know the panel -- and an operator had to read both to find
 * one address. Here they are one row: the address, every port it was refused on, every reason,
 * every name it tried, and the two states (blocked by fail2ban, held out by an operator) that say
 * what has already been done about it.
 *
 * <p>Pure. The page hands in what it fetched and gets rows back, so the merge and the filters are
 * tested without a browser.
 */

/** What `/api/control/security/refusals` answers. */
export interface LedgerPayload {
  listeners: RefusalSummaryRow[];
  windowMinutes: number;
  jails: string[];
  fail2banAvailable: boolean;
}

/** One listener an address was refused on, and how often. */
export interface PortRef {
  listener: string | null;
  port: number | null;
  count: number;
}

export interface AddressRow {
  /** As a person reads it: `::ffff:` stripped, so both spellings of an IPv4 client are one row. */
  ip: string;
  /**
   * Refusals in the range. The larger of the two sources' counts: the tail can be truncated and
   * the ledger does not see the panel, so each can be the one that undercounts.
   */
  attempts: number;
  bySurface: Record<SecuritySurface, number>;
  /** The listeners it was refused on, busiest first; empty on an older gateway with no ledger. */
  ports: PortRef[];
  /** Reason tokens with counts, busiest first. */
  reasons: { reason: string; count: number }[];
  /** The names it tried, most-tried first. Attempted names, never identities. */
  triedAs: string[];
  firstAt: string | null;
  lastAt: string | null;
  /** An operator's bind hold is in force on this address. */
  heldOut: boolean;
  /** The hold itself when one names this address, so the row can lift it. */
  hold: BindHold | null;
  /** The fail2ban ban in force, or null. */
  blocked: BlockedAddress | null;
  /** Whether a live SMPP watch makes sense: it was refused on an SMPP listener. */
  canWatch: boolean;
}

export interface RowFilter {
  surface?: SecuritySurface | "all";
  /** A listener's worker name, or null for every listener. */
  listener?: string | null;
  /** One reason token, or null for every reason. */
  reason?: string | null;
}

/** The jails FireFlo installs, for a gateway whose ledger cannot say. The server's list is the same. */
export const FALLBACK_JAILS: readonly string[] = ["fireflo-gateway", "fireflo-panel"];

/** Which surface a ledger row belongs to: the gateway names an SMPP listener and leaves REST unnamed. */
export function surfaceOfLedgerRow(row: Pick<RefusalSummaryRow, "listener">): SecuritySurface {
  return row.listener ? "smpp" : "rest";
}

/** "smppserver.main :2775", or the port alone when the gateway named no listener. */
export function portLabel(ref: Pick<PortRef, "listener" | "port">): string {
  const port = ref.port != null ? `:${ref.port}` : "";
  return ref.listener ? `${ref.listener} ${port}`.trim() : port ? `rest ${port}` : "rest";
}

/** The events that pass the filter: what the "Every attempt" tab lists. */
export function attemptsFrom(events: readonly SecurityEvent[], filter: RowFilter = {}): SecurityEvent[] {
  const surface = filter.surface && filter.surface !== "all" ? filter.surface : null;
  return events.filter((e) => {
    if (surface && e.surface !== surface) {
      return false;
    }
    if (filter.listener && e.listener !== filter.listener) {
      return false;
    }
    if (filter.reason && e.reason !== filter.reason) {
      return false;
    }
    return true;
  });
}

/** The ledger rows that pass the filter: the right listener, on the right surface. */
export function ledgerRowsFrom(ledger: readonly RefusalSummaryRow[], filter: RowFilter = {}): RefusalSummaryRow[] {
  const surface = filter.surface && filter.surface !== "all" ? filter.surface : null;
  return ledger.filter((row) => {
    if (surface && surfaceOfLedgerRow(row) !== surface) {
      return false;
    }
    if (filter.listener && row.listener !== filter.listener) {
      return false;
    }
    return true;
  });
}

interface Building {
  ip: string;
  eventCount: number;
  ledgerCount: number;
  bySurface: Record<SecuritySurface, number>;
  ports: Map<string, PortRef>;
  eventReasons: Map<string, number>;
  ledgerReasons: Map<string, number>;
  names: Map<string, number>;
  identities: string[];
  firstAt: string | null;
  lastAt: string | null;
  heldOut: boolean;
}

/**
 * One row per address, busiest first, from both sources and both states.
 *
 * @param events the refusals in the page's range, every surface
 * @param ledger the gateway's fold for the same range, or null on a gateway without one
 * @param blocked who fail2ban is blocking now
 * @param holds the bind holds in force
 */
export function addressRowsFrom(
  events: readonly SecurityEvent[],
  ledger: readonly RefusalSummaryRow[] | null,
  blocked: readonly BlockedAddress[],
  holds: readonly BindHold[],
  filter: RowFilter = {}
): AddressRow[] {
  const building = new Map<string, Building>();
  const get = (raw: string): Building => {
    const ip = displayIp(raw);
    let b = building.get(ip);
    if (!b) {
      b = {
        ip,
        eventCount: 0,
        ledgerCount: 0,
        bySurface: { smpp: 0, rest: 0, panel: 0, portal: 0 },
        ports: new Map(),
        eventReasons: new Map(),
        ledgerReasons: new Map(),
        names: new Map(),
        identities: [],
        firstAt: null,
        lastAt: null,
        heldOut: false,
      };
      building.set(ip, b);
    }
    return b;
  };
  const seen = (b: Building, at: string | null) => {
    if (!at) {
      return;
    }
    if (!b.firstAt || before(at, b.firstAt)) {
      b.firstAt = at;
    }
    if (!b.lastAt || before(b.lastAt, at)) {
      b.lastAt = at;
    }
  };

  for (const e of attemptsFrom(events, filter)) {
    const b = get(e.ip);
    b.eventCount += 1;
    b.bySurface[e.surface] += 1;
    b.eventReasons.set(e.reason, (b.eventReasons.get(e.reason) ?? 0) + 1);
    if (e.triedAs) {
      b.names.set(e.triedAs, (b.names.get(e.triedAs) ?? 0) + 1);
    }
    if (e.listener !== undefined || e.port !== undefined) {
      const key = `${e.listener ?? ""}|${e.port ?? ""}`;
      const ref = b.ports.get(key) ?? { listener: e.listener ?? null, port: e.port ?? null, count: 0 };
      ref.count += 1;
      b.ports.set(key, ref);
    }
    seen(b, e.at);
  }

  for (const row of ledgerRowsFrom(ledger ?? [], filter)) {
    for (const address of row.byAddress) {
      //with a reason filter the address counts for that reason alone, and drops out without it
      const count = filter.reason
        ? (address.byReason.find((r) => r.reason === filter.reason)?.count ?? 0)
        : address.count;
      if (count <= 0) {
        continue;
      }
      const b = get(address.ip);
      b.ledgerCount += count;
      b.heldOut = b.heldOut || address.heldOut;
      const key = `${row.listener ?? ""}|${row.port ?? ""}`;
      const ref = b.ports.get(key) ?? { listener: row.listener, port: row.port, count: 0 };
      //the ledger's count for this listener is the truth for the chip; a tail count already there
      //is at most the same refusals seen twice
      ref.count = Math.max(ref.count, count);
      b.ports.set(key, ref);
      for (const { reason, count: n } of address.byReason) {
        if (filter.reason && reason !== filter.reason) {
          continue;
        }
        b.ledgerReasons.set(reason, (b.ledgerReasons.get(reason) ?? 0) + n);
      }
      for (const identity of address.identities) {
        if (!b.identities.includes(identity)) {
          b.identities.push(identity);
        }
      }
      seen(b, address.firstAt);
      seen(b, address.lastAt);
    }
  }

  const blockedByIp = new Map<string, BlockedAddress>();
  for (const b of blocked) {
    blockedByIp.set(displayIp(b.ip), b);
  }
  const holdByIp = new Map<string, BindHold>();
  for (const h of holds) {
    if (h.kind === "ip" && !holdByIp.has(displayIp(h.value))) {
      holdByIp.set(displayIp(h.value), h);
    }
  }

  const rows: AddressRow[] = [];
  for (const b of building.values()) {
    const reasons = new Map<string, number>();
    for (const [reason, n] of b.eventReasons) {
      reasons.set(reason, n);
    }
    for (const [reason, n] of b.ledgerReasons) {
      reasons.set(reason, Math.max(reasons.get(reason) ?? 0, n));
    }
    const triedAs = [...b.names.entries()].sort((x, y) => y[1] - x[1]).map(([name]) => name);
    for (const identity of b.identities) {
      if (!triedAs.includes(identity)) {
        triedAs.push(identity);
      }
    }
    const ports = [...b.ports.values()].sort((x, y) => y.count - x.count);
    const hold = holdByIp.get(b.ip) ?? null;
    rows.push({
      ip: b.ip,
      attempts: Math.max(b.eventCount, b.ledgerCount),
      bySurface: b.bySurface,
      ports,
      reasons: [...reasons].map(([reason, count]) => ({ reason, count })).sort((x, y) => y.count - x.count || x.reason.localeCompare(y.reason)),
      triedAs,
      firstAt: b.firstAt,
      lastAt: b.lastAt,
      heldOut: b.heldOut || hold !== null,
      hold,
      blocked: blockedByIp.get(b.ip) ?? null,
      canWatch: b.bySurface.smpp > 0 || ports.some((p) => p.listener != null),
    });
  }
  return rows.sort(
    (x, y) => y.attempts - x.attempts || (before(x.lastAt ?? "", y.lastAt ?? "") ? 1 : x.lastAt === y.lastAt ? 0 : -1) || x.ip.localeCompare(y.ip)
  );
}

/** Every reason either source carries in the range, busiest first, for the Reason filter. */
export function reasonOptions(events: readonly SecurityEvent[], ledger: readonly RefusalSummaryRow[] | null): { reason: string; count: number }[] {
  const fromEvents = new Map<string, number>();
  for (const e of events) {
    fromEvents.set(e.reason, (fromEvents.get(e.reason) ?? 0) + 1);
  }
  const fromLedger = new Map<string, number>();
  for (const row of ledger ?? []) {
    for (const { reason, count } of row.byReason) {
      fromLedger.set(reason, (fromLedger.get(reason) ?? 0) + count);
    }
  }
  const totals = new Map<string, number>(fromEvents);
  for (const [reason, count] of fromLedger) {
    totals.set(reason, Math.max(totals.get(reason) ?? 0, count));
  }
  return [...totals].map(([reason, count]) => ({ reason, count })).sort((a, b) => b.count - a.count || a.reason.localeCompare(b.reason));
}

/** Every named listener either source saw, for the Port filter: the ledger's first, then the tail's. */
export function listenerOptions(events: readonly SecurityEvent[], ledger: readonly RefusalSummaryRow[] | null): PortRef[] {
  const out = new Map<string, PortRef>();
  for (const row of ledger ?? []) {
    if (row.listener) {
      out.set(row.listener, { listener: row.listener, port: row.port, count: row.total });
    }
  }
  for (const e of events) {
    if (e.listener && !out.has(e.listener)) {
      out.set(e.listener, { listener: e.listener, port: e.port ?? null, count: 0 });
    }
  }
  return [...out.values()];
}

/**
 * Whether `a` is earlier than `b`. By instant when both parse, else by string -- the gateway's log
 * lines carry a local time with no zone, which still orders correctly against each other.
 */
function before(a: string, b: string): boolean {
  const x = Date.parse(a);
  const y = Date.parse(b);
  if (Number.isFinite(x) && Number.isFinite(y)) {
    return x < y;
  }
  return a < b;
}
