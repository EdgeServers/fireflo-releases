import { test } from "node:test";
import assert from "node:assert/strict";
import { DEFAULT_PINS, MAX_PINS, isPinnedPath, pinnablePath, readPins, togglePin } from "./pins.ts";

test("nothing saved is the four defaults; a mangled entry is the defaults too", () => {
  assert.deepEqual(readPins(null), DEFAULT_PINS);
  assert.deepEqual(readPins("not json"), DEFAULT_PINS);
  assert.deepEqual(readPins('{"href":"/cp/cdrs"}'), DEFAULT_PINS);
  //an operator who unpinned everything keeps an empty bar
  assert.deepEqual(readPins("[]"), []);
});

test("only operator pages survive, once each, at most four, labels tidied", () => {
  const raw = JSON.stringify([
    { href: "/cp/cdrs?vendor=x", label: "  Messages  ", pinnedAt: 5 },
    { href: "/cp/cdrs", label: "Again", pinnedAt: 6 },
    { href: "https://evil.example/cp/x", label: "Off-site", pinnedAt: 1 },
    { href: "//evil.example", label: "Protocol-relative", pinnedAt: 1 },
    { href: "/portal/messages", label: "Portal", pinnedAt: 1 },
    { href: "/cp/vendors", label: "", pinnedAt: 1 },
    { href: "/cp/a", label: "A" }, { href: "/cp/b", label: "B" }, { href: "/cp/c", label: "C" }, { href: "/cp/d", label: "D" },
  ]);
  const pins = readPins(raw);
  assert.equal(pins.length, MAX_PINS);
  assert.deepEqual(pins[0], { href: "/cp/cdrs", label: "Messages", pinnedAt: 5 });
  assert.deepEqual(pins.map((p) => p.href), ["/cp/cdrs", "/cp/a", "/cp/b", "/cp/c"]);
  assert.equal(pins[1].pinnedAt, 0);
});

test("a pin is the path only", () => {
  assert.equal(pinnablePath("/cp/cdrs?range=7d#top"), "/cp/cdrs");
  assert.equal(pinnablePath("/cp/accounts/acme/"), "/cp/accounts/acme");
  assert.equal(pinnablePath("/portal"), null);
  assert.equal(pinnablePath("javascript:alert(1)"), null);
});

test("a fifth pin replaces the oldest -- the defaults first -- and says which", () => {
  const first = togglePin(DEFAULT_PINS, { href: "/cp/database/slow-queries", label: "Slow queries" }, 100);
  assert.equal(first.dropped?.label, "Messages");
  assert.deepEqual(first.pins.map((p) => p.label), ["Vendors", "Servers", "Accounts", "Slow queries"]);
  //later pins are newer than the defaults, so the next one goes next
  const second = togglePin(first.pins, { href: "/cp/security", label: "Security" }, 200);
  assert.equal(second.dropped?.label, "Vendors");
  const third = togglePin(
    [{ href: "/cp/a", label: "A", pinnedAt: 300 }, { href: "/cp/b", label: "B", pinnedAt: 100 },
      { href: "/cp/c", label: "C", pinnedAt: 200 }, { href: "/cp/d", label: "D", pinnedAt: 400 }],
    { href: "/cp/e", label: "E" }, 500
  );
  assert.equal(third.dropped?.label, "B");
});

test("pinning a pinned page unpins it, and an unpinnable page changes nothing", () => {
  const off = togglePin(DEFAULT_PINS, { href: "/cp/vendors?x=1", label: "Vendors" }, 1);
  assert.deepEqual(off.pins.map((p) => p.href), ["/cp/cdrs", "/cp/servers", "/cp/accounts"]);
  assert.equal(off.dropped, null);
  const room = togglePin(off.pins, { href: "/cp/security", label: "Security" }, 2);
  assert.equal(room.dropped, null);
  assert.equal(room.pins.length, 4);
  assert.equal(togglePin(DEFAULT_PINS, { href: "/portal/x", label: "X" }, 1).pins, DEFAULT_PINS);
  assert.ok(isPinnedPath(DEFAULT_PINS, "/cp/cdrs?range=7d"));
  assert.ok(!isPinnedPath(DEFAULT_PINS, "/cp/cdrs/123"));
});
