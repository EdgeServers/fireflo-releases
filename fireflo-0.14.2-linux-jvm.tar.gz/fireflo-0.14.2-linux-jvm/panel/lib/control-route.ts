/**
 * Thrown by a stats reader whose answer is not ready yet, rather than wrong: the route answers 503
 * with the message, and the client's next poll asks again.
 *
 * <p>This module used to hold `controlRoute`, the per-metric route wrapper; every stats route now
 * goes through `statsRoute` (`lib/stats-route.ts`), and only this error is left here so its
 * importers did not move.
 */
export class ServiceUnavailableError extends Error {}
