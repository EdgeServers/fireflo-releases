/**
 * Hands out a number per request and says whether an answer is still the one wanted: only the
 * newest request's answer may land. A late answer for a period the user has already switched away
 * from is dropped, rather than painted over the one they asked for.
 */
export class LatestWins {
  private seq = 0;

  /** Start a request; the returned ticket supersedes every earlier one. */
  begin(): number {
    this.seq += 1;
    return this.seq;
  }

  /** Whether `ticket` is still the newest request. */
  isCurrent(ticket: number): boolean {
    return ticket === this.seq;
  }
}
