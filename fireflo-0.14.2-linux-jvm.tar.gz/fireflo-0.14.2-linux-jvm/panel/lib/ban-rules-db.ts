import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import path from "node:path";
import { type BanRule, normaliseRule } from "@/lib/ban-rules";
import { exportDir } from "@/lib/data-dir";
import { FIREFLO_JAILS } from "@/lib/security-sources";

/**
 * Where the ban rules and their run log live: two files in the panel's data directory.
 *
 * <p>A file rather than a table, deliberately. The rules are a fact about THIS host's fail2ban --
 * which jails exist, which listener is public -- and a panel whose database is shared with a
 * second panel on another host must not run that host's rules. The data directory is per install
 * (`ReadWritePaths=` in the unit covers it), which is exactly the scope a ban rule has.
 *
 * <p>Server-only. A sibling of the exports and the access log, so every existing install already
 * has the directory and the write permission -- see `accessLogDir` for why the directory is derived
 * from `CDR_EXPORT_DIR` rather than configured.
 */

export function securityDir(): string {
  return path.resolve(exportDir(), "..", "security");
}

function rulesFile(): string {
  return path.join(securityDir(), "ban-rules.json");
}

function runsFile(): string {
  return path.join(securityDir(), "ban-rule-runs.jsonl");
}

/** How many run-log lines are kept. One rule banning once a minute fills this in eight hours. */
export const MAX_RUN_ENTRIES = 500;

/** One thing a rule run did, or decided not to do, about one address. */
export interface BanRunEntry {
  at: string;
  rule: string;
  ip: string;
  jail: string;
  dryRun: boolean;
  /** True when fail2ban was asked and answered; false for a dry run, a skip, or a failure. */
  banned: boolean;
  /** Why not, when not banned; null when it was. */
  error: string | null;
  /** The arithmetic, for the operator reading the log. */
  reason: string;
}

export async function readBanRules(): Promise<BanRule[]> {
  let text: string;
  try {
    text = await readFile(/*turbopackIgnore: true*/ rulesFile(), "utf8");
  } catch {
    //no file yet is the ordinary state of an install that has never set a rule
    return [];
  }
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    console.error(`ban rules: ${rulesFile()} is not JSON; treating it as no rules`);
    return [];
  }
  const rows = Array.isArray((parsed as { rules?: unknown })?.rules) ? (parsed as { rules: unknown[] }).rules : [];
  const out: BanRule[] = [];
  for (const row of rows) {
    //a rule the file holds that no longer normalises -- a jail removed, a limit tightened -- is
    //dropped on read rather than crashing the runner; the PUT that replaces the file will not
    //write it back
    const rule = normaliseRule(row, FIREFLO_JAILS);
    if (!("error" in rule)) {
      out.push(rule);
    }
  }
  return out;
}

/**
 * Replaces the whole set.
 *
 * <p>Written beside and renamed over, so a crash mid-write leaves the previous file rather than
 * half of the new one; the runner reads this once a minute and half a JSON file is no rules.
 */
export async function writeBanRules(rules: readonly BanRule[]): Promise<void> {
  await mkdir(/*turbopackIgnore: true*/ securityDir(), { recursive: true });
  const file = rulesFile();
  const tmp = `${file}.${process.pid}.tmp`;
  await writeFile(/*turbopackIgnore: true*/ tmp, JSON.stringify({ rules }, null, 2) + "\n", "utf8");
  await rename(/*turbopackIgnore: true*/ tmp, file);
}

export async function readBanRuns(limit = MAX_RUN_ENTRIES): Promise<BanRunEntry[]> {
  let text: string;
  try {
    text = await readFile(/*turbopackIgnore: true*/ runsFile(), "utf8");
  } catch {
    return [];
  }
  const out: BanRunEntry[] = [];
  for (const line of text.split("\n")) {
    if (!line.trim()) {
      continue;
    }
    try {
      out.push(JSON.parse(line) as BanRunEntry);
    } catch {
      continue;
    }
  }
  //newest first, which is how a log is read
  return out.slice(-limit).reverse();
}

/**
 * Records what a run did, keeping the file to {@link MAX_RUN_ENTRIES} lines.
 *
 * <p>Rewritten rather than appended, because a bound needs the whole file anyway and the file is
 * small by construction. The same write-beside-and-rename as the rules.
 */
export async function appendBanRuns(entries: readonly BanRunEntry[]): Promise<void> {
  if (entries.length === 0) {
    return;
  }
  const existing = (await readBanRuns()).reverse();
  const kept = [...existing, ...entries].slice(-MAX_RUN_ENTRIES);
  await mkdir(/*turbopackIgnore: true*/ securityDir(), { recursive: true });
  const file = runsFile();
  const tmp = `${file}.${process.pid}.tmp`;
  await writeFile(/*turbopackIgnore: true*/ tmp, kept.map((e) => JSON.stringify(e)).join("\n") + "\n", "utf8");
  await rename(/*turbopackIgnore: true*/ tmp, file);
}
