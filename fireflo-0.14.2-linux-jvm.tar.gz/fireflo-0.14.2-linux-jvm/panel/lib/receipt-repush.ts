/**
 * Re-sending delivery receipts to an SMPP login for a period: the form, the request the gateway is
 * sent, how its dry run and job status are read, and what the dialog says.
 *
 * <p>Pure and client-safe, like `queue-clean.ts`. <strong>Every field name of the gateway's re-push
 * fields is spelled here and nowhere else</strong> — `repushStart` (admin token), `repushJob` (read
 * token), `repushCancel` (admin) — so a rename on that side is a change to this file.
 *
 * <p>What a re-push is, on the gateway: the receipts are rebuilt from the call records (the same
 * message id the customer was given at submit, the state from the final record), one per part, and
 * sent the live way — on the login's sessions if it is bound, otherwise stored and replayed on its
 * next bind — paced at the chosen rate. Messages still pending are skipped and counted. The customer
 * receives receipts again for messages they may already have closed; a correct SMPP client treats a
 * repeated receipt for a known message id as a no-op.
 */

/**
 * The final states a re-push can be limited to: the call records' own words, with the receipt
 * `stat` each becomes. The value is what is sent as `states`.
 */
export const REPUSH_STATES = [
  { value: "DELIVERED", stat: "DELIVRD", label: "Delivered" },
  { value: "FAILED", stat: "UNDELIV", label: "Failed" },
  { value: "EXPIRED", stat: "EXPIRED", label: "Expired" },
  { value: "REJECTED", stat: "REJECTD", label: "Rejected" },
] as const;

/** One job covers at most this; the command line splits a longer period into consecutive jobs. */
export const MAX_REPUSH_DAYS = 31;
export const DEFAULT_REPUSH_TPS = 50;
/** The gateway further caps the rate at the login's own throughput limit. */
export const MAX_REPUSH_TPS = 1_000;

/** How often the dialog asks how the job is going. */
export const REPUSH_POLL_MS = 2_000;

/** A job id as the gateway hands one out: refused otherwise, before it reaches a URL. */
export function isJobId(value: string): boolean {
  return /^[A-Za-z0-9._:-]{1,100}$/.test(value);
}

/** What the dialog holds. `since` and `until` are ISO instants, converted from the inputs. */
export interface RepushForm {
  since: string;
  until: string;
  states: string[];
  includeProgress: boolean;
  tps: string;
  note: string;
}

/** The sentence that stops a re-push being asked for, or null. */
export function repushProblem(form: RepushForm, now: Date = new Date()): string | null {
  const since = new Date(form.since);
  const until = new Date(form.until);
  if (!form.since || Number.isNaN(since.getTime())) {
    return "Choose when the period starts.";
  }
  if (!form.until || Number.isNaN(until.getTime())) {
    return "Choose when the period ends.";
  }
  if (until <= since) {
    return "The period ends before it starts.";
  }
  if (since > now) {
    return "The period starts in the future: there is nothing to re-send yet.";
  }
  const days = (until.getTime() - since.getTime()) / 86_400_000;
  if (days > MAX_REPUSH_DAYS) {
    return `That is ${Math.ceil(days)} days. One re-push covers at most ${MAX_REPUSH_DAYS}; split the period, or use the command line, which splits it for you.`;
  }
  const known = REPUSH_STATES.map((s) => s.value as string);
  if (form.states.length === 0) {
    return "Tick at least one outcome to re-send.";
  }
  if (form.states.some((s) => !known.includes(s))) {
    return "Unknown outcome.";
  }
  const tps = Number(form.tps);
  if (!Number.isInteger(tps) || tps < 1 || tps > MAX_REPUSH_TPS) {
    return `The rate is a whole number of receipts a second, 1 to ${MAX_REPUSH_TPS}.`;
  }
  if (!form.note.trim()) {
    return "Say why in the note: it is recorded with the job.";
  }
  return null;
}

/** The request body. `states` is left out when every outcome is ticked — the gateway's default. */
export interface RepushRequest {
  systemId: string;
  since: string;
  until: string;
  states?: string[];
  includeProgress?: boolean;
  tps: number;
  dryRun: boolean;
  note?: string;
  actor?: string;
}

export function repushBody(
  systemId: string,
  form: RepushForm,
  opts: { dryRun: boolean; actor?: string }
): RepushRequest {
  const body: RepushRequest = {
    systemId,
    since: new Date(form.since).toISOString(),
    until: new Date(form.until).toISOString(),
    tps: Number(form.tps),
    dryRun: opts.dryRun,
  };
  if (form.states.length && form.states.length < REPUSH_STATES.length) {
    body.states = [...form.states];
  }
  if (form.includeProgress) body.includeProgress = true;
  if (form.note.trim()) body.note = form.note.trim();
  if (opts.actor) body.actor = opts.actor;
  return body;
}

type Raw = Record<string, unknown>;
const obj = (v: unknown): Raw => (v && typeof v === "object" && !Array.isArray(v) ? (v as Raw) : {});
const pick = (r: Raw, ...keys: string[]): unknown => {
  for (const k of keys) {
    if (r[k] !== undefined && r[k] !== null) return r[k];
  }
  return undefined;
};
const numOrNull = (v: unknown): number | null => (v == null || !Number.isFinite(Number(v)) ? null : Number(v));

/** A dry run's answer: what would be sent, and whether the login is there to receive it. */
export interface RepushDryRun {
  messages: number;
  receipts: number;
  byState: Record<string, number>;
  skippedPending: number;
  /** Null when the answer does not say. */
  bound: boolean | null;
  sessions: number | null;
  /** How long the job would take at the rate asked for, in seconds. */
  seconds: number | null;
}

/**
 * The plan fixes that a dry run answers "counts by state, parts, whether the login is bound, and the
 * time the job would take", not the names; this reads the likely spellings so the dialog does not
 * break on the first one the gateway picks. Absent figures stay null and the sentence leaves them out.
 */
export function readRepushDryRun(raw: unknown): RepushDryRun {
  const r = obj(raw);
  const byStateRaw = obj(pick(r, "byState", "states", "counts"));
  const byState: Record<string, number> = {};
  for (const [k, v] of Object.entries(byStateRaw)) {
    const n = numOrNull(v);
    if (n != null) byState[k] = n;
  }
  const messages = numOrNull(pick(r, "messages", "messageCount", "total")) ?? Object.values(byState).reduce((a, b) => a + b, 0);
  const receipts = numOrNull(pick(r, "receipts", "parts", "receiptCount")) ?? messages;
  const boundRaw = pick(r, "bound", "loginBound");
  const sessions = numOrNull(pick(r, "sessions", "boundSessions"));
  return {
    messages,
    receipts,
    byState,
    skippedPending: numOrNull(pick(r, "skippedPending", "pending")) ?? 0,
    bound: typeof boundRaw === "boolean" ? boundRaw : sessions != null ? sessions > 0 : null,
    sessions,
    seconds: numOrNull(pick(r, "etaSeconds", "seconds", "durationSeconds", "estimatedSeconds")),
  };
}

/** "1,842 receipts for 1,790 messages, login bound on 2 sessions, about 37 s at 50/s". */
export function dryRunSentence(d: RepushDryRun, tps: number): string {
  const parts = [`${d.receipts.toLocaleString()} receipt${d.receipts === 1 ? "" : "s"} for ${d.messages.toLocaleString()} message${d.messages === 1 ? "" : "s"}`];
  if (d.bound === true) {
    parts.push(d.sessions != null ? `login bound on ${d.sessions} session${d.sessions === 1 ? "" : "s"}` : "login bound");
  } else if (d.bound === false) {
    parts.push("login not bound — they are stored and replayed on its next bind");
  }
  const seconds = d.seconds ?? (tps > 0 ? Math.ceil(d.receipts / tps) : null);
  if (seconds != null) {
    parts.push(`about ${humanSeconds(seconds)} at ${tps}/s`);
  }
  return parts.join(", ");
}

export function humanSeconds(seconds: number): string {
  if (seconds < 90) return `${Math.max(0, Math.round(seconds))} s`;
  if (seconds < 5_400) return `${Math.round(seconds / 60)} min`;
  return `${(seconds / 3_600).toFixed(1).replace(/\.0$/, "")} h`;
}

/** A job's progress, as `repushJob` answers it. */
export interface RepushStatus {
  state: string;
  total: number | null;
  sent: number;
  storedForReplay: number;
  skippedPending: number;
  failed: number;
  startedAt: string | null;
  /** An instant, or a number of seconds, as the gateway gave it. */
  eta: string | number | null;
}

export function readRepushStatus(raw: unknown): RepushStatus {
  const r = obj(raw);
  const eta = r.eta;
  return {
    state: typeof r.state === "string" ? r.state : "unknown",
    total: numOrNull(r.total),
    sent: numOrNull(r.sent) ?? 0,
    storedForReplay: numOrNull(r.storedForReplay) ?? 0,
    skippedPending: numOrNull(r.skippedPending) ?? 0,
    failed: numOrNull(r.failed) ?? 0,
    startedAt: typeof r.startedAt === "string" ? r.startedAt : null,
    eta: typeof eta === "string" || typeof eta === "number" ? eta : null,
  };
}

/** The job id from a started job's answer. */
export function readJobId(raw: unknown): string | null {
  const id = pick(obj(raw), "jobId", "id");
  return typeof id === "string" && isJobId(id) ? id : null;
}

/** Still going — the dialog keeps polling. Any other state is final. */
export function isRunning(state: string): boolean {
  return ["running", "queued", "pending", "starting", "cancelling"].includes(state.toLowerCase());
}

/** Of the total, how much has been dealt with: sent, stored for replay or failed. 0..100. */
export function progressPercent(s: RepushStatus): number {
  if (!s.total) {
    return isRunning(s.state) ? 0 : 100;
  }
  return Math.min(100, Math.round(((s.sent + s.storedForReplay + s.failed) / s.total) * 100));
}

export function statusLine(s: RepushStatus): string {
  const parts = [
    `${s.sent.toLocaleString()} sent`,
    `${s.storedForReplay.toLocaleString()} stored for replay`,
  ];
  if (s.skippedPending) parts.push(`${s.skippedPending.toLocaleString()} skipped (still pending)`);
  if (s.failed) parts.push(`${s.failed.toLocaleString()} failed`);
  return `${parts.join(" · ")}${s.total != null ? ` of ${s.total.toLocaleString()}` : ""}`;
}

/** What a finished job's state means to the operator. */
export function finishedSentence(s: RepushStatus): string {
  switch (s.state.toLowerCase()) {
    case "done":
    case "finished":
    case "completed":
      return "Finished.";
    case "cancelled":
    case "canceled":
      return "Cancelled. Receipts already sent stay sent.";
    case "interrupted":
    case "lost":
      return "The gateway restarted and the job did not survive it. Start again from the last receipt sent.";
    case "failed":
      return "The job stopped with an error; the gateway log has the reason.";
    default:
      return `Ended: ${s.state}.`;
  }
}

/** Where the dialog remembers a running job for this login, so reopening it resumes the progress bar. */
export function jobStorageKey(systemId: string): string {
  return `fireflo.repush.${systemId}`;
}
