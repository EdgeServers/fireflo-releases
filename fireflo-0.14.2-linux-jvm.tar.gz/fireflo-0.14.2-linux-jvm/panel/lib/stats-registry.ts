import { byReason } from "@/lib/failure-groups";
import { listArchiveAccounts, listArchiveBatches, listArchivePartitions } from "@/lib/archives";
import { isRequestError, parseArchiveAccountFilters, parseBatchFilters } from "@/lib/archives-request";
import {
  accountUsage,
  liveTraffic,
  revenueByAccount,
  revenueSeries,
  serverTraffic,
  trafficOverTime,
  usageByDay,
  vendorPerformance,
  type Range,
} from "@/lib/metrics-queries";
import { overviewFor } from "@/lib/mis-overview";
import { getOverviewRefresher } from "@/lib/overview-refresher";
import { receiptQuality } from "@/lib/receipt-queries";
import type { CustomerSession } from "@/lib/require-customer";
import type { MetricName } from "@/lib/stats-metrics";

/** What a reader is handed: the period already checked against the metric's own list. */
export interface StatsRequest {
  range: string;
  params: URLSearchParams;
}

export interface CustomerRequest extends StatsRequest {
  session: CustomerSession;
  /** The accounts this customer may see: their own and, for a reseller, those beneath it. */
  scope: string[];
}

export interface Readers {
  operator?: (req: StatsRequest) => Promise<unknown>;
  customer?: (req: CustomerRequest) => Promise<unknown>;
  /** Response headers on success, e.g. the overview's short private cache. */
  headers?: Record<string, string>;
}

/** Days per portal-overview period. */
const PORTAL_DAYS: Record<string, number> = { "7d": 7, "14d": 14, "30d": 30, "90d": 90 };

/**
 * The reader behind each metric, for each audience `stats-metrics.ts` gives it. The readers are the
 * query functions the per-metric routes always called; only the plumbing around them is shared.
 * `Record<MetricName, …>` makes a metric listed there and missing here a compile error.
 */
export const READERS: Record<MetricName, Readers> = {
  overview: {
    operator: async ({ range, params }) => {
      const refresher = getOverviewRefresher();
      const snap = await refresher.get(range as Range, { fresh: params.get("fresh") === "1" });
      return {
        totals: snap.totals,
        traffic: snap.traffic,
        failures: byReason(snap.failures),
        failuresByAccount: snap.failures,
        failuresSince: snap.failuresSince,
        vendors: snap.vendors,
        watermark: snap.watermark,
        asOf: snap.asOf,
        builtAt: snap.builtAt,
        stale: snap.stale,
        source: snap.source,
        settlingFrom: snap.settlingFrom,
        ...(params.get("debug") === "1" ? { debug: { tickMs: snap.tickMs, ...refresher.debug() } } : {}),
      };
    },
    customer: async ({ range, session, scope }) => ({
      ...(await overviewFor(scope, session.accountId, PORTAL_DAYS[range])),
      //echoed so the page says what it shows rather than assuming client and server agree
      range,
    }),
    headers: { "Cache-Control": "private, max-age=15" },
  },
  accounts: {
    operator: ({ range, params }) => accountUsage(range as Range, params),
    customer: async ({ range, scope }) => {
      const view = await accountUsage(range as Range);
      const mine = new Set(scope);
      return {
        creditEnforced: view.creditEnforced,
        //`cost` is dropped by construction rather than zeroed: a zero would read as "we pay
        //nothing for this", which is a different lie
        accounts: view.accounts
          .filter((row) => row.accountId != null && mine.has(row.accountId))
          .map(({ cost: _cost, ...row }) => row),
      };
    },
  },
  vendors: { operator: ({ range }) => vendorPerformance(range as Range) },
  receipts: { operator: ({ range }) => receiptQuality(range as Range) },
  //the range alone: revenueByAccount's second argument is a window override, not the query string
  revenue: { operator: ({ range }) => revenueByAccount(range as Range) },
  "revenue-series": { operator: ({ range }) => revenueSeries(range as Range) },
  usage: { operator: ({ range }) => usageByDay(range as Range) },
  traffic: { operator: ({ range }) => trafficOverTime(range as Range) },
  "server-traffic": { operator: ({ range, params }) => serverTraffic(range as Range, params) },
  "traffic-live": {
    operator: async ({ params }) => {
      const since = params.get("since");
      const key = params.get("key");
      return liveTraffic(params.get("kind") === "server" ? "server" : "vendor", {
        since: since ? Number(since) : null,
        key: key && key.length <= 200 ? key : null,
      });
    },
  },
  "archive-accounts": {
    operator: async ({ params }) => {
      const filters = parseArchiveAccountFilters(params);
      if (isRequestError(filters)) {
        throw new Error(filters.error);
      }
      return listArchiveAccounts(filters);
    },
  },
  "archive-batches": {
    operator: async ({ params }) => {
      const filters = parseBatchFilters(params);
      if (isRequestError(filters)) {
        throw new Error(filters.error);
      }
      return listArchiveBatches(filters);
    },
  },
  "archive-partitions": { operator: () => listArchivePartitions() },
};
