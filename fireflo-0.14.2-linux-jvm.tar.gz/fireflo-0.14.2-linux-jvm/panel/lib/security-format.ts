import type { BanRule } from "./ban-rules.ts";
import type { BanRunEntry } from "./ban-rules-db.ts";

/**
 * The words the Security page puts beside its numbers: moments, durations, a rule in a sentence,
 * the last run of the rules. Pure, and every function that needs the time takes it as `now`.
 *
 * <p>`now` is an argument rather than `Date.now()` because these run during render. Reading the
 * clock while rendering is impure -- the same row would say "today" on one render and "yesterday"
 * on the next for no change in the data -- and the page already records when its data was read,
 * which is the moment a "last seen" is honestly relative to.
 */

/**
 * @return a local, readable moment, or the raw string when it cannot be parsed -- which is honest
 *     about a line this panel did not understand rather than showing "Invalid Date"
 */
export function when(value: string | null | undefined): string {
  if (!value) {
    return "—";
  }
  const at = new Date(value);
  return Number.isNaN(at.getTime()) ? value : at.toLocaleString();
}

/**
 * A moment, short: the time when it falls on the same day as `now`, otherwise the date and time.
 * The full one belongs in the tooltip.
 */
export function short(value: string | null | undefined, now: number): string {
  if (!value) {
    return "—";
  }
  const at = new Date(value);
  if (Number.isNaN(at.getTime())) {
    return value;
  }
  const today = new Date(now).toDateString() === at.toDateString();
  return today
    ? at.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })
    : at.toLocaleString(undefined, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

/** "10 minutes", "1 hour", "36 hours", "7 days": a ban's or a hold's length, in the largest whole unit. */
export function banDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds <= 0) {
    return "the jail's default";
  }
  const unit = (n: number, word: string) => `${n} ${word}${n === 1 ? "" : "s"}`;
  if (seconds % 86_400 === 0) {
    return unit(seconds / 86_400, "day");
  }
  if (seconds % 3_600 === 0) {
    return unit(seconds / 3_600, "hour");
  }
  if (seconds % 60 === 0) {
    return unit(seconds / 60, "minute");
  }
  return unit(seconds, "second");
}

/**
 * The rule in one sentence, for the settings row that lists it:
 * "20 badPassword refusals from one address in 10 minutes on smppserver.main → ban 1 hour in fireflo-gateway".
 *
 * <p>Reason tokens are kept as tokens rather than turned into prose, because they are what the
 * editor under the row shows and what the run log records; a sentence that said "wrong passwords"
 * would have to be matched back to `badPassword` by the reader.
 */
export function ruleSentence(rule: Pick<BanRule, "threshold" | "reasons" | "windowMinutes" | "listener" | "banSeconds" | "jail">): string {
  const what = rule.reasons.length ? `${rule.reasons.join(" or ")} refusals` : "bannable refusals";
  const where = rule.listener && rule.listener !== "any" ? `on ${rule.listener}` : "on any listener";
  const minutes = `${rule.windowMinutes} minute${rule.windowMinutes === 1 ? "" : "s"}`;
  return `${rule.threshold} ${what} from one address in ${minutes} ${where} → ban ${banDuration(rule.banSeconds)} in ${rule.jail}`;
}

/** What the newest run of the rules did, folded from its entries. */
export interface LastRun {
  /** When the run happened: the newest entry's timestamp. */
  at: string;
  banned: number;
  wouldBan: number;
  notBanned: number;
}

/**
 * The newest run, read off the run log.
 *
 * <p>The log is one line per decision rather than one per run, and the runner stamps every line of
 * a run with the same moment (within a second or so of file writing), so a run is the entries
 * within a minute of the newest one. The runner evaluates once a minute, which is what makes a
 * minute the right width: two runs cannot fall inside it.
 */
export function lastRun(runs: readonly BanRunEntry[]): LastRun | null {
  let newest: number | null = null;
  let newestAt = "";
  for (const entry of runs) {
    const at = Date.parse(entry.at);
    if (Number.isFinite(at) && (newest === null || at > newest)) {
      newest = at;
      newestAt = entry.at;
    }
  }
  if (newest === null) {
    return null;
  }
  const out: LastRun = { at: newestAt, banned: 0, wouldBan: 0, notBanned: 0 };
  for (const entry of runs) {
    const at = Date.parse(entry.at);
    if (!Number.isFinite(at) || newest - at >= 60_000) {
      continue;
    }
    if (entry.banned) {
      out.banned += 1;
    } else if (entry.dryRun) {
      out.wouldBan += 1;
    } else {
      out.notBanned += 1;
    }
  }
  return out;
}

/** "last run 09:41, 0 banned · 1 would ban", or "no run recorded yet". */
export function lastRunSentence(run: LastRun | null, now: number): string {
  if (!run) {
    return "no run recorded yet";
  }
  const parts = [`${run.banned} banned`, `${run.wouldBan} would ban`];
  if (run.notBanned > 0) {
    parts.push(`${run.notBanned} not banned`);
  }
  return `last run ${short(run.at, now)}, ${parts.join(" · ")}`;
}

/** "first 3, +2" style: the first few names and how many more there are. */
export function firstFew(names: readonly string[], keep = 3): string {
  if (names.length === 0) {
    return "—";
  }
  const rest = names.length - keep;
  return names.slice(0, keep).join(", ") + (rest > 0 ? ` +${rest}` : "");
}
