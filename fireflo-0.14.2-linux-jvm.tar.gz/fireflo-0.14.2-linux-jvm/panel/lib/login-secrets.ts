import { randomInt } from "node:crypto";

/**
 * The SMPP wire limits on a login, and generators that fit them.
 *
 * <p>SMPP 3.4 carries `system_id` in 16 octets and `password` in 9, each including its NUL, so a
 * system id is at most 15 characters and a password at most 8. A longer value is not truncated by a
 * client -- it is refused, or worse, silently cut and then fails to bind with "the right" password.
 * This panel minted 32-character SMPP passwords (`mint()`, 24 bytes base64url) until 0.12.36.0.
 *
 * <p>Generated values are 8 characters each, the same as the gateway's management API
 * (`PlatformAccounts`), so a login looks the same whichever side made it.
 */
export const SMPP_SYSTEM_ID_MAX = 15;
export const SMPP_PASSWORD_MAX = 8;
export const SMPP_LOGIN_LENGTH = 8;

/** Lower case and digits: a system id is read aloud and typed into SMPP clients. */
const ID_ALPHABET = "abcdefghijklmnopqrstuvwxyz0123456789";
/** No 0/O, 1/l/I: a password is read off a screen into somebody else's client. */
const PASSWORD_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";

function pick(alphabet: string, length: number): string {
  let out = "";
  for (let i = 0; i < length; i++) {
    out += alphabet[randomInt(alphabet.length)];
  }
  return out;
}

/** An 8-character system id. The caller checks it against existing logins before using it. */
export function smppSystemId(): string {
  return pick(ID_ALPHABET, SMPP_LOGIN_LENGTH);
}

/** An 8-character SMPP password, the most the protocol's field holds. */
export function smppPassword(): string {
  return pick(PASSWORD_ALPHABET, SMPP_PASSWORD_MAX);
}
