import { test } from "node:test";
import assert from "node:assert/strict";
import { periodKey, pickPeriod } from "./period.ts";

const OPTIONS = ["1h", "24h", "7d", "30d"] as const;

test("a page opens on what its user last chose, while it is still offered", () => {
  assert.equal(pickPeriod("7d", OPTIONS, "1h"), "7d");
  //never chosen: the page's default
  assert.equal(pickPeriod(null, OPTIONS, "1h"), "1h");
  //an option a later release removed, or anything mangled, is not trusted
  assert.equal(pickPeriod("90d", OPTIONS, "1h"), "1h");
  assert.equal(pickPeriod("", OPTIONS, "1h"), "1h");
});

test("each page keeps its own choice", () => {
  assert.equal(periodKey("vendors"), "fireflo.period.vendors");
  assert.notEqual(periodKey("vendors"), periodKey("receipts"));
});
