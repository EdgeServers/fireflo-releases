import { configQuery } from "@/lib/config-db";
import { auditConfigChange } from "@/lib/config-audit";
import { assertWritableAccount } from "@/lib/account-archive";
import { assertProductsCatalogued } from "@/lib/products";
import { BILLING_KEY } from "@/lib/billing-key";
import {
  APPROVAL_INSERT,
  APPROVAL_INSERT_TEMPLATE,
  APPROVAL_SET,
  APPROVAL_SET_TEMPLATE,
} from "@/lib/whitelist-sql";
import type {
  ApprovalStatus,
  ApprovedHeader,
  ApprovedTemplate,
  HeaderInput,
  TemplateInput,
  WhitelistMode,
  WhitelistPolicy,
  WhitelistSummary,
} from "@/lib/whitelist-types";

/**
 * The three whitelist tables.
 *
 * <p>Unlike every other catalogue this panel edits, **the gateway reads these and they can refuse
 * traffic**. `app_product`, `app_tlv_definition` and `app_account` are all inert by design; a row
 * written here stops a customer's messages within one configuration poll. Nothing in this module
 * gets to be casual about that, which is why the delete and the mode change are separate operations
 * and why the summary carries counts the UI needs in order to warn before enforcing.
 */

interface PolicyRow {
  account_id: string;
  product: string;
  header_mode: string;
  content_mode: string;
  updated_by: string | null;
  updated_at: string | null;
}

interface HeaderRow {
  id: string;
  account_id: string;
  product: string;
  header: string;
  tlvs: string | null;
  requested_tlvs: string | null;
  system_id: string | null;
  label: string | null;
  enabled: boolean;
  updated_by: string | null;
  updated_at: string | null;
  status: string;
  requested_by: string | null;
  request_note: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  review_note: string | null;
}

interface TemplateRow extends Omit<HeaderRow, "header"> {
  name: string | null;
  body: string;
}

const MODES: readonly string[] = ["OFF", "REPORT", "ENFORCE"];

/** Unknown text becomes OFF, exactly as the gateway's `WhitelistMode.of` does. */
function mode(value: string | null): WhitelistMode {
  const upper = (value ?? "").trim().toUpperCase();
  return (MODES.includes(upper) ? upper : "OFF") as WhitelistMode;
}

export async function listPolicies(): Promise<WhitelistPolicy[]> {
  const rows = await configQuery<PolicyRow>(
    `SELECT account_id, product, header_mode, content_mode, updated_by, updated_at
       FROM app_whitelist_policy
      ORDER BY account_id, product`
  );
  return rows.map((r) => ({
    accountId: r.account_id,
    product: r.product,
    headerMode: mode(r.header_mode),
    contentMode: mode(r.content_mode),
    updatedBy: r.updated_by,
    updatedAt: r.updated_at,
  }));
}

/**
 * Every account that has a policy or an approved row, with its counts.
 *
 * <p>A full outer join across the three tables, because each can mention an account the others do
 * not: a policy with no rows is the fail-closed case, and rows with no policy are the normal state
 * of a catalogue being populated before anyone decides to enforce it.
 *
 * <p>**Only enabled rows are counted**, because only enabled rows are loaded by the gateway. A
 * count that included disabled ones would make an account look safe to enforce when it is not.
 */
export async function listWhitelistSummaries(): Promise<WhitelistSummary[]> {
  const rows = await configQuery<{
    account_id: string;
    product: string;
    header_mode: string | null;
    content_mode: string | null;
    headers: number;
    templates: number;
  }>(
    `WITH scopes AS (
         SELECT account_id, product FROM app_whitelist_policy
         UNION SELECT account_id, product FROM app_header
         UNION SELECT account_id, product FROM app_template
     )
     SELECT s.account_id,
            s.product,
            p.header_mode,
            p.content_mode,
            (SELECT count(*)::int FROM app_header h
               WHERE h.account_id = s.account_id AND h.product = s.product
                 AND h.enabled AND h.status = 'APPROVED') AS headers,
            (SELECT count(*)::int FROM app_template t
               WHERE t.account_id = s.account_id AND t.product = s.product
                 AND t.enabled AND t.status = 'APPROVED') AS templates
       FROM scopes s
       LEFT JOIN app_whitelist_policy p
              ON p.account_id = s.account_id AND p.product = s.product
      ORDER BY s.account_id, s.product`
  );
  return rows.map((r) => ({
    accountId: r.account_id,
    product: r.product,
    headerMode: mode(r.header_mode),
    contentMode: mode(r.content_mode),
    headers: r.headers,
    templates: r.templates,
  }));
}

function toHeader(r: HeaderRow): ApprovedHeader {
  return {
    id: Number(r.id),
    accountId: r.account_id,
    product: r.product,
    header: r.header,
    tlvs: r.tlvs,
    requestedTlvs: r.requested_tlvs,
    systemId: r.system_id,
    label: r.label,
    enabled: r.enabled,
    updatedBy: r.updated_by,
    updatedAt: r.updated_at,
    status: r.status as ApprovalStatus,
    requestedBy: r.requested_by,
    requestNote: r.request_note,
    reviewedBy: r.reviewed_by,
    reviewedAt: r.reviewed_at,
    reviewNote: r.review_note,
  };
}

function toTemplate(r: TemplateRow): ApprovedTemplate {
  return {
    id: Number(r.id),
    accountId: r.account_id,
    product: r.product,
    name: r.name,
    body: r.body,
    tlvs: r.tlvs,
    requestedTlvs: r.requested_tlvs,
    systemId: r.system_id,
    label: r.label,
    enabled: r.enabled,
    updatedBy: r.updated_by,
    updatedAt: r.updated_at,
    status: r.status as ApprovalStatus,
    requestedBy: r.requested_by,
    requestNote: r.request_note,
    reviewedBy: r.reviewed_by,
    reviewedAt: r.reviewed_at,
    reviewNote: r.review_note,
  };
}

export type WhitelistStatusFilter = "all" | "PENDING" | "REJECTED" | "APPROVED" | "WITHDRAWN";

export const WHITELIST_STATUS_FILTERS: readonly WhitelistStatusFilter[] =
  ["all", "PENDING", "REJECTED", "APPROVED", "WITHDRAWN"];

/** The whole list's rows by state, whatever the filter: the summary strip and the chips' counts. */
export interface WhitelistCounts {
  all: number;
  PENDING: number;
  REJECTED: number;
  APPROVED: number;
  WITHDRAWN: number;
}

/** What the Headers and Templates pages ask for: one page of one list, filtered in the database. */
export interface WhitelistPageQuery {
  kind: "headers" | "templates";
  /** Matched anywhere in the account, the sender ID or the template's name and body, the stamps, the login or the product. */
  q: string;
  /** `WITHDRAWN` is approved but disabled; `APPROVED` is approved and in service. */
  status: WhitelistStatusFilter;
  /** One account only, matched exactly; null for every account. */
  account: string | null;
  /** Zero-based; past the end reads as the last page. */
  page: number;
  size: number;
}

export interface WhitelistPage {
  headers: ApprovedHeader[];
  templates: ApprovedTemplate[];
  /** Rows matching the filter, across every page. */
  total: number;
  /** The page actually served, after the clamp. */
  page: number;
  counts: WhitelistCounts;
  /** `app_account.label` for this page's accounts that have one. */
  accountLabels: Record<string, string>;
  /**
   * The other list's approved, enabled stamps on this page's accounts. A message is stamped by both
   * matches, so a row's TLV gaps count the other list as a supplier -- and the page no longer has
   * that list in hand.
   */
  siblings: { accountId: string; product: string; tlvs: string | null }[];
}

/** `%`, `_` and `\` are LIKE syntax; a search for `a_b` means the text. */
function likePattern(q: string): string | null {
  const t = q.trim();
  return t ? `%${t.replace(/[\\%_]/g, (c) => `\\${c}`)}%` : null;
}

/**
 * One page of approved sender IDs or templates, every account: pending first, then refused, then
 * approved, each by account and product. The order `pendingFirst` gave the page when it held the
 * whole list, so a request is still never paged out of sight.
 */
export async function pageWhitelist(o: WhitelistPageQuery): Promise<WhitelistPage> {
  const headers = o.kind === "headers";
  const table = headers ? "app_header" : "app_template";
  const columns = headers
    ? "id::text, account_id, product, header, tlvs, requested_tlvs, system_id, label, enabled"
    : "id::text, account_id, product, name, body, tlvs, requested_tlvs, system_id, label, enabled";
  const text = headers ? "header ILIKE $1" : "COALESCE(name, '') ILIKE $1 OR body ILIKE $1";
  const order = headers ? "lower(header), id" : "id";
  //$2 is the status filter, spelled as the chips are: WITHDRAWN is an approval taken out of
  //service, so APPROVED means in service and the two never overlap
  const where = `($1::text IS NULL OR account_id ILIKE $1 OR ${text} OR COALESCE(tlvs, '') ILIKE $1
                  OR COALESCE(system_id, '') ILIKE $1 OR product ILIKE $1)
             AND ($5::text IS NULL OR account_id = $5)
             AND CASE $2::text
                   WHEN 'PENDING'   THEN status = 'PENDING'
                   WHEN 'REJECTED'  THEN status = 'REJECTED'
                   WHEN 'APPROVED'  THEN status = 'APPROVED' AND enabled
                   WHEN 'WITHDRAWN' THEN status = 'APPROVED' AND NOT enabled
                   ELSE true END`;
  const size = Math.max(1, Math.min(100, Math.floor(o.size)));
  const pattern = likePattern(o.q);
  const status = WHITELIST_STATUS_FILTERS.includes(o.status) ? o.status : "all";
  const account = o.account?.trim() || null;

  const [counted] = await configQuery<WhitelistCounts & { total: number }>(
    `SELECT (SELECT count(*)::int FROM ${table} WHERE ${where.replaceAll("$5", "$3")}) AS total,
            count(*)::int                                                             AS "all",
            count(*) FILTER (WHERE status = 'PENDING')::int                          AS "PENDING",
            count(*) FILTER (WHERE status = 'REJECTED')::int                         AS "REJECTED",
            count(*) FILTER (WHERE status = 'APPROVED' AND enabled)::int             AS "APPROVED",
            count(*) FILTER (WHERE status = 'APPROVED' AND NOT enabled)::int         AS "WITHDRAWN"
       FROM ${table}`,
    [pattern, status, account]
  );
  const total = counted?.total ?? 0;
  const page = Math.max(0, Math.min(Math.floor(o.page) || 0, Math.ceil(total / size) - 1));
  const rows = await configQuery<HeaderRow & TemplateRow>(
    `SELECT ${columns},
            updated_by, updated_at,
            status, requested_by, request_note, reviewed_by, reviewed_at, review_note
       FROM ${table}
      WHERE ${where}
      ORDER BY CASE status WHEN 'PENDING' THEN 0 WHEN 'REJECTED' THEN 1 ELSE 2 END,
               account_id, product, ${order}
      LIMIT $3 OFFSET $4`,
    [pattern, status, size, page * size, account]
  );

  const accounts = [...new Set(rows.map((r) => r.account_id))];
  const [siblings, labels] = accounts.length
    ? await Promise.all([
        configQuery<{ account_id: string; product: string; tlvs: string | null }>(
          `SELECT account_id, product, tlvs FROM ${headers ? "app_template" : "app_header"}
            WHERE account_id = ANY($1) AND status = 'APPROVED' AND enabled`,
          [accounts]
        ),
        //a name is for the reader; an account with none, or no catalogue row, shows its id alone
        configQuery<{ id: string; label: string }>(
          `SELECT id, label FROM app_account WHERE id = ANY($1) AND label IS NOT NULL AND label <> ''`,
          [accounts]
        ).catch(() => []),
      ])
    : [[], []];

  return {
    headers: headers ? rows.map(toHeader) : [],
    templates: headers ? [] : rows.map(toTemplate),
    total,
    page,
    counts: {
      all: counted?.all ?? 0,
      PENDING: counted?.PENDING ?? 0,
      REJECTED: counted?.REJECTED ?? 0,
      APPROVED: counted?.APPROVED ?? 0,
      WITHDRAWN: counted?.WITHDRAWN ?? 0,
    },
    accountLabels: Object.fromEntries(labels.map((l) => [l.id, l.label])),
    siblings: siblings.map((r) => ({ accountId: r.account_id, product: r.product, tlvs: r.tlvs })),
  };
}

export async function listHeaders(accountId?: string): Promise<ApprovedHeader[]> {
  const rows = await configQuery<HeaderRow>(
    `SELECT id::text, account_id, product, header, tlvs, requested_tlvs, system_id, label, enabled,
            updated_by, updated_at,
            status, requested_by, request_note, reviewed_by, reviewed_at, review_note
       FROM app_header
      WHERE $1::text IS NULL OR account_id = $1
      ORDER BY account_id, product, lower(header)`,
    [accountId ?? null]
  );
  return rows.map(toHeader);
}

export async function listTemplates(accountId?: string): Promise<ApprovedTemplate[]> {
  const rows = await configQuery<TemplateRow>(
    `SELECT id::text, account_id, product, name, body, tlvs, requested_tlvs, system_id, label, enabled,
            updated_by, updated_at,
            status, requested_by, request_note, reviewed_by, reviewed_at, review_note
       FROM app_template
      WHERE $1::text IS NULL OR account_id = $1
      ORDER BY account_id, product, id`,
    [accountId ?? null]
  );
  return rows.map(toTemplate);
}

export async function saveHeader(input: HeaderInput, operator: string): Promise<void> {
  await assertWritableRow("app_header", input.id ?? null, input.accountId);
  //'' is "any product" and passes; a named one must be in the catalogue (gateway V1.56.0)
  await assertProductsCatalogued([input.product]);
  const values = [
    input.accountId.trim(),
    (input.product ?? "").trim(),
    input.header.trim(),
    input.tlvs?.trim() || null,
    input.label?.trim() || null,
    //ticking Approved is what puts a row in service, so it decides `enabled` too. Unticking is the
    //withdrawal: enabled false, status left exactly as it was
    input.approved,
    operator,
    //null, not "", so the column matches what "every login on the account" means everywhere else
    input.systemId?.trim() || null,
  ];
  const after = {
    product: (input.product ?? "").trim() || null,
    systemId: input.systemId?.trim() || null,
    label: input.label?.trim() || null,
    tlvs: input.tlvs?.trim() || null,
    approved: input.approved,
  };
  if (input.id) {
    await configQuery(
      `UPDATE app_header
          SET account_id = $1, product = $2, header = $3, tlvs = $4, label = $5, enabled = $6,
              updated_by = $7, system_id = $8, updated_at = now(),
              ${APPROVAL_SET}
        WHERE id = $9`,
      [...values, input.id]
    );
    await auditConfigChange({
      domain: "header",
      name: `${input.accountId.trim()} ${input.header.trim()}`,
      action: "update",
      account: input.accountId.trim(),
      after: { id: input.id, ...after },
    });
    return;
  }
  //the natural key is case-insensitive, so an id typed in a different case updates the existing row
  //rather than colliding with it -- which is the same thing the gateway would see.
  //
  //The conflict target has to name COALESCE(system_id, '') exactly as the index does, or PostgreSQL
  //cannot infer which index this means and the insert fails outright. That is also what makes two
  //logins able to approve the same sender ID rather than the second one overwriting the first
  const rows = await configQuery<{ id: string; created: boolean }>(
    `INSERT INTO app_header
        (account_id, product, header, tlvs, label, enabled, updated_by, system_id,
         status, reviewed_by, reviewed_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, ${APPROVAL_INSERT})
     ON CONFLICT (account_id, product, COALESCE(system_id, ''), lower(header))
     DO UPDATE SET header = EXCLUDED.header, tlvs = EXCLUDED.tlvs, label = EXCLUDED.label,
                   enabled = EXCLUDED.enabled, updated_by = EXCLUDED.updated_by, updated_at = now(),
                   ${APPROVAL_SET}
     RETURNING id::text, (xmax = 0) AS created`,
    values
  );
  await auditConfigChange({
    domain: "header",
    name: `${input.accountId.trim()} ${input.header.trim()}`,
    action: rows[0]?.created === false ? "update" : "create",
    account: input.accountId.trim(),
    after: { id: rows[0] ? Number(rows[0].id) : null, ...after },
  });
}

export async function saveTemplate(input: TemplateInput, operator: string): Promise<void> {
  await assertWritableRow("app_template", input.id ?? null, input.accountId);
  await assertProductsCatalogued([input.product]);
  const values = [
    input.accountId.trim(),
    (input.product ?? "").trim(),
    input.name?.trim() || null,
    input.body.trim(),
    input.tlvs?.trim() || null,
    input.label?.trim() || null,
    input.approved,
    operator,
    input.systemId?.trim() || null,
  ];
  //the body is message content and may be long; the line carries its length and the name
  const after = {
    product: (input.product ?? "").trim() || null,
    systemId: input.systemId?.trim() || null,
    label: input.label?.trim() || null,
    tlvs: input.tlvs?.trim() || null,
    bodyLength: input.body.trim().length,
    approved: input.approved,
  };
  const name = `${input.accountId.trim()} ${input.name?.trim() || input.body.trim().slice(0, 40)}`;
  if (input.id) {
    await configQuery(
      `UPDATE app_template
          SET account_id = $1, product = $2, name = $3, body = $4, tlvs = $5, label = $6,
              enabled = $7, updated_by = $8, system_id = $9, updated_at = now(),
              ${APPROVAL_SET_TEMPLATE}
        WHERE id = $10`,
      [...values, input.id]
    );
    await auditConfigChange({
      domain: "template", name, action: "update", account: input.accountId.trim(), after: { id: input.id, ...after },
    });
    return;
  }
  const rows = await configQuery<{ id: string }>(
    `INSERT INTO app_template
        (account_id, product, name, body, tlvs, label, enabled, updated_by, system_id,
         status, reviewed_by, reviewed_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, ${APPROVAL_INSERT_TEMPLATE})
     RETURNING id::text`,
    values
  );
  await auditConfigChange({
    domain: "template",
    name,
    action: "create",
    account: input.accountId.trim(),
    after: { id: rows[0] ? Number(rows[0].id) : null, ...after },
  });
}

export async function deleteHeader(id: number): Promise<boolean> {
  await assertWritableRow("app_header", id, null);
  const rows = await configQuery<{ id: string; account_id: string; header: string; product: string; enabled: boolean }>(
    "DELETE FROM app_header WHERE id = $1 RETURNING id::text, account_id, header, product, enabled",
    [id]
  );
  if (!rows.length) {
    return false;
  }
  const gone = rows[0];
  await auditConfigChange({
    domain: "header",
    name: `${gone.account_id} ${gone.header}`,
    action: "delete",
    account: gone.account_id,
    before: { id, product: gone.product || null, enabled: gone.enabled },
  });
  return true;
}

export async function deleteTemplate(id: number): Promise<boolean> {
  await assertWritableRow("app_template", id, null);
  const rows = await configQuery<{ id: string; account_id: string; name: string | null; product: string; enabled: boolean }>(
    "DELETE FROM app_template WHERE id = $1 RETURNING id::text, account_id, name, product, enabled",
    [id]
  );
  if (!rows.length) {
    return false;
  }
  const gone = rows[0];
  await auditConfigChange({
    domain: "template",
    name: `${gone.account_id} ${gone.name ?? `#${id}`}`,
    action: "delete",
    account: gone.account_id,
    before: { id, product: gone.product || null, enabled: gone.enabled },
  });
  return true;
}

/**
 * Sets one scope's enforcement modes.
 *
 * <p>Separate from the row editors deliberately. Approving a sender ID is additive and safe; moving
 * a scope to ENFORCE can stop a customer sending within thirty seconds, and the two should not share
 * a Save button.
 */
export async function savePolicy(
  accountId: string,
  product: string,
  headerMode: WhitelistMode,
  contentMode: WhitelistMode,
  operator: string
): Promise<void> {
  await assertProductsCatalogued([product]);
  //the previous modes are the point of this line: ENFORCE is the switch that stops a customer
  //sending, and "what was it before" is the first question when that happens
  const was = await configQuery<{ header_mode: string; content_mode: string }>(
    "SELECT header_mode, content_mode FROM app_whitelist_policy WHERE account_id = $1 AND product = $2",
    [accountId.trim(), (product ?? "").trim()]
  );
  await configQuery(
    `INSERT INTO app_whitelist_policy
            (account_id, product, header_mode, content_mode, updated_by)
     VALUES ($1, $2, $3, $4, $5)
     ON CONFLICT (account_id, product)
     DO UPDATE SET header_mode = EXCLUDED.header_mode, content_mode = EXCLUDED.content_mode,
                   updated_by = EXCLUDED.updated_by, updated_at = now()`,
    [accountId.trim(), (product ?? "").trim(), headerMode, contentMode, operator]
  );
  await auditConfigChange({
    domain: "whitelist_policy",
    name: `${accountId.trim()} ${(product ?? "").trim() || "*"}`,
    action: was.length ? "update" : "create",
    account: accountId.trim(),
    before: was.length ? { headerMode: was[0].header_mode, contentMode: was[0].content_mode } : null,
    after: { headerMode, contentMode },
  });
}

/**
 * Every scope one account has, for the enforcement guard and the account page.
 *
 * <p>All of them, deliberately, and not the one scope being edited. The gateway merges a product
 * scope over the account's any-product scope, so the question "may this account enforce" cannot be
 * answered from a single row — `enforcementReadiness` needs the whole set. Asking for one row is
 * what produced a refusal for a configuration that runs.
 *
 * <p>Filtered from `listWhitelistSummaries` rather than given its own aggregate, because a second
 * query would be a second definition of "approved" and the bug this replaces was three definitions
 * disagreeing.
 */
export async function getAccountSummaries(accountId: string): Promise<WhitelistSummary[]> {
  const all = await listWhitelistSummaries();
  return all.filter((s) => s.accountId === accountId);
}

/**
 * Products whose traffic is not checked at all.
 *
 * <p>The same statement `DbWhitelistLoader` uses, copied rather than approximated: the gateway
 * returns `AccountWhitelist.OFF` for these before any merge, so an approval filed under one protects
 * nothing. A guard that counted them would pass an account whose approvals are entirely inert.
 */
export async function listExemptProducts(): Promise<string[]> {
  const rows = await configQuery<{ name: string }>(
    "SELECT name FROM app_product WHERE enabled AND NOT whitelist_enabled"
  );
  return rows.map((r) => r.name);
}

/**
 * Why this login cannot hold this account's approval, or null.
 *
 * <p>The operator's twin of `scopedLogin` on the customer side. The value arrives in a request body,
 * so it is proved against the account's own credentials rather than trusted — a registration bound
 * to a login belonging to somebody else would do nothing today and would be a cross-account grant
 * the moment anything matched on it.
 *
 * <p>Underneath this the gateway is safe anyway: it matches `system_id` only within that account's
 * own whitelist scope, so a foreign name matches nothing rather than matching its real owner. This
 * is the layer that stops the row being written in the first place, so nobody has to rely on that.
 *
 * <p>Empty means every login on the account and is always allowed.
 */
export async function loginOutsideAccount(
  accountId: string,
  systemId: string | null | undefined
): Promise<string | null> {
  const asked = (systemId ?? "").trim();
  if (!asked) {
    return null;
  }
  const rows = await configQuery<{ system_id: string }>(
    `SELECT system_id FROM app_credential
      WHERE ${BILLING_KEY} = $1 AND system_id = $2 AND enabled`,
    [accountId.trim(), asked]
  );
  return rows.length
    ? null
    : `'${asked}' is not a login on ${accountId.trim()}. A registration can only be scoped to a `
      + "login the account owns.";
}

/**
 * Refuses a write that touches an archived account: the one a row is on now, and the one it is
 * being written to. Moving a row between accounts is its own action (`moveWhitelistRow`).
 */
async function assertWritableRow(table: "app_header" | "app_template", id: number | null, accountId: string | null): Promise<void> {
  await assertWritableAccount(null, accountId);
  if (id != null) {
    const rows = await configQuery<{ account_id: string }>(`SELECT account_id FROM ${table} WHERE id = $1`, [id]);
    await assertWritableAccount(null, rows[0]?.account_id ?? null);
  }
}
