import type { HealthSession } from "./health-types";
import { BIND_TYPE_LABELS, labelFor } from "./labels.ts";

/**
 * A listener's sessions folded by account.
 *
 * <p>The flat session table answers "which binds are up"; an operator looking at a listener
 * usually asks "who is on it, and how much of the traffic is theirs". A customer with two
 * transmitters and two receivers took four near-identical rows to say that, with the source port
 * hidden so two binds from one address could not even be told apart. One row per account, with the
 * binds counted by kind and the counters summed, is the reading; the binds themselves sit under it.
 *
 * <p>Pure, so the grouping and its wording are tested against session arrays rather than against a
 * rendered table. Nothing here fetches.
 */

export interface BindCounts {
  /** Bound TRANSMITTER, RECEIVER and TRANSCEIVER sessions, by the spec's own abbreviations. */
  TX: number;
  RX: number;
  TRX: number;
  /** Sessions the gateway still holds that are no longer bound: counted apart, never as a kind. */
  unbound: number;
}

export interface AccountGroup {
  /** The account name, or "—" for a session the gateway could not attribute. */
  account: string;
  /** Distinct system ids behind the account's binds, in first-seen order. */
  logins: string[];
  sessions: HealthSession[];
  counts: BindCounts;
  /** Distinct source addresses, in first-seen order. */
  hosts: string[];
  /** The longest-bound session's age in seconds, null when none reports one. */
  oldest: number | null;
  /** submit_sm received across the counting sessions; null when none of them counts. */
  received: number | null;
  /** deliver_sm sent back across the counting sessions (gateway 0.13.2+); null when none counts. */
  receipts: number | null;
  /** Measured tps summed over the sessions that report one; null when none does. */
  tps: number | null;
  /** The per-bind ceiling, when every bind that has one shares it; null otherwise. */
  tpsLimit: number | null;
}

/** The label of a session no account was attributed to. */
export const UNATTRIBUTED = "—";

/**
 * Fold sessions by account, busiest first.
 *
 * <p>Order is received traffic descending, then account name, so the account carrying the listener
 * sits at the top on every poll rather than wherever its first bind happened to land in the array.
 * A group that counts nothing sorts after every group that does.
 */
export function groupSessions(sessions: readonly HealthSession[]): AccountGroup[] {
  const byAccount = new Map<string, HealthSession[]>();
  for (const session of sessions) {
    const key = session.account?.trim() || UNATTRIBUTED;
    const list = byAccount.get(key);
    if (list) {
      list.push(session);
    } else {
      byAccount.set(key, [session]);
    }
  }
  return [...byAccount.entries()]
    .map(([account, rows]) => groupOf(account, rows))
    .sort((a, b) => (b.received ?? -1) - (a.received ?? -1) || a.account.localeCompare(b.account));
}

function groupOf(account: string, sessions: HealthSession[]): AccountGroup {
  const counts: BindCounts = { TX: 0, RX: 0, TRX: 0, unbound: 0 };
  const logins: string[] = [];
  const hosts: string[] = [];
  const ages: number[] = [];
  const limits = new Set<number>();
  let received: number | null = null;
  let receipts: number | null = null;
  let tps: number | null = null;

  for (const session of sessions) {
    if (!session.bound) {
      counts.unbound += 1;
    } else {
      const kind = labelFor(BIND_TYPE_LABELS, session.bind_type);
      if (kind === "TX" || kind === "RX" || kind === "TRX") {
        counts[kind] += 1;
      }
    }
    if (session.system_id && !logins.includes(session.system_id)) {
      logins.push(session.system_id);
    }
    if (session.host && !hosts.includes(session.host)) {
      hosts.push(session.host);
    }
    if (session.bound_seconds != null) {
      ages.push(session.bound_seconds);
    }
    if (session.tps_limit != null) {
      limits.add(session.tps_limit);
    }
    //null stays null until one session counts: "nothing counted" and "counted nothing" are
    //different readings, and the table draws them differently
    if (session.submitted != null) {
      received = (received ?? 0) + session.submitted;
    }
    if (session.receipts != null) {
      receipts = (receipts ?? 0) + session.receipts;
    }
    if (session.tps_measured != null) {
      tps = (tps ?? 0) + session.tps_measured;
    }
  }

  return {
    account,
    logins,
    sessions,
    counts,
    hosts,
    oldest: ages.length ? Math.max(...ages) : null,
    received,
    receipts,
    tps,
    tpsLimit: limits.size === 1 ? [...limits][0] : null,
  };
}

/** Every bind of every group, for a listener-wide total row. */
export function overall(groups: readonly AccountGroup[]): AccountGroup {
  return groupOf("Overall", groups.flatMap((g) => g.sessions));
}

/** The binds of a group as the table summarises them: `2 TX · 2 RX`, then `1 not bound` if any. */
export function bindSummary(counts: BindCounts): string {
  const parts = (["TX", "RX", "TRX"] as const)
    .filter((kind) => counts[kind] > 0)
    .map((kind) => `${counts[kind]} ${kind}`);
  if (counts.unbound > 0) {
    parts.push(`${counts.unbound} not bound`);
  }
  return parts.join(" · ");
}

/** Receipts as a share of what was submitted; null until something was submitted. */
export function receiptRate(group: Pick<AccountGroup, "received" | "receipts">): number | null {
  if (group.received == null || group.receipts == null || group.received <= 0) {
    return null;
  }
  return group.receipts / group.received;
}

/** The source addresses as the account row shows them: the first, and how many more. */
export function hostsLabel(hosts: readonly string[]): string {
  if (!hosts.length) {
    return "—";
  }
  return hosts.length === 1 ? hosts[0] : `${hosts[0]} +${hosts.length - 1}`;
}
