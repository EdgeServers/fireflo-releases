import { type BanRule, NON_BANNABLE_REASONS, type RefusalSummaryRow } from "./ban-rules.ts";

/**
 * The small pieces the Security page's ban controls and listener tiles need. Pure and client-safe.
 *
 * <p>The merge of the gateway's `refusalSummary` fold with the refusal log is in
 * `security-rows.ts`; this file is what is left once that moved: labels, the ban sentence and
 * durations, and a fresh rule.
 */

/** "smppserver.main :2775", or the port alone when the gateway named no listener. */
export function listenerLabel(row: Pick<RefusalSummaryRow, "listener" | "port">): string {
  const port = row.port != null ? `:${row.port}` : "";
  return row.listener ? `${row.listener} ${port}`.trim() : port || "unnamed";
}

/** Whether a reason is one a rule leaves out by default: a caller whose credential was accepted. */
export function isNonBannable(reason: string): boolean {
  return NON_BANNABLE_REASONS.includes(reason);
}

/**
 * The sentence the ban button carries when the panel is not on the gateway host. The route answers
 * the same thing as a 501; it is here so the button can say it before anybody presses it.
 */
export const BAN_NOT_AVAILABLE =
  "Banning from the panel needs the panel on the gateway host with fail2ban installed "
  + "(fireflo-panel-install --with-fail2ban). This panel is not, so there is nothing here to ask.";

/** The ban durations offered beside the jail; empty is the jail's own bantime. */
export const BAN_DURATIONS = [
  { value: "", label: "Jail's default" },
  { value: "3600", label: "1 hour" },
  { value: "86400", label: "1 day" },
  { value: "604800", label: "7 days" },
] as const;

/** A fresh rule with an id no existing rule holds, dry-run and off, ready to be edited. */
export function blankRule(existing: readonly BanRule[], jail: string): BanRule {
  const taken = new Set(existing.map((r) => r.id));
  let n = existing.length + 1;
  while (taken.has(`rule-${n}`)) {
    n += 1;
  }
  return {
    id: `rule-${n}`,
    name: "",
    listener: "any",
    reasons: [],
    threshold: 20,
    windowMinutes: 10,
    banSeconds: 3600,
    jail,
    enabled: false,
    dryRun: true,
  };
}
