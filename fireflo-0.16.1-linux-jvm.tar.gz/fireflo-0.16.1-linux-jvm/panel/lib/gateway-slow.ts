/**
 * A slow gateway is not an absent one (0.15.1).
 *
 * <p>Under load a gateway can take seconds to answer while working perfectly well: on staging at
 * 2,000/s with a load average of 40 the Connectivity page said "could not reach gateway" while the
 * gateway answered health in 33 ms a moment later. The rules, written once:
 *
 * <ul>
 *   <li><b>The server side</b> (`gateway-graphql-core.ts`) answers a timeout as `code: "SLOW"`, not
 *       `UNREACHABLE`, which is kept for a refusal or a name that does not resolve; the live routes
 *       carry the code in their 502 body ({@link failureBody}).</li>
 *   <li><b>The page</b> keeps its last good answer for a slow 502 ({@link isSlowAnswer}), shows
 *       {@link slowNote} instead of an error strip, and asks again on its next tick.</li>
 *   <li><b>The counters poll</b> backs off from {@link COUNTERS_POLL_MS} to
 *       {@link COUNTERS_SLOW_POLL_MS} while the gateway is slow, and comes back once an answer
 *       takes under {@link COUNTERS_FAST_MS} ({@link countersInterval}).</li>
 * </ul>
 *
 * <p>Imports nothing but lib/datetime (itself import-free): the routes' helpers and the browser's are both here, and the browser bundle
 * must not pull in the server's gateway client.
 */

import { formatClock } from "./datetime.ts";

/** The code a slow gateway's failure carries (`PANEL_CODES.slow`). */
export const SLOW_CODE = "SLOW";

/** A 502's body: the sentence, and the code when the failure had one (`SLOW` for a slow gateway). */
export interface GatewayFailureBody {
  error: string;
  code?: string;
}

function codeOf(err: unknown): string | null {
  const code = (err as { code?: unknown } | null)?.code;
  return typeof code === "string" && code ? code : null;
}

/** Whether a thrown value is a slow gateway's failure (a `GatewayError` with code `SLOW`). */
export function isSlowFailure(err: unknown): boolean {
  return codeOf(err) === SLOW_CODE;
}

/** The 502 body for a failed gateway read: the code kept, so a page can tell slow from gone. */
export function failureBody(err: unknown): GatewayFailureBody {
  const error = err instanceof Error ? err.message : "the gateway did not answer";
  const code = err instanceof Error ? codeOf(err) : null;
  return code ? { error, code } : { error };
}

/**
 * Whether a failed read means the capability is missing (a 204, not a 502): asked after the
 * failure, never before the read, and never for a slow gateway.
 */
export async function missingAfter(err: unknown, available: () => Promise<boolean>): Promise<boolean> {
  if (isSlowFailure(err)) {
    return false;
  }
  return !(await available().catch(() => true));
}

/** Whether a route's answer is a slow gateway's 502: keep the last answer, note it, retry. */
export function isSlowAnswer(status: number | undefined, body: unknown): boolean {
  return status === 502 && (body as { code?: unknown } | null)?.code === SLOW_CODE;
}

/** "gateway slow, showing data from 21:14:03": the time of the last good answer, 24-hour clock. */
export function slowNote(at: number, zone: string): string {
  const clock = formatClock(at, zone);
  return `gateway slow, showing data from ${clock}`;
}

/** The counters' normal poll. */
export const COUNTERS_POLL_MS = 2_000;
/** The counters' poll while the gateway is slow. */
export const COUNTERS_SLOW_POLL_MS = 5_000;
/** An answer faster than this brings a backed-off poll back to {@link COUNTERS_POLL_MS}. */
export const COUNTERS_FAST_MS = 1_000;

/**
 * The counters' next interval: {@link COUNTERS_SLOW_POLL_MS} after a slow answer,
 * {@link COUNTERS_POLL_MS} after one that came back under {@link COUNTERS_FAST_MS}, and otherwise
 * whatever it was -- an answer in 1-10 s neither backs off nor comes back.
 */
export function countersInterval(current: number, outcome: { slow: boolean; elapsedMs: number }): number {
  if (outcome.slow) {
    return COUNTERS_SLOW_POLL_MS;
  }
  return outcome.elapsedMs < COUNTERS_FAST_MS ? COUNTERS_POLL_MS : current;
}

/**
 * Whether a poll tick should read: not while the last read is still in flight (a slow gateway can
 * hold one for ten seconds, and a second would only queue behind it), and not within most of an
 * interval of the last one finishing -- a change of interval restarts the timer with an immediate
 * tick, which must not become a read right after the slow one.
 */
export function shouldRead(s: { inFlight: boolean; lastFinishedAt: number; now: number; intervalMs: number }): boolean {
  if (s.inFlight) {
    return false;
  }
  return s.now - s.lastFinishedAt >= s.intervalMs * 0.75;
}
