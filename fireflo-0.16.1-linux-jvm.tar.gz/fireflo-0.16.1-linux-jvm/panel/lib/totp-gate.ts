/**
 * The two-factor decision `requireOperator` makes on every request, database-free so it is tested
 * on its own.
 *
 * <ul>
 *   <li>Two-factor changed since this session was made -- turned on, off or reset
 *       (`totp_changed_at`, carried in the session as it stood at sign-in or at the session's own
 *       re-mint) -- and the session is refused, whatever two-factor is now. Null on both sides is
 *       equal: nothing has changed since before the column.</li>
 *   <li>The operator has an authenticator (`totp_enabled_at`, as a stamp): the session must have been
 *       verified with THAT one -- its `mfaAt` equal to the row's.</li>
 *   <li>No authenticator and two-factor required of every operator: the session may reach the set-up
 *       only, until it is done.</li>
 *   <li>Otherwise: through.</li>
 * </ul>
 */
export function totpGate(o: {
  rowStamp: number | null;
  sessionStamp: number | null;
  required: boolean;
  rowChanged: number | null;
  sessionChanged: number | null;
}): "ok" | "refuse" | "enrol" {
  if ((o.rowChanged ?? null) !== (o.sessionChanged ?? null)) {
    return "refuse";
  }
  if (o.rowStamp !== null) {
    return o.sessionStamp === o.rowStamp ? "ok" : "refuse";
  }
  return o.required ? "enrol" : "ok";
}
