import { reasonKey, type FailureCell } from "./failure-groups.ts";
import { SHORT_FINAL_STATE_LABELS, labelFor } from "./labels.ts";

/**
 * The dashboard's sunbursts as trees (0.15.1): the failure ring five levels deep (account › vendor ›
 * final state › error code › carrier code) and the vendor ring four (vendor › account › outcome ›
 * error code). Pure, so the shaping is tested without a browser (`sunburst-tree.test.ts`); the
 * component (`components/DashboardRings.tsx`) only draws what this returns.
 *
 * <p>The shaping, applied at every level:
 *
 * <ul>
 *   <li><b>Largest first.</b> Siblings are ordered by count, then by label.</li>
 *   <li><b>Small ones fold.</b> Two or more children each under {@link MIN_SHARE} of their parent
 *       become one "other N" sector; a single small child is kept, since "other 1" says less than its
 *       own name.</li>
 *   <li><b>A level of one collapses.</b> A child that is its parent's only child and covers all of it
 *       would draw a full ring of one sector; it is merged into its parent instead, whose label then
 *       reads "parent › child". A child that covers only part (say, the carrier codes known for some
 *       of a reason's messages) is kept, and the rest of that ring stays empty.</li>
 * </ul>
 *
 * <p><b>Colours are fixed hues</b>, not theme tokens: a reason keeps one colour wherever it appears,
 * in either ring and either theme; the level beneath it is a tint of that hue.
 */

/** A sibling below this share of its parent is folded into "other N" (with at least one more). */
export const MIN_SHARE = 0.015;

/** Failure reasons, by their rank in the period: the biggest reason is always the first colour. */
export const REASON_COLOURS = ["#2a78d6", "#eb6834", "#008300", "#e34948", "#6250d6"];
export const REST_COLOUR = "#9a988f";
/** The first ring: accounts on the failure ring, vendors on the vendor ring. */
export const SLICE_COLOURS = ["#6250d6", "#e87ba4", "#1baf7a", "#c98500", "#2a78d6", "#eb6834"];
export const OTHER_COLOUR = "#b4b2a9";
export const FAILED_COLOUR = "#e34948";
export const EXPIRED_COLOUR = "#c98500";
export const PENDING_COLOUR = "#c9c7bd";
export const STATE_COLOURS: Record<string, string> = {
  FAILED: FAILED_COLOUR,
  EXPIRED: EXPIRED_COLOUR,
  REJECTED: "#eb6834",
  DROPPED: "#6250d6",
};

/** `hex` lightened towards white by `amount` (0..1): a deeper level in its parent's hue. */
export function tint(hex: string, amount: number): string {
  const n = parseInt(hex.slice(1), 16);
  const mix = (c: number) => Math.round(c + (255 - c) * amount);
  return `#${[(n >> 16) & 255, (n >> 8) & 255, n & 255].map((c) => mix(c).toString(16).padStart(2, "0")).join("")}`;
}

/** One level of an item's path: what keys it, what it is called, how it is drawn. */
export interface Level {
  key: string;
  label: string;
  fill: string;
}

/** Something counted, with the path it sits on, outermost level last. Paths may stop early. */
export interface TreeItem {
  levels: Level[];
  value: number;
}

/** One sector, or the root. */
export interface SunNode {
  /** Unique in the tree: the key path as JSON. The chart library keys sectors by it. */
  name: string;
  /** The key path from the root, merged levels included. */
  keys: string[];
  /** The label path from the root, merged levels included, for the centre and the breadcrumb. */
  path: string[];
  /** This sector's own label: "a › b" when a single child was merged into it. */
  label: string;
  value: number;
  fill: string;
  children?: SunNode[];
  /** Set on an "other N" sector: how many siblings it stands for. */
  folded?: number;
}

const OTHER_KEY = "\u0000other";

function byValue(a: SunNode, b: SunNode): number {
  return b.value - a.value || (a.label < b.label ? -1 : a.label > b.label ? 1 : 0);
}

/**
 * The tree from the items: every level summed, then shaped (sorted, folded, collapsed) as the module
 * comment says. The root's `value` is every item's total; its `label` is `rootLabel`.
 */
export function buildSunburst(items: readonly TreeItem[], rootLabel: string, minShare = MIN_SHARE): SunNode {
  const root: SunNode = { name: JSON.stringify([]), keys: [], path: [], label: rootLabel, value: 0, fill: OTHER_COLOUR, children: [] };
  for (const item of items) {
    if (!(item.value > 0)) {
      continue;
    }
    root.value += item.value;
    let at = root;
    for (const level of item.levels) {
      at.children ??= [];
      const keys = [...at.keys, level.key];
      const name = JSON.stringify(keys);
      let child = at.children.find((c) => c.name === name);
      if (!child) {
        child = { name, keys, path: [...at.path, level.label], label: level.label, value: 0, fill: level.fill };
        at.children.push(child);
      }
      child.value += item.value;
      at = child;
    }
  }
  shape(root, minShare, true);
  return root;
}

function shape(node: SunNode, minShare: number, isRoot: boolean): void {
  if (!node.children?.length) {
    delete node.children;
    return;
  }
  node.children.sort(byValue);
  const small = node.children.filter((c) => c.value < node.value * minShare);
  if (small.length > 1) {
    const keys = [...node.keys, OTHER_KEY];
    const label = `other ${small.length}`;
    node.children = node.children.filter((c) => !small.includes(c));
    node.children.push({
      name: JSON.stringify(keys),
      keys,
      path: [...node.path, label],
      label,
      value: small.reduce((n, c) => n + c.value, 0),
      fill: OTHER_COLOUR,
      folded: small.length,
    });
  }
  for (const c of node.children) {
    shape(c, minShare, false);
  }
  //a level of one that covers its parent whole would be a full ring of one sector: merge it up
  while (!isRoot && node.children?.length === 1 && node.children[0].value === node.value && !node.children[0].folded) {
    const only: SunNode = node.children[0];
    node.label = `${node.label} › ${only.label}`;
    node.keys = only.keys;
    node.path = only.path;
    node.name = only.name;
    node.children = only.children;
  }
  if (!node.children?.length) {
    delete node.children;
  }
}

/** The node named `name`, or null. */
export function findNode(root: SunNode, name: string): SunNode | null {
  if (root.name === name) {
    return root;
  }
  for (const c of root.children ?? []) {
    const hit = findNode(c, name);
    if (hit) {
      return hit;
    }
  }
  return null;
}

/** The nodes from the root's child down to `name` (the breadcrumb), or [] when it is not there. */
export function ancestors(root: SunNode, name: string): SunNode[] {
  for (const c of root.children ?? []) {
    if (c.name === name) {
      return [c];
    }
    const below = ancestors(c, name);
    if (below.length) {
      return [c, ...below];
    }
  }
  return [];
}

/**
 * Where a click on `name` zooms: that node when it has children (it becomes the chart's root),
 * else null -- a leaf has nothing to fill the circle with.
 */
export function zoomTarget(root: SunNode, name: string): SunNode | null {
  const node = findNode(root, name);
  return node?.children?.length ? node : null;
}

/** Up one from `name`: its parent's name, or null at the top (the whole chart). */
export function zoomOut(root: SunNode, name: string): string | null {
  const chain = ancestors(root, name);
  return chain.length > 1 ? chain[chain.length - 2].name : null;
}

/** A node's share of its first-ring ancestor (the account, or the vendor): what the centre says. */
export function shareOfTop(root: SunNode, node: SunNode): { of: SunNode; share: number } | null {
  const top = ancestors(root, node.name)[0];
  return top && top.value > 0 ? { of: top, share: node.value / top.value } : null;
}

/** One row of the table: an item's whole path, unfolded, with its count. */
export interface PathRow {
  key: string;
  path: string[];
  fill: string;
  value: number;
}

/** Every distinct full path, summed, unfolded -- the table lists what the ring folds away too. */
export function pathRows(items: readonly TreeItem[], order: "desc" | "asc" = "desc"): PathRow[] {
  const by = new Map<string, PathRow>();
  for (const item of items) {
    if (!(item.value > 0)) continue;
    const key = JSON.stringify(item.levels.map((l) => l.key));
    const row = by.get(key);
    if (row) {
      row.value += item.value;
    } else {
      by.set(key, { key, path: item.levels.map((l) => l.label), fill: item.levels[item.levels.length - 1]?.fill ?? OTHER_COLOUR, value: item.value });
    }
  }
  const sign = order === "desc" ? -1 : 1;
  return [...by.values()].sort((a, b) => sign * (a.value - b.value) || (a.key < b.key ? -1 : 1));
}

// ---- the two rings' items ----

/** The error code as the gateway reads it: the code, else the receipt state, else none. */
export function codeLabel(row: Pick<FailureCell, "dlrState" | "errCode">): string {
  return row.errCode ? `error ${row.errCode}` : row.dlrState !== null ? `receipt ${row.dlrState}` : "no code";
}

/** The reason colours by rank over the rows, shared by both rings so a reason looks the same in each. */
export function reasonColours(rows: readonly FailureCell[]): Map<string, string> {
  const totals = new Map<string, number>();
  for (const r of rows) {
    totals.set(reasonKey(r), (totals.get(reasonKey(r)) ?? 0) + r.messages);
  }
  const ranked = [...totals.entries()].sort((a, b) => b[1] - a[1] || (a[0] < b[0] ? -1 : 1));
  return new Map(ranked.map(([k], i) => [k, REASON_COLOURS[i] ?? REST_COLOUR]));
}

function rankColours(totals: Map<string, number>): Map<string, string> {
  const ranked = [...totals.entries()].sort((a, b) => b[1] - a[1] || (a[0] < b[0] ? -1 : 1));
  return new Map(ranked.map(([k], i) => [k, SLICE_COLOURS[i % SLICE_COLOURS.length]]));
}

/**
 * The failure ring's items: account › vendor › final state › error code › carrier code, the last
 * only when the carrier's code says something the gateway's does not.
 */
export function failureItems(rows: readonly FailureCell[], colours = reasonColours(rows)): TreeItem[] {
  const accountTotals = new Map<string, number>();
  for (const r of rows) {
    accountTotals.set(r.account ?? "", (accountTotals.get(r.account ?? "") ?? 0) + r.messages);
  }
  const accountColour = rankColours(accountTotals);
  return rows.map((r) => {
    const acc = r.account ? accountColour.get(r.account)! : OTHER_COLOUR;
    const reason = colours.get(reasonKey(r)) ?? REST_COLOUR;
    const levels: Level[] = [
      { key: r.account ?? "", label: r.account ?? "No account", fill: acc },
      { key: r.vendor ?? "", label: r.vendor ?? "vendor not known", fill: tint(acc, 0.3) },
      { key: r.finalState, label: labelFor(SHORT_FINAL_STATE_LABELS, r.finalState), fill: STATE_COLOURS[r.finalState] ?? REST_COLOUR },
      { key: `${r.dlrState ?? ""}|${r.errCode ?? ""}`, label: codeLabel(r), fill: reason },
    ];
    if (r.vendorErrCode && r.vendorErrCode !== r.errCode) {
      levels.push({ key: r.vendorErrCode, label: `carrier ${r.vendorErrCode}`, fill: tint(reason, 0.45) });
    }
    return { levels, value: r.messages };
  });
}

/** One vendor's (or one vendor and account's) outcomes, as the overview's vendor rows carry them. */
export interface VendorOutcomes {
  vendor: string | null;
  account?: string | null;
  delivered: number;
  /** Failed, expired included -- as `vendorPerformance` counts it. */
  failed: number;
  pending: number;
}

/**
 * The vendor ring's items: vendor › account › outcome › error code. Delivered and pending come from
 * the vendor rows; failed and expired from the failure rows of the same vendor and account, by code.
 * What the rows count as failed beyond the failure rows (a window the breakdown does not cover, or
 * hours the summary served without a vendor) is kept as "failed › not broken down", so the ring
 * never draws fewer failures than the vendor row has. Rows not split by account sit under "All
 * accounts", which collapses into the vendor.
 */
export function vendorItems(
  vendors: readonly VendorOutcomes[],
  failures: readonly FailureCell[],
  colours = reasonColours(failures)
): TreeItem[] {
  const totals = new Map<string, number>();
  for (const v of vendors) {
    totals.set(v.vendor ?? "", (totals.get(v.vendor ?? "") ?? 0) + v.delivered + v.failed + v.pending);
  }
  const vendorColour = rankColours(totals);
  const split = vendors.some((v) => v.account !== undefined);
  const items: TreeItem[] = [];
  for (const v of vendors) {
    const vc = v.vendor ? vendorColour.get(v.vendor)! : OTHER_COLOUR;
    const accountKey = split ? v.account ?? "" : "\u0000all";
    const head: Level[] = [
      { key: v.vendor ?? "", label: v.vendor ?? "No vendor", fill: vc },
      { key: accountKey, label: split ? v.account ?? "No account" : "All accounts", fill: tint(vc, 0.3) },
    ];
    items.push({ levels: [...head, { key: "delivered", label: "delivered", fill: tint(vc, 0.55) }], value: v.delivered });
    items.push({ levels: [...head, { key: "pending", label: "pending", fill: PENDING_COLOUR }], value: v.pending });
    const mine = failures.filter((f) => (f.vendor ?? null) === v.vendor && (!split || (f.account ?? null) === (v.account ?? null)));
    let broken = 0;
    for (const f of mine) {
      const expired = f.finalState === "EXPIRED";
      items.push({
        levels: [
          ...head,
          expired
            ? { key: "expired", label: "expired", fill: EXPIRED_COLOUR }
            : { key: "failed", label: "failed", fill: FAILED_COLOUR },
          { key: `${f.finalState}|${f.dlrState ?? ""}|${f.errCode ?? ""}`, label: codeLabel(f), fill: colours.get(reasonKey(f)) ?? REST_COLOUR },
        ],
        value: f.messages,
      });
      broken += f.messages;
    }
    if (v.failed > broken) {
      items.push({
        levels: [...head, { key: "failed", label: "failed", fill: FAILED_COLOUR }, { key: "\u0000rest", label: "not broken down", fill: tint(FAILED_COLOUR, 0.5) }],
        value: v.failed - broken,
      });
    }
  }
  return items;
}
