import { strict as assert } from "node:assert";
import { after, before, describe, test } from "node:test";

import { cdrRouteSql, cdrRouteUnmarked, isMessageRow } from "./cdr-grain.ts";
import { mtUsageSql } from "./mt-usage-sql.ts";
import { consumedSql, MISSING_ROLLUP_SQL } from "./reconcile-sql.ts";
import {
  STATEMENT_CUT_SQL,
  statementDetailSql,
  statementSummarySql,
  summaryParams,
  type StatementCut,
} from "./statement-sql.ts";
import { OUTCOME_LATERAL, usageWindowSql } from "./usage-summary-sql.ts";

/**
 * The owner's gate for 0.15: with the call records split into hot and archive, every money and
 * report reader gives the answer it gave on one flat table.
 *
 * <p>Two schemas hold the same traffic: `flat` as one table per kind, as before V1.112.0, and
 * `tiered` as V1.112.0 leaves it -- a hot table partitioned by day from the split, an archive
 * holding everything older, the `_all` views and `cdr_tier`. The traffic straddles the split,
 * including a message submitted before it whose receipt landed after it (submit in the archive,
 * receipt in hot). Each reader runs as written on `flat` and routed by its window on `tiered`.
 *
 * <p>`CDR_TIER_TEST_DATABASE_URL` (or `STATEMENT_TEST_DATABASE_URL`) names a database this test may
 * create and drop two schemas in. The fixture is the columns these readers use, not the gateway's
 * whole schema.
 */
const URL = process.env.CDR_TIER_TEST_DATABASE_URL ?? process.env.STATEMENT_TEST_DATABASE_URL;

const ZONE = "Asia/Kolkata";
/** Where hot begins: cdr_tier.hot_from. */
const SPLIT = new Date("2026-01-20T00:00:00Z");

/** `UsageRollup.ROLLUP_SQL`'s counting over the fixture's columns, for days [$2, $3] in zone $1. */
const ROLLUP = `
  INSERT INTO usage_daily (account_id, day, product, submitted, delivered, failed, expired,
                           pending_at_rollup, unrated_messages, price_total, cost_total, mt_parts)
  SELECT COALESCE(s.account_id, ''), (s.submitted_at AT TIME ZONE $1)::date, COALESCE(s.product, ''),
         count(*),
         count(*) FILTER (WHERE o.final_state = 'DELIVERED'),
         count(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED')),
         count(*) FILTER (WHERE o.final_state = 'EXPIRED'),
         count(*) FILTER (WHERE o.final_state IS NULL),
         count(*) FILTER (WHERE s.price IS NULL),
         COALESCE(SUM(s.price), 0), COALESCE(SUM(s.cost), 0), COALESCE(SUM(s.part_count), 0)
    FROM (SELECT DISTINCT ON (c.gateway_msg_id) c.*
            FROM cdr_submit c
           WHERE c.part_no = 1
             AND (c.submitted_at AT TIME ZONE $1)::date >= $2::date
             AND (c.submitted_at AT TIME ZONE $1)::date <= $3::date
           ORDER BY c.gateway_msg_id, (c.price IS NULL), c.retry_count DESC, c.vendor_attempt DESC) s
    LEFT JOIN LATERAL (
         SELECT f.final_state FROM cdr_final f
          WHERE f.gateway_msg_id = s.gateway_msg_id AND f.part_no = s.part_no
          ORDER BY (f.final_state = 'EXPIRED'), f.final_at LIMIT 1) o ON TRUE
   GROUP BY 1, 2, 3`;

/** The core of the Messages search (`searchCdrs`): one row per message, newest first, keyset paged. */
function searchSql(since: boolean, keyset: boolean): string {
  const n = since ? 1 : 0;
  return `SELECT s.id::text, s.gateway_msg_id, s.submitted_at, s.account_id, s.price::text, o.final_state
       FROM cdr_submit s${OUTCOME_LATERAL}
      WHERE ${isMessageRow("s", { vendorAttempt: true })}${since ? " AND s.submitted_at >= $1" : ""}${keyset
    ? ` AND (s.submitted_at, s.id) < ($${n + 1}::timestamptz, $${n + 2}::bigint)`
    : ""}
      ORDER BY s.submitted_at DESC, s.id DESC
      LIMIT 7`;
}

describe("call records split into hot and archive give the flat table's answers",
  { skip: URL ? false : "CDR_TIER_TEST_DATABASE_URL is not set" }, () => {
    const FLAT = `cdr_flat_${process.pid}`;
    const TIERED = `cdr_tiered_${process.pid}`;
    let flat: import("pg").Pool;
    let tiered: import("pg").Pool;
    let admin: import("pg").Pool;

    async function run<T>(pool: import("pg").Pool, sql: string, params: unknown[] = []): Promise<T[]> {
      return (await pool.query(sql, params)).rows as T[];
    }

    /** The same reader on both: as written on flat, routed for `since` on tiered. */
    async function both<T>(sql: string, params: unknown[], since: Date | null): Promise<{ before: T[]; now: T[]; routed: string }> {
      const routed = cdrRouteSql(sql, since, SPLIT);
      return { before: await run<T>(flat, sql, params), now: await run<T>(tiered, routed, params), routed };
    }

    const at = (local: string) => new Date(`${local}:00+05:30`);

    before(async () => {
      const pg = (await import("pg")).default;
      admin = new pg.Pool({ connectionString: URL, max: 1 });
      await run(admin, `CREATE SCHEMA ${FLAT}`);
      await run(admin, `CREATE SCHEMA ${TIERED}`);
      flat = new pg.Pool({ connectionString: URL, max: 1, options: `-c search_path=${FLAT}` });
      tiered = new pg.Pool({ connectionString: URL, max: 1, options: `-c search_path=${TIERED}` });

      await run(flat, `CREATE TABLE cdr_submit (
                 id bigserial PRIMARY KEY, gateway_msg_id text NOT NULL, part_no int NOT NULL DEFAULT 1,
                 account_id text, system_id text, product text, submitted_at timestamptz NOT NULL,
                 price bigint, cost bigint, retry_count int NOT NULL DEFAULT 0, vendor_attempt int NOT NULL DEFAULT 0,
                 dest_addr text, source_addr text, part_count int NOT NULL DEFAULT 1, submit_status int, vendor text)`);
      await run(flat, `CREATE TABLE cdr_final (
                 id bigserial PRIMARY KEY, gateway_msg_id text NOT NULL, part_no int NOT NULL DEFAULT 1,
                 final_state text NOT NULL, final_at timestamptz NOT NULL, dlr_state int, err_code text)`);
      const usageDaily = `CREATE TABLE usage_daily (
                 account_id text NOT NULL, day date NOT NULL, product text NOT NULL,
                 submitted bigint NOT NULL, delivered bigint NOT NULL, failed bigint NOT NULL,
                 expired bigint NOT NULL, pending_at_rollup bigint NOT NULL,
                 unrated_messages bigint NOT NULL, price_total bigint NOT NULL, cost_total bigint NOT NULL,
                 mt_parts bigint, PRIMARY KEY (account_id, day, product))`;
      await run(flat, usageDaily);

      let n = 0;
      async function message(o: { at: Date; product?: string | null; price?: number | null;
        outcome?: [string, number][]; failover?: boolean; account?: string; parts?: number }) {
        //a v7-shaped id carrying the submit's time, as the gateway makes them
        const hex = o.at.getTime().toString(16).padStart(12, "0");
        const id = `${hex.slice(0, 8)}-${hex.slice(8)}-7000-8000-${String(++n).padStart(12, "0")}`;
        const product = o.product === undefined ? "p1" : o.product;
        const account = o.account ?? "acme";
        const insert = `INSERT INTO cdr_submit (gateway_msg_id, account_id, product, submitted_at, price, cost,
                          vendor_attempt, dest_addr, source_addr, part_count, submit_status, vendor)
                        VALUES ($1, $2, $3, $4, $5, $6, $7, '614000' || $8, 'ACME', $9, $10, $11)`;
        if (o.failover) {
          await run(flat, insert, [id, account, product, o.at, null, null, 0, n, o.parts ?? 1, 8, "v1"]);
        }
        const price = o.price === undefined ? 500 : o.price;
        await run(flat, insert, [id, account, product, o.at, price, price === null ? null : 200,
          o.failover ? 1 : 0, n, o.parts ?? 1, 0, "v2"]);
        for (const [state, afterMinutes] of o.outcome ?? []) {
          await run(flat, "INSERT INTO cdr_final (gateway_msg_id, final_state, final_at, dlr_state) VALUES ($1, $2, $3, 2)",
            [id, state, new Date(o.at.getTime() + afterMinutes * 60_000)]);
        }
      }

      for (let d = 1; d <= 28; d++) {
        const day = `2026-01-${String(d).padStart(2, "0")}`;
        await message({ at: at(`${day} 09:00`), outcome: [["DELIVERED", 1]] });
        await message({ at: at(`${day} 10:00`), product: null, price: 1200, outcome: [["FAILED", 2]], failover: d % 3 === 0 });
        if (d % 4 === 0) {
          await message({ at: at(`${day} 11:00`), product: "p2", price: 800, outcome: [["EXPIRED", 1440], ["DELIVERED", 1500]], parts: 2 });
        }
        if (d % 5 === 0) {
          await message({ at: at(`${day} 12:00`), product: "p2", price: null, outcome: [["EXPIRED", 1440]] });
        }
        if (d % 7 === 0) {
          await message({ at: at(`${day} 13:00`), price: 500 });
        }
      }
      //either side of the split: submitted in the archive, receipt in hot -- minutes and days later
      await message({ at: new Date(SPLIT.getTime() - 30 * 60_000), price: 700, outcome: [["DELIVERED", 40]] });
      await message({ at: new Date(SPLIT.getTime() - 5 * 60_000), price: 900, outcome: [["DELIVERED", 2 * 1440]], failover: true });
      await message({ at: new Date(SPLIT.getTime() + 5 * 60_000), price: 300, outcome: [["FAILED", 1]] });
      //a receipt about 20 hours late; a swept EXPIRED at the deadline and the real receipt five days
      //on (inside the correlation's life, past any deadline-based bound); one just under a day
      //before its submit's own clock. Each must still be the outcome the bounds find
      await message({ at: new Date(SPLIT.getTime() - 2 * 3_600_000), price: 410, outcome: [["DELIVERED", 20 * 60]] });
      await message({ at: new Date(SPLIT.getTime() - 3 * 3_600_000), price: 420, outcome: [["EXPIRED", 1440], ["DELIVERED", 5 * 1440]] });
      await message({ at: new Date(SPLIT.getTime() + 3 * 3_600_000), price: 430, outcome: [["DELIVERED", -23 * 60]] });
      await message({ at: at("2026-01-12 09:00"), account: "other", price: 99_999, outcome: [["DELIVERED", 1]] });
      await message({ at: at("2026-02-01 00:00"), price: 77_777, outcome: [["DELIVERED", 1]] });
      await run(flat, ROLLUP, [ZONE, "2026-01-01", "2026-01-24"]);

      //the tiered copy: the same rows, hot from SPLIT on, archived before it
      for (const [t, col] of [["cdr_submit", "submitted_at"], ["cdr_final", "final_at"]] as const) {
        await run(tiered, `CREATE TABLE ${t} (LIKE ${FLAT}.${t} INCLUDING DEFAULTS) PARTITION BY RANGE (${col})`);
        await run(tiered, `CREATE TABLE ${t}_archive (LIKE ${FLAT}.${t} INCLUDING DEFAULTS) PARTITION BY RANGE (${col})`);
        await run(tiered, `CREATE TABLE ${t}_archive_p0 PARTITION OF ${t}_archive FOR VALUES FROM (MINVALUE) TO ('${SPLIT.toISOString()}')`);
        await run(tiered, `CREATE TABLE ${t}_archive_default PARTITION OF ${t}_archive DEFAULT`);
        for (let d = 0; d < 20; d++) {
          const lo = new Date(SPLIT.getTime() + d * 86_400_000);
          const hi = new Date(lo.getTime() + 86_400_000);
          const name = `${t}_${lo.toISOString().slice(0, 10).replace(/-/g, "")}`;
          await run(tiered, `CREATE TABLE ${name} PARTITION OF ${t} FOR VALUES FROM ('${lo.toISOString()}') TO ('${hi.toISOString()}')`);
        }
        await run(tiered, `CREATE TABLE ${t}_default PARTITION OF ${t} DEFAULT`);
        await run(tiered, `INSERT INTO ${t} SELECT * FROM ${FLAT}.${t} WHERE ${col} >= $1`, [SPLIT]);
        await run(tiered, `INSERT INTO ${t}_archive SELECT * FROM ${FLAT}.${t} WHERE ${col} < $1`, [SPLIT]);
        await run(tiered, `CREATE VIEW ${t}_all AS SELECT * FROM ${t} UNION ALL SELECT * FROM ${t}_archive`);
      }
      await run(tiered, usageDaily);
      await run(tiered, `INSERT INTO usage_daily SELECT * FROM ${FLAT}.usage_daily`);
      await run(tiered, `CREATE TABLE cdr_tier (one boolean PRIMARY KEY DEFAULT TRUE, hot_from timestamptz NOT NULL,
                           moving_to timestamptz)`);
      await run(tiered, "INSERT INTO cdr_tier (hot_from) VALUES ($1)", [SPLIT]);

      //the fixture really straddles: rows on both sides, and receipts in hot for archived submits
      const [sides] = await run<{ hot: string; archived: string; crossing: string }>(tiered,
        `SELECT (SELECT count(*) FROM cdr_submit) AS hot, (SELECT count(*) FROM cdr_submit_archive) AS archived,
                (SELECT count(*) FROM cdr_final f JOIN cdr_submit_archive s USING (gateway_msg_id)) AS crossing`);
      assert.ok(Number(sides.hot) > 10 && Number(sides.archived) > 10, JSON.stringify(sides));
      assert.ok(Number(sides.crossing) >= 2, "receipts in hot for submits in the archive");
    });

    after(async () => {
      await flat?.end();
      await tiered?.end();
      if (admin) {
        await run(admin, `DROP SCHEMA IF EXISTS ${FLAT} CASCADE`).catch(() => undefined);
        await run(admin, `DROP SCHEMA IF EXISTS ${TIERED} CASCADE`).catch(() => undefined);
        await admin.end();
      }
    });

    async function statement(since: Date, until: Date) {
      const grain = { vendorAttempt: true };
      const [cut] = await run<StatementCut>(flat, STATEMENT_CUT_SQL, ["acme", since, until, ZONE, "2026-01-25", 24]);
      return both<Record<string, string>>(statementSummarySql(grain), summaryParams("acme", since, until, ZONE, cut), since);
    }

    test("a statement for a month across the split: the same lines, from the views", async () => {
      const { before, now, routed } = await statement(at("2026-01-01 00:00"), at("2026-02-01 00:00"));
      assert.match(routed, /cdr_submit_all/);
      assert.ok(before.length > 20);
      assert.deepEqual(now, before);
    });

    test("a statement period wholly inside hot reads hot alone, and agrees", async () => {
      const { before, now, routed } = await statement(at("2026-01-22 00:00"), at("2026-02-01 00:00"));
      assert.doesNotMatch(routed, /_all/);
      assert.ok(before.length > 0);
      assert.deepEqual(now, before);
    });

    test("a period starting less than the margin inside hot still reads the views", async () => {
      const since = new Date(SPLIT.getTime() + 10 * 60_000);
      const { now, before, routed } = await statement(since, at("2026-02-01 00:00"));
      assert.match(routed, /cdr_submit_all/);
      assert.deepEqual(now, before);
    });

    test("the statement detail and its CSV pages: every message, in order, priced the same", async () => {
      const grain = { vendorAttempt: true };
      const since = at("2026-01-01 00:00");
      const until = at("2026-02-01 00:00");
      const pages = async (pool: "flat" | "tiered") => {
        const out: Record<string, string>[] = [];
        let cursor: [string, string] | null = null;
        for (;;) {
          const sql = statementDetailSql(grain, cursor !== null);
          const params = [...["acme", since, until, 9], ...(cursor ?? [])];
          const rows = pool === "flat"
            ? await run<Record<string, string>>(flat, sql, params)
            : await run<Record<string, string>>(tiered, cdrRouteSql(sql, since, SPLIT), params);
          out.push(...rows);
          if (rows.length < 9) {
            return out;
          }
          const last = rows[rows.length - 1];
          cursor = [new Date(last.submitted_at).toISOString(), last.id];
        }
      };
      const before = await pages("flat");
      assert.ok(before.length > 50);
      assert.deepEqual(await pages("tiered"), before);
    });

    test("the reconciliation's consumption and missing days, MT usage and the portal's window", async () => {
      const grain = { vendorAttempt: true };
      for (const sql of [consumedSql(grain), MISSING_ROLLUP_SQL]) {
        const { before, now } = await both(sql, ["acme", ZONE], null);
        assert.deepEqual(now, before);
      }
      const mt = await both<Record<string, string>>(mtUsageSql({ vendorAttempt: true, mtParts: true, submitStatus: true }),
        ["acme", ZONE], null);
      const sort = (rows: Record<string, string>[]) => [...rows].sort((a, b) => `${a.day}${a.product}`.localeCompare(`${b.day}${b.product}`));
      assert.deepEqual(sort(mt.now), sort(mt.before));
      const window = `${usageWindowSql({ bucket: "day", account: true, wholeDays: false, vendorAttempt: true })}
        SELECT to_char(day, 'YYYY-MM-DD') AS day, SUM(submitted) AS sent, SUM(delivered) AS delivered,
               SUM(price) AS spend FROM usage_rows GROUP BY 1 ORDER BY 1`;
      const since = at("2026-01-10 00:00");
      const portal = await both(window, [since, at("2026-02-01 00:00"), ZONE, "acme"], since);
      assert.ok(portal.before.length > 10);
      assert.deepEqual(portal.now, portal.before);
    });

    test("Messages search over all, over a range across the split and inside hot: the same pages", async () => {
      const pages = async (since: Date | null, pool: "flat" | "tiered") => {
        const out: Record<string, string>[] = [];
        let cursor: [string, string] | null = null;
        for (;;) {
          const sql = searchSql(since !== null, cursor !== null);
          const params = [...(since ? [since] : []), ...(cursor ?? [])];
          const rows = pool === "flat"
            ? await run<Record<string, string>>(flat, sql, params)
            : await run<Record<string, string>>(tiered, cdrRouteSql(sql, since, SPLIT), params);
          out.push(...rows);
          if (rows.length < 7) {
            return out;
          }
          const last = rows[rows.length - 1];
          cursor = [new Date(last.submitted_at).toISOString(), last.id];
        }
      };
      for (const since of [null, at("2026-01-15 00:00"), at("2026-01-23 00:00")]) {
        const before = await pages(since, "flat");
        assert.ok(before.length > 5);
        assert.deepEqual(await pages(since, "tiered"), before, `since ${since?.toISOString() ?? "all"}`);
      }
    });

    test("the receipt bounds change no outcome", async () => {
      //the shared LATERAL with and without its bounds, on the flat table: every message's outcome
      const bounded = `SELECT s.gateway_msg_id, o.final_state FROM cdr_submit s${OUTCOME_LATERAL} ORDER BY 1`;
      const unbounded = bounded.replace(/AND f\.final_at >= s\.submitted_at - interval '1 day'\s*AND f\.final_at < s\.submitted_at \+ interval '\d+ days'\s*AND f\.final_at < now\(\) \+ interval '1 hour'/, "");
      assert.notEqual(unbounded, bounded, "the bounds are there to strip");
      const before = await run<Record<string, string>>(flat, unbounded);
      assert.deepEqual(await run(flat, bounded), before);
      assert.deepEqual(await run(tiered, cdrRouteSql(bounded, null, SPLIT)), before);
      const late = before.filter((r) => r.final_state === "DELIVERED").length;
      assert.ok(late > 30);
    });

    test("a reader nobody routed still sees the archive", async () => {
      const sql = `SELECT count(*)::int AS n, COALESCE(SUM(s.price), 0)::text AS amount
                     FROM cdr_submit s${OUTCOME_LATERAL} WHERE o.final_state = 'DELIVERED'`;
      const [before] = await run<Record<string, string>>(flat, sql);
      const [now] = await run<Record<string, string>>(tiered, cdrRouteUnmarked(sql, SPLIT));
      assert.deepEqual(now, before);
      const [hotOnly] = await run<Record<string, string>>(tiered, sql);
      assert.ok(Number(hotOnly.n) < Number(before.n), "the hot table alone is not the answer");
    });
  });
