/**
 * A small kept-answer cache for reads that run on ROUTINE page loads: one read per key at a time,
 * the answer kept for a while, and a failure that never reaches the page.
 *
 * <p>Why it exists (incident, 2026-10-31, panel 0.15.0.0 on smsc.radianceroutes.com): the account
 * page's context card ran two 90-day reads of the call records on every open, and a module-level
 * "cache" without single flight let every caller that arrived while the cache was cold run its own
 * copy. Ten of them at ~10 s each on a cold remote disk saturated the database, and the gateway's
 * small credit-refill queries starved behind them. Routine reads now go to the summaries; this is
 * the second lock, so that whatever a routine read costs, it costs it once per key per TTL.
 *
 * <ul>
 *   <li><b>Fresh</b> (younger than `ttlMs`): answered at once, no read.</li>
 *   <li><b>Single flight:</b> callers arriving while a read for the key runs share that one promise.
 *       N concurrent calls make one read.</li>
 *   <li><b>Expired:</b> the kept answer is served at once and a refresh runs behind it (one per key),
 *       so a slow database delays the next answer rather than the page -- unless it is older than
 *       `maxStaleMs`, when the caller waits for the (shared) refresh instead: a page opened an hour
 *       after the last one must not be shown the hour-old answer.</li>
 *   <li><b>Failure:</b> never thrown. The last good answer is served if there is one, else
 *       `fallback(error)`; and no new read is started for `retryMs`, so a sick database is asked
 *       once per key per `retryMs`, not once per page load.</li>
 *   <li><b>Bounded:</b> at most `max` keys, the least recently used dropped first.</li>
 * </ul>
 *
 * <p>In memory, per panel process. Unlike `stats-cache.ts` (the heavy report reads, with traces,
 * a concurrency gate and the "still reading" card) this is for small answers a page must never wait
 * on twice. Pure: no database import, so it is tested under node:test directly.
 */

export interface FlightCacheOptions {
  /** How long an answer is fresh, ms. */
  ttlMs: number;
  /** After a failed read, how long before another is tried, ms. Default: `ttlMs`, capped at 30 s. */
  retryMs?: number;
  /** Most keys kept. Default 500. */
  max?: number;
  /**
   * The oldest answer served while a refresh runs behind it, ms. Older, and the caller waits for
   * the refresh (still one per key); if that fails, the old answer is served after all. Default:
   * no limit.
   */
  maxStaleMs?: number;
  now?: () => number;
  /** Told once per failed read; default `console.warn`. */
  onError?: (key: string, error: unknown) => void;
}

interface Entry<T> {
  value?: T;
  has: boolean;
  at: number;
  failedAt: number;
}

export class FlightCache<T> {
  private readonly entries = new Map<string, Entry<T>>();
  private readonly running = new Map<string, Promise<T>>();
  private readonly ttlMs: number;
  private readonly retryMs: number;
  private readonly max: number;
  private readonly maxStaleMs: number;
  private readonly now: () => number;
  private readonly onError: (key: string, error: unknown) => void;

  constructor(o: FlightCacheOptions) {
    this.ttlMs = o.ttlMs;
    this.retryMs = o.retryMs ?? Math.min(o.ttlMs, 30_000);
    this.max = o.max ?? 500;
    this.maxStaleMs = o.maxStaleMs ?? Number.POSITIVE_INFINITY;
    this.now = o.now ?? Date.now;
    this.onError = o.onError ?? ((key, error) => {
      console.warn(`[flight-cache] read for ${key} failed: ${error instanceof Error ? error.message : String(error)}`);
    });
  }

  /**
   * The answer for `key`. Never rejects: a failed read yields the last good answer, else
   * `fallback(error)` (`error` is null when the read is skipped inside the retry window).
   */
  async get(key: string, read: () => Promise<T>, fallback: (error: unknown) => T): Promise<T> {
    const t = this.now();
    const kept = this.entries.get(key);
    if (kept) {
      this.touch(key, kept);
    }
    if (kept?.has) {
      if (t - kept.at >= this.ttlMs && t - kept.failedAt >= this.retryMs) {
        //serve the kept answer, refresh behind it; the refresh never rejects (see flight) -- or,
        //when the kept answer is too old to show, wait for that refresh, which on failure
        //answers with the kept value anyway
        const refresh = this.flight(key, read, fallback);
        if (t - kept.at >= this.maxStaleMs) {
          return refresh;
        }
      }
      return kept.value as T;
    }
    const going = this.running.get(key);
    if (going) {
      return going;
    }
    if (kept && t - kept.failedAt < this.retryMs) {
      return fallback(null);
    }
    return this.flight(key, read, fallback);
  }

  /** Forget one key, or everything. */
  forget(key?: string): void {
    if (key === undefined) {
      this.entries.clear();
    } else {
      this.entries.delete(key);
    }
  }

  /** One read per key; the shared promise resolves to the read's answer or the fallback. */
  private flight(key: string, read: () => Promise<T>, fallback: (error: unknown) => T): Promise<T> {
    const going = this.running.get(key);
    if (going) {
      return going;
    }
    const p = (async () => {
      try {
        const value = await read();
        this.touch(key, { value, has: true, at: this.now(), failedAt: 0 });
        return value;
      } catch (error) {
        this.onError(key, error);
        const last = this.entries.get(key);
        const entry: Entry<T> = last ?? { has: false, at: 0, failedAt: 0 };
        entry.failedAt = this.now();
        this.touch(key, entry);
        return entry.has ? (entry.value as T) : fallback(error);
      } finally {
        this.running.delete(key);
      }
    })();
    this.running.set(key, p);
    return p;
  }

  private touch(key: string, entry: Entry<T>): void {
    this.entries.delete(key);
    this.entries.set(key, entry);
    while (this.entries.size > this.max) {
      const oldest = this.entries.keys().next().value as string;
      this.entries.delete(oldest);
    }
  }
}
