//server-only by convention: node:crypto, and nothing a client component imports
import { createHmac, timingSafeEqual } from "node:crypto";

/**
 * Small signed statements the sign-in code hands itself: the proofs that let a session's claims be
 * refreshed only by the server, and (`totp-pending.ts`) the second-step token of a two-factor
 * sign-in.
 *
 * <p>Signed with HMAC-SHA256 under a key derived from `AUTH_SECRET` (the secret next-auth signs the
 * session cookie with) and a purpose label, so a value made for one purpose is never valid for
 * another, and rotating `AUTH_SECRET` voids them all with the sessions. No `AUTH_SECRET`: nothing
 * can be signed and every check fails -- closed.
 *
 * <h2>Why session updates need a proof</h2>
 *
 * <p>next-auth lets ANY holder of a session cookie ask for an update (`POST /api/auth/session`, the
 * client's `update()`), and the `jwt` callback receives whatever the caller sent. A claim refreshed
 * from that payload is therefore a claim the cookie's holder can set: the password stamp (which is
 * what signs out a session after a password reset) and the two-factor claim alike. The server-side
 * callers send a proof made here instead, and the callback takes the new value only with a proof
 * that verifies.
 */

function secret(): string | null {
  const s = (process.env.AUTH_SECRET ?? process.env.NEXTAUTH_SECRET ?? "").trim();
  return s ? s : null;
}

function keyFor(purpose: string): Buffer | null {
  const s = secret();
  return s ? createHmac("sha256", s).update(`fireflo.auth-proof.v1.${purpose}`).digest() : null;
}

/** HMAC-SHA256 of `message` under the key for `purpose`, base64url; null without AUTH_SECRET. */
export function authMac(purpose: string, message: string): string | null {
  const key = keyFor(purpose);
  return key ? createHmac("sha256", key).update(message).digest("base64url") : null;
}

/** Constant-time equality of two MACs. */
export function sameMac(a: string, b: string): boolean {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}

/**
 * What a proof is for: the password stamp, the two-factor stamp (`mfaAt`), or the two-factor change
 * stamp (`tcAt`, `app_user.totp_changed_at`).
 */
export type ClaimPurpose = "pwd" | "mfa" | "tc";

/** A proof that `value` is the right claim for `userId`, for one purpose. Null without AUTH_SECRET. */
export function signClaim(purpose: ClaimPurpose, userId: string | number, value: number | null): string | null {
  return authMac(purpose, `${userId}.${value ?? "null"}`);
}

/** Whether a proof from {@link signClaim} holds for this user and value. */
export function checkClaim(purpose: ClaimPurpose, userId: string | number, value: number | null, proof: unknown): boolean {
  if (typeof proof !== "string" || !proof) {
    return false;
  }
  const expected = signClaim(purpose, userId, value);
  return expected !== null && sameMac(expected, proof);
}
