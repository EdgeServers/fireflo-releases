import assert from "node:assert/strict";
import { beforeEach, test } from "node:test";

import { FRESH_MS, STALE_MS, forgetAllLiveIdentities, forgetLiveIdentity, liveIdentity, operatorKey } from "./live-identity-cache.ts";

let clock = 1_000_000;
const now = () => clock;

beforeEach(() => {
  forgetAllLiveIdentities();
  clock = 1_000_000;
});

test("within the fresh window the row is not read again", async () => {
  let reads = 0;
  const read = async () => ({ role: "admin", enabled: true, n: ++reads });
  const a = await liveIdentity("operator:1", read, { now });
  clock += FRESH_MS - 1;
  const b = await liveIdentity("operator:1", read, { now });
  assert.equal(reads, 1);
  assert.deepEqual(a, b);
  clock += 2;
  await liveIdentity("operator:1", read, { now });
  assert.equal(reads, 2, "past the window it is read again");
});

test("a read that fails serves the last answer for the stale window, then throws", async () => {
  let fail = false;
  const read = async () => {
    if (fail) {
      throw new Error("Sorry, acquisition timeout!");
    }
    return { enabled: true };
  };
  const stale: string[] = [];
  const onStale = (key: string) => stale.push(key);
  await liveIdentity("operator:2", read, { now, onStale });
  fail = true;
  clock += FRESH_MS + 1;
  assert.deepEqual(await liveIdentity("operator:2", read, { now, onStale }), { enabled: true });
  clock += FRESH_MS + 1;
  assert.deepEqual(await liveIdentity("operator:2", read, { now, onStale }), { enabled: true });
  assert.equal(stale.length, 2, "the fallback is logged once per fresh window");
  clock = 1_000_000 + STALE_MS;
  await assert.rejects(liveIdentity("operator:2", read, { now, onStale }), /acquisition timeout/);
});

test("a successful read replaces the memory, and forgetting makes the next request read", async () => {
  let enabled = true;
  const read = async () => ({ enabled });
  assert.deepEqual(await liveIdentity(operatorKey(3), read, { now }), { enabled: true });
  enabled = false;
  assert.deepEqual(await liveIdentity(operatorKey(3), read, { now }), { enabled: true }, "still fresh");
  forgetLiveIdentity(operatorKey(3));
  assert.deepEqual(await liveIdentity(operatorKey(3), read, { now }), { enabled: false }, "the change applied at once");
});

test("a null answer (no such row) is remembered like any other", async () => {
  let reads = 0;
  const read = async () => { reads++; return null; };
  assert.equal(await liveIdentity("operator:4", read, { now }), null);
  assert.equal(await liveIdentity("operator:4", read, { now }), null);
  assert.equal(reads, 1);
});

test("a read that fails with nothing remembered throws", async () => {
  await assert.rejects(liveIdentity("operator:5", async () => { throw new Error("down"); }, { now }), /down/);
});
