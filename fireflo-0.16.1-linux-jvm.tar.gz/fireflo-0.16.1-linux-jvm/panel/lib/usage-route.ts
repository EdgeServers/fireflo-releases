import { CDR_EVERYTHING } from "./cdr-grain";
import { cdrBoundary } from "./cdr-tier";
import { query } from "./metrics-db";
import { planRoute, routedSql, sliversOf, type RawSlivers, type RoutePlan } from "./usage-route-plan";

/**
 * A summary-backed statement, routed hot or `_all` by where its raw slivers really start
 * (`usage-route-plan.ts`) rather than by its window's start.
 *
 * <p>One extra round trip when the deployment has tiers with a readable boundary: the pre-read of
 * the statement's own `cut` (index endpoints of the summaries, never a call record table). Without
 * tiers, or with a boundary that cannot be read, the choice needs no pre-read and none is made.
 *
 * Server-only: importing this pulls `pg`.
 *
 * @param o.build the statement, given the slivers' own routes when the plan splits them
 * @param o.raw the pre-read (`usageRawSliversSql` and the like) and how many of `params` it binds
 * @param o.splittable whether `build` honours a split (`usageHourlySql`'s `slivers`)
 */
export async function routedQuery<T extends Record<string, unknown>>(o: {
  build: (slivers?: { head: "hot" | "all"; tail: "hot" | "all" }) => string;
  raw: { sql: string; binds: number };
  params: unknown[];
  splittable?: boolean;
}): Promise<T[]> {
  const plan = await planFor(o.raw, o.params, o.splittable ?? false);
  return query<T>(routedSql(plan, o.build), o.params);
}

const NO_SLIVERS: RawSlivers = { head: { from: null, to: null }, tail: { from: null, to: null } };

/** The plan, pre-reading the slivers only when the boundary leaves a choice to make. */
async function planFor(raw: { sql: string; binds: number }, params: unknown[], splittable: boolean): Promise<RoutePlan> {
  const boundary = await cdrBoundary();
  if (boundary === null || boundary === CDR_EVERYTHING) {
    return planRoute(NO_SLIVERS, boundary, { splittable });
  }
  const [row] = await query<Record<string, unknown>>(raw.sql, params.slice(0, raw.binds));
  return planRoute(sliversOf(row), boundary, { splittable });
}
