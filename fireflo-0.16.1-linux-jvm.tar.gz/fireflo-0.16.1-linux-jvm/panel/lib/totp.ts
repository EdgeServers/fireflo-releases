//server-only by convention: node:crypto, and nothing a client component imports
import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";

/**
 * Authenticator codes (TOTP, RFC 6238) for operator two-factor sign-in, with no library.
 *
 * <p>The parameters every authenticator app defaults to and the only ones this panel issues:
 * HMAC-SHA1, six digits, a 30-second step, and one step of drift either way (so a code is good for
 * about 90 seconds around the moment it was shown). A secret is 20 random bytes, the length
 * RFC 4226 recommends for SHA-1, carried as unpadded base32 the way `otpauth://` URIs carry it.
 *
 * <h2>Replay</h2>
 *
 * <p>{@link verifyTotp} returns the step a code matched, and takes the last step already used: a
 * code at or before it is refused, so the same six digits cannot sign in twice, even inside their
 * 90 seconds. The caller stores the matched step (`app_user.totp_last_step`) in the same statement
 * that checks it, so two requests racing with one code cannot both pass.
 *
 * <p>Every candidate step is computed and compared, in constant time, whatever matched first: the
 * time a check takes says nothing about which step, if any, was right.
 */

export const TOTP_DIGITS = 6;
export const TOTP_PERIOD_SECONDS = 30;
/** Steps of clock drift accepted either side of now. */
export const TOTP_WINDOW = 1;
export const TOTP_SECRET_BYTES = 20;
export const TOTP_ISSUER = "FireFlo";

const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

/** RFC 4648 base32, upper case, no padding. */
export function base32Encode(bytes: Uint8Array): string {
  let out = "";
  let bits = 0;
  let value = 0;
  for (const b of bytes) {
    value = (value << 8) | b;
    bits += 8;
    while (bits >= 5) {
      out += ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) {
    out += ALPHABET[(value << (5 - bits)) & 31];
  }
  return out;
}

/**
 * Base32 back to bytes. Case, spaces, dashes and `=` padding are ignored, as an operator typing a key
 * by hand would expect; any other character is not base32 and answers null.
 */
export function base32Decode(text: string): Buffer | null {
  const clean = text.toUpperCase().replace(/[\s=-]/g, "");
  if (!clean) {
    return null;
  }
  const out: number[] = [];
  let bits = 0;
  let value = 0;
  for (const ch of clean) {
    const i = ALPHABET.indexOf(ch);
    if (i < 0) {
      return null;
    }
    value = (value << 5) | i;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

/** A new secret: 20 random bytes as base32 (32 characters). */
export function generateTotpSecret(): string {
  return base32Encode(randomBytes(TOTP_SECRET_BYTES));
}

/** The 30-second step an instant falls in. */
export function totpStep(nowMs: number): number {
  return Math.floor(nowMs / 1000 / TOTP_PERIOD_SECONDS);
}

/** RFC 4226 HOTP: the code for one counter value, zero-padded. */
export function hotp(key: Uint8Array, counter: number, digits = TOTP_DIGITS, algorithm = "sha1"): string {
  const msg = Buffer.alloc(8);
  //counters past 2^53 do not occur: a 30-second step reaches that in about 8.6 billion years
  msg.writeUInt32BE(Math.floor(counter / 2 ** 32), 0);
  msg.writeUInt32BE(counter >>> 0, 4);
  const mac = createHmac(algorithm, key).update(msg).digest();
  const offset = mac[mac.length - 1] & 0xf;
  const bin = ((mac[offset] & 0x7f) << 24) | (mac[offset + 1] << 16) | (mac[offset + 2] << 8) | mac[offset + 3];
  return String(bin % 10 ** digits).padStart(digits, "0");
}

/** The code for an instant. */
export function totpAt(secret: string, nowMs: number): string | null {
  const key = base32Decode(secret);
  return key ? hotp(key, totpStep(nowMs)) : null;
}

/** Digits only: `123 456` and `123-456` as typed are `123456`. */
export function normaliseCode(code: string): string {
  return code.replace(/[\s-]/g, "");
}

/**
 * Checks a typed code against now, one step either way, refusing any step at or before
 * `lastStep`.
 *
 * @returns the step the code matched, or null
 */
export function verifyTotp(
  secret: string,
  code: string,
  o: { now?: number; lastStep?: number | null } = {}
): number | null {
  const typed = normaliseCode(code);
  const key = base32Decode(secret);
  if (!key || key.length < 10 || !/^\d{6}$/.test(typed)) {
    return null;
  }
  const current = totpStep(o.now ?? Date.now());
  const given = Buffer.from(typed);
  let matched: number | null = null;
  for (let step = current - TOTP_WINDOW; step <= current + TOTP_WINDOW; step++) {
    const equal = timingSafeEqual(Buffer.from(hotp(key, step)), given);
    //no early return: every step is computed and compared whether or not one has matched
    if (equal && matched === null) {
      matched = step;
    }
  }
  if (matched === null) {
    return null;
  }
  return o.lastStep != null && matched <= o.lastStep ? null : matched;
}

/**
 * The `otpauth://` URI an authenticator app scans: issuer FireFlo, labelled with the operator's
 * address, and the parameters spelled out though they are every app's defaults.
 */
export function otpauthUri(secret: string, email: string): string {
  const label = `${encodeURIComponent(TOTP_ISSUER)}:${encodeURIComponent(email)}`;
  const params = new URLSearchParams({
    secret,
    issuer: TOTP_ISSUER,
    algorithm: "SHA1",
    digits: String(TOTP_DIGITS),
    period: String(TOTP_PERIOD_SECONDS),
  });
  return `otpauth://totp/${label}?${params}`;
}

/** The key in groups of four, for typing into an app that cannot scan. */
export function spacedSecret(secret: string): string {
  return secret.replace(/(.{4})(?=.)/g, "$1 ");
}
