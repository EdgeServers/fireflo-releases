import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import {
  beginPage, noteSource, pageTotals, recordSource, resetSources, sourceSections, sourcesSnapshot, sourceTooltip,
  subscribeSources,
} from "./page-sources.ts";

beforeEach(() => resetSources());

const DB = (ms: number, calls = 1, extra = "") => `db=192.168.1.101:5432;db_ms=${ms};db_calls=${calls};db_max=${ms / calls};pool=metrics${extra}`;
const GW = (ms: number) => `gw=127.0.0.1:9000;gw_ms=${ms};gw_calls=1;gw_max=${ms}`;

test("a DB page: sum, count and the slowest in the tooltip", () => {
  beginPage("/cp/messages");
  recordSource("traffic", DB(80, 2), "/cp/messages");
  recordSource("vendors", DB(48), "/cp/messages");
  const { entries } = sourcesSnapshot();
  assert.deepEqual(sourceSections(entries), { db: "DB 192.168.1.101:5432 128 ms (3 reads)", gateway: null });
  assert.equal(pageTotals(entries).db?.max, 48);
  const tip = sourceTooltip(entries);
  assert.match(tip, /^Database: 128 ms over 3 reads, slowest 48 ms/);
  assert.match(tip, /traffic · metrics · 192\.168\.1\.101:5432 · 80 ms \(2 reads\)/);
  assert.match(tip, /vendors · metrics · 192\.168\.1\.101:5432 · 48 ms$/m);
});

test("a gateway-served page shows the gateway section only", () => {
  beginPage("/cp");
  recordSource("overview", GW(45), "/cp");
  recordSource("traffic", GW(3.25), "/cp");
  assert.deepEqual(sourceSections(sourcesSnapshot().entries), { db: null, gateway: "Gateway 127.0.0.1:9000 48 ms" });
});

test("both sections, and nothing at all when nothing traced was fetched", () => {
  beginPage("/cp/x");
  assert.deepEqual(sourceSections(sourcesSnapshot().entries), { db: null, gateway: null });
  recordSource("a", `${DB(12)};${GW(4)}`, "/cp/x");
  assert.deepEqual(sourceSections(sourcesSnapshot().entries), {
    db: "DB 192.168.1.101:5432 12 ms (1 read)", gateway: "Gateway 127.0.0.1:9000 4.0 ms",
  });
});

test("from cache only when every DB call was cached", () => {
  beginPage("/cp/receipts");
  recordSource("receipts", DB(900, 3, ";cached=1"), "/cp/receipts");
  assert.equal(sourceSections(sourcesSnapshot().entries).db, "DB 192.168.1.101:5432 900 ms from cache (3 reads)");
  assert.match(sourceTooltip(sourcesSnapshot().entries), /all from cache/);
  assert.match(sourceTooltip(sourcesSnapshot().entries), /· cached$/m);
  recordSource("vendors", DB(20), "/cp/receipts");
  assert.equal(sourceSections(sourcesSnapshot().entries).db, "DB 192.168.1.101:5432 920 ms (4 reads)");
});

test("polls replace their own entry: latest per metric, not cumulative", () => {
  beginPage("/cp");
  recordSource("traffic", DB(100), "/cp");
  recordSource("vendors", DB(10), "/cp");
  recordSource("traffic", DB(30), "/cp");
  recordSource("traffic", DB(40), "/cp");
  const { entries } = sourcesSnapshot();
  assert.deepEqual(entries.map((e) => e.key), ["traffic", "vendors"]);
  assert.equal(sourceSections(entries).db, "DB 192.168.1.101:5432 50 ms (2 reads)");
});

test("an answer without the header keeps the last reading", () => {
  beginPage("/cp");
  recordSource("traffic", DB(30), "/cp");
  recordSource("traffic", null, "/cp");
  noteSource("traffic", { headers: { get: () => null } }, "/cp");
  assert.equal(sourcesSnapshot().entries[0].db?.ms, 30);
});

test("navigation resets; a late answer for the old page is dropped; the same page again keeps it", () => {
  let told = 0;
  subscribeSources(() => told++);
  beginPage("/cp/a");
  recordSource("x", DB(10), "/cp/a");
  beginPage("/cp/a");
  assert.equal(sourcesSnapshot().entries.length, 1);
  beginPage("/cp/b");
  assert.deepEqual(sourcesSnapshot(), { path: "/cp/b", entries: [] });
  recordSource("x", DB(10), "/cp/a");
  assert.equal(sourcesSnapshot().entries.length, 0);
  noteSource("y", { headers: { get: (n: string) => (n === "X-FireFlo-Source" ? GW(5) : null) } }, "/cp/b");
  assert.equal(sourcesSnapshot().entries[0].gateway?.ms, 5);
  assert.ok(told >= 4);
});

test("several database servers are each named", () => {
  beginPage("/cp/vendors");
  recordSource("vendors", "db=10.0.0.1:5432,cfg (10.0.0.2):5432;db_ms=5;db_calls=2;db_max=3;pool=metrics,config", "/cp/vendors");
  assert.equal(sourceSections(sourcesSnapshot().entries).db, "DB 10.0.0.1:5432, cfg (10.0.0.2):5432 5.0 ms (2 reads)");
});
