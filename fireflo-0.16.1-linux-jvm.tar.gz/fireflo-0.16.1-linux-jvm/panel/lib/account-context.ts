/**
 * What one billing account actually has, gathered for the credential form.
 *
 * <p>Server-only: two pools, and neither may be reached from a browser. The shapes live in
 * `account-context-types` so a client component can import them without dragging `pg` in with them.
 *
 * <p><strong>Read-only, and through the read-only pool.</strong> Nothing in this module writes
 * anything; it reads through `metrics-db`, which exposes only `query()`. Writing credit lives in
 * `balance.ts` on the config pool, and even there the panel only ever appends `balance_ledger` rows
 * and creates `account_balance` rows at zero — the gateway's recharge poll remains the one writer of
 * the live `balance` figure.
 *
 * <p>What this adds is visibility: the ledger, so the person looking at a credential can see what
 * has been credited and what has not landed yet.
 */
import type { AccountContext, LedgerView } from "./account-context-types";
import { storedBillingMode } from "./balance-types";
import { signedDelta } from "./ledger-labels";
import { query } from "./metrics-db";
import { cdrIsHot, cdrSql } from "./cdr-tier";
import { FlightCache } from "./flight-cache";
import {
  VENDOR_HOT_FALLBACK_DAYS,
  VENDOR_WINDOW_DAYS,
  VENDORS_HOT_RECORDS_SQL,
  vendorsFromHourlySql,
} from "./account-context-sql";
import { hasUsageHourly, hasUsageHourlyAttempts } from "./metrics-schema";
import { currencyForNewBalance, platformCurrency } from "./platform-currency";
import { scopeKind } from "./rate-types";
import { listRules, resolveKnownScopes } from "./rates";

export type { AccountContext, LedgerEntry, LedgerView } from "./account-context-types";

/**
 * Everything five independent lookups can say about an account, none of them fatal.
 *
 * <p>`allSettled` rather than `all`: a panel pointed at a gateway without the balance tables, or
 * with a role that cannot read them, still has the rest. `null` for "could not read" and
 * `[]` for "read, and there are none" are different states and must not be conflated — an empty
 * ledger under a heading is a fact, a failed query pretending to be one is a lie.
 */
export async function accountContext(
  account: string,
  o: { pricing?: boolean } = {}
): Promise<AccountContext> {
  //`pricing: false` is the reseller portal, which withholds scopes and vendors anyway: it must not
  //pay for reading them
  const pricing = o.pricing ?? true;
  const [balance, ledger, scopes, vendors, currency, inherited] = await Promise.allSettled([
    readBalance(account),
    readLedger(account),
    pricing ? readScopes(account) : Promise.resolve(null),
    pricing ? readVendors(account) : Promise.resolve(null),
    platformCurrency(),
    //the chain a form should actually use: the gateway, then this account's parent. Settled
    //alongside the rest, so a failure here is "we could not work it out" rather than a page that
    //does not render -- and "could not work it out" is the same answer as "nobody has set one",
    //which both surfaces already handle
    currencyForNewBalance(account),
  ]);

  const scopeResult = settled(scopes);

  return {
    account,
    balance: balance.status === "fulfilled" ? balance.value : null,
    //only meaningful when the query itself succeeded; a failed read is not "no row"
    balanceMissing: balance.status === "fulfilled" && balance.value === null,
    ledger: settled(ledger),
    scopes: scopeResult?.scopes ?? null,
    vendors: settled(vendors)?.rows ?? null,
    vendorsWindow: settled(vendors)?.window ?? null,
    //null covers both "could not read" and "not set", which the form has to tell apart from a
    //currency it may safely assume. It asks only when this is null
    platformCurrency: settled(currency),
    currencyForNewBalance: settled(inherited) ?? { code: null, from: null },
    //true here because this function answers for the OPERATOR, who is the party that extends
    //credit in the first place. The portal route narrows it to the reseller's own terms
    mayGrantPostpaid: true,
    //no ceiling for an operator: the credit line starts with them
    postpaidHeadroom: null,
    collidesWithVendor: scopeResult?.collides ?? false,
  };
}

function settled<T>(result: PromiseSettledResult<T>): T | null {
  return result.status === "fulfilled" ? result.value : null;
}

/**
 * The live position.
 *
 * <p><strong>No `WHERE enabled`</strong>, unlike `accountBalances()` on the overview. That filter
 * collapses "there is no row" and "credit is switched off" into the same answer, and those are the
 * two states an operator most needs told apart. `reserved` comes back separately because it has
 * already been handed to a gateway instance and is not available to spend.
 */
async function readBalance(account: string): Promise<AccountContext["balance"]> {
  const rows = await query<{
    balance: string;
    reserved: string;
    currency: string | null;
    enabled: boolean;
    billing_mode: string;
    credit_limit: string;
  }>(
    `SELECT balance, reserved, currency, enabled, billing_mode, credit_limit
       FROM account_balance WHERE account_id = $1`,
    [account]
  );
  const row = rows[0];
  return row
    ? {
        balance: Number(row.balance),
        reserved: Number(row.reserved),
        currency: row.currency,
        enabled: row.enabled,
        billingMode: storedBillingMode(row.billing_mode),
        creditLimit: Number(row.credit_limit),
      }
    : null;
}

/**
 * The ledger. Every row in it is somebody's money.
 *
 * <p>This used to filter, and to count what it had filtered so the card could admit it. Gateway
 * migration V1.51.0 moved the gateway's own RESERVE/RELEASE bookkeeping to `balance_reservation`,
 * which is what lets `balance_ledger` be append-only — so there is nothing left here to hide, no
 * predicate to keep byte-identical with a partial index that no longer exists, and no second
 * round trip to count the hidden rows.
 */
async function readLedger(account: string): Promise<LedgerView> {
  const rows = await query<{
    id: string;
    delta: string;
    entry_type: string;
    ref: string | null;
    note: string | null;
    applied: boolean;
    created_at: string;
  }>(
    `SELECT id, delta, entry_type, ref, note, applied, created_at
       FROM balance_ledger
      WHERE account_id = $1
      ORDER BY created_at DESC, id DESC
      LIMIT 50`,
    [account]
  );

  return {
    entries: rows.map((r) => ({
      id: Number(r.id),
      //signed here, once: a DEBIT's stored delta is positive and the type carries the direction
      delta: signedDelta(r.entry_type, Number(r.delta)),
      entryType: r.entry_type,
      ref: r.ref,
      note: r.note,
      applied: r.applied,
      createdAt: r.created_at,
    })),
  };
}

/**
 * The rate scopes that price this account, and whether the name is ambiguous.
 *
 * <p>A scope is just a name, and `scopeKind` decides what it means by looking it up in both
 * directions. An account id that is also a vendor name is a real hazard rather than a curiosity: the
 * same rules would be read as cost for one and price for the other.
 */
async function readScopes(
  account: string
): Promise<{ scopes: { scope: string; kind: string; rules: number }[]; collides: boolean }> {
  const [rules, known] = await Promise.all([listRules(account), resolveKnownScopes()]);
  return {
    scopes: rules.length ? [{ scope: account, kind: scopeKind(account, known), rules: rules.length }] : [],
    collides: known.vendors.includes(account),
  };
}

/**
 * Where this account's traffic actually went, over {@link VENDOR_WINDOW_DAYS}.
 *
 * <p><strong>From the hourly summary, never the call records over a window.</strong> This runs on
 * every account page open (twice: the shell and the overview each ask) and on every credential form
 * lookup. Its 90-day `cdr_submit` form routed onto the archive and was one of the two reads that
 * saturated production's database on 2026-10-31 (see `account-context-sql.ts`). The summary lags
 * live traffic by the rollup tick, which this card does not mind; the card says so.
 *
 * <p>Kept per account for five minutes, one read per account at a time, and a failure answers with
 * the last list (or none) instead of failing the page -- see `flight-cache.ts`.
 *
 * <p><strong>Not filtered to `part_no = 1`'s representative</strong>, which every aggregate on the
 * revenue page is: a retry that landed on a second vendor is precisely what this asks about.
 */
async function readVendors(account: string): Promise<VendorsView> {
  return vendorsCache.get(account, () => readVendorsNow(account), () => ({ rows: [], window: null }));
}

type VendorsView = { rows: { vendor: string; messages: number }[]; window: AccountContext["vendorsWindow"] };

const vendorsCache = new FlightCache<VendorsView>({ ttlMs: 5 * 60_000, max: 1000 });

async function readVendorsNow(account: string): Promise<VendorsView> {
  if (await hasUsageHourly()) {
    const rows = await query<{ vendor: string; messages: string }>(
      vendorsFromHourlySql(await hasUsageHourlyAttempts()),
      [account, String(VENDOR_WINDOW_DAYS)]
    );
    return {
      rows: rows.map((r) => ({ vendor: r.vendor, messages: Number(r.messages) })),
      window: { days: VENDOR_WINDOW_DAYS, source: "summary" },
    };
  }
  //a gateway before V1.91.0 has no summary to lean on: the hot table only, and only when the
  //window really is inside it -- otherwise nothing, rather than a read of the archive
  const since = new Date(Date.now() - VENDOR_HOT_FALLBACK_DAYS * 86_400_000);
  if (!(await cdrIsHot(since))) {
    return { rows: [], window: null };
  }
  const rows = await query<{ vendor: string | null; messages: string }>(
    await cdrSql(VENDORS_HOT_RECORDS_SQL, since),
    [account, since]
  );
  return {
    rows: rows.map((r) => ({ vendor: r.vendor ?? "", messages: Number(r.messages) })),
    window: { days: VENDOR_HOT_FALLBACK_DAYS, source: "records" },
  };
}
