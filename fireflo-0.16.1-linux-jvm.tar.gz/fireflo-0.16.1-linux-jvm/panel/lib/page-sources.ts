import { parseSource, SOURCE_HEADER, type SourceSummary } from "./source-header.ts";

/**
 * What the page on screen has fetched, and from where: the operator footer's data-source stat
 * ("DB 192.168.1.101:5432 128 ms (3 reads) · Gateway 127.0.0.1:9000 45 ms", 0.15.1).
 *
 * <p>Every answer from a traced route carries `X-FireFlo-Source` (`lib/source-header.ts`). The
 * fetchers -- `useStats` in `components/useControlData.ts`, the statement loader, and the pages
 * that read the traced routes directly -- hand it here under a key naming what was fetched (the
 * metric). The footer (`components/PageTiming.tsx`) subscribes and adds it up.
 *
 * <ul>
 *   <li><b>One page at a time.</b> {@link beginPage} on every route change empties the store, and
 *       an answer for a page that is no longer on screen is dropped.</li>
 *   <li><b>Latest per key.</b> A polling chart replaces its own entry on every poll, so the
 *       figures are what the page costs now, not a running total of every poll since it opened.</li>
 *   <li><b>No header, no entry.</b> A 202 "still reading", a failure or an untraced route leaves
 *       the key's last reading in place.</li>
 * </ul>
 *
 * <p>Module state with a subscribe/snapshot pair for `useSyncExternalStore`, and no React import,
 * so the rules are tested under plain `node --test`. Browser-only in practice: the server never
 * records anything.
 */

export interface SourceEntry extends SourceSummary {
  /** What was fetched: a metric name, or the route's own short name. */
  key: string;
}

export interface PageSources {
  /** The page these are for. */
  path: string | null;
  /** In the order first fetched; a key re-fetched keeps its place. */
  entries: readonly SourceEntry[];
}

let state: PageSources = { path: null, entries: [] };
const listeners = new Set<() => void>();

function publish(next: PageSources): void {
  state = next;
  for (const l of listeners) {
    l();
  }
}

/** The page now on screen; the current `location.pathname` when there is a window. */
function here(): string | null {
  return typeof window === "undefined" ? null : window.location.pathname;
}

/** A new page: what the last one fetched no longer applies. The same page again changes nothing. */
export function beginPage(path: string | null = here()): void {
  if (state.path === path) {
    return;
  }
  publish({ path, entries: [] });
}

/**
 * Records one answer's header under `key`.
 *
 * @param path the page that asked: pass the pathname read when the request was SENT, so an answer
 *     landing after the user moved on is dropped rather than charged to the new page
 */
export function recordSource(key: string, header: string | null | undefined, path: string | null = here()): void {
  const summary = parseSource(header);
  if (!summary) {
    return;
  }
  if (state.path !== null && path !== state.path) {
    return;
  }
  const entry: SourceEntry = { key, ...summary };
  const at = state.entries.findIndex((e) => e.key === key);
  const entries = at < 0
    ? [...state.entries, entry]
    : state.entries.map((e, i) => (i === at ? entry : e));
  publish({ path: state.path ?? path, entries });
}

/** {@link recordSource} from a fetch `Response` (anything with `headers.get`). */
export function noteSource(key: string, res: { headers?: { get(name: string): string | null } } | null | undefined, path?: string | null): void {
  recordSource(key, res?.headers?.get(SOURCE_HEADER) ?? null, path === undefined ? here() : path);
}

export function subscribeSources(listener: () => void): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function sourcesSnapshot(): PageSources {
  return state;
}

/** The server renders no sources: nothing has been fetched there. */
const EMPTY: PageSources = { path: null, entries: [] };
export function serverSourcesSnapshot(): PageSources {
  return EMPTY;
}

/** Test helper. */
export function resetSources(): void {
  listeners.clear();
  state = { path: null, entries: [] };
}

/** One side of the footer: the page's calls added up. */
export interface SourceTotal {
  hosts: string[];
  /** The sum of every call, ms. */
  ms: number;
  /** The slowest single call, ms. */
  max: number;
  calls: number;
  /** Every call was a kept answer. */
  cached: boolean;
}

export interface PageTotals {
  db: SourceTotal | null;
  gateway: SourceTotal | null;
}

function add(sides: { host: string; ms: number; max: number; calls: number; cached: boolean }[]): SourceTotal | null {
  if (!sides.length) {
    return null;
  }
  return {
    hosts: [...new Set(sides.flatMap((s) => s.host.split(",")).filter(Boolean))],
    ms: sides.reduce((n, s) => n + s.ms, 0),
    max: Math.max(...sides.map((s) => s.max)),
    calls: sides.reduce((n, s) => n + s.calls, 0),
    cached: sides.every((s) => s.cached),
  };
}

export function pageTotals(entries: readonly SourceEntry[]): PageTotals {
  return {
    db: add(entries.flatMap((e) => (e.db ? [e.db] : []))),
    gateway: add(entries.flatMap((e) => (e.gateway ? [e.gateway] : []))),
  };
}

/** "128 ms", "4.2 ms": a tenth only where it says something. */
export function formatMs(ms: number): string {
  return ms < 10 ? `${(Math.round(ms * 10) / 10).toFixed(1)} ms` : `${Math.round(ms)} ms`;
}

/** The footer's sections, after "Page generated in …": each present only when the page made such calls. */
export function sourceSections(entries: readonly SourceEntry[]): { db: string | null; gateway: string | null } {
  const t = pageTotals(entries);
  const db = t.db
    ? `DB ${t.db.hosts.join(", ")} ${formatMs(t.db.ms)}${t.db.cached ? " from cache" : ""} (${t.db.calls} ${t.db.calls === 1 ? "read" : "reads"})`
    : null;
  const gateway = t.gateway
    ? `Gateway ${t.gateway.hosts.join(", ")} ${formatMs(t.gateway.ms)}${t.gateway.cached ? " from cache" : ""}`
    : null;
  return { db, gateway };
}

/** The tooltip: the totals with the slowest call, then each fetch -- what, pool, host, time, cached. */
export function sourceTooltip(entries: readonly SourceEntry[]): string {
  const t = pageTotals(entries);
  const lines: string[] = [];
  if (t.db) {
    lines.push(`Database: ${formatMs(t.db.ms)} over ${t.db.calls} ${t.db.calls === 1 ? "read" : "reads"}, slowest ${formatMs(t.db.max)}${t.db.cached ? ", all from cache" : ""}`);
  }
  if (t.gateway) {
    lines.push(`Gateway: ${formatMs(t.gateway.ms)} over ${t.gateway.calls} ${t.gateway.calls === 1 ? "call" : "calls"}, slowest ${formatMs(t.gateway.max)}${t.gateway.cached ? ", all from cache" : ""}`);
  }
  for (const e of entries) {
    if (e.db) {
      lines.push(`${e.key} · ${e.db.pools.join("+") || "db"} · ${e.db.host} · ${formatMs(e.db.ms)}${e.db.calls > 1 ? ` (${e.db.calls} reads)` : ""}${e.db.cached ? " · cached" : ""}`);
    }
    if (e.gateway) {
      lines.push(`${e.key} · gateway · ${e.gateway.host} · ${formatMs(e.gateway.ms)}${e.gateway.calls > 1 ? ` (${e.gateway.calls} calls)` : ""}${e.gateway.cached ? " · cached" : ""}`);
    }
  }
  return lines.join("\n");
}
