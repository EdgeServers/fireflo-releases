import { test } from "node:test";
import assert from "node:assert/strict";
import { NON_BANNABLE_REASONS, type RefusalSummaryRow } from "./ban-rules.ts";
import { FAIL2BAN_SCOPE, isNonBannable } from "./refusal-views.ts";
import { emptySurfaceCounts, parseGatewayRefusals, reasonLabel, surfaceLabel } from "./security-events.ts";
import { SURFACES, bucketsFor, groupByAddress } from "./security-grouping.ts";
import { GRPC_LISTENER, addressRowsFrom, attemptsFrom, ledgerRowsFrom, listenerOptions, portLabel, surfaceOfLedgerRow } from "./security-rows.ts";

/**
 * Gateway 0.15.9's gRPC listener as a third gateway surface: its refusal lines, its ledger rows
 * (listener `grpc`, port from the row), the filters, and the one reason that must never ban.
 */

const LINES = [
  '2026-11-09 10:12:03,511 WARN  auth.refused surface=grpc reason=badPassword identity="acme" listener=grpc port=8090 ip=203.0.113.9',
  '2026-11-09 10:12:04,100 WARN  auth.refused surface=grpc reason=sessionExpired identity="acme" listener=grpc port=8090 ip=198.51.100.4',
  '2026-11-09 10:12:05 WARN  auth.refused surface=smpp reason=badPassword identity="acme" listener=smppserver.main port=22775 ip=203.0.113.9',
  '2026-11-09 10:12:06 WARN  auth.refused surface=rest reason=missingCredential identity="-" ip=192.0.2.7',
];

const GRPC_ROW: RefusalSummaryRow = {
  listener: "grpc",
  port: 8090,
  total: 7,
  byReason: [{ reason: "badPassword", count: 6 }, { reason: "sessionExpired", count: 1 }],
  byAddress: [
    { ip: "203.0.113.9", count: 6, byReason: [{ reason: "badPassword", count: 6 }], identities: ["acme"], firstAt: "2026-11-09T10:00:00Z", lastAt: "2026-11-09T10:12:03Z", heldOut: false },
    { ip: "198.51.100.4", count: 1, byReason: [{ reason: "sessionExpired", count: 1 }], identities: ["acme"], firstAt: "2026-11-09T10:12:04Z", lastAt: "2026-11-09T10:12:04Z", heldOut: false },
  ],
};
const SMPP_ROW: RefusalSummaryRow = {
  listener: "smppserver.main",
  port: 22775,
  total: 1,
  byReason: [{ reason: "badPassword", count: 1 }],
  byAddress: [{ ip: "203.0.113.9", count: 1, byReason: [{ reason: "badPassword", count: 1 }], identities: ["acme"], firstAt: null, lastAt: null, heldOut: false }],
};
const REST_ROW: RefusalSummaryRow = {
  listener: null,
  port: 8081,
  total: 1,
  byReason: [{ reason: "missingCredential", count: 1 }],
  byAddress: [{ ip: "192.0.2.7", count: 1, byReason: [{ reason: "missingCredential", count: 1 }], identities: [], firstAt: null, lastAt: null, heldOut: false }],
};
const LEDGER = [GRPC_ROW, SMPP_ROW, REST_ROW];

test("a gRPC refusal line parses with surface grpc, listener grpc and its port", () => {
  const events = parseGatewayRefusals(LINES);
  assert.equal(events.length, 4);
  assert.deepEqual(events[0], {
    at: "2026-11-09T10:12:03",
    surface: "grpc",
    reason: "badPassword",
    triedAs: "acme",
    ip: "203.0.113.9",
    listener: "grpc",
    port: 8090,
  });
  assert.equal(events[1].reason, "sessionExpired");
});

test("an unknown surface still fails to parse rather than being guessed", () => {
  assert.equal(parseGatewayRefusals(['2026-11-09 10:12:03 WARN  auth.refused surface=quic reason=badPassword identity="a" ip=10.0.0.1']).length, 0);
});

test("the ledger's grpc listener is the gRPC surface; named SMPP workers stay smpp, unnamed stays rest", () => {
  assert.equal(surfaceOfLedgerRow(GRPC_ROW), "grpc");
  assert.equal(surfaceOfLedgerRow(SMPP_ROW), "smpp");
  assert.equal(surfaceOfLedgerRow(REST_ROW), "rest");
  assert.equal(GRPC_LISTENER, "grpc");
});

test("the gRPC port label comes from the row", () => {
  assert.equal(portLabel({ listener: "grpc", port: 8090 }), "grpc :8090");
  assert.equal(portLabel({ listener: "grpc", port: 9443 }), "grpc :9443");
  assert.deepEqual(listenerOptions([], LEDGER).map(portLabel), ["grpc :8090", "smppserver.main :22775"]);
});

test("the surface filter keeps gRPC apart from SMPP and REST, in both sources", () => {
  const events = parseGatewayRefusals(LINES);
  assert.deepEqual(attemptsFrom(events, { surface: "grpc" }).map((e) => e.ip), ["203.0.113.9", "198.51.100.4"]);
  assert.deepEqual(ledgerRowsFrom(LEDGER, { surface: "grpc" }).map((r) => r.listener), ["grpc"]);
  assert.deepEqual(ledgerRowsFrom(LEDGER, { surface: "smpp" }).map((r) => r.listener), ["smppserver.main"]);
  assert.deepEqual(ledgerRowsFrom(LEDGER, { surface: "rest" }).map((r) => r.listener), [null]);
});

test("an address refused on gRPC and SMPP is one row with both ports and both surfaces counted", () => {
  const rows = addressRowsFrom(parseGatewayRefusals(LINES), LEDGER, [], []);
  const busy = rows.find((r) => r.ip === "203.0.113.9")!;
  assert.deepEqual(busy.bySurface, { ...emptySurfaceCounts(), grpc: 1, smpp: 1 });
  assert.deepEqual(busy.ports.map(portLabel), ["grpc :8090", "smppserver.main :22775"]);
  assert.equal(busy.canWatch, true, "it was refused on an SMPP listener too");
});

test("an address refused only on gRPC offers no SMPP watch", () => {
  const rows = addressRowsFrom([], [GRPC_ROW], [], []);
  const expired = rows.find((r) => r.ip === "198.51.100.4")!;
  assert.deepEqual(expired.ports, [{ listener: "grpc", port: 8090, count: 1 }]);
  assert.equal(expired.canWatch, false);
});

test("sessionExpired never bans: the gateway's filter ignores it and so does a rule", () => {
  assert.ok(NON_BANNABLE_REASONS.includes("sessionExpired"));
  assert.equal(isNonBannable("sessionExpired"), true);
  assert.notEqual(reasonLabel("sessionExpired"), "sessionExpired");
});

test("gRPC is a surface on the chart, the tiles and the filter", () => {
  assert.ok(SURFACES.includes("grpc"));
  assert.equal(surfaceLabel("grpc"), "gRPC");
  assert.equal(emptySurfaceCounts().grpc, 0);
  const events = parseGatewayRefusals(LINES);
  assert.equal(groupByAddress(events).find((g) => g.ip === "203.0.113.9")!.bySurface.grpc, 1);
  const now = Date.parse("2026-11-09T11:00:00");
  const buckets = bucketsFor(events, 24, now);
  assert.equal(buckets.reduce((n, b) => n + b.bySurface.grpc, 0), 2);
});

test("the fail2ban sentence names gRPC and says expired sessions never count", () => {
  assert.match(FAIL2BAN_SCOPE, /gRPC logins/);
  assert.match(FAIL2BAN_SCOPE, /expired gRPC sessions never count/);
  assert.match(FAIL2BAN_SCOPE, /every port/);
});
