import { test } from "node:test";
import assert from "node:assert/strict";
import { BUILTIN_REGISTRY } from "./config-key-registry.ts";
import { GATEWAY_SECTIONS, GATEWAY_SETTING_FIELDS, gatewayFieldsIn } from "./gateway-setting-fields.ts";
import { judgeGatewayKey } from "./gateway-key-policy.ts";

/** Gateway 0.15.9's platform keys for the gRPC listener (plan-0159-grpc.md 6.2, V1.129.0). */
const GRPC_KEYS: Record<string, string | null> = {
  "smsg.grpc.session.idle.seconds": "3600",
  "smsg.grpc.session.max.seconds": "86400",
  "smsg.grpc.session.max.per.login": "64",
  "smsg.grpc.proxy.forwarding": null,
  "smsg.grpc.proxy.hops": null,
  "smsg.grpc.stream.max.inflight": "256",
  "smsg.grpc.receipts.enabled": "true",
  "smsg.grpc.receipts.lease.seconds": "120",
  "smsg.grpc.receipts.window": "1000",
  "smsg.grpc.receipts.pull.max": "1000",
  "smsg.grpc.receipts.poll.ms": "250",
  "smsg.grpc.receipts.max.per.login": "1000000",
  "smsg.grpc.receipts.retention.days": null,
};

test("the gRPC section holds exactly the thirteen smsg.grpc.* keys, with the design's defaults", () => {
  assert.ok(GATEWAY_SECTIONS.some((s) => s.id === "grpc"));
  const fields = gatewayFieldsIn("grpc");
  assert.deepEqual(fields.map((f) => f.key).sort(), Object.keys(GRPC_KEYS).sort());
  for (const f of fields) {
    assert.equal(f.codedDefault, GRPC_KEYS[f.key], f.key);
    assert.equal(f.startup, undefined, `${f.key} is hot, not read once at start`);
  }
  //no smsg.grpc.* key hides in another section
  assert.equal(GATEWAY_SETTING_FIELDS.filter((f) => f.key.startsWith("smsg.grpc.")).length, fields.length);
});

test("every gRPC hint names its key, its scope (platform, hot) and what it limits", () => {
  for (const f of gatewayFieldsIn("grpc")) {
    assert.ok(f.hint, f.key);
    assert.ok(f.hint!.includes(`Platform key ${f.key}`), `${f.key}: the hint names the key and its scope`);
    assert.match(f.hint!, /\bhot\b/, `${f.key}: the hint says it applies without a restart`);
    assert.match(f.hint!, /limits|decides|bounds|applies to|only read/, `${f.key}: the hint says what it limits`);
  }
});

test("the keys that follow another key when unset say which, and claim no default of their own", () => {
  const byKey = new Map(gatewayFieldsIn("grpc").map((f) => [f.key, f]));
  for (const key of ["smsg.grpc.proxy.forwarding", "smsg.grpc.proxy.hops", "smsg.grpc.receipts.retention.days"]) {
    const f = byKey.get(key)!;
    assert.equal(f.codedDefault, null, key);
    assert.ok(f.unsetLabel, `${key} says what unset means`);
  }
  assert.match(byKey.get("smsg.grpc.proxy.hops")!.hint!, /smsg\.restapi\.proxy\.hops/);
  assert.match(byKey.get("smsg.grpc.receipts.retention.days")!.hint!, /smsg\.dlr\.retention\.days/);
});

test("every gRPC key is editable, platform-scoped, in the built-in registry", () => {
  for (const key of Object.keys(GRPC_KEYS)) {
    const row = BUILTIN_REGISTRY.platform.get(key);
    assert.ok(row, `${key} is in the built-in registry`);
    assert.equal(row!.access, "editable", key);
    assert.equal(row!.secret, false, key);
    assert.equal(judgeGatewayKey(key).allowed, true, key);
  }
});

test("the REST rate limit's hint says gRPC shares it", () => {
  const rate = GATEWAY_SETTING_FIELDS.find((f) => f.key === "smsg.restapi.maxRate.default")!;
  assert.match(rate.hint!, /shared by REST and gRPC/);
  assert.match(rate.hint!, /RESOURCE_EXHAUSTED/);
});
