import assert from "node:assert/strict";
import { test } from "node:test";

import { FlightCache } from "./flight-cache.ts";

function clock(start = 1_000_000) {
  let t = start;
  return { now: () => t, advance: (ms: number) => { t += ms; } };
}

function deferred<T>() {
  let resolve!: (v: T) => void;
  let reject!: (e: unknown) => void;
  const promise = new Promise<T>((res, rej) => { resolve = res; reject = rej; });
  return { promise, resolve, reject };
}

const quiet = () => undefined;

test("N concurrent callers on a cold key make one read and share its answer", async () => {
  const c = clock();
  const cache = new FlightCache<string[]>({ ttlMs: 60_000, now: c.now, onError: quiet });
  let reads = 0;
  const gate = deferred<string[]>();
  const read = () => { reads++; return gate.promise; };
  const calls = Array.from({ length: 10 }, () => cache.get("acct", read, () => []));
  gate.resolve(["v1"]);
  const answers = await Promise.all(calls);
  assert.equal(reads, 1);
  for (const a of answers) {
    assert.deepEqual(a, ["v1"]);
  }
});

test("different keys are read separately", async () => {
  const cache = new FlightCache<string>({ ttlMs: 60_000, onError: quiet });
  const seen: string[] = [];
  const read = (k: string) => async () => { seen.push(k); return k; };
  assert.equal(await cache.get("a", read("a"), () => ""), "a");
  assert.equal(await cache.get("b", read("b"), () => ""), "b");
  assert.deepEqual(seen, ["a", "b"]);
});

test("a fresh answer is not read again; an expired one is served at once and refreshed behind", async () => {
  const c = clock();
  const cache = new FlightCache<number>({ ttlMs: 5 * 60_000, now: c.now, onError: quiet });
  let reads = 0;
  const read = async () => ++reads;
  assert.equal(await cache.get("k", read, () => 0), 1);
  c.advance(5 * 60_000 - 1);
  assert.equal(await cache.get("k", read, () => 0), 1);
  assert.equal(reads, 1, "inside the TTL there is no read");
  c.advance(2);
  //expired: the kept answer at once, a refresh started behind it
  assert.equal(await cache.get("k", read, () => 0), 1);
  await new Promise((r) => setImmediate(r));
  assert.equal(reads, 2);
  assert.equal(await cache.get("k", read, () => 0), 2, "the refresh replaced the answer");
});

test("concurrent callers on an expired key start one refresh", async () => {
  const c = clock();
  const cache = new FlightCache<number>({ ttlMs: 1_000, now: c.now, onError: quiet });
  let reads = 0;
  await cache.get("k", async () => ++reads, () => 0);
  c.advance(1_000);
  const gate = deferred<number>();
  const read = () => { reads++; return gate.promise; };
  const answers = await Promise.all(Array.from({ length: 5 }, () => cache.get("k", read, () => 0)));
  assert.deepEqual(answers, [1, 1, 1, 1, 1]);
  assert.equal(reads, 2);
  gate.resolve(9);
});

test("a failed first read answers with the fallback and never throws", async () => {
  const errors: string[] = [];
  const cache = new FlightCache<string[]>({ ttlMs: 60_000, onError: (k) => errors.push(k) });
  const v = await cache.get("k", async () => { throw new Error("canceling statement due to statement timeout"); }, () => []);
  assert.deepEqual(v, []);
  assert.deepEqual(errors, ["k"]);
});

test("a failed refresh keeps serving the last good answer", async () => {
  const c = clock();
  const cache = new FlightCache<string>({ ttlMs: 1_000, now: c.now, onError: quiet });
  await cache.get("k", async () => "good", () => "none");
  c.advance(1_000);
  const failing = async () => { throw new Error("down"); };
  assert.equal(await cache.get("k", failing, () => "none"), "good");
  await new Promise((r) => setImmediate(r));
  assert.equal(await cache.get("k", failing, () => "none"), "good");
});

test("after a failure no new read is tried inside the retry window", async () => {
  const c = clock();
  const cache = new FlightCache<string>({ ttlMs: 60_000, retryMs: 30_000, now: c.now, onError: quiet });
  let reads = 0;
  const failing = async () => { reads++; throw new Error("down"); };
  assert.equal(await cache.get("k", failing, () => "none"), "none");
  assert.equal(await cache.get("k", failing, () => "none"), "none");
  assert.equal(reads, 1, "a sick database is asked once per retry window, not per page load");
  c.advance(30_000);
  assert.equal(await cache.get("k", async () => "back", () => "none"), "back");
});

test("bounded: past max keys the least recently used is dropped", async () => {
  const cache = new FlightCache<string>({ ttlMs: 60_000, max: 2, onError: quiet });
  let reads = 0;
  const read = (v: string) => async () => { reads++; return v; };
  await cache.get("a", read("a"), () => "");
  await cache.get("b", read("b"), () => "");
  await cache.get("a", read("a"), () => "");
  await cache.get("c", read("c"), () => "");
  assert.equal(reads, 3);
  await cache.get("a", read("a"), () => "");
  assert.equal(reads, 3, "a was used recently and kept");
  await cache.get("b", read("b"), () => "");
  assert.equal(reads, 4, "b was dropped");
});

test("an answer older than maxStaleMs is not served: the caller waits for the shared refresh", async () => {
  const c = clock();
  const cache = new FlightCache<number>({ ttlMs: 1_000, maxStaleMs: 1_000, now: c.now, onError: () => {} });
  let n = 0;
  const read = async () => ++n;
  assert.equal(await cache.get("k", read, () => -1), 1);
  c.advance(1_000);
  //expired and too old to show: both callers wait for one read and get its answer
  const [a, b] = await Promise.all([cache.get("k", read, () => -1), cache.get("k", read, () => -1)]);
  assert.deepEqual([a, b, n], [2, 2, 2]);
  //a failed refresh still answers with the last good value, not the fallback
  c.advance(1_000);
  assert.equal(await cache.get("k", async () => { throw new Error("down"); }, () => -1), 2);
});
