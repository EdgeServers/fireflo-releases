import { test } from "node:test";
import assert from "node:assert/strict";
import { endpointLabel, labelFor, parseEndpoint, resetEndpointLabels } from "./db-endpoint.ts";

test("host and port from a URL, never the credentials", () => {
  assert.deepEqual(parseEndpoint("postgres://fireflo:s3cret@db.internal:6432/fireflo?sslmode=require"),
    { host: "db.internal", port: "6432", socket: false });
  assert.deepEqual(parseEndpoint("postgresql://u:p@10.128.0.2/fireflo"), { host: "10.128.0.2", port: "5432", socket: false });
  assert.deepEqual(parseEndpoint("postgres://u@[::1]:5433/db"), { host: "::1", port: "5433", socket: false });
  assert.deepEqual(parseEndpoint("postgres:///fireflo"), { host: "localhost", port: "5432", socket: false });
  assert.equal(parseEndpoint("not a url with s3cret"), null);
});

test("a Unix socket URL reports local socket", () => {
  for (const url of [
    "postgres:///fireflo?host=/var/run/postgresql",
    "postgres://u:p@%2Fvar%2Frun%2Fpostgresql/fireflo",
    "socket:/var/run/postgresql?db=fireflo",
  ]) {
    assert.equal(endpointLabel(parseEndpoint(url)), "local socket", url);
  }
});

test("the address is shown only when it differs from the host", () => {
  const named = parseEndpoint("postgres://u:p@db.internal:5432/x");
  assert.equal(endpointLabel(named, "10.128.0.2"), "db.internal (10.128.0.2):5432");
  assert.equal(endpointLabel(named), "db.internal:5432");
  const ip = parseEndpoint("postgres://u:p@192.168.1.101/x");
  assert.equal(endpointLabel(ip, "192.168.1.101"), "192.168.1.101:5432");
  assert.equal(endpointLabel(parseEndpoint("postgres://u@[::1]:5433/db")), "[::1]:5433");
  assert.equal(endpointLabel(null), "unknown");
});

test("labelFor resolves a name once, skips IPs, falls back to the name on failure, never leaks secrets", async () => {
  resetEndpointLabels();
  let asked = 0;
  const resolve = async (host: string) => { asked++; if (host === "gone.example") throw new Error("ENOTFOUND"); return "10.0.0.7"; };
  const url = "postgres://reader:hunter2@db.internal:5432/fireflo";
  assert.equal(await labelFor(url, resolve), "db.internal (10.0.0.7):5432");
  assert.equal(await labelFor(url, resolve), "db.internal (10.0.0.7):5432");
  assert.equal(asked, 1);
  assert.equal(await labelFor("postgres://reader:hunter2@10.1.2.3/x", resolve), "10.1.2.3:5432");
  assert.equal(asked, 1);
  assert.equal(await labelFor("postgres://reader:hunter2@gone.example/x", resolve), "gone.example:5432");
  for (const u of [url, "postgres://reader:hunter2@gone.example/x", "garbage hunter2 reader"]) {
    const label = await labelFor(u, resolve);
    assert.ok(!label.includes("hunter2") && !label.includes("reader"), label);
  }
  resetEndpointLabels();
});
