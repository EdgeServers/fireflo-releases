import { strict as assert } from "node:assert";
import { test } from "node:test";

import {
  customPeriod,
  monthOf,
  monthPeriod,
  periodTooLong,
  recentMonths,
  type BillingPeriod,
} from "./billing-period.ts";

function period(value: string, zone = "UTC"): BillingPeriod {
  const p = monthPeriod(value, zone);
  assert.ok(p, `${value} should be a month`);
  return p;
}

/** Whole days, which is what the calendar questions below are actually about. */
function days(p: BillingPeriod): number {
  return Math.round((p.until.getTime() - p.since.getTime()) / 86_400_000);
}

test("a month runs from its 1st to the next 1st, so February needs no special case", () => {
  assert.equal(days(period("2026-01")), 31);
  assert.equal(days(period("2026-02")), 28);
  assert.equal(days(period("2026-04")), 30);
});

test("a leap February is 29 days, with no leap-year arithmetic anywhere", () => {
  //2028 is a leap year; 2100 is not, despite being divisible by four. Both fall out of "the 1st of
  //the next month" for free, which is the whole reason the period is built that way
  assert.equal(days(period("2028-02")), 29);
  assert.equal(days(period("2100-02")), 28);
});

test("December rolls into January of the next year", () => {
  const december = period("2026-12");
  assert.equal(december.until.toISOString(), "2027-01-01T00:00:00.000Z");
  assert.equal(days(december), 31);
});

test("a month begins at midnight in the billing zone, not UTC's and not the host's", () => {
  //the failure this is really about: new Date("2026-08-01") is UTC midnight, which in Asia/Kolkata
  //is 05:30 on the 1st -- so five and a half hours of billable traffic would fall off the front of
  //every invoice, every month, with nothing anywhere saying so. And the host's own zone is not the
  //billing zone either: these run on the server
  const august = period("2026-08", "Asia/Kolkata");
  assert.equal(august.since.toISOString(), "2026-07-31T18:30:00.000Z");
  assert.equal(august.until.toISOString(), "2026-08-31T18:30:00.000Z");
  assert.equal(period("2026-08", "UTC").since.toISOString(), "2026-08-01T00:00:00.000Z");
  assert.equal(period("2026-08", "America/New_York").since.toISOString(), "2026-08-01T04:00:00.000Z");
});

test("a month across a daylight change is a month, not thirty days of 24 hours", () => {
  //New York's November: EDT at the start, EST at the end, so 30 days and one hour
  const november = period("2026-11", "America/New_York");
  assert.equal(november.since.toISOString(), "2026-11-01T04:00:00.000Z");
  assert.equal(november.until.toISOString(), "2026-12-01T05:00:00.000Z");
});

test("adjacent months meet exactly, with nothing in the gap and nothing counted twice", () => {
  //the boundary property the whole statement rests on. Half-open means the instant one period ends
  //is the instant the next begins, so a message sent at that instant belongs to exactly one of them
  const january = period("2026-01");
  const february = period("2026-02");
  assert.equal(january.until.getTime(), february.since.getTime());
});

test("a month that does not exist is not a month", () => {
  for (const bad of ["2026-13", "2026-00", "2026-1", "2026", "august", ""]) {
    assert.equal(monthPeriod(bad, "UTC"), null, bad);
  }
});

test("a custom period includes the last day the customer typed", () => {
  //typed inclusive, sent half-open. A customer asking for the 1st to the 3rd means three whole days
  const result = customPeriod("2026-08-01", "2026-08-03", "UTC");
  assert.ok(typeof result !== "string", result as string);
  assert.equal(days(result), 3);
  assert.equal(result.until.toISOString(), "2026-08-04T00:00:00.000Z");
  assert.equal(result.label, "2026-08-01..2026-08-03");
});

test("a custom period is cut in the billing zone", () => {
  const india = customPeriod("2026-08-01", "2026-08-03", "Asia/Kolkata");
  assert.ok(typeof india !== "string", india as string);
  assert.equal(india.since.toISOString(), "2026-07-31T18:30:00.000Z");
  assert.equal(india.until.toISOString(), "2026-08-03T18:30:00.000Z");
  assert.equal(india.label, "2026-08-01..2026-08-03", "named by the days typed, whatever the zone");
});

test("a custom period is refused in the same words every other range is", () => {
  assert.match(customPeriod("2026-08-03", "2026-08-01", "UTC") as string, /on or before/);
  assert.match(customPeriod("", "2026-08-01", "UTC") as string, /both a From and a To/);
  assert.match(customPeriod("2026-02-31", "2026-03-01", "UTC") as string, /not a valid date/);
  assert.match(customPeriod("2026-01-01", "2026-12-31", "UTC") as string, /at most 92/);
});

test("a calendar month is never too long, and a long custom window is", () => {
  assert.equal(periodTooLong(period("2026-01")), null);
  assert.equal(periodTooLong(period("2026-02")), null);
  const long = { since: new Date(2026, 0, 1), until: new Date(2026, 11, 1), label: "long" };
  assert.match(periodTooLong(long) ?? "", /at most 92/);
});

test("monthOf is the local month, and names a month monthPeriod accepts", () => {
  //the pair has to agree: a picker offers monthOf, and the route parses it back with monthPeriod
  const at = new Date(2026, 7, 19, 23, 45);
  assert.equal(monthOf(at), "2026-08");
  assert.equal(period(monthOf(at)).label, "2026-08");
});

test("recentMonths walks backwards across a year boundary", () => {
  assert.deepEqual(recentMonths(new Date(2026, 1, 15), 4), ["2026-02", "2026-01", "2025-12", "2025-11"]);
});

test("recentMonths does not skip a month when today is the 31st", () => {
  //the classic: setMonth on the 31st of March lands in May, because April has no 31st. The cursor
  //starts on the 1st for exactly this reason, and this is the test that keeps it there
  assert.deepEqual(recentMonths(new Date(2026, 2, 31), 3), ["2026-03", "2026-02", "2026-01"]);
});
