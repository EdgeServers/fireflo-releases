/**
 * Units accounts (gateway 0.16.0), with no database import anywhere.
 *
 * <p>Split from `units.ts` for the reason every `-types` module here is: a client component that
 * reaches a module which transitively imports `pg` does not break that page, it breaks every page.
 *
 * <p>A units account is a child account (`app_account.parent_account_id`) whose
 * `account_balance.billing_mode` is `UNITS`. It holds message units per product and no money; its
 * logins take one unit of their product per message part, and the money for each message is charged
 * to the parent. The platform that manages it (OMNI) creates it and gives it units through the
 * gateway's platform API; this panel only reads.
 */

//the extension is required for node --test to resolve this without a bundler
import { MONEY_SCALE } from "./format.ts";

/**
 * Whole units from a stored amount. Every unit column is scaled by 10 000 like money (5 units is
 * 50000) and the gateway keeps them whole (a CHECK on every table), so this division is exact; a
 * stored value that is somehow not whole is truncated toward zero rather than shown as a fraction of
 * a message.
 */
export function unitsOf(scaled: number | string): number {
  const n = typeof scaled === "string" ? Number(scaled) : scaled;
  return Number.isFinite(n) ? Math.trunc(n / MONEY_SCALE) : 0;
}

/** One product's allowance, in whole units. */
export interface UnitAllowance {
  product: string;
  /** Not held by any gateway node. */
  free: number;
  /** Held in gateway nodes' blocks and not yet settled as used. */
  reserved: number;
  /** Settled as used, net of refunds. */
  used: number;
  /** What can still be sent: free + reserved, the gateway's own rule. */
  left: number;
  /** False: no node takes units from it; what nodes already hold is still spent. */
  enabled: boolean;
}

/** An allowance row as stored (scaled), to whole units with `left` worked out. */
export function allowanceFrom(row: { product: string; free: string | number; reserved: string | number; used: string | number; enabled: boolean }): UnitAllowance {
  const free = unitsOf(row.free);
  const reserved = unitsOf(row.reserved);
  return { product: row.product, free, reserved, used: unitsOf(row.used), left: free + reserved, enabled: row.enabled };
}

/** The products with nothing left to send, which is the "no units" state. */
export function productsWithoutUnits(allowances: readonly UnitAllowance[]): string[] {
  return allowances.filter((a) => a.left <= 0).map((a) => a.product);
}

export type UnitEntryType = "GIVE" | "TAKE" | "MOVE_OUT" | "MOVE_IN" | "ADJUSTMENT";

export interface UnitLedgerEntry {
  id: number;
  product: string;
  /** Signed whole units, as it moved this account's units: given and moved in are positive. */
  units: number;
  entryType: string;
  /** The platform's idempotency key for the operation. */
  reference: string;
  /** For a move, the other units account. */
  counterparty: string | null;
  note: string | null;
  /** The gateway node that wrote it. */
  writtenBy: string | null;
  createdAt: string;
}

/** A page of the unit ledger, newest first. `next` is the cursor for the page after, or null. */
export interface UnitLedgerPage {
  entries: UnitLedgerEntry[];
  next: string | null;
}

/** What a ledger entry was, in words. An unknown type keeps its token. */
export function unitEntryLabel(entryType: string, counterparty: string | null): string {
  switch (entryType) {
    case "GIVE":
      return "Given";
    case "TAKE":
      return "Taken back";
    case "MOVE_OUT":
      return counterparty ? `Moved to ${counterparty}` : "Moved out";
    case "MOVE_IN":
      return counterparty ? `Moved from ${counterparty}` : "Moved in";
    case "ADJUSTMENT":
      return "Correction";
    default:
      return entryType;
  }
}

/** Units used per product over a period, from `unit_usage_hourly`. */
export interface UnitUsageRow {
  product: string;
  used: number;
  /** Given back for messages that were not delivered. */
  refunded: number;
  messages: number;
}

/** One billing day of one product. */
export interface UnitUsageDay extends UnitUsageRow {
  /** `YYYY-MM-DD` in the billing time zone. */
  day: string;
}

export interface UnitUsage {
  /** This month so far, in the billing time zone. */
  month: UnitUsageRow[];
  /** The last {@link UNIT_USAGE_DAYS} days, newest first. */
  days: UnitUsageDay[];
}

/** How many days of usage the units page shows: inside the summary's retention. */
export const UNIT_USAGE_DAYS = 30;

/**
 * A units account's own speed limits, as stored, and the parent's beside them.
 *
 * <p>Each value is the raw stored text (null when unset). Unset, zero or not a number all mean "no
 * limit of its own" to the gateway, which {@link ownLimit} says in words.
 */
export interface UnitsRate {
  /** `outSms.default.conf.maxRate.<account>`: gateway-wide SMPP, what the platform's setAccountRate writes. */
  smpp: string | null;
  /** `conf.maxRate.<account>` set on a listener, which beats the gateway-wide row there. */
  smppListeners: { listener: string; value: string }[];
  /** `smsg.restapi.maxRate.<account>`: HTTP (REST, platform send, gRPC). */
  http: string | null;
  /** The parent's gateway-wide SMPP ceiling, `outSms.default.conf.maxRate.<parent>`. */
  parentSmpp: string | null;
  /** The parent's HTTP ceiling, `smsg.restapi.maxRate.<parent>`. */
  parentHttp: string | null;
}

/** A stored ceiling as the gateway reads it: a positive number, else no limit of its own. */
export function ownLimit(raw: string | null | undefined): number | null {
  const n = Number((raw ?? "").trim());
  return (raw ?? "").trim() && Number.isFinite(n) && n > 0 ? n : null;
}

export interface UnitsLogin {
  systemId: string;
  product: string | null;
  enabled: boolean;
}

/**
 * Why units accounts cannot be used right now, when that can be told from the database.
 *
 * <p>The gateway creates units accounts and gives units only while every live node runs 0.16.0 or
 * newer and prepaid enforcement is on. A node older than that loads a units account's logins as
 * money logins of an account with no money, so their messages are refused there.
 */
export interface UnitsAvailability {
  /** Live nodes (heartbeat inside the node timeout) older than 0.16.0, as `node (version)`. */
  olderNodes: string[];
  /**
   * True when `smsg.balance.enabled` is stored as false in the gateway settings. An environment
   * variable on the gateway (FIREFLO_BALANCE_ENABLE) can override what is stored, so false here
   * means "not known to be off", not "known to be on".
   */
  enforcementOff: boolean;
}

/** The first gateway release that counts units. */
const FIRST = [0, 16, 0] as const;

/**
 * Whether a node reporting this version counts units: 0.16.0 or later. `v0.16.0`, `0.16.1-SNAPSHOT`
 * and `0.16.0+1` all parse; a version that does not start `major.minor.patch` is not new enough,
 * which is the gateway's own rule (`UnitAccountsGate.newEnough`), less its "same build" exception
 * that only a gateway can know.
 */
export function countsUnits(version: string | null | undefined): boolean {
  const m = /^v?(\d+)\.(\d+)\.(\d+)/.exec((version ?? "").trim());
  if (!m) {
    return false;
  }
  for (let i = 0; i < 3; i++) {
    const part = Number(m[i + 1]);
    if (part !== FIRST[i]) {
      return part > FIRST[i];
    }
  }
  return true;
}

/** What one units account is, for its own pages. */
export interface UnitsAccountView {
  account: string;
  /** The account that pays for its messages. */
  parent: { id: string; label: string | null } | null;
  allowances: UnitAllowance[];
  /** null when the usage could not be read. */
  usage: UnitUsage | null;
  logins: UnitsLogin[];
  /** null when the configuration database is not reachable from this panel. */
  rate: UnitsRate | null;
  availability: UnitsAvailability | null;
}

/** One account in a reseller's list: the reseller itself, or one of its children. */
export interface SubAccountRow {
  id: string;
  label: string | null;
  /** A units account; otherwise it has a money balance (or none). */
  units: boolean;
  enabled: boolean;
  archived: boolean;
  logins: string[];
  /** Units per product; empty for a money account. */
  allowances: UnitAllowance[];
  /**
   * Messages this month, billing time zone: for a units account from its unit usage, for a money
   * account from the hourly summary of the messages it paid for -- which, for the reseller itself,
   * includes its units accounts' messages. null when it could not be read.
   */
  messagesMonth: number | null;
}

export interface SubAccountsView {
  self: SubAccountRow;
  children: SubAccountRow[];
  availability: UnitsAvailability | null;
}
