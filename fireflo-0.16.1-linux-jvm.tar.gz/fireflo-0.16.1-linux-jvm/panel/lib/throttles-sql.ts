import type { RejectedFilters } from "./rejected-request";

/**
 * The SQL behind the Refused page's "SMPP throttles (0x58)" strip, kept apart from the query runner
 * so the window and the filters are tested without a database.
 *
 * <p>`smpp_throttle_minute` (gateway 0.15.1, V1.118.0) holds one row per node per minute per
 * (listener, account, login, limiter) that saw any throttle -- minute aggregates, never a row per
 * refused PDU, which is why a throttle is not among the per-message refusals above it. The strip
 * sums the window per account × listener × login.
 *
 * <p><strong>Bounded.</strong> The window starts no earlier than the table's retention (35 days by
 * default), so the planner always has a lower bound on the primary key's leading `minute`; the
 * groups are capped; and only the filters this table has a column for apply. A filter it cannot
 * honour -- a product, an address, a message id -- skips the strip rather than showing every
 * account's throttles under a filter that says otherwise.
 */

/** `smsg.throttle.retention.days`' default: nothing older is there to read. */
export const THROTTLE_RETENTION_DAYS = 35;
/** The most account × listener × login groups one read returns; the strip says when there are more. */
export const MAX_THROTTLE_GROUPS = 100;

export type ThrottleQuery =
  | { sql: string; params: unknown[]; since: Date; until: Date | null; clamped: boolean }
  | { skipped: string };

/** The filters of the Refused page this table cannot answer, by the name the filter bar uses. */
const NOT_HERE: [keyof RejectedFilters, string][] = [
  ["product", "product"],
  ["sourceAddr", "sender"],
  ["destAddr", "destination"],
  ["gatewayMsgId", "message id"],
  ["vendorStatus", "vendor status"],
  ["hasMsgId", "has a message id"],
  ["afterAccepting", "refused after accepting"],
];

/**
 * The aggregate for these filters, or why there is none.
 *
 * @param now the right edge when the filters give no `until`, and what the retention floor is
 *     measured from
 */
export function throttleQuery(filters: RejectedFilters, now: Date = new Date()): ThrottleQuery {
  //a reason is one of cdr_rejected's tokens, and a throttle is none of them
  if (filters.reason) {
    return { skipped: "reason" };
  }
  //HTTP has its own ceiling, recorded per message as rateLimited; this table is SMPP's
  if (filters.ingress && !/^smpp/i.test(filters.ingress.trim())) {
    return { skipped: "ingress" };
  }
  for (const [field, label] of NOT_HERE) {
    const v = filters[field];
    if (v != null && v !== "" && v !== false) {
      return { skipped: label };
    }
  }

  const params: unknown[] = [];
  const bind = (value: unknown): string => {
    params.push(value);
    return `$${params.length}`;
  };
  const floor = new Date(now.getTime() - THROTTLE_RETENTION_DAYS * 86_400_000);
  const asked = filters.since ?? new Date(now.getTime() - 86_400_000);
  const since = asked < floor ? floor : asked;
  const where = [`minute >= ${bind(since)}`];
  if (filters.until) {
    where.push(`minute < ${bind(filters.until)}`);
  }
  if (filters.accountId) {
    where.push(`account_id = ${bind(filters.accountId)}`);
  }
  if (filters.systemId) {
    where.push(`system_id = ${bind(filters.systemId)}`);
  }
  if (filters.inGateway) {
    //the table keeps the full name, smppserver.<name>; the filter bar may hold either
    const n = bind(filters.inGateway.trim());
    where.push(`(listener = ${n} OR listener = 'smppserver.' || ${n})`);
  }
  const search = filters.search?.trim();
  if (search) {
    const n = bind(`%${search.replace(/[\\%_]/g, (c) => `\\${c}`)}%`);
    where.push(`(account_id ILIKE ${n} ESCAPE '\\' OR system_id ILIKE ${n} ESCAPE '\\' OR listener ILIKE ${n} ESCAPE '\\')`);
  }
  const limit = bind(MAX_THROTTLE_GROUPS + 1);

  return {
    sql: `SELECT account_id, listener, system_id,
            sum(throttled)::text AS throttled,
            COALESCE(sum(throttled) FILTER (WHERE limiter = 'account'), 0)::text AS by_account,
            COALESCE(sum(throttled) FILTER (WHERE limiter = 'login'), 0)::text AS by_login,
            count(DISTINCT minute)::int AS minutes,
            max(minute) AS last_minute,
            max(rate)::float8 AS rate,
            (sum(sum(throttled)) OVER ())::text AS total,
            (count(*) OVER ())::int AS groups
       FROM smpp_throttle_minute
      WHERE ${where.join(" AND ")}
      GROUP BY account_id, listener, system_id
      ORDER BY sum(throttled) DESC, account_id, listener, system_id
      LIMIT ${limit}`,
    params,
    since,
    until: filters.until ?? null,
    clamped: since.getTime() !== asked.getTime(),
  };
}
