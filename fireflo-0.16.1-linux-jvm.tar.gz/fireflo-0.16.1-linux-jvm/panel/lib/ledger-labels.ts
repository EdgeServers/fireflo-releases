/**
 * What a ledger entry is called on the account pages, and which way its money moved.
 *
 * <p>`balance_ledger.delta` is positive on every money row and the type carries the direction:
 * `RECHARGE` adds, `DEBIT` (gateway 0.15.3) takes away, a `TRANSFER` takes from `account_id` and
 * gives to the counterparty. The pages show a signed amount, so a debit is read here as negative
 * once, at the edge, rather than at every place that prints it.
 */

/** The signed amount an entry moved this account's balance by, scaled. */
export function signedDelta(entryType: string, delta: number): number {
  return entryType === "DEBIT" ? -Math.abs(delta) : delta;
}

/**
 * The Type cell: `Debit · <reason>` for a debit, whose reason is the point of it, and the entry
 * type in words otherwise.
 */
export function ledgerTypeLabel(entryType: string, note: string | null | undefined): string {
  switch (entryType) {
    case "DEBIT": {
      const reason = (note ?? "").trim();
      return reason ? `Debit · ${reason}` : "Debit";
    }
    case "RECHARGE":
      return "Top up";
    case "TRANSFER":
      return "Transfer";
    case "BILL":
      return "Billed";
    case "ADJUSTMENT":
      return "Adjustment";
    default:
      return entryType;
  }
}

/** Whether the note is already in the Type cell, so the Reference cell does not repeat it. */
export function noteInTypeLabel(entryType: string): boolean {
  return entryType === "DEBIT";
}
