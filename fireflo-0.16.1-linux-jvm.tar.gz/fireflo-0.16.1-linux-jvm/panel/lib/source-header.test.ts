import { test } from "node:test";
import assert from "node:assert/strict";
import { encodeSource, parseSource, type SourceSummary } from "./source-header.ts";

test("encode and decode round trip, both sides", () => {
  const s: SourceSummary = {
    db: { host: "db.internal (10.128.0.2):5432", ms: 128.44, calls: 3, max: 96.06, pools: ["metrics"], cached: false },
    gateway: { host: "127.0.0.1:9000", ms: 45, calls: 1, max: 45, cached: false },
  };
  const header = encodeSource(s);
  assert.equal(header,
    "db=db.internal (10.128.0.2):5432;db_ms=128.4;db_calls=3;db_max=96.1;pool=metrics;gw=127.0.0.1:9000;gw_ms=45.0;gw_calls=1;gw_max=45.0");
  assert.deepEqual(parseSource(header), {
    db: { ...s.db!, ms: 128.4, max: 96.1 },
    gateway: s.gateway,
  });
});

test("cached flags per side, gateway only, nothing at all", () => {
  const db = encodeSource({ db: { host: "h:5432", ms: 10, calls: 1, max: 10, pools: ["metrics", "config"], cached: true }, gateway: null });
  assert.equal(db, "db=h:5432;db_ms=10.0;db_calls=1;db_max=10.0;pool=metrics,config;cached=1");
  assert.equal(parseSource(db)?.db?.cached, true);
  assert.deepEqual(parseSource(db)?.db?.pools, ["metrics", "config"]);
  const gw = encodeSource({ db: null, gateway: { host: "g:9000", ms: 2, calls: 2, max: 1.5, cached: true } });
  assert.equal(gw, "gw=g:9000;gw_ms=2.0;gw_calls=2;gw_max=1.5;gw_cached=1");
  assert.equal(parseSource(gw)?.db, null);
  assert.equal(parseSource(gw)?.gateway?.cached, true);
  assert.equal(encodeSource({ db: null, gateway: null }), null);
});

test("delimiters cannot be smuggled through a host; junk parses to null", () => {
  const h = encodeSource({ db: { host: "a;b=c\r\nX-Evil: 1", ms: 1, calls: 1, max: 1, pools: ["metrics"], cached: false }, gateway: null });
  assert.ok(!/[\r\n]/.test(h!));
  assert.equal(parseSource(h)?.db?.host, "abcX-Evil: 1");
  assert.equal(parseSource(null), null);
  assert.equal(parseSource(""), null);
  assert.equal(parseSource("nonsense;x=1"), null);
  assert.deepEqual(parseSource("db=h;db_ms=-4;db_calls=x"), { db: { host: "h", ms: 0, calls: 1, max: 0, pools: [], cached: false }, gateway: null });
});
