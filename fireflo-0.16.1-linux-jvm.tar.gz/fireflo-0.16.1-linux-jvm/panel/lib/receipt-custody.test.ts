import { test } from "node:test";
import assert from "node:assert/strict";
import {
  ageLabel, appendDepth, custodyExplainer, custodyPill, custodyState, dbCustodyNote, dbCustodyState,
  DEPTH_RING, hasReceiptCustody, isWriteAhead, rateLabel, receiptsWaiting, vendorWaiting,
} from "./receipt-custody.ts";
import { count } from "./format.ts";
import type { Health } from "./health-types";

const health = (extra: Partial<Health>): Health => ({ ...(extra as Health) });

test("the three states and their pills, as the mockup has them", () => {
  assert.deepEqual(custodyPill("OK"), { tone: "success", label: "OK" });
  assert.deepEqual(custodyPill("SLOW"), { tone: "warning", label: "Slow" });
  assert.deepEqual(custodyPill("BACKING_UP"), { tone: "destructive", label: "Backing up" });
  assert.equal(custodyState("backing-up"), "BACKING_UP");
  assert.equal(custodyState("slow"), "SLOW");
  assert.equal(custodyState(undefined, 0), "OK");
  assert.equal(custodyState("SOMETHING", 12), "SLOW", "an unknown state with receipts waiting is not called OK");
});

test("an older gateway has no receipts_in: no card, no vendor figure", () => {
  assert.equal(receiptsWaiting(health({})), null);
  assert.equal(receiptsWaiting(null), null);
  assert.equal(vendorWaiting(health({}), "smppclient.smppsim"), null);
  assert.equal(hasReceiptCustody(health({})), false);
  assert.equal(hasReceiptCustody(health({ api: { receipt_custody: true } })), true);
});

test("receipts_in is read with its numbers, and each vendor found by full or bare name", () => {
  const h = health({
    receipts_in: {
      depth: 4180, oldest_age_seconds: 21, in_per_second: 200, matched_per_second: 31, state: "SLOW",
      vendors: [{ worker: "smppclient.smppsim", depth: 2131, oldest_age_seconds: 21 }, { worker: "smppsim21", depth: 2049 }],
    },
  });
  const r = receiptsWaiting(h)!;
  assert.equal(r.depth, 4180);
  assert.equal(r.state, "SLOW");
  assert.equal(r.vendors.length, 2);
  assert.equal(r.vendors[1].oldestAgeSeconds, null);
  assert.equal(vendorWaiting(h, "smppclient.smppsim"), 2131);
  assert.equal(vendorWaiting(h, "smppclient.smppsim21"), 2049, "the bare name when health lists it so");
  assert.equal(vendorWaiting(h, "smppclient.other"), 0, "a vendor the list leaves out has none waiting");
});

test("ages and rates the way the card writes them", () => {
  assert.equal(ageLabel(0.2), "0.2 s");
  assert.equal(ageLabel(21), "21 s");
  assert.equal(ageLabel(242), "4 min 2 s");
  assert.equal(ageLabel(240), "4 min");
  assert.equal(ageLabel(3900), "1 h 5 min");
  assert.equal(ageLabel(null), "—");
  assert.equal(rateLabel(198, 198), "198 / 198");
  assert.equal(rateLabel(199.6, 0), "200 / 0");
  assert.equal(rateLabel(null, 3), "— / 3");
  assert.equal(rateLabel(2000, 31), `${count(2000)} / 31`);
});

test("the depth ring keeps the newest readings only", () => {
  let ring: number[] = [];
  for (let i = 0; i < DEPTH_RING + 5; i++) {
    ring = appendDepth(ring, i);
  }
  assert.equal(ring.length, DEPTH_RING);
  assert.equal(ring[0], 5);
  assert.equal(ring.at(-1), DEPTH_RING + 4);
});

test("the Database card's note follows the admission state", () => {
  assert.equal(dbCustodyState(health({})), null, "before 0.15.1 there is no admission and no note");
  assert.equal(dbCustodyState(health({ db_admission: "OK" })), "ok");
  assert.equal(dbCustodyState(health({ db_admission: "DEGRADED" })), "slow");
  assert.equal(dbCustodyState(health({ db_admission: "REFUSING" })), "down");
  assert.equal(dbCustodyNote("ok"), "Answering in time. Call records and receipts are written as they arrive.");
  assert.equal(dbCustodyNote("slow"),
    "Slow to answer. Receipts are kept in Kafka and matched as it answers; vendors are not asked to resend.");
  assert.equal(dbCustodyNote("down"),
    "Not answering. Receipts and call records are kept (Kafka and the local log) and written when it is back. "
      + "Nothing is lost while it is away.");
  assert.match(dbCustodyNote("slow", false), /kept in the local log/, "memory mode holds them in the log");
});

test("the explainer names where receipts are held, and the log row needs write-ahead", () => {
  assert.equal(custodyExplainer(true),
    "Receipts the vendors sent, held in Kafka (fireflo.receipts.in) until the receipt store records them. The vendor "
      + "was told OK when they were taken; none is ever asked to resend because the database is slow.");
  assert.match(custodyExplainer(false), /held in the gateway's local log/);
  assert.equal(isWriteAhead(health({ persist_log_mode: "write-ahead" })), true);
  assert.equal(isWriteAhead(health({ persist_log_mode: "spill-only" })), false);
  assert.equal(isWriteAhead(health({})), false);
});
