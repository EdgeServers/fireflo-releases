import { test } from "node:test";
import assert from "node:assert/strict";
import { allowanceFrom, countsUnits, ownLimit, productsWithoutUnits, unitEntryLabel, unitsOf } from "./units-types.ts";

test("stored units are scaled by 10 000 and read back whole", () => {
  assert.equal(unitsOf("50000"), 5);
  assert.equal(unitsOf(-30000), -3);
  assert.equal(unitsOf("0"), 0);
  assert.equal(unitsOf("not a number"), 0);
});

test("left is free + reserved, the gateway's rule; used is not subtracted again", () => {
  const a = allowanceFrom({ product: "otp", free: "4990000", reserved: "10000", used: "5000000", enabled: true });
  assert.deepEqual(a, { product: "otp", free: 499, reserved: 1, used: 500, left: 500, enabled: true });
  assert.deepEqual(productsWithoutUnits([a, { ...a, product: "tx", free: 0, reserved: 0, left: 0 }]), ["tx"]);
});

test("a node counts units from 0.16.0, whatever follows the three numbers", () => {
  for (const v of ["0.16.0", "v0.16.0", "0.16.1-SNAPSHOT", "0.16.0+1", "0.17.0", "1.0.0"]) {
    assert.equal(countsUnits(v), true, v);
  }
  for (const v of ["0.15.13", "0.9.99", "unknown", "", null]) {
    assert.equal(countsUnits(v), false, String(v));
  }
});

test("a stored ceiling is a limit only when it is a positive number", () => {
  assert.equal(ownLimit("50"), 50);
  for (const raw of [null, "", "0", "-1", "fast"]) {
    assert.equal(ownLimit(raw), null, String(raw));
  }
});

test("ledger entries read in words, a move naming the other account", () => {
  assert.equal(unitEntryLabel("GIVE", null), "Given");
  assert.equal(unitEntryLabel("TAKE", null), "Taken back");
  assert.equal(unitEntryLabel("MOVE_OUT", "b"), "Moved to b");
  assert.equal(unitEntryLabel("MOVE_IN", "a"), "Moved from a");
  assert.equal(unitEntryLabel("SOMETHING_NEW", null), "SOMETHING_NEW");
});
