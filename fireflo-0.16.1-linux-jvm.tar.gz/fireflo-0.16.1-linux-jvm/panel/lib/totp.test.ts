import { strict as assert } from "node:assert";
import { test } from "node:test";

import {
  base32Decode,
  base32Encode,
  generateTotpSecret,
  hotp,
  otpauthUri,
  spacedSecret,
  totpAt,
  totpStep,
  verifyTotp,
} from "./totp.ts";

test("base32 is RFC 4648's, unpadded, and reads back what it wrote", () => {
  //RFC 4648 section 10, padding dropped
  const vectors: [string, string][] = [["", ""], ["f", "MY"], ["fo", "MZXQ"], ["foo", "MZXW6"], ["foob", "MZXW6YQ"],
    ["fooba", "MZXW6YTB"], ["foobar", "MZXW6YTBOI"]];
  for (const [plain, encoded] of vectors) {
    assert.equal(base32Encode(Buffer.from(plain)), encoded);
    if (encoded) {
      assert.equal(base32Decode(encoded)!.toString(), plain);
    }
  }
  assert.equal(base32Decode("mzxw 6ytb-oi==")!.toString(), "foobar", "case, spaces, dashes and padding as typed");
  assert.equal(base32Decode("MZXW1"), null, "1 is not base32");
  assert.equal(base32Decode(""), null);
});

test("RFC 6238 appendix B, SHA-1: the reference codes at the reference instants", () => {
  const key = Buffer.from("12345678901234567890");
  const vectors: [number, string][] = [
    [59, "94287082"], [1111111109, "07081804"], [1111111111, "14050471"],
    [1234567890, "89005924"], [2000000000, "69279037"], [20000000000, "65353130"],
  ];
  for (const [seconds, code] of vectors) {
    assert.equal(hotp(key, totpStep(seconds * 1000), 8), code, `T=${seconds}`);
    //six digits are the same number mod 10^6
    assert.equal(totpAt(base32Encode(key), seconds * 1000), code.slice(2), `T=${seconds}, six digits`);
  }
});

test("a code is good one step either side of now, and no further", () => {
  const secret = base32Encode(Buffer.from("12345678901234567890"));
  const now = 1_111_111_111_000;
  const step = totpStep(now);
  for (const drift of [-1, 0, 1]) {
    const code = totpAt(secret, now + drift * 30_000)!;
    assert.equal(verifyTotp(secret, code, { now }), step + drift, `drift ${drift}`);
  }
  for (const drift of [-2, 2]) {
    assert.equal(verifyTotp(secret, totpAt(secret, now + drift * 30_000)!, { now }), null, `drift ${drift}`);
  }
  assert.equal(verifyTotp(secret, "000000", { now }), null);
  assert.equal(verifyTotp(secret, "12345", { now }), null, "five digits");
  assert.equal(verifyTotp(secret, "abcdef", { now }), null);
  assert.equal(verifyTotp(secret, ` ${totpAt(secret, now)!.replace(/(\d{3})/, "$1 ")} `, { now }), step, "spaces as typed");
  assert.equal(verifyTotp("not base32!", "123456", { now }), null);
});

test("replay: a step at or before the last one used is refused", () => {
  const secret = base32Encode(Buffer.from("12345678901234567890"));
  const now = 1_234_567_890_000;
  const code = totpAt(secret, now)!;
  const step = totpStep(now);
  assert.equal(verifyTotp(secret, code, { now, lastStep: step - 1 }), step);
  assert.equal(verifyTotp(secret, code, { now, lastStep: step }), null, "the same code twice");
  assert.equal(verifyTotp(secret, code, { now, lastStep: step + 1 }), null, "an older code after a newer one");
  //the previous step's code, still inside the window, once the current step has been used
  assert.equal(verifyTotp(secret, totpAt(secret, now - 30_000)!, { now, lastStep: step }), null);
});

test("a new secret is 20 random bytes in base32, and the URI is what an authenticator scans", () => {
  const a = generateTotpSecret();
  const b = generateTotpSecret();
  assert.match(a, /^[A-Z2-7]{32}$/);
  assert.notEqual(a, b);
  assert.equal(base32Decode(a)!.length, 20);
  const uri = otpauthUri(a, "ops@example.com");
  assert.ok(uri.startsWith("otpauth://totp/FireFlo:ops%40example.com?"));
  const params = new URL(uri).searchParams;
  assert.equal(params.get("secret"), a);
  assert.equal(params.get("issuer"), "FireFlo");
  assert.equal(params.get("algorithm"), "SHA1");
  assert.equal(params.get("digits"), "6");
  assert.equal(params.get("period"), "30");
  assert.equal(spacedSecret("ABCDEFGHIJ"), "ABCD EFGH IJ");
});
