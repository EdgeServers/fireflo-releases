import { clusterPeers, createCapability, fanOut, postToNode, probeNode, CALL_MS, type FanoutResult } from "./gateway-fanout.ts";
import { failureBody, missingAfter, type GatewayFailureBody } from "./gateway-slow.ts";
import { gqlData } from "./gateway-graphql-core.ts";

/**
 * The gateway's live counters (gateway 0.15.1, capability `live_counters`): lifetime totals kept in
 * each node's memory since its process started, for the three counter columns under the
 * Connectivity map.
 *
 * <ul>
 *   <li><b>MT</b> -- `ack`, submits accepted at the door; `nack`, submits refused at the door for
 *       any reason; `total` their sum.</li>
 *   <li><b>DLR</b> -- `in`, receipts received from vendors; `out`, receipts pushed to clients
 *       (deliver_sm sent and HTTP callbacks delivered); `total` their sum.</li>
 *   <li><b>DB</b> -- `written`, rows the persistence bus wrote; `queue`, rows waiting (the bus's
 *       depth plus the local log not yet replayed). A gauge, not a counter.</li>
 *   <li><b>Rates</b> -- each over the gateway's last five seconds.</li>
 * </ul>
 *
 * <p>Each node counts only what it handled, so the cluster's figure is every node's answer summed
 * (`gateway-fanout.ts`); `since` is the earliest node's start, the moment the oldest count began.
 *
 * <p><strong>This file is the adapter</strong>: the document, the wire types, their normalisation
 * (a GraphQL Long arrives as a string or a number), the cluster sum and the route's logic
 * ({@link readLiveCounters}, with the gateway calls passed in), so `gateway-live-counters.test.ts`
 * tests it without Next or a gateway. The document stays here, not in `gateway-queries.ts`
 * `DOCUMENTS`, until the gateway's published schema (`lib/__fixtures__/schema.graphql`) has the
 * field -- the schema check would refuse it before then.
 */

export const LIVE_COUNTERS_CAPABILITY = "live_counters";

/** The `liveCounters` document lives beside the other gateway documents. */
import { LIVE_COUNTERS } from "./gateway-queries.ts";
export { LIVE_COUNTERS };

/** One answer is shared this long, so several open pages polling every 2 s cost one fan-out. */
const ANSWER_TTL_MS = 1_000;

/** A Long or a Double as the gateway may send it. */
type Wire = string | number | null | undefined;

/** `liveCounters` as it comes off the wire, every field optional: nothing is trusted. */
export interface LiveCountersWire {
  node?: string | null;
  since?: string | null;
  mt?: { total?: Wire; ack?: Wire; nack?: Wire } | null;
  dlr?: { total?: Wire; in?: Wire; out?: Wire } | null;
  db?: { written?: Wire; queue?: Wire } | null;
  rates?: {
    mtAckPerSecond?: Wire;
    mtNackPerSecond?: Wire;
    dlrInPerSecond?: Wire;
    dlrOutPerSecond?: Wire;
    dbWrittenPerSecond?: Wire;
  } | null;
}

export interface LiveRates {
  mtAckPerSecond: number;
  mtNackPerSecond: number;
  dlrInPerSecond: number;
  dlrOutPerSecond: number;
  dbWrittenPerSecond: number;
}

/** One node's counters, normalised. */
export interface LiveCounters {
  node: string | null;
  /** The node's process start, ISO; null when it did not say or said something unreadable. */
  since: string | null;
  mt: { total: number; ack: number; nack: number };
  dlr: { total: number; in: number; out: number };
  db: { written: number; queue: number };
  rates: LiveRates;
}

/** The cluster's counters: every node that answered, summed. What the route returns. */
export interface LiveCountersSum extends Omit<LiveCounters, "node"> {
  /** The nodes summed, the answering node first. */
  nodes: string[];
  /** The peers asked that did not answer: their share is missing from the sum. */
  partial: string[];
  /** The peers in `partial` that timed out rather than refused (0.15.1); absent when none did. */
  slow?: string[];
}

function num(v: unknown): number {
  const n = typeof v === "number" ? v : typeof v === "string" && v.trim() !== "" ? Number(v) : NaN;
  return Number.isFinite(n) && n >= 0 ? n : 0;
}

function instant(v: unknown): string | null {
  if (typeof v !== "string" || v === "") {
    return null;
  }
  const at = Date.parse(v);
  return Number.isNaN(at) ? null : new Date(at).toISOString();
}

/**
 * One node's answer, normalised: Longs from strings or numbers, anything missing or unreadable as 0.
 * A total the gateway left out is its parts' sum.
 */
export function normaliseLiveCounters(wire: LiveCountersWire | null | undefined): LiveCounters {
  const w = wire ?? {};
  const ack = num(w.mt?.ack);
  const nack = num(w.mt?.nack);
  const dlrIn = num(w.dlr?.in);
  const dlrOut = num(w.dlr?.out);
  return {
    node: typeof w.node === "string" && w.node !== "" ? w.node : null,
    since: instant(w.since),
    mt: { total: w.mt?.total == null ? ack + nack : num(w.mt.total), ack, nack },
    dlr: { total: w.dlr?.total == null ? dlrIn + dlrOut : num(w.dlr.total), in: dlrIn, out: dlrOut },
    db: { written: num(w.db?.written), queue: num(w.db?.queue) },
    rates: {
      mtAckPerSecond: num(w.rates?.mtAckPerSecond),
      mtNackPerSecond: num(w.rates?.mtNackPerSecond),
      dlrInPerSecond: num(w.rates?.dlrInPerSecond),
      dlrOutPerSecond: num(w.rates?.dlrOutPerSecond),
      dbWrittenPerSecond: num(w.rates?.dbWrittenPerSecond),
    },
  };
}

/** Every node's counters summed; `since` is the earliest node's. */
export function sumLiveCounters(
  answers: readonly LiveCounters[],
  partial: readonly string[] = [],
  slow: readonly string[] = []
): LiveCountersSum {
  const out: LiveCountersSum = {
    nodes: [],
    partial: [...partial],
    ...(slow.length ? { slow: [...slow] } : {}),
    since: null,
    mt: { total: 0, ack: 0, nack: 0 },
    dlr: { total: 0, in: 0, out: 0 },
    db: { written: 0, queue: 0 },
    rates: { mtAckPerSecond: 0, mtNackPerSecond: 0, dlrInPerSecond: 0, dlrOutPerSecond: 0, dbWrittenPerSecond: 0 },
  };
  for (const a of answers) {
    if (a.node) {
      out.nodes.push(a.node);
    }
    if (a.since && (out.since === null || Date.parse(a.since) < Date.parse(out.since))) {
      out.since = a.since;
    }
    out.mt.total += a.mt.total;
    out.mt.ack += a.mt.ack;
    out.mt.nack += a.mt.nack;
    out.dlr.total += a.dlr.total;
    out.dlr.in += a.dlr.in;
    out.dlr.out += a.dlr.out;
    out.db.written += a.db.written;
    out.db.queue += a.db.queue;
    for (const k of Object.keys(out.rates) as (keyof LiveRates)[]) {
      out.rates[k] += a.rates[k];
    }
  }
  return out;
}

/** A fan-out's answers, normalised and summed. */
export function toLiveCountersSum(result: FanoutResult<LiveCountersWire>): LiveCountersSum {
  return sumLiveCounters(result.answers.map(normaliseLiveCounters), result.partial, result.slow);
}

// ---- the gateway calls ----

/**
 * `live_counters` on the main node, learnt from the reads themselves: the main node is never
 * probed before a read (0.15.1, `createCapability`).
 */
const capability = createCapability(LIVE_COUNTERS_CAPABILITY);
let answer: { at: number; settled: boolean; value: Promise<LiveCountersSum> } | null = null;

/**
 * False only once the gateway has said it has no `live_counters`; until then the read itself is
 * made and tells. Never asks the gateway.
 */
export async function liveCountersAvailable(): Promise<boolean> {
  return capability.known() !== false;
}

/**
 * `liveCounters` on the answering node and every alive peer, summed. Throws when the answering node
 * cannot answer. One read at a time: while one is in flight -- a slow gateway may take up to
 * {@link CALL_MS} -- every caller shares it, and a settled answer is shared {@link ANSWER_TTL_MS}.
 */
export function fetchLiveCounters(): Promise<LiveCountersSum> {
  if (answer && (!answer.settled || Date.now() - answer.at < ANSWER_TTL_MS)) {
    return answer.value;
  }
  const value = fanOut<LiveCountersWire>({
    local: () => capability.call(() => gqlData<LiveCountersWire>({ query: LIVE_COUNTERS, timeoutMs: CALL_MS })),
    peers: clusterPeers,
    probe: (node) => probeNode(node, LIVE_COUNTERS_CAPABILITY),
    call: (node) => postToNode<LiveCountersWire>(node, LIVE_COUNTERS, undefined, CALL_MS),
  }).then(toLiveCountersSum);
  const kept = { at: Date.now(), settled: false, value };
  answer = kept;
  value.then(
    () => {
      kept.settled = true;
      kept.at = Date.now();
    },
    () => {
      if (answer === kept) {
        answer = null;
      }
    }
  );
  return value;
}

/** For a test, or after a reload: ask again next time. */
export function forgetLiveCounters(): void {
  capability.forget();
  answer = null;
}

// ---- the route ----

/** What the route needs from the gateway, passed in so the logic is tested without one. */
export interface LiveCountersDeps {
  /** Whether the answering node may have `live_counters`: false only once it said it has not. */
  available: () => Promise<boolean>;
  /** The cluster's counters, summed; throws when the answering node cannot answer. */
  read: () => Promise<LiveCountersSum>;
}

export type LiveCountersAnswer =
  | { status: 204 }
  | { status: 200; body: { data: LiveCountersSum } }
  | { status: 502; body: GatewayFailureBody };

/**
 * `GET /api/control/connectivity/counters`: 204 when the gateway has no `live_counters` (the page
 * then shows no counters at all), 502 when it cannot be asked -- with `code: "SLOW"` when it is
 * there but slow -- else the cluster's sum. `available` never asks the gateway: it is what the
 * reads have taught, so the read is the first thing the main node is asked.
 */
export async function readLiveCounters(deps: LiveCountersDeps): Promise<LiveCountersAnswer> {
  try {
    if (!(await deps.available())) {
      return { status: 204 };
    }
    return { status: 200, body: { data: await deps.read() } };
  } catch (err) {
    if (await missingAfter(err, deps.available)) {
      return { status: 204 };
    }
    return { status: 502, body: failureBody(err) };
  }
}
