import { poolLabel } from "./db-endpoint.ts";
import { currentTrace, enterTrace, traceTotals, type DbPool, type DbTrace } from "./db-trace.ts";
import { encodeSource, SOURCE_HEADER, type SourceSummary } from "./source-header.ts";

/** Answers that never carry the header: see {@link withSourceTrace}. */
const REFUSALS = new Set([401, 403, 404]);

/**
 * Wraps a route handler so its answer says where the data came from: the `X-FireFlo-Source`
 * header (`lib/source-header.ts`) built from the request's trace (`lib/db-trace.ts`), which the
 * operator footer adds up for the page (`components/PageTiming.tsx`).
 *
 * <p>Imports nothing from Next, so it is tested under plain `node --test`; any handler answering a
 * `Response` (a `NextResponse` is one) can be wrapped, with its arguments passed through untouched.
 *
 * <p>A response whose headers cannot be changed (a `Response.redirect`) goes out as it is, and so
 * does one from a request that made no call or that marked its trace hidden (a customer's stats).
 * <strong>A refusal (401, 403, 404) never carries it</strong>: the operator check may itself have
 * read the database, and a caller who is not signed in must not learn where that database is.
 */
export function withSourceTrace<A extends unknown[], R extends Response>(
  handler: (...args: A) => Promise<R>,
  labels: (pool: DbPool) => Promise<string | null> = poolLabel
): (...args: A) => Promise<R> {
  return (...args: A) =>
    enterTrace(async () => {
      const res = await handler(...args);
      const trace = currentTrace();
      if (trace && !trace.hidden && !REFUSALS.has(res.status)) {
        const value = encodeSource(await summarise(trace, labels));
        if (value) {
          try {
            res.headers.set(SOURCE_HEADER, value);
          } catch {
            //immutable headers: the answer matters more than the footer stat
          }
        }
      }
      return res;
    });
}

/** The trace as the header carries it: totals per side, the hosts named. */
export async function summarise(
  trace: DbTrace,
  labels: (pool: DbPool) => Promise<string | null> = poolLabel
): Promise<SourceSummary> {
  const totals = traceTotals(trace);
  let db: SourceSummary["db"] = null;
  if (totals.db) {
    const hosts = (await Promise.all(totals.db.pools.map((p) => labels(p).catch(() => null))))
      .map((h) => h ?? "unknown");
    db = {
      host: [...new Set(hosts)].join(","),
      ms: totals.db.ms,
      calls: totals.db.calls,
      max: totals.db.max,
      pools: totals.db.pools,
      cached: totals.db.cached,
    };
  }
  const gateway: SourceSummary["gateway"] = totals.gateway
    ? {
        host: totals.gateway.hosts.join(","),
        ms: totals.gateway.ms,
        calls: totals.gateway.calls,
        max: totals.gateway.max,
        cached: totals.gateway.cached,
      }
    : null;
  return { db, gateway };
}
