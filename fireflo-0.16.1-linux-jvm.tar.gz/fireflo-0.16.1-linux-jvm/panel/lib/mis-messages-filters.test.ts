import { test } from "node:test";
import assert from "node:assert/strict";
import {
  CUSTOM_RANGE,
  EMPTY_MIS_FILTERS,
  type MisFilterForm,
  fromMisQuery,
  hasActiveMisFilters,
  toMisQuery,
  validateMisFilters,
} from "./mis-messages-filters.ts";

/**
 * The portal's filters on the wire.
 *
 * <p>The first test is the one that matters most, and it is about a parameter name. The page this
 * replaces sent `to`; the parser has always read `dest`; so the To-number box returned every message
 * and read as a filter that had matched broadly rather than as a control that did nothing.
 */

const form = (over: Partial<MisFilterForm> = {}): MisFilterForm => ({ ...EMPTY_MIS_FILTERS, ...over });

test("the destination filter is sent as dest, which is what the parser reads", () => {
  const params = toMisQuery(form({ dest: "+9198200" }), "UTC");

  assert.equal(params.get("dest"), "+9198200");
  assert.equal(params.get("to"), null, "`to` is read by nothing and silently filters nothing");
});

test("a preset period is sent as range, and nothing else", () => {
  const params = toMisQuery(form({ range: "7d" }), "UTC");

  assert.equal(params.get("range"), "7d");
  assert.equal(params.get("since"), null);
  assert.equal(params.get("until"), null);
});

test("a custom period is sent as since and until, and omits range", () => {
  const params = toMisQuery(form({ range: CUSTOM_RANGE, since: "2026-08-01", until: "2026-08-15" }), "UTC");

  assert.equal(params.get("range"), null, "an explicit window is not also a named one");
  assert.equal(params.get("since"), "2026-08-01T00:00:00.000Z", "midnight in the zone");
  assert.equal(params.get("until"), "2026-08-16T00:00:00.000Z", "exclusive, so the 15th is fully included");
});

test("a custom period's days are the display zone's days, and round-trip in it", () => {
  const india = toMisQuery(form({ range: CUSTOM_RANGE, since: "2026-08-01", until: "2026-08-15" }), "Asia/Kolkata");
  assert.equal(india.get("since"), "2026-07-31T18:30:00.000Z");
  assert.equal(india.get("until"), "2026-08-15T18:30:00.000Z");
  const back = fromMisQuery(india, "Asia/Kolkata");
  assert.deepEqual([back.since, back.until], ["2026-08-01", "2026-08-15"]);
});

test("empty fields are left out entirely, so the URL says what was chosen", () => {
  const params = toMisQuery(form({ range: "24h", dest: "   ", account: "acme" }), "UTC");

  assert.deepEqual([...params.keys()].sort(), ["account", "range"]);
});

test("a custom range round-trips through the query string unchanged", () => {
  //the regression this guards: `until` is the day AFTER the one that was typed, so reading it back
  //naively pushes the window one day further out on every reload of a bookmarked link
  const original = form({ range: CUSTOM_RANGE, since: "2026-08-01", until: "2026-08-15" });

  const once = fromMisQuery(toMisQuery(original, "UTC"), "UTC");
  assert.equal(once.range, CUSTOM_RANGE);
  assert.equal(once.since, "2026-08-01");
  assert.equal(once.until, "2026-08-15");

  //and again, because a drift of one day per reload is only visible on the second pass
  const twice = fromMisQuery(toMisQuery(once, "UTC"), "UTC");
  assert.deepEqual(twice, once);
});

test("a preset and its text filters round-trip too", () => {
  const original = form({ range: "30d", dest: "+91", msgId: "abc-123", outcome: "DELIVERED" });

  assert.deepEqual(fromMisQuery(toMisQuery(original, "UTC"), "UTC"), original);
});

test("a period nobody offers is dropped rather than carried into a 400", () => {
  //`all` is a real key in RANGES and the customer route refuses it, so honouring it from a URL would
  //land somebody on an error page
  assert.equal(fromMisQuery(new URLSearchParams("range=all"), "UTC").range, "1h");
  assert.equal(fromMisQuery(new URLSearchParams("range=nonsense"), "UTC").range, "1h");
});

test("an outcome the gateway never writes is dropped", () => {
  assert.equal(fromMisQuery(new URLSearchParams("outcome=MAYBE"), "UTC").outcome, "");
  assert.equal(fromMisQuery(new URLSearchParams("outcome=PENDING"), "UTC").outcome, "PENDING");
});

test("a half-specified window falls back to the default period", () => {
  //`until` alone would leave parseFilters deriving `since` from the default period, which is a
  //window nobody asked for. Both or neither
  const only = fromMisQuery(new URLSearchParams("until=2026-08-16T00:00:00.000Z"), "UTC");
  assert.equal(only.range, "1h");
  assert.equal(only.until, "");
});

test("validation refuses what the route would refuse, before the request is made", () => {
  assert.equal(validateMisFilters(form({ range: "24h" })), null);
  assert.equal(validateMisFilters(form({ range: CUSTOM_RANGE, since: "2026-08-01", until: "2026-08-15" })), null);

  assert.match(validateMisFilters(form({ range: CUSTOM_RANGE, since: "2026-08-20", until: "2026-08-01" }))!, /on or before/i);
  assert.match(validateMisFilters(form({ range: CUSTOM_RANGE, since: "2026-01-01", until: "2026-12-31" }))!, /at most/i);
  assert.match(validateMisFilters(form({ range: "everything" }))!, /Unknown period/);
  assert.match(validateMisFilters(form({ outcome: "MAYBE" }))!, /Unknown outcome/);
});

test("Clear appears for a filter, not for a period", () => {
  assert.equal(hasActiveMisFilters(form({ range: "7d" })), false, "changing the period is not a filter");
  assert.equal(hasActiveMisFilters(form({ dest: "+91" })), true);
  assert.equal(hasActiveMisFilters(form({ dest: "  " })), false, "whitespace is not a filter");
});
