/**
 * When an account may be archived, and when a login, sender ID or template may move to another
 * account -- the decisions alone, with no database import, so they can be tested and so the routes
 * and the server functions say the same sentence.
 *
 * <p>Archived (gateway V1.100.0) means retired, not paused: `enabled = false` plus `archived_at`,
 * its logins switched off, hidden from the everyday lists and read-only until an admin unarchives
 * it. Its balance and history stay where they are.
 */

import { parseTlvCsv, tlvTag } from "./tlv-string.ts";

/** What is known about an account when deciding whether it may be archived. */
export interface ArchiveFacts {
  exists: boolean;
  archived: boolean;
  /** Accounts beneath it (a reseller's customers) that are not archived themselves. */
  activeChildren: number;
}

/**
 * Why the account cannot be archived, or null.
 *
 * <p>Credit the gateway is holding for the account (`account_balance.reserved`) is NOT a reason:
 * that is a block pre-authorised for speed and held until the gateway restarts, not money for
 * messages in flight. Archiving returns it to the balance instead (the gateway's `creditRelease` mutation).
 */
export function archiveRefusal(id: string, facts: ArchiveFacts): string | null {
  if (!facts.exists) {
    return `There is no account '${id}'.`;
  }
  if (facts.archived) {
    return `'${id}' is already archived.`;
  }
  if (facts.activeChildren > 0) {
    return `'${id}' still has ${facts.activeChildren} active customer account${facts.activeChildren === 1 ? "" : "s"} `
      + "of its own. Archive them, or move them to another reseller, first.";
  }
  return null;
}

/** Why the account cannot be unarchived, or null. */
export function unarchiveRefusal(id: string, facts: Pick<ArchiveFacts, "exists" | "archived">): string | null {
  if (!facts.exists) {
    return `There is no account '${id}'.`;
  }
  return facts.archived ? null : `'${id}' is not archived.`;
}

/** The sentence every write to an archived account is refused with. */
export function archivedReadOnly(id: string): string {
  return `'${id}' is archived, so it is read-only. Unarchive it first.`;
}

/** Either side of a move, as far as the decision needs to know. */
export interface MoveSide {
  id: string;
  exists: boolean;
  archived: boolean;
}

/** Why something cannot move from one account to the other at all, or null. */
export function moveRefusal(what: string, from: MoveSide, to: MoveSide): string | null {
  if (!to.id.trim()) {
    return "Choose the account to move it to.";
  }
  if (from.id === to.id) {
    return `This ${what} already belongs to '${to.id}'.`;
  }
  if (!to.exists) {
    return `There is no account '${to.id}'.`;
  }
  if (to.archived) {
    return `'${to.id}' is archived; nothing can be moved to it.`;
  }
  if (from.archived) {
    return archivedReadOnly(from.id);
  }
  return null;
}

/** A sender ID or template that names one login, shown when that login cannot move alone. */
export interface ScopedRow {
  kind: "sender ID" | "template";
  id: number;
  name: string;
}

/**
 * Why a login cannot move while rows on its old account are scoped to it, or null.
 *
 * <p>A login moves alone: a sender ID or template narrowed to its system ID stays on the old
 * account, where it would name a login that is no longer there. So the move waits until each one
 * is moved too (after the login) or has its login cleared.
 */
export function scopedRowsRefusal(systemId: string, rows: readonly ScopedRow[]): string | null {
  if (!rows.length) {
    return null;
  }
  const shown = rows.slice(0, 5).map((r) => `${r.kind} ${r.name}`).join(", ");
  const more = rows.length > 5 ? ` and ${rows.length - 5} more` : "";
  return `${rows.length} sender ID${rows.length === 1 ? "" : "s"}/template${rows.length === 1 ? "" : "s"} on this `
    + `account ${rows.length === 1 ? "is" : "are"} scoped to the login '${systemId}': ${shown}${more}. `
    + "Clear the login on them (so they cover the whole account), or delete them, before moving it. "
    + "Once cleared, they can be moved to the new account too, on their own.";
}

/**
 * Why a sender ID or template scoped to a login cannot move to `to`, or null.
 *
 * <p>The row may only name a login the target account owns -- the same rule `loginOutsideAccount`
 * applies when one is written. Move the login first, or clear the row's login.
 */
export function scopedLoginRefusal(systemId: string | null, loginOnTarget: boolean, to: string): string | null {
  if (!systemId?.trim() || loginOnTarget) {
    return null;
  }
  return `It is scoped to the login '${systemId.trim()}', which does not belong to '${to}'. `
    + "Clear the login on this row first, so it covers the whole account, then move it.";
}

// ---- Copying sender IDs and templates to other accounts -----------------------------------------

/**
 * Copying sender IDs (headers) and templates to several accounts at once.
 *
 * <p>Unlike a move, nothing on the source account changes, and nothing already on a target is
 * touched: a row the target already has is skipped, never overwritten. Panel-only -- the gateway
 * adopts the new rows on its next configuration poll, like any other approval.
 */
export type CopyKind = "header" | "template";

/** "keep": approved stays approved (stamped with the copying operator); "pending": every copy waits. */
export type CopyStatusChoice = "keep" | "pending";

/** At most this many rows per call. */
export const COPY_MAX_ROWS = 500;
/** At most this many target accounts per call. */
export const COPY_MAX_TARGETS = 50;

/** A body `{ ids, to, status, widenScope }`, checked. */
export interface CopyRequest {
  ids: number[];
  to: string[];
  status: CopyStatusChoice;
  widenScope: boolean;
}

/** The body of `POST /api/control/whitelist/{headers|templates}/copy`, or the sentence it is refused with. */
export function parseCopyRequest(body: unknown, what: "sender IDs" | "templates"): CopyRequest | { error: string } {
  const b = (body ?? {}) as { ids?: unknown; to?: unknown; status?: unknown; widenScope?: unknown };
  if (!Array.isArray(b.ids) || !b.ids.length) {
    return { error: `Choose the ${what} to copy: expected "ids", a list of row ids.` };
  }
  if (!b.ids.every((id) => Number.isInteger(id) && (id as number) > 0)) {
    return { error: "\"ids\" must be whole numbers, the ids of the rows to copy." };
  }
  const ids = [...new Set(b.ids as number[])];
  if (ids.length > COPY_MAX_ROWS) {
    return { error: `At most ${COPY_MAX_ROWS} ${what} can be copied at once; ${ids.length} were chosen.` };
  }
  if (!Array.isArray(b.to) || !b.to.every((t) => typeof t === "string")) {
    return { error: "Choose the accounts to copy to: expected \"to\", a list of account ids." };
  }
  const to = [...new Set((b.to as string[]).map((t) => t.trim()).filter(Boolean))];
  if (!to.length) {
    return { error: "Choose at least one account to copy to." };
  }
  if (to.length > COPY_MAX_TARGETS) {
    return { error: `At most ${COPY_MAX_TARGETS} accounts can be copied to at once; ${to.length} were chosen.` };
  }
  if (b.status !== undefined && b.status !== "keep" && b.status !== "pending") {
    return { error: "\"status\" is \"keep\" (approved stays approved) or \"pending\" (every copy waits for approval)." };
  }
  if (b.widenScope !== undefined && typeof b.widenScope !== "boolean") {
    return { error: "\"widenScope\" is true or false." };
  }
  return { ids, to, status: (b.status as CopyStatusChoice | undefined) ?? "keep", widenScope: b.widenScope === true };
}

/**
 * Why the copy cannot go ahead at all, or null: a target that is not an account, or is archived.
 * Checked for every target before anything is written, so a typo does not leave half a copy.
 *
 * @param known each target that has an account row, mapped to whether it is archived
 */
export function copyTargetRefusal(targets: readonly string[], known: ReadonlyMap<string, boolean>): string | null {
  const missing = targets.filter((t) => !known.has(t));
  if (missing.length) {
    return missing.length === 1
      ? `There is no account '${missing[0]}'.`
      : `There are no accounts ${missing.map((m) => `'${m}'`).join(", ")}.`;
  }
  const archived = targets.filter((t) => known.get(t) === true);
  if (archived.length) {
    return `${archived.map((a) => `'${a}'`).join(", ")} ${archived.length === 1 ? "is" : "are"} archived; `
      + "nothing can be copied to an archived account. Remove it from the list, or unarchive it first.";
  }
  return null;
}

/** A row being copied, as read from the source account. */
export interface CopySource {
  id: number;
  accountId: string;
  product: string;
  systemId: string | null;
  /** The header, or the template's name (or the start of its body): what the result list shows. */
  display: string;
  /** `lower(header)` or `lower(body)`, folded by PostgreSQL so it compares as the index does. */
  folded: string;
  status: string;
  enabled: boolean;
}

/** Why a row was not copied to one target. */
export type CopySkipReason = "already" | "login-only" | "rejected" | "withdrawn" | "own-account";

export interface CopySkip {
  id: number;
  text: string;
  reason: CopySkipReason;
}

/** What one target account got. */
export interface CopyTargetResult {
  to: string;
  copied: number;
  skipped: CopySkip[];
}

/**
 * The duplicate key in a target: `(product, COALESCE(system_id,''), folded text)`. For a header
 * that is the natural key of V1.45.0 within one account; a template has no unique key, and this is
 * the test the gateway's duplicate check makes (`lower(body)` + product + scope).
 */
export function copyKey(product: string, systemId: string | null, folded: string): string {
  return `${product ?? ""}\u0000${systemId?.trim() ?? ""}\u0000${folded}`;
}

/**
 * Which rows go to `target` and which are skipped, and why. Pure, so every reason is tested.
 *
 * <p>Order matters only for which reason is named: the target's own rows first, then the source
 * row's state, then its scope, then whether the target already has it. A row planned earlier in the
 * same call counts as "already there" for a later one, so two selected rows that collide in the
 * target produce one copy, not two (and no unique-key error).
 *
 * @param existing the keys ({@link copyKey}) of every row the target has now
 */
export function planCopy(
  rows: readonly CopySource[],
  target: string,
  existing: ReadonlySet<string>,
  widenScope: boolean
): { copy: { row: CopySource; systemId: string | null }[]; skipped: CopySkip[] } {
  const seen = new Set(existing);
  const copy: { row: CopySource; systemId: string | null }[] = [];
  const skipped: CopySkip[] = [];
  for (const row of rows) {
    const skip = (reason: CopySkipReason) => skipped.push({ id: row.id, text: row.display, reason });
    const scope = row.systemId?.trim() || null;
    if (row.accountId === target) {
      skip("own-account");
    } else if (row.status === "REJECTED") {
      skip("rejected");
    } else if (row.status === "APPROVED" && !row.enabled) {
      //withdrawn: approved once, then taken out of service. Copying it would hand the target a
      //registration its own account no longer uses
      skip("withdrawn");
    } else if (scope && !widenScope) {
      //it names a login of the source account, which the target does not own
      skip("login-only");
    } else {
      const systemId = widenScope ? null : scope;
      const key = copyKey(row.product, systemId, row.folded);
      if (seen.has(key)) {
        skip("already");
      } else {
        seen.add(key);
        copy.push({ row, systemId });
      }
    }
  }
  return { copy, skipped };
}

/** The approval columns a copy is written with. */
export interface CopyStamp {
  status: "APPROVED" | "PENDING";
  reviewedBy: string | null;
  reviewNote: string | null;
  requestNote: string | null;
}

/**
 * How a copy is stamped.
 *
 * <p>"keep": an APPROVED row is approved in the target at once, recorded against the operator who
 * copied it ("copied from <account>"); a PENDING row stays pending. "pending": every copy waits on
 * the target's Approvals page, and the request note says where it came from. `requested_by` is left
 * empty either way: the panel reads a requester as "the customer asked", which a copy is not.
 */
export function copyStamp(sourceStatus: string, choice: CopyStatusChoice, from: string, operator: string): CopyStamp {
  if (choice === "keep" && sourceStatus === "APPROVED") {
    return { status: "APPROVED", reviewedBy: operator, reviewNote: `copied from ${from}`, requestNote: null };
  }
  return {
    status: "PENDING",
    reviewedBy: null,
    reviewNote: null,
    requestNote: choice === "pending" ? `copied from ${from} by ${operator}` : `copied from ${from}`,
  };
}

/** What the result list says for one skip reason, with its count. */
export function copySkipLabel(reason: CopySkipReason, n: number): string {
  switch (reason) {
    case "already":
      return `${n} already there`;
    case "login-only":
      return `${n} login-only, skipped`;
    case "rejected":
      return `${n} rejected, skipped`;
    case "withdrawn":
      return `${n} withdrawn, skipped`;
    case "own-account":
      return `${n} already its own`;
  }
}

const SKIP_ORDER: readonly CopySkipReason[] = ["already", "login-only", "rejected", "withdrawn", "own-account"];

/** One target's line: "3 copied · 1 already there · 1 login-only, skipped". */
export function copyResultLine(result: Pick<CopyTargetResult, "copied" | "skipped">): string {
  const parts = [`${result.copied} copied`];
  for (const reason of SKIP_ORDER) {
    const n = result.skipped.filter((s) => s.reason === reason).length;
    if (n) {
      parts.push(copySkipLabel(reason, n));
    }
  }
  return parts.join(" · ");
}

/** Two calls' results (sender IDs, then templates) merged per account, in the order first seen. */
export function mergeCopyResults(...lists: readonly (readonly CopyTargetResult[])[]): CopyTargetResult[] {
  const merged = new Map<string, CopyTargetResult>();
  for (const list of lists) {
    for (const r of list) {
      const got = merged.get(r.to);
      if (got) {
        got.copied += r.copied;
        got.skipped.push(...r.skipped);
      } else {
        merged.set(r.to, { to: r.to, copied: r.copied, skipped: [...r.skipped] });
      }
    }
  }
  return [...merged.values()];
}

/** The DLT template ID's tag: TLV 0x1401, registered under one principal entity (PE). */
export const DLT_TEMPLATE_TAG = 0x1401;

/** Whether a row's stored stamps (`name_tag=value,…`) carry a DLT template ID with a value. */
export function carriesDltTemplateId(tlvs: string | null | undefined): boolean {
  return parseTlvCsv(tlvs).some((p) => tlvTag(p.key) === DLT_TEMPLATE_TAG && p.value.trim() !== "");
}

/** A selected row, as the copy dialog knows it. */
export interface CopyPick {
  kind: CopyKind;
  id: number;
  accountId: string;
  systemId: string | null;
  tlvs: string | null;
  status: string;
}

/**
 * The warning shown when a selected row carries a DLT template ID, or null. The id is registered
 * under the source account's principal entity, and a target sending under its own PE may have it
 * refused at the operator.
 */
export function dltCopyWarning(picks: readonly CopyPick[]): string | null {
  const dlt = picks.filter((p) => p.status !== "REJECTED" && carriesDltTemplateId(p.tlvs));
  if (!dlt.length) {
    return null;
  }
  const templates = dlt.filter((p) => p.kind === "template").length;
  const noun = templates === dlt.length
    ? (dlt.length === 1 ? "template carries" : "templates carry")
    : templates === 0
      ? (dlt.length === 1 ? "header carries" : "headers carry")
      : "rows carry";
  const sources = [...new Set(dlt.map((p) => p.accountId))];
  const owners = sources.length === 1 ? `${sources[0]}'s` : `their own accounts' (${sources.join(", ")})`;
  return `${dlt.length} selected ${noun} a DLT template ID (TLV 0x1401) registered under ${owners} `
    + "principal entity. Check it is valid for each target account before relying on it.";
}

/** The help under "Copy login-only rows to the whole account", or null when no such row is selected. */
export function loginOnlyCopyNote(picks: readonly CopyPick[]): string | null {
  const scoped = picks.filter((p) => p.status !== "REJECTED" && p.systemId?.trim());
  if (!scoped.length) {
    return null;
  }
  const logins = [...new Set(scoped.map((p) => p.systemId!.trim()))];
  return `${scoped.length} selected ${scoped.length === 1 ? "row applies" : "rows apply"} to one login only `
    + `(${logins.join(", ")}). Target accounts don't have ${logins.length === 1 ? "that login" : "those logins"}, `
    + `so ${scoped.length === 1 ? "it is" : "they are"} skipped unless you tick this.`;
}

/** "Copy 3 headers and 2 templates to 4 accounts: a, b, c, d." */
export function copySummary(headers: number, templates: number, targets: readonly string[]): string {
  const parts: string[] = [];
  if (headers) {
    parts.push(`${headers} header${headers === 1 ? "" : "s"}`);
  }
  if (templates) {
    parts.push(`${templates} template${templates === 1 ? "" : "s"}`);
  }
  const what = parts.length ? parts.join(" and ") : "nothing";
  return `Copy ${what} to ${targets.length} account${targets.length === 1 ? "" : "s"}`
    + `${targets.length ? `: ${targets.join(", ")}` : ""}.`;
}
