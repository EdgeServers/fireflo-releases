import assert from "node:assert/strict";
import { test } from "node:test";

import { LiveSliceCache, liveBucketFloor } from "./live-traffic-cache.ts";

type Row = { t: number; n: number };

function clock(start = 1_000_000_000_000) {
  let t = start;
  return { now: () => t, advance: (ms: number) => { t += ms; } };
}

function deferred<T>() {
  let resolve!: (v: T) => void;
  let reject!: (e: unknown) => void;
  const promise = new Promise<T>((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
}

const rowsFrom = (from: number, until: number): Row[] => {
  const out: Row[] = [];
  for (let t = from; t < until; t += 10_000) out.push({ t, n: 1 });
  return out;
};

test("buckets are epoch-aligned ten-second floors", () => {
  assert.equal(liveBucketFloor(1_000_000_012_345, 10), 1_000_000_010_000);
  assert.equal(liveBucketFloor(1_000_000_010_000, 10), 1_000_000_010_000);
});

test("a fresh read answers every later slice it covers, cut to the caller's start", async () => {
  const c = clock();
  const cache = new LiveSliceCache<Row>({ ttlMs: 10_000, now: c.now });
  let reads = 0;
  const from = c.now() - 15 * 60_000;
  const read = async (start: number) => {
    reads++;
    return { rows: rowsFrom(start, c.now()), until: c.now() };
  };
  const full = await cache.get("vendor|a", from, read);
  assert.equal(full.since, from);
  assert.equal(reads, 1);
  //another tab's incremental poll, five seconds on: no read, only the buckets from its start
  c.advance(5_000);
  const slice = await cache.get("vendor|a", from + 14 * 60_000, read);
  assert.equal(reads, 1);
  assert.equal(slice.since, from + 14 * 60_000);
  assert.ok(slice.rows.length > 0 && slice.rows.every((r) => r.t >= slice.since));
  assert.equal(slice.until, full.until, "the read's own end, so the next slice starts there");
  //a different key is its own read
  await cache.get("vendor|b", from, read);
  assert.equal(reads, 2);
  //an earlier start than the kept read covers is read
  await cache.get("vendor|a", from - 10_000, read);
  assert.equal(reads, 3);
  //and once the read is older than the TTL, so is any slice
  c.advance(10_000);
  await cache.get("vendor|a", from + 14 * 60_000, read);
  assert.equal(reads, 4);
});

test("callers arriving while a read runs share it when it covers them", async () => {
  const c = clock();
  const cache = new LiveSliceCache<Row>({ ttlMs: 10_000, now: c.now });
  const d = deferred<{ rows: Row[]; until: number }>();
  let reads = 0;
  const read = () => {
    reads++;
    return d.promise;
  };
  const a = cache.get("server|x", 1_000, read);
  const b = cache.get("server|x", 21_000, read);
  const z = cache.get("server|x", 11_000, read);
  d.resolve({ rows: [{ t: 1_000, n: 1 }, { t: 11_000, n: 2 }, { t: 21_000, n: 3 }], until: 30_000 });
  const [ra, rb, rz] = await Promise.all([a, b, z]);
  assert.equal(reads, 1, "three concurrent polls, one read");
  assert.deepEqual(ra.rows.map((r) => r.n), [1, 2, 3]);
  assert.deepEqual(rb.rows.map((r) => r.n), [3]);
  assert.deepEqual(rz.rows.map((r) => r.n), [2, 3]);
});

test("a failed read reaches its callers and is not kept", async () => {
  const c = clock();
  const cache = new LiveSliceCache<Row>({ ttlMs: 10_000, now: c.now });
  await assert.rejects(cache.get("k", 0, async () => { throw new Error("db down"); }), /db down/);
  let reads = 0;
  await cache.get("k", 0, async () => { reads++; return { rows: [], until: 1 }; });
  assert.equal(reads, 1, "the next caller reads again");
});
