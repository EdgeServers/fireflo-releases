import { logOperatorEvent } from "@/lib/access-log";
import { configQuery, isConfigWritable } from "@/lib/config-db";

/**
 * Who reached a customer account, from where, and when.
 *
 * <h2>Why the database, when operator events go to a file</h2>
 *
 * <p>These rows are asked about per account — "when did this customer last sign in", "who has been
 * requesting links for that address" — which is a query, not a grep. Operator events go to a file
 * for the opposite reason: they are a record *of* the people who can edit this database.
 *
 * <p>Written through `CONFIG_DATABASE_URL`, which is optional by design. When it is unset the row
 * falls back to the operator file log rather than being dropped — a smaller record beats none, and
 * silence would make an install look untouched.
 *
 * <h2>It must never break a sign-in</h2>
 *
 * <p>Every call swallows its errors, including a missing connection and a missing table on a
 * database that has not run `V1.20.0`. An audit insert that can throw turns a working portal into a
 * 500 the first time somebody deploys the panel ahead of the migration.
 */

export type CustomerEvent =
  | "link_requested"
  | "link_denied"
  | "link_redeemed"
  | "link_rejected"
  | "portal_access"
  | "cross_account_access"
  /**
   * A live REST call made from the portal's playground.
   *
   * <p>Its own event rather than a `portal_access` with a detail, because it is a different act: a
   * page view versus a call that sends a message and spends credit. The detail names the endpoint
   * and the login and never the request body — that body is message content and a destination.
   *
   * <p>Needs `V1.21.0`; the column has a CHECK naming every value.
   */
  | "playground_call"
  /**
   * A customer replaced their own API password or key.
   *
   * <p>The one action a customer can take that breaks their own integration, so "who changed this
   * and when" is the first question after the support call it causes. The detail names which secret
   * and which login and never either value, old or new.
   *
   * <p>Needs `V1.23.0`.
   */
  | "credential_rotated"
  /**
   * A reseller acting on one of the accounts beneath it.
   *
   * <p>The first customer events that are writes to <em>another</em> account. Every value above
   * describes something a customer did to its own records; these describe a customer changing
   * somebody else's ability to send and be billed — which is the class of act an operator is asked
   * about afterwards, so each is queryable rather than a `cross_account_access` with a detail.
   *
   * <p>`cross_account_access` is still written alongside them by `assertInScope` and keeps its
   * meaning: one customer's identity reached another's records. These say what it then did.
   *
   * <p>The detail carries the child's id, and for a login its system id. Never a secret — the portal
   * generates both, returns each once, and does not read them back.
   *
   * <p>Needs `V1.41.0`; the column has a CHECK naming every value.
   */
  | "child_created"
  | "child_updated"
  | "child_suspended"
  | "child_resumed"
  | "child_login_created"
  | "child_login_toggled"
  /**
   * A reseller changed the credit terms on one of its accounts.
   *
   * <p>Opening the balance row, switching credit on or off, and moving between prepaid and postpaid
   * with a limit. **Not** a top-up: a reseller cannot create credit, only move its own, and that
   * lands as a `TRANSFER` in `balance_ledger` which is a record in its own right.
   *
   * <p>The detail carries which of the three it was and the value it landed on, including the
   * currency and where it was inherited from — the question asked afterwards is usually "who set
   * this account postpaid", and a log that cannot answer it is not doing its job.
   *
   * <p>Needs `V1.42.0`; the column has a CHECK naming every value.
   */
  | "child_credit_changed"
  /**
   * Password sign-in at the portal, and the password's life.
   *
   * <p>`password_signin` and `password_signin_failed` sit beside `link_redeemed` and `link_rejected`
   * so "who got into this account and how" is one query. `password_set` is the customer setting or
   * changing their own; `child_user_created` and `child_user_toggled` are a reseller giving or taking
   * away a person's access on an account beneath it -- the same class of act as `child_login_created`.
   *
   * <p>Needs `V1.52.0`; the column has a CHECK naming every value.
   */
  | "password_signin"
  | "password_signin_failed"
  | "password_set"
  | "child_user_created"
  | "child_user_toggled"
  /**
   * A reseller changed a login on one of its accounts (allowed IPs, session limits, enabled), and a
   * reseller moved credit to or from one (a recharge, a withdrawal, an opening credit).
   *
   * <p>Needs `V1.128.0` (gateway 0.15.8), which widens the CHECK. Written with a `fallback` event, so
   * on an older database the row still lands -- as `child_login_toggled` / `child_credit_changed`
   * with `detail.event` naming what it would have been -- rather than being lost to the CHECK.
   */
  | "child_login_updated"
  | "child_transfer";

export interface CustomerAccessEntry {
  event: CustomerEvent;
  accountId?: string | null;
  /** The `app_user` row, when the event is about a signed-in person. Needs `V1.52.0`. */
  userId?: number | null;
  /** What was typed. Recorded whether or not it matched an account — see the migration. */
  email?: string | null;
  ip?: string | null;
  userAgent?: string | null;
  detail?: Record<string, unknown>;
  /**
   * The event to write instead when the database's CHECK refuses {@link event} (23514): a database
   * that has not run the migration that admits it. The detail gains `event`, naming the original.
   */
  fallback?: CustomerEvent;
}

/** So a database that has not been migrated produces one complaint, not one per request. */
let complained = false;

export async function recordCustomerAccess(entry: CustomerAccessEntry): Promise<void> {
  if (!isConfigWritable()) {
    //no writing connection: keep the fact somewhere rather than nowhere
    void logOperatorEvent({
      event: "signin",
      actor: entry.accountId ?? entry.email ?? null,
      ip: entry.ip ?? null,
      userAgent: entry.userAgent ?? null,
      detail: { customer: entry.event, note: "CONFIG_DATABASE_URL unset", ...entry.detail },
    });
    return;
  }

  try {
    await configQuery(
      `INSERT INTO app_customer_access_log (event, account_id, user_id, email, ip, user_agent, detail)
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [
        entry.event,
        entry.accountId ?? null,
        entry.userId ?? null,
        entry.email ?? null,
        entry.ip ?? null,
        entry.userAgent ?? null,
        entry.detail ? JSON.stringify(entry.detail) : null,
      ]
    );
    complained = false;
  } catch (err) {
    if (entry.fallback && (err as { code?: string })?.code === "23514") {
      await recordCustomerAccess({
        ...entry,
        event: entry.fallback,
        fallback: undefined,
        detail: { ...entry.detail, event: entry.event },
      });
      return;
    }
    if (!complained) {
      complained = true;
      console.error(
        "customer access log: could not record, continuing without it. If this database has not "
          + "run V1.20.0__customer_access_log.sql, that is why.",
        err
      );
    }
  }
}
