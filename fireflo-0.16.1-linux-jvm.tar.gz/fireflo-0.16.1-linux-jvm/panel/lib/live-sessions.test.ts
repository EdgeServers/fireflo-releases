import { strict as assert } from "node:assert";
import { test } from "node:test";
import {
  accountRates, chartRows, EMPTY_LIVE_SESSIONS, foldSessions, LIVE_SESSION_COARSE_MS, LIVE_SESSION_FINE_MS,
  LIVE_SESSION_HISTORY_MS, peakTotal, splitRates, sumCounts, TOTAL_SERIES, windowSamples, type SessionReading,
} from "./live-sessions.ts";
import { groupByLogin, loginKey } from "./session-groups.ts";
import type { HealthSession } from "./health-types.ts";

const YK = loginKey("YK201", "yk201");
const YKB = loginKey("YK201", "yk201b");
const OTP = loginKey("233026", "otpmsg1");

function reading(key: string, submitted: number | null, over: Partial<SessionReading> = {}): SessionReading {
  return { key, submitted, tps: null, members: "1", ...over };
}

test("the first poll is a baseline: it takes the gateway's measured rate, or is a gap", () => {
  const h = foldSessions(EMPTY_LIVE_SESSIONS, [reading(YK, 1000, { tps: 42 }), reading(OTP, 50)], 0);
  assert.equal(h.samples.length, 1);
  assert.equal(h.samples[0].rates[YK], 42);
  assert.equal(h.samples[0].rates[OTP], null);
  assert.deepEqual(h.last[YK], { at: 0, submitted: 1000, members: "1" });
});

test("two readings five seconds apart are a per-second rate", () => {
  let h = foldSessions(EMPTY_LIVE_SESSIONS, [reading(YK, 1000)], 0);
  h = foldSessions(h, [reading(YK, 1500, { tps: 7 })], 5000);
  assert.equal(h.samples[1].rates[YK], 100);
});

test("a counter that drops is a rebind, not negative traffic: the measured rate stands in", () => {
  let h = foldSessions(EMPTY_LIVE_SESSIONS, [reading(YK, 90_000)], 0);
  h = foldSessions(h, [reading(YK, 120, { tps: 24 })], 5000);
  assert.equal(h.samples[1].rates[YK], 24);
  //and the next poll measures from the new, lower counter
  h = foldSessions(h, [reading(YK, 620)], 10_000);
  assert.equal(h.samples[2].rates[YK], 100);
});

test("a drop with nothing measured by the gateway is a gap, never zero", () => {
  let h = foldSessions(EMPTY_LIVE_SESSIONS, [reading(YK, 90_000)], 0);
  h = foldSessions(h, [reading(YK, 120)], 5000);
  assert.equal(h.samples[1].rates[YK], null);
});

test("a bind joining a login is not a spike: the sum changed membership, so no delta is taken", () => {
  let h = foldSessions(EMPTY_LIVE_SESSIONS, [reading(YK, 1000, { members: "1,2" })], 0);
  //session 3 bound with half a million on its counter already: 500,000 in five seconds is not real
  h = foldSessions(h, [reading(YK, 501_500, { members: "1,2,3", tps: 110 })], 5000);
  assert.equal(h.samples[1].rates[YK], 110);
  h = foldSessions(h, [reading(YK, 502_000, { members: "1,2,3" })], 10_000);
  assert.equal(h.samples[2].rates[YK], 100);
});

test("a login that went away starts again from a fresh baseline", () => {
  let h = foldSessions(EMPTY_LIVE_SESSIONS, [reading(YK, 1000), reading(OTP, 10)], 0);
  h = foldSessions(h, [reading(OTP, 20)], 5000);
  assert.equal(h.last[YK], undefined);
  h = foldSessions(h, [reading(YK, 5000, { tps: 3 }), reading(OTP, 30)], 10_000);
  assert.equal(h.samples[2].rates[YK], 3);
});

test("per-login rates sum to the account, and accounts sum to the listener total", () => {
  const rates = { [YK]: 100, [YKB]: 98, [OTP]: 12, [loginKey("ACME", "acme")]: null };
  assert.deepEqual(splitRates(rates, "login"), rates);
  assert.deepEqual(splitRates(rates, "account"), { YK201: 198, "233026": 12, ACME: null });
  assert.deepEqual(splitRates(rates, "total"), { [TOTAL_SERIES]: 210 });
  assert.deepEqual(accountRates({ t: 0, rates }), { YK201: 198, "233026": 12, ACME: null });
});

test("a total is null only when nothing at all was measured", () => {
  assert.deepEqual(splitRates({ [YK]: null, [OTP]: null }, "total"), { [TOTAL_SERIES]: null });
  assert.deepEqual(splitRates({ [YK]: null, [OTP]: 0 }, "total"), { [TOTAL_SERIES]: 0 });
});

test("the fold works on what groupByLogin hands it: two logins of one account, folded and summed", () => {
  const s = (over: Partial<HealthSession>): HealthSession => ({ bound: true, account: "YK201", ...over });
  const poll = (a: number, b: number, c: number) => groupByLogin([
    s({ session_id: 1, system_id: "yk201", submitted: a }),
    s({ session_id: 2, system_id: "yk201", submitted: b }),
    s({ session_id: 3, system_id: "yk201b", submitted: c }),
  ]).map((g) => ({ key: g.key, submitted: g.submitted, tps: g.tps, members: g.members }));
  let h = foldSessions(EMPTY_LIVE_SESSIONS, poll(100, 200, 50), 0);
  h = foldSessions(h, poll(350, 450, 300), 5000);
  assert.equal(h.samples[1].rates[YK], 100);
  assert.equal(h.samples[1].rates[YKB], 50);
  assert.deepEqual(accountRates(h.samples[1]), { YK201: 150 });
});

test("samples older than the hour are dropped, and older than fifteen minutes merged into ten-second means", () => {
  let h = EMPTY_LIVE_SESSIONS;
  //a reading every five seconds for 70 minutes, the counter rising 50 then 150 alternately: rates 10, 30
  let counter = 0;
  const end = 70 * 60_000;
  for (let t = 0, i = 0; t <= end; t += 5000, i++) {
    counter += i % 2 ? 150 : 50;
    h = foldSessions(h, [reading(YK, counter)], t);
  }
  const oldest = h.samples[0].t;
  assert.ok(oldest >= end - LIVE_SESSION_HISTORY_MS, `kept ${oldest}, older than the hour`);
  const fine = h.samples.filter((s) => s.t >= end - LIVE_SESSION_FINE_MS);
  const coarse = h.samples.filter((s) => s.t < end - LIVE_SESSION_FINE_MS);
  assert.equal(fine.length, LIVE_SESSION_FINE_MS / 5000 + 1);
  //two five-second readings per bucket, merged to their mean
  assert.ok(coarse.every((s) => s.rates[YK] === 20), "a coarse bucket is the mean of its readings");
  const buckets = new Set(coarse.map((s) => Math.floor(s.t / LIVE_SESSION_COARSE_MS)));
  assert.equal(buckets.size, coarse.length, "one sample per ten-second bucket");
});

test("a window draws only what is inside it, at its own resolution, for the keys it keeps", () => {
  let h = EMPTY_LIVE_SESSIONS;
  let a = 0;
  let b = 0;
  for (let t = 0; t <= 20 * 60_000; t += 5000) {
    a += 500;
    b += 50;
    h = foldSessions(h, [reading(YK, a), reading(OTP, b)], t);
  }
  const now = 20 * 60_000;
  const five = windowSamples(h, "5m", now);
  assert.ok(five.every((s) => s.t >= now - 5 * 60_000));
  assert.equal(five.length, 61);
  const hour = windowSamples(h, "1h", now);
  const steps = hour.slice(1).map((s, i) => s.t - hour[i].t);
  assert.ok(steps.every((d) => d === LIVE_SESSION_COARSE_MS), "the hour is ten-second points end to end");
  const onlyYk = windowSamples(h, "15m", now, (key) => key.startsWith("YK201"));
  assert.ok(onlyYk.every((s) => Object.keys(s.rates).every((k) => k === YK)));
});

test("chart rows put the busiest series first, and the peak is the listener total's", () => {
  const samples = [
    { t: 1, rates: { [YK]: 100, [YKB]: 90, [OTP]: 12 } },
    { t: 2, rates: { [YK]: 110, [YKB]: 80, [OTP]: 40 } },
  ];
  const { points, series } = chartRows(samples, "account");
  assert.deepEqual(series, ["YK201", "233026"]);
  assert.deepEqual(points[1], { t: 2, YK201: 190, "233026": 40 });
  assert.equal(peakTotal(samples), 230);
  assert.equal(peakTotal([{ t: 1, rates: { [YK]: null } }]), null);
});

test("receipts fold beside submits: each key's counters since bind, as of the newest poll", () => {
  let h = foldSessions(EMPTY_LIVE_SESSIONS, [reading(YK, 1000, { receipts: 940 }), reading(OTP, 50)], 0);
  assert.deepEqual(h.counts[YK], { submitted: 1000, receipts: 940 });
  //a reading without receipts (a gateway before 0.13.2) is "not counted", never zero
  assert.deepEqual(h.counts[OTP], { submitted: 50, receipts: null });
  h = foldSessions(h, [reading(YK, 1500, { receipts: 1480 }), reading(OTP, 60, { receipts: 0 })], 5000);
  assert.deepEqual(h.counts[YK], { submitted: 1500, receipts: 1480 });
  assert.deepEqual(h.counts[OTP], { submitted: 60, receipts: 0 });
});

test("a rebind restarts the counts from the new counter, and a count is never negative", () => {
  let h = foldSessions(EMPTY_LIVE_SESSIONS, [reading(YK, 90_000, { receipts: 89_000 })], 0);
  h = foldSessions(h, [reading(YK, 120, { receipts: 80, members: "2" })], 5000);
  assert.deepEqual(h.counts[YK], { submitted: 120, receipts: 80 }, "restarted, not carried across the bind");
  h = foldSessions(h, [reading(YK, -5, { receipts: -1 })], 10_000);
  assert.deepEqual(h.counts[YK], { submitted: 0, receipts: 0 });
});

test("a key that unbound has no count, and a sum is null only when nothing counts", () => {
  let h = foldSessions(EMPTY_LIVE_SESSIONS, [reading(YK, 1000, { receipts: 900 }), reading(YKB, 400, { receipts: 390 }), reading(OTP, 10)], 0);
  assert.deepEqual(sumCounts(h, (k) => k.startsWith("YK201")), { submitted: 1400, receipts: 1290 });
  h = foldSessions(h, [reading(OTP, 20)], 5000);
  assert.equal(h.counts[YK], undefined);
  assert.deepEqual(sumCounts(h, (k) => k.startsWith("YK201")), { submitted: null, receipts: null });
  assert.deepEqual(sumCounts(h, () => true), { submitted: 20, receipts: null });
});

test("the counts come from what groupByLogin sums: receipts across a login's binds", () => {
  const s = (over: Partial<HealthSession>): HealthSession => ({ bound: true, account: "YK201", ...over });
  const groups = groupByLogin([
    s({ session_id: 1, system_id: "yk201", submitted: 300, receipts: 290 }),
    s({ session_id: 2, system_id: "yk201", submitted: 200, receipts: 195 }),
  ]);
  const h = foldSessions(EMPTY_LIVE_SESSIONS, groups.map((g) => ({
    key: g.key, submitted: g.submitted, receipts: g.receipts, tps: g.tps, members: g.members,
  })), 0);
  assert.deepEqual(h.counts[YK], { submitted: 500, receipts: 485 });
});
