import { strict as assert } from "node:assert";
import { test } from "node:test";

import { cleanCode, pendingExpired, pendingTokenFrom } from "./totp-signin.ts";
import { TOTP_CODE_PREFIX } from "./totp-pending.ts";

test("the second-step token is read from the sign-in answer's code, and nothing else is", () => {
  assert.equal(TOTP_CODE_PREFIX, "totp.", "the server's prefix and the form's agree");
  assert.equal(pendingTokenFrom("totp.abc.def"), "abc.def");
  assert.equal(pendingTokenFrom("totp."), null);
  assert.equal(pendingTokenFrom("credentials"), null);
  assert.equal(pendingTokenFrom(undefined), null);
  assert.equal(pendingExpired("totp_expired"), true);
  assert.equal(pendingExpired("credentials"), false);
});

test("a code is digits only, six at most", () => {
  assert.equal(cleanCode("123 456"), "123456");
  assert.equal(cleanCode("12-34-5678"), "123456");
  assert.equal(cleanCode("abc"), "");
});
