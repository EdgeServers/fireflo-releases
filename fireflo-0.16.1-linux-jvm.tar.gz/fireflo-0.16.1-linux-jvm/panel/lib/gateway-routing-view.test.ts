import { strict as assert } from "node:assert";
import { test } from "node:test";
import { routedVendors } from "./connectivity-data.ts";
import { MOCK_ROUTING_VIEW, readRoutingView, ROUTING_VIEW_QUERY, toRoutingMap } from "./gateway-routing-view.ts";

test("the document asks the contract's fields, one root field", () => {
  for (const f of ["routing", "source", "loadedAt", "tables", "rules", "seq", "target", "kind", "copied", "enabled", "label", "groups", "members", "worker", "weight"]) {
    assert.match(ROUTING_VIEW_QUERY, new RegExp(`\\b${f}\\b`));
  }
});

test("the wire in the map's shapes: rules by seq, defaults for nulls, members by worker name", () => {
  const map = toRoutingMap(MOCK_ROUTING_VIEW);
  assert.equal(map.source, "db");
  assert.deepEqual(map.tables[0].rules.map((r) => [r.seq, r.target, r.copied, r.enabled]), [
    [10, "sim-lb", false, true], [20, "audit", true, true], [30, "old-vendor", false, false],
  ]);
  assert.equal(map.tables[0].enabled, true);
  assert.deepEqual(map.groups[0].members, [
    { workerName: "sim1", weight: 1, enabled: true }, { workerName: "sim2", weight: 1, enabled: true },
  ]);
  //what the map reads from it: the group's members, the copy target, never the switched-off rule
  const routed = routedVendors(map.tables, map.groups);
  assert.ok(routed.has("sim1") && routed.has("sim2") && routed.has("audit"));
  assert.ok(!routed.has("old-vendor"));
});

test("an empty or partial answer is an empty map, not a failure", () => {
  assert.deepEqual(toRoutingMap(null), { source: null, loadedAt: null, tables: [], groups: [] });
  assert.deepEqual(toRoutingMap({ tables: [{ name: "t", rules: null }], groups: [{ name: "", members: [] }] }).groups, []);
});

test("the route: 204 without routing_view, the map with it, 502 when the gateway fails", async () => {
  let asked = false;
  const absent = await readRoutingView({ available: async () => false, view: async () => ((asked = true), MOCK_ROUTING_VIEW) });
  assert.deepEqual(absent, { status: 204 });
  assert.equal(asked, false, "an older gateway is never sent a field it rejects");
  const ok = await readRoutingView({ available: async () => true, view: async () => MOCK_ROUTING_VIEW });
  assert.equal(ok.status, 200);
  assert.equal(ok.status === 200 && ok.body.data.groups[0].name, "sim-lb");
  const failed = await readRoutingView({ available: async () => true, view: async () => Promise.reject(new Error("gateway timed out")) });
  assert.deepEqual(failed, { status: 502, body: { error: "gateway timed out" } });
});

test("the route: a slow gateway is a 502 with code SLOW; a refused read that taught no routing_view is a 204", async () => {
  const { GatewayError, PANEL_CODES } = await import("./gateway-graphql-core.ts");
  const slow = await readRoutingView({ available: async () => true, view: async () => { throw new GatewayError(502, PANEL_CODES.slow, "slow"); } });
  assert.deepEqual(slow, { status: 502, body: { error: "slow", code: "SLOW" } });
  let has = true;
  const missing = await readRoutingView({
    available: async () => has,
    view: async () => {
      has = false;
      throw new GatewayError(400, "BAD_REQUEST", "Field 'routing' undefined");
    },
  });
  assert.deepEqual(missing, { status: 204 });
});
