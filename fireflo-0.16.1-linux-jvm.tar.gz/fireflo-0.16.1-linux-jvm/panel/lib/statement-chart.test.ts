import { strict as assert } from "node:assert";
import { test } from "node:test";

import { CHART_KEYS, keyLabel, stackedDays } from "./statement-chart.ts";

test("the biggest keys by money are named, the rest fold into Other, and nothing is lost", () => {
  const lines = ["a", "b", "c", "d", "e", "f", "g"].map((product) => ({ product }));
  const days = [{ day: "2026-01-01", price: 99, byKey: Object.fromEntries(lines.map((l, i) => [l.product, { submitted: i + 1, amount: 1 }])) }];
  const chart = stackedDays(days, lines, "login");
  assert.equal(chart.series.length, CHART_KEYS + 1);
  assert.equal(chart.series.at(-1)!.id, "other");
  assert.deepEqual(chart.series.slice(0, 2).map((s) => s.label), ["a", "b"]);
  const p = chart.data[0];
  assert.equal(p.price, 99);
  assert.equal(p.other, 6 + 7, "f and g");
  const drawn = chart.series.reduce((n, s) => n + (p[s.id] ?? 0), 0);
  assert.equal(drawn, 28, "every message is in some segment");
});

test("few keys: no Other; an empty key reads as no login (or all logins before 0.15.1) by login and 'no product' by product", () => {
  const chart = stackedDays([{ day: "d", price: 0, byKey: { "": { submitted: 2, amount: 0 } } }], [{ product: "" }], "login");
  assert.deepEqual(chart.series.map((s) => s.label), ["(no login / all logins before 0.15.1)"]);
  assert.equal(chart.data[0].k0, 2);
  assert.equal(keyLabel("", "product"), "no product");
});
