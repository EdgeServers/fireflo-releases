//server-only by convention: node:crypto, and nothing a client component imports
import { randomBytes } from "node:crypto";
import { authMac, sameMac } from "./auth-proof.ts";
import { lockoutKey } from "./signin-lockout.ts";

/**
 * The second step of a two-factor operator sign-in: what a password (or link) that was right buys
 * when the user has an authenticator -- not a session, but this token, signed under `AUTH_SECRET`
 * (`auth-proof.ts`), naming the user and their password stamp, good for five minutes, spent by the
 * sign-in it completes. The sign-in form carries it to the `operator-totp` provider with the code.
 */

/** How long a password-verified sign-in may wait for its authenticator code. */
export const PENDING_TTL_MS = 5 * 60_000;

/** What a second-step token says: who, under which password stamp, from which door, until when. */
export interface PendingSignIn {
  userId: number;
  /** `password_changed_at` at the first step: a password change in between voids the token. */
  pwdAt: number | null;
  /** How the first step was passed, for the audit line. */
  via: "password" | "link";
  /**
   * The lockout key the first step counted its attempt under (`ip|email`), when it counted one: the
   * password step's attempt is given back only when the code completes the sign-in. Signed with the
   * rest, so a client cannot name another key to clear.
   */
  lockKey?: string | null;
  expiresAt: number;
  nonce: string;
}

/**
 * The token a sign-in that passed its first step (password or link) gets in place of a session,
 * when the user has an authenticator: proof that the first step passed, good for
 * {@link PENDING_TTL_MS}. Holding it is worth exactly what knowing the password is worth -- the
 * right to try codes, which the sign-in lockout counts.
 */
export function signPending(p: Omit<PendingSignIn, "expiresAt" | "nonce">, now = Date.now()): string | null {
  const body: PendingSignIn = { ...p, expiresAt: now + PENDING_TTL_MS, nonce: randomBytes(16).toString("base64url") };
  const payload = Buffer.from(JSON.stringify(body)).toString("base64url");
  const sig = authMac("pending", payload);
  return sig ? `${payload}.${sig}` : null;
}

/** The token's statement, when it is ours, intact, unexpired and not yet spent; else null. */
export function readPending(token: unknown, now = Date.now()): PendingSignIn | null {
  if (typeof token !== "string" || token.length > 2048) {
    return null;
  }
  const dot = token.indexOf(".");
  if (dot <= 0) {
    return null;
  }
  const payload = token.slice(0, dot);
  const expected = authMac("pending", payload);
  if (!expected || !sameMac(expected, token.slice(dot + 1))) {
    return null;
  }
  try {
    const p = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as PendingSignIn;
    if (typeof p.userId !== "number" || typeof p.expiresAt !== "number" || typeof p.nonce !== "string"
        || now >= p.expiresAt || spent.has(p.nonce)) {
      return null;
    }
    return p;
  } catch {
    return null;
  }
}

/**
 * Spent second-step tokens, by nonce, until they would have expired anyway.
 *
 * <p>Per process, deliberately (accepted in the 0.15 security review): a panel restart or a second
 * panel instance does not know a token was spent, and could accept it again within its five minutes.
 * That buys nothing a fresh sign-in would not: every use still needs a new, unused authenticator code,
 * which the database counts and locks per user (`attemptCode`).
 */
const spent = new Map<string, number>();

/** Marks a token used, so the session it bought cannot be bought twice with it. */
export function spendPending(p: PendingSignIn, now = Date.now()): void {
  for (const [nonce, until] of spent) {
    if (until <= now) {
      spent.delete(nonce);
    }
  }
  spent.set(p.nonce, p.expiresAt);
}

/**
 * The in-memory lockout keys of a second step: the one the code step counts under (origin and
 * user), then the ones a right code gives back -- that key, the first step's (the password step
 * counted the attempt before it knew a code would follow, and only a completed sign-in returns it),
 * and this origin's for the address, which the first step may have used from another origin.
 */
export function secondStepLockKeys(p: PendingSignIn, ip: string | null, email: string): { counted: string; release: string[] } {
  const counted = lockoutKey(ip, `totp:${p.userId}`);
  const release = [counted, lockoutKey(ip, email)];
  if (p.lockKey && !release.includes(p.lockKey)) {
    release.push(p.lockKey);
  }
  return { counted, release };
}

/** The prefix on a `CredentialsSignin` code that carries a second-step token to the sign-in form. */
export const TOTP_CODE_PREFIX = "totp.";
