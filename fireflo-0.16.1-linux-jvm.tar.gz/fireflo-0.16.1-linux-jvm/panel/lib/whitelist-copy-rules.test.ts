import { test } from "node:test";
import assert from "node:assert/strict";
import {
  COPY_MAX_ROWS,
  COPY_MAX_TARGETS,
  type CopyPick,
  type CopySource,
  carriesDltTemplateId,
  copyKey,
  copyResultLine,
  copyStamp,
  copySummary,
  copyTargetRefusal,
  dltCopyWarning,
  loginOnlyCopyNote,
  mergeCopyResults,
  parseCopyRequest,
  planCopy,
} from "./account-archive-rules.ts";

const row = (over: Partial<CopySource> = {}): CopySource => ({
  id: 1, accountId: "load", product: "test-pro", systemId: null, display: "FIREFL", folded: "firefl",
  status: "APPROVED", enabled: true, ...over,
});

test("an approved, account-wide row the target lacks is copied as it is", () => {
  const plan = planCopy([row()], "load2", new Set(), false);
  assert.equal(plan.copy.length, 1);
  assert.equal(plan.copy[0].systemId, null);
  assert.deepEqual(plan.skipped, []);
});

test("each skip reason is named", () => {
  const plan = planCopy([
    row({ id: 1, accountId: "load2" }),
    row({ id: 2, status: "REJECTED" }),
    row({ id: 3, enabled: false }),
    row({ id: 4, systemId: "loadgen" }),
    row({ id: 5, folded: "otpsms" }),
  ], "load2", new Set([copyKey("test-pro", null, "otpsms")]), false);
  assert.equal(plan.copy.length, 0);
  assert.deepEqual(plan.skipped.map((s) => [s.id, s.reason]), [
    [1, "own-account"], [2, "rejected"], [3, "withdrawn"], [4, "login-only"], [5, "already"],
  ]);
});

test("a pending row is copied even though it is not enabled; only approved-and-disabled is withdrawn", () => {
  const plan = planCopy([row({ status: "PENDING", enabled: false })], "load2", new Set(), false);
  assert.equal(plan.copy.length, 1);
});

test("the duplicate test is per product and per scope", () => {
  const existing = new Set([copyKey("other", null, "firefl"), copyKey("test-pro", "x", "firefl")]);
  assert.equal(planCopy([row()], "load2", existing, false).copy.length, 1);
});

test("widenScope copies a login-only row account-wide, and its duplicate test is account-wide too", () => {
  const scoped = row({ systemId: "loadgen" });
  const plan = planCopy([scoped], "load2", new Set(), true);
  assert.equal(plan.copy.length, 1);
  assert.equal(plan.copy[0].systemId, null);
  const already = planCopy([scoped], "load2", new Set([copyKey("test-pro", null, "firefl")]), true);
  assert.equal(already.skipped[0].reason, "already");
});

test("a template duplicates by its body, ignoring case, as folded by the database", () => {
  //the folded text comes from lower(body); two bodies differing only in case fold to one key
  const a = row({ id: 1, display: "otp-1", folded: "your otp is {#var#}." });
  const b = row({ id: 2, accountId: "fireflo", display: "OTP", folded: "your otp is {#var#}." });
  const plan = planCopy([a, b], "load2", new Set(), false);
  assert.equal(plan.copy.length, 1, "two selected rows that collide in the target copy once");
  assert.deepEqual(plan.skipped.map((s) => s.reason), ["already"]);
  const existing = planCopy([a], "load2", new Set([copyKey("test-pro", null, "your otp is {#var#}.")]), false);
  assert.equal(existing.skipped[0].reason, "already");
});

test("keep: approved stays approved, stamped with the operator; pending stays pending", () => {
  assert.deepEqual(copyStamp("APPROVED", "keep", "load", "sudhanshu"), {
    status: "APPROVED", reviewedBy: "sudhanshu", reviewNote: "copied from load", requestNote: null,
  });
  const pending = copyStamp("PENDING", "keep", "load", "sudhanshu");
  assert.equal(pending.status, "PENDING");
  assert.equal(pending.reviewedBy, null);
  assert.equal(pending.requestNote, "copied from load");
});

test("pending: every copy waits, with where it came from and who copied it", () => {
  for (const status of ["APPROVED", "PENDING"]) {
    assert.deepEqual(copyStamp(status, "pending", "load", "sudhanshu"), {
      status: "PENDING", reviewedBy: null, reviewNote: null, requestNote: "copied from load by sudhanshu",
    });
  }
});

test("a missing or archived target refuses the whole copy", () => {
  const known = new Map([["load2", false], ["old", true]]);
  assert.equal(copyTargetRefusal(["load2"], known), null);
  assert.match(copyTargetRefusal(["load2", "ghost"], known) ?? "", /no account 'ghost'/);
  assert.match(copyTargetRefusal(["ghost", "nope"], known) ?? "", /no accounts 'ghost', 'nope'/);
  assert.match(copyTargetRefusal(["old"], known) ?? "", /'old' is archived/);
});

test("the request body is checked with sentences an operator can act on", () => {
  assert.deepEqual(parseCopyRequest({ ids: [3, 3, 4], to: [" a ", "a", "b"] }, "templates"),
    { ids: [3, 4], to: ["a", "b"], status: "keep", widenScope: false });
  assert.deepEqual(parseCopyRequest({ ids: [1], to: ["a"], status: "pending", widenScope: true }, "templates"),
    { ids: [1], to: ["a"], status: "pending", widenScope: true });
  const error = (b: unknown) => {
    const r = parseCopyRequest(b, "sender IDs");
    return "error" in r ? r.error : "";
  };
  assert.match(error({}), /Choose the sender IDs/);
  assert.match(error({ ids: [1.5], to: ["a"] }), /whole numbers/);
  assert.match(error({ ids: [1], to: [] }), /at least one account/);
  assert.match(error({ ids: [1], to: "a" }), /list of account ids/);
  assert.match(error({ ids: [1], to: ["a"], status: "approved" }), /"keep"/);
  assert.match(error({ ids: [1], to: ["a"], widenScope: "yes" }), /true or false/);
  assert.match(error({ ids: Array.from({ length: COPY_MAX_ROWS + 1 }, (_, i) => i + 1), to: ["a"] }), /At most 500/);
  assert.match(error({ ids: [1], to: Array.from({ length: COPY_MAX_TARGETS + 1 }, (_, i) => `a${i}`) }), /At most 50 accounts/);
});

test("a DLT template ID is found by its tag, however the token is spelled", () => {
  assert.equal(carriesDltTemplateId("tmplid_0x1401=1107160012345678901"), true);
  assert.equal(carriesDltTemplateId("peid_0x1400=1,0x1401=2"), true);
  assert.equal(carriesDltTemplateId("tlv_5121=2"), true, "5121 is 0x1401 in decimal");
  assert.equal(carriesDltTemplateId("tlv_1401=2"), false, "bare 1401 is decimal, tag 0x0579");
  assert.equal(carriesDltTemplateId("tmplid_0x1401="), false, "an empty value carries nothing");
  assert.equal(carriesDltTemplateId(null), false);
});

const pick = (over: Partial<CopyPick> = {}): CopyPick => ({
  kind: "template", id: 1, accountId: "load", systemId: null, tlvs: null, status: "APPROVED", ...over,
});

test("the DLT warning names the source's PE and counts only rows that carry the id", () => {
  assert.equal(dltCopyWarning([pick()]), null);
  assert.equal(
    dltCopyWarning([pick({ tlvs: "tmplid_0x1401=1107" }), pick({ id: 2 })]),
    "1 selected template carries a DLT template ID (TLV 0x1401) registered under load's principal entity. "
      + "Check it is valid for each target account before relying on it.");
  assert.match(dltCopyWarning([pick({ tlvs: "0x1401=1" }), pick({ id: 2, kind: "header", accountId: "b", tlvs: "0x1401=2" })]) ?? "",
    /^2 selected rows carry .* \(load, b\)/);
  assert.equal(dltCopyWarning([pick({ tlvs: "0x1401=1", status: "REJECTED" })]), null, "a rejected row is not copied");
});

test("the login-only note appears only when such rows are selected", () => {
  assert.equal(loginOnlyCopyNote([pick()]), null);
  assert.equal(loginOnlyCopyNote([pick({ systemId: "loadgen" })]),
    "1 selected row applies to one login only (loadgen). Target accounts don't have that login, "
      + "so it is skipped unless you tick this.");
  assert.match(loginOnlyCopyNote([pick({ systemId: "a" }), pick({ id: 2, systemId: "b" })]) ?? "",
    /2 selected rows apply .* \(a, b\)\. .* those logins, so they are skipped/);
});

test("the summary and the result lines read as the mockup does", () => {
  assert.equal(copySummary(3, 2, ["a", "b", "c", "d"]), "Copy 3 headers and 2 templates to 4 accounts: a, b, c, d.");
  assert.equal(copySummary(1, 0, ["a"]), "Copy 1 header to 1 account: a.");
  assert.equal(copySummary(0, 1, []), "Copy 1 template to 0 accounts.");
  assert.equal(copyResultLine({ copied: 3, skipped: [] }), "3 copied");
  assert.equal(copyResultLine({
    copied: 1,
    skipped: [{ id: 1, text: "x", reason: "login-only" }, { id: 2, text: "y", reason: "already" }],
  }), "1 copied · 1 already there · 1 login-only, skipped");
});

test("header and template results merge per account", () => {
  const merged = mergeCopyResults(
    [{ to: "a", copied: 2, skipped: [] }, { to: "b", copied: 1, skipped: [] }],
    [{ to: "b", copied: 1, skipped: [{ id: 9, text: "t", reason: "already" }] }],
  );
  assert.deepEqual(merged, [
    { to: "a", copied: 2, skipped: [] },
    { to: "b", copied: 2, skipped: [{ id: 9, text: "t", reason: "already" }] },
  ]);
});
