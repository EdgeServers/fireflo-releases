import type { Health } from "./health-types";

/**
 * What the gateway's API can do, read from the `health` field's `api` map (gateway 0.13+).
 *
 * <p>A capability is a fact about the build, published by name and never withdrawn while the
 * feature exists. Screens ask for a name rather than reasoning from the version string, because a
 * version says when something shipped and a name says whether it is there -- which is the question.
 * A gateway older than the map answers no to everything, and that is the right answer: none of the
 * named features existed.
 */

/**
 * The names this panel asks for, as the gateway's `ApiCapabilities` publishes them.
 *
 * <p>Gateway 0.13: `graphql_ops` is the GraphQL endpoint on the management port (and so, by
 * implication, the end of REST `/ops`); `send_as_account` and `account_sync` are the platform
 * (OMNI) fields; `slow_query_log` and `refusal_ledger` are the two new diagnostics the Security and
 * Diagnostics pages read. A screen that needs one asks by name and says so when it is absent.
 */
export const GRAPHQL_OPS = "graphql_ops";
export const SEND_AS_ACCOUNT = "send_as_account";
export const ACCOUNT_SYNC = "account_sync";
export const SLOW_QUERY_LOG = "slow_query_log";
export const REFUSAL_LEDGER = "refusal_ledger";
/** Session rows carry `receipts` (gateway 0.13.2): the listener's Status tab sets DLR against MT. */
export const SESSION_RECEIPTS = "session_receipts";

/**
 * Gateway 0.14, the Kafka backbone. `kafka_backbone`: `smsg.queue.provider=kafka` exists, with the
 * `smsg.kafka.*` keys, `health.backbone` and `brokerTest(bootstrap, topic)` -- the Queues page's
 * broker card asks for this. `node_identity`: `health.nodeId` and `health.cluster.nodes`, which
 * the Nodes page lists. `vendor_leases`: vendor sessions are leased to one node at a time (columns
 * on Nodes, later). `queue_peek`: topic rows in the queue dump carry peeked entries. `topic_lag`:
 * those rows carry the consumer group's lag and member count.
 */
export const KAFKA_BACKBONE = "kafka_backbone";
export const NODE_IDENTITY = "node_identity";
export const VENDOR_LEASES = "vendor_leases";
export const QUEUE_PEEK = "queue_peek";
export const TOPIC_LAG = "topic_lag";
/**
 * Gateway 0.14.2. `queue_provider_env`: FIREFLO_QUEUE_PROVIDER and FIREFLO_KAFKA_BOOTSTRAP in the
 * gateway's fireflo.env decide the provider over `app_config`, and `health.backbone.source` says
 * which one did. The broker card locks the two keys when it is `env`.
 */
export const QUEUE_PROVIDER_ENV = "queue_provider_env";
/**
 * Gateway 0.14.3. `kafka_topics_view`: the `kafkaTopics` field, every topic under the prefix with
 * its groups and who uses it. The Kafka page and its sidebar row ask for this (and a Kafka backbone).
 */
export const KAFKA_TOPICS_VIEW = "kafka_topics_view";

/**
 * Gateway 0.15. `cdr_storage`: the `cdrStorage` field -- the hot and archive call record tables, the
 * mover's settings and its log. Reports → Archives' Call records section asks for this.
 */
export const CDR_STORAGE_VIEW = "cdr_storage";

/**
 * Gateway 0.15.1. `vendor_backlog`: the `vendorBacklog` field -- each vendor's waiting messages
 * against its limits, its state, its bind and where its traffic went instead. The Vendors page and
 * the backlog warning on Overview and Health ask for this.
 */
export const VENDOR_BACKLOG_VIEW = "vendor_backlog";

/**
 * Gateway 0.15.1. `account_throughput`: the `accountThroughput` field (one account's ceiling per
 * listener with the setting that produced it, binds, live TPS, throttles), `Session.loginTpsLimit` /
 * `limitSource`, health's `throttling` and the `smpp_throttle_minute` table (V1.118.0). The Account ›
 * Limits tab, the health route's throttle list and the Refused page's SMPP strip ask for this.
 */
export const ACCOUNT_THROUGHPUT_VIEW = "account_throughput";
/**
 * Gateway 0.15.1. `db_admission`: health's `db_latency_ms`, `db_pool_wait_ms`, `db_admission`,
 * `db_refused_total`, and the refusal reason `dbUnavailable`. The Queues and Health pages read it.
 */
export const DB_ADMISSION_VIEW = "db_admission";
/**
 * Gateway 0.15.1. `db_info`: health's `database` block -- the gateway's PostgreSQL host, address,
 * port and database, server and schema versions, the pool and its lanes, the last probe. The Queues
 * page's Database card draws its "gateway → PostgreSQL" rows from it, and only when it is present.
 */
export const DB_INFO = "db_info";
/**
 * Gateway 0.15.1. `routing_view`: the `routing` field -- the routing tables and route groups the
 * router holds in memory and applies now (`StandardRoutingManager`), not what the database says the
 * next reload will apply. The Connectivity page reads which vendors are routed to and which a group
 * frames from it, through `/api/control/connectivity/routing`, and falls back to the config routes
 * only when it is absent.
 */
export const ROUTING_VIEW = "routing_view";

/**
 * Gateway 0.15.2. `component_restart`: the `componentRestart` mutation (ADMIN) -- one internal part of
 * the running gateway restarted without restarting the process: its database writers, its pool, the
 * Kafka router and consumers, one vendor's feed or binds -- and health's `persist_streams` with
 * `persist_writer` reading `stalled`. The Queues page's Restart rows are shown only when it is there.
 */
export const COMPONENT_RESTART = "component_restart";

/**
 * Gateway 0.15.3. `receipt_custody`: a vendor's receipt is taken into custody (Kafka
 * `fireflo.receipts.in`, or the local log in memory mode) before the vendor is told OK, and matched
 * against the receipt store at the database's pace -- so a slow database never has a vendor asked to
 * resend. Health gains `receipts_in` and `persist_log_mode`. The Queues page's "Receipts waiting to
 * be matched" card, the vendor card's "waiting to match" and the Database card's custody note are
 * shown only when it is there.
 */
export const RECEIPT_CUSTODY = "receipt_custody";

/**
 * Gateway 0.15.10. `router_anchor`: a Kafka router partition without a committed offset is held
 * rather than read from its beginning, and health's `backbone.state` / `backbone.router` list the
 * held (`partitionsUnanchored`) and stalled partitions. The Queues page's backbone card asks for it.
 */
export const ROUTER_ANCHOR = "router_anchor";

/** Whether this gateway's API has the named capability. False on an older gateway or no health. */
export function hasCapability(health: Health | null | undefined, name: string): boolean {
  return health?.api?.[name] === true;
}

/** The capabilities this gateway declares, sorted, so two gateways' lists can be read side by side. */
export function capabilityNames(health: Health | null | undefined): string[] {
  return Object.entries(health?.api ?? {})
    .filter(([, on]) => on === true)
    .map(([name]) => name)
    .sort();
}

/**
 * One sentence for a verify or status screen, or null when the gateway publishes no map at all --
 * which a caller shows as "not reported" rather than as an empty list, since those differ.
 */
export function apiLevelSentence(health: Health | null | undefined): string | null {
  if (health?.api == null) {
    return null;
  }
  const names = capabilityNames(health);
  return names.length
    ? `This gateway answers API level ${names.join(", ")}.`
    : "This gateway answers API level with no capabilities declared.";
}
