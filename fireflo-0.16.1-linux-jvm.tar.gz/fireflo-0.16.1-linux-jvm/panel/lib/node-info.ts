import type { ClusterNode } from "./health-types.ts";

/**
 * The Node information section on Gateway (0.15.1): the one-line summary it shows while closed, and
 * when it opens itself. Pure, so the wording and the rules are tested without a page.
 *
 * <p>The section replaced the Nodes page. It stays closed by default because a healthy cluster is
 * not worth a screenful above the settings, and opens on its own for the two things an operator
 * must not miss: a node that has missed the timeout, and live nodes on different releases.
 */

/** Where the open/closed choice is remembered, per browser. */
export const NODE_INFO_KEY = "fireflo.gateway.nodeInfo";

/** The anchor the old /cp/nodes redirects to; the section opens when the page arrives on it. */
export const NODE_INFO_HASH = "#nodes";

/** Live nodes first, this one first among them, then by id: the order the table reads in. */
export function sortNodes(nodes: readonly ClusterNode[], self: string | null): ClusterNode[] {
  return [...nodes].sort(
    (a, b) => Number(b.alive) - Number(a.alive) || Number(b.nodeId === self) - Number(a.nodeId === self) || a.nodeId.localeCompare(b.nodeId)
  );
}

/** The distinct releases the live nodes run; a dead node's version is history, not a mismatch. */
export function liveVersions(nodes: readonly ClusterNode[]): string[] {
  return [...new Set(nodes.filter((n) => n.alive).map((n) => n.version?.trim()).filter((v): v is string => !!v))];
}

/** "3 nodes · 2 alive · 1 missed the timeout", or "1 node · this one" for a single gateway. */
export function nodeSummary(nodes: readonly ClusterNode[], self: string | null): string {
  if (nodes.length === 0) {
    return "no nodes listed";
  }
  const alive = nodes.filter((n) => n.alive).length;
  const dead = nodes.length - alive;
  if (nodes.length === 1) {
    const only = nodes[0];
    return `1 node · ${only.nodeId === self ? "this one" : only.alive ? "alive" : "missed the timeout"}`;
  }
  const parts = [`${nodes.length} nodes`, `${alive} alive`];
  if (dead > 0) {
    parts.push(`${dead} missed the timeout`);
  }
  const versions = liveVersions(nodes);
  if (versions.length > 1) {
    parts.push(`${versions.length} releases`);
  }
  return parts.join(" · ");
}

/**
 * Why the section should open itself, or null when nothing needs it: a dead node, or live nodes on
 * different releases. A string rather than a boolean so a new alarm (a second node dying) opens it
 * again after the operator closed it for the first one.
 */
export function selfOpenReason(nodes: readonly ClusterNode[]): string | null {
  const dead = nodes.filter((n) => !n.alive).map((n) => n.nodeId).sort();
  const versions = liveVersions(nodes).sort();
  if (dead.length === 0 && versions.length <= 1) {
    return null;
  }
  return `dead:${dead.join(",")}|versions:${versions.length > 1 ? versions.join(",") : ""}`;
}

/**
 * Whether the section starts open: on `#nodes` (the old Nodes page's redirect) or when the browser
 * remembered it open. The alarms are applied after, once health has arrived.
 */
export function initiallyOpen(stored: string | null, hash: string): boolean {
  return hash === NODE_INFO_HASH || stored === "1";
}
