import { messageRows, type GrainOptions } from "./cdr-grain.ts";
import { hourUtc, LIVE_COLUMNS, OUTCOME_LATERAL } from "./usage-summary-sql.ts";

/**
 * Report > Usage (0.15.1): traffic by account × login × product over a window, its per-row hours or
 * days, and the window's own buckets -- read from the summaries, never from the busy tables.
 *
 * <h2>Where each part of the window is read from</h2>
 *
 * <ul>
 *   <li><b>Rolled days</b> (day grain only): `usage_daily`, for the billing days before the day the
 *       nightly rollup last ran on (`usage_rollup_cursor.last_daily_day`), which all have their
 *       lines. Logins from `usage_daily.system_id` (V1.115.0), or none before it.</li>
 *   <li><b>Hours</b>: `usage_hourly` from the end of the rolled days (or the window's start) up to
 *       the gateway's watermark, `hourly_hwm`. Logins from `usage_hourly.system_id` (V1.113.0).</li>
 *   <li><b>The raw edge</b>: `cdr_submit` only for what no summary holds yet -- the minutes past the
 *       watermark, and a sliver before the first whole UTC hour when the window does not start on one
 *       -- bounded on `submitted_at` at both ends, one row per message as the rollup counts, with the
 *       bounded outcome LATERAL. The caller refuses to read at all when the watermark is more than a
 *       few hours old (`metrics-queries.ts`), so the edge is minutes, on the hot tables.</li>
 * </ul>
 *
 * <p>Hours with no summary rows are empty, not read from the records: a summary younger than the
 * window shows the window as quieter than it was, rather than scanning call records for it. That is
 * the owner's rule for this page -- never load the busy tables.
 *
 * <p>An hour is put in the billing day its start falls in. In a zone whose offset is not a whole
 * number of hours an hour row straddles two days and lands in the first: the Usage page is
 * operational, and the statement is where a billing day is exact.
 *
 * <h2>Binds</h2>
 *
 * <p>`$1` since, `$2` until, `$3` the billing zone, `$4` account, `$5` login, `$6` product. With
 * `match: "filter"` a null filter matches anything; with `match: "exact"` (one row's breakdown) the
 * three are the row's own keys and a null matches only "none" -- traffic that named no account,
 * no login recorded, no product. Every key is compared after `NULLIF(…, '')`, so the summaries'
 * `''` and the records' NULL are one "—".
 */

export type UsageGrain = "hour" | "day";

export interface UsageGridOptions extends GrainOptions {
  grain: UsageGrain;
  /** `usage_daily.system_id` exists (V1.115.0). */
  dailyLogin: boolean;
  /** `usage_hourly.system_id` exists (V1.113.0). */
  hourlyLogin: boolean;
  /** How `$4`-`$6` match: a filter (null is anything) or one row's exact keys (null is none). */
  match: "filter" | "exact";
}

/** The predicate for one key column against its bind, in either matching mode. */
function keyMatch(expr: string, bind: string, match: UsageGridOptions["match"]): string {
  return match === "exact"
    ? `NULLIF(${expr}, '') IS NOT DISTINCT FROM ${bind}::text`
    : `(${bind}::text IS NULL OR ${expr} = ${bind}::text)`;
}

/** All three keys of one source; a source with no login column can only match "no login". */
function keysMatch(account: string, login: string | null, product: string, match: UsageGridOptions["match"]): string {
  //no login column: only "no login" matches -- a filter for none, or a row whose login is none
  const loginMatch = login ? keyMatch(login, "$5", match) : "$5::text IS NULL";
  return `${keyMatch(account, "$4", match)} AND ${loginMatch} AND ${keyMatch(product, "$6", match)}`;
}

/**
 * The `WITH` prelude: `cut` and `grid`, whose rows are `bucket` (a billing day for the day grain, a
 * UTC hour for the hour grain), `account_id`, `login`, `product` (each NULL for none) and the counts:
 * `submitted`, `delivered`, `failed` (failed and expired together, as the Usage chart draws them),
 * `pending` and `price` (scaled). The caller appends its `SELECT … FROM grid`.
 */
export function usageGridSql(o: UsageGridOptions): string {
  const day = o.grain === "day";
  //where the rolled days end and the hours begin: the day the nightly rollup last ran on, inside
  //the window; the window's start for the hour grain, or with no rollup cursor
  const dailyEnd = day
    ? `LEAST($2::timestamptz, GREATEST($1::timestamptz,
         COALESCE((SELECT (c.last_daily_day::timestamp AT TIME ZONE $3) FROM usage_rollup_cursor c), $1::timestamptz)))`
    : "$1::timestamptz";
  const rawBucket = day ? "(s.submitted_at AT TIME ZONE $3)::date" : hourUtc("s.submitted_at");
  const hourBucket = day ? "(h.hour AT TIME ZONE $3)::date" : "h.hour";
  const rawKeys = keysMatch("s.account_id", "s.system_id", "s.product", o.match);
  //LIVE_COLUMNS carries system_id already: the login the raw edge groups by
  const columns = [...new Set([...LIVE_COLUMNS, "system_id"])];
  const head = messageRows(
    `s.submitted_at >= cut.hourly_lo AND s.submitted_at < LEAST(cut.first_hour, cut.seam, cut.until) AND ${rawKeys}`,
    o,
    columns
  );
  const tail = messageRows(`s.submitted_at >= cut.seam AND s.submitted_at < cut.until AND ${rawKeys}`, o, columns);

  const daily = day
    ? `
      SELECT u.day AS bucket,
             NULLIF(u.account_id, '') AS account_id,
             ${o.dailyLogin ? "NULLIF(u.system_id, '')" : "NULL::text"} AS login,
             NULLIF(u.product, '') AS product,
             u.submitted, u.delivered, u.failed + u.expired AS failed,
             u.pending_at_rollup AS pending, u.price_total AS price
        FROM cut, usage_daily u
       WHERE u.day >= (cut.since AT TIME ZONE $3)::date
         AND u.day < (cut.hourly_lo AT TIME ZONE $3)::date
         AND ${keysMatch("u.account_id", o.dailyLogin ? "u.system_id" : null, "u.product", o.match)}
      UNION ALL`
    : "";

  return `
  WITH cut AS (
      SELECT w.since, w.until, w.hourly_lo,
             --the first whole UTC hour at or after where the hours begin
             CASE WHEN ${hourUtc("w.hourly_lo")} < w.hourly_lo THEN ${hourUtc("w.hourly_lo")} + interval '1 hour'
                  ELSE w.hourly_lo END AS first_hour,
             --the watermark clamped into the window; back to the hour until falls in when the
             --summary has moved past until, so no hour row reaches beyond the window
             GREATEST(w.hourly_lo, LEAST(CASE WHEN w.hwm >= w.until THEN ${hourUtc("w.until")} ELSE w.hwm END, w.until)) AS seam
        --the zone is named here too, typed, so an hour-grain statement that reads no billing day still
        --binds it the same way
        FROM (SELECT $1::timestamptz AS since, $2::timestamptz AS until, ${dailyEnd} AS hourly_lo, $3::text AS zone,
                     COALESCE((SELECT c.hourly_hwm FROM usage_rollup_cursor c), $1::timestamptz) AS hwm) w
  ),
  grid AS (${daily}
      SELECT ${hourBucket} AS bucket,
             NULLIF(h.account_id, '') AS account_id,
             ${o.hourlyLogin ? "NULLIF(h.system_id, '')" : "NULL::text"} AS login,
             NULLIF(h.product, '') AS product,
             h.submitted, h.delivered, h.failed + h.expired AS failed,
             h.pending_at_rollup AS pending, h.price_total AS price
        FROM cut, usage_hourly h
       WHERE h.hour >= cut.first_hour AND h.hour < cut.seam
         AND ${keysMatch("h.account_id", o.hourlyLogin ? "h.system_id" : null, "h.product", o.match)}
      UNION ALL
      --the raw edge: one row per message, as the rollup counts, over the two slivers no summary holds
      SELECT ${rawBucket} AS bucket,
             NULLIF(s.account_id, '') AS account_id,
             NULLIF(s.system_id, '') AS login,
             NULLIF(s.product, '') AS product,
             count(*) AS submitted,
             count(*) FILTER (WHERE o.final_state = 'DELIVERED') AS delivered,
             count(*) FILTER (WHERE o.final_state IN ('FAILED', 'REJECTED', 'DROPPED', 'EXPIRED')) AS failed,
             count(*) FILTER (WHERE o.final_state IS NULL) AS pending,
             COALESCE(SUM(s.price), 0) AS price
        FROM cut, LATERAL (
             SELECT * FROM ${head}
             UNION ALL
             SELECT * FROM ${tail}
        ) s${OUTCOME_LATERAL}
       GROUP BY 1, 2, 3, 4
  )`;
}

/** The figures every projection sums, in the order the rows carry them. */
const SUMS = `SUM(submitted)::bigint AS submitted, SUM(delivered)::bigint AS delivered,
         SUM(failed)::bigint AS failed, SUM(pending)::bigint AS pending, SUM(price)::bigint AS price`;

/**
 * One row per account × login × product, heaviest first, one page: `$7` the page size, `$8` the
 * offset. `total_rows` is every row's count, for the pager.
 */
export function usageRowsSql(o: Omit<UsageGridOptions, "match">): string {
  return `${usageGridSql({ ...o, match: "filter" })}
  SELECT account_id, login, product, ${SUMS}, count(*) OVER () AS total_rows
    FROM grid
   GROUP BY account_id, login, product
   ORDER BY SUM(submitted) DESC, account_id NULLS LAST, login NULLS LAST, product NULLS LAST
   LIMIT $7 OFFSET $8`;
}

/** The text a bucket is answered as: `YYYY-MM-DD`, or the UTC hour as an ISO instant. */
function bucketText(grain: UsageGrain, expr: string): string {
  return grain === "day" ? `to_char(${expr}, 'YYYY-MM-DD')` : `to_char(${expr} AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')`;
}

/**
 * Every bucket of the window, with what fell in it: for the chart (`match: "filter"`, the page's
 * filters) and for one row's breakdown (`match: "exact"`, the row's keys). Buckets with nothing in
 * them are listed with zeros, so a breakdown has one sub-row per hour or day of the window.
 */
export function usageBucketsSql(o: UsageGridOptions): string {
  const series = o.grain === "day"
    ? `SELECT g::date AS bucket FROM generate_series(($1::timestamptz AT TIME ZONE $3)::date,
                                                    (($2::timestamptz - interval '1 microsecond') AT TIME ZONE $3)::date,
                                                    interval '1 day') g`
    : `SELECT g AS bucket FROM generate_series(${hourUtc("$1::timestamptz")}, $2::timestamptz - interval '1 microsecond',
                                              interval '1 hour') g`;
  return `${usageGridSql(o)},
  buckets AS (${series})
  SELECT ${bucketText(o.grain, "b.bucket")} AS bucket,
         COALESCE(SUM(grid.submitted), 0)::bigint AS submitted, COALESCE(SUM(grid.delivered), 0)::bigint AS delivered,
         COALESCE(SUM(grid.failed), 0)::bigint AS failed, COALESCE(SUM(grid.pending), 0)::bigint AS pending,
         COALESCE(SUM(grid.price), 0)::bigint AS price
    FROM buckets b
    LEFT JOIN grid ON grid.bucket = b.bucket
   GROUP BY b.bucket
   ORDER BY b.bucket`;
}
