import type { HealthSession, LimitSource } from "./health-types";
import { BIND_TYPE_LABELS, labelFor } from "./labels.ts";
import { formatTps } from "./tps-format.ts";

/**
 * A listener's sessions folded by account.
 *
 * <p>The flat session table answers "which binds are up"; an operator looking at a listener
 * usually asks "who is on it, and how much of the traffic is theirs". A customer with two
 * transmitters and two receivers took four near-identical rows to say that, with the source port
 * hidden so two binds from one address could not even be told apart. One row per account, with the
 * binds counted by kind and the counters summed, is the reading; the binds themselves sit under it.
 *
 * <p>Pure, so the grouping and its wording are tested against session arrays rather than against a
 * rendered table. Nothing here fetches.
 */

export interface BindCounts {
  /** Bound TRANSMITTER, RECEIVER and TRANSCEIVER sessions, by the spec's own abbreviations. */
  TX: number;
  RX: number;
  TRX: number;
  /** Sessions the gateway still holds that are no longer bound: counted apart, never as a kind. */
  unbound: number;
}

export interface AccountGroup {
  /** The account name, or "—" for a session the gateway could not attribute. */
  account: string;
  /** Distinct system ids behind the account's binds, in first-seen order. */
  logins: string[];
  sessions: HealthSession[];
  counts: BindCounts;
  /** Distinct source addresses, in first-seen order. */
  hosts: string[];
  /** The longest-bound session's age in seconds, null when none reports one. */
  oldest: number | null;
  /** submit_sm received across the counting sessions; null when none of them counts. */
  received: number | null;
  /** deliver_sm sent back across the counting sessions (gateway 0.13.2+); null when none counts. */
  receipts: number | null;
  /** Measured tps summed over the sessions that report one; null when none does. */
  tps: number | null;
  /** The per-bind ceiling, when every bind that has one shares it; null otherwise. */
  tpsLimit: number | null;
  /**
   * Where that account ceiling came from, when the gateway says (0.15.1+) and the binds agree. A bind
   * held by its login's own `max_tps` says nothing about the account's, so it is left out of the vote.
   */
  limitSource: LimitSource | null;
}

/** The label of a session no account was attributed to. */
export const UNATTRIBUTED = "—";

/**
 * Fold sessions by account, busiest first.
 *
 * <p>Order is received traffic descending, then account name, so the account carrying the listener
 * sits at the top on every poll rather than wherever its first bind happened to land in the array.
 * A group that counts nothing sorts after every group that does.
 */
export function groupSessions(sessions: readonly HealthSession[]): AccountGroup[] {
  const byAccount = new Map<string, HealthSession[]>();
  for (const session of sessions) {
    const key = session.account?.trim() || UNATTRIBUTED;
    const list = byAccount.get(key);
    if (list) {
      list.push(session);
    } else {
      byAccount.set(key, [session]);
    }
  }
  return [...byAccount.entries()]
    .map(([account, rows]) => groupOf(account, rows))
    .sort((a, b) => (b.received ?? -1) - (a.received ?? -1) || a.account.localeCompare(b.account));
}

function groupOf(account: string, sessions: HealthSession[]): AccountGroup {
  const counts: BindCounts = { TX: 0, RX: 0, TRX: 0, unbound: 0 };
  const logins: string[] = [];
  const hosts: string[] = [];
  const ages: number[] = [];
  const limits = new Set<number>();
  const sources = new Set<LimitSource>();
  let received: number | null = null;
  let receipts: number | null = null;
  let tps: number | null = null;

  for (const session of sessions) {
    if (!session.bound) {
      counts.unbound += 1;
    } else {
      const kind = labelFor(BIND_TYPE_LABELS, session.bind_type);
      if (kind === "TX" || kind === "RX" || kind === "TRX") {
        counts[kind] += 1;
      }
    }
    if (session.system_id && !logins.includes(session.system_id)) {
      logins.push(session.system_id);
    }
    if (session.host && !hosts.includes(session.host)) {
      hosts.push(session.host);
    }
    if (session.bound_seconds != null) {
      ages.push(session.bound_seconds);
    }
    if (session.tps_limit != null) {
      limits.add(session.tps_limit);
    }
    if (session.limit_source && session.limit_source !== "LOGIN_MAX_TPS") {
      sources.add(session.limit_source);
    }
    //null stays null until one session counts: "nothing counted" and "counted nothing" are
    //different readings, and the table draws them differently
    if (session.submitted != null) {
      received = (received ?? 0) + session.submitted;
    }
    if (session.receipts != null) {
      receipts = (receipts ?? 0) + session.receipts;
    }
    if (session.tps_measured != null) {
      tps = (tps ?? 0) + session.tps_measured;
    }
  }

  return {
    account,
    logins,
    sessions,
    counts,
    hosts,
    oldest: ages.length ? Math.max(...ages) : null,
    received,
    receipts,
    tps,
    tpsLimit: limits.size === 1 ? [...limits][0] : null,
    limitSource: sources.size === 1 ? [...sources][0] : null,
  };
}

/** A ceiling and the setting it came from, when the gateway says (0.15.1+). */
export interface SessionCeiling {
  value: number;
  source: LimitSource | null;
}

/**
 * The ceiling one session is held to: its login's own `max_tps` when the gateway says that is the
 * one that binds, else the account's (`tps_limit`). Null when unlimited or not reported.
 */
export function sessionCeiling(
  s: Pick<HealthSession, "tps_limit" | "login_tps_limit" | "limit_source">
): SessionCeiling | null {
  if (s.limit_source === "UNLIMITED") {
    return null;
  }
  if (s.limit_source === "LOGIN_MAX_TPS" && s.login_tps_limit != null) {
    return { value: s.login_tps_limit, source: "LOGIN_MAX_TPS" };
  }
  return s.tps_limit != null ? { value: s.tps_limit, source: s.limit_source ?? null } : null;
}

/** The pill's word for each source: short enough to sit beside the number in a table cell. */
export const SOURCE_WORDS: Record<LimitSource, string | null> = {
  ACCOUNT_OVERRIDE: "override",
  LOGIN_MAX_TPS: "login",
  LISTENER_DEFAULT: "default",
  PORT_SHARE: "share",
  UNLIMITED: null,
};

/** "≤250 · override", "≤50 · login", or the bare "≤250" from a gateway before 0.15.1. */
export function ceilingLabel(c: SessionCeiling): string {
  const word = c.source ? SOURCE_WORDS[c.source] : null;
  return word ? `≤${formatTps(c.value)} · ${word}` : `≤${formatTps(c.value)}`;
}

/**
 * A listener's sessions folded one step further: by account <b>and</b> login.
 *
 * <p>The listener Status tab's row. An account ceiling is shared by every login of the account, but
 * a login is what a customer's engineer configures and what a `max_tps` narrows, so "which of my
 * three logins is sending the traffic" needs a row per login, not one per account.
 */
export interface LoginGroup {
  /** {@link loginKey} of the two below: what the live rates are folded by. */
  key: string;
  account: string;
  /** The system id, or "—" for a session that reported none. */
  systemId: string;
  sessions: HealthSession[];
  /** Bound sessions: what the Binds column counts. */
  binds: number;
  /** Distinct source addresses, in first-seen order. */
  hosts: string[];
  /** The most recently bound session's age in seconds: how long the login has been fully up. */
  youngest: number | null;
  /** submit_sm received across the counting sessions; null when none of them counts. */
  submitted: number | null;
  receipts: number | null;
  /** The gateway's own measured rate, summed; the fallback when no delta can be taken. */
  tps: number | null;
  /** The account ceiling the sessions report, when they agree; null otherwise. */
  tpsLimit: number | null;
  /** The login's own `max_tps`, when the gateway reports it (0.15.1+). */
  loginTpsLimit: number | null;
  /** Which limit binds, when the gateway reports it and the sessions agree (0.15.1+). */
  limitSource: LimitSource | null;
  /**
   * What the sessions are, as one string: their ids, sorted. Two readings whose members differ are
   * not comparable as a counter -- a bind came or went between them -- so the rate fold falls back
   * to the gateway's own measurement for that poll.
   */
  members: string;
}

/** The separator inside a {@link loginKey}: a control character no account or system id carries. */
const KEY_SEP = "\u001f";

/** The key one account × login is folded and charted by. */
export function loginKey(account: string, systemId: string): string {
  return `${account}${KEY_SEP}${systemId}`;
}

/** The account half of a {@link loginKey}. */
export function accountOfKey(key: string): string {
  const at = key.indexOf(KEY_SEP);
  return at < 0 ? key : key.slice(0, at);
}

/** The login half of a {@link loginKey}. */
export function loginOfKey(key: string): string {
  const at = key.indexOf(KEY_SEP);
  return at < 0 ? "" : key.slice(at + 1);
}

/**
 * Fold sessions by account × login, busiest first by the gateway's measured rate, then by what was
 * submitted, then by name -- so the order holds still from poll to poll.
 */
export function groupByLogin(sessions: readonly HealthSession[]): LoginGroup[] {
  const byKey = new Map<string, HealthSession[]>();
  for (const session of sessions) {
    const key = loginKey(session.account?.trim() || UNATTRIBUTED, session.system_id?.trim() || UNATTRIBUTED);
    const list = byKey.get(key);
    if (list) {
      list.push(session);
    } else {
      byKey.set(key, [session]);
    }
  }
  return [...byKey.entries()]
    .map(([key, rows]) => loginGroupOf(key, rows))
    .sort((a, b) =>
      (b.tps ?? -1) - (a.tps ?? -1)
      || (b.submitted ?? -1) - (a.submitted ?? -1)
      || a.key.localeCompare(b.key));
}

function loginGroupOf(key: string, sessions: HealthSession[]): LoginGroup {
  const hosts: string[] = [];
  const ages: number[] = [];
  const ids: string[] = [];
  const limits = new Set<number>();
  const loginLimits = new Set<number>();
  const sources = new Set<LimitSource>();
  let binds = 0;
  let submitted: number | null = null;
  let receipts: number | null = null;
  let tps: number | null = null;

  for (const session of sessions) {
    if (session.bound) {
      binds += 1;
    }
    if (session.host && !hosts.includes(session.host)) {
      hosts.push(session.host);
    }
    if (session.bound_seconds != null) {
      ages.push(session.bound_seconds);
    }
    //the listener's own session number when there is one; otherwise the far end, which is as
    //unique as anything a session without a number offers
    ids.push(session.session_id != null ? String(session.session_id) : `${session.host ?? ""}:${session.port ?? ""}`);
    if (session.tps_limit != null) {
      limits.add(session.tps_limit);
    }
    if (session.login_tps_limit != null) {
      loginLimits.add(session.login_tps_limit);
    }
    if (session.limit_source) {
      sources.add(session.limit_source);
    }
    //the same null rule as the account fold: "nothing counted" is not "counted nothing"
    if (session.submitted != null) {
      submitted = (submitted ?? 0) + session.submitted;
    }
    if (session.receipts != null) {
      receipts = (receipts ?? 0) + session.receipts;
    }
    if (session.tps_measured != null) {
      tps = (tps ?? 0) + session.tps_measured;
    }
  }

  return {
    key,
    account: accountOfKey(key),
    systemId: loginOfKey(key),
    sessions,
    binds,
    hosts,
    youngest: ages.length ? Math.min(...ages) : null,
    submitted,
    receipts,
    tps,
    tpsLimit: limits.size === 1 ? [...limits][0] : null,
    loginTpsLimit: loginLimits.size === 1 ? [...loginLimits][0] : null,
    limitSource: sources.size === 1 ? [...sources][0] : null,
    members: ids.sort().join(","),
  };
}

/** Every bind of every group, for a listener-wide total row. */
export function overall(groups: readonly AccountGroup[]): AccountGroup {
  return groupOf("Overall", groups.flatMap((g) => g.sessions));
}

/** The binds of a group as the table summarises them: `2 TX · 2 RX`, then `1 not bound` if any. */
export function bindSummary(counts: BindCounts): string {
  const parts = (["TX", "RX", "TRX"] as const)
    .filter((kind) => counts[kind] > 0)
    .map((kind) => `${counts[kind]} ${kind}`);
  if (counts.unbound > 0) {
    parts.push(`${counts.unbound} not bound`);
  }
  return parts.join(" · ");
}

/** Receipts as a share of what was submitted; null until something was submitted. */
export function receiptRate(group: Pick<AccountGroup, "received" | "receipts">): number | null {
  if (group.received == null || group.receipts == null || group.received <= 0) {
    return null;
  }
  return group.receipts / group.received;
}

/** The source addresses as the account row shows them: the first, and how many more. */
export function hostsLabel(hosts: readonly string[]): string {
  if (!hosts.length) {
    return "—";
  }
  return hosts.length === 1 ? hosts[0] : `${hosts[0]} +${hosts.length - 1}`;
}
