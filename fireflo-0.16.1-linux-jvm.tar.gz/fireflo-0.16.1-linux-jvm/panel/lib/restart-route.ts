import { COMPONENT_RESTART as COMPONENT_RESTART_CAPABILITY, hasCapability } from "./capabilities.ts";
import type { ConfigChange } from "./config-change.ts";
import type { GqlCall, GqlOutcome } from "./gateway-graphql-core.ts";
import { COMPONENT_RESTART, HEALTH_API } from "./gateway-queries.ts";
import type { Health } from "./health-types.ts";
import { ADMIN_ROLE } from "./roles.ts";
import {
  RESTART_UNSUPPORTED,
  parseRestartResult,
  readRestartRequest,
  restartAuditName,
  restartVariables,
  type RestartResult,
} from "./gateway-restart.ts";

/**
 * What `POST /api/control/restart` does, with the gateway call passed in so it can be tested
 * without one (the `lib/cdr-storage-route.ts` pattern). The route adds the session and the audit.
 *
 * <p>In order: an admin, or 404 -- the house rule for admin-only routes (`queues/clean`,
 * `requireAdmin`): an operator who is not one learns nothing about the route, and the Queues page
 * shows them no Restart rows anyway; the body checked ({@link readRestartRequest}), 400 with the reason; the capability map, 409
 * when the gateway does not advertise `component_restart` (an older gateway would reject the field
 * by name, which reads as a fault); then the mutation with the admin token, its refusals passed
 * through at the gateway's status with its sentence (BAD_REQUEST 400, NOT_FOUND 404, CONFLICT 409).
 */

/** The gateway call: `executeGql` in the route. */
export type RestartExecutor = <T>(call: GqlCall) => Promise<GqlOutcome<T>>;

/** The signed-in operator, as `requireOperator` answers it. */
export interface RestartOperator {
  name: string;
  role: string;
}

export type RestartOutcome =
  | { status: 200; body: { data: RestartResult }; audit: ConfigChange }
  | { status: number; body: { error: string; code?: string }; audit?: undefined };

/**
 * Persist drains each stream for up to ten seconds and there are three; a vendor rebind waits for
 * the vendor. A minute leaves room for both without letting a stuck gateway hold the dialog open.
 */
export const RESTART_TIMEOUT_MS = 60_000;

export async function runRestart(exec: RestartExecutor, operator: RestartOperator, raw: unknown): Promise<RestartOutcome> {
  if (operator.role !== ADMIN_ROLE) {
    return { status: 404, body: { error: "Not found", code: "NOT_FOUND" } };
  }
  const read = readRestartRequest(raw);
  if (!read.ok) {
    return { status: 400, body: { error: read.error, code: "BAD_REQUEST" } };
  }
  const { request } = read;

  const health = await exec<{ api?: Record<string, boolean> | null }>({ query: HEALTH_API, timeoutMs: 5_000 });
  if (!health.ok) {
    return { status: health.status, body: { error: health.error, code: health.code } };
  }
  if (!hasCapability({ api: health.data?.api ?? null } as Health, COMPONENT_RESTART_CAPABILITY)) {
    return { status: 409, body: { error: RESTART_UNSUPPORTED, code: "UNSUPPORTED" } };
  }

  const answer = await exec<unknown>({
    query: COMPONENT_RESTART,
    variables: restartVariables(request, operator.name),
    auth: "admin",
    timeoutMs: RESTART_TIMEOUT_MS,
    //a refusal is addressed to the operator ("another restart of persist is already running"), so
    //its sentence and status are what the button shows, not a flattened 502
    passErrors: true,
  });
  if (!answer.ok) {
    return { status: answer.status, body: { error: answer.error, code: answer.code } };
  }
  const result = parseRestartResult(answer.data);
  return {
    status: 200,
    body: { data: result },
    audit: {
      domain: "component",
      name: restartAuditName(request),
      action: "action:restart",
      after: {
        component: request.component,
        target: request.target,
        hard: request.hard,
        ok: result.ok,
        tookMs: result.tookMs,
        detail: result.detail,
      },
    },
  };
}
