import { signinLockout } from "./signin-lockout.ts";

/**
 * Failed operator sign-ins and authenticator codes, counted together and apart from the portal's
 * (lib/signin-lockout.ts). One counter for the password, the second step and the two-factor screens'
 * code checks, so a code cannot be guessed faster by spreading the guesses over them.
 */
export const operatorLockout = signinLockout();
