import { test } from "node:test";
import assert from "node:assert/strict";
import {
  addDays,
  dayKeyIn,
  dayStartIn,
  formatChartLabel,
  formatClock,
  formatClockTime,
  formatDate,
  formatDay,
  formatDayMonth,
  formatHour,
  formatHourSpan,
  formatMoment,
  formatMonth,
  formatTimestamp,
  instantToWallTime,
  isUtcZone,
  parseZoneCookie,
  resolveDisplayZone,
  wallTimeToInstant,
  zoneCookieValue,
  zoneLabel,
  zoneOffsetMinutes,
  zoneShortName,
  parseInstantParam,
} from "./datetime.ts";

/**
 * The panel's one set of date formats, now in a named zone and a fixed locale (en-GB, 24-hour), so
 * these pin literal strings: the output no longer depends on the host's zone or locale.
 */

const AT = "2026-08-15T09:02:07.441Z";
const KOLKATA = "Asia/Kolkata";
const NY = "America/New_York";

test("nothing to format renders as nothing, not as the word null", () => {
  for (const empty of [null, undefined, ""]) {
    assert.equal(formatTimestamp(empty, "UTC"), "");
    assert.equal(formatClockTime(empty, "UTC"), "");
    assert.equal(formatDate(empty, "UTC"), "");
    assert.equal(formatHour(empty, "UTC"), "");
  }
});

test("a value that is not a date shows what is stored, not 'Invalid Date'", () => {
  assert.equal(formatTimestamp("not a date", "UTC"), "not a date");
  assert.equal(formatClockTime("not a date", "UTC"), "not a date");
  assert.equal(formatDate("not a date", "UTC"), "not a date");
  assert.equal(formatDay("not a day"), "not a day");
});

test("a timestamp in UTC, India and New York", () => {
  assert.equal(formatTimestamp(AT, "UTC"), "15 Aug 2026 09:02:07");
  assert.equal(formatTimestamp(AT, KOLKATA), "15 Aug 2026 14:32:07");
  assert.equal(formatTimestamp(AT, NY), "15 Aug 2026 05:02:07");
});

test("a Date, an ISO string and epoch milliseconds format identically", () => {
  const at = new Date(AT);
  assert.equal(formatTimestamp(at, KOLKATA), formatTimestamp(AT, KOLKATA));
  assert.equal(formatTimestamp(at.getTime(), KOLKATA), formatTimestamp(AT, KOLKATA));
});

test("the date is the zone's date, which is not always UTC's", () => {
  //20:00 UTC on the 15th is already the 16th in India
  assert.equal(formatDate("2026-08-15T20:00:00Z", "UTC"), "15 Aug 2026");
  assert.equal(formatDate("2026-08-15T20:00:00Z", KOLKATA), "16 Aug 2026");
  assert.equal(formatDayMonth("2026-08-15T20:00:00Z", KOLKATA), "16 Aug");
});

test("an unknown zone falls back to UTC rather than throwing", () => {
  assert.equal(formatTimestamp(AT, "Not/AZone"), "15 Aug 2026 09:02:07");
});

test("the clock time is just the clock today, the full stamp otherwise -- today in the zone", () => {
  const now = "2026-08-15T20:00:00Z";
  assert.equal(formatClockTime("2026-08-15T19:00:00Z", "UTC", now), "19:00:00");
  //in India 19:00Z on the 15th is 00:30 on the 16th, and now is 01:30 on the 16th: still today
  assert.equal(formatClockTime("2026-08-15T19:00:00Z", KOLKATA, now), "00:30:00");
  //18:00Z is 23:30 on the 15th in India: yesterday there, though today in UTC
  assert.equal(formatClockTime("2026-08-15T18:00:00Z", KOLKATA, now), "15 Aug 2026 23:30:00");
  assert.equal(formatClockTime("2026-08-15T18:00:00Z", "UTC", now), "18:00:00");
});

test("a bare clock, with and without seconds and milliseconds", () => {
  assert.equal(formatClock(AT, KOLKATA), "14:32:07");
  assert.equal(formatClock(AT, KOLKATA, { seconds: false }), "14:32");
  assert.equal(formatClock(AT, KOLKATA, { millis: true }), "14:32:07.441");
});

test("a short moment drops the date on the same day in the zone", () => {
  assert.equal(formatMoment(AT, "UTC", "2026-08-15T12:00:00Z"), "09:02");
  assert.equal(formatMoment(AT, "UTC", "2026-08-16T12:00:00Z"), "15 Aug 09:02");
});

test("an hour bucket is labelled by its start in the zone: :30 in India", () => {
  const hour = "2026-08-15T09:00:00Z";
  assert.equal(formatHour(hour, "UTC"), "09:00");
  assert.equal(formatHour(hour, KOLKATA), "14:30");
  assert.equal(formatHour(hour, NY), "05:00");
  assert.equal(formatHourSpan(hour, KOLKATA), "15 Aug 14:30–15:30 IST");
  assert.equal(formatHourSpan(hour, "UTC"), "15 Aug 09:00–10:00 UTC");
  assert.equal(formatHourSpan("2026-08-15T09:05:00Z", "UTC", 5), "15 Aug 09:05–09:10 UTC");
});

test("a day key is labelled as itself, never shifted by a zone", () => {
  assert.equal(formatDay("2026-10-31"), "31 Oct");
  assert.equal(formatDay("2026-10-31", { year: true }), "31 Oct 2026");
  assert.equal(formatDay("2026-01-01"), "1 Jan");
  assert.equal(formatMonth(2026, 10), "October 2026");
});

test("a chart label: a day key as a day, an instant in the zone, text as text", () => {
  assert.equal(formatChartLabel("2026-10-31", KOLKATA), "31 Oct 2026");
  assert.equal(formatChartLabel("2026-08-15T09:00:00Z", KOLKATA), "15 Aug 14:30 IST");
  assert.equal(formatChartLabel(Date.parse("2026-08-15T09:00:00Z"), "UTC"), "15 Aug 09:00 UTC");
  assert.equal(formatChartLabel("vendor-a", "UTC"), "vendor-a");
  assert.equal(formatChartLabel(undefined, "UTC"), "");
});

test("short zone names: UTC, IST, and New York's two", () => {
  assert.equal(zoneShortName("UTC"), "UTC");
  assert.equal(zoneShortName("Etc/UTC"), "UTC");
  assert.equal(zoneShortName(KOLKATA), "IST");
  assert.equal(zoneShortName(NY, "2026-08-15T12:00:00Z"), "EDT");
  assert.equal(zoneShortName(NY, "2026-12-15T12:00:00Z"), "EST");
  assert.equal(zoneLabel(KOLKATA), "IST · Asia/Kolkata");
  assert.equal(zoneLabel("UTC"), "UTC");
  assert.ok(isUtcZone("Etc/GMT"));
  assert.ok(!isUtcZone("Europe/London"));
});

test("offsets, including both sides of New York's November change", () => {
  assert.equal(zoneOffsetMinutes("UTC", AT), 0);
  assert.equal(zoneOffsetMinutes(KOLKATA, AT), 330);
  //2026-11-01 06:00Z is 02:00 EDT -> 01:00 EST
  assert.equal(zoneOffsetMinutes(NY, "2026-11-01T05:59:00Z"), -240);
  assert.equal(zoneOffsetMinutes(NY, "2026-11-01T06:00:00Z"), -300);
});

test("day keys in a zone", () => {
  assert.equal(dayKeyIn("2026-08-15T20:00:00Z", "UTC"), "2026-08-15");
  assert.equal(dayKeyIn("2026-08-15T20:00:00Z", KOLKATA), "2026-08-16");
  assert.equal(dayKeyIn("2026-08-15T02:00:00Z", NY), "2026-08-14");
  assert.equal(addDays("2026-10-31", 1), "2026-11-01");
  assert.equal(addDays("2026-03-01", -1), "2026-02-28");
});

test("a wall time typed in a zone is the instant it names", () => {
  assert.equal(wallTimeToInstant("2026-10-31T15:00", "UTC")?.toISOString(), "2026-10-31T15:00:00.000Z");
  assert.equal(wallTimeToInstant("2026-10-31T15:00", KOLKATA)?.toISOString(), "2026-10-31T09:30:00.000Z");
  assert.equal(wallTimeToInstant("2026-10-31 15:00:30", NY)?.toISOString(), "2026-10-31T19:00:30.000Z");
  assert.equal(wallTimeToInstant("2026-12-01T09:00", NY)?.toISOString(), "2026-12-01T14:00:00.000Z");
  assert.equal(wallTimeToInstant("2026-10-31", KOLKATA)?.toISOString(), "2026-10-30T18:30:00.000Z");
  assert.equal(wallTimeToInstant("yesterday", "UTC"), null);
});

test("the DST edges: a repeated hour is its first occurrence, a skipped one lands after the change", () => {
  //01:30 on 2026-11-01 happens twice in New York; the first is EDT
  assert.equal(wallTimeToInstant("2026-11-01T01:30", NY)?.toISOString(), "2026-11-01T05:30:00.000Z");
  //02:30 on 2026-03-08 never happens; read with EST it is 07:30Z, which the clock shows as 03:30 EDT
  assert.equal(wallTimeToInstant("2026-03-08T02:30", NY)?.toISOString(), "2026-03-08T07:30:00.000Z");
  //either side of the change are ordinary
  assert.equal(wallTimeToInstant("2026-03-08T01:30", NY)?.toISOString(), "2026-03-08T06:30:00.000Z");
  assert.equal(wallTimeToInstant("2026-03-08T03:30", NY)?.toISOString(), "2026-03-08T07:30:00.000Z");
  //and a New York day across the change is 23 hours
  const start = dayStartIn("2026-03-08", NY)!.getTime();
  const next = dayStartIn("2026-03-09", NY)!.getTime();
  assert.equal((next - start) / 3_600_000, 23);
});

test("an instant as a datetime-local value round-trips", () => {
  assert.equal(instantToWallTime("2026-10-31T09:30:00Z", KOLKATA), "2026-10-31T15:00");
  assert.equal(instantToWallTime("2026-10-31T09:30:05Z", KOLKATA, { seconds: true }), "2026-10-31T15:00:05");
  for (const zone of ["UTC", KOLKATA, NY]) {
    const wall = "2026-07-04T08:15";
    assert.equal(instantToWallTime(wallTimeToInstant(wall, zone), zone), wall);
  }
});

test("the display zone a mode resolves to", () => {
  assert.equal(resolveDisplayZone("platform", KOLKATA, NY), KOLKATA);
  assert.equal(resolveDisplayZone("browser", KOLKATA, NY), NY);
  assert.equal(resolveDisplayZone("browser", KOLKATA, null), KOLKATA, "not yet known: the platform's");
  assert.equal(resolveDisplayZone("utc", KOLKATA, NY), "UTC");
  assert.equal(resolveDisplayZone("platform", "Bogus/Zone", null), "UTC");
});

test("the cookie round-trips, and nonsense in it is the default", () => {
  assert.deepEqual(parseZoneCookie(zoneCookieValue("browser", NY)), { mode: "browser", browserZone: NY });
  assert.deepEqual(parseZoneCookie(encodeURIComponent(zoneCookieValue("browser", NY))), { mode: "browser", browserZone: NY });
  assert.deepEqual(parseZoneCookie("utc"), { mode: "utc", browserZone: null });
  assert.deepEqual(parseZoneCookie("browser:Not/AZone"), { mode: "browser", browserZone: null });
  assert.deepEqual(parseZoneCookie(undefined), { mode: "platform", browserZone: null });
  assert.deepEqual(parseZoneCookie("<script>"), { mode: "platform", browserZone: null });
});

test("a query parameter with no zone is UTC, whatever the host's zone", () => {
  assert.equal(parseInstantParam("2026-10-31T15:00")?.toISOString(), "2026-10-31T15:00:00.000Z");
  assert.equal(parseInstantParam("2026-10-31")?.toISOString(), "2026-10-31T00:00:00.000Z");
  assert.equal(parseInstantParam("2026-10-31T15:00:00+05:30")?.toISOString(), "2026-10-31T09:30:00.000Z");
  assert.equal(parseInstantParam("2026-10-31T09:30:00.000Z")?.toISOString(), "2026-10-31T09:30:00.000Z");
  assert.equal(parseInstantParam("soon"), null);
  assert.equal(parseInstantParam(""), null);
});
