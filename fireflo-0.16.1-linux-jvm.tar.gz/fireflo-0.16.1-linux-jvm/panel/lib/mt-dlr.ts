import { localeNumber } from "./format.ts";

/**
 * The MT/DLR pair on the Servers and Vendors cards (gateway 0.15.2, health `workers[].receipts`,
 * capability `worker_receipts`).
 *
 * <p>`submitted` is the MT side: what customers sent us on a listener, what we sent the vendor on a
 * vendor. `receipts` is the DLR side: receipts we sent back to customers on a listener, receipts the
 * vendor sent us on a vendor. `submitted` is summed over the current sessions (a replaced bind starts
 * again); `receipts` counts since the gateway started. An older gateway omits
 * `receipts`, which reads as a dash with a hover saying why -- never as 0, which would claim no
 * receipts are coming back.
 */

/** The hover on a dash where the gateway does not report receipts. */
export const RECEIPTS_NEED_GATEWAY = "DLR count needs gateway 0.15.2";

/** A count, or a dash when the gateway did not report it. */
export function countOrDash(value: number | null | undefined): string {
  return value != null ? localeNumber(value) : "—";
}

/** The title on the DLR figure: why it is a dash, or nothing when there is a number. */
export function receiptsTitle(receipts: number | null | undefined): string | undefined {
  return receipts == null ? RECEIPTS_NEED_GATEWAY : undefined;
}

/** The closed worker card's header: `12,000 MT · 11,980 DLR`, `12,000 MT · — DLR` on an older gateway. */
export function mtDlrShort(submitted: number | null | undefined, receipts: number | null | undefined): string {
  return `${countOrDash(submitted)} MT · ${countOrDash(receipts)} DLR`;
}
