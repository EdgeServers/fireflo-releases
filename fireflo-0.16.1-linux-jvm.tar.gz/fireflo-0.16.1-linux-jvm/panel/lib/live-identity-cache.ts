/**
 * A short memory of "is this signed-in person still allowed in?", so a slow database does not take
 * the live pages down with it.
 *
 * <p>Every operator request re-reads the person's `app_user` row (role, enabled, the password and
 * authenticator stamps) before it does anything else -- see lib/require-operator.ts. That read is
 * the right security rule: a disabled user or a changed password is refused on the next request,
 * not at the next sign-in. It is also the one PostgreSQL read in front of every page, including
 * the pages whose data comes from the gateway's GraphQL API and touches no table at all. On the
 * 0.15.1 rc7 bench (2026-10-30) the staging database spent 10-20 s at a time refusing new work;
 * the health, Status and Connectivity pages, which read only the gateway, sat behind this one
 * query's 5 s connection wait and 10 s statement timeout and the panel looked dead for a minute at a
 * time.
 *
 * <p>So the answer is remembered per user for {@link FRESH_MS}: within that window no read is made.
 * Past it the row is read again; if that read FAILS -- a timeout, a pool that has no connection to
 * give -- the last answer is served for up to {@link STALE_MS} more, and the failure is logged once
 * per user per window. A read that succeeds always replaces the memory, and a change made through
 * this panel process (password, enabled, role, authenticator) calls {@link forgetLiveIdentity} so it
 * applies on the very next request as before. A change made elsewhere (the CLI, another panel
 * process) applies within {@link FRESH_MS}, or within {@link STALE_MS} while the database is not
 * answering -- the window during which no sign-in could be made either.
 *
 * <p>A null answer (no such row) is remembered too: a deleted user is refused on every request,
 * and the read that proved it is not repeated 20 times a second by a page that keeps polling.
 */

export const FRESH_MS = 5_000;
export const STALE_MS = 60_000;

interface Entry<T> {
  value: T;
  readAt: number;
  failedLoggedAt: number;
}

const entries = new Map<string, Entry<unknown>>();

export interface LiveIdentityOptions {
  freshMs?: number;
  staleMs?: number;
  now?: () => number;
  onStale?: (key: string, error: unknown, ageMs: number) => void;
}

/**
 * The remembered answer for {@code key} when it is fresh; otherwise {@code read()}'s, remembered;
 * otherwise, when the read fails and a stale answer is still within {@link STALE_MS}, that answer.
 * A read that fails with nothing to fall back on throws as it always did.
 */
export async function liveIdentity<T>(key: string, read: () => Promise<T>, options: LiveIdentityOptions = {}): Promise<T> {
  const freshMs = options.freshMs ?? FRESH_MS;
  const staleMs = options.staleMs ?? STALE_MS;
  const now = options.now ?? Date.now;
  const t = now();
  const have = entries.get(key) as Entry<T> | undefined;
  if (have && t - have.readAt < freshMs) {
    return have.value;
  }
  try {
    const value = await read();
    entries.set(key, { value, readAt: t, failedLoggedAt: 0 });
    return value;
  } catch (error) {
    if (have && t - have.readAt < staleMs) {
      if (t - have.failedLoggedAt >= freshMs) {
        have.failedLoggedAt = t;
        (options.onStale ?? defaultOnStale)(key, error, t - have.readAt);
      }
      return have.value;
    }
    throw error;
  }
}

/** Drops the memory for one key: call after this process changed the person's row. */
export function forgetLiveIdentity(key: string): void {
  entries.delete(key);
}

/** Drops every memory: tests, and a sign-out of everyone (a password-stamp change for all). */
export function forgetAllLiveIdentities(): void {
  entries.clear();
}

export function operatorKey(userId: number): string {
  return `operator:${userId}`;
}

function defaultOnStale(key: string, error: unknown, ageMs: number): void {
  const reason = error instanceof Error ? error.message : String(error);
  console.warn(`live identity for ${key} could not be re-read (${reason}); serving the answer from ${Math.round(ageMs / 1000)} s ago`);
}
