import { failureBody, missingAfter, type GatewayFailureBody } from "./gateway-slow.ts";
import type { LiveBucket, LiveGrain, LiveGroup, LiveSeriesSum } from "./gateway-live-series.ts";
import { formatClock } from "./datetime.ts";

/**
 * MT and DLR counts for the Connectivity map, from memory only (0.15.1).
 *
 * <p>The map shows how much has flowed, not only how fast, over one of two windows the page offers:
 *
 * <ul>
 *   <li><b>Last hour</b> -- the gateway's in-memory live series (capability `live_series`):
 *       `liveSeries(range: H1, grain: HOUR)` summed across the cluster, once grouped
 *       `[LISTENER, ACCOUNT]` for the client and listener boxes and once `[VENDOR, ACCOUNT]` for the
 *       vendor boxes (the vendor family knows the vendor and the account only). On the listener side
 *       MT is `submitted` and DLR `delivered + failed`, the outcomes the ledger holds for the hour;
 *       on the vendor side MT is `sent` (what the vendor took) and DLR `delivered + failed` (the
 *       receipts it reported). H1 is the minute in progress and the sixty before it, so the hour
 *       bins together are the whole window. A bucket the gateway marks `backfilled` -- after a
 *       restart, a whole hour from `usage_hourly` folded into its first minute -- is skipped, so a
 *       restart inside the window never inflates the counts; the page then names the window
 *       "since restart HH:MM" ({@link hourWindowLabel}).</li>
 *   <li><b>Since bind</b> -- the session counters the page already polls (`submitted` and
 *       `receipts`, folded by `lib/live-sessions.ts`) and each vendor worker's `submitted`. The only
 *       window on a gateway without `live_series`.</li>
 * </ul>
 *
 * <p><b>Refused at the door.</b> Whichever window is shown, the route also asks
 * `liveSeries(range: H1, grain: MINUTE, groupBy: [LISTENER])` and keeps the last <i>full</i> minute
 * -- the one before the minute in progress, found from the nodes' `until` -- per listener: `refused`
 * and its `refusedBy` reasons. The map draws each refusing port's edge back to its clients at
 * `refused / 60` a second ({@link listenerRefusal}). A failure of that one query leaves the
 * refusals empty and the counts standing.
 *
 * <p>No PostgreSQL read either way. This file is the last-hour half's adapter: the operator route
 * (`app/api/control/connectivity/counts`) is {@link readConnectivityCounts} with the gateway calls
 * passed in, so it is tested here without Next or a gateway.
 */

/** Which window the counts cover. */
export type CountsWindow = "hour" | "bind";

/** How the tooltips, the focus readout and the control name each window. */
export const COUNTS_WINDOW_LABEL: Record<CountsWindow, string> = { hour: "last hour", bind: "since bind" };

/** One box's two counts. */
export interface CountPair {
  mt: number;
  dlr: number;
}

/** One listener × account over the hour. `listener` is the instance name (no `smppserver.`). */
export interface ListenerCountRow extends CountPair {
  listener: string;
  account: string | null;
}

/** One vendor over the hour, every account summed. `vendor` is the instance name (no `smppclient.`). */
export interface VendorCountRow extends CountPair {
  vendor: string;
}

/** One reason and how many submits it refused. */
export interface ReasonCount {
  reason: string;
  count: number;
}

/** One listener's refusals over the last full minute, its reasons summed across the cluster, most first. */
export interface ListenerRefusalRow {
  listener: string;
  refused: number;
  by: ReasonCount[];
}

/** A listener's refusals as the map draws them: the minute's count a second. */
export interface ListenerRefusal {
  /** `refused / 60`. */
  rate: number;
  /** The minute's count. */
  total: number;
  by: ReasonCount[];
}

export interface ConnectivityCounts {
  listeners: ListenerCountRow[];
  vendors: VendorCountRow[];
  /** Refused at the door per listener over {@link refusalsMinute}; empty when unknown. */
  refusals: ListenerRefusalRow[];
  /** The start of the minute the refusals are from, ISO; null when the minute series was not read. */
  refusalsMinute: string | null;
  /** The nodes whose memory is in the sums, and the alive ones that did not answer. */
  nodes: string[];
  partial: string[];
  /** The latest node restart: before it, the hour is short by that node's share. */
  liveSince: string | null;
  /** Backfilled buckets left out of the sums; above zero, the window really starts at the restart. */
  skippedBackfill: number;
  /** When counting restarted (`liveSince`, else how far the backfill reached); null when unknown. */
  restartedAt: string | null;
}

/** The two groupings asked, one per side of the map. */
export const LISTENER_GROUPING: readonly LiveGroup[] = ["LISTENER", "ACCOUNT"];
export const VENDOR_GROUPING: readonly LiveGroup[] = ["VENDOR", "ACCOUNT"];
/** The refusals' grouping, asked in minute bins. */
export const REFUSAL_GROUPING: readonly LiveGroup[] = ["LISTENER"];

const MINUTE_MS = 60_000;

/**
 * The start (ms) of the last full minute: the one before the minute in progress. The nodes' `until`
 * is the end of the minute in progress; without it the panel's clock stands in.
 */
export function lastFullMinute(series: Pick<LiveSeriesSum, "until"> | null | undefined, now: number): number {
  const until = series?.until ? Date.parse(series.until) : NaN;
  const current = Number.isFinite(until)
    ? Math.floor((until - 1) / MINUTE_MS) * MINUTE_MS
    : Math.floor(now / MINUTE_MS) * MINUTE_MS;
  return current - MINUTE_MS;
}

/** The last full minute's refusals per listener, from `liveSeries(H1, MINUTE, [LISTENER])`. */
export function toRefusals(series: LiveSeriesSum, now: number): { rows: ListenerRefusalRow[]; minute: string } {
  const at = lastFullMinute(series, now);
  const out = new Map<string, { refused: number; by: Map<string, number> }>();
  for (const b of series.buckets) {
    //a backfilled bucket is a whole hour folded into one minute; REST traffic has no listener
    if (b.backfilled || !b.keys.listener || Date.parse(b.bucket) !== at) {
      continue;
    }
    const name = instanceName(b.keys.listener, "smppserver");
    const acc = out.get(name) ?? { refused: 0, by: new Map<string, number>() };
    acc.refused += nonNegative(b.refused);
    for (const r of b.refusedBy) {
      acc.by.set(r.reason, (acc.by.get(r.reason) ?? 0) + nonNegative(r.count));
    }
    out.set(name, acc);
  }
  const rows = [...out.entries()]
    .filter(([, v]) => v.refused > 0)
    .map(([listener, v]) => ({
      listener,
      refused: v.refused,
      by: [...v.by.entries()]
        .filter(([, n]) => n > 0)
        .map(([reason, count]) => ({ reason, count }))
        .sort((x, y) => y.count - x.count || x.reason.localeCompare(y.reason)),
    }))
    .sort((x, y) => x.listener.localeCompare(y.listener));
  return { rows, minute: new Date(at).toISOString().replace(/\.\d{3}Z$/, "Z") };
}

/** One listener's refusals over the last full minute; null when it refused nothing or nothing is known. */
export function listenerRefusal(counts: ConnectivityCounts | null | undefined, listener: string): ListenerRefusal | null {
  const name = instanceName(listener, "smppserver");
  const row = (counts?.refusals ?? []).find((r) => r.listener === name);
  return row && row.refused > 0 ? { rate: row.refused / 60, total: row.refused, by: row.by } : null;
}

/** A series key without its worker-type prefix: `smppserver.dltsmpp` and `dltsmpp` are one listener. */
export function instanceName(key: string, prefix: "smppserver" | "smppclient"): string {
  return key.startsWith(`${prefix}.`) ? key.slice(prefix.length + 1) : key;
}

function nonNegative(n: number): number {
  return Number.isFinite(n) && n > 0 ? n : 0;
}

function fold<K extends string>(
  buckets: readonly LiveBucket[],
  keyOf: (b: LiveBucket) => K | null,
  mt: (b: LiveBucket) => number
): Map<K, CountPair> {
  const out = new Map<K, CountPair>();
  for (const b of buckets) {
    //a backfilled bucket is a whole hour in one minute: inside an H1 window it would overcount
    if (b.backfilled) {
      continue;
    }
    const k = keyOf(b);
    if (k == null) {
      continue;
    }
    const acc = out.get(k) ?? { mt: 0, dlr: 0 };
    acc.mt += nonNegative(mt(b));
    acc.dlr += nonNegative(b.delivered) + nonNegative(b.failed);
    out.set(k, acc);
  }
  return out;
}

/**
 * The series as the page's rows: per listener × account, per vendor, and -- given the minute
 * series -- each listener's refusals over the last full minute.
 */
export function toConnectivityCounts(
  listenerSeries: LiveSeriesSum,
  vendorSeries: LiveSeriesSum,
  minuteSeries: LiveSeriesSum | null = null,
  now: number = Date.now()
): ConnectivityCounts {
  const SEP = "\u001f";
  const byListener = fold(
    listenerSeries.buckets,
    //REST traffic has no listener: it has no box on the map either
    (b) => (b.keys.listener ? `${instanceName(b.keys.listener, "smppserver")}${SEP}${b.keys.account ?? ""}` : null),
    (b) => b.submitted
  );
  const byVendor = fold(
    vendorSeries.buckets,
    (b) => (b.keys.vendor ? instanceName(b.keys.vendor, "smppclient") : null),
    (b) => b.sent
  );
  const listeners: ListenerCountRow[] = [...byListener.entries()]
    .map(([k, c]) => {
      const at = k.indexOf(SEP);
      const account = k.slice(at + 1);
      return { listener: k.slice(0, at), account: account || null, ...c };
    })
    .sort((a, b) => a.listener.localeCompare(b.listener) || (a.account ?? "").localeCompare(b.account ?? ""));
  const vendors: VendorCountRow[] = [...byVendor.entries()]
    .map(([vendor, c]) => ({ vendor, ...c }))
    .sort((a, b) => a.vendor.localeCompare(b.vendor));
  const later = (a: string | null, b: string | null) => (!a ? b : !b ? a : a > b ? a : b);
  const skippedBackfill = [...listenerSeries.buckets, ...vendorSeries.buckets].filter((b) => b.backfilled).length;
  const liveSince = later(listenerSeries.liveSince, vendorSeries.liveSince);
  const refusals = minuteSeries ? toRefusals(minuteSeries, now) : null;
  return {
    listeners,
    vendors,
    refusals: refusals?.rows ?? [],
    refusalsMinute: refusals?.minute ?? null,
    nodes: [...new Set([...listenerSeries.nodes, ...vendorSeries.nodes])].sort(),
    partial: [...new Set([...listenerSeries.partial, ...vendorSeries.partial])].sort(),
    liveSince,
    skippedBackfill,
    restartedAt: liveSince ?? later(listenerSeries.backfilledThrough, vendorSeries.backfilledThrough),
  };
}

/**
 * How the page names the last-hour window: "last hour", or "since restart HH:MM" when backfilled
 * buckets were left out -- with the sentence the tooltips give for it.
 *
 * @param zone the display zone, for the clock time
 */
export function hourWindowLabel(counts: ConnectivityCounts | null, zone: string): { label: string; note: string | null } {
  if (!counts || counts.skippedBackfill <= 0) {
    return { label: COUNTS_WINDOW_LABEL.hour, note: null };
  }
  const at = counts.restartedAt ? new Date(counts.restartedAt) : null;
  const clock = at && !Number.isNaN(at.getTime()) ? formatClock(at, zone, { seconds: false }) : null;
  return {
    label: clock ? `since restart ${clock}` : "since restart",
    note: "The gateway restarted inside the hour and refilled it from the database as whole hours; "
      + "those are left out so the counts are not inflated, so they start at the restart.",
  };
}

/** What the route needs from the gateway, passed in so the logic is tested without one. */
export interface CountsDeps {
  /**
   * Whether the answering node may have `live_series`: false only once it said it has not. Never
   * asks the gateway before the read; asked again after a refused read, to tell a 204 from a 502.
   */
  available: () => Promise<boolean>;
  /** `liveSeries(H1, grain, groupBy)` across the cluster, summed. */
  series: (groupBy: readonly LiveGroup[], grain: LiveGrain) => Promise<LiveSeriesSum>;
  /** The clock, for the last full minute when no node says; `Date.now` by default. */
  now?: () => number;
}

export type CountsAnswer =
  | { status: 200; body: { data: ConnectivityCounts } }
  /** The gateway has no live series: the page offers "since bind" only. */
  | { status: 204 }
  | { status: 502; body: GatewayFailureBody };

/** The route's answer: the hour's counts and the minute's refusals, 204 without the capability, 502 when the gateway failed. */
export async function readConnectivityCounts(deps: CountsDeps): Promise<CountsAnswer> {
  try {
    if (!(await deps.available())) {
      return { status: 204 };
    }
    const [listenerSeries, vendorSeries, minuteSeries] = await Promise.all([
      deps.series(LISTENER_GROUPING, "HOUR"),
      deps.series(VENDOR_GROUPING, "HOUR"),
      //the refusals are an extra: their failure must not cost the counts
      deps.series(REFUSAL_GROUPING, "MINUTE").catch(() => null),
    ]);
    const now = (deps.now ?? Date.now)();
    return { status: 200, body: { data: toConnectivityCounts(listenerSeries, vendorSeries, minuteSeries, now) } };
  } catch (err) {
    if (await missingAfter(err, deps.available)) {
      return { status: 204 };
    }
    //`code: "SLOW"` for a gateway that is there but slow: the page keeps its last counts
    return { status: 502, body: failureBody(err) };
  }
}

/** The hour's counts for one listener, every account or one; null when the series has none for it. */
export function listenerHour(counts: ConnectivityCounts, listener: string, account?: string): CountPair | null {
  const name = instanceName(listener, "smppserver");
  return sumPairs(counts.listeners.filter((r) => r.listener === name && (account === undefined || (r.account ?? "—") === account)));
}

/** The hour's counts for one vendor; null when the series has none for it. */
export function vendorHour(counts: ConnectivityCounts, vendor: string): CountPair | null {
  const name = instanceName(vendor, "smppclient");
  return sumPairs(counts.vendors.filter((r) => r.vendor === name));
}

function sumPairs(rows: readonly CountPair[]): CountPair | null {
  return rows.length ? rows.reduce((a, r) => ({ mt: a.mt + r.mt, dlr: a.dlr + r.dlr }), { mt: 0, dlr: 0 }) : null;
}
