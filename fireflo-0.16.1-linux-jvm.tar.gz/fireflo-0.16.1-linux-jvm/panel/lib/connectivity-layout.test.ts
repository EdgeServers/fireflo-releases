import { strict as assert } from "node:assert";
import { test } from "node:test";
import {
  BOX_GAP, BOX_H, BOX_W, DATABASE_BOX_ID, DB_W, EMPTY_VIEW, databaseLines, databaseRefusing, databaseState, reasonMix, refusedLabel, MAX_PORTS, OTHER_PORTS, PAGE_SIZE, clientBoxId, countsText, dotCount, dotSpeed, edgeAt,
  edgePath, edgeWidth, figuresLine, focusSet, formatCount, fullCount, groupBoxId, hitIndex, hitTest, layoutMap, listenerBoxId, nodeBoxId, pointAt, polylineLength,
  LAG_WARN, QUEUE_SAMPLES, RISE_MIN, nodeState, queueTrend, searchMap, segmentCrosses, totalsText, vendorBoxId, vendorGroupBoxId,
  type ClientIn, type ListenerIn, type MapInput, type MapLayout, type MapView, type NodeIn, type NodeQueue, type QueueSample,
  type DatabaseIn, type VendorIn,
} from "./connectivity-layout.ts";
import type { ListenerRefusal } from "./connectivity-counts.ts";

function listener(name: string, over: Partial<ListenerIn> = {}): ListenerIn {
  return {
    id: `smppserver.${name}`, name, port: "22775", bound: 1, rate: 10, ceiling: null,
    live: true, error: false, held: false, suspended: false, node: "node-1", mt: null, dlr: null, ...over,
  };
}

function client(listenerName: string, account: string, over: Partial<ClientIn> = {}): ClientIn {
  return {
    key: account, account, ip: null, hosts: ["10.0.0.1"], logins: [account.toLowerCase()],
    listener: `smppserver.${listenerName}`, binds: 2, rate: 10, receiptRate: null, refusedRate: null, ceiling: null,
    mt: null, dlr: null, ...over,
  };
}

function vendor(name: string, over: Partial<VendorIn> = {}): VendorIn {
  return {
    id: `smppclient.${name}`, name, rate: 100, tpsLimit: null, bound: true, backlog: null,
    held: false, suspended: false, routed: true, node: "node-1", group: null, mt: null, dlr: null, ...over,
  };
}

function queue(over: Partial<NodeQueue> = {}): NodeQueue {
  return { router: 0, lag: 0, persist: 0, persistLagSeconds: 0, retry: 0, persistLagMax: 60, ...over };
}

const NODE: NodeIn = { id: "node-1", self: true, alive: true, backbone: "kafka", queue: queue(), trend: null };

function input(over: Partial<MapInput> = {}): MapInput {
  return {
    clients: [], listeners: [listener("dltsmpp")], nodes: [NODE], vendors: [vendor("jio")], kafka: true, countsWindow: "hour", ...over,
  };
}

function view(over: Partial<MapView> = {}): MapView {
  return { ...EMPTY_VIEW, ...over };
}

/** Fifty-five clients on one port, rates 1..55 so the busiest are known. */
function crowd(n = 55): ClientIn[] {
  return Array.from({ length: n }, (_, i) => client("dltsmpp", `A${String(i + 1).padStart(2, "0")}`, { rate: i + 1, binds: (i % 4) + 1 }));
}

const box = (layout: MapLayout, id: string) => layout.boxes.find((b) => b.id === id);
const tier = (layout: MapLayout, t: string) => layout.boxes.filter((b) => b.tier === t && !b.frame);

test("tier packing: one row per tier, fixed boxes a gap apart, bands top to bottom without overlap", () => {
  const layout = layoutMap(input({
    listeners: [listener("a"), listener("b"), listener("c")],
    vendors: [vendor("v1"), vendor("v2")],
  }));
  const ports = tier(layout, "listeners").sort((a, b) => a.rect.x - b.rect.x);
  assert.equal(ports.length, 3);
  for (const p of ports) {
    assert.equal(p.rect.w, BOX_W);
    assert.equal(p.rect.h, BOX_H);
    assert.equal(p.rect.y, ports[0].rect.y);
  }
  assert.equal(ports[1].rect.x - ports[0].rect.x, BOX_W + BOX_GAP);
  //bands in order, each below the last, every box inside its own band
  const order = layout.bands.map((b) => b.id);
  assert.deepEqual(order, ["clients", "listeners", "nodes", "vendors"]);
  for (let i = 1; i < layout.bands.length; i++) {
    assert.ok(layout.bands[i].rect.y > layout.bands[i - 1].rect.y + layout.bands[i - 1].rect.h);
  }
  for (const b of layout.boxes) {
    const band = layout.bands.find((t) => t.id === b.tier)!.rect;
    assert.ok(b.rect.y >= band.y && b.rect.y + b.rect.h <= band.y + band.h, `${b.id} inside its band`);
    assert.ok(b.rect.x >= band.x && b.rect.x + b.rect.w <= band.x + band.w);
  }
  assert.ok(layout.width >= 720);
  assert.ok(layout.height > layout.bands[3].rect.y + layout.bands[3].rect.h - 1);
});

test("a wide tier sets the content width and the others are centred in it", () => {
  const vendors = Array.from({ length: 20 }, (_, i) => vendor(`v${String(i).padStart(2, "0")}`));
  const layout = layoutMap(input({ vendors }));
  const row = tier(layout, "vendors");
  assert.ok(layout.width >= 20 * BOX_W + 19 * BOX_GAP);
  const port = tier(layout, "listeners")[0];
  assert.equal(Math.round(port.rect.x + BOX_W / 2), Math.round(layout.width / 2));
  assert.equal(row.length, 20);
});

test("a port's clients roll up into one group box carrying their count and summed rate", () => {
  const layout = layoutMap(input({ clients: crowd() }));
  const clients = tier(layout, "clients");
  assert.equal(clients.length, 1);
  const g = clients[0];
  assert.equal(g.id, groupBoxId("smppserver.dltsmpp"));
  assert.match(g.lines[0], /▸ dltsmpp clients/);
  assert.match(g.lines[1], /^55 · 1,540\/s$/);
  //one edge to the port with the summed rate
  const e = layout.edges.filter((x) => x.from === g.id);
  assert.equal(e.length, 1);
  assert.equal(e[0].rate, (55 * 56) / 2);
  assert.equal(e[0].to, listenerBoxId("smppserver.dltsmpp"));
});

test("an open group shows its ten busiest and a chip for the rest; the chip pages ten at a time", () => {
  const key = "smppserver.dltsmpp";
  let layout = layoutMap(input({ clients: crowd() }), view({ expanded: new Set([key]) }));
  let members = layout.boxes.filter((b) => b.kind === "client");
  assert.equal(members.length, PAGE_SIZE);
  assert.deepEqual(members.map((b) => b.ref), ["A55", "A54", "A53", "A52", "A51", "A50", "A49", "A48", "A47", "A46"]);
  const chip = layout.boxes.find((b) => b.kind === "clientMore")!;
  assert.match(chip.lines[0], /^\+45 more · /);
  assert.match(chip.lines[1], /next 10/);
  assert.ok(chip.actions.includes("next-page"));
  //the frame encloses its members
  const frame = box(layout, groupBoxId(key))!;
  assert.ok(frame.frame);
  for (const m of members) {
    assert.ok(m.rect.x >= frame.rect.x && m.rect.x + m.rect.w <= frame.rect.x + frame.rect.w);
    assert.ok(m.rect.y >= frame.rect.y && m.rect.y + m.rect.h <= frame.rect.y + frame.rect.h);
  }
  //the last page holds the remainder and offers the way back to the top
  layout = layoutMap(input({ clients: crowd() }), view({ expanded: new Set([key]), pages: { [key]: 5 } }));
  members = layout.boxes.filter((b) => b.kind === "client");
  assert.deepEqual(members.map((b) => b.ref), ["A05", "A04", "A03", "A02", "A01"]);
  assert.match(layout.boxes.find((b) => b.kind === "clientMore")!.lines[1], /first 10/);
  //a page past the end clamps to the last
  layout = layoutMap(input({ clients: crowd() }), view({ expanded: new Set([key]), pages: { [key]: 99 } }));
  assert.equal(layout.boxes.filter((b) => b.kind === "client").length, 5);
});

test("a group sorts by rate, binds or name", () => {
  const key = "smppserver.dltsmpp";
  const clients = [
    client("dltsmpp", "ZED", { rate: 900, binds: 1 }),
    client("dltsmpp", "ACME", { rate: 5, binds: 2 }),
    client("dltsmpp", "MID", { rate: 50, binds: 9 }),
  ];
  const refs = (sort: "rate" | "binds" | "name") => layoutMap(input({ clients }), view({ expanded: new Set([key]), sorts: { [key]: sort } }))
    .boxes.filter((b) => b.kind === "client").map((b) => b.ref);
  assert.deepEqual(refs("rate"), ["ZED", "MID", "ACME"]);
  assert.deepEqual(refs("binds"), ["MID", "ACME", "ZED"]);
  assert.deepEqual(refs("name"), ["ACME", "MID", "ZED"]);
});

test("a small group has no chip", () => {
  const key = "smppserver.dltsmpp";
  const layout = layoutMap(input({ clients: crowd(4) }), view({ expanded: new Set([key]) }));
  assert.equal(layout.boxes.filter((b) => b.kind === "client").length, 4);
  assert.equal(layout.boxes.filter((b) => b.kind === "clientMore").length, 0);
});

test("ports beyond six collapse the quietest into +n ports, and their clients into one group", () => {
  const listeners = Array.from({ length: 9 }, (_, i) => listener(`p${i}`, { rate: (i + 1) * 100, bound: i }));
  const clients = listeners.map((l) => client(l.name, `C${l.name}`));
  let layout = layoutMap(input({ listeners, clients }));
  const ports = tier(layout, "listeners");
  assert.equal(ports.filter((b) => b.kind === "listener").length, MAX_PORTS);
  const more = ports.find((b) => b.kind === "portsMore")!;
  assert.match(more.lines[0], /^\+3 ports$/);
  //the quietest three are the hidden ones
  assert.deepEqual(more.facts.map(([n]) => n).sort(), ["p0", "p1", "p2"]);
  const other = box(layout, groupBoxId("+"))!;
  assert.match(other.lines[1], /^3 · /);
  assert.ok(layout.edges.some((e) => e.from === other.id && e.to === more.id));
  //shown in name order, the busiest six
  assert.deepEqual(ports.filter((b) => b.kind === "listener").map((b) => b.lines[0].split(" ")[0]), ["p3", "p4", "p5", "p6", "p7", "p8"]);
  //all ports: nothing collapses
  layout = layoutMap(input({ listeners, clients }), view({ allPorts: true }));
  assert.equal(tier(layout, "listeners").length, 9);
  assert.equal(layout.boxes.filter((b) => b.kind === "portsMore").length, 0);
});

test("six ports or fewer never collapse", () => {
  const listeners = Array.from({ length: 6 }, (_, i) => listener(`p${i}`));
  assert.equal(tier(layoutMap(input({ listeners })), "listeners").length, 6);
});

test("edge width: 1.2 px under 50/s, 4 px at 2,000/s and above, log scale between", () => {
  assert.equal(edgeWidth(0), 1.2);
  assert.equal(edgeWidth(null), 1.2);
  assert.equal(edgeWidth(49), 1.2);
  assert.equal(edgeWidth(2000), 4);
  assert.equal(edgeWidth(50_000), 4);
  const mid = edgeWidth(Math.sqrt(50 * 2000));
  assert.ok(Math.abs(mid - 2.6) < 1e-9, `geometric midpoint is the width midpoint, got ${mid}`);
  assert.ok(edgeWidth(300) < edgeWidth(1200));
});

test("dots: one per 400/s, at most five, speed rising with rate, a stalled link still", () => {
  assert.equal(dotCount(0), 1);
  assert.equal(dotCount(1), 1);
  assert.equal(dotCount(401), 2);
  assert.equal(dotCount(3000), 5);
  assert.equal(dotSpeed(0), 0);
  assert.ok(dotSpeed(10) > 0);
  assert.ok(dotSpeed(3000) > dotSpeed(300));
});

test("edge routing is orthogonal and never crosses a box of the tiers it joins", () => {
  const key = "smppserver.p1";
  const listeners = Array.from({ length: 9 }, (_, i) => listener(`p${i}`, { rate: 100 + i, bound: 3, node: i % 2 ? "node-1" : "node-2" }));
  const clients = listeners.flatMap((l) => crowd(14).map((c) => ({ ...c, listener: l.id, receiptRate: 3 })));
  //four of them in an open route group: its frame is drawn around them, and edges reach them through it
  const vendors = Array.from({ length: 12 }, (_, i) => vendor(`v${i}`, { node: i % 2 ? "node-1" : "node-2", bound: i !== 3, group: i >= 8 ? "lb" : null }));
  const layout = layoutMap(
    input({ listeners, clients, vendors, nodes: [NODE, { ...NODE, id: "node-2", self: false }] }),
    view({ expanded: new Set([key, "smppserver.p5"]) })
  );
  assert.ok(layout.edges.length > 30);
  const byId = new Map(layout.boxes.map((b) => [b.id, b]));
  for (const e of layout.edges) {
    //orthogonal: every segment is horizontal or vertical
    for (let i = 1; i < e.points.length; i++) {
      const [a, b] = [e.points[i - 1], e.points[i]];
      assert.ok(a[0] === b[0] || a[1] === b[1], `${e.id} segment ${i} is orthogonal`);
    }
    assert.match(edgePath(e.points), /^M [\d.]+,[\d.]+( [VH] [\d.]+)+$/);
    const tiers = new Set([byId.get(e.from)!.tier, byId.get(e.to)!.tier]);
    const ends = new Set([e.from, e.to, byId.get(e.from)!.parent, byId.get(e.to)!.parent]);
    for (const b of layout.boxes) {
      if (b.frame || ends.has(b.id) || !tiers.has(b.tier)) {
        continue;
      }
      for (let i = 1; i < e.points.length; i++) {
        assert.ok(!segmentCrosses(e.points[i - 1], e.points[i], b.rect), `${e.id} crosses ${b.id}`);
      }
    }
    //it starts and ends on its boxes' edges
    const from = byId.get(e.from)!.rect;
    const to = byId.get(e.to)!.rect;
    const [sx, sy] = e.points[0];
    const [tx, ty] = e.points.at(-1)!;
    assert.ok(sx >= from.x && sx <= from.x + from.w && (sy === from.y || sy === from.y + from.h));
    assert.ok(tx >= to.x && tx <= to.x + to.w && (ty === to.y || ty === to.y + to.h));
  }
  assert.ok(box(layout, vendorGroupBoxId("lb"))?.frame);
  //the unbound vendor's routed edge is drawn as refused
  assert.equal(layout.edges.find((e) => e.to === vendorBoxId("smppclient.v3"))?.kind, "refused");
});

test("a receipt runs beside its submit, the other way", () => {
  const layout = layoutMap(input({ clients: [client("dltsmpp", "ACME", { rate: 100, receiptRate: 90 })] }));
  const g = groupBoxId("smppserver.dltsmpp");
  const submit = layout.edges.find((e) => e.from === g && e.kind === "submit")!;
  const receipt = layout.edges.find((e) => e.to === g && e.kind === "receipt")!;
  assert.ok(receipt);
  assert.equal(receipt.points[0][0] - submit.points.at(-1)![0], 7);
  assert.equal(receipt.points.at(-1)![1], submit.points[0][1]);
});

test("an idle vendor nothing routes to gets a box and no edge; a routed idle one gets an edge", () => {
  const layout = layoutMap(input({ vendors: [vendor("idle", { routed: false, bound: false, rate: 0 }), vendor("spare", { rate: 0 })] }));
  assert.ok(box(layout, vendorBoxId("smppclient.idle")));
  assert.equal(layout.edges.filter((e) => e.to === vendorBoxId("smppclient.idle")).length, 0);
  assert.equal(layout.edges.filter((e) => e.to === vendorBoxId("smppclient.spare")).length, 1);
});

test("states: at a ceiling or held is a warning, unbound or refusing is down", () => {
  const layout = layoutMap(input({
    listeners: [listener("dltsmpp", { held: true })],
    clients: [client("dltsmpp", "HOT", { rate: 95, ceiling: 100 })],
    vendors: [vendor("otp", { backlog: { state: "THROTTLING", depth: 41_000 } }), vendor("down", { bound: false })],
  }), view({ expanded: new Set(["smppserver.dltsmpp"]) }));
  assert.equal(box(layout, clientBoxId("smppserver.dltsmpp", "HOT"))!.state, "warn");
  assert.equal(box(layout, listenerBoxId("smppserver.dltsmpp"))!.state, "warn");
  assert.ok(box(layout, listenerBoxId("smppserver.dltsmpp"))!.actions.includes("release"));
  assert.equal(box(layout, vendorBoxId("smppclient.otp"))!.state, "warn");
  assert.match(box(layout, vendorBoxId("smppclient.otp"))!.lines[1], /backlog 41k/);
  assert.equal(box(layout, vendorBoxId("smppclient.down"))!.state, "down");
});

test("route groups are open frames by default and collapse one at a time into one box", () => {
  const vendors = [vendor("a", { group: "jio" }), vendor("b", { group: "jio" }), vendor("c")];
  let layout = layoutMap(input({ vendors }));
  assert.equal(tier(layout, "vendors").length, 3);
  assert.equal(box(layout, "vg:jio")?.frame, true);
  layout = layoutMap(input({ vendors }), view({ openVendorGroups: { jio: false } }));
  assert.deepEqual(tier(layout, "vendors").map((b) => b.id).sort(), ["v:smppclient.c", "vg:jio"]);
  assert.equal(layout.edges.find((e) => e.to === "vg:jio")?.rate, 200);
  //a group of one is just its vendor
  layout = layoutMap(input({ vendors: [vendor("solo", { group: "alone" })] }));
  assert.ok(!box(layout, "vg:alone"));
});

test("the Kafka page is offered on the gateway box only on a Kafka backbone", () => {
  assert.ok(box(layoutMap(input()), nodeBoxId("node-1"))!.actions.includes("kafka"));
  assert.ok(!box(layoutMap(input({ kafka: false })), nodeBoxId("node-1"))!.actions.includes("kafka"));
});

test("focus: a client lights its path down to the vendors and leaves its siblings dim", () => {
  const key = "smppserver.dltsmpp";
  const layout = layoutMap(input({
    listeners: [listener("dltsmpp"), listener("otp")],
    clients: [client("dltsmpp", "ACME", { receiptRate: 1 }), client("dltsmpp", "YK"), client("otp", "BANK")],
    vendors: [vendor("jio"), vendor("bsnl")],
  }), view({ expanded: new Set([key]) }));
  const acme = clientBoxId(key, "ACME");
  const { boxes, edges } = focusSet(layout, acme);
  assert.ok(boxes.has(acme));
  assert.ok(boxes.has(listenerBoxId(key)));
  assert.ok(boxes.has(nodeBoxId("node-1")));
  assert.ok(boxes.has(vendorBoxId("smppclient.jio")) && boxes.has(vendorBoxId("smppclient.bsnl")));
  assert.ok(!boxes.has(clientBoxId(key, "YK")), "a sibling stays dim");
  assert.ok(!boxes.has(listenerBoxId("smppserver.otp")), "another port stays dim");
  assert.ok(edges.has(`submit:${acme}>${listenerBoxId(key)}`));
  assert.ok(edges.has(`receipt:${listenerBoxId(key)}>${acme}`));
  assert.ok(!edges.has(`submit:${clientBoxId(key, "YK")}>${listenerBoxId(key)}`));
  //a vendor lights everything upstream of it
  const up = focusSet(layout, vendorBoxId("smppclient.jio"));
  assert.ok(up.boxes.has(clientBoxId(key, "YK")) && up.boxes.has(groupBoxId("smppserver.otp")));
  assert.ok(!up.boxes.has(vendorBoxId("smppclient.bsnl")));
  //an open group lights its members
  assert.ok(focusSet(layout, groupBoxId(key)).boxes.has(clientBoxId(key, "YK")));
});

test("search opens the group, on the page holding the match, and names the box to focus", () => {
  const key = "smppserver.dltsmpp";
  const data = input({ clients: crowd() });
  //A03 is the 53rd busiest: page 5
  const hit = searchMap(data, EMPTY_VIEW, "a03")!;
  assert.equal(hit.boxId, clientBoxId(key, "A03"));
  assert.ok(hit.view.expanded.has(key));
  assert.equal(hit.view.pages[key], 5);
  assert.ok(box(layoutMap(data, hit.view), hit.boxId), "the box exists in the view the search returns");
  //by login and by IP too
  assert.equal(searchMap(data, EMPTY_VIEW, "a54")!.boxId, clientBoxId(key, "A54"));
  const byIp = input({ clients: [client("dltsmpp", "ACME", { hosts: ["203.0.113.9"] })] });
  assert.equal(searchMap(byIp, EMPTY_VIEW, "203.0.113")!.boxId, clientBoxId(key, "ACME"));
  //vendors and listeners
  assert.equal(searchMap(data, EMPTY_VIEW, "JIO")!.boxId, vendorBoxId("smppclient.jio"));
  assert.equal(searchMap(data, EMPTY_VIEW, "dltsmpp")!.boxId, listenerBoxId(key));
  assert.equal(searchMap(data, EMPTY_VIEW, "nothing-like-it"), null);
  assert.equal(searchMap(data, EMPTY_VIEW, "  "), null);
});

test("search reaches a client behind +n ports by showing every port", () => {
  const listeners = Array.from({ length: 8 }, (_, i) => listener(`p${i}`, { rate: (i + 1) * 100 }));
  const data = input({ listeners, clients: [client("p0", "QUIET")] });
  const hit = searchMap(data, EMPTY_VIEW, "quiet")!;
  assert.ok(hit.view.allPorts);
  assert.ok(box(layoutMap(data, hit.view), hit.boxId));
});

test("hit-testing finds the member before its group's frame, and nothing between boxes", () => {
  const key = "smppserver.dltsmpp";
  const layout = layoutMap(input({ clients: crowd(3) }), view({ expanded: new Set([key]) }));
  const index = hitIndex(layout.boxes);
  const m = layout.boxes.find((b) => b.kind === "client")!;
  assert.equal(hitTest(index, m.rect.x + 5, m.rect.y + 5)?.id, m.id);
  const frame = box(layout, groupBoxId(key))!;
  assert.equal(hitTest(index, frame.rect.x + 3, frame.rect.y + 3)?.id, frame.id);
  assert.equal(hitTest(index, 1, 1), null);
});

test("polyline helpers: length and the point along it", () => {
  const pts: [number, number][] = [[0, 0], [0, 10], [20, 10], [20, 30]];
  assert.equal(polylineLength(pts), 50);
  assert.deepEqual(pointAt(pts, 5), [0, 5]);
  assert.deepEqual(pointAt(pts, 20), [10, 10]);
  assert.deepEqual(pointAt(pts, 99), [20, 30]);
});

test("formatCount: in full to 99,999, then k and M; the tooltip keeps every digit", () => {
  assert.equal(formatCount(0), "0");
  assert.equal(formatCount(61_204), "61,204");
  assert.equal(formatCount(99_999), "99,999");
  assert.equal(formatCount(100_000), "100k");
  assert.equal(formatCount(612_449), "612k");
  assert.equal(formatCount(999_499), "999k");
  assert.equal(formatCount(999_600), "1M");
  assert.equal(formatCount(1_240_000), "1.24M");
  assert.equal(formatCount(12_345_678), "12.3M");
  assert.equal(formatCount(null), "—");
  assert.equal(fullCount(1_240_000), "1,240,000");
  assert.equal(countsText(null, null), "");
  assert.equal(countsText(61_204, null), "MT 61,204 · DLR —");
  assert.equal(figuresLine(1840, 61_204, 59_880, "old"), "1,840/s · MT 61,204 · DLR 59,880");
  assert.equal(figuresLine(1840, null, null, "old"), "old");
});

test("counts on the boxes: the second line is rate · MT · DLR, and the tooltip names the window", () => {
  const layout = layoutMap(input({
    listeners: [listener("dltsmpp", { rate: 1840, mt: 61_204, dlr: 59_880 })],
    vendors: [vendor("jio", { rate: 1420, mt: 47_880, dlr: 46_910, backlog: { state: "OK", depth: 41_000 } })],
  }));
  const port = box(layout, listenerBoxId("smppserver.dltsmpp"))!;
  assert.equal(port.lines[1], "1,840/s · MT 61,204 · DLR 59,880");
  assert.deepEqual([port.mt, port.dlr], [61_204, 59_880]);
  assert.deepEqual(port.facts.filter(([k]) => k.startsWith("MT") || k.startsWith("DLR")), [["MT · last hour", "61,204"], ["DLR · last hour", "59,880"]]);
  const jio = box(layout, vendorBoxId("smppclient.jio"))!;
  assert.equal(jio.lines[1], "1,420/s · MT 47,880 · DLR 46,910", "the backlog moves to the tooltip");
  assert.ok(jio.facts.some(([k]) => k === "Backlog"));
  //the Gateway box: its listeners' totals, in the tooltip -- its line is the rate in and the queue
  const node = box(layout, nodeBoxId("node-1"))!;
  assert.equal(node.lines[1], "1,840/s in · queue 0");
  assert.deepEqual(node.facts.filter(([k]) => k.startsWith("MT") || k.startsWith("DLR")), [["MT · last hour", "61,204"], ["DLR · last hour", "59,880"]]);
  assert.equal(layout.countsLabel, "last hour");
  const since = layoutMap(input({ countsWindow: "bind", listeners: [listener("dltsmpp", { mt: 5, dlr: 4 })] }));
  assert.ok(box(since, listenerBoxId("smppserver.dltsmpp"))!.facts.some(([k]) => k === "MT · since bind"));
  //a box past 99,999 abbreviates; the tooltip does not
  const big = layoutMap(input({ listeners: [listener("dltsmpp", { rate: 3000, mt: 1_240_000, dlr: 612_449 })] }));
  const bigPort = box(big, listenerBoxId("smppserver.dltsmpp"))!;
  assert.equal(bigPort.lines[1], "3,000/s · MT 1.24M · DLR 612k");
  assert.ok(bigPort.facts.some(([k, v]) => k === "MT · last hour" && v === "1,240,000"));
});

test("counts unknown: null on the box, and the old line stands", () => {
  const layout = layoutMap(input({ clients: [client("dltsmpp", "ACME")] }), view({ expanded: new Set(["smppserver.dltsmpp"]) }));
  const acme = box(layout, clientBoxId("smppserver.dltsmpp", "ACME"))!;
  assert.deepEqual([acme.mt, acme.dlr], [null, null]);
  assert.equal(acme.lines[1], "10/s · 2 binds");
  assert.ok(!acme.facts.some(([k]) => k.startsWith("MT")));
  const port = box(layout, listenerBoxId("smppserver.dltsmpp"))!;
  assert.match(port.lines[1], /bound/);
  const node = box(layout, nodeBoxId("node-1"))!;
  assert.deepEqual([node.mt, node.dlr], [null, null]);
});

test("a group sums its members' counts; the open frame, the chip and an edge carry them too", () => {
  const clients = [
    client("dltsmpp", "YK201", { rate: 612, mt: 21_940, dlr: 21_310 }),
    client("dltsmpp", "ACME", { rate: 410, mt: 14_702, dlr: null }),
    ...Array.from({ length: 11 }, (_, i) => client("dltsmpp", `Z${i}`, { rate: 1, mt: 100, dlr: 90 })),
  ];
  const closed = layoutMap(input({ clients, listeners: [listener("dltsmpp", { mt: 1, dlr: 1 })] }));
  const g = box(closed, groupBoxId("smppserver.dltsmpp"))!;
  assert.equal(g.lines[0], "▸ dltsmpp clients · 13");
  assert.equal(g.lines[1], "1,033/s · MT 37,742 · DLR 22,300", "members summed, not the port's own");
  assert.deepEqual([g.mt, g.dlr], [37_742, 22_300]);
  const submit = closed.edges.find((e) => e.from === g.id)!;
  assert.deepEqual([submit.mt, submit.dlr], [37_742, 22_300]);
  assert.equal(submit.title, "dltsmpp clients → dltsmpp :22775");
  assert.deepEqual(submit.facts, [["Submits/s", "1,033/s"], ["MT · last hour", "37,742"], ["DLR · last hour", "22,300"]]);

  const open = layoutMap(input({ clients }), view({ expanded: new Set(["smppserver.dltsmpp"]) }));
  const frame = box(open, groupBoxId("smppserver.dltsmpp"))!;
  assert.match(frame.lines[0], / · MT 37,742 · DLR 22,300$/);
  const yk = box(open, clientBoxId("smppserver.dltsmpp", "YK201"))!;
  assert.equal(yk.lines[1], "612/s · MT 21,940 · DLR 21,310");
  const acme = box(open, clientBoxId("smppserver.dltsmpp", "ACME"))!;
  assert.equal(acme.lines[1], "410/s · MT 14,702 · DLR —");
  const chip = open.boxes.find((b) => b.kind === "clientMore")!;
  assert.deepEqual([chip.mt, chip.dlr], [300, 270], "the three not shown");
  assert.ok(chip.facts.some(([k, v]) => k === "MT · last hour" && v === "300"));
});

test("a group whose members know no count (split by IP over the hour) shows its port's", () => {
  const clients = [client("dltsmpp", "ACME", { ip: "10.0.0.1", key: "ACME·1" }), client("dltsmpp", "ACME", { ip: "10.0.0.2", key: "ACME·2" })];
  const layout = layoutMap(input({ clients, listeners: [listener("dltsmpp", { mt: 900, dlr: 880 })] }));
  const g = box(layout, groupBoxId("smppserver.dltsmpp"))!;
  assert.deepEqual([g.mt, g.dlr], [900, 880]);
});

test("the ports chip, the node and a vendor group sum what they stand for", () => {
  const listeners = Array.from({ length: MAX_PORTS + 2 }, (_, i) => listener(`p${i}`, { rate: 100 - i, mt: 10, dlr: 5 }));
  const layout = layoutMap(input({ listeners }));
  const more = box(layout, listenerBoxId(OTHER_PORTS))!;
  assert.deepEqual([more.mt, more.dlr], [20, 10]);
  const node = box(layout, nodeBoxId("node-1"))!;
  assert.deepEqual([node.mt, node.dlr], [80, 40]);

  const vendors = [vendor("a", { group: "G", mt: 100, dlr: 90 }), vendor("b", { group: "G", mt: 50, dlr: null })];
  const grouped = layoutMap(input({ vendors }), view({ openVendorGroups: { G: false } }));
  const vg = grouped.boxes.find((b) => b.kind === "vendorGroup")!;
  assert.equal(vg.lines[0], "▸ G · 2");
  assert.match(vg.lines[1], / · MT 150 · DLR 90$/);
  const into = grouped.edges.find((e) => e.to === vg.id)!;
  assert.deepEqual([into.mt, into.dlr], [150, 90]);
});

test("edgeAt: the nearest edge under the pointer, among those the filter keeps", () => {
  const layout = layoutMap(input({ clients: [client("dltsmpp", "ACME", { receiptRate: 5 })] }));
  const submit = layout.edges.find((e) => e.kind === "submit" && e.from === groupBoxId("smppserver.dltsmpp"))!;
  const [x, y] = submit.points[1];
  assert.equal(edgeAt(layout.edges, x, y)?.id, submit.id);
  assert.equal(edgeAt(layout.edges, x + 2, y - 1, 5, (e) => e.kind === "submit")?.id, submit.id);
  assert.equal(edgeAt(layout.edges, -500, -500), null);
  assert.notEqual(edgeAt(layout.edges, x, y, 5, (e) => e.kind === "receipt")?.id, submit.id);
});

/** Samples five seconds apart. */
function samples(...values: (number | null)[]): QueueSample[] {
  return values.map((queue, i) => ({ at: 1_000_000 + i * 5_000, queue }));
}

test("the node's line is the rate in and the queue: router + lag + retry; persistence stays in the tooltip", () => {
  const layout = layoutMap(input({
    listeners: [listener("a", { rate: 1007, mt: 5, dlr: 4 })],
    nodes: [{ ...NODE, queue: queue({ router: 40, lag: 2, retry: 1, persist: 900, persistLagSeconds: 3.4 }) }],
  }));
  const n = box(layout, nodeBoxId("node-1"))!;
  assert.equal(n.lines[1], "1,007/s in · queue 43");
  assert.equal(n.state, "ok");
  const facts = Object.fromEntries(n.facts);
  assert.equal(facts["Queue"], "43");
  assert.equal(facts["Router queue"], "40");
  assert.equal(facts["Router lag"], "2");
  assert.equal(facts["Retry"], "1");
  assert.equal(facts["Persistence"], "900 · 3 s behind");
  assert.equal(facts["Line"], "10,000 queued · 60 s persist");
  assert.equal(facts["MT · last hour"], "5");
  //the node still carries its counts for the focus readout
  assert.deepEqual([n.mt, n.dlr], [5, 4]);
  //a node whose queue nobody knows says so
  const other = layoutMap(input({ nodes: [{ ...NODE, queue: null }] }));
  assert.equal(box(other, nodeBoxId("node-1"))!.lines[1], "10/s in · queue —");
});

test("rising: up on each of the last three polls by 1,000 or more; the run's growth and time", () => {
  assert.equal(queueTrend(samples(5)), null);
  assert.deepEqual(queueTrend(samples(0, 0, 0, 0)), { rising: false, delta: 0, seconds: 5 });
  //three rises, 2,300 over 15 s
  assert.deepEqual(queueTrend(samples(9_000, 10_000, 11_000, 11_300)), { rising: true, delta: 2_300, seconds: 15 });
  //a longer run counts from where it began
  assert.deepEqual(queueTrend(samples(100, 200, 900, 1_400, 1_800, 2_400, 2_400)), { rising: false, delta: 0, seconds: 5 });
  assert.deepEqual(queueTrend(samples(5, 100, 900, 1_400, 1_800, 2_400)), { rising: true, delta: 2_395, seconds: 25 });
  //two rises are not enough, nor a wobble that adds up to little
  assert.equal(queueTrend(samples(0, 0, 5_000, 9_000))!.rising, false);
  assert.equal(queueTrend(samples(100, 200, 300, 400))!.rising, false);
  assert.ok(RISE_MIN > 300);
  //falling says so; an unknown reading is skipped, not read as zero
  assert.deepEqual(queueTrend(samples(5_000, 4_000)), { rising: false, delta: -1_000, seconds: 5 });
  assert.equal(queueTrend(samples(0, 2_000, null, 4_000, 6_000))!.rising, true);
  assert.equal(QUEUE_SAMPLES, 12);
});

test("alarm: rising, or past either line, whatever the trend; a down node stays down", () => {
  const rising = { rising: true, delta: 2_300, seconds: 30 };
  assert.equal(nodeState({ ...NODE, queue: queue({ router: 12_300 }), trend: rising }), "alarm");
  assert.equal(nodeState({ ...NODE, queue: queue({ router: 300 }), trend: rising }), "alarm");
  //past the queue line: router + lag + retry
  assert.equal(nodeState({ ...NODE, queue: queue({ router: 4_000, lag: 5_000, retry: 1_001 }) }), "alarm");
  assert.equal(nodeState({ ...NODE, queue: queue({ router: LAG_WARN }) }), "ok");
  //past the persist lag line, the gateway's or 60 s
  assert.equal(nodeState({ ...NODE, queue: queue({ persistLagSeconds: 61 }) }), "alarm");
  assert.equal(nodeState({ ...NODE, queue: queue({ persistLagSeconds: 61, persistLagMax: 120 }) }), "ok");
  assert.equal(nodeState({ ...NODE, alive: false, queue: queue({ router: 50_000 }) }), "down");

  const layout = layoutMap(input({ nodes: [{ ...NODE, queue: queue({ router: 12_300 }), trend: rising }] }));
  const n = box(layout, nodeBoxId("node-1"))!;
  assert.equal(n.state, "alarm");
  assert.equal(n.lines[1], "10/s in · queue 12,300 ▲");
  assert.equal(Object.fromEntries(n.facts)["Trend"], "rising 2,300 in 30 s");
  assert.equal(Object.fromEntries(n.facts)["Past the line"], "queue");
  assert.equal(n.speech, "node-1 · Router, 10/s in · queue 12,300 rising");
});

test("an open route group is a frame holding its members side by side, under its title band", () => {
  const vendors = [vendor("sim1", { group: "sim-lb", rate: 600, mt: 10, dlr: 9 }), vendor("sim2", { group: "sim-lb", rate: 407, bound: false }), vendor("x")];
  const layout = layoutMap(input({ vendors }));
  const frame = box(layout, vendorGroupBoxId("sim-lb"))!;
  assert.equal(frame.frame, true);
  assert.equal(frame.kind, "vendorGroup");
  assert.equal(frame.lines[0], "▾ sim-lb · 2 vendors · 1,007/s · MT 10 · DLR 9");
  //the worst member's state: an unbound member is down
  assert.equal(frame.state, "down");
  const members = layout.boxes.filter((b) => b.parent === frame.id).sort((a, b) => a.rect.x - b.rect.x);
  assert.deepEqual(members.map((m) => m.id), [vendorBoxId("smppclient.sim1"), vendorBoxId("smppclient.sim2")]);
  for (const m of members) {
    assert.ok(m.rect.x >= frame.rect.x && m.rect.x + m.rect.w <= frame.rect.x + frame.rect.w, `${m.id} inside the frame sideways`);
    assert.ok(m.rect.y >= frame.rect.y + 20 && m.rect.y + m.rect.h <= frame.rect.y + frame.rect.h, `${m.id} under the title band`);
  }
  assert.equal(members[0].rect.y, members[1].rect.y);
  assert.equal(members[1].rect.x - members[0].rect.x, BOX_W + BOX_GAP);
  //the frame sits inside the vendors band, and the ungrouped vendor beside it on the members' row
  const band = layout.bands.find((b) => b.id === "vendors")!.rect;
  assert.ok(frame.rect.y >= band.y && frame.rect.y + frame.rect.h <= band.y + band.h);
  assert.equal(box(layout, vendorBoxId("smppclient.x"))!.rect.y, members[0].rect.y);
  //open, the node's edges go to each member, none to the frame
  assert.equal(layout.edges.filter((e) => e.to === frame.id).length, 0);
  assert.equal(layout.edges.filter((e) => members.some((m) => m.id === e.to)).length, 2);
  //the frame is hit-tested after its members
  const idx = hitIndex(layout.boxes);
  assert.equal(hitTest(idx, members[0].rect.x + 5, members[0].rect.y + 5)?.id, members[0].id);
  assert.equal(hitTest(idx, frame.rect.x + 5, frame.rect.y + 5)?.id, frame.id);
});

test("a collapsed group is one box and the node's edge lands on its top centre", () => {
  const vendors = [vendor("sim1", { group: "sim-lb" }), vendor("sim2", { group: "sim-lb" })];
  const layout = layoutMap(input({ vendors }), view({ openVendorGroups: { "sim-lb": false } }));
  const g = box(layout, vendorGroupBoxId("sim-lb"))!;
  assert.ok(!g.frame);
  assert.equal(g.lines[0], "▸ sim-lb");
  const e = layout.edges.find((x) => x.to === g.id)!;
  const [tx, ty] = e.points.at(-1)!;
  assert.equal(ty, g.rect.y);
  assert.ok(Math.abs(tx - (g.rect.x + g.rect.w / 2)) <= 4, "the top centre");
  assert.equal(layout.boxes.filter((b) => b.parent === g.id).length, 0);
  //search for a member opens its group again
  const hit = searchMap(input({ vendors }), view({ openVendorGroups: { "sim-lb": false } }), "sim2")!;
  assert.equal(hit.view.openVendorGroups["sim-lb"], true);
});

test("the header totals: rate summed over listeners, then clients, ports, alive nodes, vendors, groups", () => {
  const base = input({
    clients: [client("a", "ACME")],
    listeners: [listener("a", { rate: 1000 }), listener("b", { rate: 7 })],
    vendors: [vendor("sim1", { group: "sim-lb" }), vendor("sim2", { group: "sim-lb" })],
    nodes: [NODE, { ...NODE, id: "node-2", alive: false }],
  });
  assert.equal(totalsText(base), "1,007/s · 1 clients · 2 ports · 1 node · 2 vendors · 1 group");
  assert.equal(totalsText({ ...base, vendors: [vendor("v")] }), "1,007/s · 1 clients · 2 ports · 1 node · 1 vendors");
  assert.equal(totalsText({ ...base, listeners: [] }, true), "—/s · 1 client addresses · 0 ports · 1 node · 2 vendors · 1 group");
});

//─── the database, its writes, and refusals at the door (0.15.1) ───

function database(over: Partial<DatabaseIn> = {}): DatabaseIn {
  return {
    node: "node-1", server: "db.internal (10.128.0.2):5432", name: "fireflo", version: "18.6", schema: "1.122.0",
    connectedSince: "2026-10-30T09:42:17Z", admission: "OK", reason: null, probeMs: 12, poolActive: 3, poolMax: 16, poolWaitMs: 1,
    lanes: "lease 1/2 · control 0/2", writeRate: 1840, persistDepth: 1250, persistLagSeconds: 2, logBytes: 1_288_490_189,
    logCapBytes: null, logHealthy: true, refusedTotal: 4_812, ...over,
  };
}

const refusal = (rate: number, by: [string, number][]): ListenerRefusal => ({
  rate, total: Math.round(rate * 60), by: by.map(([reason, count]) => ({ reason, count })),
});

test("no database: no Database box and no persist edge", () => {
  const layout = layoutMap(input());
  assert.equal(box(layout, DATABASE_BOX_ID), undefined);
  assert.ok(!layout.edges.some((e) => e.kind === "persist"));
  assert.equal(box(layoutMap(input({ database: null })), DATABASE_BOX_ID), undefined);
});

test("the Database box: beside the node that asks it, its two lines, its actions", () => {
  const layout = layoutMap(input({ database: database(), nodes: [NODE, { ...NODE, id: "node-2", self: false }] }));
  const d = box(layout, DATABASE_BOX_ID)!;
  assert.equal(d.kind, "database");
  assert.equal(d.tier, "nodes");
  assert.equal(d.rect.w, DB_W);
  assert.deepEqual(d.lines, ["PostgreSQL · db.internal (10.128.0.2):5432", "probe 12 ms · pool 3/16 · 1,840 rows/s"]);
  //row order: node-1, the database, node-2
  const row = tier(layout, "nodes").sort((a, b) => a.rect.x - b.rect.x).map((b) => b.id);
  assert.deepEqual(row, [nodeBoxId("node-1"), DATABASE_BOX_ID, nodeBoxId("node-2")]);
  assert.deepEqual(d.actions, ["queues", "health", "slow-queries"]);
  assert.equal(d.state, "ok");
  assert.equal(d.badge, undefined);
  const facts = new Map(d.facts);
  assert.equal(facts.get("Server"), "PostgreSQL 18.6");
  assert.equal(facts.get("Schema"), "1.122.0");
  assert.equal(facts.get("Connected since"), "30 Oct 2026 09:42:17 UTC", "in the display zone, named; UTC when the input names none");
  assert.equal(facts.get("Lanes"), "lease 1/2 · control 0/2");
  assert.equal(facts.get("Persistence"), "1,250 · 2 s behind");
  assert.equal(facts.get("Local log"), "1.2 GiB");
  assert.equal(facts.get("Refused for it"), "4,812 since start");
  assert.match(d.speech ?? "", /^Database PostgreSQL · db\.internal/);
});

test("the Database box's state is the admission's; unknown parts drop out of its line", () => {
  assert.equal(databaseState({ admission: "OK", reason: null }), "ok");
  assert.equal(databaseState({ admission: "DEGRADED", reason: "probe" }), "warn");
  //accept-and-queue (0.15.1): a slow database refuses nothing, so REFUSING alone is a warning; the door
  //refuses only for the local log, which the reason names
  assert.equal(databaseState({ admission: "REFUSING", reason: "probe" }), "warn");
  assert.equal(databaseState({ admission: "REFUSING", reason: "logCap" }), "refusing");
  assert.equal(databaseState({ admission: "OK", reason: "logFsync" }), "refusing");
  assert.equal(databaseState({ admission: null, reason: null }), "ok");
  const bare = database({ server: null, name: null, probeMs: null, poolActive: null, poolMax: null, writeRate: null });
  assert.deepEqual(databaseLines(bare), ["PostgreSQL", "—"]);
  assert.deepEqual(databaseLines(database({ server: null, poolMax: null, writeRate: null })), ["PostgreSQL · fireflo", "probe 12 ms · pool 3"]);
  const capped = layoutMap(input({ database: database({ logCapBytes: 8192 * 1024 * 1024, logHealthy: false, admission: "REFUSING", reason: "logCap" }) }));
  const facts = new Map(box(capped, DATABASE_BOX_ID)!.facts);
  assert.equal(facts.get("Local log"), "1.2 GiB of 8.0 GiB · fsync failing");
  assert.equal(facts.get("Admission"), "REFUSING · logCap");
  assert.equal(box(capped, DATABASE_BOX_ID)!.state, "refusing");
});

test("the persist edge: node → database, straight across, width by rows/s on the submits' scale, coloured by the state", () => {
  const layout = layoutMap(input({ database: database({ admission: "DEGRADED" }), nodes: [NODE, { ...NODE, id: "node-2", self: false }] }));
  const persist = layout.edges.filter((e) => e.kind === "persist");
  assert.equal(persist.length, 1, "only the answering node's writes are known");
  const e = persist[0];
  assert.equal(e.from, nodeBoxId("node-1"));
  assert.equal(e.to, DATABASE_BOX_ID);
  assert.equal(e.rate, 1840);
  assert.equal(e.width, edgeWidth(1840));
  assert.equal(e.state, "warn");
  const n = box(layout, nodeBoxId("node-1"))!.rect;
  const d = box(layout, DATABASE_BOX_ID)!.rect;
  assert.deepEqual(e.points, [[n.x + n.w, n.y + n.h / 2], [d.x, d.y + d.h / 2]]);
  for (const b of layout.boxes) {
    assert.ok(!segmentCrosses(e.points[0], e.points[1], b.rect), `crosses ${b.id}`);
  }
  assert.equal(e.title, "node-1 → PostgreSQL");
  assert.deepEqual(e.facts, [["Rows written/s", "1,840/s"], ["Persistence depth", "1,250"], ["Lag", "2 s"], ["Database", "DEGRADED"]]);
  const slow = layoutMap(input({ database: database({ writeRate: 40 }) })).edges.find((x) => x.kind === "persist")!;
  assert.ok(slow.width < e.width);
  assert.equal(layoutMap(input({ database: database({ writeRate: null }) })).edges.find((x) => x.kind === "persist")!.rate, 0);
  //focusing the node lights its writes and the database
  const lit = focusSet(layout, nodeBoxId("node-1"));
  assert.ok(lit.edges.has(e.id));
  assert.ok(lit.boxes.has(DATABASE_BOX_ID));
});

test("reason mix: most first, rounded, <1 % for a sliver, the rest as other", () => {
  assert.equal(reasonMix([{ reason: "creditPending", count: 20 }, { reason: "dbUnavailable", count: 80 }]), "dbUnavailable 80 % · creditPending 20 %");
  assert.equal(reasonMix([{ reason: "a", count: 999 }, { reason: "b", count: 1 }]), "a 100 % · b <1 %");
  assert.equal(
    reasonMix([{ reason: "a", count: 40 }, { reason: "b", count: 30 }, { reason: "c", count: 20 }, { reason: "d", count: 6 }, { reason: "e", count: 4 }]),
    "a 40 % · b 30 % · c 20 % · other 10 %"
  );
  assert.equal(reasonMix([]), "");
  assert.equal(refusedLabel(refusal(312, [["dbUnavailable", 14_976], ["creditPending", 3_744]])), "312/s refused · dbUnavailable 80 % · creditPending 20 %");
  assert.equal(refusedLabel(refusal(2, [])), "2/s refused");
});

test("refused at the door: a red edge from the port back to its clients' group, collapsed or open, labelled", () => {
  const refused = refusal(312, [["dbUnavailable", 14_976], ["creditPending", 3_744]]);
  const listeners = [listener("dltsmpp", { refused }), listener("otp", { port: "22780" })];
  const clients = [client("dltsmpp", "YK201"), client("otp", "ACME")];
  for (const v of [view(), view({ expanded: new Set(["smppserver.dltsmpp"]) })]) {
    const layout = layoutMap(input({ listeners, clients }), v);
    const doors = layout.edges.filter((e) => e.kind === "refused" && e.from.startsWith("l:"));
    assert.equal(doors.length, 1, "only the refusing port");
    const e = doors[0];
    assert.equal(e.from, listenerBoxId("smppserver.dltsmpp"));
    assert.equal(e.to, groupBoxId("smppserver.dltsmpp"));
    assert.equal(e.rate, 312);
    assert.equal(e.label, "312/s refused · dbUnavailable 80 % · creditPending 20 %");
    assert.deepEqual(e.facts.slice(0, 2), [["Refused/s", "312/s"], ["In the minute", "18,720"]]);
    //it runs up: from the port's top to the group's bottom, orthogonal, crossing nothing
    const l = box(layout, e.from)!.rect;
    const g = box(layout, e.to)!.rect;
    assert.equal(e.points[0][1], l.y);
    assert.equal(e.points.at(-1)![1], g.y + g.h);
    for (let i = 1; i < e.points.length; i++) {
      const [a, b] = [e.points[i - 1], e.points[i]];
      assert.ok(a[0] === b[0] || a[1] === b[1]);
      for (const other of layout.boxes) {
        if (other.id !== e.from && other.id !== e.to && !other.frame && other.parent !== e.to) {
          assert.ok(!segmentCrosses(a, b, other.rect), `crosses ${other.id}`);
        }
      }
    }
    const lb = box(layout, e.from)!;
    assert.deepEqual(new Map(lb.facts).get("Reasons"), "dbUnavailable 80 % · creditPending 20 %");
    assert.match(lb.speech ?? "", /refusing 312\/s: dbUnavailable 80 %, creditPending 20 %/);
  }
  //no refusals, no edge
  assert.ok(!layoutMap(input({ listeners: [listener("dltsmpp")], clients })).edges.some((e) => e.kind === "refused"));
});

test("hidden ports' refusals are one edge from +n ports to the other ports' clients", () => {
  const listeners = Array.from({ length: MAX_PORTS + 2 }, (_, i) => listener(`p${i}`, {
    rate: 100 - i,
    ...(i >= MAX_PORTS ? { refused: refusal(10, [["throttled", 600]]) } : {}),
  }));
  const clients = listeners.map((l) => client(l.name, `A${l.name}`));
  const layout = layoutMap(input({ listeners, clients }));
  const e = layout.edges.find((x) => x.kind === "refused" && x.from === listenerBoxId(OTHER_PORTS))!;
  assert.equal(e.to, groupBoxId(OTHER_PORTS));
  assert.equal(e.rate, 20);
  assert.equal(e.label, "20/s refused · throttled 100 %");
});

test("the database's badge: refusing N/s only when the doors refuse mostly for the database", () => {
  const db = database({ admission: "REFUSING", reason: "logCap" });
  const mostlyDb = [listener("a", { refused: refusal(312, [["dbUnavailable", 14_976], ["creditPending", 3_744]]) }), listener("b", { refused: refusal(1, [["logCap", 60]]) })];
  assert.equal(databaseRefusing(mostlyDb), (14_976 + 60) / 60);
  const layout = layoutMap(input({ database: db, listeners: mostlyDb }));
  const d = box(layout, DATABASE_BOX_ID)!;
  assert.equal(d.badge, "refusing 251/s");
  assert.equal(new Map(d.facts).get("Refusing now"), "251/s · last minute");
  assert.match(d.speech ?? "", /refusing 251\/s$/);
  //logCap alone is the database's too
  assert.equal(databaseRefusing([listener("a", { refused: refusal(5, [["logCap", 300]]) })]), 5);
  //mostly credit: not the database's
  const credit = [listener("a", { refused: refusal(10, [["creditPending", 500], ["dbUnavailable", 100]]) })];
  assert.equal(databaseRefusing(credit), null);
  assert.equal(box(layoutMap(input({ database: db, listeners: credit })), DATABASE_BOX_ID)!.badge, undefined);
  assert.equal(databaseRefusing([listener("a")]), null);
});

test("a held vendor in a route group reads 'paused · routed around'; alone it reads 'sending paused'", () => {
  const grouped = layoutMap(input({
    vendors: [vendor("v1", { held: true, group: "sim-lb", backlog: { state: "PAUSED", depth: 0 } }), vendor("v2", { group: "sim-lb" })],
  }));
  const v1 = box(grouped, vendorBoxId("smppclient.v1")) ?? grouped.boxes.find((b) => b.ref === "smppclient.v1" || b.ref === "v1");
  assert.ok(v1, "the held vendor has a box");
  assert.ok(v1!.facts.some(([k, v]) => k === "State" && v === "paused · routed around"), JSON.stringify(v1!.facts));
  const alone = layoutMap(input({ vendors: [vendor("v1", { held: true, group: null, backlog: { state: "PAUSED", depth: 0 } })] }));
  const solo = box(alone, vendorBoxId("smppclient.v1")) ?? alone.boxes.find((b) => b.ref === "smppclient.v1" || b.ref === "v1");
  assert.ok(solo!.facts.some(([k, v]) => k === "State" && v === "sending paused"), JSON.stringify(solo!.facts));
});
