import { BILLING_KEY } from "@/lib/billing-key";
import { configQuery } from "@/lib/config-db";
import { auditConfigChange } from "@/lib/config-audit";
import { ensureCustomerUser } from "@/lib/users";
import { assertWritableAccount } from "@/lib/account-archive";
import {
  type Account,
  type AccountInput,
  type AccountSummary,
  type OrphanAccount,
} from "@/lib/account-types";
import { DEFAULT_SCOPE } from "@/lib/rate-types";

/**
 * The account catalogue.
 *
 * <p>Server-only: importing this pulls `pg`. The shapes live in `account-types.ts`.
 *
 * <p>`app_account` began as a catalogue of names over ids minted independently in
 * `app_credential.account_id`, `app_rate_rule.scope`, `account_balance.account_id` and
 * `cdr_submit.account_id`, with nothing reconciling them.
 *
 * <p><strong>Since gateway migration V1.55.0 it is the source of truth for configuration and
 * money.</strong> Logins, balances, the ledger, reservations, sender IDs, templates and whitelist
 * policies hold a foreign key to it; a trigger catalogues an id the moment one of them first names
 * it, so writing a login for a new account still just works. What can still lack a row: an id
 * that only a rate rule's scope or the call records name — the rate scope also names vendors, and
 * call records keep ids after an account is gone. That is what {@link listOrphanAccounts} now
 * finds, and why the account page still works for an id with no row.
 *
 * <h2>What must never be joined in here</h2>
 *
 * <p><strong>`account_balance`.</strong> It is the gateway's hot path — reserved on submit, debited
 * on accept, per message — and everything in this module runs over the *whole* customer base to fill
 * an index. A `LEFT JOIN` onto it would put a scan across every account in contention with the money
 * path on every page load. Reading one balance for one account is fine and `account-context.ts` does
 * exactly that; a list must not. If an index ever genuinely needs balances, it needs a periodic
 * snapshot, not a join.
 *
 * <p><strong>`cdr_submit`.</strong> Unbounded history on the other database. Last-sent, message
 * counts and spend are `/cdrs` questions.
 *
 * <p>`app_credential`, `app_rate_rule` and `app_worker` carry no such risk: they are cold
 * configuration, read by the gateway's poller and written from this panel.
 */

interface AccountRow {
  id: string;
  label: string | null;
  description: string | null;
  enabled: boolean;
  email: string | null;
  resells: boolean;
  parent_account_id: string | null;
  updated_at: Date | null;
  archived_at?: Date | null;
  archived_by?: string | null;
  external_ref?: string | null;
  credential_count?: number;
  rule_count?: number;
  collides?: boolean;
  child_count?: number;
}

/**
 * The catalogue, with how much is riding on each row.
 *
 * <p>The credential count is deliberately computed from the same fallback the gateway uses rather
 * than from `account_id` alone: a login with a blank account bills to its system id, so it belongs
 * to that account even though the column is null. Counting only the explicit column would show zero
 * logins for an account that has three.
 */
export async function listAccounts(
  { archived = false }: { archived?: boolean } = {}
): Promise<AccountSummary[]> {
  const rows = await configQuery<AccountRow>(
    `SELECT a.id, a.label, a.description, a.enabled, a.email, a.updated_at,
            a.resells, a.parent_account_id, a.archived_at, a.archived_by, a.external_ref,
            COALESCE(c.creds, 0)::int AS credential_count,
            COALESCE(r.rules, 0)::int AS rule_count,
            COALESCE(k.kids, 0)::int AS child_count,
            EXISTS (SELECT 1 FROM app_worker w
                     WHERE w.type = 'smppclient' AND w.name = a.id) AS collides
       FROM app_account a
       LEFT JOIN (SELECT ${BILLING_KEY} AS acct, count(*) AS creds
                    FROM app_credential GROUP BY 1) c ON c.acct = a.id
       LEFT JOIN (SELECT parent_account_id AS parent, count(*) AS kids
                    FROM app_account WHERE parent_account_id IS NOT NULL
                   GROUP BY 1) k ON k.parent = a.id
       LEFT JOIN (SELECT scope, count(*) AS rules
                    FROM app_rate_rule GROUP BY scope) r ON r.scope = a.id
      WHERE (a.archived_at IS NOT NULL) = $1
      ORDER BY a.id`,
    //archived accounts are out of the everyday list and have one of their own
    [archived]
  );
  return rows.map(toSummary);
}

/**
 * Account ids in use that the catalogue has never heard of, and where each was found.
 *
 * <p>The same shape as `listOrphanProducts`. Since gateway migration V1.55.0 a login can no longer
 * name an uncatalogued account -- a trigger catalogues it and a foreign key holds it there -- so in
 * practice what this finds is an id that exists only as a rate scope, which has no foreign key
 * because the same column also names vendors.
 *
 * <p><strong>The source is returned rather than flattened away, because one of the two is
 * ambiguous.</strong> An id found on a credential is an account by construction — it is the billing
 * key. An id found only as a rate scope may equally be a vendor that was deleted or never
 * configured, since `app_rate_rule.scope` holds vendor instance names in the same column. Offering
 * that as an account to adopt would invite exactly the collision `validateScope` refuses, so the
 * caller has to be able to tell the two apart and say so.
 *
 * <p>Scopes matching a currently configured vendor are excluded outright — those are not ambiguous,
 * they are cost rules.
 *
 * <p>So is the default scope, for the same reason and more strongly. `*` is reserved: `scopeKind`
 * returns "default" for it before consulting either catalogue, and `validateScope` refuses to let an
 * account or a vendor be named it. It arrived here as an id with no `app_account` row and was
 * offered in the accounts table as an unnamed account that "may not be an account" — a hedge that is
 * honest about a deleted vendor's leftover scope and simply wrong about this one. Worse, an orphan
 * row is what an operator adopts INTO a real account, and creating one named `*` is precisely what
 * the validator exists to prevent. Its home is the pricing page, which describes it correctly.
 *
 * <p>Config sources only. `cdr_submit.account_id` lives on the other database and is unbounded
 * history, so an account that sent once in 2019 is not something to put in an editable list.
 */
export async function listOrphanAccounts(): Promise<OrphanAccount[]> {
  const rows = await configQuery<{ id: string; from_credential: boolean; from_rate_scope: boolean }>(
    `SELECT id,
            bool_or(src = 'credential') AS from_credential,
            bool_or(src = 'rateScope')  AS from_rate_scope
       FROM (
         SELECT ${BILLING_KEY} AS id, 'credential' AS src FROM app_credential
         UNION ALL
         SELECT scope, 'rateScope' FROM app_rate_rule
          WHERE scope NOT IN (SELECT name FROM app_worker WHERE type = 'smppclient')
            AND scope <> $1
       ) t
      WHERE id IS NOT NULL AND btrim(id) <> ''
        AND id NOT IN (SELECT id FROM app_account)
      GROUP BY id
      ORDER BY id`,
    [DEFAULT_SCOPE]
  );
  return rows.map((r) => ({
    id: r.id,
    fromCredential: r.from_credential,
    fromRateScope: r.from_rate_scope,
  }));
}

export async function getAccount(id: string): Promise<Account | null> {
  const rows = await configQuery<AccountRow>(
    `SELECT id, label, description, enabled, email, resells, parent_account_id, updated_at,
            archived_at, archived_by, external_ref
       FROM app_account WHERE id = $1`,
    [id]
  );
  return rows.length ? toSummary(rows[0]) : null;
}

/**
 * Creates or updates one account.
 *
 * <p>Upsert rather than separate create and update paths, because an account routinely exists as a
 * string before it exists as a row — adopting an orphan and editing a catalogued account are the
 * same operation, and splitting them would mean the panel had to know which it was doing.
 */
export async function saveAccount(input: AccountInput): Promise<void> {
  //an archived account is read-only; unarchiving is its own action (lib/account-archive.ts)
  await assertWritableAccount(null, input.id);
  try {
    await saveAccountRow(input);
  } catch (err) {
    throw translateHierarchy(err, input);
  }
}

/**
 * Turns the two-level constraints into something an operator can act on.
 *
 * <p>The shape of the account tree is held by the database rather than by this panel -- a composite
 * foreign key forces a parent to be a reseller, and a CHECK stops a child from reselling. That is
 * the right place for it, and it means the failure arrives as a constraint name. Left alone the
 * form would show `violates foreign key constraint "app_account_parent_is_reseller"`, which is
 * accurate and tells nobody what to do next.
 *
 * <p>Deliberately mapped by constraint name and not re-validated here. Checking the tree in
 * JavaScript first would be a second implementation of the same rule, free to disagree with the one
 * that actually holds -- and it would still have to handle the race where the parent stops
 * reselling between the check and the write.
 */
function translateHierarchy(err: unknown, input: AccountInput): Error {
  const constraint = (err as { constraint?: string })?.constraint;
  const parent = input.parentAccountId?.trim();

  if (constraint === "app_account_parent_is_reseller") {
    return new Error(
      parent
        ? `'${parent}' cannot hold accounts: it is not marked as a reseller, or it has a parent of `
          + "its own. Mark it as reselling first."
        : "This account still has accounts beneath it, so it cannot stop reselling. Move them to "
          + "another reseller, or make them top-level, first."
    );
  }
  if (constraint === "app_account_two_levels") {
    return new Error(
      "An account cannot both resell and belong to a reseller. There are exactly two levels: a "
      + "reseller, and the accounts beneath it."
    );
  }
  return err instanceof Error ? err : new Error(String(err));
}

async function saveAccountRow(input: AccountInput): Promise<void> {
  await configQuery(
    `INSERT INTO app_account (id, label, description, email, enabled, resells,
                              parent_account_id, updated_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, now())
     ON CONFLICT (id) DO UPDATE
       SET label = EXCLUDED.label, description = EXCLUDED.description,
           email = EXCLUDED.email, enabled = EXCLUDED.enabled,
           resells = EXCLUDED.resells, parent_account_id = EXCLUDED.parent_account_id,
           updated_at = now()`,
    //trimmed, never lower-cased: `uq_app_account_email` indexes lower(email), so case-insensitive
    //uniqueness is the index's job, and folding the stored value could break the local part
    [
      input.id.trim(),
      input.label?.trim() || null,
      input.description?.trim() || null,
      input.email?.trim() || null,
      input.enabled,
      input.resells ?? false,
      //empty string is not "no parent" -- it is a foreign key to an account named "", which does
      //not exist. Null is the only way to say top-level
      input.parentAccountId?.trim() || null,
    ]
  );
  //the address on the account is also a person who may sign in to the portal. After the row, because
  //app_user.account_id is a foreign key to it -- see ensureCustomerUser for why insert-only
  await ensureCustomerUser(input.id.trim(), input.email);
}

/** Why an account cannot be deleted: what still uses it, in words, e.g. "2 logins". */
export class AccountInUseError extends Error {
  constructor(readonly id: string, readonly uses: string[], readonly hasHistory: boolean) {
    super(
      hasHistory
        ? `'${id}' has money history (${uses.join(", ")}). The ledger is kept forever, so this ` +
            "account can be disabled but never deleted."
        : `'${id}' is still used by ${uses.join(", ")}. Remove those first, or disable the account instead.`
    );
    this.name = "AccountInUseError";
  }
}

/**
 * Deletes an account that nothing uses.
 *
 * <p>Since gateway migration V1.55.0 the logins, balance, ledger, reservations, sender IDs,
 * templates and whitelist policies all hold a foreign key to `app_account`, ON DELETE RESTRICT, so
 * this is a real delete rather than the removal of a name it used to be ("nothing cascades, the id
 * reappears as an orphan"). It asks first, so the refusal names what is in the way instead of
 * surfacing a constraint name. Its portal users go with it -- `app_user` cascades, as it always did.
 *
 * <p>Call records and `usage_daily` are deliberately not counted: they keep the id after the
 * account is gone, which is what lets history outlive a customer.
 *
 * @throws AccountInUseError when anything still references the account
 */
export async function deleteAccount(id: string): Promise<boolean> {
  const [use] = await configQuery<Record<string, string>>(
    `SELECT (SELECT count(*) FROM app_credential WHERE account_id = $1)::text AS logins,
            (SELECT count(*) FROM account_balance WHERE account_id = $1)::text AS balance,
            (SELECT count(*) FROM balance_ledger WHERE account_id = $1 OR counterparty_account_id = $1)::text AS ledger,
            (SELECT count(*) FROM balance_reservation WHERE account_id = $1)::text AS reservations,
            (SELECT count(*) FROM app_header WHERE account_id = $1)::text AS senders,
            (SELECT count(*) FROM app_template WHERE account_id = $1)::text AS templates,
            (SELECT count(*) FROM app_whitelist_policy WHERE account_id = $1)::text AS policies,
            (SELECT count(*) FROM app_account WHERE parent_account_id = $1)::text AS children`,
    [id]
  );
  const words: [string, string, string][] = [
    ["logins", "login", "logins"], ["balance", "a balance", "a balance"],
    ["ledger", "ledger entry", "ledger entries"], ["reservations", "credit reservation", "credit reservations"],
    ["senders", "sender ID", "sender IDs"], ["templates", "template", "templates"],
    ["policies", "whitelist policy", "whitelist policies"], ["children", "child account", "child accounts"],
  ];
  const uses = words
    .filter(([key]) => Number(use[key]) > 0)
    .map(([key, one, many]) => (key === "balance" ? one : `${use[key]} ${Number(use[key]) === 1 ? one : many}`));
  if (uses.length) {
    throw new AccountInUseError(id, uses, Number(use.ledger) > 0 || Number(use.reservations) > 0);
  }
  const rows = await configQuery<{ id: string; label: string | null }>(
    "DELETE FROM app_account WHERE id = $1 RETURNING id, label",
    [id]
  );
  if (!rows.length) {
    return false;
  }
  //`account_updated` covers creation and edits from the catalogue route; the delete is the one
  //catalogue write that had no line, and the one after which the row cannot say anything itself
  await auditConfigChange({ domain: "account", name: id, action: "delete", account: id, before: { label: rows[0].label } });
  return true;
}

function toSummary(row: AccountRow): AccountSummary {
  return {
    id: row.id,
    label: row.label,
    description: row.description,
    enabled: row.enabled,
    email: row.email,
    resells: row.resells ?? false,
    parentAccountId: row.parent_account_id,
    updatedAt: row.updated_at ? new Date(row.updated_at).toISOString() : null,
    archivedAt: row.archived_at ? new Date(row.archived_at).toISOString() : null,
    archivedBy: row.archived_by ?? null,
    externalRef: row.external_ref ?? null,
    credentialCount: Number(row.credential_count ?? 0),
    childCount: Number(row.child_count ?? 0),
    ruleCount: Number(row.rule_count ?? 0),
    collidesWithVendor: row.collides ?? false,
  };
}
