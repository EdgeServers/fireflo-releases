import { cdrQuery } from "@/lib/cdr-tier";
import { ServiceUnavailableError } from "@/lib/control-route";
import { query } from "@/lib/metrics-db";
import { hasUsageDailyLogin, hasUsageHourly, hasUsageHourlyLogin, hasVendorAttempt, hourlyWatermark } from "@/lib/metrics-schema";
import { billingZone } from "@/lib/platform-currency";
import {
  grainFor,
  parseUsageFilters,
  USAGE_PAGE_SIZE,
  type UsageBucket,
  type UsageFilters,
  type UsageGridRow,
  type UsageGridView,
} from "@/lib/usage-grid";
import { usageBucketsSql, usageRowsSql, type UsageGrain } from "@/lib/usage-grid-sql";
import { formatTimestamp, zoneShortName } from "@/lib/datetime";

/**
 * Report > Usage's reads (0.15.1): the account × login × product rows, the window's buckets and one
 * row's breakdown, all from the summaries (`usage-grid-sql.ts`). Server-only.
 *
 * <p><strong>Never the busy tables.</strong> The records are read only for what no summary holds
 * yet, the minutes past the hourly watermark, so a watermark more than {@link MAX_EDGE_MS} behind is
 * refused with a sentence rather than read around: the page says the summary has stopped, and no
 * toggle or filter can turn it into a scan of the call records.
 */

/** The most the raw edge may span: the summary's watermark this far behind is a stopped summary. */
export const MAX_EDGE_MS = 3 * 3_600_000;

const HOURS: Record<string, number> = { "1h": 1, "24h": 24 };
const DAYS: Record<string, number> = { "7d": 7, "30d": 30 };

interface Window {
  since: Date;
  until: Date;
  /** Where the records may first be read: the start of the hours (the end of the rolled days). */
  hourlyLo: Date;
  grain: UsageGrain;
  zone: string;
}

/**
 * The window in the billing zone: a date range's days, both included, ending no later than now; the
 * hour and the 24 hours as they say; 7 and 30 days from the start of that billing day.
 */
async function windowFor(range: string, f: UsageFilters): Promise<Window> {
  const zone = await billingZone();
  const grain = grainFor(range, f);
  let since: string;
  let until: string;
  const params: unknown[] = [zone];
  if (f.from && f.to) {
    params.push(f.from, f.to);
    since = "(($2::date)::timestamp AT TIME ZONE $1)";
    until = "LEAST(now(), (($3::date + 1)::timestamp AT TIME ZONE $1))";
  } else if (HOURS[range]) {
    params.push(HOURS[range]);
    since = "now() - make_interval(hours => $2::int)";
    until = "now()";
  } else {
    params.push(DAYS[range] ?? 7);
    since = "((((now() - make_interval(days => $2::int)) AT TIME ZONE $1)::date)::timestamp AT TIME ZONE $1)";
    until = "now()";
  }
  const hourlyLo = grain === "day"
    ? `LEAST(w.until, GREATEST(w.since, COALESCE((SELECT (c.last_daily_day::timestamp AT TIME ZONE $1) FROM usage_rollup_cursor c), w.since)))`
    : "w.since";
  const [w] = await query<{ since: Date; until: Date; hourly_lo: Date }>(
    //the zone is named in every shape, typed, though the hour ranges read no billing day
    `SELECT w.since, w.until, ${hourlyLo} AS hourly_lo FROM (SELECT ${since} AS since, ${until} AS until, $1::text AS zone) w`,
    params
  );
  return { since: new Date(w.since), until: new Date(w.until), hourlyLo: new Date(w.hourly_lo), grain, zone };
}

/** The summaries this page reads, or a refusal in words when they cannot answer it alone. */
async function readiness(window: Window) {
  if (!(await hasUsageHourly())) {
    throw new ServiceUnavailableError(
      "This page reads the gateway's usage summaries, which arrive with gateway 0.12.16 (V1.91.0).");
  }
  const hwm = await hourlyWatermark();
  const edgeEnd = Math.min(window.until.getTime(), Date.now());
  if (!hwm || edgeEnd - hwm.getTime() > MAX_EDGE_MS) {
    throw new ServiceUnavailableError(
      `The gateway's hourly usage summary ${hwm ? `has not moved since ${await stamped(hwm)}` : "has not started"}. `
        + "This page reads only the summaries, never the call records, so it shows figures again once the "
        + "summary is running (Gateway › Usage summaries).");
  }
  const [vendorAttempt, dailyLogin, hourlyLogin] = await Promise.all([hasVendorAttempt(), hasUsageDailyLogin(), hasUsageHourlyLogin()]);
  return { vendorAttempt, dailyLogin, hourlyLogin };
}

const num = (v: unknown) => Number(v ?? 0);

/**
 * An instant in words for a message the server writes: in the billing zone, named. The server
 * does not know the reader's display zone, and the platform's is the one everyone shares.
 */
async function stamped(at: Date): Promise<string> {
  const zone = await billingZone();
  return `${formatTimestamp(at, zone)} ${zoneShortName(zone, at)}`;
}

function toBucket(r: Record<string, unknown>): UsageBucket {
  return {
    bucket: String(r.bucket),
    submitted: num(r.submitted),
    delivered: num(r.delivered),
    failed: num(r.failed),
    pending: num(r.pending),
    price: num(r.price),
  };
}

function filtersOf(params: URLSearchParams): UsageFilters {
  const f = parseUsageFilters(params);
  if ("error" in f) {
    throw new Error(f.error);
  }
  return f;
}

/** One page of rows and every bucket of the window, under the page's filters. */
export async function usageGrid(range: string, params: URLSearchParams): Promise<UsageGridView> {
  const f = filtersOf(params);
  const window = await windowFor(range, f);
  const have = await readiness(window);
  const page = Math.max(0, Math.min(10_000, Math.trunc(Number(params.get("page") ?? 0)) || 0));
  const binds = [window.since, window.until, window.zone, f.account, f.login, f.product];
  const options = { grain: window.grain, vendorAttempt: have.vendorAttempt, dailyLogin: have.dailyLogin, hourlyLogin: have.hourlyLogin };
  //the records are read from where the hours begin at the earliest, so that picks the tables
  const [rows, series] = await Promise.all([
    cdrQuery<Record<string, unknown>>(usageRowsSql(options), [...binds, USAGE_PAGE_SIZE, page * USAGE_PAGE_SIZE], window.hourlyLo),
    cdrQuery<Record<string, unknown>>(usageBucketsSql({ ...options, match: "filter" }), binds, window.hourlyLo),
  ]);
  return {
    grain: window.grain,
    since: window.since.toISOString(),
    until: window.until.toISOString(),
    page,
    pageSize: USAGE_PAGE_SIZE,
    totalRows: num(rows[0]?.total_rows),
    rows: rows.map((r): UsageGridRow => ({
      accountId: (r.account_id as string | null) ?? null,
      login: (r.login as string | null) ?? null,
      product: (r.product as string | null) ?? null,
      submitted: num(r.submitted),
      delivered: num(r.delivered),
      failed: num(r.failed),
      pending: num(r.pending),
      price: num(r.price),
    })),
    series: series.map(toBucket),
    logins: { daily: have.dailyLogin, hourly: have.hourlyLogin },
  };
}

/**
 * One row's hours (24 hours, a date range under two days) or days (7 and 30 days): every bucket of
 * the window, those with nothing in them as zeros. The row is named by `ra`, `rl` and `rp`, each
 * absent for "none" -- matched exactly, so the sub-rows add up to the row.
 */
export async function usageBreakdown(range: string, params: URLSearchParams): Promise<{ grain: UsageGrain; buckets: UsageBucket[] }> {
  const f = filtersOf(params);
  const window = await windowFor(range, f);
  const have = await readiness(window);
  const key = (name: string) => {
    const v = (params.get(name) ?? "").trim();
    return v && v.length <= 200 ? v : null;
  };
  const buckets = await cdrQuery<Record<string, unknown>>(
    usageBucketsSql({ grain: window.grain, vendorAttempt: have.vendorAttempt, dailyLogin: have.dailyLogin,
      hourlyLogin: have.hourlyLogin, match: "exact" }),
    [window.since, window.until, window.zone, key("ra"), key("rl"), key("rp")],
    window.hourlyLo
  );
  return { grain: window.grain, buckets: buckets.map(toBucket) };
}
