/**
 * The live traffic chart's reads, shared: one read per (kind, key) at a time, and an answer kept for
 * a few seconds that serves every later slice it covers.
 *
 * <p>The chart polls every ten seconds per open tab, each asking for the slice since its own last
 * read. Without this, N tabs on one key were N reads of the same receipts every ten seconds. Now a
 * read starting at `from` answers any caller asking from `from` or later while it is fresh (or
 * running): the rows are cut to the caller's start and the answer says where it starts, so the
 * chart replaces exactly what it is handed.
 *
 * <p>Buckets are aligned to the epoch ({@link liveBucketFloor}), so a slice of a longer read is
 * the same set of whole buckets a read of its own would have made. A failure is not kept and
 * reaches the caller, as it always did. Pure: no database import.
 */

/** The start of the `bucketSeconds` bucket `ms` falls in, aligned to the Unix epoch. */
export function liveBucketFloor(ms: number, bucketSeconds: number): number {
  const w = bucketSeconds * 1000;
  return Math.floor(ms / w) * w;
}

export interface LiveSlice<R> {
  rows: R[];
  /** Where these rows start: the caller's bucket-aligned start. */
  since: number;
  until: number;
}

interface Kept<R> {
  since: number;
  rows: R[];
  until: number;
  at: number;
}

export class LiveSliceCache<R extends { t: number }> {
  private readonly entries = new Map<string, Kept<R>>();
  private readonly running = new Map<string, { since: number; p: Promise<{ rows: R[]; until: number }> }>();
  private readonly ttlMs: number;
  private readonly max: number;
  private readonly now: () => number;

  constructor(o: { ttlMs: number; max?: number; now?: () => number }) {
    this.ttlMs = o.ttlMs;
    this.max = o.max ?? 200;
    this.now = o.now ?? Date.now;
  }

  /**
   * Rows from `from` on for `id`: from a fresh kept read, or a running one, that starts at or
   * before `from`; otherwise from a read of `read(from)`, which is then kept.
   */
  async get(id: string, from: number, read: (from: number) => Promise<{ rows: R[]; until: number }>): Promise<LiveSlice<R>> {
    const kept = this.entries.get(id);
    if (kept && this.now() - kept.at < this.ttlMs && kept.since <= from) {
      return slice(kept.rows, from, kept.until);
    }
    const going = this.running.get(id);
    if (going && going.since <= from) {
      const v = await going.p;
      return slice(v.rows, from, v.until);
    }
    const p = read(from);
    this.running.set(id, { since: from, p });
    try {
      const v = await p;
      this.entries.delete(id);
      this.entries.set(id, { since: from, rows: v.rows, until: v.until, at: this.now() });
      while (this.entries.size > this.max) {
        this.entries.delete(this.entries.keys().next().value as string);
      }
      return { rows: v.rows, since: from, until: v.until };
    } finally {
      if (this.running.get(id)?.p === p) {
        this.running.delete(id);
      }
    }
  }
}

function slice<R extends { t: number }>(rows: R[], from: number, until: number): LiveSlice<R> {
  return { rows: rows.filter((r) => r.t >= from), since: from, until };
}
