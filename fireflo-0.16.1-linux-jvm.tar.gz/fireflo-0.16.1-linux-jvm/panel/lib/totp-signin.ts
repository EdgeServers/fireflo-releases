/**
 * The sign-in form's half of the two-factor second step: reading the token out of next-auth's
 * answer, and what to say about the code. Client-safe.
 */

/** The prefix `lib/auth.ts` puts on the `CredentialsSignin` code that carries the token. */
const PREFIX = "totp.";

/** The second-step token in a sign-in answer's `code`, or null when the answer was something else. */
export function pendingTokenFrom(code: string | null | undefined): string | null {
  return typeof code === "string" && code.startsWith(PREFIX) && code.length > PREFIX.length
    ? code.slice(PREFIX.length)
    : null;
}

/** Whether the second step's token has lapsed or been spent: the form goes back to the first step. */
export function pendingExpired(code: string | null | undefined): boolean {
  return code === "totp_expired";
}

/** A code as the form sends it: digits only, at most six. */
export function cleanCode(typed: string): string {
  return typed.replace(/\D/g, "").slice(0, 6);
}

export const TOTP_WRONG =
  "That code did not work. Use the newest code your authenticator shows, and check the phone's clock is set automatically.";

export const TOTP_EXPIRED = "That took too long, so sign in again. The code step lasts five minutes.";

export const TOTP_LOST =
  "Lost your authenticator? An admin can reset it on the server with: fireflo user totp-reset --email you@example.com";
