import { GatewayError, gqlData } from "@/lib/gateway-graphql";
import { HEALTH } from "@/lib/gateway-queries";
import { isConfigured } from "@/lib/metrics-db";
import { isConfigWritable } from "@/lib/config-db";
import {
  flattenHealth,
  readsCredentialsFromDatabase,
  readsRatesFromDatabase,
  readsRoutingFromDatabase,
  readsWorkersFromDatabase,
  type Health,
  type HealthField,
} from "@/lib/health-types";
import { listRouteTables } from "@/lib/routing";
import { listWorkers } from "@/lib/workers";
import { listFilters } from "@/lib/filters";
import { summariseRejected } from "@/lib/rejected";
import { listThrottles } from "@/lib/throttles";
import { listUnratedAccountProducts } from "@/lib/rates";
import { listExemptProducts, listWhitelistSummaries } from "@/lib/whitelist";
import { diagnose, type DiagnosisInput, type Finding, type WorkerState } from "@/lib/delivery-diagnosis";

/**
 * Gathers everything the diagnosis needs, and decides nothing.
 *
 * <p>Every judgement lives in `lib/delivery-diagnosis.ts`, which takes plain data — so the rules
 * are testable without a database and this module stays a list of reads.
 *
 * <p><strong>Every read degrades rather than throws.</strong> Both database connections are
 * independently optional and the gateway may be unreachable, so a check run on a half-configured
 * panel has to return the part it could see. A diagnostic that 500s during an incident is worse
 * than one that reports less.
 */

/**
 * Live gateway state, or why there is none.
 *
 * <p>The three-valued answer is the point. Swallowing the failure makes "the ops token is wrong"
 * indistinguishable from "no vendor is connected", and for a report about why nothing is
 * delivering that conflation would manufacture an outage. The `GatewayError` code says which:
 * NOT_CONFIGURED is the URL or the token unset, UNREACHABLE is no answer at all, and everything
 * else -- a 404 for a wrong token, an address off the allow-list, a 0.12 gateway -- is a refusal
 * that the source deliberately does not narrow further.
 */
export async function readHealth(): Promise<
  { health: Health } | { unavailable: "not-configured" | "unreachable" | "refused" }
> {
  try {
    const field = await gqlData<HealthField | null>({ query: HEALTH });
    if (!field) {
      return { unavailable: "unreachable" };
    }
    return { health: flattenHealth(field) };
  } catch (err) {
    if (err instanceof GatewayError) {
      if (err.code === "NOT_CONFIGURED") return { unavailable: "not-configured" };
      if (err.code === "UNREACHABLE") return { unavailable: "unreachable" };
      return { unavailable: "refused" };
    }
    return { unavailable: "unreachable" };
  }
}

/** How far back the refusal evidence looks. A day: long enough to catch a nightly job. */
const WINDOW_HOURS = 24;

/**
 * How many recent refusals the summary is counted over.
 *
 * <p>Not the whole window. The aggregate was time-bounded but otherwise unbounded, and once 24
 * hours grew past roughly a tenth of `cdr_rejected` the planner stopped using the index and read
 * the table — gigabytes of heap I/O on one of only eight metrics connections, cancelled at the 10s
 * statement timeout with the pages already pulled through shared buffers.
 *
 * <p>5,000 is chosen against what the check does with the number: `diagnose` calls a reason
 * "stopping" at 100 messages, so a sample this size still resolves that threshold with room to
 * spare, while being a fixed cost no matter how large the table gets.
 *
 * <p>The UI must present these as counts of a sample. See DeliveryCheck's own note.
 */
export const REFUSAL_SAMPLE = 5_000;

export async function runDeliveryCheck(accountId: string | null): Promise<{
  findings: Finding[];
  /** Named so the report can say what it could not look at, rather than implying it was clean. */
  skipped: string[];
  /**
   * Vendors the gateway currently holds sessions to.
   *
   * <p>The only sane candidates for a catch-all: pointing one at a vendor that is not connected is
   * the same outage with an extra step. Empty when health could not be read, which is why the
   * dialog offering them says so rather than presenting an empty list as "no vendors".
   */
  boundVendors: string[];
}> {
  const skipped: string[] = [];
  const live = await readHealth();
  const health = "health" in live ? live.health : null;

  const input: DiagnosisInput = {
    accountId,
    readsFromDatabase: {
      routing: readsRoutingFromDatabase(health),
      credentials: readsCredentialsFromDatabase(health),
      rates: readsRatesFromDatabase(health),
      workers: readsWorkersFromDatabase(health),
    },
    healthUnavailable: "unavailable" in live ? live.unavailable : undefined,
  };

  if (isConfigured()) {
    const since = new Date(Date.now() - WINDOW_HOURS * 3600_000);
    await attempt(skipped, "what was refused", async () => {
      //the aggregate alone. This used to call the row query with a limit of 1 and throw the row
      //away; asking the summary directly is both what it meant and one less statement
      const page = await summariseRejected(
        { since, accountId: accountId ?? undefined },
        { sampleLimit: REFUSAL_SAMPLE }
      );
      input.refusals = { summary: page.summary, total: page.total, hours: WINDOW_HOURS,
        sampledOver: REFUSAL_SAMPLE };
    });
    //SMPP throttles are minute counts in their own table (0.15.1); absent before V1.118.0, which is
    //not something this check could not look at, so it is not listed as skipped
    await attempt(skipped, "SMPP throttles", async () => {
      const page = await listThrottles({ since, accountId: accountId ?? undefined });
      if (page.data) {
        input.throttles = { total: page.data.total, hours: WINDOW_HOURS, top: page.data.groups.slice(0, 5) };
      }
    });
  } else {
    skipped.push("what was refused (METRICS_DATABASE_URL is not set)");
  }

  if (!isConfigWritable()) {
    skipped.push("routing, vendors, filters and approvals (CONFIG_DATABASE_URL is not set)");
    return { findings: diagnose(input), skipped, boundVendors: [] };
  }

  await attempt(skipped, "routing tables", async () => {
    input.routing = { tables: await listRouteTables() };
  });
  await attempt(skipped, "filters", async () => {
    input.filters = (await listFilters()).map((f) => ({
      name: f.name,
      enabled: f.enabled,
      conditionCount: f.conditions.length,
    }));
  });
  await attempt(skipped, "vendors and listeners", async () => {
    const workers = [...await listWorkers("smppclient"), ...await listWorkers("smppserver")];
    input.workers = workers.map((w): WorkerState => {
      const seen = health?.workers?.find((h) => h.name === w.name);
      return {
        name: w.name,
        type: w.type,
        enabled: w.enabled,
        //undefined, not 0, when health could not be read or the gateway has never heard of it
        bound: health && seen ? (seen.bound ?? 0) : undefined,
      };
    });
  });
  await attempt(skipped, "sender ID and content approvals", async () => {
    const summaries = await listWhitelistSummaries();
    input.whitelist = {
      summaries,
      exemptProducts: await listExemptProducts(),
      accounts: summaries.map((s) => ({ accountId: s.accountId, product: s.product })),
    };
  });

  //after the whitelist read rather than beside the routing one, because the order findings are built
  //in is fixed by `diagnose` and this only has to be present by the time it runs
  await attempt(skipped, "which accounts have a price", async () => {
    input.unratedProducts = await listUnratedAccountProducts(accountId);
  });

  //only vendors the gateway says it is actually connected to. A catch-all pointed at a vendor that
  //is not bound is the same outage with an extra step
  const boundVendors = (health?.workers ?? [])
    .filter((w) => w.type === "smppclient" && (w.bound ?? 0) > 0)
    .map((w) => w.name);

  return { findings: diagnose(input), skipped, boundVendors };
}

/**
 * Runs one read, and records it as skipped rather than failing the whole check.
 *
 * <p>Named in `skipped` so the report can say what it did not look at. A check that quietly
 * examined six things out of eight and reported "nothing wrong" would be worse than no check.
 */
async function attempt(skipped: string[], what: string, run: () => Promise<void>): Promise<void> {
  try {
    await run();
  } catch (err) {
    skipped.push(`${what} (${err instanceof Error ? err.message : "could not be read"})`);
  }
}
