import type { RoutingGroupLike, RoutingTableLike } from "./connectivity-data.ts";
import { failureBody, missingAfter, type GatewayFailureBody } from "./gateway-slow.ts";
import { ROUTING_VIEW } from "./gateway-queries.ts";

/**
 * The gateway's in-memory routing (gateway 0.15.1, capability `routing_view`): the tables and route
 * groups `StandardRoutingManager` holds and applies now. What a live map should show -- not what the
 * database says the next reload will apply -- and no PostgreSQL read on the panel's side, so the
 * Connectivity page reads nothing from the database at all.
 *
 * <p><strong>This file is the adapter.</strong> The document, the wire types, their normalisation to
 * the shapes the map reads (`RoutingTableLike`, `RoutingGroupLike` in `lib/connectivity-data.ts`) and
 * the route's whole answer ({@link readRoutingView}, with the gateway calls passed in) live here, so
 * if the gateway's schema moves, little else does; `gateway-routing-view.test.ts` tests it without
 * Next or a gateway.
 *
 * <p>The document stays here, not in `gateway-queries.ts`, until the gateway's published schema
 * (`lib/__fixtures__/schema.graphql`) carries `routing`: `gateway-queries.test.ts` holds every
 * document there to that schema, and this one would fail it. Move it beside the live ones when the
 * fixture is refreshed from a gateway that has the field.
 */


/** The `routing` document lives beside the other gateway documents; kept under its old name for the callers. */
export const ROUTING_VIEW_QUERY = ROUTING_VIEW;

/** A rule as the router holds it. `kind` says what `target` resolved to (a worker, a table, a group). */
export interface RoutingRuleWire {
  seq: number;
  target: string;
  kind?: string | null;
  copied?: boolean | null;
  enabled?: boolean | null;
  label?: string | null;
}

export interface RoutingTableWire {
  name: string;
  rules?: RoutingRuleWire[] | null;
}

export interface RoutingGroupMemberWire {
  worker: string;
  weight?: number | null;
  enabled?: boolean | null;
}

export interface RoutingGroupWire {
  name: string;
  members?: RoutingGroupMemberWire[] | null;
}

/** The `routing` field's value. `source` is where the tables were read from (`db`, `file`). */
export interface RoutingViewWire {
  source?: string | null;
  loadedAt?: string | null;
  tables?: RoutingTableWire[] | null;
  groups?: RoutingGroupWire[] | null;
}

export interface RoutingMapRule {
  seq: number;
  target: string;
  kind: string | null;
  copied: boolean;
  enabled: boolean;
  label: string | null;
}

/**
 * A table the router holds. Loaded means applied, so `enabled` is always true: a table switched off
 * is not in the router's memory at all.
 */
export interface RoutingMapTable extends RoutingTableLike {
  name: string;
  enabled: true;
  rules: RoutingMapRule[];
}

export interface RoutingMapGroup extends RoutingGroupLike {
  name: string;
  /** Held by the router, so applied: see {@link RoutingMapTable}. */
  enabled: true;
  members: { workerName: string; weight: number; enabled: boolean }[];
}

/** What `/api/control/connectivity/routing` answers in `data`. */
export interface RoutingMap {
  source: string | null;
  loadedAt: string | null;
  tables: RoutingMapTable[];
  groups: RoutingMapGroup[];
}

/**
 * The wire answer in the map's shapes: rules in `seq` order, nulls read as the gateway's defaults (a
 * rule or member is enabled unless it says otherwise, a weight is 1), nameless rows dropped.
 */
export function toRoutingMap(wire: RoutingViewWire | null | undefined): RoutingMap {
  return {
    source: wire?.source?.trim() || null,
    loadedAt: wire?.loadedAt ?? null,
    tables: (wire?.tables ?? [])
      .filter((t) => t?.name)
      .map((t) => ({
        name: t.name,
        enabled: true as const,
        rules: (t.rules ?? [])
          .filter((r) => r?.target)
          .map((r) => ({
            seq: Number(r.seq) || 0,
            target: r.target,
            kind: r.kind ?? null,
            copied: r.copied === true,
            enabled: r.enabled !== false,
            label: r.label ?? null,
          }))
          .sort((a, b) => a.seq - b.seq),
      })),
    groups: (wire?.groups ?? [])
      .filter((g) => g?.name)
      .map((g) => ({
        name: g.name,
        enabled: true as const,
        members: (g.members ?? [])
          .filter((m) => m?.worker)
          .map((m) => ({ workerName: m.worker, weight: m.weight != null && m.weight > 0 ? m.weight : 1, enabled: m.enabled !== false })),
      })),
  };
}

export interface RoutingViewDeps {
  /**
   * Whether the gateway may have `routing_view`: false only once it said it has not. Never asks the
   * gateway before the read; asked again after a refused read, to tell a 204 from a 502.
   */
  available(): Promise<boolean>;
  /** The `routing` field's value. */
  view(): Promise<RoutingViewWire | null>;
}

export type RoutingViewAnswer =
  | { status: 204 }
  | { status: 200; body: { data: RoutingMap } }
  | { status: 502; body: GatewayFailureBody };

/**
 * The route's answer: 204 when the gateway has no `routing_view` (the page then reads the two config
 * routes), the map when it has, 502 when it could not be asked.
 */
export async function readRoutingView(deps: RoutingViewDeps): Promise<RoutingViewAnswer> {
  try {
    if (!(await deps.available())) {
      return { status: 204 };
    }
    return { status: 200, body: { data: toRoutingMap(await deps.view()) } };
  } catch (err) {
    if (await missingAfter(err, deps.available)) {
      return { status: 204 };
    }
    return { status: 502, body: failureBody(err) };
  }
}

/**
 * A gateway's answer as the contract describes it, for tests and for working on the page before a
 * gateway with the field is at hand: one table into a group of two SMPPSim binds, a copy rule, and a
 * switched-off rule.
 */
export const MOCK_ROUTING_VIEW: RoutingViewWire = {
  source: "db",
  loadedAt: "2026-10-30T09:00:00Z",
  tables: [
    {
      name: "default",
      rules: [
        { seq: 20, target: "audit", kind: "WORKER", copied: true, enabled: true, label: "copy to audit" },
        { seq: 10, target: "sim-lb", kind: "GROUP", copied: false, enabled: true, label: null },
        { seq: 30, target: "old-vendor", kind: "WORKER", copied: false, enabled: false, label: "retired" },
      ],
    },
  ],
  groups: [
    {
      name: "sim-lb",
      members: [
        { worker: "sim1", weight: 1, enabled: true },
        { worker: "sim2", weight: null, enabled: true },
      ],
    },
  ],
};
