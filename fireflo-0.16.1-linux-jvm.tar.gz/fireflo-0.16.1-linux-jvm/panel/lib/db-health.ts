import type { PoolReport, PoolsReport } from "./db-pools.ts";
import type { Health, HealthDatabase } from "./health-types.ts";
import { localeNumber } from "./format.ts";

/**
 * The database as the gateway's ingresses see it (0.15.1), as the Queues and Health pages show it:
 * latency, pool wait, the admission state, refusals since start, the receipt store's write-behind
 * buffer and the call-record spill alarm. Pure, so the tones are tested without a page.
 */

export type DbTone = "default" | "success" | "warning" | "destructive";

export interface DbFact {
  key: string;
  label: string;
  value: string;
  tone: DbTone;
  hint: string;
}

/** The admission state's colour: OK is quiet, DEGRADED refuses the accounts above their share, REFUSING refuses everyone new. */
export const ADMISSION_TONE: Record<"OK" | "DEGRADED" | "REFUSING", DbTone> = {
  OK: "success",
  DEGRADED: "warning",
  REFUSING: "destructive",
};

const ms = (v: number) => `${localeNumber(Math.round(v))} ms`;

/**
 * The facts present in this health, in reading order; empty from a gateway before 0.15.1 (or one
 * with no database), which the pages take as "draw nothing" rather than a row of dashes.
 */
export function dbHealthFacts(h: Health | null | undefined): DbFact[] {
  if (!h) {
    return [];
  }
  const out: DbFact[] = [];
  if (h.db_admission) {
    out.push({
      key: "admission",
      label: "Database admission",
      value: h.db_admission,
      tone: ADMISSION_TONE[h.db_admission] ?? "default",
      hint: h.db_admission === "OK"
        ? "New submits are admitted"
        : h.db_admission === "DEGRADED"
          ? "Accounts above their share are refused dbUnavailable"
          : "Every new submit is refused dbUnavailable, before the charge",
    });
  }
  if (h.db_latency_ms != null) {
    out.push({
      key: "latency",
      label: "Database latency",
      value: ms(h.db_latency_ms),
      tone: h.db_admission && h.db_admission !== "OK" ? ADMISSION_TONE[h.db_admission] : "default",
      hint: "The hot writers' statements, averaged, every 2 s",
    });
  }
  if (h.db_pool_wait_ms != null) {
    out.push({
      key: "pool",
      label: "Pool wait",
      value: ms(h.db_pool_wait_ms),
      tone: h.db_pool_wait_ms >= 500 ? "warning" : "default",
      hint: "Time to take a connection from the main pool",
    });
  }
  if (h.db_refused_total != null) {
    out.push({
      key: "refused",
      label: "Refused, database",
      value: localeNumber(h.db_refused_total),
      tone: h.db_refused_total > 0 ? "warning" : "default",
      hint: "Submits refused dbUnavailable since start",
    });
  }
  if (h.dlr_store_buffer != null) {
    out.push({
      key: "dlr-buffer",
      label: "Receipt-store buffer",
      value: localeNumber(h.dlr_store_buffer),
      tone: h.dlr_store_buffer >= 1_000 ? "warning" : "default",
      hint: "Receipt writes waiting to commit; near zero when the database keeps up",
    });
  }
  if (h.cdr?.spill_over_cap != null) {
    out.push({
      key: "spill",
      label: "Call-record spill",
      value: h.cdr.spill_over_cap ? "over its cap" : "within its cap",
      tone: h.cdr.spill_over_cap ? "destructive" : "default",
      hint: h.cdr.spill_over_cap
        ? "Past smsg.cdr.spill.max.mb: nothing is dropped, but restore the database and re-import"
        : "smsg.cdr.spill.max.mb",
    });
  }
  return out;
}

/**
 * One row of the Database card's three blocks (0.15.1): a label and a value, with the tone and an
 * optional tooltip. `at` asks the card to format `value` as a timestamp in the browser's zone.
 */
export interface DbRow {
  key: string;
  label: string;
  value: string;
  tone: DbTone;
  title?: string;
  at?: boolean;
}

export interface DbCardBlocks {
  /** The admission state for the header's badge; null from a gateway before 0.15.1. */
  admission: DbFact | null;
  /** "Connection · gateway → PostgreSQL", from `health.database` (`db_info`); empty without it. */
  gateway: DbRow[];
  /** "Connection · panel → PostgreSQL", from the pools route; empty until it answers. */
  panel: DbRow[];
  /** "Admission": latency against its thresholds, refusals, the receipt buffer, the spill. */
  checks: DbRow[];
}

/**
 * The gateway's coded admission thresholds (DbLatencyMonitor: `smsg.db.latency.lowwater.ms` 500,
 * `smsg.db.latency.highwater.ms` 2000). Health does not carry the configured values, so the card
 * says the defaults and names the keys in the tooltip.
 */
export const ADMISSION_LOWWATER_MS = 500;
export const ADMISSION_HIGHWATER_MS = 2_000;

const num = (v: number | string | null | undefined): number | null => {
  if (v == null || v === "") {
    return null;
  }
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

/** "db.internal (10.128.0.2):5432", the way the panel's footer and endpointLabel name a server. */
export function serverLabel(d: HealthDatabase): string | null {
  const host = d.host?.trim() || null;
  const ip = d.ip?.trim() || null;
  const shown = host && ip && ip !== host ? `${host} (${ip})` : host ?? ip;
  if (!shown) {
    return null;
  }
  const port = d.port == null || d.port === "" ? null : String(d.port);
  return port ? `${shown}:${port}` : shown;
}

function gatewayRows(d: HealthDatabase | null | undefined): DbRow[] {
  if (!d) {
    return [];
  }
  const out: DbRow[] = [];
  const server = serverLabel(d);
  const name = d.name?.trim();
  if (server || name) {
    out.push({ key: "gw-server", label: "Server", value: [server, name].filter(Boolean).join(" · "), tone: "default" });
  }
  if (d.server_version?.trim()) {
    out.push({ key: "gw-version", label: "PostgreSQL", value: d.server_version.trim(), tone: "default" });
  }
  if (d.schema_version?.trim()) {
    out.push({ key: "gw-schema", label: "Schema", value: d.schema_version.trim(), tone: "default" });
  }
  const active = num(d.pool?.active);
  const max = num(d.pool?.max);
  if (active != null && max != null) {
    const waiting = num(d.pool?.waiting);
    const lane = (n: string, l: { max?: number | null; active?: number | null } | null | undefined) =>
      num(l?.active) != null && num(l?.max) != null ? `${n} ${num(l?.active)}/${num(l?.max)}` : null;
    const lanes = [lane("lease", d.lanes?.lease), lane("control", d.lanes?.control)].filter(Boolean);
    const parts = [`${localeNumber(active)} of ${localeNumber(max)} in use`];
    if (waiting != null) {
      parts.push(`${localeNumber(waiting)} waiting`);
    }
    if (lanes.length) {
      parts.push(`lanes ${lanes.join(", ")}`);
    }
    const idle = num(d.pool?.idle);
    const timeout = num(d.pool?.acquisition_timeout_ms);
    out.push({
      key: "gw-pool",
      label: "Pool",
      value: parts.join(" · "),
      tone: (waiting ?? 0) > 0 ? "warning" : "default",
      title: [idle != null ? `${idle} idle` : null, timeout != null ? `a caller gives up after ${ms(timeout)}` : null]
        .filter(Boolean).join(" · ") || undefined,
    });
  }
  if (d.connected_since?.trim()) {
    out.push({ key: "gw-since", label: "Connected since", value: d.connected_since.trim(), tone: "default", at: true });
  }
  const probe = num(d.probe_ms);
  const wait = num(d.pool_wait_ms);
  if (probe != null || wait != null) {
    out.push({
      key: "gw-probe",
      label: "Probe",
      value: [probe != null ? ms(probe) : null, wait != null ? `pool wait ${ms(wait)}` : null].filter(Boolean).join(" · "),
      tone: (wait ?? 0) >= 500 ? "warning" : "default",
      title: "The gateway's last SELECT 1, and its last wait for a connection",
    });
  }
  return out;
}

function panelRow(key: string, label: string, p: PoolReport | null | undefined): DbRow | null {
  if (!p) {
    return null;
  }
  if (!p.host) {
    return { key, label, value: "not configured", tone: "default" };
  }
  const parts = [p.host, `${localeNumber(p.size)} connection${p.size === 1 ? "" : "s"}`];
  if (p.waiting > 0) {
    parts.push(`${localeNumber(p.waiting)} waiting`);
  }
  if (p.lastReadMs != null) {
    parts.push(`last read ${ms(p.lastReadMs)}`);
  }
  return {
    key,
    label,
    value: parts.join(" · "),
    tone: p.waiting > 0 ? "warning" : "default",
    title: `${p.open} open, ${p.idle} idle, ${p.waiting} waiting`,
  };
}

/**
 * The Database card's three blocks, each only with the rows this gateway and this panel can fill.
 * A gateway without `health.database` (before 0.15.1's `db_info`) gets no gateway block at all and
 * keeps its pool wait under Admission, where it was; nothing is drawn as a dash.
 */
export function dbCardBlocks(h: Health | null | undefined, pools: PoolsReport | null | undefined): DbCardBlocks {
  const facts = dbHealthFacts(h);
  const by = new Map(facts.map((f) => [f.key, f]));
  const gateway = gatewayRows(h?.database);
  const panel = [panelRow("panel-metrics", "Reports", pools?.metrics), panelRow("panel-config", "Settings", pools?.config)]
    .filter((r): r is DbRow => r != null);
  const checks: DbRow[] = [];
  const latency = by.get("latency");
  if (latency) {
    checks.push({
      key: "latency",
      label: "Latency",
      value: `${latency.value} (degraded above ${localeNumber(ADMISSION_LOWWATER_MS)}, refusing above ${localeNumber(ADMISSION_HIGHWATER_MS)})`,
      tone: latency.tone,
      title: `${latency.hint}. The gateway's defaults for smsg.db.latency.lowwater.ms and smsg.db.latency.highwater.ms`,
    });
  }
  const pool = by.get("pool");
  if (pool && !gateway.some((r) => r.key === "gw-probe")) {
    checks.push({ key: "pool", label: "Pool wait", value: pool.value, tone: pool.tone, title: pool.hint });
  }
  const refused = by.get("refused");
  if (refused) {
    checks.push({ key: "refused", label: "Refused since start", value: refused.value, tone: refused.tone, title: refused.hint });
  }
  const buffer = by.get("dlr-buffer");
  if (buffer) {
    checks.push({ key: "dlr-buffer", label: "Receipt buffer", value: `${buffer.value} waiting`, tone: buffer.tone, title: buffer.hint });
  }
  const spill = by.get("spill");
  if (spill) {
    checks.push({ key: "spill", label: "Call-record spill", value: spill.value, tone: spill.tone, title: spill.hint });
  }
  return { admission: by.get("admission") ?? null, gateway, panel, checks };
}
