/**
 * Reading units accounts (gateway 0.16.0).
 *
 * <p>Server-only, and read-only: the gateway tables through the read-only metrics pool, the stored
 * speed limits and two gateway settings through the config pool. Nothing here writes. Units accounts
 * are created and given units by the platform that manages them, through the gateway's platform API;
 * the panel is the operator's view of them.
 *
 * <p>Every read is one or two small indexed statements: `unit_allowance` by its primary key,
 * `unit_ledger` by `idx_unit_ledger_account`, `unit_usage_hourly` by its primary key
 * `(account_id, hour, product)` over at most 30 days, the hourly summary by `pk_usage_hourly` over a
 * month. None touches the call records.
 */
import { configQuery } from "./config-db";
import { query } from "./metrics-db";
import { billingZone } from "./platform-currency";
import {
  allowanceFrom,
  countsUnits,
  unitsOf,
  UNIT_USAGE_DAYS,
  type SubAccountRow,
  type SubAccountsView,
  type UnitAllowance,
  type UnitLedgerPage,
  type UnitsAccountView,
  type UnitsAvailability,
  type UnitsRate,
  type UnitUsage,
} from "./units-types";

export type { SubAccountsView, UnitLedgerPage, UnitsAccountView } from "./units-types";

/** A ledger page: the money ledger's size. */
export const UNIT_LEDGER_PAGE = 50;

/** Whether `account_balance` says this account is a units account. False with no row. */
export async function isUnitsAccount(account: string): Promise<boolean> {
  const rows = await query<{ billing_mode: string }>(
    "SELECT billing_mode FROM account_balance WHERE account_id = $1",
    [account]
  );
  return rows[0]?.billing_mode === "UNITS";
}

/**
 * Everything the units account's pages show, or null when the account is not a units account.
 * Usage, the stored limits and availability are each allowed to fail without failing the page.
 */
export async function unitsAccountView(account: string): Promise<UnitsAccountView | null> {
  const head = await query<{ billing_mode: string | null; parent: string | null; parent_label: string | null }>(
    `SELECT b.billing_mode, a.parent_account_id AS parent, p.label AS parent_label
       FROM account_balance b
       LEFT JOIN app_account a ON a.id = b.account_id
       LEFT JOIN app_account p ON p.id = a.parent_account_id
      WHERE b.account_id = $1`,
    [account]
  );
  if (head[0]?.billing_mode !== "UNITS") {
    return null;
  }
  const parent = head[0].parent ? { id: head[0].parent, label: head[0].parent_label } : null;

  const [allowances, logins, usage, rate, availability] = await Promise.allSettled([
    allowancesFor([account]),
    query<{ system_id: string; product: string | null; enabled: boolean }>(
      //never password or api_key: a secret that is not read cannot leak through a later change here
      "SELECT system_id, product, enabled FROM app_credential WHERE account_id = $1 ORDER BY system_id",
      [account]
    ),
    usageFor(account),
    rateFor(account, parent?.id ?? null),
    unitsAvailability(),
  ]);

  if (allowances.status === "rejected") {
    throw allowances.reason;
  }
  return {
    account,
    parent,
    allowances: allowances.value.get(account) ?? [],
    usage: usage.status === "fulfilled" ? usage.value : null,
    logins: logins.status === "fulfilled"
      ? logins.value.map((l) => ({ systemId: l.system_id, product: l.product, enabled: l.enabled }))
      : [],
    rate: rate.status === "fulfilled" ? rate.value : null,
    availability: availability.status === "fulfilled" ? availability.value : null,
  };
}

/** Allowances per account, whole units, products in name order. */
async function allowancesFor(accounts: string[]): Promise<Map<string, UnitAllowance[]>> {
  const rows = await query<{ account_id: string; product: string; free: string; reserved: string; used: string; enabled: boolean }>(
    `SELECT account_id, product, free::text, reserved::text, used::text, enabled
       FROM unit_allowance
      WHERE account_id = ANY($1::text[])
      ORDER BY account_id, product`,
    [accounts]
  );
  const map = new Map<string, UnitAllowance[]>();
  for (const r of rows) {
    const list = map.get(r.account_id) ?? [];
    list.push(allowanceFrom(r));
    map.set(r.account_id, list);
  }
  return map;
}

/**
 * One page of the unit ledger, newest first, keyset on `id` (the ledger is append-only, so an id
 * never moves between pages).
 *
 * @param before the `next` of the page before, or null for the newest
 */
export async function unitLedgerPage(account: string, before: string | null): Promise<UnitLedgerPage> {
  const cursor = before && /^\d+$/.test(before) ? before : null;
  const rows = await query<{
    id: string;
    product: string;
    delta: string;
    entry_type: string;
    reference: string;
    counterparty_account_id: string | null;
    note: string | null;
    written_by: string | null;
    created_at: string;
  }>(
    `SELECT id::text, product, delta::text, entry_type, reference, counterparty_account_id, note, written_by, created_at
       FROM unit_ledger
      WHERE account_id = $1 AND ($2::bigint IS NULL OR id < $2::bigint)
      ORDER BY id DESC
      LIMIT $3`,
    [account, cursor, UNIT_LEDGER_PAGE + 1]
  );
  const more = rows.length > UNIT_LEDGER_PAGE;
  const page = rows.slice(0, UNIT_LEDGER_PAGE);
  return {
    entries: page.map((r) => ({
      id: Number(r.id),
      product: r.product,
      //signed as stored: GIVE and MOVE_IN positive, TAKE and MOVE_OUT negative
      units: unitsOf(r.delta),
      entryType: r.entry_type,
      reference: r.reference,
      counterparty: r.counterparty_account_id,
      note: r.note,
      writtenBy: r.written_by,
      createdAt: r.created_at,
    })),
    next: more ? page[page.length - 1].id : null,
  };
}

/** This month and the last {@link UNIT_USAGE_DAYS} days of units used, in the billing time zone. */
async function usageFor(account: string): Promise<UnitUsage> {
  const zone = await billingZone();
  const [month, days] = await Promise.all([
    query<{ product: string; used: string; refunded: string; messages: string }>(
      `SELECT product, sum(used)::text AS used, sum(refunded)::text AS refunded, sum(messages)::text AS messages
         FROM unit_usage_hourly
        WHERE account_id = $1
          AND hour >= (date_trunc('month', now() AT TIME ZONE $2) AT TIME ZONE $2)
        GROUP BY product
        ORDER BY product`,
      [account, zone]
    ),
    query<{ day: string; product: string; used: string; refunded: string; messages: string }>(
      `SELECT ((hour AT TIME ZONE $2)::date)::text AS day, product,
              sum(used)::text AS used, sum(refunded)::text AS refunded, sum(messages)::text AS messages
         FROM unit_usage_hourly
        WHERE account_id = $1 AND hour >= now() - make_interval(days => $3)
        GROUP BY 1, 2
        ORDER BY 1 DESC, 2`,
      [account, zone, UNIT_USAGE_DAYS]
    ),
  ]);
  const row = (r: { product: string; used: string; refunded: string; messages: string }) => ({
    product: r.product,
    used: unitsOf(r.used),
    refunded: unitsOf(r.refunded),
    messages: Number(r.messages),
  });
  return { month: month.map(row), days: days.map((d) => ({ day: d.day, ...row(d) })) };
}

/** The stored speed limits of a units account and its parent. Needs the config database. */
async function rateFor(account: string, parent: string | null): Promise<UnitsRate> {
  const keys = {
    smpp: `outSms.default.conf.maxRate.${account}`,
    http: `smsg.restapi.maxRate.${account}`,
    parentSmpp: parent ? `outSms.default.conf.maxRate.${parent}` : null,
    parentHttp: parent ? `smsg.restapi.maxRate.${parent}` : null,
  };
  const wanted = Object.values(keys).filter((k): k is string => k !== null);
  const [config, listeners] = await Promise.all([
    configQuery<{ key: string; value: string | null }>(
      "SELECT key, value FROM app_config WHERE key = ANY($1::text[]) AND enabled",
      [wanted]
    ),
    configQuery<{ name: string; value: string | null }>(
      `SELECT w.name, p.value
         FROM app_worker w
         JOIN app_worker_property p ON p.worker_name = w.name
        WHERE w.type = 'smppserver' AND p.key = $1
        ORDER BY w.name`,
      [`conf.maxRate.${account}`]
    ),
  ]);
  const got = new Map(config.map((r) => [r.key, r.value?.trim() || null] as const));
  return {
    smpp: got.get(keys.smpp) ?? null,
    smppListeners: listeners
      .filter((l) => (l.value ?? "").trim())
      .map((l) => ({ listener: l.name, value: (l.value ?? "").trim() })),
    http: got.get(keys.http) ?? null,
    parentSmpp: keys.parentSmpp ? got.get(keys.parentSmpp) ?? null : null,
    parentHttp: keys.parentHttp ? got.get(keys.parentHttp) ?? null : null,
  };
}

/** The gateway's own defaults for the node heartbeat and the node timeout (NodeHeartbeat). */
const HEARTBEAT_DEFAULT = 5;
const NODE_TIMEOUT_DEFAULT = 30;

/**
 * Live nodes older than 0.16.0, and whether prepaid enforcement is stored as off -- the two things
 * that stop the gateway creating units accounts, read the way the gateway reads them
 * (`UnitAccountsGate`): a node is live while its heartbeat is within the node timeout, never less
 * than two beats.
 */
export async function unitsAvailability(): Promise<UnitsAvailability> {
  let settings = new Map<string, string>();
  try {
    const rows = await configQuery<{ key: string; value: string | null }>(
      "SELECT key, value FROM app_config WHERE key = ANY($1::text[]) AND enabled",
      [["smsg.balance.enabled", "smsg.cluster.heartbeat.seconds", "smsg.cluster.node.timeout.seconds"]]
    );
    settings = new Map(rows.map((r) => [r.key, (r.value ?? "").trim()] as const));
  } catch {
    //no config database: the defaults below, and nothing known about enforcement
  }
  const whole = (raw: string | undefined, fallback: number) => {
    const n = Number(raw);
    return raw && Number.isInteger(n) && n > 0 ? n : fallback;
  };
  const timeout = Math.max(
    2 * whole(settings.get("smsg.cluster.heartbeat.seconds"), HEARTBEAT_DEFAULT),
    whole(settings.get("smsg.cluster.node.timeout.seconds"), NODE_TIMEOUT_DEFAULT)
  );

  let olderNodes: string[] = [];
  try {
    const nodes = await query<{ node_id: string; version: string }>(
      `SELECT node_id, version FROM gateway_node
        WHERE heartbeat_at >= now() - make_interval(secs => $1)
        ORDER BY node_id`,
      [timeout]
    );
    olderNodes = nodes.filter((n) => !countsUnits(n.version)).map((n) => `${n.node_id} (${n.version})`);
  } catch {
    //no gateway_node (file mode or a schema before V1.103.0): a single gateway, nothing to say
  }
  return { olderNodes, enforcementOff: settings.get("smsg.balance.enabled")?.toLowerCase() === "false" };
}

/**
 * A reseller and the accounts beneath it, units accounts marked, for its Billing tab.
 *
 * <p>Three statements for the list whatever its length (the accounts with their billing mode, their
 * allowances, their logins), and two for messages this month: units accounts from
 * `unit_usage_hourly`, money accounts from `usage_hourly`.
 */
export async function subAccounts(parent: string): Promise<SubAccountsView> {
  const accounts = await query<{ id: string; label: string | null; enabled: boolean; archived: boolean; billing_mode: string | null }>(
    `SELECT a.id, a.label, a.enabled, (a.archived_at IS NOT NULL) AS archived, b.billing_mode
       FROM app_account a
       LEFT JOIN account_balance b ON b.account_id = a.id
      WHERE a.id = $1 OR a.parent_account_id = $1
      ORDER BY (a.id = $1) DESC, a.id`,
    [parent]
  );
  const ids = accounts.map((a) => a.id);
  if (!ids.includes(parent)) {
    ids.unshift(parent);
  }
  const unitIds = accounts.filter((a) => a.billing_mode === "UNITS").map((a) => a.id);
  const moneyIds = ids.filter((id) => !unitIds.includes(id));

  const [allowances, logins, unitMessages, moneyMessages, availability] = await Promise.allSettled([
    unitIds.length ? allowancesFor(unitIds) : Promise.resolve(new Map<string, UnitAllowance[]>()),
    query<{ account_id: string; system_id: string }>(
      "SELECT account_id, system_id FROM app_credential WHERE account_id = ANY($1::text[]) ORDER BY system_id",
      [ids]
    ),
    unitIds.length ? monthMessages("unit_usage_hourly", "messages", unitIds) : Promise.resolve(new Map<string, number>()),
    monthMessages("usage_hourly", "submitted", moneyIds),
    unitsAvailability(),
  ]);

  const loginsBy = new Map<string, string[]>();
  for (const l of logins.status === "fulfilled" ? logins.value : []) {
    loginsBy.set(l.account_id, [...(loginsBy.get(l.account_id) ?? []), l.system_id]);
  }
  const row = (id: string): SubAccountRow => {
    const a = accounts.find((x) => x.id === id);
    const units = a?.billing_mode === "UNITS";
    const counted = units ? unitMessages : moneyMessages;
    return {
      id,
      label: a?.label ?? null,
      units,
      enabled: a?.enabled ?? true,
      archived: a?.archived ?? false,
      logins: loginsBy.get(id) ?? [],
      allowances: units && allowances.status === "fulfilled" ? allowances.value.get(id) ?? [] : [],
      messagesMonth: counted.status === "fulfilled" ? counted.value.get(id) ?? 0 : null,
    };
  };
  return {
    self: row(parent),
    children: ids.filter((id) => id !== parent).map(row),
    availability: availability.status === "fulfilled" ? availability.value : null,
  };
}

/**
 * Messages this month per account from one of the two hourly summaries, in the billing time zone.
 * `table` and `column` are this module's constants, never input.
 */
async function monthMessages(
  table: "unit_usage_hourly" | "usage_hourly",
  column: "messages" | "submitted",
  accounts: string[]
): Promise<Map<string, number>> {
  if (!accounts.length) {
    return new Map();
  }
  const zone = await billingZone();
  const rows = await query<{ account_id: string; messages: string }>(
    `SELECT account_id, sum(${column})::text AS messages
       FROM ${table}
      WHERE account_id = ANY($1::text[])
        AND hour >= (date_trunc('month', now() AT TIME ZONE $2) AT TIME ZONE $2)
      GROUP BY account_id`,
    [accounts, zone]
  );
  return new Map(rows.map((r) => [r.account_id, Number(r.messages)] as const));
}
