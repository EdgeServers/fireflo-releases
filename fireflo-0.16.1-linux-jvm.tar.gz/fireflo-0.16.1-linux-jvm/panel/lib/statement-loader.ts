/**
 * How a statement page asks for its figures: only when told to, newest request wins, and a `202`
 * is waited out rather than shown as an error.
 *
 * <p>Database- and React-free, so the rules can be tested with a fake `fetch` and fake timers; the
 * pages wrap it in `components/useStatement.ts`.
 *
 * <ul>
 *   <li><b>Nothing happens until {@link StatementLoader.show}.</b> Choosing a month or a date range
 *       used to refetch on every change, so stepping through the month list fired a month-sized
 *       statement per step and the last one to finish -- not the last one asked for -- was what
 *       the page showed.</li>
 *   <li><b>One request at a time, and only the newest lands.</b> A new `show` aborts the one in
 *       flight; a late answer for an older one is dropped (`LatestWins`).</li>
 *   <li><b>`202 { busy, retryAfter }` is "still reading".</b> The server goes on reading in the
 *       background (`statement-cache.ts`), so the loader marks itself busy -- the page's breathing
 *       card -- and asks again after `retryAfter` seconds, until an answer or an error comes.</li>
 * </ul>
 */
import { validateRange } from "./date-range.ts";
import { LatestWins } from "./latest-wins.ts";

/** What a page renders from. */
export interface StatementLoadState<T> {
  /** The figures on screen, or null. */
  data: T | null;
  /** The URL `data` (or the request in flight) is for. */
  url: string | null;
  /** A sentence from the server, or about the network. Empty when there is none. */
  error: string;
  /** A request is in flight, or a 202 is being waited out: the Show button's sweep. */
  loading: boolean;
  /** The server said it is still reading: the breathing card. */
  busy: boolean;
  /** Seconds until the next ask, while `busy`. */
  retryAfter: number;
  /** An older answer, because the latest read failed. */
  stale: { at: string; reason: string } | null;
}

export interface LoaderDeps {
  fetch: (url: string, init: { cache: "no-store"; signal: AbortSignal }) => Promise<{
    ok: boolean;
    status: number;
    json: () => Promise<unknown>;
    headers?: { get(name: string): string | null };
  }>;
  setTimer: (fn: () => void, ms: number) => unknown;
  clearTimer: (handle: unknown) => void;
  /** Called with every new state. */
  onChange: (state: StatementLoadState<unknown>) => void;
  /**
   * Called with each answer that landed, for the footer's data-source stat (`page-sources.ts`):
   * the request's URL and the response, whose `X-FireFlo-Source` header says what it cost.
   */
  onAnswer?: (url: string, res: { headers?: { get(name: string): string | null } }) => void;
}

/** When the server names no wait. The stats route's and the statement route's own value. */
const DEFAULT_RETRY_S = 15;

export function initialLoadState<T>(): StatementLoadState<T> {
  return { data: null, url: null, error: "", loading: false, busy: false, retryAfter: DEFAULT_RETRY_S, stale: null };
}

export class StatementLoader<T> {
  private state: StatementLoadState<T> = initialLoadState<T>();
  private readonly gate = new LatestWins();
  private inFlight: AbortController | null = null;
  private retry: unknown = null;
  private readonly deps: LoaderDeps;

  constructor(deps: LoaderDeps) {
    this.deps = deps;
  }

  get current(): StatementLoadState<T> {
    return this.state;
  }

  /**
   * Fetches `url` now. The figures on screen are kept only when they are for the same URL -- a
   * re-read after closing a period -- so a different period never shows under another's controls.
   */
  show(url: string): void {
    const same = this.state.url === url;
    this.set({
      url,
      loading: true,
      error: "",
      ...(same ? {} : { data: null, stale: null, busy: false }),
    });
    void this.ask(url);
  }

  /** Stops the request in flight and any pending retry: the page is going away. */
  dispose(): void {
    this.inFlight?.abort();
    this.inFlight = null;
    this.clearRetry();
    this.gate.begin();
  }

  private async ask(url: string): Promise<void> {
    this.inFlight?.abort();
    this.clearRetry();
    const controller = new AbortController();
    this.inFlight = controller;
    const ticket = this.gate.begin();
    try {
      const res = await this.deps.fetch(url, { cache: "no-store", signal: controller.signal });
      const json = (await res.json().catch(() => null)) as {
        data?: T; error?: string; retryAfter?: number; stale?: { at: string; reason: string };
      } | null;
      if (!this.gate.isCurrent(ticket)) {
        return;
      }
      this.deps.onAnswer?.(url, res);
      if (res.status === 202) {
        //still being read in the background: wait, and ask again, with the card up and no error
        const after = Number(json?.retryAfter) > 0 ? Number(json?.retryAfter) : DEFAULT_RETRY_S;
        this.set({ busy: true, loading: true, retryAfter: after });
        this.retry = this.deps.setTimer(() => {
          this.retry = null;
          void this.ask(url);
        }, after * 1000);
        return;
      }
      if (!res.ok) {
        this.set({
          busy: false,
          loading: false,
          error: json?.error ?? `Could not read the statement (${res.status}).`,
        });
        return;
      }
      this.set({ busy: false, loading: false, data: json?.data ?? null, stale: json?.stale ?? null, error: "" });
    } catch {
      if (controller.signal.aborted || !this.gate.isCurrent(ticket)) {
        return;
      }
      this.set({ busy: false, loading: false, error: "Could not reach the panel. Check the connection and press Show again." });
    } finally {
      if (this.inFlight === controller) {
        this.inFlight = null;
      }
    }
  }

  private clearRetry(): void {
    if (this.retry !== null) {
      this.deps.clearTimer(this.retry);
      this.retry = null;
    }
  }

  private set(next: Partial<StatementLoadState<T>>): void {
    this.state = { ...this.state, ...next };
    this.deps.onChange(this.state as StatementLoadState<unknown>);
  }
}

/** The period controls' draft: a month, or a From/To range. */
export interface PeriodDraft {
  mode: "month" | "range";
  month: string;
  from: string;
  to: string;
}

/**
 * The query string a draft asks for, or why it cannot be asked: the same refusal the route gives,
 * shown beside the controls before anything is sent: From after To, or more than 92 days.
 */
export function periodQuery(draft: PeriodDraft): { query: string } | { invalid: string } {
  if (draft.mode === "month") {
    return { query: `month=${encodeURIComponent(draft.month)}` };
  }
  const invalid = validateRange(draft.from, draft.to);
  return invalid
    ? { invalid }
    : { query: `from=${encodeURIComponent(draft.from)}&to=${encodeURIComponent(draft.to)}` };
}
