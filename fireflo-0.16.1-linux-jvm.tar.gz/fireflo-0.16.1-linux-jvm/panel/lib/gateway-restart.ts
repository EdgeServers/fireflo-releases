import { count } from "./format.ts";
import type { Health, HealthPersistLane } from "./health-types.ts";

/**
 * Restarting one internal part of the running gateway (0.15.2, capability `component_restart`), as
 * the Queues page offers it: the Restart rows on the Database, Kafka backbone and vendor queue cards,
 * the confirmation, the before → after result, and the refusal in plain words.
 *
 * <p>Pure, and free of any server import, so the route, the client components and the tests read
 * one copy. The words a button's help shows and the words its confirmation shows come from
 * {@link RESTART_COPY}: an operator reads the same promise twice, and it cannot drift between them.
 *
 * <p>The gateway's half is `componentRestart(component, target, hard, by): JSON!` (ADMIN), and the
 * same thing as `fireflo restart <part> [target]` on the command line. It restarts the gateway's own
 * connections and threads, never the PostgreSQL or Kafka servers.
 */

/** Every part the gateway restarts, in its own order (`OpsRestartService.PARTS`). */
export const RESTART_PARTS = [
  "persist",
  "db",
  "kafka-router",
  "kafka-consumers",
  "vendor-feed",
  "vendor",
  "jobs",
  "config",
] as const;

export type RestartPart = (typeof RESTART_PARTS)[number];

/** The parts the Queues page has a button for; jobs and config stay on the command line. */
export type QueuesRestartPart = Exclude<RestartPart, "jobs" | "config">;

/** The parts that name a vendor: the restart is that vendor's, and the target is required. */
export const VENDOR_PARTS: readonly RestartPart[] = ["vendor-feed", "vendor"];

/** The persistence streams `persist` may be narrowed to; without one, every stream. */
export const PERSIST_STREAMS = ["cdr", "dlr-store", "unpushed"] as const;

export type PersistStream = (typeof PERSIST_STREAMS)[number];

/** What each stream holds, in words, for the write-behind block and the stream picker. */
export const STREAM_LABEL: Record<string, string> = {
  cdr: "call records",
  "dlr-store": "receipts awaiting a match",
  unpushed: "receipts not yet sent on",
};

/** The longest target the route forwards: a vendor's full name or a stream, never a paragraph. */
export const MAX_TARGET_CHARS = 200;

export function isRestartPart(value: unknown): value is RestartPart {
  return typeof value === "string" && (RESTART_PARTS as readonly string[]).includes(value);
}

/**
 * The words for one part: the button, its help, and the confirmation's facts.
 *
 * <p>Owner rule: help is visible text under the button, never a tooltip. Every field here is shown
 * somewhere, so none of it is decoration -- `bindsDropped` is what an operator most needs to know
 * before pressing, and it is the confirmation's first fact.
 */
export interface RestartCopy {
  /** The button, and the confirm button inside the dialog. */
  label: string;
  /** Under the button. */
  help: string;
  /** The dialog's title, a question. */
  question: string;
  /** The result dialog's title once it ran. */
  done: string;
  /** What happens, in a paragraph. */
  whatHappens: string;
  /** Customer binds: dropped or not. */
  customerBinds: string;
  /** Vendor binds: dropped or not. */
  vendorBinds: string;
  /** Whether any bind drops, for a component that wants a yes or no. */
  dropsBinds: boolean;
  /** What is kept. */
  kept: string;
  /** How long it usually takes. */
  usually: string;
  /** The same thing on the command line, without the target. */
  command: string;
  /** The lucide icon the button carries. */
  icon: "rotate-cw" | "rotate-ccw" | "plug" | "plug-zap";
}

const BINDS_UP = "Not dropped. Customers keep submitting and getting receipts.";

export const RESTART_COPY: Record<QueuesRestartPart, RestartCopy> = {
  persist: {
    label: "Restart writers",
    help:
      "Starts fresh database writers for the streams above (call records, receipts, unpushed receipts). Use it when a "
      + "stream says stalled. Queued records stay in the gateway's local log and are written after the restart. "
      + "Customer and vendor binds stay up.",
    question: "Restart the database writers?",
    done: "Writers restarted",
    whatHappens:
      "Each stream's writer finishes what it is writing (up to 10 s), hands anything left to the gateway's local log, "
      + "and a fresh writer takes over and writes the log back to PostgreSQL. Messages keep flowing the whole time; only "
      + "the write to the database pauses.",
    customerBinds: BINDS_UP,
    vendorBinds: "Not dropped.",
    dropsBinds: false,
    kept:
      "Queued records stay in the gateway's local log and are written after the restart. Nothing is lost or charged twice.",
    usually: "A few seconds; up to 10 s per stream while it drains.",
    command: "fireflo restart persist",
    icon: "rotate-cw",
  },
  db: {
    label: "Reconnect pool",
    help:
      "Closes idle and broken database connections and opens new ones. Use it after a database failover, or when the "
      + "probe climbs while PostgreSQL itself is fine. A hard option, asked in the confirmation, also closes busy ones. "
      + "Binds stay up.",
    question: "Reconnect the database pool?",
    done: "Pool reconnected",
    whatHappens:
      "The gateway closes the connections that are idle or broken and opens new ones as they are needed. The control "
      + "lane is rebuilt too. The lease lane is left alone, because a gap there would fence the vendors.",
    customerBinds: "Not dropped.",
    vendorBinds: "Not dropped.",
    dropsBinds: false,
    kept: "Everything: a write that fails on a closed connection is retried; queued records wait in the local log.",
    usually: "Under a second.",
    command: "fireflo restart db",
    icon: "plug",
  },
  "kafka-router": {
    label: "Restart router",
    help:
      "Closes and reopens the router's Kafka consumer. Records it had not settled come back to it and are routed once: "
      + "the transaction keeps that exactly-once. Use it when Router lag grows while the group has members. Binds stay up.",
    question: "Restart the Kafka router?",
    done: "Router restarted",
    whatHappens:
      "Each router feed's consumer is closed at its next read and reopened, and the transaction it had open is aborted. "
      + "What it took since its last commit comes back to it and is routed again, exactly once.",
    customerBinds: BINDS_UP,
    vendorBinds: "Not dropped.",
    dropsBinds: false,
    kept: "Everything on the topics. Nothing is routed twice or charged twice.",
    usually: "A few seconds, while the group rebalances.",
    command: "fireflo restart kafka-router",
    icon: "rotate-cw",
  },
  "kafka-consumers": {
    label: "Restart consumers",
    help:
      "Stops and starts the deliver, webhook and retry-tier consumers and the lag sampler. Brings back a consumer thread "
      + "that died. Use it when a topic is behind and its group has no members. Binds stay up.",
    question: "Restart the Kafka consumers?",
    done: "Consumers restarted",
    whatHappens:
      "The deliver, webhook and retry-tier consumers and the lag sampler are stopped and started again, which also "
      + "revives one whose thread had died. The router is not touched.",
    customerBinds: BINDS_UP,
    vendorBinds: "Not dropped.",
    dropsBinds: false,
    kept: "Everything on the topics: each consumer carries on from its group's last commit.",
    usually: "A few seconds, while the groups rebalance.",
    command: "fireflo restart kafka-consumers",
    icon: "rotate-cw",
  },
  "vendor-feed": {
    label: "Reset feed",
    help:
      "Re-reads this vendor's topic from its last commit, resumes paused partitions and sends a stuck first message "
      + "again. Use it when the vendor is bound but its queue does not move. Binds stay up.",
    question: "Reset this vendor's feed?",
    done: "Feed reset",
    whatHappens:
      "The vendor's Kafka feed is committed again, its paused partitions are resumed and the message at its head that "
      + "never settled is read again. Its binds are not touched.",
    customerBinds: "Not dropped.",
    vendorBinds: "Not dropped.",
    dropsBinds: false,
    kept: "The vendor's queue: every waiting message stays and is sent once.",
    usually: "Under a second.",
    command: "fireflo restart vendor-feed",
    icon: "rotate-ccw",
  },
  vendor: {
    label: "Rebind",
    help:
      "Closes and reopens this vendor's binds. Only this vendor's binds drop, for a few seconds; its queued messages are "
      + "kept and go out when the binds return.",
    question: "Rebind this vendor?",
    done: "Vendor rebound",
    whatHappens:
      "The vendor's binds are closed and made again. Messages for it wait in its queue while they are down and go out "
      + "when they return.",
    customerBinds: "Not dropped.",
    vendorBinds: "This vendor's binds drop for a few seconds and are made again. Other vendors are not touched.",
    dropsBinds: true,
    kept: "This vendor's queued messages: they go out when the binds return.",
    usually: "A few seconds, as long as the vendor takes to accept a bind.",
    command: "fireflo restart vendor",
    icon: "plug-zap",
  },
};

/** The hard option's explanation, under its checkbox in the Reconnect pool confirmation. */
export const HARD_HELP =
  "Statements running at that moment fail and are retried by whatever sent them, so a few writes land a second or two "
  + "late. Use it only when the pool is stuck on connections to a database that is gone (after a failover). Leave it "
  + "off for an ordinary reconnect.";

/** The sentence for a gateway that does not advertise `component_restart`. */
export const RESTART_UNSUPPORTED =
  "This gateway cannot restart its parts from here: that arrives with gateway 0.15.2 (component_restart).";

/** The sentence for an operator who is not an admin. */
export const RESTART_ADMIN_ONLY = "Restarts are for admins: ask one to run it.";

/** The `fireflo restart` line for a part and its target, as the confirmation shows it. */
export function restartCommand(part: QueuesRestartPart, target?: string | null): string {
  const t = target?.trim();
  return t ? `${RESTART_COPY[part].command} ${t}` : RESTART_COPY[part].command;
}

// ---- the request ---------------------------------------------------------------------------------

/** A request the route will forward: checked, trimmed, nothing extra. */
export interface RestartRequest {
  component: RestartPart;
  target: string | null;
  hard: boolean;
}

/**
 * The request a body asks for, or the sentence that says why it is not one.
 *
 * <p>Stricter than the gateway on purpose, so a mistake is answered here in the panel's words and
 * never reaches the gateway: a vendor part needs its vendor, `persist` takes a stream or none, the
 * Kafka parts and `db` take no target, and only `db` has a hard form.
 */
export function readRestartRequest(raw: unknown): { ok: true; request: RestartRequest } | { ok: false; error: string } {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return { ok: false, error: "Expected a JSON body." };
  }
  const body = raw as Record<string, unknown>;
  const component = typeof body.component === "string" ? body.component.trim() : "";
  if (!isRestartPart(component)) {
    return {
      ok: false,
      error: `Unknown part '${component}'. Parts: ${RESTART_PARTS.join(", ")}.`,
    };
  }
  if (body.target != null && typeof body.target !== "string") {
    return { ok: false, error: "target must be text." };
  }
  const target = typeof body.target === "string" && body.target.trim() ? body.target.trim() : null;
  if (target && target.length > MAX_TARGET_CHARS) {
    return { ok: false, error: `target is longer than ${MAX_TARGET_CHARS} characters.` };
  }
  if (body.hard != null && typeof body.hard !== "boolean") {
    return { ok: false, error: "hard must be true or false." };
  }
  const hard = body.hard === true;

  if (VENDOR_PARTS.includes(component) && !target) {
    return { ok: false, error: `${component} needs the vendor to restart.` };
  }
  if (component === "persist" && target && !(PERSIST_STREAMS as readonly string[]).includes(target)) {
    return { ok: false, error: `Unknown stream '${target}'. Streams: ${PERSIST_STREAMS.join(", ")}, or none for all.` };
  }
  if ((component === "db" || component === "kafka-router" || component === "kafka-consumers" || component === "config") && target) {
    return { ok: false, error: `${component} takes no target.` };
  }
  if (hard && component !== "db") {
    return { ok: false, error: "Only db has a hard reconnect." };
  }
  return { ok: true, request: { component, target, hard } };
}

/** The variables the mutation is sent with: `by` is the signed-in operator, never the browser's word. */
export function restartVariables(request: RestartRequest, by: string): Record<string, unknown> {
  return {
    component: request.component,
    target: request.target,
    hard: request.component === "db" ? request.hard : null,
    by,
  };
}

/** The access-log name for a restart: the part, with its vendor or stream after it. */
export function restartAuditName(request: Pick<RestartRequest, "component" | "target">): string {
  return request.target ? `${request.component} ${request.target}` : request.component;
}

// ---- the answer ----------------------------------------------------------------------------------

/** The gateway's answer, every field read defensively: an older or newer build may differ. */
export interface RestartResult {
  component: string;
  target: string | null;
  ok: boolean;
  tookMs: number | null;
  detail: string | null;
  /** What each piece said, e.g. `{main: "idle and invalid connections closed", lease: "not reset"}`. */
  results: Record<string, string>;
  before: Record<string, unknown>;
  after: Record<string, unknown>;
}

const asRecord = (v: unknown): Record<string, unknown> =>
  v && typeof v === "object" && !Array.isArray(v) ? (v as Record<string, unknown>) : {};

const asNumber = (v: unknown): number | null => {
  if (v == null || v === "" || typeof v === "boolean") {
    return null;
  }
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

const asText = (v: unknown): string | null => (typeof v === "string" && v.trim() ? v.trim() : null);

/** The answer, tolerant of any field missing. `ok` is false unless the gateway said true. */
export function parseRestartResult(raw: unknown): RestartResult {
  const r = asRecord(raw);
  const results: Record<string, string> = {};
  for (const [k, v] of Object.entries(asRecord(r.results))) {
    if (v != null) {
      results[k] = typeof v === "string" ? v : JSON.stringify(v);
    }
  }
  return {
    component: asText(r.component) ?? "",
    target: asText(r.target),
    ok: r.ok === true,
    tookMs: asNumber(r.tookMs),
    detail: asText(r.detail),
    results,
    before: asRecord(r.before),
    after: asRecord(r.after),
  };
}

/** "3.4 s", "820 ms": how long it took. */
export function tookLabel(ms: number | null): string | null {
  if (ms == null) {
    return null;
  }
  return ms < 1000 ? `${Math.round(ms)} ms` : `${(ms / 1000).toFixed(1)} s`;
}

/** Seconds as the write-behind block says "behind": "0.3 s", "6 m 12 s", "1 h 4 m". */
export function secondsLabel(s: number | null): string {
  if (s == null) {
    return "—";
  }
  if (s < 10) {
    return `${Math.round(s * 10) / 10} s`;
  }
  if (s < 60) {
    return `${Math.round(s)} s`;
  }
  const m = Math.floor(s / 60);
  if (m < 60) {
    const rest = Math.round(s - m * 60);
    return rest ? `${m} m ${rest} s` : `${m} m`;
  }
  const h = Math.floor(m / 60);
  const rest = m - h * 60;
  return rest ? `${h} h ${rest} m` : `${h} h`;
}

/** One row of the before → after table. `state` rows are drawn as a pill whose tone is the word. */
export interface FigureRow {
  key: string;
  label: string;
  before: string;
  after: string;
  state?: boolean;
}

const n0 = (v: number | null) => (v == null ? "—" : count(v));
const yesNo = (v: unknown) => (v === true ? "yes" : v === false ? "no" : "—");
const word = (v: unknown) => asText(v)?.toLowerCase() ?? "—";

/** A persist figure's lanes summed by stream: the depth, and the longest stall. */
function streamTotals(figures: Record<string, unknown>): Map<string, { depth: number; stalledSeconds: number }> {
  const out = new Map<string, { depth: number; stalledSeconds: number }>();
  const lanes = Array.isArray(figures.streams) ? figures.streams : [];
  for (const raw of lanes) {
    const l = asRecord(raw);
    const stream = asText(l.stream);
    if (!stream) {
      continue;
    }
    const t = out.get(stream) ?? { depth: 0, stalledSeconds: 0 };
    t.depth += asNumber(l.depth) ?? 0;
    t.stalledSeconds = Math.max(t.stalledSeconds, asNumber(l.stalledSeconds ?? l.stalled_seconds) ?? 0);
    out.set(stream, t);
  }
  return out;
}

/** The db figures' pool, nested (`pool: {active, idle, waiting}`) or flat, whichever the gateway sent. */
function poolOf(figures: Record<string, unknown>): Record<string, unknown> {
  const nested = asRecord(figures.pool);
  return Object.keys(nested).length ? nested : figures;
}

/** The vendor figures' backlog, nested (`backlog: {depth, state}`) or flat. */
function backlogOf(figures: Record<string, unknown>): Record<string, unknown> {
  const nested = asRecord(figures.backlog);
  return Object.keys(nested).length ? nested : figures;
}

/**
 * The before → after rows for a result, only those the gateway gave a figure for on either side.
 * A part with no figures of its own (jobs, config) gets none, and the dialog says the detail alone.
 */
export function figureRows(result: RestartResult): FigureRow[] {
  const { before: b, after: a } = result;
  const rows: FigureRow[] = [];
  const add = (key: string, label: string, before: string, after: string, state = false) => {
    if (before !== "—" || after !== "—") {
      rows.push({ key, label, before, after, ...(state ? { state } : {}) });
    }
  };
  switch (result.component) {
    case "persist": {
      add("writer", "Writer", word(b.writer), word(a.writer), true);
      const sb = streamTotals(b);
      const sa = streamTotals(a);
      const names = [...new Set([...sb.keys(), ...sa.keys()])]
        .filter((s) => !result.target || s === result.target)
        .sort((x, y) => PERSIST_STREAMS.indexOf(x as PersistStream) - PERSIST_STREAMS.indexOf(y as PersistStream));
      for (const s of names) {
        const x = sb.get(s);
        const y = sa.get(s);
        const st = (t: { stalledSeconds: number } | undefined) => (t == null ? "—" : t.stalledSeconds > 0 ? "stalled" : "ok");
        add(`${s}-state`, `${s} writer`, st(x), st(y), true);
        add(`${s}-depth`, `${s} waiting`, n0(x?.depth ?? null), n0(y?.depth ?? null));
      }
      add("depth", "Waiting, every stream", n0(asNumber(b.depth)), n0(asNumber(a.depth)));
      add("lag", "Behind", asNumber(b.lagSeconds) == null ? "—" : secondsLabel(asNumber(b.lagSeconds)),
        asNumber(a.lagSeconds) == null ? "—" : secondsLabel(asNumber(a.lagSeconds)));
      const rate = (v: unknown) => (asNumber(v) == null ? "—" : `${n0(asNumber(v))} rows/s`);
      add("rate", "Write rate", rate(b.writeRate), rate(a.writeRate));
      break;
    }
    case "db": {
      const pb = poolOf(b);
      const pa = poolOf(a);
      add("active", "Connections in use", n0(asNumber(pb.active)), n0(asNumber(pa.active)));
      add("idle", "Idle", n0(asNumber(pb.idle)), n0(asNumber(pa.idle)));
      add("waiting", "Callers waiting", n0(asNumber(pb.waiting)), n0(asNumber(pa.waiting)));
      const ms = (v: unknown) => (asNumber(v) == null ? "—" : `${n0(asNumber(v))} ms`);
      add("probe", "Probe", ms(b.probeMs), ms(a.probeMs));
      add("poolWait", "Pool wait", ms(b.poolWaitMs), ms(a.poolWaitMs));
      break;
    }
    case "kafka-router":
    case "kafka-consumers": {
      add("connected", "Connected", yesNo(b.connected), yesNo(a.connected));
      add("routerLag", "Router lag", n0(asNumber(b.routerLag)), n0(asNumber(a.routerLag)));
      add("assignment", "Partitions held here", n0(asNumber(b.assignment)), n0(asNumber(a.assignment)));
      break;
    }
    case "vendor-feed":
    case "vendor": {
      add("bound", "Bound", yesNo(b.bound), yesNo(a.bound));
      const kb = backlogOf(b);
      const ka = backlogOf(a);
      add("depth", "Waiting", n0(asNumber(kb.depth)), n0(asNumber(ka.depth)));
      add("state", "Queue", word(kb.state), word(ka.state), true);
      break;
    }
    default:
      break;
  }
  return rows;
}

/** The tone a state word is drawn in: stalled and its kin warn, ok is quiet green. */
export function stateTone(state: string): "success" | "warning" | "destructive" | "outline" {
  switch (state.toLowerCase()) {
    case "ok":
    case "draining":
    case "idle":
      return "success";
    case "stalled":
    case "slow":
    case "paused":
    case "throttling":
      return "warning";
    case "refusing":
      return "destructive";
    default:
      return "outline";
  }
}

/**
 * What the operator reads under the button when the restart did not run.
 *
 * <p>The gateway's own sentence when it sent one ("Another restart of the writers is running; try
 * again in a moment.", "This gateway runs the in-memory backbone: ...") -- they are written to be
 * read as they are -- and a sentence of the panel's for a status that came without one.
 */
export function refusalSentence(status: number, error: unknown): string {
  const said = asText(error);
  if (said) {
    return said;
  }
  switch (status) {
    case 400:
      return "The gateway did not accept that restart.";
    case 403:
    case 404:
      return RESTART_ADMIN_ONLY;
    case 409:
      return "The gateway could not restart that part now: another restart may be running.";
    case 0:
      return "Could not reach the panel's API.";
    default:
      return `The gateway did not answer the restart (${status}).`;
  }
}

// ---- the write-behind block ----------------------------------------------------------------------

/** One stream in the Database card's write-behind block, its lanes summed. */
export interface WriteBehindStream {
  stream: string;
  /** What the stream holds, in words. */
  what: string;
  depth: number;
  /** Any lane writing from the local log. */
  spilled: boolean;
  /** The longest stall among its lanes; 0 while none is stalled. */
  stalledSeconds: number;
  state: "stalled" | "from log" | "ok";
  lanes: number;
}

export interface WriteBehind {
  streams: WriteBehindStream[];
  /** A lane is stalled, by the lanes or by `persist_writer`. */
  stalled: boolean;
  /** The bus's oldest write waiting, seconds; null when not published. */
  lagSeconds: number | null;
  /** Rows a second written, all streams; null before the first measurement. */
  writeRate: number | null;
  /** The local log's size, and its cap when published. */
  logBytes: number | null;
  logMaxMb: number | null;
  /** The door still admits new submits. */
  admitting: boolean;
}

/**
 * The write-behind block's reading, or null when health has no `persist_streams` (a gateway before
 * 0.15.2, or one without the persistence bus): the block is then left out, not drawn empty.
 */
export function writeBehind(h: Health | null | undefined): WriteBehind | null {
  const lanes = h?.persist_streams;
  if (!Array.isArray(lanes)) {
    return null;
  }
  const by = new Map<string, WriteBehindStream>();
  for (const l of lanes as HealthPersistLane[]) {
    const stream = asText(l?.stream);
    if (!stream) {
      continue;
    }
    const s = by.get(stream) ?? {
      stream,
      what: STREAM_LABEL[stream] ?? "",
      depth: 0,
      spilled: false,
      stalledSeconds: 0,
      state: "ok" as const,
      lanes: 0,
    };
    s.depth += asNumber(l.depth) ?? 0;
    s.spilled ||= l.spilled === true;
    s.stalledSeconds = Math.max(s.stalledSeconds, asNumber(l.stalled_seconds) ?? 0);
    s.lanes += 1;
    by.set(stream, s);
  }
  const streams = [...by.values()]
    .map((s) => ({ ...s, state: s.stalledSeconds > 0 ? ("stalled" as const) : s.spilled ? ("from log" as const) : ("ok" as const) }))
    .sort((x, y) => rank(x.stream) - rank(y.stream));
  return {
    streams,
    stalled: streams.some((s) => s.state === "stalled") || h?.persist_writer?.trim().toLowerCase() === "stalled",
    lagSeconds: asNumber(h?.persist_lag_seconds),
    writeRate: asNumber(h?.db_write_rate),
    logBytes: asNumber(h?.persist_log_bytes),
    logMaxMb: asNumber(h?.persist_log_max_mb),
    admitting: h?.db_admission == null || h.db_admission === "OK",
  };
}

function rank(stream: string): number {
  const i = PERSIST_STREAMS.indexOf(stream as PersistStream);
  return i < 0 ? PERSIST_STREAMS.length : i;
}

/** The streams that are stalled, by name, for the header's hint: "dlr-store", "cdr and dlr-store". */
export function stalledNames(w: WriteBehind): string[] {
  return w.streams.filter((s) => s.state === "stalled").map((s) => s.stream);
}

/** "dlr-store has not written for 6 m 12 s", for the Database card's header beside "Writer stalled". */
export function stalledHint(w: WriteBehind): string {
  const names = stalledNames(w);
  if (!names.length) {
    return "a writer has stopped writing";
  }
  const longest = Math.max(...w.streams.map((s) => s.stalledSeconds));
  const who = names.length === 1 ? names[0] : `${names.slice(0, -1).join(", ")} and ${names[names.length - 1]}`;
  return `${who} ${names.length === 1 ? "has" : "have"} not written for ${secondsLabel(longest)}`;
}
