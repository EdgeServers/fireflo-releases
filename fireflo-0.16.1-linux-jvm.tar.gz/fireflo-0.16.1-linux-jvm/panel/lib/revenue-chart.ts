/**
 * The Revenue page's two charts: revenue over the period, split into what it cost and what it kept,
 * and the accounts that brought it in.
 *
 * <p>Pure, so the arithmetic is tested without a browser. Amounts stay in the panel's scaled
 * integers (`money()` formats them), as everywhere else.
 */

import { formatDay, formatHour, formatHourSpan, zoneShortName } from "./datetime.ts";

export interface RevenueBucketLike {
  /** `YYYY-MM-DD` for a day, an ISO instant for an hour or five minutes. */
  bucket: string;
  revenue: number;
  cost: number;
}

export interface SeriesBar {
  label: string;
  /** The tooltip's heading: the day with the zone it is a day in, or the bucket's span. */
  heading: string;
  revenue: number;
  /** Stacked: cost, then margin on top -- together the revenue. */
  cost: number;
  margin: number;
  /** Cost above revenue: the bar shows the cost alone and the tooltip says it was a loss. */
  loss: boolean;
}

/**
 * `23 Oct` for a billing day, labelled by its own date; `14:05` for an hour or five minutes, the
 * bucket's start in the display zone (the buckets are UTC, so `19:35` in India).
 */
export function bucketLabel(bucket: string, zone: string): string {
  return bucket.length === 10 ? formatDay(bucket) : formatHour(bucket, zone);
}

/** The tooltip's heading for a bucket; see {@link SeriesBar.heading}. */
export function bucketHeading(bucket: string, zone: string, billingZone: string, minutes = 60): string {
  return bucket.length === 10
    ? `${formatDay(bucket, { year: true })} (${zoneShortName(billingZone)} day)`
    : formatHourSpan(bucket, zone, minutes);
}

/**
 * @param zone        the display zone, for hour and five-minute buckets
 * @param billingZone the zone a day bucket is a day in, named in its tooltip
 * @param minutes     an instant bucket's width
 */
export function seriesBars(buckets: readonly RevenueBucketLike[], zone = "UTC", billingZone = "UTC", minutes = 60): SeriesBar[] {
  return buckets.map((b) => {
    const loss = b.cost > b.revenue;
    return {
      label: bucketLabel(b.bucket, zone),
      heading: bucketHeading(b.bucket, zone, billingZone, minutes),
      revenue: b.revenue,
      cost: b.cost,
      //never a negative segment: a loss is drawn as its cost, and flagged
      margin: loss ? 0 : b.revenue - b.cost,
      loss,
    };
  });
}

export interface AccountBar {
  account: string;
  revenue: number;
}

/** Accounts drawn one by one; the rest are summed into "Other". */
export const TOP_ACCOUNTS = 7;

/** Revenue per account (the table's rows are account x product), busiest first, the rest as Other. */
export function topAccounts(rows: readonly { accountId: string | null; revenue: number }[]): AccountBar[] {
  const byAccount = new Map<string, number>();
  for (const r of rows) {
    const key = r.accountId ?? "No account";
    byAccount.set(key, (byAccount.get(key) ?? 0) + r.revenue);
  }
  const sorted = [...byAccount.entries()]
    .map(([account, revenue]) => ({ account, revenue }))
    .filter((a) => a.revenue > 0)
    .sort((a, b) => b.revenue - a.revenue);
  if (sorted.length <= TOP_ACCOUNTS) return sorted;
  const shown = sorted.slice(0, TOP_ACCOUNTS - 1);
  const rest = sorted.slice(shown.length);
  return [...shown, { account: `Other (${rest.length})`, revenue: rest.reduce((n, a) => n + a.revenue, 0) }];
}
