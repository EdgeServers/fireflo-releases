import { hasCapability, VENDOR_BACKLOG_VIEW } from "./capabilities.ts";
import type { GqlFailure, GqlOutcome } from "./gateway-graphql-core.ts";
import { HEALTH, VENDOR_BACKLOG } from "./gateway-queries.ts";
import { flattenHealth, type HealthField } from "./health-types.ts";
import { localeNumber } from "./format.ts";

/**
 * Vendor backlogs (gateway 0.15.1, `vendorBacklog`, capability `vendor_backlog`): what each vendor
 * has been handed and not sent, against its limits; whether it is bound; where its traffic went
 * instead. And the pure pieces the Vendors page and the warning on Overview and Health draw it with.
 *
 * <p>A GraphQL read of the gateway's once-a-second monitor -- never the call records, never a
 * broker call per query -- kept ten seconds by the route.
 */

export type BacklogState = "OK" | "THROTTLING" | "REFUSING";

export interface VendorBacklog {
  worker: string;
  /** -1 before the first reading. */
  depth: number;
  oldestAgeSeconds: number | null;
  limit: number;
  maxAgeSeconds: number;
  expireSeconds: number;
  state: BacklogState;
  bound: boolean;
  unboundSinceSeconds: number | null;
  /** Kafka only. */
  retentionUsedPercent: number | null;
  failoverTarget: string | null;
  refusedTotal: number;
  expiredTotal: number;
  sampledAt: string | null;
}

/** What `/api/control/vendors/backlog` answers. */
export type VendorBacklogAnswer =
  | { data: { vendors: VendorBacklog[]; unboundGraceSeconds: number } }
  | { data: null; unsupported: true };

/** `smsg.vendor.unbound.refuse.after.seconds` when it is not set. */
export const DEFAULT_UNBOUND_GRACE_SECONDS = 600;
/** A Kafka backlog this far into its topic's retention is about to lose messages. */
export const RETENTION_ALARM_PERCENT = 50;

function numOrNull(v: unknown): number | null {
  return v == null || v === "" ? null : Number(v);
}

export function normaliseBacklog(raw: unknown): VendorBacklog[] {
  if (!Array.isArray(raw)) {
    return [];
  }
  return raw.map((r: Record<string, unknown>) => ({
    worker: String(r.worker ?? ""),
    depth: Number(r.depth ?? -1),
    oldestAgeSeconds: numOrNull(r.oldestAgeSeconds),
    limit: Number(r.limit ?? 0),
    maxAgeSeconds: Number(r.maxAgeSeconds ?? 0),
    expireSeconds: Number(r.expireSeconds ?? 0),
    state: (r.state === "THROTTLING" || r.state === "REFUSING" ? r.state : "OK") as BacklogState,
    bound: r.bound === true,
    unboundSinceSeconds: numOrNull(r.unboundSinceSeconds),
    retentionUsedPercent: numOrNull(r.retentionUsedPercent),
    failoverTarget: r.failoverTarget == null ? null : String(r.failoverTarget),
    refusedTotal: Number(r.refusedTotal ?? 0),
    expiredTotal: Number(r.expiredTotal ?? 0),
    sampledAt: r.sampledAt == null ? null : String(r.sampledAt),
  }));
}

/** One vendor's trouble, in a sentence; nothing for a healthy one. */
export interface BacklogAlert {
  worker: string;
  tone: "destructive" | "warning";
  message: string;
}

/** `95 s`, `12 min`, `3 h 4 min`. */
export function ageWords(seconds: number | null): string {
  if (seconds == null) {
    return "—";
  }
  if (seconds < 120) {
    return `${seconds} s`;
  }
  const minutes = Math.round(seconds / 60);
  return minutes < 120 ? `${minutes} min` : `${Math.floor(minutes / 60)} h ${minutes % 60} min`;
}

/**
 * The vendors worth a warning on Overview and Health: refusing, unbound past the grace after which
 * the gateway refuses its traffic, or a Kafka backlog half way through its retention.
 */
export function backlogAlerts(vendors: readonly VendorBacklog[], unboundGraceSeconds = DEFAULT_UNBOUND_GRACE_SECONDS): BacklogAlert[] {
  const out: BacklogAlert[] = [];
  for (const v of vendors) {
    if (v.state === "REFUSING") {
      out.push({
        worker: v.worker,
        tone: "destructive",
        message: `${v.worker} is past its backlog limit (${localeNumber(v.depth)} waiting, oldest ${ageWords(v.oldestAgeSeconds)})`
          + (v.failoverTarget ? `: its traffic goes to ${v.failoverTarget}.` : ": submits with no other route are refused (vendorBacklog)."),
      });
    }
    if (!v.bound && v.unboundSinceSeconds != null && v.unboundSinceSeconds >= unboundGraceSeconds) {
      out.push({
        worker: v.worker,
        tone: "destructive",
        message: `${v.worker} has had no bind for ${ageWords(v.unboundSinceSeconds)}`
          + (v.failoverTarget ? `; its traffic goes to ${v.failoverTarget}.` : "; submits with no other route are refused (vendorUnavailable)."),
      });
    }
    if (v.retentionUsedPercent != null && v.retentionUsedPercent >= RETENTION_ALARM_PERCENT) {
      out.push({
        worker: v.worker,
        tone: v.retentionUsedPercent >= 80 ? "destructive" : "warning",
        message: `${v.worker}'s oldest waiting message is ${v.retentionUsedPercent}% of the way through its topic's retention: `
          + "past 100% it is gone unsent.",
      });
    }
  }
  return out;
}

/** The badge a vendor's backlog gets, or null when there is nothing to say. */
export function backlogBadge(v: VendorBacklog): { label: string; tone: "destructive" | "warning" } | null {
  if (v.state === "REFUSING") return { label: "refusing", tone: "destructive" };
  if (!v.bound && v.unboundSinceSeconds != null) return { label: "unbound", tone: "destructive" };
  if (v.state === "THROTTLING") return { label: "throttling", tone: "warning" };
  return null;
}

const STATE_RANK: Record<BacklogState, number> = { OK: 0, THROTTLING: 1, REFUSING: 2 };

/**
 * The collapsed Backlogs card's header: `Backlogs · 2 vendors · 1,240 queued · worst: OK`. Queued
 * adds every vendor's depth, skipping the -1 of one not read yet; worst is the most severe state.
 */
export function backlogSummary(vendors: readonly VendorBacklog[]): string {
  const queued = vendors.reduce((sum, v) => sum + Math.max(v.depth, 0), 0);
  const worst = vendors.reduce<BacklogState>((w, v) => (STATE_RANK[v.state] > STATE_RANK[w] ? v.state : w), "OK");
  const n = vendors.length;
  return `Backlogs · ${localeNumber(n)} ${n === 1 ? "vendor" : "vendors"} · ${localeNumber(queued)} queued · worst: ${worst}`;
}

/** The gateway call: `executeGql` in the route. */
export type GqlExecutor = <T>(call: { query: string; timeoutMs?: number }) => Promise<GqlOutcome<T>>;

/**
 * The route's work, with the gateway call passed in: the capability map first, as the Kafka and
 * call-record routes do, so a gateway before 0.15.1 is told apart and never asked the field.
 */
export async function readVendorBacklog(
  exec: GqlExecutor,
  unboundGraceSeconds: number
): Promise<{ ok: true; body: VendorBacklogAnswer } | { ok: false; failure: GqlFailure }> {
  const health = await exec<HealthField>({ query: HEALTH, timeoutMs: 5_000 });
  if (!health.ok) {
    return { ok: false, failure: health };
  }
  if (!hasCapability(flattenHealth(health.data), VENDOR_BACKLOG_VIEW)) {
    return { ok: true, body: { data: null, unsupported: true } };
  }
  const read = await exec<unknown>({ query: VENDOR_BACKLOG, timeoutMs: 5_000 });
  if (!read.ok) {
    return { ok: false, failure: read };
  }
  return { ok: true, body: { data: { vendors: normaliseBacklog(read.data), unboundGraceSeconds } } };
}
