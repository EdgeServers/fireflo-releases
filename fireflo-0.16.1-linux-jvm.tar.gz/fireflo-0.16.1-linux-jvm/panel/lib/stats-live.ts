import { GatewayError, PANEL_CODES } from "./gateway-graphql-core.ts";
import {
  GRAIN_MS,
  fromSeam,
  grainOf,
  inWindow,
  isLiveRange,
  mergeAccountActivity,
  mergeRevenueRows,
  mergeRevenueSeries,
  mergeServerTraffic,
  mergeTraffic,
  mergeVendors,
  spliceFrom,
  toAccountActivity,
  toFailureRows,
  toReceipts,
  toRevenueRows,
  toRevenueSeries,
  toServerTraffic,
  toTraffic,
  toUsageGrid,
  toVendors,
  windowOf,
  withBalances,
  type AccountActivity,
  type LiveFailure,
  type ConfiguredCredential,
  type ConvertContext,
  type LiveBucket,
  type LiveFilter,
  type LiveGrain,
  type LiveGroup,
  type LivePanelRange,
  type LiveReceiptQuality,
  type LiveSeriesSum,
} from "./gateway-live-series.ts";
import { totalsOf, type RevenueRow, type TrafficBucket } from "./overview-totals.ts";
import { vendorsOf, type FailureRowLike, type RangeSnapshot } from "./overview-snapshot.ts";
import { parseUsageFilters, type UsageGridView } from "./usage-grid.ts";
import type { AccountsView, RevenueBucket, ServerTraffic, VendorRow } from "./metrics-queries.ts";
import type { ReceiptQualityRow } from "./receipt-queries.ts";

/**
 * Which source answers a 1h or 24h chart: the gateway's live series, or the database (0.15.1).
 *
 * <p>The rules, in order, for the metrics that have a live reader (overview, traffic,
 * server-traffic, accounts, vendors, receipts, revenue, revenue-series, usage-grid):
 *
 * <ol>
 *   <li><b>Only 1h and 24h.</b> 7d and 30d stay on `usage_daily`, which is cheap and cached.</li>
 *   <li><b>The capability.</b> The answering node must publish `live_series`; a gateway that
 *       cannot be asked (unreachable, no token) or does not publish it is read from the database.</li>
 *   <li><b>The read.</b> A gateway that fails the read itself -- any {@link GatewayError}, or an
 *       answer this panel cannot use -- is read from the database too: a chart that could be drawn
 *       from the database never blanks because the gateway refused. Unreachable and not configured
 *       are expected and quiet; anything else is logged, at most once a minute per metric.</li>
 *   <li><b>The seam.</b> A gateway that restarted inside the window without a backfill from
 *       `usage_hourly` knows only the part since. The part before the seam (`spliceFrom`) is then
 *       read from the database -- the summary-backed readers, bounded by `until` -- and joined to the
 *       series from the seam on. Receipts (timings do not add), Usage (paged rows do not add)
 *       and the overview's failure rings (the breakdown has no `until`) go wholly to the database
 *       instead. When the database is not configured, slow (past
 *       {@link LiveDeps.spliceTimeoutMs}) or failing, the series is served alone and the envelope's
 *       `liveSince` tells the page where it starts.</li>
 *   <li><b>No database.</b> With no `METRICS_DATABASE_URL`, a read the gateway cannot serve is
 *       {@link NoDataSourceError}: the route's 503, as before. One the gateway can serve needs no
 *       database at all.</li>
 * </ol>
 *
 * <p>Database-free by injection, as `overview-snapshot.ts` is: the gateway and every SQL read are
 * functions in {@link LiveDeps} and {@link SqlDeps}, so the choice and each fallback are tested
 * without either (`stats-live.test.ts`). `stats-registry.ts` wires the real ones.
 */

export type DataSource = "gateway" | "database";

const BRAND = "__firefloSourced";

/** A reader's answer with where it came from, unwrapped by the route into the envelope. */
export interface Sourced<T> {
  [BRAND]: true;
  value: T;
  source: DataSource;
  /** When the series starts (the latest node's start), for the page's marker; gateway only. */
  liveSince?: string | null;
  /** How far the gateway's restart backfill reaches; null when it had none. Gateway only. */
  backfilledThrough?: string | null;
  /** Cluster nodes that were asked and did not answer. */
  partial?: string[];
  /** Whether the part before `liveSince` was read from the database and joined in. */
  spliced?: boolean;
}

export function sourced<T>(value: T, meta: Omit<Sourced<T>, typeof BRAND | "value">): Sourced<T> {
  return { [BRAND]: true, value, ...meta };
}

export function isSourced(v: unknown): v is Sourced<unknown> {
  return typeof v === "object" && v !== null && (v as Record<string, unknown>)[BRAND] === true;
}

/** Neither source can answer: the gateway cannot, and there is no metrics database. */
export class NoDataSourceError extends Error {
  constructor() {
    super("METRICS_DATABASE_URL is not set and the gateway's live series is not available; this panel has no data source.");
    this.name = "NoDataSourceError";
  }
}

export interface LiveDeps {
  /** `live_series` on the answering node. Throws the gateway's error when it cannot be asked. */
  capability(): Promise<boolean>;
  series(range: LivePanelRange, grain: LiveGrain, groupBy: readonly LiveGroup[], filter?: LiveFilter): Promise<LiveSeriesSum>;
  receiptQuality(range: LivePanelRange): Promise<{ rows: LiveReceiptQuality[]; partial: string[] }>;
  /** `liveFailures` grouped by account, summed across the cluster. */
  failures(range: LivePanelRange): Promise<{ rows: LiveFailure[]; partial: string[] }>;
  /** `METRICS_DATABASE_URL` is set. */
  dbConfigured(): boolean;
  now(): Date;
  log(line: string): void;
  /** How long a database read for the part before the seam may take before the series is served alone. Default 5 s. */
  spliceTimeoutMs?: number;
}

/** The SQL readers, each with the `until` that bounds a read to the part before the seam. */
export interface SqlDeps {
  traffic(range: LivePanelRange, o: { until?: Date }): Promise<TrafficBucket[]>;
  revenue(range: LivePanelRange, o: { until?: Date }): Promise<RevenueRow[]>;
  revenueSeries(range: LivePanelRange, o: { until?: Date }): Promise<RevenueBucket[]>;
  vendors(range: LivePanelRange, o: { until?: Date; byAccount?: boolean }): Promise<VendorRow[]>;
  accounts(range: LivePanelRange, params: URLSearchParams | undefined, o: { until?: Date }): Promise<AccountsView>;
  serverTraffic(range: LivePanelRange, params: URLSearchParams | undefined, o: { until?: Date }): Promise<ServerTraffic>;
  receipts(range: LivePanelRange): Promise<ReceiptQualityRow[]>;
  usageGrid(range: LivePanelRange, params: URLSearchParams): Promise<UsageGridView>;
  /** `failureBreakdown`: the overview's failures when the gateway cannot give them. */
  failures(range: LivePanelRange): Promise<{ since: string; rows: FailureRowLike[] }>;
  /** Credentials and balances for the Accounts rows: cheap reads of the config pool, kept briefly. */
  configured(account: string | null): Promise<ConfiguredCredential[]>;
  balances(): Promise<Map<string, { balance: number; currency: string | null; units?: boolean }>>;
}

/** The overview snapshot's shape, with `source` saying the gateway when it served it. */
export type LiveOverview = Omit<RangeSnapshot, "source"> & { source: RangeSnapshot["source"] | "gateway" };

const QUIET = new Set<string>([PANEL_CODES.unreachable, PANEL_CODES.notConfigured]);
/** The overview's failures are re-read from the database this often, as the refresher does. */
const FAILURES_TTL_MS = 5 * 60_000;
/** ... and given this long before the overview is served without them. */
const FAILURES_WAIT_MS = 3_000;
/** A read of the part before the seam is kept this long. */
const SPLICE_TTL_MS = 60_000;
const SERVER_TRAFFIC_ACCOUNTS = 50;

class Timeout extends Error {}

function within<T>(p: Promise<T>, ms: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const t = setTimeout(() => reject(new Timeout(`no answer in ${ms} ms`)), ms);
    p.then(
      (v) => {
        clearTimeout(t);
        resolve(v);
      },
      (e) => {
        clearTimeout(t);
        reject(e);
      }
    );
  });
}

function message(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}

export function createLiveReaders(live: LiveDeps, sql: SqlDeps) {
  const spliceMs = live.spliceTimeoutMs ?? 5_000;
  const lastLog = new Map<string, number>();
  const spliceKept = new Map<string, { at: number; value: Promise<unknown> }>();
  const failuresKept = new Map<string, { at: number; value: { since: string; rows: FailureRowLike[] } }>();

  function note(metric: string, err: unknown): void {
    if (err instanceof GatewayError && QUIET.has(err.code)) {
      return;
    }
    const now = Date.now();
    if (now - (lastLog.get(metric) ?? 0) < 60_000) {
      return;
    }
    lastLog.set(metric, now);
    live.log(`stats ${metric}: the gateway's live series could not serve this read, reading the database: ${message(err)}`);
  }

  /**
   * The gateway's answer when it can give one, else the database's. `gateway` answers null to ask
   * for the database outright (receipts and Usage across a seam).
   */
  async function choose<T>(metric: string, range: string, gateway: (r: LivePanelRange) => Promise<Sourced<T> | null>, database: () => Promise<T>): Promise<Sourced<T>> {
    if (isLiveRange(range)) {
      try {
        if (await live.capability()) {
          const got = await gateway(range);
          if (got) {
            return got;
          }
        }
      } catch (err) {
        note(metric, err);
      }
    }
    if (!live.dbConfigured()) {
      throw new NoDataSourceError();
    }
    return sourced(await database(), { source: "database" });
  }

  /**
   * The database's read of `[since, seam)`, or null: no seam, no database, or a database too slow
   * or failing to wait for -- the series is then served alone. Kept {@link SPLICE_TTL_MS} per key.
   */
  async function beforeSeam<T>(metric: string, key: string, seam: Date | null, read: (until: Date) => Promise<T>): Promise<T | null> {
    if (seam === null || !live.dbConfigured()) {
      return null;
    }
    const k = `${metric}|${key}|${seam.toISOString()}`;
    let hit = spliceKept.get(k);
    if (!hit || Date.now() - hit.at >= SPLICE_TTL_MS) {
      const value = read(seam);
      hit = { at: Date.now(), value };
      spliceKept.set(k, hit);
      value.catch(() => {
        if (spliceKept.get(k)?.value === value) {
          spliceKept.delete(k);
        }
      });
      if (spliceKept.size > 128) {
        spliceKept.delete(spliceKept.keys().next().value!);
      }
    }
    try {
      return (await within(hit.value, spliceMs)) as T;
    } catch (err) {
      note(`${metric} (before ${seam.toISOString()})`, err);
      return null;
    }
  }

  function ctxOf(range: LivePanelRange, sum: LiveSeriesSum): ConvertContext {
    return { range, now: live.now(), deadlineHours: sum.deadlineHours };
  }

  function meta(sum: LiveSeriesSum, spliced: boolean, partial: string[] = sum.partial) {
    return {
      source: "gateway" as const,
      liveSince: sum.liveSince,
      backfilledThrough: sum.backfilledThrough,
      partial: [...new Set(partial)].sort(),
      spliced,
    };
  }

  /**
   * The series' buckets in the window, the seam, and the database's part before it when there is
   * one: the step every spliceable reader shares. `live` is the series' buckets the reader converts:
   * from the seam on when the database's part came back, else all of them.
   */
  async function windowed<S>(
    metric: string,
    key: string,
    range: LivePanelRange,
    sum: LiveSeriesSum,
    read: (until: Date) => Promise<S>
  ): Promise<{ ctx: ConvertContext; live: LiveBucket[]; before: S | null }> {
    const ctx = ctxOf(range, sum);
    const buckets = inWindow(sum.buckets, ctx);
    const seam = spliceFrom(sum, range, ctx.now);
    const before = await beforeSeam(metric, `${range}|${key}`, seam, read);
    return { ctx, live: before === null ? buckets : fromSeam(buckets, seam), before };
  }

  async function trafficLive(range: LivePanelRange): Promise<Sourced<TrafficBucket[]>> {
    const sum = await live.series(range, grainOf(range), []);
    const w = await windowed("traffic", "", range, sum, (until) => sql.traffic(range, { until }));
    const series = toTraffic(w.live, w.ctx);
    return sourced(w.before ? mergeTraffic(w.before, series) : series, meta(sum, w.before !== null));
  }

  async function revenueLive(range: LivePanelRange): Promise<Sourced<RevenueRow[]>> {
    const sum = await live.series(range, grainOf(range), ["ACCOUNT", "PRODUCT"]);
    const w = await windowed("revenue", "", range, sum, (until) => sql.revenue(range, { until }));
    const rows = toRevenueRows(w.live);
    return sourced(w.before ? mergeRevenueRows(w.before, rows) : rows, meta(sum, w.before !== null));
  }

  /** Per vendor (the Vendors page), or per vendor and account (the overview's vendor ring). */
  async function vendorsLive(range: LivePanelRange, byAccount = false): Promise<Sourced<VendorRow[]>> {
    const sum = await live.series(range, grainOf(range), byAccount ? ["ACCOUNT", "VENDOR"] : ["VENDOR"]);
    const w = await windowed(byAccount ? "vendor-accounts" : "vendors", "", range, sum, (until) =>
      sql.vendors(range, byAccount ? { until, byAccount } : { until }));
    const rows = toVendors(w.live, w.ctx, byAccount);
    return sourced(w.before ? mergeVendors(w.before, rows) : rows, meta(sum, w.before !== null));
  }

  async function failuresFor(range: LivePanelRange): Promise<{ since: string; rows: FailureRowLike[]; stale: boolean }> {
    const kept = failuresKept.get(range);
    if (kept && Date.now() - kept.at < FAILURES_TTL_MS) {
      return { ...kept.value, stale: false };
    }
    if (!live.dbConfigured()) {
      return { since: live.now().toISOString(), rows: [], stale: false };
    }
    try {
      const value = await within(sql.failures(range), FAILURES_WAIT_MS);
      failuresKept.set(range, { at: Date.now(), value });
      return { ...value, stale: false };
    } catch (err) {
      note("overview failures", err);
      return kept ? { ...kept.value, stale: true } : { since: live.now().toISOString(), rows: [], stale: true };
    }
  }

  /**
   * The overview's failures from the gateway's `liveFailures`, with each account's pending past the
   * deadline as EXPIRED; `failuresSince` is the window's start. The database's breakdown instead
   * (kept, bounded -- {@link failuresFor}) when the gateway fails the read, or across a seam with a
   * database to read: the breakdown has no `until`, so it is taken whole, as receipts are.
   */
  async function overviewFailures(range: LivePanelRange): Promise<{ since: string; rows: FailureRowLike[]; stale: boolean; partial: string[] }> {
    try {
      const [f, sum] = await Promise.all([live.failures(range), live.series(range, grainOf(range), ["ACCOUNT", "VENDOR"])]);
      const ctx = ctxOf(range, sum);
      if (spliceFrom(sum, range, ctx.now) === null || !live.dbConfigured()) {
        return {
          since: windowOf(range, ctx.now).since.toISOString(),
          rows: toFailureRows(f.rows, ctx, inWindow(sum.buckets, ctx)),
          stale: false,
          partial: f.partial,
        };
      }
    } catch (err) {
      note("overview failures", err);
    }
    return { ...(await failuresFor(range)), partial: [] };
  }

  return {
    /** The home page's snapshot from the series: tiles, chart, vendors and the failure rings. */
    overview(range: string, database: () => Promise<RangeSnapshot>): Promise<Sourced<LiveOverview>> {
      return choose<LiveOverview>("overview", range, async (r) => {
        const started = Date.now();
        const [traffic, revenue, vendors, failures] = await Promise.all([
          trafficLive(r),
          revenueLive(r),
          vendorsLive(r, true),
          overviewFailures(r),
        ]);
        const sum = await live.series(r, grainOf(r), []);
        const now = live.now();
        const snap: LiveOverview = {
          builtAt: now.toISOString(),
          asOf: now.toISOString(),
          traffic: traffic.value,
          revenue: revenue.value,
          totals: totalsOf(traffic.value, revenue.value),
          failures: failures.rows,
          failuresSince: failures.since,
          vendors: vendorsOf(vendors.value),
          vendorAccounts: vendors.value,
          watermark: null,
          stale: { traffic: false, revenue: false, failures: failures.stale, vendors: false },
          settlingFrom: new Date(now.getTime() - sum.deadlineHours * 3_600_000).toISOString(),
          source: "gateway",
          tickMs: Date.now() - started,
        };
        return sourced(snap, {
          ...meta(sum, !!(traffic.spliced || revenue.spliced || vendors.spliced), [
            ...(traffic.partial ?? []),
            ...(revenue.partial ?? []),
            ...(vendors.partial ?? []),
            ...failures.partial,
          ]),
        });
      }, database);
    },

    traffic(range: string): Promise<Sourced<TrafficBucket[]>> {
      return choose("traffic", range, trafficLive, () => sql.traffic(range as LivePanelRange, {}));
    },

    revenue(range: string): Promise<Sourced<RevenueRow[]>> {
      return choose("revenue", range, revenueLive, () => sql.revenue(range as LivePanelRange, {}));
    },

    revenueSeries(range: string): Promise<Sourced<RevenueBucket[]>> {
      return choose("revenue-series", range, async (r) => {
        const sum = await live.series(r, grainOf(r), []);
        const w = await windowed("revenue-series", "", r, sum, (until) => sql.revenueSeries(r, { until }));
        const rows = toRevenueSeries(w.live);
        return sourced(w.before ? mergeRevenueSeries(w.before, rows) : rows, meta(sum, w.before !== null));
      }, () => sql.revenueSeries(range as LivePanelRange, {}));
    },

    vendors(range: string): Promise<Sourced<VendorRow[]>> {
      return choose("vendors", range, vendorsLive, () => sql.vendors(range as LivePanelRange, {}));
    },

    accounts(range: string, params?: URLSearchParams): Promise<Sourced<AccountsView>> {
      return choose("accounts", range, async (r) => {
        const account = params?.get("account")?.trim() || null;
        const sum = await live.series(r, grainOf(r), ["ACCOUNT", "LOGIN", "PRODUCT"], account ? { account } : undefined);
        const w = await windowed("accounts", account ?? "", r, sum, async (until): Promise<AccountActivity[]> => {
          const view = await sql.accounts(r, params, { until });
          return view.accounts
            .filter((row) => !row.idle)
            .map(({ balance: _b, currency: _c, idle: _i, ...row }) => row);
        });
        const rows = toAccountActivity(w.live, w.ctx);
        //credentials and balances are cheap reads of the config pool: never the busy tables, and
        //an empty answer when it is not configured or not granted
        const [configured, balances] = await Promise.all([
          sql.configured(account).catch(() => []),
          sql.balances().catch(() => new Map<string, { balance: number; currency: string | null }>()),
        ]);
        return sourced(
          withBalances(w.before ? mergeAccountActivity(w.before, rows) : rows, configured, balances),
          meta(sum, w.before !== null)
        );
      }, () => sql.accounts(range as LivePanelRange, params, {}));
    },

    serverTraffic(range: string, params?: URLSearchParams): Promise<Sourced<ServerTraffic>> {
      //the SQL reader's own check, first: a bad name is the caller's error on either source
      const name = params?.get("server")?.trim() ?? "";
      if (!/^[\w.-]{1,100}$/.test(name)) {
        return Promise.reject(new Error("Which listener? Pass ?server=<name>."));
      }
      return choose("server-traffic", range, async (r) => {
        const sum = await live.series(r, grainOf(r), ["LISTENER", "ACCOUNT"]);
        const w = await windowed("server-traffic", name, r, sum, (until) => sql.serverTraffic(r, params, { until }));
        const view = toServerTraffic(w.live, name, w.ctx, SERVER_TRAFFIC_ACCOUNTS);
        return sourced(w.before ? mergeServerTraffic(w.before, view, SERVER_TRAFFIC_ACCOUNTS) : view, meta(sum, w.before !== null));
      }, () => sql.serverTraffic(range as LivePanelRange, params, {}));
    },

    receipts(range: string): Promise<Sourced<ReceiptQualityRow[]>> {
      return choose("receipts", range, async (r) => {
        const [quality, sum] = await Promise.all([live.receiptQuality(r), live.series(r, grainOf(r), ["VENDOR"])]);
        const ctx = ctxOf(r, sum);
        //timings do not add across sources: a seam with a database to read means the database
        if (spliceFrom(sum, r, ctx.now) !== null && live.dbConfigured()) {
          return null;
        }
        return sourced(toReceipts(quality.rows, inWindow(sum.buckets, ctx), ctx), meta(sum, false, [...sum.partial, ...quality.partial]));
      }, () => sql.receipts(range as LivePanelRange));
    },

    usageGrid(range: string, params: URLSearchParams): Promise<Sourced<UsageGridView>> {
      //the SQL reader's own check, first: bad filters are the caller's error on either source
      const f = parseUsageFilters(params);
      if ("error" in f) {
        return Promise.reject(new Error(f.error));
      }
      return choose("usage-grid", range, async (r) => {
        //a date range is calendar days of the summaries, never the live window
        if (f.from || f.to) {
          return null;
        }
        const filter: LiveFilter = { account: f.account, login: f.login, product: f.product };
        const sum = await live.series(r, "HOUR", ["ACCOUNT", "LOGIN", "PRODUCT"], filter);
        const ctx = ctxOf(r, sum);
        //paged rows do not add across sources: a seam with a database to read means the database
        if (spliceFrom(sum, r, ctx.now, GRAIN_MS.HOUR) !== null && live.dbConfigured()) {
          return null;
        }
        const page = Math.max(0, Math.min(10_000, Math.trunc(Number(params.get("page") ?? 0)) || 0));
        return sourced(toUsageGrid(inWindow(sum.buckets, ctx, GRAIN_MS.HOUR), ctx, page), meta(sum, false));
      }, () => sql.usageGrid(range as LivePanelRange, params));
    },
  };
}

export type LiveReaders = ReturnType<typeof createLiveReaders>;
