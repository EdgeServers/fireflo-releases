/**
 * What an account owes for a period, and the messages it owes it for.
 *
 * <p>Server-only. Reads through `metrics-db`, which exposes `query()` and nothing else — a
 * statement is a report, and nothing here writes anything.
 *
 * <h2>The invoice is a query, not a counter</h2>
 *
 * <p>Everything below is a pure function of the call records over a half-open window. It never reads
 * `account_balance`, never reads `balance_ledger`, and never reads the gateway's in-memory
 * enforcement figures. That is the whole design: the limit check is allowed to be stale, the
 * invoice is not, and keeping them apart means the only thing that can make a bill wrong is a
 * missing or extra record.
 *
 * <h2>...and `cdr_submit` is not the only place those records live</h2>
 *
 * <p><strong>`fireflo usage purge` deletes `cdr_submit` past the retention window.</strong> Reading
 * that table alone, a statement for a purged period recomputed to **zero** — and the panel then
 * compared that zero against the closed invoice and rendered "the full invoice is owed back and
 * carries forward as a credit". A correct, paid invoice presented as entirely refundable, on every
 * period older than the window, for ever.
 *
 * <p>`usage_daily` exists precisely to stop this: `docs/13` says no statement older than the window
 * can ever be reissued, and the summary table is what was supposed to make that true. It was written
 * every night and this file never read it.
 *
 * <p>So a day is taken from `cdr_submit` or from `usage_daily` -- **never both**, which is the same
 * disjointness rule `reconcile-sql.ts` states, and for the same reason. Which one is decided by the
 * day, not by probing for records: finished days before a boundary come from `usage_daily`, purged
 * or not, and the last day or two, where outcomes still move, from the call records.
 * `statement-sql.ts` sets the boundary and says why; asking "are this day's records still there?"
 * per line was what made the statement time out.
 *
 * <h2>One row per message, as UsageRollup</h2>
 *
 * <p>Every vendor attempt is its own `cdr_submit` row, and all of them share the message's receipt,
 * so counting rows billed a message that failed over once as two submitted and two delivered -- and
 * its refused attempt as an unrated message. The counts here take one row per message by the
 * rollup's own `DISTINCT ON` (money row first, else the latest attempt), which is also what makes a
 * live day agree with the `usage_daily` line it later becomes. The money needed no change: only one
 * row per message ever carries a price. `lib/cdr-grain.ts` holds the rule.
 *
 */

import type { BillingPeriod } from "./billing-period";
import { parseBillReference, type ClosedPeriod } from "./period-close";
import { query } from "./metrics-db";
import { cdrQuery } from "./cdr-tier";
import { hasUsageDailyLogin, hasUsageHourly, hasUsageHourlyLogin, hasVendorAttempt, lastDailyDay } from "./metrics-schema";
import { deadlineHours } from "./overview-refresher";
import {
  HOURLY_SETTLE_MINUTES,
  STATEMENT_CUT_SQL,
  STATEMENT_HOURLY_CUT_SQL,
  statementDetailSql,
  statementSummarySql,
  summariseStatement,
  summaryParams,
  type StatementCut,
  type StatementDay,
  type StatementDayProductRow,
  type StatementLine,
  type StatementSplit,
} from "./statement-sql";

export type { StatementDay, StatementLine, StatementSplit } from "./statement-sql";

/** Why the statement cannot be split by login on this gateway, in a sentence. */
export const LOGIN_SPLIT_UNAVAILABLE =
  "Splitting by login needs the gateway's 0.15.1 database update (V1.115.0), which records the login on each day's usage summary.";

/** Asked for a split by login on a gateway that cannot answer it. */
export class LoginSplitUnavailable extends Error {
  constructor() {
    super(LOGIN_SPLIT_UNAVAILABLE);
    this.name = "LoginSplitUnavailable";
  }
}

export interface StatementSummary {
  accountId: string;
  since: string;
  until: string;
  label: string;
  currency: string | null;
  /**
   * What the lines are split by. With `login`, each line's `product` field holds the login, and `''`
   * is "—": traffic before the login was recorded, or that named none. The totals do not change.
   */
  split: StatementSplit;
  /** Whether this gateway can split by login, and why not when it cannot. */
  loginSplit: { available: boolean; reason: string | null };
  lines: StatementLine[];
  /** The same window per billing day, from the same rows as the lines: the statement's chart. */
  days: StatementDay[];
  totalSubmitted: number;
  totalDelivered: number;
  totalUnrated: number;
  /** Scaled by 10,000. The figure being invoiced. */
  totalAmount: number;
  /**
   * Whether this period can still be recomputed at all.
   *
   * <p>False when the call records for the period are gone AND no rollup covers it, which makes
   * `totalAmount` zero for want of evidence rather than because nothing was sent. **A caller
   * comparing a recomputed figure against a closed invoice must not compare this one** -- that is
   * how a paid invoice came to be reported as fully refundable. See `restatementOf`.
   */
  recomputable: boolean;
  /**
   * Days in the period taken from `usage_daily` rather than the call records: every finished day
   * before the split (`statement-sql.ts`), purged or not, that has a line.
   */
  daysFromSummary: number;
}

export interface StatementRow {
  id: string;
  submittedAt: string;
  gatewayMsgId: string;
  product: string | null;
  to: string | null;
  from: string | null;
  parts: number;
  outcome: string;
  /** Scaled by 10,000, or null for a message that went out unrated or was refunded. */
  price: number | null;
}

/**
 * The bill, one line per product, and the same window per day.
 *
 * <p>Two or three statements: a one-row cut that decides where the window splits between
 * `usage_daily` and the call records, on a gateway with `usage_hourly` a second that decides how much
 * of the tail its trusted hours cover, then the summary over plain bounds from them.
 * `statement-sql.ts` explains both splits and why they fall where they do.
 *
 * <p><strong>Billed on `submitted_at`, never `accepted_at`.</strong> `accepted_at` is nullable, and
 * a period boundary drawn on a nullable column silently loses every row where it is missing.
 * `submitted_at` is NOT NULL, is the gateway's own clock, and never moves once written.
 *
 * <p>Heavy for a large account even so, so the routes run it under `withStatementTimeout` through
 * `statement-cache.ts` rather than on the pool's ten seconds.
 */
export async function statementSummary(
  accountId: string,
  period: BillingPeriod,
  currency: string | null,
  zone: string,
  split: StatementSplit = "product"
): Promise<StatementSummary> {
  const [vendorAttempt, lastDaily, deadline, hourly, dailyLogin, hourlyLogin] = await Promise.all([
    hasVendorAttempt(), lastDailyDay(), deadlineHours(), hasUsageHourly(), hasUsageDailyLogin(), hasUsageHourlyLogin(),
  ]);
  if (split === "login" && !dailyLogin) {
    throw new LoginSplitUnavailable();
  }
  const [cut] = await query<StatementCut & Record<string, unknown>>(STATEMENT_CUT_SQL, [
    accountId, period.since, period.until, zone, lastDaily, Math.max(1, Math.ceil(deadline)),
  ]);
  //the tail's trusted whole hours, when the gateway keeps them. The seam is B itself when none can
  //be used (a half-hour zone, no watermark), and the summary then reads the tail live as before
  let seam: Date | string | undefined;
  if (hourly && new Date(cut.tail_from).getTime() < period.until.getTime()) {
    const [h] = await query<{ seam: Date | string }>(STATEMENT_HOURLY_CUT_SQL, [
      accountId, cut.tail_from, period.until, zone, HOURLY_SETTLE_MINUTES,
    ]);
    seam = h?.seam ?? undefined;
  }
  //the records are read only for the partial leading day (when there is one) and the tail past the
  //seam: those windows pick the tables, not the period's start. An old month's head or a current
  //month's tail is a day at most, and a tail inside the hot days reads them alone -- the same rows
  //either way, so the bill cannot change with the tiers
  const rawFrom = new Date(cut.head_until).getTime() > period.since.getTime()
    ? period.since
    : new Date(seam ?? cut.tail_from);
  const rows = await cdrQuery<StatementDayProductRow & Record<string, unknown>>(
    statementSummarySql({ vendorAttempt }, { hourly: seam !== undefined, split, dailyLogin, hourlyLogin }),
    summaryParams(accountId, period.since, period.until, zone, cut, seam),
    rawFrom
  );
  const { lines, days, daysFromSummary } = summariseStatement(rows);

  return {
    accountId,
    since: period.since.toISOString(),
    until: period.until.toISOString(),
    label: period.label,
    currency,
    split,
    loginSplit: { available: dailyLogin, reason: dailyLogin ? null : LOGIN_SPLIT_UNAVAILABLE },
    lines,
    days,
    totalSubmitted: lines.reduce((n, l) => n + l.submitted, 0),
    totalDelivered: lines.reduce((n, l) => n + l.delivered, 0),
    totalUnrated: lines.reduce((n, l) => n + l.unrated, 0),
    totalAmount: lines.reduce((n, l) => n + l.amount, 0),
    //a period with no lines at all is only "nothing was sent" if the evidence still exists. With
    //the call records purged and no rollup covering them there is nothing left to recompute FROM,
    //and reporting that as a total of zero is what turned a paid invoice into a full credit note
    recomputable: lines.length > 0,
    daysFromSummary,
  };
}

/** Where a page of the detail left off. `submitted_at` alone is not unique enough to page on. */
export interface StatementCursor {
  submittedAt: string;
  id: string;
}

/**
 * The messages behind the bill, keyset-paged.
 *
 * <p><strong>Keyset rather than OFFSET.</strong> An account's month can be millions of rows, and
 * `OFFSET 500000` makes PostgreSQL walk and discard half a million of them for every page — the
 * export of a large account would spend most of its time re-reading rows it had already written.
 *
 * <p>Every message is listed, not only the priced ones, because a customer reconciling an invoice
 * against their own send log needs to find the message they are looking for. The price column is
 * what distinguishes a message that was charged, and it is the same column the total is summed from.
 *
 * <p><strong>One row per message, as UsageRollup</strong> -- not one per vendor attempt. A failover
 * used to list the message twice, the refused attempt carrying the message's own DELIVERED receipt
 * and no price, which reads to a customer as a delivered message they were not charged for. Taken
 * by `isMessageRow` rather than a `DISTINCT ON` subquery, so each keyset page still walks the index
 * instead of sorting the whole period. Vendor attempts are an operator's question, and the operator
 * message browser still shows them.
 */
export async function statementDetail(
  accountId: string,
  period: BillingPeriod,
  cursor: StatementCursor | null,
  limit: number
): Promise<{ rows: StatementRow[]; nextCursor: StatementCursor | null }> {
  const grain = { vendorAttempt: await hasVendorAttempt() };
  const params: unknown[] = [accountId, period.since, period.until, limit];
  if (cursor) {
    params.push(cursor.submittedAt, cursor.id);
  }

  //routed by the period's start, not the page's: every page of one export reads the same tables
  const rows = await cdrQuery<{
    id: string;
    submitted_at: string;
    gateway_msg_id: string;
    product: string | null;
    dst: string | null;
    src: string | null;
    part_count: number;
    final_state: string | null;
    price: string | null;
  }>(statementDetailSql(grain, cursor !== null), params, period.since);

  const mapped: StatementRow[] = rows.map((r) => ({
    id: r.id,
    submittedAt: r.submitted_at,
    gatewayMsgId: r.gateway_msg_id,
    product: r.product,
    to: r.dst,
    from: r.src,
    parts: r.part_count,
    //"Pending" rather than empty: a message with no receipt yet is a state, not a missing value
    outcome: r.final_state ?? "PENDING",
    price: r.price === null ? null : Number(r.price),
  }));

  const last = rows[rows.length - 1];
  return {
    rows: mapped,
    //a short page is the last page. Asking for one more to find out would double the query count
    nextCursor:
      last && rows.length === limit ? { submittedAt: last.submitted_at, id: last.id } : null,
  };
}

/**
 * The periods already closed for an account, newest first.
 *
 * <p>Reads `BILL` rows, which `idx_balance_ledger_human` covers — they are human entries by the
 * negative predicate, which is exactly the property V1.35.0 was written for.
 *
 * <p>`delta` is stored negative (consumption); it is returned positive, because every surface asks
 * "what was this invoiced at" rather than "which way did it move".
 */
export async function closedPeriods(accountId: string): Promise<ClosedPeriod[]> {
  const rows = await query<{ ref: string | null; delta: string; created_at: string; note: string | null }>(
    `SELECT ref, delta::text, created_at, note
       FROM balance_ledger
      WHERE account_id = $1 AND entry_type = 'BILL'
      ORDER BY created_at DESC, id DESC
      LIMIT 24`,
    [accountId]
  );
  return rows.flatMap((r) => {
    const parsed = parseBillReference(r.ref);
    //a BILL row with an unparseable ref is not shown rather than shown under a guessed period: an
    //invoice attributed to the wrong month is worse than one nobody can see
    return parsed
      ? [{ label: parsed.label, invoiced: Math.abs(Number(r.delta)), closedAt: r.created_at, note: r.note }]
      : [];
  });
}
