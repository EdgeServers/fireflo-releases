/**
 * One account's MT usage, read from the gateway's database.
 *
 * <p>Server-only and read-only. The arithmetic is `mt-usage.ts`; the SQL is `mt-usage-sql.ts`.
 */

import { query } from "./metrics-db";
import { cdrBoundary, cdrQuery } from "./cdr-tier";
import { FlightCache } from "./flight-cache";
import { hasSubmitStatus, hasUsageMtParts, hasVendorAttempt } from "./metrics-schema";
import { MT_TAIL_FROM_SQL, mtTailPlan, mtUsageSql, TODAY_SQL } from "./mt-usage-sql";
import { summariseMtUsage, type MtUsage } from "./mt-usage";

/** How long one account's usage is kept, ms. */
const MT_USAGE_TTL_MS = 60_000;

const slot = globalThis as { __firefloMtUsageCache?: FlightCache<MtUsage> };
function cache(): FlightCache<MtUsage> {
  //one per process, surviving `next dev`'s re-evaluation
  return (slot.__firefloMtUsageCache ??= new FlightCache<MtUsage>({ ttlMs: MT_USAGE_TTL_MS, maxStaleMs: MT_USAGE_TTL_MS, max: 1000 }));
}

/**
 * Kept per account (and zone) for {@link MT_USAGE_TTL_MS}, one read per key at a time: the Billing
 * tab asks on every open, from the operator panel and the portal. A failed read serves the last good
 * answer; with none it fails, as it always did.
 *
 * @param zone must match `FIREFLO_BILLING_ZONE` on the gateway, or the tail is cut into days
 *     differently from the rollup and a day near midnight is counted on the wrong side
 */
export async function mtUsageFor(accountId: string, zone: string): Promise<MtUsage> {
  return cache().get(
    `${zone}|${accountId}`,
    () => mtUsageNow(accountId, zone),
    (error) => {
      throw error ?? new Error("Usage could not be read just now; try again shortly.");
    }
  );
}

async function mtUsageNow(accountId: string, zone: string): Promise<MtUsage> {
  const [vendorAttempt, mtParts, submitStatus, seam, boundary] = await Promise.all([
    hasVendorAttempt(),
    hasUsageMtParts(),
    hasSubmitStatus(),
    query<{ tail_from: Date | string | null }>(MT_TAIL_FROM_SQL, [accountId, zone]),
    cdrBoundary(),
  ]);
  const raw = seam[0]?.tail_from;
  //the tail starts at the account's own seam, which the database has just told us: routed on that,
  //not on "everything". No line at all bounds it to the hot days (mtTailPlan)
  const plan = mtTailPlan(raw == null ? null : new Date(raw), boundary, Date.now());
  const [rows, today] = await Promise.all([
    cdrQuery<{ day: string; product: string; messages: string; mt_parts: string | null; price: string }>(
      mtUsageSql({ vendorAttempt, mtParts, submitStatus, bounded: true }),
      [accountId, zone, plan.from],
      plan.from
    ),
    query<{ today: string }>(TODAY_SQL, [zone]),
  ]);
  return {
    ...summariseMtUsage(
      rows.map((r) => ({
        day: r.day,
        product: r.product,
        messages: Number(r.messages),
        mtParts: r.mt_parts === null ? null : Number(r.mt_parts),
        price: Number(r.price),
      })),
      today[0].today
    ),
    recordsFrom: plan.recordsFrom?.toISOString() ?? null,
  };
}
