import { test } from "node:test";
import assert from "node:assert/strict";
import { createSessionsReader, LEGACY_MEMORY_MS, type SessionsExecutor } from "./sessions-read.ts";

function gateway(knowsLimits: boolean) {
  const asked: string[] = [];
  const exec: SessionsExecutor = async <T,>(call: { query: string }) => {
    asked.push(call.query);
    if (call.query === "FULL" && !knowsLimits) {
      return { ok: false as const, status: 502, code: "ValidationError", error: "Validation error (FieldUndefined@[sessions/rows/loginTpsLimit]) : Field 'loginTpsLimit' in type 'Session' is undefined" };
    }
    return { ok: true as const, data: { rows: [], total: 0 } as T };
  };
  return { exec, asked };
}

const docs = { full: "FULL", legacy: "LEGACY" };

test("a 0.15.1 gateway is asked the full document, every time", async () => {
  const read = createSessionsReader(docs);
  const gw = gateway(true);
  assert.equal((await read(gw.exec, { worker: "a" })).ok, true);
  assert.equal((await read(gw.exec, { worker: "a" })).ok, true);
  assert.deepEqual(gw.asked, ["FULL", "FULL"]);
});

test("an older gateway's refusal is retried once without the fields, and remembered", async () => {
  let clock = 0;
  const read = createSessionsReader(docs, () => clock);
  const gw = gateway(false);
  assert.equal((await read(gw.exec, { worker: "a" })).ok, true, "the caller never sees the refusal");
  assert.deepEqual(gw.asked, ["FULL", "LEGACY"]);
  await read(gw.exec, { worker: "a" });
  assert.deepEqual(gw.asked, ["FULL", "LEGACY", "LEGACY"], "remembered: no second refusal");
  clock += LEGACY_MEMORY_MS;
  await read(gw.exec, { worker: "a" });
  assert.deepEqual(gw.asked.slice(3), ["FULL", "LEGACY"], "tried again later, in case of an upgrade");
});

test("any other failure is the caller's, and is not retried", async () => {
  const read = createSessionsReader(docs);
  const asked: string[] = [];
  const exec: SessionsExecutor = async (call) => {
    asked.push(call.query);
    return { ok: false as const, status: 502, code: "UNREACHABLE", error: "Could not reach the gateway" };
  };
  const out = await read(exec, { worker: "a" });
  assert.equal(out.ok, false);
  assert.deepEqual(asked, ["FULL"]);
});
