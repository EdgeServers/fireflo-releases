import { strict as assert } from "node:assert";
import { after, before, describe, test } from "node:test";

/**
 * Operator two-factor against PostgreSQL: enrolment, the sign-in check, replay, the required switch
 * and turning it off, through the same functions the panel runs (`totp-store.ts`, given a pool).
 *
 * <p>`TOTP_TEST_DATABASE_URL` (or `CDR_TIER_TEST_DATABASE_URL`) names a database this test may
 * create and drop two schemas in: one with V1.114.0's columns, one without. The fixture is the
 * columns these functions use, not the gateway's schema.
 */
const URL = process.env.TOTP_TEST_DATABASE_URL ?? process.env.CDR_TIER_TEST_DATABASE_URL;

//sealed at rest, as on a panel with a secrets key
process.env.FIREFLO_SECRETS_KEY = "totp-test-secrets-key";

const store = await import("./totp-store.ts");
const { totpAt } = await import("./totp.ts");
const { totpGate } = await import("./totp-gate.ts");
const { isSealed } = await import("./secret-box.ts");

describe("operator two-factor in app_user", { skip: URL ? false : "TOTP_TEST_DATABASE_URL is not set" }, () => {
  const WITH = `totp_${process.pid}`;
  const WITHOUT = `totp_old_${process.pid}`;
  let admin: import("pg").Pool;
  let pool: import("pg").Pool;
  let old: import("pg").Pool;
  const dbOf = (p: import("pg").Pool): import("./totp-store.ts").Db =>
    async (sql, params) => (await p.query(sql, params ?? [])).rows;
  /** A transaction on its own connection from the pool, as the panel's inTransaction. */
  const txOf = (p: import("pg").Pool): import("./totp-store.ts").Tx => async (work) => {
    const client = await p.connect();
    try {
      await client.query("BEGIN");
      const out = await work(async (sql, params) => (await client.query(sql, params ?? [])).rows);
      await client.query("COMMIT");
      return out;
    } catch (err) {
      await client.query("ROLLBACK").catch(() => undefined);
      throw err;
    } finally {
      client.release();
    }
  };
  let tx: import("./totp-store.ts").Tx;
  let wide: import("pg").Pool;
  let db: import("./totp-store.ts").Db;
  let id: number;

  before(async () => {
    const pg = (await import("pg")).default;
    admin = new pg.Pool({ connectionString: URL, max: 1 });
    await admin.query(`CREATE SCHEMA ${WITH}`);
    await admin.query(`CREATE SCHEMA ${WITHOUT}`);
    pool = new pg.Pool({ connectionString: URL, max: 1, options: `-c search_path=${WITH}` });
    //many connections, for the concurrency test: guesses really do run at once
    wide = new pg.Pool({ connectionString: URL, max: 20, options: `-c search_path=${WITH}` });
    old = new pg.Pool({ connectionString: URL, max: 1, options: `-c search_path=${WITHOUT}` });
    const base = `id bigserial PRIMARY KEY, email text NOT NULL, role text NOT NULL, account_id text,
                  enabled boolean NOT NULL DEFAULT true, password_hash text, password_changed_at timestamptz`;
    await pool.query(`CREATE TABLE app_user (${base}, totp_secret text, totp_pending_secret text,
                      totp_pending_at timestamptz, totp_enabled_at timestamptz, totp_last_step bigint,
                      totp_failed_count int NOT NULL DEFAULT 0, totp_locked_until timestamptz,
                      totp_changed_at timestamptz)`);
    await old.query(`CREATE TABLE app_user (${base})`);
    for (const p of [pool, old]) {
      await p.query("CREATE TABLE app_config (key text PRIMARY KEY, value text, enabled boolean NOT NULL DEFAULT true)");
    }
    id = Number((await pool.query("INSERT INTO app_user (email, role) VALUES ('ops@example.com', 'operator') RETURNING id")).rows[0].id);
    db = dbOf(pool);
    tx = txOf(pool);
  });

  after(async () => {
    await pool?.end();
    await wide?.end();
    await old?.end();
    if (admin) {
      await admin.query(`DROP SCHEMA IF EXISTS ${WITH} CASCADE`).catch(() => undefined);
      await admin.query(`DROP SCHEMA IF EXISTS ${WITHOUT} CASCADE`).catch(() => undefined);
      await admin.end();
    }
  });

  test("a database without V1.114.0's columns has no two-factor", async () => {
    store.resetTotpProbe();
    assert.equal(await store.hasTotpColumns(dbOf(old)), false);
    store.resetTotpProbe();
    assert.equal(await store.hasTotpColumns(db), true, "this schema's own, though another has none");
    store.resetTotpProbe();
  });

  test("enrolment: a pending secret, sealed, confirmed by its first code, lapsing after 15 minutes", async () => {
    const t0 = Date.now();
    assert.deepEqual(await store.totpStatus(id, db, t0), { enabled: false, enabledAt: null, pending: false });
    const secret = await store.startEnrolment(id, db);
    const [row] = (await pool.query("SELECT totp_pending_secret, totp_secret FROM app_user WHERE id = $1", [id])).rows;
    assert.ok(isSealed(row.totp_pending_secret), "kept sealed with FIREFLO_SECRETS_KEY");
    assert.equal(row.totp_secret, null);
    assert.equal((await store.totpStatus(id, db))!.pending, true);

    assert.equal((await store.attemptCode(id, "000000", "confirm", { tx })).outcome, "wrong", "a wrong code changes nothing but the count");
    assert.equal((await store.attemptCode(id, totpAt(secret, Date.now())!, "confirm", { tx, now: Date.now() + 16 * 60_000 })).outcome,
      "none", "a lapsed set-up");

    //a restart replaces the secret: the first one's codes no longer confirm it
    const second = await store.startEnrolment(id, db);
    assert.notEqual(second, secret);
    assert.equal((await store.attemptCode(id, totpAt(secret, Date.now())!, "confirm", { tx })).outcome, "wrong");

    const done = await store.attemptCode(id, totpAt(second, Date.now())!, "confirm", { tx });
    assert.equal(done.outcome, "ok");
    const ok = done as Extract<typeof done, { outcome: "ok" }>;
    assert.equal(typeof ok.stamp, "number");
    assert.equal(ok.changed, ok.stamp, "turning it on is a change");
    const [after] = (await pool.query("SELECT totp_failed_count, totp_locked_until FROM app_user WHERE id = $1", [id])).rows;
    assert.deepEqual([after.totp_failed_count, after.totp_locked_until], [0, null], "a right code resets the count");
    const status = (await store.totpStatus(id, db))!;
    assert.equal(status.enabled, true);
    assert.equal(new Date(status.enabledAt!).getTime(), ok.stamp);
    await assert.rejects(store.startEnrolment(id, db), store.TotpRefused, "already on");
    //the enrolling code's step is used: it cannot sign in as well
    assert.equal((await store.attemptCode(id, totpAt(second, Date.now())!, "signin", { tx })).outcome, "wrong");
    await pool.query("UPDATE app_user SET totp_failed_count = 0 WHERE id = $1", [id]);
    (globalThis as { secret?: string }).secret = second;
  });

  test("sign-in: a code is good once, and a racing second use gets nothing", async () => {
    const secret = (globalThis as { secret?: string }).secret!;
    const next = Date.now() + 30_000;
    const code = totpAt(secret, next)!;
    const wideTx = txOf(wide);
    //four, so the replays (each a counted failure) stay under the lock
    const results = await Promise.all(Array.from({ length: 4 }, () => store.attemptCode(id, code, "signin", { tx: wideTx, now: next })));
    assert.equal(results.filter((r) => r.outcome === "ok").length, 1, "exactly one of the four");
    assert.equal(results.filter((r) => r.outcome === "wrong").length, 3, "the rest are replays");
    await pool.query("UPDATE app_user SET totp_failed_count = 0 WHERE id = $1", [id]);
    assert.equal((await store.attemptCode(id, code, "signin", { tx, now: next })).outcome, "wrong", "and never again");
    const later = await store.attemptCode(id, totpAt(secret, next + 30_000)!, "signin", { tx, now: next + 30_000 });
    assert.equal(later.outcome, "ok", "the next step's code");
    await pool.query("UPDATE app_user SET totp_failed_count = 0, totp_locked_until = NULL WHERE id = $1", [id]);
  });

  test("200 wrong codes at once: five are checked, then the user's code checks lock", async () => {
    const secret = (globalThis as { secret?: string }).secret!;
    const wideTx = txOf(wide);
    const burst = await Promise.all(Array.from({ length: 200 }, (_, i) =>
      store.attemptCode(id, String(100000 + i), "signin", { tx: wideTx })));
    const checked = burst.filter((r) => r.outcome === "wrong");
    assert.equal(checked.length, store.FAILURES_PER_LOCK, "only the first five are ever verified");
    assert.equal(burst.filter((r) => r.outcome === "locked").length, 200 - store.FAILURES_PER_LOCK);
    const locking = checked.filter((r) => r.outcome === "wrong" && r.lockedUntil);
    assert.equal(locking.length, 1, "the fifth locks");
    const until = (locking[0] as { lockedUntil: Date }).lockedUntil.getTime();
    assert.ok(Math.abs(until - Date.now() - 15 * 60_000) < 60_000, "for 15 minutes");
    //even the right code is refused while locked
    assert.equal((await store.attemptCode(id, totpAt(secret, Date.now() + 60_000)!, "signin", { tx, now: Date.now() + 60_000 })).outcome, "locked");
    assert.ok(await store.codeChecksLocked(id, db));

    //once the lock has passed, the next five wrong codes lock for twice as long
    await pool.query("UPDATE app_user SET totp_locked_until = now() - interval '1 second' WHERE id = $1", [id]);
    let last: Awaited<ReturnType<typeof store.attemptCode>> | null = null;
    for (let i = 0; i < store.FAILURES_PER_LOCK; i++) {
      last = await store.attemptCode(id, "999999", "signin", { tx });
    }
    assert.equal(last!.outcome, "wrong");
    const second = (last as { lockedUntil: Date }).lockedUntil.getTime();
    assert.ok(Math.abs(second - Date.now() - 30 * 60_000) < 60_000, "30 minutes the second time");

    //a right code after the lock has passed resets the count
    await pool.query("UPDATE app_user SET totp_locked_until = now() - interval '1 second' WHERE id = $1", [id]);
    assert.equal((await store.attemptCode(id, totpAt(secret, Date.now() + 90_000)!, "signin", { tx, now: Date.now() + 90_000 })).outcome, "ok");
    const [row] = (await pool.query("SELECT totp_failed_count, totp_locked_until FROM app_user WHERE id = $1", [id])).rows;
    assert.deepEqual([row.totp_failed_count, row.totp_locked_until], [0, null]);
  });

  test("required mode: no authenticator is the set-up only; one, with a stale session, is refused", async () => {
    const other = Number((await pool.query("INSERT INTO app_user (email, role) VALUES ('new@example.com', 'admin') RETURNING id")).rows[0].id);
    let live = (await store.liveOperator(other, db))!;
    const gate = (l: typeof live, sessionStamp: number | null, sessionChanged: number | null) =>
      totpGate({ rowStamp: l.totpStamp, sessionStamp, required: l.totpRequired, rowChanged: l.totpChanged, sessionChanged });
    assert.equal(live.totpRequired, false);
    assert.equal(gate(live, null, null), "ok");
    await pool.query(`INSERT INTO app_config (key, value) VALUES ('${store.TOTP_REQUIRED_KEY}', 'true')`);
    live = (await store.liveOperator(other, db))!;
    assert.equal(live.totpRequired, true);
    assert.equal(gate(live, null, null), "enrol");
    //the operator with an authenticator: a session verified with it passes, one without is refused
    const mine = (await store.liveOperator(id, db))!;
    assert.equal(gate(mine, mine.totpStamp, mine.totpChanged), "ok");
    assert.equal(gate(mine, null, mine.totpChanged), "refuse");
    assert.equal(gate(mine, mine.totpStamp, null), "refuse", "a session from before two-factor was turned on");
    //a disabled row switch is not required
    await pool.query(`UPDATE app_config SET enabled = false WHERE key = '${store.TOTP_REQUIRED_KEY}'`);
    assert.equal(await store.totpRequired(db), false);
  });

  test("turning it off takes a code, clears every column and is a change older sessions fail on", async () => {
    const secret = (globalThis as { secret?: string }).secret!;
    const before = (await store.liveOperator(id, db))!;
    const at = Date.now() + 120_000;
    assert.equal((await store.attemptCode(id, "123456", "disable", { tx, now: at })).outcome, "wrong");
    const done = await store.attemptCode(id, totpAt(secret, at)!, "disable", { tx, now: at });
    assert.equal(done.outcome, "ok");
    const [row] = (await pool.query(
      "SELECT totp_secret, totp_pending_secret, totp_pending_at, totp_enabled_at, totp_last_step, totp_failed_count, totp_locked_until FROM app_user WHERE id = $1", [id])).rows;
    assert.deepEqual(Object.values(row), [null, null, null, null, null, 0, null]);
    const after = (await store.liveOperator(id, db))!;
    assert.ok(after.totpChanged! > before.totpChanged!, "totp_changed_at moved");
    assert.equal(totpGate({ rowStamp: after.totpStamp, sessionStamp: before.totpStamp, required: false,
      rowChanged: after.totpChanged, sessionChanged: before.totpChanged }), "refuse", "a session from before the disable");
    assert.equal((await store.attemptCode(id, "123456", "signin", { tx })).outcome, "none", "nothing to check against");
  });
});
