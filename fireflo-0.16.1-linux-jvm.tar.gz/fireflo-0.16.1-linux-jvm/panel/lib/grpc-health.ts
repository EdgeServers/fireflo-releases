/**
 * The gRPC listener as the Queues page's card shows it (gateway 0.15.9). Pure.
 *
 * <p>Health's `grpc` block: whether the listener is on and on which port, the sessions and streams
 * open on this node, and the receipt feed -- receipts queued for HTTP logins that collect them over
 * gRPC, the oldest unacknowledged one's age, how many logins are at their cap, and the deepest
 * queues. Absent on an older gateway, which hides the card rather than showing zeros.
 */

import type { Health, HealthGrpc } from "./health-types";

export interface GrpcView {
  enabled: boolean;
  /** Null while switched off, or when the gateway did not say. */
  port: number | null;
  sessions: number;
  /** Of `sessions`, platform sessions (PlatformLogin, gateway 0.15.10); null on an older gateway. */
  sessionsPlatform: number | null;
  streams: number;
  receipts: {
    depth: number;
    oldestAgeSeconds: number | null;
    loginsAtCap: number;
    top: { systemId: string; depth: number }[];
  };
}

const num = (v: unknown): number | null =>
  typeof v === "number" && Number.isFinite(v) ? v : v != null && v !== "" && Number.isFinite(Number(v)) ? Number(v) : null;

/** Health's `grpc`, read for the card, or null when the gateway publishes none. */
export function grpcView(health: Health | null | undefined): GrpcView | null {
  const g: HealthGrpc | null | undefined = health?.grpc;
  if (!g || typeof g !== "object") {
    return null;
  }
  const r = g.receipts && typeof g.receipts === "object" ? g.receipts : {};
  const port = num(g.port);
  return {
    enabled: g.enabled === true,
    port: port && port > 0 ? port : null,
    sessions: num(g.sessions) ?? 0,
    sessionsPlatform: num(g.sessions_platform),
    //the gateway reports streams by kind, `{send: n}`; a plain number is taken too so an older or
    //newer block still reads
    streams: typeof g.streams === "number" ? g.streams : (num(g.streams?.send) ?? 0),
    receipts: {
      depth: num(r.depth) ?? 0,
      oldestAgeSeconds: num(r.oldest_age_seconds),
      loginsAtCap: num(r.logins_at_cap) ?? 0,
      top: (Array.isArray(r.top) ? r.top : [])
        .filter((t) => t && typeof t.system_id === "string" && t.system_id)
        .map((t) => ({ systemId: t.system_id, depth: num(t.depth) ?? 0 }))
        .sort((a, b) => b.depth - a.depth || a.systemId.localeCompare(b.systemId)),
    },
  };
}

/** The pill: Off, On, or a warning when a login is at its cap and receipts are being left out. */
export function grpcPill(v: GrpcView): { tone: "success" | "warning" | "outline"; label: string } {
  if (!v.enabled) {
    return { tone: "outline", label: "Off" };
  }
  if (v.receipts.loginsAtCap > 0) {
    return { tone: "warning", label: `${v.receipts.loginsAtCap} login${v.receipts.loginsAtCap === 1 ? "" : "s"} at cap` };
  }
  return { tone: "success", label: "On" };
}

/** The card's one sentence: what it is, and what to do when it is off or a feed is full. */
export function grpcExplainer(v: GrpcView): string {
  if (!v.enabled) {
    return "gRPC is switched off on this gateway: set FIREFLO_GRPC_PORT (the installer's --grpc-port) and restart to open it. REST and SMPP are unaffected.";
  }
  const base =
    "Sessions and streams are this node's. Receipts wait here for HTTP logins that send dlr without a dlr_url, until the customer acknowledges them over gRPC (Subscribe or Pull, then Ack).";
  return v.receipts.loginsAtCap > 0
    ? `${base} A login at its cap (smsg.grpc.receipts.max.per.login) gets no new receipts queued until it reads its feed.`
    : base;
}
