import { validateRange } from "./date-range.ts";
import type { UsageGrain } from "./usage-grid-sql.ts";

/**
 * Report > Usage's filters, rows and grains (0.15.1), with no database import: shared by the page
 * and the reader, and tested on its own.
 */

/** Rows per page of the account table. */
export const USAGE_PAGE_SIZE = 50;
/** "Expand all" fetches the breakdowns of at most this many rows on screen. */
export const EXPAND_ALL_MAX = 25;
/** The typeahead's: at least this many characters, this long a pause, this many suggestions. */
export const LOOKUP_MIN_CHARS = 2;
export const LOOKUP_DEBOUNCE_MS = 250;
export const LOOKUP_LIMIT = 10;

/** The quick-filter bar, as applied. Null is "any". */
export interface UsageFilters {
  account: string | null;
  login: string | null;
  product: string | null;
  /** `YYYY-MM-DD`, billing days, both included; together they replace the range toggle. */
  from: string | null;
  to: string | null;
}

export const NO_FILTERS: UsageFilters = { account: null, login: null, product: null, from: null, to: null };

/** One identifier from the query string: trimmed, at most 200 characters, or null. */
function ident(value: string | null): string | null {
  const v = (value ?? "").trim();
  return v && v.length <= 200 ? v : null;
}

/**
 * The filters a request carries, checked: dates both or neither, at most 92 days (MAX_RANGE_DAYS).
 *
 * @returns the filters, or a sentence saying what is wrong with them
 */
export function parseUsageFilters(params: URLSearchParams): UsageFilters | { error: string } {
  const from = ident(params.get("from"));
  const to = ident(params.get("to"));
  if (from || to) {
    if (!from || !to || !/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to)) {
      return { error: "Choose both a From and a To date, as YYYY-MM-DD." };
    }
    const invalid = validateRange(from, to);
    if (invalid) {
      return { error: invalid };
    }
  }
  return { account: ident(params.get("account")), login: ident(params.get("login")), product: ident(params.get("product")), from, to };
}

/** The filters as the query string the stats route reads (only those set). */
export function filterQuery(f: UsageFilters): Record<string, string> {
  const q: Record<string, string> = {};
  for (const key of ["account", "login", "product", "from", "to"] as const) {
    const v = f[key];
    if (v) {
      q[key] = v;
    }
  }
  return q;
}

/**
 * How finely a window is cut: hours for the hour and the 24 hours, and for a date range under two
 * days; days otherwise. A breakdown is one sub-row per bucket, so it is offered only when there is
 * more than one -- never for the last hour.
 */
export function grainFor(range: string, f: Pick<UsageFilters, "from" | "to">): UsageGrain {
  if (f.from && f.to) {
    const days = Math.round((Date.parse(`${f.to}T00:00:00Z`) - Date.parse(`${f.from}T00:00:00Z`)) / 86_400_000) + 1;
    return days < 2 ? "hour" : "day";
  }
  return range === "1h" || range === "24h" ? "hour" : "day";
}

/** Whether rows can be expanded in this window. */
export function expandable(range: string, f: Pick<UsageFilters, "from" | "to">): boolean {
  return !(range === "1h" && !(f.from && f.to));
}

/** One row of the account table: an account, a login and a product, each null for none. */
export interface UsageGridRow {
  accountId: string | null;
  login: string | null;
  product: string | null;
  submitted: number;
  delivered: number;
  failed: number;
  pending: number;
  price: number;
}

/** One bucket of the chart or of a row's breakdown. */
export interface UsageBucket {
  /** `YYYY-MM-DD` for a day, the UTC hour as an ISO instant for an hour. */
  bucket: string;
  submitted: number;
  delivered: number;
  failed: number;
  pending: number;
  price: number;
}

/** What the page draws: the window, one page of rows, every bucket, and what the summaries know. */
export interface UsageGridView {
  grain: UsageGrain;
  since: string;
  until: string;
  page: number;
  pageSize: number;
  totalRows: number;
  rows: UsageGridRow[];
  series: UsageBucket[];
  /** Whether each summary records the login: day windows read "—" before V1.115.0. */
  logins: { daily: boolean; hourly: boolean };
}

/**
 * A row's React key and its breakdown's identity. A NUL separates the parts and stands for "none",
 * written as an escape: no identifier from the wire can contain it.
 */
export function rowKey(r: Pick<UsageGridRow, "accountId" | "login" | "product">): string {
  return [r.accountId, r.login, r.product].map((v) => (v === null ? "\u0000" : v)).join("\u0000|");
}

/**
 * The query string of one row's breakdown: its three keys as `ra`, `rl` and `rp`, each left out
 * when the row has none -- which the reader matches as exactly none, not as anything.
 */
export function breakdownQuery(r: Pick<UsageGridRow, "accountId" | "login" | "product">): Record<string, string> {
  const q: Record<string, string> = {};
  if (r.accountId !== null) q.ra = r.accountId;
  if (r.login !== null) q.rl = r.login;
  if (r.product !== null) q.rp = r.product;
  return q;
}

/** Delivered as a share of what settled, as the rest of Usage divides; null when nothing has. */
export function rateOf(r: { delivered: number; failed: number }): number | null {
  const settled = r.delivered + r.failed;
  return settled === 0 ? null : r.delivered / settled;
}

/** The sums over buckets: the tiles and a check that rows and breakdowns agree. */
export function sumBuckets(rows: readonly { submitted: number; delivered: number; failed: number; pending: number; price: number }[]) {
  return rows.reduce(
    (t, r) => ({
      submitted: t.submitted + r.submitted,
      delivered: t.delivered + r.delivered,
      failed: t.failed + r.failed,
      pending: t.pending + r.pending,
      price: t.price + r.price,
    }),
    { submitted: 0, delivered: 0, failed: 0, pending: 0, price: 0 }
  );
}
