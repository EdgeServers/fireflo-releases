import { strict as assert } from "node:assert";
import { test } from "node:test";

import {
  CDR_EVERYTHING,
  CDR_HOT_FALLBACK_MS,
  CDR_ROUTED,
  CDR_TIER_MARGIN_MS,
  cdrHotStart,
  cdrRouteChosen,
  cdrRouteSql,
  isMessageRow,
} from "./cdr-grain.ts";
import { failureFallbackRecordsFrom } from "./failure-breakdown-sql.ts";
import { MT_TAIL_FROM_SQL, mtTailPlan, mtUsageSql } from "./mt-usage-sql.ts";
import { planRoute, routedSql, sliversOf, type RawSlivers } from "./usage-route-plan.ts";
import {
  OUTCOME_LATERAL,
  accountUsageRawSql,
  accountUsageSql,
  usageHourlySql,
  usageRawSliversSql,
  usageWindowSql,
} from "./usage-summary-sql.ts";
import { vendorPerformanceHourlySql, vendorRawSliversSql } from "./vendor-performance-sql.ts";

/*
 * Incident 2026-10-31: summary-backed readers routed on their WINDOW's start, so every 7- and
 * 30-day read named the _all views (and the cold archive behind them) for raw rows that were all in
 * the hot days. These pin the new choice -- and that it is the old one wherever the old was right.
 */

const DAY = 86_400_000;
const NOW = Date.parse("2026-10-31T10:07:30Z");
/** Three hot days. */
const BOUNDARY = new Date(NOW - 3 * DAY);
const at = (msAgo: number) => new Date(NOW - msAgo);
const sl = (head: [number, number] | null, tail: [number, number] | null): RawSlivers => ({
  head: head ? { from: at(head[0]), to: at(head[1]) } : { from: null, to: null },
  tail: tail ? { from: at(tail[0]), to: at(tail[1]) } : { from: null, to: null },
});

/** Every call record table the statement reads, by the name it reads it by. */
const tables = (sql: string) => [...new Set(sql.match(/\bcdr_(submit|final|interim|event|rejected)(_all)?\b/g) ?? [])].sort();
const namesAll = (sql: string) => /\bcdr_\w+_all\b/.test(sql);
const namesHot = (sql: string) => /\bcdr_(submit|final|interim|event|rejected)\b(?!_)/.test(sql);

const OPTS = { bucket: "day", account: false, wholeDays: true, vendorAttempt: true } as const;

test("a 30-day window whose raw slivers are in the hot days names the hot tables, not _all", () => {
  //the daily seam: no head (whole days), the tail from the day before the newest line
  const plan = planRoute(sl(null, [2 * DAY, 0]), BOUNDARY, { splittable: false });
  assert.deepEqual(plan, { kind: "statement", hot: true });
  const sql = routedSql(plan, () => usageWindowSql(OPTS));
  assert.ok(sql.startsWith(CDR_ROUTED));
  assert.deepEqual(tables(sql), ["cdr_final", "cdr_submit"]);
  //what the window's start chose before: the archive, for rows it cannot hold
  assert.ok(namesAll(cdrRouteSql(usageWindowSql(OPTS), at(30 * DAY), BOUNDARY)));
});

test("where the old routing was right, the plan makes the same choice", () => {
  //a window inside the hot days: hot, as before
  for (const since of [at(DAY), at(2 * DAY)]) {
    const plan = planRoute(sl(null, [(NOW - since.getTime()), 0]), BOUNDARY, { splittable: false });
    assert.equal(routedSql(plan, () => usageWindowSql(OPTS)), cdrRouteSql(usageWindowSql(OPTS), since, BOUNDARY));
  }
  //a tail that really reaches into the archive (no usage_daily lines: the whole window is raw)
  const plan = planRoute(sl(null, [30 * DAY, 0]), BOUNDARY, { splittable: false });
  assert.equal(routedSql(plan, () => usageWindowSql(OPTS)), cdrRouteSql(usageWindowSql(OPTS), at(30 * DAY), BOUNDARY));
  //a sliver starting within the hour of margin after the boundary is not hot, exactly as cdrWindowIsHot says
  const edge = 3 * DAY - CDR_TIER_MARGIN_MS / 2;
  assert.deepEqual(planRoute(sl(null, [edge, 0]), BOUNDARY, { splittable: false }), { kind: "statement", hot: false });
  //without tiers every statement is as written; with an unreadable boundary everything is _all
  assert.deepEqual(planRoute(sl(null, [30 * DAY, 0]), null, { splittable: true }), { kind: "statement", hot: true });
  assert.equal(routedSql({ kind: "statement", hot: true }, () => usageWindowSql(OPTS)), cdrRouteSql(usageWindowSql(OPTS), at(30 * DAY), null));
  assert.deepEqual(planRoute(sl(null, [60_000, 0]), CDR_EVERYTHING, { splittable: true }), { kind: "statement", hot: false });
});

test("empty slivers do not count; no raw rows at all reads hot", () => {
  //the hourly path for a range starting on the hour: head [since, since) is empty
  assert.deepEqual(planRoute(sl([30 * DAY, 30 * DAY], [120_000, 0]), BOUNDARY, { splittable: true }),
    { kind: "statement", hot: true });
  assert.deepEqual(planRoute(sl(null, [0, 0]), BOUNDARY, { splittable: false }), { kind: "statement", hot: true });
  //a head whose end is before its start (LEAST of a seam before since) is empty too
  assert.deepEqual(planRoute(sl([30 * DAY, 31 * DAY], [120_000, 0]), BOUNDARY, { splittable: false }),
    { kind: "statement", hot: true });
});

test("a head in the archive and a tail in the hot days: split where the statement can, else _all", () => {
  const raw = sl([30 * DAY, 30 * DAY - 30 * 60_000], [120_000, 0]);
  assert.deepEqual(planRoute(raw, BOUNDARY, { splittable: true }), { kind: "split", head: "all", tail: "hot" });
  //a statement that cannot split reads the views, as it did
  assert.deepEqual(planRoute(raw, BOUNDARY, { splittable: false }), { kind: "statement", hot: false });
});

test("a split hourly statement reads the head through the views and the tail from the hot tables", () => {
  const o = { bucket: "day", account: true, logins: false, vendorAttempt: true, refused: true } as const;
  const sql = routedSql({ kind: "split", head: "all", tail: "hot" }, (slivers) => usageHourlySql({ ...o, ...(slivers ? { slivers } : {}) }));
  const [head, tail] = sql.split(/--the head sliver|--the tail sliver/).slice(1);
  assert.ok(head && tail, "two live selects");
  assert.deepEqual(tables(head), ["cdr_final_all", "cdr_rejected_all", "cdr_submit_all"]);
  assert.deepEqual(tables(tail), ["cdr_final", "cdr_rejected", "cdr_submit"]);
  //the slivers keep their own bounds, and each its own outcome LATERAL
  assert.match(head, /s\.submitted_at >= cut\.since\s+AND s\.submitted_at < LEAST\(cut\.until, cut\.first_hour, cut\.seam\)/);
  assert.match(tail, /s\.submitted_at >= GREATEST\(cut\.seam, cut\.since\)\s+AND s\.submitted_at < cut\.until/);
  assert.equal(sql.split("LEFT JOIN LATERAL").length - 1, 2);
  //without slivers the statement is exactly what it always was
  assert.equal(usageHourlySql(o), usageHourlySql({ ...o, slivers: undefined }));
  assert.doesNotMatch(usageHourlySql(o), /--the head sliver/);
});

test("the pre-reads are the statements' own cut, name no call record table, and bind what they use", () => {
  const daily = usageRawSliversSql("live", { ...OPTS, account: true });
  assert.equal(daily.binds, 4);
  assert.deepEqual(tables(daily.sql), []);
  //the same cut text as the statement it plans for
  const cut = (sql: string) => sql.slice(sql.indexOf("cut AS ("), sql.indexOf("\n  )", sql.indexOf("cut AS (")));
  assert.equal(cut(daily.sql), cut(usageWindowSql({ ...OPTS, account: true })));
  assert.match(daily.sql, /NULL::timestamptz AS head_from/, "whole days: no head");
  assert.match(daily.sql, /GREATEST\(cut\.since, cut\.first_full_at, LEAST\(cut\.tail_from, cut\.end_full_at\)\) AS tail_from/);
  const partial = usageRawSliversSql("live", { ...OPTS, wholeDays: false });
  assert.equal(partial.binds, 3);
  assert.match(partial.sql, /cut\.since AS head_from, LEAST\(cut\.until, cut\.first_full_at\) AS head_to/);

  const hourly = usageRawSliversSql("hourly", { ...OPTS, accounts: true });
  assert.equal(hourly.binds, 2, "the hourly cut reads since and until only");
  assert.doesNotMatch(hourly.sql, /\$[3-9]/);
  assert.equal(cut(hourly.sql), cut(usageHourlySql({ ...OPTS, accounts: true })));
  assert.deepEqual(tables(hourly.sql), []);

  const vendor = vendorRawSliversSql();
  assert.equal(vendor.binds, 3);
  assert.deepEqual(tables(vendor.sql), []);
  assert.equal(cut(vendor.sql), cut(vendorPerformanceHourlySql(true)));
  assert.match(vendor.sql, /cut\.since AS head_from, LEAST\(cut\.first_hour, cut\.seam\) AS head_to,\s+cut\.seam AS tail_from, cut\.until AS tail_to/);

  const acct = { source: "hourly", logins: false, scoped: true, vendorAttempt: true } as const;
  assert.equal(accountUsageRawSql(acct).sql, usageRawSliversSql("hourly", { bucket: "day", account: true, wholeDays: false }).sql);
  assert.equal(accountUsageRawSql({ ...acct, source: "live" }).binds, 4);
});

test("accountUsage at 30 days: the hourly statement split, or hot, never _all for minutes of rows", () => {
  const acct = { source: "hourly", logins: false, scoped: false, vendorAttempt: true } as const;
  //a half-hour zone's midnight: a 30-minute head 30 days back, the tail two minutes old
  const split = planRoute(sl([30 * DAY, 30 * DAY - 30 * 60_000], [120_000, 0]), BOUNDARY, { splittable: true });
  const sql = routedSql(split, (slivers) => accountUsageSql({ ...acct, ...(slivers ? { slivers } : {}) }));
  assert.ok(namesHot(sql) && namesAll(sql));
  //a whole-hour zone: no head, so the statement is hot and is exactly the old text
  const hot = planRoute(sl([30 * DAY, 30 * DAY], [120_000, 0]), BOUNDARY, { splittable: true });
  assert.equal(routedSql(hot, (slivers) => accountUsageSql({ ...acct, ...(slivers ? { slivers } : {}) })),
    `${CDR_ROUTED} ${accountUsageSql(acct)}`);
});

test("vendorPerformance at 30 days with the summary covering the range: hot", () => {
  //first_hour is the hour since falls in, so the head is empty unless the summary began later
  const plan = planRoute(sl([30 * DAY, 30 * DAY - 1], [90_000, 0]), BOUNDARY, { splittable: false });
  assert.equal(plan.kind, "statement");
  assert.equal(plan.kind === "statement" && plan.hot, false, "a non-empty head 30 days back: the views, as before");
  const covered = planRoute(sl([30 * DAY, 30 * DAY], [90_000, 0]), BOUNDARY, { splittable: false });
  assert.deepEqual(tables(routedSql(covered, () => vendorPerformanceHourlySql(true))), ["cdr_final", "cdr_submit"]);
});

test("the pre-read's row parses, Dates or strings, and a missing value is no sliver", () => {
  const s = sliversOf({ head_from: "2026-10-01T00:00:00Z", head_to: null, tail_from: new Date(NOW), tail_to: "garbage" });
  assert.equal(s.head.from?.toISOString(), "2026-10-01T00:00:00.000Z");
  assert.equal(s.head.to, null);
  assert.equal(s.tail.from?.getTime(), NOW);
  assert.equal(s.tail.to, null);
  assert.deepEqual(sliversOf(undefined), { head: { from: null, to: null }, tail: { from: null, to: null } });
});

test("the portal's lists start at the hot boundary, so a 14-day range reads the hot tables", () => {
  const since = at(14 * DAY);
  const start = cdrHotStart(since, BOUNDARY, NOW);
  assert.equal(start.getTime(), BOUNDARY.getTime() + CDR_TIER_MARGIN_MS);
  const list = `SELECT s.gateway_msg_id FROM cdr_submit s${OUTCOME_LATERAL}
    WHERE ${isMessageRow("s", { vendorAttempt: true })} AND s.submitted_at >= $2 ORDER BY s.submitted_at DESC LIMIT 6`;
  assert.ok(!namesAll(cdrRouteSql(list, start, BOUNDARY)), "hot");
  assert.ok(namesAll(cdrRouteSql(list, since, BOUNDARY)), "what the range's start chose");
  //a range inside the hot days keeps its own start; no tiers keeps it whatever it is
  assert.equal(cdrHotStart(at(DAY), BOUNDARY, NOW).getTime(), at(DAY).getTime());
  assert.equal(cdrHotStart(since, null, NOW), since);
  //an unreadable boundary: the last three days, through the views
  assert.equal(cdrHotStart(since, CDR_EVERYTHING, NOW).getTime(), NOW - CDR_HOT_FALLBACK_MS);
  assert.equal(cdrRouteChosen("SELECT 1 FROM cdr_submit", false), `${CDR_ROUTED} SELECT 1 FROM cdr_submit_all`);
});

test("MT usage: routed on the account's own seam; no line at all reads the hot days only", () => {
  const seam = at(2 * DAY);
  assert.deepEqual(mtTailPlan(seam, BOUNDARY, NOW), { from: seam, recordsFrom: null });
  //and the statement routed on it is hot, where it used to be routed on "everything"
  const sql = mtUsageSql({ vendorAttempt: true, mtParts: true, submitStatus: true, bounded: true });
  assert.ok(!namesAll(cdrRouteSql(sql, seam, BOUNDARY)));
  assert.ok(namesAll(cdrRouteSql(sql, null, BOUNDARY)), "the old routing");
  //an old seam still reads the views, as it must
  assert.ok(namesAll(cdrRouteSql(sql, mtTailPlan(at(40 * DAY), BOUNDARY, NOW).from, BOUNDARY)));

  const never = mtTailPlan(null, BOUNDARY, NOW);
  assert.equal(never.from.getTime(), BOUNDARY.getTime() + CDR_TIER_MARGIN_MS);
  assert.equal(never.recordsFrom, never.from, "the page is told the figures are partial");
  assert.ok(!namesAll(cdrRouteSql(sql, never.from, BOUNDARY)));
  assert.equal(mtTailPlan(null, null, NOW).from.getTime(), NOW - CDR_HOT_FALLBACK_MS);
  assert.equal(mtTailPlan(null, CDR_EVERYTHING, NOW).from.getTime(), NOW - CDR_HOT_FALLBACK_MS);

  //the bound is ADDED to the seam the statement computes, which it never undercuts
  assert.match(sql, /AND s\.submitted_at >= \(SELECT COALESCE\(\(\(max\(u\.day\) - 1\)[^]*?WHERE u\.account_id = \$1\)\s+AND s\.submitted_at >= \$3::timestamptz\s+AND NOT EXISTS/);
  assert.doesNotMatch(mtUsageSql({ vendorAttempt: true, mtParts: true, submitStatus: true }), /\$3/);
  assert.deepEqual(tables(MT_TAIL_FROM_SQL), []);
  assert.match(MT_TAIL_FROM_SQL, /\(max\(u\.day\) - 1\)::timestamp AT TIME ZONE \$2/);
});

test("the failure breakdown's records fallback is routed on the day it reads, not the range", () => {
  const until = new Date(NOW);
  const from = failureFallbackRecordsFrom(at(30 * DAY), until, NOW);
  assert.equal(from.getTime(), NOW - 26 * 3_600_000);
  //never before since, and from a caller's own earlier end
  assert.equal(failureFallbackRecordsFrom(at(3_600_000), until, NOW).getTime(), NOW - 3_600_000);
  assert.equal(failureFallbackRecordsFrom(at(30 * DAY), at(DAY), NOW).getTime(), NOW - DAY - 26 * 3_600_000);
  //hot with three hot days, where cdrEarlier(30 days) was the archive
  assert.ok(from.getTime() - CDR_TIER_MARGIN_MS >= BOUNDARY.getTime());
});
