import type { LimitSource } from "./health-types";
import type { GqlFailure, GqlOutcome } from "./gateway-graphql-core";
import { formatTps } from "./tps-format.ts";

/**
 * One account's throughput, as the gateway explains it (0.15.1, `accountThroughput`): for every
 * SMPP listener the ceiling and the setting that produced it, the cluster share and what this node
 * enforces, live TPS, binds against the bind limit and the throttle counts -- per login too -- plus
 * the HTTP ceiling. What the Account › Limits tab draws (`S['account-limits']` in the mockups).
 *
 * <p>No database and no React, so the wording of a source chip and of `configured × share` is
 * tested against plain objects. The gateway call is passed in for the same reason.
 */

/** Where a setting's value came from, as the gateway's `SettingTier` names it. */
export type SettingTier = "LISTENER" | "GATEWAY" | "ENVIRONMENT" | "CODED" | "RUNTIME";

export interface IgnoredSetting {
  key: string;
  raw: string | null;
  why: string;
}

export interface RateCeiling {
  source: LimitSource;
  /** The key as resolved; `app_credential.max_tps` for a login; null when nothing is set. */
  key: string | null;
  rawValue: string | null;
  /** Null for a login's own limit, which is not a configuration key. */
  tier: SettingTier | null;
  /** The contract, messages a second; null for unlimited. */
  configured: number | null;
  /** This node's share: 1 on a single gateway. */
  share: number;
  /** What this node enforces, configured × share, never below 1/s; null for unlimited. */
  effective: number | null;
  ignored: IgnoredSetting[];
  /** The listener's tps, its submit budget; null without one or before gateway 0.15.2. */
  portLimit?: number | null;
  /** Customers sharing it now (active in the window, without a dedicated login rate). */
  activeAccounts?: number | null;
}

export interface BindLimit {
  key: string | null;
  /** Binds allowed; 0 is unlimited. */
  value: number;
  source: LimitSource;
  tier: SettingTier | null;
}

export interface ThrottleCounts {
  lastMinute: number;
  last5Minutes: number;
  lastHour: number;
  sinceStart: number;
  lastAt: string | null;
  /** lastHour turned away by the account's ceiling. */
  byAccountLimit: number;
  /** lastHour turned away by a login's own TPS. */
  byLoginLimit: number;
}

export interface LoginThroughput {
  systemId: string;
  sessions: number;
  ceiling: RateCeiling;
  /** Which of the login's own TPS and the account's ceiling binds. */
  binding: LimitSource;
  tpsMeasured: number | null;
  throttled: ThrottleCounts;
}

export interface ListenerThroughput {
  /** The full name, `smppserver.<name>`. */
  listener: string;
  port: number | null;
  ceiling: RateCeiling;
  bindLimit: BindLimit;
  binds: number;
  tpsMeasured: number | null;
  throttled: ThrottleCounts;
  logins: LoginThroughput[];
  /** gateway 0.15.2: the listener's submit budget and the customers sharing it; null before. */
  portLimit: number | null;
  activeAccounts: number | null;
}

export interface ThrottleMinute {
  minute: string;
  byAccountLimit: number;
  byLoginLimit: number;
}

export interface AccountThroughput {
  account: string;
  node: string;
  nodes: number;
  windowSeconds: number | null;
  listeners: ListenerThroughput[];
  http: { ceiling: RateCeiling; rateLimitedLastHour: number | null };
  /** Null without a database on the gateway's side. */
  history: ThrottleMinute[] | null;
}

/** What the throughput route answers: the account's figures, or a gateway too old to have them. */
export type ThroughputAnswer = { data: AccountThroughput | null; unsupported?: true };

const SOURCES: readonly LimitSource[] = ["LOGIN_MAX_TPS", "ACCOUNT_OVERRIDE", "LISTENER_DEFAULT", "PORT_SHARE", "UNLIMITED"];
const TIERS: readonly SettingTier[] = ["LISTENER", "GATEWAY", "ENVIRONMENT", "CODED", "RUNTIME"];

/** A Long arrives as a string from some GraphQL serialisers; a missing count is zero, a missing rate is null. */
function num(raw: unknown): number | null {
  if (raw == null || raw === "") {
    return null;
  }
  const n = typeof raw === "number" ? raw : Number(raw);
  return Number.isFinite(n) ? n : null;
}

function str(raw: unknown): string | null {
  return typeof raw === "string" && raw !== "" ? raw : null;
}

function source(raw: unknown): LimitSource {
  return SOURCES.includes(raw as LimitSource) ? (raw as LimitSource) : "UNLIMITED";
}

function tier(raw: unknown): SettingTier | null {
  return TIERS.includes(raw as SettingTier) ? (raw as SettingTier) : null;
}

type Obj = Record<string, unknown>;
const obj = (raw: unknown): Obj => (raw && typeof raw === "object" ? (raw as Obj) : {});
const list = (raw: unknown): unknown[] => (Array.isArray(raw) ? raw : []);

function ceilingOf(raw: unknown): RateCeiling {
  const c = obj(raw);
  return {
    source: source(c.source),
    key: str(c.key),
    rawValue: typeof c.rawValue === "string" ? c.rawValue : null,
    tier: tier(c.tier),
    configured: num(c.configured),
    share: num(c.share) ?? 1,
    effective: num(c.effective),
    portLimit: num(c.portLimit),
    activeAccounts: num(c.activeAccounts),
    ignored: list(c.ignored).map((i) => {
      const o = obj(i);
      return { key: String(o.key ?? ""), raw: typeof o.raw === "string" ? o.raw : null, why: String(o.why ?? "") };
    }),
  };
}

function countsOf(raw: unknown): ThrottleCounts {
  const t = obj(raw);
  return {
    lastMinute: num(t.lastMinute) ?? 0,
    last5Minutes: num(t.last5Minutes) ?? 0,
    lastHour: num(t.lastHour) ?? 0,
    sinceStart: num(t.sinceStart) ?? 0,
    lastAt: str(t.lastAt),
    byAccountLimit: num(t.byAccountLimit) ?? 0,
    byLoginLimit: num(t.byLoginLimit) ?? 0,
  };
}

/** The gateway's answer, made safe to render: every count a number, every enum one this panel knows. */
export function normaliseThroughput(raw: unknown): AccountThroughput | null {
  if (!raw || typeof raw !== "object") {
    return null;
  }
  const a = raw as Obj;
  const http = obj(a.http);
  return {
    account: String(a.account ?? ""),
    node: String(a.node ?? ""),
    nodes: num(a.nodes) ?? 1,
    windowSeconds: num(a.windowSeconds),
    listeners: list(a.listeners).map((l): ListenerThroughput => {
      const o = obj(l);
      const b = obj(o.bindLimit);
      return {
        listener: String(o.listener ?? ""),
        port: num(o.port),
        ceiling: ceilingOf(o.ceiling),
        bindLimit: { key: str(b.key), value: num(b.value) ?? 0, source: source(b.source), tier: tier(b.tier) },
        binds: num(o.binds) ?? 0,
        tpsMeasured: num(o.tpsMeasured),
        throttled: countsOf(o.throttled),
        portLimit: num(o.portLimit),
        activeAccounts: num(o.activeAccounts),
        logins: list(o.logins).map((g): LoginThroughput => {
          const x = obj(g);
          return {
            systemId: String(x.systemId ?? ""),
            sessions: num(x.sessions) ?? 0,
            ceiling: ceilingOf(x.ceiling),
            binding: source(x.binding),
            tpsMeasured: num(x.tpsMeasured),
            throttled: countsOf(x.throttled),
          };
        }),
      };
    }),
    http: { ceiling: ceilingOf(http.ceiling), rateLimitedLastHour: num(http.rateLimitedLastHour) },
    history: Array.isArray(a.history)
      ? a.history.map((m) => {
        const o = obj(m);
        return { minute: String(o.minute ?? ""), byAccountLimit: num(o.byAccountLimit) ?? 0, byLoginLimit: num(o.byLoginLimit) ?? 0 };
      })
      : null,
  };
}

/** How a source chip is drawn: the words, the key in mono beside them, and a tier note when it says more. */
export interface SourceChip {
  label: string;
  key: string | null;
  note: string | null;
  variant: "default" | "info" | "outline";
}

/**
 * The chip beside a ceiling: which setting produced it, in the words the mockup uses.
 *
 * <p>"account override `conf.maxRate.YK201`", "listener default `conf.maxRate.default`", "all
 * listeners `outSms.default.conf.maxRate.default`" (one gateway-wide row caps every listener without
 * a row of its own), "login `max_tps`", "unlimited". For HTTP the default is "all accounts", since
 * `smsg.restapi.maxRate.default` is one key for the whole REST ingress.
 */
export function sourceChip(
  c: Pick<RateCeiling, "source" | "key" | "tier" | "portLimit" | "activeAccounts">,
  surface: "smpp" | "http" = "smpp"
): SourceChip {
  const note = c.tier === "GATEWAY" ? "gateway-wide"
    : c.tier === "ENVIRONMENT" ? "environment"
      : c.tier === "CODED" ? "coded default"
        : c.tier === "RUNTIME" ? "set at start"
          : null;
  switch (c.source) {
    case "LOGIN_MAX_TPS":
      return { label: "login (dedicated)", key: "max_tps", note: null, variant: "info" };
    case "PORT_SHARE":
      //gateway 0.15.2: the listener's tps split between the customers sending on it
      return {
        label: "port share",
        key: "tps",
        note: c.portLimit != null && c.activeAccounts != null
          ? `${portSplitText({ portLimit: c.portLimit, activeAccounts: c.activeAccounts })} active`
          : null,
        variant: "outline",
      };
    case "UNLIMITED":
      return { label: "unlimited", key: null, note: null, variant: "outline" };
    case "ACCOUNT_OVERRIDE":
      //an account's own key written gateway-wide still names the account: it is an override, on
      //every listener at once
      return {
        label: "account override",
        key: c.key,
        note: c.tier === "GATEWAY" && surface === "smpp" ? "all listeners" : note === "gateway-wide" ? null : note,
        variant: "default",
      };
    case "LISTENER_DEFAULT":
      if (surface === "http") {
        return { label: "all accounts", key: c.key, note, variant: "outline" };
      }
      return c.tier === "GATEWAY"
        ? { label: "all listeners", key: c.key, note: "gateway-wide", variant: "outline" }
        : { label: "listener default", key: c.key, note: c.tier === "LISTENER" ? null : note, variant: "outline" };
  }
}

/**
 * "1,000 ÷ 5": a listener's tps split between the customers sending on it (gateway 0.15.2). Grouped
 * with a pinned locale so the chip, the tile and the overview card read it alike.
 */
export function portSplitText(c: { portLimit: number; activeAccounts: number }): string {
  return `${Math.round(c.portLimit).toLocaleString("en")} ÷ ${c.activeAccounts}`;
}

/** The chip as one line, for a title attribute and for the tests. */
export function sourceChipText(c: Pick<RateCeiling, "source" | "key" | "tier" | "portLimit" | "activeAccounts">, surface: "smpp" | "http" = "smpp"): string {
  const chip = sourceChip(c, surface);
  return [chip.label, chip.key, chip.note && `(${chip.note})`].filter(Boolean).join(" ");
}

/** A share as a short decimal: 1, 0.5, 0.33. */
export function formatShare(share: number): string {
  return String(Math.round(share * 100) / 100);
}

/**
 * `configured × share = effective`: why a contract of 600 reads 300 on this node. Null for an
 * unlimited ceiling, which has nothing to multiply.
 */
export function shareText(c: Pick<RateCeiling, "configured" | "share" | "effective">): string | null {
  if (c.configured == null) {
    return null;
  }
  const effective = c.effective ?? c.configured * c.share;
  return `${formatTps(c.configured)} × ${formatShare(c.share)} = ${formatTps(Math.round(effective * 100) / 100)}`;
}

/** `≤300/s`, or null for unlimited. */
export function ceilingText(c: Pick<RateCeiling, "effective" | "configured">): string | null {
  const v = c.effective ?? c.configured;
  return v == null ? null : `≤${formatTps(v)}/s`;
}

/** The listener's instance name, which the worker routes and pages use: `smppserver.dltsmpp` → `dltsmpp`. */
export function listenerName(full: string): string {
  return full.startsWith("smppserver.") ? full.slice("smppserver.".length) : full;
}

/** "account override", "listener default": the short form of a listener's chip, for a tile's hint. */
export function sourceWords(l: Pick<ListenerThroughput, "ceiling" | "portLimit" | "activeAccounts">): string {
  switch (l.ceiling.source) {
    case "ACCOUNT_OVERRIDE":
      return "account override";
    case "LISTENER_DEFAULT":
      return l.ceiling.tier === "GATEWAY" ? "all listeners" : "listener default";
    case "LOGIN_MAX_TPS":
      return "login (dedicated)";
    case "PORT_SHARE":
      return l.portLimit != null && l.activeAccounts != null
        ? `port share ${portSplitText({ portLimit: l.portLimit, activeAccounts: l.activeAccounts })}`
        : "port share";
    case "UNLIMITED":
      return "unlimited";
  }
}

/** One listener on the overview's ceiling card. */
export interface CeilingRow {
  /** The short name, `smpp` for `smppserver.smpp`. */
  name: string;
  port: number | null;
  ceiling: RateCeiling;
  /** What this node enforces; null for unlimited. */
  effective: number | null;
  measured: number | null;
  /** measured ÷ effective, 0 to 1; null when unlimited. */
  usage: number | null;
  /** "240 ÷ 3 active · now 78.4/s": why the number, and the traffic against it. */
  note: string;
}

/** A login whose ceiling is its own TPS: dedicated, outside the account's split. */
export interface DedicatedLogin {
  systemId: string;
  /** Its TPS on this node; null when the gateway gave no figure. */
  ceiling: number | null;
  measured: number | null;
}

export interface CeilingSummary {
  /**
   * The one listener the card shows: where the account is active now (the busiest, most binds on a
   * tie), or -- when it is bound nowhere -- the one it would bind on. Null without an SMPP listener.
   */
  active: CeilingRow | null;
  /** Bound on no listener now: `active` is where it would bind, not where it sends. */
  idle: boolean;
  /** The listeners besides `active`, which the Limits page lists. */
  others: number;
  logins: DedicatedLogin[];
  /** Submits answered 0x58 in the last minute, over every listener. */
  throttledLastMinute: number;
}

/** Within a percent of the ceiling reads as at it: the measured rate is a mean over a window. */
const AT_CEILING = 0.99;

/** Binds on the listener: its own count, or its logins' sessions when the count is missing. */
function bindsOf(l: ListenerThroughput): number {
  return l.binds > 0 ? l.binds : l.logins.reduce((sum, g) => sum + g.sessions, 0);
}

function ceilingNote(l: ListenerThroughput, effective: number | null, idle: boolean): string {
  const c = l.ceiling;
  const parts: string[] = [];
  if (c.source === "PORT_SHARE") {
    const limit = l.portLimit ?? c.portLimit ?? null;
    const active = l.activeAccounts ?? c.activeAccounts ?? null;
    if (limit != null && active != null) {
      parts.push(`${portSplitText({ portLimit: limit, activeAccounts: active })} active`);
    }
  } else if (c.source === "ACCOUNT_OVERRIDE") {
    parts.push("outside the split");
  } else if (c.source === "UNLIMITED") {
    parts.push("nothing set");
  }
  //a cluster: the configured value times this node's share
  if (c.source !== "UNLIMITED" && c.share !== 1) {
    const share = shareText(c);
    if (share) {
      parts.push(share);
    }
  }
  if (idle) {
    //no traffic to show: what it would get on binding
    if (c.source === "PORT_SHARE" || c.source === "LISTENER_DEFAULT") {
      parts.push("shared with the other active accounts");
    }
    return parts.join(" · ");
  }
  const m = l.tpsMeasured;
  if (m == null || m <= 0) {
    parts.push("no traffic");
  } else {
    const at = effective != null && m >= effective * AT_CEILING;
    parts.push(`now ${formatTps(m)}/s${at ? ", at the ceiling" : ""}`);
  }
  const binds = bindsOf(l);
  parts.push(`${binds} bind${binds === 1 ? "" : "s"}`);
  return parts.join(" · ");
}

function ceilingRow(l: ListenerThroughput, idle: boolean): CeilingRow {
  const effective = l.ceiling.effective ?? l.ceiling.configured;
  return {
    name: listenerName(l.listener),
    port: l.port,
    ceiling: l.ceiling,
    effective,
    measured: l.tpsMeasured,
    usage: idle || effective == null || effective <= 0 ? null : Math.min(1, Math.max(0, (l.tpsMeasured ?? 0) / effective)),
    note: ceilingNote(l, effective, idle),
  };
}

/** The latest moment the answer shows the account using a listener: its last refused submit. */
function lastSeen(l: ListenerThroughput): number {
  const at = [l.throttled.lastAt, ...l.logins.map((g) => g.throttled.lastAt)]
    .map((t) => (t ? Date.parse(t) : NaN))
    .filter((t) => Number.isFinite(t));
  return at.length ? Math.max(...at) : -Infinity;
}

/**
 * What the overview's "SMPP ceiling" card shows: the one listener where this account is active now
 * (binds or sessions; the busiest by measured TPS, most binds on a tie), or -- bound nowhere -- the
 * one it would bind on (the last it used if the answer shows it, else the first); how many other
 * listeners there are; the logins with their own TPS, which come first and sit outside the split; and
 * how many submits were refused 0x58 in the last minute.
 */
export function ceilingSummary(data: AccountThroughput): CeilingSummary {
  const used = data.listeners.filter((l) =>
    l.binds > 0 || (l.tpsMeasured ?? 0) > 0 || l.logins.some((g) => g.sessions > 0));
  const idle = used.length === 0;
  let pick: ListenerThroughput | undefined;
  if (!idle) {
    pick = [...used].sort((a, b) =>
      (b.tpsMeasured ?? 0) - (a.tpsMeasured ?? 0) || bindsOf(b) - bindsOf(a) || a.listener.localeCompare(b.listener))[0];
  } else if (data.listeners.length) {
    //the one it used last, when a refusal dates it; else the first listener
    const recent = data.listeners.reduce((best, l) => (lastSeen(l) > lastSeen(best) ? l : best), data.listeners[0]);
    pick = lastSeen(recent) > -Infinity ? recent : data.listeners[0];
  }

  //one row per login, however many listeners it is bound on: its TPS is its own, and the traffic
  //is what it sends in all
  const logins = new Map<string, DedicatedLogin>();
  for (const l of data.listeners) {
    for (const g of l.logins) {
      if (g.ceiling.source !== "LOGIN_MAX_TPS") {
        continue;
      }
      const seen = logins.get(g.systemId);
      const ceiling = g.ceiling.effective ?? g.ceiling.configured;
      if (!seen) {
        logins.set(g.systemId, { systemId: g.systemId, ceiling, measured: g.tpsMeasured });
      } else {
        seen.ceiling = seen.ceiling ?? ceiling;
        seen.measured = seen.measured == null && g.tpsMeasured == null ? null : (seen.measured ?? 0) + (g.tpsMeasured ?? 0);
      }
    }
  }

  return {
    active: pick ? ceilingRow(pick, idle) : null,
    idle,
    others: pick ? data.listeners.length - 1 : 0,
    logins: [...logins.values()].sort((a, b) => (b.measured ?? 0) - (a.measured ?? 0) || a.systemId.localeCompare(b.systemId)),
    throttledLastMinute: data.listeners.reduce((sum, l) => sum + l.throttled.lastMinute, 0),
  };
}

/**
 * Throttled submits per minute over the last `minutes`, oldest first, with the minutes the table has
 * no row for filled with zero -- it keeps non-zero minutes only, and a sparkline over the rows alone
 * would draw a quiet hour as a flat line at the last busy minute.
 */
export function historySeries(history: readonly ThrottleMinute[] | null, minutes: number, now: number): number[] | null {
  if (!history) {
    return null;
  }
  const end = Math.floor(now / 60_000);
  const byMinute = new Map<number, number>();
  for (const m of history) {
    const at = Date.parse(m.minute);
    if (Number.isFinite(at)) {
      const k = Math.floor(at / 60_000);
      byMinute.set(k, (byMinute.get(k) ?? 0) + m.byAccountLimit + m.byLoginLimit);
    }
  }
  const out: number[] = [];
  for (let k = end - minutes + 1; k <= end; k++) {
    out.push(byMinute.get(k) ?? 0);
  }
  return out;
}

/**
 * Whether a failure is the gateway saying it does not know a field -- a gateway older than the
 * document. graphql-java words it "Validation error (FieldUndefined@[...]) : Field 'x' in type 'Y' is
 * undefined"; the code varies with the build, so the sentence is what is matched.
 */
export function isUnknownFieldError(failure: Pick<GqlFailure, "code" | "error">): boolean {
  return /FieldUndefined|ValidationError|Validation error|is undefined|Unknown (field|type|argument)/i
    .test(`${failure.code} ${failure.error}`);
}

export type GqlExecutor = <T>(call: { query: string; variables?: Record<string, unknown>; timeoutMs?: number }) => Promise<GqlOutcome<T>>;

/**
 * The route's work, with the gateway call passed in: the capability map first, so a gateway before
 * 0.15.1 is told apart and never asked the field -- and a refusal by name treated the same way, for
 * a build whose map and schema disagree.
 */
export async function readAccountThroughput(
  exec: GqlExecutor,
  account: string,
  documents: { health: string; throughput: string },
  hasField: (health: unknown) => boolean
): Promise<{ ok: true; body: ThroughputAnswer } | { ok: false; failure: GqlFailure }> {
  const health = await exec<unknown>({ query: documents.health, timeoutMs: 5_000 });
  if (!health.ok) {
    return { ok: false, failure: health };
  }
  if (!hasField(health.data)) {
    return { ok: true, body: { data: null, unsupported: true } };
  }
  const read = await exec<unknown>({ query: documents.throughput, variables: { account, minutes: 60 }, timeoutMs: 10_000 });
  if (!read.ok) {
    return isUnknownFieldError(read)
      ? { ok: true, body: { data: null, unsupported: true } }
      : { ok: false, failure: read };
  }
  return { ok: true, body: { data: normaliseThroughput(read.data) } };
}
