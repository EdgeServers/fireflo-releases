/**
 * The one line that stays on the page for a setting whose explanation is long.
 *
 * <p>A setting's hint is written to be complete: what it does, when it applies, what happens past
 * it. Under a label in a narrow column that ran to ten or fifteen lines and pushed the value off the
 * screen. So the page shows one plain sentence saying what the setting is, and the hint itself goes
 * behind the info button beside the label, unchanged.
 *
 * <p>Keyed by the setting's key. A hint with no line here shows its first sentence when that fits
 * (see {@link pageLine}); `setting-short.test.ts` fails when a long hint has neither.
 *
 * <p>No imports, so the catalogues it describes can be tested against it without a cycle.
 */

/** A line longer than this wraps past two lines in a settings row's left column. */
export const PAGE_LINE_MAX = 90;

/** Listener-side meaning of a key the vendor form also uses. */
export const SERVER_SIDE = "@server";

export const SETTING_SHORT: Readonly<Record<string, string>> = {
  // --- Gateway settings page ---------------------------------------------------------------------
  "smsg.preprocessor.editable": "Lets an admin change, test and save preprocessor programs from this panel.",
  "smsg.restapi.whitelist.tlvs.mode": "What a matched sender ID or template does with its TLVs on HTTP traffic.",
  "smsg.restapi.maxRate.default": "Messages a second one account may send over HTTP and gRPC, with no limit of its own.",
  "smsg.restapi.client.ref.window.hours": "How long a repeated send with the same client_ref is answered, not sent again.",
  "smsg.restapi.batch.queue.highwater": "The backlog at which a batch pauses and waits for it to drain. 0 switches it off.",
  "smsg.restapi.batch.durable": "Store each batch so it survives a restart and can run on any node.",
  "smsg.grpc.session.max.seconds": "The longest a gRPC session lasts before the customer logs in again.",
  "smsg.grpc.session.max.per.login": "How many gRPC sessions one HTTP login may hold at once.",
  "smsg.grpc.proxy.forwarding": "Read the client's address from the proxy's header instead of the connection.",
  "smsg.grpc.proxy.hops": "How many proxies you run in front of the gRPC port.",
  "smsg.grpc.stream.max.inflight": "How many messages one stream may have sent and not yet had answered.",
  "smsg.grpc.receipts.enabled": "Keep delivery receipts for HTTP logins that gave no receipt URL.",
  "smsg.grpc.receipts.lease.seconds": "How long a delivered receipt waits for its acknowledgement before it is offered again.",
  "smsg.grpc.receipts.window": "The most receipts one stream holds delivered but not yet acknowledged.",
  "smsg.grpc.receipts.poll.ms": "How often a node checks for receipts queued on another node.",
  "smsg.grpc.receipts.max.per.login": "The most receipts kept waiting for one HTTP login.",
  "smsg.webhook.retry.pending.max": "Callbacks kept waiting for their turn or retry when there is no broker.",
  "smsg.smpp.whitelist.first.bind": "A login with no allowed addresses is locked to the first address it binds from.",
  "smsg.callback.bulk.accounts": "These accounts get receipts and batch results as one array per request.",
  "smsg.dlr.deadline.receipt.enabled": "A message with no outcome by the receipt deadline gets a final UNKNOWN receipt.",
  "smsg.cdr.event.retention.days": "Receipt and callback events older than this are dropped, a month at a time.",
  "smsg.queue.archive.retention.days": "How long archived queue entries are kept. 0 keeps every month.",
  "smsg.cdr.put.timeout.ms": "How long a message waits for room in the queue before its record is spilled.",
  "smsg.cdr.archive.export": "Also write each fully archived billing day as a CSV file with a checksum.",
  "smsg.vendor.backlog.enabled": "Fail traffic over from a backed-up vendor, and expire what waits too long.",
  "smsg.vendor.backlog.max": "Messages waiting for one vendor above which new submits for it are refused.",
  "smsg.vendor.backlog.max.age.seconds": "The age of a vendor's oldest waiting message above which new submits are refused.",
  "smsg.vendor.backlog.expire.seconds": "A message waiting for its vendor longer than this is refunded, not sent.",
  "smsg.vendor.unbound.refuse.after.seconds": "How long a vendor with no bind is still queued for before submits are refused.",
  "smsg.vendor.stall.seconds": "A bound vendor that has sent nothing for this long has its binds recycled. 0 is off.",
  "smsg.shutdown.drain.seconds": "How long a stopping gateway may take to hand on what it already took.",
  "smsg.usage.hourly.enabled": "Count each hour's traffic and money as it goes, so dashboards read a summary.",
  "smsg.usage.hourly.lag.seconds": "A count stops this far short of now, so records still being written are not missed.",
  "smsg.usage.hourly.restate.minutes": "Recent hours are recounted this often until late receipts have settled.",
  "smsg.usage.hourly.retention.days": "Hourly rows older than this are dropped; the daily summary is kept.",
  "smsg.usage.daily.schedule": "The local time at which the gateway writes yesterday's daily summary. Empty is off.",

  // --- listener and vendor settings --------------------------------------------------------------
  tps: "How fast the gateway sends to this vendor, in messages a second. 0 means no limit.",
  [`tps${SERVER_SIDE}`]: "This port's total submit budget, in messages a second, shared by its customers.",
  maxRetries: "Total sends this carrier may see for one message. 0 keeps trying forever.",
  "window.offer.timeout.ms": "How long a send waits for a free window slot before going back on the queue.",
  "dest.addr.convert": "Rewrites each number into the form the recipient type of number asks for.",
  "srv.bind.backoff.enabled": "After five refused binds in a minute, an address waits thirty seconds.",
  "conf.maxRate.default": "The most one customer may submit a second on this port, with no rate of its own.",
  "conf.maxConnectionsPerUser.default": "How many binds one account may hold on this port at once.",
  "backlog.max": "Messages waiting for this vendor above which new submits for it are refused.",
  "backlog.max.age.seconds": "Age of this vendor's oldest waiting message above which new submits are refused.",
  "conf.status.vendorBacklog": "The SMPP status sent when every vendor for the destination is backed up.",
  "conf.status.vendorUnavailable": "The SMPP status sent when the destination's vendor has no bind.",
  "conf.status.noUnits": "The SMPP status sent when a units login has no units left. Default 0x403.",
  "dlr.errcodes.passthrough": "Send a carrier error code you have not mapped to the customer as it came.",
};

/** A rate or limit field's four answers; shown as labelled entries in the popover. */
export interface SettingFacts {
  scope: string;
  limits: string;
  precedence: string;
  over: string;
}

export const SETTING_FACTS: Readonly<Record<string, SettingFacts>> = {
  "smsg.restapi.maxRate.default": {
    scope: "Platform-wide, per account: one ceiling shared by REST and gRPC. Separate from the SMPP ports and their ceilings.",
    limits: "Messages a second one account may send over the HTTP API and gRPC together.",
    precedence: "An account's own smsg.restapi.maxRate.<account> replaces it. Unset means unlimited.",
    over: "The send is answered HTTP 429 (gRPC RESOURCE_EXHAUSTED) and is not charged.",
  },
  "smsg.vendor.backlog.max": {
    scope: "Every vendor, unless the vendor has a Backlog limit of its own.",
    limits: "Messages waiting for one vendor. It is the only limit a vendor sets on what customers may submit: its Throughput limit never does.",
    precedence: "A vendor's own Backlog limit overrides it. Past three quarters, a group prefers another member.",
    over: "New submits for that vendor are refused before any charge (0x14, vendorBacklog) when no other vendor on the route can take them.",
  },
  "smsg.vendor.backlog.max.age.seconds": {
    scope: "Every vendor, unless the vendor has a Backlog age limit of its own.",
    limits: "The age of a vendor's oldest waiting message.",
    precedence: "A vendor's own Backlog age limit overrides it.",
    over: "New submits for that vendor are refused before any charge, as for the backlog limit (0x14).",
  },
  tps: {
    scope: "This vendor, across all its binds and sending threads.",
    limits: "How fast the gateway sends to the vendor, in messages a second. It never limits what customers may submit.",
    precedence: "Messages beyond it wait in this vendor's queue. Only the backlog limit refuses new submits.",
    over: "Nothing is refused: the messages wait. 0 means no limit.",
  },
  [`tps${SERVER_SIDE}`]: {
    scope: "This port. A budget shared equally by the customers sending on it that have no rate of their own.",
    limits: "Submits a second: 1,000 with 5 active customers gives each 200, and a share grows as others go quiet (active = submitted in the last 10 s). It does not slow receipts.",
    precedence: "A customer gets the lower of its share and the Default rate ceiling. A login with its own TPS, and an account with its own ceiling, keep theirs.",
    over: "The submit is answered 0x58 (throttled) and is not charged. 0 means no port budget.",
  },
  "conf.maxRate.default": {
    scope: "This port, per account: each account has its own allowance, shared by all its binds.",
    limits: "Submits a second by one customer whose login and account have no rate of their own.",
    precedence: "Login TPS first, then the account's own ceiling, then this. The customer gets the lower of this and its share of the port's Throughput limit.",
    over: "The submit is answered 0x58 (throttled) and is not charged. 0 means no per-customer ceiling.",
  },
  "conf.maxConnectionsPerUser.default": {
    scope: "This port, per account.",
    limits: "Binds one account may hold on the port at once.",
    precedence: "An account's own bind limit replaces it.",
    over: "A bind past it is refused.",
  },
  "backlog.max": {
    scope: "This vendor only.",
    limits: "Messages waiting for this vendor. It is the only limit a vendor sets on what customers may submit.",
    precedence: "Overrides smsg.vendor.backlog.max (50,000), which applies when this is empty.",
    over: "New submits for it are refused before any charge (0x14, vendorBacklog) when no other vendor on the route can take them.",
  },
  "backlog.max.age.seconds": {
    scope: "This vendor only.",
    limits: "The age of this vendor's oldest waiting message.",
    precedence: "Overrides smsg.vendor.backlog.max.age.seconds (600), which applies when this is empty.",
    over: "New submits for it are refused before any charge, as for the backlog limit (0x14).",
  },
};

/** One account's own rate on a listener: `conf.maxRate.<account>`. */
const ACCOUNT_RATE = /^conf\.maxRate\.([^\s.]+)$/;

/** The line on the page for `key`, when one was written for it. `side` picks a listener's meaning. */
export function settingShort(key: string, side?: "server" | "client"): string | undefined {
  if (side === "server" && SETTING_SHORT[key + SERVER_SIDE]) {
    return SETTING_SHORT[key + SERVER_SIDE];
  }
  const account = ACCOUNT_RATE.exec(key);
  if (account && account[1] !== "default") {
    return "This account's own submit rate on this port, in messages a second.";
  }
  return SETTING_SHORT[key];
}

/** The four answers for `key`, when it is a rate or limit field. */
export function settingFacts(key: string, side?: "server" | "client"): SettingFacts | undefined {
  if (side === "server" && SETTING_FACTS[key + SERVER_SIDE]) {
    return SETTING_FACTS[key + SERVER_SIDE];
  }
  const account = ACCOUNT_RATE.exec(key);
  if (account && account[1] !== "default") {
    return {
      scope: "This port, this account: shared by its logins.",
      limits: "The account's exact submit rate on the port, in messages a second.",
      precedence: "It replaces the Default rate ceiling and the port's share for this account. A login with its own TPS keeps that instead.",
      over: "The submit is answered 0x58 (throttled) and is not charged.",
    };
  }
  return SETTING_FACTS[key];
}

/** The first sentence of a hint, when the hint is more than one. */
function firstSentence(hint: string): string | undefined {
  const m = /^(.+?[.!?])\s+(?=[A-Z`"'(])/.exec(hint.trim());
  return m ? m[1] : undefined;
}

/**
 * What a settings row shows under its label, and whether the whole hint goes behind an info button.
 *
 * <p>A hint that fits is the line, with nothing behind a button. A longer one shows its written
 * line, else its first sentence when that fits; `more` is then true and the caller puts the hint
 * (or the field's facts) in the popover.
 */
export function pageLine(hint: string | undefined, short: string | undefined): { line: string; more: boolean } {
  const text = (hint ?? "").trim();
  if (short) {
    return { line: short, more: text !== "" && text !== short };
  }
  if (text.length <= PAGE_LINE_MAX) {
    return { line: text, more: false };
  }
  const first = firstSentence(text);
  return first && first.length <= PAGE_LINE_MAX ? { line: first, more: true } : { line: text, more: false };
}
