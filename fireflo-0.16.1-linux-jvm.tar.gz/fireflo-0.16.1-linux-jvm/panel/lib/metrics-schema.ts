import { query } from "@/lib/metrics-db";
import {
  encodingComplete,
  encodingSupportFrom,
  ENCODING_PROBE_SQL,
  NO_ENCODING,
  type EncodingSupport,
  type ProbeRow,
} from "./cdr-encoding-sql.ts";

/**
 * What the CDR schema in front of us actually has.
 *
 * <p>The panel and the gateway are two services that are deployed separately, and the schema belongs
 * to the gateway — it owns the migrations. Every other query in the panel simply assumes the newest
 * one has run, which has been fine because a missing column only ever broke the page that used it.
 *
 * <p><strong>`cdr_submit.body` is the first one where that is not fine.</strong> It arrives in the
 * gateway's V1.31.0, and the portal's landing page reads it. Assume it and a panel talking to a
 * gateway that is one release behind answers 502 on the page a customer arrives at — for a column
 * that is optional, off by default, and null on every row even once it exists. That is a bad trade,
 * so this asks.
 *
 * <p>V1.33.0 brought two more of the same shape — `cdr_interim` and `cdr_submit.registered_delivery`
 * — and both are read by the message detail page, which is the page somebody opens *because*
 * something went wrong. Answering 502 there is the worst possible moment to be a release ahead.
 *
 * <p>Server-only: importing this pulls `pg`.
 */

/**
 * One probe's memory.
 *
 * <p>Once true it stays true — neither a column nor a table is dropped by an upgrade. A negative
 * answer expires, so a panel that was started before the migration ran picks the object up on its
 * own; caching "no" forever would mean an upgrade needed a panel restart to become visible.
 */
interface Probe {
  present: boolean | null;
  checkedAt: number;
  sql: string;
}

const NEGATIVE_TTL_MS = 60_000;

/**
 * `information_schema` rather than a probe query that catches an error: a failed statement inside a
 * transaction poisons it, and these run beside others on a pooled connection.
 */
const PROBES = {
  body: {
    present: null,
    checkedAt: 0,
    sql: `SELECT EXISTS (
            SELECT 1 FROM information_schema.columns
             WHERE table_name = 'cdr_submit' AND column_name = 'body'
          ) AS exists`,
  },
  interim: {
    present: null,
    checkedAt: 0,
    sql: `SELECT EXISTS (
            SELECT 1 FROM information_schema.tables
             WHERE table_name = 'cdr_interim'
          ) AS exists`,
  },
  registeredDelivery: {
    present: null,
    checkedAt: 0,
    sql: `SELECT EXISTS (
            SELECT 1 FROM information_schema.columns
             WHERE table_name = 'cdr_submit' AND column_name = 'registered_delivery'
          ) AS exists`,
  },
  reassembledParts: {
    present: null,
    checkedAt: 0,
    sql: `SELECT EXISTS (
            SELECT 1 FROM information_schema.columns
             WHERE table_name = 'cdr_submit' AND column_name = 'reassembled_parts'
          ) AS exists`,
  },
  submitStatus: {
    present: null,
    checkedAt: 0,
    sql: `SELECT EXISTS (
            SELECT 1 FROM information_schema.columns
             WHERE table_name = 'cdr_submit' AND column_name = 'submit_status'
          ) AS exists`,
  },
  vendorAttempt: {
    present: null,
    checkedAt: 0,
    sql: `SELECT EXISTS (
            SELECT 1 FROM information_schema.columns
             WHERE table_name = 'cdr_submit' AND column_name = 'vendor_attempt'
          ) AS exists`,
  },
  vendorErrCode: {
    present: null,
    checkedAt: 0,
    sql: `SELECT EXISTS (
            SELECT 1 FROM information_schema.columns
             WHERE table_name = 'cdr_final' AND column_name = 'vendor_err_code'
          ) AS exists`,
  },
    routeRule: {
      present: null,
      checkedAt: 0,
      sql: `SELECT EXISTS (
              SELECT 1 FROM information_schema.columns
               WHERE table_name = 'cdr_submit' AND column_name = 'route_rule'
            ) AS exists`,
    },
  eventResponse: {
    present: null,
    checkedAt: 0,
    sql: `SELECT EXISTS (
            SELECT 1 FROM information_schema.columns
             WHERE table_name = 'cdr_event' AND column_name = 'response_excerpt'
          ) AS exists`,
  },
  //a TABLE rather than a column, so this probes information_schema.tables. A gateway before
  //V1.46.0 has no cdr_event at all, and querying it would be an error rather than a null column
  eventTable: {
    present: null,
    checkedAt: 0,
    sql: `SELECT EXISTS (
            SELECT 1 FROM information_schema.tables
             WHERE table_name = 'cdr_event'
          ) AS exists`,
  },
  usageMtParts: {
    present: null,
    checkedAt: 0,
    sql: `SELECT EXISTS (
            SELECT 1 FROM information_schema.columns
             WHERE table_name = 'usage_daily' AND column_name = 'mt_parts'
          ) AS exists`,
  },
  //a TABLE, like cdr_event: the gateway's V1.91.0 creates usage_hourly and usage_rollup_cursor in
  //one migration, so one probe answers for both
  usageHourly: {
    present: null,
    checkedAt: 0,
    sql: `SELECT EXISTS (
            SELECT 1 FROM information_schema.tables
             WHERE table_name = 'usage_hourly'
          ) AS exists`,
  },
  //the gateway's V1.97.0: attempts by the vendor each went to, which lets the vendor figures come
  //from the summary rather than from every call record in the range
  usageHourlyAttempts: {
    present: null,
    checkedAt: 0,
    sql: `SELECT EXISTS (
            SELECT 1 FROM information_schema.columns
             WHERE table_name = 'usage_hourly' AND column_name = 'attempts'
          ) AS exists`,
  },
  //the gateway's V1.113.0 (0.15): the login each hour's row was counted for, so the 24 hours keeps
  //its split by login when it reads the summary
  usageHourlyLogin: {
    present: null,
    checkedAt: 0,
    sql: `SELECT EXISTS (
            SELECT 1 FROM information_schema.columns
             WHERE table_name = 'usage_hourly' AND column_name = 'system_id'
          ) AS exists`,
  },
  //the gateway's V1.115.0 (0.15.1): the login each day's line was rolled for -- the statement's
  //split by login and the Usage page's day windows read it
  usageDailyLogin: {
    present: null,
    checkedAt: 0,
    sql: `SELECT EXISTS (
            SELECT 1 FROM information_schema.columns
             WHERE table_name = 'usage_daily' AND column_name = 'system_id'
          ) AS exists`,
  },
  //the gateway's V1.98.0: failed messages per hour by state, receipt and error, which lets the home
  //page's failures tile come from the summary rather than from every call record in the window
  usageFailureHourly: {
    present: null,
    checkedAt: 0,
    sql: `SELECT EXISTS (
            SELECT 1 FROM information_schema.tables
             WHERE table_name = 'usage_failure_hourly'
          ) AS exists`,
  },
  //a TABLE, like usage_hourly: the gateway's V1.93.0 creates queue_archive, queue_archive_batch and
  //queue_archive_summary in one migration, so one probe answers for all three
  queueArchive: {
    present: null,
    checkedAt: 0,
    sql: `SELECT EXISTS (
            SELECT 1 FROM information_schema.tables
             WHERE table_name = 'queue_archive_summary'
          ) AS exists`,
  },
} satisfies Record<string, Probe>;

type ProbeName = keyof typeof PROBES;

/**
 * Fails **closed** — an unreadable catalogue answers "no", which costs a column and keeps the page
 * up. The opposite default trades a working page for a field nobody has switched on.
 */
async function has(name: ProbeName): Promise<boolean> {
  const probe: Probe = PROBES[name];
  if (probe.present === true) {
    return true;
  }
  if (probe.present === false && Date.now() - probe.checkedAt < NEGATIVE_TTL_MS) {
    return false;
  }

  try {
    const rows = await query<{ exists: boolean }>(probe.sql);
    probe.present = rows[0]?.exists === true;
  } catch {
    probe.present = false;
  }
  probe.checkedAt = Date.now();
  return probe.present;
}

/** Whether `cdr_submit.body` exists. The gateway's V1.31.0. */
export function hasBodyColumn(): Promise<boolean> {
  return has("body");
}

/**
 * Whether `cdr_interim` exists. The gateway's V1.33.0.
 *
 * <p>False means progress receipts are not being recorded at all, which is a different statement
 * from "this message had none" — the detail view says which, because "no ENROUTE was ever sent for
 * this message" and "this gateway does not keep them" lead to entirely different next steps.
 */
export function hasInterimTable(): Promise<boolean> {
  return has("interim");
}

/** Whether `cdr_submit.registered_delivery` exists. The gateway's V1.33.0, same migration. */
export function hasRegisteredDelivery(): Promise<boolean> {
  return has("registeredDelivery");
}

/**
 * Whether `cdr_submit.reassembled_parts` exists. The gateway's V1.34.0.
 *
 * <p>False costs only the extra half of the id lookup: the message's own id still resolves, exactly
 * as it did before the column. Naming the column against a gateway that has not migrated is a hard
 * error, and it would take out the id search itself rather than one column of the result.
 */
export function hasReassembledParts(): Promise<boolean> {
  return has("reassembledParts");
}

/**
 * Whether `cdr_submit.submit_status` exists. The gateway's V1.40.0.
 *
 * <p>False costs the SMPP exchange view its one honest signal for why a retryable attempt failed —
 * the row is still there, dated and counted, just without the vendor's own answer on it.
 */
export function hasSubmitStatus(): Promise<boolean> {
  return has("submitStatus");
}

/**
 * Whether `cdr_submit.vendor_attempt` exists. The gateway's V1.40.0, the migration that made every
 * vendor attempt its own row.
 *
 * <p>False drops only the last rank key of `lib/cdr-grain.ts`'s representative-row choice — and a
 * gateway without the column writes no per-attempt rows, so there is nothing for it to break a tie
 * between. Naming it there would be a hard error that took out every message count in the panel.
 */
export function hasVendorAttempt(): Promise<boolean> {
  return has("vendorAttempt");
}

/**
 * Whether `cdr_final.vendor_err_code` exists. The gateway's 0.9.0 baseline.
 *
 * <p>False costs the carrier's own failure code, and the page says "not recorded" rather than
 * showing the translated one twice. That distinction is the column's whole point: its own comment
 * in the gateway schema states that NULL means the carrier reported none **or** the row predates
 * the column, and that it NEVER means "the same as err_code".
 *
 * <p>Note this probes `cdr_final` rather than `cdr_submit`, unlike every probe above it — an error
 * code belongs to a receipt, not to a submission.
 */
export function hasVendorErrCode(): Promise<boolean> {
  return has("vendorErrCode");
}

/**
 * Whether `cdr_submit.route_rule` exists — the gateway's V1.47.0.
 *
 * <p>Absent, the panel asks for nothing and shows nothing. Present but NULL on a row means the row
 * predates the migration, or that attempt reached a vendor without matching a rule. It never means
 * "no rule", so the two are not collapsed on screen.
 */
export function hasRouteRule(): Promise<boolean> {
  return has("routeRule");
}

/**
 * Whether this gateway records customer-side events at all.
 *
 * <p>False on anything before V1.46.0, and false when the catalogue cannot be read — the same
 * fail-closed rule every probe here follows. The page then renders without the card rather than
 * erroring, which is the behaviour that matters: a panel is routinely pointed at a gateway older
 * than itself.
 *
 * <p>Note this says nothing about whether `smsg.cdr.events` is switched on. A deployment with the
 * table and the mode off has the card and no rows, and that is honest — "nothing was recorded" and
 * "this gateway cannot record" are different answers and the page says which.
 */
export function hasEventTable(): Promise<boolean> {
  return has("eventTable");
}

let encodingProbe: { have: EncodingSupport; checkedAt: number } | null = null;

/**
 * Which of the gateway's V1.124.0 encoding columns exist — eight columns over three tables, one
 * round trip. See `cdr-encoding-sql.ts` for why a column on a table but not yet on its `_all`
 * view counts as absent.
 *
 * <p>The same memory as {@link has}: once every column is there the answer is kept for good; an
 * incomplete one expires, so a migration that runs while the panel is up shows within a minute.
 * Fails closed — an unreadable catalogue answers "none", which costs the encoding cells and keeps
 * the detail page up.
 */
export async function encodingSupport(): Promise<EncodingSupport> {
  if (encodingProbe && (encodingComplete(encodingProbe.have)
    || Date.now() - encodingProbe.checkedAt < NEGATIVE_TTL_MS)) {
    return encodingProbe.have;
  }
  let have = NO_ENCODING;
  try {
    have = encodingSupportFrom(await query<ProbeRow & Record<string, unknown>>(ENCODING_PROBE_SQL));
  } catch {
    have = NO_ENCODING;
  }
  encodingProbe = { have, checkedAt: Date.now() };
  return have;
}

/**
 * Whether `usage_daily.mt_parts` exists — the gateway's V1.68.0.
 *
 * <p>False costs the billing page its MT figures for rolled-up days, which then read as not counted;
 * days still in `cdr_submit` are counted either way, since `part_count` has always been there.
 */
export function hasUsageMtParts(): Promise<boolean> {
  return has("usageMtParts");
}

/**
 * Whether `usage_hourly` exists — the gateway's V1.91.0, the in-process hourly usage summary.
 *
 * <p>False costs nothing a page shows: the hourly series and today's tail are then read from the
 * call records, as they always were, and the home page's snapshot re-reads its hot window
 * progressively instead. True lets a 24-hour view be 24 small rows plus the last minute or two of
 * records (`usageHourlySql` in `usage-summary-sql.ts`).
 */
export function hasUsageHourly(): Promise<boolean> {
  return has("usageHourly");
}

/**
 * Whether `usage_hourly.attempts` exists -- the gateway's V1.97.0. Without it the vendor figures are
 * read from the call records, as they always were.
 */
export function hasUsageHourlyAttempts(): Promise<boolean> {
  return has("usageHourlyAttempts");
}

/**
 * Whether `usage_hourly.system_id` exists -- the gateway's V1.113.0 (0.15). With it the 24 hours read
 * from the summary keeps its split by login; without it a summary row has no login, and that view is
 * one row per account and product. `''` in the column is an hour rolled before the column existed.
 */
export function hasUsageHourlyLogin(): Promise<boolean> {
  return has("usageHourlyLogin");
}

/**
 * Whether `usage_daily.system_id` exists -- the gateway's V1.115.0 (0.15.1). With it a statement can
 * be split by login and the Usage page's day windows show each login; without it a rolled day has
 * no login, the statement's Login option is offered disabled with the reason, and those rows read
 * "—". `''` in the column is a day rolled before the column existed.
 */
export function hasUsageDailyLogin(): Promise<boolean> {
  return has("usageDailyLogin");
}

/**
 * Whether the hourly failure summary exists — the gateway's V1.98.0 (release 0.12.29). Without it the
 * failures tile reads the call records, as it always did.
 */
export function hasUsageFailureHourly(): Promise<boolean> {
  return has("usageFailureHourly");
}

/**
 * Whether the queue archive exists — the gateway's V1.93.0 (release 0.12.19), which adds
 * `queue_archive` (partitioned by month), `queue_archive_batch` and `queue_archive_summary`.
 *
 * <p>False is an ordinary state, not an error: a panel is routinely pointed at a gateway older than
 * itself, and the Archives report then says which release brings it rather than answering 500 for a
 * table that has never existed there. Every archive read in `lib/archives.ts` asks this first.
 */
export function hasQueueArchive(): Promise<boolean> {
  return has("queueArchive");
}

/**
 * How far the gateway's hourly summary has been brought up to: `usage_rollup_cursor.hourly_hwm`.
 *
 * <p>The seam between `usage_hourly` and the live records. Everything submitted before this
 * instant is in the summary (the gateway's tick commits the counts and the cursor together), and
 * everything at or after it is not. Null when the table is absent, when the gateway has not yet
 * created its one cursor row (the rollup is switched off, or has never run), or when the read
 * fails — and a null reads as "no summary to lean on": the caller stays on the live path rather
 * than trusting a seam it cannot see.
 */
export async function hourlyWatermark(): Promise<Date | null> {
  if (!(await hasUsageHourly())) {
    return null;
  }
  try {
    const rows = await query<{ hourly_hwm: Date | string | null }>(
      "SELECT hourly_hwm FROM usage_rollup_cursor"
    );
    const raw = rows[0]?.hourly_hwm;
    return raw == null ? null : new Date(raw);
  } catch {
    return null;
  }
}

/**
 * The billing day the gateway's nightly `usage_daily` rollup last ran ON:
 * `usage_rollup_cursor.last_daily_day`, as `YYYY-MM-DD`.
 *
 * <p>The scheduler rolls yesterday (and any missing day) and then stores today, so every day before
 * this one has its lines and this one may not. It is written only after a rollup succeeds. Null when
 * the table is absent (a gateway before V1.91.0, which created it with `usage_hourly`), when the
 * nightly rollup has never run in-process (the CLI does not move it), or when the read fails -- and
 * the statement then falls back to the account's own newest line (`statement-sql.ts`).
 */
export async function lastDailyDay(): Promise<string | null> {
  if (!(await hasUsageHourly())) {
    return null;
  }
  try {
    const rows = await query<{ day: string | null }>(
      "SELECT to_char(last_daily_day, 'YYYY-MM-DD') AS day FROM usage_rollup_cursor"
    );
    return rows[0]?.day ?? null;
  } catch {
    return null;
  }
}

/** For tests, and for nothing else. */
export function resetSchemaCache(): void {
  for (const probe of Object.values(PROBES) as Probe[]) {
    probe.present = null;
    probe.checkedAt = 0;
  }
}

/**
 * Whether `cdr_event.response_excerpt` exists — the gateway's V1.48.0.
 *
 * <p>Probes only the excerpt: the migration adds both response columns in one statement, so a
 * schema holding one and not the other is not a state this gateway can reach, and a second probe
 * would buy a round trip's worth of nothing.
 *
 * <p>False and present-but-null are different answers and the detail view says which. False means
 * this gateway *cannot* capture a response, so asking its operator to switch something on would be
 * wrong advice. Null means it can and did not — `smsg.cdr.events.response` is off, which is the one
 * case where that advice is right.
 */
export function hasEventResponse(): Promise<boolean> {
  return has("eventResponse");
}
