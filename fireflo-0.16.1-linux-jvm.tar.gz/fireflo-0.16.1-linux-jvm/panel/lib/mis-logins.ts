import { BILLING_KEY } from "@/lib/billing-key";
import { configQuery, inTransaction } from "@/lib/config-db";
import { disconnectBindsFor } from "@/lib/gateway-sessions";
import { NO_LIMITS, billingOf, type Credential } from "@/lib/credential-types";
import { createSubAccountLogin } from "@/lib/reseller-accounts";
import type { NewLogin } from "@/lib/reseller-rules";

/**
 * The logins on a reseller's own accounts: listing them, creating one, switching one off.
 *
 * <p>Server-only. Deliberately <strong>not</strong> `lib/credentials.ts`, which is the operator's
 * whole-row editor — a customer path that could reach `saveCredential` could reach `account_id`,
 * `product`, `allowed_products` and `default_tlvs` with it. Same separation, and the same reason, as
 * `lib/mis-credentials.ts` (which does one thing: rotate a secret on the caller's own login).
 *
 * <p>The field narrowing is in `lib/mis-account-rules.ts`. This file is the query and the
 * transaction.
 *
 * <h2>Two columns are written NULL and never read from the request</h2>
 *
 * <p><strong>`product` and `allowed_products`.</strong> The product picks which rate rule matches, so
 * a reseller free to set it is a reseller setting its own child's price — the one thing this whole
 * surface exists to not allow. An empty `allowed_products` already means "may not name one" to the
 * gateway, so the child cannot choose a product per message either. Both are the operator's, on the
 * operator's page.
 *
 * <p><strong>`default_tlvs`</strong> is absent for a different reason: those arrive through the
 * registration-approval path, where an operator sees what is being stamped before it reaches a
 * carrier.
 *
 * <h2>What a new login costs</h2>
 *
 * <p>`DbConfigPoller` reloads credentials on a poll — `smsg.config.db.poll.seconds`, default 30. So
 * a login created here does not work for up to that long, and one switched off keeps working for up
 * to that long. Every caller has to say so; it is the likeliest support call this feature generates,
 * exactly as `lib/mis-credentials.ts` records for rotation.
 */

/** Matches `smsg.config.db.poll.seconds`' default. Said in words, as `mis-credentials.ts` does. */
export const POLL_SECONDS = 30;

/**
 * The lookup key, computed in SQL exactly as `Credential.getLookupKey()` does.
 *
 * <p>The same expression `lib/credentials.ts` holds, and it is duplicated rather than exported
 * because that module pulls the products catalogue and the TLV parser in behind it. If the two ever
 * disagree the collision check below is checking a collision that does not exist — so the copy is
 * annotated in both places.
 */
const LOOKUP_KEY = `CASE WHEN type = 'SMPP' THEN system_id
                         ELSE COALESCE(NULLIF(api_key, ''), system_id) END`;

/**
 * Secret-free by construction.
 *
 * <p>`password` and `api_key` appear only inside `IS NOT NULL` tests. Nothing selects either value,
 * which is a step beyond sending a placeholder: a placeholder still requires the column to have been
 * read. The one exception in this module is the value {@link createLogin} generates and returns
 * once, which never comes back out of the database.
 */
const PROJECTION = `
  id::text, type, system_id, account_id, product, allowed_ips, allowed_products,
  enabled, updated_at,
  (password IS NOT NULL AND password <> '') AS has_password,
  (api_key  IS NOT NULL AND api_key  <> '') AS has_api_key,
  ${LOOKUP_KEY} AS lookup_key,
  (type <> 'SMPP' AND COALESCE(api_key, '') <> '') AS lookup_key_is_secret`;

interface Row {
  id: string;
  type: string;
  system_id: string | null;
  account_id: string | null;
  product: string | null;
  allowed_ips: string[] | null;
  allowed_products: string[] | null;
  enabled: boolean;
  updated_at: Date | null;
  has_password: boolean;
  has_api_key: boolean;
  lookup_key: string | null;
  lookup_key_is_secret: boolean;
}

/**
 * Every login billing to these accounts.
 *
 * <p>Selected by {@link BILLING_KEY} rather than `account_id`, for the reason that module exists: a
 * login with a blank account bills to its system id, so it belongs to that account even though the
 * column is null. A query reading the column raw would show a child no logins while it happily sends.
 *
 * <p>Returned as `Credential[]`, the operator type, because the portal renders the operator's own
 * `AccountsCatalogueClient` and `CredentialsClient` — see `lib/panel-surface.ts`.
 */
export async function listChildLogins(accountIds: readonly string[]): Promise<Credential[]> {
  if (!accountIds.length) {
    return [];
  }
  const rows = await configQuery<Row>(
    `SELECT ${PROJECTION} FROM app_credential WHERE ${BILLING_KEY} = ANY($1) ORDER BY id`,
    [accountIds]
  );
  return rows.map(toCredential);
}

function toCredential(row: Row): Credential {
  const billing = billingOf(row.type, row.account_id, row.system_id, row.has_api_key);
  return {
    id: Number(row.id),
    type: row.type,
    systemId: row.system_id,
    accountId: row.account_id,
    product: row.product,
    allowedIps: row.allowed_ips ?? [],
    allowedProducts: row.allowed_products ?? [],
    //never populated on this surface, and not parsed either: the reseller cannot set default TLVs,
    //and rendering an operator's would show a customer the DLT identifiers of its own child's
    //approvals before an operator had decided them
    defaultTlvs: [],
    //never set from the portal, and not shown to a reseller: the operator's to decide
    limits: NO_LIMITS,
    enabled: row.enabled,
    updatedAt: row.updated_at ? row.updated_at.toISOString() : null,
    password: row.has_password ? "stored" : "unset",
    apiKey: row.has_api_key ? "stored" : "unset",
    //dropped rather than sent: for an HTTP credential with an api key this value IS the secret
    lookupKey: row.lookup_key_is_secret ? null : row.lookup_key,
    lookupKeyIsSecret: row.lookup_key_is_secret,
    billingAccount: billing.account,
    billingAccountFallback: billing.fallback,
  };
}

export type CreateResult =
  | {
      ok: true;
      id: number;
      /** Returned exactly once. Not stored anywhere the panel can read it back. */
      secret: string;
      /** Always a password now: an HTTP login is system id + password, as the REST API signs in. */
      secretKind: "password";
      /** The login name: the SMPP system id, or the HTTP Basic username. */
      username: string;
    }
  | { ok: false; problem: string; status?: number };

/**
 * Creates one login on one child, with a generated password -- through the sub-account pages' own
 * writer (`createSubAccountLogin` in `lib/reseller-accounts.ts`), so this older route and
 * `/api/mis/sub-accounts/{id}/logins` hold one rule set.
 *
 * <p><strong>What changed in 0.15.8:</strong> an HTTP login used to be made with an API key and no
 * password, which is valid configuration that cannot sign in -- the REST API authenticates with HTTP
 * Basic, the key as username and a password. It is now `system_id` + a sealed password, exactly as
 * the gateway's `AccountProvisioner` makes one. A chosen name is checked free across every login and
 * vendor ignoring case; the SMPP limit (15) is in `parseNewLogin`.
 */
export async function createLogin(accountId: string, input: NewLogin): Promise<CreateResult> {
  const created = await createSubAccountLogin(accountId, input);
  if (!created.ok) {
    return { ok: false, problem: created.error, status: created.status };
  }
  return { ok: true, id: created.id, secret: created.password, secretKind: "password", username: created.systemId };
}

export type ToggleResult =
  | { ok: true; systemId: string | null; enabled: boolean; dropped: number; problem?: string }
  | { ok: false; notFound: true };

/**
 * Switches one of a child's logins on or off, and drops its binds when switching off.
 *
 * <p>Ownership is proved twice, as `rotateSecret` does and for the same reason: once by the caller
 * through `assertInScope`, and again inside the transaction with `FOR UPDATE`, because between those
 * two moments an operator may have moved the login to another account. The second check is what
 * makes the write safe rather than merely likely to be safe.
 *
 * <p>Dropping the binds is best effort and happens after the commit. `enabled = false` is a statement
 * about future binds only — a customer already bound keeps submitting until something ends the
 * session. An unreachable gateway is worth reporting and never worth failing the write for, since
 * the stored change is the durable intent and the gateway applies it on its next poll regardless.
 */
export async function setLoginEnabled(
  accountId: string,
  id: number,
  enabled: boolean
): Promise<ToggleResult> {
  const row = await inTransaction(async (client) => {
    const current = await client.query<{ account_id: string | null; system_id: string | null; type: string }>(
      `SELECT ${BILLING_KEY} AS account_id, system_id, type
         FROM app_credential WHERE id = $1 FOR UPDATE`,
      [id]
    );
    if (!current.rows.length || current.rows[0].account_id !== accountId) {
      return null;
    }
    await client.query(
      "UPDATE app_credential SET enabled = $2, updated_at = now() WHERE id = $1",
      [id, enabled]
    );
    return current.rows[0];
  });

  if (!row) {
    return { ok: false, notFound: true };
  }
  if (enabled || row.type !== "SMPP" || !row.system_id) {
    return { ok: true, systemId: row.system_id, enabled, dropped: 0 };
  }
  const teardown = await disconnectBindsFor(row.system_id);
  return {
    ok: true,
    systemId: row.system_id,
    enabled,
    dropped: teardown.dropped,
    problem: teardown.problem,
  };
}
