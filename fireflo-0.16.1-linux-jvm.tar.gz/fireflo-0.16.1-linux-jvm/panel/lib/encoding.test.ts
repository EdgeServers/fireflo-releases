import { test } from "node:test";
import assert from "node:assert/strict";
import {
  anyConverted,
  convertedFrom,
  customerLegSummary,
  dcsLabel,
  dcsName,
  esmClassText,
  ingressEncoding,
  messageCaption,
  receiptInEncoding,
  receiptOutEncoding,
  vendorLegSummary,
  vendorSubmitEncoding,
} from "./encoding.ts";

test("every SMPP data_coding the panel names, and dcs N for the rest", () => {
  const expected: [number, string][] = [
    [0, "GSM-7"], [1, "IA5/ASCII"], [2, "8-bit"], [3, "Latin-1"], [4, "8-bit binary"],
    [5, "JIS"], [6, "Cyrillic"], [7, "Hebrew"], [8, "UCS-2"],
  ];
  for (const [dcs, name] of expected) {
    assert.equal(dcsName(dcs), name);
    assert.equal(dcsLabel(dcs), `${name} · dcs ${dcs}`);
  }
  assert.equal(dcsName(17), "dcs 17");
  assert.equal(dcsLabel(240), "dcs 240");
  //a missing coding is not GSM-7
  assert.equal(dcsName(null), null);
  assert.equal(dcsLabel(undefined), null);
});

test("esm_class in words: UDH, receipts, modes", () => {
  assert.equal(esmClassText(0x00), "no flags");
  assert.equal(esmClassText(0x40), "UDH present");
  assert.equal(esmClassText(0x04), "delivery receipt");
  //what the gateway puts on a progress receipt to a customer
  assert.equal(esmClassText(0x24), "progress receipt");
  assert.equal(esmClassText(0x43), "UDH present, store and forward");
  assert.equal(esmClassText(0x80), "reply path");
  assert.equal(esmClassText(null), null);
});

test("converted is a different dcs on the way out, and only when both sides are known", () => {
  assert.equal(convertedFrom(3, 0), "converted from Latin-1 (dcs 3)");
  assert.equal(convertedFrom(8, 8), null);
  assert.equal(convertedFrom(null, 0), null, "an unknown ingress coding is not a conversion");
  assert.equal(convertedFrom(3, null), null, "an unrecorded send is not a conversion");
  assert.equal(anyConverted([{ dcs: 3, dcsSent: 3 }, { dcs: 3, dcsSent: 0 }]), true);
  assert.equal(anyConverted([{ dcs: 3 }]), false, "an older gateway has no dcsSent at all");
});

test("an SMPP submission: coding, esm_class, bytes and the field the text was in", () => {
  const e = ingressEncoding({
    ingress: "smpp", dcs: 8, esmClassReceived: 0, bytesReceived: 188, payloadReceived: false, charsReceived: 94,
  });
  assert.equal(e.label, "UCS-2 · dcs 8");
  assert.equal(e.detail, "esm 0x00 · 188 bytes · short_message");
  const p = ingressEncoding({ ingress: "smpp", dcs: 8, esmClassReceived: 0x40, bytesReceived: 300, payloadReceived: true });
  assert.equal(p.detail, "esm 0x40 UDH present · 300 bytes · message_payload");
});

test("an HTTP submission: the gateway's NULLs are said, not shown blank", () => {
  const e = ingressEncoding({
    ingress: "http", dcs: 0, esmClassReceived: null, bytesReceived: null, payloadReceived: null, charsReceived: 52,
  });
  assert.equal(e.label, "GSM-7 · dcs 0");
  assert.equal(e.detail, "52 characters · over HTTP: no esm_class or octets");
  const s = customerLegSummary({ ingress: "http", dcs: 0, charsReceived: 52 }, false);
  assert.deepEqual(s.chips.map((c) => c.text), ["Received as GSM-7 · dcs 0 · over HTTP · 52 characters"]);
});

test("on a 1.123.0 database the ingress dcs still speaks, and nothing else is claimed", () => {
  //no V1.124.0 keys on the row at all
  const e = ingressEncoding({ ingress: "smpp", dcs: 3 });
  assert.equal(e.label, "Latin-1 · dcs 3");
  assert.equal(e.detail, null);
  assert.equal(vendorSubmitEncoding({ dcs: 3 }), undefined, "no guessing that the vendor got dcs 3");
  assert.equal(receiptInEncoding({}), undefined);
  assert.deepEqual(vendorLegSummary([{ dcs: 3, partNo: 1, vendor: "v" }], [{}]), { chips: [], note: null });
});

test("the customer leg's chips: received, and the receipt we sent, always dcs 0", () => {
  const s = customerLegSummary({ ingress: "smpp", dcs: 8, bytesReceived: 188, inboundSegments: null }, true);
  assert.deepEqual(s.chips.map((c) => c.text), [
    "Received as UCS-2 · dcs 8 · 1 submit_sm · 188 bytes",
    "Receipt sent as GSM-7 · dcs 0",
  ]);
  const two = customerLegSummary({ ingress: "smpp", dcs: 8, inboundSegments: 2 }, false);
  assert.deepEqual(two.chips.map((c) => c.text), ["Received as UCS-2 · dcs 8 · 2 submit_sms"]);
  assert.equal(receiptOutEncoding(true).label, "GSM-7 · dcs 0");
  assert.equal(receiptOutEncoding(true).detail, "esm 0x04 delivery receipt · always dcs 0");
  assert.equal(receiptOutEncoding(false).detail, "esm 0x24 progress receipt · always dcs 0");
});

test("the vendor leg: same coding, parts and UDH; receipt coding", () => {
  const s = vendorLegSummary(
    [
      { dcs: 8, dcsSent: 8, esmClassSent: 0x40, bytesSent: 140, partNo: 1, vendor: "jio" },
      { dcs: 8, dcsSent: 8, esmClassSent: 0x40, bytesSent: 54, partNo: 2, vendor: "jio" },
    ],
    [{ dcsReceived: 0 }, { dcsReceived: 0 }]
  );
  assert.deepEqual(s.chips, [
    { text: "Sent as UCS-2 · dcs 8 · 2 parts · UDH", tone: "neutral" },
    { text: "Receipt received as GSM-7 · dcs 0", tone: "neutral" },
  ]);
  assert.equal(s.note, "Same coding as the customer sent: nothing converted.");
});

test("a conversion is a warning chip naming the vendor and its msgType.dcs.map", () => {
  const s = vendorLegSummary([{ dcs: 3, dcsSent: 0, esmClassSent: 0, bytesSent: 52, partNo: 1, vendor: "airtel-txn" }], []);
  assert.deepEqual(s.chips, [
    { text: "Sent as GSM-7 · dcs 0, converted from Latin-1 (dcs 3) · 1 part", tone: "warning" },
  ]);
  assert.match(s.note ?? "", /airtel-txn maps the customer's dcs 3 to dcs 0 \(its msgType\.dcs\.map/);
  assert.match(s.note ?? "", /GSM-7 cannot carry would have been replaced/);
  const cell = vendorSubmitEncoding({ dcs: 3, dcsSent: 0, esmClassSent: 0, bytesSent: 52 })!;
  assert.equal(cell.label, "GSM-7 · dcs 0");
  assert.equal(cell.convertedFrom, "converted from Latin-1 (dcs 3)");
  assert.equal(cell.detail, "esm 0x00 · 52 bytes");
});

test("an attempt with the column but no value says not recorded, visibly", () => {
  const cell = vendorSubmitEncoding({ dcs: 0, dcsSent: null, esmClassSent: null, bytesSent: null })!;
  assert.equal(cell.label, "not recorded");
  assert.ok(cell.detail, "the reason is on the cell, not only in a tooltip");
  assert.equal(receiptInEncoding({ dcsReceived: null })!.label, "not recorded");
  assert.equal(receiptInEncoding({ dcsReceived: 8 })!.label, "UCS-2 · dcs 8");
});

test("the Message caption counts characters without the body", () => {
  assert.equal(
    messageCaption({ ingress: "smpp", dcs: 8, charsReceived: 94, partCount: 2, body: null }, [{ dcs: 8, dcsSent: 8 }]),
    "UCS-2 · 94 characters · 2 parts"
  );
  assert.equal(
    messageCaption({ ingress: "smpp", dcs: 3, charsReceived: 52, partCount: 1 }, [{ dcs: 3, dcsSent: 0 }]),
    "Latin-1 in, GSM-7 out · 52 characters · 1 part"
  );
  //before V1.124.0: the stored body's length, or no count at all
  assert.equal(messageCaption({ ingress: "smpp", dcs: 0, partCount: 1, body: "hello" }, [{ dcs: 0 }]), "GSM-7 · 5 characters · 1 part");
  assert.equal(messageCaption({ ingress: "smpp", dcs: null, partCount: 1 }, []), "1 part");
});

test("one row per message: the vendor chip counts parts from part_count, not from rows", () => {
  const s = vendorLegSummary(
    [{ partNo: 1, partCount: 2, vendor: "jio-mkt-002", dcs: 8, dcsSent: 8, esmClassSent: 0x43, bytesSent: 212 }],
    []
  );
  assert.match(s.chips[0].text, /Sent as UCS-2 · dcs 8 · 2 parts · UDH/);
});
