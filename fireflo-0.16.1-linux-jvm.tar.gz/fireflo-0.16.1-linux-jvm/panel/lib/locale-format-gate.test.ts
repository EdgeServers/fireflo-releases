import { test } from "node:test";
import assert from "node:assert/strict";
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { fileURLToPath } from "node:url";

/**
 * Every time on the panel is written by lib/datetime, in the display zone. This keeps it that way.
 *
 * <p>The bug this guards against was thirty call sites of `new Date(x).toLocaleString()`, each in
 * whatever zone and locale the browser (or the server) happened to have, and table axes cut with
 * `.slice(11, 16)` out of a UTC ISO string -- so one page could show the same instant three ways.
 * A new one is easy to write and invisible in review, hence a test rather than a convention.
 *
 * <p>The rules, over app/, components/, lib/ and hooks/ (tests and comments excepted):
 *
 * <ul>
 *   <li>`toLocaleTimeString(` and `toLocaleDateString(` only in lib/datetime.ts: they only format dates.</li>
 *   <li>`toLocaleString(` only in the number formatters (lib/format.ts, lib/tps-format.ts) and on the
 *       few lines below that group a number with a pinned locale. A number elsewhere goes through
 *       `count()` / `localeNumber()` from lib/format; a date through lib/datetime.</li>
 *   <li>No `.slice(11, 16)` or `.slice(11, 19)`: that is the UTC clock out of an ISO string, labelled
 *       as nothing. `formatHour` / `formatClock` say which zone it is in.</li>
 * </ul>
 */

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const DIRS = ["app", "components", "lib", "hooks"];

/** The files whose job is formatting: numbers in the first two, dates in the last. */
const NUMBER_FORMATTERS = new Set(["lib/format.ts", "lib/tps-format.ts", "lib/datetime.ts"]);

/** Lines that group a number with a deliberately pinned locale; each is a number, by reading it. */
const NUMBER_LINES: readonly [file: string, snippet: string][] = [
  ["lib/throughput.ts", 'Math.round(c.portLimit).toLocaleString("en")'],
  ["lib/encoding.ts", 'n.toLocaleString("en-AU")'],
];

function sources(dir: string): string[] {
  const out: string[] = [];
  for (const name of readdirSync(dir)) {
    const path = join(dir, name);
    if (name === "node_modules" || name.startsWith(".") || name === "__fixtures__") {
      continue;
    }
    if (statSync(path).isDirectory()) {
      out.push(...sources(path));
    } else if (/\.(ts|tsx)$/.test(name) && !/\.test\.tsx?$/.test(name) && !name.endsWith(".d.ts")) {
      out.push(path);
    }
  }
  return out;
}

/** Each line that is code: block-comment and line-comment lines are prose about these calls. */
function codeLines(text: string): { n: number; line: string }[] {
  const out: { n: number; line: string }[] = [];
  let inBlock = false;
  text.split("\n").forEach((raw, i) => {
    const t = raw.trim();
    if (inBlock) {
      if (t.includes("*/")) inBlock = false;
      return;
    }
    if (t.startsWith("/*")) {
      if (!t.includes("*/")) inBlock = true;
      return;
    }
    if (t.startsWith("//") || t.startsWith("*") || t.startsWith("{/*")) {
      return;
    }
    out.push({ n: i + 1, line: raw.replace(/\/\/.*$/, "") });
  });
  return out;
}

function offences(): string[] {
  const found: string[] = [];
  for (const dir of DIRS) {
    let files: string[];
    try {
      files = sources(join(ROOT, dir));
    } catch {
      continue;
    }
    for (const path of files) {
      const file = relative(ROOT, path).split("\\").join("/");
      for (const { n, line } of codeLines(readFileSync(path, "utf8"))) {
        const at = `${file}:${n}: ${line.trim()}`;
        if (/\.toLocale(?:Time|Date)String\(/.test(line) && file !== "lib/datetime.ts") {
          found.push(`date formatted outside lib/datetime -- ${at}`);
        }
        if (/\.toLocaleString\(/.test(line)
          && !NUMBER_FORMATTERS.has(file)
          && !NUMBER_LINES.some(([f, snippet]) => f === file && line.includes(snippet))) {
          found.push(`toLocaleString outside the formatters (a number: count()/localeNumber(); a date: lib/datetime) -- ${at}`);
        }
        if (/\.slice\(\s*11\s*,\s*(?:16|19)\s*\)/.test(line)) {
          found.push(`a UTC clock cut out of an ISO string (use formatHour/formatClock) -- ${at}`);
        }
      }
    }
  }
  return found;
}

test("times are formatted by lib/datetime only, numbers by lib/format", () => {
  const found = offences();
  assert.deepEqual(found, [], `\n${found.join("\n")}`);
});

test("the gate sees what it is for", () => {
  //a guard that matches nothing passes forever; prove each rule bites on a line it should
  const probe = codeLines([
    "const a = new Date(x).toLocaleString();",
    "// new Date(x).toLocaleTimeString() in a comment is prose",
    "const b = iso.slice(11, 16);",
  ].join("\n"));
  assert.equal(probe.length, 2);
  assert.match(probe[0].line, /\.toLocaleString\(/);
  assert.match(probe[1].line, /\.slice\(\s*11\s*,\s*16\s*\)/);
  //and every allowlisted number line still exists, so the list cannot rot into blanket permission
  for (const [file, snippet] of NUMBER_LINES) {
    assert.ok(readFileSync(join(ROOT, file), "utf8").includes(snippet), `${file} no longer has ${snippet}`);
  }
});
