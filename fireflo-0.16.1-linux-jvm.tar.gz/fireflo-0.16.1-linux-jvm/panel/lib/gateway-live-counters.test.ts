import { strict as assert } from "node:assert";
import { test } from "node:test";
import {
  normaliseLiveCounters, readLiveCounters, sumLiveCounters, toLiveCountersSum, type LiveCountersSum, type LiveCountersWire,
} from "./gateway-live-counters.ts";

const NODE_1: LiveCountersWire = {
  node: "node-1",
  since: "2026-10-30T07:41:12.345Z",
  mt: { total: "1000", ack: "990", nack: 10 },
  dlr: { total: 1800, in: "900", out: "900" },
  db: { written: "4000000000", queue: 12 },
  rates: { mtAckPerSecond: "100.5", mtNackPerSecond: 0.5, dlrInPerSecond: 90, dlrOutPerSecond: "88", dbWrittenPerSecond: 101 },
};
const NODE_2: LiveCountersWire = {
  node: "node-2",
  since: "2026-10-30T06:00:00Z",
  mt: { total: 200, ack: 200, nack: 0 },
  dlr: { total: 300, in: 150, out: 150 },
  db: { written: 200, queue: 0 },
  rates: { mtAckPerSecond: 20, mtNackPerSecond: 0, dlrInPerSecond: 15, dlrOutPerSecond: 15, dbWrittenPerSecond: 20 },
};

test("normalise: Longs as strings or numbers, the since instant re-emitted as ISO", () => {
  const n = normaliseLiveCounters(NODE_1);
  assert.equal(n.node, "node-1");
  assert.equal(n.since, "2026-10-30T07:41:12.345Z");
  assert.deepEqual(n.mt, { total: 1000, ack: 990, nack: 10 });
  assert.deepEqual(n.dlr, { total: 1800, in: 900, out: 900 });
  assert.deepEqual(n.db, { written: 4_000_000_000, queue: 12 });
  assert.deepEqual(n.rates, { mtAckPerSecond: 100.5, mtNackPerSecond: 0.5, dlrInPerSecond: 90, dlrOutPerSecond: 88, dbWrittenPerSecond: 101 });
});

test("normalise: missing, null, negative and unreadable figures are 0; a missing total is its parts' sum", () => {
  const n = normaliseLiveCounters({ node: "", since: "not a date", mt: { ack: "7", nack: "x" }, dlr: null, db: { written: -3, queue: "" } });
  assert.equal(n.node, null);
  assert.equal(n.since, null);
  assert.deepEqual(n.mt, { total: 7, ack: 7, nack: 0 });
  assert.deepEqual(n.dlr, { total: 0, in: 0, out: 0 });
  assert.deepEqual(n.db, { written: 0, queue: 0 });
  assert.equal(n.rates.dbWrittenPerSecond, 0);
  assert.deepEqual(normaliseLiveCounters(null).mt, { total: 0, ack: 0, nack: 0 });
});

test("sum: every node's counters and rates added, since the earliest node's, partial kept", () => {
  const s = sumLiveCounters([normaliseLiveCounters(NODE_1), normaliseLiveCounters(NODE_2)], ["node-3"]);
  assert.deepEqual(s.nodes, ["node-1", "node-2"]);
  assert.deepEqual(s.partial, ["node-3"]);
  assert.equal(s.since, "2026-10-30T06:00:00.000Z");
  assert.deepEqual(s.mt, { total: 1200, ack: 1190, nack: 10 });
  assert.deepEqual(s.dlr, { total: 2100, in: 1050, out: 1050 });
  assert.deepEqual(s.db, { written: 4_000_000_200, queue: 12 });
  assert.deepEqual(s.rates, { mtAckPerSecond: 120.5, mtNackPerSecond: 0.5, dlrInPerSecond: 105, dlrOutPerSecond: 103, dbWrittenPerSecond: 121 });
});

test("sum: a node without a since does not hide the others'; none at all is null", () => {
  const s = toLiveCountersSum({ answers: [{ ...NODE_2, since: null }, NODE_1], partial: [] });
  assert.equal(s.since, "2026-10-30T07:41:12.345Z");
  assert.equal(sumLiveCounters([]).since, null);
  assert.equal(sumLiveCounters([]).mt.total, 0);
});

const SUM: LiveCountersSum = sumLiveCounters([normaliseLiveCounters(NODE_1)]);

test("route: 204 when the gateway has no live_counters, without asking for the counters", async () => {
  let read = 0;
  const a = await readLiveCounters({ available: async () => false, read: async () => (read++, SUM) });
  assert.deepEqual(a, { status: 204 });
  assert.equal(read, 0);
});

test("route: 502 when the capability cannot be asked, or the counters cannot be read", async () => {
  const down = await readLiveCounters({ available: async () => { throw new Error("Could not reach the gateway"); }, read: async () => SUM });
  assert.deepEqual(down, { status: 502, body: { error: "Could not reach the gateway" } });
  const refused = await readLiveCounters({ available: async () => true, read: async () => { throw new Error("liveCounters refused"); } });
  assert.deepEqual(refused, { status: 502, body: { error: "liveCounters refused" } });
  const odd = await readLiveCounters({ available: async () => true, read: () => Promise.reject("no") });
  assert.equal(odd.status, 502);
});

test("route: 200 with the cluster's sum", async () => {
  const a = await readLiveCounters({ available: async () => true, read: async () => SUM });
  assert.deepEqual(a, { status: 200, body: { data: SUM } });
});

test("route: a slow gateway is a 502 with code SLOW, and its capability is not asked after it", async () => {
  const { GatewayError, PANEL_CODES } = await import("./gateway-graphql-core.ts");
  let available = 0;
  const a = await readLiveCounters({
    available: async () => (available++, true),
    read: async () => { throw new GatewayError(502, PANEL_CODES.slow, "The gateway is slow: no answer within 10 s."); },
  });
  assert.deepEqual(a, { status: 502, body: { error: "The gateway is slow: no answer within 10 s.", code: "SLOW" } });
  assert.equal(available, 1, "asked once, before the read, and that never reaches the gateway");
});

test("route: a refused read that taught the gateway lacks live_counters is a 204", async () => {
  const { GatewayError } = await import("./gateway-graphql-core.ts");
  let has = true;
  const a = await readLiveCounters({
    available: async () => has,
    read: async () => {
      has = false;
      throw new GatewayError(400, "BAD_REQUEST", "Field 'liveCounters' undefined");
    },
  });
  assert.deepEqual(a, { status: 204 });
});
