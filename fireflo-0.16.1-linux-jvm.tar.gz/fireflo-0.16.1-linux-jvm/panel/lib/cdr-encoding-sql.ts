import type { CdrRow } from "./cdr-request.ts";

/**
 * Which of the gateway's V1.124.0 encoding columns this database has, and the SQL that selects them.
 *
 * <p>Database-free on purpose: the probe's answer is turned into a decision by
 * {@link encodingSupportFrom} and the projections by {@link submitEncodingSelect} and friends, so
 * `node --test` can show that a 1.123.0 database is never asked for a column it lacks. The query
 * itself runs in `metrics-schema.ts`.
 *
 * <p><strong>A column counts only where every relation a reader may name has it.</strong> The
 * `_all` views (V1.112.0) are `SELECT *` over the live and archive tables, and Postgres expands
 * the star when a view is created, so a column added to `cdr_submit` is not in `cdr_submit_all`
 * until the migration recreates the view. `cdr-tier.ts` routes the detail page to the views for an
 * archived message; selecting a column the view lacks is a hard error, not a null. So a column on
 * the table and missing from an existing view is treated as absent.
 */

/** The `cdr_submit` columns, in the order they are selected. */
export const SUBMIT_ENCODING_COLUMNS = [
  "esm_class_received",
  "chars_received",
  "bytes_received",
  "payload_received",
  "dcs_sent",
  "esm_class_sent",
  "bytes_sent",
] as const;

export type SubmitEncodingColumn = (typeof SUBMIT_ENCODING_COLUMNS)[number];

/** On `cdr_final` and `cdr_interim`: the vendor receipt's data_coding. */
export const RECEIPT_ENCODING_COLUMN = "dcs_received";

export interface EncodingSupport {
  submit: ReadonlySet<SubmitEncodingColumn>;
  /** `cdr_final.dcs_received`. */
  final: boolean;
  /** `cdr_interim.dcs_received`. */
  interim: boolean;
}

export const NO_ENCODING: EncodingSupport = { submit: new Set(), final: false, interim: false };

type Base = "cdr_submit" | "cdr_final" | "cdr_interim";

/**
 * One round trip for all eight columns, on the base tables and their `_all` views, plus which of
 * the views exist. Rows with a null `column_name` are the views.
 */
export const ENCODING_PROBE_SQL = `
  SELECT table_name, column_name
    FROM information_schema.columns
   WHERE table_name IN ('cdr_submit', 'cdr_submit_all', 'cdr_final', 'cdr_final_all',
                        'cdr_interim', 'cdr_interim_all')
     AND column_name IN (${[...SUBMIT_ENCODING_COLUMNS, RECEIPT_ENCODING_COLUMN].map((c) => `'${c}'`).join(", ")})
  UNION ALL
  SELECT table_name, NULL
    FROM information_schema.tables
   WHERE table_name IN ('cdr_submit_all', 'cdr_final_all', 'cdr_interim_all')`;

export interface ProbeRow {
  table_name: string;
  column_name: string | null;
}

/** The probe's rows, as a decision: a column is present when its table and any view of it have it. */
export function encodingSupportFrom(rows: readonly ProbeRow[]): EncodingSupport {
  const views = new Set(rows.filter((r) => r.column_name == null).map((r) => r.table_name));
  const has = new Set(rows.filter((r) => r.column_name != null).map((r) => `${r.table_name}.${r.column_name}`));
  const present = (base: Base, column: string): boolean =>
    has.has(`${base}.${column}`) && (!views.has(`${base}_all`) || has.has(`${base}_all.${column}`));
  return {
    submit: new Set(SUBMIT_ENCODING_COLUMNS.filter((c) => present("cdr_submit", c))),
    final: present("cdr_final", RECEIPT_ENCODING_COLUMN),
    interim: present("cdr_interim", RECEIPT_ENCODING_COLUMN),
  };
}

/** Whether nothing more can appear: every column present, so the answer may be cached for good. */
export function encodingComplete(have: EncodingSupport): boolean {
  return have.submit.size === SUBMIT_ENCODING_COLUMNS.length && have.final && have.interim;
}

/** `, s.esm_class_received, …` for the columns present, or "" on a 1.123.0 database. */
export function submitEncodingSelect(have: EncodingSupport, alias = "s"): string {
  return SUBMIT_ENCODING_COLUMNS.filter((c) => have.submit.has(c)).map((c) => `, ${alias}.${c}`).join("");
}

/** `, dcs_received` on a receipt table that has it, else "". */
export function receiptEncodingSelect(present: boolean, alias = ""): string {
  return present ? `, ${alias ? `${alias}.` : ""}${RECEIPT_ENCODING_COLUMN}` : "";
}

/**
 * The encoding columns of one result row, each only when it was selected.
 *
 * <p>The absent/null distinction is the whole contract -- absent is a schema without the column,
 * null a row without a value -- and it is easy to lose to a `?? null` written in passing.
 */
export function encodingFields(r: Record<string, unknown>): Partial<CdrRow> {
  const out: Partial<CdrRow> = {};
  if ("esm_class_received" in r) out.esmClassReceived = int(r.esm_class_received);
  if ("chars_received" in r) out.charsReceived = int(r.chars_received);
  if ("bytes_received" in r) out.bytesReceived = int(r.bytes_received);
  if ("payload_received" in r) out.payloadReceived = bool(r.payload_received);
  if ("dcs_sent" in r) out.dcsSent = int(r.dcs_sent);
  if ("esm_class_sent" in r) out.esmClassSent = int(r.esm_class_sent);
  if ("bytes_sent" in r) out.bytesSent = int(r.bytes_sent);
  if ("dcs_received" in r) out.dcsReceived = int(r.dcs_received);
  if ("inbound_segments" in r) out.inboundSegments = int(r.inbound_segments);
  return out;
}

function int(value: unknown): number | null {
  if (value == null || value === "") {
    return null;
  }
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

/** pg hands a boolean back as one; a text-cast copy would be "t"/"f". Null stays null. */
function bool(value: unknown): boolean | null {
  if (value == null) {
    return null;
  }
  return value === true || value === "t" || value === "true";
}
