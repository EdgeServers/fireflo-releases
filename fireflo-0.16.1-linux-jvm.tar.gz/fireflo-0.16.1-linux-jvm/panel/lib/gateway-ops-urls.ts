/**
 * Which gateway node's management port to call, for a 0.14 cluster.
 *
 * <p>`GATEWAY_OPS_URLS` is an optional failover list, `id=url` pairs separated by commas
 * (`gw-1=http://10.0.0.11:9000,gw-2=http://10.0.0.12:9000`), written by
 * `fireflo-panel-install --gateway-ops-urls`. The panel uses the first node, in listed order, that
 * answers a cheap health query within {@link OPS_PROBE_TIMEOUT_MS}, and then keeps calling that node
 * directly -- it is never probed before a call (0.15.1):
 *
 * <ul>
 *   <li><b>A refusal drops it.</b> A call that finds the port refusing, or the name not resolving,
 *       invalidates the choice, so the next call re-probes from the top and lands on the next node
 *       that answers.</li>
 *   <li><b>A slow answer does not.</b> A timeout is the node working under load, and the next call
 *       goes to the same node again; moving on would only move the load (`PANEL_CODES.slow`).</li>
 *   <li><b>Failback runs beside the calls.</b> A choice that is not the first listed node is
 *       re-checked every {@link OPS_URLS_TTL_MS}, in the background, against the nodes listed before
 *       it: the call in hand goes to the current node, and a later call moves to an earlier node
 *       only once it has answered the probe.</li>
 *   <li><b>A slow probe still counts.</b> When no node answers in time but one is slow, the first
 *       slow node is chosen over the fallback: it is there.</li>
 * </ul>
 *
 * <p>With no list -- every install before 0.14, and every single-node one -- the answer is
 * `GATEWAY_OPS_URL`, exactly as before, with no probe at all.
 *
 * <p>Only the URL changes from node to node. The tokens are the same on every node: in db config
 * mode the gateway keeps smsg.ops.token and smsg.ops.admin.token in app_config, which every node
 * reads, so one `GATEWAY_OPS_TOKEN` / `GATEWAY_OPS_ADMIN_TOKEN` pair serves the whole cluster.
 *
 * <p>Imports nothing from Next, so it runs under plain `node --test`.
 */

export interface OpsNode {
  id: string;
  url: string;
}

/**
 * Parses `id=url,id=url`. Entries that are not `id=url` with an http(s) URL are skipped rather
 * than thrown on: the installer already refuses them, and a hand-edited panel.env with one bad
 * entry should still reach the good ones. A repeated id keeps its first entry.
 */
export function parseOpsUrls(raw: string | undefined): OpsNode[] {
  const nodes: OpsNode[] = [];
  const seen = new Set<string>();
  for (const part of (raw ?? "").split(",")) {
    const entry = part.trim();
    const eq = entry.indexOf("=");
    if (eq <= 0) {
      continue;
    }
    const id = entry.slice(0, eq).trim();
    const url = entry.slice(eq + 1).trim().replace(/\/+$/, "");
    if (!id || !/^https?:\/\/[^/]/.test(url) || seen.has(id)) {
      continue;
    }
    seen.add(id);
    nodes.push({ id, url });
  }
  return nodes;
}

/**
 * Whether a node's management port answers, within the probe's own deadline: `true` (or "up") when
 * it does, "slow" when it timed out, `false` (or "down") when it refused.
 */
export type OpsProbe = (url: string) => Promise<boolean | ProbeVerdict>;
export type ProbeVerdict = "up" | "slow" | "down";

export interface OpsUrlResolverOptions {
  nodes: OpsNode[];
  /** `GATEWAY_OPS_URL`, the last resort when no listed node answers. */
  fallback?: string;
  probe: OpsProbe;
  ttlMs?: number;
  now?: () => number;
}

export interface OpsUrlResolver {
  /** The base URL to call, or undefined when there is neither a list nor a fallback. */
  resolve(): Promise<string | undefined>;
  /** Forget the kept choice, after a call to `url` was refused. Never after a slow answer. */
  invalidate(url: string): void;
}

/** How often a choice that is not the first listed node is re-checked for failback, in the background. */
export const OPS_URLS_TTL_MS = 30_000;
/** How long a node may take to answer the health probe before it counts as slow. */
export const OPS_PROBE_TIMEOUT_MS = 5_000;

function verdictOf(v: boolean | ProbeVerdict): ProbeVerdict {
  return v === true ? "up" : v === false ? "down" : v;
}

export function createOpsUrlResolver({
  nodes,
  fallback,
  probe,
  ttlMs = OPS_URLS_TTL_MS,
  now = Date.now,
}: OpsUrlResolverOptions): OpsUrlResolver {
  const last = fallback?.trim().replace(/\/+$/, "") || undefined;
  let cached: { url: string | undefined; at: number } | null = null;
  //one round of probes at a time: a burst of page requests must not become a burst of probes
  let inFlight: Promise<string | undefined> | null = null;
  let failback: Promise<void> | null = null;

  const ask = (url: string) => probe(url).then(verdictOf, () => "down" as const);

  async function choose(): Promise<string | undefined> {
    let firstSlow: string | undefined;
    for (const node of nodes) {
      const verdict = await ask(node.url);
      if (verdict === "up") {
        return node.url;
      }
      if (verdict === "slow" && firstSlow === undefined) {
        firstSlow = node.url;
      }
    }
    //nothing answered in time: a node that is there but slow, else the fallback if there is one,
    //else the first node, so the caller's own error names a real address rather than "not configured"
    return firstSlow ?? last ?? nodes[0]?.url;
  }

  /** The nodes listed before `url` (all of them when it is not listed), in order, for failback. */
  function before(url: string | undefined): OpsNode[] {
    const i = nodes.findIndex((n) => n.url === url);
    return i < 0 ? nodes : nodes.slice(0, i);
  }

  function checkFailback(kept: { url: string | undefined; at: number }) {
    const earlier = before(kept.url);
    if (earlier.length === 0 || failback || now() - kept.at < ttlMs) {
      return;
    }
    failback = (async () => {
      for (const node of earlier) {
        if ((await ask(node.url)) === "up") {
          //only if nothing replaced the choice meanwhile (a refusal, another round)
          if (cached === kept) {
            cached = { url: node.url, at: now() };
          }
          return;
        }
      }
      if (cached === kept) {
        cached = { url: kept.url, at: now() };
      }
    })().finally(() => {
      failback = null;
    });
  }

  return {
    async resolve() {
      if (nodes.length === 0) {
        return last;
      }
      if (cached) {
        //the kept node, directly; an earlier node is looked for beside this call, not before it
        checkFailback(cached);
        return cached.url;
      }
      if (!inFlight) {
        inFlight = choose().then(
          (url) => {
            cached = { url, at: now() };
            inFlight = null;
            return url;
          },
          (err) => {
            inFlight = null;
            throw err;
          }
        );
      }
      return inFlight;
    },
    invalidate(url) {
      if (cached && cached.url === url) {
        cached = null;
      }
    },
  };
}

/**
 * The default probe: `query Health { health { version } }` with the read token,
 * {@link OPS_PROBE_TIMEOUT_MS}. Anything but an HTTP 200 counts as not answering -- a node that
 * refuses the token or this panel's address is of no use to it, even though the port is open. A
 * timeout is "slow": the node is there.
 */
export function healthProbe(token: string | undefined, timeoutMs = OPS_PROBE_TIMEOUT_MS): OpsProbe {
  return async (url) => {
    try {
      const res = await fetch(`${url}/graphql`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token ?? ""}`, "Content-Type": "application/json" },
        body: JSON.stringify({ query: "query Health { health { version } }" }),
        signal: AbortSignal.timeout(timeoutMs),
        cache: "no-store",
      });
      await res.body?.cancel().catch(() => undefined);
      return res.status === 200;
    } catch (err) {
      const name = (err as { name?: unknown } | null)?.name;
      return name === "TimeoutError" || name === "AbortError" ? "slow" : false;
    }
  };
}

let shared: { key: string; resolver: OpsUrlResolver } | null = null;

/**
 * The process-wide resolver for the current environment. Rebuilt when any of the three variables
 * it depends on changes, which only tests do.
 */
export function opsUrlResolver(env: NodeJS.ProcessEnv = process.env): OpsUrlResolver {
  const key = [env.GATEWAY_OPS_URLS ?? "", env.GATEWAY_OPS_URL ?? "", env.GATEWAY_OPS_TOKEN ?? ""].join("\n");
  if (!shared || shared.key !== key) {
    shared = {
      key,
      resolver: createOpsUrlResolver({
        nodes: parseOpsUrls(env.GATEWAY_OPS_URLS),
        fallback: env.GATEWAY_OPS_URL,
        probe: healthProbe(env.GATEWAY_OPS_TOKEN?.trim()),
      }),
    };
  }
  return shared.resolver;
}
