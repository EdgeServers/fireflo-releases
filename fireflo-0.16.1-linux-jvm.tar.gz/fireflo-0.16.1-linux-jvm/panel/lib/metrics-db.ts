import { AsyncLocalStorage } from "node:async_hooks";
import { Pool, type QueryResultRow } from "pg";

import { CDR_ROUTED, cdrNamesTable, cdrRouteUnmarked, readCdrBoundary, type CdrBoundary } from "./cdr-grain.ts";
import { timedDb } from "./db-trace.ts";

/**
 * Read-only access to the gateway's call-record database.
 *
 * <p>This module never issues DDL and never writes. That is not a convention to be relied on
 * alone -- the connection should use a role granted only SELECT, so a mistake here cannot damage
 * billing records. The sibling panel's Postgres helper runs a CREATE TABLE block on connect, which
 * is precisely why this is a separate module rather than a reuse of it.
 *
 * <p>Every query is parameterised. Nothing here interpolates a value, an identifier or an
 * interval into SQL.
 *
 * <p><strong>Hot and archive (gateway 0.15).</strong> A statement that names a call record table
 * and was not routed by `cdr-tier.ts` (`cdrSql`) is read through the `_all` views once the tables
 * are split, so a reader that forgot its window still sees every row. The boundary it routes by,
 * {@link cdrBoundary}, is read from `cdr_tier` here, once a minute.
 */
let pool: Pool | null = null;

/** The pool's ceiling, also reported on the Queues page's Database card. */
export const METRICS_POOL_MAX = 8;

/**
 * The pool's connections now: open, idle and callers waiting for one (pg's own counters). All zero
 * before the first read opens the pool.
 */
export function metricsPoolStats(): { max: number; total: number; idle: number; waiting: number } {
  return { max: METRICS_POOL_MAX, total: pool?.totalCount ?? 0, idle: pool?.idleCount ?? 0, waiting: pool?.waitingCount ?? 0 };
}

export function isConfigured(): boolean {
  return !!process.env.METRICS_DATABASE_URL?.trim();
}

function getPool(): Pool {
  const url = process.env.METRICS_DATABASE_URL?.trim();
  if (!url) {
    throw new Error("METRICS_DATABASE_URL is not set");
  }
  if (!pool) {
    pool = new Pool({
      connectionString: url,
      max: METRICS_POOL_MAX,
      connectionTimeoutMillis: 5_000,
      idleTimeoutMillis: 30_000,
      //a dashboard query that has not answered in ten seconds is not going to be useful, and
      //holding the connection helps nobody
      statement_timeout: 10_000,
      //every session in UTC, whatever the database server's own \`timezone\` setting is. The panel
      //cuts days explicitly (\`AT TIME ZONE\` the billing zone) and sends instants; a session zone
      //would only matter where a query forgot to, and then it should be the same answer on every
      //install rather than whatever postgresql.conf on that host says
      options: "-c timezone=UTC",
    });
  }
  return pool;
}

/** A longer statement limit for the reads made inside {@link withStatementTimeout}; none means the pool's 10 s. */
const limits = new AsyncLocalStorage<number>();

/**
 * Runs `read` with every statement it makes allowed `ms` rather than the pool's 10 s.
 *
 * <p>For the heavy stats only (`stats-route.ts`), which read on in the background after the page
 * has been told to wait: a month of receipts at production volume can need more than ten seconds,
 * and cutting it off means it never finishes at all. The connection's limit is set for the
 * statement and reset before it goes back to the pool, so nothing else inherits it.
 */
export function withStatementTimeout<T>(ms: number, read: () => Promise<T>): Promise<T> {
  return limits.run(ms, read);
}

const BOUNDARY_TTL_MS = 60_000;
let boundaryCache: { at: CdrBoundary; readAt: number } | null = null;
let boundaryRead: Promise<CdrBoundary> | null = null;
let boundaryWarned = false;

/**
 * Where the hot call record tables begin: `max(cdr_tier.hot_from, cdr_tier.moving_to)`; null on a
 * database without tiers (before V1.112.0); `CDR_EVERYTHING` when `cdr_tier` exists but cannot be
 * read. Cached a minute, which the mover allows for: it publishes `moving_to` and waits longer than
 * that before it moves anything, so a cached boundary is never later than the one in force.
 */
export async function cdrBoundary(): Promise<CdrBoundary> {
  if (boundaryCache && Date.now() - boundaryCache.readAt < BOUNDARY_TTL_MS) {
    return boundaryCache.at;
  }
  if (!boundaryRead) {
    boundaryRead = readCdrBoundary(async (sql) => (await getPool().query(sql)).rows)
      .then(({ boundary, error }) => {
        if (error && !boundaryWarned) {
          boundaryWarned = true;
          console.warn(`cdr_tier: ${error}; every call record read goes through the _all views`);
        }
        boundaryCache = { at: boundary, readAt: Date.now() };
        return boundary;
      })
      .finally(() => {
        boundaryRead = null;
      });
  }
  return boundaryRead;
}

/** Test helper: forget the cached boundary. */
export function resetCdrBoundary(): void {
  boundaryCache = null;
  boundaryRead = null;
  boundaryWarned = false;
}

export async function query<T extends QueryResultRow>(text: string, params: unknown[] = []): Promise<T[]> {
  //the boundary is asked only by a statement that reads a call record table nobody routed
  const sql = !text.includes(CDR_ROUTED) && cdrNamesTable(text) ? cdrRouteUnmarked(text, await cdrBoundary()) : text;
  const ms = limits.getStore();
  //timed for the footer's data-source stat when a request is being traced (db-trace.ts): the whole
  //call, connection acquisition and the statement-limit round trips included, since that is the
  //wait the page sees
  return timedDb("metrics", async () => {
    if (ms === undefined) {
      const result = await getPool().query<T>(sql, params);
      return result.rows;
    }
    const client = await getPool().connect();
    try {
      await client.query(`SET statement_timeout = ${Math.max(1_000, Math.floor(ms))}`);
      const result = await client.query<T>(sql, params);
      return result.rows;
    } finally {
      await client.query("RESET statement_timeout").catch(() => undefined);
      client.release();
    }
  });
}

/** Test and shutdown helper. */
export async function closeMetricsDb(): Promise<void> {
  const existing = pool;
  pool = null;
  await existing?.end();
}
