import { strict as assert } from "node:assert";
import { test } from "node:test";
import {
  HARD_HELP,
  PERSIST_STREAMS,
  RESTART_COPY,
  RESTART_PARTS,
  figureRows,
  parseRestartResult,
  readRestartRequest,
  refusalSentence,
  restartAuditName,
  restartCommand,
  restartVariables,
  secondsLabel,
  stalledHint,
  stateTone,
  tookLabel,
  writeBehind,
  type QueuesRestartPart,
} from "./gateway-restart.ts";
import type { Health } from "./health-types.ts";

// ---- the copy ----

const QUEUES_PARTS: QueuesRestartPart[] = ["persist", "db", "kafka-router", "kafka-consumers", "vendor-feed", "vendor"];

test("every Queues part has its copy, every field filled", () => {
  assert.deepEqual(Object.keys(RESTART_COPY).sort(), [...QUEUES_PARTS].sort());
  for (const part of QUEUES_PARTS) {
    const c = RESTART_COPY[part];
    for (const [k, v] of Object.entries(c)) {
      if (typeof v === "string") {
        assert.ok(v.trim().length > 0, `${part}.${k} is empty`);
      }
    }
    assert.ok(c.command.startsWith(`fireflo restart ${part}`), `${part}: the command names the part`);
    assert.ok(c.question.endsWith("?"), `${part}: the confirmation asks`);
  }
});

test("the copy says the labels the mockup shows", () => {
  assert.equal(RESTART_COPY.persist.label, "Restart writers");
  assert.equal(RESTART_COPY.db.label, "Reconnect pool");
  assert.equal(RESTART_COPY["kafka-router"].label, "Restart router");
  assert.equal(RESTART_COPY["kafka-consumers"].label, "Restart consumers");
  assert.equal(RESTART_COPY["vendor-feed"].label, "Reset feed");
  assert.equal(RESTART_COPY.vendor.label, "Rebind");
});

test("only Rebind drops binds, and its help and facts say so", () => {
  for (const part of QUEUES_PARTS) {
    assert.equal(RESTART_COPY[part].dropsBinds, part === "vendor", part);
  }
  assert.match(RESTART_COPY.vendor.help, /binds drop/);
  assert.match(RESTART_COPY.vendor.vendorBinds, /drop/);
  for (const part of QUEUES_PARTS.filter((p) => p !== "vendor")) {
    assert.match(RESTART_COPY[part].help, /Binds stay up|binds stay up/, `${part}: the help says binds stay up`);
    assert.match(RESTART_COPY[part].customerBinds, /^Not dropped/);
    assert.match(RESTART_COPY[part].vendorBinds, /^Not dropped/);
  }
});

test("persist promises the local log; db explains the hard option in text", () => {
  assert.match(RESTART_COPY.persist.kept, /local log/);
  assert.match(RESTART_COPY.persist.help, /stalled/);
  assert.match(RESTART_COPY.db.help, /hard/);
  assert.match(HARD_HELP, /busy|running/);
  assert.match(RESTART_COPY.db.whatHappens, /lease lane is left alone/);
});

test("restartCommand adds the target", () => {
  assert.equal(restartCommand("persist"), "fireflo restart persist");
  assert.equal(restartCommand("persist", "dlr-store"), "fireflo restart persist dlr-store");
  assert.equal(restartCommand("vendor", " smppclient.optus "), "fireflo restart vendor smppclient.optus");
});

// ---- the request ----

test("an unknown part is refused with the list", () => {
  const r = readRestartRequest({ component: "listener" });
  assert.equal(r.ok, false);
  assert.match(!r.ok ? r.error : "", /Unknown part 'listener'/);
  assert.match(!r.ok ? r.error : "", new RegExp(RESTART_PARTS.join(", ")));
});

test("not a body, not an object", () => {
  assert.equal(readRestartRequest(null).ok, false);
  assert.equal(readRestartRequest([]).ok, false);
  assert.equal(readRestartRequest("persist").ok, false);
});

test("a vendor part needs its vendor", () => {
  for (const component of ["vendor", "vendor-feed"]) {
    const r = readRestartRequest({ component });
    assert.equal(r.ok, false, component);
    assert.match(!r.ok ? r.error : "", /needs the vendor/);
    assert.equal(readRestartRequest({ component, target: "  " }).ok, false, `${component}: blank is none`);
    const ok = readRestartRequest({ component, target: " smppclient.optus " });
    assert.deepEqual(ok, { ok: true, request: { component, target: "smppclient.optus", hard: false } });
  }
});

test("persist takes a known stream or none", () => {
  assert.deepEqual(readRestartRequest({ component: "persist" }), {
    ok: true,
    request: { component: "persist", target: null, hard: false },
  });
  for (const s of PERSIST_STREAMS) {
    assert.equal(readRestartRequest({ component: "persist", target: s }).ok, true, s);
  }
  assert.equal(readRestartRequest({ component: "persist", target: "receipts" }).ok, false);
});

test("db and the kafka parts take no target; only db is hard", () => {
  for (const component of ["db", "kafka-router", "kafka-consumers", "config"]) {
    assert.equal(readRestartRequest({ component, target: "x" }).ok, false, component);
  }
  assert.deepEqual(readRestartRequest({ component: "db", hard: true }), {
    ok: true,
    request: { component: "db", target: null, hard: true },
  });
  assert.equal(readRestartRequest({ component: "persist", hard: true }).ok, false);
  assert.equal(readRestartRequest({ component: "db", hard: "yes" }).ok, false);
  assert.equal(readRestartRequest({ component: "vendor", target: 7 }).ok, false);
  assert.equal(readRestartRequest({ component: "vendor", target: "v".repeat(201) }).ok, false);
});

test("the variables carry the operator as by, hard only for db", () => {
  assert.deepEqual(restartVariables({ component: "db", target: null, hard: true }, "admin@x"), {
    component: "db",
    target: null,
    hard: true,
    by: "admin@x",
  });
  assert.equal(restartVariables({ component: "persist", target: "cdr", hard: false }, "a").hard, null);
  assert.equal(restartAuditName({ component: "vendor", target: "smppclient.optus" }), "vendor smppclient.optus");
  assert.equal(restartAuditName({ component: "persist", target: null }), "persist");
});

// ---- the answer ----

const PERSIST_FULL = {
  component: "persist",
  target: null,
  ok: true,
  tookMs: 3400,
  detail: "Writers replaced: cdr, dlr-store, unpushed.",
  results: { cdr: "replaced", "dlr-store": "replaced", n: 3 },
  before: {
    depth: 442545,
    lagSeconds: 372,
    writeRate: 0,
    writer: "stalled",
    streams: [
      { stream: "dlr-store", lane: 0, depth: 441341, spilled: true, stalledSeconds: 372 },
      { stream: "cdr", lane: 0, depth: 604, spilled: false, stalledSeconds: 0 },
      { stream: "cdr", lane: 1, depth: 600, spilled: false, stalledSeconds: 0 },
    ],
  },
  after: {
    depth: 992,
    lagSeconds: 0.3,
    writeRate: 16011,
    writer: "ok",
    streams: [
      { stream: "cdr", lane: 0, depth: 500, spilled: false, stalledSeconds: 0 },
      { stream: "cdr", lane: 1, depth: 480, spilled: false, stalledSeconds: 0 },
      { stream: "dlr-store", lane: 0, depth: 12, spilled: false, stalledSeconds: 0 },
    ],
  },
};

test("a full persist answer parses, lanes summed by stream in stream order", () => {
  const r = parseRestartResult(PERSIST_FULL);
  assert.equal(r.ok, true);
  assert.equal(r.tookMs, 3400);
  assert.equal(r.results.n, "3");
  assert.equal(tookLabel(r.tookMs), "3.4 s");
  const rows = figureRows(r);
  const by = new Map(rows.map((x) => [x.key, x]));
  assert.deepEqual(by.get("writer"), { key: "writer", label: "Writer", before: "stalled", after: "ok", state: true });
  assert.deepEqual(rows.filter((x) => x.key.endsWith("-depth")).map((x) => x.key), ["cdr-depth", "dlr-store-depth"]);
  assert.equal(by.get("cdr-depth")?.before, (1204).toLocaleString());
  assert.equal(by.get("dlr-store-state")?.before, "stalled");
  assert.equal(by.get("dlr-store-state")?.after, "ok");
  assert.equal(by.get("rate")?.after, `${(16011).toLocaleString()} rows/s`);
  assert.equal(by.get("lag")?.before, "6 m 12 s");
});

test("a persist answer narrowed to one stream shows that stream only", () => {
  const rows = figureRows(parseRestartResult({ ...PERSIST_FULL, target: "dlr-store" }));
  assert.ok(rows.some((x) => x.key === "dlr-store-depth"));
  assert.ok(!rows.some((x) => x.key === "cdr-depth"));
});

test("a partial answer: missing fields are dashes, a row missing on both sides is left out", () => {
  const r = parseRestartResult({ component: "db", ok: true, before: { active: 5, idle: 11 }, after: { active: 2 } });
  assert.equal(r.tookMs, null);
  assert.equal(r.detail, null);
  assert.equal(tookLabel(null), null);
  const rows = figureRows(r);
  assert.deepEqual(rows.map((x) => x.key), ["active", "idle"]);
  assert.equal(rows[1].after, "—");
});

test("db reads a nested pool as well as a flat one", () => {
  const rows = figureRows(parseRestartResult({
    component: "db",
    before: { pool: { active: 9, idle: 0, waiting: 4 }, probeMs: 1800 },
    after: { pool: { active: 1, idle: 8, waiting: 0 }, probeMs: 12 },
  }));
  const by = new Map(rows.map((x) => [x.key, x]));
  assert.equal(by.get("waiting")?.before, "4");
  assert.equal(by.get("probe")?.after, "12 ms");
});

test("kafka and vendor figures, nested backlog or flat", () => {
  const k = figureRows(parseRestartResult({ component: "kafka-router", before: { connected: true, routerLag: 900 }, after: { connected: true, routerLag: 0 } }));
  assert.deepEqual(k.map((x) => [x.key, x.before, x.after]), [["connected", "yes", "yes"], ["routerLag", "900", "0"]]);
  const v1 = figureRows(parseRestartResult({ component: "vendor", before: { bound: false, backlog: { depth: 104, state: "THROTTLING" } }, after: { bound: true, depth: 0, state: "OK" } }));
  const by = new Map(v1.map((x) => [x.key, x]));
  assert.equal(by.get("bound")?.before, "no");
  assert.equal(by.get("depth")?.before, "104");
  assert.equal(by.get("state")?.before, "throttling");
  assert.equal(by.get("state")?.after, "ok");
  assert.equal(by.get("state")?.state, true);
});

test("an absent or junk answer is not ok and has no rows", () => {
  for (const raw of [null, undefined, "x", 3, [], {}]) {
    const r = parseRestartResult(raw);
    assert.equal(r.ok, false);
    assert.deepEqual(r.before, {});
    assert.deepEqual(figureRows(r), []);
  }
  assert.equal(parseRestartResult({ ok: "true" }).ok, false, "only true is true");
  assert.deepEqual(figureRows(parseRestartResult({ component: "jobs", ok: true, before: {}, after: {} })), []);
});

test("state tones", () => {
  assert.equal(stateTone("ok"), "success");
  assert.equal(stateTone("stalled"), "warning");
  assert.equal(stateTone("REFUSING".toLowerCase()), "destructive");
  assert.equal(stateTone("whatever"), "outline");
});

test("a refusal keeps the gateway's sentence, and has one of its own without", () => {
  assert.equal(
    refusalSentence(409, "A restart of persist is already running; try again when it has finished."),
    "A restart of persist is already running; try again when it has finished."
  );
  assert.match(refusalSentence(403, null), /admins/);
  assert.match(refusalSentence(409, ""), /another restart/);
  assert.match(refusalSentence(0, undefined), /reach the panel/);
  assert.match(refusalSentence(502, null), /502/);
});

test("secondsLabel", () => {
  assert.equal(secondsLabel(null), "—");
  assert.equal(secondsLabel(0.3), "0.3 s");
  assert.equal(secondsLabel(42), "42 s");
  assert.equal(secondsLabel(372), "6 m 12 s");
  assert.equal(secondsLabel(3600 + 240), "1 h 4 m");
});

// ---- the write-behind block ----

const base = { observed_at: "2026-10-31T14:36:00Z" } as unknown as Health;

test("no persist_streams, no block: an older gateway", () => {
  assert.equal(writeBehind(null), null);
  assert.equal(writeBehind(base), null);
  assert.equal(writeBehind({ ...base, persist_streams: null }), null);
});

test("the streams summed, ordered, and a stalled one names itself", () => {
  const w = writeBehind({
    ...base,
    persist_writer: "stalled",
    persist_lag_seconds: 372,
    db_write_rate: 9880,
    db_admission: "OK",
    persist_streams: [
      { stream: "unpushed", lane: 0, depth: 0, spilled: false, stalled_seconds: 0 },
      { stream: "dlr-store", lane: 0, depth: 441341, spilled: true, stalled_seconds: 372 },
      { stream: "cdr", lane: 0, depth: 604, spilled: false, stalled_seconds: 0 },
      { stream: "cdr", lane: 1, depth: 600, spilled: false, stalled_seconds: 0 },
    ],
  });
  assert.ok(w);
  assert.deepEqual(w.streams.map((s) => [s.stream, s.depth, s.state, s.lanes]), [
    ["cdr", 1204, "ok", 2],
    ["dlr-store", 441341, "stalled", 1],
    ["unpushed", 0, "ok", 1],
  ]);
  assert.equal(w.stalled, true);
  assert.equal(w.admitting, true);
  assert.equal(w.streams[1].what, "receipts awaiting a match");
  assert.equal(stalledHint(w), "dlr-store has not written for 6 m 12 s");
});

test("persist_writer stalled alone still says stalled; a spilled lane reads from log; fields may be missing", () => {
  const w = writeBehind({
    ...base,
    persist_writer: "stalled",
    persist_streams: [{ stream: "cdr", spilled: true }, { stream: "" }],
  });
  assert.ok(w);
  assert.equal(w.stalled, true);
  assert.deepEqual(w.streams.map((s) => [s.stream, s.depth, s.state]), [["cdr", 0, "from log"]]);
  assert.equal(w.lagSeconds, null);
  assert.equal(w.writeRate, null);
  assert.equal(stalledHint(w), "a writer has stopped writing");
  const ok = writeBehind({ ...base, persist_writer: "ok", persist_streams: [] });
  assert.equal(ok?.stalled, false);
});
