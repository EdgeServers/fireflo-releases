import { FINAL_STATES, RANGES } from "./cdr-request.ts";
import { validateRange } from "./date-range.ts";
import { addDays, dayKeyIn, dayStartIn } from "./datetime.ts";

/**
 * The portal's message filters, as the browser holds them and as they travel.
 *
 * <p>A separate form from the operator's {@link CdrFilterForm} rather than a reuse of it. The
 * operator's carries `vendor` and an attempts switch, neither of which a customer may set — vendor
 * is our buy side, and "every attempt and segment" is a diagnostic view that makes a customer's own
 * volume look inflated. Sharing the type would put both on this page and rely on the component not
 * rendering them.
 *
 * <p>What it does share is the vocabulary: `RANGES` and `FINAL_STATES` come from `cdr-request.ts`,
 * so the two pages cannot drift on what a period or an outcome is.
 *
 * <p>Database-free, so a client component can import it.
 */

/** The value of `range` that means "the two date boxes below are what I mean". */
export const CUSTOM_RANGE = "custom";

/**
 * The presets offered, in order.
 *
 * <p>`all` is in `RANGES` and deliberately not here: the route refuses an unbounded window on a
 * customer-facing endpoint, and offering a choice that always returns an error is worse than not
 * offering it.
 */
export const MIS_RANGES = ["1h", "24h", "7d", "30d"] as const;

export interface MisFilterForm {
  /** One of {@link MIS_RANGES}, or {@link CUSTOM_RANGE}. */
  range: string;
  /** `YYYY-MM-DD`, and only meaningful when `range` is custom. */
  since: string;
  until: string;
  account: string;
  dest: string;
  source: string;
  msgId: string;
  /** A phrase from the message text. Finds nothing unless the gateway is recording content. */
  text: string;
  outcome: string;
  product: string;
}

export const EMPTY_MIS_FILTERS: MisFilterForm = {
  range: "1h",
  since: "",
  until: "",
  account: "",
  dest: "",
  source: "",
  msgId: "",
  text: "",
  outcome: "",
  product: "",
};

/**
 * The text filters, as [query parameter, form field].
 *
 * <p>One list, so the two directions cannot disagree — and the parameter names are the ones
 * `parseFilters` reads, which is the whole point of writing them down once.
 *
 * <p><strong>`dest`, not `to`.</strong> The page this replaces sent `to`, `parseFilters` has always
 * read `dest`, and the box therefore did nothing at all: typing a number returned every message and
 * looked like a filter that had matched broadly.
 */
const TEXT_FIELDS: [string, keyof MisFilterForm][] = [
  ["account", "account"],
  ["dest", "dest"],
  ["source", "source"],
  ["msgId", "msgId"],
  //the same parameter the operator page uses, so one vocabulary covers both surfaces
  ["text", "text"],
  ["outcome", "outcome"],
  ["product", "product"],
];

/**
 * Why this form cannot be submitted, in a sentence the customer can act on.
 *
 * @return null when it is fine
 */
export function validateMisFilters(form: MisFilterForm): string | null {
  if (form.range === CUSTOM_RANGE) {
    return validateRange(form.since, form.until);
  }
  if (!(form.range in RANGES)) {
    return `Unknown period '${form.range}'.`;
  }
  if (form.outcome && !isMisOutcome(form.outcome)) {
    return `Unknown outcome '${form.outcome}'.`;
  }
  return null;
}

export function isMisOutcome(value: string): boolean {
  return value === "PENDING" || (FINAL_STATES as readonly string[]).includes(value);
}

/**
 * The form as a query string, carrying only what is set.
 *
 * <p>A custom window is sent as `since` and `until` and **no** `range`. `parseFilters` defaults
 * `range` to 24h and derives a `since` from it, then lets an explicit `since` overwrite that — so
 * both arrive at the same answer, and leaving `range` off keeps the URL honest about what was
 * actually chosen.
 *
 * <p>The days are the display zone's: midnight to midnight in the zone the table's times are shown
 * in, so a customer who picks the 15th sees messages stamped the 15th and no others. They travel as
 * the two exact instants, so the server needs no zone of its own.
 *
 * <p>Call {@link validateMisFilters} first. This does not throw on a bad date; it omits it, which on
 * a custom range would quietly widen the window to the 24-hour default.
 *
 * @param zone the display zone
 */
export function toMisQuery(form: MisFilterForm, zone: string): URLSearchParams {
  const params = new URLSearchParams();

  if (form.range === CUSTOM_RANGE) {
    const since = validDay(form.since) ? dayStartIn(form.since.trim(), zone) : null;
    const until = validDay(form.until) ? dayStartIn(addDays(form.until.trim(), 1), zone) : null;
    if (since && until) {
      params.set("since", since.toISOString());
      params.set("until", until.toISOString());
    }
  } else {
    params.set("range", form.range);
  }

  for (const [param, field] of TEXT_FIELDS) {
    const value = form[field].trim();
    if (value) {
      params.set(param, value);
    }
  }
  return params;
}

/**
 * A query string back into a form, so a bookmarked or shared link opens on the window it named.
 *
 * <p>The end date is converted back through {@link inclusiveEndFromExclusive}: `until` on the wire
 * is the start of the day *after* the one that was asked for, and reading it straight back would
 * put the 16th in a box somebody typed the 15th into — and push the window one day further out on
 * every reload.
 */
export function fromMisQuery(params: URLSearchParams, zone: string): MisFilterForm {
  const form = { ...EMPTY_MIS_FILTERS };

  const since = params.get("since");
  const until = params.get("until");
  if (since && until) {
    const from = new Date(since);
    const to = new Date(until);
    if (!Number.isNaN(from.getTime()) && !Number.isNaN(to.getTime())) {
      form.range = CUSTOM_RANGE;
      form.since = dayKeyIn(from, zone);
      form.until = addDays(dayKeyIn(to, zone), -1);
    }
  } else {
    const range = params.get("range");
    if (range && (MIS_RANGES as readonly string[]).includes(range)) {
      form.range = range;
    }
  }

  for (const [param, field] of TEXT_FIELDS) {
    const value = params.get(param);
    if (value != null) {
      form[field] = value;
    }
  }
  //an outcome that is not one of ours is dropped rather than carried: the route would refuse it
  //with a 400, and a link that lands on an error page is not a link worth honouring
  if (form.outcome && !isMisOutcome(form.outcome)) {
    form.outcome = "";
  }
  return form;
}

/** Whether anything beyond the period is set — for a Clear button that knows when to appear. */
export function hasActiveMisFilters(form: MisFilterForm): boolean {
  return TEXT_FIELDS.some(([, field]) => form[field].trim() !== "");
}

/** A real calendar day as a date input holds it: `2026-02-31` is not one. */
function validDay(value: string): boolean {
  const v = value.trim();
  return /^\d{4}-\d{2}-\d{2}$/.test(v) && addDays(v, 0) === v;
}
