import { RoutingClient } from "@/components/RoutingClient";

/**
 * One client owns the page now: the health strip, the tabs and the table cards share state (the
 * Advanced switch, the editor) that a server component cannot hold, and the three tools that used
 * to sit in a rail are tabs inside it.
 */
export default function RoutingPage() {
  return <RoutingClient />;
}
