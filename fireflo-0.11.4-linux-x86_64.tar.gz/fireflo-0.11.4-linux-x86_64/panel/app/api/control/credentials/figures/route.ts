import { NextRequest, NextResponse } from "next/server";
import { isConfigured, query } from "@/lib/metrics-db";
import { OUTCOME_LATERAL } from "@/lib/metrics-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET /api/control/credentials/figures?ids=a,b,c
 *
 * <p>Today's traffic per login, for the login cards: sent, refused, and when it was last seen. One
 * query over the call records for the system ids named, so a page of six logins costs one round
 * trip rather than six. Absent a metrics database the page shows dashes -- the cards do not need
 * these numbers to be useful, they are the glance that says "this one is live".
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  if (!isConfigured()) {
    return NextResponse.json({ data: {} });
  }
  const ids = (new URL(req.url).searchParams.get("ids") ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 200);
  if (!ids.length) {
    return NextResponse.json({ data: {} });
  }
  try {
    const rows = await query<{ system_id: string; sent: string; refused: string; last_seen: Date | null }>(
      `SELECT s.system_id,
              COUNT(*) AS sent,
              COUNT(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED')) AS refused,
              MAX(s.submitted_at) AS last_seen
         FROM cdr_submit s${OUTCOME_LATERAL}
        WHERE s.system_id = ANY($1::text[]) AND s.submitted_at > now() - interval '24 hours'
        GROUP BY s.system_id`,
      [ids]
    );
    const data: Record<string, { sent: number; refused: number; lastSeen: string | null }> = {};
    for (const r of rows) {
      data[r.system_id] = {
        sent: Number(r.sent),
        refused: Number(r.refused),
        lastSeen: r.last_seen ? new Date(r.last_seen).toISOString() : null,
      };
    }
    return NextResponse.json({ data });
  } catch (err) {
    //the figures are a glance, not the page: a failed aggregate is dashes, not a 500
    console.error("credential figures", err);
    return NextResponse.json({ data: {} });
  }
}
