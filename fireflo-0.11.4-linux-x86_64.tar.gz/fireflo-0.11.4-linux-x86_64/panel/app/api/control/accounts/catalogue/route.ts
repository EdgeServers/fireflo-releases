import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { listAccounts, listOrphanAccounts, saveAccount } from "@/lib/accounts";
import { validateAccount } from "@/lib/account-types";
import { logOperatorEvent } from "@/lib/access-log";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { passwordProblem } from "@/lib/password-policy";
import { requireOperator } from "@/lib/require-operator";
import { DuplicateUserError, setCustomerPassword } from "@/lib/users";

const TABLES = "app_account";

/**
 * The account catalogue, and the ids in use that are not in it.
 *
 * <p>Under `/accounts/catalogue` rather than at `/accounts`, which already means something else: the
 * traffic view, grouped by account, system id and product from call records. One is who is
 * provisioned, the other is who actually sent, and conflating the two routes would conflate the two
 * ideas.
 *
 * <p>Orphans come back with the list because a catalogue that silently omits the accounts nobody has
 * named yet would be worse than no catalogue — there is no foreign key making the two agree.
 *
 */
export async function GET(): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  try {
    const [accounts, orphans] = await Promise.all([listAccounts(), listOrphanAccounts()]);
    return NextResponse.json({ data: { accounts, orphans } });
  } catch (err) {
    return configFailed("account catalogue", err);
  }
}

/**
 * Creates or updates one account.
 *
 * <p>One verb for both, because an id routinely exists as a string before it exists as a row.
 * Adopting an orphan and renaming a catalogued account are the same write, and making the caller
 * choose would mean it had to know which case it was in.
 */
export async function PUT(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const input = body as {
    id?: unknown; label?: unknown; description?: unknown; email?: unknown; enabled?: unknown;
    resells?: unknown; parentAccountId?: unknown; portalPassword?: unknown;
  };
  const email = typeof input.email === "string" ? input.email : null;
  const portalPassword = typeof input.portalPassword === "string" && input.portalPassword ? input.portalPassword : null;
  if (portalPassword) {
    if (!email?.trim()) {
      return NextResponse.json({ error: "A portal password needs an email address to belong to." }, { status: 400 });
    }
    const weak = passwordProblem(portalPassword, email);
    if (weak) {
      return NextResponse.json({ error: weak }, { status: 400 });
    }
  }
  const invalid = validateAccount({
    id: typeof input.id === "string" ? input.id : "",
    email,
    enabled: input.enabled !== false,
  });
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }

  try {
    await saveAccount({
      id: String(input.id).trim(),
      label: typeof input.label === "string" ? input.label : null,
      description: typeof input.description === "string" ? input.description : null,
      email,
      enabled: input.enabled !== false,
      resells: input.resells === true,
      //the shape of the tree is held by the database -- a composite foreign key forces a parent to
      //be a reseller and a CHECK caps it at two levels -- so nothing is re-validated here. A second
      //implementation in TypeScript could only disagree with the one that actually holds, and would
      //still lose the race where the parent stops reselling between the check and the write
      parentAccountId: typeof input.parentAccountId === "string" ? input.parentAccountId : null,
    });
    if (portalPassword) {
      const accountId = String(input.id).trim();
      await setCustomerPassword(accountId, email!, portalPassword);
      const admin = await requireOperator();
      void logOperatorEvent({
        event: "user_password_set",
        actor: admin.name,
        userId: admin.userId,
        ip: clientIp(req),
        userAgent: clientUserAgent(req),
        detail: { subject: email!.trim(), account: accountId },
      });
    }
    return NextResponse.json({ data: { id: String(input.id).trim() } });
  } catch (err) {
    if (err instanceof DuplicateUserError) {
      return NextResponse.json({ error: `${err.message} That login belongs to another account.` }, { status: 409 });
    }
    //`uq_app_account_email` is case-insensitive, so the clash may not look like one to whoever hit
    //it. Said in words rather than letting a constraint name reach the interface
    if ((err as { code?: string })?.code === "23505") {
      return NextResponse.json(
        {
          error: `'${email}' is already the address on another account. An email identifies one `
            + "account, ignoring case, so that a sign-in link can tell which one it is for.",
        },
        { status: 409 }
      );
    }
    //saveAccount already turned the two-level constraints into a sentence an operator can act on.
    //Letting configFailed swallow that into "could not save account" would throw away the only part
    //of the message that says what to do next
    if (err instanceof Error && /reseller|two levels/i.test(err.message)) {
      return NextResponse.json({ error: err.message }, { status: 409 });
    }
    return configFailed("save account", err);
  }
}
