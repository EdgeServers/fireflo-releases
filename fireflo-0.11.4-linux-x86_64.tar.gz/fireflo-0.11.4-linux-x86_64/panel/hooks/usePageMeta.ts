"use client";
import { usePathname } from "next/navigation";

/**
 * Title and subtitle for the header bars, derived from the route.
 *
 * <p>The `/cp` prefix is stripped once, at the top, rather than written into every entry below.
 * This table is about which operator SECTION you are in; `/cp` is where the panel happens to be
 * mounted, which is a deployment fact and not part of that question.
 *
 * <p>A table rather than an if-chain, and one entry per sidebar item: the chain this replaced knew
 * ten sections, so the other fourteen routes -- Routing, Error codes, Filters, Security, every
 * report -- silently fell through to "Overview / Traffic and delivery across the gateway" and looked
 * like a styling bug. The titles are the sidebar labels, so the bar and the nav never disagree.
 * Longest prefix wins, which is what lets `/assets/headers` and `/assets/templates` differ.
 */
const SECTIONS: [prefix: string, title: string, subtitle: string][] = [
  ["/vendors", "Vendors", "Connections out, with what each one carried"],
  ["/servers", "Servers", "Listeners customers bind to"],
  ["/health", "Live health", "Binds, queues and throughput, read from the running gateway"],
  ["/metrics", "Runtime", "Memory, CPU and request handling inside the gateway process"],
  ["/products", "Products", "The tariffs a customer's bind can ask for by system_type"],
  ["/pricing", "Pricing", "What we pay each vendor, and what each account pays us"],
  ["/cdrs", "Messages", "Individual call records, with filters and downloadable exports"],
  ["/accounts", "Accounts", "Who is sending, what they spend, and their credit"],
  ["/revenue", "Revenue", "Cost, price and margin by account and product"],
  ["/diagnostics", "Logs", "Logs and configuration read from the machine running the gateway"],
  ["/routing", "Routing", "Which vendor each message goes to, and why"],
  ["/security", "Security", "Who signed in, from where, and what was refused"],
  ["/gateway", "Gateway", "Settings for the whole gateway, and what it has adopted"],
  ["/error-codes", "Error codes", "What a carrier's failure codes become on the customer's receipt"],
  ["/filters", "Filters", "Named conditions that routing and pricing rules reuse"],
  ["/tlvs", "TLVs", "The optional SMPP parameters this gateway knows by name"],
  ["/assets/headers", "Headers", "Sender IDs and who may use them"],
  ["/assets/templates", "Templates", "Message text approved in advance"],
  ["/rejected", "Refused", "Messages the gateway would not send, and why"],
  ["/access-log", "Access log", "Every sign-in, successful or not, on both doors"],
  ["/queues", "Queues", "What is waiting inside the gateway, and for what"],
  ["/receipts", "Receipts", "How quickly and how completely each vendor confirms delivery"],
  ["/usage", "Usage", "Traffic and delivery across every account"],
  ["/users", "Users", "Who can open this panel, and as what"],
];

export function usePageMeta(): { title: string; subtitle?: string } {
  //|| "/" so that /cp itself, whose remainder is the empty string, still reaches the default below
  const pathname = usePathname().replace(/^\/cp/, "") || "/";
  let best: (typeof SECTIONS)[number] | undefined;
  for (const entry of SECTIONS) {
    if (pathname.startsWith(entry[0]) && (!best || entry[0].length > best[0].length)) {
      best = entry;
    }
  }
  return best
    ? { title: best[1], subtitle: best[2] }
    : { title: "Overview", subtitle: "Traffic and delivery across the gateway" };
}
