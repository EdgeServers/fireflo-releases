/**
 * Rows the suite writes for itself. Two layers:
 *
 *   - `seedBaseline(db, env)` — run once by global setup after bootstrap: the accounts, logins,
 *     vendors, listeners, prices and settings every epic assumes exist. Names start `qa-`.
 *   - the `seed` fixture — per test, worker-prefixed (`qa-w<n>-…`) rows that are removed in reverse
 *     order when the test ends, so four panel workers never see each other's data.
 *
 * Everything here is plain SQL against the gateway's schema (V1.45.0 baseline and later). It
 * deliberately does not go through the panel's lib/ writers: the suite must observe the panel, not
 * borrow its code paths, or a panel bug would be baked into the fixture that is meant to catch it.
 */
import { randomBytes } from "node:crypto";
import type { Db } from "./db";
import type { E2EEnv } from "./env";

export interface AccountSpec {
  id: string;
  label?: string;
  email?: string | null;
  enabled?: boolean;
  resells?: boolean;
  parentAccountId?: string | null;
}

export interface CredentialSpec {
  type?: "SMPP" | "HTTP";
  systemId: string;
  password?: string;
  apiKey?: string | null;
  accountId: string | null;
  product?: string | null;
  allowedIps?: string[] | null;
  allowedProducts?: string[] | null;
  enabled?: boolean;
}

export interface BalanceSpec {
  accountId: string;
  /** minor units ×10⁴ — 100.0000 is 1_000_000 */
  balance?: number;
  currency?: string;
  enabled?: boolean;
  billingMode?: "PREPAID" | "POSTPAID";
  creditLimit?: number;
}

export interface CdrSpec {
  accountId: string;
  systemId?: string;
  product?: string;
  ingress?: "smpp" | "http";
  inGateway?: string;
  vendor?: string;
  from?: string;
  to?: string;
  /** minor units ×10⁴ */
  price?: number;
  cost?: number;
  /** DELIVRD | UNDELIV | EXPIRED | none (still pending) */
  outcome?: "DELIVRD" | "UNDELIV" | "EXPIRED" | "PENDING";
  submittedAt?: Date;
  body?: string | null;
}

export async function insertAccount(db: Db, a: AccountSpec): Promise<void> {
  await db.q(
    `INSERT INTO app_account (id, label, description, enabled, email, resells, parent_account_id)
     VALUES ($1, $2, NULL, $3, $4, $5, $6)
     ON CONFLICT (id) DO UPDATE SET label = EXCLUDED.label, enabled = EXCLUDED.enabled, email = EXCLUDED.email,
       resells = EXCLUDED.resells, parent_account_id = EXCLUDED.parent_account_id`,
    [a.id, a.label ?? a.id, a.enabled ?? true, a.email ?? null, a.resells ?? false, a.parentAccountId ?? null],
  );
  // since V1.52.0 the address that may sign in is an app_user row; the panel's account editor
  // creates one the same way (ensureCustomerUser), so the seed does too
  if (a.email) {
    await db.q(
      `INSERT INTO app_user (email, role, account_id) VALUES ($1, 'customer', $2)
       ON CONFLICT (lower(email)) DO UPDATE SET account_id = EXCLUDED.account_id, enabled = true`,
      [a.email, a.id],
    );
  }
}

export async function insertCredential(db: Db, c: CredentialSpec): Promise<number> {
  const row = await db.one<{ id: string }>(
    `INSERT INTO app_credential (type, system_id, password, api_key, account_id, product, allowed_ips, allowed_products, enabled)
     VALUES ($1, $2, $3, $4, $5, $6, $7::text[], $8::text[], $9) RETURNING id::text`,
    [c.type ?? "SMPP", c.systemId, c.password ?? null, c.apiKey ?? null, c.accountId, c.product ?? null, c.allowedIps ?? null, c.allowedProducts ?? null, c.enabled ?? true],
  );
  return Number(row.id);
}

export async function upsertBalance(db: Db, b: BalanceSpec): Promise<void> {
  await db.q(
    `INSERT INTO account_balance (account_id, balance, reserved, currency, enabled, billing_mode, credit_limit)
     VALUES ($1, $2, 0, $3, $4, $5, $6)
     ON CONFLICT (account_id) DO UPDATE SET balance = EXCLUDED.balance, reserved = 0, currency = EXCLUDED.currency,
       enabled = EXCLUDED.enabled, billing_mode = EXCLUDED.billing_mode, credit_limit = EXCLUDED.credit_limit`,
    [b.accountId, b.balance ?? 0, b.currency ?? "AUD", b.enabled ?? true, b.billingMode ?? "PREPAID", b.creditLimit ?? 0],
  );
}

export async function setConfig(db: Db, key: string, value: string | null): Promise<string | null> {
  const prior = await db.maybe<{ value: string }>("SELECT value FROM app_config WHERE key = $1", [key]);
  if (value === null) await db.q("DELETE FROM app_config WHERE key = $1", [key]);
  else await db.q(
    `INSERT INTO app_config (key, value, enabled, updated_at) VALUES ($1, $2, true, now())
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, enabled = true, updated_at = now()`,
    [key, value],
  );
  return prior?.value ?? null;
}

/** One message's call records, as the gateway would have written them. */
export async function insertCdr(db: Db, c: CdrSpec): Promise<string> {
  const id = randomBytes(16).toString("hex").replace(/^(.{8})(.{4})(.{4})(.{4})(.{12})$/, "$1-$2-$3-$4-$5");
  const at = c.submittedAt ?? new Date();
  const outcome = c.outcome ?? "DELIVRD";
  await db.q(
    `INSERT INTO cdr_submit (gateway_msg_id, part_no, part_count, retry_count, account_id, system_id, product, ingress, in_gateway,
        vendor, operator_msg_id, source_addr, dest_addr, price, price_currency, cost, cost_currency, billed_units, cost_units,
        margin_status, accepted_at, submitted_at, body, registered_delivery, submit_status, msg_type)
     VALUES ($1, 1, 1, 0, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, 'AUD', $12, 'AUD', 1, 1, 'CALCULATED', $13, $13, $14, 1, 0, 0)`,
    [id, c.accountId, c.systemId ?? `${c.accountId}-smpp`, c.product ?? "", c.ingress ?? "smpp",
      c.inGateway ?? "smppserver.smpp", c.vendor ?? "smppclient.qa-sim1", `op-${id.slice(0, 8)}`,
      c.from ?? "QATEST", c.to ?? "61400000001", c.price ?? 100, c.cost ?? 50, at, c.body ?? null],
  );
  if (outcome !== "PENDING") {
    // final_state is the gateway's vocabulary (CdrFinal.DELIVERED/FAILED/EXPIRED); dlr_state is the
    // SMPP message_state number the receipt carried (2 DELIVERED, 3 EXPIRED, 5 UNDELIVERABLE)
    const state = outcome === "DELIVRD" ? "DELIVERED" : outcome === "UNDELIV" ? "FAILED" : "EXPIRED";
    const dlrState = outcome === "DELIVRD" ? 2 : outcome === "UNDELIV" ? 5 : 3;
    await db.q(
      `INSERT INTO cdr_final (gateway_msg_id, part_no, operator_msg_id, final_state, dlr_state, err_code, final_at)
       VALUES ($1, 1, $2, $3, $4, $5, $6)`,
      [id, `op-${id.slice(0, 8)}`, state, dlrState, outcome === "DELIVRD" ? "000" : "001", new Date(at.getTime() + 2000)],
    );
  }
  return id;
}

/** The accounts and logins every panel epic can rely on. Gateway-side rows join in phase 4. */
export const BASELINE = {
  accounts: {
    a: "qa-acct-a",
    b: "qa-acct-b",
    portal: "qa-portal-a",
    reseller: "qa-reseller-r",
    child: "qa-child-c1",
  },
  emails: {
    portal: "qa-portal-a@fireflo.test",
    reseller: "qa-reseller-r@fireflo.test",
    child: "qa-child-c1@fireflo.test",
  },
  /**
   * SMPP and HTTP logins, one pair per account that sends. SMPP bounds them: a system_id is at most
   * 15 characters and a password at most 8 — longer ones cannot cross the wire.
   */
  logins: {
    a: { systemId: "qa-acct-a-smpp", password: "qaApw001" },
    aHttp: { systemId: "qa-acct-a-http", password: "qa-acct-a-http-pw-1" },
    b: { systemId: "qa-acct-b-smpp", password: "qaBpw001" },
    portal: { systemId: "qa-portal-smpp", password: "qaPpw001" },
    portalHttp: { systemId: "qa-portal-http", password: "qa-portal-http-pw-1" },
    child: { systemId: "qa-child-smpp", password: "qaCpw001" },
  },
  product: "standard",
  currency: "AUD",
  /** [*] price and vendor cost, minor units ×10⁴ */
  price: 100,
  cost: 50,
} as const;

export async function seedBaseline(db: Db, _env: E2EEnv): Promise<void> {
  const A = BASELINE.accounts;
  const E = BASELINE.emails;
  const L = BASELINE.logins;
  await insertAccount(db, { id: A.a, label: "QA account A" });
  await insertAccount(db, { id: A.b, label: "QA account B" });
  await insertAccount(db, { id: A.portal, label: "QA portal customer", email: E.portal });
  await insertAccount(db, { id: A.reseller, label: "QA reseller", email: E.reseller, resells: true });
  await insertAccount(db, { id: A.child, label: "QA reseller child", email: E.child, parentAccountId: A.reseller });

  await db.q(
    `INSERT INTO app_product (name, label, description, enabled, whitelist_enabled) VALUES ($1, 'Standard', 'QA product', true, true)
     ON CONFLICT (name) DO NOTHING`,
    [BASELINE.product],
  );

  await insertCredential(db, { systemId: L.a.systemId, password: L.a.password, accountId: A.a, product: BASELINE.product });
  await insertCredential(db, { type: "HTTP", systemId: L.aHttp.systemId, password: L.aHttp.password, accountId: A.a, product: BASELINE.product });
  await insertCredential(db, { systemId: L.b.systemId, password: L.b.password, accountId: A.b, product: BASELINE.product });
  await insertCredential(db, { systemId: L.portal.systemId, password: L.portal.password, accountId: A.portal, product: BASELINE.product });
  await insertCredential(db, { type: "HTTP", systemId: L.portalHttp.systemId, password: L.portalHttp.password, accountId: A.portal, product: BASELINE.product });
  await insertCredential(db, { systemId: L.child.systemId, password: L.child.password, accountId: A.child, product: BASELINE.product });

  for (const id of [A.a, A.b, A.portal, A.reseller, A.child]) {
    await upsertBalance(db, { accountId: id, balance: 1_000_000, currency: BASELINE.currency }); // 100.0000
  }

  // the platform currency, the money scale and the poll interval the whole suite relies on
  await setConfig(db, "smsg.rates.currency", BASELINE.currency);
  await setConfig(db, "smsg.money.scale", "4");
  await setConfig(db, "smsg.config.db.poll.seconds", "2");
  // the [*] price every account inherits, and the vendor cost, so margins are computable
  await db.q(
    `INSERT INTO app_rate_rule (scope, seq, amount, product, currency, label, enabled)
     VALUES ('[*]', 1, $1, NULL, $2, 'qa baseline price', true)`,
    [(BASELINE.price / 10_000).toFixed(4), BASELINE.currency],
  );
}

/**
 * Per-test seeding with automatic cleanup. `prefix` is `qa-w<worker>-` so parallel workers cannot
 * collide; `undo` runs in reverse order after the test.
 */
export interface Seed {
  prefix: string;
  name(base: string): string;
  account(spec: Partial<AccountSpec> & { id?: string }): Promise<string>;
  credential(spec: Omit<CredentialSpec, "systemId"> & { systemId?: string }): Promise<{ id: number; systemId: string; password: string }>;
  balance(spec: BalanceSpec): Promise<void>;
  /** set an app_config key for the test; the prior value is restored afterwards */
  config(key: string, value: string | null): Promise<void>;
  cdrs(spec: CdrSpec, n?: number): Promise<string[]>;
  /** register an arbitrary cleanup, run in reverse order */
  cleanup(fn: () => Promise<void>): void;
  /** run all cleanups now (the fixture does this automatically) */
  undo(): Promise<void>;
}

export function makeSeed(db: Db, workerIndex: number): Seed {
  const prefix = `qa-w${workerIndex}-`;
  const undo: (() => Promise<void>)[] = [];
  const rand = () => Math.random().toString(36).slice(2, 8);
  const seed: Seed = {
    prefix,
    name: (base) => (base.startsWith(prefix) ? base : prefix + base),
    async account(spec) {
      const id = seed.name(spec.id ?? `acct-${rand()}`);
      await insertAccount(db, { ...spec, id });
      undo.push(async () => {
        await db.q("DELETE FROM app_credential WHERE account_id = $1", [id]);
        await db.q("DELETE FROM account_balance WHERE account_id = $1", [id]);
        await db.q("DELETE FROM app_account WHERE id = $1", [id]);
      });
      return id;
    },
    async credential(spec) {
      // an SMPP system_id is at most 15 characters, so logins get a short name: w<worker><6 random>
      const systemId = spec.systemId ?? `w${workerIndex}${rand()}`;
      const password = spec.password ?? (spec.type === "HTTP" ? `pw-${rand()}${rand()}` : `p${rand()}`.slice(0, 8));
      const id = await insertCredential(db, { ...spec, systemId, password });
      undo.push(async () => { await db.q("DELETE FROM app_credential WHERE id = $1", [id]); });
      return { id, systemId, password };
    },
    async balance(spec) {
      const prior = await db.maybe<{ account_id: string }>("SELECT account_id FROM account_balance WHERE account_id = $1", [spec.accountId]);
      await upsertBalance(db, spec);
      if (!prior) undo.push(async () => { await db.q("DELETE FROM account_balance WHERE account_id = $1", [spec.accountId]); });
    },
    async config(key, value) {
      const prior = await setConfig(db, key, value);
      undo.push(async () => { await setConfig(db, key, prior); });
    },
    async cdrs(spec, n = 1) {
      const ids: string[] = [];
      for (let i = 0; i < n; i++) ids.push(await insertCdr(db, spec));
      undo.push(async () => {
        await db.q("DELETE FROM cdr_final WHERE gateway_msg_id = ANY($1)", [ids]);
        await db.q("DELETE FROM cdr_submit WHERE gateway_msg_id = ANY($1)", [ids]);
      });
      return ids;
    },
    cleanup: (fn) => { undo.push(fn); },
    async undo() {
      while (undo.length) {
        const fn = undo.pop()!;
        try { await fn(); } catch (e) { console.warn(`seed cleanup failed: ${e instanceof Error ? e.message : e}`); }
      }
    },
  };
  return seed;
}
