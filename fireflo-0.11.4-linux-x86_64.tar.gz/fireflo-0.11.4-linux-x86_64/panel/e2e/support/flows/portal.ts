/**
 * Customer-portal flows shared by EP-22 and EP-23: asking for a sign-in link, following one from
 * the SMTP spool, reading the outcome the verify page shows, signing out.
 */
import { expect } from "@playwright/test";
import type { APIRequestContext, Page } from "@playwright/test";
import { e2eEnv } from "../../fixtures/env";
import { mailbox } from "../../fixtures/sinks";

export const LINK_SENT_MESSAGE = "If that address is on an account, a sign-in link is on its way. It expires in 15 minutes.";
export const LINK_FAILED_MESSAGE = "That link did not work.";

/** POST /api/mis/login-link as the sign-in page does. */
export async function requestLoginLink(ctx: APIRequestContext, email: string, baseURL = e2eEnv().panelUrl) {
  const res = await ctx.post(`${baseURL}/api/mis/login-link`, { data: { email }, headers: { "content-type": "application/json" } });
  const body = (await res.json().catch(() => ({}))) as { message?: string; error?: string };
  return { status: res.status(), body, text: body.message ?? body.error ?? "" };
}

/** Ask for a link and wait for it to land in the spool. Returns the URL in the mail. */
export async function requestAndReceiveLink(ctx: APIRequestContext, email: string, baseURL?: string): Promise<{ link: string; status: number }> {
  const since = mailbox.mark();
  const { status } = await requestLoginLink(ctx, email, baseURL);
  const link = await mailbox.signInLink(since, email);
  return { link, status };
}

/** Open a sign-in link in a browser and report where it ended up. */
export async function followLink(page: Page, link: string): Promise<"signed-in" | "rejected"> {
  await page.goto(link);
  const failed = page.getByText(LINK_FAILED_MESSAGE);
  //the page no longer redeems on load -- a mail scanner would spend the token -- so press the
  //button; a link without a token shows the failure straight away and has no button to press
  const signIn = page.getByRole("button", { name: "Sign in" });
  await signIn.or(failed).first().waitFor({ state: "visible", timeout: 15_000 });
  if (await signIn.isVisible()) await signIn.click();
  await Promise.race([
    page.waitForURL(/\/overview/, { timeout: 15_000 }).catch(() => undefined),
    failed.waitFor({ state: "visible", timeout: 15_000 }).catch(() => undefined),
  ]);
  if (/\/overview/.test(page.url())) return "signed-in";
  await expect(failed).toBeVisible();
  return "rejected";
}

export async function signOutPortal(page: Page): Promise<void> {
  await page.getByRole("button", { name: "Sign out" }).click();
  await expect(page).not.toHaveURL(/\/overview/);
}

/** The portal's audit rows, newest first, for one account or an email. */
export interface CustomerAccessRow {
  id: string;
  occurred_at: string;
  event: string;
  account_id: string | null;
  email: string | null;
  ip: string | null;
  detail: Record<string, unknown> | null;
}
