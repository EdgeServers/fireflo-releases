"use client";
import { useState } from "react";
import Link from "next/link";
import { Plus } from "lucide-react";
import { Button, buttonClasses } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { AdvancedToggle } from "./AdvancedToggle";
import { CardActions, Figures, HealthStrip } from "./CardBits";
import { DangerAction } from "./DangerAction";
import { useAdvanced } from "@/hooks/useAdvanced";
import { ProductForm } from "./ProductForm";
import { useProducts } from "./useProducts";
import type { ProductInput, ProductSummary } from "@/lib/product-types";
import { EmptyState } from "@/components/ui/empty-state";

/**
 * The product catalogue.
 *
 * <p>A product is the tariff a customer's bind selects, through `system_type`. The gateway learns it
 * from the wire and never from this table — so nothing here changes behaviour. What it changes is
 * whether anyone can tell what `premium` was supposed to mean.
 */
export function ProductsClient() {
  const { products, orphans, error, loading, busy, load, setEnabled, remove } = useProducts();
  const [editing, setEditing] = useState<ProductInput | "new" | null>(null);
  const [advanced, setAdvanced] = useAdvanced("products");

  if (editing) {
    const isNew = editing === "new";
    return (
      <ProductForm
        initial={isNew ? { name: "", label: "", description: "", enabled: true, whitelistEnabled: true } : editing}
        isNew={isNew}
        onSaved={async () => {
          setEditing(null);
          await load();
        }}
        onCancel={() => setEditing(null)}
      />
    );
  }

  return (
    <>
      <PageHeader
        title="Products"
        description={
          <>
            A product is what a customer&rsquo;s bind asks for as <code className="text-xs">system_type</code>.
            The gateway learns it from the wire; this is where it gets a name and a price.
          </>
        }
        actions={
          <>
            <AdvancedToggle on={advanced} onChange={setAdvanced} />
            <Button onClick={() => setEditing("new")} className="gap-2">
              <Plus className="h-4 w-4" />
              Add product
            </Button>
          </>
        }
      />

      {/* the compensating control for having no foreign key on app_rate_rule.product -- on a fresh
          install this is where every product that actually exists shows up. One line, not a card:
          the fix is one click per name */}
      {!!orphans.length && (
        <HealthStrip>
          <span className="mr-2">In use but not described:</span>
          <span className="inline-flex flex-wrap gap-1 align-middle">
            {orphans.map((name) => (
              <Button
                key={name}
                variant="outline"
                size="sm"
                className="h-7 text-foreground"
                onClick={() => setEditing({ name, label: "", description: "", enabled: true, whitelistEnabled: true })}
              >
                Describe &lsquo;{name}&rsquo;
              </Button>
            ))}
          </span>
        </HealthStrip>
      )}

      {error && (
        <Card>
          <CardContent className="py-4 text-sm text-destructive">{error}</CardContent>
        </Card>
      )}

      {!products.length && (
        <EmptyState>
          {loading ? "Loading…" : "No products described yet"}
        </EmptyState>
      )}

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {products.map((p) => (
          <ProductCard
            key={p.name}
            product={p}
            advanced={advanced}
            busy={busy === p.name}
            onEdit={() =>
              setEditing({
                name: p.name,
                label: p.label,
                description: p.description,
                enabled: p.enabled,
                whitelistEnabled: p.whitelistEnabled,
              })
            }
            onToggle={() => setEnabled(p.name, !p.enabled)}
            removeConsequence={describeProductRemoval(p)}
            onRemove={() => remove(p.name)}
          />
        ))}
      </div>
    </>
  );
}

/**
 * What deleting a product actually costs.
 *
 * <p>Counts logins as well as rules. This once counted rules alone while the card above it displayed
 * the credential count, so a product no rule priced but a login still selected was offered for
 * deletion with nothing said — and the server allowed it.
 *
 * <p>The whitelist exemption is stated whenever it is in effect, not only when a rule happens to
 * price the product: losing the exemption is about traffic, and traffic comes from the logins.
 */
function describeProductRemoval(product: ProductSummary): string {
  const users = [
    product.ruleCount ? `prices ${product.ruleCount} rule(s)` : null,
    product.credentialCount ? `is the default product on ${product.credentialCount} login(s)` : null,
  ].filter(Boolean).join(", and ");

  const still = users
    ? `'${product.name}' still ${users}. Those keep working either way — nothing here is a foreign `
      + "key — so this only removes the description. "
    : "";
  const whitelist = product.whitelistEnabled
    ? ""
    : "It is exempt from sender ID and content checking, and deleting it ends that: this traffic "
      + "goes back under the whitelist and may start being refused.";

  return `${still}${whitelist}` || "Only the description goes; nothing prices or selects it.";
}

function ProductCard({
  product,
  advanced,
  busy,
  onEdit,
  onToggle,
  onRemove,
  removeConsequence,
}: {
  product: ProductSummary;
  advanced: boolean;
  busy: boolean;
  onEdit: () => void;
  onToggle: () => void;
  onRemove: () => void;
  /** What is still using this product, and whether deleting it ends a whitelist exemption. */
  removeConsequence: string;
}) {
  const wired = product.ruleCount > 0 || product.credentialCount > 0;
  return (
    <Card className={cn("min-w-0", !product.enabled && "opacity-70")}>
      <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
        {/* the code is the identity: it is what a bind sends and what every rule names */}
        <Link
          href={`/cp/products/${encodeURIComponent(product.name)}`}
          className={`rounded-md px-2 py-0.5 font-mono text-xs font-bold ${product.enabled ? "bg-primary-soft text-primary" : "bg-muted text-muted-foreground"}`}
        >
          {product.name}
        </Link>
        <CardActions>
          <Link href={`/cp/products/${encodeURIComponent(product.name)}`} className={buttonClasses({ variant: "outline", size: "sm" })}>
            Pricing
          </Link>
          <Button variant="ghost" size="sm" onClick={onEdit}>Edit</Button>
          {advanced && (
            <>
              <Button variant="ghost" size="sm" onClick={onToggle} disabled={busy}>
                {product.enabled ? "Unlist" : "List"}
              </Button>
              <DangerAction
                label="Delete"
                confirmLabel="Delete this product"
                consequence={removeConsequence}
                busy={busy}
                onConfirm={onRemove}
              />
            </>
          )}
        </CardActions>
      </CardHeader>
      <CardContent className="space-y-3 pt-3">
        <div>
          <p className="text-sm font-medium">{product.label || product.name}</p>
          <p className="text-xs text-muted-foreground">{product.description || "No description yet."}</p>
        </div>
        <Figures
          figures={[
            { value: product.ruleCount, label: product.ruleCount === 1 ? "rule" : "rules" },
            { value: product.scopeCount, label: product.scopeCount === 1 ? "scope" : "scopes" },
            { value: product.credentialCount, label: product.credentialCount === 1 ? "login" : "logins" },
          ]}
        />
        <div className="flex flex-wrap gap-1">
          <Badge variant={product.enabled ? "success" : "outline"}>{product.enabled ? "Listed" : "Unlisted"}</Badge>
          {/* traffic deliberately going unchecked is worth seeing without opening the form, and only
              while it is actually in effect -- an unlisted product is not exempt */}
          {product.enabled && (
            <Badge variant={product.whitelistEnabled ? "success" : "warning"}>
              {product.whitelistEnabled ? "Whitelist checked" : "Not whitelist checked"}
            </Badge>
          )}
          {!wired && <Badge variant="outline">Nothing prices or selects it</Badge>}
        </div>
      </CardContent>
    </Card>
  );
}
