"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { ArrowDownToLine, ArrowLeft } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClasses } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { EmptyState } from "@/components/ui/empty-state";
import { CardActions, HealthStrip } from "@/components/CardBits";
import { ErrorCodeEditor } from "@/components/ErrorCodeEditor";
import { workerDefaultKey } from "@/lib/gateway-key-policy";
import {
  errorCodeProblem,
  formatErrorCodes,
  parseErrorCodes,
  type ErrorCodePair,
} from "@/lib/error-codes";
import type { Worker } from "@/lib/worker-types";

/**
 * One vendor's error-code list, with the global one read-only beneath it.
 *
 * <h2>The replacement is what this page exists to make visible</h2>
 *
 * <p>{@code configDlrsErrorCodeMapping} reads ONE value per vendor. There is no merge: a vendor that
 * maps only 630 silently loses every other global entry. {@code FireFloConfigurationHandler.get}
 * falls back to {@code outSms.default.*} only when the instance key is <em>unresolved</em> — it does
 * not union the two maps.
 *
 * <p>So the global list is rendered below, greyed, with a control to adopt each row. "Replaces" is
 * then visible before the first entry is typed rather than discovered from a support ticket
 * afterwards.
 *
 * <h2>Two tiers, two writers</h2>
 *
 * <p>Everything editable here writes {@code app_worker_property} through {@code setWorkerProperty};
 * the read-only half comes from {@code app_config}. The global list is deliberately not editable
 * from this page — a control that changed every other vendor, sitting under the heading of one
 * vendor, is exactly the confusion the split was for.
 */
const GLOBAL_LIST_KEY = workerDefaultKey("dlr.errcodes");
const GLOBAL_PASSTHROUGH_KEY = workerDefaultKey("dlr.errcodes.passthrough");

export function VendorErrorCodesClient({ name }: { name: string }) {
  const [pairs, setPairs] = useState<ErrorCodePair[]>([]);
  /** null when the vendor carries no list of its own — which is not the same as an empty one. */
  const [stored, setStored] = useState<string | null>(null);
  const [passthrough, setPassthrough] = useState<boolean | null>(null);
  const [globalPairs, setGlobalPairs] = useState<ErrorCodePair[]>([]);
  const [globalPassthrough, setGlobalPassthrough] = useState(false);
  const [missing, setMissing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [settingsRes, workersRes] = await Promise.all([
        fetch("/api/control/gateway-settings"),
        fetch("/api/control/workers?type=smppclient"),
      ]);
      const settings = await settingsRes.json();
      const workers = await workersRes.json();
      if (!settingsRes.ok) throw new Error(settings?.error ?? "Could not read settings.");
      if (!workersRes.ok) throw new Error(workers?.error ?? "Could not read vendors.");

      setGlobalPairs(parseErrorCodes(settings?.data?.[GLOBAL_LIST_KEY]?.value ?? ""));
      setGlobalPassthrough(
        (settings?.data?.[GLOBAL_PASSTHROUGH_KEY]?.value ?? "").trim().toLowerCase() === "true"
      );

      const vendor = ((workers?.data ?? []) as Worker[]).find((w) => w.name === name);
      if (!vendor) {
        setMissing(true);
        setLoading(false);
        return;
      }
      setMissing(false);
      //`setWorkerProperty` deletes the row for an empty value, so an absent property IS "inherits".
      //Kept as null rather than "" so this page can tell "no list of its own" from "a list that
      //happens to be empty"
      const own = vendor.properties.find((p) => p.key === "dlr.errcodes")?.value ?? null;
      const ownPassthrough =
        vendor.properties.find((p) => p.key === "dlr.errcodes.passthrough")?.value ?? null;
      setStored(own);
      setPairs(parseErrorCodes(own));
      setPassthrough(
        ownPassthrough === null ? null : ownPassthrough.trim().toLowerCase() === "true"
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load error codes.");
    }
    setLoading(false);
  }, [name]);

  useEffect(() => {
    void load();
  }, [load]);

  const save = useCallback(
    async (key: string, value: string) => {
      setSaving(key);
      setError(null);
      const res = await fetch(`/api/control/workers/${encodeURIComponent(name)}`, {
        //PATCH, not PUT: the full save replaces every setting and would need a complete copy of the
        //vendor, password included, just to change one mapping
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ property: { key, value } }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => null);
        setError(body?.error ?? "That could not be saved.");
      }
      setSaving(null);
      await load();
    },
    [name, load]
  );

  const back = (
    <Link
      href={`/cp/vendors/${encodeURIComponent(name)}`}
      className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
    >
      <ArrowLeft className="h-4 w-4" /> {name}
    </Link>
  );

  if (loading || missing) {
    return (
      <div className="space-y-5">
        {back}
        <EmptyState>
          {loading ? (
            "Loading…"
          ) : (
            <>
              There is no SMPP vendor named <code className="font-mono">{name}</code>. Error codes belong
              to whoever sent them, so there is nothing to translate here.{" "}
              <Link href="/cp/error-codes" className="text-primary hover:underline">
                The list every vendor inherits →
              </Link>
            </>
          )}
        </EmptyState>
      </div>
    );
  }

  const own = stored !== null;
  const blocked = pairs.some((p) => errorCodeProblem(p) !== null);
  //what the vendor will actually do about an unmapped code, which is its own answer where it has
  //one and the global one otherwise -- the same fallback the gateway applies
  const effectivePassthrough = passthrough ?? globalPassthrough;

  return (
    <div className="space-y-5">
      {back}

      {/* the vendor detail page's shape: what you edit on the left, what you glance at -- the list
          this one replaces -- in a rail on the right, so "replaces" is visible while you type */}
      <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_300px]">
      <Card className="min-w-0">
        <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
          <span className="text-base font-medium">Error codes</span>
          <span className="font-mono text-xs text-muted-foreground">{name}</span>
          <Badge variant={own ? "default" : "outline"}>{own ? "Own list" : "Inherits global"}</Badge>
          <CardActions>
            <Button
              size="sm"
              onClick={() => save("dlr.errcodes", formatErrorCodes(pairs))}
              disabled={saving !== null || blocked}
            >
              {saving === "dlr.errcodes" ? "Saving…" : "Save"}
            </Button>
            {own && (
              //back to inheriting. Clearing the key is what `setWorkerProperty` treats as a delete,
              //which is the only way to get the global list applying again
              <Button
                variant="outline"
                size="sm"
                disabled={saving !== null}
                onClick={() => {
                  setPairs([]);
                  void save("dlr.errcodes", "");
                }}
              >
                Use the global list
              </Button>
            )}
          </CardActions>
        </CardHeader>
        <CardContent className="space-y-3 pt-3">
          {error && <HealthStrip tone="destructive">{error}</HealthStrip>}
          <p className="text-xs text-muted-foreground">
            {own
              ? "Uses its own list. The global one does not apply to this vendor."
              : "Inherits the global list. Adding a mapping here replaces it."}{" "}
            What this carrier&apos;s failure codes become on the receipt the customer reads.
          </p>

          {/* shown whenever a list exists OR is being started, because that is exactly when the
              replacement bites. The gateway reads one value; it does not merge the tiers */}
          {(own || pairs.length > 0) && globalPairs.length > 0 && (
            <HealthStrip tone="warning">
              This list replaces the global one for {name} — it does not add to it. The{" "}
              {globalPairs.length} global {globalPairs.length === 1 ? "entry" : "entries"} beside it
              stop applying here, including any not repeated above.
            </HealthStrip>
          )}

          <ErrorCodeEditor
            pairs={pairs}
            onChange={setPairs}
            disabled={saving === "dlr.errcodes"}
          />

          <label className="flex items-start gap-2 text-sm">
            <Checkbox
              checked={effectivePassthrough}
              disabled={saving === "dlr.errcodes.passthrough"}
              //saves on its own rather than waiting for the button below: it is one boolean and
              //there is nothing to review before committing it, unlike the table above
              onChange={(e) =>
                save("dlr.errcodes.passthrough", e.target.checked ? "true" : "false")
              }
            />
            <span>
              Send codes we have not mapped as {name} sent them.
              <span className="block text-xs text-muted-foreground">
                {passthrough === null
                  ? `Not set — following the global answer, which is currently ${
                      globalPassthrough ? "on" : "off"
                    }.`
                  : "Off, anything not listed above reaches the customer as 018."}
              </span>
            </span>
          </label>
        </CardContent>
      </Card>

      <div className="min-w-0 space-y-4 xl:sticky xl:top-4">
        <Card>
          <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
            <span className="text-sm font-medium">
              {own ? "Global list, not used here" : "Inherited today"}
            </span>
            <span className="text-xs text-muted-foreground">{globalPairs.length} mapped</span>
            <CardActions>
              <Link href="/cp/error-codes" className={buttonClasses({ variant: "outline", size: "sm" })}>
                Edit for every vendor →
              </Link>
            </CardActions>
          </CardHeader>
          <CardContent className="pt-3">
            {globalPairs.length === 0 ? (
              <p className="text-xs text-muted-foreground">
                Nothing is mapped globally, so this vendor inherits no translations.
              </p>
            ) : (
              <ul className="divide-y divide-border">
                {globalPairs.map((pair) => (
                  <li key={pair.carrier} className="flex items-center justify-between gap-3 py-1 text-sm">
                    <span className="font-mono text-muted-foreground">
                      {pair.carrier} → {pair.ours}
                    </span>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="gap-1.5"
                      disabled={saving !== null || pairs.some((p) => p.carrier === pair.carrier)}
                      onClick={() => setPairs((prev) => [...prev, { ...pair }])}
                    >
                      <ArrowDownToLine className="h-3.5 w-3.5" />
                      Copy here
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
      </div>
    </div>
  );
}
