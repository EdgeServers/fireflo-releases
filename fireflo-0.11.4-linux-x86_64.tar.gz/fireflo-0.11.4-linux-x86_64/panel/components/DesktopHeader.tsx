"use client";
import { usePageMeta } from "@/hooks/usePageMeta";
import { HealthLink } from "./HealthLink";
import { ThemeToggle } from "./ThemeToggle";

export function DesktopHeader() {
  const { title, subtitle } = usePageMeta();

  return (
    //52px, the sample's bar: the page name as a breadcrumb-weight title, the subtitle beside it
    //rather than under it so the bar stays one line tall
    <header className="hidden h-[52px] shrink-0 items-center gap-3 border-b bg-card px-5 md:flex">
      <div className="flex min-w-0 items-baseline gap-2">
        <p className="truncate text-sm font-semibold tracking-tight">{title}</p>
        {subtitle && (
          <p className="truncate text-xs text-muted-foreground">{subtitle}</p>
        )}
      </div>
      <div className="ml-auto flex items-center gap-1">
        <HealthLink />
        <ThemeToggle />
      </div>
    </header>
  );
}
