"use client";
import { useState } from "react";
import { DangerAction } from "./DangerAction";
import { Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle, EditPanel,
} from "@/components/ui/card";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { ErrorCard } from "./FormNotices";
import { FilterForm } from "./FilterForm";
import { GatewayIgnores } from "./GatewayIgnores";
import { useFilters } from "./useFilters";
import { type Filter, usedByTotal } from "@/lib/filter-types";

/**
 * Named condition sets, defined once and referenced by rules.
 *
 * <p>The reason this page exists: before it, the same clause was retyped on every rate rule that
 * needed it, and changing it meant finding all of them. The tables and the gateway loaders have
 * supported filters since V1.4.0 — `app_filter` was simply empty because nothing could write to it.
 *
 * <p><strong>Usage counts are the point of the list, not decoration.</strong> A filter is never
 * edited in isolation: disabling one skips every rule using it, and deleting one is refused while
 * any rule does. Both consequences are proportional to that number, so it sits on the row.
 */
export function FiltersClient() {
  const { filters, error, loading, busy, save, remove } = useFilters();
  const [editing, setEditing] = useState<Filter | "new" | null>(null);
  const [removeError, setRemoveError] = useState("");

  return (
    <>
      <ErrorCard error={error || removeError} />

      {/* a filter on a rate rule is inert while the gateway prices from its file */}
      <GatewayIgnores domain="rates" />

      <Card>
        <CardHeader bar>
          <div className="min-w-0 space-y-1.5">
            <CardTitle>Filters</CardTitle>
            <CardDescription>
              A named set of conditions that pricing and routing rules reference instead of repeating
              it. Every condition in a filter must hold, on top of whatever the rule using it
              requires — a filter narrows a rule, it never widens one.
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {editing !== null && (
            <EditPanel className="mb-3">
              <FilterForm
                editing={editing === "new" ? null : editing}
                onSave={async (input) => {
                  const failure = await save(input);
                  if (!failure) {
                    setEditing(null);
                  }
                  return failure;
                }}
                onCancel={() => setEditing(null)}
              />
            </EditPanel>
          )}

          {!filters.length ? (
            <p className="py-6 text-center text-sm text-muted-foreground">
              {loading ? "Loading…" : "No filters yet. Define one to stop retyping the same clause."}
            </p>
          ) : (
            <TableInCard>
              <THead>
                <TR>
                  <TH>Name</TH>
                  <TH>Conditions</TH>
                  <TH>Used by</TH>
                  <TH />
                </TR>
              </THead>
              <TBody>
                {filters.map((f) => {
                  const uses = usedByTotal(f);
                  return (
                    <TR key={f.name}>
                      <TD className="align-top">
                        <button type="button" onClick={() => setEditing(f)}
                          className="font-mono text-sm text-primary hover:underline">
                          {f.name}
                        </button>
                        {!f.enabled && <Badge variant="outline" className="ml-2">off</Badge>}
                        {f.label && (
                          <span className="block text-xs text-muted-foreground">{f.label}</span>
                        )}
                      </TD>
                      <TD className="align-top">
                        {f.conditions.length ? (
                          <span className="flex flex-col gap-0.5 font-mono text-xs text-muted-foreground">
                            {f.conditions.map((c, i) => (
                              <span key={i} className="whitespace-nowrap">
                                {c.field} {c.negate ? "not " : ""}{c.operator} {c.value}
                              </span>
                            ))}
                          </span>
                        ) : (
                          //legal, and worth flagging: it narrows nothing
                          <span className="text-xs text-amber-600 dark:text-amber-400">
                            no conditions — narrows nothing
                          </span>
                        )}
                      </TD>
                      <TD className="align-top">
                        {uses === 0 ? (
                          <span className="text-muted-foreground">unused</span>
                        ) : (
                          <span className="whitespace-nowrap">
                            {f.usedBy.rates > 0 && `${f.usedBy.rates} price`}
                            {f.usedBy.rates > 0 && f.usedBy.routes > 0 && " · "}
                            {f.usedBy.routes > 0 && `${f.usedBy.routes} routing`}
                          </span>
                        )}
                      </TD>
                      <TD align="right" className="whitespace-nowrap align-top">
                        <DangerAction
                          label="Delete"
                          confirmLabel="Delete this filter"
                          busy={busy === f.name}
                          consequence={
                            uses > 0
                              ? `${uses} rule(s) reference '${f.name}', so this will be refused — `
                                + "detach it from them first."
                              : `Nothing references '${f.name}', so nothing changes for any rule.`
                          }
                          onConfirm={async () => setRemoveError((await remove(f.name)) ?? "")}
                        />
                      </TD>
                    </TR>
                  );
                })}
              </TBody>
            </TableInCard>
          )}

          <p className="text-sm text-muted-foreground">
            Disabling a filter is not the same as loosening it. Every rule referencing a disabled
            filter is <strong>skipped</strong> by the gateway, so that traffic falls through to
            whatever prices or routes it next.
          </p>
        </CardContent>
        <CardFooter bar>
          <Button size="sm" className="gap-2" onClick={() => setEditing("new")}>
            <Plus className="h-4 w-4" />
            New filter
          </Button>
        </CardFooter>
      </Card>
    </>
  );
}
