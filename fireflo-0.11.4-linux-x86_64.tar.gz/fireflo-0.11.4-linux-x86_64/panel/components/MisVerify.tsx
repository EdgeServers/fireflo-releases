"use client";
import { useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Card, CardContent } from "@/components/ui/card";
import { buttonClasses } from "@/components/ui/button";
import Link from "next/link";
import { verifyOutcome, type VerifySession } from "@/lib/verify-outcome";

/**
 * Spends the token in the URL and signs the browser in -- when the customer presses the button, not
 * when the page loads.
 *
 * <p><strong>Why a button.</strong> Mail link scanners (Defender Safe Links, Mimecast, Proofpoint)
 * open links in a browser that runs JavaScript, and so does an in-app mail preview. When this page
 * redeemed on load, the scanner spent the single-use token and the customer's own click was
 * refused. Only a person presses the button, so only the person's browser gets the session.
 *
 * <p>Posts to the portal's own NextAuth callback rather than calling `signIn` from `next-auth/react`
 * — that helper is bound to the operator instance's endpoint, and using it here would try to sign
 * the customer in as an operator.
 *
 * <p><strong>Guarded against firing twice.</strong> A token is single use: a double click would
 * spend it on the first press and report "already used" on the second.
 */
export function MisVerify() {
  const params = useSearchParams();
  const router = useRouter();
  const token = params.get("token");
  const [failed, setFailed] = useState(!token);
  const [busy, setBusy] = useState(false);
  const started = useRef(false);

  async function redeem() {
    if (started.current || !token) {
      return;
    }
    started.current = true;
    setBusy(true);

    try {
      const csrfRes = await fetch("/api/mis/auth/csrf");
      const { csrfToken } = (await csrfRes.json()) as { csrfToken: string };
      const body = new URLSearchParams({ csrfToken, token, redirect: "false" });
      const res = await fetch("/api/mis/auth/callback/magic-link", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body,
      });
      //neither the status nor the session can answer this alone -- the rule, and the defect it
      //replaces, are written out in lib/verify-outcome.ts, where they are testable without a
      //browser. In short: fetch follows next-auth's 302, so res.ok is true for a rejected token,
      //and a browser that is already signed in has a session whatever this token did
      const session = (await (await fetch("/api/mis/auth/session")).json()) as VerifySession;
      if (verifyOutcome(res.url, window.location.origin, session) === "signed-in") {
        //the overview, not the message list. Signing in and being handed three hundred rows
        //answers "what happened to message X" before anybody has asked it; the dashboard answers
        //"is my traffic healthy", which is the question somebody actually arrives with
        router.replace("/overview");
        return;
      }
      setFailed(true);
    } catch {
      setFailed(true);
    }
  }

  return (
    <main className="flex min-h-dvh items-center justify-center px-4">
      <Card className="w-full max-w-md">
        <CardContent className="space-y-3 py-8 text-center text-base">
          {failed ? (
            <>
              <p className="font-medium">That link did not work.</p>
              <p className="text-muted-foreground">
                Sign-in links work once and expire after 15 minutes. Ask for a new one.
              </p>
              <Link href="/" className={buttonClasses({ variant: "outline", size: "sm" })}>
                Back to sign in
              </Link>
            </>
          ) : (
            <>
              <p className="font-medium">Finish signing in.</p>
              <p className="text-muted-foreground">This link works once and expires after 15 minutes.</p>
              <button
                type="button"
                onClick={redeem}
                disabled={busy}
                className={buttonClasses({ className: "w-full" })}
              >
                {busy ? "Signing you in…" : "Sign in"}
              </button>
            </>
          )}
        </CardContent>
      </Card>
    </main>
  );
}
