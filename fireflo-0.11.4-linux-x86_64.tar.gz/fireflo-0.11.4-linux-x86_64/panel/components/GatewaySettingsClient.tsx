"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { HealthStrip } from "@/components/CardBits";
import { Select } from "@/components/ui/select";
import { GatewayKeyTable, type KeyField, type KeyRow } from "@/components/GatewayKeyTable";
import { GatewayDiagnostics } from "@/components/GatewayDiagnostics";
import { GatewayInForce } from "@/components/GatewayInForce";

/** The one level, and the two keys it supplies defaults for. */
const DIAGNOSTICS_KEY = "smsg.diagnostics";
const MessageTraceKey = "message.trace.mode";
const EVENTS_KEY = "smsg.cdr.events";
import { SettingControl } from "@/components/SettingControl";
import { Tabs } from "@/components/ui/tabs";
import { gatewayFieldsFor } from "@/lib/gateway-setting-fields";
import { judgeGatewayKey, workerDefaultKey, WRITABLE_PREFIXES } from "@/lib/gateway-key-policy";
import { settingLabel } from "@/lib/labels";
import { SETTING_FIELDS, type SettingWidget } from "@/lib/setting-fields";

/**
 * The two configuration tiers above a worker.
 *
 * <p><strong>Why this page exists at all.</strong> The gateway has three tiers and the panel could
 * only edit the narrowest, so an operator could set a value on one listener but had no way to say
 * "every listener" or "the REST ingress" without editing a properties file or writing SQL. That is
 * also why the two ingresses drifted: `smsg.restapi.*` and a listener's own keys each configure one
 * side, and nothing put them where somebody would notice they disagree.
 *
 * <p><strong>Two columns, by scope.</strong> REST on the left, everything that governs both ingresses
 * on the right. Putting them side by side is the whole point — the asymmetry this page exists to
 * expose cannot be read when one is scrolled off the bottom of the other.
 *
 * <p><strong>The grid is owned here.</strong> A child that owns its own split produced three columns
 * at `xl` the last time; see the note on `VendorsClient`. Every cell is a wrapper that always exists,
 * because a bare conditional renders no cell at all and the survivor spreads across the full width.
 */
type Values = Record<string, { value: string | null; enabled: boolean }>;

/** One editable row, whichever catalogue described it. */
interface Renderable {
  key: string;
  label: string;
  hint?: string;
  widget: SettingWidget;
  /** Null where no default was read out of the gateway source, so nothing is claimed. */
  codedDefault: string | null;
}

export function GatewaySettingsClient() {
  const [values, setValues] = useState<Values>({});
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [withheld, setWithheld] = useState(0);
  const [addingDefault, setAddingDefault] = useState("");
  const [tab, setTab] = useState<"settings" | "diagnostics" | "inForce">("settings");
  /**
   * Edits made but not yet written.
   *
   * <p>Nothing on this tab reaches the gateway until Save. Every key here is one value for every
   * vendor, every listener and both ingresses at once, and the previous version committed each one
   * on blur -- a gateway-wide change with no moment where anybody agreed to it. A key mapped to the
   * empty string is a pending clear, which is why this is keyed presence rather than truthiness.
   */
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [savingAll, setSavingAll] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/control/gateway-settings", { cache: "no-store" });
      const body = await res.json();
      if (!res.ok) {
        setError(body?.error ?? "Could not read gateway configuration.");
        setValues({});
      } else {
        setError(null);
        setValues(body.data ?? {});
        setWithheld(typeof body.withheld === "number" ? body.withheld : 0);
      }
    } catch {
      setError("Could not reach the panel's own API.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  /** Stage an edit. Setting a field back to what is stored clears it rather than saving a no-op. */
  const draft = useCallback((key: string, value: string, stored: string) => {
    setDrafts((prev) => {
      const next = { ...prev };
      if (value === stored) {
        delete next[key];
      } else {
        next[key] = value;
      }
      return next;
    });
  }, []);

  const save = useCallback(async (key: string, value: string): Promise<boolean> => {
    setSaving(key);
    try {
      const res = await fetch("/api/control/gateway-settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key, value }),
      });
      const body = await res.json();
      if (!res.ok) {
        setError(body?.error ?? "Could not save.");
        return false;
      }
      setError(null);
      setValues((prev) => {
        const next = { ...prev };
        if (value.trim() === "") {
          delete next[key];
        } else {
          next[key] = { value, enabled: true };
        }
        return next;
      });
      //a picked-and-now-saved default is an ordinary persisted row from here on -- values already
      //excludes it from the picker's option list, so the pending-pick flag must step aside too, or a
      //later delete of this same row can never make the key pickable again (unsetWorkerKeys would
      //keep excluding it forever on the addingDefault check alone)
      setAddingDefault((prev) => (prev && workerDefaultKey(prev) === key ? "" : prev));
      return true;
    } catch {
      setError("Could not reach the panel's own API.");
      return false;
    } finally {
      setSaving(null);
    }
  }, []);

  /**
   * Write every pending edit, then clear the ones that landed.
   *
   * <p>Sequential rather than parallel, and it stops at the first refusal. These are configuration
   * writes with an audit line each; firing them concurrently would interleave the log and, worse,
   * would leave a half-applied set with no way to say which half.
   */
  const saveAll = useCallback(async () => {
    setSavingAll(true);
    try {
      for (const [key, value] of Object.entries(drafts)) {
        const ok = await save(key, value);
        if (!ok) {
          //the failed key keeps its draft, so the error names something still on screen
          return;
        }
        setDrafts((prev) => {
          const next = { ...prev };
          delete next[key];
          return next;
        });
      }
    } finally {
      setSavingAll(false);
    }
  }, [drafts, save]);

  //the catalogue owns its own grouping, rather than this component re-deriving the same filter
  const restapi = gatewayFieldsFor("restapi");
  const gateway = gatewayFieldsFor("gateway");

  const smsgPrefix = WRITABLE_PREFIXES[0];
  const workerPrefix = WRITABLE_PREFIXES[1];

  /** The catalogue entry for a bare (unprefixed) worker key, in the shape GatewayKeyTable renders. */
  const workerFieldFor = useCallback((bareKey: string): KeyField | undefined => {
    if (!(bareKey in SETTING_FIELDS)) {
      return undefined;
    }
    const field = SETTING_FIELDS[bareKey as keyof typeof SETTING_FIELDS];
    const { label, hint } = settingLabel(bareKey);
    return { label, hint, widget: field.widget, codedDefault: field.codedDefault };
  }, []);

  /** Same lookup, taking the full `outSms.default.<key>` form GatewayKeyTable's rows carry. */
  const resolveWorkerField = useCallback(
    (key: string): KeyField | undefined =>
      key.startsWith(workerPrefix) ? workerFieldFor(key.slice(workerPrefix.length)) : undefined,
    [workerFieldFor, workerPrefix]
  );

  /**
   * The delete button on every row in the merged table calls this, not `draft` directly.
   *
   * <p>Deleting the row that reflects an in-progress, unsaved picker selection has to do one thing
   * `draft` alone cannot: clear `addingDefault`. Without that the blank row stays force-included by
   * `workerDefaults` regardless of what happens to `drafts`, since it was never a draft to begin with
   * -- picking a default and deleting it again before typing anything stages nothing.
   */
  const removeWorkerKey = useCallback(
    (key: string, stored: string) => {
      if (key.startsWith(workerPrefix) && key.slice(workerPrefix.length) === addingDefault) {
        setAddingDefault("");
      }
      draft(key, "", stored);
    },
    [workerPrefix, addingDefault, draft]
  );

  /**
   * Every `outSms.default.*` key that is actually set, plus any the operator has just opened for
   * editing. Catalogued or not — a worker default with no field of its own is still something an
   * operator set and needs to see, which is why it lives here and not in Any other key.
   *
   * <p>Not every possible worker key: there are eighty-odd, and a wall of eighty empty fields would
   * bury the handful that matter. A default only exists once somebody sets one, so the list of set
   * ones *is* the interesting list, and the picker beneath adds to it.
   */
  const workerDefaults: KeyRow[] = useMemo(() => {
    const keys = Object.keys(values)
      .filter((k) => k.startsWith(workerPrefix))
      .map((k) => k.slice(workerPrefix.length));
    if (addingDefault && !keys.includes(addingDefault)) {
      keys.push(addingDefault);
    }
    return keys
      .sort((a, b) => settingLabel(a).label.localeCompare(settingLabel(b).label))
      .map((k) => {
        const full = workerDefaultKey(k);
        const current = values[full];
        return {
          key: full,
          value: current?.value ?? null,
          enabled: current?.enabled ?? true,
          //shown and locked when another screen owns the key -- the same treatment the broker and
          //sink wiring gets below, and for the same reason: an operator needs to see that a default
          //is set far more often than they need to change it from here
          writable: SETTING_FIELDS[k as keyof typeof SETTING_FIELDS]?.elsewhere === undefined,
          field: workerFieldFor(k),
        };
      });
  }, [values, addingDefault, workerPrefix, workerFieldFor]);

  /**
   * Uncurated `smsg.*` keys that no card above renders. `outSms.default.*` never reaches this list —
   * that whole prefix belongs to Worker defaults above, curated or not, stated explicitly here rather
   * than left as something that happens to be true of two other computations.
   */
  const extras: KeyRow[] = useMemo(() => {
    const shown = new Set([...restapi.map((f) => f.key), ...gateway.map((f) => f.key)]);
    return Object.entries(values)
      .filter(([key]) => {
        if (!key.startsWith(smsgPrefix) || shown.has(key)) {
          return false;
        }
        const verdict = judgeGatewayKey(key);
        //a curated key belongs in a card above, not here. A key that is readable but not writable --
        //the broker and sink wiring -- does belong here, shown and locked: seeing that smsg.cdr.sink
        //is set to something unexpected is exactly what an operator opens this page to find out
        return verdict.allowed ? !verdict.curated : true;
      })
      .map(([key, v]) => ({
        key,
        value: v.value,
        enabled: v.enabled,
        writable: judgeGatewayKey(key).allowed,
      }))
      .sort((a, b) => a.key.localeCompare(b.key));
  }, [values, restapi, gateway, smsgPrefix]);

  /**
   * Catalogued worker-default settings the picker may still offer.
   *
   * <p>Excludes more than just what is persisted: `addingDefault` is a pick already showing as a
   * blank row, and a curated key can now also reach `drafts` directly through the free-text Add box
   * (which used to refuse it) -- either way it is already spoken for and must not also appear as a
   * choice, or picking it twice would fight over the same row.
   */
  const unsetWorkerKeys = Object.keys(SETTING_FIELDS)
    .filter((k) => {
      const full = workerDefaultKey(k);
      //and never a key another screen owns: the picker's job is to open a blank editor, which is
      //exactly what that screen exists to be
      if (SETTING_FIELDS[k as keyof typeof SETTING_FIELDS].elsewhere !== undefined) {
        return false;
      }
      return !(full in values) && k !== addingDefault && !(full in drafts);
    })
    .sort((a, b) => settingLabel(a).label.localeCompare(settingLabel(b).label));

  const dirty = Object.keys(drafts).length;

  const row = (f: Renderable) => (
    <Field
      key={f.key}
      field={f}
      current={values[f.key]}
      pending={drafts[f.key]}
      busy={saving === f.key || savingAll || loading}
      onDraft={draft}
    />
  );

  return (
    <>
      <PageHeader
        title="Gateway"
        description="Configuration for the whole gateway: what the panel has written, its diagnostics level, and what the running process has adopted."
      />
      {/* two tabs because there are two questions, and conflating them is what made a saved-but-
          ignored row invisible. Settings is what we have written; In force is what the gateway is
          running. The second is read-only on purpose */}
      <Tabs
        label="Gateway configuration"
        active={tab}
        onSelect={setTab}
        items={[
          { id: "settings" as const, label: "Settings" },
          { id: "diagnostics" as const, label: "Diagnostics" },
          { id: "inForce" as const, label: "In force" },
        ]}
      />

      {tab === "diagnostics" ? (
        <Card>
          <CardHeader>
            <CardTitle>Diagnostics</CardTitle>
          </CardHeader>
          <CardContent>
            <GatewayDiagnostics
              level={values[DIAGNOSTICS_KEY]?.value ?? ""}
              //the two keys the level fronts, when either is set on its own. Reported rather than
              //hidden: a level that reads as in force while a key outranks it is the one failure
              //this design introduces
              overrides={[MessageTraceKey, EVENTS_KEY]
                .filter((k) => (values[k]?.value ?? "").trim() !== "")
                .map((k) => ({ key: k, value: values[k]?.value ?? "" }))}
              busy={saving !== null}
              onChange={(next) => void save(DIAGNOSTICS_KEY, next)}
            />
          </CardContent>
        </Card>
      ) : tab === "inForce" ? (
        <GatewayInForce />
      ) : (
      <>
      <p className="text-sm text-muted-foreground">
        These apply to the whole gateway, above anything set on an individual vendor or listener. A
        worker with no value of its own inherits from here.
      </p>

      {/* the page's one commit point. Every key on this tab is one value for every vendor, every
          listener and both ingresses at once, and it used to write on blur -- a gateway-wide change
          with no moment where anybody agreed to it. Rendered above the cards rather than below them
          so the count is visible from the field being edited */}
      {dirty > 0 && (
        <Card className="border-primary/40">
          <CardContent className="flex flex-wrap items-center gap-3 py-3">
            <p className="text-sm">
              <span className="font-medium">
                {dirty} unsaved {dirty === 1 ? "change" : "changes"}
              </span>
              <span className="text-muted-foreground"> — nothing has reached the gateway yet.</span>
            </p>
            <div className="ml-auto flex gap-2">
              <Button
                type="button"
                variant="outline"
                disabled={savingAll}
                //a picked-but-untyped default has no draft to discard -- it only ever lived in
                //addingDefault -- so Discard has to clear both or the blank row survives its own undo
                onClick={() => {
                  setDrafts({});
                  setAddingDefault("");
                }}
              >
                Discard
              </Button>
              <Button type="button" disabled={savingAll} onClick={() => void saveAll()}>
                {savingAll ? "Saving…" : "Save changes"}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {error && <HealthStrip tone="destructive">{error}</HealthStrip>}

      <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <div className="min-w-0">
          <Card>
            <CardHeader>
              <CardTitle>REST API</CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              {/* the sentence this page was built to make available. Each ingress carries its own
                  copy of these settings, so "the SMPP side does something else" is a normal state
                  rather than a fault -- but it should be a state somebody chose */}
              <p className="text-sm text-muted-foreground">
                The HTTP ingress has its own copy of several settings that the SMPP listeners also
                have. They are independent, and they do not have to agree — but they should disagree
                on purpose. The equivalents live on each listener under Servers.
              </p>
              {restapi.map(row)}
            </CardContent>
          </Card>
        </div>

        <div className="min-w-0">
          <Card>
            <CardHeader>
              <CardTitle>Gateway-wide</CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">{gateway.map(row)}</CardContent>
          </Card>
        </div>
      </div>

      {/* full width at every size, deliberately outside the REST/Gateway-wide comparison grid above:
          a table of rows reads better edge to edge than squeezed into a half column, and it has no
          side-by-side counterpart to be compared against. Worker defaults and Any other key are one
          card because they are the same shape of question -- "what has been set beyond the curated
          fields above" -- once a curated worker default renders with its own widget in the same list
          as an uncurated one; splitting them was two cards answering the same question */}
      <GatewayKeyTable
        title="Worker defaults and other keys"
        description="Every outSms.default.* key, inherited by every vendor and listener that sets nothing of its own, plus any other gateway key with no field of its own. The panel does not check an uncatalogued value — a wrong one is found by the gateway, not by this form."
        emptyLabel="Nothing set beyond the fields above."
        rows={[...workerDefaults, ...extras]}
        drafts={drafts}
        busy={savingAll || loading}
        onDraft={draft}
        onRemove={removeWorkerKey}
        ownCuratedPrefix={workerPrefix}
        resolveField={resolveWorkerField}
        picker={
          <Select
            aria-label="Setting to default"
            value={addingDefault}
            onChange={(e) => setAddingDefault(e.target.value)}
          >
            <option value="">Choose a setting…</option>
            {unsetWorkerKeys.map((k) => (
              <option key={k} value={k}>
                {settingLabel(k).label}
              </option>
            ))}
          </Select>
        }
      />

      {withheld > 0 && (
        //said rather than silently omitted. The count only -- naming them would undo the withholding
        <p className="text-sm text-muted-foreground">
          {withheld} {withheld === 1 ? "key is" : "keys are"} set on this gateway and not shown here,
          because {withheld === 1 ? "it holds" : "they hold"} a credential. Edit{" "}
          {withheld === 1 ? "it" : "them"} on the host.
        </p>
      )}
      </>
      )}
    </>
  );
}

function Field({
  field,
  current,
  pending,
  busy,
  onDraft,
}: {
  field: Renderable;
  current: { value: string | null; enabled: boolean } | undefined;
  /** An edit staged but not yet saved. `undefined` means this field is untouched. */
  pending: string | undefined;
  busy: boolean;
  onDraft: (key: string, value: string, stored: string) => void;
}) {
  const stored = current?.value ?? "";
  const set = current !== undefined;

  /**
   * Every control is controlled, from the parent's draft or from the store.
   *
   * <p>The text boxes used to be uncontrolled, with `defaultValue`. The first render happens while
   * the fetch is still in flight, so the DOM value was set to `""` and React does not update an
   * uncontrolled input afterwards — which meant three fields on this page rendered blank whatever
   * was stored, and read as "not set" for a value that was very much set.
   */
  const shown = pending ?? stored;
  const edited = pending !== undefined;

  return (
    <div className="space-y-1.5">
      <div className="flex flex-wrap items-center gap-2">
        <label htmlFor={field.key} className="text-sm font-medium">
          {field.label}
        </label>
        {edited && (
          //a change that exists only in this browser until Save is pressed
          <Badge variant="outline">Unsaved</Badge>
        )}
        {set && current?.enabled === false && (
          //a row the gateway is ignoring. DbConfigPoller selects WHERE enabled, so this value is
          //present and doing nothing -- which is otherwise invisible and reads as "I set that and
          //nothing happened"
          <Badge variant="outline">Saved but switched off</Badge>
        )}
        <code className="ml-auto font-mono text-2xs text-muted-foreground">{field.key}</code>
      </div>

      <SettingControl
        id={field.key}
        widget={field.widget}
        codedDefault={field.codedDefault}
        value={shown}
        disabled={busy}
        onChange={(v) => onDraft(field.key, v, stored)}
      />

      {field.hint && <p className="text-sm text-muted-foreground">{field.hint}</p>}
    </div>
  );
}
