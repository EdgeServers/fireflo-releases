# FireFlo Control Panel

An operator view of the FireFlo SMS gateway — traffic, delivery, vendor performance and margin, read
straight from the gateway's call records — and the configuration editor for everything the gateway
holds in PostgreSQL.

**Two audiences, one application, two separate sessions.**

| | Where | Who signs in | Sees |
| :--- | :--- | :--- | :--- |
| Control panel | `/cp` | the operator, from `panel.env` | everything, across every account: margin, vendor names, every login |
| Customer portal | `/` | a customer, by an emailed single-use link | their own account and nothing else |

> **The `/cp` half is an operator tool and has no tenant scoping.** It shows margin and the names of
> the vendors traffic is bought from, across every account. The portal is the scoped half, and the
> boundary between them is a separate cookie and a separate guard — `requireOperator()` against
> `requireCustomer()` — not a hidden menu.

**It is not on the message path.** A panel that is down costs you the ability to make changes, not
the ability to send.

---

## Versioning: the panel follows the gateway

The panel's version says **which gateway release it pairs with**. The first three numbers are that
gateway version and move only when it does; a panel-only change adds a fourth number.

```
0.4.1     the panel that ships with gateway 0.4.1
0.4.1.1   a panel-only change on top of it
0.4.2     the gateway moved, and the panel follows
```

This is worth the small awkwardness because the two are deployed together and read the same schema:
"which panel goes with this gateway" is the question anybody debugging a live pair asks first, and
the version answers it without a compatibility table.

**`package.json` cannot hold four numbers.** npm requires valid semver, which is exactly three, and
would reject `0.4.1.1`. So the file carries it as build metadata — `"version": "0.4.1+1"` — which npm
accepts and preserves verbatim, and [next.config.ts](next.config.ts) turns the `+` into a `.` for the
version shown beside the wordmark. One source of truth, two spellings.

Two consequences worth knowing. Build metadata is **ignored when semver compares versions**, so
`0.4.1+1` does not sort above `0.4.1` — harmless here, because nothing resolves this package by a
version range, but it would matter if the panel were ever published to a registry. And a fourth
number is not a prerelease: `0.4.1-1` would have been legal semver but means "on the way to 0.4.1",
which is the opposite of what is meant.

---

## What it shows

### The control panel, at `/cp`

| Page | Answers |
| :--- | :--- |
| **Overview** | How much went out, how much arrived, what is still in flight, and why the rest failed |
| **Vendors** | Each connection out: its settings, plus volume, retries, delivery rate and spend |
| **Servers** | The listeners customers bind to, with live sessions and measured throughput |
| **Accounts** | The logins customers connect with, and who is actually sending, spending and in credit |
| **Revenue** | Billed against vendor cost, by account and product, with in-flight exposure |
| **Messages** | Individual call records, filtered and paged, with CSV exports prepared in the background |
| **Refused** | What was turned away and why, including messages dropped after every routing attempt |
| **Products** | The tariffs a customer's bind asks for by `system_type`, and what each one means |
| **Pricing** | What we pay each vendor and what each account pays us, rule by rule |
| **Routing** | The routing tables and their ordered rules |
| **Filters** | Named, reusable predicates shared by routing and pricing |
| **Sender IDs · Content** | Every approved registration across every account, with its approval state, and the requests still waiting |
| **TLVs** | The tag names this deployment uses, and where each one is set |
| **Queues** | What is waiting to go out, per worker |
| **Live health** | Bind state, queue depth, the broker, and both versions side by side |
| **Runtime** | The process: heap, threads, HTTP. Explicitly not the traffic — see [What it does not show](#what-it-does-not-show) |
| **Diagnostics** | Bounded log tails and a redacted configuration dump, behind the admin token |

Editing is separate from reading. The pages that write need `CONFIG_DATABASE_URL`; without it the
panel says the domain is not editable rather than failing at the first save. And a change lands at
the gateway on its **next configuration poll**, not immediately — thirty seconds by default.

### The customer portal, at `/`

| Page | Answers |
| :--- | :--- |
| **Messages** | Their own call records, and nothing from any other account |
| **Sender IDs · Templates** | What they have had approved, what is still a request, and the reason anything was refused |
| **Playground** | Real calls against their own account, with their own login |
| **API reference** | Every endpoint and field, generated from the same catalogue the playground uses |

Plus, on their own logins: rotating a password or an API key, shown once. A reseller sees its
children and can transfer credit down to them.

**Two words, used everywhere.** A **vendor** is a connection out to someone who carries our
traffic; a **server** is a listener customers bind in to. The gateway calls these `smppclient` and
`smppserver` in its configuration, and those values are still what sit in the database — they just
never appear in the interface.

Failure states are kept apart rather than collapsed into "failed": `EXPIRED`, `REJECTD` and
`UNDELIV` all bill the same and mean entirely different things.

---

## Installing it on a server

```bash
./scripts/fireflo-panel-install check      # is this host ready? changes nothing
sudo ./scripts/fireflo-panel-install install
```

It interviews you for the directories, the port, the database and the operator name, shows every
answer, and changes nothing until you agree. Then: Node 22 from NodeSource (Ubuntu ships 18, which
Next.js 16 will not run on), a service account, `npm ci`, a production build, an environment file at
`/etc/fireflo-panel/panel.env` with a generated session secret and operator password, a systemd unit,
and a check that the sign-in page answers.

**Point it at the gateway's configuration directory and most of that is answered for you:**

```bash
sudo ./scripts/fireflo-panel-install install \
    --gateway-conf-dir /etc/fireflo \
    --gateway-ops-url http://127.0.0.1:9000
```

From that one directory it takes the **two operational tokens** and the **reading database
connection** — the same PostgreSQL the gateway uses, rewritten from the JVM's
`jdbc:postgresql://host:port/db` with the user and password beside it into the single
`postgres://user:pass@host:port/db` that node-postgres wants. Both are things that must match the
gateway exactly and produce misleading failures when they do not: a mistyped token gives a 404 that
reads as "these endpoints are switched off", and a wrong database name gives a panel that starts,
signs in, and shows an empty Messages page with no error anywhere.

`--metrics-url` still overrides it, for reading as a separate less-privileged role. `--config-url` is
never derived: without it the panel can display everything and change nothing, and quietly handing it
a connection that can write would be a change of posture nobody asked for.

Check what it would use, without touching the host:

```bash
./scripts/fireflo-panel-install check --gateway-conf-dir /etc/fireflo
```

### Installing a second panel

```bash
sudo ./scripts/fireflo-panel-install install \
    --tenant websmsc --user websmsc --port 3001 \
    --gateway-conf-dir /etc/fireflo/websmsc
```

`--tenant NAME` puts the panel in `/srv/fireflo/NAME/panel/{app,conf,data}` under the unit
`fireflo-NAME-panel`. **The same word names the same instance to the gateway installer** — `tenant
websmsc` there is `/srv/fireflo/websmsc/gateway` — which is the point of it: one name per customer,
two products, nothing to keep in step by hand.

**Both together put the tenant in a directory you choose.** `--tenant websmsc --vhost /home/websmsc`
gives `/home/websmsc/panel/{app,conf,data}`, with the gateway installing alongside at
`/home/websmsc/gateway` from `--tenant websmsc --vhost /home/websmsc` there. That is the shape for a
per-customer virtualhost account: one home, both products, and the generated unit mounts a tmpfs over
`/home` so the panel cannot see any other customer's home at all.

```bash
sudo ./scripts/fireflo-panel-install install \
    --tenant websmsc --vhost /home/websmsc --user websmsc --port 3002 \
    --gateway-conf-dir /home/websmsc/gateway/conf
```

`--vhost PATH` **on its own** keeps its old meaning — `PATH/{app,conf,data}`, flat, with no product
subdirectory — because that is how the panels already installed under `/home/<name>` are laid out and
their update command has to keep working:

```bash
sudo ./scripts/fireflo-panel-install install \
    --vhost /home/websmsc --user websmsc \
    --service-name fireflo-panel-websmsc --port 3001 \
    --gateway-conf-dir /etc/fireflo/websmsc
```

Either way one flag sets three directories — `app` for the source and its build, `conf/panel.env` for
the environment, `data` for prepared exports — and `--app-dir`, `--conf-dir` and `--data-dir` still
override individually, in whichever order they are given.

Neither derives the **service account**: `--user` stays explicit, because a panel holding two
database passwords running as an account inferred from a path is a quiet failure.

**The generated unit mounts a tmpfs over `/home` and binds only that one virtualhost back in**, so
the panel cannot see any other account's home — that is what `--vhost` buys over typing three
directory flags, and it is why the layout and the isolation are one decision rather than two.

An existing account is reused untouched, including its primary group, which is not always named
after it. One panel per tenant or virtualhost: each needs its own `--port` (and its own
`--service-name`, unless `--tenant` named the unit for it), and the installer refuses to overwrite a unit belonging to a different install rather than leaving you with
two panels and one of them unreachable.

The application directory is a *subdirectory* of the virtualhost and never the virtualhost itself,
because `update` runs `rsync --delete` over it. The installer refuses any layout where that would
reach a home directory, the environment file or the exports.

Verbs are `check`, `install`, `update`, `service` and `passwd`. `update` rebuilds from the current
source and never touches the environment file; `service` regenerates the unit on an install that
already exists; `passwd` rolls the operator credential, below. `--dry-run` prints every command and
file and touches nothing.

### Resetting the operator password

```bash
sudo ./scripts/fireflo-panel-install passwd --tenant websmsc --user websmsc
# or, for a panel installed in a virtualhost
sudo ./scripts/fireflo-panel-install passwd --vhost /home/websmsc --user websmsc
```

Every verb takes whichever of `--tenant`, `--vhost` or the three directory flags the panel was
installed with; they are how it finds `panel.env`, and none of them is remembered between runs.

It writes a new password into `panel.env`, restarts the service, and prints the password **once**.
Nothing else stores it. The username comes from the file unless `--operator NAME` says otherwise, and
no rebuild is involved — this touches the environment file and the unit, not the application.

**A password change signs nobody out.** Sessions are JWTs signed with `AUTH_SECRET`, and nothing
re-checks the password after sign-in, so a session cookie taken before the reset keeps working. Add
`--rotate-secret` to roll that too, which invalidates every session immediately. A forgotten password
does not need it; a suspected compromise does, and the command says which case you are in rather than
leaving it to be assumed.

**There is deliberately no `--password` flag.** A password in an argument is a password in the shell
history and in the output of `ps` — the same reasoning as `--db-password-file` on the gateway's
installer. `--password-file PATH` takes one you have already chosen, and refuses an empty file:
an empty `OPERATOR_PASSWORD` disables sign-in entirely rather than accepting anything, which is a
lockout rather than a reset.

**Install the gateway first.** The gateway owns the database schema — this panel only reads and
writes rows in it — so `fireflo db migrate` has to have run before any page here will work. If the
gateway is on the same host, the installer copies the two operational tokens out of its
`fireflo.env` rather than making you retype them; they have to match exactly, and a mistyped one
produces a 404 that reads as "the endpoints are switched off".

**TLS is not optional and the installer does not set it up.** The panel speaks plain HTTP on
loopback, and an operator session over plain HTTP is a session anybody on the path can take. Put
nginx in front, proxy to the port, and pass `X-Forwarded-Proto` and `Host` through.

**Set `--public-url` as well.** Those forwarded headers do not decide where the panel redirects:
Next builds request URLs from the address it bound, so **Sign out lands on `http://localhost:PORT`**
until `AUTH_URL` names the public origin. It must be a bare origin — next-auth adopts a URL's path
as its base path, and `https://panel.example.com/panel` then makes every `/api/auth` call answer
"Bad request". Forward the headers anyway; they are what keeps secure-cookie handling and the access
log honest.

Two things worth knowing about the generated environment. There are no `export` prefixes, because
systemd's `EnvironmentFile` does not run a shell and rejects them — the same file is still
sourceable by hand. And `NODE_ENV=production` is set for the build as well as the run: it decides
whether the session cookie is marked secure, so a panel built in development mode hands out a cookie
that will travel over plain HTTP.

### Updating

```bash
git pull && sudo ./scripts/fireflo-panel-install update --tenant <name> --user <name> --group <name>
```

or, for a panel installed in a virtualhost:

```bash
git pull && sudo ./scripts/fireflo-panel-install update --vhost /home/<name> --user <name> --group <name>
```

`update` builds **before** it stops anything, so a failed build costs no downtime, then restarts and
verifies. It leaves `panel.env` completely alone — which also means it adds nothing new to it.

**`--vhost` and `--tenant` derive the directories and the unit name, but deliberately not the
account.** `PATH/app`, `PATH/conf`, `PATH/data` and the unit name all follow from either; `--user`
does not, because a wrong directory name is cosmetic and a wrong service account is a panel holding
two database passwords. Omit `--user` on a virtualhost install and the build fails at `npm ci`:

```
sh: 1: cd: can't cd to /home/<name>/app
```

That is not a missing directory — root has already created and populated it. It is the *service
account* being unable to enter another account's home. Name it and the same command works.

**`--port` is read back out of `panel.env`**, so `update`, `service` and `check` probe the port this
panel is actually on. It did not use to: the flag defaulted to 3000 whatever was deployed, and a
panel on 3001 either reported

```
fireflo-panel-install: the panel did not answer on http://127.0.0.1:3000/cp/login (last: 000).
```

while running perfectly, or — worse on a host with two panels — reported **success** because the
other one answered on 3000. Give `--port` explicitly only to move a panel.

**A genuine start failure looks different.** `status=226/NAMESPACE` in the journal means a directory
named in the unit's `BindPaths=` or `ReadWritePaths=` does not exist — the unit loads cleanly and
only fails to start, so `systemd-analyze verify` says nothing about it. Create the directory (owned
by the service account), or pass the `--data-dir` the install actually used.

Confirm the new build is really serving, rather than that something is listening — the version in
the wordmark comes from `package.json` at build time:

```bash
curl -s http://127.0.0.1:<port>/ | grep -o '>[0-9.]\+<'
```

`<port>` is whatever `PORT=` says in that instance's `panel.env` — the installer reads it back, but
this curl does not.

## The customer portal, per instance

`/` is not a separate deployment. The customer portal is a set of routes in this application, on
the same port and
under the same unit, so **whichever flag reaches the panel reaches its portal** — there is nothing
extra to install and no second service to update.

| | `--tenant NAME` | `--vhost PATH` |
| :--- | :--- | :--- |
| environment | `/srv/fireflo/NAME/panel/conf/panel.env` | `PATH/conf/panel.env` |
| unit | `fireflo-NAME-panel` | `fireflo-<basename>-panel` |
| portal | `<public-url>/` | `<public-url>/` |
| control panel | `<public-url>/cp` | `<public-url>/cp` |

A first install with the portal working from the start:

```bash
sudo ./scripts/fireflo-panel-install install \
    --tenant acme --user acme --port 3002 \
    --gateway-conf-dir /srv/fireflo/acme/gateway/conf \
    --public-url https://acme.example.com \
    --mis-base-url https://acme.example.com \
    --smtp-host smtp.example.com --smtp-from 'FireFlo <no-reply@example.com>' --smtp-secure false
```

Answer the **prompt** for the SMTP password rather than passing `--smtp-password`: an argument is
visible in shell history and in `ps`.

Both URLs are needed and they are not the same thing. `--public-url` becomes `AUTH_URL` and is what
stops a sign-out redirecting the operator to `localhost` — Next builds request URLs from the address
it bound, and no proxy header changes that. `--mis-base-url` becomes `MIS_PANEL_BASE_URL` and goes
*into the mail*: unset, the sign-in link is built relative and arrives as something no mail client
can follow. Give both as a **bare origin** — a path on `--public-url` is adopted as NextAuth's base
path and every `/api/auth` call then fails.

Updating the portal is updating the panel; there is no portal-specific verb:

```bash
sudo ./scripts/fireflo-panel-install update --tenant acme --user acme --group acme
```

```bash
sudo ./scripts/fireflo-panel-install update --vhost /home/websmsc --user websmsc --group websmsc
```

Use whichever the panel was installed with. `--tenant` on a panel installed in a virtualhost derives
`/srv/fireflo/NAME/panel`, finds no `panel.env` there, and stops with nothing touched.

### SMTP is not carried by an update

`update` never rewrites `panel.env`, so mail settings have to be added by hand and the service
restarted. Without them the portal can issue no sign-in link at all — and it will not tell you:
the portal answers a request identically whether SMTP is broken or the address has no account, by
design, so nobody can use it to test which addresses exist. Verify by asking for a link with a real
customer address and reading the journal, never by watching the page.

```bash
sudoedit /srv/fireflo/<name>/panel/conf/panel.env    # or <vhost>/conf/panel.env
```

```
FIREFLO_SMTP_HOST=smtp.example.com
FIREFLO_SMTP_PORT=587
FIREFLO_SMTP_USER=...
FIREFLO_SMTP_PASSWORD=...
FIREFLO_SMTP_SECURE=false
FIREFLO_SMTP_FROM=FireFlo <no-reply@example.com>
MIS_PANEL_BASE_URL=https://panel.example.com
AUTH_URL=https://panel.example.com
```

```bash
sudo systemctl restart fireflo-<name>-panel && journalctl -u fireflo-<name>-panel -f
```

`FIREFLO_SMTP_SECURE` selects implicit TLS and belongs to the port: `true` for 465, `false` for 587,
where the connection starts in clear and is upgraded — and that upgrade is now *required* rather than
merely offered, so a server that will not do STARTTLS fails loudly instead of sending the credential
in clear. `MIS_PANEL_BASE_URL` and `FIREFLO_SMTP_FROM` are both required alongside the host; the
mailer treats host-and-from as one setting.

When SMTP is genuinely absent the portal now says so — a distinct 503, `"Sign-in by email is not
available on this panel"` — rather than telling a customer a link is on its way. It is safe to be
distinct because it is checked **before any account is looked up**, so every address gets it and it
reveals nothing about who has an account.

### Update the gateway first

This panel lets customers submit sender IDs and templates, which land `PENDING`; only a gateway that
knows about `app_header.status` filters them out. Update and restart the gateway before the panel, or
a customer submission is served without anybody approving it.

## Running it locally

```bash
npm install
cp .env.local.example .env.local   # then fill it in
npm run dev
```

Three variables matter:

| Variable | Notes |
| :--- | :--- |
| `AUTH_SECRET` | Signs the session. `openssl rand -base64 64` |
| `OPERATOR_PASSWORD` | **Unset means nobody can sign in.** Missing configuration fails closed |
| `METRICS_DATABASE_URL` | The gateway's Postgres, read-only |

`OPERATOR_USERNAME` defaults to `operator`.

### Editing configuration

Five pages write; everything else reads. They go through `CONFIG_DATABASE_URL`, which is a
**separate** variable from `METRICS_DATABASE_URL` and separate on purpose: enabling writes against
the gateway's configuration should be a decision rather than a side effect of having a read URL.
Leave it unset and all four are off.

Everything the gateway reads is behind **one switch**, `smsg.config.source` — `FIREFLO_CONFIG_SOURCE`
in the environment.

| Pages | Tables | Live when the gateway runs with |
| :--- | :--- | :--- |
| Vendors, Servers | `app_worker`, `app_worker_property` | `smsg.config.source=db` |
| Pricing, Products › pricing | `app_rate_rule`, `app_rate_rule_condition` | `smsg.config.source=db` |
| Accounts › logins | `app_credential` | `smsg.config.source=db` |
| Routing | `app_route_table`, `app_route_rule` | `smsg.config.source=db` |
| Products, Filters, whitelist | `app_product`, `app_filter`, … | *— see below* |

It was four independent switches, one per domain, and keeping them in agreement by hand was the
thing most likely to waste an afternoon. The switch is read before the database is consulted, so it
lives in the environment and can never be in a table — meaning nothing here can check it for you,
only report what `/ops/health` says. With the gateway on file configuration, rows written here are
stored, valid, and ignored, and the affected pages say so at the top.

The last row is different: `app_product` and the panel-only catalogues have no file form, so the
gateway either always reads them (filters, whitelist) or never does (products). No switch applies.

⚠️ **The credentials switch is the dangerous one.** With `app_credential` empty and
`smsg.config.source=db`, the gateway publishes an empty credential map rather than ignoring it:
every bind and every REST call is refused at once, with no fallback to the file and nothing in the
logs naming the cause. Fill the table with `scripts/fireflo import credentials` before switching.

Also worth knowing:

- **Secrets are never sent to the browser**, and the two editors do it differently on purpose.
  Vendor and server settings use a `********` placeholder that means "leave it alone" on the way
  back. Credentials do not: a read reports only *whether* a password is stored, and a write says
  `unset`, `kept` or `set` with a value. That closes two things the placeholder cannot. A placeholder
  for a key with nothing stored resolves to empty and is skipped — harmless for a worker setting,
  but for a bind password it produces a row the gateway skips with a warning and no error, so the
  credential exists, is enabled, and is not there. And a password that genuinely is `********` stops
  being indistinguishable from the placeholder.
- **A rate rule's id is referenced by every call record it charged.** `cdr_submit.cost_rule_id` and
  `price_rule_id` point at `app_rate_rule.id` with no foreign key, so nothing warns. Saving a scope
  preserves the ids of the rules that survive; *deleting* a rule makes the history of what it charged
  unreadable, which is why **Retire** and not Delete is the ordinary way to stop one.
- **The gateway is the authority on whether a rule is valid.** The panel checks what it can, but a
  rule it accepts and the gateway cannot build fails at the gateway's next *poll* — at which point it
  keeps the prices it already had and says so in its own log. "Saved" does not mean "loaded".

Moving an existing deployment from `rates.conf` to the database is `scripts/fireflo import` in the
gateway repo. Run it with `--dry-run` first and read the report.

**Starting from nothing**, there is no file configuration to import — use `scripts/fireflo bootstrap`
after `db migrate`. It writes the least that will start: a `default` routing table, a listener, and
one login whose password it prints once. Without it the gateway refuses to start at all, because an
empty `app_route_table` leaves it with nowhere to send anything. It writes no vendor and no rates,
so this panel is where the rest goes in — Vendors first, then Pricing.

The gateway notices a change within one poll interval. **Apply now** asks it to re-read immediately
instead — the same thing `scripts/fireflo reload` does from a shell.

### Which database user to use

The gateway's own user is fine to start with, and is what `.env.local.example` shows. Nothing in
this codebase issues DDL, and the **read** path writes nothing at all —
[`lib/metrics-db.ts`](lib/metrics-db.ts) exposes only `query()`, and the module exists specifically to
keep the schema-creating helper in the sibling panel away from this database. Writes are confined to
[`lib/config-db.ts`](lib/config-db.ts) and reach the configuration tables — plus the two prepaid
credit tables, which is newer than the rest of this paragraph and is the one exception worth naming.
Nothing in the panel can touch `cdr_*`.

The credit exception is narrow on purpose. The panel writes `balance_ledger` rows and creates
`account_balance` rows at zero; it never writes the `balance` column itself. The gateway's recharge
poll remains the only thing that moves the live figure, so the panel records what it was told and the
gateway decides what that means.

A dedicated read-only role is worth the trouble when the panel runs somewhere shared, when more than
one person has the connection string, or when it is not on your own machine — because the tables
behind it are billing records, and with the gateway's user a bug in a query could write to them or
drop them. A grant is a guarantee where a convention is only an intention.

It needs a superuser to create, since the gateway's user typically has no `CREATEROLE`:

```sql
CREATE ROLE fireflo_ro LOGIN PASSWORD 'choose-something';
GRANT CONNECT ON DATABASE omni5 TO fireflo_ro;
GRANT USAGE ON SCHEMA public TO fireflo_ro;
GRANT SELECT ON cdr_submit, cdr_final, cdr_rejected, account_balance TO fireflo_ro;

-- Four columns, not the table. The metrics side reads app_credential for one thing -- naming the
-- accounts that exist but have sent nothing -- and that needs no secret. A whole-table grant here
-- would let the read-only role read every bind password and API key in the deployment, which is
-- precisely what it exists not to do.
--
-- `enabled` is in the list because the query filters on it, and PostgreSQL checks column
-- privileges on every column a statement mentions, WHERE included. Grant only the three columns
-- that come back and the query fails with "permission denied for column enabled" -- which reads
-- like a bug in the panel rather than a grant that is one column short.
GRANT SELECT (account_id, system_id, product, enabled) ON app_credential TO fireflo_ro;
```

Then point `METRICS_DATABASE_URL` at it.

> **`cdr_rejected` is a correction, like the two below.** It was missing from this block from the
> moment the Refused page shipped, so a role built strictly from these instructions has never been
> able to show a refused message — the page fails rather than coming back empty. Deployments that
> granted more broadly were unaffected.
>
> **`cdr_pnl` has gone from this block.** It is a real view and the grant did no harm, but nothing in
> the panel reads it. If you also use this role to query profit and loss by hand, put it back.

**On a role that already exists, the column grant alone changes nothing.** Column privileges do not
replace a table-wide one — they sit beside it, and the wider grant still wins. An existing
`fireflo_ro` needs the table grant taken away first:

```sql
REVOKE SELECT ON app_credential FROM fireflo_ro;
GRANT SELECT (account_id, system_id, product, enabled) ON app_credential TO fireflo_ro;
REVOKE SELECT ON cdr_pnl FROM fireflo_ro;   -- optional; see above
GRANT SELECT ON cdr_rejected TO fireflo_ro; -- the correction
```

Run the `SELECT account_id, system_id, product FROM app_credential WHERE enabled` the panel uses
afterwards, as `fireflo_ro`, to confirm it still works — and `SELECT password FROM app_credential`
to confirm it now does not.

The **write** role, for `CONFIG_DATABASE_URL`, needs rather more — and one grant that is easy to miss:

```sql
CREATE ROLE fireflo_rw LOGIN PASSWORD 'choose-something';
GRANT CONNECT ON DATABASE omni5 TO fireflo_rw;
GRANT USAGE ON SCHEMA public TO fireflo_rw;
GRANT SELECT, INSERT, UPDATE, DELETE ON
      app_worker, app_worker_property,
      app_product,
      app_rate_rule, app_rate_rule_condition,
      app_credential,
      app_whitelist_policy, app_header, app_template TO fireflo_rw;
GRANT SELECT ON app_rate_rule_filter, cdr_submit TO fireflo_rw;

-- Prepaid credit. INSERT and UPDATE only, and no DELETE: a ledger is append-only, and an operator
-- who could remove a top-up could remove the evidence of one. Without these, Add credit answers
-- 503 with a sentence naming the missing grant rather than a driver error.
GRANT SELECT, INSERT, UPDATE ON account_balance, balance_ledger TO fireflo_rw;

-- Accounts and the customer portal. The panel creates, edits and deletes catalogue rows, and
-- sign-in links are looked up against app_user and spent in app_login_token -- so without these
-- the portal cannot issue a link OR redeem one, and the error surfaces as a failed insert rather
-- than a missing grant.
GRANT SELECT, INSERT, UPDATE, DELETE ON app_account TO fireflo_rw;
GRANT SELECT, INSERT, UPDATE ON app_login_token TO fireflo_rw;

-- Who may sign in (V1.52.0). No DELETE: a user is disabled, never removed, so the access logs
-- keep pointing at a person. The gateway's `fireflo user` command writes this table as its owner.
GRANT SELECT, INSERT, UPDATE ON app_user TO fireflo_rw;

-- The two access logs. INSERT and SELECT only, deliberately: no DELETE and no UPDATE, so
-- "kept forever" is enforced by the grant rather than by everyone remembering it is meant to be.
GRANT INSERT, SELECT ON app_customer_access_log, app_operator_access_log TO fireflo_rw;

-- Routing and the filter library. Both pages read and write these, so without them the Routing and
-- Filters pages fail on their first query rather than showing an empty list.
GRANT SELECT, INSERT, UPDATE, DELETE ON
      app_route_table, app_route_rule, app_route_rule_condition, app_route_rule_filter,
      app_filter, app_filter_condition TO fireflo_rw;

-- The TLV catalogue, and the suggestions customers raise against it.
GRANT SELECT, INSERT, UPDATE, DELETE ON app_tlv_definition, app_tlv_suggestion TO fireflo_rw;

-- Read-only on purpose. The panel reads platform settings from here -- the currency, the decimal
-- length, the mandatory TLV list -- and never writes them. The gateway owns this table.
GRANT SELECT ON app_config TO fireflo_rw;

-- All BIGSERIAL. Without these every insert fails at runtime with
-- "permission denied for sequence", which does not obviously read as a missing grant.
GRANT USAGE, SELECT ON SEQUENCE app_rate_rule_id_seq, app_credential_id_seq,
      app_header_id_seq, app_template_id_seq, balance_ledger_id_seq,
      app_customer_access_log_id_seq, app_operator_access_log_id_seq, app_user_id_seq,
      app_route_rule_id_seq TO fireflo_rw;
```

> **Several of these grants are corrections, not new requirements.** `app_account` and
> `app_login_token` were missing since the customer portal shipped, so a role built strictly from
> these instructions could neither send nor redeem a sign-in link. Routing, the filter library, the
> TLV catalogue and `app_config` were missing for as long as those pages have existed. Deployments
> that granted more broadly were unaffected and need no change.
>
> This block is now checked against the queries rather than remembered: every table either
> connection actually names was enumerated from the source, and this is the result. If a page you
> use is failing on a permission error, that is a bug in this list.

**`fireflo_rw` can now read every bind password and API key in the deployment.** That follows
unavoidably from being able to edit them, and it is a material change to what this database user
*is* — worth knowing here rather than discovering. The panel itself never selects those columns; the
grant is what makes the editing possible at all.

The read-only role is already narrowed to four non-secret columns of `app_credential`, above — it is
the write role that can read secrets, and only because editing them requires it.

`app_rate_rule_filter` is SELECT-only on purpose: the panel reads named filters so it can show that a
rule is narrowed by one, and cannot edit them yet. A rule that lost a filter reference would not
fail — it would match *more*, at whatever amount it was carrying.

### The index behind time-ordered browsing

`cdr_submit` was indexed on `(vendor | account_id | product, submitted_at)` and **not on
`submitted_at` alone**, so a query filtering only by time sorted the whole table. The gateway's
`V1.5.0` migration adds it:

```sql
CREATE INDEX CONCURRENTLY idx_cdr_submit_time ON cdr_submit (submitted_at DESC, id DESC);
```

Both columns, both descending, and that is not decoration — it is what the Messages page's keyset
paging orders by, so the scan returns rows already in order and the sort disappears. An index on
`submitted_at` alone would not serve it.

---

## Why the queries look the way they do

Four properties of the call-record schema make the obvious query wrong — and wrong in a way that
produces *plausible* numbers rather than obvious nonsense. All four are handled in
`lib/metrics-queries.ts`:

1. **A retried message writes another submit row.** `COUNT(*)` counts attempts, not messages. Both
   are reported, because vendor load really is attempts while customer volume really is messages.
2. **Revenue repeats on every attempt row**, but the customer is charged once. Revenue is summed
   over first attempts only.
3. **Cost is genuinely per attempt** — each one was handed to a vendor — so cost is summed across
   all of them.
4. **`cdr_final` has no uniqueness constraint.** Concurrent receipts append two rows by design, so
   the outcome is taken through a `LATERAL … LIMIT 1` rather than a plain join.

Because revenue and cost are counted over different row sets, **margin is computed from those two
sums rather than by summing the stored `margin` column.** That column is correct per row, but
summing it is not the same thing — and on live data the two already disagree: one message cost 450
at a vendor and was never billed (`margin_status = UNKNOWN`), so its margin is NULL. Summing the
column silently omits that loss; revenue − cost keeps it.

Money is a `BIGINT` scaled by 10 000 and lives only on part 1 of a message. It is divided for
display and nowhere else.

### Paging the Messages page

`lib/cdr-queries.ts` pages by **keyset**, not `OFFSET`. `submitted_at` is not unique — messages
accepted in the same instant are ordinary — so the sort key is the pair `(submitted_at, id)` and each
page asks for rows strictly before the last pair it saw:

```sql
WHERE (s.submitted_at, s.id) < ($1::timestamptz, $2::bigint)
ORDER BY s.submitted_at DESC, s.id DESC
```

`OFFSET` on a table being written to continuously repeats and drops rows at page boundaries, and the
rows that vanish are the ones nobody saw, so nobody reports it. The row-wise comparison is written as
a tuple rather than expanded into `ts < $1 OR (ts = $1 AND id < $2)` because the expanded form is
where the off-by-one lives — and Postgres pushes the tuple straight into the index:

```
Index Cond: (ROW(submitted_at, id) < ROW($1, $2))
```

That index is `idx_cdr_submit_time`, added by the gateway's `V1.5.0` migration. Without it a
time-ordered browse sorts the whole table. There is deliberately **no total row count** on the page:
`COUNT(*)` over a filtered set is the one query here that does not stay fast as the table grows.

### Exports

CSV exports are a request-and-collect flow, not a download: `POST /api/control/cdrs/export` records
the request and returns immediately, a worker pages the same keyset query in 5,000-row batches, and
the file is collected afterwards. Batching is what keeps each query inside the pool's 10-second
`statement_timeout` and stops one export monopolising eight connections shared with the dashboard's
polling.

Job state is a **directory of JSON manifests plus CSVs** under `CDR_EXPORT_DIR`, not a database
table. The call-record database is read-only from this panel, and the export queue is state only the
panel owns; putting it in the gateway's schema would need a migration in the other repo every time
this feature changed. The trade is that it is local disk — correct for one panel process, wrong
behind a load balancer, where a file prepared by one instance is a 404 on the other.

Exported fields that came off the wire are prefixed with `'` when they start with `=`, `+`, `-` or
`@`, because Excel and Sheets execute those as formulas. A source address is whatever the customer
put there.

---

## What it does not show

**SMS business metrics from `/q/metrics`.** That endpoint carries stock JVM, HTTP, Vert.x and Netty
families and no FireFlo ones at all — nothing there counts messages, deliveries or per-vendor
throughput, and adding them means instrumenting the gateway with Micrometer first. The Runtime page
visualises what it does carry, and says on the page that it is the process rather than the traffic.

Live *traffic* state — bind counts, queue depth, measured TPS, sessions and messages awaiting a
receipt — comes from `/ops/health` instead, and is on the Live health and Vendors pages. Both that
endpoint and `/q/metrics` are on the gateway's management port rather than under `/secure`, which
any customer credential can read.

**Credential secrets.** The Accounts page is built from traffic, not from the credential table.
Where that table *is* read — to surface a provisioned account that has sent nothing — the query
selects `account_id`, `system_id` and `product` and nothing else. `password` and `api_key` are
never read, so no change to the rendering can leak them.

**Prepaid credit, unless it is enabled.** The panel cannot see the gateway's `smsg.balance.enabled`,
so it infers from whether any balance rows exist and shows "not enforced" when none do. That is a
heuristic: an enabled gateway that has never been funded looks the same.

**Anything the file CDR sink wrote.** With `smsg.cdr.sink=file` the records are JSON lines on the
gateway's disk and there is no database to query.

---

## Security notes

- Every API route calls `requireOperator()` as its first statement and returns **404**, not 403 —
  a 403 confirms there is something there to be forbidden from. Hiding the nav is presentation; the
  route check is the control.
- The operator credential is deliberately not a gateway messaging credential. The gateway has no
  admin role, and its `/secure/*` prefix is readable by every customer who can send an SMS.
- The session cookie has no `maxAge`, so it dies with the browser.
- **There is no user table.** `OPERATOR_USERNAME` and `OPERATOR_PASSWORD` in `panel.env` are the
  whole operator account, compared in constant time so a wrong username and a wrong password cannot
  be told apart by timing. With `OPERATOR_PASSWORD` unset there is no way in at all — not "any
  password works", not "no password required". Missing configuration fails closed.
- The password is stored as written rather than hashed, and `panel.env` is mode 600 because of it.
  That file also holds both database URLs and both gateway tokens, so anyone who can read the
  password already has everything else; hashing it would protect nothing that is not already lost.
  `fireflo-panel-install passwd` is the supported way to change it.
- **The customer half is a separate session, not a role.** A customer signs in through a single-use
  emailed token and gets its own cookie; `requireCustomer()` resolves the account from that cookie
  and every customer query is scoped by it server-side. An operator cookie does not open a portal
  page and a customer cookie does not open `/cp`. Neither guard consults the other's.
- **A customer cannot name another customer's anything.** Every id that arrives in a request — a
  login to rotate, a registration to edit, a child account to fund — is resolved against the
  session's account before it is used, so an id from somewhere else is a 404 rather than a
  forbidden.
- **Two access logs**, one per audience: who signed in, from what address, and what they did. Neither
  records a password, a token, an API key or a message body. The playground records that a call
  happened and to which endpoint, never the body it carried.
- **The playground presents the panel's address to the gateway, not the customer's.** A customer with
  a non-empty `allowedIps` therefore gets a 403 from it while their own integration works. The route
  detects that case and says so in those words rather than showing a bare 403 that reads as a wrong
  password.

---

## Every setting, in one table

The gateway repository's `docs/09-configuration-reference.md` carries a **Control Panel
Configuration** section: every variable this application reads, which are required, and which hold
secrets. It is there rather than here because an operator configures the two together and reads one
page while doing it.

The long-form notes for each one — why `AUTH_URL` must be a bare origin, why `GATEWAY_API_URL` and
`GATEWAY_OPS_URL` are different ports — stay in [conf.example/panel.env](conf.example/panel.env),
which is the file being edited at the time.
