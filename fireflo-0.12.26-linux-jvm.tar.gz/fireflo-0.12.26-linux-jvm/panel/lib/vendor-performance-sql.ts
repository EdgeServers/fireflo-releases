/**
 * Per-vendor traffic from the gateway's hourly summary, with only the edges read from the records.
 *
 * <p>Database-free so the text can be asserted without a connection; `vendorPerformance` in
 * `metrics-queries.ts` runs it.
 *
 * <h2>Why it exists</h2>
 *
 * <p>The vendor page and the Vendors list read every call record in the range on every load: a
 * distinct count of message ids, a DISTINCT ON over every message, and a receipt lookup per message.
 * On 2.9 million rows that ran past the panel's 10-second statement timeout; at ten million a day it
 * could never finish. `usage_hourly` already holds, per vendor and UTC hour, each message's count,
 * outcome and cost under the vendor that carried it, and from gateway V1.97.0 `attempts` under the
 * vendor each attempt went to. So the whole hours come from there, and only the part of the first
 * hour before the range's first whole hour and the minute or two past the summary's watermark are
 * read from the records -- a few small windows instead of the range.
 *
 * <h2>The three windows</h2>
 *
 * <pre>
 *   [since, LEAST(first_hour, seam))   records   the range's opening part-hour
 *   hours in [first_hour, seam)        summary   usage_hourly, whole hours plus the partial hour
 *                                                the watermark sits in, which the gateway's tick
 *                                                has filled up to exactly the watermark
 *   [seam, until)                      records   what the summary has not reached yet
 * </pre>
 *
 * <p>`seam` is the watermark clamped into the range. With a watermark before the first whole hour the
 * middle is empty and the two record windows meet at the seam, so every instant is counted once.
 *
 * <h2>What each figure means</h2>
 *
 * <ul>
 *   <li><b>attempts</b> -- submits to this vendor, refused ones included. Summary: `attempts`.</li>
 *   <li><b>messages</b> -- messages this vendor carried: the representative attempt, as UsageRollup
 *       picks it. Summary: `submitted`.</li>
 *   <li><b>delivered / failed / pending</b> -- those messages' outcomes; failed includes expired.
 *       Summary: `delivered`, `failed + expired`, `pending_at_rollup` (as of the hour's last restate,
 *       which the gateway repeats until the receipt deadline has passed).</li>
 *   <li><b>cost</b> -- only the money row carries one, so a sum over attempts is exact.</li>
 * </ul>
 *
 * <p>$1 since, $2 until, $3 the summary's watermark.
 */

import { partOne, representativeKeys } from "./cdr-grain.ts";
import { OUTCOME_LATERAL } from "./usage-summary-sql.ts";

export function vendorPerformanceHourlySql(vendorAttempt: boolean): string {
  return `
  WITH cut AS (
      SELECT $1::timestamptz AS since,
             $2::timestamptz AS until,
             LEAST(GREATEST($3::timestamptz, $1::timestamptz), $2::timestamptz) AS seam,
             --the first whole UTC hour at or after since
             (date_trunc('hour', ($1::timestamptz - interval '1 microsecond') AT TIME ZONE 'UTC')
                 + interval '1 hour') AT TIME ZONE 'UTC' AS first_hour
  ),
  edge AS (
      SELECT c.*
        FROM cdr_submit c, cut
       WHERE ${partOne("c")}
         AND ((c.submitted_at >= cut.since AND c.submitted_at < LEAST(cut.first_hour, cut.seam))
           OR (c.submitted_at >= cut.seam AND c.submitted_at < cut.until))
  ),
  edge_attempts AS (
      SELECT COALESCE(vendor, '') AS vendor, COUNT(*) AS attempts, COALESCE(SUM(cost), 0) AS cost
        FROM edge
       GROUP BY 1
  ),
  edge_carried AS (
      SELECT DISTINCT ON (gateway_msg_id) gateway_msg_id, part_no, vendor
        FROM edge
       ORDER BY gateway_msg_id, ${representativeKeys("", vendorAttempt)}
  ),
  edge_outcomes AS (
      SELECT COALESCE(s.vendor, '') AS vendor,
             COUNT(*) AS messages,
             COUNT(*) FILTER (WHERE o.final_state = 'DELIVERED') AS delivered,
             COUNT(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED','EXPIRED')) AS failed,
             COUNT(*) FILTER (WHERE o.final_state IS NULL) AS pending
        FROM edge_carried s${OUTCOME_LATERAL}
       GROUP BY 1
  ),
  rolled AS (
      SELECT h.vendor,
             SUM(h.attempts) AS attempts,
             SUM(h.cost_total) AS cost,
             SUM(h.submitted) AS messages,
             SUM(h.delivered) AS delivered,
             SUM(h.failed + h.expired) AS failed,
             SUM(h.pending_at_rollup) AS pending
        FROM usage_hourly h, cut
       WHERE h.hour >= cut.first_hour AND h.hour < cut.seam
       GROUP BY 1
  ),
  merged AS (
      SELECT vendor, attempts, cost, 0 AS messages, 0 AS delivered, 0 AS failed, 0 AS pending FROM edge_attempts
      UNION ALL
      SELECT vendor, 0, 0, messages, delivered, failed, pending FROM edge_outcomes
      UNION ALL
      SELECT vendor, attempts, cost, messages, delivered, failed, pending FROM rolled
  )
  SELECT NULLIF(vendor, '') AS vendor,
         SUM(attempts)  AS attempts,
         SUM(messages)  AS messages,
         SUM(cost)      AS cost,
         SUM(delivered) AS delivered,
         SUM(failed)    AS failed,
         SUM(pending)   AS pending
    FROM merged
   GROUP BY 1
  --a vendor-'' summary row that only holds refusals (V1.91.0 keys them there) adds nothing here
  HAVING SUM(attempts) > 0 OR SUM(messages) > 0
   ORDER BY SUM(attempts) DESC`;
}
