"use client";
import { useMemo } from "react";
import CodeMirror from "@uiw/react-codemirror";
import { python } from "@codemirror/lang-python";
import { java } from "@codemirror/lang-java";
import { linter, lintGutter, type Diagnostic } from "@codemirror/lint";
import { useTheme } from "@/components/ThemeProvider";

export interface CodeError {
  line: number;
  column?: number | null;
  message: string;
}

/**
 * CodeMirror 6 for a preprocessor's source. Loaded only on the workbench page, through
 * `next/dynamic`, so no other page carries the editor.
 *
 * <p>`errors` are the gateway's own check results -- the host's `python3` or `javac`, not a linter
 * running in the browser -- drawn as diagnostics on their line. They are the answer for the text
 * that was checked, so they are cleared by the caller as soon as the text changes.
 */
export default function CodeEditor({
  value,
  onChange,
  language,
  readOnly,
  errors,
}: {
  value: string;
  onChange: (next: string) => void;
  language: "python" | "java" | "text" | "other";
  readOnly?: boolean;
  errors: CodeError[];
}) {
  const { resolvedTheme } = useTheme();
  //rebuilt when the check results change: CodeMirror reconfigures in place and the new linter
  //draws them at once, without the editor losing its text, selection or scroll position
  const extensions = useMemo(() => {
    const lang = language === "python" ? [python()] : language === "java" ? [java()] : [];
    const lint = linter((v) => {
      const doc = v.state.doc;
      return errors.flatMap((e): Diagnostic[] => {
        if (e.line < 1 || e.line > doc.lines) return [];
        const line = doc.line(e.line);
        const from = Math.min(line.to, line.from + Math.max(0, (e.column ?? 1) - 1));
        return [{ from, to: Math.max(from, line.to), severity: "error", message: e.message }];
      });
    }, { delay: 0 });
    return [...lang, lint, lintGutter()];
  }, [language, errors]);

  return (
    <CodeMirror
      value={value}
      onChange={onChange}
      extensions={extensions}
      readOnly={readOnly}
      editable={!readOnly}
      theme={resolvedTheme === "dark" ? "dark" : "light"}
      minHeight="420px"
      basicSetup={{ foldGutter: false, highlightActiveLine: !readOnly, autocompletion: true }}
      className="text-[13px]"
    />
  );
}
