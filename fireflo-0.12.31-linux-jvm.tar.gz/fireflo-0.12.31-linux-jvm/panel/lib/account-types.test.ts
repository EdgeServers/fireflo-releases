import { strict as assert } from "node:assert";
import { test } from "node:test";
import { newAccountIdProblem, validateAccount } from "./account-types.ts";

const taken = ["acme-au", "telstra-a"];

test("a new id must survive a URL, a rate scope and a system id unchanged", () => {
  assert.match(newAccountIdProblem("bad id!", taken) ?? "", /letters, digits, dots, dashes and underscores/);
  assert.match(newAccountIdProblem(" acme", taken) ?? "", /space at one end/);
  assert.match(newAccountIdProblem("x".repeat(65), taken) ?? "", /too long/);
  assert.match(newAccountIdProblem("", taken) ?? "", /required/);
});

test("a vendor's name is refused whatever its case, so a rate scope never names two things", () => {
  assert.match(newAccountIdProblem("telstra-a", taken) ?? "", /already in use/);
  assert.match(newAccountIdProblem("TELSTRA-A", taken) ?? "", /already in use/);
  assert.match(newAccountIdProblem("Acme-AU", taken) ?? "", /already in use/);
});

test("a free, well-formed id passes", () => {
  assert.equal(newAccountIdProblem("acme-nz", taken), null);
  assert.equal(newAccountIdProblem("acct_1002.v2", taken), null);
});

test("an existing row keeps the lenient rule: adopted ids are whatever the wire carries", () => {
  assert.equal(validateAccount({ id: "bad id!", email: null, enabled: true }), null);
  assert.match(validateAccount({ id: " acme", email: null, enabled: true }) ?? "", /space at one end/);
});
