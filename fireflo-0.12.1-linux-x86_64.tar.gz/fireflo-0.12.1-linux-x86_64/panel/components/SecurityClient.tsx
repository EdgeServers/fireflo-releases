"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Antenna, Globe, ShieldBan, UserX } from "lucide-react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { Button, buttonClasses } from "@/components/ui/button";
import { isAdminSession } from "@/lib/roles";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import { HealthStrip } from "@/components/CardBits";
import { StatCard } from "@/components/StatCard";
import { SignInSummaryCard } from "@/components/SignInSummaryCard";
import { ClientWatchCard } from "@/components/ClientWatchCard";
import {
  hourlyCounts,
  reasonLabel,
  surfaceLabel,
  type BlockedAddress,
  type SecurityEvent,
  type SecuritySurface,
} from "@/lib/security-events";

/**
 * Who was refused, and who is blocked.
 *
 * <p>Blocked sits above the refusals because it is the actionable state and the refusals are the
 * evidence for it. The three surfaces share ONE table rather than three: the same actor moves
 * between them — the address working through system ids on 2775 is often the one trying the panel
 * afterwards — and three tables would hide exactly that.
 *
 * <p>The column is "Tried as", not "User". Nothing here authenticated, so a name in it is an
 * attempted name; rendering it as an identity would put a customer's name against somebody else's
 * attack. And the reason never says which half of a credential was wrong, because the gateway
 * compares in constant time precisely so that it does not.
 *
 * <p><strong>Every source says separately why it is empty.</strong> A gateway that cannot be
 * reached, a refusal log that is switched off, and a host with no fail2ban all produce no rows, and
 * an operator has to be able to tell which. That is why the notes below are rendered rather than
 * summarised into one "nothing to show".
 */

interface SourceState {
  reachable?: boolean;
  present?: boolean;
  state?: string | null;
  truncated?: boolean;
  note?: string | null;
  path?: string;
  /** True when the list came from fail2ban itself rather than from the notify action's file. */
  live?: boolean;
  historyPresent?: boolean;
  canUnban?: boolean;
  unbanCommand?: string;
}

interface Payload {
  events: SecurityEvent[];
  blocked: BlockedAddress[];
  sources: {
    gateway: SourceState;
    operator: SourceState;
    fail2ban: SourceState;
  };
}

const WINDOWS = [
  { id: "1h", label: "Last hour", hours: 1 },
  { id: "24h", label: "Last 24 hours", hours: 24 },
  { id: "7d", label: "Last 7 days", hours: 24 * 7 },
  { id: "all", label: "Everything kept", hours: 0 },
] as const;

type WindowId = (typeof WINDOWS)[number]["id"];

export function SecurityClient() {
  const { data: session } = useSession();
  const admin = isAdminSession(session);
  const [data, setData] = useState<Payload | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [windowId, setWindowId] = useState<WindowId>("24h");
  const [surface, setSurface] = useState<SecuritySurface | "all">("all");
  const [busy, setBusy] = useState<string | null>(null);
  /**
   * When the data on screen was read.
   *
   * <p>The window is measured from here rather than from `Date.now()` during render. Reading the
   * clock while rendering is impure -- the cutoff would move on every re-render, so a row could
   * drop out of "the last hour" because something unrelated changed -- and this is also the more
   * honest reading: the window is relative to the moment these events were fetched.
   */
  const [readAt, setReadAt] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/control/security", { cache: "no-store" });
      const body = await res.json();
      if (!res.ok) {
        throw new Error(body?.error ?? "Could not read the security log.");
      }
      setData(body.data as Payload);
      setReadAt(Date.now());
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  //filtered once, and both the table and the chart read the result. A chart built from its own
  //pass over the data eventually disagrees with the rows under it, and nothing would say so
  const shown = useMemo(() => {
    const events = data?.events ?? [];
    const hours = WINDOWS.find((w) => w.id === windowId)!.hours;
    const cutoff = hours === 0 || readAt === null ? 0 : readAt - hours * 3_600_000;
    return events.filter((e) => {
      if (surface !== "all" && e.surface !== surface) {
        return false;
      }
      if (cutoff === 0 || !e.at) {
        return true;
      }
      const at = Date.parse(e.at);
      return Number.isNaN(at) || at >= cutoff;
    });
  }, [data, windowId, surface, readAt]);

  const buckets = useMemo(() => hourlyCounts(shown), [shown]);
  const counts = useMemo(() => {
    const by = { smpp: 0, rest: 0, panel: 0, portal: 0 };
    for (const event of shown) {
      by[event.surface] += 1;
    }
    return by;
  }, [shown]);

  const unban = useCallback(
    async (jail: string, ip: string) => {
      setBusy(`${jail} ${ip}`);
      try {
        const res = await fetch("/api/control/security/unban", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ jail, ip }),
        });
        const body = await res.json();
        if (!res.ok) {
          throw new Error(body?.error ?? "The unban did not complete.");
        }
        await load();
      } catch (err) {
        setError(err instanceof Error ? err.message : String(err));
      } finally {
        setBusy(null);
      }
    },
    [load]
  );

  const sources = data?.sources;
  const canUnban = Boolean(sources?.fail2ban.canUnban);

  return (
    <>
      <PageHeader
        title="Security"
        description="Who was refused, and who is currently blocked. FireFlo records the refusals; fail2ban does the blocking."
        actions={
          <div className="flex flex-wrap gap-2">
            {/* who may sign in belongs with who was refused; it has no nav entry of its own, and only
                an admin may open it */}
            {admin && (
              <Link href="/cp/users" className={buttonClasses({ variant: "outline" })}>
                Users
              </Link>
            )}
            <Button variant="outline" onClick={() => void load()} disabled={loading}>
              {loading ? "Reading…" : "Refresh"}
            </Button>
          </div>
        }
      />

      {error && <HealthStrip tone="destructive">{error}</HealthStrip>}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard title="SMPP binds" value={String(counts.smpp)} icon={Antenna} loading={loading} />
        <StatCard title="REST API" value={String(counts.rest)} icon={Globe} loading={loading} />
        <StatCard
          title="Control panel"
          value={String(counts.panel + counts.portal)}
          hint={`${counts.panel} operator, ${counts.portal} portal`}
          icon={UserX}
          loading={loading}
        />
        <StatCard
          title="Blocked now"
          value={String(data?.blocked.length ?? 0)}
          icon={ShieldBan}
          loading={loading}
          tone={data && data.blocked.length > 0 ? "negative" : "default"}
        />
      </div>

      {/* two columns from xl: the evidence on the left, and on the right a live watch of one address
          -- usually one just read off the left. Wider than the usual 20rem rail so a PDU line stays
          readable; below xl it stacks under the rest */}
      <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_28rem]">
      <div className="min-w-0 space-y-4">
      {/* the database view, beside the file-and-fail2ban one: the file is what bans, the table is
          what people read, and the two agreeing is itself worth being able to see */}
      <SignInSummaryCard days={7} />

      <Card>
        <CardHeader>
          <CardTitle>Currently blocked</CardTitle>
        </CardHeader>
        <CardContent>
          {sources && !sources.fail2ban.present ? (
            <div className="space-y-3 text-sm text-muted-foreground">
              <p>{sources.fail2ban.note}</p>
              {/* WHERE it looked, labelled, because the next question is always that one -- and an
                  empty list must never read the same as a host with nothing set up. Each path
                  appears exactly once: the sentence above used to repeat the first of them */}
              <dl className="space-y-1 text-xs">
                <div className="flex flex-wrap gap-x-2">
                  <dt className="w-40">To ask fail2ban</dt>
                  <dd className="font-mono">{sources.fail2ban.unbanCommand}</dd>
                </div>
                <div className="flex flex-wrap gap-x-2">
                  <dt className="w-40">For recorded bans</dt>
                  <dd className="font-mono">{sources.fail2ban.path}</dd>
                </div>
              </dl>
              {/* names the VERB, not the flag. This said "reinstalling with --with-fail2ban",
                  which is the one route that cannot work on a host that already has an install:
                  `install` refuses outright, and `update` accepted the flag and dropped it. An
                  operator followed this exactly and got a missing file */}
              <p className="text-xs">
                Neither is on this host. Set them up with{" "}
                <code className="font-mono">sudo fireflo-install fail2ban</code>, and fill in the
                never-ban list before you do: a ban is on an address, and an address usually
                carries a whole customer.
              </p>
            </div>
          ) : !data?.blocked.length ? (
            <p className="text-sm text-muted-foreground">Nothing is blocked.</p>
          ) : (
            <div>
              <TableInCard>
                <THead>
                  <tr>
                    <TH>Address</TH>
                    <TH>Jail</TH>
                    <TH align="right">Failures</TH>
                    <TH>Blocked since</TH>
                    <TH>Lifts</TH>
                    <TH />
                  </tr>
                </THead>
                <TBody>
                  {data.blocked.map((row) => (
                    <TR key={`${row.jail} ${row.ip}`}>
                      <TD className="font-mono">{row.ip}</TD>
                      <TD muted>{row.jail}</TD>
                      <TD num>{row.failures}</TD>
                      <TD className="whitespace-nowrap">{when(row.since)}</TD>
                      <TD muted className="whitespace-nowrap">
                        {row.until ? when(row.until) : "does not expire"}
                      </TD>
                      <TD align="right">
                        {canUnban ? (
                          <Button
                            variant="outline"
                            size="sm"
                            disabled={busy === `${row.jail} ${row.ip}`}
                            onClick={() => void unban(row.jail, row.ip)}
                          >
                            {busy === `${row.jail} ${row.ip}` ? "Releasing…" : "Unban"}
                          </Button>
                        ) : null}
                      </TD>
                    </TR>
                  ))}
                </TBody>
              </TableInCard>
              {/* which source answered, because they can disagree and the live one is the truth.
                  A ban made by hand, or before the notify action existed, is in fail2ban and not in
                  the file -- so a page reading only the file would say an address is free while
                  its traffic is still being dropped */}
              <p className="px-4 pt-3 text-xs text-muted-foreground">
                {sources?.fail2ban.live
                  ? "Asked fail2ban directly, so this is what is blocking traffic right now."
                  : "fail2ban could not be asked, so this is reconstructed from the recorded bans "
                    + "and releases. A ban made outside FireFlo would not appear here."}
              </p>
              {!canUnban && (
                <p className="px-4 pt-3 text-xs text-muted-foreground">
                  Unbanning from here is not set up on this host. Release one on the host with{" "}
                  <code className="font-mono">
                    sudo fail2ban-client set &lt;jail&gt; unbanip &lt;address&gt;
                  </code>
                  .
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex-row flex-wrap items-center gap-2 space-y-0">
          <CardTitle>Recent failed logins</CardTitle>
          <div className="ml-auto flex flex-wrap gap-2">
            <select
              aria-label="Surface"
              className="h-9 rounded-md border border-border bg-background px-2 text-sm"
              value={surface}
              onChange={(e) => setSurface(e.target.value as SecuritySurface | "all")}
            >
              <option value="all">Every surface</option>
              <option value="smpp">SMPP</option>
              <option value="rest">REST</option>
              <option value="panel">Operator</option>
              <option value="portal">Portal</option>
            </select>
            <select
              aria-label="Window"
              className="h-9 rounded-md border border-border bg-background px-2 text-sm"
              value={windowId}
              onChange={(e) => setWindowId(e.target.value as WindowId)}
            >
              {WINDOWS.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.label}
                </option>
              ))}
            </select>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <SourceNotes sources={sources} />

          {buckets.length > 1 && <RateChart buckets={buckets} />}

          {!shown.length ? (
            <p className="text-sm text-muted-foreground">
              {loading ? "Reading…" : "No refused logins in this window."}
            </p>
          ) : (
            <div>
              <TableInCard>
                <THead>
                  <tr>
                    <TH>Surface</TH>
                    <TH>Reason</TH>
                    <TH>Tried as</TH>
                    <TH>Address</TH>
                    <TH>When</TH>
                  </tr>
                </THead>
                <TBody>
                  {shown.slice(0, 500).map((event, i) => (
                    <TR key={`${event.at}-${event.ip}-${i}`}>
                      <TD>
                        <SurfaceBadge surface={event.surface} />
                      </TD>
                      <TD>{reasonLabel(event.reason)}</TD>
                      <TD muted className="font-mono">
                        {event.triedAs ?? "—"}
                      </TD>
                      <TD className="font-mono">{event.ip}</TD>
                      <TD muted className="whitespace-nowrap">
                        {when(event.at)}
                      </TD>
                    </TR>
                  ))}
                </TBody>
              </TableInCard>
              {shown.length > 500 && (
                <p className="px-4 pt-3 text-xs text-muted-foreground">
                  Showing the newest 500 of {shown.length}. Narrow the window to see fewer.
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
      </div>

      <div className="min-w-0 xl:sticky xl:top-4">
        <ClientWatchCard />
      </div>
      </div>
    </>
  );
}

/**
 * Why a source has nothing, in its own words.
 *
 * <p>Rendered rather than folded into a single message. "The gateway is unreachable", "the log is
 * switched off" and "nobody has failed to log in" are three different pieces of news, and only the
 * last one is good.
 */
function SourceNotes({ sources }: { sources: Payload["sources"] | undefined }) {
  if (!sources) {
    return null;
  }
  const notes: string[] = [];
  if (sources.gateway.reachable === false && sources.gateway.note) {
    notes.push(sources.gateway.note);
  }
  if (sources.gateway.state === "disabled" && sources.gateway.note) {
    notes.push(sources.gateway.note);
  }
  if (sources.gateway.truncated) {
    notes.push(
      "The gateway's refusal log was longer than the window read, so the oldest entries in it are "
        + "not shown here."
    );
  }
  if (sources.operator.note) {
    notes.push(sources.operator.note);
  }
  if (notes.length === 0) {
    return null;
  }
  return (
    <div className="space-y-1 rounded-md border border-border bg-muted/40 p-3 text-sm text-muted-foreground">
      {notes.map((note) => (
        <p key={note}>{note}</p>
      ))}
    </div>
  );
}

/**
 * Refusals per hour.
 *
 * <p>Bars rather than a chart library: it has one series, no axes worth labelling and no
 * interaction, and the point is the shape of a burst rather than a readable value per hour.
 */
function RateChart({ buckets }: { buckets: { hour: string; count: number }[] }) {
  const peak = Math.max(...buckets.map((b) => b.count), 1);
  const first = buckets[0];
  const last = buckets[buckets.length - 1];
  return (
    <div>
      <div className="flex h-16 items-end gap-px" aria-hidden="true">
        {buckets.map((bucket) => (
          <div
            key={bucket.hour}
            title={`${new Date(bucket.hour).toLocaleString()} — ${bucket.count}`}
            className="flex-1 rounded-t-sm bg-primary/70"
            //a bucket with nothing in it still draws a hairline, so a quiet hour reads as an hour
            //that was quiet rather than as an hour that is missing
            style={{ height: `${bucket.count === 0 ? 2 : Math.max(6, (bucket.count / peak) * 100)}%` }}
          />
        ))}
      </div>
      <div className="flex justify-between pt-1 text-xs text-muted-foreground">
        <span>{when(first.hour)}</span>
        <span>peak {peak} in an hour</span>
        <span>{when(last.hour)}</span>
      </div>
    </div>
  );
}

function SurfaceBadge({ surface }: { surface: SecuritySurface }) {
  const tone =
    surface === "smpp"
      ? "bg-primary/10 text-primary"
      : surface === "rest"
        ? "bg-amber-500/10 text-amber-700 dark:text-amber-400"
        : surface === "panel"
          ? "bg-violet-500/10 text-violet-700 dark:text-violet-400"
          : "bg-sky-500/10 text-sky-700 dark:text-sky-400";
  return (
    <span className={`rounded px-2 py-0.5 text-xs font-medium ${tone}`}>
      {surfaceLabel(surface)}
    </span>
  );
}

/**
 * @return a local, readable moment, or the raw string when it cannot be parsed — which is honest
 *     about a line this panel did not understand rather than showing "Invalid Date"
 */
function when(value: string | null): string {
  if (!value) {
    return "—";
  }
  const at = new Date(value);
  return Number.isNaN(at.getTime()) ? value : at.toLocaleString();
}
