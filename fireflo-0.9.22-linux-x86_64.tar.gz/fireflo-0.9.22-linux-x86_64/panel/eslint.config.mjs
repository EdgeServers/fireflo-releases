import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTypescript from "eslint-config-next/typescript";

/**
 * Linting, chiefly to catch the thing that keeps slipping through: an import left behind after the
 * code that used it moved. Two of those shipped — `Gauge` in the sidebar and `latency` in the
 * metrics page — because `tsc --noEmit` does not consider an unused import an error and nothing
 * else was looking.
 *
 * Flat config with the ESLint CLI, not `next lint`: that command was REMOVED in Next.js 16, and
 * `next build` no longer runs linting either. A `.eslintrc.json` would be silently ignored.
 */
export default defineConfig([
  ...nextVitals,
  ...nextTypescript,
  globalIgnores([
    // the defaults from eslint-config-next, which are replaced rather than extended by this call
    ".next/**",
    "out/**",
    "build/**",
    "next-env.d.ts",
  ]),
  {
    rules: {
      /**
       * The rule this whole file exists for, and it has to be set here.
       *
       * The Next config's own rules are all Next-specific — fonts, scripts, images — and none of
       * them look at unused variables. typescript-eslint's recommended set does include this one,
       * but only as a warning, and a warning that does not fail a command is a warning nobody sees.
       *
       * `_`-prefixed arguments are exempt because the route handlers genuinely have them: a Next
       * route signature is `(_req, { params })` and the request really is unused.
       */
      "@typescript-eslint/no-unused-vars": [
        "error",
        {
          argsIgnorePattern: "^_",
          varsIgnorePattern: "^_",
          caughtErrorsIgnorePattern: "^_",
          //an unused import is the failure mode being targeted, so never soften this one
          ignoreRestSiblings: false,
        },
      ],

      /**
       * Reported, not enforced.
       *
       * The four places this fires are legitimate: closing the mobile drawer when the route
       * changes, reading the stored theme after hydration (it CANNOT run during render without an
       * SSR mismatch), and fetching on mount in the two polling hooks. React's compiler-era
       * guidance behind this rule is sound in general, but "fixing" these means restructuring
       * working code around a constraint that does not apply to them — and getting the theme one
       * wrong shows every visitor a flash of the wrong palette.
       *
       * Left visible rather than switched off, because a genuinely careless setState in an effect
       * is worth seeing.
       */
      "react-hooks/set-state-in-effect": "warn",

      /**
       * Downgraded, deliberately. This project's polling hooks pass `load` and `push` as
       * dependencies on purpose and the rule's suggestions there are wrong; making it an error
       * would mean either disabling it inline in several places or restructuring working code to
       * satisfy a heuristic. It still reports, which is what it is good for.
       */
      "react-hooks/exhaustive-deps": "warn",
    },
  },

  /**
   * The TLV catalogue must never become a whitelist.
   *
   * The gateway accepts any tag from 0x0000 to 0xFFFF and treats names as cosmetic, so a definition
   * is a label and never a permission. The obvious well-meant change is to check a tag against the
   * definitions table before saving a worker or a credential — which would start refusing valid
   * configuration the moment a vendor used a tag nobody had named yet, and the operator would have
   * no way to get past it.
   *
   * Structural rather than a comment, because a comment is exactly what gets read past.
   */
  {
    files: ["lib/workers.ts", "lib/credentials.ts"],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          patterns: [
            {
              group: ["**/tlv-definitions", "@/lib/tlv-definitions"],
              message:
                "Write paths must not consult the TLV catalogue. Any tag 0x0000-0xFFFF is legal to "
                + "the gateway, so a definition can never gate a save.",
            },
          ],
        },
      ],
    },
  },
]);
