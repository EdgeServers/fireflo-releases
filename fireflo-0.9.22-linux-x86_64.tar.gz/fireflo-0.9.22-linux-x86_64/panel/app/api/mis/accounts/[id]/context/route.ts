import { NextRequest, NextResponse } from "next/server";
import { accountContext } from "@/lib/account-context";
import { notFoundOrThrow } from "@/lib/mis-route";
import { assertInScope, requireReseller } from "@/lib/require-customer";
import { getBalance } from "@/lib/balance";
import { postpaidHeadroom } from "@/lib/mis-accounts";
import { DEFAULT_LEDGER_SCOPE, isLedgerScope } from "@/lib/ledger-scope";

/**
 * GET /api/mis/accounts/{id}/context — one child's balance and credit history.
 *
 * <p>Mirrors the operator route's path and shape so `useAccountContext` swaps only its base — see
 * `lib/panel-surface.ts`. It feeds the balance in the account header and the whole Billing tab.
 *
 * <p><strong>Two fields the operator's answer carries are stripped here, and neither is an
 * oversight.</strong>
 *
 * <ul>
 *   <li>`scopes` is the account's rate scopes and how many price rules sit on each. That is the
 *       tariff, which is the one thing a reseller does not see or set.</li>
 *   <li>`vendors` names the carriers this account's traffic actually went out over. A reseller's
 *       customer being told which carrier its operator buys from is a commercial disclosure, not a
 *       UI detail.</li>
 * </ul>
 *
 * <p>Both come back <strong>null</strong>, which the type already defines as "could not be read" —
 * a slight imprecision, and the honest alternative would be a third state on a shared interface for
 * one caller. What makes it safe rather than merely quiet is that the components which would render
 * them are gated off on this surface anyway, so nothing here relies on a null being interpreted
 * correctly.
 *
 * <p>`collidesWithVendor` goes too: it is a statement about the rate scope being ambiguous.
 */
type Params = { params: Promise<{ id: string }> };

export async function GET(req: NextRequest, { params }: Params): Promise<NextResponse> {
  let child: string;
  let session;
  try {
    session = await requireReseller();
    child = decodeURIComponent((await params).id);
    //the id arrives in the path, so it is proved to be this reseller's before it reaches a query
    await assertInScope(session, child);
  } catch (err) {
    return notFoundOrThrow(err);
  }

  //validated rather than passed through: it reaches a query, and an unrecognised value must read as
  //the default rather than as an error for a query-string typo
  const asked = req.nextUrl.searchParams.get("ledger");
  const scope = isLedgerScope(asked) ? asked : DEFAULT_LEDGER_SCOPE;

  const full = await accountContext(child, scope);
  //the reseller's OWN terms decide whether it may pass postpaid down. A prepaid reseller has no
  //credit line from the operator, so it has none to extend -- see mayGrantPostpaid on AccountContext
  const [own, room] = await Promise.all([
    getBalance(session.accountId).catch(() => null),
    postpaidHeadroom(session.accountId, child),
  ]);
  return NextResponse.json({
    //`currencyForNewBalance` passes through untouched, deliberately. It is not a pricing fact: it is
    //which unit the balance is counted in, and a reseller opening a child's balance row must be told
    //rather than asked -- see `chooseCurrency` in lib/balance-types.ts. Under a reseller the answer
    //is usually sourced "parent", which is that reseller's own code
    data: {
      ...full,
      scopes: null,
      vendors: null,
      collidesWithVendor: false,
      mayGrantPostpaid: own?.billingMode === "POSTPAID",
      //what is left of that line after the reseller's other children -- see postpaidHeadroom
      postpaidHeadroom: room.headroom,
    },
  });
}
