"use client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { RechargeLog } from "./AccountContextCard";
import { CreditActions } from "./CreditActions";
import { ReconcileCard } from "./ReconcileCard";
import { useAccountContext } from "./useAccountContext";
import { surface } from "@/lib/panel-surface";
import { money } from "@/lib/format";

/**
 * What this account holds, what it may spend, and whether the two agree.
 *
 * <p>Four sibling cards where there was one card holding four stacked sections. Balance, top-up,
 * reconciliation and the ledger are four unrelated jobs — the only thing they shared was a heading
 * reading "Prepaid credit", which was also wrong for a postpaid account.
 */
export function AccountBillingClient({ id }: { id: string }) {
  const { context, loading, reload, setLedgerScope } = useAccountContext(id);
  const balance = context?.balance ?? null;
  const currency = balance?.currency ?? "";
  const postpaid = balance?.billingMode === "POSTPAID";

  return (
    <>
      {/*
        Three abreast, then the ledger across the full width beneath.

        These stopped being one card because they are three unrelated jobs; a column each is what
        that split was for. `items-start` so the shortest does not stretch to match the tallest --
        Add credit carries a form and will always set the row height.

        `md` rather than `lg`: none of the three holds a nested field grid, so they survive a third
        of 768px, and stacking them until 1024 wastes the width this change exists to use.
      */}
      <div className="grid items-start gap-4 md:grid-cols-3">
      <Card>
        <CardHeader bar>
          <CardTitle className="text-base font-medium">
            {postpaid ? "Postpaid" : "Prepaid credit"}
          </CardTitle>
          <CardDescription>
            {postpaid
              ? "What this account may run up before the gateway stops it."
              : "What this account has to spend, and what the gateway will let it send against."}
          </CardDescription>
        </CardHeader>
        <CardContent className="text-base">
          {loading && !context ? (
            <p className="text-muted-foreground">Loading…</p>
          ) : balance ? (
            <div className="flex flex-wrap gap-x-6 gap-y-3">
              <Figure label={postpaid ? "Credit limit" : "Available"}
                value={money(postpaid ? balance.creditLimit : balance.balance, currency)} />
              {/* not a hold that shrinks as messages go out -- it is what has been moved out of
                  balance, so it only ever grows until an operator releases it */}
              {balance.reserved > 0 && (
                <Figure label="Reserved" value={money(balance.reserved, currency)} />
              )}
              {!balance.enabled && (
                <div>
                  <p className="text-xs text-muted-foreground">Credit</p>
                  <p className="text-destructive">Switched off</p>
                </div>
              )}
            </div>
          ) : context?.balanceMissing ? (
            <p className="text-xs text-amber-600 dark:text-amber-400">
              No balance row — not zero, absent. A top-up before the row exists is left pending
              rather than credited.
            </p>
          ) : (
            <p className="text-xs text-muted-foreground">Could not be read.</p>
          )}
        </CardContent>
      </Card>

      {context && (
        <Card>
          <CardHeader bar>
            <CardTitle className="text-base font-medium">Add credit</CardTitle>
          </CardHeader>
          <CardContent>
            <CreditActions
              accountId={id}
              hasRow={!context.balanceMissing && context.balance !== null}
              currency={balance?.currency ?? null}
              //the chain, not the bare gateway key: under a reseller this resolves to the
              //parent's own code, which is what stops a child being asked -- see chooseCurrency
              inheritedCurrency={context.currencyForNewBalance}
              //a reseller moves its own balance rather than issuing credit -- see CreditActions.
              //The portal's balance route refuses `topUp` by name regardless, so this decides what
              //the interface offers rather than what the server permits
              funding={surface().pricing ? "recharge" : "transfer"}
              //true for an operator; for a reseller it is that reseller's own billing mode.
              //Postpaid is a credit line and a prepaid reseller has none to pass down
              mayGrantPostpaid={context.mayGrantPostpaid}
              postpaidHeadroom={context.postpaidHeadroom}
              enabled={balance?.enabled ?? true}
              billingMode={balance?.billingMode ?? "PREPAID"}
              creditLimit={balance?.creditLimit ?? 0}
              onDone={reload}
            />
          </CardContent>
        </Card>
      )}

      {context && (
        <Card>
          <CardHeader bar>
            <CardTitle className="text-base font-medium">Does the credit add up?</CardTitle>
            <CardDescription>
              Two identities over the account&apos;s lifetime: every unit credited is still in
              balance or reserved, and what was reserved covers what was spent.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ReconcileCard accountId={id} currency={currency} />
          </CardContent>
        </Card>
      )}
      </div>

      {context && (
        <Card>
          <CardHeader bar>
            <CardTitle className="text-base font-medium">Money in and out</CardTitle>
            <CardDescription>
              Recharges and transfers, written by the billing system or from this page; the gateway
              applies them on its next poll. The gateway&apos;s own credit reservations are counted
              but not listed.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <RechargeLog
              ledger={context.ledger}
              balanceMissing={context.balanceMissing}
              currency={currency}
              onScopeChange={setLedgerScope}
            />
          </CardContent>
        </Card>
      )}
    </>
  );
}

function Figure({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="font-mono text-xl tabular-nums">{value}</p>
    </div>
  );
}
