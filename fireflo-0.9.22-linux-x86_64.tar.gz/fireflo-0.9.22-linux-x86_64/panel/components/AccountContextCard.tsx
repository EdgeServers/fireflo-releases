"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ArrowDown, ArrowUp } from "lucide-react";
import {
  Card, CardContent, CardHeader, CardTitle, EditPanel,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAccountContext } from "./useAccountContext";
import { money } from "@/lib/format";
import type { Credential } from "@/lib/credential-types";
import type { LedgerView } from "@/lib/account-context-types";
import { hiddenEntriesLabel, type LedgerScope } from "@/lib/ledger-scope";
import { formatTimestamp } from "@/lib/datetime";
import { sortRows, type SortDirection, type TableColumn } from "@/lib/table-columns";
import type { LedgerEntry } from "@/lib/account-context-types";
import { Pager } from "./Pager";
import { SearchInput } from "./SearchInput";
import { usePaging } from "./usePaging";

/** Stable identity, so the memo above does not see a new array every render. */
const EMPTY: readonly LedgerEntry[] = [];

const PAGE_SIZE = 15;

/**
 * The ledger's five columns, widths included.
 *
 * <p>`TableColumn` rather than a bespoke shape so `sortRows` can be reused — it puts nulls last in
 * both directions, which matters here because `ref` and `note` are frequently absent and a naive
 * sort would file every blank at one end and call it order.
 *
 * <p>No `ColumnChooser` and no catalogue module: five columns, every one of which is load-bearing,
 * and a per-surface storage key would be machinery with nobody to serve.
 */
type LedgerColumn = TableColumn<LedgerEntry> & { width: string };

const LEDGER_COLUMNS: readonly LedgerColumn[] = [
  { id: "when", header: "When", group: "", from: (e) => e.createdAt, defaultOn: true, width: "9.5rem" },
  { id: "amount", header: "Amount", group: "", from: (e) => e.delta, align: "right", defaultOn: true, width: "7rem" },
  { id: "type", header: "Type", group: "", from: (e) => e.entryType, defaultOn: true, width: "6.5rem" },
  { id: "ref", header: "Reference", group: "", from: (e) => e.ref, defaultOn: true, width: "auto" },
  { id: "state", header: "State", group: "", from: (e) => e.applied, defaultOn: true, width: "15rem" },
];

/**
 * What the account this credential bills to actually has today.
 *
 * <p><strong>Read-only here, deliberately.</strong> Credit can now be added from the account page —
 * see `CreditActions` — but not from beside a credential form. This card sits next to the Account
 * box while somebody is editing a login, and a top-up field within reach of a form about something
 * else is how the wrong customer gets credited.
 *
 * <p>It also never disables the form and its failure is never an error: it is context beside a
 * field, and a panel that refuses to save a credential because a balance query timed out would be
 * worse than one that says nothing.
 *
 * <p>Keyed on the <em>effective</em> billing account rather than on the Account box, because that is
 * what the gateway will use. When the fallback is the system ID, the operator is looking at the
 * balance of their system id — which is exactly the surprise worth putting on screen.
 */
export function AccountContextCard({
  account,
  fallback,
  flat = false,
}: {
  /** The effective billing account, or null when there is nothing to look up. */
  account: string | null;
  fallback: Credential["billingAccountFallback"];
  /**
   * Render without a Card of its own.
   *
   * <p>True when this sits inside a form that is itself inside a card. The dialog panel is
   * `bg-card`, so a Card here would have no tonal separation from its container and would read as a
   * stray sibling rather than as context attached to the field above it.
   */
  flat?: boolean;
}) {
  //the effective account IS the secret here. The panel does not have it and must not ask for it
  const lookup = fallback === "apiKey" ? null : account;
  const { context, loading, setLedgerScope } = useAccountContext(lookup);

  if (fallback === "apiKey") {
    return (
      <Note>
        Nothing to look up: with no account and an API key, the billing account <em>is</em> the key,
        and this panel neither holds it nor sends it anywhere.
      </Note>
    );
  }
  if (!account) {
    return (
      <Note>
        No account and no system ID yet, so there is nothing for prepaid credit or rate rules to be
        keyed on.
      </Note>
    );
  }
  if (!context) {
    return <Note>{loading ? `Looking up ${account}…` : `Nothing could be read about ${account}.`}</Note>;
  }

  const { balance, balanceMissing, ledger, scopes, vendors, collidesWithVendor } = context;
  const currency = balance?.currency ?? "";
  const unseen = balanceMissing && !scopes?.length && !vendors?.length && !ledger?.entries.length;

  const Shell = flat ? EditPanel : Card;
  const Head = flat ? "div" : CardHeader;
  const Body = flat ? "div" : CardContent;

  return (
    //dimmed rather than emptied while reloading: a balance that blinks to a dash reads as it changing
    <Shell className={loading ? "opacity-60 transition-opacity" : "transition-opacity"}>
      <Head className={flat ? "space-y-1.5" : "pb-3"}>
        <CardTitle className="flex flex-wrap items-center gap-2 text-base font-medium">
          <Link href={`/cp/accounts/${encodeURIComponent(account)}`} className="hover:underline">
            {account}
          </Link>
          {fallback === "systemId" && (
            <Badge variant="outline">from the system ID, not the account field</Badge>
          )}
        </CardTitle>
      </Head>
      <Body className="space-y-4 text-base">
        {collidesWithVendor && (
          <p className="text-amber-600 dark:text-amber-400">
            A vendor is also called {account}. Rate scopes are matched by name alone, so its rules
            are read as <strong>cost</strong> for the vendor and as <strong>price</strong> here —
            the same numbers meaning two different things.
          </p>
        )}

        {unseen ? (
          <p className="text-muted-foreground">
            Nothing in this gateway has ever heard of {account}: no balance row, no rate scope, no
            traffic. That is fine for a new customer — but note that topping up a balance before the
            row exists silently does nothing.
          </p>
        ) : (
          <>
            <div className="flex flex-wrap gap-6">
              <div>
                <p className="text-sm text-muted-foreground">Balance</p>
                {balance ? (
                  <p className="font-mono text-lg tabular-nums">{money(balance.balance, currency)}</p>
                ) : balanceMissing ? (
                  <p className="text-sm text-amber-600 dark:text-amber-400">
                    No balance row — not zero, absent.
                  </p>
                ) : (
                  <p className="text-sm text-muted-foreground">Could not be read.</p>
                )}
              </div>
              {balance && balance.reserved > 0 && (
                <div>
                  <p className="text-sm text-muted-foreground">Reserved</p>
                  <p className="font-mono text-lg tabular-nums">{money(balance.reserved, currency)}</p>
                  <p className="text-sm text-muted-foreground">
                    Already handed to a gateway instance; not available to spend.
                  </p>
                </div>
              )}
              {balance && !balance.enabled && (
                <div>
                  <p className="text-sm text-muted-foreground">Credit</p>
                  <p className="text-base text-destructive">Switched off</p>
                </div>
              )}
            </div>

            <div className="flex flex-wrap gap-6 text-sm">
              <div>
                <p className="text-muted-foreground">Priced by</p>
                {scopes == null ? (
                  <p className="text-muted-foreground">Could not be read.</p>
                ) : scopes.length ? (
                  <p>
                    <Link href="/cp/pricing" className="text-primary hover:underline">
                      {scopes[0].rules} rule{scopes[0].rules === 1 ? "" : "s"} under {account}
                    </Link>
                  </p>
                ) : (
                  <p className="text-muted-foreground">
                    No scope of its own — whatever catch-all exists.
                  </p>
                )}
              </div>
              <div>
                <p className="text-muted-foreground">Traffic has gone to</p>
                {vendors == null ? (
                  <p className="text-muted-foreground">Could not be read.</p>
                ) : vendors.length ? (
                  <p>{vendors.map((v) => `${v.vendor} (${v.messages})`).join(", ")}</p>
                ) : (
                  <p className="text-muted-foreground">Nothing yet.</p>
                )}
              </div>
            </div>

            <RechargeLog
              ledger={ledger}
              balanceMissing={balanceMissing}
              currency={currency}
              onScopeChange={setLedgerScope}
            />
          </>
        )}
      </Body>
    </Shell>
  );
}

/**
 * The recharge log, and the one thing it exists to catch.
 *
 * <p>`BalanceService.applyPendingRecharges` adds the delta with `UPDATE account_balance … WHERE
 * account_id = ?` and then marks the ledger row applied <strong>unconditionally</strong>. For an
 * account with no balance row the update matches nothing, the mark still fires, and the top-up is
 * gone: recorded as applied, never credited, with no error raised anywhere in either system.
 *
 * <p>So a row is shown in one of three states, and the third is the whole reason this is here.
 * Deriving it needs nothing new — only the ledger and whether the balance query found a row.
 */
export function RechargeLog({
  ledger,
  balanceMissing,
  currency,
  onScopeChange,
}: {
  ledger: LedgerView | null;
  balanceMissing: boolean;
  currency: string;
  /** Absent on surfaces that cannot reload, where the toggle is simply not offered. */
  onScopeChange?: (scope: LedgerScope) => void;
}) {
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<{ id: string; dir: SortDirection }>({ id: "when", dir: "desc" });

  const entries = ledger?.entries ?? EMPTY;
  const rows = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const matching = needle
      ? entries.filter((e) =>
          `${e.ref ?? ""} ${e.note ?? ""} ${e.entryType}`.toLowerCase().includes(needle))
      : [...entries];
    const column = LEDGER_COLUMNS.find((c) => c.id === sort.id);
    return column ? sortRows(matching, column, sort.dir) : matching;
  }, [entries, query, sort]);

  const { page, pages, shown, setPage, reset } = usePaging(rows, PAGE_SIZE);
  //a narrower list must not leave the reader on a page that no longer exists
  useEffect(() => { reset(); }, [query, sort, reset]);

  if (ledger == null) {
    return <p className="text-sm text-muted-foreground">The recharge log could not be read.</p>;
  }

  const { machineEntries, scope } = ledger;
  const hidden = scope === "human" ? machineEntries : 0;

  //offered whenever there is something to reveal, including when the human list is empty -- "no
  //recharges, and 12,481 reservations you are not seeing" is a different answer from "nothing here".
  //
  //A BUTTON, not a column filter: `onScopeChange` refetches with a different scope rather than
  //hiding rows the client already holds, so the machine entries are not present to be filtered
  const toggle = onScopeChange && machineEntries > 0 && (
    <button
      type="button"
      className="underline underline-offset-2 hover:text-foreground"
      onClick={() => onScopeChange(scope === "human" ? "all" : "human")}
    >
      {scope === "human" ? "Show them" : "Hide them"}
    </button>
  );

  if (!entries.length) {
    return (
      <p className="text-sm text-muted-foreground">
        {hidden > 0
          ? `No recharges or transfers recorded. ${hiddenEntriesLabel(hidden)} — the gateway's own
             credit bookkeeping, which moves no money. `
          : "No recharges recorded. "}
        {toggle}
      </p>
    );
  }

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-center gap-2">
        <p className="min-w-0 flex-1 text-xs text-muted-foreground">
          {scope === "human"
            ? "Written by the billing system or from this page; the gateway applies them on its next poll."
            : "Every entry, including the gateway's own credit reservations."}{" "}
          {hidden > 0 && <>{hiddenEntriesLabel(hidden)} — credit moved between two columns of one row. </>}
          {toggle}
        </p>
        <SearchInput
          value={query}
          onChange={setQuery}
          placeholder="reference, note, type"
          ariaLabel="Search the ledger"
          className="w-48"
        />
      </div>

      <div className="overflow-x-auto">
        <table className="striped w-full text-sm tabular-nums">
          <thead className="text-muted-foreground">
            <tr className="text-left">
              {LEDGER_COLUMNS.map((column) => {
                const active = sort.id === column.id;
                return (
                  <th
                    key={column.id}
                    //explicit widths: State holds a full sentence and Reference is two lines, so
                    //without these the columns resize between pages and the table appears to jump
                    style={{ width: column.width }}
                    aria-sort={active ? (sort.dir === "asc" ? "ascending" : "descending") : "none"}
                    className={`py-1 pr-4 font-medium ${column.align === "right" ? "text-right" : ""}`}
                  >
                    <button
                      type="button"
                      className="inline-flex items-center gap-1 hover:text-foreground"
                      onClick={() =>
                        setSort((s) =>
                          s.id === column.id
                            ? { id: column.id, dir: s.dir === "asc" ? "desc" : "asc" }
                            : { id: column.id, dir: "asc" })}
                    >
                      {column.header}
                      {active && (sort.dir === "asc"
                        ? <ArrowUp className="h-3 w-3" aria-hidden="true" />
                        : <ArrowDown className="h-3 w-3" aria-hidden="true" />)}
                    </button>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {shown.map((entry) => (
              <tr key={entry.id} className="border-t border-border align-top">
                {/* the ledger is a prop, so this renders on the server in the host's zone */}
                <td className="py-1.5 pr-4 whitespace-nowrap" suppressHydrationWarning>
                  {formatTimestamp(entry.createdAt)}
                </td>
                <td className="py-1.5 pr-4 text-right font-mono">{money(entry.delta, currency)}</td>
                <td className="py-1.5 pr-4">{entry.entryType}</td>
                <td className="py-1.5 pr-4 font-mono text-muted-foreground">
                  {entry.ref ?? "—"}
                  {entry.note && <span className="block font-sans">{entry.note}</span>}
                </td>
                <td className="py-1.5">
                  {balanceMissing && entry.delta > 0 ? (
                    <span className="text-amber-600 dark:text-amber-400">
                      {entry.applied
                        ? "Applied before this account's balance row went missing. Nothing here can "
                          + "say what it was credited to."
                        : "Waiting for a balance row. It is held rather than lost, and credits "
                          + "itself the moment the row exists — open the account for credit."}
                    </span>
                  ) : entry.applied ? (
                    <span className="text-muted-foreground">Applied</span>
                  ) : (
                    <span>Pending — the gateway applies it on its next poll.</span>
                  )}
                </td>
              </tr>
            ))}
            {shown.length === 0 && (
              <tr className="border-t border-border">
                <td colSpan={LEDGER_COLUMNS.length} className="py-3 text-muted-foreground">
                  Nothing matches that search.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Pager page={page} pages={pages} total={rows.length} noun="entry" onPage={setPage} />
    </div>
  );
}

function Note({ children }: { children: React.ReactNode }) {
  return <p className="text-sm text-muted-foreground">{children}</p>;
}
