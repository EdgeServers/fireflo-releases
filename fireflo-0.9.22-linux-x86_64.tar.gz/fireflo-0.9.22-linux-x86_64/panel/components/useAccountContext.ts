"use client";
import { useEffect, useState } from "react";
import type { AccountContext } from "@/lib/account-context-types";
import { DEFAULT_LEDGER_SCOPE, type LedgerScope } from "@/lib/ledger-scope";
import { surface } from "@/lib/panel-surface";

/** Long enough that typing an account id does not fire a request per keystroke. */
const DEBOUNCE_MS = 400;

/**
 * What the account named in the form actually has, kept in step with the box as it is typed.
 *
 * <p><strong>Three guards, and the third is the one that matters.</strong> Debouncing keeps the
 * request count down and the abort keeps the network tidy, but neither prevents the failure worth
 * preventing: typing `acct-100` and then `acct-1001` can land the first reply after the second
 * request was issued, painting one account's balance under the other's name. An abort is a request
 * for cancellation, not a guarantee. So the reply carries the account it describes and is discarded
 * unless it still matches.
 *
 * <p>While reloading, the previous answer stays on screen and is dimmed by the caller. A balance
 * that blanks to a dash between keystrokes reads as the balance changing.
 *
 * @param account the effective billing account, or null when there is nothing to look up — an empty
 *     box, or an API-key credential whose effective account is the secret itself and must never be
 *     sent anywhere
 */
export function useAccountContext(account: string | null): {
  context: AccountContext | null;
  loading: boolean;
  reload: () => void;
  setLedgerScope: (scope: LedgerScope) => void;
} {
  const [context, setContext] = useState<AccountContext | null>(null);
  const [loading, setLoading] = useState(false);
  //server-side rather than a client filter: the machine rows are the ones being left out, and
  //fetching fifty of them in order to drop them would show fewer than fifty human entries
  const [ledgerScope, setLedgerScope] = useState<LedgerScope>(DEFAULT_LEDGER_SCOPE);
  //bumped to refetch after a write. The effect is keyed on the account, which never changes while
  //somebody is topping it up, so without this the card would keep showing the balance from before
  const [nonce, setNonce] = useState(0);

  useEffect(() => {
    if (!account) {
      setContext(null);
      setLoading(false);
      return;
    }

    const controller = new AbortController();
    let live = true;
    setLoading(true);

    const timer = setTimeout(async () => {
      try {
        const res = await fetch(
          `${surface().apiBase}/accounts/${encodeURIComponent(account)}/context?ledger=${ledgerScope}`,
          { cache: "no-store", signal: controller.signal }
        );
        const json = await res.json().catch(() => null);
        if (!live) {
          return;
        }
        //the identity check: a reply for a different account is not this account's, whatever order
        //it arrived in
        if (res.ok && json?.data?.account === account) {
          setContext(json.data as AccountContext);
        }
      } catch {
        //a failed lookup is never an error state here -- the card is context, not a gate
      } finally {
        if (live) {
          setLoading(false);
        }
      }
    }, DEBOUNCE_MS);

    return () => {
      live = false;
      clearTimeout(timer);
      controller.abort();
    };
  }, [account, nonce, ledgerScope]);

  return { context, loading, reload: () => setNonce((n) => n + 1), setLedgerScope };
}
