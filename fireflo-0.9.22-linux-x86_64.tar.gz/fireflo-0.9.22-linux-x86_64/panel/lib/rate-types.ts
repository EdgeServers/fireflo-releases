/**
 * Pricing rules, and everything that decides whether one is wrong.
 *
 * <p><strong>Zero database imports, and it must stay that way.</strong> `lib/config-db.ts` pulls
 * `pg`; a client component importing so much as a string constant from a module that transitively
 * reaches it drags a Postgres driver into the browser bundle, the bundler fails on `dns`, and
 * *every* page in the app starts returning 500 — not only the one that made the mistake. The
 * condition vocabulary below is needed by a dropdown, so it lives here rather than beside the SQL.
 *
 * <p>When routing gets its own editor, the field and operator catalogues move to a shared
 * `condition-types.ts` used by both. They are exported flat and named generically so that lift is a
 * file move rather than a rewrite.
 */
/** What the query layer takes and the form holds. `amount` is a string everywhere — see below. */
export interface ConditionInput {
  field: string;
  operator: string;
  value: string;
  negate: boolean;
}

export interface RateRuleInput {
  /** null for a rule that does not exist yet. Existing ids are preserved across a save. */
  id: number | null;
  /**
   * A decimal string, never a number.
   *
   * <p>`pg` returns NUMERIC as a string precisely to avoid binary floating point, and this is money.
   * It stays a string from the row, through the DTO, through JSON, through React state and back into
   * a bind parameter. There is no point in this feature where it becomes a `number`, and anyone
   * "fixing" that with a `pg` type parser reintroduces rounding error into a billing path.
   */
  amount: string;
  product: string | null;
  currency: string | null;
  label: string | null;
  enabled: boolean;
  conditions: ConditionInput[];
  /**
   * Named filters this rule carries, from `app_filter`.
   *
   * <p>Their conditions are ANDed with {@link conditions} at load time — a filter narrows this rule,
   * it never replaces or widens what the rule already requires. And a filter that has been *disabled*
   * makes the gateway skip this rule entirely rather than treat it as a catch-all, which is why
   * {@link isCatchAll} counts these and why the editor keeps showing one that has since been
   * switched off.
   */
  filters: string[];
}

/**
 * What an inline editor may change about an existing rule.
 *
 * <p>`id` is excluded deliberately: a patch that could carry one would let a form move a rule's
 * identity, and the id is what every historical call record points at.
 */
export type RulePatch = Partial<Omit<RateRuleInput, "id">>;

export interface RateRule extends RateRuleInput {
  id: number;
  scope: string;
  seq: number;
  updatedAt: string | null;
}

export interface ScopeInput {
  scope: string;
  /** Set when the operator has said out loud that an unrecognised scope is intentional. */
  scopeConfirmed?: boolean;
  /**
   * Whether this save is creating the scope rather than editing one that exists.
   *
   * <p>Only affects what an empty rule list means — see {@link validateScope}. A caller that omits
   * it gets the old behaviour, which is the right default for the CSV import and for any editor
   * that legitimately empties a scope.
   */
  isNew?: boolean;
  rules: RateRuleInput[];
}

export interface ScopeSummary {
  scope: string;
  rules: number;
  enabled: number;
  products: string[];
}

/**
 * What a scope is pricing.
 *
 * <p>`scope` is one column with two opposite meanings — a vendor instance name is what a carrier
 * charges us, an account id is what we charge a customer — and the schema cannot tell them apart.
 * Derived, never stored: a column for it would be a second source of truth the gateway does not read.
 */
export type ScopeKind = "cost" | "price" | "default" | "unknown";

/**
 * The scope whose rules price an account that has none of its own.
 *
 * <p>Mirrors `RateSnapshot.DEFAULT_SCOPE` in the gateway, and must stay equal to it: the gateway
 * appends this scope's rules to the account's on the sell side only, so a rule stored here is what
 * every unpriced account pays. Reserved, so an account or vendor cannot be named it.
 */
export const DEFAULT_SCOPE = "*";

export interface KnownScopes {
  vendors: string[];
  accounts: string[];
  /**
   * Per account, the products its logins carry — the credential's `product` field.
   *
   * Absent when it could not be read, which is not the same as an account whose logins carry
   * nothing: the first means "no opinion", the second is a real and reportable state. Only an
   * account present as a key has been looked at.
   */
  carriedProducts?: Record<string, string[]>;
}

export function scopeKind(scope: string, known: KnownScopes): ScopeKind {
  //before the catalogues, because this one is reserved and cannot be either of them
  if (scope === DEFAULT_SCOPE) {
    return "default";
  }
  if (known.vendors.includes(scope)) {
    return "cost";
  }
  return known.accounts.includes(scope) ? "price" : "unknown";
}

/**
 * A plain decimal with at most four places.
 *
 * <p>Tested as a **string**. `0.0035 * 10000` is `34.999999999999996` in a JavaScript float, so any
 * check built on arithmetic is itself the bug it is trying to catch. The pattern also rejects `.5`,
 * `1e-4`, `+0.5`, a trailing space, and anything negative.
 */
export const AMOUNT_PATTERN = /^\d+(\.\d{1,4})?$/;

/** The shortlist offered as a dropdown. Everything else is reachable through the free-text box. */
export const COMMON_FIELDS = [
  "to",
  "from",
  "product",
  "systemId",
  "owner_id",
  "type",
  "onetwork",
  "cnetwork",
  "parts",
  "body",
] as const;

/**
 * Every field a message exposes to a condition, from `StandardMessage.fieldMap`.
 *
 * <p>`target.*` fields are deliberately absent. `RateRule.matches` passes a null worker, so a
 * `target.queueSize` condition resolves to false and the rule silently never fires — offering them
 * would be offering a way to write a rate that can never be charged.
 */
export const ALL_FIELDS = [
  "acked", "binbody", "binheader", "body", "cnetwork", "cost", "ctstamp", "dcs", "ddt",
  "dispatchType", "errcode", "expr", "extrid", "field1", "field2", "field3", "field4", "field5",
  "field6", "field7", "field8", "field9", "field10", "flash", "from", "ingateway",
  "marginPercentage", "marginStatus", "mclass", "message_center", "metadata", "msgId",
  "nextTarget", "onetwork", "outgateway", "owner_id", "paid", "parts", "priority", "product",
  "rtxCnt", "serial", "state", "sutstamp", "systemId", "timestamp", "to", "ttl", "type",
] as const;

export const STRING_OPERATORS = [
  "equals",
  "equalsIgnoreCase",
  "matches",
  "startsWith",
  "endsWith",
  "greaterThan",
  "greaterEqual",
  "lessThan",
  "lessEqual",
  "isNull",
] as const;

export const BOOLEAN_OPERATORS = ["isTrue", "isFalse"] as const;

/** The numeric comparisons, plus their type suffixes: i int, l long, f double, s short, c char, b byte. */
export const NUMERIC_OPERATORS = ["==", ">", ">=", "<", "<="] as const;

export const OPERATORS = [...STRING_OPERATORS, ...BOOLEAN_OPERATORS, ...NUMERIC_OPERATORS] as const;

/**
 * The condition that loads perfectly and can never be true.
 *
 * <p>Only `matches` treats its value as a pattern. Every other operator compares literal text —
 * `startsWith` is `msgVal.startsWith(value)` in the gateway — so a regular expression handed to one
 * of them asks whether a destination literally begins with the characters `^(?:\+91`. Nothing does.
 * The rule stores, loads, displays and prices nothing, which is the worst shape a pricing bug has:
 * every page agrees it is fine.
 *
 * <p>Here rather than in a module of its own because this file is already the shared condition
 * vocabulary — the fields and operators above — and it is reached by both the rate editor and the
 * filter form. It moves with them if `condition-types.ts` is ever split out.
 *
 * <p><strong>Strong signals only.</strong> `+91` is a correct and ordinary `startsWith` value, and a
 * warning that fires on it teaches people to scroll past warnings — which costs more than this check
 * saves. So a bare `+`, `-`, `*` or `?` is not evidence of anything; each of these is.
 */
const SIGNALS: { pattern: RegExp; name: string }[] = [
  { pattern: /^\^/, name: "a leading ^" },
  { pattern: /\$$/, name: "a trailing $" },
  { pattern: /\\[dwsDWS.+*?^$|()[\]{}\\/]/, name: "a backslash escape" },
  { pattern: /\[.*\]/, name: "a character class in []" },
  { pattern: /\(.*\)/, name: "a group in ()" },
  { pattern: /\{\d+(,\d*)?\}/, name: "a {n} quantifier" },
  { pattern: /\.[*+]/, name: ".* or .+" },
];

/** The one operator whose value is compiled rather than compared. */
const PATTERN_OPERATOR = "matches";

/**
 * Strips the negation the policy string packs in.
 *
 * <p>`!matches` is still `matches` for this purpose, and `!startsWith` is still literal. Reading the
 * `!` as part of the operator name would let a negated condition past the check.
 */
function bareOperator(operator: string): string {
  return operator.startsWith("!") ? operator.slice(1) : operator;
}

/** Whether this value was written as a regular expression, on the strong signals above. */
export function looksLikeRegex(value: string): boolean {
  return SIGNALS.some((s) => s.pattern.test(value));
}

/**
 * The warning, or null when there is nothing to say.
 *
 * <p>Phrased around the consequence rather than the syntax. "That is a regex" is a fact the person
 * who typed it already knows; "this can never be true, so the rule never fires" is the part they do
 * not, and it is what makes the fix — switch the operator to `matches` — obvious.
 */
export function regexInLiteralOperator(operator: string, value: string): string | null {
  const bare = bareOperator(operator ?? "");
  if (bare === PATTERN_OPERATOR || !value) {
    return null;
  }
  const signal = SIGNALS.find((s) => s.pattern.test(value));
  if (!signal) {
    return null;
  }
  return `'${value}' has ${signal.name}, so it was written as a regular expression — but '${bare}' `
    + "compares it as literal text, character for character. No real value contains those "
    + "characters, so this condition can never be true: the rule stores, loads, displays and never "
    + "fires. Change the operator to 'matches' to treat the value as a pattern.";
}

/**
 * Every such warning a list of conditions earns, deduplicated.
 *
 * <p>Takes conditions rather than a filter or a rule because that is all it looks at, which is what
 * lets the filter form and the rate editor share it. Deduplicated by message: one filter listing the
 * same bad pattern on two fields has one mistake in it, not two, and repeating it buries the rest.
 */
export function conditionWarnings(conditions: ConditionInput[]): string[] {
  const seen = new Set<string>();
  for (const c of conditions) {
    const warning = regexInLiteralOperator(c.negate ? `!${c.operator}` : c.operator, c.value ?? "");
    if (warning) {
      seen.add(warning);
    }
  }
  return [...seen];
}


/**
 * Which fields each typed accessor on `StandardMessage` can actually read.
 *
 * <p>Taken from the `switch` in each `getXxxValue(int)`, mapped back through `fieldMap`. A numeric
 * operator on a field outside the matching set makes the `Condition` constructor throw, which fails
 * the whole rate table rather than the one rule.
 *
 * <p><strong>`field1`…`field10` appear in every one of those switches and are still string-only.</strong>
 * They are declared `public Object` and are null on the static probe message the constructor tests
 * against, so `(Integer) field1` unboxes to a NullPointerException, the catch swallows it, and the
 * accessor throws — so `field1:==:5` is rejected at load. That is the least guessable rule in the
 * whole grammar, which is why it is written down here.
 */
export const INT_FIELDS: ReadonlySet<string> = new Set([
  "type", "priority", "rtxCnt", "ttl", "ddt", "mclass", "msgId", "onetwork", "cnetwork", "state",
  "dispatchType", "marginPercentage", "marginStatus",
]);

export const LONG_FIELDS: ReadonlySet<string> = new Set(["expr", "cost", "ctstamp", "sutstamp"]);

export const DOUBLE_FIELDS: ReadonlySet<string> = new Set(["marginPercentage"]);

export const BYTE_FIELDS: ReadonlySet<string> = new Set(["dcs"]);

export const BOOLEAN_FIELDS: ReadonlySet<string> = new Set(["acked", "flash", "paid"]);

/** Fields any numeric operator can read, whichever suffix it carries. */
const NUMERIC_FIELDS: ReadonlySet<string> = new Set([
  ...INT_FIELDS, ...LONG_FIELDS, ...DOUBLE_FIELDS, ...BYTE_FIELDS,
]);

/** SMPP 3.4 gives system_type 13 octets, so a longer product cannot be selected by a bind. */
export const SMPP_SYSTEM_TYPE_MAX = 12;

/**
 * One rule as a sentence, for a list that has to be read rather than decoded.
 *
 * <p>A rule carrying a named filter and no inline conditions would otherwise render as "for
 * everything else" — a display that is wrong about money. Callers show the filter badges; this says
 * the rule is narrowed by something not written here.
 */
export function describeRule(rule: RateRuleInput): string {
  const amount = rule.amount || "0";
  //the product is part of the sentence, not a separate column, because without it the premium
  //catch-all and the any-product catch-all read as the same rule at two different prices
  const scope = rule.product ? ` on ${rule.product}` : "";

  if (!rule.conditions.length) {
    if (rule.filters.length) {
      return `${amount}${scope} where a shared filter allows it`;
    }
    return rule.product
      ? `${amount} for everything else on ${rule.product}`
      : `${amount} for everything else`;
  }

  const parts = rule.conditions.map((c) => {
    const not = c.negate ? "not " : "";
    return c.operator === "isNull" || c.operator === "isTrue" || c.operator === "isFalse"
      ? `${c.field} is ${not}${readable(c.operator)}`
      : `${c.field} ${not}${readable(c.operator)} ${c.value}`;
  });
  return `${amount}${scope} when ${parts.join(" and ")}`;
}

/**
 * Everything wrong with one rule, as one human sentence.
 *
 * <p>Named rather than numbered, because a rule's position is not always on screen. The whole-scope
 * form passes `rule 3`; an editor with a single rule open passes `this rule`, where a number would
 * point at a row the operator cannot see.
 *
 * <p>Shared with {@link validateScope} rather than duplicated, so the one-at-a-time editor cannot
 * accept a rule the whole-scope form would have refused.
 */
export function validateRule(rule: RateRuleInput, label: string): string | null {
  const Label = sentenceCase(label);

  //said separately from a malformed amount: "the amount '' must be a plain number" is a sentence
  //about a value that is not there, which reads as a bug rather than as an empty box
  if (!(rule.amount ?? "").trim()) {
    return `${Label} needs an amount — a plain number with at most four decimal places.`;
  }
  if (!AMOUNT_PATTERN.test(rule.amount)) {
    return `The amount '${rule.amount}' on ${label} must be a plain number with at most four `
      + "decimal places. The column stores four and Postgres rounds on the way in rather than "
      + "refusing, so 0.04505 would be stored as 0.0451 and nothing anywhere would tell you.";
  }
  if (rule.product != null && rule.product !== rule.product.trim()) {
    return `${Label}'s product has a space at one end. Products are matched exactly.`;
  }
  return validateConditions(rule, label);
}

/** `rule 2` -> `Rule 2`, `this rule` -> `This rule`. For a label starting a sentence. */
function sentenceCase(label: string): string {
  return label.charAt(0).toUpperCase() + label.slice(1);
}

/**
 * Everything that must stop a save, as one human sentence.
 *
 * <p>A sentence rather than an array or a thrown error, matching `worker-types.ts`: the operator
 * needs to know which rule and what will happen, not a schema dump.
 *
 * @returns the reason, or null when the scope is fit to save
 */
export function validateScope(input: ScopeInput, known: KnownScopes): string | null {
  const scope = input.scope ?? "";
  if (!scope.trim()) {
    return "A scope is required. It names either a vendor instance (what a carrier charges us) or "
      + "an account id (what we charge a customer).";
  }
  if (scope !== scope.trim()) {
    return `'${scope}' has a space at one end. Scopes are matched exactly, and a trailing space is `
      + "invisible everywhere it is displayed, so this would silently price nothing.";
  }

  //one string, two opposite meanings, and a typo turns a vendor cost into an account price that
  //never matches -- at which point cost is unknown and margin looks wonderful
  if (known.vendors.includes(scope) && known.accounts.includes(scope)) {
    return `'${scope}' is both a vendor name and an account id. Rating cannot tell them apart, so `
      + "the same rules would be used as our cost and as the customer's price. Rename one.";
  }
  if (scopeKind(scope, known) === "unknown" && !input.scopeConfirmed) {
    return `'${scope}' is neither a known vendor nor a known account. A scope names one or the `
      + "other; anything else is stored, loaded, and matches nothing at all. "
      + `Vendors: ${known.vendors.join(", ") || "none"}. `
      + `Accounts: ${known.accounts.join(", ") || "none"}. `
      + "Tick the confirmation if this is a new account id you are about to onboard.";
  }

  if (!input.rules.length) {
    //creating a scope with no rules writes nothing at all, and used to do it with a 200 and a
    //cheerful refresh: the save path has nothing to insert, so the list came back exactly as it
    //was. "Add pricing" appeared to do nothing, which is how a platform ends up with no default
    //price and nobody able to set one
    if (input.isNew) {
      return "New pricing needs at least one rule. A scope with no rules is not stored at all — "
        + "there would be nothing to price with, and nothing on screen to say so.";
    }
    //an EXISTING scope may legitimately be emptied: that is how the last rule is removed, and the
    //CSV import relies on it
    return null;
  }

  const seen = new Set<number>();
  for (let i = 0; i < input.rules.length; i++) {
    const rule = input.rules[i];
    const n = i + 1;

    if (seen.has(i)) {
      return `Two rules are at position ${i}. Position decides which rate wins.`;
    }
    seen.add(i);

    const problem = validateRule(rule, `rule ${n}`);
    if (problem) {
      return problem;
    }
  }

  return catchAllProblem(input);
}

/**
 * A catch-all above other rules in the same bucket makes them dead.
 *
 * <p>Bucketing is load bearing here. `RateSnapshot.rulesFor` returns the product-specific rules
 * followed by the any-product ones and walks that concatenation in order, so an unconditional
 * any-product rule shadows the rest of the **any** bucket and none of the product buckets. A check
 * that ignored that would cry wolf on the very first realistic table — the shipped `rates.conf` has
 * a catch-all at position 3 and premium rules at 0 and 1, in a different bucket — and a validator
 * that cries wolf is worse than no validator.
 */
function catchAllProblem(input: ScopeInput): string | null {
  const buckets = new Map<string, { rule: RateRuleInput; n: number }[]>();
  input.rules.forEach((rule, i) => {
    const key = rule.product ?? "";
    const bucket = buckets.get(key) ?? [];
    bucket.push({ rule, n: i + 1 });
    buckets.set(key, bucket);
  });

  for (const [product, bucket] of buckets) {
    const where = product ? `for product '${product}'` : "for any product";
    for (let i = 0; i < bucket.length - 1; i++) {
      if (isCatchAll(bucket[i].rule)) {
        const dead = bucket.slice(i + 1).map((b) => b.n).join(", ");
        return `Rule ${bucket[i].n} ${where} has no conditions, so it matches everything and `
          + `rule${dead.includes(",") ? "s" : ""} ${dead} below it can never be reached. `
          + "Move it to the end.";
      }
    }
  }
  return null;
}

/**
 * The condition checks that are true of any rule the gateway parses, rate or route.
 *
 * <p>Extracted because only the rates page was running them. `validateRouteTable` checked the table
 * name and non-empty targets and nothing else, so a routing rule with a numeric operator on a text
 * field saved cleanly from the panel and then made the gateway refuse the WHOLE routing table set --
 * silently keeping the previous one, so the page showed one thing and the gateway routed another.
 *
 * @param subject what the gateway refuses when this is wrong, in the words the caller's user thinks
 *     in: "rate table" or "routing table". The consequence is the same shape and the noun is not.
 */
export function conditionErrors(
  conditions: readonly { field: string; operator: string; value: string; negate?: boolean }[],
  label: string,
  subject: "rate table" | "routing table"
): string | null {
  const Label = sentenceCase(label);
  for (const c of conditions) {
    if (!c.field?.trim()) {
      return `A condition on ${label} has no field.`;
    }
    if (c.value !== c.value.trim()) {
      return `A condition on ${label} has a space at one end of '${c.value}'. Values are matched `
        + "exactly, so this would compare against something nobody can see.";
    }

    //'==' is numeric and 'equals' is text. The gateway does not reject the one rule -- the whole
    //table fails to load, and what it was serving silently stays in place
    const base = numericBase(c.operator);
    if (base && !NUMERIC_FIELDS.has(c.field)) {
      return `${Label} uses '${c.operator}' on '${c.field}', which is text. '==' compares numbers `
        + `and 'equals' compares text. The gateway refuses the entire ${subject} on this, so it `
        + "would keep whatever it loaded last and nothing here would show it.";
    }
    if (c.operator === "matches") {
      try {
        new RegExp(c.value);
      } catch (err) {
        return `${Label}'s pattern '${c.value}' does not compile: `
          + `${err instanceof Error ? err.message : "invalid"}. `
          + "(Checked with JavaScript's engine, which is close to but not identical to Java's.)";
      }
    }
  }
  return null;
}

function validateConditions(rule: RateRuleInput, label: string): string | null {
  const Label = sentenceCase(label);
  const generic = conditionErrors(rule.conditions, label, "rate table");
  if (generic) {
    return generic;
  }
  for (const c of rule.conditions) {

    //the column is not a shorthand for this condition -- it is the thing that puts the rule in its
    //own bucket, and only the bucket survives a reorder
    if (c.field === "product" && c.operator === "equals" && !c.negate) {
      return `${Label} narrows itself with a 'product equals ${c.value}' condition instead of `
        + "setting the rule's Product. Both match the same messages today, but only the Product "
        + "field puts the rule in its own bucket, where it is tried ahead of every any-product rule "
        + "regardless of position. With the condition alone, any catch-all above it wins instead.";
    }
  }
  return null;
}

/**
 * Rules priced for a product that no login on this account claims.
 *
 * <p>The rule is correct, enabled, scoped to a real account and priced — and never fires. Rating
 * offers a message only the rules whose product matches its own, and a message takes its product
 * from the bind's `system_type`, falling back to the login's `product` field. So a rule for
 * 'premium' on an account whose only login carries 'sms' is matched by nothing, and every message
 * is recorded unpriced. Unpriced is not free: it is never charged, so it can never be reconciled
 * or refunded either.
 *
 * <p>The same trap exists on the gateway side, where `fireflo bootstrap --product` writes the
 * product onto the login it creates for exactly this reason.
 *
 * <p>Deliberately a warning and not a refusal, because `system_type` can override the login's
 * product per session. A customer who binds with `system_type=premium` reaches this rule whatever
 * their credential says — which is a real way to run, and the reason the wording hedges rather than
 * asserting the rule is dead.
 */
function unreachableProductWarnings(input: ScopeInput, known?: KnownScopes): string[] {
  const scope = (input.scope ?? "").trim();
  const carried = known?.carriedProducts?.[scope];
  //no entry means the logins were not read, which is not the same as an account whose logins carry
  //nothing. A vendor scope has no logins at all and is skipped for the same reason
  if (!carried || !carried.length || !known?.accounts.includes(scope)) {
    return [];
  }

  const missing = [...new Set(
    input.rules.map((r) => (r.product ?? "").trim()).filter((p) => p && !carried.includes(p))
  )];
  return missing.map((product) =>
    `No login on '${scope}' carries the product '${product}', so nothing reaches these rules and `
    + "those messages are recorded with no price at all. Its logins carry: "
    + `${carried.join(", ")}. Set the product on the login under Accounts, or have the customer `
    + `bind with system_type '${product}'.`);
}

/**
 * Everything worth saying that should not stop a save.
 *
 * <p>Rendered as amber cards while typing, the same treatment as `millisecondWarnings`.
 */
export function scopeWarnings(input: ScopeInput, known?: KnownScopes): string[] {
  const warnings: string[] = [];

  warnings.push(...unreachableProductWarnings(input, known));

  input.rules.forEach((rule, i) => {
    const n = i + 1;
    if (rule.amount === "0" || /^0(\.0{1,4})?$/.test(rule.amount ?? "")) {
      warnings.push(`Rule ${n} charges nothing.`);
    }
    if (rule.currency) {
      warnings.push(`Rule ${n} sets its own currency (${rule.currency}), overriding the gateway's `
        + "default. FireFlo never converts between currencies — it reports whichever one the rule "
        + "carried.");
    }
    for (const c of rule.conditions) {
      //Java's Pattern.matches compares the WHOLE value. '^614' matches only the literal text '614',
      //so the rule loads perfectly, never fires, and the traffic is billed by whatever catch-all
      //comes next. Nothing else in either repo catches this
      if (c.operator === "matches" && !/(\$|\.\*|\.\+|\*|\+|\})\s*$/.test(c.value)) {
        warnings.push(`Rule ${n}'s pattern '${c.value}' has to match the whole value, not part of `
          + "it. As written it matches only the exact text — add '.*' at the end, or use "
          + "'startsWith' instead.");
      }
      //the mirror image of the warning above, and the one that was missing: a pattern handed to an
      //operator that compares literal text. Same silent outcome, opposite mistake
      const literal = regexInLiteralOperator(c.negate ? `!${c.operator}` : c.operator, c.value ?? "");
      if (literal) {
        warnings.push(`Rule ${n}: ${literal}`);
      }
    }
  });

  const buckets = new Set(input.rules.map((r) => r.product ?? ""));
  for (const product of buckets) {
    const bucket = input.rules.filter((r) => (r.product ?? "") === product);
    if (!bucket.some(isCatchAll)) {
      warnings.push(`Nothing ${product ? `for product '${product}'` : "for any product"} matches `
        + "everything. A message matching no rule comes back with an unknown amount, which must "
        + "never be read as free.");
    }
  }

  const shapes = new Set<string>();
  input.rules.forEach((rule, i) => {
    //filters are part of what a rule matches, not decoration -- their conditions are ANDed with the
    //rule's own at load time, which is why `isCatchAll` counts them too. Leaving them out here calls
    //a per-country tariff (same product, same amount, one filter each) unreachable, which is false.
    //Sorted, because two rules carrying the same filters in a different order match the same messages
    const shape = JSON.stringify([rule.product ?? "", rule.conditions, [...rule.filters].sort()]);
    if (shapes.has(shape)) {
      warnings.push(`Rule ${i + 1} matches exactly what an earlier rule matches, so it can never `
        + "be reached.");
    }
    shapes.add(shape);
  });

  return warnings;
}

/** A rule with nothing narrowing it. Filters count: a rule carrying one is not a catch-all. */
function isCatchAll(rule: RateRuleInput): boolean {
  return !rule.conditions.length && !rule.filters.length;
}

/**
 * The numeric operator underneath a suffixed one, or null when it is not numeric at all.
 *
 * <p>`>=l` is `>=` on a long; `>=` alone is on an int. Both are numeric, and both fail on a text
 * field.
 */
function numericBase(operator: string): string | null {
  const bare = operator.replace(/[ilfscb]$/, "");
  return (NUMERIC_OPERATORS as readonly string[]).includes(bare) ? bare : null;
}

function readable(operator: string): string {
  const words: Record<string, string> = {
    equals: "is",
    equalsIgnoreCase: "is (any case)",
    matches: "matches",
    startsWith: "starts with",
    endsWith: "ends with",
    greaterThan: "is after",
    greaterEqual: "is at or after",
    lessThan: "is before",
    lessEqual: "is at or before",
    isNull: "empty",
    isTrue: "set",
    isFalse: "unset",
  };
  return words[operator] ?? operator;
}

/**
 * One scope's coverage of one product, without its rules.
 *
 * <p>What the product page lists. The rules themselves arrive per scope, on demand, because loading
 * them all is what stopped the page working at a thousand customers.
 */
export interface ProductScopeSummary {
  scope: string;
  /** Rules that price this product: its own plus the catch-alls. */
  rules: number;
  /** Every rule in the scope. The difference from `rules` is what a filtered save also rewrites. */
  scopeRules: number;
  enabledRules: number;
  /** False when the scope reaches this product only through a rule that prices everything. */
  specificToProduct: boolean;
  minAmount: string | null;
  maxAmount: string | null;
}

/** One enabled rule reduced to what decides coverage. `product` is `""` for a rule pricing anything. */
export interface RuleCoverage {
  scope: string;
  product: string;
}

/** An account and one of the products its logins carry, with nothing priced for the pair. */
export interface UnratedPair {
  scope: string;
  product: string;
}

/**
 * Which account and product pairs no enabled rule would price.
 *
 * <p>The configuration-side companion to the traffic count in `unrated-preflight.ts`: that one asks
 * what has already been sent unpriced, this one asks what *would* be, including for an account
 * onboarded this morning that has not sent yet. Both feed the same decision about
 * `smsg.rating.unrated.refuse`.
 *
 * <p><strong>Four places a price can come from, and missing any of them invents a fault.</strong>
 * `RateSnapshot.rulesForPrice` hands the matcher the account's own rules followed by the default
 * scope's, and `rulesFor` expands each of those into the product's own rules followed by the
 * any-product ones. So a pair is unrated only when all four buckets are empty — in particular an
 * account covered by nothing but a `*` catch-all **is priced**, and reporting it would send an
 * operator hunting for a rule that is working.
 *
 * <p>It answers "no rule could match", not "no rule will match": a candidate carrying conditions or
 * filters still counts as coverage here, because whether it matches depends on the message. The
 * false negative is deliberate — the alternative is re-implementing the matcher against traffic that
 * has not happened, and the traffic-side pre-flight already catches what slips through.
 *
 * @param carried per account, the products its logins claim — `KnownScopes.carriedProducts`
 * @param covered every **enabled** rule, as scope and product
 */
export function unratedPairs(
  carried: Record<string, readonly string[]>,
  covered: Iterable<RuleCoverage>
): UnratedPair[] {
  const has = new Set<string>();
  for (const rule of covered) {
    has.add(`${rule.scope}\u0000${rule.product}`);
  }

  const pairs: UnratedPair[] = [];
  for (const scope of Object.keys(carried).sort()) {
    //an account named the default scope cannot exist -- creating one is refused -- and if one ever
    //did, rulesForPrice would not append the default to itself. Skipping it keeps the two agreeing
    if (scope === DEFAULT_SCOPE) {
      continue;
    }
    for (const product of [...new Set(carried[scope])].sort()) {
      const priced = has.has(`${scope}\u0000${product}`)
        || has.has(`${scope}\u0000`)
        || has.has(`${DEFAULT_SCOPE}\u0000${product}`)
        || has.has(`${DEFAULT_SCOPE}\u0000`);
      if (!priced) {
        pairs.push({ scope, product });
      }
    }
  }
  return pairs;
}
