import { oneRowPerMessage } from "@/lib/cdr-grain";
import { query } from "@/lib/metrics-db";

/**
 * Aggregates over the gateway's call records.
 *
 * <p>Four properties of that schema make the obvious query wrong, and wrong in a way that produces
 * plausible numbers rather than obvious nonsense. They are handled here, once, so no route has to
 * remember them:
 *
 * <ol>
 *   <li><b>A retried message writes another submit row.</b> `COUNT(*)` counts attempts, not
 *       messages. Which of the two you want depends on the question -- vendor load is attempts,
 *       customer volume is messages -- so both are reported rather than one being guessed at.</li>
 *   <li><b>Revenue is repeated on every attempt row</b>, but the customer is charged once. Summing
 *       `price` across retries inflates revenue.</li>
 *   <li><b>Cost is genuinely per attempt</b> -- each one really was handed to a vendor -- so cost
 *       must be summed across all of them.</li>
 *   <li><b>`cdr_final` has no uniqueness constraint.</b> Concurrent receipts for one message append
 *       two rows by design, so a plain join multiplies the row it joins to.</li>
 * </ol>
 *
 * <p>Money is a BIGINT scaled by 10 000 and lives only on part 1; later segments are delivery rows
 * with no amounts. Everything here returns the scaled integer -- dividing is a presentation
 * concern, and doing it in the aggregate would round away money.
 */

export type Range = "24h" | "7d" | "30d";

const RANGES: Record<Range, { hours: number; bucket: "hour" | "day" }> = {
  "24h": { hours: 24, bucket: "hour" },
  "7d": { hours: 24 * 7, bucket: "day" },
  "30d": { hours: 24 * 30, bucket: "day" },
};

export function isRange(value: string | null): value is Range {
  return value === "24h" || value === "7d" || value === "30d";
}

export function resolveRange(range: Range): {
  since: Date;
  until: Date;
  bucket: "hour" | "day";
} {
  const { hours, bucket } = RANGES[range];
  const until = new Date();
  const since = new Date(until.getTime() - hours * 3_600_000);
  return { since, until, bucket };
}

/**
 * The outcome of a message, deduplicated.
 *
 * <p>Exported because it is the one correct receipt dedupe and `statement-queries.ts` needs the same
 * answer. A second copy would drift, and the drift would be a delivery count on an invoice
 * disagreeing with the delivery count on the dashboard beside it.
 *
 * <p>Taken as a LATERAL rather than a grouped join so it uses `idx_cdr_final_msg_part` and returns
 * exactly one row however many receipts arrived. Ordered by `final_at` so the first terminal
 * outcome wins -- the expiry sweeper only writes EXPIRED for messages that never had one, so it
 * cannot displace a real receipt.
 */
export const OUTCOME_LATERAL = `
  LEFT JOIN LATERAL (
    SELECT f.final_state, f.dlr_state, f.err_code
      FROM cdr_final f
     WHERE f.gateway_msg_id = s.gateway_msg_id AND f.part_no = s.part_no
     --A real receipt outranks a swept EXPIRED, whichever landed first: EXPIRED is synthetic,
     --written by the gateway's expiry sweep, and a genuine receipt can still arrive after it
     --because the correlation index outlives the deadline. false sorts before true.
     --SAME RULE IN UsageRollup.java AND THREE OTHER lib/ QUERIES. Change one, change all five.
     ORDER BY (f.final_state = 'EXPIRED'), f.final_at
     LIMIT 1
  ) o ON TRUE`;

export interface TrafficBucket {
  bucket: string;
  submitted: number;
  delivered: number;
  failed: number;
  expired: number;
  pending: number;
}

/**
 * Messages over time, bucketed by when they were accepted.
 *
 * <p>Counts first attempts only, so one message is one message however many vendors it was tried
 * on. Retry pressure is a vendor question and is reported there instead.
 */
export async function trafficOverTime(range: Range): Promise<TrafficBucket[]> {
  const { since, until, bucket } = resolveRange(range);
  const rows = await query<Record<string, string>>(
    `SELECT to_char(date_trunc($3, s.submitted_at), 'YYYY-MM-DD"T"HH24:MI:SSZ') AS bucket,
            COUNT(*)                                                      AS submitted,
            COUNT(*) FILTER (WHERE o.final_state = 'DELIVERED')            AS delivered,
            COUNT(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED')) AS failed,
            COUNT(*) FILTER (WHERE o.final_state = 'EXPIRED')              AS expired,
            COUNT(*) FILTER (WHERE o.final_state IS NULL)                  AS pending
       FROM cdr_submit s${OUTCOME_LATERAL}
      WHERE ${oneRowPerMessage()}
        AND s.submitted_at >= $1 AND s.submitted_at < $2
      GROUP BY 1
      ORDER BY 1`,
    [since, until, bucket]
  );
  return rows.map((r) => ({
    bucket: r.bucket,
    submitted: num(r.submitted),
    delivered: num(r.delivered),
    failed: num(r.failed),
    expired: num(r.expired),
    pending: num(r.pending),
  }));
}

export interface FailureRow {
  finalState: string;
  dlrState: number | null;
  errCode: string | null;
  messages: number;
  /**
   * The newest occurrence of this failure kind in the window, as an ISO instant.
   *
   * <p>What makes a dismissal self-healing. `lib/failure-dismissals.ts` hides a row only while this
   * is older than when the operator dismissed it, so the same failure happening once more brings
   * the row back with nothing to expire and nothing to remember. Dismissing on the count instead
   * would resurrect rows on its own, because the window rolls.
   */
  lastSeen: string;
}

/**
 * Why messages failed.
 *
 * <p>`dlr_state` is kept raw on purpose: EXPIRED, REJECTD and UNDELIV all bill as failures but mean
 * very different things, and collapsing them is exactly what makes a delivery problem hard to
 * diagnose.
 */
export async function failureBreakdown(range: Range): Promise<FailureRow[]> {
  const { since, until } = resolveRange(range);
  const rows = await query<Record<string, string>>(
    //max() over a group already being formed, so last_seen costs nothing beyond the aggregate
    `SELECT o.final_state, o.dlr_state, o.err_code, COUNT(*) AS messages,
            MAX(s.submitted_at) AS last_seen
       FROM cdr_submit s${OUTCOME_LATERAL}
      WHERE ${oneRowPerMessage()}
        AND s.submitted_at >= $1 AND s.submitted_at < $2
        AND o.final_state IS NOT NULL
        AND o.final_state <> 'DELIVERED'
      GROUP BY 1, 2, 3
      ORDER BY 4 DESC`,
    [since, until]
  );
  return rows.map((r) => ({
    finalState: r.final_state,
    dlrState: r.dlr_state === null ? null : num(r.dlr_state),
    errCode: r.err_code ?? null,
    messages: num(r.messages),
    //the driver hands back a Date for a timestamptz; an ISO string is what survives JSON either way
    lastSeen: new Date(r.last_seen).toISOString(),
  }));
}

export interface VendorRow {
  vendor: string | null;
  attempts: number;
  messages: number;
  delivered: number;
  failed: number;
  pending: number;
  cost: number;
  deliveryRate: number | null;
}

/**
 * Per-vendor performance.
 *
 * <p>Two different scopes in one row, deliberately. <b>Attempts and cost</b> cover every submit,
 * because a retried message really was handed to a vendor twice and really was charged twice.
 * <b>Delivery outcome</b> is attributed to the <i>last</i> attempt only — the vendor that
 * actually carried it. Attributing one outcome to every vendor that tried would credit a delivery
 * to the vendor that failed.
 */
export async function vendorPerformance(range: Range): Promise<VendorRow[]> {
  const { since, until } = resolveRange(range);
  const rows = await query<Record<string, string>>(
    `WITH attempts AS (
        SELECT vendor,
               COUNT(*)                          AS attempts,
               COUNT(DISTINCT gateway_msg_id)    AS messages,
               COALESCE(SUM(cost), 0)            AS cost
          FROM cdr_submit
         WHERE ${oneRowPerMessage("")}
           AND submitted_at >= $1 AND submitted_at < $2
         GROUP BY vendor
     ),
     last_attempt AS (
        SELECT DISTINCT ON (gateway_msg_id)
               gateway_msg_id, part_no, vendor
          FROM cdr_submit
         WHERE ${oneRowPerMessage("")}
           AND submitted_at >= $1 AND submitted_at < $2
         ORDER BY gateway_msg_id, retry_count DESC
     ),
     outcomes AS (
        SELECT s.vendor,
               COUNT(*) FILTER (WHERE o.final_state = 'DELIVERED')          AS delivered,
               COUNT(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED','EXPIRED')) AS failed,
               COUNT(*) FILTER (WHERE o.final_state IS NULL)                AS pending
          FROM last_attempt s${OUTCOME_LATERAL}
         GROUP BY s.vendor
     )
     SELECT a.vendor,
            a.attempts, a.messages, a.cost,
            COALESCE(o.delivered, 0) AS delivered,
            COALESCE(o.failed, 0)    AS failed,
            COALESCE(o.pending, 0)   AS pending
       FROM attempts a
       LEFT JOIN outcomes o ON o.vendor IS NOT DISTINCT FROM a.vendor
      ORDER BY a.attempts DESC`,
    [since, until]
  );
  return rows.map((r) => {
    const delivered = num(r.delivered);
    const failed = num(r.failed);
    const settled = delivered + failed;
    return {
      vendor: r.vendor ?? null,
      attempts: num(r.attempts),
      messages: num(r.messages),
      delivered,
      failed,
      pending: num(r.pending),
      cost: num(r.cost),
      //undefined rather than 0 while nothing has settled -- a brand-new vendor has no delivery
      //rate, which is not the same as a delivery rate of nought
      deliveryRate: settled === 0 ? null : delivered / settled,
    };
  });
}

export interface RevenueRow {
  accountId: string | null;
  product: string | null;
  messages: number;
  revenue: number;
  cost: number;
  margin: number;
  pendingRevenue: number;
}

/**
 * Money, by account and product.
 *
 * <p>Revenue and cost are counted over different row sets — revenue on first attempts only, cost
 * across every attempt — so the margin here is computed from those two sums rather than by summing
 * the stored `margin` column. That column is correct per row, but summing it inherits the
 * retry double-count and would overstate profit on exactly the traffic that went wrong.
 *
 * <p>`pendingRevenue` is billed traffic with no outcome yet: real in-flight exposure, not an error.
 * The gateway's sweeper closes it as EXPIRED after 48 hours.
 */
export async function revenueByAccount(range: Range): Promise<RevenueRow[]> {
  const { since, until } = resolveRange(range);
  const rows = await query<Record<string, string>>(
    `WITH attempts AS (
        SELECT s.account_id, s.product, s.price, o.final_state,
               --a message the vendor refused: recorded because it went on the wire, refunded
               --because it never left. Asked of cdr_rejected rather than of final_state, which
               --cannot tell it apart from a carrier's REJECTD receipt on a message that WAS
               --accepted and is legitimately billed. Served by idx_cdr_rejected_msg
               EXISTS (SELECT 1 FROM cdr_rejected r
                        WHERE r.gateway_msg_id = s.gateway_msg_id
                          AND r.reason = 'vendorRejected') AS refused
          FROM cdr_submit s${OUTCOME_LATERAL}
         WHERE ${oneRowPerMessage()}
           AND s.submitted_at >= $1 AND s.submitted_at < $2
     ),
     billed AS (
        SELECT account_id, product,
               --refused attempts are excluded rather than counted at zero: this column sits beside
               --revenue, and counting traffic nobody paid for would drag revenue per message down
               --without anything on screen saying why
               COUNT(*) FILTER (WHERE NOT refused)            AS messages,
               COALESCE(SUM(price), 0)                        AS revenue,
               COALESCE(SUM(price) FILTER (WHERE final_state IS NULL), 0) AS pending_revenue
          FROM attempts
         GROUP BY 1, 2
     ),
     spent AS (
        SELECT account_id, product, COALESCE(SUM(cost), 0) AS cost
          FROM cdr_submit
         WHERE ${oneRowPerMessage("")}
           AND submitted_at >= $1 AND submitted_at < $2
         GROUP BY 1, 2
     )
     SELECT b.account_id, b.product, b.messages, b.revenue, b.pending_revenue,
            COALESCE(sp.cost, 0) AS cost
       FROM billed b
       LEFT JOIN spent sp
              ON sp.account_id IS NOT DISTINCT FROM b.account_id
             AND sp.product    IS NOT DISTINCT FROM b.product
      ORDER BY b.revenue DESC`,
    [since, until]
  );
  return rows.map((r) => {
    const revenue = num(r.revenue);
    const cost = num(r.cost);
    return {
      accountId: r.account_id ?? null,
      product: r.product ?? null,
      messages: num(r.messages),
      revenue,
      cost,
      margin: revenue - cost,
      pendingRevenue: num(r.pending_revenue),
    };
  });
}

export interface UsageDay {
  /** The bucket, `YYYY-MM-DD` for a day range and an ISO instant for the hourly one. */
  day: string;
  /** `null` for traffic that named no account — real, and not the same as an account called "". */
  accountId: string | null;
  submitted: number;
  delivered: number;
  failed: number;
  pending: number;
  /** Scaled by 10 000, like every other amount here. */
  price: number;
}

/**
 * Traffic and money at day x account, which is the grain the usage page needs and nothing had.
 *
 * <p>{@link trafficOverTime} groups by bucket with no account, and {@link revenueByAccount} groups
 * by account with no day. Composing the two client-side cannot produce this: a per-day series split
 * by account is not derivable from a total per day and a total per account.
 *
 * <p>Both figures come from one pass over the same rows, which is what makes them agree. Doing the
 * counts and the sum as separate queries is how a page ends up reporting more messages than it
 * billed for and no reason why.
 *
 * <p>`price` is summed rather than counted, so an unrated message contributes a row to `submitted`
 * and nothing to the money — NULL sums to nothing on its own and needs no extra clause. Unlike
 * {@link revenueByAccount} this does <em>not</em> exclude vendor-refused messages: this is a usage
 * view, and a message that went on the wire and was refunded is traffic that happened. The money
 * column already excludes it, because a refunded row's price is NULL.
 */
export async function usageByDay(range: Range): Promise<UsageDay[]> {
  const { since, until, bucket } = resolveRange(range);
  return usageBetween(since, until, bucket);
}

/**
 * The same figures over an arbitrary window, optionally for one account.
 *
 * <p>Split out because a statement period is not one of the three named ranges — it is a calendar
 * month, or whatever two dates an operator typed. Sharing the query rather than writing a second
 * one is what makes the statement's daily chart agree with the usage page: the two are the same
 * arithmetic over a different window, and two queries would eventually disagree about a retry or a
 * refund and there would be no way to tell which was right.
 *
 * <p>The window is half-open, `[since, until)`, exactly as the statement is — so a message belongs
 * to one period and never to two.
 */
export async function usageBetween(
  since: Date,
  until: Date,
  bucket: "hour" | "day",
  accountId?: string | null
): Promise<UsageDay[]> {
  const rows = await query<Record<string, string>>(
    `SELECT to_char(date_trunc($3, s.submitted_at),
                    CASE WHEN $3 = 'day' THEN 'YYYY-MM-DD'
                         ELSE 'YYYY-MM-DD"T"HH24:MI:SSZ' END)          AS day,
            s.account_id                                               AS account_id,
            COUNT(*)                                                   AS submitted,
            COUNT(*) FILTER (WHERE o.final_state = 'DELIVERED')        AS delivered,
            COUNT(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED','EXPIRED'))
                                                                       AS failed,
            COUNT(*) FILTER (WHERE o.final_state IS NULL)              AS pending,
            COALESCE(SUM(s.price), 0)                                  AS price
       FROM cdr_submit s${OUTCOME_LATERAL}
      WHERE ${oneRowPerMessage()}
        AND s.submitted_at >= $1 AND s.submitted_at < $2
        --$4 IS NULL rather than a second query: one plan, and the parameter is bound rather than
        --interpolated, so an account id is never concatenated into SQL
        AND ($4::text IS NULL OR s.account_id = $4)
      GROUP BY 1, 2
      ORDER BY 1, 2`,
    [since, until, bucket, accountId ?? null]
  );
  return rows.map((r) => ({
    day: r.day,
    accountId: r.account_id ?? null,
    submitted: num(r.submitted),
    delivered: num(r.delivered),
    failed: num(r.failed),
    pending: num(r.pending),
    price: num(r.price),
  }));
}

export interface Totals {
  messages: number;
  delivered: number;
  failed: number;
  pending: number;
  revenue: number;
  cost: number;
  margin: number;
  deliveryRate: number | null;
}

/** The headline figures, scoped exactly as the detailed queries are. */
export async function totals(range: Range): Promise<Totals> {
  const [traffic, revenue] = await Promise.all([trafficOverTime(range), revenueByAccount(range)]);

  const messages = sum(traffic, (t) => t.submitted);
  const delivered = sum(traffic, (t) => t.delivered);
  const failed = sum(traffic, (t) => t.failed) + sum(traffic, (t) => t.expired);
  const settled = delivered + failed;

  return {
    messages,
    delivered,
    failed,
    pending: sum(traffic, (t) => t.pending),
    revenue: sum(revenue, (r) => r.revenue),
    cost: sum(revenue, (r) => r.cost),
    margin: sum(revenue, (r) => r.margin),
    deliveryRate: settled === 0 ? null : delivered / settled,
  };
}

export interface AccountRow {
  accountId: string | null;
  systemId: string | null;
  product: string | null;
  messages: number;
  delivered: number;
  failed: number;
  pending: number;
  billed: number;
  cost: number;
  deliveryRate: number | null;
  lastSeen: string | null;
  /** Spendable credit, or null when the account has no balance row. */
  balance: number | null;
  currency: string | null;
  /** True when the credential is configured but sent nothing in this period. */
  idle: boolean;
}

export interface AccountsView {
  /**
   * Whether prepaid credit appears to be switched on.
   *
   * <p>A heuristic, and worth naming as one: the panel cannot read the gateway's
   * `smsg.balance.enabled`, so it infers from whether any balance rows exist. An enabled gateway
   * that has never been funded looks the same as a disabled one — but both mean "no credit figure
   * to show", which is what the column needs to decide.
   */
  creditEnforced: boolean;
  accounts: AccountRow[];
}

/**
 * Who is using the gateway.
 *
 * <p>Built from the call records rather than the credential table, because credentials may be
 * configured from a file — in which case `app_credential` is empty and would show nothing at all.
 * Configured credentials are merged in on top when the table *is* populated, so a provisioned
 * account that has sent nothing still appears rather than silently going missing.
 */
export async function accountUsage(range: Range): Promise<AccountsView> {
  const { since, until } = resolveRange(range);

  const [activity, configured, funded] = await Promise.all([
    query<Record<string, string>>(
      `WITH act AS (
          SELECT s.account_id, s.system_id, s.product,
                 COUNT(*)                                                   AS messages,
                 COALESCE(SUM(s.price), 0)                                  AS billed,
                 MAX(s.submitted_at)                                        AS last_seen,
                 COUNT(*) FILTER (WHERE o.final_state = 'DELIVERED')        AS delivered,
                 COUNT(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED','EXPIRED')) AS failed,
                 COUNT(*) FILTER (WHERE o.final_state IS NULL)              AS pending
            FROM cdr_submit s${OUTCOME_LATERAL}
           WHERE ${oneRowPerMessage()}
             AND s.submitted_at >= $1 AND s.submitted_at < $2
           GROUP BY 1, 2, 3
       ),
       spend AS (
          SELECT account_id, system_id, product, COALESCE(SUM(cost), 0) AS cost
            FROM cdr_submit
           WHERE ${oneRowPerMessage("")}
             AND submitted_at >= $1 AND submitted_at < $2
           GROUP BY 1, 2, 3
       )
       SELECT a.account_id, a.system_id, a.product, a.messages, a.billed,
              to_char(a.last_seen, 'YYYY-MM-DD"T"HH24:MI:SSZ') AS last_seen,
              a.delivered, a.failed, a.pending,
              COALESCE(sp.cost, 0) AS cost
         FROM act a
         LEFT JOIN spend sp
                ON sp.account_id IS NOT DISTINCT FROM a.account_id
               AND sp.system_id  IS NOT DISTINCT FROM a.system_id
               AND sp.product    IS NOT DISTINCT FROM a.product
        ORDER BY a.messages DESC`,
      [since, until]
    ),
    configuredCredentials(),
    accountBalances(),
  ]);

  const rows: AccountRow[] = activity.map((r) => {
    const delivered = num(r.delivered);
    const failed = num(r.failed);
    const settled = delivered + failed;
    const balance = funded.get(r.account_id ?? "");
    return {
      accountId: r.account_id ?? null,
      systemId: r.system_id ?? null,
      product: r.product ?? null,
      messages: num(r.messages),
      delivered,
      failed,
      pending: num(r.pending),
      billed: num(r.billed),
      cost: num(r.cost),
      deliveryRate: settled === 0 ? null : delivered / settled,
      lastSeen: r.last_seen ?? null,
      balance: balance?.balance ?? null,
      currency: balance?.currency ?? null,
      idle: false,
    };
  });

  //a credential that is provisioned but sent nothing in this window is worth seeing, not omitting
  const seen = new Set(rows.map((r) => `${r.accountId}|${r.systemId}`));
  for (const c of configured) {
    if (seen.has(`${c.accountId}|${c.systemId}`)) continue;
    const balance = funded.get(c.accountId ?? "");
    rows.push({
      accountId: c.accountId,
      systemId: c.systemId,
      product: c.product,
      messages: 0,
      delivered: 0,
      failed: 0,
      pending: 0,
      billed: 0,
      cost: 0,
      deliveryRate: null,
      lastSeen: null,
      balance: balance?.balance ?? null,
      currency: balance?.currency ?? null,
      idle: true,
    });
  }

  return { creditEnforced: funded.size > 0, accounts: rows };
}

interface ConfiguredCredential {
  accountId: string | null;
  systemId: string | null;
  product: string | null;
}

/**
 * Credentials configured in the database, if any.
 *
 * <p>Note the column list: `password` and `api_key` are in this table and are never selected.
 * A secret that is not read cannot be leaked by a later change to how this is rendered.
 *
 * <p>Returns empty rather than throwing when the table is absent or unreadable — a gateway using
 * file-based credentials is a normal configuration, not a failure, and the read-only role may
 * legitimately have no grant on it.
 */
async function configuredCredentials(): Promise<ConfiguredCredential[]> {
  try {
    const rows = await query<Record<string, string>>(
      `SELECT account_id, system_id, product FROM app_credential WHERE enabled ORDER BY system_id`
    );
    return rows.map((r) => ({
      accountId: r.account_id ?? null,
      systemId: r.system_id ?? null,
      product: r.product ?? null,
    }));
  } catch {
    return [];
  }
}

async function accountBalances(): Promise<Map<string, { balance: number; currency: string | null }>> {
  const map = new Map<string, { balance: number; currency: string | null }>();
  try {
    const rows = await query<Record<string, string>>(
      `SELECT account_id, balance, currency FROM account_balance WHERE enabled`
    );
    for (const r of rows) {
      map.set(r.account_id, { balance: num(r.balance), currency: r.currency ?? null });
    }
  } catch {
    //same reasoning as above: no balance table, or no grant, is not an error worth failing on
  }
  return map;
}

/** Postgres returns BIGINT as a string, so every count and amount arrives as text. */
function num(value: string | null | undefined): number {
  return value == null ? 0 : Number(value);
}

function sum<T>(rows: T[], pick: (row: T) => number): number {
  return rows.reduce((acc, row) => acc + pick(row), 0);
}

/** The most groups a pre-flight lists. Beyond this it is a platform-wide problem, not a list. */
const UNRATED_GROUP_LIMIT = 50;

/**
 * Recent traffic that carried no price, grouped by who sent it and under what.
 *
 * <p>Answers one question: what would `smsg.rating.unrated.refuse` refuse if it were switched on
 * now. Every row here is a message that flows today and would be refused — `0x418` over SMPP, `403`
 * over REST — from the gateway's next configuration poll onward.
 *
 * <p><strong>`price_rule_id IS NULL`, not `price = 0` and not `price IS NULL`.</strong> The gateway
 * refuses only when no rule matched; a rule deliberately set to zero prices the message at nothing
 * and keeps sending once the flag is on. `price_rule_id` is the only column that records which of
 * those two happened, and getting it wrong would report every free route as about to break.
 *
 * <p>The total is a window function rather than a second query, so the number is the whole picture
 * even when the list is truncated — "50 groups" with a total covering all of them, not a total that
 * silently means "the 50 shown".
 */
export async function unratedTraffic(hours: number): Promise<{
  groups: { accountId: string; product: string; messages: number }[];
  total: number;
}> {
  const rows = await query<Record<string, string>>(
    `SELECT COALESCE(account_id, '')          AS account_id,
            COALESCE(product, '')             AS product,
            count(*)::int                     AS messages,
            (sum(count(*)) OVER ())::bigint   AS total
       FROM cdr_submit
      WHERE submitted_at > now() - ($1 || ' hours')::interval
        AND price_rule_id IS NULL
      GROUP BY 1, 2
      ORDER BY messages DESC, account_id
      LIMIT ${UNRATED_GROUP_LIMIT}`,
    [String(hours)]
  );

  return {
    groups: rows.map((r) => ({
      accountId: r.account_id,
      product: r.product,
      messages: num(r.messages),
    })),
    total: num(rows[0]?.total),
  };
}
