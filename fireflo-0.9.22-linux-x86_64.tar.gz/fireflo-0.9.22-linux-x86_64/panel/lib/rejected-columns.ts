import type { RejectedRow } from "./rejected-types";
import type { TableColumn } from "./table-columns";
//with the extension, because `node --test` runs these modules directly and does not read tsconfig
//paths or resolve extensionless specifiers. Type-only imports above are erased and need neither
import { resolveColumns as resolveFrom } from "./table-columns.ts";
import { reasonLabel, receiptLabel, refusedAfterAccepting, vendorStatusName } from "./rejected-types.ts";

/**
 * Every column of a refusal, in English, with how to render it.
 *
 * <p>The sibling of `cdr-columns.ts`, and the same argument: this is the one place a `cdr_rejected`
 * column gets a name, and the table and the chooser both read it. The choosing and remembering live
 * in `table-columns.ts`, shared with `/cdrs` and `/accounts`.
 *
 * <p><strong>The array order is the TABLE order.</strong> `group` affects the chooser and nothing
 * else. `cdr-columns.ts` happens to be clustered by group and it does not matter there; clustering
 * this one would silently reorder an operator's table, because "Via" is a Route column sitting
 * between two Message columns in the layout this page has always had.
 *
 * <p>Database-free, so a client component can import it.
 */

export type RejectedFormat =
  //the timestamp
  | "time"
  | "text"
  //an identifier: monospaced, because these are compared character by character
  | "id"
  | "number"
  //the refusal itself: a badge, the detail beneath it, and a link to the message when there is one
  | "reason"
  //the carrier's number with its mnemonic beside it
  | "receipt"
  | "vendorStatus"
  //the ingress, with the listener that took it
  | "ingress"
  //a link to the call record, for the refusals that have one
  | "msgid"
  //a smallint the gateway writes as 0 when it never computed one. See `parts` below
  | "countOrUnknown"
  | "yesno"
  //free text with a click-to-expand: the detail and the message excerpt
  | "excerpt";

export type RejectedColumnGroup = "Refusal" | "Route" | "Message";

/**
 * The nine columns that are on by default are exactly the nine the table rendered before it had a
 * chooser, in exactly that order, so nobody's view changed on upgrade. `rejected-columns.test.ts`
 * pins that list, order included.
 */
export interface RejectedColumn extends TableColumn<RejectedRow, RejectedColumnGroup> {
  format: RejectedFormat;
}

export const REJECTED_COLUMNS: readonly RejectedColumn[] = [
  { id: "rejectedAt", header: "Refused", group: "Refusal", from: (r) => r.rejectedAt, format: "time", defaultOn: true },

  /**
   * The raw token, rendered as the badge cluster the page has always shown.
   *
   * <p>`from` returns the token rather than its label because that is what the cell needs; the
   * English is available as its own column for anyone who wants a plain one to read or export.
   */
  { id: "reason", header: "Why", group: "Refusal", from: (r) => r.reason, format: "reason", defaultOn: true, unsortable: true },
  { id: "reasonLabel", header: "Why, in English", group: "Refusal", from: (r) => reasonLabel(r.reason), format: "text", defaultOn: false },
  { id: "detail", header: "Detail", group: "Refusal", from: (r) => r.detail, format: "excerpt", defaultOn: false, unsortable: true },

  /**
   * Whether the customer was told yes before this happened.
   *
   * <p>Derived rather than stored, and worth a column of its own: it is the difference between "we
   * refused it at the door, nothing was charged" and "we accepted it, charged it, then could not
   * send it and gave the money back". Sorting by it groups the two kinds, which is why it is left
   * sortable while the badge above is not.
   */
  { id: "afterAccepting", header: "Charged, then refunded", group: "Refusal", from: (r) => refusedAfterAccepting(r.reason), format: "yesno", defaultOn: false },

  //off by default, and that is deliberate rather than timidity. Most refusals happen at the door,
  //where the client was told in the response it was already waiting on, so this column reads
  //"Told at submit" on the majority of rows and earns nothing. It is worth turning on for the
  //question it exists to answer -- did the customer hear about a message we accepted and then
  //dropped -- which is a question an operator asks deliberately, not one they scan for
  { id: "receipt", header: "Customer told", group: "Refusal", from: (r) => receiptLabel(r.receipt), format: "text", defaultOn: false },
  { id: "vendorStatus", header: "Vendor said", group: "Refusal", from: (r) => r.vendorStatus, format: "vendorStatus", defaultOn: true },
  { id: "vendorStatusName", header: "Vendor code name", group: "Refusal", from: (r) => (r.vendorStatus == null ? null : vendorStatusName(r.vendorStatus)), format: "text", defaultOn: false },

  { id: "accountId", header: "Account", group: "Route", from: (r) => r.accountId, format: "id", defaultOn: true },
  { id: "systemId", header: "System ID", group: "Route", from: (r) => r.systemId, format: "id", defaultOn: false },
  { id: "product", header: "Product", group: "Route", from: (r) => r.product, format: "id", defaultOn: true },
  { id: "sourceAddr", header: "From", group: "Message", from: (r) => r.sourceAddr, format: "id", defaultOn: true },
  { id: "destAddr", header: "To", group: "Message", from: (r) => r.destAddr, format: "id", defaultOn: true },

  /** Ingress with the listener beside it, which is how this cell has always read. */
  { id: "ingress", header: "Via", group: "Route", from: (r) => r.ingress, format: "ingress", defaultOn: true },
  { id: "inGateway", header: "In gateway", group: "Route", from: (r) => r.inGateway, format: "text", defaultOn: false },

  /**
   * The first 160 characters of what was sent.
   *
   * <p>Unlike the call record's body, this is not behind `smsg.cdr.body`: a content refusal cannot
   * be diagnosed without seeing what was refused, so the gateway keeps the excerpt unconditionally.
   */
  { id: "bodyExcerpt", header: "Message", group: "Message", from: (r) => r.bodyExcerpt, format: "excerpt", defaultOn: true, unsortable: true },

  /** 0 is GSM 7-bit and entirely real, so this renders zeros. Contrast `parts` below. */
  { id: "dcs", header: "Data coding", group: "Message", from: (r) => r.dcs, format: "number", align: "right", defaultOn: false },

  /**
   * 0 here cannot be real — every message has at least one part — so it means the refusal happened
   * before anything counted them. The gateway writes a Java primitive, so there is no NULL to write
   * and the panel is the only place that distinction can be made.
   */
  { id: "parts", header: "Parts", group: "Message", from: (r) => r.parts, format: "countOrUnknown", align: "right", defaultOn: false },

  /**
   * Empty for most rows, and that is the fact rather than a gap: a message refused at the door was
   * never submitted, so there is nothing to point at. `|| null` because the gateway usually stores
   * an empty string rather than NULL — see `hasMsgId` in `rejected-request.ts`.
   */
  { id: "gatewayMsgId", header: "Message ID", group: "Message", from: (r) => r.gatewayMsgId || null, format: "msgid", defaultOn: false },

  { id: "id", header: "Row ID", group: "Refusal", from: (r) => r.id, format: "id", align: "right", defaultOn: false },
];

export const REJECTED_COLUMN_GROUPS = ["Refusal", "Route", "Message"] as const;

/**
 * Where the choice is kept.
 *
 * <p>Its own key, not the CDR page's: the two tables share no columns, so one stored preference
 * would resolve to nonsense on whichever page it was not written for.
 */
export const REJECTED_COLUMN_STORAGE_KEY = "fireflo.rejected.columns";

export type { ColumnChoice } from "./table-columns.ts";
export { readColumnChoice, toggleColumn } from "./table-columns.ts";

/** The catalogue is fixed here, so callers pass only the stored choice. */
export function resolveColumns(
  choice: import("./table-columns").ColumnChoice | null
): RejectedColumn[] {
  return resolveFrom(REJECTED_COLUMNS, choice) as RejectedColumn[];
}
