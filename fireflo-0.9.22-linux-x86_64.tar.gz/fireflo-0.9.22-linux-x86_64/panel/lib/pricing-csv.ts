import { csv, parseCsv } from "@/lib/csv";
import { AMOUNT_PATTERN, type ConditionInput, type RateRule, type RateRuleInput } from "@/lib/rate-types";

/**
 * Pricing rules as CSV, and the diff a file produces against what is stored.
 *
 * <p>Client-safe and pure — the preview and the apply both run it, so they cannot disagree about what
 * a file means.
 */

/**
 * Fixed, and new columns go on the end.
 *
 * <p>Whoever opens this in a spreadsheet writes formulas against column letters. Reordering breaks
 * those silently.
 */
export const COLUMNS = [
  "scope",
  "seq",
  "rule_id",
  "amount",
  "product",
  "currency",
  "label",
  "enabled",
  "filters",
  "conditions",
] as const;

/** Between conditions, matching the file grammar's multi-condition separator. */
const CONDITION_SEPARATOR = " ~~ ";

/**
 * Conditions packed into one cell as `field:operator:value`.
 *
 * <p>Not a new dialect: this is the `rule_line` grammar the gateway's own configuration files use, so
 * anyone who has read `rates.conf` can read this column. Negation is a `!` prefix on the operator,
 * as it is there.
 */
export function packConditions(conditions: ConditionInput[]): string {
  return conditions
    .map((c) => `${c.field}:${c.negate ? "!" : ""}${c.operator}:${c.value}`)
    .join(CONDITION_SEPARATOR);
}

/**
 * The inverse, split right-limited.
 *
 * <p>`field` up to the first colon, `operator` up to the second, **everything after is the value** —
 * so a regex like `^\d{2}:\d{2}$` survives, which is entirely plausible in a condition. Only a colon
 * inside a field or operator name would break it, and neither catalogue contains one.
 *
 * @throws Error naming the offender rather than guessing
 */
export function unpackConditions(cell: string): ConditionInput[] {
  const text = cell.trim();
  if (!text) {
    return [];
  }
  return text.split(CONDITION_SEPARATOR).map((part) => {
    const first = part.indexOf(":");
    const second = part.indexOf(":", first + 1);
    if (first < 0 || second < 0) {
      throw new Error(
        `'${part}' is not a condition. Each one is field:operator:value, joined by ' ~~ '.`
      );
    }
    const operator = part.slice(first + 1, second);
    return {
      field: part.slice(0, first),
      operator: operator.startsWith("!") ? operator.slice(1) : operator,
      value: part.slice(second + 1),
      negate: operator.startsWith("!"),
    };
  });
}

export function toCsv(scopes: { scope: string; rules: RateRule[] }[]): string {
  const lines = [COLUMNS.join(",")];
  for (const { scope, rules } of scopes) {
    for (const rule of rules) {
      lines.push(
        [
          scope,
          rule.seq,
          rule.id,
          rule.amount,
          rule.product ?? "",
          rule.currency ?? "",
          rule.label ?? "",
          rule.enabled ? "true" : "false",
          rule.filters.join(";"),
          packConditions(rule.conditions),
        ]
          .map(csv)
          .join(",")
      );
    }
  }
  return `${lines.join("\n")}\n`;
}

export interface ParsedRow {
  scope: string;
  ruleId: number | null;
  amount: string;
  product: string | null;
  currency: string | null;
  label: string | null;
  enabled: boolean;
  filters: string[];
  conditions: ConditionInput[];
}

/**
 * A file into rows, or the first reason it is not usable.
 *
 * <p>Whole-file refusal on any bad row rather than importing what parses. A pricing file that half
 * applied would leave a scope in a state nobody described.
 *
 * @param product the page's product — a row naming a different one is refused, or a product-scoped
 *     import quietly becomes a general pricing rewrite
 */
export function fromCsv(text: string, product: string): ParsedRow[] | string {
  let rows: string[][];
  try {
    rows = parseCsv(text);
  } catch (err) {
    return err instanceof Error ? err.message : "The file could not be parsed.";
  }
  if (!rows.length) {
    return "The file is empty.";
  }

  //exact and in order, not "contains". A reordered header on a money import is not a place to be
  //clever. Extra trailing columns are ignored so a future column stays compatible
  const header = rows[0];
  for (let i = 0; i < COLUMNS.length; i++) {
    if (header[i]?.trim() !== COLUMNS[i]) {
      return `Column ${i + 1} of the header is '${header[i] ?? ""}', expected '${COLUMNS[i]}'. The `
        + `columns must be exactly ${COLUMNS.join(", ")}, in that order.`;
    }
  }

  const parsed: ParsedRow[] = [];
  for (let n = 1; n < rows.length; n++) {
    const row = rows[n];
    const where = `Row ${n + 1}`;
    if (row.length < COLUMNS.length) {
      return `${where} has ${row.length} values, expected ${COLUMNS.length}.`;
    }
    const [scope, , ruleId, amount, rowProduct, currency, label, enabled, filters, conditions] = row;

    if (!scope.trim()) {
      return `${where} has no scope.`;
    }
    if (scope !== scope.trim()) {
      return `${where}'s scope has a space at one end. Scopes are matched exactly.`;
    }
    if (!AMOUNT_PATTERN.test(amount.trim())) {
      return `${where}'s amount '${amount}' must be a plain number with at most four decimal places. `
        + "The column stores four and rounds on the way in rather than refusing.";
    }
    if (rowProduct.trim() && rowProduct.trim() !== product) {
      return `${where} is for product '${rowProduct}', not '${product}'. Importing it here would turn `
        + "a product's pricing file into a general rewrite.";
    }
    if (enabled.trim() !== "true" && enabled.trim() !== "false") {
      return `${where}'s enabled is '${enabled}', expected true or false.`;
    }
    if (ruleId.trim() && !/^\d+$/.test(ruleId.trim())) {
      return `${where}'s rule_id '${ruleId}' is not a whole number. Leave it blank to add a new rule.`;
    }

    let unpacked: ConditionInput[];
    try {
      unpacked = unpackConditions(conditions);
    } catch (err) {
      return `${where}: ${err instanceof Error ? err.message : "bad conditions"}`;
    }

    parsed.push({
      scope: scope.trim(),
      ruleId: ruleId.trim() ? Number(ruleId.trim()) : null,
      amount: amount.trim(),
      product: rowProduct.trim() || null,
      currency: currency.trim() || null,
      label: label.trim() || null,
      enabled: enabled.trim() === "true",
      filters: filters.trim() ? filters.split(";").map((f) => f.trim()).filter(Boolean) : [],
      conditions: unpacked,
    });
  }
  return parsed;
}

export interface FieldChange {
  field: string;
  from: string;
  to: string;
}

export interface RulePlan {
  scope: string;
  ruleId: number | null;
  describe: string;
  changes: FieldChange[];
}

export interface ImportPlan {
  added: RulePlan[];
  changed: RulePlan[];
  removed: RulePlan[];
  unchanged: number;
  /** Scopes the file touches, each of which is replaced wholesale. */
  scopes: string[];
  /** The complete rule list per scope, ready for PUT. */
  result: Record<string, RateRuleInput[]>;
}

/**
 * What a file would do.
 *
 * <p><strong>Rows match by `rule_id`, never by `(scope, seq)`.</strong> `seq` is rewritten from array
 * position on every save, so it names a position rather than a rule — a file exported before someone
 * inserted a rule would apply row three's amount to whatever now sits there, and because ids are
 * preserved the call records would go on saying a rule charged an amount it never charged.
 *
 * <p><strong>A scope the file mentions is replaced wholesale</strong>, because that is all
 * `saveScope` can do. So a rule of that scope missing from the file is a deletion, and the caller
 * must present those individually rather than as a count.
 *
 * @returns the plan, or the first reason the file cannot be applied
 */
export function diffScopes(
  rows: ParsedRow[],
  stored: { scope: string; rules: RateRule[] }[]
): ImportPlan | string {
  const byScope = new Map(stored.map((s) => [s.scope, s.rules]));
  const touched = [...new Set(rows.map((r) => r.scope))];

  const plan: ImportPlan = {
    added: [], changed: [], removed: [], unchanged: 0, scopes: touched, result: {},
  };

  for (const scope of touched) {
    const existing = byScope.get(scope) ?? [];
    const byId = new Map(existing.map((r) => [r.id, r]));
    const seen = new Set<number>();
    const result: RateRuleInput[] = [];

    for (const row of rows.filter((r) => r.scope === scope)) {
      if (row.ruleId == null) {
        plan.added.push({ scope, ruleId: null, describe: `${row.amount}`, changes: [] });
        result.push(toInput(row, null));
        continue;
      }
      const current = byId.get(row.ruleId);
      if (!current) {
        //inventing a rule for an unknown id is how a whole tariff quietly lands in the wrong place
        return `Rule ${row.ruleId} is not part of '${scope}'. This file is from another scope or `
          + "another deployment. Clear the rule_id to add it as a new rule instead.";
      }
      if (current.filters.join(";") !== row.filters.join(";")) {
        return `Rule ${row.ruleId} carries the shared filter(s) ${current.filters.join(", ") || "none"}, `
          + `and the file says ${row.filters.join(", ") || "none"}. This panel cannot edit named `
          + "filters, and dropping one does not make a rule fail — it makes it match more, at "
          + "whatever amount it was carrying.";
      }
      seen.add(row.ruleId);

      const changes = fieldChanges(current, row);
      if (changes.length) {
        plan.changed.push({ scope, ruleId: row.ruleId, describe: `#${row.ruleId}`, changes });
      } else {
        plan.unchanged++;
      }
      result.push(toInput(row, row.ruleId));
    }

    for (const rule of existing) {
      if (!seen.has(rule.id)) {
        plan.removed.push({
          scope,
          ruleId: rule.id,
          describe: `${rule.amount}${rule.product ? ` on ${rule.product}` : ""}`,
          changes: [],
        });
      }
    }
    plan.result[scope] = result;
  }

  return plan;
}

function fieldChanges(current: RateRule, row: ParsedRow): FieldChange[] {
  const changes: FieldChange[] = [];
  const compare = (field: string, from: string, to: string) => {
    if (from !== to) {
      changes.push({ field, from, to });
    }
  };
  compare("amount", current.amount, row.amount);
  compare("product", current.product ?? "", row.product ?? "");
  compare("currency", current.currency ?? "", row.currency ?? "");
  compare("label", current.label ?? "", row.label ?? "");
  compare("enabled", String(current.enabled), String(row.enabled));
  compare("conditions", packConditions(current.conditions), packConditions(row.conditions));
  return changes;
}

function toInput(row: ParsedRow, id: number | null): RateRuleInput {
  return {
    id,
    amount: row.amount,
    product: row.product,
    currency: row.currency,
    label: row.label,
    enabled: row.enabled,
    conditions: row.conditions,
    filters: row.filters,
  };
}
