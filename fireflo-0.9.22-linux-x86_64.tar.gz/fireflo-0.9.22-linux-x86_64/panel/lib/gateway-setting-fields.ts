import type { SettingWidget } from "./setting-fields";

/**
 * The gateway-wide keys this panel is willing to edit, and how to render them.
 *
 * <h2>An allow-list, not a key/value editor</h2>
 *
 * <p>There are 59 `smsg.*` keys in the gateway source. This catalogue holds the ones an operator has
 * a reason to change, and a key with no entry here cannot be written from the panel at all. That is
 * the security boundary, and it is deliberately a list rather than a filter:
 *
 * <ul>
 *   <li><strong>Credentials.</strong> `smsg.ops.token` and `smsg.ops.admin.token` are how the panel
 *       authenticates to the gateway. An editor for a credential is how a credential leaks — into a
 *       screenshot, a support ticket, a browser's autofill store.
 *   <li><strong>Anything that decides where configuration comes from.</strong> `smsg.config.source`
 *       and the four `*.file.path` keys. Editing those through a panel that reads its own
 *       configuration from the database is a way to lock everyone out of the room they are standing
 *       in.
 *   <li><strong>The broker and sink wiring.</strong> `smsg.queue.amqp.uri` can carry a password;
 *       `smsg.queue.provider` and `smsg.cdr.sink` change where messages and records go, mid-flight.
 *   <li><strong>The webhook egress guards.</strong> `smsg.webhook.private.targets` and
 *       `smsg.webhook.schemes` exist to stop the gateway being pointed at internal addresses.
 *       Loosening an SSRF guard from a web form is not an operator convenience.
 *   <li><strong>Keys the panel already edits elsewhere</strong> — currency, money scale, billing zone
 *       — because two editors for one value is how they come to disagree.
 * </ul>
 *
 * <h2>codedDefault is optional here, and that is the point</h2>
 *
 * <p>{@code SETTING_FIELDS} carries a `codedDefault` for every worker key, read out of the Java. This
 * catalogue allows null, because a default nobody has actually read is exactly the failure this whole
 * change exists to fix: the worker form has been telling operators "the gateway's default is X" from
 * a snapshot, and has been wrong whenever a gateway default was set. Null renders as "not set"
 * without a claim attached.
 *
 * <p>Every non-null value below was read from the gateway source at the call site, not from a
 * javadoc — see `smsg.restapi.billing.units`, where the two disagree.
 */
export interface GatewaySettingField {
  key: string;
  label: string;
  hint?: string;
  widget: SettingWidget;
  /** The literal the gateway parses when the key is absent, or null when it has not been verified. */
  codedDefault: string | null;
  /** Which part of the page this belongs to. */
  group: "restapi" | "gateway";
}

export const GATEWAY_SETTING_FIELDS: readonly GatewaySettingField[] = [
  // --- the REST ingress's own configuration ----------------------------------------------------
  {
    key: "smsg.restapi.whitelist.tlvs.mode",
    label: "Stamp approved TLVs",
    hint:
      "What a matched sender ID or template does with the TLVs it carries, for messages arriving " +
      "over HTTP. The SMPP listeners have their own setting and default the other way — this page " +
      "is where the two can be compared.",
    widget: {
      kind: "enum",
      options: [
        { value: "off", label: "Off — a match stamps nothing" },
        { value: "assign", label: "Assign — fill the tag only when the customer sent none" },
        { value: "replace", label: "Replace — the approved value always wins" },
      ],
    },
    //MessageSubmissionService:491 -- `configured.isBlank() ? TlvStampMode.REPLACE`
    codedDefault: "replace",
    group: "restapi",
  },
  {
    key: "smsg.restapi.mandatory.tlvs.submit",
    label: "Required TLVs",
    hint:
      "A message arriving over HTTP without these is refused. Declared separately from a listener's " +
      "own list because that belongs to one listener and there may be several — set both when the " +
      "requirement is gateway-wide. They do not track each other.",
    widget: { kind: "list", itemPlaceholder: "name_0x1400", itemKind: "tlv" },
    codedDefault: "",
    group: "restapi",
  },
  {
    key: "smsg.restapi.billing.units",
    label: "Billed per",
    hint:
      "Whether a long message costs once or once per segment over HTTP. SMPP always charges per " +
      "inbound PDU, so `segment` prices the two ingresses alike and `message` makes a long message " +
      "cheaper over HTTP.",
    widget: {
      kind: "enum",
      options: [
        { value: "segment", label: "Segment — each segment is a billable unit" },
        { value: "message", label: "Message — one charge however many segments" },
      ],
    },
    //MessageSubmissionService:649 -- getPrpt(PRP_BILLING_UNITS, UNITS_SEGMENT). NOTE the javadoc on
    //PRP_BILLING_UNITS says it defaults to `message`; the code says `segment`. Taken from the code,
    //because that is what the customer is charged
    codedDefault: "segment",
    group: "restapi",
  },
  {
    key: "smsg.restapi.product.required",
    label: "A product must be named",
    hint: "Refuse an HTTP submission that does not name a product this gateway sells.",
    widget: { kind: "boolean" },
    //MessageSubmissionService -- getBlnPrpt(PRP_PRODUCT_REQUIRED, "false")
    codedDefault: "false",
    group: "restapi",
  },
  {
    key: "smsg.restapi.maxRate.default",
    label: "Default rate limit",
    hint: "Messages per second for an account with no limit of its own. Unlimited when unset.",
    widget: { kind: "number" },
    //not verified at its call site, and deliberately not guessed
    codedDefault: null,
    group: "restapi",
  },

  // --- gateway-wide, both ingresses ------------------------------------------------------------
  {
    key: "smsg.whitelist.enabled",
    label: "Sender ID and template approval",
    hint:
      "The master switch. A listener's own flag and the product flag both have to agree before a " +
      "message is checked, so turning this off stops all approval checking everywhere.",
    widget: { kind: "boolean" },
    //WhitelistService:94 -- getBlnPrpt(ENABLED_KEY, false), and conf.example says "off by default"
    codedDefault: "false",
    group: "gateway",
  },
  {
    key: "smsg.rating.unrated.refuse",
    label: "Refuse messages that cannot be priced",
    hint: "Otherwise an unrated message is sent and charged nothing.",
    widget: { kind: "boolean" },
    //getBlnPrpt(PRP_REFUSE_UNRATED, "false")
    codedDefault: "false",
    group: "gateway",
  },
  {
    key: "smsg.dlr.forward.format",
    label: "Delivery receipt format",
    hint:
      "JSON posts a body carrying the state, both timestamps and the addresses. Kannel substitutes " +
      "%s and %d into the registered URL and issues a bare GET, which carries only what the URL was " +
      "written to hold — a URL with no placeholders gets a request with nothing in it.",
    widget: {
      kind: "enum",
      options: [
        { value: "json", label: "JSON — a posted body" },
        { value: "kannel", label: "Kannel — placeholders in the URL" },
      ],
    },
    //ForwardDlrService:203 -- getPrpt(PRP_FORMAT, FORMAT_JSON)
    codedDefault: "json",
    group: "gateway",
  },
  {
    key: "smsg.dlr.forward.fields.vendor",
    label: "Name the vendor in receipts",
    hint:
      "Off unless switched on. The field names your supplier to your customer, at an endpoint the " +
      "customer controls — the CDR surfaces already treat that as buy-side and refuse it.",
    widget: { kind: "boolean" },
    //ForwardDlrService:222 -- getBlnPrpt(PRP_SEND_VENDOR, false)
    codedDefault: "false",
    group: "gateway",
  },
  {
    key: "smsg.cdr.events.response",
    label: "Keep what a callback endpoint answered",
    hint:
      "Off unless switched on. Records up to 500 characters of the response body and a fixed list " +
      "of headers on each callback attempt, which is where a 401 behind a proxy stops looking like " +
      "a 401 from the application. It is a separate key from the diagnostics level on purpose: a " +
      "response body is a customer's own server's content, and no level turns that on for you.",
    widget: { kind: "enum", options: [
      { value: "off", label: "Off" },
      { value: "excerpt", label: "First 500 characters" },
    ] },
    //ResponseMode.of -- null and anything unrecognised resolve to OFF
    codedDefault: "off",
    group: "gateway",
  },
  {
    key: "smsg.cdr.deadline.hours",
    label: "Give up waiting for a receipt after (hours)",
    hint: "The expiry sweep closes a message still PENDING for longer than this, as EXPIRED.",
    //no unit on the widget: SettingWidget offers ms, s and min, and this key is hours. The label
    //carries it rather than the field rendering "48 minutes" beside a value that means two days
    widget: { kind: "number" },
    //CdrExpirySweeper:49 -- DEFAULT_DEADLINE_HOURS = 48
    codedDefault: "48",
    group: "gateway",
  },
];

/** Fields for one section of the page, in catalogue order. */
export function gatewayFieldsFor(group: GatewaySettingField["group"]): GatewaySettingField[] {
  return GATEWAY_SETTING_FIELDS.filter((f) => f.group === group);
}

//`isEditableGatewayKey` used to live here, and membership of this catalogue was the security
//boundary. It no longer is: the free-form editor means an operator can name a key this catalogue has
//never heard of, so the boundary had to become a thing of its own that can be reasoned about and
//tested. It is `lib/gateway-key-policy.ts`. This file is now what it says on the front -- the keys
//that get a label, a widget and a hint -- and answers no security question at all
