/**
 * What one billing account actually has, gathered for the credential form.
 *
 * <p>Server-only: two pools, and neither may be reached from a browser. The shapes live in
 * `account-context-types` so a client component can import them without dragging `pg` in with them.
 *
 * <p><strong>Read-only, and through the read-only pool.</strong> Nothing in this module writes
 * anything; it reads through `metrics-db`, which exposes only `query()`. Writing credit lives in
 * `balance.ts` on the config pool, and even there the panel only ever appends `balance_ledger` rows
 * and creates `account_balance` rows at zero — the gateway's recharge poll remains the one writer of
 * the live `balance` figure.
 *
 * <p>What this adds is visibility: the ledger, so the person looking at a credential can see what
 * has been credited and what has not landed yet.
 */
import type { AccountContext, LedgerView } from "./account-context-types";
import { DEFAULT_LEDGER_SCOPE, humanEntriesPredicate, type LedgerScope } from "./ledger-scope";
import { query } from "./metrics-db";
import { currencyForNewBalance, platformCurrency } from "./platform-currency";
import { scopeKind } from "./rate-types";
import { listRules, resolveKnownScopes } from "./rates";

export type { AccountContext, LedgerEntry, LedgerView } from "./account-context-types";

/**
 * Everything five independent lookups can say about an account, none of them fatal.
 *
 * <p>`allSettled` rather than `all`: a panel pointed at a gateway without the balance tables, or
 * with a role that cannot read them, still has the rest. `null` for "could not read" and
 * `[]` for "read, and there are none" are different states and must not be conflated — an empty
 * ledger under a heading is a fact, a failed query pretending to be one is a lie.
 */
export async function accountContext(
  account: string,
  scope: LedgerScope = DEFAULT_LEDGER_SCOPE
): Promise<AccountContext> {
  const [balance, ledger, scopes, vendors, currency, inherited] = await Promise.allSettled([
    readBalance(account),
    readLedger(account, scope),
    readScopes(account),
    readVendors(account),
    platformCurrency(),
    //the chain a form should actually use: the gateway, then this account's parent. Settled
    //alongside the rest, so a failure here is "we could not work it out" rather than a page that
    //does not render -- and "could not work it out" is the same answer as "nobody has set one",
    //which both surfaces already handle
    currencyForNewBalance(account),
  ]);

  const scopeResult = settled(scopes);

  return {
    account,
    balance: balance.status === "fulfilled" ? balance.value : null,
    //only meaningful when the query itself succeeded; a failed read is not "no row"
    balanceMissing: balance.status === "fulfilled" && balance.value === null,
    ledger: settled(ledger),
    scopes: scopeResult?.scopes ?? null,
    vendors: settled(vendors),
    //null covers both "could not read" and "not set", which the form has to tell apart from a
    //currency it may safely assume. It asks only when this is null
    platformCurrency: settled(currency),
    currencyForNewBalance: settled(inherited) ?? { code: null, from: null },
    //true here because this function answers for the OPERATOR, who is the party that extends
    //credit in the first place. The portal route narrows it to the reseller's own terms
    mayGrantPostpaid: true,
    //no ceiling for an operator: the credit line starts with them
    postpaidHeadroom: null,
    collidesWithVendor: scopeResult?.collides ?? false,
  };
}

function settled<T>(result: PromiseSettledResult<T>): T | null {
  return result.status === "fulfilled" ? result.value : null;
}

/**
 * The live position.
 *
 * <p><strong>No `WHERE enabled`</strong>, unlike `accountBalances()` on the overview. That filter
 * collapses "there is no row" and "credit is switched off" into the same answer, and those are the
 * two states an operator most needs told apart. `reserved` comes back separately because it has
 * already been handed to a gateway instance and is not available to spend.
 */
async function readBalance(account: string): Promise<AccountContext["balance"]> {
  const rows = await query<{
    balance: string;
    reserved: string;
    currency: string | null;
    enabled: boolean;
    billing_mode: string;
    credit_limit: string;
  }>(
    `SELECT balance, reserved, currency, enabled, billing_mode, credit_limit
       FROM account_balance WHERE account_id = $1`,
    [account]
  );
  const row = rows[0];
  return row
    ? {
        balance: Number(row.balance),
        reserved: Number(row.reserved),
        currency: row.currency,
        enabled: row.enabled,
        billingMode: row.billing_mode === "POSTPAID" ? "POSTPAID" : "PREPAID",
        creditLimit: Number(row.credit_limit),
      }
    : null;
}

/**
 * The ledger, with the gateway's own block bookkeeping left out by default.
 *
 * <p>`idx_balance_ledger_human` covers the default ordering exactly, which is why the predicate
 * comes from {@link humanEntriesPredicate} rather than being written here — the two have to agree
 * character for character or the planner cannot use the partial index.
 *
 * <p>The hidden rows are **counted**, in the same round trip, so the card can say how many there
 * are. Hiding thousands of rows silently would replace one confusing page with a different one.
 */
async function readLedger(account: string, scope: LedgerScope): Promise<LedgerView> {
  const humanOnly = scope === "human";
  const rows = await query<{
    id: string;
    delta: string;
    entry_type: string;
    ref: string | null;
    note: string | null;
    applied: boolean;
    created_at: string;
  }>(
    `SELECT id, delta, entry_type, ref, note, applied, created_at
       FROM balance_ledger
      WHERE account_id = $1
        ${humanOnly ? `AND ${humanEntriesPredicate()}` : ""}
      ORDER BY created_at DESC, id DESC
      LIMIT 50`,
    [account]
  );

  //counted whichever scope is asked for, so switching to "all" does not make the number disappear
  //and leave the operator wondering whether it was ever true
  const [counted] = await query<{ machine: string }>(
    `SELECT count(*) AS machine FROM balance_ledger
      WHERE account_id = $1 AND NOT (${humanEntriesPredicate()})`,
    [account]
  );

  return {
    scope,
    machineEntries: Number(counted?.machine ?? 0),
    entries: rows.map((r) => ({
      id: Number(r.id),
      delta: Number(r.delta),
      entryType: r.entry_type,
      ref: r.ref,
      note: r.note,
      applied: r.applied,
      createdAt: r.created_at,
    })),
  };
}

/**
 * The rate scopes that price this account, and whether the name is ambiguous.
 *
 * <p>A scope is just a name, and `scopeKind` decides what it means by looking it up in both
 * directions. An account id that is also a vendor name is a real hazard rather than a curiosity: the
 * same rules would be read as cost for one and price for the other.
 */
async function readScopes(
  account: string
): Promise<{ scopes: { scope: string; kind: string; rules: number }[]; collides: boolean }> {
  const [rules, known] = await Promise.all([listRules(account), resolveKnownScopes()]);
  return {
    scopes: rules.length ? [{ scope: account, kind: scopeKind(account, known), rules: rules.length }] : [],
    collides: known.vendors.includes(account),
  };
}

/**
 * Where this account's traffic actually went.
 *
 * <p><strong>Not filtered to `part_no = 1`</strong>, which every aggregate on
 * the revenue page is. A retry that landed on a second vendor is precisely the thing this question
 * is asking about, and the standard filter would hide it.
 */
async function readVendors(account: string): Promise<{ vendor: string; messages: number }[]> {
  //bounded to 90 days (Audit F15): this was a lifetime scan per page open, and "where does this
  //account's traffic actually go" is a question about recent traffic -- a vendor last used two
  //years ago is exactly the stale answer the card should not lead with. The range rides the
  //(account_id, submitted_at) index instead of walking the account's whole history
  const rows = await query<{ vendor: string | null; messages: string }>(
    `SELECT vendor, count(*) AS messages
       FROM cdr_submit
      WHERE account_id = $1 AND vendor IS NOT NULL
        AND submitted_at > now() - interval '90 days'
      GROUP BY vendor
      ORDER BY count(*) DESC
      LIMIT 10`,
    [account]
  );
  return rows.map((r) => ({ vendor: r.vendor ?? "", messages: Number(r.messages) }));
}
