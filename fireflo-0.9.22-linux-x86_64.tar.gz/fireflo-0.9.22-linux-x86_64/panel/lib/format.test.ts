import { test } from "node:test";
import assert from "node:assert/strict";
import {
  clampScale,
  DEFAULT_MONEY_SCALE,
  money,
  moneyFromBigintString,
  moneyScale,
  setMoneyScale,
} from "./format.ts";


/**
 * The declared decimal length, and the three functions that used to disagree about it.
 *
 * <p>Before this, one amount could be rendered three ways: `money()` through `toLocaleString` at 2–4
 * places, a rate through `.toFixed(4)`, and the portal's balance by slicing the last four digits off
 * a string — which is truncation, not rounding. `12462.2795` came out as `12462.28` in one place and
 * `12462.27` in another, a cent apart on the same number.
 *
 * <p>These pin the two survivors against each other and against the gateway's `Money.display`, whose
 * own tests use the same fixtures. If those two ever disagree, a customer sees one balance in the
 * portal and a different one from `/secure/balance`.
 */

/** 124622795 ten-thousandths — the dev account's balance, and not a round number. */
const BALANCE = 124_622_795;

test("a total rounds HALF_UP to the declared scale", () => {
  assert.equal(money(BALANCE, "", 2), "12,462.28");
  assert.equal(money(BALANCE, "", 4), "12,462.2795");
  assert.equal(money(BALANCE, "", 0), "12,462");
});

test("the string path agrees with the number path, digit for digit", () => {
  //the same amount, one arriving as a BIGINT string from the portal's summary route and one as a
  //number from an aggregate. A cent of disagreement here is a support ticket
  for (const scale of [0, 1, 2, 3, 4]) {
    assert.equal(
      moneyFromBigintString(String(BALANCE), scale),
      money(BALANCE, "", scale),
      `the two renderings differ at ${scale} decimal places`
    );
  }
});

test("HALF_UP, not truncation: this is the bug the portal had", () => {
  //slicing the last two digits off 2795 gives 27. Rounding gives 28, which is what the gateway
  //and the operator panel both say
  assert.equal(moneyFromBigintString("124622795", 2), "12,462.28");
  assert.equal(moneyFromBigintString("124622750", 2), "12,462.28", "exactly half goes up");
  assert.equal(moneyFromBigintString("124622749", 2), "12,462.27");
});

test("a carry across the whole part is carried, not dropped", () => {
  //9.9999 at two places is 10.00, and the naive string slice would have said 9.99
  assert.equal(moneyFromBigintString("99999", 2), "10.00");
  assert.equal(moneyFromBigintString("99999", 0), "10");
  assert.equal(money(99_999, "", 2), "10.00");
});

test("a balance larger than Number.MAX_SAFE_INTEGER survives the string path", () => {
  //the reason the portal formats from a string at all: this is a BIGINT column, and the number
  //path would have lost the low digits before it got to the rounding
  assert.equal(
    moneyFromBigintString("123456789012345678", 2),
    "12,345,678,901,234.57"
  );
});

test("a negative balance rounds away from zero, like the positive", () => {
  assert.equal(money(-124_622_795, "", 2), "-12,462.28");
  assert.equal(moneyFromBigintString("-124622795", 2), "-12,462.28");
});

test("zero renders at the declared scale rather than as a bare 0", () => {
  assert.equal(money(0, "", 2), "0.00");
  assert.equal(moneyFromBigintString("0", 2), "0.00");
  assert.equal(money(0, "", 0), "0");
});

test("the currency is appended, and only when there is one", () => {
  assert.equal(money(BALANCE, "INR", 2), "12,462.28 INR");
  assert.equal(money(BALANCE, "", 2), "12,462.28");
});

test("the platform scale is what money() uses when nothing is passed", () => {
  const previous = moneyScale();
  try {
    setMoneyScale(2);
    assert.equal(money(BALANCE), "12,462.28");
    setMoneyScale(4);
    assert.equal(money(BALANCE), "12,462.2795");
  } finally {
    setMoneyScale(previous);
  }
});

/**
 * `clampScale` is the panel's copy of the gateway's `Money.displayScale`, and the two are lenient in
 * the same direction on purpose: a bad configuration row must not stop an amount rendering.
 */
test("an unset or nonsense scale is four, and never an exception", () => {
  assert.equal(clampScale(null), DEFAULT_MONEY_SCALE);
  assert.equal(clampScale(undefined), DEFAULT_MONEY_SCALE);
  assert.equal(clampScale(""), DEFAULT_MONEY_SCALE);
  assert.equal(clampScale("  "), DEFAULT_MONEY_SCALE, "Number('  ') is 0, and 0 is a legal scale");
  assert.equal(clampScale("two"), DEFAULT_MONEY_SCALE);
  assert.equal(clampScale("2.5"), DEFAULT_MONEY_SCALE);
});

test("above four is refused: the fifth place does not exist in the database", () => {
  assert.equal(clampScale("5"), DEFAULT_MONEY_SCALE);
  assert.equal(clampScale("-1"), DEFAULT_MONEY_SCALE);
});

test("a real setting is honoured, including zero", () => {
  assert.equal(clampScale("0"), 0);
  assert.equal(clampScale("2"), 2);
  assert.equal(clampScale(" 2 "), 2);
  assert.equal(clampScale("4"), 4);
});
