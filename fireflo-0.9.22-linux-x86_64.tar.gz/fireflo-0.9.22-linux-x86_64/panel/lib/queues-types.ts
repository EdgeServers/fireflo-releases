/**
 * The gateway's live queues, as `/ops/queues` reports them.
 *
 * <p>Types only, no `pg` import: this is read by a client component, and anything that reaches into
 * the database from here drags the driver into the browser bundle.
 *
 * <p>The shape mirrors the gateway's `QueueDump` record. Note what is absent — there is no message
 * body and no field that carries one. `cdr_submit` excludes it on principle and the dump inherits
 * that, so this page shows how big each message is and never what it says.
 */

/** What a queue is for. Each answers a different question about where traffic is stuck. */
export type QueueKind = "router" | "pending" | "delayed" | "broker";

export interface QueueEntry {
  serial: string | null;
  msg_id: number;
  account: string | null;
  product: string | null;
  from: string | null;
  to: string | null;
  /** How long the text is. Present instead of the text. */
  body_chars: number;
  encoding: "gsm7" | "ucs2" | "binary";
  parts: number;
  retries: number;
  priority: number;
  ingress: string | null;
  target: string | null;
  queued_at: string | null;
  /** Delayed queues only: how long until this is eligible again. Negative means already due. */
  ready_in_ms?: number | null;
}

export interface QueueSnapshot {
  name: string;
  kind: QueueKind;
  /** The whole queue. `entries.length` is only what was listed — the two are different questions. */
  depth: number;
  /** Whether `entries` is the order the gateway will send in. False for priority and delay queues. */
  ordered: boolean;
  returned: number;
  /**
   * Broker queues only, and usually the number that matters more than the depth: a backlog with no
   * consumer is not slow, it is unattended. Absent elsewhere, where the concept does not apply.
   */
  consumers?: number | null;
  note?: string | null;
  entries: QueueEntry[];
}

export interface QueueDump {
  observed_at: string;
  limit_per_queue: number;
  queues: QueueSnapshot[];
}

/**
 * @returns what this kind of queue holds, in the words an operator would use
 */
export function kindLabel(kind: QueueKind): string {
  switch (kind) {
    case "router":
      return "Waiting to be routed";
    case "pending":
      return "Waiting for the vendor";
    case "delayed":
      return "Scheduled retries";
    case "broker":
      return "Held on the broker";
  }
}

/**
 * @returns the sentence that stops a number being misread, or undefined when it speaks for itself
 */
export function kindHint(kind: QueueKind): string | undefined {
  switch (kind) {
    case "router":
      return "Accepted and not yet assigned to a vendor. One queue for the whole gateway.";
    case "pending":
      return "Routed to this vendor and waiting for its session to take them.";
    case "delayed":
      return "Sending failed and these are queued to be tried again.";
    case "broker":
      return undefined;
  }
}

/**
 * The single most useful reading of a queue, and the reason `retries` is on the summary rather than
 * buried in the table.
 *
 * <p>A deep queue of first attempts and a deep queue of fifth attempts are different incidents with
 * opposite responses — add capacity, or stop sending to a vendor that is failing — and the depth
 * alone cannot tell them apart.
 */
export function diagnose(queue: QueueSnapshot): string | null {
  if (queue.depth === 0 || queue.entries.length === 0) {
    return null;
  }
  const retrying = queue.entries.filter((e) => e.retries > 0).length;
  const share = retrying / queue.entries.length;
  if (share >= 0.5) {
    return "Mostly retries — the vendor is failing, not merely slow. Adding capacity will not help.";
  }
  if (retrying > 0) {
    return "Some retries mixed in. Worth watching whether the share is growing.";
  }
  const accounts = new Set(queue.entries.map((e) => e.account ?? "—"));
  if (accounts.size === 1) {
    return `All first attempts, all from ${[...accounts][0]} — one sender's volume, not a vendor fault.`;
  }
  return "All first attempts — more arrived than is being drained, spread across senders.";
}
