import { oneRowPerMessage } from "./cdr-grain";
import { query } from "@/lib/metrics-db";
import { hasInterimTable } from "@/lib/metrics-schema";
import { resolveRange, type Range } from "@/lib/metrics-queries";

/**
 * How well each vendor reports on the traffic it carries.
 *
 * <p>Separate from `metrics-queries.ts` because it asks a different question about the same rows.
 * Those aggregates ask **what happened** — delivered, failed, what it cost. This asks **whether we
 * were told, and how quickly**, which is a property of the vendor rather than of the traffic and is
 * the one an operator argues with a carrier about.
 *
 * <p>The distinction that makes it worth a module: a vendor with a 95% delivery rate over the
 * messages it reported and a 40% reporting rate is not a good vendor. The first number is computed
 * over a denominator the vendor itself chose, and until now it was the only number the panel showed.
 *
 * <p>Server-only: importing this pulls `pg`.
 */

export interface ReceiptQualityRow {
  vendor: string | null;
  /** Messages sent in the window. One row per message: first segment, first attempt. */
  sent: number;
  /**
   * Messages the vendor gave an outcome for.
   *
   * <p><strong>EXPIRED is excluded on purpose.</strong> That state is written by our own sweeper
   * when no receipt arrived within the deadline — counting it as "reported" would let a vendor that
   * never says anything score 100%, which is precisely backwards.
   */
  reported: number;
  /** Messages the sweeper gave up on. The complement of `reported` that has already timed out. */
  expired: number;
  /** Still open: no receipt and not yet swept. Not a failure, and not yet a silence. */
  open: number;
  /** Of the reported ones, how many said delivered. */
  delivered: number;
  /** Seconds from submit to the outcome, over the messages that got one. Null when none did. */
  medianToOutcome: number | null;
  p90ToOutcome: number | null;
  /**
   * Progress receipts recorded for this vendor's traffic in the window.
   *
   * <p>Zero from a vendor that sends none — which is not a fault, merely a fact about what it will
   * tell you before the end. Null when this gateway has no `cdr_interim` at all, which is a
   * different statement and is rendered differently.
   */
  progressReceipts: number | null;
  /** Messages that got at least one progress receipt. */
  messagesWithProgress: number | null;
  /** Seconds from submit to the first sign of life, progress or outcome, whichever came first. */
  medianToFirstSign: number | null;
}

/**
 * One row per message, matching every other aggregate in this panel.
 *
 * <p>`part_no = 1` — the one row a message leaves, whatever happened to it. No retry term: a
 * retried message does not leave a second row, so adding one would drop the message rather than
 * deduplicate it. `lib/cdr-grain.ts` has the proof.
 */
const ONE_ROW_PER_MESSAGE = oneRowPerMessage();

/**
 * The earliest outcome per message, exactly as every other reader takes it.
 *
 * <p>`cdr_final` has no uniqueness constraint, so a plain join would double a message that received
 * two receipts and quietly inflate both the numerator and the timing percentiles.
 */
const OUTCOME = `
  LEFT JOIN LATERAL (
    SELECT f.final_state, f.final_at,
           --when the VENDOR answered, which is not the same column as when the message closed.
           --An EXPIRED row is written by our own sweeper at the deadline, so final_at on one of
           --those is a fact about our configuration and not about the vendor: including it drags
           --every percentile towards smsg.cdr.deadline.hours and reports 48h as a vendor's median
           --response time. percentile_cont ignores nulls, so nulling it here is the whole fix
           CASE WHEN f.final_state <> 'EXPIRED' THEN f.final_at END AS reported_at
      FROM cdr_final f
     WHERE f.gateway_msg_id = s.gateway_msg_id AND f.part_no = s.part_no
     --A real receipt outranks a swept EXPIRED, whichever landed first: EXPIRED is synthetic,
     --written by the gateway's expiry sweep, and a genuine receipt can still arrive after it
     --because the correlation index outlives the deadline. false sorts before true.
     --SAME RULE IN UsageRollup.java AND THREE OTHER lib/ QUERIES. Change one, change all five.
     ORDER BY (f.final_state = 'EXPIRED'), f.final_at
     LIMIT 1
  ) o ON TRUE`;

/**
 * The first progress receipt per message, when the gateway records them.
 *
 * <p>Interpolated rather than parameterised because it is a fragment of SQL text and not a value —
 * it is either this constant or the empty string, and neither comes from a caller.
 */
const PROGRESS = `
  LEFT JOIN LATERAL (
    SELECT i.received_at, count(*) OVER () AS progress_count
      FROM cdr_interim i
     WHERE i.gateway_msg_id = s.gateway_msg_id AND i.part_no = s.part_no
     ORDER BY i.received_at
     LIMIT 1
  ) p ON TRUE`;

/**
 * Receipt quality per vendor over the range.
 *
 * <p>Degrades rather than fails against a gateway without `cdr_interim`: the progress columns come
 * back null and the surfaces say the gateway is not recording them, which is a different answer from
 * "this vendor sends none".
 */
export async function receiptQuality(range: Range): Promise<ReceiptQualityRow[]> {
  const { since, until } = resolveRange(range);
  const progress = await hasInterimTable();

  const rows = await query<Record<string, string | null>>(
    `SELECT s.vendor,
            count(*)                                                     AS sent,
            count(*) FILTER (WHERE o.final_state IS NOT NULL
                               AND o.final_state <> 'EXPIRED')           AS reported,
            count(*) FILTER (WHERE o.final_state = 'EXPIRED')            AS expired,
            count(*) FILTER (WHERE o.final_state IS NULL)                AS still_open,
            count(*) FILTER (WHERE o.final_state = 'DELIVERED')          AS delivered,
            percentile_cont(0.5) WITHIN GROUP (
              ORDER BY EXTRACT(EPOCH FROM (o.reported_at - s.submitted_at)))  AS median_outcome,
            percentile_cont(0.9) WITHIN GROUP (
              ORDER BY EXTRACT(EPOCH FROM (o.reported_at - s.submitted_at)))  AS p90_outcome,
            ${progress ? `
            COALESCE(sum(p.progress_count), 0)                           AS progress_receipts,
            count(*) FILTER (WHERE p.received_at IS NOT NULL)            AS with_progress,
            --LEAST ignores nulls in Postgres and returns null only when both are, which is exactly
            --the reading wanted: the earlier of the two when both exist, whichever exists when one
            --does, and nothing at all for a message that was never reported on
            percentile_cont(0.5) WITHIN GROUP (
              ORDER BY EXTRACT(EPOCH FROM (
                LEAST(p.received_at, o.reported_at) - s.submitted_at)))  AS median_first_sign
            ` : `
            NULL::bigint  AS progress_receipts,
            NULL::bigint  AS with_progress,
            --with no interim table the first sign IS the outcome, so this repeats the median above
            percentile_cont(0.5) WITHIN GROUP (
              ORDER BY EXTRACT(EPOCH FROM (o.reported_at - s.submitted_at)))  AS median_first_sign
            `}
       FROM cdr_submit s${OUTCOME}${progress ? PROGRESS : ""}
      WHERE ${ONE_ROW_PER_MESSAGE}
        AND s.submitted_at >= $1 AND s.submitted_at < $2
      GROUP BY s.vendor
      ORDER BY count(*) DESC`,
    [since, until]
  );

  return rows.map((r) => ({
    vendor: r.vendor ?? null,
    sent: int(r.sent),
    reported: int(r.reported),
    expired: int(r.expired),
    open: int(r.still_open),
    delivered: int(r.delivered),
    medianToOutcome: seconds(r.median_outcome),
    p90ToOutcome: seconds(r.p90_outcome),
    progressReceipts: progress ? int(r.progress_receipts) : null,
    messagesWithProgress: progress ? int(r.with_progress) : null,
    medianToFirstSign: seconds(r.median_first_sign),
  }));
}

/**
 * How often this vendor tells us anything at all.
 *
 * @returns a fraction of the messages that have settled one way or the other, or null while none
 *     have. **Open messages are excluded from the denominator**, not counted as silence — traffic
 *     sent four minutes ago has not yet had the chance to be reported on, and including it would
 *     make every vendor look worse the more recently you looked
 */
export function reportingRate(row: ReceiptQualityRow): number | null {
  const settled = row.reported + row.expired;
  return settled === 0 ? null : row.reported / settled;
}

/** Delivered as a fraction of what the vendor actually reported on. */
export function deliveryRate(row: ReceiptQualityRow): number | null {
  return row.reported === 0 ? null : row.delivered / row.reported;
}

function int(value: string | null | undefined): number {
  const n = Number(value ?? 0);
  return Number.isFinite(n) ? n : 0;
}

/** Null-preserving: "no message got an outcome" is not "it took zero seconds". */
function seconds(value: string | null | undefined): number | null {
  if (value == null || value === "") {
    return null;
  }
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}
