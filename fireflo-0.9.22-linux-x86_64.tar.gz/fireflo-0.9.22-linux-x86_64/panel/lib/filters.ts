import { configQuery, inTransaction } from "@/lib/config-db";
import type { ConditionInput } from "@/lib/rate-types";
import type { Filter, FilterInput } from "@/lib/filter-types";

/**
 * The filter library: named condition sets that rate rules and routing rules reference by name.
 *
 * <p>Server-only: importing this pulls `pg`. The shapes live in `filter-types.ts`, which also
 * carries the two facts about filters that matter — they expand at load time and AND with the rule's
 * own conditions, and disabling one *skips* every rule using it rather than widening it.
 *
 * <p>`app_filter` was created by V1.4.0 alongside the loaders that read it, and until now nothing
 * could write to it. It has been empty since, which is why no rule in this deployment references a
 * filter.
 */

interface FilterRow {
  name: string;
  label: string | null;
  enabled: boolean;
  updated_at: Date | null;
  rate_uses: number;
  route_uses: number;
}

/**
 * Every filter, with how much is riding on each.
 *
 * <p>The two usage counts are separate subqueries rather than joins: joining both would multiply
 * each filter by its rate references and its route references at once, the same trap
 * {@code listScope} documents for conditions and filters.
 *
 * <p>They are counted apart rather than summed because the consequences differ. A disabled filter
 * on a rate rule reprices traffic; on a routing rule it stops the traffic being sent at all.
 */
export async function listFilters(): Promise<Filter[]> {
  const rows = await configQuery<FilterRow>(
    `SELECT f.name, f.label, f.enabled, f.updated_at,
            COALESCE(r.uses, 0)::int AS rate_uses,
            COALESCE(t.uses, 0)::int AS route_uses
       FROM app_filter f
       LEFT JOIN (SELECT filter_name, count(*) AS uses
                    FROM app_rate_rule_filter GROUP BY filter_name) r ON r.filter_name = f.name
       LEFT JOIN (SELECT filter_name, count(*) AS uses
                    FROM app_route_rule_filter GROUP BY filter_name) t ON t.filter_name = f.name
      ORDER BY f.name`
  );

  const conditions = await configQuery<{
    filter_name: string; field: string; operator: string; value: string; negate: boolean;
  }>(
    `SELECT filter_name, field, operator, value, negate
       FROM app_filter_condition ORDER BY filter_name, seq`
  );

  const byFilter = new Map<string, ConditionInput[]>();
  for (const c of conditions) {
    const list = byFilter.get(c.filter_name) ?? [];
    list.push({ field: c.field, operator: c.operator, value: c.value, negate: c.negate });
    byFilter.set(c.filter_name, list);
  }

  return rows.map((f) => ({
    name: f.name,
    label: f.label,
    enabled: f.enabled,
    conditions: byFilter.get(f.name) ?? [],
    usedBy: { rates: Number(f.rate_uses), routes: Number(f.route_uses) },
    updatedAt: f.updated_at ? new Date(f.updated_at).toISOString() : null,
  }));
}

/**
 * Creates or replaces one filter.
 *
 * <p>Upsert on the name, then rewrite the conditions wholesale — the same shape `saveScope` uses for
 * a rule's conditions, and for the same reason: the conditions are an ordered list with no identity
 * of their own, so diffing them would be more code than replacing them.
 *
 * <p>In one transaction, so a filter is never briefly visible with half its conditions. The loader
 * polls this table, and a rule whose filter momentarily had one fewer condition would price or route
 * more traffic than intended for exactly that poll.
 */
export async function saveFilter(input: FilterInput): Promise<void> {
  const name = input.name.trim();
  await inTransaction(async (client) => {
    await client.query(
      `INSERT INTO app_filter (name, label, enabled, updated_at)
       VALUES ($1, $2, $3, now())
       ON CONFLICT (name) DO UPDATE
         SET label = EXCLUDED.label, enabled = EXCLUDED.enabled, updated_at = now()`,
      [name, input.label?.trim() || null, input.enabled]
    );
    await client.query(`DELETE FROM app_filter_condition WHERE filter_name = $1`, [name]);
    for (let i = 0; i < input.conditions.length; i++) {
      const c = input.conditions[i];
      await client.query(
        `INSERT INTO app_filter_condition (filter_name, seq, field, operator, value, negate)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [name, i, c.field.trim(), c.operator, c.value ?? "", c.negate]
      );
    }
  });
}

/**
 * Thrown when rules still reference the filter, which the foreign key refuses to orphan.
 *
 * <p>The field is `filterName`, not `name`: `Error` already owns `name` and setting it to the class
 * name — which is what every guide tells you to do — silently overwrote the filter's own name, so
 * the refusal read "'FilterInUse' is still used by…".
 */
export class FilterInUse extends Error {
  constructor(readonly filterName: string) {
    super(`'${filterName}' is still referenced by at least one rule.`);
    this.name = "FilterInUse";
  }
}

/**
 * Removes a filter, provided nothing references it.
 *
 * <p>`app_rate_rule_filter.filter_name` and `app_route_rule_filter.filter_name` reference this table
 * with no `ON DELETE` clause — unlike `app_filter_condition`, which cascades. That asymmetry is
 * right: a filter's own conditions belong to it, but a rule referencing it does not, and silently
 * dropping the reference would turn a narrowed rule into a catch-all that charges or routes
 * everything. The database refuses; this turns the refusal into a sentence.
 */
export async function deleteFilter(name: string): Promise<boolean> {
  try {
    const rows = await configQuery<{ name: string }>(
      "DELETE FROM app_filter WHERE name = $1 RETURNING name",
      [name]
    );
    return rows.length > 0;
  } catch (err) {
    if ((err as { code?: string })?.code === "23503") {
      throw new FilterInUse(name);
    }
    throw err;
  }
}
