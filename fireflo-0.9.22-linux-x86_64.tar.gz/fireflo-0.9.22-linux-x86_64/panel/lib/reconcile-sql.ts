/**
 * The SQL the reconciliation reads, with no database import.
 *
 * <p>Split out of `reconcile-queries.ts` so it can be asserted without a connection. The exclusions
 * below are the money identity expressed as a query, and the cheapest way for one to break is
 * somebody widening the entry-type list or dropping the anti-join -- both visible in the text.
 * See `reconcile-sql.test.ts`, and replace it with a container test when one exists.
 */

/**
 * Consumption, without double counting the overlap.
 *
 * <p><strong>The subtlety this exists to get right.</strong> A rolled-up day usually STILL HAS its
 * `cdr_submit` rows — the purge runs long after the rollup. Summing both tables would count that
 * day twice and invent a discrepancy the size of the retention window.
 *
 * <p>So: `usage_daily` for every day it covers, and `cdr_submit` only for days it does not. The two
 * sets are disjoint by construction, which makes the sum exact rather than approximately right.
 *
 * <p>The day boundary is the database's `AT TIME ZONE`, matching `UsageRollup` exactly. A different
 * zone here would slice the tail differently from the rollup and leave a sliver counted twice or
 * not at all.
 *
 * <p><strong>And the anti-join is at the summary's grain, which is per product.</strong>
 * `usage_daily` is keyed `(account_id, day, product)`, but this correlated on `(account_id, day)`
 * alone, so a day with an `otp` line already rolled up read as fully covered — and traffic on a
 * second product that arrived on that day afterwards fell in the gap: absent from `rolled` because
 * it has no line, and excluded from `tail` because the day "was covered". Consumption silently
 * **undercounted**, in the window between a rollup and the next one. The gateway's `UsageRollup`
 * had the same confusion in its purge interlock, where it read the other way and let a day be
 * purged with a product line missing; both are fixed to ask at the same grain.
 */
export const CONSUMED_SQL = `
  WITH rolled AS (
      SELECT COALESCE(SUM(price_total), 0) AS amount,
             COALESCE(SUM(unrated_messages), 0) AS unrated
        FROM usage_daily
       WHERE account_id = $1
  ),
  tail AS (
      SELECT COALESCE(SUM(s.price), 0) AS amount,
             count(*) FILTER (WHERE s.price IS NULL) AS unrated
        FROM cdr_submit s
       WHERE s.account_id = $1
         AND s.part_no = 1
         AND NOT EXISTS (
                 SELECT 1 FROM usage_daily u
                  WHERE u.account_id = s.account_id
                    AND u.day = (s.submitted_at AT TIME ZONE $2)::date
                    AND u.product = COALESCE(s.product, ''))
  )
  SELECT (SELECT amount FROM rolled) + (SELECT amount FROM tail)  AS consumed,
         (SELECT unrated FROM rolled) + (SELECT unrated FROM tail) AS unrated`;


/**
 * Money that actually entered or left the account.
 *
 * <p>`RECHARGE` and `TRANSFER` only. `RESERVE`/`RELEASE` net to zero against `balance + reserved`
 * and `BILL` moves nothing — including either would make every account look wrong by a predictable
 * amount, which is the worst kind of wrong because it looks like a real finding.
 *
 * <p>Split by `applied`, because an entry the gateway has not picked up yet is a known and benign
 * reason for a gap, and naming it is the difference between a shrug and a support call.
 *
 * <p><strong>A TRANSFER is one row describing two accounts, and reading it as one was this query's
 * worst bug.</strong> `/api/mis/transfer` writes a single row: `account_id` is the payer,
 * `counterparty_account_id` is the payee, and `delta` is always positive — `parseAmount` cannot
 * produce anything else. The gateway reads it correctly, debiting the payer and crediting the
 * counterparty. This query did not: it filtered on `account_id` alone and summed `delta` with no
 * regard to direction, so `counterparty_account_id` appeared nowhere in the panel outside the
 * INSERT that writes it. For a transfer of X the payer was counted **+X** while its balance moved
 * **−X**, and the payee was counted **nothing** while its balance moved **+X**:
 *
 * <pre>
 *   payer   drift +2X  ->  reported as creditLost
 *   payee   drift  −X  ->  reported as creditMinted
 * </pre>
 *
 * So I1 failed by construction on any account that had ever transferred — the very identity
 * `reconcile.ts` claims holds to the unit on every account — and a reseller funding a child was
 * shown "credit the account has and nobody put in", about money they had themselves sent.
 *
 * <p>Hence the three arms. A RECHARGE credits the named account. A TRANSFER is counted **twice**,
 * once negative against the payer and once positive for the payee, which is the same movement the
 * gateway's two statements make. The arms are disjoint by schema, not by hope:
 * `balance_ledger_transfer_has_counterparty` makes `counterparty_account_id IS NOT NULL` exactly
 * equivalent to `entry_type = 'TRANSFER'`, and `balance_ledger_transfer_not_self` forbids an
 * account transferring to itself, so no row can be caught by two arms at once.
 *
 * <p>Both directions carry `applied` from their own row, so a pending transfer is pending for both
 * sides — a payee's credit cannot appear before the payer's debit does.
 *
 * <p><strong>The same arithmetic lives in the gateway's `ArchiveCommand.accounts`</strong>, which
 * writes `credited_through` into the nightly archive. The two must not drift: a change to either
 * belongs in both, and getting it wrong there is worse, because the archive is the opening balance
 * every later period is differenced against and is not something anyone can reload.
 */
export const CREDITED_SQL = `
  SELECT COALESCE(SUM(signed) FILTER (WHERE applied), 0)     AS credited,
         COALESCE(SUM(signed) FILTER (WHERE NOT applied), 0) AS pending
    FROM (
        SELECT applied, delta AS signed
          FROM balance_ledger
         WHERE account_id = $1
           AND entry_type = 'RECHARGE'
        UNION ALL
        SELECT applied, -delta
          FROM balance_ledger
         WHERE account_id = $1
           AND entry_type = 'TRANSFER'
        UNION ALL
        SELECT applied, delta
          FROM balance_ledger
         WHERE counterparty_account_id = $1
           AND entry_type = 'TRANSFER'
    ) movement`;


/**
 * Days whose traffic no rollup fully covers. Their consumption is in the tail, but say so anyway.
 *
 * <p>Same grain as `CONSUMED_SQL`'s anti-join, and it has to be: this is the count of exactly the
 * days that query is taking from the call records instead of the summary. Two different grains here
 * would report a number that did not describe what the figure beside it was doing.
 */
export const MISSING_ROLLUP_SQL = `
  SELECT count(DISTINCT (s.submitted_at AT TIME ZONE $2)::date) AS days
    FROM cdr_submit s
   WHERE s.account_id = $1
     AND s.part_no = 1
     AND NOT EXISTS (
             SELECT 1 FROM usage_daily u
              WHERE u.account_id = s.account_id
                AND u.day = (s.submitted_at AT TIME ZONE $2)::date
                AND u.product = COALESCE(s.product, ''))`;


/**
 * `CONSUMED_SQL` and `MISSING_ROLLUP_SQL` for every account on the page, in ONE scan (Audit F15).
 *
 * <p>`reconcileAll` used to run the per-account queries in a loop: 200 accounts made 801
 * serialised round trips, four of them lifetime scans EACH. Grouped, the whole page is one pass
 * over `usage_daily` and one over `cdr_submit`.
 *
 * <p><strong>The arithmetic is `CONSUMED_SQL`'s, restated with GROUP BY, and the two must not
 * drift</strong> — same `part_no = 1`, same anti-join at the `(account_id, day, product)` grain,
 * same zone slicing. `reconcile-sql.test.ts` asserts the load-bearing fragments appear in both.
 * The tail scan also carries `MISSING_ROLLUP_SQL`'s distinct-day count, because it is a count over
 * exactly the rows this scan is already reading — a separate query would read them twice.
 *
 * <p>$1 = zone, $2 = the page's account limit, ordered as `reconcileAll` orders.
 */
export const CONSUMED_ALL_SQL = `
  WITH accts AS (
      SELECT account_id FROM account_balance ORDER BY account_id LIMIT $2
  ),
  rolled AS (
      SELECT u.account_id,
             COALESCE(SUM(u.price_total), 0) AS amount,
             COALESCE(SUM(u.unrated_messages), 0) AS unrated
        FROM usage_daily u
        JOIN accts a USING (account_id)
       GROUP BY u.account_id
  ),
  tail AS (
      SELECT s.account_id,
             COALESCE(SUM(s.price), 0) AS amount,
             count(*) FILTER (WHERE s.price IS NULL) AS unrated,
             count(DISTINCT (s.submitted_at AT TIME ZONE $1)::date) AS days
        FROM cdr_submit s
        JOIN accts a USING (account_id)
       WHERE s.part_no = 1
         AND NOT EXISTS (
                 SELECT 1 FROM usage_daily u
                  WHERE u.account_id = s.account_id
                    AND u.day = (s.submitted_at AT TIME ZONE $1)::date
                    AND u.product = COALESCE(s.product, ''))
       GROUP BY s.account_id
  )
  SELECT a.account_id,
         COALESCE(r.amount, 0) + COALESCE(t.amount, 0)   AS consumed,
         COALESCE(r.unrated, 0) + COALESCE(t.unrated, 0) AS unrated,
         COALESCE(t.days, 0)                             AS days
    FROM accts a
    LEFT JOIN rolled r USING (account_id)
    LEFT JOIN tail t USING (account_id)`;

/**
 * `CREDITED_SQL` for every account on the page, one pass over the ledger (Audit F15).
 *
 * <p>Same three arms, same signs, same disjointness-by-schema argument — see `CREDITED_SQL`, whose
 * text is the authority and whose docs carry the transfer-direction bug this must never
 * reintroduce. The archive drift warning there applies to this variant identically.
 *
 * <p>$1 = the page's account limit.
 */
export const CREDITED_ALL_SQL = `
  WITH accts AS (
      SELECT account_id FROM account_balance ORDER BY account_id LIMIT $1
  ),
  movement AS (
      SELECT account_id, applied, delta AS signed
        FROM balance_ledger
       WHERE entry_type = 'RECHARGE'
      UNION ALL
      SELECT account_id, applied, -delta
        FROM balance_ledger
       WHERE entry_type = 'TRANSFER'
      UNION ALL
      SELECT counterparty_account_id, applied, delta
        FROM balance_ledger
       WHERE entry_type = 'TRANSFER'
  )
  SELECT m.account_id,
         COALESCE(SUM(signed) FILTER (WHERE applied), 0)     AS credited,
         COALESCE(SUM(signed) FILTER (WHERE NOT applied), 0) AS pending
    FROM movement m
    JOIN accts a USING (account_id)
   GROUP BY m.account_id`;
