/**
 * Which `balance_ledger` rows are somebody's money and which are the gateway's bookkeeping.
 *
 * <p>Database-free on purpose, like `cdr-request.ts` and `whitelist-sql.ts`: it is imported by a
 * client component for the labels and by a server module for the SQL, and it is the only place the
 * distinction is written down.
 *
 * <p>The table holds two unrelated kinds of row under one `entry_type`. `RECHARGE` and `TRANSFER`
 * are money entering or leaving an account. `RESERVE` and `RELEASE` are the gateway moving its own
 * credit between `account_balance.balance` and `.reserved` so it can spend from memory — each pair
 * nets to zero, no money moves, and there is one every twenty messages or so. The panel read the
 * last fifty rows by time, so on any account with traffic all fifty were `RESERVE` and a customer's
 * payment was invisible.
 */

/** The gateway's own block bookkeeping. Everything else is somebody's money. */
export const MACHINE_ENTRY_TYPES = ["RESERVE", "RELEASE"] as const;

export type LedgerScope = "human" | "all";

export const DEFAULT_LEDGER_SCOPE: LedgerScope = "human";

export function isLedgerScope(value: unknown): value is LedgerScope {
  return value === "human" || value === "all";
}

/** Anything not machine bookkeeping. See `humanEntriesPredicate` for why this is stated negatively. */
export function isHumanEntry(entryType: string): boolean {
  return !(MACHINE_ENTRY_TYPES as readonly string[]).includes(entryType);
}

/**
 * The SQL that selects human entries, and the thing that must not drift.
 *
 * <p><strong>This text has to match `idx_balance_ledger_human`'s predicate exactly</strong>, or
 * PostgreSQL cannot prove the partial index covers the query and falls back to a sequential scan
 * over the whole ledger — which on a busy platform is the largest table after the CDRs. The failure
 * is silent: correct rows, slow page, nothing anywhere saying why. `ledger-scope.test.ts` asserts
 * the string by value against the migration's own wording for that reason.
 *
 * <p><strong>Negative, not a list of the human types.</strong> `BILL` and `ADJUSTMENT` are coming,
 * and whatever is invented after them is a human entry the day it is first written. A positive list
 * would need editing in two repositories every time the vocabulary grows, and its failure mode is
 * the bad one — an entry type nobody can see, which is the defect this fixes.
 */
export function humanEntriesPredicate(): string {
  return MACHINE_ENTRY_TYPES.map((type) => `entry_type <> '${type}'`).join(" AND ");
}

/** How the hidden rows are described, so the count never reads as an error. */
export function hiddenEntriesLabel(hidden: number): string {
  if (hidden <= 0) {
    return "";
  }
  const noun = hidden === 1 ? "credit reservation" : "credit reservations";
  return `${hidden.toLocaleString()} ${noun} hidden`;
}
