import { createHash, randomBytes, timingSafeEqual } from "crypto";
import { configQuery } from "@/lib/config-db";

/**
 * One-time sign-in links for the customer portal.
 *
 * <p>Server-only: importing this pulls `pg`.
 *
 * <h2>The token is never stored</h2>
 *
 * <p>Only its SHA-256 goes into `app_login_token`. A database that leaks is bad; a database that
 * leaks a working sign-in link for every account at once is a different order of bad, and hashing
 * costs nothing here because the token is high-entropy random rather than a password — there is
 * nothing to brute-force and so no reason to reach for a slow KDF.
 *
 * <h2>Redemption is one statement</h2>
 *
 * <p>`UPDATE … WHERE used_at IS NULL AND expires_at > now() RETURNING account_id`. Reading the row
 * and then marking it spent would let two clicks on the same link both pass the read — which is not
 * hypothetical, because mail clients and link scanners fetch URLs, sometimes twice, before a human
 * ever sees them.
 */

/** How long a link works for. Long enough to walk to a laptop, short enough to be worthless later. */
const TTL_MINUTES = 15;

/**
 * 32 bytes of `randomBytes`, base64url.
 *
 * <p>Not `Math.random`, and not a uuid: this is the entire credential for the duration, so it wants
 * a CSPRNG and enough width that guessing is not a strategy.
 */
function mintToken(): string {
  return randomBytes(32).toString("base64url");
}

function hash(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

/**
 * Issues a link for an account, without saying whether that account exists.
 *
 * <p>The caller passes an email; this resolves it and returns the token only when it matched. The
 * *caller* must answer identically either way — see the route. Returning null rather than throwing
 * is what makes the identical answer easy to write and hard to get wrong.
 *
 * @returns the raw token to put in the link, or null when no enabled account has that address
 */
export async function issueLoginToken(email: string, ip: string | null): Promise<
  { token: string; accountId: string } | null
> {
  const trimmed = email.trim();
  if (!trimmed) {
    return null;
  }

  //lower(email) is what `uq_app_account_email` indexes, so this matches the way uniqueness is
  //defined rather than a way that merely usually agrees with it
  const found = await configQuery<{ id: string }>(
    "SELECT id FROM app_account WHERE lower(email) = lower($1) AND enabled LIMIT 1",
    [trimmed]
  );
  if (!found.length) {
    return null;
  }

  const token = mintToken();
  await configQuery(
    `INSERT INTO app_login_token (token_hash, account_id, expires_at, requested_ip)
     VALUES ($1, $2, now() + ($3 || ' minutes')::interval, $4)`,
    [hash(token), found[0].id, String(TTL_MINUTES), ip]
  );
  return { token, accountId: found[0].id };
}

/**
 * Spends a token, once.
 *
 * <p>The `WHERE` clause carries every condition: unspent, unexpired, and the hash matching. A row
 * comes back only if all three held at the instant of the write, so there is no window between
 * deciding and spending.
 *
 * @returns the account the link was for, or null when the token is unknown, expired or already used
 */
export async function redeemLoginToken(token: string): Promise<string | null> {
  if (!token || typeof token !== "string") {
    return null;
  }
  const rows = await configQuery<{ account_id: string }>(
    `UPDATE app_login_token
        SET used_at = now()
      WHERE token_hash = $1 AND used_at IS NULL AND expires_at > now()
      RETURNING account_id`,
    [hash(token)]
  );
  return rows.length ? rows[0].account_id : null;
}

/**
 * How many links this address has been sent recently.
 *
 * <p>Counted against the *account*, not the email string, so asking under three spellings of the
 * same address does not buy three times the budget.
 */
export async function recentTokenCount(email: string, withinMinutes: number): Promise<number> {
  const rows = await configQuery<{ n: string }>(
    `SELECT count(*) AS n
       FROM app_login_token t
       JOIN app_account a ON a.id = t.account_id
      WHERE lower(a.email) = lower($1)
        AND t.created_at > now() - ($2 || ' minutes')::interval`,
    [email.trim(), String(withinMinutes)]
  );
  return Number(rows[0]?.n ?? 0);
}

/**
 * Constant-time compare, for anything that ends up comparing tokens outside the database.
 *
 * <p>Nothing uses it today — redemption compares hashes inside PostgreSQL. It exists so that the
 * next person to need one does not reach for `===`.
 */
export function tokensEqual(a: string, b: string): boolean {
  const left = Buffer.from(a, "utf8");
  const right = Buffer.from(b, "utf8");
  return left.length === right.length && timingSafeEqual(left, right);
}
