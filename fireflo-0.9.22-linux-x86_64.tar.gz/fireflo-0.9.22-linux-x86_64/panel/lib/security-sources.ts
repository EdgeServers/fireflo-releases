import { execFile } from "node:child_process";
import { open, readdir, stat } from "node:fs/promises";
import path from "node:path";
import { promisify } from "node:util";
import { accessLogDir } from "@/lib/data-dir";
import { parseLiveBans, type BlockedAddress } from "@/lib/security-events";

const run = promisify(execFile);

/**
 * The two files the Security page reads off the host, and how it reads them safely.
 *
 * <p>Server-only. The third source — the gateway's refusal log — is not here: it comes over
 * `/ops/logs/auth` like every other gateway log, because the panel is not guaranteed to share a
 * filesystem with the gateway and reaching for one would be the first place in this codebase that
 * did.
 *
 * <h2>Both reads are bounded, and that is the whole design</h2>
 *
 * <p>Neither file is rotated by the panel. The operator log keeps a file per UTC day for ever, and
 * the ban file grows for as long as fail2ban has been running. A page that read either whole would
 * work for a year and then take a server down, so both are read as a fixed tail from the end. The
 * cost of a huge file is a slow read of the last 512 KB, not a heap.
 */

/** Enough for a busy day of either file, small enough that reading it is never the slow part. */
const TAIL_BYTES = 512 * 1024;

/**
 * How many day-files back to look for failed sign-ins.
 *
 * <p>The page's longest window. Reading more would not show more, because the window selector
 * cannot ask for it.
 */
const OPERATOR_DAYS = 8;

/**
 * Where fail2ban's `fireflo-notify` action writes bans.
 *
 * <p>A fixed path rather than something derived from the tenant: fail2ban is host-wide, one
 * installation serves every tenant on the box, and its action has no idea which of them a ban
 * belongs to. Overridable for a host that puts it elsewhere.
 */
export function banStateFile(): string {
  return process.env.FIREFLO_BANS_FILE?.trim() || "/var/log/fireflo-bans/bans.jsonl";
}

export interface TailResult {
  lines: string[];
  /** False when the file is not there at all, which is a different answer from "no lines". */
  present: boolean;
  /** True when the file was longer than the window read, so the oldest entries are not here. */
  truncated: boolean;
}

/**
 * Reads the last {@link TAIL_BYTES} of a file as lines.
 *
 * <p>Total: a missing file, a directory, a permission error and an unreadable device all answer
 * `present: false` rather than throwing. This runs on a page an operator opens when something is
 * already wrong, and a 500 there would replace the answer with a different problem.
 *
 * <p>The first line is dropped when the window did not start at the beginning of the file, because
 * a tail almost always begins mid-line and half a JSON object parses as nothing — or, worse, as
 * something.
 */
export async function tailFile(file: string, bytes = TAIL_BYTES): Promise<TailResult> {
  let handle;
  try {
    const info = await stat(file);
    if (!info.isFile()) {
      return { lines: [], present: false, truncated: false };
    }
    const start = Math.max(0, info.size - bytes);
    const length = info.size - start;
    handle = await open(file, "r");
    const buffer = Buffer.alloc(length);
    await handle.read(buffer, 0, length, start);
    const text = buffer.toString("utf8");
    const lines = text.split("\n");
    if (start > 0 && lines.length > 0) {
      lines.shift();
    }
    return {
      lines: lines.filter((line) => line.trim().length > 0),
      present: true,
      truncated: start > 0,
    };
  } catch {
    return { lines: [], present: false, truncated: false };
  } finally {
    await handle?.close().catch(() => undefined);
  }
}

/**
 * The panel's own refused sign-ins, newest day last -- operator AND customer portal.
 *
 * <p>Reads whole day-files rather than filtering by name against a computed date range: the files
 * are named in UTC and the window the operator asked for is in their own zone, so picking files by
 * arithmetic would drop the edges. Taking the last few files and letting the caller filter by
 * timestamp is both simpler and correct at a boundary.
 */
export async function readPanelRefusalLines(): Promise<TailResult> {
  let dir: string;
  try {
    dir = accessLogDir();
  } catch {
    return { lines: [], present: false, truncated: false };
  }

  let names: string[];
  try {
    names = (await readdir(dir))
      .filter((name) => name.startsWith("auth-failed-") && name.endsWith(".jsonl"))
      .sort();
  } catch {
    //the directory does not exist until the first operator event is written, which on a fresh
    //install is a real state rather than a fault
    return { lines: [], present: false, truncated: false };
  }
  if (names.length === 0) {
    return { lines: [], present: true, truncated: false };
  }

  const recent = names.slice(-OPERATOR_DAYS);
  const lines: string[] = [];
  let truncated = names.length > recent.length;
  for (const name of recent) {
    const result = await tailFile(path.join(dir, name));
    lines.push(...result.lines);
    truncated = truncated || result.truncated;
  }
  return { lines, present: true, truncated };
}

/**
 * Whether the host has the unban wrapper the panel would call.
 *
 * <p>Checked so the page can leave the button out and say why, rather than rendering a control that
 * answers 500. Its absence is the ordinary state on a host installed without `--with-fail2ban`, not
 * a fault.
 */
export function fail2banWrapper(): string {
  return process.env.FIREFLO_FAIL2BAN_COMMAND?.trim() || "/usr/local/sbin/fireflo-fail2ban";
}

export async function fail2banAvailable(): Promise<boolean> {
  try {
    const info = await stat(fail2banWrapper());
    return info.isFile();
  } catch {
    return false;
  }
}

/** The jails FireFlo installs. The wrapper enforces this list too. */
export const FIREFLO_JAILS = ["fireflo-gateway", "fireflo-panel"] as const;

export interface LiveBans {
  blocked: BlockedAddress[];
  /** False when fail2ban could not be asked at all — no wrapper, no sudo rule, not running. */
  live: boolean;
  note: string | null;
}

/**
 * Asks fail2ban who is banned right now.
 *
 * <p>Preferred over the notify action's file, because this is fail2ban's own state and the file is
 * a derived record of it: the file misses a ban made before the action was installed, one made by
 * hand, and anything lost across a restart. The file is still read, for the history the live list
 * cannot give — a lifted ban is simply not in it any more.
 *
 * <p>Every failure answers `live: false` with a sentence rather than throwing. A jail that is not
 * running, a missing sudo rule and a host with no fail2ban are all ordinary states of a page whose
 * whole job is to say what is and is not protecting you.
 */
export async function liveBans(): Promise<LiveBans> {
  if (!(await fail2banAvailable())) {
    return {
      blocked: [],
      live: false,
      note: `fail2ban is not wired up for FireFlo on this host: ${fail2banWrapper()} is not there.`,
    };
  }

  const blocked: BlockedAddress[] = [];
  const unreadable: string[] = [];
  for (const jail of FIREFLO_JAILS) {
    try {
      //sudo -n so a missing NOPASSWD rule fails at once instead of blocking on a prompt nobody can
      //answer. execFile with an argument array: no shell stands between here and the wrapper
      const { stdout } = await run("sudo", ["-n", fail2banWrapper(), "list", jail], {
        timeout: 5_000,
      });
      blocked.push(...parseLiveBans(stdout, jail));
    } catch {
      //a jail that is not running is the ordinary case on a host that installed only one of them
      unreadable.push(jail);
    }
  }

  if (unreadable.length === FIREFLO_JAILS.length) {
    return {
      blocked: [],
      live: false,
      note:
        "fail2ban did not answer for any FireFlo jail. It may not be running, the jails may not be "
        + `enabled, or the sudo rule for ${fail2banWrapper()} may be missing.`,
    };
  }

  return {
    blocked,
    live: true,
    note:
      unreadable.length > 0
        ? `Not counting ${unreadable.join(" and ")}: fail2ban did not answer for it, so anything it `
          + "is blocking is not shown here."
        : null,
  };
}
