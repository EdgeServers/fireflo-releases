/** Amounts are stored scaled by this, as BIGINT, and never as floating point. */
export const MONEY_SCALE = 10_000;

/**
 * What every reader falls back to, and what the database actually holds.
 *
 * <p>`MSG_COST_PRECISION` is 10 000 and `account_balance.balance` is a BIGINT of ten-thousandths, so
 * four is both the default and the ceiling. A configured fifth place would print a digit that is
 * always zero.
 */
export const DEFAULT_MONEY_SCALE = 4;
export const MAX_MONEY_SCALE = 4;

/**
 * The gateway's `Money.displayScale`, in TypeScript, and it has to agree with it.
 *
 * <p>Both are lenient in the same direction and for the same reason: a bad value is a typo in one
 * row, and refusing to render money over it would be a worse outcome than rendering it at four
 * places. The place that refuses is the setting form, where somebody is watching.
 */
export function clampScale(raw: string | null | undefined): number {
  const trimmed = (raw ?? "").trim();
  //the empty string first, because Number("") is 0 and 0 is a legal scale -- an unset row would
  //otherwise round every amount to whole units
  if (!trimmed) {
    return DEFAULT_MONEY_SCALE;
  }
  const parsed = Number(trimmed);
  if (!Number.isInteger(parsed) || parsed < 0 || parsed > MAX_MONEY_SCALE) {
    return DEFAULT_MONEY_SCALE;
  }
  return parsed;
}

/**
 * How many decimal places a total is shown with, for the whole panel.
 *
 * <p><strong>Module state, set once per process, and that is a deliberate trade.</strong> `money()`
 * is called from about thirty places — table cells, column renderers, summary tiles — several of
 * which are plain functions rather than components and could not read a React context. Threading a
 * scale prop through nine client components to reach them would be a large diff whose only failure
 * mode is one call site quietly left on the old default, which is exactly the bug this is meant to
 * fix.
 *
 * <p>It is safe here for one specific reason: there is exactly one of these per platform, the same
 * argument `platform-currency.ts` makes about the currency. It is not per user, per account or per
 * request, so a value shared across concurrent server renders is the right value for all of them.
 *
 * <p>{@link PlatformScale} sets it **during render** rather than in an effect, so the server's first
 * paint and the client's hydration agree. Setting it in an effect would render every amount at four
 * places for one frame and then reflow the whole page.
 */
let displayScale = 4;

/** @see displayScale for why this is module state rather than a context. */
export function setMoneyScale(scale: number): void {
  displayScale = scale;
}

export function moneyScale(): number {
  return displayScale;
}

/**
 * Renders a scaled **total**.
 *
 * <p>The division happens here and only here — an aggregate that divided first would round money
 * away before it was summed.
 *
 * <p>Rounds to the declared scale, `HALF_UP`, matching the gateway's `Money.display` so the panel
 * and `/secure/balance` cannot show different numbers for the same amount. `toLocaleString` rounds
 * half away from zero for positives, which is the same thing; the explicit `Math.round` on the
 * scaled integer is what makes it true for negatives too, and a balance can be negative.
 *
 * <p><strong>Not for a per-message rate.</strong> `0.0450` at two places is `0.05`, an 11% error on
 * every message. Rate call sites render four places explicitly and say so — see `CdrsClient` and
 * `ProductPricingTable`.
 *
 * @param scale overrides the platform default. For the rare caller that knows better; almost
 *     nothing should pass it
 */
export function money(scaled: number, currency = "", scale = displayScale): string {
  const factor = 10 ** scale;
  //round on the integer before dividing, so the value handed to toLocaleString is already exact at
  //the target scale and the locale formatter has nothing left to decide
  const rounded = Math.sign(scaled) * Math.round(Math.abs(scaled) * factor / MONEY_SCALE) / factor;
  const rendered = rounded.toLocaleString(undefined, {
    minimumFractionDigits: scale,
    maximumFractionDigits: scale,
  });
  return currency ? `${rendered} ${currency}` : rendered;
}

export function count(value: number): string {
  return value.toLocaleString();
}

/**
 * @param rate a fraction, or null when nothing has settled yet — which is not the same as a rate
 *     of zero and is rendered as a dash rather than 0%
 */
export function percent(rate: number | null): string {
  return rate === null ? "—" : `${(rate * 100).toFixed(1)}%`;
}

/**
 * An elapsed time, at one or two units of precision.
 *
 * <p>For how long a session has been bound, where the useful reading is the order of magnitude: a
 * session that says `12s` every time you look is flapping, and one that says `6d` is not. Exact
 * seconds on a four-day-old connection would be noise.
 */
export function duration(seconds: number): string {
  if (seconds < 60) {
    return `${Math.floor(seconds)}s`;
  }
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) {
    return `${minutes}m`;
  }
  const hours = Math.floor(minutes / 60);
  if (hours < 24) {
    const remainder = minutes % 60;
    return remainder ? `${hours}h ${remainder}m` : `${hours}h`;
  }
  const days = Math.floor(hours / 24);
  const remainder = hours % 24;
  return remainder ? `${days}d ${remainder}h` : `${days}d`;
}

/**
 * A byte count at three significant figures.
 *
 * <p>Binary units, labelled as binary units. Every number this renders comes from the JVM, which
 * reports heap and buffer sizes in powers of two — so a 4 GiB heap set with `-Xmx4g` shows as
 * "4.0 GiB". Dividing by 1024 and then writing "GB" would print 4.0 for a value that is not four
 * billion bytes, and someone checking the setting took would be reading a number that is off by 7%.
 */
export function bytes(value: number): string {
  if (!Number.isFinite(value)) {
    return "—";
  }
  const units = ["B", "KiB", "MiB", "GiB", "TiB"];
  let n = Math.abs(value);
  let unit = 0;
  while (n >= 1024 && unit < units.length - 1) {
    n /= 1024;
    unit++;
  }
  const rendered = unit === 0 ? String(Math.round(n)) : n.toFixed(n >= 100 ? 0 : 1);
  return `${value < 0 ? "-" : ""}${rendered} ${units[unit]}`;
}

/**
 * A duration given in seconds, at whatever scale makes it readable.
 *
 * <p>Separate from {@link duration} rather than an extension of it: that one floors to whole seconds
 * on purpose, so a garbage-collection pause or a request latency would render as `0s`. These values
 * are almost always sub-second and the interesting digits are the small ones.
 */
export function latency(seconds: number | null): string {
  if (seconds == null || !Number.isFinite(seconds)) {
    return "—";
  }
  if (seconds === 0) {
    return "0";
  }
  if (seconds < 0.001) {
    return `${(seconds * 1_000_000).toFixed(0)} µs`;
  }
  if (seconds < 1) {
    return `${(seconds * 1000).toFixed(1)} ms`;
  }
  return `${seconds.toFixed(2)} s`;
}

/**
 * How long after something else, at whatever scale reads best.
 *
 * <p>{@link latency} below a minute and {@link duration} above it, because a receipt timeline spans
 * both: a carrier's ACCEPTD lands in tens of milliseconds and its EXPIRED lands two days later, and
 * neither `172800.00 s` nor `0s` is a useful way to say so.
 *
 * <p><strong>Negative is rendered, not hidden.</strong> A receipt stamped before the submit it
 * belongs to means two machines disagree about the time, and that is worth seeing on the page rather
 * than being quietly floored to zero — clock skew between the gateway and a carrier is a real cause
 * of "the receipt arrived before we sent it" support tickets.
 */
export function elapsed(seconds: number | null): string {
  if (seconds == null || !Number.isFinite(seconds)) {
    return "—";
  }
  const magnitude = Math.abs(seconds);
  const rendered = magnitude < 60 ? latency(magnitude) : duration(magnitude);
  return seconds < 0 ? `−${rendered}` : rendered;
}

/**
 * @param rate a fraction, rendered without the decimal point when it is not informative
 */
export function ratio(rate: number | null): string {
  if (rate == null || !Number.isFinite(rate)) {
    return "—";
  }
  const asPercent = rate * 100;
  return `${asPercent >= 10 ? asPercent.toFixed(0) : asPercent.toFixed(1)}%`;
}

/**
 * BIGINT x10^4, formatted without ever becoming a float.
 *
 * <p>String arithmetic rather than {@link money}, because the balance arrives from the portal's
 * summary route as a string: it is a BIGINT, and 19 digits do not survive a round trip through a
 * JavaScript number. So this cannot divide, and it rounds by carrying instead.
 *
 * <p>It used to slice the last four digits off and stop, which is truncation -- at two places
 * `12462.2795` came out as `12462.27` while the operator panel and `/secure/balance` both said
 * `12462.28`. Three renderings of one amount, disagreeing by a cent.
 *
 * @param scale places to show, `HALF_UP`, matching the gateway's `Money.display`
 */
export function moneyFromBigintString(raw: string, scale: number): string {
  const negative = raw.startsWith("-");
  let digits = (negative ? raw.slice(1) : raw).padStart(5, "0");

  //round off the places that are not being shown, by looking at the first digit dropped. Done on
  //the digit string so a 19-digit balance is still exact
  const drop = 4 - scale;
  if (drop > 0) {
    const kept = digits.slice(0, digits.length - drop);
    const roundUp = digits.charAt(digits.length - drop) >= "5";
    //BigInt(1) rather than a 1n literal: the build targets below ES2020 and rejects the literal.
    //BigInt itself is fine, and is what keeps a 19-digit balance exact through the carry
    digits = roundUp ? (BigInt(kept) + BigInt(1)).toString() : kept;
    digits = digits.padStart(scale + 1, "0");
  }

  const whole = digits.slice(0, digits.length - scale).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  const fraction = scale > 0 ? `.${digits.slice(digits.length - scale)}` : "";
  return `${negative ? "-" : ""}${whole}${fraction}`;
}
