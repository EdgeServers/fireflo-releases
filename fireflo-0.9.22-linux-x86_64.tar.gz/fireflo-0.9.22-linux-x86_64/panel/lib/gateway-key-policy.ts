import type { SettingKey } from "./labels";
//with the extension, because `node --test` runs this module directly and does not resolve
//extensionless specifiers. Both catalogues import types only, so neither drags in a database
import { GATEWAY_SETTING_FIELDS } from "./gateway-setting-fields.ts";
import { SETTING_FIELDS } from "./setting-fields.ts";

/**
 * Which gateway configuration keys this panel will show, and which it will write.
 *
 * <h2>Why this exists at all</h2>
 *
 * <p>`gateway-setting-fields.ts` is an allow-list of ten keys, and while the page could only edit
 * those ten, membership of that list *was* the security boundary. The free-form editor removes that
 * coupling: an operator can now type any key. So the boundary has to become a thing of its own,
 * stated once and enforced in both directions.
 *
 * <h2>Both directions, and that is the part that was missing</h2>
 *
 * <p>The reading half is not new caution, it is a live defect. `readGatewaySettings` selects
 * `key LIKE 'smsg.%'`, and `OpsTokenGuard` reads `smsg.ops.token` and `smsg.ops.admin.token`
 * through the same configuration handler — so in database mode those are ordinary rows under that
 * prefix and **the GET handler has been returning both tokens to the browser**. Not rendered, because
 * the page filtered to the catalogue, but present in the response body, in React state, and in
 * anything that logs a response. Every worker form fetches the same endpoint.
 *
 * <p>The gateway saw this coming. `ConfigRedactor`, which does the same job for the gateway's own
 * `/ops/config`, says of the panel: *"the panel's own SECRET_KEYS holds two entries and would sail
 * straight past smsg.ops.token."* It was right.
 *
 * <h2>A list plus a shape, not either alone</h2>
 *
 * <p>The named list below is the one `gateway-setting-fields.ts` already documents in prose, lifted
 * into code so it can be enforced rather than merely observed. On top of it sits a shape rule taking
 * `SensitiveLogSanitizer.isSensitiveKey`'s argument directly: *"An enumerated list is a list somebody
 * forgets to extend."* A key nobody listed is denied the day it is added rather than the day somebody
 * notices.
 *
 * <p>The shape rule is deliberately **not** matched against `url` or `uri` in general —
 * `smsg.dlr.forward.url` is an ordinary setting an operator has a reason to change. The one URI that
 * carries a password is named explicitly instead.
 *
 * <p>Erring wide costs little: a key wrongly judged secret is one an operator edits on the host, and
 * a key wrongly judged writable is a credential in a screenshot.
 */

export type DenialReason =
  /** Holds a credential. Denied in both directions — never shown, never written. */
  | "secret"
  /** Decides where configuration is read from. Editing it from here locks the room from inside. */
  | "config-source"
  /** Broker, sink and egress guards. Readable, because seeing it is diagnostic; not writable. */
  | "wiring"
  /** The panel edits this on a screen of its own. Two editors is how they come to disagree. */
  | "elsewhere"
  /** Licensing. Not the panel's to touch, in either direction. See {@link LICENSING_PREFIX}. */
  | "licensing"
  /** Not a gateway configuration key at all. */
  | "prefix";

export type KeyVerdict =
  | { allowed: true; curated: boolean }
  | { allowed: false; reason: DenialReason };

/** The two namespaces the gateway resolves configuration from. Anything else is not ours to write. */
export const WRITABLE_PREFIXES = ["smsg.", "outSms.default."] as const;

/**
 * Keys that are settable despite carrying neither prefix.
 *
 * <p><strong>These were never denied on purpose.</strong> The prefix rule exists to keep the panel
 * out of namespaces it has no business writing — `postgres.`, `quarkus.` and everything else the
 * gateway reads. `message.trace.mode` is an ordinary global diagnostic toggle that simply predates
 * the `smsg.` convention, and it was caught by the rule incidentally.
 *
 * <p>The cost of that accident was concrete: diagnosing a customer's missing delivery receipts
 * needed this key, the panel refused it, and the operator was sent to psql on a live gateway to set
 * a logging level. The denials that ARE deliberate — secrets, config source, wiring, licensing —
 * are all checked above this and are unaffected.
 *
 * <p>A set rather than a prefix, deliberately: this is a list of specific historical names, not a
 * new namespace, and it should not become somewhere to put things.
 */
export const LEGACY_WRITABLE: ReadonlySet<string> = new Set(["message.trace.mode"]);

/**
 * The licensing namespace, denied as a whole rather than key by key.
 *
 * <p><strong>A prefix, because the impact of the two keys in it today is not the argument.</strong>
 * `smsg.license.server.url` decides which server this gateway asks for a licence, and
 * `smsg.license.directory` decides where it keeps the one it has — both read through the ordinary
 * configuration handler, so both were accepted by the free-form editor: they start with `smsg.`
 * and neither looks like a credential.
 *
 * <p>Neither is a bypass on its own. The Ed25519 public key is compiled into the gateway artefact,
 * so a substitute licence server returns something `LicenseVerifier` refuses to store; and an empty
 * licence directory recovers from `app_license` rather than minting a fresh identity. The reason
 * this is shut anyway is what the keys are: **this panel's source ships to customers**, so an
 * editor here is an editor the licensee owns, and licensing settings are the one category where
 * "they could do it another way anyway" is not a reason to leave a door standing open.
 *
 * <p>A prefix rather than two entries, for the reason the shape rule above already gives about
 * enumerated lists. A later `smsg.license.key` — a bearer credential — would be denied the day it
 * is added rather than the day somebody notices it is neither listed here nor caught by the
 * substring rule.
 *
 * <p>Denied for **writing only**. Which licence server a gateway points at is diagnostic, and an
 * operator staring at an install that will not activate should be able to see it.
 */
export const LICENSING_PREFIX = "smsg.license.";

/**
 * Keys denied by name, with the reason each is denied.
 *
 * <p>Every entry here is one `gateway-setting-fields.ts` already argued for in its header. The key
 * literals were read from the gateway source rather than from documentation.
 */
const DENIED: Record<string, DenialReason> = {
  //the two secrets guarding the endpoint the panel authenticates to
  "smsg.ops.token": "secret",
  "smsg.ops.admin.token": "secret",
  //carries a password in its userinfo -- see the conf.example line, which is literally
  //amqp://fireflo:secret@host
  "smsg.queue.amqp.uri": "secret",

  "smsg.config.source": "config-source",
  "smsg.properties.file.path": "config-source",
  "smsg.credentials.file.path": "config-source",
  "smsg.rates.file.path": "config-source",
  "smsg.routing.file.path": "config-source",

  "smsg.queue.provider": "wiring",
  "smsg.cdr.sink": "wiring",
  //loosening an SSRF guard from a web form is not an operator convenience
  "smsg.webhook.private.targets": "wiring",
  "smsg.webhook.schemes": "wiring",

  "smsg.rates.currency": "elsewhere",
  "smsg.money.scale": "elsewhere",
  "smsg.billing.zone": "elsewhere",
};

/**
 * The substrings that make a key a secret whatever else is true of it.
 *
 * <p>A deliberate mirror of the gateway's `SensitiveLogSanitizer.isSensitiveKey`, which the panel
 * cannot call because it is Java. Kept in the same order and with the same entries so a reader can
 * diff the two by eye. `pwd` and `passwd` are here for the same reason they are there: neither
 * contains `password` as a substring.
 */
const SENSITIVE_SUBSTRINGS = [
  "password",
  "passwd",
  "pwd",
  "secret",
  "token",
  "credential",
  "keystore",
  "truststore",
  "apikey",
  "api_key",
  "api-key",
  "api.key",
  "privatekey",
  "private_key",
  "private-key",
  "private.key",
] as const;

/** Whether the key's shape says it holds a credential, regardless of any list. */
export function looksSensitive(key: string): boolean {
  const lower = key.toLowerCase();
  return SENSITIVE_SUBSTRINGS.some((needle) => lower.includes(needle));
}

/**
 * The `outSms.default.<key>` form of a worker setting key.
 *
 * <p>Lives here rather than beside the database writer it used to sit next to, so that the module
 * which decides what `outSms.default.` means is also the one that spells it. It is pure, and this
 * module has to stay importable by `node --test`, which a module that opens a connection pool is not.
 */
export function workerDefaultKey(settingKey: string): string {
  return `${WRITABLE_PREFIXES[1]}${settingKey}`;
}

/** Every `outSms.default.<key>` the worker form already knows how to render. Built once. */
const CURATED_WORKER_DEFAULTS: ReadonlySet<string> = new Set(
  (Object.keys(SETTING_FIELDS) as SettingKey[]).map(workerDefaultKey)
);

const CURATED_GLOBAL: ReadonlySet<string> = new Set(GATEWAY_SETTING_FIELDS.map((f) => f.key));

/**
 * The one judgement, which every caller reads rather than re-deriving.
 *
 * <p>`curated` is not part of the boundary — it says whether a field exists for this key, so the
 * page can put it in a card with a label and a widget instead of in the free-form list. An
 * uncurated key is still perfectly writable; it just has no editor of its own.
 */
export function judgeGatewayKey(key: string): KeyVerdict {
  const trimmed = key.trim();

  //the shape rule runs first and outranks everything, including the prefix check: a key that looks
  //like a credential should read as a credential in the refusal, not as a typo
  if (looksSensitive(trimmed)) {
    return { allowed: false, reason: "secret" };
  }

  const named = DENIED[trimmed];
  if (named) {
    return { allowed: false, reason: named };
  }

  //the whole namespace, ahead of the prefix check below rather than after it: these keys DO start
  //with `smsg.`, so reaching the general rule would let every one of them through
  if (trimmed.startsWith(LICENSING_PREFIX)) {
    return { allowed: false, reason: "licensing" };
  }

  if (!WRITABLE_PREFIXES.some((prefix) => trimmed.startsWith(prefix))
      && !LEGACY_WRITABLE.has(trimmed)) {
    return { allowed: false, reason: "prefix" };
  }

  //a bare prefix with nothing after it is not a key
  if (WRITABLE_PREFIXES.some((prefix) => trimmed === prefix)) {
    return { allowed: false, reason: "prefix" };
  }

  return {
    allowed: true,
    curated: CURATED_GLOBAL.has(trimmed) || CURATED_WORKER_DEFAULTS.has(trimmed),
  };
}

/**
 * Whether the panel may put this key on screen.
 *
 * <p>Only a secret is withheld. A `wiring` key is shown and not editable, because knowing that
 * `smsg.cdr.sink` is set to something unexpected is exactly the kind of thing an operator opens this
 * page to find out, and its value is not a credential.
 */
export function isReadable(key: string): boolean {
  const verdict = judgeGatewayKey(key);
  return verdict.allowed || (verdict.reason !== "secret" && verdict.reason !== "prefix");
}

/** Whether the panel may write this key. */
export function isWritable(key: string): boolean {
  return judgeGatewayKey(key).allowed;
}

/**
 * Why a key was refused, in a sentence an operator can act on.
 *
 * <p>Says what to do instead rather than only that it refused: the alternative is somebody retrying
 * a key that can never work here, or worse, concluding the panel is broken.
 */
export function denialMessage(key: string, reason: DenialReason): string {
  const named = key.trim() || "(empty)";
  switch (reason) {
    case "secret":
      return `${named} holds a credential and cannot be set from the panel. Edit it on the host.`;
    case "config-source":
      return `${named} decides where the gateway reads its configuration. Changing it from a panel `
        + `that reads the same configuration is how an install locks itself out. Edit it on the host.`;
    case "wiring":
      return `${named} changes where messages and records go while traffic is running. It is shown `
        + `here so you can see it, and edited on the host so it is a deliberate act.`;
    case "elsewhere":
      return `${named} is set on its own screen in this panel. Two editors for one value is how they `
        + `come to disagree.`;
    case "licensing":
      return `${named} is part of this gateway's licensing and is not set from the panel. It is `
        + `shown here so you can see it. Change it on the host, or use 'fireflo license'.`;
    case "prefix":
      return `${named} is not a gateway configuration key. Gateway-wide keys start with 'smsg.', and `
        + `a worker default starts with 'outSms.default.'.`;
  }
}
