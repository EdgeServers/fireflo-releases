import { test } from "node:test";
import assert from "node:assert/strict";
import { CUSTOMER_ROLE, OPERATOR_ROLE, isOperatorSession } from "./roles.ts";

/**
 * The one test in this codebase whose failure is a data breach rather than a bug.
 *
 * <p>`isOperatorSession` is what `requireOperator` asks before opening any control route: margin,
 * the names of the vendors traffic is bought from, every account's messages, credential editing.
 * These cases are written against the session shapes an attacker actually holds -- a real customer
 * session, the old shape with no role, and a role that is merely truthy.
 *
 * <p>No test framework and no mocking: `roles.ts` imports nothing, which is why it can be checked
 * this cheaply.
 *
 * <pre>npm run test:auth</pre>
 */

test("an operator is admitted", () => {
  assert.equal(isOperatorSession({ user: { name: "operator", role: OPERATOR_ROLE } }), true);
});

test("a customer session is refused, though it is valid and signed", () => {
  assert.equal(
    isOperatorSession({ user: { name: "acct-1001", role: CUSTOMER_ROLE } }),
    false,
    "a customer reaching a control route is the failure this gate exists to prevent"
  );
});

test("a name with no role is refused", () => {
  assert.equal(
    isOperatorSession({ user: { name: "operator" } }),
    false,
    "this is the old shape exactly: presence must no longer be enough"
  );
});

test("a role that is merely truthy is refused", () => {
  assert.equal(
    isOperatorSession({ user: { name: "operator", role: "admin" } }),
    false,
    "it must be an equality against OPERATOR_ROLE, not a truthiness test"
  );
});

test("the right role without a name is refused", () => {
  assert.equal(isOperatorSession({ user: { role: OPERATOR_ROLE } }), false);
});

test("no session, no user, and a null user are all refused", () => {
  assert.equal(isOperatorSession(null), false);
  assert.equal(isOperatorSession(undefined), false);
  assert.equal(isOperatorSession({}), false);
  assert.equal(isOperatorSession({ user: null }), false);
});
