import { callOps } from "@/lib/gateway-ops";
import type { Health, HealthWorker } from "@/lib/health-types";
import { KIND } from "@/lib/worker-types";

/**
 * Ending the connections a login is already holding.
 *
 * <p>Server-only. Exists because `enabled = false` on a credential is a statement about future
 * binds and nothing else: a customer already bound keeps submitting on that session until it drops
 * of its own accord. An operator switching a login off in a hurry means both, and until now got only
 * one of them, silently.
 *
 * <p><strong>Best effort by design.</strong> The stored change is the durable intent and has already
 * happened by the time this runs; the gateway would apply it on its next configuration poll anyway.
 * So an unreachable gateway is worth reporting and never worth failing the write for.
 */

/** What happened to the live sessions, in words a caller can show without interpreting. */
export interface BindTeardown {
  dropped: number;
  /** Present when the sessions could not be reached — the stored change still stands. */
  problem?: string;
}

/**
 * Drops every bind currently held by one SMPP login, across every listener.
 *
 * <p>Across listeners rather than one, because nothing stops the same login binding to two: session
 * ids are per listener, so each has to be named with the worker that issued it.
 */
export async function disconnectBindsFor(systemId: string): Promise<BindTeardown> {
  if (!systemId) {
    return { dropped: 0 };
  }

  let health: Health | null;
  try {
    const res = await callOps({ path: "/ops/health", timeoutMs: 5_000 });
    const json = (await res.json().catch(() => null)) as { data?: Health; error?: string } | null;
    if (!res.ok) {
      return { dropped: 0, problem: json?.error ?? "the gateway did not answer" };
    }
    health = json?.data ?? null;
  } catch (err) {
    return { dropped: 0, problem: err instanceof Error ? err.message : "the gateway is unreachable" };
  }

  //health carries only a SAMPLE of each worker's sessions, so it can no longer be walked to find
  //a login's binds -- a customer holding more binds than the sample would have kept the ones past
  //it, silently, which is the failure this whole flow exists to prevent. The names come from
  //health; the sessions come from the endpoint that can page.
  const targets: { worker: string; sessionId: number }[] = [];
  let problem: string | undefined;
  for (const worker of health?.workers ?? []) {
    if (!isListener(worker)) {
      continue;
    }
    const found = await sessionsFor(worker.name, systemId);
    if (found.problem) {
      problem ??= found.problem;
      continue;
    }
    targets.push(...found.targets);
  }
  if (!targets.length) {
    return problem ? { dropped: 0, problem } : { dropped: 0 };
  }

  //sequential rather than concurrent: each one waits on an unbind handshake, and a customer with
  //several binds is not a reason to open several admin calls at once against the management port
  let dropped = 0;
  for (const target of targets) {
    try {
      const res = await callOps({
        path: `/ops/workers/${encodeURIComponent(target.worker)}/sessions/${target.sessionId}/disconnect`,
        method: "POST",
        auth: "admin",
        timeoutMs: 15_000,
      });
      if (res.ok) {
        dropped += 1;
      } else if (res.status !== 404) {
        //404 is the session having ended between reading the list and acting, which is the ordinary
        //case and not something to report as a problem
        const json = (await res.json().catch(() => null)) as { error?: string } | null;
        problem ??= json?.error ?? `the gateway refused (${res.status})`;
      }
    } catch (err) {
      problem ??= err instanceof Error ? err.message : "the gateway is unreachable";
    }
  }
  return problem ? { dropped, problem } : { dropped };
}

function isListener(worker: HealthWorker): boolean {
  return worker.type === KIND.server;
}

/** What the gateway's paged session endpoint returns. */
interface SessionPage {
  rows: { session_id?: number | null; system_id?: string | null }[];
  matched: number;
  limit: number;
}

/**
 * Every session one login holds on one listener.
 *
 * <p>Pages until the matched set is exhausted, because the whole reason this exists is a login with
 * more binds than fit in one response.
 *
 * <p><strong>The search finds candidates; the equality check decides.</strong> `q=` is a substring
 * match, so searching for `ACME` also returns `ACMEINTL` — acting on the search result directly
 * would drop a different customer's sessions, from a form that named the first one. The filter below
 * is not belt and braces; it is the correctness step.
 */
async function sessionsFor(
  worker: string,
  systemId: string
): Promise<{ targets: { worker: string; sessionId: number }[]; problem?: string }> {
  const targets: { worker: string; sessionId: number }[] = [];
  let offset = 0;

  //bounded rather than `while (true)`: a gateway answering inconsistently mid-page must not spin
  //this loop against the management port
  for (let request = 0; request < 50; request++) {
    let page: SessionPage | null;
    try {
      const res = await callOps({
        path:
          `/ops/workers/${encodeURIComponent(worker)}/sessions` +
          `?q=${encodeURIComponent(systemId)}&offset=${offset}&limit=200`,
        timeoutMs: 5_000,
      });
      const json = (await res.json().catch(() => null)) as
        | { data?: SessionPage; error?: string }
        | null;
      if (!res.ok) {
        return { targets, problem: json?.error ?? "the gateway did not list its sessions" };
      }
      page = json?.data ?? null;
    } catch (err) {
      return {
        targets,
        problem: err instanceof Error ? err.message : "the gateway is unreachable",
      };
    }

    const rows = page?.rows ?? [];
    for (const row of rows) {
      if (row.system_id === systemId && row.session_id != null) {
        targets.push({ worker, sessionId: row.session_id });
      }
    }

    offset += rows.length;
    if (!rows.length || offset >= (page?.matched ?? 0)) {
      break;
    }
  }
  return { targets };
}
