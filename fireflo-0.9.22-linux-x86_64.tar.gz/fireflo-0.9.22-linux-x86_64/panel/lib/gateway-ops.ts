import { NextResponse } from "next/server";

/**
 * Calling the gateway's operational endpoints.
 *
 * <p>Server-only: the tokens are read from the process environment and must never reach a browser.
 * Every `/api/control` route that talks to `/ops` goes through here, so the base URL, the token
 * choice and the wording of a refusal exist once.
 *
 * <p><strong>These are not on the gateway's message port.</strong> They live on its management
 * interface — 9000 by default, beside `/q/metrics` — which is why `GATEWAY_OPS_URL` is separate from
 * `GATEWAY_BASE_URL`. Pointing this at the messaging port gets 404s that look exactly like a wrong
 * token.
 */
const READ_TOKEN_HELP =
  "GATEWAY_OPS_URL and GATEWAY_OPS_TOKEN must both be set to reach the gateway's operational port.";

const ADMIN_TOKEN_HELP =
  "GATEWAY_OPS_URL and GATEWAY_OPS_ADMIN_TOKEN must both be set to control the gateway. The admin "
  + "token is deliberately separate from the read-only one, and must match smsg.ops.admin.token.";

/**
 * `admin` for anything that changes what the gateway is doing, `read` for everything else.
 *
 * <p>The gateway refuses an action presented with the read token, so using the wrong one here is a
 * 404 rather than a subtle failure.
 */
export type OpsAuth = "read" | "admin";

export interface OpsCall {
  path: string;
  method?: "GET" | "POST" | "DELETE";
  auth?: OpsAuth;
  timeoutMs?: number;
  /**
   * A JSON body, for the few POSTs that carry one.
   *
   * Most `/ops` actions take their arguments in the path or the query string, so this stayed
   * absent until licensing needed it: a licence key and a signed licence are both far too long
   * for a query string, and a key in one would land in the gateway's own access log.
   */
  body?: unknown;
  /**
   * Forward the gateway's own status and sentence instead of flattening it to a 502.
   *
   * Off by default, and that default is right for nearly everything here: a 4xx from `/ops` is
   * normally a fault in the request this panel built, and an operator is better served by "could
   * not reach the gateway" than by a protocol complaint they cannot act on.
   *
   * Licensing is the exception, which is why this exists. A 402 there is a **product outcome**
   * addressed to the operator -- "that licence key is not one we issued", "this licence belongs to
   * a different installation" -- and it names which of six things went wrong. Flattening it would
   * throw away the only part of the answer that tells them what to do next.
   */
  passErrors?: boolean;
}

/**
 * Proxies one call and turns anything unhappy into a NextResponse the pages can render.
 *
 * @returns the gateway's `data` on success, or an error response ready to return
 */
export async function callOps({
  path,
  method = "GET",
  auth = "read",
  timeoutMs = 10_000,
  body,
  passErrors = false,
}: OpsCall): Promise<NextResponse> {
  const target = resolve(auth);
  if ("failed" in target) {
    return target.failed;
  }
  const { base, token } = target;

  try {
    const res = await fetch(`${base}${path}`, {
      method,
      headers: body === undefined
        ? { Authorization: `Bearer ${token}` }
        : { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: AbortSignal.timeout(timeoutMs),
      cache: "no-store",
    });
    const json = await res.json().catch(() => null);
    if (!res.ok) {
      //the gateway's envelope puts its sentence in `message` (ApiEnvelope), not `error`. The
      //original check read only `error`, so this branch never fired and every licence 402 was
      //flattened to a 502 -- the exact outcome the passErrors flag exists to prevent. Both keys
      //are accepted now, `error` first in case something upstream ever adopts it
      const sentence = typeof json?.error === "string" && json.error
        ? json.error
        : typeof json?.message === "string" && json.message
          ? json.message
          : "";
      if (passErrors && sentence) {
        //the gateway's sentence, at the gateway's status. See passErrors
        return NextResponse.json({ error: sentence }, { status: res.status });
      }
      return NextResponse.json({ error: describe(res.status, json, auth) }, { status: 502 });
    }
    return NextResponse.json({ data: json?.data ?? null });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? `Could not reach the gateway: ${err.message}` : "Unreachable" },
      { status: 502 }
    );
  }
}

/**
 * Fetches an endpoint whose body is NOT JSON.
 *
 * <p>Needed because {@link callOps} calls `res.json()` behind a `.catch(() => null)` and then
 * returns `{ data: json?.data ?? null }`. Handed `text/plain` it therefore answers **HTTP 200 with
 * `data: null`** — no error, no bad status, just an empty payload that reads as "the gateway has
 * nothing to say". `/q/metrics` is exactly that shape, so it needs its own path rather than a flag.
 *
 * @returns the body, or the error response to return as-is
 */
export async function callOpsText({
  path,
  timeoutMs = 10_000,
}: {
  path: string;
  timeoutMs?: number;
}): Promise<{ text: string } | { failed: NextResponse }> {
  const target = resolve("read");
  if ("failed" in target) {
    return target;
  }
  const { base, token } = target;

  try {
    const res = await fetch(`${base}${path}`, {
      headers: { Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(timeoutMs),
      cache: "no-store",
    });
    if (!res.ok) {
      return {
        failed: NextResponse.json({ error: describe(res.status, null, "read") }, { status: 502 }),
      };
    }
    return { text: await res.text() };
  } catch (err) {
    return {
      failed: NextResponse.json(
        {
          error:
            err instanceof Error ? `Could not reach the gateway: ${err.message}` : "Unreachable",
        },
        { status: 502 }
      ),
    };
  }
}

/**
 * Streams a file back from the gateway, under a filename this process chooses.
 *
 * <p>The third variant, because neither of the other two fits: {@link callOps} parses JSON and would
 * answer `data: null` for a `.pcap`, and {@link callOpsText} is hardcoded to the read token, which
 * the gateway refuses for a capture. Downloads also need headers the JSON helper never sets.
 *
 * <p><strong>The filename is built here, never taken from the request.</strong> It lands in a
 * `Content-Disposition` header and then in a save dialog, so accepting one from the browser would
 * let a caller choose what a colleague's machine writes to disk.
 *
 * <p>`no-store` because a capture is customer message content: it must not sit in a shared cache or
 * come back from the browser's history after the gateway has expired it.
 */
export async function callOpsDownload({
  path,
  filename,
  contentType,
  auth = "admin",
  timeoutMs = 30_000,
}: {
  path: string;
  filename: string;
  contentType: string;
  auth?: OpsAuth;
  timeoutMs?: number;
}): Promise<NextResponse> {
  const target = resolve(auth);
  if ("failed" in target) {
    return target.failed;
  }
  const { base, token } = target;

  try {
    const res = await fetch(`${base}${path}`, {
      headers: { Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(timeoutMs),
      cache: "no-store",
    });
    if (!res.ok) {
      return NextResponse.json({ error: describe(res.status, null, auth) }, { status: 502 });
    }
    const safe = filename.replace(/[^A-Za-z0-9._-]/g, "-");
    return new NextResponse(await res.arrayBuffer(), {
      status: 200,
      headers: {
        "Content-Type": contentType,
        "Content-Disposition": `attachment; filename="${safe}"`,
        "Cache-Control": "private, no-store",
      },
    });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? `Could not reach the gateway: ${err.message}` : "Unreachable" },
      { status: 502 }
    );
  }
}

/**
 * The base URL and the right token, or the 503 explaining which is missing.
 */
function resolve(auth: OpsAuth): { base: string; token: string } | { failed: NextResponse } {
  const base = process.env.GATEWAY_OPS_URL?.trim().replace(/\/$/, "");
  const token =
    auth === "admin"
      ? process.env.GATEWAY_OPS_ADMIN_TOKEN?.trim()
      : process.env.GATEWAY_OPS_TOKEN?.trim();

  if (!base || !token) {
    return {
      failed: NextResponse.json(
        { error: auth === "admin" ? ADMIN_TOKEN_HELP : READ_TOKEN_HELP },
        { status: 503 }
      ),
    };
  }
  return { base, token };
}

/**
 * <p>A 404 from the gateway is ambiguous on purpose — it means the token is wrong, the endpoint is
 * switched off, or there is genuinely no such worker — so this says all of it rather than guessing
 * one. The gateway's own message is included when it carried one, because for "no such worker" it
 * is the useful half.
 */
function describe(status: number, json: { message?: string } | null, auth: OpsAuth): string {
  if (status !== 404) {
    return json?.message ?? `Gateway returned ${status}`;
  }
  const setting = auth === "admin" ? "smsg.ops.admin.token" : "smsg.ops.token";
  const variable = auth === "admin" ? "GATEWAY_OPS_ADMIN_TOKEN" : "GATEWAY_OPS_TOKEN";
  const detail = json?.message && json.message !== "Not found" ? ` ${json.message}` : "";
  return (
    `The gateway refused.${detail} Either ${setting} is unset there or does not match ${variable}, `
    + "or there is no such worker."
  );
}
