import { configQuery, inTransaction } from "@/lib/config-db";
import type { ConditionInput } from "@/lib/rate-types";
import type { RouteRule, RouteTable, RouteTableInput, TargetFunction } from "@/lib/routing-types";

/**
 * Routing tables and their ordered rules.
 *
 * <p>Server-only: importing this pulls `pg`. The shapes and every statement about behaviour live in
 * `routing-types.ts`.
 *
 * <p>These tables have been readable by `DbRoutingLoader` since V1.4.0 and populated by
 * `fireflo import routing`, but nothing could edit them — which is why the gateway in this
 * deployment still reads `conf/routingTable.conf`. Editing them is what makes flipping
 * `FIREFLO_CONFIG_SOURCE=db` a reasonable thing to do rather than a one-way door.
 */

interface TableRow {
  name: string;
  target_function: string;
  label: string | null;
  enabled: boolean;
}

interface RuleRow {
  id: string;
  table_name: string;
  target: string;
  copied: boolean;
  label: string | null;
  enabled: boolean;
}

/**
 * Every table with its rules in order.
 *
 * <p>Four queries rather than one join, for the reason `listScope` gives: joining the rules to both
 * their conditions and their filters at once multiplies each rule by the product of the two.
 */
export async function listRouteTables(): Promise<RouteTable[]> {
  const [tables, rules] = await Promise.all([
    configQuery<TableRow>(
      "SELECT name, target_function, label, enabled FROM app_route_table ORDER BY name"
    ),
    configQuery<RuleRow>(
      `SELECT id::text, table_name, target, copied, label, enabled
         FROM app_route_rule ORDER BY table_name, seq`
    ),
  ]);

  const ids = rules.map((r) => r.id);
  const [conditions, filters] = ids.length
    ? await Promise.all([
        configQuery<{ rule_id: string; field: string; operator: string; value: string; negate: boolean }>(
          `SELECT rule_id::text, field, operator, value, negate
             FROM app_route_rule_condition WHERE rule_id = ANY($1::bigint[]) ORDER BY rule_id, seq`,
          [ids]
        ),
        configQuery<{ rule_id: string; filter_name: string }>(
          `SELECT rule_id::text, filter_name
             FROM app_route_rule_filter WHERE rule_id = ANY($1::bigint[]) ORDER BY rule_id, seq`,
          [ids]
        ),
      ])
    : [[], []];

  const conditionsByRule = new Map<string, ConditionInput[]>();
  for (const c of conditions) {
    const list = conditionsByRule.get(c.rule_id) ?? [];
    list.push({ field: c.field, operator: c.operator, value: c.value, negate: c.negate });
    conditionsByRule.set(c.rule_id, list);
  }
  const filtersByRule = new Map<string, string[]>();
  for (const f of filters) {
    const list = filtersByRule.get(f.rule_id) ?? [];
    list.push(f.filter_name);
    filtersByRule.set(f.rule_id, list);
  }

  const rulesByTable = new Map<string, RouteRule[]>();
  for (const r of rules) {
    const list = rulesByTable.get(r.table_name) ?? [];
    list.push({
      id: Number(r.id),
      target: r.target,
      copied: r.copied,
      label: r.label,
      enabled: r.enabled,
      conditions: conditionsByRule.get(r.id) ?? [],
      filters: filtersByRule.get(r.id) ?? [],
    });
    rulesByTable.set(r.table_name, list);
  }

  return tables.map((t) => ({
    name: t.name,
    //the column is CHECK-constrained to these two, but a cast is still a claim about data. A row
    //written before V1.28.0 dropped RC lands on NORMAL here, which is what RC always did anyway
    targetFunction: (["NORMAL", "LCR"].includes(t.target_function)
      ? t.target_function
      : "NORMAL") as TargetFunction,
    label: t.label,
    enabled: t.enabled,
    rules: rulesByTable.get(t.name) ?? [],
  }));
}

/**
 * Creates or rewrites one table and every rule in it.
 *
 * <h3>Why the seqs go negative first</h3>
 *
 * <p>`uq_app_route_rule_seq UNIQUE (table_name, seq)` is non-deferrable, so it is checked per row as
 * the statement runs — the obvious "set each rule's seq to its new position" fails the moment two
 * rules swap places. Parking every survivor in `[-n, -1]` in one statement, with distinct targets
 * from `row_number()`, vacates `[0, ∞)` before any final position is written. `saveScope` solves the
 * identical constraint the identical way; the two are worth keeping in step.
 *
 * <p>Rules that survive are UPDATEd rather than deleted and recreated, so their ids are stable and
 * nothing cascades. Conditions and filters are delete-and-reinsert per rule, which is safe: both are
 * keyed on `(rule_id, seq)`, nothing references either, and the parent id does not move.
 */
export async function saveRouteTable(input: RouteTableInput): Promise<void> {
  const name = input.name.trim();
  await inTransaction(async (client) => {
    await client.query(
      `INSERT INTO app_route_table (name, target_function, label, enabled, updated_at)
       VALUES ($1, $2, $3, $4, now())
       ON CONFLICT (name) DO UPDATE
         SET target_function = EXCLUDED.target_function, label = EXCLUDED.label,
             enabled = EXCLUDED.enabled, updated_at = now()`,
      [name, input.targetFunction, input.label?.trim() || null, input.enabled]
    );

    const existing = await client.query<{ id: string; seq: number }>(
      "SELECT id::text, seq FROM app_route_rule WHERE table_name = $1 ORDER BY seq FOR UPDATE",
      [name]
    );
    if (existing.rows.some((r) => r.seq < 0)) {
      throw new Error(
        `'${name}' has a rule at a negative position, which this rewrite cannot run safely against. `
        + "Fix it directly in the database first."
      );
    }

    const live = new Set(existing.rows.map((r) => r.id));
    const keep = input.rules.map((r) => r.id).filter((id): id is number => id != null).map(String);
    for (const id of keep) {
      if (!live.has(id)) {
        throw new Error(
          `Rule ${id} is not part of '${name}' any more. Reload the page — someone else has changed `
          + "this table since it was opened."
        );
      }
    }

    await client.query(
      "DELETE FROM app_route_rule WHERE table_name = $1 AND NOT (id = ANY($2::bigint[]))",
      [name, keep]
    );

    await client.query(
      `UPDATE app_route_rule r SET seq = -sub.rn
         FROM (SELECT id, row_number() OVER (ORDER BY id) AS rn
                 FROM app_route_rule WHERE table_name = $1) sub
        WHERE r.id = sub.id`,
      [name]
    );

    for (let i = 0; i < input.rules.length; i++) {
      const rule = input.rules[i];
      const values = [
        i, rule.target.trim(), rule.copied, rule.label?.trim() || null, rule.enabled,
      ];

      let id: string;
      if (rule.id != null) {
        const updated = await client.query<{ id: string }>(
          `UPDATE app_route_rule
              SET seq = $3, target = $4, copied = $5, label = $6, enabled = $7, updated_at = now()
            WHERE id = $2 AND table_name = $1
            RETURNING id::text`,
          [name, rule.id, ...values]
        );
        id = updated.rows[0].id;
        await client.query("DELETE FROM app_route_rule_condition WHERE rule_id = $1", [id]);
        await client.query("DELETE FROM app_route_rule_filter WHERE rule_id = $1", [id]);
      } else {
        const created = await client.query<{ id: string }>(
          `INSERT INTO app_route_rule (table_name, seq, target, copied, label, enabled, updated_at)
           VALUES ($1, $2, $3, $4, $5, $6, now())
           RETURNING id::text`,
          [name, ...values]
        );
        id = created.rows[0].id;
      }

      for (let c = 0; c < rule.conditions.length; c++) {
        const condition = rule.conditions[c];
        await client.query(
          `INSERT INTO app_route_rule_condition (rule_id, seq, field, operator, value, negate)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [id, c, condition.field, condition.operator, condition.value ?? "", condition.negate]
        );
      }

      //deduplicated for the same reason as a rate rule's: the same filter twice would apply its
      //conditions twice and inflate every usage count the filter library shows
      const names = [...new Set(rule.filters.map((f) => f.trim()).filter(Boolean))];
      for (let f = 0; f < names.length; f++) {
        await client.query(
          "INSERT INTO app_route_rule_filter (rule_id, filter_name, seq) VALUES ($1, $2, $3)",
          [id, names[f], f]
        );
      }
    }
  });
}

/**
 * Turns one rule on or off, without touching the order or anything else about it.
 *
 * <p>Separate from the whole-table PUT for the reason `setRuleEnabled` in `lib/rates.ts` is separate
 * from `saveScope`: retiring a rule is the thing an operator does in a hurry during an incident, and
 * it should not require re-sending every other rule in the table to do it. `saveRouteTable`'s
 * negative-seq dance and its "someone else changed this table" guard both exist because a whole-table
 * write can race a concurrent edit; a single-column update on one row cannot.
 */
export async function setRouteRuleEnabled(
  tableName: string,
  id: number,
  enabled: boolean
): Promise<boolean> {
  const rows = await configQuery<{ id: string }>(
    `UPDATE app_route_rule SET enabled = $3, updated_at = now()
      WHERE id = $2 AND table_name = $1 RETURNING id::text`,
    [tableName, id, enabled]
  );
  return rows.length > 0;
}

/**
 * Removes a table and its rules.
 *
 * <p>The rules cascade. What does not cascade — and cannot, because there is no foreign key on
 * `app_route_rule.target` — is a rule in *another* table that chains into this one. Those become
 * dead targets, which the editor flags; the alternative would be a foreign key on a column that
 * legitimately holds worker names too.
 */
export async function deleteRouteTable(name: string): Promise<boolean> {
  const rows = await configQuery<{ name: string }>(
    "DELETE FROM app_route_table WHERE name = $1 RETURNING name",
    [name]
  );
  return rows.length > 0;
}
