import { auth } from "@/lib/auth";
import { isOperatorSession } from "@/lib/roles";

/**
 * The gate every control route passes through.
 *
 * <p>Every API route calls this as its first statement. Hiding a nav item is presentation; this is
 * the control. The data behind these routes is margin and vendor names, so an unauthenticated
 * caller must get nothing, and must not learn that there was something to get.
 *
 * <h2>Why this checks the role and not just the session</h2>
 *
 * <p>It used to ask only whether a session had a name, which was correct while an operator was the
 * only identity this application could issue. The customer portal changed that. A customer holds a
 * real, valid, signed session -- and under the old check it would have satisfied this function and
 * opened every control route: margin, vendor names, every account's messages, credential editing.
 *
 * <p><strong>Do not weaken this back to a presence check.</strong> The decision lives in
 * {@link isOperatorSession}, and `lib/roles.test.ts` fails if it is loosened.
 *
 * @throws NotOperatorError which the route turns into a 404 rather than a 403 -- a 403 confirms
 *     the endpoint exists, which is more than an anonymous caller needs to know
 */
export async function requireOperator(): Promise<string> {
  const session = await auth();
  if (!isOperatorSession(session)) {
    throw new NotOperatorError();
  }
  return session!.user!.name!;
}

export class NotOperatorError extends Error {
  constructor() {
    super("Not found");
    this.name = "NotOperatorError";
  }
}
