import { randomBytes } from "crypto";
import { BILLING_KEY } from "@/lib/billing-key";
import { configQuery, inTransaction } from "@/lib/config-db";
import { disconnectBindsFor } from "@/lib/gateway-sessions";
import { billingOf, type Credential } from "@/lib/credential-types";
import type { ChildLoginWrite } from "@/lib/mis-account-rules";

/**
 * The logins on a reseller's own accounts: listing them, creating one, switching one off.
 *
 * <p>Server-only. Deliberately <strong>not</strong> `lib/credentials.ts`, which is the operator's
 * whole-row editor — a customer path that could reach `saveCredential` could reach `account_id`,
 * `product`, `allowed_products` and `default_tlvs` with it. Same separation, and the same reason, as
 * `lib/mis-credentials.ts` (which does one thing: rotate a secret on the caller's own login).
 *
 * <p>The field narrowing is in `lib/mis-account-rules.ts`. This file is the query and the
 * transaction.
 *
 * <h2>Two columns are written NULL and never read from the request</h2>
 *
 * <p><strong>`product` and `allowed_products`.</strong> The product picks which rate rule matches, so
 * a reseller free to set it is a reseller setting its own child's price — the one thing this whole
 * surface exists to not allow. An empty `allowed_products` already means "may not name one" to the
 * gateway, so the child cannot choose a product per message either. Both are the operator's, on the
 * operator's page.
 *
 * <p><strong>`default_tlvs`</strong> is absent for a different reason: those arrive through the
 * registration-approval path, where an operator sees what is being stamped before it reaches a
 * carrier.
 *
 * <h2>What a new login costs</h2>
 *
 * <p>`DbConfigPoller` reloads credentials on a poll — `smsg.config.db.poll.seconds`, default 30. So
 * a login created here does not work for up to that long, and one switched off keeps working for up
 * to that long. Every caller has to say so; it is the likeliest support call this feature generates,
 * exactly as `lib/mis-credentials.ts` records for rotation.
 */

/** Matches `smsg.config.db.poll.seconds`' default. Said in words, as `mis-credentials.ts` does. */
export const POLL_SECONDS = 30;

/**
 * The lookup key, computed in SQL exactly as `Credential.getLookupKey()` does.
 *
 * <p>The same expression `lib/credentials.ts` holds, and it is duplicated rather than exported
 * because that module pulls the products catalogue and the TLV parser in behind it. If the two ever
 * disagree the collision check below is checking a collision that does not exist — so the copy is
 * annotated in both places.
 */
const LOOKUP_KEY = `CASE WHEN type = 'SMPP' THEN system_id
                         ELSE COALESCE(NULLIF(api_key, ''), system_id) END`;

/**
 * Secret-free by construction.
 *
 * <p>`password` and `api_key` appear only inside `IS NOT NULL` tests. Nothing selects either value,
 * which is a step beyond sending a placeholder: a placeholder still requires the column to have been
 * read. The one exception in this module is the value {@link createLogin} generates and returns
 * once, which never comes back out of the database.
 */
const PROJECTION = `
  id::text, type, system_id, account_id, product, allowed_ips, allowed_products,
  enabled, updated_at,
  (password IS NOT NULL AND password <> '') AS has_password,
  (api_key  IS NOT NULL AND api_key  <> '') AS has_api_key,
  ${LOOKUP_KEY} AS lookup_key,
  (type <> 'SMPP' AND COALESCE(api_key, '') <> '') AS lookup_key_is_secret`;

interface Row {
  id: string;
  type: string;
  system_id: string | null;
  account_id: string | null;
  product: string | null;
  allowed_ips: string[] | null;
  allowed_products: string[] | null;
  enabled: boolean;
  updated_at: Date | null;
  has_password: boolean;
  has_api_key: boolean;
  lookup_key: string | null;
  lookup_key_is_secret: boolean;
}

/**
 * Every login billing to these accounts.
 *
 * <p>Selected by {@link BILLING_KEY} rather than `account_id`, for the reason that module exists: a
 * login with a blank account bills to its system id, so it belongs to that account even though the
 * column is null. A query reading the column raw would show a child no logins while it happily sends.
 *
 * <p>Returned as `Credential[]`, the operator type, because the portal renders the operator's own
 * `AccountsCatalogueClient` and `CredentialsClient` — see `lib/panel-surface.ts`.
 */
export async function listChildLogins(accountIds: readonly string[]): Promise<Credential[]> {
  if (!accountIds.length) {
    return [];
  }
  const rows = await configQuery<Row>(
    `SELECT ${PROJECTION} FROM app_credential WHERE ${BILLING_KEY} = ANY($1) ORDER BY id`,
    [accountIds]
  );
  return rows.map(toCredential);
}

function toCredential(row: Row): Credential {
  const billing = billingOf(row.type, row.account_id, row.system_id, row.has_api_key);
  return {
    id: Number(row.id),
    type: row.type,
    systemId: row.system_id,
    accountId: row.account_id,
    product: row.product,
    allowedIps: row.allowed_ips ?? [],
    allowedProducts: row.allowed_products ?? [],
    //never populated on this surface, and not parsed either: the reseller cannot set default TLVs,
    //and rendering an operator's would show a customer the DLT identifiers of its own child's
    //approvals before an operator had decided them
    defaultTlvs: [],
    enabled: row.enabled,
    updatedAt: row.updated_at ? row.updated_at.toISOString() : null,
    password: row.has_password ? "stored" : "unset",
    apiKey: row.has_api_key ? "stored" : "unset",
    //dropped rather than sent: for an HTTP credential with an api key this value IS the secret
    lookupKey: row.lookup_key_is_secret ? null : row.lookup_key,
    lookupKeyIsSecret: row.lookup_key_is_secret,
    billingAccount: billing.account,
    billingAccountFallback: billing.fallback,
  };
}

/**
 * 24 bytes of `randomBytes`, base64url.
 *
 * <p>The same construction as `lib/mis-credentials.ts` and the portal's sign-in tokens. Not a
 * passphrase and not derived from anything — the gateway compares this byte for byte, so width is
 * the only property that matters and a CSPRNG is the only acceptable source.
 */
function mint(): string {
  return randomBytes(24).toString("base64url");
}

export type CreateResult =
  | {
      ok: true;
      id: number;
      /** Returned exactly once. Not stored anywhere the panel can read it back. */
      secret: string;
      /** Which secret the value is — an SMPP login gets a password, an HTTP one an API key. */
      secretKind: "password" | "apiKey";
      /** For HTTP, the API key is also the Basic username. Said, not left to be discovered. */
      username: string | null;
    }
  | { ok: false; problem: string };

/**
 * Creates one login on one child, with a generated secret.
 *
 * <p><strong>No secret is accepted from the caller.</strong> A chosen secret is one that has been
 * typed into a form, pasted into a chat and reused from somewhere else; there is no path in this
 * panel that takes one from a customer and there should not be. The value is in the return and
 * nowhere else — not logged, not in the audit detail, not readable back through {@link PROJECTION}.
 *
 * <p>The account is a parameter, not a field: the caller has already put it through `assertInScope`.
 *
 * <p>The lookup-key clash check runs inside the transaction, and it matters more here than it does
 * for an operator. The gateway loads every credential into one map keyed on it and resolves a
 * duplicate by keeping the later row — so a reseller picking a system id that another customer
 * already uses would take **that customer** offline. There is no unique index to lean on; this check
 * narrows the race and does not close it, which is the same compensating-control argument
 * `saveCredential` makes.
 */
export async function createLogin(
  accountId: string,
  input: ChildLoginWrite
): Promise<CreateResult> {
  const systemId = input.systemId?.trim() || null;
  if (input.type === "SMPP" && !systemId) {
    return {
      ok: false,
      problem: "An SMPP login needs a system ID. It is the username the connection binds with.",
    };
  }
  if (input.type === "SMPP" && systemId && systemId.length > 16) {
    //the SMPP wire field is 16 octets including its terminator, so a longer value cannot be sent.
    //Refused here rather than truncated: a silently shortened system id is a bind that fails with
    //the right password
    return {
      ok: false,
      problem: `'${systemId}' is too long for SMPP. A system ID is at most 15 characters — the `
        + "protocol field cannot carry more, so a longer one could never be used to connect.",
    };
  }

  const secret = mint();
  //an SMPP login authenticates with system id and password; an HTTP one with an API key, which is
  //also its Basic username. One secret each, so there is one thing to hand over and one thing to
  //rotate -- the two-secret shapes the operator form allows exist for migrations, not for new logins
  const isSmpp = input.type === "SMPP";
  const password = isSmpp ? secret : null;
  const apiKey = isSmpp ? null : secret;
  const key = isSmpp ? systemId : apiKey;

  return inTransaction(async (client) => {
    if (key) {
      const clash = await client.query<{ id: string }>(
        `SELECT id::text FROM app_credential WHERE enabled AND ${LOOKUP_KEY} = $1`,
        [key]
      );
      if (clash.rows.length) {
        //the id of the other row is deliberately NOT in the message. On the operator's form it is
        //useful; here it would tell one customer that another customer's login exists
        return {
          ok: false,
          problem: `'${key}' is already in use as a login name. Pick another — the gateway keeps `
            + "only one login per name, so sharing one would take somebody offline.",
        } as CreateResult;
      }
    }

    const created = await client.query<{ id: string }>(
      `INSERT INTO app_credential
              (type, system_id, password, api_key, account_id, product,
               allowed_ips, allowed_products, default_tlvs, enabled, updated_at)
       VALUES ($1, $2, $3, $4, $5, NULL, $6::text[], NULL, NULL, $7, now())
       RETURNING id::text`,
      [
        input.type,
        systemId,
        password,
        apiKey,
        accountId,
        //null rather than an empty array: both mean allow-all to the gateway, but null is what
        //"absent" means and it keeps "which logins are unrestricted" a question SQL can answer
        input.allowedIps.length ? input.allowedIps : null,
        input.enabled,
      ]
    );

    return {
      ok: true,
      id: Number(created.rows[0].id),
      secret,
      secretKind: isSmpp ? "password" : "apiKey",
      //for HTTP the key is the username too, which is the single most common thing to get wrong
      //about this API -- see the warning `credentialWarnings` already carries about it
      username: isSmpp ? systemId : secret,
    } as CreateResult;
  });
}

export type ToggleResult =
  | { ok: true; systemId: string | null; enabled: boolean; dropped: number; problem?: string }
  | { ok: false; notFound: true };

/**
 * Switches one of a child's logins on or off, and drops its binds when switching off.
 *
 * <p>Ownership is proved twice, as `rotateSecret` does and for the same reason: once by the caller
 * through `assertInScope`, and again inside the transaction with `FOR UPDATE`, because between those
 * two moments an operator may have moved the login to another account. The second check is what
 * makes the write safe rather than merely likely to be safe.
 *
 * <p>Dropping the binds is best effort and happens after the commit. `enabled = false` is a statement
 * about future binds only — a customer already bound keeps submitting until something ends the
 * session. An unreachable gateway is worth reporting and never worth failing the write for, since
 * the stored change is the durable intent and the gateway applies it on its next poll regardless.
 */
export async function setLoginEnabled(
  accountId: string,
  id: number,
  enabled: boolean
): Promise<ToggleResult> {
  const row = await inTransaction(async (client) => {
    const current = await client.query<{ account_id: string | null; system_id: string | null; type: string }>(
      `SELECT ${BILLING_KEY} AS account_id, system_id, type
         FROM app_credential WHERE id = $1 FOR UPDATE`,
      [id]
    );
    if (!current.rows.length || current.rows[0].account_id !== accountId) {
      return null;
    }
    await client.query(
      "UPDATE app_credential SET enabled = $2, updated_at = now() WHERE id = $1",
      [id, enabled]
    );
    return current.rows[0];
  });

  if (!row) {
    return { ok: false, notFound: true };
  }
  if (enabled || row.type !== "SMPP" || !row.system_id) {
    return { ok: true, systemId: row.system_id, enabled, dropped: 0 };
  }
  const teardown = await disconnectBindsFor(row.system_id);
  return {
    ok: true,
    systemId: row.system_id,
    enabled,
    dropped: teardown.dropped,
    problem: teardown.problem,
  };
}
