import type { RateRuleInput } from "./rate-types.ts";

/**
 * Working out what a **product-scoped** save does to a scope, without a database.
 *
 * <p>`saveScope` replaces a scope wholesale: it deletes every rule it is not given. That is correct
 * on `/cp/pricing`, where the form holds and displays the entire scope before it replaces it. It is
 * a data-loss trap anywhere the operator is looking at one product — following the product page's
 * own instruction ("add pricing with the scope `*`") would have deleted `*` for every other product
 * on the platform, from a page that never named them.
 *
 * <p>So this decides the same three things a whole-scope save decides — what goes, what stays, and
 * what sequence number everything ends up at — for one product's slice, and leaves the rest of the
 * scope exactly as it was.
 *
 * <h2>Why the sequence numbers still have to be worked out across the whole scope</h2>
 *
 * <p>`seq` is unique per scope, not per product, and `UNIQUE (scope, seq)` is not deferrable. A
 * product-scoped write therefore cannot number its own rules in isolation: it has to allocate around
 * the rules it is not touching. This module produces those positions; `saveScopeForProduct` applies
 * them in one transaction.
 *
 * <h2>Why this is a plan and not a query</h2>
 *
 * <p>Extracted so the assertion that matters can be made without a database. The panel's tests run
 * `node --test` over `lib/` with no Postgres and no container, so a `saveScopeForProduct` that held
 * this arithmetic inline would be verifiable only by hand — and "the other product's rules are still
 * there" is precisely the property nobody notices until a customer's tariff is gone.
 */

/** One rule already stored in the scope, as much of it as the arithmetic needs. */
export interface ExistingRule {
  id: number;
  seq: number;
  product: string | null;
}

/** Where one rule ends up. */
export interface Placement {
  id: number;
  seq: number;
}

/** Everything a product-scoped save has to do, decided up front. */
export interface ScopeWritePlan {
  /**
   * Rules of **this product** that the submitted set no longer contains.
   *
   * <p>Never contains a rule of another product. That is the whole invariant.
   */
  deleteIds: number[];
  /**
   * Final positions for the rules this save is not touching, in the order they already had.
   *
   * <p>They move — a scope's positions are renumbered from zero on every write — but only relative
   * to each other do positions mean anything, and relative to each other they are unchanged.
   */
  keep: Placement[];
  /** The submitted rules with the positions they take, in the submitted order. */
  writes: { rule: RateRuleInput; seq: number }[];
}

/**
 * Decides a product-scoped save.
 *
 * <p>This product's rules are placed **after** every rule the save is not touching. That is not a
 * detail: `RateSnapshot.rulesFor` returns a scope's rules for the product followed by its
 * any-product ones and walks that concatenation, so buckets are matched separately and only the
 * order *within* a bucket decides anything. Appending is therefore free of meaning for matching, and
 * it is the one arrangement that leaves every other bucket's internal order visibly untouched.
 *
 * @param existing every rule stored in the scope, in `seq` order
 * @param product the product being priced — non-empty, because the any-product bucket is the one
 *     bucket this cannot be used for: "the rules with no product" is what a catch-all is, and
 *     rewriting it under the name of a product would be a different operation wearing this one's name
 * @param rules the rules this product should have afterwards, in the order they should be tried. A
 *     rule carrying an `id` must already belong to this product in this scope
 * @throws Error with a sentence when the submitted set cannot be applied
 */
export function planProductWrite(
  existing: readonly ExistingRule[],
  product: string,
  rules: readonly RateRuleInput[]
): ScopeWritePlan {
  const target = product.trim();
  if (!target) {
    throw new Error(
      "A product-scoped save needs a product. Without one this would rewrite the scope's "
      + "any-product rules, which are its catch-alls — use the whole-scope editor for those."
    );
  }

  //there is no CHECK (seq >= 0) on the column, so a hand-written negative would collide with the
  //parking range the transaction uses and produce a duplicate key from a statement that looks
  //unrelated. The same refusal saveScope makes, for the same reason
  if (existing.some((r) => r.seq < 0)) {
    throw new Error(
      "This scope has a rule at a negative position, which this rewrite cannot run safely against. "
      + "Fix it directly in the database first."
    );
  }

  //exact equality, not a trimmed comparison, because that is what every query matching this column
  //does -- and it is what the list the operator is looking at was built from. A stored ' promo' is a
  //rule that prices nothing (validateRule refuses saving one), and adopting it here would delete it
  //from a page that never showed it
  const mine = existing.filter((r) => r.product === target);
  const others = existing.filter((r) => r.product !== target);
  const mineById = new Map(mine.map((r) => [r.id, r]));
  const otherById = new Map(others.map((r) => [r.id, r]));

  const keepIds = new Set<number>();
  for (const rule of rules) {
    if (rule.id == null) {
      continue;
    }
    //an id belonging to ANOTHER product is refused rather than adopted. Accepting it would move that
    //rule into this product's bucket -- silently repricing whatever it was pricing, and removing it
    //from the page that shows it
    if (otherById.has(rule.id)) {
      const owner = otherById.get(rule.id)!.product;
      throw new Error(
        `Rule ${rule.id} prices ${owner ? `'${owner}'` : "every product"} in this scope, not `
        + `'${target}'. Editing it here would move it out of the bucket it belongs to. Open it from `
        + "the scope itself."
      );
    }
    if (!mineById.has(rule.id)) {
      throw new Error(
        `Rule ${rule.id} is not part of '${target}' in this scope any more. Reload the page — `
        + "someone else has changed this pricing since it was opened."
      );
    }
    if (keepIds.has(rule.id)) {
      throw new Error(`Rule ${rule.id} appears twice. A rule holds one position, not two.`);
    }
    keepIds.add(rule.id);
  }

  return {
    deleteIds: mine.filter((r) => !keepIds.has(r.id)).map((r) => r.id),
    //`others` is already in seq order because `existing` is; renumbering it densely from zero keeps
    //that order and vacates the tail for this product's rules
    keep: others.map((r, i) => ({ id: r.id, seq: i })),
    writes: rules.map((rule, i) => ({ rule, seq: others.length + i })),
  };
}
