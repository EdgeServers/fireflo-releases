import { timingSafeEqual } from "crypto";
import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { logAuthFailure, logOperatorEvent } from "@/lib/access-log";
import { currentRequestContext, markRequestHandled } from "@/lib/request-context";
import { OPERATOR_ROLE } from "@/lib/roles";

declare module "next-auth" {
  interface Session {
    user: {
      name?: string | null;
      email?: string | null;
      image?: string | null;
      /** `"operator"` and nothing else. See {@link OPERATOR_ROLE}. */
      role?: string | null;
    };
  }
}

/** The single claim this instance adds to the token. */
interface RoleToken { role?: string }

const DEFAULT_USERNAME = "operator";

/**
 * `AUTH_URL` must be a bare origin, and saying so early is cheaper than the failure.
 *
 * <p>next-auth does `config.basePath || (config.basePath = pathname)`. A value with a path —
 * `https://panel.example.com/panel` — therefore silently moves this instance's endpoints to
 * `/panel`, and every call to `/api/auth/*` answers "Bad request" with nothing pointing at the
 * cause. The customer instance escapes this only because it sets `basePath` explicitly.
 *
 * <p>Warned, not thrown: a hard failure at module load takes the entire panel down over a trailing
 * slash somebody typed into an environment file, which is a worse outcome than a broken redirect.
 */
function warnIfAuthUrlHasPath(): void {
  const raw = process.env.AUTH_URL?.trim();
  if (!raw) {
    return;
  }
  try {
    const parsed = new URL(raw);
    if (parsed.pathname !== "/" && parsed.pathname !== "") {
      console.error(
        `AUTH_URL is "${raw}", which has a path. next-auth adopts that path as its basePath, so `
          + "every /api/auth call will fail. Set it to the bare origin: "
          + `${parsed.protocol}//${parsed.host}`
      );
    }
  } catch {
    console.error(`AUTH_URL is "${raw}", which is not a URL. Sign-out will redirect to the port this process bound.`);
  }
}

warnIfAuthUrlHasPath();

/**
 * Operator sign-in.
 *
 * <p>This is deliberately NOT a gateway messaging credential. The data behind this panel includes
 * margin and the names of the vendors traffic is bought from; the gateway's own credentials
 * belong to customers, and it has no notion of an admin role. An operator is a different kind of
 * identity, so it gets a different authenticator.
 *
 * <p>With `OPERATOR_PASSWORD` unset there is no way in at all — not "any password works", not
 * "no password required". Missing configuration fails closed.
 */
export const { handlers, auth, signIn, signOut } = NextAuth({
  providers: [
    Credentials({
      id: "operator",
      name: "Operator",
      credentials: {
        username: { label: "Username", type: "text" },
        password: { label: "Password", type: "password" },
      },
      authorize(credentials) {
        //the IP arrives through an async context because this function is handed credentials and
        //nothing else. See lib/request-context.ts for why that beats reading the response.
        const context = currentRequestContext();
        const record = (event: "signin" | "signin_failed", actor: string | null, reason?: string) => {
          markRequestHandled();
          void logOperatorEvent({
            event,
            actor,
            ip: context?.ip ?? null,
            userAgent: context?.userAgent ?? null,
            detail: reason ? { reason } : undefined,
          });
          //also to the file fail2ban watches. The operator log stays what it is -- an audit trail
          //of what an operator did, where a success sits beside a failure -- and only the dedicated
          //one is jailed, so a refusal is recorded twice and counted once
          if (event === "signin_failed") {
            void logAuthFailure({
              surface: "panel",
              reason: reason ?? "bad_credentials",
              triedAs: actor,
              ip: context?.ip ?? null,
            });
          }
        };

        const expectedPassword = process.env.OPERATOR_PASSWORD;
        if (!expectedPassword) {
          console.error("OPERATOR_PASSWORD is not set; operator sign-in is disabled.");
          record("signin_failed", null, "not_configured");
          return null;
        }

        const expectedUsername = process.env.OPERATOR_USERNAME?.trim() || DEFAULT_USERNAME;
        const username = (credentials?.username as string | undefined)?.trim() ?? "";
        const password = (credentials?.password as string | undefined) ?? "";

        //both compared in constant time, and both must pass -- returning early on a username
        //mismatch would leak which half was wrong through timing
        const userOk = constantTimeEquals(username, expectedUsername);
        const passOk = constantTimeEquals(password, expectedPassword);
        if (!userOk || !passOk) {
          //the attempted name is recorded, the reason is not broken down: a log that said which
          //half matched would hand back through disk exactly what the constant-time compare above
          //refuses to leak through timing
          record("signin_failed", username || null, "bad_credentials");
          return null;
        }

        record("signin", expectedUsername);
        return { id: expectedUsername, name: expectedUsername, email: `${expectedUsername}@control.local` };
      },
    }),
  ],

  pages: { signIn: "/cp/login" },
  trustHost: true,
  session: { strategy: "jwt" },

  callbacks: {
    //the role is stamped at sign-in and carried in the JWT rather than recomputed. Only this
    //provider can put it there, and this provider only authorises operators
    jwt({ token, user }) {
      if (user) {
        //cast rather than a `next-auth/jwt` module augmentation: v5 does not publish that subpath,
        //so augmenting it is a type error rather than a declaration
        (token as RoleToken).role = OPERATOR_ROLE;
      }
      return token;
    },
    session({ session, token }) {
      session.user.role = (token as RoleToken).role ?? null;
      return session;
    },
    authorized({ auth: session }) {
      return session?.user?.role === OPERATOR_ROLE;
    },
  },

  // no maxAge: the session dies with the browser
  cookies: {
    sessionToken: {
      name: "fireflo-control.session-token",
      options: {
        httpOnly: true,
        sameSite: "lax" as const,
        path: "/",
        secure: process.env.NODE_ENV === "production",
      },
    },
  },
});

/**
 * Compares without revealing how much matched through timing.
 *
 * <p>Lengths are compared separately because `timingSafeEqual` throws on a length mismatch, which
 * would itself be a signal. Hashing both sides to a fixed width would hide even that; for a single
 * local operator credential the length leak is not worth the extra machinery, but it is a leak and
 * worth naming rather than pretending otherwise.
 */
function constantTimeEquals(a: string, b: string): boolean {
  const left = Buffer.from(a, "utf8");
  const right = Buffer.from(b, "utf8");
  if (left.length !== right.length) {
    return false;
  }
  return timingSafeEqual(left, right);
}
