import { test } from "node:test";
import assert from "node:assert/strict";
import {
  REJECTED_COLUMNS,
  REJECTED_COLUMN_GROUPS,
  resolveColumns,
} from "./rejected-columns.ts";
import { toggleColumn } from "./table-columns.ts";
import type { RejectedRow } from "./rejected-types.ts";

/**
 * The refusals catalogue.
 *
 * <p>Components have no tests in this repository, which is precisely why the promise that matters
 * lives down here: an operator who has never opened the chooser must see the table they saw before
 * there was one.
 */

test("the default columns are the nine the table had before it had a chooser, in that order", () => {
  //Order included, and that is the point of writing it this way. `group` orders the CHOOSER; the
  //array orders the TABLE, and clustering the array by group -- which is how cdr-columns.ts happens
  //to read -- would silently move "Via" out from between "To" and "Message"
  assert.deepEqual(
    REJECTED_COLUMNS.filter((c) => c.defaultOn).map((c) => c.id),
    [
      "rejectedAt",
      "reason",
      "vendorStatus",
      "accountId",
      "product",
      "sourceAddr",
      "destAddr",
      "ingress",
      "bodyExcerpt",
    ]
  );
});

test("the default headers still read as the old table's header row", () => {
  assert.deepEqual(
    REJECTED_COLUMNS.filter((c) => c.defaultOn).map((c) => c.header),
    ["Refused", "Why", "Vendor said", "Account", "Product", "From", "To", "Via", "Message"]
  );
});

test("every column of cdr_rejected is offered", () => {
  //the whole point of the change. If the gateway adds a column and the panel forgets it, this is
  //where that shows up rather than in somebody wondering why the chooser is short
  const offered = new Set(REJECTED_COLUMNS.map((c) => c.id));
  for (const column of [
    "id", "rejectedAt", "reason", "detail", "accountId", "systemId", "product", "ingress",
    "inGateway", "sourceAddr", "destAddr", "bodyExcerpt", "dcs", "parts", "gatewayMsgId",
    "vendorStatus",
  ]) {
    assert.ok(offered.has(column), `${column} exists in the table and is in no column`);
  }
});

test("ids are unique and every group is one the chooser knows", () => {
  const ids = REJECTED_COLUMNS.map((c) => c.id);
  assert.equal(new Set(ids).size, ids.length, "a duplicate id makes one column unreachable");
  for (const column of REJECTED_COLUMNS) {
    assert.ok(
      (REJECTED_COLUMN_GROUPS as readonly string[]).includes(column.group),
      `${column.id} is in group '${column.group}', which the chooser does not render`
    );
  }
});

test("a column added later appears for someone who has already used the chooser", () => {
  //the reason ColumnChoice records decisions rather than a flat list of enabled ids. With a flat
  //list a new column would be absent from every stored preference, permanently and silently
  const choice = toggleColumn(null, "dcs", true);
  const resolved = resolveColumns(choice).map((c) => c.id);
  assert.ok(resolved.includes("dcs"), "the column just ticked");
  assert.ok(resolved.includes("rejectedAt"), "and one never mentioned, from its own default");
});

test("turning a default column off keeps the rest", () => {
  const resolved = resolveColumns(toggleColumn(null, "bodyExcerpt", false)).map((c) => c.id);
  assert.ok(!resolved.includes("bodyExcerpt"));
  assert.ok(resolved.includes("ingress"));
});

test("the derived columns read what they claim to", () => {
  const row: RejectedRow = {
    id: "12",
    rejectedAt: "2026-08-18T12:00:00.000Z",
    reason: "vendorRejected",
    detail: "the vendor refused the submit without saying why",
    accountId: "acct-1",
    systemId: "sys-1",
    product: "india-tr",
    ingress: "SMPP",
    inGateway: "smppserver.in",
    sourceAddr: "ACME",
    destAddr: "919999999999",
    bodyExcerpt: "Dear Priya, your order has shipped",
    dcs: 0,
    parts: 0,
    gatewayMsgId: "gw-1",
    vendorStatus: 69,
  };
  const by = (id: string) => REJECTED_COLUMNS.find((c) => c.id === id)!.from(row);

  assert.equal(by("reasonLabel"), "Vendor refused it");
  assert.equal(by("vendorStatusName"), "ESME_RSUBMITFAIL");
  assert.equal(by("afterAccepting"), true, "vendorRejected happens after the customer was told yes");
  //0 rather than blank: the cell decides what a zero means, and the two zeros mean opposite things
  assert.equal(by("dcs"), 0);
  assert.equal(by("parts"), 0);
});

test("a door refusal reads as having no vendor and no message", () => {
  const row: RejectedRow = {
    id: "13",
    rejectedAt: "2026-08-18T12:00:00.000Z",
    reason: "headerNotApproved",
    detail: null,
    accountId: "acct-1",
    systemId: null,
    product: "",
    ingress: "HTTP",
    inGateway: null,
    sourceAddr: "NOTMINE",
    destAddr: "919999999999",
    bodyExcerpt: null,
    dcs: 0,
    //the gateway stores an empty string here, not NULL -- StandardMessage.serial starts as "" and
    //is written through unchecked. The column has to render that as absent, not as an empty link
    gatewayMsgId: "",
    parts: 1,
    vendorStatus: null,
  };
  const by = (id: string) => REJECTED_COLUMNS.find((c) => c.id === id)!.from(row);

  assert.equal(by("gatewayMsgId"), null, "an empty serial is no message id at all");
  assert.equal(by("vendorStatusName"), null);
  assert.equal(by("afterAccepting"), false, "refused at the door: nothing was charged");
});
