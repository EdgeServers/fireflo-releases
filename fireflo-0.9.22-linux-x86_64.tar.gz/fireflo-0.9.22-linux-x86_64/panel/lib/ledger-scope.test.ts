import { strict as assert } from "node:assert";
import { test } from "node:test";

import {
  DEFAULT_LEDGER_SCOPE,
  MACHINE_ENTRY_TYPES,
  hiddenEntriesLabel,
  humanEntriesPredicate,
  isHumanEntry,
  isLedgerScope,
} from "./ledger-scope.ts";

test("the predicate is byte-identical to the migration's index predicate", () => {
  //V1.35.0__balance_ledger_human_entries.sql:
  //  WHERE entry_type <> 'RESERVE' AND entry_type <> 'RELEASE'
  //
  //asserted by value rather than by behaviour because behaviour cannot see the difference: any
  //predicate selecting the same rows returns the same page, and only this exact one lets the
  //planner use the partial index. Drift here is a silent sequential scan over the whole ledger
  assert.equal(humanEntriesPredicate(), "entry_type <> 'RESERVE' AND entry_type <> 'RELEASE'");
});

test("the two machine types are the whole of the machine vocabulary", () => {
  //if a third is ever added it must be added to the migration in the same commit, or the index
  //stops covering the query and this test is the only thing that will say so
  assert.deepEqual([...MACHINE_ENTRY_TYPES], ["RESERVE", "RELEASE"]);
});

test("a type nobody has invented yet is human", () => {
  //the point of stating it negatively: BILL and ADJUSTMENT show up the day they are first written,
  //with no migration and no panel release
  assert.equal(isHumanEntry("RECHARGE"), true);
  assert.equal(isHumanEntry("TRANSFER"), true);
  assert.equal(isHumanEntry("BILL"), true);
  assert.equal(isHumanEntry("ADJUSTMENT"), true);
  assert.equal(isHumanEntry("SOMETHING_FROM_2027"), true);
  assert.equal(isHumanEntry("RESERVE"), false);
  assert.equal(isHumanEntry("RELEASE"), false);
});

test("the default hides the machine rows", () => {
  //the whole report was "I could not find the human transaction", so the default is the fix
  assert.equal(DEFAULT_LEDGER_SCOPE, "human");
});

test("a scope from a query string is validated rather than trusted", () => {
  assert.equal(isLedgerScope("human"), true);
  assert.equal(isLedgerScope("all"), true);
  assert.equal(isLedgerScope("HUMAN"), false);
  assert.equal(isLedgerScope(""), false);
  assert.equal(isLedgerScope(undefined), false);
  assert.equal(isLedgerScope("all; DROP TABLE balance_ledger"), false);
});

test("hidden rows are counted out loud, never hidden silently", () => {
  assert.equal(hiddenEntriesLabel(0), "");
  assert.equal(hiddenEntriesLabel(1), "1 credit reservation hidden");
  assert.equal(hiddenEntriesLabel(12481), "12,481 credit reservations hidden");
});
