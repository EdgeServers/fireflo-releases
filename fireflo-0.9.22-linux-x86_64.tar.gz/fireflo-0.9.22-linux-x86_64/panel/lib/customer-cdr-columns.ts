import { CDR_COLUMNS, type CdrColumn } from "./cdr-columns.ts";

/**
 * The message columns a customer may see.
 *
 * <p><strong>An allow-list, not a deny-list, and that is the whole point.</strong> The operator
 * table has a Money group carrying `cost`, `costRate`, `costUnits`, `costRuleId`, `margin` and
 * `marginPct`, plus `vendor` in Route. Every one of those is our buy price or who we buy from.
 * "The same table as /cdrs" would hand all of it to every customer.
 *
 * <p>Listing what is allowed means a column added to the operator table later is invisible here by
 * default. A deny-list would mean the opposite: the next `costPerSegment` somebody adds would show
 * up in the portal until somebody remembered to hide it, and nobody would be looking.
 *
 * <p><strong>`price` is deliberately in.</strong> A customer may see what they were charged — that
 * is their invoice line. What they may not see is what it cost us, which is a different number and
 * the only one worth protecting.
 */
const ALLOWED = new Set<string>([
  // --- what was sent, and when
  "submittedAt",
  "acceptedAt",
  "destAddr",
  "sourceAddr",
  "gatewayMsgId",
  "partNo",
  "partCount",
  "retryCount",
  "dcs",
  "msgType",
  "accountId",
  "systemId",
  "product",
  "ingress",
  //what THEY sent us, and only that. The resolved set carries our account defaults and approved
  //sender IDs; the sent set carries which tags our vendor registered. Both are ours, not theirs
  "tlvsReceived",
  //and the message itself, whole. This is the one field where the allow-list opens rather than
  //closes: a customer reading back what they sent us is reading their own content, and refusing it
  //would be protecting them from themselves. Empty unless the gateway is recording content at all
  "body",
  // --- where it landed. The network is theirs to know; the vendor we bought from is not
  "mcc",
  "mnc",
  // --- what happened to it
  "outcome",
  "dlrState",
  "errCode",
  "finalAt",
  "operatorMsgId",
  //what THEY asked to be told. Their own request read back to them, and the field a "why did my
  //system get no receipt" ticket turns on -- refusing it would mean the answer only exists on our
  //side of the conversation
  "registeredDelivery",
  // --- what it cost THEM, and nothing about what it cost US
  "price",
  "priceRate",
  "billedUnits",
  "currency",
]);

/**
 * The customer table's columns, in the operator table's order.
 *
 * <p>Derived from `CDR_COLUMNS` rather than redeclared, so a column's header, formatter and sort
 * behave identically on both surfaces and only the membership differs.
 */
export const CUSTOMER_CDR_COLUMNS: CdrColumn[] = CDR_COLUMNS.filter((c) => ALLOWED.has(c.id));

/**
 * The same list as ids, for the export path.
 *
 * <p>Exports build their own column list from the request. Without this they would happily write a
 * CSV containing exactly the columns the table just hid, which is the more damaging leak of the two
 * because it lands in a file somebody keeps.
 *
 * <p><strong>These are column ids, not row fields.</strong> Use {@link CUSTOMER_CDR_FIELDS} to
 * decide what may travel — see the note there for what happens when the two are confused.
 */
export const CUSTOMER_CDR_COLUMN_IDS: readonly string[] = CUSTOMER_CDR_COLUMNS.map((c) => c.id);

/**
 * Column ids whose data lives under a different name on the row.
 *
 * <p>Only one today, and it cost us: the outcome column is `outcome` and reads `finalState`. The
 * projection below used to filter the row by column id, so `"outcome" in row` was false, the field
 * was dropped, and every message reached the customer with no outcome at all — rendering as
 * "Awaiting receipt" for traffic the operator's own table showed as FAILED.
 *
 * <p>A column added later with a mismatched name would do exactly the same thing, silently. The
 * test beside this file is what makes that a failure rather than a support ticket.
 */
const FIELD_FOR: Record<string, string> = {
  outcome: "finalState",
  //id and field happen to match here, but listing it documents that this is the CUSTOMER's own
  //submission and not the resolved or sent set, which have no entry and no column
  tlvsReceived: "tlvsReceived",
  //likewise: the customer's own message text, and nothing derived from it
  body: "body",
};

/**
 * The row fields a customer may receive.
 *
 * <p>Derived from the same allow-list as the columns, so there is still one place that decides what
 * a customer may see — this only translates that decision from what the table calls a column into
 * what the query calls a field.
 */
export const CUSTOMER_CDR_FIELDS: readonly string[] = CUSTOMER_CDR_COLUMN_IDS.map(
  (id) => FIELD_FOR[id] ?? id
);

/**
 * Drops every field not on the customer list.
 *
 * <p>Built from the allow-list rather than by deleting known-sensitive keys: a row gaining a field
 * upstream is then absent here by default rather than present until somebody notices.
 *
 * <p>Lives here rather than in the route so it can be tested directly. What it must guarantee is
 * two-sided and only one side is about security: nothing forbidden survives, **and** everything the
 * customer table renders does.
 */
export function projectForCustomer(row: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const field of CUSTOMER_CDR_FIELDS) {
    if (field in row) {
      out[field] = row[field];
    }
  }
  return out;
}

/** Whether a column id may be served to a customer. For validating anything caller-supplied. */
export function allowedForCustomer(id: string): boolean {
  return ALLOWED.has(id);
}
