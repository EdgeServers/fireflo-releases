import { test } from "node:test";
import assert from "node:assert/strict";
import type { CdrRow } from "./cdr-request";
import {
  CUSTOMER_CDR_COLUMNS,
  CUSTOMER_CDR_FIELDS,
  allowedForCustomer,
  projectForCustomer,
} from "./customer-cdr-columns.ts";

/**
 * What reaches a customer, in both directions.
 *
 * <p>The allow-list has always been tested by inspection in one direction only — nothing forbidden
 * gets out — and that half was fine. The half nobody checked is whether everything the customer
 * table *renders* survives the projection, and it did not: the outcome column is called `outcome`
 * and reads `finalState`, the projection filtered by column id, so `finalState` was dropped from
 * every row. Customers saw "Awaiting receipt" on messages the operator's table showed as FAILED.
 *
 * <p>Both directions are asserted here, because a projection that leaks is a security bug and a
 * projection that over-drops is a correctness bug, and only one of them announces itself.
 */

/** Every field a row off `searchCdrs` carries, populated so a dropped one is unmistakable. */
const fullRow: CdrRow = {
  id: "9001",
  gatewayMsgId: "a3f9c1d2",
  partNo: 1,
  partCount: 1,
  retryCount: 0,
  submittedAt: "2026-08-15T09:02:07.441Z",
  acceptedAt: "2026-08-15T09:02:07.001Z",
  accountId: "acme-in",
  systemId: "acme-smpp",
  product: "promo",
  ingress: "smpp",
  inGateway: "smppserver.smpp",
  vendor: "vendor1",
  sourceAddr: "ACMEIN",
  destAddr: "+919820011234",
  mcc: 404,
  mnc: 20,
  dcs: 0,
  msgType: 0,
  operatorMsgId: "OP-77",
  costRate: 800,
  costUnits: 1,
  cost: 800,
  priceRate: 1250,
  billedUnits: 1,
  price: 1250,
  margin: 450,
  marginPct: 36,
  marginStatus: "ok",
  costRuleId: "11",
  priceRuleId: "22",
  currency: "INR",
  finalState: "FAILED",
  dlrState: 5,
  errCode: "0x0000000B",
  finalAt: "2026-08-15T09:02:11.000Z",
  tlvs: '{"0x1400":"resolved"}',
  tlvsReceived: '{"0x1400":"asked"}',
  tlvsSent: '{"0x1400":"onwire"}',
  body: "Your code is 4471",
};

const projected = () => projectForCustomer(fullRow as unknown as Record<string, unknown>);

test("a column fetched on demand is absent rather than empty when it was not fetched", () => {
  //tlvsReceived is unbounded TEXT and only selected when the chooser asks for it, so its absence is
  //normal. It must stay absent rather than arriving as null: "not fetched" and "the customer sent
  //none" are different answers, and the query layer keeps them apart for that reason
  const notFetched = { ...(fullRow as unknown as Record<string, unknown>) };
  delete notFetched.tlvsReceived;

  assert.ok(!("tlvsReceived" in projectForCustomer(notFetched)));
});

test("every customer column can still read its value after projection", () => {
  //THE regression. A column whose id differs from its field is dropped by an id-keyed projection,
  //and the symptom is not an error -- it is a confident wrong answer in a table
  const row = projected() as unknown as CdrRow;

  for (const column of CUSTOMER_CDR_COLUMNS) {
    assert.notEqual(
      column.from(row),
      undefined,
      `column '${column.id}' reads a field the projection did not send`
    );
  }
});

test("the outcome survives, by name, and is the one the gateway wrote", () => {
  //named separately from the sweep above because this is the field that was actually lost, and a
  //sweep that starts passing for an unrelated reason should not take this with it
  const row = projected();

  assert.equal(row.finalState, "FAILED");
  assert.notEqual(row.finalState, undefined, "a customer saw 'Awaiting receipt' on a failed message");
});

test("our buy side never leaves the handler", () => {
  const row = projected();

  for (const forbidden of [
    "cost", "costRate", "costUnits", "costRuleId",
    "margin", "marginPct", "marginStatus",
    "vendor", "inGateway", "priceRuleId", "tlvs",
  ]) {
    assert.ok(!(forbidden in row), `${forbidden} reached the customer`);
  }
});

test("a customer sees the TLVs they sent, and neither of the other two sets", () => {
  //the resolved set carries our account defaults and approved sender IDs; the sent set carries
  //which tags our vendor registered. Both are ours. Only the customer's own submission is theirs
  const row = projectForCustomer({
    ...(fullRow as unknown as Record<string, unknown>),
    tlvsReceived: '{"0x1400":"what-they-sent"}',
    tlvsSent: '{"0x1400":"what-the-vendor-carried"}',
    body: "Your code is 4471",
  });

  assert.equal(row.tlvsReceived, '{"0x1400":"what-they-sent"}');
  assert.ok(!("tlvs" in row), "the resolved set is ours, not theirs");
  assert.ok(!("tlvsSent" in row), "the sent set discloses our vendor's tag registrations");
  //but their own message comes back whole. The allow-list is not "hide everything": it is "theirs
  //yes, ours no", and the body is the clearest case of theirs
  assert.equal(row.body, "Your code is 4471");
});

test("the export allow-list agrees with the projection about the three TLV sets", () => {
  //two independent gates, and they have to say the same thing: the CSV is the more damaging leak
  //because it lands in a file somebody keeps
  assert.ok(allowedForCustomer("tlvsReceived"));
  assert.ok(!allowedForCustomer("tlvs"));
  assert.ok(!allowedForCustomer("tlvsSent"));
  assert.ok(allowedForCustomer("body"), "a customer may read back what they sent");
});

test("the internal row id is not published", () => {
  //a BIGINT from a shared sequence: handing it to every customer discloses total platform volume
  //and its rate of change. The table keys on the message id instead
  assert.ok(!("id" in projected()));
});

test("a field the row gains upstream is absent until somebody allows it", () => {
  //the reason this is an allow-list. A new column on cdr_submit must not appear here by default
  const withNewField = { ...fullRow, supplierReference: "leak-me" } as unknown as Record<string, unknown>;

  assert.ok(!("supplierReference" in projectForCustomer(withNewField)));
});

test("a missing field is omitted rather than sent as undefined", () => {
  //`finalAt` is absent on a message with no receipt yet. An explicit undefined would serialise to
  //nothing over JSON anyway, but the shapes should not differ
  const pending = { ...fullRow };
  delete (pending as Partial<CdrRow>).finalAt;

  assert.ok(!("finalAt" in projectForCustomer(pending as unknown as Record<string, unknown>)));
});

test("the field list and the column list describe the same allow-list", () => {
  assert.equal(CUSTOMER_CDR_FIELDS.length, CUSTOMER_CDR_COLUMNS.length);
  //allowedForCustomer answers about COLUMN IDS -- it is what the export route validates against,
  //and 'outcome' is a legitimate thing to ask for there
  assert.ok(allowedForCustomer("outcome"));
  assert.ok(!allowedForCustomer("cost"));
});
