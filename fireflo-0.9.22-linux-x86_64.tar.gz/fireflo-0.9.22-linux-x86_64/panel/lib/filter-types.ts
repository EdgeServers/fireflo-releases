import type { ConditionInput } from "@/lib/rate-types";

/**
 * A named, reusable set of conditions.
 *
 * <p>Zero database imports — see the note at the top of `rate-types.ts` for what happens otherwise.
 *
 * <h2>What a filter actually is to the gateway</h2>
 *
 * <p><strong>A load-time expansion, not a runtime indirection.</strong> `FilterLibrary` says it
 * outright: a filter expands into exactly the conditions it holds, which are then appended to the
 * conditions of every rule referencing it. So a rule's real test is
 * `its own conditions AND every referenced filter's conditions` — filters narrow a rule, they never
 * replace or loosen it.
 *
 * <p><strong>Disabling one deletes rules rather than widening them.</strong>
 * `FilterLibrary.conditionsFor` returns null for a disabled filter, and both `DbRateLoader` and
 * `DbRoutingLoader` respond by skipping the rule entirely. So switching a filter off silently
 * removes every rule that uses it from the running snapshot, and that traffic falls through to
 * whatever matches next — a different price, or a different vendor. It is the most dangerous
 * control on the page and the interface has to say so with a count.
 */

export interface Filter {
  /** The primary key, compared by value from every referencing rule. */
  name: string;
  label: string | null;
  enabled: boolean;
  conditions: ConditionInput[];
  /**
   * Rules referencing this filter — rate rules and routing rules together.
   *
   * <p>Both, deliberately. A count that only looked at pricing would under-report what disabling
   * this breaks, and routing rules are the half where the consequence is "messages stop being sent"
   * rather than "messages are priced differently".
   */
  usedBy: { rates: number; routes: number };
  updatedAt: string | null;
}

export interface FilterInput {
  name: string;
  label?: string | null;
  enabled: boolean;
  conditions: ConditionInput[];
}

/** Total references, which is the number that matters when disabling or deleting. */
export function usedByTotal(filter: Filter): number {
  return filter.usedBy.rates + filter.usedBy.routes;
}

/**
 * The name is a primary key matched by value from `app_rate_rule_filter` and
 * `app_route_rule_filter`, so it is exact — the same reasoning as an account id or a product name.
 */
export function validateFilter(input: FilterInput): string | null {
  const name = input.name ?? "";
  if (!name.trim()) {
    return "A filter needs a name. It is what rules reference it by.";
  }
  if (name !== name.trim()) {
    return `'${name}' has a space at one end. Filter names are matched exactly and a trailing space `
      + "is invisible everywhere it is shown, so no rule would ever resolve it.";
  }
  for (const condition of input.conditions) {
    if (!condition.field.trim()) {
      return "Every condition needs a field. An empty one would be applied to nothing.";
    }
  }
  //not an error: an empty filter saves and loads, which is what lets one be built up a condition at
  //a time. What it does to the running snapshot is another matter -- see `emptyFilterWarning`
  return null;
}

/**
 * Said out loud rather than blocked, because an empty filter is legal while one is being built up.
 *
 * <p>It is worth naming because the gateway's answer to an empty filter is the opposite of the
 * intuitive one. `DbFilterLoader` adds a filter with no conditions to the *disabled* set — the
 * comment there is explicit that it refuses one rather than let it widen a rule downstream — and
 * both `DbRateLoader` and `DbRoutingLoader` skip every rule referencing a disabled filter. So an
 * empty filter deletes rules from the running snapshot; it does not loosen them. Same consequence as
 * switching a filter off, which is why this is worded like the disable warning rather than shrugged
 * off as harmless.
 */
export function emptyFilterWarning(input: FilterInput): string | null {
  return input.conditions.length
    ? null
    : "This filter has no conditions, so the gateway treats it as disabled: every rule referencing "
      + "it is skipped entirely rather than widened, and that traffic falls through to whatever "
      + "matches next — a different price, or a different vendor. Add a condition, or remove the "
      + "filter from those rules deliberately.";
}
