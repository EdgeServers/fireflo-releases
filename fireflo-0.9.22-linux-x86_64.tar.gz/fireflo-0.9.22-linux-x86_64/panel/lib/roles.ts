/**
 * Who a session belongs to, and the one predicate that decides it.
 *
 * <p><strong>A leaf module on purpose: it imports nothing.</strong> The decision it encodes is the
 * boundary between an operator and a customer, and a boundary worth testing has to be reachable
 * without dragging NextAuth, the database pool and half of Next.js in behind it. Keeping it free of
 * imports is what lets `roles.test.ts` run on Node's built-in runner with no test framework at all.
 */

/**
 * Stamped only by the operator provider in `lib/auth.ts`.
 *
 * <p>The customer portal runs a separate NextAuth instance on its own cookie and cannot mint this.
 */
export const OPERATOR_ROLE = "operator";

/** Stamped only by the portal's instance in `lib/mis-auth.ts`. */
export const CUSTOMER_ROLE = "customer";

/** As much of a session as the decision needs. */
export interface RoleBearing {
  user?: { name?: string | null; role?: string | null } | null;
}

/**
 * Whether this session may reach the control routes.
 *
 * <p>This used to be "does the session have a name", which was right while an operator was the only
 * identity the application could issue. The customer portal ended that: a customer holds a real,
 * signed, valid session, and under a presence check it would have opened every control route --
 * margin, vendor names, every account's messages, credential editing.
 *
 * <p>So it is an equality against {@link OPERATOR_ROLE} and never a truthiness test on the role. A
 * truthy check would admit any future role somebody adds without thinking about this line.
 */
export function isOperatorSession(session: RoleBearing | null | undefined): boolean {
  return !!session?.user?.name && session.user.role === OPERATOR_ROLE;
}
