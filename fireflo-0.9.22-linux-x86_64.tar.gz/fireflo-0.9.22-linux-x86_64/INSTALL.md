# Installing FireFlo 0.9.22

Full documentation: https://docs.fireflo.au/platform/install/getting-fireflo

## Before you install

You should have verified the download already. If you have not:

    sha256sum -c SHA256SUMS
    gpg --verify SHA256SUMS.asc SHA256SUMS

The checksum proves the file arrived whole. Only the signature proves it came
from us -- anyone able to replace the tarball can replace the checksum beside
it. If your release came with no signature, ask before installing it on
anything that will carry customer traffic.

Read MANIFEST. It names the version, the commit and the platform this binary
was compiled for. It will not run on another architecture.

## Install

    ./scripts/fireflo-install check
    sudo ./scripts/fireflo-install install --from ./gateway

The first changes nothing and reports whether this host has what it needs. The
second asks for what it needs, prints every decision before acting, and waits.

**No Java is required.** The gateway carries its own runtime, and so do the
operator commands -- 'fireflo db migrate', 'fireflo license activate' and the
rest all run from the same executable.

## Activate the licence

    FIREFLO_LICENSE_KEY=<your-licence-key> scripts/fireflo license activate

The key goes in the environment and never on the command line, so it does not
land in your shell history or in 'ps'.

An unlicensed gateway keeps sending. What a lapsed licence stops is picking up
configuration changes -- see the licensing page on the documentation site.


## The control panel

The panel ships as source at 'panel/' and is built on this host. Install it
AFTER the gateway: the gateway owns the database schema and the panel only
reads and writes rows in it.

    sudo ./panel/scripts/fireflo-panel-install check
    sudo ./panel/scripts/fireflo-panel-install install --gateway-conf-dir <conf-dir>

Run it from 'panel/scripts/', not from 'scripts/'. It locates the panel source
relative to itself, so it has to be the copy that sits inside the panel tree.

There is no '--from': the source is the directory it lives in. To upgrade later:

    sudo ./panel/scripts/fireflo-panel-install update

Add '--tenant NAME' to both commands on a host running more than one instance,
matching the name you gave the gateway.

## The REST panel

The panel your CUSTOMERS sign in to -- campaigns, contacts, sender IDs,
templates and message logs. Optional: the gateway and the control panel do not
need it.

It talks to the gateway over the REST API only, with the customer's own
credentials, and keeps its own database. Both have to be given to it, and
neither has a safe default:

    sudo ./rest-panel/scripts/fireflo-rest-panel-install install \
        --db-url postgres://user:pass@host/its_own_database \
        --gateway-url http://127.0.0.1:8080

Its OWN database, not the gateway's: it creates its tables at runtime, while the
gateway's schema is version-checked, and a migration meeting tables it does not
know about is a bad afternoon.

Run it from 'rest-panel/scripts/' for the same reason as the control panel's --
it finds its source relative to itself.

## Upgrading

The next release arrives the same way. Verify it, unpack it, then:

    sudo ./scripts/fireflo-install update --from ./gateway

'update' never touches your configuration directory, and keeps the previous
version so 'fireflo-install rollback' is one command.

## Help

support@fireflo.au
