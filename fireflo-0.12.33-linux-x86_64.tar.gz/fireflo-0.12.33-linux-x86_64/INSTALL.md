# Installing FireFlo 0.12.33

Full documentation: https://docs.fireflo.au/platform/install/getting-fireflo

## Before you install

You should have verified the download already. If you have not:

    sha256sum -c SHA256SUMS
    gpg --verify SHA256SUMS.asc SHA256SUMS

The checksum proves the file arrived whole. Only the signature proves it came
from us -- anyone able to replace the tarball can replace the checksum beside
it. If your release came with no signature, ask before installing it on
anything that will carry customer traffic.

Read MANIFEST. It names the version, the commit and the platform this binary
was compiled for. It will not run on another architecture.

## Install

    ./scripts/fireflo-install check
    sudo ./scripts/fireflo-install install --from ./gateway

The first changes nothing and reports whether this host has what it needs. The
second asks for what it needs, prints every decision before acting, and waits.

**No Java is required.** The gateway carries its own runtime, and so do the
operator commands -- 'fireflo db migrate', 'fireflo license activate' and the
rest all run from the same executable. (The optional SMPPSim test SMSC is the
one exception: it brings the distribution's Java runtime with it.)

## Activate the licence

    FIREFLO_LICENSE_KEY=<your-licence-key> scripts/fireflo license activate

The key goes in the environment and never on the command line, so it does not
land in your shell history or in 'ps'.

An unlicensed gateway keeps sending. What a lapsed licence stops is picking up
configuration changes -- see the licensing page on the documentation site.


## Trying it with SMPPSim

To see a message go all the way through on a fresh install -- routed, priced,
delivered and debited -- add SMPPSim, a test SMSC included at smppsim/:

    sudo ./scripts/fireflo-install install --from ./gateway \
        --config-source db --bootstrap --with-smppsim --balance ...

It runs as its own service, bootstrap routes MESSAGE to it, and the install
ends with 'fireflo selftest', which you can run again at any time. SMPPSim
accepts everything and invents delivery receipts: replace it with a real
vendor before real traffic. It is third-party GPL-2 software (smppsim/LICENSE)
and needs a Java runtime, which the installer adds for it alone.

## The control panel

The panel ships as source at 'panel/' and is built on this host. Install it
AFTER the gateway: the gateway owns the database schema and the panel only
reads and writes rows in it.

    sudo ./panel/scripts/fireflo-panel-install check
    sudo ./panel/scripts/fireflo-panel-install install --gateway-conf-dir <conf-dir>

Run it from 'panel/scripts/', not from 'scripts/'. It locates the panel source
relative to itself, so it has to be the copy that sits inside the panel tree.

There is no '--from': the source is the directory it lives in. To upgrade later:

    sudo ./panel/scripts/fireflo-panel-install update

Add '--tenant NAME' to both commands on a host running more than one instance,
matching the name you gave the gateway.


## Upgrading

The next release arrives the same way. Verify it, unpack it, then:

    sudo ./scripts/fireflo-install update --from ./gateway

'update' never touches your configuration directory, and keeps the previous
version so 'fireflo-install rollback' is one command.

## Help

support@fireflo.au
