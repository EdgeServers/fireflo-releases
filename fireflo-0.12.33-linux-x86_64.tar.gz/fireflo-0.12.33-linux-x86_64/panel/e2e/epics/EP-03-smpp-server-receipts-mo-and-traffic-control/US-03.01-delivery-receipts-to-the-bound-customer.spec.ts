/**
 * EP-03 SMPP Server — Receipts, MO & Traffic Control
 * US-03.01 Delivery receipts to the bound customer
 *
 * EdgeSmsc A answers every accepted submit with a receipt (`dlr <STATE> <err> <delayMs>`); the ESME
 * fixture acknowledges every deliver_sm and keeps the parsed receipt.
 */
import { expect, test } from "../../fixtures";
import { edgeA } from "../../fixtures/edgesmsc";
import { awaitGatewayAdopts } from "../../fixtures/gateway";
import { VENDORS } from "../../fixtures/gateway-rig";
import { BASELINE } from "../../fixtures/seed";
import { gatewayLog } from "../../fixtures/trace";
import { bindA, sendAndRecord, waitFinal } from "../../support/flows/gateway";
import { setWorkerProperty } from "../../support/flows/submit";
import { tc } from "../../support/tc";
import { LOAD } from "../../support/tags";

const A = BASELINE.logins.a;

test.describe("SC-03.01.01 Receipt round trip DELIVRD", () => {
  test(...tc("TC-03.01.01-P01", "Receipt arrives with the gateway id and DELIVRD", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    await edgeA().baseline();
    const esme = await bindA();
    try {
      const { messageId } = await sendAndRecord(esme, db, { registeredDelivery: 1, source: "QATEST", dest: "61400000777" });
      const r = await esme.waitReceipt((x) => x.text.includes(messageId) || x.receiptedMessageId === messageId, 30_000);
      expect(Number(r.pdu.esm_class) & 0x04).toBe(0x04);
      expect(r.fields.stat).toBe("DELIVRD");
      expect(r.fields.err).toBe("000");
      expect(r.source, "source/dest reversed against the submit").toBe("61400000777");
      expect(r.dest).toBe("QATEST");
      tcx.note(`deliver_sm esm_class 0x${Number(r.pdu.esm_class).toString(16)} "${r.text.slice(0, 90)}" from ${r.source} to ${r.dest}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-03.01.01-P02", "cdr_final written once", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    await edgeA().baseline();
    const esme = await bindA();
    try {
      const { messageId } = await sendAndRecord(esme, db, { registeredDelivery: 1 });
      const f = await waitFinal(db, messageId);
      await new Promise((r) => setTimeout(r, 1500));
      expect(await db.count("cdr_final", "gateway_msg_id = $1", [messageId])).toBe(1);
      expect(f.final_state).toBe("DELIVERED");
      expect(Number(f.dlr_state)).toBe(2);
      expect(f.vendor_err_code === null || /^0+$/.test(f.vendor_err_code)).toBe(true);
      tcx.note(`1 row: final_state=${f.final_state} dlr_state=${f.dlr_state} vendor_err_code=${f.vendor_err_code}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-03.01.01-P03", "Receipt count equals accepted count at load", { requires: ["gateway", "edgesmsc"], tags: [LOAD] }), async ({ db, env, tcx }) => {
    test.setTimeout(300_000);
    const edge = edgeA();
    await edge.baseline();
    const n = Math.max(200, Math.round(5000 * env.loadScale));
    // the anti-vacuity half first: nothing asked, nothing received, nothing expired
    const quiet = await bindA();
    const off = await quiet.submitMany(50, { registeredDelivery: 0 }, { tps: 250, window: 50 });
    await new Promise((r) => setTimeout(r, 4000));
    expect(quiet.receipts.length, "--receipts off: zero receipts").toBe(0);
    await quiet.unbind();
    const esme = await bindA();
    try {
      const run = await esme.submitMany(n, { registeredDelivery: 1 }, { tps: 250, window: 100 });
      await expect.poll(() => esme.receipts.length, { timeout: 180_000 }).toBe(run.accepted);
      const expired = await db.count("cdr_final f JOIN cdr_submit s USING (gateway_msg_id)", "s.system_id = $1 AND f.final_state = 'EXPIRED' AND s.submitted_at >= now() - interval '10 minutes'", [A.systemId]);
      expect(expired).toBe(0);
      tcx.note(`accepted ${run.accepted}/${n}, receipts ${esme.receipts.length}, EXPIRED 0 (rd=0 control: ${off.accepted} sent, 0 receipts)`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-03.01.01-P04", "receipt.acked recorded at events=all", { requires: ["gateway", "edgesmsc"] }), async ({ db, seed, tcx }) => {
    await seed.config("smsg.cdr.events", "all");
    await edgeA().baseline();
    const esme = await bindA();
    try {
      const { messageId } = await sendAndRecord(esme, db, { registeredDelivery: 1 });
      await esme.waitReceipt((x) => x.text.includes(messageId) || x.receiptedMessageId === messageId, 30_000);
      const kinds = (await db.waitForRow<{ kinds: string[] }>(
        "SELECT array_agg(kind ORDER BY id) AS kinds FROM cdr_event WHERE gateway_msg_id = $1 HAVING 'receipt.acked' = ANY(array_agg(kind))", [messageId], { timeoutMs: 30_000 })).kinds;
      expect(kinds.indexOf("receipt.sent")).toBeGreaterThanOrEqual(0);
      expect(kinds.indexOf("receipt.acked")).toBeGreaterThan(kinds.indexOf("receipt.sent"));
      const acked = await db.one<{ status: number | null }>("SELECT status FROM cdr_event WHERE gateway_msg_id = $1 AND kind = 'receipt.acked'", [messageId]);
      expect(Number(acked.status)).toBe(0);
      tcx.note(`cdr_event: ${kinds.join(" → ")}; receipt.acked status ${acked.status}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-03.01.01-P05", "flag.reverseDlrSrcDst=true on the listener restores the old receipt order", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    await edgeA().baseline();
    const esme = await bindA();
    /** One message QATEST → 61400000777 and the receipt's source → dest. */
    const roundTrip = async () => {
      const { messageId } = await sendAndRecord(esme, db, { registeredDelivery: 1, source: "QATEST", dest: "61400000777" });
      const r = await esme.waitReceipt((x) => x.text.includes(messageId) || x.receiptedMessageId === messageId, 30_000);
      expect(r.fields.stat).toBe("DELIVRD");
      return `${r.source} → ${r.dest}`;
    };
    try {
      let flagged = "";
      // the listener reads the key when the poll lands, so the probe is the receipt itself
      const restore = await setWorkerProperty(db, "smpp", "flag.reverseDlrSrcDst", "true",
        async () => (flagged = await roundTrip()) === "QATEST → 61400000777");
      expect(flagged, "flag on: the order sent until 0.12.33").toBe("QATEST → 61400000777");
      await restore();
      let standard = "";
      await awaitGatewayAdopts(async () => (standard = await roundTrip()) === "61400000777 → QATEST", { timeoutMs: 40_000 });
      expect(standard, "flag removed: back to the handset first").toBe("61400000777 → QATEST");
      tcx.note(`flag on: ${flagged}; removed: ${standard}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-03.01.01-N01", "No receipt when not requested", { requires: ["gateway", "edgesmsc", "trace"] }), async ({ db, seed, tcx }) => {
    await seed.config("smsg.cdr.events", "problems");
    await seed.config("message.trace.mode", "all");
    await edgeA().baseline();
    const mark = gatewayLog.mark();
    const esme = await bindA();
    try {
      const { messageId } = await sendAndRecord(esme, db, { registeredDelivery: 0 });
      await waitFinal(db, messageId);
      const line = await gatewayLog.waitFor(/message\.dlr\.suppressed[^\n]*/, mark);
      expect(line.input).toMatch(/0x00|registered_delivery=0/);
      await db.waitForRow("SELECT 1 FROM cdr_event WHERE gateway_msg_id = $1 AND kind = 'receipt.suppressed'", [messageId], { timeoutMs: 20_000 });
      await new Promise((r) => setTimeout(r, 2000));
      expect(esme.receipts.length).toBe(0);
      tcx.note(`no deliver_sm; ${line[0].slice(0, 100)}; cdr_event receipt.suppressed`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-03.01.01-N02", "registered_delivery=0x02 (failure only) suppresses a DELIVRD", { requires: ["gateway", "edgesmsc", "trace"] }), async ({ db, seed, tcx }) => {
    await seed.config("message.trace.mode", "all");
    await edgeA().baseline();
    const mark = gatewayLog.mark();
    const esme = await bindA();
    try {
      const { messageId } = await sendAndRecord(esme, db, { registeredDelivery: 0x02 });
      await waitFinal(db, messageId);
      const line = await gatewayLog.waitFor(/message\.dlr\.suppressed[^\n]*/, mark);
      expect(line.input).toMatch(/0x02/);
      await new Promise((r) => setTimeout(r, 2000));
      expect(esme.receipts.length).toBe(0);
      tcx.note(`DELIVRD withheld under rd=0x02; ${line[0].slice(0, 100)}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-03.01.01-N03", "registered_delivery=0x02 delivers an UNDELIV", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const edge = edgeA();
    await edge.baseline();
    await edge.dlr("UNDELIV", "001", 500);
    const esme = await bindA();
    try {
      const { messageId } = await sendAndRecord(esme, db, { registeredDelivery: 0x02 });
      const r = await esme.waitReceipt((x) => x.text.includes(messageId) || x.receiptedMessageId === messageId, 30_000);
      expect(r.fields.stat).toBe("UNDELIV");
      tcx.note(`rd=0x02 + vendor UNDELIV → receipt ${r.fields.stat} err:${r.fields.err}`);
    } finally {
      await esme.unbind();
      await edge.baseline();
    }
  });

  test(...tc("TC-03.01.01-N04", "Customer never answers deliver_sm -> receipt.unacked", { requires: ["gateway", "edgesmsc"] }), async ({ db, seed, tcx }) => {
    test.setTimeout(180_000);
    await seed.config("smsg.cdr.events", "problems");
    await edgeA().baseline();
    const esme = await bindA();
    // an ESME that takes the deliver_sm and never answers it
    esme.session.removeAllListeners("deliver_sm");
    let seen = 0;
    esme.session.on("deliver_sm", () => { seen++; });
    try {
      const { messageId } = await sendAndRecord(esme, db, { registeredDelivery: 1 });
      await expect.poll(() => seen, { timeout: 30_000 }).toBeGreaterThan(0);
      const row = await db.waitForRow<{ kind: string }>("SELECT kind FROM cdr_event WHERE gateway_msg_id = $1 AND kind = 'receipt.unacked'", [messageId], { timeoutMs: 120_000 });
      expect(await db.count("cdr_event", "gateway_msg_id = $1 AND kind = 'receipt.acked'", [messageId])).toBe(0);
      tcx.note(`deliver_sm received ${seen}× and never answered; cdr_event ${row.kind} after the expiry window; no receipt.acked`);
    } finally {
      await esme.destroy();
    }
  });
});

test.describe("SC-03.01.02 Vendor error code translation", () => {
  const V = VENDORS.a;

  test(...tc("TC-03.01.02-P01", "Unmapped code collapses to 018 by default", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const restoreMap = await setWorkerProperty(db, V, "dlr.errcodes", null);
    const restorePass = await setWorkerProperty(db, V, "dlr.errcodes.passthrough", "false");
    const edge = edgeA();
    await edge.baseline();
    await edge.dlr("UNDELIV", "630", 300);
    const esme = await bindA();
    try {
      const { messageId } = await sendAndRecord(esme, db, { registeredDelivery: 1 });
      const r = await esme.waitReceipt((x) => x.text.includes(messageId) || x.receiptedMessageId === messageId, 30_000);
      const f = await waitFinal(db, messageId);
      expect(r.fields.err).toBe("018");
      expect(f.err_code).toBe("18");
      expect(f.vendor_err_code).toBe("630");
      tcx.note(`receipt err:${r.fields.err}; cdr_final err_code=${f.err_code} vendor_err_code=${f.vendor_err_code}`);
    } finally {
      await esme.unbind();
      await edge.baseline();
      await restorePass(); await restoreMap();
    }
  });

  test(...tc("TC-03.01.02-P02", "Mapped code 630_16 becomes 016", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const restoreMap = await setWorkerProperty(db, V, "dlr.errcodes", "630_16");
    const edge = edgeA();
    await edge.baseline();
    await edge.dlr("UNDELIV", "630", 300);
    const esme = await bindA();
    try {
      const { messageId } = await sendAndRecord(esme, db, { registeredDelivery: 1 });
      const r = await esme.waitReceipt((x) => x.text.includes(messageId) || x.receiptedMessageId === messageId, 30_000);
      const f = await waitFinal(db, messageId);
      expect(r.fields.err).toBe("016");
      expect(f.vendor_err_code).toBe("630");
      tcx.note(`receipt err:${r.fields.err}; vendor_err_code=${f.vendor_err_code}`);
    } finally {
      await esme.unbind();
      await edge.baseline();
      await restoreMap();
    }
  });

  test(...tc("TC-03.01.02-P03", "Passthrough forwards the raw code", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const restoreMap = await setWorkerProperty(db, V, "dlr.errcodes", null);
    const restorePass = await setWorkerProperty(db, V, "dlr.errcodes.passthrough", "true");
    const edge = edgeA();
    await edge.baseline();
    await edge.dlr("UNDELIV", "630", 300);
    const esme = await bindA();
    try {
      const { messageId } = await sendAndRecord(esme, db, { registeredDelivery: 1 });
      const r = await esme.waitReceipt((x) => x.text.includes(messageId) || x.receiptedMessageId === messageId, 30_000);
      expect(r.fields.err).toBe("630");
      tcx.note(`passthrough: receipt err:${r.fields.err}`);
    } finally {
      await esme.unbind();
      await edge.baseline();
      await restorePass(); await restoreMap();
    }
  });

  test(...tc("TC-03.01.02-N01", "Non-numeric carrier code does not throw", { requires: ["gateway", "edgesmsc", "trace"] }), async ({ db, tcx }) => {
    const edge = edgeA();
    await edge.baseline();
    await edge.dlr("UNDELIV", "N/A", 300);
    const mark = gatewayLog.mark();
    const esme = await bindA();
    try {
      const { messageId } = await sendAndRecord(esme, db, { registeredDelivery: 1 });
      const r = await esme.waitReceipt((x) => x.text.includes(messageId) || x.receiptedMessageId === messageId, 30_000);
      const f = await waitFinal(db, messageId);
      expect(gatewayLog.count(/NumberFormatException|Exception/, mark)).toBe(0);
      tcx.note(`receipt produced (err:${r.fields.err}); vendor_err_code=${f.vendor_err_code}; no exception logged`);
      expect(f.vendor_err_code).toBe("N/A");
    } finally {
      await esme.unbind();
      await edge.baseline();
    }
  });

  test(...tc("TC-03.01.02-N02", "vendor_err_code is never a copy of err_code", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const restoreMap = await setWorkerProperty(db, V, "dlr.errcodes", null);
    const restorePass = await setWorkerProperty(db, V, "dlr.errcodes.passthrough", "false");
    const edge = edgeA();
    await edge.baseline();
    await edge.dlr("UNDELIV", "630", 300);
    const esme = await bindA();
    try {
      const { messageId } = await sendAndRecord(esme, db, { registeredDelivery: 1 });
      const f = await waitFinal(db, messageId);
      expect(f.err_code).toBe("18");
      expect(f.vendor_err_code).toBe("630");
      expect(f.err_code).not.toBe(f.vendor_err_code);
      tcx.note(`err_code=${f.err_code} ≠ vendor_err_code=${f.vendor_err_code}`);
    } finally {
      await esme.unbind();
      await edge.baseline();
      await restorePass(); await restoreMap();
    }
  });
});
