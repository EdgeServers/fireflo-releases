"use client";
import { useMemo, useState } from "react";
import { Lock, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Segmented } from "@/components/ui/segmented";
import { Select } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { SettingsRow, SettingsRows } from "@/components/ui/settings-row";
import { ConditionEditor } from "./ConditionEditor";
import { FilterPicker } from "./FilterPicker";
import { WarningNote } from "./FormNotices";
import { GuidedConditionRow, useGuidedOptions } from "./GuidedConditionRow";
import { blankGuided, fromConditions, GUIDED_KINDS, toConditions, type GuidedField, type GuidedKind } from "@/lib/filter-guide";
import type { Filter } from "@/lib/filter-types";
import { conditionWarnings, type ConditionInput } from "@/lib/rate-types";
import { describeRuleWhen, targetKindLabel, type TargetOptionGroup } from "@/lib/routing-guide";
import { describeRouteRule, type RouteRule, type TargetFunction, type TargetWorker } from "@/lib/routing-types";

/**
 * One routing rule, in words: where it sends, when, and what happens after.
 *
 * <p>Replaces the table form's wall of inputs, where every rule showed a target box, a note, Copy,
 * Active, arrows, a filter picker and the raw condition editor at once. The conditions are the
 * filter wizard's guided fields, so a destination prefix is entered the same way on both pages; a
 * rule they cannot express -- a receipt rule's `type == 18`, an `ingateway` -- opens in the raw
 * editor instead, and any rule can switch to it.
 *
 * <p>Done stages the rule into the table. Nothing reaches the gateway until the table's Save.
 */
export function RouteRuleDialog({
  rule,
  position,
  tableName,
  targetFunction,
  targets,
  tableNames,
  workers,
  groupNames,
  filters,
  belowCatchAll,
  onDone,
  onDelete,
  onClose,
  locked,
}: {
  /** The rule to edit, or a draft. `id` null for a rule not saved yet. */
  rule: RouteRule;
  /** "Rule 3", or null for a new rule. */
  position: number | null;
  tableName: string;
  targetFunction: TargetFunction;
  targets: TargetOptionGroup[];
  tableNames: readonly string[];
  workers: readonly TargetWorker[];
  groupNames: readonly string[];
  filters: Filter[];
  /** A rule above this one already takes every message, so this one is never reached. */
  belowCatchAll: boolean;
  onDone: (rule: RouteRule) => void;
  onDelete: (() => void) | null;
  onClose: () => void;
  /**
   * Why this rule can't be changed, for a system rule the panel keeps itself. The dialog then shows
   * the rule read-only, with nothing to delete or save.
   */
  locked?: string;
}) {
  const options = useGuidedOptions();
  const guidedStart = fromConditions(rule.conditions);
  const [target, setTarget] = useState(rule.target);
  const [only, setOnly] = useState(rule.conditions.length > 0 || rule.filters.length > 0);
  const [fields, setFields] = useState<GuidedField[]>(
    guidedStart?.length ? guidedStart : [blankGuided("destination")]
  );
  const [advanced, setAdvanced] = useState(guidedStart === null);
  const [raw, setRaw] = useState<ConditionInput[]>(rule.conditions.map((c) => ({ ...c })));
  const [chosenFilters, setChosenFilters] = useState<string[]>(rule.filters);
  const [copied, setCopied] = useState(rule.copied);
  const [label, setLabel] = useState(rule.label ?? "");
  const [enabled, setEnabled] = useState(rule.enabled);

  const conditions = useMemo(
    () => (!only ? [] : advanced ? raw : toConditions(fields)),
    [only, advanced, raw, fields]
  );
  const result: RouteRule = {
    ...rule,
    target: target.trim(),
    conditions,
    filters: only ? chosenFilters : [],
    copied: targetFunction === "NORMAL" && copied,
    label: label.trim() || null,
    enabled,
  };
  const kind = targetKindLabel(result.target, tableNames, workers, groupNames);
  const knownTarget = targets.some((g) => g.options.some((o) => o.value === rule.target));
  const narrowed = result.conditions.length > 0 || result.filters.length > 0;
  const backToGuided = advanced ? fromConditions(raw) : null;
  const picked = new Set(fields.map((f) => f.kind));
  const warnings = [
    ...conditionWarnings(conditions),
    only && !narrowed ? "Only when… is chosen but nothing is filled in yet, so this would match every message." : null,
  ].filter((w): w is string => w != null);

  function update(k: GuidedKind, patch: Partial<GuidedField>) {
    setFields((cur) => cur.map((f) => (f.kind === k ? { ...f, ...patch } : f)));
  }
  function toAdvanced() {
    setRaw(conditions.map((c) => ({ ...c })));
    setAdvanced(true);
  }

  const title = position === null ? `New rule in ${tableName}`
    : `Rule ${position} in ${tableName}${locked ? " · system" : ""}`;

  return (
    <Dialog open onClose={onClose} title={title} className="max-w-2xl">
      <div className="space-y-4">
        {locked && (
          <p className="flex items-start gap-2 rounded-lg border border-border bg-muted/40 px-4 py-3 text-sm">
            <Lock className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" aria-hidden="true" />
            <span>{locked}</span>
          </p>
        )}
        {/* a disabled fieldset disables every control inside it, the guided editor's included */}
        <SettingsRows as="fieldset" disabled={Boolean(locked)}>
        <SettingsRow label="Send to" htmlFor="rr-target">
          <Select id="rr-target" value={target} onChange={(e) => setTarget(e.target.value)}>
            <option value="">Choose where it goes…</option>
            {targets.map((g) => (
              <optgroup key={g.label} label={g.label}>
                {g.options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
              </optgroup>
            ))}
            {rule.target && !knownTarget && <option value={rule.target}>{rule.target} (not recognised)</option>}
          </Select>
          {result.target && (
            <div className="mt-1.5 flex flex-wrap items-center gap-2">
              <Badge variant={kind.kind === "disabled" || kind.kind === "unknown" ? "warning" : "outline"}>{kind.label}</Badge>
              {kind.kind === "table" && targetFunction === "LCR" && (
                <span className="text-xs text-warning">A cheapest-vendor table skips rules that send into a table.</span>
              )}
            </div>
          )}
        </SettingsRow>

        <SettingsRow label="When" wide>
          <Segmented<"every" | "only">
            label="When this rule applies"
            value={only ? "only" : "every"}
            onChange={(v) => setOnly(v === "only")}
            options={[{ value: "every", label: "Every message" }, { value: "only", label: "Only when…" }]}
          />
          {only && (
            <div className="mt-3 space-y-3">
              {advanced ? (
                <div className="space-y-2">
                  <ConditionEditor conditions={raw} onChange={setRaw} filterCount={chosenFilters.length} />
                  <p className="text-xs text-muted-foreground">
                    The gateway&apos;s own fields and operators. Every condition must hold.{" "}
                    {backToGuided && (
                      <button type="button" className="text-primary hover:underline"
                        onClick={() => { setFields(backToGuided.length ? backToGuided : [blankGuided("destination")]); setAdvanced(false); }}>
                        Back to the guided fields
                      </button>
                    )}
                  </p>
                </div>
              ) : (
                <>
                  {fields.map((f) => (
                    <GuidedConditionRow key={f.kind} field={f} options={options} onChange={(p) => update(f.kind, p)}
                      onRemove={() => setFields((cur) => cur.filter((x) => x.kind !== f.kind))} />
                  ))}
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm">
                    <Select aria-label="Add a condition" value="" className="w-auto"
                      onChange={(e) => {
                        const k = e.target.value as GuidedKind;
                        if (k) setFields((cur) => [...cur, blankGuided(k)]);
                      }}>
                      <option value="">+ Add a condition</option>
                      {GUIDED_KINDS.filter((k) => !picked.has(k.id)).map((k) => <option key={k.id} value={k.id}>{k.label}</option>)}
                    </Select>
                    <button type="button" className="text-muted-foreground hover:text-foreground hover:underline" onClick={toAdvanced}>
                      Edit as conditions
                    </button>
                  </div>
                </>
              )}
              <FilterPicker chosen={chosenFilters} library={filters} onChange={setChosenFilters} />
            </div>
          )}
        </SettingsRow>

        {targetFunction === "NORMAL" && (
          <SettingsRow label="After a match">
            <Segmented<"stop" | "copy">
              label="After a match"
              value={copied ? "copy" : "stop"}
              onChange={(v) => setCopied(v === "copy")}
              options={[{ value: "stop", label: "Stop here" }, { value: "copy", label: "Copy and keep going" }]}
            />
            <p className="mt-1.5 text-xs text-muted-foreground">
              {copied
                ? "A copy goes to this target and the rules below still run."
                : "The message goes to this target and no rule below sees it."}
            </p>
          </SettingsRow>
        )}

        <SettingsRow label="Note" htmlFor="rr-note">
          <Input id="rr-note" value={label} placeholder="What this rule is for" onChange={(e) => setLabel(e.target.value)} />
          {label.startsWith("system:") && (
            <p className="mt-1.5 text-xs text-muted-foreground">
              A system: note marks a rule default routing wrote. Changing it moves the rule out of the system rules.
            </p>
          )}
        </SettingsRow>

        <SettingsRow label="Active" labelId="rr-active">
          <div className="flex items-center gap-3">
            <Switch checked={enabled} onChange={setEnabled} aria-labelledby="rr-active" />
            <span className="text-sm text-muted-foreground">{enabled ? "The gateway uses this rule." : "Skipped, as if it were not here."}</span>
          </div>
        </SettingsRow>

        </SettingsRows>

        <div className="rounded-lg border border-border bg-muted/40 px-4 py-3 text-sm">
          <span className="text-muted-foreground">Reads: </span>
          <span className="font-medium">
            {describeRuleWhen(result)}, {result.copied ? "copy to" : "send to"} {result.target || "…"}
          </span>
          {result.target && (
            <span className="block text-muted-foreground">{describeRouteRule(result, targetFunction, tableNames, workers)}</span>
          )}
        </div>

        {belowCatchAll && enabled && (
          <p className="rounded-lg border border-warning/40 bg-warning-soft/40 px-4 py-3 text-sm">
            A rule above already takes every message, so this rule is never reached. Move it above that rule.
          </p>
        )}
        <WarningNote warnings={warnings} />

        <div className="flex flex-wrap items-center gap-2 border-t border-border pt-4">
          {onDelete && !locked && (
            <Button type="button" variant="ghost" className="gap-1.5 text-destructive" onClick={onDelete}>
              <Trash2 className="h-4 w-4" aria-hidden="true" /> Remove rule
            </Button>
          )}
          <span className="mr-auto" />
          {locked ? (
            <Button type="button" onClick={onClose}>Close</Button>
          ) : (
            <>
              <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
              <Button type="button" disabled={!result.target} onClick={() => onDone(result)}>Done</Button>
            </>
          )}
        </div>
      </div>
    </Dialog>
  );
}

/** A label beside its control on a wide screen, above it on a phone. */
