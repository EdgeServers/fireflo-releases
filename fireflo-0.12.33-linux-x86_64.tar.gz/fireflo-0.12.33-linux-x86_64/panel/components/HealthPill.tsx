"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useMemo } from "react";
import { useHealth } from "./useHealth";
import { Sparkline } from "./Sparkline";
import { gatewayVerdict, vendorTpsHistory } from "@/lib/gateway-verdict";
import { cn } from "@/lib/utils";

const DOT: Record<string, string> = {
  success: "bg-success",
  warning: "bg-warning",
  destructive: "bg-destructive",
};

/**
 * The gateway in one glance, on every page: a dot, a word, and the outbound rate with its trend.
 *
 * <p>Replaces the heart icon that only linked to the health page. The link is still there -- the
 * whole pill is it -- but now it says something before it is clicked, which is what a thing in
 * the chrome is for. It reads the shared health poll, so it costs no extra request.
 */
export function HealthPill() {
  const pathname = usePathname();
  const { health, error, tpsHistory } = useHealth();
  const verdict = useMemo(() => gatewayVerdict(health, error), [health, error]);
  const trend = useMemo(
    () => (health ? vendorTpsHistory(tpsHistory, health.workers) : []),
    [tpsHistory, health]
  );
  const active = pathname.startsWith("/cp/health");

  return (
    <Link
      href="/cp/health"
      aria-label="Live health"
      aria-current={active ? "page" : undefined}
      title={verdict.detail}
      className={cn(
        "flex h-9 items-center gap-2 rounded-full border border-border py-1 pl-2.5 pr-3 text-xs transition-colors hover:bg-muted",
        active && "bg-muted"
      )}
    >
      <span className={cn("h-2 w-2 shrink-0 rounded-full", DOT[verdict.tone])} aria-hidden />
      <span className="font-medium">{verdict.label}</span>
      {verdict.tps != null && (
        <span className="hidden items-center gap-1.5 text-muted-foreground sm:inline-flex">
          {trend.filter((v) => v != null).length > 1 && (
            <Sparkline values={trend} className="h-3.5 w-11" />
          )}
          <span className="tabular-nums">{verdict.tps.toLocaleString()}/s</span>
        </span>
      )}
    </Link>
  );
}
