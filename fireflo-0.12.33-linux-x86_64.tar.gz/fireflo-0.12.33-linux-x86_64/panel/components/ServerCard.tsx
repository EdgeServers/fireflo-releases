"use client";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { CardActions, Figures, HealthStrip } from "./CardBits";
import type { HealthWorker } from "@/lib/health-types";
import type { WorkerVerdict } from "@/lib/worker-verdict";
import { KIND, type Worker } from "@/lib/worker-types";
import { formatTimestamp } from "@/lib/datetime";
import { PeakLine } from "./PeakLine";
import { useConfirmEnabled } from "./ConnectionStatus";

/**
 * One listener on the list: who is connected to it, and what it is holding.
 *
 * <p>The server twin of {@link VendorCard}. The figures mean the opposite thing by their number --
 * `connected` is customers bound in, `received` is what they sent us, and a held count is inbound
 * parked while Stop sending is on -- so the captions say so rather than reusing the vendor words.
 */
export function ServerCard({
  worker,
  live,
  verdict,
  busy,
  onEdit,
  onToggleEnabled,
}: {
  worker: Worker;
  live: HealthWorker | undefined;
  verdict: WorkerVerdict;
  busy: boolean;
  onEdit: () => void;
  onToggleEnabled: (enabled: boolean) => void;
}) {
  const confirmEnabled = useConfirmEnabled();
  const port = prop(worker, "srv.port");
  const host = prop(worker, "srv.public.host") || prop(worker, "srv.host");
  const where = [host, port].filter(Boolean).join(":") || (port && `port ${port}`);
  const bad = verdict.tone === "destructive";
  const ceiling = prop(worker, "srv.maxConnections");
  const settings = [
    worker.label,
    ceiling && `up to ${ceiling} connections`,
    prop(worker, "srv.maxConnectionsPerIP") && `${prop(worker, "srv.maxConnectionsPerIP")} per IP`,
    prop(worker, "srv.tls.enabled") === "true" && `TLS on ${prop(worker, "srv.tls.port") || "its port"}`,
  ].filter(Boolean).join(" · ");

  return (
    <Card className={bad ? "border-destructive" : !worker.enabled ? "opacity-70" : undefined}>
      <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
        <span
          aria-hidden
          className={`h-2 w-2 shrink-0 rounded-full ${bad ? "bg-destructive" : verdict.tone === "success" ? "bg-success" : verdict.tone === "warning" ? "bg-warning" : "bg-border"}`}
        />
        <Link href={`/cp/servers/${encodeURIComponent(worker.name)}`} className="text-sm font-medium hover:underline">
          {worker.name}
        </Link>
        {where && <span className="font-mono text-xs text-muted-foreground">{where}</span>}
        <Badge variant={verdict.tone}>{verdict.label}</Badge>
        <CardActions>
          <Button variant="outline" size="sm" onClick={onEdit}>Edit</Button>
          <Button
            variant="ghost"
            size="sm"
            disabled={busy}
            onClick={async () => {
              if (await confirmEnabled(worker.name, KIND.server, !worker.enabled)) {
                onToggleEnabled(!worker.enabled);
              }
            }}
          >
            {worker.enabled ? "Disable" : "Enable"}
          </Button>
        </CardActions>
      </CardHeader>
      <CardContent className="space-y-3 pt-3">
        <Figures
          figures={[
            { value: live?.bound ?? "—", label: ceiling ? `connected of ${ceiling}` : "connected" },
            { value: live?.submitted != null ? live.submitted.toLocaleString() : "—", label: "received" },
            { value: live?.held_inbound ?? "—", label: "held inbound", tone: live?.held_inbound ? "warning" : "default" },
            { value: live?.tps_measured != null ? live.tps_measured : "—", label: "tps now" },
          ]}
        />
        <PeakLine peak={live?.tps_peak} />
        {live?.last_error && (
          <HealthStrip tone="destructive">
            <span className="line-clamp-2">{live.last_error}</span>
            {live.last_error_at && <span className="ml-2 opacity-80">{formatTimestamp(live.last_error_at)}</span>}
          </HealthStrip>
        )}
        <div className="flex items-center gap-2 text-xs">
          <span className="min-w-0 flex-1 truncate text-muted-foreground">{settings || "No stored settings"}</span>
          <Link href={`/cp/servers/${encodeURIComponent(worker.name)}`} className="font-semibold text-primary hover:underline">
            Open listener →
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}

function prop(worker: Worker, key: string): string {
  return worker.properties.find((p) => p.key === key)?.value ?? "";
}
