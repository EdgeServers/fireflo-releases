"use client";
import { useState } from "react";
import Link from "next/link";
import { ArrowLeft, Languages } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClasses } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Tabs } from "@/components/ui/tabs";
import { AdvancedToggle } from "./AdvancedToggle";
import { CardActions, FactGrid, Figures, HealthStrip } from "./CardBits";
import { BindList, ConnectionStatus, LiveTrafficControls, useConfirmEnabled } from "./ConnectionStatus";
import { useConfirmChange, useConfirmDelete } from "./ConfirmProvider";
import { CleanQueueButton } from "./QueueCleanDialog";
import { RangePicker } from "./RangePicker";
import { ReceiptQualityLine, type ReceiptQualityRow } from "./ReceiptQuality";
import { SettingsList } from "./SettingsList";
import { VendorCostRates } from "./VendorCostRates";
import { VendorTraffic, type VendorRow } from "./VendorTraffic";
import { ConnectionTestButton, ConnectionTestLog, useConnectionTest } from "./VendorConnectionTest";
import { WorkerForm } from "./WorkerForm";
import { useProductCatalogue } from "./useProducts";
import { useHealth } from "./useHealth";
import { useWorkers } from "./useWorkers";
import { RANGES, useControlData, type Range } from "./useControlData";
import { useAdvanced } from "@/hooks/useAdvanced";
import { cn } from "@/lib/utils";
import { verdictFor } from "@/lib/worker-verdict";
import { KIND, isOn, trafficKey } from "@/lib/worker-types";
import { EmptyState } from "@/components/ui/empty-state";
import { PeakLine } from "./PeakLine";

type Tab = "status" | "settings" | "rates" | "traffic" | "sessions";

/**
 * One vendor, in full: what the list card leaves out, under tabs.
 *
 * <p>The traffic controls stay in the header on every tab, so "Stop sending" is never two clicks
 * away during an incident. Edit replaces the page with the worker form, as the list page does, and
 * comes back here when it is done.
 */
export function VendorDetailClient({ name }: { name: string }) {
  const {
    workers, error, errorFor, loading, busy, busyLabel,
    load, setEnabled, setProperty, restart, remove,
  } = useWorkers(KIND.vendor);
  const { health, byFullName, tpsHistory, reload: reloadHealth } = useHealth();
  const [range, setRange] = useState<Range>("24h");
  const [tab, setTab] = useState<Tab>("status");
  const [editing, setEditing] = useState(false);
  const [advanced, setAdvanced] = useAdvanced("vendor");
  const productCatalogue = useProductCatalogue();
  const { data: traffic } = useControlData<VendorRow[]>("vendors", range);
  const { data: quality } = useControlData<ReceiptQualityRow[]>("receipts", range);
  const connectionTest = useConnectionTest(name);
  const confirm = useConfirmChange();
  const confirmDelete = useConfirmDelete();
  const confirmEnabled = useConfirmEnabled();

  //Restart bounces every connection of the vendor: confirmed wherever it is offered
  const confirmRestart = (vendor: string) => confirm({
    title: `Restart ${vendor}?`,
    consequence: `Every connection of the vendor ${vendor} is closed and opened again; messages in flight are retried.`,
    confirmLabel: "Restart",
    tone: "caution",
  });

  const worker = workers.find((w) => w.name === name);

  if (!worker) {
    return (
      <div className="space-y-5">
        <Link href="/cp/vendors" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Vendors
        </Link>
        <EmptyState>
          {loading ? "Loading…" : error || `No vendor called '${name}'.`}
        </EmptyState>
      </div>
    );
  }

  if (editing) {
    return (
      <WorkerForm
        type={KIND.vendor}
        worker={worker}
        onCancel={() => setEditing(false)}
        onSaved={async () => {
          setEditing(false);
          await load();
        }}
        onRestart={async () => {
          if (!(await confirmRestart(worker.name))) {
            return;
          }
          setEditing(false);
          await restart(worker.name);
        }}
      />
    );
  }

  const key = trafficKey(worker);
  const live = byFullName.get(key);
  const verdict = verdictFor(worker, byFullName, KIND.vendor);
  const suspended = isOn(worker, "suspend");
  const paused = isOn(worker, "pause");
  const host = [prop(worker, "host"), prop(worker, "port")].filter(Boolean).join(":");
  const rangeTitle = `Last ${RANGES.find((r) => r.value === range)?.label ?? range}`;
  const transceivers = Number(prop(worker, "connections.transceivers"));
  const capacity = Number.isFinite(transceivers) && transceivers > 0 ? { kind: "target" as const, value: transceivers } : null;

  const tabs: { id: Tab; label: string }[] = [
    { id: "status", label: "Status" },
    { id: "settings", label: `Bind settings · ${worker.properties.length}` },
    { id: "rates", label: "Cost rates" },
    { id: "traffic", label: "Traffic" },
    { id: "sessions", label: `Sessions · ${live?.sessions?.length ?? 0}` },
  ];

  return (
    <div className="space-y-5">
      <Link href="/cp/vendors" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Vendors
      </Link>

      {/* two columns from xl: the tabs on the left are what you work in, the rail on the right is
          what you glance at -- the facts that identify the vendor and the three live figures -- so
          neither scrolls away while you are in the other */}
      <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_300px]">
      <div className="min-w-0 space-y-4">
      <Card className={cn("min-w-0", verdict.tone === "destructive" && "border-destructive")}>
        <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
          <span className="text-base font-medium">{worker.name}</span>
          {host && <span className="font-mono text-xs text-muted-foreground">{host}</span>}
          <Badge variant={verdict.tone}>{verdict.label}</Badge>
          {worker.label && <span className="text-xs text-muted-foreground">{worker.label}</span>}
          <CardActions>
            {/* Restart bounces the vendor's connections -- something done while looking at its
                state, so it sits up here rather than among the footer's actions on the vendor */}
            <Button
              variant="outline"
              size="sm"
              disabled={busy === worker.name}
              onClick={async () => {
                if (await confirmRestart(worker.name)) {
                  await restart(worker.name);
                }
              }}
            >
              {busy === worker.name && busyLabel === "Restart" ? "Restarting…" : "Restart"}
            </Button>
            <AdvancedToggle on={advanced} onChange={setAdvanced} />
          </CardActions>
        </CardHeader>
        <CardContent className="space-y-4 pt-3">
          {errorFor === worker.name && error && <HealthStrip tone="destructive">{error}</HealthStrip>}

          <Tabs label="Vendor" items={tabs} active={tab} onSelect={setTab} />

          {tab === "status" && (
            <div className="space-y-3">
              <ConnectionStatus
                type={KIND.vendor}
                live={live}
                verdict={verdict}
                paused={paused}
                capacity={capacity}
                windowSeconds={health?.tps_window_seconds}
                tpsHistory={tpsHistory.get(key)}
              />
            </div>
          )}

          {tab === "settings" && (
            <div className="space-y-4">
              <SettingsList
                type={KIND.vendor}
                properties={worker.properties}
                empty="No settings — the gateway will use its own defaults for everything."
              />
              {advanced && !!worker.properties.length && (
                <div className="border-t border-dashed border-border pt-3">
                  <p className="mb-2 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">Every stored key</p>
                  <FactGrid facts={worker.properties.map((p) => ({ label: p.key, value: p.value, mono: true }))} />
                </div>
              )}
            </div>
          )}

          {/* vendor.name, not trafficKey: the rate scope is the bare instance name the gateway binds
              cost with, while trafficKey is the full smppclient.<name> the call records use */}
          {tab === "rates" && <VendorCostRates vendorName={worker.name} catalogue={productCatalogue} />}

          {tab === "traffic" && (
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-sm font-medium">{rangeTitle} <span className="text-xs font-normal text-muted-foreground">From the call records.</span></p>
                <RangePicker value={range} onChange={setRange} />
              </div>
              <VendorTraffic row={(traffic ?? []).find((r) => r.vendor === key)} />
              <ReceiptQualityLine row={(quality ?? []).find((r) => r.vendor === key)} />
            </div>
          )}

          {tab === "sessions" && <BindList type={KIND.vendor} live={live} />}
        </CardContent>
        {/* actions on the vendor as a whole sit at the foot, as on the list page's cards; the
            header keeps Restart and the Advanced toggle, which scopes what the card shows. The traffic
            controls take the rest of the row and right-align themselves. id="test" is the anchor the
            list page's Test link jumps to. Test connection is offered here whatever the vendor's
            state, and its log opens below the card */}
        <CardFooter id="test" className="border-t border-border pt-3">
          <Link href={`/cp/cdrs?vendor=${encodeURIComponent(key)}`} className={buttonClasses({ variant: "outline", size: "sm" })}>
            Messages →
          </Link>
          <Link href={`/cp/error-codes/${encodeURIComponent(worker.name)}`} className={buttonClasses({ variant: "outline", size: "sm" })}>
            <Languages className="h-3.5 w-3.5" />
            Error codes
          </Link>
          <ConnectionTestButton running={connectionTest.running} onRun={connectionTest.run} />
          <Button variant="outline" size="sm" onClick={() => setEditing(true)}>Edit</Button>
          <Button
            variant="ghost"
            size="sm"
            disabled={busy === worker.name}
            onClick={async () => {
              if (await confirmEnabled(worker.name, KIND.vendor, !worker.enabled)) {
                await setEnabled(worker.name, !worker.enabled);
              }
            }}
          >
            {worker.enabled ? "Disable" : "Enable"}
          </Button>
          {advanced && (
            <Button
              variant="ghost"
              size="sm"
              className="text-destructive hover:text-destructive"
              disabled={busy === worker.name}
              onClick={async () => {
                const ok = await confirmDelete({
                  title: `Delete the vendor ${worker.name}?`,
                  consequence: `${worker.name} and its settings are deleted. A routing table that still names it sends nothing there.`,
                  confirmLabel: `Delete ${worker.name}`,
                });
                if (!ok) {
                  return;
                }
                await remove(worker.name);
                window.location.assign("/cp/vendors");
              }}
            >
              Delete
            </Button>
          )}
          {/* beside the traffic controls it is the last resort after: what is waiting is archived
              and ended, so it only appears while something is waiting */}
          <CleanQueueButton
            worker={key}
            listener={false}
            waiting={!!live && ((live.queue_depth ?? 0) + (live.retry_queue_depth ?? 0) > 0 || suspended || paused)}
            onDone={reloadHealth}
          />
          <LiveTrafficControls
            name={worker.name}
            type={KIND.vendor}
            live={live}
            verdict={verdict}
            suspended={suspended}
            paused={paused}
            busy={busy === worker.name}
            busyLabel={busyLabel}
            onSuspend={(on) => setProperty(worker.name, "suspend", on, on ? "Stop sending" : "Resume sending")}
            onPause={(on) => setProperty(worker.name, "pause", on, on ? "Hold" : "Release hold")}
            offerTest={false}
          />
        </CardFooter>
      </Card>

      {connectionTest.open && (
        <ConnectionTestLog
          name={worker.name}
          running={connectionTest.running}
          startedAt={connectionTest.startedAt}
          result={connectionTest.result}
          error={connectionTest.error}
          onRun={connectionTest.run}
          onClose={connectionTest.clear}
        />
      )}
      </div>

      <div className="min-w-0 space-y-4 xl:sticky xl:top-4">
        <Card>
          <CardHeader className="flex flex-row items-center gap-2 space-y-0 border-b border-border">
            <span className="text-sm font-medium">Right now</span>
            <span className="text-xs text-muted-foreground">refreshed every 10s</span>
          </CardHeader>
          <CardContent className="space-y-3 pt-3">
            <Badge variant={verdict.tone}>{verdict.label}</Badge>
            {verdict.detail && <p className="text-xs text-muted-foreground">{verdict.detail}</p>}
            <Figures
              figures={[
                { value: live?.bound ?? "—", label: "binds", tone: live && (live.bound ?? 0) === 0 && worker.enabled ? "destructive" : "default" },
                { value: live ? (live.queue_depth ?? 0) + (live.retry_queue_depth ?? 0) : "—", label: "queued" },
                { value: live?.tps_measured != null ? live.tps_measured : "—", label: "tps now" },
              ]}
            />
            <PeakLine peak={live?.tps_peak} scope={live?.name} onReset={reloadHealth} />
            {live?.last_error && (
              <HealthStrip tone="destructive">
                <span className="line-clamp-3">{live.last_error}</span>
              </HealthStrip>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center gap-2 space-y-0 border-b border-border">
            <span className="text-sm font-medium">Connection</span>
          </CardHeader>
          <CardContent className="pt-3">
            <FactGrid
              columns={2}
              facts={[
                { label: "Host", value: prop(worker, "host") || "—", mono: true, muted: !prop(worker, "host") },
                { label: "Port", value: prop(worker, "port") || "—", mono: true, muted: !prop(worker, "port") },
                { label: "System ID", value: prop(worker, "username") || "—", mono: true, muted: !prop(worker, "username") },
                { label: "System type", value: prop(worker, "systemType") || "—", mono: true, muted: !prop(worker, "systemType") },
                { label: "Transceivers", value: prop(worker, "connections.transceivers") || "default", muted: !prop(worker, "connections.transceivers") },
                { label: "Window", value: prop(worker, "windowSize") || "default", muted: !prop(worker, "windowSize") },
                { label: "Throughput limit", value: Number(prop(worker, "tps")) > 0 ? `${prop(worker, "tps")} tps` : live?.tps_limit ? `${live.tps_limit} tps` : "none", muted: !(Number(prop(worker, "tps")) > 0) && !live?.tps_limit },
                { label: "Stop sending", value: suspended ? "on" : "off", muted: !suspended },
                { label: "Enabled", value: worker.enabled ? "yes" : "no", muted: !worker.enabled },
              ]}
            />
          </CardContent>
        </Card>
      </div>
      </div>
    </div>
  );
}

function prop(worker: { properties: { key: string; value: string }[] }, key: string): string {
  return worker.properties.find((p) => p.key === key)?.value ?? "";
}
