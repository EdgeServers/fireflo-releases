/**
 * The GraphQL documents this panel sends to the gateway, one root field each.
 *
 * <p>Plain strings rather than a query builder: the schema is the gateway's
 * (`fireflo-restapi/src/main/resources/graphql/*.graphql`), the panel asks for the fields it reads,
 * and a document that names a field the gateway does not have fails at the gateway with a sentence
 * naming it -- which is a better failure than a builder's. `lib/gateway-queries.test.ts` holds each
 * one to the shape the routes rely on and to the gateway's own schema, a copy of which is committed
 * at `lib/__fixtures__/schema.graphql` (from the gateway's `api/schema.graphql`).
 *
 * <p>Names on the wire are the schema's `camelCase`. Routes that promised a REST-era `snake_case`
 * shape convert at the edge (`snakeCaseKeys`), so a page reading `days_until_frozen` today still
 * does.
 */

/**
 * What the gateway is doing. `snapshot` is the whole old `/ops/health` object, field names and all,
 * so a page that reads `router_queue` keeps reading it; the typed fields beside it are the ones the
 * panel decides from (pairing, capabilities) and are spread over the snapshot by the route.
 */
/** Just the platform currency, for the one reader that wants nothing else (lib/platform-currency.ts). */
export const HEALTH_CURRENCY = `query HealthCurrency {
  health {
    currency
  }
}`;

export const HEALTH = `query Health {
  health {
    version
    observedAt
    schemaVersion
    api
    currency
    opsAllowList { entries loopbackOnly }
    db { slowThresholdMs slowLastHour }
    snapshot
  }
}`;

/**
 * This node's identity, the cluster it sees and the Kafka backbone (gateway 0.14, `node_identity`
 * and `kafka_backbone`). A document of its own rather than three more fields on HEALTH: a 0.13
 * gateway rejects a selection it does not know, and health must keep answering there. The health
 * route sends this second document only when the capability map says the fields exist.
 */
function healthCluster(name: string, backboneExtra: string): string {
  return `query ${name} {
  health {
    nodeId
    cluster {
      mode
      nodes { nodeId host version startedAt heartbeatAt alive opsUrl }
    }
    backbone {
      provider
      bootstrap
      connected
      routerGroup
      routerLag
      assignment
      retryDepth
      dlqDepth
      lastError
      lastErrorAt${backboneExtra}
    }
  }
}`;
}

export const HEALTH_CLUSTER = healthCluster("HealthCluster", "");

/**
 * HEALTH_CLUSTER with `backbone.source`: what decided the provider, fireflo.env or `app_config`
 * (gateway `queue_provider_env`). A document of its own for the same reason HEALTH_CLUSTER is one:
 * a 0.14.0 or 0.14.1 gateway rejects a selection it does not know, so the health route sends this
 * one only when the capability map names the field.
 */
export const HEALTH_CLUSTER_SOURCE = healthCluster("HealthClusterSource", "\n      source");

/**
 * The backbone's provider, bootstrap and source alone, for the broker settings route, which locks
 * the two keys fireflo.env decides. Sent only to a gateway with `queue_provider_env`.
 */
export const HEALTH_BACKBONE_SOURCE = `query HealthBackboneSource {
  health {
    backbone {
      provider
      bootstrap
      source
    }
  }
}`;

/**
 * Every Kafka topic under the gateway's prefix, with its groups and who uses it (gateway 0.14.3,
 * `kafka_topics_view`). Admin calls on the gateway's side, cached there for five seconds. Sent only
 * to a gateway that declares the capability: an older one rejects the field by name.
 */
export const KAFKA_TOPICS = `query KafkaTopics {
  kafkaTopics {
    provider
    available
    topicPrefix
    groupPrefix
    readAt
    cacheSeconds
    error
    topics {
      name
      role
      subject
      purpose
      partitions
      replication
      retentionMs
      messages
      beginOffset
      endOffset
      lag
      holderNode
      groups { group state members committed lag expected }
      usedBy { kind name detail }
    }
  }
}`;

const LICENSE_FIELDS = `verdict
    licenseId
    tier
    installId
    boundIp
    notAfter
    graceEndsAt
    daysUntilFrozen
    lastRefreshedAt
    configurationAdopted
    serverUrl
    configurationChangedWhileUnlicensed
    machineMatches
    message`;

export const LICENSE = `query License {
  license {
    ${LICENSE_FIELDS}
  }
}`;

export const LICENSE_ACTIVATE = `mutation LicenseActivate($key: String!) {
  licenseActivate(key: $key) {
    ${LICENSE_FIELDS}
  }
}`;

export const LICENSE_REVALIDATE = `mutation LicenseRevalidate {
  licenseRevalidate {
    ${LICENSE_FIELDS}
  }
}`;

export const LICENSE_OFFLINE_REQUEST = `mutation LicenseOfflineRequest($key: String!) {
  licenseOfflineRequest(key: $key) {
    request
  }
}`;

export const LICENSE_OFFLINE_APPLY = `mutation LicenseOfflineApply($license: String!) {
  licenseOfflineApply(license: $license) {
    ${LICENSE_FIELDS}
  }
}`;

export const LICENSE_RELEASE = `mutation LicenseRelease {
  licenseRelease {
    ${LICENSE_FIELDS}
  }
}`;

export const RELOAD = `mutation Reload {
  reload {
    observedAt
    reloaded
    adopted
    reason
  }
}`;

/** The database statements that ran longer than the gateway's threshold. */
export const SLOW_QUERIES = `query SlowQueries($minMs: Int, $since: DateTime, $caller: String, $limit: Int) {
  slowQueries(minMs: $minMs, since: $since, caller: $caller, limit: $limit) {
    startedAt
    durationMs
    shape
    updateCount
    caller
    thread
  }
}`;

export const SLOW_QUERY_SUMMARY = `query SlowQuerySummary($since: DateTime) {
  slowQuerySummary(since: $since) {
    thresholdMs
    kept
    lastHour
    shapes { shape count maxMs meanMs lastAt }
  }
}`;

export const SLOW_QUERIES_CLEAR = `mutation SlowQueriesClear {
  slowQueriesClear
}`;

/** The refusal ledger: every refused bind and REST credential, by listener and address. */
export const REFUSALS = `query Refusals($windowMinutes: Int, $listener: String, $surface: String, $reason: String, $ip: String, $limit: Int) {
  refusals(windowMinutes: $windowMinutes, listener: $listener, surface: $surface, reason: $reason, ip: $ip, limit: $limit) {
    at
    surface
    listener
    port
    reason
    ip
    identity
    heldOut
  }
}`;

/** The ledger folded by listener and address, which is what a ban rule evaluates. */
export const REFUSAL_SUMMARY = `query RefusalSummary($windowMinutes: Int, $listener: String) {
  refusalSummary(windowMinutes: $windowMinutes, listener: $listener) {
    listener
    port
    total
    byReason { reason count }
    byAddress {
      ip
      count
      byReason { reason count }
      identities
      firstAt
      lastAt
      heldOut
    }
  }
}`;

export const BIND_HOLDS = `query BindHolds {
  bindHolds {
    id
    kind
    value
    listener
    until
    reason
    createdBy
    createdAt
  }
}`;

// ---- queues, housekeeping and re-push ----

/** What is waiting in each queue: the old `/ops/queues` object, untouched. */
export const QUEUES = `query Queues($worker: String, $limit: Int, $store: String, $systemId: String, $account: String) {
  queues(worker: $worker, limit: $limit, store: $store, systemId: $systemId, account: $account)
}`;

/** One store's housekeeping: `input` is the old request body, the answer the old `data`. */
export const HOUSEKEEPING = `mutation Housekeeping($store: String!, $input: JSON!) {
  housekeeping(store: $store, input: $input)
}`;

const REPUSH_FIELDS = `jobId
    dryRun
    preview
    state
    total
    sent
    storedForReplay
    skippedPending
    failed
    startedAt
    eta
    lastSubmittedAt
    note`;

export const REPUSH_START = `mutation RepushStart($input: JSON!) {
  repushStart(input: $input) {
    ${REPUSH_FIELDS}
  }
}`;

export const REPUSH_JOB = `query RepushJob($jobId: ID!) {
  repushJob(jobId: $jobId) {
    ${REPUSH_FIELDS}
  }
}`;

export const REPUSH_CANCEL = `mutation RepushCancel($jobId: ID!) {
  repushCancel(jobId: $jobId) {
    ${REPUSH_FIELDS}
  }
}`;

// ---- the testers ----

export const ROUTING_EXPLAIN = `query RoutingExplain($table: String, $from: String, $to: String, $type: String, $product: String, $ingateway: String, $account: String) {
  routingExplain(table: $table, from: $from, to: $to, type: $type, product: $product, ingateway: $ingateway, account: $account)
}`;

export const RATING_EXPLAIN = `query RatingExplain($account: String, $to: String, $from: String, $product: String, $vendor: String, $content: String) {
  ratingExplain(account: $account, to: $to, from: $from, product: $product, vendor: $vendor, content: $content)
}`;

export const FILTERS_TEST = `query FiltersTest($to: String, $from: String, $product: String, $account: String, $type: String) {
  filtersTest(to: $to, from: $from, product: $product, account: $account, type: $type)
}`;

/** What the live whitelist makes of one body: a query, it changes nothing. The e2e suite's oracle. */
export const WHITELIST_TEST = `query WhitelistTest($account: String, $product: String, $systemId: String, $body: String) {
  whitelistTest(account: $account, product: $product, systemId: $systemId, body: $body)
}`;

/** Reaches a Kafka cluster once from the gateway's host and describes it; its own connection is untouched (gateway 0.14). */
export const BROKER_TEST = `mutation BrokerTest($bootstrap: String!, $topic: String) {
  brokerTest(bootstrap: $bootstrap, topic: $topic)
}`;

export const TEST_BIND = `mutation TestBind($worker: String!) {
  testBind(worker: $worker)
}`;

// ---- sessions and binds ----

/** One worker's sessions, paged. Typed and camelCase: the route converts rows to the snapshot's spelling. */
export const SESSIONS = `query Sessions($worker: String!, $q: String, $offset: Int, $limit: Int) {
  sessions(worker: $worker, q: $q, offset: $offset, limit: $limit) {
    rows {
      sessionId
      bindType
      bound
      role
      host
      port
      systemId
      account
      systemType
      submitted
      receipts
      tpsMeasured
      tpsLimit
      boundSeconds
    }
    total
    matched
    offset
    limit
  }
}`;

export const SESSION_SUMMARY = `query SessionSummary($systemIds: [String!]) {
  sessionSummary(systemIds: $systemIds)
}`;

/** `target` is `{ip}`, `{account}` or `{system_id}`: the old query parameter as an object. */
export const SESSION_MATCH = `query SessionMatch($target: JSON!, $listener: String) {
  sessionMatch(target: $target, listener: $listener)
}`;

export const SESSIONS_DISCONNECT = `mutation SessionsDisconnect($target: JSON!, $listener: String, $hold: String, $reason: String, $by: String) {
  sessionsDisconnect(target: $target, listener: $listener, hold: $hold, reason: $reason, by: $by)
}`;

export const SESSION_DISCONNECT = `mutation SessionDisconnect($worker: String!, $sessionId: String!) {
  sessionDisconnect(worker: $worker, sessionId: $sessionId)
}`;

export const BIND_HOLD_LIFT = `mutation BindHoldLift($id: ID!, $by: String) {
  bindHoldLift(id: $id, by: $by) {
    lifted
  }
}`;

export const WORKER_ACTION = `mutation WorkerAction($worker: String!, $action: String!) {
  workerAction(worker: $worker, action: $action)
}`;

export const CREDIT_RELEASE = `mutation CreditRelease($account: String) {
  creditRelease(account: $account) {
    account
    accountsReleased
  }
}`;

export const TPS_PEAKS_CLEAR = `mutation TpsPeaksClear($scope: String) {
  tpsPeaksClear(scope: $scope) {
    removed
  }
}`;

// ---- captures and watches: the admin token, they carry customer content ----

const CAPTURE_FIELDS = `worker
    sessionId
    running
    startedAt
    stoppedAt
    stoppedBecause
    pdus
    bytes
    dropped
    preview`;

export const CAPTURE = `query Capture($worker: String!, $sessionId: String!, $preview: Int) {
  capture(worker: $worker, sessionId: $sessionId, preview: $preview) {
    ${CAPTURE_FIELDS}
  }
}`;

export const CAPTURE_START = `mutation CaptureStart($worker: String!, $sessionId: String!, $seconds: Int, $pdus: Int) {
  captureStart(worker: $worker, sessionId: $sessionId, seconds: $seconds, pdus: $pdus) {
    ${CAPTURE_FIELDS}
  }
}`;

export const CAPTURE_STOP = `mutation CaptureStop($worker: String!, $sessionId: String!) {
  captureStop(worker: $worker, sessionId: $sessionId) {
    ${CAPTURE_FIELDS}
  }
}`;

const FILE_FIELDS = `filename
    contentType
    bytesBase64
    size`;

export const CAPTURE_FILE = `mutation CaptureFile($worker: String!, $sessionId: String!, $kind: CaptureKind!) {
  captureFile(worker: $worker, sessionId: $sessionId, kind: $kind) {
    ${FILE_FIELDS}
  }
}`;

const WATCH_FIELDS = `id
    worker
    ip
    port
    running
    startedAt
    endsAt
    stoppedAt
    stoppedBecause
    dropped
    events { seq at sessionId peer kind direction command sequence status text }
    next
    more`;

export const WATCH = `query Watch($id: ID!, $after: Int) {
  watch(id: $id, after: $after) {
    ${WATCH_FIELDS}
  }
}`;

export const WATCH_START = `mutation WatchStart($ip: String!, $port: Int!, $seconds: Int) {
  watchStart(ip: $ip, port: $port, seconds: $seconds) {
    ${WATCH_FIELDS}
  }
}`;

export const WATCH_STOP = `mutation WatchStop($id: ID!) {
  watchStop(id: $id) {
    ${WATCH_FIELDS}
  }
}`;

export const WATCH_FILE = `mutation WatchFile($id: ID!) {
  watchFile(id: $id) {
    ${FILE_FIELDS}
  }
}`;

// ---- files and configuration: the admin token, a log carries customer traffic ----

export const FILES = `query Files {
  files
}`;

export const LOG_TAIL = `query LogTail($name: String!, $lines: Int, $contains: String) {
  logTail(name: $name, lines: $lines, contains: $contains) {
    name
    path
    state
    sizeBytes
    requestedLines
    returnedLines
    windowBytes
    truncated
    filter
    note
    lines
  }
}`;

export const RESOLVED_CONFIG = `query ResolvedConfig {
  resolvedConfig
}`;

export const CONFIG_FILE = `query ConfigFile($name: String!) {
  configFile(name: $name)
}`;

export const DIAGNOSTICS = `query Diagnostics($lines: Int) {
  diagnostics(lines: $lines)
}`;

// ---- the preprocessor workbench ----

export const PREPROCESSOR_FILES = `query PreprocessorFiles {
  preprocessorFiles
}`;

export const PREPROCESSOR_FILE = `query PreprocessorFile($name: String!) {
  preprocessorFile(name: $name)
}`;

export const PREPROCESSOR_CHECK = `mutation PreprocessorCheck($input: JSON!) {
  preprocessorCheck(input: $input)
}`;

export const PREPROCESSOR_TEST = `mutation PreprocessorTest($input: JSON!) {
  preprocessorTest(input: $input)
}`;

export const PREPROCESSOR_SAVE = `mutation PreprocessorSave($name: String!, $content: String!, $expectedSha: String, $actor: String) {
  preprocessorSave(name: $name, content: $content, expectedSha: $expectedSha, actor: $actor)
}`;

export const PREPROCESSOR_ROLLBACK = `mutation PreprocessorRollback($name: String!, $sha: String!, $actor: String) {
  preprocessorRollback(name: $name, sha: $sha, actor: $actor)
}`;

/** Every document above, by name, so a test can walk them without a second list to keep in step. */
export const DOCUMENTS = {
  HEALTH,
  HEALTH_CURRENCY,
  HEALTH_CLUSTER,
  HEALTH_CLUSTER_SOURCE,
  HEALTH_BACKBONE_SOURCE,
  KAFKA_TOPICS,
  LICENSE,
  LICENSE_ACTIVATE,
  LICENSE_REVALIDATE,
  LICENSE_OFFLINE_REQUEST,
  LICENSE_OFFLINE_APPLY,
  LICENSE_RELEASE,
  RELOAD,
  SLOW_QUERIES,
  SLOW_QUERY_SUMMARY,
  SLOW_QUERIES_CLEAR,
  REFUSALS,
  REFUSAL_SUMMARY,
  BIND_HOLDS,
  QUEUES,
  HOUSEKEEPING,
  REPUSH_START,
  REPUSH_JOB,
  REPUSH_CANCEL,
  ROUTING_EXPLAIN,
  RATING_EXPLAIN,
  FILTERS_TEST,
  WHITELIST_TEST,
  BROKER_TEST,
  TEST_BIND,
  SESSIONS,
  SESSION_SUMMARY,
  SESSION_MATCH,
  SESSIONS_DISCONNECT,
  SESSION_DISCONNECT,
  BIND_HOLD_LIFT,
  WORKER_ACTION,
  CREDIT_RELEASE,
  TPS_PEAKS_CLEAR,
  CAPTURE,
  CAPTURE_START,
  CAPTURE_STOP,
  CAPTURE_FILE,
  WATCH,
  WATCH_START,
  WATCH_STOP,
  WATCH_FILE,
  FILES,
  LOG_TAIL,
  RESOLVED_CONFIG,
  CONFIG_FILE,
  DIAGNOSTICS,
  PREPROCESSOR_FILES,
  PREPROCESSOR_FILE,
  PREPROCESSOR_CHECK,
  PREPROCESSOR_TEST,
  PREPROCESSOR_SAVE,
  PREPROCESSOR_ROLLBACK,
} as const;

/**
 * The operation kind and root field of a document, read the way the gateway would.
 *
 * <p>Returns null for anything that is not `query|mutation Name(...)? { field`. Used by the test
 * and by nothing on the request path, so a document never pays for its own parsing.
 */
export function rootFieldOf(document: string): { kind: "query" | "mutation"; field: string } | null {
  const m = /^\s*(query|mutation)\s+\w+\s*(?:\([^)]*\))?\s*\{\s*(\w+)/.exec(document);
  return m ? { kind: m[1] as "query" | "mutation", field: m[2] } : null;
}
