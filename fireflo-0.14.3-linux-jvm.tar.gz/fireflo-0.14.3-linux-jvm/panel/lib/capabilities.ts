import type { Health } from "./health-types";

/**
 * What the gateway's API can do, read from the `health` field's `api` map (gateway 0.13+).
 *
 * <p>A capability is a fact about the build, published by name and never withdrawn while the
 * feature exists. Screens ask for a name rather than reasoning from the version string, because a
 * version says when something shipped and a name says whether it is there -- which is the question.
 * A gateway older than the map answers no to everything, and that is the right answer: none of the
 * named features existed.
 */

/**
 * The names this panel asks for, as the gateway's `ApiCapabilities` publishes them.
 *
 * <p>Gateway 0.13: `graphql_ops` is the GraphQL endpoint on the management port (and so, by
 * implication, the end of REST `/ops`); `send_as_account` and `account_sync` are the platform
 * (OMNI) fields; `slow_query_log` and `refusal_ledger` are the two new diagnostics the Security and
 * Diagnostics pages read. A screen that needs one asks by name and says so when it is absent.
 */
export const GRAPHQL_OPS = "graphql_ops";
export const SEND_AS_ACCOUNT = "send_as_account";
export const ACCOUNT_SYNC = "account_sync";
export const SLOW_QUERY_LOG = "slow_query_log";
export const REFUSAL_LEDGER = "refusal_ledger";
/** Session rows carry `receipts` (gateway 0.13.2): the listener's Status tab sets DLR against MT. */
export const SESSION_RECEIPTS = "session_receipts";

/**
 * Gateway 0.14, the Kafka backbone. `kafka_backbone`: `smsg.queue.provider=kafka` exists, with the
 * `smsg.kafka.*` keys, `health.backbone` and `brokerTest(bootstrap, topic)` -- the Queues page's
 * broker card asks for this. `node_identity`: `health.nodeId` and `health.cluster.nodes`, which
 * the Nodes page lists. `vendor_leases`: vendor sessions are leased to one node at a time (columns
 * on Nodes, later). `queue_peek`: topic rows in the queue dump carry peeked entries. `topic_lag`:
 * those rows carry the consumer group's lag and member count.
 */
export const KAFKA_BACKBONE = "kafka_backbone";
export const NODE_IDENTITY = "node_identity";
export const VENDOR_LEASES = "vendor_leases";
export const QUEUE_PEEK = "queue_peek";
export const TOPIC_LAG = "topic_lag";
/**
 * Gateway 0.14.2. `queue_provider_env`: FIREFLO_QUEUE_PROVIDER and FIREFLO_KAFKA_BOOTSTRAP in the
 * gateway's fireflo.env decide the provider over `app_config`, and `health.backbone.source` says
 * which one did. The broker card locks the two keys when it is `env`.
 */
export const QUEUE_PROVIDER_ENV = "queue_provider_env";
/**
 * Gateway 0.14.3. `kafka_topics_view`: the `kafkaTopics` field, every topic under the prefix with
 * its groups and who uses it. The Kafka page and its sidebar row ask for this (and a Kafka backbone).
 */
export const KAFKA_TOPICS_VIEW = "kafka_topics_view";

/** Whether this gateway's API has the named capability. False on an older gateway or no health. */
export function hasCapability(health: Health | null | undefined, name: string): boolean {
  return health?.api?.[name] === true;
}

/** The capabilities this gateway declares, sorted, so two gateways' lists can be read side by side. */
export function capabilityNames(health: Health | null | undefined): string[] {
  return Object.entries(health?.api ?? {})
    .filter(([, on]) => on === true)
    .map(([name]) => name)
    .sort();
}

/**
 * One sentence for a verify or status screen, or null when the gateway publishes no map at all --
 * which a caller shows as "not reported" rather than as an empty list, since those differ.
 */
export function apiLevelSentence(health: Health | null | undefined): string | null {
  if (health?.api == null) {
    return null;
  }
  const names = capabilityNames(health);
  return names.length
    ? `This gateway answers API level ${names.join(", ")}.`
    : "This gateway answers API level with no capabilities declared.";
}
