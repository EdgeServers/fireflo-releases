import { hasCapability, KAFKA_TOPICS_VIEW } from "./capabilities.ts";
import type { Health } from "./health-types.ts";

/**
 * The gateway's Kafka topics view (gateway 0.14.3, `kafkaTopics`, capability `kafka_topics_view`),
 * and the pure pieces the Kafka page draws it with: the role grouping and order, retention and
 * lag wording, and where a user of a topic links to.
 *
 * <p>Kept out of the component so the decisions can be tested without React: which roles come
 * first, how a tier sorts, when a lag is highlighted.
 */

/** Something whose traffic passes through a topic: an SMPP listener, a vendor, or a REST caller. */
export interface KafkaTopicUser {
  /** `server`, `vendor` or `rest`. */
  kind: string;
  name: string;
  /** A listener's port (`:2775`), a vendor's node pin. */
  detail?: string | null;
}

/** One consumer group on one topic. */
export interface KafkaTopicGroup {
  group: string;
  state?: string | null;
  members?: number | null;
  /** The committed offsets on this topic, summed; null when the group has committed none. */
  committed?: number | null;
  lag?: number | null;
  /** The group the gateway itself reads the topic with. */
  expected: boolean;
}

export interface KafkaTopic {
  name: string;
  /** router, retry, vendor, deliver, dlq, webhook or other. */
  role: string;
  /** The retry tier, the vendor's full name or the deliver topic's node. */
  subject?: string | null;
  purpose: string;
  partitions?: number | null;
  replication?: number | null;
  /** `retention.ms`; -1 is unlimited. */
  retentionMs?: number | null;
  /** Records kept now (latest minus earliest), not what is waiting. */
  messages?: number | null;
  beginOffset?: number | null;
  endOffset?: number | null;
  /** The gateway's own group's lag: what is waiting. */
  lag?: number | null;
  groups: KafkaTopicGroup[];
  holderNode?: string | null;
  usedBy: KafkaTopicUser[];
}

export interface KafkaTopicsView {
  provider: string;
  available: boolean;
  topicPrefix?: string | null;
  groupPrefix?: string | null;
  readAt?: string | null;
  cacheSeconds: number;
  error?: string | null;
  topics: KafkaTopic[];
}

/** The order the page shows roles in: where traffic enters, where it leaves, then where it waits. */
export const ROLE_ORDER = ["router", "deliver", "vendor", "retry", "dlq", "webhook", "other"] as const;

export const ROLE_LABEL: Record<string, string> = {
  router: "Router",
  deliver: "Deliver",
  vendor: "Vendors",
  retry: "Retry",
  dlq: "DLQ",
  webhook: "Webhook",
  other: "Other",
};

/** The retry tiers, shortest first, as the gateway names them. */
export const TIER_ORDER = ["1s", "5s", "30s", "2m", "10m", "1h"];

export interface RoleSection {
  role: string;
  label: string;
  topics: KafkaTopic[];
}

function roleRank(role: string): number {
  const i = (ROLE_ORDER as readonly string[]).indexOf(role);
  return i < 0 ? ROLE_ORDER.length - 1 : i;
}

function tierRank(subject: string | null | undefined): number {
  const i = TIER_ORDER.indexOf(subject ?? "");
  return i < 0 ? TIER_ORDER.length : i;
}

/**
 * The topics in sections by role, in `ROLE_ORDER`, empty sections left out. Retry tiers sort
 * shortest first; everything else by name. A role this panel does not know joins Other.
 */
export function groupByRole(topics: KafkaTopic[]): RoleSection[] {
  const sections = new Map<string, KafkaTopic[]>();
  for (const t of topics) {
    const role = (ROLE_ORDER as readonly string[]).includes(t.role) ? t.role : "other";
    const list = sections.get(role) ?? [];
    list.push(t);
    sections.set(role, list);
  }
  return [...sections.entries()]
    .sort(([a], [b]) => roleRank(a) - roleRank(b))
    .map(([role, list]) => ({
      role,
      label: ROLE_LABEL[role] ?? role,
      topics: [...list].sort((a, b) =>
        role === "retry" ? tierRank(a.subject) - tierRank(b.subject) || a.name.localeCompare(b.name) : a.name.localeCompare(b.name)
      ),
    }));
}

/** `retention.ms` as an operator reads it: `7 d`, `24 h`, `unlimited`, or a dash when unread. */
export function formatRetention(ms: number | null | undefined): string {
  if (ms == null || Number.isNaN(ms)) {
    return "—";
  }
  if (ms < 0) {
    return "unlimited";
  }
  const minute = 60_000;
  const hour = 60 * minute;
  const day = 24 * hour;
  if (ms >= day && ms % day === 0) {
    return `${ms / day} d`;
  }
  if (ms >= hour && ms % hour === 0) {
    return `${ms / hour} h`;
  }
  if (ms >= minute && ms % minute === 0) {
    return `${ms / minute} min`;
  }
  if (ms >= 1000 && ms % 1000 === 0) {
    return `${ms / 1000} s`;
  }
  return `${ms} ms`;
}

/**
 * How a lag reads against the previous refresh: `clear` at zero or unread, `growing` when above
 * zero and higher than last time, `behind` when above zero and not growing. Only `growing` is
 * highlighted as a problem: a lag that is falling is a consumer catching up.
 */
export type LagState = "clear" | "behind" | "growing";

export function lagState(lag: number | null | undefined, previous: number | null | undefined): LagState {
  if (lag == null || lag <= 0) {
    return "clear";
  }
  return previous != null && lag > previous ? "growing" : "behind";
}

/** Each topic's lag, by name, for the next refresh to compare against. */
export function lagsByTopic(topics: KafkaTopic[]): Map<string, number> {
  const out = new Map<string, number>();
  for (const t of topics) {
    if (t.lag != null) {
      out.set(t.name, t.lag);
    }
  }
  return out;
}

/** Where a topic's user is configured: a listener's or a vendor's page; null for a REST caller. */
export function userHref(user: KafkaTopicUser): string | null {
  if (user.kind === "server") {
    return `/cp/servers/${encodeURIComponent(user.name)}`;
  }
  if (user.kind === "vendor") {
    return `/cp/vendors/${encodeURIComponent(user.name)}`;
  }
  return null;
}

/**
 * Whether the Kafka page and its sidebar row are shown: a gateway on the Kafka backbone that
 * declares the topics view. A memory gateway has no topics, and an older one no `kafkaTopics`.
 */
export function showKafkaPage(health: Health | null | undefined): boolean {
  return hasCapability(health, KAFKA_TOPICS_VIEW) && health?.backbone?.provider?.trim().toLowerCase() === "kafka";
}
