import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";
import { DOCUMENTS, rootFieldOf } from "./gateway-queries.ts";

/**
 * Each document is one well-formed operation on the root field its name promises, and names only
 * fields, arguments and selections the gateway's schema has.
 *
 * <p>The schema is a committed copy of the gateway's `api/schema.graphql`
 * (`lib/__fixtures__/schema.graphql`): the contract the gateway publishes, read here by a small
 * hand-written SDL walker rather than a GraphQL dependency the panel does not otherwise need. It
 * reads `type X { ... }` and `extend type X { ... }` blocks, each field's arguments and its result
 * type, and checks every document against them. A document that names a field the gateway lacks
 * fails here before it fails at a gateway.
 */

/** The root field each constant must open, and whether it is a query or a mutation. */
const EXPECTED: Record<keyof typeof DOCUMENTS, { kind: "query" | "mutation"; field: string }> = {
  HEALTH: { kind: "query", field: "health" },
  HEALTH_CURRENCY: { kind: "query", field: "health" },
  HEALTH_CLUSTER: { kind: "query", field: "health" },
  HEALTH_CLUSTER_SOURCE: { kind: "query", field: "health" },
  HEALTH_BACKBONE_SOURCE: { kind: "query", field: "health" },
  KAFKA_TOPICS: { kind: "query", field: "kafkaTopics" },
  LICENSE: { kind: "query", field: "license" },
  LICENSE_ACTIVATE: { kind: "mutation", field: "licenseActivate" },
  LICENSE_REVALIDATE: { kind: "mutation", field: "licenseRevalidate" },
  LICENSE_OFFLINE_REQUEST: { kind: "mutation", field: "licenseOfflineRequest" },
  LICENSE_OFFLINE_APPLY: { kind: "mutation", field: "licenseOfflineApply" },
  LICENSE_RELEASE: { kind: "mutation", field: "licenseRelease" },
  RELOAD: { kind: "mutation", field: "reload" },
  SLOW_QUERIES: { kind: "query", field: "slowQueries" },
  SLOW_QUERY_SUMMARY: { kind: "query", field: "slowQuerySummary" },
  SLOW_QUERIES_CLEAR: { kind: "mutation", field: "slowQueriesClear" },
  REFUSALS: { kind: "query", field: "refusals" },
  REFUSAL_SUMMARY: { kind: "query", field: "refusalSummary" },
  BIND_HOLDS: { kind: "query", field: "bindHolds" },
  QUEUES: { kind: "query", field: "queues" },
  HOUSEKEEPING: { kind: "mutation", field: "housekeeping" },
  REPUSH_START: { kind: "mutation", field: "repushStart" },
  REPUSH_JOB: { kind: "query", field: "repushJob" },
  REPUSH_CANCEL: { kind: "mutation", field: "repushCancel" },
  ROUTING_EXPLAIN: { kind: "query", field: "routingExplain" },
  RATING_EXPLAIN: { kind: "query", field: "ratingExplain" },
  FILTERS_TEST: { kind: "query", field: "filtersTest" },
  WHITELIST_TEST: { kind: "query", field: "whitelistTest" },
  BROKER_TEST: { kind: "mutation", field: "brokerTest" },
  TEST_BIND: { kind: "mutation", field: "testBind" },
  SESSIONS: { kind: "query", field: "sessions" },
  SESSION_SUMMARY: { kind: "query", field: "sessionSummary" },
  SESSION_MATCH: { kind: "query", field: "sessionMatch" },
  SESSIONS_DISCONNECT: { kind: "mutation", field: "sessionsDisconnect" },
  SESSION_DISCONNECT: { kind: "mutation", field: "sessionDisconnect" },
  BIND_HOLD_LIFT: { kind: "mutation", field: "bindHoldLift" },
  WORKER_ACTION: { kind: "mutation", field: "workerAction" },
  CREDIT_RELEASE: { kind: "mutation", field: "creditRelease" },
  TPS_PEAKS_CLEAR: { kind: "mutation", field: "tpsPeaksClear" },
  CAPTURE: { kind: "query", field: "capture" },
  CAPTURE_START: { kind: "mutation", field: "captureStart" },
  CAPTURE_STOP: { kind: "mutation", field: "captureStop" },
  CAPTURE_FILE: { kind: "mutation", field: "captureFile" },
  WATCH: { kind: "query", field: "watch" },
  WATCH_START: { kind: "mutation", field: "watchStart" },
  WATCH_STOP: { kind: "mutation", field: "watchStop" },
  WATCH_FILE: { kind: "mutation", field: "watchFile" },
  FILES: { kind: "query", field: "files" },
  LOG_TAIL: { kind: "query", field: "logTail" },
  RESOLVED_CONFIG: { kind: "query", field: "resolvedConfig" },
  CONFIG_FILE: { kind: "query", field: "configFile" },
  DIAGNOSTICS: { kind: "query", field: "diagnostics" },
  PREPROCESSOR_FILES: { kind: "query", field: "preprocessorFiles" },
  PREPROCESSOR_FILE: { kind: "query", field: "preprocessorFile" },
  PREPROCESSOR_CHECK: { kind: "mutation", field: "preprocessorCheck" },
  PREPROCESSOR_TEST: { kind: "mutation", field: "preprocessorTest" },
  PREPROCESSOR_SAVE: { kind: "mutation", field: "preprocessorSave" },
  PREPROCESSOR_ROLLBACK: { kind: "mutation", field: "preprocessorRollback" },
};

function balanced(document: string, open: string, close: string): boolean {
  let depth = 0;
  for (const ch of document) {
    if (ch === open) depth++;
    if (ch === close) depth--;
    if (depth < 0) return false;
  }
  return depth === 0;
}

for (const [name, expected] of Object.entries(EXPECTED) as [keyof typeof DOCUMENTS, { kind: string; field: string }][]) {
  test(`${name} is a ${expected.kind} on ${expected.field}`, () => {
    const document = DOCUMENTS[name];
    assert.ok(balanced(document, "{", "}"), "braces balance");
    assert.ok(balanced(document, "(", ")"), "parentheses balance");
    assert.deepEqual(rootFieldOf(document), expected);
    //exactly one root field: the client answers `data[<the one key>]`, so a second root field
    //would silently hand a route the whole object instead
    const body = document.slice(document.indexOf("{") + 1);
    const roots = body.match(/^\s{2}\w+/gm) ?? [];
    assert.equal(roots.length, 1, `one root field, found ${roots.length}`);
  });
}

test("every document constant is listed in DOCUMENTS and in this test", () => {
  assert.deepEqual(Object.keys(DOCUMENTS).sort(), Object.keys(EXPECTED).sort());
});

test("every variable a document declares is used, and every one used is declared", () => {
  for (const [name, document] of Object.entries(DOCUMENTS)) {
    const declared = new Set([...(document.match(/\$(\w+)\s*:/g) ?? [])].map((d) => d.replace(/[$:\s]/g, "")));
    const used = new Set([...(document.match(/:\s*\$(\w+)/g) ?? [])].map((u) => u.replace(/[:$\s]/g, "")));
    assert.deepEqual([...used].sort(), [...declared].sort(), name);
  }
});

test("rootFieldOf rejects anything that is not an operation", () => {
  assert.equal(rootFieldOf("{ health { version } }"), null, "an anonymous query is not what we send");
  assert.equal(rootFieldOf("fragment X on Y { a }"), null);
});

// ---- the contract with the gateway's schema ----

interface SdlField {
  /** Argument name to its declared type, e.g. `limit: Int`, `kind: CaptureKind!`. */
  args: Map<string, string>;
  /** The result type with list and non-null markers stripped: `Session`, `JSON`, `String`. */
  type: string;
  /** Whether the result is an object type (needs a selection) rather than a scalar or enum. */
  object: boolean;
}

interface Sdl {
  types: Map<string, Map<string, SdlField>>;
  scalars: Set<string>;
  enums: Map<string, Set<string>>;
}

/** Strips `"""..."""` and `"..."` descriptions and `#` comments, which may contain braces. */
function stripDescriptions(sdl: string): string {
  return sdl
    .replace(/"""[\s\S]*?"""/g, "")
    .replace(/"(?:[^"\\]|\\.)*"/g, "")
    .replace(/#[^\n]*/g, "");
}

/** `type X { ... }`, `extend type X { ... }`, `enum E { ... }` and `scalar S`, by regex over a cleaned SDL. */
function parseSdl(raw: string): Sdl {
  const sdl = stripDescriptions(raw);
  const types = new Map<string, Map<string, SdlField>>();
  const scalars = new Set(["Int", "Float", "String", "Boolean", "ID"]);
  const enums = new Map<string, Set<string>>();

  for (const m of sdl.matchAll(/\bscalar\s+(\w+)/g)) {
    scalars.add(m[1]);
  }
  for (const m of sdl.matchAll(/\benum\s+(\w+)\s*\{([^}]*)\}/g)) {
    enums.set(m[1], new Set(m[2].split(/\s+/).filter(Boolean)));
  }
  for (const m of sdl.matchAll(/(?:extend\s+)?type\s+(\w+)\s*\{([^}]*)\}/g)) {
    const fields = types.get(m[1]) ?? new Map<string, SdlField>();
    //one field per line: `name(args): Type! @directive(...)`
    for (const line of m[2].split("\n")) {
      const f = /^\s*(\w+)\s*(?:\(([^)]*)\))?\s*:\s*([\w![\]]+)/.exec(line);
      if (!f) continue;
      const args = new Map<string, string>();
      for (const a of (f[2] ?? "").split(",")) {
        const p = /^\s*(\w+)\s*:\s*([\w![\]]+)/.exec(a);
        if (p) args.set(p[1], p[2]);
      }
      const type = f[3].replace(/[![\]]/g, "");
      fields.set(f[1], { args, type, object: false });
    }
    types.set(m[1], fields);
  }
  for (const fields of types.values()) {
    for (const field of fields.values()) {
      field.object = !scalars.has(field.type) && !enums.has(field.type);
    }
  }
  return { types, scalars, enums };
}

const SCHEMA = parseSdl(readFileSync(path.join(import.meta.dirname, "__fixtures__", "schema.graphql"), "utf8"));

/** `name(args)? { ...selection }` or `name(args)?`, walked recursively against a parent type. */
function checkSelection(body: string, parent: string, where: string, declaredVars: Map<string, string>): void {
  const fields = SCHEMA.types.get(parent);
  assert.ok(fields, `${where}: no type ${parent} in the schema`);
  let i = 0;
  while (i < body.length) {
    const rest = body.slice(i);
    const m = /^\s*(\w+)\s*/.exec(rest);
    if (!m) {
      assert.match(rest, /^\s*$/, `${where}: unreadable selection near "${rest.slice(0, 30)}"`);
      break;
    }
    const name = m[1];
    i += m[0].length;
    const field = fields.get(name);
    assert.ok(field, `${where}: ${parent}.${name} is not in the schema`);

    //arguments: name: $var pairs
    if (body[i] === "(") {
      const close = body.indexOf(")", i);
      const argText = body.slice(i + 1, close);
      i = close + 1;
      for (const a of argText.split(",")) {
        const p = /^\s*(\w+)\s*:\s*\$(\w+)\s*$/.exec(a);
        assert.ok(p, `${where}: ${parent}.${name} argument "${a.trim()}" must be name: $variable`);
        const declared = field.args.get(p[1]);
        assert.ok(declared, `${where}: ${parent}.${name} has no argument ${p[1]}`);
        const varType = declaredVars.get(p[2]);
        assert.ok(varType, `${where}: $${p[2]} is not declared`);
        //a variable may be declared non-null where the argument is nullable, never the reverse
        assert.equal(varType.replace(/!$/, ""), declared.replace(/!$/, ""), `${where}: $${p[2]} is ${varType}, ${name}.${p[1]} takes ${declared}`);
        if (declared.endsWith("!")) {
          assert.ok(varType.endsWith("!"), `${where}: ${name}.${p[1]} is required, $${p[2]} must be ${declared}`);
        }
      }
      i += (/^\s*/.exec(body.slice(i)) ?? [""])[0].length;
    }

    //selection: a balanced block
    if (body[i] === "{") {
      let depth = 0;
      let j = i;
      for (; j < body.length; j++) {
        if (body[j] === "{") depth++;
        if (body[j] === "}") depth--;
        if (depth === 0) break;
      }
      assert.ok(field.object, `${where}: ${parent}.${name} is a ${field.type} and takes no selection`);
      checkSelection(body.slice(i + 1, j), field.type, `${where} > ${name}`, declaredVars);
      i = j + 1;
    } else {
      assert.ok(!field.object, `${where}: ${parent}.${name} is a ${field.type} and needs a selection`);
    }
  }
}

for (const [name, document] of Object.entries(DOCUMENTS)) {
  test(`${name} matches the gateway's schema`, () => {
    const head = /^\s*(query|mutation)\s+\w+\s*(?:\(([^)]*)\))?\s*\{([\s\S]*)\}\s*$/.exec(document);
    assert.ok(head, "an operation");
    const declaredVars = new Map<string, string>();
    for (const v of (head[2] ?? "").split(",")) {
      const p = /^\s*\$(\w+)\s*:\s*([\w![\]]+)\s*$/.exec(v);
      if (p) declaredVars.set(p[1], p[2]);
    }
    for (const type of declaredVars.values()) {
      const bare = type.replace(/[![\]]/g, "");
      assert.ok(SCHEMA.scalars.has(bare) || SCHEMA.enums.has(bare), `$ of type ${type}: no such scalar or enum`);
    }
    checkSelection(head[3], head[1] === "query" ? "Query" : "Mutation", name, declaredVars);
  });
}

test("the walker reads the schema it is given", () => {
  assert.ok(SCHEMA.types.get("Query")?.has("health"));
  assert.ok(SCHEMA.types.get("Mutation")?.has("captureFile"));
  assert.equal(SCHEMA.types.get("Mutation")?.get("captureFile")?.args.get("kind"), "CaptureKind!");
  assert.ok(SCHEMA.enums.get("CaptureKind")?.has("PCAP"));
  assert.equal(SCHEMA.types.get("Query")?.get("sessions")?.type, "SessionPage");
  assert.equal(SCHEMA.types.get("Query")?.get("queues")?.object, false, "JSON is a scalar");
  assert.throws(
    () => checkSelection("health { nope }", "Query", "probe", new Map()),
    /Health\.nope is not in the schema/
  );
  assert.throws(
    () => checkSelection("queues { a }", "Query", "probe", new Map()),
    /takes no selection/
  );
});
