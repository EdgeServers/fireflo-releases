import { strict as assert } from "node:assert";
import { test } from "node:test";

import { byAccount, byReason, reasonKey } from "./failure-groups.ts";

const row = (account: string, errCode: string, messages: number, lastSeen = "2026-10-21T10:00:00.000Z") =>
  ({ finalState: "FAILED", dlrState: 5, errCode, account, messages, lastSeen });

test("the reasons list sums the accounts back together and keeps the newest occurrence", () => {
  const rows = byReason([row("a", "0B", 3, "2026-10-21T09:00:00.000Z"), row("b", "0B", 4, "2026-10-21T11:00:00.000Z"), row("a", "45", 1)]);
  assert.deepEqual(rows.map((r) => [r.errCode, r.messages, r.lastSeen]), [
    ["0B", 7, "2026-10-21T11:00:00.000Z"],
    ["45", 1, "2026-10-21T10:00:00.000Z"],
  ]);
  assert.equal(rows[0].account, undefined, "a reason row belongs to no one account");
  assert.equal(reasonKey(rows[0]), "FAILED|5|0B", "the same key dismissals use");
});

test("the account ring names the top accounts and folds the rest into Other", () => {
  const rows = [row("a", "0B", 10), row("b", "0B", 8), row("c", "45", 6), row("d", "45", 4), row("e", "0B", 2), row("f", "0B", 1)];
  const ring = byAccount(rows, 4);
  assert.deepEqual(ring.map((s) => [s.account, s.accounts, s.messages]), [
    ["a", 1, 10], ["b", 1, 8], ["c", 1, 6], ["d", 1, 4], [null, 2, 3],
  ]);
  assert.deepEqual(ring[4].reasons.map((r) => r.messages), [3], "Other's reasons are summed too");
});

test("one account more than the top is shown by name rather than as an Other of one", () => {
  const ring = byAccount([row("a", "0B", 5), row("b", "0B", 4), row("c", "0B", 3)], 2);
  assert.deepEqual(ring.map((s) => s.account), ["a", "b", "c"]);
});

test("an account's slice carries its reasons largest first", () => {
  const ring = byAccount([row("a", "45", 2), row("a", "0B", 9)]);
  assert.deepEqual(ring[0].reasons.map((r) => [r.row.errCode, r.messages]), [["0B", 9], ["45", 2]]);
});
