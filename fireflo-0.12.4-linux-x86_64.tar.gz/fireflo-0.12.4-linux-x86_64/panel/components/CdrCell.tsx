"use client";
import { useState } from "react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import type { CdrColumn } from "@/lib/cdr-columns";
import type { CdrRow } from "@/lib/cdr-request";
import { formatTimestamp } from "@/lib/datetime";
import { FINAL_STATE_LABELS, SHORT_FINAL_STATE_LABELS, labelFor } from "@/lib/labels";
import { money } from "@/lib/format";

/**
 * One cell of a call-record table, rendered by the format its column declares.
 *
 * <p>Lifted out of `CdrsClient`, where it was module-private, when the customer portal needed the
 * same thing. It is worth naming what the portal was doing instead: `String(c.from(row))`, which
 * ignores the `format` field on the very catalogue it was reading. So timestamps arrived as raw ISO
 * text, and — the one that is money — an amount is a BIGINT scaled by 10 000, so a billed charge of
 * `0.1250` was shown to the customer as <strong>1250</strong>.
 *
 * <p>That is the argument for one renderer rather than two. The columns were already shared; only
 * the rendering was duplicated, and the duplicate was the one nobody was looking at.
 *
 * <p>The link is a prop rather than a constant because the two surfaces differ there and only
 * there: an operator's timestamp opens `/cp/cdrs/<id>`, which a customer may not reach. Passing no
 * `detailHref` renders the same cell without a link, rather than rendering a link that 404s.
 */
export function CdrCell({
  column,
  row,
  detailHref,
}: {
  column: CdrColumn;
  row: CdrRow;
  /** Where this row's detail lives, or null for a surface that has none. */
  detailHref?: (row: CdrRow) => string | null;
}) {
  const value = column.from(row);

  if (column.format === "outcome") {
    return <Outcome row={row} />;
  }
  if (value == null || value === "") {
    return <span className="text-muted-foreground">—</span>;
  }

  switch (column.format) {
    case "longtext":
      return <LongText value={String(value)} />;

    case "time": {
      //suppressHydrationWarning on every one of these: the server renders in the host's zone and the
      //browser in the viewer's, and React 19 throws on the mismatch rather than patching it up
      const rendered = formatTimestamp(String(value));
      const href = column.id === "submittedAt" ? detailHref?.(row) : null;
      if (!href) {
        return (
          <span className="whitespace-nowrap tabular-nums" suppressHydrationWarning>
            {rendered}
          </span>
        );
      }
      return (
        //the way into the detail view: a link on a cell that is already there, rather than a column
        //of its own on a table that has a chooser
        <Link href={href} className="whitespace-nowrap tabular-nums hover:underline" suppressHydrationWarning>
          {rendered}
          <span className="block text-sm text-muted-foreground" title={row.gatewayMsgId}>
            {row.gatewayMsgId.slice(0, 12)}
            {segment(row)}
          </span>
        </Link>
      );
    }

    case "money":
      return <span className="tabular-nums">{money(Number(value))}</span>;

    //a rate is per message, not a total: at the platform's two places 0.0450 would read 0.05, so it
    //keeps all four before trailing zeros are trimmed
    case "rate":
      return <span className="tabular-nums">{money(Number(value), "", 4)}</span>;

    case "percent":
      return <span className="tabular-nums">{Number(value).toFixed(2)}%</span>;

    case "number":
      return <span className="tabular-nums">{String(value)}</span>;

    case "id":
      return <span className="font-mono text-sm">{String(value)}</span>;

    default:
      return <span className="tabular-nums">{String(value)}</span>;
  }
}

/** Only shown when there is something to say — an unretried single-part message needs no annotation. */
export function segment(r: CdrRow): string {
  const parts: string[] = [];
  if (r.partCount > 1) {
    parts.push(`part ${r.partNo}/${r.partCount}`);
  }
  if (r.retryCount > 0) {
    parts.push(`retry ${r.retryCount}`);
  }
  return parts.length ? ` · ${parts.join(" · ")}` : "";
}

/**
 * What an outcome badge needs, and nothing else.
 *
 * <p>Deliberately not `CdrRow`. That interface has some forty-five fields, so asking for it made
 * this badge unreachable from any surface holding less than a whole call record — and the dashboard,
 * whose rows carry five fields, grew a second badge with its own idea of which states are red. A
 * structural type is the whole fix: every existing caller passes a `CdrRow` and still compiles,
 * because a `CdrRow` already has both of these.
 */
export interface HasOutcome {
  /** null means no receipt has arrived, which is pending rather than failed. */
  finalState: string | null;
  errCode?: string | null;
}

/**
 * The outcome, as a badge.
 *
 * <p>Exported because both tables also use it outside a cell — in the card layout each falls back to
 * on a narrow screen — and because the portal dashboard's two panels use it with no table at all.
 *
 * @param compact for a column too narrow for a sentence in a pill: the short label, and no error
 *     code beneath. Both of those belong on the caller's own line when it has one — "Rejected on
 *     submission" wraps to three lines inside a badge in a half-width panel
 */
export function Outcome({ row, compact }: { row: HasOutcome; compact?: boolean }) {
  if (!row.finalState) {
    return <Badge variant="outline">Awaiting receipt</Badge>;
  }
  const variant = row.finalState === "DELIVERED" ? "success" : "destructive";
  const labels = compact ? SHORT_FINAL_STATE_LABELS : FINAL_STATE_LABELS;
  return (
    <span className="inline-flex flex-col items-start gap-0.5">
      <Badge variant={variant} className="whitespace-nowrap">
        {labelFor(labels, row.finalState)}
      </Badge>
      {!compact && row.errCode && (
        <span className="text-sm text-muted-foreground">error {row.errCode}</span>
      )}
    </span>
  );
}

/**
 * A message body in a table cell.
 *
 * <p>One line until asked otherwise. A body is up to 1,600 characters and a page is fifty rows, so
 * rendering them whole turns a table into a wall — but truncating with no way back is worse on the
 * portal, which has no detail view at all: for a customer this cell is the only place their own
 * message exists.
 *
 * <p>Clicking toggles rather than opening anything, because the alternative on the portal would be a
 * detail route that does not exist, and on the operator side a trip away from a list somebody is
 * mid-scan of.
 */
function LongText({ value }: { value: string }) {
  const [open, setOpen] = useState(false);
  //cheap enough to be worth avoiding a button that does nothing: a short message just renders
  const clipped = value.length > 60;

  if (!clipped) {
    return <span className="break-words">{value}</span>;
  }
  return (
    <button
      type="button"
      onClick={() => setOpen((v) => !v)}
      title={open ? "Show less" : "Show the whole message"}
      aria-expanded={open}
      className={`max-w-xs cursor-pointer text-left break-words hover:text-foreground ${
        open ? "" : "line-clamp-1"
      }`}
    >
      {value}
    </button>
  );
}
