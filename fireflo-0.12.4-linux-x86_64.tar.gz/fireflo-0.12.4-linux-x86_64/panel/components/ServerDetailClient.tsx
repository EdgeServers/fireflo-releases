"use client";
import { useState } from "react";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClasses } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Tabs } from "@/components/ui/tabs";
import { AdvancedToggle } from "./AdvancedToggle";
import { CardActions, FactGrid, Figures, HealthStrip } from "./CardBits";
import { BindList, ConnectionStatus, LiveTrafficControls } from "./ConnectionStatus";
import { DangerAction } from "./DangerAction";
import { ProductReadiness } from "./ProductReadiness";
import { SettingsList } from "./SettingsList";
import { WorkerForm } from "./WorkerForm";
import { useHealth } from "./useHealth";
import { useWorkers } from "./useWorkers";
import { useAdvanced } from "@/hooks/useAdvanced";
import { cn } from "@/lib/utils";
import { verdictFor } from "@/lib/worker-verdict";
import { KIND, isOn, trafficKey } from "@/lib/worker-types";
import { EmptyState } from "@/components/ui/empty-state";

type Tab = "status" | "settings" | "sessions";

/**
 * One listener, in full -- the server twin of {@link VendorDetailClient}, with the same shape:
 * the traffic controls in the header, tabs on the left, a rail of what identifies it on the right.
 * No cost rates and no error codes, because a listener is charged nothing and dials nobody.
 */
export function ServerDetailClient({ name }: { name: string }) {
  const {
    workers, error, errorFor, loading, busy, busyLabel,
    load, setEnabled, setProperty, remove,
  } = useWorkers(KIND.server);
  const { health, byFullName, tpsHistory } = useHealth();
  const [tab, setTab] = useState<Tab>("status");
  const [editing, setEditing] = useState(false);
  const [advanced, setAdvanced] = useAdvanced("server");

  const worker = workers.find((w) => w.name === name);

  if (!worker) {
    return (
      <div className="space-y-5">
        <Link href="/cp/servers" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Servers
        </Link>
        <EmptyState>
          {loading ? "Loading…" : error || `No listener called '${name}'.`}
        </EmptyState>
      </div>
    );
  }

  if (editing) {
    return (
      <WorkerForm
        type={KIND.server}
        worker={worker}
        onCancel={() => setEditing(false)}
        onSaved={async () => {
          setEditing(false);
          await load();
        }}
      />
    );
  }

  const key = trafficKey(worker);
  const live = byFullName.get(key);
  const verdict = verdictFor(worker, byFullName, KIND.server);
  const suspended = isOn(worker, "suspend");
  const paused = isOn(worker, "pause");
  const port = prop(worker, "srv.port");
  const ceiling = Number(prop(worker, "srv.maxConnections"));
  const capacity = Number.isFinite(ceiling) && ceiling > 0 ? { kind: "ceiling" as const, value: ceiling } : null;

  const tabs: { id: Tab; label: string }[] = [
    { id: "status", label: "Status" },
    { id: "settings", label: `Listener settings · ${worker.properties.length}` },
    { id: "sessions", label: `Connections · ${live?.sessions?.length ?? 0}` },
  ];

  return (
    <div className="space-y-5">
      <Link href="/cp/servers" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Servers
      </Link>

      <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_300px]">
      <Card className={cn("min-w-0", verdict.tone === "destructive" && "border-destructive")}>
        <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
          <span className="text-base font-medium">{worker.name}</span>
          {port && <span className="font-mono text-xs text-muted-foreground">port {port}</span>}
          <Badge variant={verdict.tone}>{verdict.label}</Badge>
          {worker.label && <span className="text-xs text-muted-foreground">{worker.label}</span>}
          <CardActions>
            <AdvancedToggle on={advanced} onChange={setAdvanced} />
            <Link href={`/cp/cdrs?systemId=${encodeURIComponent(worker.name)}`} className={buttonClasses({ variant: "outline", size: "sm" })}>
              Messages →
            </Link>
            {advanced && (
              <DangerAction
                label="Delete"
                confirmLabel={`Delete ${worker.name}`}
                consequence="Every customer bound to this listener is disconnected."
                busy={busy === worker.name}
                onConfirm={async () => {
                  await remove(worker.name);
                  window.location.assign("/cp/servers");
                }}
              />
            )}
          </CardActions>
        </CardHeader>
        <CardContent className="space-y-4 pt-3">
          {errorFor === worker.name && error && <HealthStrip tone="destructive">{error}</HealthStrip>}

          <Tabs label="Listener" items={tabs} active={tab} onSelect={setTab} />

          {tab === "status" && (
            <div className="space-y-3">
              <ConnectionStatus
                type={KIND.server}
                live={live}
                verdict={verdict}
                paused={paused}
                capacity={capacity}
                windowSeconds={health?.tps_window_seconds}
                tpsHistory={tpsHistory.get(key)}
              />
              {/* what would stop binding if this listener began requiring a product: the decision is
                  made in its settings, so the answer sits beside them */}
              <ProductReadiness />
            </div>
          )}

          {tab === "settings" && (
            <div className="space-y-4">
              <SettingsList
                type={KIND.server}
                properties={worker.properties}
                empty="No settings — the gateway will use its own defaults, including the listen port."
              />
              {advanced && !!worker.properties.length && (
                <div className="border-t border-dashed border-border pt-3">
                  <p className="mb-2 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">Every stored key</p>
                  <FactGrid facts={worker.properties.map((p) => ({ label: p.key, value: p.value, mono: true }))} />
                </div>
              )}
            </div>
          )}

          {tab === "sessions" && <BindList type={KIND.server} live={live} />}
        </CardContent>
        {/* actions on the listener as a whole sit at the foot, as on the vendor page: Edit and
            Disable on the left, and the traffic controls take the rest of the row and right-align
            themselves */}
        <CardFooter className="border-t border-border pt-3">
          <Button variant="outline" size="sm" onClick={() => setEditing(true)}>Edit</Button>
          <Button variant="ghost" size="sm" disabled={busy === worker.name} onClick={() => setEnabled(worker.name, !worker.enabled)}>
            {worker.enabled ? "Disable" : "Enable"}
          </Button>
          <LiveTrafficControls
            name={worker.name}
            type={KIND.server}
            live={live}
            verdict={verdict}
            suspended={suspended}
            paused={paused}
            busy={busy === worker.name}
            busyLabel={busyLabel}
            onSuspend={(on) => setProperty(worker.name, "suspend", on, on ? "Stop sending" : "Resume sending")}
            onPause={(on) => setProperty(worker.name, "pause", on, on ? "Hold" : "Release hold")}
          />
        </CardFooter>
      </Card>

      <div className="min-w-0 space-y-4 xl:sticky xl:top-4">
        <Card>
          <CardHeader className="flex flex-row items-center gap-2 space-y-0 border-b border-border">
            <span className="text-sm font-medium">Right now</span>
            <span className="text-xs text-muted-foreground">refreshed every 10s</span>
          </CardHeader>
          <CardContent className="space-y-3 pt-3">
            <Badge variant={verdict.tone}>{verdict.label}</Badge>
            {verdict.detail && <p className="text-xs text-muted-foreground">{verdict.detail}</p>}
            <Figures
              figures={[
                { value: live?.bound ?? "—", label: capacity ? `connected of ${capacity.value}` : "connected" },
                { value: live?.held_inbound ?? "—", label: "held inbound", tone: live?.held_inbound ? "warning" : "default" },
                { value: live?.tps_measured != null ? live.tps_measured : "—", label: "tps now" },
              ]}
            />
            {live?.last_error && (
              <HealthStrip tone="destructive">
                <span className="line-clamp-3">{live.last_error}</span>
              </HealthStrip>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center gap-2 space-y-0 border-b border-border">
            <span className="text-sm font-medium">Listener</span>
          </CardHeader>
          <CardContent className="pt-3">
            <FactGrid
              columns={2}
              facts={[
                //the address customers are told, not a bind address: the listener binds every interface
                { label: "Public IP", value: prop(worker, "srv.public.host") || "not set", mono: !!prop(worker, "srv.public.host"), muted: !prop(worker, "srv.public.host") },
                { label: "Port", value: port || "default", mono: !!port, muted: !port },
                { label: "Max connections", value: prop(worker, "srv.maxConnections") || "default", muted: !prop(worker, "srv.maxConnections") },
                { label: "Per IP", value: prop(worker, "srv.maxConnectionsPerIP") || "default", muted: !prop(worker, "srv.maxConnectionsPerIP") },
                { label: "System ID", value: prop(worker, "srv.systemId") || "—", mono: !!prop(worker, "srv.systemId"), muted: !prop(worker, "srv.systemId") },
                //a stored 0 is the gateway's "unlimited", and so is nothing stored at all
                { label: "Rate limit", value: Number(prop(worker, "tps")) > 0 ? `${prop(worker, "tps")} tps` : "none", muted: !(Number(prop(worker, "tps")) > 0) },
                { label: "TLS", value: prop(worker, "srv.tls.enabled") === "true" ? `on, port ${prop(worker, "srv.tls.port") || "?"}` : "off", muted: prop(worker, "srv.tls.enabled") !== "true" },
                { label: "Stop sending", value: suspended ? "on" : "off", muted: !suspended },
                { label: "Enabled", value: worker.enabled ? "yes" : "no", muted: !worker.enabled },
              ]}
            />
          </CardContent>
        </Card>
      </div>
      </div>
    </div>
  );
}

function prop(worker: { properties: { key: string; value: string }[] }, key: string): string {
  return worker.properties.find((p) => p.key === key)?.value ?? "";
}
