import { NodesClient } from "@/components/NodesClient";

export default function NodesPage() {
  return <NodesClient />;
}
