"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { ChevronLeft, ChevronRight, Columns3 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CdrCell, Outcome } from "./CdrCell";
import { ColumnChooser } from "./ColumnChooser";
import { CdrFilterBar } from "./CdrFilterBar";
import { ExportsCard } from "./ExportsCard";
import {
  EMPTY_FILTERS,
  type CdrCursor,
  type CdrFilterForm,
  type CdrRow,
  fromQuery,
  toQuery,
} from "@/lib/cdr-request";
import {
  CDR_COLUMNS,
  CDR_COLUMN_GROUPS,
  COLUMN_STORAGE_KEY,
  HEAVY_CDR_COLUMN_IDS,
  type ColumnChoice,
  readColumnChoice,
  resolveColumns,
  toggleColumn,
} from "@/lib/cdr-columns";
import { formatTimestamp } from "@/lib/datetime";
import { money } from "@/lib/format";

const PAGE_SIZE = 50;

/** Where a row's full history lives. Passed to {@link CdrCell}; the customer table has no equivalent. */
const detailHref = (row: CdrRow) => `/cp/cdrs/${encodeURIComponent(row.gatewayMsgId)}`;

/**
 * Individual call records, which no other page in this panel can show — everything else here is a
 * GROUP BY aggregate, and "what happened to this one message" is not a question an aggregate answers.
 *
 * <p>Paging is keyset, so Next is a cursor rather than an offset. That makes Previous something the
 * page has to remember rather than compute: the stack below holds the cursor each page started from.
 * The alternative — reversing the sort to page backwards — returns the right rows in the wrong order
 * and is the classic source of a "Previous" that skips a row every time the table is being written
 * to, which for a live gateway is always.
 *
 * <p>Which columns are shown is a per-operator choice kept in `localStorage`, not in the URL: the
 * query string is the filters' home and is meant to be shared, and a shared link should not impose
 * the sharer's columns on whoever opens it.
 */
export function CdrsClient() {
  const [filters, setFilters] = useState<CdrFilterForm>(EMPTY_FILTERS);
  const [rows, setRows] = useState<CdrRow[]>([]);
  const [nextCursor, setNextCursor] = useState<CdrCursor | null>(null);
  //one entry per page already visited; the last is the page currently shown
  const [history, setHistory] = useState<(CdrCursor | null)[]>([null]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [choice, setChoice] = useState<ColumnChoice | null>(null);
  const [chooserOpen, setChooserOpen] = useState(false);

  //read after mount, never in a lazy initialiser: localStorage does not exist while the page is
  //rendered on the server, and React 19 throws on the resulting mismatch rather than patching it up
  useEffect(() => {
    setChoice(readColumnChoice(window.localStorage.getItem(COLUMN_STORAGE_KEY)));
  }, []);

  function choose(id: string, enabled: boolean) {
    const next = toggleColumn(choice, id, enabled);
    setChoice(next);
    window.localStorage.setItem(COLUMN_STORAGE_KEY, JSON.stringify(next));
  }

  function resetColumns() {
    setChoice(null);
    window.localStorage.removeItem(COLUMN_STORAGE_KEY);
  }

  const columns = resolveColumns(choice);

  const columnIds = columns.map((c) => c.id);

  /**
   * @param ids the columns on screen, so the route knows whether to select the unbounded TLV
   *     columns. Passed in rather than closed over, which would make `load` change identity every
   *     time the chooser did — and the mount effect below depends on it, so that would re-run
   *     `setFilters(initial)` and silently reset the operator's filters back to the query string.
   */
  const load = useCallback(async (form: CdrFilterForm, cursor: CdrCursor | null, ids: string[]) => {
    setLoading(true);
    try {
      const params = toQuery(form);
      params.set("limit", String(PAGE_SIZE));
      //what the chooser is showing, so the route knows whether to select the unbounded TLV columns.
      //Without it they were never fetched and a ticked TLV column rendered blank
      params.set("columns", ids.join(","));
      if (cursor) {
        params.set("cursorTs", cursor.submittedAt);
        params.set("cursorId", cursor.id);
      }
      const res = await fetch(`/api/control/cdrs?${params}`);
      const body = await res.json();
      if (!res.ok) {
        throw new Error(body?.error ?? `Request failed (${res.status})`);
      }
      setRows(body.data?.rows ?? []);
      setNextCursor(body.data?.nextCursor ?? null);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not read call records");
      setRows([]);
      setNextCursor(null);
    } finally {
      setLoading(false);
    }
  }, []);

  /**
   * The first load honours the query string, which it previously ignored.
   *
   * <p>`fromQuery` existed and nothing called it, so every link into this page — "Messages sent
   * under this product", and now the two from the vendor and server cards — landed on an unfiltered
   * list showing all traffic. That reads as the filter having been applied and matched everything,
   * which is worse than an obvious failure.
   *
   * <p>Read in an effect rather than in a `useState` initialiser: `window` does not exist while this
   * renders on the server, and React 19 throws on the mismatch instead of patching it up.
   */
  useEffect(() => {
    const initial = fromQuery(new URLSearchParams(window.location.search));
    setFilters(initial);
    //the default columns carry nothing heavy, so the first load asks for no TLV column. An operator
    //whose saved choice includes one gets it from the effect below, once localStorage has been read
    void load(initial, null, []);
  }, [load]);

  /**
   * Re-fetches when a heavy column is ticked or unticked.
   *
   * <p>Only the heavy ones: every other column is already in the rows on screen, so toggling it is a
   * render and not a round trip. The TLV columns are the exception — they are selected only when
   * asked for, so ticking one would otherwise show a column of blanks until the next search, which
   * looks exactly like the data being missing.
   */
  const heavyChosen = HEAVY_CDR_COLUMN_IDS.filter((id) => columnIds.includes(id)).join(",");
  useEffect(() => {
    //nothing heavy on screen means nothing extra to fetch -- which is also the state at mount, so
    //this cannot race the effect above, and unticking needs no round trip either
    if (!heavyChosen) {
      return;
    }
    void load(filters, history[history.length - 1], heavyChosen.split(","));
  }, [heavyChosen]);   // eslint-disable-line react-hooks/exhaustive-deps

  function apply(next: CdrFilterForm) {
    //a filter change resets paging. Keeping the cursor would ask for "the page after this timestamp"
    //under a different filter, which lands somewhere arbitrary in the new result set
    setFilters(next);
    setHistory([null]);
    void load(next, null, columnIds);
  }

  function forward() {
    if (!nextCursor) {
      return;
    }
    setHistory((h) => [...h, nextCursor]);
    void load(filters, nextCursor, columnIds);
  }

  function back() {
    if (history.length < 2) {
      return;
    }
    const trimmed = history.slice(0, -1);
    setHistory(trimmed);
    void load(filters, trimmed[trimmed.length - 1], columnIds);
  }

  const page = history.length;
  const pending = rows.filter((r) => !r.finalState).length;

  return (
    <>
      <CdrFilterBar value={filters} onApply={apply} busy={loading} />

      {error && (
        <Card>
          <CardContent className="py-6 text-base text-destructive">{error}</CardContent>
        </Card>
      )}

      {!error && !rows.length && (
        <div className="rounded-xl border border-border p-12 text-center text-muted-foreground">
          {loading ? "Loading…" : "No messages match these filters in this period"}
        </div>
      )}

      {!!rows.length && (
        <>
          {/* said plainly rather than left to be inferred from a column of dashes: most traffic has
              no receipt yet at any given moment, and a table that looks half-empty reads as broken */}
          {pending > 0 && (
            <p className="text-base text-muted-foreground">
              {pending} of these {rows.length} are still awaiting a delivery receipt. That is normal —
              the gateway closes anything with no receipt after its expiry deadline.
            </p>
          )}

          <div className="hidden overflow-x-auto rounded-xl border border-border md:block">
            <table className="striped w-full text-sm">
              <thead className="border-b border-border bg-muted/50 text-left">
                <tr>
                  {columns.map((column) => (
                    <th
                      key={column.id}
                      className={`px-4 py-3 font-medium whitespace-nowrap ${column.align === "right" ? "text-right" : ""}`}
                    >
                      {column.header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr
                    key={r.id}
                    className="border-b border-border last:border-0"
                  >
                    {columns.map((column) => (
                      <td
                        key={column.id}
                        className={`px-4 py-3 ${column.align === "right" ? "text-right" : ""}`}
                      >
                        <CdrCell column={column} row={r} detailHref={detailHref} />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex flex-col gap-3 md:hidden">
            {rows.map((r) => (
              <Card key={r.id}>
                <CardContent className="space-y-2 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-medium tabular-nums">{r.destAddr ?? "—"}</p>
                      <Link
                        href={detailHref(r)}
                        className="text-sm text-muted-foreground hover:text-foreground"
                        suppressHydrationWarning
                      >
                        {formatTimestamp(r.submittedAt)}
                      </Link>
                    </div>
                    <Outcome row={r} />
                  </div>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-base">
                    <span className="text-muted-foreground">From</span>
                    <span className="text-right tabular-nums">{r.sourceAddr ?? "—"}</span>
                    <span className="text-muted-foreground">Account</span>
                    <span className="text-right">{r.accountId ?? "—"}</span>
                    <span className="text-muted-foreground">Vendor</span>
                    <span className="text-right">{r.vendor ?? "—"}</span>
                    <span className="text-muted-foreground">Billed</span>
                    <span className="text-right tabular-nums">
                      {r.price == null ? "—" : money(r.price)}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3">
            {/* no total and no page count: both need a COUNT(*) over the whole filtered set, which is
                the one query that does not stay fast as this table grows */}
            <p className="text-base text-muted-foreground">Page {page}</p>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5"
                onClick={() => setChooserOpen((v) => !v)}
                aria-expanded={chooserOpen}
              >
                <Columns3 className="h-4 w-4" />
                Columns
              </Button>
              <Button variant="outline" size="sm" onClick={back} disabled={page < 2 || loading} className="gap-1">
                <ChevronLeft className="h-4 w-4" />
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={forward}
                disabled={!nextCursor || loading}
                className="gap-1"
              >
                Next
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {chooserOpen && (
            <ColumnChooser
              columns={CDR_COLUMNS}
              groups={CDR_COLUMN_GROUPS}
              enabled={new Set(columns.map((c) => c.id))}
              onToggle={choose}
              onReset={resetColumns}
              /* a chooser that silently does nothing on a phone is worse than no chooser */
              note="On a narrow screen the cards below the table keep their fixed summary and ignore this."
            />
          )}
        </>
      )}

      <ExportsCard
        endpoint="/api/control/cdrs/export"
        params={toQuery(filters)}
        description={
          <>
            Prepared in the background and kept for seven days. The CSV carries every column of the
            record whatever is chosen above — two people exporting the same filters must get the same
            file, because spreadsheets address columns by letter.
          </>
        }
      />
    </>
  );
}

