"use client";
import { useState } from "react";
import Link from "next/link";
import { AlertTriangle, Package, Plus, RefreshCw } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button, buttonClasses } from "@/components/ui/button";
import { ProductReadiness } from "./ProductReadiness";
import { WorkerForm } from "./WorkerForm";
import { TrafficControlLegend, WorkerCard } from "./WorkerCard";
import { WorkerRail } from "./WorkerRail";
import { WorkerSummary } from "./WorkerSummary";
import { useWorkers } from "./useWorkers";
import { useHealth } from "./useHealth";
import { useRuntimeMetrics } from "./useRuntimeMetrics";
import { useAccordion } from "./useAccordion";
import { readsWorkersFromDatabase } from "@/lib/health-types";
import { SEVERITY, verdictFor } from "@/lib/worker-verdict";
import { KIND, trafficKey, type Worker } from "@/lib/worker-types";

/**
 * Servers: the listeners customers bind in to.
 *
 * <p>No traffic section, unlike vendors. Inbound volume is a question about a customer rather than
 * about the listener, and the Accounts page already answers it — a per-server total would only tell
 * you which port something arrived on.
 *
 * <p>This configures the listener. Which customers may bind to it is a different table
 * (`app_credential`) and is not editable here.
 */
/** The counter's reason tags, said in words an operator can act on. */
const REFUSAL_WORDS: Record<string, string> = {
  "ip-limit": "over the per-IP connection limit",
  "account-limit": "over the account's connection limit",
  credentials: "bad credentials",
  product: "product missing or unknown",
};

export function ServersClient() {
  const [editing, setEditing] = useState<Worker | "new" | null>(null);
  const {
    workers, error, errorFor, notice, loading, busy, busyLabel,
    load, setEnabled, setProperty, restart, remove, applyNow,
  } = useWorkers(KIND.server);
  const { health, error: healthError, byFullName, tpsHistory } = useHealth();
  const { snapshot } = useRuntimeMetrics();
  const fromDatabase = readsWorkersFromDatabase(health);
  //why binds were refused since restart (gateway I3). Empty means no counter OR no refusals; the
  //card only renders when a reason has actually counted, so an older gateway shows nothing new
  const bindRefusals = Object.entries(snapshot?.bindRefusals ?? {});

  const sorted = [...workers].sort((a, b) => severity(a) - severity(b) || a.name.localeCompare(b.name));

  function severity(worker: Worker): number {
    return SEVERITY[verdictFor(worker, byFullName, KIND.server).tone];
  }

  //sorted, not workers: the rail and the cards read from the same order or they contradict each other
  const { open, toggle, select, cardRef } = useAccordion(sorted);

  if (editing) {
    return (
      <WorkerForm
        type={KIND.server}
        worker={editing === "new" ? null : editing}
        onCancel={() => setEditing(null)}
        onSaved={async () => {
          setEditing(null);
          await load();
        }}
      />
    );
  }

  return (
    <>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <p className="max-w-2xl text-base text-muted-foreground">
          Listeners customers bind to, with how many are connected right now. Who is allowed to
          bind is set by credentials, not here.
        </p>
        <div className="ml-auto flex shrink-0 flex-wrap justify-end gap-2">
          {/* products belong next to the listeners: a product is what a customer's bind asks for by
              system_type, so it is chosen at the moment of binding to one of these */}
          <Link href="/cp/products" className={buttonClasses({ variant: "outline" })}>
            <Package className="h-4 w-4" />
            Products
          </Link>
          <Button variant="outline" onClick={applyNow} disabled={busy === "__reload"}>
            <RefreshCw className="mr-1.5 h-4 w-4" />
            {busy === "__reload" ? "Reloading…" : "Apply now"}
          </Button>
          <Button onClick={() => setEditing("new")}>
            <Plus className="mr-1.5 h-4 w-4" />
            Add server
          </Button>
        </div>
      </div>

      {fromDatabase === false && (
        <Card className="border-destructive/40">
          <CardContent className="flex items-start gap-2 py-4 text-base">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
            <span>
              <strong>Nothing on this page is loaded by the gateway.</strong> It is reading its
              workers from{" "}
              <code className="rounded bg-muted px-1 py-0.5 text-sm">smsg.properties</code>, not the
              database. These rows are stored and valid, and ignored. Start the gateway with{" "}
              <code className="rounded bg-muted px-1 py-0.5 text-sm">
                FIREFLO_CONFIG_SOURCE=db
              </code>{" "}
              to use them.
            </span>
          </CardContent>
        </Card>
      )}

      {/* above the listeners rather than inside one, because the answer is about the logins that
          would bind and is the same whichever listener the setting is turned on for */}
      <ProductReadiness />

      {/* only what belongs to the page; an action's failure is rendered on its own card */}
      {error && !errorFor && (
        <Card>
          <CardContent className="py-6 text-base text-destructive">{error}</CardContent>
        </Card>
      )}
      {bindRefusals.length > 0 && (
        <Card className="border-amber-500/40">
          <CardContent className="flex items-start gap-2 py-4 text-base">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />
            <span>
              <strong>Binds are being refused.</strong> Since the gateway last started:{" "}
              {bindRefusals
                .map(([reason, n]) => `${n} × ${REFUSAL_WORDS[reason] ?? reason}`)
                .join(", ")}
              . The connection ceilings are{" "}
              <code className="rounded bg-muted px-1 py-0.5 text-sm">srv.maxConnectionsPerIP</code>{" "}
              and the credential&apos;s max connections — a customer fleet behind one NAT counts as
              one IP.
            </span>
          </CardContent>
        </Card>
      )}

      {healthError && (
        <Card>
          <CardContent className="py-4 text-base text-muted-foreground">
            Live state unavailable: {healthError} — settings below are still current.
          </CardContent>
        </Card>
      )}
      {notice && (
        <Card>
          <CardContent className="py-4 text-base text-muted-foreground">{notice}</CardContent>
        </Card>
      )}

      {!errorFor && !error && !workers.length && (
        <div className="rounded-xl border border-border p-12 text-center text-muted-foreground">
          {loading ? "Loading…" : "No servers yet"}
        </div>
      )}

      <WorkerSummary
        workers={workers}
        byFullName={byFullName}
        type={KIND.server}
        loading={loading}
      />

      {/* the page owns the grid; see the note on VendorsClient and routing/page.tsx for why a child
          must not own its own split */}
      <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_16rem]">
        <div className="space-y-3">
          {sorted.map((server) => (
            <div key={server.name} ref={cardRef(server.name)} className="scroll-mt-4">
              <WorkerCard
                worker={server}
                type={KIND.server}
                live={byFullName.get(trafficKey(server))}
                busy={busy === server.name}
                busyLabel={busyLabel}
                error={errorFor === server.name ? error : undefined}
                open={open === server.name}
                onToggle={() => toggle(server.name)}
                onEdit={() => setEditing(server)}
                onToggleEnabled={(enabled) => setEnabled(server.name, enabled)}
                onSetProperty={(key, on, label) => setProperty(server.name, key, on, label)}
                onRestart={() => restart(server.name)}
                onRemove={() => remove(server.name)}
                windowSeconds={health?.tps_window_seconds}
                tpsHistory={tpsHistory.get(trafficKey(server))}
              />
            </div>
          ))}

          {!!workers.length && <TrafficControlLegend type={KIND.server} />}
        </div>

        <div className="hidden xl:sticky xl:top-0 xl:block">
          <WorkerRail
            workers={sorted}
            byFullName={byFullName}
            type={KIND.server}
            selected={open}
            onSelect={select}
          />
        </div>
      </div>
    </>
  );
}
