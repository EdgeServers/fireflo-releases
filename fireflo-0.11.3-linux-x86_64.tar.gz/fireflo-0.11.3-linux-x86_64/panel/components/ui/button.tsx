"use client";
import * as React from "react";
import { cn } from "@/lib/utils";

type Variant = "default" | "destructive" | "outline" | "ghost" | "link";
type Size = "default" | "sm" | "lg" | "icon";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

const variantClasses: Record<Variant, string> = {
  default:
    "bg-primary text-primary-foreground hover:bg-primary/90 shadow",
  destructive:
    "bg-destructive text-destructive-foreground hover:bg-destructive/90 shadow-sm",
  outline:
    "border border-input bg-background hover:bg-accent hover:text-accent-foreground shadow-sm",
  ghost: "hover:bg-accent hover:text-accent-foreground",
  link: "text-primary underline-offset-4 hover:underline",
};

/*
 * Taller below `md:`, unchanged above it.
 *
 * `h-11` is 44px and `h-9` is 36px, and 44 is the smallest target a thumb hits reliably. Set here
 * rather than at the call sites so every button on every page gets it from one edit, which is the
 * same reason `buttonClasses` exists.
 *
 * The breakpoint is `md:` and not `sm:`, which is the part worth knowing. A touch device is not
 * the same thing as a narrow one: the nav collapses to a drawer at `md:` (768px), so between 640
 * and 768 -- an iPad held in portrait -- the drawer is still showing and the device is still being
 * touched, while a `sm:` bump has already given the controls back to the pointer. Measured in that
 * band before this changed: 36px. Both breakpoints have to name the same idea of "touch", and the
 * drawer is the one that decides it.
 *
 * This was previously `sm:`, justified in a comment by "at the mobile root size h-9 measures 41px".
 * That root was 18px and stopped existing when the mobile step-down was removed; at the 20px root
 * that followed, `h-9` measured 45px and this bump was doing nothing at all.
 */
const sizeClasses: Record<Size, string> = {
  default: "h-11 px-4 py-2 md:h-9",
  //`sm` is h-11 below md:, the same as `default`. A small button is small on a pointer device and
  //still has to be hittable by a thumb, so the size prop narrows the DESKTOP height and leaves the
  //touch height alone. It was h-10 -- 40px, four short -- which passed only because the old 20px
  //root inflated it to 50.
  sm: "h-11 rounded-md px-3 text-sm md:h-8",
  lg: "h-12 rounded-md px-8 md:h-10",
  icon: "h-11 w-11 md:h-9 md:w-9",
};

/**
 * The class string a {@link Button} renders with, for the things that cannot be buttons.
 *
 * <p>A `<Link>` that should look like a button is the whole reason this is exported. The
 * alternatives were worse: hand-rolling the classes at the call site, which is how three subtly
 * different link-buttons appeared, or adding a Slot/`asChild` indirection to `Button` for one shape.
 */
export function buttonClasses({
  variant = "default",
  size = "default",
  className,
}: { variant?: Variant; size?: Size; className?: string } = {}): string {
  return cn(BASE, variantClasses[variant], sizeClasses[size], className);
}

const BASE =
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-base font-medium "
  + "transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring "
  + "disabled:pointer-events-none disabled:opacity-50";

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "default", size = "default", ...props }, ref) => (
    <button
      ref={ref}
      /* defaults to "button", not the HTML default of "submit". Every button in the worker form sets
         this explicitly today, so nothing changes -- but the next one added inside that <form>
         would otherwise submit the whole worker instead of doing its own job */
      type={props.type ?? "button"}
      className={buttonClasses({ variant, size, className })}
      {...props}
    />
  )
);
Button.displayName = "Button";
