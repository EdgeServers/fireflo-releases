import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * The page tier — the heading that names the whole screen. One per page, never inside a Card.
 *
 * <p>See the tier table in {@link ../ui/card.tsx}. This is the top rank: `text-xl font-semibold`,
 * 20px, and the only place `font-semibold` is used. Everything below it — entity, card, sub-card —
 * is `font-medium`, so the heading that names the screen is the one that looks like it does.
 *
 * <p>It exists because the tier was written down long before it was applied. Six of thirty-nine
 * pages emitted it and the rest had no page title at all, so "one per page" was aspirational and
 * every new page copied whichever neighbour it was pasted from. Four portal pages had drifted to
 * their own `h1`, split between `font-medium` and `font-semibold` at the same rank.
 *
 * <p>`h1` rather than the `h2` the operator pages used. There is no `h1` above it on the page —
 * the shell renders navigation, not a document title — so starting at `h2` skipped a level for
 * anything reading the outline.
 *
 * @param description one sentence under the title, for what the screen is for. Not a place for
 *     instructions; if a control needs explaining, explain it at the control.
 * @param actions controls that act on the whole page — an export, a range picker. They sit on the
 *     title's baseline rather than below it, so the heading and the thing that changes it are read
 *     together.
 */
export function PageHeader({
  title,
  description,
  actions,
  className,
}: {
  title: React.ReactNode;
  description?: React.ReactNode;
  actions?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-wrap items-start justify-between gap-3", className)}>
      <div className="min-w-0 space-y-1">
        <h1 className="text-xl font-semibold leading-tight">{title}</h1>
        {description && (
          <p className="text-sm leading-relaxed text-muted-foreground">{description}</p>
        )}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}
