/**
 * The FireFlo mark, and the product name it sits beside.
 *
 * <p>Served from `public/` as an `<img>` rather than inlined as JSX. Inlining would be tempting for
 * a 24px icon, but this export carries its own `<defs>` — four clip paths, three masks and a colour
 * matrix filter — and those ids would collide the moment two copies rendered on one page. An `<img>`
 * gives each instance its own document, costs one cached request, and keeps ~6 kB of `<path>` data
 * out of the JS bundle.
 *
 * <p>No `currentColor`: this is a fixed three-green brand mark and it must look the same in either
 * theme.
 */

/** Set from `package.json` at build time — see `next.config.ts`. */
export const APP_VERSION = process.env.NEXT_PUBLIC_APP_VERSION ?? "";

export function FireFloMark({ className = "h-6 w-6" }: { className?: string }) {
  //decorative: every place this appears, "FireFlo" is written next to it in text
  // eslint-disable-next-line @next/next/no-img-element
  return <img src="/fireflo-mark.svg" alt="" aria-hidden="true" className={`shrink-0 ${className}`} />;
}

/**
 * The mark and "FireFlo 0.3.3", as one unit.
 *
 * <p>The version is `text-sm` and muted beside a bold name, because it answers a question nobody
 * asks until something is wrong — and then it is the first thing they need.
 *
 * <p>`name` exists for the customer portal, which a tenant may run under its own brand — see
 * {@code lib/brand.ts}. It defaults to the product's own name, so every operator-side caller is
 * unchanged and stays that way on purpose.
 */
export function FireFloWordmark({
  className = "",
  name = "FireFlo",
}: { className?: string; name?: string }) {
  return (
    <span className={`flex min-w-0 items-baseline gap-1.5 ${className}`}>
      <span className="text-xl font-bold tracking-tight">{name}</span>
      {APP_VERSION && (
        <span className="text-sm font-normal tabular-nums text-muted-foreground">
          {APP_VERSION}
        </span>
      )}
    </span>
  );
}
