"use client";
import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { AccountForm } from "./AccountForm";
import { useAccounts } from "./useAccounts";
import type { AccountSummary } from "@/lib/account-types";
import { formatTimestamp } from "@/lib/datetime";
import { accountHref, surface } from "@/lib/panel-surface";

/** Who this account is, and the facts about it the form does not set. */
export function AccountSettingsClient({ id }: { id: string }) {
  const { accounts, orphans, save, busy, load } = useAccounts();
  //what this surface may show about what an account is charged -- see lib/panel-surface.ts
  const { pricing } = surface();
  const catalogued = accounts.find((a) => a.id === id) ?? null;
  const orphan = orphans.find((o) => o.id === id) ?? null;

  return (
    //form left, facts right. `xl` not `lg`: the form has its own two-column field grid inside, and
    //that wraps badly in two thirds of 1024px -- the same reasoning the vendors page records
    <div className="grid items-start gap-6 xl:grid-cols-[minmax(0,1fr)_20rem]">
      <Card>
        <CardHeader bar>
          <CardTitle className="text-base font-medium">
            {catalogued ? "Organisation" : "Name this account"}
          </CardTitle>
          <CardDescription>
            {catalogued
              ? "What this account is called, and where it sits."
              : "This id is in use but has no catalogue row."}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {catalogued ? (
            <AccountForm
              id={id}
              label={catalogued.label ?? ""}
              description={catalogued.description ?? ""}
              email={catalogued.email ?? ""}
              enabled={catalogued.enabled}
              resells={catalogued.resells}
              parentAccountId={catalogued.parentAccountId}
              childCount={"childCount" in catalogued ? catalogued.childCount : 0}
              //listing, reselling and the parent are the operator's. On the reseller surface the
              //write path pins all three, so offering them would be a form that lies about what
              //it saved -- see AccountForm
              allowHierarchy={pricing}
              busy={busy === id}
              onSave={save}
              onReload={load}
            />
          ) : (
            <NameIt id={id} orphan={orphan} busy={busy === id} onSave={(input) => void save(input)} />
          )}
        </CardContent>
      </Card>

      {catalogued && <SummaryRail id={id} account={catalogued} pricing={pricing} />}
    </div>
  );
}

/**
 * What is true of this account that the form does not set.
 *
 * <p>Read-only and free: every figure is already on `AccountSummary`, so the rail costs no request.
 * It exists because the form is one column of six fields and the tab was otherwise a single card
 * stretched across a desktop — and because "how many logins does this account have" is asked far
 * more often than it is answered without opening another tab.
 */
function SummaryRail({
  id,
  account,
  pricing,
}: {
  id: string;
  account: AccountSummary;
  pricing: boolean;
}) {
  const base = accountHref(id);
  return (
    <Card>
      <CardHeader bar>
        <CardTitle className="text-base font-medium">This account</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 text-sm">
        <dl className="space-y-2">
          <Row label="Id" value={<span className="font-mono">{id}</span>} />
          <Row label="Logins" value={String(account.credentialCount)} />
          {/* a count of price rules is still a fact about pricing, and on the reseller surface
              the query does not even fetch it -- rendering the zero would be a confident lie */}
          {pricing && <Row label="Rate rules" value={String(account.ruleCount)} />}
          {account.resells && <Row label="Holds" value={`${account.childCount} accounts`} />}
          {account.parentAccountId && (
            <Row label="Belongs to" value={<span className="font-mono">{account.parentAccountId}</span>} />
          )}
          <Row
            label="Edited"
            value={account.updatedAt
              ? <span suppressHydrationWarning>{formatTimestamp(account.updatedAt)}</span>
              : <span className="text-muted-foreground">never</span>}
          />
        </dl>
        <div className="flex flex-wrap gap-3 border-t border-border pt-3">
          <Link href={`${base}/logins`} className="text-primary hover:underline">Logins</Link>
          {/* the two tabs that do not exist on a surface without pricing. A link to a route that
              is not there is worse than no link: it 404s rather than saying why */}
          {pricing && (
            <>
              <Link href={`${base}/tariff`} className="text-primary hover:underline">Tariff</Link>
              <Link href={`${base}/statement`} className="text-primary hover:underline">Statement</Link>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-3">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="tabular-nums">{value}</dd>
    </div>
  );
}

/** Offers a name for an id that has one everywhere except in the catalogue. */
function NameIt({
  id,
  orphan,
  busy,
  onSave,
}: {
  id: string;
  orphan: { fromCredential: boolean; fromRateScope: boolean } | null;
  busy: boolean;
  onSave: (input: { id: string; label: string; enabled: boolean }) => void;
}) {
  const [label, setLabel] = useState("");
  return (
    <div className="space-y-2">
      <p className="text-xs text-muted-foreground">
        {orphan?.fromCredential
          ? "In use by a login, but nobody has given it a name."
          : orphan?.fromRateScope
            ? "Found only as a rate scope. That column also holds vendor names, so check this is an "
              + "account before naming it — a name here does not make it one."
            : "Nothing in the configuration mentions this id yet."}
      </p>
      <div className="flex flex-wrap items-end gap-2">
        <Field label="Name" htmlFor="adopt" className="min-w-48 flex-1">
          <Input id="adopt" value={label} onChange={(e) => setLabel(e.target.value)}
            placeholder="Acme Communications" />
        </Field>
        <Button disabled={busy || !label.trim()}
          onClick={() => onSave({ id, label: label.trim(), enabled: true })}>
          {busy ? "Saving…" : "Add to the catalogue"}
        </Button>
      </div>
    </div>
  );
}
