"use client";
import { useState } from "react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { ErrorCard, ErrorNote } from "./FormNotices";
import { RangePicker } from "./RangePicker";
import { useControlData, type Range } from "./useControlData";
import { count, money, percent } from "@/lib/format";
import { formatTimestamp } from "@/lib/datetime";
import { accountHref, surface } from "@/lib/panel-surface";

interface AccountRow {
  accountId: string | null;
  systemId: string | null;
  product: string | null;
  messages: number;
  delivered: number;
  failed: number;
  pending: number;
  billed: number;
  cost: number;
  deliveryRate: number | null;
  lastSeen: string | null;
  balance: number | null;
  currency: string | null;
  idle: boolean;
}

interface AccountsView {
  creditEnforced: boolean;
  accounts: AccountRow[];
}


/**
 * An account id from traffic, as a way into the account.
 *
 * <p>Null is a real value here and not a gap in the data: a login with no account field bills by its
 * system id, and traffic that predates the account being set has nothing to point at. Those stay
 * plain text rather than linking to a page for an account that does not exist.
 */
function AccountLink({ id }: { id: string | null }) {
  if (!id) {
    return <>—</>;
  }
  return (
    <Link href={accountHref(id)} className="hover:underline">
      {id}
    </Link>
  );
}

export function AccountsClient({
  account,
  chrome = true,
  range: controlledRange,
  onRangeChange,
}: {
  account?: string;
  /**
   * Whether to render this component's own heading, description, range picker and empty-state box.
   *
   * <p>False when a card around it already supplies them. Named for the one thing it does rather
   * than for the caller's situation -- "embedded" would invite it to mean denser, or narrower, or
   * read-only, and then nobody could say what setting it does.
   */
  chrome?: boolean;
  /** Controlled range, so the card's header can own the picker. Uncontrolled when absent. */
  range?: Range;
  onRangeChange?: (range: Range) => void;
} = {}) {
  const [ownRange, setOwnRange] = useState<Range>("24h");
  const range = controlledRange ?? ownRange;
  const setRange = onRangeChange ?? setOwnRange;
  const { data, error, loading } = useControlData<AccountsView>("accounts", range);
  //what this surface may show about what an account is charged -- see lib/panel-surface.ts. Here it
  //is one column: `cost` is what the operator paid a vendor, so billed minus cost is the margin.
  //The portal's own route does not send it either, so this is the second lock rather than the first
  const { pricing } = surface();
  const all = data?.accounts ?? [];
  //scoped when mounted on one account's page. Still several rows there: traffic splits by system id
  //and product, which is how the money splits, and folding those together would hide the case where
  //one login of two is failing
  const rows = account ? all.filter((r) => r.accountId === account) : all;

  const nothing = loading
    ? "Loading…"
    : account
      ? "Nothing sent in this period"
      : "No accounts sent in this period";

  return (
    <div className={chrome ? "space-y-6" : "space-y-3"}>
      {chrome && (
        <div className="flex items-center justify-between gap-4">
          <p className="text-base text-muted-foreground">
            Derived from traffic, so this is who actually sent — not who is provisioned. Configured
            credentials appear too when the gateway keeps them in the database.
          </p>
          <RangePicker value={range} onChange={setRange} />
        </div>
      )}

      {error && (chrome ? <ErrorCard error={error} /> : <ErrorNote error={error} />)}

      {!error && !rows.length && (
        chrome ? (
          <div className="rounded-xl border border-border p-12 text-center text-muted-foreground">
            {nothing}
          </div>
        ) : (
          <p className="py-4 text-base text-muted-foreground">{nothing}</p>
        )
      )}

      {!!rows.length && (
        <>
          {/* one table, always. The card stack this replaced was gated on md: and, inside a
              col-span-3 column, its `overflow-hidden` sibling clipped a nine-column table with no
              scrollbar -- three columns were simply unreachable. A card in a column is also worse
              than a scrolling table, because it dropped System ID, Product and Last seen entirely */}
          <div className={chrome ? "overflow-x-auto rounded-xl border border-border" : "overflow-x-auto"}>
            <table className="striped w-full text-sm">
              <thead className="border-b border-border text-left text-muted-foreground">
                <tr>
                  <th className="px-3 py-2.5 font-medium">Account</th>
                  <th className="px-3 py-2.5 font-medium">System ID</th>
                  <th className="px-3 py-2.5 font-medium">Product</th>
                  <th className="px-3 py-2.5 text-right font-medium">Messages</th>
                  <th className="px-3 py-2.5 text-right font-medium">Delivery</th>
                  <th className="px-3 py-2.5 text-right font-medium">Billed</th>
                  {pricing && <th className="px-3 py-2.5 text-right font-medium">Cost</th>}
                  <th className="px-3 py-2.5 text-right font-medium">Credit</th>
                  <th className="px-3 py-2.5 text-right font-medium">Last seen</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r, i) => (
                  <tr
                    key={`${r.accountId}-${r.systemId}-${r.product}-${i}`}
                    className="border-b border-border last:border-0"
                  >
                    <td className="px-3 py-2.5 font-medium">
                      <AccountLink id={r.accountId} />
                      {r.idle && (
                        <Badge variant="outline" className="ml-2">
                          idle
                        </Badge>
                      )}
                    </td>
                    <td className="px-3 py-2.5 text-muted-foreground">{r.systemId ?? "—"}</td>
                    <td className="px-3 py-2.5 text-muted-foreground">{r.product ?? "—"}</td>
                    <td className="px-3 py-2.5 text-right tabular-nums">{count(r.messages)}</td>
                    <td className="px-3 py-2.5 text-right">
                      <RateBadge rate={r.deliveryRate} />
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums">{money(r.billed)}</td>
                    {pricing && (
                      <td className="px-3 py-2.5 text-right font-mono tabular-nums text-muted-foreground">
                        {money(r.cost)}
                      </td>
                    )}
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums">
                      <Credit value={r.balance} currency={r.currency} enforced={data?.creditEnforced ?? false} />
                    </td>
                    <td className="px-3 py-2.5 text-right text-sm text-muted-foreground" suppressHydrationWarning>
                      {formatTimestamp(r.lastSeen) || "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {!data?.creditEnforced && (
            <p className="text-sm text-muted-foreground">
              Prepaid credit is not enforced on this gateway — no account has a balance, so there is
              nothing to count against. That is not the same as every account being at zero.
            </p>
          )}
        </>
      )}
    </div>
  );
}

function Credit({
  value,
  currency,
  enforced,
}: {
  value: number | null;
  currency: string | null;
  enforced: boolean;
}) {
  //"not enforced" and "out of credit" are different states and must not render the same
  if (!enforced) return <span className="text-muted-foreground">—</span>;
  if (value === null) return <span className="text-muted-foreground">no balance</span>;
  return <span className={value <= 0 ? "text-destructive" : ""}>{money(value, currency ?? "")}</span>;
}

function RateBadge({ rate }: { rate: number | null }) {
  if (rate === null) return <Badge variant="outline">—</Badge>;
  const variant = rate >= 0.9 ? "success" : rate >= 0.7 ? "outline" : "destructive";
  return <Badge variant={variant}>{percent(rate)}</Badge>;
}
