"use client";
import { useState } from "react";
import Link from "next/link";
import { Package, Plus, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DangerAction } from "./DangerAction";
import { ProductForm } from "./ProductForm";
import { useProducts } from "./useProducts";
import type { ProductInput, ProductSummary } from "@/lib/product-types";

/**
 * The product catalogue.
 *
 * <p>A product is the tariff a customer's bind selects, through `system_type`. The gateway learns it
 * from the wire and never from this table — so nothing here changes behaviour. What it changes is
 * whether anyone can tell what `premium` was supposed to mean.
 */
export function ProductsClient() {
  const { products, orphans, error, loading, busy, load, setEnabled, remove } = useProducts();
  const [editing, setEditing] = useState<ProductInput | "new" | null>(null);

  if (editing) {
    const isNew = editing === "new";
    return (
      <ProductForm
        initial={isNew ? { name: "", label: "", description: "", enabled: true, whitelistEnabled: true } : editing}
        isNew={isNew}
        onSaved={async () => {
          setEditing(null);
          await load();
        }}
        onCancel={() => setEditing(null)}
      />
    );
  }

  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-base text-muted-foreground">
          A product is what a customer&rsquo;s bind asks for as <code className="text-sm">system_type</code>.
        </p>
        <Button onClick={() => setEditing("new")} className="gap-2">
          <Plus className="h-4 w-4" />
          Add product
        </Button>
      </div>

      {/* the compensating control for having no foreign key on app_rate_rule.product -- on a fresh
          install this is where every product that actually exists shows up */}
      {!!orphans.length && (
        <Card className="border-amber-500/40">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base font-medium">
              <TriangleAlert className="h-4 w-4 text-amber-500" />
              In use, but not described here
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-base">
            <p className="text-muted-foreground">
              These are priced by a rate rule or selected by a credential, and have no catalogue
              entry. They work — nothing here is required — but nobody can tell what they mean.
            </p>
            <div className="flex flex-wrap gap-2">
              {orphans.map((name) => (
                <Button
                  key={name}
                  variant="outline"
                  size="sm"
                  onClick={() => setEditing({ name, label: "", description: "", enabled: true, whitelistEnabled: true })}
                >
                  Describe &lsquo;{name}&rsquo;
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {error && (
        <Card>
          <CardContent className="py-4 text-base text-destructive">{error}</CardContent>
        </Card>
      )}

      {!products.length && (
        <div className="rounded-xl border border-border p-12 text-center text-muted-foreground">
          {loading ? "Loading…" : "No products described yet"}
        </div>
      )}

      <div className="space-y-3">
        {products.map((p) => (
          <ProductCard
            key={p.name}
            product={p}
            busy={busy === p.name}
            onEdit={() =>
              setEditing({
                name: p.name,
                label: p.label,
                description: p.description,
                enabled: p.enabled,
                whitelistEnabled: p.whitelistEnabled,
              })
            }
            onToggle={() => setEnabled(p.name, !p.enabled)}
            removeConsequence={describeProductRemoval(p)}
            onRemove={() => remove(p.name)}
          />
        ))}
      </div>
    </>
  );
}

/**
 * What deleting a product actually costs.
 *
 * <p>Counts logins as well as rules. This once counted rules alone while the card above it displayed
 * the credential count, so a product no rule priced but a login still selected was offered for
 * deletion with nothing said — and the server allowed it.
 *
 * <p>The whitelist exemption is stated whenever it is in effect, not only when a rule happens to
 * price the product: losing the exemption is about traffic, and traffic comes from the logins.
 */
function describeProductRemoval(product: ProductSummary): string {
  const users = [
    product.ruleCount ? `prices ${product.ruleCount} rule(s)` : null,
    product.credentialCount ? `is the default product on ${product.credentialCount} login(s)` : null,
  ].filter(Boolean).join(", and ");

  const still = users
    ? `'${product.name}' still ${users}. Those keep working either way — nothing here is a foreign `
      + "key — so this only removes the description. "
    : "";
  const whitelist = product.whitelistEnabled
    ? ""
    : "It is exempt from sender ID and content checking, and deleting it ends that: this traffic "
      + "goes back under the whitelist and may start being refused.";

  return `${still}${whitelist}` || "Only the description goes; nothing prices or selects it.";
}

function ProductCard({
  product,
  busy,
  onEdit,
  onToggle,
  onRemove,
  removeConsequence,
}: {
  product: ProductSummary;
  busy: boolean;
  onEdit: () => void;
  onToggle: () => void;
  onRemove: () => void;
  /** What is still using this product, and whether deleting it ends a whitelist exemption. */
  removeConsequence: string;
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row flex-wrap items-start justify-between gap-3 pb-3">
        <div className="min-w-0">
          <CardTitle className="flex flex-wrap items-center gap-2 text-base font-medium">
            <Package className="h-4 w-4 shrink-0 text-muted-foreground" />
            {product.label || product.name}
            {product.label && <code className="text-sm font-normal text-muted-foreground">{product.name}</code>}
            {!product.enabled && <Badge variant="outline">unlisted</Badge>}
            {/* traffic deliberately going unchecked is worth seeing without opening the form, and
                only while it is actually in effect -- an unlisted product is not exempt */}
            {!product.whitelistEnabled && product.enabled && (
              <Badge variant="outline" className="border-amber-500/50 text-amber-600 dark:text-amber-400">
                not whitelist checked
              </Badge>
            )}
          </CardTitle>
          {product.description && (
            <p className="mt-1 text-base text-muted-foreground">{product.description}</p>
          )}
        </div>
        <div className="flex shrink-0 gap-2">
          <Link
            href={`/cp/products/${encodeURIComponent(product.name)}`}
            className="inline-flex h-8 items-center rounded-md border border-input bg-background px-3 text-sm font-medium shadow-sm transition-colors hover:bg-accent"
          >
            Pricing
          </Link>
          <Button variant="outline" size="sm" onClick={onEdit}>Edit</Button>
          <Button variant="ghost" size="sm" onClick={onToggle} disabled={busy}>
            {product.enabled ? "Unlist" : "List"}
          </Button>
          <DangerAction
            label="Delete"
            confirmLabel="Delete this product"
            consequence={removeConsequence}
            busy={busy}
            onConfirm={onRemove}
          />
        </div>
      </CardHeader>
      <CardContent className="flex flex-wrap gap-x-6 gap-y-1 pt-0 text-base text-muted-foreground">
        <span>
          <strong className="text-foreground tabular-nums">{product.ruleCount}</strong> rule
          {product.ruleCount === 1 ? "" : "s"} priced for it
          {product.scopeCount > 0 && ` across ${product.scopeCount} scope${product.scopeCount === 1 ? "" : "s"}`}
        </span>
        <span>
          <strong className="text-foreground tabular-nums">{product.credentialCount}</strong>{" "}
          credential{product.credentialCount === 1 ? "" : "s"} default to it
        </span>
      </CardContent>
    </Card>
  );
}
