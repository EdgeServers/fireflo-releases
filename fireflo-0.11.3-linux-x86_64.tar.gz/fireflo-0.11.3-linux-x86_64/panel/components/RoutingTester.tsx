"use client";
import { useState } from "react";
import { Beaker } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import type { RoutingExplanation } from "@/lib/routing-types";
import { trafficKey } from "@/lib/worker-types";
import { useRouting } from "./useRouting";
import { useWorkers } from "./useWorkers";

/** Message type presets a tester is likely to want; anything else can still be typed in. */
const TYPE_PRESETS = [
  { value: "", label: "Ordinary message (default)" },
  { value: "0", label: "0 — Inbound (MO)" },
  { value: "18", label: "18 — Delivery receipt (DLR)" },
];

/**
 * "Test a message": asks the gateway which rule a hypothetical message would hit, without sending
 * anything. Calls `/ops/routing/explain` through the panel's proxy, so the answer is the gateway's
 * own — the same `RoutingRule.matches`/`explainMismatch` calls the real router uses, not this
 * panel's reading of the conditions.
 *
 * <p>Works in both file and database mode: it asks the running gateway's live table set, not
 * `app_route_table`, so it is not gated on {@link readsRoutingFromDatabase} the way the editor is.
 *
 * <p>Self-contained rather than fed by props, the same way {@code GroupsClient} and {@code
 * DeliveryCheck} are: it lives in the routing page's right-hand rail, a sibling of {@code
 * RoutingClient} rather than a child of it, so it fetches its own table names and listener list.
 */
export function RoutingTester() {
  const { tables } = useRouting();
  const { workers: servers } = useWorkers("smppserver");
  const tableNames = tables.map((t) => t.name);
  const [table, setTable] = useState("default");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [type, setType] = useState("");
  const [product, setProduct] = useState("");
  const [ingateway, setIngateway] = useState("");
  const [result, setResult] = useState<RoutingExplanation | null>(null);
  const [error, setError] = useState("");
  const [running, setRunning] = useState(false);

  async function run() {
    setRunning(true);
    setError("");
    setResult(null);
    try {
      const params = new URLSearchParams();
      if (table) {
        params.set("table", table);
      }
      if (from) {
        params.set("from", from);
      }
      if (to) {
        params.set("to", to);
      }
      if (type) {
        params.set("type", type);
      }
      if (product) {
        params.set("product", product);
      }
      if (ingateway) {
        params.set("ingateway", ingateway);
      }
      const res = await fetch(`/api/control/routing/explain?${params.toString()}`);
      const json = await res.json();
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
      } else if (!json.data) {
        setError("Routing is not available on this gateway.");
      } else {
        setResult(json.data as RoutingExplanation);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setRunning(false);
    }
  }

  return (
    <Card>
      <CardHeader bar>
        <CardTitle className="flex items-center gap-2 text-base font-medium">
          <Beaker className="h-4 w-4" />
          Test a message
        </CardTitle>
        <CardDescription>
          Asks the gateway which rule a message like this would hit, without sending anything. This
          reads the gateway&apos;s own live tables, so it works the same whether routing is
          configured from a file or the database.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* The column gets NARROWER at xl, not wider: that is the breakpoint where this card moves
            into the page's one-third rail. So two fields across while the card is full width, and
            one once it is not. Read the other way round -- `lg:grid-cols-3`, which is what this was
            -- the form is worse at 1280px than at 1279px, because sm: and lg: are viewport queries
            and cannot see that the container just shrank to ~373px. `WorkerFields.tsx` records the
            same lesson from the other side of the page. */}
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-1">
          <Field label="Table" htmlFor="rt-table">
            <Select id="rt-table" value={table} onChange={(e) => setTable(e.target.value)}>
              {tableNames.map((name) => (
                <option key={name} value={name}>{name}</option>
              ))}
            </Select>
          </Field>
          <Field label="Type" htmlFor="rt-type">
            <Select id="rt-type" value={type} onChange={(e) => setType(e.target.value)}>
              {TYPE_PRESETS.map((p) => (
                <option key={p.value} value={p.value}>{p.label}</option>
              ))}
            </Select>
          </Field>
          <Field
            label="Arrived on"
            htmlFor="rt-ingateway"
            hint="Which listener the message came in on. An inbound message from a vendor is told apart by this and nothing else."
          >
            <Select id="rt-ingateway" value={ingateway} onChange={(e) => setIngateway(e.target.value)}>
              <option value="">— an HTTP-origin message</option>
              {servers.map((s) => (
                <option key={s.name} value={trafficKey(s)}>{trafficKey(s)}</option>
              ))}
            </Select>
          </Field>
          <Field label="From" htmlFor="rt-from">
            <Input id="rt-from" value={from} onChange={(e) => setFrom(e.target.value)} placeholder="WEB0TP" />
          </Field>
          <Field label="To" htmlFor="rt-to">
            <Input id="rt-to" value={to} onChange={(e) => setTo(e.target.value)} placeholder="61412345678" />
          </Field>
          <Field label="Product" htmlFor="rt-product">
            <Input id="rt-product" value={product} onChange={(e) => setProduct(e.target.value)} placeholder="(none)" />
          </Field>
        </div>

        <Button variant="outline" size="sm" disabled={running} onClick={run}>
          {running ? "Testing…" : "Test"}
        </Button>

        {error && <p className="text-sm text-destructive">{error}</p>}

        {result && <Result explanation={result} />}
      </CardContent>
    </Card>
  );
}

function Result({ explanation }: { explanation: RoutingExplanation }) {
  if (!explanation.tableFound) {
    return (
      <p className="text-sm text-destructive">
        No table named &apos;{explanation.table}&apos; exists.
      </p>
    );
  }
  if (!explanation.rules.length) {
    return <p className="text-sm text-muted-foreground">This table has no rules — it routes nothing.</p>;
  }

  return (
    <div className="space-y-2">
      {explanation.targetFunction === "LCR" && (
        <p className="text-sm text-muted-foreground">
          Least-cost table: every matching rule below is a candidate, and the cheapest wins — this
          tester has no vendor rate to compare, so it cannot say which.
        </p>
      )}
      <table className="striped w-full text-sm">
        <thead className="border-b border-border text-left text-muted-foreground">
          <tr>
            <th className="px-3 py-2 font-medium">#</th>
            <th className="px-3 py-2 font-medium">Target</th>
            <th className="px-3 py-2 font-medium">Verdict</th>
          </tr>
        </thead>
        <tbody>
          {explanation.rules.map((rule) => {
            const won = explanation.matchedIndex === rule.index;
            return (
              <tr key={rule.index} className="border-b border-border last:border-0">
                <td className="px-3 py-2 align-top text-muted-foreground">{rule.index}</td>
                <td className="px-3 py-2 align-top">
                  <span className="font-mono text-sm">{rule.target}</span>
                  {rule.label && (
                    <span className="block text-xs text-muted-foreground">{rule.label}</span>
                  )}
                </td>
                <td className="px-3 py-2 align-top">
                  {won && <Badge>matched — sends here</Badge>}
                  {!won && rule.matched && <Badge variant="outline">also matches</Badge>}
                  {!won && !rule.matched && rule.evaluable && (
                    <span className="text-xs text-muted-foreground">{rule.mismatch}</span>
                  )}
                  {!won && !rule.evaluable && (
                    <span className="text-xs text-muted-foreground">
                      needs a live vendor to evaluate — not tested
                    </span>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      {explanation.matchedIndex === null && explanation.targetFunction === "NORMAL" && (
        <p className="text-sm text-muted-foreground">No rule matches — this message would be unroutable.</p>
      )}
    </div>
  );
}
