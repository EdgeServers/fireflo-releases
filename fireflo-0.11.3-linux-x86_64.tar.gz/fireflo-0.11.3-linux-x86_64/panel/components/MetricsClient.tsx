"use client";
import { useState } from "react";
import { ChevronRight, Info, Search } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkline } from "./Sparkline";
import { MetricsTable, filterFamilies } from "./MetricsTable";
import { Input } from "@/components/ui/input";
import { useRuntimeMetrics } from "./useRuntimeMetrics";
import type { MetricGroup, RuntimeSnapshot } from "@/lib/runtime-metrics";
import { areasFrom, VERDICT_LABELS, type Area, type Verdict } from "@/lib/runtime-verdicts";
import { bytes, count, ratio } from "@/lib/format";
import { formatClockTime } from "@/lib/datetime";

/**
 * How hard the gateway process is working, in words rather than in metric names.
 *
 * <p>Five areas, each stating what is happening, whether it is a problem, and the rule behind that
 * judgement. The raw exposition data is still reachable, but behind one deliberate step — the
 * previous version dropped a reader from plain English to `pool_name=vert.x-internal-blocking` in a
 * single click, which is not progressive disclosure so much as a cliff.
 */
export function MetricsClient() {
  const { snapshot, history, error, loading } = useRuntimeMetrics();
  const [advanced, setAdvanced] = useState(false);
  const [query, setQuery] = useState("");

  if (loading && !snapshot) {
    return <div className="h-64 animate-pulse rounded-xl bg-muted" />;
  }
  if (!snapshot) {
    return (
      <Card>
        <CardContent className="py-6 text-base text-destructive">
          {error || "No metrics available."}
        </CardContent>
      </Card>
    );
  }

  const areas = areasFrom(snapshot.headline);
  const h = snapshot.headline;

  return (
    <>
      <Card>
        <CardContent className="flex flex-wrap items-start gap-3 py-4 text-base">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
          <p className="max-w-3xl text-muted-foreground">
            <strong className="text-foreground">This page is about the gateway itself, not the
            messages it carries.</strong>{" "}
            Nothing here counts messages, deliveries or vendor throughput — those are on the Overview
            and Live health pages. This is whether the software has the memory, processing power and
            connection capacity to keep doing its job.
          </p>
        </CardContent>
      </Card>

      {error && <p className="text-sm text-muted-foreground">Last reading failed: {error}</p>}

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-baseline justify-between gap-2 text-base font-medium">
            Recent trend
            {/* the buffer is per-tab and starts empty, so claiming more would be a lie */}
            <span className="text-sm font-normal text-muted-foreground">since this page opened</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Trend label="Memory" values={history.map((p) => p.heapUsed)} now={bytes(h.heapUsed)}
                 colour="var(--color-chart-1)" />
          <Trend label="Processor" values={history.map((p) => p.processCpu)} now={ratio(h.processCpu)}
                 colour="var(--color-chart-2)" />
          <Trend label="Tasks running" values={history.map((p) => p.threadsLive)}
                 now={count(h.threadsLive ?? 0)} colour="var(--color-chart-3)" />
          <Trend label="Work waiting" values={history.map((p) => p.workerQueued)}
                 now={count(h.workerQueued ?? 0)} colour="var(--color-chart-5)" />
        </CardContent>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        {areas.map((area) => (
          <AreaCard key={area.key} area={area} />
        ))}
      </div>


      <div className="space-y-3">
        <button
          type="button"
          onClick={() => setAdvanced((v) => !v)}
          className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
        >
          <ChevronRight className={`h-3 w-3 transition-transform ${advanced ? "rotate-90" : ""}`} />
          {advanced ? "Hide" : "Show"} the raw readings
        </button>
        {advanced && <RawReadings snapshot={snapshot} query={query} onQuery={setQuery} />}
      </div>

      {/* the snapshot arrives as a prop, so this renders on the server too -- in the host's zone,
          and against the host's idea of "today". Both differ from the reader's */}
      <p className="text-sm text-muted-foreground" suppressHydrationWarning>
        Read at {formatClockTime(snapshot.observedAt)}, refreshing every 10 seconds.
      </p>
    </>
  );
}

const TONE: Record<Verdict, { badge: "success" | "outline" | "destructive"; bar: string }> = {
  good: { badge: "success", bar: "var(--color-chart-1)" },
  watch: { badge: "outline", bar: "hsl(38 92% 50%)" },
  high: { badge: "destructive", bar: "var(--color-destructive)" },
  unknown: { badge: "outline", bar: "var(--color-muted-foreground)" },
};

function AreaCard({ area }: { area: Area }) {
  const tone = TONE[area.verdict];
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex flex-wrap items-center justify-between gap-2 text-base font-medium">
          {area.title}
          <Badge variant={tone.badge}>{VERDICT_LABELS[area.verdict]}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-base">{area.summary}</p>

        {area.fraction != null && (
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full transition-[width] duration-500"
              style={{
                width: `${Math.min(100, Math.max(0, area.fraction * 100))}%`,
                backgroundColor: tone.bar,
              }}
            />
          </div>
        )}

        {area.detail && <p className="text-sm text-muted-foreground">{area.detail}</p>}
        <p className="text-sm text-muted-foreground">{area.meaning}</p>
        {/* the threshold is published so the badge can be argued with; a verdict whose rule is
            hidden is a colour, not a judgement */}
        <p className="text-sm text-muted-foreground">{area.rule}</p>
      </CardContent>
    </Card>
  );
}

function Trend({
  label,
  values,
  now,
  colour,
}: {
  label: string;
  values: (number | null)[];
  now: string;
  colour: string;
}) {
  return (
    <div className="space-y-1">
      <div className="flex items-baseline justify-between gap-2 text-sm">
        <span className="text-muted-foreground">{label}</span>
        <span className="tabular-nums">{now}</span>
      </div>
      <Sparkline values={values} color={colour} className="h-10 w-full" />
    </div>
  );
}

/**
 * The unfiltered exposition data, with one search across every group.
 *
 * <p>One box rather than one per card. A measurement's group is not something you know before you
 * look — that is most of why you are searching — so a per-card filter would mean guessing which card
 * to type into.
 *
 * <p>Groups that match nothing disappear rather than showing an empty card, and the count says how
 * much is hidden. A filter that leaves eleven empty headings behind reads as broken.
 */
function RawReadings({
  snapshot,
  query,
  onQuery,
}: {
  snapshot: RuntimeSnapshot;
  query: string;
  onQuery: (value: string) => void;
}) {
  const groups = snapshot.groups
    .map((group) => ({ ...group, families: filterFamilies(group.families, query) }))
    .filter((group) => group.families.length > 0);
  const shown = groups.reduce((total, group) => total + group.families.length, 0);

  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="max-w-2xl text-sm text-muted-foreground">
          Everything the gateway publishes, exactly as it publishes it — {count(snapshot.familyCount)}{" "}
          measurements grouped by subject, using the software&apos;s own names. This is the same data a
          monitoring system would scrape, and it is here for investigating something the cards above
          cannot explain.
        </p>
        <div className="relative shrink-0">
          <Search className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => onQuery(e.target.value)}
            placeholder="name, description or label"
            aria-label="Search the raw readings"
            className="h-8 w-64 pl-7 text-sm"
          />
        </div>
      </div>

      {query.trim() && (
        <p className="text-xs text-muted-foreground">
          {shown === 0
            ? `Nothing matches "${query.trim()}".`
            : `${count(shown)} of ${count(snapshot.familyCount)} measurements match.`}
        </p>
      )}

      {groups.map((group) => (
        <Group key={group.key} group={group} />
      ))}
    </>
  );
}

function Group({ group }: { group: MetricGroup }) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium">{group.label}</CardTitle>
        <p className="text-xs text-muted-foreground">{group.hint}</p>
      </CardHeader>
      <CardContent>
        <MetricsTable families={group.families} />
      </CardContent>
    </Card>
  );
}
