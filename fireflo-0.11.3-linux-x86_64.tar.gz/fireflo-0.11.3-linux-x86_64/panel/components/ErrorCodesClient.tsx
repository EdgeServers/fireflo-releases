"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { ErrorCodeEditor } from "@/components/ErrorCodeEditor";
import { workerDefaultKey } from "@/lib/gateway-key-policy";
import {
  errorCodeProblem,
  formatErrorCodes,
  parseErrorCodes,
  type ErrorCodePair,
} from "@/lib/error-codes";
import type { Worker } from "@/lib/worker-types";

/**
 * The global error-code list — the one every vendor inherits.
 *
 * <h2>No vendor's mappings appear here, and that is the point</h2>
 *
 * <p>The first version of this screen held both tiers, on the argument that "a vendor list REPLACES
 * the global one" had nowhere to live if they were split. It does have somewhere — underneath that
 * vendor's own list, on that vendor's own page — and stacking every vendor below the global card
 * produced a page that grew with every carrier and buried the one you came for.
 *
 * <p>What DOES belong here is the one cross-vendor fact the global tier raises: <em>who is not using
 * this list</em>. So the foot of the page names the vendors that set a list of their own, with a
 * count and a link. Names and counts, never rows — reading a vendor's mappings means opening that
 * vendor.
 *
 * <h2>The gateway resolves this with no Java change</h2>
 *
 * <p>{@code FireFloConfigurationHandler.get} rewrites an unresolved
 * {@code outSms.instance.<vendor>.<prop>} to {@code outSms.default.<prop>}, so both keys written
 * here already reach every vendor that sets nothing itself. It does NOT union the two maps: a vendor
 * with a list of its own loses every entry below.
 */
const LIST_KEY = workerDefaultKey("dlr.errcodes");
const PASSTHROUGH_KEY = workerDefaultKey("dlr.errcodes.passthrough");

interface Override {
  name: string;
  count: number;
}

export function ErrorCodesClient() {
  const [pairs, setPairs] = useState<ErrorCodePair[]>([]);
  const [passthrough, setPassthrough] = useState(false);
  const [overrides, setOverrides] = useState<Override[]>([]);
  const [vendorCount, setVendorCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [settingsRes, workersRes] = await Promise.all([
        fetch("/api/control/gateway-settings"),
        fetch("/api/control/workers?type=smppclient"),
      ]);
      const settings = await settingsRes.json();
      const workers = await workersRes.json();
      if (!settingsRes.ok) throw new Error(settings?.error ?? "Could not read settings.");
      if (!workersRes.ok) throw new Error(workers?.error ?? "Could not read vendors.");

      setPairs(parseErrorCodes(settings?.data?.[LIST_KEY]?.value ?? ""));
      setPassthrough(
        (settings?.data?.[PASSTHROUGH_KEY]?.value ?? "").trim().toLowerCase() === "true"
      );

      const list: Worker[] = workers?.data ?? [];
      setVendorCount(list.length);
      //only the vendors that carry their own list. A vendor inheriting this one has nothing to say
      //here, and listing it would put the whole estate back on this page
      setOverrides(
        list
          .map((w) => ({
            name: w.name,
            count: parseErrorCodes(
              w.properties.find((p) => p.key === "dlr.errcodes")?.value ?? null
            ).length,
          }))
          .filter((v) => v.count > 0)
          .sort((a, b) => a.name.localeCompare(b.name))
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load error codes.");
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const save = useCallback(
    async (key: string, value: string) => {
      setSaving(key);
      setError(null);
      const res = await fetch("/api/control/gateway-settings", {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ key, value }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => null);
        setError(body?.error ?? "That could not be saved.");
      }
      setSaving(null);
      await load();
    },
    [load]
  );

  if (loading) {
    return <p className="text-base text-muted-foreground">Loading…</p>;
  }

  const blocked = pairs.some((p) => errorCodeProblem(p) !== null);
  const inheriting = vendorCount - overrides.length;

  return (
    <div className="space-y-4">
      {error && (
        <Card className="border-destructive/40">
          <CardContent className="flex items-start gap-2 py-4 text-base">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
            <span>{error}</span>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-base font-medium">Every vendor</CardTitle>
          <p className="text-base text-muted-foreground">
            Applies to any vendor that has not set a list of its own.
            {vendorCount > 0 && (
              <>
                {" "}
                {inheriting} of {vendorCount}{" "}
                {vendorCount === 1 ? "vendor uses" : "vendors use"} it today.
              </>
            )}
          </p>
        </CardHeader>
        <CardContent className="space-y-3">
          <ErrorCodeEditor pairs={pairs} onChange={setPairs} disabled={saving === LIST_KEY} />

          <label className="flex items-start gap-2 text-base">
            <Checkbox
              checked={passthrough}
              disabled={saving === PASSTHROUGH_KEY}
              //saves on its own rather than waiting for the button below: it is one boolean and
              //there is nothing to review before committing it, unlike the table above.
              //An empty value rather than "false" -- `setGatewaySetting` deletes the row for an
              //empty value, and absent is what "the gateway's own default" means
              onChange={(e) => save(PASSTHROUGH_KEY, e.target.checked ? "true" : "")}
            />
            <span>
              Send codes we have not mapped as the carrier sent them.
              <span className="block text-muted-foreground">
                Off, anything not listed above reaches the customer as 018.
              </span>
            </span>
          </label>

          {/* the gateway defaults this off so that an upgrade changes nothing, and this control can
              undo that for the whole deployment in one click. Amber rather than a refusal: it is a
              legitimate thing to want, and the operator is the one who knows their carriers */}
          {passthrough && (
            <p className="flex items-start gap-2 text-base text-amber-600 dark:text-amber-400">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>
                This changes the <code className="font-mono">err:</code> value on receipts from every
                vendor that has not set its own answer — including carriers whose codes nobody here
                has checked. A customer with logic built on seeing 018 will see something else.
              </span>
            </p>
          )}

          <Button
            onClick={() => save(LIST_KEY, formatErrorCodes(pairs))}
            disabled={saving !== null || blocked}
          >
            {saving === LIST_KEY ? "Saving…" : "Save"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base font-medium">Vendors with their own list</CardTitle>
          <p className="text-base text-muted-foreground">
            A vendor list <strong>replaces</strong> this one rather than adding to it, so nothing
            above applies to these.
          </p>
        </CardHeader>
        <CardContent>
          {overrides.length === 0 ? (
            <p className="text-base text-muted-foreground">
              {vendorCount === 0
                ? "No SMPP vendors configured, so there is nothing to translate yet."
                : "None — every vendor uses the list above."}
            </p>
          ) : (
            <ul className="space-y-1">
              {overrides.map((vendor) => (
                <li key={vendor.name} className="flex items-baseline justify-between gap-3">
                  <Link
                    href={`/cp/error-codes/${encodeURIComponent(vendor.name)}`}
                    className="text-base text-primary hover:underline"
                  >
                    {vendor.name}
                  </Link>
                  <span className="text-base text-muted-foreground">
                    {vendor.count} {vendor.count === 1 ? "mapping" : "mappings"} of its own
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
