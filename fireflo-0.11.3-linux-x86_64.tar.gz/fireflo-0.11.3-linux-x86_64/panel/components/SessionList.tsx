"use client";
import { useState } from "react";
import type { HealthSession } from "@/lib/health-types";
import { KIND, type WorkerType } from "@/lib/worker-types";
import { count, duration } from "@/lib/format";
import { shareOf } from "@/lib/bind-summary";
import { BIND_TYPE_LABELS, labelFor, ROLE_LABELS } from "@/lib/labels";
import { Checkbox } from "@/components/ui/checkbox";
import { DangerAction } from "./DangerAction";
import { CaptureSession } from "./CaptureSession";

/**
 * The individual connections behind a bind count.
 *
 * <p>Shared by the vendor page and the health page. The count alone cannot answer what usually
 * follows it: whether a vendor landed on its primary host or fell back to a backup, whether every
 * bind is a transceiver, or whether one session has been up for days while another keeps cycling.
 *
 * <p>The two kinds hold genuinely different facts — a vendor session knows the host it dialled, a
 * listener session knows which customer is on the other end, where from, and what they asked to bind
 * as — so the columns differ rather than being padded out to match.
 *
 * @param worker the worker's full name. Supplying it turns on the per-session actions -- capture on
 *     either kind, and disconnect on a listener; leaving it out keeps the table inert
 * @param canDisconnect false suppresses Disconnect while leaving Capture, which is what `/health`
 *     wants: the same listener sessions, readable, without a lever that drops a customer
 */
export function SessionList({
  type,
  sessions,
  worker,
  canDisconnect: allowDisconnect = true,
  total,
}: {
  type: WorkerType;
  sessions: HealthSession[];
  worker?: string;
  canDisconnect?: boolean;
  /**
   * The worker's whole counted traffic, which turns each row's own count into a share of it.
   *
   * <p>Supplied only when these rows <em>are</em> the whole set. Within one page of a longer list
   * the sum is not the worker's traffic, so a percentage against it would be a share of the page —
   * a number that changes when you turn to the next one. Absent, the column is not rendered at all.
   */
  total?: number;
}) {
  const isVendor = type === KIND.vendor;
  const showShare = total != null && total > 0;
  const canDisconnect = allowDisconnect && !isVendor && !!worker;
  //capture reads a session rather than acting on it, so it is offered on a vendor connection too --
  //which is why the action column is no longer decided by whether Disconnect is available
  const canCapture = !!worker;
  const hasActions = canDisconnect || canCapture;
  if (!sessions.length) {
    return <p className="text-sm text-muted-foreground">Nothing bound.</p>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="striped w-full text-sm tabular-nums">
        <thead className="text-muted-foreground">
          <tr className="text-left">
            <th className="py-1.5 pr-4 font-medium">{isVendor ? "Bind" : "Customer"}</th>
            {/* the credential this bind used. Returned for both kinds and rendered only for
                listeners until now, which left a vendor with several logins unable to say which
                one a given session dialled with */}
            <th className="py-1.5 pr-4 font-medium">System ID</th>
            {isVendor && <th className="py-1.5 pr-4 font-medium">Host</th>}
            {!isVendor && <th className="py-1.5 pr-4 font-medium">From</th>}
            {!isVendor && <th className="py-1.5 pr-4 font-medium">Bind</th>}
            {/* was "Bound as", which stopped being usable the moment a real bind-type column sat
                next to it -- two headings about the bind, one of them not about the bind at all */}
            {!isVendor && <th className="py-1.5 pr-4 font-medium">System type</th>}
            <th className="py-1.5 pr-4 font-medium">Up for</th>
            {/* "Received" on a listener: the counter behind this column is getRxSubmitSM for an
                inbound session, so it is traffic the customer sent us. See `submittedLabel` */}
            <th className="py-1.5 pr-4 text-right font-medium">{isVendor ? "Sent" : "Received"}</th>
            <th className="py-1.5 pr-4 text-right font-medium">tps</th>
            {showShare && <th className="py-1.5 pr-4 font-medium">Share</th>}
            {hasActions && <th className="py-1.5 pl-4" />}
          </tr>
        </thead>
        <tbody>
          {sessions.map((session, index) => (
            //every session now carries an id, a vendor's included, so the index fallback below is
            //only for a gateway older than that change. Keying a vendor row by its index made every
            //row below a dropped session change identity
            <tr
              key={session.session_id ?? index}
              className={
                session.bound
                  ? "border-t border-border"
                  : //still in the set but not bound: worth seeing rather than hiding, because it is
                    //a session the gateway believes it has
                    "border-t border-border text-muted-foreground"
              }
            >
              <td className="py-1.5 pr-4">
                {isVendor ? (
                  <span title={session.bind_type ?? undefined}>
                    {labelFor(BIND_TYPE_LABELS, session.bind_type)}
                    {/* only when it is not the primary: on the common path this would be a column
                        of NORMAL that teaches nobody anything */}
                    {session.role && session.role !== "NORMAL" && (
                      <span className="ml-1.5 rounded bg-amber-500/10 px-1 text-amber-600 dark:text-amber-400">
                        {labelFor(ROLE_LABELS, session.role)}
                      </span>
                    )}
                  </span>
                ) : (
                  (session.account ?? "—")
                )}
                {!session.bound && <span className="ml-1.5">(not bound)</span>}
              </td>
              <td className="py-1.5 pr-4">{session.system_id ?? "—"}</td>
              {isVendor && (
                <td className="py-1.5 pr-4">
                  {session.host
                    ? `${session.host}${session.port != null ? `:${session.port}` : ""}`
                    : "—"}
                </td>
              )}
              {!isVendor && (
                //the source port changes every reconnect and identifies nothing, so only the address
                <td className="py-1.5 pr-4">{session.host ?? "—"}</td>
              )}
              {!isVendor && (
                //what the client asked to bind as, in the specification's own abbreviations. A
                //customer bound RX cannot submit, which is the usual answer to "why is nothing
                //arriving from them"
                <td className="py-1.5 pr-4" title={session.bind_type ?? undefined}>
                  {labelFor(BIND_TYPE_LABELS, session.bind_type)}
                </td>
              )}
              {!isVendor && (
                <td className="py-1.5 pr-4">
                  {session.system_type ?? (
                    //absent is a fact, not a gap: the login's own product applied. Saying "—" is
                    //honest where naming that product here would look like the client chose it
                    <span className="text-muted-foreground" title="No system_type on the bind — the login's own product applies">
                      —
                    </span>
                  )}
                </td>
              )}
              <td className="py-1.5 pr-4">
                {session.bound_seconds != null ? duration(session.bound_seconds) : "—"}
              </td>
              <td className="py-1.5 pr-4 text-right">
                {session.submitted != null ? count(session.submitted) : "—"}
              </td>
              <td className="py-1.5 pr-4 text-right">
                {/* != null, not truthiness: 0 here means bound and sending nothing, which is the
                    reading worth showing */}
                {session.tps_measured != null ? session.tps_measured : "—"}
                {!isVendor && session.tps_limit != null && (
                  <span className="text-muted-foreground"> / ≤{session.tps_limit}</span>
                )}
              </td>
              {showShare && (
                <td className="py-1.5 pr-4">
                  <Share value={shareOf(session.submitted, total!)} />
                </td>
              )}
              {hasActions && (
                <td className="py-1.5 pl-4 text-right align-top">
                  {session.session_id != null && (
                    <span className="inline-flex items-start justify-end gap-1.5">
                      {canCapture && (
                        <CaptureSession
                          worker={worker!}
                          session={session}
                          isVendor={isVendor}
                        />
                      )}
                      {canDisconnect && <DisconnectSession worker={worker!} session={session} />}
                    </span>
                  )}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/**
 * How much of the worker's traffic went over this one bind.
 *
 * <p>A bar rather than a percentage because the reading is comparative — five rows of "20%" is
 * harder to scan than five bars of the same length, and one long bar among four stubs is the
 * shape worth catching. The figure is in the title for anyone who wants the number.
 *
 * <p>Null renders as a dash, not an empty bar: a session with counters switched off has no share,
 * which is a different statement from having carried nothing.
 */
function Share({ value }: { value: number | null }) {
  if (value == null) {
    return <span className="text-muted-foreground">—</span>;
  }
  return (
    <span
      className="block h-1.5 w-full min-w-8 overflow-hidden rounded-full bg-muted"
      title={`${(value * 100).toFixed(1)}% of this worker's counted traffic`}
    >
      <span
        className="block h-full rounded-full bg-muted-foreground/60"
        style={{ width: `${Math.max(value * 100, 1)}%` }}
      />
    </span>
  );
}

/**
 * Drop one customer's bind.
 *
 * <p>No refresh on success: the health poll removes the row within ten seconds, and a session list
 * that redrew from this button alone would be showing one row's worth of fresher truth than the rest
 * of the table.
 *
 * <p>The tick box is the difference between a nudge and a shut door, and it is unticked by default
 * because a disconnect is reversible in seconds and disabling a login is not.
 */
function DisconnectSession({ worker, session }: { worker: string; session: HealthSession }) {
  const [alsoDisable, setAlsoDisable] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function disconnect() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(
        `/api/control/workers/${encodeURIComponent(worker)}/sessions/${session.session_id}/disconnect`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            disable_login: alsoDisable,
            system_id: session.system_id ?? "",
          }),
        }
      );
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? "The gateway did not confirm.");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not reach the panel.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <span className="inline-flex flex-col items-end gap-1">
      <DangerAction
        label="Disconnect"
        confirmLabel={alsoDisable ? "Disconnect and disable" : "Disconnect"}
        consequence={
          alsoDisable
            ? `${session.system_id ?? "This login"} is switched off and this bind is dropped.`
            : "This bind is dropped. A client that retries will be back within seconds."
        }
        busy={busy}
        extra={
          <label className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Checkbox checked={alsoDisable} onChange={(e) => setAlsoDisable(e.target.checked)} />
            <span>
              Also disable this login
              <span className="block">
                Takes up to the gateway&rsquo;s poll interval, so a fast reconnect is still let in.
              </span>
            </span>
          </label>
        }
        onConfirm={disconnect}
      />
      {error && <span className="max-w-64 text-xs text-destructive">{error}</span>}
    </span>
  );
}
