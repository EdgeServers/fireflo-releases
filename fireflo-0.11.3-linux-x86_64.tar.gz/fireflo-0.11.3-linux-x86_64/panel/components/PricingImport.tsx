"use client";
import { useRef, useState } from "react";
import { Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import type { ImportPlan } from "@/lib/pricing-csv";

/** Matches the route's ceiling; a browser should not upload what the server will refuse. */
const MAX_BYTES = 2 * 1024 * 1024;

/**
 * Import a pricing CSV: preview first, apply second.
 *
 * <p>The file is read in the browser and posted as text rather than as multipart — this panel has no
 * form-data path anywhere, and a few hundred rules is tens of kilobytes.
 *
 * <p>The preview leads with removals, listed individually. A scope the file mentions is replaced
 * wholesale, so a rule missing from the file is a deletion — and summarising those as "3 removed"
 * would be the one line nobody reads before pressing apply.
 */
export function PricingImport({ product, onImported }: { product: string; onImported: () => Promise<void> }) {
  const input = useRef<HTMLInputElement>(null);
  const [csv, setCsv] = useState<string | null>(null);
  const [plan, setPlan] = useState<ImportPlan | null>(null);
  const [error, setError] = useState("");
  const [confirmRemovals, setConfirmRemovals] = useState(false);
  const [busy, setBusy] = useState(false);

  const url = `/api/control/products/${encodeURIComponent(product)}/pricing/import`;

  async function preview(file: File) {
    setError("");
    setPlan(null);
    setConfirmRemovals(false);
    if (file.size > MAX_BYTES) {
      setError(`That file is larger than ${MAX_BYTES / 1024 / 1024} MB.`);
      return;
    }
    const text = await file.text();
    setCsv(text);
    setBusy(true);
    try {
      const res = await fetch(`${url}?dryRun=1`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ csv: text }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      setPlan(json.data as ImportPlan);
    } finally {
      setBusy(false);
    }
  }

  async function apply() {
    if (!csv) {
      return;
    }
    setBusy(true);
    setError("");
    try {
      const res = await fetch(`${url}${confirmRemovals ? "?confirmRemovals=1" : ""}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ csv }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      reset();
      await onImported();
    } finally {
      setBusy(false);
    }
  }

  function reset() {
    setCsv(null);
    setPlan(null);
    setError("");
    setConfirmRemovals(false);
    if (input.current) {
      input.current.value = "";
    }
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-medium">Import pricing</CardTitle>
        <CardDescription>
          A CSV in the shape the export produces. Nothing is written until you have read what it would
          do.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap items-center gap-3">
          <input
            ref={input}
            type="file"
            accept=".csv,text/csv"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                preview(file);
              }
            }}
            className="block text-sm text-muted-foreground file:mr-3 file:rounded-md file:border file:border-input file:bg-background file:px-3 file:py-1.5 file:text-sm file:font-medium hover:file:bg-accent"
          />
          {(csv || plan) && (
            <Button type="button" variant="ghost" size="sm" onClick={reset}>Clear</Button>
          )}
        </div>

        {error && <p className="text-base text-destructive">{error}</p>}

        {plan && (
          <div className="space-y-3 text-base">
            {!!plan.removed.length && (
              <div className="rounded-lg border border-destructive p-3">
                <p className="font-medium text-destructive">
                  {plan.removed.length} rule{plan.removed.length === 1 ? "" : "s"} would be deleted
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  A scope this file mentions is replaced wholesale, so anything of that scope missing
                  from the file goes.
                </p>
                <ul className="mt-2 space-y-0.5 text-sm">
                  {plan.removed.map((r) => (
                    <li key={`${r.scope}-${r.ruleId}`} className="font-mono">
                      {r.scope} #{r.ruleId} — {r.describe}
                    </li>
                  ))}
                </ul>
                <label className="mt-3 flex items-start gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={confirmRemovals}
                    onChange={(e) => setConfirmRemovals(e.target.checked)}
                    className="mt-0.5 h-3.5 w-3.5 rounded border-input accent-primary"
                  />
                  Delete them.
                </label>
              </div>
            )}

            {!!plan.changed.length && (
              <div className="rounded-lg border border-border p-3">
                <p className="font-medium">{plan.changed.length} changed</p>
                <ul className="mt-2 space-y-1 text-sm">
                  {plan.changed.map((c) => (
                    <li key={`${c.scope}-${c.ruleId}`}>
                      <span className="font-mono">{c.scope} #{c.ruleId}</span>
                      {/* field by field, old to new: "changed" hides 0.0450 becoming 0.0045 */}
                      {c.changes.map((f) => (
                        <span key={f.field} className="ml-2">
                          {f.field}: <span className="font-mono">{f.from || "—"}</span> →{" "}
                          <span className="font-mono">{f.to || "—"}</span>
                        </span>
                      ))}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {!!plan.added.length && (
              <div className="rounded-lg border border-border p-3">
                <p className="font-medium">{plan.added.length} added</p>
                <ul className="mt-2 space-y-0.5 text-sm font-mono">
                  {plan.added.map((a, i) => (
                    <li key={i}>{a.scope} — {a.describe}</li>
                  ))}
                </ul>
              </div>
            )}

            <p className="text-xs text-muted-foreground">
              {plan.unchanged} unchanged · touches {plan.scopes.join(", ")}. Each scope is written
              separately, so a failure part way leaves the earlier ones applied.
            </p>

            <Button
              type="button"
              disabled={busy || (!!plan.removed.length && !confirmRemovals)}
              onClick={apply}
              className="gap-2"
            >
              <Upload className="h-4 w-4" />
              {busy ? "Applying…" : "Apply"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
