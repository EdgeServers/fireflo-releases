"use client";
import { useState } from "react";
import Link from "next/link";
import { AlertTriangle, Antenna, Plus, RefreshCw, Waypoints } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClasses } from "@/components/ui/button";
import { RangePicker } from "./RangePicker";
import { WorkerForm } from "./WorkerForm";
import { VendorTraffic, type VendorRow } from "./VendorTraffic";
import { ReceiptQualityLine, type ReceiptQualityRow } from "./ReceiptQuality";
import { TrafficControlLegend, WorkerCard } from "./WorkerCard";
import { WorkerRail } from "./WorkerRail";
import { WorkerSummary } from "./WorkerSummary";
import { VendorCostRates } from "./VendorCostRates";
import { useProductCatalogue } from "./useProducts";
import { useWorkers } from "./useWorkers";
import { useHealth } from "./useHealth";
import { CardSection } from "@/components/ui/card";
import { useAccordion } from "./useAccordion";
import { RANGES, useControlData, type Range } from "./useControlData";
import { readsWorkersFromDatabase } from "@/lib/health-types";
import { SEVERITY, needsAttention, verdictFor } from "@/lib/worker-verdict";
import { KIND, trafficKey, type Worker } from "@/lib/worker-types";

/**
 * Vendors: the connections out to whoever carries our traffic.
 *
 * <p>Settings and traffic on one page, because they are two views of the same thing and having them
 * in separate menus meant answering "is this vendor working" in two places.
 *
 * <p>Vendors with traffic but no stored settings are shown too. With the gateway reading its
 * configuration from `smsg.properties` rather than the database that is <em>every</em> vendor, and
 * dropping them for having no row here would hide real spend.
 *
 * <p><strong>Ordered by how much attention each one needs</strong>, not alphabetically. A list is
 * scanned from the top, and a vendor that has stopped carrying traffic is the reason anyone opened
 * the page; leaving it in name order puts it wherever the alphabet happens to put it.
 */
export function VendorsClient() {
  const [range, setRange] = useState<Range>("24h");
  const [editing, setEditing] = useState<Worker | "new" | null>(null);
  //once for the page, then handed to every card's rate editor. Fetching it inside VendorCostRates
  //would be one request per vendor for an identical list
  const productCatalogue = useProductCatalogue();
  const {
    workers, error, errorFor, notice, loading, busy, busyLabel,
    load, setEnabled, setProperty, restart, remove, applyNow,
  } = useWorkers(KIND.vendor);
  const { data: traffic, error: trafficError } = useControlData<VendorRow[]>("vendors", range);
  //a second request rather than a wider one: receipt quality is a different question over the same
  //rows, and a vendor list that fails to render because a percentile query was slow would be a bad
  //trade. Its error is deliberately not surfaced -- the line simply does not appear
  const { data: quality } = useControlData<ReceiptQualityRow[]>("receipts", range);
  const { health, error: healthError, byFullName, tpsHistory } = useHealth();
  const fromDatabase = readsWorkersFromDatabase(health);
  //taken from the picker's own catalogue rather than written out again here, so the heading over
  //the figures cannot end up naming a different window from the control that chose them
  const rangeTitle = `Last ${RANGES.find((r) => r.value === range)?.label ?? range}`;

  //call detail records store the FULL worker name, so this is the only correct join key -- see
  //trafficKey, which exists because matching on the bare name silently reads zero for everything
  const byVendor = new Map((traffic ?? []).map((row) => [row.vendor ?? "", row]));
  //same join key, same reason
  const byQuality = new Map((quality ?? []).map((row) => [row.vendor ?? "", row]));
  const configured = new Set(workers.map((w) => trafficKey(w)));
  const unconfigured = (traffic ?? []).filter((row) => !configured.has(row.vendor ?? ""));

  const sorted = [...workers].sort((a, b) => severity(a) - severity(b) || a.name.localeCompare(b.name));
  const attention = sorted.filter((w) => needsAttention(verdictFor(w, byFullName, KIND.vendor))).length;

  function severity(worker: Worker): number {
    return SEVERITY[verdictFor(worker, byFullName, KIND.vendor).tone];
  }

  //one open at a time, opened on the worst one. sorted, not workers: the rail and the cards share
  //this order and a rail that disagrees with the list beside it is worse than no rail
  const { open, toggle, select, cardRef } = useAccordion(sorted);

  if (editing) {
    return (
      <WorkerForm
        type={KIND.vendor}
        worker={editing === "new" ? null : editing}
        onCancel={() => setEditing(null)}
        onSaved={async () => {
          setEditing(null);
          await load();
        }}
      />
    );
  }

  return (
    <>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="max-w-2xl space-y-1">
          <p className="text-base text-muted-foreground">
            Settings here, live connection state from the gateway, and traffic for the period.
          </p>
          {attention > 0 && (
            <p className="text-base text-amber-600 dark:text-amber-400">
              {attention === 1 ? "One vendor needs" : `${attention} vendors need`} attention — listed
              first.
            </p>
          )}
        </div>
        <div className="ml-auto flex shrink-0 flex-wrap justify-end gap-2">
          <RangePicker value={range} onChange={setRange} />
          {/* routing lives here rather than in the nav: a routing table's whole job is choosing
              which of these vendors a message goes to, so it is only ever read next to them */}
          {/* no "Error codes" button here, deliberately. One sat beside Routing and went to the
              GLOBAL list, while each vendor card's footer carries a link to that vendor's own --
              two controls, one label, different destinations, and from a collapsed list only the
              global one was visible. The global list is reached from Configuration in the sidebar;
              a vendor's own is reached from that vendor */}
          <Link href="/cp/routing" className={buttonClasses({ variant: "outline" })}>
            <Waypoints className="h-4 w-4" />
            Routing
          </Link>
          <Button variant="outline" onClick={applyNow} disabled={busy === "__reload"}>
            <RefreshCw className="mr-1.5 h-4 w-4" />
            {busy === "__reload" ? "Reloading…" : "Apply now"}
          </Button>
          <Button onClick={() => setEditing("new")}>
            <Plus className="mr-1.5 h-4 w-4" />
            Add vendor
          </Button>
        </div>
      </div>

      {fromDatabase === false && (
        <Card className="border-destructive/40">
          <CardContent className="flex items-start gap-2 py-4 text-base">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
            <span>
              <strong>Nothing on this page is loaded by the gateway.</strong> It is reading its
              workers from{" "}
              <code className="rounded bg-muted px-1 py-0.5 text-sm">smsg.properties</code>, not the
              database. These rows are stored and valid, and ignored. Start the gateway with{" "}
              <code className="rounded bg-muted px-1 py-0.5 text-sm">
                FIREFLO_CONFIG_SOURCE=db
              </code>{" "}
              to use them.
            </span>
          </CardContent>
        </Card>
      )}

      {/* only what belongs to the page. An error from an action is rendered on the card that
          caused it, where the button is -- a banner up here is off screen by the eighth vendor */}
      {((error && !errorFor) || trafficError) && (
        <Card>
          <CardContent className="py-6 text-base text-destructive">{error || trafficError}</CardContent>
        </Card>
      )}
      {healthError && (
        <Card>
          <CardContent className="py-4 text-base text-muted-foreground">
            Live state unavailable: {healthError} — settings below are still current.
          </CardContent>
        </Card>
      )}
      {notice && (
        <Card>
          <CardContent className="py-4 text-base text-muted-foreground">{notice}</CardContent>
        </Card>
      )}

      {!errorFor && !error && !workers.length && !unconfigured.length && (
        <div className="rounded-xl border border-border p-12 text-center text-muted-foreground">
          {loading ? "Loading…" : "No vendors yet"}
        </div>
      )}

      <WorkerSummary
        workers={workers}
        byFullName={byFullName}
        type={KIND.vendor}
        loading={loading}
      />

      {/* the grid is owned here rather than by a child, because a child that owns its own split
          produced three columns at xl the last time -- see app/cp/(dashboard)/routing/page.tsx.
          `items-start` so the rail does not stretch to the height of the open card. xl and not lg
          because a worker card holds a settings grid and session details, and both wrap badly in
          two thirds of 1024px */}
      <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_16rem]">
        <div className="space-y-3">
          {sorted.map((vendor) => (
            <div key={vendor.name} ref={cardRef(vendor.name)} className="scroll-mt-4">
              <WorkerCard
                worker={vendor}
                type={KIND.vendor}
                live={byFullName.get(trafficKey(vendor))}
                busy={busy === vendor.name}
                busyLabel={busyLabel}
                error={errorFor === vendor.name ? error : undefined}
                open={open === vendor.name}
                onToggle={() => toggle(vendor.name)}
                onEdit={() => setEditing(vendor)}
                onToggleEnabled={(enabled) => setEnabled(vendor.name, enabled)}
                onSetProperty={(key, on, label) => setProperty(vendor.name, key, on, label)}
                onRestart={() => restart(vendor.name)}
                onRemove={() => remove(vendor.name)}
                //vendor.name, not trafficKey(vendor): the rate scope is the bare instance name the
                //gateway binds cost with, while trafficKey is the full smppclient.<name> the call
                //records use. They look equally right and only one of them matches
                costRates={<VendorCostRates vendorName={vendor.name} catalogue={productCatalogue} />}
                windowSeconds={health?.tps_window_seconds}
                tpsHistory={tpsHistory.get(trafficKey(vendor))}
              >
                {/* named, because everything above it on this card is a ten-second poll and this is
                    a rolling window over the call records. Stacked with no heading, a card mixed
                    "right now" with "since yesterday" and nothing marked the change of subject */}
                <CardSection title={rangeTitle} description="From the call records.">
                  <VendorTraffic row={byVendor.get(trafficKey(vendor))} />
                  {/* the delivery rate above is computed over what this vendor chose to report on,
                      so how much it reports belongs beside it or the first number reads as the
                      whole story */}
                  <ReceiptQualityLine row={byQuality.get(trafficKey(vendor))} />
                </CardSection>
              </WorkerCard>
            </div>
          ))}

          {unconfigured.map((row) => (
            <Card key={row.vendor ?? "unrouted"} className="border-border/60">
              <CardHeader className="pb-3">
                <CardTitle className="flex flex-wrap items-center gap-2 text-base font-medium">
                  <Antenna className="h-4 w-4 text-muted-foreground" />
                  {row.vendor ?? "Never routed"}
                  <Badge variant="outline">no stored settings</Badge>
                </CardTitle>
                <CardDescription>
                  {row.vendor
                    ? "Carrying traffic but configured outside the database — most likely in smsg.properties. Nothing here can be edited or controlled."
                    : "Messages that never reached a vendor at all."}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <VendorTraffic row={row} />
              </CardContent>
            </Card>
          ))}

          {!!workers.length && <TrafficControlLegend type={KIND.vendor} />}
        </div>

        {/* hidden below xl rather than stacked: a sticky rail on a narrow screen covers what it
            links to, and with one card open the accordion is already the navigation */}
        <div className="hidden xl:sticky xl:top-0 xl:block">
          <WorkerRail
            workers={sorted}
            byFullName={byFullName}
            type={KIND.vendor}
            selected={open}
            onSelect={select}
          />
        </div>
      </div>
    </>
  );
}
