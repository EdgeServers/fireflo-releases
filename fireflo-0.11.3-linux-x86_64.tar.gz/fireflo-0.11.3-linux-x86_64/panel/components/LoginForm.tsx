"use client";
import { useEffect, useState } from "react";
import { signIn } from "next-auth/react";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { APP_VERSION, FireFloMark } from "@/components/FireFloMark";
import { signInErrorMessage } from "@/lib/sign-in-error";

/** Where the remembered username is kept. Not the password — see the note on `submit`. */
const REMEMBERED = "fireflo-control.remembered-operator";

export function LoginForm() {
  const [username, setUsername] = useState("operator");
  const [password, setPassword] = useState("");
  const [visible, setVisible] = useState(false);
  const [remember, setRemember] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  //read after hydration rather than in a lazy initialiser: localStorage does not exist during the
  //server render, and seeding state from it would make the first client render disagree with the
  //HTML that was sent
  useEffect(() => {
    const stored = window.localStorage.getItem(REMEMBERED);
    if (stored) {
      setUsername(stored);
      setRemember(true);
    }
  }, []);

  /**
   * Signs in, then leaves via a real navigation.
   *
   * <p>The navigation is the point, and it is why this is `window.location` rather than
   * `router.push`. Browsers only offer to save a password when they see a form submitted and the
   * page then go somewhere; a client-side route change looks like nothing happened, so Chrome and
   * Firefox stay silent and the credential is never saved. One full page load on sign-in is the
   * price of the browser's password manager working at all.
   *
   * <p>Which is also why nothing here writes the password anywhere itself. Keeping it in
   * `localStorage` would put a plaintext operator credential somewhere every script on the page can
   * read, surviving sign-out, for the sake of saving a paste. The password manager is the thing
   * built for this — it is encrypted at rest, it is scoped to the origin, and it is under the
   * operator's control rather than this form's.
   */
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await signIn("operator", { username, password, redirect: false });
      if (res?.error) {
        //a wrong username and a wrong password read the same; a cookie the browser dropped, or a
        //server fault, does not -- see lib/sign-in-error.ts
        setError(signInErrorMessage(res.error, window.location));
        return;
      }
      if (remember) {
        window.localStorage.setItem(REMEMBERED, username);
      } else {
        window.localStorage.removeItem(REMEMBERED);
      }
      window.location.assign("/cp");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-sm">
        <CardHeader className="space-y-2">
          <div className="flex items-center gap-2">
            <FireFloMark className="h-7 w-7" />
            <CardTitle className="flex items-baseline gap-1.5">
              FireFlo
              {APP_VERSION && (
                <span className="text-sm font-normal tabular-nums text-muted-foreground">
                  {APP_VERSION}
                </span>
              )}
            </CardTitle>
          </div>
          <p className="text-base text-muted-foreground">
            Operator access. This is not a gateway messaging credential.
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                //password managers key off `name` as much as `autoComplete`; without it the pair is
                //saved as an anonymous credential that never autofills again
                name="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                autoComplete="username"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  name="password"
                  type={visible ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="current-password"
                  className="pr-9"
                />
                <button
                  type="button"
                  onClick={() => setVisible((v) => !v)}
                  //not in the tab order: tabbing from the password field should reach Sign in, and
                  //revealing a password is a deliberate act rather than something to land on
                  tabIndex={-1}
                  aria-label={visible ? "Hide password" : "Show password"}
                  aria-pressed={visible}
                  className="absolute inset-y-0 right-0 flex w-9 items-center justify-center rounded-r-md text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                >
                  {visible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <label className="flex items-start gap-2 text-base">
              <input
                type="checkbox"
                checked={remember}
                onChange={(e) => setRemember(e.target.checked)}
                className="mt-0.5 h-4 w-4 rounded border-input accent-primary"
              />
              <span>
                Remember me on this device
                {/* said out loud so nobody assumes the password is being kept here too */}
                <span className="block text-xs text-muted-foreground">
                  Keeps the username. Let your browser save the password.
                </span>
              </span>
            </label>

            {error && <p className="text-base text-destructive">{error}</p>}
            <Button type="submit" className="w-full" disabled={loading || !password}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Sign in
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
