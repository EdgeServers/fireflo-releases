"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { ConditionEditor } from "./ConditionEditor";
import { ErrorNote, WarningNote } from "@/components/FormNotices";
import {
  type Filter,
  type FilterInput,
  emptyFilterWarning,
  usedByTotal,
  validateFilter,
} from "@/lib/filter-types";
import { type ConditionInput, conditionWarnings } from "@/lib/rate-types";

/**
 * One named filter: a clause several rules share.
 *
 * <p>The condition editor is `ConditionEditor`, unchanged and shared with the pricing form. A filter
 * *is* a list of conditions, so a second editor for them would be two implementations of the same
 * idea drifting apart.
 */
export function FilterForm({
  editing,
  onSave,
  onCancel,
}: {
  editing: Filter | null;
  //no `busy` prop: this form tracks its own submit, and the parent's busy flag is about the list
  onSave: (input: FilterInput) => Promise<string | null>;
  onCancel: () => void;
}) {
  const isNew = editing == null;
  const [name, setName] = useState(editing?.name ?? "");
  const [label, setLabel] = useState(editing?.label ?? "");
  const [enabled, setEnabled] = useState(editing?.enabled ?? true);
  const [conditions, setConditions] = useState<ConditionInput[]>(editing?.conditions ?? []);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const input: FilterInput = { name, label, enabled, conditions };
  const uses = editing ? usedByTotal(editing) : 0;
  const warnings = [
    emptyFilterWarning(input),
    //the mistake that made this check exist was made here and noticed on a pricing page, three
    //screens away, weeks later
    ...conditionWarnings(conditions),
    //the consequence nobody expects, stated at the moment of switching it off rather than after
    !enabled && uses > 0
      ? `Switching this off removes ${uses} rule${uses === 1 ? "" : "s"} from the gateway. A `
        + "disabled filter does not become a catch-all — every rule using it is skipped, and that "
        + "traffic falls through to whatever matches next."
      : null,
  ].filter((w): w is string => w != null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const invalid = validateFilter(input);
    if (invalid) {
      setError(invalid);
      return;
    }
    setSaving(true);
    setError("");
    const failure = await onSave(input);
    setSaving(false);
    if (failure) {
      setError(failure);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2">
        <Field
          label="Name"
          htmlFor="filter-name"
          hint={isNew
            ? "What rules reference it by. Matched exactly, and fixed once created."
            : "Fixed once created — rules reference it by this."}
        >
          <Input id="filter-name" value={name} disabled={!isNew} placeholder="in_txn"
            className="font-mono" onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Description" htmlFor="filter-label" hint="Optional — what this clause is for.">
          <Input id="filter-label" value={label ?? ""} placeholder="India, transactional"
            onChange={(e) => setLabel(e.target.value)} />
        </Field>
      </div>

      <div className="space-y-2">
        <p className="text-sm font-medium text-muted-foreground">Conditions</p>
        <ConditionEditor conditions={conditions} onChange={setConditions} />
        <p className="text-xs text-muted-foreground">
          All of these must hold, <strong>in addition to</strong> whatever conditions the rule using
          this filter carries of its own. A filter narrows a rule; it never widens one.
        </p>
      </div>

      <label className="flex items-start gap-2 text-base">
        <Checkbox checked={enabled} onChange={(e) => setEnabled(e.target.checked)} className="mt-0.5" />
        <span>
          Enabled
          <span className="block text-xs text-muted-foreground">
            {uses > 0
              ? `Used by ${uses} rule${uses === 1 ? "" : "s"}. Switching it off skips every one of `
                + "them, rather than letting them match everything."
              : "Used by nothing yet, so switching it off changes nothing."}
          </span>
        </span>
      </label>

      <WarningNote warnings={warnings} />
      <ErrorNote error={error} />

      <div className="flex items-center gap-3">
        <Button type="submit" disabled={saving || !name.trim()}>
          {saving ? "Saving…" : isNew ? "Create filter" : "Save changes"}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
      </div>
    </form>
  );
}
