"use client";
import { CopyButton } from "./CopyButton";
import { cn } from "@/lib/utils";

/**
 * A block of code or a response body, with a title bar and a copy button.
 *
 * <p><strong>No syntax highlighting, deliberately.</strong> Every highlighter is a large dependency
 * against a nine-package list, and what actually makes a curl command readable is the line breaking
 * and the monospace — not the colours. A customer copies this and reads it in their own editor.
 *
 * <p>The `<pre>` class matches the one used for raw payloads elsewhere in the panel, so a code block
 * here and a message body on the CDR detail page look like the same kind of object.
 */
export function CodeBlock({
  code,
  title,
  right,
  className,
  copyLabel,
}: {
  code: string;
  /** Left of the bar — "Request", "Response", or a language name. */
  title?: React.ReactNode;
  /** Right of the bar, before the copy button — a status, a timing, a language switcher. */
  right?: React.ReactNode;
  className?: string;
  copyLabel?: string;
}) {
  return (
    <div className={className}>
      {(title || right) && (
        <div className="mb-1.5 flex items-center justify-between gap-3">
          <span className="text-xs text-muted-foreground">{title}</span>
          <span className="flex items-center gap-2">
            {right}
            <CopyButton value={code} label={copyLabel ?? "Copy"} />
          </span>
        </div>
      )}
      {/*overflow-x rather than wrapping: a broken curl line is a curl line that does not run when
         it is pasted, and a horizontal scrollbar says "there is more" where a soft wrap lies.
         font-mono is stated rather than inherited: a bare <pre> is monospace only because Tailwind's
         preflight styles the element, which is true today and is not this component's to rely on --
         the monospace is the whole point of the block, per the note above*/}
      <pre className={cn(
        "overflow-x-auto rounded bg-muted p-3 font-mono text-sm leading-relaxed",
        //tabular text in a pre that may be empty still needs a height, or the panel jumps as
        //a response arrives
        !code && "min-h-[2.5rem]"
      )}>
        {code}
      </pre>
    </div>
  );
}
