"use client";
import { useCallback, useEffect, useState } from "react";
import { Download, FileDown, Loader2, Trash2, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { bytes, count } from "@/lib/format";
import { formatTimestamp } from "@/lib/datetime";

interface ExportJob {
  id: string;
  status: "queued" | "running" | "ready" | "failed";
  requestedAt: string;
  finishedAt: string | null;
  rows: number;
  label: string;
  error: string | null;
  bytes: number | null;
}

/** Only polls while something is actually being prepared, so an idle page makes no requests at all. */
const POLL_MS = 3_000;

/**
 * Requested downloads: ask for a CSV, then collect it when it is ready.
 *
 * <p>Not a direct download. Exporting a month of traffic takes long enough that a synchronous
 * response would be holding a connection open while the browser decides it has timed out — and the
 * work would be lost with it. Here the request is recorded first and survives you closing the tab.
 *
 * <p>Generic over what is being exported, because nothing in it ever was specific: it takes an
 * endpoint and the query string the table above is showing. The row type appears nowhere here,
 * which is the test for whether something should be shared or forked — contrast `RejectedCell`,
 * where it appears in every branch.
 */
export function ExportsCard({
  endpoint,
  params,
  description,
}: {
  /** The export collection, e.g. `/api/control/rejected/export`. Job ids are appended to it. */
  endpoint: string;
  /** The filters currently applied, so the file matches what is on screen. */
  params: URLSearchParams;
  description: React.ReactNode;
}) {
  const [jobs, setJobs] = useState<ExportJob[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [requesting, setRequesting] = useState(false);

  const load = useCallback(async () => {
    try {
      const res = await fetch(endpoint);
      const body = await res.json();
      if (!res.ok) {
        throw new Error(body?.error ?? `Request failed (${res.status})`);
      }
      setJobs(body.data ?? []);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not read the download list");
    }
  }, [endpoint]);

  useEffect(() => {
    void load();
  }, [load]);

  //polling is conditional on there being something in flight. A dashboard that polls forever is how
  //an idle browser tab ends up being the busiest client the panel has
  const pending = jobs.some((j) => j.status === "queued" || j.status === "running");
  useEffect(() => {
    if (!pending) {
      return;
    }
    const timer = setInterval(() => void load(), POLL_MS);
    return () => clearInterval(timer);
  }, [pending, load]);

  async function request() {
    setRequesting(true);
    try {
      //the same query string the table is showing, so the CSV matches what is on screen
      const res = await fetch(`${endpoint}?${params}`, { method: "POST" });
      const body = await res.json();
      if (!res.ok) {
        throw new Error(body?.error ?? `Request failed (${res.status})`);
      }
      setError(null);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not start the export");
    } finally {
      setRequesting(false);
    }
  }

  async function remove(id: string) {
    await fetch(`${endpoint}/${id}`, { method: "DELETE" });
    await load();
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-3">
        <div>
          <CardTitle className="text-base font-medium">Downloads</CardTitle>
          <CardDescription>{description}</CardDescription>
        </div>
        <Button onClick={request} disabled={requesting} size="sm" className="gap-2">
          <FileDown className="h-4 w-4" />
          {requesting ? "Requesting…" : "Export these results"}
        </Button>
      </CardHeader>
      <CardContent>
        {error && <p className="pb-3 text-base text-destructive">{error}</p>}

        {!jobs.length && !error && (
          <p className="py-4 text-base text-muted-foreground">
            Nothing requested yet. An export uses the filters currently applied above.
          </p>
        )}

        <div className="space-y-2">
          {jobs.map((job) => (
            <div
              key={job.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border px-3 py-2.5"
            >
              <div className="min-w-0">
                <p className="truncate text-base font-medium">{job.label || "All records"}</p>
                <p className="text-sm text-muted-foreground" suppressHydrationWarning>
                  {formatTimestamp(job.requestedAt)}
                  {job.status === "ready" && ` · ${count(job.rows)} rows`}
                  {job.status === "ready" && job.bytes != null && ` · ${bytes(job.bytes)}`}
                  {job.status === "running" && ` · ${count(job.rows)} rows so far`}
                </p>
                {job.error && (
                  <p className="mt-1 flex items-start gap-1.5 text-sm text-destructive">
                    <TriangleAlert className="mt-0.5 h-3 w-3 shrink-0" />
                    {job.error}
                  </p>
                )}
              </div>

              <div className="flex shrink-0 items-center gap-2">
                <Status status={job.status} />
                {job.status === "ready" && (
                  //a plain link, not a fetch-into-blob: the browser streams it straight to disk and
                  //a 200MB CSV never touches the page's memory
                  <a
                    href={`${endpoint}/${job.id}`}
                    download
                    className="inline-flex h-8 items-center gap-2 rounded-md border border-input bg-background px-3 text-sm font-medium shadow-sm transition-colors hover:bg-accent hover:text-accent-foreground"
                  >
                    <Download className="h-3.5 w-3.5" />
                    Download
                  </a>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => remove(job.id)}
                  aria-label="Delete this export"
                  className="h-8 w-8"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function Status({ status }: { status: ExportJob["status"] }) {
  if (status === "ready") {
    return <Badge variant="success">Ready</Badge>;
  }
  if (status === "failed") {
    return <Badge variant="destructive">Failed</Badge>;
  }
  return (
    <Badge variant="outline" className="gap-1.5">
      <Loader2 className="h-3 w-3 animate-spin" />
      {status === "queued" ? "Queued" : "Preparing"}
    </Badge>
  );
}
