"use client";
import { FILTER_WIDTH } from "@/lib/filter-widths";
import { useState } from "react";
import { Filter, RotateCcw, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Select } from "@/components/ui/select";
import { Field } from "@/components/ui/field";
import {
  EMPTY_FILTERS,
  FINAL_STATES,
  RANGES,
  type CdrFilterForm,
  hasActiveFilters,
} from "@/lib/cdr-request";
import { FINAL_STATE_LABELS, labelFor } from "@/lib/labels";

/**
 * The filter form.
 *
 * <p>Holds a draft and only lifts it on submit. Filtering as you type would fire a database query
 * per keystroke against a pool of eight connections shared with the dashboard's polling, and the
 * results would flicker between four different answers before settling on the one you meant.
 *
 * <p>Free text rather than dropdowns for every dimension — see the note in `cdr-queries.ts`.
 */
export function CdrFilterBar({
  value,
  onApply,
  busy,
}: {
  value: CdrFilterForm;
  onApply: (next: CdrFilterForm) => void;
  busy: boolean;
}) {
  const [draft, setDraft] = useState<CdrFilterForm>(value);
  const [open, setOpen] = useState(false);

  const set = <K extends keyof CdrFilterForm>(key: K, next: CdrFilterForm[K]) =>
    setDraft((d) => ({ ...d, [key]: next }));

  function submit(e: React.FormEvent) {
    e.preventDefault();
    onApply(draft);
  }

  function clear() {
    //the range survives a clear: resetting it to 24h as well would look like the filters failed to
    //apply rather than that they were removed
    const next = { ...EMPTY_FILTERS, range: draft.range };
    setDraft(next);
    onApply(next);
  }

  return (
    <Card>
      <CardContent className="p-4">
        <form onSubmit={submit} className="space-y-4">
          <div className="flex flex-wrap items-end gap-3">
            <Field label="Period" className={FILTER_WIDTH.select}>
              <Select value={draft.range} onChange={(e) => set("range", e.target.value)}>
                {Object.keys(RANGES).map((key) => (
                  <option key={key} value={key}>
                    {key === "all" ? "All time" : `Last ${key}`}
                  </option>
                ))}
              </Select>
            </Field>

            <Field label="Outcome" className={FILTER_WIDTH.choice}>
              <Select value={draft.outcome} onChange={(e) => set("outcome", e.target.value)}>
                <option value="">Any outcome</option>
                {/* PENDING first: it is the majority of rows and the one people forget exists */}
                <option value="PENDING">Awaiting a receipt</option>
                {FINAL_STATES.map((state) => (
                  <option key={state} value={state}>
                    {labelFor(FINAL_STATE_LABELS, state)}
                  </option>
                ))}
              </Select>
            </Field>

            <Field label="To number" className={FILTER_WIDTH.phone}>
              <Input
                value={draft.dest}
                onChange={(e) => set("dest", e.target.value)}
                placeholder="starts with…"
                inputMode="tel"
              />
            </Field>

            <Field label="Message id" className={FILTER_WIDTH.text}>
              <Input
                value={draft.msgId}
                onChange={(e) => set("msgId", e.target.value)}
                placeholder="exact"
              />
            </Field>

            {/* the one box here that searches inside a value rather than matching one. It finds
                nothing at all unless the gateway is recording message text -- smsg.cdr.body, off by
                default -- which is why the placeholder says what it looks in rather than "search" */}
            <Field label="Message text" className={FILTER_WIDTH.text}>
              <Input
                value={draft.text}
                onChange={(e) => set("text", e.target.value)}
                placeholder="contains…"
              />
            </Field>

            <Button type="submit" disabled={busy} className="gap-2">
              <Search className="h-4 w-4" />
              {busy ? "Searching…" : "Search"}
            </Button>

            <Button type="button" variant="ghost" onClick={() => setOpen((o) => !o)} className="gap-2">
              <Filter className="h-4 w-4" />
              {open ? "Fewer filters" : "More filters"}
            </Button>

            {hasActiveFilters(draft) && (
              <Button type="button" variant="ghost" onClick={clear} className="gap-2">
                <RotateCcw className="h-4 w-4" />
                Clear
              </Button>
            )}
          </div>

          {open && (
            <div className="grid gap-3 border-t border-border pt-4 sm:grid-cols-2 lg:grid-cols-3">
              <Field label="Account">
                <Input value={draft.account} onChange={(e) => set("account", e.target.value)} placeholder="exact" />
              </Field>
              <Field label="Bind name (system id)">
                <Input value={draft.systemId} onChange={(e) => set("systemId", e.target.value)} placeholder="exact" />
              </Field>
              <Field label="Vendor">
                <Input value={draft.vendor} onChange={(e) => set("vendor", e.target.value)} placeholder="exact" />
              </Field>
              <Field label="Product">
                <Input value={draft.product} onChange={(e) => set("product", e.target.value)} placeholder="exact" />
              </Field>
              <Field label="Came in via">
                <Input value={draft.ingress} onChange={(e) => set("ingress", e.target.value)} placeholder="smpp, http…" />
              </Field>
              <Field label="From number">
                <Input value={draft.source} onChange={(e) => set("source", e.target.value)} placeholder="starts with…" />
              </Field>

              <Field
                label="Rows"
                hint="One row per message, or one per vendor attempt including retries and long-message segments."
                className="sm:col-span-2 lg:col-span-3"
              >
                <Select
                  value={draft.attempts}
                  onChange={(e) => set("attempts", e.target.value === "all" ? "all" : "first")}
                >
                  <option value="first">One row per message</option>
                  <option value="all">Every attempt and segment</option>
                </Select>
              </Field>
            </div>
          )}
        </form>
      </CardContent>
    </Card>
  );
}
