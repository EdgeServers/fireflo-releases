"use client";
import { useCallback, useEffect, useState } from "react";
import type { Health, HealthWorker } from "@/lib/health-types";
import { appendTps, type TpsHistory } from "@/lib/tps-history";

const REFRESH_MS = 10_000;

/**
 * The same interval in seconds, for a card that says how fresh its numbers are.
 *
 * <p>Exported rather than written as "10s" wherever it is shown, because a caption that disagrees
 * with the timer is worse than no caption: it tells someone a stale figure is current.
 */
export const HEALTH_POLL_SECONDS = REFRESH_MS / 1000;

/**
 * Live gateway state, polled, keyed by full worker name.
 *
 * <p>Slower than the health page's five seconds: this is a status line beside settings, not a
 * counter someone is watching tick.
 *
 * <p>An unreachable gateway is reported as an error but leaves the last snapshot in place. Blanking
 * the page on one failed poll would make a working gateway look like it disappeared, and the
 * settings beside the status are still worth reading either way.
 */
export function useHealth() {
  const [health, setHealth] = useState<Health | null>(null);
  const [tpsHistory, setTpsHistory] = useState<TpsHistory>(new Map());
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/control/health", { cache: "no-store" });
      const json = await res.json();
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
      } else {
        const snapshot = json.data as Health;
        setHealth(snapshot);
        //folded in here rather than derived by a card, because this is the one place a new
        //snapshot is known to be new. A component cannot tell a fresh poll from a re-render
        setTpsHistory((past) => appendTps(past, snapshot));
        setError("");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not reach the gateway");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    let alive = true;
    const run = () => {
      if (alive) void load();
    };
    run();
    let timer: ReturnType<typeof setInterval> | null = setInterval(run, REFRESH_MS);
    //a hidden tab polling a gateway forever is pure noise in its logs
    const onVisibility = () => {
      if (document.hidden) {
        if (timer) clearInterval(timer);
        timer = null;
      } else if (!timer) {
        run();
        timer = setInterval(run, REFRESH_MS);
      }
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      alive = false;
      if (timer) clearInterval(timer);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [load]);

  //the snapshot reports getFullName() -- 'smppclient.vendor1' -- while app_worker.name is the
  //instance alone; see trafficKey, which exists for the same mismatch on the traffic join
  const byFullName = new Map((health?.workers ?? []).map((w) => [w.name, w] as const));

  return { health, error, loading, reload: load, byFullName, tpsHistory };
}

export type { Health, HealthWorker };
