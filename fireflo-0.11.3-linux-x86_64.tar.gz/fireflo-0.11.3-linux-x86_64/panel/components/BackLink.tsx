import Link from "next/link";
import { ArrowLeft } from "lucide-react";

/**
 * The way back to the list this page was reached from.
 *
 * <p>Extracted because three detail pages had the same class string written out by hand, and the one
 * on the account page had already drifted in structure. A detail page is always reached from
 * somewhere; the link back should look the same wherever you are.
 *
 * <p>Deliberately not a `Button`. It is navigation within the page's own hierarchy, not an action,
 * and giving it a button's weight would make it compete with the actions in the cards below.
 */
export function BackLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link
      href={href}
      className="inline-flex items-center gap-1.5 text-base text-muted-foreground hover:text-foreground"
    >
      <ArrowLeft className="h-4 w-4" />
      {children}
    </Link>
  );
}
