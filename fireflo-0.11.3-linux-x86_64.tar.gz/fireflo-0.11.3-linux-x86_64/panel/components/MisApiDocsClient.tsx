"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Terminal } from "lucide-react";
import { CodeBlock } from "./CodeBlock";
import { CopyButton } from "./CopyButton";
import { MisRotateSecret } from "./MisRotateSecret";
import { PASSWORD_PLACEHOLDER, useApiAccess } from "./useApiAccess";
import {
  BATCH_CALLBACK_PARAMS,
  CODE_LANGUAGES,
  FALLBACK_MSISDN,
  dlrExample,
  DLR_FIELDS,
  ENDPOINTS,
  SHARED_ERRORS,
  codeSample,
  exampleValue,
  type ApiEndpoint,
  type CodeLanguage,
} from "@/lib/api-catalogue";

/**
 * The reference a customer integrates against.
 *
 * <p>Generated from `lib/api-catalogue.ts`, which is also what the playground's form is built from.
 * That is the point: a reference written separately from the thing you can click drifts, and the
 * drift is invisible until somebody has already shipped against the wrong half.
 *
 * <p><strong>Filled in with this customer's own values.</strong> Their base URL and their login name
 * appear in every example, so a curl block is one paste from working. Never their password —
 * examples carry a placeholder, because a page showing a live credential is a page that ends up in a
 * screenshot on a support ticket.
 *
 * <p>One long page rather than a route per endpoint. There are five endpoints; paginating them would
 * add navigation to a document short enough to read straight through, and Ctrl-F over one page is
 * the search feature nobody has to build.
 */

const SECTIONS = [
  { id: "auth", label: "Authentication" },
  ...ENDPOINTS.map((e) => ({ id: e.id, label: e.title })),
  { id: "dlr", label: "Delivery receipts" },
  { id: "callbacks", label: "Batch callbacks" },
  { id: "errors", label: "Errors" },
];

/**
 * Which section is being read, for the rail to mark.
 *
 * <p>Worth its fifteen lines only because the rail moved. Against the left edge, beside the portal's
 * own nav, an unmarked list of anchors was tolerable; on the far side of the reading column it is a
 * list you glance at, and a glance wants an answer.
 *
 * <p>`rootMargin` pulls the observation band up to the top fifth of the viewport, so the current
 * section is the one you are reading rather than whichever happens to be tallest on screen. Without
 * it, a long endpoint keeps the mark while the next heading sits under your eyes.
 *
 * <p><strong>An `IntersectionObserver` delivers nothing at all in a tab that is not compositing</strong>
 * — not even its initial callback — so in a background tab the mark simply stays where it was. That
 * is the right failure for a marker on a list of anchors, which is why this is safe where the same
 * property is a real defect for the charts on the dashboard (see the `ANIMATION` note there, where
 * an uncomposited recharts renders no shape at all rather than a stale one). It is also why this is
 * not verifiable in a browser pane that is not painting.
 *
 * @param waiting true while the page is still a loading placeholder, so the effect re-runs once the
 *     sections it observes actually exist
 */
function useCurrentSection(waiting: boolean): string {
  const [here, setHere] = useState(SECTIONS[0].id);

  useEffect(() => {
    if (waiting || typeof IntersectionObserver === "undefined") {
      return;
    }
    const seen = new Map<string, boolean>();
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          seen.set(entry.target.id, entry.isIntersecting);
        }
        //the FIRST section in page order that is on screen, not the last entry to fire -- callbacks
        //arrive in whatever order the browser noticed, and taking the newest makes the mark jump
        //backwards when two sections cross the band together
        const first = SECTIONS.find((s) => seen.get(s.id));
        if (first) {
          setHere(first.id);
        }
      },
      { rootMargin: "0px 0px -80% 0px" }
    );

    for (const s of SECTIONS) {
      const el = document.getElementById(s.id);
      if (el) {
        observer.observe(el);
      }
    }
    return () => observer.disconnect();
  }, [waiting]);

  return here;
}

export function MisApiDocsClient({ exampleTo }: {
  /** The platform's example destination, or null to keep the catalogue's own. */
  exampleTo?: string | null;
}) {
  const { access, loading } = useApiAccess();
  const [language, setLanguage] = useState<CodeLanguage>("curl");
  const here = useCurrentSection(loading);

  const ctx = useMemo(() => ({
    baseUrl: access?.baseUrl ?? "https://your-gateway",
    login: access?.logins[0]?.lookupKey ?? "your-login",
  }), [access]);

  if (loading) {
    return <p className="text-base text-muted-foreground">Loading…</p>;
  }

  //flex-row-REVERSE, so the rail sits on the right on a wide screen without moving in the DOM. The
  //portal's own nav is already an 18rem rail on the left; a second one beside it pushed the prose a
  //third of the way across the page and left the reading column against neither edge. Reversing
  //rather than reordering keeps the mobile stack as it was -- nav first, then content
  return (
    <div className="flex flex-col gap-6 lg:flex-row-reverse">
      {/*sticky on a wide screen, an ordinary block on a phone -- a sticky rail on a 375px viewport
         is a rail that covers the thing it links to*/}
      <nav className="shrink-0 lg:sticky lg:top-4 lg:h-fit lg:w-52">
        <p className="mb-2 text-xs uppercase tracking-wide text-muted-foreground">On this page</p>
        <ul className="space-y-0.5">
          {SECTIONS.map((s) => (
            <li key={s.id}>
              {/*the marker is a left border rather than a background, so it reads as a position in
                 a list rather than as a selected control -- these are anchors, and nothing here is
                 in a chosen state*/}
              <a href={`#${s.id}`}
                aria-current={here === s.id ? "location" : undefined}
                className={"block rounded border-l-2 px-2 py-1 text-base hover:bg-accent hover:text-foreground "
                  + (here === s.id
                    ? "border-foreground/40 text-foreground"
                    : "border-transparent text-muted-foreground")}>
                {s.label}
              </a>
            </li>
          ))}
        </ul>
      </nav>

      <div className="min-w-0 flex-1 space-y-8">
        <header className="space-y-2">
          <h1 className="text-xl font-semibold leading-tight">REST API</h1>
          <p className="text-base text-muted-foreground">
            Send from your own software. Everything below is filled in with your account&apos;s
            details — try any of it in the{" "}
            <Link href="/playground" className="text-primary hover:underline">
              <Terminal className="mr-0.5 inline h-3.5 w-3.5 align-[-2px]" />playground
            </Link>.
          </p>
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <Chip label="Base URL" value={ctx.baseUrl} />
            <Chip label="Your login" value={ctx.login} />
          </div>
          {!access?.baseUrl && (
            <p className="text-xs text-amber-600 dark:text-amber-500">
              Your operator has not published the API address here, so the examples use a placeholder
              host. Ask them for it.
            </p>
          )}
        </header>

        <section id="auth" className="space-y-2 scroll-mt-4">
          <h2 className="text-lg font-medium">Authentication</h2>
          <p className="text-base leading-relaxed text-muted-foreground">
            HTTP Basic on every <Code>/secure/</Code> path. The username is your login, the password
            is the one you were issued. Sending them in the request body instead is refused with{" "}
            <Code>Unknown argument: username</Code> rather than ignored — a password in a body is a
            password in an access log.
          </p>
          <p className="text-base leading-relaxed text-muted-foreground">
            Only HTTP logins can use this API. An SMPP login is refused with{" "}
            <Code>Authentication failure</Code>, which reads exactly like a wrong password.
          </p>
          <CodeBlock
            code={`Authorization: Basic ${btoaSafe(`${ctx.login}:${PASSWORD_PLACEHOLDER}`)}`}
            title="Header"
            copyLabel="Copy header"
          />

          {/* here rather than in the playground: this is where a customer reads which credential
              they authenticate with, so it is where they look when they want a different one. A
              rotate control on the playground would invalidate the password in the box above it */}
          <p className="pt-1 text-base text-muted-foreground">
            Replacing a credential is self-service. The new value is shown once.
          </p>
          <MisRotateSecret logins={access?.rotatable ?? []} />
        </section>

        {ENDPOINTS.map((endpoint) => (
          <Endpoint key={endpoint.id} endpoint={endpoint} ctx={ctx}
            language={language} onLanguage={setLanguage} exampleTo={exampleTo} />
        ))}

        <section id="dlr" className="space-y-2 scroll-mt-4">
          <h2 className="text-lg font-medium">Delivery receipts</h2>
          <p className="text-base leading-relaxed text-muted-foreground">
            Send with <Code>dlr: &quot;yes&quot;</Code> and a <Code>dlr_url</Code>, and the gateway
            POSTs JSON to that URL when the message reaches a final state. Answer with any 2xx; a
            failure is retried, and a URL that never answers is eventually given up on.
          </p>
          <p className="text-base leading-relaxed text-muted-foreground">
            <Code>dlr_level</Code> chooses which receipts you get: <Code>1</Code> progress only,{" "}
            <Code>2</Code> the outcome, <Code>3</Code> both. It defaults to <Code>2</Code>, so
            nothing changes for an existing integration. A progress receipt carries{" "}
            <Code>level: 1</Code> and a state such as <Code>ACCEPTD</Code> or <Code>BUFFRED</Code>;
            it means the carrier has the message and <em>not</em> that it is finished, so another
            receipt follows. Asking for <Code>1</Code> on its own gives you progress and no outcome
            — that is deliberate, not an oversight.
          </p>
          <p className="text-base leading-relaxed text-muted-foreground">
            <Code>dlr_method</Code> is accepted and has no effect: the receipt format is a
            gateway-wide setting, not something a single message chooses.
          </p>
          <FieldTable rows={DLR_FIELDS} head="Field" />
          <CodeBlock code={dlrExample(exampleTo ?? FALLBACK_MSISDN)} title="What arrives at your URL" copyLabel="Copy example" />
        </section>

        <section id="callbacks" className="space-y-2 scroll-mt-4">
          <h2 className="text-lg font-medium">Batch callbacks</h2>
          <p className="text-base leading-relaxed text-muted-foreground">
            A batch answers 200 as soon as it is queued, so the response says nothing about whether
            any individual message was accepted. Those results arrive as a bare <Code>GET</Code> —
            no body — against your <Code>callback_url</Code> or <Code>errback_url</Code>, one per
            message.
          </p>
          <p className="text-base leading-relaxed text-muted-foreground">
            This is the only place a per-message refusal appears. A message refused inside a batch for
            an unapproved sender, an empty balance or a rate limit never changes the HTTP response,
            and there is no endpoint to ask a batch how it went afterwards.
          </p>
          <FieldTable rows={BATCH_CALLBACK_PARAMS} head="Parameter" />
          <CodeBlock
            code={"GET https://your-app.example/batch-ok"
              + "?batchId=c0ffee12-9f3a-4a1e-8d55-1b2c3d4e5f60"
              + `\n    &to=${exampleTo || FALLBACK_MSISDN}&status=1`
              + "&statusText=7a2a5b6c-3ec3-44e0-b2a6-9b056b887c46"}
            title="An accepted message"
          />
        </section>

        <section id="errors" className="space-y-2 scroll-mt-4">
          <h2 className="text-lg font-medium">Errors</h2>
          <p className="text-base leading-relaxed text-muted-foreground">
            Every failure is <Code>{'{"message": "…"}'}</Code> with no <Code>data</Code> key, and the
            message is written to be read. These can come back from any authenticated call; the ones
            particular to an endpoint are listed with it above.
          </p>
          <ErrorTable errors={SHARED_ERRORS} />
          <p className="text-xs text-muted-foreground">
            On 429 there is no <Code>Retry-After</Code> header — back off and retry. The limit is per
            account, so adding logins does not raise it.
          </p>
        </section>
      </div>
    </div>
  );
}

/**
 * A second destination for the batch example, one digit on from the first.
 *
 * <p>Derived rather than a second constant so a localized example stays in its own country: a fixed
 * Australian sibling beside an Indian primary would read as a mistake, because it would be one.
 */
function sibling(msisdn: string): string {
  const last = msisdn.slice(-1);
  return /[0-9]/.test(last) ? msisdn.slice(0, -1) + ((Number(last) + 1) % 10) : msisdn;
}

function Endpoint({
  endpoint, ctx, language, onLanguage, exampleTo,
}: {
  endpoint: ApiEndpoint;
  /** The platform's example destination, or null to keep the catalogue's own. */
  exampleTo?: string | null;
  ctx: { baseUrl: string; login: string };
  language: CodeLanguage;
  onLanguage: (l: CodeLanguage) => void;
}) {
  const primary = exampleTo || FALLBACK_MSISDN;
  const example = useMemo(() => {
    const values: Record<string, unknown> = {};
    for (const field of endpoint.fields) {
      const example = exampleValue(field, exampleTo);
      if (example !== undefined) {
        values[field.name] = field.type === "integer" ? Number(example) : example;
      }
    }
    //no `from` on the send example, deliberately. Any value put here would be a sender ID this
    //account has probably not had approved, so pasting it would produce a 403 that reads as a
    //broken example -- and omitting it is correct anyway: the gateway substitutes the login name.
    //The smallest request that works is the one worth copying
    if (endpoint.id === "sendbatch") {
      values.messages = [
        //two destinations, because a batch of one teaches nothing about the shape. The second is
        //the first with its last digit moved on, so a localized example stays plausible
        { to: [primary, sibling(primary)], content: "Your OTP is 4417." },
      ];
    }
    return values;
  }, [endpoint, exampleTo, primary]);

  return (
    <section id={endpoint.id} className="space-y-2 scroll-mt-4">
      <h2 className="flex flex-wrap items-baseline gap-2 text-lg font-medium">
        {endpoint.title}
        <span className="font-mono text-xs text-muted-foreground">
          {endpoint.method} {endpoint.path}
        </span>
      </h2>
      <p className="text-base leading-relaxed text-muted-foreground">{endpoint.blurb}</p>

      {endpoint.fields.length > 0 && (
        <>
          <table className="w-full table-fixed border-collapse text-sm">
            <thead>
              <tr className="text-left text-xs uppercase tracking-wide text-muted-foreground">
                <th className="w-1/4 py-1.5 font-normal">
                  {endpoint.method === "GET" ? "Parameter" : "Field"}
                </th>
                <th className="w-1/6 py-1.5 font-normal">Type</th>
                <th className="py-1.5 font-normal">Notes</th>
              </tr>
            </thead>
            <tbody>
              {endpoint.fields.map((field) => (
                <tr key={field.name} className="border-t border-border align-top">
                  <td className="py-1.5 pr-4 font-mono text-sm">
                    {field.name}
                    {field.required === true && <span className="text-destructive"> *</span>}
                  </td>
                  {/*the type is the wire's own vocabulary -- `integer`, `object` -- sitting beside a
                     field name that is already monospace. Sans-serif here made the two halves of one
                     fact look like a label and a sentence*/}
                  <td className="py-1.5 pr-4 font-mono text-sm text-muted-foreground">
                    {field.type}
                  </td>
                  <td className="py-1.5 text-sm text-muted-foreground">
                    {field.note}
                    {/*the value in monospace, the sentence around it not: `Defaults to 2.` set as
                       prose reads as a number in a paragraph rather than as the literal to send*/}
                    {field.fallback && <> Defaults to <Code>{field.fallback}</Code>.</>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {endpoint.method === "POST" && (
            //the rule most likely to surprise somebody porting from another gateway, and it is a
            //400 rather than a last-one-wins
            <p className="text-xs text-muted-foreground">
              Underscores and hyphens are interchangeable — <Code>dlr_url</Code> and{" "}
              <Code>dlr-url</Code> are one field, and sending both is an error. The exception is{" "}
              <Code>custom_tlvs</Code>, which keeps its underscore.
            </p>
          )}

          {endpoint.fields.some((f) => f.name === "custom_tlvs") && <TlvAttributes />}
        </>
      )}

      <CodeBlock
        code={codeSample(language, endpoint, example, ctx)}
        title="Example"
        copyLabel="Copy example"
        right={
          <span className="flex gap-2">
            {CODE_LANGUAGES.map((l) => (
              <button key={l} type="button" onClick={() => onLanguage(l)}
                className={"text-xs " + (l === language
                  ? "border-b border-foreground text-foreground"
                  : "text-muted-foreground hover:text-foreground")}>
                {l}
              </button>
            ))}
          </span>
        }
      />
      {/*an HTTP status, which the error table two sections down already sets in monospace. A bare
         "200" in the body font was the same fact typeset two different ways on one page*/}
      <CodeBlock
        code={endpoint.success}
        title={<span className="font-mono">200</span>}
        copyLabel="Copy response"
      />

      {endpoint.errors.length > 0 && <ErrorTable errors={endpoint.errors} />}
    </section>
  );
}

function ErrorTable({ errors }: { errors: { status: number; message: string; when: string }[] }) {
  return (
    <table className="w-full table-fixed border-collapse text-sm">
      <thead>
        <tr className="text-left text-xs uppercase tracking-wide text-muted-foreground">
          <th className="w-12 py-1.5 font-normal">Code</th>
          <th className="w-2/5 py-1.5 font-normal">Message</th>
          <th className="py-1.5 font-normal">When</th>
        </tr>
      </thead>
      <tbody>
        {errors.map((e, i) => (
          <tr key={`${e.status}-${i}`} className="border-t border-border align-top">
            <td className="py-1.5 pr-4 font-mono text-sm">{e.status}</td>
            <td className="py-1.5 pr-4 font-mono text-sm text-muted-foreground">{e.message}</td>
            <td className="py-1.5 text-sm text-muted-foreground">{e.when}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function FieldTable({ rows, head }: { rows: { name: string; note: string }[]; head: string }) {
  return (
    <table className="w-full table-fixed border-collapse text-sm">
      <thead>
        <tr className="text-left text-xs uppercase tracking-wide text-muted-foreground">
          <th className="w-1/4 py-1.5 font-normal">{head}</th>
          <th className="py-1.5 font-normal">Meaning</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r.name} className="border-t border-border align-top">
            <td className="py-1.5 pr-4 font-mono text-sm">{r.name}</td>
            <td className="py-1.5 text-sm text-muted-foreground">{r.note}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function Chip({ label, value }: { label: string; value: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded bg-muted px-2 py-1">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-mono text-foreground">{value}</span>
      <CopyButton value={value} label={`Copy ${label.toLowerCase()}`} />
    </span>
  );
}

function Code({ children }: { children: React.ReactNode }) {
  return <code className="rounded bg-muted px-1 py-0.5 font-mono text-sm">{children}</code>;
}

/**
 * How to attach an SMPP optional parameter — the section this page did not have.
 *
 * <p>Written because a customer sending an India DLT template id had one sentence to go on and got
 * a 400 that quoted their own valid JSON back at them. The gateway's refusal cannot help there: it
 * says "has an invalid value" and the value looks fine, because what is wrong is the *shape* — a
 * string where an object belongs.
 *
 * <p>So the shape leads, and the tag table is second. Everything here is checked against
 * `SendRequestParser.readCustomTlvs`; `lib/custom-tlvs.ts` is the executable copy of the same rules.
 */
function TlvAttributes() {
  return (
    <div className="space-y-3 rounded-lg border border-border p-4">
      <div>
        <h4 className="text-base font-medium">TLV attributes</h4>
        <p className="mt-1 text-xs text-muted-foreground">
          Optional SMPP parameters, for the values a carrier requires beyond the message itself — an
          India DLT entity and template id, most often.
        </p>
      </div>

      <div>
        <p className="mb-1.5 text-xs text-muted-foreground">
          <Code>custom_tlvs</Code> is a JSON <strong>object</strong>. Not a list of pairs, and not a
          string containing JSON — a quoted one is refused with{" "}
          <Code>Argument custom_tlvs has an invalid value</Code>, which is the same message a
          non-numeric <Code>coding</Code> produces and so does not say which of the two happened.
        </p>
        <CodeBlock
          code={`{
  "to": "919216217231",
  "content": "Your OTP is 4417, valid for 10 minutes.",
  "custom_tlvs": {
    "0x1400": "1101234567890123456",
    "0x1401:Int8": 1401778070000018542
  }
}`}
          title="A DLT message with an entity and a template id"
          copyLabel="Copy example"
        />
      </div>

      <div>
        <p className="mb-1.5 text-xs font-medium">Keys</p>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left text-muted-foreground">
              <th className="py-1.5 pr-4 font-medium">Write</th>
              <th className="py-1.5 font-medium">Means</th>
            </tr>
          </thead>
          <tbody className="align-top">
            <tr className="border-b border-border/60">
              <td className="py-1.5 pr-4"><Code>0x1401</Code></td>
              <td className="py-1.5">Tag 0x1401. The usual form.</td>
            </tr>
            <tr className="border-b border-border/60">
              <td className="py-1.5 pr-4"><Code>0x1401:Int8</Code></td>
              <td className="py-1.5">The same tag, sent as an eight-byte integer instead of text.</td>
            </tr>
            <tr className="border-b border-border/60">
              <td className="py-1.5 pr-4"><Code>5121</Code></td>
              <td className="py-1.5">
                Also tag 0x1401 — a bare number is read as <strong>decimal</strong>. Watch this one:{" "}
                <Code>1401</Code> is decimal 1401, which is tag <Code>0x0579</Code>, not 0x1401.
              </td>
            </tr>
            <tr className="border-b border-border/60">
              <td className="py-1.5 pr-4"><Code>tmid_0x1401</Code></td>
              <td className="py-1.5">
                Tag 0x1401 with a name in front, for your own readability. The tag is whatever
                follows the last underscore.
              </td>
            </tr>
            <tr>
              <td className="py-1.5 pr-4"><Code>peid</Code></td>
              <td className="py-1.5">
                <strong>Refused.</strong> A name alone names no tag — this API matches on the number.
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div>
        <p className="mb-1.5 text-xs font-medium">Types</p>
        <p className="text-xs text-muted-foreground">
          Add <Code>:Type</Code> to a key to pin the wire encoding:{" "}
          <Code>OctetString</Code> (the default — the text as you wrote it),{" "}
          <Code>COctetString</Code> (the same, NUL-terminated), or{" "}
          <Code>Int1</Code> <Code>Int2</Code> <Code>Int4</Code> <Code>Int8</Code>.
        </p>
        <p className="mt-1 text-xs text-muted-foreground">
          <strong>The number in IntN is octets, not bits</strong> — <Code>Int8</Code> is an
          eight-byte field, which is the only one a DLT template id near 1.4×10¹⁸ fits in. A value
          too wide for its type is refused rather than truncated, and two keys resolving to the same
          tag are refused too.
        </p>
      </div>
    </div>
  );
}

/**
 * Base64 for the header example.
 *
 * <p>`btoa` throws on anything outside Latin-1, and a login is operator-chosen text that has never
 * been constrained to it. A header that cannot be encoded is shown as the pair instead, which is
 * still the useful half.
 */
function btoaSafe(pair: string): string {
  try {
    return btoa(pair);
  } catch {
    return `base64(${pair})`;
  }
}
