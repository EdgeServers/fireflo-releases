"use client";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RangePicker } from "./RangePicker";
import { useControlData, type Range } from "./useControlData";
import { count, money, percent } from "@/lib/format";

interface RevenueRow {
  accountId: string | null;
  product: string | null;
  messages: number;
  revenue: number;
  cost: number;
  margin: number;
  pendingRevenue: number;
}

export function RevenueClient() {
  const [range, setRange] = useState<Range>("24h");
  const { data, error, loading } = useControlData<RevenueRow[]>("revenue", range);
  const rows = data ?? [];

  const revenue = rows.reduce((a, r) => a + r.revenue, 0);
  const cost = rows.reduce((a, r) => a + r.cost, 0);
  const pending = rows.reduce((a, r) => a + r.pendingRevenue, 0);
  const margin = revenue - cost;

  return (
    <>
      <div className="flex items-center justify-between">
        <p className="text-base text-muted-foreground">
          Revenue counts each message once; cost counts every vendor attempt.
        </p>
        <RangePicker value={range} onChange={setRange} />
      </div>

      {error && (
        <Card>
          <CardContent className="py-6 text-base text-destructive">{error}</CardContent>
        </Card>
      )}

      {!error && !!rows.length && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-medium">Total</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-4">
            <Summary label="Billed" value={money(revenue)} />
            <Summary label="Vendor cost" value={money(cost)} />
            <Summary
              label="Margin"
              value={money(margin)}
              hint={revenue > 0 ? percent(margin / revenue) : undefined}
              tone={margin < 0 ? "negative" : "positive"}
            />
            {/* not an error: billed traffic with no outcome yet. The gateway's sweeper closes it
                as EXPIRED after 48h, so anything older than that means the sweeper is not running */}
            <Summary label="In flight" value={money(pending)} hint="Billed, outcome unknown" />
          </CardContent>
        </Card>
      )}

      {!error && !rows.length && (
        <div className="rounded-xl border border-border p-12 text-center text-muted-foreground">
          {loading ? "Loading…" : "No billed traffic in this period"}
        </div>
      )}

      {!!rows.length && (
        <>
          <div className="hidden overflow-hidden rounded-xl border border-border md:block">
            <table className="striped w-full text-sm">
              <thead className="border-b border-border bg-muted/50 text-left">
                <tr>
                  <th className="px-3 py-2.5 font-medium">Account</th>
                  <th className="px-3 py-2.5 font-medium">Product</th>
                  <th className="px-3 py-2.5 text-right font-medium">Messages</th>
                  <th className="px-3 py-2.5 text-right font-medium">Billed</th>
                  <th className="px-3 py-2.5 text-right font-medium">Cost</th>
                  <th className="px-3 py-2.5 text-right font-medium">Margin</th>
                  <th className="px-3 py-2.5 text-right font-medium">In flight</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r, i) => (
                  <tr
                    key={`${r.accountId}-${r.product}-${i}`}
                    className="border-b border-border last:border-0"
                  >
                    <td className="px-3 py-2.5 font-medium">{r.accountId ?? "—"}</td>
                    <td className="px-3 py-2.5 text-muted-foreground">{r.product ?? "—"}</td>
                    <td className="px-3 py-2.5 text-right tabular-nums">{count(r.messages)}</td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums">{money(r.revenue)}</td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums">{money(r.cost)}</td>
                    <td
                      className={`px-4 py-3 text-right font-mono tabular-nums ${
                        r.margin < 0 ? "text-destructive" : "text-primary"
                      }`}
                    >
                      {money(r.margin)}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-muted-foreground">
                      {money(r.pendingRevenue)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex flex-col gap-3 md:hidden">
            {rows.map((r, i) => (
              <Card key={`${r.accountId}-${r.product}-${i}`}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">
                    {r.accountId ?? "—"}
                    {r.product && (
                      <span className="ml-2 text-sm font-normal text-muted-foreground">{r.product}</span>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-2 gap-x-4 gap-y-1 text-base">
                  <span className="text-muted-foreground">Messages</span>
                  <span className="text-right tabular-nums">{count(r.messages)}</span>
                  <span className="text-muted-foreground">Billed</span>
                  <span className="text-right tabular-nums">{money(r.revenue)}</span>
                  <span className="text-muted-foreground">Cost</span>
                  <span className="text-right tabular-nums">{money(r.cost)}</span>
                  <span className="text-muted-foreground">Margin</span>
                  <span
                    className={`text-right tabular-nums ${r.margin < 0 ? "text-destructive" : "text-primary"}`}
                  >
                    {money(r.margin)}
                  </span>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      )}
    </>
  );
}

function Summary({
  label,
  value,
  hint,
  tone = "default",
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: "default" | "positive" | "negative";
}) {
  const toneClass =
    tone === "positive" ? "text-primary" : tone === "negative" ? "text-destructive" : "";
  return (
    <div>
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className={`font-mono text-2xl font-bold tabular-nums ${toneClass}`}>{value}</p>
      {hint && <p className="text-sm text-muted-foreground">{hint}</p>}
    </div>
  );
}
