"use client";
import { Activity, Layers, Link2, Timer } from "lucide-react";
import { StatCard } from "./StatCard";
import { type HealthWorker } from "@/lib/health-types";
import { needsAttention, verdictFor } from "@/lib/worker-verdict";
import { KIND, isOn, trafficKey, type Worker, type WorkerType } from "@/lib/worker-types";

/**
 * The four figures that answer "is anything wrong here" without scrolling.
 *
 * <p>Neither of these pages had a summary of any kind: the only way to learn that one vendor of six
 * had stopped carrying traffic was to scroll until a red badge appeared. The cards are still the
 * detail — this is the sentence above them.
 *
 * <p>Totalled across the page's own instances rather than read from a gateway-wide figure, so what
 * it says always matches the cards underneath it. `/cp/health` answers the gateway-wide question and
 * a second, subtly different total on this page would only invite the two to be compared.
 */
export function WorkerSummary({ workers, byFullName, type, loading, error }: {
  workers: Worker[];
  byFullName: Map<string, HealthWorker>;
  type: WorkerType;
  loading?: boolean;
  error?: string;
}) {
  const isVendor = type === KIND.vendor;
  if (!workers.length) {
    return null;
  }

  const live = workers.map((w) => byFullName.get(trafficKey(w)));
  const down = workers.filter((w) => needsAttention(verdictFor(w, byFullName, type))).length;
  const held = workers.some((w) => isOn(w, "pause") || isOn(w, "suspend"));

  const bound = sum(live.map((l) => l?.bound));
  const queued = sum(live.map((l) => l?.queue_depth)) + sum(live.map((l) => l?.retry_queue_depth));
  const measured = sum(live.map((l) => l?.tps_measured));
  const ceiling = sum(live.map((l) => l?.tps_limit));

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <StatCard
        title={isVendor ? "Vendors" : "Servers"}
        value={String(workers.length)}
        hint={down ? `${down} needing attention` : "All healthy"}
        icon={Layers}
        loading={loading}
        error={error}
        tone={down ? "negative" : "default"}
      />
      <StatCard
        title={isVendor ? "Bound" : "Bound customers"}
        value={bound.toLocaleString()}
        //a vendor with nothing bound cannot send at all; a listener with nobody bound is just quiet,
        //and painting that red sends somebody chasing a fault that does not exist
        hint={isVendor ? "Sessions carrying traffic out" : "Customers connected right now"}
        icon={Link2}
        loading={loading}
        error={error}
        tone={isVendor && bound === 0 ? "negative" : "default"}
      />
      <StatCard
        title="Queued"
        value={queued.toLocaleString()}
        hint={held ? "Something is held, so this only grows" : "Waiting to go out, including retries"}
        icon={Timer}
        loading={loading}
        error={error}
        tone={queued > 0 && held ? "negative" : "default"}
      />
      <StatCard
        title="Throughput"
        //the ceiling travels with the measurement, because a bare rate cannot say whether it is
        //healthy: 180/sec is either comfortable or pinned, depending entirely on the limit
        value={ceiling ? `${measured.toLocaleString()} of ${ceiling.toLocaleString()}` : measured.toLocaleString()}
        hint={measured === 0 && queued > 0 ? "Messages waiting and nothing moving" : "Messages per second"}
        icon={Activity}
        loading={loading}
        error={error}
        tone={measured === 0 && queued > 0 ? "negative" : "default"}
      />
    </div>
  );
}

/** Null and undefined contribute nothing, rather than turning the whole total into NaN. */
function sum(values: (number | null | undefined)[]): number {
  return values.reduce<number>((total, v) => total + (v ?? 0), 0);
}
