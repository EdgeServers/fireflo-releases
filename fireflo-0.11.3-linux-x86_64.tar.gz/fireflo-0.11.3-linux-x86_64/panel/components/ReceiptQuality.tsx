"use client";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RangePicker } from "./RangePicker";
import { useControlData, type Range } from "./useControlData";
import { count, elapsed, percent } from "@/lib/format";

/**
 * Whether each vendor tells us what happened, and how quickly.
 *
 * <p>A different question from the one Vendors already answers. That page shows a delivery rate —
 * delivered over *reported* — and a vendor reporting on 40% of the traffic it carries can show 95%
 * there while three messages in five have no outcome at all. Both numbers are true; only one of them
 * is about the vendor's behaviour, and the panel used to show only the flattering one.
 *
 * <p><strong>The comparison is the point</strong>, which is why this is a page rather than a card on
 * each vendor. "Two and a half minutes to an outcome" means nothing alone and everything beside a
 * vendor doing the same job in nine seconds.
 */

/** Mirrors `ReceiptQualityRow` in `lib/receipt-queries.ts`. */
export interface ReceiptQualityRow {
  vendor: string | null;
  sent: number;
  reported: number;
  expired: number;
  open: number;
  delivered: number;
  medianToOutcome: number | null;
  p90ToOutcome: number | null;
  progressReceipts: number | null;
  messagesWithProgress: number | null;
  medianToFirstSign: number | null;
}

/** Settled messages the vendor actually reported on. Open traffic is not counted as silence. */
export function reportingRate(row: ReceiptQualityRow): number | null {
  const settled = row.reported + row.expired;
  return settled === 0 ? null : row.reported / settled;
}

export function ReceiptQualityClient() {
  const [range, setRange] = useState<Range>("24h");
  const { data, error, loading } = useControlData<ReceiptQualityRow[]>("receipts", range);
  const rows = data ?? [];
  //null on every row means the gateway has no cdr_interim, not that no vendor sends progress
  const progressRecorded = rows.some((r) => r.progressReceipts !== null);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-base text-muted-foreground">
          How often each vendor reports an outcome, and how long it takes to arrive.
        </p>
        <RangePicker value={range} onChange={setRange} />
      </div>

      {error && (
        <Card>
          <CardContent className="py-6 text-base text-destructive">{error}</CardContent>
        </Card>
      )}

      {!error && !rows.length && (
        <div className="rounded-xl border border-border p-12 text-center text-muted-foreground">
          {loading ? "Loading…" : "No traffic in this period"}
        </div>
      )}

      {!!rows.length && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-medium">By vendor</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="overflow-x-auto">
              <table className="striped w-full text-sm tabular-nums">
                <thead className="text-muted-foreground">
                  <tr className="text-left">
                    <th className="py-1.5 pr-4 font-medium">Vendor</th>
                    <th className="py-1.5 pr-4 text-right font-medium">Sent</th>
                    <th className="py-1.5 pr-4 text-right font-medium">Reported</th>
                    <th className="py-1.5 pr-4 text-right font-medium">Reporting rate</th>
                    <th className="py-1.5 pr-4 text-right font-medium">Gave up on</th>
                    <th className="py-1.5 pr-4 text-right font-medium">Still open</th>
                    <th className="py-1.5 pr-4 text-right font-medium">Delivered</th>
                    <th className="py-1.5 pr-4 text-right font-medium">Median</th>
                    <th className="py-1.5 pr-4 text-right font-medium">90th</th>
                    <th className="py-1.5 text-right font-medium">Progress</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row) => (
                    <tr key={row.vendor ?? "none"} className="border-t border-border">
                      <td className="py-1.5 pr-4">
                        {row.vendor ?? <span className="text-muted-foreground">no vendor</span>}
                      </td>
                      <td className="py-1.5 pr-4 text-right">{count(row.sent)}</td>
                      <td className="py-1.5 pr-4 text-right">{count(row.reported)}</td>
                      <td className="py-1.5 pr-4 text-right">
                        <ReportingBadge rate={reportingRate(row)} />
                      </td>
                      <td className="py-1.5 pr-4 text-right">{count(row.expired)}</td>
                      <td className="py-1.5 pr-4 text-right">{count(row.open)}</td>
                      <td className="py-1.5 pr-4 text-right">
                        {row.reported === 0
                          ? "—"
                          : percent(row.delivered / row.reported)}
                      </td>
                      <td className="py-1.5 pr-4 text-right">{elapsed(row.medianToOutcome)}</td>
                      <td className="py-1.5 pr-4 text-right">{elapsed(row.p90ToOutcome)}</td>
                      <td className="py-1.5 text-right">
                        {row.progressReceipts === null
                          ? <span className="text-muted-foreground" title="not recorded">·</span>
                          : count(row.progressReceipts)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="space-y-1 text-sm text-muted-foreground">
              <p>
                <strong>Reporting rate</strong> is outcomes the vendor sent, over the messages that
                have settled one way or another. Messages still in flight are left out of the
                denominator entirely — traffic sent a minute ago has not had its chance yet, and
                counting it as silence would make every vendor look worse the sooner you looked.
              </p>
              <p>
                <strong>Gave up on</strong> is our own sweeper writing EXPIRED because no receipt
                ever arrived. Those are not counted as reported, which is the difference between
                this table and the delivery rate on Vendors: that one is computed over a denominator
                the vendor itself chose.
              </p>
              <p>
                <strong>Delivered</strong> is a share of what was reported, so it says nothing about
                the messages in the two columns before it.
              </p>
              {progressRecorded ? (
                <p>
                  <strong>Progress</strong> counts non-terminal receipts — ACCEPTD, BUFFRED — that
                  say a message is moving without saying how it ended. A vendor sending none is not
                  at fault; it simply will not tell you anything before the end.
                </p>
              ) : (
                <p>
                  <strong>Progress is not recorded by this gateway.</strong> <code>cdr_interim</code>
                  {" "}arrives in V1.33.0, and until it does a non-terminal receipt leaves no trace,
                  so the column is blank rather than zero.
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

/**
 * How often this vendor says anything at all, on the same scale the delivery badge uses.
 *
 * <p>Coloured, unlike most numbers in this panel, because it is the one an operator is looking for:
 * a vendor below 70% is losing the platform its own view of what happened to paid traffic.
 */
function ReportingBadge({ rate }: { rate: number | null }) {
  if (rate === null) {
    return <span className="text-muted-foreground">—</span>;
  }
  return (
    <Badge variant={rate >= 0.95 ? "success" : rate >= 0.7 ? "outline" : "destructive"}>
      {percent(rate)}
    </Badge>
  );
}

/**
 * How well this vendor reports back, under its card on `/cp/vendors`.
 *
 * <p>This used to render four of `ReceiptQualityRow`'s eleven fields on the reasoning that the
 * card should prompt someone to open the full report rather than duplicate it. The four it chose
 * were the right four, but the seven it dropped were fetched on every poll and thrown away, and
 * two of them are the ones that make the first four checkable:
 *
 * <ul>
 *   <li><strong>the denominators.</strong> "Reports outcomes 98%" is a ratio with its terms
 *       hidden. `sent`, `reported` and `open` are what it is a ratio of, and without them a
 *       reassuring percentage over eleven settled messages looks the same as one over fifty
 *       thousand</li>
 *   <li><strong>time to the first sign of life</strong>, as distinct from time to a final
 *       outcome. A vendor that acknowledges in a second and settles in ten minutes and one that
 *       says nothing for ten minutes have the same median to outcome and are not the same vendor</li>
 *   <li><strong>progress coverage</strong> — how much of the traffic reports intermediate state at
 *       all, which is what says whether the previous figure describes the traffic or a corner of it</li>
 * </ul>
 *
 * <p>Still not a copy of the report: the per-vendor table on `/cp/receipts` compares vendors
 * against each other, which is a different question from how this one is behaving.
 */
export function ReceiptQualityLine({ row }: { row: ReceiptQualityRow | undefined }) {
  if (!row) {
    //not zeros. Nothing was measured, which is different from measuring nothing
    return null;
  }
  const rate = reportingRate(row);

  return (
    <div className="space-y-2 border-t border-border pt-3">
      <p className="text-xs text-muted-foreground">Delivery receipts</p>
      <dl className="grid gap-x-6 gap-y-2 text-sm sm:grid-cols-2 lg:grid-cols-4">
        <div className="flex items-center justify-between gap-2 sm:block">
          <dt className="text-muted-foreground">Reports outcomes</dt>
          <dd className="font-medium tabular-nums">
            <ReportingBadge rate={rate} />
          </dd>
        </div>
        <Stat label="Sent" value={count(row.sent)} />
        <Stat label="Reported" value={count(row.reported)} />
        <Stat label="Still open" value={count(row.open)} />
        {/* first sign beside final outcome, in that order: they are the same clock read at two
            points, and the gap between them is the reading */}
        <Stat label="Median to first sign" value={elapsed(row.medianToFirstSign)} />
        <Stat label="Median to outcome" value={elapsed(row.medianToOutcome)} />
        <Stat label="90th percentile" value={elapsed(row.p90ToOutcome)} />
        <Stat
          label="Never reported"
          value={count(row.expired)}
          note={row.expired > 0 ? "swept as expired" : undefined}
        />
      </dl>
      {/* one sentence rather than two more tiles: the pair only means anything together, and the
          share is what says whether the median above describes the traffic or a corner of it */}
      {row.progressReceipts != null && row.messagesWithProgress != null && (
        <p className="text-sm text-muted-foreground">
          Progress receipts{" "}
          <span className="font-medium tabular-nums text-foreground">
            {count(row.progressReceipts)}
          </span>{" "}
          across{" "}
          <span className="font-medium tabular-nums text-foreground">
            {count(row.messagesWithProgress)}
          </span>{" "}
          messages
          {row.sent > 0 && (
            <> · {percent(row.messagesWithProgress / row.sent)} of traffic reports intermediate state</>
          )}
        </p>
      )}
    </div>
  );
}

function Stat({ label, value, note }: { label: string; value: string; note?: string }) {
  return (
    <div className="flex items-center justify-between gap-2 sm:block">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="font-medium tabular-nums">
        {value}
        {note && <span className="ml-1 font-normal text-muted-foreground">{note}</span>}
      </dd>
    </div>
  );
}
