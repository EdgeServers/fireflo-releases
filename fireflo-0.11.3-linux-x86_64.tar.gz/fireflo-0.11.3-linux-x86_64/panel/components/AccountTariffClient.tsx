"use client";
import { useCallback, useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { ErrorCard, SavedNote } from "./FormNotices";
import { GatewayIgnores } from "./GatewayIgnores";
import { ScopeForm } from "./ScopeForm";
import { useProductCatalogue } from "./useProducts";
import { useRates } from "./useRates";
import { scopeKind, type RateRule, type RateRuleInput } from "@/lib/rate-types";
import { formatClockTime } from "@/lib/datetime";

/**
 * One account's custom tariff, on a page of its own.
 *
 * <p>It used to sit at the bottom of the account page, and it did not belong there. A rule list is
 * as wide as the screen, grows without limit, and every row carries a condition editor — so it took
 * over the page it was a section of, and pushed everything above it out of view for anyone whose
 * account had more than a handful of rules. Pricing is also the one thing on that page you arrive to
 * do deliberately, rather than something you glance at while doing something else.
 *
 * <p>The whole scope loads and saves here, which is what makes reordering possible: {@code
 * saveScope} rewrites `seq` from array position and deletes any rule it is not given, so an editor
 * holding a filtered view could not be allowed to move anything. This one holds all of it.
 */
export function AccountTariffClient({ id }: { id: string }) {
  const { known, loadScope, saveScope } = useRates();

  const [rules, setRules] = useState<RateRule[] | null>(null);
  const [savedAt, setSavedAt] = useState<string | null>(null);
  const [error, setError] = useState("");

  const kind = scopeKind(id, known);
  const productCatalogue = useProductCatalogue();

  const loadRules = useCallback(async () => {
    setRules((await loadScope(id)) ?? []);
  }, [id, loadScope]);

  useEffect(() => {
    void loadRules();
  }, [loadRules]);

  return (
    <>
      {/* no BackLink and no heading: this is a tab now, and the shell above it already names the
          account and offers the way out. Two back links on one page is worse than none */}
      <GatewayIgnores domain="rates" />
      <ErrorCard error={error} />
      <SavedNote
        at={savedAt}
        detail={"The gateway picks pricing up on its next configuration poll, within thirty "
          + "seconds — there is no immediate push for rates."}
      />

      {kind === "cost" && (
        <Card className="border-destructive">
          <CardContent className="py-3 text-base text-destructive">
            A vendor is also called <code>{id}</code>. Rating matches a rate scope by name alone, so
            these rules are read as <strong>our cost for that vendor</strong> as well as this
            account&apos;s price. Rename one before pricing either.
          </CardContent>
        </Card>
      )}

      {rules === null ? (
        <p className="text-base text-muted-foreground">Loading…</p>
      ) : (
        <ScopeForm
          //keyed on CONTENT, not on ids. Editing an amount leaves every id unchanged, so an
          //id-only key never remounted and the editor went on showing the array it had submitted
          //rather than what came back -- which is exactly why a save was indistinguishable from a
          //failed one. Now the fields are re-seeded from the reload, so what is on screen after a
          //save is what is stored
          key={rules.map((r) => `${r.id}:${r.seq}:${r.amount}:${r.product ?? ""}:${r.enabled}`).join("|")}
          scope={id}
          initial={rules as RateRuleInput[]}
          known={known}
          catalogue={productCatalogue}
          isNew={rules.length === 0}
          locked
          onDirty={() => setSavedAt(null)}
          onSave={async (scope, next, confirmed) => {
            const failure = await saveScope(scope, next, confirmed, rules.length === 0);
            if (!failure) {
              await loadRules();
              setSavedAt(formatClockTime(new Date()));
            }
            return failure;
          }}
          onCancel={() => {
            setError("");
            void loadRules();
          }}
        />
      )}
    </>
  );
}
