"use client";
import { useEffect, useState } from "react";
import { Columns3, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AccountTableCell } from "./AccountTableCell";
import { ColumnChooser } from "./ColumnChooser";
import { surface } from "@/lib/panel-surface";
import { DangerAction } from "./DangerAction";
import { CredentialForm } from "./CredentialForm";
import { Dialog } from "@/components/ui/dialog";
import { useCredentials } from "./useCredentials";
import { useHealth } from "./useHealth";
import { readsCredentialsFromDatabase } from "@/lib/health-types";
import type { Credential } from "@/lib/credential-types";
import {
  LOGIN_COLUMNS,
  LOGIN_COLUMN_GROUPS,
  RESELLER_LOGIN_COLUMNS,
  LOGIN_COLUMN_STORAGE_KEY,
  loginRow,
  resolveLoginColumnsFor,
} from "@/lib/account-columns";
import { type ColumnChoice, readColumnChoice, toggleColumn } from "@/lib/table-columns";

/**
 * Who can connect — the SMPP and HTTP logins.
 *
 * <p>Sits above the traffic table on the Accounts page rather than replacing it. The two are keyed
 * differently and both keys are right: traffic groups by account, system id and product because that
 * is how the money splits, while a login is one row. And the traffic view has to keep working with no
 * configuration database at all, which is the ordinary case.
 */
export function CredentialsClient({
  account,
  chrome = true,
  addOpen = false,
  onAddHandled,
}: {
  account?: string;
  /**
   * Opens the new-login form from outside.
   *
   * <p>With `chrome` off the card around this owns the "Add login" button -- it lives in the card's
   * footer, beside nothing else, where an action on the whole list belongs. That button has to be
   * able to reach this component's editing state, and this is the smallest way to let it: one
   * boolean in, one callback back when the form has taken it.
   */
  addOpen?: boolean;
  onAddHandled?: () => void;
  /**
   * Whether to render this component's own description, "Add login" button and empty-state box.
   *
   * <p>False when a card around it already supplies them -- otherwise the parent's heading and this
   * component's paragraph say the same thing twice, one under the other.
   */
  chrome?: boolean;
} = {}) {
  const { credentials: all, context, error, loading, busy, disabled, save, setEnabled, remove } =
    useCredentials();
  const { health } = useHealth();
  const [editing, setEditing] = useState<Credential | "new" | null>(null);
  const [choice, setChoice] = useState<ColumnChoice | null>(null);
  const [chooserOpen, setChooserOpen] = useState(false);

  //after mount, never in a lazy initialiser: localStorage does not exist during the server render
  //and React 19 throws on the mismatch rather than patching it up
  useEffect(() => {
    setChoice(readColumnChoice(window.localStorage.getItem(LOGIN_COLUMN_STORAGE_KEY)));
  }, []);

  function storeColumns(next: ColumnChoice) {
    setChoice(next);
    window.localStorage.setItem(LOGIN_COLUMN_STORAGE_KEY, JSON.stringify(next));
  }

  //adopt the parent's request to open the form, then tell it so it can reset its own flag
  useEffect(() => {
    if (addOpen) {
      setEditing("new");
      onAddHandled?.();
    }
  }, [addOpen, onAddHandled]);

  //scoped to one account when this is mounted on that account's page. `billingAccount` is resolved
  //server-side through billingOf, so this catches the logins that reach the account by the
  //system-id fallback as well -- and those are the ones worth showing, because they mention it
  //nowhere a search would find
  const credentials = account ? all.filter((c) => c.billingAccount === account) : all;

  if (disabled) {
    return (
      <p className="text-base text-muted-foreground">
        Editing logins is switched off — <code>CONFIG_DATABASE_URL</code> is not set.
      </p>
    );
  }


  const fromDatabase = readsCredentialsFromDatabase(health);
  //what this surface may show about what a login is charged -- see lib/panel-surface.ts. The
  //chooser and the resolver read the same catalogue, or a stored choice naming a pricing column
  //brings it back on a surface that filtered it out
  const { pricing } = surface();
  const catalogue = pricing ? LOGIN_COLUMNS : RESELLER_LOGIN_COLUMNS;
  const columns = resolveLoginColumnsFor(choice, pricing);

  const form = (
    <CredentialForm
      initial={editing === "new" || editing === null ? null : editing}
      context={context}
      defaultAccountId={account}
      //product and allowed products are the price -- see CredentialForm
      allowPricing={pricing}
      onSave={async (input) => {
        const failure = await save(input);
        if (!failure) {
          setEditing(null);
        }
        return failure;
      }}
      onCancel={() => setEditing(null)}
    />
  );

  const list = (
    <div className="space-y-3">
      {chrome && (
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-base text-muted-foreground">
            Who may connect, and which account their traffic bills to.
          </p>
          <Button onClick={() => setEditing("new")} size="sm" className="gap-2">
            <Plus className="h-4 w-4" />
            Add login
          </Button>
        </div>
      )}

      {/* the single most destructive switch in the panel: with this table empty and the source
          flipped, no customer can connect at all, and nothing in the logs names the cause */}
      {fromDatabase === false && (
        <Card className="border-destructive">
          <CardContent className="py-4 text-base">
            <strong>These logins are not in use.</strong> The gateway is authenticating from{" "}
            <code className="text-sm">conf/credentials.yml</code>, not the database — anything here is
            stored, valid, and ignored. Before switching it with{" "}
            <code className="text-sm">FIREFLO_CONFIG_SOURCE=db</code>, make sure this list is
            complete: an empty table refuses <em>every</em> bind and <em>every</em> REST call at once,
            with no fallback to the file. <code className="text-sm">scripts/fireflo import credentials</code>{" "}
            fills it from the file.
          </CardContent>
        </Card>
      )}

      {fromDatabase === true && !all.length && !loading && (
        <Card className="border-destructive">
          <CardContent className="py-4 text-base text-destructive">
            <strong>The gateway is authenticating from this database, and it is empty.</strong> No
            customer can connect. Import from the file or add a login now.
          </CardContent>
        </Card>
      )}

      {error && (
        <Card>
          <CardContent className="py-4 text-base text-destructive">{error}</CardContent>
        </Card>
      )}

      {!credentials.length && !error && (
        chrome ? (
          <div className="rounded-xl border border-border p-8 text-center text-base text-muted-foreground">
            {loading ? "Loading…" : "No logins stored"}
          </div>
        ) : (
          <p className="py-4 text-base text-muted-foreground">
            {loading ? "Loading…" : "No login bills to this account yet."}
          </p>
        )
      )}

      {/*
        A table over the same catalogue the /accounts index reads, narrowed to the Login group. It
        replaced hairline rows that showed a system id, two badges and a "Bills to" line -- which said
        the account this card's own title already names, and hid product, IPs, auth and TLVs behind
        opening each login in turn.
      */}
      {!!credentials.length && (
        <>
          <div className="flex justify-end">
            <Button variant="outline" size="sm" className="h-8 gap-1.5"
              onClick={() => setChooserOpen((v) => !v)} aria-expanded={chooserOpen}>
              <Columns3 className="h-4 w-4" />
              Columns
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="striped w-full text-sm">
              <thead className="border-b border-border text-left text-muted-foreground">
                <tr>
                  {columns.map((column) => (
                    <th key={column.id}
                      className={`px-3 py-2 font-medium ${column.align === "right" ? "text-right" : ""}`}>
                      {column.header}
                    </th>
                  ))}
                  <th className="px-3 py-2.5" />
                </tr>
              </thead>
              <tbody>
                {credentials.map((c) => {
                  const row = loginRow(c);
                  return (
                    <tr key={c.id} className="border-b border-border last:border-0">
                      {columns.map((column) => (
                        <td key={column.id}
                          className={`px-3 py-2 align-top ${column.align === "right" ? "text-right" : ""}`}>
                          <AccountTableCell column={column} row={row} onOpenLogin={() => setEditing(c)} />
                        </td>
                      ))}
                      {/* never choosable: a row you cannot act on is not a row. Edit is gone -- the
                          system id opens the editor, the same way it does on the index */}
                      <td className="whitespace-nowrap px-3 py-2.5 text-right align-top">
                        <Button variant="ghost" size="sm" disabled={busy === c.id}
                          //disabling drops whatever this login is holding as well as refusing the
                          //next bind. Stored `enabled` alone governs only future binds, so without
                          //that a login went grey here while the customer carried on sending
                          title={c.enabled
                            ? "Refuse new binds, and drop any this login is holding now"
                            : "Allow this login to bind again"}
                          onClick={() => setEnabled(c.id, !c.enabled)}>
                          {c.enabled ? "Disable" : "Enable"}
                        </Button>
                        <DangerAction
                          label="Delete"
                          confirmLabel="Delete this login"
                          busy={busy === c.id}
                          consequence={
                            `'${c.systemId ?? c.id}' stops being able to connect at the gateway's `
                            + "next poll. Past call records survive, but nothing else records who "
                            + "this system ID belonged to."
                          }
                          onConfirm={() => remove(c.id)}
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {chooserOpen && (
            <ColumnChooser
              columns={catalogue}
              groups={LOGIN_COLUMN_GROUPS}
              enabled={new Set(columns.map((c) => c.id))}
              onToggle={(id, on) => storeColumns(toggleColumn(choice, id, on))}
              onReset={() => {
                setChoice(null);
                window.localStorage.removeItem(LOGIN_COLUMN_STORAGE_KEY);
              }}
              note="Separate from the columns chosen on the accounts index."
            />
          )}
        </>
      )}
    </div>
  );

  /*
    Embedded, the form opens in a dialog rather than replacing the section. Swapping it out worked
    when this component owned the whole page; inside somebody else's card it would put a four-part
    form in the card's body and take the card's title away while you edited, which is the one moment
    you most want to know which account you are editing a login for.
  */
  if (editing && !chrome) {
    return (
      <>
        {list}
        <Dialog
          open
          onClose={() => setEditing(null)}
          title={editing === "new" ? "New login" : `Editing ${editing.systemId ?? `#${editing.id}`}`}
          description={account ? `Billing to ${account}.` : undefined}
          className="max-w-3xl"
        >
          {form}
        </Dialog>
      </>
    );
  }
  if (editing) {
    return form;
  }


  return list;
}
