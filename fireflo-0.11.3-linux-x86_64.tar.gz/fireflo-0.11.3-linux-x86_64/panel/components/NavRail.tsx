"use client";
import Link from "next/link";
import { cn } from "@/lib/utils";

/**
 * The two pieces both navs are built from.
 *
 * <p>Extracted when the portal grew a dashboard and its nav went from three flat links to six in
 * groups — the shape the operator panel had already settled on. The alternative was a second copy
 * of the accent bar, the collapsed tooltip rule and the `aria-current` handling, which is exactly
 * the kind of duplication that is identical on the day it is written and subtly different a month
 * later.
 *
 * <p><strong>What is deliberately not shared is which link is active.</strong> The operator matches
 * by prefix so a detail page keeps its section lit; the portal matches exactly, because its root is
 * a prefix of every other route it has. Both rules are right for their own app and neither
 * generalises, so the caller decides and passes a boolean.
 */

/**
 * A group's label, or the rule that stands in for it on the rail.
 *
 * <p>The rail cannot show the word, but it still needs the grouping — without some mark the icons
 * read as one undifferentiated column. A hairline costs no width and keeps the same rhythm.
 */
export function NavGroupHeading({ label, collapsed }: { label: string; collapsed: boolean }) {
  if (collapsed) {
    return <div className="mx-2 my-2 border-t border-border/70" aria-hidden />;
  }
  return (
    <p className="px-3 pb-1 text-2xs font-semibold uppercase tracking-[0.12em] text-muted-foreground">
      {label}
    </p>
  );
}

/**
 * One nav row.
 *
 * <p>At module scope rather than inside a shell: a component declared during render is a new
 * component type on every render, so React unmounts and remounts the whole nav each time — losing
 * focus and any transient state with it.
 */
export function NavLink({ href, label, icon: Icon, collapsed, active }: {
  href: string;
  label: string;
  icon: React.ElementType;
  collapsed: boolean;
  /** Computed by the caller — see the note above about why this is not decided here. */
  active: boolean;
}) {
  return (
    <Link
      href={href}
      //the name is the tooltip when it is not on screen, so a rail is still navigable without
      //learning the icons
      title={collapsed ? label : undefined}
      aria-label={collapsed ? label : undefined}
      //the one thing a screen reader cannot infer from styling
      aria-current={active ? "page" : undefined}
      className={cn(
        //py-2.5 below md:, so a nav row clears the 44px a thumb needs. They drop back to py-2 on a
        //pointer device, where the smaller target was never the problem. The breakpoint is md: and
        //not sm: because that is where the nav becomes a drawer -- between 640 and 768 the drawer
        //is still showing and the device is still being touched. See ui/button.tsx.
        "group relative flex min-h-11 items-center rounded-lg py-2.5 text-sm transition-colors duration-150 md:min-h-0 md:py-2",
        collapsed ? "justify-center px-0" : "gap-3 px-3",
        active
          ? "bg-primary/10 font-semibold text-primary"
          : "font-medium text-muted-foreground hover:bg-accent/60 hover:text-foreground"
      )}
    >
      {/* the accent bar carries the active state as shape as well as colour, so it survives a
          colour-blind reader and a low-contrast display -- neither of which a tint alone does */}
      {active && (
        <span
          aria-hidden
          className={cn(
            "absolute left-0 top-1/2 h-5 w-0.5 -translate-y-1/2 rounded-r-full bg-primary",
            collapsed && "h-6"
          )}
        />
      )}
      <Icon className={cn("h-4 w-4 shrink-0", active ? "text-primary" : "text-muted-foreground")} />
      {!collapsed && <span className="truncate">{label}</span>}
    </Link>
  );
}
