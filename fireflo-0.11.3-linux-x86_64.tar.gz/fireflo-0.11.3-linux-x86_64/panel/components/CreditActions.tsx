"use client";
import { useRef, useState } from "react";
import { DangerAction } from "./DangerAction";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { surface } from "@/lib/panel-surface";
import {
  formatAmount,
  type InheritedCurrency,
  parseAmount,
  validateBillingChange,
  validateCurrency,
  validateTopUp,
  type BillingMode,
} from "@/lib/balance-types";

/**
 * Opening an account for credit, and topping it up.
 *
 * <p>The only write in this panel that moves money, which shapes everything about it: the amount is
 * confirmed before it is sent, the reference is required rather than optional, and the form says out
 * loud that the gateway applies it on its next poll rather than immediately.
 *
 * <p>Top-ups are positive only. `balance_ledger.delta` may be negative and `entry_type` may be
 * `ADJUST`, so taking credit away is a small change away — but a panel that can debit a customer is
 * a different conversation from one that can credit them, and this is not it.
 */
export function CreditActions({
  accountId,
  hasRow,
  currency,
  inheritedCurrency,
  funding = "recharge",
  mayGrantPostpaid = true,
  postpaidHeadroom = null,
  enabled,
  billingMode,
  creditLimit,
  onDone,
}: {
  accountId: string;
  hasRow: boolean;
  /** The currency on the balance row, once it exists. */
  currency: string | null;
  /**
   * What a row that does not exist yet should be denominated in, and where that was decided.
   *
   * <p>`{code: null}` means neither the gateway nor a parent account could answer — the only case in
   * which anybody is asked, and only on the operator panel. See `chooseCurrency`.
   */
  inheritedCurrency: InheritedCurrency;
  /**
   * Where the money adding to this balance comes from.
   *
   * <p>`"recharge"` is the operator's: a `RECHARGE` row credits the account and **nothing is
   * debited anywhere**. That is the platform issuing credit, and it belongs to whoever carries the
   * receivable.
   *
   * <p>`"transfer"` is a reseller's: a `TRANSFER` row moves the caller's own balance to this
   * account, debiting the payer in the same statement that credits the payee. Two directions —
   * down to fund, up to take back — because a reseller that can only ever push money out has no way
   * to correct an overpayment.
   *
   * <p>Defaults to `"recharge"`, so every operator caller is unchanged. The portal's balance route
   * refuses `topUp` by name regardless, so this prop decides what the interface offers rather than
   * what the server permits.
   */
  funding?: "recharge" | "transfer";
  /**
   * Whether whoever is looking may put this account on postpaid terms.
   *
   * <p>False for a **prepaid reseller**: postpaid is a credit line, and a reseller with none from
   * the operator has none to pass down. The route refuses it too — this is the form not offering
   * what the server would reject, which is the difference between a control and a trap.
   *
   * <p>Defaults to true, which is the operator: they are the party that extends credit.
   */
  mayGrantPostpaid?: boolean;
  /**
   * The largest postpaid limit this account may be given, or null for no ceiling.
   *
   * <p>A reseller's own limit minus what it has already committed to its other children. The route
   * refuses anything above it; showing the number here is what turns that refusal into a form the
   * reader can fill in correctly the first time.
   */
  postpaidHeadroom?: number | null;
  enabled: boolean;
  billingMode: BillingMode;
  /** Scaled by 10,000. Zero on a prepaid row, where it means nothing. */
  creditLimit: number;
  onDone: () => void | Promise<void>;
}) {
  const [open, setOpen] = useState<"open" | "topUp" | "takeBack" | "billing" | null>(null);
  //a ref rather than state: changing it must not re-render, and it must not be reset by one
  const transferKey = useRef<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function post(body: Record<string, unknown>): Promise<boolean> {
    setBusy(true);
    setError("");
    try {
      const res = await fetch(
        `${surface().apiBase}/accounts/${encodeURIComponent(accountId)}/balance`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        }
      );
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return false;
      }
      setNotice(json?.notice ?? "");
      await onDone();
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
      return false;
    } finally {
      setBusy(false);
    }
  }

  /**
   * Moves the caller's own balance to or from this account.
   *
   * <p>A different endpoint from `post`, deliberately: `/api/mis/transfer` writes a `TRANSFER` row
   * against two accounts and proves the subject is one of the caller's children, which is a
   * different check from "may I edit this balance row".
   *
   * <p>The key is held across retries and cleared only once one is queued, which is what makes it a
   * key rather than a serial number. A double-click, or a
   * retry after a network failure that actually landed, sends the same value and the server answers
   * 409 rather than queueing a second transfer.
   */
  async function transfer(direction: "down" | "up", amount: string): Promise<boolean> {
    setBusy(true);
    setError("");
    transferKey.current ??= `xfer:${crypto.randomUUID()}`;
    try {
      const res = await fetch("/api/mis/transfer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ accountId, amount, direction, ref: transferKey.current }),
      });
      const json = await res.json().catch(() => null);
      //409 means an earlier attempt landed, so the transfer exists either way and the form has to
      //move on. Treating it as a failure would invite the retry that was just refused
      if (!res.ok && res.status !== 409) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return false;
      }
      transferKey.current = null;
      setNotice(json?.data?.message ?? "Queued.");
      await onDone();
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
      return false;
    } finally {
      setBusy(false);
    }
  }

  if (!hasRow) {
    return (
      <div className="space-y-2 border-t border-border/40 pt-3">
        {open === "open" ? (
          <OpenForm
            inherited={inheritedCurrency}
            askable={surface().pricing}
            busy={busy}
            error={error}
            onCancel={() => { setOpen(null); setError(""); }}
            onSubmit={async (typed) => {
              //`currency` is sent ONLY when the operator typed one, which is the one case where the
              //server has nothing to resolve. When it was inherited the field is absent entirely --
              //both routes resolve it themselves, so a request cannot carry a code the form never
              //showed, and the two cannot disagree
              const body: Record<string, unknown> = { action: "open", enabled: true };
              if (typed) {
                body.currency = typed;
              }
              if (await post(body)) {
                setOpen(null);
              }
            }}
          />
        ) : (
          <>
            <Button size="sm" variant="outline" className="h-7" onClick={() => setOpen("open")}>
              Open for credit
            </Button>
            <p className="text-xs text-muted-foreground">
              Creates the balance row at zero. Until it exists a top-up has nothing to land on — the
              gateway leaves it pending rather than crediting it.
            </p>
          </>
        )}
        {error && <p className="text-sm text-destructive">{error}</p>}
      </div>
    );
  }

  return (
    <div className="space-y-2 border-t border-border/40 pt-3">
      {open === "topUp" && funding === "transfer" ? (
        <TransferForm
          direction="down"
          currency={currency}
          busy={busy}
          error={error}
          onCancel={() => { setOpen(null); setError(""); }}
          onSubmit={async (amount) => {
            if (await transfer("down", amount)) {
              setOpen(null);
            }
          }}
        />
      ) : open === "takeBack" ? (
        <TransferForm
          direction="up"
          currency={currency}
          busy={busy}
          error={error}
          onCancel={() => { setOpen(null); setError(""); }}
          onSubmit={async (amount) => {
            if (await transfer("up", amount)) {
              setOpen(null);
            }
          }}
        />
      ) : open === "topUp" ? (
        <TopUpForm
          currency={currency}
          busy={busy}
          error={error}
          onCancel={() => { setOpen(null); setError(""); }}
          onSubmit={async (amount, ref, note) => {
            if (await post({ action: "topUp", amount, ref, note })) {
              setOpen(null);
              setNotice(
                `Recorded ${amount}${currency ? ` ${currency}` : ""}. The gateway credits it on its `
                  + "next poll, within thirty seconds."
              );
            }
          }}
        />
      ) : open === "billing" ? (
        <BillingForm
          mode={billingMode}
          mayGrantPostpaid={mayGrantPostpaid}
          headroom={postpaidHeadroom}
          creditLimit={creditLimit}
          currency={currency}
          busy={busy}
          error={error}
          onCancel={() => { setOpen(null); setError(""); }}
          onSubmit={async (mode, limit) => {
            if (await post({ action: "billing", mode, creditLimit: limit })) {
              setOpen(null);
            }
          }}
        />
      ) : (
        <div className="flex flex-wrap items-center gap-2">
          {billingMode === "POSTPAID" ? (
            <span className="text-xs text-muted-foreground">
              Postpaid — nothing is debited. Limit{" "}
              <span className="font-mono">{formatAmount(creditLimit)}{currency ? ` ${currency}` : ""}</span>
              , invoiced in arrears.
            </span>
          ) : (
            <Button size="sm" className="h-7" onClick={() => setOpen("topUp")}>
              {funding === "transfer" ? "Send funds" : "Add credit"}
            </Button>
          )}
          {/*the reverse, and only a reseller has it. An operator's RECHARGE has no counterpart here
             on purpose -- taking credit BACK from a customer is a different conversation from
             giving it, and this panel deliberately has no debit. A transfer up is not that: it is
             the reseller's own money returning, which is why it is safe to offer*/}
          {funding === "transfer" && (
            <Button size="sm" variant="ghost" className="h-7" onClick={() => setOpen("takeBack")}>
              Take funds back
            </Button>
          )}
          <Button size="sm" variant="ghost" className="h-7" onClick={() => setOpen("billing")}>
            {billingMode === "POSTPAID"
              ? "Change limit or go prepaid"
              : mayGrantPostpaid
                ? "Switch to postpaid"
                : "Billing terms"}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-7"
            disabled={busy}
            onClick={() => void post({ action: enabled ? "disable" : "enable" })}
          >
            {enabled ? "Switch credit off" : "Switch credit on"}
          </Button>
          {!enabled && (
            <span className="text-xs text-destructive">
              Credit is off — this account stops sending once the block it already holds runs out.
            </span>
          )}
        </div>
      )}
      {notice && <p className="text-xs text-amber-600 dark:text-amber-400">{notice}</p>}
      {error && <p className="text-sm text-destructive">{error}</p>}
    </div>
  );
}

/**
 * Opening the balance row.
 *
 * <p><strong>The currency is not a question when anything can answer it.</strong> FireFlo has one
 * currency and never converts: `smsg.rates.currency` is stamped on every rated message, and the
 * per-rule column is an override written as NULL on purpose so the global keeps applying. A second
 * code typed here would not be a second currency, it would be a balance denominated in something no
 * price is ever expressed in — and nothing reconciles the two, so it reads correct forever.
 *
 * <p>Two sources answer, in order (`chooseCurrency`, `lib/balance-types.ts`): the gateway, then the
 * **parent account's** own balance. The second is what makes a child under a reseller inherit rather
 * than be asked — a reseller's customer has no way to know the platform's currency, and until this
 * existed the file-mode deployment asked them anyway.
 *
 * <p><strong>Only the operator panel asks when neither answers.</strong> `askable` is false in the
 * customer portal, where the honest response is to name the operator: `openBalance` is
 * `ON CONFLICT DO NOTHING`, so a wrong code cannot be undone by opening the account again.
 */
function OpenForm({
  inherited,
  askable,
  busy,
  error,
  onCancel,
  onSubmit,
}: {
  inherited: InheritedCurrency;
  /** Whether this surface may fall back to asking. True on `/cp`, false in the portal. */
  askable: boolean;
  busy: boolean;
  error: string;
  onCancel: () => void;
  /** The typed code, or "" when it was inherited and the server will resolve it. */
  onSubmit: (typed: string) => void | Promise<void>;
}) {
  const [code, setCode] = useState("");
  const invalid = code.trim() ? validateCurrency(code) : null;
  const fixed = Boolean(inherited.code);

  return (
    <form
      className="space-y-2"
      onSubmit={(e) => {
        e.preventDefault();
        if (fixed) {
          //nothing typed and nothing sent: the server resolves the same chain this form displayed
          void onSubmit("");
          return;
        }
        if (!invalid && code.trim()) {
          void onSubmit(code.trim().toUpperCase());
        }
      }}
    >
      {fixed ? (
        <p className="text-xs text-muted-foreground">
          Currency <span className="font-mono uppercase text-foreground">{inherited.code}</span>,{" "}
          {inherited.from === "gateway" ? (
            <>
              from the gateway&apos;s <code className="text-xs">smsg.rates.currency</code>.
            </>
          ) : (
            //said as inheritance rather than as a platform fact, because that is what it is: the
            //code already in use one level up, which is weaker evidence than the gateway's and
            //should not be presented as equal to it
            <>inherited from the account above this one.</>
          )}{" "}
          One currency per platform — FireFlo never converts, so a balance in anything else could
          never be spent against a price.
        </p>
      ) : askable ? (
        <>
          <div className="w-32">
            <Label htmlFor="credit-currency" className="mb-1 block text-xs">Currency</Label>
            <Input id="credit-currency" value={code} onChange={(e) => setCode(e.target.value)}
              className="h-7 font-mono uppercase" maxLength={3} />
          </div>
          <p className="text-xs text-muted-foreground">
            Neither the gateway&apos;s <code className="text-xs">smsg.rates.currency</code> nor a
            parent account could answer, so this cannot be filled in. Use the same code everywhere:
            there is one currency per platform and nothing converts between two.
          </p>
        </>
      ) : (
        <p className="text-xs text-amber-600 dark:text-amber-400">
          This platform has not published a currency that we can read, and there is none on the
          account above this one to inherit. Ask your account manager to set one — a balance opened
          in the wrong currency cannot be corrected afterwards.
        </p>
      )}
      {invalid && <p className="text-sm text-destructive">{invalid}</p>}
      {error && <p className="text-sm text-destructive">{error}</p>}
      <div className="flex gap-2">
        {(fixed || askable) && (
          <Button
            type="submit"
            size="sm"
            className="h-7"
            disabled={busy || (!fixed && (Boolean(invalid) || !code.trim()))}
          >
            {busy ? "Opening…" : "Open"}
          </Button>
        )}
        <Button type="button" size="sm" variant="ghost" className="h-7" onClick={onCancel}>
          {fixed || askable ? "Cancel" : "Close"}
        </Button>
      </div>
    </form>
  );
}

/**
 * Moving a reseller's own balance to or from one of its accounts.
 *
 * <p>Not a top-up. `TopUpForm` above records a `RECHARGE`, which credits an account with nothing
 * debited anywhere; this writes a `TRANSFER`, which moves money that already exists. That is why it
 * asks for no reference: the operator's reference is their receipt from the billing system, and here
 * there is no outside transaction to point at — the counterparty is the reseller itself.
 *
 * <h2>What the gateway guarantees, stated because the form claims it</h2>
 *
 * <p>The panel writes an <strong>unapplied</strong> ledger row and stops. `account_balance` has
 * exactly one writer, and `BalanceService.applyPendingTransfers` does all three of these inside one
 * transaction, per row:
 *
 * <ul>
 *   <li>It <strong>claims</strong> the entry before touching any balance, so a transfer cannot be
 *       applied twice however many times the poll runs.</li>
 *   <li>It <strong>debits the payer with the sufficiency check inside the statement</strong>
 *       (`balance >= ?`). Zero rows means not enough, nothing moved, and the entry stays pending —
 *       so a transfer authorised against a balance the account's own traffic has since spent does
 *       not overdraw it.</li>
 *   <li>If the <strong>credit half lands nowhere</strong> — no balance row on the payee, or credit
 *       switched off — it writes a compensating credit back to the payer and unmarks the entry. The
 *       debit is never left standing.</li>
 * </ul>
 *
 * <p>So the honest word on this form is <strong>queued</strong>, and the honest promise is that it
 * either happens completely or not at all. Neither is a claim about this component; both are
 * properties of the statement that moves the money.
 */
function TransferForm({
  direction,
  currency,
  busy,
  error,
  onCancel,
  onSubmit,
}: {
  /** `down` funds the account from the caller's balance; `up` returns it. */
  direction: "down" | "up";
  currency: string | null;
  busy: boolean;
  error: string;
  onCancel: () => void;
  onSubmit: (amount: string) => void | Promise<void>;
}) {
  const [amount, setAmount] = useState("");
  const scaled = amount.trim() ? parseAmount(amount) : null;
  const invalid = amount.trim() && (scaled === null || scaled <= 0)
    ? "Enter an amount greater than zero, with at most four decimal places."
    : null;
  const down = direction === "down";

  return (
    <form
      className="space-y-2"
      onSubmit={(e) => {
        e.preventDefault();
        if (!invalid && amount.trim()) {
          void onSubmit(amount.trim());
        }
      }}
    >
      <div className="w-40">
        <Label htmlFor="xfer-amount" className="mb-1 block text-xs">
          {down ? "Send" : "Take back"}{currency ? ` (${currency})` : ""}
        </Label>
        <Input id="xfer-amount" value={amount} onChange={(e) => setAmount(e.target.value)}
          className="h-7 font-mono" inputMode="decimal" placeholder="100.0000" />
      </div>
      <p className="text-xs leading-relaxed text-muted-foreground">
        {down
          ? "Moves it from your own balance to theirs. "
          : "Moves it from their balance back to yours. "}
        The gateway applies it on its next poll, within thirty seconds — it is not moved yet. If{" "}
        {down ? "you do" : "they do"} not have enough by then it is refused and stays pending, and a
        credit that cannot land is put back. It never half-happens.
      </p>
      {invalid && <p className="text-sm text-destructive">{invalid}</p>}
      {error && <p className="text-sm text-destructive">{error}</p>}
      <div className="flex gap-2">
        <Button type="submit" size="sm" className="h-7"
          disabled={busy || Boolean(invalid) || !amount.trim()}>
          {busy ? "Queueing…" : down ? "Send funds" : "Take back"}
        </Button>
        <Button type="button" size="sm" variant="ghost" className="h-7" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  );
}

function TopUpForm({
  currency,
  busy,
  error,
  onCancel,
  onSubmit,
}: {
  currency: string | null;
  busy: boolean;
  error: string;
  onCancel: () => void;
  onSubmit: (amount: string, ref: string, note: string) => void | Promise<void>;
}) {
  const [amount, setAmount] = useState("");
  const [ref, setRef] = useState("");
  const [note, setNote] = useState("");

  const invalid = amount.trim() || ref.trim() ? validateTopUp({ amount, ref }) : null;
  const scaled = parseAmount(amount);

  return (
    <form
      className="space-y-2"
      //no onSubmit handler: the confirm below is the submit. A form that could be sent by pressing
      //Enter in a field would bypass it, which for the one irreversible write in this panel is the
      //wrong way round
      onSubmit={(e) => e.preventDefault()}
    >
      <div className="flex flex-wrap gap-2">
        <div className="w-32">
          <Label htmlFor="credit-amount" className="mb-1 block text-xs">
            Amount{currency ? ` (${currency})` : ""}
          </Label>
          <Input id="credit-amount" value={amount} onChange={(e) => setAmount(e.target.value)}
            className="h-7 font-mono" inputMode="decimal" placeholder="250" />
        </div>
        <div className="w-40">
          <Label htmlFor="credit-ref" className="mb-1 block text-xs">Reference</Label>
          <Input id="credit-ref" value={ref} onChange={(e) => setRef(e.target.value)}
            className="h-7 font-mono" placeholder="receipt-1042" />
        </div>
        <div className="min-w-40 flex-1">
          <Label htmlFor="credit-note" className="mb-1 block text-xs">Note</Label>
          <Input id="credit-note" value={note} onChange={(e) => setNote(e.target.value)}
            className="h-7" placeholder="optional" />
        </div>
      </div>

      {scaled !== null && scaled > 0 && (
        <p className="text-xs text-muted-foreground">
          Recorded exactly as <span className="font-mono">{formatAmount(scaled)}</span> — stored as{" "}
          <span className="font-mono">{scaled}</span> at four decimal places.
        </p>
      )}
      {invalid && <p className="text-sm text-destructive">{invalid}</p>}
      {error && <p className="text-sm text-destructive">{error}</p>}

      <p className="text-xs text-muted-foreground">
        This writes a recharge entry. The gateway applies it on its next configuration poll, within
        thirty seconds — the balance above will not move immediately.
      </p>

      <div className="flex flex-wrap items-center gap-2">
        {/* the only irreversible write in this panel: there is no 'remove credit', and undoing one
            needs a negative ADJUST that nobody has built. It was guarded by window.confirm, which a
            browser may suppress -- and a suppressed dialog means the click silently does nothing,
            so the operator presses it again */}
        <DangerAction
          label="Add credit"
          confirmLabel={`Add ${amount.trim() || "credit"}${currency ? ` ${currency}` : ""}`}
          tone="caution"
          busy={busy}
          disabled={Boolean(invalid) || !amount.trim()}
          consequence={
            `${amount.trim()}${currency ? ` ${currency}` : ""} goes onto this account against `
            + `'${ref.trim()}'. This cannot be undone from the panel.`
          }
          onConfirm={() => void onSubmit(amount.trim(), ref.trim(), note.trim())}
        />
        <Button type="button" size="sm" variant="ghost" className="h-7" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  );
}

/**
 * Choosing between prepaid and postpaid, and setting the limit that goes with it.
 *
 * <p>One form for both directions because they are one database statement: the constraint requires a
 * prepaid row to carry a zero limit, so the mode and the limit cannot be saved separately.
 *
 * <p>The zero refusal is in `validateBillingChange` rather than here, so the route enforces the same
 * rule when the request does not come from this form.
 */
function BillingForm({
  mode,
  mayGrantPostpaid,
  headroom,
  creditLimit,
  currency,
  busy,
  error,
  onCancel,
  onSubmit,
}: {
  mode: BillingMode;
  /** False for a prepaid reseller — see `CreditActions`. */
  mayGrantPostpaid: boolean;
  /** The ceiling on this account's limit, or null for none. */
  headroom: number | null;
  creditLimit: number;
  currency: string | null;
  busy: boolean;
  error: string;
  onCancel: () => void;
  onSubmit: (mode: BillingMode, limit: string) => void | Promise<void>;
}) {
  const [chosen, setChosen] = useState<BillingMode>(mode);
  const [limit, setLimit] = useState(creditLimit ? formatAmount(creditLimit) : "");
  const [local, setLocal] = useState("");

  return (
    <form
      className="space-y-2"
      onSubmit={(e) => {
        e.preventDefault();
        const invalid = validateBillingChange(chosen, limit);
        //the ceiling is checked here as well as on the route, so the number can be corrected
        //without a round trip. The route's check is the one that holds -- another child's limit may
        //have moved since this page loaded
        const over = !invalid && chosen === "POSTPAID" && headroom !== null
          && (parseAmount(limit) ?? 0) > headroom;
        setLocal(
          invalid
            ?? (over
              ? `That is more than you have left to give — ${formatAmount(headroom)} at most.`
              : "")
        );
        if (!invalid && !over) {
          void onSubmit(chosen, limit);
        }
      }}
    >
      <div className="flex flex-wrap items-center gap-3">
        <Label className="flex items-center gap-1.5 text-sm font-normal">
          <input
            type="radio"
            name="billing-mode"
            checked={chosen === "PREPAID"}
            onChange={() => setChosen("PREPAID")}
          />
          Prepaid — spends a balance
        </Label>
        {/* an account ALREADY on postpaid keeps the option even when it is not this caller's to
            grant, so they can still see which mode it is in and move it back to prepaid. Taking the
            radio away there would leave the form unable to describe its own state */}
        {(mayGrantPostpaid || mode === "POSTPAID") && (
          <Label className="flex items-center gap-1.5 text-sm font-normal">
            <input
              type="radio"
              name="billing-mode"
              checked={chosen === "POSTPAID"}
              disabled={!mayGrantPostpaid}
              onChange={() => setChosen("POSTPAID")}
            />
            Postpaid — billed in arrears
          </Label>
        )}
      </div>

      {!mayGrantPostpaid && (
        <p className="text-xs leading-relaxed text-muted-foreground">
          Your own account is on prepaid terms, so postpaid is not yours to give. A postpaid customer
          sends against a limit rather than against funds, and somebody carries it until it is
          invoiced. Ask your account manager.
        </p>
      )}

      {chosen === "POSTPAID" && (
        <div className="space-y-1">
          <Label htmlFor="credit-limit" className="text-sm">
            Credit limit{currency ? ` (${currency})` : ""}
          </Label>
          <Input
            id="credit-limit"
            className="h-7 max-w-40 font-mono text-sm"
            value={limit}
            onChange={(e) => setLimit(e.target.value)}
            placeholder="0.0000"
            autoComplete="off"
          />
          <p className="text-xs text-muted-foreground">
            How much unbilled usage this account may run up before it is refused — the same refusal
            a prepaid account gets when it runs out. <strong>Zero is not unlimited</strong>: it means
            no credit, so it is not accepted here.
            {headroom !== null && (
              <>
                {" "}You have <strong>{formatAmount(headroom)}</strong> of your own limit left to
                give, after what is already committed to your other accounts.
              </>
            )}
          </p>
        </div>
      )}

      {chosen !== mode && (
        <p className="text-xs text-amber-600 dark:text-amber-400">
          {chosen === "POSTPAID"
            ? "Switching to postpaid stops this account spending its balance. Anything already "
              + "reserved stays reserved until an operator releases it."
            : "Switching back to prepaid clears the limit and the account spends its balance "
              + "again. Usage since the last bill is still owed."}
        </p>
      )}

      <div className="flex items-center gap-2">
        <Button type="submit" size="sm" className="h-7" disabled={busy}>Save</Button>
        <Button type="button" size="sm" variant="ghost" className="h-7" onClick={onCancel}>
          Cancel
        </Button>
      </div>
      {(local || error) && <p className="text-sm text-destructive">{local || error}</p>}
    </form>
  );
}
