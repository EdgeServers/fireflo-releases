"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { Plus, Search, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Dialog } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { ErrorCard } from "./FormNotices";
import { TlvSourceChip } from "./TlvTokenInput";
import { useTlvDefinitions, type TlvUsage } from "./useTlvDefinitions";
import {
  CONVENTION_TAGS,
  SPEC_TAGS,
  type TlvDefinition,
  resolveTlv,
  validateTlvDefinition,
} from "@/lib/tlv-catalogue";

const hex = (tag: number) => `0x${tag.toString(16).toUpperCase().padStart(4, "0")}`;

/**
 * Every TLV tag this panel can name, and every one this deployment actually declares.
 *
 * <p><strong>Leads with conflicts, not with the glossary.</strong> A list of 66 standard tags is
 * reference material nobody reads twice; two vendors calling `0x1403` different things is a live
 * misconfiguration that nothing else in either system reports. The glossary is underneath.
 */
export function TlvReferenceClient() {
  const { definitions, suggested, usage, error, loading, busy, save, setSuggested, remove } =
    useTlvDefinitions();
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<TlvDefinition | "new" | null>(null);

  const conflicts = useMemo(() => findConflicts(usage), [usage]);
  const undefined_ = useMemo(() => findUndefined(usage, definitions), [usage, definitions]);

  const rows = useMemo(() => {
    const tags = new Set<number>([
      ...SPEC_TAGS.map((d) => d.tag),
      ...CONVENTION_TAGS.map((d) => d.tag),
      ...definitions.map((d) => d.tag),
      ...(usage ?? []).map((u) => u.tag),
    ]);
    const q = query.trim().toLowerCase();
    return [...tags]
      .sort((a, b) => a - b)
      .map((tag) => ({ tag, resolved: resolveTlv(tag, definitions), uses: (usage ?? []).filter((u) => u.tag === tag) }))
      .filter(({ tag, resolved }) =>
        !q
        || hex(tag).toLowerCase().includes(q)
        || String(tag).includes(q)
        || (resolved?.name ?? "").toLowerCase().includes(q)
        || (resolved?.label ?? "").toLowerCase().includes(q)
      );
  }, [definitions, usage, query]);

  //a tag with no decision is offered, so the default is the whole catalogue rather than none of it
  const isSuggested = (tag: number) => suggested[tag] ?? true;
  const shownTags = rows.map((r) => r.tag);
  const suggestedCount = [
    ...new Set([...SPEC_TAGS, ...CONVENTION_TAGS].map((d) => d.tag).concat(definitions.map((d) => d.tag))),
  ].filter(isSuggested).length;
  const totalCount = new Set(
    [...SPEC_TAGS, ...CONVENTION_TAGS].map((d) => d.tag).concat(definitions.map((d) => d.tag))
  ).size;

  return (
    <>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <p className="max-w-2xl text-base text-muted-foreground">
          A TLV is declared as <code>name_tag</code> and only the tag reaches the wire — the name is
          for people. The SMPP standard and the DLT convention are built in; anything else this
          gateway uses can be named here.
        </p>
        <Button onClick={() => setEditing("new")} className="shrink-0">
          <Plus className="mr-1.5 h-4 w-4" />
          Name a tag
        </Button>
      </div>

      <ErrorCard error={error} />

      {!!conflicts.length && (
        <Card className="border-amber-500/40">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-medium">
              {conflicts.length === 1 ? "One tag is" : `${conflicts.length} tags are`} declared under
              more than one name
            </CardTitle>
            <CardDescription>
              Only the number reaches the wire, so this is not broken by itself — but the same
              parameter meaning two things to two vendors usually is. Worth confirming which is right.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {conflicts.map(({ tag, uses }) => (
              <div key={tag} className="flex flex-wrap items-baseline gap-2">
                <span className="font-mono">{hex(tag)}</span>
                {uses.map((u) => (
                  <span key={`${u.where}-${u.setting}-${u.name}`} className="text-muted-foreground">
                    <span className="font-mono text-foreground">{u.name}</span> on {u.where}
                    <span className="text-muted-foreground"> ({u.setting})</span>
                  </span>
                ))}
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {!!undefined_.length && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-medium">
              {undefined_.length} tag{undefined_.length === 1 ? "" : "s"} in use with no definition
            </CardTitle>
            <CardDescription>
              Perfectly legal — the gateway takes any tag. Naming one only helps whoever reads this
              next.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2 text-sm">
            {undefined_.map(({ tag, uses }) => (
              <button
                key={tag}
                type="button"
                onClick={() => setEditing({ tag, name: uses[0]?.name ?? "" })}
                className="rounded-md border border-border px-2 py-1 hover:bg-accent"
              >
                <span className="font-mono">{hex(tag)}</span>{" "}
                <span className="text-muted-foreground">
                  as {uses[0]?.name} on {uses[0]?.where} — add a name
                </span>
              </button>
            ))}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex flex-wrap items-center justify-between gap-3 text-base font-medium">
            <span className="flex flex-wrap items-baseline gap-2">
              All tags
              <span className="text-xs font-normal text-muted-foreground">
                {suggestedCount} of {totalCount} suggested
              </span>
            </span>
            <span className="relative">
              <Search className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="tag or name"
                className="h-8 w-52 pl-7 text-sm font-normal"
                aria-label="Search tags"
              />
            </span>
          </CardTitle>
          {/* scoped to what the search matches, not to the catalogue: search "broadcast", switch off
              all eleven at once. The count is in the label because two buttons that look identical
              and act on eleven rows or on sixty-six is a difference that has to be readable before
              the click rather than after it */}
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <Button variant="outline" size="sm" className="h-7 text-sm"
              disabled={busy || !shownTags.length}
              onClick={() => setSuggested(shownTags, true)}>
              Suggest {query.trim() ? `these ${shownTags.length}` : "all"}
            </Button>
            <Button variant="outline" size="sm" className="h-7 text-sm"
              disabled={busy || !shownTags.length}
              onClick={() => setSuggested(shownTags, false)}>
              Stop suggesting {query.trim() ? `these ${shownTags.length}` : "all"}
            </Button>
            {query.trim() && (
              <span className="text-xs text-muted-foreground">
                the {shownTags.length} matching &ldquo;{query.trim()}&rdquo;, not the whole catalogue
              </span>
            )}
          </div>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          {loading ? (
            <p className="text-base text-muted-foreground">Loading…</p>
          ) : (
            <table className="striped w-full text-sm">
              <thead className="text-muted-foreground">
                <tr className="text-left">
                  <th className="py-1.5 pr-4 font-medium">Suggested</th>
                  <th className="py-1.5 pr-4 font-medium">Tag</th>
                  <th className="py-1.5 pr-4 font-medium">Name</th>
                  <th className="py-1.5 pr-4 font-medium">Meaning</th>
                  <th className="py-1.5 pr-4 font-medium">Used by</th>
                  <th className="py-1.5 font-medium" />
                </tr>
              </thead>
              <tbody>
                {rows.map(({ tag, resolved, uses }) => {
                  const own = definitions.find((d) => d.tag === tag);
                  return (
                    <tr key={tag} className="border-t border-border align-top">
                      <td className="py-1.5 pr-4">
                        <Checkbox
                          checked={isSuggested(tag)}
                          disabled={busy}
                          onChange={(e) => setSuggested([tag], e.target.checked)}
                          aria-label={`Suggest ${hex(tag)}`}
                        />
                      </td>
                      <td className="py-1.5 pr-4 font-mono whitespace-nowrap">
                        {hex(tag)}
                        <span className="block text-muted-foreground">{tag}</span>
                      </td>
                      <td className="py-1.5 pr-4 font-mono">
                        {resolved?.name ?? <span className="text-muted-foreground">—</span>}
                      </td>
                      <td className="py-1.5 pr-4">
                        {resolved ? (
                          <>
                            <span className="flex flex-wrap items-center gap-1.5">
                              {resolved.label}
                              <TlvSourceChip provenance={resolved.provenance} />
                            </span>
                            {resolved.shadows && (
                              <span className="block text-amber-600 dark:text-amber-400">
                                overrides{" "}
                                {resolved.shadows.provenance === "spec" ? "the SMPP spec" : "convention"}:{" "}
                                <code>{resolved.shadows.name}</code>
                              </span>
                            )}
                            {resolved.note && (
                              <span className="block text-muted-foreground">{resolved.note}</span>
                            )}
                          </>
                        ) : (
                          <span className="text-muted-foreground">Not named</span>
                        )}
                      </td>
                      <td className="py-1.5 pr-4 text-muted-foreground">
                        {uses.length
                          ? [...new Set(uses.map((u) => u.where))].join(", ")
                          : <span className="text-muted-foreground">—</span>}
                      </td>
                      <td className="py-1.5 whitespace-nowrap">
                        <Button variant="ghost" size="sm" className="h-6 px-2"
                          onClick={() => setEditing(own ?? { tag, name: resolved?.name ?? "" })}>
                          {own ? "Edit name" : "Add name"}
                        </Button>
                        {own && (
                          <Button variant="ghost" size="sm" className="h-6 px-2 text-muted-foreground"
                            disabled={busy} onClick={() => remove(tag)} aria-label={`Remove ${hex(tag)}`}>
                            <X className="h-3.5 w-3.5" />
                          </Button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>

      {/* a modal rather than a panel beside the table: naming a tag is a short, complete task, and
          the alternative put the editor either off screen above a long table or in a column that
          was empty most of the time */}
      <DefinitionForm
        //keyed by tag so the fields re-seed. Without it the useState initialisers never re-run and
        //an editor reopened on another tag keeps the first one's values under the second's name
        key={editing === "new" ? "new" : (editing?.tag ?? "closed")}
        editing={editing}
        busy={busy}
        onCancel={() => setEditing(null)}
        onSave={async (input) => {
          if (await save(input)) {
            setEditing(null);
          }
        }}
      />

      <p className="text-base text-muted-foreground">
        <strong className="text-foreground">Suggesting is about the dropdown, not the gateway.</strong>{" "}
        A tag you stop suggesting leaves the type-ahead on vendors, servers and accounts — and stays
        typeable into every one of those fields, still resolving to its name, still saving.
        Nothing here changes what the gateway sends. Names never reach the wire, the gateway accepts
        any tag from <code>0x0000</code> to <code>0xFFFF</code>, and removing a definition leaves
        every setting that uses the tag working exactly as before.
      </p>
    </>
  );
}

/**
 * The editor, in a modal.
 *
 * <p>Takes the whole `editing` value rather than an `initial` plus an `open`, so there is one source
 * of truth for whether it is showing and for what. Null means closed.
 *
 * <p>Submits as a form so Enter saves, which is the difference between a dialog and a box with
 * buttons in it — four short fields is exactly the case where nobody reaches for the mouse.
 */
function DefinitionForm({
  editing,
  busy,
  onCancel,
  onSave,
}: {
  editing: TlvDefinition | "new" | null;
  busy: boolean;
  onCancel: () => void;
  onSave: (input: { tag: number; name: string; label?: string; description?: string }) => void;
}) {
  const initial = editing === "new" || editing === null ? null : editing;
  const [tag, setTag] = useState(initial ? hex(initial.tag) : "");
  const [name, setName] = useState(initial?.name ?? "");
  const [label, setLabel] = useState(initial?.label ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  const firstField = useRef<HTMLInputElement>(null);

  //the field you are about to type in: the tag when naming a new one, the name when it is known.
  //Dialog focuses its own panel, which is the right fallback but not the useful one
  useEffect(() => {
    firstField.current?.focus();
  }, []);

  const parsed = tag.trim().toLowerCase().startsWith("0x")
    ? Number.parseInt(tag.trim().slice(2), 16)
    : Number.parseInt(tag.trim(), 10);
  const invalid = validateTlvDefinition({ tag: parsed, name });

  return (
    <Dialog
      open={editing !== null}
      onClose={onCancel}
      title={initial ? `Name ${hex(initial.tag)}` : "Name a tag"}
      description={
        "Gives a tag a name and a meaning for this panel to show. It changes nothing the gateway "
        + "sends — names never reach the wire — and it is only needed for tags the SMPP spec and the "
        + "DLT convention do not already cover."
      }
    >
      <form
        className="space-y-4"
        onSubmit={(e) => {
          e.preventDefault();
          if (!invalid && !busy) {
            onSave({ tag: parsed, name: name.trim(), label, description });
          }
        }}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Tag" htmlFor="tlv-tag" hint="0x1403, or 5123 in decimal.">
            <Input id="tlv-tag" value={tag} onChange={(e) => setTag(e.target.value)}
              ref={initial ? undefined : firstField}
              placeholder="0x1403" className="font-mono" disabled={!!initial} />
          </Field>
          <Field label="Name" htmlFor="tlv-name"
            hint="Prefilled into a token, so no comma, equals sign or space.">
            <Input id="tlv-name" value={name} onChange={(e) => setName(e.target.value)}
              ref={initial ? firstField : undefined}
              placeholder="cref" className="font-mono" />
          </Field>
          <Field label="Meaning" htmlFor="tlv-label" hint="One line, for a list."
            className="sm:col-span-2">
            <Input id="tlv-label" value={label} onChange={(e) => setLabel(e.target.value)}
              placeholder="Customer reference" />
          </Field>
          <Field label="Notes" htmlFor="tlv-desc" className="sm:col-span-2"
            hint="Anything the next person needs — what the vendor expects, how it is encoded.">
            <Input id="tlv-desc" value={description} onChange={(e) => setDescription(e.target.value)} />
          </Field>
        </div>

        {invalid && name.trim() !== "" && <p className="text-xs text-destructive">{invalid}</p>}

        <div className="flex gap-2">
          <Button type="submit" disabled={busy || !!invalid}>
            {busy ? "Saving…" : "Save"}
          </Button>
          <Button type="button" variant="outline" onClick={onCancel} disabled={busy}>Cancel</Button>
        </div>
      </form>
    </Dialog>
  );
}

/** Tags declared under two or more different names. */
function findConflicts(usage: TlvUsage[] | null): { tag: number; uses: TlvUsage[] }[] {
  if (!usage) {
    return [];
  }
  const byTag = new Map<number, TlvUsage[]>();
  for (const u of usage) {
    byTag.set(u.tag, [...(byTag.get(u.tag) ?? []), u]);
  }
  return [...byTag]
    .filter(([, uses]) => new Set(uses.map((u) => u.name)).size > 1)
    .map(([tag, uses]) => ({ tag, uses }))
    .sort((a, b) => a.tag - b.tag);
}

/** Tags in use that no layer names. */
function findUndefined(
  usage: TlvUsage[] | null,
  definitions: readonly TlvDefinition[]
): { tag: number; uses: TlvUsage[] }[] {
  if (!usage) {
    return [];
  }
  const byTag = new Map<number, TlvUsage[]>();
  for (const u of usage) {
    byTag.set(u.tag, [...(byTag.get(u.tag) ?? []), u]);
  }
  return [...byTag]
    .filter(([tag]) => resolveTlv(tag, definitions) == null)
    .map(([tag, uses]) => ({ tag, uses }))
    .sort((a, b) => a.tag - b.tag);
}
