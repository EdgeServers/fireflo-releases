"use client";
import { useState } from "react";
import { ArrowRight, Plus, Power, PowerOff } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle,
} from "@/components/ui/card";
import { DangerAction } from "./DangerAction";
import { DefaultRouting } from "./DefaultRouting";
import { ErrorCard } from "./FormNotices";
import { GatewayIgnores } from "./GatewayIgnores";
import { RouteTableForm } from "./RouteTableForm";
import { useHealth } from "./useHealth";
import { useRouting } from "./useRouting";
import { useRuntimeMetrics } from "./useRuntimeMetrics";
import { useWorkers } from "./useWorkers";
import { readsRoutingFromDatabase } from "@/lib/health-types";
import {
  RULE_DIRECTION_LABEL,
  TARGET_FUNCTION_MEANING,
  ruleDirection,
  type RouteRule,
  type RouteTable,
  routeTableWarnings,
  targetKind,
} from "@/lib/routing-types";
import type { RuntimeSnapshot } from "@/lib/runtime-metrics";

/**
 * Reads one rule's traffic counter out of the metrics snapshot, using the exact key
 * {@code AbstractRoutingManager.recordRuleMatch} builds on the gateway: the rule's own label when
 * it has one, else {@code table:seq} with {@code seq} 1-based -- the same "Order" column every rule
 * row already shows.
 *
 * @returns null when there is no snapshot yet, or the rule has never matched -- both render as
 *     nothing rather than "0", so a metrics fetch that has not landed does not look like dead traffic
 */
function ruleMatchCount(
  metrics: RuntimeSnapshot | null,
  tableName: string,
  rule: RouteRule,
  index: number
): number | null {
  if (!metrics) {
    return null;
  }
  const key = rule.label ?? `${tableName}:${index + 1}`;
  return metrics.routingRuleMatches[tableName]?.[key] ?? null;
}

/**
 * Where messages go: the routing tables, and the rules that chain them together.
 *
 * <p>The last configuration domain the panel could not edit. `app_route_table` and `app_route_rule`
 * have been readable since V1.4.0 and were filled by `fireflo import routing`, but with no editor
 * the only safe source was the file. This page is what made `FIREFLO_CONFIG_SOURCE=db` a reasonable
 * thing to set rather than a one-way door.
 *
 * <p><strong>Tables are listed rather than nested.</strong> Routing is a graph — `default` chains
 * into `MESSAGE`, which chains into `cheapest` — and drawing it as a tree would either repeat
 * subtrees or pick an arbitrary root. A flat list with each rule's target labelled as table or
 * worker lets the reader follow the chain without the page claiming a shape the data does not have.
 */
/**
 * What deleting a routing table costs.
 *
 * <p>Names the tables that chain INTO it as well as the rules inside it. A table deleted while other
 * tables still target it leaves those rules pointing at nothing, which the routing engine treats as
 * an unroutable message rather than an error anybody sees.
 */
function describeTableRemoval(table: RouteTable, tables: RouteTable[]): string {
  const into = tables
    .flatMap((t) => t.rules.map((r) => ({ from: t.name, target: r.target })))
    .filter((r) => r.target === table.name && r.from !== table.name);
  const chained = [...new Set(into.map((r) => r.from))];

  return `Its ${table.rules.length} rule(s) go with it.`
    + (chained.length
      ? ` ${into.length} rule(s) in ${chained.join(", ")} chain into it and will be left pointing at`
        + " nothing."
      : "");
}

export function RoutingClient() {
  const { tables, error, loading, busy, load, save, remove, toggleRule } = useRouting();
  //a live counter since the gateway last restarted, not a durable history -- see the "since
  //restart" label on each count. Polled independently of the routing tables themselves, which come
  //from app_route_table and change on an edit, not on traffic
  const { snapshot: metrics } = useRuntimeMetrics();
  //both kinds: a vendor is an outbound target, a listener is where a delivery receipt goes back
  const { workers: clients } = useWorkers("smppclient");
  const { workers: servers } = useWorkers("smppserver");
  const workers = [...clients, ...servers];
  const { health } = useHealth();
  const writable = readsRoutingFromDatabase(health);
  const [editing, setEditing] = useState<RouteTable | "new" | null>(null);
  const [removeError, setRemoveError] = useState("");

  const tableNames = tables.map((t) => t.name);

  //"Start rule" hands the operator a table already carrying the draft, unsaved -- the same edit
  //flow as clicking Edit, just with one more row already in the form for them to point somewhere
  function startMoRule(draft: RouteRule) {
    const target = tables.find((t) => t.name === "default");
    if (!target) {
      setRemoveError("There is no 'default' routing table to add the rule to. Create one first.");
      return;
    }
    setEditing({ ...target, rules: [...target.rules, draft] });
  }

  if (editing !== null) {
    return (
      <div className="space-y-6">
        <ErrorCard error={error} />
        <RouteTableForm
          key={editing === "new" ? "new" : editing.name}
          initial={editing === "new" ? null : editing}
          tableNames={tableNames}
          workers={workers}
          onSave={async (input) => {
            const failure = await save(input);
            if (!failure) {
              setEditing(null);
            }
            return failure;
          }}
          onCancel={() => setEditing(null)}
        />
      </div>
    );
  }

  //no grid here any more. The page owns the two columns, because the right one now carries the
  //vendor groups as well as the delivery check -- nesting a second grid inside this one produced
  //three columns at xl and squeezed the rule conditions into a rail nobody could read
  return (
    <div className="space-y-6">
      <ErrorCard error={error || removeError} />

      <GatewayIgnores domain="routing" />

      <DefaultRouting
        tables={tables}
        servers={servers}
        vendors={clients}
        writable={writable}
        onApplied={load}
        onStartMoRule={startMoRule}
      />

      {tables.map((table) => {
        const warnings = routeTableWarnings(table, tableNames, workers);
        return (
          <Card key={table.name}>
            <CardHeader bar className="flex flex-row flex-wrap items-start justify-between gap-3 space-y-0">
              <div className="min-w-0 space-y-1.5">
                <CardTitle className="flex flex-wrap items-center gap-2 text-base font-medium">
                  <span className="font-mono">{table.name}</span>
                  <Badge variant="outline">{table.targetFunction}</Badge>
                  {!table.enabled && <Badge variant="destructive">disabled</Badge>}
                  {!!warnings.length && <Badge variant="warning">{warnings.length} to check</Badge>}
                </CardTitle>
                <CardDescription>
                  {table.label?.trim() || TARGET_FUNCTION_MEANING[table.targetFunction]}
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              {!table.rules.length ? (
                <p className="py-4 text-base text-muted-foreground">
                  No rules, so this table routes nothing.
                </p>
              ) : (
                <table className="striped w-full text-sm">
                  <thead className="border-b border-border text-left text-muted-foreground">
                    <tr>
                      <th className="px-3 py-2.5 font-medium">
                        {table.targetFunction === "NORMAL" ? "Order" : ""}
                      </th>
                      <th className="px-3 py-2.5 font-medium">Sends to</th>
                      <th className="px-3 py-2.5 font-medium">When</th>
                      <th className="px-3 py-2.5 font-medium">Filters</th>
                      <th className="px-3 py-2.5 font-medium">
                        <span className="sr-only">On</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {table.rules.map((rule, i) => {
                      const kind = targetKind(rule.target, tableNames, workers);
                      //Outbound is not shown: it is the ordinary case, and a badge on every row
                      //would be the row nobody reads. Receipt and Inbound are the two directions
                      //worth a second look, because they are the ones a business rule can be
                      //mistaken for -- or the reverse, a system rule mistaken for a stray one
                      const direction = ruleDirection(rule);
                      return (
                        <tr key={rule.id ?? i} className="border-b border-border last:border-0">
                          <td className="px-3 py-2.5 align-top text-sm text-muted-foreground">
                            {table.targetFunction === "NORMAL" ? i + 1 : "·"}
                          </td>
                          <td className="px-3 py-2.5 align-top">
                            <span className="flex flex-wrap items-center gap-1.5">
                              <span className="font-mono text-sm">{rule.target}</span>
                              {kind === "table" && (
                                <ArrowRight className="h-3 w-3 text-muted-foreground" aria-label="another table" />
                              )}
                              {kind === "unknown" && (
                                <Badge variant="warning">not recognised</Badge>
                              )}
                              {/*certain, unlike "not recognised": the worker is in app_worker with
                                 enabled = false, so this rule provably sends nothing*/}
                              {kind === "disabled" && (
                                <Badge variant="warning">vendor switched off</Badge>
                              )}
                              {direction !== "outbound" && (
                                <Badge variant={direction === "receipt" ? "default" : "outline"}>
                                  {RULE_DIRECTION_LABEL[direction]}
                                </Badge>
                              )}
                              {rule.copied && <Badge variant="outline">copy</Badge>}
                            </span>
                            {rule.label && (
                              <span className="block text-xs text-muted-foreground">{rule.label}</span>
                            )}
                            {ruleMatchCount(metrics, table.name, rule, i) !== null && (
                              <span className="block text-xs text-muted-foreground">
                                {ruleMatchCount(metrics, table.name, rule, i)} sent · since restart
                              </span>
                            )}
                          </td>
                          <td className="px-3 py-2.5 align-top">
                            {rule.conditions.length ? (
                              <span className="flex flex-col gap-0.5 font-mono text-xs text-muted-foreground">
                                {rule.conditions.map((c, n) => (
                                  <span key={n} className="whitespace-nowrap">
                                    {c.field} {c.negate ? "not " : ""}{c.operator} {c.value}
                                  </span>
                                ))}
                              </span>
                            ) : (
                              <span className="text-xs text-muted-foreground">anything</span>
                            )}
                          </td>
                          <td className="px-3 py-2.5 align-top">
                            {rule.filters.length ? (
                              <span className="flex flex-wrap gap-1">
                                {rule.filters.map((f) => (
                                  <span key={f} className="font-mono text-xs text-muted-foreground">{f}</span>
                                ))}
                              </span>
                            ) : (
                              <span className="text-xs text-muted-foreground">—</span>
                            )}
                          </td>
                          <td className="px-3 py-2.5 align-top text-right">
                            {rule.id != null && (
                              <Button
                                variant="ghost"
                                size="sm"
                                className={rule.enabled ? "text-muted-foreground" : undefined}
                                disabled={busy === `${table.name}:${rule.id}`}
                                title={rule.enabled ? "Disable this rule" : "Enable this rule"}
                                onClick={async () => {
                                  const failure = await toggleRule(table.name, rule.id!, !rule.enabled);
                                  if (failure) {
                                    setRemoveError(failure);
                                  }
                                }}
                              >
                                {rule.enabled
                                  ? <Power className="h-4 w-4" />
                                  : <PowerOff className="h-4 w-4 text-amber-600 dark:text-amber-400" />}
                              </Button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}

              {warnings.map((w) => (
                <p key={w} className="mt-2 text-sm text-amber-600 dark:text-amber-400">{w}</p>
              ))}
            </CardContent>
            <CardFooter bar className="gap-2">
              <Button variant="outline" size="sm" onClick={() => setEditing(table)}>Edit</Button>
              <span className="ml-auto">
                <DangerAction
                  label="Delete"
                  confirmLabel="Delete this table"
                  busy={busy === table.name}
                  consequence={describeTableRemoval(table, tables)}
                  onConfirm={async () => setRemoveError((await remove(table.name)) ?? "")}
                />
              </span>
            </CardFooter>
          </Card>
        );
      })}

      {!tables.length && !loading && (
        <Card>
          <CardContent className="py-8 text-center text-base text-muted-foreground">
            No routing tables. The gateway would have nowhere to send anything.
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader bar>
          <CardTitle className="text-base font-medium">Add a table</CardTitle>
          <CardDescription>
            A table is a named list of rules. Other tables chain into it by name, and so does the
            entry point the gateway starts from.
          </CardDescription>
        </CardHeader>
        <CardFooter bar>
          <Button size="sm" className="gap-2" onClick={() => setEditing("new")}>
            <Plus className="h-4 w-4" />
            New routing table
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
