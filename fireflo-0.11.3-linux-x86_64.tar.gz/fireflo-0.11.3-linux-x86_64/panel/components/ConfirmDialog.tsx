"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";

/**
 * A destructive action confirmed in a modal, for triggers too small to arm in place.
 *
 * <p><strong>This does not replace {@link DangerAction}, and the difference is the trigger rather
 * than the danger.</strong> `DangerAction` expands in the row it lives in, which is right when the
 * trigger is a word wide enough to grow into a sentence. An icon-only trigger has nowhere to expand
 * to — a 32px button cannot become a paragraph without the table reflowing under the pointer — so
 * the sentence goes in a dialog instead.
 *
 * <p><strong>The consequence sentence is not optional.</strong> That is the whole safety posture
 * this codebase has about destructive actions: the operator is told what stops working, in the
 * specific — which sender ID, which customer — rather than being asked "are you sure?", which is a
 * question nobody has ever answered no to. A trash icon that deleted on click would be the only
 * unconfirmed destructive action in the panel.
 *
 * <p>Escape, focus return and the tab trap come from `Dialog`. Errors keep the dialog open, because
 * a failure with nowhere to appear is a failure the operator does not learn about.
 */
export function ConfirmDialog({
  open,
  title,
  consequence,
  confirmLabel,
  tone = "destructive",
  busy = false,
  error = "",
  onConfirm,
  onCancel,
  children,
}: {
  open: boolean;
  title: string;
  /** What stops working, named. Not "this cannot be undone". */
  consequence: string;
  confirmLabel: string;
  /**
   * Red is the default because everything that reached for this dialog first was a deletion. Bulk
   * approval is consequential enough to confirm and not destructive at all, and a red button on it
   * would teach operators that the colour means nothing.
   */
  tone?: "destructive" | "primary";
  busy?: boolean;
  error?: string;
  onConfirm: () => void;
  onCancel: () => void;
  /**
   * One control the confirmation itself needs — a target to pick, say.
   *
   * <p>Deliberately narrow. A dialog that grows a form stops being a confirmation, and the whole
   * value of this component is that the operator is reading a consequence rather than filling
   * something in. Use it when the action has exactly one free choice and no sensible default.
   */
  children?: React.ReactNode;
}) {
  if (!open) {
    return null;
  }
  return (
    <Dialog open onClose={busy ? () => {} : onCancel} title={title} className="max-w-md">
      <p className="text-base text-muted-foreground">{consequence}</p>
      {children}
      {error && <p className="mt-3 text-sm text-destructive">{error}</p>}
      <div className="mt-5 flex justify-end gap-2">
        <Button variant="outline" size="sm" disabled={busy} onClick={onCancel}>
          Cancel
        </Button>
        <Button
          size="sm"
          disabled={busy}
          onClick={onConfirm}
          className={tone === "destructive"
            ? "bg-destructive text-destructive-foreground hover:bg-destructive/90"
            : undefined}
        >
          {busy ? "Working…" : confirmLabel}
        </Button>
      </div>
    </Dialog>
  );
}

/**
 * The open/closed bookkeeping for a table where each row can raise the same dialog.
 *
 * <p>One piece of state for the whole table rather than one per row: two confirmations open at once
 * is not a state worth being able to reach.
 */
export function useConfirm<T>() {
  const [pending, setPending] = useState<T | null>(null);
  return { pending, ask: setPending, dismiss: () => setPending(null) };
}
