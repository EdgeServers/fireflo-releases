"use client";
import { Menu } from "lucide-react";
import { HealthLink } from "./HealthLink";
import { ThemeToggle } from "./ThemeToggle";
import { usePageMeta } from "@/hooks/usePageMeta";

interface MobileHeaderProps {
  onMenuClick: () => void;
}

export function MobileHeader({ onMenuClick }: MobileHeaderProps) {
  const { title } = usePageMeta();

  return (
    <header className="flex items-center justify-between border-b border-border bg-card px-4 py-3 md:hidden">
      <button
        onClick={onMenuClick}
        //-ml-1.5 keeps the icon optically aligned with the content below while the padding grows:
        //this is the most-tapped control on a phone and 41px was under the 44 a thumb needs
        className="-ml-1.5 rounded-md p-3 text-muted-foreground hover:bg-accent hover:text-foreground transition-colors"
        aria-label="Open menu"
      >
        <Menu className="h-5 w-5" />
      </button>

      <div className="text-center">
        <p className="text-base font-semibold tracking-tight leading-tight">{title}</p>
      </div>

      <div className="flex items-center gap-1">
        <HealthLink />
        <ThemeToggle />
      </div>
    </header>
  );
}
