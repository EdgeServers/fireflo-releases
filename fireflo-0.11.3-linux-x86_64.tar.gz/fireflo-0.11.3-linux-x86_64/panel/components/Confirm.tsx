import { Checkbox } from "@/components/ui/checkbox";

/**
 * A tick box that has to be ticked before something surprising is allowed.
 *
 * <p>Amber-bordered rather than destructive: what it guards is legal, and the operator may well mean
 * it. What it prevents is doing it without having read the sentence.
 *
 * <p>Lifted out of `CredentialForm`, which already carried a comment admitting the duplicate.
 */
export function Confirm({
  checked,
  onChange,
  title,
  detail,
}: {
  checked: boolean;
  onChange: (checked: boolean) => void;
  title: string;
  detail: string;
}) {
  return (
    <label className="flex items-start gap-2 rounded-lg border border-amber-500/40 p-3 text-base">
      <Checkbox checked={checked} onChange={(e) => onChange(e.target.checked)} className="mt-0.5" />
      <span>
        {title}
        <span className="block text-xs text-muted-foreground">{detail}</span>
      </span>
    </label>
  );
}
