"use client";
import { useCallback, useEffect, useState } from "react";
import { Download, Loader2, Radio } from "lucide-react";
import { Button, buttonClasses } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { count } from "@/lib/format";
import type { HealthSession } from "@/lib/health-types";

/**
 * Record one session's SMPP traffic, then read or download it.
 *
 * <p>The narrow replacement for the only tool that existed: turning on `log.pdus` for a whole
 * worker, which writes every session's PDUs into a shared log file kept for a fortnight. This
 * records one session, stops on its own, and the gateway drops it after fifteen minutes.
 *
 * <p><strong>Not a {@code DangerAction}.</strong> A capture changes nothing about the traffic — that
 * component's own documentation warns against colouring a non-destructive act red, and treating a
 * read as destructive would make the real destructive button beside it mean less. The consequence
 * that <em>does</em> need saying is about content, not damage, so the dialog says it in a sentence.
 */
const DURATIONS = [30, 60, 120, 300];

/** Only polls while a capture is actually running — never a third always-on timer beside the health poll. */
const POLL_MS = 3_000;

interface CaptureState {
  running: boolean;
  pdus: number;
  bytes: number;
  dropped: number;
  stopped_because: string | null;
  preview: string[];
}

export function CaptureSession({
  worker,
  session,
  isVendor,
}: {
  worker: string;
  session: HealthSession;
  isVendor: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [seconds, setSeconds] = useState(60);
  const [state, setState] = useState<CaptureState | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const id = session.session_id;
  const base = `/api/control/workers/${encodeURIComponent(worker)}/sessions/${id}/capture`;

  const refresh = useCallback(async () => {
    try {
      const res = await fetch(`${base}?preview=40`);
      const json = await res.json().catch(() => null);
      if (res.ok && json?.data) {
        setState(json.data as CaptureState);
      }
    } catch {
      //a failed poll is not worth an error message: the next one is three seconds away, and the
      //buttons below still report anything the operator actually asked for
    }
  }, [base]);

  useEffect(() => {
    if (!open || !state?.running) {
      return;
    }
    const timer = setInterval(refresh, POLL_MS);
    return () => clearInterval(timer);
  }, [open, state?.running, refresh]);

  async function send(method: "POST" | "DELETE") {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(base, {
        method,
        headers: { "Content-Type": "application/json" },
        body: method === "POST" ? JSON.stringify({ seconds }) : undefined,
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? "The gateway did not confirm.");
        return;
      }
      setState(json?.data as CaptureState);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not reach the panel.");
    } finally {
      setBusy(false);
    }
  }

  const running = state?.running ?? false;
  const finished = state != null && !running && state.pdus > 0;

  return (
    <>
      <Button variant="outline" size="sm" onClick={() => { setOpen(true); void refresh(); }}>
        <Radio className="size-3.5" aria-hidden />
        Capture
      </Button>

      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        title={`Capture ${session.system_id ?? session.host ?? "session"} · ${id}`}
        description={
          isVendor
            ? //the vendor-specific exposure, said where the decision is made rather than in a doc:
              //this worker reconnects on its own schedule, and the bind it sends is our credential
              "Records this connection's SMPP traffic, including message content and destination "
              + "numbers. If this vendor reconnects while the capture runs, the bind it sends "
              + "contains this gateway's password at that carrier."
            : "Records this session's SMPP traffic, including message content and destination "
              + "numbers. A customer's password only appears if they re-bind while the capture runs."
        }
      >
        <div className="flex flex-col gap-3">
          {!running && (
            <label className="flex items-center gap-2 text-sm">
              <span className="text-muted-foreground">Run for</span>
              <select
                className="h-11 rounded border border-input bg-transparent px-2 text-sm md:h-9 md:py-1"
                value={seconds}
                onChange={(e) => setSeconds(Number(e.target.value))}
              >
                {DURATIONS.map((d) => (
                  <option key={d} value={d}>
                    {d < 60 ? `${d} seconds` : `${d / 60} minute${d > 60 ? "s" : ""}`}
                  </option>
                ))}
              </select>
              <span className="text-muted-foreground">or until you stop it</span>
            </label>
          )}

          <div className="flex items-center gap-2">
            <Button size="sm" disabled={busy} onClick={() => send(running ? "DELETE" : "POST")}>
              {busy && <Loader2 className="size-3.5 animate-spin" aria-hidden />}
              {running ? "Stop" : "Start capture"}
            </Button>
            {state && (
              <span className="text-xs text-muted-foreground">
                {count(state.pdus)} PDUs · {count(state.bytes)} bytes
                {/* > 0, not truthiness: reporting "0 dropped" on every capture would train people to
                    stop reading the one number that says the file is incomplete */}
                {state.dropped > 0 && (
                  <span className="text-destructive"> · {count(state.dropped)} dropped</span>
                )}
                {!running && state.stopped_because && ` · ${state.stopped_because}`}
              </span>
            )}
          </div>

          {error && <p className="text-xs text-destructive">{error}</p>}

          {state && state.preview.length > 0 && (
            <pre className="max-h-64 overflow-auto rounded bg-muted p-2 text-xs leading-relaxed">
              {state.preview.join("\n")}
            </pre>
          )}

          {finished && (
            <div className="flex items-center gap-2">
              {/* plain links, not fetch-into-blob: the browser owns the save dialog, the file never
                  passes through JavaScript, and a large capture is not held in memory twice */}
              <a className={buttonClasses({ variant: "outline", size: "sm" })} href={`${base}/file/txt`} download>
                <Download className="size-3.5" aria-hidden />
                Decoded log
              </a>
              <a className={buttonClasses({ variant: "outline", size: "sm" })} href={`${base}/file/pcap`} download>
                <Download className="size-3.5" aria-hidden />
                Wireshark pcap
              </a>
              <span className="text-xs text-muted-foreground">Kept for 15 minutes.</span>
            </div>
          )}
        </div>
      </Dialog>
    </>
  );
}
