"use client";
import { usePageMeta } from "@/hooks/usePageMeta";
import { HealthLink } from "./HealthLink";
import { ThemeToggle } from "./ThemeToggle";

export function DesktopHeader() {
  const { title, subtitle } = usePageMeta();

  return (
    <header className="hidden md:flex shrink-0 items-center justify-between border-b bg-card px-8 py-3">
      <div>
        <p className="text-base font-semibold tracking-tight">{title}</p>
        {subtitle && (
          <p className="text-sm text-muted-foreground mt-0.5">{subtitle}</p>
        )}
      </div>
      <div className="flex items-center gap-1">
        <HealthLink />
        <ThemeToggle />
      </div>
    </header>
  );
}
