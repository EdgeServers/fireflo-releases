"use client";
import { useState } from "react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle,
} from "@/components/ui/card";
import { CredentialsClient } from "./CredentialsClient";
import { ProductReadiness } from "./ProductReadiness";
import { surface } from "@/lib/panel-surface";

/**
 * Who may connect as this account.
 *
 * <p>`addingLogin` used to live on the account page so a footer button in one card could open a
 * form in another card's body — coordination state that existed only because two unrelated cards
 * shared a page. Here the card and the form are the whole tab, so it is local.
 */
export function AccountLoginsClient({ id }: { id: string }) {
  const [adding, setAdding] = useState(false);

  return (
    //full width on purpose: the credentials table inside carries a column chooser and eight columns,
    //so this is a tab that earns the space rather than a card stretched across it
    <div className="space-y-4">
      <Card>
      <CardHeader bar>
        <CardTitle className="text-base font-medium">Logins that bill here</CardTitle>
        <CardDescription>
          A message carries its own account id, so pricing still applies to traffic that arrives
          under it from a login this panel never saw.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* above the list rather than beside a row: the fix is usually "create the product" or
            "correct the login", and knowing which needs seeing them together.

            Operator-only: it reports whether each login's product is rated, which is a statement
            about the tariff. A reseller-created login carries no product at all -- the writer pins
            the column NULL -- so there would be nothing for it to report either way */}
        {surface().pricing && <ProductReadiness account={id} />}
        <CredentialsClient account={id} chrome={false} addOpen={adding}
          onAddHandled={() => setAdding(false)} />
      </CardContent>
      <CardFooter bar>
        <Button size="sm" className="gap-2" onClick={() => setAdding(true)}>
          <Plus className="h-4 w-4" />
          Add login
        </Button>
      </CardFooter>
      </Card>
    </div>
  );
}
