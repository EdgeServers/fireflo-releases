"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Antenna, ArrowLeft, ChevronDown, ChevronRight, Globe, Plus, Search, Wallet } from "lucide-react";
import { DangerAction } from "./DangerAction";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { AddRuleButton, ProductPricingTable } from "./ProductPricingTable";
import { GatewayIgnores } from "./GatewayIgnores";
import { PricingImport } from "./PricingImport";
import { ScopeForm } from "./ScopeForm";
import { useProductCatalogue } from "./useProducts";
import { useRates } from "./useRates";
import {
  type KnownScopes,
  type ProductScopeSummary,
  type RateRule,
  type RateRuleInput,
  type RulePatch,
  DEFAULT_SCOPE,
  scopeKind,
  scopeWarnings,
} from "@/lib/rate-types";

/** Rows per page. The search box is the real tool; this just keeps the DOM sane. */
const PAGE_SIZE = 25;

/**
 * Who prices one product, and an editor for whichever of them you open.
 *
 * <p><strong>This page used to load every rule of every scope.</strong> It had to: saving replaces a
 * scope wholesale, so the editor could not hold a filtered view — and with a thousand customers that
 * meant a thousand complete scopes, which the server refused outright past two thousand rules. The
 * page did not get slow, it stopped working.
 *
 * <p>Now it lists counts and fetches one scope's rules when somebody opens that row. There is no
 * threshold and no second mode: the same list, the same editor, at three scopes or three thousand.
 *
 * <p>The whole-scope rule did not go away, it moved. An expanded row holds the complete scope in
 * `seq` order even though it shows only this product's slice — because `saveScope` still deletes
 * every rule it is not given, and still renumbers `seq` from array position.
 *
 * <p>Reordering still is not offered here, for the reason it never was: this view is filtered, so a
 * move button would reorder against rules that are not on screen. The escape hatch now goes
 * somewhere useful — the account or vendor page, which holds the scope entire.
 */
export function ProductDetailClient({ name }: { name: string }) {
  const [scopes, setScopes] = useState<ProductScopeSummary[]>([]);
  const [known, setKnown] = useState<KnownScopes>({ vendors: [], accounts: [] });
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [pushing, setPushing] = useState(false);
  const [page, setPage] = useState(0);

  //the scope currently open, and the WHOLE of it. Never the filtered view -- see the class comment
  const [open, setOpen] = useState<string | null>(null);
  const [held, setHeld] = useState<RateRule[] | null>(null);
  const [dirty, setDirty] = useState(false);

  //the "set a price" dialog. `scope` is what it will write to, `locked` fixes it there
  const [pricing, setPricing] = useState<{ scope: string; locked: boolean } | null>(null);

  const { loadScope, saveScope, setRuleEnabled, busy } = useRates();
  const catalogue = useProductCatalogue();

  const load = useCallback(async () => {
    try {
      const res = await fetch(`/api/control/products/${encodeURIComponent(name)}/pricing`, {
        cache: "no-store",
      });
      const json = await res.json();
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      setScopes(json.data.scopes as ProductScopeSummary[]);
      setKnown(json.data.known as KnownScopes);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setLoading(false);
    }
  }, [name]);

  useEffect(() => {
    void load();
  }, [load]);

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return scopes.filter((s) => !q || s.scope.toLowerCase().includes(q));
  }, [scopes, query]);

  //the default is one of the scopes pricing this product, but it is not one of them in meaning:
  //it belongs to no customer and applies to all of them, so it is lifted out of the list
  const defaultScope = useMemo(
    () => scopes.find((s) => s.scope === DEFAULT_SCOPE) ?? null,
    [scopes]
  );

  const pages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const shown = rows.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  async function expand(scope: string) {
    if (open === scope) {
      setOpen(null);
      setHeld(null);
      setDirty(false);
      return;
    }
    setOpen(scope);
    setHeld(null);
    setDirty(false);
    setHeld((await loadScope(scope)) ?? []);
  }

  function edit(id: number, patch: RulePatch) {
    setHeld((current) => current?.map((r) => (r.id === id ? { ...r, ...patch } : r)) ?? null);
    setDirty(true);
  }

  function addRule() {
    setHeld((current) => [
      ...(current ?? []),
      {
        //negative so it cannot collide with a real id; the route treats a null id as a create
        id: -Date.now(),
        scope: open ?? "",
        seq: (current?.length ?? 0),
        amount: "",
        product: name,
        currency: null,
        label: null,
        enabled: true,
        conditions: [],
        filters: [],
        updatedAt: null,
      },
    ]);
    setDirty(true);
  }

  async function save() {
    if (!open || !held) {
      return;
    }
    //the WHOLE held scope, in its held order -- never the filtered view on screen
    const rules: RateRuleInput[] = held.map((r) => ({
      id: r.id > 0 ? r.id : null,
      amount: r.amount,
      product: r.product,
      currency: r.currency,
      label: r.label,
      enabled: r.enabled,
      conditions: r.conditions,
      filters: r.filters,
    }));
    const failure = await saveScope(open, rules, true);
    if (failure) {
      setError(failure);
      return;
    }
    setError("");
    setNotice(`Saved ${open}. The gateway picks it up on its next poll, within thirty seconds.`);
    setDirty(false);
    setHeld((await loadScope(open)) ?? []);
    await load();
  }

  /**
   * Writes one scope's price for THIS product, leaving the rest of that scope alone.
   *
   * <p>Not `saveScope`. That replaces a scope wholesale — correct on `/cp/pricing`, whose form shows
   * you everything it is about to replace, and a data-loss trap here: creating `*` for this product
   * through it would delete `*` for every other product, from a page that never named them.
   */
  async function savePricing(scope: string, rules: RateRuleInput[]): Promise<string | null> {
    try {
      const res = await fetch(`/api/control/products/${encodeURIComponent(name)}/pricing`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        //isNew is about the RULES, not the scope: this dialog always adds pricing that was not
        //there, so an empty rule list is a save that would store nothing and say it worked
        body: JSON.stringify({ scope, rules, isNew: true, scopeConfirmed: true }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        return json?.error ?? `Request failed (${res.status})`;
      }
      setPricing(null);
      setNotice(
        `Saved. ${scope === DEFAULT_SCOPE ? `Every account with no pricing of its own now pays this for ${name}.` : `'${scope}' now has its own price for ${name}.`}`
        + " The gateway picks it up on its next poll, within thirty seconds."
      );
      await load();
      return null;
    } catch (err) {
      return err instanceof Error ? err.message : "Request failed";
    }
  }

  return (
    <>
      {pricing && (
        <Dialog
          open
          onClose={() => setPricing(null)}
          className="max-w-3xl"
          title={
            pricing.scope === DEFAULT_SCOPE
              ? `What everyone pays for ${name}`
              : `Price ${name} for one account`
          }
          description={
            pricing.scope === DEFAULT_SCOPE
              ? "Applies to every account that has no pricing of its own for this product. An "
                + "account's own rule always wins, so this is a floor rather than an override."
              : "Names one account. Its own rules are tried before the default, whatever the default says."
          }
        >
          <ScopeForm
            scope={pricing.scope}
            //one row already there, because the thing being asked for is a price. An empty form
            //invites a save that stores nothing -- which is exactly what this page used to do
            initial={[{
              id: null,
              amount: "",
              product: name,
              currency: null,
              label: null,
              enabled: true,
              conditions: [],
              filters: [],
            }]}
            known={known}
            catalogue={catalogue}
            isNew
            locked={pricing.locked}
            product={name}
            onSave={(scope, rules) => savePricing(scope, rules)}
            onCancel={() => setPricing(null)}
          />
        </Dialog>
      )}

      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link href="/cp/products"
          className="inline-flex items-center gap-1.5 text-base text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" />
          All products
        </Link>
        <div className="flex flex-wrap items-center gap-3">
          <Link href={`/cp/cdrs?product=${encodeURIComponent(name)}`}
            className="text-base text-primary hover:underline">
            Messages sent under {name} →
          </Link>
          <a
            href={`/api/control/products/${encodeURIComponent(name)}/pricing/export`}
            download
            className="inline-flex h-8 items-center rounded-md border border-input bg-background px-3 text-sm font-medium shadow-sm transition-colors hover:bg-accent"
          >
            Export CSV
          </a>
        </div>
      </div>

      <GatewayIgnores domain="rates" />

      {error && (
        <Card>
          <CardContent className="py-4 text-base text-destructive">{error}</CardContent>
        </Card>
      )}
      {notice && (
        <Card className="border-amber-500/40">
          <CardContent className="py-3 text-base">{notice}</CardContent>
        </Card>
      )}

      <Card>
        <CardContent className="space-y-3 py-4">
          <p className="flex items-center gap-2 text-base font-medium">
            <Globe className="h-4 w-4 text-muted-foreground" />
            What everyone pays for {name}
          </p>
          {defaultScope ? (
            <p className="text-base text-muted-foreground">
              {defaultScope.rules} rule{defaultScope.rules === 1 ? "" : "s"} under the default scope
              price this product for <strong>every account with no pricing of its own</strong>. An
              account&rsquo;s own rule always wins, so this is a floor rather than an override.{" "}
              <button type="button" className="underline underline-offset-2"
                onClick={() => void expand(DEFAULT_SCOPE)}>
                Open it below
              </button>{" "}
              to change it.
            </p>
          ) : (
            <div className="space-y-3">
              <p className="text-base text-muted-foreground">
                Nothing sets a default. Until one exists, an account with no rule for {name} sends
                <strong> unpriced and uncharged</strong> rather than being refused &mdash; so a customer
                onboarded and not individually priced is traffic given away.
              </p>
              <div className="flex flex-wrap items-center gap-3">
                {/* the fix, where the problem is described. This used to be a bare link to
                    /cp/pricing carrying neither the product nor the scope -- onto a page that hides
                    its sell-side section when it is empty, which is exactly when you arrive */}
                <Button className="gap-2" onClick={() => setPricing({ scope: DEFAULT_SCOPE, locked: true })}>
                  <Plus className="h-4 w-4" />
                  Set what everyone pays
                </Button>
                <Link
                  href={`/cp/pricing?scope=${encodeURIComponent(DEFAULT_SCOPE)}&product=${encodeURIComponent(name)}`}
                  className="text-xs text-muted-foreground underline underline-offset-2"
                >
                  or set it on the pricing page, with the rest of the scope in view
                </Link>
              </div>
            </div>
          )}
          {defaultScope && (
            <div className="flex flex-wrap items-center gap-3">
              {/* caution rather than destructive: this is a bulk write across every account, which
                  is worth confirming, but it takes nothing away — and colouring it the same red as a
                  delete would teach the red to mean "a dialog appeared" */}
              <DangerAction
                label="Copy onto every account"
                confirmLabel="Copy to every account"
                tone="caution"
                busy={pushing}
                consequence={
                  `Every account gets its own copy of the default price for '${name}'. Accounts `
                  + "that already price it are left exactly as they are — nothing is replaced or "
                  + "deleted."
                }
                onConfirm={async () => {
                  setPushing(true);
                  setError("");
                  try {
                    const res = await fetch(
                      `/api/control/products/${encodeURIComponent(name)}/pricing/apply-default`,
                      { method: "POST" }
                    );
                    const json = await res.json().catch(() => null);
                    if (!res.ok) {
                      setError(json?.error ?? `Request failed (${res.status})`);
                    } else {
                      setNotice(json?.notice ?? "Done.");
                      await load();
                    }
                  } finally {
                    setPushing(false);
                  }
                }}
              />
              <span className="text-xs text-muted-foreground">
                Optional. The default already applies without this &mdash; copying is for when each
                account should carry its own editable figure.
              </span>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="max-w-2xl text-base text-muted-foreground">
          {loading
            ? "Loading…"
            : `${scopes.length} scope${scopes.length === 1 ? "" : "s"} price ${name}. Open one to edit `
              + "its rules for this product, or use the CSV to change many at once."}
        </p>
        <div className="flex shrink-0 flex-wrap items-center gap-2">
          {/* the other half of "there is no option to add pricing for customers": a default is one
              price for everybody, and a negotiated rate for one account had no entry point here at
              all -- only the pricing page, where the scope box never enumerated accounts */}
          <Button variant="outline" size="sm" className="h-8 gap-1.5"
            onClick={() => setPricing({ scope: "", locked: false })}>
            <Plus className="h-3.5 w-3.5" />
            Price one account
          </Button>
          <span className="relative">
            <Search className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => { setQuery(e.target.value); setPage(0); }}
              placeholder="vendor or account"
              aria-label="Search scopes"
              className="h-8 w-56 pl-7 text-sm"
            />
          </span>
        </div>
      </div>

      {!loading && !rows.length && (
        <div className="rounded-xl border border-border p-12 text-center text-muted-foreground">
          {query.trim()
            ? `No scope matching "${query.trim()}" prices ${name}.`
            : `Nothing prices '${name}', and no catch-all covers it either.`}
        </div>
      )}

      {!!rows.length && (
        <div className="overflow-hidden rounded-xl border border-border">
          <table className="striped w-full text-sm">
            <thead className="border-b border-border bg-muted/50 text-left">
              <tr>
                <th className="w-8 px-3 py-2.5" />
                <th className="px-3 py-2.5 font-medium">Scope</th>
                <th className="px-3 py-2.5 font-medium">Rules</th>
                <th className="px-3 py-2.5 text-right font-medium">Amount</th>
              </tr>
            </thead>
            <tbody>
              {shown.map((s) => {
                const kind = scopeKind(s.scope, known);
                const Icon = kind === "cost" ? Antenna : Wallet;
                const expanded = open === s.scope;
                return (
                  <tr key={s.scope} className="border-b border-border last:border-0">
                    <td colSpan={4} className="p-0">
                      <button
                        type="button"
                        onClick={() => void expand(s.scope)}
                        aria-expanded={expanded}
                        className="flex w-full items-center gap-3 px-3 py-2.5 text-left hover:bg-accent/40"
                      >
                        {expanded
                          ? <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" />
                          : <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />}
                        <Icon className="h-4 w-4 shrink-0 text-muted-foreground" />
                        <span className="flex-1 min-w-0">
                          <span className="font-mono">{s.scope}</span>
                          <span className="ml-2 text-xs text-muted-foreground">
                            {kind === "cost"
                              ? "what this vendor charges us"
                              : kind === "price"
                                ? "what this account pays us"
                                : "neither a known vendor nor a known account"}
                            {!s.specificToProduct && " · reaches this product through a catch-all"}
                          </span>
                        </span>
                        <span className="shrink-0 text-xs tabular-nums text-muted-foreground">
                          {s.rules} of {s.scopeRules}
                        </span>
                        <span className="w-24 shrink-0 text-right font-mono text-sm tabular-nums">
                          {s.minAmount === s.maxAmount ? s.minAmount : `${s.minAmount}–${s.maxAmount}`}
                        </span>
                      </button>

                      {expanded && (
                        <div className="border-t border-border bg-muted/10 px-3 py-3">
                          {held === null ? (
                            <p className="text-xs text-muted-foreground">Loading the whole scope…</p>
                          ) : (
                            <ScopeEditor
                              product={name}
                              scope={s.scope}
                              kind={kind}
                              known={known}
                              held={held}
                              dirty={dirty}
                              busy={busy === s.scope}
                              onEdit={edit}
                              onToggleEnabled={async (id, enabled) => {
                                if (await setRuleEnabled(s.scope, id, enabled)) {
                                  setHeld((c) => c?.map((r) => (r.id === id ? { ...r, enabled } : r)) ?? null);
                                }
                              }}
                              onAdd={addRule}
                              onSave={save}
                            />
                          )}
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {pages > 1 && (
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span>{rows.length} scopes · page {page + 1} of {pages}</span>
          <span className="flex gap-2">
            <Button variant="outline" size="sm" className="h-7" disabled={page === 0}
              onClick={() => setPage(page - 1)}>Previous</Button>
            <Button variant="outline" size="sm" className="h-7" disabled={page >= pages - 1}
              onClick={() => setPage(page + 1)}>Next</Button>
          </span>
        </div>
      )}

      <PricingImport product={name} onImported={load} />

      {!!scopes.length && (
        <p className="text-base text-muted-foreground">
          No margin is shown here on purpose: a price rule and a cost rule are only comparable when
          their conditions match exactly.{" "}
          <Link href="/cp/revenue" className="text-primary hover:underline">Revenue</Link> has the real
          figure, from traffic that actually happened.
        </p>
      )}
    </>
  );
}

/**
 * One scope's rules for this product, with the whole scope behind them.
 *
 * <p>`held` is the complete scope; `relevant` is what this product is priced by, which is the
 * product's own rules plus the catch-alls — the same set `RateSnapshot.rulesFor` assembles. The
 * difference between the two is what the table warns about, because a save writes `held`.
 */
function ScopeEditor({
  product,
  scope,
  kind,
  known,
  held,
  dirty,
  busy,
  onEdit,
  onToggleEnabled,
  onAdd,
  onSave,
}: {
  product: string;
  scope: string;
  kind: string;
  known: KnownScopes;
  held: RateRule[];
  dirty: boolean;
  busy: boolean;
  onEdit: (id: number, patch: RulePatch) => void;
  onToggleEnabled: (id: number, enabled: boolean) => void;
  onAdd: () => void;
  onSave: () => void;
}) {
  const relevant = held.filter((r) => !r.product || r.product === product);
  const warnings = scopeWarnings({
    scope,
    rules: held.map((r) => ({ ...r, id: r.id > 0 ? r.id : null })),
  }, known);

  return (
    <div className="space-y-2">
      <ProductPricingTable
        product={product}
        scope={scope}
        kind={kind}
        rules={relevant}
        hidden={held.length - relevant.length}
        busy={busy}
        onChange={onEdit}
        onToggleEnabled={onToggleEnabled}
      />
      <div className="flex flex-wrap items-center gap-3">
        <AddRuleButton onAdd={onAdd} />
        {dirty && (
          <Button size="sm" disabled={busy} onClick={onSave}>
            {busy ? "Saving…" : "Save"}
          </Button>
        )}
        {/* the escape hatch, and it now goes somewhere that can actually reorder: that page holds
            the scope entire, which is the condition saveScope was built around */}
        <Link
          href={kind === "cost" ? "/cp/vendors" : `/cp/accounts/${encodeURIComponent(scope)}`}
          className="text-xs text-primary hover:underline"
        >
          {kind === "cost"
            ? `Edit all of ${scope}'s cost rates on the vendor →`
            : `Edit all of ${scope}'s pricing →`}
        </Link>
      </div>
      {!!warnings.length && (
        <div className="space-y-1 pt-1">
          {warnings.map((w, i) => (
            <p key={i} className="text-xs text-amber-600 dark:text-amber-400">{w}</p>
          ))}
        </div>
      )}
    </div>
  );
}
