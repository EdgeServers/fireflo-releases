"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { DisclosureSection } from "./DisclosureSection";
import type { AccountInput } from "@/lib/account-types";

/**
 * Who an account is, and the three switches that decide where it sits.
 *
 * <p>Six controls. It used to read as far more than that because each one carried a three-line
 * paragraph explaining a consequence — the prose ran to twice the length of the form, and the two
 * fields somebody actually edits were the two hardest to find. The explanations are all still true,
 * so none of them are deleted: the one-liner stays visible and the full version moves to `title`.
 *
 * <p>Name, email and notes are always open because they are what changes. Listing, reselling and
 * the parent are behind {@link DisclosureSection} — each is a decision made once at onboarding, and
 * two of them are dangerous to nudge while looking for the name field.
 *
 * <p>The badge on that section counts what is <em>set</em> rather than what is present, so a
 * collapsed section still tells you an account is unlisted or belongs to a reseller. Hiding that
 * silently is exactly how a form loses a setting.
 */
export function AccountForm({
  id,
  label: initialLabel,
  description: initialDescription,
  email: initialEmail,
  enabled: initialEnabled,
  resells: initialResells,
  parentAccountId: initialParent,
  childCount,
  busy,
  allowHierarchy = true,
  onSave,
  onReload,
}: {
  id: string;
  label: string;
  description: string;
  email: string;
  enabled: boolean;
  resells: boolean;
  parentAccountId: string | null;
  childCount: number;
  busy: boolean;
  /**
   * Whether to offer the Advanced section at all: listing, reselling and the parent.
   *
   * <p>False in the customer portal. Those are the three fields the write path pins rather than
   * accepts — `parent_account_id` is set from the session, `resells` is written FALSE as a literal,
   * and listing is changed by Suspend, which does the operational half as well. Rendering controls
   * the server would ignore is how a form comes to lie about what it did.
   *
   * <p>Defaults to true, so every operator caller is unchanged and stays that way on purpose.
   */
  allowHierarchy?: boolean;
  onSave: (input: AccountInput) => Promise<boolean>;
  onReload: () => void;
}) {
  //one object rather than six useStates. The old form kept six, and its Cancel reset four of them
  //-- `resells` and the parent survived a discard and were saved on the next click, which is a
  //silent wrong write on the two fields with database constraints behind them. Resetting one value
  //cannot go out of step with the fields the way six assignments did
  const seed = {
    label: initialLabel,
    description: initialDescription,
    email: initialEmail,
    enabled: initialEnabled,
    resells: initialResells,
    parent: initialParent ?? "",
  };
  const [form, setForm] = useState(seed);
  const set = <K extends keyof typeof seed>(key: K, value: (typeof seed)[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  const dirty = (Object.keys(seed) as (keyof typeof seed)[]).some((k) => form[k] !== seed[k]);
  //what the collapsed section is hiding, counted as "not the default" rather than "not empty":
  //unlisted is a set state even though the value is false
  const advancedSet = (form.enabled ? 0 : 1) + (form.resells ? 1 : 0) + (form.parent.trim() ? 1 : 0);
  const [advancedOpen, setAdvancedOpen] = useState(advancedSet > 0);

  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Name" htmlFor="acct-label">
          <Input id="acct-label" value={form.label} placeholder="Acme Communications"
            onChange={(e) => set("label", e.target.value)} />
        </Field>
        <Field
          label="Email"
          htmlFor="acct-email"
          hint="How this customer signs in to their portal. Without it, they cannot."
        >
          <Input id="acct-email" type="email" value={form.email} placeholder="ops@acme.com"
            title="The customer enters this address on the portal and a single-use sign-in link is
                   mailed to it — there is no password, and no operator-side way to issue the link,
                   so an account with no address here cannot reach the portal at all. One account
                   per address, ignoring case: a second account with the same address is refused."
            onChange={(e) => set("email", e.target.value)} />
        </Field>
        {/* a note is a sentence, and it was in a single-line Input under a label reading "Notes" */}
        <Field label="Notes" htmlFor="acct-desc" className="sm:col-span-2">
          <textarea
            id="acct-desc"
            rows={2}
            value={form.description}
            onChange={(e) => set("description", e.target.value)}
            className="w-full rounded-md border border-input bg-background px-3 py-2 text-base shadow-sm"
            placeholder="Anything the next operator should know"
          />
        </Field>
      </div>

      {allowHierarchy && (
      <DisclosureSection
        title="Advanced"
        set={advancedSet}
        open={advancedOpen}
        onToggle={() => setAdvancedOpen((o) => !o)}
        note="Listing, reselling and the hierarchy. Set once at onboarding and rarely again."
      >
        <label className="flex items-start gap-2 text-base">
          <Checkbox checked={form.enabled} className="mt-0.5"
            onChange={(e) => set("enabled", e.target.checked)} />
          <span>
            Listed
            <span
              className="block text-xs text-muted-foreground"
              title="The gateway never reads the account catalogue. Unlisting one does not stop its
                     logins connecting, its traffic sending, or its rate rules pricing. To stop
                     traffic, disable the logins; to stop spend, use the balance."
            >
              Shows it in this panel&rsquo;s lists. Traffic keeps flowing either way.
            </span>
          </span>
        </label>

        {/*
          An account either holds others or belongs to one — the database refuses the combination
          outright. Offering both and letting the save fail would be a form that invites a
          rejection, so each half disables the other.
        */}
        <label className="flex items-start gap-2 text-base">
          <Checkbox checked={form.resells} disabled={form.parent.trim() !== ""} className="mt-0.5"
            onChange={(e) => set("resells", e.target.checked)} />
          <span>
            Resells services
            <span className="block text-xs text-muted-foreground">
              Lets it hold other accounts and move balance to and from them.
              {childCount > 0
                && ` Holds ${childCount} account${childCount === 1 ? "" : "s"}, so it cannot be switched off until they move.`}
            </span>
          </span>
        </label>

        <Field
          label="Belongs to"
          htmlFor="acct-parent"
          hint={form.resells
            ? "Unavailable while this account resells."
            : "The reseller above it. Empty means top-level."}
        >
          <Input id="acct-parent" value={form.parent} placeholder="reseller-a" className="font-mono"
            disabled={form.resells}
            title="That reseller must already be marked as reselling. There are exactly two levels,
                   and the database enforces both rules."
            onChange={(e) => set("parent", e.target.value)} />
        </Field>
      </DisclosureSection>
      )}

      {dirty && (
        <div className="flex gap-2">
          <Button disabled={busy}
            onClick={async () => {
              if (await onSave({
                id,
                label: form.label,
                description: form.description,
                email: form.email,
                enabled: form.enabled,
                resells: form.resells,
                parentAccountId: form.parent.trim() || null,
              })) {
                onReload();
              }
            }}>
            {busy ? "Saving…" : "Save"}
          </Button>
          {/* one assignment, so a field added above cannot be forgotten here */}
          <Button variant="outline" disabled={busy} onClick={() => setForm(seed)}>
            Cancel
          </Button>
        </div>
      )}
    </div>
  );
}
