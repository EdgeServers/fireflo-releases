"use client";
import { useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Card, CardContent } from "@/components/ui/card";
import { buttonClasses } from "@/components/ui/button";
import Link from "next/link";
import { verifyOutcome, type VerifySession } from "@/lib/verify-outcome";

/**
 * Spends the token in the URL and signs the browser in.
 *
 * <p>Posts to the portal's own NextAuth callback rather than calling `signIn` from `next-auth/react`
 * — that helper is bound to the operator instance's endpoint, and using it here would try to sign
 * the customer in as an operator.
 *
 * <p><strong>Guarded against firing twice.</strong> React 19 runs effects twice in development, and
 * a token is single use: without the ref the second run spends a token that was already spent and
 * the customer sees "this link has already been used" for a link that just worked.
 */
export function MisVerify() {
  const params = useSearchParams();
  const router = useRouter();
  const [failed, setFailed] = useState(false);
  const started = useRef(false);

  useEffect(() => {
    if (started.current) {
      return;
    }
    started.current = true;

    const token = params.get("token");
    if (!token) {
      setFailed(true);
      return;
    }

    (async () => {
      try {
        const csrfRes = await fetch("/api/mis/auth/csrf");
        const { csrfToken } = (await csrfRes.json()) as { csrfToken: string };
        const body = new URLSearchParams({ csrfToken, token, redirect: "false" });
        const res = await fetch("/api/mis/auth/callback/magic-link", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body,
        });
        //neither the status nor the session can answer this alone -- the rule, and the defect it
        //replaces, are written out in lib/verify-outcome.ts, where they are testable without a
        //browser. In short: fetch follows next-auth's 302, so res.ok is true for a rejected token,
        //and a browser that is already signed in has a session whatever this token did
        const session = (await (await fetch("/api/mis/auth/session")).json()) as VerifySession;
        if (verifyOutcome(res.url, window.location.origin, session) === "signed-in") {
          //the overview, not the message list. Signing in and being handed three hundred rows
          //answers "what happened to message X" before anybody has asked it; the dashboard answers
          //"is my traffic healthy", which is the question somebody actually arrives with
          router.replace("/overview");
          return;
        }
        setFailed(true);
      } catch {
        setFailed(true);
      }
    })();
  }, [params, router]);

  return (
    <main className="flex min-h-dvh items-center justify-center px-4">
      <Card className="w-full max-w-md">
        <CardContent className="space-y-3 py-8 text-center text-base">
          {failed ? (
            <>
              <p className="font-medium">That link did not work.</p>
              <p className="text-muted-foreground">
                Sign-in links work once and expire after 15 minutes. Ask for a new one.
              </p>
              <Link href="/" className={buttonClasses({ variant: "outline", size: "sm" })}>
                Back to sign in
              </Link>
            </>
          ) : (
            <p className="text-muted-foreground">Signing you in…</p>
          )}
        </CardContent>
      </Card>
    </main>
  );
}
