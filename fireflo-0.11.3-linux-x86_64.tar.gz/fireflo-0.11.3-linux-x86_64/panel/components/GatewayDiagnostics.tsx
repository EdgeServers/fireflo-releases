"use client";

/**
 * How much the gateway says about itself, as one control.
 *
 * <h2>Why this card exists</h2>
 *
 * <p>Answering "why did this customer stop getting delivery receipts" used to mean knowing that
 * `message.trace.mode` exists, that it is global rather than per-instance, that this panel could not
 * set it at all, and that `smsg.cdr.events` is a different key with a different vocabulary. Three
 * names for one idea, and a psql session on a live gateway to reach one of them.
 *
 * <h2>What the level does not touch, and why that is on screen</h2>
 *
 * <p>`smsg.cdr.body` and `print.msgs` store customer message text, phone numbers and bind
 * passwords. No level here switches either on, and the card says so — an operator raising a
 * diagnostic level to chase a receipt must not discover afterwards that they began retaining
 * message content.
 */
const LEVELS = [
  {
    value: "off",
    label: "Off",
    blurb: "Errors only. Nothing about individual messages.",
    cost: "No write volume. Also no way to answer a support question without changing this first.",
  },
  {
    value: "problems",
    label: "Problems",
    blurb:
      "Lifecycle milestones, plus a durable record of anything that did not go as the customer "
      + "asked — a receipt withheld, held, or that failed to send, and callbacks that did not "
      + "succeed.",
    cost: "Near-zero on a healthy gateway: these rows appear when something goes wrong.",
  },
  {
    value: "verbose",
    label: "Verbose",
    blurb: "Every routing decision, submit response and enqueue, and an event row per receipt.",
    cost: "Real log and database volume on a busy gateway. For one customer for one afternoon.",
  },
] as const;

export function GatewayDiagnostics({
  level,
  overrides,
  onChange,
  busy = false,
}: {
  /** The stored `smsg.diagnostics`, or "" when unset. */
  level: string;
  /**
   * Keys set explicitly, which therefore beat the level. Shown because a level that appears to be
   * in force while a key quietly outranks it is the one failure this design introduces.
   */
  overrides: { key: string; value: string }[];
  onChange: (level: string) => void;
  busy?: boolean;
}) {
  const current = LEVELS.find((l) => l.value === level);

  return (
    <div className="space-y-3">
      <p className="text-base text-muted-foreground">
        One setting for how much the gateway records about individual messages. It supplies the
        default for <code className="font-mono">message.trace.mode</code> and{" "}
        <code className="font-mono">smsg.cdr.events</code>; either key set on its own still wins.
      </p>

      <div className="space-y-2">
        {LEVELS.map((l) => (
          <label key={l.value} className="flex items-start gap-2 text-base">
            <input
              type="radio"
              name="diagnostics"
              value={l.value}
              checked={level === l.value}
              disabled={busy}
              onChange={() => onChange(l.value)}
              className="mt-1"
            />
            <span>
              <span className="font-medium">{l.label}</span>
              {l.value === "problems" && (
                <span className="text-muted-foreground"> — recommended</span>
              )}
              <span className="block text-muted-foreground">{l.blurb}</span>
              <span className="block text-xs text-muted-foreground">{l.cost}</span>
            </span>
          </label>
        ))}
        <label className="flex items-start gap-2 text-base">
          <input
            type="radio"
            name="diagnostics"
            value=""
            checked={!current}
            disabled={busy}
            onChange={() => onChange("")}
            className="mt-1"
          />
          <span>
            <span className="font-medium">Not set</span>
            <span className="block text-muted-foreground">
              Each key keeps its own default. This is what an upgraded gateway looks like until
              somebody chooses a level, and it changes nothing.
            </span>
          </span>
        </label>
      </div>

      {/* the failure this design introduces: a level that reads as in force while a key outranks
          it. Saying which key, rather than only that one exists, is what makes it actionable */}
      {overrides.length > 0 && (
        <p className="rounded-md border border-amber-500/40 bg-amber-500/5 px-3 py-2 text-base">
          {overrides.length === 1 ? "One key is" : `${overrides.length} keys are`} set explicitly and
          therefore {overrides.length === 1 ? "overrides" : "override"} the level:{" "}
          {overrides.map((o, i) => (
            <span key={o.key}>
              {i > 0 && ", "}
              <code className="font-mono">{o.key}</code> = {o.value || "(empty)"}
            </span>
          ))}
          . Clear {overrides.length === 1 ? "it" : "them"} to let the level decide.
        </p>
      )}

      {level === "verbose" && (
        <p className="rounded-md border border-amber-500/40 bg-amber-500/5 px-3 py-2 text-base">
          Verbose is on. It logs every routing decision and writes an event row per receipt — put it
          back to <strong>Problems</strong> once you have what you came for.
        </p>
      )}

      <p className="text-xs text-muted-foreground">
        Message content is <strong>not</strong> part of this.{" "}
        <code className="font-mono">smsg.cdr.body</code> and{" "}
        <code className="font-mono">print.msgs</code> store message text, destination numbers and
        bind passwords, and no level here switches either on — those are decisions about retaining
        customer data, not about how much detail you want today.
      </p>
    </div>
  );
}
