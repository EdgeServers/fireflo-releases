"use client";
import { useState } from "react";
import { ChevronDown, ChevronUp, Plus, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { ConditionEditor } from "./ConditionEditor";
import { FilterPicker } from "./FilterPicker";
import { ErrorNote, WarningNote } from "@/components/FormNotices";
import { useFilters } from "./useFilters";
import {
  TARGET_FUNCTIONS,
  TARGET_FUNCTION_MEANING,
  type RouteRule,
  type RouteTable,
  type RouteTableInput,
  type TargetWorker,
  type TargetFunction,
  describeRouteRule,
  routeTableWarnings,
  targetKind,
  validateRouteTable,
} from "@/lib/routing-types";

const BLANK: RouteRule = {
  id: null, target: "", copied: false, label: null, enabled: true, conditions: [], filters: [],
};

/**
 * One routing table and its ordered rules.
 *
 * <p>Deliberately the same shape as `ScopeForm`: an ordered list of rules, each with conditions and
 * named filters, reordered with the same controls. A rate rule and a routing rule differ in what
 * they carry — an amount against a target — and in nothing else, so an operator who has priced
 * something already knows how to route it.
 *
 * <p>What is different, and has to be, is that **the meaning of order depends on the target
 * function**. Under NORMAL the first match wins and position is the priority; under LCR the whole
 * table is scanned and order means nothing at all. The form says which of those is in force rather
 * than presenting one list that behaves two ways.
 */
export function RouteTableForm({
  initial,
  tableNames,
  workers,
  onSave,
  onCancel,
}: {
  initial: RouteTable | null;
  /** Every table name, for resolving a target and for spotting a chain into nothing. */
  tableNames: readonly string[];
  workers: readonly TargetWorker[];
  onSave: (input: RouteTableInput) => Promise<string | null>;
  onCancel: () => void;
}) {
  const isNew = initial == null;
  const { filters: library } = useFilters();
  const [name, setName] = useState(initial?.name ?? "");
  const [targetFunction, setTargetFunction] = useState<TargetFunction>(
    initial?.targetFunction ?? "NORMAL"
  );
  const [label, setLabel] = useState(initial?.label ?? "");
  const [enabled, setEnabled] = useState(initial?.enabled ?? true);
  const [rules, setRules] = useState<RouteRule[]>(initial?.rules ?? []);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const input: RouteTableInput = { name, targetFunction, label, enabled, rules };
  const warnings = routeTableWarnings(input, tableNames, workers);

  const set = (i: number, patch: Partial<RouteRule>) =>
    setRules(rules.map((r, n) => (n === i ? { ...r, ...patch } : r)));

  function move(i: number, by: number) {
    const next = [...rules];
    const to = i + by;
    if (to < 0 || to >= next.length) {
      return;
    }
    [next[i], next[to]] = [next[to], next[i]];
    setRules(next);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const invalid = validateRouteTable(input);
    if (invalid) {
      setError(invalid);
      return;
    }
    setSaving(true);
    setError("");
    const failure = await onSave(input);
    setSaving(false);
    if (failure) {
      setError(failure);
    }
  }

  //under LCR the rules are alternatives rather than a fallback chain, so the arrows would imply a
  //priority that does not exist
  const ordered = targetFunction === "NORMAL";

  return (
    <form onSubmit={submit} className="space-y-4">
      <Card>
        <CardHeader bar>
          <CardTitle className="text-lg">
            {isNew ? "New routing table" : `Routing table ${initial?.name}`}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <Field
              label="Name"
              htmlFor="rt-name"
              hint={isNew
                ? "What other tables chain into it by. Matched exactly, and fixed once created."
                : "Fixed once created — other tables chain into it by this."}
            >
              <Input id="rt-name" value={name} disabled={!isNew} placeholder="cheapest"
                className="font-mono" onChange={(e) => setName(e.target.value)} />
            </Field>
            <Field
              label="How it chooses"
              htmlFor="rt-fn"
              hint={TARGET_FUNCTION_MEANING[targetFunction]}
            >
              <Select id="rt-fn" value={targetFunction}
                onChange={(e) => setTargetFunction(e.target.value as TargetFunction)}>
                {TARGET_FUNCTIONS.map((f) => (
                  <option key={f} value={f}>
                    {f === "NORMAL" ? "In order — first match wins"
                      : f === "LCR" ? "Least cost — cheapest candidate wins"
                      : "Routing class — the message picks"}
                  </option>
                ))}
              </Select>
            </Field>
          </div>

          <Field label="Description" htmlFor="rt-label" hint="Optional — what this table is for.">
            <Input id="rt-label" value={label ?? ""} onChange={(e) => setLabel(e.target.value)} />
          </Field>

          <label className="flex items-start gap-2 text-base">
            <Checkbox checked={enabled} onChange={(e) => setEnabled(e.target.checked)} className="mt-0.5" />
            <span>
              Enabled
              <span className="block text-xs text-muted-foreground">
                A disabled table routes nothing. Anything chaining into it is left with nowhere to go.
              </span>
            </span>
          </label>

          {rules.map((rule, i) => {
            const kind = targetKind(rule.target, tableNames, workers);
            return (
              <div key={rule.id ?? `new-${i}`}
                className="space-y-3 border-t border-border pt-4 first:border-t-0">
                <div className="flex flex-wrap items-end gap-3">
                  <span className="pb-2 text-sm text-muted-foreground">
                    {ordered ? `#${i + 1}` : "·"}
                  </span>

                  <div className="min-w-48 flex-1">
                    <label className="mb-1.5 block text-sm text-muted-foreground" htmlFor={`rt-target-${i}`}>
                      Sends to
                    </label>
                    <Input
                      id={`rt-target-${i}`}
                      value={rule.target}
                      onChange={(e) => set(i, { target: e.target.value })}
                      placeholder="vendor1"
                      list="rt-targets"
                      className="font-mono"
                    />
                  </div>

                  <span className="pb-2">
                    {kind === "table" && <Badge variant="outline">routing table</Badge>}
                    {kind === "worker" && <Badge variant="outline">worker</Badge>}
                    {kind === "unknown" && <Badge variant="warning">not recognised</Badge>}
                    {kind === "disabled" && <Badge variant="warning">switched off</Badge>}
                  </span>

                  <div className="min-w-40 flex-1">
                    <label className="mb-1.5 block text-sm text-muted-foreground" htmlFor={`rt-note-${i}`}>
                      Note
                    </label>
                    <Input id={`rt-note-${i}`} value={rule.label ?? ""}
                      onChange={(e) => set(i, { label: e.target.value || null })}
                      placeholder="what this rule is for" />
                  </div>

                  {/* only meaningful when order means something: it is the "and keep scanning" flag */}
                  {ordered && (
                    <label className="flex items-center gap-1.5 pb-2 text-base">
                      <Checkbox checked={rule.copied}
                        onChange={(e) => set(i, { copied: e.target.checked })} />
                      Copy
                    </label>
                  )}

                  <label className="flex items-center gap-1.5 pb-2 text-base">
                    <Checkbox checked={rule.enabled}
                      onChange={(e) => set(i, { enabled: e.target.checked })} />
                    Active
                  </label>

                  <div className="flex gap-1 pb-1">
                    {ordered && (
                      <>
                        <Button type="button" variant="ghost" size="icon" className="h-8 w-8"
                          aria-label="Move up" disabled={i === 0} onClick={() => move(i, -1)}>
                          <ChevronUp className="h-4 w-4" />
                        </Button>
                        <Button type="button" variant="ghost" size="icon" className="h-8 w-8"
                          aria-label="Move down" disabled={i === rules.length - 1}
                          onClick={() => move(i, 1)}>
                          <ChevronDown className="h-4 w-4" />
                        </Button>
                      </>
                    )}
                    <Button type="button" variant="ghost" size="icon" className="h-8 w-8"
                      aria-label="Remove this rule"
                      onClick={() => setRules(rules.filter((_, n) => n !== i))}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <FilterPicker
                  chosen={rule.filters}
                  library={library}
                  onChange={(filters) => set(i, { filters })}
                />

                <ConditionEditor
                  conditions={rule.conditions}
                  filterCount={rule.filters.length}
                  onChange={(conditions) => set(i, { conditions })}
                />

                <p className="text-xs text-muted-foreground">
                  {describeRouteRule(rule, targetFunction, tableNames, workers)}
                </p>
              </div>
            );
          })}

          {/* one list for both the target input's datalist and the reader's sense of what exists */}
          <datalist id="rt-targets">
            {[...tableNames, ...workers.map((w) => w.name)].map((t) => <option key={t} value={t} />)}
          </datalist>

          <WarningNote warnings={warnings} />
          <ErrorNote error={error} />

          <p className="text-xs text-muted-foreground">
            A target is looked up as a routing table first and as a worker second, so a table and a
            worker sharing a name means the table wins.
          </p>
        </CardContent>
        <CardFooter bar className="gap-3">
          <Button type="submit" disabled={saving || !name.trim()}>
            {saving ? "Saving…" : isNew ? "Create table" : "Save changes"}
          </Button>
          <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
          <Button type="button" variant="outline" className="ml-auto gap-2"
            onClick={() => setRules([...rules, { ...BLANK }])}>
            <Plus className="h-4 w-4" />
            Add a rule
          </Button>
        </CardFooter>
      </Card>
    </form>
  );
}
