"use client";
import type { MetricFamily } from "@/lib/prometheus";
import { bytes, count, latency, ratio } from "@/lib/format";

/**
 * One group's raw readings, as a table.
 *
 * <p>Replaces a grid of fixed-width tiles, which were the wrong shape for this data: a tile gave a
 * single gauge the same width as a nine-row request breakdown, so every row was either mostly empty
 * or hiding a scrollbar, and no two numbers ever lined up with each other. A table is what a list of
 * name/value pairs already is.
 *
 * <p><strong>Two row shapes, chosen per family rather than uniformly.</strong> A measurement with one
 * unlabelled value is one row. A measurement with a breakdown becomes a `<tbody>` row group: a
 * spanning header naming it, then one row per label set.
 *
 * <p>Both shapes earn their place — measured against the live gateway, 26 of 67 families publish a
 * single sample, another 26 publish two, and the tail runs to nine. So the flat row is not a rare
 * special case to be folded away, and the group row is not the common one to optimise for; roughly
 * half the table is each.
 *
 * <p>`<tbody>` per family is also what makes this navigable to a screen reader — the grouping is in
 * the markup rather than implied by indentation, and it is what the shared `striped` utility bands
 * against: one measurement's whole breakdown is shaded as a unit rather than striped row by row,
 * which would split one subject into things that look separate.
 */
export function MetricsTable({ families }: { families: MetricFamily[] }) {
  return (
    //the card is fixed width; a label set like uri=/ops/health,method=GET is not. Scrolling the
    //table rather than the page is what keeps the rest of the layout still
    <div className="overflow-x-auto">
      <table className="striped w-full text-sm">
        <thead>
          <tr className="border-b border-border text-left text-muted-foreground">
            <th scope="col" className="py-1.5 pr-4 font-medium">Measurement</th>
            <th scope="col" className="py-1.5 pr-4 font-medium">Breakdown</th>
            <th scope="col" className="py-1.5 text-right font-medium">Value</th>
          </tr>
        </thead>

        {families.map((family) => {
          const samples = family.samples;
          const single = samples.length === 1 && !Object.keys(samples[0].labels).length;

          if (single) {
            return (
              <tbody key={family.name}>
                <tr className="border-b border-border/50">
                  <th scope="row" className="py-1.5 pr-4 text-left font-normal align-top">
                    <Name family={family} />
                  </th>
                  <td className="py-1.5 pr-4 text-muted-foreground">—</td>
                  <td className="py-1.5 text-right font-medium tabular-nums">
                    {renderMetricValue(family.name, samples[0].value)}
                  </td>
                </tr>
              </tbody>
            );
          }

          return (
            <tbody key={family.name} className="border-b border-border/50">
              <tr>
                {/* the group's own heading row, spanning the table. scope="colgroup" rather than
                    "row": it labels the rows beneath it, not the cells beside it */}
                <th scope="colgroup" colSpan={3} className="pt-3 pb-1 text-left font-normal">
                  <Name family={family} />
                </th>
              </tr>
              {samples.map((sample, i) => (
                <tr key={i} className="border-t border-border/30">
                  <td className="py-1.5 pr-4" />
                  <td className="py-1.5 pr-4">
                    <span className="flex flex-wrap gap-x-3 gap-y-0.5 text-muted-foreground">
                      {Object.entries(sample.labels).map(([k, v]) => (
                        <span key={k} className="whitespace-nowrap">
                          <span className="text-muted-foreground/60">{k}=</span>
                          {v}
                        </span>
                      ))}
                      {!Object.keys(sample.labels).length && <span>—</span>}
                    </span>
                  </td>
                  <td className="py-1.5 text-right font-medium tabular-nums whitespace-nowrap">
                    {renderMetricValue(family.name, sample.value)}
                  </td>
                </tr>
              ))}
            </tbody>
          );
        })}
      </table>
    </div>
  );
}

/** The gateway's own name for a measurement, and its own description of it. */
function Name({ family }: { family: MetricFamily }) {
  return (
    <>
      <code className="font-medium">{family.name}</code>
      {family.help && (
        //no longer clamped: a table row can be as tall as its text, which the fixed-height tile
        //this replaced could not, so the only explanation of what a number means survives intact
        <span className="block text-xs font-normal text-muted-foreground">{family.help}</span>
      )}
    </>
  );
}

/**
 * Units inferred from the name, because the exposition format does not carry them.
 *
 * <p>Micrometer's naming convention is the only signal available: a name ending `_bytes` is bytes,
 * `_seconds` is seconds. Anything else is printed plainly rather than guessed at.
 */
export function renderMetricValue(name: string, value: number): string {
  if (!Number.isFinite(value)) {
    return value > 0 ? "∞" : "—";
  }
  if (name.includes("_bytes") || name.endsWith("_size")) {
    return bytes(value);
  }
  if (name.includes("_seconds") && !name.endsWith("_count")) {
    return latency(value);
  }
  if (name.endsWith("_usage") || name.endsWith("_ratio") || name.endsWith("_overhead")) {
    return ratio(value);
  }
  return Number.isInteger(value) ? count(value) : value.toFixed(3);
}

/**
 * Narrows a group to what matches a query, or drops it entirely.
 *
 * <p>Two levels, because the two are asked for differently. Matching a family's <em>name or help</em>
 * keeps all of its samples — "http" means show me the HTTP measurements, all of them. Matching only
 * a <em>label</em> keeps just the rows that matched — "/ops/health" means show me that endpoint, not
 * every endpoint in a family that happens to contain it.
 *
 * <p>Case-insensitive substring, not a regex: this is a filter box on a diagnostic table, and a
 * half-typed regex would empty the screen rather than narrow it.
 */
export function filterFamilies(families: MetricFamily[], query: string): MetricFamily[] {
  const q = query.trim().toLowerCase();
  if (!q) {
    return families;
  }
  const out: MetricFamily[] = [];
  for (const family of families) {
    if (family.name.toLowerCase().includes(q) || (family.help ?? "").toLowerCase().includes(q)) {
      out.push(family);
      continue;
    }
    const samples = family.samples.filter((sample) =>
      Object.entries(sample.labels).some(
        ([k, v]) => k.toLowerCase().includes(q) || String(v).toLowerCase().includes(q)
      )
    );
    if (samples.length) {
      out.push({ ...family, samples });
    }
  }
  return out;
}
