"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Antenna, Globe, Pencil, Plus, TriangleAlert, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RateRuleLines } from "./RateRuleLines";
import { DangerAction } from "./DangerAction";
import { ScopeForm } from "./ScopeForm";
import { useProductCatalogue } from "./useProducts";
import { useRates } from "./useRates";
import { GatewayIgnores } from "./GatewayIgnores";
import { UnratedPreflight } from "./UnratedPreflight";
import { useHealth } from "./useHealth";
import { readsRatesFromDatabase } from "@/lib/health-types";
import { type RateRule, type RateRuleInput, type ScopeKind, type ScopeSummary, scopeKind } from "@/lib/rate-types";

type Editing = { scope: string; rules: RateRuleInput[]; isNew: boolean } | null;

/** One empty row, so a form asking for a price opens with somewhere to type one. */
const BLANK_RULE: RateRuleInput = {
  id: null,
  amount: "",
  product: null,
  currency: null,
  label: null,
  enabled: true,
  conditions: [],
  filters: [],
};

/**
 * Pricing: what we pay each vendor, and what each account pays us.
 *
 * <p>Those are the same table. `app_rate_rule.scope` is one column holding either a vendor instance
 * name or an account id, and nothing in the schema distinguishes them — the gateway tells them apart
 * only by which lookup asks. So this page groups them, because a list that mixed them would be a
 * list where our costs and our revenue looked identical.
 *
 * <p>The third group is the one that matters: a scope matching neither. Those rules load fine and
 * match nothing, which for a cost scope means every message through that vendor has an unknown cost
 * and a margin that looks wonderful. It is styled to be impossible to scroll past.
 */
export function PricingClient() {
  const { scopes, known, error, loading, busy, loadScope, saveScope, removeScope } = useRates();
  const { health } = useHealth();
  const [editing, setEditing] = useState<Editing>(null);
  const [expanded, setExpanded] = useState<Record<string, RateRule[]>>({});

  //the shared hook rather than a fetch of its own, which offered `app_product` rows only. A product
  //named by a login or a rule without a catalogue row -- the normal state of anything imported, and
  //the likeliest thing to be pricing -- was missing from the dropdown while plainly in use elsewhere
  const catalogue = useProductCatalogue();

  const expand = useCallback(
    async (scope: string) => {
      if (expanded[scope]) {
        setExpanded((e) => {
          const next = { ...e };
          delete next[scope];
          return next;
        });
        return;
      }
      const rules = await loadScope(scope);
      if (rules) {
        setExpanded((e) => ({ ...e, [scope]: rules }));
      }
    },
    [expanded, loadScope]
  );

  //`?scope=&product=` opens this page on the thing that sent you here. The product page links in
  //with both, because a link that lands you on a list which hides its sell-side section when empty
  //-- exactly when you need it -- is how "Add pricing" became a button that appeared to do nothing
  const opened = useRef(false);
  useEffect(() => {
    if (opened.current) {
      return;
    }
    opened.current = true;
    const params = new URLSearchParams(window.location.search);
    const scope = params.get("scope");
    if (!scope) {
      return;
    }
    const product = params.get("product");
    void (async () => {
      //an existing scope is opened for editing rather than recreated: a create would replace it,
      //and this URL can be bookmarked long after the scope was set up
      const rules = await loadScope(scope);
      setEditing(
        rules?.length
          ? { scope, rules, isNew: false }
          : { scope, isNew: true, rules: [{ ...BLANK_RULE, product }] }
      );
    })();
  }, [loadScope]);

  async function edit(scope: string) {
    const rules = await loadScope(scope);
    if (rules) {
      setEditing({ scope, rules, isNew: false });
    }
  }

  const fromDatabase = readsRatesFromDatabase(health);
  const nothingStored = fromDatabase === true && !scopes.length;

  if (editing) {
    return (
      <ScopeForm
        scope={editing.scope}
        initial={editing.rules}
        known={known}
        catalogue={catalogue}
        isNew={editing.isNew}
        onSave={async (scope, rules, confirmed) => {
          const failure = await saveScope(scope, rules, confirmed, editing.isNew);
          if (!failure) {
            setEditing(null);
            setExpanded({});
          }
          return failure;
        }}
        onCancel={() => setEditing(null)}
      />
    );
  }

  const groups: { kind: ScopeKind; title: string; blurb: string; icon: typeof Antenna }[] = [
    { kind: "cost", title: "What we pay", blurb: "Per-message cost from each vendor.", icon: Antenna },
    { kind: "price", title: "What we charge", blurb: "Per-message price for each account.", icon: Wallet },
    //between the two named sides and the unknown one, because that is where it sits in meaning: a
    //real price, owned by no single account
    {
      kind: "default",
      title: "What everyone pays",
      blurb: "Applied to any account with no pricing of its own. An account's own rule always wins.",
      icon: Globe,
    },
    { kind: "unknown", title: "Unknown scope", blurb: "", icon: TriangleAlert },
  ];

  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-base text-muted-foreground">
          The first rule that matches wins, within a scope and a product.
        </p>
        <Button
          //with a row in it. Opening empty let a save through that stored nothing at all and
          //answered 200 -- the list came back unchanged and the button looked broken
          onClick={() => setEditing({ scope: "", rules: [{ ...BLANK_RULE }], isNew: true })}
          className="gap-2"
        >
          <Plus className="h-4 w-4" />
          Add pricing
        </Button>
      </div>

      {/* ordered deliberately: nothing below matters if the gateway is not reading any of it */}
      <GatewayIgnores domain="rates" />

      {/* what the missing half of this page costs, in messages. A price that has not been set is
          invisible here by nature -- the scope simply is not listed -- so the only way to see the
          gap is to count the traffic falling through it */}
      <UnratedPreflight />

      {nothingStored && (
        <Card className="border-destructive">
          <CardContent className="py-4 text-base text-destructive">
            <strong>The gateway is reading pricing from this database, and there is none.</strong>{" "}
            There is no fall back to the file — every message is being accepted with no price and no
            cost. Import the existing file with
            <code className="mx-1 text-sm">scripts/fireflo import rates</code>, or add pricing here,
            now.
          </CardContent>
        </Card>
      )}

      {error && (
        <Card>
          <CardContent className="py-4 text-base text-destructive">{error}</CardContent>
        </Card>
      )}

      {!scopes.length && !nothingStored && (
        <div className="rounded-xl border border-border p-12 text-center text-muted-foreground">
          {loading ? "Loading…" : "No pricing stored yet"}
        </div>
      )}

      {/* the two sides of the same message, side by side. They are read against each other — what a
          vendor charges us and what we charge for it — and stacked full width the comparison was a
          scroll apart, with each card only ever one header row tall.

          `items-start` so an empty or short side does not stretch, and `lg` rather than `xl` because
          a collapsed ScopeCard is a name and a rule count and needs very little width */}
      <div className="grid items-start gap-6 lg:grid-cols-2">
        {groups.filter((g) => g.kind === "cost" || g.kind === "price").map((group) => (
          <ScopeGroup
            key={group.kind}
            group={group}
            scopes={scopes.filter((s) => scopeKind(s.scope, known) === group.kind)}
            expanded={expanded}
            busy={busy}
            onExpand={expand}
            onEdit={edit}
            onRemove={removeScope}
          />
        ))}
      </div>

      {/* full width, and NOT halved into a third column: neither is the counterpart of anything.
          "What everyone pays" is a platform default rather than a side of a trade, and the unknown
          group carries a destructive warning that would end up in a corner */}
      {groups.filter((g) => g.kind === "default" || g.kind === "unknown").map((group) => (
        <ScopeGroup
          key={group.kind}
          group={group}
          scopes={scopes.filter((s) => scopeKind(s.scope, known) === group.kind)}
          expanded={expanded}
          busy={busy}
          onExpand={expand}
          onEdit={edit}
          onRemove={removeScope}
        />
      ))}
    </>
  );
}

/** One titled group of scopes. Renders nothing at all when the group is empty. */
function ScopeGroup({ group, scopes, expanded, busy, onExpand, onEdit, onRemove }: {
  group: { kind: ScopeKind; title: string; blurb: string; icon: typeof Antenna };
  scopes: ScopeSummary[];
  expanded: Record<string, RateRule[]>;
  busy: string | null;
  onExpand: (scope: string) => void;
  onEdit: (scope: string) => void;
  onRemove: (scope: string) => void;
}) {
  if (!scopes.length) {
    return null;
  }
  return (
    <section className="space-y-3">
      <div className="flex items-center gap-2">
        <group.icon
          className={`h-4 w-4 ${group.kind === "unknown" ? "text-destructive" : "text-muted-foreground"}`}
        />
        <h2 className="text-base font-semibold">{group.title}</h2>
        <span className="text-sm text-muted-foreground">{group.blurb}</span>
      </div>

      {group.kind === "unknown" && (
        <Card className="border-destructive">
          <CardContent className="py-3 text-base text-destructive">
            These scopes name neither a configured vendor nor an account that has sent. Their rules
            load and match nothing — for a vendor that means every message through it has no recorded
            cost, and the margin on it will look better than it is.
          </CardContent>
        </Card>
      )}

      {scopes.map((s) => (
        <ScopeCard
          key={s.scope}
          summary={s}
          kind={group.kind}
          rules={expanded[s.scope]}
          busy={busy === s.scope}
          onToggle={() => onExpand(s.scope)}
          onEdit={() => onEdit(s.scope)}
          removeConsequence={
            `All ${s.rules} rule(s) for '${s.scope}' go. `
            + (group.kind === "cost"
              ? "Messages through it will have no recorded cost, so margin on them becomes unknown."
              : "Messages for it will have no price.")
          }
          onRemove={() => onRemove(s.scope)}
        />
      ))}
    </section>
  );
}

function ScopeCard({
  summary,
  kind,
  rules,
  busy,
  onToggle,
  onEdit,
  onRemove,
  removeConsequence,
}: {
  summary: ScopeSummary;
  kind: ScopeKind;
  rules: RateRule[] | undefined;
  busy: boolean;
  onToggle: () => void;
  onEdit: () => void;
  onRemove: () => void;
  /** What deleting this scope costs, in the caller's words -- cost and price lose different things. */
  removeConsequence: string;
}) {
  return (
    <Card className={kind === "unknown" ? "border-destructive/40" : undefined}>
      <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-3 pb-3">
        <div className="min-w-0">
          <CardTitle className="text-base font-medium">
            {/* where a scope is edited scope-complete: an account page for a price scope, the vendor
                card for a cost one. An unknown scope has neither, and saying so by not linking is
                more honest than a link to a page that would have to invent which one it meant */}
            {kind === "unknown" ? (
              summary.scope
            ) : (
              <Link
                href={kind === "cost" ? "/cp/vendors" : `/cp/accounts/${encodeURIComponent(summary.scope)}`}
                className="hover:underline"
              >
                {summary.scope}
              </Link>
            )}
          </CardTitle>
          <p className="mt-0.5 text-sm text-muted-foreground">
            {summary.rules} rule{summary.rules === 1 ? "" : "s"}
            {summary.enabled < summary.rules && `, ${summary.rules - summary.enabled} retired`}
            {!!summary.products.length && ` · ${summary.products.join(", ")}`}
          </p>
        </div>
        <div className="flex shrink-0 gap-2">
          <Button variant="ghost" size="sm" onClick={onToggle}>
            {rules ? "Hide rules" : "Show rules"}
          </Button>
          <Button variant="outline" size="sm" onClick={onEdit} className="gap-1.5">
            <Pencil className="h-3.5 w-3.5" />
            Edit
          </Button>
          <DangerAction
            label="Delete"
            confirmLabel="Delete these rules"
            consequence={removeConsequence}
            busy={busy}
            onConfirm={onRemove}
          />
        </div>
      </CardHeader>

      {rules && (
        <CardContent className="pt-0">
          <RateRuleLines rules={rules} />
        </CardContent>
      )}
    </Card>
  );
}
