"use client";
import { usePathname } from "next/navigation";

/**
 * Title and subtitle for the header bars, derived from the route.
 *
 * <p>The `/cp` prefix is stripped once, at the top, rather than written into all nine tests below.
 * This chain is about which operator SECTION you are in; `/cp` is where the panel happens to be
 * mounted, which is a deployment fact and not part of that question.
 *
 * <p>It is also the failure worth designing against. Every branch here falls through to "Overview",
 * so a prefix these tests do not know about does not raise anything — it silently titles every page
 * in the panel "Overview / Traffic and delivery across the gateway" and looks like a styling bug.
 */
export function usePageMeta(): { title: string; subtitle?: string } {
  //|| "/" so that /cp itself, whose remainder is the empty string, still reaches the default below
  const pathname = usePathname().replace(/^\/cp/, "") || "/";

  if (pathname.startsWith("/vendors")) {
    return { title: "Vendors", subtitle: "Connections out, with what each one carried" };
  }
  if (pathname.startsWith("/servers")) {
    return { title: "Servers", subtitle: "Listeners customers bind to" };
  }
  if (pathname.startsWith("/health")) {
    return { title: "Live health", subtitle: "Binds, queues and throughput, read from the running gateway" };
  }
  if (pathname.startsWith("/metrics")) {
    return {
      title: "Runtime",
      subtitle: "Memory, CPU and request handling inside the gateway process",
    };
  }
  if (pathname.startsWith("/products")) {
    return { title: "Products", subtitle: "The tariffs a customer's bind can ask for by system_type" };
  }
  if (pathname.startsWith("/pricing")) {
    return { title: "Pricing", subtitle: "What we pay each vendor, and what each account pays us" };
  }
  if (pathname.startsWith("/cdrs")) {
    return {
      title: "Messages",
      subtitle: "Individual call records, with filters and downloadable exports",
    };
  }
  if (pathname.startsWith("/accounts")) {
    return { title: "Accounts", subtitle: "Who is sending, what they spend, and their credit" };
  }
  if (pathname.startsWith("/revenue")) {
    return { title: "Revenue", subtitle: "Cost, price and margin by account and product" };
  }
  //the fall-through this file's own header warns about, caught in the wild: /cp/diagnostics has
  //been titled "Overview / Traffic and delivery across the gateway" since the page was added
  if (pathname.startsWith("/diagnostics")) {
    return {
      title: "Diagnostics",
      subtitle: "Logs and configuration read from the machine running the gateway",
    };
  }
  return { title: "Overview", subtitle: "Traffic and delivery across the gateway" };
}
