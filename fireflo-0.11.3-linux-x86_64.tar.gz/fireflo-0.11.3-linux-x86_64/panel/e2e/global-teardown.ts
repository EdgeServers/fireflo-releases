/**
 * Stops what setup started — by the PIDs recorded in e2e/.run/state.json and nothing else. Never
 * a `pkill -f`: jasmin holds 2775 on this box and a pattern kill is how it has been taken down
 * before. Each PID is checked to still be the kind of process we spawn before it is signalled.
 */
import type { FullConfig } from "@playwright/test";
import { stopTracked } from "./fixtures/process";
import { readState, updateState } from "./fixtures/state";

export default async function globalTeardown(_config: FullConfig) {
  if (process.env.E2E_LISTING === "1" || process.env.E2E_NO_RIG === "1") return;
  if (process.env.E2E_KEEP_RIG === "1") {
    console.log("[e2e teardown] E2E_KEEP_RIG=1: leaving the rig running (PIDs in e2e/.run/state.json)");
    return;
  }
  const state = readState();
  for (const { name, pid } of [...state.pids].reverse()) {
    console.log(`[e2e teardown] ${await stopTracked(name, pid)}`);
  }
  updateState((s) => { s.pids = []; s.gatewayUp = false; });
}
