/**
 * `tc()` — the contract between the sheet and the suite.
 *
 * Every test case in docs/26-qa-test-plan-0.11.xlsx is declared exactly once, by its sheet id:
 *
 *   test(...tc("TC-17.01.01-P01", "Correct credentials land on /cp"), async ({ page, tcx }) => { … });
 *   test(...tc("TC-05.03.01-P01", "…", { requires: ["edgesmsc", "trace"] }), async (…) => { … });
 *   test(...tc.manual("TC-24.02.01-P01", "…", "needs a fresh host and the installer"));
 *   test(...tc.fixme("TC-…", "…", "known defect #123"));
 *   test(...tc.todo("TC-…", "…"));
 *
 * `tc(…)` answers the `[title, details]` pair Playwright's `test()` takes, so the spec file itself is
 * what calls `test` — Playwright records the caller of `test()` as the test's location, and a
 * wrapper would put every one of the 643 cases in this file. The spread is the price of a report
 * that groups by story.
 *
 * The id is checked against the committed catalog at declaration time, so a typo throws before
 * anything is listed; the catalog check (`npm run e2e:check`) asserts the reverse: every catalog id
 * is declared exactly once with the sheet's title.
 *
 * Skips are decided at declaration and carried in the annotations: `manual`, `todo`, `fixme`, and
 * `blocked` (a `requires` capability the run lacks — no EdgeSmsc in mode B, no panel variants). The
 * `tcGuard` auto-fixture in e2e/fixtures reads them and skips before any other fixture is set up,
 * so a Blocked case never opens a browser. The reporter maps each kind to the sheet's Status.
 *
 * `tcx.note(text)` in a body attaches the observed value the reporter writes into "Actual result":
 * the number the oracle produced, not prose.
 */
import { readFileSync } from "node:fs";
import path from "node:path";
import type { TestDetails } from "@playwright/test";
import { capabilities } from "../fixtures/env";
import type { Capability } from "../fixtures/env";

export type TcKind = "auto" | "manual" | "blocked" | "fixme" | "todo";

export interface CatalogEntry {
  id: string;
  scenario: string;
  story: string;
  epic: string;
  type: "Positive" | "Negative";
  title: string;
  priority: string;
  component: string;
}

interface Catalog { tcs: CatalogEntry[] }

const catalog: Catalog = JSON.parse(readFileSync(path.join(__dirname, "tc-catalog.json"), "utf8"));
const byId = new Map(catalog.tcs.map((t) => [t.id, t]));

/** ids declared in this process — a duplicate is a copy-paste that would double-report one TC */
const declared = new Set<string>();

export interface TcOptions {
  /** rig capabilities this TC needs; absent ones make it Blocked with a reason, never a failure */
  requires?: Capability[];
  tags?: string[];
}

/** what `test(…)` takes before the body */
export type TcHead = readonly [title: string, details: TestDetails];
/** a head plus a no-op body, for the kinds that never run */
export type TcHeadWithBody = readonly [title: string, details: TestDetails, body: () => Promise<void>];

function lookup(id: string): CatalogEntry {
  const entry = byId.get(id);
  if (!entry) throw new Error(`tc(): ${id} is not in tc-catalog.json — regenerate the catalog or fix the id`);
  if (declared.has(id)) throw new Error(`tc(): ${id} is declared twice`);
  declared.add(id);
  return entry;
}

function titleOf(entry: CatalogEntry, title: string): string {
  if (title !== entry.title) {
    // the catalog check turns this into a failure; the warning is so the author sees it first
    console.warn(`tc(): ${entry.id} title differs from the sheet:\n  spec:  ${title}\n  sheet: ${entry.title}`);
  }
  return `${entry.id} ${entry.title}`;
}

function details(entry: CatalogEntry, kind: TcKind, reason: string | undefined, extraTags: string[]): TestDetails {
  const annotation = [
    { type: "tc", description: entry.id },
    { type: "tc-kind", description: kind },
    { type: "epic", description: entry.epic },
    { type: "story", description: entry.story },
    { type: "scenario", description: entry.scenario },
    ...(reason ? [{ type: "tc-reason", description: reason }] : []),
  ];
  const tag = [
    `@${entry.epic}`, `@${entry.story}`, `@${entry.scenario}`,
    `@${entry.priority}`, `@${entry.type.toLowerCase()}`,
    ...(kind === "auto" ? [] : [`@${kind}`]),
    ...extraTags,
  ];
  return { tag, annotation };
}

const noop = async () => {};

/** An automated test case: `test(...tc(id, title, opts?), body)`. */
export function tc(id: string, title: string, opts: TcOptions = {}): TcHead {
  const entry = lookup(id);
  const caps = capabilities();
  const absent = (opts.requires ?? []).filter((c) => !caps.has(c));
  if (absent.length) {
    return [titleOf(entry, title), details(entry, "blocked", `needs ${absent.join(", ")} (not available in this run)`, opts.tags ?? [])];
  }
  return [titleOf(entry, title), details(entry, "auto", undefined, opts.tags ?? [])];
}

/** A test case that stays manual; listed so the sheet shows Not run with the reason. */
tc.manual = function manual(id: string, title: string, reason: string): TcHeadWithBody {
  const entry = lookup(id);
  return [titleOf(entry, title), details(entry, "manual", reason, []), noop];
};

/** Automated in principle, skipped for a reason on our side (a known defect, a fixture not built). */
tc.fixme = function fixme(id: string, title: string, reason: string): TcHeadWithBody {
  const entry = lookup(id);
  return [titleOf(entry, title), details(entry, "fixme", reason, []), noop];
};

/** The scaffold's placeholder; counted, reported as Not run, never green. */
tc.todo = function todo(id: string, title: string): TcHeadWithBody {
  const entry = lookup(id);
  return [titleOf(entry, title), details(entry, "todo", "not automated yet", []), noop];
};
