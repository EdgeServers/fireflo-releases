/**
 * Polling helpers. Playwright's `expect.poll` covers most of the suite; these are for the places
 * that are not inside an expect — a fixture waiting for a port, a setup step waiting for a bind.
 */
type Falsy = undefined | null | false | 0 | "";

/**
 * Poll `probe` until it answers something truthy, and return that. Sync or async probes; a throwing
 * probe counts as "not yet" and its message is what the timeout error carries.
 */
export async function waitFor<T>(
  probe: () => T | Falsy | Promise<T | Falsy>,
  opts: { timeoutMs?: number; intervalMs?: number; what?: string } = {},
): Promise<T> {
  const timeoutMs = opts.timeoutMs ?? 15_000;
  const intervalMs = opts.intervalMs ?? 250;
  const started = Date.now();
  let last: unknown;
  for (;;) {
    try {
      const v = await probe();
      if (v) return v as T;
      last = v;
    } catch (e) {
      last = e;
    }
    if (Date.now() - started > timeoutMs) {
      const detail = last instanceof Error ? last.message : String(last);
      throw new Error(`timed out after ${timeoutMs}ms waiting for ${opts.what ?? "condition"} (last: ${detail})`);
    }
    await sleep(intervalMs);
  }
}

export function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

/** A TCP port answers a connect. */
export async function waitForPort(host: string, port: number, timeoutMs = 15_000): Promise<void> {
  const net = await import("node:net");
  await waitFor(
    () =>
      new Promise<boolean>((resolve) => {
        const s = net.createConnection({ host, port });
        s.once("connect", () => { s.destroy(); resolve(true); });
        s.once("error", () => { s.destroy(); resolve(false); });
      }),
    { timeoutMs, what: `${host}:${port} to accept a connection` },
  );
}

/** A TCP port refuses a connect (something was stopped). */
export async function waitForPortClosed(host: string, port: number, timeoutMs = 15_000): Promise<void> {
  const net = await import("node:net");
  await waitFor(
    () =>
      new Promise<boolean>((resolve) => {
        const s = net.createConnection({ host, port });
        s.once("connect", () => { s.destroy(); resolve(false); });
        s.once("error", () => { s.destroy(); resolve(true); });
      }),
    { timeoutMs, what: `${host}:${port} to close` },
  );
}
