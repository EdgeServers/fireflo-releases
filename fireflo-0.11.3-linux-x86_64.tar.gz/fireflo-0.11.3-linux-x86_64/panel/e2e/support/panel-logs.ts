/**
 * The panel's own audit files, read straight off the run directory: `operator-<UTC day>.jsonl`
 * (every operator act) and `auth-failed-<UTC day>.jsonl` (refused sign-ins on both surfaces), both
 * under e2e/.run/panel-data/access — see lib/access-log.ts for the writer and lib/data-dir.ts for
 * why the directory sits beside the exports.
 */
import { existsSync, readdirSync, readFileSync } from "node:fs";
import path from "node:path";
import { e2eEnv } from "../fixtures/env";
import { waitFor } from "./wait";

export interface OperatorLine {
  ts: string;
  event: string;
  actor?: string;
  ip?: string | null;
  ua?: string | null;
  detail?: Record<string, unknown>;
  [k: string]: unknown;
}

export interface AuthFailedLine {
  ts: string;
  surface: "panel" | "portal";
  reason: string;
  triedAs?: string | null;
  ip?: string | null;
  [k: string]: unknown;
}

export function accessDir(): string {
  return path.join(e2eEnv().runDir, "panel-data", "access");
}

function linesOf<T>(prefix: string, since: Date): T[] {
  const dir = accessDir();
  if (!existsSync(dir)) return [];
  const out: T[] = [];
  for (const name of readdirSync(dir).filter((n) => n.startsWith(`${prefix}-`) && n.endsWith(".jsonl")).sort()) {
    for (const raw of readFileSync(path.join(dir, name), "utf8").split("\n")) {
      if (!raw.trim()) continue;
      try {
        const line = JSON.parse(raw) as T & { ts: string };
        if (new Date(line.ts).getTime() >= since.getTime() - 1000) out.push(line);
      } catch { /* a partial line still being written */ }
    }
  }
  return out;
}

export const panelLog = {
  /** a timestamp to pass as `since`; take it before the act being tested */
  mark: () => new Date(),
  operator: (since: Date) => linesOf<OperatorLine>("operator", since),
  authFailed: (since: Date) => linesOf<AuthFailedLine>("auth-failed", since),
  /** wait for an operator line matching `pred` written after `since` */
  waitOperator(since: Date, pred: (l: OperatorLine) => boolean, timeoutMs = 10_000) {
    return waitFor(() => panelLog.operator(since).find(pred), { timeoutMs, intervalMs: 200, what: "an operator audit line" });
  },
  waitAuthFailed(since: Date, pred: (l: AuthFailedLine) => boolean, timeoutMs = 10_000) {
    return waitFor(() => panelLog.authFailed(since).find(pred), { timeoutMs, intervalMs: 200, what: "an auth-failed line" });
  },
};
