/**
 * Playwright tags the suite filters on. `@EP-05` and `@US-05.03` are added by `tc()` from the id,
 * so `npm run e2e:epic -- @EP-05` needs no list. The ones here are hand-applied.
 */
export const SLOW = "@slow";        // waits on a real timer (reconnect backoff, expiry)
export const LOAD = "@load";        // volume-shaped; scaled by E2E_LOAD_SCALE
export const SERIAL = "@serial";    // must not share a worker with its neighbours (rate limiters)
