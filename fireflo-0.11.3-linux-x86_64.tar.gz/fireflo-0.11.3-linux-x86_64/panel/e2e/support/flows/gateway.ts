/**
 * Gateway-side flows shared by EP-01..16: reading /ops/health for a listener's sessions, scraping a
 * Prometheus counter, and the one-message round trip (bind → submit → receipt → CDR) that half the
 * sheet's oracles start from.
 */
import { expect } from "@playwright/test";
import type { Db } from "../../fixtures/db";
import { e2eEnv } from "../../fixtures/env";
import { ops } from "../../fixtures/gateway";
import type { HealthSnapshot } from "../../fixtures/gateway";
import { BASELINE } from "../../fixtures/seed";
import { connectEsme } from "../../fixtures/smpp";
import type { ConnectOptions, Esme, SubmitOptions } from "../../fixtures/smpp";
import { waitFor } from "../wait";

export interface HealthWorker {
  name: string;
  type: string;
  accepting: boolean;
  paused: boolean;
  suspended_manually: boolean;
  suspended_automatically: boolean;
  queue_depth: number;
  retry_queue_depth: number;
  sessions: HealthSession[];
  [k: string]: unknown;
}

export interface HealthSession {
  session_id: number | null;
  bind_type: string | null;
  bound: boolean;
  role: string | null;
  host: string | null;
  system_id: string | null;
  account: string | null;
  system_type: string | null;
  bound_seconds: number | null;
  [k: string]: unknown;
}

export type Health = Omit<HealthSnapshot, "workers"> & { workers: HealthWorker[] };

export async function health(): Promise<Health> {
  const res = await ops().health();
  expect(res.status, `GET /ops/health → ${res.status}`).toBe(200);
  //the ops routes answer an ApiEnvelope: the snapshot sits under `data`
  const raw = res.body as unknown as { data?: Health } & Health;
  const body = (raw.data ?? raw) as Health;
  return { ...body, workers: Array.isArray(body.workers) ? body.workers : [] };
}

export async function worker(name: string): Promise<HealthWorker> {
  const h = await health();
  const w = h.workers.find((x) => x.name === name || x.name === `smppserver.${name}` || x.name === `smppclient.${name}`);
  if (!w) throw new Error(`/ops/health has no worker ${name}; has [${h.workers.map((x) => x.name).join(", ")}] — body keys ${Object.keys(h).join(",")}: ${JSON.stringify(h).slice(0, 400)}`);
  return w;
}

/** sessions bound on a listener for one system id */
export async function sessionsOf(listener: string, systemId?: string): Promise<HealthSession[]> {
  const w = await worker(listener);
  return (w.sessions ?? []).filter((s) => s.bound && (!systemId || s.system_id === systemId));
}

export function waitSessions(listener: string, systemId: string, n: number, timeoutMs = 15_000): Promise<HealthSession[]> {
  return waitFor(async () => { const s = await sessionsOf(listener, systemId); return s.length === n ? s : undefined; }, { timeoutMs, intervalMs: 500, what: `${n} bound session(s) of ${systemId} on ${listener}` });
}

/** A Prometheus counter/gauge from /q/metrics (management port), summed over the samples matching `tags`. */
export async function metric(name: string, tags: Record<string, string> = {}): Promise<number | null> {
  const env = e2eEnv();
  const res = await fetch(`${env.gatewayOpsUrl}/q/metrics`);
  if (!res.ok) throw new Error(`GET /q/metrics → ${res.status}`);
  const text = await res.text();
  let found = false;
  let sum = 0;
  for (const line of text.split("\n")) {
    if (!line.startsWith(name)) continue;
    const m = /^([a-zA-Z_:][a-zA-Z0-9_:]*)(\{[^}]*\})?\s+([-+0-9.eE]+)/.exec(line);
    if (!m || m[1] !== name) continue;
    const labels = m[2] ?? "";
    if (Object.entries(tags).every(([k, v]) => labels.includes(`${k}="${v}"`))) { found = true; sum += Number(m[3]); }
  }
  return found ? sum : null;
}

export const BIND_REFUSED_METRIC = "fireflo_smpp_bind_refused_total";

/** The baseline login of account A, bound TRX to the main listener. */
export function bindA(extra: Partial<ConnectOptions> = {}): Promise<Esme> {
  return connectEsme({ ...BASELINE.logins.a, ...extra });
}

/** Submit one message and wait for its cdr_submit row; answers the gateway message id. */
export async function sendAndRecord(esme: Esme, db: Db, opts: SubmitOptions = {}, timeoutMs = 20_000): Promise<{ messageId: string; status: number }> {
  const r = await esme.submit(opts);
  expect(r.status, `submit_sm_resp 0x${r.status.toString(16)}`).toBe(0);
  const id = r.messageId!;
  await db.waitForRow("SELECT 1 FROM cdr_submit WHERE gateway_msg_id = $1", [id], { timeoutMs, what: `cdr_submit for ${id}` });
  return { messageId: id, status: r.status };
}

/** Wait for the message's terminal record. */
export async function waitFinal(db: Db, messageId: string, timeoutMs = 30_000) {
  return db.waitForRow<{ final_state: string; dlr_state: string | null; err_code: string | null; vendor_err_code: string | null }>(
    "SELECT final_state, dlr_state, err_code, vendor_err_code FROM cdr_final WHERE gateway_msg_id = $1 ORDER BY id DESC LIMIT 1", [messageId], { timeoutMs, what: `cdr_final for ${messageId}` });
}
