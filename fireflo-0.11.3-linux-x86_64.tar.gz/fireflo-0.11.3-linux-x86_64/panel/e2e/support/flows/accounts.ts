/**
 * Operator-panel account flows shared by EP-18, EP-19 (approvals) and EP-21 (reports): opening the
 * catalogue and an account's tabs, and the Add-login form.
 */
import { expect } from "@playwright/test";
import type { Page } from "@playwright/test";

export type AccountTab = "" | "settings" | "logins" | "approvals" | "billing" | "tariff" | "statement";

export async function openAccountsPage(page: Page): Promise<void> {
  await page.goto("/cp/accounts");
  await expect(page.getByRole("heading", { name: /Accounts/ }).first()).toBeVisible();
}

export async function openAccount(page: Page, id: string, tab: AccountTab = ""): Promise<void> {
  await page.goto(`/cp/accounts/${encodeURIComponent(id)}${tab ? `/${tab}` : ""}`);
  await expect.poll(() => decodeURIComponent(new URL(page.url()).pathname)).toContain(`/cp/accounts/${id}`);
}

export interface NewLogin {
  type?: "SMPP" | "HTTP";
  systemId: string;
  password: string;
  product?: string;
  allowedIps?: string[];
}

/** The Add-login form on an account's Logins tab; resolves once the save round-trip finished. */
export async function addLoginViaForm(page: Page, login: NewLogin): Promise<void> {
  await page.getByRole("button", { name: "Add login" }).click();
  const form = page.getByRole("dialog");
  if (login.type) await form.locator("#type").selectOption(login.type);
  await form.locator("#systemId").fill(login.systemId);
  // the secret starts "unset"; Set reveals the input
  await form.getByRole("button", { name: "Set", exact: true }).first().click();
  await form.locator("#password").fill(login.password);
  if (login.product) await form.locator("#product").selectOption(login.product);
  for (const ip of login.allowedIps ?? []) {
    await form.getByRole("button", { name: "Add an address" }).click();
    await form.getByPlaceholder("203.0.113.10").last().fill(ip);
  }
  await page.getByRole("dialog").getByRole("button", { name: /Create login|Save/ }).click();
}

/** The catalogue's id box: opens (or starts) the account with that id. */
export async function openAccountById(page: Page, id: string): Promise<void> {
  await page.getByRole("textbox", { name: "Open an account by id" }).fill(id);
  await page.getByRole("button", { name: "Open", exact: true }).click();
  // the router encodes the id its own way ("bad id!" → bad%20id! or bad+id!), so compare decoded
  await expect.poll(() => decodeURIComponent(new URL(page.url()).pathname).replace(/\+/g, " ")).toContain(`/cp/accounts/${id}`);
}

export interface SettingsInput { label?: string; email?: string; description?: string }

/**
 * Save the Settings tab. An account not yet in the catalogue shows the "Name this account" form
 * (one Name box); a catalogued one shows the full form. Returns the refusal message if one
 * appeared within a few seconds, else null.
 */
export async function saveAccountSettings(page: Page, input: SettingsInput, opts: { expectRefusal?: boolean } = {}): Promise<{ message: string | null }> {
  const adopt = page.locator("#adopt");
  if (await adopt.count()) {
    await adopt.fill(input.label ?? "QA account");
    await page.getByRole("button", { name: /Name|Save|Adopt|Add|Create/ }).first().click();
    if (input.email || input.description) {
      // the full form appears once the row exists
      await expect(page.locator("#acct-label")).toBeVisible({ timeout: 15_000 });
      return saveAccountSettings(page, input, opts);
    }
  } else {
    if (input.label !== undefined) await page.locator("#acct-label").fill(input.label);
    if (input.email !== undefined) await page.locator("#acct-email").fill(input.email);
    if (input.description !== undefined) await page.locator("#acct-desc").fill(input.description);
    await page.getByRole("button", { name: /^Save/ }).first().click();
  }
  const alert = page.locator("[role=alert], .text-destructive, [data-sonner-toast]").filter({ hasText: /./ }).first();
  const message = await alert.textContent({ timeout: opts.expectRefusal ? 8_000 : 2_500 }).catch(() => null);
  return { message: message?.trim() || null };
}
