/**
 * Operator-panel flows shared by every EP-17..21 spec: the exact clicks a person makes, written
 * once. Selectors are the visible labels and roles — the panel has no test ids, and a label that
 * changes should break the suite, since it also changes what the operator reads.
 */
import os from "node:os";
import { expect } from "@playwright/test";
import type { Page } from "@playwright/test";
import { e2eEnv } from "../../fixtures/env";

export async function signInOperator(page: Page, creds?: { username: string; password: string }, baseURL?: string): Promise<void> {
  const env = e2eEnv();
  const c = creds ?? env.operator;
  await page.goto(`${baseURL ?? env.panelUrl}/cp/login`);
  // by role, not by label: "Remember me on this device" has "username" in its help text and
  // getByLabel matches substrings
  const username = page.getByRole("textbox", { name: "Username" });
  const password = page.getByLabel("Password", { exact: true });
  const button = page.getByRole("button", { name: "Sign in" });
  // Under `next dev` the form is served before React hydrates it; a value typed before hydration is
  // thrown away when the component mounts, and the submit button stays disabled. Fill, then wait
  // for the button to enable; if it does not, the fill was pre-hydration — do it again.
  // Under a cold `next dev` that can take tens of seconds the first time a route compiles.
  for (let attempt = 0; attempt < 150; attempt++) {
    await username.fill(c.username);
    await password.fill(c.password);
    await page.waitForTimeout(300);
    const stuck = (await password.inputValue().catch(() => "")) === c.password && (await button.isEnabled().catch(() => false));
    if (stuck) break;
  }
  await expect(button).toBeEnabled();
  await button.click();
}

/** Sign in and assert the dashboard came up. */
export async function signInOperatorOk(page: Page, creds?: { username: string; password: string }, baseURL?: string): Promise<void> {
  await signInOperator(page, creds, baseURL);
  await expect(page).toHaveURL(/\/cp(\/|$|\?)/);
  await expect(page).not.toHaveURL(/\/cp\/login/);
}

/** Sign in with credentials expected to be refused; returns the message the form shows. */
export async function signInOperatorRefused(page: Page, creds: { username: string; password: string }, baseURL?: string): Promise<string> {
  await signInOperator(page, creds, baseURL);
  const msg = page.locator("form p.text-destructive");
  await expect(msg).toBeVisible();
  await expect(page).toHaveURL(/\/cp\/login/);
  return (await msg.textContent())?.trim() ?? "";
}

export async function signOutOperator(page: Page): Promise<void> {
  await page.getByRole("button", { name: "Sign out" }).click();
  await expect(page).toHaveURL(/\/cp\/login/);
}

/** The dashboard route families a session must be refused on when it is not an operator's. */
/** A non-loopback IPv4 of this host, for the cases where loopback's "secure context" would mask a Secure cookie. */
export function lanAddress(): string | null {
  const nets = os.networkInterfaces();
  for (const list of Object.values(nets)) {
    for (const n of list ?? []) {
      if (n.family === "IPv4" && !n.internal) return n.address;
    }
  }
  return null;
}

export const CONTROL_ROUTE_FAMILIES: { family: string; path: string }[] = [
  { family: "config (accounts)", path: "/api/control/accounts" },
  { family: "config (vendors)", path: "/api/control/vendors" },
  { family: "metrics (cdrs)", path: "/api/control/cdrs" },
  { family: "metrics (overview)", path: "/api/control/overview" },
  { family: "ops (health)", path: "/api/control/health" },
  { family: "ops (gateway-config-resolved)", path: "/api/control/gateway-config-resolved" },
  { family: "security", path: "/api/control/security" },
  { family: "licence", path: "/api/control/license" },
];
