/**
 * Submit-side helpers shared by EP-02, EP-03, EP-05, EP-09 and EP-12: UDH-concatenated segments,
 * custom TLVs (registered once with the smpp codec), listener settings that are adopted live, and
 * the balance/refund identity a refused message must leave intact.
 */
import smpp from "smpp";
import type { Db } from "../../fixtures/db";
import { awaitGatewayAdopts, ops } from "../../fixtures/gateway";

/** UCS-2 text split into `n` UDH-concatenated segments (ref, total, seq). */
export function ucs2Segments(text: string, n: number, ref = Math.floor(Math.random() * 200) + 1): { udh: Buffer; text: Buffer }[] {
  const chars = [...text];
  const per = Math.ceil(chars.length / n);
  const out: { udh: Buffer; text: Buffer }[] = [];
  for (let i = 0; i < n; i++) {
    const slice = chars.slice(i * per, (i + 1) * per).join("");
    out.push({ udh: Buffer.from([0x05, 0x00, 0x03, ref, n, i + 1]), text: Buffer.from(slice, "utf16le").swap16() });
  }
  return out;
}

const registered = new Set<string>();
/** Register a custom TLV with the smpp codec once; the name is then usable as a submit parameter. */
export function tlv(name: string, id: number, type: "string" | "buffer" | "int8" | "int16" | "int32" = "string"): string {
  if (!registered.has(name)) {
    smpp.addTLV(name, { id, type: smpp.types.tlv[type] });
    registered.add(name);
  }
  return name;
}

/** Set (or with null, clear) a listener/vendor property and wait until `check` says it is in force. */
export async function setWorkerProperty(db: Db, worker: string, key: string, value: string | null, check?: () => Promise<boolean>): Promise<() => Promise<void>> {
  const prior = await db.maybe<{ value: string }>("SELECT value FROM app_worker_property WHERE worker_name = $1 AND key = $2", [worker, key]);
  const write = async (v: string | null) => {
    if (v === null) await db.q("DELETE FROM app_worker_property WHERE worker_name = $1 AND key = $2", [worker, key]);
    else await db.q("INSERT INTO app_worker_property (worker_name, key, value) VALUES ($1, $2, $3) ON CONFLICT (worker_name, key) DO UPDATE SET value = EXCLUDED.value", [worker, key, v]);
  };
  await write(value);
  if (check) await awaitGatewayAdopts(check); else { await ops().reload(); await new Promise((r) => setTimeout(r, 2500)); }
  return async () => { await write(prior?.value ?? null); await ops().reload().catch(() => undefined); };
}

export async function balanceOf(db: Db, accountId: string): Promise<{ balance: number; reserved: number; total: number }> {
  const r = await db.one<{ balance: string; reserved: string }>("SELECT balance::text, reserved::text FROM account_balance WHERE account_id = $1", [accountId]);
  return { balance: Number(r.balance), reserved: Number(r.reserved), total: Number(r.balance) + Number(r.reserved) };
}

export async function rejectedFor(db: Db, opts: { since: Date; reason?: string; systemId?: string }) {
  return db.q<{ reason: string; detail: string | null; gateway_msg_id: string | null; receipt: string | null }>(
    `SELECT reason, detail, gateway_msg_id, receipt FROM cdr_rejected
      WHERE rejected_at >= $1 AND ($2::text IS NULL OR reason = $2) AND ($3::text IS NULL OR system_id = $3) ORDER BY id`,
    [opts.since, opts.reason ?? null, opts.systemId ?? null],
  );
}

/** A generic-NACK probe: 16 raw header bytes with an unknown command id, answered by generic_nack. */
export function unknownCommandPdu(commandId = 0x7777, seq = 1): Buffer {
  const b = Buffer.alloc(16);
  b.writeUInt32BE(16, 0);
  b.writeUInt32BE(commandId, 4);
  b.writeUInt32BE(0, 8);
  b.writeUInt32BE(seq, 12);
  return b;
}
