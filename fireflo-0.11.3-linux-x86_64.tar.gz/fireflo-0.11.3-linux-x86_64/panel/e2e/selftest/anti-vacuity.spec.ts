/**
 * Proves the reporting path can carry a failure. A suite whose reporter only ever saw green would
 * pass a write-back that dropped every Fail on the floor, so this project runs a test that MUST
 * fail and one that must pass, both annotated the way tc() annotates, under ids the catalog does
 * not know (TC-00.*). The catalog check ignores this directory; the write-back ignores unknown ids;
 * `npm run e2e:selftest` asserts results.json holds the Fail.
 */
import { expect, test } from "../fixtures";

function annotateLike(info: import("@playwright/test").TestInfo, id: string, kind = "auto") {
  info.annotations.push({ type: "tc", description: id });
  info.annotations.push({ type: "tc-kind", description: kind });
  info.annotations.push({ type: "epic", description: "EP-00" });
  info.annotations.push({ type: "story", description: "US-00.00" });
  info.annotations.push({ type: "scenario", description: "SC-00.00.00" });
}

test.describe("SC-00.00.00 the reporter carries every outcome", () => {
  test("TC-00.00.00-N01 an inverted assertion is recorded as Fail", async ({}, info) => {
    annotateLike(info, "TC-00.00.00-N01");
    info.annotations.push({ type: "note", description: "observed 2" });
    // deliberately wrong: 1 + 1 is not 3. If this ever passes, arithmetic has changed.
    expect(1 + 1, "selftest: this assertion is meant to fail").toBe(3);
  });

  test("TC-00.00.00-P01 a passing test is recorded as Pass", async ({}, info) => {
    annotateLike(info, "TC-00.00.00-P01");
    info.annotations.push({ type: "note", description: "observed 2" });
    expect(1 + 1).toBe(2);
  });

  test("TC-00.00.00-P02 a manual case is recorded as Not run", async ({}, info) => {
    annotateLike(info, "TC-00.00.00-P02", "manual");
    info.annotations.push({ type: "tc-reason", description: "selftest manual reason" });
    test.skip(true, "manual: selftest");
  });

  test("TC-00.00.00-P03 a blocked case is recorded as Blocked", async ({}, info) => {
    annotateLike(info, "TC-00.00.00-P03", "blocked");
    info.annotations.push({ type: "tc-reason", description: "needs nothing (selftest)" });
    test.skip(true, "blocked: selftest");
  });
});
