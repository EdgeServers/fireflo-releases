/**
 * Writes e2e/.run/results.json — one record per sheet id — for `npm run e2e:writeback`.
 *
 * The mapping from a Playwright outcome to a sheet status is decided here and nowhere else:
 *
 *   passed                       → Pass
 *   failed / timedOut            → Fail        (Actual result = the error, first line)
 *   skipped, kind=manual         → Not run     (Notes = "manual: <reason>")
 *   skipped, kind=todo           → Not run     (Notes = "todo: not automated yet")
 *   skipped, kind=blocked/fixme  → Blocked     (Notes = the reason)
 *   interrupted                  → Blocked     (the run was stopped under it)
 *
 * A test that ran and passed but was retried is still Pass, but the sheet gets a note — the suite
 * runs with retries: 0 precisely so flakiness is recorded rather than hidden, and the note is the
 * record if somebody raises retries locally.
 */
import { execFileSync } from "node:child_process";
import { mkdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import type { FullConfig, FullResult, Reporter, TestCase, TestResult } from "@playwright/test/reporter";

export type SheetStatus = "Pass" | "Fail" | "Blocked" | "Not run";

export interface TcResult {
  id: string;
  epic: string;
  story: string;
  scenario: string;
  kind: string;
  status: SheetStatus;
  playwrightStatus: TestResult["status"];
  title: string;
  project: string;
  file: string;
  durationMs: number;
  actual: string;
  notes: string;
  error: string | null;
  retries: number;
}

export interface ResultsFile {
  startedAt: string;
  finishedAt: string;
  tester: string;
  git: { panel: string | null; gateway: string | null };
  counts: Record<SheetStatus, number>;
  results: TcResult[];
}

// tc() sets its annotations in the test's details (static, on the TestCase); note() and the
// selftest push theirs at run time (on the TestResult). Both are read.
function all(test: TestCase, result: TestResult) {
  return [...test.annotations, ...result.annotations];
}

function annotation(test: TestCase, result: TestResult, type: string): string | undefined {
  return all(test, result).find((a) => a.type === type)?.description;
}

function annotations(test: TestCase, result: TestResult, type: string): string[] {
  return all(test, result).filter((a) => a.type === type).map((a) => a.description ?? "").filter(Boolean);
}

// ESC [ … m — terminal colour sequences Playwright puts in error messages
const ANSI = new RegExp(String.fromCharCode(27) + "\\[[0-9;]*m", "g");

function firstLine(s: string | undefined): string {
  if (!s) return "";
  const clean = s.replace(ANSI, "");
  return clean.split("\n").map((l) => l.trim()).find(Boolean) ?? "";
}

function gitHead(dir: string): string | null {
  try {
    return execFileSync("git", ["rev-parse", "--short", "HEAD"], { cwd: dir, stdio: ["ignore", "pipe", "ignore"] })
      .toString()
      .trim();
  } catch {
    return null;
  }
}

export default class TcResultsReporter implements Reporter {
  private results = new Map<string, TcResult>();
  private startedAt = new Date();
  private outFile = "";
  private tester = process.env.E2E_TESTER ?? "playwright";

  onBegin(config: FullConfig) {
    this.outFile = path.join(config.rootDir, ".run", "results.json");
  }

  onTestEnd(test: TestCase, result: TestResult) {
    const id = annotation(test, result, "tc");
    if (!id) return;
    const kind = annotation(test, result, "tc-kind") ?? "auto";
    const reason = annotation(test, result, "tc-reason") ?? "";
    const notes = annotations(test, result, "note");
    let status: SheetStatus;
    let noteText = "";
    switch (result.status) {
      case "passed":
        status = "Pass";
        if (result.retry > 0) noteText = `passed on retry ${result.retry}`;
        break;
      case "failed":
      case "timedOut":
        status = "Fail";
        break;
      case "interrupted":
        status = "Blocked";
        noteText = "run interrupted";
        break;
      case "skipped":
        if (kind === "manual") { status = "Not run"; noteText = `manual: ${reason}`; }
        else if (kind === "todo") { status = "Not run"; noteText = "todo: not automated yet"; }
        else { status = "Blocked"; noteText = reason || "skipped"; }
        break;
    }
    const error = result.error ? firstLine(result.error.message) : null;
    const actual = [...(status === "Fail" && error ? [error] : []), ...notes].join(" | ");
    const prior = this.results.get(id);
    // a retried test reports once; the last result wins and the retry count is kept
    this.results.set(id, {
      id,
      epic: annotation(test, result, "epic") ?? "",
      story: annotation(test, result, "story") ?? "",
      scenario: annotation(test, result, "scenario") ?? "",
      kind,
      status,
      playwrightStatus: result.status,
      title: test.title,
      project: test.parent.project()?.name ?? "",
      file: path.relative(process.cwd(), test.location.file),
      durationMs: result.duration + (prior?.durationMs ?? 0),
      actual,
      notes: noteText,
      error,
      retries: result.retry,
    });
  }

  async onEnd(_result: FullResult) {
    try {
      this.write();
    } catch (e) {
      console.error(`tc-results: could not write ${this.outFile}: ${e instanceof Error ? e.stack : e}`);
    }
  }

  private write() {
    const results = [...this.results.values()].sort((a, b) => a.id.localeCompare(b.id));
    const counts: Record<SheetStatus, number> = { Pass: 0, Fail: 0, Blocked: 0, "Not run": 0 };
    for (const r of results) counts[r.status]++;
    const file: ResultsFile = {
      startedAt: this.startedAt.toISOString(),
      finishedAt: new Date().toISOString(),
      tester: this.tester,
      git: {
        panel: gitHead(process.cwd()),
        gateway: gitHead(path.resolve(process.cwd(), process.env.E2E_GATEWAY_REPO ?? "../fireflo-sms-gateway")),
      },
      counts,
      results,
    };
    mkdirSync(path.dirname(this.outFile), { recursive: true });
    writeFileSync(this.outFile, JSON.stringify(file, null, 1) + "\n");
    console.log(
      `\ntc-results: ${results.length} test cases → Pass ${counts.Pass} · Fail ${counts.Fail} · Blocked ${counts.Blocked} · Not run ${counts["Not run"]}` +
        `\n            ${path.relative(process.cwd(), this.outFile)}`,
    );
  }

  printsToStdio() {
    return false;
  }
}
