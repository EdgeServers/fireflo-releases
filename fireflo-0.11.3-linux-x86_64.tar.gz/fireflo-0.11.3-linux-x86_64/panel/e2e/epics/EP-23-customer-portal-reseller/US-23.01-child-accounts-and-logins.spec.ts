/**
 * EP-23 Customer Portal — Reseller
 * US-23.01 Child accounts and logins
 */
import { expect, test } from "../../fixtures";
import { awaitGatewayAdopts } from "../../fixtures/gateway";
import { BASELINE } from "../../fixtures/seed";
import { bindAttempt, connectEsme } from "../../fixtures/smpp";
import { tc } from "../../support/tc";

const R = BASELINE.accounts.reseller;

async function childOf(db: import("../../fixtures").Db, seed: import("../../fixtures").Seed, reseller: string): Promise<string> {
  const id = await seed.account({ label: "QA child", parentAccountId: reseller, email: `${seed.prefix}child-${Date.now().toString(36)}@fireflo.test` });
  await db.q("UPDATE app_account SET resells = false WHERE id = $1", [id]);
  return id;
}

test.describe("SC-23.01.01 Onboard a child", () => {
  test(...tc("TC-23.01.01-P01", "Create child lands with the right parent"), async ({ portalApi, db, seed, tcx }) => {
    const api = await portalApi(R);
    const id = seed.name(`c-${Date.now().toString(36)}`);
    seed.cleanup(async () => { await db.q("DELETE FROM app_credential WHERE account_id = $1", [id]); await db.q("DELETE FROM app_account WHERE id = $1", [id]); });
    const since = new Date();
    const res = await api.post("/api/mis/accounts/catalogue", { data: { id, label: "QA onboarded child", email: `${id}@fireflo.test` } });
    expect(res.status(), await res.text()).toBeLessThan(300);
    const row = await db.one<{ parent_account_id: string; resells: boolean; enabled: boolean }>("SELECT parent_account_id, resells, enabled FROM app_account WHERE id = $1", [id]);
    expect(row).toEqual({ parent_account_id: R, resells: false, enabled: true });
    await db.waitForRow("SELECT 1 FROM app_customer_access_log WHERE event = 'child_created' AND account_id = $1 AND occurred_at >= $2", [R, since]);
    tcx.note(`${id}: parent ${row.parent_account_id}, resells ${row.resells}; child_created audited`);
  });

  test(...tc("TC-23.01.01-P02", "Create login shows the secret once"), async ({ portalApi, db, seed, tcx }) => {
    const child = await childOf(db, seed, R);
    const api = await portalApi(R);
    const systemId = `c1l1${Date.now().toString(36).slice(-6)}`; // ≤ 15 characters
    const res = await api.post("/api/mis/credentials", { data: { accountId: child, type: "SMPP", systemId, allowedIps: [] } });
    expect(res.status(), await res.text()).toBe(200);
    const body = (await res.json()) as { data: { id: number; secret: string; secretKind: string } };
    expect(body.data.secret, "the secret is returned exactly once").toMatch(/\S{16,}/);
    const row = await db.one<{ product: string | null; allowed_products: string[] | null; password: string }>("SELECT product, allowed_products, password FROM app_credential WHERE system_id = $1", [systemId]);
    expect(row.product, "a reseller cannot pick the price").toBeNull();
    expect(row.allowed_products).toBeNull();
    expect(row.password).toBe(body.data.secret);
    const list = await api.get("/api/mis/logins");
    expect(await list.text()).not.toContain(body.data.secret);
    const childLogins = await api.get(`/api/mis/credentials?account=${child}`);
    expect(await childLogins.text()).not.toContain(body.data.secret);
    tcx.note(`secret returned once (${body.data.secretKind}); product/allowed_products NULL; absent from every listing`);
  });

  test(...tc("TC-23.01.01-N01", "Body cannot set resells or parent"), async ({ portalApi, db, seed, tcx }) => {
    const api = await portalApi(R);
    const id = seed.name(`c-pin-${Date.now().toString(36)}`);
    seed.cleanup(async () => { await db.q("DELETE FROM app_account WHERE id = $1", [id]); });
    const res = await api.post("/api/mis/accounts/catalogue", { data: { id, label: "QA pinned", resells: true, parentAccountId: BASELINE.accounts.a } });
    expect(res.status(), await res.text()).toBeLessThan(300);
    const row = await db.one<{ parent_account_id: string; resells: boolean }>("SELECT parent_account_id, resells FROM app_account WHERE id = $1", [id]);
    expect(row).toEqual({ parent_account_id: R, resells: false });
    tcx.note(`resells:true and parentAccountId:${BASELINE.accounts.a} in the body → row parent ${row.parent_account_id}, resells ${row.resells}`);
  });

  test(...tc("TC-23.01.01-N02", "Non-reseller gets 404 on /accounts"), async ({ portalApi, portalPage, tcx }) => {
    const api = await portalApi(BASELINE.accounts.portal);
    const list = await api.get("/api/mis/accounts");
    const create = await api.post("/api/mis/accounts/catalogue", { data: { id: "qa-should-not-exist", label: "x" } });
    expect(list.status()).toBe(404);
    expect(create.status()).toBe(404);
    const page = await portalPage(BASELINE.accounts.portal);
    const res = await page.goto("/accounts");
    expect(res?.status(), "the page is notFound()").toBe(404);
    await expect(page.getByRole("link", { name: "Accounts" })).toHaveCount(0);
    tcx.note(`API ${list.status()}/${create.status()}; page ${res?.status()}; no Accounts link in the nav`);
  });

  test(...tc("TC-23.01.01-N03", "Id colliding with an existing account is refused, not overwritten"), async ({ portalApi, db, seed, tcx }) => {
    const own = await childOf(db, seed, R);
    const stranger = BASELINE.accounts.a;
    const api = await portalApi(R);
    const before = await db.q<{ id: string; label: string; email: string | null }>("SELECT id, label, email FROM app_account WHERE id = ANY($1) ORDER BY id", [[own, stranger]]);
    const ownRes = await api.post("/api/mis/accounts/catalogue", { data: { id: own, label: "QA impostor", email: `imp-${own}@fireflo.test` } });
    const strangerRes = await api.post("/api/mis/accounts/catalogue", { data: { id: stranger, label: "QA impostor", email: `imp-${stranger}@fireflo.test` } });
    expect(ownRes.status()).toBe(409);
    expect(await ownRes.text()).toContain("already have an account");
    expect([400, 409]).toContain(strangerRes.status());
    const after = await db.q<{ id: string; label: string; email: string | null }>("SELECT id, label, email FROM app_account WHERE id = ANY($1) ORDER BY id", [[own, stranger]]);
    expect(after).toEqual(before);
    tcx.note(`own → ${ownRes.status()}; stranger → ${strangerRes.status()}; neither row changed`);
  });
});

test.describe("SC-23.01.02 Suspend is real", () => {
  test(...tc("TC-23.01.02-P01", "Suspend drops the bind and blocks re-bind", { requires: ["gateway"] }), async ({ portalApi, db, seed, tcx }) => {
    const child = await childOf(db, seed, R);
    const login = await seed.credential({ accountId: child, product: BASELINE.product });
    await awaitGatewayAdopts(async () => (await bindAttempt(login)).status === 0, { timeoutMs: 40_000 });
    const esme = await connectEsme(login);
    expect(esme.bound).toBe(true);
    const api = await portalApi(R);
    const since = new Date();
    const res = await api.post(`/api/mis/accounts/${child}`, { data: { action: "suspend" } });
    expect(res.status(), await res.text()).toBe(200);
    // the logins are disabled and the live bind is dropped
    expect((await db.one<{ enabled: boolean }>("SELECT enabled FROM app_credential WHERE id = $1", [login.id])).enabled).toBe(false);
    await expect.poll(() => esme.bound, { timeout: 15_000 }).toBe(false);
    await awaitGatewayAdopts(async () => (await bindAttempt(login)).status !== 0, { timeoutMs: 40_000 });
    const again = await bindAttempt(login);
    expect(again.status).not.toBe(0);
    await db.waitForRow("SELECT 1 FROM app_customer_access_log WHERE event = 'child_suspended' AND occurred_at >= $1", [since]);
    tcx.note(`bind dropped; re-bind → 0x${again.status.toString(16)}; child_suspended audited`);
    await esme.destroy();
  });

  test(...tc("TC-23.01.02-P02", "Resume allows re-bind", { requires: ["gateway"] }), async ({ portalApi, db, seed, tcx }) => {
    const child = await childOf(db, seed, R);
    const login = await seed.credential({ accountId: child, product: BASELINE.product });
    const api = await portalApi(R);
    expect((await api.post(`/api/mis/accounts/${child}`, { data: { action: "suspend" } })).status()).toBe(200);
    await awaitGatewayAdopts(async () => (await bindAttempt(login)).status !== 0, { timeoutMs: 40_000 });
    const since = new Date();
    expect((await api.post(`/api/mis/accounts/${child}`, { data: { action: "resume" } })).status()).toBe(200);
    await awaitGatewayAdopts(async () => (await bindAttempt(login)).status === 0, { timeoutMs: 40_000 });
    expect((await bindAttempt(login)).status).toBe(0);
    await db.waitForRow("SELECT 1 FROM app_customer_access_log WHERE event = 'child_resumed' AND occurred_at >= $1", [since]);
    tcx.note("bind OK after resume + poll; child_resumed audited");
  });
});
