/**
 * EP-23 Customer Portal — Reseller
 * US-23.03 Scope enforcement
 */
import { randomUUID } from "node:crypto";
import { expect, test } from "../../fixtures";
import { tc } from "../../support/tc";

async function twoResellers(db: import("../../fixtures").Db, seed: import("../../fixtures").Seed) {
  const r1 = await seed.account({ label: "QA R1", resells: true, email: `${seed.prefix}r1-${Date.now().toString(36)}@fireflo.test` });
  const c1 = await seed.account({ label: "QA c1", parentAccountId: r1 });
  const r2 = await seed.account({ label: "QA R2", resells: true, email: `${seed.prefix}r2-${Date.now().toString(36)}@fireflo.test` });
  const c2 = await seed.account({ label: "QA c2", parentAccountId: r2 });
  await seed.balance({ accountId: r1, balance: 1_000_000 });
  await seed.balance({ accountId: c2, balance: 0 });
  seed.cleanup(async () => { await db.q("DELETE FROM balance_ledger WHERE account_id = ANY($1) OR counterparty_account_id = ANY($1)", [[r1, c1, r2, c2]]).catch(() => undefined); });
  return { r1, c1, r2, c2 };
}

test.describe("SC-23.03.01 Stranger's child", () => {
  test(...tc("TC-23.03.01-N01", "R1 cannot read c2"), async ({ portalApi, db, seed, tcx }) => {
    const { r1, c1, c2 } = await twoResellers(db, seed);
    const api = await portalApi(r1);
    expect((await api.get(`/api/mis/accounts/${c1}/context`)).status(), "own child reads").toBe(200);
    const res = await api.get(`/api/mis/accounts/${c2}/context`);
    expect(res.status(), "a stranger's child is 404, never 403").toBe(404);
    tcx.note(`c1 200, c2 ${res.status()}`);
  });

  test(...tc("TC-23.03.01-N02", "R1 cannot transfer to c2"), async ({ portalApi, db, seed, tcx }) => {
    const { r1, c2 } = await twoResellers(db, seed);
    const api = await portalApi(r1);
    const before = await db.count("balance_ledger", "account_id = ANY($1) OR counterparty_account_id = ANY($1)", [[r1, c2]]);
    const res = await api.post("/api/mis/transfer", { data: { accountId: c2, amount: "10.0000", direction: "down", ref: `xfer:${randomUUID()}` } });
    expect(res.status()).toBe(404);
    expect(await db.count("balance_ledger", "account_id = ANY($1) OR counterparty_account_id = ANY($1)", [[r1, c2]])).toBe(before);
    tcx.note(`transfer to c2 → ${res.status()}; no ledger row`);
  });

  test(...tc("TC-23.03.01-N03", "R1 cannot suspend c2"), async ({ portalApi, db, seed, tcx }) => {
    const { r1, c2 } = await twoResellers(db, seed);
    const login = await seed.credential({ accountId: c2 });
    const api = await portalApi(r1);
    const res = await api.post(`/api/mis/accounts/${c2}`, { data: { action: "suspend" } });
    expect(res.status()).toBe(404);
    expect((await db.one<{ enabled: boolean }>("SELECT enabled FROM app_credential WHERE id = $1", [login.id])).enabled, "c2's login untouched").toBe(true);
    tcx.note(`suspend c2 → ${res.status()}; c2's login still enabled`);
  });

  test(...tc("TC-23.03.01-P01", "In-scope reach is audited"), async ({ portalApi, db, seed, tcx }) => {
    const { r1, c1 } = await twoResellers(db, seed);
    const api = await portalApi(r1);
    const since = new Date();
    expect((await api.get(`/api/mis/accounts/${c1}/context`)).status()).toBe(200);
    const row = await db.waitForRow<{ detail: Record<string, unknown> }>("SELECT detail FROM app_customer_access_log WHERE event = 'cross_account_access' AND account_id = $1 AND occurred_at >= $2", [r1, since]);
    expect(JSON.stringify(row.detail)).toContain(c1);
    tcx.note(`cross_account_access by ${r1} naming ${c1}`);
  });

  test(...tc("TC-23.03.01-P02", "Reseller tabs exclude Tariff"), async ({ portalPage, db, seed, tcx }) => {
    const { r1, c1 } = await twoResellers(db, seed);
    await seed.cdrs({ accountId: c1 }, 2);
    const page = await portalPage(r1);
    await page.goto(`/accounts/${c1}`);
    await expect(page).toHaveURL(new RegExp(`/accounts/${c1}`));
    const tabs = page.getByRole("navigation").getByRole("link");
    const names = (await tabs.allTextContents()).map((t) => t.trim());
    for (const want of ["Overview", "Settings", "Logins", "Approvals", "Billing", "Statement"]) expect(names, `tab ${want}`).toContain(want);
    expect(names).not.toContain("Tariff");
    await expect(page.getByRole("columnheader", { name: /^Cost$/ })).toHaveCount(0);
    await page.goto(`/accounts/${c1}/approvals`);
    await expect(page.getByRole("button", { name: /^Approve/ })).toHaveCount(0);
    tcx.note(`tabs: ${names.join(", ")}; no Cost column; no Approve button`);
  });
});
