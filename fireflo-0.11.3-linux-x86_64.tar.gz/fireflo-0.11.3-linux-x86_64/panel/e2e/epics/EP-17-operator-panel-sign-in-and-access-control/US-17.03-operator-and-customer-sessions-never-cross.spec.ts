/**
 * EP-17 Operator Panel — Sign-in & Access Control
 * US-17.03 Operator and customer sessions never cross
 */
import { expect, test } from "../../fixtures";
import { carryCookie, mintOperatorContext, mintPortalContext, OPERATOR_COOKIE, PORTAL_COOKIE } from "../../fixtures/auth";
import { BASELINE } from "../../fixtures/seed";
import { tc } from "../../support/tc";

test.describe("SC-17.03.01 Two cookies, two surfaces", () => {
  test(...tc("TC-17.03.01-N01", "Operator cookie on the portal is rejected"), async ({ operatorApi, browser, tcx }) => {
    // the operator context genuinely is signed in on /cp…
    expect((await operatorApi.get("/api/control/accounts")).status()).toBe(200);
    // …and that session buys nothing on the customer surface
    const overview = await operatorApi.get("/api/mis/overview");
    expect(overview.status(), "portal API answers 404, not 403").toBe(404);
    const context = await browser.newContext({ storageState: undefined });
    await carryCookie(operatorApi, context, OPERATOR_COOKIE);
    const page = await context.newPage();
    await page.goto("/overview");
    await expect(page).not.toHaveURL(/\/overview/);
    tcx.note(`/api/mis/overview ${overview.status()}; /overview → ${page.url()}`);
    await context.close();
  });

  test(...tc("TC-17.03.01-N02", "Customer cookie on /cp is rejected"), async ({ db, browser, tcx }) => {
    const portal = await mintPortalContext(db, BASELINE.accounts.portal);
    try {
      expect((await portal.get("/api/mis/overview")).status(), "the customer session works on its own surface").toBe(200);
      const jar = (await portal.storageState()).cookies;
      const held = jar.map((c) => c.name).sort();
      const describe = jar.map((c) => `${c.name}@${c.domain}${c.path}=${c.value.slice(0, 12)}…`).join(" ");
      tcx.note(`cookies: ${describe}`);
      const control = await portal.get("/api/control/accounts");
      const opSession = await (await portal.get("/api/auth/session")).text();
      tcx.note(`portal jar: ${held.join(",")}; /api/auth/session → ${opSession.slice(0, 120)}`);
      expect(held, "the portal jar must not carry the operator cookie").not.toContain(OPERATOR_COOKIE);
      expect(control.status(), "operator API answers 404, not 403").toBe(404);
      const context = await browser.newContext({ storageState: undefined });
      await carryCookie(portal, context, PORTAL_COOKIE);
      const page = await context.newPage();
      await page.goto("/cp");
      await expect(page).toHaveURL(/\/cp\/login/);
      tcx.note(`/api/control/accounts ${control.status()}; /cp → ${page.url()}`);
      await context.close();
    } finally {
      await portal.dispose();
    }
  });

  test(...tc("TC-17.03.01-P01", "Both sessions coexist in one browser without leaking"), async ({ db, browser, tcx }) => {
    const operator = await mintOperatorContext();
    const portal = await mintPortalContext(db, BASELINE.accounts.portal);
    try {
      const context = await browser.newContext({ storageState: undefined });
      await carryCookie(operator, context, OPERATOR_COOKIE);
      await carryCookie(portal, context, PORTAL_COOKIE);
      const page = await context.newPage();
      await page.goto("/cp");
      await expect(page).toHaveURL(/\/cp(\/|$)/);
      await page.goto("/overview");
      await expect(page).toHaveURL(/\/overview/);
      const control = await context.request.get("/api/control/accounts");
      const mis = await context.request.get("/api/mis/overview");
      expect(control.status()).toBe(200);
      expect(mis.status()).toBe(200);
      // the operator session names the operator, the portal session names the account — never swapped
      const opSession = (await (await context.request.get("/api/auth/session")).json()) as { user?: { name: string } };
      const misSession = (await (await context.request.get("/api/mis/auth/session")).json()) as { user?: { name: string } };
      expect(opSession.user?.name).not.toBe(BASELINE.accounts.portal);
      expect(misSession.user?.name).toBe(BASELINE.accounts.portal);
      tcx.note(`/cp and /overview both served; sessions ${opSession.user?.name} / ${misSession.user?.name}`);
      await context.close();
    } finally {
      await operator.dispose();
      await portal.dispose();
    }
  });
});
