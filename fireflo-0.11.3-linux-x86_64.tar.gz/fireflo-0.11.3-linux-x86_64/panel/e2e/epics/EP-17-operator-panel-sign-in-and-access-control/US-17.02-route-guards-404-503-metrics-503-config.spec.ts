/**
 * EP-17 Operator Panel — Sign-in & Access Control
 * US-17.02 Route guards: 404, 503-metrics, 503-config
 */
import { expect, test } from "../../fixtures";
import { mintOperatorContext } from "../../fixtures/auth";
import { startPanelVariant } from "../../fixtures/panel-variant";
import { CONTROL_ROUTE_FAMILIES, signInOperatorOk } from "../../support/flows/operator";
import { tc } from "../../support/tc";

test.describe("SC-17.02.01 The three guards", () => {
  test(...tc("TC-17.02.01-N01", "Non-operator on every route family is 404"), async ({ anonContext, tcx }) => {
    const seen: string[] = [];
    for (const { family, path } of CONTROL_ROUTE_FAMILIES) {
      const get = await anonContext.request.get(path);
      expect(get.status(), `${family} GET ${path}`).toBe(404);
      expect(await get.json(), `${family} body`).toEqual({ error: "Not found" });
      seen.push(`${path}:${get.status()}`);
    }
    // a write is refused the same way, before any body is read
    const put = await anonContext.request.put("/api/control/gateway-settings", { data: { key: "smsg.x", value: "1" } });
    expect(put.status()).toBe(404);
    const post = await anonContext.request.post("/api/control/reload", { data: {} });
    expect(post.status()).toBe(404);
    tcx.note(seen.join(" "));
  });

  test(...tc("TC-17.02.01-N02", "No metrics DB → 503 on report routes", { requires: ["variants"] }), async ({ tcx }) => {
    const v = await startPanelVariant("no-metrics-db", { METRICS_DATABASE_URL: undefined });
    try {
      const ctx = await mintOperatorContext(v.url);
      const cdrs = await ctx.get("/api/control/cdrs");
      const cdrsBody = (await cdrs.json().catch(() => ({}))) as { error?: string };
      const overview = await ctx.get("/api/control/overview");
      // a pure configuration route is unaffected by the metrics pool (accounts' usage view is not: it joins CDRs)
      const accounts = await ctx.get("/api/control/accounts/catalogue");
      await ctx.dispose();
      expect(cdrs.status()).toBe(503);
      expect(cdrsBody.error).toContain("METRICS_DATABASE_URL is not set");
      expect(overview.status()).toBe(503);
      expect(accounts.status(), "config routes still answer").toBe(200);
      tcx.note(`cdrs ${cdrs.status()}, overview ${overview.status()}, accounts ${accounts.status()}`);
    } finally {
      await v.stop();
    }
  });

  test(...tc("TC-17.02.01-N03", "No config DB → 503 on writes, banner on pages", { requires: ["variants"] }), async ({ browser, env, tcx }) => {
    const v = await startPanelVariant("no-config-db", { CONFIG_DATABASE_URL: undefined });
    try {
      const ctx = await mintOperatorContext(v.url);
      const write = await ctx.put("/api/control/gateway-settings", { data: { key: "smsg.cdr.deadline.hours", value: "24" } });
      const writeBody = (await write.json().catch(() => ({}))) as { error?: string };
      const vendorWrite = await ctx.put("/api/control/accounts/catalogue", { data: { id: "qa-x", label: "x" } });
      // reports still work: they read the metrics pool
      const cdrs = await ctx.get("/api/control/cdrs");
      await ctx.dispose();
      expect(write.status()).toBe(503);
      expect(writeBody.error).toContain("CONFIG_DATABASE_URL is not set");
      expect(vendorWrite.status()).toBe(503);
      expect(cdrs.status()).toBe(200);
      // and the page says so rather than offering a form that will fail
      const context = await browser.newContext({ storageState: undefined });
      const page = await context.newPage();
      await signInOperatorOk(page, env.operator, v.url);
      await page.goto(`${v.url}/cp/vendors`);
      await expect(page.getByText(/CONFIG_DATABASE_URL|switched off|read-only|cannot be edited/i).first(),
        "a page that cannot write must say so; only the API's 503 does today").toBeVisible();
      await context.close();
      tcx.note(`writes ${write.status()}/${vendorWrite.status()}, reads ${cdrs.status()}, notice shown on /cp/vendors`);
    } finally {
      await v.stop();
    }
  });

  test(...tc("TC-17.02.01-P01", "Full env: all three families answer 200", { requires: ["gateway"] }), async ({ operatorApi, tcx }) => {
    const config = await operatorApi.get("/api/control/accounts");
    const metrics = await operatorApi.get("/api/control/cdrs");
    const ops = await operatorApi.get("/api/control/health");
    expect(config.status(), "config family").toBe(200);
    expect(metrics.status(), "metrics family").toBe(200);
    expect(ops.status(), "ops family (proxied to the gateway)").toBe(200);
    tcx.note(`accounts ${config.status()}, cdrs ${metrics.status()}, health ${ops.status()}`);
  });
});
