/**
 * EP-20 Operator Panel — Pricing, Gateway Settings & Approvals
 * US-20.03 Gateway key policy: secrets and wiring are refused
 *
 * All over the API: the policy lives in lib/gateway-key-policy.ts and the route is its only door.
 * The anti-vacuity rule of the sheet is followed literally for N01 — the token rows are written
 * first and proven present, so their absence from the response is filtering, not emptiness.
 */
import { expect, test } from "../../fixtures";
import { tc } from "../../support/tc";

const SETTINGS = "/api/control/gateway-settings";

async function putKey(api: import("@playwright/test").APIRequestContext, key: string, value: string) {
  const res = await api.put(SETTINGS, { data: { key, value } });
  const body = (await res.json().catch(() => ({}))) as { error?: string; data?: unknown };
  return { status: res.status(), body };
}

test.describe("SC-20.03.01 Secrets never cross", () => {
  test(...tc("TC-20.03.01-N01", "GET omits both tokens"), async ({ operatorApi, seed, db, tcx }) => {
    // seed both token rows and prove they are there — absence must be filtering, not emptiness
    await seed.config("smsg.ops.token", "qa-read-token-that-must-not-leak");
    await seed.config("smsg.ops.admin.token", "qa-admin-token-that-must-not-leak");
    expect(await db.count("app_config", "key IN ('smsg.ops.token','smsg.ops.admin.token')")).toBe(2);
    const res = await operatorApi.get(SETTINGS);
    expect(res.status()).toBe(200);
    const text = await res.text();
    expect(text).not.toContain("qa-read-token-that-must-not-leak");
    expect(text).not.toContain("qa-admin-token-that-must-not-leak");
    expect(text).not.toContain("smsg.ops.token");
    expect(text).not.toContain("smsg.ops.admin.token");
    // and an ordinary key written the same way IS returned, so the filter is selective
    await seed.config("smsg.cdr.deadline.hours", "36");
    const again = await operatorApi.get(SETTINGS);
    expect(await again.text()).toContain("smsg.cdr.deadline.hours");
    tcx.note("both token rows present in app_config; neither key nor value in the GET body; smsg.cdr.deadline.hours is");
  });

  test(...tc("TC-20.03.01-N02", "PUT of a token is 403"), async ({ operatorApi, db, tcx }) => {
    const r = await putKey(operatorApi, "smsg.ops.admin.token", "new-token");
    expect(r.status).toBe(403);
    expect(r.body.error ?? "").toMatch(/credential/i);
    expect(await db.count("app_config", "key = 'smsg.ops.admin.token' AND value = 'new-token'")).toBe(0);
    tcx.note(`${r.status}: ${r.body.error}`);
  });

  test(...tc("TC-20.03.01-N03", "Shape rule catches an unlisted secret"), async ({ operatorApi, db, tcx }) => {
    const r = await putKey(operatorApi, "smsg.vendor.x.password", "hunter2");
    expect(r.status).toBe(403);
    expect(r.body.error ?? "").toMatch(/credential/i);
    expect(await db.count("app_config", "key = 'smsg.vendor.x.password'")).toBe(0);
    tcx.note(`${r.status}: ${r.body.error}`);
  });

  test(...tc("TC-20.03.01-N04", "Wiring key refused"), async ({ operatorApi, db, tcx }) => {
    const r = await putKey(operatorApi, "smsg.cdr.sink", "file");
    expect(r.status).toBe(400);
    expect(r.body.error ?? "").toMatch(/where messages and records go|traffic is running/i);
    expect(await db.count("app_config", "key = 'smsg.cdr.sink' AND value = 'file'")).toBe(0);
    tcx.note(`${r.status}: ${r.body.error}`);
  });

  test(...tc("TC-20.03.01-N05", "Foreign prefix is 400"), async ({ operatorApi, db, tcx }) => {
    const r = await putKey(operatorApi, "postgres.url", "jdbc:postgresql://evil/db");
    expect(r.status).toBe(400);
    expect(r.body.error ?? "").toMatch(/not a gateway configuration key|smsg\./i);
    expect(await db.count("app_config", "key = 'postgres.url'")).toBe(0);
    tcx.note(`${r.status}: ${r.body.error}`);
  });

  test(...tc("TC-20.03.01-P01", "Allowed uncurated key writes"), async ({ operatorApi, db, seed, tcx }) => {
    seed.cleanup(async () => { await db.q("DELETE FROM app_config WHERE key = 'smsg.whitelist.max.variable'"); });
    const r = await putKey(operatorApi, "smsg.whitelist.max.variable", "8");
    expect(r.status).toBe(200);
    const row = await db.one<{ value: string; enabled: boolean }>("SELECT value, enabled FROM app_config WHERE key = 'smsg.whitelist.max.variable'");
    expect(row.value).toBe("8");
    expect(row.enabled).toBe(true);
    tcx.note(`200; app_config smsg.whitelist.max.variable = ${row.value}`);
  });
});
