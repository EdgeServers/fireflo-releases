/**
 * EP-22 Customer Portal — Sign-in & Self-service
 * US-22.05 Portal guards
 */
import { expect, test } from "../../fixtures";
import { carryCookie, mintPortalContext, PORTAL_COOKIE } from "../../fixtures/auth";
import { tc } from "../../support/tc";

test.describe("SC-22.05.01 Disabled mid-session", () => {
  test(...tc("TC-22.05.01-N01", "Disabling the account ends access on the next request"), async ({ browser, db, seed, tcx }) => {
    const id = await seed.account({ label: "QA disabled mid-session", email: `${seed.prefix}mid-${Date.now().toString(36)}@fireflo.test` });
    const api = await mintPortalContext(db, id);
    expect((await api.get("/api/mis/overview")).status()).toBe(200);
    await db.q("UPDATE app_account SET enabled = false WHERE id = $1", [id]);
    const after = await api.get("/api/mis/overview");
    expect(after.status(), "requireCustomer re-reads app_account on every request").toBe(404);
    const context = await browser.newContext({ storageState: undefined });
    await carryCookie(api, context, PORTAL_COOKIE);
    const page = await context.newPage();
    const res = await page.goto("/overview");
    // notFound() renders at the same URL, so the status is the signal — and the dashboard must not be there
    expect(res?.status(), "/overview for a disabled account").toBe(404);
    await expect(page.getByRole("link", { name: "Statement" })).toHaveCount(0);
    tcx.note(`API 200 → ${after.status()} after disable; /overview → ${res?.status()}`);
    await context.close();
    await api.dispose();
  });

  test(...tc("TC-22.05.01-P01", "Re-enable restores"), async ({ db, seed, tcx }) => {
    const id = await seed.account({ label: "QA re-enabled", email: `${seed.prefix}re-${Date.now().toString(36)}@fireflo.test` });
    const api = await mintPortalContext(db, id);
    await db.q("UPDATE app_account SET enabled = false WHERE id = $1", [id]);
    expect((await api.get("/api/mis/overview")).status()).toBe(404);
    await db.q("UPDATE app_account SET enabled = true WHERE id = $1", [id]);
    const back = await api.get("/api/mis/overview");
    expect(back.status()).toBe(200);
    tcx.note(`404 while disabled, ${back.status()} once re-enabled — same session cookie`);
    await api.dispose();
  });

  test(...tc("TC-22.05.01-N02", "portal_access is sampled, not per request"), async ({ db, seed, tcx }) => {
    const id = await seed.account({ label: "QA sampled", email: `${seed.prefix}sample-${Date.now().toString(36)}@fireflo.test` });
    const api = await mintPortalContext(db, id);
    const since = new Date();
    for (let i = 0; i < 20; i++) expect((await api.get("/api/mis/overview")).status()).toBe(200);
    await new Promise((r) => setTimeout(r, 1000));
    const rows = await db.count("app_customer_access_log", "event = 'portal_access' AND account_id = $1 AND occurred_at >= $2", [id, since]);
    expect(rows, "one row per (account, ip) per window").toBe(1);
    tcx.note(`20 requests → ${rows} portal_access row`);
    await api.dispose();
  });
});
