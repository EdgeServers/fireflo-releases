/**
 * EP-22 Customer Portal — Sign-in & Self-service
 * US-22.01 Magic-link sign-in
 *
 * The mail leg is real: the panel sends over TLS to the suite's SMTP sink on 4465 and the tests
 * read the spool. Rate-limit cases are @serial: the limiter is in-process and per address/origin
 * for 15 minutes, so they run last in this file and use addresses nothing else touches.
 */
import { expect, test } from "../../fixtures";
import { freshRequestContext, issueLoginTokenFor, PORTAL_COOKIE } from "../../fixtures/auth";
import { startPanelVariant } from "../../fixtures/panel-variant";
import { BASELINE } from "../../fixtures/seed";
import { mailbox } from "../../fixtures/sinks";
import { followLink, LINK_FAILED_MESSAGE, LINK_SENT_MESSAGE, requestAndReceiveLink, requestLoginLink, signOutPortal } from "../../support/flows/portal";
import { tc } from "../../support/tc";
import { SERIAL } from "../../support/tags";

/**
 * A portal account of the test's own. Five tokens per account per 15 minutes is the panel's
 * budget — counted from app_login_token, so tokens the suite inserts directly count too — and a
 * file of link tests sharing one account exhausts it on the third worker.
 */
async function ownAccount(seed: import("../../fixtures").Seed): Promise<{ id: string; email: string; label: string }> {
  const label = `QA portal ${Date.now().toString(36)}`;
  const email = `${seed.prefix}link-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}@fireflo.test`;
  const id = await seed.account({ email, label });
  return { id, email, label };
}

async function audit(db: import("../../fixtures").Db, since: Date, event: string, email?: string) {
  return db.q<{ event: string; account_id: string | null; email: string | null; detail: Record<string, unknown> | null }>(
    `SELECT event, account_id, email, detail FROM app_customer_access_log
      WHERE occurred_at >= $1 AND event = $2 AND ($3::text IS NULL OR email = $3 OR account_id = $3) ORDER BY id`,
    [since, event, email ?? null],
  );
}

test.describe("SC-22.01.01 Request a link", () => {
  test(...tc("TC-22.01.01-P01", "Known address gets a token and an email"), async ({ db, seed, tcx }) => {
    const ctx = await freshRequestContext();
    const own = await ownAccount(seed);
    const email = own.email;
    const since = mailbox.mark();
    const before = await db.count("app_login_token", "account_id = $1", [own.id]);
    const r = await requestLoginLink(ctx, email);
    expect(r.status).toBe(200);
    expect(r.text).toBe(LINK_SENT_MESSAGE);
    const row = await db.one<{ used_at: string | null; minutes: number }>(
      `SELECT used_at, round(extract(epoch from (expires_at - created_at)) / 60)::int AS minutes
         FROM app_login_token WHERE account_id = $1 ORDER BY created_at DESC LIMIT 1`, [own.id]);
    expect(await db.count("app_login_token", "account_id = $1", [own.id])).toBe(before + 1);
    expect(row.used_at).toBeNull();
    expect(row.minutes).toBe(15);
    const mail = await mailbox.waitFor(since, (m) => m.to.includes(email));
    expect(mail.subject).toBe("Your sign-in link");
    expect(mail.raw).toMatch(/Content-Type: text\/plain/i);
    expect(mail.links.some((l) => /\/verify\?token=/.test(l)), "the sign-in link is in the body").toBe(true);
    expect(mail.port, "delivered over the TLS sink").toBe(4465);
    await ctx.dispose();
    tcx.note(`token row expires in ${row.minutes} min; mail subject "${mail.subject}" via port ${mail.port}`);
  });

  test(...tc("TC-22.01.01-P02", "Same answer for an unknown address"), async ({ db, seed, tcx }) => {
    const ctx = await freshRequestContext();
    const own = await ownAccount(seed);
    const unknown = `nobody-${Date.now().toString(36)}@example.test`;
    const since = new Date();
    const mailSince = mailbox.mark();
    const known = await requestLoginLink(ctx, own.email);
    const r = await requestLoginLink(ctx, unknown);
    expect(r.status).toBe(200);
    expect(r.body, "byte-identical answer").toEqual(known.body);
    expect(await db.count("app_login_token", "created_at >= $1 AND account_id NOT IN (SELECT id FROM app_account)", [since])).toBe(0);
    const denied = await db.waitForRow(
      `SELECT detail FROM app_customer_access_log WHERE occurred_at >= $1 AND event = 'link_denied' AND email = $2`, [since, unknown]);
    expect((denied.detail as { reason?: string }).reason).toBe("unknown_address");
    await new Promise((r) => setTimeout(r, 1500));
    expect(mailbox.all(mailSince).filter((m) => m.to.includes(unknown)).length, "no mail to the unknown address").toBe(0);
    await ctx.dispose();
    tcx.note(`200 identical body; link_denied reason=unknown_address; no token, no mail`);
  });

  test(...tc("TC-22.01.01-P03", "Dev printing prints the link when no SMTP", { requires: ["variants"] }), async ({ db, seed, tcx }) => {
    const own = await ownAccount(seed);
    const v = await startPanelVariant("dev-login-link", { FIREFLO_SMTP_HOST: undefined, FIREFLO_DEV_LOGIN_LINK: "true" });
    try {
      const ctx = await freshRequestContext(v.url);
      const r = await requestLoginLink(ctx, own.email, v.url);
      await ctx.dispose();
      expect(r.status).toBe(200);
      await expect.poll(() => v.output(), { timeout: 15_000 }).toMatch(/FIREFLO_DEV_LOGIN_LINK is on/);
      await expect.poll(() => v.output()).toMatch(/verify\?token=/);
      const printed = /(https?:\/\/\S+\/verify\?token=\S+)/.exec(v.output())?.[1] ?? "";
      expect(await db.count("app_login_token", "account_id = $1 AND used_at IS NULL", [own.id])).toBeGreaterThan(0);
      tcx.note(`200; console printed ${printed.slice(0, 40)}…`);
    } finally {
      await v.stop();
    }
  });

  test(...tc("TC-22.01.01-N03", "No mailer and no dev printing", { requires: ["variants"] }), async ({ tcx }) => {
    const v = await startPanelVariant("no-mailer", { FIREFLO_SMTP_HOST: undefined, FIREFLO_DEV_LOGIN_LINK: undefined });
    try {
      const ctx = await freshRequestContext(v.url);
      const r = await requestLoginLink(ctx, BASELINE.emails.portal, v.url);
      await ctx.dispose();
      expect(r.status).toBe(503);
      expect(r.text).toBe("Sign-in by email is not available on this panel. Ask your account manager.");
      tcx.note(`${r.status}: ${r.text}`);
    } finally {
      await v.stop();
    }
  });

  test(...tc("TC-22.01.01-N04", "Relative base URL sends nothing", { requires: ["variants"] }), async ({ db, seed, tcx }) => {
    const own = await ownAccount(seed);
    const v = await startPanelVariant("relative-base-url", { MIS_PANEL_BASE_URL: "/portal" });
    try {
      const ctx = await freshRequestContext(v.url);
      const since = new Date();
      const mailSince = mailbox.mark();
      const before = await db.count("app_login_token", "account_id = $1", [own.id]);
      const r = await requestLoginLink(ctx, own.email, v.url);
      await ctx.dispose();
      expect(r.status).toBe(200);
      const denied = await db.waitForRow(
        `SELECT detail FROM app_customer_access_log WHERE occurred_at >= $1 AND event = 'link_denied' AND email = $2`, [since, own.email]);
      expect((denied.detail as { reason?: string }).reason).toBe("base_url_unusable");
      expect(await db.count("app_login_token", "account_id = $1", [own.id]), "token budget not spent").toBe(before);
      await new Promise((r) => setTimeout(r, 1500));
      expect(mailbox.all(mailSince).length).toBe(0);
      tcx.note("link_denied reason=base_url_unusable; no token row; no mail");
    } finally {
      await v.stop();
    }
  });

  test(...tc("TC-22.01.01-N05", "SMTP downgrade refused", { requires: ["variants"] }), async ({ db, env, seed, tcx }) => {
    // a plain-text sink on 4587 that answers 454 to STARTTLS; the panel requires TLS
    const own = await ownAccount(seed);
    const v = await startPanelVariant("smtp-plain", { FIREFLO_SMTP_PORT: String(env.smtpPlainPort), FIREFLO_SMTP_SECURE: "false" });
    try {
      const ctx = await freshRequestContext(v.url);
      const since = new Date();
      const mailSince = mailbox.mark();
      const r = await requestLoginLink(ctx, own.email, v.url);
      await ctx.dispose();
      expect(r.status, "the caller still gets the neutral answer").toBe(200);
      const denied = await db.waitForRow(
        `SELECT detail FROM app_customer_access_log WHERE occurred_at >= $1 AND event = 'link_denied' AND email = $2`, [since, own.email]);
      expect((denied.detail as { reason?: string }).reason).toBe("send_failed");
      await new Promise((r) => setTimeout(r, 1500));
      expect(mailbox.all(mailSince).filter((m) => m.port === env.smtpPlainPort).length, "nothing was sent in clear").toBe(0);
      tcx.note(`send_failed: ${JSON.stringify(denied.detail).slice(0, 160)}`);
    } finally {
      await v.stop();
    }
  });

  test(...tc("TC-22.01.01-N01", "Rate limit per address", { tags: [SERIAL], requires: ["variants"] }), async ({ db, seed, tcx }) => {
    // an account of this test's own, so the per-account window is not shared — and a panel of its
    // own, because the per-ORIGIN limiter (20 per 15 min from 127.0.0.1) is shared by the whole run
    const email = `${seed.prefix}limit-${Date.now().toString(36)}@fireflo.test`;
    const id = await seed.account({ email });
    const v = await startPanelVariant("rate-limit-address", {});
    const ctx = await freshRequestContext(v.url);
    const since = new Date();
    const answers: number[] = [];
    try {
      for (let i = 0; i < 6; i++) answers.push((await requestLoginLink(ctx, email, v.url)).status);
    } finally {
      await ctx.dispose();
      await v.stop();
    }
    expect(answers.every((s) => s === 200), "every answer is the neutral 200").toBe(true);
    const tokens = await db.count("app_login_token", "account_id = $1", [id]);
    expect(tokens, "five issued, the sixth denied").toBe(5);
    const denied = await audit(db, since, "link_denied", email);
    expect(denied.map((d) => (d.detail as { reason?: string })?.reason)).toContain("rate_limited");
    tcx.note(`6 requests → ${tokens} tokens; link_denied rate_limited ×${denied.length}`);
  });

  test(...tc("TC-22.01.01-N02", "Rate limit per IP", { tags: [SERIAL], requires: ["variants"] }), async ({ db, tcx }) => {
    // 21 requests from one origin for unknown addresses; the per-origin limiter is 20 per window and
    // in-process, so this runs on a panel of its own where nothing else has spent the budget
    const v = await startPanelVariant("rate-limit-ip", {});
    const ctx = await freshRequestContext(v.url);
    const since = new Date();
    let last: { status: number; text: string } = { status: 0, text: "" };
    try {
      for (let i = 0; i < 21; i++) last = await requestLoginLink(ctx, `nobody-${i}-${Date.now().toString(36)}@example.test`, v.url);
    } finally {
      await ctx.dispose();
      await v.stop();
    }
    expect(last.status, "the 21st is refused outright").toBe(429);
    // the per-origin refusal is answered before the body is read and before any database work — a
    // flood must cost nothing — so the record of it is the 429 itself, not an audit row
    const denied = await audit(db, since, "link_denied");
    expect(denied.filter((d) => (d.detail as { reason?: string })?.reason === "unknown_address").length, "the 20 allowed ones were processed").toBe(20);
    tcx.note(`21st answered ${last.status}; 20 unknown_address audits, the 21st cost no database work`);
  });
});

test.describe("SC-22.01.02 Redeem the link (verify) — including the spent-link fix", () => {
  test(...tc("TC-22.01.02-P01", "Fresh link signs in and lands on /overview"), async ({ anonPage, anonContext, db, seed, tcx }) => {
    const own = await ownAccount(seed);
    const ctx = await freshRequestContext();
    const since = new Date();
    const { link } = await requestAndReceiveLink(ctx, own.email);
    await ctx.dispose();
    expect(await followLink(anonPage, link)).toBe("signed-in");
    await expect(anonPage.getByText(own.label)).toBeVisible();
    const session = (await (await anonContext.request.get("/api/mis/auth/session")).json()) as { user?: { name: string } };
    expect(session.user?.name).toBe(own.id);
    await db.waitForRow(`SELECT 1 FROM app_customer_access_log WHERE occurred_at >= $1 AND event = 'link_redeemed' AND account_id = $2`, [since, own.id]);
    await db.waitForRow(`SELECT 1 FROM app_customer_access_log WHERE occurred_at >= $1 AND event = 'portal_access' AND account_id = $2`, [since, own.id]);
    tcx.note(`landed on ${anonPage.url()}; session ${session.user?.name}; link_redeemed then portal_access`);
  });

  test(...tc("TC-22.01.02-P02", "Token is consumed"), async ({ anonPage, db, tcx }) => {
    const token = await issueLoginTokenFor(db, BASELINE.accounts.portal);
    const hash = (await import("node:crypto")).createHash("sha256").update(token).digest("hex");
    expect((await db.one<{ used_at: string | null }>("SELECT used_at FROM app_login_token WHERE token_hash = $1", [hash])).used_at).toBeNull();
    expect(await followLink(anonPage, `/verify?token=${token}`)).toBe("signed-in");
    const after = await db.one<{ used_at: string | null }>("SELECT used_at FROM app_login_token WHERE token_hash = $1", [hash]);
    expect(after.used_at).not.toBeNull();
    tcx.note(`used_at ${after.used_at}`);
  });

  test(...tc("TC-22.01.02-N01", "Replaying a spent link from a clean browser is refused"), async ({ browser, db, tcx }) => {
    const token = await issueLoginTokenFor(db, BASELINE.accounts.portal);
    const first = await browser.newContext({ storageState: undefined });
    expect(await followLink(await first.newPage(), `/verify?token=${token}`)).toBe("signed-in");
    await first.close();
    const since = new Date();
    const second = await browser.newContext({ storageState: undefined });
    const page = await second.newPage();
    expect(await followLink(page, `/verify?token=${token}`)).toBe("rejected");
    const session = ((await (await second.request.get("/api/mis/auth/session")).json().catch(() => null)) ?? {}) as { user?: unknown };
    expect(session.user ?? null).toBeNull();
    await db.waitForRow(`SELECT 1 FROM app_customer_access_log WHERE occurred_at >= $1 AND event = 'link_rejected'`, [since]);
    await second.close();
    tcx.note(`second browser: "${LINK_FAILED_MESSAGE}", session null, link_rejected logged`);
  });

  test(...tc("TC-22.01.02-N02", "Replaying a spent link while ALREADY signed in is refused (0.11 fix)"), async ({ anonPage, db, tcx }) => {
    const token = await issueLoginTokenFor(db, BASELINE.accounts.portal);
    expect(await followLink(anonPage, `/verify?token=${token}`)).toBe("signed-in");
    const since = new Date();
    // same browser, still signed in, same link: pre-fix this showed Overview while the server logged link_rejected
    expect(await followLink(anonPage, `/verify?token=${token}`)).toBe("rejected");
    await expect(anonPage).not.toHaveURL(/\/overview/);
    await db.waitForRow(`SELECT 1 FROM app_customer_access_log WHERE occurred_at >= $1 AND event = 'link_rejected'`, [since]);
    tcx.note(`replay while signed in: "${LINK_FAILED_MESSAGE}" at ${anonPage.url()}; link_rejected logged`);
  });

  test(...tc("TC-22.01.02-N03", "Expired link is refused"), async ({ anonPage, db, tcx }) => {
    const token = await issueLoginTokenFor(db, BASELINE.accounts.portal, { ttlMinutes: -1 });
    expect(await followLink(anonPage, `/verify?token=${token}`)).toBe("rejected");
    tcx.note("token with expires_at in the past → rejected");
  });

  test(...tc("TC-22.01.02-N04", "Link for a disabled account is refused"), async ({ anonPage, anonContext, db, seed, tcx }) => {
    const email = `${seed.prefix}disabled-${Date.now().toString(36)}@fireflo.test`;
    const id = await seed.account({ email, label: "QA disabled after issue" });
    const token = await issueLoginTokenFor(db, id);
    await db.q("UPDATE app_account SET enabled = false WHERE id = $1", [id]);
    await anonPage.goto(`/verify?token=${token}`);
    await anonPage.waitForTimeout(3000);
    // whatever the verify page shows, the account must not be usable
    const overview = await anonContext.request.get("/api/mis/overview");
    expect(overview.status(), "a disabled account cannot read its portal").toBe(404);
    const cookie = (await anonContext.cookies()).find((c) => c.name === PORTAL_COOKIE);
    tcx.note(`verify → ${anonPage.url()}; /api/mis/overview ${overview.status()}; portal cookie ${cookie ? "present" : "absent"}`);
  });

  test(...tc("TC-22.01.02-P03", "Sign out ends the session"), async ({ anonPage, anonContext, db, tcx }) => {
    const token = await issueLoginTokenFor(db, BASELINE.accounts.portal);
    expect(await followLink(anonPage, `/verify?token=${token}`)).toBe("signed-in");
    await signOutPortal(anonPage);
    expect((await anonContext.cookies()).find((c) => c.name === PORTAL_COOKIE)).toBeFalsy();
    await anonPage.goto("/overview");
    await expect(anonPage).not.toHaveURL(/\/overview/);
    tcx.note(`after sign-out /overview → ${anonPage.url()}`);
  });
});
