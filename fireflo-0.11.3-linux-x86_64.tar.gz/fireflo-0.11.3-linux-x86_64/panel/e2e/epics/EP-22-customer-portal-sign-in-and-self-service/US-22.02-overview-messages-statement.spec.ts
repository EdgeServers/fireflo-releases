/**
 * EP-22 Customer Portal — Sign-in & Self-service
 * US-22.02 Overview, messages, statement
 *
 * Two accounts with traffic; the portal signed in as A must only ever see A. The rows are seeded
 * as the gateway would have written them (cdr_submit + cdr_final).
 */
import { expect, test } from "../../fixtures";
import { BASELINE } from "../../fixtures/seed";
import { tc } from "../../support/tc";

const A = BASELINE.accounts.portal;
const B = BASELINE.accounts.b;

test.describe("SC-22.02.01 Own data only", () => {
  test(...tc("TC-22.02.01-P01", "Overview shows only A"), async ({ portalApi, seed, db, tcx }) => {
    await seed.cdrs({ accountId: A, outcome: "DELIVRD" }, 4);
    await seed.cdrs({ accountId: A, outcome: "UNDELIV" }, 2);
    await seed.cdrs({ accountId: B, outcome: "DELIVRD" }, 3);
    const api = await portalApi(A);
    const res = await api.get("/api/mis/overview?range=7d");
    expect(res.status()).toBe(200);
    const { data } = (await res.json()) as { data: { tiles: { sent: number; delivered: number; failed: number }; since: string; until: string } };
    const sent = await db.count("cdr_submit", "account_id = $1 AND submitted_at >= $2 AND submitted_at < $3", [A, data.since, data.until]);
    const delivered = await db.count("cdr_final f JOIN cdr_submit s USING (gateway_msg_id)", "s.account_id = $1 AND f.final_state = 'DELIVERED' AND s.submitted_at >= $2 AND s.submitted_at < $3", [A, data.since, data.until]);
    const bSent = await db.count("cdr_submit", "account_id = $1", [B]);
    expect(data.tiles.sent).toBe(sent);
    expect(data.tiles.delivered).toBe(delivered);
    expect(bSent, "B has traffic the tiles must not include").toBeGreaterThan(0);
    expect(data.tiles.sent).toBeLessThan(sent + bSent);
    tcx.note(`tiles sent ${data.tiles.sent} = psql ${sent}; delivered ${data.tiles.delivered} = psql ${delivered}; B's ${bSent} excluded`);
  });

  test(...tc("TC-22.02.01-P02", "Messages export CSV has customer columns"), async ({ portalApi, seed, db, tcx }) => {
    await seed.cdrs({ accountId: A, outcome: "DELIVRD" }, 3);
    await seed.cdrs({ accountId: B, outcome: "DELIVRD" }, 2);
    const api = await portalApi(A);
    // ask for the operator-only columns too: the allow-list must drop them rather than honour them
    const res = await api.get("/api/mis/messages/export?columns=submittedAt,destAddr,sourceAddr,gatewayMsgId,cost,vendor,margin,price");
    expect(res.status()).toBe(200);
    expect(res.headers()["content-type"]).toContain("text/csv");
    const csv = await res.text();
    const lines = csv.trim().split(/\r?\n/);
    const header = lines[0].toLowerCase();
    expect(header).not.toMatch(/\bcost\b|\bvendor\b|\bmargin\b/);
    const total = await db.count("cdr_submit", "account_id = $1", [A]);
    expect(lines.length - 1, "one row per message of A").toBe(total);
    const bIds = (await db.q<{ gateway_msg_id: string }>("SELECT gateway_msg_id FROM cdr_submit WHERE account_id = $1", [B])).map((r) => r.gateway_msg_id);
    for (const id of bIds) expect(csv).not.toContain(id);
    tcx.note(`header: ${lines[0].slice(0, 100)}; ${lines.length - 1} rows = A's ${total}`);
  });

  test(...tc("TC-22.02.01-N01", "Statement for B via ?account=B is refused"), async ({ portalApi, tcx }) => {
    const api = await portalApi(A);
    const month = new Date().toISOString().slice(0, 7);
    const own = await api.get(`/api/mis/statement?month=${month}`);
    const other = await api.get(`/api/mis/statement?month=${month}&account=${B}`);
    expect(own.status(), "the customer's own statement answers").toBe(200);
    expect(other.status(), "assertInScope: 404, not 403").toBe(404);
    tcx.note(`own ${own.status()}, ?account=${B} → ${other.status()}`);
  });

  test(...tc("TC-22.02.01-N02", "Message detail of B's id is not visible"), async ({ portalApi, seed, tcx }) => {
    const [bId] = await seed.cdrs({ accountId: B, outcome: "DELIVRD" }, 1);
    await seed.cdrs({ accountId: A, outcome: "DELIVRD" }, 1);
    const api = await portalApi(A);
    const list = await api.get("/api/mis/messages?limit=200&columns=gatewayMsgId,destAddr,submittedAt");
    expect(list.status()).toBe(200);
    const text = await list.text();
    expect(text).not.toContain(bId);
    // and naming B's id in a query does not fetch it either
    const crafted = await api.get(`/api/mis/messages?limit=200&columns=gatewayMsgId&id=${bId}&gatewayMsgId=${bId}`);
    expect(await crafted.text()).not.toContain(bId);
    tcx.note(`B's ${bId.slice(0, 8)}… absent from A's list and from a crafted query`);
  });
});
