/**
 * EP-18 Operator Panel — Accounts, Logins & Billing
 * US-18.01 Account catalogue: create, edit, delete, search
 *
 * On the operator surface an account is not "created" by a dialog: the catalogue's id box opens
 * the account's page ("an account exists the moment a login names it") and the Settings tab's Save
 * writes the catalogue row. That is the flow these cases drive, with the database as the oracle
 * every time — a refusal on screen with a row behind it is the bug still present.
 */
import { expect, test } from "../../fixtures";
import { openAccount, openAccountsPage, openAccountById, saveAccountSettings } from "../../support/flows/accounts";
import { tc } from "../../support/tc";

test.describe("SC-18.01.01 Create and collide", () => {
  test(...tc("TC-18.01.01-P01", "Create lands in app_account"), async ({ page, db, seed, tcx }) => {
    const id = seed.name(`created-${Date.now().toString(36)}`);
    seed.cleanup(async () => { await db.q("DELETE FROM app_account WHERE id = $1", [id]); });
    await openAccountsPage(page);
    await openAccountById(page, id);
    await openAccount(page, id, "settings");
    await saveAccountSettings(page, { label: "QA created via UI", email: `${id}@fireflo.test` });
    const row = await db.waitForRow<{ label: string; email: string; enabled: boolean }>("SELECT label, email, enabled FROM app_account WHERE id = $1", [id]);
    expect(row).toEqual({ label: "QA created via UI", email: `${id}@fireflo.test`, enabled: true });
    await openAccountsPage(page);
    await page.getByLabel("Search accounts").fill(id);
    await expect(page.getByText("QA created via UI").first()).toBeVisible();
    tcx.note(`app_account ${id}: label/email/enabled as entered; listed in the catalogue`);
  });

  test(...tc("TC-18.01.01-P02", "Edit label and email persists"), async ({ page, db, seed, tcx }) => {
    const id = await seed.account({ label: "QA before edit", email: `before-${Date.now().toString(36)}@fireflo.test` });
    await openAccount(page, id, "settings");
    await saveAccountSettings(page, { label: "QA after edit", email: `after-${id}@fireflo.test` });
    await expect.poll(async () => (await db.one<{ label: string }>("SELECT label FROM app_account WHERE id = $1", [id])).label).toBe("QA after edit");
    const row = await db.one<{ label: string; email: string }>("SELECT label, email FROM app_account WHERE id = $1", [id]);
    expect(row.email).toBe(`after-${id}@fireflo.test`);
    await openAccountsPage(page);
    await page.getByLabel("Search accounts").fill(id);
    await expect(page.getByText("QA after edit").first()).toBeVisible();
    tcx.note(`row now ${row.label} / ${row.email}; catalogue reflects it`);
  });

  test(...tc("TC-18.01.01-N01", "Duplicate id is refused, not overwritten"), async ({ page, db, seed, tcx }) => {
    const email = `keep-${Date.now().toString(36)}@fireflo.test`;
    const id = await seed.account({ label: "QA existing", email });
    // "creating" an id that exists opens the existing account rather than a blank one…
    await openAccountsPage(page);
    await openAccountById(page, id);
    await expect(page.getByText("QA existing").first()).toBeVisible();
    // …and its Settings tab is pre-filled with what is there, so nothing is silently replaced
    await openAccount(page, id, "settings");
    await expect(page.locator("#acct-email")).toHaveValue(email);
    await expect(page.locator("#acct-label")).toHaveValue("QA existing");
    const row = await db.one<{ label: string; email: string }>("SELECT label, email FROM app_account WHERE id = $1", [id]);
    expect(row, "nothing written by opening").toEqual({ label: "QA existing", email });
    tcx.note(`opening ${id} shows the existing account; settings pre-filled; row unchanged`);
    expect(row.email, "the historical bug silently overwrote the email").toBe(email);
  });

  test(...tc("TC-18.01.01-N02", "Id equal to a vendor worker name is refused"), async ({ page, db, seed, tcx }) => {
    const vendor = seed.name(`sim-${Date.now().toString(36)}`);
    await db.q("INSERT INTO app_worker (name, type, enabled, label) VALUES ($1, 'smppclient', true, 'QA vendor') ON CONFLICT (name) DO NOTHING", [vendor]);
    seed.cleanup(async () => {
      await db.q("DELETE FROM app_account WHERE id = $1", [vendor]);
      await db.q("DELETE FROM app_worker WHERE name = $1", [vendor]);
    });
    await openAccountsPage(page);
    await openAccountById(page, vendor);
    await openAccount(page, vendor, "settings");
    const outcome = await saveAccountSettings(page, { label: "QA vendor-named account" }, { expectRefusal: true });
    const written = await db.count("app_account", "id = $1", [vendor]);
    tcx.note(`save → ${outcome.message ? `refused: ${outcome.message.slice(0, 120)}` : "accepted"}; rows written ${written}`);
    expect(written, "an account named like a vendor makes app_rate_rule.scope ambiguous and must be refused").toBe(0);
  });

  test(...tc("TC-18.01.01-N03", "Invalid id characters refused"), async ({ page, db, seed, tcx }) => {
    const bad = `${seed.prefix}bad id!`;
    seed.cleanup(async () => { await db.q("DELETE FROM app_account WHERE id = $1", [bad]); });
    await openAccountsPage(page);
    await openAccountById(page, bad);
    await openAccount(page, bad, "settings");
    const outcome = await saveAccountSettings(page, { label: "QA bad id" }, { expectRefusal: true });
    const written = await db.count("app_account", "id = $1", [bad]);
    tcx.note(`save → ${outcome.message ? `refused: ${outcome.message.slice(0, 120)}` : "accepted"}; rows written ${written}`);
    expect(written, "an id with a space and punctuation must not be written").toBe(0);
  });

  test(...tc("TC-18.01.01-P03", "Search and columns"), async ({ page, seed, tcx }) => {
    await seed.account({ label: "QA searchable alpha" });
    await seed.account({ label: "ZZ not matching" });
    await openAccountsPage(page);
    const search = page.getByLabel("Search accounts");
    await search.fill("QA searchable");
    await expect(page.getByText("QA searchable alpha").first()).toBeVisible();
    await expect(page.getByText("ZZ not matching")).toHaveCount(0);
    // hide a column and see it stay hidden across a reload
    await page.getByRole("button", { name: "Columns" }).click();
    const email = page.getByLabel("Email", { exact: true });
    await email.uncheck();
    await expect(page.getByRole("columnheader", { name: "Email" })).toHaveCount(0);
    await page.reload();
    await page.getByRole("button", { name: "Columns" }).click();
    await expect(page.getByLabel("Email", { exact: true })).not.toBeChecked();
    const stored = await page.evaluate(() => Object.keys(window.localStorage).filter((k) => /column/i.test(k)));
    tcx.note(`search filtered to the match; Email column hidden and persisted (${stored.join(",")})`);
  });
});
