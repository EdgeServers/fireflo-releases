/**
 * EP-18 Operator Panel — Accounts, Logins & Billing
 * US-18.02 Logins (credentials) with once-shown secrets
 *
 * The bind and REST halves need the gateway (mode A brings it up; mode B points at one) and are
 * Blocked without it. The secret-handling half is pure panel + database.
 */
import { expect, test } from "../../fixtures";
import { bindAttempt, connectEsme } from "../../fixtures/smpp";
import { awaitGatewayAdopts } from "../../fixtures/gateway";
import { BASELINE } from "../../fixtures/seed";
import { addLoginViaForm, openAccount } from "../../support/flows/accounts";
import { tc } from "../../support/tc";

test.describe("SC-18.02.01 Create login → bind", () => {
  test(...tc("TC-18.02.01-P01", "SMPP login binds after one poll", { requires: ["gateway"] }), async ({ page, db, seed, tcx }) => {
    const account = await seed.account({ label: "QA login owner" });
    const systemId = seed.name(`l1-${Date.now().toString(36)}`);
    const password = "qa-once-shown-secret-1";
    seed.cleanup(async () => { await db.q("DELETE FROM app_credential WHERE system_id = $1", [systemId]); });
    await openAccount(page, account, "logins");
    await addLoginViaForm(page, { type: "SMPP", systemId, password, product: BASELINE.product });
    await expect(page.getByText(systemId)).toBeVisible();
    const t0 = Date.now();
    await awaitGatewayAdopts(async () => (await bindAttempt({ systemId, password })).status === 0, { nudge: false, timeoutMs: 40_000 });
    const bind = await bindAttempt({ systemId, password });
    expect(bind.status, "ESME_ROK").toBe(0);
    tcx.note(`bound with the new login after ${((Date.now() - t0) / 1000).toFixed(1)}s (poll interval 2s)`);
  });

  test(...tc("TC-18.02.01-P02", "Secret shown once only"), async ({ page, db, seed, operatorApi, tcx }) => {
    const account = await seed.account({ label: "QA secret owner" });
    const systemId = seed.name(`l2-${Date.now().toString(36)}`);
    const password = "qa-secret-never-returned-2";
    seed.cleanup(async () => { await db.q("DELETE FROM app_credential WHERE system_id = $1", [systemId]); });
    await openAccount(page, account, "logins");
    await addLoginViaForm(page, { type: "SMPP", systemId, password, product: BASELINE.product });
    await expect(page.getByText(systemId)).toBeVisible();
    // the row exists with the password stored…
    const row = await db.one<{ password: string }>("SELECT password FROM app_credential WHERE system_id = $1", [systemId]);
    expect(row.password).toBe(password);
    // …and neither the page after a reload nor the API ever carries it
    await page.reload();
    await expect(page.getByText(systemId)).toBeVisible();
    expect(await page.content()).not.toContain(password);
    const api = await operatorApi.get("/api/control/credentials");
    const text = await api.text();
    expect(text).not.toContain(password);
    // secrets are read as booleans, never as values (lib/credentials.ts PROJECTION)
    expect(text).toMatch(/"has_password"|"hasPassword"|"password":\s*"(stored|unset)"/);
    expect(text).not.toMatch(/"password":\s*"(?!stored|unset)[^"]/);
    expect(text).not.toMatch(/"api_key":\s*"(?!stored|unset)[^"]|"apiKey":\s*"(?!stored|unset)[^"]/);
    tcx.note("password stored; absent from the reloaded page and from GET /api/control/credentials (booleans only)");
  });

  test(...tc("TC-18.02.01-P03", "HTTP login authenticates", { requires: ["gateway"] }), async ({ page, db, seed, env, tcx }) => {
    const account = await seed.account({ label: "QA http owner" });
    await seed.balance({ accountId: account, balance: 500_000 });
    const systemId = seed.name(`h1-${Date.now().toString(36)}`);
    const password = "qa-http-secret-3";
    seed.cleanup(async () => { await db.q("DELETE FROM app_credential WHERE system_id = $1", [systemId]); });
    await openAccount(page, account, "logins");
    await addLoginViaForm(page, { type: "HTTP", systemId, password, product: BASELINE.product });
    await expect(page.getByText(systemId)).toBeVisible();
    const auth = "Basic " + Buffer.from(`${systemId}:${password}`).toString("base64");
    let status = 0;
    await awaitGatewayAdopts(async () => {
      status = (await fetch(`${env.gatewayApiUrl}/secure/balance`, { headers: { Authorization: auth } })).status;
      return status === 200;
    }, { nudge: false, timeoutMs: 40_000 });
    expect(status).toBe(200);
    tcx.note(`GET /secure/balance with the new HTTP login → ${status}`);
  });

  test(...tc("TC-18.02.01-N01", "Duplicate system_id refused"), async ({ page, db, seed, tcx }) => {
    const account = await seed.account({ label: "QA dup owner" });
    const existing = await seed.credential({ accountId: account, product: BASELINE.product });
    await openAccount(page, account, "logins");
    await addLoginViaForm(page, { type: "SMPP", systemId: existing.systemId, password: "another-secret-4", product: BASELINE.product });
    const refusal = page.getByText(/already the lookup key|already/i).first();
    await expect(refusal).toBeVisible();
    expect(await db.count("app_credential", "system_id = $1", [existing.systemId]), "still exactly one row").toBe(1);
    tcx.note(`refused: ${(await refusal.textContent())?.slice(0, 120)}`);
  });

  test(...tc("TC-18.02.01-N02", "Disabled login refuses NEW binds but keeps existing ones", { requires: ["gateway"] }), async ({ page, db, seed, tcx }) => {
    const account = await seed.account({ label: "QA disable owner" });
    const login = await seed.credential({ accountId: account, product: BASELINE.product });
    await awaitGatewayAdopts(async () => (await bindAttempt(login)).status === 0, { timeoutMs: 40_000 });
    const first = await connectEsme(login);
    expect(first.bound).toBe(true);
    try {
      await openAccount(page, account, "logins");
      const row = page.locator("tr", { hasText: login.systemId });
      await row.getByRole("checkbox").first().uncheck().catch(async () => { await row.getByRole("button", { name: /Disable/ }).click(); });
      await expect.poll(async () => (await db.one<{ enabled: boolean }>("SELECT enabled FROM app_credential WHERE id = $1", [login.id])).enabled).toBe(false);
      await awaitGatewayAdopts(async () => (await bindAttempt({ ...login, localAddress: "127.0.0.2" })).status !== 0, { timeoutMs: 40_000 });
      const second = await bindAttempt({ ...login, localAddress: "127.0.0.2" });
      expect(second.status, "a new bind is refused").not.toBe(0);
      const link = await first.enquireLink();
      expect(link.command_status, "the existing session is still bound (Suspend is what drops it)").toBe(0);
      tcx.note(`second bind → 0x${second.status.toString(16)}; first session enquire_link still 0`);
    } finally {
      await first.destroy();
    }
  });

  test(...tc("TC-18.02.01-N03", "allowed_ips typo is validated"), async ({ page, db, seed, tcx }) => {
    const account = await seed.account({ label: "QA ip owner" });
    const systemId = seed.name(`ip-${Date.now().toString(36)}`);
    seed.cleanup(async () => { await db.q("DELETE FROM app_credential WHERE system_id = $1", [systemId]); });
    await openAccount(page, account, "logins");
    await addLoginViaForm(page, { type: "SMPP", systemId, password: "qa-ip-secret-5", product: BASELINE.product, allowedIps: ["10.0.0.999"] });
    const refusal = page.getByText(/10\.0\.0\.999/).first();
    await expect(refusal).toBeVisible();
    expect(await db.count("app_credential", "system_id = $1", [systemId]), "nothing written").toBe(0);
    tcx.note(`refused: ${(await refusal.textContent())?.slice(0, 140)}`);
  });
});
