/**
 * EdgeSmsc — the vendor that misbehaves on command (fireflo-core's test tree, packaged by
 * scripts/loadgen-package so no Maven is needed at run time). One process per vendor; the suite
 * spawns them so that the channel-death cases can SIGKILL exactly the process they mean.
 *
 * Control is one line to its loopback control port; the answer ends with a line "END" for `stats`
 * and is a single "ok …" line otherwise.
 */
import { existsSync } from "node:fs";
import { createConnection } from "node:net";
import path from "node:path";
import { e2eEnv } from "./env";
import type { E2EEnv } from "./env";
import { spawnTracked } from "./process";
import type { Tracked } from "./process";
import { readState } from "./state";
import { waitFor, waitForPort } from "../support/wait";

export interface EdgeStats {
  pdus: number;
  distinct: number;
  submitsPerMessage: number;
  refused: number;
  unreadable: number;
  binds: number;
  bindsRefused: number;
  dlrsSent: number;
  dlrsFailed: number;
  sessions: number;
}

export interface EdgeSmsc {
  name: string;
  port: number;
  controlPort: number;
  proc: Tracked | null;
  control(line: string): Promise<string>;
  stats(): Promise<EdgeStats>;
  delay(ms: number): Promise<string>;
  refuse(status: number | string, percent: number): Promise<string>;
  accept(): Promise<string>;
  hang(on: boolean): Promise<string>;
  drop(): Promise<string>;
  binds(mode: "refuse" | "accept"): Promise<string>;
  dlr(state: "DELIVRD" | "UNDELIV" | "EXPIRED" | "REJECTD" | "ACCEPTD", err?: string, delayMs?: number): Promise<string>;
  dlrOff(): Promise<string>;
  dlrBogus(): Promise<string>;
  reset(): Promise<string>;
  /** the behaviour every test starts from: no delay, accept everything, receipts DELIVRD after 50 ms */
  baseline(): Promise<void>;
  /** wait until the gateway has bound (sessions >= n) */
  waitBound(n?: number, timeoutMs?: number): Promise<EdgeStats>;
  /** SIGKILL the child we spawned; the vendor's channel dies without an unbind */
  kill9(): Promise<void>;
  /** start it again on the same ports */
  restart(): Promise<void>;
  stop(): Promise<void>;
}

export function loadgenDir(env: E2EEnv = e2eEnv()): string {
  return path.join(env.runDir, "loadgen");
}

function send(port: number, line: string, timeoutMs = 10_000): Promise<string> {
  return new Promise((resolve, reject) => {
    const s = createConnection({ host: "127.0.0.1", port });
    let out = "";
    const timer = setTimeout(() => { s.destroy(); reject(new Error(`EdgeSmsc control ${port}: no answer to '${line}'`)); }, timeoutMs);
    s.on("connect", () => s.write(line + "\n"));
    s.on("data", (d) => {
      out += d.toString();
      if (line.startsWith("stats") ? /\nEND\s*$/.test(out) : /\n/.test(out)) { clearTimeout(timer); s.end(); resolve(out.trim()); }
    });
    s.on("error", (e) => { clearTimeout(timer); reject(e); });
    s.on("close", () => { clearTimeout(timer); resolve(out.trim()); });
  });
}

function parseStats(text: string): EdgeStats {
  const kv: Record<string, number> = {};
  for (const line of text.split("\n")) {
    const m = /^(\w+)=([\d.]+)$/.exec(line.trim());
    if (m) kv[m[1]] = Number(m[2]);
  }
  return {
    pdus: kv.pdus ?? 0, distinct: kv.distinct ?? 0, submitsPerMessage: kv.submitsPerMessage ?? 0, refused: kv.refused ?? 0,
    unreadable: kv.unreadable ?? 0, binds: kv.binds ?? 0, bindsRefused: kv.bindsRefused ?? 0, dlrsSent: kv.dlrsSent ?? 0,
    dlrsFailed: kv.dlrsFailed ?? 0, sessions: kv.sessions ?? 0,
  };
}

export function edgeSmscHandle(name: string, port: number, controlPort: number, proc: Tracked | null): EdgeSmsc {
  const env = e2eEnv();
  const edge: EdgeSmsc = {
    name, port, controlPort, proc,
    control: (line) => send(controlPort, line),
    stats: async () => parseStats(await send(controlPort, "stats")),
    delay: (ms) => edge.control(`delay ${ms}`),
    refuse: (status, percent) => edge.control(`refuse ${typeof status === "number" ? "0x" + status.toString(16) : status} ${percent}`),
    accept: () => edge.control("accept"),
    hang: (on) => edge.control(`hang ${on ? "on" : "off"}`),
    drop: () => edge.control("drop"),
    binds: (mode) => edge.control(`binds ${mode}`),
    dlr: (state, err = "000", delayMs = 50) => edge.control(`dlr ${state} ${err} ${delayMs}`),
    dlrOff: () => edge.control("dlr off"),
    dlrBogus: () => edge.control("dlr bogus"),
    reset: () => edge.control("reset"),
    async baseline() {
      await edge.delay(0); await edge.accept(); await edge.hang(false); await edge.binds("accept"); await edge.dlr("DELIVRD", "000", 50); await edge.reset();
    },
    waitBound: (n = 1, timeoutMs = 60_000) => waitFor(async () => { const s = await edge.stats(); return s.sessions >= n ? s : undefined; }, { timeoutMs, intervalMs: 500, what: `${name} to hold ${n} bound session(s)` }),
    async kill9() {
      if (!edge.proc) throw new Error(`${name}: not spawned by this suite (mode B), cannot kill it`);
      await edge.proc.kill9();
    },
    async restart() {
      if (edge.proc && edge.proc.child.exitCode === null) await edge.proc.stop();
      edge.proc = spawnEdge(env, name, port, controlPort);
      await waitForPort("127.0.0.1", controlPort, 30_000);
      await waitForPort("127.0.0.1", port, 30_000);
    },
    async stop() { if (edge.proc) await edge.proc.stop(); },
  };
  return edge;
}

export function spawnEdge(env: E2EEnv, name: string, port: number, controlPort: number): Tracked {
  const dir = loadgenDir(env);
  if (!existsSync(path.join(dir, "classes", "loadgen", "EdgeSmsc.class"))) throw new Error(`EdgeSmsc is not packaged at ${dir}; global setup runs scripts/loadgen-package there`);
  return spawnTracked(name, "java", ["-cp", `classes:lib/*`, "loadgen.EdgeSmsc", "--port", String(port), "--control-port", String(controlPort)], { cwd: dir });
}

/** The two vendors global setup started, addressed by name; a test resets them to baseline first. */
export function edgeA(): EdgeSmsc {
  const env = e2eEnv();
  const pid = readState().pids.find((p) => p.name === "edge-a");
  return edgeSmscHandle("edge-a", env.edgeA.port, env.edgeA.control, pid ? trackedByPid("edge-a", pid.pid) : null);
}
export function edgeB(): EdgeSmsc {
  const env = e2eEnv();
  const pid = readState().pids.find((p) => p.name === "edge-b");
  return edgeSmscHandle("edge-b", env.edgeB.port, env.edgeB.control, pid ? trackedByPid("edge-b", pid.pid) : null);
}

/** A minimal handle on a process another Playwright process spawned (the PID is what state.json holds). */
function trackedByPid(name: string, pid: number): Tracked {
  const env = e2eEnv();
  const gone = () => new Promise<boolean>((resolve) => { try { process.kill(pid, 0); resolve(false); } catch { resolve(true); } });
  const signal = (sig: NodeJS.Signals) => { try { process.kill(-pid, sig); } catch { try { process.kill(pid, sig); } catch { /* gone */ } } };
  const child = { pid, exitCode: null } as unknown as Tracked["child"];
  return {
    name, child, pid, logFile: path.join(env.runDir, "logs", `${name}.log`),
    output: () => "",
    waitForOutput: async () => { throw new Error("not available across processes"); },
    async stop(graceMs = 8_000) {
      if (await gone()) return;
      signal("SIGTERM");
      const started = Date.now();
      while (!(await gone())) { if (Date.now() - started > graceMs) { signal("SIGKILL"); break; } await new Promise((r) => setTimeout(r, 100)); }
    },
    async kill9() { signal("SIGKILL"); await waitFor(gone, { timeoutMs: 5_000, what: `${name} to die` }); },
  };
}
