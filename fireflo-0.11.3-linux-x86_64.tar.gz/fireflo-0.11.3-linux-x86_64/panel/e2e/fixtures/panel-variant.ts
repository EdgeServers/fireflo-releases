/**
 * A second panel with different environment — `next start` on a free port from the one production
 * build global setup made — for the env-matrix cases: AUTH_COOKIE_SECURE unset in production, a
 * missing METRICS_DATABASE_URL, a missing OPERATOR_PASSWORD, plain SMTP.
 *
 * Costs a few seconds each, so a spec starts one per describe and stops it after. The main panel
 * under `next dev` is never restarted: its env is the run's baseline.
 */
import path from "node:path";
import { e2eEnv } from "./env";
import { freePort, spawnTracked } from "./process";
import type { Tracked } from "./process";
import { readState } from "./state";
import { waitForPort } from "../support/wait";

export interface PanelVariant {
  url: string;
  port: number;
  proc: Tracked;
  /** stderr+stdout so far — the AUTH_URL warning, a "not configured" line */
  output(): string;
  stop(): Promise<void>;
}

/**
 * The main panel's environment, as a base to override. EVERY variable the panel reads is named
 * here, the unused ones as "" — because `next dev` and `next start` both load the repo's .env.local
 * for any variable the process environment does not carry, and an "unset" that fell through to the
 * developer's real database once made a "no metrics DB" variant answer 200 from the wrong database.
 * An empty string is present in the environment, so Next leaves it alone, and every panel check is
 * `process.env.X?.trim()` or `!process.env.X`, so it reads as unset.
 */
export function baselinePanelEnv(port: number, host = "localhost"): NodeJS.ProcessEnv {
  const env = e2eEnv();
  const runDir = env.runDir;
  const url = `http://${host}:${port}`;
  return {
    PORT: String(port),
    // not used by the rig: pinned empty so .env.local cannot supply them
    GATEWAY_BASE_URL: "",
    FIREFLO_SMTP_USER: "",
    FIREFLO_SMTP_PASSWORD: "",
    TRUSTED_PROXY_HOPS: "",
    MIS_PANEL_BRAND: "",
    FIREFLO_FAIL2BAN_COMMAND: "",
    FIREFLO_BANS_FILE: path.join(runDir, "panel-data", "bans.jsonl"),
    CONFIG_DATABASE_URL: env.databaseUrl,
    METRICS_DATABASE_URL: env.databaseUrl,
    OPERATOR_USERNAME: env.operator.username,
    OPERATOR_PASSWORD: env.operator.password,
    AUTH_SECRET: env.authSecret,
    AUTH_URL: url,
    AUTH_TRUST_HOST: "true",
    AUTH_COOKIE_SECURE: "false",
    GATEWAY_OPS_URL: env.gatewayOpsUrl,
    GATEWAY_OPS_TOKEN: env.opsReadToken,
    GATEWAY_OPS_ADMIN_TOKEN: env.opsAdminToken,
    GATEWAY_API_URL: env.gatewayApiUrl,
    MIS_PANEL_BASE_URL: url,
    FIREFLO_DEV_LOGIN_LINK: "true",
    FIREFLO_SMTP_HOST: "127.0.0.1",
    FIREFLO_SMTP_PORT: String(env.smtpTlsPort),
    FIREFLO_SMTP_SECURE: "true",
    FIREFLO_SMTP_FROM: "qa@fireflo.test",
    NODE_EXTRA_CA_CERTS: path.join(runDir, "smtp", "ca.pem"),
    CDR_EXPORT_DIR: path.join(runDir, "panel-data", "exports"),
  };
}

/**
 * Start a variant. `overrides` replaces a variable, or with `undefined` UNSETS it — written as ""
 * rather than deleted, for the .env.local reason above. Unsetting is the point for most of the
 * matrix, so it is spelled out rather than being a falsy value.
 */
export async function startPanelVariant(name: string, overrides: Record<string, string | undefined>): Promise<PanelVariant> {
  const env = e2eEnv();
  if (!readState().panelBuilt) throw new Error("panel variants need the production build; global setup did not make one (E2E_PANEL_VARIANTS=1)");
  const port = await freePort();
  const base = baselinePanelEnv(port);
  const merged: NodeJS.ProcessEnv = { ...base };
  for (const [k, v] of Object.entries(overrides)) merged[k] = v === undefined ? "" : v;
  // `next start` runs as production; the variant must not inherit the dev server's env
  const clean: NodeJS.ProcessEnv = {};
  for (const [k, v] of Object.entries(process.env)) if (!(k in base)) clean[k] = v;
  const proc = spawnTracked(`panel-${name}`, "npx", ["next", "start", "-p", String(port)], {
    cwd: env.root,
    env: { ...clean, ...merged, NODE_ENV: "production" },
  });
  await waitForPort("127.0.0.1", port, 60_000);
  const url = `http://localhost:${port}`;
  return {
    url,
    port,
    proc,
    output: () => proc.output(),
    stop: () => proc.stop(),
  };
}
