/**
 * Spawning the rig's processes so that teardown can stop exactly them and nothing else.
 *
 * Every child is recorded in state.json by PID as it starts. `stopTracked` signals a PID only after
 * checking `/proc/<pid>/cmdline` still names the command we launched — a PID reused by something
 * unrelated after our child exited is left alone. There is no pattern kill anywhere in this suite:
 * jasmin holds 2775 on the reference box and `pkill -f` has taken it down before.
 */
import { spawn } from "node:child_process";
import type { ChildProcess } from "node:child_process";
import { closeSync, existsSync, mkdirSync, openSync, readdirSync, readFileSync, readSync, statSync, writeSync } from "node:fs";
import path from "node:path";
import { e2eEnv } from "./env";
import { updateState } from "./state";
import { sleep, waitFor } from "../support/wait";

export interface Tracked {
  name: string;
  child: ChildProcess;
  pid: number;
  logFile: string;
  /** everything the child wrote so far (stdout and stderr interleaved) */
  output(): string;
  /** wait until the log contains `re` */
  waitForOutput(re: RegExp, timeoutMs?: number): Promise<RegExpMatchArray>;
  /** SIGTERM, then SIGKILL after `graceMs`; resolves when the process is gone */
  stop(graceMs?: number): Promise<void>;
  /** SIGKILL now — the vendor-death cases */
  kill9(): Promise<void>;
}

export interface SpawnOptions {
  cwd?: string;
  env?: NodeJS.ProcessEnv;
  /** log file name under e2e/.run/logs; defaults to <name>.log */
  log?: string;
}

export function spawnTracked(name: string, command: string, args: string[], opts: SpawnOptions = {}): Tracked {
  const env = e2eEnv();
  const logDir = path.join(env.runDir, "logs");
  mkdirSync(logDir, { recursive: true });
  const logFile = path.join(logDir, opts.log ?? `${name}.log`);
  // the child writes straight to its log file rather than to a pipe: a pipe is drained only while
  // the process that spawned it lives, and a rig kept running after that (E2E_KEEP_RIG) would block
  // on its first full pipe buffer
  const fd = openSync(logFile, "a");
  writeSync(fd, `\n===== ${new Date().toISOString()} spawn ${command} ${args.join(" ")}\n`);
  const child = spawn(command, args, {
    cwd: opts.cwd ?? env.root,
    env: { ...process.env, ...opts.env },
    stdio: ["ignore", fd, fd],
    // its own process group, so `npx → next → next-server` (or `java` under a wrapper) is stopped
    // as a unit by signalling the group; a SIGTERM to the leader alone orphans the listener
    detached: true,
  });
  closeSync(fd);
  if (!child.pid) throw new Error(`could not spawn ${name} (${command})`);
  const startOffset = statSync(logFile).size;
  child.unref();
  const output = () => {
    // everything this spawn wrote (the file is appended across runs), capped at the last 2 MB
    try {
      const size = statSync(logFile).size;
      const from = Math.max(startOffset, size - 2_000_000);
      const buf = Buffer.alloc(size - from);
      const rfd = openSync(logFile, "r");
      try { readSync(rfd, buf, 0, buf.length, from); } finally { closeSync(rfd); }
      return buf.toString("utf8");
    } catch { return ""; }
  };
  updateState((s) => { s.pids.push({ name, pid: child.pid! }); });
  const pid = child.pid;

  const gone = () => new Promise<boolean>((resolve) => {
    try { process.kill(pid, 0); resolve(false); } catch { resolve(groupMembers(pid).length === 0); }
  });
  const signalGroup = (sig: NodeJS.Signals) => {
    try { process.kill(-pid, sig); } catch { /* no group */ }
    for (const m of groupMembers(pid)) { try { process.kill(m, sig); } catch { /* gone */ } }
  };

  const tracked: Tracked = {
    name,
    child,
    pid,
    logFile,
    output,
    waitForOutput: (re, timeoutMs = 30_000) =>
      waitFor(() => output().match(re), { timeoutMs, intervalMs: 100, what: `${name} to print ${re}` }),
    async stop(graceMs = 8_000) {
      if (await gone()) return;
      signalGroup("SIGTERM");
      const started = Date.now();
      while (!(await gone())) {
        if (Date.now() - started > graceMs) { signalGroup("SIGKILL"); break; }
        await sleep(100);
      }
      await waitFor(gone, { timeoutMs: 5_000, what: `${name} (${pid}) to exit` });
      forget(pid);
    },
    async kill9() {
      if (await gone()) return;
      signalGroup("SIGKILL");
      await waitFor(gone, { timeoutMs: 5_000, what: `${name} (${pid}) to die` });
      forget(pid);
    },
  };
  return tracked;
}

function forget(pid: number) {
  updateState((s) => { s.pids = s.pids.filter((p) => p.pid !== pid); });
}

/** The command line a PID is running, or null when it is gone. */
export function cmdlineOf(pid: number): string | null {
  const f = `/proc/${pid}/cmdline`;
  if (!existsSync(f)) return null;
  try { return readFileSync(f, "utf8").replace(/\0/g, " ").trim(); } catch { return null; }
}

/** Every live PID in process group `pgid` — the leader we spawned and whatever it forked. */
export function groupMembers(pgid: number): number[] {
  const out: number[] = [];
  let entries: string[] = [];
  try { entries = readdirSync("/proc"); } catch { return out; }
  for (const e of entries) {
    if (!/^\d+$/.test(e)) continue;
    try {
      const stat = readFileSync(`/proc/${e}/stat`, "utf8");
      const fields = stat.slice(stat.lastIndexOf(")") + 2).split(" ");
      if (Number(fields[2]) === pgid) out.push(Number(e));
    } catch { /* raced with exit */ }
  }
  return out;
}

/**
 * Teardown's kill: only PIDs setup recorded, and only if they still look like something we started
 * (java, node, next, the native runner). The leader was spawned detached, so its PID is also its
 * process group, and the group is what gets signalled — `npx` exits on SIGTERM and would leave
 * `next dev` and its `next-server` behind if only the leader were stopped. SIGTERM first, SIGKILL
 * for whatever is still in the group after the grace period.
 */
export async function stopTracked(name: string, pid: number, graceMs = 8_000): Promise<string> {
  const cmd = cmdlineOf(pid);
  const members = groupMembers(pid);
  if (cmd === null && members.length === 0) return `${name} (${pid}): already gone`;
  if (cmd !== null && !/(java|node|next|fireflo-app|runner|EdgeSmsc)/.test(cmd)) return `${name} (${pid}): not ours any more (${cmd.slice(0, 60)}), left alone`;
  const signal = (sig: NodeJS.Signals) => {
    try { process.kill(-pid, sig); } catch { /* no group: fall through to members */ }
    for (const m of groupMembers(pid)) { try { process.kill(m, sig); } catch { /* gone */ } }
  };
  signal("SIGTERM");
  const started = Date.now();
  while (cmdlineOf(pid) !== null || groupMembers(pid).length > 0) {
    if (Date.now() - started > graceMs) { signal("SIGKILL"); await sleep(300); return `${name} (${pid}): killed ${groupMembers(pid).length === 0 ? "the group" : "some of the group"} after ${graceMs}ms`; }
    await sleep(100);
  }
  return `${name} (${pid}): stopped (${members.length} in the group)`;
}

/** A free loopback TCP port. */
export async function freePort(): Promise<number> {
  const net = await import("node:net");
  return new Promise((resolve, reject) => {
    const s = net.createServer();
    s.listen(0, "127.0.0.1", () => {
      const a = s.address();
      const port = typeof a === "object" && a ? a.port : 0;
      s.close(() => resolve(port));
    });
    s.on("error", reject);
  });
}

/** Whether something already listens on a loopback port. */
export async function portInUse(port: number): Promise<boolean> {
  const net = await import("node:net");
  return new Promise((resolve) => {
    const s = net.createConnection({ host: "127.0.0.1", port });
    s.once("connect", () => { s.destroy(); resolve(true); });
    s.once("error", () => { s.destroy(); resolve(false); });
  });
}
