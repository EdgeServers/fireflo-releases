/**
 * In-process sinks the rig points the product at: the two SMTP servers the portal's mail goes to
 * (TLS on 4465 — what the panel is configured for — and plain on 4587 for the downgrade case), and
 * the webhook sink the gateway posts receipts to.
 *
 * The SMTP sinks live in the global-setup process and write every message to a spool directory,
 * because tests run in other processes and read the spool. The webhook sink is per test.
 */
import { createServer as createHttpServer } from "node:http";
import type { IncomingMessage, Server as HttpServer, ServerResponse } from "node:http";
import { createServer as createTcpServer } from "node:net";
import type { Server as TcpServer, Socket } from "node:net";
import { createServer as createTlsServer } from "node:tls";
import { existsSync, mkdirSync, readdirSync, readFileSync, readFileSync as read, writeFileSync } from "node:fs";
import path from "node:path";
import { e2eEnv } from "./env";
import type { E2EEnv } from "./env";
import { waitFor } from "../support/wait";

// ---------------------------------------------------------------- SMTP

export interface SpooledMail {
  file: string;
  receivedAt: string;
  port: number;
  from: string;
  to: string[];
  raw: string;
  subject: string;
  /** every http(s) link in the body, the sign-in link among them */
  links: string[];
}

function spoolDir(env: E2EEnv = e2eEnv()): string {
  return path.join(env.runDir, "smtp", "spool");
}

/**
 * A minimal SMTP receiver: greets, accepts EHLO/MAIL/RCPT/DATA/QUIT, records the message. No AUTH
 * (the panel sends none by default), no STARTTLS — the TLS variant is implicit TLS on connect, which
 * is what FIREFLO_SMTP_SECURE=true means to nodemailer.
 */
function attachSmtp(socket: Socket, port: number, env: E2EEnv) {
  let from = "";
  const to: string[] = [];
  let data = "";
  let inData = false;
  socket.write("220 fireflo-e2e ESMTP\r\n");
  let buf = "";
  socket.on("data", (chunk) => {
    buf += chunk.toString("utf8");
    for (;;) {
      const nl = buf.indexOf("\r\n");
      if (nl < 0) break;
      const line = buf.slice(0, nl);
      buf = buf.slice(nl + 2);
      if (inData) {
        if (line === ".") {
          inData = false;
          const subject = /^Subject:\s*(.*)$/im.exec(data)?.[1] ?? "";
          const decoded = data.replace(/=\r?\n/g, "").replace(/=([0-9A-F]{2})/g, (_m, h) => String.fromCharCode(parseInt(h, 16)));
          const links = [...decoded.matchAll(/https?:\/\/[^\s"'<>]+/g)].map((m) => m[0]);
          const mail: SpooledMail = { file: "", receivedAt: new Date().toISOString(), port, from, to: [...to], raw: data, subject, links };
          const dir = spoolDir(env);
          mkdirSync(dir, { recursive: true });
          const file = path.join(dir, `${Date.now()}-${Math.random().toString(36).slice(2, 7)}.json`);
          mail.file = file;
          writeFileSync(file, JSON.stringify(mail, null, 1));
          socket.write("250 OK queued\r\n");
          from = ""; to.length = 0; data = "";
        } else {
          data += (line.startsWith("..") ? line.slice(1) : line) + "\r\n";
        }
        continue;
      }
      const verb = line.slice(0, 4).toUpperCase();
      if (verb === "EHLO" || verb === "HELO") socket.write("250-fireflo-e2e\r\n250-8BITMIME\r\n250 SIZE 1048576\r\n");
      else if (verb === "MAIL") { from = /<([^>]*)>/.exec(line)?.[1] ?? line.slice(10); socket.write("250 OK\r\n"); }
      else if (verb === "RCPT") { to.push(/<([^>]*)>/.exec(line)?.[1] ?? line.slice(8)); socket.write("250 OK\r\n"); }
      else if (verb === "DATA") { inData = true; socket.write("354 End data with <CR><LF>.<CR><LF>\r\n"); }
      else if (verb === "RSET") { from = ""; to.length = 0; data = ""; socket.write("250 OK\r\n"); }
      else if (verb === "NOOP") socket.write("250 OK\r\n");
      else if (verb === "QUIT") { socket.write("221 Bye\r\n"); socket.end(); }
      else if (verb === "STAR") socket.write("454 TLS not available\r\n");
      else socket.write("502 Command not implemented\r\n");
    }
  });
  socket.on("error", () => undefined);
}

export interface SmtpSinks {
  tls: TcpServer;
  plain: TcpServer;
  close(): Promise<void>;
}

export async function startSmtpSinks(env: E2EEnv): Promise<SmtpSinks> {
  const certDir = path.join(env.runDir, "smtp");
  const tls = createTlsServer(
    { key: read(path.join(certDir, "key.pem")), cert: read(path.join(certDir, "ca.pem")) },
    (socket) => attachSmtp(socket, env.smtpTlsPort, env),
  );
  const plain = createTcpServer((socket) => attachSmtp(socket, env.smtpPlainPort, env));
  await new Promise<void>((res, rej) => { tls.once("error", rej); tls.listen(env.smtpTlsPort, "127.0.0.1", res); });
  await new Promise<void>((res, rej) => { plain.once("error", rej); plain.listen(env.smtpPlainPort, "127.0.0.1", res); });
  mkdirSync(spoolDir(env), { recursive: true });
  return {
    tls,
    plain,
    close: async () => { await new Promise((r) => tls.close(r)); await new Promise((r) => plain.close(r)); },
  };
}

/** Read the spool from other processes. */
export const mailbox = {
  mark: () => new Date(),
  all(since?: Date): SpooledMail[] {
    const dir = spoolDir();
    if (!existsSync(dir)) return [];
    return readdirSync(dir)
      .filter((n) => n.endsWith(".json"))
      .sort()
      .map((n) => JSON.parse(readFileSync(path.join(dir, n), "utf8")) as SpooledMail)
      .filter((m) => !since || new Date(m.receivedAt).getTime() >= since.getTime() - 1000);
  },
  waitFor(since: Date, pred: (m: SpooledMail) => boolean, timeoutMs = 15_000): Promise<SpooledMail> {
    return waitFor(() => mailbox.all(since).find(pred), { timeoutMs, intervalMs: 250, what: "a spooled mail" });
  },
  /** the first sign-in link in the newest mail to `address` since `since` */
  async signInLink(since: Date, address: string, timeoutMs = 15_000): Promise<string> {
    const m = await mailbox.waitFor(since, (x) => x.to.some((t) => t.toLowerCase() === address.toLowerCase()), timeoutMs);
    const link = m.links.find((l) => /\/verify\?token=|token=/.test(l));
    if (!link) throw new Error(`mail to ${address} carries no sign-in link: ${m.links.join(", ")}`);
    return link;
  },
};

// ---------------------------------------------------------------- webhook sink

export interface WebhookHit {
  at: number;
  method: string;
  url: string;
  headers: Record<string, string>;
  body: string;
  json: unknown;
}

export interface WebhookSink {
  url: string;
  port: number;
  hits: WebhookHit[];
  maxConcurrent: number;
  /** wait for at least n hits */
  waitHits(n: number, timeoutMs?: number): Promise<WebhookHit[]>;
  /** change behaviour mid-test */
  respond(status: number | ((hit: WebhookHit) => number), opts?: { sleepMs?: number; location?: string }): void;
  close(): Promise<void>;
}

export async function startWebhookSink(opts: { status?: number | ((hit: WebhookHit) => number); sleepMs?: number; location?: string; port?: number } = {}): Promise<WebhookSink> {
  let status = opts.status ?? 200;
  let sleepMs = opts.sleepMs ?? 0;
  let location = opts.location;
  let inFlight = 0;
  const hits: WebhookHit[] = [];
  const sink = { maxConcurrent: 0 } as WebhookSink;
  const server: HttpServer = createHttpServer((req: IncomingMessage, res: ServerResponse) => {
    let body = "";
    req.on("data", (c) => { body += c; });
    req.on("end", async () => {
      inFlight++;
      sink.maxConcurrent = Math.max(sink.maxConcurrent, inFlight);
      const headers: Record<string, string> = {};
      for (const [k, v] of Object.entries(req.headers)) headers[k] = Array.isArray(v) ? v.join(",") : (v ?? "");
      let json: unknown = null;
      try { json = JSON.parse(body); } catch { /* form or empty */ }
      const hit: WebhookHit = { at: Date.now(), method: req.method ?? "", url: req.url ?? "", headers, body, json };
      hits.push(hit);
      if (sleepMs) await new Promise((r) => setTimeout(r, sleepMs));
      const code = typeof status === "function" ? status(hit) : status;
      const h: Record<string, string> = { "content-type": "text/plain" };
      if (location && code >= 300 && code < 400) h.location = location;
      res.writeHead(code, h);
      res.end(code >= 400 ? "sink says no" : "ok");
      inFlight--;
    });
  });
  const port = await new Promise<number>((resolve, reject) => {
    server.once("error", reject);
    server.listen(opts.port ?? 0, "127.0.0.1", () => {
      const a = server.address();
      resolve(typeof a === "object" && a ? a.port : 0);
    });
  });
  Object.assign(sink, {
    url: `http://127.0.0.1:${port}/hook`,
    port,
    hits,
    waitHits: (n: number, timeoutMs = 20_000) => waitFor(() => (hits.length >= n ? hits : undefined), { timeoutMs, intervalMs: 100, what: `${n} webhook hit(s)` }),
    respond(s: number | ((hit: WebhookHit) => number), o: { sleepMs?: number; location?: string } = {}) { status = s; if (o.sleepMs !== undefined) sleepMs = o.sleepMs; if (o.location !== undefined) location = o.location; },
    close: () => new Promise<void>((r) => server.close(() => r())),
  });
  return sink;
}
