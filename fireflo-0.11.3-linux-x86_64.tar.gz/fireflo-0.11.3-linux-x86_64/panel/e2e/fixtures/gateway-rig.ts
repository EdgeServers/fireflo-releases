/**
 * The gateway side of the rig.
 *
 * Mode A (E2E_START_GATEWAY=1): package EdgeSmsc once (scripts/loadgen-package), seed the vendor
 * and listener rows the gateway reads in database mode, spawn EdgeSmsc A and B, spawn the gateway
 * (native runner or fast-jar) with FIREFLO_CONFIG_SOURCE=db against the e2e database, and wait for
 * /ops/health and the listener port. Everything spawned is recorded in state.json for teardown.
 *
 * Mode B: probe the configured /ops/health and record whether it answers.
 *
 * In database mode the properties file is NEVER read (fireflo-install says so), so every gateway
 * setting the suite depends on is an app_config row written by `seedGatewayConfig`; the gateway's
 * own environment carries only the connection, the ports and the file locations.
 */
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, writeFileSync } from "node:fs";
import { randomBytes } from "node:crypto";
import path from "node:path";
import { openDb } from "./db";
import type { Db } from "./db";
import { edgeSmscHandle, loadgenDir, spawnEdge } from "./edgesmsc";
import type { E2EEnv } from "./env";
import { spawnTracked } from "./process";
import { BASELINE, setConfig } from "./seed";
import { updateState } from "./state";
import { waitFor, waitForPort } from "../support/wait";

export const VENDORS = { a: "qa-sim1", b: "qa-sim2" } as const;
export const LISTENERS = { main: "smpp", second: "smpp2" } as const;

export async function probeHealth(env: E2EEnv): Promise<boolean> {
  try {
    const res = await fetch(`${env.gatewayOpsUrl}/ops/health`, { headers: { Authorization: `Bearer ${env.opsReadToken}` } });
    return res.ok;
  } catch {
    return false;
  }
}

export async function startGatewayRig(env: E2EEnv): Promise<void> {
  if (!env.startGateway) {
    const up = await probeHealth(env);
    updateState((s) => { s.gatewayUp = up; });
    console.log(`[e2e setup] gateway (mode B) ${up ? "answers" : "does NOT answer"} ${env.gatewayOpsUrl}/ops/health`);
    return;
  }
  if (!env.gatewayRepo || !env.gatewayBin) throw new Error("mode A needs E2E_GATEWAY_REPO and E2E_GATEWAY_BIN");
  if (!existsSync(env.gatewayBin)) throw new Error(`E2E_GATEWAY_BIN does not exist: ${env.gatewayBin} (build the gateway first)`);

  const db = openDb(2);
  try {
    await seedGatewayConfig(db, env);
    await seedSetupWindow(db, env);
  } finally {
    await db.close();
  }

  packageLoadgen(env);
  const a = spawnEdge(env, "edge-a", env.edgeA.port, env.edgeA.control);
  const b = spawnEdge(env, "edge-b", env.edgeB.port, env.edgeB.control);
  await waitForPort("127.0.0.1", env.edgeA.control, 60_000);
  await waitForPort("127.0.0.1", env.edgeB.control, 60_000);
  console.log(`[e2e setup] EdgeSmsc A pid ${a.pid} on ${env.edgeA.port}/${env.edgeA.control}, B pid ${b.pid} on ${env.edgeB.port}/${env.edgeB.control}`);
  // a freshly spawned EdgeSmsc answers submits and issues NO receipts; the rig's resting state is
  // "every accepted message gets DELIVRD", which is what baseline() sets
  await edgeSmscHandle("edge-a", env.edgeA.port, env.edgeA.control, a).baseline();
  await edgeSmscHandle("edge-b", env.edgeB.port, env.edgeB.control, b).baseline();

  const gw = spawnGateway(env);
  await waitFor(() => probeHealth(env), { timeoutMs: 180_000, intervalMs: 1000, what: "the gateway's /ops/health" });
  await waitForPort("127.0.0.1", env.smppPort, 60_000);
  updateState((s) => { s.gatewayUp = true; });
  console.log(`[e2e setup] gateway pid ${gw.pid}: /ops/health answers, listener on ${env.smppPort}`);
}

function packageLoadgen(env: E2EEnv): void {
  const dir = loadgenDir(env);
  if (existsSync(path.join(dir, "classes", "loadgen", "EdgeSmsc.class")) && process.env.E2E_REPACKAGE_LOADGEN !== "1") return;
  console.log(`[e2e setup] packaging EdgeSmsc into ${dir} (scripts/loadgen-package; set E2E_REPACKAGE_LOADGEN=1 to force)`);
  execFileSync(path.join(env.gatewayRepo!, "scripts", "loadgen-package"), [dir], { cwd: env.gatewayRepo!, stdio: ["ignore", "inherit", "inherit"] });
}

/** Everything the gateway reads from app_config / app_worker in this rig, idempotently. */
export async function seedGatewayConfig(db: Db, env: E2EEnv): Promise<void> {
  await setConfig(db, "smsg.ops.token", env.opsReadToken);
  await setConfig(db, "smsg.ops.admin.token", env.opsAdminToken);
  await setConfig(db, "smsg.config.db.poll.seconds", "2");
  await setConfig(db, "smsg.queue.capacity", "2000");
  await setConfig(db, "smsg.rates.currency", BASELINE.currency);
  await setConfig(db, "smsg.money.scale", "4");
  // the working default; the deny-default cases flip it and put it back
  await setConfig(db, "smsg.webhook.private.targets", "allow");
  await setConfig(db, "smsg.dlr.store.path", path.join(env.runDir, "data", "dlr-mvstore.db"));
  await setConfig(db, "smsg.cdr.sink", "postgres");
  await setConfig(db, "smsg.diagnostics", "problems");

  const vendor = async (name: string, port: number) => {
    await db.q("INSERT INTO app_worker (name, type, enabled, label) VALUES ($1, 'smppclient', true, $2) ON CONFLICT (name) DO UPDATE SET type = 'smppclient', enabled = true", [name, `QA vendor ${name}`]);
    const props: Record<string, string> = {
      host: "127.0.0.1", port: String(port), username: name, password: `${name}-pw`,
      windowSize: "200", "connections.transceivers": "1", tps: "0", threadCount: "4",
      "enquire.link.interval.millis": "10000", "reconnect.interval.millis": "3000",
      "request.tout": "30000", "window.monitor.interval.millis": "5000",
      maxRetries: "3", "fail.action.worker.sleep": "500",
      "src.addr.ton": "5", "src.addr.npi": "0", "dest.addr.ton": "1", "dest.addr.npi": "1",
      "dlr.charset.fixed": "GSM",
    };
    for (const [k, v] of Object.entries(props)) {
      await db.q("INSERT INTO app_worker_property (worker_name, key, value) VALUES ($1, $2, $3) ON CONFLICT (worker_name, key) DO UPDATE SET value = EXCLUDED.value", [name, k, v]);
    }
  };
  await vendor(VENDORS.a, env.edgeA.port);
  await vendor(VENDORS.b, env.edgeB.port);
  // vendor cost, so margins are computable: 0.0050 per message
  for (const v of [VENDORS.a, VENDORS.b]) {
    await db.q("DELETE FROM app_rate_rule WHERE scope = $1", [v]);
    await db.q("INSERT INTO app_rate_rule (scope, seq, amount, product, currency, label, enabled) VALUES ($1, 1, $2, NULL, $3, 'qa vendor cost', true)", [v, (BASELINE.cost / 10_000).toFixed(4), BASELINE.currency]);
  }

  // the bootstrap listener gets the rig's ceilings; a second plain listener rides beside it
  const listener = async (name: string, port: number, extra: Record<string, string> = {}) => {
    await db.q("INSERT INTO app_worker (name, type, enabled, label) VALUES ($1, 'smppserver', true, $2) ON CONFLICT (name) DO UPDATE SET enabled = true", [name, `QA listener ${name}`]);
    const props: Record<string, string> = {
      "srv.host": "0.0.0.0", "srv.port": String(port), "srv.maxConnections": "100",
      "srv.maxConnectionsPerIP": "4", "conf.maxConnectionsPerUser.default": "4", "conf.maxRate.default": "0",
      "srv.maxInactivityTime": "600", tps: "0", "conf.whitelist.enabled": "true", "forward.dlrs": "true",
      ...extra,
    };
    for (const [k, v] of Object.entries(props)) {
      await db.q("INSERT INTO app_worker_property (worker_name, key, value) VALUES ($1, $2, $3) ON CONFLICT (worker_name, key) DO UPDATE SET value = EXCLUDED.value", [name, k, v]);
    }
  };
  await listener(LISTENERS.main, env.smppPort);
  // the second listener also answers the PROXY protocol on its proxy port (EP-01.05)
  await listener(LISTENERS.second, env.smppPort2, { "srv.proxy.enabled": "true", "srv.proxy.port": String(env.smppProxyPort) });

  // MESSAGE table: everything to vendor A (bootstrap wrote the default → MESSAGE rules and the DLR return)
  if ((await db.count("app_route_rule", "table_name = 'MESSAGE'")) === 0) {
    await db.q("INSERT INTO app_route_rule (table_name, seq, target, copied, label, enabled) VALUES ('MESSAGE', 0, $1, false, 'qa: everything to vendor A', true)", [`smppclient.${VENDORS.a}`]);
  }
  // a failover group both vendors belong to, for the reclaim and failover cases
  await db.q("INSERT INTO app_route_group (name, policy, label, enabled) VALUES ('qa-failover', 'FAILOVER', 'QA failover A→B', true) ON CONFLICT (name) DO NOTHING");
  await db.q("INSERT INTO app_route_group_member (group_name, worker_name, weight, seq, enabled) VALUES ('qa-failover', $1, 1, 1, true), ('qa-failover', $2, 1, 2, true) ON CONFLICT DO NOTHING", [VENDORS.a, VENDORS.b]);
}

/**
 * Put the rig inside a licence SETUP window, or the gateway adopts nothing after its first load.
 *
 * A fresh install has no licence and no window: `LicensePolicy.verdictFor` answers NONE, and
 * `DbConfigPoller` then refuses every later snapshot -- which is exactly right for a customer box
 * and exactly wrong for a rig whose cases write `app_config` and `app_credential` and expect the
 * gateway to notice. The compatibility gate for installs that predate the trial rework still
 * honours a stamped `first_seen_at` for SETUP_DAYS, so the rig poses as one of those: a
 * `license.json` with `firstSeenAt` = now (the file wins over the table in `recover()`), mirrored
 * into `app_license` so a wiped data directory recovers the same window. The licensed behaviour
 * itself is EP-14's business, and those cases override this deliberately.
 */
export async function seedSetupWindow(db: Db, env: E2EEnv): Promise<void> {
  const licenseDir = path.join(env.runDir, "data", "license");
  mkdirSync(licenseDir, { recursive: true });
  const now = new Date().toISOString();
  const installId = `ins_${randomBytes(6).toString("hex")}`;
  writeFileSync(path.join(licenseDir, "license.json"), JSON.stringify({
    installId, licenseKey: null, license: null, highWaterAt: now, refreshedAt: null, firstSeenAt: now,
    configFingerprint: null, configFingerprintAt: null,
  }, null, 2));
  await db.q(
    `INSERT INTO app_license (id, install_id, license_key, license, high_water_at, refreshed_at, first_seen_at, updated_at)
     VALUES (TRUE, $1, NULL, NULL, $2, NULL, $2, now())
     ON CONFLICT (id) DO UPDATE SET install_id = EXCLUDED.install_id, license_key = NULL, license = NULL,
       high_water_at = EXCLUDED.high_water_at, refreshed_at = NULL, first_seen_at = EXCLUDED.first_seen_at, updated_at = now()`,
    [installId, now]);
}

export function gatewayEnv(env: E2EEnv): NodeJS.ProcessEnv {
  const u = new URL(env.databaseUrl);
  const logs = path.join(env.runDir, "logs");
  const data = path.join(env.runDir, "data");
  const conf = path.join(env.runDir, "conf");
  for (const d of [logs, data, conf, path.join(data, "license")]) mkdirSync(d, { recursive: true });
  return {
    ...process.env,
    FIREFLO_CONFIG_SOURCE: "db",
    FIREFLO_DB_URL: `jdbc:postgresql://${u.hostname}:${u.port || "5432"}${u.pathname}`,
    FIREFLO_DB_USER: decodeURIComponent(u.username),
    FIREFLO_DB_PASSWORD: decodeURIComponent(u.password),
    FIREFLO_DB_MIGRATE: "false",
    FIREFLO_DATA_DIR: data,
    FIREFLO_CONF_DIR: conf,
    FIREFLO_LICENSE_DIRECTORY: path.join(data, "license"),
    FIREFLO_BALANCE_ENABLE: "true",
    FIREFLO_SMPP_PORT_RANGE: `${env.smppPort}-${env.smppPort + 20}`,
    QUARKUS_HTTP_PORT: String(new URL(env.gatewayApiUrl).port),
    QUARKUS_HTTP_HOST: "0.0.0.0",
    FIREFLO_OPS_PORT: String(new URL(env.gatewayOpsUrl).port),
    QUARKUS_LOG_FILE_ENABLE: "true",
    QUARKUS_LOG_FILE_PATH: path.join(logs, "smsg.log"),
    QUARKUS_LOG_FILE_SMPPCLIENT_PATH: path.join(logs, "smppclient.log"),
    QUARKUS_LOG_FILE_SMPPSERVER_PATH: path.join(logs, "smppserver.log"),
    QUARKUS_LOG_FILE_AUTHFAIL_PATH: path.join(logs, "auth-failed.log"),
    QUARKUS_HTTP_ACCESS_LOG_DIRECTORY: logs,
    FIREFLO_LICENSE_KEY: "",
  };
}

export function spawnGateway(env: E2EEnv) {
  const bin = env.gatewayBin!;
  const gwEnv = gatewayEnv(env);
  if (bin.endsWith(".jar")) return spawnTracked("gateway", "java", ["-jar", bin], { cwd: env.gatewayRepo!, env: gwEnv });
  return spawnTracked("gateway", bin, [], { cwd: env.gatewayRepo!, env: gwEnv });
}
