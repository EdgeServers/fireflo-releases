/**
 * e2e/.run/state.json — what global setup started and what it found, read by teardown and by the
 * capability check. One small file, rewritten whole on every change; setup is the only writer
 * while the rig is coming up and teardown the only reader once it is going down.
 */
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { e2eEnv } from "./env";

export interface RunState {
  startedAt: string;
  /** children spawned by setup, in start order; teardown signals them in reverse */
  pids: { name: string; pid: number }[];
  /** the gateway is up and answering /ops/health (mode A: ours; mode B: the one configured) */
  gatewayUp: boolean;
  /** `next build` completed, so `next start` variants can be launched */
  panelBuilt: boolean;
  /** the bootstrap login's system_id and the password setup overwrote it with */
  bootstrapLogin: { systemId: string; password: string } | null;
  /** per-name ports the rig chose at runtime (panel variants) */
  ports: Record<string, number>;
}

function file(): string {
  return path.join(e2eEnv().runDir, "state.json");
}

export function readState(): RunState {
  const f = file();
  if (!existsSync(f)) {
    return { startedAt: "", pids: [], gatewayUp: false, panelBuilt: false, bootstrapLogin: null, ports: {} };
  }
  return { gatewayUp: false, panelBuilt: false, bootstrapLogin: null, ports: {}, ...JSON.parse(readFileSync(f, "utf8")) };
}

export function writeState(state: RunState): void {
  mkdirSync(path.dirname(file()), { recursive: true });
  writeFileSync(file(), JSON.stringify(state, null, 1) + "\n");
}

export function updateState(patch: (s: RunState) => void): RunState {
  const s = readState();
  patch(s);
  writeState(s);
  return s;
}
