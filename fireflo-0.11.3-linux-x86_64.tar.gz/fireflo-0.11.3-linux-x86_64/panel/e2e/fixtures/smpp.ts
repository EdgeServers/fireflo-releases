/**
 * SMPP from the customer's side (an ESME binding to a listener) and from the vendor's side (a
 * fake SMSC the gateway binds to), both on the `smpp` package. The ESME is what EP-01..03 and the
 * panel's login/whitelist cases speak; the fake SMSC is the stand-in for SMPPSim — it captures every
 * submit_sm (TLVs, TON/NPI, DCS, UDH) and can push MOs and receipts back.
 */
import { once } from "node:events";
import smpp from "smpp";
import type { Pdu, Server, Session } from "smpp";
import { e2eEnv } from "./env";
import { sleep, waitFor } from "../support/wait";

export type BindType = "trx" | "tx" | "rx";

export interface ConnectOptions {
  host?: string;
  port?: number;
  systemId: string;
  password: string;
  bind?: BindType;
  systemType?: string;
  /** a second source address (127.0.0.2 …) for the per-IP cases */
  localAddress?: string;
  enquireLinkMs?: number;
  timeoutMs?: number;
  /** a PROXY protocol v1 line written before the bind, e.g. "PROXY TCP4 203.0.113.9 127.0.0.1 40000 27802" */
  proxyHeader?: string;
}

export interface SubmitOptions {
  source?: string;
  dest?: string;
  text?: string | Buffer;
  dcs?: number;
  esmClass?: number;
  registeredDelivery?: number;
  sourceTon?: number;
  sourceNpi?: number;
  destTon?: number;
  destNpi?: number;
  udh?: Buffer;
  validityPeriod?: string;
  priority?: number;
  tlvs?: Record<string, unknown>;
}

export interface SubmitResult {
  status: number;
  messageId: string | null;
  pdu: Pdu;
}

export interface Receipt {
  at: number;
  pdu: Pdu;
  text: string;
  /** fields parsed off the receipt text: id, stat, err, sub, dlvrd */
  fields: Record<string, string>;
  receiptedMessageId: string | null;
  source: string;
  dest: string;
  sourceTon: number;
  destTon: number;
}

export interface Esme {
  session: Session;
  systemId: string;
  bound: boolean;
  bindStatus: number;
  receipts: Receipt[];
  /** every deliver_sm that is not a receipt (an MO) */
  inbound: Pdu[];
  submit(opts?: SubmitOptions): Promise<SubmitResult>;
  submitMany(n: number, template?: SubmitOptions, opts?: { tps?: number; window?: number }): Promise<{ accepted: number; refused: Map<number, number>; ids: string[]; elapsedMs: number }>;
  waitReceipt(pred: (r: Receipt) => boolean, timeoutMs?: number): Promise<Receipt>;
  waitInbound(pred: (p: Pdu) => boolean, timeoutMs?: number): Promise<Pdu>;
  enquireLink(): Promise<Pdu>;
  unbind(): Promise<void>;
  destroy(): Promise<void>;
}

function text(pdu: Pdu): string {
  const m = pdu.short_message;
  if (m == null) return "";
  if (typeof m === "string") return m;
  if (Buffer.isBuffer(m)) return m.toString("latin1");
  const inner = (m as { message: string | Buffer }).message;
  return typeof inner === "string" ? inner : inner.toString("latin1");
}

function receiptFields(s: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const m of s.matchAll(/(\w+):(\S*)/g)) out[m[1]] = m[2];
  return out;
}

function isReceipt(pdu: Pdu): boolean {
  return ((pdu.esm_class as number) ?? 0) & 0x04 ? true : /\bstat:/.test(text(pdu));
}

/** Bind an ESME. Resolves once bind_resp arrived (bound or refused — read `bindStatus`). */
export async function connectEsme(opts: ConnectOptions): Promise<Esme> {
  const env = e2eEnv();
  const host = opts.host ?? env.smppHost;
  const port = opts.port ?? env.smppPort;
  let session: Session;
  if (opts.proxyHeader) {
    // the header goes down the raw socket first; the Session then takes over an already-open socket
    const { createConnection } = await import("node:net");
    const socket = createConnection({ host, port, localAddress: opts.localAddress });
    await new Promise<void>((resolve, reject) => { socket.once("connect", resolve); socket.once("error", reject); });
    socket.write(opts.proxyHeader.replace(/\r?\n$/, "") + "\r\n");
    session = new smpp.Session({ socket } as unknown as import("smpp").SessionOptions);
    setImmediate(() => session.emit("connect"));
  } else {
    session = smpp.connect({
      host, port,
      localAddress: opts.localAddress,
      auto_enquire_link_period: opts.enquireLinkMs ?? 0,
      connectTimeout: opts.timeoutMs ?? 10_000,
    });
  }
  session.on("error", () => undefined);
  const esme: Esme = {
    session, systemId: opts.systemId, bound: false, bindStatus: -1, receipts: [], inbound: [],
    async submit(o = {}) {
      const params: Record<string, unknown> = {
        source_addr: o.source ?? "QATEST",
        destination_addr: o.dest ?? "61400000001",
        short_message: o.udh ? { udh: o.udh, message: o.text ?? "qa" } : (o.text ?? "qa"),
        data_coding: o.dcs ?? 0,
        esm_class: o.esmClass ?? (o.udh ? 0x40 : 0),
        registered_delivery: o.registeredDelivery ?? 0,
        ...(o.sourceTon !== undefined ? { source_addr_ton: o.sourceTon } : {}),
        ...(o.sourceNpi !== undefined ? { source_addr_npi: o.sourceNpi } : {}),
        ...(o.destTon !== undefined ? { dest_addr_ton: o.destTon } : {}),
        ...(o.destNpi !== undefined ? { dest_addr_npi: o.destNpi } : {}),
        ...(o.validityPeriod !== undefined ? { validity_period: o.validityPeriod } : {}),
        ...(o.priority !== undefined ? { priority_flag: o.priority } : {}),
        ...(o.tlvs ?? {}),
      };
      const pdu = await new Promise<Pdu>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("submit_sm_resp timed out")), 30_000);
        session.submit_sm(params, (resp) => { clearTimeout(timer); resolve(resp); });
      });
      return { status: pdu.command_status, messageId: pdu.message_id ?? null, pdu };
    },
    async submitMany(n, template = {}, o = {}) {
      const started = Date.now();
      const refused = new Map<number, number>();
      const ids: string[] = [];
      let accepted = 0;
      const window = o.window ?? 50;
      const gapMs = o.tps ? 1000 / o.tps : 0;
      let inFlight = 0;
      let sent = 0;
      await new Promise<void>((resolve) => {
        const pump = () => {
          while (sent < n && inFlight < window) {
            sent++; inFlight++;
            const i = sent;
            esme.submit({ ...template, dest: template.dest ?? `6140000${String(i).padStart(4, "0")}` })
              .then((r) => { if (r.status === 0) { accepted++; if (r.messageId) ids.push(r.messageId); } else refused.set(r.status, (refused.get(r.status) ?? 0) + 1); })
              .catch(() => refused.set(-1, (refused.get(-1) ?? 0) + 1))
              .finally(() => { inFlight--; if (sent >= n && inFlight === 0) resolve(); else if (!gapMs) pump(); });
            if (gapMs) { setTimeout(pump, gapMs); return; }
          }
        };
        pump();
      });
      return { accepted, refused, ids, elapsedMs: Date.now() - started };
    },
    waitReceipt: (pred, timeoutMs = 20_000) => waitFor(() => esme.receipts.find(pred), { timeoutMs, intervalMs: 100, what: "a delivery receipt" }),
    waitInbound: (pred, timeoutMs = 20_000) => waitFor(() => esme.inbound.find(pred), { timeoutMs, intervalMs: 100, what: "an inbound deliver_sm" }),
    enquireLink: () => new Promise<Pdu>((resolve) => session.enquire_link({}, resolve)),
    async unbind() {
      await new Promise<void>((resolve) => { session.unbind({}, () => resolve()); setTimeout(resolve, 3000); });
      session.close();
      esme.bound = false;
    },
    async destroy() {
      session.destroy();
      esme.bound = false;
      await sleep(50);
    },
  };
  session.on("deliver_sm", (pdu: Pdu) => {
    // the ESME must answer every deliver_sm, or the gateway counts it as unacknowledged
    session.send(pdu.response());
    if (isReceipt(pdu)) {
      const t = text(pdu);
      esme.receipts.push({
        at: Date.now(), pdu, text: t, fields: receiptFields(t),
        receiptedMessageId: (pdu.receipted_message_id as string | undefined) ?? receiptFields(t).id ?? null,
        source: pdu.source_addr ?? "", dest: pdu.destination_addr ?? "",
        sourceTon: Number(pdu.source_addr_ton ?? 0), destTon: Number(pdu.dest_addr_ton ?? 0),
      });
    } else {
      esme.inbound.push(pdu);
    }
  });
  session.on("enquire_link", (pdu: Pdu) => session.send(pdu.response()));
  session.on("unbind", (pdu: Pdu) => { session.send(pdu.response()); esme.bound = false; });
  session.on("close", () => { esme.bound = false; });

  await Promise.race([
    once(session, "connect"),
    new Promise((_r, rej) => session.once("error", rej)),
    sleep(opts.timeoutMs ?? 10_000).then(() => { throw new Error(`connect to ${host}:${port} timed out`); }),
  ]);
  const bindFn = opts.bind === "tx" ? session.bind_transmitter : opts.bind === "rx" ? session.bind_receiver : session.bind_transceiver;
  const resp = await new Promise<Pdu>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("bind_resp timed out")), opts.timeoutMs ?? 10_000);
    bindFn.call(session, { system_id: opts.systemId, password: opts.password, system_type: opts.systemType ?? "", interface_version: 0x34 }, (pdu: Pdu) => { clearTimeout(timer); resolve(pdu); });
  });
  esme.bindStatus = resp.command_status;
  esme.bound = resp.command_status === 0;
  if (!esme.bound) session.destroy();
  return esme;
}

/** One bind attempt, answering the status and closing. For refusal cases. */
export async function bindAttempt(opts: ConnectOptions): Promise<{ status: number; error?: string }> {
  try {
    const e = await connectEsme(opts);
    const status = e.bindStatus;
    if (e.bound) await e.unbind();
    return { status };
  } catch (err) {
    return { status: -1, error: err instanceof Error ? err.message : String(err) };
  }
}

// ---------------------------------------------------------------- fake SMSC (vendor side)

export interface CapturedSubmit {
  at: number;
  pdu: Pdu;
  text: string;
  source: string;
  dest: string;
  sourceTon: number;
  sourceNpi: number;
  destTon: number;
  destNpi: number;
  dcs: number;
  esmClass: number;
  registeredDelivery: number;
  udh: Buffer | null;
  tlvs: Record<string, unknown>;
  messageId: string;
  systemId: string;
}

export interface FakeSmsc {
  port: number;
  server: Server;
  sessions: Session[];
  binds: { systemId: string; password: string; type: string; status: number }[];
  captured: CapturedSubmit[];
  /** what submit_sm is answered with; a function may vary it per PDU */
  respond: number | ((c: CapturedSubmit) => number);
  /** bind refusal status, or 0 to accept */
  bindStatus: number;
  waitCaptured(n: number, timeoutMs?: number): Promise<CapturedSubmit[]>;
  /** push a delivery receipt for a message id the gateway got from us */
  deliverReceipt(messageId: string, opts?: { stat?: string; err?: string; source?: string; dest?: string; text?: string }): Promise<Pdu>;
  /** push an MO to the bound gateway */
  deliverMo(opts: { source: string; dest: string; text: string; dcs?: number }): Promise<Pdu>;
  close(): Promise<void>;
}

const KNOWN_FIELDS = new Set(["command", "command_id", "command_status", "command_length", "sequence_number", "service_type", "source_addr_ton", "source_addr_npi", "source_addr", "dest_addr_ton", "dest_addr_npi", "destination_addr", "esm_class", "protocol_id", "priority_flag", "schedule_delivery_time", "validity_period", "registered_delivery", "replace_if_present_flag", "data_coding", "sm_default_msg_id", "short_message"]);

export async function startFakeSmsc(opts: { port?: number; systemId?: string; password?: string; respond?: number } = {}): Promise<FakeSmsc> {
  let seq = 0;
  const fake = {
    sessions: [] as Session[],
    binds: [] as FakeSmsc["binds"],
    captured: [] as CapturedSubmit[],
    respond: opts.respond ?? 0,
    bindStatus: 0,
  } as FakeSmsc;
  const server = smpp.createServer({}, (session: Session) => {
    session.on("error", () => undefined);
    fake.sessions.push(session);
    for (const kind of ["bind_transceiver", "bind_transmitter", "bind_receiver"]) {
      session.on(kind, (pdu: Pdu) => {
        const status = fake.bindStatus || ((opts.systemId && pdu.system_id !== opts.systemId) || (opts.password && pdu.password !== opts.password) ? smpp.ESME_RINVPASWD : 0);
        fake.binds.push({ systemId: pdu.system_id ?? "", password: pdu.password ?? "", type: kind, status });
        session.send(pdu.response({ command_status: status, system_id: "qa-fake-smsc" }));
      });
    }
    session.on("submit_sm", (pdu: Pdu) => {
      const tlvs: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(pdu)) if (!KNOWN_FIELDS.has(k) && typeof v !== "function" && !k.startsWith("_")) tlvs[k] = v;
      const sm = pdu.short_message;
      const udh = sm && typeof sm === "object" && !Buffer.isBuffer(sm) && (sm as { udh?: Buffer }).udh ? (sm as { udh: Buffer }).udh : null;
      const c: CapturedSubmit = {
        at: Date.now(), pdu, text: text(pdu), source: pdu.source_addr ?? "", dest: pdu.destination_addr ?? "",
        sourceTon: Number(pdu.source_addr_ton ?? 0), sourceNpi: Number(pdu.source_addr_npi ?? 0),
        destTon: Number(pdu.dest_addr_ton ?? 0), destNpi: Number(pdu.dest_addr_npi ?? 0),
        dcs: Number(pdu.data_coding ?? 0), esmClass: Number(pdu.esm_class ?? 0), registeredDelivery: Number(pdu.registered_delivery ?? 0),
        udh, tlvs, messageId: `fk${++seq}`, systemId: fake.binds.at(-1)?.systemId ?? "",
      };
      fake.captured.push(c);
      const status = typeof fake.respond === "function" ? fake.respond(c) : fake.respond;
      session.send(pdu.response({ command_status: status, message_id: status === 0 ? c.messageId : "" }));
    });
    session.on("enquire_link", (pdu: Pdu) => session.send(pdu.response()));
    session.on("unbind", (pdu: Pdu) => { session.send(pdu.response()); session.close(); });
    session.on("deliver_sm_resp", () => undefined);
  });
  const port = await new Promise<number>((resolve, reject) => {
    server.once("error", reject);
    server.listen(opts.port ?? 0, "127.0.0.1", () => {
      const a = server.address();
      resolve(typeof a === "object" && a ? a.port : (opts.port ?? 0));
    });
  });
  const bound = () => fake.sessions.filter((s) => !s.socket.destroyed);
  const push = (params: Record<string, unknown>) => new Promise<Pdu>((resolve, reject) => {
    const s = bound().at(-1);
    if (!s) return reject(new Error("fake SMSC: no bound session to deliver on"));
    const timer = setTimeout(() => reject(new Error("deliver_sm_resp timed out")), 20_000);
    s.deliver_sm(params, (resp) => { clearTimeout(timer); resolve(resp); });
  });
  Object.assign(fake, {
    port, server,
    waitCaptured: (n: number, timeoutMs = 20_000) => waitFor(() => (fake.captured.length >= n ? fake.captured : undefined), { timeoutMs, intervalMs: 100, what: `${n} captured submit_sm` }),
    deliverReceipt: (messageId: string, o: { stat?: string; err?: string; source?: string; dest?: string; text?: string } = {}) => {
      const stat = o.stat ?? "DELIVRD";
      const err = o.err ?? "000";
      const stamp = new Date().toISOString().replace(/[-:T]/g, "").slice(2, 12);
      const body = o.text ?? `id:${messageId} sub:001 dlvrd:${stat === "DELIVRD" ? "001" : "000"} submit date:${stamp} done date:${stamp} stat:${stat} err:${err} text:qa`;
      return push({ source_addr: o.source ?? "61400000001", destination_addr: o.dest ?? "QATEST", short_message: body, esm_class: 0x04, receipted_message_id: messageId, message_state: stat === "DELIVRD" ? 2 : stat === "EXPIRED" ? 3 : 5 });
    },
    deliverMo: (o: { source: string; dest: string; text: string; dcs?: number }) => push({ source_addr: o.source, destination_addr: o.dest, short_message: o.text, data_coding: o.dcs ?? 0, esm_class: 0 }),
    close: () => new Promise<void>((resolve) => { for (const s of fake.sessions) s.destroy(); server.close(() => resolve()); }),
  });
  return fake;
}
