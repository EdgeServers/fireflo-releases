/**
 * Sessions on both panel surfaces, minted the way the browser does it and nothing else.
 *
 * There is no test bypass in the panel and there must not be one. The operator signs in through
 * next-auth's credentials callback (`/api/auth/callback/operator`), the customer through the
 * magic-link callback (`/api/mis/auth/callback/magic-link`) with a token whose sha256 we insert into
 * app_login_token exactly as `issueLoginToken` does. Both give an ordinary session cookie — the
 * operator's `fireflo-control.session-token`, the portal's `fireflo-mis.session-token` — that the
 * rest of the suite carries in a storage state or an APIRequestContext.
 */
import { createHash, randomBytes } from "node:crypto";
import { request } from "@playwright/test";
import type { APIRequestContext, APIResponse, BrowserContext } from "@playwright/test";
import type { Db } from "./db";
import { e2eEnv } from "./env";

export const OPERATOR_COOKIE = "fireflo-control.session-token";
export const PORTAL_COOKIE = "fireflo-mis.session-token";

/**
 * A request context with NO cookies. Inside a test, `request.newContext()` inherits the project's
 * `use.storageState` — the operator's session — so a "portal-only" context made without this would
 * quietly carry the operator cookie too, and every cross-surface case would be measuring nothing.
 */
export async function freshRequestContext(baseURL = e2eEnv().panelUrl): Promise<APIRequestContext> {
  return request.newContext({ baseURL, storageState: { cookies: [], origins: [] } });
}

/** The header the next-auth client sends so the callback answers JSON `{url}` instead of a 302. */
const RETURN_REDIRECT = { "X-Auth-Return-Redirect": "1" };

async function csrfToken(ctx: APIRequestContext, basePath: string): Promise<string> {
  const res = await ctx.get(`${basePath}/csrf`);
  if (!res.ok()) throw new Error(`GET ${basePath}/csrf → ${res.status()}`);
  return ((await res.json()) as { csrfToken: string }).csrfToken;
}

export interface SignInOutcome {
  /** the callback's own answer; next-auth puts `?error=` on it when the credentials were refused */
  url: string;
  signedIn: boolean;
  status: number;
}

/**
 * The operator credentials callback, answered as JSON. `ctx` keeps whatever cookie came back.
 */
export async function operatorSignIn(
  ctx: APIRequestContext,
  creds: { username: string; password: string },
  baseURL = e2eEnv().panelUrl,
): Promise<SignInOutcome> {
  const csrf = await csrfToken(ctx, "/api/auth");
  const res = await ctx.post("/api/auth/callback/operator", {
    form: { csrfToken: csrf, username: creds.username, password: creds.password, callbackUrl: `${baseURL}/cp`, redirect: "false" },
    headers: RETURN_REDIRECT,
  });
  const body = (await res.json().catch(() => ({}))) as { url?: string };
  const url = body.url ?? res.url();
  return { url, status: res.status(), signedIn: !/[?&]error=/.test(url) && (await operatorSessionOf(ctx)) !== null };
}

/** The raw callback response with redirects NOT followed — for reading Set-Cookie attributes. */
export async function operatorSignInRaw(
  ctx: APIRequestContext,
  creds: { username: string; password: string },
  baseURL = e2eEnv().panelUrl,
): Promise<{ response: APIResponse; setCookie: string[] }> {
  const csrf = await csrfToken(ctx, "/api/auth");
  const response = await ctx.post("/api/auth/callback/operator", {
    form: { csrfToken: csrf, username: creds.username, password: creds.password, callbackUrl: `${baseURL}/cp`, redirect: "false" },
    maxRedirects: 0,
  });
  const setCookie = response.headersArray().filter((h) => h.name.toLowerCase() === "set-cookie").map((h) => h.value);
  return { response, setCookie };
}

export async function operatorSessionOf(ctx: APIRequestContext): Promise<{ name: string; role?: string } | null> {
  const res = await ctx.get("/api/auth/session");
  if (!res.ok()) return null;
  const body = (await res.json().catch(() => null)) as { user?: { name: string; role?: string } } | null;
  return body?.user ?? null;
}

/** A fresh request context carrying an operator session. */
export async function mintOperatorContext(baseURL = e2eEnv().panelUrl): Promise<APIRequestContext> {
  const env = e2eEnv();
  const ctx = await freshRequestContext(baseURL);
  const outcome = await operatorSignIn(ctx, env.operator, baseURL);
  if (!outcome.signedIn) throw new Error(`operator sign-in refused: ${outcome.url}`);
  return ctx;
}

/** Insert a sign-in token for `accountId` the way `issueLoginToken` does, and return the raw token. */
export async function issueLoginTokenFor(db: Db, accountId: string, opts: { ttlMinutes?: number; ip?: string | null } = {}): Promise<string> {
  const token = randomBytes(32).toString("base64url");
  const hash = createHash("sha256").update(token).digest("hex");
  await db.q(
    `INSERT INTO app_login_token (token_hash, account_id, expires_at, requested_ip)
     VALUES ($1, $2, now() + ($3 || ' minutes')::interval, $4)`,
    [hash, accountId, String(opts.ttlMinutes ?? 15), opts.ip ?? "127.0.0.1"],
  );
  return token;
}

/** Spend a magic-link token through the portal callback. `ctx` keeps the cookie. */
export async function portalRedeem(ctx: APIRequestContext, token: string, baseURL = e2eEnv().panelUrl): Promise<SignInOutcome> {
  const csrf = await csrfToken(ctx, "/api/mis/auth");
  const res = await ctx.post("/api/mis/auth/callback/magic-link", {
    form: { csrfToken: csrf, token, callbackUrl: `${baseURL}/overview`, redirect: "false" },
    headers: RETURN_REDIRECT,
  });
  const body = (await res.json().catch(() => ({}))) as { url?: string };
  const url = body.url ?? res.url();
  return { url, status: res.status(), signedIn: !/[?&]error=/.test(url) && (await portalSessionOf(ctx)) !== null };
}

export async function portalSessionOf(ctx: APIRequestContext): Promise<{ name: string } | null> {
  const res = await ctx.get("/api/mis/auth/session");
  if (!res.ok()) return null;
  const body = (await res.json().catch(() => null)) as { user?: { name: string } } | null;
  return body?.user ?? null;
}

/** A fresh request context signed in as a customer account. */
export async function mintPortalContext(db: Db, accountId: string, baseURL = e2eEnv().panelUrl): Promise<APIRequestContext> {
  const ctx = await freshRequestContext(baseURL);
  const token = await issueLoginTokenFor(db, accountId);
  const outcome = await portalRedeem(ctx, token, baseURL);
  if (!outcome.signedIn) throw new Error(`portal sign-in for ${accountId} refused: ${outcome.url}`);
  return ctx;
}

/** Copy one surface's cookie from a request context into a browser context. */
export async function carryCookie(from: APIRequestContext, to: BrowserContext, name: string): Promise<void> {
  const state = await from.storageState();
  const cookie = state.cookies.find((c) => c.name === name);
  if (!cookie) throw new Error(`no ${name} cookie to carry`);
  await to.addCookies([cookie]);
}

export function cookieValue(setCookie: string[], name: string): { value: string; attrs: string[] } | null {
  for (const line of setCookie) {
    const [pair, ...attrs] = line.split(";").map((s) => s.trim());
    const eq = pair.indexOf("=");
    if (pair.slice(0, eq) === name) return { value: pair.slice(eq + 1), attrs: attrs.map((a) => a.toLowerCase()) };
  }
  return null;
}
