/**
 * The gateway over HTTP: its operational API (`/ops/*`, bearer tokens), its customer REST API
 * (`/secure/*`, Basic auth), its CLI, and the one wait every configuration case needs — for the
 * gateway to have adopted what the panel just wrote.
 */
import { execFileSync } from "node:child_process";
import path from "node:path";
import { e2eEnv } from "./env";
import type { E2EEnv } from "./env";
import { waitFor } from "../support/wait";

export interface OpsResponse<T = unknown> { status: number; body: T; text: string }

async function call<T = unknown>(url: string, init: RequestInit): Promise<OpsResponse<T>> {
  const res = await fetch(url, init);
  const text = await res.text();
  let body: unknown = null;
  try { body = JSON.parse(text); } catch { body = text; }
  return { status: res.status, body: body as T, text };
}

export function ops(env: E2EEnv = e2eEnv()) {
  const auth = (admin: boolean) => ({ Authorization: `Bearer ${admin ? env.opsAdminToken : env.opsReadToken}` });
  const base = env.gatewayOpsUrl;
  return {
    get: <T = unknown>(p: string, admin = false) => call<T>(`${base}${p}`, { headers: auth(admin) }),
    post: <T = unknown>(p: string, body?: unknown, admin = true) =>
      call<T>(`${base}${p}`, { method: "POST", headers: { ...auth(admin), "content-type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) }),
    /** with a token of the caller's choosing, for the guard cases */
    withToken: <T = unknown>(p: string, token: string | null, method = "GET") =>
      call<T>(`${base}${p}`, { method, headers: token === null ? {} : { Authorization: `Bearer ${token}` } }),
    health: () => call<HealthSnapshot>(`${base}/ops/health`, { headers: auth(false) }),
    resolvedConfig: () => call<{ gateway?: Record<string, ResolvedEntry>; workers?: Record<string, Record<string, ResolvedEntry>> } & Record<string, unknown>>(`${base}/ops/config/resolved`, { headers: auth(true) }),
    explain: (q: Record<string, string>) => call<Record<string, unknown>>(`${base}/ops/routing/explain?${new URLSearchParams(q)}`, { headers: auth(true) }),
    reload: () => call(`${base}/ops/reload`, { method: "POST", headers: auth(true) }),
    workerAction: (name: string, action: string) => call(`${base}/ops/workers/${encodeURIComponent(name)}/${action}`, { method: "POST", headers: auth(true) }),
    sessions: (name: string) => call<Record<string, unknown>>(`${base}/ops/workers/${encodeURIComponent(name)}/sessions`, { headers: auth(false) }),
    disconnect: (name: string, sessionId: string) => call(`${base}/ops/workers/${encodeURIComponent(name)}/sessions/${encodeURIComponent(sessionId)}/disconnect`, { method: "POST", headers: auth(true) }),
    testBind: (name: string) => call(`${base}/ops/workers/${encodeURIComponent(name)}/test-bind`, { method: "POST", headers: auth(true) }),
    queues: () => call<Record<string, unknown>>(`${base}/ops/queues`, { headers: auth(false) }),
    log: (name: string) => call<string>(`${base}/ops/logs/${name}`, { headers: auth(true) }),
    license: () => call<Record<string, unknown>>(`${base}/ops/license`, { headers: auth(false) }),
  };
}

export interface ResolvedEntry { value?: string | null; source?: string; tier?: string; [k: string]: unknown }
export interface HealthSnapshot {
  version?: string;
  workers?: Record<string, unknown> | unknown[];
  config_sources?: Record<string, string>;
  license?: Record<string, unknown>;
  [k: string]: unknown;
}

/** The customer REST API with HTTP Basic credentials. */
export function rest(creds: { systemId: string; password: string } | { apiKey: string }, env: E2EEnv = e2eEnv()) {
  const token = "apiKey" in creds ? Buffer.from(`${creds.apiKey}:`).toString("base64") : Buffer.from(`${creds.systemId}:${creds.password}`).toString("base64");
  const headers = { Authorization: `Basic ${token}`, "content-type": "application/json" };
  const base = env.gatewayApiUrl;
  return {
    get: <T = unknown>(p: string) => call<T>(`${base}${p}`, { headers }),
    post: <T = unknown>(p: string, body: unknown) => call<T>(`${base}${p}`, { method: "POST", headers, body: JSON.stringify(body) }),
    del: <T = unknown>(p: string) => call<T>(`${base}${p}`, { method: "DELETE", headers }),
    send: (body: Record<string, unknown>) => call<Record<string, unknown>>(`${base}/secure/send`, { method: "POST", headers, body: JSON.stringify({ to: "61400000001", from: "QATEST", content: "qa", ...body }) }),
    sendbatch: (body: Record<string, unknown>) => call<Record<string, unknown>>(`${base}/secure/sendbatch`, { method: "POST", headers, body: JSON.stringify(body) }),
    balance: () => call<Record<string, unknown>>(`${base}/secure/balance`, { headers }),
    rate: (q: Record<string, string>) => call<Record<string, unknown>>(`${base}/secure/rate?${new URLSearchParams(q)}`, { headers }),
  };
}

/**
 * Wait for the gateway to adopt a configuration change. The poll interval is 2 s in this rig, so
 * `nudge` (POST /ops/reload) is the default and a case whose point is the poll passes nudge:false.
 */
export async function awaitGatewayAdopts(check: () => Promise<boolean>, opts: { nudge?: boolean; timeoutMs?: number } = {}): Promise<void> {
  const env = e2eEnv();
  if (opts.nudge !== false) await ops(env).reload().catch(() => undefined);
  await waitFor(async () => (await check()) || undefined, { timeoutMs: opts.timeoutMs ?? 20_000, intervalMs: 500, what: "the gateway to adopt the change" });
}

/** `scripts/fireflo <verb…>` against the e2e database and gateway. */
export function cli(args: string[], extraEnv: NodeJS.ProcessEnv = {}): { status: number; stdout: string; stderr: string } {
  const env = e2eEnv();
  if (!env.gatewayRepo) throw new Error("E2E_GATEWAY_REPO is not set; the CLI is unavailable");
  const u = new URL(env.databaseUrl);
  try {
    const stdout = execFileSync(path.join(env.gatewayRepo, "scripts", "fireflo"), args, {
      cwd: env.gatewayRepo,
      encoding: "utf8",
      stdio: ["ignore", "pipe", "pipe"],
      env: {
        ...process.env,
        FIREFLO_DB_URL: `jdbc:postgresql://${u.hostname}:${u.port || "5432"}${u.pathname}`,
        FIREFLO_DB_USER: decodeURIComponent(u.username),
        FIREFLO_DB_PASSWORD: decodeURIComponent(u.password),
        FIREFLO_OPS_URL: env.gatewayOpsUrl,
        FIREFLO_OPS_TOKEN: env.opsReadToken,
        FIREFLO_OPS_ADMIN_TOKEN: env.opsAdminToken,
        FIREFLO_SEND_URL: env.gatewayApiUrl,
        ...extraEnv,
      },
    });
    return { status: 0, stdout, stderr: "" };
  } catch (e) {
    const err = e as { status?: number; stdout?: string; stderr?: string };
    return { status: err.status ?? 1, stdout: err.stdout ?? "", stderr: err.stderr ?? "" };
  }
}
