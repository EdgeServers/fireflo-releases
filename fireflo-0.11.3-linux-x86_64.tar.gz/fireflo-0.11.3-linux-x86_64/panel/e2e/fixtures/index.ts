/**
 * The extended `test` every spec uses. A spec never imports `@playwright/test` directly, so `tc()`
 * hands every test the same set and a new fixture reaches every epic at once.
 *
 * Worker-scoped: `db` (one small pool) and `workerSeed` prefix. Test-scoped: `seed` (undone after
 * the test), `operatorApi` / `portalApi` (request contexts carrying a session), `anonContext` /
 * `anonPage` (no cookies at all), `portalPage` (a browser context signed in as an account).
 *
 * The operator projects give `page` an operator session through the project's storageState, so
 * `page` there is already signed in; `anonPage` is the way to be signed out.
 */
import { test as base, expect } from "@playwright/test";
import type { APIRequestContext, BrowserContext, Page, TestInfo } from "@playwright/test";
import { carryCookie, mintOperatorContext, mintPortalContext, PORTAL_COOKIE } from "./auth";
import { openDb } from "./db";
import type { Db } from "./db";
import { e2eEnv, capabilities } from "./env";
import type { E2EEnv, Capability } from "./env";
import { makeSeed } from "./seed";
import type { Seed } from "./seed";

/** Per-test context for the sheet: `note()` is what lands in "Actual result". */
export interface TcContext {
  info: TestInfo;
  id: string;
  note(text: string): void;
}

export interface E2EFixtures {
  /** auto: skips the manual/todo/fixme/blocked kinds before any other fixture is built */
  tcGuard: void;
  env: E2EEnv;
  caps: Set<Capability>;
  tcx: TcContext;
  seed: Seed;
  operatorApi: APIRequestContext;
  /** a request context signed in as an account: `await portalApi("qa-portal-a")` */
  portalApi: (accountId: string) => Promise<APIRequestContext>;
  anonContext: BrowserContext;
  anonPage: Page;
  /** a browser page signed in as an account: `await portalPage("qa-portal-a")` */
  portalPage: (accountId: string) => Promise<Page>;
}

export interface E2EWorkerFixtures {
  db: Db;
}

export const test = base.extend<E2EFixtures, E2EWorkerFixtures>({
  tcGuard: [async ({}, provide, info) => {
    const kind = info.annotations.find((a) => a.type === "tc-kind")?.description;
    const reason = info.annotations.find((a) => a.type === "tc-reason")?.description ?? "";
    if (kind === "manual") info.skip(true, `manual: ${reason}`);
    else if (kind === "todo") info.skip(true, "todo: not automated yet");
    else if (kind === "blocked") info.skip(true, `blocked: ${reason}`);
    else if (kind === "fixme") info.fixme(true, `fixme: ${reason}`);
    await provide();
  }, { auto: true }],

  db: [async ({}, provide) => {
    const db = openDb(2);
    await provide(db);
    await db.close();
  }, { scope: "worker" }],

  env: async ({}, provide) => { await provide(e2eEnv()); },
  caps: async ({}, provide) => { await provide(capabilities()); },
  tcx: async ({}, provide, info) => {
    await provide({
      info,
      id: info.annotations.find((a) => a.type === "tc")?.description ?? "",
      note(text: string) { info.annotations.push({ type: "note", description: text }); },
    });
  },

  seed: async ({ db }, provide, info) => {
    const seed = makeSeed(db, info.workerIndex);
    await provide(seed);
    await seed.undo();
  },

  operatorApi: async ({}, provide) => {
    const ctx = await mintOperatorContext();
    await provide(ctx);
    await ctx.dispose();
  },

  portalApi: async ({ db }, provide) => {
    const made: APIRequestContext[] = [];
    await provide(async (accountId: string) => {
      const ctx = await mintPortalContext(db, accountId);
      made.push(ctx);
      return ctx;
    });
    for (const c of made) await c.dispose();
  },

  anonContext: async ({ browser }, provide) => {
    const ctx = await browser.newContext({ storageState: undefined });
    await provide(ctx);
    await ctx.close();
  },
  anonPage: async ({ anonContext }, provide) => {
    await provide(await anonContext.newPage());
  },

  portalPage: async ({ browser, db }, provide) => {
    const contexts: BrowserContext[] = [];
    await provide(async (accountId: string) => {
      const api = await mintPortalContext(db, accountId);
      const ctx = await browser.newContext({ storageState: undefined });
      await carryCookie(api, ctx, PORTAL_COOKIE);
      await api.dispose();
      contexts.push(ctx);
      return ctx.newPage();
    });
    for (const c of contexts) await c.close();
  },
});

export { expect };
export type { E2EEnv, Capability, Db, Seed };
