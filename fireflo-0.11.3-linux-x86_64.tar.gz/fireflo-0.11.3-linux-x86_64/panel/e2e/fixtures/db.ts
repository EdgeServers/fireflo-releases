/**
 * The e2e database, read and written directly. The suite's oracles are mostly rows — a CDR that
 * exists, a balance that moved, an audit line — so this is the fixture most tests touch.
 *
 * One small pool per worker. `truncateAll()` is setup-only and guarded twice: by the "e2e" rule on
 * the database name in env.ts and by refusing to run while a test is executing.
 */
import { Pool } from "pg";
import type { PoolClient, QueryResultRow } from "pg";
import { e2eEnv } from "./env";
import { waitFor } from "../support/wait";

export interface Db {
  q<T extends QueryResultRow = QueryResultRow>(sql: string, params?: unknown[]): Promise<T[]>;
  one<T extends QueryResultRow = QueryResultRow>(sql: string, params?: unknown[]): Promise<T>;
  maybe<T extends QueryResultRow = QueryResultRow>(sql: string, params?: unknown[]): Promise<T | null>;
  scalar<T = unknown>(sql: string, params?: unknown[]): Promise<T>;
  count(table: string, where?: string, params?: unknown[]): Promise<number>;
  /** poll until a row matches; the oracle for anything the gateway writes asynchronously */
  waitForRow<T extends QueryResultRow = QueryResultRow>(sql: string, params?: unknown[], opts?: { timeoutMs?: number; what?: string }): Promise<T>;
  /** poll until a count is reached */
  waitForCount(table: string, where: string, params: unknown[], n: number, opts?: { timeoutMs?: number }): Promise<number>;
  /** run `work` holding a transaction-scoped advisory lock keyed on `key` — shared app_config edits */
  withAdvisoryLock<T>(key: string, work: (c: PoolClient) => Promise<T>): Promise<T>;
  tx<T>(work: (c: PoolClient) => Promise<T>): Promise<T>;
  close(): Promise<void>;
}

export function openDb(max = 2): Db {
  const pool = new Pool({ connectionString: e2eEnv().databaseUrl, max, idleTimeoutMillis: 10_000 });
  const db: Db = {
    async q(sql, params = []) { return (await pool.query(sql, params)).rows; },
    async one(sql, params = []) {
      const rows = await db.q(sql, params);
      if (rows.length !== 1) throw new Error(`expected one row, got ${rows.length}: ${sql}`);
      return rows[0] as never;
    },
    async maybe(sql, params = []) {
      const rows = await db.q(sql, params);
      return (rows[0] as never) ?? null;
    },
    async scalar(sql, params = []) {
      const row = await db.one(sql, params);
      return Object.values(row)[0] as never;
    },
    async count(table, where = "true", params = []) {
      return Number(await db.scalar(`SELECT count(*)::int AS n FROM ${table} WHERE ${where}`, params));
    },
    waitForRow(sql, params = [], opts = {}) {
      return waitFor(async () => (await db.q(sql, params))[0] as never, { timeoutMs: opts.timeoutMs ?? 15_000, intervalMs: 250, what: opts.what ?? `a row from: ${sql}` });
    },
    async waitForCount(table, where, params, n, opts = {}) {
      return waitFor(async () => {
        const c = await db.count(table, where, params);
        return c >= n ? c : undefined;
      }, { timeoutMs: opts.timeoutMs ?? 15_000, intervalMs: 250, what: `count(${table} where ${where}) >= ${n}` });
    },
    async withAdvisoryLock(key, work) {
      return db.tx(async (c) => {
        await c.query("SELECT pg_advisory_xact_lock(hashtext($1))", [key]);
        return work(c);
      });
    },
    async tx(work) {
      const c = await pool.connect();
      try {
        await c.query("BEGIN");
        const r = await work(c);
        await c.query("COMMIT");
        return r;
      } catch (e) {
        await c.query("ROLLBACK").catch(() => undefined);
        throw e;
      } finally {
        c.release();
      }
    },
    close: () => pool.end(),
  };
  return db;
}

/** Every public table except Flyway's history, so the schema stays migrated. Setup only. */
export async function truncateAll(db: Db): Promise<string[]> {
  const tables = (await db.q<{ tablename: string }>(
    "SELECT tablename FROM pg_tables WHERE schemaname = 'public' AND tablename <> 'flyway_schema_history' ORDER BY 1",
  )).map((r) => r.tablename);
  if (tables.length) await db.q(`TRUNCATE ${tables.map((t) => `"${t}"`).join(", ")} RESTART IDENTITY CASCADE`);
  return tables;
}

/** The identity every money test ends on: Σ applied credit == balance + reserved, per account. */
export async function balanceIdentity(db: Db, accountId: string): Promise<{ credited: string; balance: string; reserved: string; exact: boolean }> {
  const row = await db.one<{ credited: string; balance: string; reserved: string }>(
    `SELECT COALESCE((SELECT sum(delta) FROM balance_ledger l
                       WHERE l.account_id = $1 AND l.applied AND l.entry_type IN ('RECHARGE') ), 0)::text AS credited,
            b.balance::text, b.reserved::text
       FROM account_balance b WHERE b.account_id = $1`,
    [accountId],
  );
  const exact = BigInt(row.credited) === BigInt(row.balance) + BigInt(row.reserved);
  return { ...row, exact };
}
