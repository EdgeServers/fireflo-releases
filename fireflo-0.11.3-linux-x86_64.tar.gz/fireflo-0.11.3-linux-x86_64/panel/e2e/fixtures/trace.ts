/**
 * The gateway's log files as oracles: smsg.log (message trace, reclaim lines, routing misses),
 * auth-failed.log (every refused bind and REST auth), smppclient.log / smppserver.log. Mode A
 * writes them under e2e/.run/logs; mode B needs E2E_GATEWAY_LOG for smsg.log and has no
 * auth-failed.log unless it sits beside it.
 */
import { existsSync, readFileSync, statSync } from "node:fs";
import path from "node:path";
import { e2eEnv } from "./env";
import { waitFor } from "../support/wait";

export interface LogMark { file: string; offset: number; at: number }

function logFile(name: "smsg" | "auth-failed" | "smppclient" | "smppserver" | "httpapi"): string {
  const env = e2eEnv();
  if (!env.startGateway) {
    if (!env.gatewayLog) throw new Error("E2E_GATEWAY_LOG is not set; the gateway's logs are not readable in this run");
    return name === "smsg" ? env.gatewayLog : path.join(path.dirname(env.gatewayLog), `${name}.log`);
  }
  return path.join(env.runDir, "logs", name === "httpapi" ? "httpapi.log" : `${name}.log`);
}

function read(file: string, from = 0): string {
  if (!existsSync(file)) return "";
  const size = statSync(file).size;
  if (size <= from) return "";
  const buf = readFileSync(file);
  return buf.subarray(from).toString("utf8");
}

function log(name: Parameters<typeof logFile>[0]) {
  const file = () => logFile(name);
  return {
    file,
    mark(): LogMark {
      const f = file();
      return { file: f, offset: existsSync(f) ? statSync(f).size : 0, at: Date.now() };
    },
    since: (mark: LogMark) => read(mark.file, mark.offset),
    lines: (mark: LogMark) => read(mark.file, mark.offset).split("\n").filter(Boolean),
    grep: (re: RegExp, mark: LogMark) => read(mark.file, mark.offset).split("\n").filter((l) => re.test(l)),
    count: (re: RegExp, mark: LogMark) => read(mark.file, mark.offset).split("\n").filter((l) => re.test(l)).length,
    /** the first line matching `re` written after `mark`; the match array's `input` is the whole line */
    waitFor(re: RegExp, mark: LogMark, timeoutMs = 20_000): Promise<RegExpMatchArray & { input: string }> {
      return waitFor(() => { for (const l of read(mark.file, mark.offset).split("\n")) { const m = l.match(re); if (m) return m as RegExpMatchArray & { input: string }; } return undefined; }, { timeoutMs, intervalMs: 200, what: `${name}.log to contain ${re}` });
    },
    /** every trace line naming one gateway message id, in order */
    traceOf: (gatewayMsgId: string, mark?: LogMark) => read(mark?.file ?? file(), mark?.offset ?? 0).split("\n").filter((l) => l.includes(gatewayMsgId)),
  };
}

export const gatewayLog = log("smsg");
export const authFailedLog = log("auth-failed");
export const smppClientLog = log("smppclient");
export const smppServerLog = log("smppserver");
export const httpApiLog = log("httpapi");
