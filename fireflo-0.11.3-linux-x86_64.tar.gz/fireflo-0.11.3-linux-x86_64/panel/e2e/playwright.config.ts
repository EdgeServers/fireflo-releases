/**
 * FireFlo 0.11 QA suite — one Playwright project per surface, one spec per story, one `tc()` per
 * sheet id. See e2e/README.md for how a run is set up and how results reach the workbook.
 */
import { defineConfig, devices } from "@playwright/test";
import path from "node:path";
import { e2eEnv } from "./fixtures/env";

const env = e2eEnv();
const runDir = path.join(__dirname, ".run");

export default defineConfig({
  testDir: __dirname,
  testMatch: ["epics/**/*.spec.ts", "selftest/**/*.spec.ts"],
  outputDir: path.join(__dirname, "test-results"),
  globalSetup: path.join(__dirname, "global-setup.ts"),
  globalTeardown: path.join(__dirname, "global-teardown.ts"),
  // retries: 0 on purpose — a retry hides exactly the flakiness the sheet has to record
  retries: 0,
  fullyParallel: false,
  forbidOnly: !!process.env.CI,
  // generous: under `next dev` a route's first compile can take tens of seconds
  timeout: 90_000,
  expect: { timeout: 10_000 },
  reporter: [
    ["list"],
    ["html", { outputFolder: path.join(__dirname, "report", "html"), open: "never" }],
    [path.join(__dirname, "reporters", "tc-results.ts")],
  ],
  use: {
    baseURL: env.panelUrl,
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
    video: "off",
  },
  projects: [
    {
      name: "selftest",
      testMatch: /selftest\/.*\.spec\.ts$/,
      use: { ...devices["Desktop Chrome"] },
    },
    {
      // EP-17..21: the operator panel at /cp. Several workers; seeds are prefixed per worker and
      // shared app_config edits take an advisory lock.
      name: "panel-operator",
      testMatch: /epics\/EP-(17|18|19|20|21)-.*\.spec\.ts$/,
      workers: 4,
      use: { ...devices["Desktop Chrome"], storageState: path.join(runDir, "state", "operator.json") },
    },
    {
      // EP-22..23: the customer portal. Two workers — the portal's in-process rate limiters are
      // per address, so anything that exercises them is @serial.
      name: "panel-portal",
      testMatch: /epics\/EP-(22|23)-.*\.spec\.ts$/,
      workers: 2,
      use: { ...devices["Desktop Chrome"] },
    },
    {
      // EP-01..16, EP-24: the gateway over SMPP, REST and /ops. One worker: EdgeSmsc state and
      // app_config are process-global, and the vendor-death cases kill a shared process.
      name: "gateway",
      testMatch: /epics\/EP-(0[1-9]|1[0-6]|24)-.*\.spec\.ts$/,
      workers: 1,
      timeout: 120_000,
      use: { ...devices["Desktop Chrome"], storageState: path.join(runDir, "state", "operator.json") },
    },
  ],
  // no `webServer`: global setup starts the panel itself, after the database is ready and with
  // the environment `baselinePanelEnv()` describes — the same function the variants use.
});
