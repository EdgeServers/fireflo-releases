/**
 * Brings up the self-contained rig before any project starts. The steps are ordered so that each
 * one's failure names what is missing rather than what it broke:
 *
 *   1. environment and the "e2e" database-name guard (env.ts throws)
 *   2. the SMTP sinks' certificate, so the panel can start with NODE_EXTRA_CA_CERTS in place
 *   3. the database: create if absent → migrate → truncate → bootstrap → seed the baseline
 *   4. the vendor side (EdgeSmsc A/B) and the gateway — mode A; a health probe — mode B
 *   5. the production build, when panel variants are wanted, THEN the dev panel on E2E_PANEL_PORT
 *   6. the SMTP sinks
 *   7. storage states for the operator (the portal is minted per test)
 *
 * The panel is started here rather than by Playwright's `webServer` so that it comes up after the
 * database is ready and with exactly the environment `baselinePanelEnv()` describes — the same
 * function the variants use, so a variant differs from the baseline only by its overrides.
 *
 * PIDs of everything spawned land in e2e/.run/state.json; teardown kills only those.
 *
 * `E2E_LISTING=1` (set by the catalog check) and `E2E_NO_RIG=1` (the selftest) stop after step 1 —
 * a listing must not start a rig.
 */
import { execFileSync, spawnSync } from "node:child_process";
import { existsSync, mkdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import { chromium } from "@playwright/test";
import type { FullConfig } from "@playwright/test";
import { Client } from "pg";
import { mintOperatorContext } from "./fixtures/auth";
import { openDb, truncateAll } from "./fixtures/db";
import { e2eEnv } from "./fixtures/env";
import type { E2EEnv } from "./fixtures/env";
import { baselinePanelEnv } from "./fixtures/panel-variant";
import { portInUse, spawnTracked } from "./fixtures/process";
import { seedBaseline } from "./fixtures/seed";
import { updateState, writeState } from "./fixtures/state";
import { startGatewayRig } from "./fixtures/gateway-rig";
import { startSmtpSinks } from "./fixtures/sinks";
import { waitFor } from "./support/wait";

export default async function globalSetup(_config: FullConfig) {
  const env = e2eEnv();
  for (const d of ["state", "smtp", "panel-data/exports", "panel-data/access", "conf", "data", "logs"]) {
    mkdirSync(path.join(env.runDir, d), { recursive: true });
  }
  writeState({ startedAt: new Date().toISOString(), pids: [], gatewayUp: false, panelBuilt: false, bootstrapLogin: null, ports: {} });
  if (process.env.E2E_LISTING === "1" || process.env.E2E_NO_RIG === "1") return;

  const t0 = Date.now();
  const step = (msg: string) => console.log(`[e2e setup +${((Date.now() - t0) / 1000).toFixed(1)}s] ${msg}`);

  step("SMTP certificate");
  ensureSmtpCert(env);

  step(`database ${dbName(env)}`);
  await ensureDatabase(env);
  await migrate(env);
  const db = openDb(2);
  try {
    const truncated = await truncateAll(db);
    step(`truncated ${truncated.length} tables; bootstrap --port ${env.smppPort}`);
    bootstrap(env);
    // bootstrap writes exactly one login; its type spelling is the gateway's business
    const login = await db.one<{ system_id: string }>("SELECT system_id FROM app_credential ORDER BY id LIMIT 1");
    const password = "qa-bootstrap-password-1";
    await db.q("UPDATE app_credential SET password = $1 WHERE system_id = $2", [password, login.system_id]);
    updateState((s) => { s.bootstrapLogin = { systemId: login.system_id, password }; });
    step(`seed baseline (bootstrap login ${login.system_id})`);
    await seedBaseline(db, env);
  } finally {
    await db.close();
  }

  step("gateway rig");
  await startGatewayRig(env);

  if (env.panelVariants) {
    if (process.env.E2E_PANEL_REBUILD === "1" || !existsSync(path.join(env.root, ".next", "BUILD_ID"))) {
      step("next build (for panel variants; set E2E_PANEL_VARIANTS=0 to skip)");
      const r = spawnSync("npx", ["next", "build"], { cwd: env.root, stdio: "inherit", env: { ...process.env, ...baselinePanelEnv(env.panelPort) } });
      if (r.status !== 0) throw new Error("next build failed; panel variants unavailable");
    } else {
      step("next build: reusing .next (E2E_PANEL_REBUILD=1 to rebuild)");
    }
    updateState((s) => { s.panelBuilt = true; });
  }

  step(`panel on ${env.panelUrl}`);
  await startPanel(env);

  step("SMTP sinks");
  await startSmtpSinks(env);

  step("operator storage state");
  const ctx = await mintOperatorContext();
  await ctx.storageState({ path: path.join(env.runDir, "state", "operator.json") });
  await ctx.dispose();

  step("warming the panel's client bundles");
  await warmPanel(env);
  step("ready");
}

/**
 * `next dev` compiles a route's client bundle the first time a browser asks for it — tens of
 * seconds on a cold tree — and until then the page is server-rendered HTML that never hydrates: a
 * form fills but its submit stays disabled. Visiting the routes every project starts on, with a real
 * browser, moves that cost here rather than into the first test's timeout.
 */
async function warmPanel(env: E2EEnv): Promise<void> {
  const browser = await chromium.launch();
  try {
    const context = await browser.newContext({ storageState: path.join(env.runDir, "state", "operator.json") });
    const page = await context.newPage();
    for (const p of ["/cp/login", "/cp", "/cp/accounts", "/", "/overview"]) {
      await page.goto(`${env.panelUrl}${p}`, { waitUntil: "networkidle", timeout: 120_000 }).catch((e) => console.warn(`[e2e setup] warm ${p}: ${e.message}`));
    }
    await context.close();
  } finally {
    await browser.close();
  }
}

function dbName(env: E2EEnv): string {
  return new URL(env.databaseUrl).pathname.replace(/^\//, "");
}

/** `CREATE DATABASE` through the maintenance database when the e2e one is absent. */
async function ensureDatabase(env: E2EEnv): Promise<void> {
  const name = dbName(env);
  const admin = new URL(env.databaseUrl);
  admin.pathname = "/postgres";
  const c = new Client({ connectionString: admin.toString() });
  await c.connect();
  try {
    const exists = await c.query("SELECT 1 FROM pg_database WHERE datname = $1", [name]);
    if (exists.rowCount === 0) {
      await c.query(`CREATE DATABASE "${name}"`);
      console.log(`[e2e setup] created database ${name}`);
    }
  } finally {
    await c.end();
  }
}

/** The gateway's own CLI as the migration tool; its env wants a JDBC URL and the interlock. */
function gatewayCliEnv(env: E2EEnv): NodeJS.ProcessEnv {
  if (!env.gatewayRepo) throw new Error("E2E_GATEWAY_REPO is needed to migrate and bootstrap the database");
  const u = new URL(env.databaseUrl);
  return {
    ...process.env,
    FIREFLO_DB_URL: `jdbc:postgresql://${u.hostname}:${u.port || "5432"}${u.pathname}`,
    FIREFLO_DB_USER: decodeURIComponent(u.username),
    FIREFLO_DB_PASSWORD: decodeURIComponent(u.password),
    FIREFLO_DB_MIGRATE: "true",
    FIREFLO_OPS_URL: env.gatewayOpsUrl,
    FIREFLO_OPS_TOKEN: env.opsReadToken,
    FIREFLO_OPS_ADMIN_TOKEN: env.opsAdminToken,
  };
}

export function gatewayCli(env: E2EEnv, args: string[], extraEnv: NodeJS.ProcessEnv = {}): string {
  return execFileSync(path.join(env.gatewayRepo!, "scripts", "fireflo"), args, {
    cwd: env.gatewayRepo!,
    env: { ...gatewayCliEnv(env), ...extraEnv },
    encoding: "utf8",
    stdio: ["ignore", "pipe", "pipe"],
  });
}

function migrate(env: E2EEnv): void {
  const out = gatewayCli(env, ["db", "migrate"]);
  const m = out.match(/Successfully (?:applied|validated) (\d+) migrations?|no migration necessary|up to date/i);
  console.log(`[e2e setup] db migrate: ${m ? m[0] : out.trim().split("\n").slice(-1)[0]}`);
}

function bootstrap(env: E2EEnv): void {
  const out = gatewayCli(env, ["bootstrap", "--port", String(env.smppPort)]);
  console.log(`[e2e setup] bootstrap: ${out.trim().split("\n").slice(-1)[0]}`);
}

function ensureSmtpCert(env: E2EEnv): void {
  const dir = path.join(env.runDir, "smtp");
  const ca = path.join(dir, "ca.pem");
  const key = path.join(dir, "key.pem");
  if (existsSync(ca) && existsSync(key)) return;
  execFileSync("openssl", [
    "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "2",
    "-keyout", key, "-out", ca,
    "-subj", "/CN=127.0.0.1", "-addext", "subjectAltName=IP:127.0.0.1,DNS:localhost",
  ], { stdio: ["ignore", "ignore", "pipe"] });
}

async function startPanel(env: E2EEnv): Promise<void> {
  if (await portInUse(env.panelPort)) {
    if (process.env.E2E_REUSE_PANEL === "1") { console.log(`[e2e setup] reusing the panel already on ${env.panelPort}`); return; }
    throw new Error(`port ${env.panelPort} is already in use; stop it (by its own PID) or set E2E_REUSE_PANEL=1 to test against it`);
  }
  const proc = spawnTracked("panel", "npx", ["next", "dev", "-p", String(env.panelPort)], {
    cwd: env.root,
    env: baselinePanelEnv(env.panelPort),
  });
  await waitFor(async () => {
    const res = await fetch(`${env.panelUrl}/cp/login`).catch(() => null);
    return res?.status === 200;
  }, { timeoutMs: 120_000, intervalMs: 500, what: `the panel on ${env.panelUrl}` });
  // the first compile of a route under `next dev` is slow; warm the ones every project hits
  for (const p of ["/cp", "/", "/api/auth/csrf", "/api/mis/auth/csrf"]) await fetch(`${env.panelUrl}${p}`).catch(() => undefined);
  writeFileSync(path.join(env.runDir, "panel.url"), env.panelUrl);
  void proc;
}
