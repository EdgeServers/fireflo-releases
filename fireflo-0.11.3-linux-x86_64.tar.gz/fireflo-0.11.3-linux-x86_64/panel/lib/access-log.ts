import { appendFile, mkdir } from "node:fs/promises";
import path from "node:path";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { accessLogDir } from "@/lib/data-dir";

/**
 * Who did what, on disk, for as long as the disk lasts.
 *
 * <h2>Why a file</h2>
 *
 * <p>Until this existed the only record of an operator action was `console.*` into the systemd
 * journal, which rotates on the host's schedule and is gone. A failed sign-in was not even that:
 * `lib/auth.ts` returned null in silence, so somebody working through passwords left no trace at
 * all.
 *
 * <p>Operator events go here rather than to the database on purpose. The database is the thing an
 * operator can already change through this panel; an append-only file they would have to reach the
 * host to alter is a better record of what they did. Customer events go the other way — see
 * `lib/customer-access-log.ts` — because those are asked about per account and want to be queried.
 *
 * <h2>Nothing here is ever deleted</h2>
 *
 * <p>A new file per UTC day, kept forever. This is worth saying plainly because `lib/exports.ts`
 * sits in a sibling directory and sweeps itself on every list call, so the next reader will
 * reasonably assume the same happens here. It does not. If the volume ever matters, archive the old
 * files off the box; do not add a sweep, because the point of an access log is that it still exists
 * after the period somebody wishes it did not.
 *
 * <h2>It must never break a request</h2>
 *
 * <p>Every write is wrapped, every failure is swallowed, and the returned promise always resolves.
 * A logging call that can throw turns an unwritable directory into a panel nobody can sign into,
 * which is a worse outcome than the gap in the log. Call sites use `void logOperatorEvent(...)`.
 */

/** What happened. Kept short and machine-greppable; the sentence goes in `detail`. */
export type OperatorEvent =
  | "signin"
  | "signin_failed"
  | "signout"
  | "download"
  | "export_deleted"
  | "capture_started"
  //gateway-wide configuration. Two events rather than one because "cleared" and "set" are different
  //acts: clearing a key hands the decision back to the tier above, which is a thing an operator does
  //deliberately and a thing that has to be findable afterwards
  | "gateway_setting_set"
  | "gateway_setting_cleared"
  //routing had no audit event at all before this one, and the recreate is the write that most
  //needed it: it is the only action that can add rules to several lanes and reorder the entry-point
  //table in one go. `app_route_table` carries an updated_at and no updated_by, so without this the
  //only record of who rebuilt routing is the timestamp
  | "routing_recreated"
  //the only action in this panel that changes the HOST rather than the gateway or the database, and
  //the only one that reaches root. It also undoes a security control, so "who released this address
  //and when" is a question that will be asked -- and this file is the answer, because it is the one
  //record an operator cannot edit from the panel. fail2ban writes its own unban line as well; the
  //two should agree, and a gap between them is worth noticing
  | "ip_unbanned";

export interface OperatorEntry {
  event: OperatorEvent;
  /** The operator's username, or the one that was attempted on a failure. */
  actor: string | null;
  ip: string | null;
  userAgent?: string | null;
  detail?: Record<string, unknown>;
}

/**
 * Keeps one line inside the size that makes an append atomic.
 *
 * <p>`appendFile` opens with `O_APPEND`, and on Linux a single write below `PIPE_BUF` will not
 * interleave with another process's. Above it, two concurrent downloads can produce one corrupt
 * line each. 3500 leaves room for the fixed fields under the 4096 limit.
 */
const MAX_LINE = 3500;

/** Long enough to identify a browser or a worker, short enough not to dominate the line. */
const MAX_FIELD = 256;

/** So an unwritable directory produces one complaint, not one per request forever. */
let complained = false;

/** Appends are chained so two callers in this process cannot be mid-write at the same moment. */
let tail: Promise<void> = Promise.resolve();

export async function logOperatorEvent(entry: OperatorEntry): Promise<void> {
  const line = serialise(entry);
  //chained rather than awaited by the caller: ordering within the process is worth having, blocking
  //a download on a disk write is not
  tail = tail.then(() => write(line)).catch(() => undefined);
  return tail;
}

/** Which front door was knocked on. The operator panel, or a customer's portal. */
export type AuthSurface = "panel" | "portal";

export interface AuthFailure {
  surface: AuthSurface;
  /** A short machine token. Never says which half of a credential was wrong. */
  reason: string;
  /** The name or address that was tried, if there was one. Never a secret. */
  triedAs: string | null;
  ip: string | null;
}

/**
 * A refused sign-in, in the file fail2ban reads.
 *
 * <h2>Why this is a separate file from the two audit logs</h2>
 *
 * <p>The operator access log records what an operator DID and is an audit trail; the customer
 * access log is in the database because it is asked about per account. Neither is a good thing to
 * point a jail at: one is a mixed record where a successful sign-in sits beside a failed one, and
 * the other is a database fail2ban cannot read at all.
 *
 * <p>So refused sign-ins also go here, to `auth-failed-<UTC day>.jsonl` — one line per refusal and
 * nothing else, exactly as the gateway writes `auth-failed.log` for the same reason. It is empty on
 * a panel nobody is attacking, cheap for fail2ban to watch, and greppable during an incident.
 * The audit logs keep their own entries; only THIS file is watched, so nothing is counted twice.
 *
 * <p><strong>Only caller-driven failures belong here.</strong> A sign-in link that could not be sent
 * because our SMTP is unconfigured is our fault, not the visitor's, and banning on it would cut off
 * a customer because our mailer broke. The call sites decide; this writes what it is given.
 *
 * <p>No address, no line: a refusal fail2ban cannot ban from does not protect anything and would
 * still count against the window a jail is measuring.
 */
export async function logAuthFailure(entry: AuthFailure): Promise<void> {
  if (!entry.ip) {
    return;
  }
  const line = `${JSON.stringify({
    ts: new Date().toISOString(),
    surface: entry.surface,
    reason: entry.reason,
    triedAs: clip(entry.triedAs),
    ip: entry.ip,
  })}\n`;
  tail = tail.then(() => write(line, "auth-failed")).catch(() => undefined);
  return tail;
}

function serialise(entry: OperatorEntry): string {
  const record: Record<string, unknown> = {
    ts: new Date().toISOString(),
    event: entry.event,
    actor: clip(entry.actor),
    ip: entry.ip ?? null,
  };
  if (entry.userAgent) {
    record.ua = clip(entry.userAgent);
  }
  if (entry.detail && Object.keys(entry.detail).length > 0) {
    record.detail = clipDetail(entry.detail);
  }

  let line = JSON.stringify(record);
  if (line.length > MAX_LINE) {
    //the detail is the only part that can grow without bound, so it is the part that goes. Saying
    //so beats a silently truncated line that still parses and quietly means something else
    record.detail = { truncated: true };
    line = JSON.stringify(record);
  }
  return `${line}\n`;
}

function clip(value: string | null | undefined): string | null {
  if (!value) {
    return null;
  }
  return value.length > MAX_FIELD ? `${value.slice(0, MAX_FIELD - 3)}...` : value;
}

function clipDetail(detail: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(detail)) {
    out[key] = typeof value === "string" ? clip(value) : value;
  }
  return out;
}

async function write(line: string, prefix = "operator"): Promise<void> {
  try {
    const dir = accessLogDir();
    await mkdir(dir, { recursive: true });
    //UTC, so a file boundary means the same thing wherever the server and the reader are
    const day = new Date().toISOString().slice(0, 10);
    await appendFile(path.join(dir, `${prefix}-${day}.jsonl`), line, "utf8");
    complained = false;
  } catch (err) {
    if (!complained) {
      complained = true;
      console.error("access log: could not write, continuing without it", err);
    }
  }
}

/**
 * Runs a download and records it, but only if it actually produced one.
 *
 * <p>The status gate is the point. `app/api/control/cdrs/export/[id]` answers 409 while an export is
 * still being prepared, and a refused request logged as a download would put a file in somebody's
 * hands on paper that they never received.
 *
 * <p>For a streamed response a 2xx means the transfer *started* — the body is produced after this
 * returns. That is the honest granularity: nothing here can know whether the connection survived.
 *
 * <p>Wrapped at the route rather than inside `callOpsDownload`, which has neither a request nor a
 * session; teaching a transport helper about authentication to save four call sites is a worse
 * trade than four call sites.
 */
export async function auditedDownload(
  req: { headers: Headers },
  what: { kind: string; actor: string | null; subject?: string },
  produce: () => Promise<Response>
): Promise<Response> {
  const response = await produce();
  if (response.ok) {
    void logOperatorEvent({
      event: "download",
      actor: what.actor,
      ip: clientIp(req),
      userAgent: clientUserAgent(req),
      detail: what.subject ? { kind: what.kind, subject: what.subject } : { kind: what.kind },
    });
  }
  return response;
}
