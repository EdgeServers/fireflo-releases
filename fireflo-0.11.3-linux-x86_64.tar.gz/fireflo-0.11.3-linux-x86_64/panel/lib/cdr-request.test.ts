import { test } from "node:test";
import assert from "node:assert/strict";
import { MAX_TEXT_FILTER, isFilterError, messageIdClause, parseFilters } from "./cdr-request.ts";

/**
 * The filters on the wire, for the two surfaces that share this parser.
 *
 * <p>Both the operator page and the customer portal reach `parseFilters` with a query string the
 * browser did not have to have produced. The portal is the one that matters: it parses a
 * session-holder's parameters before the route narrows them to that session's accounts, so anything
 * unbounded here is unbounded for a customer.
 */

test("the message-text box lands on the body column, not on a parameter of its own", () => {
  const filters = parseFilters(new URLSearchParams("text=verification code"));
  assert.ok(!isFilterError(filters));
  //"text" is what a reader searching message content would call it; `body` is the schema's word.
  //If these ever drift apart the box silently filters nothing, which reads as "no such message"
  assert.equal(filters.body, "verification code");
});

test("a phrase longer than any body the gateway records is refused rather than run", () => {
  const params = new URLSearchParams();
  params.set("text", "x".repeat(MAX_TEXT_FILTER + 1));

  const filters = parseFilters(params);
  assert.ok(isFilterError(filters), "an over-long phrase should not reach the database");
  assert.match(filters.error, /longer than 1600 characters/);
});

test("a phrase exactly as long as the longest possible body is allowed", () => {
  //the boundary is inclusive on purpose: 1,600 characters is a real concatenated multipart message,
  //so somebody pasting one back in to find it is doing the obvious thing, not attacking anything
  const phrase = "x".repeat(MAX_TEXT_FILTER);
  const filters = parseFilters(new URLSearchParams([["text", phrase]]));
  assert.ok(!isFilterError(filters));
  assert.equal(filters.body, phrase);
});

test("the bound covers every text filter, not only the substring one", () => {
  //`text` is the only ILIKE, but an identifier field is still a string sent to the database, and a
  //ceiling that only guards the field somebody remembered is the kind that stops guarding
  const params = new URLSearchParams();
  params.set("dest", "9".repeat(MAX_TEXT_FILTER + 1));

  const filters = parseFilters(params);
  assert.ok(isFilterError(filters));
  assert.match(filters.error, /'dest'/);
});

test("whitespace around a phrase is not what makes it too long", () => {
  //the length test runs on the trimmed value, so a pasted phrase with a trailing newline is not
  //refused for a character the searcher cannot see and did not intend to type
  const params = new URLSearchParams();
  params.set("text", `  ${"x".repeat(MAX_TEXT_FILTER)}  `);

  const filters = parseFilters(params);
  assert.ok(!isFilterError(filters), "trimming happens before the ceiling is applied");
});

test("a message id matches its own row and any segment it was assembled from", () => {
  //the customer holds one id per submit_sm they sent, and quotes whichever is on the receipt they
  //are chasing. Only the first is gateway_msg_id; before the segment list, the rest found nothing
  const clause = messageIdClause("$3", true);

  assert.match(clause, /s\.gateway_msg_id = \$3/, "the message's own id still matches");
  assert.match(clause, /s\.reassembled_parts @> ARRAY\[\$3\]/, "and so does a segment's");
});

test("the id clause is bracketed, so an OR cannot escape the account scope", () => {
  //THE ONE THAT MATTERS. Callers AND these fragments together and one of them is the portal's
  //`account_id = ANY(...)`. Unbracketed, `A AND B OR C` binds as `(A AND B) OR C`, and C on its own
  //returns any message on the platform whose segment list holds an id the caller guessed -- a
  //cross-customer read reachable from the customer portal's own message-id box.
  const clause = messageIdClause("$1", true);

  assert.ok(clause.startsWith("("), "an unbracketed OR here is a data leak, not a formatting nit");
  assert.ok(clause.endsWith(")"));
});

test("against a gateway without the column, the clause names only what exists", () => {
  //naming reassembled_parts before V1.34.0 is a hard error, and it would take out id search
  //altogether rather than costing the extra half of it
  const clause = messageIdClause("$2", false);

  assert.equal(clause, "s.gateway_msg_id = $2");
  assert.ok(!clause.includes("reassembled_parts"));
});

test("the clause carries a placeholder, never a value", () => {
  //the query layer's standing promise: no caller string reaches the SQL text. An id is the most
  //tempting one to interpolate, because it looks like an opaque token rather than user input
  const clause = messageIdClause("$1", true);

  assert.ok(!clause.includes("'"), "no quoting means nothing was interpolated");
});
