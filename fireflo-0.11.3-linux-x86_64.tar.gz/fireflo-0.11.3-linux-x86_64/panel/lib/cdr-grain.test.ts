import { strict as assert } from "node:assert";
import { test } from "node:test";

import { carriesMoney, oneRowPerMessage } from "./cdr-grain.ts";

test("the predicate carries no retry term", () => {
  //the whole finding, pinned. A retried message's single row has retry_count >= 1, so adding
  //`AND retry_count = 0` does not deduplicate anything -- it drops the message, from the count and
  //from the money. Asserted by value because the failure is silent: correct-looking figures that
  //are low by the retry rate
  assert.equal(oneRowPerMessage(), "s.part_no = 1");
  assert.ok(!oneRowPerMessage().includes("retry_count"));
});

test("counting and summing are the same predicate, deliberately", () => {
  //one part-1 row per message means "how many messages" and "how much money" are the same set. Two
  //different predicates would be two chances to get it wrong, which is how this started
  assert.equal(carriesMoney(), oneRowPerMessage());
  assert.equal(carriesMoney("x"), oneRowPerMessage("x"));
});

test("the alias is applied, and an empty alias means an unaliased table", () => {
  //both spellings exist in the query layer -- some CTEs select straight from cdr_submit
  assert.equal(oneRowPerMessage("s"), "s.part_no = 1");
  assert.equal(oneRowPerMessage("cs"), "cs.part_no = 1");
  assert.equal(oneRowPerMessage(""), "part_no = 1");
});
