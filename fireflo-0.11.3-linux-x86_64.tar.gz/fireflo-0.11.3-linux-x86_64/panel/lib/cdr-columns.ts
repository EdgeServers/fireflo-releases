import type { CdrRow } from "./cdr-request";
import type { TableColumn } from "./table-columns";
//with the extension, because `node --test` runs these modules directly and does not read tsconfig
//paths or resolve extensionless specifiers. Type-only imports above are erased and need neither
import { resolveColumns as resolveFrom } from "./table-columns.ts";
import { receiptRequestSummary } from "./receipt-request.ts";

/**
 * Every column of a call record, in English, with how to render it.
 *
 * <p>Data rather than JSX, on the same reasoning as `labels.ts`: this is the one place a `cdr_submit`
 * column gets an English name, and the table, the column chooser and the detail view's raw record all
 * read it. A second copy in a component would drift from this the first time either was edited.
 *
 * <p>The choosing and remembering live in `table-columns.ts`, shared with `/accounts`. What stays
 * here is the part that is genuinely about call records: which columns exist, and how each renders.
 *
 * <p>Database-free, so a client component can import it.
 */

export type CdrFormat =
  | "time"
  | "text"
  //a message body: one line in the table, expandable in place. See LongText in CdrCell
  | "longtext"
  | "number"
  | "money"
  | "rate"
  | "percent"
  | "outcome"
  | "id";

export type CdrColumnGroup = "Message" | "Route" | "Money" | "Outcome";

/**
 * The seven columns that are on by default are exactly the seven the table rendered before there was
 * a chooser, so nobody's view changed on upgrade.
 */
export interface CdrColumn extends TableColumn<CdrRow, CdrColumnGroup> {
  format: CdrFormat;
}

export const CDR_COLUMNS: readonly CdrColumn[] = [
  //"Submitted", not "Accepted". The cell has always shown submitted_at; the old header was wrong,
  //and accepted_at is a genuinely different timestamp now offered separately below
  { id: "submittedAt", header: "Submitted", group: "Message", from: (r) => r.submittedAt, format: "time", defaultOn: true },
  { id: "acceptedAt", header: "Accepted", group: "Message", from: (r) => r.acceptedAt, format: "time", defaultOn: false },
  { id: "destAddr", header: "To", group: "Message", from: (r) => r.destAddr, format: "text", defaultOn: true },
  { id: "sourceAddr", header: "From", group: "Message", from: (r) => r.sourceAddr, format: "text", defaultOn: true },
  { id: "gatewayMsgId", header: "Message ID", group: "Message", from: (r) => r.gatewayMsgId, format: "id", defaultOn: false },
  { id: "partNo", header: "Part", group: "Message", from: (r) => r.partNo, format: "number", align: "right", defaultOn: false },
  { id: "partCount", header: "Parts", group: "Message", from: (r) => r.partCount, format: "number", align: "right", defaultOn: false },
  { id: "retryCount", header: "Retry", group: "Message", from: (r) => r.retryCount, format: "number", align: "right", defaultOn: false },
  { id: "dcs", header: "Data coding", group: "Message", from: (r) => r.dcs, format: "number", align: "right", defaultOn: false },
  { id: "msgType", header: "Message type", group: "Message", from: (r) => r.msgType, format: "number", align: "right", defaultOn: false },

  { id: "accountId", header: "Account", group: "Route", from: (r) => r.accountId, format: "text", defaultOn: true },
  { id: "systemId", header: "System ID", group: "Route", from: (r) => r.systemId, format: "text", defaultOn: false },
  { id: "product", header: "Product", group: "Route", from: (r) => r.product, format: "text", defaultOn: false },
  { id: "ingress", header: "Ingress", group: "Route", from: (r) => r.ingress, format: "text", defaultOn: false },
  { id: "inGateway", header: "In gateway", group: "Route", from: (r) => r.inGateway, format: "text", defaultOn: false },
  { id: "vendor", header: "Vendor", group: "Route", from: (r) => r.vendor, format: "text", defaultOn: true },
  { id: "mcc", header: "MCC", group: "Route", from: (r) => r.mcc, format: "number", align: "right", defaultOn: false },
  { id: "mnc", header: "MNC", group: "Route", from: (r) => r.mnc, format: "number", align: "right", defaultOn: false },

  { id: "price", header: "Billed", group: "Money", from: (r) => r.price, format: "money", align: "right", defaultOn: true },
  { id: "priceRate", header: "Price rate", group: "Money", from: (r) => r.priceRate, format: "rate", align: "right", defaultOn: false },
  { id: "billedUnits", header: "Billed units", group: "Money", from: (r) => r.billedUnits, format: "number", align: "right", defaultOn: false },
  { id: "cost", header: "Cost", group: "Money", from: (r) => r.cost, format: "money", align: "right", defaultOn: false },
  { id: "costRate", header: "Cost rate", group: "Money", from: (r) => r.costRate, format: "rate", align: "right", defaultOn: false },
  { id: "costUnits", header: "Cost units", group: "Money", from: (r) => r.costUnits, format: "number", align: "right", defaultOn: false },
  { id: "margin", header: "Margin", group: "Money", from: (r) => r.margin, format: "money", align: "right", defaultOn: false },
  { id: "marginPct", header: "Margin %", group: "Money", from: (r) => r.marginPct, format: "percent", align: "right", defaultOn: false },
  { id: "marginStatus", header: "Margin status", group: "Money", from: (r) => r.marginStatus, format: "text", defaultOn: false },
  { id: "currency", header: "Currency", group: "Money", from: (r) => r.currency, format: "text", defaultOn: false },
  { id: "costRuleId", header: "Cost rule", group: "Money", from: (r) => r.costRuleId, format: "id", defaultOn: false },
  { id: "priceRuleId", header: "Price rule", group: "Money", from: (r) => r.priceRuleId, format: "id", defaultOn: false },

  { id: "outcome", header: "Outcome", group: "Outcome", from: (r) => r.finalState, format: "outcome", defaultOn: true },
  { id: "dlrState", header: "Receipt state", group: "Outcome", from: (r) => r.dlrState, format: "number", align: "right", defaultOn: false },
  { id: "errCode", header: "Error code", group: "Outcome", from: (r) => r.errCode, format: "text", defaultOn: false },
  //beside the translated one, off by default like it. Empty on every row until the gateway is past
  //the 0.9.0 baseline, and on rows written before it -- which is honest rather than a fault: the
  //carrier's code was genuinely not kept, and it was deliberately not backfilled
  { id: "vendorErrCode", header: "Carrier error code", group: "Outcome", from: (r) => r.vendorErrCode ?? null, format: "text", defaultOn: false },
  { id: "finalAt", header: "Receipt at", group: "Outcome", from: (r) => r.finalAt, format: "time", defaultOn: false },
  { id: "operatorMsgId", header: "Operator message ID", group: "Outcome", from: (r) => r.operatorMsgId, format: "id", defaultOn: false },

  /**
   * What the customer asked to be told, in English rather than as an octet.
   *
   * <p>In Outcome rather than Message because of the question it answers: a customer reporting that
   * receipts stopped, beside the outcome that did or did not reach them. Reading `1` or `17` in a
   * cell would answer nothing, so the cell carries the sentence and the detail view carries the hex.
   *
   * <p>Empty on every row against a gateway before V1.33.0, and on rows written before the column
   * existed. "Not recorded" is deliberately not "no receipt requested" — see `receipt-request.ts`.
   */
  { id: "registeredDelivery", header: "Receipt requested", group: "Outcome", from: (r) => receiptRequestSummary(r.registeredDelivery), format: "text", defaultOn: false, unsortable: true },

  /**
   * The TLVs as the customer sent them.
   *
   * <p>The only one of the three TLV columns that is a column at all. It exists because the portal
   * has no per-message detail view, so a list column is the only way to show a customer their own
   * optional parameters — and it is the only one they may see: the resolved and sent sets reflect
   * our own defaults and our vendors' tag registrations.
   *
   * <p>Off by default, and unbounded TEXT, so `cdr-queries.ts` fetches it only when it is chosen.
   * Reading three hundred of them on a page that is not displaying them is the cost that switch
   * exists to avoid.
   */
  { id: "tlvsReceived", header: "TLVs from the customer", group: "Message", from: (r) => r.tlvsReceived, format: "text", defaultOn: false, unsortable: true },

  /**
   * The TLVs the vendor actually put on the wire.
   *
   * <p>The one an operator is usually looking for, and until now the only way to see it was to open
   * a message's detail view one at a time. On a DLT lane the question behind a refused batch is
   * "what entity and template id actually went out", and answering it for a hundred messages meant
   * a hundred clicks — or reading `tlvs_sent` in SQL, which is where this was actually being done.
   *
   * <p>Null means nothing recorded it, which includes every message that never reached a vendor and
   * every non-SMPP vendor, since no other worker type carries optional parameters at all. Empty
   * means the vendor was asked and carried none. The two look the same in a cell and are not the
   * same fact, which is why the detail view stays the place to compare all three.
   *
   * <p>Heavy and off by default for the same reason as the column above.
   */
  { id: "tlvsSent", header: "TLVs on the wire", group: "Message", from: (r) => r.tlvsSent, format: "text", defaultOn: false, unsortable: true },

  /**
   * What the message said.
   *
   * <p>Empty on every row unless the gateway is recording content — `smsg.cdr.body`, which ships
   * off. That is worth knowing before concluding the column is broken: an empty cell here means
   * either "the switch is off" or "this row predates it", and neither is a panel bug.
   *
   * <p>The list carries the first 160 characters; the whole message is on the detail view. Heavy and
   * off by default, so it is fetched only when somebody ticks it.
   */
  { id: "body", header: "Message", group: "Message", from: (r) => r.body, format: "longtext", defaultOn: false, unsortable: true },
];

/**
 * Columns whose data is unbounded TEXT and is therefore fetched on demand.
 *
 * <p>Named here rather than inferred from the format, because "wide" is a property of the value and
 * not of how it renders. `cdr-queries.ts` reads this to decide which column set to select.
 */
export const HEAVY_CDR_COLUMN_IDS: readonly string[] = ["tlvsReceived", "tlvsSent", "body"];

export const CDR_COLUMN_GROUPS = ["Message", "Route", "Money", "Outcome"] as const;

/** Where the choice is kept. Not the URL — that is the filters' home, and a shared link should carry filters, not somebody else's columns. */
export const COLUMN_STORAGE_KEY = "fireflo.cdrs.columns";

export type { ColumnChoice } from "./table-columns.ts";
export { readColumnChoice, toggleColumn } from "./table-columns.ts";

/** The catalogue is fixed here, so callers pass only the stored choice. */
export function resolveColumns(choice: import("./table-columns").ColumnChoice | null): CdrColumn[] {
  return resolveFrom(CDR_COLUMNS, choice) as CdrColumn[];
}
