import { NextResponse } from "next/server";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { isConfigWritable } from "@/lib/config-db";

/**
 * The preamble every configuration-writing route shares.
 *
 * <p>`workers/route.ts` grew its own copy of this, and its sibling `[name]/route.ts` grew a second
 * with a shorter 503 message. Adding products and pricing would have made five. The reasoning behind
 * both refusals is worth having in exactly one place.
 *
 * @param tables named in the 503 so an operator setting up the write role knows what to grant
 * @returns a response to send back, or null to carry on
 */
export async function guardConfigWrite(tables: string): Promise<NextResponse | null> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      //404, not 403: a 403 confirms there is something here to be forbidden from
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  if (!isConfigWritable()) {
    return NextResponse.json(
      {
        error: "CONFIG_DATABASE_URL is not set, so editing is switched off. "
          + `It needs a database user that may write to ${tables}.`,
      },
      { status: 503 }
    );
  }
  return null;
}

/**
 * Turns a thrown error into a 500 that still says something.
 *
 * <p>The real message is returned deliberately: it can name a missing table, a missing sequence
 * grant, or a constraint, which is exactly what the operator needs and nobody else can reach.
 */
export function configFailed(context: string, err: unknown): NextResponse {
  const message = err instanceof Error ? err.message : "Unknown error";
  console.error(`${context}:`, message);
  return NextResponse.json({ error: message }, { status: 500 });
}
