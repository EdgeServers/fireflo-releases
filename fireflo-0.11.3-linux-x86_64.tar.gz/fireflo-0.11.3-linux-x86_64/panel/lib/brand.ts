/**
 * The name the customer portal calls itself.
 *
 * <p><strong>The portal only.</strong> The operator panel stays "FireFlo" deliberately: an operator
 * knows which platform they are running, and renaming their side would make a support conversation
 * harder rather than easier. The portal is the surface a *customer* sees, and a customer of a tenant
 * has no reason to be shown the platform underneath.
 *
 * <p><strong>Read at runtime, not baked into the build.</strong> The obvious spelling would be
 * `NEXT_PUBLIC_MIS_PANEL_BRAND`, which Next inlines at build time — and the panel installer builds
 * with only `HOME` and `npm_config_cache` in the environment, not `panel.env`. A `NEXT_PUBLIC_`
 * brand would therefore come out empty on the first install and empty again after every `update`.
 * Reading a plain variable on the server and passing it down survives both.
 *
 * <p>Server-only: nothing importing this may be a client component. The two portal surfaces take the
 * resolved value as a prop from their server parent.
 */

/** What the portal is called when nobody has said otherwise. */
export const DEFAULT_BRAND = "FireFlo";

/**
 * The configured portal name, or the product's own.
 *
 * <p>Trimmed and emptiness-checked rather than `??`: a variable set to the empty string in
 * `panel.env` -- which is how an operator "unsets" one without deleting the line -- would otherwise
 * render a blank space where the name goes.
 */
export function portalBrand(): string {
  return process.env.MIS_PANEL_BRAND?.trim() || DEFAULT_BRAND;
}

/**
 * Fixed, not `new Date().getFullYear()`.
 *
 * <p>A computed year rolls over at midnight on the first of January, in whichever timezone the
 * server happens to run, without anybody deciding it should. A copyright year is a claim about when
 * the work was published, so a person moves it.
 */
const COPYRIGHT_YEAR = 2026;

/**
 * The portal's footer notice, which is two different notices.
 *
 * <p>Unbranded, this is our own portal and the full attribution is simply true. Branded, naming the
 * platform would undo on every page the thing {@link portalBrand} exists to do — so the notice
 * carries the tenant's name and nothing else.
 *
 * <p><strong>The branded form asserts a copyright on the tenant's behalf</strong>, and that is worth
 * being deliberate about rather than incidental. It is defensible only because the name in it is
 * the one the operator configured for this deployment; we are not inventing a claimant. It says
 * nothing beyond the reservation itself for the same reason.
 *
 * <p>Resolved here rather than in the shell because the shell is a client component and this module
 * is server-only. Deciding there would mean a second copy of {@link DEFAULT_BRAND} across the
 * boundary, which is two things answering one question.
 */
export function portalCopyright(): string {
  const brand = portalBrand();
  return brand === DEFAULT_BRAND
    ? `© ${COPYRIGHT_YEAR} FireFlo by WebSMSpanel. All rights reserved.`
    : `© ${COPYRIGHT_YEAR} ${brand}. All rights reserved.`;
}
