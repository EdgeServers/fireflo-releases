import { test } from "node:test";
import assert from "node:assert/strict";
import { clientIp, clientUserAgent } from "./client-ip.ts";

/**
 * Which entry of `X-Forwarded-For` is the caller.
 *
 * <p>This took the left-most entry until an audit pointed out the comment justifying it had the
 * reasoning backwards. Left-most is only trustworthy under `$remote_addr`, which overwrites; the
 * common `$proxy_add_x_forwarded_for` appends, so left-most was whatever the client typed — and
 * both access logs, plus the stolen-link detection that compares a request address against a
 * redemption address, were recording forged values.
 *
 * <p>Every case here is written from an attacker's side of it: the header always contains a
 * plausible forgery, and the test is whether that forgery is what comes back.
 */

function req(headers: Record<string, string>): { headers: Headers } {
  return { headers: new Headers(headers) };
}

test("the forged entry a client prepends is not what comes back", () => {
  //what nginx produces with $proxy_add_x_forwarded_for when the client sent its own header
  const ip = clientIp(req({ "x-forwarded-for": "1.2.3.4, 203.0.113.9" }));

  assert.equal(ip, "203.0.113.9", "the hop nginx observed, not the one the client claimed");
});

test("a whole forged chain still yields the address the proxy saw", () => {
  const ip = clientIp(req({
    "x-forwarded-for": "10.0.0.1, 10.0.0.2, 10.0.0.3, 198.51.100.7",
  }));

  assert.equal(ip, "198.51.100.7");
});

test("an overwriting proxy leaves one entry, which is both ends at once", () => {
  //proxy_set_header X-Forwarded-For $remote_addr — the recipe the old comment assumed
  assert.equal(clientIp(req({ "x-forwarded-for": "203.0.113.9" })), "203.0.113.9");
});

test("whitespace and empty entries do not shift which hop is chosen", () => {
  assert.equal(clientIp(req({ "x-forwarded-for": " 1.2.3.4 ,  , 203.0.113.9 " })), "203.0.113.9");
});

test("a chain shorter than the configured trust falls back rather than returning nothing", () => {
  //a misconfiguration, not an attack: fewer proxies than configured means the left-most entry is
  //the closest thing to an answer, and returning null would lose the address entirely
  assert.equal(clientIp(req({ "x-forwarded-for": "203.0.113.9" })), "203.0.113.9");
});

test("x-real-ip is the fallback, and only when there is no chain", () => {
  assert.equal(clientIp(req({ "x-real-ip": "203.0.113.9" })), "203.0.113.9");
  assert.equal(
    clientIp(req({ "x-forwarded-for": "1.2.3.4, 203.0.113.9", "x-real-ip": "9.9.9.9" })),
    "203.0.113.9",
    "a chain-aware header wins, so a forged x-real-ip cannot displace it"
  );
});

test("no headers at all is null, not a guess", () => {
  assert.equal(clientIp(req({})), null);
  assert.equal(clientIp(req({ "x-forwarded-for": "  ,  " })), null);
});

test("a user agent is truncated so one request cannot break an append", () => {
  assert.equal(clientUserAgent(req({ "user-agent": "curl/8.0" })), "curl/8.0");
  assert.equal(clientUserAgent(req({})), null);

  const long = clientUserAgent(req({ "user-agent": "x".repeat(500) })) ?? "";
  assert.equal(long.length, 256);
  assert.ok(long.endsWith("..."));
});
