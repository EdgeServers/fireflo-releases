/**
 * Which `cdr_submit` rows are one message, in one place.
 *
 * <p>Database-free, so anything may import it.
 *
 * <h2>The invariant</h2>
 *
 * <p><strong>A message leaves exactly one `part_no = 1` row in `cdr_submit`, whatever happened to
 * it.</strong> That is enforced by the gateway having a single writer and calling it only from
 * terminal events:
 *
 * <ul>
 *   <li>`SmppClientWorker.successMessage` writes one row, `billed = true`.
 *   <li>`SmppClientWorker.failMessage` writes one row, `billed = false` — the money has already
 *       been refunded, so its price columns are NULL.
 *   <li>A vendor refusal that is going to be <em>retried</em> writes NOTHING. Both retry policies —
 *       `RETRY_WORKER` and `RETRY_ROUTER` — call `onMessageTemporaryFailed` / `onMessageFailed`,
 *       and neither of those records a CDR.
 *   <li>Segments 2..N write nothing: `recordSubmitCdr` returns early for a concatenation segment,
 *       and the one row carries `part_count`.
 * </ul>
 *
 * <p>So there is no such thing as a per-attempt row to deduplicate. `retry_count` records how many
 * attempts the message took before it reached its one outcome — it does not multiply the rows.
 *
 * <h2>Why `AND retry_count = 0` is wrong, and was everywhere</h2>
 *
 * <p>Every aggregate in this panel used to add `AND retry_count = 0`, with a comment explaining
 * that it stopped a retry being counted as extra traffic. Given the invariant above there is no
 * extra traffic to stop — and since a retried message's single row carries `retry_count >= 1`, the
 * clause did not deduplicate anything. It <strong>excluded the message entirely</strong>, from both
 * the count and the money.
 *
 * <p>The clearest evidence was inside one query: `revenuePerAccount` summed `price` from a CTE
 * filtered on `retry_count = 0` while summing `cost` from one that was not, so margin was computed
 * from a revenue and a cost that disagreed about exactly the retried traffic.
 *
 * <p><strong>Removing it moves reported figures.</strong> Traffic counts, revenue, cost and margin
 * all rise by whatever the deployment's retry rate is. That is a correction, not a change: the
 * money was always charged and the messages were always sent.
 */

/**
 * One message, one row.
 *
 * <p>Serves counting and summing alike, because the invariant above makes them the same question.
 * Two names for one predicate would only invite them to drift.
 *
 * @param alias the table alias the query uses, or "" for an unaliased `cdr_submit`
 */
export function oneRowPerMessage(alias = "s"): string {
  return `${alias ? `${alias}.` : ""}part_no = 1`;
}

/**
 * The rows carrying money, which is the same set.
 *
 * <p>Kept as its own name so a money query says so at the call site. It deliberately returns the
 * identical predicate: `CdrSubmit.carriesMoney` is `partNo == 1 && rating != null && billed`, with
 * no retry term, and an unbilled row's price columns are NULL — so summing a column of NULLs adds
 * nothing and no extra clause is needed. Refunds need none either, for the same reason.
 */
export function carriesMoney(alias = "s"): string {
  return oneRowPerMessage(alias);
}
