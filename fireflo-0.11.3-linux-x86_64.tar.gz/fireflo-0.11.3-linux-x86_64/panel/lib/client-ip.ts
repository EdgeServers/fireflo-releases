/**
 * The caller's address, as far as we can tell.
 *
 * <p>One implementation, because two would drift and an access log whose IP means something
 * different depending on which route wrote it is worse than one with no IP at all.
 *
 * <h2>Right-most, not left-most, and the reasoning that got this wrong</h2>
 *
 * <p>This used to take the **left-most** `X-Forwarded-For` entry, justified by "that is the one
 * nginx wrote and anything a client forged is pushed to the right of it". That is only true of
 * `proxy_set_header X-Forwarded-For $remote_addr`, which **overwrites**. The near-universal recipe
 * is `$proxy_add_x_forwarded_for`, which **appends** — so with it the left-most entry is whatever
 * the client sent, and every address in both access logs was chosen by the visitor.
 *
 * <p>That is not a cosmetic error. `lib/mis-auth.ts` names `link_requested.requested_ip` against
 * `link_redeemed.ip` as the row that makes a stolen sign-in link visible, and a forgeable field
 * cannot do that. `notePortalAccess` also dedups on `accountId|ip`, so a varying forged value
 * defeats its one-row-per-hour bound.
 *
 * <p>So: **count from the right**, which is correct under both recipes. Appending leaves the hop
 * your proxy observed at the end; overwriting leaves exactly one entry, which is both ends at once.
 *
 * <p><strong>It still trusts the proxy, and that is unavoidable.</strong> Expose the panel's port
 * directly and every value here is chosen by the visitor. What changed is that the safe deployment
 * is now the common one rather than the rare one.
 */

/**
 * How many entries at the right-hand end were written by infrastructure you control.
 *
 * <p>One nginx on loopback appends one entry, which is the default. A CDN in front of it appends
 * another, so that deployment sets `2` — and setting it too high hands the choice back to the
 * client, which is why it is a deliberate number rather than something guessed from the chain.
 */
const TRUSTED_HOPS = Math.max(1, Number(process.env.TRUSTED_PROXY_HOPS ?? 1) || 1);

export function clientIp(req: { headers: Headers }): string | null {
  const forwarded = req.headers.get("x-forwarded-for");
  if (forwarded) {
    const hops = forwarded.split(",").map((h) => h.trim()).filter(Boolean);
    //the entry the outermost trusted proxy observed. Clamped rather than returning null on a short
    //chain: a request that reached us through fewer proxies than configured is a misconfiguration,
    //and the left-most entry is the closest thing to an answer it has
    const at = Math.max(0, hops.length - TRUSTED_HOPS);
    if (hops[at]) {
      return hops[at];
    }
  }
  //some proxies send only this one. Checked second so a chain-aware header always wins
  return req.headers.get("x-real-ip")?.trim() || null;
}

/**
 * @return the user agent, truncated. Long enough to tell browsers apart, short enough that one
 *     request cannot push an access-log line past the size that keeps appends atomic
 */
export function clientUserAgent(req: { headers: Headers }): string | null {
  const ua = req.headers.get("user-agent")?.trim();
  if (!ua) {
    return null;
  }
  return ua.length > 256 ? `${ua.slice(0, 253)}...` : ua;
}
