import { MisVerify } from "@/components/MisVerify";

/**
 * Where an emailed link lands. Spends the token and signs the browser in.
 *
 * <p>A client component does the redeeming, through the portal's NextAuth endpoint, because the
 * session cookie has to be set on a response the browser is actually navigating with.
 */
export const metadata = { title: "Signing you in" };

export default function VerifyPage() {
  return <MisVerify />;
}
