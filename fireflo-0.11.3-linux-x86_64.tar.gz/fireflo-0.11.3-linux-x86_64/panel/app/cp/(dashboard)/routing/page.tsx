import { PageHeader } from "@/components/ui/page-header";
import { DeliveryCheck } from "@/components/DeliveryCheck";
import { GroupsClient } from "@/components/GroupsClient";
import { RoutingClient } from "@/components/RoutingClient";
import { RoutingTester } from "@/components/RoutingTester";

export default function RoutingPage() {
  return (
    <>
      <PageHeader title="Routing" />
      {/* Tables carry four columns of rule detail, so they get two thirds. The right column is what
          you reach for when the tables look right and messages still are not arriving: where a rule
          can send, whether a hypothetical message would actually hit the rule you think it would,
          and whether anything is arriving at all.

          One grid, owned here. RoutingClient used to hold its own two-column split with the
          delivery check as a rail, which nested inside this one produced three columns at xl and
          squeezed the rule conditions to nothing. RoutingTester is a sibling of RoutingClient for
          the same reason -- it fetches its own table names and listener list rather than taking
          them as props, so it is not tied to which column RoutingClient happens to render in.

          Breaks at xl, not lg: at 1024px the rule table in two thirds wraps its conditions, which
          reads worse than the two stacked. items-start so neither column stretches to the other's
          height. */}
      <div className="grid items-start gap-6 xl:grid-cols-3">
        <div className="xl:col-span-2">
          <RoutingClient />
        </div>
        {/* groups first: it is configuration, and it is the thing the tables send to. The tester
            comes next -- the thing you reach for once the tables and groups look right and you want
            to check before touching real traffic. The delivery check is a read-only diagnostic over
            traffic that already happened, so it reads last. */}
        <div className="space-y-6">
          <GroupsClient />
          <RoutingTester />
          <DeliveryCheck />
        </div>
      </div>
    </>
  );
}
