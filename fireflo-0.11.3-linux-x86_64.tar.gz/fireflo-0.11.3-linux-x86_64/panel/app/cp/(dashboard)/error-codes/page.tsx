import { PageHeader } from "@/components/ui/page-header";
import { ErrorCodesClient } from "@/components/ErrorCodesClient";

/**
 * Both tiers of `dlr.errcodes` on one page.
 *
 * <p>Under Configuration rather than beside a vendor because the global list is not any one
 * vendor's — but the button on Vendors lands here too, since a vendor's own list is only
 * comprehensible next to the list it replaces.
 */
export default function ErrorCodesPage() {
  return (
    <>
      <PageHeader
        title="Error codes"
        description="What a carrier's failure code becomes on the receipt the customer reads."
      />
      <ErrorCodesClient />
    </>
  );
}
