import { PageHeader } from "@/components/ui/page-header";
import { VendorErrorCodesClient } from "@/components/VendorErrorCodesClient";

/** Next 16: route params arrive as a promise. */
export default async function VendorErrorCodesPage({
  params,
}: {
  params: Promise<{ vendor: string }>;
}) {
  const { vendor } = await params;
  const name = decodeURIComponent(vendor);
  return (
    <>
      <PageHeader
        title={`Error codes — ${name}`}
        description="What this carrier's failure codes become on the receipt the customer reads."
      />
      <VendorErrorCodesClient name={name} />
    </>
  );
}
