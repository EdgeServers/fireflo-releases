import { PageHeader } from "@/components/ui/page-header";
import { FiltersClient } from "@/components/FiltersClient";

export default function FiltersPage() {
  return (
    <>
      <PageHeader title="Filters" />
      <FiltersClient />
    </>
  );
}
