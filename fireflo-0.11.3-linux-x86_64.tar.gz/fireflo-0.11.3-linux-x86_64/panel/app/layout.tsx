import type { Metadata } from "next";
import { cookies } from "next/headers";
import { SessionProvider } from "next-auth/react";
import { ThemeProvider } from "@/components/ThemeProvider";
import "./globals.css";

/*
 * No webfont. This loaded Teachers through `next/font/google`, self-hosted from our own origin so
 * no page load reached Google -- but a cold build still needed network access to
 * fonts.googleapis.com, and every visitor paid for the font download. `globals.css` now names the
 * system stack directly, so there is nothing to fetch at build time or at run time.
 */

/**
 * The product is called "FireFlo SMS/SMPP Gateway" in title positions and "FireFlo" in prose.
 *
 * <p>This is a title position, so it carries the long form. The header wordmark in
 * {@code FireFloMark} keeps the short one — it sits in a fixed-height bar beside the mark, and the
 * full name would wrap there without telling anyone anything the tab title has not already said.
 */
export const metadata: Metadata = {
  title: "Control Panel — FireFlo SMS/SMPP Gateway",
  description: "Operational metrics for the FireFlo SMS/SMPP Gateway",
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  //the theme cookie is written by ThemeProvider on the client; reading it here avoids the
  //first-paint flash. No cookie means no class, and the client applies one.
  const theme = (await cookies()).get("theme")?.value;

  return (
    <html
      lang="en"
      className={theme === "dark" ? "dark" : ""}
      suppressHydrationWarning
    >
      <body>
        <SessionProvider>
          <ThemeProvider>{children}</ThemeProvider>
        </SessionProvider>
      </body>
    </html>
  );
}
