import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { deleteAccount } from "@/lib/accounts";

type Params = { params: Promise<{ id: string }> };

const TABLES = "app_account";

/**
 * Removes the catalogue row, which is not the same as removing the account.
 *
 * <p>Nothing cascades, because nothing references it. The logins keep binding, the rate rules keep
 * pricing, the balance keeps its money and the call records keep their history — all of them point
 * at a string, not at this row. What is lost is the name, and the id reappears in the orphan list
 * immediately.
 *
 * <p>Which is why this needs no confirmation about traffic, unlike deleting a vendor.
 */
export async function DELETE(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { id } = await params;
  try {
    const removed = await deleteAccount(decodeURIComponent(id));
    return removed
      ? NextResponse.json({ data: { id } })
      : NextResponse.json({ error: "No catalogue row for that account." }, { status: 404 });
  } catch (err) {
    return configFailed("delete account", err);
  }
}
