import { NextResponse } from "next/server";
import { createReadStream } from "node:fs";
import { Readable } from "node:stream";
import { auditedDownload, logOperatorEvent } from "@/lib/access-log";
import { guardCdrRoute, queryFailed } from "@/lib/cdr-guard";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { requireOperator } from "@/lib/require-operator";
import { KIND } from "@/lib/statement-export";
import { csvPath, discard, downloadName, getExport } from "@/lib/exports";

type Params = { params: Promise<{ id: string; job: string }> };

/**
 * Collects a finished statement, or deletes one.
 *
 * <p>A near-copy of the refusal-export route, for the reason that one is a near-copy of the
 * call-record one: sharing the handler would mean one route serving several kinds under whichever
 * audit name it happened to be written with, and an audit trail that names the wrong file is worse
 * than four duplicated lines.
 *
 * <p><strong>The account in the path is checked against the account in the job.</strong> That is the
 * check this route has and its siblings do not need. A statement is scoped to one customer, the job
 * id is the only thing identifying the file, and without this a statement is downloadable from any
 * other account's URL by anybody who has the id — every operator can see every account's page, so
 * the URL is not a secret and must not be load-bearing.
 */
export async function GET(req: Request, { params }: Params): Promise<NextResponse | Response> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  const operator = await requireOperator();
  const { id, job: jobId } = await params;
  const accountId = decodeURIComponent(id).trim();

  const job = await getExport(jobId);
  if (!job || job.kind !== KIND || job.filters?.accountId !== accountId) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  if (job.status !== "ready") {
    //409 rather than 404: the request exists, it is not collectable yet, and the difference decides
    //whether the page should keep polling or stop
    return NextResponse.json(
      { error: `This statement is ${job.status}.`, status: job.status },
      { status: 409 }
    );
  }

  const file = csvPath(jobId);
  if (!file) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  //audited around the stream, so a 409 never appears in the log as a download somebody took. A 2xx
  //means the transfer STARTED; nothing here can know whether the connection survived it
  return auditedDownload(
    req,
    { kind: "statement", actor: operator, subject: downloadName(job) },
    async () => {
      try {
        const stream = Readable.toWeb(createReadStream(file)) as ReadableStream;
        return new Response(stream, {
          headers: {
            "Content-Type": "text/csv; charset=utf-8",
            //derived from the job, never from user input, so it needs no escaping
            "Content-Disposition": `attachment; filename="${downloadName(job)}"`,
            ...(job.bytes != null ? { "Content-Length": String(job.bytes) } : {}),
            //a customer's traffic and what they were charged for it. Nothing in front keeps a copy
            "Cache-Control": "private, no-store",
          },
        });
      } catch (err) {
        return queryFailed("statement download", err);
      }
    }
  );
}

export async function DELETE(req: Request, { params }: Params): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  const operator = await requireOperator();
  const { id, job: jobId } = await params;
  const accountId = decodeURIComponent(id).trim();

  const job = await getExport(jobId);
  if (!job || job.kind !== KIND || job.filters?.accountId !== accountId) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  try {
    await discard(jobId);
    //logged because it destroys a file of a customer's billed traffic. A trail that records who
    //took a copy but not who removed it is only half an audit trail
    void logOperatorEvent({
      event: "export_deleted",
      actor: operator,
      ip: clientIp(req),
      userAgent: clientUserAgent(req),
      detail: { id: jobId, kind: KIND, account: accountId },
    });
    return NextResponse.json({ data: { id: jobId } });
  } catch (err) {
    return queryFailed("statement delete", err);
  }
}
