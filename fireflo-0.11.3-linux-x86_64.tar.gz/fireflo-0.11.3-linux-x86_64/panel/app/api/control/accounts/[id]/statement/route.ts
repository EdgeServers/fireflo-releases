import { NextRequest, NextResponse } from "next/server";
import { guardCdrRoute, queryFailed } from "@/lib/cdr-guard";
import {
  customPeriod,
  monthPeriod,
  periodTooLong,
  type BillingPeriod,
} from "@/lib/billing-period";
import { billingZone, platformCurrency } from "@/lib/platform-currency";
import { closedPeriods, statementDetail, statementSummary, type StatementCursor, type StatementRow }
  from "@/lib/statement-queries";
import { closePeriod, DuplicateReference, NoBalanceRow } from "@/lib/balance";
import { guardConfigWrite } from "@/lib/config-guard";
import { requireOperator } from "@/lib/require-operator";
import { usageBetween } from "@/lib/metrics-queries";
import { restatementOf } from "@/lib/period-close";
import { HEADERS, KIND, toCsvLine } from "@/lib/statement-export";
import { type ExportSource, listExports, requestExport } from "@/lib/exports";

type Params = { params: Promise<{ id: string }> };

/** What the export job carries between batches. Serialised into the job record, so no `Date`s. */
interface StatementFilters {
  accountId: string;
  since: string;
  until: string;
  label: string;
}

/**
 * A statement as the generic job store consumes it.
 *
 * <p>`page` calls the DETAIL query and never the summary. Re-running a whole month's aggregate for
 * every 5,000-row batch would be the most expensive available mistake, and the two being separate
 * functions is what makes it unavailable rather than merely discouraged.
 */
const STATEMENT_EXPORT: ExportSource<StatementRow, StatementFilters> = {
  kind: KIND,
  headers: HEADERS,
  toCsvLine,
  page: async (filters, cursor, batch) => {
    const period: BillingPeriod = {
      since: new Date(filters.since),
      until: new Date(filters.until),
      label: filters.label,
    };
    return statementDetail(filters.accountId, period, cursor as StatementCursor | null, batch);
  },
  //already flat strings, so there is nothing to flatten. Passed through rather than run through
  //serialiseFilters, which exists to reduce arbitrary filter objects
  serialise: (filters) => ({ ...filters }),
};

/**
 * Reads the period off the query string.
 *
 * <p>`?month=2026-08`, or `?from=&to=` for an arbitrary window. A month is checked for length too,
 * even though a calendar month is always inside the ceiling — "the caller already validated" is the
 * assumption that stops being true the moment a second caller appears.
 */
function readPeriod(params: URLSearchParams): BillingPeriod | string {
  const month = params.get("month");
  if (month) {
    const period = monthPeriod(month);
    if (!period) {
      return `'${month}' is not a month. Use YYYY-MM.`;
    }
    return periodTooLong(period) ?? period;
  }
  const period = customPeriod(params.get("from") ?? "", params.get("to") ?? "");
  if (typeof period === "string") {
    return period;
  }
  return periodTooLong(period) ?? period;
}

/**
 * The bill for one account and one period, and the queue of files prepared from it.
 *
 * <p>Read-only. A statement is derived from `cdr_submit` every time it is asked for; nothing is
 * stored, and nothing here writes. Closing a period is a separate, explicit action.
 *
 * <p>`?exports=1` lists the prepared files instead of computing the bill.
 */
export async function GET(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  const { id } = await params;
  const accountId = decodeURIComponent(id).trim();
  if (!accountId) {
    return NextResponse.json({ error: "No account given." }, { status: 400 });
  }

  const search = new URL(req.url).searchParams;

  if (search.get("exports") === "1") {
    try {
      //FILTERED TO THIS ACCOUNT. listExports(kind) is global, so without this every account's
      //statement page would list every other account's prepared files -- and the filenames carry
      //the account id, so that is a disclosure rather than only a confusing list
      const all = await listExports(KIND);
      const mine = all.filter((job) => job.filters?.accountId === accountId);
      return NextResponse.json({ data: mine });
    } catch (err) {
      return queryFailed("statement export list", err);
    }
  }

  const period = readPeriod(search);
  if (typeof period === "string") {
    return NextResponse.json({ error: period }, { status: 400 });
  }

  try {
    const [currency, zone, closed] = await Promise.all([
      platformCurrency(), billingZone(), closedPeriods(accountId),
    ]);
    //the daily shape of the same window, from the same query the usage page uses. Sharing it is
    //what makes the chart and the total agree: a second query would eventually differ about a
    //retry or a refund, and nothing on screen would say which one to believe
    const [summary, days] = await Promise.all([
      statementSummary(accountId, period, currency, zone),
      usageBetween(period.since, period.until, "day", accountId),
    ]);
    const already = closed.find((c) => c.label === period.label) ?? null;
    return NextResponse.json({
      data: {
        ...summary,
        days,
        closed,
        //present only when THIS period is closed and has since moved. The invoice stands either
        //way; this is what the difference carries forward as
        closedAs: already,
        //ONLY when the period can still be recomputed. With the call records purged and no rollup
        //covering them, `totalAmount` is zero for want of evidence rather than because nothing was
        //sent -- and comparing that zero against the invoice rendered "the full invoice is owed
        //back and carries forward as a credit" on every paid period older than the retention
        //window. A closed invoice nothing can be checked against is simply the invoice
        restatement: already && summary.recomputable
          ? restatementOf(already, summary.totalAmount)
          : null,
      },
    });
  } catch (err) {
    return queryFailed("statement", err);
  }
}

/**
 * Closes the period, which is the only write this file has.
 *
 * <p>PUT rather than POST because POST on this path already means "prepare a CSV", and one verb
 * doing two unrelated things behind a body field is how the wrong one gets called.
 *
 * <p>The amount is recomputed HERE and never taken from the request. A client-supplied figure would
 * make the invoice a claim rather than a derivation, and the whole design rests on the bill being a
 * pure function of `cdr_submit`.
 */
export async function PUT(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite("balance_ledger");
  if (refused) {
    return refused;
  }
  const { id } = await params;
  const accountId = decodeURIComponent(id).trim();
  if (!accountId) {
    return NextResponse.json({ error: "No account given." }, { status: 400 });
  }

  const period = readPeriod(new URL(req.url).searchParams);
  if (typeof period === "string") {
    return NextResponse.json({ error: period }, { status: 400 });
  }
  if (period.until.getTime() > Date.now()) {
    //a period that has not finished would be invoiced for traffic still arriving, and closing is
    //irreversible. The operator can close it the moment it ends
    return NextResponse.json(
      { error: `${period.label} has not finished yet. A period can only be closed once it has ended.` },
      { status: 400 }
    );
  }

  let note: string | null = null;
  try {
    const body = (await req.json()) as { note?: string };
    note = typeof body?.note === "string" ? body.note.slice(0, 500) : null;
  } catch {
    //a note is optional, so an absent or unparseable body is not an error
  }

  try {
    const operator = await requireOperator();
    const [currency, zone] = await Promise.all([platformCurrency(), billingZone()]);
    const summary = await statementSummary(accountId, period, currency, zone);
    if (!summary.recomputable) {
      //closing on a total of zero would write a BILL row invoicing nothing, permanently, for a
      //period that may well have carried traffic. The refusal names the cause because the fix is
      //a rollup, not a retry
      return NextResponse.json({
        error: `${period.label} has no call records and no usage_daily rollup covering it, so `
          + "there is nothing to invoice from. Closing it now would record an invoice of zero. "
          + "Run 'fireflo usage rollup --catch-up' if the period is still within the retention "
          + "window; if its records have already been purged, it cannot be closed after the fact.",
      }, { status: 409 });
    }
    await closePeriod(accountId, period.label, summary.totalAmount, note, operator);
    return NextResponse.json({
      data: { accountId, label: period.label, invoiced: summary.totalAmount },
      notice: "Closed. This period is now immutable — anything that lands against it later shows "
        + "as a credit note on the next period rather than changing this invoice.",
    });
  } catch (err) {
    if (err instanceof DuplicateReference) {
      return NextResponse.json(
        { error: `${period.label} has already been closed for this account. A closed period is `
          + "never reissued; the difference carries forward instead." },
        { status: 409 }
      );
    }
    if (err instanceof NoBalanceRow) {
      return NextResponse.json(
        { error: "This account has no balance row yet. Open it for credit first." },
        { status: 404 }
      );
    }
    return queryFailed("close period", err);
  }
}

/** Requests the CSV. Answers when the job is recorded, not when the file is finished. */
export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  const { id } = await params;
  const accountId = decodeURIComponent(id).trim();
  if (!accountId) {
    return NextResponse.json({ error: "No account given." }, { status: 400 });
  }

  const period = readPeriod(new URL(req.url).searchParams);
  if (typeof period === "string") {
    return NextResponse.json({ error: period }, { status: 400 });
  }

  //the window is pinned once, here. Re-deriving it per batch would let it slide as the export runs
  const filters: StatementFilters = {
    accountId,
    since: period.since.toISOString(),
    until: period.until.toISOString(),
    label: period.label,
  };

  try {
    return NextResponse.json({
      data: await requestExport(STATEMENT_EXPORT, filters, `${accountId}, ${period.label}`),
    });
  } catch (err) {
    return queryFailed("statement export request", err);
  }
}
