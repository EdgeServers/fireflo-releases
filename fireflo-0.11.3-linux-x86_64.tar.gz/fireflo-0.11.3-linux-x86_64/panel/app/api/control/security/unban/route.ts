import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { NextRequest, NextResponse } from "next/server";
import { logOperatorEvent } from "@/lib/access-log";
import { requestContext } from "@/lib/request-context";
import { fail2banAvailable, fail2banWrapper } from "@/lib/security-sources";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

const run = promisify(execFile);

/**
 * POST /api/control/security/unban  { jail, ip }
 *
 * <p>Releases one address from one FireFlo jail. <strong>This is the only thing in the panel that
 * changes the host, and the only path that reaches root.</strong>
 *
 * <h2>What actually holds the line here</h2>
 *
 * <p>Not this file. The real guard is `/usr/local/sbin/fireflo-unban`, which sudo permits the
 * panel's service user to run and nothing else: it takes exactly a jail and an address, refuses any
 * jail outside FireFlo's own, refuses anything that is not a literal address, and has no verb that
 * can ADD a block. A compromised panel session can release an address; it cannot cut anybody off,
 * and it cannot reach the rest of `fail2ban-client`.
 *
 * <p>The checks below are the second of two rather than the only one. They exist so a typo answers
 * a sentence instead of a non-zero exit code, and so nothing shaped like an argument gets as far as
 * a process.
 *
 * <p><strong>`execFile`, never `exec`.</strong> The arguments are passed as an array to a named
 * binary, so there is no shell to interpret them — a semicolon in the address is an address that
 * fails validation, not a command.
 */

/** The jails FireFlo installs. The wrapper enforces this too; disagreeing with it is a 500. */
const JAILS = new Set(["fireflo-gateway", "fireflo-panel"]);

/**
 * A literal IPv4 or IPv6 address and nothing else.
 *
 * <p>Not a hostname, not a range, not a CIDR. fail2ban would accept some of those, and
 * "unban 0.0.0.0/0" is not a thing a browser should be able to ask for.
 */
const LITERAL_ADDRESS = /^[0-9a-fA-F.:]{2,45}$/;

export async function POST(request: NextRequest): Promise<NextResponse> {
  let operator: string;
  try {
    operator = await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  let body: { jail?: unknown; ip?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body with a jail and an ip." }, { status: 400 });
  }

  const jail = typeof body.jail === "string" ? body.jail.trim() : "";
  const ip = typeof body.ip === "string" ? body.ip.trim() : "";

  if (!JAILS.has(jail)) {
    return NextResponse.json(
      { error: `Not a FireFlo jail. Expected one of: ${[...JAILS].join(", ")}` },
      { status: 400 }
    );
  }
  if (!LITERAL_ADDRESS.test(ip)) {
    return NextResponse.json(
      { error: "That is not a literal address. Only a single IPv4 or IPv6 address can be released here." },
      { status: 400 }
    );
  }

  if (!(await fail2banAvailable())) {
    //the ordinary state on a host installed without --with-fail2ban. Say what is missing and what
    //to run instead, rather than failing at the exec with something an operator cannot act on
    return NextResponse.json(
      {
        error:
          `Unbanning from the panel is not set up on this host: ${fail2banWrapper()} is not there. `
          + `Release it on the host instead: sudo fail2ban-client set ${jail} unbanip ${ip}`,
      },
      { status: 409 }
    );
  }

  //recorded BEFORE the call, and kept whatever the outcome. An unban that failed half way is
  //exactly the one somebody needs to find afterwards, and a log written only on success is a log
  //that goes quiet at the interesting moment
  const ctx = await requestContext();
  void logOperatorEvent({
    event: "ip_unbanned",
    actor: operator,
    ip: ctx.ip,
    userAgent: ctx.userAgent,
    detail: { jail, released: ip },
  });

  try {
    //sudo -n: the grant is NOPASSWD for this one path, so a host where that rule is missing must
    //fail immediately rather than block on a password prompt nobody can answer and sit there until
    //the timeout. `execFile` with an argument array means there is no shell between here and the
    //wrapper -- nothing in `ip` can be read as a second command
    await run("sudo", ["-n", fail2banWrapper(), "unban", jail, ip], { timeout: 10_000 });
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    return NextResponse.json(
      {
        error:
          `The unban did not complete: ${detail}. If this says "a password is required", the sudo `
          + `rule for ${fail2banWrapper()} is missing -- reinstall with --with-fail2ban, or release it `
          + `on the host: sudo fail2ban-client set ${jail} unbanip ${ip}`,
      },
      { status: 502 }
    );
  }

  return NextResponse.json({ data: { jail, ip, released: true } });
}
