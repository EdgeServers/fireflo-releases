import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { listRouteTables, saveRouteTable } from "@/lib/routing";
import {
  TARGET_FUNCTIONS,
  type RouteTableInput,
  type TargetFunction,
  validateRouteTable,
} from "@/lib/routing-types";

const TABLES = "app_route_table, app_route_rule";

/** Every routing table with its rules in order. */
export async function GET(): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  try {
    return NextResponse.json({ data: { tables: await listRouteTables() } });
  } catch (err) {
    return configFailed("routing", err);
  }
}

/**
 * Creates or rewrites one table.
 *
 * <p>Whole-table writes, not per-rule: the rules are an ordered list whose positions are the
 * priority, so a partial update would have to describe a reordering. `saveScope` takes the same
 * shape for the same reason.
 */
export async function PUT(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const raw = body as Partial<RouteTableInput> & { targetFunction?: string };
  const fn = (TARGET_FUNCTIONS as readonly string[]).includes(raw.targetFunction ?? "")
    ? (raw.targetFunction as TargetFunction)
    : "NORMAL";

  const input: RouteTableInput = {
    name: typeof raw.name === "string" ? raw.name : "",
    targetFunction: fn,
    label: typeof raw.label === "string" ? raw.label : null,
    enabled: raw.enabled !== false,
    rules: Array.isArray(raw.rules) ? raw.rules : [],
  };

  const invalid = validateRouteTable(input);
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }

  try {
    await saveRouteTable(input);
    return NextResponse.json({ data: { name: input.name.trim() } });
  } catch (err) {
    return configFailed("save routing table", err);
  }
}
