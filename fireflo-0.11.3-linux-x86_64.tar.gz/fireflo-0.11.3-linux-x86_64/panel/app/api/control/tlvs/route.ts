import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { requireOperator } from "@/lib/require-operator";
import {
  listTlvDefinitions,
  listTlvSuggestions,
  scanTlvUsage,
  setTlvSuggested,
  upsertTlvDefinition,
} from "@/lib/tlv-definitions";
import { validateTlvDefinition } from "@/lib/tlv-catalogue";

const TABLES = "app_tlv_definition and app_tlv_suggestion";

/**
 * Operator-defined TLV names, plus where every TLV in this deployment is actually declared.
 *
 * <p>The usage scan comes back with the definitions because the two are read together everywhere —
 * a definition on its own cannot say whether anything uses it, and a declaration on its own cannot
 * say what it means.
 *
 * <p>The scan is failure-tolerant: a definitions list is useful without it, and it reads two tables
 * this route does not otherwise need.
 */
export async function GET(): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  try {
    const [definitions, suggestions, usage] = await Promise.all([
      listTlvDefinitions(),
      listTlvSuggestions(),
      scanTlvUsage().catch(() => null),
    ]);
    return NextResponse.json({ data: { definitions, suggestions, usage } });
  } catch (err) {
    return configFailed("TLV definitions", err);
  }
}

/** Creates or replaces one definition, keyed on the tag. */
export async function PUT(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const input = body as { tag?: unknown; name?: unknown; label?: unknown; description?: unknown };
  const invalid = validateTlvDefinition({
    tag: input.tag,
    name: input.name,
  });
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }

  try {
    const operator = await requireOperator();
    await upsertTlvDefinition(
      {
        tag: Number(input.tag),
        name: String(input.name).trim(),
        label: typeof input.label === "string" ? input.label : null,
        description: typeof input.description === "string" ? input.description : null,
      },
      operator
    );
    return NextResponse.json({ data: { tag: Number(input.tag) } });
  } catch (err) {
    return configFailed("save TLV definition", err);
  }
}

/**
 * Records whether tags are offered as suggestions.
 *
 * <p>Takes an array so curating the sixty spec parameters a deployment will never use is one
 * request. Mirrors `PATCH /api/control/products/[name]` in shape — a single boolean, validated as a
 * boolean rather than coerced, because `{ suggested: "false" }` coerced would be the opposite of
 * what was asked for.
 *
 * <p>This decides what a dropdown offers and nothing else. Every tag stays typeable, saveable and
 * resolvable whatever is recorded here, which is why there is no equivalent check on any write path.
 */
export async function PATCH(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const { tags, suggested } = body as { tags?: unknown; suggested?: unknown };
  if (typeof suggested !== "boolean") {
    return NextResponse.json(
      { error: "Expected { tags: number[], suggested: true | false }." },
      { status: 400 }
    );
  }
  if (
    !Array.isArray(tags)
    || !tags.length
    || tags.some((t) => !Number.isInteger(t) || t < 0 || t > 0xffff)
  ) {
    return NextResponse.json(
      { error: "tags must be a non-empty array of whole numbers from 0 to 65535." },
      { status: 400 }
    );
  }

  try {
    const operator = await requireOperator();
    await setTlvSuggested(tags as number[], suggested, operator);
    return NextResponse.json({ data: { tags, suggested } });
  } catch (err) {
    return configFailed("set TLV suggestions", err);
  }
}
