import { NextRequest, NextResponse } from "next/server";
import { auditedDownload } from "@/lib/access-log";
import { callOps } from "@/lib/gateway-ops";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import type { GatewayConfigView, GatewayLogTail } from "@/lib/gateway-files-types";

/**
 * GET /api/control/diagnostics
 *
 * <p>Health, every configuration file and a tail of every log, rendered as one plain-text document
 * to attach to a ticket.
 *
 * <p>Synchronous, like the pricing export and unlike the CDR one. `lib/exports.ts` is an
 * asynchronous job store with a retention sweep, built for a month of call records; this is tens of
 * kilobytes and the machinery would buy nothing.
 *
 * <p><strong>Every secret was already blanked on the gateway.</strong> Nothing here re-derives that
 * judgement — the whole point of redacting at the source is that the secret never crosses the
 * network, so this process has nothing to decide and no list to keep in step.
 */
export async function GET(request: NextRequest): Promise<NextResponse | Response> {
  let operator: string;
  try {
    operator = await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  //the whole bundle is worth an audit line on its own: it carries every configuration file and a
  //tail of every log, which is the widest single disclosure this panel offers
  return auditedDownload(request, { kind: "diagnostics", actor: operator }, () => build());
}

async function build(): Promise<NextResponse | Response> {
  //the bundle stats eight files and tails four of them, so it is slower than any single route here
  const response = await callOps({
    path: "/ops/diagnostics?lines=500",
    auth: "admin",
    timeoutMs: 20_000,
  });
  if (response.status !== 200) {
    return response;
  }

  const body = (await response.json()) as { data: Bundle | null };
  if (!body.data) {
    return NextResponse.json({ error: "The gateway returned an empty bundle." }, { status: 502 });
  }

  const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
  return new Response(render(body.data), {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      //the filename is built here from a timestamp, never from anything a browser sent, so there is
      //nothing in it to escape
      "Content-Disposition": `attachment; filename="fireflo-diagnostics-${stamp}.txt"`,
      //a diagnostics bundle names vendors, accounts and destination numbers. It has no business in
      //a shared cache, and no business being re-served to the next person on this browser
      "Cache-Control": "private, no-store",
    },
  });
}

interface Bundle {
  collected_at: string;
  lines_per_log: number;
  health: unknown;
  files: { files: Array<{ name: string; kind: string; path: string; state: string }> };
  config: GatewayConfigView[];
  logs: GatewayLogTail[];
}

/**
 * Renders the bundle as something a person reads top to bottom.
 *
 * <p>Plain text rather than the raw JSON because the point is that somebody else can open it a week
 * later without a JSON viewer, and because the log tails are the bulk of it — JSON-escaped log lines
 * are close to unreadable.
 */
function render(bundle: Bundle): string {
  const out: string[] = [];
  const rule = "=".repeat(78);

  out.push(rule, `FireFlo diagnostics — collected ${bundle.collected_at}`, rule, "");

  out.push("FILES", "-".repeat(78));
  for (const file of bundle.files?.files ?? []) {
    out.push(`  ${file.name.padEnd(12)} ${file.kind.padEnd(7)} ${file.state.padEnd(9)} ${file.path}`);
  }
  out.push("");

  out.push("HEALTH", "-".repeat(78), JSON.stringify(bundle.health, null, 2), "");

  for (const view of bundle.config ?? []) {
    out.push(rule, `CONFIG: ${view.name}  (${view.source})`, `path: ${view.path}`, rule);
    if (view.note) {
      out.push(`# ${view.note}`);
    }
    if (view.content) {
      out.push("", view.content);
    } else if (view.credentials) {
      out.push("");
      for (const credential of view.credentials) {
        out.push(
          `  ${credential.type ?? "?"} ${credential.system_id ?? "?"}` +
            `  account=${credential.account_id ?? "-"} product=${credential.product ?? "-"}` +
            `  secret=${credential.secret}`
        );
      }
    }
    out.push("");
  }

  for (const log of bundle.logs ?? []) {
    out.push(rule, `LOG: ${log.name}  (${log.state})`, `path: ${log.path}`, rule);
    if (log.note) {
      out.push(`# ${log.note}`);
    }
    out.push("", ...log.lines, "");
  }

  return out.join("\n");
}
