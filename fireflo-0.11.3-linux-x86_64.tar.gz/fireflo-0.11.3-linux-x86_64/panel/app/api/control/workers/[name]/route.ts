import { NextRequest, NextResponse } from "next/server";
import { isConfigWritable } from "@/lib/config-db";
import { deleteWorker, setWorkerEnabled, setWorkerProperty } from "@/lib/workers";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * Enable, disable or remove one vendor or server.
 *
 * <p>Separate from the create/replace endpoint because these are the things an operator does in a
 * hurry — usually to stop traffic — and none of them should require sending the whole thing back.
 * The full save replaces every setting, so it would need a complete and current copy of the worker,
 * password included, just to pause it.
 *
 * <p>PATCH takes either `{ enabled }` or `{ property: { key, value } }`, one per request.
 */
type Params = { params: Promise<{ name: string }> };

export async function PATCH(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guard();
  if (refused) {
    return refused;
  }
  const { name } = await params;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const fields = (body as Record<string, unknown> | null) ?? {};

  if ("property" in fields) {
    const property = fields.property as Record<string, unknown> | null;
    const key = typeof property?.key === "string" ? property.key.trim() : "";
    const value = typeof property?.value === "string" ? property.value : "";
    if (!SETTABLE.has(key)) {
      //not a general-purpose setting writer: this endpoint exists for the controls, and the form
      //is the way to change anything else. A typo here would otherwise create a dead setting
      return NextResponse.json(
        { error: `'${key || "(empty)"}' cannot be set here. Use the edit form.` },
        { status: 400 }
      );
    }
    try {
      const found = await setWorkerProperty(name, key, value);
      if (!found) {
        return NextResponse.json({ error: `Nothing named '${name}'.` }, { status: 404 });
      }
      return NextResponse.json({ data: { name, key, value } });
    } catch (err) {
      return failed(err);
    }
  }

  const enabled = fields.enabled;
  if (typeof enabled !== "boolean") {
    return NextResponse.json(
      { error: "Expected either { enabled } or { property: { key, value } }." },
      { status: 400 }
    );
  }

  try {
    const found = await setWorkerEnabled(name, enabled);
    if (!found) {
      return NextResponse.json({ error: `Nothing named '${name}'.` }, { status: 404 });
    }
    return NextResponse.json({ data: { name, enabled } });
  } catch (err) {
    return failed(err);
  }
}

/**
 * The settings this endpoint may write.
 *
 * <p>`suspend` stops the worker accepting and drains its queue back to the router, so traffic
 * reroutes elsewhere. `pause` keeps accepting and stops sending, so the queue grows for as long as
 * it is held. Both are live-change properties on the gateway: the poller notices and the worker
 * applies them without a restart.
 */
/**
 * The keys this endpoint may write.
 *
 * <p>An allow-list rather than a general setting writer, for the reason the refusal above gives: a
 * typo would otherwise create a dead setting nobody reads. `suspend` and `pause` are the two
 * controls; the two `dlr.errcodes*` keys are here because the error-code editor is a dedicated
 * screen rather than part of the worker form, and it has nowhere else to write.
 */
const SETTABLE = new Set(["suspend", "pause", "dlr.errcodes", "dlr.errcodes.passthrough"]);

export async function DELETE(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guard();
  if (refused) {
    return refused;
  }
  const { name } = await params;

  try {
    const found = await deleteWorker(name);
    if (!found) {
      return NextResponse.json({ error: `Nothing named '${name}'.` }, { status: 404 });
    }
    return NextResponse.json({ data: { name, deleted: true } });
  } catch (err) {
    return failed(err);
  }
}

async function guard(): Promise<NextResponse | null> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  if (!isConfigWritable()) {
    return NextResponse.json(
      { error: "CONFIG_DATABASE_URL is not set, so editing is switched off." },
      { status: 503 }
    );
  }
  return null;
}

function failed(err: unknown): NextResponse {
  const message = err instanceof Error ? err.message : "Unknown error";
  console.error("workers:", message);
  return NextResponse.json({ error: message }, { status: 500 });
}
