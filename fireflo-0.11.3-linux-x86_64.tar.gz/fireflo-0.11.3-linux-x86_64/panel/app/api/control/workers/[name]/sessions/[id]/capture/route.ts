import { NextRequest, NextResponse } from "next/server";
import { logOperatorEvent } from "@/lib/access-log";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { callOps } from "@/lib/gateway-ops";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * POST / DELETE / GET /api/control/workers/{name}/sessions/{id}/capture
 *
 * <p>Starts, stops and reports one session's SMPP capture. The downloads live one level down in
 * `capture/file/[kind]`, because they answer with a file rather than JSON.
 *
 * <p><strong>The admin token, for a read-only action.</strong> Everywhere else in this panel the
 * read token covers looking and the admin token covers changing, and a capture only looks. It takes
 * the admin token anyway because of *what* it looks at: decoded message bodies and destination
 * numbers for one named customer. The gateway enforces this; the choice here is only to match it.
 *
 * <p>The id is checked as a number before it is forwarded, so an unexpected path segment cannot be
 * passed through to the gateway.
 */
type Params = { params: Promise<{ name: string; id: string }> };

/** Kept in step with OpsCaptureService, which clamps anything outside its own bounds. */
const MAX_SECONDS = 300;

async function guard(): Promise<NextResponse | null> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      //404 rather than 403: a non-operator should not learn that this route exists
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  return null;
}

function base(name: string, id: string): string {
  return `/ops/workers/${encodeURIComponent(name)}/sessions/${id}/capture`;
}

function badId(id: string): NextResponse | null {
  return /^\d+$/.test(id)
    ? null
    : NextResponse.json({ error: `'${id}' is not a session id.` }, { status: 400 });
}

export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guard();
  if (refused) {
    return refused;
  }
  const { name, id } = await params;
  const malformed = badId(id);
  if (malformed) {
    return malformed;
  }

  //the guard above has already established this succeeds; it just does not hand the name back
  const operator = await requireOperator();

  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  const seconds = Number(body?.seconds);
  //rebuilt here rather than forwarded: the gateway clamps anyway, but a query string assembled from
  //validated numbers cannot carry anything else through
  const query =
    Number.isFinite(seconds) && seconds > 0
      ? `?seconds=${Math.min(Math.floor(seconds), MAX_SECONDS)}`
      : "";

  const started = await callOps({ path: `${base(name, id)}${query}`, method: "POST", auth: "admin" });
  if (started.ok) {
    //the arming is the decision worth recording, more than the download that may follow it: this is
    //the moment somebody chose to record a named customer's traffic
    void logOperatorEvent({
      event: "capture_started",
      actor: operator,
      ip: clientIp(req),
      userAgent: clientUserAgent(req),
      detail: { worker: name, session: id, seconds: query ? seconds : null },
    });
  }
  return started;
}

export async function DELETE(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guard();
  if (refused) {
    return refused;
  }
  const { name, id } = await params;
  const malformed = badId(id);
  if (malformed) {
    return malformed;
  }
  return callOps({ path: base(name, id), method: "DELETE", auth: "admin" });
}

export async function GET(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guard();
  if (refused) {
    return refused;
  }
  const { name, id } = await params;
  const malformed = badId(id);
  if (malformed) {
    return malformed;
  }

  const preview = Number(req.nextUrl.searchParams.get("preview"));
  const query = Number.isFinite(preview) && preview > 0 ? `?preview=${Math.min(Math.floor(preview), 200)}` : "";
  return callOps({ path: `${base(name, id)}${query}`, auth: "admin" });
}
