import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { GROUP_POLICIES, type GroupPolicy, type RouteGroupInput, validateRouteGroup } from "@/lib/group-types";
import { deleteRouteGroup, listRouteGroups, routeRulesTargeting, saveRouteGroup } from "@/lib/groups";
import { listRouteTables } from "@/lib/routing";

const TABLES = "app_route_group, app_route_group_member";

/** Every vendor group with its members in preference order. */
export async function GET(): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  try {
    return NextResponse.json({ data: { groups: await listRouteGroups() } });
  } catch (err) {
    return configFailed("groups", err);
  }
}

/**
 * Creates or rewrites one group.
 *
 * <p>Whole-group writes, like `saveRouteTable`: the members are an ordered list whose positions are
 * the failover preference, so a partial update would have to describe a reordering.
 */
export async function PUT(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const raw = body as Partial<RouteGroupInput> & { policy?: string };
  const input: RouteGroupInput = {
    name: typeof raw.name === "string" ? raw.name : "",
    policy: (GROUP_POLICIES as readonly string[]).includes(raw.policy ?? "")
      ? (raw.policy as GroupPolicy)
      : "ROUND_ROBIN",
    label: typeof raw.label === "string" ? raw.label : null,
    enabled: raw.enabled !== false,
    //normalised before validation, so a member posted without a weight is a 1 rather than a NaN
    members: Array.isArray(raw.members)
      ? raw.members.map((m) => ({
        workerName: typeof m?.workerName === "string" ? m.workerName : "",
        weight: Number.isInteger(m?.weight) ? m.weight : 1,
        enabled: m?.enabled !== false,
      }))
      : [],
  };

  try {
    //the collision checks need the other namespaces, and the gateway refuses the WHOLE routing
    //configuration on one -- so this is worth a query rather than being left to be discovered when
    //the next reload takes routing down
    const tableNames = (await listRouteTables()).map((t) => t.name);
    const invalid = validateRouteGroup(input, tableNames);
    if (invalid) {
      return NextResponse.json({ error: invalid }, { status: 400 });
    }
    await saveRouteGroup(input);
    return NextResponse.json({ data: { name: input.name.trim() } });
  } catch (err) {
    return configFailed("save group", err);
  }
}

/**
 * Removes a group, reporting the rules it leaves pointing at nothing.
 *
 * <p>Those rules are not deleted: that would be a larger action than the button describes, and a
 * rule whose target vanished is reported by the gateway once per rule rather than silently.
 */
export async function DELETE(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const name = new URL(req.url).searchParams.get("name");
  if (!name?.trim()) {
    return NextResponse.json({ error: "Which group?" }, { status: 400 });
  }
  try {
    const orphaned = await routeRulesTargeting(name);
    await deleteRouteGroup(name);
    return NextResponse.json({ data: { name: name.trim(), orphanedRules: orphaned } });
  } catch (err) {
    return configFailed("delete group", err);
  }
}
