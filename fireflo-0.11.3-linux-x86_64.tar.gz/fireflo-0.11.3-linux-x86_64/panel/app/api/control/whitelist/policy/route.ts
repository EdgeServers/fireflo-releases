import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { requireOperator } from "@/lib/require-operator";
import {
  getAccountSummaries,
  listExemptProducts,
  listWhitelistSummaries,
  savePolicy,
} from "@/lib/whitelist";
import {
  WHITELIST_MODES,
  enforcementReadiness,
  type WhitelistMode,
} from "@/lib/whitelist-types";

const TABLES = "app_whitelist_policy";

export async function GET(): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  try {
    return NextResponse.json({ data: { summaries: await listWhitelistSummaries() } });
  } catch (err) {
    return configFailed("whitelist policy", err);
  }
}

/**
 * Sets one scope's enforcement modes.
 *
 * <p><strong>Only the mode that was sent is written or checked.</strong> Both fields are optional
 * and an absent one is filled from the stored row. That is not tidiness: the client's copy of the
 * mode it is not editing comes from a summary that may be minutes old, so a request carrying both
 * could silently write back a stale value — and, worse, be refused for it. An operator changing
 * sender IDs was being shown an error about templates, for a field they had not touched.
 *
 * <p><strong>Refuses ENFORCE only when it would refuse everything.</strong> The counts come from
 * `enforcementReadiness`, which models the gateway's merge: a product scope inherits the account's
 * approvals, so an approval filed under one product makes an account-level ENFORCE viable. Checking
 * a single scope in isolation — which this used to do — refused setups that work.
 *
 * <p>What is left is a real refusal and a real warning, and the warning is load-bearing rather than
 * decorative: allowing this configuration means traffic on a product with no approvals of its own,
 * and any login with no product at all, stops at the next poll. Saying which is the whole
 * compensation for no longer refusing outright.
 */
export async function PUT(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const input = body as {
    accountId?: string;
    product?: string;
    headerMode?: WhitelistMode;
    contentMode?: WhitelistMode;
  };
  if (!input?.accountId?.trim()) {
    return NextResponse.json({ error: "An account is required." }, { status: 400 });
  }
  //absent means "leave this one alone" -- see the note above. Only what was sent is validated
  for (const mode of [input.headerMode, input.contentMode]) {
    if (mode !== undefined && !WHITELIST_MODES.includes(mode)) {
      return NextResponse.json(
        { error: `'${mode}' is not a mode. Use OFF, REPORT or ENFORCE.` },
        { status: 400 }
      );
    }
  }
  if (input.headerMode === undefined && input.contentMode === undefined) {
    return NextResponse.json({ error: "Nothing to set." }, { status: 400 });
  }

  try {
    const accountId = input.accountId.trim();
    const product = (input.product ?? "").trim();
    const [summaries, exempt] = await Promise.all([
      getAccountSummaries(accountId),
      listExemptProducts(),
    ]);
    const stored = summaries.find((s) => s.accountId === accountId && s.product === product);

    const warnings: string[] = [];
    for (const [kind, mode] of [
      ["header", input.headerMode],
      ["content", input.contentMode],
    ] as const) {
      if (mode === undefined) {
        continue;
      }
      const readiness = enforcementReadiness(summaries, accountId, product, kind, mode, exempt);
      if (readiness.refuse) {
        return NextResponse.json({ error: readiness.refuse }, { status: 409 });
      }
      if (readiness.warn) {
        warnings.push(readiness.warn);
      }
    }

    const operator = await requireOperator();
    const headerMode = input.headerMode ?? stored?.headerMode ?? "OFF";
    const contentMode = input.contentMode ?? stored?.contentMode ?? "OFF";
    await savePolicy(accountId, product, headerMode, contentMode, operator);
    return NextResponse.json({
      data: { accountId, product, headerMode, contentMode, warnings },
    });
  } catch (err) {
    return configFailed("save whitelist policy", err);
  }
}
