import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { requireOperator } from "@/lib/require-operator";
import { reviewHeader } from "@/lib/mis-whitelist";
import { deleteHeader } from "@/lib/whitelist";

type Params = { params: Promise<{ id: string }> };

const TABLES = "app_header";

/**
 * Withdraws an approved sender ID.
 *
 * <p>Unlike deleting a catalogue row elsewhere in this panel, this one has an immediate effect on
 * traffic: if the account is enforcing, the customer stops being able to send from that sender ID
 * within one configuration poll. The UI asks before calling it.
 */
export async function DELETE(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { id } = await params;
  try {
    const removed = await deleteHeader(Number(id));
    return removed
      ? NextResponse.json({ data: { id } })
      : NextResponse.json({ error: "No such approved sender ID." }, { status: 404 });
  } catch (err) {
    return configFailed("delete approved header", err);
  }
}

/**
 * Approves or refuses a request.
 *
 * <p>Approving is what puts a row into service: the gateway serves it only when it is enabled AND
 * approved, so until this runs a customer's submission is stored and inert.
 *
 * <p>**A refusal requires a reason and the route enforces it**, not the form. The customer is shown
 * this text and nothing else about the decision, so a blank one leaves them with a registration that
 * does not work and no idea what to change -- which produces the support ticket the portal existed
 * to avoid.
 */
export async function PATCH(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const operator = await requireOperator();
  const { id } = await params;
  if (!/^\d+$/.test(id)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  let body: Record<string, unknown> | null;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const status = body?.status;
  if (status !== "APPROVED" && status !== "REJECTED") {
    return NextResponse.json({ error: "Expected { status: 'APPROVED' | 'REJECTED' }." }, { status: 400 });
  }
  const reviewNote = typeof body?.reviewNote === "string" ? body.reviewNote.trim() : "";
  if (status === "REJECTED" && !reviewNote) {
    return NextResponse.json(
      { error: "Say why. The customer is shown this and nothing else about the decision." },
      { status: 400 }
    );
  }

  try {
    await reviewHeader(Number(id), status, operator, reviewNote || null);
    return NextResponse.json({ data: { id, status } });
  } catch (err) {
    return configFailed("review approved header", err);
  }
}
