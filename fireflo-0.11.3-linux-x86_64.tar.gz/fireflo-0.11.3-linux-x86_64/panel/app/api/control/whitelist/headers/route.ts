import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { requireOperator } from "@/lib/require-operator";
import { loadCoverage } from "@/lib/tlv-coverage-payload";
import { listLoginProducts } from "@/lib/credentials";
import { loginOutsideAccount } from "@/lib/whitelist";
import { tlvCsvProblem } from "@/lib/tlv-string";
import { listHeaders, listWhitelistSummaries, saveHeader } from "@/lib/whitelist";
import { validateHeader, type HeaderInput } from "@/lib/whitelist-types";

const TABLES = "app_header and app_whitelist_policy";

/**
 * Approved sender IDs, optionally for one account.
 *
 * <p>The summaries come back alongside, because every screen that lists headers also needs to say
 * whether they are being enforced — a list of approved sender IDs with no indication that the mode
 * is OFF reads as protection that is not there.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const account = req.nextUrl.searchParams.get("account") ?? undefined;
  try {
    const [headers, summaries, coverage, logins] = await Promise.all([
      listHeaders(account),
      listWhitelistSummaries(),
      //beside the summaries and for the same reason they are here: a row that will stamp nothing
      //looks identical to one that will, and only configuration this page cannot see tells them apart
      loadCoverage(account),
      //its own key rather than reading coverage.logins: loadCoverage deliberately returns empty
      //lists when no listener declares a mandatory TLV, which is most deployments -- correct for a
      //coverage sentence, and it left the login picker with nothing to offer
      listLoginProducts(account),
    ]);
    return NextResponse.json({
      data: {
        headers,
        summaries,
        coverage,
        //system_id only, and never null: an HTTP login keyed on its api key has no name to bind an
        //approval to, and offering one would write a scope that matches nothing
        logins: [...new Set(logins.map((l) => l.systemId).filter(Boolean))].sort(),
      },
    });
  } catch (err) {
    return configFailed("approved headers", err);
  }
}

export async function PUT(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const input = body as HeaderInput;
  if (!input?.accountId?.trim()) {
    return NextResponse.json(
      { error: "An account is required. A sender ID is approved for one customer, not globally." },
      { status: 400 }
    );
  }
  const invalid = validateHeader(input.header ?? "");
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }
  const badTlv = tlvCsvProblem(input.tlvs?.trim() || null);
  if (badTlv) {
    //the form refuses this too, but the form is not where a rule lives -- and this is the one that
    //stops a token like `1401` reaching a column the gateway stamps from
    return NextResponse.json({ error: badTlv }, { status: 400 });
  }
  const badLogin = await loginOutsideAccount(input.accountId, input.systemId);
  if (badLogin) {
    return NextResponse.json({ error: badLogin }, { status: 400 });
  }

  try {
    const operator = await requireOperator();
    await saveHeader(input, operator);
    return NextResponse.json({ data: { accountId: input.accountId, header: input.header } });
  } catch (err) {
    return configFailed("save approved header", err);
  }
}
