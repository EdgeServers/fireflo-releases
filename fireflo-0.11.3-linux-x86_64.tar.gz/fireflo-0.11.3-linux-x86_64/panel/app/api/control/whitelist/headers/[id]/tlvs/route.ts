import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { requireOperator } from "@/lib/require-operator";
import { decideHeaderTlvs } from "@/lib/mis-whitelist";

type Params = { params: Promise<{ id: string }> };

/**
 * POST /api/control/whitelist/headers/{id}/tlvs — the operator's answer to a TLV proposal.
 *
 * <p>Its own route rather than another shape on the review `PATCH`, because it is a different
 * decision about a different column. The review decides whether the sender ID may be used at all;
 * this decides what it stamps, and the two are independent — a proposal can be accepted on a row
 * that is already approved, which is the ordinary case, and neither action touches the other's
 * field.
 *
 * <p>`{ accept: true }` moves `requested_tlvs` into `tlvs`, which **changes what goes on the wire at
 * the next configuration poll** — this is the one write here with an effect on live traffic.
 * `{ accept: false }` clears the request and leaves `tlvs` untouched.
 *
 * <p>Either way the proposal stops being outstanding. A decision that left it in place would leave
 * the customer looking at a request nobody had answered.
 */
export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite("app_header");
  if (refused) {
    return refused;
  }
  const operator = await requireOperator();
  const { id } = await params;
  if (!/^\d+$/.test(id)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  let body: Record<string, unknown> | null;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  if (typeof body?.accept !== "boolean") {
    return NextResponse.json({ error: "Expected { accept: true | false }." }, { status: 400 });
  }

  try {
    //the WHERE clause carries `requested_tlvs IS NOT NULL`, so a second click, or two operators
    //answering the same request, gets this rather than silently clearing a proposal filed since
    const decided = await decideHeaderTlvs(Number(id), body.accept, operator);
    return decided
      ? NextResponse.json({ data: { id, accepted: body.accept } })
      : NextResponse.json(
        { error: "There is no proposal on this sender ID. Somebody may have answered it already." },
        { status: 409 }
      );
  } catch (err) {
    return configFailed("decide proposed header TLVs", err);
  }
}
