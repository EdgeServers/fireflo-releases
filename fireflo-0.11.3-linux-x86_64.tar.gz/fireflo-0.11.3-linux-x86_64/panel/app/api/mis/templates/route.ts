import { NextRequest, NextResponse } from "next/server";
import { requireCustomer, scopeFor, subjectAccount } from "@/lib/require-customer";
import { notFoundOrThrow, note } from "@/lib/mis-route";
import { proposedTlvs } from "@/lib/tlv-string";
import { listOwnTemplates, scopedLogin, scopedProduct, submitTemplate } from "@/lib/mis-whitelist";
import { validateTemplate } from "@/lib/whitelist-types";

/**
 * GET|POST /api/mis/templates — the customer's own approved and requested wording.
 *
 * <p>Same rules as the sender IDs beside it: the account comes from the session, the status is
 * forced to `PENDING`, and nothing the body claims about either is read.
 *
 * <p><strong>`tlvs` is deliberately not accepted.</strong> Under DLT that column carries the
 * registered template id, which the gateway stamps over whatever the client claimed — a customer who
 * could write it could assert somebody else's registration while sending approved wording, which is
 * exactly what approving wording is for. The customer states their registration reference in
 * `requestNote`, as a claim to be checked, and the operator sets the real value at approval.
 */
export async function GET(): Promise<NextResponse> {
  let scope: string[];
  try {
    scope = await scopeFor(await requireCustomer());
  } catch (err) {
    return notFoundOrThrow(err);
  }
  return NextResponse.json({ data: { rows: await listOwnTemplates(scope), scope } });
}

export async function POST(req: NextRequest): Promise<NextResponse> {
  let body: Record<string, unknown> | null;
  let accountId: string;
  try {
    const session = await requireCustomer();
    //read before the account is resolved, because the account may be named in it
    body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
    if (!body) {
      return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
    }
    //absent means "me", which is every ordinary customer's request unchanged. A reseller may name
    //one of its own accounts instead, and that id goes through `assertInScope` before it is used
    //for anything -- see lib/require-customer.ts
    accountId = await subjectAccount(session, body.accountId);
  } catch (err) {
    return notFoundOrThrow(err);
  }

  const text = typeof body?.body === "string" ? body.body.trim() : "";
  //the same rejections the gateway makes when it loads the row, so a template that could never
  //match is refused here rather than approved and then silently skipped at load
  const invalid = validateTemplate(text);
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }

  const tlvs = proposedTlvs(body?.requestedTlvs);
  if ("error" in tlvs) {
    return NextResponse.json({ error: tlvs.error }, { status: 400 });
  }

  //this account only, never the reseller's whole scope. `accountId` is the SUBJECT here -- a
  //reseller asking on a child's behalf gets the child -- so the login must be one of that account's
  //own. Passing the scope would let a reseller bind a child's approval to its own login
  const login = await scopedLogin([accountId], body?.systemId);
  if ("error" in login) {
    return NextResponse.json({ error: login.error }, { status: 400 });
  }

  //the same treatment, and it had none: `product` went from the request into the column untouched,
  //so it was both unbounded in length and free to name somebody else's product
  const product = await scopedProduct(accountId, body?.product);
  if ("error" in product) {
    return NextResponse.json({ error: product.error }, { status: 400 });
  }

  const failure = await submitTemplate({
    accountId,
    product: product.value,
    name: note(body?.name),
    body: text,
    requestNote: note(body?.requestNote),
    requestedTlvs: tlvs.value,
    systemId: login.value,
  });
  if (failure) {
    return NextResponse.json({ error: failure }, { status: 409 });
  }
  return NextResponse.json({
    data: { submitted: true, message: "Sent for approval. It is not in use until an operator approves it." },
  });
}
