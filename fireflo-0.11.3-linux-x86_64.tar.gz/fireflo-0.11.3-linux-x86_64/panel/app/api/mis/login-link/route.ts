import { NextRequest, NextResponse } from "next/server";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { logAuthFailure } from "@/lib/access-log";
import { recordCustomerAccess } from "@/lib/customer-access-log";
import { issueLoginToken, recentTokenCount } from "@/lib/login-token";
import { describeMailError, mailerConfigured, sendLoginLink } from "@/lib/mailer";
import { limiter } from "@/lib/rate-limit";

/**
 * Asks for a sign-in link. Public, and the only public write in this application.
 *
 * <h2>It always answers the same thing</h2>
 *
 * <p>Unknown address, disabled account, mail server down, rate limited: one 200 and one sentence.
 * The alternative is an oracle — a form that says "no such account" lets anybody test a list of
 * addresses against your customer base, and the customer base is the thing worth stealing here.
 *
 * <p>That is uncomfortable to write, because it means a customer who typos their address gets the
 * same reassuring message as one who did not. It is still right: the person who mistyped can try
 * again, and the person enumerating cannot learn anything at all.
 *
 * <p><strong>The server still knows.</strong> Every branch that answers "sent" without sending logs
 * why, so an operator can tell "nobody asked" from "the mail server is refusing us" — which is the
 * distinction the identical response destroys for the caller and must not destroy for the operator.
 *
 * <h2>The per-IP limit, which is not the same limit as the per-account one</h2>
 *
 * <p>`recentTokenCount` is keyed on an **account**, so it only ever applied to addresses that have
 * one. For an unknown address there was no limit at all — and every request still cost two SELECTs
 * and an INSERT into `app_customer_access_log`, against a pool of four connections that
 * `requireCustomer()` and every operator config route share. A loop against this one endpoint
 * degraded both panels and grew an operator-facing audit table without bound.
 *
 * <p>So there is a bucket per address-of-origin, checked **before the body is even parsed**. It is
 * safe to answer 429 here where the per-account limit answers the neutral 200, and the difference is
 * the point: this one is keyed on something the caller already knows about itself, so refusing
 * loudly teaches an enumerator nothing. Saying it about an *address* would be the oracle.
 */

/** Per account, and generous: a customer who did not get the first mail will click again. */
const MAX_PER_WINDOW = 5;
const WINDOW_MINUTES = 15;

/**
 * Per address-of-origin, and deliberately looser than the per-account limit.
 *
 * <p>An office behind one NAT address is several customers sharing a bucket, so this has to leave
 * room for a genuine morning; it only has to be tight enough that a flood cannot outpace a
 * database. Twenty requests per quarter hour is far more than any person clicks and far less than
 * anything that would be felt.
 *
 * <p>In-process, so two instances behind a load balancer allow it twice — see `lib/rate-limit.ts`.
 * That is fine for bounding a flood and would not be fine for a quota.
 */
const perOrigin = limiter(20, WINDOW_MINUTES * 60_000);

/**
 * Where the customer's browser can actually reach this panel, or null.
 *
 * <p>Absolute and http(s) or nothing: a link is the whole credential and the only way into the
 * portal, so a value that cannot be clicked is worse than an unconfigured feature — the customer is
 * told a link is on its way, and one arrives that does not work.
 */
function baseUrl(): string | null {
  const raw = process.env.MIS_PANEL_BASE_URL?.trim().replace(/\/+$/, "");
  if (!raw) {
    return null;
  }
  try {
    const parsed = new URL(raw);
    return parsed.protocol === "http:" || parsed.protocol === "https:" ? raw : null;
  } catch {
    return null;
  }
}

const SAME_ANSWER = {
  message: "If that address is on an account, a sign-in link is on its way. It expires in 15 minutes.",
};

/**
 * Said when this panel cannot send mail at all.
 *
 * <p>Deliberately different from {@link SAME_ANSWER}, and safe to be: it is checked **before any
 * account is looked up**, so it describes the server and not the address. Every address gets it,
 * whether or not it has an account, which is what keeps it from becoming the enumeration oracle the
 * neutral answer exists to prevent. Move this check below the lookup and that stops being true.
 *
 * <p>The neutral answer stays for every other case. Telling a customer "a link is on its way" when
 * the server knows it can never send one is the one branch where the neutral wording misleads the
 * person it was meant to protect.
 */
const NO_MAIL = {
  error: "Sign-in by email is not available on this panel. Ask your account manager.",
};

/**
 * Whether to print the sign-in link to this process's console instead of posting it.
 *
 * <p>For a development instance with no mail server, where the alternative is that the portal
 * cannot be entered at all. Off unless {@code FIREFLO_DEV_LOGIN_LINK} is exactly `true`: not
 * "anything truthy", because a stray `0` or `false` in an environment file must not switch this on.
 *
 * <p><strong>A printed link is a sign-in.</strong> Anyone who can read the journal can become any
 * customer on this deployment, for fifteen minutes, without their password and without their
 * mailbox. On a laptop that is a convenience; on anything shared or reachable it is an account
 * takeover with no audit trail beyond this line. **Never set it on a production panel.**
 *
 * <p>The HTTP response is deliberately unchanged either way. The link goes to the console and
 * nowhere else, so this cannot turn the endpoint into the address-enumeration oracle that
 * {@link SAME_ANSWER} exists to prevent — the caller still learns nothing.
 */
function devLinkPrinting(): boolean {
  return process.env.FIREFLO_DEV_LOGIN_LINK?.trim() === "true";
}

/**
 * The refusals a visitor caused, as opposed to the ones we did.
 *
 * <p>Only these reach the ban feed. `unknown_address` is address enumeration -- the probe that finds
 * out which customers exist -- and `rate_limited` is the same actor not stopping. Everything else a
 * `link_denied` can carry is a fault on our side of the wire.
 */
const CALLER_FAULT = new Set(["unknown_address", "rate_limited"]);

export async function POST(req: NextRequest): Promise<NextResponse> {
  const ip = clientIp(req);
  //FIRST, ahead of req.json(): the body is unbounded and parsing it is the first thing a flood
  //would make this process pay for. Nothing here touches the database, and nothing is logged --
  //a refusal that wrote an audit row would be the amplifier this exists to close
  if (!perOrigin.allow(ip ?? "unknown")) {
    return NextResponse.json(
      { error: "Too many sign-in requests from this address. Try again shortly." },
      { status: 429 }
    );
  }

  let email = "";
  try {
    const body = (await req.json()) as { email?: unknown };
    email = typeof body.email === "string" ? body.email.trim() : "";
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  //the one thing worth refusing outright, because it cannot be anybody's address and refusing it
  //reveals nothing about who has an account
  if (!email || !email.includes("@") || email.length > 320) {
    return NextResponse.json({ error: "That does not look like an email address." }, { status: 400 });
  }

  const userAgent = clientUserAgent(req);
  //one row per branch, so the log can distinguish what the response deliberately cannot.
  //
  //"extra" carries the diagnosis on the branches that have one. It goes in the detail column rather
  //than into a new event name because app_customer_access_log has a CHECK constraint listing the
  //events it accepts (V1.20.0) -- a new one would be a migration, and this is a reason, not a kind
  const record = (
    event: "link_requested" | "link_denied",
    reason?: string,
    extra?: Record<string, unknown>
  ) => {
    void recordCustomerAccess({
      event,
      email,
      ip,
      userAgent,
      detail: reason ? { reason, ...extra } : extra,
    });
    //and, for the ones the CALLER caused, into the file fail2ban watches.
    //
    //The split matters more than it looks. smtp_unconfigured, base_url_unusable and send_failed are
    //OUR faults: the visitor asked for a link and our mailer could not send one. Banning on those
    //would cut a customer off because our SMTP broke, and they would have no idea why. What is left
    //is caller-driven: an address with no account is somebody working through addresses to find out
    //which exist, and rate_limited is that same somebody, persisting.
    if (event === "link_denied" && reason && CALLER_FAULT.has(reason)) {
      void logAuthFailure({ surface: "portal", reason, triedAs: email, ip });
    }
  };

  try {
    //FIRST, before recentTokenCount or issueLoginToken touch the database. That ordering is what
    //makes NO_MAIL safe to be a distinct answer -- see its doc
    const canMail = mailerConfigured();
    //the dev console is the second way a link can reach somebody, so "we cannot send" is only true
    //when neither is available. With printing on this falls through to issuance, and the answer the
    //caller gets is the ordinary neutral one -- see devLinkPrinting
    if (!canMail && !devLinkPrinting()) {
      console.error("mis-panel: a sign-in link was requested but SMTP is not configured.");
      record("link_denied", "smtp_unconfigured");
      return NextResponse.json(NO_MAIL, { status: 503 });
    }
    //checked BEFORE minting a token, not while building the URL. Unset, the link used to be sent as
    //'/verify?token=…' -- a relative reference, which is not something a mail client can follow. The
    //customer got an unusable link, the token was spent from the rate-limit budget, and nothing
    //anywhere said the base URL was the problem
    const base = baseUrl();
    if (!base) {
      console.error(
        "mis-panel: a sign-in link was requested but MIS_PANEL_BASE_URL is not set to an absolute "
          + "http(s) URL, so the link would not be one anybody could follow. Nothing was sent."
      );
      record("link_denied", "base_url_unusable");
      return NextResponse.json(SAME_ANSWER);
    }
    if ((await recentTokenCount(email, WINDOW_MINUTES)) >= MAX_PER_WINDOW) {
      console.warn(`mis-panel: rate limited sign-in requests for ${email} from ${ip ?? "unknown"}`);
      record("link_denied", "rate_limited");
      return NextResponse.json(SAME_ANSWER);
    }

    const issued = await issueLoginToken(email, ip);
    if (!issued) {
      //no enabled account has this address, or the account is disabled. Ordinary -- a typo, or
      //somebody trying addresses -- and silence here would hide the second case entirely.
      //
      //The ADDRESS is in the database row, not in this line: the journal is read over shoulders and
      //copied into tickets, and an address that has no account is still somebody's address. An
      //operator asking "why did this customer get no link" queries the log by email and finds the
      //row; nobody has to grep the journal for it
      console.info(
        `mis-panel: sign-in requested for an address with no enabled account, from ${ip ?? "unknown"}`
      );
      record("link_denied", "unknown_address");
      return NextResponse.json(SAME_ANSWER);
    }

    const url = `${base}/verify?token=${encodeURIComponent(issued.token)}`;
    if (devLinkPrinting()) {
      //loud, and on its own lines, because this is a credential in a log and somebody scrolling
      //past it should not mistake it for routine output
      console.warn(
        `\n${"=".repeat(78)}\n` +
          `FIREFLO_DEV_LOGIN_LINK is on. This link signs in as ${issued.accountId} for 15 minutes,\n` +
          `once. Treat it as a password. It must never be enabled on a production panel.\n\n` +
          `  ${url}\n${"=".repeat(78)}\n`
      );
    }
    if (canMail) {
      await sendLoginLink(email, url, issued.accountId);
    }
    //the success path logged nothing at all before this
    void recordCustomerAccess({
      event: "link_requested",
      accountId: issued.accountId,
      email,
      ip,
      userAgent,
    });
    return NextResponse.json(SAME_ANSWER);
  } catch (err) {
    //still the same answer. A mail server that is refusing us is our problem, not a signal to hand
    //to whoever is on the other end of this request.
    //
    //But it IS the operator's problem, so the diagnosis goes to both places: the journal for
    //whoever is watching it, and the access log for whoever is asked a week later why a particular
    //customer never got their link. describeMailError picks out the fields that say which -- a
    //refused socket, a rejected login, a relay that will not do TLS -- rather than one sentence
    const detail = describeMailError(err);
    console.error(
      `mis-panel: could not send a sign-in link (${Object.entries(detail)
        .map(([k, v]) => `${k}=${v}`)
        .join(" ")})`,
      err
    );
    record("link_denied", "send_failed", detail);
    return NextResponse.json(SAME_ANSWER);
  }
}
