import { NextRequest, NextResponse } from "next/server";
import { requireCustomer, scopeFor, subjectAccount } from "@/lib/require-customer";
import { notFoundOrThrow, note } from "@/lib/mis-route";
import { proposedTlvs } from "@/lib/tlv-string";
import { listOwnHeaders, scopedLogin, scopedProduct, submitHeader } from "@/lib/mis-whitelist";
import { validateHeader } from "@/lib/whitelist-types";

/**
 * GET|POST /api/mis/senders — the customer's own approved and requested sender IDs.
 *
 * <p><strong>The account comes from the session, never from the body.</strong> POST reads only the
 * sender ID, the product and the customer's note; `accountId`, `status` and `requestedBy` are set
 * here regardless of what was sent. A body field that could widen the account is the one mistake
 * this whole surface has to be built around — see the note on `lib/require-customer.ts`.
 *
 * <p>Everything a customer writes lands `PENDING`, so it is stored and not in use. The gateway
 * serves a row only when it is enabled AND approved.
 */
export async function GET(): Promise<NextResponse> {
  let scope: string[];
  try {
    scope = await scopeFor(await requireCustomer());
  } catch (err) {
    return notFoundOrThrow(err);
  }
  return NextResponse.json({ data: { rows: await listOwnHeaders(scope), scope } });
}

export async function POST(req: NextRequest): Promise<NextResponse> {
  let body: Record<string, unknown> | null;
  let accountId: string;
  try {
    const session = await requireCustomer();
    //read before the account is resolved, because the account may be named in it
    body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
    if (!body) {
      return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
    }
    //absent means "me", which is every ordinary customer's request unchanged. A reseller may name
    //one of its own accounts instead, and that id goes through `assertInScope` before it is used
    //for anything -- see lib/require-customer.ts
    accountId = await subjectAccount(session, body.accountId);
  } catch (err) {
    return notFoundOrThrow(err);
  }

  const header = typeof body?.header === "string" ? body.header.trim() : "";
  //the same rejections the operator's form makes, and the same ones the database CHECK makes
  const invalid = validateHeader(header);
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }

  const tlvs = proposedTlvs(body?.requestedTlvs);
  if ("error" in tlvs) {
    return NextResponse.json({ error: tlvs.error }, { status: 400 });
  }

  //this account only, never the reseller's whole scope. `accountId` is the SUBJECT here -- a
  //reseller asking on a child's behalf gets the child -- so the login must be one of that account's
  //own. Passing the scope would let a reseller bind a child's approval to its own login
  const login = await scopedLogin([accountId], body?.systemId);
  if ("error" in login) {
    return NextResponse.json({ error: login.error }, { status: 400 });
  }

  //the same treatment, and it had none: `product` went from the request into the column untouched,
  //so it was both unbounded in length and free to name somebody else's product
  const product = await scopedProduct(accountId, body?.product);
  if ("error" in product) {
    return NextResponse.json({ error: product.error }, { status: 400 });
  }

  const failure = await submitHeader({
    //the subject, resolved above: the caller's own account, or a child it named and was proved to
    //hold. Never taken from the body directly
    accountId,
    product: product.value,
    header,
    requestNote: note(body?.requestNote),
    requestedTlvs: tlvs.value,
    systemId: login.value,
  });
  if (failure) {
    return NextResponse.json({ error: failure }, { status: 409 });
  }
  return NextResponse.json({
    data: { submitted: true, message: "Sent for approval. It is not in use until an operator approves it." },
  });
}
