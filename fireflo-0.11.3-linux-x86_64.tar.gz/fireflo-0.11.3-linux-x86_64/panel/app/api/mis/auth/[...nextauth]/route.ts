import type { NextRequest } from "next/server";
import { misHandlers } from "@/lib/mis-auth";
import { runWithRequestContext } from "@/lib/request-context";

/**
 * The portal's own NextAuth endpoint, mounted away from `/api/auth` so the two instances never
 * share a route any more than they share a cookie.
 *
 * <p>Wrapped for the same reason as the operator instance: `authorize()` redeems the sign-in link
 * and is the only place that knows an account just signed in, but it is handed the token and
 * nothing else. Without the address carried through here, a redeemed link records only `used_at` —
 * so a link redeemed by whoever intercepted the mail looks exactly like the customer using it.
 */

export async function GET(req: NextRequest): Promise<Response> {
  return runWithRequestContext(req, () => misHandlers.GET(req));
}

export async function POST(req: NextRequest): Promise<Response> {
  return runWithRequestContext(req, () => misHandlers.POST(req));
}
