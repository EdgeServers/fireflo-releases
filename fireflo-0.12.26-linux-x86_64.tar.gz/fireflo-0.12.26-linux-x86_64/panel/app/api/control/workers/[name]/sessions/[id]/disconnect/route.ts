import { NextRequest, NextResponse } from "next/server";
import { auditConfigChange } from "@/lib/config-audit";
import { callOps } from "@/lib/gateway-ops";
import { isConfigWritable } from "@/lib/config-db";
import { findBoundSmppCredential, setCredentialEnabled } from "@/lib/credentials";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * POST /api/control/workers/{name}/sessions/{id}/disconnect
 *
 * <p>Drops one customer's bind on one listener, leaving every other bind on it carrying traffic.
 * Before this the only lever was stopping the listener, which takes every other customer down too.
 *
 * <p>The admin token, and not arguably: it ends a connection a customer is sending on.
 *
 * <p><strong>Disconnecting does not exclude.</strong> A client with a healthy bind loop is back
 * within seconds. Keeping it out means disabling the credential, which is a database write in
 * another domain and only reaches the gateway on its next configuration poll — so
 * `{ "disable_login": true }` asks for both.
 *
 * <p><strong>The order is the reason both live in one route.</strong> Disable first, disconnect
 * second. The other way round leaves a guaranteed window in which the reconnect is matched against a
 * credential snapshot that still says enabled, and two browser calls could not be relied on to keep
 * that order across a slow network or a closed tab. Even so the door is not shut instantly: the
 * gateway is serving a cached snapshot, so a reconnect inside the poll interval is still admitted.
 * The caller is told this rather than left to assume otherwise.
 *
 * <p>The id is checked as a number before forwarding, so an unexpected path segment cannot be passed
 * through to the gateway.
 */
type Params = { params: Promise<{ name: string; id: string }> };

export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  let operator;
  try {
    operator = await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const { name, id } = await params;
  if (!/^\d+$/.test(id)) {
    return NextResponse.json({ error: `'${id}' is not a session id.` }, { status: 400 });
  }

  //no body at all is the common case: drop this one bind and nothing else
  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  const disableLogin = body?.disable_login === true;
  const systemId = typeof body?.system_id === "string" ? body.system_id.trim() : "";

  let disabled: number | null = null;
  if (disableLogin) {
    if (!isConfigWritable()) {
      return NextResponse.json(
        {
          error: "CONFIG_DATABASE_URL is not set, so the login cannot be disabled from here. "
            + "Disconnect without it, or disable the login on the gateway.",
        },
        { status: 503 }
      );
    }
    if (!systemId) {
      return NextResponse.json(
        { error: "Disabling a login needs the system_id the session is bound with." },
        { status: 400 }
      );
    }

    const credential = await findBoundSmppCredential(systemId);
    if (!credential) {
      //deliberately fatal rather than "disconnect anyway": the caller asked to keep this customer
      //out, and doing half of that while reporting success is the failure worth avoiding
      return NextResponse.json(
        {
          error: `No enabled SMPP login has the system ID '${systemId}', so there is nothing to `
            + "disable. Nothing was disconnected.",
        },
        { status: 404 }
      );
    }
    await setCredentialEnabled(credential.id, false);
    disabled = credential.id;
  }

  const dropped = await callOps({
    path: `/ops/workers/${encodeURIComponent(name)}/sessions/${id}/disconnect`,
    method: "POST",
    auth: "admin",
    //the gateway waits up to five seconds for the customer's unbind_resp before closing anyway
    timeoutMs: 15_000,
  });
  if (dropped.ok) {
    //the disable above is audited by setCredentialEnabled; this is the live session going
    await auditConfigChange({
      domain: "session",
      name: `${name}#${id}`,
      action: "action:disconnect",
      after: { listener: name, systemId: systemId || null, disabledCredential: disabled },
    }, operator);
  }

  if (disabled === null) {
    return dropped;
  }

  //the login is already off at this point, so a failed disconnect is a partial result rather than a
  //failure -- saying "could not disconnect" alone would hide a change that has been made
  const payload = (await dropped.json().catch(() => null)) as Record<string, unknown> | null;
  if (!dropped.ok) {
    return NextResponse.json(
      {
        error: `Login ${systemId} is disabled and will stop binding within the gateway's poll `
          + `interval, but the live session was not dropped: ${payload?.error ?? "unknown error"}`,
      },
      { status: dropped.status }
    );
  }
  return NextResponse.json({ data: { ...(payload?.data as object), disabled_credential: disabled } });
}
