import { NextRequest, NextResponse } from "next/server";
import { auditConfigChange } from "@/lib/config-audit";
import { callOps } from "@/lib/gateway-ops";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET / DELETE /api/control/security/watch/{id}
 *
 * <p>GET returns the events after `?after=`, which is the `next` of the previous reply; the
 * Security page polls it about once a second while a watch runs. DELETE stops the watch.
 *
 * <p>The id is checked as the gateway's hex form before it is forwarded, so an unexpected path
 * segment cannot be passed through.
 */
type Params = { params: Promise<{ id: string }> };

async function guard(id: string): Promise<NextResponse | null> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  return /^[0-9a-f]{16}$/.test(id)
    ? null
    : NextResponse.json({ error: `'${id}' is not a watch id.` }, { status: 400 });
}

export async function GET(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const { id } = await params;
  const refused = await guard(id);
  if (refused) {
    return refused;
  }
  const after = Number(req.nextUrl.searchParams.get("after"));
  const query = Number.isSafeInteger(after) && after > 0 ? `?after=${after}` : "";
  return callOps({ path: `/ops/watches/${id}${query}`, auth: "admin", passErrors: true });
}

export async function DELETE(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const { id } = await params;
  const refused = await guard(id);
  if (refused) {
    return refused;
  }
  const res = await callOps({ path: `/ops/watches/${id}`, method: "DELETE", auth: "admin", passErrors: true });
  if (res.ok) {
    //starting a watch is logged by the sibling POST; stopping one is logged here so the pair closes
    await auditConfigChange({ domain: "watch", name: id, action: "delete" });
  }
  return res;
}
