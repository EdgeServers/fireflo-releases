"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft, Plus, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CardActions } from "@/components/CardBits";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ErrorCard, WarningCard } from "@/components/FormNotices";
import { describePortProblem, parsePortRange } from "@/lib/port-range";
import { DisclosureSection } from "@/components/DisclosureSection";
import { WorkerFields } from "@/components/WorkerFields";
import { settingLabel } from "@/lib/labels";
import { statusVerdict, type ConfigKeyRow, type StatusVerdict } from "@/lib/config-key-registry";
import { DEAD_KEYS, SECTIONS, fieldFor, needsRestart, type SectionId } from "@/lib/setting-fields";
import {
  KIND,
  KIND_NOUN,
  REDACTED,
  millisecondWarnings,
  publicHostProblem,
  recipientCountryProblem,
  type Worker,
  type WorkerType,
} from "@/lib/worker-types";

/** What /api/control/listener-ports answers with. */
interface PortAdvice {
  range: string | null;
  used: { name: string; port: number }[];
  suggested: number | null;
}

interface WorkerFormProps {
  /** Fixed by the page, never chosen here — a vendor page creates vendors and nothing else. */
  type: WorkerType;
  worker: Worker | null;
  onCancel: () => void;
  onSaved: () => void | Promise<void>;
  /**
   * Restart the worker now, offered on the "saved, but needs a restart" card. Absent on a page
   * that cannot restart (a new worker has nothing running yet), the card says Done only.
   */
  onRestart?: () => void | Promise<void>;
  /** A section to open and scroll to, for a link that came here to change one setting. */
  focus?: SectionId;
}

/**
 * Create or replace one vendor or server.
 *
 * <p>The type is a prop rather than a field. Besides matching how the pages are split, it closes a
 * real hazard: the type used to be an editable dropdown, and changing it kept the settings belonging
 * to the old kind — a vendor's host and password left behind on a listener. Now that cannot be
 * expressed.
 *
 * <p>Every setting this panel has an English name for is offered as a field with a control that
 * suits it, split into what a connection needs to exist at all and the groups behind it. Anything
 * the gateway accepts that is not in the catalogue still goes in below as a free-form pair, and that
 * list is now the exact complement of the catalogue — so a setting added by hand in an earlier
 * release moves into its proper section the first time this form opens, with no change to the data.
 *
 * <p>An empty field means "unset" and is not written, so the gateway falls back to its own default
 * rather than being handed an empty string it would treat as a real value.
 */
export function WorkerForm({ type, worker, onCancel, onSaved, onRestart, focus }: WorkerFormProps) {
  const isNew = worker === null;
  const noun = KIND_NOUN[type];
  const [name, setName] = useState(worker?.name ?? "");
  const [label, setLabel] = useState(worker?.label ?? "");
  const [enabled, setEnabled] = useState(worker?.enabled ?? true);
  const [values, setValues] = useState<Record<string, string>>(
    Object.fromEntries((worker?.properties ?? []).map((p) => [p.key, p.value]))
  );
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  //starts shut even when this worker already has extras, unlike the catalogue sections beside it.
  //Those open themselves because a named field is something you might edit; an arbitrary property
  //is something you went looking for, and the "N set" badge is enough to say it is there
  const [extrasOpen, setExtrasOpen] = useState(false);
  //non-null once a save has succeeded: the list of restart-required settings that changed
  const [restartNeeded, setRestartNeeded] = useState<string[] | null>(null);
  //what the gateway allows for a listener port, and where the next free one is. Null until the
  //answer arrives, and it stays null on a gateway that declares no band or cannot be reached
  const [portAdvice, setPortAdvice] = useState<PortAdvice | null>(null);
  /**
   * What this worker inherits when a field is left unset.
   *
   * <p>`outSms.default.<key>`, which `FireFloConfigurationHandler.get()` resolves for any worker key
   * it cannot find. Until this was fetched, an unset field showed the literal compiled into the
   * gateway and called it "the gateway's default" -- a snapshot of a Java file, and wrong for every
   * key an operator had set a default for. Empty when there are none, or when the panel cannot read
   * them at all; either way the fields fall back to the coded literal exactly as before.
   */
  const [gatewayDefaults, setGatewayDefaults] = useState<Record<string, string>>({});
  /**
   * What `app_config_key` says about each worker key's standing (gateway V1.88.0), by bare key, for
   * every key that is not simply current. Comes with the same answer as the defaults above, so it
   * costs no request of its own; empty on an older gateway, which reads as every key current.
   */
  const [keyStatuses, setKeyStatuses] = useState<Record<string, StatusVerdict>>({});

  useEffect(() => {
    let live = true;
    fetch("/api/control/gateway-settings", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((body) => {
        if (!live || !body?.data) {
          return;
        }
        const statuses: Record<string, StatusVerdict> = {};
        for (const row of ((body.registry?.rows ?? []) as ConfigKeyRow[])) {
          if (row.scope === "worker" && row.status && row.status !== "current") {
            statuses[row.key] = statusVerdict(row);
          }
        }
        setKeyStatuses(statuses);
        const prefix = "outSms.default.";
        const defaults: Record<string, string> = {};
        for (const [key, entry] of Object.entries(body.data as Record<string, { value: string | null; enabled: boolean }>)) {
          //a disabled row is one the gateway skips -- DbConfigPoller selects WHERE enabled -- so it
          //must not be shown here as the value being inherited
          if (key.startsWith(prefix) && entry.enabled && entry.value) {
            defaults[key.slice(prefix.length)] = entry.value;
          }
        }
        setGatewayDefaults(defaults);
      })
      .catch(() => undefined);
    return () => {
      live = false;
    };
  }, []);

  //Only for a NEW listener. Editing one must not have its port quietly moved underneath it, and a
  //vendor connection dials out rather than listening, so it has no port to allocate at all.
  useEffect(() => {
    if (type !== "smppserver") {
      return;
    }
    let live = true;
    fetch("/api/control/listener-ports", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((body) => {
        if (!live || !body?.data) {
          return;
        }
        const advice = body.data as PortAdvice;
        setPortAdvice(advice);
        //pre-fill rather than force: a port already typed, or one this listener already has, wins
        if (isNew && advice.suggested) {
          setValues((prev) => (prev["srv.port"] ? prev : { ...prev, "srv.port": String(advice.suggested) }));
        }
      })
      .catch(() => {
        //a listener can still be configured without the advice; the server checks it either way
      });
    return () => {
      live = false;
    };
  }, [type, isNew]);

  const portProblem = (() => {
    const typed = Number((values["srv.port"] ?? "").trim());
    if (!portAdvice || !values["srv.port"] || !Number.isInteger(typed) || typed === 0) {
      return null;
    }
    const taken = (portAdvice.used ?? []).filter((u) => u.name !== worker?.name).map((u) => u.port);
    return describePortProblem(typed, parsePortRange(portAdvice.range), taken);
  })();

  //refused rather than warned about, like the port: it goes into connection instructions as typed
  const hostProblem = type === "smppserver" ? publicHostProblem(values["srv.public.host"] ?? "") : null;
  //refused too: the gateway would treat it as no country and convert only '+' numbers, silently
  const countryProblem = type === "smppclient" ? recipientCountryProblem(values["dest.addr.country"] ?? "") : null;

  //what the worker had when the form opened, so a diff at save time is against the truth rather
  //than against whatever the form has been rebuilt from since
  const [original] = useState<Record<string, string>>(() =>
    Object.fromEntries((worker?.properties ?? []).map((p) => [p.key, p.value]))
  );
  const [storedSecrets] = useState<Set<string>>(
    () => new Set((worker?.properties ?? []).filter((p) => p.value === REDACTED).map((p) => p.key))
  );

  const properties = Object.entries(values)
    .filter(([, value]) => value.trim() !== "")
    .map(([key, value]) => ({ key, value }));
  //shown as you type rather than only on save: the point is to catch the mistake before it is made
  const warnings = millisecondWarnings(properties);

  //the exact complement of the catalogue, so nothing can appear in both places
  const extras = Object.entries(values).filter(([key]) => fieldFor(key) === null);

  function setValue(key: string, value: string) {
    setValues((prev) => ({ ...prev, [key]: value }));
  }

  function removeKey(key: string) {
    setValues((prev) => {
      const next = { ...prev };
      delete next[key];
      return next;
    });
  }

  /**
   * Which restart-required settings this save actually changed.
   *
   * <p>Computed rather than warned about per field, because a per-field tag on the twenty or so keys
   * that need a restart is noise on every form, every time. This says nothing at all until it has
   * something to say.
   */
  function restartedBy(): string[] {
    const keys = new Set([...Object.keys(original), ...Object.keys(values)]);
    return [...keys]
      .filter((key) => needsRestart(key))
      .filter((key) => (original[key] ?? "") !== (values[key] ?? ""))
      .map((key) => settingLabel(key).label)
      .sort();
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");
    const changed = restartedBy();
    try {
      const res = await fetch("/api/control/workers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, type, enabled, label, properties }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      if (changed.length && !isNew) {
        //stay on the page rather than navigating away, because this is the one moment the operator
        //can act on it
        setRestartNeeded(changed);
        return;
      }
      await onSaved();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setSaving(false);
    }
  }

  if (restartNeeded) {
    return (
      <Card className="border-warning">
        <CardHeader>
          <CardTitle>Saved</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <p>
            {restartNeeded.length === 1 ? "One setting does" : `${restartNeeded.length} settings do`}{" "}
            not reach a running {noun}. {name} keeps its current behaviour until it is restarted:
          </p>
          <ul className="list-inside list-disc text-muted-foreground">
            {restartNeeded.map((entry) => (
              <li key={entry}>{entry}</li>
            ))}
          </ul>
          <p className="text-xs text-muted-foreground">
            Everything else you changed takes effect within one poll interval.
            {onRestart && (type === KIND.vendor
              ? " Restarting drops the vendor's sessions and re-dials them."
              : " Restarting disconnects every bound client; they reconnect on the new settings. Messages in flight are kept.")}
          </p>
          <div className="flex flex-wrap gap-2">
            {onRestart && (
              <Button type="button" onClick={() => onRestart()}>Restart {name} now</Button>
            )}
            <Button type="button" variant={onRestart ? "outline" : "default"} onClick={() => onSaved()}>
              {onRestart ? "Later" : "Done"}
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-5">
      {/* the same chrome as the detail page this replaced: a back link, then one card whose header
          names the thing and carries its actions. Cancel is the back link too, so leaving the form
          looks like leaving any other page */}
      <button
        type="button"
        onClick={onCancel}
        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" /> {isNew ? `${noun[0].toUpperCase()}${noun.slice(1)}s` : worker.name}
      </button>

      <Card>
        <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
          <span className="text-base font-medium">{isNew ? `Add a ${noun}` : `Edit ${worker.name}`}</span>
          <Badge variant="outline">{noun}</Badge>
          {!isNew && worker.label && <span className="text-xs text-muted-foreground">{worker.label}</span>}
          <CardActions>
            <Button type="submit" size="sm" disabled={saving || !name || portProblem !== null || hostProblem !== null || countryProblem !== null}>
              {saving ? "Saving…" : isNew ? `Create ${noun}` : "Save changes"}
            </Button>
            <Button type="button" variant="outline" size="sm" onClick={onCancel} disabled={saving}>
              Cancel
            </Button>
          </CardActions>
        </CardHeader>
        <CardContent className="space-y-4 pt-3">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                disabled={!isNew}
                placeholder={type === "smppserver" ? "inbound" : "vendor1"}
                required
              />
              <p className="text-xs text-muted-foreground">
                {isNew
                  ? "Letters, digits, hyphen and underscore. No dots — the gateway looks it up by a property name that a dot would break."
                  : "The name identifies it to the gateway and cannot be changed; delete and recreate instead."}
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="label">Description</Label>
              <Input
                id="label"
                value={label ?? ""}
                onChange={(e) => setLabel(e.target.value)}
                placeholder="Optional — what this connection is for"
              />
            </div>
          </div>

          <label className="flex items-center gap-2 text-sm">
            <Checkbox checked={enabled} onChange={(e) => setEnabled(e.target.checked)} />
            Enabled
            <span className="text-xs text-muted-foreground">
              — when disabled it is stopped within one poll interval
            </span>
          </label>
        </CardContent>
      </Card>

      {/*
        "Other settings" rides in the advanced column rather than sitting alone at the foot of the
        form. It is the same kind of thing as the sections already there -- something most workers
        never open -- and as the last card on the page it read as a step in the flow rather than as
        the escape hatch it is. Collapsed by default for the same reason: an empty text box inviting
        an arbitrary property name is not what should greet someone editing a port number.
      */}
      <WorkerFields
        type={type}
        values={values}
        gatewayDefaults={gatewayDefaults}
        storedSecrets={storedSecrets}
        onChange={setValue}
        onClear={removeKey}
        problems={{
          ...(hostProblem ? { "srv.public.host": hostProblem } : {}),
          ...(countryProblem ? { "dest.addr.country": countryProblem } : {}),
        }}
        focus={focus}
        statuses={keyStatuses}
        extras={
          <DisclosureSection
            title="Other settings"
            set={extras.length}
            open={extrasOpen}
            onToggle={() => setExtrasOpen((current) => !current)}
          >
            <p className="text-xs text-muted-foreground">
              Anything else the gateway accepts, without the{" "}
              <code className="rounded bg-muted px-1 py-0.5">
                outSms.instance.{name || "<name>"}.
              </code>{" "}
              prefix — the gateway adds that itself. An unrecognised name is logged rather than
              rejected, so check the gateway log after adding one.
            </p>
            {extras.map(([key, value]) => (
              <div key={key} className={`flex items-end gap-2${keyStatuses[key]?.status === "retired" ? " opacity-60" : ""}`}>
                <div className="flex-1 space-y-1.5">
                  {/* the raw key stays visible here, subordinate to the name: anyone editing a
                      setting this unusual is exactly the person who needs to match it against
                      smsg.properties or the gateway log */}
                  <Label>
                    {settingLabel(key).label}
                    <span className="ml-1.5 font-normal text-muted-foreground">{key}</span>
                  </Label>
                  <Input value={value} disabled={keyStatuses[key]?.status === "retired"} onChange={(e) => setValue(key, e.target.value)} />
                  {/* the registry's word first (V1.88.0), the panel's own list of dead keys for a
                      gateway too old to carry one. Both say the same thing about the same keys */}
                  {keyStatuses[key]?.notice ? (
                    <p className="text-xs text-amber-600 dark:text-amber-400" data-key-status={keyStatuses[key].status}>
                      {keyStatuses[key].notice}
                      {DEAD_KEYS[key] ? ` ${DEAD_KEYS[key]}` : ""}
                    </p>
                  ) : DEAD_KEYS[key] && (
                    <p className="text-xs text-amber-600 dark:text-amber-400">{DEAD_KEYS[key]}</p>
                  )}
                </div>
                <Button type="button" variant="ghost" size="icon" onClick={() => removeKey(key)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
            <ExtraSettingAdder type={type} present={values} statuses={keyStatuses} onAdd={(key) => setValue(key, "")} />
          </DisclosureSection>
        }
      />

      <p className="text-xs text-muted-foreground">
        A setting left blank is not written, so the gateway falls back — first to the gateway-wide{" "}
        <code className="rounded bg-muted px-1 py-0.5">outSms.default.</code> value, then to the
        default compiled into it. A greyed-out value is whichever of those applies, and a field that
        says <em>inheriting</em> is showing a real gateway-wide setting rather than the compiled one.
        Set those under{" "}
        <Link href="/cp/gateway" className="underline underline-offset-2">
          Gateway settings
        </Link>
        .
      </p>

      <WarningCard warnings={warnings} />
      {/* the port is refused rather than warned about: the gateway will not bind it, so saving
          would write a listener that never starts */}
      <ErrorCard error={portProblem ?? error} />

      <p className="text-xs text-muted-foreground">
        Saving writes to the database. The gateway picks it up within one poll interval, or
        immediately if you use <strong>Apply now</strong>.
      </p>
    </form>
  );
}

/**
 * Adds a setting the catalogue has no field for.
 *
 * <p>Two refusals, both because the alternative fails silently. A key that already has a field would
 * appear twice with one of the two blank, and `validate()`'s duplicate check does not fire on that
 * — the blank one is dropped before the request is built and whichever survives wins by accident. A
 * dead key is worse: it is accepted, stored, loaded by the gateway and never read, and
 * `srv.defaultWindowSize` in particular is the one someone will type because it is in the README.
 */
function ExtraSettingAdder({
  type,
  present,
  statuses,
  onAdd,
}: {
  type: WorkerType;
  present: Record<string, string>;
  /** The registry's standing for each key that is not current; a retired one is refused here. */
  statuses: Record<string, StatusVerdict>;
  onAdd: (key: string) => void;
}) {
  const [key, setKey] = useState("");
  const [refusal, setRefusal] = useState("");

  function add() {
    const trimmed = key.trim();
    if (!trimmed) {
      return;
    }
    const field = fieldFor(trimmed);
    if (field) {
      const section = SECTIONS.find((s) => s.id === field.section);
      setRefusal(
        `${settingLabel(trimmed).label} already has a field, under ${section?.title ?? field.section}`
          + `${field.applies !== "both" && field.applies !== (type === "smppclient" ? "client" : "server")
            ? " — on the other kind of connection, though, so it does nothing here."
            : "."}`
      );
      return;
    }
    if (statuses[trimmed]?.status === "retired") {
      setRefusal(`${trimmed} is retired: the gateway no longer reads it, so setting it would have no effect.`
        + (DEAD_KEYS[trimmed] ? ` ${DEAD_KEYS[trimmed]}` : ""));
      return;
    }
    if (DEAD_KEYS[trimmed]) {
      setRefusal(`${trimmed} — ${DEAD_KEYS[trimmed]}`);
      return;
    }
    if (trimmed in present) {
      setRefusal(`${trimmed} is already in the list.`);
      return;
    }
    setRefusal("");
    onAdd(trimmed);
    setKey("");
  }

  return (
    <div className="space-y-1.5">
      <div className="flex items-end gap-2">
        <div className="flex-1 space-y-1.5">
          <Label htmlFor="extra">Add a setting</Label>
          <Input
            id="extra"
            value={key}
            onChange={(e) => { setKey(e.target.value); setRefusal(""); }}
            placeholder="e.g. kpi.fail.statuses"
            onKeyDown={(e) => {
              //Enter here must not submit the whole form
              if (e.key === "Enter") {
                e.preventDefault();
                add();
              }
            }}
          />
        </div>
        <Button type="button" variant="outline" onClick={add} disabled={!key.trim()}>
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      {refusal && <p className="text-xs text-amber-600 dark:text-amber-400">{refusal}</p>}
    </div>
  );
}
