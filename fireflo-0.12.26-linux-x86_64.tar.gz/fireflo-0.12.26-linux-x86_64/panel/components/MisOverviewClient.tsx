"use client";
import { PageHeader } from "@/components/ui/page-header";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import {
  Bar, CartesianGrid, Cell, ComposedChart, Line, Pie, PieChart, XAxis, YAxis,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { EmptyState } from "@/components/ui/empty-state";
import { TableInCard, THead, TH, TBody, TR, TD } from "@/components/ui/table";
import {
  ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig,
} from "@/components/ui/chart";
import { Outcome } from "./CdrCell";
import { formatTimestamp } from "@/lib/datetime";
import { count, money } from "@/lib/format";
import { dlrStateLabel, FINAL_STATE_LABELS, labelFor } from "@/lib/labels";

/**
 * What a customer sees when they sign in.
 *
 * <p>Before this the portal opened on a list of rows, which answers "what happened to message X" and
 * not "is my traffic healthy" — the question somebody actually has when they log in.
 *
 * <p><strong>The bars and the line measure different things on purpose.</strong> Bars are volume,
 * stacked delivered over failed so the height is what was sent; the line is the delivery rate on its
 * own axis. A line and bars in the same units would be one series drawn twice — the reason to combine
 * them is to see a day where volume doubled and the rate fell, which is a shape rather than a number.
 */

interface TrafficDay {
  day: string; sent: number; delivered: number; failed: number; pending: number; rate: number | null;
}
interface OutcomeSlice { outcome: string; messages: number }
interface RecentMessage {
  gatewayMsgId: string; submittedAt: string; destAddr: string | null;
  finalState: string | null; body: string | null;
}
interface FailedMessage extends RecentMessage {
  dlrState: number | null;
  errCode: string | null;
}
interface Overview {
  tiles: {
    sent: number; delivered: number; rate: number | null;
    spend: number; balance: number | null; currency: string | null;
  };
  traffic: TrafficDay[];
  outcomes: OutcomeSlice[];
  recent: RecentMessage[];
  failed: FailedMessage[];
  failedTotal: number;
  settling: boolean;
  range: string;
  /** When the series, tiles and outcomes were built; the lists and the balance are live. */
  asOf?: string;
  /** True when the last build failed and the figures are the previous build's. */
  stale?: boolean;
}

/** `HH:MM:SS` in the browser's zone, on a 24-hour clock. */
function asOfTime(iso: string): string {
  return new Date(iso).toLocaleTimeString(undefined, { hourCycle: "h23", hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

const RANGES = ["7d", "14d", "30d", "90d"] as const;

/**
 * No grow-in animation on the bars or the donut.
 *
 * <p>Not a taste call. In recharts 3.10 a `Bar` or `Pie` renders **no shape element at all** until
 * its entry animation has run a frame — so anywhere `requestAnimationFrame` does not fire, the chart
 * is not a chart that has not animated yet, it is an empty pair of axes. A background tab is the
 * common case; it is also how this was found, in a browser pane that was not compositing.
 *
 * <p>The line is unaffected, which is what makes the failure so quiet: the page looks like it
 * rendered, with a delivery-rate line floating over nothing.
 */
const ANIMATION = { isAnimationActive: false } as const;

/**
 * One colour per outcome, shared by the bars and the donut.
 *
 * <p>Shared deliberately: the same fact in two charts on one screen must be the same colour, or the
 * reader has to learn the page twice. Semantic rather than decorative — delivered is the accent,
 * failed is the warning, pending is neutral because it is not a verdict yet.
 */
const chartConfig = {
  //`--color-chart-N`, not `--chart-N`. This theme names them with the prefix, and a bare
  //`var(--chart-1)` resolves to nothing at all -- an SVG fill of "none", which is an invisible chart
  //rather than an error anybody notices
  delivered: { label: "Delivered", color: "var(--color-chart-1)" },
  //"Failed" covers a carrier's failure and the platform's own refusal alike: the figures come from
  //the gateway's usage summaries, which do not tell the two apart. The failures list names each
  //message's own reason
  failed: { label: "Failed", color: "var(--color-destructive)" },
  pending: { label: "Awaiting receipt", color: "var(--color-muted-foreground)" },
  rate: { label: "Delivery rate", color: "var(--color-chart-2)" },
} satisfies ChartConfig;

export function MisOverviewClient() {
  const [data, setData] = useState<Overview | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [range, setRange] = useState<string>("14d");

  const load = useCallback(async (window: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/mis/overview?range=${window}`, { cache: "no-store" });
      const body = await res.json();
      if (!res.ok) {
        throw new Error(body?.error ?? `Request failed (${res.status})`);
      }
      setData(body.data as Overview);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Traffic could not be read.");
      setData(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load(range);
  }, [load, range]);

  const tiles = data?.tiles;
  //an account that has never sent gets a sentence, not four zeroes and three empty axes. "Nothing
  //yet" and "something is broken" look identical when a dashboard renders its skeleton either way
  const empty = !loading && !error && data != null && tiles!.sent === 0;

  return (
    <>
      <PageHeader
        title="Overview"
        description="Your traffic and what happened to it"
        actions={
          <div className="flex flex-wrap gap-1" role="group" aria-label="Period">
            {RANGES.map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => setRange(r)}
                aria-pressed={range === r}
                //min-h-11 below md: for the same reason the shared primitives carry it -- these are
                //hand-rolled and so miss the Button treatment entirely. They measured 26px by 36,
                //which is not a target a thumb hits, and never was: at the old 20px root they were
                //32px, still short. Only the desktop size shrinks back.
                className={`inline-flex min-h-11 items-center justify-center rounded-md border px-3 text-xs md:min-h-0 md:px-2.5 md:py-1 ${
                  range === r
                    ? "border-foreground/30 font-medium"
                    : "border-border text-muted-foreground hover:text-foreground"
                }`}
              >
                {r}
              </button>
            ))}
          </div>
        }
      />

      {error && (
        <Card><CardContent className="py-6 text-sm text-destructive">{error}</CardContent></Card>
      )}

      {/* the figures are built once a minute per account and served from memory; the time says
          when. Rendered only once data has arrived, so the server never paints a clock */}
      {data?.asOf && !empty && (
        <p className="-mt-2 text-xs text-muted-foreground" data-testid="overview-as-of">
          as of <span className="tabular-nums" suppressHydrationWarning>{asOfTime(data.asOf)}</span>
          {data.stale && <span className="ml-2">(stale: the latest read failed, showing the previous figures)</span>}
        </p>
      )}

      {empty ? (
        <EmptyState>
          <p className="text-foreground">No messages in this period.</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Once you start sending, this page shows what went out and what happened to it. The
            <Link href="/playground" className="mx-1 underline">API playground</Link>
            is the quickest way to send your first.
          </p>
        </EmptyState>
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Tile label="Sent" value={tiles ? count(tiles.sent) : "—"} />
            {/* not `percent()` from lib/format: that one takes a FRACTION, and these rates are
                already percentages because the chart's right-hand axis is 0-100. Handing it 98.4
                would render 9840.0% */}
            <Tile
              label="Delivered"
              value={tiles?.rate == null ? "—" : `${tiles.rate.toFixed(1)}%`}
              note={tiles && tiles.rate == null ? "no receipts yet" : undefined}
            />
            <Tile label="Spend" value={tiles ? money(tiles.spend) : "—"} />
            <Tile
              label="Balance"
              value={tiles?.balance == null ? "—" : money(tiles.balance)}
              //null is not zero: it means credit is not enforced for this account, and showing 0
              //would read as "you are out of money" to somebody who has no limit at all
              note={tiles && tiles.balance == null ? "not enforced" : "now"}
            />
          </div>

          {data?.settling && (
            <p className="text-xs text-muted-foreground">
              Some of this period has no delivery receipt yet, so the rate is still moving. The
              gateway closes anything without one after its expiry deadline.
            </p>
          )}

          {/* minmax(0, …) rather than a bare `fr`: a recharts container measures its parent and a
              plain `1.55fr` track has an automatic minimum of its content, so the chart's width and
              the track's width chase each other outward. The symptom is not a wide chart -- it is
              the whole page growing sideways and the sidebar beside it going full width */}
          <div className="grid gap-4 lg:grid-cols-[minmax(0,1.55fr)_minmax(0,1fr)]">
            <Card className="min-w-0">
              <CardHeader>
                <CardTitle>Traffic sent</CardTitle>
                <p className="text-xs text-muted-foreground">
                  Bars: messages per day · Line: delivery rate
                </p>
              </CardHeader>
              <CardContent>
                {loading && !data ? (
                  <div className="h-64" />
                ) : (
                  <ChartContainer config={chartConfig} className="h-64 w-full">
                    <ComposedChart data={data?.traffic ?? []} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--color-border)" />
                      <XAxis
                        dataKey="day"
                        tickLine={false}
                        axisLine={false}
                        tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                        tickFormatter={(v: string) => v.slice(5)}
                        interval="preserveStartEnd"
                      />
                      <YAxis
                        yAxisId="volume"
                        tickLine={false}
                        axisLine={false}
                        tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                        width={40}
                        allowDecimals={false}
                      />
                      {/* its own axis, fixed at 0-100. Sharing the volume axis would flatten the rate
                          into the baseline the moment a day passed a hundred messages */}
                      <YAxis
                        yAxisId="rate"
                        orientation="right"
                        domain={[0, 100]}
                        tickLine={false}
                        axisLine={false}
                        tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                        width={36}
                        tickFormatter={(v: number) => `${v}%`}
                      />
                      <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
                      {/* {@link ANIMATION} — a Bar with the default animation draws nothing at all
                          until a frame is painted */}
                      <Bar {...ANIMATION} yAxisId="volume" dataKey="delivered" stackId="v" fill={chartConfig.delivered.color} radius={[0, 0, 2, 2]} />
                      <Bar {...ANIMATION} yAxisId="volume" dataKey="failed" stackId="v" fill={chartConfig.failed.color} radius={[2, 2, 0, 0]} />
                      {/* connectNulls={false}: a day with nothing sent has no rate, and joining
                          across it would draw a line through a gap that never happened */}
                      <Line
                        yAxisId="rate"
                        dataKey="rate"
                        stroke={chartConfig.rate.color}
                        strokeWidth={2}
                        dot={false}
                        connectNulls={false}
                      />
                    </ComposedChart>
                  </ChartContainer>
                )}
              </CardContent>
            </Card>

            <Card className="min-w-0">
              <CardHeader>
                <CardTitle>Results</CardTitle>
                <p className="text-xs text-muted-foreground">Every message in the period</p>
              </CardHeader>
              <CardContent>
                <ChartContainer config={chartConfig} className="h-64 w-full">
                  <PieChart>
                    <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
                    <Pie
                      data={(data?.outcomes ?? []).filter((o) => o.messages > 0)}
                      {...ANIMATION}
                      dataKey="messages"
                      nameKey="outcome"
                      innerRadius={52}
                      outerRadius={78}
                      paddingAngle={1}
                    >
                      {(data?.outcomes ?? []).filter((o) => o.messages > 0).map((o) => (
                        <Cell
                          key={o.outcome}
                          fill={chartConfig[o.outcome as keyof typeof chartConfig]?.color ?? "var(--muted)"}
                        />
                      ))}
                    </Pie>
                  </PieChart>
                </ChartContainer>
                <ul className="mt-2 space-y-1">
                  {(data?.outcomes ?? []).map((o) => (
                    <li key={o.outcome} className="flex items-center gap-2 text-xs">
                      <span
                        className="h-2 w-2 rounded-full"
                        style={{ background: chartConfig[o.outcome as keyof typeof chartConfig]?.color }}
                      />
                      <span className="flex-1 text-muted-foreground">
                        {chartConfig[o.outcome as keyof typeof chartConfig]?.label ?? o.outcome}
                      </span>
                      <span className="tabular-nums">{count(o.messages)}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* sibling cards, never one card split: `ui/card.tsx` states that a Card inside a Card is
              invisible in dark mode, where --color-card sits 2% from --color-background.
              minmax(0,…) rather than grid-cols-2 for the reason the charts row above carries — a
              bare `1fr` takes an automatic minimum from its content, and a long message body would
              then push the track, and the page, sideways */}
          <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
            <MessagePanel
              title="Latest messages"
              rows={data?.recent ?? []}
              empty="Nothing in this period."
              loading={loading && !data}
            />
            <MessagePanel
              title="Recent failures"
              rows={data?.failed ?? []}
              total={data?.failedTotal}
              //the one empty state on this page that is good news, and it has to say so: an empty
              //list beside a full one reads as a broken panel rather than as a clean period
              empty="Nothing failed in this period."
              loading={loading && !data}
            />
          </div>
        </>
      )}
    </>
  );
}

/**
 * One half of the pair at the foot of the dashboard.
 *
 * <p>One component for both panels rather than two, so a reader comparing "latest" against "recent
 * failures" is comparing the same columns in the same order — the two sit side by side and any
 * difference in shape between them would read as a difference in the data.
 *
 * <p><strong>Three columns and a spanning line, not four columns.</strong> Half of the content
 * column is about 314px at the `lg` breakpoint with the portal's own rail expanded, which is
 * narrower than the phone this list was originally designed around. So the identifier, the time and
 * the outcome share a row and the fourth fact — the message on the left, the reason on the right —
 * gets a line of its own. Full width, that gives a proper header row and aligned columns; at 375px
 * it degrades to what was there before.
 *
 * @param total how many matched in the whole range, when that is more than is shown. Absent on the
 *     latest panel, where "6 of 4,318" would be noise — that one is a sample by construction
 */
function MessagePanel({ title, rows, total, empty, loading }: {
  title: string;
  rows: (RecentMessage | FailedMessage)[];
  total?: number;
  empty: string;
  loading: boolean;
}) {
  return (
    <Card className="min-w-0">
      <CardHeader className="flex-row flex-wrap items-baseline gap-2 space-y-0">
        <CardTitle>{title}</CardTitle>
        <span className="ml-auto flex items-baseline gap-3 text-xs text-muted-foreground">
          {total != null && total > rows.length && (
            <span className="tabular-nums">{count(rows.length)} of {count(total)}</span>
          )}
          <Link href="/messages" className="underline">All messages</Link>
        </span>
      </CardHeader>
      <CardContent>
        {rows.length ? (
          <TableInCard>
            <THead>
              <tr>
                <TH>To</TH>
                <TH>Sent</TH>
                <TH>{isFailure(rows[0]) ? "Why" : "Outcome"}</TH>
              </tr>
            </THead>
            {/* one tbody per message, ruled as a unit, so the pair of rows reads as one message */}
            {rows.map((m) => (
              <TBody key={m.gatewayMsgId} className="border-b border-border last:border-0">
                <TR className="border-0">
                  <TD className="font-mono">{m.destAddr ?? "—"}</TD>
                  {/* deliberately NOT whitespace-nowrap, which is what the wide tables use. A
                      formatted timestamp is ~150px of a column that has 283px to spend at the lg
                      breakpoint with the portal's rail out, and holding it on one line made the
                      table wider than its own card. Wrapping to two lines costs no height, because
                      the row below it is already there */}
                  <TD muted className="tabular-nums" suppressHydrationWarning>
                    {formatTimestamp(m.submittedAt)}
                  </TD>
                  <TD>
                    {/* compact: the reason is on the line below, and repeating the error code
                        inside the badge wraps a cell this narrow */}
                    <Outcome row={m} compact />
                  </TD>
                </TR>
                <TR className="border-0">
                  <TD colSpan={3} muted className="pt-0 text-xs">
                    {isFailure(m) ? reasonFor(m) : (m.body ?? "No message text recorded")}
                  </TD>
                </TR>
              </TBody>
            ))}
          </TableInCard>
        ) : (
          <p className="py-2 text-xs text-muted-foreground">{loading ? "Loading…" : empty}</p>
        )}
      </CardContent>
    </Card>
  );
}

function isFailure(row: RecentMessage | FailedMessage): row is FailedMessage {
  return "dlrState" in row;
}

/**
 * Why a message did not arrive, in as much English as the record supports.
 *
 * <p>The receipt state first, because `DLR_STATES` turns it into a sentence — "Undeliverable", "The
 * carrier gave up before delivering" — where `err_code` is a vendor-specific string with no
 * catalogue anywhere in this panel. The code goes after it, verbatim, because it is the thing a
 * customer quotes when they raise it with us.
 *
 * <p><strong>Both are null more often than they are set</strong>, and that is not a gap in the
 * record: a message the platform refused never reached a carrier, so no carrier had anything to
 * say, and a message the sweeper expired is by definition one nothing was ever reported for. Those
 * fall back to the long form of the outcome, which is the sentence the badge above is the short
 * form of — so the line always says something, and the two together read as one statement.
 */
function reasonFor(m: FailedMessage): string {
  const parts: string[] = [];
  if (m.dlrState != null) {
    parts.push(dlrStateLabel(m.dlrState));
  }
  if (m.errCode) {
    parts.push(`error ${m.errCode}`);
  }
  return parts.length ? parts.join(" · ") : labelFor(FINAL_STATE_LABELS, m.finalState);
}

function Tile({ label, value, note }: { label: string; value: string; note?: string }) {
  return (
    <Card className="min-w-0">
      <CardContent className="py-4">
        <p className="text-2xs font-semibold uppercase tracking-wide text-muted-foreground">{label}</p>
        <p className="mt-1 text-2xl font-semibold tabular-nums">{value}</p>
        {note && <p className="text-xs text-muted-foreground">{note}</p>}
      </CardContent>
    </Card>
  );
}
