"use client";
import { useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { Activity, AlertTriangle, Database, Layers, Radio, Signpost } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { HealthStrip } from "./CardBits";
import { Badge } from "@/components/ui/badge";
import { StatCard } from "./StatCard";
import { APP_VERSION } from "./FireFloMark";
import { schemaPairing, versionPairing } from "@/lib/version-pairing";
import { count } from "@/lib/format";
import { tpsSummary, tpsUtilisation, type Health, type HealthWorker as Worker } from "@/lib/health-types";
import { SessionBrowser } from "./SessionBrowser";
import { KIND, KIND_LABEL, type WorkerType } from "@/lib/worker-types";
import { formatClockTime } from "@/lib/datetime";


const REFRESH_MS = 5_000;

export function HealthClient() {
  const [data, setData] = useState<Health | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    async function load() {
      try {
        const res = await fetch("/api/control/health", { cache: "no-store" });
        const json = await res.json();
        if (!alive) return;
        if (!res.ok) {
          setError(json?.error ?? `Request failed (${res.status})`);
        } else {
          setData(json.data as Health);
          setError("");
        }
      } catch (err) {
        if (alive) setError(err instanceof Error ? err.message : "Request failed");
      } finally {
        if (alive) setLoading(false);
      }
    }

    load();
    //faster than the historical pages: this is a counter you watch, not a report you read
    let timer: ReturnType<typeof setInterval> | null = setInterval(load, REFRESH_MS);
    const onVisibility = () => {
      if (document.hidden) {
        if (timer) clearInterval(timer);
        timer = null;
      } else if (!timer) {
        load();
        timer = setInterval(load, REFRESH_MS);
      }
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      alive = false;
      if (timer) clearInterval(timer);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, []);

  const pairing = versionPairing(APP_VERSION, data?.version);
  const schema = schemaPairing(data?.schema_version);

  return (
    <>
      <PageHeader
        title="Health"
        description="Read from the running gateway's memory, not the database. It is gone when the process restarts."
        actions={
          data && (
            <span className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground">
              {/*the pair, side by side. The panel's version is a CLAIM about which gateway release it
                 was built for; until the gateway published its own there was no way to check it, and
                 a stale panel build looked exactly like a current one*/}
              <span>
                panel {APP_VERSION || "unknown"} · gateway {data.version?.trim() || "not reported"}
              </span>
              <span suppressHydrationWarning>
                {formatClockTime(data.observed_at)}
              </span>
            </span>
          )
        }
      />

      {/*only when they actually disagree. A matched pair says nothing, and neither does a gateway
         too old to report a version -- warning about that would train people past this line*/}
      {pairing.verdict === "mismatched" && <HealthStrip tone="warning">{pairing.message}</HealthStrip>}
      {/* the same rule for the schema: an older database is the fault that breaks the panel's
         queries, a newer one is only worth knowing, and a gateway that reports none is left alone */}
      {schema.message && (
        <HealthStrip tone={schema.verdict === "older" ? "destructive" : "warning"}>{schema.message}</HealthStrip>
      )}

      {error && <HealthStrip tone="destructive">{error}</HealthStrip>}

      {/* 1, 2, 3 columns -- chosen because every one of them divides six, so a sixth card fills the
          last row instead of sitting on it alone. The old lg:grid-cols-4 stranded the fifth card,
          and four divides six no better than it divides five.

          Deliberately NOT `auto-fit` with a min width, which is the obvious way to make a grid
          "adjustable" and is wrong here: it picks the column count from the container, so a 1280px
          desktop gets five tracks and one card alone on row two -- exactly the thing being fixed.
          A fixed small set of counts is less clever and always even.

          Adding a seventh card means revisiting this line; six is what it is tuned for. */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard
          title="Router queue"
          value={count(data?.router_queue ?? 0)}
          hint="Waiting to be routed"
          icon={Layers}
          loading={loading}
          error={error}
        />
        <StatCard
          title="Awaiting receipt"
          value={count(data?.awaiting_receipt ?? 0)}
          hint={data ? (data.dlr_store_persistent ? "Store survives restart" : "In memory only") : undefined}
          icon={Activity}
          loading={loading}
          error={error}
        />
        <StatCard
          title="Records written"
          value={count(data?.cdr?.written ?? 0)}
          hint={data?.cdr ? `sink: ${data.cdr.sink}` : undefined}
          icon={Database}
          loading={loading}
          error={error}
        />
        {/* NOT the same backlog as the router queue above. The consumer stops pulling once the
            in-process queue passes the highwater mark, so a broker backlog shows up here and as a
            flat router queue -- which is exactly why one number could never have covered both */}
        <StatCard
          title="Waiting on the broker"
          value={brokerValue(data?.broker)}
          hint={brokerHint(data?.broker)}
          icon={Layers}
          loading={loading}
          error={error}
          tone={data?.broker && !data.broker.connected ? "negative" : "default"}
        />
        {/* a failed batch is never retried, so this is lost billing data rather than a transient */}
        <StatCard
          title="Records lost"
          value={count(data?.cdr?.failed ?? 0)}
          hint={data?.cdr?.failed ? "Failed writes are not retried" : "None"}
          icon={AlertTriangle}
          loading={loading}
          error={error}
          tone={(data?.cdr?.failed ?? 0) > 0 ? "negative" : "default"}
        />
      </div>

      {/* three of the cards above are depths, and a depth is where a diagnosis stops. This is the
          way through to whose messages they are, put here because here is where you notice */}
      <p className="text-sm text-muted-foreground">
        A queue deeper than you expected?{" "}
        <Link href="/cp/queues" className="font-medium text-primary hover:underline">
          See what is waiting in it
        </Link>{" "}
        — account, destination and retry count, per message.
      </p>

      {/* only when there is something to say. A card reading "no routing problems" on every load
          is a card people stop seeing, and this one has to be noticed the one time it appears */}
      {!!data?.routing_warnings?.length && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Signpost className="h-4 w-4 text-amber-500" />
              Routing tables
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {/* none of these stop the gateway, which is exactly why they need saying: the traffic
                they lose is dropped twenty attempts later with nothing pointing back here */}
            {data.routing_warnings.map((w) => (
              <div key={`${w.table}:${w.cause}`} className="flex flex-wrap items-baseline gap-2">
                <Link
                  href="/cp/routing"
                  className="font-mono text-sm font-medium text-primary hover:underline"
                >
                  {w.table}
                </Link>
                <Badge variant="outline" className="font-mono text-xs">{w.cause}</Badge>
                <p className="w-full text-sm text-muted-foreground">{w.detail}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Radio className="h-4 w-4 text-muted-foreground" />
            Connections
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!data?.workers.length ? (
            <p className="py-6 text-center text-sm text-muted-foreground">
              {loading ? "Loading…" : error ? "Unavailable" : "No workers running"}
            </p>
          ) : (
            <div className="space-y-2">
              {data.workers.map((w) => (
                <WorkerRow key={w.name} worker={w}>
                  <div className="flex min-w-0 items-center gap-2">
                    <StateBadge worker={w} />
                    <span className="truncate text-sm font-medium">{w.name}</span>
                    <span className="text-sm text-muted-foreground">{KIND_LABEL[w.type as WorkerType] ?? w.type}</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm tabular-nums text-muted-foreground">
                    {w.bound != null && (
                      <span title="Bound sessions, and how many can transmit">
                        binds <span className="text-foreground">{w.bound}</span>
                        {w.bound_transmittable != null && w.bound_transmittable !== w.bound && (
                          <span> ({w.bound_transmittable} tx)</span>
                        )}
                      </span>
                    )}
                    <span>
                      queue <span className="text-foreground">{count(w.queue_depth)}</span>
                    </span>
                    {w.retry_queue_depth > 0 && <span>retry {count(w.retry_queue_depth)}</span>}
                    <TpsCell worker={w} windowSeconds={data.tps_window_seconds} />
                    {w.submitted != null && (
                      <span title="submit_sm on the current sessions; restarts at zero on rebind">
                        submitted <span className="text-foreground">{count(w.submitted)}</span>
                      </span>
                    )}
                  </div>
                </WorkerRow>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
}

/**
 * One worker, with its sessions behind a disclosure when it has any.
 *
 * <p>A native `<details>` rather than `useState`: this list re-renders every five seconds, and
 * `<details>` keeps its own open state across a re-render, so an open breakdown does not snap shut
 * under the poll. A worker with no sessions keeps the plain row, so nothing invites a click that
 * would reveal an empty box.
 */
function WorkerRow({ worker, children }: { worker: Worker; children: ReactNode }) {
  const row = "flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border px-3 py-2.5";
  if (!worker.sessions?.length) {
    return <div className={row}>{children}</div>;
  }
  return (
    <details className="rounded-lg border border-border">
      <summary className={`${row} cursor-pointer border-0`}>{children}</summary>
      <div className="border-t border-border px-3 py-2">
        {/* no `worker` prop for the disconnect: this page is somewhere to read from, and a
            destructive button on a five-second poll is a button that moves under the cursor.
            The browser fetches its own page, so the search box survives the poll that redraws
            everything around it */}
        <SessionBrowser
          worker={worker.name}
          type={worker.type === KIND.server ? KIND.server : KIND.vendor}
          canDisconnect={false}
          total={worker.sessions_total ?? worker.sessions?.length}
        />
      </div>
    </details>
  );
}

/**
 * What it is pushing, next to what it is allowed to push.
 *
 * <p>Measured in the foreground and the ceiling muted: the eye should land on what is happening
 * rather than on what was configured. Utilisation goes in the tooltip — the most useful derived
 * number and the least deserving of a column.
 */
function TpsCell({ worker, windowSeconds }: { worker: Worker; windowSeconds?: number | null }) {
  const summary = tpsSummary(worker);
  if (!summary) {
    return null;
  }
  const used = tpsUtilisation(worker);
  const title = [
    worker.tps_measured != null && windowSeconds != null
      ? `Averaged over the last ${windowSeconds}s`
      : null,
    used != null ? `${Math.round(used * 100)}% of the configured ceiling` : null,
  ]
    .filter(Boolean)
    .join(" — ");
  return (
    <span title={title || undefined}>
      {/* != null so a measured 0 still renders in the foreground: bound and sending nothing is
          the reading worth noticing, and truthiness would grey it out */}
      {worker.tps_measured != null ? (
        <span className="text-foreground">{worker.tps_measured} tps</span>
      ) : null}
      {worker.tps_measured != null && worker.tps_limit != null && " of "}
      {worker.tps_limit != null && <span>≤{worker.tps_limit}{worker.tps_measured == null && " tps"}</span>}
    </span>
  );
}

/**
 * @returns the depth, or a word — never 0, which would claim an empty broker where there may be no
 *     broker at all or one that is not answering
 */
function brokerValue(broker: Health["broker"]): string {
  if (!broker) {
    return "—";
  }
  if (!broker.connected || broker.messages == null) {
    return "Unknown";
  }
  return count(broker.messages);
}

function brokerHint(broker: Health["broker"]): string | undefined {
  if (!broker) {
    return "No message broker configured";
  }
  if (!broker.connected) {
    //the important one: submissions are still being accepted, into a queue that a restart empties
    return "Broker unreachable — submissions are going to memory";
  }
  const consumers = broker.consumers ?? 0;
  if (consumers === 0) {
    return `${broker.queue ?? "queue"} — nothing is draining it`;
  }
  return `${broker.queue ?? "queue"} · ${count(consumers)} consumer${consumers === 1 ? "" : "s"}`;
}

function StateBadge({ worker }: { worker: Worker }) {
  //accepting is the worker's own composite, so it is the honest headline; the reason goes beside it
  if (worker.accepting) return <Badge variant="success">accepting</Badge>;
  if (worker.suspended_automatically) return <Badge variant="destructive">no binds</Badge>;
  if (worker.suspended_manually) return <Badge variant="outline">suspended</Badge>;
  if (worker.paused) return <Badge variant="outline">paused</Badge>;
  return <Badge variant="destructive">not accepting</Badge>;
}
