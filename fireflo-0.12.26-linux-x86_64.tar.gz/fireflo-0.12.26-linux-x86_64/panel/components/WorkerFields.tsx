"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Eye, EyeOff, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { fallbackFor } from "@/lib/setting-resolution";
import { DisclosureSection } from "./DisclosureSection";
import { TlvTokenInput } from "./TlvTokenInput";
import { useTlvDefinitions } from "./useTlvDefinitions";
import { settingLabel, type SettingKey } from "@/lib/labels";
import {
  SETTING_FIELDS,
  type SectionId,
  type SettingField,
  fieldsForType,
} from "@/lib/setting-fields";
import { REDACTED, type WorkerType } from "@/lib/worker-types";
import type { StatusVerdict } from "@/lib/config-key-registry";
import type { TlvDefinition } from "@/lib/tlv-catalogue";
import { cn } from "@/lib/utils";

/**
 * Every setting this panel has a name for, grouped and given a control that matches its type.
 *
 * <p><strong>Nothing here seeds `values`.</strong> A control reads `values[key] ?? ""` and a key
 * only enters the map when someone touches it. That was incidental when the form had eleven fields;
 * at fifty-eight it is load-bearing, because seeding would write fifty-eight rows for a worker that
 * had three and would collapse the boolean tri-state the moment the form opened.
 *
 * <p><strong>An empty value is not written at all</strong>, which is why "unset" and "set to false"
 * have to be distinguishable in the interface: several settings default to true in the gateway, so
 * absent and false are opposite answers. Booleans therefore always store the literal `"true"` or
 * `"false"`, and **Use default** is the only way back to absent.
 */
export function WorkerFields({
  type,
  values,
  gatewayDefaults,
  storedSecrets,
  onChange,
  onClear,
  problems = {},
  extras,
  focus,
  statuses = {},
}: {
  type: WorkerType;
  values: Record<string, string>;
  /**
   * `outSms.default.<key>` values, by bare key.
   *
   * <p>What this worker inherits where it sets nothing itself. Three comments in this repository
   * used to say the panel could not read these and guessed the coded literal instead; it can, and
   * the guess was wrong for every key an operator had set a default for.
   */
  gatewayDefaults: Record<string, string>;
  /** Keys the server says already hold a secret, so "Keep the stored one" can be offered. */
  storedSecrets: Set<string>;
  onChange: (key: string, value: string) => void;
  onClear: (key: string) => void;
  /** Why a field's value cannot be saved, by key: shown under that field, where the eye already is. */
  problems?: Record<string, string>;
  /**
   * Rendered last in the advanced column. This is where the free-form "any other property" editor
   * goes: it is the same kind of thing as the sections beside it -- something most workers never
   * open -- but it is built from the worker's own extra keys rather than from the field catalogue,
   * so it is owned by the caller and merely placed here.
   */
  extras?: React.ReactNode;
  /** A section to open and scroll to on arrival, for a link that names the setting to change. */
  focus?: SectionId;
  /**
   * What `app_config_key` says about each key's standing (gateway V1.88.0), by bare key. A retired
   * key renders greyed and disabled; a deprecated one names its successor. Empty on an older gateway,
   * which reads as every key current.
   */
  statuses?: Record<string, StatusVerdict>;
}) {
  const groups = useMemo(() => fieldsForType(type), [type]);
  const side = type === "smppclient" ? "client" : "server";
  //one fetch for the whole form rather than one per TLV row. Degrades to [] on failure, so a
  //definitions outage costs the annotations and nothing else
  const { definitions, suggested } = useTlvDefinitions();

  //computed once, from the worker as it was loaded: a section holding configuration someone already
  //set must not start collapsed, or the disclosure becomes a way to lose it
  const [open, setOpen] = useState<Set<SectionId>>(() => {
    const initial = new Set<SectionId>();
    for (const { section, keys } of groups) {
      if (section.essential) {
        continue;
      }
      if (keys.some((key) => isSet(values[key]))) {
        initial.add(section.id);
      }
    }
    //TLS and PROXY are worth opening when they are switched on, even with nothing else set
    if (values["srv.tls.enabled"] === "true") {
      initial.add("tls");
    }
    if (values["srv.proxy.enabled"] === "true") {
      initial.add("proxy");
    }
    if (focus) {
      initial.add(focus);
    }
    return initial;
  });

  //once, after the section has rendered open
  useEffect(() => {
    if (focus) {
      document.getElementById(`section-${focus}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [focus]);

  function toggle(id: SectionId) {
    setOpen((current) => {
      const next = new Set(current);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  }

  const essentials = groups.filter((g) => g.section.essential);
  const advanced = groups.filter((g) => !g.section.essential);

  const row = (key: SettingKey) => (
    <SettingRow
      key={key}
      settingKey={key}
      value={values[key]}
      inherited={gatewayDefaults[key]}
      stored={storedSecrets.has(key)}
      side={side}
      definitions={definitions}
      suggested={suggested}
      onChange={onChange}
      onClear={onClear}
      problem={problems[key]}
      status={statuses[key]}
    />
  );

  const rows = (keys: SettingKey[]) => {
    //a key that sits under another goes in that key's cell, so the pair cannot be split by the grid
    const under = (host: SettingKey) => keys.filter((key) => SETTING_FIELDS[key].under === host);
    return (
      //xl rather than sm: inside a half-width column on a tablet, sm:grid-cols-2 would give two
      //quarter-width fields
      <div className="grid gap-4 xl:grid-cols-2">
        {keys
          .filter((key) => {
            const host = SETTING_FIELDS[key].under;
            return host === undefined || !keys.includes(host);
          })
          .map((key) => {
            const below = under(key);
            return below.length === 0 ? row(key) : (
              <div key={key} className="space-y-3">
                {row(key)}
                {below.map(row)}
              </div>
            );
          })}
      </div>
    );
  };

  //3/2 rather than an even split: the right column holds collapsed disclosure headers -- a title
  //and an "N set" badge -- while the left holds the settings whose field rows go two-up at `xl`.
  //
  //This used to cite the account page as its source. That page is tabs now, and each tab picks the
  //grid its own content wants, so there is no single "account page grid" left to point at

  return (
    <div className="grid items-start gap-4 md:grid-cols-5">
      <div className="min-w-0 space-y-4 md:col-span-3">
        {essentials.map(({ section, keys }) => (
          <Card key={section.id}>
            <CardHeader>
              <CardTitle>{section.title}</CardTitle>
              {section.note && (
                <CardDescription>{section.note}</CardDescription>
              )}
            </CardHeader>
            <CardContent>{rows(keys)}</CardContent>
          </Card>
        ))}
      </div>

      <div className="min-w-0 space-y-3 md:col-span-2">
        {advanced.map(({ section, keys }) => (
          <DisclosureSection
            key={section.id}
            id={`section-${section.id}`}
            title={section.title}
            set={keys.filter((key) => isSet(values[key])).length}
            open={open.has(section.id)}
            onToggle={() => toggle(section.id)}
            note={section.note}
          >
            {rows(keys)}
          </DisclosureSection>
        ))}
        {extras}
      </div>
    </div>
  );
}

/**
 * Whether a key counts as configured.
 *
 * <p>The empty string is not: `saveWorker` skips it, so it is stored nowhere and the gateway falls
 * back to its own default. Treating it as set would put a "1 set" badge on a section holding a field
 * someone had just emptied.
 */
function isSet(value: string | undefined): boolean {
  return value != null && value !== "";
}

/**
 * Clears a setting back to unset.
 *
 * <p>One component so it cannot drift, and so there is one place holding the rule that it must never
 * be rendered inside a `<label>`.
 */
function UseDefault({ onClick, className }: { onClick: () => void; className?: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn("text-xs font-normal text-primary hover:underline", className)}
    >
      Use default
    </button>
  );
}

/** Whether a field's control wants the full width of its section. */
function isWide(field: SettingField): boolean {
  const kind = field.widget.kind;
  return kind === "list" || kind === "pairs" || kind === "pattern";
}

function SettingRow({
  settingKey,
  value,
  inherited,
  stored,
  side,
  definitions,
  suggested,
  onChange,
  onClear,
  problem,
  status,
}: {
  settingKey: SettingKey;
  value: string | undefined;
  /** `outSms.default.<key>`, when the gateway has one. What this field falls back to. */
  inherited: string | undefined;
  stored: boolean;
  side: "client" | "server";
  definitions: readonly TlvDefinition[];
  suggested: Record<number, boolean>;
  onChange: (key: string, value: string) => void;
  onClear: (key: string) => void;
  problem?: string;
  status?: StatusVerdict;
}) {
  const field = SETTING_FIELDS[settingKey];
  const { label, hint } = settingLabel(settingKey);
  const serverHint = side === "server" ? field.serverHint : undefined;
  const set = isSet(value);
  const retired = status?.status === "retired";
  //the registry's sentence goes where the hint goes: under the field, where the eye already is
  const standing = status?.notice ? (
    <span
      className={cn("block", retired ? "text-muted-foreground" : "text-amber-700 dark:text-amber-400")}
      data-key-status={status!.status}
    >
      {status!.notice}
      {status!.replacedBy && !retired && (
        <>
          {" "}
          <a href={`#${status!.replacedBy}`} className="underline underline-offset-2">Go to it</a>
        </>
      )}
    </span>
  ) : null;

  //beside the label rather than inside it: a <button> is not allowed in a <label>, and a label click
  //is forwarded to the control it names -- on an enum that opened the select as well
  const action = set && field.widget.kind !== "secret"
    ? <UseDefault onClick={() => onClear(settingKey)} />
    : undefined;

  const help = [hint, serverHint].filter(Boolean).join(" ");

  if (field.widget.kind === "boolean") {
    return (
      <div className={cn(isWide(field) && "xl:col-span-2", retired && "pointer-events-none opacity-60")} aria-disabled={retired || undefined}>
        <BooleanRow
          settingKey={settingKey}
          label={label}
          hint={[help, status?.notice].filter(Boolean).join(" ")}
          value={value}
          codedDefault={field.codedDefault}
          inherited={inherited}
          onChange={onChange}
          onClear={onClear}
        />
      </div>
    );
  }

  return (
    <Field
      label={label}
      hint={problem || standing ? (
        <>
          {help && <span className="block">{help}</span>}
          {problem && <span className="block text-destructive">{problem}</span>}
          {standing}
        </>
      ) : help || undefined}
      //list and pairs render several inputs and none of them carries this id, so a label click
      //would have nothing to focus
      htmlFor={isWide(field) ? undefined : settingKey}
      action={action}
      className={cn(isWide(field) && "xl:col-span-2", retired && "opacity-60")}
    >
      <Control
        settingKey={settingKey}
        field={field}
        value={value}
        inherited={inherited}
        stored={stored}
        definitions={definitions}
        suggested={suggested}
        onChange={onChange}
        onClear={onClear}
      />
    </Field>
  );
}

function Control({
  settingKey,
  field,
  value,
  inherited,
  stored,
  definitions,
  suggested,
  onChange,
  onClear,
}: {
  settingKey: SettingKey;
  field: SettingField;
  value: string | undefined;
  inherited: string | undefined;
  stored: boolean;
  definitions: readonly TlvDefinition[];
  suggested: Record<number, boolean>;
  onChange: (key: string, value: string) => void;
  onClear: (key: string) => void;
}) {
  const widget = field.widget;

  switch (widget.kind) {
    case "secret":
      return (
        <SecretControl
          settingKey={settingKey}
          value={value}
          stored={stored}
          onChange={onChange}
          onClear={onClear}
        />
      );

    case "enum":
      return (
        <Select
          id={settingKey}
          value={value ?? ""}
          onChange={(e) => (e.target.value === "" ? onClear(settingKey) : onChange(settingKey, e.target.value))}
        >
          <option value="">{notSetEnumLabel(field, widget.options, inherited)}</option>
          {widget.options.map((option) => (
            <option key={option.value} value={option.value}>{option.label}</option>
          ))}
          {/* a value nobody anticipated stays selectable rather than silently reverting */}
          {value != null && !widget.options.some((o) => o.value === value) && (
            <option value={value}>{value} — not a value this panel knows</option>
          )}
        </Select>
      );

    case "number":
      return (
        <div className="flex items-center gap-2">
          <Input
            id={settingKey}
            value={value ?? ""}
            onChange={(e) => onChange(settingKey, e.target.value)}
            inputMode="numeric"
            placeholder={fallbackFor(inherited, field.codedDefault).value}
            className="tabular-nums"
          />
          {widget.unit && (
            <span className="shrink-0 text-sm text-muted-foreground">{UNIT_WORDS[widget.unit]}</span>
          )}
        </div>
      );

    case "list":
      return (
        <ListControl
          settingKey={settingKey}
          value={value ?? ""}
          placeholder={widget.itemPlaceholder}
          isTlv={widget.itemKind === "tlv"}
          definitions={definitions}
          suggested={suggested}
          onChange={onChange}
        />
      );

    case "pairs":
      return (
        <PairsControl
          settingKey={settingKey}
          value={value ?? ""}
          assign={widget.assign}
          keyPlaceholder={widget.keyPlaceholder}
          valuePlaceholder={widget.valuePlaceholder}
          isTlv={widget.itemKind === "tlv"}
          definitions={definitions}
          suggested={suggested}
          onChange={onChange}
        />
      );

    case "pattern":
      return (
        <PatternControl
          settingKey={settingKey}
          value={value ?? ""}
          placeholder={field.codedDefault}
          onChange={onChange}
        />
      );

    case "text":
      return (
        <Input
          id={settingKey}
          value={value ?? ""}
          onChange={(e) => onChange(settingKey, e.target.value)}
          placeholder={widget.placeholder ?? (fallbackFor(inherited, field.codedDefault).value || undefined)}
        />
      );

    default:
      //boolean, which SettingRow renders itself because its label is part of the control
      return null;
  }
}

const UNIT_WORDS = { ms: "milliseconds", s: "seconds", min: "minutes" } as const;

/**
 * What "not set" means for an enum, now that the tier above can answer.
 *
 * <p>Prefers the value actually inherited over the literal compiled into the gateway. The literal is
 * a snapshot of a Java file in another repository and was being presented as fact -- correct only
 * while nobody had set a gateway default, and silently wrong afterwards.
 */
function notSetEnumLabel(
  field: SettingField,
  options: readonly { value: string; label: string }[],
  inherited: string | undefined
): string {
  const fallback = fallbackFor(inherited, field.codedDefault);
  if (fallback.inherited) {
    return `Not set — inheriting ${labelOf(options, fallback.value)}`;
  }
  if (fallback.value) {
    return `Not set — the gateway uses ${labelOf(options, fallback.value)}`;
  }
  //no literal and nothing inherited: the tier above simply has no opinion yet
  return "Not set — use the gateway default";
}

function labelOf(options: readonly { value: string; label: string }[], value: string): string {
  return options.find((o) => o.value === value)?.label ?? value;
}

/**
 * A setting with three states, of which the third is the one that makes the display honest.
 *
 * <p>Absent is not false. `counters`, `ccat.8bit`, `srv.enabled` and `forward.dlrs` all default to
 * true in the gateway, so a two-state box would draw an empty tick next to a setting that is on.
 * Unset renders indeterminate and says what the gateway's own default is.
 *
 * <p>Clicking from unset writes the **opposite** of what is currently in force, because agreeing
 * with a default is not a reason to touch the field. "In force" means the inherited
 * `outSms.default.<key>` where there is one, and the coded literal otherwise -- so the toggle flips
 * away from what the worker is actually doing rather than from a guess. The literal is still always
 * written, even when it matches: this panel's idea of the coded default is a snapshot of a Java file
 * in another repository.
 */
function BooleanRow({
  settingKey,
  inherited,
  label,
  hint,
  value,
  codedDefault,
  onChange,
  onClear,
}: {
  settingKey: string;
  label: string;
  hint?: string;
  value: string | undefined;
  codedDefault: string;
  inherited: string | undefined;
  onChange: (key: string, value: string) => void;
  onClear: (key: string) => void;
}) {
  const unset = !isSet(value);
  const on = value === "true";
  const strange = !unset && value !== "true" && value !== "false";

  return (
    <div className="flex items-start gap-2 text-sm">
      <Checkbox
        id={settingKey}
        className="mt-0.5"
        checked={on}
        indeterminate={unset}
        onChange={() => onChange(settingKey, unset ? String(fallbackFor(inherited, codedDefault).value !== "true") : String(!on))}
      />
      <div className="flex-1">
        {/* the label wraps only the text. It used to wrap the whole row including the button below,
            which is invalid -- and a label containing its own checkbox forwards a click to it, so
            "Use default" cleared the key and the checkbox immediately set it again */}
        <label htmlFor={settingKey} className="cursor-pointer">
          {label}
        </label>
        {!unset && <UseDefault className="ml-2" onClick={() => onClear(settingKey)} />}
        {hint && <span className="block text-xs text-muted-foreground">{hint}</span>}
        {unset && (
          <span className="block text-xs text-muted-foreground">
            {inherited !== undefined ? (
              <>
                Not set — inheriting <strong>{inherited === "true" ? "on" : "off"}</strong> from the
                gateway default.
              </>
            ) : (
              <>Not set — the gateway&apos;s default is {codedDefault === "true" ? "on" : "off"}.</>
            )}
          </span>
        )}
        {strange && (
          <span className="block text-xs text-amber-600 dark:text-amber-400">
            Stored as <code>{value}</code>, which the gateway reads as off — it only accepts
            &ldquo;true&rdquo;. Saving rewrites it.
          </span>
        )}
      </div>
    </div>
  );
}

/**
 * A stored secret, edited without its value reaching the browser.
 *
 * <p>Works on the worker wire contract directly: the server sends {@link REDACTED} in place of a
 * stored value and treats it on the way back as "leave the row alone". Nothing here normalises,
 * trims or seeds — a widget that wrote asterisks into `values` on mount would overwrite the TLS
 * keystore password on the first save of an unrelated field, and nothing would report it until the
 * listener failed to start.
 */
function SecretControl({
  settingKey,
  value,
  stored,
  onChange,
  onClear,
}: {
  settingKey: string;
  value: string | undefined;
  stored: boolean;
  onChange: (key: string, value: string) => void;
  onClear: (key: string) => void;
}) {
  const [visible, setVisible] = useState(false);

  if (value === REDACTED) {
    return (
      <div className="flex items-center gap-2">
        <Input id={settingKey} value="••••••••" readOnly disabled className="font-mono" />
        <Button type="button" variant="outline" size="sm" onClick={() => onChange(settingKey, "")}>
          Replace
        </Button>
        <Button type="button" variant="ghost" size="sm" onClick={() => onClear(settingKey)}>
          Remove
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Input
            id={settingKey}
            type={visible ? "text" : "password"}
            value={value ?? ""}
            onChange={(e) => onChange(settingKey, e.target.value)}
            className="pr-9 font-mono"
            autoComplete="new-password"
          />
          <button
            type="button"
            tabIndex={-1}
            onClick={() => setVisible((v) => !v)}
            aria-label={visible ? "Hide" : "Show"}
            className="absolute inset-y-0 right-0 flex w-9 items-center justify-center rounded-r-md text-muted-foreground transition-colors hover:text-foreground"
          >
            {visible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>
        {stored && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => onChange(settingKey, REDACTED)}
          >
            Keep the stored one
          </Button>
        )}
      </div>
      {stored && (value ?? "") === "" && (
        <p className="mt-1 text-xs text-destructive">
          Left blank, saving removes the stored value.
        </p>
      )}
    </div>
  );
}

/**
 * Keeps an editing buffer in step with a value that can also change from outside.
 *
 * <p><strong>The buffer is required, not a convenience.</strong> These controls edit rows but store
 * one joined string, and some editing states have no representation in that string: a single empty
 * row serialises to `""`, which parses back to *no* rows. Deriving the rows from the value each
 * render — which both of these used to do — therefore made **Add** do nothing at all on an empty
 * field, and an empty field is exactly where you press it.
 *
 * <p>But a pure buffer ignores the outside world, and there is one writer out there that matters:
 * **Use default** deletes the key. So the buffer re-seeds whenever the incoming value stops matching
 * what the buffer itself would write.
 *
 * <p>Adjust-during-render rather than an effect, deliberately. An effect leaves one render showing
 * stale rows, and a keystroke landing in that window writes the stale rows back over the change that
 * triggered it.
 */
function useRowBuffer<T>(
  value: string,
  parse: (value: string) => T[],
  serialise: (rows: T[]) => string
): [T[], (next: T[]) => void] {
  const [rows, setRows] = useState<T[]>(() => parse(value));
  const [seen, setSeen] = useState(value);

  if (value !== seen) {
    setSeen(value);
    //only when the change did not come from this buffer -- otherwise every keystroke would reset the
    //empty rows the buffer exists to hold
    if (value !== serialise(rows)) {
      setRows(parse(value));
    }
  }

  return [rows, setRows];
}

/**
 * One comma-joined string, edited as rows.
 *
 * <p>Not the same thing as `CredentialForm`'s list editors, which hold and persist real arrays. This
 * edits a single value and joins it back on every keystroke, so a comma typed inside an item would
 * split it — hence the stripping below rather than a silent split later.
 */
function ListControl({
  settingKey,
  value,
  placeholder,
  isTlv,
  definitions,
  suggested,
  onChange,
}: {
  settingKey: string;
  value: string;
  placeholder?: string;
  /** Renders each row as a TLV token, with the tag resolved beside it. */
  isTlv?: boolean;
  definitions?: readonly TlvDefinition[];
  suggested?: Record<number, boolean>;
  onChange: (key: string, value: string) => void;
}) {
  const [items, setItems] = useRowBuffer<string>(value, parseList, serialiseList);

  function write(next: string[]) {
    setItems(next);
    onChange(settingKey, serialiseList(next));
  }

  return (
    <div className="space-y-2">
      {items.map((item, i) => {
        const set = (raw: string) =>
          write(items.map((v, n) => (n === i ? raw.replace(/,/g, "") : v)));
        return (
          <div key={i} className="flex items-start gap-2">
            {isTlv ? (
              <TlvTokenInput
                value={item}
                onChange={set}
                placeholder={placeholder}
                definitions={definitions}
          suggested={suggested}
                ariaLabel="TLV token"
                className="flex-1"
              />
            ) : (
              <Input
                value={item}
                placeholder={placeholder}
                onChange={(e) => set(e.target.value)}
                className="font-mono"
              />
            )}
            <Button
              type="button"
              variant="ghost"
              size="icon"
              aria-label="Remove"
              onClick={() => write(items.filter((_, n) => n !== i))}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        );
      })}
      <Button type="button" variant="outline" size="sm" className="gap-1.5" onClick={() => write([...items, ""])}>
        <Plus className="h-3.5 w-3.5" />
        Add
      </Button>
    </div>
  );
}

const parseList = (value: string): string[] => (value === "" ? [] : value.split(","));

/** Blank rows are dropped on the way out: a trailing comma is an entry the gateway would try to parse. */
const serialiseList = (rows: string[]): string => rows.filter((item) => item !== "").join(",");

/**
 * A comma-joined list of pairs, joined by `_` or `=`.
 *
 * <p>Neither separator can appear inside a value — the gateway splits on the first one it finds —
 * so both are stripped as they are typed. A pair with an empty name is dropped rather than written
 * as a bare separator, which the gateway would parse as a nameless entry and quietly ignore.
 */
interface Pair {
  name: string;
  val: string;
}

function PairsControl({
  settingKey,
  value,
  assign,
  keyPlaceholder,
  valuePlaceholder,
  isTlv,
  definitions,
  suggested,
  onChange,
}: {
  settingKey: string;
  value: string;
  assign: "=" | "_";
  keyPlaceholder?: string;
  valuePlaceholder?: string;
  /** The name half of each pair is a TLV token. */
  isTlv?: boolean;
  definitions?: readonly TlvDefinition[];
  suggested?: Record<number, boolean>;
  onChange: (key: string, value: string) => void;
}) {
  /**
   * The rows on screen, which are not quite the stored value.
   *
   * <p>A half-typed pair has no name yet, and `=value` is not something the gateway should ever be
   * handed — it parses as a nameless entry and ignores it. So the buffer holds every row including
   * the incomplete ones, and only complete pairs are written.
   */
  const parse = useCallback(
    (raw: string): Pair[] =>
      raw === ""
        ? []
        : raw.split(",").map((entry) => {
            const at = entry.indexOf(assign);
            return at < 0
              ? { name: entry, val: "" }
              : { name: entry.slice(0, at), val: entry.slice(at + 1) };
          }),
    [assign]
  );
  const serialise = useCallback(
    (next: Pair[]): string =>
      next.filter((p) => p.name !== "").map((p) => `${p.name}${assign}${p.val}`).join(","),
    [assign]
  );

  const [rows, setRows] = useRowBuffer<Pair>(value, parse, serialise);

  const clean = (raw: string) => raw.replace(/,/g, "").split(assign).join("");

  function update(next: Pair[]) {
    setRows(next);
    onChange(settingKey, serialise(next));
  }

  return (
    <div className="space-y-2">
      {rows.map((pair, i) => (
        <div key={i} className="flex items-start gap-2">
          {isTlv ? (
            <TlvTokenInput
              value={pair.name}
              onChange={(raw) => update(rows.map((p, n) => (n === i ? { ...p, name: clean(raw) } : p)))}
              placeholder={keyPlaceholder}
              definitions={definitions}
          suggested={suggested}
              ariaLabel="TLV token"
              className="w-64"
            />
          ) : (
            <Input
              value={pair.name}
              placeholder={keyPlaceholder}
              onChange={(e) => update(rows.map((p, n) => (n === i ? { ...p, name: clean(e.target.value) } : p)))}
              className="w-44 font-mono"
              aria-label="Name"
            />
          )}
          <Input
            value={pair.val}
            placeholder={valuePlaceholder}
            onChange={(e) => update(rows.map((p, n) => (n === i ? { ...p, val: clean(e.target.value) } : p)))}
            className="flex-1 font-mono"
            aria-label="Value"
          />
          <Button
            type="button"
            variant="ghost"
            size="icon"
            aria-label="Remove"
            onClick={() => update(rows.filter((_, n) => n !== i))}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      ))}
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="gap-1.5"
        onClick={() => update([...rows, { name: "", val: "" }])}
      >
        <Plus className="h-3.5 w-3.5" />
        Add
      </Button>
    </div>
  );
}

/** A regular expression, checked for compiling and nothing else. */
function PatternControl({
  settingKey,
  value,
  placeholder,
  onChange,
}: {
  settingKey: string;
  value: string;
  placeholder?: string;
  onChange: (key: string, value: string) => void;
}) {
  let broken = false;
  if (value !== "") {
    try {
      new RegExp(value);
    } catch {
      broken = true;
    }
  }

  return (
    <div>
      <Input
        id={settingKey}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(settingKey, e.target.value)}
        className="font-mono"
      />
      {broken && (
        <p className="mt-1 text-xs text-destructive">
          This does not compile as a regular expression here. Java&apos;s syntax is not identical, so
          one that compiles here can still be rejected by the gateway.
        </p>
      )}
    </div>
  );
}

