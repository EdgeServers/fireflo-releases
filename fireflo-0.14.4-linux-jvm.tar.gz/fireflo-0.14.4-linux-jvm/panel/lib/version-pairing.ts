/**
 * Whether this panel and the gateway it is talking to are the pair they claim to be.
 *
 * <p>The panel's version is a claim about the gateway: its first three numbers **are** a gateway
 * release, by the scheme in the README, and a fourth number is a panel-only revision on top of it.
 * Until the gateway published its own version that claim was unverifiable from either side — a
 * panel built for one release talking to another looked exactly like a matched pair, and the number
 * beside the wordmark answered a question nobody could check.
 *
 * <p>Database-free so the check is one function rather than one per surface.
 */

export type PairingVerdict =
  /** The first three numbers agree. */
  | "matched"
  /** They do not, and both are known. */
  | "mismatched"
  /** The gateway did not say, so there is nothing to compare. */
  | "unknown";

export interface VersionPairing {
  verdict: PairingVerdict;
  panel: string;
  gateway: string | null;
  /** What to tell the operator, or null when there is nothing worth saying. */
  message: string | null;
}

/**
 * The first three numbers, which is the part that has to agree.
 *
 * <p>Tolerates the product name the gateway prefixes ("FireFlo 0.5.0"), and both spellings the
 * panel uses for its own version — `0.4.1+1` in `package.json`
 * because npm requires valid semver, and `0.4.1.1` on screen — since this is called with each in
 * different places and a comparison that understood only one would silently never match.
 */
export function gatewayRelease(version: string | null | undefined): string | null {
  const trimmed = (version ?? "").trim();
  if (!trimmed) {
    return null;
  }
  //The gateway reports "FireFlo 0.5.0" so a version read out of context still says what it is a
  //version of. Everything before the last space goes, which also covers a future rename without
  //this needing to know the product's name.
  //
  //Getting this wrong is silent: an unparsed version returns null, the verdict degrades to
  //"unknown", and the mismatch warning simply stops appearing -- which looks exactly like a
  //correctly matched pair.
  const numeric = trimmed.slice(trimmed.lastIndexOf(" ") + 1);
  //everything up to the fourth separator, whichever spelling produced it
  const parts = numeric.replace("+", ".").split(".");
  if (parts.length < 3) {
    return null;
  }
  const first = parts.slice(0, 3);
  return first.every((p) => /^\d+$/.test(p)) ? first.join(".") : null;
}

/**
 * Compares the pair and says what is wrong in the operator's terms.
 *
 * <p>**Silent unless something is actually wrong.** A matched pair says nothing, and so does a
 * gateway too old to report a version — that is not a fault, it is a gateway from before the field
 * existed, and warning about it would train people to ignore the warning that matters.
 */
export function versionPairing(
  panelVersion: string,
  gatewayVersion: string | null | undefined
): VersionPairing {
  const panel = gatewayRelease(panelVersion);
  const gateway = gatewayRelease(gatewayVersion);

  if (!gateway) {
    return {
      verdict: "unknown",
      panel: panelVersion,
      gateway: gatewayVersion?.trim() || null,
      message: null,
    };
  }
  if (panel && panel === gateway) {
    return { verdict: "matched", panel: panelVersion, gateway: gatewayVersion!.trim(), message: null };
  }
  return {
    verdict: "mismatched",
    panel: panelVersion,
    gateway: gatewayVersion!.trim(),
    message:
      `This panel was built for gateway ${panel ?? panelVersion} and is talking to ${gateway}. `
      + "The two are deployed together and read the same schema, so a mismatch usually means one "
      + "of them did not get updated — check which, rather than trusting either screen.",
  };
}

/**
 * The newest gateway schema version this panel was written against.
 *
 * <p>Bumped when a gateway migration changes a table the panel reads -- a column added to
 * `app_config_key`, a new `cdr_*` table, a renamed enum value -- never for a migration the panel
 * does not notice. It is a claim about the panel's SQL, not about the gateway's release: a gateway
 * one release ahead whose migrations touched nothing the panel reads is a matched pair here.
 *
 * <p>1.90.0: `app_config_key.status` / `replaced_by` (V1.88.0), `cdr_submit.client_ref` (V1.89.0),
 * `srv.bind.backoff.enabled` registered (V1.90.0). 1.91.0: `usage_hourly` and `usage_rollup_cursor`,
 * which the home page and the portal read where present, and the six `smsg.usage.*` keys. 1.92.0:
 * `smsg.cdr.body` registered. 1.93.0: `queue_archive`, `queue_archive_batch` and
 * `queue_archive_summary`, which Reports → Archives reads where present, and
 * `smsg.queue.archive.retention.days` registered. 1.94.0: the vendor keys `dest.addr.convert` and
 * `dest.addr.country` registered. 1.95.0: `account_balance.spent` and SPEND reservation rows, which
 * the reconciliation reads as the third column of the money identity. 1.96.0: partial GIN indexes
 * on `cdr_submit` (nothing the panel reads changes shape). 1.97.0: `usage_hourly.attempts`, which the
 * vendor figures read from the summary. 1.98.0: `usage_failure_hourly`, which the home page's failures
 * tile reads where present. 1.99.0: the three `smsg.dlr.deadline.receipt.*` keys registered, and
 * `smsg.cdr.deadline.hours`'s registered default corrected to 24. 1.100.0: `app_account.archived_at`,
 * `archived_by` and `archived_logins`, which the account list, the archive actions and every
 * account writer's read-only check read. 1.101.0: `app_account.external_ref` (the platform, e.g. OMNI,
 * that owns an account; shown on the account and in the list) and `app_rate_rule.managed_by` (a
 * platform's custom-tariff rules, which the pricing screens show read-only and every save leaves alone).
 * 1.102.0: gateway 0.13 -- the release that replaces REST `/ops` with GraphQL and adds the slow-query
 * log and the refusal ledger; the panel 0.13.0.0 pairs with gateway 0.13.0 and expects this schema.
 * 1.103.0 to 1.109.0: gateway 0.14 -- `gateway_node` and `cluster_job` (the Nodes page reads the
 * former), `client_ref_claim`, `balance_hold` (per-node credit holds; `account_balance.reserved` is
 * their sum and `reserved_by` is no longer written), the PostgreSQL receipt store (`dlr_*`),
 * `vendor_lease` and `app_worker.node_pin`, `smpp_session`, and the `smsg.kafka.*` / `smsg.cluster.*`
 * keys with `smsg.queue.provider` narrowed to memory|kafka and the RabbitMQ keys retired (V1.109.0).
 * 1.110.0: gateway 0.14.3 -- `rest_batch` and `rest_batch_callback` (durable REST batches, which
 * nothing in the panel reads yet) and five `smsg.restapi.batch.*` keys registered.
 * 1.111.0: gateway 0.14.4 -- `balance_generation`, `balance_settle_mark` and `balance_charge_tally`
 * (each prepaid charge tagged and its priced call records tallied, so a killed node's unsettled
 * spending is charged on reconcile); nothing in the panel reads them yet.
 */
export const EXPECTED_SCHEMA_VERSION = "1.111.0";

export type SchemaVerdict =
  /** The database is at the version this panel expects, or past it in a way that cannot be older. */
  | "matched"
  /** The database has not been through a migration this panel's queries rely on. */
  | "older"
  /** The database is ahead of this panel: a warning, since migrations are additive, not a block. */
  | "newer"
  /** The gateway did not say, said `none` (no database) or `unknown`; nothing to compare. */
  | "unknown";

export interface SchemaPairing {
  verdict: SchemaVerdict;
  expected: string;
  /** What the gateway reported, trimmed, or null when it reported nothing. */
  schema: string | null;
  message: string | null;
}

/** `1.90.0` as `[1, 90, 0]`, or null for anything that is not dotted numbers. */
function schemaParts(version: string | null | undefined): number[] | null {
  const trimmed = (version ?? "").trim();
  if (!/^\d+(\.\d+)*$/.test(trimmed)) {
    return null;
  }
  return trimmed.split(".").map(Number);
}

/** Numeric, part by part; a missing part is zero, so `1.90` equals `1.90.0`. */
export function compareSchemaVersions(a: string, b: string): number {
  const pa = schemaParts(a) ?? [];
  const pb = schemaParts(b) ?? [];
  const n = Math.max(pa.length, pb.length);
  for (let i = 0; i < n; i++) {
    const d = (pa[i] ?? 0) - (pb[i] ?? 0);
    if (d !== 0) {
      return d < 0 ? -1 : 1;
    }
  }
  return 0;
}

/**
 * Whether the database is the one this panel's queries were written for.
 *
 * <p>Silent when matched and when there is nothing to compare: a gateway too old to report a schema
 * version, one in file mode (`none`) or one that could not read its own history (`unknown`) is not
 * something this panel can judge, and the release pairing above already covers the first. An older
 * schema is the fault that matters -- the panel's next query may fail on a column that is not there
 * -- so its sentence says what to do. A newer schema is only a warning: migrations are additive,
 * so the panel keeps working and simply does not know about what was added.
 */
export function schemaPairing(
  reported: string | null | undefined,
  expected: string = EXPECTED_SCHEMA_VERSION
): SchemaPairing {
  const schema = reported?.trim() || null;
  if (!schema || schemaParts(schema) === null) {
    return { verdict: "unknown", expected, schema, message: null };
  }
  const order = compareSchemaVersions(schema, expected);
  if (order === 0) {
    return { verdict: "matched", expected, schema, message: null };
  }
  if (order < 0) {
    return {
      verdict: "older",
      expected,
      schema,
      message: `Database schema ${schema} is older than this panel expects (${expected}): run the gateway's update first.`,
    };
  }
  return {
    verdict: "newer",
    expected,
    schema,
    message: `Database schema ${schema} is newer than this panel expects (${expected}): update the panel too. `
      + "Migrations are additive, so this panel keeps working and simply does not know what was added.",
  };
}
