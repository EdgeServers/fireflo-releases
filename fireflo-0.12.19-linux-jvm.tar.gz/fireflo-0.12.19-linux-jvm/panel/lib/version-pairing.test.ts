import { test } from "node:test";
import assert from "node:assert/strict";
import { compareSchemaVersions, EXPECTED_SCHEMA_VERSION, gatewayRelease, schemaPairing, versionPairing } from "./version-pairing.ts";

/**
 * The panel/gateway pairing check.
 *
 * <p>This exists because a stale panel build is invisible: it renders perfectly, talks to the
 * gateway perfectly, and claims a version it was not built from. The case that prompted it was a
 * server showing 0.4.1.2 against a 0.4.2 gateway after an update appeared to succeed.
 */

test("a panel-only revision still pairs with the gateway it names", () => {
  //0.4.1.1 means "the panel that goes with gateway 0.4.1, first revision" -- the fourth number is
  //the panel's own and must not make the pair look mismatched
  assert.equal(versionPairing("0.4.1.1", "0.4.1").verdict, "matched");
  assert.equal(versionPairing("0.4.1+1", "0.4.1").verdict, "matched",
    "package.json spells the same thing with a plus, because npm requires valid semver");
});

test("an exact match is silent", () => {
  const p = versionPairing("0.4.2", "0.4.2");
  assert.equal(p.verdict, "matched");
  assert.equal(p.message, null, "a matched pair must say nothing at all");
});

test("the case this was built for: a stale panel against a newer gateway", () => {
  const p = versionPairing("0.4.1.2", "0.4.2");
  assert.equal(p.verdict, "mismatched");
  assert.match(p.message ?? "", /built for gateway 0\.4\.1/);
  assert.match(p.message ?? "", /talking to 0\.4\.2/);
  //the useful instruction: do not trust either screen until you know which one is behind
  assert.match(p.message ?? "", /check which/);
});

test("a newer panel against an older gateway is just as wrong", () => {
  assert.equal(versionPairing("0.5.0", "0.4.2").verdict, "mismatched");
});

test("a gateway too old to report a version is not a fault", () => {
  //the field did not exist before this change, so an older gateway simply omits it. Warning here
  //would train people to ignore the warning that matters
  for (const missing of [null, undefined, "", "   "]) {
    const p = versionPairing("0.4.2", missing);
    assert.equal(p.verdict, "unknown");
    assert.equal(p.message, null);
  }
});

test("the gateway's own fallback string is treated as no answer", () => {
  //OpsHealthService sends "unknown" in a dev run with no version configured
  const p = versionPairing("0.4.2", "unknown");
  assert.equal(p.verdict, "unknown");
  assert.equal(p.message, null);
  assert.equal(p.gateway, "unknown", "but it is still shown, rather than hidden");
});

test("the release is the first three numbers, in either spelling", () => {
  assert.equal(gatewayRelease("0.4.1"), "0.4.1");
  assert.equal(gatewayRelease("0.4.1.7"), "0.4.1");
  assert.equal(gatewayRelease("0.4.1+7"), "0.4.1");
  assert.equal(gatewayRelease("10.20.30.40"), "10.20.30");
});

test("anything that is not three numbers yields nothing to compare", () => {
  for (const bad of ["", "  ", "0.4", "unknown", "v0.4.1", "0.4.x"]) {
    assert.equal(gatewayRelease(bad), null, bad);
  }
});

test("the gateway's product prefix is stripped before comparing", () => {
  //the gateway reports "FireFlo 0.5.0" so a version read out of a log or a ticket says what it is a
  //version of. If this parser did not know that, gatewayRelease would return null, every pair would
  //degrade to "unknown", and the mismatch warning would stop appearing -- silently, and looking
  //exactly like a correctly matched pair
  assert.equal(gatewayRelease("FireFlo 0.5.0"), "0.5.0");
  assert.equal(gatewayRelease("  FireFlo 0.5.0  "), "0.5.0");
});

test("a prefixed gateway version still matches a bare panel version", () => {
  const p = versionPairing("0.5.0.1", "FireFlo 0.5.0");

  assert.equal(p.verdict, "matched");
  assert.equal(p.message, null, "a matched pair says nothing, prefix or not");
});

test("a prefixed gateway version still reports a real mismatch", () => {
  //a panel one gateway release behind, which is what 0.4.5.6 against 0.5.0 was until the panel
  //caught up. Kept as the mismatch case precisely because it really happened. The warning
  //appearing is the proof the prefix was parsed -- silence here would mean the parser broke
  const p = versionPairing("0.4.5.6", "FireFlo 0.5.0");

  assert.equal(p.verdict, "mismatched");
  assert.match(p.message ?? "", /built for gateway 0\.4\.5/);
  assert.match(p.message ?? "", /talking to 0\.5\.0/);
});

test("a product name alone is not a version", () => {
  assert.equal(gatewayRelease("FireFlo"), null);
  assert.equal(gatewayRelease("FireFlo unknown"), null);
});

test("a database at the expected schema is silent", () => {
  const p = schemaPairing(EXPECTED_SCHEMA_VERSION, "1.93.0");
  assert.equal(p.verdict, "matched");
  assert.equal(p.message, null);
  assert.equal(schemaPairing("1.90", "1.90.0").verdict, "matched", "a missing part is zero");
});

test("an older schema says to run the gateway's update first", () => {
  const p = schemaPairing("1.85.0", "1.90.0");
  assert.equal(p.verdict, "older");
  assert.equal(p.message, "Database schema 1.85.0 is older than this panel expects (1.90.0): run the gateway's update first.");
  //numeric, not textual: 1.9.0 is older than 1.90.0 and 1.100.0 is newer
  assert.equal(schemaPairing("1.9.0", "1.90.0").verdict, "older");
  assert.equal(compareSchemaVersions("1.100.0", "1.90.0"), 1);
});

test("a newer schema is a warning that names both numbers, not a block", () => {
  const p = schemaPairing("1.92.0", "1.90.0");
  assert.equal(p.verdict, "newer");
  assert.match(p.message ?? "", /Database schema 1\.92\.0 is newer than this panel expects \(1\.90\.0\)/);
  assert.match(p.message ?? "", /keeps working/);
});

test("no schema, 'none' and 'unknown' are nothing to compare, and say nothing", () => {
  for (const reported of [null, undefined, "", "  ", "none", "unknown", "v1.90.0"]) {
    const p = schemaPairing(reported, "1.90.0");
    assert.equal(p.verdict, "unknown", String(reported));
    assert.equal(p.message, null);
  }
  //but the word is kept, so a screen can still show which the gateway said
  assert.equal(schemaPairing("none", "1.90.0").schema, "none");
  assert.equal(schemaPairing("   ", "1.90.0").schema, null);
});

test("the expected schema is a dotted number the comparison understands", () => {
  assert.equal(compareSchemaVersions(EXPECTED_SCHEMA_VERSION, EXPECTED_SCHEMA_VERSION), 0);
  assert.match(EXPECTED_SCHEMA_VERSION, /^\d+\.\d+\.\d+$/);
});
