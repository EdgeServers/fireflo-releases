"use client";
import { useState } from "react";
import { ArrowDown, ArrowUp, Pencil, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog } from "@/components/ui/dialog";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { InfoPopover } from "@/components/ui/popover";
import { Switch } from "@/components/ui/switch";
import { TableEmpty, TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { HealthStrip } from "./CardBits";
import { DangerAction } from "./DangerAction";
import { ErrorCard, ErrorNote } from "./FormNotices";
import { useConfirmChange } from "./ConfirmProvider";
import { useTags } from "./useTags";
import { TagChip, tagDotClass } from "./TagChip";
import {
  type Tag,
  type TagColor,
  TAG_COLORS,
  TAG_COLOR_LABELS,
  TAG_DESCRIPTION_MAX,
  TAGS_NEED_GATEWAY,
  TAGS_TAKE_EFFECT,
  inUseMessage,
  isUsed,
  moveTag,
  tagDescriptionProblem,
  tagLabelProblem,
  tagNameProblem,
  usageLine,
} from "@/lib/tag-types";
import { cn } from "@/lib/utils";

/**
 * The one list of account tags (gateway 0.17.0): add, relabel, switch on or off, reorder, delete.
 *
 * <p>Order matters for prices only: when an account has several tags with price lists, the one
 * higher here wins. A tag that a rule, filter or price list names cannot be deleted, only switched
 * off -- and a switched-off tag matches nothing and prices nothing.
 */
export function TagsClient() {
  const { tags, available, error, busy, create, update, remove, reorder } = useTags();
  const confirm = useConfirmChange();
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<Tag | null>(null);
  const [open, setOpen] = useState<string | null>(null);
  const [actionError, setActionError] = useState("");

  if (available === false) {
    return <HealthStrip tone="info">{TAGS_NEED_GATEWAY}</HealthStrip>;
  }

  const order = tags.map((t) => t.name);

  async function move(name: string, by: -1 | 1) {
    setActionError((await reorder(moveTag(order, name, by))) ?? "");
  }

  async function toggle(t: Tag, on: boolean) {
    const used = isUsed(t.usage);
    if (!on && (used || t.accounts > 0)) {
      const ok = await confirm({
        title: `Switch off ${t.name}?`,
        consequence: `A switched-off tag matches nothing and prices nothing: ${used ? `${usageLine(t.usage)} stop applying to` : "nothing changes for"} `
          + `its ${t.accounts} account${t.accounts === 1 ? "" : "s"}. They keep the tag, so switching it back on restores it. ${TAGS_TAKE_EFFECT}`,
        confirmLabel: "Switch off",
      });
      if (!ok) return;
    }
    setActionError((await update(t.name, { enabled: on })) ?? "");
  }

  return (
    <>
      <ErrorCard error={error || actionError} />
      <Card>
        <CardHeader bar className="flex flex-row flex-wrap items-center gap-2 space-y-0">
          <div className="flex min-w-0 flex-1 items-center gap-2">
            <CardTitle>
              Tags <span className="font-normal text-muted-foreground">· {tags.length}</span>
            </CardTitle>
            <InfoPopover label="How tags work">
              <div className="space-y-2 text-sm">
                <p>
                  A tag is defined once here, put on accounts by the operator on each account&apos;s Settings
                  tab, and then used wherever a rule can say who it applies to: routing rules, filters and
                  prices (the condition &ldquo;Account tag&rdquo;, and a price list per tag on the Pricing page).
                </p>
                <p>
                  Order decides which tag&apos;s price wins when an account has several tags with price lists:
                  the higher one. A units sub-account carries its parent&apos;s tags as well as its own.
                </p>
                <p>
                  A tag that a rule, filter or price list names cannot be deleted, only switched off. A
                  switched-off tag matches nothing and prices nothing; accounts keep it.
                </p>
                <p>The gateway picks up every change at its next configuration poll, within 30 seconds.</p>
              </div>
            </InfoPopover>
          </div>
          <Button size="sm" className="gap-2" onClick={() => setAdding(true)} disabled={available === null}>
            <Plus className="h-4 w-4" aria-hidden="true" /> Add a tag
          </Button>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">
            Order decides whose price wins when an account has several tags. {TAGS_TAKE_EFFECT}
          </p>
          <TableInCard>
            <THead>
              <TR>
                <TH align="right">Order</TH>
                <TH>Tag</TH>
                <TH>Label</TH>
                <TH align="right">Accounts</TH>
                <TH>Used in</TH>
                <TH>State</TH>
                <TH><span className="sr-only">Actions</span></TH>
              </TR>
            </THead>
            <TBody>
              {tags.length === 0 && (
                <TableEmpty colSpan={7}>
                  {available === null ? "Loading…" : "No tags yet. Add one, then put it on accounts from their Settings tab."}
                </TableEmpty>
              )}
              {tags.map((t, i) => {
                const used = isUsed(t.usage);
                return (
                  <TagRow
                    key={t.name}
                    tag={t}
                    position={i + 1}
                    first={i === 0}
                    last={i === tags.length - 1}
                    busy={busy === t.name || busy === "order"}
                    open={open === t.name}
                    used={used}
                    onToggleUses={() => setOpen((o) => (o === t.name ? null : t.name))}
                    onToggle={(on) => void toggle(t, on)}
                    onEdit={() => setEditing(t)}
                    onMove={(by) => void move(t.name, by)}
                    onDelete={async () => setActionError((await remove(t.name)) ?? "")}
                  />
                );
              })}
            </TBody>
          </TableInCard>
        </CardContent>
      </Card>

      {adding && (
        <TagDialog
          mode="add"
          taken={order}
          onClose={() => setAdding(false)}
          onSave={async (name, details) => {
            const failure = await create(name, details);
            if (!failure) setAdding(false);
            return failure;
          }}
        />
      )}
      {editing && (
        <TagDialog
          mode="edit"
          initial={editing}
          taken={order}
          onClose={() => setEditing(null)}
          onSave={async (_name, details) => {
            const failure = await update(editing.name, details);
            if (!failure) setEditing(null);
            return failure;
          }}
        />
      )}
    </>
  );
}

const chip = "inline-flex items-center rounded-full px-2 py-px text-2xs font-medium";

function TagRow({
  tag: t, position, first, last, busy, open, used, onToggleUses, onToggle, onEdit, onMove, onDelete,
}: {
  tag: Tag;
  position: number;
  first: boolean;
  last: boolean;
  busy: boolean;
  open: boolean;
  used: boolean;
  onToggleUses: () => void;
  onToggle: (on: boolean) => void;
  onEdit: () => void;
  onMove: (by: -1 | 1) => void;
  onDelete: () => Promise<void>;
}) {
  const usesId = `tag-${t.name}-uses`;
  return (
    <>
      <TR id={`tag-${t.name}`} data-tag={t.name}>
        <TD num muted>{position}</TD>
        <TD><TagChip name={t.name} label={t.label} description={t.description} color={t.color} enabled={t.enabled} /></TD>
        <TD>
          {t.label || <span className="text-muted-foreground">—</span>}
          {t.description && <span className="block text-xs text-muted-foreground" data-testid="tag-description">{t.description}</span>}
        </TD>
        <TD num>{t.accounts}</TD>
        <TD>
          {used ? (
            <button type="button" aria-expanded={open} aria-controls={usesId} onClick={onToggleUses}
              className="text-left text-sm text-primary hover:underline">
              {usageLine(t.usage)}
            </button>
          ) : (
            <span className="text-sm text-muted-foreground">not used</span>
          )}
        </TD>
        <TD>
          <span className="flex items-center gap-2">
            <Switch checked={t.enabled} disabled={busy} onChange={onToggle}
              aria-label={`${t.name} ${t.enabled ? "on" : "off"}`} />
            <Badge variant={t.enabled ? "success" : "outline"}>{t.enabled ? "On" : "Off"}</Badge>
          </span>
        </TD>
        <TD>
          <span className="flex items-center justify-end gap-1">
            <Button variant="ghost" size="sm" className="gap-1.5" onClick={onEdit} aria-label={`Edit ${t.name}`}>
              <Pencil className="h-3.5 w-3.5" aria-hidden="true" /> Edit
            </Button>
            <Button variant="ghost" size="sm" className="h-8 w-8 px-0" aria-label={`Move ${t.name} up`} disabled={first || busy} onClick={() => onMove(-1)}>
              <ArrowUp className="h-4 w-4" aria-hidden="true" />
            </Button>
            <Button variant="ghost" size="sm" className="h-8 w-8 px-0" aria-label={`Move ${t.name} down`} disabled={last || busy} onClick={() => onMove(1)}>
              <ArrowDown className="h-4 w-4" aria-hidden="true" />
            </Button>
            <DangerAction
              label="Delete"
              confirmLabel={`Delete ${t.name}`}
              busy={busy}
              consequence={used
                ? `${inUseMessage(t.name, t.usage)} This will be refused.`
                : `Takes ${t.name} off ${t.accounts} account${t.accounts === 1 ? "" : "s"} and removes it. Nothing names it, so no rule or price changes.`}
              onConfirm={() => void onDelete()}
            />
          </span>
        </TD>
      </TR>
      {open && used && (
        <tr id={usesId}>
          <td colSpan={7} className="bg-muted/40 px-4 py-2">
            <ul className="space-y-1 text-sm">
              {t.usage.items.map((u, i) => (
                <li key={i} className="flex items-center gap-2">
                  <span className={cn(chip, u.kind === "routing" ? "bg-info-soft text-info" : u.kind === "filter" ? "bg-muted text-foreground" : "bg-primary-soft text-foreground")}>
                    {u.kind === "routing" ? "Routing" : u.kind === "filter" ? "Filter" : "Pricing"}
                  </span>
                  <span className="font-mono text-sm">{u.label}</span>
                </li>
              ))}
            </ul>
          </td>
        </tr>
      )}
    </>
  );
}

/** What the dialog saves besides the name. */
interface TagDetails {
  label: string;
  description: string;
  color: TagColor;
}

/** Add a tag (name, label, description, colour), or change those. The name is fixed once made. */
function TagDialog({
  mode, initial, taken, onClose, onSave,
}: {
  mode: "add" | "edit";
  initial?: Tag;
  taken: string[];
  onClose: () => void;
  onSave: (name: string, details: TagDetails) => Promise<string | null>;
}) {
  const [name, setName] = useState(initial?.name ?? "");
  const [label, setLabel] = useState(initial?.label ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  const [color, setColor] = useState<TagColor>(initial?.color ?? "gray");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const nameProblem = mode === "add" && name ? (tagNameProblem(name) ?? (taken.includes(name) ? `A tag called '${name}' already exists.` : null)) : null;

  async function submit() {
    const bad = mode === "add" ? (tagNameProblem(name) ?? nameProblem) : null;
    const badLabel = tagLabelProblem(label.trim()) ?? tagDescriptionProblem(description.trim());
    if (bad || badLabel) {
      setError(bad ?? badLabel ?? "");
      return;
    }
    setSaving(true);
    const failure = await onSave(name, { label: label.trim(), description: description.trim(), color });
    setSaving(false);
    if (failure) setError(failure);
  }

  return (
    <Dialog open onClose={onClose} title={mode === "add" ? "Add a tag" : `Edit ${initial?.name}`}>
      <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); void submit(); }}>
        <Field label="Name" htmlFor="tag-name"
          hint={mode === "add" ? "Fixed once added: rules and prices name it." : "Fixed: rules and prices name it."}
          more="Lower-case letters, digits, '-' and '_', starting with a letter or digit, at most 40 characters. Routing rules, filters and price lists refer to the tag by this name, so it cannot be renamed; the label can.">
          <Input id="tag-name" className="font-mono" value={name} disabled={mode === "edit"} autoFocus={mode === "add"}
            placeholder="premium" onChange={(e) => setName(e.target.value)} aria-invalid={!!nameProblem || undefined} />
        </Field>
        {nameProblem && <p className="text-sm text-destructive">{nameProblem}</p>}
        <Field label="Label" htmlFor="tag-label" hint="Optional. What the tag is for, shown beside it.">
          <Input id="tag-label" value={label} autoFocus={mode === "edit"} placeholder="Premium routes"
            onChange={(e) => setLabel(e.target.value)} />
        </Field>
        <Field label="Description" htmlFor="tag-description" hint="Optional. Shown when pointing at the tag.">
          <Input id="tag-description" value={description} maxLength={TAG_DESCRIPTION_MAX}
            placeholder="Accounts sending one-time passwords" onChange={(e) => setDescription(e.target.value)} />
        </Field>
        <ColorPicker value={color} onChange={setColor} />
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          Looks like <TagChip name={name || "tag"} label={label} description={description} color={color} />
        </div>
        <p className="text-xs text-muted-foreground">
          {mode === "add" ? "A new tag is on and at the end of the order. " : ""}Colour and description are for people only; routing and prices do not read them.
        </p>
        <ErrorNote error={error} />
        <div className="flex flex-wrap justify-end gap-2 border-t border-border pt-4">
          <Button type="button" variant="ghost" className="mr-auto" onClick={onClose}>Cancel</Button>
          <Button type="submit" disabled={saving || (mode === "add" && (!name || !!nameProblem))}>
            {saving ? "Saving…" : mode === "add" ? "Add tag" : "Save"}
          </Button>
        </div>
      </form>
    </Dialog>
  );
}

/**
 * Nine labelled swatches as a radio group: Tab reaches the group, the arrow keys move within it,
 * and each swatch says its colour's name, so nothing rests on telling hues apart.
 */
function ColorPicker({ value, onChange }: { value: TagColor; onChange: (next: TagColor) => void }) {
  return (
    <fieldset>
      <legend className="mb-1.5 text-sm font-medium">Colour</legend>
      <div role="radiogroup" aria-label="Colour" className="flex flex-wrap gap-1.5">
        {TAG_COLORS.map((c) => (
          <label key={c}
            className={cn(
              "flex cursor-pointer items-center gap-1.5 rounded-full border px-2 py-1 text-xs focus-within:ring-2 focus-within:ring-ring",
              value === c ? "border-foreground font-semibold" : "border-border text-muted-foreground"
            )}>
            <input type="radio" name="tag-color" value={c} checked={value === c} onChange={() => onChange(c)}
              className="sr-only" />
            <span className={cn("h-3 w-3 rounded-full", tagDotClass(c))} aria-hidden="true" />
            {TAG_COLOR_LABELS[c]}
          </label>
        ))}
      </div>
    </fieldset>
  );
}
