"use client";
import { useCallback, useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { ErrorCard, SavedNote } from "./FormNotices";
import { GatewayIgnores } from "./GatewayIgnores";
import { ScopeForm } from "./ScopeForm";
import { PriceOrderCard } from "./PriceOrderCard";
import { useProductCatalogue } from "./useProducts";
import { useRates } from "./useRates";
import { useConfirmChange } from "./ConfirmProvider";
import { stagedSummary } from "@/lib/confirm-changes";
import { scopeKind, type ManagedRule, type RateRule, type RateRuleInput } from "@/lib/rate-types";
import { platformOf } from "@/lib/account-columns";
import { formatClockTime } from "@/lib/datetime";
import { useDisplayZone } from "@/components/DisplayZoneProvider";

/**
 * One account's custom tariff, on a page of its own.
 *
 * <p>It used to sit at the bottom of the account page, and it did not belong there. A rule list is
 * as wide as the screen, grows without limit, and every row carries a condition editor — so it took
 * over the page it was a section of, and pushed everything above it out of view for anyone whose
 * account had more than a handful of rules. Pricing is also the one thing on that page you arrive to
 * do deliberately, rather than something you glance at while doing something else.
 *
 * <p>The whole scope loads and saves here, which is what makes reordering possible: {@code
 * saveScope} rewrites `seq` from array position and deletes any rule it is not given, so an editor
 * holding a filtered view could not be allowed to move anything. This one holds all of it.
 */
export function AccountTariffClient({ id }: { id: string }) {
  const { zone } = useDisplayZone();
  const { known, scopes, load: loadSummary, loadScope, loadManaged, saveScope } = useRates();

  const [rules, setRules] = useState<RateRule[] | null>(null);
  const [managed, setManaged] = useState<ManagedRule[]>([]);
  const [savedAt, setSavedAt] = useState<string | null>(null);
  const [error, setError] = useState("");

  const kind = scopeKind(id, known);
  const productCatalogue = useProductCatalogue();
  const confirm = useConfirmChange();

  const loadRules = useCallback(async () => {
    const [own, platform] = await Promise.all([loadScope(id), loadManaged(id)]);
    setRules(own ?? []);
    setManaged(platform);
  }, [id, loadScope, loadManaged]);

  useEffect(() => {
    void loadRules();
  }, [loadRules]);

  return (
    <>
      {/* no BackLink and no heading: this is a tab now, and the shell above it already names the
          account and offers the way out. Two back links on one page is worse than none */}
      <GatewayIgnores domain="rates" />
      <ErrorCard error={error} />
      <SavedNote
        at={savedAt}
        detail={"The gateway picks pricing up on its next configuration poll, within thirty "
          + "seconds — there is no immediate push for rates."}
      />

      {kind === "cost" && (
        <Card className="border-destructive">
          <CardContent className="py-3 text-sm text-destructive">
            A vendor is also called <code>{id}</code>. Rating matches a rate scope by name alone, so
            these rules are read as <strong>our cost for that vendor</strong> as well as this
            account&apos;s price. Rename one before pricing either.
          </CardContent>
        </Card>
      )}

      {/* own → tags in order → default, and which levels hold prices (gateway 0.17.0) */}
      {kind !== "cost" && <PriceOrderCard id={id} known={known} scopes={scopes} platformTariff={managed.length > 0} />}

      {managed.length > 0 && (
        <Card>
          <CardContent className="space-y-2 py-3">
            <p className="text-sm">
              <strong>Custom tariff set by {platformOf(managed[0].managedBy)}.</strong>{" "}
              <span className="text-muted-foreground">
                Priced ahead of the rules below, and changed only there: saving this page leaves it as it is.
              </span>
            </p>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs text-muted-foreground">
                    <th className="py-1 pr-4 font-medium">Product</th>
                    <th className="py-1 pr-4 font-medium">Destinations starting</th>
                    <th className="py-1 font-medium">Price per segment</th>
                  </tr>
                </thead>
                <tbody>
                  {managed.map((r) => (
                    <tr key={r.id} className="border-t border-border">
                      <td className="py-1 pr-4 font-mono">{r.product ?? "any"}</td>
                      <td className="py-1 pr-4 font-mono">{r.prefixes.map((p) => `+${p}`).join(", ")}</td>
                      <td className="py-1 tabular-nums">{r.amount}{r.enabled ? "" : " (off)"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {rules === null ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : (
        <ScopeForm
          //keyed on CONTENT, not on ids. Editing an amount leaves every id unchanged, so an
          //id-only key never remounted and the editor went on showing the array it had submitted
          //rather than what came back -- which is exactly why a save was indistinguishable from a
          //failed one. Now the fields are re-seeded from the reload, so what is on screen after a
          //save is what is stored
          key={rules.map((r) => `${r.id}:${r.seq}:${r.amount}:${r.product ?? ""}:${r.enabled}`).join("|")}
          scope={id}
          initial={rules as RateRuleInput[]}
          known={known}
          catalogue={productCatalogue}
          isNew={rules.length === 0}
          locked
          onDirty={() => setSavedAt(null)}
          onSave={async (scope, next, confirmed) => {
            //new rules have no id yet, so they key by position among the new ones
            let fresh = 0;
            const key = (r: RateRuleInput) => (r.id === null ? `new-${fresh++}` : String(r.id));
            const summary = stagedSummary(rules as RateRuleInput[], next, key, (r) => JSON.stringify(r));
            if (!(await confirm({
              title: "Save this tariff?",
              consequence: `Replaces ${scope}'s price rules${summary ? `: ${summary}` : ""}. The gateway prices ` +
                "its next messages by them.",
              confirmLabel: "Save tariff",
            }))) {
              //not saved, and nothing to report: the form stays as it was for another try
              return "";
            }
            const failure = await saveScope(scope, next, confirmed, rules.length === 0);
            if (!failure) {
              await loadRules();
              //the "Which price applies" counts come from the scope summary
              void loadSummary();
              setSavedAt(formatClockTime(new Date(), zone));
            }
            return failure;
          }}
          onCancel={() => {
            setError("");
            void loadRules();
          }}
        />
      )}
    </>
  );
}
