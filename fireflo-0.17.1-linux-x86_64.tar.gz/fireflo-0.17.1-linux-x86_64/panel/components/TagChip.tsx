"use client";
import { X } from "lucide-react";
import { type TagColor, tagColorOf, tagTitle } from "@/lib/tag-types";
import { cn } from "@/lib/utils";
import { useTagNames } from "./useTags";

/**
 * The tag colours as classes, written out whole so the stylesheet keeps every one. Tokens from
 * `app/globals.css` (`--color-tag-<colour>` and `-soft`), redefined for the dark theme.
 */
const TONE: Record<TagColor, { chip: string; dot: string }> = {
  gray: { chip: "bg-tag-gray-soft text-tag-gray", dot: "bg-tag-gray" },
  red: { chip: "bg-tag-red-soft text-tag-red", dot: "bg-tag-red" },
  orange: { chip: "bg-tag-orange-soft text-tag-orange", dot: "bg-tag-orange" },
  yellow: { chip: "bg-tag-yellow-soft text-tag-yellow", dot: "bg-tag-yellow" },
  green: { chip: "bg-tag-green-soft text-tag-green", dot: "bg-tag-green" },
  teal: { chip: "bg-tag-teal-soft text-tag-teal", dot: "bg-tag-teal" },
  blue: { chip: "bg-tag-blue-soft text-tag-blue", dot: "bg-tag-blue" },
  purple: { chip: "bg-tag-purple-soft text-tag-purple", dot: "bg-tag-purple" },
  pink: { chip: "bg-tag-pink-soft text-tag-pink", dot: "bg-tag-pink" },
};

/** The dot of one colour, for the colour picker's swatches. */
export function tagDotClass(color: TagColor): string {
  return TONE[color].dot;
}

/** The chip classes of one colour. */
export function tagChipClass(color: TagColor): string {
  return TONE[color].chip;
}

/**
 * One account tag, drawn the same way everywhere: its name, in its colour, with label and
 * description as the tooltip. The name is always shown, so the colour is never the only signal.
 * A switched-off tag is dashed and says "off".
 *
 * <p>Pass the details when the caller has them (the Tags page); otherwise they are looked up by
 * name in the page's shared tag list, and an unknown name draws gray.
 */
export function TagChip({
  name,
  label,
  description,
  color,
  enabled,
  onRemove,
  removeLabel,
  className,
}: {
  name: string;
  label?: string;
  description?: string;
  color?: string;
  enabled?: boolean;
  /** Draws an × that calls this; its accessible name is `removeLabel` or "Remove tag <name>". */
  onRemove?: () => void;
  removeLabel?: string;
  className?: string;
}) {
  const { tags } = useTagNames();
  const known = tags.find((t) => t.name === name);
  const tone = tagColorOf(color ?? known?.color);
  const off = (enabled ?? known?.enabled) === false;
  const title = tagTitle({
    name,
    label: label ?? known?.label,
    description: description ?? known?.description,
    enabled: enabled ?? known?.enabled,
  });
  return (
    <span
      title={title}
      data-tag-chip={name}
      data-tag-color={tone}
      className={cn(
        "inline-flex max-w-full items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium",
        TONE[tone].chip,
        off && "border border-dashed border-current opacity-80",
        className
      )}
    >
      <span className="truncate font-mono text-xs">{name}</span>
      {off && <span className="font-normal">off</span>}
      {onRemove && (
        <button type="button" aria-label={removeLabel ?? `Remove tag ${name}`} onClick={onRemove}
          className="-mr-0.5 rounded-full p-0.5 opacity-70 hover:opacity-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
          <X className="h-3 w-3" aria-hidden="true" />
        </button>
      )}
    </span>
  );
}
