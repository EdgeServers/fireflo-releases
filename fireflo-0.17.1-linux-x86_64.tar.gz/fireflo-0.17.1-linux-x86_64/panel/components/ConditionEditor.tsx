"use client";
import { Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import {
  ALL_FIELDS,
  BOOLEAN_OPERATORS,
  COMMON_FIELDS,
  type ConditionInput,
  NUMERIC_OPERATORS,
  STRING_OPERATORS,
  TAG_FIELD,
  TAG_OPERATORS,
  tagConditionProblem,
} from "@/lib/rate-types";

import { unknownTagNames } from "@/lib/tag-types";
import { useTagNames } from "./useTags";

/** What each tag operator means, since the gateway's names say something else. */
const TAG_OPERATOR_WORDS: Record<(typeof TAG_OPERATORS)[number], string> = {
  equals: "equals (has all of)",
  startsWithAny: "startsWithAny (has any of)",
  isNull: "isNull (has no tag)",
};

/** Operators that compare against nothing, so their value box is hidden rather than left empty. */
const VALUELESS = new Set(["isNull", "isTrue", "isFalse", "default"]);

/**
 * The conditions on one rule. All of them must hold for the rule to apply.
 *
 * <p>The field is a datalist rather than a closed dropdown: the ten or so fields anyone actually
 * prices on are offered, and the other forty are reachable by typing. The same shape as the worker
 * form's common settings plus its free-form extras, and for the same reason — a closed list would
 * either be too long to scan or too short to be honest.
 */
export function ConditionEditor({
  conditions,
  filterCount = 0,
  onChange,
}: {
  conditions: ConditionInput[];
  /**
   * How many filters the rule carries.
   *
   * <p>A count rather than the filters themselves, because the only question here is whether
   * anything else narrows this rule. Without it this component asserted "matches every message" for
   * a filtered rule while `isCatchAll` — which does count filters — correctly said the scope had no
   * catch-all. Two messages about one rule, disagreeing, two elements apart on screen.
   */
  filterCount?: number;
  onChange: (next: ConditionInput[]) => void;
}) {
  //the tag list, for the warning about a name it does not have (a warning, not a block: the tag
  //may be about to be added)
  const tagList = useTagNames(conditions.some((c) => c.field.trim() === TAG_FIELD));
  const set = (i: number, patch: Partial<ConditionInput>) =>
    onChange(conditions.map((c, n) => {
      if (n !== i) return c;
      const next = { ...c, ...patch };
      //a tag takes only its three operators: anything else would make the gateway refuse the rule
      if (next.field.trim() === TAG_FIELD && !(TAG_OPERATORS as readonly string[]).includes(next.operator)) {
        next.operator = "equals";
      }
      return next;
    }));

  return (
    <div className="space-y-2">
      {!conditions.length && filterCount === 0 && (
        <p className="text-sm text-muted-foreground">
          No conditions, so this rule matches every message it is asked about. That is what a
          catch-all is — and it must be the last rule, or nothing below it can ever be reached.
        </p>
      )}

      {!conditions.length && filterCount > 0 && (
        <p className="text-sm text-muted-foreground">
          No conditions of its own — but {filterCount === 1 ? "the filter" : `the ${filterCount} filters`}
          {" "}below {filterCount === 1 ? "narrows" : "narrow"} this rule, so it is{" "}
          <strong>not</strong> a catch-all. Whatever falls outside{" "}
          {filterCount === 1 ? "it" : "them"} is priced by the next rule that matches, or by nothing
          at all.
        </p>
      )}

      {conditions.map((c, i) => {
        const isTag = c.field.trim() === TAG_FIELD;
        const tagProblem = tagConditionProblem(c);
        return (
        <div key={i} className="flex flex-wrap items-center gap-2">
          <span className="w-8 shrink-0 text-sm text-muted-foreground">{i === 0 ? "when" : "and"}</span>

          <Input
            list="cdr-condition-fields"
            value={c.field}
            onChange={(e) => set(i, { field: e.target.value })}
            placeholder="field"
            className="w-40"
            aria-label="Field"
          />

          <label className="flex items-center gap-1.5 text-sm text-muted-foreground">
            <input
              type="checkbox"
              checked={c.negate}
              onChange={(e) => set(i, { negate: e.target.checked })}
              className="h-3.5 w-3.5 rounded border-input accent-primary"
            />
            not
          </label>

          <Select
            value={c.operator}
            onChange={(e) => set(i, { operator: e.target.value })}
            className="w-44"
            aria-label="Operator"
          >
            {isTag ? (
              <optgroup label="Account tag">
                {TAG_OPERATORS.map((o) => (
                  <option key={o} value={o}>{TAG_OPERATOR_WORDS[o]}</option>
                ))}
              </optgroup>
            ) : (<>
            <optgroup label="Text">
              {STRING_OPERATORS.map((o) => (
                <option key={o} value={o}>{o}</option>
              ))}
            </optgroup>
            <optgroup label="Yes / no">
              {BOOLEAN_OPERATORS.map((o) => (
                <option key={o} value={o}>{o}</option>
              ))}
            </optgroup>
            {/* kept visibly apart from the text operators because mixing them up is the classic
                mistake: '==' compares numbers, 'equals' compares text, and the gateway refuses the
                whole rate table rather than the one rule */}
            <optgroup label="Numbers only">
              {NUMERIC_OPERATORS.map((o) => (
                <option key={o} value={o}>{o}</option>
              ))}
            </optgroup>
            </>)}
          </Select>

          {!VALUELESS.has(c.operator) && (
            <Input
              value={c.value}
              onChange={(e) => set(i, { value: e.target.value })}
              placeholder={isTag ? "premium or otp,premium" : c.operator === "matches" ? "regular expression" : "value"}
              className="w-56 font-mono"
              aria-label="Value"
            />
          )}

          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            aria-label="Remove this condition"
            onClick={() => onChange(conditions.filter((_, n) => n !== i))}
          >
            <X className="h-3.5 w-3.5" />
          </Button>
          {isTag && tagProblem && (c.value || c.operator !== "equals") && (
            <p className="basis-full pl-10 text-xs text-destructive">{tagProblem}</p>
          )}
          {isTag && !tagProblem && tagList.available && (() => {
            const unknown = unknownTagNames([c], tagList.tags.map((t) => t.name));
            return unknown.length > 0 && (
              <p className="basis-full pl-10 text-xs text-warning">
                No tag called {unknown.join(", ")} on the Tags page, so this matches no account until one is added.
              </p>
            );
          })()}
        </div>
        );
      })}

      <Button
        type="button"
        variant="ghost"
        size="sm"
        className="gap-1.5"
        onClick={() => onChange([...conditions, { field: "to", operator: "startsWith", value: "", negate: false }])}
      >
        <Plus className="h-3.5 w-3.5" />
        Add a condition
      </Button>

      {/* one datalist for the whole form rather than one per row; duplicate ids would be invalid
          HTML and browsers resolve them unpredictably */}
      <datalist id="cdr-condition-fields">
        {[...COMMON_FIELDS, ...ALL_FIELDS.filter((f) => !COMMON_FIELDS.includes(f as never))].map((f) => (
          <option key={f} value={f} />
        ))}
      </datalist>
    </div>
  );
}
