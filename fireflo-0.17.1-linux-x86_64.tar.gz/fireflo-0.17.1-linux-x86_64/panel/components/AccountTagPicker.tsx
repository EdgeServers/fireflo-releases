"use client";
import Link from "next/link";
import { TagChip } from "./TagChip";
import { Select } from "@/components/ui/select";
import { SettingsRow } from "@/components/ui/settings-row";
import { TAGS_NEED_GATEWAY } from "@/lib/tag-types";
import type { TagName } from "./useTags";

/** What the account's Settings tab knows about tags, from `/api/control/accounts/[id]/tags`. */
export interface AccountTagging {
  available: boolean;
  /** Its own tags, as stored. */
  own: string[];
  /** Every tag in order, for the picker. */
  options: TagName[];
  /** A units sub-account's parent and the parent's enabled tags it carries. */
  inherited: { parent: string; tags: string[] } | null;
  /** Units sub-accounts carrying this account's tags. */
  inheritingChildren: number;
}

/**
 * The account's own tags as chips, with "Add a tag…" offering the enabled tags it does not have.
 * Inherited tags are listed read-only underneath. The change is saved with the account form.
 */
export function TagPicker({
  tagging,
  value,
  onChange,
  disabled,
}: {
  tagging: AccountTagging;
  value: string[];
  onChange: (next: string[]) => void;
  disabled?: boolean;
}) {
  const more = (
    <div className="space-y-2">
      <p>
        Routing rules, filters and prices can test an account&apos;s tags (the condition &ldquo;Account
        tag&rdquo;), and a tag can have its own price list on the Pricing page.
      </p>
      <p>
        Only the operator sees and sets them. A units sub-account of this account carries these tags too,
        plus its own. A tag switched off on the Tags page stays on the account but matches nothing.
      </p>
      <p>Saved with the rest of this form. The gateway follows the change within 30 seconds.</p>
    </div>
  );

  if (!tagging.available) {
    return (
      <SettingsRow label="Tags" help={TAGS_NEED_GATEWAY}>
        <span className="text-sm text-muted-foreground">—</span>
      </SettingsRow>
    );
  }

  const byName = new Map(tagging.options.map((t) => [t.name, t]));
  //in the Tags list's order, whatever order they were added in
  const shown = [...value].sort((a, b) => (byName.get(a)?.seq ?? 1e9) - (byName.get(b)?.seq ?? 1e9) || a.localeCompare(b));
  const addable = tagging.options.filter((t) => t.enabled && !value.includes(t.name));

  return (
    <SettingsRow
      label="Tags"
      labelId="acct-tags"
      help="Used by routing rules, filters and prices. A change takes effect within 30 seconds."
      more={more}
    >
      <div className="space-y-2" data-testid="account-tags">
        <div className="flex flex-wrap items-center gap-1.5">
          {shown.map((t) => (
            <TagChip key={t} name={t} onRemove={disabled ? undefined : () => onChange(value.filter((x) => x !== t))} />
          ))}
          {addable.length > 0 ? (
            <Select aria-label="Add a tag" value="" disabled={disabled} className="h-8 w-auto text-sm"
              onChange={(e) => e.target.value && onChange([...value, e.target.value])}>
              <option value="">Add a tag…</option>
              {addable.map((t) => (
                <option key={t.name} value={t.name}>{t.label ? `${t.name} — ${t.label}` : t.name}</option>
              ))}
            </Select>
          ) : (
            <span className="text-xs text-muted-foreground">
              {tagging.options.length ? "Every enabled tag is on." : <>No tags yet. <Link href="/cp/tags" className="text-primary hover:underline">Add one</Link>.</>}
            </span>
          )}
        </div>
        {tagging.inherited && (
          <p className="text-xs text-muted-foreground" data-testid="account-tags-inherited">
            {tagging.inherited.tags.length
              ? <>Also carries {tagging.inherited.tags.map((t) => <TagChip key={t} name={t} className="mx-0.5" />)} from its parent{" "}</>
              : <>Carries no tags from its parent{" "}</>}
            <Link href={`/cp/accounts/${encodeURIComponent(tagging.inherited.parent)}`} className="font-mono text-primary hover:underline">
              {tagging.inherited.parent}
            </Link>
            . Change those on the parent.
          </p>
        )}
        {tagging.inheritingChildren > 0 && (
          <p className="text-xs text-muted-foreground" data-testid="account-tags-children">
            {tagging.inheritingChildren} units sub-account{tagging.inheritingChildren === 1 ? "" : "s"} carr{tagging.inheritingChildren === 1 ? "ies" : "y"} these tags too.
          </p>
        )}
      </div>
    </SettingsRow>
  );
}
