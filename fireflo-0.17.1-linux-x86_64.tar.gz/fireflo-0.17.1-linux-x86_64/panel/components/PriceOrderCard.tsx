"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { InfoPopover } from "@/components/ui/popover";
import { scopeHref } from "./PricingShell";
import type { KnownScopes, ScopeSummary } from "@/lib/rate-types";
import type { AccountTags } from "@/lib/tag-types";
import { priceLevels } from "@/lib/price-order";
import { TagChip } from "./TagChip";

/**
 * "Which price applies" on an account's Tariff tab: the order the gateway looks for a sell price --
 * the account's own prices, then each of its enabled tags by the Tags list's order, then the default
 * -- and which of those levels has a price list at all.
 *
 * <p>Deliberately not a per-message answer. Which rule matches one message depends on its product,
 * destination and every condition, and that is the gateway's matcher; re-implementing it here would
 * be a second matcher free to disagree with the one that charges. Shown only where the gateway has
 * tags (0.17.0); without them the order is simply own, then default, which the page already says.
 */
export function PriceOrderCard({
  id,
  known,
  scopes,
  platformTariff,
}: {
  id: string;
  known: KnownScopes;
  scopes: ScopeSummary[];
  /** A platform's custom tariff sits on the account's own scope, ahead of its other rules. */
  platformTariff: boolean;
}) {
  const [tags, setTags] = useState<AccountTags | null>(null);
  useEffect(() => {
    let live = true;
    fetch(`/api/control/accounts/${encodeURIComponent(id)}/tags`, { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((json) => live && setTags((json?.data as AccountTags | undefined) ?? null))
      .catch(() => live && setTags(null));
    return () => {
      live = false;
    };
  }, [id]);

  if (!tags?.available || !known.tagDetails) {
    return null;
  }
  const levels = priceLevels(id, tags.effective, scopes, known.tagDetails, tags.own);

  return (
    <Card data-testid="price-order">
      <CardHeader bar className="flex flex-row items-center gap-2 space-y-0">
        <CardTitle>Which price applies</CardTitle>
        <InfoPopover label="Which price applies">
          <div className="space-y-2 text-sm">
            <p>
              For each message the gateway looks for a sell price in this order and takes the first price
              that matches the message&apos;s product and conditions: the account&apos;s own prices, then each
              of its tags in the Tags list&apos;s order, then the default.
            </p>
            <p>
              Only switched-on tags count. A units sub-account also carries its parent&apos;s tags. This shows
              the order and which levels hold prices; whether one of them matches a given message is decided
              by the gateway, so a level with prices can still be passed over for a message none of them fits.
            </p>
            <p>Changes to tags, their order or any price list reach the gateway within 30 seconds.</p>
          </div>
        </InfoPopover>
      </CardHeader>
      <CardContent className="pt-3">
        <ol className="divide-y divide-border rounded-lg border border-border text-sm">
          {levels.map((l, i) => (
            <li key={l.scope} className="flex flex-wrap items-center gap-x-3 gap-y-1 px-3 py-2">
              <span className="w-5 tabular-nums text-muted-foreground">{i + 1}</span>
              <span className="min-w-0 flex-1">
                {l.kind === "own" ? "The account's own prices" + (platformTariff ? " (its platform tariff first)" : "")
                  : l.kind === "tag" ? <>Tag <TagChip name={l.tag!} /> <span className="text-muted-foreground">(order {l.order}{l.inherited ? ", from its parent" : ""})</span></>
                  : "Default price"}
              </span>
              <Link href={scopeHref(l.scope)} className={l.prices ? "text-primary hover:underline" : "text-muted-foreground hover:underline"}>
                {l.prices ? `${l.prices} price${l.prices === 1 ? "" : "s"}` : l.kind === "default" ? "not set" : l.kind === "own" ? "none" : "no price list"}
              </Link>
            </li>
          ))}
        </ol>
        <p className="mt-2 text-xs text-muted-foreground">
          The first level with a matching price is charged.
          {tags.effective.length === 0 && " This account has no switched-on tags, so it goes from its own prices to the default."}
        </p>
      </CardContent>
    </Card>
  );
}
