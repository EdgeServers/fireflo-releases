"use client";
import { useEffect, useState } from "react";
import { Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Segmented } from "@/components/ui/segmented";
import { Select } from "@/components/ui/select";
import { GUIDED_KINDS, TAG_MODES, type GuidedField, type MatchMode, type TagMode } from "@/lib/filter-guide";
import { TAGS_NEED_GATEWAY } from "@/lib/tag-types";
import { TagChip } from "./TagChip";

/**
 * One guided condition: how to compare, the value, and "except". Shared by the filter wizard and the
 * routing rule editor, so a destination prefix is entered the same way in both.
 */

export interface GuidedOptions {
  products: { value: string; label: string }[];
  logins: { value: string; label: string }[];
  accounts: { value: string; label: string }[];
  /** Account tags in order, disabled ones marked "off" (gateway 0.17.0). */
  tags: { value: string; label: string; enabled: boolean }[];
  /** False on a database without tags; null until it has answered. */
  tagsAvailable: boolean | null;
}

/**
 * The catalogue lists the value controls choose from. A failed fetch leaves its list empty, and that
 * control falls back to a text box.
 */
export function useGuidedOptions(): GuidedOptions {
  const [options, setOptions] = useState<GuidedOptions>({ products: [], logins: [], accounts: [], tags: [], tagsAvailable: null });
  useEffect(() => {
    let live = true;
    const get = (url: string) => fetch(url, { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).catch(() => null);
    void Promise.all([
      get("/api/control/products"),
      get("/api/control/credentials"),
      get("/api/control/accounts/catalogue"),
      get("/api/control/tags?names=1"),
    ]).then(([p, c, a, t]) => {
      if (!live) return;
      setOptions({
        products: ((p?.data?.products ?? []) as { name: string; label: string | null }[])
          .map((x) => ({ value: x.name, label: x.label ? `${x.name} — ${x.label}` : x.name })),
        logins: ((c?.data?.credentials ?? []) as { systemId: string | null; type: string }[])
          .filter((x) => x.systemId)
          .map((x) => ({ value: x.systemId!, label: `${x.systemId} (${x.type})` })),
        accounts: ((a?.data?.accounts ?? []) as { id: string; label: string | null }[])
          .map((x) => ({ value: x.id, label: x.label ? `${x.id} — ${x.label}` : x.id })),
        tags: ((t?.data?.tags ?? []) as { name: string; label: string; enabled: boolean }[])
          .map((x) => ({
            value: x.name,
            label: `${x.name}${x.label ? ` — ${x.label}` : ""}${x.enabled ? "" : " (off)"}`,
            enabled: x.enabled,
          })),
        tagsAvailable: t ? t.data?.available !== false : false,
      });
    });
    return () => {
      live = false;
    };
  }, []);
  return options;
}

/** One guided field's controls: how to compare, the value, and "except". */
export function GuidedConditionRow({
  field,
  options,
  onChange,
  onRemove,
}: {
  field: GuidedField;
  options: GuidedOptions;
  onChange: (patch: Partial<GuidedField>) => void;
  onRemove: () => void;
}) {
  const meta = GUIDED_KINDS.find((k) => k.id === field.kind)!;
  if (field.kind === "tag") {
    return <TagConditionRow field={field} options={options} onChange={onChange} onRemove={onRemove} />;
  }
  const id = `fw-${field.kind}`;
  const value = field.values[0] ?? "";
  const list = field.kind === "product" ? options.products : field.kind === "login" ? options.logins : field.kind === "account" ? options.accounts : null;
  const numberish = field.kind === "destination" || field.kind === "sender";

  return (
    <div className="space-y-2 rounded-lg border border-border p-4">
      <div className="flex flex-wrap items-center gap-3">
        <span id={`${id}-label`} className="font-semibold">{meta.label}</span>
        {numberish && (
          <Segmented<MatchMode>
            label={`How to compare the ${meta.label.toLowerCase()}`}
            value={field.mode}
            onChange={(mode) => onChange({ mode, values: mode === "prefixes" ? field.values : [field.values[0] ?? ""] })}
            options={[
              { value: "prefix", label: "Starts with" },
              { value: "exact", label: "Is exactly" },
              { value: "prefixes", label: "Any of these prefixes" },
            ]}
            //its own line under the label, sharing the card's width: three options side by side ran
            //past the card's edge in a dialog
            fill
            className="order-last basis-full"
          />
        )}
        <button type="button" aria-label={`Stop matching on ${meta.label.toLowerCase()}`} onClick={onRemove}
          className="ml-auto rounded p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground">
          <X className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {numberish && field.mode === "prefixes" ? (
          <>
            {field.values.map((v, i) => (
              <span key={i} className="flex items-center gap-1">
                <Input aria-label={`Prefix ${i + 1}`} className="w-36 font-mono" value={v} placeholder={field.kind === "destination" ? "+91" : "ACME"}
                  onChange={(e) => onChange({ values: field.values.map((x, n) => (n === i ? e.target.value : x)) })} />
                {field.values.length > 1 && (
                  <button type="button" aria-label={`Remove prefix ${v || i + 1}`} className="rounded p-1 text-muted-foreground hover:text-foreground"
                    onClick={() => onChange({ values: field.values.filter((_, n) => n !== i) })}>
                    <X className="h-3.5 w-3.5" aria-hidden="true" />
                  </button>
                )}
              </span>
            ))}
            <Button type="button" variant="ghost" size="sm" className="gap-1" onClick={() => onChange({ values: [...field.values, ""] })}>
              <Plus className="h-3.5 w-3.5" aria-hidden="true" /> Another prefix
            </Button>
          </>
        ) : list && list.length > 0 ? (
          <Select aria-labelledby={`${id}-label`} value={value} onChange={(e) => onChange({ values: [e.target.value] })} className="w-80 max-w-full">
            <option value="">Choose…</option>
            {list.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            {value && !list.some((o) => o.value === value) && <option value={value}>{value} (not in the catalogue)</option>}
          </Select>
        ) : (
          <Input aria-labelledby={`${id}-label`} className="w-80 max-w-full font-mono" value={value}
            inputMode={field.kind === "network" ? "numeric" : undefined}
            placeholder={{ destination: "+91", sender: "ACME", network: "405", text: "OTP", product: "transactional", login: "acme1", account: "acme" }[field.kind]}
            onChange={(e) => onChange({ values: [e.target.value] })} />
        )}
        {field.kind === "text" && <span className="text-sm text-muted-foreground">anywhere in the text</span>}
      </div>

      <label className="flex items-center gap-2 text-sm">
        <Checkbox checked={field.except} onChange={(e) => onChange({ except: e.target.checked })} />
        <span>{field.kind === "text" ? "Except when the text contains this" : field.mode === "prefixes" ? "Except these" : "Except this"}</span>
      </label>
    </div>
  );
}

/**
 * The "Account tag" condition: has, has all of, has any of, has none of, or has no tag, with the tags chosen
 * from the Tags list (switched-off ones marked "off" -- they match nothing while off). Maps onto the
 * gateway's `equals`, `startsWithAny` (negated for none of) and `isNull`, see `toConditions`.
 */
function TagConditionRow({
  field,
  options,
  onChange,
  onRemove,
}: {
  field: GuidedField;
  options: GuidedOptions;
  onChange: (patch: Partial<GuidedField>) => void;
  onRemove: () => void;
}) {
  const id = "fw-tag";
  const mode = field.mode as TagMode;
  const chosen = field.values.filter(Boolean);
  const list = options.tags;
  const unknown = chosen.filter((v) => list.length > 0 && !list.some((o) => o.value === v));
  const offChosen = chosen.filter((v) => list.find((o) => o.value === v)?.enabled === false);

  return (
    <div className="space-y-2 rounded-lg border border-border p-4" data-testid="guided-tag">
      <div className="flex flex-wrap items-center gap-3">
        <span id={`${id}-label`} className="font-semibold">Account tag</span>
        <Segmented<TagMode>
          label="How to test the account's tags"
          value={mode}
          onChange={(next) => onChange({
            mode: next,
            values: next === "untagged" ? [""] : next === "has" ? [chosen[0] ?? ""] : chosen.length ? chosen : [""],
          })}
          options={TAG_MODES}
          fill
          className="order-last basis-full"
        />
        <button type="button" aria-label="Stop matching on account tag" onClick={onRemove}
          className="ml-auto rounded p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground">
          <X className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>

      {options.tagsAvailable === false ? (
        <p className="text-sm text-muted-foreground">{TAGS_NEED_GATEWAY}</p>
      ) : mode === "untagged" ? (
        <p className="text-sm text-muted-foreground">Matches accounts that carry no tag at all, their own or a parent&apos;s.</p>
      ) : mode === "has" ? (
        list.length > 0 ? (
          <Select aria-labelledby={`${id}-label`} value={chosen[0] ?? ""} onChange={(e) => onChange({ values: [e.target.value] })} className="w-80 max-w-full">
            <option value="">Choose a tag…</option>
            {list.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            {chosen[0] && !list.some((o) => o.value === chosen[0]) && <option value={chosen[0]}>{chosen[0]} (not in the tag list)</option>}
          </Select>
        ) : (
          <Input aria-labelledby={`${id}-label`} className="w-80 max-w-full font-mono" value={chosen[0] ?? ""} placeholder="premium"
            onChange={(e) => onChange({ values: [e.target.value] })} />
        )
      ) : (
        <div className="flex flex-wrap items-center gap-1.5">
          {chosen.map((v) => (
            <TagChip key={v} name={v}
              onRemove={() => onChange({ values: chosen.filter((x) => x !== v).length ? chosen.filter((x) => x !== v) : [""] })} />
          ))}
          {list.length > 0 ? (
            <Select aria-label="Add a tag to the list" value="" className="h-8 w-auto text-sm"
              onChange={(e) => e.target.value && onChange({ values: [...chosen, e.target.value] })}>
              <option value="">Add…</option>
              {list.filter((o) => !chosen.includes(o.value)).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </Select>
          ) : (
            <Input aria-label="Tags, separated by commas" className="w-80 max-w-full font-mono" value={chosen.join(",")} placeholder="premium,otp"
              onChange={(e) => onChange({ values: e.target.value.split(",") })} />
          )}
        </div>
      )}
      {mode === "has" && chosen[0] && <div><TagChip name={chosen[0]} /></div>}
      {unknown.length > 0 && (
        <p className="text-xs text-warning">
          {unknown.join(", ")} {unknown.length === 1 ? "is" : "are"} not in the tag list, so {unknown.length === 1 ? "it matches" : "they match"} no account.
        </p>
      )}
      {offChosen.length > 0 && (
        <p className="text-xs text-warning">
          {offChosen.join(", ")} {offChosen.length === 1 ? "is" : "are"} switched off on the Tags page, so {offChosen.length === 1 ? "it matches" : "they match"} nothing until switched back on.
        </p>
      )}
    </div>
  );
}
