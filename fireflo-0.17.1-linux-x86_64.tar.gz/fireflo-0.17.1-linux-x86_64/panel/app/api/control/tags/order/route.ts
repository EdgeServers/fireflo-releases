import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { reorderTags } from "@/lib/tags";

const TABLES = "app_tag";

/**
 * PUT: the whole order, `{ order: [name, …] }`, written as `seq` 1, 2, 3…. It must name every tag
 * once; a list from a stale page is refused rather than half applied.
 */
export async function PUT(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  let body: { order?: unknown };
  try {
    body = (await req.json()) as typeof body;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const order = Array.isArray(body.order) ? body.order.filter((n): n is string => typeof n === "string") : [];
  try {
    await reorderTags(order);
    return NextResponse.json({ data: { order } });
  } catch (err) {
    return configFailed("reorder tags", err);
  }
}
