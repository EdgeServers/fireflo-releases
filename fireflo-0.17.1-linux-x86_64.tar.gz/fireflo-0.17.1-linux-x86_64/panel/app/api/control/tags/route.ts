import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { createTag, listTagNames, listTags, tagsAvailable } from "@/lib/tags";

const TABLES = "app_tag, app_account_tag";

/**
 * GET: every account tag in order, with its account count and where it is used. `available: false`
 * on a database before gateway 0.17.0 (V1.133.0), so the page and the pickers can say so rather
 * than show a missing-table error. `?names=1` answers name, label, description, colour, order and
 * state alone, for pickers and chips.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  try {
    if (!(await tagsAvailable())) {
      return NextResponse.json({ data: { available: false, tags: [] } });
    }
    const namesOnly = req.nextUrl.searchParams.get("names") === "1";
    return NextResponse.json({
      data: { available: true, tags: namesOnly ? await listTagNames() : await listTags() },
    });
  } catch (err) {
    return configFailed("tags", err);
  }
}

/** POST: adds one tag, at the end of the order. `{ name, label, description?, color? }`. */
export async function POST(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  let body: { name?: unknown; label?: unknown; description?: unknown; color?: unknown };
  try {
    body = (await req.json()) as typeof body;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  try {
    if (!(await tagsAvailable())) {
      return NextResponse.json({ error: "Account tags need gateway 0.17.0." }, { status: 409 });
    }
    const name = typeof body.name === "string" ? body.name : "";
    await createTag({
      name,
      label: typeof body.label === "string" ? body.label : "",
      description: typeof body.description === "string" ? body.description : "",
      color: typeof body.color === "string" ? body.color : undefined,
    });
    return NextResponse.json({ data: { name } });
  } catch (err) {
    return configFailed("add tag", err);
  }
}
