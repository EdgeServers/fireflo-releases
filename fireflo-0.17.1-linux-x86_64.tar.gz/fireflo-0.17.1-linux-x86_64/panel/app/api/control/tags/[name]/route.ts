import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { TagInUse, deleteTag, updateTag } from "@/lib/tags";

const TABLES = "app_tag, app_account_tag";

type Params = { params: Promise<{ name: string }> };

/**
 * PATCH: a tag's label, description, colour and whether it is on,
 * `{ label?, description?, color?, enabled? }`. The name never changes.
 */
export async function PATCH(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const name = decodeURIComponent((await params).name);
  let body: { label?: unknown; description?: unknown; color?: unknown; enabled?: unknown };
  try {
    body = (await req.json()) as typeof body;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  try {
    const found = await updateTag(name, {
      label: typeof body.label === "string" ? body.label : undefined,
      description: typeof body.description === "string" ? body.description : undefined,
      color: typeof body.color === "string" ? body.color : undefined,
      enabled: typeof body.enabled === "boolean" ? body.enabled : undefined,
    });
    return found
      ? NextResponse.json({ data: { name } })
      : NextResponse.json({ error: `No tag called '${name}'.` }, { status: 404 });
  } catch (err) {
    return configFailed("update tag", err);
  }
}

/**
 * DELETE: removes a tag and its assignments, refused (409, saying where) while a routing rule, a
 * price rule, a filter or a price list names it.
 */
export async function DELETE(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const name = decodeURIComponent((await params).name);
  try {
    const accounts = await deleteTag(name);
    return accounts === null
      ? NextResponse.json({ error: `No tag called '${name}'.` }, { status: 404 })
      : NextResponse.json({ data: { name, accounts } });
  } catch (err) {
    if (err instanceof TagInUse) {
      return NextResponse.json({ error: err.message }, { status: 409 });
    }
    return configFailed("delete tag", err);
  }
}
