import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { accountTags } from "@/lib/tags";

type Params = { params: Promise<{ id: string }> };

/**
 * GET: one account's tags -- its own, the ones it carries from a units parent, what rules and prices
 * see, and how many units sub-accounts carry its tags. Operator only. Saving goes through the
 * account catalogue PUT (`tagsAdd`, `tagsRemove`), in the same transaction as the account.
 */
export async function GET(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite("app_tag, app_account_tag");
  if (refused) {
    return refused;
  }
  const id = decodeURIComponent((await params).id).trim();
  if (!id) {
    return NextResponse.json({ error: "No account given." }, { status: 400 });
  }
  try {
    return NextResponse.json({ data: await accountTags(id) });
  } catch (err) {
    return configFailed("account tags", err);
  }
}
