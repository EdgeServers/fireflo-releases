import { PageHeader } from "@/components/ui/page-header";
import { TagsClient } from "@/components/TagsClient";
import { ApplyNowButton } from "@/components/ApplyNowButton";

export default function TagsPage() {
  return (
    <>
      <PageHeader
        title="Tags"
        description="Names put on accounts, which routing rules, filters and prices can test."
        actions={<ApplyNowButton />}
      />
      <TagsClient />
    </>
  );
}
