/**
 * EP-09 Rating & Billing
 * US-09.06 Product-specific prices and the product a message carries
 *
 * The 2026-10-15 staging reproduction, as tests: a price saved under a product reaches only the
 * messages whose login carries that product (RateSnapshot.rulesFor shows a product-less message the
 * any-product rules alone), and since 0.12.14 an SMPP session bound before the login got its product
 * follows the change without rebinding (BasicSmppSessionContext.followCredential).
 *
 * Every case builds its own account, logins, product and rules with the per-worker seed, so nothing
 * here depends on another case's state. The baseline [*] any-product rule would price a product-less
 * message at 0.0100, so the cases that need "unrated" switch it off for their duration and put it
 * back; the gateway project runs one worker, and the panel projects do not send messages, so the
 * window is harmless. File-mode and restart-bound cases stay manual.
 */
import { expect, test } from "../../fixtures";
import type { Db, E2EEnv, Seed } from "../../fixtures";
import { awaitGatewayAdopts, ops, rest } from "../../fixtures/gateway";
import { VENDORS } from "../../fixtures/gateway-rig";
import { BASELINE } from "../../fixtures/seed";
import { connectEsme } from "../../fixtures/smpp";
import { gatewayLog } from "../../fixtures/trace";
import { tc } from "../../support/tc";

const TEN_AUD = 100_000; // 10.0000 in minor units ×10⁴
const PRODUCT_PRICE = "0.1100";
const PRODUCT_PRICE_UNITS = 1100;

interface Rig {
  account: string;
  product: string;
  http: { systemId: string; password: string; id: number };
  smpp: { systemId: string; password: string; id: number };
}

/** A product, an account with 10 AUD, an HTTP and an SMPP login (product blank unless told), and a product rule. */
async function rig(db: Db, seed: Seed, opts: { loginProduct?: string | null; rules?: { scope?: string; product: string | null; amount: string }[]; withProductRule?: boolean } = {}): Promise<Rig> {
  const product = seed.name("pro").replace(/[^a-z0-9-]/g, "-").slice(0, 20);
  await db.q(`INSERT INTO app_product (name, label, description, enabled, whitelist_enabled) VALUES ($1, $1, 'US-09.06', true, true) ON CONFLICT (name) DO NOTHING`, [product]);
  const account = await seed.account({ label: "US-09.06" });
  await seed.balance({ accountId: account, balance: TEN_AUD, currency: BASELINE.currency });
  const http = await seed.credential({ type: "HTTP", accountId: account, product: opts.loginProduct ?? null });
  const smpp = await seed.credential({ type: "SMPP", accountId: account, product: opts.loginProduct ?? null });
  //"__own__" stands for the rig's own product, which does not exist before this runs
  const rules = (opts.rules ?? (opts.withProductRule === false ? [] : [{ product, amount: PRODUCT_PRICE }]))
    .map((r) => ({ ...r, product: r.product === "__own__" ? product : r.product }));
  for (const r of rules) {
    const scope = r.scope ?? account;
    const seq = Number(await db.scalar("SELECT COALESCE(max(seq), 0) + 1 FROM app_rate_rule WHERE scope = $1", [scope]));
    await db.q(
      `INSERT INTO app_rate_rule (scope, seq, amount, product, currency, label, enabled) VALUES ($1, $2, $3::numeric, $4, $5, 'US-09.06', true)`,
      [scope, seq, r.amount, r.product, BASELINE.currency],
    );
  }
  seed.cleanup(async () => {
    await db.q("DELETE FROM app_rate_rule WHERE label = 'US-09.06' AND (scope = $1 OR product = $2 OR scope = '*')", [account, product]);
    await db.q("UPDATE app_credential SET product = NULL WHERE product = $1", [product]);
    await db.q("DELETE FROM app_product WHERE name = $1", [product]);
  });
  //wait until the gateway prices under the first rule's product (any-product when it has none);
  //the baseline * rule prices every other product, so "nothing priced" is never a usable signal
  if (rules.length) await adopt(account, rules[0].product ?? "", true);
  return { account, product, http, smpp };
}

/** Waits until the gateway's own answer shows the account's rules (or none) in force. */
async function adopt(account: string, product: string, expectRule: boolean) {
  await awaitGatewayAdopts(async () => {
    const q: Record<string, string> = { account, to: "61400000001", content: "hi" };
    if (product) q.product = product;
    const r = await explain(q);
    const priced = (r.body as { data?: { price?: unknown } }).data?.price != null;
    return r.status === 200 && priced === expectRule;
  });
}

/** A property saved to app_config reaches the gateway on its next poll (2 s in the rig); the reload nudges it. */
async function settingAdopted() {
  await ops().reload().catch(() => undefined);
  await new Promise((r) => setTimeout(r, 3_000));
}

async function explain(q: Record<string, string>) {
  return ops().get<{ data: Record<string, unknown> }>(`/ops/rating/explain?${new URLSearchParams(q)}`);
}

async function setLoginProduct(db: Db, credentialId: number, product: string | null, account: string) {
  await db.q("UPDATE app_credential SET product = $1, updated_at = now() WHERE id = $2", [product, credentialId]);
  await awaitGatewayAdopts(async () => {
    const r = await explain({ account, to: "61400000001", content: "hi" });
    const data = (r.body as { data?: { login_products?: string[] } }).data;
    const carried = data?.login_products ?? [];
    return product ? carried.includes(product) : !carried.includes("");
  });
}

/** Switches the baseline [*] any-product rule off for this test and back on afterwards. */
async function withoutDefaultPrice(db: Db, seed: Seed) {
  await db.q("UPDATE app_rate_rule SET enabled = false WHERE label = 'qa baseline price'");
  seed.cleanup(async () => {
    await db.q("UPDATE app_rate_rule SET enabled = true WHERE label = 'qa baseline price'");
    await ops().reload().catch(() => undefined);
  });
  await awaitGatewayAdopts(async () => {
    const r = await explain({ to: "61400000001", content: "hi" });
    return r.status === 200 && (r.body as { data?: { price?: unknown } }).data?.price == null;
  });
}

interface SubmitRow { product: string | null; price: string | null; price_rule_id: string | null; billed_units: number | null; cost: string | null; cost_rule_id: string | null; margin_status: string | null }

async function submitRow(db: Db, id: string): Promise<SubmitRow> {
  await db.waitForRow("SELECT 1 FROM cdr_submit WHERE gateway_msg_id = $1", [id], { what: `cdr_submit for ${id}` });
  return db.one<SubmitRow>(
    "SELECT product, price::text, price_rule_id::text, billed_units, cost::text, cost_rule_id::text, margin_status FROM cdr_submit WHERE gateway_msg_id = $1 AND part_no = 1", [id]);
}

async function balanceOf(db: Db, account: string) {
  return db.one<{ balance: string; reserved: string }>("SELECT balance::text, reserved::text FROM account_balance WHERE account_id = $1", [account]);
}

/** cdr_submit money columns are bigint minor units (×10⁴): 0.1100 is 1100. */
function priceUnits(row: SubmitRow): number | null {
  return row.price == null ? null : Math.round(Number(row.price));
}

async function sendHttp(login: { systemId: string; password: string }, body: Record<string, unknown> = {}) {
  const r = await rest(login).send({ to: "61400000001", from: "QATEST", content: "US-09.06", ...body });
  return { status: r.status, id: (r.body as { data?: { messageId?: string } }).data?.messageId ?? null, body: r.body as Record<string, unknown> };
}

function bind(env: E2EEnv, login: { systemId: string; password: string }, systemType?: string) {
  return connectEsme({ host: env.smppHost, port: env.smppPort, systemId: login.systemId, password: login.password, systemType });
}

test.describe("SC-09.06.01 Product rule, product-less login, then the login gets the product (HTTP)", () => {
  test(...tc("TC-09.06.01-P01", "A product-less login is unrated and undebited; once the login carries the product the next HTTP message prices and debits", { requires: ["gateway", "trace"] }), async ({ db, seed, tcx }) => {
    await withoutDefaultPrice(db, seed);
    const r = await rig(db, seed);
    const mark = gatewayLog.mark();

    // the anti-vacuity half first: the login carries no product, so the product rule must not reach it
    const first = await sendHttp(r.http);
    expect(first.status, JSON.stringify(first.body)).toBe(200);
    const row1 = await submitRow(db, first.id!);
    expect(row1.product).toBeNull();
    expect(row1.price).toBeNull();
    expect(row1.price_rule_id).toBeNull();
    expect(row1.billed_units).toBe(1);
    const bal1 = await balanceOf(db, r.account);
    expect(Number(bal1.balance)).toBe(TEN_AUD);
    expect(Number(bal1.reserved)).toBe(0);
    await gatewayLog.waitFor(new RegExp(`message\\.unrated ingress=rest account:${r.account} product:null`), mark);

    await setLoginProduct(db, r.http.id, r.product, r.account);
    const second = await sendHttp(r.http);
    expect(second.status).toBe(200);
    const row2 = await submitRow(db, second.id!);
    expect(row2.product).toBe(r.product);
    expect(priceUnits(row2)).toBe(PRODUCT_PRICE_UNITS);
    expect(row2.price_rule_id).not.toBeNull();
    await expect.poll(async () => Number((await balanceOf(db, r.account)).reserved), { timeout: 15_000 }).toBeGreaterThan(0);
    const bal2 = await balanceOf(db, r.account);
    expect(Number(bal2.balance) + Number(bal2.reserved)).toBe(TEN_AUD);
    tcx.note(`before: product null price null balance ${bal1.balance}/${bal1.reserved}; after: ${row2.product} ${row2.price} rule ${row2.price_rule_id}, balance ${bal2.balance} reserved ${bal2.reserved}`);
  });

  test(...tc("TC-09.06.01-N01", "With the refuse switch on, the product-less login is refused instead of leaking", { requires: ["gateway"] }), async ({ db, seed, env, tcx }) => {
    await withoutDefaultPrice(db, seed);
    const r = await rig(db, seed);
    await seed.config("smsg.rating.unrated.refuse", "true");
    await settingAdopted();
    const http = await sendHttp(r.http);
    expect(http.status).toBe(403);
    const esme = await bind(env, r.smpp);
    try {
      const s = await esme.submit({ text: "US-09.06 refuse" });
      expect(s.status).toBe(0x418);
    } finally {
      await esme.unbind();
    }
    //cdr_rejected is written through the sink's queue, a moment after the refusal
    await expect.poll(() => db.count("cdr_rejected", "account_id = $1 AND reason = 'unrated'", [r.account]), { timeout: 15_000 }).toBe(2);
    const rejected = 2;
    expect(await db.count("cdr_submit", "account_id = $1", [r.account])).toBe(0);
    const bal = await balanceOf(db, r.account);
    expect(Number(bal.balance)).toBe(TEN_AUD);
    tcx.note(`HTTP ${http.status} ${JSON.stringify(http.body).slice(0, 120)}; SMPP 0x418; cdr_rejected unrated ×${rejected}; balance ${bal.balance}`);
  });

  test(...tc("TC-09.06.01-N02", "The quote agrees with the send: a product-less login is quoted ND, never 0 and never the product price", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    await withoutDefaultPrice(db, seed);
    const r = await rig(db, seed);
    const before = await rest(r.http).rate({ to: "61400000001", content: "hello" });
    expect(before.status).toBe(200);
    expect(String((before.body as { data?: { unit_rate?: unknown } }).data?.unit_rate ?? (before.body as { unit_rate?: unknown }).unit_rate)).toBe("ND");
    await setLoginProduct(db, r.http.id, r.product, r.account);
    const after = await rest(r.http).rate({ to: "61400000001", content: "hello" });
    const body = (after.body as { data?: Record<string, unknown> }).data ?? (after.body as Record<string, unknown>);
    expect(Number(body.unit_rate)).toBeCloseTo(0.11, 4);
    expect(Number(body.submit_sm_count)).toBe(1);
    const bal = await balanceOf(db, r.account);
    expect(Number(bal.balance)).toBe(TEN_AUD);
    tcx.note(`rate before: ND; after: ${body.unit_rate} × ${body.submit_sm_count}; balance ${bal.balance} untouched`);
  });
});

test.describe("SC-09.06.02 SMPP session bound before the login got its product", () => {
  test(...tc("TC-09.06.02-P01", "A session bound without system_type before the login got its product prices on its next message without rebinding (0.12.14)", { requires: ["gateway", "trace"] }), async ({ db, seed, env, tcx }) => {
    await withoutDefaultPrice(db, seed);
    const r = await rig(db, seed);
    const mark = gatewayLog.mark();
    const esme = await bind(env, r.smpp);
    try {
      const a = await esme.submit({ text: "US-09.06 A" });
      expect(a.status).toBe(0);
      const rowA = await submitRow(db, a.messageId!);
      expect(rowA.product).toBeNull();
      expect(rowA.price).toBeNull();
      await gatewayLog.waitFor(new RegExp(`message\\.unrated ingress=smppserver account:${r.account} product:null`), mark);

      await setLoginProduct(db, r.smpp.id, r.product, r.account);
      // the same session: no unbind, no rebind
      expect(esme.bound).toBe(true);
      const b = await esme.submit({ text: "US-09.06 B" });
      expect(b.status, `submit_sm_resp 0x${b.status.toString(16)}`).toBe(0);
      const rowB = await submitRow(db, b.messageId!);
      expect(rowB.product).toBe(r.product);
      expect(priceUnits(rowB)).toBe(PRODUCT_PRICE_UNITS);
      await gatewayLog.waitFor(new RegExp(`Session ${r.smpp.systemId} \\(${r.account}\\) now rates as product '${r.product}' \\(was ''\\)`), mark);
      await expect.poll(async () => Number((await balanceOf(db, r.account)).reserved), { timeout: 15_000 }).toBeGreaterThan(0);
      tcx.note(`A: product null price null; B on the same session: ${rowB.product} ${rowB.price}; log 'now rates as product'`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-09.06.02-P02", "A fresh bind after the product change prices from its first message", { requires: ["gateway", "trace"] }), async ({ db, seed, env, tcx }) => {
    await withoutDefaultPrice(db, seed);
    const r = await rig(db, seed, { loginProduct: null });
    await setLoginProduct(db, r.smpp.id, r.product, r.account);
    const mark = gatewayLog.mark();
    const esme = await bind(env, r.smpp);
    try {
      const s = await esme.submit({ text: "US-09.06 fresh" });
      expect(s.status).toBe(0);
      const row = await submitRow(db, s.messageId!);
      expect(row.product).toBe(r.product);
      expect(priceUnits(row)).toBe(PRODUCT_PRICE_UNITS);
      const unrated = gatewayLog.grep(new RegExp(`message\\.unrated.*account:${r.account}`), mark);
      expect(unrated.length).toBe(0);
      tcx.note(`first message on a fresh bind: ${row.product} ${row.price}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-09.06.02-N01", "A bind that named a system_type keeps it when the login's product changes", { requires: ["gateway", "trace"] }), async ({ db, seed, env, tcx }) => {
    const otp = seed.name("OTP").toUpperCase().replace(/[^A-Z0-9-]/g, "-").slice(0, 20);
    await db.q(`INSERT INTO app_product (name, label, description, enabled, whitelist_enabled) VALUES ($1, $1, 'US-09.06', true, true) ON CONFLICT (name) DO NOTHING`, [otp]);
    seed.cleanup(async () => { await db.q("DELETE FROM app_rate_rule WHERE product = $1", [otp]); await db.q("DELETE FROM app_product WHERE name = $1", [otp]); });
    const r = await rig(db, seed, { rules: [{ product: otp, amount: "0.0500" }, { product: "__own__", amount: PRODUCT_PRICE }] });
    const mark = gatewayLog.mark();
    const esme = await bind(env, r.smpp, otp.toLowerCase());
    try {
      const a = await esme.submit({ text: "US-09.06 otp A" });
      expect(a.status).toBe(0);
      const rowA = await submitRow(db, a.messageId!);
      expect(rowA.product).toBe(otp);
      expect(priceUnits(rowA)).toBe(500);
      await setLoginProduct(db, r.smpp.id, r.product, r.account);
      const b = await esme.submit({ text: "US-09.06 otp B" });
      expect(b.status).toBe(0);
      const rowB = await submitRow(db, b.messageId!);
      expect(rowB.product).toBe(otp);
      expect(priceUnits(rowB)).toBe(500);
      expect(gatewayLog.grep(new RegExp(`Session ${r.smpp.systemId} .*now rates as product`), mark).length).toBe(0);
      tcx.note(`system_type '${otp.toLowerCase()}' → product ${rowA.product} 0.0500 before and after the login changed to ${r.product}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc.manual("TC-09.06.02-N02", "A login missing from the republished snapshot keeps its last product rather than falling to none", "file configuration mode: the rig runs FIREFLO_CONFIG_SOURCE=db; covered at unit level by BasicSmppSessionContextTest"));
});

test.describe("SC-09.06.03 Any-product fallback and the [*] scope under product semantics", () => {
  test(...tc("TC-09.06.03-P01", "A product-specific rule is read before the account's any-product rule; a product-less message sees only the any-product rule", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    const r = await rig(db, seed, { rules: [{ product: null, amount: "0.0100" }, { product: "__own__", amount: PRODUCT_PRICE }] });
    const withProduct = await seed.credential({ type: "HTTP", accountId: r.account, product: r.product });
    const withStandard = await seed.credential({ type: "HTTP", accountId: r.account, product: BASELINE.product });
    await setLoginProduct(db, withProduct.id, r.product, r.account);
    const rows = [] as SubmitRow[];
    for (const login of [withProduct, r.http, withStandard]) {
      const s = await sendHttp(login);
      expect(s.status).toBe(200);
      rows.push(await submitRow(db, s.id!));
    }
    expect(priceUnits(rows[0])).toBe(1100);
    expect(rows[0].product).toBe(r.product);
    expect(priceUnits(rows[1])).toBe(100);
    expect(rows[1].product).toBeNull();
    expect(priceUnits(rows[2])).toBe(100);
    expect(rows[2].product).toBe(BASELINE.product);
    expect(rows[1].price_rule_id).toBe(rows[2].price_rule_id);
    expect(rows[0].price_rule_id).not.toBe(rows[1].price_rule_id);
    tcx.note(`test-pro 0.1100 (rule ${rows[0].price_rule_id}); none 0.0100 and standard 0.0100 (rule ${rows[1].price_rule_id})`);
  });

  test(...tc("TC-09.06.03-P02", "A [*] rule restricted to a product prices that product on accounts with no rules and nothing else", { requires: ["gateway", "trace"] }), async ({ db, seed, tcx }) => {
    await withoutDefaultPrice(db, seed);
    const r = await rig(db, seed, { rules: [{ scope: "*", product: "__own__", amount: "0.0500" }] });
    const withProduct = await seed.credential({ type: "HTTP", accountId: r.account, product: r.product });
    const withStandard = await seed.credential({ type: "HTTP", accountId: r.account, product: BASELINE.product });
    await setLoginProduct(db, withProduct.id, r.product, r.account);
    const mark = gatewayLog.mark();
    const a = await sendHttp(withProduct);
    const rowA = await submitRow(db, a.id!);
    expect(priceUnits(rowA)).toBe(500);
    const rule = await db.one<{ scope: string }>("SELECT scope FROM app_rate_rule WHERE id = $1::bigint", [rowA.price_rule_id]);
    expect(rule.scope).toBe("*");
    const b = await sendHttp(withStandard);
    const rowB = await submitRow(db, b.id!);
    expect(rowB.price).toBeNull();
    await gatewayLog.waitFor(new RegExp(`message\\.unrated ingress=rest account:${r.account} product:${BASELINE.product}`), mark);
    tcx.note(`[*] ${r.product} 0.0500 priced the ${r.product} login; the standard login went unrated`);
  });

  test(...tc("TC-09.06.03-P03", "Own rules and the [*] fallback merge under one product filter", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    // the baseline [*] 0.0100 any-product rule is the fallback here
    const r = await rig(db, seed);
    const withStandard = await seed.credential({ type: "HTTP", accountId: r.account, product: BASELINE.product });
    const withProduct = await seed.credential({ type: "HTTP", accountId: r.account, product: r.product });
    await setLoginProduct(db, withProduct.id, r.product, r.account);
    const s1 = await submitRow(db, (await sendHttp(withStandard)).id!);
    const s2 = await submitRow(db, (await sendHttp(withProduct)).id!);
    const s3 = await submitRow(db, (await sendHttp(r.http)).id!);
    expect(priceUnits(s1)).toBe(100);
    expect(priceUnits(s2)).toBe(1100);
    expect(priceUnits(s3)).toBe(100);
    const scopes = await db.q<{ id: string; scope: string }>("SELECT id::text, scope FROM app_rate_rule WHERE id = ANY($1::bigint[])", [[s1.price_rule_id, s2.price_rule_id, s3.price_rule_id]]);
    const scopeOf = (id: string | null) => scopes.find((x) => x.id === id)?.scope;
    expect(scopeOf(s1.price_rule_id)).toBe("*");
    expect(scopeOf(s2.price_rule_id)).toBe(r.account);
    expect(scopeOf(s3.price_rule_id)).toBe("*");
    tcx.note(`standard → [*] 0.0100; ${r.product} → own 0.1100; none → [*] 0.0100`);
  });

  test(...tc("TC-09.06.03-N01", "A vendor cost rule restricted to a product never costs another product", { requires: ["gateway", "edgesmsc"] }), async ({ db, seed, tcx }) => {
    const r = await rig(db, seed, { rules: [{ product: null, amount: "0.0100" }] });
    await db.q(`INSERT INTO app_rate_rule (scope, seq, amount, product, currency, label, enabled) VALUES ($1, 99, 0.0050, $2, $3, 'US-09.06', true)`, [VENDORS.a, r.product, BASELINE.currency]);
    seed.cleanup(async () => { await db.q("DELETE FROM app_rate_rule WHERE scope = $1 AND label = 'US-09.06'", [VENDORS.a]); });
    await awaitGatewayAdopts(async () => {
      const x = await explain({ account: r.account, product: r.product, vendor: VENDORS.a, to: "61400000001", content: "hi" });
      return (x.body as { data?: { cost?: unknown } }).data?.cost != null;
    });
    const withStandard = await seed.credential({ type: "HTTP", accountId: r.account, product: BASELINE.product });
    const withProduct = await seed.credential({ type: "HTTP", accountId: r.account, product: r.product });
    await setLoginProduct(db, withProduct.id, r.product, r.account);
    const s1 = await submitRow(db, (await sendHttp(withStandard)).id!);
    const s2 = await submitRow(db, (await sendHttp(withProduct)).id!);
    // the baseline may or may not carry a vendor cost for every product; what this proves is that the
    // product-restricted cost reached only the product's message
    expect(s2.cost_rule_id).not.toBeNull();
    expect(Math.round(Number(s2.cost))).toBe(50);
    expect(s1.cost_rule_id).not.toBe(s2.cost_rule_id);
    tcx.note(`standard: cost ${s1.cost} rule ${s1.cost_rule_id} margin_status ${s1.margin_status}; ${r.product}: cost ${s2.cost} rule ${s2.cost_rule_id}`);
  });
});

test.describe("SC-09.06.04 The REST product field and the catalogue's spelling", () => {
  test(...tc("TC-09.06.04-P01", "A product on the login's allowed_products selects that product's price", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    const r = await rig(db, seed, { rules: [{ product: null, amount: "0.0100" }, { product: "__own__", amount: PRODUCT_PRICE }] });
    await db.q("UPDATE app_credential SET product = $1, allowed_products = ARRAY[$2]::text[] WHERE id = $3", [BASELINE.product, r.product, r.http.id]);
    await setLoginProduct(db, r.http.id, BASELINE.product, r.account);
    const named = await sendHttp(r.http, { product: r.product });
    expect(named.status, JSON.stringify(named.body)).toBe(200);
    const bare = await sendHttp(r.http);
    const rowNamed = await submitRow(db, named.id!);
    const rowBare = await submitRow(db, bare.id!);
    expect(rowNamed.product).toBe(r.product);
    expect(priceUnits(rowNamed)).toBe(1100);
    expect(rowBare.product).toBe(BASELINE.product);
    expect(priceUnits(rowBare)).toBe(100);
    expect(rowNamed.price_rule_id).not.toBe(rowBare.price_rule_id);
    tcx.note(`product=${r.product} → 0.1100 (rule ${rowNamed.price_rule_id}); without → ${BASELINE.product} 0.0100 (rule ${rowBare.price_rule_id})`);
  });

  test(...tc("TC-09.06.04-P02", "A product typed in another case is recorded and priced in the catalogue's spelling", { requires: ["gateway"] }), async ({ db, seed, env, tcx }) => {
    const otp = seed.name("OTP").toUpperCase().replace(/[^A-Z0-9-]/g, "-").slice(0, 20);
    await db.q(`INSERT INTO app_product (name, label, description, enabled, whitelist_enabled) VALUES ($1, $1, 'US-09.06', true, true) ON CONFLICT (name) DO NOTHING`, [otp]);
    seed.cleanup(async () => { await db.q("DELETE FROM app_rate_rule WHERE product = $1", [otp]); await db.q("DELETE FROM app_product WHERE name = $1", [otp]); });
    const r = await rig(db, seed, { rules: [{ product: otp, amount: "0.0500" }] });
    await db.q("UPDATE app_credential SET allowed_products = ARRAY[$1]::text[] WHERE id = $2", [otp, r.http.id]);
    await awaitGatewayAdopts(async () => {
      const x = await explain({ account: r.account, product: otp.toLowerCase(), to: "61400000001", content: "hi" });
      return (x.body as { data?: { product?: string } }).data?.product === otp;
    });
    const http = await sendHttp(r.http, { product: otp.toLowerCase() });
    expect(http.status, JSON.stringify(http.body)).toBe(200);
    const rowHttp = await submitRow(db, http.id!);
    const esme = await bind(env, r.smpp, otp.charAt(0) + otp.slice(1).toLowerCase());
    try {
      const s = await esme.submit({ text: "US-09.06 Otp" });
      expect(s.status).toBe(0);
      const rowSmpp = await submitRow(db, s.messageId!);
      expect(rowHttp.product).toBe(otp);
      expect(rowSmpp.product).toBe(otp);
      expect(priceUnits(rowHttp)).toBe(500);
      expect(priceUnits(rowSmpp)).toBe(500);
      tcx.note(`'${otp.toLowerCase()}' (REST) and '${otp.charAt(0) + otp.slice(1).toLowerCase()}' (system_type) both recorded as ${otp} at 0.0500`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-09.06.04-N01", "A product the login may not name is 403 productNotAllowed and costs nothing", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    const otp = seed.name("OTP").toUpperCase().replace(/[^A-Z0-9-]/g, "-").slice(0, 20);
    await db.q(`INSERT INTO app_product (name, label, description, enabled, whitelist_enabled) VALUES ($1, $1, 'US-09.06', true, true) ON CONFLICT (name) DO NOTHING`, [otp]);
    seed.cleanup(async () => { await db.q("DELETE FROM app_rate_rule WHERE product = $1", [otp]); await db.q("DELETE FROM app_product WHERE name = $1", [otp]); });
    const r = await rig(db, seed, { rules: [{ product: otp, amount: "0.0500" }] });
    await db.q("UPDATE app_credential SET product = $1, allowed_products = ARRAY[$2]::text[] WHERE id = $3", [BASELINE.product, r.product, r.http.id]);
    await setLoginProduct(db, r.http.id, BASELINE.product, r.account);
    const listed = await sendHttp(r.http, { product: otp });
    expect(listed.status).toBe(403);
    expect(JSON.stringify(listed.body)).toContain(otp);
    const bareLogin = await seed.credential({ type: "HTTP", accountId: r.account, product: BASELINE.product });
    await setLoginProduct(db, bareLogin.id, BASELINE.product, r.account);
    const unlisted = await sendHttp(bareLogin, { product: r.product });
    expect(unlisted.status).toBe(403);
    expect(await db.count("cdr_submit", "account_id = $1", [r.account])).toBe(0);
    const bal = await balanceOf(db, r.account);
    expect(Number(bal.balance)).toBe(TEN_AUD);
    tcx.note(`listed-for-another: ${listed.status} ${JSON.stringify(listed.body).slice(0, 100)}; no list: ${unlisted.status}; no rows, balance ${bal.balance}`);
  });

  test(...tc("TC-09.06.04-N02", "A product the gateway does not sell is 403 productNotSold on send and on rate alike", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    //allowed_products is kept in app_credential_product with a foreign key to the catalogue, so a
    //name that was never a product cannot be listed; "not sold" is a product that was sold and is
    //no longer enabled -- the shape a catalogue clean-up leaves behind
    const legacy = seed.name("legacy").replace(/[^a-z0-9-]/g, "-").slice(0, 20);
    await db.q(`INSERT INTO app_product (name, label, description, enabled, whitelist_enabled) VALUES ($1, $1, 'US-09.06', true, true) ON CONFLICT (name) DO NOTHING`, [legacy]);
    seed.cleanup(async () => { await db.q("UPDATE app_credential SET allowed_products = NULL WHERE $1 = ANY(allowed_products)", [legacy]); await db.q("DELETE FROM app_product WHERE name = $1", [legacy]); });
    const r = await rig(db, seed, { withProductRule: false });
    await seed.config("smsg.restapi.product.required", "true");
    await db.q("UPDATE app_credential SET allowed_products = ARRAY[$1]::text[] WHERE id = $2", [legacy, r.http.id]);
    await db.q("UPDATE app_product SET enabled = false WHERE name = $1", [legacy]);
    await settingAdopted();
    const send = await sendHttp(r.http, { product: legacy });
    const quote = await rest(r.http).rate({ to: "61400000001", content: "hi", product: legacy });
    expect(send.status).toBe(403);
    expect(quote.status).toBe(403);
    expect(JSON.stringify(send.body)).toEqual(JSON.stringify(quote.body));
    expect(await db.count("cdr_submit", "account_id = $1", [r.account])).toBe(0);
    tcx.note(`send ${send.status} / rate ${quote.status}: ${JSON.stringify(send.body).slice(0, 140)}`);
  });

  test(...tc("TC-09.06.04-N03", "A quote for a product spelt in another case prices as the send would", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    const otp = seed.name("OTP").toUpperCase().replace(/[^A-Z0-9-]/g, "-").slice(0, 20);
    await db.q(`INSERT INTO app_product (name, label, description, enabled, whitelist_enabled) VALUES ($1, $1, 'US-09.06', true, true) ON CONFLICT (name) DO NOTHING`, [otp]);
    seed.cleanup(async () => { await db.q("DELETE FROM app_rate_rule WHERE product = $1", [otp]); await db.q("DELETE FROM app_product WHERE name = $1", [otp]); });
    const r = await rig(db, seed, { rules: [{ product: otp, amount: "0.0500" }] });
    await db.q("UPDATE app_credential SET allowed_products = ARRAY[$1]::text[] WHERE id = $2", [otp, r.http.id]);
    await awaitGatewayAdopts(async () => {
      const x = await explain({ account: r.account, product: otp.toLowerCase(), to: "61400000001", content: "hi" });
      return (x.body as { data?: { price?: unknown } }).data?.price != null;
    });
    const quote = await rest(r.http).rate({ to: "61400000001", content: "hi", product: otp.toLowerCase() });
    const body = (quote.body as { data?: Record<string, unknown> }).data ?? (quote.body as Record<string, unknown>);
    expect(quote.status).toBe(200);
    expect(Number(body.unit_rate), `unit_rate ${String(body.unit_rate)} -- the 0.12.13 quote answered ND here`).toBeCloseTo(0.05, 4);
    const send = await sendHttp(r.http, { product: otp.toLowerCase() });
    const row = await submitRow(db, send.id!);
    expect(priceUnits(row)).toBe(500);
    tcx.note(`rate?product=${otp.toLowerCase()} → ${body.unit_rate}; send recorded ${row.product} ${row.price}`);
  });
});

test.describe("SC-09.06.05 The explain endpoint resolves the product as ingress does", () => {
  const data = (r: { body: unknown }) => (r.body as { data: Record<string, unknown> }).data;

  test(...tc("TC-09.06.05-P01", "A blank product is filled from the account's login and the answer says so", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    const r = await rig(db, seed, { loginProduct: null });
    await db.q("UPDATE app_credential SET product = $1 WHERE id = ANY($2::int[])", [r.product, [r.http.id, r.smpp.id]]);
    await setLoginProduct(db, r.http.id, r.product, r.account);
    const x = data(await explain({ account: r.account, to: "61400000000", content: "hi" }));
    expect(x.product).toBe(r.product);
    expect(x.product_from).toBe("login");
    expect(x.login_products).toEqual([r.product]);
    expect(x.logins_without_product).toEqual([]);
    const price = x.price as { rate: string; scope: string } | null;
    expect(price?.rate).toBe(PRODUCT_PRICE);
    expect(price?.scope).toBe(r.account);
    tcx.note(`product ${x.product} from ${x.product_from}; price ${price?.rate} scope ${price?.scope}`);
  });

  test(...tc("TC-09.06.05-P02", "A typed product wins and is spelt as the catalogue spells it", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    const otp = seed.name("OTP").toUpperCase().replace(/[^A-Z0-9-]/g, "-").slice(0, 20);
    await db.q(`INSERT INTO app_product (name, label, description, enabled, whitelist_enabled) VALUES ($1, $1, 'US-09.06', true, true) ON CONFLICT (name) DO NOTHING`, [otp]);
    seed.cleanup(async () => { await db.q("DELETE FROM app_rate_rule WHERE product = $1", [otp]); await db.q("DELETE FROM app_product WHERE name = $1", [otp]); });
    await withoutDefaultPrice(db, seed);
    const r = await rig(db, seed, { loginProduct: null, rules: [{ product: otp, amount: "0.0500" }, { product: "__own__", amount: PRODUCT_PRICE }] });
    const typed = data(await explain({ account: r.account, product: otp.toLowerCase(), to: "61400000000", content: "hi" }));
    expect(typed.product).toBe(otp);
    expect(typed.product_from).toBe("typed");
    expect((typed.price as { rate: string } | null)?.rate).toBe("0.0500");
    const other = data(await explain({ account: r.account, product: BASELINE.product, to: "61400000000", content: "hi" }));
    expect(other.product).toBe(BASELINE.product);
    expect(other.product_from).toBe("typed");
    expect(other.price).toBeNull();
    expect(other.products_with_rules).toEqual(expect.arrayContaining([otp, r.product]));
    tcx.note(`typed '${otp.toLowerCase()}' → ${typed.product} 0.0500; typed ${BASELINE.product} → no price, rules for ${(other.products_with_rules as string[]).join(", ")}`);
  });

  test(...tc("TC-09.06.05-P03", "The answer names the account's logins that carry no product, whose traffic it does not describe (0.12.14)", { requires: ["gateway", "trace"] }), async ({ db, seed, env, tcx }) => {
    await withoutDefaultPrice(db, seed);
    const r = await rig(db, seed, { loginProduct: null });
    await setLoginProduct(db, r.http.id, r.product, r.account);
    const x = data(await explain({ account: r.account, to: "61400000000", content: "hi" }));
    expect(x.product).toBe(r.product);
    expect(x.product_from).toBe("login");
    expect((x.price as { rate: string } | null)?.rate).toBe(PRODUCT_PRICE);
    expect(x.logins_without_product).toEqual([r.smpp.systemId]);
    const esme = await bind(env, r.smpp);
    try {
      const s = await esme.submit({ text: "US-09.06 bare login" });
      expect(s.status).toBe(0);
      const row = await submitRow(db, s.messageId!);
      expect(row.product).toBeNull();
      expect(row.price).toBeNull();
      tcx.note(`explain: ${x.product} from login at ${PRODUCT_PRICE}, logins_without_product ${JSON.stringify(x.logins_without_product)}; the bare login's message: product null price null`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-09.06.05-P04", "With no account the answer is what Everyone pays (0.12.12)", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    const r = await rig(db, seed, { rules: [{ product: null, amount: "0.0200" }] });
    const x = data(await explain({ to: "61400000000", content: "hi" }));
    const price = x.price as { rate: string; scope: string } | null;
    expect(price).not.toBeNull();
    expect(price?.scope).toBe("*");
    expect(price?.rate).toBe((BASELINE.price / 10_000).toFixed(4));
    expect(x.product).toBeNull();
    expect(x.product_from).toBe("none");
    tcx.note(`no account: ${price?.rate} on scope ${price?.scope} (not ${r.account}'s 0.0200)`);
  });

  test(...tc("TC-09.06.05-N01", "Logins carrying different products make the answer ambiguous and nothing is assumed", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    const r = await rig(db, seed, { loginProduct: null });
    await db.q("UPDATE app_credential SET product = $1 WHERE id = $2", [BASELINE.product, r.smpp.id]);
    await setLoginProduct(db, r.http.id, r.product, r.account);
    const x = data(await explain({ account: r.account, to: "61400000000", content: "hi" }));
    expect(x.product).toBeNull();
    expect(x.product_from).toBe("ambiguous");
    expect(x.login_products).toEqual(expect.arrayContaining([r.product, BASELINE.product]));
    const price = x.price as { rate: string; scope: string } | null;
    // only any-product rules may answer: the baseline [*] 0.0100, never the account's product rule
    expect(price?.rate).not.toBe(PRODUCT_PRICE);
    tcx.note(`ambiguous between ${(x.login_products as string[]).join(", ")}; price ${price?.rate ?? "none"} from ${price?.scope ?? "-"}`);
  });

  test(...tc("TC-09.06.05-N02", "A typed product is not remembered between tests", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    const r = await rig(db, seed, { loginProduct: null });
    await setLoginProduct(db, r.http.id, r.product, r.account);
    const typed = data(await explain({ account: r.account, product: BASELINE.product, to: "61400000000", content: "hi" }));
    expect(typed.product_from).toBe("typed");
    const after = data(await explain({ account: r.account, to: "61400000000", content: "hi" }));
    expect(after.product_from).not.toBe("typed");
    expect(after.product).toBe(r.product);
    tcx.note(`typed ${typed.product}; next call without a product: ${after.product} from ${after.product_from}`);
  });
});
