"use client";
import { FILTER_WIDTH } from "@/lib/filter-widths";
import { useEffect, useState } from "react";
import { Filter, RotateCcw, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Select } from "@/components/ui/select";
import { Field } from "@/components/ui/field";
import {
  EMPTY_FILTERS,
  FINAL_STATES,
  RANGES,
  type CdrFilterForm,
  CUSTOM_RANGE,
  hasActiveFilters,
} from "@/lib/cdr-request";
import { FINAL_STATE_LABELS, labelFor } from "@/lib/labels";

/**
 * The filter form.
 *
 * <p>Holds a draft and only lifts it on submit. Filtering as you type would fire a database query
 * per keystroke against a pool of eight connections shared with the dashboard's polling, and the
 * results would flicker between four different answers before settling on the one you meant.
 *
 * <p>Free text rather than dropdowns for every dimension — see the note in `cdr-queries.ts`. The
 * two worker dimensions, ingress server and vendor, get a datalist of the configured workers' names
 * on top of that: the value is still the exact name the record carries, but nobody has to remember
 * that a listener is `smppserver.smpp` and a vendor `smppclient.x`.
 */
export function CdrFilterBar({
  value,
  onApply,
  busy,
}: {
  value: CdrFilterForm;
  onApply: (next: CdrFilterForm) => void;
  busy: boolean;
}) {
  const [draft, setDraft] = useState<CdrFilterForm>(value);
  const [open, setOpen] = useState(false);
  const names = useWorkerNames();

  const set = <K extends keyof CdrFilterForm>(key: K, next: CdrFilterForm[K]) =>
    setDraft((d) => ({ ...d, [key]: next }));

  function submit(e: React.FormEvent) {
    e.preventDefault();
    onApply(draft);
  }

  function clear() {
    //the range survives a clear: resetting it to 24h as well would look like the filters failed to
    //apply rather than that they were removed
    const next = { ...EMPTY_FILTERS, range: draft.range };
    setDraft(next);
    onApply(next);
  }

  return (
    <Card>
      <CardContent className="py-4">
        <form onSubmit={submit} className="space-y-4">
          <div className="flex flex-wrap items-end gap-3">
            <Field label="Period" className={FILTER_WIDTH.select}>
              <Select
                value={draft.range}
                onChange={(e) => {
                  const range = e.target.value;
                  //leaving the custom period drops its dates, so a shortcut chosen afterwards is
                  //not quietly narrowed by a window nobody can see any more
                  setDraft((d) => (range === CUSTOM_RANGE ? { ...d, range } : { ...d, range, since: "", until: "" }));
                }}
              >
                {Object.keys(RANGES).map((key) => (
                  <option key={key} value={key}>
                    {key === "all" ? "All time" : `Last ${key}`}
                  </option>
                ))}
                <option value={CUSTOM_RANGE}>Date range</option>
              </Select>
            </Field>

            {/* an explicit window, for "what happened between 2 and 3 on Tuesday". Either end alone
                works, and the dates travel as UTC instants */}
            {draft.range === CUSTOM_RANGE && (
              <>
                <Field label="From" htmlFor="cdr-since" className={FILTER_WIDTH.choice}>
                  <Input id="cdr-since" type="datetime-local" value={draft.since} max={draft.until || undefined}
                    onChange={(e) => set("since", e.target.value)} />
                </Field>
                <Field label="To" htmlFor="cdr-until" className={FILTER_WIDTH.choice}>
                  <Input id="cdr-until" type="datetime-local" value={draft.until} min={draft.since || undefined}
                    onChange={(e) => set("until", e.target.value)} />
                </Field>
              </>
            )}

            <Field label="Outcome" className={FILTER_WIDTH.choice}>
              <Select value={draft.outcome} onChange={(e) => set("outcome", e.target.value)}>
                <option value="">Any outcome</option>
                {/* PENDING first: it is the majority of rows and the one people forget exists */}
                <option value="PENDING">Awaiting a receipt</option>
                {FINAL_STATES.map((state) => (
                  <option key={state} value={state}>
                    {labelFor(FINAL_STATE_LABELS, state)}
                  </option>
                ))}
              </Select>
            </Field>

            <Field label="To number" className={FILTER_WIDTH.phone}>
              <Input
                value={draft.dest}
                onChange={(e) => set("dest", e.target.value)}
                placeholder="starts with…"
                inputMode="tel"
              />
            </Field>

            <Field label="Ingress server" className={FILTER_WIDTH.text}>
              <Input
                value={draft.server}
                onChange={(e) => set("server", e.target.value)}
                placeholder="any listener"
                list="cdr-ingress-servers"
              />
              <datalist id="cdr-ingress-servers">
                {names.servers.map((n) => <option key={n} value={n} />)}
              </datalist>
            </Field>

            <Field label="Vendor" className={FILTER_WIDTH.text}>
              <Input
                value={draft.vendor}
                onChange={(e) => set("vendor", e.target.value)}
                placeholder="any vendor"
                list="cdr-vendors"
              />
              <datalist id="cdr-vendors">
                {names.vendors.map((n) => <option key={n} value={n} />)}
              </datalist>
            </Field>

            <Field label="Message id" className={FILTER_WIDTH.text}>
              <Input
                value={draft.msgId}
                onChange={(e) => set("msgId", e.target.value)}
                placeholder="exact"
              />
            </Field>

            {/* the one box here that searches inside a value rather than matching one. It finds
                nothing at all unless the gateway is recording message text -- smsg.cdr.body, off by
                default -- which is why the placeholder says what it looks in rather than "search" */}
            <Field label="Message text" className={FILTER_WIDTH.text}>
              <Input
                value={draft.text}
                onChange={(e) => set("text", e.target.value)}
                placeholder="contains…"
              />
            </Field>

            <Button type="submit" disabled={busy} className="gap-2">
              <Search className="h-4 w-4" />
              {busy ? "Searching…" : "Search"}
            </Button>

            <Button type="button" variant="ghost" onClick={() => setOpen((o) => !o)} className="gap-2">
              <Filter className="h-4 w-4" />
              {open ? "Fewer filters" : "More filters"}
            </Button>

            {hasActiveFilters(draft) && (
              <Button type="button" variant="ghost" onClick={clear} className="gap-2">
                <RotateCcw className="h-4 w-4" />
                Clear
              </Button>
            )}
          </div>

          {open && (
            <div className="grid gap-3 border-t border-border pt-4 sm:grid-cols-2 lg:grid-cols-3">
              <Field label="Account">
                <Input value={draft.account} onChange={(e) => set("account", e.target.value)} placeholder="exact" />
              </Field>
              <Field label="Bind name (system id)">
                <Input value={draft.systemId} onChange={(e) => set("systemId", e.target.value)} placeholder="exact" />
              </Field>
              <Field label="Product">
                <Input value={draft.product} onChange={(e) => set("product", e.target.value)} placeholder="exact" />
              </Field>
              <Field label="Came in via">
                <Input value={draft.ingress} onChange={(e) => set("ingress", e.target.value)} placeholder="smpp, http…" />
              </Field>
              <Field label="From number">
                <Input value={draft.source} onChange={(e) => set("source", e.target.value)} placeholder="starts with…" />
              </Field>

              <Field
                label="Rows"
                hint="One row per message, or one per vendor attempt including retries and long-message segments."
                className="sm:col-span-2 lg:col-span-3"
              >
                <Select
                  value={draft.attempts}
                  onChange={(e) => set("attempts", e.target.value === "all" ? "all" : "first")}
                >
                  <option value="first">One row per message</option>
                  <option value="all">Every attempt and segment</option>
                </Select>
              </Field>
            </div>
          )}
        </form>
      </CardContent>
    </Card>
  );
}

/** Worker names as the call records carry them: `smppserver.<name>` for a listener, `smppclient.<name>` for a vendor. */
interface WorkerNames {
  servers: string[];
  vendors: string[];
}

//one read per page load, not per search: the bar is remounted with every applied filter set
let cachedNames: WorkerNames | null = null;
let namesInFlight: Promise<WorkerNames> | null = null;

async function loadWorkerNames(): Promise<WorkerNames> {
  const read = async (type: string, prefix: string): Promise<string[]> => {
    try {
      const res = await fetch(`/api/control/workers?type=${type}`, { cache: "no-store" });
      const json = await res.json().catch(() => null);
      const rows: { name?: string }[] = res.ok && Array.isArray(json?.data) ? json.data : [];
      return rows.map((w) => (w.name ? `${prefix}.${w.name}` : "")).filter(Boolean).sort();
    } catch {
      return [];
    }
  };
  const [servers, vendors] = await Promise.all([read("smppserver", "smppserver"), read("smppclient", "smppclient")]);
  return { servers, vendors };
}

function useWorkerNames(): WorkerNames {
  const [names, setNames] = useState<WorkerNames>(cachedNames ?? { servers: [], vendors: [] });
  useEffect(() => {
    if (cachedNames) {
      return;
    }
    let live = true;
    namesInFlight ??= loadWorkerNames().then((n) => {
      cachedNames = n;
      return n;
    });
    void namesInFlight.then((n) => {
      if (live) {
        setNames(n);
      }
    });
    return () => {
      live = false;
    };
  }, []);
  return names;
}
