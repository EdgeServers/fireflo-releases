/**
 * How each worker setting behaves, as opposed to what it is called.
 *
 * <p>A deliberate sibling of {@link SETTING_LABELS} rather than an extension of it. That catalogue
 * stakes itself as prose a locale layer could sit in front of; `widget`, `unit` and `live` are not
 * prose and would never be translated. Prose there, behaviour here, and the compiler keeps them in
 * step: {@link SETTING_FIELDS} is a `Record<SettingKey, SettingField>`, so a field for a key with no
 * label and a labelled key with no field are both compile errors.
 *
 * <p><strong>Every `codedDefault` here was read out of the gateway source</strong> — the `prms`
 * tables in `AbstractOutWorker`, `SmppClientWorker` and `SmppServerWorker`, where each entry is
 * `{name, default}`. It is a snapshot of another repository and is only ever shown as a placeholder
 * or as "the gateway's default is X". It is never written on the operator's behalf, because a
 * gateway-wide `outSms.default.<key>` overrides it.
 *
 * <p>It is also the FALLBACK rather than the answer. The panel reads `outSms.default.*` now -- see
 * `lib/gateway-settings.ts` -- so a field with no value of its own shows what it actually inherits,
 * and drops back to this literal only when the tier above has nothing to say. This comment used to
 * end "and this panel cannot read those", which was true and was why every unset field on every
 * worker was wrong for any key an operator had set a default for.
 *
 * <p><strong>`live` means a change reaches a running worker</strong>, by either of the two
 * mechanisms the gateway actually has: the key is handled in a `myPropertyChange` branch, or it is
 * read from the configuration provider at the moment it is used. Everything else is read once when a
 * session or a listener is built, so it needs a restart — or, for a few, the next reconnect. The
 * form says "restart" for those, which is never wrong and is sometimes pessimistic.
 */
import type { SettingKey } from "./labels";

export type SettingWidget =
  | { kind: "text"; placeholder?: string }
  | { kind: "secret" }
  | { kind: "boolean" }
  | { kind: "number"; unit?: "ms" | "s" | "min"; specials?: readonly { value: string; means: string }[] }
  | { kind: "enum"; options: readonly { value: string; label: string }[] }
  /** One comma-joined string, edited as rows. Not an array — it persists as a single value. */
  | { kind: "list"; itemPlaceholder?: string; itemKind?: "tlv" }
  /** A comma-joined list of pairs, joined by `_` or `=` depending on the key. */
  | { kind: "pairs"; assign: "=" | "_"; keyPlaceholder?: string; valuePlaceholder?: string; itemKind?: "tlv" }
  /** A regular expression. Checked for compiling, never for meaning. */
  | { kind: "pattern" };

export type SectionId =
  | "connection"
  | "binds"
  | "throughput"
  | "listener"
  | "customerDefaults"
  | "timers"
  | "addressing"
  | "encoding"
  | "tlvs"
  | "failure"
  | "traffic"
  | "inbound"
  | "accepted"
  | "tls"
  | "proxy"
  | "diagnostics";

export interface SettingField {
  widget: SettingWidget;
  section: SectionId;
  applies: "client" | "server" | "both";
  /**
   * A screen that owns this key instead of the worker form, if one does.
   *
   * <p>The entry stays — it is what {@link settingLabel}, {@link needsRestart} and the gateway
   * key policy read, and deleting it would make the key uncurated everywhere rather than edited
   * somewhere better. What this does is take it off the forms, so one key has one editor.
   *
   * <p>The string is shown to an operator, so it names the screen rather than a route.
   */
  elsewhere?: string;
  /** The literal the gateway parses when the key is absent. A placeholder, never a written value. */
  codedDefault: string;
  /** True when a running worker picks the change up without being restarted. */
  live: boolean;
  /** Only where the same key means something materially different on the other side. */
  serverHint?: string;
  /**
   * Rendered under that key's field, in the same grid cell, rather than in a slot of its own. For a
   * checkbox that belongs to a field: "Listener enabled" sits under "Listen port".
   */
  under?: SettingKey;
}

export interface Section {
  id: SectionId;
  title: string;
  /** Left-hand column: shown open, without disclosure chrome. */
  essential: boolean;
  /** Rendered above the fields when every field in the section needs a restart. */
  note?: string;
}

/**
 * Type of number, as SMPP numbers them.
 *
 * <p>Offered as a dropdown because the stored value is the integer, and an operator who types
 * "International" gets a setting the gateway parses as zero without complaining.
 */
const TON_OPTIONS = [
  { value: "0", label: "0 — Unknown" },
  { value: "1", label: "1 — International" },
  { value: "2", label: "2 — National" },
  { value: "3", label: "3 — Network specific" },
  { value: "4", label: "4 — Subscriber number" },
  { value: "5", label: "5 — Alphanumeric" },
  { value: "6", label: "6 — Abbreviated" },
] as const;

const NPI_OPTIONS = [
  { value: "0", label: "0 — Unknown" },
  { value: "1", label: "1 — ISDN (E.164)" },
  { value: "3", label: "3 — Data (X.121)" },
  { value: "4", label: "4 — Telex" },
  { value: "6", label: "6 — Land mobile" },
  { value: "8", label: "8 — National" },
  { value: "9", label: "9 — Private" },
  { value: "10", label: "10 — ERMES" },
  { value: "14", label: "14 — Internet (IP)" },
  { value: "18", label: "18 — WAP client ID" },
] as const;

/** `SmppClientWorker.NackHandlePolicy`. An unrecognised value falls back silently. */
const NACK_POLICY_OPTIONS = [
  { value: "RETRY_WORKER", label: "Retry on this vendor" },
  { value: "RETRY_ROUTER", label: "Send back to the router" },
  { value: "FAIL", label: "Fail the message" },
] as const;

/** `AbstractOutWorker.SuspensionPolicy`. */
const SUSPENSION_POLICY_OPTIONS = [
  { value: "SUSPEND", label: "Suspend the worker" },
  { value: "RETRY_ROUTER", label: "Send messages back to the router" },
  { value: "FAIL", label: "Fail the messages" },
] as const;

const UNLIMITED = [{ value: "0", means: "no limit" }] as const;
const NEVER = [{ value: "-1", means: "never" }] as const;

/**
 * The sections a form is built from, in the order they appear.
 *
 * <p>`essential` is the column split, not an importance ranking: essentials are what someone has to
 * fill in for the connection to exist at all, which is also the set that is almost entirely
 * restart-required. A section with no fields for the form being rendered is skipped.
 */
export const SECTIONS: readonly Section[] = [
  {
    id: "connection",
    title: "Connection",
    essential: true,
    note: "These are read when a session is built, so a change needs a restart.",
  },
  {
    id: "listener",
    title: "Listener",
    essential: true,
  },
  {
    id: "binds",
    title: "Binds and window",
    essential: true,
    note: "Window size is read when a session is built; the bind counts take effect on the next connection check.",
  },
  {
    id: "customerDefaults",
    title: "Per-customer defaults",
    essential: true,
    note: "Applied to a customer that has no value of its own on its credential.",
  },
  { id: "throughput", title: "Throughput and retries", essential: true },
  { id: "timers", title: "Timers", essential: false },
  { id: "addressing", title: "Addressing", essential: false },
  { id: "encoding", title: "Encoding", essential: false },
  { id: "accepted", title: "Messages accepted", essential: false },
  { id: "tlvs", title: "TLVs", essential: false },
  { id: "failure", title: "Failure handling", essential: false },
  { id: "traffic", title: "Traffic control", essential: false },
  { id: "inbound", title: "Inbound messages", essential: false },
  {
    id: "tls",
    title: "TLS",
    essential: false,
    note: "Read when the TLS listener starts. Turning TLS off and on again restarts it and picks these up.",
  },
  {
    id: "proxy",
    title: "PROXY protocol",
    essential: false,
    note: "Read when the PROXY listener starts.",
  },
  { id: "diagnostics", title: "Diagnostics", essential: false },
];

/**
 * Every labelled setting, and how to render and interpret it.
 *
 * <p>Fifteen keys apply to both kinds of worker, forty-three only to a vendor and twenty-three only
 * to a server — fifty-eight fields on the vendor form and thirty-eight on the server form.
 */
export const SETTING_FIELDS: Record<SettingKey, SettingField> = {
  // --- connection (vendor) --------------------------------------------------------------------
  host: { widget: { kind: "text" }, section: "connection", applies: "client", codedDefault: "localhost", live: false },
  port: { widget: { kind: "number" }, section: "connection", applies: "client", codedDefault: "27777", live: false },
  username: { widget: { kind: "text" }, section: "connection", applies: "client", codedDefault: "smsp", live: false },
  password: { widget: { kind: "secret" }, section: "connection", applies: "client", codedDefault: "psms", live: false },
  systemType: { widget: { kind: "text" }, section: "connection", applies: "client", codedDefault: "", live: false },
  "extra.hosts": {
    widget: { kind: "list", itemPlaceholder: "host:port" },
    section: "connection",
    applies: "client",
    codedDefault: "",
    //read on every connection check rather than only at start
    live: true,
  },
  "backup.hosts": {
    widget: { kind: "list", itemPlaceholder: "host:port" },
    section: "connection",
    applies: "client",
    codedDefault: "",
    live: true,
  },
  "local.bind.host": {
    widget: { kind: "text" },
    section: "connection",
    applies: "client",
    codedDefault: "",
    live: false,
  },
  interfaceVersion: {
    widget: {
      kind: "enum",
      options: [
        { value: "52", label: "52 — SMPP 3.4" },
        { value: "51", label: "51 — SMPP 3.3" },
      ],
    },
    section: "connection",
    applies: "client",
    codedDefault: "52",
    live: false,
  },

  // --- binds and window (vendor) --------------------------------------------------------------
  "connections.transceivers": {
    widget: { kind: "number" },
    section: "binds",
    applies: "client",
    codedDefault: "1",
    live: true,
  },
  "connections.transmitters": {
    widget: { kind: "number" },
    section: "binds",
    applies: "client",
    codedDefault: "0",
    live: true,
  },
  "connections.receivers": {
    widget: { kind: "number" },
    section: "binds",
    applies: "client",
    codedDefault: "0",
    live: true,
  },
  "reconnection.threads": {
    widget: { kind: "number" },
    section: "binds",
    applies: "client",
    codedDefault: "1",
    live: false,
  },
  windowSize: { widget: { kind: "number" }, section: "binds", applies: "client", codedDefault: "100", live: false },

  // --- throughput and retries (both) ----------------------------------------------------------
  tps: {
    widget: { kind: "number", specials: UNLIMITED },
    section: "throughput",
    applies: "both",
    codedDefault: "0",
    live: true,
  },
  maxRetries: {
    widget: { kind: "number", specials: [{ value: "0", means: "retry forever" }] },
    section: "throughput",
    applies: "both",
    codedDefault: "1",
    live: true,
  },
  threadCount: {
    widget: { kind: "number" },
    section: "throughput",
    applies: "both",
    codedDefault: "1",
    live: false,
  },

  // --- traffic control (both) -----------------------------------------------------------------
  suspend: { widget: { kind: "boolean" }, section: "traffic", applies: "both", codedDefault: "false", live: true },
  pause: { widget: { kind: "boolean" }, section: "traffic", applies: "both", codedDefault: "false", live: true },
  "pause.sleep.ms": {
    widget: { kind: "number", unit: "ms" },
    section: "traffic",
    applies: "both",
    codedDefault: "1000",
    live: false,
  },

  // --- timers (vendor) ------------------------------------------------------------------------
  "enquire.link.interval.millis": {
    widget: { kind: "number", unit: "ms" },
    section: "timers",
    applies: "client",
    codedDefault: "30000",
    live: true,
  },
  "reconnect.interval.millis": {
    widget: { kind: "number", unit: "ms" },
    section: "timers",
    applies: "client",
    codedDefault: "60000",
    live: true,
  },
  "con.tout": {
    widget: { kind: "number", unit: "ms" },
    section: "timers",
    applies: "client",
    codedDefault: "10000",
    live: false,
  },
  "request.tout": {
    widget: { kind: "number", unit: "ms" },
    section: "timers",
    applies: "client",
    codedDefault: "30000",
    //read per send, so the submit timeout changes at once; the bind timeout it also feeds does not
    live: true,
  },
  "unbind.timeout.millis": {
    widget: { kind: "number", unit: "ms" },
    section: "timers",
    applies: "client",
    codedDefault: "5000",
    live: true,
  },
  "window.monitor.interval.millis": {
    widget: { kind: "number", unit: "ms" },
    section: "timers",
    applies: "client",
    codedDefault: "15000",
    live: false,
  },
  "reconnection.stability.threshold.millis": {
    widget: { kind: "number", unit: "ms" },
    section: "timers",
    applies: "client",
    codedDefault: "5000",
    live: true,
  },

  // --- addressing (vendor) --------------------------------------------------------------------
  "src.addr.ton": {
    widget: { kind: "enum", options: TON_OPTIONS },
    section: "addressing",
    applies: "client",
    codedDefault: "2",
    live: true,
  },
  "src.addr.npi": {
    widget: { kind: "enum", options: NPI_OPTIONS },
    section: "addressing",
    applies: "client",
    codedDefault: "1",
    live: true,
  },
  "src.addr.autodetect": {
    widget: { kind: "boolean" },
    section: "addressing",
    applies: "client",
    codedDefault: "true",
    live: true,
  },
  "dest.addr.ton": {
    widget: { kind: "enum", options: TON_OPTIONS },
    section: "addressing",
    applies: "client",
    codedDefault: "2",
    live: true,
  },
  "dest.addr.npi": {
    widget: { kind: "enum", options: NPI_OPTIONS },
    section: "addressing",
    applies: "client",
    codedDefault: "1",
    live: true,
  },
  addressRange: {
    widget: { kind: "text" },
    section: "addressing",
    applies: "client",
    codedDefault: "",
    live: false,
  },

  // --- encoding -------------------------------------------------------------------------------
  "dcs.charset.map": {
    widget: { kind: "pairs", assign: "_", keyPlaceholder: "data coding", valuePlaceholder: "charset" },
    section: "encoding",
    applies: "client",
    codedDefault: "0_GSM,1_GSM,3_ISO-8859-1,8_UCS-2,4_HEX",
    live: true,
  },
  "dcs.charset.ext": {
    widget: { kind: "pairs", assign: "_", keyPlaceholder: "data coding", valuePlaceholder: "charset" },
    section: "encoding",
    applies: "client",
    codedDefault: "",
    live: true,
  },
  "dlr.charset.fixed": {
    widget: { kind: "text", placeholder: "e.g. GSM" },
    section: "encoding",
    applies: "client",
    codedDefault: "",
    live: true,
  },
  "ccat.8bit": {
    widget: { kind: "boolean" },
    section: "encoding",
    applies: "both",
    codedDefault: "true",
    //read while splitting each message, so it takes effect on the next one
    live: true,
  },
  "esm.class": { widget: { kind: "text" }, section: "encoding", applies: "client", codedDefault: "", live: true },
  "esm.class.override": {
    widget: { kind: "boolean" },
    section: "encoding",
    applies: "client",
    codedDefault: "false",
    live: true,
  },

  // --- TLVs -----------------------------------------------------------------------------------
  "registered.tlvs.submit": {
    widget: { kind: "list", itemPlaceholder: "name_0x1400", itemKind: "tlv" },
    section: "tlvs",
    applies: "both",
    codedDefault: "",
    live: true,
    serverHint:
      "On a server this is the list extracted from an inbound submit_sm, not a list appended to it.",
  },
  "registered.tlvs.dlr": {
    widget: { kind: "list", itemPlaceholder: "name_0x1400", itemKind: "tlv" },
    section: "tlvs",
    applies: "client",
    codedDefault: "",
    live: true,
  },
  "registered.tlvs.mo": {
    widget: { kind: "list", itemPlaceholder: "name_0x1400", itemKind: "tlv" },
    section: "tlvs",
    applies: "client",
    codedDefault: "",
    live: true,
  },
  "default.tlvs.submit": {
    widget: { kind: "pairs", assign: "=", keyPlaceholder: "name_0x1400", valuePlaceholder: "value", itemKind: "tlv" },
    section: "tlvs",
    applies: "client",
    codedDefault: "",
    live: true,
  },
  "mandatory.tlvs.submit": {
    widget: { kind: "list", itemPlaceholder: "name_0x1400", itemKind: "tlv" },
    section: "tlvs",
    applies: "server",
    codedDefault: "",
    live: true,
  },
  /**
   * What a matched approved row does with the TLVs it carries, on this listener.
   *
   * `replace` is what makes an approved registration a control rather than a suggestion: it
   * overwrites whatever the client asserted, which is the only thing stopping a customer sending
   * approved wording under somebody else's Entity ID. `assign` gives that up to fill a tag the
   * customer omitted. `off` stamps nothing at all.
   *
   * <p><strong>`off` is listed explicitly, and unset no longer claims to mean it.</strong> Unset
   * means the gateway resolves `outSms.default.whitelist.tlvs.mode` instead — that is what
   * `FireFloConfigurationHandler.get()` does with any worker key it cannot find. So the estate-wide
   * value goes on the gateway default and a listener that must not stamp says `off` here. That is
   * the kill switch, and until this option existed the panel could not express it: the only way to
   * say "off" was to leave the field unset, which now means the opposite.
   *
   * <p>The empty option is deliberately absent from this list. `WorkerFields` renders its own
   * "not set" entry for every enum, and carrying one here put two `value=""` options in the same
   * dropdown.
   */
  "whitelist.tlvs.mode": {
    widget: {
      kind: "enum",
      options: [
        { value: "off", label: "Off — a match stamps nothing" },
        { value: "assign", label: "Assign — fill the tag only when the customer sent none" },
        { value: "replace", label: "Replace — the approved value always wins" },
      ],
    },
    section: "tlvs",
    applies: "server",
    codedDefault: "",
    live: true,
  },
  /*
   * `whitelist.tlvs.replace` used to sit here, beside the enum that superseded it, and both
   * rendered on the listener form. An operator could not tell which one was deciding -- the rule is
   * that the boolean is read only while the mode is blank, and that rule lived in a javadoc on
   * TlvStampMode and nowhere they would look. Worse, ticking the box while the mode said `off` did
   * nothing at all, silently.
   *
   * Gateway migration V1.38.0 translates it (`true` becomes `mode = replace`) and drops it, so a
   * database-configured listener no longer has one. It is deliberately NOT re-added here for the
   * file-mode deployments that still can: an editor for a setting we want nobody to set is how it
   * survives. The gateway warns at startup for those, which is the honest place -- it is the only
   * side that can see a properties file.
   *
   * `lib/mandatory-tlvs.ts` still READS the key when computing coverage, and must keep doing so:
   * reporting is about what a listener does today, not about what it should be configured with.
   */

  /**
   * The carrier's own error codes, and what becomes of one the operator has not named.
   *
   * `applies: "client"` -- the vendor side, not the listener -- and that is the whole design: 630
   * from one carrier and 630 from another are unrelated numbers in unrelated spaces, so this
   * belongs to whoever sent the code. The listener renders the receipt but has no idea whose
   * numbering it is reading.
   *
   * This was free text on the worker form, and the reason recorded here was that `TlvPairsEditor`'s
   * shape was wrong: its keys are tags from a catalogue we know, and these are a carrier's private
   * numbers that no catalogue can enumerate. **That half is still right and is why the left column
   * of the editor that replaced it is free text too** — what was wrong was concluding from it that
   * the whole thing had to be one string. A two-column table makes the grammar structural without
   * implying either column is a known set; only a *dropdown* would have done that.
   *
   * So it now has a screen of its own (`/cp/error-codes`), which the single field could never have
   * carried: the global tier, the inherited rows, and the sentence that a vendor list REPLACES the
   * global one rather than adding to it. `elsewhere` takes it off this form so the two do not both
   * decide the key.
   */
  "dlr.errcodes": {
    widget: { kind: "text" },
    section: "failure",
    applies: "client",
    codedDefault: "",
    live: true,
    elsewhere: "Error codes",
  },
  /**
   * Blank is not a value here -- see the tiers note in `conf.example/smsg.properties`. Off is the
   * coded default and is what every release before 0.8.10 did unconditionally.
   */
  "dlr.errcodes.passthrough": {
    widget: { kind: "boolean" },
    section: "failure",
    applies: "client",
    codedDefault: "false",
    live: true,
    //with the list, because it is meaningless without one: it decides what happens to a code the
    //list does not name, and there is nothing to decide until there is a list
    elsewhere: "Error codes",
  },

  // --- failure handling -----------------------------------------------------------------------
  "status.retry.worker": {
    widget: { kind: "list", itemPlaceholder: "status, in decimal" },
    section: "failure",
    applies: "client",
    codedDefault: "20,88",
    live: true,
  },
  "status.retry.router": {
    widget: { kind: "list", itemPlaceholder: "status, in decimal" },
    section: "failure",
    applies: "client",
    codedDefault: "",
    live: true,
  },
  "status.fail": {
    widget: { kind: "list", itemPlaceholder: "status, in decimal" },
    section: "failure",
    applies: "client",
    codedDefault: "",
    live: true,
  },
  "status.default": {
    widget: { kind: "enum", options: NACK_POLICY_OPTIONS },
    section: "failure",
    applies: "client",
    codedDefault: "RETRY_WORKER",
    live: true,
  },
  "suspension.policy": {
    widget: { kind: "enum", options: SUSPENSION_POLICY_OPTIONS },
    section: "failure",
    applies: "both",
    codedDefault: "SUSPEND",
    live: true,
  },
  "suspension.stopMessages.ms": {
    widget: { kind: "number", unit: "ms", specials: NEVER },
    section: "failure",
    applies: "both",
    codedDefault: "-1",
    live: true,
  },
  "suspension.disable.ms": {
    widget: { kind: "number", unit: "ms", specials: NEVER },
    section: "failure",
    applies: "both",
    codedDefault: "-1",
    live: true,
  },

  // --- diagnostics ----------------------------------------------------------------------------
  debug: { widget: { kind: "boolean" }, section: "diagnostics", applies: "both", codedDefault: "false", live: true },
  counters: {
    widget: { kind: "boolean" },
    section: "diagnostics",
    applies: "client",
    codedDefault: "true",
    //set on the session configuration, so only sessions opened after the change carry it
    live: false,
  },
  "log.pdus": {
    widget: { kind: "boolean" },
    section: "diagnostics",
    applies: "both",
    codedDefault: "false",
    live: true,
  },
  "log.bytes": {
    widget: { kind: "boolean" },
    section: "diagnostics",
    applies: "both",
    codedDefault: "false",
    live: true,
  },
  "print.msgs": {
    widget: { kind: "boolean" },
    section: "diagnostics",
    applies: "both",
    codedDefault: "false",
    live: true,
  },
  "connection.healthcheck": {
    widget: { kind: "boolean" },
    section: "diagnostics",
    applies: "client",
    codedDefault: "false",
    live: true,
  },

  // --- inbound messages (vendor) --------------------------------------------------------------
  "forward.mo.url": {
    widget: { kind: "text", placeholder: "https://…" },
    section: "inbound",
    applies: "client",
    codedDefault: "",
    live: true,
  },
  "forward.mo.format": {
    widget: {
      kind: "enum",
      options: [
        { value: "JSON", label: "JSON body" },
        { value: "FORM", label: "Form encoded" },
      ],
    },
    section: "inbound",
    applies: "client",
    codedDefault: "JSON",
    live: true,
  },

  // --- listener (server) ----------------------------------------------------------------------
  "srv.port": {
    widget: { kind: "number", specials: [{ value: "0", means: "the listener does not start" }] },
    section: "listener",
    applies: "server",
    codedDefault: "0",
    live: false,
  },
  /**
   * The address customers connect to, which the gateway never reads.
   *
   * <p>Not `srv.host`: that one looks like a bind address, and the gateway loads it and never applies
   * it (see {@link DEAD_KEYS}). This is the panel's own key, stored beside the listener's other
   * settings so the connection instructions can name it. `live` because nothing restarts for it.
   */
  "srv.public.host": {
    widget: { kind: "text", placeholder: "203.0.113.10" },
    section: "listener",
    applies: "server",
    codedDefault: "",
    live: true,
  },
  "srv.enabled": {
    widget: { kind: "boolean" },
    section: "listener",
    applies: "server",
    codedDefault: "true",
    live: true,
    under: "srv.port",
  },
  "srv.systemId": {
    widget: { kind: "text" },
    section: "listener",
    applies: "server",
    codedDefault: "FireFlo",
    live: false,
  },
  "srv.maxConnections": {
    widget: { kind: "number" },
    section: "listener",
    applies: "server",
    codedDefault: "1000",
    live: false,
  },
  "srv.maxConnectionsPerIP": {
    widget: { kind: "number", specials: UNLIMITED },
    section: "listener",
    applies: "server",
    codedDefault: "0",
    live: true,
  },
  "srv.maxInactivityTime": {
    //minutes, and it sits two rows from srv.bindTimeout which is milliseconds
    widget: { kind: "number", unit: "min" },
    section: "listener",
    applies: "server",
    codedDefault: "60",
    live: true,
  },
  "srv.bindTimeout": {
    widget: { kind: "number", unit: "ms" },
    section: "listener",
    applies: "server",
    codedDefault: "5000",
    live: false,
  },

  // --- TLS (server) ---------------------------------------------------------------------------
  "srv.tls.enabled": {
    widget: { kind: "boolean" },
    section: "tls",
    applies: "server",
    codedDefault: "false",
    live: true,
  },
  "srv.tls.port": {
    widget: { kind: "number", specials: [{ value: "0", means: "the TLS listener does not start" }] },
    section: "tls",
    applies: "server",
    codedDefault: "0",
    live: false,
  },
  "srv.tls.keystore.path": {
    widget: { kind: "text", placeholder: "/etc/fireflo/keystore.p12" },
    section: "tls",
    applies: "server",
    codedDefault: "",
    live: false,
  },
  "srv.tls.keystore.alias": {
    widget: { kind: "text" },
    section: "tls",
    applies: "server",
    codedDefault: "",
    live: false,
  },
  "srv.tls.keystore.password": {
    widget: { kind: "secret" },
    section: "tls",
    applies: "server",
    codedDefault: "",
    live: false,
  },

  // --- PROXY protocol (server) --------------------------------------------------------------
  "srv.proxy.enabled": {
    widget: { kind: "boolean" },
    section: "proxy",
    applies: "server",
    codedDefault: "false",
    live: true,
  },
  "srv.proxy.port": {
    widget: { kind: "number" },
    section: "proxy",
    applies: "server",
    codedDefault: "2777",
    live: false,
  },

  // --- per-customer defaults (server) ---------------------------------------------------------
  /**
   * Whether this listener honours the sender ID and content whitelist.
   *
   * Three things must agree before a message is checked: the gateway's smsg.whitelist.enabled,
   * this, and a policy for the account and product. Turning it off here exempts only this
   * listener -- the same account submitting over REST is still governed by its policy.
   */
  "conf.whitelist.enabled": {
    widget: { kind: "boolean" },
    section: "customerDefaults",
    applies: "server",
    codedDefault: "true",
    live: true,
  },
  /**
   * How many delivery receipts a concatenated message produces on this listener.
   *
   * Counts the ids the CUSTOMER submitted, not the segments the gateway sent the carrier. A client
   * that sends three submit_sm is acknowledged three times and holds three ids; the outbound split
   * is separate and is aggregated to one outcome before any receipt is built, so all three receipts
   * report the same verdict and differ only in the id they quote.
   *
   * `all` is the shipped default and is what the gateway has always done, so changing nothing here
   * changes nothing for a customer. `first` and `last` serve an aggregator that expects one message
   * in and one receipt out; the single receipt then reports sub:00N for the N it speaks for.
   */
  "conf.dlr.multipart": {
    widget: {
      kind: "enum",
      options: [
        { value: "all", label: "One per submitted message (default)" },
        { value: "first", label: "One, quoting the first id" },
        { value: "last", label: "One, quoting the last id" },
      ],
    },
    section: "customerDefaults",
    applies: "server",
    codedDefault: "all",
    live: true,
  },
  /**
   * Whether a bind here must name a product this gateway sells.
   *
   * Off by default, because turning it on refuses binds that work today -- check the report on the
   * accounts page before switching it on.
   *
   * What it closes is a billing hole rather than a validation gap. An SMPP client picks its product
   * with the system_type on the bind, which overrides the credential's own value and is free text,
   * so a customer sending 'prem' for 'premium' gets a session matching no product-scoped rate rule.
   * That message is left unrated, and an unrated message is never charged -- it sends for nothing.
   * Requiring merely a non-empty value would not catch it, so this checks membership of the product
   * catalogue. A gateway with no catalogue to read enforces only the non-empty half.
   */
  "conf.product.required": {
    widget: { kind: "boolean" },
    section: "customerDefaults",
    applies: "server",
    codedDefault: "false",
    live: true,
  },
  "conf.maxRate.default": {
    widget: { kind: "number", specials: UNLIMITED },
    section: "customerDefaults",
    applies: "server",
    codedDefault: "0",
    live: true,
  },
  "conf.maxConnectionsPerUser.default": {
    widget: { kind: "number", specials: UNLIMITED },
    section: "customerDefaults",
    applies: "server",
    codedDefault: "0",
    live: true,
  },
  "conf.maxPending.default": {
    widget: { kind: "number" },
    section: "customerDefaults",
    applies: "server",
    codedDefault: "1000",
    live: true,
  },
  "conf.responseTout.default": {
    widget: { kind: "number", unit: "ms" },
    section: "customerDefaults",
    applies: "server",
    codedDefault: "30000",
    live: true,
  },

  // --- messages accepted (server) -------------------------------------------------------------
  "ptrn.valid.receiver": {
    widget: { kind: "pattern" },
    section: "accepted",
    applies: "server",
    codedDefault: "[+]?[0-9]{10,20}",
    live: true,
  },
  "forward.dlrs": {
    widget: { kind: "boolean" },
    section: "accepted",
    applies: "server",
    codedDefault: "true",
    live: true,
  },
  "reassembling.timeoutMillis": {
    widget: { kind: "number", unit: "ms" },
    section: "accepted",
    applies: "server",
    codedDefault: "30000",
    live: true,
  },
};

/**
 * The field for a key, or null when nobody has written one.
 *
 * <p>Deliberately partial, unlike {@link settingLabel}. "Other settings" needs to tell a key the
 * catalogue knows from a key nobody has met, because only the latter keeps its raw identifier on
 * screen.
 */
export function fieldFor(key: string): SettingField | null {
  return (SETTING_FIELDS as Record<string, SettingField>)[key] ?? null;
}

/** The keys a form of this type offers, in section order. */
export function fieldsForType(type: "smppclient" | "smppserver"): { section: Section; keys: SettingKey[] }[] {
  const side = type === "smppclient" ? "client" : "server";
  return SECTIONS.map((section) => ({
    section,
    keys: (Object.keys(SETTING_FIELDS) as SettingKey[]).filter((key) => {
      const field = SETTING_FIELDS[key];
      //`elsewhere` keys are edited on their own screen; rendering them here too would be two
      //editors for one key, which is how the two come to disagree
      return (
        field.elsewhere === undefined
        && field.section === section.id
        && (field.applies === "both" || field.applies === side)
      );
    }),
  })).filter((group) => group.keys.length > 0);
}

/**
 * Settings the gateway loads and then never reads, and what to use instead.
 *
 * <p>Keyed by plain string rather than {@link SettingKey}, because the whole point is that these are
 * not fields. Each was confirmed by counting occurrences in the gateway source: a live key such as
 * `srv.port` appears four times — declared, collected into the property list, and read twice. Each
 * key here appears exactly twice, declared and collected.
 */
export const DEAD_KEYS: Record<string, string> = {
  "srv.host":
    "FireFlo never applies a bind address, so the listener binds every interface whatever this says. "
    + "Restrict access with a firewall instead.",
  "srv.tls.host": "Same as srv.host — loaded and never applied.",
  "conf.sleepWindow": "Loaded and never read. Nothing uses it.",
  "srv.defaultWindowSize":
    "Not a setting the gateway has ever had, despite appearing in older README and example files. "
    + "Use conf.maxPending.default.",
};

/** Whether a change to this key needs the worker restarted. Unknown keys are in neither set. */
export function needsRestart(key: string): boolean {
  const field = fieldFor(key);
  return field != null && !field.live;
}

/**
 * Settings measured in milliseconds, and a plausible floor for each.
 *
 * <p>Derived from the catalogue rather than listed again, so a new `unit: "ms"` field is covered the
 * moment it is added. These invite a value in seconds: `enquire.link.interval.millis = 30` is legal
 * and sends about thirty-three probes a second down every session, and reads perfectly reasonable in
 * the field.
 */
export const MILLISECOND_KEYS: Record<string, number> = Object.fromEntries(
  (Object.entries(SETTING_FIELDS) as [string, SettingField][])
    .filter(([, field]) => field.widget.kind === "number" && field.widget.unit === "ms")
    .map(([key]) => [key, 1000])
);

/**
 * The few settings worth showing on a list card without being asked.
 *
 * <p>Chosen as "what identifies this connection", not "what matters most" — the card is a list entry
 * and the question it answers is *which* vendor is this and roughly how hard is it being driven.
 * Everything else goes behind a disclosure.
 *
 * <p>This became necessary rather than nice when the editor grew from sixteen fields to eighty: a
 * card rendering every stored property used to be a tidy three or four rows and would now be fifty,
 * burying the live state above it.
 */
export const SUMMARY_KEYS: Record<"smppclient" | "smppserver", readonly SettingKey[]> = {
  smppclient: ["host", "port", "username", "connections.transceivers", "windowSize", "tps", "maxRetries"],
  smppserver: [
    "srv.port",
    "srv.tls.enabled",
    "srv.maxConnections",
    "conf.maxRate.default",
    "conf.maxPending.default",
    "tps",
  ],
};

/** The section a key belongs to, in English, for grouping stored settings. Unknown keys group last. */
export function sectionTitle(key: string): string {
  const field = fieldFor(key);
  if (!field) {
    return "Other settings";
  }
  return SECTIONS.find((s) => s.id === field.section)?.title ?? "Other settings";
}
