import { type ConditionInput, conditionErrors, conditionWarnings } from "./rate-types.ts";
import { isOn, trafficKey, type Worker } from "./worker-types.ts";

/**
 * Routing tables and the rules in them — where a message is sent.
 *
 * <p>Zero database imports; see the note at the top of `rate-types.ts` for what happens otherwise.
 *
 * <p>Every statement here about behaviour comes from `StandardRoutingManager` and
 * `RoutingTable.TargetFunction` in the gateway, not from inference. Routing decides where every
 * message goes, so a UI that describes it approximately is worse than one that says nothing.
 */

export const TARGET_FUNCTIONS = ["NORMAL", "LCR"] as const;
export type TargetFunction = (typeof TARGET_FUNCTIONS)[number];

export interface RouteRule {
  /** null for a rule that does not exist yet. Existing ids are preserved across a save. */
  id: number | null;
  /** A worker instance name, or another routing table to chain into. */
  target: string;
  /**
   * Was the `+` prefix in the file: the message is copied to this target and the scan **continues**
   * to later rules, rather than stopping here.
   */
  copied: boolean;
  label: string | null;
  enabled: boolean;
  conditions: ConditionInput[];
  /** Named filters, ANDed with `conditions` at load time exactly as on a rate rule. */
  filters: string[];
}

export interface RouteTable {
  name: string;
  targetFunction: TargetFunction;
  label: string | null;
  enabled: boolean;
  rules: RouteRule[];
}

export interface RouteTableInput {
  name: string;
  targetFunction: TargetFunction;
  label?: string | null;
  enabled: boolean;
  rules: RouteRule[];
}

/**
 * What each target function does, in the words the gateway's own behaviour justifies.
 *
 * <p>The differences are not cosmetic — they change whether rule order means anything, and whether
 * conditions are consulted at all.
 */
export const TARGET_FUNCTION_MEANING: Record<TargetFunction, string> = {
  NORMAL:
    "Rules are tried in order and the first match wins. Order is the priority — a rule can only be "
    + "reached if every rule above it failed to match.",
  LCR:
    "Every matching rule is a candidate and the cheapest vendor rate wins, so the order here means "
    + "nothing. Only targets that are vendors can compete; a rule pointing at another table is "
    + "skipped, because a nested cost cannot be compared.",
};

/** A worker, as much of it as resolving a target needs. */
export interface TargetWorker {
  name: string;
  type: string;
  /**
   * Whether the operator has it switched on.
   *
   * <p>Optional so a caller that genuinely cannot tell — and there is no such caller today — is not
   * forced to claim a worker is enabled. Absent is treated as enabled, which keeps the answer the
   * same as before this existed rather than warning about every rule on a page that has no worker
   * state to hand.
   */
  enabled?: boolean;
}

/**
 * How a rule's target resolves, as far as this panel can tell.
 *
 * <p>`unknown` is deliberately not called "missing". `RoutingTargets.getWorker` is a plain map
 * lookup against workers registered at runtime, and the panel only knows what is in `app_worker` —
 * so a target it does not recognise may still be perfectly live. It is worth a note, not an alarm.
 *
 * <p>`disabled` is the opposite case and is not a hedge at all: the worker is right there in
 * `app_worker` with `enabled = false`, so the gateway never registers it and the rule sends nothing.
 * That rendered identically to a healthy rule until this existed — the one state the panel could be
 * certain about was the one it did not show.
 */
export type TargetKind = "table" | "group" | "worker" | "preprocessor" | "disabled" | "unknown";

/** Whether a rule hands its messages to a preprocessor (`@name`) rather than sending them anywhere. */
export function isPreprocessorTarget(target: string): boolean {
  return target.trim().startsWith("@") && target.trim().length > 1;
}

export function targetKind(
  target: string,
  tableNames: readonly string[],
  workers: readonly TargetWorker[],
  groupNames: readonly string[] = []
): TargetKind {
  const t = target.trim();
  if (!t) {
    return "unknown";
  }
  //checked by the database rather than here: V1.62.0's trigger refuses a rule naming a preprocessor
  //that does not exist, so a saved `@name` always resolves
  if (isPreprocessorTarget(t)) {
    return "preprocessor";
  }
  //`StandardRoutingManager` asks getTargets().getTable(name) before getWorker(name), so a table of
  //the same name wins. Worth surfacing rather than leaving to be discovered
  if (tableNames.includes(t)) {
    return "table";
  }
  //table, then group, then worker -- the gateway's own order. It refuses the whole configuration
  //when a name is in two of the three, so this ordering only ever decides what to CALL a name the
  //gateway would not have accepted anyway
  if (groupNames.includes(t)) {
    return "group";
  }
  //both forms: an outbound vendor registers under its bare instance name, while a listener is
  //reached as `<type>.<name>` -- which is how `smppserver.smpp` returns a delivery receipt to the
  //customer bound to it, and why a bare-name check alone would call that rule dead
  const worker = workers.find((w) => w.name === t || `${w.type}.${w.name}` === t);
  if (!worker) {
    return "unknown";
  }
  //absent means enabled: see TargetWorker.enabled
  return worker.enabled === false ? "disabled" : "worker";
}

/** A rule with nothing narrowing it, so it matches every message that reaches it. */
export function isRoutingCatchAll(rule: RouteRule): boolean {
  //filters count, for the reason the rate side records: a rule carrying one is narrowed by it, and
  //calling that a catch-all is how a table with no real fallback comes to look like it has one
  return !rule.conditions.length && !rule.filters.length;
}

/**
 * Everything wrong with a table that the gateway will not tell you about.
 *
 * <p>All three are silent at runtime: a dead target is skipped, a nested table inside a least-cost
 * table is skipped with a log line nobody reads, and an empty table routes nothing. None of them
 * produce an error, which is exactly why they belong in the editor.
 */
export function routeTableWarnings(
  table: RouteTableInput,
  tableNames: readonly string[],
  workers: readonly TargetWorker[],
  groups: readonly { name: string; members: readonly { enabled: boolean }[] }[] = []
): string[] {
  const warnings: string[] = [];
  const live = table.rules.filter((r) => r.enabled);

  if (!live.length) {
    warnings.push(
      "No enabled rules, so this table routes nothing. A message that reaches it is left with "
      + "nowhere to go."
    );
  }

  for (const rule of live) {
    //the same check the filter form and the rate scope form already make, on the same shared
    //predicate. It never reached this page, so `to startsWith ^91[6-9]...` -- a regex handed to an
    //operator that compares literal text -- warned on /filters and said nothing here, while routing
    //silently matched nothing and dropped the traffic twenty attempts later
    for (const warning of conditionWarnings(rule.conditions)) {
      if (!warnings.includes(warning)) {
        warnings.push(warning);
      }
    }

    if (moRuleExcludesUnicode(rule)) {
      warnings.push(
        `'${rule.target || "(empty)"}' routes inbound messages but is narrowed by a message type, `
        + "so it only catches the GSM-7 ones. A Unicode inbound carries a different type, falls "
        + "through to the outbound rules below and is submitted back out to a vendor as charged "
        + "traffic. Drop the type condition and let the ingateway condition do the work."
      );
    }

    const kind = targetKind(rule.target, tableNames, workers);
    if (kind === "unknown") {
      warnings.push(
        `'${rule.target || "(empty)"}' matches no routing table and no configured worker. Unless it `
        + "is one this panel cannot see, the gateway skips this rule and it sends nothing."
      );
    } else if (kind === "disabled") {
      warnings.push(
        `'${rule.target}' is a configured worker that is switched off, so the gateway never `
        + "registers it and this rule sends nothing. Unlike an unrecognised name this is certain: "
        + "the row is right there with enabled = false."
      );
    } else if (kind === "group" && table.targetFunction === "LCR") {
      //not a warning about one rule: the gateway refuses the WHOLE routing configuration on this,
      //so the table set stops updating entirely until it is fixed
      warnings.push(
        `'${rule.target}' is a vendor group, and this is a least-cost table. The gateway refuses `
        + "the entire routing configuration rather than choose between picking by price and "
        + "picking by the group's policy — so nothing here takes effect until one of the two "
        + "changes."
      );
    } else if (kind === "group"
      && !groups.find((g) => g.name === rule.target)?.members.some((m) => m.enabled)) {
      warnings.push(
        `Every member of '${rule.target}' is switched off, so this rule sends nothing. The message `
        + "falls through to the rule below it, and is dropped if there is none."
      );
    } else if (kind === "preprocessor" && table.targetFunction === "LCR") {
      warnings.push(
        `'${rule.target}' is a preprocessor, and this is a least-cost table — the gateway only `
        + "compares vendors here, so this rule is skipped. Put it in the table that jumps here."
      );
    } else if (kind === "table" && table.targetFunction === "LCR") {
      warnings.push(
        `'${rule.target}' is another routing table, and this is a least-cost table — the gateway `
        + "skips rules like this one because a nested cost cannot be compared against a vendor rate."
      );
    }
  }

  //Ordering, which the rates page has checked for a while and this one never has. A NORMAL table
  //stops at the first match, so both of these are silent at runtime and expensive: the gateway
  //neither errors nor logs, it simply drops the message twenty attempts later.
  if (table.targetFunction === "NORMAL" && live.length) {
    //a preprocessor rule delivers nothing and never stops the scan -- the message comes back and
    //carries on below it -- so it neither catches the rest nor hides what follows. The gateway's
    //own table warnings make the same exception
    const catches = (r: RouteRule) => isRoutingCatchAll(r) && !isPreprocessorTarget(r.target);
    const catchAllAt = live.findIndex(catches);
    //`copied` is the exception, and getting it wrong would make this warning a lie: a copy-and-
    //continue rule adds its target and keeps scanning, so a copied catch-all kills nothing below it
    const stopsAt = live.findIndex((r) => catches(r) && !r.copied);
    if (catchAllAt < 0 && table.name === DEFAULT_TABLE_NAME) {
      //the entry-point table is the one place a missing catch-all is correct: the shipped
      //routingTable.conf enumerates the outbound content types and stops there, so a receipt whose
      //listener has no rule, or an MO from an unmapped vendor, is dropped and refunded rather than
      //handed to a vendor as billed outbound traffic. What is worth saying here is which of those
      //content types has no rule -- the generic sentence below would read as advice to add the one
      //thing this table deliberately does not have
      const uncovered = missingMtTypes(table);
      if (uncovered.length) {
        warnings.push(
          `No rule for outbound message ${uncovered.length === 1 ? "type" : "types"} `
          + `${uncovered.join(", ")}. A message of that type reaches this table, matches nothing `
          + "and is dropped after 20 attempts."
        );
      }
    } else if (catchAllAt < 0) {
      warnings.push(
        "No catch-all: every rule here is narrowed by a condition or a filter, so a message "
        + "matching none of them has nowhere to go and is dropped after 20 attempts. A rule with no "
        + "conditions and no filters, placed last, is what catches the rest."
      );
    } else if (stopsAt >= 0 && stopsAt < live.length - 1) {
      const dead = live.length - stopsAt - 1;
      warnings.push(
        `Rule ${stopsAt + 1} matches everything, and this table stops at the first match — so `
        + `the ${dead === 1 ? "rule" : `${dead} rules`} below it can never be reached. Move it last.`
      );
    }
  }

  if (table.targetFunction === "LCR" && live.some((r) => r.copied)) {
    warnings.push(
      "Copy-and-continue has no meaning in a least-cost table: the whole table is scanned and one "
      + "cheapest candidate is chosen, so nothing is skipped for a copy to bypass."
    );
  }

  return warnings;
}

/**
 * Default routing — the rules the gateway needs to work at all, as distinct from the business
 * rules an operator writes.
 *
 * <p>Three lanes, and the discriminator is not the one the message-type constants suggest.
 * `StandardMessage` declares `MSG_TEXT = 0` and `MSG_DLR = 18` and **no MO type at all**: an
 * inbound MO carries whatever content type its DCS maps to, so `type == 0` for GSM-7 and
 * `type == 11` for UCS-2 — exactly what an ordinary outbound message carries.
 * `SmppClientWorker.routeMo` is what separates them, by stamping `ingateway = smppclient.<vendor>`.
 * Every ingress stamps that field differently (`smppserver.<listener>` for a customer submit, empty
 * for HTTP), which makes it the only field that can tell the three lanes apart.
 *
 * <p>That is why the MO check reads `ingateway` and not `type`. A rule written as
 * `type == 0 AND ingateway == smppclient.x` — which is what this module used to generate — misses
 * a Unicode MO, and the gateway's own seed script records what happens next: the MO falls to the
 * outbound lane and "the customer's own short code becomes a billed outbound message to whoever
 * texted them".
 *
 * <p>The DLR and MO checks stay conservative: they look for a rule that genuinely covers the
 * traffic, not for anything that happens to mention the same field. A false "missing" an operator
 * can dismiss by looking at their table is better than a false "present" that hides a rule which
 * does not do what this expects.
 */
export type SystemRuleKind = "dlr-return" | "mo-route";

export interface SystemRuleGap {
  kind: SystemRuleKind;
  /** The bare worker name, e.g. `smpp`. */
  workerName: string;
  /** `<type>.<name>`, e.g. `smppserver.smpp` — what a rule's `target` or `ingateway` names it as. */
  workerFullName: string;
}

const MSG_TYPE_DLR = "18";

/**
 * The content types an ordinary outbound message carries, as the shipped `conf/routingTable.conf`
 * enumerates them: 0=text, 10=binary, 11=UCS-2, 14=flash, 17=push.
 *
 * <p>Enumerated rather than caught by a catch-all on purpose. A catch-all in the entry-point table
 * would also swallow a receipt whose listener has no rule and an MO from a vendor nobody mapped,
 * and hand both to a vendor as billed outbound traffic. Left unmatched they are dropped and
 * refunded instead, which is the cheaper way to be wrong.
 */
export const MT_MESSAGE_TYPES = ["0", "10", "11", "14", "17"] as const;

/** What `SmppClientWorker.routeMo` stamps on an inbound MO, and nothing else stamps. */
const MO_INGATEWAY_PREFIX = "smppclient.";
/** The worker type alone, so `equals smppclient.vendor1` and `startsWith smppclient.` both read. */
const MO_INGATEWAY_KIND = "smppclient";

/** True when this condition selects MO ingress — the field, the direction, and a live value. */
function namesMoIngress(condition: ConditionInput): boolean {
  return condition.field === "ingateway"
    && !condition.negate
    && (condition.operator === "startsWith" || condition.operator === "equals"
      || condition.operator === "==")
    && condition.value.startsWith(MO_INGATEWAY_KIND);
}

/** True when `rule` covers MO traffic from this specific vendor. */
function coversMoVendor(rule: RouteRule, vendorFullName: string): boolean {
  return rule.conditions.some((c) => {
    if (!namesMoIngress(c)) {
      return false;
    }
    //`startsWith smppclient.` covers every vendor; `startsWith smppclient.acme` covers one
    return c.operator === "startsWith"
      ? vendorFullName.startsWith(c.value)
      : c.value === vendorFullName;
  });
}

/**
 * True when an MO rule also carries `type == 0`, which silently excludes Unicode.
 *
 * <p>Not treated as a missing rule — the vendor's GSM-7 MOs really are routed, and reporting it as
 * absent would flag every deployment carrying the shape this module used to generate. It is
 * surfaced as a warning on the table instead, where it can be read next to the rule it is about.
 */
function moRuleExcludesUnicode(rule: RouteRule): boolean {
  return rule.conditions.some(namesMoIngress)
    && rule.conditions.some((c) => c.field === "type" && c.operator === "==" && !c.negate);
}

/**
 * True when `rule` returns receipts to `workerFullName`.
 *
 * <p>Both shapes count. A single-listener gateway needs only `type == 18`, and that is what shipped
 * — narrowing it later would report every existing rule as missing and move its metrics key. A
 * multi-listener one additionally needs `ingateway`, because otherwise the first matching rule
 * takes every listener's receipts and delivers them to the wrong ESME.
 */
function isDlrReturnRule(rule: RouteRule, gap: Omit<SystemRuleGap, "kind">): boolean {
  //both spellings, because the gateway registers every worker under both: StandardRoutingManager
  //puts `getFullName()` AND `getInstanceName()` into the same target map, so `smpp` and
  //`smppserver.smpp` reach the same listener. `targetKind` already knows this; this did not, and
  //the consequence was worse than a cosmetic false alarm -- the seeded table on a live box writes
  //the bare name, so the listener read as "missing" and a recreate would have appended a second,
  //duplicate return rule
  const target = rule.target.trim();
  if (target !== gap.workerFullName && target !== gap.workerName) {
    return false;
  }
  const receipts = rule.conditions.some((c) => c.field === "type" && c.operator === "=="
    && c.value === MSG_TYPE_DLR && !c.negate);
  if (!receipts) {
    return false;
  }
  if (rule.conditions.length === 1) {
    return true;
  }
  //anything beyond the optional ingateway qualifier narrows the rule further than this expects,
  //and claiming it covers the listener would be the false "present" the type note warns about
  //the qualifier is always the FULL name, whichever spelling the target uses: a receipt carries
  //`ingateway = smppserver.<listener>`, set from the worker's own getFullName()
  return rule.conditions.length === 2 && rule.conditions.some((c) => c.field === "ingateway"
    && (c.operator === "equals" || c.operator === "==") && c.value === gap.workerFullName
    && !c.negate);
}

/**
 * One SMPP listener, one rule: every configured `smppserver` worker needs an enabled rule sending
 * `type == 18` back to itself, or a delivery receipt for a message that arrived on it has nowhere
 * to go and is dropped after 20 routing attempts — see the incident this feature exists to
 * prevent recurring. REST-ingress receipts never reach the router, so they need no rule and are
 * not checked here.
 */
export function missingDlrReturnRules(
  tables: readonly RouteTableInput[],
  servers: readonly (Pick<Worker, "name" | "type"> & { enabled?: boolean })[]
): SystemRuleGap[] {
  const rules = tables.flatMap((t) => t.rules.filter((r) => r.enabled));
  return servers
    //a disabled listener accepts nothing, so a return rule for it is a rule that can never fire --
    //and Recreate would write one per disabled row, quietly growing the table with dead entries.
    //`enabled` is optional so an older caller passing a bare {name,type} still behaves as before
    .filter((w) => w.enabled !== false)
    .map((w) => ({ workerName: w.name, workerFullName: trafficKey(w) }))
    .filter((gap) => !rules.some((r) => isDlrReturnRule(r, gap)))
    .map(({ workerName, workerFullName }) => ({ kind: "dlr-return" as const, workerName, workerFullName }));
}

/**
 * One vendor, one gap — but only when `mo.route` is actually on for it. The flag is off by
 * default for exactly the reason a missing rule matters once it's on: `SmppClientWorker`'s own
 * comment records that turning it on for every deployment already using `forward.mo.url` would
 * have started routing MOs nobody asked to route. Off means no rule is needed and this reports
 * nothing for that vendor, not a warning.
 *
 * <p>Reported per vendor because that is how an operator reads it, even though the rule that closes
 * every gap at once is a single `ingateway startsWith smppclient.`.
 */
export function missingMoRouteRules(
  tables: readonly RouteTableInput[],
  vendors: readonly Worker[]
): SystemRuleGap[] {
  const rules = tables.flatMap((t) => t.rules.filter((r) => r.enabled));
  return vendors
    .filter((w) => isOn(w, "mo.route"))
    .map((w) => ({ workerName: w.name, workerFullName: trafficKey(w) }))
    .filter(({ workerFullName }) => !rules.some((r) => coversMoVendor(r, workerFullName)))
    .map(({ workerName, workerFullName }) => ({ kind: "mo-route" as const, workerName, workerFullName }));
}

/**
 * The outbound message types no enabled rule in this table covers.
 *
 * <p>An MO rule is not counted: it selects on `ingateway`, so it takes inbound traffic of the same
 * content type and leaves the outbound lane exactly as uncovered as before.
 */
export function missingMtTypes(table: RouteTableInput | undefined): string[] {
  if (!table) {
    return [...MT_MESSAGE_TYPES];
  }
  const live = table.rules.filter((r) => r.enabled);
  return MT_MESSAGE_TYPES.filter((type) => !live.some((rule) => {
    if (rule.conditions.some(namesMoIngress)) {
      return false;
    }
    if (isRoutingCatchAll(rule)) {
      return true;
    }
    return rule.conditions.some((c) => c.field === "type" && c.operator === "==" && !c.negate
      && c.value === type);
  }));
}

/** The rule `missingDlrReturnRules` would then no longer report as missing. */
export function buildDlrReturnRule(
  gap: SystemRuleGap,
  options: { qualify?: boolean } = {}
): RouteRule {
  const conditions: ConditionInput[] = [
    { field: "type", operator: "==", value: MSG_TYPE_DLR, negate: false },
  ];
  if (options.qualify) {
    conditions.push({
      field: "ingateway", operator: "equals", value: gap.workerFullName, negate: false,
    });
  }
  return {
    id: null,
    target: gap.workerFullName,
    copied: false,
    label: `system:dlr-return:${gap.workerName}`,
    enabled: true,
    conditions,
    filters: [],
  };
}

/**
 * The one rule that routes every vendor's inbound MO to a listener.
 *
 * <p>No `type` condition, deliberately: see the note at the top of this section. Which listener is
 * the operator's choice — the listener's own `mo.owner.map` resolves the message to a customer from
 * there, so the routing rule only has to get it to the right process.
 */
export function buildMoRouteRule(target: string): RouteRule {
  return {
    id: null,
    target: target.trim(),
    copied: false,
    label: "system:mo-route",
    enabled: true,
    conditions: [
      { field: "ingateway", operator: "startsWith", value: MO_INGATEWAY_PREFIX, negate: false },
    ],
    filters: [],
  };
}

/** One rule per outbound content type, chaining to whatever the operator picked. */
export function buildMtRules(target: string): RouteRule[] {
  return MT_MESSAGE_TYPES.map((type) => ({
    id: null,
    target: target.trim(),
    copied: false,
    label: `system:mt:${type}`,
    enabled: true,
    conditions: [{ field: "type", operator: "==", value: type, negate: false }],
    filters: [],
  }));
}

/**
 * A starting point for a single vendor's MO rule — conditions filled in, target deliberately blank,
 * for an operator who wants one vendor's inbound to go somewhere of its own rather than taking the
 * shared rule `buildMoRouteRule` writes.
 */
export function buildMoRouteRuleDraft(gap: SystemRuleGap): RouteRule {
  return {
    id: null,
    target: "",
    copied: false,
    label: null,
    enabled: true,
    conditions: [
      { field: "ingateway", operator: "equals", value: gap.workerFullName, negate: false },
    ],
    filters: [],
  };
}

/**
 * How a rule's own traffic flows, read off its conditions.
 *
 * <p>`ingateway` is consulted before `type`, and that order is the whole correctness of this
 * function: an inbound MO carries `type == 0` or `type == 11`, the same values an ordinary outbound
 * message carries, so reading `type` first labels every stock `MESSAGE:type:==:0` rule "Inbound".
 *
 * <p>Best-effort, not exhaustive: a rule combining a direction condition with something else (say,
 * `type == 18 AND account == acme`) is still labelled by its direction, because the label answers
 * "which way does this go" and that is still true — only the default-routing detection above
 * requires a shape it can be certain about.
 */
export type RuleDirection = "receipt" | "inbound" | "outbound";

/** What to call each direction on screen, next to the badge variant a caller pairs it with. */
export const RULE_DIRECTION_LABEL: Record<RuleDirection, string> = {
  receipt: "Receipt",
  inbound: "Inbound",
  outbound: "Outbound",
};

export function ruleDirection(rule: RouteRule): RuleDirection {
  if (rule.conditions.some(namesMoIngress)) {
    return "inbound";
  }
  //negate matters even in this best-effort reading: "type != 18" means everything EXCEPT
  //receipts, which is the opposite direction from what a bare value match would suggest
  const typeValue = rule.conditions
    .find((c) => c.field === "type" && c.operator === "==" && !c.negate)?.value;
  return typeValue === MSG_TYPE_DLR ? "receipt" : "outbound";
}

/** The name the gateway refuses to start without — `StandardRoutingManager` insists on it by name. */
export const DEFAULT_TABLE_NAME = "default";

/** Where each lane should send, for the two lanes whose target cannot be derived from config. */
export interface DefaultRoutingTargets {
  /** A table, group or vendor that ordinary outbound messages chain to. */
  mtTarget: string;
  /** The listener inbound MOs are delivered to. */
  moTarget: string;
}

export interface DefaultRoutingPlan {
  /** The `default` table as it should be written. Safe to hand straight to `saveRouteTable`. */
  table: RouteTableInput;
  /** One sentence per change, in the order they were decided. Empty means nothing to do. */
  changes: string[];
  /** True when the table does not exist yet — the accidental-delete case. */
  created: boolean;
}

/**
 * What it would take to make default routing whole again, without disturbing anything an operator
 * wrote.
 *
 * <p>Additive: every existing rule survives, with its id, its conditions and its target untouched.
 * The only thing that moves is position, and only into three bands — the direction rules first,
 * then everything else in the order it was already in, then any catch-all last.
 *
 * <p>That ordering is not tidiness. An MO carries the same message type as an outbound message, so
 * an MO rule below the outbound lane never runs; and a receipt's `from`/`to` are swapped relative
 * to the message it is about, so a rule selecting on sender ID can catch one. Both are silent at
 * runtime — the gateway neither errors nor logs, the message is simply dropped twenty attempts
 * later or, worse, billed out to a vendor.
 *
 * <p>Idempotent: run twice, the second run reports no changes and writes nothing.
 */
export function defaultRoutingPlan(
  tables: readonly RouteTableInput[],
  servers: readonly Pick<Worker, "name" | "type">[],
  vendors: readonly Worker[],
  targets: DefaultRoutingTargets
): DefaultRoutingPlan {
  const existing = tables.find((t) => t.name === DEFAULT_TABLE_NAME);
  const created = !existing;
  const base: RouteTableInput = existing
    ? { ...existing, rules: [...existing.rules] }
    : {
      name: DEFAULT_TABLE_NAME, targetFunction: "NORMAL", label: null, enabled: true, rules: [],
    };

  const changes: string[] = [];
  if (created) {
    changes.push(
      "Creates the 'default' table. The gateway refuses a routing configuration without one, so "
      + "until it exists nothing routes at all."
    );
  }

  const added: RouteRule[] = [];

  //receipts first: the one lane with a target that needs no asking. Qualified by ingateway only
  //when there is more than one listener to tell apart
  const qualify = servers.length > 1;
  for (const gap of missingDlrReturnRules(tables, servers)) {
    added.push(buildDlrReturnRule(gap, { qualify }));
    changes.push(`Returns delivery receipts arriving on ${gap.workerFullName} to that listener.`);
  }

  const moGaps = missingMoRouteRules(tables, vendors);
  const moTarget = targets.moTarget.trim();
  if (moGaps.length && moTarget) {
    added.push(buildMoRouteRule(moTarget));
    const names = moGaps.map((g) => g.workerName).join(", ");
    changes.push(`Sends inbound messages from ${names} to ${moTarget}.`);
  }

  const missingTypes = missingMtTypes(existing);
  const mtTarget = targets.mtTarget.trim();
  if (missingTypes.length && mtTarget) {
    added.push(...buildMtRules(mtTarget)
      .filter((r) => missingTypes.includes(r.conditions[0].value)));
    changes.push(`Sends outbound message types ${missingTypes.join(", ")} to ${mtTarget}.`);
  }

  //a catch-all is never a direction rule -- it has no conditions, so it reads as outbound -- which
  //is what keeps these three bands disjoint
  const all = [...base.rules, ...added];
  const direction = all.filter((r) => ruleDirection(r) !== "outbound");
  const catchAlls = all.filter((r) => ruleDirection(r) === "outbound" && isRoutingCatchAll(r));
  const rest = all.filter((r) => ruleDirection(r) === "outbound" && !isRoutingCatchAll(r));
  const rules = [...direction, ...rest, ...catchAlls];

  //compared against a plain append, so this reports the banding and not the addition. Comparing
  //the surviving rules against each other instead would miss the case that matters most -- a lone
  //catch-all sitting first, which keeps its position among the survivors while every new rule
  //lands above it
  if (rules.some((r, i) => r !== all[i])) {
    changes.push(
      "Moves the receipt and inbound rules above the outbound ones, and any catch-all last. An "
      + "inbound message carries the same message type as an outbound one, so an inbound rule "
      + "sitting below the outbound lane never sees a message."
    );
  }

  return { table: { ...base, rules }, changes, created };
}

/** The name is a primary key referenced by every rule that chains into it, so it is exact. */
export function validateRouteTable(input: RouteTableInput): string | null {
  const name = input.name ?? "";
  if (!name.trim()) {
    return "A routing table needs a name. Rules chain into it by that name.";
  }
  if (name !== name.trim()) {
    return `'${name}' has a space at one end. Table names are matched exactly and a trailing space `
      + "is invisible everywhere it is shown, so nothing would ever route into it.";
  }
  for (const [i, rule] of input.rules.entries()) {
    //the API route hands `raw.rules` straight here after an Array.isArray check and nothing more,
    //so the elements are whatever was posted. Checked rather than trusted: an absent `conditions`
    //or `value` would otherwise throw inside the loop below and answer a bad request with a 500,
    //which reads as "the panel is broken" instead of "that body is wrong"
    if (typeof rule?.target !== "string" || !rule.target.trim()) {
      return "Every rule needs a target — the worker or table it sends to.";
    }
    if (!Array.isArray(rule.conditions)
      || rule.conditions.some((c) => typeof c?.field !== "string"
        || typeof c?.operator !== "string" || typeof c?.value !== "string")) {
      return `Rule ${i + 1} has a malformed condition. Each one needs a field, an operator and a `
        + "value, all text.";
    }
    //the check this file never ran. A numeric operator on a text field saved cleanly and then made
    //the gateway refuse the WHOLE table set, silently keeping the previous one -- so the page
    //showed one thing and the gateway routed another, with nothing anywhere saying so
    const bad = conditionErrors(rule.conditions, `rule ${i + 1}`, "routing table");
    if (bad) {
      return bad;
    }
  }
  return null;
}

/** One rule in a sentence, for the summary line under it. */
export function describeRouteRule(
  rule: RouteRule,
  targetFunction: TargetFunction,
  tableNames: readonly string[],
  workers: readonly TargetWorker[]
): string {
  const kind = targetKind(rule.target, tableNames, workers);
  if (kind === "unknown") {
    return `'${rule.target || "(no target)"}' matches no table and no worker this panel knows of.`;
  }
  if (kind === "preprocessor") {
    return targetFunction === "LCR"
      ? "Skipped — a least-cost table only compares vendors."
      : `Hands matching messages to the ${rule.target.trim().slice(1)} preprocessor, then carries on below with its answer.`;
  }
  const where = kind === "table" ? `into the ${rule.target} table` : `to ${rule.target}`;
  const when = rule.conditions.length || rule.filters.length
    ? "when its conditions hold"
    : "for every message that reaches it";

  if (targetFunction === "LCR") {
    return kind === "table"
      ? `Skipped — a least-cost table cannot compare a nested table's cost.`
      : `A candidate ${when}; wins only if ${rule.target} is the cheapest of them.`;
  }
  return rule.copied
    ? `Copies ${where} ${when}, and carries on to the rules below.`
    : `Sends ${where} ${when}, and stops.`;
}

/**
 * The gateway's own answer to "which rule would this message hit" — mirrors
 * `RoutingExplanation`/`RoutingExplanation.RuleOutcome` in `fireflo-restapi`. Built from
 * `RoutingRule.matches`/`explainMismatch` against the live table set, not from anything this panel
 * infers, which is the entire reason it is worth calling rather than reading the rule conditions by
 * eye.
 */
export interface RuleOutcome {
  index: number;
  target: string;
  label: string | null;
  matched: boolean;
  mismatch: string | null;
  evaluable: boolean;
}

export interface RoutingExplanation {
  table: string;
  tableFound: boolean;
  targetFunction: TargetFunction | null;
  matchedIndex: number | null;
  rules: RuleOutcome[];
}


/**
 * Where a receipt for one listener actually goes, according to the gateway's own matcher.
 *
 * <p><strong>The check that {@link missingDlrReturnRules} cannot make.</strong> That one answers
 * "is a return rule present". This answers "where does a receipt land", and the difference between
 * those two questions is an entire incident: on a box with a second listener, a receipt was routed
 * to the *first* listener and parked unreachable — a rule was present and matching, so nothing was
 * reported missing. Repairing it by hand then left `type == 18` matching a rule that targeted the
 * **vendor**, and receipts were submitted upstream as billed outbound messages.
 *
 * <p>Rules are first-match in `seq` order and a receipt is an ordinary message to the matcher — its
 * addresses are merely reversed — so a business rule above the return rule swallows it. Position is
 * what makes the return rule work, not its conditions, and only the matcher can see position.
 *
 * @param expectedTarget the listener the probe was run for, in `smppserver.<name>` form
 * @param answeredTarget what `/ops/routing/explain` said, or null when nothing matched
 */
export function receiptRoutingProblem(
  expectedTarget: string,
  answeredTarget: string | null
): { severity: "none" | "warn" | "danger"; message: string } {
  if (answeredTarget === expectedTarget) {
    return { severity: "none", message: "" };
  }
  if (answeredTarget === null || answeredTarget.trim() === "") {
    return {
      severity: "warn",
      message: `No rule places a delivery receipt from ${expectedTarget}. Its customers receive `
        + "none: the receipt is retried and then dropped.",
    };
  }
  //a receipt reaching a vendor is not a worse shade of the same fault -- it leaves the platform as
  //traffic, is billed, and may put an Appendix B receipt on somebody's handset as a message
  if (answeredTarget.startsWith("smppclient.")) {
    return {
      severity: "danger",
      message: `Receipts from ${expectedTarget} are being routed to ${answeredTarget}, a VENDOR. `
        + "They are submitted upstream as outbound messages and billed. Move the receipt rule above "
        + "the rule that is matching, or disable that rule now.",
    };
  }
  return {
    severity: "warn",
    message: `Receipts from ${expectedTarget} are going to ${answeredTarget}, not to the listener `
      + "the message arrived on. Their customers receive nothing. The receipt rule needs an "
      + `ingateway condition, and it must sit above the rule matching first.`,
  };
}
