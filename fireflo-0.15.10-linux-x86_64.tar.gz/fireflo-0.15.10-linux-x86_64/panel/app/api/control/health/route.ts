import { NextResponse } from "next/server";
import { gqlFailed } from "@/lib/gateway-graphql";
import { executeGql } from "@/lib/gateway-graphql-core";
import { HEALTH, HEALTH_CLUSTER, HEALTH_CLUSTER_ROUTER, HEALTH_CLUSTER_SOURCE, HEALTH_THROTTLING } from "@/lib/gateway-queries";
import {
  ACCOUNT_THROUGHPUT_VIEW, KAFKA_BACKBONE, NODE_IDENTITY, QUEUE_PROVIDER_ENV, ROUTER_ANCHOR, hasCapability,
} from "@/lib/capabilities";
import {
  flattenHealth, type HealthClusterField, type HealthField, type HealthThrottlingField, withCluster, withThrottling,
} from "@/lib/health-types";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { withSourceTrace } from "@/lib/source-trace-route";

/**
 * GET /api/control/health
 *
 * <p>Proxies the gateway's `health` field. A proxy rather than a direct browser call for two
 * reasons: the shared token stays on the server and never reaches a page, and the operator check
 * happens here rather than being something the gateway would have to learn about.
 *
 * <p>The answer keeps the shape `/ops/health` had: `flattenHealth` spreads the typed fields the
 * gateway now carries beside the snapshot over it, under the names the pages already read.
 *
 * <p>The cluster fields (`nodeId`, `cluster`, `backbone`; gateway 0.14) come from a second document,
 * sent only when the capability map says the gateway has them: a 0.13 gateway rejects a selection
 * it does not know, and health must keep answering there. In-memory on the gateway, so the second
 * round trip is cheap; a failure of it leaves the first answer intact rather than failing the poll.
 * `backbone.source` (fireflo.env or `app_config`) is asked for the same way, only from a gateway
 * that declares `queue_provider_env`; on 0.14.0 and 0.14.1 it is simply absent. `backbone.state` and
 * `backbone.router` (held and stalled router partitions, 0.15.10) likewise only from one that declares
 * `router_anchor`. The accounts being
 * throttled (`throttling`, 0.15.1) come the same way, from a gateway with `account_throughput`.
 */
export const GET = withSourceTrace(async function GET(): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  //the gateway is answering from memory; if it cannot do that in five seconds it is the problem
  //being diagnosed, not a slow query
  const first = await executeGql<HealthField>({ query: HEALTH, timeoutMs: 5_000 });
  if (!first.ok) {
    return gqlFailed(first);
  }
  let health = flattenHealth(first.data);
  if (hasCapability(health, NODE_IDENTITY) || hasCapability(health, KAFKA_BACKBONE)) {
    const query = hasCapability(health, ROUTER_ANCHOR)
      ? HEALTH_CLUSTER_ROUTER
      : hasCapability(health, QUEUE_PROVIDER_ENV) ? HEALTH_CLUSTER_SOURCE : HEALTH_CLUSTER;
    const second = await executeGql<HealthClusterField>({ query, timeoutMs: 5_000 });
    if (second.ok) {
      health = withCluster(health, second.data);
    }
  }
  //who this node is throttling (0.15.1): a third document, only to a gateway that names it, and
  //like the second a failure leaves the rest of health standing
  if (hasCapability(health, ACCOUNT_THROUGHPUT_VIEW)) {
    const third = await executeGql<HealthThrottlingField>({ query: HEALTH_THROTTLING, timeoutMs: 5_000 });
    if (third.ok) {
      health = withThrottling(health, third.data);
    }
  }
  return NextResponse.json({ data: health });
});
