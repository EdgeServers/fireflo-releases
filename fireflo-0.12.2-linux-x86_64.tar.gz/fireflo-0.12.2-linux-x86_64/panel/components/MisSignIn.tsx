"use client";
import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader } from "@/components/ui/card";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { FireFloMark, FireFloWordmark } from "./FireFloMark";
import { verifyOutcome, type VerifySession } from "@/lib/verify-outcome";

/**
 * Sign in with a password, or ask for a sign-in link.
 *
 * <p>Password first, because a customer who has one should not wait for mail. The link stays one
 * click away: it is how anybody without a password gets in, and how somebody who has forgotten
 * theirs does. A wrong password gets one sentence whatever was wrong -- unknown address, no
 * password on that login, disabled account -- for the same reason the link's confirmation does.
 *
 * <h2>The link</h2>
 *
 * <p><strong>The confirmation is the same whatever happened.</strong> Unknown address, disabled
 * account, mail server refusing us — one message. That is deliberate and it comes at a real cost: a
 * customer who mistypes their address gets the same reassuring sentence as one who did not, and
 * will wait for a mail that never arrives.
 *
 * <p>The alternative is worse. "No account with that address" turns this form into a way to test a
 * list of addresses against the customer base, and the customer base is the thing worth stealing
 * from an SMS gateway. So the wording carries the hedge — *if that address is on an account* —
 * which is honest about the uncertainty rather than promising something it cannot know.
 *
 * <p><strong>Which is exactly why resending has to be offered.</strong> The customer cannot be told
 * whether the mail failed, so the one thing they can usefully do — ask again — must be in front of
 * them rather than requiring a reload. The wait is there because mail is not instant: a resend
 * offered immediately gets pressed immediately, three times, and the customer then has three links
 * of which only the last one works.
 */

/** Long enough for a relay to deliver, short enough not to feel like a punishment. */
const RESEND_AFTER_SECONDS = 120;

/**
 * Survives a reload, deliberately.
 *
 * <p>Without this the countdown is theatre: refresh the page and it is gone. Worse, the customer who
 * refreshes and sends again spends another of their five requests per quarter hour and invalidates
 * the link that may be arriving. Session storage rather than local: it belongs to this tab and this
 * visit, and a link asked for yesterday should not silently gag the form today.
 */
const RESEND_KEY = "fireflo.mis.resend";

interface Pending {
  email: string;
  /** Epoch milliseconds. Absolute, not a duration — see the tick below. */
  until: number;
}

function readPending(): Pending | null {
  try {
    const raw = sessionStorage.getItem(RESEND_KEY);
    if (!raw) {
      return null;
    }
    const parsed = JSON.parse(raw) as Partial<Pending>;
    if (typeof parsed.email !== "string" || typeof parsed.until !== "number") {
      return null;
    }
    return parsed.until > Date.now() ? { email: parsed.email, until: parsed.until } : null;
  } catch {
    //private modes throw on sessionStorage, and a corrupt value is not worth a crash. The countdown
    //is a courtesy; the rate limit on the server is the thing that actually holds
    return null;
  }
}

function writePending(pending: Pending | null): void {
  try {
    if (pending) {
      sessionStorage.setItem(RESEND_KEY, JSON.stringify(pending));
    } else {
      sessionStorage.removeItem(RESEND_KEY);
    }
  } catch {
    //as above
  }
}

function mmss(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}

export function MisSignIn({ brand = "FireFlo" }: { brand?: string }) {
  const router = useRouter();
  const [mode, setMode] = useState<"password" | "link">("password");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [resendAt, setResendAt] = useState(0);
  //seeded at first render rather than from an effect, so the countdown is never computed against a
  //clock reading from whenever the component happened to mount. Safe for hydration: nothing
  //rendered on the server depends on it -- the countdown only exists once "sent" is true
  const [now, setNow] = useState(() => Date.now());

  //restored after mount rather than during render: sessionStorage does not exist on the server, and
  //reading it in the initial state would make the first client render disagree with the HTML
  useEffect(() => {
    const pending = readPending();
    if (pending) {
      setMode("link");
      setEmail(pending.email);
      setSent(true);
      setResendAt(pending.until);
    }
  }, []);

  //ticks against the CLOCK, not a counter it decrements. A background tab has its timers throttled
  //to once a minute or stopped outright, so a counter that subtracts one per tick would still read
  //"1:47" on a tab left alone for five minutes.
  //
  //Reading Date.now() on each tick makes the value correct rather than drifted -- but only as often
  //as the tick fires, which on a hidden tab is once a minute. Watching visibilitychange as well is
  //what makes it correct ON RETURN: the customer switches to their mail client, comes back, and the
  //button is right immediately instead of showing a minute-old number. Observed, not theorised --
  //a hidden tab in testing sat at 1:53 while the true remaining was 1:11
  useEffect(() => {
    if (!resendAt) {
      return;
    }
    const tick = () => setNow(Date.now());
    const id = setInterval(tick, 1000);
    document.addEventListener("visibilitychange", tick);
    return () => {
      clearInterval(id);
      document.removeEventListener("visibilitychange", tick);
    };
  }, [resendAt]);

  const secondsLeft = resendAt ? Math.max(0, Math.ceil((resendAt - now) / 1000)) : 0;

  const request = useCallback(
    async (address: string) => {
      setBusy(true);
      setError("");
      try {
        const res = await fetch("/api/mis/login-link", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: address }),
        });
        const json = (await res.json().catch(() => null)) as { error?: string } | null;
        if (!res.ok) {
          //the one case with a real message rather than the neutral answer: this panel cannot send
          //mail at all. Safe to show, because it is decided before any account is looked up
          setError(json?.error ?? "Something went wrong. Try again.");
          return false;
        }
        const until = Date.now() + RESEND_AFTER_SECONDS * 1000;
        //both from the same reading, in an event handler where the clock is current: the first
        //interval tick is a second away, and until then this is what the countdown renders against
        setNow(Date.now());
        setResendAt(until);
        writePending({ email: address, until });
        setSent(true);
        return true;
      } catch {
        setError("Could not reach the server. Try again.");
        return false;
      } finally {
        setBusy(false);
      }
    },
    []
  );

  function submit(e: React.FormEvent) {
    e.preventDefault();
    void request(email);
  }

  /**
   * The same three steps as the link's redeem in MisVerify: a CSRF token, the credentials POST, then
   * the session -- and the same rule for reading the answer, in lib/verify-outcome.ts.
   */
  async function signInWithPassword(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const csrfRes = await fetch("/api/mis/auth/csrf");
      const { csrfToken } = (await csrfRes.json()) as { csrfToken: string };
      const body = new URLSearchParams({ csrfToken, email: email.trim(), password, redirect: "false" });
      const res = await fetch("/api/mis/auth/callback/password", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body,
      });
      const session = (await (await fetch("/api/mis/auth/session")).json()) as VerifySession;
      if (verifyOutcome(res.url, window.location.origin, session) === "signed-in") {
        router.replace("/overview");
        return;
      }
      setPassword("");
      setError("That email and password do not match, or that login has no password yet. "
        + "You can sign in by emailed link instead.");
    } catch {
      setError("Could not reach the server. Try again.");
    } finally {
      setBusy(false);
    }
  }

  function switchTo(next: "password" | "link") {
    setMode(next);
    setError("");
    setPassword("");
  }

  function startOver() {
    setSent(false);
    setError("");
    setResendAt(0);
    writePending(null);
  }

  return (
    <main className="flex min-h-dvh items-center justify-center px-4 py-10">
      <Card className="w-full max-w-md">
        <CardHeader bar className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <FireFloMark />
            <FireFloWordmark name={brand} />
            <Badge variant="outline">MIS Panel</Badge>
          </div>
          <CardDescription>
            {mode === "password"
              ? "Sign in with the email address on your account and your password."
              : "We will email a single-use sign-in link to the address on your account."}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {mode === "password" ? (
            <form onSubmit={signInWithPassword} className="space-y-4">
              <Field label="Email address" htmlFor="mis-email">
                <Input
                  id="mis-email"
                  type="email"
                  required
                  autoComplete="username"
                  autoFocus
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </Field>
              <Field label="Password" htmlFor="mis-password">
                <Input
                  id="mis-password"
                  type="password"
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </Field>
              {error && <p className="text-sm text-destructive">{error}</p>}
              <Button type="submit" className="w-full" disabled={busy || !email.trim() || !password}>
                {busy ? "Signing in…" : "Sign in"}
              </Button>
              <div className="text-center">
                <Button type="button" variant="ghost" size="sm" onClick={() => switchTo("link")}>
                  No password, or forgotten it? Email me a sign-in link instead
                </Button>
              </div>
            </form>
          ) : sent ? (
            <div className="space-y-2 text-sm">
              <p className="font-medium">Check your inbox.</p>
              <p className="text-muted-foreground">
                If that address is on an account, a sign-in link is on its way to{" "}
                <span className="font-medium text-foreground">{email}</span>. It works once and
                expires in 15 minutes.
              </p>
              <p className="text-muted-foreground">
                Nothing after a minute or two? Check the spam folder, then send it again — the newest
                link is the one that works.
              </p>
              {error && <p className="text-destructive">{error}</p>}
              <div className="mt-3 flex flex-wrap gap-2">
                <Button
                  size="sm"
                  disabled={busy || secondsLeft > 0}
                  onClick={() => void request(email)}
                >
                  {busy
                    ? "Sending…"
                    : secondsLeft > 0
                      ? `Send it again in ${mmss(secondsLeft)}`
                      : "Send it again"}
                </Button>
                <Button variant="outline" size="sm" onClick={startOver}>
                  Use a different address
                </Button>
              </div>
            </div>
          ) : (
            <form onSubmit={submit} className="space-y-4">
              <Field label="Email address" htmlFor="mis-email">
                <Input
                  id="mis-email"
                  type="email"
                  required
                  autoComplete="email"
                  autoFocus
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </Field>
              {error && <p className="text-sm text-destructive">{error}</p>}
              <Button type="submit" className="w-full" disabled={busy || !email.trim()}>
                {busy ? "Sending…" : "Email me a link"}
              </Button>
              <div className="text-center">
                <Button type="button" variant="ghost" size="sm" onClick={() => switchTo("password")}>
                  Sign in with a password instead
                </Button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>
    </main>
  );
}
