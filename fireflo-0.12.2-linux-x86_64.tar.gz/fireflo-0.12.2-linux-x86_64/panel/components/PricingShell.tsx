"use client";
import { createContext, useContext, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Download, Plus, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { PageHeader } from "@/components/ui/page-header";
import { Select } from "@/components/ui/select";
import { HealthStrip } from "./CardBits";
import { GatewayIgnores } from "./GatewayIgnores";
import { PricingExportDialog, PricingImportDialog } from "./PricingTransfer";
import { useFilters } from "./useFilters";
import { useProductCatalogue } from "./useProducts";
import { useRates } from "./useRates";
import type { Filter } from "@/lib/filter-types";
import { DEFAULT_SCOPE, scopeKind, type KnownScopes, type RateRule, type RateRuleInput, type ScopeSummary } from "@/lib/rate-types";
import { cn } from "@/lib/utils";

/**
 * Everything the Pricing section reads, loaded once in its layout.
 *
 * <p>The left column lists what can be priced -- the default, the accounts with pricing of their
 * own, every vendor -- and the right is the open one. Accounts that pay the default are not listed:
 * a deployment has hundreds, and a column of "Default" rows buried the ones that say something. The
 * find box reaches any of them.
 */
export interface PricingData {
  scopes: ScopeSummary[];
  known: KnownScopes;
  loading: boolean;
  error: string;
  busy: string;
  catalogue: string[];
  filters: Filter[];
  reload: () => Promise<void>;
  loadScope: (scope: string) => Promise<RateRule[] | null>;
  saveScope: (scope: string, rules: RateRuleInput[], confirmed: boolean, isNew?: boolean) => Promise<string | null>;
  removeScope: (scope: string) => Promise<boolean>;
}

const Ctx = createContext<PricingData | null>(null);

export function usePricingData(): PricingData {
  const value = useContext(Ctx);
  if (!value) {
    throw new Error("usePricingData is used outside the Pricing layout.");
  }
  return value;
}

/** One scope's page. `?new=1` opens a new price on arrival; `&product=` fills its product. */
export function scopeHref(scope: string, opts: { new?: boolean; product?: string | null } = {}): string {
  const q = new URLSearchParams();
  if (opts.new) q.set("new", "1");
  if (opts.product) q.set("product", opts.product);
  const tail = q.size ? `?${q}` : "";
  return `/cp/pricing/scope/${encodeURIComponent(scope)}${tail}`;
}

export function scopeTitle(scope: string): string {
  return scope === DEFAULT_SCOPE ? "Everyone" : scope;
}

export function PricingShell({ children }: { children: ReactNode }) {
  const rates = useRates();
  const catalogue = useProductCatalogue();
  const { filters } = useFilters();
  const [dialog, setDialog] = useState<"add" | "export" | "import" | null>(null);
  const pathname = usePathname();
  const openScope = pathname.startsWith("/cp/pricing/scope/")
    ? decodeURIComponent(pathname.slice("/cp/pricing/scope/".length))
    : null;

  const data: PricingData = {
    scopes: rates.scopes,
    known: rates.known,
    loading: rates.loading,
    error: rates.error,
    busy: rates.busy,
    catalogue,
    filters,
    reload: rates.load,
    loadScope: rates.loadScope,
    saveScope: rates.saveScope,
    removeScope: rates.removeScope,
  };

  return (
    <Ctx.Provider value={data}>
      <PageHeader
        title="Pricing"
        description="What vendors charge us and what accounts pay. Within a scope and a product, the first matching price wins."
        actions={
          <>
            <Button variant="outline" className="gap-2" onClick={() => setDialog("export")}>
              <Download className="h-4 w-4" aria-hidden="true" /> Export
            </Button>
            <Button variant="outline" className="gap-2" onClick={() => setDialog("import")}>
              <Upload className="h-4 w-4" aria-hidden="true" /> Import
            </Button>
            <Button className="gap-2" onClick={() => setDialog("add")}>
              <Plus className="h-4 w-4" aria-hidden="true" /> Add pricing
            </Button>
          </>
        }
      />
      {/* nothing below matters if the gateway is not reading any of it */}
      <GatewayIgnores domain="rates" />
      {rates.error && <HealthStrip tone="destructive">{rates.error}</HealthStrip>}
      <div className="flex flex-wrap items-start gap-6">
        <PricingNav data={data} active={openScope} />
        <div className="flex min-w-0 flex-[999_1_560px] flex-col gap-5">{children}</div>
      </div>
      {dialog === "add" && <AddPricingDialog known={rates.known} onClose={() => setDialog(null)} />}
      {dialog === "export" && <PricingExportDialog scope={openScope} scopes={rates.scopes} onClose={() => setDialog(null)} />}
      {dialog === "import" && (
        <PricingImportDialog
          onClose={() => setDialog(null)}
          onApplied={async () => {
            await rates.load();
          }}
        />
      )}
    </Ctx.Provider>
  );
}

function PricingNav({ data, active }: { data: PricingData; active: string | null }) {
  const router = useRouter();
  const [find, setFind] = useState("");
  const q = find.trim().toLowerCase();
  const byScope = new Map(data.scopes.map((s) => [s.scope, s]));
  const kind = (s: string) => scopeKind(s, data.known);

  const pricedAccounts = data.scopes.filter((s) => kind(s.scope) === "price").map((s) => s.scope);
  //searching reaches every account the panel knows, priced or not
  const accounts = q ? data.known.accounts.filter((a) => a.toLowerCase().includes(q)) : pricedAccounts;
  const unpriced = data.known.accounts.length - pricedAccounts.length;
  const vendors = data.known.vendors.filter((v) => !q || v.toLowerCase().includes(q));
  const unknown = data.scopes.filter((s) => kind(s.scope) === "unknown").map((s) => s.scope)
    .filter((s) => !q || s.toLowerCase().includes(q));
  const shownAccounts = accounts.slice(0, 50);

  const count = (s: string) => byScope.get(s)?.rules ?? 0;
  const rulesChip = (s: string) => {
    const n = count(s);
    return <Chip tone="ok">{n} {n === 1 ? "rule" : "rules"}</Chip>;
  };

  const row = (scope: string, chip: ReactNode, sub?: string) => (
    <Link
      key={scope}
      href={scopeHref(scope)}
      aria-current={active === scope ? "page" : undefined}
      className={cn(
        "flex items-center gap-2 rounded-lg px-3 py-2",
        active === scope ? "border border-border bg-card font-semibold shadow-sm" : "text-muted-foreground hover:bg-muted hover:text-foreground"
      )}
    >
      <span className="flex min-w-0 flex-col">
        <span className={cn("truncate text-foreground", scope !== DEFAULT_SCOPE && "font-mono text-xs")}>{scopeTitle(scope)}</span>
        {sub && <span className="text-2xs font-normal text-muted-foreground">{sub}</span>}
      </span>
      <span className="ml-auto shrink-0">{chip}</span>
    </Link>
  );
  const heading = (text: string) => (
    <div className="px-3 pb-1 pt-4 text-2xs font-bold uppercase tracking-wider text-muted-foreground">{text}</div>
  );

  return (
    <>
      {/* a select on a phone; accounts that pay the default are reached through Add pricing there */}
      <label className="flex w-full flex-col gap-1 text-xs text-muted-foreground lg:hidden">
        Show
        <Select
          aria-label="Pricing to show"
          value={active === null ? "" : active}
          onChange={(e) => router.push(e.target.value === "" ? "/cp/pricing" : scopeHref(e.target.value))}
        >
          <option value="">Overview</option>
          <option value={DEFAULT_SCOPE}>Everyone · the default</option>
          <optgroup label="Accounts with their own pricing">
            {pricedAccounts.map((a) => <option key={a} value={a}>{a} · {count(a)} rules</option>)}
            {active !== null && kind(active) === "price" && !pricedAccounts.includes(active) && (
              <option value={active}>{active} · pays the default</option>
            )}
          </optgroup>
          <optgroup label="Vendors">
            {data.known.vendors.map((v) => <option key={v} value={v}>{v} · {count(v) ? `${count(v)} rules` : "no cost"}</option>)}
          </optgroup>
          {unknown.length > 0 && (
            <optgroup label="Matches nothing">
              {unknown.map((u) => <option key={u} value={u}>{u}</option>)}
            </optgroup>
          )}
        </Select>
      </label>

      <nav aria-label="Pricing" className="hidden flex-[0_0_260px] flex-col gap-1 text-sm lg:sticky lg:top-4 lg:flex">
        <Link
          href="/cp/pricing"
          aria-current={active === null ? "page" : undefined}
          className={cn(
            "rounded-lg px-3 py-2",
            active === null ? "border border-border bg-card font-semibold text-foreground shadow-sm" : "text-muted-foreground hover:bg-muted hover:text-foreground"
          )}
        >
          Overview
        </Link>
        {row(DEFAULT_SCOPE, count(DEFAULT_SCOPE) ? rulesChip(DEFAULT_SCOPE) : <Chip tone="warn">Not set</Chip>, "every account without its own")}

        <Input
          aria-label="Find an account or vendor"
          placeholder="Find an account or vendor"
          value={find}
          onChange={(e) => setFind(e.target.value)}
          className="mt-2"
        />

        {heading("Accounts · what they pay us")}
        {data.loading && <p className="px-3 text-muted-foreground">Loading…</p>}
        {shownAccounts.map((a) => row(a, count(a) ? rulesChip(a) : <Chip>Default</Chip>))}
        {accounts.length > shownAccounts.length && (
          <p className="px-3 text-xs text-muted-foreground">{accounts.length - shownAccounts.length} more. Narrow the search.</p>
        )}
        {!data.loading && !accounts.length && (
          <p className="px-3 text-xs text-muted-foreground">{q ? "No account matches." : "No account has pricing of its own yet."}</p>
        )}
        {!q && unpriced > 0 && (
          <p className="px-3 text-xs text-muted-foreground">
            {unpriced} more {unpriced === 1 ? "account pays" : "accounts pay"} the default. Search to find one.
          </p>
        )}

        {heading("Vendors · what they charge us")}
        {vendors.map((v) => row(v, count(v) ? rulesChip(v) : <Chip tone="bad">No cost</Chip>))}
        {!data.loading && !vendors.length && (
          <p className="px-3 text-xs text-muted-foreground">{q ? "No vendor matches." : "No vendors configured."}</p>
        )}

        {unknown.length > 0 && (
          <>
            {heading("Matches nothing")}
            {unknown.map((u) => row(u, <Chip tone="bad">Unknown</Chip>))}
          </>
        )}
      </nav>
    </>
  );
}

function Chip({ tone = "muted", children }: { tone?: "ok" | "warn" | "bad" | "muted"; children: ReactNode }) {
  return (
    <span className={cn(
      "rounded-full px-2 py-px text-2xs font-medium",
      tone === "ok" && "bg-primary-soft text-primary",
      tone === "warn" && "bg-warning-soft text-warning",
      tone === "bad" && "bg-destructive-soft text-destructive",
      tone === "muted" && "border border-border text-muted-foreground"
    )}>
      {children}
    </span>
  );
}

/**
 * Who to price: an account, a vendor, or everyone. Only names the panel knows are offered; the scope
 * used to be free text, and a typo there made pricing that loads and matches nothing.
 */
function AddPricingDialog({ known, onClose }: { known: KnownScopes; onClose: () => void }) {
  const router = useRouter();
  const [kind, setKind] = useState<"account" | "vendor" | "default">("account");
  const list = kind === "account" ? known.accounts : known.vendors;
  const [who, setWho] = useState("");
  const chosen = kind === "default" ? DEFAULT_SCOPE : who || list[0] || "";

  const options = [
    { id: "account" as const, title: "An account", hint: "What a customer pays us" },
    { id: "vendor" as const, title: "A vendor", hint: "What a carrier charges us" },
    { id: "default" as const, title: "Everyone", hint: "Every account without its own" },
  ];

  return (
    <Dialog open onClose={onClose} title="Add pricing">
      <div className="space-y-4">
        <div className="grid gap-2 sm:grid-cols-3">
          {options.map((o) => (
            <button key={o.id} type="button" aria-pressed={kind === o.id}
              onClick={() => { setKind(o.id); setWho(""); }}
              className={cn(
                "rounded-lg border p-3 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                kind === o.id ? "border-primary bg-primary-soft/50 ring-1 ring-primary" : "border-border hover:border-muted-foreground/40"
              )}>
              <span className="block font-semibold">{o.title}</span>
              <span className="block text-sm text-muted-foreground">{o.hint}</span>
            </button>
          ))}
        </div>
        {kind !== "default" && (
          list.length ? (
            <label className="block space-y-1.5 text-sm font-medium">
              {kind === "account" ? "Account" : "Vendor"}
              <Select value={chosen} onChange={(e) => setWho(e.target.value)}>
                {list.map((x) => <option key={x} value={x}>{x}</option>)}
              </Select>
            </label>
          ) : (
            <p className="text-sm text-muted-foreground">
              {kind === "account" ? "No accounts yet. Add one on the Accounts page first." : "No vendors yet. Add one on the Vendors page first."}
            </p>
          )
        )}
        <div className="flex flex-wrap justify-end gap-2 border-t border-border pt-4">
          <Button type="button" variant="ghost" className="mr-auto" onClick={onClose}>Cancel</Button>
          <Button type="button" disabled={!chosen} onClick={() => { onClose(); router.push(scopeHref(chosen, { new: true })); }}>
            Continue
          </Button>
        </div>
      </div>
    </Dialog>
  );
}
