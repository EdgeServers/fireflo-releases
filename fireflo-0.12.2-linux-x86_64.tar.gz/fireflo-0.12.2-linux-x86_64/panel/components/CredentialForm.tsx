"use client";
import { useState } from "react";
import { Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CardSection } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { ErrorNote, WarningNote } from "@/components/FormNotices";
import { Confirm } from "@/components/Confirm";
import { AccountContextCard } from "@/components/AccountContextCard";
import { TlvPairsEditor } from "@/components/TlvPairsEditor";
import { useTlvDefinitions } from "@/components/useTlvDefinitions";
import { SecretInput } from "./SecretInput";
import {
  CREDENTIAL_TYPES,
  type Credential,
  type CredentialContext,
  type CredentialInput,
  type SessionLimits,
  NO_LIMITS,
  billingOf,
  hasLimits,
  limitsSummary,
  credentialWarnings,
  validateCredential,
} from "@/lib/credential-types";

/**
 * One login: how a customer connects, and what their traffic is billed to.
 *
 * <p>The billing line is the part worth having. `accountId` is optional, and what happens when it is
 * blank differs by protocol in a way nothing surfaces anywhere else — so the form computes the
 * answer as you type and says it in words.
 */
export function CredentialForm({
  initial,
  context,
  defaultAccountId,
  allowPricing = true,
  advanced = true,
  onSave,
  onCancel,
}: {
  initial: Credential | null;
  context: CredentialContext;
  /**
   * The billing account a new login is created under, taken from the page it was opened from.
   *
   * <p><strong>This is the only chance to set it.</strong> The Account field is a read-out, not an
   * input — see the comment beside it — so whatever arrives here is what the login bills to for the
   * rest of its life. `AccountDetailClient` is the only caller that creates, and it always passes
   * one; <strong>any new creation path must do the same</strong>, or it will mint a login whose
   * account can never be set from this panel.
   *
   * <p>Unused when `initial` is present: an existing login carries its own account.
   */
  defaultAccountId?: string;
  /**
   * Whether the rarely-touched sections -- addresses, allowed products, default TLVs -- are shown.
   *
   * <p>Off, each section that already holds values still shows (a hidden value that is in force is
   * worse than a long form), and the empty ones are one line saying where the switch is.
   */
  advanced?: boolean;
  /**
   * Whether this surface may set what the login's traffic is priced at.
   *
   * <p>False in the customer portal. `product` picks which rate rule matches, and
   * `allowedProducts` decides whether the caller may pick one per message — so both are the price,
   * and a reseller setting them would be a reseller setting its own child's price.
   *
   * <p>The writer pins both columns NULL regardless (`lib/mis-logins.ts`), so this prop is the form
   * telling the truth rather than the enforcement. Rendering a control the server ignores is how a
   * form comes to lie about what it saved.
   *
   * <p>Defaults to true, so every operator caller is unchanged and stays that way on purpose.
   */
  allowPricing?: boolean;
  onSave: (input: CredentialInput) => Promise<string | null>;
  onCancel: () => void;
}) {
  //resolved beside each TLV token. Degrades to [] on failure -- a definitions outage must not stop
  //someone editing a credential
  const { definitions: tlvDefinitions, suggested: tlvSuggested } = useTlvDefinitions();
  const isNew = initial == null;
  const [input, setInput] = useState<CredentialInput>(() => ({
    id: initial?.id ?? null,
    type: initial?.type ?? "SMPP",
    systemId: initial?.systemId ?? "",
    //an existing secret starts as "keep it" -- the value was never sent here to begin with
    password: initial?.password === "stored" ? { state: "kept" } : { state: "unset" },
    apiKey: initial?.apiKey === "stored" ? { state: "kept" } : { state: "unset" },
    accountId: initial?.accountId ?? defaultAccountId ?? "",
    product: initial?.product ?? "",
    allowedIps: initial?.allowedIps ?? [],
    allowedProducts: initial?.allowedProducts ?? [],
    defaultTlvs: initial?.defaultTlvs ?? [],
    //the operator's only: the portal sends none, and its writer would ignore them if it did
    limits: allowPricing ? { ...(initial?.limits ?? NO_LIMITS) } : undefined,
    enabled: initial?.enabled ?? true,
    productConfirmed: false,
    billingConfirmed: false,
  }));
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const set = (patch: Partial<CredentialInput>) => setInput((c) => ({ ...c, ...patch }));
  const warnings = credentialWarnings(input, context);
  const hasApiKey = input.apiKey.state !== "unset";
  const billing = billingOf(input.type, input.accountId, input.systemId, hasApiKey);
  const unknownProduct =
    !!input.product?.trim() && !context.products.includes(input.product.trim());
  //names on the allow list that no product row backs. Not a refusal -- the panel deliberately
  //accepts orphan product names elsewhere so an existing login is not blocked by its own history
  const unknownAllowed = input.allowedProducts
    .map((p) => p.trim())
    .filter((p) => p && !context.products.includes(p));
  const billingLeak = !input.accountId?.trim() && input.type === "HTTP" && hasApiKey;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const invalid = validateCredential(input, context);
    if (invalid) {
      setError(invalid);
      return;
    }
    setSaving(true);
    setError("");
    const failure = await onSave(input);
    setSaving(false);
    if (failure) {
      setError(failure);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      {/* no identity Card: whatever opens this form already names what is being edited -- the
          dialog in its title, the standalone page in its heading -- and a second copy of the same
          words inside a box that cannot separate itself from its container is the nesting this
          vocabulary exists to prevent */}
      <CardSection title="Connection" className="px-6">
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="type" className="mb-1.5 block">Connects by</Label>
              <Select id="type" value={input.type} onChange={(e) => set({ type: e.target.value })}>
                {CREDENTIAL_TYPES.map((t) => (
                  <option key={t} value={t}>{t === "SMPP" ? "SMPP bind" : "HTTP / REST"}</option>
                ))}
                {/* an existing row may hold something else entirely; the form has to be able to show
                    it rather than silently presenting it as SMPP */}
                {!(CREDENTIAL_TYPES as readonly string[]).includes(input.type) && (
                  <option value={input.type}>{input.type} (not valid)</option>
                )}
              </Select>
            </div>
            <div>
              {/* a label of its own, so the checkbox sits on the same baseline as the Select beside
                  it rather than floating up against that Select's label */}
              <Label className="mb-1.5 block">Status</Label>
              <label className="flex items-start gap-2 text-base">
                <input
                  type="checkbox"
                  checked={input.enabled}
                  onChange={(e) => set({ enabled: e.target.checked })}
                  className="mt-1 h-4 w-4 rounded border-input accent-primary"
                />
                <span>
                  Enabled
                  {/* unlike a product, where enabled is panel-side only */}
                  <span className="block text-xs text-muted-foreground">
                    Disabling stops this customer connecting, from the gateway&rsquo;s next
                    configuration poll — within thirty seconds.
                  </span>
                </span>
              </label>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="systemId" className="mb-1.5 block">System ID</Label>
              <Input
                id="systemId"
                value={input.systemId ?? ""}
                onChange={(e) => set({ systemId: e.target.value })}
                placeholder="acme-smpp"
              />
              <p className="mt-1 text-xs text-muted-foreground">
                {input.type === "SMPP"
                  ? "What the client binds with, and what the gateway looks it up by."
                  : "The HTTP Basic username, unless an API key is set."}
              </p>
            </div>
            <SecretInput
              id="password"
              label="Password"
              stored={initial?.password ?? "unset"}
              value={input.password}
              onChange={(password) => set({ password })}
              hint="Compared byte for byte, and never trimmed."
            />
          </div>

          {/* its own row rather than paired with anything: it appears and disappears with the type,
              and pairing it would reshuffle the fields above every time that changed */}
          {input.type === "HTTP" && (
            <div className="grid gap-4 sm:grid-cols-2">
              <SecretInput
                id="apiKey"
                label="API key"
                stored={initial?.apiKey ?? "unset"}
                value={input.apiKey}
                onChange={(apiKey) => set({ apiKey })}
                hint="Replaces the system ID as the Basic username, and becomes the lookup key."
              />
            </div>
          )}
        </div>
      </CardSection>

      <CardSection title="Billing and tariff" className="px-6">
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label className="mb-1.5 block">Account</Label>
              {/*
                Read-only, and not merely disabled: there is no input here at all. This is the
                billing key -- `app_rate_rule.scope`, `account_balance.account_id` and every call
                record are keyed on it -- so retyping it moves a customer's traffic onto somebody
                else's bill, silently and with no undo. A login is born with its account from the
                page it was created on and keeps it.

                The resolved value is shown rather than the stored one, so a login whose column is
                null but which bills to its system ID reads as billing somewhere, not as blank.
              */}
              <p className="flex h-9 flex-wrap items-center gap-2 text-base">
                {billing.account ? (
                  <>
                    <span className="font-mono">{billing.account}</span>
                    {billing.fallback === "systemId" && (
                      <span className="text-xs text-muted-foreground">· from the system ID</span>
                    )}
                  </>
                ) : (
                  <span className="text-muted-foreground">—</span>
                )}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                {billing.account
                  ? billing.fallback === "systemId"
                    ? "No account is set, so traffic bills to the system ID. Fixed once created."
                    : "Rate scopes and prepaid balances are both keyed on this. Fixed once created."
                  : billing.fallback === "apiKey"
                  ? <span className="text-destructive">
                      With no account this would bill to the API key itself.
                    </span>
                  : "Rate scopes and prepaid balances are both keyed on this."}
              </p>
            </div>
            {allowPricing && (
            <div>
              <Label htmlFor="product" className="mb-1.5 block">Product</Label>
              <Select
                id="product"
                value={input.product ?? ""}
                onChange={(e) => set({ product: e.target.value })}
              >
                <option value="">No product</option>
                {context.products.map((p) => (
                  <option key={p} value={p}>{p}</option>
                ))}
                {unknownProduct && <option value={input.product ?? ""}>{input.product} (unknown)</option>}
              </Select>
              <p className="mt-1 text-xs text-muted-foreground">
                {input.type === "SMPP"
                  ? "The default. A system_type on the bind overrides it per session."
                  : "Authoritative — HTTP callers have no bind to override it."}
              </p>
            </div>
            )}
          </div>

          {/* what the account actually has, rather than a paragraph about what it might not:
              the difference between "no balance" and "zero" decides whether prepaid credit blocks
              anything, and only a lookup can tell them apart */}
          {/* gated with the product field rather than shown alongside it: the card carries the
              recharge ledger and links into the operator's account pages, and on a surface without
              pricing its lookup route does not exist -- so it would fetch, 404, and render as a
              silent blank. The reseller reads a child's balance from the portal's own sidebar */}
          {allowPricing
            && <AccountContextCard account={billing.account} fallback={billing.fallback} flat />}

          {unknownProduct && (
            <Confirm
              checked={input.productConfirmed === true}
              onChange={(productConfirmed) => set({ productConfirmed })}
              title={`Use '${input.product}' anyway`}
              detail="It is in no catalogue and nothing else uses it. Products are matched exactly, so an unrecognised one loads fine, matches no product-specific rate rule, and the traffic bills at whatever any-product catch-all exists."
            />
          )}
          {billingLeak && (
            <Confirm
              checked={input.billingConfirmed === true}
              onChange={(billingConfirmed) => set({ billingConfirmed })}
              title="Bill to the API key"
              detail="With no account, billing falls back to the lookup key — which here is the API key. The secret would appear in every call record, in the revenue figures, and in every CSV export of them."
            />
          )}
        </div>
      </CardSection>

      {!advanced && (
        <div className="space-y-1 px-6 text-xs text-muted-foreground">
          <p>
            Session and TPS limits, addresses, allowed products and default TLVs are under{" "}
            <strong>Advanced</strong> on the page.
            {(input.allowedProducts.length || input.defaultTlvs.length)
              ? " Products and TLVs already set are shown below."
              : ""}
          </p>
          {/* what is in force, in one line, so a limit or an address list is never invisible just
              because the switch is off */}
          {input.type === "SMPP" && hasLimits(input.limits) && (
            <p className="text-foreground">Limits: {limitsSummary(input.limits!)}</p>
          )}
          {input.allowedIps.length > 0 && (
            <p className="text-foreground">
              Connects only from: <span className="font-mono">{input.allowedIps.join(", ")}</span>
            </p>
          )}
        </div>
      )}

      {advanced && input.type === "SMPP" && input.limits && (
        <CardSection title="Session and TPS limits" className="px-6">
          <LimitsEditor limits={input.limits} onChange={(limits) => set({ limits })} />
        </CardSection>
      )}

      {advanced && (
      <CardSection title="Where it may connect from" className="px-6">
        <div className="space-y-2">
          <ListEditor
            values={input.allowedIps}
            onChange={(allowedIps) => set({ allowedIps })}
            placeholder="203.0.113.10"
            addLabel="Add an address"
          />
          <p className="text-xs text-muted-foreground">
            Exact addresses only — the gateway compares the peer address as a string, so a range like
            <code className="mx-1">203.0.113.0/24</code> matches nothing. An empty list is{" "}
            <strong>allow-all</strong>, not deny-all.
          </p>
        </div>
      </CardSection>
      )}

      {/*HTTP only: an SMPP client picks its product with system_type on the bind, which this list
         has no bearing on. Showing it there would imply a control that does nothing*/}
      {allowPricing && input.type !== "SMPP" && (advanced || input.allowedProducts.length > 0) && (
        <CardSection title="Products it may name on a send" className="px-6">
          <div className="space-y-2">
            <ListEditor
              values={input.allowedProducts}
              onChange={(allowedProducts) => set({ allowedProducts })}
              placeholder="premium"
              addLabel="Allow another product"
            />
            <p className="text-xs leading-relaxed text-muted-foreground">
              A REST caller may send <code className="mx-0.5">product</code> to price a message on
              something other than this login&rsquo;s own. <strong>An empty list refuses the field
              outright</strong> — the opposite of the address list above, because the product picks
              the rate and a caller free to choose one is free to choose their own price.
              {input.product?.trim() && (
                <>
                  {" "}This login&rsquo;s own{" "}
                  <code className="mx-0.5">{input.product.trim()}</code> is always allowed and does
                  not need listing.
                </>
              )}
            </p>
            {unknownAllowed.length > 0 && (
              <p className="text-xs text-amber-600 dark:text-amber-500">
                {/*the same warning the product field itself gets, for the same reason: a name with
                   no catalogue row passes this list and is then refused as PRODUCT_NOT_SOLD*/}
                {unknownAllowed.join(", ")} {unknownAllowed.length === 1 ? "is" : "are"} not in the
                product catalogue. The allow list would let this login name{" "}
                {unknownAllowed.length === 1 ? "it" : "them"}, and the send would then be refused
                because the gateway sells no such product.
              </p>
            )}
          </div>
        </CardSection>
      )}

      {(advanced || input.defaultTlvs.length > 0) && (
      <CardSection title="Default TLVs" className="px-6">
        <TlvPairsEditor
          pairs={input.defaultTlvs}
          onChange={(defaultTlvs) => set({ defaultTlvs })}
          definitions={tlvDefinitions}
          suggested={tlvSuggested}
          addLabel="Add a default"
        />
      </CardSection>
      )}

      <WarningNote warnings={warnings} />
      <ErrorNote error={error} />

      <div className="flex items-center gap-3">
        <Button type="submit" disabled={saving}>
          {saving ? "Saving…" : isNew ? "Create login" : "Save changes"}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
      </div>
    </form>
  );
}

/**
 * This login's own limits. Empty is "none of its own": the listener's and account's settings decide.
 */
function LimitsEditor({ limits, onChange }: { limits: SessionLimits; onChange: (next: SessionLimits) => void }) {
  const field = (key: keyof SessionLimits, label: string, hint: string, step = "1") => (
    <div>
      <Label htmlFor={`limit-${key}`} className="mb-1.5 block">{label}</Label>
      <Input
        id={`limit-${key}`}
        type="number"
        inputMode={step === "1" ? "numeric" : "decimal"}
        min={step === "1" ? 1 : 0.01}
        step={step}
        value={limits[key] ?? ""}
        placeholder="account's"
        onChange={(e) => onChange({ ...limits, [key]: e.target.value === "" ? null : Number(e.target.value) })}
      />
      <p className="mt-1 text-xs text-muted-foreground">{hint}</p>
    </div>
  );
  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        {field("maxSessions", "Sessions", "In total, of any bind type, on one listener.")}
        {field("maxTps", "TPS", "Messages per second across all its sessions.", "0.01")}
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        {field("maxTx", "Transmitter (TX)", "bind_transmitter sessions.")}
        {field("maxRx", "Receiver (RX)", "bind_receiver sessions.")}
        {field("maxTrx", "Transceiver (TRX)", "bind_transceiver sessions.")}
      </div>
      <p className="text-xs leading-relaxed text-muted-foreground">
        Empty means no limit of its own. These only narrow: the account&rsquo;s connection limit and
        TPS still apply, so a login can be held below its account but never lifted above it. A bind
        past a session limit is refused as too many sessions; a message past the TPS is answered
        throttled. A changed TPS reaches a login&rsquo;s sessions from their next bind.
      </p>
    </div>
  );
}

/** The say-it-out-loud tick, the same idiom the pricing form uses for an unrecognised scope. */

function ListEditor({
  values,
  onChange,
  placeholder,
  addLabel,
}: {
  values: string[];
  onChange: (next: string[]) => void;
  placeholder: string;
  addLabel: string;
}) {
  return (
    <>
      {values.map((value, i) => (
        <div key={i} className="flex items-center gap-2">
          <Input
            value={value}
            onChange={(e) => onChange(values.map((v, n) => (n === i ? e.target.value : v)))}
            placeholder={placeholder}
            className="w-64 font-mono"
          />
          <Button type="button" variant="ghost" size="icon" className="h-8 w-8"
            aria-label="Remove" onClick={() => onChange(values.filter((_, n) => n !== i))}>
            <X className="h-3.5 w-3.5" />
          </Button>
        </div>
      ))}
      <Button type="button" variant="ghost" size="sm" className="gap-1.5"
        onClick={() => onChange([...values, ""])}>
        <Plus className="h-3.5 w-3.5" />
        {addLabel}
      </Button>
    </>
  );
}
