"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import { ArrowLeft, CheckCircle2, Loader2, Play, Plus, RotateCcw, TriangleAlert, X } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { HealthStrip } from "./CardBits";
import { useHealth } from "./useHealth";
import type { CodeError } from "./CodeEditor";
import { count } from "@/lib/format";
import { isAdminSession } from "@/lib/roles";
import { cn } from "@/lib/utils";
import {
  ON_ERROR,
  SENDABLE_FIELDS,
  emptyPreprocessor,
  joinOnError,
  runnerFor,
  splitOnError,
  validatePreprocessor,
  type Preprocessor,
  type PreprocessorInput,
} from "@/lib/preprocessor-types";
import { BASH_HELPER, BASH_HELPER_NAME, PYTHON_HELPER, PYTHON_HELPER_NAME, STARTERS, type Starter } from "@/lib/preprocessor-starters";

const CodeEditor = dynamic(() => import("./CodeEditor"), {
  ssr: false,
  loading: () => <div className="flex h-[420px] items-center justify-center text-sm text-muted-foreground">Loading the editor…</div>,
});

interface FileInfo {
  name: string;
  editable: boolean;
  sha: string | null;
  usedBy: string[];
}

interface Version {
  sha: string;
  size: number;
  savedAt: string;
  actor: string | null;
  restorable: boolean;
}

interface CheckResult {
  ok: boolean | null;
  checker: string;
  note?: string;
  errors: CodeError[];
}

interface TestResult {
  ready: boolean;
  readyMs: number | null;
  timedOut: boolean;
  exit: number | null;
  command: string;
  results: {
    index: number;
    action?: string;
    set?: Record<string, string>;
    tlvs?: Record<string, string | null>;
    target?: string;
    status?: string;
    detail?: string;
    ms?: number;
    error?: string;
  }[];
  stdout: string[];
  stderr: string;
}

type Sample = Record<string, string>;

/** Stable, so an unchecked editor is not reconfigured on every keystroke. */
const NO_ERRORS: CodeError[] = [];

function languageOf(file: string): "python" | "java" | "bash" | "text" | "other" {
  const f = file.toLowerCase();
  return f.endsWith(".py") ? "python" : f.endsWith(".java") ? "java" : f.endsWith(".sh") ? "bash" : f.endsWith(".txt") ? "text" : "other";
}

/** Lines that differ, counted both ways -- enough to say how big a save is, not a diff. */
function changedLines(before: string, after: string): number {
  const a = before.split("\n");
  const b = after.split("\n");
  const left = new Map<string, number>();
  for (const l of a) left.set(l, (left.get(l) ?? 0) + 1);
  let common = 0;
  for (const l of b) {
    const n = left.get(l) ?? 0;
    if (n > 0) {
      common++;
      left.set(l, n - 1);
    }
  }
  return a.length - common + (b.length - common);
}

async function call<T>(url: string, init?: RequestInit): Promise<{ data?: T; error?: string; status: number }> {
  try {
    const res = await fetch(url, { cache: "no-store", ...init, headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) } });
    const body = await res.json().catch(() => null);
    return res.ok ? { data: body?.data as T, status: res.status } : { error: body?.error ?? `Request failed (${res.status})`, status: res.status };
  } catch {
    return { error: "Could not reach the panel's API.", status: 0 };
  }
}

/**
 * The preprocessor workbench: code on the left, settings, test, history and usage in a rail.
 *
 * <p>One page for adding and editing, because they are the same work -- a new preprocessor is an
 * existing one that has not been saved yet. Nothing here touches traffic until **Save and run**:
 * Check parses the draft with the gateway host's own interpreter, and Test runs the draft in a
 * throwaway copy of the directory against the samples on the right.
 *
 * <p>Saving writes the file through the gateway, which keeps the version it replaced, and then the
 * settings row. The gateway notices the new file within five seconds and swaps the running copies,
 * letting the old ones finish what they hold.
 */
export function PreprocessorWorkbench({ name }: { name: string | null }) {
  const router = useRouter();
  const { data: session } = useSession();
  const admin = isAdminSession(session);
  const { health } = useHealth();
  const isNew = name === null;

  const [def, setDef] = useState<PreprocessorInput>(emptyPreprocessor());
  const [usedBy, setUsedBy] = useState<Preprocessor["usedBy"]>([]);
  const [files, setFiles] = useState<FileInfo[] | null>(null);
  const [editable, setEditable] = useState(true);
  const [enabled, setEnabled] = useState(true);
  const [starter, setStarter] = useState<Starter | null>(null);
  const [content, setContent] = useState("");
  const [saved, setSaved] = useState<{ content: string; sha: string | null }>({ content: "", sha: null });
  const [versions, setVersions] = useState<Version[]>([]);
  const [loadError, setLoadError] = useState("");
  const [check, setCheck] = useState<CheckResult | null>(null);
  const [checking, setChecking] = useState(false);
  const [samples, setSamples] = useState<Sample[]>([{ to: "+61400000001", from: "acme" }, { to: "+919811111111", from: "Other" }]);
  const [test, setTest] = useState<TestResult | null>(null);
  const [testError, setTestError] = useState("");
  const [testing, setTesting] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState("");
  const [notice, setNotice] = useState("");

  const file = def.run.trim();
  const language = languageOf(file);
  const dirty = content !== saved.content;
  const settingsInvalid = validatePreprocessor({ ...def });
  const readOnly = !admin || !editable || !enabled;
  const live = (health?.preprocessors ?? []).find((p) => p.name === (name ?? def.name));
  const draftKey = file ? `fireflo.pp-draft:${file}` : "";

  const loadFile = useCallback(async (run: string) => {
    const res = await call<{ content: string; sha: string; versions: Version[]; editable: boolean }>(
      `/api/control/preprocessors/files/${encodeURIComponent(run)}`);
    if (res.status === 404) {
      setSaved({ content: "", sha: null });
      setContent("");
      setVersions([]);
      setLoadError(`'${run}' is not in the gateway's preprocessor directory yet. Write it here and save to create it.`);
      return;
    }
    if (!res.data) {
      setLoadError(res.error ?? "Could not read the file.");
      return;
    }
    setLoadError("");
    setSaved({ content: res.data.content, sha: res.data.sha });
    setVersions(res.data.versions ?? []);
    setEditable(res.data.editable);
    let draft: string | null = null;
    try {
      draft = window.localStorage.getItem(`fireflo.pp-draft:${run}`);
    } catch {
      draft = null;
    }
    setContent(draft ?? res.data.content);
    if (draft && draft !== res.data.content) setNotice("Restored your unsaved edit from this browser.");
  }, []);

  //the definition, the directory listing, then the file the definition runs
  useEffect(() => {
    let alive = true;
    void (async () => {
      const list = await call<{ files: FileInfo[]; editable: boolean; enabled?: boolean }>("/api/control/preprocessors/files");
      if (!alive) return;
      if (list.data) {
        setFiles(list.data.files);
        setEditable(list.data.editable);
        setEnabled(list.data.enabled !== false);
      } else {
        setLoadError(list.error ?? "Could not list the preprocessor directory.");
      }
      if (isNew) return;
      const defs = await call<{ preprocessors: Preprocessor[] }>("/api/control/preprocessors");
      const found = defs.data?.preprocessors.find((p) => p.name === name);
      if (!alive) return;
      if (!found) {
        setLoadError(defs.error ?? `No preprocessor called '${name}'.`);
        return;
      }
      setDef({ ...found });
      setUsedBy(found.usedBy);
      await loadFile(found.run);
    })();
    return () => {
      alive = false;
    };
  }, [isNew, name, loadFile]);

  //unsaved edits survive a reload, per file, in this browser only
  useEffect(() => {
    if (!draftKey) return;
    try {
      if (dirty) window.localStorage.setItem(draftKey, content);
      else window.localStorage.removeItem(draftKey);
    } catch {
      //storage refused; the edit is still on screen
    }
  }, [draftKey, content, dirty]);

  function pickStarter(s: Starter) {
    setStarter(s);
    setContent(s.content);
    setSaved({ content: "", sha: null });
    setCheck(null);
    setTest(null);
    setDef((d) => ({ ...d, run: d.run && d.run !== starter?.file ? d.run : s.file, name: d.name || s.file.replace(/\.(py|java|sh)$/i, "").toLowerCase() }));
  }

  function edit(next: string) {
    setContent(next);
    //a check answers for the text it checked; any edit makes it stale
    if (check) setCheck(null);
  }

  async function runCheck(): Promise<CheckResult | null> {
    setChecking(true);
    const res = await call<CheckResult>("/api/control/preprocessors/check", {
      method: "POST",
      body: JSON.stringify({ name: file, content }),
    });
    setChecking(false);
    if (!res.data) {
      setCheck({ ok: false, checker: "", errors: [{ line: 1, message: res.error ?? "The check could not run." }] });
      return null;
    }
    setCheck(res.data);
    return res.data;
  }

  async function runTest() {
    setTesting(true);
    setTestError("");
    const res = await call<TestResult>("/api/control/preprocessors/test", {
      method: "POST",
      body: JSON.stringify({ name: file, content, fields: def.fields, messages: samples }),
    });
    setTesting(false);
    if (!res.data) {
      setTest(null);
      setTestError(res.error ?? "The test could not run.");
      return;
    }
    setTest(res.data);
  }

  async function saveAll() {
    setSaving(true);
    setSaveError("");
    //the helper a Python or bash starter uses, when the directory does not have it yet
    const helper = language === "python" ? { name: PYTHON_HELPER_NAME, content: PYTHON_HELPER, lang: "Python" }
      : language === "bash" ? { name: BASH_HELPER_NAME, content: BASH_HELPER, lang: "bash" } : null;
    if (isNew && helper && files && !files.some((f) => f.name === helper.name) && content.includes("fireflo_preprocessor")) {
      const written = await call(`/api/control/preprocessors/files/${helper.name}`, {
        method: "PUT", body: JSON.stringify({ content: helper.content, expectedSha: "" }),
      });
      if (written.error) {
        setSaving(false);
        setSaveError(`The ${helper.lang} helper could not be written: ${written.error}`);
        return;
      }
    }
    for (const data of starter?.data ?? []) {
      if (files && !files.some((f) => f.name === data.name)) {
        await call(`/api/control/preprocessors/files/${encodeURIComponent(data.name)}`, {
          method: "PUT", body: JSON.stringify({ content: data.content, expectedSha: "" }),
        });
      }
    }
    if (dirty || isNew) {
      const res = await call<{ sha: string; versions: Version[] }>(`/api/control/preprocessors/files/${encodeURIComponent(file)}`, {
        method: "PUT", body: JSON.stringify({ content, expectedSha: saved.sha ?? "" }),
      });
      if (!res.data) {
        setSaving(false);
        setSaveError(res.error ?? "The file could not be saved.");
        return;
      }
      setSaved({ content, sha: res.data.sha });
      setVersions(res.data.versions ?? []);
    }
    const settings = await call("/api/control/preprocessors", { method: "PUT", body: JSON.stringify(def) });
    setSaving(false);
    if (settings.error) {
      setSaveError(`The code is saved, but the settings were not: ${settings.error}`);
      return;
    }
    setConfirming(false);
    setNotice("Saved. The gateway picks the new version up within about five seconds; running copies finish what they hold first.");
    if (isNew) router.replace(`/cp/preprocessors/${encodeURIComponent(def.name.trim())}`);
  }

  async function restore(v: Version) {
    const res = await call<{ sha: string }>(`/api/control/preprocessors/files/${encodeURIComponent(file)}/rollback`, {
      method: "POST", body: JSON.stringify({ sha: v.sha }),
    });
    if (res.error) {
      setSaveError(res.error);
      return;
    }
    try {
      window.localStorage.removeItem(draftKey);
    } catch {
      //nothing stored
    }
    await loadFile(file);
    setNotice(`Restored the version from ${new Date(v.savedAt).toLocaleString()}. Live within about five seconds.`);
  }

  const canSave = !readOnly && !settingsInvalid && !!content.trim() && check?.ok !== false && !checking;
  const status = isNew ? { tone: "outline" as const, label: "Not saved yet" }
    : !live ? { tone: "warning" as const, label: def.enabled ? "Not loaded yet" : "Switched off" }
    : live.state === "off" ? { tone: "outline" as const, label: "Off on this gateway" }
    : live.state === "unavailable" ? { tone: "destructive" as const, label: "Cannot run" }
    : live.ready === 0 ? { tone: "warning" as const, label: "Starting" }
    : { tone: "success" as const, label: `Running ${live.ready}/${live.workers}` };

  return (
    <div className="space-y-4">
      <div>
        <Link href="/cp/preprocessors" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Preprocessors
        </Link>
        <div className="mt-1 flex flex-wrap items-center gap-2">
          <h1 className="text-xl font-semibold">{isNew ? "New preprocessor" : <span className="font-mono">@{name}</span>}</h1>
          <Badge variant={status.tone}>{status.label}</Badge>
          {dirty && <span className="text-xs text-warning">● unsaved changes</span>}
          <div className="ml-auto flex flex-wrap gap-2">
            <Button variant="outline" disabled={readOnly || !content.trim() || checking || !file} onClick={runCheck}>
              {checking ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />} Check
            </Button>
            <Button disabled={!canSave} onClick={async () => {
              //never save code that has not been checked against the host's own interpreter
              const result = check ?? await runCheck();
              if (result && result.ok !== false) setConfirming(true);
            }}>
              {isNew ? "Create and run" : "Save and run"}
            </Button>
          </div>
        </div>
      </div>

      {readOnly && (
        <HealthStrip>
          {!enabled
            ? <>Preprocessors are switched off on this gateway, so code cannot be checked, tested or saved. Turn on <em>Run preprocessors</em> under <Link href="/cp/gateway" className="font-medium text-primary hover:underline">Gateway settings</Link>.</>
            : !editable
            ? <>Code editing is switched off on this gateway (<code className="font-mono">smsg.preprocessor.editable=false</code>). You can read the code and its history; change it on the gateway host.</>
            : "Only an admin can change or run preprocessor code. You can read it and its history."}
        </HealthStrip>
      )}
      {loadError && <HealthStrip>{loadError}</HealthStrip>}
      {notice && <HealthStrip>{notice}</HealthStrip>}
      {check?.ok === false && (
        <HealthStrip tone="destructive">
          {check.errors.length} problem{check.errors.length === 1 ? "" : "s"} in <span className="font-mono">{file}</span>. Saving stays off
          until it parses; the running copies keep the last saved version.
        </HealthStrip>
      )}
      {live?.state === "unavailable" && live.problem && <HealthStrip tone="destructive">{live.problem}</HealthStrip>}

      <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_360px]">
        <Card className="min-w-0 overflow-hidden">
          {isNew && !starter ? (
            <>
              <CardHeader className="border-b border-border">
                <span className="font-medium">Start from</span>
                <span className="text-sm text-muted-foreground">A starting file you then edit. Nothing runs until you save.</span>
              </CardHeader>
              <CardContent className="grid gap-3 pt-4 sm:grid-cols-2">
                {STARTERS.map((s) => (
                  <button key={s.id} type="button" onClick={() => pickStarter(s)} disabled={readOnly}
                    className="rounded-lg border border-border p-3 text-left hover:bg-accent disabled:opacity-50">
                    <span className="block font-semibold">{s.title}</span>
                    <span className="block font-mono text-2xs text-muted-foreground">{s.language} · {s.file}</span>
                    <span className="mt-1 block text-sm text-muted-foreground">{s.description}</span>
                  </button>
                ))}
              </CardContent>
            </>
          ) : (
            <>
              <div className="flex flex-wrap items-center gap-2 border-b border-border px-4 py-2">
                <span className="rounded bg-muted px-2 py-0.5 font-mono text-sm">{file || "untitled"}</span>
                <span className="font-mono text-2xs text-muted-foreground">{runnerFor(file)}</span>
                {readOnly && <Badge variant="outline">read-only</Badge>}
                {files && (
                  <span className="ml-auto truncate text-2xs text-muted-foreground">
                    beside it: {files.filter((f) => f.name !== file).map((f) => f.name).join(" · ") || "nothing"}
                  </span>
                )}
              </div>
              <CodeEditor value={content} onChange={edit} language={language} readOnly={readOnly}
                errors={check?.errors ?? NO_ERRORS} />
              <div className="flex flex-wrap items-center gap-2 border-t border-border px-4 py-2 text-xs text-muted-foreground">
                {check === null ? (
                  <span>Not checked since the last edit.</span>
                ) : check.ok === true ? (
                  <span className="text-success">✓ Syntax OK · {check.checker}</span>
                ) : check.ok === null ? (
                  <span>{check.note}</span>
                ) : (
                  <span className="text-destructive">
                    ✕ {check.errors.map((e) => `line ${e.line}${e.column ? `, column ${e.column}` : ""}: ${e.message}`).join(" · ")}
                  </span>
                )}
                {saved.sha && <span className="ml-auto font-mono">saved {saved.sha.slice(0, 7)}</span>}
              </div>
            </>
          )}
        </Card>

        <aside className="space-y-4 xl:sticky xl:top-4">
          <SettingsCard def={def} setDef={setDef} isNew={isNew} readOnly={readOnly} />
          <TestCard
            fields={def.fields}
            samples={samples}
            setSamples={setSamples}
            result={test}
            error={testError}
            running={testing}
            disabled={readOnly || !content.trim() || !file || check?.ok === false || language === "text"}
            onRun={runTest}
          />
          {!isNew && <HistoryCard versions={versions} currentSha={saved.sha} readOnly={readOnly} onRestore={restore} />}
          {!isNew && (
            <Card>
              <CardHeader className="border-b border-border"><span className="font-medium">Sent to by</span></CardHeader>
              <CardContent className="pt-3 text-sm">
                {usedBy.length === 0 ? (
                  <p className="text-muted-foreground">No routing rule yet. Add one with target <span className="font-mono">@{name}</span>.</p>
                ) : (
                  <div className="flex flex-wrap gap-1.5">
                    {usedBy.map((u) => (
                      <Link key={`${u.table}-${u.seq}`} href={`/cp/routing/tables/${encodeURIComponent(u.table)}`}
                        className={cn("rounded border border-border px-1.5 py-0.5 font-mono text-xs hover:bg-accent", !u.enabled && "opacity-60")}>
                        {u.table} #{u.seq}{!u.enabled && " (off)"}
                      </Link>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </aside>
      </div>

      {confirming && (
        <Dialog open onClose={() => setConfirming(false)} title={`${isNew ? "Create" : "Save"} and run ${file}?`}
          description="The gateway starts the new version and lets the running copies finish what they hold, so no message is dropped for the switch.">
          <ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">
            {(dirty || isNew) && <li>{count(changedLines(saved.content, content))} line{changedLines(saved.content, content) === 1 ? "" : "s"} changed{saved.sha ? ` (from ${saved.sha.slice(0, 7)})` : " — a new file"}</li>}
            <li>Live within about five seconds{usedBy.length ? <>, for <b>{usedBy.map((u) => `${u.table} #${u.seq}`).join(", ")}</b></> : " — no routing rule sends to it yet"}</li>
            {saved.sha && <li>The current version is kept in History</li>}
            <li>Recorded in the access log as you</li>
          </ul>
          {saveError && <p className="mt-3 text-sm text-destructive">{saveError}</p>}
          <div className="mt-4 flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setConfirming(false)}>Cancel</Button>
            <Button disabled={saving} onClick={saveAll}>{saving ? "Saving…" : isNew ? "Create and run" : "Save and run"}</Button>
          </div>
        </Dialog>
      )}
      {!confirming && saveError && <HealthStrip tone="destructive">{saveError}</HealthStrip>}
    </div>
  );
}

function SettingsCard({ def, setDef, isNew, readOnly }: {
  def: PreprocessorInput;
  setDef: (fn: (d: PreprocessorInput) => PreprocessorInput) => void;
  isNew: boolean;
  readOnly: boolean;
}) {
  const split = useMemo(() => splitOnError(def.onError), [def.onError]);
  const invalid = validatePreprocessor(def);
  const set = (patch: Partial<PreprocessorInput>) => setDef((d) => ({ ...d, ...patch }));
  return (
    <Card>
      <CardHeader className="border-b border-border"><span className="font-medium">Settings</span></CardHeader>
      <CardContent className="space-y-3 pt-3 text-sm">
        <div className="grid grid-cols-2 gap-3">
          <label className="space-y-1">
            <span className="text-xs text-muted-foreground">Name</span>
            <Input value={def.name} readOnly={!isNew} disabled={readOnly} className="font-mono" placeholder="sender"
              onChange={(e) => set({ name: e.target.value })} />
          </label>
          <label className="space-y-1">
            <span className="text-xs text-muted-foreground">File</span>
            <Input value={def.run} readOnly={!isNew} disabled={readOnly} className="font-mono" placeholder="sender.py"
              onChange={(e) => set({ run: e.target.value })} />
          </label>
          <label className="space-y-1">
            <span className="text-xs text-muted-foreground">Copies</span>
            <Input type="number" min={1} max={64} value={def.workers} disabled={readOnly} onChange={(e) => set({ workers: Number(e.target.value) })} />
          </label>
          <label className="space-y-1">
            <span className="text-xs text-muted-foreground">Time limit (ms)</span>
            <Input type="number" min={1} max={60000} value={def.timeoutMs} disabled={readOnly} onChange={(e) => set({ timeoutMs: Number(e.target.value) })} />
          </label>
          <label className="space-y-1">
            <span className="text-xs text-muted-foreground">Waiting, at most</span>
            <Input type="number" min={1} max={100000} value={def.inflight} disabled={readOnly} onChange={(e) => set({ inflight: Number(e.target.value) })} />
          </label>
          <label className="space-y-1">
            <span className="text-xs text-muted-foreground">If no answer</span>
            <Select value={split.kind} disabled={readOnly}
              onChange={(e) => set({ onError: joinOnError(e.target.value as typeof split.kind, split.status) })}>
              {ON_ERROR.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
            </Select>
          </label>
        </div>
        {split.kind === "reject" && (
          <Input placeholder="refusal status, e.g. DND" value={split.status} disabled={readOnly}
            onChange={(e) => set({ onError: joinOnError("reject", e.target.value) })} />
        )}
        <div>
          <span className="text-xs text-muted-foreground">Fields sent</span>
          <div className="mt-1 flex flex-wrap gap-1.5">
            {SENDABLE_FIELDS.map((f) => {
              const on = def.fields.includes(f.id);
              return (
                <button key={f.id} type="button" aria-pressed={on} disabled={readOnly} title={f.hint}
                  onClick={() => set({ fields: on ? def.fields.filter((x) => x !== f.id) : [...def.fields, f.id] })}
                  className={cn("rounded-md border px-2 py-0.5 text-xs disabled:opacity-60",
                    on ? "border-primary bg-primary-soft text-primary" : "border-border text-muted-foreground hover:bg-accent",
                    f.id === "body" && on && "border-warning bg-warning-soft text-warning")}>
                  {f.id}
                </button>
              );
            })}
          </div>
          <p className="mt-1 text-2xs text-muted-foreground">The message text is sent only when “body” is on.</p>
        </div>
        <label className="flex items-center gap-2">
          <Switch checked={def.enabled} disabled={readOnly} onChange={(on) => set({ enabled: on })} />
          <span>Enabled — when off, rules sending to it are skipped</span>
        </label>
        {invalid && <p className="text-xs text-muted-foreground">{invalid}</p>}
      </CardContent>
    </Card>
  );
}

function TestCard({ fields, samples, setSamples, result, error, running, disabled, onRun }: {
  fields: string[];
  samples: Sample[];
  setSamples: (s: Sample[]) => void;
  result: TestResult | null;
  error: string;
  running: boolean;
  disabled: boolean;
  onRun: () => void;
}) {
  const cols = fields.length ? fields : ["to", "from"];
  return (
    <Card>
      <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
        <span className="font-medium">Test</span>
        <span className="text-xs text-muted-foreground">runs the draft, not the live copy</span>
        <Button size="sm" className="ml-auto gap-1" disabled={disabled || running || samples.length === 0} onClick={onRun}>
          {running ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />} Run test
        </Button>
      </CardHeader>
      <CardContent className="space-y-3 pt-3 text-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-left text-muted-foreground">
                {cols.map((c) => <th key={c} className="pb-1 pr-1 font-medium">{c}</th>)}
                <th />
              </tr>
            </thead>
            <tbody>
              {samples.map((s, i) => (
                <tr key={i} className="border-t border-border">
                  {cols.map((c) => (
                    <td key={c} className="py-0.5 pr-1">
                      <input aria-label={`Sample ${i + 1} ${c}`} value={s[c] ?? ""}
                        className="w-full min-w-0 rounded border border-transparent bg-transparent px-1 py-0.5 font-mono hover:border-border focus:border-primary focus:outline-none"
                        onChange={(e) => setSamples(samples.map((x, j) => (j === i ? { ...x, [c]: e.target.value } : x)))} />
                    </td>
                  ))}
                  <td>
                    <button type="button" aria-label={`Remove sample ${i + 1}`} className="p-1 text-muted-foreground hover:text-foreground"
                      onClick={() => setSamples(samples.filter((_, j) => j !== i))}>
                      <X className="h-3 w-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Button variant="outline" size="sm" className="gap-1" disabled={samples.length >= 20}
          onClick={() => setSamples([...samples, Object.fromEntries(cols.map((c) => [c, ""]))])}>
          <Plus className="h-3.5 w-3.5" /> Sample
        </Button>

        {error && <p className="text-xs text-destructive">{error}</p>}
        {result && (
          <div className="space-y-1.5 border-t border-dashed border-border pt-2">
            {!result.ready ? (
              <p className="flex items-start gap-1.5 text-xs text-destructive">
                <TriangleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                It never printed {"{\"ready\":true}"}
                {result.exit != null ? `, and exited with ${result.exit}` : result.timedOut ? " within 10 seconds" : ""}. Its stderr is below.
              </p>
            ) : (
              result.results.map((r) => (
                <div key={r.index} className="grid grid-cols-[1.5rem_minmax(0,1fr)_auto] items-baseline gap-1.5 text-xs">
                  <span className="text-muted-foreground">#{r.index}</span>
                  <span className="min-w-0 truncate">
                    {r.error ? <span className="text-destructive">{r.error}</span> : (
                      <>
                        <Badge variant={r.action === "reject" || r.action === "drop" ? "destructive" : r.action === "continue" ? "outline" : "default"}>{r.action}</Badge>{" "}
                        {r.set && Object.keys(r.set).length > 0 && Object.entries(r.set).map(([k, v]) => `${k} → ${v}`).join(", ")}
                        {r.tlvs && Object.keys(r.tlvs).length > 0 && (
                          <span className="font-mono"> {Object.entries(r.tlvs).map(([k, v]) => (v == null ? `TLV ${k} removed` : `TLV ${k} = ${v}`)).join(", ")}</span>
                        )}
                        {r.target && `→ ${r.target}`}
                        {r.status && ` ${r.status}`}
                        {r.detail && <span className="text-muted-foreground"> · {r.detail}</span>}
                      </>
                    )}
                  </span>
                  {r.ms != null && <span className="tabular-nums text-muted-foreground">{r.ms} ms</span>}
                </div>
              ))
            )}
            <details className="text-xs">
              <summary className="cursor-pointer text-muted-foreground">
                stderr{result.readyMs != null ? ` · started in ${result.readyMs} ms` : ""} · {result.stderr ? result.stderr.split("\n").filter(Boolean).length : 0} lines
              </summary>
              <pre className="mt-1 max-h-48 overflow-auto whitespace-pre-wrap rounded bg-muted p-2 text-2xs">
                {[result.stderr, ...result.stdout.map((l) => `stdout: ${l}`)].filter(Boolean).join("\n") || "(nothing written to stderr)"}
              </pre>
            </details>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function HistoryCard({ versions, currentSha, readOnly, onRestore }: {
  versions: Version[];
  currentSha: string | null;
  readOnly: boolean;
  onRestore: (v: Version) => void;
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center gap-2 space-y-0 border-b border-border">
        <span className="font-medium">History</span>
        <span className="ml-auto text-xs text-muted-foreground">last 20 kept</span>
      </CardHeader>
      <CardContent className="pt-1 text-xs">
        {versions.length === 0 ? (
          <p className="py-2 text-muted-foreground">No saves from the panel yet. The first save keeps whatever is on disk now.</p>
        ) : versions.map((v, i) => (
          <div key={`${v.sha}-${i}`} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2 border-t border-border py-1.5 first:border-t-0">
            <span className="min-w-0 truncate">
              <span className="tabular-nums">{new Date(v.savedAt).toLocaleString()}</span>
              {" · "}<span className="text-muted-foreground">{v.actor ?? "on disk before"}</span>
              {" · "}<span className="font-mono text-muted-foreground">{v.sha.slice(0, 7)}</span>
            </span>
            {v.sha === currentSha ? <Badge variant="success">running</Badge> : (
              <Button variant="outline" size="sm" className="h-7 gap-1 px-2" disabled={readOnly || !v.restorable} onClick={() => onRestore(v)}>
                <RotateCcw className="h-3 w-3" /> Restore
              </Button>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
