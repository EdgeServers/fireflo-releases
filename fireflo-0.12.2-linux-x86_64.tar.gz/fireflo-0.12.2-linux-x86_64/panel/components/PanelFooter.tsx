import { APP_VERSION } from "./FireFloMark";

/**
 * The copyright line and the running panel version, at the foot of every operator page.
 *
 * <h2>The operator side only</h2>
 *
 * <p>This is deliberately not rendered in the customer portal. That surface can be white-labelled —
 * see {@code lib/brand.ts}, which exists so a tenant's customers are never shown the platform
 * underneath — and a footer reading "FireFlo by RemotIQ" would undo it on every page. Asserting
 * the *tenant's* copyright there instead would be worse: whose notice that is, and what it says, is
 * not ours to invent.
 *
 * <h2>Inside the scrolling region, not under it</h2>
 *
 * <p>{@code DashboardShell} is a full-height flex container with `overflow-hidden`, and only its
 * `<main>` scrolls. A footer placed after the shell would sit below the viewport with nothing able
 * to scroll to it — present in the markup and unreachable, which is the worst of both.
 *
 * <p>The version repeats what the header wordmark already shows. That is on purpose: this is the
 * end of a long scrolling page, and "which version am I looking at" is asked with a screenshot in
 * hand, where the header has usually been cropped away.
 */
export function PanelFooter() {
  return (
    <footer className="flex flex-wrap items-center justify-between gap-2 border-t border-border pt-4 text-xs text-muted-foreground">
      <span>© {COPYRIGHT_YEAR} FireFlo by RemotIQ. All rights reserved.</span>
      {APP_VERSION && <span className="font-mono tabular-nums">v{APP_VERSION}</span>}
    </footer>
  );
}

/**
 * Fixed, not `new Date().getFullYear()`.
 *
 * <p>A computed year rolls over at midnight on the first of January, in whichever timezone the
 * server happens to run, without anybody deciding it should. A copyright year is a claim about when
 * the work was published, so a person moves it.
 */
const COPYRIGHT_YEAR = 2026;
