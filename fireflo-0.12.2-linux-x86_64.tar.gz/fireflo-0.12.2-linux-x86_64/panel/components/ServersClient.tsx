"use client";
import { useState } from "react";
import Link from "next/link";
import { Package, Plus, RefreshCw } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button, buttonClasses } from "@/components/ui/button";
import { PageHeader } from "@/components/ui/page-header";
import { HealthStrip } from "./CardBits";
import { ProductReadiness } from "./ProductReadiness";
import { ServerCard } from "./ServerCard";
import { WorkerForm } from "./WorkerForm";
import { TrafficControlLegend } from "./WorkerCard";
import { WorkerSummary } from "./WorkerSummary";
import { useWorkers } from "./useWorkers";
import { useHealth } from "./useHealth";
import { LiveTrafficChart } from "./LiveTrafficChart";
import { useRuntimeMetrics } from "./useRuntimeMetrics";
import { readsWorkersFromDatabase } from "@/lib/health-types";
import { SEVERITY, verdictFor } from "@/lib/worker-verdict";
import { KIND, trafficKey, type Worker } from "@/lib/worker-types";
import { EmptyState } from "@/components/ui/empty-state";

/**
 * Servers: the listeners customers bind in to.
 *
 * <p>No traffic section, unlike vendors. Inbound volume is a question about a customer rather than
 * about the listener, and the Accounts page already answers it — a per-server total would only tell
 * you which port something arrived on.
 *
 * <p>This configures the listener. Which customers may bind to it is a different table
 * (`app_credential`) and is not editable here.
 */
/** The counter's reason tags, said in words an operator can act on. */
const REFUSAL_WORDS: Record<string, string> = {
  "ip-limit": "over the per-IP connection limit",
  "account-limit": "over the account's connection limit",
  credentials: "bad credentials",
  product: "product missing or unknown",
};

export function ServersClient() {
  const [editing, setEditing] = useState<Worker | "new" | null>(null);
  const {
    workers, error, errorFor, notice, loading, busy,
    load, setEnabled, applyNow,
  } = useWorkers(KIND.server);
  const { health, error: healthError, byFullName, queueHistory } = useHealth();
  const { snapshot } = useRuntimeMetrics();
  const fromDatabase = readsWorkersFromDatabase(health);
  //why binds were refused since restart (gateway I3). Empty means no counter OR no refusals; the
  //card only renders when a reason has actually counted, so an older gateway shows nothing new
  const bindRefusals = Object.entries(snapshot?.bindRefusals ?? {});

  const sorted = [...workers].sort((a, b) => severity(a) - severity(b) || a.name.localeCompare(b.name));

  function severity(worker: Worker): number {
    return SEVERITY[verdictFor(worker, byFullName, KIND.server).tone];
  }

  if (editing) {
    return (
      <WorkerForm
        type={KIND.server}
        worker={editing === "new" ? null : editing}
        onCancel={() => setEditing(null)}
        onSaved={async () => {
          setEditing(null);
          await load();
        }}
      />
    );
  }

  return (
    <>
      <PageHeader
        title="Servers"
        description="Listeners customers bind to, with how many are connected right now. Who is allowed to bind is set by credentials, not here."
        actions={
          <>
            {/* products belong next to the listeners: a product is what a customer's bind asks for by
                system_type, so it is chosen at the moment of binding to one of these */}
            <Link href="/cp/products" className={buttonClasses({ variant: "outline" })}>
              <Package className="h-4 w-4" />
              Products
            </Link>
            <Button variant="outline" onClick={applyNow} disabled={busy === "__reload"}>
              <RefreshCw className="mr-1.5 h-4 w-4" />
              {busy === "__reload" ? "Reloading…" : "Apply now"}
            </Button>
            <Button onClick={() => setEditing("new")}>
              <Plus className="mr-1.5 h-4 w-4" />
              Add server
            </Button>
          </>
        }
      />

      {fromDatabase === false && (
        <HealthStrip tone="destructive">
          <strong>Nothing on this page is loaded by the gateway.</strong> It is reading its workers
          from <code>smsg.properties</code>, not the database. These rows are stored, valid and
          ignored; start the gateway with <code>FIREFLO_CONFIG_SOURCE=db</code> to use them.
        </HealthStrip>
      )}

      {/* above the listeners rather than inside one, because the answer is about the logins that
          would bind and is the same whichever listener the setting is turned on for */}
      <ProductReadiness />

      {/* only what belongs to the page; an action's failure is rendered on its own card */}
      {error && !errorFor && (
        <Card>
          <CardContent className="py-4 text-sm text-destructive">{error}</CardContent>
        </Card>
      )}
      {bindRefusals.length > 0 && (
        <HealthStrip>
          <strong>Binds are being refused.</strong> Since the gateway last started:{" "}
          {bindRefusals.map(([reason, n]) => `${n} × ${REFUSAL_WORDS[reason] ?? reason}`).join(", ")}.
          The ceilings are <code>srv.maxConnectionsPerIP</code> and the credential&apos;s max
          connections — a customer fleet behind one NAT counts as one IP.
        </HealthStrip>
      )}

      {healthError && (
        <Card>
          <CardContent className="py-4 text-sm text-muted-foreground">
            Live state unavailable: {healthError} — settings below are still current.
          </CardContent>
        </Card>
      )}
      {notice && (
        <Card>
          <CardContent className="py-4 text-sm text-muted-foreground">{notice}</CardContent>
        </Card>
      )}

      {!errorFor && !error && !workers.length && (
        <EmptyState>
          {loading ? "Loading…" : "No servers yet"}
        </EmptyState>
      )}

      <LiveTrafficChart kind={KIND.server} queueHistory={queueHistory} />

      <WorkerSummary
        workers={workers}
        byFullName={byFullName}
        type={KIND.server}
        loading={loading}
      />

      {/* a grid of short cards; everything a card does not show is on the listener's own page */}
      <div className="grid gap-4 xl:grid-cols-2">
        {sorted.map((server) => (
          <div key={server.name} className="min-w-0 space-y-2">
            <ServerCard
              worker={server}
              live={byFullName.get(trafficKey(server))}
              verdict={verdictFor(server, byFullName, KIND.server)}
              busy={busy === server.name}
              onEdit={() => setEditing(server)}
              onToggleEnabled={(enabled) => setEnabled(server.name, enabled)}
            />
            {errorFor === server.name && error && <p className="text-xs text-destructive">{error}</p>}
          </div>
        ))}
      </div>

      {!!workers.length && <TrafficControlLegend type={KIND.server} />}
    </>
  );
}
