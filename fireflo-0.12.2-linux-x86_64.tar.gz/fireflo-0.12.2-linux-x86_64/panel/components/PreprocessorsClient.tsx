"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Cpu, Plus } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClasses } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";
import { CardActions, HealthStrip } from "./CardBits";
import { DangerAction } from "./DangerAction";
import { useHealth } from "./useHealth";
import { count } from "@/lib/format";
import { cn } from "@/lib/utils";
import {
  ON_ERROR,
  runnerFor,
  splitOnError,
  type Preprocessor,
  type PreprocessorInput,
  type PreprocessorLive,
} from "@/lib/preprocessor-types";

/**
 * The preprocessors this gateway runs, what each is doing, and which routing rules send to it.
 *
 * <p>Two sources, deliberately side by side: the rows in `app_preprocessor` (what is configured) and
 * `/ops/health` (what is actually running). They disagree in exactly the cases worth seeing -- a
 * file that is not on the gateway host, one with the wrong owner, a program that never says it is
 * ready -- and the gateway then skips every rule naming it, so the card says why in the gateway's
 * own words rather than leaving it to be found in a log.
 */
export function PreprocessorsClient() {
  const [list, setList] = useState<Preprocessor[] | null>(null);
  const [available, setAvailable] = useState(true);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");
  const { health } = useHealth();

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/control/preprocessors", { cache: "no-store" });
      const body = await res.json().catch(() => null);
      if (!res.ok) {
        setError(body?.error ?? `Request failed (${res.status})`);
        return;
      }
      setError("");
      setAvailable(body.data.available !== false);
      setList(body.data.preprocessors as Preprocessor[]);
    } catch {
      setError("Could not reach the panel's API.");
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const live = new Map((health?.preprocessors ?? []).map((p) => [p.name, p] as const));
  const gatewayKnows = health?.preprocessors != null;

  async function save(input: PreprocessorInput): Promise<string | null> {
    const res = await fetch("/api/control/preprocessors", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    });
    const body = await res.json().catch(() => null);
    if (!res.ok) {
      return body?.error ?? `Request failed (${res.status})`;
    }
    await load();
    return null;
  }

  async function setEnabled(p: Preprocessor, enabled: boolean) {
    setBusy(p.name);
    const failed = await save({ ...p, enabled });
    setBusy("");
    setError(failed ?? "");
  }

  async function remove(p: Preprocessor) {
    setBusy(p.name);
    const res = await fetch(`/api/control/preprocessors/${encodeURIComponent(p.name)}`, { method: "DELETE" });
    const body = await res.json().catch(() => null);
    setBusy("");
    if (!res.ok) {
      setError(body?.error ?? `Request failed (${res.status})`);
      return;
    }
    setError("");
    await load();
  }

  if (!available) {
    return (
      <HealthStrip>
        This database has no preprocessors table yet. It arrives with gateway 0.12.0 (migration V1.62.0) — upgrade
        the gateway, and this page fills in.
      </HealthStrip>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <p className="min-w-0 flex-1 text-sm text-muted-foreground">
          A routing rule sends to one as <code className="font-mono">@name</code>, and only the messages that rule
          matches ever reach it. The program lives on the gateway host, in its preprocessor directory; this page
          says which file runs and how, never what it does.
        </p>
        <Link href="/cp/preprocessors/new" className={buttonClasses({ className: "gap-2" })}>
          <Plus className="h-4 w-4" aria-hidden="true" /> Add preprocessor
        </Link>
      </div>

      {error && <HealthStrip tone="destructive">{error}</HealthStrip>}
      {health?.preprocessors_enabled === false && (
        <HealthStrip>
          <strong>Preprocessors are switched off on this gateway.</strong> Nothing below runs, and routing rules
          that send to one are skipped. Turn on <em>Run preprocessors</em> under{" "}
          <Link href="/cp/gateway" className="font-medium text-primary hover:underline">Gateway settings</Link>.
        </HealthStrip>
      )}

      {list && list.length === 0 && (
        <EmptyState>
          No preprocessors yet. Put a program in the gateway&apos;s preprocessor directory, add it here, then send
          traffic to it from a routing rule. The gateway ships samples in conf.example/preprocessors.
        </EmptyState>
      )}

      <div className="grid gap-4 xl:grid-cols-2">
        {(list ?? []).map((p) => (
          <PreprocessorCard
            key={p.name}
            p={p}
            live={live.get(p.name)}
            gatewayKnows={gatewayKnows}
            busy={busy === p.name}
            onToggle={(on) => setEnabled(p, on)}
            onDelete={() => remove(p)}
          />
        ))}
      </div>

    </div>
  );
}

function PreprocessorCard({
  p,
  live,
  gatewayKnows,
  busy,
  onToggle,
  onDelete,
}: {
  p: Preprocessor;
  live: PreprocessorLive | undefined;
  gatewayKnows: boolean;
  busy: boolean;
  onToggle: (on: boolean) => void;
  onDelete: () => void;
}) {
  const { kind, status } = splitOnError(p.onError);
  const onErrorLabel = ON_ERROR.find((o) => o.id === kind)?.label ?? kind;
  const state = !p.enabled ? { tone: "outline" as const, label: "Switched off" }
    : !gatewayKnows ? { tone: "outline" as const, label: "Gateway not reporting" }
    : !live ? { tone: "warning" as const, label: "Not loaded yet" }
    : live.state === "off" ? { tone: "outline" as const, label: "Off on this gateway" }
    : live.state === "unavailable" ? { tone: "destructive" as const, label: "Cannot run" }
    : live.ready === 0 ? { tone: "warning" as const, label: "Starting" }
    : { tone: "success" as const, label: `Running ${live.ready}/${live.workers}` };

  return (
    <Card className={cn("min-w-0", state.tone === "destructive" && "border-destructive")}>
      <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
        <Cpu className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
        <span className="font-mono text-base font-medium">@{p.name}</span>
        <Badge variant={state.tone}>{state.label}</Badge>
        {p.label && <span className="text-xs text-muted-foreground">{p.label}</span>}
      </CardHeader>
      <CardContent className="space-y-3 pt-3 text-sm">
        {live?.state === "unavailable" && live.problem && (
          <HealthStrip tone="destructive">
            {live.problem}. Every rule sending to @{p.name} is skipped until this is fixed.
          </HealthStrip>
        )}
        <dl className="grid grid-cols-[auto_minmax(0,1fr)] gap-x-4 gap-y-1">
          <dt className="text-muted-foreground">Runs</dt>
          <dd className="min-w-0 truncate"><span className="font-mono">{p.run}</span> <span className="text-muted-foreground">· {runnerFor(p.run)}</span></dd>
          <dt className="text-muted-foreground">Copies</dt>
          <dd>{p.workers}, up to {count(p.inflight)} messages waiting</dd>
          <dt className="text-muted-foreground">Time limit</dt>
          <dd>{p.timeoutMs} ms, then: {onErrorLabel}{status && ` (${status})`}</dd>
          <dt className="text-muted-foreground">Sent</dt>
          <dd className="font-mono text-xs">{p.fields.join(", ")}</dd>
        </dl>

        {live && live.state !== "unavailable" && live.state !== "off" && (
          <div className="flex flex-wrap gap-x-5 gap-y-1 border-t border-dashed border-border pt-3">
            <Stat label="answered" value={Object.values(live.actions).reduce((a, b) => a + b, 0)} />
            <Stat label="waiting now" value={live.waiting} />
            <Stat label="median" value={live.p50_ms} unit="ms" />
            <Stat label="p99" value={live.p99_ms} unit="ms" />
            <Stat label="timed out" value={live.timeouts} bad />
            <Stat label="not taken" value={live.refused} bad />
            <Stat label="restarts" value={live.restarts} bad />
          </div>
        )}
        {live && Object.values(live.actions).some((n) => n > 0) && (
          <p className="text-xs text-muted-foreground">
            {Object.entries(live.actions).filter(([, n]) => n > 0).map(([a, n]) => `${a} ${count(n)}`).join(" · ")}
          </p>
        )}

        <div className="border-t border-dashed border-border pt-3">
          <p className="mb-1 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">Sent to by</p>
          {p.usedBy.length === 0 ? (
            <p className="text-muted-foreground">
              No routing rule yet. Add one with target <span className="font-mono">@{p.name}</span> and the filter that
              picks its traffic.
            </p>
          ) : (
            <ul className="flex flex-wrap gap-1.5">
              {p.usedBy.map((u) => (
                <li key={`${u.table}-${u.seq}`}>
                  <Link
                    href={`/cp/routing/tables/${encodeURIComponent(u.table)}`}
                    className={cn("rounded border border-border px-1.5 py-0.5 font-mono text-xs hover:bg-accent", !u.enabled && "opacity-60")}
                  >
                    {u.table} #{u.seq}{!u.enabled && " (off)"}
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      </CardContent>
      <CardFooter className="border-t border-border pt-3">
        <Link href={`/cp/preprocessors/${encodeURIComponent(p.name)}`} className={buttonClasses({ variant: "outline", size: "sm" })}>
          Edit code
        </Link>
        <Button variant="ghost" size="sm" disabled={busy} onClick={() => onToggle(!p.enabled)}>
          {p.enabled ? "Disable" : "Enable"}
        </Button>
        <CardActions>
          <DangerAction
            label="Delete"
            confirmLabel={`Delete @${p.name}`}
            consequence={p.usedBy.length
              ? "Routing rules still send to it, so the database will refuse. Change those rules first."
              : "Its settings go. The program file on the gateway host is not touched."}
            busy={busy}
            onConfirm={onDelete}
          />
        </CardActions>
      </CardFooter>
    </Card>
  );
}

function Stat({ label, value, unit, bad }: { label: string; value: number | null | undefined; unit?: string; bad?: boolean }) {
  return (
    <span className="text-xs text-muted-foreground">
      <span className={cn("font-mono text-sm tabular-nums text-foreground", bad && (value ?? 0) > 0 && "text-destructive")}>
        {value == null ? "—" : count(value)}
      </span>
      {unit && value != null ? ` ${unit}` : ""} {label}
    </span>
  );
}
