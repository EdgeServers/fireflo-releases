import { configQuery } from "@/lib/config-db";
import {
  BUILTIN_REGISTRY,
  registryFrom,
  type ConfigKeyRegistry,
  type ConfigKeyRow,
} from "@/lib/config-key-registry";

/**
 * `app_config_key`, read from the gateway's database. Server-only: importing this pulls `pg`.
 *
 * <p>The table (gateway migration V1.61.0) is the one list of what every configuration key is; see
 * `config-key-registry.ts` for why. This returns it as a registry, or {@link BUILTIN_REGISTRY} when it
 * cannot be read -- a gateway in file mode has no such table to read, and a role built from an older
 * grant block cannot see it. The fallback is the same list the table was seeded from, so falling back
 * only loses keys added to the table since.
 *
 * <p>Held for {@link TTL_MS}: it changes when the gateway is upgraded, not while an operator works, and
 * every settings request asking the database for 118 rows it already has would be waste.
 */

const TTL_MS = 30_000;

let cached: { at: number; registry: ConfigKeyRegistry } | null = null;
let warned = false;

interface Row {
  scope: ConfigKeyRow["scope"];
  key: string;
  kind: ConfigKeyRow["kind"];
  choices: string[] | null;
  unit: string | null;
  coded_default: string | null;
  secret: boolean;
  access: ConfigKeyRow["access"];
  reason: ConfigKeyRow["reason"];
  label: string | null;
}

export async function loadConfigKeyRegistry(): Promise<ConfigKeyRegistry> {
  if (cached && Date.now() - cached.at < TTL_MS) {
    return cached.registry;
  }
  let registry: ConfigKeyRegistry;
  try {
    const rows = await configQuery<Row>(
      `SELECT scope, key, kind, choices, unit, coded_default, secret, access, reason, label
         FROM app_config_key ORDER BY scope, key`
    );
    registry = rows.length
      ? registryFrom(rows.map((r) => ({
        scope: r.scope, key: r.key, kind: r.kind, choices: r.choices, unit: r.unit,
        codedDefault: r.coded_default, secret: r.secret, access: r.access, reason: r.reason, label: r.label,
      })), "database")
      : BUILTIN_REGISTRY;
  } catch (err) {
    //once, not per request: the cause is a deployment fact (file mode, a missing grant) that a log
    //repeating it every thirty seconds would only bury
    if (!warned) {
      warned = true;
      console.warn(`app_config_key could not be read, using the panel's built-in copy: ${err instanceof Error ? err.message : err}`);
    }
    registry = BUILTIN_REGISTRY;
  }
  cached = { at: Date.now(), registry };
  return registry;
}
