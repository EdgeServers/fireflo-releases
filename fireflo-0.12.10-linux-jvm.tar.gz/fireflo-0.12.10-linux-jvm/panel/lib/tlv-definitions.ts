/**
 * Operator-defined TLV names, and what this deployment actually does with TLVs.
 *
 * <p>Server-only: opens the config pool. The shapes and the resolver live in `tlv-catalogue.ts`,
 * which is database-free so the forms can use them.
 *
 * <p><strong>Nothing here is ever consulted before a write.</strong> The gateway accepts any tag
 * from 0x0000 to 0xFFFF, so a definition is a label and never a permission. `eslint.config.mjs`
 * forbids `lib/workers.ts` and `lib/credentials.ts` from importing this module, which is what keeps
 * that true when someone reasonably thinks a bit of validation would be helpful.
 */
import { configQuery } from "./config-db";
import { type TlvDefinition, tlvTag } from "./tlv-catalogue";

export interface StoredTlvDefinition extends TlvDefinition {
  updatedBy: string | null;
  updatedAt: string | null;
}

/** Where a tag is declared, and under what name. One entry per declaration, not per tag. */
export interface TlvUsage {
  tag: number;
  /** The name half of the token, as written. */
  name: string;
  /** `vendor1`, `acme-smpp`, … */
  where: string;
  /** Which setting or field it was declared in. */
  setting: string;
}

interface DefinitionRow {
  tag: number;
  name: string;
  label: string | null;
  description: string | null;
  updated_by: string | null;
  updated_at: string | null;
}

export async function listTlvDefinitions(): Promise<StoredTlvDefinition[]> {
  const rows = await configQuery<DefinitionRow>(
    `SELECT tag, name, label, description, updated_by, updated_at
       FROM app_tlv_definition ORDER BY tag`
  );
  return rows.map((r) => ({
    tag: Number(r.tag),
    name: r.name,
    label: r.label ?? undefined,
    description: r.description ?? undefined,
    updatedBy: r.updated_by,
    updatedAt: r.updated_at,
  }));
}

export async function upsertTlvDefinition(
  input: { tag: number; name: string; label?: string | null; description?: string | null },
  operator: string
): Promise<void> {
  await configQuery(
    `INSERT INTO app_tlv_definition (tag, name, label, description, updated_by, updated_at)
     VALUES ($1, $2, $3, $4, $5, now())
     ON CONFLICT (tag) DO UPDATE
       SET name = EXCLUDED.name, label = EXCLUDED.label, description = EXCLUDED.description,
           updated_by = EXCLUDED.updated_by, updated_at = now()`,
    [
      input.tag,
      input.name.trim(),
      input.label?.trim() || null,
      input.description?.trim() || null,
      operator,
    ]
  );
}

export async function deleteTlvDefinition(tag: number): Promise<boolean> {
  const rows = await configQuery<{ tag: number }>(
    "DELETE FROM app_tlv_definition WHERE tag = $1 RETURNING tag",
    [tag]
  );
  return rows.length > 0;
}

/** The five worker settings that declare TLVs. */
const TLV_SETTINGS = [
  "registered.tlvs.submit",
  "registered.tlvs.dlr",
  "registered.tlvs.mo",
  "mandatory.tlvs.submit",
  "default.tlvs.submit",
];

/**
 * Every TLV this deployment declares anywhere, and under what name.
 *
 * <p>This is what makes the catalogue reflect the deployment rather than a fixed list: an
 * undocumented tag someone configured last year shows up here without anybody having to remember it.
 *
 * <p><strong>Config only.</strong> Counting how often a tag actually arrived would mean
 * `jsonb_object_keys` over an unindexed TEXT column on `cdr_submit`, which is the largest table
 * here, against a ten-second statement timeout — and it could not supply a name anyway, because
 * `CdrSubmit.tlvsOf` writes the canonical `0x%04X` and discards the token. Names come from config or
 * from nowhere.
 *
 * <p>Tokens are parsed with {@link tlvTag} rather than in SQL. A second parser would eventually
 * disagree with `TlvUtil.parseTag` about `tlv_0100` — tag 100, not 64 — and the disagreement would
 * be silent.
 */
export async function scanTlvUsage(): Promise<TlvUsage[]> {
  const [properties, credentials] = await Promise.all([
    configQuery<{ worker_name: string; key: string; value: string }>(
      `SELECT worker_name, key, value
         FROM app_worker_property
        WHERE key = ANY($1::text[]) AND value IS NOT NULL AND btrim(value) <> ''`,
      [TLV_SETTINGS]
    ),
    //never api_key: this is a diagnostic listing and a secret has no business in one
    configQuery<{ id: number; system_id: string | null; token: string }>(
      `SELECT id, system_id, jsonb_object_keys(default_tlvs) AS token
         FROM app_credential
        WHERE default_tlvs IS NOT NULL AND jsonb_typeof(default_tlvs) = 'object'`
    ),
  ]);

  const usage: TlvUsage[] = [];

  for (const row of properties) {
    for (const token of tokensOf(row.value, row.key)) {
      const tag = tlvTag(token);
      if (tag != null) {
        usage.push({ tag, name: nameOf(token), where: row.worker_name, setting: row.key });
      }
    }
  }

  for (const row of credentials) {
    const tag = tlvTag(row.token);
    if (tag != null) {
      usage.push({
        tag,
        name: nameOf(row.token),
        where: row.system_id ?? `credential #${row.id}`,
        setting: "credential default",
      });
    }
  }

  return usage;
}

/**
 * The tokens in one stored setting.
 *
 * <p>Two formats: `default.tlvs.submit` is `name_tag=value` pairs, the rest are bare `name_tag`
 * tokens. Both are comma-joined, and neither escapes anything.
 */
function tokensOf(value: string, setting: string): string[] {
  return value
    .split(",")
    .map((entry) => (setting === "default.tlvs.submit" ? entry.split("=")[0] : entry))
    .map((token) => token.trim())
    .filter(Boolean);
}

/** The name half of a token — everything before the last underscore. */
function nameOf(token: string): string {
  const cut = token.lastIndexOf("_");
  return cut > 0 ? token.slice(0, cut) : token;
}

/**
 * Which tags have had a decision made about them, and what it was.
 *
 * <p>A tag absent from this map has never been considered and takes the default, which is suggested.
 * That is why the table stores `suggested` rather than only the hidden tags — see the migration.
 */
export async function listTlvSuggestions(): Promise<Record<number, boolean>> {
  const rows = await configQuery<{ tag: number; suggested: boolean }>(
    "SELECT tag, suggested FROM app_tlv_suggestion"
  );
  return Object.fromEntries(rows.map((r) => [Number(r.tag), r.suggested]));
}

/**
 * Records a decision about one tag, or about many at once.
 *
 * <p>Bulk exists because the useful unit of curation is "the sixty spec tags this deployment will
 * never use", and sixty round trips is not a feature. One statement either way, so a bulk change is
 * atomic — a half-applied curation would leave the operator unable to tell what they had done.
 */
export async function setTlvSuggested(
  tags: readonly number[],
  suggested: boolean,
  operator: string
): Promise<void> {
  if (!tags.length) {
    return;
  }
  await configQuery(
    `INSERT INTO app_tlv_suggestion (tag, suggested, updated_by, updated_at)
     SELECT t, $2, $3, now() FROM unnest($1::int[]) AS t
     ON CONFLICT (tag) DO UPDATE
       SET suggested = EXCLUDED.suggested, updated_by = EXCLUDED.updated_by, updated_at = now()`,
    [tags, suggested, operator]
  );
}
