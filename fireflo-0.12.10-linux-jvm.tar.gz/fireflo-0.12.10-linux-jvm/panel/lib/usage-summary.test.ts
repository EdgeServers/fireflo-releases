import { strict as assert } from "node:assert";
import { test } from "node:test";

import { toAccountRows, toSeries, usageTotals } from "./usage-summary.ts";
import type { UsageDay } from "./metrics-queries.ts";

function row(over: Partial<UsageDay> = {}): UsageDay {
  return {
    day: "2026-08-14",
    accountId: "acct-1001",
    submitted: 10,
    delivered: 9,
    failed: 1,
    pending: 0,
    price: 20_000,
    ...over,
  };
}

test("a day with nothing settled has no delivery rate, rather than zero", () => {
  //the distinction the whole chart rests on. A quiet day drawn as 0% puts a cliff in the line that
  //never happened, and an operator reads a cliff as an outage
  const [point] = toSeries([row({ submitted: 4, delivered: 0, failed: 0, pending: 4 })]);
  assert.equal(point.rate, null);
  assert.notEqual(point.rate, 0);
});

test("the rate divides by what settled, not by what was sent", () => {
  //dividing by submitted counts in-flight traffic as failure, so the rate dips whenever volume
  //rises and recovers overnight on its own -- an alarm that fires on traffic rather than trouble
  const [point] = toSeries([row({ submitted: 100, delivered: 45, failed: 5, pending: 50 })]);
  assert.equal(point.rate, 90, "45 of the 50 that settled");
});

test("pending is counted and reported, but is not drawn as a bar", () => {
  const rows = [row({ submitted: 50, delivered: 10, failed: 0, pending: 40 })];
  const [point] = toSeries(rows);
  assert.equal(point.delivered + point.failed, 10, "today's bar is what settled");
  assert.equal(usageTotals(rows).pending, 40, "and the 40 in flight are still reported");
});

test("accounts collapse into one series per day, in date order", () => {
  const series = toSeries([
    row({ day: "2026-08-15", accountId: "acct-b", delivered: 3, failed: 0 }),
    row({ day: "2026-08-14", accountId: "acct-a", delivered: 5, failed: 1 }),
    row({ day: "2026-08-14", accountId: "acct-b", delivered: 2, failed: 0 }),
  ]);
  assert.deepEqual(series.map((p) => p.day), ["2026-08-14", "2026-08-15"]);
  assert.equal(series[0].delivered, 7, "both accounts on the 14th");
});

test("an account called nothing does not merge with traffic that named no account", () => {
  //an id is free text on the wire. Keying a map on `accountId ?? ""` would fold a real account
  //called "" -- or "null", depending on the sentinel -- into the unattributed bucket, and the
  //symptom is one customer's traffic silently appearing under somebody else's row
  const rows = toAccountRows([
    row({ accountId: null, submitted: 5 }),
    row({ accountId: "", submitted: 7 }),
    row({ accountId: "null", submitted: 3 }),
  ]);
  assert.equal(rows.length, 3, "three distinct rows");
  assert.equal(rows.find((r) => r.accountId === null)?.submitted, 5);
  assert.equal(rows.find((r) => r.accountId === "")?.submitted, 7);
  assert.equal(rows.find((r) => r.accountId === "null")?.submitted, 3);
});

test("an account's figures sum across every day in the window", () => {
  const rows = toAccountRows([
    row({ day: "2026-08-14", submitted: 10, delivered: 9, failed: 1, price: 20_000 }),
    row({ day: "2026-08-15", submitted: 20, delivered: 18, failed: 2, price: 40_000 }),
  ]);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].submitted, 30);
  assert.equal(rows[0].price, 60_000, "money stays scaled -- dividing is money()'s job");
  assert.equal(rows[0].rate, 90);
});

test("the table is ordered by volume, heaviest first", () => {
  const rows = toAccountRows([
    row({ accountId: "small", submitted: 5 }),
    row({ accountId: "large", submitted: 500 }),
    row({ accountId: "middle", submitted: 50 }),
  ]);
  assert.deepEqual(rows.map((r) => r.accountId), ["large", "middle", "small"]);
});

test("an unrated message is traffic with no money against it", () => {
  //price is summed, not counted, so a message the rating engine never priced contributes to volume
  //and nothing to revenue. That is the correct reading: it was sent, and nobody was charged
  const rows = [row({ submitted: 10, delivered: 10, failed: 0, price: 0 })];
  assert.equal(usageTotals(rows).submitted, 10);
  assert.equal(usageTotals(rows).price, 0);
});

test("totals agree with the sum of the account rows", () => {
  //the two are rendered side by side, and an operator who adds the column up must get the tile
  const rows = [
    row({ accountId: "a", submitted: 10, delivered: 8, failed: 2, pending: 0, price: 1_000 }),
    row({ accountId: "b", submitted: 30, delivered: 20, failed: 5, pending: 5, price: 3_000 }),
  ];
  const totals = usageTotals(rows);
  const table = toAccountRows(rows);
  assert.equal(totals.submitted, table.reduce((n, r) => n + r.submitted, 0));
  assert.equal(totals.price, table.reduce((n, r) => n + r.price, 0));
  assert.equal(totals.rate, 80, "28 delivered of the 35 that settled");
});

test("no rows at all is an empty page, not a crash or a zero rate", () => {
  assert.deepEqual(toSeries([]), []);
  assert.deepEqual(toAccountRows([]), []);
  assert.equal(usageTotals([]).rate, null);
  assert.equal(usageTotals([]).submitted, 0);
});
