/**
 * The message tester: shapes of the gateway's answers, and the hand-off to an editor when a test
 * finds nothing to match.
 *
 * <p>No database import and no React, so the rules for what is suggested can be tested on their own.
 */

import type { ConditionInput } from "./rate-types.ts";

/** One price or cost rule as `/ops/rating/explain` reports it. Amounts are decimal strings. */
export interface RatedRule {
  rule_id: number;
  scope: string;
  /** The account had no rule of its own and Default answered. */
  fallback: boolean;
  product: string | null;
  seq: number;
  conditions: string[];
  rate: string;
  currency: string | null;
  total: string;
}

export interface RatingAnswer {
  /** False when the gateway has no rates loaded at all. */
  active: boolean;
  parts: number;
  price: RatedRule | null;
  vendor: string | null;
  cost: RatedRule | null;
  margin?: string;
  margin_pct?: string | null;
}

export interface FilterOutcome {
  name: string;
  enabled: boolean;
  conditions: string[];
  matched: boolean;
  mismatch: string | null;
  used_by: string[];
}

export type TesterTab = "routing" | "pricing" | "filters";

/** What a test is run with. Kept in the address so a link reopens the same test. */
export interface TesterInput {
  account: string;
  to: string;
  from: string;
  product: string;
  ingateway: string;
  type: string;
  content: string;
}

export const BLANK_INPUT: TesterInput = { account: "", to: "", from: "", product: "", ingateway: "", type: "", content: "" };

/**
 * The prefix a "create one" suggestion starts from: the country code as typed, with its '+' if it
 * had one -- `+447700900123` gives `+44`, `919812345678` gives `91`. A guess for a person to
 * correct in the editor, never saved without them.
 */
export function suggestPrefix(number: string): string {
  const trimmed = number.trim();
  const plus = trimmed.startsWith("+") ? "+" : "";
  const digits = trimmed.replace(/^\+/, "").replace(/^00/, "");
  if (!digits) return "";
  //one-digit country codes (1, 7) are common enough that two digits would be wrong for them
  const width = digits.startsWith("1") || digits.startsWith("7") ? 1 : 2;
  return plus + digits.slice(0, width);
}

/** The one condition an editor opens pre-filled with, as address parameters. */
export function prefillParams(condition: ConditionInput, extra: Record<string, string> = {}): string {
  const params = new URLSearchParams({ new: "1", ...extra });
  params.set("wf", condition.field);
  params.set("wo", condition.operator);
  params.set("wv", condition.value);
  return params.toString();
}

/** The condition back out of the address, or null when there is none to open with. */
export function prefillFrom(params: { get(name: string): string | null }): ConditionInput | null {
  const field = params.get("wf");
  const operator = params.get("wo");
  const value = params.get("wv");
  if (!field || !operator || value === null) return null;
  return { field, operator, value, negate: false };
}

/** The destination condition a suggestion writes for a number. */
export function destinationCondition(number: string): ConditionInput {
  return { field: "to", operator: "startsWith", value: suggestPrefix(number), negate: false };
}

/**
 * Where a routing explanation leads next: a target that names a routing table is followed (the
 * real router continues there); anything else is where the message ends up.
 */
export function nextTable(target: string | null | undefined, tables: readonly string[]): string | null {
  return target && tables.includes(target) ? target : null;
}

/**
 * The vendor a final target names, for costing. Rules name a vendor by its short name
 * (`smppsim`) or its full one (`smppclient.smppsim`); a preprocessor (`@dnd`) or a listener
 * (`smppserver.x`, a receipt going back to a customer) is not one. The gateway resolves either
 * spelling to the scope its costs are kept under.
 */
export function vendorOf(target: string | null | undefined, tables: readonly string[] = []): string | null {
  if (!target || target.startsWith("@") || target.startsWith("smppserver.") || tables.includes(target)) return null;
  return target;
}

/**
 * The rule that decides where a message goes, by the router's own rule: the first matching rule,
 * except that a preprocessor rule (`@name`) never delivers and never stops the scan -- the message
 * comes back and carries on below it. Null when nothing past the preprocessors matches.
 */
export function deciding<R extends { matched: boolean; evaluable: boolean; target: string }>(rules: readonly R[]): R | null {
  return rules.find((r) => r.evaluable && r.matched && !r.target.startsWith("@")) ?? null;
}


/**
 * The table a filter's "used by" line names -- `routing: sample · rule 1014` gives `sample` -- when
 * that table is one nothing routes to, so the tester can say the rule never runs. Null for a price
 * line, or a table a message can reach.
 */
export function neverRunsIn(usedBy: string, unreached: readonly string[]): string | null {
  const table = /^routing: (.+?) · /.exec(usedBy)?.[1];
  return table && unreached.includes(table) ? table : null;
}
