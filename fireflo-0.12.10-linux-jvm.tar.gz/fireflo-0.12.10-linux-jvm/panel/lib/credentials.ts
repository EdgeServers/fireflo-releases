import { seal } from "@/lib/secret-box";
import { configQuery, inTransaction } from "@/lib/config-db";
import { resolveSecret } from "@/lib/secrets";
import { billingOf, type Credential, type CredentialContext, type CredentialInput } from "@/lib/credential-types";
import { assertProductsCatalogued, listOrphanProducts, listProducts } from "@/lib/products";
import { BILLING_KEY } from "@/lib/billing-key";
import { tlvTag } from "@/lib/tlv-string";
import type { LoginDefaults } from "@/lib/tlv-coverage";
import type { LoginProduct } from "@/lib/product-readiness";

/**
 * The SMPP and HTTP logins.
 *
 * <p>Server-only: importing this pulls `pg`. Types and validation live in `credential-types.ts`.
 *
 * <p><strong>Secrets are read as a boolean and never as a value.</strong> `password` and `api_key`
 * are not in any projection here; the browser learns only whether something is stored. That is a
 * deliberate step beyond the worker convention, which sends a placeholder — a placeholder still
 * requires the value to have been selected.
 *
 * <p><strong>Balances are not here at all.</strong> `account_balance` and `balance_ledger` are read
 * elsewhere and never written from this panel. The gateway's own note is that nothing in FireFlo can
 * mint credit, and a RECHARGE for an account with no balance row updates nothing while still being
 * marked applied — so the money vanishes with no error. Creating a credential does not create a
 * balance, and the form says so.
 */

interface CredentialRow {
  id: string;
  type: string;
  system_id: string | null;
  account_id: string | null;
  product: string | null;
  allowed_ips: string[] | null;
  allowed_products: string[] | null;
  default_tlvs: string | null;
  max_sessions: number | null;
  max_tx: number | null;
  max_rx: number | null;
  max_trx: number | null;
  /** numeric comes back from pg as a string, so it is not rounded through a float on the way */
  max_tps: string | null;
  enabled: boolean;
  updated_at: Date | null;
  has_password: boolean;
  has_api_key: boolean;
  lookup_key: string | null;
  lookup_key_is_secret: boolean;
}

/**
 * The lookup key, computed in SQL exactly as `Credential.getLookupKey()` does.
 *
 * <p>Kept identical on purpose: if the panel and the gateway disagreed about which row shadows which,
 * the panel's collision warning would be about a collision that does not exist, or worse, silent
 * about one that does.
 *
 * <p><strong>`lib/mis-logins.ts` holds the same expression</strong>, copied rather than imported
 * because this module pulls the products catalogue and the TLV parser in behind it and that one is
 * on the customer path. The two must not drift; each names the other.
 */
const LOOKUP_KEY = `CASE WHEN type = 'SMPP' THEN system_id
                         ELSE COALESCE(NULLIF(api_key, ''), system_id) END`;

const PROJECTION = `
  id::text, type, system_id, account_id, product, allowed_ips, allowed_products,
  default_tlvs::text AS default_tlvs, enabled, updated_at,
  max_sessions, max_tx, max_rx, max_trx, max_tps,
  (password IS NOT NULL AND password <> '') AS has_password,
  (api_key  IS NOT NULL AND api_key  <> '') AS has_api_key,
  ${LOOKUP_KEY} AS lookup_key,
  (type <> 'SMPP' AND COALESCE(api_key, '') <> '') AS lookup_key_is_secret`;

export async function listCredentials(): Promise<Credential[]> {
  const rows = await configQuery<CredentialRow>(
    `SELECT ${PROJECTION} FROM app_credential ORDER BY id`
  );
  return rows.map(toCredential);
}

export async function getCredential(id: number): Promise<Credential | null> {
  const rows = await configQuery<CredentialRow>(
    `SELECT ${PROJECTION} FROM app_credential WHERE id = $1`,
    [id]
  );
  return rows.length ? toCredential(rows[0]) : null;
}

/**
 * Everything validation needs from other tables.
 *
 * <p>Products are the catalogue plus the orphans, or an existing credential would be refused for the
 * product it already has — on this deployment that is every one of them.
 */
export async function credentialContext(): Promise<CredentialContext> {
  const [catalogue, orphans, keys] = await Promise.all([
    listProducts(),
    listOrphanProducts(),
    configQuery<{ key: string; id: string; type: string; enabled: boolean }>(
      `SELECT ${LOOKUP_KEY} AS key, id::text, type, enabled
         FROM app_credential
        WHERE ${LOOKUP_KEY} IS NOT NULL
        ORDER BY id`
    ),
  ]);
  return {
    products: [...new Set([...catalogue.map((p) => p.name), ...orphans])].sort(),
    disabledProducts: catalogue.filter((p) => !p.enabled).map((p) => p.name),
    conflicts: keys.map((k) => ({ key: k.key, id: Number(k.id), type: k.type, enabled: k.enabled })),
  };
}

/**
 * Creates or replaces one credential.
 *
 * <p>The unit of write is the row, unlike `saveScope`. Credentials are keyed independently and have
 * no ordinal meaning, so there is nothing a neighbouring row can make wrong that this row's own
 * validation cannot see.
 *
 * <p>The lookup-key check runs again inside the transaction. It narrows the race the missing unique
 * index leaves open — it does not close it, because only the index could. The panel is the
 * compensating control, in the same way `deleteProduct` is for the absent product foreign key.
 *
 * @throws Error with a sentence, for the route to return as a 400
 */
export async function saveCredential(input: CredentialInput): Promise<number> {
  return inTransaction(async (client) => {
    await assertProductsCatalogued([input.product, ...input.allowedProducts], client);
    let storedPassword: string | null = null;
    let storedApiKey: string | null = null;

    if (input.id != null) {
      const existing = await client.query<{ password: string | null; api_key: string | null }>(
        `SELECT password, api_key FROM app_credential WHERE id = $1 FOR UPDATE`,
        [input.id]
      );
      if (!existing.rows.length) {
        throw new Error("Reload the page — this credential has been deleted since it was opened.");
      }
      storedPassword = existing.rows[0].password;
      storedApiKey = existing.rows[0].api_key;
    }

    //sealed at rest when FIREFLO_SECRETS_KEY is set, in the gateway's format. A `kept` password is
    //the stored value, sealed or not, carried through unchanged; a new one is sealed here
    const password = seal(resolveSecret(input.password, storedPassword, "password"));
    const apiKey = resolveSecret(input.apiKey, storedApiKey, "API key");

    //recomputed from the RESOLVED secrets: a `kept` api key still makes the lookup key the api key
    const key = input.type === "SMPP"
      ? input.systemId?.trim() || null
      : (apiKey || input.systemId?.trim() || null);
    if (key) {
      const clash = await client.query<{ id: string; type: string }>(
        `SELECT id::text, type FROM app_credential
          WHERE enabled AND ${LOOKUP_KEY} = $1 AND ($2::bigint IS NULL OR id <> $2::bigint)`,
        [key, input.id]
      );
      if (clash.rows.length) {
        throw new Error(
          `Another enabled credential (#${clash.rows[0].id}, ${clash.rows[0].type}) already uses this `
          + "lookup key. The gateway keeps only one of them, so one of the two customers would stop "
          + "working."
        );
      }
    }

    const values = [
      //written from the validated set, never as typed: a lowercase value would behave as SMPP and
      //escape the unique index, which compares type = 'SMPP' literally
      input.type,
      input.systemId?.trim() || null,
      password,
      apiKey,
      input.accountId?.trim() || null,
      input.product?.trim() || null,
      //null rather than an empty array: both mean allow-all to the gateway, but null is what "absent"
      //means and it keeps "which credentials are unrestricted" a question SQL can answer
      input.allowedIps.length ? input.allowedIps : null,
      //same null-not-empty rule, opposite default. An empty allowed_ips means "from anywhere"; an
      //empty allowed_products means "may not name one", because the product picks the price and
      //nobody should choose their own by default
      input.allowedProducts.length ? input.allowedProducts : null,
      input.defaultTlvs.length
        ? JSON.stringify(Object.fromEntries(input.defaultTlvs.map((t) => [t.key, t.value])))
        : null,
      input.enabled,
    ];
    //SMPP only, and only when the request carried them: the portal's writer never does, so an
    //update from there leaves an operator's limits in place rather than clearing them
    const limits = input.type === "SMPP" ? input.limits : undefined;
    const limitValues = limits
      ? [limits.maxSessions, limits.maxTx, limits.maxRx, limits.maxTrx, limits.maxTps]
      : [null, null, null, null, null];

    if (input.id == null) {
      const created = await client.query<{ id: string }>(
        `INSERT INTO app_credential
                (type, system_id, password, api_key, account_id, product,
                 allowed_ips, allowed_products, default_tlvs, enabled,
                 max_sessions, max_tx, max_rx, max_trx, max_tps, updated_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7::text[], $8::text[], $9::jsonb, $10,
                 $11, $12, $13, $14, $15, now())
         RETURNING id::text`,
        [...values, ...limitValues]
      );
      return Number(created.rows[0].id);
    }

    await client.query(
      `UPDATE app_credential
          SET type = $2, system_id = $3, password = $4, api_key = $5, account_id = $6,
              product = $7, allowed_ips = $8::text[], allowed_products = $9::text[],
              default_tlvs = $10::jsonb, enabled = $11, updated_at = now()
        WHERE id = $1`,
      [input.id, ...values]
    );
    //separate, so "absent" can mean "leave as they are" without a second copy of the statement above.
    //A login that is not SMPP has its limits cleared: they would mean nothing on REST
    if (limits || input.type !== "SMPP") {
      await client.query(
        `UPDATE app_credential
            SET max_sessions = $2, max_tx = $3, max_rx = $4, max_trx = $5, max_tps = $6
          WHERE id = $1`,
        [input.id, ...limitValues]
      );
    }
    return input.id;
  });
}

/**
 * Turns a credential on or off.
 *
 * <p>Takes effect on the gateway's next configuration poll, as a product's `enabled` does too -- the
 * gateway's catalogue is the enabled products, and an unlisted one is refused as unknown where a
 * listener requires a product.
 *
 * <p>Returns the row's identity rather than a bare boolean because switching a login off has a live
 * consequence the caller has to follow up: any session already bound with it keeps sending until
 * something ends it, and ending those needs the system ID.
 *
 * @returns null when there is no such row
 */
export async function setCredentialEnabled(
  id: number,
  enabled: boolean
): Promise<{ type: string; systemId: string | null } | null> {
  const rows = await configQuery<{ type: string; system_id: string | null }>(
    `UPDATE app_credential SET enabled = $2, updated_at = now() WHERE id = $1
      RETURNING type, system_id`,
    [id, enabled]
  );
  return rows.length > 0 ? { type: rows[0].type, systemId: rows[0].system_id } : null;
}

/**
 * The enabled SMPP login a bound session is using.
 *
 * <p>A live session reports the system ID it bound with and nothing that identifies a row, so this
 * is the only way back from a connection to the credential that admitted it — which is what
 * "disconnect and stop it coming back" needs.
 *
 * <p>Restricted to enabled rows because a disabled one cannot be what admitted the bind, and to SMPP
 * because an HTTP credential holds no sessions. Returns null rather than guessing when the system ID
 * matches nothing: turning off the wrong login is worse than turning off none.
 *
 * @returns at most one row — `uq_app_credential_smpp` is unique over enabled SMPP system IDs
 */
export async function findBoundSmppCredential(systemId: string): Promise<{ id: number } | null> {
  const rows = await configQuery<{ id: string }>(
    `SELECT id::text FROM app_credential
      WHERE type = 'SMPP' AND enabled AND system_id = $1`,
    [systemId]
  );
  return rows.length === 1 ? { id: Number(rows[0].id) } : null;
}

export async function deleteCredential(id: number): Promise<boolean> {
  const rows = await configQuery<{ id: string }>(
    `DELETE FROM app_credential WHERE id = $1 RETURNING id::text`,
    [id]
  );
  return rows.length > 0;
}

function toCredential(row: CredentialRow): Credential {
  const billing = billingOf(row.type, row.account_id, row.system_id, row.has_api_key);
  return {
    id: Number(row.id),
    type: row.type,
    systemId: row.system_id,
    accountId: row.account_id,
    product: row.product,
    allowedIps: row.allowed_ips ?? [],
    allowedProducts: row.allowed_products ?? [],
    defaultTlvs: parseTlvs(row.default_tlvs),
    limits: {
      maxSessions: row.max_sessions,
      maxTx: row.max_tx,
      maxRx: row.max_rx,
      maxTrx: row.max_trx,
      maxTps: row.max_tps == null ? null : Number(row.max_tps),
    },
    enabled: row.enabled,
    updatedAt: row.updated_at ? row.updated_at.toISOString() : null,
    password: row.has_password ? "stored" : "unset",
    apiKey: row.has_api_key ? "stored" : "unset",
    //dropped rather than sent: for an HTTP credential with an api key this value IS the secret
    lookupKey: row.lookup_key_is_secret ? null : row.lookup_key,
    lookupKeyIsSecret: row.lookup_key_is_secret,
    billingAccount: billing.account,
    billingAccountFallback: billing.fallback,
  };
}

/** A malformed value costs the TLVs, not the row — the gateway does the same, with a warning. */
function parseTlvs(json: string | null): { key: string; value: string }[] {
  if (!json) {
    return [];
  }
  try {
    const parsed = JSON.parse(json);
    if (!parsed || typeof parsed !== "object") {
      return [];
    }
    return Object.entries(parsed as Record<string, unknown>).map(([key, value]) => ({
      key,
      value: String(value ?? ""),
    }));
  } catch {
    return [];
  }
}

/**
 * What each enabled login already puts on every message it carries, as tags.
 *
 * <p>One of the three things that can satisfy a mandatory TLV — see `lib/tlv-coverage.ts` — and the
 * one an operator is least likely to remember, because it is set per login rather than per account.
 *
 * <p><strong>Tags only, never the values.</strong> A default TLV value is a customer's DLT
 * registration identifier; the coverage question is "is this tag supplied", so the values have no
 * business crossing to the browser. Not `listCredentials()` for the same reason — that is the
 * editor's projection and answering a different question with it would ship more than is needed.
 *
 * <p>Disabled logins are excluded: one carries nothing, so it neither covers a tag nor fails to.
 *
 * <p>A login whose billing key is NULL — HTTP keyed on its api key, which is a secret — is dropped
 * by {@link BILLING_KEY} and is therefore invisible to the coverage rule. That is a real limit and
 * it is the same one every other account-scoped query here has.
 */
/**
 * What product each enabled login is configured with, and nothing else.
 *
 * <p>The input to `lib/product-readiness.ts`, which answers what would stop binding if a listener
 * began requiring a product. Deliberately not `listCredentials()` — that is the editor's projection
 * and carries secrets this question has no use for.
 *
 * <p>Disabled logins are excluded: one binds nothing, so it can neither pass nor fail the check.
 *
 * <p>The type comes back because it changes what can be said about the answer. An HTTP login's
 * product is the only source there is, so the report is exact; an SMPP client can override it with
 * the `system_type` on its bind, which this cannot see.
 */
export async function listLoginProducts(accountId?: string): Promise<LoginProduct[]> {
  const rows = await configQuery<{
    account_id: string | null;
    system_id: string | null;
    type: string;
    product: string;
  }>(
    `SELECT ${BILLING_KEY} AS account_id,
            system_id,
            type,
            COALESCE(NULLIF(btrim(product), ''), '') AS product
       FROM app_credential
      WHERE enabled
      ORDER BY id`
  );

  return rows
    .filter((r) => r.account_id && (!accountId || r.account_id === accountId))
    .map((r) => ({
      accountId: r.account_id as string,
      systemId: r.system_id,
      type: r.type === "SMPP" ? "SMPP" as const : "HTTP" as const,
      product: r.product,
    }));
}

export async function listLoginDefaults(accountId?: string): Promise<LoginDefaults[]> {
  const rows = await configQuery<{
    account_id: string | null;
    product: string;
    system_id: string | null;
    default_tlvs: string | null;
  }>(
    `SELECT ${BILLING_KEY} AS account_id,
            COALESCE(NULLIF(btrim(product), ''), '') AS product,
            system_id,
            default_tlvs::text AS default_tlvs
       FROM app_credential
      WHERE enabled
      ORDER BY id`
  );

  return rows
    .filter((r) => r.account_id && (!accountId || r.account_id === accountId))
    .map((r) => ({
      accountId: r.account_id as string,
      product: r.product,
      systemId: r.system_id,
      //an empty default supplies nothing: MessageFlexValue.getValueFor returns null for "" and for
      //the literal "null", and validateMandatoryTlvs reads an empty value as unset
      tags: parseTlvs(r.default_tlvs)
        .filter((t) => t.value.trim() && t.value.trim() !== "null")
        .map((t) => tlvTag(t.key))
        .filter((tag): tag is number => tag !== null),
    }));
}
