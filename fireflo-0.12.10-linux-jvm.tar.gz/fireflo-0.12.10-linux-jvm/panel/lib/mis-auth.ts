import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { CUSTOMER_ROLE } from "@/lib/roles";
import { logAuthFailure } from "@/lib/access-log";
import { recordCustomerAccess } from "@/lib/customer-access-log";
import { redeemLoginToken } from "@/lib/login-token";
import { burnVerifyTime, verifyPassword } from "@/lib/password-hash";
import { lockoutKey, signinLockout } from "@/lib/signin-lockout";
import { normaliseEmail } from "@/lib/user-types";
import { findLoginUser, touchLastLogin } from "@/lib/users";
import { currentRequestContext, markRequestHandled } from "@/lib/request-context";

/** Failed portal password sign-ins, counted apart from the operator's -- see lib/signin-lockout.ts. */
const lockout = signinLockout();

/**
 * Customer sign-in, for the portal at the site root.
 *
 * <p><strong>A second NextAuth instance, on its own cookie.</strong> Not a second provider on the
 * operator's: a provider shares the cookie, and a shared cookie means one token type for two kinds
 * of identity, so every operator route would be one missed check away from a customer. Separate
 * instances make the separation structural — this one cannot mint the operator role, and the
 * operator's cannot mint an account id.
 *
 * <p>Two credentials. A password, for a login that has one -- set by an operator on the account
 * page, or by the customer from the portal. And a one-time token from an emailed link: proof the
 * person can read an address that is an `app_user` row on their account, which is also how somebody
 * with no password gets in. Both are providers on THIS instance, never on the operator's.
 */
export const {
  handlers: misHandlers,
  auth: misAuth,
  signIn: misSignIn,
  signOut: misSignOut,
} = NextAuth({
  providers: [
    Credentials({
      id: "password",
      name: "Password",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const context = currentRequestContext();
        const ip = context?.ip ?? null;
        const userAgent = context?.userAgent ?? null;
        const typed = typeof credentials?.email === "string" ? credentials.email.trim() : "";
        const password = typeof credentials?.password === "string" ? credentials.password : "";
        const email = normaliseEmail(typed) ?? typed;
        const key = lockoutKey(ip, email);

        //one shape for every refusal, and the reason only in the logs: a reply that said which half
        //was wrong would tell an attacker which addresses are customers
        const refuse = (reason: string) => {
          markRequestHandled();
          void recordCustomerAccess({ event: "password_signin_failed", email: typed || null, ip, userAgent, detail: { reason } });
          void logAuthFailure({ surface: "portal", reason, triedAs: typed || null, ip });
          return null;
        };

        if (!typed || !password) {
          return refuse("bad_credentials");
        }
        if (lockout.lockedOut(key)) {
          return refuse("rate_limited");
        }
        //disabled people and disabled accounts are not found, so they read as a wrong password
        const user = await findLoginUser(email, "portal");
        //the derivation runs whether or not there is a hash, so an unknown address and a link-only
        //login cost the same time as a real one -- see burnVerifyTime
        const ok = user?.passwordHash
          ? await verifyPassword(password, user.passwordHash)
          : (await burnVerifyTime(password), false);
        if (!user || !ok || !user.accountId) {
          lockout.noteFailure(key);
          return refuse("bad_credentials");
        }
        lockout.clear(key);
        markRequestHandled();
        void recordCustomerAccess({ event: "password_signin", accountId: user.accountId, userId: user.id, email: user.email, ip, userAgent });
        void touchLastLogin(user.id);
        return { id: String(user.id), name: user.accountId, accountId: user.accountId };
      },
    }),
    Credentials({
      id: "magic-link",
      name: "Sign-in link",
      credentials: { token: { label: "Token", type: "text" } },
      async authorize(credentials) {
        const token = credentials?.token;
        if (typeof token !== "string") {
          return null;
        }
        //the address arrives through an async context, because this function is handed the token
        //and nothing else. Read here rather than inside login-token.ts, which stays free of
        //ambient state -- see lib/request-context.ts
        const context = currentRequestContext();
        const ip = context?.ip ?? null;
        const userAgent = context?.userAgent ?? null;

        //spends the token. Anything falsy here -- unknown, expired, already used -- is one null,
        //because telling them apart would tell an attacker which of their guesses was close
        const redeemed = await redeemLoginToken(token, "portal");
        if (!redeemed) {
          //the caller still learns nothing; the log does
          void recordCustomerAccess({ event: "link_rejected", ip, userAgent });
          //a link that was never valid, has expired, or has already been spent. The third case is
          //the one worth banning on: somebody replaying links they should not hold
          void logAuthFailure({ surface: "portal", reason: "link_rejected", triedAs: null, ip });
          return null;
        }

        //the row that makes a stolen link visible: app_login_token.requested_ip says where the link
        //was asked for, this says where it was spent, and a mismatch is one query away
        const { userId } = redeemed;
        //never null on the portal surface: the redeem's WHERE requires an account
        const accountId = redeemed.accountId!;
        void recordCustomerAccess({ event: "link_redeemed", accountId, userId, ip, userAgent });
        void touchLastLogin(userId);
        //`id` is what next-auth hands the jwt callback as `user.id`; the account rides alongside
        return { id: String(userId), name: accountId, accountId };
      },
    }),
  ],

  pages: { signIn: "/" },
  //NextAuth assumes /api/auth and builds every callback URL from it. The operator instance already
  //owns that path, so this one has to be told where it actually lives -- without it every endpoint
  //here answers "Bad request" because the route it thinks it is serving is not the route it is on
  basePath: "/api/mis/auth",
  trustHost: true,
  session: { strategy: "jwt" },

  callbacks: {
    jwt({ token, user }) {
      if (user) {
        token.role = CUSTOMER_ROLE;
        token.accountId = (user as { accountId?: string }).accountId;
        token.userId = user.id;
      }
      return token;
    },
    session({ session, token }) {
      const t = token as { role?: string; accountId?: string; userId?: string };
      session.user.role = t.role ?? null;
      //the only place the account is ever established. Every portal query reads it from here and
      //nothing takes it from a request -- see require-customer.ts
      session.user.accountId = t.accountId ?? null;
      session.user.userId = t.userId ?? null;
      return session;
    },
  },

  cookies: {
    //every cookie this instance sets is named apart from the operator's, not only the session.
    //The CSRF and callback cookies default to the same names on both instances, and Auth.js
    //rewrites the CSRF cookie on ANY request that arrives without one -- including the operator
    //SessionProvider's /api/auth/session probe that the root layout fires on every page. On
    ///verify that probe raced the portal's own csrf fetch, the later Set-Cookie won, and the
    //magic-link POST was refused as MissingCSRF for a link that was perfectly good
    csrfToken: {
      name: "fireflo-mis.csrf-token",
      options: { httpOnly: true, sameSite: "lax" as const, path: "/", secure: secureCookies() },
    },
    callbackUrl: {
      name: "fireflo-mis.callback-url",
      options: { sameSite: "lax" as const, path: "/", secure: secureCookies() },
    },
    sessionToken: {
      //a different name from the operator's, which is what stops the browser sending one where the
      //other is expected
      name: "fireflo-mis.session-token",
      options: {
        httpOnly: true,
        sameSite: "lax" as const,
        path: "/",
        //the same rule as the operator cookie, reasoned out in lib/auth.ts. This one had been left
        //on the NODE_ENV guess, so over http the first click redeemed the token, the browser
        //dropped the cookie, the page said the link failed, and the customer's second click found
        //the token spent -- logged as CredentialsSignin, which pointed at the link, not the cookie
        secure: secureCookies(),
      },
    },
  },
});

function secureCookies(): boolean {
  return process.env.AUTH_COOKIE_SECURE
    ? process.env.AUTH_COOKIE_SECURE === "true"
    : process.env.NODE_ENV === "production";
}
