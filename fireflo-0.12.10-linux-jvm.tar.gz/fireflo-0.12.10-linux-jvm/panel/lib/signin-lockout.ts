/**
 * Ten FAILED attempts per address and peer per quarter hour, then a refusal until the window ends.
 *
 * <p>Failures, not attempts: a limiter that counted successes locked out an operator who signed in
 * from several tabs, and the e2e suite, which signs in once per test. A wrong password is what an
 * attacker produces and a right one is not. Bounded like `rate-limit.ts` -- cleared wholesale rather
 * than swept, and the cost of clearing is a fresh allowance, which is the safe direction.
 *
 * <p>One per sign-in surface: the operator panel and the customer portal each make their own, so a
 * run of failures at one door never locks the other.
 */
export const MAX_FAILURES = 10;
export const FAILURE_WINDOW_MS = 15 * 60_000;

export interface SigninLockout {
  lockedOut(key: string): boolean;
  noteFailure(key: string): void;
  clear(key: string): void;
}

export function signinLockout(): SigninLockout {
  const failures = new Map<string, { count: number; until: number }>();
  return {
    lockedOut(key) {
      const f = failures.get(key);
      return !!f && Date.now() < f.until && f.count >= MAX_FAILURES;
    },
    noteFailure(key) {
      const now = Date.now();
      const f = failures.get(key);
      if (!f || now > f.until) {
        if (failures.size > 10_000) {
          failures.clear();
        }
        failures.set(key, { count: 1, until: now + FAILURE_WINDOW_MS });
        return;
      }
      f.count += 1;
    },
    clear(key) {
      failures.delete(key);
    },
  };
}

/** The key both sign-ins count failures under: where it came from, and which address it named. */
export function lockoutKey(ip: string | null, email: string): string {
  return `${ip ?? "-"}|${email.toLowerCase()}`;
}
