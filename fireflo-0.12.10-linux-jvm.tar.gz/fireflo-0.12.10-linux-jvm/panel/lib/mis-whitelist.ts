import { configQuery } from "@/lib/config-db";
import { BILLING_KEY } from "@/lib/billing-key";
import type { ApprovedHeader, ApprovedTemplate } from "@/lib/whitelist-types";

/**
 * What a customer may do to their own sender IDs and templates.
 *
 * <p>Server-only. Separate from `lib/whitelist.ts` rather than added to it, because the two have
 * different rules and mixing them is how one leaks into the other: the operator's functions take an
 * account id as an argument and may set any status, and none of that is safe to expose to a
 * customer. Every function here takes the account from its caller's session and forces the status
 * itself.
 *
 * <h2>Submitting is not approving</h2>
 *
 * <p>Everything a customer writes lands `PENDING`. The gateway serves a row only when it is
 * `enabled AND status = 'APPROVED'`, so a submission is stored, visible to both sides, and not in
 * use until an operator decides.
 *
 * <h2>Editing an approved row withdraws it</h2>
 *
 * <p>{@link updateOwnHeader} and {@link updateOwnTemplate} set the status back to `PENDING`, so an
 * edit takes the registration out of service until it is approved again. That is deliberate -- a
 * customer must not be able to change what was approved and keep sending under the approval -- and
 * it has a sharp edge: a typo stops their traffic. The caller is responsible for saying so before
 * the write, which is why the forms arm a confirmation.
 */

/** Both lists for one account, newest request first so a pending item is not buried. */
export async function listOwnHeaders(accountIds: string[]): Promise<ApprovedHeader[]> {
  const rows = await configQuery<ApprovalRow & { header: string }>(
    `SELECT id::text, account_id, product, header, tlvs, requested_tlvs, system_id, label, enabled,
            updated_by, updated_at,
            status, requested_by, request_note, reviewed_by, reviewed_at, review_note
       FROM app_header
      WHERE account_id = ANY($1)
      ORDER BY CASE status WHEN 'PENDING' THEN 0 WHEN 'REJECTED' THEN 1 ELSE 2 END,
               account_id, product, header`,
    [accountIds]
  );
  return rows.map(toHeader);
}

export async function listOwnTemplates(accountIds: string[]): Promise<ApprovedTemplate[]> {
  const rows = await configQuery<ApprovalRow & { name: string | null; body: string }>(
    `SELECT id::text, account_id, product, name, body, tlvs, requested_tlvs, system_id, label, enabled,
            updated_by, updated_at,
            status, requested_by, request_note, reviewed_by, reviewed_at, review_note
       FROM app_template
      WHERE account_id = ANY($1)
      ORDER BY CASE status WHEN 'PENDING' THEN 0 WHEN 'REJECTED' THEN 1 ELSE 2 END,
               account_id, product, id`,
    [accountIds]
  );
  return rows.map(toTemplate);
}

/**
 * The account a row belongs to, or null when there is no such row.
 *
 * <p>Every customer write names a row by id, and an id is a number somebody can guess. The caller
 * puts this through `assertInScope` before touching anything -- checking ownership by adding
 * `AND account_id = $2` to the UPDATE would work too, but it answers "nothing happened" for both a
 * missing row and somebody else's, and those deserve the same 404 for different reasons.
 */
export async function ownerOfHeader(id: number): Promise<string | null> {
  const rows = await configQuery<{ account_id: string }>(
    "SELECT account_id FROM app_header WHERE id = $1",
    [id]
  );
  return rows.length ? rows[0].account_id : null;
}

export async function ownerOfTemplate(id: number): Promise<string | null> {
  const rows = await configQuery<{ account_id: string }>(
    "SELECT account_id FROM app_template WHERE id = $1",
    [id]
  );
  return rows.length ? rows[0].account_id : null;
}

export interface SenderSubmission {
  accountId: string;
  /**
   * The customer user asking. `requested_by` records the ACCOUNT, which says whose request it is
   * but not who made it; since gateway V1.59.0 this goes in `requested_by_user_id` beside it.
   */
  userId: number;
  product: string;
  header: string;
  requestNote: string | null;
  /** Proposed, never served. See the note on `updateOwnHeader`. */
  requestedTlvs: string | null;
  /** One of this account's logins, or null for all of them. Validated by the route. */
  systemId: string | null;
}

export interface TemplateSubmission {
  accountId: string;
  /**
   * The customer user asking. `requested_by` records the ACCOUNT, which says whose request it is
   * but not who made it; since gateway V1.59.0 this goes in `requested_by_user_id` beside it.
   */
  userId: number;
  product: string;
  name: string | null;
  body: string;
  requestNote: string | null;
  requestedTlvs: string | null;
  systemId: string | null;
}

/**
 * @returns an error to show the customer, or null. A duplicate is the expected failure: the natural
 *     key spans every status, so asking again for something already requested or approved is caught
 *     here rather than becoming a second row nobody can tell apart from the first.
 */
export async function submitHeader(input: SenderSubmission): Promise<string | null> {
  const existing = await configQuery<{ status: string }>(
    //scoped to the login too, because the natural key is -- two logins asking for the same sender
    //ID is the case this exists for, and refusing the second would be refusing the feature
    `SELECT status FROM app_header
      WHERE account_id = $1 AND product = $2 AND lower(header) = lower($3)
        AND COALESCE(system_id, '') = COALESCE($4::text, '')`,
    [input.accountId, input.product, input.header, input.systemId]
  );
  if (existing.length) {
    return existing[0].status === "APPROVED"
      ? "That sender ID is already approved for this account."
      : "You have already asked for that sender ID; it is waiting on an operator.";
  }

  await configQuery(
    `INSERT INTO app_header
        (account_id, product, header, enabled, status, requested_by, request_note, requested_tlvs,
         system_id, requested_by_user_id)
     VALUES ($1, $2, $3, true, 'PENDING', $1, $4, $5, $6, $7)`,
    [input.accountId, input.product, input.header, input.requestNote, input.requestedTlvs,
      input.systemId, input.userId]
  );
  return null;
}

export async function submitTemplate(input: TemplateSubmission): Promise<string | null> {
  //no natural key on app_template, so a duplicate body is checked here rather than by a constraint.
  //Ignoring case, as the gateway matches: two bodies that differ only in case approve the same messages
  const existing = await configQuery<{ status: string }>(
    `SELECT status FROM app_template
      WHERE account_id = $1 AND product = $2 AND lower(body) = lower($3)
        AND COALESCE(system_id, '') = COALESCE($4::text, '')`,
    [input.accountId, input.product, input.body, input.systemId]
  );
  if (existing.length) {
    return existing[0].status === "APPROVED"
      ? "That wording is already approved for this account."
      : "You have already asked for that wording; it is waiting on an operator.";
  }

  await configQuery(
    `INSERT INTO app_template
        (account_id, product, name, body, enabled, status, requested_by, request_note,
         requested_tlvs, system_id, requested_by_user_id)
     VALUES ($1, $2, $3, $4, true, 'PENDING', $1, $5, $6, $7, $8)`,
    [input.accountId, input.product, input.name, input.body, input.requestNote,
      input.requestedTlvs, input.systemId, input.userId]
  );
  return null;
}

/**
 * What counts as a change worth re-approving, written once so the four `CASE`s cannot disagree.
 *
 * <p>`requested_tlvs` is deliberately absent from both. That is the whole point of the column.
 */
const HEADER_SUSPENDS =
  "(b.header IS DISTINCT FROM $2::text OR b.request_note IS DISTINCT FROM $3::text "
  + "OR b.system_id IS DISTINCT FROM $5::text)";

const TEMPLATE_SUSPENDS =
  "(b.name IS DISTINCT FROM $2::text OR b.body IS DISTINCT FROM $3::text "
  + "OR b.request_note IS DISTINCT FROM $4::text OR b.system_id IS DISTINCT FROM $6::text)";

/**
 * Edits a row the customer owns, and puts it back in the queue -- unless all they changed was the
 * TLVs they are proposing.
 *
 * <p>The status reset is the point rather than a side effect. Leaving an edited row `APPROVED` would
 * let a customer change the wording under an approval an operator gave to something else, which is
 * the whole thing approval exists to stop. `reviewed_by`, `reviewed_at` and `review_note` are
 * cleared with it: a stale rejection reason sitting beside a fresh request reads as though the new
 * one had been refused.
 *
 * <p><strong>A TLV proposal is the one exception, and it is safe for one specific reason:</strong>
 * `requested_tlvs` is read by nothing on the message path. Nothing the gateway serves changes, so
 * there is nothing to re-approve and no reason to take a working registration out of service while
 * an operator considers it. Changing the wording *and* proposing TLVs in one save still suspends --
 * that is the wording's rule applying, not the proposal's.
 *
 * <p>The comparison is made in SQL rather than by the caller, so there is no read-then-write window
 * in which two saves could interleave. It goes through a CTE rather than referencing the columns
 * directly, and that detail is load bearing: on the right-hand side of a `SET` a column reads as it
 * was before the statement, but in `RETURNING` the same expression reads the row **after** — so a
 * bare `header IS DISTINCT FROM $2` would be correct in the `CASE` and always false in the
 * `RETURNING`. The CTE holds the old row for both.
 *
 * @returns whether the row was taken out of service, so the caller can say which of the two rules
 *     applied rather than describing both and leaving the customer to work it out
 */
export async function updateOwnHeader(
  id: number,
  header: string,
  requestNote: string | null,
  requestedTlvs: string | null,
  systemId: string | null
): Promise<boolean> {
  const rows = await configQuery<{ suspended: boolean }>(
    `WITH b AS (SELECT id, header, request_note, system_id FROM app_header WHERE id = $1)
     UPDATE app_header AS h
        SET header = $2,
            request_note = $3,
            requested_tlvs = $4,
            system_id = $5,
            status = CASE WHEN ${HEADER_SUSPENDS} THEN 'PENDING' ELSE h.status END,
            reviewed_by = CASE WHEN ${HEADER_SUSPENDS} THEN NULL ELSE h.reviewed_by END,
            reviewed_at = CASE WHEN ${HEADER_SUSPENDS} THEN NULL ELSE h.reviewed_at END,
            review_note = CASE WHEN ${HEADER_SUSPENDS} THEN NULL ELSE h.review_note END,
            updated_at = now()
       FROM b
      WHERE h.id = b.id
      RETURNING ${HEADER_SUSPENDS} AS suspended`,
    [id, header, requestNote, requestedTlvs, systemId]
  );
  return rows.length > 0 && rows[0].suspended;
}

export async function updateOwnTemplate(
  id: number,
  name: string | null,
  body: string,
  requestNote: string | null,
  requestedTlvs: string | null,
  systemId: string | null
): Promise<boolean> {
  const rows = await configQuery<{ suspended: boolean }>(
    `WITH b AS (SELECT id, name, body, request_note, system_id FROM app_template WHERE id = $1)
     UPDATE app_template AS t
        SET name = $2,
            body = $3,
            request_note = $4,
            requested_tlvs = $5,
            system_id = $6,
            status = CASE WHEN ${TEMPLATE_SUSPENDS} THEN 'PENDING' ELSE t.status END,
            reviewed_by = CASE WHEN ${TEMPLATE_SUSPENDS} THEN NULL ELSE t.reviewed_by END,
            reviewed_at = CASE WHEN ${TEMPLATE_SUSPENDS} THEN NULL ELSE t.reviewed_at END,
            review_note = CASE WHEN ${TEMPLATE_SUSPENDS} THEN NULL ELSE t.review_note END,
            updated_at = now()
       FROM b
      WHERE t.id = b.id
      RETURNING ${TEMPLATE_SUSPENDS} AS suspended`,
    [id, name, body, requestNote, requestedTlvs, systemId]
  );
  return rows.length > 0 && rows[0].suspended;
}

/**
 * The operator's answer to a TLV proposal.
 *
 * <p>Accepting moves `requested_tlvs` into `tlvs` and clears it; dismissing clears it and leaves
 * `tlvs` exactly as it was. Either way the request stops being outstanding, which is what keeps the
 * operator's queue honest — a proposal that could be silently ignored is a proposal the customer
 * will ask about by email instead.
 *
 * <p>**Neither touches `status`.** The row was approved or it was not, and an operator deciding
 * about stamps is not deciding about the sender ID. Accepting does change what goes on the wire, so
 * it stamps `updated_by`: this is the operator's value now, whoever first typed it.
 *
 * @returns false when there was no proposal to decide, which the route turns into a 409 rather than
 *     reporting a success that changed nothing
 */
export async function decideHeaderTlvs(
  id: number,
  accept: boolean,
  operator: string
): Promise<boolean> {
  const rows = await configQuery<{ id: string }>(
    `UPDATE app_header
        SET tlvs = CASE WHEN $2 THEN requested_tlvs ELSE tlvs END,
            requested_tlvs = NULL,
            updated_by = CASE WHEN $2 THEN $3 ELSE updated_by END,
            updated_at = now()
      WHERE id = $1 AND requested_tlvs IS NOT NULL
      RETURNING id::text`,
    [id, accept, operator]
  );
  return rows.length > 0;
}

export async function decideTemplateTlvs(
  id: number,
  accept: boolean,
  operator: string
): Promise<boolean> {
  const rows = await configQuery<{ id: string }>(
    `UPDATE app_template
        SET tlvs = CASE WHEN $2 THEN requested_tlvs ELSE tlvs END,
            requested_tlvs = NULL,
            updated_by = CASE WHEN $2 THEN $3 ELSE updated_by END,
            updated_at = now()
      WHERE id = $1 AND requested_tlvs IS NOT NULL
      RETURNING id::text`,
    [id, accept, operator]
  );
  return rows.length > 0;
}

export async function withdrawHeader(id: number): Promise<void> {
  await configQuery("DELETE FROM app_header WHERE id = $1", [id]);
}

export async function withdrawTemplate(id: number): Promise<void> {
  await configQuery("DELETE FROM app_template WHERE id = $1", [id]);
}

/**
 * The operator's decision.
 *
 * <p>`REJECTED` keeps the row so the customer can be told why, which is also why the note is
 * required by the route rather than optional here.
 */
export async function reviewHeader(
  id: number,
  status: "APPROVED" | "REJECTED",
  operator: string,
  note: string | null
): Promise<void> {
  await configQuery(
    `UPDATE app_header
        SET status = $2, reviewed_by = $3, reviewed_at = now(), review_note = $4, updated_at = now()
      WHERE id = $1`,
    [id, status, operator, note]
  );
}

export async function reviewTemplate(
  id: number,
  status: "APPROVED" | "REJECTED",
  operator: string,
  note: string | null
): Promise<void> {
  await configQuery(
    `UPDATE app_template
        SET status = $2, reviewed_by = $3, reviewed_at = now(), review_note = $4, updated_at = now()
      WHERE id = $1`,
    [id, status, operator, note]
  );
}

/** The review fields both rows carry, mapped once so the two projections cannot disagree. */
interface ApprovalRow {
  id: string;
  account_id: string;
  product: string;
  tlvs: string | null;
  requested_tlvs: string | null;
  system_id: string | null;
  label: string | null;
  enabled: boolean;
  updated_by: string | null;
  updated_at: string | null;
  status: string;
  requested_by: string | null;
  request_note: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  review_note: string | null;
}

function common(r: ApprovalRow) {
  return {
    id: Number(r.id),
    accountId: r.account_id,
    product: r.product,
    tlvs: r.tlvs,
    requestedTlvs: r.requested_tlvs,
    systemId: r.system_id,
    label: r.label,
    enabled: r.enabled,
    updatedBy: r.updated_by,
    updatedAt: r.updated_at,
    status: r.status as ApprovedHeader["status"],
    requestedBy: r.requested_by,
    requestNote: r.request_note,
    reviewedBy: r.reviewed_by,
    reviewedAt: r.reviewed_at,
    reviewNote: r.review_note,
  };
}

function toHeader(r: ApprovalRow & { header: string }): ApprovedHeader {
  return { ...common(r), header: r.header };
}

function toTemplate(r: ApprovalRow & { name: string | null; body: string }): ApprovedTemplate {
  return { ...common(r), name: r.name, body: r.body };
}

/**
 * The product a customer asked to scope a registration to, proved to be one they actually use.
 *
 * <p>The same reasoning as {@link scopedLogin}, and it had none of it: `product` arrived from the
 * request and went into the column untouched, so a customer could file a registration under any
 * string at all — unbounded in length, and naming a product belonging to somebody else's price
 * list. Neither does anything today, and both are the kind of thing that becomes live the moment
 * something starts matching on it.
 *
 * <p>Checked against the products this account's own **enabled logins** carry, not the platform
 * catalogue: a product nothing of theirs can send under is not one they can sensibly register for,
 * and the catalogue would tell them what other customers buy.
 *
 * <p>Absent or empty means every product, which is what the form offers by default.
 */
export async function scopedProduct(
  accountId: string,
  value: unknown
): Promise<{ value: string } | { error: string }> {
  if (typeof value !== "string" || !value.trim()) {
    return { value: "" };
  }
  const asked = value.trim();
  const rows = await configQuery<{ product: string }>(
    `SELECT DISTINCT product FROM app_credential
      WHERE ${BILLING_KEY} = $1 AND product = $2 AND enabled`,
    [accountId, asked]
  );
  return rows.length
    ? { value: asked }
    : { error: "That is not one of your products." };
}

/**
 * The login a customer asked to scope a registration to, proved to be one of theirs.
 *
 * <p>The value arrives in the request, so it is checked against the account's own logins rather than
 * trusted: without this a customer could bind an approval to a stranger's login name, which would do
 * nothing today and would be a live cross-account grant the moment anything matched on it.
 *
 * <p>Absent, empty and "all" mean every login on the account, which is what every row meant before
 * the column existed and is the default the form offers.
 */
export async function scopedLogin(
  accountIds: string[],
  value: unknown
): Promise<{ value: string | null } | { error: string }> {
  if (typeof value !== "string" || !value.trim()) {
    return { value: null };
  }
  const asked = value.trim();
  const rows = await configQuery<{ system_id: string }>(
    `SELECT system_id FROM app_credential
      WHERE ${BILLING_KEY} = ANY($1) AND system_id = $2 AND enabled`,
    [accountIds, asked]
  );
  return rows.length
    ? { value: asked }
    : { error: "That is not one of your logins." };
}
