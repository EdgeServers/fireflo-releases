import { configQuery } from "@/lib/config-db";
import { assertProductsCatalogued } from "@/lib/products";
import { BILLING_KEY } from "@/lib/billing-key";
import {
  APPROVAL_INSERT,
  APPROVAL_INSERT_TEMPLATE,
  APPROVAL_SET,
  APPROVAL_SET_TEMPLATE,
} from "@/lib/whitelist-sql";
import type {
  ApprovalStatus,
  ApprovedHeader,
  ApprovedTemplate,
  HeaderInput,
  TemplateInput,
  WhitelistMode,
  WhitelistPolicy,
  WhitelistSummary,
} from "@/lib/whitelist-types";

/**
 * The three whitelist tables.
 *
 * <p>Unlike every other catalogue this panel edits, **the gateway reads these and they can refuse
 * traffic**. `app_product`, `app_tlv_definition` and `app_account` are all inert by design; a row
 * written here stops a customer's messages within one configuration poll. Nothing in this module
 * gets to be casual about that, which is why the delete and the mode change are separate operations
 * and why the summary carries counts the UI needs in order to warn before enforcing.
 */

interface PolicyRow {
  account_id: string;
  product: string;
  header_mode: string;
  content_mode: string;
  updated_by: string | null;
  updated_at: string | null;
}

interface HeaderRow {
  id: string;
  account_id: string;
  product: string;
  header: string;
  tlvs: string | null;
  requested_tlvs: string | null;
  system_id: string | null;
  label: string | null;
  enabled: boolean;
  updated_by: string | null;
  updated_at: string | null;
  status: string;
  requested_by: string | null;
  request_note: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  review_note: string | null;
}

interface TemplateRow extends Omit<HeaderRow, "header"> {
  name: string | null;
  body: string;
}

const MODES: readonly string[] = ["OFF", "REPORT", "ENFORCE"];

/** Unknown text becomes OFF, exactly as the gateway's `WhitelistMode.of` does. */
function mode(value: string | null): WhitelistMode {
  const upper = (value ?? "").trim().toUpperCase();
  return (MODES.includes(upper) ? upper : "OFF") as WhitelistMode;
}

export async function listPolicies(): Promise<WhitelistPolicy[]> {
  const rows = await configQuery<PolicyRow>(
    `SELECT account_id, product, header_mode, content_mode, updated_by, updated_at
       FROM app_whitelist_policy
      ORDER BY account_id, product`
  );
  return rows.map((r) => ({
    accountId: r.account_id,
    product: r.product,
    headerMode: mode(r.header_mode),
    contentMode: mode(r.content_mode),
    updatedBy: r.updated_by,
    updatedAt: r.updated_at,
  }));
}

/**
 * Every account that has a policy or an approved row, with its counts.
 *
 * <p>A full outer join across the three tables, because each can mention an account the others do
 * not: a policy with no rows is the fail-closed case, and rows with no policy are the normal state
 * of a catalogue being populated before anyone decides to enforce it.
 *
 * <p>**Only enabled rows are counted**, because only enabled rows are loaded by the gateway. A
 * count that included disabled ones would make an account look safe to enforce when it is not.
 */
export async function listWhitelistSummaries(): Promise<WhitelistSummary[]> {
  const rows = await configQuery<{
    account_id: string;
    product: string;
    header_mode: string | null;
    content_mode: string | null;
    headers: number;
    templates: number;
  }>(
    `WITH scopes AS (
         SELECT account_id, product FROM app_whitelist_policy
         UNION SELECT account_id, product FROM app_header
         UNION SELECT account_id, product FROM app_template
     )
     SELECT s.account_id,
            s.product,
            p.header_mode,
            p.content_mode,
            (SELECT count(*)::int FROM app_header h
               WHERE h.account_id = s.account_id AND h.product = s.product
                 AND h.enabled AND h.status = 'APPROVED') AS headers,
            (SELECT count(*)::int FROM app_template t
               WHERE t.account_id = s.account_id AND t.product = s.product
                 AND t.enabled AND t.status = 'APPROVED') AS templates
       FROM scopes s
       LEFT JOIN app_whitelist_policy p
              ON p.account_id = s.account_id AND p.product = s.product
      ORDER BY s.account_id, s.product`
  );
  return rows.map((r) => ({
    accountId: r.account_id,
    product: r.product,
    headerMode: mode(r.header_mode),
    contentMode: mode(r.content_mode),
    headers: r.headers,
    templates: r.templates,
  }));
}

export async function listHeaders(accountId?: string): Promise<ApprovedHeader[]> {
  const rows = await configQuery<HeaderRow>(
    `SELECT id::text, account_id, product, header, tlvs, requested_tlvs, system_id, label, enabled,
            updated_by, updated_at,
            status, requested_by, request_note, reviewed_by, reviewed_at, review_note
       FROM app_header
      WHERE $1::text IS NULL OR account_id = $1
      ORDER BY account_id, product, lower(header)`,
    [accountId ?? null]
  );
  return rows.map((r) => ({
    id: Number(r.id),
    accountId: r.account_id,
    product: r.product,
    header: r.header,
    tlvs: r.tlvs,
    requestedTlvs: r.requested_tlvs,
    systemId: r.system_id,
    label: r.label,
    enabled: r.enabled,
    updatedBy: r.updated_by,
    updatedAt: r.updated_at,
    status: r.status as ApprovalStatus,
    requestedBy: r.requested_by,
    requestNote: r.request_note,
    reviewedBy: r.reviewed_by,
    reviewedAt: r.reviewed_at,
    reviewNote: r.review_note,
  }));
}

export async function listTemplates(accountId?: string): Promise<ApprovedTemplate[]> {
  const rows = await configQuery<TemplateRow>(
    `SELECT id::text, account_id, product, name, body, tlvs, requested_tlvs, system_id, label, enabled,
            updated_by, updated_at,
            status, requested_by, request_note, reviewed_by, reviewed_at, review_note
       FROM app_template
      WHERE $1::text IS NULL OR account_id = $1
      ORDER BY account_id, product, id`,
    [accountId ?? null]
  );
  return rows.map((r) => ({
    id: Number(r.id),
    accountId: r.account_id,
    product: r.product,
    name: r.name,
    body: r.body,
    tlvs: r.tlvs,
    requestedTlvs: r.requested_tlvs,
    systemId: r.system_id,
    label: r.label,
    enabled: r.enabled,
    updatedBy: r.updated_by,
    updatedAt: r.updated_at,
    status: r.status as ApprovalStatus,
    requestedBy: r.requested_by,
    requestNote: r.request_note,
    reviewedBy: r.reviewed_by,
    reviewedAt: r.reviewed_at,
    reviewNote: r.review_note,
  }));
}

export async function saveHeader(input: HeaderInput, operator: string): Promise<void> {
  //'' is "any product" and passes; a named one must be in the catalogue (gateway V1.56.0)
  await assertProductsCatalogued([input.product]);
  const values = [
    input.accountId.trim(),
    (input.product ?? "").trim(),
    input.header.trim(),
    input.tlvs?.trim() || null,
    input.label?.trim() || null,
    //ticking Approved is what puts a row in service, so it decides `enabled` too. Unticking is the
    //withdrawal: enabled false, status left exactly as it was
    input.approved,
    operator,
    //null, not "", so the column matches what "every login on the account" means everywhere else
    input.systemId?.trim() || null,
  ];
  if (input.id) {
    await configQuery(
      `UPDATE app_header
          SET account_id = $1, product = $2, header = $3, tlvs = $4, label = $5, enabled = $6,
              updated_by = $7, system_id = $8, updated_at = now(),
              ${APPROVAL_SET}
        WHERE id = $9`,
      [...values, input.id]
    );
    return;
  }
  //the natural key is case-insensitive, so an id typed in a different case updates the existing row
  //rather than colliding with it -- which is the same thing the gateway would see.
  //
  //The conflict target has to name COALESCE(system_id, '') exactly as the index does, or PostgreSQL
  //cannot infer which index this means and the insert fails outright. That is also what makes two
  //logins able to approve the same sender ID rather than the second one overwriting the first
  await configQuery(
    `INSERT INTO app_header
        (account_id, product, header, tlvs, label, enabled, updated_by, system_id,
         status, reviewed_by, reviewed_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, ${APPROVAL_INSERT})
     ON CONFLICT (account_id, product, COALESCE(system_id, ''), lower(header))
     DO UPDATE SET header = EXCLUDED.header, tlvs = EXCLUDED.tlvs, label = EXCLUDED.label,
                   enabled = EXCLUDED.enabled, updated_by = EXCLUDED.updated_by, updated_at = now(),
                   ${APPROVAL_SET}`,
    values
  );
}

export async function saveTemplate(input: TemplateInput, operator: string): Promise<void> {
  await assertProductsCatalogued([input.product]);
  const values = [
    input.accountId.trim(),
    (input.product ?? "").trim(),
    input.name?.trim() || null,
    input.body.trim(),
    input.tlvs?.trim() || null,
    input.label?.trim() || null,
    input.approved,
    operator,
    input.systemId?.trim() || null,
  ];
  if (input.id) {
    await configQuery(
      `UPDATE app_template
          SET account_id = $1, product = $2, name = $3, body = $4, tlvs = $5, label = $6,
              enabled = $7, updated_by = $8, system_id = $9, updated_at = now(),
              ${APPROVAL_SET_TEMPLATE}
        WHERE id = $10`,
      [...values, input.id]
    );
    return;
  }
  await configQuery(
    `INSERT INTO app_template
        (account_id, product, name, body, tlvs, label, enabled, updated_by, system_id,
         status, reviewed_by, reviewed_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, ${APPROVAL_INSERT_TEMPLATE})`,
    values
  );
}

export async function deleteHeader(id: number): Promise<boolean> {
  const rows = await configQuery<{ id: string }>(
    "DELETE FROM app_header WHERE id = $1 RETURNING id::text",
    [id]
  );
  return rows.length > 0;
}

export async function deleteTemplate(id: number): Promise<boolean> {
  const rows = await configQuery<{ id: string }>(
    "DELETE FROM app_template WHERE id = $1 RETURNING id::text",
    [id]
  );
  return rows.length > 0;
}

/**
 * Sets one scope's enforcement modes.
 *
 * <p>Separate from the row editors deliberately. Approving a sender ID is additive and safe; moving
 * a scope to ENFORCE can stop a customer sending within thirty seconds, and the two should not share
 * a Save button.
 */
export async function savePolicy(
  accountId: string,
  product: string,
  headerMode: WhitelistMode,
  contentMode: WhitelistMode,
  operator: string
): Promise<void> {
  await assertProductsCatalogued([product]);
  await configQuery(
    `INSERT INTO app_whitelist_policy
            (account_id, product, header_mode, content_mode, updated_by)
     VALUES ($1, $2, $3, $4, $5)
     ON CONFLICT (account_id, product)
     DO UPDATE SET header_mode = EXCLUDED.header_mode, content_mode = EXCLUDED.content_mode,
                   updated_by = EXCLUDED.updated_by, updated_at = now()`,
    [accountId.trim(), (product ?? "").trim(), headerMode, contentMode, operator]
  );
}

/**
 * Every scope one account has, for the enforcement guard and the account page.
 *
 * <p>All of them, deliberately, and not the one scope being edited. The gateway merges a product
 * scope over the account's any-product scope, so the question "may this account enforce" cannot be
 * answered from a single row — `enforcementReadiness` needs the whole set. Asking for one row is
 * what produced a refusal for a configuration that runs.
 *
 * <p>Filtered from `listWhitelistSummaries` rather than given its own aggregate, because a second
 * query would be a second definition of "approved" and the bug this replaces was three definitions
 * disagreeing.
 */
export async function getAccountSummaries(accountId: string): Promise<WhitelistSummary[]> {
  const all = await listWhitelistSummaries();
  return all.filter((s) => s.accountId === accountId);
}

/**
 * Products whose traffic is not checked at all.
 *
 * <p>The same statement `DbWhitelistLoader` uses, copied rather than approximated: the gateway
 * returns `AccountWhitelist.OFF` for these before any merge, so an approval filed under one protects
 * nothing. A guard that counted them would pass an account whose approvals are entirely inert.
 */
export async function listExemptProducts(): Promise<string[]> {
  const rows = await configQuery<{ name: string }>(
    "SELECT name FROM app_product WHERE enabled AND NOT whitelist_enabled"
  );
  return rows.map((r) => r.name);
}

/**
 * Why this login cannot hold this account's approval, or null.
 *
 * <p>The operator's twin of `scopedLogin` on the customer side. The value arrives in a request body,
 * so it is proved against the account's own credentials rather than trusted — a registration bound
 * to a login belonging to somebody else would do nothing today and would be a cross-account grant
 * the moment anything matched on it.
 *
 * <p>Underneath this the gateway is safe anyway: it matches `system_id` only within that account's
 * own whitelist scope, so a foreign name matches nothing rather than matching its real owner. This
 * is the layer that stops the row being written in the first place, so nobody has to rely on that.
 *
 * <p>Empty means every login on the account and is always allowed.
 */
export async function loginOutsideAccount(
  accountId: string,
  systemId: string | null | undefined
): Promise<string | null> {
  const asked = (systemId ?? "").trim();
  if (!asked) {
    return null;
  }
  const rows = await configQuery<{ system_id: string }>(
    `SELECT system_id FROM app_credential
      WHERE ${BILLING_KEY} = $1 AND system_id = $2 AND enabled`,
    [accountId.trim(), asked]
  );
  return rows.length
    ? null
    : `'${asked}' is not a login on ${accountId.trim()}. A registration can only be scoped to a `
      + "login the account owns.";
}
