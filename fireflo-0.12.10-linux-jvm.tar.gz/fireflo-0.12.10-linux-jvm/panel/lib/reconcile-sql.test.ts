import { strict as assert } from "node:assert";
import { test } from "node:test";

import {
  CONSUMED_ALL_SQL,
  CONSUMED_SQL,
  CREDITED_ALL_SQL,
  CREDITED_SQL,
  MISSING_ROLLUP_SQL,
} from "./reconcile-sql.ts";

/**
 * Test plan M14.4, M14.5, M14.6, M14.7.
 *
 * <p>These four cases are properties of the SQL, not of `reconcile()`, and running them properly
 * needs a PostgreSQL container. Until that exists, assert the query TEXT — which is weaker than
 * executing it but catches the change that actually happens: somebody adding an entry type to the
 * IN list, or dropping the anti-join that keeps the two consumption sources disjoint.
 *
 * <p>Replace these with container tests when one is available; do not add to them.
 */

const norm = (sql: string) => sql.replace(/\s+/g, " ").trim();

test("M14.4/M14.5 credited counts RECHARGE and TRANSFER, and nothing else", () => {
  const sql = norm(CREDITED_SQL);
  assert.match(sql, /entry_type = 'RECHARGE'/, "a top-up credits the account it names");
  assert.match(sql, /entry_type = 'TRANSFER'/, "and a transfer moves money between two");

  //the exclusions, named individually so a failure says which one crept back in
  for (const excluded of ["RESERVE", "RELEASE", "BILL"]) {
    assert.doesNotMatch(sql, new RegExp(`'${excluded}'`),
      `${excluded} must not be counted as credit: RESERVE/RELEASE net to zero against `
      + "balance + reserved, and BILL moves nothing. Including one makes every account look "
      + "wrong by a predictable amount, which reads as a real finding");
  }
});

test("B1 a transfer is counted from both ends, with opposite signs", () => {
  //THE BUG THIS PINS. /api/mis/transfer writes ONE row for a transfer: account_id is the payer,
  //counterparty_account_id is the payee, delta is always positive. The gateway reads it that way
  //and moves the money accordingly. This query used to filter on account_id alone and sum delta
  //regardless of direction, so counterparty_account_id appeared nowhere in the panel outside the
  //INSERT. The payer was counted +X while its balance went -X (drift +2X, "creditLost"), and the
  //payee was counted nothing while its balance went +X (drift -X, "creditMinted"). I1 therefore
  //failed on any account that had ever transferred, and a reseller funding a child was told the
  //child held credit nobody had put in -- about money the reseller had itself just sent.
  const sql = norm(CREDITED_SQL);

  assert.match(sql, /counterparty_account_id = \$1/,
    "the payee's side of a transfer must be counted at all -- this column was referenced nowhere "
    + "in the panel outside the INSERT that writes it");
  assert.match(sql, /SELECT applied, -delta FROM balance_ledger WHERE account_id = \$1 AND entry_type = 'TRANSFER'/,
    "the payer's own transfer is money LEAVING, so it is negative here");
  assert.match(sql, /SELECT applied, delta FROM balance_ledger WHERE counterparty_account_id = \$1 AND entry_type = 'TRANSFER'/,
    "and the payee's is money arriving, so it is positive");
});

test("B1 the outgoing and incoming arms cannot both catch one row", () => {
  //the arms are disjoint by schema rather than by hope: balance_ledger_transfer_not_self forbids
  //account_id = counterparty_account_id, so no transfer is ever both sides of itself. Asserted
  //here because the day that constraint is relaxed, this query silently starts counting a
  //self-transfer twice and the identity it exists to check reports the gap it just created
  const sql = norm(CREDITED_SQL);
  assert.match(sql, /WHERE account_id = \$1 AND entry_type = 'TRANSFER'/);
  assert.match(sql, /WHERE counterparty_account_id = \$1 AND entry_type = 'TRANSFER'/);
  assert.doesNotMatch(sql, /OR counterparty_account_id/,
    "the two directions are separate arms with separate signs, never one predicate");
});

test("M14.6 credited splits applied from pending, and only applied is money that arrived", () => {
  //both halves are COALESCEd, so an account with no ledger rows at all reads 0/0 rather than
  //NULL -- a NULL here would poison the residual arithmetic downstream instead of reporting zero
  const sql = norm(CREDITED_SQL);
  assert.match(sql, /COALESCE\(SUM\(signed\) FILTER \(WHERE applied\), 0\) AS credited/);
  assert.match(sql, /COALESCE\(SUM\(signed\) FILTER \(WHERE NOT applied\), 0\) AS pending/);
  //and `applied` is carried from each row rather than assumed, so a pending transfer is pending
  //for BOTH sides -- a payee's credit must never appear before the payer's debit
  assert.equal((sql.match(/SELECT applied,/g) ?? []).length, 3,
    "every arm carries its own row's applied flag");
});

test("M14.7 consumption sources are disjoint by construction, not by hope", () => {
  const sql = norm(CONSUMED_SQL);
  //a rolled-up day usually STILL has its cdr_submit rows -- the purge runs long after the rollup.
  //Summing both without this anti-join double-counts the whole retention window
  assert.match(sql, /NOT EXISTS/, "the tail must exclude days usage_daily already covers");
  assert.match(sql, /FROM usage_daily u/);
  assert.match(sql, /u\.day = \(s\.submitted_at AT TIME ZONE \$2\)::date/);
});

test("B5 the anti-join is at the summary's grain, which includes product", () => {
  //usage_daily is keyed (account_id, day, product). Correlating on (account_id, day) alone made a
  //day with one product's line read as fully covered, so a second product's traffic arriving on
  //that day afterwards was absent from `rolled` AND excluded from `tail` -- consumption silently
  //undercounted. The gateway's purge interlock had the same confusion pointing the other way.
  assert.match(norm(CONSUMED_SQL), /u\.product = COALESCE\(s\.product, ''\)/,
    "the tail may only skip a day for the product usage_daily actually covers");
});

test("M14.7 consumption counts part 1 only, so a concatenated message is not multiplied", () => {
  assert.match(norm(CONSUMED_SQL), /s\.part_no = 1/);
});

test("M14.7 the tail and the rollup bucket days in the same zone", () => {
  //a different zone in either place slices the seam differently and leaves a sliver counted twice
  //or not at all. Both must take it from the same parameter
  for (const sql of [CONSUMED_SQL, MISSING_ROLLUP_SQL]) {
    assert.match(norm(sql), /AT TIME ZONE \$2/);
  }
});

test("M14 the reconciliation queries read and never write", () => {
  //the module's own doc: posting an adjusting entry for the residual is the one thing this feature
  //must never do. The cheapest structural form of that promise
  for (const sql of [CONSUMED_SQL, CREDITED_SQL, MISSING_ROLLUP_SQL]) {
    for (const verb of ["INSERT", "UPDATE", "DELETE", "MERGE", "TRUNCATE"]) {
      assert.doesNotMatch(norm(sql).toUpperCase(), new RegExp(`\\b${verb}\\b`),
        `${verb} has no place in a reconciliation query`);
    }
  }
});

test("F15 the grouped consumption restates the per-account arithmetic, fragment for fragment", () => {
  //CONSUMED_SQL is the authority; the grouped variant must carry the same load-bearing pieces or
  //the platform page and the account page disagree about the same account
  const grouped = norm(CONSUMED_ALL_SQL);
  assert.match(grouped, /s\.part_no = 1/, "part 1 only, or concatenated messages multiply");
  assert.match(grouped, /u\.product = COALESCE\(s\.product, ''\)/,
    "the anti-join must stay at the (account, day, product) grain");
  assert.match(grouped, /NOT EXISTS/, "dropping the anti-join double counts the retention window");
  assert.match(grouped, /AT TIME ZONE \$1/, "the tail must slice days in the caller's zone");
});

test("F15 the grouped credit keeps all three transfer arms with their signs", () => {
  const grouped = norm(CREDITED_ALL_SQL);
  assert.match(grouped, /entry_type = 'RECHARGE'/);
  //the payer arm is negative and the payee arm reads the counterparty column -- the exact shape
  //whose absence was the transfer-direction bug CREDITED_SQL documents
  assert.match(grouped, /-delta/, "the payer's side of a transfer must be negative");
  assert.match(grouped, /counterparty_account_id, applied, delta/,
    "the payee's side must come from the counterparty column");
  assert.doesNotMatch(grouped, /RESERVE|RELEASE|BILL/,
    "including inert entry types would make every account look wrong by a predictable amount");
});

test("F15 the grouped queries read and never write", () => {
  for (const sql of [CONSUMED_ALL_SQL, CREDITED_ALL_SQL]) {
    for (const verb of ["INSERT", "UPDATE", "DELETE", "MERGE", "TRUNCATE"]) {
      assert.doesNotMatch(norm(sql).toUpperCase(), new RegExp(`\\b${verb}\\b`));
    }
  }
});
