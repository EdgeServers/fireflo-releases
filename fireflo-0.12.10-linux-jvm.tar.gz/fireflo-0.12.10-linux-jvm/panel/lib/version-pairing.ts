/**
 * Whether this panel and the gateway it is talking to are the pair they claim to be.
 *
 * <p>The panel's version is a claim about the gateway: its first three numbers **are** a gateway
 * release, by the scheme in the README, and a fourth number is a panel-only revision on top of it.
 * Until the gateway published its own version that claim was unverifiable from either side — a
 * panel built for one release talking to another looked exactly like a matched pair, and the number
 * beside the wordmark answered a question nobody could check.
 *
 * <p>Database-free so the check is one function rather than one per surface.
 */

export type PairingVerdict =
  /** The first three numbers agree. */
  | "matched"
  /** They do not, and both are known. */
  | "mismatched"
  /** The gateway did not say, so there is nothing to compare. */
  | "unknown";

export interface VersionPairing {
  verdict: PairingVerdict;
  panel: string;
  gateway: string | null;
  /** What to tell the operator, or null when there is nothing worth saying. */
  message: string | null;
}

/**
 * The first three numbers, which is the part that has to agree.
 *
 * <p>Tolerates the product name the gateway prefixes ("FireFlo 0.5.0"), and both spellings the
 * panel uses for its own version — `0.4.1+1` in `package.json`
 * because npm requires valid semver, and `0.4.1.1` on screen — since this is called with each in
 * different places and a comparison that understood only one would silently never match.
 */
export function gatewayRelease(version: string | null | undefined): string | null {
  const trimmed = (version ?? "").trim();
  if (!trimmed) {
    return null;
  }
  //The gateway reports "FireFlo 0.5.0" so a version read out of context still says what it is a
  //version of. Everything before the last space goes, which also covers a future rename without
  //this needing to know the product's name.
  //
  //Getting this wrong is silent: an unparsed version returns null, the verdict degrades to
  //"unknown", and the mismatch warning simply stops appearing -- which looks exactly like a
  //correctly matched pair.
  const numeric = trimmed.slice(trimmed.lastIndexOf(" ") + 1);
  //everything up to the fourth separator, whichever spelling produced it
  const parts = numeric.replace("+", ".").split(".");
  if (parts.length < 3) {
    return null;
  }
  const first = parts.slice(0, 3);
  return first.every((p) => /^\d+$/.test(p)) ? first.join(".") : null;
}

/**
 * Compares the pair and says what is wrong in the operator's terms.
 *
 * <p>**Silent unless something is actually wrong.** A matched pair says nothing, and so does a
 * gateway too old to report a version — that is not a fault, it is a gateway from before the field
 * existed, and warning about it would train people to ignore the warning that matters.
 */
export function versionPairing(
  panelVersion: string,
  gatewayVersion: string | null | undefined
): VersionPairing {
  const panel = gatewayRelease(panelVersion);
  const gateway = gatewayRelease(gatewayVersion);

  if (!gateway) {
    return {
      verdict: "unknown",
      panel: panelVersion,
      gateway: gatewayVersion?.trim() || null,
      message: null,
    };
  }
  if (panel && panel === gateway) {
    return { verdict: "matched", panel: panelVersion, gateway: gatewayVersion!.trim(), message: null };
  }
  return {
    verdict: "mismatched",
    panel: panelVersion,
    gateway: gatewayVersion!.trim(),
    message:
      `This panel was built for gateway ${panel ?? panelVersion} and is talking to ${gateway}. `
      + "The two are deployed together and read the same schema, so a mismatch usually means one "
      + "of them did not get updated — check which, rather than trusting either screen.",
  };
}
