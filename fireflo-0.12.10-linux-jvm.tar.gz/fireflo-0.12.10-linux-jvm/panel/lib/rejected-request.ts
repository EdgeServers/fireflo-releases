import type { RejectedRow, RejectedSummary } from "./rejected-types";
//with the extension, because `node --test` runs these modules directly and does not read tsconfig
//paths or resolve extensionless specifiers. The type-only import above is erased and needs neither
import { MAX_TEXT_FILTER, RANGES } from "./cdr-request.ts";

/**
 * A refusal filter set as it travels: query string in, query string out.
 *
 * <p><b>This module must never import `rejected.ts`</b>, and the dependency runs that way for the
 * reason `cdr-request.ts` states at length: `rejected.ts` opens a database pool, so a client
 * component reaching in for the filter vocabulary would pull `pg` into the browser bundle — and the
 * symptom is not a scoped error but every page returning 500 at once.
 *
 * <p><strong>The period vocabulary is imported from `cdr-request.ts` rather than redefined.</strong>
 * "Last 7 days" has to mean the same thing on Messages and on Refused, and the surest way to keep two
 * pages agreeing on that is for there to be one list. Nothing else is shared: the two tables have
 * almost no columns in common.
 *
 * <p>The vocabulary of refusals themselves — labels, hints, vendor mnemonics — stays in
 * `rejected-types.ts`, which the diagnosis engine imports and which has no business knowing what a
 * query string is.
 */

/** What the query layer takes. Dates here, strings on the wire. */
export interface RejectedFilters {
  since?: Date | null;
  until?: Date | null;
  /**
   * The gateway's own token, matched exactly and **not validated against a known set**.
   *
   * <p>Unlike an outcome, which this product writes, a reason is written by the gateway. Validating
   * it would 400 the page the first time a new token appeared — and the link that produced it comes
   * from the Delivery check, which builds `?reason=` from whatever the database contained.
   */
  reason?: string | null;
  accountId?: string | null;
  systemId?: string | null;
  product?: string | null;
  ingress?: string | null;
  inGateway?: string | null;
  /** Prefix-matched, like a phone number on the Messages page. */
  sourceAddr?: string | null;
  destAddr?: string | null;
  gatewayMsgId?: string | null;
  /**
   * Only refusals that carry a message id.
   *
   * <p>Which is not the same as `gateway_msg_id IS NOT NULL`. The gateway initialises a message's
   * serial to an empty string and writes it through unchecked, so a refusal at the door usually
   * stores `''` rather than NULL — and the partial index on that column is full of them.
   */
  hasMsgId?: boolean;
  vendorStatus?: number | null;
  /** Only the reasons that happen after the customer was told yes. See {@link REFUSED_AFTER_ACCEPTING}. */
  afterAccepting?: boolean;
  /**
   * Free text, matched case-insensitively against everything the table shows.
   *
   * <p>Deliberately wider than the Messages page's `text`, which is the message body alone. Here the
   * rule is that anything visible is findable, so results are explainable without knowing which
   * columns the reader happens to have chosen.
   */
  search?: string | null;
}

/** The plain-text filters, as [query parameter, filter field]. One list, so the two directions agree. */
const TEXT_FIELDS: [string, keyof RejectedFilters][] = [
  ["reason", "reason"],
  ["account", "accountId"],
  ["systemId", "systemId"],
  ["product", "product"],
  ["ingress", "ingress"],
  ["inGateway", "inGateway"],
  ["source", "sourceAddr"],
  ["dest", "destAddr"],
  ["msgId", "gatewayMsgId"],
  //"q" rather than "text": the Delivery check and the diagnosis findings already link with it, and
  //what it searches is genuinely different from the Messages page's `text` -- see `search` above
  ["q", "search"],
];

/** What the browser holds, before any of it becomes a Date. Every field a string, so one loop serialises it. */
export interface RejectedFilterForm {
  range: string;
  reason: string;
  account: string;
  systemId: string;
  product: string;
  ingress: string;
  inGateway: string;
  source: string;
  dest: string;
  msgId: string;
  vendorStatus: string;
  /** "1" when only refusals carrying a message id are wanted. */
  hasMsgId: string;
  /** "1" when only the refusals that happened after acceptance are wanted. */
  afterAccepting: string;
  q: string;
}

export const EMPTY_REJECTED_FILTERS: RejectedFilterForm = {
  range: "24h",
  reason: "",
  account: "",
  systemId: "",
  product: "",
  ingress: "",
  inGateway: "",
  source: "",
  dest: "",
  msgId: "",
  vendorStatus: "",
  hasMsgId: "",
  afterAccepting: "",
  q: "",
};

/** Whether anything beyond the default window is set — for a "clear filters" button that knows to appear. */
export function hasActiveFilters(form: RejectedFilterForm): boolean {
  return (Object.keys(EMPTY_REJECTED_FILTERS) as (keyof RejectedFilterForm)[]).some(
    (key) => key !== "range" && form[key] !== EMPTY_REJECTED_FILTERS[key]
  );
}

/** Only what is set, so the URL stays readable and a shared link carries exactly the filters chosen. */
export function toQuery(form: RejectedFilterForm): URLSearchParams {
  const params = new URLSearchParams();
  for (const key of Object.keys(EMPTY_REJECTED_FILTERS) as (keyof RejectedFilterForm)[]) {
    const value = form[key];
    if (value && value !== EMPTY_REJECTED_FILTERS[key]) {
      params.set(key, value);
    }
  }
  return params;
}

export function fromQuery(params: URLSearchParams): RejectedFilterForm {
  const form = { ...EMPTY_REJECTED_FILTERS };
  for (const key of Object.keys(EMPTY_REJECTED_FILTERS) as (keyof RejectedFilterForm)[]) {
    const value = params.get(key);
    if (value != null) {
      //safe because every field of RejectedFilterForm is a string
      (form as Record<string, string>)[key] = value;
    }
  }
  //the page this replaced offered three hour-buttons and put the number in `hours`. Links carrying
  //one still exist, and landing on a 24-hour window with the button unhighlighted would read as the
  //link having been ignored
  const hours = params.get("hours");
  if (hours && !params.get("range")) {
    form.range = rangeForHours(Number(hours)) ?? form.range;
  }
  return form;
}

/** The shortcut whose window matches, so a legacy `?hours=` link lights up the right button. */
function rangeForHours(hours: number): string | null {
  if (!Number.isFinite(hours) || hours <= 0) {
    return null;
  }
  return Object.keys(RANGES).find((key) => RANGES[key] === hours) ?? null;
}

/**
 * Query string to database filters, or a message saying why not.
 *
 * <p>Rejects rather than falls back, for the reason `parseFilters` gives: a filter silently ignored
 * shows rows under a heading claiming something they are not, which is the kind of wrong that gets
 * believed. The one deliberate exception is `reason` — see {@link RejectedFilters.reason}.
 *
 * @param now injected so the export worker can pin the window to when the request was made, rather
 *     than sliding it every time a batch runs and re-reading rows it already wrote
 */
export function parseRejectedFilters(
  params: URLSearchParams,
  now: Date = new Date()
): RejectedFilters | { error: string } {
  const filters: RejectedFilters = {};

  const explicitRange = params.get("range");
  const legacyHours = params.get("hours");
  if (explicitRange != null && !(explicitRange in RANGES)) {
    return {
      error: `Unknown range '${explicitRange}'. Expected one of ${Object.keys(RANGES).join(", ")}.`,
    };
  }
  if (explicitRange == null && legacyHours != null) {
    //the retired parameter, still honoured: unlike `range` it was a free number, so any positive
    //value is a window rather than only the four the buttons offered
    const hours = Number(legacyHours);
    if (!Number.isFinite(hours) || hours < 0) {
      return { error: `'hours' is not a number of hours.` };
    }
    if (hours > 0) {
      filters.since = new Date(now.getTime() - hours * 3_600_000);
    }
  } else {
    const hours = RANGES[explicitRange ?? "24h"];
    if (hours > 0) {
      filters.since = new Date(now.getTime() - hours * 3_600_000);
    }
  }

  //an explicit window beats the shortcut, which is how a link to a specific incident stays pinned
  for (const key of ["since", "until"] as const) {
    const raw = params.get(key);
    if (raw) {
      const at = new Date(raw);
      if (Number.isNaN(at.getTime())) {
        return { error: `'${key}' is not a valid timestamp.` };
      }
      filters[key] = at;
    }
  }

  for (const [param, field] of TEXT_FIELDS) {
    const value = params.get(param)?.trim();
    if (value && value.length > MAX_TEXT_FILTER) {
      return { error: `'${param}' is longer than ${MAX_TEXT_FILTER} characters.` };
    }
    if (value) {
      //assigning through a narrowed record: every one of these fields is `string | null | undefined`
      (filters as Record<string, unknown>)[field] = value;
    }
  }

  const vendorStatus = params.get("vendorStatus")?.trim();
  if (vendorStatus) {
    //refused rather than ignored: an SMPP status is a number, and "0x45" typed into a box expecting
    //69 would otherwise silently return every refusal in the window
    if (!/^\d+$/.test(vendorStatus)) {
      return { error: `'vendorStatus' must be a decimal SMPP status, e.g. 69 for ESME_RSUBMITFAIL.` };
    }
    filters.vendorStatus = Number(vendorStatus);
  }

  if (params.get("hasMsgId") === "1") {
    filters.hasMsgId = true;
  }
  if (params.get("afterAccepting") === "1") {
    filters.afterAccepting = true;
  }
  return filters;
}

export function isRejectedFilterError(
  value: RejectedFilters | { error: string }
): value is { error: string } {
  return "error" in value;
}

/**
 * The last row of a page, as the next page's starting point.
 *
 * <p>Here rather than beside the query for the reason at the top of this file: the table component
 * needs the shape and cannot reach into `rejected.ts` for it.
 */
export interface RejectedCursor {
  rejectedAt: string;
  id: string;
}

/**
 * What the route answers with.
 *
 * <p>`summary` and `total` describe the **window**, not the page, and are present only on a request
 * with no cursor — recomputing an aggregate per page would both double the database work and let the
 * counts visibly shift under a reader who is only turning pages.
 */
export interface RejectedPage {
  rows: RejectedRow[];
  nextCursor: RejectedCursor | null;
  summary?: RejectedSummary[];
  /** Total in the window, so the page can say "50 of 1,204" rather than implying 50 is all of it. */
  total?: number;
  /** Of that total, how many carry the reason currently selected. Absent when none is. */
  matching?: number;
}
