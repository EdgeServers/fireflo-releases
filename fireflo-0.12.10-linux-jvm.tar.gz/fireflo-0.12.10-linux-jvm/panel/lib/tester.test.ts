import { test } from "node:test";
import assert from "node:assert/strict";
import { deciding, destinationCondition, neverRunsIn, nextTable, prefillFrom, prefillParams, suggestPrefix, vendorOf } from "./tester.ts";

test("a suggestion starts from the country code as typed, '+' kept", () => {
  assert.equal(suggestPrefix("+447700900123"), "+44");
  assert.equal(suggestPrefix("919812345678"), "91");
  assert.equal(suggestPrefix("+14155550100"), "+1");
  assert.equal(suggestPrefix("0091 98123"), "91");
  assert.equal(suggestPrefix(""), "");
});

test("the pre-fill survives the round trip through the address", () => {
  const condition = destinationCondition("+447700900123");
  const params = new URLSearchParams(prefillParams(condition, { product: "sms" }));
  assert.equal(params.get("new"), "1");
  assert.equal(params.get("product"), "sms");
  assert.deepEqual(prefillFrom(params), { field: "to", operator: "startsWith", value: "+44", negate: false });
  assert.equal(prefillFrom(new URLSearchParams("new=1")), null);
});

test("routing is followed into another table, and a client worker is the vendor", () => {
  assert.equal(nextTable("MESSAGE", ["default", "MESSAGE"]), "MESSAGE");
  assert.equal(nextTable("smppclient.smppsim", ["default", "MESSAGE"]), null);
  assert.equal(vendorOf("smppclient.smppsim"), "smppclient.smppsim");
  assert.equal(vendorOf("smppsim"), "smppsim", "rules usually name a vendor by its short name");
  assert.equal(vendorOf("smppserver.smpp"), null);
  assert.equal(vendorOf("@dnd"), null);
  assert.equal(vendorOf("MESSAGE", ["MESSAGE"]), null);
});

test("a matching preprocessor rule runs and the scan carries on, as the router does", () => {
  const rules = [
    { index: 1, target: "@tlv", matched: false, evaluable: true },
    { index: 2, target: "@dnd", matched: true, evaluable: true },
    { index: 3, target: "smppsim", matched: true, evaluable: true },
  ];
  assert.equal(deciding(rules)?.index, 3);
  assert.equal(deciding(rules.slice(0, 2)), null);
});


test("a 'used by' line in a table nothing reaches is picked out", () => {
  assert.equal(neverRunsIn("routing: sample · rule 1014", ["sample"]), "sample");
  assert.equal(neverRunsIn("routing: MESSAGE · india", ["sample"]), null);
  assert.equal(neverRunsIn("price: Default · transactional", ["Default"]), null);
});
