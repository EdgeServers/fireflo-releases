import { test } from "node:test";
import assert from "node:assert/strict";
import { BUILTIN_REGISTRY, registryFrom, isSecretWorkerKey, type ConfigKeyRow } from "./config-key-registry.ts";
import { GATEWAY_SETTING_FIELDS } from "./gateway-setting-fields.ts";
import { SETTING_FIELDS } from "./setting-fields.ts";
import { judgeGatewayKey, isReadable } from "./gateway-key-policy.ts";

test("every catalogued key is in the registry, with the catalogue's kind, choices and default", () => {
  for (const f of GATEWAY_SETTING_FIELDS) {
    const row = BUILTIN_REGISTRY.platform.get(f.key);
    assert.ok(row, `${f.key} is catalogued but not in the registry`);
    assert.equal(row.kind, f.widget.kind, f.key);
    assert.equal(row.codedDefault, f.codedDefault, f.key);
    if (f.widget.kind === "enum") {
      assert.deepEqual(row.choices, f.widget.options.map((o) => o.value), f.key);
    }
  }
  for (const [key, f] of Object.entries(SETTING_FIELDS)) {
    const row = BUILTIN_REGISTRY.worker.get(key);
    assert.ok(row, `${key} is catalogued but not in the registry`);
    assert.equal(row.kind, f.widget.kind, key);
    assert.equal(row.secret, f.widget.kind === "secret", key);
  }
});

test("the registry keeps app_config_key's own rules: a secret is hidden, a denial has a reason", () => {
  for (const r of BUILTIN_REGISTRY.rows) {
    if (r.secret) assert.equal(r.access, "hidden", `${r.scope}:${r.key}`);
    assert.equal(r.access === "editable", r.reason === null, `${r.scope}:${r.key}`);
    assert.equal(r.kind === "enum", r.choices !== null, `${r.scope}:${r.key}`);
  }
});

test("the built-in registry reproduces the denials the code used to hold", () => {
  assert.deepEqual(judgeGatewayKey("smsg.queue.amqp.uri"), { allowed: false, reason: "secret" });
  assert.deepEqual(judgeGatewayKey("smsg.cdr.sink"), { allowed: false, reason: "wiring" });
  assert.deepEqual(judgeGatewayKey("smsg.billing.zone"), { allowed: false, reason: "elsewhere" });
  assert.equal(judgeGatewayKey("smsg.whitelist.enabled").allowed, true);
  assert.equal(isSecretWorkerKey(BUILTIN_REGISTRY, "password"), true);
  assert.equal(isSecretWorkerKey(BUILTIN_REGISTRY, "host"), false);
});

test("a registry read from the database decides, beyond what the code knew", () => {
  //a key whose name says nothing, made a secret by the table -- the case the table exists for
  const extra: ConfigKeyRow = {
    scope: "platform", key: "smsg.partner.endpoint", kind: "text", choices: null, unit: null,
    codedDefault: null, secret: true, access: "hidden", reason: "secret", label: "Partner endpoint",
  };
  const worker: ConfigKeyRow = {
    scope: "worker", key: "bind.code", kind: "secret", choices: null, unit: null,
    codedDefault: null, secret: true, access: "hidden", reason: "secret", label: "Bind code",
  };
  const db = registryFrom([...BUILTIN_REGISTRY.rows, extra, worker], "database");

  assert.equal(judgeGatewayKey("smsg.partner.endpoint").allowed, true, "the code alone allows it");
  assert.deepEqual(judgeGatewayKey("smsg.partner.endpoint", db), { allowed: false, reason: "secret" });
  assert.equal(isReadable("smsg.partner.endpoint", db), false, "a secret is not shown");
  //a worker secret is a secret as a gateway-wide default too
  assert.deepEqual(judgeGatewayKey("outSms.default.bind.code", db), { allowed: false, reason: "secret" });
  assert.equal(isSecretWorkerKey(db, "bind.code"), true);
});

test("the name rule still decides for a key no registry lists", () => {
  const empty = registryFrom([], "database");
  assert.deepEqual(judgeGatewayKey("smsg.vendor.api_key", empty), { allowed: false, reason: "secret" });
});
