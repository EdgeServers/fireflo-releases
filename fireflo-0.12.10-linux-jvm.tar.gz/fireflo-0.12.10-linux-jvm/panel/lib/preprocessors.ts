import { configQuery } from "@/lib/config-db";
import type { Preprocessor, PreprocessorInput } from "@/lib/preprocessor-types";

/**
 * `app_preprocessor`, read and written. Server-only: importing this pulls `pg`.
 *
 * <p>The table arrives with gateway V1.62.0. Against an older database every read answers
 * "unavailable" rather than failing, so the page can say the gateway needs upgrading instead of
 * showing a database error.
 */

interface Row {
  name: string;
  run: string;
  workers: number;
  timeout_ms: number;
  inflight: number;
  on_error: string;
  fields: string;
  label: string | null;
  enabled: boolean;
  updated_at: Date | null;
}

/** Whether this database has preprocessors at all (gateway 0.12.0, migration V1.62.0). */
export async function preprocessorsAvailable(): Promise<boolean> {
  const rows = await configQuery<{ ok: boolean }>("SELECT to_regclass('public.app_preprocessor') IS NOT NULL AS ok");
  return !!rows[0]?.ok;
}

export async function listPreprocessors(): Promise<Preprocessor[]> {
  const [rows, uses] = await Promise.all([
    configQuery<Row>(
      `SELECT name, run, workers, timeout_ms, inflight, on_error, fields, label, enabled, updated_at
         FROM app_preprocessor ORDER BY name`
    ),
    configQuery<{ name: string; table_name: string; seq: number; enabled: boolean }>(
      `SELECT target_preprocessor AS name, table_name, seq, enabled
         FROM app_route_rule WHERE target_preprocessor IS NOT NULL ORDER BY table_name, seq`
    ),
  ]);
  return rows.map((r) => ({
    name: r.name,
    run: r.run,
    workers: r.workers,
    timeoutMs: r.timeout_ms,
    inflight: r.inflight,
    onError: r.on_error,
    fields: r.fields.split(",").map((f) => f.trim()).filter(Boolean),
    label: r.label,
    enabled: r.enabled,
    updatedAt: r.updated_at ? r.updated_at.toISOString() : null,
    //seq is 0-based in the table and every page shows rules from 1
    usedBy: uses.filter((u) => u.name === r.name).map((u) => ({ table: u.table_name, seq: u.seq + 1, enabled: u.enabled })),
  }));
}

/** Just the names, for the routing rule dialog's target list. */
export async function listPreprocessorNames(): Promise<{ name: string; enabled: boolean; label: string | null }[]> {
  if (!(await preprocessorsAvailable())) {
    return [];
  }
  return configQuery<{ name: string; enabled: boolean; label: string | null }>(
    "SELECT name, enabled, label FROM app_preprocessor ORDER BY name"
  );
}

export async function savePreprocessor(p: PreprocessorInput): Promise<void> {
  await configQuery(
    `INSERT INTO app_preprocessor (name, run, workers, timeout_ms, inflight, on_error, fields, label, enabled, updated_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, now())
     ON CONFLICT (name) DO UPDATE SET
       run = EXCLUDED.run, workers = EXCLUDED.workers, timeout_ms = EXCLUDED.timeout_ms,
       inflight = EXCLUDED.inflight, on_error = EXCLUDED.on_error, fields = EXCLUDED.fields,
       label = EXCLUDED.label, enabled = EXCLUDED.enabled, updated_at = now()`,
    [
      p.name.trim(), p.run.trim(), p.workers, p.timeoutMs, p.inflight, p.onError.trim(),
      (p.fields.length ? p.fields : ["to"]).join(","), p.label?.trim() || null, p.enabled,
    ]
  );
}

/** Thrown when routing rules still send to it, which the V1.62.0 foreign key refuses to orphan. */
export class PreprocessorInUse extends Error {
  constructor(readonly preprocessorName: string) {
    super(`'${preprocessorName}' is still the target of at least one routing rule.`);
    this.name = "PreprocessorInUse";
  }
}

export async function deletePreprocessor(name: string): Promise<boolean> {
  try {
    const rows = await configQuery<{ name: string }>("DELETE FROM app_preprocessor WHERE name = $1 RETURNING name", [name]);
    return rows.length > 0;
  } catch (err) {
    if ((err as { code?: string })?.code === "23503") {
      throw new PreprocessorInUse(name);
    }
    throw err;
  }
}
