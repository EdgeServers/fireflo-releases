import { isMessageRow, messageRows, type GrainOptions } from "./cdr-grain";
import { getBalance } from "@/lib/balance";
import { query } from "@/lib/metrics-db";
import { hasBodyColumn, hasVendorAttempt } from "@/lib/metrics-schema";

/**
 * What the portal's landing page shows a customer about their own traffic.
 *
 * <p>One module, three shapes, one range — a dashboard that fires four requests is four chances to
 * paint half a page, and four places for the range to disagree with itself.
 *
 * <p><strong>Every query here is bounded twice</strong>: by the range, and by the accounts the
 * session may see. The scope arrives from `scopeFor(session)` and is never taken from the request,
 * for the reason `CdrFilters.accountIn` documents — a boundary that a query string can widen is not
 * a boundary.
 *
 * <p>Server-only: importing this pulls `pg`.
 */

/** One day of traffic. `rate` is null on a day with nothing sent, rather than a misleading zero. */
export interface TrafficDay {
  day: string;
  sent: number;
  delivered: number;
  failed: number;
  pending: number;
  /** Delivered as a percentage of those that have an outcome. Null while nothing has resolved. */
  rate: number | null;
}

export interface OutcomeSlice {
  outcome: "delivered" | "failed" | "pending" | "refused";
  messages: number;
}

export interface OverviewTiles {
  sent: number;
  delivered: number;
  /** Delivered over resolved, as a percentage. Null when nothing has resolved yet. */
  rate: number | null;
  /** Scaled by 10 000 like every amount in this schema. */
  spend: number;
  /** Live, not for the period — and null when credit is not enforced for this account. */
  balance: number | null;
  currency: string | null;
}

/**
 * A row in the latest-messages strip.
 *
 * <p>`body` is null on every row unless the gateway is recording content — see `smsg.cdr.body`,
 * which ships off. The strip renders without it; it is a nicety, not the point of the row.
 */
export interface RecentMessage {
  gatewayMsgId: string;
  submittedAt: string;
  destAddr: string | null;
  finalState: string | null;
  body: string | null;
}

/**
 * A message that did not arrive, and what is known about why.
 *
 * <p>A superset of {@link RecentMessage} rather than a variant of it: the two panels sit beside each
 * other and a reader comparing them should be reading the same columns in the same order.
 */
export interface FailedMessage extends RecentMessage {
  /** The raw SMPP receipt state, which `DLR_STATES` in `labels.ts` turns into a sentence. */
  dlrState: number | null;
  /** The vendor's own code. Free-form, vendor-specific, and shown verbatim because it must be. */
  errCode: string | null;
}

export interface Overview {
  tiles: OverviewTiles;
  traffic: TrafficDay[];
  outcomes: OutcomeSlice[];
  recent: RecentMessage[];
  /**
   * The most recent messages that did not arrive.
   *
   * <p>Empty is the good outcome here, and the surface says so — an empty list beside a full one
   * reads as broken unless the page states which it is.
   */
  failed: FailedMessage[];
  /** How many failed in the whole range, so the panel can say "6 of 214" rather than imply 6. */
  failedTotal: number;
  /** True while some of the range has no receipt yet, so the percentages are still moving. */
  settling: boolean;
}

/**
 * The outcome of each message, deduplicated.
 *
 * <p>The same LATERAL the other CDR queries use, and for the same reason: `cdr_final` has no
 * uniqueness constraint, so a plain join counts a message twice the moment two receipts race.
 *
 * <p>It carries `dlr_state` and `err_code` for {@link failedMessages} alone — the aggregates below
 * only ever name `o.final_state`. Selecting three columns rather than one costs nothing here (the
 * lateral runs per row either way) and is what lets a failure say *why* in English: `err_code` is a
 * vendor hex string with no catalogue anywhere, while `dlr_state` resolves through `DLR_STATES` to
 * "Undeliverable" or "The carrier gave up before delivering".
 */
const OUTCOME = `
  LEFT JOIN LATERAL (
    SELECT f.final_state, f.dlr_state, f.err_code
      FROM cdr_final f
     WHERE f.gateway_msg_id = s.gateway_msg_id AND f.part_no = s.part_no
     --A real receipt outranks a swept EXPIRED, whichever landed first: EXPIRED is synthetic,
     --written by the gateway's expiry sweep, and a genuine receipt can still arrive after it
     --because the correlation index outlives the deadline. false sorts before true.
     --SAME RULE IN UsageRollup.java AND THREE OTHER lib/ QUERIES. Change one, change all five.
     ORDER BY (f.final_state = 'EXPIRED'), f.final_at
     LIMIT 1
  ) o ON TRUE`;

/**
 * One message is one row, as UsageRollup.
 *
 * <p>Every vendor attempt is its own `cdr_submit` row and every one of them joins the message's
 * receipt, so a message that failed over once used to read here as two sent and two delivered. The
 * aggregates take `messageRows` -- the rollup's own `DISTINCT ON`, money row first, else the latest
 * attempt -- with the range and the scope inside it. The two short lists take `isMessageRow`, the
 * same choice as a predicate, so they keep their index walk. Neither has a retry term: the accepted
 * attempt is not the first one after a failover. See `lib/cdr-grain.ts`.
 */
async function grain(): Promise<GrainOptions> {
  return { vendorAttempt: await hasVendorAttempt() };
}

/** The range and the account boundary, applied inside the one-row-per-message choice. */
const IN_RANGE_AND_SCOPE =
  "s.submitted_at >= $2 AND s.submitted_at < $3 AND s.account_id = ANY($1)";

/**
 * What the failures panel means by "failed", in one place because two places would drift.
 *
 * <p>**Anything with an outcome that is not `DELIVERED`** — so `FAILED`, `EXPIRED`, `REJECTED` and
 * `DROPPED` together. The donut above keeps its four slices, which distinguish a carrier failing to
 * deliver from us declining to send; the panel deliberately does not, because a panel that shows
 * *some* failures is worse than no panel — a customer whose sender ID started being rejected would
 * look at an empty list and conclude nothing was wrong.
 *
 * <p>`IS NOT NULL` matters: a message with no receipt yet is pending, not failed, and every recent
 * message is pending for a while.
 *
 * <p>Used as a `FILTER` in {@link outcomeTotals} and as a `WHERE` in {@link failedMessages}, so the
 * count above the panel and the rows inside it cannot disagree.
 */
const NOT_DELIVERED = "o.final_state IS NOT NULL AND o.final_state <> 'DELIVERED'";

/** Rows in each dashboard panel. Both the same, so the two cards stand the same height. */
const PANEL_ROWS = 6;

/**
 * @param scope every account this session may see — a reseller's children included
 * @param ownAccountId the session's own account, and the only one whose balance is theirs. Summing
 *     a reseller's children into one figure would answer a question nobody asked; each child's
 *     balance is on its own page
 */
export async function overviewFor(
  scope: string[],
  ownAccountId: string,
  since: Date,
  until: Date
): Promise<Overview> {
  const [traffic, outcomes, tiles, recent, failed] = await Promise.all([
    trafficByDay(scope, since, until),
    outcomeTotals(scope, since, until),
    tilesFor(scope, ownAccountId, since, until),
    recentMessages(scope, since, until),
    failedMessages(scope, since, until),
  ]);

  return {
    tiles,
    traffic,
    outcomes: outcomes.slices,
    recent,
    failed,
    //from the same predicate the rows came from, so "6 of 214" cannot be a lie
    failedTotal: outcomes.notDelivered,
    //said rather than left to be inferred from a rate that keeps climbing: most of today's traffic
    //has no receipt yet at any given moment, and a customer comparing two page loads deserves to
    //know why the number moved
    settling: outcomes.slices.some((o) => o.outcome === "pending" && o.messages > 0),
  };
}

async function trafficByDay(scope: string[], since: Date, until: Date): Promise<TrafficDay[]> {
  const g = await grain();
  //generate_series, not GROUP BY alone: a day with no traffic must appear as a gap in the chart
  //rather than being closed up, which would draw a smooth line over an outage
  const rows = await query<Record<string, string>>(
    //`until` is midnight tomorrow, an exclusive bound, and generate_series includes both ends -- so
    //stopping at it would draw a fifteenth bar for a day that has not started. One interval back
    `WITH days AS (
       SELECT generate_series(date_trunc('day', $2::timestamptz),
                              date_trunc('day', $3::timestamptz) - interval '1 day',
                              interval '1 day') AS day
     )
     SELECT to_char(d.day, 'YYYY-MM-DD') AS day,
            COUNT(s.id)::int                                                        AS sent,
            COUNT(*) FILTER (WHERE o.final_state = 'DELIVERED')::int                AS delivered,
            COUNT(*) FILTER (WHERE o.final_state IN ('FAILED','EXPIRED','REJECTED'))::int AS failed,
            COUNT(*) FILTER (WHERE s.id IS NOT NULL AND o.final_state IS NULL)::int  AS pending
       FROM days d
       --one row per message, as UsageRollup, with the range and scope inside the DISTINCT ON
       LEFT JOIN ${messageRows(IN_RANGE_AND_SCOPE, g)}${OUTCOME}
              ON date_trunc('day', s.submitted_at) = d.day
      GROUP BY d.day
      ORDER BY d.day`,
    [scope, since.toISOString(), until.toISOString()]
  );

  return rows.map((r) => {
    const delivered = num(r.delivered);
    const failed = num(r.failed);
    const resolved = delivered + failed;
    return {
      day: r.day,
      sent: num(r.sent),
      delivered,
      failed,
      pending: num(r.pending),
      //over what has RESOLVED, not over what was sent. Dividing by sent makes every recent day look
      //like a failure, because its receipts have not arrived yet
      rate: resolved ? Math.round((delivered / resolved) * 1000) / 10 : null,
    };
  });
}

async function outcomeTotals(
  scope: string[],
  since: Date,
  until: Date
): Promise<{ slices: OutcomeSlice[]; notDelivered: number }> {
  const g = await grain();
  const rows = await query<Record<string, string>>(
    `SELECT COUNT(*) FILTER (WHERE o.final_state = 'DELIVERED')::int AS delivered,
            COUNT(*) FILTER (WHERE o.final_state IN ('FAILED','EXPIRED'))::int AS failed,
            COUNT(*) FILTER (WHERE o.final_state IN ('REJECTED','DROPPED'))::int AS refused,
            COUNT(*) FILTER (WHERE o.final_state IS NULL)::int       AS pending,
            COUNT(*) FILTER (WHERE ${NOT_DELIVERED})::int            AS not_delivered
       --one row per message, as UsageRollup
       FROM ${messageRows(IN_RANGE_AND_SCOPE, g)}${OUTCOME}`,
    [scope, since.toISOString(), until.toISOString()]
  );

  const r = rows[0] ?? {};
  //refused kept apart from failed: one never left the platform and one did, and a customer chasing
  //a delivery problem is looking at two different problems depending which it was.
  //
  //DROPPED joins REJECTED here, and did not used to be counted at all -- it is a legal final_state
  //(a filter discarded the message before a vendor saw it) and it was in none of the four slices, so
  //the donut quietly failed to add up to `sent`. It belongs with REJECTED: both are the platform
  //declining to send, as against a carrier failing to deliver
  const slices: OutcomeSlice[] = [
    { outcome: "delivered", messages: num(r.delivered) },
    { outcome: "failed", messages: num(r.failed) },
    { outcome: "refused", messages: num(r.refused) },
    { outcome: "pending", messages: num(r.pending) },
  ];
  return { slices, notDelivered: num(r.not_delivered) };
}

/**
 * The most recent handful, so the page shows something concrete under the aggregates.
 *
 * <p>Bounded by the same range as everything else on the page rather than being "the last few ever":
 * a range button that moves three charts and leaves this list alone would be lying about what it
 * selects.
 *
 * <p>`ORDER BY submitted_at DESC LIMIT n` rides `idx_cdr_submit_submitted_at`, which is what makes
 * this cheap on a table this size — but only with the range in the WHERE clause, so the planner has
 * a bound to walk backwards from.
 */
async function recentMessages(
  scope: string[],
  since: Date,
  until: Date
): Promise<RecentMessage[]> {
  const g = await grain();
  const rows = await query<Record<string, string | null>>(
    //one row per message, as UsageRollup -- as a predicate rather than a DISTINCT ON subquery, so
    //the index walk described above survives: a subquery would sort the whole range first
    `SELECT s.gateway_msg_id, s.submitted_at, s.dest_addr, o.final_state,
            ${await bodyExpression()} AS body
       FROM cdr_submit s${OUTCOME}
      WHERE ${isMessageRow("s", g)}
        AND s.submitted_at >= $2 AND s.submitted_at < $3
        AND s.account_id = ANY($1)
      ORDER BY s.submitted_at DESC
      LIMIT ${PANEL_ROWS}`,
    [scope, since.toISOString(), until.toISOString()]
  );

  return rows.map(toRecent);
}

/**
 * The same, for messages that did not arrive.
 *
 * <p>**The cost is different from the query above and worth knowing.** That one stops after the
 * first few rows the index hands back; this one filters on the LATERAL's output, so the planner
 * walks backwards through submissions until it has accumulated {@link PANEL_ROWS} failures. On an
 * account failing 0.5% of its traffic that is a walk of about a thousand rows — bounded, because the
 * date range is still in the WHERE clause, and the walk stops at the start of the range whether or
 * not it found six. An account with no failures at all scans its whole range and returns nothing,
 * which is the worst case and is exactly the case where the range is smallest in rows.
 *
 * <p>No `count(*) OVER ()` for the total: that would make the query evaluate every failure in the
 * range rather than stopping at six. {@link outcomeTotals} already counts them with the same
 * predicate, in a query that has to scan the range anyway.
 */
async function failedMessages(
  scope: string[],
  since: Date,
  until: Date
): Promise<FailedMessage[]> {
  const g = await grain();
  const rows = await query<Record<string, string | null>>(
    //one row per message, as UsageRollup, by the same predicate as recentMessages and for the same
    //reason. Without it a failed-over message that then failed was listed once per attempt
    `SELECT s.gateway_msg_id, s.submitted_at, s.dest_addr,
            o.final_state, o.dlr_state, o.err_code,
            ${await bodyExpression()} AS body
       FROM cdr_submit s${OUTCOME}
      WHERE ${isMessageRow("s", g)}
        AND ${NOT_DELIVERED}
        AND s.submitted_at >= $2 AND s.submitted_at < $3
        AND s.account_id = ANY($1)
      ORDER BY s.submitted_at DESC
      LIMIT ${PANEL_ROWS}`,
    [scope, since.toISOString(), until.toISOString()]
  );

  return rows.map((r) => ({
    ...toRecent(r),
    dlrState: r.dlr_state == null ? null : num(r.dlr_state),
    errCode: r.err_code ?? null,
  }));
}

/**
 * The message text, or a literal null where the column does not exist.
 *
 * <p>The landing page must not be the one that needs the newest migration. Against a gateway that
 * has not applied V1.31.0 there is no `body` column, and naming it would take the whole dashboard
 * down for a field that is off by default and null on every row even where it exists.
 */
async function bodyExpression(): Promise<string> {
  return (await hasBodyColumn()) ? "left(s.body, 160)" : "NULL::text";
}

function toRecent(r: Record<string, string | null>): RecentMessage {
  return {
    gatewayMsgId: String(r.gateway_msg_id ?? ""),
    submittedAt: new Date(r.submitted_at as string).toISOString(),
    destAddr: r.dest_addr ?? null,
    finalState: r.final_state ?? null,
    body: r.body ?? null,
  };
}

async function tilesFor(
  scope: string[],
  ownAccountId: string,
  since: Date,
  until: Date
): Promise<OverviewTiles> {
  const g = await grain();
  const [totals, credit] = await Promise.all([
    query<Record<string, string>>(
      `SELECT COUNT(*)::int                                              AS sent,
              COUNT(*) FILTER (WHERE o.final_state = 'DELIVERED')::int   AS delivered,
              COUNT(*) FILTER (WHERE o.final_state IS NOT NULL)::int     AS resolved,
              COALESCE(SUM(s.price), 0)::bigint                          AS spend,
              MAX(s.price_currency)                                      AS currency
         --one row per message, as UsageRollup. spend is unchanged by it: only that row has a price
         FROM ${messageRows(IN_RANGE_AND_SCOPE, g)}${OUTCOME}`,
      [scope, since.toISOString(), until.toISOString()]
    ),
    //live, and deliberately not filtered by the range: a balance is what is there now. Read through
    //the existing helper because `account_balance` lives in the CONFIG database, not the metrics one
    //every other query here uses -- and null when there is no row, meaning credit is not enforced
    //for this account rather than "out of money"
    getBalance(ownAccountId).catch(() => null),
  ]);

  const t = totals[0] ?? {};
  const delivered = num(t.delivered);
  const resolved = num(t.resolved);

  return {
    sent: num(t.sent),
    delivered,
    rate: resolved ? Math.round((delivered / resolved) * 1000) / 10 : null,
    spend: num(t.spend),
    balance: credit?.enabled === false ? null : credit?.balance ?? null,
    currency: t.currency ?? credit?.currency ?? null,
  };
}

function num(value: unknown): number {
  const n = Number(value ?? 0);
  return Number.isFinite(n) ? n : 0;
}
