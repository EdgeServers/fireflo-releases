import { messageRows, partOne, representativeKeys } from "@/lib/cdr-grain";
import { query } from "@/lib/metrics-db";
import { hasVendorAttempt } from "@/lib/metrics-schema";

/**
 * Aggregates over the gateway's call records.
 *
 * <p>Four properties of that schema make the obvious query wrong, and wrong in a way that produces
 * plausible numbers rather than obvious nonsense. They are handled here, once, so no route has to
 * remember them:
 *
 * <ol>
 *   <li><b>Every vendor attempt writes its own submit row</b>, and every one of them joins the
 *       message's receipt. `COUNT(*)` counts attempts, not messages. Which of the two you want
 *       depends on the question -- vendor load is attempts, customer volume is messages -- so the
 *       message figures go through `messageRows` (one row per message, as UsageRollup) and the
 *       vendor ones count every attempt but credit the receipt to the accepted attempt only.
 *       `lib/cdr-grain.ts` has the detail.</li>
 *   <li><b>Money is on one row per message</b> -- `CdrSubmit.carriesMoney` -- and NULL on every
 *       refused attempt, so `price` and `cost` sum correctly over every part-1 row as long as no
 *       join multiplies them.</li>
 *   <li><b>`cdr_final` has no uniqueness constraint.</b> Concurrent receipts for one message append
 *       two rows by design, so a plain join multiplies the row it joins to.</li>
 * </ol>
 *
 * <p>Money is a BIGINT scaled by 10 000 and lives only on part 1; later segments are delivery rows
 * with no amounts. Everything here returns the scaled integer -- dividing is a presentation
 * concern, and doing it in the aggregate would round away money.
 */

export type Range = "24h" | "7d" | "30d";

const RANGES: Record<Range, { hours: number; bucket: "hour" | "day" }> = {
  "24h": { hours: 24, bucket: "hour" },
  "7d": { hours: 24 * 7, bucket: "day" },
  "30d": { hours: 24 * 30, bucket: "day" },
};

export function isRange(value: string | null): value is Range {
  return value === "24h" || value === "7d" || value === "30d";
}

export function resolveRange(range: Range): {
  since: Date;
  until: Date;
  bucket: "hour" | "day";
} {
  const { hours, bucket } = RANGES[range];
  const until = new Date();
  const since = new Date(until.getTime() - hours * 3_600_000);
  return { since, until, bucket };
}

/**
 * The outcome of a message, deduplicated.
 *
 * <p>Exported because it is the one correct receipt dedupe and `statement-queries.ts` needs the same
 * answer. A second copy would drift, and the drift would be a delivery count on an invoice
 * disagreeing with the delivery count on the dashboard beside it.
 *
 * <p>Taken as a LATERAL rather than a grouped join so it uses `idx_cdr_final_msg_part` and returns
 * exactly one row however many receipts arrived. Ordered by `final_at` so the first terminal
 * outcome wins -- the expiry sweeper only writes EXPIRED for messages that never had one, so it
 * cannot displace a real receipt.
 */
export const OUTCOME_LATERAL = `
  LEFT JOIN LATERAL (
    SELECT f.final_state, f.dlr_state, f.err_code
      FROM cdr_final f
     WHERE f.gateway_msg_id = s.gateway_msg_id AND f.part_no = s.part_no
     --A real receipt outranks a swept EXPIRED, whichever landed first: EXPIRED is synthetic,
     --written by the gateway's expiry sweep, and a genuine receipt can still arrive after it
     --because the correlation index outlives the deadline. false sorts before true.
     --SAME RULE IN UsageRollup.java AND THREE OTHER lib/ QUERIES. Change one, change all five.
     ORDER BY (f.final_state = 'EXPIRED'), f.final_at
     LIMIT 1
  ) o ON TRUE`;

export interface TrafficBucket {
  bucket: string;
  submitted: number;
  delivered: number;
  failed: number;
  expired: number;
  pending: number;
}

/**
 * Messages over time, bucketed by when they were accepted.
 *
 * <p>One row per message, as UsageRollup -- however many vendors it was tried on. Retry pressure is
 * a vendor question and is reported there instead.
 */
export async function trafficOverTime(range: Range): Promise<TrafficBucket[]> {
  const { since, until, bucket } = resolveRange(range);
  const grain = { vendorAttempt: await hasVendorAttempt() };
  const rows = await query<Record<string, string>>(
    `SELECT to_char(date_trunc($3, s.submitted_at), 'YYYY-MM-DD"T"HH24:MI:SSZ') AS bucket,
            COUNT(*)                                                      AS submitted,
            COUNT(*) FILTER (WHERE o.final_state = 'DELIVERED')            AS delivered,
            COUNT(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED')) AS failed,
            COUNT(*) FILTER (WHERE o.final_state = 'EXPIRED')              AS expired,
            COUNT(*) FILTER (WHERE o.final_state IS NULL)                  AS pending
       --one row per message, as UsageRollup: a failover's refused attempt joins the same receipt
       FROM ${messageRows("s.submitted_at >= $1 AND s.submitted_at < $2", grain)}${OUTCOME_LATERAL}
      GROUP BY 1
      ORDER BY 1`,
    [since, until, bucket]
  );
  return rows.map((r) => ({
    bucket: r.bucket,
    submitted: num(r.submitted),
    delivered: num(r.delivered),
    failed: num(r.failed),
    expired: num(r.expired),
    pending: num(r.pending),
  }));
}

export interface FailureRow {
  finalState: string;
  dlrState: number | null;
  errCode: string | null;
  messages: number;
  /**
   * The newest occurrence of this failure kind in the window, as an ISO instant.
   *
   * <p>What makes a dismissal self-healing. `lib/failure-dismissals.ts` hides a row only while this
   * is older than when the operator dismissed it, so the same failure happening once more brings
   * the row back with nothing to expire and nothing to remember. Dismissing on the count instead
   * would resurrect rows on its own, because the window rolls.
   */
  lastSeen: string;
}

/**
 * Why messages failed.
 *
 * <p>`dlr_state` is kept raw on purpose: EXPIRED, REJECTD and UNDELIV all bill as failures but mean
 * very different things, and collapsing them is exactly what makes a delivery problem hard to
 * diagnose.
 */
export async function failureBreakdown(range: Range): Promise<FailureRow[]> {
  const { since, until } = resolveRange(range);
  const grain = { vendorAttempt: await hasVendorAttempt() };
  const rows = await query<Record<string, string>>(
    //max() over a group already being formed, so last_seen costs nothing beyond the aggregate.
    //One row per message, as UsageRollup: otherwise a failed-over message's failure counts twice
    `SELECT o.final_state, o.dlr_state, o.err_code, COUNT(*) AS messages,
            MAX(s.submitted_at) AS last_seen
       FROM ${messageRows("s.submitted_at >= $1 AND s.submitted_at < $2", grain)}${OUTCOME_LATERAL}
      WHERE o.final_state IS NOT NULL
        AND o.final_state <> 'DELIVERED'
      GROUP BY 1, 2, 3
      ORDER BY 4 DESC`,
    [since, until]
  );
  return rows.map((r) => ({
    finalState: r.final_state,
    dlrState: r.dlr_state === null ? null : num(r.dlr_state),
    errCode: r.err_code ?? null,
    messages: num(r.messages),
    //the driver hands back a Date for a timestamptz; an ISO string is what survives JSON either way
    lastSeen: new Date(r.last_seen).toISOString(),
  }));
}

export interface VendorRow {
  vendor: string | null;
  attempts: number;
  messages: number;
  delivered: number;
  failed: number;
  pending: number;
  cost: number;
  deliveryRate: number | null;
}

/**
 * Per-vendor performance.
 *
 * <p>Two different scopes in one row, deliberately. <b>Attempts</b> cover every submit, because a
 * failed-over message really was handed to two vendors and the refusal is real load on the first.
 * <b>Delivery outcome</b> is attributed to the message's representative attempt only — the one
 * carrying money, else the latest, exactly as UsageRollup picks it — which is the attempt the vendor
 * accepted. Attributing one outcome to every vendor that tried would credit a delivery to the vendor
 * that refused it; a refused attempt stays in `attempts` and shows no outcome at all.
 *
 * <p>Only the money row has a cost, so `cost` is exact summed over every attempt -- refused ones add
 * NULL.
 */
export async function vendorPerformance(range: Range): Promise<VendorRow[]> {
  const { since, until } = resolveRange(range);
  const vendorAttempt = await hasVendorAttempt();
  const rows = await query<Record<string, string>>(
    `WITH attempts AS (
        SELECT vendor,
               COUNT(*)                          AS attempts,
               COUNT(DISTINCT gateway_msg_id)    AS messages,
               COALESCE(SUM(cost), 0)            AS cost
          FROM cdr_submit
         WHERE ${partOne("")}
           AND submitted_at >= $1 AND submitted_at < $2
         GROUP BY vendor
     ),
     --outcome credited to the accepted attempt only: the representative row, as UsageRollup picks
     --it. This used to order by retry_count alone, which left attempts sharing a retry_count (an
     --in-worker retry at one vendor) to chance, and could pick a refusal over the money row
     last_attempt AS (
        SELECT DISTINCT ON (gateway_msg_id)
               gateway_msg_id, part_no, vendor
          FROM cdr_submit
         WHERE ${partOne("")}
           AND submitted_at >= $1 AND submitted_at < $2
         ORDER BY gateway_msg_id, ${representativeKeys("", vendorAttempt)}
     ),
     outcomes AS (
        SELECT s.vendor,
               COUNT(*) FILTER (WHERE o.final_state = 'DELIVERED')          AS delivered,
               COUNT(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED','EXPIRED')) AS failed,
               COUNT(*) FILTER (WHERE o.final_state IS NULL)                AS pending
          FROM last_attempt s${OUTCOME_LATERAL}
         GROUP BY s.vendor
     )
     SELECT a.vendor,
            a.attempts, a.messages, a.cost,
            COALESCE(o.delivered, 0) AS delivered,
            COALESCE(o.failed, 0)    AS failed,
            COALESCE(o.pending, 0)   AS pending
       FROM attempts a
       LEFT JOIN outcomes o ON o.vendor IS NOT DISTINCT FROM a.vendor
      ORDER BY a.attempts DESC`,
    [since, until]
  );
  return rows.map((r) => {
    const delivered = num(r.delivered);
    const failed = num(r.failed);
    const settled = delivered + failed;
    return {
      vendor: r.vendor ?? null,
      attempts: num(r.attempts),
      messages: num(r.messages),
      delivered,
      failed,
      pending: num(r.pending),
      cost: num(r.cost),
      //undefined rather than 0 while nothing has settled -- a brand-new vendor has no delivery
      //rate, which is not the same as a delivery rate of nought
      deliveryRate: settled === 0 ? null : delivered / settled,
    };
  });
}

export interface RevenueRow {
  accountId: string | null;
  product: string | null;
  messages: number;
  revenue: number;
  cost: number;
  margin: number;
  pendingRevenue: number;
}

/**
 * Money, by account and product.
 *
 * <p>Revenue and cost are read over different row sets — revenue and the message count over one row
 * per message (as UsageRollup), cost over every part-1 attempt — which give the same money, because
 * only the one row per message carries any. The margin is computed from those two sums rather than
 * by summing the stored `margin` column, so it cannot inherit a row-set mistake in either.
 *
 * <p>`pendingRevenue` is billed traffic with no outcome yet: real in-flight exposure, not an error.
 * The gateway's sweeper closes it as EXPIRED after 48 hours.
 */
export async function revenueByAccount(range: Range): Promise<RevenueRow[]> {
  const { since, until } = resolveRange(range);
  const grain = { vendorAttempt: await hasVendorAttempt() };
  const rows = await query<Record<string, string>>(
    `WITH attempts AS (
        SELECT s.account_id, s.product, s.price, o.final_state,
               --a message the vendor refused: recorded because it went on the wire, refunded
               --because it never left. Asked of cdr_rejected rather than of final_state, which
               --cannot tell it apart from a carrier's REJECTD receipt on a message that WAS
               --accepted and is legitimately billed. Served by idx_cdr_rejected_msg
               EXISTS (SELECT 1 FROM cdr_rejected r
                        WHERE r.gateway_msg_id = s.gateway_msg_id
                          AND r.reason = 'vendorRejected') AS refused
          --one row per message, as UsageRollup: "messages" is a message count. The price sum is
          --unchanged by it -- only the representative row ever carries one
          FROM ${messageRows("s.submitted_at >= $1 AND s.submitted_at < $2", grain)}${OUTCOME_LATERAL}
     ),
     billed AS (
        SELECT account_id, product,
               --refused attempts are excluded rather than counted at zero: this column sits beside
               --revenue, and counting traffic nobody paid for would drag revenue per message down
               --without anything on screen saying why
               COUNT(*) FILTER (WHERE NOT refused)            AS messages,
               COALESCE(SUM(price), 0)                        AS revenue,
               COALESCE(SUM(price) FILTER (WHERE final_state IS NULL), 0) AS pending_revenue
          FROM attempts
         GROUP BY 1, 2
     ),
     spent AS (
        --every part-1 row: only the money row has a cost, so this is exact without deduplication
        SELECT account_id, product, COALESCE(SUM(cost), 0) AS cost
          FROM cdr_submit
         WHERE ${partOne("")}
           AND submitted_at >= $1 AND submitted_at < $2
         GROUP BY 1, 2
     )
     SELECT b.account_id, b.product, b.messages, b.revenue, b.pending_revenue,
            COALESCE(sp.cost, 0) AS cost
       FROM billed b
       LEFT JOIN spent sp
              ON sp.account_id IS NOT DISTINCT FROM b.account_id
             AND sp.product    IS NOT DISTINCT FROM b.product
      ORDER BY b.revenue DESC`,
    [since, until]
  );
  return rows.map((r) => {
    const revenue = num(r.revenue);
    const cost = num(r.cost);
    return {
      accountId: r.account_id ?? null,
      product: r.product ?? null,
      messages: num(r.messages),
      revenue,
      cost,
      margin: revenue - cost,
      pendingRevenue: num(r.pending_revenue),
    };
  });
}

export interface UsageDay {
  /** The bucket, `YYYY-MM-DD` for a day range and an ISO instant for the hourly one. */
  day: string;
  /** `null` for traffic that named no account — real, and not the same as an account called "". */
  accountId: string | null;
  submitted: number;
  delivered: number;
  failed: number;
  pending: number;
  /** Scaled by 10 000, like every other amount here. */
  price: number;
}

/**
 * Traffic and money at day x account, which is the grain the usage page needs and nothing had.
 *
 * <p>{@link trafficOverTime} groups by bucket with no account, and {@link revenueByAccount} groups
 * by account with no day. Composing the two client-side cannot produce this: a per-day series split
 * by account is not derivable from a total per day and a total per account.
 *
 * <p>Both figures come from one pass over the same rows, which is what makes them agree. Doing the
 * counts and the sum as separate queries is how a page ends up reporting more messages than it
 * billed for and no reason why.
 *
 * <p>`price` is summed rather than counted, so an unrated message contributes a row to `submitted`
 * and nothing to the money — NULL sums to nothing on its own and needs no extra clause. Unlike
 * {@link revenueByAccount} this does <em>not</em> exclude vendor-refused messages: this is a usage
 * view, and a message that went on the wire and was refunded is traffic that happened. The money
 * column already excludes it, because a refunded row's price is NULL.
 */
export async function usageByDay(range: Range): Promise<UsageDay[]> {
  const { since, until, bucket } = resolveRange(range);
  return usageBetween(since, until, bucket);
}

/**
 * The same figures over an arbitrary window, optionally for one account.
 *
 * <p>Split out because a statement period is not one of the three named ranges — it is a calendar
 * month, or whatever two dates an operator typed. Sharing the query rather than writing a second
 * one is what makes the statement's daily chart agree with the usage page: the two are the same
 * arithmetic over a different window, and two queries would eventually disagree about a retry or a
 * refund and there would be no way to tell which was right.
 *
 * <p>The window is half-open, `[since, until)`, exactly as the statement is — so a message belongs
 * to one period and never to two.
 */
export async function usageBetween(
  since: Date,
  until: Date,
  bucket: "hour" | "day",
  accountId?: string | null
): Promise<UsageDay[]> {
  const grain = { vendorAttempt: await hasVendorAttempt() };
  const rows = await query<Record<string, string>>(
    `SELECT to_char(date_trunc($3, s.submitted_at),
                    CASE WHEN $3 = 'day' THEN 'YYYY-MM-DD'
                         ELSE 'YYYY-MM-DD"T"HH24:MI:SSZ' END)          AS day,
            s.account_id                                               AS account_id,
            COUNT(*)                                                   AS submitted,
            COUNT(*) FILTER (WHERE o.final_state = 'DELIVERED')        AS delivered,
            COUNT(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED','EXPIRED'))
                                                                       AS failed,
            COUNT(*) FILTER (WHERE o.final_state IS NULL)              AS pending,
            COALESCE(SUM(s.price), 0)                                  AS price
       --one row per message, as UsageRollup -- which is what makes this agree with usage_daily
       --once the day is rolled up. $4 IS NULL rather than a second query: one plan, and the
       --parameter is bound rather than interpolated, so an account id is never concatenated into SQL
       FROM ${messageRows(
         "s.submitted_at >= $1 AND s.submitted_at < $2 AND ($4::text IS NULL OR s.account_id = $4)",
         grain
       )}${OUTCOME_LATERAL}
      GROUP BY 1, 2
      ORDER BY 1, 2`,
    [since, until, bucket, accountId ?? null]
  );
  return rows.map((r) => ({
    day: r.day,
    accountId: r.account_id ?? null,
    submitted: num(r.submitted),
    delivered: num(r.delivered),
    failed: num(r.failed),
    pending: num(r.pending),
    price: num(r.price),
  }));
}

export interface Totals {
  messages: number;
  delivered: number;
  failed: number;
  pending: number;
  revenue: number;
  cost: number;
  margin: number;
  deliveryRate: number | null;
}

/** The headline figures, scoped exactly as the detailed queries are. */
export async function totals(range: Range): Promise<Totals> {
  const [traffic, revenue] = await Promise.all([trafficOverTime(range), revenueByAccount(range)]);

  const messages = sum(traffic, (t) => t.submitted);
  const delivered = sum(traffic, (t) => t.delivered);
  const failed = sum(traffic, (t) => t.failed) + sum(traffic, (t) => t.expired);
  const settled = delivered + failed;

  return {
    messages,
    delivered,
    failed,
    pending: sum(traffic, (t) => t.pending),
    revenue: sum(revenue, (r) => r.revenue),
    cost: sum(revenue, (r) => r.cost),
    margin: sum(revenue, (r) => r.margin),
    deliveryRate: settled === 0 ? null : delivered / settled,
  };
}

export interface AccountRow {
  accountId: string | null;
  systemId: string | null;
  product: string | null;
  messages: number;
  delivered: number;
  failed: number;
  pending: number;
  billed: number;
  cost: number;
  deliveryRate: number | null;
  lastSeen: string | null;
  /** Spendable credit, or null when the account has no balance row. */
  balance: number | null;
  currency: string | null;
  /** True when the credential is configured but sent nothing in this period. */
  idle: boolean;
}

export interface AccountsView {
  /**
   * Whether prepaid credit appears to be switched on.
   *
   * <p>A heuristic, and worth naming as one: the panel cannot read the gateway's
   * `smsg.balance.enabled`, so it infers from whether any balance rows exist. An enabled gateway
   * that has never been funded looks the same as a disabled one — but both mean "no credit figure
   * to show", which is what the column needs to decide.
   */
  creditEnforced: boolean;
  accounts: AccountRow[];
}

/**
 * Who is using the gateway.
 *
 * <p>Built from the call records rather than the credential table, because credentials may be
 * configured from a file — in which case `app_credential` is empty and would show nothing at all.
 * Configured credentials are merged in on top when the table *is* populated, so a provisioned
 * account that has sent nothing still appears rather than silently going missing.
 */
export async function accountUsage(range: Range): Promise<AccountsView> {
  const { since, until } = resolveRange(range);
  const grain = { vendorAttempt: await hasVendorAttempt() };

  const [activity, configured, funded] = await Promise.all([
    query<Record<string, string>>(
      `WITH act AS (
          SELECT s.account_id, s.system_id, s.product,
                 COUNT(*)                                                   AS messages,
                 COALESCE(SUM(s.price), 0)                                  AS billed,
                 MAX(s.submitted_at)                                        AS last_seen,
                 COUNT(*) FILTER (WHERE o.final_state = 'DELIVERED')        AS delivered,
                 COUNT(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED','EXPIRED')) AS failed,
                 COUNT(*) FILTER (WHERE o.final_state IS NULL)              AS pending
            --one row per message, as UsageRollup
            FROM ${messageRows("s.submitted_at >= $1 AND s.submitted_at < $2", grain)}${OUTCOME_LATERAL}
           GROUP BY 1, 2, 3
       ),
       spend AS (
          --every part-1 row: only the money row has a cost
          SELECT account_id, system_id, product, COALESCE(SUM(cost), 0) AS cost
            FROM cdr_submit
           WHERE ${partOne("")}
             AND submitted_at >= $1 AND submitted_at < $2
           GROUP BY 1, 2, 3
       )
       SELECT a.account_id, a.system_id, a.product, a.messages, a.billed,
              to_char(a.last_seen, 'YYYY-MM-DD"T"HH24:MI:SSZ') AS last_seen,
              a.delivered, a.failed, a.pending,
              COALESCE(sp.cost, 0) AS cost
         FROM act a
         LEFT JOIN spend sp
                ON sp.account_id IS NOT DISTINCT FROM a.account_id
               AND sp.system_id  IS NOT DISTINCT FROM a.system_id
               AND sp.product    IS NOT DISTINCT FROM a.product
        ORDER BY a.messages DESC`,
      [since, until]
    ),
    configuredCredentials(),
    accountBalances(),
  ]);

  const rows: AccountRow[] = activity.map((r) => {
    const delivered = num(r.delivered);
    const failed = num(r.failed);
    const settled = delivered + failed;
    const balance = funded.get(r.account_id ?? "");
    return {
      accountId: r.account_id ?? null,
      systemId: r.system_id ?? null,
      product: r.product ?? null,
      messages: num(r.messages),
      delivered,
      failed,
      pending: num(r.pending),
      billed: num(r.billed),
      cost: num(r.cost),
      deliveryRate: settled === 0 ? null : delivered / settled,
      lastSeen: r.last_seen ?? null,
      balance: balance?.balance ?? null,
      currency: balance?.currency ?? null,
      idle: false,
    };
  });

  //a credential that is provisioned but sent nothing in this window is worth seeing, not omitting
  const seen = new Set(rows.map((r) => `${r.accountId}|${r.systemId}`));
  for (const c of configured) {
    if (seen.has(`${c.accountId}|${c.systemId}`)) continue;
    const balance = funded.get(c.accountId ?? "");
    rows.push({
      accountId: c.accountId,
      systemId: c.systemId,
      product: c.product,
      messages: 0,
      delivered: 0,
      failed: 0,
      pending: 0,
      billed: 0,
      cost: 0,
      deliveryRate: null,
      lastSeen: null,
      balance: balance?.balance ?? null,
      currency: balance?.currency ?? null,
      idle: true,
    });
  }

  return { creditEnforced: funded.size > 0, accounts: rows };
}

interface ConfiguredCredential {
  accountId: string | null;
  systemId: string | null;
  product: string | null;
}

/**
 * Credentials configured in the database, if any.
 *
 * <p>Note the column list: `password` and `api_key` are in this table and are never selected.
 * A secret that is not read cannot be leaked by a later change to how this is rendered.
 *
 * <p>Returns empty rather than throwing when the table is absent or unreadable — a gateway using
 * file-based credentials is a normal configuration, not a failure, and the read-only role may
 * legitimately have no grant on it.
 */
async function configuredCredentials(): Promise<ConfiguredCredential[]> {
  try {
    const rows = await query<Record<string, string>>(
      `SELECT account_id, system_id, product FROM app_credential WHERE enabled ORDER BY system_id`
    );
    return rows.map((r) => ({
      accountId: r.account_id ?? null,
      systemId: r.system_id ?? null,
      product: r.product ?? null,
    }));
  } catch {
    return [];
  }
}

async function accountBalances(): Promise<Map<string, { balance: number; currency: string | null }>> {
  const map = new Map<string, { balance: number; currency: string | null }>();
  try {
    const rows = await query<Record<string, string>>(
      `SELECT account_id, balance, currency FROM account_balance WHERE enabled`
    );
    for (const r of rows) {
      map.set(r.account_id, { balance: num(r.balance), currency: r.currency ?? null });
    }
  } catch {
    //same reasoning as above: no balance table, or no grant, is not an error worth failing on
  }
  return map;
}

/** Postgres returns BIGINT as a string, so every count and amount arrives as text. */
function num(value: string | null | undefined): number {
  return value == null ? 0 : Number(value);
}

function sum<T>(rows: T[], pick: (row: T) => number): number {
  return rows.reduce((acc, row) => acc + pick(row), 0);
}

/** The most groups a pre-flight lists. Beyond this it is a platform-wide problem, not a list. */
const UNRATED_GROUP_LIMIT = 50;

/**
 * Recent traffic that carried no price, grouped by who sent it and under what.
 *
 * <p>Answers one question: what would `smsg.rating.unrated.refuse` refuse if it were switched on
 * now. Every row here is a message that flows today and would be refused — `0x418` over SMPP, `403`
 * over REST — from the gateway's next configuration poll onward.
 *
 * <p><strong>`price_rule_id IS NULL`, not `price = 0` and not `price IS NULL`.</strong> The gateway
 * refuses only when no rule matched; a rule deliberately set to zero prices the message at nothing
 * and keeps sending once the flag is on. `price_rule_id` is the only column that records which of
 * those two happened, and getting it wrong would report every free route as about to break.
 *
 * <p>The total is a window function rather than a second query, so the number is the whole picture
 * even when the list is truncated — "50 groups" with a total covering all of them, not a total that
 * silently means "the 50 shown".
 */
export async function unratedTraffic(hours: number): Promise<{
  groups: { accountId: string; product: string; messages: number }[];
  total: number;
}> {
  const grain = { vendorAttempt: await hasVendorAttempt() };
  const rows = await query<Record<string, string>>(
    //one row per message, as UsageRollup. Every refused attempt is written UNRATED -- its rating is
    //dropped because it carries no money -- so counting rows reported each failover of a perfectly
    //well-priced message as unrated traffic. The representative row is the money row when there is
    //one, and that has its price_rule_id
    `SELECT COALESCE(s.account_id, '')        AS account_id,
            COALESCE(s.product, '')           AS product,
            count(*)::int                     AS messages,
            (sum(count(*)) OVER ())::bigint   AS total
       FROM ${messageRows("s.submitted_at > now() - ($1 || ' hours')::interval", grain)}
      WHERE s.price_rule_id IS NULL
      GROUP BY 1, 2
      ORDER BY messages DESC, account_id
      LIMIT ${UNRATED_GROUP_LIMIT}`,
    [String(hours)]
  );

  return {
    groups: rows.map((r) => ({
      accountId: r.account_id,
      product: r.product,
      messages: num(r.messages),
    })),
    total: num(rows[0]?.total),
  };
}

/** How far back the live traffic chart looks, and how wide each of its points is. */
export const LIVE_WINDOW_MS = 15 * 60_000;
export const LIVE_BUCKET_SECONDS = 10;

/** One point of the live chart, for one vendor or account. Counts, not rates. */
export interface LiveTrafficRow {
  /** Bucket start, epoch milliseconds. */
  t: number;
  /** A vendor's full worker name (`smppclient.x`, as `trafficKey`) or an account id. */
  key: string;
  mt: number;
  dlr: number;
}

/**
 * MT and DLR over the last fifteen minutes, in ten-second buckets, per vendor or per account.
 *
 * <p>Both count segments, not messages, so they sit on the same scale as the gateway's own TPS:
 *
 * <ul>
 *   <li><b>Vendors, MT</b> is every submit row -- every attempt, every part -- because each one is a
 *       submit_sm the vendor had to take. Load on a vendor is attempts.</li>
 *   <li><b>Accounts, MT</b> is each (message, part) once, however many vendors it was tried on: a
 *       failover is the gateway's retry, not more traffic from the customer.</li>
 *   <li><b>DLR</b> is each (message, part) with a receipt in the bucket, credited to the attempt
 *       that represents the message (`representativeKeys`). `cdr_final` can hold two rows for one
 *       part, hence the DISTINCT. A swept EXPIRED is left out: the gateway writes it with no
 *       `dlr_state` when no receipt came, so counting it would draw receipts that never arrived.</li>
 * </ul>
 *
 * <p>Buckets with nothing in them are absent; the chart fills them with zero.
 */
export async function liveTraffic(kind: "vendor" | "server"): Promise<LiveTrafficRow[]> {
  const until = new Date();
  const since = new Date(until.getTime() - LIVE_WINDOW_MS);
  const vendorAttempt = await hasVendorAttempt();
  const keyCol = kind === "vendor" ? "vendor" : "account_id";
  const bin = `date_bin(interval '${LIVE_BUCKET_SECONDS} seconds', %s, $1::timestamptz)`;
  const mtCount = kind === "vendor" ? "COUNT(*)" : "COUNT(DISTINCT (s.gateway_msg_id, s.part_no))";

  const rows = await query<Record<string, string>>(
    `WITH mt AS (
       SELECT ${bin.replace("%s", "s.submitted_at")} AS b, s.${keyCol} AS key, ${mtCount} AS n
         FROM cdr_submit s
        WHERE s.submitted_at >= $1 AND s.submitted_at < $2 AND s.${keyCol} IS NOT NULL
        GROUP BY 1, 2
     ), dlr AS (
       SELECT ${bin.replace("%s", "f.final_at")} AS b, s.key, COUNT(DISTINCT (f.gateway_msg_id, f.part_no)) AS n
         FROM cdr_final f
         JOIN LATERAL (
           SELECT s.${keyCol} AS key
             FROM cdr_submit s
            WHERE s.gateway_msg_id = f.gateway_msg_id AND s.part_no = f.part_no
            ORDER BY ${representativeKeys("s", vendorAttempt)}
            LIMIT 1
         ) s ON TRUE
        WHERE f.final_at >= $1 AND f.final_at < $2 AND f.dlr_state IS NOT NULL AND s.key IS NOT NULL
        GROUP BY 1, 2
     )
     SELECT (EXTRACT(EPOCH FROM COALESCE(mt.b, dlr.b)) * 1000)::bigint AS t,
            COALESCE(mt.key, dlr.key) AS key,
            COALESCE(mt.n, 0) AS mt,
            COALESCE(dlr.n, 0) AS dlr
       FROM mt FULL JOIN dlr ON mt.b = dlr.b AND mt.key = dlr.key
      ORDER BY 1`,
    [since, until]
  );
  return rows.map((r) => ({ t: num(r.t), key: r.key, mt: num(r.mt), dlr: num(r.dlr) }));
}
