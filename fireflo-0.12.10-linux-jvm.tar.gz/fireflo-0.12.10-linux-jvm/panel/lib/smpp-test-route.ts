import { NextResponse } from "next/server";
import { NotOperatorError, requireAdmin } from "@/lib/require-operator";

/**
 * The guard every SMPP test route shares: an admin, or a 404 that does not say the route exists.
 *
 * @returns the admin's name, or the response to send instead
 */
export async function adminOr404(): Promise<string | NextResponse> {
  try {
    return (await requireAdmin()).name;
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
}

/** Where the gateway's listeners are: SMPP_TEST_HOST, else the ops URL's host, else this host. */
export function gatewayHost(): string {
  const explicit = process.env.SMPP_TEST_HOST?.trim();
  if (explicit) {
    return explicit;
  }
  try {
    const ops = process.env.GATEWAY_OPS_URL?.trim();
    if (ops) {
      return new URL(ops).hostname;
    }
  } catch {
    //not a URL; fall through
  }
  return "127.0.0.1";
}

export const SESSION_ID = /^[0-9a-f]{16}$/;
