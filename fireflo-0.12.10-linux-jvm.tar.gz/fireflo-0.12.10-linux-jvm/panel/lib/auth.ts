import { timingSafeEqual } from "crypto";
import { lockoutKey, signinLockout } from "@/lib/signin-lockout";
import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { logAuthFailure, logOperatorEvent } from "@/lib/access-log";
import { isConfigWritable } from "@/lib/config-db";
import { burnVerifyTime, verifyPassword } from "@/lib/password-hash";
import { currentRequestContext, markRequestHandled } from "@/lib/request-context";
import { ADMIN_ROLE, OPERATOR_ROLE } from "@/lib/roles";
import { redeemLoginToken } from "@/lib/login-token";
import { findLoginUser, panelUsersExist, touchLastLogin } from "@/lib/users";
import { normaliseEmail } from "@/lib/user-types";

declare module "next-auth" {
  /**
   * Shared by both NextAuth instances. The widening is type-only: which fields a session actually
   * carries is decided by the instance that minted it, and each stamps only its own.
   */
  interface Session {
    user: {
      name?: string | null;
      email?: string | null;
      image?: string | null;
      /** `admin` or `operator` from `lib/auth.ts`; `customer` from `lib/mis-auth.ts`. Never both. */
      role?: string | null;
      /** The `app_user.id` as a string. Null for the deprecated env-fallback operator. */
      userId?: string | null;
      /** Only the portal instance sets this. */
      accountId?: string | null;
    };
  }
}

/** The claims this instance adds to the token. */
interface OperatorToken { role?: string; userId?: string | null }

const DEFAULT_USERNAME = "operator";

/** Failed operator sign-ins, counted apart from the portal's -- see lib/signin-lockout.ts. */
const lockout = signinLockout();

/**
 * `AUTH_URL` must be a bare origin, and saying so early is cheaper than the failure.
 *
 * <p>next-auth does `config.basePath || (config.basePath = pathname)`. A value with a path —
 * `https://panel.example.com/panel` — therefore silently moves this instance's endpoints to
 * `/panel`, and every call to `/api/auth/*` answers "Bad request" with nothing pointing at the
 * cause. The customer instance escapes this only because it sets `basePath` explicitly.
 *
 * <p>Warned, not thrown: a hard failure at module load takes the entire panel down over a trailing
 * slash somebody typed into an environment file, which is a worse outcome than a broken redirect.
 */
function warnIfAuthUrlHasPath(): void {
  const raw = process.env.AUTH_URL?.trim();
  if (!raw) {
    return;
  }
  try {
    const parsed = new URL(raw);
    if (parsed.pathname !== "/" && parsed.pathname !== "") {
      console.error(
        `AUTH_URL is "${raw}", which has a path. next-auth adopts that path as its basePath, so `
          + "every /api/auth call will fail. Set it to the bare origin: "
          + `${parsed.protocol}//${parsed.host}`
      );
    }
  } catch {
    console.error(`AUTH_URL is "${raw}", which is not a URL. Sign-out will redirect to the port this process bound.`);
  }
}

warnIfAuthUrlHasPath();

/**
 * Operator sign-in.
 *
 * <p>This is deliberately NOT a gateway messaging credential. The data behind this panel includes
 * margin and the names of the vendors traffic is bought from; the gateway's own credentials
 * belong to customers, and it has no notion of an admin role. An operator is a different kind of
 * identity, so it gets a different authenticator.
 *
 * <h2>Where the password lives now</h2>
 *
 * <p>In `app_user`, as a hash the gateway's `fireflo user` command and this module both read
 * (`lib/password-hash.ts`). The lookup is {@link findLoginUser} with the `"operator"` surface, whose
 * WHERE clause admits only rows with no account and a panel role — so a customer row can never sign
 * in here whatever its password, and this instance can stamp only {@link ADMIN_ROLE} or
 * {@link OPERATOR_ROLE}.
 *
 * <h2>The env fallback, for one release</h2>
 *
 * <p>Until this release the whole operator account was `OPERATOR_USERNAME` and `OPERATOR_PASSWORD`
 * in `panel.env`. The installer's `update` moves that into an admin row and removes the variables,
 * but a panel upgraded before its gateway ran V1.52.0 has no table yet, and a panel whose installer
 * step failed has an empty one. So: when no admin or operator row exists at all and
 * `OPERATOR_PASSWORD` is set, the old comparison still runs, is logged as `env_fallback`, and
 * complains in the journal. The moment one panel user exists the variables are ignored. Remove
 * the whole branch in the release after this one.
 *
 * <p>With neither a user row nor `OPERATOR_PASSWORD` there is no way in at all — not "any password
 * works", not "no password required". Missing configuration fails closed.
 */
export const { handlers, auth, signIn, signOut } = NextAuth({
  providers: [
    Credentials({
      id: "operator",
      name: "Operator",
      credentials: {
        username: { label: "Email", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        //the IP arrives through an async context because this function is handed credentials and
        //nothing else. See lib/request-context.ts for why that beats reading the response.
        const context = currentRequestContext();
        const ip = context?.ip ?? null;
        const record = (
          event: "signin" | "signin_failed",
          actor: string | null,
          userId: number | null,
          reason?: string
        ) => {
          markRequestHandled();
          void logOperatorEvent({
            event,
            actor,
            userId,
            ip,
            userAgent: context?.userAgent ?? null,
            detail: reason ? { reason } : undefined,
          });
          //also to the file fail2ban watches. The operator log stays what it is -- an audit trail
          //of what an operator did, where a success sits beside a failure -- and only the dedicated
          //one is jailed, so a refusal is recorded twice and counted once
          if (event === "signin_failed") {
            void logAuthFailure({ surface: "panel", reason: reason ?? "bad_credentials", triedAs: actor, ip });
          }
        };

        const typed = (credentials?.username as string | undefined)?.trim() ?? "";
        const password = (credentials?.password as string | undefined) ?? "";
        const email = normaliseEmail(typed || DEFAULT_USERNAME) ?? typed;
        const lockKey = lockoutKey(ip, email);

        if (lockout.lockedOut(lockKey)) {
          record("signin_failed", typed || null, null, "rate_limited");
          return null;
        }

        if (isConfigWritable() && (await panelUsersExist())) {
          const user = await findLoginUser(email, "operator");
          //the derivation runs whether or not a row was found, so an unknown address costs the same
          //third of a second a known one does -- see burnVerifyTime
          const ok = user?.passwordHash
            ? await verifyPassword(password, user.passwordHash)
            : (await burnVerifyTime(password), false);
          if (!user || !ok) {
            //what was TYPED is recorded, not the normalised address, so the log shows the attacker's
            //string; the reason is not broken down, because a log that said which half matched
            //would hand back through disk exactly what the constant-time compare refuses to leak
            lockout.noteFailure(lockKey);
            record("signin_failed", typed || null, null, "bad_credentials");
            return null;
          }
          lockout.clear(lockKey);
          void touchLastLogin(user.id);
          record("signin", user.email, user.id);
          return { id: String(user.id), name: user.email, email: user.email, role: user.role };
        }

        //---- env fallback: no panel user exists yet (or no table) ----
        const expectedPassword = process.env.OPERATOR_PASSWORD;
        if (!expectedPassword) {
          console.error(
            "No admin or operator user exists and OPERATOR_PASSWORD is not set; operator sign-in is "
              + "disabled. Create one with: fireflo user add --email you@example.com --role admin --generate"
          );
          record("signin_failed", null, null, "not_configured");
          return null;
        }
        const expectedUsername = normaliseEmail(process.env.OPERATOR_USERNAME?.trim() || DEFAULT_USERNAME)!;

        //both compared in constant time, and both must pass -- returning early on a username
        //mismatch would leak which half was wrong through timing
        const userOk = constantTimeEquals(email.toLowerCase(), expectedUsername.toLowerCase());
        const passOk = constantTimeEquals(password, expectedPassword);
        if (!userOk || !passOk) {
          lockout.noteFailure(lockKey);
          record("signin_failed", typed || null, null, "bad_credentials");
          return null;
        }
        lockout.clear(lockKey);

        console.error(
          "Operator signed in with OPERATOR_PASSWORD from panel.env. This fallback is deprecated and "
            + "goes away next release: run 'fireflo-panel-install update' to move the account into app_user."
        );
        record("signin", expectedUsername, null, "env_fallback");
        return { id: "env", name: expectedUsername, email: expectedUsername, role: ADMIN_ROLE };
      },
    }),

    /**
     * The one-time link, for operators and admins.
     *
     * <p>A second provider on THIS instance, not a use of the portal's: the redeem names the door in
     * its SQL, so a customer's token is not found here and an operator's is not found there, and
     * the session this mints carries only the roles this instance may stamp. The link is also how
     * a new operator sets their first password, and how a forgotten one is replaced.
     */
    Credentials({
      id: "magic-link",
      name: "Sign-in link",
      credentials: { token: { label: "Token", type: "text" } },
      async authorize(credentials) {
        const token = credentials?.token;
        if (typeof token !== "string") {
          return null;
        }
        const context = currentRequestContext();
        const ip = context?.ip ?? null;
        const userAgent = context?.userAgent ?? null;
        markRequestHandled();

        if (!isConfigWritable()) {
          return null;
        }
        //spends the token. Unknown, expired, already used, or issued for the portal: one null,
        //because telling them apart would tell an attacker which of their guesses was close
        const redeemed = await redeemLoginToken(token, "operator");
        if (!redeemed) {
          void logOperatorEvent({ event: "link_rejected", actor: null, userId: null, ip, userAgent });
          void logAuthFailure({ surface: "panel", reason: "link_rejected", triedAs: null, ip });
          return null;
        }
        void touchLastLogin(redeemed.userId);
        void logOperatorEvent({ event: "link_redeemed", actor: redeemed.email, userId: redeemed.userId, ip, userAgent });
        return { id: String(redeemed.userId), name: redeemed.email, email: redeemed.email, role: redeemed.role };
      },
    }),
  ],

  pages: { signIn: "/cp/login" },
  trustHost: true,
  session: { strategy: "jwt" },

  callbacks: {
    //the role is stamped at sign-in and carried in the JWT rather than recomputed. Only this
    //provider can put it there, and this provider only authorises admins and operators; whether
    //the person is STILL one is re-read from the row on every request by requireOperator
    jwt({ token, user }) {
      if (user) {
        const u = user as { id?: string; role?: string };
        const t = token as OperatorToken;
        t.role = u.role === ADMIN_ROLE ? ADMIN_ROLE : OPERATOR_ROLE;
        //cast rather than a `next-auth/jwt` module augmentation: v5 does not publish that subpath,
        //so augmenting it is a type error rather than a declaration
        t.userId = u.id && u.id !== "env" ? u.id : null;
      }
      return token;
    },
    session({ session, token }) {
      const t = token as OperatorToken;
      session.user.role = t.role ?? null;
      session.user.userId = t.userId ?? null;
      return session;
    },
    authorized({ auth: session }) {
      return session?.user?.role === OPERATOR_ROLE || session?.user?.role === ADMIN_ROLE;
    },
  },

  // no maxAge: the session dies with the browser
  cookies: {
    sessionToken: {
      name: "fireflo-control.session-token",
      options: {
        httpOnly: true,
        sameSite: "lax" as const,
        path: "/",
        //AUTH_COOKIE_SECURE overrides the NODE_ENV guess, and without it a panel served over
        //plain HTTP cannot hold a session at all. `secure` tells the browser to send the cookie
        //only over TLS, so on http:// it is accepted from the server and then silently dropped --
        //sign-in succeeds, the redirect follows, and the next request arrives with no session, so
        //the operator lands back on the login page with nothing anywhere saying why. The server
        //logs a successful signin; the browser shows a failed one.
        //
        //NODE_ENV alone cannot answer this. It says "this is a production build", which is true of
        //every installed panel including the ones reached over http on a private network, and it
        //is not a statement about the scheme. So the deployment states the scheme and the build
        //mode stays the fallback for anyone who has not.
        //
        //Found on an install that had been hand-patched to this exact expression, with
        //AUTH_COOKIE_SECURE already in its panel.env -- the workaround existed and had never
        //reached the repository, so every fresh HTTP install rediscovered the same dead end.
        secure: process.env.AUTH_COOKIE_SECURE
          ? process.env.AUTH_COOKIE_SECURE === "true"
          : process.env.NODE_ENV === "production",
      },
    },
  },
});

/**
 * Compares without revealing how much matched through timing. Only the env fallback uses it now.
 *
 * <p>Lengths are compared separately because `timingSafeEqual` throws on a length mismatch, which
 * would itself be a signal. Hashing both sides to a fixed width would hide even that; for a single
 * local operator credential the length leak is not worth the extra machinery, but it is a leak and
 * worth naming rather than pretending otherwise.
 */
function constantTimeEquals(a: string, b: string): boolean {
  const left = Buffer.from(a, "utf8");
  const right = Buffer.from(b, "utf8");
  if (left.length !== right.length) {
    return false;
  }
  return timingSafeEqual(left, right);
}
