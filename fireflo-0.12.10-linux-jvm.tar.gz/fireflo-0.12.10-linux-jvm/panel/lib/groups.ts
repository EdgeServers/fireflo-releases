import { ConfigRefusal } from "@/lib/config-guard";
import { configQuery, inTransaction } from "@/lib/config-db";
import type { GroupPolicy, RouteGroup, RouteGroupInput } from "@/lib/group-types";

/**
 * Vendor groups and their ordered members.
 *
 * <p>Server-only: importing this pulls `pg`. Every statement about what a group *means* lives in
 * `group-types.ts`, so the editor and the API route can share it.
 */

interface GroupRow {
  name: string;
  policy: string;
  label: string | null;
  enabled: boolean;
}

interface MemberRow {
  group_name: string;
  worker_name: string;
  weight: number;
  enabled: boolean;
}

/** Every group with its members in preference order. */
export async function listRouteGroups(): Promise<RouteGroup[]> {
  const groups = await configQuery<GroupRow>(
    "SELECT name, policy, label, enabled FROM app_route_group ORDER BY name"
  );
  if (!groups.length) {
    return [];
  }
  const members = await configQuery<MemberRow>(
    `SELECT group_name, worker_name, weight, enabled FROM app_route_group_member
      ORDER BY group_name, seq`
  );

  const byGroup = new Map<string, RouteGroup["members"]>();
  for (const row of members) {
    const list = byGroup.get(row.group_name) ?? [];
    list.push({ workerName: row.worker_name, weight: row.weight, enabled: row.enabled });
    byGroup.set(row.group_name, list);
  }

  return groups.map((g) => ({
    name: g.name,
    //the column is CHECK-constrained, but a cast is still a claim about data
    policy: (["ROUND_ROBIN", "WEIGHTED", "FAILOVER"].includes(g.policy)
      ? g.policy
      : "ROUND_ROBIN") as GroupPolicy,
    label: g.label,
    enabled: g.enabled,
    members: byGroup.get(g.name) ?? [],
  }));
}

/**
 * Creates or rewrites one group and every member of it.
 *
 * <h3>Why this does not need the seq-parking dance `saveRouteTable` does</h3>
 *
 * <p>`UNIQUE (group_name, seq)` is non-deferrable here too, so reordering members by UPDATE would
 * fail the moment two of them swapped. It is avoided rather than worked around: a member has no
 * surrogate id and nothing references it, so deleting them all and reinserting loses nothing —
 * unlike a routing rule, whose id owns its conditions and filters. The delete and the inserts are in
 * one transaction, so no reader ever sees the group empty.
 */
export async function saveRouteGroup(input: RouteGroupInput): Promise<void> {
  const name = input.name.trim();
  await inTransaction(async (client) => {
    await client.query(
      `INSERT INTO app_route_group (name, policy, label, enabled, updated_at)
       VALUES ($1, $2, $3, $4, now())
       ON CONFLICT (name) DO UPDATE
         SET policy = EXCLUDED.policy, label = EXCLUDED.label,
             enabled = EXCLUDED.enabled, updated_at = now()`,
      [name, input.policy, input.label?.trim() || null, input.enabled]
    );

    //FOR UPDATE on the parent, so two operators saving the same group serialise rather than
    //interleaving a delete with the other's inserts
    await client.query("SELECT 1 FROM app_route_group WHERE name = $1 FOR UPDATE", [name]);
    await client.query("DELETE FROM app_route_group_member WHERE group_name = $1", [name]);

    for (let i = 0; i < input.members.length; i++) {
      const member = input.members[i];
      await client.query(
        `INSERT INTO app_route_group_member (group_name, worker_name, weight, seq, enabled)
         VALUES ($1, $2, $3, $4, $5)`,
        [name, member.workerName.trim(), member.weight, i, member.enabled]
      );
    }
  });
}

/**
 * Removes a group.
 *
 * <p>Members go with it through ON DELETE CASCADE. Rules that still target the name are left alone
 * and become unresolvable — reported by the gateway as an unknown target, once per rule. Deleting
 * the rules too would be a larger and more surprising action than the button says.
 *
 * @returns the rules that will be left pointing at nothing, so the caller can say so before doing it
 */
export async function routeRulesTargeting(name: string): Promise<{ table: string; target: string }[]> {
  return configQuery<{ table: string; target: string }>(
    "SELECT table_name AS table, target FROM app_route_rule WHERE target = $1 ORDER BY table_name, seq",
    [name.trim()]
  );
}

/**
 * Removes a group and its members, if no rule sends to it.
 *
 * <p>It used to go through and report the rules it left pointing at nothing. Since gateway migration
 * V1.58.0 a rule's target is a foreign key (`target_group`), so that delete would fail at commit;
 * this refuses first and names the tables to fix.
 *
 * @throws ConfigRefusal naming the routing tables with rules that send to the group
 */
export async function deleteRouteGroup(name: string): Promise<void> {
  const using = await routeRulesTargeting(name);
  if (using.length) {
    const tables = [...new Set(using.map((r) => r.table))].map((t) => `'${t}'`).join(", ");
    throw new ConfigRefusal(
      `${using.length} rule(s) in ${tables} still send to '${name.trim()}'. Point them somewhere else first.`
    );
  }
  await inTransaction(async (client) => {
    await client.query("DELETE FROM app_route_group WHERE name = $1", [name.trim()]);
  });
}
