//with the extension, because `node --test` runs this module directly and does not resolve
//extensionless specifiers. Everything imported is pure data, so this stays importable by a client
//component and by the seed script alike
import { GATEWAY_SETTING_FIELDS } from "./gateway-setting-fields.ts";
import { SETTING_FIELDS, type SettingWidget } from "./setting-fields.ts";
import { settingLabel, type SettingKey } from "./labels.ts";

/**
 * What every gateway configuration key is -- the one list both the gateway and this panel read.
 *
 * <h2>Why it is a table</h2>
 *
 * <p>Whether a key is a credential, whether the panel may show or edit it, and what shape its value
 * has used to be written down five times: the gateway's `SensitiveLogSanitizer`, this panel's
 * `DENIED` map and substring list, its separate `SECRET_KEYS` for worker settings, the `secret`
 * widget kind in the setting catalogues, and the gateway's lenient value parsers. Two of those
 * disagreeing is how `smsg.ops.token` once reached the browser. Since gateway migration V1.61.0 the
 * facts live in `app_config_key`, the gateway masks what it says is secret, and this panel reads it
 * on the server and hands the verdicts to its screens.
 *
 * <h2>What stays in code, and why</h2>
 *
 * <ul>
 *   <li>{@link BUILTIN_REGISTRY}, below: what `app_config_key` was seeded from, and what this panel
 *       falls back to when it cannot read the table -- a gateway in file mode, or a role without the
 *       grant. It is generated from the same catalogues the forms render, so the two cannot drift;
 *       `scripts/config-key-registry-sql.ts` prints it as the migration's seed.</li>
 *   <li>The substring rule in `gateway-key-policy.ts` and the gateway's `isSensitiveKey`. A list
 *       only covers the keys somebody listed; a key nobody listed must still be caught by its name,
 *       the day it is added.</li>
 *   <li>Labels, hints and form layout. Those are this panel's presentation, not facts about the
 *       gateway; the registry carries a label only so a database reader can tell keys apart.</li>
 * </ul>
 */

/** Why the panel will not write a key. The same reasons `gateway-key-policy.ts` has always given. */
export type DenialReason = "secret" | "config-source" | "wiring" | "elsewhere" | "licensing" | "prefix";

/** Where the key lives: `app_config` (platform), or a worker property (`app_worker_property`, and `outSms.default.<key>`). */
export type KeyScope = "platform" | "worker";

/** What the panel may do with it. */
export type KeyAccess = "editable" | "read-only" | "hidden";

export type KeyKind = SettingWidget["kind"];

export interface ConfigKeyRow {
  scope: KeyScope;
  key: string;
  kind: KeyKind;
  /** The values an `enum` accepts; null otherwise. */
  choices: string[] | null;
  /** `ms`, `s` or `min` for a number that is a duration; null otherwise. */
  unit: string | null;
  /** The literal the gateway parses when the key is absent; null when it has not been verified. */
  codedDefault: string | null;
  secret: boolean;
  access: KeyAccess;
  /** Why it is not editable; null when it is. */
  reason: DenialReason | null;
  label: string | null;
}

/**
 * Keys denied by name, with the reason. Moved here from `gateway-key-policy.ts` so the code holds one
 * list, and that list is the registry's seed; every entry is one `gateway-setting-fields.ts` argues
 * for in its header, and the key literals were read from the gateway source.
 */
const DENIED_PLATFORM: readonly {
  key: string;
  reason: DenialReason;
  label: string;
  /** For a key whose value is one of a few: the choices, and the first is the coded default. */
  choices?: string[];
}[] = [
  //the two secrets guarding the endpoint the panel authenticates to
  { key: "smsg.ops.token", reason: "secret", label: "Ops API token" },
  { key: "smsg.ops.admin.token", reason: "secret", label: "Ops API admin token" },
  //carries a password in its userinfo -- the conf.example line is literally amqp://fireflo:secret@host
  { key: "smsg.queue.amqp.uri", reason: "secret", label: "Message broker address" },

  { key: "smsg.config.source", reason: "config-source", label: "Where configuration is read from" },
  { key: "smsg.properties.file.path", reason: "config-source", label: "Properties file" },
  { key: "smsg.credentials.file.path", reason: "config-source", label: "Credentials file" },
  { key: "smsg.rates.file.path", reason: "config-source", label: "Rates file" },
  { key: "smsg.routing.file.path", reason: "config-source", label: "Routing file" },

  //set on the Queues page since V1.67.0, which also made it a checked choice
  { key: "smsg.queue.provider", reason: "elsewhere", label: "Message broker", choices: ["memory", "rabbitmq"] },
  { key: "smsg.cdr.sink", reason: "wiring", label: "Where call records go" },
  //loosening an SSRF guard from a web form is not an operator convenience
  { key: "smsg.webhook.private.targets", reason: "wiring", label: "Webhooks to private addresses" },
  { key: "smsg.webhook.schemes", reason: "wiring", label: "Webhook URL schemes" },

  { key: "smsg.rates.currency", reason: "elsewhere", label: "Platform currency" },
  { key: "smsg.money.scale", reason: "elsewhere", label: "Decimal places shown" },
  { key: "smsg.billing.zone", reason: "elsewhere", label: "Billing time zone" },

  //the licensing namespace is denied as a prefix in gateway-key-policy.ts; these are the two keys in
  //it today, listed so a database reader sees them
  { key: "smsg.license.server.url", reason: "licensing", label: "Licence server" },
  { key: "smsg.license.directory", reason: "licensing", label: "Licence directory" },
];

/** Settable despite carrying neither writable prefix -- see `LEGACY_WRITABLE` in gateway-key-policy.ts. */
const LEGACY_PLATFORM: readonly { key: string; label: string; kind: KeyKind; choices: string[] | null; codedDefault: string | null }[] = [
  { key: "message.trace.mode", label: "Message trace", kind: "text", choices: null, codedDefault: null },
];

function shape(widget: SettingWidget): Pick<ConfigKeyRow, "kind" | "choices" | "unit"> {
  return {
    kind: widget.kind,
    choices: widget.kind === "enum" ? widget.options.map((o) => o.value) : null,
    unit: widget.kind === "number" ? widget.unit ?? null : null,
  };
}

function build(): ConfigKeyRow[] {
  const rows: ConfigKeyRow[] = [];
  for (const d of DENIED_PLATFORM) {
    rows.push({
      scope: "platform", key: d.key, kind: d.choices ? "enum" : "text", choices: d.choices ?? null, unit: null,
      codedDefault: d.choices?.[0] ?? null,
      secret: d.reason === "secret",
      //a secret is withheld in both directions; every other denial is shown and not written
      access: d.reason === "secret" ? "hidden" : "read-only",
      reason: d.reason, label: d.label,
    });
  }
  for (const f of GATEWAY_SETTING_FIELDS) {
    rows.push({
      scope: "platform", key: f.key, ...shape(f.widget), codedDefault: f.codedDefault,
      secret: f.widget.kind === "secret", access: f.widget.kind === "secret" ? "hidden" : "editable",
      reason: f.widget.kind === "secret" ? "secret" : null, label: f.label,
    });
  }
  for (const l of LEGACY_PLATFORM) {
    rows.push({
      scope: "platform", key: l.key, kind: l.kind, choices: l.choices, unit: null, codedDefault: l.codedDefault,
      secret: false, access: "editable", reason: null, label: l.label,
    });
  }
  for (const key of Object.keys(SETTING_FIELDS) as SettingKey[]) {
    const f = SETTING_FIELDS[key];
    const secret = f.widget.kind === "secret";
    rows.push({
      scope: "worker", key, ...shape(f.widget), codedDefault: f.codedDefault ?? null,
      secret,
      //a worker secret is written through the worker form's own kept/set protocol and never shown;
      //a key another screen owns is still editable -- that is the screen's business, not a denial
      access: secret ? "hidden" : "editable",
      reason: secret ? "secret" : null,
      label: settingLabel(key).label,
    });
  }
  return rows;
}

/** The registry as an index, which is the shape every reader wants. */
export interface ConfigKeyRegistry {
  rows: readonly ConfigKeyRow[];
  platform: ReadonlyMap<string, ConfigKeyRow>;
  worker: ReadonlyMap<string, ConfigKeyRow>;
  /** Where these rows came from, so a screen can say when it is showing the fallback. */
  source: "database" | "builtin";
}

export function registryFrom(rows: readonly ConfigKeyRow[], source: ConfigKeyRegistry["source"]): ConfigKeyRegistry {
  return {
    rows,
    platform: new Map(rows.filter((r) => r.scope === "platform").map((r) => [r.key, r])),
    worker: new Map(rows.filter((r) => r.scope === "worker").map((r) => [r.key, r])),
    source,
  };
}

/** What `app_config_key` was seeded from, and the fallback when it cannot be read. */
export const BUILTIN_REGISTRY: ConfigKeyRegistry = registryFrom(build(), "builtin");

/** Whether a worker setting key holds a credential, by the registry -- the replacement for `SECRET_KEYS`. */
export function isSecretWorkerKey(registry: ConfigKeyRegistry, key: string): boolean {
  return registry.worker.get(key)?.secret ?? false;
}
