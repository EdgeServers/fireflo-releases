import { auth } from "@/lib/auth";
import { isConfigWritable } from "@/lib/config-db";
import { ADMIN_ROLE, OPERATOR_ROLE, isAdminSession, isOperatorSession } from "@/lib/roles";
import { liveRole } from "@/lib/users";

/**
 * The gate every control route passes through.
 *
 * <p>Every API route calls this as its first statement. Hiding a nav item is presentation; this is
 * the control. The data behind these routes is margin and vendor names, so an unauthenticated
 * caller must get nothing, and must not learn that there was something to get.
 *
 * <h2>Why this checks the role and not just the session</h2>
 *
 * <p>It used to ask only whether a session had a name, which was correct while an operator was the
 * only identity this application could issue. The customer portal changed that. A customer holds a
 * real, valid, signed session -- and under the old check it would have satisfied this function and
 * opened every control route: margin, vendor names, every account's messages, credential editing.
 *
 * <p><strong>Do not weaken this back to a presence check.</strong> The decision lives in
 * {@link isOperatorSession}, and `lib/roles.test.ts` fails if it is loosened.
 *
 * <h2>Why it also reads the row</h2>
 *
 * <p>The session is a JWT and nothing re-signs it. An operator disabled an hour ago still holds a
 * valid cookie, so the role and the enabled flag are read fresh from `app_user` on every call --
 * the rule `requireCustomer` already applies to `app_account.enabled`. The env-fallback operator
 * (`userId` null) has no row to read and is admitted on the token alone, which is the one-release
 * break-glass `lib/auth.ts` describes.
 */

export interface OperatorIdentity {
  /** The `app_user.id`, or null for the deprecated env-fallback operator. */
  userId: number | null;
  /** The address they signed in with. What the audit log calls the actor. */
  name: string;
  role: typeof ADMIN_ROLE | typeof OPERATOR_ROLE;
}

/**
 * @throws NotOperatorError which the route turns into a 404 rather than a 403 -- a 403 confirms
 *     the endpoint exists, which is more than an anonymous caller needs to know
 */
export async function requireOperator(): Promise<OperatorIdentity> {
  const session = await auth();
  if (!isOperatorSession(session)) {
    throw new NotOperatorError();
  }
  const user = session!.user;
  const userId = user.userId == null ? null : Number(user.userId);
  let role = user.role as OperatorIdentity["role"];

  if (userId !== null && isConfigWritable()) {
    const live = await liveRole(userId);
    //gone, disabled, or moved to the portal side: the cookie is still valid and the person is not
    if (!live || !live.enabled || (live.role !== ADMIN_ROLE && live.role !== OPERATOR_ROLE)) {
      throw new NotOperatorError();
    }
    //a demotion applies on the next request, not at the next sign-in
    role = live.role;
  }
  return { userId, name: user.name!, role };
}

/**
 * As {@link requireOperator}, and additionally that this is an admin.
 *
 * <p>Refused with the same {@link NotOperatorError}: an operator has no business learning that the
 * user-management routes exist, any more than an anonymous caller does.
 */
export async function requireAdmin(): Promise<OperatorIdentity> {
  const identity = await requireOperator();
  if (identity.role !== ADMIN_ROLE) {
    throw new NotOperatorError();
  }
  return identity;
}

/** For pages: the session check alone, without the fresh read. Routes use {@link requireAdmin}. */
export { isAdminSession };

export class NotOperatorError extends Error {
  constructor() {
    super("Not found");
    this.name = "NotOperatorError";
  }
}
