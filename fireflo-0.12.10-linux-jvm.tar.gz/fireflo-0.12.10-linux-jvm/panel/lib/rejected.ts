import { query } from "@/lib/metrics-db";
import type { RejectedCursor, RejectedFilters } from "@/lib/rejected-request";
import { REFUSED_AFTER_ACCEPTING, type RejectedRow, type RejectedSummary } from "@/lib/rejected-types";

/**
 * Messages the gateway refused.
 *
 * <p>Server-only: importing this pulls `pg`. The filter vocabulary lives in `rejected-request.ts`,
 * which a client component may import; the dependency runs that way and never back.
 *
 * <p><strong>Why this is a separate table and a separate query rather than a filter on `/cdrs`.</strong>
 * A refused message was never submitted — no gateway message id, no vendor, no price, no receipt.
 * It shares almost no columns with `cdr_submit`, and folding it in would have made every traffic
 * count and revenue sum wrong by exactly the refusals, which for an enforced account can be most of
 * its attempts.
 *
 * <p>Every filter value is a bind parameter, as in `cdr-queries.ts`: no caller string reaches the
 * SQL text.
 *
 * <p><strong>Two functions, not one.</strong> The rows are paged and the summary is not, and keeping
 * them separate makes that structural rather than a comment somebody has to read: {@link
 * summariseRejected} takes no cursor, so it cannot acquire one, and {@link listRejected} takes no
 * sample limit, so a sampled row list — a page presented as if it were the whole window — is not
 * something a caller can ask for by accident.
 */

/**
 * The most rows one call may return.
 *
 * <p>Deliberately far above anything a browser asks for. The page cap belongs to the route, because
 * the export worker is the other caller and legitimately asks for thousands at a time; clamping here
 * would silently cut its batches to a browser page and multiply its round trips. This exists only so
 * that a caller cannot ask for the whole table in one statement.
 */
export const MAX_BATCH = 5_000;

/** Where each query's parameters are built. Never shared between two of them — see the note below. */
function buildWhere(filters: RejectedFilters): { sql: string; params: unknown[] } {
  const where: string[] = [];
  const params: unknown[] = [];

  /** Binds a value and returns its placeholder, so `$n` is always derived from the array length. */
  const bind = (value: unknown): string => {
    params.push(value);
    return `$${params.length}`;
  };

  //defaults to the last 24 hours rather than to everything: this table has no natural bound and a
  //bare SELECT over it gets slower every day the gateway runs
  where.push(`rejected_at >= ${bind(filters.since ?? new Date(Date.now() - 86_400_000))}`);
  if (filters.until) {
    where.push(`rejected_at < ${bind(filters.until)}`);
  }

  for (const [column, value] of [
    ["reason", filters.reason],
    ["account_id", filters.accountId],
    ["system_id", filters.systemId],
    ["product", filters.product],
    ["ingress", filters.ingress],
    ["in_gateway", filters.inGateway],
    ["gateway_msg_id", filters.gatewayMsgId],
  ] as const) {
    if (value) {
      where.push(`${column} = ${bind(value)}`);
    }
  }

  //prefix rather than exact, because these are the two fields somebody types a fragment of: a
  //country code, a short-code stem, a sender ID they only remember the front of
  for (const [column, value] of [
    ["source_addr", filters.sourceAddr],
    ["dest_addr", filters.destAddr],
  ] as const) {
    if (value) {
      where.push(`${column} LIKE ${bind(`${escapeLike(value)}%`)} ESCAPE '\\'`);
    }
  }

  if (filters.vendorStatus != null) {
    where.push(`vendor_status = ${bind(filters.vendorStatus)}`);
  }

  if (filters.hasMsgId) {
    //NOT NULL alone is wrong here, and quietly so. The gateway initialises a message's serial to an
    //empty string and writes it through unchecked, so most door refusals store '' rather than NULL
    //-- and the partial index on this column is full of them
    where.push(`gateway_msg_id IS NOT NULL AND gateway_msg_id <> ''`);
  }

  if (filters.afterAccepting) {
    where.push(`reason = ANY(${bind([...REFUSED_AFTER_ACCEPTING])})`);
  }

  const search = filters.search?.trim();
  if (search) {
    //one bind parameter reused across the columns rather than one per column: the same value, and a
    //single $n keeps the list aligned with the numbering above. % and _ are escaped so a phone
    //number search does not silently become a wildcard
    const n = bind(`%${escapeLike(search)}%`);
    where.push(
      `(account_id ILIKE ${n} ESCAPE '\\' OR source_addr ILIKE ${n} ESCAPE '\\'
        OR dest_addr ILIKE ${n} ESCAPE '\\' OR product ILIKE ${n} ESCAPE '\\'
        OR system_id ILIKE ${n} ESCAPE '\\' OR detail ILIKE ${n} ESCAPE '\\'
        OR body_excerpt ILIKE ${n} ESCAPE '\\')`
    );
  }

  return { sql: `WHERE ${where.join(" AND ")}`, params };
}

function escapeLike(value: string): string {
  return value.replace(/[%_\\]/g, (c) => `\\${c}`);
}

interface RejectedDbRow {
  id: string;
  rejected_at: Date;
  reason: string;
  detail: string | null;
  account_id: string | null;
  system_id: string | null;
  product: string | null;
  ingress: string | null;
  in_gateway: string | null;
  source_addr: string | null;
  dest_addr: string | null;
  body_excerpt: string | null;
  dcs: number | null;
  parts: number | null;
  gateway_msg_id: string | null;
  vendor_status: number | null;
  receipt: string | null;
}

/**
 * One page of refusals, newest first.
 *
 * <p>Keyset rather than OFFSET, on `(rejected_at, id)` — which is the sort order and the shape of
 * `idx_cdr_rejected_time_reason` (V1.53.0 dropped its uncovered twin), so paging costs an index
 * seek rather than a growing scan. One extra row is asked for and thrown away, which is how the
 * caller learns there is more without a `COUNT(*)`
 * over the whole window.
 */
export async function listRejected(
  filters: RejectedFilters = {},
  opts: { limit?: number; cursor?: RejectedCursor | null } = {}
): Promise<{ rows: RejectedRow[]; nextCursor: RejectedCursor | null }> {
  const { sql, params } = buildWhere(filters);
  const size = Math.min(Math.max(1, Math.floor(opts.limit ?? 50)), MAX_BATCH);

  let keyset = "";
  if (opts.cursor) {
    params.push(opts.cursor.rejectedAt, opts.cursor.id);
    //row-wise comparison rather than two ORed predicates: it matches the ORDER BY exactly, so the
    //planner walks the index instead of filtering after the fact
    keyset = ` AND (rejected_at, id) < ($${params.length - 1}::timestamptz, $${params.length}::bigint)`;
  }
  params.push(size + 1);

  const rows = await query<RejectedDbRow>(
    `SELECT id::text, rejected_at, reason, detail, account_id, system_id, product,
            ingress, in_gateway, source_addr, dest_addr, body_excerpt, dcs, parts,
            gateway_msg_id, vendor_status, receipt
       FROM cdr_rejected
       ${sql}${keyset}
      ORDER BY rejected_at DESC, id DESC
      LIMIT $${params.length}`,
    params
  );

  const page = rows.slice(0, size).map(toRow);
  const last = page[page.length - 1];
  return {
    rows: page,
    nextCursor:
      rows.length > size && last ? { rejectedAt: last.rejectedAt, id: last.id } : null,
  };
}

/**
 * A count per reason, over the whole window.
 *
 * <p>The number an operator actually wants first — "is this one customer or everybody, one reason or
 * several" — so it is computed over the window rather than over a page, which would just describe
 * the page. There is deliberately no cursor parameter: see the note at the top of this file.
 */
export async function summariseRejected(
  filters: RejectedFilters = {},
  opts: {
    /**
     * Cap the aggregate at the most recent N refusals rather than the whole window.
     *
     * <p>Undefined means "count the window", which is what the Refused page wants and can afford: it
     * is index-only since `idx_cdr_rejected_time_reason`.
     *
     * <p>The Delivery check passes a number. Its aggregate was time-bounded but otherwise unbounded,
     * and once 24 hours grew past roughly a tenth of the table the planner abandoned the index and
     * read all of it — on a large `cdr_rejected` that is gigabytes of heap I/O holding one of only
     * eight metrics connections until the 10s statement timeout kills it. A sample is O(N) whatever
     * the table does.
     *
     * <p>A caller that samples MUST say so on screen. A sampled number presented as a total is worse
     * than no number at all.
     */
    sampleLimit?: number;
  } = {}
): Promise<{ summary: RejectedSummary[]; total: number }> {
  const { sql, params } = buildWhere(filters);

  //the sampled form wraps the scan in a bounded subquery, so the row count it groups over is fixed
  //no matter how large the window turns out to be
  const sampled = opts.sampleLimit != null && opts.sampleLimit > 0;
  const cap = sampled ? Math.min(Math.max(1, Math.floor(opts.sampleLimit!)), 100_000) : 0;
  const summary = await query<{ reason: string; count: string }>(
    sampled
      ? `SELECT reason, count(*)::text AS count FROM (
           SELECT reason FROM cdr_rejected ${sql}
            ORDER BY rejected_at DESC LIMIT ${cap}
         ) s GROUP BY reason ORDER BY count(*) DESC`
      : `SELECT reason, count(*)::text AS count FROM cdr_rejected ${sql}
          GROUP BY reason ORDER BY count(*) DESC`,
    params
  );

  return {
    summary: summary.map((s): RejectedSummary => ({ reason: s.reason, count: Number(s.count) })),
    total: summary.reduce((sum, s) => sum + Number(s.count), 0),
  };
}

function toRow(r: RejectedDbRow): RejectedRow {
  return {
    id: r.id,
    rejectedAt: r.rejected_at.toISOString(),
    reason: r.reason,
    detail: r.detail,
    accountId: r.account_id,
    systemId: r.system_id,
    product: r.product,
    ingress: r.ingress,
    inGateway: r.in_gateway,
    sourceAddr: r.source_addr,
    destAddr: r.dest_addr,
    bodyExcerpt: r.body_excerpt,
    dcs: r.dcs,
    parts: r.parts,
    gatewayMsgId: r.gateway_msg_id,
    vendorStatus: r.vendor_status,
    receipt: r.receipt,
  };
}

export type { RejectedCursor, RejectedFilters } from "@/lib/rejected-request";
