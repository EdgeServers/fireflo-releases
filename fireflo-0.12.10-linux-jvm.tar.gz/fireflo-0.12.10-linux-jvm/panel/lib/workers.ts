import { ConfigRefusal } from "@/lib/config-guard";
import { configQuery, inTransaction } from "./config-db";
import { isSecretWorkerKey } from "./config-key-registry";
import { loadConfigKeyRegistry } from "./config-key-registry-db";
import { looksSensitive } from "./gateway-key-policy";
import { dropReceiptRuleIn, reconcileReceiptRulesIn } from "./routing";
import {
  REDACTED,
  type Worker,
  type WorkerInput,
  type WorkerProperty,
  type WorkerType,
} from "./worker-types";

/**
 * Reading and writing workers — vendors and servers alike.
 *
 * <p>Server-only: this imports the database pool. The shapes and the validation live in
 * `worker-types` so a client component can use them without pulling `pg` in with them.
 *
 * <p>Named for the table rather than for either of the two words the interface uses. `app_worker`
 * holds both kinds, and calling this module `vendors` would make the code disagree with the schema
 * it writes to.
 */
interface WorkerRow {
  name: string;
  type: WorkerType;
  enabled: boolean;
  label: string | null;
}

interface PropertyRow {
  worker_name: string;
  key: string;
  value: string | null;
}

/**
 * Workers with their settings, optionally of one kind only.
 *
 * <p>Secrets come back as a placeholder rather than as themselves. A bind password has no business
 * in a browser, and the edit path treats the placeholder as "leave it alone" so a round trip cannot
 * overwrite one with asterisks.
 */
export async function listWorkers(type?: WorkerType): Promise<Worker[]> {
  const [workers, properties] = await Promise.all([
    type
      ? configQuery<WorkerRow>(
          "SELECT name, type, enabled, label FROM app_worker WHERE type = $1 ORDER BY name",
          [type]
        )
      : configQuery<WorkerRow>("SELECT name, type, enabled, label FROM app_worker ORDER BY name"),
    configQuery<PropertyRow>(
      "SELECT worker_name, key, value FROM app_worker_property ORDER BY worker_name, key"
    ),
  ]);

  //app_config_key decides which settings are credentials (gateway V1.61.0), and the name rule the
  //gateway masks by covers a key the registry has never heard of -- a free-form "apiKey" a vendor
  //needed. This used to be a two-entry list of its own, which is how a secret gets past one masker
  const registry = await loadConfigKeyRegistry();
  const byWorker = new Map<string, WorkerProperty[]>();
  for (const row of properties) {
    const list = byWorker.get(row.worker_name) ?? [];
    const secret = isSecretWorkerKey(registry, row.key) || looksSensitive(row.key);
    list.push({
      key: row.key,
      value: secret ? REDACTED : row.value ?? "",
    });
    byWorker.set(row.worker_name, list);
  }

  return workers.map((w) => ({ ...w, properties: byWorker.get(w.name) ?? [] }));
}

/**
 * Which ports listeners already hold, so a new one can be offered a free number.
 *
 * <p>Reads `srv.port` rather than the gateway's live sockets on purpose: what matters when choosing
 * a port is what is configured, including listeners that are disabled or currently failing to bind.
 * A port belonging to a stopped listener is still spoken for, and handing it out again would make
 * the two collide the day somebody enables it.
 *
 * @returns the listener name and port for every server worker that declares one
 */
export async function listListenerPorts(): Promise<{ name: string; port: number }[]> {
  const rows = await configQuery<{ worker_name: string; value: string | null }>(
    `SELECT p.worker_name, p.value
       FROM app_worker_property p
       JOIN app_worker w ON w.name = p.worker_name
      WHERE p.key = 'srv.port' AND w.type = 'smppserver'
      ORDER BY p.worker_name`
  );
  return rows
    .map((r) => ({ name: r.worker_name, port: Number(r.value ?? "") }))
    //0 means "this listener does not start", so it is not holding a port
    .filter((r) => Number.isInteger(r.port) && r.port > 0);
}

/**
 * Creates or replaces one worker and its settings.
 *
 * <p>Settings are deleted and re-inserted rather than merged, so clearing a field in the form
 * actually removes it — a merge would leave an orphaned setting behind that still applies. The
 * placeholder value is the one exception: it means the stored secret is kept.
 */
export async function saveWorker(input: WorkerInput): Promise<void> {
  await inTransaction(async (client) => {
    await client.query(
      `INSERT INTO app_worker (name, type, enabled, label, updated_at)
       VALUES ($1, $2, $3, $4, now())
       ON CONFLICT (name) DO UPDATE
         SET type = EXCLUDED.type, enabled = EXCLUDED.enabled,
             label = EXCLUDED.label, updated_at = now()`,
      [input.name, input.type, input.enabled, input.label?.trim() || null]
    );

    const kept = await client.query<PropertyRow>(
      "SELECT worker_name, key, value FROM app_worker_property WHERE worker_name = $1",
      [input.name]
    );
    const existing = new Map(kept.rows.map((r) => [r.key, r.value ?? ""]));

    await client.query("DELETE FROM app_worker_property WHERE worker_name = $1", [input.name]);

    for (const property of input.properties) {
      const key = property.key.trim();
      const value = property.value === REDACTED ? existing.get(key) ?? "" : property.value;
      if (value === "") {
        //an empty field means "unset", not "set to the empty string" -- the gateway would read the
        //latter as a real value and skip its coded default
        continue;
      }
      await client.query(
        "INSERT INTO app_worker_property (worker_name, key, value) VALUES ($1, $2, $3)",
        [input.name, key, value]
      );
    }

    //a listener and its receipt rule are committed together, so there is no moment in which its
    //customers' receipts have nowhere to go. Saving an existing listener repairs one that never had
    //a rule, which is every listener added before this
    if (input.type === "smppserver") {
      await reconcileReceiptRulesIn(client);
    }
  });
}

export async function setWorkerEnabled(name: string, enabled: boolean): Promise<boolean> {
  const rows = await configQuery<{ name: string }>(
    "UPDATE app_worker SET enabled = $2, updated_at = now() WHERE name = $1 RETURNING name",
    [name, enabled]
  );
  return rows.length > 0;
}

/**
 * Sets or clears one setting, leaving the rest of the worker alone.
 *
 * <p>For `suspend` and `pause`, which are how traffic is stopped and held. Those go through here
 * rather than through {@link saveWorker} because that one replaces every setting, and stopping a
 * vendor in a hurry must not depend on the browser holding a complete and current copy of its
 * configuration — with a redacted password among it.
 *
 * <p>An empty value deletes the row instead of storing `""`. The gateway reads an empty string as a
 * real value and skips its own default, so "off" has to mean absent.
 *
 * @returns false when there is no such worker
 */
export async function setWorkerProperty(
  name: string,
  key: string,
  value: string
): Promise<boolean> {
  return inTransaction(async (client) => {
    const worker = await client.query<{ name: string }>(
      "UPDATE app_worker SET updated_at = now() WHERE name = $1 RETURNING name",
      [name]
    );
    if (!worker.rows.length) {
      return false;
    }
    if (value === "") {
      await client.query("DELETE FROM app_worker_property WHERE worker_name = $1 AND key = $2", [
        name,
        key,
      ]);
    } else {
      await client.query(
        `INSERT INTO app_worker_property (worker_name, key, value) VALUES ($1, $2, $3)
         ON CONFLICT (worker_name, key) DO UPDATE SET value = EXCLUDED.value`,
        [name, key, value]
      );
    }
    return true;
  });
}

/**
 * Deletes a vendor or listener that nothing routes to.
 *
 * <p>Since gateway migration V1.57.0 a vendor-group member is a foreign key to the vendor, and
 * since V1.58.0 so is a route rule's target, both ON DELETE RESTRICT. The delete used to go
 * through and leave those pointing at nothing -- the gateway then logged an unknown target once
 * per rule and every message reaching it fell through. Asking first turns the refusal into a
 * sentence that says where to look.
 *
 * @throws ConfigRefusal naming the groups and routing tables that still use it
 */
export async function deleteWorker(name: string): Promise<boolean> {
  return inTransaction(async (client) => {
    //its own receipt rule goes with it; checking first would find that rule and refuse
    await dropReceiptRuleIn(client, name);
    const { rows: [use] } = await client.query<{ groups: string[] | null; tables: string[] | null }>(
      `SELECT (SELECT array_agg(DISTINCT group_name ORDER BY group_name) FROM app_route_group_member
                WHERE worker_name = $1) AS groups,
              (SELECT array_agg(DISTINCT table_name ORDER BY table_name) FROM app_route_rule
                WHERE target IN ($1, 'smppclient.' || $1, 'smppserver.' || $1)) AS tables`,
      [name]
    );
    const where = [
      use?.groups?.length ? `vendor group ${use.groups.map((g) => `'${g}'`).join(", ")}` : null,
      use?.tables?.length ? `routing table ${use.tables.map((t) => `'${t}'`).join(", ")}` : null,
    ].filter(Boolean);
    if (where.length) {
      throw new ConfigRefusal(
        `'${name}' is still used by ${where.join(" and ")}. Take it out of those first, or disable it instead.`
      );
    }
    //app_worker_property cascades on the foreign key, so the settings go with it
    const rows = await client.query<{ name: string }>(
      "DELETE FROM app_worker WHERE name = $1 RETURNING name",
      [name]
    );
    return rows.rows.length > 0;
  });
}
