import type { NextConfig } from "next";
import { version } from "./package.json";

const nextConfig: NextConfig = {
  // pg ships native bindings; leaving it unbundled is what the sibling panel does too
  serverExternalPackages: ["pg"],
  // The version shown beside the mark, read from package.json at build time so the two cannot
  // disagree. A hand-kept copy in a component is a string nobody remembers to bump on release.
  //
  // The panel is versioned AGAINST THE GATEWAY: the first three numbers are whatever gateway
  // release this panel goes with, and only move when that does. A panel-only change adds a fourth
  // number instead, so 0.4.1.1 reads as "the panel that pairs with gateway 0.4.1, first revision".
  //
  // package.json cannot hold four numbers -- npm requires valid semver, which is exactly three --
  // so the file carries it as build metadata, "0.4.1+1", which npm accepts and preserves verbatim.
  // This turns it back into the four-number form for display. One source of truth, two spellings,
  // and the conversion in the one place that reads it.
  env: { NEXT_PUBLIC_APP_VERSION: version.replace("+", ".") },
};

export default nextConfig;
