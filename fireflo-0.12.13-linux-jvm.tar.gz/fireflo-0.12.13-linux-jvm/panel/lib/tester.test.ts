import { test } from "node:test";
import assert from "node:assert/strict";
import { deciding, destinationCondition, missingPriceText, neverRunsIn, nextTable, prefillFrom, prefillParams, productUsedText, suggestPrefix, vendorOf, type RatingAnswer } from "./tester.ts";

test("a suggestion starts from the country code as typed, '+' kept", () => {
  assert.equal(suggestPrefix("+447700900123"), "+44");
  assert.equal(suggestPrefix("919812345678"), "91");
  assert.equal(suggestPrefix("+14155550100"), "+1");
  assert.equal(suggestPrefix("0091 98123"), "91");
  assert.equal(suggestPrefix(""), "");
});

test("the pre-fill survives the round trip through the address", () => {
  const condition = destinationCondition("+447700900123");
  const params = new URLSearchParams(prefillParams(condition, { product: "sms" }));
  assert.equal(params.get("new"), "1");
  assert.equal(params.get("product"), "sms");
  assert.deepEqual(prefillFrom(params), { field: "to", operator: "startsWith", value: "+44", negate: false });
  assert.equal(prefillFrom(new URLSearchParams("new=1")), null);
});

test("routing is followed into another table, and a client worker is the vendor", () => {
  assert.equal(nextTable("MESSAGE", ["default", "MESSAGE"]), "MESSAGE");
  assert.equal(nextTable("smppclient.smppsim", ["default", "MESSAGE"]), null);
  assert.equal(vendorOf("smppclient.smppsim"), "smppclient.smppsim");
  assert.equal(vendorOf("smppsim"), "smppsim", "rules usually name a vendor by its short name");
  assert.equal(vendorOf("smppserver.smpp"), null);
  assert.equal(vendorOf("@dnd"), null);
  assert.equal(vendorOf("MESSAGE", ["MESSAGE"]), null);
});

test("a matching preprocessor rule runs and the scan carries on, as the router does", () => {
  const rules = [
    { index: 1, target: "@tlv", matched: false, evaluable: true },
    { index: 2, target: "@dnd", matched: true, evaluable: true },
    { index: 3, target: "smppsim", matched: true, evaluable: true },
  ];
  assert.equal(deciding(rules)?.index, 3);
  assert.equal(deciding(rules.slice(0, 2)), null);
});


test("a 'used by' line in a table nothing reaches is picked out", () => {
  assert.equal(neverRunsIn("routing: sample · rule 1014", ["sample"]), "sample");
  assert.equal(neverRunsIn("routing: MESSAGE · india", ["sample"]), null);
  assert.equal(neverRunsIn("price: Default · transactional", ["Default"]), null);
});

const unpriced = (over: Partial<RatingAnswer> = {}): RatingAnswer => ({ active: true, parts: 1, price: null, vendor: null, cost: null, ...over });

test("the tester says which product it ran as, and why a price is missing", () => {
  //the report: one "everything else on test-pro" rule on Everyone, the Product box blank, "No price"
  assert.equal(productUsedText({ product: "test-pro", product_from: "login" }, "omni"),
    "Tested as product 'test-pro', from omni's login — what its messages carry.");
  assert.equal(productUsedText({ product: null, product_from: "none" }, "probe"), "Tested with no product: probe's logins carry none.");
  assert.equal(productUsedText({}, "omni"), null, "an older gateway says nothing");

  const forAnotherProduct = unpriced({ product: null, product_from: "none", products_with_rules: ["test-pro"] });
  assert.match(missingPriceText(forAnotherProduct, "probe"), /no product for probe, but rules exist for 'test-pro'/);
  const ambiguous = unpriced({ product_from: "ambiguous", login_products: ["a", "b"], products_with_rules: ["a"] });
  assert.match(missingPriceText(ambiguous, "omni"), /several products \(a, b\)/);
  assert.match(missingPriceText(unpriced({ product: "test-pro", products_with_rules: ["test-pro"] }), "omni"), /^Neither omni's own pricing/);
  //no account: the gateway answers with Everyone's default, so a miss means Everyone has none
  assert.match(missingPriceText(unpriced(), ""), /^Everyone has no default rule/);
  assert.equal(missingPriceText(unpriced({ active: false }), ""), "Choose an account to see its price.");
});
