"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { SettingsRow } from "@/components/ui/settings-row";
import { SettingsSection } from "@/components/ui/settings-section";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { HealthStrip } from "./CardBits";
import { useDisplayZone } from "@/components/DisplayZoneProvider";
import { count } from "@/lib/format";
import { formatDay, formatTimestamp } from "@/lib/datetime";
import { accountHref } from "@/lib/panel-surface";
import {
  ownLimit,
  unitEntryLabel,
  UNIT_USAGE_DAYS,
  type UnitAllowance,
  type UnitLedgerEntry,
  type UnitLedgerPage,
  type UnitsAvailability,
  type UnitsLogin,
  type UnitsRate,
  type UnitUsage,
} from "@/lib/units-types";

/**
 * The pieces of a units account's pages (gateway 0.16.0): its units per product, what it used, its
 * unit ledger and its own speed limits. Read-only: units are given by the platform that manages the
 * account, so nothing here offers to change them.
 */

/** A units count with its sign, for the ledger: +500, −200. */
function signed(units: number): string {
  return units > 0 ? `+${count(units)}` : units < 0 ? `−${count(-units)}` : "0";
}

/**
 * Why units accounts do not work here now, when the database can tell: a live node older than
 * 0.16.0, or prepaid enforcement stored as off. Nothing when neither is known.
 */
export function UnitsAvailabilityStrip({
  availability,
  existing,
}: {
  availability: UnitsAvailability | null;
  /** True on a units account's own page: its logins are affected now, not just new accounts. */
  existing: boolean;
}) {
  if (!availability) {
    return null;
  }
  const { olderNodes, enforcementOff } = availability;
  if (!olderNodes.length && !enforcementOff) {
    return null;
  }
  return (
    <div className="space-y-2">
      {olderNodes.length > 0 && (
        <HealthStrip tone={existing ? "destructive" : "warning"}>
          {olderNodes.length === 1 ? "A gateway node runs" : "Gateway nodes run"} a release older than 0.16.0:{" "}
          {olderNodes.join(", ")}.{" "}
          {existing
            ? "Such a node does not count units, so this account's messages are refused there. "
            : ""}
          Units accounts can be made and given units only once every live node runs 0.16.0 or later.
        </HealthStrip>
      )}
      {enforcementOff && (
        <HealthStrip tone={existing ? "destructive" : "warning"}>
          Prepaid credit is switched off (<code className="font-mono">smsg.balance.enabled</code> is false), so units are
          not counted. {existing ? "This account's logins are not loaded, and " : ""}No units account can be made or given
          units until it is on.
        </HealthStrip>
      )}
    </div>
  );
}

/** Units per product: left, used, and whether the product is out or switched off. */
export function UnitAllowanceTable({ allowances }: { allowances: UnitAllowance[] }) {
  if (!allowances.length) {
    return (
      <p className="text-sm text-muted-foreground">
        No units given yet. Its logins cannot send until the platform that manages it gives units of their product.
      </p>
    );
  }
  return (
    <TableInCard>
      <THead>
        <TR>
          <TH>Product</TH>
          <TH align="right">Left</TH>
          <TH align="right">Used</TH>
          <TH>State</TH>
        </TR>
      </THead>
      <TBody>
        {allowances.map((a) => (
          <TR key={a.product}>
            <TD primary>{a.product}</TD>
            <TD num>{count(a.left)}</TD>
            <TD num muted>{count(a.used)}</TD>
            <TD><UnitState allowance={a} /></TD>
          </TR>
        ))}
      </TBody>
    </TableInCard>
  );
}

export function UnitState({ allowance }: { allowance: UnitAllowance }) {
  if (!allowance.enabled) {
    return <Badge variant="outline" title="No gateway node takes units from it; what nodes already hold is still used.">off</Badge>;
  }
  if (allowance.left <= 0) {
    return <Badge variant="destructive" title="Its logins' messages of this product are refused: no units left.">no units</Badge>;
  }
  return <Badge variant="success">on</Badge>;
}

/** The hint every units figure carries once: what "left" counts. */
export const LEFT_HINT =
  "Left is what can still be sent: units not yet handed out, plus units gateway nodes hold and have not used. "
  + "Used units are settled every few seconds, so a busy account's figures move a little behind its traffic.";

/**
 * Units used this month and over the last days, per product, from the gateway's hourly unit summary,
 * with the way to the messages themselves: those are recorded under the parent, which pays, and the
 * login that sent them.
 */
export function UnitUsageCard({
  usage,
  parent,
  logins,
}: {
  usage: UnitUsage | null;
  parent: string | null;
  logins: UnitsLogin[];
}) {
  const days = usage?.days ?? [];
  return (
    <Card className="min-w-0">
      <CardHeader bar>
        <CardTitle>Units used</CardTitle>
        <CardDescription>
          One unit per message part. Units come back for a message that was refused or expired after it was accepted.
          Days are in the billing time zone.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {!usage ? (
          <p className="text-sm text-muted-foreground">The usage could not be read.</p>
        ) : !usage.month.length && !days.length ? (
          <p className="py-4 text-center text-sm text-muted-foreground">Nothing sent in the last {UNIT_USAGE_DAYS} days.</p>
        ) : (
          <>
            <TableInCard>
              <THead>
                <TR>
                  <TH>This month</TH>
                  <TH align="right">Messages</TH>
                  <TH align="right">Units used</TH>
                  <TH align="right">Units returned</TH>
                </TR>
              </THead>
              <TBody>
                {usage.month.map((m) => (
                  <TR key={m.product}>
                    <TD primary>{m.product}</TD>
                    <TD num>{count(m.messages)}</TD>
                    <TD num>{count(m.used)}</TD>
                    <TD num muted>{count(m.refunded)}</TD>
                  </TR>
                ))}
                {!usage.month.length && (
                  <TR><TD colSpan={4} className="text-muted-foreground">Nothing sent this month.</TD></TR>
                )}
              </TBody>
            </TableInCard>
            {days.length > 0 && (
              <TableInCard>
                <THead>
                  <TR>
                    <TH>Day</TH>
                    <TH>Product</TH>
                    <TH align="right">Messages</TH>
                    <TH align="right">Units used</TH>
                    <TH align="right">Units returned</TH>
                  </TR>
                </THead>
                <TBody>
                  {days.map((d) => (
                    <TR key={`${d.day}-${d.product}`}>
                      <TD className="whitespace-nowrap">{formatDay(d.day)}</TD>
                      <TD muted>{d.product}</TD>
                      <TD num>{count(d.messages)}</TD>
                      <TD num>{count(d.used)}</TD>
                      <TD num muted>{count(d.refunded)}</TD>
                    </TR>
                  ))}
                </TBody>
              </TableInCard>
            )}
          </>
        )}
        {parent && logins.length > 0 && (
          <p className="text-xs text-muted-foreground">
            Its messages are recorded under <Link href={accountHref(parent)} className="underline underline-offset-2">{parent}</Link>,
            which pays for them, and the login that sent them. Messages:{" "}
            {logins.map((l, i) => (
              <span key={l.systemId}>
                {i > 0 && " · "}
                <Link
                  href={`/cp/cdrs?account=${encodeURIComponent(parent)}&systemId=${encodeURIComponent(l.systemId)}`}
                  className="font-mono text-primary hover:underline"
                >
                  {l.systemId}
                </Link>
              </span>
            ))}
            . Refused:{" "}
            {logins.map((l, i) => (
              <span key={l.systemId}>
                {i > 0 && " · "}
                <Link
                  href={`/cp/rejected?account=${encodeURIComponent(parent)}&systemId=${encodeURIComponent(l.systemId)}`}
                  className="font-mono text-primary hover:underline"
                >
                  {l.systemId}
                </Link>
              </span>
            ))}
            .
          </p>
        )}
      </CardContent>
    </Card>
  );
}

/** Every change to what the account was given, newest first, a page at a time. */
export function UnitLedgerCard({ id }: { id: string }) {
  const { zone, short } = useDisplayZone();
  const [entries, setEntries] = useState<UnitLedgerEntry[]>([]);
  const [next, setNext] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchPage = useCallback(async (before: string | null) => {
    try {
      const q = before ? `?before=${encodeURIComponent(before)}` : "";
      const res = await fetch(`/api/control/accounts/${encodeURIComponent(id)}/units/ledger${q}`, { cache: "no-store" });
      const json = await res.json().catch(() => null);
      if (!res.ok || !json?.data) {
        setError(json?.error ?? "The unit ledger could not be read.");
        return;
      }
      setError(null);
      const page = json.data as UnitLedgerPage;
      setEntries((prev) => (before ? prev.concat(page.entries) : page.entries));
      setNext(page.next);
    } catch {
      setError("Could not reach the panel.");
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    void fetchPage(null);
  }, [fetchPage]);

  return (
    <Card>
      <CardHeader bar>
        <CardTitle>Unit ledger</CardTitle>
        <CardDescription>
          Units given, taken back and moved between this reseller&apos;s accounts, all by the platform that manages
          them. Units used are not listed here; they are under Units used.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-2">
        {error && <p className="text-sm text-destructive">{error}</p>}
        {!loading && !error && !entries.length && (
          <p className="py-4 text-center text-sm text-muted-foreground">Nothing given yet.</p>
        )}
        {entries.length > 0 && (
          <TableInCard>
            <THead>
              <TR>
                <TH>When ({short})</TH>
                <TH>What</TH>
                <TH>Product</TH>
                <TH align="right">Units</TH>
                <TH>Reference</TH>
              </TR>
            </THead>
            <TBody>
              {entries.map((e) => (
                <TR key={e.id}>
                  <TD muted className="whitespace-nowrap" suppressHydrationWarning>{formatTimestamp(e.createdAt, zone)}</TD>
                  <TD>
                    {unitEntryLabel(e.entryType, e.counterparty)}
                    {e.note && <span className="block text-xs text-muted-foreground">{e.note}</span>}
                  </TD>
                  <TD muted>{e.product}</TD>
                  <TD num className={e.units < 0 ? "text-destructive" : "text-success"}>{signed(e.units)}</TD>
                  <TD muted className="max-w-48 truncate font-mono text-xs" title={e.reference}>{e.reference}</TD>
                </TR>
              ))}
            </TBody>
          </TableInCard>
        )}
        {(next || loading) && (
          <div className="pt-1 text-center">
            <Button size="sm" variant="ghost" disabled={loading} onClick={() => { setLoading(true); void fetchPage(next); }}>
              {loading ? "Reading…" : "Older"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/** A stored ceiling in words. */
function limitText(raw: string | null): string {
  const n = ownLimit(raw);
  return n === null ? "No limit of its own" : `${count(n)} msg/s`;
}

/**
 * The units account's own speed limits, each explained: the key, its scope, what it limits, how it
 * sits with the parent's limit and a login's own TPS, and what a sender over it is answered.
 * Read-only here: the platform sets them (setAccountRate), and an SMPP ceiling per listener is set on
 * the Limits page.
 */
export function UnitSpeedLimitCard({ id, parent, rate }: { id: string; parent: string | null; rate: UnitsRate | null }) {
  const parentName = parent ?? "the parent";
  return (
    <SettingsSection
      id={`units-rate-${id}`}
      title="Speed limit"
      description={
        <>
          This account&apos;s own ceilings. They are checked first and in addition to {parentName}&apos;s, which still
          covers every account beneath it.
        </>
      }
      bodyClassName={rate ? undefined : "px-4 py-4 md:px-5"}
    >
      {!rate ? (
        <p className="text-sm text-muted-foreground">
          The stored limits could not be read: this panel has no configuration database.
        </p>
      ) : (
        <>
          <SettingsRow
            label="SMPP"
            keyName={`outSms.default.conf.maxRate.${id}`}
            help={
              <>
                Gateway-wide, for every SMPP listener; a listener&apos;s own <code className="font-mono">conf.maxRate.{id}</code>{" "}
                beats it there. Messages a second across all this account&apos;s logins, split evenly between live nodes.
                It also caps a login&apos;s own TPS. {parentName}&apos;s ceiling applies as well, and the listener default
                and port share never count as this account&apos;s own. Over it a submit is answered 0x58 and not charged.
              </>
            }
          >
            <p className="text-sm tabular-nums">{limitText(rate.smpp)}</p>
            {rate.smppListeners.map((l) => (
              <p key={l.listener} className="text-xs text-muted-foreground">
                <span className="font-mono">{l.listener}</span>: {limitText(l.value)}
              </p>
            ))}
            <p className="text-xs text-muted-foreground">
              {parentName}: {limitText(rate.parentSmpp)}
              {" · "}
              <Link href={accountHref(id, "limits")} className="text-primary hover:underline">Limits per listener</Link>
            </p>
          </SettingsRow>
          <SettingsRow
            label="HTTP"
            keyName={`smsg.restapi.maxRate.${id}`}
            help={
              <>
                Platform-wide: REST, the platform&apos;s send and gRPC. Messages a second across this account&apos;s
                HTTP logins, checked before {parentName}&apos;s <code className="font-mono">smsg.restapi.maxRate.{parentName}</code>{" "}
                (or the default), which applies as well; the default never counts as this account&apos;s own. Over it
                REST answers 429 RATE_LIMITED (gRPC RESOURCE_EXHAUSTED) and nothing is charged.
              </>
            }
          >
            <p className="text-sm tabular-nums">{limitText(rate.http)}</p>
            <p className="text-xs text-muted-foreground">{parentName}: {limitText(rate.parentHttp)}</p>
          </SettingsRow>
        </>
      )}
    </SettingsSection>
  );
}
