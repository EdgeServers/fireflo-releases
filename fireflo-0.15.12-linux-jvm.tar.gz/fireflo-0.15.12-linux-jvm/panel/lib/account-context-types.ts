/**
 * The shapes of what an account lookup returns, with no database import anywhere.
 *
 * <p>Split from `account-context.ts` for the same reason `cdr-request.ts` is split from
 * `cdr-queries.ts`: a client component that reaches a module which transitively imports `pg` does
 * not break that page, it breaks **every** page in the panel with a DNS resolution failure that
 * names none of the code involved. `import type` is erased and would be safe, but the boundary is
 * worth being structural rather than a property of one keyword nobody will notice deleting.
 */

import type { InheritedCurrency } from "./balance-types";

export interface LedgerEntry {
  id: number;
  /**
   * Scaled by 10^4, like every other amount in this schema. Positive credits; a `DEBIT` (gateway
   * 0.15.3) is stored positive and read back negative here, so it prints as money taken away.
   */
  delta: number;
  entryType: string;
  ref: string | null;
  note: string | null;
  applied: boolean;
  createdAt: string;
}

/**
 * A page of the ledger.
 *
 * <p>It used to carry a count of what had been left out, because the table mixed money with the
 * gateway's own RESERVE/RELEASE bookkeeping and a card that hid thousands of rows without saying
 * so would have been a different confusing page rather than a fixed one. Gateway migration
 * V1.51.0 moved that bookkeeping to `balance_reservation`; every row here is somebody's money, so
 * there is nothing to leave out and nothing to declare.
 */
export interface LedgerView {
  entries: LedgerEntry[];
}

export interface AccountContext {
  /** The effective billing account this describes, echoed back so a stale reply can be discarded. */
  account: string;
  /** null means the balance could not be read; `balanceMissing` means read, and there is no row. */
  balance: {
    balance: number;
    reserved: number;
    currency: string | null;
    enabled: boolean;
    billingMode: "PREPAID" | "POSTPAID";
    /** Scaled by 10,000. Zero on a prepaid row, where it carries no meaning. */
    creditLimit: number;
  } | null;
  balanceMissing: boolean;
  /** null means could not be read. An empty `entries` means read, and there are none. */
  ledger: LedgerView | null;
  scopes: { scope: string; kind: string; rules: number }[] | null;
  vendors: { vendor: string; messages: number }[] | null;
  /**
   * What {@link AccountContext.vendors} covers: the last `days`, from the hourly summary (behind live
   * traffic by the rollup tick) or, on a gateway without one, the hot call records. null when the
   * list was not read.
   */
  vendorsWindow: { days: number; source: "summary" | "records" } | null;
  /**
   * The one currency this platform has, from `smsg.rates.currency`.
   *
   * <p>null when it could not be read or is not set -- in file mode it lives in `smsg.properties`,
   * which this panel does not read. This field means exactly that key and nothing else; what a form
   * should actually put on a new balance row is {@link AccountContext.currencyForNewBalance}, which
   * falls back past it.
   */
  platformCurrency: string | null;
  /**
   * What a balance opened for THIS account should be denominated in, and where that came from.
   *
   * <p>Its own field rather than a wider `platformCurrency`, because the two are different claims: a
   * value here sourced `"parent"` is not the platform's currency, it is the code already in use one
   * level up. Overloading the field above would make its own documentation false.
   *
   * <p>`{code: null}` means neither the gateway nor a parent could answer. The two surfaces treat
   * that differently on purpose -- see `chooseCurrency` in `lib/balance-types.ts`.
   */
  currencyForNewBalance: InheritedCurrency;
  /**
   * Whether whoever is looking may put this account on postpaid terms.
   *
   * <p>Always true for an operator: postpaid is a credit line, and the operator is the party that
   * extends it.
   *
   * <p>For a reseller it is **its own billing mode**. A prepaid reseller has no credit line from the
   * operator, so it has none to pass on — letting it set a child postpaid would let it extend credit
   * that exists nowhere, and the child's traffic would be carried against a limit nobody is behind.
   */
  mayGrantPostpaid: boolean;
  /**
   * The largest postpaid limit this account may be given, or null for no ceiling.
   *
   * <p>null for an operator: the credit line originates with them, so there is nothing above it to
   * fit inside.
   *
   * <p>For a reseller it is its **own limit minus what it has already committed to its other
   * children**, with this account's current limit excluded because a write replaces it rather than
   * adding to it. Aggregate rather than per child on purpose: a rule that only compared one child
   * against the reseller's limit would let five children hold the full limit each.
   */
  postpaidHeadroom: number | null;
  /** True when this name is also a configured vendor, which makes its rate scope ambiguous. */
  collidesWithVendor: boolean;
}
