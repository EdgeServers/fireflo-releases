import { strict as assert } from "node:assert";
import { test } from "node:test";
import { perAccountKey, perAccountKeyFor, settable } from "./worker-settable.ts";
import { PER_ACCOUNT_SCREEN, fieldFor, sectionTitle } from "./setting-fields.ts";
import { settingLabel } from "./labels.ts";

test("the fixed controls take any value, as before", () => {
  assert.deepEqual(settable("suspend", "true"), { ok: true, key: "suspend", account: null });
  assert.deepEqual(settable("pause", ""), { ok: true, key: "pause", account: null });
  assert.equal(settable("dlr.errcodes", "0x45=8").ok, true);
  assert.equal(settable("dlr.errcodes.passthrough", "true").ok, true);
});

test("per-account ceilings and binds name the account, and take a whole number or nothing", () => {
  assert.deepEqual(settable("conf.maxRate.YK201", "250"), { ok: true, key: "conf.maxRate.YK201", account: "YK201" });
  assert.deepEqual(settable("conf.maxConnectionsPerUser.233026", "4"), { ok: true, key: "conf.maxConnectionsPerUser.233026", account: "233026" });
  assert.deepEqual(settable("conf.maxRate.YK201", ""), { ok: true, key: "conf.maxRate.YK201", account: "YK201" });
  assert.equal(settable("conf.maxRate.YK201", "0").ok, true);
  for (const bad of ["-1", "1.5", "abc", "1e3", " "]) {
    assert.equal(settable("conf.maxRate.YK201", bad).ok, false, bad);
  }
});

test("a vendor's tps is numeric, with no account", () => {
  assert.deepEqual(settable("tps", "1500"), { ok: true, key: "tps", account: null });
  assert.equal(settable("tps", "fast").ok, false);
});

test("anything else is refused: the defaults, other keys, malformed account keys", () => {
  for (const key of [
    "", "host", "conf.maxRate.default", "conf.maxConnectionsPerUser.default", "conf.maxRate.", "conf.maxRate.a.b",
    "conf.maxRate.has space", "conf.maxPending.YK201", `conf.maxRate.${"x".repeat(65)}`, "srv.port",
  ]) {
    assert.equal(settable(key, "1").ok, false, key);
  }
});

test("a per-account key names its account and kind; the defaults and other keys do not", () => {
  assert.deepEqual(perAccountKey("conf.maxRate.YK201"), { kind: "rate", account: "YK201" });
  assert.deepEqual(perAccountKey("conf.maxConnectionsPerUser.233026"), { kind: "binds", account: "233026" });
  for (const key of ["conf.maxRate.default", "conf.maxConnectionsPerUser.default", "conf.maxPending.YK201", "conf.maxRate.a.b", "tps"]) {
    assert.equal(perAccountKey(key), null, key);
  }
  assert.equal(perAccountKeyFor("rate", "YK201"), "conf.maxRate.YK201");
  assert.equal(perAccountKeyFor("binds", "YK201"), "conf.maxConnectionsPerUser.YK201");
});

test("the per-account keys have a field, edited elsewhere, so they leave Other settings", () => {
  const field = fieldFor("conf.maxRate.YK201");
  assert.ok(field, "a prefix match, not a catalogue entry");
  assert.equal(field.elsewhere, PER_ACCOUNT_SCREEN);
  assert.equal(field.applies, "server");
  assert.ok(fieldFor("conf.maxConnectionsPerUser.YK201")?.elsewhere);
  assert.equal(sectionTitle("conf.maxRate.YK201"), "Per-account overrides");
  assert.equal(fieldFor("conf.maxRate.default")?.elsewhere, undefined, "the listener default stays on the form");
  assert.equal(fieldFor("some.unknown.key"), null);
  assert.equal(settingLabel("conf.maxRate.YK201").label, "Rate ceiling for YK201");
  assert.equal(settingLabel("conf.maxConnectionsPerUser.YK201").label, "Binds for YK201");
});
