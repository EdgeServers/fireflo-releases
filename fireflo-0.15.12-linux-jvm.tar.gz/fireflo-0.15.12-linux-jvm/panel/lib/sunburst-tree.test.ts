import { test } from "node:test";
import assert from "node:assert/strict";
import {
  EXPIRED_COLOUR,
  FAILED_COLOUR,
  OTHER_COLOUR,
  REASON_COLOURS,
  ancestors,
  buildSunburst,
  codeLabel,
  failureItems,
  findNode,
  pathRows,
  reasonColours,
  shareOfTop,
  tint,
  vendorItems,
  zoomOut,
  zoomTarget,
  type SunNode,
  type TreeItem,
} from "./sunburst-tree.ts";
import type { FailureCell } from "./failure-groups.ts";

const row = (o: Partial<FailureCell> & Pick<FailureCell, "messages">): FailureCell => ({
  finalState: "FAILED", dlrState: 2, errCode: "0x45", account: "acme", vendor: "telstra", vendorErrCode: null,
  lastSeen: "2026-10-30T10:00:00.000Z", ...o,
});

const item = (keys: string[], value: number): TreeItem => ({ levels: keys.map((k) => ({ key: k, label: k, fill: "#000000" })), value });

const depth = (n: SunNode): number => (n.children?.length ? 1 + Math.max(...n.children.map(depth)) : 0);

test("failure items: five levels, the carrier code only when it says something the gateway's does not", () => {
  const items = failureItems([
    row({ messages: 10, vendorErrCode: "34" }),
    row({ messages: 4, vendorErrCode: "0x45" }),
    row({ messages: 3, errCode: null, dlrState: 8, finalState: "REJECTED" }),
    row({ messages: 2, errCode: null, dlrState: null, finalState: "EXPIRED", vendor: null, account: null }),
  ]);
  assert.deepEqual(items[0].levels.map((l) => l.label), ["acme", "telstra", "Failed", "error 0x45", "carrier 34"]);
  assert.equal(items[1].levels.length, 4, "the same code twice is one level");
  assert.deepEqual(items[2].levels.map((l) => l.label).slice(2), ["Rejected", "receipt 8"]);
  assert.deepEqual(items[3].levels.map((l) => l.label).slice(0, 2), ["No account", "vendor not known"]);
  assert.equal(codeLabel({ errCode: null, dlrState: null }), "no code");
  //a reason keeps its hue; the carrier level beneath it is a tint of it
  assert.equal(items[0].levels[3].fill, REASON_COLOURS[0]);
  assert.equal(items[0].levels[4].fill, tint(REASON_COLOURS[0], 0.45));
  assert.equal(items[0].levels[1].fill, tint(items[0].levels[0].fill, 0.3));
  assert.equal(items[3].levels[0].fill, OTHER_COLOUR);
});

test("levels are summed and ordered largest first; values line up ring to ring", () => {
  const root = buildSunburst([item(["a", "x"], 30), item(["b", "y"], 50), item(["a", "z"], 20)], "all");
  assert.equal(root.value, 100);
  assert.deepEqual(root.children!.map((c) => [c.label, c.value]), [["a", 50], ["b › y", 50]]);
  assert.deepEqual(root.children![0].children!.map((c) => [c.label, c.value]), [["x", 30], ["z", 20]]);
  assert.deepEqual(root.children![0].path, ["a"]);
  assert.deepEqual(root.children![0].children![1].path, ["a", "z"]);
});

test("a level of one that covers its parent collapses into it; one that covers part of it is kept", () => {
  const root = buildSunburst([item(["acme", "telstra", "Failed", "error 0x45"], 10), item(["acme", "telstra", "Failed", "error 0x45", "carrier 34"], 5)], "all");
  //acme has one vendor, which has one state, which has one code: one sector, the whole path in its label
  const acme = root.children![0];
  assert.equal(acme.label, "acme › telstra › Failed › error 0x45");
  assert.deepEqual(acme.path, ["acme", "telstra", "Failed", "error 0x45"]);
  //the carrier code covers 5 of 15: kept, the rest of that ring empty
  assert.equal(acme.children!.length, 1);
  assert.equal(acme.children![0].label, "carrier 34");
  assert.equal(acme.children![0].value, 5);
  assert.equal(depth(root), 2, "two rings, not five");
  //the root is never merged into its only child: the first ring stays the first level
  const one = buildSunburst([item(["solo", "x"], 3)], "all");
  assert.equal(one.label, "all");
  assert.equal(one.children![0].label, "solo › x");
  assert.equal(one.children![0].children, undefined, "a leaf has no children array");
});

test("children under 1.5 % of their parent fold into 'other N', per level; a single small one is kept", () => {
  const items = [
    item(["big"], 1000), item(["t1"], 5), item(["t2"], 4), item(["t3"], 3), item(["mid"], 100),
    //inside 'big': two small ones at the second level fold too, against big's own value
    item(["big", "main"], 0), // zero items are ignored
  ];
  const root = buildSunburst(items, "all");
  assert.deepEqual(root.children!.map((c) => [c.label, c.value]), [["big", 1000], ["mid", 100], ["other 3", 12]]);
  const other = root.children![2];
  assert.equal(other.folded, 3);
  assert.equal(other.fill, OTHER_COLOUR);
  assert.deepEqual(other.path, ["other 3"]);

  const nested = buildSunburst([item(["a", "x"], 980), item(["a", "y"], 10), item(["a", "z"], 10), item(["b"], 5)], "all");
  const a = nested.children![0];
  assert.deepEqual(a.children!.map((c) => c.label), ["x", "other 2"], "1.5 % of a (1,000), not of the root");
  assert.equal(nested.children![1].label, "b", "one small sibling alone is kept by name");
});

test("zoom: a sector with children becomes the root, a leaf does not; the breadcrumb is its ancestors; up goes one level", () => {
  const root = buildSunburst([
    item(["acme", "telstra", "Failed", "e1"], 6), item(["acme", "telstra", "Failed", "e2"], 4),
    item(["acme", "optus", "Expired", "none"], 5), item(["nbank", "optus", "Failed", "e1"], 5),
    item(["nbank", "optus", "Expired", "none"], 5),
  ], "all");
  const acme = root.children!.find((c) => c.label === "acme")!;
  assert.equal(zoomTarget(root, acme.name), acme);
  const telstra = acme.children!.find((c) => c.label === "telstra › Failed")!;
  assert.ok(telstra, "telstra's one state is merged into it");
  assert.equal(zoomTarget(root, telstra.name), telstra);
  const leaf = telstra.children![0];
  assert.equal(zoomTarget(root, leaf.name), null, "nothing to fill the circle with");
  assert.deepEqual(ancestors(root, leaf.name).map((n) => n.label), ["acme", "telstra › Failed", "e1"]);
  assert.equal(zoomOut(root, telstra.name), acme.name);
  assert.equal(zoomOut(root, acme.name), null, "up from the first ring is the whole chart");
  assert.equal(findNode(root, "nope"), null);
  const share = shareOfTop(root, leaf)!;
  assert.equal(share.of, acme);
  assert.equal(share.share, 6 / 15);
});

test("the table: every full path, unfolded, summed, sortable by count either way", () => {
  const items = [item(["a", "x"], 3), item(["a", "x"], 2), item(["b"], 9), item(["c", "y"], 1)];
  assert.deepEqual(pathRows(items).map((r) => [r.path.join(" › "), r.value]), [["b", 9], ["a › x", 5], ["c › y", 1]]);
  assert.deepEqual(pathRows(items, "asc").map((r) => r.value), [1, 5, 9]);
});

test("vendor items: vendor › account › outcome › code; failures beyond the breakdown kept as 'not broken down'", () => {
  const failures = [
    row({ messages: 6, vendor: "telstra", account: "acme" }),
    row({ messages: 2, vendor: "telstra", account: "acme", finalState: "EXPIRED", errCode: null, dlrState: null }),
  ];
  const items = vendorItems(
    [
      { vendor: "telstra", account: "acme", delivered: 90, failed: 10, pending: 3 },
      { vendor: "telstra", account: "nbank", delivered: 40, failed: 0, pending: 0 },
    ],
    failures
  );
  const root = buildSunburst(items, "sent");
  assert.equal(root.value, 90 + 10 + 3 + 40);
  const telstra = root.children![0];
  assert.equal(telstra.label, "telstra");
  const acme = telstra.children!.find((c) => c.label === "acme")!;
  assert.deepEqual(acme.children!.map((c) => [c.label, c.value]), [["delivered", 90], ["failed", 8], ["pending", 3], ["expired › no code", 2]]);
  const failed = acme.children!.find((c) => c.label === "failed")!;
  assert.deepEqual(failed.children!.map((c) => [c.label, c.value]), [["error 0x45", 6], ["not broken down", 2]]);
  assert.equal(failed.fill, FAILED_COLOUR);
  assert.equal(acme.children!.find((c) => c.label.startsWith("expired"))!.fill, EXPIRED_COLOUR);
  //nbank only delivered: its one outcome merges into it
  assert.equal(telstra.children!.find((c) => c.label.startsWith("nbank"))!.label, "nbank › delivered");
  //the same reason has the same colour in both rings
  const colours = reasonColours(failures);
  assert.equal(failed.children![0].fill, colours.get("FAILED|2|0x45"));
});

test("vendor rows not split by account sit under 'All accounts', which collapses into the vendor", () => {
  const root = buildSunburst(vendorItems([{ vendor: "v", delivered: 5, failed: 0, pending: 5 }], []), "sent");
  assert.equal(root.children![0].label, "v › All accounts");
  assert.deepEqual(root.children![0].children!.map((c) => c.label), ["delivered", "pending"]);
});
