import { byReason } from "@/lib/failure-groups";
import { listArchiveAccounts, listArchiveBatches, listArchivePartitions } from "@/lib/archives";
import { isRequestError, parseArchiveAccountFilters, parseBatchFilters } from "@/lib/archives-request";
import { configQuery } from "@/lib/config-db";
import {
  fetchLiveFailures,
  fetchLiveReceiptQuality,
  fetchLiveSeries,
  isLiveRange,
  liveSeriesAvailable,
  type ConfiguredCredential,
} from "@/lib/gateway-live-series";
import { isConfigured, query } from "@/lib/metrics-db";
import {
  accountUsage,
  failureBreakdown,
  freshHourlySource,
  liveTraffic,
  revenueByAccount,
  revenueSeries,
  serverTraffic,
  trafficOverTime,
  usageByDay,
  vendorPerformance,
  type Range,
} from "@/lib/metrics-queries";
import { overviewFor } from "@/lib/mis-overview";
import { usageBreakdown, usageGrid } from "@/lib/usage-grid-queries";
import { getOverviewRefresher } from "@/lib/overview-refresher";
import { receiptQuality } from "@/lib/receipt-queries";
import type { CustomerSession } from "@/lib/require-customer";
import type { MetricName } from "@/lib/stats-metrics";
import { createLiveReaders, type LiveReaders } from "@/lib/stats-live";

/** What a reader is handed: the period already checked against the metric's own list. */
export interface StatsRequest {
  range: string;
  params: URLSearchParams;
}

export interface CustomerRequest extends StatsRequest {
  session: CustomerSession;
  /** The accounts this customer may see: their own and, for a reseller, those beneath it. */
  scope: string[];
}

export interface Readers {
  /**
   * An answer, or a `Sourced` one (`stats-live.ts`) saying whether the gateway or the database
   * served it; the route unwraps it into the envelope's `source` and `liveSince`.
   */
  operator?: (req: StatsRequest) => Promise<unknown>;
  customer?: (req: CustomerRequest) => Promise<unknown>;
  /**
   * Whether this metric at this range may be served by the gateway's live series, and so needs no
   * metrics database: the route answers its 503 for a missing `METRICS_DATABASE_URL` only when this
   * is absent or false. A read that then finds the gateway unable throws `NoDataSourceError`.
   */
  live?: (range: string) => boolean;
  /** Response headers on success, e.g. the overview's short private cache. */
  headers?: Record<string, string>;
}

/** The live readers this metric list uses, at 1h and 24h; see `stats-live.ts` for the rules. */
const live = (range: string) => isLiveRange(range);

/** How long the Accounts rows' credentials and balances are kept on the live path. */
const EXTRAS_TTL_MS = 10_000;
const extras = new Map<string, { at: number; value: Promise<unknown> }>();

/** One cheap read per key per {@link EXTRAS_TTL_MS}; a failure is not kept. */
function keptFor<T>(key: string, read: () => Promise<T>): Promise<T> {
  const hit = extras.get(key);
  if (hit && Date.now() - hit.at < EXTRAS_TTL_MS) {
    return hit.value as Promise<T>;
  }
  const value = read();
  extras.set(key, { at: Date.now(), value });
  value.catch(() => extras.delete(key));
  return value;
}

/**
 * A config-database read, or the metrics pool when this panel has no `CONFIG_DATABASE_URL` (the
 * tables are the gateway's either way). The live Accounts path reads credentials and balances so,
 * never the call records.
 */
function configOrMetrics<T extends Record<string, unknown>>(text: string, params: unknown[]): Promise<T[]> {
  return process.env.CONFIG_DATABASE_URL?.trim() ? configQuery<T>(text, params) : query<T>(text, params);
}

const liveSlot = globalThis as { __firefloLiveReaders?: LiveReaders };

/** The one set of live readers per process, wired to the gateway and the SQL readers. */
function liveReaders(): LiveReaders {
  return (liveSlot.__firefloLiveReaders ??= createLiveReaders(
    {
      capability: liveSeriesAvailable,
      series: fetchLiveSeries,
      receiptQuality: fetchLiveReceiptQuality,
      failures: (range) => fetchLiveFailures(range, ["ACCOUNT", "VENDOR"]),
      dbConfigured: isConfigured,
      now: () => new Date(),
      log: (line) => console.warn(line),
    },
    {
      //no `until`: exactly the call the reader always made. With one, the part before the seam,
      //from the hourly summary while it is current
      traffic: async (range, o) =>
        o.until ? trafficOverTime(range, { until: o.until, source: await freshHourlySource() }) : trafficOverTime(range),
      revenue: (range, o) => (o.until ? revenueByAccount(range, { until: o.until }) : revenueByAccount(range)),
      revenueSeries: (range, o) => revenueSeries(range, o),
      vendors: (range, o) => vendorPerformance(range, o),
      accounts: (range, params, o) => accountUsage(range, params, o),
      serverTraffic: (range, params, o) => serverTraffic(range, params, o),
      receipts: (range) => receiptQuality(range),
      usageGrid: (range, params) => usageGrid(range, params),
      failures: (range) => failureBreakdown(range),
      configured: (account) =>
        keptFor(`configured|${account ?? ""}`, async (): Promise<ConfiguredCredential[]> => {
          //never password or api_key: a secret not read cannot leak (metrics-queries.ts)
          const rows = await configOrMetrics<Record<string, string | null>>(
            `SELECT account_id, system_id, product FROM app_credential
              WHERE enabled${account !== null ? " AND account_id = $1" : ""} ORDER BY system_id`,
            account !== null ? [account] : []
          );
          return rows.map((r) => ({ accountId: r.account_id ?? null, systemId: r.system_id ?? null, product: r.product ?? null }));
        }),
      balances: () =>
        keptFor("balances", async () => {
          const map = new Map<string, { balance: number; currency: string | null }>();
          const rows = await configOrMetrics<Record<string, string | null>>(
            "SELECT account_id, balance, currency FROM account_balance WHERE enabled",
            []
          );
          for (const r of rows) {
            map.set(r.account_id ?? "", { balance: Number(r.balance ?? 0), currency: r.currency ?? null });
          }
          return map;
        }),
    }
  ));
}

/** Days per portal-overview period. */
const PORTAL_DAYS: Record<string, number> = { "7d": 7, "14d": 14, "30d": 30, "90d": 90 };

/**
 * The reader behind each metric, for each audience `stats-metrics.ts` gives it. The readers are the
 * query functions the per-metric routes always called; only the plumbing around them is shared.
 * `Record<MetricName, …>` makes a metric listed there and missing here a compile error.
 */
export const READERS: Record<MetricName, Readers> = {
  overview: {
    operator: async ({ range, params }) => {
      //the refresher only when the database serves it: a gateway-served overview never starts its timer
      const answer = await liveReaders().overview(range, () =>
        getOverviewRefresher().get(range as Range, { fresh: params.get("fresh") === "1" })
      );
      const snap = answer.value;
      const debug = params.get("debug") === "1" && answer.source === "database";
      return { ...answer, value: {
        totals: snap.totals,
        traffic: snap.traffic,
        failures: byReason(snap.failures),
        failuresByAccount: snap.failures,
        failuresSince: snap.failuresSince,
        vendors: snap.vendors,
        vendorAccounts: snap.vendorAccounts,
        watermark: snap.watermark,
        asOf: snap.asOf,
        builtAt: snap.builtAt,
        stale: snap.stale,
        source: snap.source,
        settlingFrom: snap.settlingFrom,
        ...(debug ? { debug: { tickMs: snap.tickMs, ...getOverviewRefresher().debug() } } : {}),
      } };
    },
    live,
    customer: async ({ range, session, scope }) => ({
      ...(await overviewFor(scope, session.accountId, PORTAL_DAYS[range])),
      //echoed so the page says what it shows rather than assuming client and server agree
      range,
    }),
    headers: { "Cache-Control": "private, max-age=15" },
  },
  accounts: {
    operator: ({ range, params }) => liveReaders().accounts(range, params),
    customer: async ({ range, scope }) => {
      const answer = await liveReaders().accounts(range);
      const view = answer.value;
      const mine = new Set(scope);
      return {
        ...answer,
        value: {
          creditEnforced: view.creditEnforced,
          //`cost` is dropped by construction rather than zeroed: a zero would read as "we pay
          //nothing for this", which is a different lie
          accounts: view.accounts
            .filter((row) => row.accountId != null && mine.has(row.accountId))
            .map(({ cost: _cost, ...row }) => row),
        },
      };
    },
    live,
  },
  vendors: { operator: ({ range }) => liveReaders().vendors(range), live },
  receipts: { operator: ({ range }) => liveReaders().receipts(range), live },
  //the range alone: revenueByAccount's second argument is a window override, not the query string
  revenue: { operator: ({ range }) => liveReaders().revenue(range), live },
  "revenue-series": { operator: ({ range }) => liveReaders().revenueSeries(range), live },
  usage: { operator: ({ range }) => usageByDay(range as Range) },
  "usage-grid": { operator: ({ range, params }) => liveReaders().usageGrid(range, params), live },
  "usage-breakdown": { operator: ({ range, params }) => usageBreakdown(range, params) },
  traffic: { operator: ({ range }) => liveReaders().traffic(range), live },
  "server-traffic": { operator: ({ range, params }) => liveReaders().serverTraffic(range, params), live },
  "traffic-live": {
    operator: async ({ params }) => {
      const since = params.get("since");
      const key = params.get("key");
      return liveTraffic(params.get("kind") === "server" ? "server" : "vendor", {
        since: since ? Number(since) : null,
        key: key && key.length <= 200 ? key : null,
      });
    },
  },
  "archive-accounts": {
    operator: async ({ params }) => {
      const filters = parseArchiveAccountFilters(params);
      if (isRequestError(filters)) {
        throw new Error(filters.error);
      }
      return listArchiveAccounts(filters);
    },
  },
  "archive-batches": {
    operator: async ({ params }) => {
      const filters = parseBatchFilters(params);
      if (isRequestError(filters)) {
        throw new Error(filters.error);
      }
      return listArchiveBatches(filters);
    },
  },
  "archive-partitions": { operator: () => listArchivePartitions() },
};
