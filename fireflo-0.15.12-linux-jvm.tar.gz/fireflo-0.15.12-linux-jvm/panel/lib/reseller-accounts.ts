import { randomBytes, randomUUID } from "node:crypto";
import type { PoolClient } from "pg";
import { BILLING_KEY } from "@/lib/billing-key";
import { configQuery, inTransaction } from "@/lib/config-db";
import { query as metricsQuery } from "@/lib/metrics-db";
import { hasUsageHourly } from "@/lib/metrics-schema";
import { billingZone, currencyForNewBalance, platformCurrency } from "@/lib/platform-currency";
import { disconnectBindsFor } from "@/lib/gateway-sessions";
import { gqlData, GatewayError } from "@/lib/gateway-graphql";
import { CREDIT_RELEASE, RELOAD } from "@/lib/gateway-queries";
import { seal } from "@/lib/secret-box";
import { smppPassword, smppSystemId } from "@/lib/login-secrets";
import { isUniqueViolation } from "@/lib/balance";
import { money } from "@/lib/format";
import { ensureCustomerUser } from "@/lib/users";
import {
  readTransferNote,
  shortfallProblem,
  transferNote,
  transferStateProblem,
  type LoginPatch,
  type NewLogin,
  type Refusal,
  type TransferInput,
  type TransferKind,
} from "@/lib/reseller-rules";

/**
 * The accounts beneath a reseller, as the portal's sub-account pages see and change them: the list,
 * one account, its logins, and credit moved to and from it.
 *
 * <p>Server-only. <strong>This is the panel's copy of the gateway's reseller API</strong> (0.15.8,
 * `manage/ResellerAccounts` behind `/secure/accounts`): the same operations under the same rules,
 * written against the configuration database because the portal has no reseller credential to call
 * that API with, and the API is not released yet. The rules themselves are in
 * `lib/reseller-rules.ts`; what is here is the SQL and the order of the steps. Where the gateway does
 * something in-process the panel asks for it over the ops channel with the admin token, as the rest
 * of the panel does:
 *
 * <ul>
 *   <li>a withdrawal first asks the gateway to hand back the child's held credit
 *       (`creditRelease`), so the transfer can reach it -- the operator's archive path does the same;</li>
 *   <li>a login change asks for a configuration reload (`reload`, the gateway's `pollOnce`, which
 *       respects the licence freeze) so it applies in seconds rather than at the next poll;</li>
 *   <li>switching a login off drops its open binds (`sessionsDisconnect`).</li>
 * </ul>
 *
 * <p>Each step that talks to the gateway is best effort and after the commit: the stored change is
 * the durable intent, and an unreachable gateway is reported, never a reason to undo it.
 *
 * <h2>Money</h2>
 *
 * <p>Nothing here writes `account_balance.balance`. A recharge, a withdrawal and an opening credit are
 * unapplied `TRANSFER` rows in `balance_ledger`, which the gateway applies with its own
 * `balance >= ?` guard on its next poll. A new sub-account gets its balance row here (zero, in the
 * platform currency) because a transfer to an account with no balance row could never apply.
 */

/** Matches `smsg.config.db.poll.seconds`' default: the longest a change waits if the reload fails. */
export const POLL_SECONDS = 30;

/** `smsg.transfer.pending.max`'s default, the gateway's ceiling on one payer's queued transfers. */
const PENDING_TRANSFERS_MAX = 50;

export interface Money {
  balance: number;
  reserved: number;
  currency: string | null;
}

export interface SubAccountRow {
  id: string;
  label: string | null;
  enabled: boolean;
  archived: boolean;
  /** Null when the account has no balance row (made outside the portal, never funded). */
  balance: Money | null;
  logins: number;
  /** The start of the last hour it sent in, from `usage_hourly` (about 35 days kept). */
  lastSentAt: string | null;
  sent24h: number | null;
}

export interface SubAccountList {
  accounts: SubAccountRow[];
  /** The reseller's own balance, for "Available" and "your balance after". */
  self: Money & { spendable: number } | null;
  currency: string | null;
}

interface ChildRow {
  id: string;
  label: string | null;
  enabled: boolean;
  archived: boolean;
  logins: number;
}

async function childRows(resellerId: string, only?: string): Promise<ChildRow[]> {
  return configQuery<ChildRow>(
    `SELECT a.id, a.label, a.enabled, (a.archived_at IS NOT NULL) AS archived,
            COALESCE(c.n, 0)::int AS logins
       FROM app_account a
       LEFT JOIN (SELECT ${BILLING_KEY} AS acct, count(*) AS n FROM app_credential GROUP BY 1) c
         ON c.acct = a.id
      WHERE a.parent_account_id = $1 AND ($2::text IS NULL OR a.id = $2)
      ORDER BY lower(COALESCE(a.label, a.id)), a.id`,
    [resellerId, only ?? null]
  );
}

/**
 * Balances by account: an index lookup per id on `account_balance`'s primary key, never a scan. The
 * gateway reserves and debits on this table per message; a read takes no lock against that.
 */
async function balances(ids: readonly string[]): Promise<Map<string, Money>> {
  if (!ids.length) {
    return new Map();
  }
  const rows = await configQuery<{ account_id: string; balance: string; reserved: string; currency: string | null }>(
    `SELECT account_id, balance::text, reserved::text, currency
       FROM account_balance WHERE account_id = ANY($1)`,
    [ids]
  );
  return new Map(rows.map((r) => [r.account_id, {
    balance: Number(r.balance), reserved: Number(r.reserved), currency: r.currency,
  }]));
}

/**
 * What a payer could move right now: its `balance` (the part no gateway holds as a block, and the
 * only part the poll's debit can reach) less the transfers it has queued and not yet had applied.
 * The gateway's `SPENDABLE_SQL`, read the same way and for the same advisory purpose.
 */
async function spendable(db: Pick<PoolClient, "query"> | null, payer: string): Promise<number> {
  const sql = `SELECT COALESCE((SELECT balance FROM account_balance WHERE account_id = $1), 0)
                    - COALESCE((SELECT sum(delta) FROM balance_ledger
                                 WHERE NOT applied AND entry_type = 'TRANSFER' AND account_id = $1), 0) AS n`;
  const rows = db
    ? (await db.query<{ n: string }>(sql, [payer])).rows
    : await configQuery<{ n: string }>(sql, [payer]);
  return Number(rows[0]?.n ?? 0);
}

/** Sent counts from the hourly summary. Null when the gateway keeps none (before V1.91.0). */
async function usage(ids: readonly string[]): Promise<Map<string, { sent24h: number; last: string | null }> | null> {
  if (!ids.length || !(await hasUsageHourly().catch(() => false))) {
    return null;
  }
  try {
    const rows = await metricsQuery<{ account_id: string; sent24h: string; last_hour: Date | string | null }>(
      `SELECT account_id,
              COALESCE(sum(submitted) FILTER (WHERE hour >= now() - interval '24 hours'), 0)::text AS sent24h,
              max(hour) FILTER (WHERE submitted > 0) AS last_hour
         FROM usage_hourly
        WHERE account_id = ANY($1)
        GROUP BY account_id`,
      [ids]
    );
    return new Map(rows.map((r) => [r.account_id, {
      sent24h: Number(r.sent24h),
      last: r.last_hour ? new Date(r.last_hour).toISOString() : null,
    }]));
  } catch {
    return null;
  }
}

async function selfMoney(resellerId: string): Promise<SubAccountList["self"]> {
  const [own, free] = await Promise.all([balances([resellerId]), spendable(null, resellerId)]);
  const row = own.get(resellerId);
  return row ? { ...row, spendable: free } : null;
}

/** The sub-accounts list: every child with its balance, logins and recent sending. */
export async function listSubAccounts(resellerId: string): Promise<SubAccountList> {
  const children = await childRows(resellerId);
  const ids = children.map((c) => c.id);
  const [money, sent, self, currency] = await Promise.all([
    balances(ids), usage(ids), selfMoney(resellerId), platformCurrency().catch(() => null),
  ]);
  return {
    accounts: children.map((c) => ({
      ...c,
      balance: money.get(c.id) ?? null,
      lastSentAt: sent?.get(c.id)?.last ?? null,
      sent24h: sent ? (sent.get(c.id)?.sent24h ?? 0) : null,
    })),
    self,
    currency: currency ?? self?.currency ?? null,
  };
}

export interface SubAccountDetail extends SubAccountRow {
  /** What it has been charged since the start of this month in the billing zone. */
  spentThisMonth: number | null;
  self: SubAccountList["self"];
}

/** One child, or null when it is not this reseller's. */
export async function getSubAccount(resellerId: string, id: string): Promise<SubAccountDetail | null> {
  const [row] = await childRows(resellerId, id);
  if (!row) {
    return null;
  }
  const [money, sent, self, spent] = await Promise.all([
    balances([id]), usage([id]), selfMoney(resellerId), spentThisMonth(id),
  ]);
  return {
    ...row,
    balance: money.get(id) ?? null,
    lastSentAt: sent?.get(id)?.last ?? null,
    sent24h: sent ? (sent.get(id)?.sent24h ?? 0) : null,
    spentThisMonth: spent,
    self,
  };
}

/**
 * This month's charges from `usage_hourly.price_total` (which keeps about 35 days, so a whole
 * month). Behind live traffic by the rollup tick; null when there is no hourly summary.
 */
async function spentThisMonth(id: string): Promise<number | null> {
  if (!(await hasUsageHourly().catch(() => false))) {
    return null;
  }
  try {
    const zone = await billingZone();
    const rows = await metricsQuery<{ n: string | null }>(
      `SELECT COALESCE(sum(price_total), 0)::text AS n
         FROM usage_hourly
        WHERE account_id = $1
          AND hour >= (date_trunc('month', now() AT TIME ZONE $2) AT TIME ZONE $2)`,
      [id, zone]
    );
    return Number(rows[0]?.n ?? 0);
  } catch {
    return null;
  }
}

// ---- logins ----

/** One login as the Logins tab shows it. No secret is selected, only whether one is stored. */
export interface SubAccountLogin {
  id: number;
  type: string;
  /** The SMPP system id, or the HTTP login's Basic username. Null when that would be an API key. */
  systemId: string | null;
  enabled: boolean;
  allowedIps: string[];
  maxSessions: number | null;
  maxTx: number | null;
  maxRx: number | null;
  maxTrx: number | null;
  /** Read-only here: "set by your platform". */
  maxTps: number | null;
  /** Read-only here: the product (message type) it is priced as. */
  product: string | null;
  hasPassword: boolean;
  /** An HTTP login keyed by an API key: its name is the secret, so it is never shown. */
  keyedByApiKey: boolean;
  updatedAt: string | null;
}

interface LoginRow {
  id: string;
  type: string;
  system_id: string | null;
  enabled: boolean;
  allowed_ips: string[] | null;
  max_sessions: number | null;
  max_tx: number | null;
  max_rx: number | null;
  max_trx: number | null;
  max_tps: string | null;
  product: string | null;
  has_password: boolean;
  keyed: boolean;
  updated_at: Date | null;
}

/** Every login billing to this account (by `BILLING_KEY`, never `account_id` raw). */
export async function listSubAccountLogins(child: string): Promise<SubAccountLogin[]> {
  const rows = await configQuery<LoginRow>(
    `SELECT id::text, type, system_id, enabled, allowed_ips,
            max_sessions, max_tx, max_rx, max_trx, max_tps::text,
            NULLIF(btrim(COALESCE(product, '')), '') AS product,
            (password IS NOT NULL AND password <> '') AS has_password,
            (type <> 'SMPP' AND COALESCE(api_key, '') <> '') AS keyed,
            updated_at
       FROM app_credential
      WHERE ${BILLING_KEY} = $1
      ORDER BY (type = 'SMPP') DESC, id`,
    [child]
  );
  return rows.map((r) => ({
    id: Number(r.id),
    type: r.type,
    systemId: r.keyed ? null : r.system_id,
    enabled: r.enabled,
    allowedIps: r.allowed_ips ?? [],
    maxSessions: r.max_sessions,
    maxTx: r.max_tx,
    maxRx: r.max_rx,
    maxTrx: r.max_trx,
    maxTps: r.max_tps == null ? null : Number(r.max_tps),
    product: r.product,
    hasPassword: r.has_password,
    keyedByApiKey: r.keyed,
    updatedAt: r.updated_at ? new Date(r.updated_at).toISOString() : null,
  }));
}

/**
 * Whether a login name is taken: by any login (its system id or API key, enabled or not) or any
 * vendor, ignoring case. The gateway's `PlatformAccounts.freeSystemId` asks the same question; a
 * clash would make the gateway keep one of two logins and take a customer offline.
 */
async function nameTaken(db: Pick<PoolClient, "query">, name: string): Promise<boolean> {
  const rows = await db.query(
    `SELECT 1 FROM app_credential WHERE lower(system_id) = lower($1) OR lower(api_key) = lower($1)
      UNION ALL
     SELECT 1 FROM app_worker WHERE lower(name) = lower($1)
      LIMIT 1`,
    [name]
  );
  return rows.rows.length > 0;
}

/** An HTTP password: 24 random bytes, base64url. Compared byte for byte, so width is what matters. */
function httpPassword(): string {
  return randomBytes(24).toString("base64url");
}

export type LoginCreated =
  | { ok: true; id: number; type: "SMPP" | "HTTP"; systemId: string; password: string }
  | ({ ok: false } & Refusal);

/**
 * Writes one login inside the caller's transaction: a chosen name checked free, or a generated one;
 * a generated password, sealed at rest when `FIREFLO_SECRETS_KEY` is set and returned once.
 *
 * <p><strong>HTTP logins get a password, not an API key.</strong> The portal made them apiKey-only
 * until 0.15.8, and a REST call authenticates with HTTP Basic -- the key as username and a password
 * -- so those logins could never sign in. Now an HTTP login is `system_id` + password, exactly as the
 * gateway's `AccountProvisioner` makes one.
 *
 * <p>`product` and `allowed_products` are written NULL and `max_tps` is never written: the pricing
 * boundary.
 */
async function insertLogin(
  db: Pick<PoolClient, "query">,
  account: string,
  input: NewLogin
): Promise<LoginCreated> {
  let systemId = input.systemId;
  if (systemId) {
    if (await nameTaken(db, systemId)) {
      return { ok: false, status: 409, error: `'${systemId}' is already taken. Pick another, or leave it empty to have one made.` };
    }
  } else {
    for (let i = 0; i < 10 && !systemId; i++) {
      const candidate = smppSystemId();
      if (!(await nameTaken(db, candidate))) {
        systemId = candidate;
      }
    }
    if (!systemId) {
      return { ok: false, status: 409, error: "Could not find a free login name. Try again." };
    }
  }
  const password = input.type === "SMPP" ? smppPassword() : httpPassword();
  const created = await db.query<{ id: string }>(
    `INSERT INTO app_credential
            (type, system_id, password, api_key, account_id, product, allowed_ips, allowed_products,
             default_tlvs, max_sessions, max_tx, max_rx, max_trx, enabled, updated_at)
     VALUES ($1, $2, $3, NULL, $4, NULL, $5::text[], NULL, NULL, $6, $7, $8, $9, TRUE, now())
     RETURNING id::text`,
    [
      input.type, systemId, seal(password), account,
      input.allowedIps.length ? input.allowedIps : null,
      input.limits.maxSessions, input.limits.maxTx, input.limits.maxRx, input.limits.maxTrx,
    ]
  );
  return { ok: true, id: Number(created.rows[0].id), type: input.type, systemId, password };
}

/** Asks the gateway to adopt written configuration now (`pollOnce`). True when it said it did. */
export async function nudgeConfig(): Promise<boolean> {
  try {
    const result = await gqlData<{ reload?: { adopted?: boolean } } | { adopted?: boolean } | null>({
      query: RELOAD,
      auth: "admin",
    });
    const answer = (result && "reload" in result ? result.reload : result) as { adopted?: boolean } | null;
    return answer?.adopted !== false;
  } catch {
    return false;
  }
}

/** A new login on a child the caller has already proved is this reseller's. */
export async function createSubAccountLogin(account: string, input: NewLogin): Promise<LoginCreated> {
  try {
    return await inTransaction((client) => insertLogin(client, account, input));
  } catch (err) {
    if (isUniqueViolation(err)) {
      return { ok: false, status: 409, error: `'${input.systemId ?? "That name"}' was taken a moment ago. Try again.` };
    }
    throw err;
  }
}

export type LoginUpdated =
  | { ok: true; login: SubAccountLogin; dropped: number; problem?: string; changed: string[] }
  | { ok: false; notFound: true };

/**
 * Applies a patch to one of a child's logins. Ownership is proved again inside the transaction with
 * `FOR UPDATE`: between the route's scope check and here an operator may have moved it.
 */
export async function updateSubAccountLogin(
  account: string,
  loginId: number,
  patch: LoginPatch
): Promise<LoginUpdated> {
  const row = await inTransaction(async (client) => {
    const current = await client.query<{ acct: string | null; type: string; system_id: string | null; enabled: boolean }>(
      `SELECT ${BILLING_KEY} AS acct, type, system_id, enabled FROM app_credential WHERE id = $1 FOR UPDATE`,
      [loginId]
    );
    const found = current.rows[0];
    if (!found || found.acct !== account) {
      return null;
    }
    const sets: string[] = [];
    const params: unknown[] = [loginId];
    const changed: string[] = [];
    if (patch.enabled !== undefined) {
      params.push(patch.enabled);
      sets.push(`enabled = $${params.length}`);
      changed.push("enabled");
    }
    if (patch.allowedIps !== undefined) {
      params.push(patch.allowedIps.length ? patch.allowedIps : null);
      sets.push(`allowed_ips = $${params.length}::text[]`);
      changed.push("allowed_ips");
    }
    if (patch.limits !== undefined) {
      for (const [col, value] of [
        ["max_sessions", patch.limits.maxSessions], ["max_tx", patch.limits.maxTx],
        ["max_rx", patch.limits.maxRx], ["max_trx", patch.limits.maxTrx],
      ] as const) {
        params.push(value);
        sets.push(`${col} = $${params.length}`);
      }
      changed.push("limits");
    }
    await client.query(`UPDATE app_credential SET ${sets.join(", ")}, updated_at = now() WHERE id = $1`, params);
    return { ...found, changed };
  });
  if (!row) {
    return { ok: false, notFound: true };
  }
  let dropped = 0;
  let problem: string | undefined;
  if (patch.enabled === false && row.enabled && row.type === "SMPP" && row.system_id) {
    const teardown = await disconnectBindsFor(row.system_id);
    dropped = teardown.dropped;
    problem = teardown.problem;
  }
  const login = (await listSubAccountLogins(account)).find((l) => l.id === loginId);
  return login ? { ok: true, login, dropped, problem, changed: row.changed } : { ok: false, notFound: true };
}

export type PasswordIssued =
  | { ok: true; systemId: string | null; password: string }
  | { ok: false; notFound: true };

/** A new generated password on one of a child's logins, returned once. The old one stops at the next poll. */
export async function newLoginPassword(account: string, loginId: number): Promise<PasswordIssued> {
  return inTransaction(async (client) => {
    const current = await client.query<{ acct: string | null; type: string; system_id: string | null; keyed: boolean }>(
      `SELECT ${BILLING_KEY} AS acct, type, system_id,
              (type <> 'SMPP' AND COALESCE(api_key, '') <> '') AS keyed
         FROM app_credential WHERE id = $1 FOR UPDATE`,
      [loginId]
    );
    const found = current.rows[0];
    if (!found || found.acct !== account) {
      return { ok: false, notFound: true } as PasswordIssued;
    }
    const password = found.type === "SMPP" ? smppPassword() : httpPassword();
    await client.query("UPDATE app_credential SET password = $2, updated_at = now() WHERE id = $1", [loginId, seal(password)]);
    return { ok: true, systemId: found.keyed ? null : found.system_id, password } as PasswordIssued;
  });
}

// ---- creating a sub-account ----

export type SubAccountCreated =
  | {
      ok: true;
      id: string;
      currency: string;
      login: { id: number; systemId: string; type: "HTTP"; password: string };
      opening: { amount: number; transferId: number } | null;
    }
  | ({ ok: false } & Refusal);

/**
 * Creates one account beneath this reseller, in one transaction: the account (`resells` false and
 * the parent as literals), its balance row in the platform currency, one HTTP login named after the
 * account with a generated password, and -- when asked -- the opening credit as a `TRANSFER` from the
 * reseller, refused with 402 when the reseller cannot cover it now.
 *
 * <p>The id has already been through `childIdProblem`; the primary key catches the race.
 */
export async function createSubAccount(
  resellerId: string,
  input: { id: string; label: string | null; opening: number; email?: string | null },
  by: string
): Promise<SubAccountCreated> {
  const inherited = await currencyForNewBalance(resellerId);
  //this reseller's own currency is what the opening credit moves in; the platform's comes first
  const own = (await balances([resellerId])).get(resellerId);
  const currency = inherited.code ?? own?.currency ?? null;
  if (!currency) {
    return {
      ok: false, status: 409,
      error: "This platform has not published a currency we can read, and there is none on your own "
        + "balance to inherit. Ask your account manager to set one.",
    };
  }
  try {
    const created = await inTransaction(async (client) => {
      await client.query(
        `INSERT INTO app_account (id, label, description, email, enabled, resells, parent_account_id, updated_at)
         VALUES ($1, $2, NULL, $3, TRUE, FALSE, $4, now())`,
        [input.id, input.label, input.email ?? null, resellerId]
      );
      await client.query(
        `INSERT INTO account_balance (account_id, balance, reserved, currency, enabled)
         VALUES ($1, 0, 0, $2, TRUE) ON CONFLICT (account_id) DO NOTHING`,
        [input.id, currency]
      );
      const login = await insertLogin(client, input.id, {
        type: "HTTP", systemId: input.id, allowedIps: [],
        limits: { maxSessions: null, maxTx: null, maxRx: null, maxTrx: null },
      });
      if (!login.ok) {
        //its HTTP login is named after it, and that name is already a login or a vendor somewhere
        throw new Refused({
          status: 409,
          error: `'${input.id}' is already a login name on this platform, so the account's own login `
            + "can't take it. Pick another id.",
        });
      }
      let opening: { amount: number; transferId: number } | null = null;
      if (input.opening > 0) {
        await lockPayer(client, resellerId);
        const short = shortfallProblem(await spendable(client, resellerId), input.opening, (n) => money(n, currency));
        if (short) {
          throw new Refused(short);
        }
        const row = await client.query<{ id: string }>(
          `INSERT INTO balance_ledger (account_id, delta, entry_type, counterparty_account_id, ref, note, applied)
           VALUES ($1, $2, 'TRANSFER', $3, $4, $5, FALSE) RETURNING id::text`,
          [resellerId, input.opening, input.id, `xfer:${randomUUID()}`, transferNote("opening", by, null)]
        );
        opening = { amount: input.opening, transferId: Number(row.rows[0].id) };
      }
      return {
        ok: true as const,
        id: input.id,
        currency,
        login: { id: login.id, systemId: login.systemId, type: "HTTP" as const, password: login.password },
        opening,
      };
    });
    //after the commit: app_user.account_id is a foreign key to the new row
    if (input.email) {
      await ensureCustomerUser(input.id, input.email);
    }
    void nudgeConfig();
    return created;
  } catch (err) {
    if (err instanceof Refused) {
      return { ok: false, ...err.refusal };
    }
    const e = err as { code?: string; constraint?: string };
    if (e?.code === "23505") {
      if (e.constraint === "uq_app_account_email") {
        return { ok: false, status: 409, error: `'${input.email}' is already the address on another account.` };
      }
      return { ok: false, status: 409, error: "That id was taken while you were filling this in. Pick another." };
    }
    throw err;
  }
}

/**
 * Serialises this panel's transfer checks for one payer, so two requests cannot both pass the
 * sufficiency or pending-count check. An advisory lock, deliberately NOT `FOR UPDATE` on the payer's
 * `account_balance` row: the gateway reserves and debits that row per message, and a panel request
 * holding its lock would stall the reseller's own traffic for the length of this transaction.
 */
async function lockPayer(client: Pick<PoolClient, "query">, payer: string): Promise<void> {
  await client.query("SELECT pg_advisory_xact_lock(hashtext($1))", [`fireflo:transfer:${payer}`]);
}

/** A refusal thrown out of a transaction so it rolls back, and caught as the answer. */
class Refused extends Error {
  constructor(readonly refusal: Refusal) {
    super(refusal.error);
  }
}

// ---- transfers ----

export type TransferQueued =
  | {
      ok: true;
      transferId: number;
      duplicate: boolean;
      /** Set on a withdrawal when the held credit could not be released; the row still stands. */
      problem?: string;
      released: boolean;
    }
  | ({ ok: false } & Refusal);

/**
 * A recharge (down: reseller pays the child) or a withdrawal (up: the child pays the reseller), as
 * the gateway's `CreditTransferService.recharge` / `withdraw` (0.15.8) decide them:
 *
 * <ol>
 *   <li>the child must be this reseller's (404), and neither archived nor suspended (409);</li>
 *   <li>a recharge the reseller cannot cover now is refused with 402; a repeat of the same key is
 *       never a new spend, so it skips that check and answers the original;</li>
 *   <li>a withdrawal first asks the gateway to release the child's held credit (`creditRelease`) --
 *       a sending child holds most of its money as a block the poll's debit cannot reach, so without
 *       this a withdrawal from an active child stayed pending for as long as it kept sending;</li>
 *   <li>the unapplied `TRANSFER` row, the payer's queued transfers capped at the gateway's ceiling;</li>
 *   <li>a reload, so the poll that applies it runs now rather than in up to {@link POLL_SECONDS}.</li>
 * </ol>
 */
export async function queueTransfer(
  resellerId: string,
  child: string,
  kind: Exclude<TransferKind, "opening">,
  input: TransferInput,
  by: string
): Promise<TransferQueued> {
  const state = await configQuery<{ enabled: boolean; archived: boolean }>(
    `SELECT enabled, (archived_at IS NOT NULL) AS archived FROM app_account WHERE id = $1 AND parent_account_id = $2`,
    [child, resellerId]
  );
  if (!state.length) {
    return { ok: false, status: 404, error: "Not found" };
  }
  const refused = transferStateProblem(child, state[0]);
  if (refused) {
    return { ok: false, ...refused };
  }
  const existing = await configQuery<{ id: string }>("SELECT id::text FROM balance_ledger WHERE ref = $1", [input.ref]);
  if (existing.length) {
    return { ok: true, transferId: Number(existing[0].id), duplicate: true, released: false };
  }

  const payer = kind === "recharge" ? resellerId : child;
  const payee = kind === "recharge" ? child : resellerId;
  const currency = (await balances([payer])).get(payer)?.currency ?? (await platformCurrency().catch(() => null)) ?? "";

  let released = false;
  let problem: string | undefined;
  if (kind === "withdraw") {
    try {
      await gqlData({ query: CREDIT_RELEASE, variables: { account: child }, auth: "admin" });
      released = true;
    } catch (err) {
      //409 is "nothing reserved" (or prepaid credit off): there was nothing to hand back
      if (err instanceof GatewayError && err.status === 409) {
        released = true;
      } else {
        problem = "The gateway could not hand back the credit this account holds for sending right now, "
          + "so part of the withdrawal may wait until it stops sending.";
      }
    }
  }

  try {
    const id = await inTransaction(async (client) => {
      await lockPayer(client, payer);
      if (kind === "recharge") {
        const short = shortfallProblem(await spendable(client, payer), input.amount, (n) => money(n, currency));
        if (short) {
          throw new Refused(short);
        }
      }
      const pending = await client.query<{ n: number }>(
        "SELECT count(*)::int AS n FROM balance_ledger WHERE NOT applied AND entry_type = 'TRANSFER' AND account_id = $1",
        [payer]
      );
      if ((pending.rows[0]?.n ?? 0) >= PENDING_TRANSFERS_MAX) {
        throw new Refused({
          status: 409,
          error: `There are already ${PENDING_TRANSFERS_MAX} transfers waiting to be applied. They apply on the `
            + "gateway's next poll; try again after that.",
        });
      }
      const row = await client.query<{ id: string }>(
        `INSERT INTO balance_ledger (account_id, delta, entry_type, counterparty_account_id, ref, note, applied)
         VALUES ($1, $2, 'TRANSFER', $3, $4, $5, FALSE) RETURNING id::text`,
        [payer, input.amount, payee, input.ref, transferNote(kind, by, input.reference)]
      );
      return Number(row.rows[0].id);
    });
    void nudgeConfig();
    return { ok: true, transferId: id, duplicate: false, released, problem };
  } catch (err) {
    if (err instanceof Refused) {
      return { ok: false, ...err.refusal };
    }
    if (isUniqueViolation(err)) {
      const again = await configQuery<{ id: string }>("SELECT id::text FROM balance_ledger WHERE ref = $1", [input.ref]);
      return { ok: true, transferId: Number(again[0]?.id ?? 0), duplicate: true, released };
    }
    throw err;
  }
}

export interface TransferRow {
  id: number;
  at: string;
  /** From the child's side: a recharge or opening credit adds, a withdrawal takes away. */
  kind: TransferKind;
  /** Signed from the child's side, scaled. */
  amount: number;
  applied: boolean;
  reference: string | null;
  by: string | null;
  via: "portal" | "api" | null;
}

/** The transfers between this reseller and one child, newest first. Movements with a former parent stay out. */
export async function listTransfers(resellerId: string, child: string, limit = 50): Promise<TransferRow[]> {
  const rows = await configQuery<{ id: string; account_id: string; delta: string; applied: boolean; note: string | null; created_at: Date | string }>(
    `SELECT id::text, account_id, delta::text, applied, note, created_at
       FROM balance_ledger
      WHERE entry_type = 'TRANSFER'
        AND ((account_id = $1 AND counterparty_account_id = $2)
          OR (account_id = $2 AND counterparty_account_id = $1))
      ORDER BY id DESC
      LIMIT $3`,
    [resellerId, child, limit]
  );
  return rows.map((r) => {
    const note = readTransferNote(r.note);
    const down = r.account_id === resellerId;
    const amount = Number(r.delta);
    return {
      id: Number(r.id),
      at: new Date(r.created_at).toISOString(),
      kind: down ? (note.kind === "opening" ? "opening" : "recharge") : "withdraw",
      amount: down ? amount : -amount,
      applied: r.applied,
      reference: note.reference,
      by: note.by,
      via: note.via,
    };
  });
}
