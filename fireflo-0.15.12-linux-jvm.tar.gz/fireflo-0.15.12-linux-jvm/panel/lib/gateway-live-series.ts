import { clusterPeers, createCapability, fanOut, postToNode, probeNode, CALL_MS, type FanoutResult } from "./gateway-fanout.ts";
import { gqlData } from "./gateway-graphql-core.ts";
import { byReason } from "./failure-groups.ts";
import { LIVE_FAILURES, LIVE_RECEIPT_QUALITY, LIVE_SERIES } from "./gateway-queries.ts";
import { sumRevenueByAccount, type RevenueRow, type TrafficBucket } from "./overview-totals.ts";
import { USAGE_PAGE_SIZE, type UsageBucket, type UsageGridRow, type UsageGridView } from "./usage-grid.ts";
import type { AccountRow, RevenueBucket, ServerTraffic, ServerTrafficRow, VendorRow } from "./metrics-queries.ts";
import type { ReceiptQualityRow } from "./receipt-queries.ts";
import type { FailureRowLike } from "./overview-snapshot.ts";

/**
 * The gateway's live series (gateway 0.15.1, capability `live_series`): the last hour and the last
 * 24 hours of traffic counted in the gateway's memory, so the charts an operator watches live never
 * wait on the database.
 *
 * <p><strong>This file is the adapter.</strong> The wire types, their normalisation, the cluster sum,
 * the gateway's grouping rules and the conversions to the shapes the charts already render
 * (`TrafficBucket`, `RevenueRow`, `RevenueBucket`, `VendorRow`, `AccountRow`, `ServerTraffic`,
 * `ReceiptQualityRow`, `UsageGridView`, `FailureRowLike`) all live here, so if the gateway's schema
 * moves, little else does. The documents are in `gateway-queries.ts`, checked against the gateway's
 * published schema (`lib/__fixtures__/schema.graphql`). Database-free
 * and pure: `gateway-live-series.test.ts` tests it without a gateway.
 *
 * <p>What the SQL readers do, kept here so the two sources agree:
 *
 * <ul>
 *   <li>1h is five-minute buckets, 24h is UTC hours, labelled `YYYY-MM-DDTHH:MM:SSZ` on the same
 *       boundaries as `date_bin` (5-minute bins on the 2000-01-01Z epoch) and `date_trunc('hour')`.</li>
 *   <li>Outcomes belong to the bucket the message was <em>submitted</em> in, as `cdr_submit.submitted_at`
 *       attributes them.</li>
 *   <li>`failed` is FAILED, REJECTED and DROPPED. The gateway has no EXPIRED event (the sweeper is
 *       SQL), so a bucket wholly older than `smsg.cdr.deadline.hours` has its pending counted as
 *       expired -- what the sweeper will have written.</li>
 *   <li>Money is the BIGINT scaled by 10 000, as in the database; `priceSum`/`costSum` may arrive as
 *       strings (a GraphQL Long) and are numbers here.</li>
 *   <li>Revenue's `messages` is submitted less vendor-refused: the SQL's `submitted - refused`, where
 *       `refused` is the vendor refusals that were refunded.</li>
 * </ul>
 */

export type LiveRange = "H1" | "H24";
export type LiveGrain = "MINUTE" | "FIVE_MINUTES" | "HOUR";
export type LiveGroup = "ACCOUNT" | "LOGIN" | "LISTENER" | "PRODUCT" | "VENDOR";
/** The panel's own names for the two ranges this serves. */
export type LivePanelRange = "1h" | "24h";

export interface LiveFilter {
  account?: string | null;
  login?: string | null;
  listener?: string | null;
  vendor?: string | null;
  product?: string | null;
}

export interface LiveKeys {
  account: string | null;
  login: string | null;
  listener: string | null;
  product: string | null;
  vendor: string | null;
}

/** One bucket of one key combination, as the gateway counts it. */
export interface LiveBucket {
  bucket: string;
  keys: LiveKeys;
  /** Before `backfilledThrough`: the hour from `usage_hourly`, all of it in its first minute. */
  backfilled: boolean;
  /**
   * Accepted at the door. On a vendor series (grouped or filtered by vendor): what the vendor took
   * or refused for good, one per message -- the SQL's representative attempt.
   */
  submitted: number;
  /** Refused at the door, by reason below. Never in `submitted`; 0 on a vendor series. */
  refused: number;
  refusedBy: { reason: string; count: number }[];
  priceSum: number;
  costSum: number;
  /** Every vendor attempt, retries included: a vendor series only, else null. */
  attempts: number | null;
  /** Taken by a vendor. */
  sent: number;
  /** Refused by a vendor for good (refunded). */
  vendorRefused: number;
  delivered: number;
  /** FAILED, REJECTED and DROPPED. */
  failed: number;
  /** Expired in a vendor's queue, or swept EXPIRED in a backfilled hour. */
  expired: number;
  /** submitted - delivered - failed - expired: no outcome yet. Past the deadline, read as expired. */
  pending: number;
}

/** One node's answer. */
export interface LiveSeries {
  node: string;
  /** When this node started counting, ISO. */
  liveSince: string | null;
  /** How far its restart backfill from `usage_hourly` reaches, or null when it had none. */
  backfilledThrough: string | null;
  /** `smsg.cdr.deadline.hours` as the node reads it. */
  deadlineHours: number | null;
  /** The window the node answered: the first minute's start and the end of the minute in progress. */
  from: string | null;
  until: string | null;
  /** Keys held, and the cap past which new ones count under "other". */
  keys: number;
  maxKeys: number;
  buckets: LiveBucket[];
}

/** The cluster's answer: every node's buckets summed by bucket and key. */
export interface LiveSeriesSum {
  /** The nodes whose answers are in the sum. */
  nodes: string[];
  /** Alive nodes that were asked and did not answer: their share is missing. */
  partial: string[];
  /** The nodes in `partial` that timed out rather than refused (0.15.1); absent when none did. */
  slow?: string[];
  /** The latest `liveSince` of any node: before it, at least one node's share is missing. */
  liveSince: string | null;
  /** The earliest backfill of any node, or null when any node had none. */
  backfilledThrough: string | null;
  deadlineHours: number;
  /** Nodes holding as many keys as their cap: new keys there count under "other". */
  saturated: string[];
  buckets: LiveBucket[];
  /**
   * The earliest node's end of the minute in progress, so a reader can tell the last full minute
   * from the one still counting; null when no node said. Optional: older fixtures leave it out.
   */
  until?: string | null;
}

/** One vendor's receipts on one node (`liveReceiptQuality(...).vendors[]`, flattened with its node). */
export interface LiveReceiptQuality {
  node: string;
  vendor: string | null;
  /** Every submit handed to it, retries included: the gateway's `attempts`. */
  sent: number;
  accepted: number;
  refused: number;
  reported: number;
  delivered: number;
  failed: number;
  /** Swept EXPIRED (backfilled hours only). */
  expired: number;
  open: number;
  /** Seconds from the vendor taking the message to its receipt; null with none in the range. */
  medianToOutcome: number | null;
  p90ToOutcome: number | null;
}

/** One failure kind as one node counts it: messages whose outcome was not DELIVERED, by key. */
export interface LiveFailure {
  node: string;
  account: string | null;
  vendor: string | null;
  finalState: string;
  dlrState: number | null;
  errCode: string | null;
  vendorErrCode: string | null;
  messages: number;
  /** The newest submit of this kind in the window, ISO. */
  lastSeen: string;
}

/** The gateway's own default (CdrExpirySweeper), for an answer that does not say. */
export const DEFAULT_DEADLINE_HOURS = 24;

// ---- the documents: LIVE_SERIES, LIVE_RECEIPT_QUALITY, LIVE_FAILURES in gateway-queries.ts ----

/** The capability the gateway publishes in `health.api`. */
export const LIVE_SERIES_CAPABILITY = "live_series";

// ---- ranges and grains ----

export const GRAIN_MS: Record<LiveGrain, number> = { MINUTE: 60_000, FIVE_MINUTES: 300_000, HOUR: 3_600_000 };
const RANGE_HOURS: Record<LivePanelRange, number> = { "1h": 1, "24h": 24 };

export function isLiveRange(range: string): range is LivePanelRange {
  return range === "1h" || range === "24h";
}

export function liveRangeOf(range: LivePanelRange): LiveRange {
  return range === "1h" ? "H1" : "H24";
}

/** The grain the SQL uses for the range: five minutes for the hour, hours for the day. */
export function grainOf(range: LivePanelRange): LiveGrain {
  return range === "1h" ? "FIVE_MINUTES" : "HOUR";
}

/** The window the SQL reads: `[now - hours, now)`. */
export function windowOf(range: LivePanelRange, now: Date): { since: Date; until: Date } {
  return { since: new Date(now.getTime() - RANGE_HOURS[range] * 3_600_000), until: now };
}

/** A bucket key as the SQL emits it: the UTC instant without milliseconds. */
export function bucketLabel(at: number): string {
  return new Date(at).toISOString().replace(/\.\d{3}Z$/, "Z");
}

// ---- normalisation ----

function num(v: unknown): number {
  const n = typeof v === "number" ? v : Number(v ?? 0);
  return Number.isFinite(n) ? n : 0;
}

function numOrNull(v: unknown): number | null {
  if (v === null || v === undefined || v === "") {
    return null;
  }
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function key(v: unknown): string | null {
  return typeof v === "string" && v !== "" ? v : null;
}

function iso(v: unknown): string | null {
  if (typeof v !== "string" || v === "") {
    return null;
  }
  const t = Date.parse(v);
  return Number.isFinite(t) ? new Date(t).toISOString() : null;
}

/** The bucket label normalised to `YYYY-MM-DDTHH:MM:SSZ`, whatever precision the wire carried. */
function label(v: unknown): string | null {
  const t = typeof v === "string" ? Date.parse(v) : NaN;
  return Number.isFinite(t) ? bucketLabel(t) : null;
}

/** One node's `liveSeries`, numbers as numbers, empty keys as none. Malformed buckets are dropped. */
export function normaliseSeries(raw: unknown): LiveSeries {
  const r = (raw ?? {}) as Record<string, unknown>;
  const buckets: LiveBucket[] = [];
  for (const b of Array.isArray(r.buckets) ? (r.buckets as Record<string, unknown>[]) : []) {
    const at = label(b?.bucket);
    if (at === null) {
      continue;
    }
    const k = (b.keys ?? {}) as Record<string, unknown>;
    buckets.push({
      bucket: at,
      keys: { account: key(k.account), login: key(k.login), listener: key(k.listener), product: key(k.product), vendor: key(k.vendor) },
      submitted: num(b.submitted),
      refused: num(b.refused),
      refusedBy: Array.isArray(b.refusedBy)
        ? (b.refusedBy as Record<string, unknown>[]).map((x) => ({ reason: String(x?.reason ?? "other"), count: num(x?.count) }))
        : [],
      priceSum: num(b.priceSum),
      costSum: num(b.costSum),
      attempts: numOrNull(b.attempts),
      sent: num(b.sent),
      vendorRefused: num(b.vendorRefused),
      delivered: num(b.delivered),
      failed: num(b.failed),
      expired: num(b.expired),
      pending: Math.max(0, num(b.pending)),
      backfilled: b.backfilled === true,
    });
  }
  return {
    node: typeof r.node === "string" ? r.node : "",
    liveSince: iso(r.liveSince),
    backfilledThrough: iso(r.backfilledThrough),
    deadlineHours: numOrNull(r.deadlineHours),
    from: iso(r.from),
    until: iso(r.until),
    keys: num(r.keys),
    maxKeys: num(r.maxKeys),
    buckets,
  };
}

/**
 * One node's `liveReceiptQuality` -- one object, its `vendors` list -- as rows carrying the node.
 * `attempts` is the panel's `sent`; the timings are seconds already.
 */
export function normaliseReceiptQuality(raw: unknown): LiveReceiptQuality[] {
  const r = (raw ?? {}) as Record<string, unknown>;
  const node = typeof r.node === "string" ? r.node : "";
  return (Array.isArray(r.vendors) ? (r.vendors as Record<string, unknown>[]) : []).filter(Boolean).map((v) => ({
    node,
    vendor: key(v.vendor),
    sent: num(v.attempts),
    accepted: num(v.accepted),
    refused: num(v.refused),
    reported: num(v.reported),
    delivered: num(v.delivered),
    failed: num(v.failed),
    expired: num(v.expired),
    open: num(v.open),
    medianToOutcome: numOrNull(v.medianToOutcome),
    p90ToOutcome: numOrNull(v.p90ToOutcome),
  }));
}

/** One node's `liveFailures`; rows with no final state or no instant are dropped. */
export function normaliseFailures(raw: unknown): LiveFailure[] {
  const out: LiveFailure[] = [];
  for (const r of Array.isArray(raw) ? (raw as Record<string, unknown>[]) : []) {
    const lastSeen = iso(r?.lastSeen);
    const finalState = key(r?.finalState);
    if (!r || lastSeen === null || finalState === null) {
      continue;
    }
    out.push({
      node: typeof r.node === "string" ? r.node : "",
      account: key(r.account),
      vendor: key(r.vendor),
      finalState,
      dlrState: numOrNull(r.dlrState),
      errCode: key(r.errCode),
      vendorErrCode: key(r.vendorErrCode),
      messages: num(r.messages),
      lastSeen,
    });
  }
  return out;
}

// ---- the cluster sum ----

/** JSON, not a joined string: an id is free text and a separator could be in it. */
function keyOf(k: LiveKeys): string {
  return JSON.stringify([k.account, k.login, k.listener, k.product, k.vendor]);
}

function addInto(acc: LiveBucket, b: LiveBucket): void {
  acc.submitted += b.submitted;
  acc.refused += b.refused;
  acc.priceSum += b.priceSum;
  acc.costSum += b.costSum;
  if (b.attempts !== null) {
    acc.attempts = (acc.attempts ?? 0) + b.attempts;
  }
  acc.sent += b.sent;
  acc.vendorRefused += b.vendorRefused;
  acc.delivered += b.delivered;
  acc.failed += b.failed;
  acc.expired += b.expired;
  acc.pending += b.pending;
  //a minute is backfilled on one node and live on another: it is partly both, and "backfilled" is
  //the claim that needs every node
  acc.backfilled = acc.backfilled && b.backfilled;
  for (const r of b.refusedBy) {
    const hit = acc.refusedBy.find((x) => x.reason === r.reason);
    if (hit) {
      hit.count += r.count;
    } else {
      acc.refusedBy.push({ ...r });
    }
  }
}

function copy(b: LiveBucket): LiveBucket {
  return { ...b, keys: { ...b.keys }, refusedBy: b.refusedBy.map((r) => ({ ...r })) };
}

/**
 * Every node's answer summed by bucket and key, buckets in time order.
 *
 * <p>`liveSince` is the latest of the nodes' (before it some node's share is missing);
 * `backfilledThrough` the earliest, and null when any node had none; `deadlineHours` the largest
 * any node reports, so nothing is called expired before every node would sweep it.
 */
export function sumSeries(answers: readonly LiveSeries[], partial: readonly string[] = [], slow: readonly string[] = []): LiveSeriesSum {
  const byKey = new Map<string, LiveBucket>();
  for (const a of answers) {
    for (const b of a.buckets) {
      const k = `${b.bucket}|${keyOf(b.keys)}`;
      const acc = byKey.get(k);
      if (acc) {
        addInto(acc, b);
      } else {
        byKey.set(k, copy(b));
      }
    }
  }
  const since = answers.map((a) => a.liveSince).filter((s): s is string => s !== null).sort();
  const backfills = answers.map((a) => a.backfilledThrough);
  const deadlines = answers.map((a) => a.deadlineHours).filter((d): d is number => d !== null && d > 0);
  return {
    nodes: answers.map((a) => a.node),
    partial: [...partial],
    ...(slow.length ? { slow: [...slow] } : {}),
    liveSince: since.length ? since[since.length - 1] : null,
    backfilledThrough: backfills.length && backfills.every((b) => b !== null) ? (backfills as string[]).sort()[0] : null,
    deadlineHours: deadlines.length ? Math.max(...deadlines) : DEFAULT_DEADLINE_HOURS,
    saturated: answers.filter((a) => a.maxKeys > 0 && a.keys >= a.maxKeys).map((a) => a.node),
    until: answers.map((a) => a.until).filter((u): u is string => u !== null).sort()[0] ?? null,
    buckets: [...byKey.values()].sort((x, y) => (x.bucket < y.bucket ? -1 : x.bucket > y.bucket ? 1 : 0)),
  };
}

/**
 * Receipt quality summed per vendor across nodes. Counts add; the timings cannot, so each is the
 * mean of the nodes' weighted by how many outcomes each saw -- exact on one node, an estimate on
 * several (a median of medians is not the median).
 */
export function sumReceiptQuality(rows: readonly LiveReceiptQuality[]): LiveReceiptQuality[] {
  const by = new Map<string, { row: LiveReceiptQuality; mw: number; pw: number; w: number }>();
  for (const r of rows) {
    const k = JSON.stringify(r.vendor);
    let acc = by.get(k);
    if (!acc) {
      acc = {
        row: { ...r, node: "", sent: 0, accepted: 0, refused: 0, reported: 0, delivered: 0, failed: 0, expired: 0, open: 0,
          medianToOutcome: null, p90ToOutcome: null },
        mw: 0, pw: 0, w: 0,
      };
      by.set(k, acc);
    }
    for (const f of ["sent", "accepted", "refused", "reported", "delivered", "failed", "expired", "open"] as const) {
      acc.row[f] += r[f];
    }
    if (r.medianToOutcome !== null && r.p90ToOutcome !== null && r.reported > 0) {
      acc.mw += r.medianToOutcome * r.reported;
      acc.pw += r.p90ToOutcome * r.reported;
      acc.w += r.reported;
    }
  }
  return [...by.values()].map(({ row, mw, pw, w }) => ({
    ...row,
    medianToOutcome: w > 0 ? mw / w : null,
    p90ToOutcome: w > 0 ? pw / w : null,
  }));
}

/**
 * Failures summed across nodes by every key (account, vendor, final state, receipt state, error
 * codes): `messages` added, the newest `lastSeen` kept. Largest first.
 */
export function sumFailures(rows: readonly LiveFailure[]): LiveFailure[] {
  const by = new Map<string, LiveFailure>();
  for (const r of rows) {
    const k = JSON.stringify([r.account, r.vendor, r.finalState, r.dlrState, r.errCode, r.vendorErrCode]);
    const acc = by.get(k);
    if (acc) {
      acc.messages += r.messages;
      if (r.lastSeen > acc.lastSeen) {
        acc.lastSeen = r.lastSeen;
      }
    } else {
      by.set(k, { ...r, node: "" });
    }
  }
  return [...by.values()].sort((x, y) => y.messages - x.messages);
}

// ---- the window and the seam with the database ----

export interface ConvertContext {
  range: LivePanelRange;
  now: Date;
  deadlineHours: number;
}

function widthOf(range: LivePanelRange): number {
  return GRAIN_MS[grainOf(range)];
}

/** Buckets that overlap the window `[now - range, now)`, as the SQL's first, partial bucket does. */
export function inWindow(buckets: readonly LiveBucket[], ctx: ConvertContext, widthMs = widthOf(ctx.range)): LiveBucket[] {
  const { since, until } = windowOf(ctx.range, ctx.now);
  return buckets.filter((b) => {
    const t = Date.parse(b.bucket);
    return t + widthMs > since.getTime() && t < until.getTime();
  });
}

/**
 * Where the live series must be joined to the database, or null when it covers the window alone.
 *
 * <p>With no backfill, every node's count starts at its `liveSince`. The seam is the first bucket
 * boundary at or after the latest of those, so that every bucket from it on is whole on every
 * node, and the window before it -- `[since, seam)` -- is read from the database for all of them.
 * Cutting at `liveSince` itself would be exact on one node and double count on a cluster, where an
 * older node's share before the restart is in both. Null when there is a backfill, when the nodes
 * did not say when they started, or when they started before the window.
 */
export function spliceFrom(
  sum: Pick<LiveSeriesSum, "liveSince" | "backfilledThrough">,
  range: LivePanelRange,
  now: Date,
  width = widthOf(range)
): Date | null {
  if (sum.backfilledThrough !== null || sum.liveSince === null) {
    return null;
  }
  const started = Date.parse(sum.liveSince);
  const seam = Math.ceil(started / width) * width;
  const { since } = windowOf(range, now);
  if (seam <= Math.floor(since.getTime() / width) * width) {
    return null;
  }
  return new Date(Math.min(seam, now.getTime()));
}

/** The buckets from the seam on: the part the database does not serve. */
export function fromSeam(buckets: readonly LiveBucket[], seam: Date | null): LiveBucket[] {
  return seam === null ? [...buckets] : buckets.filter((b) => Date.parse(b.bucket) >= seam.getTime());
}

/** Whether every message in a bucket is past the deadline: its pending is what the sweeper expired. */
function expiredBucket(bucket: string, widthMs: number, ctx: ConvertContext): boolean {
  return Date.parse(bucket) + widthMs <= ctx.now.getTime() - ctx.deadlineHours * 3_600_000;
}

/**
 * What is still open and what has expired: the gateway's own `expired` (a vendor's queue, or a
 * backfilled hour's sweep), plus pending in a bucket wholly past the deadline -- what the SQL sweeper
 * will have closed, which the ledger still holds as pending. `swept` is that second part alone.
 */
function outcome(b: LiveBucket, widthMs: number, ctx: ConvertContext): { pending: number; expired: number; swept: number } {
  const swept = expiredBucket(b.bucket, widthMs, ctx) ? b.pending : 0;
  return { pending: b.pending - swept, expired: b.expired + swept, swept };
}

function byOrder(x: string, y: string): number {
  return x < y ? -1 : x > y ? 1 : 0;
}

// ---- conversions to the chart shapes ----

/** `trafficOverTime`'s shape: per bucket, every key summed. */
export function toTraffic(buckets: readonly LiveBucket[], ctx: ConvertContext): TrafficBucket[] {
  const width = widthOf(ctx.range);
  const by = new Map<string, TrafficBucket>();
  for (const b of buckets) {
    const o = outcome(b, width, ctx);
    const acc = by.get(b.bucket) ?? { bucket: b.bucket, submitted: 0, delivered: 0, failed: 0, expired: 0, pending: 0 };
    acc.submitted += b.submitted;
    acc.delivered += b.delivered;
    acc.failed += b.failed;
    acc.expired += o.expired;
    acc.pending += o.pending;
    by.set(b.bucket, acc);
  }
  return [...by.values()].sort((x, y) => byOrder(x.bucket, y.bucket));
}

/**
 * `revenueByAccount`'s shape: per account and product. `pendingRevenue` is 0: the series counts
 * what is pending, not its money -- as `usage_hourly` does for rolled hours.
 */
export function toRevenueRows(buckets: readonly LiveBucket[]): RevenueRow[] {
  return sumRevenueByAccount(
    buckets.map((b) => ({
      accountId: b.keys.account,
      product: b.keys.product,
      messages: b.submitted - b.vendorRefused,
      revenue: b.priceSum,
      cost: b.costSum,
      margin: b.priceSum - b.costSum,
      pendingRevenue: 0,
    }))
  );
}

/** `revenueSeries`'s shape: per bucket. */
export function toRevenueSeries(buckets: readonly LiveBucket[]): RevenueBucket[] {
  const by = new Map<string, RevenueBucket>();
  for (const b of buckets) {
    const acc = by.get(b.bucket) ?? { bucket: b.bucket, messages: 0, revenue: 0, cost: 0 };
    acc.messages += b.submitted - b.vendorRefused;
    acc.revenue += b.priceSum;
    acc.cost += b.costSum;
    by.set(b.bucket, acc);
  }
  return [...by.values()].sort((x, y) => byOrder(x.bucket, y.bucket));
}

function rate(delivered: number, failed: number): number | null {
  return delivered + failed === 0 ? null : delivered / (delivered + failed);
}

/**
 * `vendorPerformance`'s shape, from buckets grouped by vendor. `attempts` is every attempt handed
 * over (`sent`); `messages` the accepted ones (`sent - vendorRefused`), which is what the outcome is
 * credited to; `failed` includes expired, as the SQL's does. Rows with nothing handed over and no
 * vendor -- ingress counts with no vendor dimension -- are not a vendor and are left out.
 */
export function toVendors(buckets: readonly LiveBucket[], ctx: ConvertContext, byAccount = false): VendorRow[] {
  const width = widthOf(ctx.range);
  const by = new Map<string, VendorRow>();
  for (const b of buckets) {
    if (b.submitted === 0 && b.sent === 0 && (b.attempts ?? 0) === 0) {
      continue;
    }
    const k = vendorKey(b.keys.vendor, byAccount ? b.keys.account : undefined);
    const o = outcome(b, width, ctx);
    const acc = by.get(k) ?? {
      vendor: b.keys.vendor,
      ...(byAccount ? { account: b.keys.account } : {}),
      attempts: 0, messages: 0, delivered: 0, failed: 0, pending: 0, cost: 0, deliveryRate: null,
    };
    //a vendor series: attempts are every submit, retries included; messages the representative one
    acc.attempts += b.attempts ?? b.sent;
    acc.messages += b.submitted;
    acc.delivered += b.delivered;
    acc.failed += b.failed + o.expired;
    acc.pending += o.pending;
    acc.cost += b.costSum;
    by.set(k, acc);
  }
  return finishVendors([...by.values()]);
}

/** A vendor row's key: the vendor, and the account when the rows are split by it. */
function vendorKey(vendor: string | null, account: string | null | undefined): string {
  return JSON.stringify(account === undefined ? [vendor] : [vendor, account]);
}

function finishVendors(rows: VendorRow[]): VendorRow[] {
  return rows
    .map((r) => ({ ...r, deliveryRate: rate(r.delivered, r.failed) }))
    .sort((x, y) => y.attempts - x.attempts);
}

/** The activity half of an `AccountRow`: what the series knows. Balance and idleness are added after. */
export type AccountActivity = Omit<AccountRow, "balance" | "currency" | "idle">;

/**
 * `accountUsage`'s activity rows, by account, login and product. `lastSeen` is the start of the
 * latest bucket with traffic -- the series knows the bucket, not the minute -- as a rolled row's is.
 */
export function toAccountActivity(buckets: readonly LiveBucket[], ctx: ConvertContext): AccountActivity[] {
  const width = widthOf(ctx.range);
  const by = new Map<string, AccountActivity>();
  for (const b of buckets) {
    if (b.submitted === 0 && b.delivered === 0 && b.failed === 0 && b.pending === 0) {
      continue;
    }
    const k = JSON.stringify([b.keys.account, b.keys.login, b.keys.product]);
    const o = outcome(b, width, ctx);
    const acc = by.get(k) ?? {
      accountId: b.keys.account,
      systemId: b.keys.login,
      product: b.keys.product,
      messages: 0,
      delivered: 0,
      failed: 0,
      pending: 0,
      billed: 0,
      cost: 0,
      deliveryRate: null,
      lastSeen: null,
    };
    acc.messages += b.submitted;
    acc.delivered += b.delivered;
    acc.failed += b.failed + o.expired;
    acc.pending += o.pending;
    acc.billed += b.priceSum;
    acc.cost += b.costSum;
    if (b.submitted > 0 && (acc.lastSeen === null || b.bucket > acc.lastSeen)) {
      acc.lastSeen = b.bucket;
    }
    by.set(k, acc);
  }
  return finishAccounts([...by.values()]);
}

function finishAccounts(rows: AccountActivity[]): AccountActivity[] {
  return rows
    .map((r) => ({ ...r, deliveryRate: rate(r.delivered, r.failed) }))
    .sort((x, y) => y.messages - x.messages);
}

export interface ConfiguredCredential {
  accountId: string | null;
  systemId: string | null;
  product: string | null;
}

/**
 * The Accounts page's rows: the activity with each account's balance, and every configured
 * credential that sent nothing as an idle row -- `accountUsage`'s rules, with the login split
 * (the series always has it).
 */
export function withBalances(
  activity: readonly AccountActivity[],
  configured: readonly ConfiguredCredential[],
  balances: ReadonlyMap<string, { balance: number; currency: string | null }>
): { creditEnforced: boolean; accounts: AccountRow[] } {
  const rows: AccountRow[] = activity.map((r) => {
    const b = balances.get(r.accountId ?? "");
    return { ...r, balance: b?.balance ?? null, currency: b?.currency ?? null, idle: false };
  });
  const seen = new Set(rows.map((r) => `${r.accountId}|${r.systemId}`));
  for (const c of configured) {
    if (seen.has(`${c.accountId}|${c.systemId}`)) continue;
    const b = balances.get(c.accountId ?? "");
    rows.push({
      accountId: c.accountId,
      systemId: c.systemId,
      product: c.product,
      messages: 0,
      delivered: 0,
      failed: 0,
      pending: 0,
      billed: 0,
      cost: 0,
      deliveryRate: null,
      lastSeen: null,
      balance: b?.balance ?? null,
      currency: b?.currency ?? null,
      idle: true,
    });
  }
  return { creditEnforced: balances.size > 0, accounts: rows };
}

/** Whether a series listener key names the Servers page's listener (`name` or `smppserver.name`). */
export function listenerMatches(listener: string | null, name: string): boolean {
  return listener === name || listener === `smppserver.${name}`;
}

/**
 * `serverTraffic`'s shape for one listener: by account, busiest first, at most `limit` rows; the
 * totals over every account. `failed` excludes expired here, which has its own column, as the SQL.
 */
export function toServerTraffic(buckets: readonly LiveBucket[], name: string, ctx: ConvertContext, limit: number): ServerTraffic {
  const width = widthOf(ctx.range);
  const by = new Map<string, ServerTrafficRow>();
  for (const b of buckets) {
    if (!listenerMatches(b.keys.listener, name) || b.submitted === 0) {
      continue;
    }
    const k = JSON.stringify(b.keys.account);
    const o = outcome(b, width, ctx);
    const acc = by.get(k) ?? { accountId: b.keys.account, messages: 0, delivered: 0, failed: 0, expired: 0, pending: 0 };
    acc.messages += b.submitted;
    acc.delivered += b.delivered;
    acc.failed += b.failed;
    acc.expired += o.expired;
    acc.pending += o.pending;
    by.set(k, acc);
  }
  return finishServerTraffic(ctx.range, [...by.values()], limit);
}

function finishServerTraffic(range: LivePanelRange, all: ServerTrafficRow[], limit: number): ServerTraffic {
  const sorted = all.sort((x, y) => y.messages - x.messages || byOrder(x.accountId ?? "￿", y.accountId ?? "￿"));
  return {
    range,
    rows: sorted.slice(0, limit),
    totals: {
      messages: all.reduce((n, r) => n + r.messages, 0),
      delivered: all.reduce((n, r) => n + r.delivered, 0),
      reported: all.reduce((n, r) => n + r.delivered + r.failed, 0),
    },
  };
}

/**
 * `receiptQuality`'s shape. The gateway's histogram gives sent, reported, open, delivered and the
 * timings (ms here, seconds there); `expired` is the pending of vendor buckets past the deadline,
 * taken out of `open` because the gateway does not know the sweeper ran. Progress receipts and the
 * first-sign timing are not in the series: null, which the page reads as "not recorded here".
 */
export function toReceipts(
  quality: readonly LiveReceiptQuality[],
  vendorBuckets: readonly LiveBucket[],
  ctx: ConvertContext
): ReceiptQualityRow[] {
  const width = widthOf(ctx.range);
  const swept = new Map<string, number>();
  for (const b of vendorBuckets) {
    const o = outcome(b, width, ctx);
    if (o.swept > 0) {
      const k = JSON.stringify(b.keys.vendor);
      swept.set(k, (swept.get(k) ?? 0) + o.swept);
    }
  }
  return sumReceiptQuality(quality)
    .map((q) => {
      const gone = Math.min(q.open, swept.get(JSON.stringify(q.vendor)) ?? 0);
      return {
        vendor: q.vendor,
        sent: q.sent,
        reported: q.reported,
        expired: q.expired + gone,
        open: q.open - gone,
        delivered: q.delivered,
        medianToOutcome: q.medianToOutcome,
        p90ToOutcome: q.p90ToOutcome,
        progressReceipts: null,
        messagesWithProgress: null,
        medianToFirstSign: null,
        sampled: null,
      };
    })
    .sort((x, y) => y.sent - x.sent);
}

/**
 * `usageGrid`'s view for the hour and the 24 hours (hour grain): one page of account × login ×
 * product rows, heaviest first, and every hour of the window, empty ones as zeros. `failed`
 * includes expired and `pending` excludes it, as the Usage page draws them. Buckets must be hourly.
 */
export function toUsageGrid(buckets: readonly LiveBucket[], ctx: ConvertContext, page: number): UsageGridView {
  const width = GRAIN_MS.HOUR;
  const { since, until } = windowOf(ctx.range, ctx.now);
  const rowsBy = new Map<string, UsageGridRow>();
  const seriesBy = new Map<string, UsageBucket>();
  for (let t = Math.floor(since.getTime() / width) * width; t < until.getTime(); t += width) {
    const at = bucketLabel(t);
    seriesBy.set(at, { bucket: at, submitted: 0, delivered: 0, failed: 0, pending: 0, price: 0 });
  }
  for (const b of buckets) {
    const o = outcome(b, width, ctx);
    const k = JSON.stringify([b.keys.account, b.keys.login, b.keys.product]);
    const row = rowsBy.get(k) ?? { accountId: b.keys.account, login: b.keys.login, product: b.keys.product, submitted: 0, delivered: 0, failed: 0, pending: 0, price: 0 };
    for (const acc of [row, seriesBy.get(b.bucket)]) {
      if (!acc) continue;
      acc.submitted += b.submitted;
      acc.delivered += b.delivered;
      acc.failed += b.failed + o.expired;
      acc.pending += o.pending;
      acc.price += b.priceSum;
    }
    rowsBy.set(k, row);
  }
  //as usageRowsSql orders: heaviest first, then the keys with none last
  const last = (v: string | null) => v ?? "￿";
  const all = [...rowsBy.values()].sort(
    (x, y) =>
      y.submitted - x.submitted ||
      byOrder(last(x.accountId), last(y.accountId)) ||
      byOrder(last(x.login), last(y.login)) ||
      byOrder(last(x.product), last(y.product))
  );
  return {
    grain: "hour",
    since: since.toISOString(),
    until: until.toISOString(),
    page,
    pageSize: USAGE_PAGE_SIZE,
    totalRows: all.length,
    rows: all.slice(page * USAGE_PAGE_SIZE, (page + 1) * USAGE_PAGE_SIZE),
    series: [...seriesBy.values()],
    //the series always carries the login
    logins: { daily: true, hourly: true },
  };
}

/**
 * `failureBreakdown`'s rows, per account, vendor and carrier code -- what the failure ring draws at
 * every depth: `messages` summed and the newest `lastSeen` kept per key. With `vendorBuckets` (the
 * series grouped by account and vendor), each pair's pending in buckets wholly past the deadline is
 * added as EXPIRED with no receipt state or code, as the sweeper writes it: the gateway has no
 * EXPIRED event to count. Only the vendor side's buckets count there, so an ingress count of the
 * same messages is not expired twice. Largest first, `lastSeen` as an ISO instant.
 */
export function toFailureRows(
  failures: readonly LiveFailure[],
  ctx?: ConvertContext,
  vendorBuckets: readonly LiveBucket[] = []
): FailureRowLike[] {
  const by = new Map<string, FailureRowLike>();
  const add = (row: FailureRowLike) => {
    const k = JSON.stringify([row.account ?? null, row.vendor ?? null, row.finalState, row.dlrState, row.errCode, row.vendorErrCode ?? null]);
    const acc = by.get(k);
    if (acc) {
      acc.messages += row.messages;
      if (row.lastSeen > acc.lastSeen) {
        acc.lastSeen = row.lastSeen;
      }
    } else {
      by.set(k, { ...row });
    }
  };
  for (const f of failures) {
    if (f.finalState === "DELIVERED" || f.messages <= 0) {
      continue;
    }
    add({
      finalState: f.finalState,
      dlrState: f.dlrState,
      errCode: f.errCode,
      account: f.account,
      vendor: f.vendor,
      vendorErrCode: f.vendorErrCode,
      messages: f.messages,
      lastSeen: f.lastSeen,
    });
  }
  if (ctx) {
    const width = widthOf(ctx.range);
    for (const b of vendorBuckets) {
      const o = outcome(b, width, ctx);
      //only what the deadline closes: a vendor queue's expiry is in liveFailures already, as EXPIRED
      if (o.swept > 0) {
        add({
          finalState: "EXPIRED",
          dlrState: null,
          errCode: null,
          account: b.keys.account,
          vendor: b.keys.vendor,
          vendorErrCode: null,
          messages: o.swept,
          lastSeen: new Date(Date.parse(b.bucket)).toISOString(),
        });
      }
    }
  }
  return [...by.values()].sort((x, y) => y.messages - x.messages);
}

/** The reasons list: the per-account rows summed back per failure kind, as the overview reader folds them. */
export function failureReasons(rows: readonly FailureRowLike[]): FailureRowLike[] {
  return byReason(rows);
}

// ---- joining a database read from before the seam ----

/** Traffic: the database's buckets before the seam, the series' from it, summed where they meet. */
export function mergeTraffic(sql: readonly TrafficBucket[], live: readonly TrafficBucket[]): TrafficBucket[] {
  const by = new Map<string, TrafficBucket>();
  for (const b of [...sql, ...live]) {
    const acc = by.get(b.bucket);
    if (acc) {
      acc.submitted += b.submitted;
      acc.delivered += b.delivered;
      acc.failed += b.failed;
      acc.expired += b.expired;
      acc.pending += b.pending;
    } else {
      by.set(b.bucket, { ...b });
    }
  }
  return [...by.values()].sort((x, y) => byOrder(x.bucket, y.bucket));
}

export function mergeRevenueSeries(sql: readonly RevenueBucket[], live: readonly RevenueBucket[]): RevenueBucket[] {
  const by = new Map<string, RevenueBucket>();
  for (const b of [...sql, ...live]) {
    const acc = by.get(b.bucket);
    if (acc) {
      acc.messages += b.messages;
      acc.revenue += b.revenue;
      acc.cost += b.cost;
    } else {
      by.set(b.bucket, { ...b });
    }
  }
  return [...by.values()].sort((x, y) => byOrder(x.bucket, y.bucket));
}

export function mergeRevenueRows(sql: readonly RevenueRow[], live: readonly RevenueRow[]): RevenueRow[] {
  return sumRevenueByAccount([...sql, ...live]);
}

export function mergeVendors(sql: readonly VendorRow[], live: readonly VendorRow[]): VendorRow[] {
  const by = new Map<string, VendorRow>();
  for (const r of [...sql, ...live]) {
    const k = vendorKey(r.vendor, r.account);
    const acc = by.get(k);
    if (acc) {
      acc.attempts += r.attempts;
      acc.messages += r.messages;
      acc.delivered += r.delivered;
      acc.failed += r.failed;
      acc.pending += r.pending;
      acc.cost += r.cost;
    } else {
      by.set(k, { ...r });
    }
  }
  return finishVendors([...by.values()]);
}

/** Accounts: active rows summed by account, login and product; idle and balance are added after. */
export function mergeAccountActivity(sql: readonly AccountActivity[], live: readonly AccountActivity[]): AccountActivity[] {
  const by = new Map<string, AccountActivity>();
  for (const r of [...sql, ...live]) {
    const k = JSON.stringify([r.accountId, r.systemId, r.product]);
    const acc = by.get(k);
    if (acc) {
      acc.messages += r.messages;
      acc.delivered += r.delivered;
      acc.failed += r.failed;
      acc.pending += r.pending;
      acc.billed += r.billed;
      acc.cost += r.cost;
      if (r.lastSeen !== null && (acc.lastSeen === null || r.lastSeen > acc.lastSeen)) {
        acc.lastSeen = r.lastSeen;
      }
    } else {
      by.set(k, { ...r });
    }
  }
  return finishAccounts([...by.values()]);
}

export function mergeServerTraffic(sql: ServerTraffic, live: ServerTraffic, limit: number): ServerTraffic {
  //the database's rows are its top `limit`; its totals cover every account, so the totals add exactly
  //and a row beyond either top list is missing from the rows only, as on the database alone
  const by = new Map<string, ServerTrafficRow>();
  for (const r of [...sql.rows, ...live.rows]) {
    const k = JSON.stringify(r.accountId);
    const acc = by.get(k);
    if (acc) {
      acc.messages += r.messages;
      acc.delivered += r.delivered;
      acc.failed += r.failed;
      acc.expired += r.expired;
      acc.pending += r.pending;
    } else {
      by.set(k, { ...r });
    }
  }
  const merged = finishServerTraffic(live.range, [...by.values()], limit);
  return {
    ...merged,
    totals: {
      messages: sql.totals.messages + live.totals.messages,
      delivered: sql.totals.delivered + live.totals.delivered,
      reported: sql.totals.reported + live.totals.reported,
    },
  };
}

// ---- asking the gateway ----

/** How long an answer is kept: the overview, Traffic and the Vendors ring ask the same thing. */
const ANSWER_TTL_MS = 10_000;
const answers = new Map<string, { at: number; settled: boolean; value: Promise<unknown> }>();

/**
 * One read per key per {@link ANSWER_TTL_MS}, shared by every caller meanwhile (single flight) --
 * and for as long as it is in flight, however long a slow gateway takes. A failed read is forgotten
 * at once, so the next caller tries again rather than inheriting it.
 */
function kept<T>(key: string, ttlMs: number, read: () => Promise<T>): Promise<T> {
  const hit = answers.get(key);
  if (hit && (!hit.settled || Date.now() - hit.at < ttlMs)) {
    return hit.value as Promise<T>;
  }
  const value = read();
  const entry = { at: Date.now(), settled: false, value: value as Promise<unknown> };
  answers.set(key, entry);
  value.then(
    () => {
      entry.settled = true;
      entry.at = Date.now();
    },
    () => {
      if (answers.get(key) === entry) {
        answers.delete(key);
      }
    }
  );
  if (answers.size > 256) {
    //a bounded map: the oldest entry goes first (insertion order)
    answers.delete(answers.keys().next().value!);
  }
  return value;
}

/**
 * `live_series` on the main node, learnt from the reads themselves: the main node is never probed
 * before a read (0.15.1, `createCapability`).
 */
const capability = createCapability(LIVE_SERIES_CAPABILITY);

/**
 * Whether to read the live series: false once the gateway said it has no `live_series`, and for
 * the stats pages ({@link liveSeriesAvailable}) also for a while after a read found it slow or
 * absent -- they have the database to read instead of waiting on a busy gateway. Never asks the
 * gateway: until it has said, the read is made and tells.
 */
export async function liveSeriesAvailable(): Promise<boolean> {
  return capability.known() !== false && !capability.recentlyFailed();
}

/**
 * The same without the recent-failure rule, for a live route (the Connectivity counts): a slow
 * gateway is asked again on the next poll, and a page keeps its last answer meanwhile.
 */
export async function liveSeriesKnown(): Promise<boolean> {
  return capability.known() !== false;
}

/** For a test, or after a reload: ask again next time. */
export function forgetLiveSeries(): void {
  capability.forget();
  answers.clear();
}

/** The same document on the answering node and every alive peer; see `gateway-fanout.ts`. */
function everyNode<T>(query: string, variables: Record<string, unknown>): Promise<FanoutResult<T>> {
  return fanOut<T>({
    local: () => capability.call(() => gqlData<T>({ query, variables, timeoutMs: CALL_MS })),
    peers: clusterPeers,
    probe: (node) => probeNode(node, LIVE_SERIES_CAPABILITY),
    call: (node) => postToNode<T>(node, query, variables, CALL_MS),
  });
}

/**
 * The gateway's grouping rules, checked before asking (it answers BAD_REQUEST otherwise): a vendor
 * series knows the vendor and the account only, so VENDOR groups with ACCOUNT alone and a vendor
 * filter goes with an account filter alone; failures are kept per account and vendor only.
 *
 * @returns the sentence, or null when the request is one the gateway takes
 */
export function groupingProblem(
  field: "liveSeries" | "liveFailures",
  groupBy: readonly LiveGroup[],
  filter?: LiveFilter
): string | null {
  const other = (g: string) => g === "LOGIN" || g === "LISTENER" || g === "PRODUCT";
  const filtered = Object.entries(filter ?? {}).filter(([, v]) => v !== null && v !== undefined).map(([k]) => k.toUpperCase());
  if (field === "liveFailures") {
    return [...groupBy, ...filtered].some(other) ? "liveFailures is kept per account and vendor only" : null;
  }
  const vendor = groupBy.includes("VENDOR") || filtered.includes("VENDOR");
  if (vendor && [...groupBy, ...filtered].some(other)) {
    return "a vendor series knows the vendor and the account only";
  }
  return null;
}

/** `liveSeries` across the cluster, summed. Throws when the answering node cannot answer. */
export function fetchLiveSeries(
  range: LivePanelRange,
  grain: LiveGrain,
  groupBy: readonly LiveGroup[],
  filter?: LiveFilter
): Promise<LiveSeriesSum> {
  const clean = filter
    ? Object.fromEntries(Object.entries(filter).filter(([, v]) => v !== null && v !== undefined && v !== ""))
    : {};
  const problem = groupingProblem("liveSeries", groupBy, clean);
  if (problem) {
    return Promise.reject(new Error(`liveSeries ${JSON.stringify(groupBy)}: ${problem}`));
  }
  const variables: Record<string, unknown> = {
    range: liveRangeOf(range),
    grain,
    groupBy: [...groupBy].sort(),
    ...(Object.keys(clean).length ? { filter: clean } : {}),
  };
  return kept(`series|${JSON.stringify(variables)}`, ANSWER_TTL_MS, async () => {
    const { answers: got, partial, slow } = await everyNode<unknown>(LIVE_SERIES, variables);
    return sumSeries(got.map(normaliseSeries), partial, slow);
  });
}

/** `liveReceiptQuality` across the cluster, every node's rows (summed later, per vendor). */
export function fetchLiveReceiptQuality(range: LivePanelRange): Promise<{ rows: LiveReceiptQuality[]; partial: string[] }> {
  const variables = { range: liveRangeOf(range) };
  return kept(`receipts|${JSON.stringify(variables)}`, ANSWER_TTL_MS, async () => {
    const { answers: got, partial } = await everyNode<unknown>(LIVE_RECEIPT_QUALITY, variables);
    return { rows: got.flatMap(normaliseReceiptQuality), partial };
  });
}

/** `liveFailures` across the cluster, summed by key. Throws when the answering node cannot answer. */
export function fetchLiveFailures(
  range: LivePanelRange,
  groupBy: readonly LiveGroup[] = ["ACCOUNT", "VENDOR"],
  filter?: LiveFilter
): Promise<{ rows: LiveFailure[]; partial: string[] }> {
  const problem = groupingProblem("liveFailures", groupBy, filter);
  if (problem) {
    return Promise.reject(new Error(`liveFailures ${JSON.stringify(groupBy)}: ${problem}`));
  }
  const variables: Record<string, unknown> = {
    range: liveRangeOf(range),
    groupBy: [...groupBy].sort(),
    ...(filter ? { filter } : {}),
  };
  return kept(`failures|${JSON.stringify(variables)}`, ANSWER_TTL_MS, async () => {
    const { answers: got, partial } = await everyNode<unknown>(LIVE_FAILURES, variables);
    return { rows: sumFailures(got.flatMap(normaliseFailures)), partial };
  });
}
