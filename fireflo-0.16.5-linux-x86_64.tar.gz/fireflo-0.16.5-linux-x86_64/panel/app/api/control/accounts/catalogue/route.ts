import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { getAccount, listAccounts, listOrphanAccounts, saveAccount } from "@/lib/accounts";
import { type Account, mergeAccountInput, newAccountIdProblem, validateAccount } from "@/lib/account-types";
import { takenAccountIds } from "@/lib/mis-accounts";
import { logOperatorEvent } from "@/lib/access-log";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { passwordProblem } from "@/lib/password-policy";
import { requireOperator } from "@/lib/require-operator";
import { DuplicateUserError, setCustomerPassword } from "@/lib/users";

const TABLES = "app_account";

/**
 * The account catalogue, and the ids in use that are not in it.
 *
 * <p>Under `/accounts/catalogue` rather than at `/accounts`, which already means something else: the
 * traffic view, grouped by account, system id and product from call records. One is who is
 * provisioned, the other is who actually sent, and conflating the two routes would conflate the two
 * ideas.
 *
 * <p>Orphans come back with the list because a catalogue that silently omits the accounts nobody has
 * named yet would be worse than no catalogue. Since V1.55.0 logins and balances cannot produce one;
 * a rate scope still can, because that column names vendors too and so has no foreign key.
 *
 */
export async function GET(): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  try {
    //archived accounts (V1.100.0) come back apart, for the list's "Archived" filter: out of the
    //everyday list, never out of reach
    const [accounts, orphans, archived] = await Promise.all([
      listAccounts(), listOrphanAccounts(), listAccounts({ archived: true }),
    ]);
    return NextResponse.json({ data: { accounts, orphans, archived } });
  } catch (err) {
    return configFailed("account catalogue", err);
  }
}

/**
 * Creates or updates one account.
 *
 * <p>One verb for both, because an id routinely exists as a string before it exists as a row.
 * Adopting an orphan and renaming a catalogued account are the same write, and making the caller
 * choose would mean it had to know which case it was in.
 */
export async function PUT(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const input = body as {
    id?: unknown; label?: unknown; description?: unknown; email?: unknown; enabled?: unknown;
    resells?: unknown; parentAccountId?: unknown; portalPassword?: unknown;
  };
  //the row as it stands, read first: a field the body leaves out keeps its stored value (see
  //mergeAccountInput), so the email checked below is the one that will be saved
  const askedId = typeof input.id === "string" ? input.id.trim() : "";
  let before: Account | null = null;
  if (askedId) {
    try {
      before = await getAccount(askedId);
    } catch (err) {
      return configFailed("save account", err);
    }
  }
  const fields = mergeAccountInput(before, input as Record<string, unknown>);
  const email = fields.email;
  const portalPassword = typeof input.portalPassword === "string" && input.portalPassword ? input.portalPassword : null;
  if (portalPassword) {
    if (!email?.trim()) {
      return NextResponse.json({ error: "A portal password needs an email address to belong to." }, { status: 400 });
    }
    const weak = passwordProblem(portalPassword, email);
    if (weak) {
      return NextResponse.json({ error: weak }, { status: 400 });
    }
  }
  const invalid = validateAccount({
    id: typeof input.id === "string" ? input.id : "",
    email,
    enabled: fields.enabled,
  });
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }

  try {
    const accountId = String(input.id).trim();
    //one upsert, two acts. Editing a row, or ADOPTING an id the gateway already bills to (an
    //orphan: a credential's billing key, or a rate scope that is not a vendor), takes the id as it
    //is -- a legacy id has to stay nameable whatever it looks like. An id nobody has ever used is
    //being minted here, and gets the rule a minted id gets everywhere else: well-formed, and not a
    //vendor's name, since app_rate_rule.scope would then name two things. A vendor's name is never
    //an orphan -- listOrphanAccounts leaves vendor names out of the rate-scope arm -- so it reaches
    //the rule and is refused whichever way it was typed
    if (!before) {
      const orphan = (await listOrphanAccounts()).some((o) => o.id === accountId);
      if (!orphan) {
        const problem = newAccountIdProblem(accountId, await takenAccountIds());
        if (problem) {
          return NextResponse.json({ error: problem }, { status: 400 });
        }
      }
    }
    await saveAccount({
      id: accountId,
      ...fields,
      //the shape of the tree is held by the database -- a composite foreign key forces a parent to
      //be a reseller and a CHECK caps it at two levels -- so nothing is re-validated here. A second
      //implementation in TypeScript could only disagree with the one that actually holds, and would
      //still lose the race where the parent stops reselling between the check and the write
    });
    //who changed what on the account, for its activity history. Read back rather than taken from the
    //request, so the record is what the database now holds
    const after = await getAccount(accountId);
    const changed = accountChanges(before, after);
    if (after && (!before || Object.keys(changed).length > 0)) {
      const operator = await requireOperator();
      void logOperatorEvent({
        event: "account_updated",
        actor: operator.name,
        userId: operator.userId,
        ip: clientIp(req),
        userAgent: clientUserAgent(req),
        detail: { account: accountId, created: !before, changed },
      });
    }
    if (portalPassword) {
      await setCustomerPassword(accountId, email!, portalPassword);
      const admin = await requireOperator();
      void logOperatorEvent({
        event: "user_password_set",
        actor: admin.name,
        userId: admin.userId,
        ip: clientIp(req),
        userAgent: clientUserAgent(req),
        detail: { subject: email!.trim(), account: accountId },
      });
    }
    return NextResponse.json({ data: { id: String(input.id).trim() } });
  } catch (err) {
    if (err instanceof DuplicateUserError) {
      return NextResponse.json({ error: `${err.message} That login belongs to another account.` }, { status: 409 });
    }
    //`uq_app_account_email` is case-insensitive, so the clash may not look like one to whoever hit
    //it. Said in words rather than letting a constraint name reach the interface
    if ((err as { code?: string })?.code === "23505") {
      return NextResponse.json(
        {
          error: `'${email}' is already the address on another account. An email identifies one `
            + "account, ignoring case, so that a sign-in link can tell which one it is for.",
        },
        { status: 409 }
      );
    }
    //saveAccount already turned the two-level constraints into a sentence an operator can act on.
    //Letting configFailed swallow that into "could not save account" would throw away the only part
    //of the message that says what to do next
    if (err instanceof Error && /reseller|two levels/i.test(err.message)) {
      return NextResponse.json({ error: err.message }, { status: 409 });
    }
    return configFailed("save account", err);
  }
}

const AUDITED = ["label", "description", "email", "enabled", "resells", "parentAccountId"] as const;

/** Each audited field whose value differs, as `{from, to}`. Everything, from null, for a new row. */
function accountChanges(
  before: Account | null,
  after: Account | null
): Record<string, { from: unknown; to: unknown }> {
  const out: Record<string, { from: unknown; to: unknown }> = {};
  if (!after) {
    return out;
  }
  for (const field of AUDITED) {
    const was = before ? (before[field] ?? null) : null;
    const now = after[field] ?? null;
    if (was !== now) {
      out[field] = { from: was, to: now };
    }
  }
  return out;
}
