import { NextRequest, NextResponse } from "next/server";
import { guardCdrRoute, queryFailed } from "@/lib/cdr-guard";
import { subAccounts } from "@/lib/units";

type Params = { params: Promise<{ id: string }> };

/**
 * GET /api/control/accounts/{id}/children — a reseller and the accounts beneath it, with units
 * accounts marked and their units per product (gateway 0.16.0), and why new units accounts cannot be
 * made now when the database can tell. Read-only, operator-only.
 */
export async function GET(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  const account = decodeURIComponent((await params).id).trim();
  if (!account) {
    return NextResponse.json({ error: "No account given." }, { status: 400 });
  }
  try {
    return NextResponse.json({ data: await subAccounts(account) });
  } catch (err) {
    return queryFailed("sub-accounts", err);
  }
}
