import { NextRequest, NextResponse } from "next/server";
import { guardCdrRoute, queryFailed } from "@/lib/cdr-guard";
import { unitLedgerPage } from "@/lib/units";

type Params = { params: Promise<{ id: string }> };

/**
 * GET /api/control/accounts/{id}/units/ledger?before=<cursor> — one page of a units account's unit
 * ledger (given, taken back, moved, corrected), newest first. `next` is the cursor for the page after.
 */
export async function GET(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  const account = decodeURIComponent((await params).id).trim();
  if (!account) {
    return NextResponse.json({ error: "No account given." }, { status: 400 });
  }
  try {
    return NextResponse.json({ data: await unitLedgerPage(account, req.nextUrl.searchParams.get("before")) });
  } catch (err) {
    return queryFailed("unit ledger", err);
  }
}
