import { NextRequest, NextResponse } from "next/server";
import { guardCdrRoute, queryFailed } from "@/lib/cdr-guard";
import { unitsAccountView } from "@/lib/units";

type Params = { params: Promise<{ id: string }> };

/**
 * GET /api/control/accounts/{id}/units — a units account (gateway 0.16.0): its allowances per
 * product, its usage, its logins, its own speed limits and the account that pays for it.
 *
 * <p>Read-only, operator-only (404 for anyone else, as every control read). `data` is null when the
 * account is not a units account. Units are given by the platform that manages the account, never
 * from the panel, so there is no sibling that writes.
 */
export async function GET(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  const account = decodeURIComponent((await params).id).trim();
  if (!account) {
    return NextResponse.json({ error: "No account given." }, { status: 400 });
  }
  try {
    return NextResponse.json({ data: await unitsAccountView(account) });
  } catch (err) {
    return queryFailed("units account", err);
  }
}
