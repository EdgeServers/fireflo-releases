import { NextRequest, NextResponse } from "next/server";
import { gql } from "@/lib/gateway-graphql";
import { CONFIG_FILE } from "@/lib/gateway-queries";
import { CONFIG_NAMES, isConfigName } from "@/lib/gateway-files-types";
import { NotOperatorError, requireAdmin } from "@/lib/require-operator";

type Params = { params: Promise<{ name: string }> };

/**
 * GET /api/control/gateway-config/[name]
 *
 * <p>One of the gateway's configuration files, as the gateway holds it, with every secret blanked
 * before it left that process.
 *
 * <p>This is the view that settles the question the rest of the panel can only half answer: in file
 * mode the panel writes to `app_*` tables the gateway is not reading, and until now it could say
 * *"nothing on this page is in use"* without being able to show what **is**.
 *
 * <p>Redaction happens on the gateway, not here. That is deliberate — the secret should never cross
 * the network, so there is no point in this process being the one to decide.
 */
export async function GET(_request: NextRequest, { params }: Params): Promise<NextResponse> {
  //admin only since 0.16.4 (audit F4): this hands out what the gateway admin token reads -- SMPP binds
  //carry passwords in clear, and config and log text describe every customer
  try {
    await requireAdmin();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const { name } = await params;
  if (!isConfigName(name)) {
    return NextResponse.json(
      { error: `No such configuration file. Readable files are: ${CONFIG_NAMES.join(", ")}` },
      { status: 404 }
    );
  }

  return gql({ query: CONFIG_FILE, variables: { name }, auth: "admin", timeoutMs: 10_000 });
}
