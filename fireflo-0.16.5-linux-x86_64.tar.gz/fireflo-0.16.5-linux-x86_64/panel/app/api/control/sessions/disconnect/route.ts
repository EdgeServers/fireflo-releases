import { NextRequest, NextResponse } from "next/server";
import { auditConfigChange } from "@/lib/config-audit";
import { gql } from "@/lib/gateway-graphql";
import { SESSIONS_DISCONNECT } from "@/lib/gateway-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

const KINDS = ["ip", "account", "system_id"];

/**
 * POST /api/control/sessions/disconnect  { kind, value, listener?, hold?, reason? }
 *
 * <p>Drops every session of an IP, an account or a login, on every listener or one, and with
 * `hold` (seconds, or "forever") refuses that client's binds for a while on every node. The admin
 * token: it ends connections customers are sending on. The operator's address goes along as who
 * made the hold.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  let operator;
  try {
    operator = await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) return NextResponse.json({ error: "Not found" }, { status: 404 });
    throw err;
  }
  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  const kind = typeof body?.kind === "string" ? body.kind : "";
  const value = typeof body?.value === "string" ? body.value.trim() : "";
  if (!KINDS.includes(kind) || !value) {
    return NextResponse.json({ error: "Name an ip, an account or a system_id." }, { status: 400 });
  }
  const listener = typeof body?.listener === "string" && body.listener ? body.listener : null;
  const hold = typeof body?.hold === "string" && /^(\d+|forever)$/.test(body.hold) ? body.hold : null;
  const reason = typeof body?.reason === "string" && body.reason.trim() ? body.reason.trim().slice(0, 300) : null;
  const res = await gql({
    query: SESSIONS_DISCONNECT,
    variables: {
      target: { [kind]: value },
      by: operator.name,
      listener: listener ?? undefined,
      hold: hold ?? undefined,
      reason: reason ?? undefined,
    },
    auth: "admin",
    //each session waits up to five seconds for the customer's unbind_resp
    timeoutMs: 30_000,
  });
  if (res.ok) {
    //a hold is a refusal of a customer's binds; who placed it, on whom and for how long is the
    //question asked when that customer calls. The gateway records `by` too; the two should agree
    const payload = (await res.clone().json().catch(() => null)) as { data?: { dropped?: unknown[] } } | null;
    await auditConfigChange({
      domain: "session",
      name: `${kind}=${value}`,
      action: "action:disconnect",
      account: kind === "account" ? value : null,
      after: {
        listener,
        hold,
        reason,
        dropped: payload?.data?.dropped?.length ?? null,
      },
    }, operator);
  }
  return res;
}
