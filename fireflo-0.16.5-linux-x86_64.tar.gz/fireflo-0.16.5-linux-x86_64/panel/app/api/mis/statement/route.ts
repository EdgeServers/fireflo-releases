import { NextRequest, NextResponse } from "next/server";
import { isConfigured } from "@/lib/metrics-db";
import {
  assertInScope,
  NotCustomerError,
  requireCustomer,
  scopeFor,
} from "@/lib/require-customer";
import { customPeriod, monthPeriod, periodTooLong, type BillingPeriod } from "@/lib/billing-period";
import { billingZone, platformCurrency } from "@/lib/platform-currency";
import { closedPeriods, LoginSplitUnavailable, statementSummary, type StatementSplit } from "@/lib/statement-queries";
import {
  STATEMENT_RETRY_AFTER_S,
  StillReadingError,
  cachedStatement,
  isStatementTimeout,
  statementFailure,
  statementKey,
} from "@/lib/statement-cache";
import { getBalance } from "@/lib/balance";

/**
 * The customer's own statement, for the period they picked.
 *
 * <h2>What a customer is never shown</h2>
 *
 * <p>`statementSummary` selects only sell-side figures — counts, outcomes and `price`. It has no
 * `cost`, no `margin` and no `vendor` column at all, which is why it can be shared with the
 * operator route rather than duplicated. The thing that must NOT be shared is the CSV: the
 * operator's `statement-export.ts` is a fixed header list and a job store on local disk, and the
 * customer download is a separate bounded stream for exactly the reason
 * `app/api/mis/messages/export` gives.
 *
 * <h2>The account comes from the session, or from a child it is proved to hold</h2>
 *
 * <p><strong>The default has no account parameter at all.</strong> A reseller's own statement is the
 * SUM over `scopeFor`, which is the figure it is invoiced for, and nothing in the request can widen
 * that set.
 *
 * <p>`?account=` narrows it to ONE of those accounts, for the per-child statement on
 * `/accounts/{id}/statement`. That was previously called out here as a different question that this
 * route deliberately did not answer — and it is a different question, which is why it is a separate
 * parameter with its own check rather than a filter folded into the total. The id goes through
 * `assertInScope` before it reaches a query, so it can only ever narrow, never widen: a stranger's
 * id answers the same 404 an unauthenticated call gets.
 *
 * <p>The distinction the old note was protecting still holds: the unparameterised total is labelled
 * as the reseller's own and is never silently one child's traffic.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  let session;
  try {
    session = await requireCustomer();
  } catch (err) {
    if (err instanceof NotCustomerError) {
      //404 rather than 401, matching every other portal route: an unauthenticated caller learns
      //nothing about which endpoints exist
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  if (!isConfigured()) {
    return NextResponse.json(
      { error: "Statements are not available on this deployment." },
      { status: 503 }
    );
  }

  const period = readPeriod(req.nextUrl.searchParams, await billingZone());
  if (typeof period === "string") {
    return NextResponse.json({ error: period }, { status: 400 });
  }

  //absent means the whole scope, which is every ordinary customer's request unchanged. A named
  //account narrows to one, and only after being proved to be this session's or one of its children
  const asked = req.nextUrl.searchParams.get("account");
  let scope: string[];
  try {
    if (asked) {
      await assertInScope(session, asked);
      scope = [asked];
    } else {
      scope = await scopeFor(session);
    }
  } catch (err) {
    if (err instanceof NotCustomerError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  //by product unless asked by login (0.15.1): the customer's own logins, sell-side figures only
  const split: StatementSplit = req.nextUrl.searchParams.get("split") === "login" ? "login" : "product";

  try {
    const [currency, zone] = await Promise.all([platformCurrency(), billingZone()]);

    //summed across the scope, one query per account. A reseller has a handful of children, not a
    //page of them -- the two-level constraint in V1.15.0 is what makes that safe to assume. Kept
    //and shared as the operator's statement is (statement-cache.ts), keyed by the whole scope, so
    //one customer's figures never answer another's request
    const answer = await cachedStatement(
      statementKey({ who: "customer", accounts: scope, label: period.label, since: period.since, until: period.until, split }),
      () => Promise.all(scope.map((id) => statementSummary(id, period, currency, zone, split)))
    );
    const parts = answer.value;

    //the same window the total covers, day by day, from the same rows as the lines -- each summary
    //carries its own. Sell-side only: a day carries counts and `price`, and has no cost, margin or
    //vendor column to leak. Summed over the scope for the same reason the lines are -- a reseller
    //is invoiced for the total, so the chart has to plot it
    const byDay = new Map<string, { day: string; submitted: number; delivered: number;
      failed: number; pending: number; price: number; byKey: Record<string, { submitted: number; amount: number }> }>();
    for (const row of parts.flatMap((p) => p.days)) {
      const at = byDay.get(row.day)
        ?? { day: row.day, submitted: 0, delivered: 0, failed: 0, pending: 0, price: 0, byKey: Object.create(null) };
      for (const [key, part] of Object.entries(row.byKey ?? {})) {
        const k = at.byKey[key] ?? { submitted: 0, amount: 0 };
        k.submitted += part.submitted;
        k.amount += part.amount;
        at.byKey[key] = k;
      }
      at.submitted += row.submitted;
      at.delivered += row.delivered;
      at.failed += row.failed;
      at.pending += row.pending;
      at.price += row.price;
      byDay.set(row.day, at);
    }
    //no account id on a day, on purpose. Within a reseller's own total it would be the one field
    //that splits the figure back into per-child traffic, which is the distinction this route's
    //header says the statement deliberately does not answer
    const days = [...byDay.values()].sort((a, b) => a.day.localeCompare(b.day));

    const lines = new Map<string, { product: string; submitted: number; delivered: number;
      failed: number; expired: number; pending: number; unrated: number; amount: number }>();
    for (const part of parts) {
      for (const line of part.lines) {
        const at = lines.get(line.product) ?? {
          product: line.product, submitted: 0, delivered: 0, failed: 0,
          expired: 0, pending: 0, unrated: 0, amount: 0,
        };
        at.submitted += line.submitted;
        at.delivered += line.delivered;
        at.failed += line.failed;
        at.expired += line.expired;
        at.pending += line.pending;
        at.unrated += line.unrated;
        at.amount += line.amount;
        lines.set(line.product, at);
      }
    }

    //the account the statement is ABOUT, which is the child when one was named. A reseller reading
    //a child's statement wants that child's balance and that child's closed periods beside it --
    //showing its own under a heading naming the child is the misreading this whole route guards
    const subject = asked || session.accountId;
    const [balance, closed] = await Promise.all([
      getBalance(subject).catch(() => null),
      closedPeriods(subject).catch(() => []),
    ]);

    return NextResponse.json({
      asOf: new Date(answer.at).toISOString(),
      //an older answer, because the latest read failed. The reason is a sentence of ours, never the
      //driver's message
      ...(answer.stale
        ? { stale: { at: new Date(answer.at).toISOString(), reason: "The latest read did not finish." } }
        : {}),
      data: {
        label: period.label,
        currency,
        split,
        loginSplit: parts[0]?.loginSplit ?? { available: true, reason: null },
        lines: [...lines.values()].sort((a, b) => b.amount - a.amount),
        days,
        totalSubmitted: parts.reduce((n, p) => n + p.totalSubmitted, 0),
        totalDelivered: parts.reduce((n, p) => n + p.totalDelivered, 0),
        totalUnrated: parts.reduce((n, p) => n + p.totalUnrated, 0),
        totalAmount: parts.reduce((n, p) => n + p.totalAmount, 0),
        //a postpaid customer sees what they may still run up; a prepaid one sees what is left.
        //Different questions, and showing the wrong one is how somebody plans against a number
        //that does not apply to them
        billingMode: balance?.billingMode ?? "PREPAID",
        balance: balance?.balance ?? null,
        creditLimit: balance?.billingMode === "POSTPAID" ? balance.creditLimit : null,
        closed,
      },
    });
  } catch (err) {
    if (err instanceof LoginSplitUnavailable) {
      return NextResponse.json({ error: err.message }, { status: 409 });
    }
    if (err instanceof StillReadingError) {
      //still reading in the background: the page shows its breathing card and asks again
      return NextResponse.json(
        { busy: true, retryAfter: STATEMENT_RETRY_AFTER_S },
        { status: 202, headers: { "Cache-Control": "private, no-store", "Retry-After": String(STATEMENT_RETRY_AFTER_S) } }
      );
    }
    //deliberately not echoing the error: a customer-facing route must not leak a driver message.
    //The sentence says only whether it was the database's time; the log has the rest
    console.error(`portal statement ${period.label} failed`, err);
    return NextResponse.json(
      { error: isStatementTimeout(err) ? statementFailure(err) : "Could not prepare the statement." },
      { status: 500 }
    );
  }
}

/** `?month=YYYY-MM`, or `?from=&to=`. Both bounded by the same 92-day ceiling everything else has. */
/** @param zone the billing zone: a month and a day start at its midnight, never the host's. */
function readPeriod(params: URLSearchParams, zone: string): BillingPeriod | string {
  const month = params.get("month");
  if (month) {
    const period = monthPeriod(month, zone);
    if (!period) {
      return `'${month}' is not a month. Use YYYY-MM.`;
    }
    return periodTooLong(period) ?? period;
  }
  const period = customPeriod(params.get("from") ?? "", params.get("to") ?? "", zone);
  if (typeof period === "string") {
    return period;
  }
  return periodTooLong(period) ?? period;
}
