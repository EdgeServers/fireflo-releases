"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { UnitsAvailabilityStrip } from "./UnitsAccountParts";
import { count } from "@/lib/format";
import { accountHref } from "@/lib/panel-surface";
import { productsWithoutUnits, type SubAccountRow, type SubAccountsView } from "@/lib/units-types";

/**
 * Account › Billing on a reseller: the accounts beneath it, units accounts marked with their units
 * per product (gateway 0.16.0). Operator only (the route is under `/api/control`); shown only when
 * the account has children.
 *
 * <p>A units account holds no money: each message takes a unit of its product there and its price
 * from this account's balance, which is why the two sit together on this tab.
 */
export function SubAccountsCard({ id }: { id: string }) {
  const [state, setState] = useState<{ id: string; view: SubAccountsView | null; error: string }>({ id, view: null, error: "" });

  useEffect(() => {
    const controller = new AbortController();
    void (async () => {
      try {
        const res = await fetch(`/api/control/accounts/${encodeURIComponent(id)}/children`,
          { cache: "no-store", signal: controller.signal });
        const json = await res.json().catch(() => null);
        setState(res.ok
          ? { id, view: json?.data ?? null, error: "" }
          : { id, view: null, error: json?.error ?? `The accounts beneath could not be read (${res.status}).` });
      } catch (err) {
        if (!controller.signal.aborted) {
          setState({ id, view: null, error: err instanceof Error ? err.message : "The accounts beneath could not be read." });
        }
      }
    })();
    return () => controller.abort();
  }, [id]);

  const view = state.id === id ? state.view : null;
  const error = state.id === id ? state.error : "";
  if (error) {
    return <p className="text-sm text-muted-foreground">{error}</p>;
  }
  //nothing beneath it: nothing to show, and a money account's tab stays as it was
  if (!view || !view.children.length) {
    return null;
  }
  const anyUnits = view.children.some((c) => c.units);

  return (
    <Card>
      <CardHeader bar>
        <CardTitle>Sub-accounts</CardTitle>
        <CardDescription>
          The accounts beneath this one{anyUnits ? ", with units accounts' units left per product" : ""}. Messages this
          month are in the billing time zone.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <UnitsAvailabilityStrip availability={view.availability} existing={false} />
        <TableInCard>
          <THead>
            <TR>
              <TH>Sub-account</TH>
              <TH>Logins</TH>
              <TH>Units left</TH>
              <TH align="right">Messages this month</TH>
              <TH>State</TH>
            </TR>
          </THead>
          <TBody>
            <Row row={view.self} self />
            {view.children.map((c) => <Row key={c.id} row={c} />)}
          </TBody>
        </TableInCard>
        <p className="text-xs text-muted-foreground">
          {anyUnits
            ? "A message from a units account needs a unit of its product there AND money in this account's balance: the unit comes off the units account, the price off this balance. This account's own count includes its units accounts' messages, which it pays for. Units are given by the platform that manages them."
            : "This account's own count is the messages it paid for."}
        </p>
      </CardContent>
    </Card>
  );
}

function Row({ row, self = false }: { row: SubAccountRow; self?: boolean }) {
  const out = productsWithoutUnits(row.allowances);
  return (
    <TR>
      <TD>
        {self ? (
          <span className="font-semibold">{row.id}</span>
        ) : (
          <Link href={accountHref(row.id, "billing")} className="font-semibold hover:underline">{row.id}</Link>
        )}
        <span className="block text-xs text-muted-foreground">
          {self ? "this account" : [row.label, row.units ? "units only" : null].filter(Boolean).join(" · ") || "money"}
        </span>
      </TD>
      <TD muted className="font-mono text-xs">{row.logins.length ? row.logins.join(" · ") : "—"}</TD>
      <TD>
        {row.units ? (
          row.allowances.length ? (
            <span className="tabular-nums">{row.allowances.map((a) => `${a.product} ${count(a.left)}`).join(" · ")}</span>
          ) : (
            <span className="text-muted-foreground">none given</span>
          )
        ) : (
          <span className="text-muted-foreground">{self ? "Not limited · uses the balance" : "Not limited · own balance"}</span>
        )}
      </TD>
      <TD num>{row.messagesMonth == null ? "—" : count(row.messagesMonth)}</TD>
      <TD>
        <span className="flex flex-wrap gap-1">
          {row.archived ? (
            <Badge variant="destructive">archived</Badge>
          ) : !row.enabled ? (
            <Badge variant="outline">disabled</Badge>
          ) : row.units && (out.length || !row.allowances.length) ? (
            (out.length ? out : ["all"]).map((p) => <Badge key={p} variant="warning">{p}: no units</Badge>)
          ) : (
            <Badge variant="success">On</Badge>
          )}
        </span>
      </TD>
    </TR>
  );
}
