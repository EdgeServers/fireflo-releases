"use client";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useUnitsAccount } from "./useUnitsAccount";
import {
  LEFT_HINT,
  UnitAllowanceTable,
  UnitLedgerCard,
  UnitsAvailabilityStrip,
  UnitSpeedLimitCard,
  UnitUsageCard,
} from "./UnitsAccountParts";
import { accountHref } from "@/lib/panel-surface";
import { productsWithoutUnits } from "@/lib/units-types";

/**
 * Account › Billing for a units account (gateway 0.16.0): what it may still send per product, who
 * pays for it, what it used, its unit ledger and its own speed limits.
 *
 * <p>Where a money account's Billing tab has a balance and the actions that change it, this has
 * units and none: a units account holds no money (its messages are charged to its parent, which is
 * named wherever a balance would be), and units are given by the platform that manages it.
 */
export function UnitsBillingClient({ id }: { id: string }) {
  const { view, error, loading } = useUnitsAccount(id);

  if (loading && !view) {
    return <p className="text-sm text-muted-foreground">Loading…</p>;
  }
  if (error || !view) {
    return <p className="text-sm text-muted-foreground">{error || "This is not a units account."}</p>;
  }

  const out = productsWithoutUnits(view.allowances);
  const parent = view.parent?.id ?? null;

  return (
    <div className="space-y-4">
      <UnitsAvailabilityStrip availability={view.availability} existing />

      <Card className="grid overflow-hidden md:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
        <section className="min-w-0 p-5 max-sm:p-4">
          <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-muted-foreground">
            Units left
            <Badge variant="info">Units</Badge>
            {out.length > 0 && <Badge variant="destructive">{out.join(", ")}: no units</Badge>}
          </div>
          <div className="mt-3">
            <UnitAllowanceTable allowances={view.allowances} />
          </div>
          <p className="mt-3 text-xs text-muted-foreground">{LEFT_HINT}</p>
        </section>
        <section className="min-w-0 space-y-3 border-t border-border p-5 text-sm max-sm:p-4 md:border-l md:border-t-0">
          <div>
            <p className="text-xs font-medium text-muted-foreground">Charged to</p>
            <p className="mt-1.5 text-title">
              {parent ? (
                <Link href={accountHref(parent, "billing")} className="hover:underline">
                  {view.parent?.label || parent}
                </Link>
              ) : (
                <span className="text-warning">No parent account</span>
              )}
            </p>
          </div>
          <p className="text-xs text-muted-foreground">
            This account holds units, not money. Each message part takes one unit of its login&apos;s product here, and its
            price comes off {parent ?? "the parent"}&apos;s balance; a message needs both. Units are given and taken back by
            the platform that manages the account, not from this panel.
          </p>
          <div>
            <p className="text-xs font-medium text-muted-foreground">Logins</p>
            {view.logins.length ? (
              <ul className="mt-1 space-y-0.5">
                {view.logins.map((l) => (
                  <li key={l.systemId} className="flex flex-wrap items-center gap-2">
                    <span className="font-mono">{l.systemId}</span>
                    {l.product && <span className="text-xs text-muted-foreground">{l.product}</span>}
                    {!l.enabled && <Badge variant="outline">disabled</Badge>}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="mt-1 text-muted-foreground">None yet.</p>
            )}
            <Link href={accountHref(id, "logins")} className="mt-1 inline-block text-xs text-primary hover:underline">
              Open logins →
            </Link>
          </div>
        </section>
      </Card>

      <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
        <UnitUsageCard usage={view.usage} parent={parent} logins={view.logins} />
        <UnitSpeedLimitCard id={id} parent={parent} rate={view.rate} />
      </div>

      <UnitLedgerCard id={id} />
    </div>
  );
}

/**
 * What a surface without the units routes (the customer portal) shows on a units account's Billing
 * tab: what it is, who pays, and no money actions.
 */
export function UnitsAccountNote({ parent }: { parent: string | null }) {
  return (
    <Card>
      <CardHeader bar>
        <CardTitle>Units account</CardTitle>
        <CardDescription>Holds units, not money.</CardDescription>
      </CardHeader>
      <CardContent className="text-sm text-muted-foreground">
        Its messages are charged to {parent ?? "the account above it"}. Units are given by the platform that manages it, so
        there is no balance to move to or from it here.
      </CardContent>
    </Card>
  );
}
