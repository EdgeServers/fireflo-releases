"use client";
import { useState } from "react";
import { usePeriod } from "@/components/usePeriod";
import Link from "next/link";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AccountCeilingCard } from "./AccountCeilingCard";
import { AccountsClient } from "./AccountsClient";
import { DeliveryCheck } from "./DeliveryCheck";
import { RangePicker } from "./RangePicker";
import { RANGE_VALUES, type Range } from "./useControlData";
import { useAccountContext } from "./useAccountContext";
import { useRates } from "./useRates";
import { useUnitsAccount } from "./useUnitsAccount";
import { LEFT_HINT, UnitAllowanceTable, UnitsAvailabilityStrip, UnitUsageCard } from "./UnitsAccountParts";
import { scopeKind } from "@/lib/rate-types";
import { surface } from "@/lib/panel-surface";

/**
 * What this account has been doing, and whether anything is wrong with it.
 *
 * <p>The landing tab, so it answers the question somebody arriving actually has — "they say their
 * messages are failing" — before any of the configuration tabs they would otherwise open one by one
 * looking for the cause.
 */
export function AccountOverviewClient({ id }: { id: string }) {
  const { context } = useAccountContext(id);
  const { known } = useRates();
  const [range, setRange] = usePeriod<Range>("account", RANGE_VALUES, "1h");
  const [switching, setSwitching] = useState(false);
  const kind = scopeKind(id, known);
  //what this surface may show about what an account is charged, and who carries it -- see
  //lib/panel-surface.ts
  const { pricing } = surface();
  //gateway 0.16.0: a units account's messages are recorded under its parent, so the traffic table
  //(which reads by the account the message is billed to) would show nothing here. Its units and
  //what it used stand in for it on the operator's panel
  const units = pricing && context?.balance?.billingMode === "UNITS";
  const unitsView = useUnitsAccount(id, units);

  if (units) {
    const view = unitsView.view;
    return (
      <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_20rem]">
        <div className="min-w-0 space-y-4">
          <UnitsAvailabilityStrip availability={view?.availability ?? null} existing />
          {unitsView.error ? (
            <p className="text-sm text-muted-foreground">{unitsView.error}</p>
          ) : !view ? (
            <p className="text-sm text-muted-foreground">Loading…</p>
          ) : (
            <UnitUsageCard usage={view.usage} parent={view.parent?.id ?? null} logins={view.logins} />
          )}
        </div>
        <div className="min-w-0 space-y-4">
          <Card>
            <CardHeader bar>
              <CardTitle>Units left</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {view ? <UnitAllowanceTable allowances={view.allowances} /> : <p className="text-xs text-muted-foreground">Loading…</p>}
              <p className="text-xs text-muted-foreground">{LEFT_HINT}</p>
            </CardContent>
          </Card>
          <AccountCeilingCard id={id} />
        </div>
      </div>
    );
  }

  return (
    //traffic left, the two things you check about it right. The vendor list and the delivery check
    //were both stacked above a table that is the reason anyone opens this tab, so they pushed it
    //down without being read; beside it they are glanceable and the table keeps the width
    <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_20rem]">
      <Card className="min-w-0">
        <CardHeader bar className="flex flex-row flex-wrap items-center gap-2 space-y-0">
          <div className="min-w-0 space-y-1.5">
            <CardTitle>Traffic</CardTitle>
            <CardDescription>
              Derived from the messages that actually arrived, split by login and product.
            </CardDescription>
          </div>
          <div className="ml-auto">
            <RangePicker value={range} onChange={setRange} busy={switching} />
          </div>
        </CardHeader>
        <CardContent>
          <AccountsClient account={id} chrome={false} range={range} onRangeChange={setRange} onSwitchingChange={setSwitching} />
        </CardContent>
      </Card>

      <div className="min-w-0 space-y-4">
        {/* the Limits page's answer at a glance: what this account may send on each listener and
            why. Operator-only, like the throughput route behind it (it 404s for anyone else) */}
        {pricing && <AccountCeilingCard id={id} />}

        {/* the customer-shaped question -- "they say their messages are failing" -- answered
            beside the traffic rather than above it.

            Operator-only: it diagnoses the ROUTING TABLE and offers to write a fix to it, which is
            the operator's configuration and not a fact about this account at all */}
        {pricing && <DeliveryCheck accountId={id} />}

        {pricing && kind === "cost" && (
          <Card className="border-destructive">
            <CardContent className="py-3 text-sm text-destructive">
              A vendor is also called <code>{id}</code>. Rating matches a rate scope by name alone,
              so this account&apos;s rules are read as <strong>our cost for that vendor</strong> as
              well as its price. Rename one before pricing either.
            </CardContent>
          </Card>
        )}

        {/* which carriers this account's traffic actually went out over. A reseller's customer
            being told which carrier its operator buys from is a commercial disclosure, so the
            portal's context route does not send this either -- the gate here is the second lock */}
        {pricing && context?.vendors?.length ? (
          <Card>
            <CardHeader bar>
              <CardTitle>Where it went</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <ul className="space-y-1">
                {context.vendors.map((v) => (
                  <li key={v.vendor} className="font-mono">{v.vendor}</li>
                ))}
              </ul>
              {context.vendorsWindow && (
                <p className="text-xs text-muted-foreground">
                  {context.vendorsWindow.source === "summary"
                    ? `Last ${context.vendorsWindow.days} days, from the hourly summary: a few minutes behind live traffic.`
                    : `Last ${context.vendorsWindow.days} days.`}
                </p>
              )}
              <Link href={`/cp/cdrs?account=${encodeURIComponent(id)}`}
                className="inline-block text-primary hover:underline">
                See the messages
              </Link>
            </CardContent>
          </Card>
        ) : null}
      </div>
    </div>
  );
}
