"use client";
import { useEffect, useState } from "react";
import { Mail, MailCheck, Plus, Unplug } from "lucide-react";
import { useSession } from "next-auth/react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { CardActions, FactGrid, Figures, HealthStrip, type Fact } from "./CardBits";
import { OPERATOR_SURFACE, surface } from "@/lib/panel-surface";
import { ConnectionInstructionsDialog } from "./ConnectionInstructionsDialog";
import { ReceiptRepushDialog } from "./ReceiptRepushDialog";
import { isAdminSession } from "@/lib/roles";
import { useConfirmChange, useConfirmDelete } from "./ConfirmProvider";
import { MoveToAccountDialog } from "./MoveToAccountDialog";
import { ForceDisconnectDialog } from "./ForceDisconnectDialog";
import { CredentialForm } from "./CredentialForm";
import { Dialog } from "@/components/ui/dialog";
import { useCredentials } from "./useCredentials";
import { useHealth } from "./useHealth";
import { useProductReadiness } from "./ProductReadiness";
import { productGapSentence } from "@/lib/product-readiness";
import { readsCredentialsFromDatabase } from "@/lib/health-types";
import { type Credential, hasLimits, limitsSummary } from "@/lib/credential-types";
import { formatClockTime, formatTimestamp } from "@/lib/datetime";
import { bindLabel, boundFor, connectionView, type SessionSummary } from "@/lib/login-sessions";
import { EmptyState } from "@/components/ui/empty-state";
import { cn } from "@/lib/utils";
import { noteSource } from "@/lib/page-sources";
import { useDisplayZone } from "@/components/DisplayZoneProvider";
import { localeNumber } from "@/lib/format";

/**
 * Who can connect — the SMPP and HTTP logins.
 *
 * <p>Sits above the traffic table on the Accounts page rather than replacing it. The two are keyed
 * differently and both keys are right: traffic groups by account, system id and product because that
 * is how the money splits, while a login is one row. And the traffic view has to keep working with no
 * configuration database at all, which is the ordinary case.
 */
export function CredentialsClient({
  account,
  chrome = true,
  advanced = false,
  addOpen = false,
  onAddHandled,
  editLogin = "",
  onEditHandled,
}: {
  account?: string;
  /** Show the rarely-touched facts on each card and the matching sections in the editor. */
  advanced?: boolean;
  /**
   * Opens the new-login form from outside.
   *
   * <p>With `chrome` off the card around this owns the "Add login" button -- it lives in the card's
   * footer, beside nothing else, where an action on the whole list belongs. That button has to be
   * able to reach this component's editing state, and this is the smallest way to let it: one
   * boolean in, one callback back when the form has taken it.
   */
  addOpen?: boolean;
  onAddHandled?: () => void;
  /**
   * Opens one login's form from outside, by system id, scrolled to its Session and TPS limits --
   * the Limits tab's link to a login's own TPS. Handled once the login is in the list.
   */
  editLogin?: string;
  onEditHandled?: () => void;
  /**
   * Whether to render this component's own description, "Add login" button and empty-state box.
   *
   * <p>False when a card around it already supplies them -- otherwise the parent's heading and this
   * component's paragraph say the same thing twice, one under the other.
   */
  chrome?: boolean;
} = {}) {
  const { credentials: all, context, error, loading, busy, disabled, load, save, setEnabled, remove } =
    useCredentials();
  const { health } = useHealth();
  const [editing, setEditing] = useState<Credential | "new" | null>(null);
  const [figures, setFigures] = useState<Record<string, LoginFigures>>({});
  //who is bound right now, per SMPP login. null until the gateway has answered, and again when it
  //cannot be reached: then a card says nothing rather than "Not connected"
  const [live, setLive] = useState<{ at: number; data: Record<string, SessionSummary> } | null>(null);
  //the login whose connection details are being mailed. Operator only: the route reads the
  //password, and the portal has no business composing a mail that carries one
  const [instructing, setInstructing] = useState<Credential | null>(null);
  //operator-only: the report is about the tariff, and a reseller-created login carries no product
  const readiness = useProductReadiness(surface().pricing ? account : undefined);
  //the login whose receipts are being re-sent. Admin and operator panel only: it re-sends real
  //receipts to a customer's system, and the portal renders this component too
  const [repushing, setRepushing] = useState<Credential | null>(null);
  //the login being moved to another account (operator only), and what the last move reported
  const [moving, setMoving] = useState<Credential | null>(null);
  const [moved, setMoved] = useState("");
  const { data: session } = useSession();

  //adopt the parent's request to open the form, then tell it so it can reset its own flag
  useEffect(() => {
    if (addOpen) {
      setEditing("new");
      onAddHandled?.();
    }
  }, [addOpen, onAddHandled]);

  //adopt a request to edit one login once the list holds it, and bring its limits into view
  useEffect(() => {
    if (!editLogin) {
      return;
    }
    const found = all.find((c) => c.systemId === editLogin);
    if (!found) {
      return;
    }
    //eslint-disable-next-line react-hooks/set-state-in-effect -- adopting a request made from outside
    setEditing(found);
    onEditHandled?.();
    //not cleared on re-run: handling the request clears editLogin, which re-runs this at once.
    //SettingsSection anchors its id as gw-<id>
    setTimeout(() => document.getElementById("gw-cred-limits")?.scrollIntoView({ block: "start" }), 150);
  }, [editLogin, all, onEditHandled]);

  //scoped to one account when this is mounted on that account's page. `billingAccount` is resolved
  //server-side through billingOf, so this catches the logins that reach the account by the
  //system-id fallback as well -- and those are the ones worth showing, because they mention it
  //nowhere a search would find
  const credentials = account ? all.filter((c) => c.billingAccount === account) : all;

  //today's traffic per login, one request for the page. Operator surface only: the portal has no
  //metrics route, and its cards simply show no figures
  const ids = credentials.map((c) => c.systemId).filter((v): v is string => !!v).join(",");
  useEffect(() => {
    if (!ids || !surface().pricing) {
      return;
    }
    let live = true;
    fetch(`/api/control/credentials/figures?ids=${encodeURIComponent(ids)}`, { cache: "no-store" })
      .then((res) => res.json())
      .then((json) => {
        if (live && json?.data) {
          setFigures(json.data as Record<string, LoginFigures>);
        }
      })
      .catch(() => undefined);
    return () => {
      live = false;
    };
  }, [ids]);

  //SMPP logins only: an HTTP login holds no session. Refreshed every 10 s while the tab is visible
  const smppIds = credentials.filter((c) => c.type === "SMPP" && c.systemId).map((c) => c.systemId!).join(",");
  useEffect(() => {
    if (!smppIds || !surface().pricing) {
      return;
    }
    let alive = true;
    const load = () => {
      if (document.visibilityState !== "visible") return;
      fetch(`/api/control/credentials/sessions?ids=${encodeURIComponent(smppIds)}`, { cache: "no-store" })
        .then((res) => {
          if (alive) noteSource("sessions", res);
          return res.ok ? res.json() : null;
        })
        .then((json) => {
          if (alive) setLive(json?.data ? { at: Date.now(), data: json.data as Record<string, SessionSummary> } : null);
        })
        .catch(() => {
          if (alive) setLive(null);
        });
    };
    load();
    const timer = window.setInterval(load, 10_000);
    document.addEventListener("visibilitychange", load);
    return () => {
      alive = false;
      window.clearInterval(timer);
      document.removeEventListener("visibilitychange", load);
    };
  }, [smppIds]);

  if (disabled) {
    return (
      <p className="text-sm text-muted-foreground">
        Editing logins is switched off — <code>CONFIG_DATABASE_URL</code> is not set.
      </p>
    );
  }


  const fromDatabase = readsCredentialsFromDatabase(health);
  //what this surface may show about what a login is charged -- see lib/panel-surface.ts
  const { pricing, apiBase } = surface();
  const canInstruct = apiBase === OPERATOR_SURFACE.apiBase;
  const gapsByLogin = new Map(
    (readiness?.gaps ?? []).map((g) => [g.systemId ?? "", productGapSentence(g)])
  );

  const form = (
    <CredentialForm
      initial={editing === "new" || editing === null ? null : editing}
      context={context}
      defaultAccountId={account}
      //product and allowed products are the price -- see CredentialForm
      allowPricing={pricing}
      advanced={advanced}
      onSave={async (input) => {
        const failure = await save(input);
        if (!failure) {
          setEditing(null);
        }
        return failure;
      }}
      onCancel={() => setEditing(null)}
    />
  );

  const list = (
    <div className="space-y-3">
      {chrome && (
        <div className="flex flex-wrap items-center gap-2">
          <p className="min-w-0 flex-1 text-sm text-muted-foreground">
            Who may connect, and which account their traffic bills to.
          </p>
          <Button onClick={() => setEditing("new")} size="sm" className="ml-auto gap-2">
            <Plus className="h-4 w-4" />
            Add login
          </Button>
        </div>
      )}

      {/* the single most destructive switch in the panel: with this table empty and the source
          flipped, no customer can connect at all, and nothing in the logs names the cause */}
      {fromDatabase === false && (
        <Card className="border-destructive">
          <CardContent className="py-4 text-sm">
            <strong>These logins are not in use.</strong> The gateway is authenticating from{" "}
            <code className="text-sm">conf/credentials.yml</code>, not the database — anything here is
            stored, valid, and ignored. Before switching it with{" "}
            <code className="text-sm">FIREFLO_CONFIG_SOURCE=db</code>, make sure this list is
            complete: an empty table refuses <em>every</em> bind and <em>every</em> REST call at once,
            with no fallback to the file. <code className="text-sm">scripts/fireflo import credentials</code>{" "}
            fills it from the file.
          </CardContent>
        </Card>
      )}

      {fromDatabase === true && !all.length && !loading && (
        <HealthStrip tone="destructive">
          <strong>The gateway is authenticating from this database, and it is empty.</strong> No
          customer can connect. Import from the file or add a login now.
        </HealthStrip>
      )}

      {error && (
        <HealthStrip tone="destructive">{error}</HealthStrip>
      )}

      {!credentials.length && !error && (
        chrome ? (
          <EmptyState>
            {loading ? "Loading…" : "No logins stored"}
          </EmptyState>
        ) : (
          <p className="py-4 text-sm text-muted-foreground">
            {loading ? "Loading…" : "No login bills to this account yet."}
          </p>
        )
      )}

      {/* one card per login. A card answers "is this login right, and is it alive" in three facts
          and three figures; the eight-column table it replaced answered it across a row too wide to
          read, and hid the facts that mattered behind a column chooser */}
      {!!credentials.length && (
        <div className="grid gap-4 xl:grid-cols-2">
          {credentials.map((c) => (
            <LoginCard
              key={c.id}
              credential={c}
              advanced={advanced}
              pricing={pricing}
              figures={c.systemId ? figures[c.systemId] : undefined}
              live={c.type === "SMPP" && c.systemId && live ? { at: live.at, summary: live.data[c.systemId] } : undefined}
              gap={c.systemId ? gapsByLogin.get(c.systemId) : undefined}
              busy={busy === c.id}
              onEdit={() => setEditing(c)}
              onToggle={() => setEnabled(c.id, !c.enabled)}
              onRemove={() => remove(c.id)}
              onMove={pricing ? () => setMoving(c) : undefined}
              onInstruct={canInstruct && (c.type === "SMPP" || c.type === "HTTP") ? () => setInstructing(c) : undefined}
              onRepush={canInstruct && isAdminSession(session) && c.type === "SMPP" && c.systemId ? () => setRepushing(c) : undefined}
            />
          ))}
        </div>
      )}

      {moved && <HealthStrip tone="info">{moved}</HealthStrip>}

      {moving && (
        <MoveToAccountDialog
          what="login"
          name={moving.systemId ?? `#${moving.id}`}
          from={moving.billingAccount}
          note={moving.type === "SMPP"
            ? "Any session it holds now is dropped, so it re-binds billing the new account. Sender IDs or templates scoped to it must be cleared first."
            : "Sender IDs or templates scoped to it must be cleared first."}
          endpoint={`/api/control/credentials/${moving.id}/move`}
          onClose={() => setMoving(null)}
          onMoved={(r) => {
            setMoved(`${moving.systemId ?? `#${moving.id}`} moved to ${r.to}`
              + (r.dropped ? `; ${r.dropped} bind${r.dropped === 1 ? "" : "s"} dropped.` : ".")
              + (r.problem ? ` The live sessions could not be reached (${r.problem}); they move when they reconnect.` : ""));
            setMoving(null);
            void load();
          }}
        />
      )}

      {repushing?.systemId && (
        <ReceiptRepushDialog
          systemId={repushing.systemId}
          account={repushing.billingAccount}
          onClose={() => setRepushing(null)}
        />
      )}

      {instructing && (
        <ConnectionInstructionsDialog
          credential={instructing}
          apiBase={apiBase}
          onClose={() => setInstructing(null)}
        />
      )}
    </div>
  );

  /*
    Embedded, the form opens in a dialog rather than replacing the section. Swapping it out worked
    when this component owned the whole page; inside somebody else's card it would put a four-part
    form in the card's body and take the card's title away while you edited, which is the one moment
    you most want to know which account you are editing a login for.
  */
  if (editing && !chrome) {
    return (
      <>
        {list}
        <Dialog
          open
          onClose={() => setEditing(null)}
          title={editing === "new" ? "New login" : `Editing ${editing.systemId ?? `#${editing.id}`}`}
          description={account ? `Billing to ${account}.` : undefined}
          className="max-w-3xl"
        >
          {form}
        </Dialog>
      </>
    );
  }
  if (editing) {
    return form;
  }


  return list;
}

interface LoginFigures {
  sent: number;
  refused: number;
  lastSeen: string | null;
}

function LoginCard({
  credential: c,
  advanced,
  pricing,
  figures,
  live,
  gap,
  busy,
  onEdit,
  onToggle,
  onRemove,
  onMove,
  onInstruct,
  onRepush,
}: {
  credential: Credential;
  advanced: boolean;
  pricing: boolean;
  figures: LoginFigures | undefined;
  /**
   * The gateway's live sessions for an SMPP login: `summary` absent means nothing is bound. Undefined
   * altogether when there is no answer to show -- an HTTP login, the portal, or a gateway that did
   * not reply.
   */
  live?: { at: number; summary: SessionSummary | undefined };
  /** The product-readiness sentence about this login, when there is one. */
  gap: string | undefined;
  busy: boolean;
  onEdit: () => void;
  onToggle: () => void;
  onRemove: () => void;
  /** Opens Move to account… Operator panel only. */
  onMove?: () => void;
  /** Opens the connection-instructions mail. Absent where the card may not offer it. */
  onInstruct?: () => void;
  /** Opens Re-send receipts… for an SMPP login. Admins on the operator panel only. */
  onRepush?: () => void;
}) {
  const { zone } = useDisplayZone();
  const [forcing, setForcing] = useState(false);
  const confirm = useConfirmChange();
  const confirmDelete = useConfirmDelete();
  const name = c.systemId ?? `#${c.id}`;
  const auth = [
    c.password === "stored" ? "password" : null,
    c.apiKey === "stored" ? "API key" : null,
  ].filter(Boolean).join(" · ") || "none set";

  const facts: Fact[] = [
    { label: "Auth", value: auth, muted: auth === "none set" },
    ...(pricing
      ? [{ label: "Product", value: c.product ?? "— none", muted: !c.product, mono: !!c.product }]
      : []),
    {
      label: "Allowed from",
      value: c.allowedIps.length ? c.allowedIps.join(", ") : "any address",
      muted: !c.allowedIps.length,
      mono: c.allowedIps.length > 0,
    },
    //only when set: a login without limits of its own is the ordinary case and says nothing new
    ...(c.type === "SMPP" && hasLimits(c.limits)
      ? [{ label: "Limits", value: limitsSummary(c.limits) }]
      : []),
  ];
  const more: Fact[] = [
    ...(pricing && c.type !== "SMPP"
      ? [{
        label: "Allowed products",
        value: c.allowedProducts.length ? c.allowedProducts.join(", ") : "— none (field refused)",
        muted: !c.allowedProducts.length,
      }]
      : []),
    {
      label: "Default TLVs",
      value: c.defaultTlvs.length ? c.defaultTlvs.map((t) => `${t.key} = ${t.value}`).join(", ") : "—",
      muted: !c.defaultTlvs.length,
      mono: c.defaultTlvs.length > 0,
    },
    {
      label: "Bills to",
      value: `${c.billingAccount ?? "—"}${c.billingAccountFallback !== "none" ? ` · via ${c.billingAccountFallback === "apiKey" ? "API key" : "system id"}` : ""}`,
      mono: true,
    },
  ];

  return (
    <Card data-login={c.systemId ?? c.id} className={cn("min-w-0", !c.enabled && "opacity-70")}>
      <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
        {/* the system id opens the editor, the same way it does on the index */}
        <button type="button" onClick={onEdit} className="font-mono text-sm font-medium hover:underline">
          {c.systemId ?? `#${c.id}`}
        </button>
        <Badge variant="outline">{c.type}</Badge>
        <Badge variant={c.enabled ? "success" : "destructive"}>{c.enabled ? "Enabled" : "Disabled"}</Badge>
        {live && (live.summary
          ? <Badge variant="success" className="gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-success" aria-hidden />Connected</Badge>
          : <Badge variant="outline">Not connected</Badge>)}
        <CardActions>
          <Button variant="outline" size="sm" onClick={onEdit}>Edit</Button>
          {onMove && (
            <Button variant="ghost" size="sm" disabled={busy} onClick={onMove}
              title="Give this login to another account">
              Move…
            </Button>
          )}
          <Button variant="ghost" size="sm" disabled={busy}
            //disabling drops whatever this login is holding as well as refusing the next bind.
            //Stored `enabled` alone governs only future binds, so without that a login went grey
            //here while the customer carried on sending
            title={c.enabled
              ? "Refuse new binds, and drop any this login is holding now"
              : "Allow this login to bind again"}
            onClick={async () => {
              if (!(await confirm({
                title: c.enabled ? `Disable ${name}?` : `Enable ${name}?`,
                consequence: c.enabled
                  ? `${name} is refused new binds, and any session it holds now is dropped.`
                  : `${name} may bind again from the gateway's next configuration poll.`,
                confirmLabel: c.enabled ? "Disable" : "Enable",
                tone: "caution",
              }))) {
                return;
              }
              onToggle();
            }}>
            {c.enabled ? "Disable" : "Enable"}
          </Button>
          <Button variant="ghost" size="sm" disabled={busy}
            className="text-destructive hover:text-destructive"
            onClick={async () => {
              if (!(await confirmDelete({
                title: `Delete ${name}?`,
                consequence: `'${name}' stops being able to connect at the gateway's next poll. Past call ` +
                  "records survive, but nothing else records who this system ID belonged to.",
                confirmLabel: "Delete this login",
              }))) {
                return;
              }
              onRemove();
            }}>
            Delete
          </Button>
        </CardActions>
      </CardHeader>
      <CardContent className="space-y-3 pt-3">
        {gap && (
          <HealthStrip action={<Button variant="outline" size="sm" className="h-7" onClick={onEdit}>Set a product</Button>}>
            {gap}
          </HealthStrip>
        )}
        <FactGrid facts={facts} />
        {live && (
          <LiveSessions live={live} limits={c.limits} advanced={advanced}
            onDisconnect={live.summary && c.systemId ? () => setForcing(true) : undefined} />
        )}
        {forcing && c.systemId && (
          <ForceDisconnectDialog initialKind="system_id" initialValue={c.systemId}
            initialValues={c.billingAccount ? { account: c.billingAccount } : {}}
            kinds={c.billingAccount ? ["system_id", "account"] : ["system_id"]}
            onClose={() => setForcing(false)} />
        )}
        {pricing && (
          <Figures
            figures={[
              { value: figures ? localeNumber(figures.sent) : "—", label: "sent today" },
              { value: figures ? localeNumber(figures.refused) : "—", label: "refused", tone: figures?.refused ? "destructive" : "default" },
              { value: figures?.lastSeen ? formatTimestamp(figures.lastSeen, zone) : "—", label: "last seen" },
            ]}
          />
        )}
        {advanced && (
          <div className="border-t border-border pt-3">
            <FactGrid facts={more} />
          </div>
        )}
        {(onInstruct || onRepush) && (
          <div className="flex flex-wrap justify-end gap-2 border-t border-border pt-3">
            {onRepush && (
              <Button variant="outline" size="sm" className="gap-2" onClick={onRepush}
                title="Re-send this login's delivery receipts for a period, from the call records">
                <MailCheck className="h-4 w-4" />
                Re-send receipts…
              </Button>
            )}
            {onInstruct && (
              <Button variant="outline" size="sm" className="gap-2" onClick={onInstruct}
                title="Mail this login's server, port, system ID and password to the customer">
                <Mail className="h-4 w-4" />
                Send connection instructions
              </Button>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/**
 * An SMPP login's sessions right now: how many, by bind type, against the login's own limits, and
 * where they come from. "of N" appears only where the login has a limit of its own.
 */
function LiveSessions({ live, limits, advanced, onDisconnect }: {
  live: { at: number; summary: SessionSummary | undefined };
  limits: Credential["limits"];
  advanced: boolean;
  /** Opens the force-disconnect dialog on this login. Absent when nothing is bound. */
  onDisconnect?: () => void;
}) {
  const { zone } = useDisplayZone();
  const s = live.summary;
  if (!s) {
    return (
      <p className="rounded-lg border border-border px-3 py-2 text-xs text-muted-foreground">
        No session open right now.
      </p>
    );
  }
  const view = connectionView(s, limits);
  const per = view.perListener ? " per listener" : "";
  const facts: Fact[] = [
    { label: "From", value: s.hosts.length ? s.hosts.join(", ") : "—", mono: s.hosts.length > 0 },
    { label: s.listeners.length === 1 ? "Listener" : "Listeners", value: s.listeners.join(", "), mono: true },
    //the label carries "oldest" so the value stays short enough not to truncate on a phone
    { label: s.sessions > 1 ? "Oldest bound for" : "Bound for", value: boundFor(s.oldest_bound_seconds) },
  ];
  return (
    <div className="space-y-3 rounded-lg border border-border px-3 py-2.5">
      <div className="flex flex-wrap items-baseline gap-x-2">
        <b className={cn("text-figure tabular-nums", view.full && "text-warning")}>{view.sessions}</b>
        <span className="text-sm text-muted-foreground">
          {view.sessions === 1 ? "session" : "sessions"}{view.limit != null ? ` of ${view.limit}${per}` : ""}
        </span>
        <span className="ml-auto text-2xs text-muted-foreground" title={formatClockTime(live.at, zone)}>live · every 10 s</span>
        {onDisconnect && (
          <Button variant="outline" size="sm" className="h-7 gap-1.5" onClick={onDisconnect}
            title="Drop this login's sessions, or its whole account's, and optionally keep them out">
            <Unplug className="h-3.5 w-3.5" aria-hidden /> Disconnect
          </Button>
        )}
      </div>
      <div className="grid grid-cols-3 gap-2">
        {view.binds.map((b) => (
          <div key={b.key} className={cn("rounded-md px-2.5 py-1.5", b.full ? "bg-warning-soft" : "bg-muted")}>
            <div className="text-2xs font-semibold tracking-wide text-muted-foreground">{b.key}</div>
            <div className={cn("font-bold tabular-nums", b.full && "text-warning")}>
              {b.count}
              {b.limit != null && <span className="font-normal text-muted-foreground">{` of ${b.limit}${per}`}</span>}
            </div>
          </div>
        ))}
      </div>
      {view.note && <p className="text-xs text-warning">{view.note}</p>}
      <FactGrid facts={facts} />
      {advanced && s.rows.length > 0 && (
        <div className="overflow-x-auto border-t border-border pt-2">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-left text-muted-foreground">
                <th className="py-1 pr-2 font-semibold">Bind</th>
                <th className="py-1 pr-2 font-semibold">From</th>
                <th className="py-1 pr-2 font-semibold">Bound for</th>
                <th className="py-1 text-right font-semibold">Submitted</th>
              </tr>
            </thead>
            <tbody>
              {s.rows.map((r, i) => (
                <tr key={r.session_id ?? i} className="border-t border-border">
                  <td className="py-1 pr-2">{bindLabel(r.bind_type)}</td>
                  <td className="py-1 pr-2 font-mono">{r.host ?? "—"}{r.port != null ? `:${r.port}` : ""}</td>
                  <td className="py-1 pr-2">{boundFor(r.bound_seconds)}</td>
                  <td className="py-1 text-right tabular-nums">{r.submitted != null ? localeNumber(r.submitted) : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {s.sessions > s.rows.length && (
            <p className="pt-1 text-2xs text-muted-foreground">{`First ${s.rows.length} of ${s.sessions} sessions.`}</p>
          )}
        </div>
      )}
    </div>
  );
}
