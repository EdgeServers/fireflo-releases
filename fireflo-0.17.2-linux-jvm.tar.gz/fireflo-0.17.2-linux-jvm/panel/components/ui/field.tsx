import * as React from "react";
import { Label } from "@/components/ui/label";
import { InfoPopover } from "@/components/ui/popover";
import { RowHelp } from "@/components/ui/row-help";

/**
 * A labelled control with an optional hint underneath.
 *
 * <p>Promoted verbatim out of `CdrFilterBar`, where it was module-private, once the worker forms and
 * the CDR column chooser needed the same three lines of markup. Byte-identical to what was there, so
 * this is a de-duplication and not a new decision.
 */
export function Field({
  label,
  hint,
  more,
  className,
  htmlFor,
  action,
  children,
}: {
  /**
   * Text, and only text.
   *
   * <p>This was `ReactNode`, and a caller duly passed a `<span>` containing a `<button>`. A
   * `<label>`'s content model excludes interactive content, and its activation behaviour forwards a
   * click to the control it labels — so the button both was invalid and did a second thing nobody
   * asked for. Narrowing the type is what stops that coming back: it is now a compile error rather
   * than a convention.
   */
  label: string;
  hint?: React.ReactNode;
  /** The full explanation, behind an info button beside the label; `hint` is then the short line. */
  more?: React.ReactNode;
  className?: string;
  htmlFor?: string;
  /** A control that belongs beside the label — rendered as its sibling, never inside it. */
  action?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className={className}>
      <div className="mb-1.5 flex items-center gap-2">
        <Label htmlFor={htmlFor} className="block">
          {label}
        </Label>
        {more && (
          <InfoPopover label={label}>
            <div className="max-h-[60vh] overflow-y-auto break-words text-sm">{more}</div>
          </InfoPopover>
        )}
        {action}
      </div>
      {children}
      {/* the label is 12px semibold in the text colour and the hint 12px regular in the muted one,
          the sample's pairing: weight and colour tell them apart, not size. These were once both
          text-sm muted, so a hint carried exactly as much weight as the thing it was explaining */}
      {hint && <RowHelp label={label} className="mt-1.5">{hint}</RowHelp>}
    </div>
  );
}
