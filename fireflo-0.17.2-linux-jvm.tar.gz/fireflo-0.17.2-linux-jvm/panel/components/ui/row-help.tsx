"use client";
import * as React from "react";
import { InfoPopover } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

/**
 * The explanation under a label: at most two lines, the whole of it behind an info button.
 *
 * <p>A setting's help is worth having and not worth reading every time. In a row's left column a
 * careful paragraph ran to fifteen lines and pushed the value it explained off the screen. So the
 * text is cut to two lines, and only when that cuts something off does the info button appear,
 * holding the full text in a popover. A help that fits is shown as it always was, with no button.
 *
 * <p>Measured, not guessed from the length: the same sentence fits on a wide screen and wraps to
 * five lines in a narrow column, and help is often markup rather than a string.
 */
export function RowHelp({
  children,
  label,
  id,
  className,
}: {
  children: React.ReactNode;
  /** What the help explains, for the info button: "SMPP". */
  label?: string;
  id?: string;
  className?: string;
}) {
  const text = React.useRef<HTMLParagraphElement>(null);
  const [cut, setCut] = React.useState(false);

  React.useEffect(() => {
    const el = text.current;
    if (!el) {
      return;
    }
    const measure = () => setCut(el.scrollHeight > el.clientHeight + 1);
    measure();
    const watch = new ResizeObserver(measure);
    watch.observe(el);
    return () => watch.disconnect();
  }, [children]);

  return (
    <div className={cn("mt-1 flex items-start gap-1", className)}>
      <p ref={text} id={id} className="line-clamp-2 min-w-0 text-xs text-muted-foreground">
        {children}
      </p>
      {cut && (
        <InfoPopover label={label ?? "this setting"} className="-mt-0.5">
          <div className="max-h-[60vh] overflow-y-auto break-words text-sm">{children}</div>
        </InfoPopover>
      )}
    </div>
  );
}
