import type { ReactNode } from "react";

/**
 * What a rate or limit field does, as four answers instead of one paragraph.
 *
 * <p>Every field that sets how fast or how much someone may send is asked the same four things:
 * where it applies, what it counts, which limit wins when several apply, and what the sender is
 * told when it is over. Written as a paragraph the answers ran together and an operator had to
 * read all of it to find the one they wanted; as labelled entries the eye goes straight to it.
 * Shown inside an {@link InfoPopover}, never on the page itself.
 */
export interface LimitFactsText {
  /** Where it applies: gateway-wide, per listener, per node. */
  scope: ReactNode;
  /** What it counts: submits a second, parts, binds. */
  limits: ReactNode;
  /** Which limit wins when several apply. */
  precedence: ReactNode;
  /** What a sender over it is answered: 0x58, 429. */
  over: ReactNode;
}

export function LimitFacts({ facts }: { facts: LimitFactsText }) {
  const rows: [string, ReactNode][] = [
    ["Scope", facts.scope],
    ["What it limits", facts.limits],
    ["Precedence", facts.precedence],
    ["Over the limit", facts.over],
  ];
  return (
    <dl className="space-y-2">
      {rows.map(([term, text]) => (
        <div key={term}>
          <dt className="text-xs font-medium text-muted-foreground">{term}</dt>
          <dd className="break-words text-sm">{text}</dd>
        </div>
      ))}
    </dl>
  );
}
