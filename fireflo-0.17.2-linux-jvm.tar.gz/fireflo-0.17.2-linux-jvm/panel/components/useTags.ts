"use client";
import { useCallback, useEffect, useState, useSyncExternalStore } from "react";
import { type Tag, type TagColor, tagColorOf } from "@/lib/tag-types";

/** A tag as the pickers and chips need it: name, label, description, colour, order and state. */
export interface TagName {
  name: string;
  label: string;
  description: string;
  color: TagColor;
  seq: number;
  enabled: boolean;
}

async function send(url: string, method: string, body?: unknown): Promise<string | null> {
  try {
    const res = await fetch(url, {
      method,
      headers: body === undefined ? undefined : { "Content-Type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    if (res.ok) return null;
    const json = await res.json().catch(() => null);
    return json?.error ?? `Request failed (${res.status})`;
  } catch (err) {
    return err instanceof Error ? err.message : "Request failed";
  }
}

/**
 * The Tags page's data and writes. `available` is false on a database before gateway 0.17.0, and
 * null until the first answer. Every write reloads, so the counts and the order are what is stored.
 */
export function useTags() {
  const [tags, setTags] = useState<Tag[]>([]);
  const [available, setAvailable] = useState<boolean | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/control/tags", { cache: "no-store" });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      setAvailable(json.data.available !== false);
      setTags((json.data.tags ?? []) as Tag[]);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    }
  }, []);

  useEffect(() => {
    //eslint-disable-next-line react-hooks/set-state-in-effect -- loading the tag list on mount
    void load();
  }, [load]);

  const run = useCallback(async (key: string, work: () => Promise<string | null>) => {
    setBusy(key);
    try {
      const failure = await work();
      if (!failure) {
        await load();
        //every chip on the page draws from the shared list: let it read the change
        invalidateTagNames();
      }
      return failure;
    } finally {
      setBusy("");
    }
  }, [load]);

  return {
    tags,
    available,
    error,
    busy,
    load,
    create: (name: string, details: { label: string; description?: string; color?: string }) =>
      run(name, () => send("/api/control/tags", "POST", { name, ...details })),
    update: (name: string, patch: { label?: string; description?: string; color?: string; enabled?: boolean }) =>
      run(name, () => send(`/api/control/tags/${encodeURIComponent(name)}`, "PATCH", patch)),
    remove: (name: string) => run(name, () => send(`/api/control/tags/${encodeURIComponent(name)}`, "DELETE")),
    reorder: (order: string[]) => run("order", () => send("/api/control/tags/order", "PUT", { order })),
  };
}

interface NamesSnapshot {
  tags: TagName[];
  /** False on a database without tags or a surface that cannot ask; null until answered. */
  available: boolean | null;
}

const EMPTY: NamesSnapshot = { tags: [], available: null };
const FRESH_MS = 30_000;
let snapshot: NamesSnapshot = EMPTY;
let loadedAt = 0;
let inflight: Promise<void> | null = null;
const listeners = new Set<() => void>();

function publish(next: NamesSnapshot) {
  snapshot = next;
  for (const l of listeners) l();
}

/** One request for every chip and picker on the page, kept for half a minute. */
function refresh(force: boolean) {
  if (inflight || (!force && snapshot.available !== null && Date.now() - loadedAt < FRESH_MS)) {
    return;
  }
  inflight = fetch("/api/control/tags?names=1", { cache: "no-store" })
    .then((r) => (r.ok ? r.json() : null))
    .then((json) => {
      loadedAt = Date.now();
      const rows = (json?.data?.tags ?? []) as Partial<TagName>[];
      publish({
        available: json ? json.data.available !== false : false,
        tags: rows.map((t) => ({
          name: String(t.name ?? ""),
          label: t.label ?? "",
          description: t.description ?? "",
          color: tagColorOf(t.color),
          seq: Number(t.seq ?? 0),
          enabled: t.enabled !== false,
        })),
      });
    })
    .catch(() => publish({ tags: [], available: false }))
    .finally(() => {
      inflight = null;
    });
}

/** After a write on the Tags page: every chip and picker reads the list again. */
export function invalidateTagNames() {
  loadedAt = 0;
  refresh(true);
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

/**
 * The tag list alone, for pickers, filters and chips: one shared light request (`?names=1`) for
 * the whole page. On a surface that cannot reach the operator API, or a database without tags,
 * `available` comes back false and the list empty. `enabled: false` asks nothing.
 */
export function useTagNames(enabled = true): NamesSnapshot {
  const value = useSyncExternalStore(subscribe, () => snapshot, () => EMPTY);
  useEffect(() => {
    if (enabled) refresh(false);
  }, [enabled]);
  return enabled ? value : EMPTY;
}
