"use client";
import { useEffect, useState } from "react";
import type { UnitsAccountView } from "@/lib/units-types";

/**
 * A units account's allowances, usage, logins and limits (gateway 0.16.0), read once per account.
 *
 * <p>Operator only: the route is under `/api/control`. `enabled` false skips the read, for the
 * money accounts that share the component calling this.
 */
export function useUnitsAccount(account: string, enabled = true): {
  view: UnitsAccountView | null;
  error: string;
  loading: boolean;
} {
  const [state, setState] = useState<{ account: string; view: UnitsAccountView | null; error: string; loading: boolean }>(
    { account, view: null, error: "", loading: enabled });

  useEffect(() => {
    if (!enabled) {
      return;
    }
    //no "loading" reset here: a reply for another account is already hidden by the identity check below
    const controller = new AbortController();
    void (async () => {
      try {
        const res = await fetch(`/api/control/accounts/${encodeURIComponent(account)}/units`,
          { cache: "no-store", signal: controller.signal });
        const json = await res.json().catch(() => null);
        setState(res.ok
          ? { account, view: json?.data ?? null, error: "", loading: false }
          : { account, view: null, error: json?.error ?? `The units could not be read (${res.status}).`, loading: false });
      } catch (err) {
        if (!controller.signal.aborted) {
          setState({ account, view: null, error: err instanceof Error ? err.message : "The units could not be read.", loading: false });
        }
      }
    })();
    return () => controller.abort();
  }, [account, enabled]);

  //a reply for another account is never shown under this one's name
  return state.account === account ? state : { view: null, error: "", loading: enabled };
}
