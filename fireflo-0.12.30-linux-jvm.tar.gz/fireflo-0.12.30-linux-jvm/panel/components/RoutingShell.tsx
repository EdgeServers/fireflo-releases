"use client";
import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { AlertTriangle, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { PageHeader } from "@/components/ui/page-header";
import { Segmented } from "@/components/ui/segmented";
import { Select } from "@/components/ui/select";
import { Rail, RailCard, RailNote, railItemClass } from "@/components/ui/rail";
import { useConfirmChange } from "./ConfirmProvider";
import { ErrorCard, ErrorNote } from "./FormNotices";
import { GatewayIgnores } from "./GatewayIgnores";
import { useFilters } from "./useFilters";
import { useHealth } from "./useHealth";
import { useRouting } from "./useRouting";
import { useRuntimeMetrics } from "./useRuntimeMetrics";
import { useWorkers } from "./useWorkers";
import type { Filter } from "@/lib/filter-types";
import type { RouteGroup } from "@/lib/group-types";
import { readsRoutingFromDatabase } from "@/lib/health-types";
import { unreachedNote } from "@/lib/routing-guide";
import {
  DEFAULT_TABLE_NAME,
  routeTableWarnings,
  validateRouteTable,
  type RouteRule,
  type RouteTable,
  type RouteTableInput,
  type TargetFunction,
} from "@/lib/routing-types";
import type { RuntimeSnapshot } from "@/lib/runtime-metrics";
import type { Worker } from "@/lib/worker-types";
import { cn } from "@/lib/utils";
import { TesterButton } from "./TesterModal";
import { ApplyNowButton } from "./ApplyNowButton";

/**
 * Everything the Routing section reads, loaded once in its layout.
 *
 * <p>The left column lists the routing tables and the tools that used to be tabs; the right is the
 * open one. Living in the layout keeps the column mounted while an operator moves between tables,
 * and lets a table page, the tester and the overview share one copy of the tables, vendors, groups
 * and filters instead of each fetching its own.
 */
export interface RoutingData {
  tables: RouteTable[];
  loading: boolean;
  error: string;
  busy: string;
  load: () => Promise<void>;
  save: (input: RouteTableInput) => Promise<string | null>;
  remove: (name: string) => Promise<string | null>;
  /** Outbound vendors. */
  clients: Worker[];
  /** Listeners: where a receipt or an inbound message is handed back. */
  servers: Worker[];
  workers: Worker[];
  groups: RouteGroup[];
  /** Preprocessors a rule can send to as `@name` (gateway 0.12.0+); empty on an older database. */
  preprocessors: { name: string; enabled: boolean }[];
  filters: Filter[];
  metrics: RuntimeSnapshot | null;
  /** `undefined` while health is unread; `false` when the gateway routes from a file. */
  writable: boolean | undefined;
  /**
   * A rule to open in the editor when `table` is next shown, unsaved. How "Start rule" on the
   * overview lands on the `default` table with its draft already in the editor.
   */
  pending: { table: string; rule: RouteRule } | null;
  startRule: (table: string, rule: RouteRule) => void;
  takePending: (table: string) => RouteRule | null;
}

const Ctx = createContext<RoutingData | null>(null);

export function useRoutingData(): RoutingData {
  const value = useContext(Ctx);
  if (!value) {
    throw new Error("useRoutingData is used outside the Routing layout.");
  }
  return value;
}

/** The same, or null outside the layout -- for a tool that fetches for itself when it has to. */
export function useRoutingDataIfPresent(): RoutingData | null {
  return useContext(Ctx);
}

/** Where each part of the section lives. Tables sit under `tables/` so no table name can shadow a tool. */
export function tableHref(name: string): string {
  return `/cp/routing/tables/${encodeURIComponent(name)}`;
}

const TOOLS = [
  { href: "/cp/routing", label: "Start here" },
  { href: "/cp/routing/groups", label: "Vendor groups" },
  { href: "/cp/routing/test", label: "Test and check" },
] as const;

export function RoutingShell({ children }: { children: ReactNode }) {
  const routing = useRouting();
  const { snapshot: metrics } = useRuntimeMetrics();
  const { workers: clients } = useWorkers("smppclient");
  const { workers: servers } = useWorkers("smppserver");
  const { filters } = useFilters();
  const { health } = useHealth();
  const [groups, setGroups] = useState<RouteGroup[]>([]);
  const [preprocessors, setPreprocessors] = useState<RoutingData["preprocessors"]>([]);
  const [pending, setPending] = useState<RoutingData["pending"]>(null);
  const [creating, setCreating] = useState(false);
  const router = useRouter();

  //the group list is small and only names targets here; GroupsClient keeps its own for editing
  useEffect(() => {
    let live = true;
    fetch("/api/control/groups", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((body) => {
        if (live && body?.data?.groups) setGroups(body.data.groups as RouteGroup[]);
      })
      .catch(() => {});
    return () => {
      live = false;
    };
  }, []);

  useEffect(() => {
    let live = true;
    fetch("/api/control/preprocessors", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((body) => {
        if (live && Array.isArray(body?.data?.preprocessors)) {
          setPreprocessors((body.data.preprocessors as { name: string; enabled: boolean }[])
            .map((p) => ({ name: p.name, enabled: p.enabled })));
        }
      })
      .catch(() => {});
    return () => {
      live = false;
    };
  }, []);

  const startRule = useCallback((table: string, rule: RouteRule) => {
    setPending({ table, rule });
    router.push(tableHref(table));
  }, [router]);

  const takePending = useCallback((table: string) => {
    if (pending?.table !== table) return null;
    setPending(null);
    return pending.rule;
  }, [pending]);

  const data: RoutingData = {
    tables: routing.tables,
    loading: routing.loading,
    error: routing.error,
    busy: routing.busy,
    load: routing.load,
    save: routing.save,
    remove: routing.remove,
    clients,
    servers,
    workers: [...clients, ...servers],
    groups,
    preprocessors,
    filters,
    metrics,
    writable: readsRoutingFromDatabase(health),
    pending,
    startRule,
    takePending,
  };

  return (
    <Ctx.Provider value={data}>
      <PageHeader
        title="Routing"
        description="Which vendor each message goes to. Rules are tried top to bottom, and the first match wins."
        actions={
          <>
            <TesterButton tab="routing" data={{ tables: routing.tables, servers }} />
            <ApplyNowButton />
            <Button className="gap-2 lg:hidden" onClick={() => setCreating(true)}>
              <Plus className="h-4 w-4" aria-hidden="true" /> New table
            </Button>
          </>
        }
      />
      <ErrorCard error={routing.error} />
      <GatewayIgnores domain="routing" />
      <div className="flex flex-wrap items-start gap-6">
        <RoutingNav data={data} onNew={() => setCreating(true)} />
        <div className="flex min-w-0 flex-[999_1_560px] flex-col gap-5">{children}</div>
      </div>
      {creating && (
        <NewTableDialog
          tables={routing.tables}
          onClose={() => setCreating(false)}
          onCreate={async (input) => {
            const failure = await routing.save(input);
            if (!failure) {
              setCreating(false);
              router.push(tableHref(input.name));
            }
            return failure;
          }}
        />
      )}
    </Ctx.Provider>
  );
}

function RoutingNav({ data, onNew }: { data: RoutingData; onNew: () => void }) {
  const pathname = usePathname();
  const router = useRouter();
  const tableNames = data.tables.map((t) => t.name);
  const groupNames = data.groups.map((g) => g.name);
  const activeTable = pathname.startsWith("/cp/routing/tables/")
    ? decodeURIComponent(pathname.slice("/cp/routing/tables/".length))
    : null;
  const activeTool = activeTable === null ? pathname : null;
  //the entry point first, then the rest as the database orders them
  const ordered = [
    ...data.tables.filter((t) => t.name === DEFAULT_TABLE_NAME),
    ...data.tables.filter((t) => t.name !== DEFAULT_TABLE_NAME),
  ];

  return (
    <>
      {/* a select on a phone, where a column of links would push the table below the fold */}
      <label className="flex w-full flex-col gap-1 text-xs text-muted-foreground lg:hidden">
        Show
        <Select
          aria-label="Routing table or tool"
          value={activeTable !== null ? tableHref(activeTable) : pathname}
          onChange={(e) => router.push(e.target.value)}
        >
          <optgroup label="Routing tables">
            {ordered.map((t) => (
              <option key={t.name} value={tableHref(t.name)}>
                {t.name} · {t.rules.length} {t.rules.length === 1 ? "rule" : "rules"}
                {t.name === DEFAULT_TABLE_NAME ? " · entry point" : ""}
                {t.targetFunction === "LCR" ? " · cheapest" : ""}
              </option>
            ))}
          </optgroup>
          <optgroup label="Tools">
            {TOOLS.map((t) => <option key={t.href} value={t.href}>{t.label}</option>)}
          </optgroup>
        </Select>
      </label>

      {/* where to start, then the tables in a card of their own -- the same rail as Pricing */}
      <Rail label="Routing">
        <RailCard>
          {TOOLS.map((tool) => (
            <Link
              key={tool.href}
              href={tool.href}
              aria-current={activeTool === tool.href ? "page" : undefined}
              className={railItemClass(activeTool === tool.href)}
            >
              {tool.label}
              {tool.href === "/cp/routing/groups" && groupNames.length > 0 && (
                <span className="ml-auto text-xs font-normal tabular-nums text-muted-foreground">{groupNames.length}</span>
              )}
            </Link>
          ))}
        </RailCard>

        <RailCard title="Tables" what="where messages go" count={data.loading ? null : data.tables.length}>
          {data.loading && <RailNote>Loading…</RailNote>}
          {ordered.map((t) => {
            const active = activeTable === t.name;
            const unreached = unreachedNote(t.name, data.tables);
            const reasons = [...(unreached ? [unreached] : []), ...routeTableWarnings(t, tableNames, data.workers, data.groups)];
            return (
              <Link
                key={t.name}
                href={tableHref(t.name)}
                aria-current={active ? "page" : undefined}
                className={railItemClass(active, cn(!t.enabled && "opacity-60"))}
              >
                <span className="min-w-0 truncate font-mono text-sm">{t.name}</span>
                {t.name === DEFAULT_TABLE_NAME && <RailChip tone="ok">Entry</RailChip>}
                {t.targetFunction === "LCR" && <RailChip>LCR</RailChip>}
                {!t.enabled && <RailChip>Off</RailChip>}
                <span className="ml-auto flex shrink-0 items-center gap-1 pl-1 text-xs font-normal tabular-nums text-muted-foreground">
                  {reasons.length > 0 && (
                    <span title={reasons.join("\n\n")} className="inline-flex">
                      <AlertTriangle className="h-3.5 w-3.5 text-warning" aria-label={reasons.join(" ")} />
                    </span>
                  )}
                  {t.rules.length}
                </span>
              </Link>
            );
          })}
          {!data.loading && !data.tables.length && <RailNote>No routing tables yet.</RailNote>}
          <button type="button" onClick={onNew} className={railItemClass(false, "gap-1.5 font-semibold text-primary")}>
            <Plus className="h-3.5 w-3.5" aria-hidden="true" /> New table
          </button>
        </RailCard>
      </Rail>
    </>
  );
}

const FUNCTION_OPTIONS = [
  { value: "NORMAL" as const, label: "In order", title: "The first matching rule wins." },
  { value: "LCR" as const, label: "Cheapest vendor", title: "Every matching vendor competes, and the cheapest rate wins." },
];

/** A new table: a name, how it chooses, what it is for. It starts empty and opens for rules. */
function NewTableDialog({
  tables,
  onClose,
  onCreate,
}: {
  tables: RouteTable[];
  onClose: () => void;
  onCreate: (input: RouteTableInput) => Promise<string | null>;
}) {
  const [name, setName] = useState("");
  const [targetFunction, setTargetFunction] = useState<TargetFunction>("NORMAL");
  const [label, setLabel] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const confirm = useConfirmChange();
  const taken = tables.some((t) => t.name === name.trim());

  async function submit() {
    const input: RouteTableInput = { name, targetFunction, label, enabled: true, rules: [] };
    const invalid = validateRouteTable(input) ?? (taken ? `A table named ${name.trim()} already exists.` : null);
    if (invalid) {
      setError(invalid);
      return;
    }
    const ok = await confirm({
      title: `Create routing table ${name.trim()}`,
      consequence: `An empty ${targetFunction} table named ${name.trim()} is added. It routes nothing until a rule `
        + "in another table sends to it and it has rules of its own.",
      confirmLabel: "Create table",
    });
    if (!ok) return;
    setSaving(true);
    setError("");
    const failure = await onCreate(input);
    setSaving(false);
    if (failure) setError(failure);
  }

  return (
    <Dialog open onClose={onClose} title="New routing table">
      <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); void submit(); }}>
        <Field label="Name" htmlFor="nt-name" hint="Rules send into it by this name. Matched exactly, and fixed once created.">
          <Input id="nt-name" className="font-mono" value={name} placeholder="india_routes" autoFocus
            onChange={(e) => setName(e.target.value)} aria-invalid={taken || undefined} />
        </Field>
        <div className="space-y-1.5">
          <div id="nt-fn" className="text-sm font-medium">How it chooses</div>
          <Segmented<TargetFunction> label="How it chooses" value={targetFunction} onChange={setTargetFunction} options={FUNCTION_OPTIONS} fill />
          <p className="text-xs text-muted-foreground">
            {targetFunction === "NORMAL"
              ? "Rules are tried top to bottom and the first match wins."
              : "Every matching vendor is a candidate and the cheapest rate wins. Order does not matter."}
          </p>
        </div>
        <Field label="Description" htmlFor="nt-label" hint="Optional. What this table is for.">
          <Input id="nt-label" value={label} onChange={(e) => setLabel(e.target.value)} />
        </Field>
        <ErrorNote error={error} />
        <div className="flex flex-wrap justify-end gap-2 border-t border-border pt-4">
          <Button type="button" variant="ghost" className="mr-auto" onClick={onClose}>Cancel</Button>
          <Button type="submit" disabled={saving || !name.trim() || taken}>{saving ? "Creating…" : "Create table"}</Button>
        </div>
      </form>
    </Dialog>
  );
}

/** A small tag on a rail row, drawn as Pricing's are. */
function RailChip({ tone = "muted", children }: { tone?: "ok" | "muted"; children: ReactNode }) {
  return (
    <span className={cn(
      "shrink-0 rounded-full px-2 py-px text-2xs font-medium",
      tone === "ok" ? "bg-primary-soft text-primary" : "border border-border text-muted-foreground"
    )}>
      {children}
    </span>
  );
}
