"use client";
import { useState } from "react";
import { AlertTriangle, PlugZap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CardSection } from "@/components/ui/card";
import { tpsSummary, type HealthWorker } from "@/lib/health-types";
import { SessionBrowser } from "./SessionBrowser";
import { SessionList } from "./SessionList";
import { HEALTH_POLL_SECONDS } from "./useHealth";
import { KIND, type WorkerType } from "@/lib/worker-types";
import {
  liveStats, throughputTone, type BindCapacity, type WorkerVerdict,
} from "@/lib/worker-verdict";
import { bindTotal, sessionsAreComplete, summariseBinds } from "@/lib/bind-summary";
import { LiveStatCards } from "./LiveStatCards";
import { useConfirmChange } from "./ConfirmProvider";
import { count } from "@/lib/format";

/**
 * What the gateway is doing with this connection, and the controls that change it.
 *
 * <p>Restructured around one idea: <strong>reading and acting are separate</strong>. The numbers
 * describe, the buttons below them act, and the buttons that change live traffic are grouped and
 * labelled as such — they used to sit in an undifferentiated row of five outline buttons split
 * across the card header and the card body, so nothing said which ones reroute production traffic.
 *
 * <p>The verdict badge itself lives in the card header, next to the name, because that is where
 * someone scanning ten vendors looks. This renders the detail behind it.
 *
 * <h2>Two clocks, and now they say so</h2>
 *
 * <p>Everything here is a ten-second poll of the gateway — what is true at this instant. The
 * traffic block further down the same card is a rolling window over the call records, refreshed a
 * sixth as often. They used to stack with no break between them, so a card mixed "right now" and
 * "since yesterday" in one column with nothing marking the change of subject. Hence the section
 * heading, and hence it names the refresh interval rather than leaving it to be guessed.
 */
export function ConnectionStatus({
  type,
  live,
  verdict,
  paused,
  capacity = null,
  windowSeconds,
  tpsHistory,
}: {
  type: WorkerType;
  live: HealthWorker | undefined;
  verdict: WorkerVerdict;
  /** Only to tone the queue card — a queue that is being held reads differently from one that is not. */
  paused: boolean;
  /** What the stored settings ask for, so the bind count can be read against it. */
  capacity?: BindCapacity | null;
  /** `tps_window_seconds` from the snapshot — the period the measured rate is a mean over. */
  windowSeconds?: number | null;
  /** Recent measured rates, oldest first, for the trend under the throughput figure. */
  tpsHistory?: readonly (number | null)[];
}) {
  const isVendor = type === KIND.vendor;
  const stats = liveStats(live, isVendor, paused, capacity);
  const throughput = live ? tpsSummary(live) : null;

  return (
    <CardSection
      title="Right now"
      description={`Refreshed every ${HEALTH_POLL_SECONDS}s`}
    >
      {verdict.detail && <p className="text-sm text-muted-foreground">{verdict.detail}</p>}

      {verdict.pending && (
        <p className="text-sm text-amber-600 dark:text-amber-400">
          Stored settings and what the gateway is running disagree. The change is saved; either it has
          not been picked up yet, or the push did not reach the gateway and the thirty-second poll
          will apply it.
        </p>
      )}

      {live?.last_error && (
        <p className="flex items-start gap-1.5 text-sm text-destructive">
          <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <span>
            {live.last_error}
            {live.last_error_at && (
              <span className="text-muted-foreground"> — {live.last_error_at}</span>
            )}
          </span>
        </p>
      )}

      {/* A bound vendor refusing every submit is the failure this whole block existed to miss: the
          sessions are up, the queue drains, and nothing above says a word. Shown in amber, not red
          -- the connection genuinely is fine, and colouring it the same as "not connected" would
          send an operator to check the wrong thing. */}
      {live?.last_submit_error && (
        <p className="flex items-start gap-1.5 text-sm text-amber-600 dark:text-amber-400">
          <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <span>
            Vendor rejected {live.submit_rejected ? count(live.submit_rejected) : "a"} submit
            {live.submit_rejected === 1 ? "" : "s"} — {live.last_submit_error}
            {live.last_submit_error_at && (
              <span className="text-muted-foreground"> — {live.last_submit_error_at}</span>
            )}
          </span>
        </p>
      )}

      {/* the throughput sits with the counts rather than in a row of its own: it answers the same
          question they do, and it is the only one carrying a ceiling worth comparing against */}
      <LiveStatCards
        stats={[
          ...stats,
          ...(throughput
            ? [{
                label: "Throughput",
                value: throughput,
                history: tpsHistory,
                ...throughputTone(live, paused, windowSeconds),
              }]
            : []),
        ]}
      />
    </CardSection>
  );
}

/**
 * The individual binds behind the count, as a section rather than a footnote.
 *
 * <p>This used to be a bare `<details>` whose summary read "5 sessions", and the snapshot behind it
 * was fetched every ten seconds purely to decide whether that disclosure should exist. Every field
 * in the sample was discarded, and opening it then made a <em>second</em> request for the same
 * rows. Two things follow from that:
 *
 * <ul>
 *   <li>the heading now carries {@link summariseBinds}, so the closed state says something —
 *       what kind of binds, whether any fell back to a backup host, whether one is doing all the
 *       work — instead of restating a number already in the badge above it</li>
 *   <li>when the snapshot holds every session, the table renders from it directly. `/ops/health`
 *       caps the array at twenty, so for a five-bind vendor a round trip to fetch what is already
 *       in memory buys nothing but a spinner</li>
 * </ul>
 *
 * <p>{@link SessionBrowser} is still the right answer above that cap — a listener with four hundred
 * customers needs search and paging, and a twenty-row sample of it would be a lie by omission.
 *
 * <p>`canDisconnect` for a listener only, and only here: `/cp/health` is somewhere to read from,
 * and a destructive button on a five-second poll is a button that moves under the cursor.
 */
export function BindList({
  type,
  live,
}: {
  type: WorkerType;
  live: HealthWorker | undefined;
}) {
  const isVendor = type === KIND.vendor;
  const sessions = live?.sessions ?? [];
  if (!live || sessions.length === 0) {
    return null;
  }
  const total = sessionCount(live);
  const complete = sessionsAreComplete(live.sessions_total, sessions.length);

  return (
    <CardSection
      title={isVendor ? "Binds" : "Bound customers"}
      description={summariseBinds(sessions, isVendor)}
    >
      {complete ? (
        <SessionList
          type={type}
          sessions={sessions}
          worker={live.name}
          canDisconnect={type === KIND.server}
          //the denominator for Share, and only supplied on this path: within a page of a larger
          //set the sum is not the worker's traffic, so a percentage of it would not be a share
          total={bindTotal(sessions)}
        />
      ) : (
        <SessionBrowser
          worker={live.name}
          type={type}
          canDisconnect={type === KIND.server}
          total={total}
        />
      )}
    </CardSection>
  );
}

/**
 * The controls that change live traffic, for a card footer.
 *
 * <p>Separated from the status above it because reading and acting are different jobs, and because
 * the footer is where an action belongs on a card this tall — by the time you have scrolled past
 * eighty settings, a control buried in the middle of the body is somewhere you have to go back to.
 *
 * <p>Right-aligned, with the queue warning on the left: a held queue grows for as long as it is
 * held, and that growth is the entire risk of the control it sits beside.
 */
export function LiveTrafficControls({
  name,
  type,
  live,
  verdict,
  suspended,
  paused,
  busy,
  busyLabel,
  onSuspend,
  onPause,
  onRestart,
  offerTest = true,
}: {
  name: string;
  type: WorkerType;
  live: HealthWorker | undefined;
  verdict: WorkerVerdict;
  suspended: boolean;
  paused: boolean;
  busy: boolean;
  busyLabel: string;
  onSuspend: (on: boolean) => void;
  onPause: (on: boolean) => void;
  onRestart?: () => void;
  /** False where the page offers its own Test connection, with the step log. */
  offerTest?: boolean;
}) {
  const isVendor = type === KIND.vendor;
  const confirm = useConfirmChange();
  const noun = isVendor ? "vendor" : "listener";

  //every traffic control is confirmed, on vendors and listeners alike: each one changes what the
  //gateway does with live traffic the moment it lands
  const suspend = async () => {
    const on = !suspended;
    const ok = await confirm({
      title: on ? `Stop sending on ${name}?` : `Resume sending on ${name}?`,
      consequence: on
        ? isVendor
          ? `The ${noun} ${name} stops taking messages; they wait in its queue until you resume.`
          : `The ${noun} ${name} keeps accepting messages but routes none of them; they are parked until you resume.`
        : `The ${noun} ${name} goes back to ${isVendor ? "sending what is queued for it" : "routing what it accepts, parked messages first"}.`,
      confirmLabel: on ? "Stop sending" : "Resume sending",
      tone: "caution",
    });
    if (ok) {
      onSuspend(on);
    }
  };
  const pause = async () => {
    const on = !paused;
    const ok = await confirm({
      title: on ? `Hold ${name}?` : `Release the hold on ${name}?`,
      consequence: on
        ? `The ${noun} ${name} refuses new messages at the door, and its receipts are held, until you release it.`
        : `The ${noun} ${name} accepts messages again and delivers the receipts it held.`,
      confirmLabel: on ? "Hold" : "Release hold",
      tone: "caution",
    });
    if (ok) {
      onPause(on);
    }
  };
  const restart = async () => {
    const ok = await confirm({
      title: `Restart ${name}?`,
      consequence: `Every connection of the ${noun} ${name} is closed and opened again; messages in flight are retried.`,
      confirmLabel: "Restart",
      tone: "caution",
    });
    if (ok) {
      onRestart?.();
    }
  };

  return (
    <div className="flex flex-1 flex-wrap items-center justify-end gap-2">
      {paused && live && live.queue_depth > 0 && (
        <Badge variant="warning" className="mr-auto">
          {count(live.queue_depth)} queued and growing
        </Badge>
      )}
      {/* the park is the whole point of Stop sending on a listener: accepted, not routed, and
          not lost — say so where the operator is looking */}
      {suspended && !isVendor && live?.held_inbound != null && live.held_inbound > 0 && (
        <Badge variant="warning" className="mr-auto">
          {count(live.held_inbound)} accepted and parked — routed on resume
        </Badge>
      )}
      {/* only worth offering when it can tell you something: a bound vendor has already answered
          the question, and one the gateway has not loaded cannot be asked to dial */}
      {offerTest && isVendor && verdict.label === "Not connected" && <TestConnection name={name} />}
      <ToggleControl
        on={suspended}
        busy={busy}
        busyLabel={busyLabel}
        offLabel="Stop sending"
        onLabel="Resume sending"
        onToggle={suspend}
      />
      {/* the two worker kinds carry different second controls, per the chosen semantics: a
          listener can HOLD (refuse at the door, receipts held too — release resumes because
          clients retry on RMSGQFUL), while a vendor gets RESTART (bounce the connection) and no
          Hold — holding a vendor only grew its queue and read as "still sending" */}
      {isVendor ? (
        onRestart && (
          <Button
            variant="outline"
            size="sm"
            disabled={busy}
            onClick={restart}
          >
            {busy && busyLabel === "Restart" ? "Restarting…" : "Restart"}
          </Button>
        )
      ) : (
        <ToggleControl
          on={paused}
          busy={busy}
          busyLabel={busyLabel}
          offLabel="Hold"
          onLabel="Release hold"
          onToggle={pause}
        />
      )}
    </div>
  );
}

/**
 * Confirms enabling or disabling a vendor or listener; resolves true to go ahead.
 *
 * <p>Shared by the list cards and the detail pages of both kinds, so the four Enable/Disable buttons
 * say the same thing about the same act.
 */
export function useConfirmEnabled(): (name: string, type: WorkerType, enable: boolean) => Promise<boolean> {
  const confirm = useConfirmChange();
  return (name, type, enable) => {
    const noun = type === KIND.vendor ? "vendor" : "listener";
    return confirm({
      title: `${enable ? "Enable" : "Disable"} ${name}?`,
      consequence: enable
        ? `The gateway starts the ${noun} ${name} and it takes traffic again.`
        : type === KIND.vendor
          ? `The gateway closes every connection of the ${noun} ${name}; routes to it stop sending until it is enabled again.`
          : `The gateway closes the ${noun} ${name} and every client bound to it is disconnected.`,
      confirmLabel: enable ? "Enable" : "Disable",
      tone: "caution",
    });
  };
}

/**
 * A control whose current state is visible in the button, not only in a badge somewhere else.
 *
 * <p>An engaged control gets the amber treatment the rest of the panel uses for "on purpose, and
 * worth noticing". The old version drew both buttons identically whether or not the thing was
 * engaged, so "Hold" and "Release hold" were told apart only by reading the label.
 */
function ToggleControl({
  on,
  busy,
  busyLabel,
  offLabel,
  onLabel,
  onToggle,
}: {
  on: boolean;
  busy: boolean;
  busyLabel: string;
  offLabel: string;
  onLabel: string;
  onToggle: () => void;
}) {
  const label = on ? onLabel : offLabel;
  return (
    <Button
      variant="outline"
      size="sm"
      aria-pressed={on}
      disabled={busy}
      className={on ? "border-amber-500/40 bg-amber-500/10 text-amber-600 dark:text-amber-400" : undefined}
      onClick={onToggle}
    >
      {busy && busyLabel === label ? "Working…" : label}
    </Button>
  );
}

interface TestResult {
  tested: boolean;
  bound: boolean;
  detail: string;
}

function TestConnection({ name }: { name: string }) {
  const [result, setResult] = useState<TestResult | null>(null);
  const [error, setError] = useState("");
  const [running, setRunning] = useState(false);

  async function run() {
    setRunning(true);
    setResult(null);
    setError("");
    try {
      const res = await fetch(`/api/control/workers/${encodeURIComponent(name)}/test-bind`, {
        method: "POST",
      });
      const json = await res.json();
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
      } else {
        setResult(json.data as TestResult);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setRunning(false);
    }
  }

  return (
    <>
      <Button variant="outline" size="sm" disabled={running} onClick={run}>
        <PlugZap className="mr-1.5 h-4 w-4" />
        {running ? "Connecting…" : "Test connection"}
      </Button>
      {error && <span className="text-sm text-destructive">{error}</span>}
      {result && (
        //`tested: false` means nothing was dialled -- refused because already bound, or nothing
        //configured to dial. Drawing that in red would report a failure that never happened
        <span
          className={
            !result.tested
              ? "text-sm text-muted-foreground"
              : result.bound
                ? "text-sm text-emerald-600 dark:text-emerald-400"
                : "text-sm text-destructive"
          }
        >
          {result.detail}
        </span>
      )}
    </>
  );
}

/**
 * How many sessions this worker really has.
 *
 * <p>`sessions` from health is a bounded sample, so its length is a fact about the payload rather
 * than about the customer. `sessions_total` is the count; the length is only the fallback for a
 * gateway older than that field, where the two were the same thing.
 */
function sessionCount(worker: HealthWorker): number {
  return worker.sessions_total ?? worker.sessions?.length ?? 0;
}
