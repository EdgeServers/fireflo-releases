import { strict as assert } from "node:assert";
import { after, before, describe, test } from "node:test";

import {
  STATEMENT_CUT_SQL,
  statementSummarySql,
  summariseStatement,
  summaryParams,
  type StatementCut,
  type StatementDayProductRow,
} from "./statement-sql.ts";

const norm = (sql: string) => sql.replace(/\s+/g, " ").trim();

test("by login, each source groups by its own login column; by product, nothing changes", () => {
  const product = norm(statementSummarySql({ vendorAttempt: true }, { hourly: true }));
  assert.equal(product, norm(statementSummarySql({ vendorAttempt: true }, { hourly: true, split: "product", dailyLogin: true, hourlyLogin: true })),
    "the login columns are not even named by product");
  assert.doesNotMatch(product, /system_id/);
  const login = norm(statementSummarySql({ vendorAttempt: true }, { hourly: true, split: "login", dailyLogin: true, hourlyLogin: true }));
  assert.match(login, /COALESCE\(s\.system_id, ''\) AS product/);
  assert.match(login, /SELECT u\.day, COALESCE\(u\.system_id, ''\) AS product/);
  assert.match(login, /COALESCE\(h\.system_id, ''\) AS product/);
  assert.match(login, /s\.system_id FROM cdr_submit s/, "the records carry the login through the DISTINCT ON");
  //a gateway without the columns: those sources are the "—" login, and never name the column
  const old = norm(statementSummarySql({ vendorAttempt: true }, { hourly: true, split: "login" }));
  assert.doesNotMatch(old, /[uh]\.system_id/);
  assert.match(old, /SELECT u\.day, ''::text AS product/);
});

test("the days carry each key's messages and money, and add up to the lines", () => {
  const rows: StatementDayProductRow[] = [
    { day: "2026-01-01", product: "L1", submitted: 3, delivered: 3, failed: 0, expired: 0, pending: 0, unrated: 0, amount: 300, from_summary: 1 },
    { day: "2026-01-01", product: "", submitted: 2, delivered: 1, failed: 1, expired: 0, pending: 0, unrated: 0, amount: 200, from_summary: 1 },
    { day: "2026-01-02", product: "L1", submitted: 1, delivered: 1, failed: 0, expired: 0, pending: 0, unrated: 0, amount: 100, from_summary: 0 },
  ];
  const { lines, days } = summariseStatement(rows);
  assert.deepEqual({ ...days[0].byKey }, { L1: { submitted: 3, amount: 300 }, "": { submitted: 2, amount: 200 } });
  assert.deepEqual({ ...days[1].byKey }, { L1: { submitted: 1, amount: 100 } });
  const sumDays = days.reduce((n, d) => n + Object.values(d.byKey).reduce((m, k) => m + k.amount, 0), 0);
  assert.equal(sumDays, lines.reduce((n, l) => n + l.amount, 0));
});

/**
 * Against PostgreSQL: two logins over rolled days, trusted hours and the raw tail give per-login
 * lines that sum to the product lines, and days rolled before the login column read as "—".
 */
const URL = process.env.STATEMENT_TEST_DATABASE_URL ?? process.env.CDR_TIER_TEST_DATABASE_URL;

describe("the statement split against PostgreSQL", { skip: URL ? false : "STATEMENT_TEST_DATABASE_URL is not set" }, () => {
  const SCHEMA = `stmt_login_${process.pid}`;
  const ZONE = "UTC";
  let pool: import("pg").Pool;
  const run = async <T,>(sql: string, params: unknown[] = []) => (await pool.query(sql, params)).rows as T[];
  const at = (s: string) => new Date(`${s}Z`);
  /** The truth: every message's login, product and price, straight from the fixture. */
  const truth = new Map<string, { submitted: number; amount: number }>();
  const add = (key: string, price: number) => {
    const t = truth.get(key) ?? { submitted: 0, amount: 0 };
    t.submitted += 1;
    t.amount += price;
    truth.set(key, t);
  };

  before(async () => {
    const pg = (await import("pg")).default;
    pool = new pg.Pool({ connectionString: URL, max: 1, options: `-c search_path=${SCHEMA}` });
    await run(`CREATE SCHEMA ${SCHEMA}`);
    await run(`CREATE TABLE cdr_submit (id bigserial PRIMARY KEY, gateway_msg_id text NOT NULL, part_no int NOT NULL DEFAULT 1,
      account_id text, system_id text, product text, submitted_at timestamptz NOT NULL, price bigint,
      retry_count int NOT NULL DEFAULT 0, vendor_attempt int NOT NULL DEFAULT 0)`);
    await run(`CREATE TABLE cdr_final (gateway_msg_id text NOT NULL, part_no int NOT NULL DEFAULT 1, final_state text NOT NULL,
      final_at timestamptz NOT NULL, dlr_state int, err_code text)`);
    const summary = `account_id text NOT NULL, product text NOT NULL, system_id text NOT NULL DEFAULT '',
      submitted bigint NOT NULL, delivered bigint NOT NULL, failed bigint NOT NULL, expired bigint NOT NULL,
      pending_at_rollup bigint NOT NULL, unrated_messages bigint NOT NULL, price_total bigint NOT NULL`;
    await run(`CREATE TABLE usage_daily (day date NOT NULL, ${summary}, PRIMARY KEY (account_id, day, product, system_id))`);
    await run(`CREATE TABLE usage_hourly (hour timestamptz NOT NULL, vendor text NOT NULL DEFAULT '', ${summary},
      rolled_up_at timestamptz NOT NULL DEFAULT now())`);

    let n = 0;
    for (let d = 1; d <= 31; d++) {
      const day = `2026-01-${String(d).padStart(2, "0")}`;
      for (const [login, product, price, hh] of [["L1", "p1", 500, "09"], ["L2", "p1", 700, "10"], ["L2", "p2", 300, "11"], ["L1", "p2", 900, "12"]] as const) {
        if ((d + hh.length + price) % 3 === 0 && login === "L1" && product === "p2") {
          continue;
        }
        const id = `m${++n}`;
        await run(`INSERT INTO cdr_submit (gateway_msg_id, account_id, system_id, product, submitted_at, price)
                   VALUES ($1, 'acme', $2, $3, $4, $5)`, [id, login, product, at(`${day}T${hh}:00:00`), price]);
        await run("INSERT INTO cdr_final (gateway_msg_id, final_state, final_at) VALUES ($1, 'DELIVERED', $2)",
          [id, at(`${day}T${hh}:01:00`)]);
        //days before the 10th were rolled before the login column existed: "—"
        add(d < 10 ? "" : login, price);
      }
    }
    const roll = (login: boolean) => `
      INSERT INTO usage_daily (account_id, day, product, system_id, submitted, delivered, failed, expired,
                               pending_at_rollup, unrated_messages, price_total)
      SELECT s.account_id, (s.submitted_at AT TIME ZONE 'UTC')::date, s.product, ${login ? "s.system_id" : "''"},
             count(*), count(*), 0, 0, 0, 0, sum(s.price)
        FROM cdr_submit s WHERE s.submitted_at >= $1 AND s.submitted_at < $2 GROUP BY 1, 2, 3, 4`;
    await run(roll(false), [at("2026-01-01T00:00:00"), at("2026-01-10T00:00:00")]);
    await run(roll(true), [at("2026-01-10T00:00:00"), at("2026-01-25T00:00:00")]);
    //the trusted hours of the tail, [25th, 27th), by login
    await run(`INSERT INTO usage_hourly (account_id, hour, product, system_id, submitted, delivered, failed, expired,
                                         pending_at_rollup, unrated_messages, price_total)
      SELECT s.account_id, date_trunc('hour', s.submitted_at), s.product, s.system_id,
             count(*), count(*), 0, 0, 0, 0, sum(s.price)
        FROM cdr_submit s WHERE s.submitted_at >= $1 AND s.submitted_at < $2 GROUP BY 1, 2, 3, 4`,
      [at("2026-01-25T00:00:00"), at("2026-01-27T00:00:00")]);
  });

  after(async () => {
    if (pool) {
      await run(`DROP SCHEMA IF EXISTS ${SCHEMA} CASCADE`).catch(() => undefined);
      await pool.end();
    }
  });

  async function statement(split: "product" | "login") {
    const since = at("2026-01-01T00:00:00");
    const until = at("2026-02-01T00:00:00");
    const [cut] = await run<StatementCut>(STATEMENT_CUT_SQL, ["acme", since, until, ZONE, "2026-01-25", 24]);
    assert.equal(cut.boundary, "2026-01-25");
    //the hourly seam: the 27th; the records from there
    const seam = at("2026-01-27T00:00:00");
    const rows = await run<StatementDayProductRow>(
      statementSummarySql({ vendorAttempt: true }, { hourly: true, split, dailyLogin: true, hourlyLogin: true }),
      summaryParams("acme", since, until, ZONE, cut, seam));
    return summariseStatement(rows);
  }

  test("per-login lines over rolled days, trusted hours and the raw tail: the truth, and the product totals", async () => {
    const byLogin = await statement("login");
    const byProduct = await statement("product");
    const lines = Object.fromEntries(byLogin.lines.map((l) => [l.product, { submitted: l.submitted, amount: l.amount }]));
    assert.deepEqual(lines, Object.fromEntries(truth));
    assert.ok("" in lines, "days rolled before the login column are one '—' line");
    const total = (ls: { submitted: number; amount: number }[]) =>
      ls.reduce((n, l) => ({ submitted: n.submitted + l.submitted, amount: n.amount + l.amount }), { submitted: 0, amount: 0 });
    assert.deepEqual(total(byLogin.lines), total(byProduct.lines), "the totals are the same in both modes");
    assert.deepEqual(byLogin.days.map((d) => [d.day, d.submitted, d.price]), byProduct.days.map((d) => [d.day, d.submitted, d.price]),
      "and so is every day");
    assert.equal(byLogin.days.length, 31);
  });
});
