import { lookup } from "node:dns/promises";
import { isIP } from "node:net";

import type { DbPool } from "./db-trace.ts";

/**
 * Which database server a pool talks to, as the footer names it: `host:port`, with the address
 * beside a name when the two differ -- "db.internal (10.128.0.2):5432" -- or "local socket".
 *
 * <p><strong>Never the user or the password.</strong> Only the URL's host and port are read; the
 * rest of a connection string is not looked at, let alone kept. A URL that does not parse reports
 * "unknown" rather than echoing the string, which may hold the secret.
 *
 * <p>Resolved once per URL for the life of the process (`dns.lookup`, the resolver the pool itself
 * uses): a footer stat is not worth a DNS query per request, and a failed lookup just shows the
 * name.
 */

export interface Endpoint {
  /** The host as written: a name, an IPv4 address or an IPv6 one without brackets. Null for a socket. */
  host: string | null;
  port: string;
  socket: boolean;
}

const DEFAULT_PORT = "5432";

/** The host and port of a PostgreSQL URL, or null when it does not parse. */
export function parseEndpoint(raw: string): Endpoint | null {
  const text = raw.trim();
  if (text.startsWith("socket:")) {
    return { host: null, port: DEFAULT_PORT, socket: true };
  }
  let url: URL;
  try {
    url = new URL(text);
  } catch {
    return null;
  }
  const port = url.port || DEFAULT_PORT;
  //`?host=/var/run/postgresql` and an encoded path as the host both mean a Unix socket
  const queryHost = url.searchParams.get("host");
  if (queryHost?.startsWith("/")) {
    return { host: null, port, socket: true };
  }
  let host = decodeURIComponent(url.hostname);
  if (host.startsWith("/")) {
    return { host: null, port, socket: true };
  }
  if (host.startsWith("[") && host.endsWith("]")) {
    host = host.slice(1, -1);
  }
  //no host at all: node-postgres connects to localhost over TCP
  return { host: host || queryHost || "localhost", port, socket: false };
}

/** The footer's wording for an endpoint, given the address its name resolved to (if any). */
export function endpointLabel(e: Endpoint | null, address?: string | null): string {
  if (!e) {
    return "unknown";
  }
  if (e.socket || !e.host) {
    return "local socket";
  }
  const shown = isIP(e.host) === 6 ? `[${e.host}]` : e.host;
  if (address && address !== e.host) {
    return `${shown} (${address}):${e.port}`;
  }
  return `${shown}:${e.port}`;
}

type Resolve = (host: string) => Promise<string>;

const defaultResolve: Resolve = async (host) => (await lookup(host)).address;

const labels = new Map<string, Promise<string>>();

/**
 * The label for `url`, resolving its host at first use and keeping the answer for the process.
 *
 * @param resolve for tests; `dns.lookup` otherwise
 */
export function labelFor(url: string, resolve: Resolve = defaultResolve): Promise<string> {
  const known = labels.get(url);
  if (known) {
    return known;
  }
  const e = parseEndpoint(url);
  const label = (async () => {
    if (!e || e.socket || !e.host || isIP(e.host)) {
      return endpointLabel(e);
    }
    try {
      return endpointLabel(e, await resolve(e.host));
    } catch {
      return endpointLabel(e);
    }
  })();
  labels.set(url, label);
  return label;
}

/** The label for one of the panel's pools, from its environment variable; null when it is unset. */
export async function poolLabel(pool: DbPool): Promise<string | null> {
  const url = (pool === "metrics" ? process.env.METRICS_DATABASE_URL : process.env.CONFIG_DATABASE_URL)?.trim();
  return url ? labelFor(url) : null;
}

/** Test helper: forget every resolved label. */
export function resetEndpointLabels(): void {
  labels.clear();
}
