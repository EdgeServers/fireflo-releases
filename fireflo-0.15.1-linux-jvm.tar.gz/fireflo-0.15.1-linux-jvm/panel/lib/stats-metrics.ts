/**
 * Every stat and chart the panels read, by name: who may ask for it, over which periods, and which
 * period it answers when none (or a wrong one) is asked for.
 *
 * <p>Pure, so the rules are tested without a database; `stats-registry.ts` attaches the readers and the
 * compiler holds the two to the same list of names. One route serves them all --
 * `GET /api/stats/<metric>` -- for the operator panel and the customer portal alike: the session
 * decides which reader answers, and a caller with no reader for a metric gets the same 404 as one
 * asking for a metric that does not exist.
 */

/** The named periods the operator pages offer, shortest first: the last hour is the default. */
export const OPERATOR_RANGES = ["1h", "24h", "7d", "30d"] as const;
/** The portal overview's: whole days, because its chart is by day. */
export const PORTAL_OVERVIEW_RANGES = ["7d", "14d", "30d", "90d"] as const;

export interface Audience {
  /** Periods this reader accepts; empty when it takes none. */
  ranges: readonly string[];
  /** What an absent or unknown period means. One of `ranges`, or "" when there are none. */
  defaultRange: string;
}

export interface MetricSpec {
  /**
   * Reads millions of records at production volume: its answers are kept and shared for a while
   * (`stats-cache.ts`), and a failed read serves the last good one, marked stale.
   */
  heavy?: boolean;
  operator?: Audience;
  /** A customer of the portal: their own accounts only, and never the operator's cost. */
  customer?: Audience & {
    /** Only an account that holds others may see a per-account table. */
    resellersOnly?: boolean;
  };
}

const operatorRanged: Audience = { ranges: OPERATOR_RANGES, defaultRange: "1h" };
const operatorUnranged: Audience = { ranges: [], defaultRange: "" };

export const METRICS = {
  overview: {
    operator: operatorRanged,
    customer: { ranges: PORTAL_OVERVIEW_RANGES, defaultRange: "14d" },
  },
  accounts: {
    operator: operatorRanged,
    customer: { ranges: OPERATOR_RANGES, defaultRange: "1h", resellersOnly: true },
  },
  vendors: { heavy: true, operator: operatorRanged },
  receipts: { heavy: true, operator: operatorRanged },
  revenue: { heavy: true, operator: operatorRanged },
  usage: { heavy: true, operator: operatorRanged },
  //Report > Usage (0.15.1): rows by account × login × product and the window's buckets, and one
  //row's breakdown. Summaries only; kept and shared like the other heavy reads
  "usage-grid": { heavy: true, operator: operatorRanged },
  "usage-breakdown": { heavy: true, operator: operatorRanged },
  traffic: { operator: operatorRanged },
  "revenue-series": { heavy: true, operator: operatorRanged },
  "server-traffic": { operator: { ranges: ["1h", "24h"], defaultRange: "1h" } },
  "traffic-live": { operator: operatorUnranged },
  "archive-accounts": { operator: operatorUnranged },
  "archive-batches": { operator: operatorUnranged },
  "archive-partitions": { operator: operatorUnranged },
} as const satisfies Record<string, MetricSpec>;

export type MetricName = keyof typeof METRICS;
export type Who = "operator" | "customer";

export function isMetric(name: string): name is MetricName {
  return Object.hasOwn(METRICS, name);
}

/** The audience a caller is served as, or null: an unknown metric and a forbidden one look alike. */
export function audienceFor(name: string, who: Who): Audience | null {
  if (!isMetric(name)) {
    return null;
  }
  const spec: MetricSpec = METRICS[name];
  return spec[who] ?? null;
}

/** The period to answer: the one asked for when the reader offers it, else its default. */
export function pickRange(audience: Audience, asked: string | null): string {
  return asked !== null && audience.ranges.includes(asked) ? asked : audience.defaultRange;
}
