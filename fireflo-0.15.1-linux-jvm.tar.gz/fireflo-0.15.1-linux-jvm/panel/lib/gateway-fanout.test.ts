import { test } from "node:test";
import assert from "node:assert/strict";
import { GatewayError, PANEL_CODES } from "./gateway-graphql-core.ts";
import { CALL_MS, PROBE_MS, createCapability, fanOut, peersOf, type FanoutDeps, type FanoutNode } from "./gateway-fanout.ts";
import { normaliseSeries, sumSeries, type LiveSeries } from "./gateway-live-series.ts";

const node = (nodeId: string): FanoutNode => ({ nodeId, opsUrl: `http://${nodeId}:9000` });

function series(nodeId: string, submitted: number, liveSince = "2026-10-30T00:00:00Z"): LiveSeries {
  return normaliseSeries({
    node: nodeId,
    liveSince,
    backfilledThrough: "2026-10-29T00:00:00Z",
    deadlineHours: 24,
    buckets: [
      {
        bucket: "2026-10-30T10:00:00Z",
        keys: { account: "acme", login: null, listener: null, product: null, vendor: null },
        submitted,
        delivered: submitted,
        priceSum: String(submitted * 500),
      },
    ],
  });
}

function deps(over: Partial<FanoutDeps<LiveSeries>> = {}): FanoutDeps<LiveSeries> {
  return {
    local: async () => series("a", 10),
    peers: async () => ({ selfId: "a", nodes: [node("b"), node("c"), node("d")] }),
    probe: async (n) => n.nodeId !== "c",
    call: async (n) => {
      if (n.nodeId === "d") throw new GatewayError(502, PANEL_CODES.unreachable, "timed out");
      return series(n.nodeId, 5);
    },
    ...over,
  };
}

test("every peer that answers is in the sum; one failing its probe and one failing its call are partial", async () => {
  const got = await fanOut(deps());
  assert.deepEqual(got.answers.map((a) => a.node), ["a", "b"]);
  assert.deepEqual(got.partial, ["c", "d"]);
  const sum = sumSeries(got.answers, got.partial);
  assert.equal(sum.buckets.length, 1, "one bucket and key across the nodes");
  assert.equal(sum.buckets[0].submitted, 15);
  assert.equal(sum.buckets[0].delivered, 15);
  assert.equal(sum.buckets[0].priceSum, 7_500, "a Long as a string is summed as a number");
  assert.deepEqual(sum.partial, ["c", "d"]);
  assert.deepEqual(sum.nodes, ["a", "b"]);
});

test("the answering node's failure is the caller's: no cluster figure without it", async () => {
  await assert.rejects(
    fanOut(deps({ local: async () => { throw new GatewayError(502, PANEL_CODES.unreachable, "down"); } })),
    (err: unknown) => err instanceof GatewayError && err.code === PANEL_CODES.unreachable
  );
});

test("no cluster list (or a failing one) is the answering node alone, nothing partial", async () => {
  const got = await fanOut(deps({ peers: async () => { throw new Error("no node_identity"); } }));
  assert.deepEqual(got.answers.map((a) => a.node), ["a"]);
  assert.deepEqual(got.partial, []);
});

test("the answering node is never asked twice, even when the list names it", async () => {
  const asked: string[] = [];
  await fanOut(deps({
    peers: async () => ({ selfId: "a", nodes: [node("a"), node("b")] }),
    call: async (n) => {
      asked.push(n.nodeId);
      return series(n.nodeId, 1);
    },
  }));
  assert.deepEqual(asked, ["b"]);
});

test("peersOf: alive nodes with a management port, not the answering one, trailing slash trimmed", () => {
  const got = peersOf({
    nodeId: "a",
    cluster: {
      mode: "kafka",
      nodes: [
        { nodeId: "a", alive: true, opsUrl: "http://a:9000" },
        { nodeId: "b", alive: true, opsUrl: "http://b:9000/" },
        { nodeId: "c", alive: false, opsUrl: "http://c:9000" },
        { nodeId: "d", alive: true, opsUrl: null },
        { nodeId: "e", alive: true, opsUrl: "  " },
      ],
    },
  });
  assert.equal(got.selfId, "a");
  assert.deepEqual(got.nodes, [{ nodeId: "b", opsUrl: "http://b:9000" }]);
  assert.deepEqual(peersOf(null), { selfId: null, nodes: [] });
});

test("the sum's liveSince is the latest node's, and one node with no backfill makes the cluster's none", () => {
  const a = series("a", 1, "2026-10-30T08:00:00Z");
  const b = { ...series("b", 1, "2026-10-30T09:30:00Z"), backfilledThrough: null };
  const sum = sumSeries([a, b]);
  assert.equal(sum.liveSince, "2026-10-30T09:30:00.000Z");
  assert.equal(sum.backfilledThrough, null);
  assert.equal(sumSeries([a, series("c", 1)]).backfilledThrough, "2026-10-29T00:00:00.000Z");
});

test("timeouts: probe 5 s, call 10 s", () => {
  assert.equal(PROBE_MS, 5_000);
  assert.equal(CALL_MS, 10_000);
});

test("a peer that times out, on its probe or its call, is slow as well as partial; a refusal is partial only", async () => {
  const got = await fanOut(deps({
    peers: async () => ({ selfId: "a", nodes: [node("b"), node("c"), node("d"), node("e")] }),
    probe: async (n) => (n.nodeId === "c" ? "slow" : n.nodeId !== "e"),
    call: async (n) => {
      if (n.nodeId === "d") throw new GatewayError(502, PANEL_CODES.slow, "Node d is slow");
      return series(n.nodeId, 5);
    },
  }));
  assert.deepEqual(got.answers.map((a) => a.node), ["a", "b"]);
  assert.deepEqual(got.partial, ["c", "d", "e"]);
  assert.deepEqual(got.slow, ["c", "d"]);
  const sum = sumSeries(got.answers, got.partial, got.slow);
  assert.deepEqual(sum.slow, ["c", "d"]);
  assert.equal(sumSeries(got.answers, got.partial).slow, undefined, "no slow field when none was slow");
});

test("the main node is never probed: called directly, and skipped in the list by URL when it does not name itself", async () => {
  const probed: string[] = [];
  const called: string[] = [];
  let local = 0;
  const got = await fanOut(deps({
    local: async () => (local++, series("a", 10)),
    //a list from a node with no node id: the main node is in it, under its own URL
    peers: async () => ({ selfId: null, mainUrl: "http://main:9000/", nodes: [{ nodeId: "a", opsUrl: "http://main:9000" }, node("b")] }),
    probe: async (n) => (probed.push(n.nodeId), true),
    call: async (n) => (called.push(n.nodeId), series(n.nodeId, 1)),
  }));
  assert.equal(local, 1);
  assert.deepEqual(probed, ["b"]);
  assert.deepEqual(called, ["b"]);
  assert.deepEqual(got.answers.map((a) => a.node), ["a", "b"]);
});

test("the main node slow: the fan-out fails SLOW, and the caller decides (the live routes keep their last answer)", async () => {
  await assert.rejects(
    fanOut(deps({ local: async () => { throw new GatewayError(502, PANEL_CODES.slow, "The gateway is slow"); } })),
    (err: unknown) => err instanceof GatewayError && err.code === PANEL_CODES.slow
  );
});

test("capability: unknown is a call, an answer is a yes, nothing asked before the call", async () => {
  let asked = 0;
  const cap = createCapability("live_counters", async () => (asked++, { live_counters: true }));
  assert.equal(cap.known(), null);
  assert.equal(await cap.call(async () => 42), 42);
  assert.equal(cap.known(), true);
  assert.equal(asked, 0);
});

test("capability: a refused call asks the map afterwards and keeps the answer; slow or unreachable asks nothing", async () => {
  let t = 0;
  let asked = 0;
  const cap = createCapability("live_counters", async () => (asked++, { live_counters: false }), () => t);
  await assert.rejects(cap.call(async () => { throw new GatewayError(502, PANEL_CODES.slow, "slow"); }));
  await assert.rejects(cap.call(async () => { throw new GatewayError(502, PANEL_CODES.unreachable, "gone"); }));
  assert.equal(asked, 0);
  assert.equal(cap.known(), null, "a slow gateway teaches nothing about the capability");
  assert.equal(cap.recentlyFailed(), true);
  await assert.rejects(cap.call(async () => { throw new GatewayError(400, "BAD_REQUEST", "Field 'liveCounters' undefined"); }));
  assert.equal(asked, 1);
  assert.equal(cap.known(), false);
  t = 30_000;
  assert.equal(cap.known(), null, "kept 30 s, then asked again by the next call");
  assert.equal(cap.recentlyFailed(), false);
});
