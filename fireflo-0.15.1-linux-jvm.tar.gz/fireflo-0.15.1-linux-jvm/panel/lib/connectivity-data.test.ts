import { strict as assert } from "node:assert";
import { test } from "node:test";
import {
  buildMapInput, clientsInWindow, clientsOf, databaseOf, EMPTY_LISTENER_HISTORY, EMPTY_QUEUE_HISTORY, foldListener, foldQueue, nodeQueueOf, routedVendors,
  type MapSources,
} from "./connectivity-data.ts";
import type { Health } from "./health-types.ts";
import type { ConnectivityCounts } from "./connectivity-counts.ts";
import type { HealthSession } from "./health-types.ts";
import type { RouteTable } from "./routing-types.ts";
import type { Worker } from "./worker-types.ts";

const L = "smppserver.dltsmpp";

function session(id: number, account: string, host: string, submitted: number, over: Partial<HealthSession> = {}): HealthSession {
  return { session_id: id, bound: true, account, host, system_id: account.toLowerCase(), submitted, receipts: submitted / 2, ...over };
}

test("two polls give per-client rates, by account or split by IP, from one history", () => {
  const first = [session(1, "ACME", "10.0.0.1", 1000), session(2, "ACME", "10.0.0.2", 0), session(3, "YK", "10.0.0.9", 0)];
  const second = [session(1, "ACME", "10.0.0.1", 1500), session(2, "ACME", "10.0.0.2", 250), session(3, "YK", "10.0.0.9", 50)];
  let h = foldListener(EMPTY_LISTENER_HISTORY, first, 0);
  h = foldListener(h, second, 5000);

  const byAccount = clientsOf(L, second, h, false);
  const acme = byAccount.find((c) => c.account === "ACME")!;
  assert.equal(acme.rate, 150);
  assert.equal(acme.receiptRate, 75);
  assert.equal(acme.binds, 2);
  assert.deepEqual(acme.hosts, ["10.0.0.1", "10.0.0.2"]);
  assert.equal(acme.ip, null);

  const byIp = clientsOf(L, second, h, true);
  assert.equal(byIp.length, 3);
  assert.deepEqual(byIp.filter((c) => c.account === "ACME").map((c) => [c.ip, c.rate]), [["10.0.0.1", 100], ["10.0.0.2", 50]]);
});

test("a throttled account carries its refusal rate once, on its busiest row", () => {
  const rows = [session(1, "ACME", "10.0.0.1", 0, { tps_measured: 90 }), session(2, "ACME", "10.0.0.2", 0, { tps_measured: 10 })];
  const h = foldListener(EMPTY_LISTENER_HISTORY, rows, 0);
  const throttled = new Map([["ACME", 120]]);
  assert.equal(clientsOf(L, rows, h, false, throttled)[0].refusedRate, 2);
  const split = clientsOf(L, rows, h, true, throttled);
  assert.deepEqual(split.map((c) => c.refusedRate), [2, null]);
});

test("routed vendors: enabled rules of enabled tables, through enabled groups", () => {
  const rule = (target: string, enabled = true) => ({ id: 1, target, copied: false, label: null, enabled, conditions: [], filters: [] });
  const tables: RouteTable[] = [
    { name: "main", targetFunction: "NORMAL", label: null, enabled: true, rules: [rule("jio"), rule("off", false), rule("grp")] },
    { name: "dead", targetFunction: "NORMAL", label: null, enabled: false, rules: [rule("never")] },
  ];
  const groups = [{
    name: "grp", policy: "FAILOVER" as const, label: null, enabled: true,
    members: [{ workerName: "a", weight: 1, enabled: true }, { workerName: "b", weight: 1, enabled: false }],
  }];
  const routed = routedVendors(tables, groups);
  assert.ok(routed.has("jio") && routed.has("a"));
  assert.ok(!routed.has("off") && !routed.has("never") && !routed.has("b"));
});

test("the map input: enabled workers only, one node when there is no cluster, rates from the clients", () => {
  const worker = (name: string, type: Worker["type"], enabled = true, properties: Worker["properties"] = []): Worker =>
    ({ name, type, enabled, label: null, properties });
  const input = buildMapInput({
    health: {
      observed_at: "", router_queue: 0, awaiting_receipt: 0, dlr_store_persistent: true, cdr: null, node_id: "n1",
      workers: [
        { name: L, type: "smppserver", accepting: true, paused: false, suspended_manually: false, suspended_automatically: false, bound: 2, queue_depth: 0, retry_queue_depth: 0, tps_measured: 7 },
        { name: "smppclient.jio", type: "smppclient", accepting: true, paused: false, suspended_manually: false, suspended_automatically: false, bound: 1, queue_depth: 0, retry_queue_depth: 0, tps_limit: 500, tps_measured: 40 },
      ],
    },
    workerRates: {},
    servers: [worker("dltsmpp", "smppserver", true, [{ key: "srv.port", value: "22775" }, { key: "pause", value: "true" }]), worker("off", "smppserver", false)],
    vendors: [worker("jio", "smppclient")],
    clients: new Map([[L, [{ key: "ACME", account: "ACME", ip: null, hosts: [], logins: [], listener: L, binds: 2, rate: 120, receiptRate: null, refusedRate: null, ceiling: null, mt: null, dlr: null }]]]),
    backlog: [],
    routed: new Set(["jio"]),
    groups: [],
    kafka: false,
    countsWindow: "bind",
    hour: null,
  });
  assert.deepEqual(input.listeners.map((l) => [l.name, l.port, l.rate, l.held, l.node]), [["dltsmpp", "22775", 120, true, "n1"]]);
  assert.deepEqual(input.nodes.map((n) => n.id), ["n1"]);
  assert.deepEqual(input.vendors.map((v) => [v.name, v.rate, v.tpsLimit, v.bound, v.routed]), [["jio", 40, 500, true, true]]);
  assert.equal(input.clients.length, 1);
});

test("since bind: a client's MT and DLR are its sessions' counters, summed by account or by IP", () => {
  const rows = [
    session(1, "ACME", "10.0.0.1", 1000, { receipts: 900 }),
    session(2, "ACME", "10.0.0.2", 500, { receipts: null }),
    session(3, "YK", "10.0.0.9", 40, { receipts: undefined }),
  ];
  const h = foldListener(EMPTY_LISTENER_HISTORY, rows, 0);
  const byAccount = clientsOf(L, rows, h, false);
  assert.deepEqual(byAccount.find((c) => c.account === "ACME")!.mt, 1500);
  assert.deepEqual(byAccount.find((c) => c.account === "ACME")!.dlr, 900);
  assert.equal(byAccount.find((c) => c.account === "YK")!.dlr, null, "not counted is null, not zero");
  const byIp = clientsOf(L, rows, h, true);
  assert.deepEqual(byIp.filter((c) => c.account === "ACME").map((c) => [c.ip, c.mt, c.dlr]), [["10.0.0.1", 1000, 900], ["10.0.0.2", 500, null]]);
});

test("since bind: a rebind restarts the client's count rather than carrying it", () => {
  let h = foldListener(EMPTY_LISTENER_HISTORY, [session(1, "ACME", "10.0.0.1", 90_000, { receipts: 89_000 })], 0);
  const after = [session(7, "ACME", "10.0.0.1", 120, { receipts: 100 })];
  h = foldListener(h, after, 5000);
  const [acme] = clientsOf(L, after, h, false);
  assert.deepEqual([acme.mt, acme.dlr], [120, 100]);
});

const HOUR: ConnectivityCounts = {
  listeners: [
    { listener: "dltsmpp", account: "ACME", mt: 61_204, dlr: 59_880 },
    { listener: "dltsmpp", account: "YK", mt: 10, dlr: 9 },
  ],
  vendors: [{ vendor: "jio", mt: 50_000, dlr: 49_000 }],
  nodes: ["n1"],
  partial: [],
  liveSince: null,
  skippedBackfill: 0,
  restartedAt: null,
  refusals: [{ listener: "dltsmpp", refused: 18_720, by: [{ reason: "dbUnavailable", count: 14_976 }, { reason: "creditPending", count: 3_744 }] }],
  refusalsMinute: "2026-10-30T12:09:00Z",
};

function sources(over: Partial<MapSources> = {}): MapSources {
  const worker = (name: string, type: Worker["type"]): Worker => ({ name, type, enabled: true, label: null, properties: [] });
  const acme = { key: "ACME", account: "ACME", ip: null, hosts: [], logins: [], listener: L, binds: 2, rate: 120, receiptRate: null, refusedRate: null, ceiling: null, mt: 400, dlr: 390 };
  return {
    health: {
      observed_at: "", router_queue: 0, awaiting_receipt: 0, dlr_store_persistent: true, cdr: null, node_id: "n1",
      workers: [
        { name: L, type: "smppserver", accepting: true, paused: false, suspended_manually: false, suspended_automatically: false, bound: 2, queue_depth: 0, retry_queue_depth: 0, submitted: 777 },
        { name: "smppclient.jio", type: "smppclient", accepting: true, paused: false, suspended_manually: false, suspended_automatically: false, bound: 1, queue_depth: 0, retry_queue_depth: 0, submitted: 395, sessions: [{ bound: true, receipts: null }] },
        { name: "smppclient.otp", type: "smppclient", accepting: true, paused: false, suspended_manually: false, suspended_automatically: false, bound: 1, queue_depth: 0, retry_queue_depth: 0 },
      ],
    },
    workerRates: {},
    servers: [worker("dltsmpp", "smppserver")],
    vendors: [worker("jio", "smppclient"), worker("otp", "smppclient")],
    clients: new Map([[L, [acme]]]),
    backlog: [],
    routed: new Set(),
    groups: [],
    kafka: false,
    countsWindow: "bind",
    hour: null,
    ...over,
  };
}

test("since bind on the map: listeners sum their clients, vendors take the worker's submitted, DLR unknown there", () => {
  const input = buildMapInput(sources());
  assert.equal(input.countsWindow, "bind");
  assert.deepEqual(input.clients.map((c) => [c.mt, c.dlr]), [[400, 390]]);
  assert.deepEqual(input.listeners.map((l) => [l.mt, l.dlr]), [[400, 390]]);
  assert.deepEqual(input.vendors.map((v) => [v.name, v.mt, v.dlr]), [["jio", 395, null], ["otp", null, null]]);
});

test("last hour on the map: the series per listener × account and per vendor; a key it lacks moved nothing", () => {
  const input = buildMapInput(sources({ countsWindow: "hour", hour: HOUR }));
  assert.deepEqual(input.clients.map((c) => [c.account, c.mt, c.dlr]), [["ACME", 61_204, 59_880]]);
  assert.deepEqual(input.listeners.map((l) => [l.mt, l.dlr]), [[61_214, 59_889]]);
  assert.deepEqual(input.vendors.map((v) => [v.name, v.mt, v.dlr]), [["jio", 50_000, 49_000], ["otp", 0, 0]]);
});

test("last hour before the first answer (or with none): every count is unknown, never zero", () => {
  const input = buildMapInput(sources({ countsWindow: "hour", hour: null }));
  assert.deepEqual(input.clients.map((c) => [c.mt, c.dlr]), [[null, null]]);
  assert.deepEqual(input.listeners.map((l) => [l.mt, l.dlr]), [[null, null]]);
  assert.deepEqual(input.vendors.map((v) => [v.mt, v.dlr]), [[null, null], [null, null]]);
});

test("last hour split by IP: the series has no address, so the rows carry none", () => {
  const rows = [{ key: "ACME\u001f10.0.0.1", account: "ACME", ip: "10.0.0.1", hosts: [], logins: [], listener: L, binds: 1, rate: 1, receiptRate: null, refusedRate: null, ceiling: null, mt: 5, dlr: 5 }];
  assert.deepEqual(clientsInWindow(rows, "hour", HOUR).map((c) => [c.mt, c.dlr]), [[null, null]]);
  assert.deepEqual(clientsInWindow(rows, "bind", HOUR).map((c) => [c.mt, c.dlr]), [[5, 5]]);
});

test("a restart inside the hour renames the window on the map and in its tooltips", () => {
  const plain = buildMapInput(sources({ countsWindow: "hour", hour: HOUR }));
  assert.deepEqual([plain.countsLabel, plain.countsNote], ["last hour", null]);
  const restarted = buildMapInput(sources({ countsWindow: "hour", hour: { ...HOUR, skippedBackfill: 3, restartedAt: "2026-10-30T11:20:00Z" } }));
  assert.match(restarted.countsLabel ?? "", /^since restart \d\d:\d\d$/);
  assert.ok(restarted.countsNote);
  assert.equal(buildMapInput(sources()).countsLabel, undefined, "since bind keeps its own name");
});

function snapshot(over: Partial<Health> = {}): Health {
  return { observed_at: "2026-10-30T10:00:00Z", router_queue: 0, awaiting_receipt: 0, dlr_store_persistent: true, cdr: null, node_id: "n1", workers: [], ...over };
}

test("the node's queue from the snapshot: router, lag, retry from both places, persistence summed", () => {
  const q = nodeQueueOf(snapshot({
    router_queue: 9_800,
    routing_retry_queue: 150,
    persist_depth: { cdr: 1_000, dlr: 250, usage: null },
    persist_lag_seconds: 2.4,
    persist_lag_max_seconds: 90,
    backbone: { provider: "kafka", connected: true, routerLag: 2_100, retryDepth: 250 },
  }));
  assert.deepEqual(q, { router: 9_800, lag: 2_100, persist: 1_250, persistLagSeconds: 2.4, retry: 400, persistLagMax: 90 });
});

test("the node's queue: what an older or memory-mode gateway does not say is null, and the line falls back to 60 s", () => {
  assert.equal(nodeQueueOf(null), null);
  assert.deepEqual(nodeQueueOf(snapshot({ router_queue: 3 })), {
    router: 3, lag: null, persist: null, persistLagSeconds: null, retry: null, persistLagMax: 60,
  });
  //the map's answering node gets it; a peer's is not known
  const input = buildMapInput(sources({
    health: snapshot({ router_queue: 7, cluster: { mode: "kafka", nodes: [
      { nodeId: "n1", host: "a", version: "", startedAt: "", heartbeatAt: "", alive: true, opsUrl: null },
      { nodeId: "n2", host: "b", version: "", startedAt: "", heartbeatAt: "", alive: true, opsUrl: null },
    ] } }),
  }));
  assert.deepEqual(input.nodes.map((n) => [n.id, n.queue?.router ?? null]), [["n1", 7], ["n2", null]]);
});

test("the queue history: one sample per snapshot, twelve kept, and the trend on the map", () => {
  let history = EMPTY_QUEUE_HISTORY;
  const at = (i: number) => new Date(Date.parse("2026-10-30T10:00:00Z") + i * 5_000).toISOString();
  for (let i = 0; i < 15; i++) {
    history = foldQueue(history, snapshot({ observed_at: at(i), router_queue: i < 11 ? 0 : (i - 10) * 1_000 }));
  }
  //the same snapshot read twice is one sample
  history = foldQueue(history, snapshot({ observed_at: at(14), router_queue: 4_000 }));
  const kept = history.get("n1")!;
  assert.equal(kept.length, 12);
  assert.deepEqual(kept.slice(-4).map((s) => s.queue), [1_000, 2_000, 3_000, 4_000]);
  const input = buildMapInput(sources({ health: snapshot({ observed_at: at(14), router_queue: 4_000 }), queues: history }));
  assert.deepEqual(input.nodes[0].trend, { rising: true, delta: 4_000, seconds: 20 });
  //no history, no trend
  assert.equal(buildMapInput(sources()).nodes[0].trend, null);
});

test("a route group member found by instance or full name", () => {
  const groups = [{ name: "sim-lb", enabled: true, members: [{ workerName: "jio", enabled: true }, { workerName: "smppclient.otp", enabled: true }] }];
  const input = buildMapInput(sources({ groups }));
  assert.deepEqual(input.vendors.map((v) => [v.name, v.group]), [["jio", "sim-lb"], ["otp", "sim-lb"]]);
});

test("the database: none without a database block or an admission (older gateway, or no database)", () => {
  assert.equal(databaseOf(null, "n1"), null);
  assert.equal(databaseOf(snapshot(), "n1"), null);
  assert.equal(buildMapInput(sources()).database, null);
});

test("the database from an admission alone: a box whose figures are unknown", () => {
  const d = databaseOf(snapshot({ db_admission: "DEGRADED" }), "n1")!;
  assert.equal(d.admission, "DEGRADED");
  assert.deepEqual([d.server, d.probeMs, d.poolActive, d.writeRate, d.logBytes, d.logCapBytes, d.persistDepth], [null, null, null, null, null, null, null]);
});

test("the database from the block and the snapshot: where, pool, lanes, writes, persistence, log, refusals", () => {
  const d = databaseOf(snapshot({
    database: {
      host: "db.internal", ip: "10.128.0.2", port: 5432, name: "fireflo", server_version: "18.6", schema_version: "1.122.0",
      connected_since: "2026-10-30T09:42:17Z", pool: { max: 16, active: 3, idle: 13, waiting: 0 },
      lanes: { lease: { max: 2, active: 1 }, control: { max: 2, active: 0 } }, probe_ms: 12, pool_wait_ms: 1,
    },
    db_latency_ms: 99,
    db_admission: "REFUSING",
    db_admission_reason: "logCap",
    db_write_rate: 1840.4,
    db_refused_total: 4_812,
    persist_depth: { cdr: 1_000, dlr: 250, unpushed: null },
    persist_lag_seconds: 2.4,
    persist_log_bytes: 1_288_490_189,
    persist_log_healthy: true,
  }), "n1")!;
  assert.deepEqual(d, {
    node: "n1", server: "db.internal (10.128.0.2):5432", name: "fireflo", version: "18.6", schema: "1.122.0",
    connectedSince: "2026-10-30T09:42:17Z", admission: "REFUSING", reason: "logCap", probeMs: 12, poolActive: 3, poolMax: 16,
    poolWaitMs: 1, lanes: "lease 1/2 · control 0/2", writeRate: 1840.4, persistDepth: 1_250, persistLagSeconds: 2.4,
    logBytes: 1_288_490_189, logCapBytes: null, logHealthy: true, refusedTotal: 4_812,
  });
  //the probe and the pool wait fall back to the latency monitor's own readings; the cap, when published, is in bytes
  const fallback = databaseOf(snapshot({ db_admission: "OK", db_latency_ms: 40, db_pool_wait_ms: 3, persist_log_max_mb: 8192 }), "n1")!;
  assert.deepEqual([fallback.probeMs, fallback.poolWaitMs, fallback.logCapBytes], [40, 3, 8192 * 1024 * 1024]);
  //on the map, beside the answering node
  assert.equal(buildMapInput(sources({ health: snapshot({ db_admission: "OK" }) })).database?.node, "n1");
});

test("each listener's refusals over the last full minute, by instance name, in either counts window", () => {
  for (const countsWindow of ["hour", "bind"] as const) {
    const input = buildMapInput(sources({ countsWindow, hour: HOUR }));
    assert.deepEqual(input.listeners[0].refused, {
      rate: 312, total: 18_720, by: [{ reason: "dbUnavailable", count: 14_976 }, { reason: "creditPending", count: 3_744 }],
    });
  }
  assert.equal(buildMapInput(sources({ hour: null })).listeners[0].refused, null);
});
