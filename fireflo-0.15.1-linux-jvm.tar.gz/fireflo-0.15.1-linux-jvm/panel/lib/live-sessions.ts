import { accountOfKey } from "./session-groups.ts";

/**
 * Live submit rates per client of one listener: `lib/live-rates.ts`, generalised from workers to
 * account × login.
 *
 * <h2>Where the numbers come from</h2>
 *
 * <p>The listener Status tab reads the operator `sessions` query every five seconds and folds the
 * rows by account and login (`groupByLogin`). Each group carries the summed `submitted` counter of its
 * sessions -- submit_sm received since each bind -- so two readings of it are a rate, exactly as two
 * readings of a worker's counter are in `appendRates`. Nothing is read from the database and nothing
 * is stored: the history lives in the tab and starts when it was opened.
 *
 * <h2>When a delta is not a rate</h2>
 *
 * <p>A counter restarts at zero when its session rebinds, and a login's sum changes membership when a
 * bind comes or goes. Either way the difference between two readings is not traffic: a <b>drop</b>
 * would read as a negative rate, and a new member's whole lifetime count as a spike. So a key whose
 * counter fell, or whose sessions are not the same ones as last time, takes the gateway's own
 * `tps_measured` for that poll, and is a gap when the gateway measured nothing either. The first
 * reading of a key is a baseline and takes the same fallback.
 *
 * <h2>How long it is kept</h2>
 *
 * <p>An hour, at two resolutions: the last fifteen minutes at the poll's own five seconds, anything
 * older merged into ten-second buckets (the mean of the readings in each). The 5 min and 15 min
 * windows draw the fine samples; the hour draws ten-second points throughout, so its line is one
 * resolution end to end.
 *
 * <h2>Counts since bind</h2>
 *
 * <p>The same readings say how much each key has moved, not only how fast: the summed `submitted`
 * and, when the reading carries it, the summed `receipts` (deliver_sm sent back down) of its
 * sessions, as of the newest poll. That is "since bind" on the Connectivity map. A rebind restarts a
 * session's counter, so a key's count can fall -- it then restarts from the lower figure, never
 * carried across the bind and never below zero; a key absent from the poll has no count.
 *
 * <p>Pure, so the fold is tested against arrays of readings rather than through a rendered chart.
 */

/** How far back the history reaches: the longest window the chart offers. */
export const LIVE_SESSION_HISTORY_MS = 60 * 60_000;
/** How far back samples stay at the poll's own resolution. */
export const LIVE_SESSION_FINE_MS = 15 * 60_000;
/** The bucket older samples are merged into, and the hour window is drawn at. */
export const LIVE_SESSION_COARSE_MS = 10_000;

/** One key's reading on one poll: a `LoginGroup` reduced to what the fold needs. */
export interface SessionReading {
  key: string;
  /** Summed submit_sm since each bind; null when none of the sessions counts. */
  submitted: number | null;
  /** The gateway's own measured rate, summed: the fallback. */
  tps: number | null;
  /** Which sessions the sum is over (`LoginGroup.members`). */
  members: string;
  /** Summed deliver_sm sent back down since each bind; null or absent when none of the sessions counts. */
  receipts?: number | null;
}

/** One key's counters as of the newest poll: what it has moved since its sessions bound. */
export interface SessionCounts {
  /** submit_sm received; null when not counted. */
  submitted: number | null;
  /** deliver_sm sent back down (receipts and inbound); null when not counted. */
  receipts: number | null;
}

/** One poll: when it arrived, and each key's rate over the poll before it. */
export interface LiveSessionSample {
  t: number;
  /** Messages per second by key; `null` where nothing could be measured. */
  rates: Readonly<Record<string, number | null>>;
}

export interface LiveSessionHistory {
  readonly samples: readonly LiveSessionSample[];
  /** Each key's last counter, the baseline the next delta is taken from. */
  readonly last: Readonly<Record<string, { at: number; submitted: number; members: string }>>;
  /** Each key present in the newest poll, with its counters since bind. */
  readonly counts: Readonly<Record<string, SessionCounts>>;
}

export const EMPTY_LIVE_SESSIONS: LiveSessionHistory = { samples: [], last: {}, counts: {} };

/** A counter as a count: null stays null, anything else is a whole number at or above zero. */
function count(v: number | null | undefined): number | null {
  return v == null || !Number.isFinite(v) ? null : Math.max(0, Math.round(v));
}

/** Fold one poll's readings into the history. */
export function foldSessions(
  previous: LiveSessionHistory,
  readings: readonly SessionReading[],
  now: number
): LiveSessionHistory {
  const rates: Record<string, number | null> = {};
  const last: Record<string, { at: number; submitted: number; members: string }> = {};
  const counts: Record<string, SessionCounts> = {};
  for (const reading of readings) {
    counts[reading.key] = { submitted: count(reading.submitted), receipts: count(reading.receipts) };
    const before = previous.last[reading.key];
    let rate: number | null = null;
    if (
      reading.submitted != null
      && before
      && before.members === reading.members
      && reading.submitted >= before.submitted
      && now > before.at
    ) {
      rate = ((reading.submitted - before.submitted) * 1000) / (now - before.at);
    } else if (reading.tps != null) {
      rate = reading.tps;
    }
    rates[reading.key] = rate;
    if (reading.submitted != null) {
      last[reading.key] = { at: now, submitted: reading.submitted, members: reading.members };
    }
  }
  //a key absent from this poll has unbound: its baseline goes with it, so a login that comes back
  //starts from a fresh baseline rather than a delta across the time it was away
  return {
    samples: thin([...previous.samples, { t: now, rates }], now),
    last,
    counts,
  };
}

/**
 * Drop what is older than the history, and merge what is older than the fine window into
 * ten-second buckets.
 */
export function thin(samples: readonly LiveSessionSample[], now: number): LiveSessionSample[] {
  const floor = now - LIVE_SESSION_HISTORY_MS;
  const fine = now - LIVE_SESSION_FINE_MS;
  const coarse = samples.filter((s) => s.t >= floor && s.t < fine);
  return [...mergeBuckets(coarse, LIVE_SESSION_COARSE_MS), ...samples.filter((s) => s.t >= fine)];
}

/**
 * Samples merged into buckets of `stepMs`: one per bucket, timed at the bucket's start so the points
 * are evenly spaced even while the newest bucket is still filling, each key the mean of the readings
 * that measured it (a key no reading measured stays null).
 */
export function mergeBuckets(samples: readonly LiveSessionSample[], stepMs: number): LiveSessionSample[] {
  const buckets = new Map<number, LiveSessionSample[]>();
  for (const sample of samples) {
    const b = Math.floor(sample.t / stepMs);
    const list = buckets.get(b);
    if (list) {
      list.push(sample);
    } else {
      buckets.set(b, [sample]);
    }
  }
  return [...buckets.entries()]
    .sort(([a], [b]) => a - b)
    .map(([bucket, list]) => {
      const t = bucket * stepMs;
      if (list.length === 1) {
        return { t, rates: list[0].rates };
      }
      const sums: Record<string, { total: number; n: number }> = {};
      const keys = new Set<string>();
      for (const sample of list) {
        for (const [key, rate] of Object.entries(sample.rates)) {
          keys.add(key);
          if (rate != null) {
            const acc = (sums[key] ??= { total: 0, n: 0 });
            acc.total += rate;
            acc.n += 1;
          }
        }
      }
      const rates: Record<string, number | null> = {};
      for (const key of keys) {
        rates[key] = sums[key] ? sums[key].total / sums[key].n : null;
      }
      return { t, rates };
    });
}

/** The windows the chart offers, and the resolution each is drawn at. */
export const LIVE_WINDOWS = {
  "5m": { ms: 5 * 60_000, stepMs: null },
  "15m": { ms: 15 * 60_000, stepMs: null },
  "1h": { ms: 60 * 60_000, stepMs: LIVE_SESSION_COARSE_MS },
} as const;

export type LiveWindow = keyof typeof LIVE_WINDOWS;

/** How the lines are cut: one per account, one per login, or the listener's total. */
export type LiveSplit = "account" | "login" | "total";

/** The series key of the listener total. */
export const TOTAL_SERIES = "total";

/**
 * The samples a window draws: those inside it, at its resolution.
 *
 * @param keep which keys count at all -- one account picked, say; every key when omitted
 */
export function windowSamples(
  history: LiveSessionHistory,
  window: LiveWindow,
  now: number,
  keep?: (key: string) => boolean
): LiveSessionSample[] {
  const { ms, stepMs } = LIVE_WINDOWS[window];
  const inside = history.samples
    .filter((s) => s.t >= now - ms)
    .map((s) => (keep ? { t: s.t, rates: pick(s.rates, keep) } : s));
  return stepMs ? mergeBuckets(inside, stepMs) : inside;
}

function pick(rates: Readonly<Record<string, number | null>>, keep: (key: string) => boolean) {
  const out: Record<string, number | null> = {};
  for (const [key, rate] of Object.entries(rates)) {
    if (keep(key)) {
      out[key] = rate;
    }
  }
  return out;
}

/**
 * One sample's rates cut by `split`: per login (the keys themselves), summed per account, or summed
 * to one total. A sum is null only when none of its keys measured anything -- a line at zero for
 * "nothing measured" would claim an idle client.
 */
export function splitRates(rates: Readonly<Record<string, number | null>>, split: LiveSplit): Record<string, number | null> {
  if (split === "login") {
    return { ...rates };
  }
  const out: Record<string, number | null> = {};
  for (const [key, rate] of Object.entries(rates)) {
    const series = split === "account" ? accountOfKey(key) : TOTAL_SERIES;
    if (!(series in out)) {
      out[series] = null;
    }
    if (rate != null) {
      out[series] = (out[series] ?? 0) + rate;
    }
  }
  return out;
}

/** One chart row: the time, and a rate per series. */
export type LivePoint = { t: number } & Record<string, number | null>;

/**
 * The window as chart rows, with the series ordered busiest first by their peak in it, so the
 * colours land on the same clients poll after poll and a cap keeps the busiest.
 */
export function chartRows(
  samples: readonly LiveSessionSample[],
  split: LiveSplit
): { points: LivePoint[]; series: string[] } {
  const peaks = new Map<string, number>();
  const points = samples.map((s) => {
    const rates = splitRates(s.rates, split);
    for (const [series, rate] of Object.entries(rates)) {
      peaks.set(series, Math.max(peaks.get(series) ?? 0, rate ?? 0));
    }
    return { ...rates, t: s.t } as LivePoint;
  });
  const series = [...peaks.entries()]
    .sort(([a, pa], [b, pb]) => pb - pa || a.localeCompare(b))
    .map(([name]) => name);
  return { points, series };
}

/** The highest listener total in the samples; null when nothing was measured. */
export function peakTotal(samples: readonly LiveSessionSample[]): number | null {
  let peak: number | null = null;
  for (const sample of samples) {
    const total = splitRates(sample.rates, "total")[TOTAL_SERIES];
    if (total != null && (peak == null || total > peak)) {
      peak = total;
    }
  }
  return peak;
}

/** Each account's summed rate in one sample: what an account ceiling is measured against. */
export function accountRates(sample: LiveSessionSample | undefined): Record<string, number | null> {
  return sample ? splitRates(sample.rates, "account") : {};
}

/**
 * What the keys `keep` selects have moved since bind, summed: one client box's MT and DLR. A sum is
 * null only when none of its keys counts, as the rates are.
 */
export function sumCounts(history: LiveSessionHistory, keep: (key: string) => boolean): SessionCounts {
  let submitted: number | null = null;
  let receipts: number | null = null;
  for (const [key, c] of Object.entries(history.counts)) {
    if (!keep(key)) {
      continue;
    }
    if (c.submitted != null) {
      submitted = (submitted ?? 0) + c.submitted;
    }
    if (c.receipts != null) {
      receipts = (receipts ?? 0) + c.receipts;
    }
  }
  return { submitted, receipts };
}
