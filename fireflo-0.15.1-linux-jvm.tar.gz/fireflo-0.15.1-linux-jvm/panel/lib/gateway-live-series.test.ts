import { test } from "node:test";
import assert from "node:assert/strict";
import {
  failureReasons,
  fromSeam,
  groupingProblem,
  inWindow,
  mergeAccountActivity,
  mergeServerTraffic,
  mergeTraffic,
  mergeVendors,
  normaliseFailures,
  normaliseReceiptQuality,
  normaliseSeries,
  spliceFrom,
  sumSeries,
  sumFailures,
  sumReceiptQuality,
  toAccountActivity,
  toFailureRows,
  toReceipts,
  toRevenueRows,
  toRevenueSeries,
  toServerTraffic,
  toTraffic,
  toUsageGrid,
  toVendors,
  withBalances,
  type ConvertContext,
  type LiveBucket,
  type LiveKeys,
} from "./gateway-live-series.ts";

const NOW = new Date("2026-10-30T12:02:00Z");
const NONE: LiveKeys = { account: null, login: null, listener: null, product: null, vendor: null };

function b(bucket: string, keys: Partial<LiveKeys>, n: Partial<LiveBucket> = {}): LiveBucket {
  return {
    bucket,
    keys: { ...NONE, ...keys },
    submitted: 0,
    refused: 0,
    refusedBy: [],
    priceSum: 0,
    costSum: 0,
    attempts: null,
    sent: 0,
    vendorRefused: 0,
    delivered: 0,
    failed: 0,
    expired: 0,
    pending: 0,
    backfilled: false,
    ...n,
  };
}

const H24: ConvertContext = { range: "24h", now: NOW, deadlineHours: 24 };
const H1: ConvertContext = { range: "1h", now: NOW, deadlineHours: 24 };

test("normaliseSeries: numbers from Long strings, empty keys as none, labels to the second, bad buckets dropped", () => {
  const s = normaliseSeries({
    node: "n1",
    liveSince: "2026-10-30T08:00:00.123Z",
    backfilledThrough: null,
    deadlineHours: "48",
    buckets: [
      { bucket: "2026-10-30T11:00:00.000Z", keys: { account: "acme", login: "", vendor: null }, submitted: "12", priceSum: "60000", pending: -3 },
      { bucket: "not a time", keys: {}, submitted: 1 },
      null,
    ],
  });
  assert.equal(s.node, "n1");
  assert.equal(s.deadlineHours, 48);
  assert.equal(s.backfilledThrough, null);
  assert.equal(s.buckets.length, 1);
  assert.equal(s.buckets[0].bucket, "2026-10-30T11:00:00Z");
  assert.deepEqual(s.buckets[0].keys, { account: "acme", login: null, listener: null, product: null, vendor: null });
  assert.equal(s.buckets[0].submitted, 12);
  assert.equal(s.buckets[0].priceSum, 60_000);
  assert.equal(s.buckets[0].pending, 0, "a negative pending is clamped");
  assert.deepEqual(normaliseSeries(null).buckets, []);
});

test("toTraffic: keys summed per bucket in time order; pending past the deadline is expired", () => {
  const rows = toTraffic(
    [
      b("2026-10-30T11:00:00Z", { account: "a" }, { submitted: 10, delivered: 6, failed: 1, pending: 3 }),
      b("2026-10-30T11:00:00Z", { account: "b" }, { submitted: 5, delivered: 5 }),
      b("2026-10-30T09:00:00Z", { account: "a" }, { submitted: 4, delivered: 1, pending: 3 }),
    ],
    { ...H24, deadlineHours: 2 }
  );
  assert.deepEqual(rows, [
    //09:00-10:00 ends before 12:02 - 2 h: its pending is what the sweeper expired
    { bucket: "2026-10-30T09:00:00Z", submitted: 4, delivered: 1, failed: 0, expired: 3, pending: 0 },
    //11:00-12:00 ends after 10:02: still pending
    { bucket: "2026-10-30T11:00:00Z", submitted: 15, delivered: 11, failed: 1, expired: 0, pending: 3 },
  ]);
});

test("toRevenueRows: messages are submitted less vendor-refused, margin from the sums, heaviest first", () => {
  const rows = toRevenueRows([
    b("2026-10-30T11:00:00Z", { account: "a", product: "p" }, { submitted: 10, vendorRefused: 2, priceSum: 8_000, costSum: 3_000 }),
    b("2026-10-30T12:00:00Z", { account: "a", product: "p" }, { submitted: 1, priceSum: 1_000, costSum: 500 }),
    b("2026-10-30T12:00:00Z", { account: "b", product: null }, { submitted: 50, priceSum: 50_000, costSum: 60_000 }),
  ]);
  assert.deepEqual(rows, [
    { accountId: "b", product: null, messages: 50, revenue: 50_000, cost: 60_000, margin: -10_000, pendingRevenue: 0 },
    { accountId: "a", product: "p", messages: 9, revenue: 9_000, cost: 3_500, margin: 5_500, pendingRevenue: 0 },
  ]);
});

test("toRevenueSeries: per bucket, the same arithmetic", () => {
  assert.deepEqual(
    toRevenueSeries([
      b("2026-10-30T12:00:00Z", { account: "a" }, { submitted: 3, vendorRefused: 1, priceSum: 30, costSum: 10 }),
      b("2026-10-30T11:55:00Z", { account: "b" }, { submitted: 1, priceSum: 10, costSum: 5 }),
      b("2026-10-30T12:00:00Z", { account: "b" }, { submitted: 2, priceSum: 20, costSum: 5 }),
    ]),
    [
      { bucket: "2026-10-30T11:55:00Z", messages: 1, revenue: 10, cost: 5 },
      { bucket: "2026-10-30T12:00:00Z", messages: 4, revenue: 50, cost: 15 },
    ]
  );
});

test("toVendors: a vendor series' attempts and representative messages; failed includes the gateway's expired and the deadline's", () => {
  const rows = toVendors(
    [
      b("2026-10-30T11:00:00Z", { vendor: "smppclient.v1" }, { attempts: 14, submitted: 12, sent: 11, vendorRefused: 1, delivered: 7, failed: 1, expired: 1, pending: 2, costSum: 900 }),
      b("2026-10-30T08:00:00Z", { vendor: "smppclient.v1" }, { attempts: 3, submitted: 3, sent: 3, delivered: 1, pending: 2 }),
      b("2026-10-30T11:00:00Z", { vendor: "smppclient.v2" }, { attempts: 1, submitted: 1, sent: 1, pending: 1 }),
      b("2026-10-30T11:00:00Z", {}, {}),
    ],
    { ...H24, deadlineHours: 3 }
  );
  assert.deepEqual(rows, [
    //08:00 is past the 3 h deadline: its 2 pending are what the sweeper closed
    { vendor: "smppclient.v1", attempts: 17, messages: 15, delivered: 8, failed: 4, pending: 2, cost: 900, deliveryRate: 8 / 12 },
    { vendor: "smppclient.v2", attempts: 1, messages: 1, delivered: 0, failed: 0, pending: 1, cost: 0, deliveryRate: null },
  ]);
  //split by account, and attempts falling back to sent where a series carries none
  const split = toVendors([b("2026-10-30T11:00:00Z", { vendor: "v", account: "a" }, { submitted: 2, sent: 2, delivered: 2 })], H24, true);
  assert.deepEqual(split.map((r) => [r.vendor, r.account, r.attempts, r.messages]), [["v", "a", 2, 2]]);
});

test("accounts: activity by account, login and product, balances added, configured-but-silent credentials idle", () => {
  const activity = toAccountActivity(
    [
      b("2026-10-30T10:00:00Z", { account: "a", login: "a1", product: "p" }, { submitted: 4, delivered: 3, failed: 1, priceSum: 400, costSum: 100 }),
      b("2026-10-30T11:00:00Z", { account: "a", login: "a1", product: "p" }, { submitted: 2, pending: 2, priceSum: 200, costSum: 50 }),
      b("2026-10-30T11:00:00Z", { account: "b", login: "b1", product: null }, {}),
    ],
    H24
  );
  assert.deepEqual(activity, [
    {
      accountId: "a", systemId: "a1", product: "p", messages: 6, delivered: 3, failed: 1, pending: 2,
      billed: 600, cost: 150, deliveryRate: 0.75, lastSeen: "2026-10-30T11:00:00Z",
    },
  ]);
  const view = withBalances(
    activity,
    [
      { accountId: "a", systemId: "a1", product: "p" },
      { accountId: "a", systemId: "a2", product: "p" },
    ],
    new Map([["a", { balance: 123_0000, currency: "AUD" }]])
  );
  assert.equal(view.creditEnforced, true);
  assert.equal(view.accounts.length, 2);
  assert.equal(view.accounts[0].balance, 123_0000);
  assert.equal(view.accounts[0].currency, "AUD");
  assert.equal(view.accounts[0].idle, false);
  assert.equal(view.accounts[1].systemId, "a2");
  assert.equal(view.accounts[1].idle, true);
  assert.equal(view.accounts[1].balance, 123_0000);
  assert.equal(withBalances([], [], new Map()).creditEnforced, false);
});

test("toServerTraffic: one listener (bare or prefixed), by account, top N, totals over all; reported excludes expired", () => {
  const view = toServerTraffic(
    [
      b("2026-10-30T11:00:00Z", { listener: "smppserver.main", account: "a" }, { submitted: 10, delivered: 7, failed: 2, pending: 1 }),
      b("2026-10-30T11:00:00Z", { listener: "main", account: "b" }, { submitted: 20, delivered: 20 }),
      b("2026-10-30T11:00:00Z", { listener: "main", account: "c" }, { submitted: 1, failed: 1 }),
      b("2026-10-30T11:00:00Z", { listener: "smppserver.other", account: "a" }, { submitted: 99 }),
      b("2026-10-30T08:00:00Z", { listener: "main", account: "a" }, { submitted: 2, pending: 2 }),
    ],
    "main",
    { ...H24, deadlineHours: 3 },
    2
  );
  assert.equal(view.range, "24h");
  assert.deepEqual(view.rows, [
    { accountId: "b", messages: 20, delivered: 20, failed: 0, expired: 0, pending: 0 },
    { accountId: "a", messages: 12, delivered: 7, failed: 2, expired: 2, pending: 1 },
  ]);
  assert.deepEqual(view.totals, { messages: 33, delivered: 27, reported: 30 });
});

test("toReceipts: one object per node flattened, attempts as sent, seconds as given, deadline expiries taken out of open", () => {
  const quality = [
    ...normaliseReceiptQuality({
      node: "n1", liveSince: "2026-10-30T00:00:00Z", backfilledThrough: null, from: "x", until: "y",
      vendors: [
        { vendor: "v1", attempts: 10, accepted: 9, refused: 1, reported: 6, delivered: 5, failed: 1, expired: 1, open: 2, medianToOutcome: 2, p90ToOutcome: 9 },
        { vendor: "v2", attempts: 30, accepted: 30, refused: 0, reported: 0, delivered: 0, failed: 0, expired: 0, open: 30, medianToOutcome: null, p90ToOutcome: null },
      ],
    }),
    ...normaliseReceiptQuality({
      node: "n2",
      vendors: [{ vendor: "v1", attempts: "10", accepted: 10, refused: 0, reported: 2, delivered: 2, failed: 0, expired: 0, open: 8, medianToOutcome: 6.0, p90ToOutcome: 13.0 }],
    }),
  ];
  assert.equal(quality.length, 3);
  assert.equal(quality[2].node, "n2");
  assert.equal(quality[2].sent, 10);
  assert.deepEqual(normaliseReceiptQuality([]), [], "not the object: nothing");
  const rows = toReceipts(
    quality,
    [b("2026-10-30T08:00:00Z", { vendor: "v1" }, { pending: 3 }), b("2026-10-30T11:00:00Z", { vendor: "v1" }, { pending: 9 })],
    { ...H24, deadlineHours: 3 }
  );
  assert.equal(rows[0].vendor, "v2");
  assert.equal(rows[0].medianToOutcome, null);
  const v1 = rows[1];
  assert.equal(v1.sent, 20);
  assert.equal(v1.reported, 8);
  assert.equal(v1.expired, 1 + 3, "the gateway's own expired, plus the deadline's");
  assert.equal(v1.open, 10 - 3);
  assert.equal(v1.delivered, 7);
  //weighted by outcomes seen: (2 s x 6 + 6 s x 2) / 8
  assert.equal(v1.medianToOutcome, 3);
  assert.equal(v1.p90ToOutcome, 10);
  assert.equal(v1.progressReceipts, null);
  assert.equal(v1.sampled, null);
  assert.equal(sumReceiptQuality([]).length, 0);
});

test("toUsageGrid: every hour of the window, zeros included; rows heaviest first, none last, paged", () => {
  const view = toUsageGrid(
    [
      b("2026-10-30T11:00:00Z", { account: "a", login: "a1", product: "p" }, { submitted: 3, delivered: 2, pending: 1, priceSum: 30 }),
      b("2026-10-30T12:00:00Z", { account: null, login: null, product: null }, { submitted: 3, failed: 3 }),
      b("2026-10-30T12:00:00Z", { account: "b", login: null, product: null }, { submitted: 9, delivered: 9, priceSum: 90 }),
    ],
    H1,
    0
  );
  assert.equal(view.grain, "hour");
  assert.equal(view.since, "2026-10-30T11:02:00.000Z");
  assert.equal(view.until, NOW.toISOString());
  assert.deepEqual(view.series.map((s) => [s.bucket, s.submitted]), [
    ["2026-10-30T11:00:00Z", 3],
    ["2026-10-30T12:00:00Z", 12],
  ]);
  assert.deepEqual(view.rows.map((r) => r.accountId), ["b", "a", null]);
  assert.equal(view.totalRows, 3);
  assert.equal(view.rows[1].pending, 1);
  assert.equal(view.rows[2].failed, 3);
  assert.deepEqual(view.logins, { daily: true, hourly: true });
  assert.equal(toUsageGrid([], H1, 1).rows.length, 0);
});

test("inWindow keeps the buckets overlapping [now - range, now), as the SQL's partial first bucket", () => {
  const kept = inWindow(
    [b("2026-10-30T10:55:00Z", {}), b("2026-10-30T11:00:00Z", {}), b("2026-10-30T12:00:00Z", {}), b("2026-10-30T12:05:00Z", {})],
    H1
  );
  assert.deepEqual(kept.map((k) => k.bucket), ["2026-10-30T11:00:00Z", "2026-10-30T12:00:00Z"]);
});

test("spliceFrom: none with a backfill or a start before the window; else the next whole bucket after the start", () => {
  const started = "2026-10-30T09:20:00.000Z";
  assert.equal(spliceFrom({ liveSince: started, backfilledThrough: "2026-10-30T09:00:00Z" }, "24h", NOW), null);
  assert.equal(spliceFrom({ liveSince: null, backfilledThrough: null }, "24h", NOW), null);
  assert.equal(spliceFrom({ liveSince: "2026-10-29T08:00:00Z", backfilledThrough: null }, "24h", NOW), null);
  assert.equal(spliceFrom({ liveSince: started, backfilledThrough: null }, "24h", NOW)?.toISOString(), "2026-10-30T10:00:00.000Z");
  assert.equal(spliceFrom({ liveSince: started, backfilledThrough: null }, "1h", NOW), null, "started before the hour");
  assert.equal(
    spliceFrom({ liveSince: "2026-10-30T11:31:10Z", backfilledThrough: null }, "1h", NOW)?.toISOString(),
    "2026-10-30T11:35:00.000Z"
  );
  //started inside the current bucket: the database serves all of it, up to now
  assert.equal(spliceFrom({ liveSince: "2026-10-30T12:01:00Z", backfilledThrough: null }, "1h", NOW)?.toISOString(), NOW.toISOString());
  const seam = new Date("2026-10-30T10:00:00Z");
  assert.deepEqual(fromSeam([b("2026-10-30T09:00:00Z", {}), b("2026-10-30T10:00:00Z", {})], seam).map((x) => x.bucket), ["2026-10-30T10:00:00Z"]);
});

test("merges: database buckets and rows before the seam joined to the series', summed where they meet", () => {
  assert.deepEqual(
    mergeTraffic(
      [{ bucket: "2026-10-30T09:00:00Z", submitted: 1, delivered: 1, failed: 0, expired: 0, pending: 0 }],
      [
        { bucket: "2026-10-30T09:00:00Z", submitted: 2, delivered: 0, failed: 1, expired: 0, pending: 1 },
        { bucket: "2026-10-30T10:00:00Z", submitted: 5, delivered: 5, failed: 0, expired: 0, pending: 0 },
      ]
    ),
    [
      { bucket: "2026-10-30T09:00:00Z", submitted: 3, delivered: 1, failed: 1, expired: 0, pending: 1 },
      { bucket: "2026-10-30T10:00:00Z", submitted: 5, delivered: 5, failed: 0, expired: 0, pending: 0 },
    ]
  );
  const v = mergeVendors(
    [{ vendor: "v", attempts: 2, messages: 2, delivered: 1, failed: 1, pending: 0, cost: 10, deliveryRate: 0.5 }],
    [{ vendor: "v", attempts: 3, messages: 3, delivered: 3, failed: 0, pending: 0, cost: 20, deliveryRate: 1 }]
  );
  assert.deepEqual(v, [{ vendor: "v", attempts: 5, messages: 5, delivered: 4, failed: 1, pending: 0, cost: 30, deliveryRate: 0.8 }]);
  const a = mergeAccountActivity(
    [{ accountId: "a", systemId: "x", product: null, messages: 1, delivered: 1, failed: 0, pending: 0, billed: 5, cost: 1, deliveryRate: 1, lastSeen: "2026-10-30T09:59:00Z" }],
    [{ accountId: "a", systemId: "x", product: null, messages: 1, delivered: 0, failed: 1, pending: 0, billed: 5, cost: 1, deliveryRate: 0, lastSeen: "2026-10-30T11:00:00Z" }]
  );
  assert.equal(a.length, 1);
  assert.equal(a[0].messages, 2);
  assert.equal(a[0].deliveryRate, 0.5);
  assert.equal(a[0].lastSeen, "2026-10-30T11:00:00Z");
  const s = mergeServerTraffic(
    { range: "24h", rows: [{ accountId: "a", messages: 1, delivered: 1, failed: 0, expired: 0, pending: 0 }], totals: { messages: 4, delivered: 3, reported: 3 } },
    { range: "24h", rows: [{ accountId: "a", messages: 2, delivered: 2, failed: 0, expired: 0, pending: 0 }], totals: { messages: 2, delivered: 2, reported: 2 } },
    50
  );
  assert.deepEqual(s.rows, [{ accountId: "a", messages: 3, delivered: 3, failed: 0, expired: 0, pending: 0 }]);
  assert.deepEqual(s.totals, { messages: 6, delivered: 5, reported: 5 });
});

test("failures: normalised, summed across nodes by key (messages added, newest lastSeen), then per account and per reason", () => {
  const n1 = normaliseFailures([
    { node: "n1", account: "acme", vendor: "v1", finalState: "FAILED", dlrState: "2", errCode: "0x0b", vendorErrCode: "11", messages: "3", lastSeen: "2026-10-30T10:00:00Z" },
    { node: "n1", account: "acme", vendor: "v2", finalState: "FAILED", dlrState: 2, errCode: "0x0b", vendorErrCode: "", messages: 1, lastSeen: "2026-10-30T09:00:00Z" },
    { node: "n1", account: "", vendor: null, finalState: "REJECTED", dlrState: null, errCode: null, vendorErrCode: null, messages: 2, lastSeen: "2026-10-30T08:00:00Z" },
    { node: "n1", account: "acme", finalState: "", messages: 9, lastSeen: "2026-10-30T08:00:00Z" },
    { node: "n1", account: "acme", finalState: "FAILED", messages: 9, lastSeen: "nope" },
  ]);
  assert.equal(n1.length, 3, "rows with no state or no instant are dropped");
  assert.equal(n1[0].dlrState, 2);
  assert.equal(n1[0].messages, 3);
  assert.equal(n1[1].vendorErrCode, null);
  assert.equal(n1[2].account, null);
  const n2 = normaliseFailures([
    { node: "n2", account: "acme", vendor: "v1", finalState: "FAILED", dlrState: 2, errCode: "0x0b", vendorErrCode: "11", messages: 4, lastSeen: "2026-10-30T11:30:00Z" },
  ]);
  const summed = sumFailures([...n1, ...n2]);
  assert.equal(summed.length, 3);
  assert.equal(summed[0].messages, 7, "the same key on two nodes is one row");
  assert.equal(summed[0].lastSeen, "2026-10-30T11:30:00.000Z");

  //vendor and carrier code kept for the ring's deeper levels; each account and vendor's pending past
  //the deadline is EXPIRED. A vendor queue's own expiry (expired) is in liveFailures already: not added
  const rows = toFailureRows(summed, { ...H24, deadlineHours: 3 }, [
    b("2026-10-30T08:00:00Z", { account: "acme", vendor: "v1" }, { pending: 5, expired: 4 }),
    b("2026-10-30T11:00:00Z", { account: "acme", vendor: "v1" }, { pending: 9 }),
  ]);
  assert.deepEqual(rows, [
    { finalState: "FAILED", dlrState: 2, errCode: "0x0b", account: "acme", vendor: "v1", vendorErrCode: "11", messages: 7, lastSeen: "2026-10-30T11:30:00.000Z" },
    { finalState: "EXPIRED", dlrState: null, errCode: null, account: "acme", vendor: "v1", vendorErrCode: null, messages: 5, lastSeen: "2026-10-30T08:00:00.000Z" },
    { finalState: "REJECTED", dlrState: null, errCode: null, account: null, vendor: null, vendorErrCode: null, messages: 2, lastSeen: "2026-10-30T08:00:00.000Z" },
    { finalState: "FAILED", dlrState: 2, errCode: "0x0b", account: "acme", vendor: "v2", vendorErrCode: null, messages: 1, lastSeen: "2026-10-30T09:00:00.000Z" },
  ]);
  const reasons = failureReasons([...rows, { ...rows[0], account: "other", messages: 1, lastSeen: "2026-10-30T11:59:00.000Z" }]);
  assert.equal(reasons[0].messages, 9);
  assert.equal(reasons[0].vendor, undefined, "nor a vendor");
  assert.equal(reasons[0].lastSeen, "2026-10-30T11:59:00.000Z");
  assert.equal(reasons[0].account, undefined, "the reasons list has no account");
  assert.equal(toFailureRows([{ ...summed[0], finalState: "DELIVERED" }]).length, 0);
});

test("the gateway's grouping rules are checked before asking: VENDOR with ACCOUNT only, failures per account and vendor", () => {
  assert.equal(groupingProblem("liveSeries", ["VENDOR"]), null);
  assert.equal(groupingProblem("liveSeries", ["ACCOUNT", "VENDOR"]), null);
  assert.equal(groupingProblem("liveSeries", ["ACCOUNT", "LOGIN", "PRODUCT"]), null);
  assert.equal(groupingProblem("liveSeries", ["LISTENER", "ACCOUNT"]), null);
  assert.match(groupingProblem("liveSeries", ["VENDOR", "LOGIN"])!, /vendor and the account only/);
  assert.match(groupingProblem("liveSeries", ["ACCOUNT"], { vendor: "smppclient.v", product: "p" })!, /vendor/);
  assert.equal(groupingProblem("liveSeries", ["ACCOUNT"], { vendor: "smppclient.v", account: "a" }), null);
  assert.equal(groupingProblem("liveFailures", ["ACCOUNT", "VENDOR"]), null);
  assert.match(groupingProblem("liveFailures", ["ACCOUNT"], { login: "x" })!, /per account and vendor/);
});

test("the gateway's expired counts as expired; a backfilled flag survives only where every node says so", () => {
  const t = toTraffic([b("2026-10-30T11:00:00Z", {}, { submitted: 10, delivered: 6, failed: 1, expired: 2, pending: 1 })], H24);
  assert.deepEqual(t, [{ bucket: "2026-10-30T11:00:00Z", submitted: 10, delivered: 6, failed: 1, expired: 2, pending: 1 }]);
  const node = (name: string, backfilled: boolean, keys = 10) => normaliseSeries({
    node: name, liveSince: "2026-10-30T00:00:00Z", deadlineHours: 24, keys, maxKeys: 10,
    buckets: [{ bucket: "2026-10-30T09:00:00Z", keys: {}, backfilled, submitted: 1, attempts: null }],
  });
  const sum = sumSeries([node("a", true), node("b", false, 3)]);
  assert.equal(sum.buckets[0].backfilled, false);
  assert.equal(sum.buckets[0].attempts, null, "no vendor series, no attempts");
  assert.deepEqual(sum.saturated, ["a"], "a node at its key cap is named");
});
