import { configQuery, isConfigWritable } from "@/lib/config-db";
import { escapeLike } from "@/lib/cdr-request";
import { query } from "@/lib/metrics-db";
import { LOOKUP_LIMIT, LOOKUP_MIN_CHARS } from "@/lib/usage-grid";

/**
 * Report > Usage's typeahead (0.15.1): accounts, logins and products from the CATALOGUE -- the
 * accounts and credentials tables -- never from call records. A prefix match, case-insensitive,
 * {@link LOOKUP_LIMIT} at most, at least {@link LOOKUP_MIN_CHARS} characters, and every answer kept
 * per panel process for a minute. Products are a short list, all of them.
 *
 * <p>Accounts come from `app_account` when this panel has its configuration database, else from the
 * accounts its logins name (`app_credential`, which the read-only role may read by column).
 */

const TTL_MS = 60_000;
const cache = new Map<string, { at: number; values: string[] }>();

export type LookupKind = "account" | "login" | "product";

export async function lookup(kind: LookupKind, q: string, account: string | null): Promise<string[]> {
  const typed = q.trim().slice(0, 100);
  if (kind !== "product" && typed.length < LOOKUP_MIN_CHARS) {
    return [];
  }
  const key = `${kind}|${typed.toLowerCase()}|${account ?? ""}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL_MS) {
    return hit.values;
  }
  const prefix = `${escapeLike(typed.toLowerCase())}%`;
  let values: string[];
  if (kind === "account") {
    const rows = isConfigWritable()
      ? await configQuery<{ v: string }>(
        //lower(id) LIKE 'x%': idx_app_account_id_prefix (V1.115.0, text_pattern_ops)
        `SELECT id AS v FROM app_account WHERE lower(id) LIKE $1 ORDER BY id LIMIT ${LOOKUP_LIMIT}`, [prefix])
      : await query<{ v: string }>(
        `SELECT DISTINCT account_id AS v FROM app_credential
          WHERE account_id IS NOT NULL AND lower(account_id) LIKE $1 ORDER BY 1 LIMIT ${LOOKUP_LIMIT}`, [prefix]);
    values = rows.map((r) => r.v);
  } else if (kind === "login") {
    const rows = await query<{ v: string }>(
      //lower(…) LIKE 'x%' so idx_app_credential_system_id_prefix (V1.115.0) serves it; '' is never
      //offered: it is not one login
      `SELECT DISTINCT system_id AS v FROM app_credential
        WHERE system_id IS NOT NULL AND system_id <> '' AND lower(system_id) LIKE $1 AND ($2::text IS NULL OR account_id = $2)
        ORDER BY 1 LIMIT ${LOOKUP_LIMIT}`, [prefix, account]);
    values = rows.map((r) => r.v);
  } else {
    const rows = await query<{ v: string }>(
      `SELECT DISTINCT product AS v FROM app_credential WHERE product IS NOT NULL AND product <> '' ORDER BY 1 LIMIT 100`);
    values = rows.map((r) => r.v);
  }
  if (cache.size > 2_000) {
    cache.clear();
  }
  cache.set(key, { at: Date.now(), values });
  return values;
}
