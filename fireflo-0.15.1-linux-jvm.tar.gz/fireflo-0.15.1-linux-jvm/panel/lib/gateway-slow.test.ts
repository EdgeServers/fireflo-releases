import { strict as assert } from "node:assert";
import { test } from "node:test";
import {
  COUNTERS_POLL_MS, COUNTERS_SLOW_POLL_MS, countersInterval, failureBody, isSlowAnswer, isSlowFailure, missingAfter, shouldRead, slowNote,
} from "./gateway-slow.ts";
import { GatewayError, PANEL_CODES } from "./gateway-graphql-core.ts";

test("counters back-off: 2 s to 5 s on a slow answer, back to 2 s only on an answer under 1 s", () => {
  assert.equal(COUNTERS_POLL_MS, 2_000);
  assert.equal(COUNTERS_SLOW_POLL_MS, 5_000);
  let ms = COUNTERS_POLL_MS;
  ms = countersInterval(ms, { slow: true, elapsedMs: 10_000 });
  assert.equal(ms, 5_000);
  ms = countersInterval(ms, { slow: true, elapsedMs: 10_000 });
  assert.equal(ms, 5_000, "stays backed off while slow");
  ms = countersInterval(ms, { slow: false, elapsedMs: 3_000 });
  assert.equal(ms, 5_000, "an answer, but not a quick one: still 5 s");
  ms = countersInterval(ms, { slow: false, elapsedMs: 999 });
  assert.equal(ms, 2_000, "under 1 s: back to 2 s");
  assert.equal(countersInterval(2_000, { slow: false, elapsedMs: 1_500 }), 2_000, "a 2 s poll is not slowed by a 1.5 s answer");
});

test("a tick reads only when nothing is in flight and most of an interval has passed since the last read", () => {
  assert.equal(shouldRead({ inFlight: true, lastFinishedAt: 0, now: 100_000, intervalMs: 2_000 }), false);
  assert.equal(shouldRead({ inFlight: false, lastFinishedAt: 0, now: 100_000, intervalMs: 2_000 }), true);
  //the timer restarts with an immediate tick when the interval changes: not a read right after the slow one
  assert.equal(shouldRead({ inFlight: false, lastFinishedAt: 100_000, now: 100_010, intervalMs: 5_000 }), false);
  assert.equal(shouldRead({ inFlight: false, lastFinishedAt: 100_000, now: 105_000, intervalMs: 5_000 }), true);
  assert.equal(shouldRead({ inFlight: false, lastFinishedAt: 100_050, now: 102_000, intervalMs: 2_000 }), true, "a normal 2 s tick");
});

test("a slow 502 is told apart from any other failure", () => {
  assert.equal(isSlowAnswer(502, { error: "slow", code: "SLOW" }), true);
  assert.equal(isSlowAnswer(502, { error: "Could not reach the gateway", code: "UNREACHABLE" }), false);
  assert.equal(isSlowAnswer(502, null), false);
  assert.equal(isSlowAnswer(200, { code: "SLOW" }), false);
  assert.equal(isSlowAnswer(undefined, undefined), false);
});

test("the note names the last good answer's time, 24-hour", () => {
  assert.equal(slowNote(Date.parse("2026-10-31T21:14:03Z"), "UTC"), "gateway slow, showing data from 21:14:03");
});

test("the 502 body keeps the gateway's code; missingAfter never asks for a slow gateway", async () => {
  const slow = new GatewayError(502, PANEL_CODES.slow, "The gateway is slow");
  assert.equal(PANEL_CODES.slow, "SLOW");
  assert.equal(isSlowFailure(slow), true);
  assert.deepEqual(failureBody(slow), { error: "The gateway is slow", code: "SLOW" });
  assert.deepEqual(failureBody(new Error("plain")), { error: "plain" });
  assert.deepEqual(failureBody("odd"), { error: "the gateway did not answer" });
  let asked = 0;
  assert.equal(await missingAfter(slow, async () => (asked++, false)), false);
  assert.equal(asked, 0);
  assert.equal(await missingAfter(new GatewayError(400, "BAD_REQUEST", "no field"), async () => false), true);
  assert.equal(await missingAfter(new Error("x"), async () => { throw new Error("cannot ask"); }), false);
});
