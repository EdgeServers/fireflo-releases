/**
 * Which worker settings `PATCH /api/control/workers/<name>` may write one at a time, and what they
 * may be set to.
 *
 * <p>An allow-list rather than a general setting writer: a typo would otherwise create a dead
 * setting nobody reads. Fixed keys -- the two controls (`suspend`, `pause`), the error-code
 * editor's two keys -- take any value, as they always have. The numeric ones the Connectivity map
 * sets from a box (0.15.1) take a whole number ≥ 0, or empty to remove the setting:
 *
 * <ul>
 *   <li>`tps` -- a vendor's send rate;
 *   <li>`conf.maxRate.<account>` -- one account's rate ceiling on a listener;
 *   <li>`conf.maxConnectionsPerUser.<account>` -- one account's binds on a listener.
 * </ul>
 *
 * <p>The per-account keys name an account, and a key for an account that does not exist is exactly
 * the dead setting the list exists to prevent, so the route checks the account before writing. The
 * listener-wide `.default` keys are not here: they belong to the edit form.
 *
 * <p>Pure, so the patterns are tested without a database.
 */

const FIXED = new Set(["suspend", "pause", "dlr.errcodes", "dlr.errcodes.passthrough"]);
const NUMERIC = new Set(["tps"]);
const PER_ACCOUNT = /^conf\.(maxRate|maxConnectionsPerUser)\.([^\s.]+)$/;
/** Matches what an account id may look like here: no spaces, no dots, nothing enormous. */
const ACCOUNT_MAX = 64;

/**
 * The account a per-account listener key names, and which of the two it is: `conf.maxRate.YK201`
 * → `{ kind: "rate", account: "YK201" }`. Null for anything else, the `.default` keys among them --
 * those are the listener's own and belong to the edit form.
 */
export function perAccountKey(key: string): { kind: "rate" | "binds"; account: string } | null {
  const m = PER_ACCOUNT.exec(key);
  if (!m || m[2] === "default" || m[2].length > ACCOUNT_MAX) {
    return null;
  }
  return { kind: m[1] === "maxRate" ? "rate" : "binds", account: m[2] };
}

/** The key for one account's override of one kind on a listener. */
export function perAccountKeyFor(kind: "rate" | "binds", account: string): string {
  return `${kind === "rate" ? "conf.maxRate" : "conf.maxConnectionsPerUser"}.${account}`;
}

export type SettableKey =
  | { ok: true; key: string; account: string | null }
  | { ok: false; error: string };

/** Whether `key` may be written with `value`, and the account it names when it names one. */
export function settable(key: string, value: string): SettableKey {
  if (FIXED.has(key)) {
    return { ok: true, key, account: null };
  }
  const perAccount = PER_ACCOUNT.exec(key);
  if (!NUMERIC.has(key) && !perAccount) {
    return { ok: false, error: `'${key || "(empty)"}' cannot be set here. Use the edit form.` };
  }
  const account = perAccount ? perAccount[2] : null;
  if (account != null && (account === "default" || account.length > ACCOUNT_MAX)) {
    return { ok: false, error: `'${key}' cannot be set here. Use the edit form.` };
  }
  if (value !== "" && !/^\d+$/.test(value.trim())) {
    return { ok: false, error: `${key} takes a whole number of 0 or more, or nothing to remove it.` };
  }
  return { ok: true, key, account };
}
