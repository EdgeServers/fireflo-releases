/**
 * The Refused page's SMPP throttle strip, as the route answers it. No database import, so the client
 * component can use it.
 */

/** One account × listener × login over the window: submits answered 0x58 at a ceiling. */
export interface ThrottleGroup {
  accountId: string;
  /** The listener's full name, `smppserver.<name>`. */
  listener: string;
  systemId: string;
  throttled: number;
  /** Turned away by the account's ceiling (`conf.maxRate.*`). */
  byAccount: number;
  /** Turned away by the login's own TPS (`app_credential.max_tps`). */
  byLogin: number;
  /** Minutes in the window with any throttle. */
  minutes: number;
  lastMinute: string;
  /** The limiter's rate at the last throttle, messages a second. */
  rate: number | null;
}

export interface ThrottleAnswer {
  groups: ThrottleGroup[];
  total: number;
  /** Groups in the window, of which `groups` holds the busiest. */
  groupCount: number;
  since: string;
  until: string | null;
  /** True when the window asked for began before the table's retention, and was cut to it. */
  clamped: boolean;
}

/**
 * The route's answer: the strip, or why there is none -- a filter the table cannot honour
 * (`skipped`, the filter's name) or a database before V1.118.0 (`unsupported`).
 */
export type ThrottlePage = { data: ThrottleAnswer | null; skipped?: string; unsupported?: true };
