import { test } from "node:test";
import assert from "node:assert/strict";
import { dbCardBlocks, dbHealthFacts } from "./db-health.ts";
import { poolsReport, type PoolsReport } from "./db-pools.ts";
import { poolLabel, resetEndpointLabels } from "./db-endpoint.ts";
import { throttlingOn, withThrottling, type Health } from "./health-types.ts";

const base = { workers: [], router_queue: 0, awaiting_receipt: 0, dlr_store_persistent: true, cdr: null } as unknown as Health;

test("an older gateway has no database facts, and nothing is drawn", () => {
  assert.deepEqual(dbHealthFacts(base), []);
  assert.deepEqual(dbHealthFacts(null), []);
});

test("admission colours the state and the latency beside it; the spill alarm is red", () => {
  const facts = dbHealthFacts({
    ...base,
    db_admission: "REFUSING", db_latency_ms: 2400, db_pool_wait_ms: 30, db_refused_total: 512, dlr_store_buffer: 12,
    cdr: { enabled: true, sink: "postgres", written: 1, failed: 0, spill_over_cap: true },
  });
  const by = Object.fromEntries(facts.map((f) => [f.key, f]));
  assert.equal(by.admission.tone, "destructive");
  assert.equal(by.latency.value, "2,400 ms");
  assert.equal(by.latency.tone, "destructive");
  assert.equal(by.pool.tone, "default");
  assert.equal(by.refused.tone, "warning");
  assert.equal(by["dlr-buffer"].tone, "default");
  assert.equal(by.spill.tone, "destructive");
  assert.equal(dbHealthFacts({ ...base, db_admission: "OK" })[0].tone, "success");
  assert.equal(dbHealthFacts({ ...base, db_admission: "DEGRADED" })[0].tone, "warning");
});

test("health's throttle list is spelt the snapshot's way, Longs as numbers, and found by listener", () => {
  const h = withThrottling(base, {
    throttling: [{ account: "YK201", lastMinute: "412", last5Minutes: 2140, byAccountLimit: "400", byLoginLimit: 12, listeners: ["smppserver.dltsmpp"] }],
  });
  assert.deepEqual(h.throttling, [{
    account: "YK201", last_minute: 412, last5_minutes: 2140, by_account_limit: 400, by_login_limit: 12, listeners: ["smppserver.dltsmpp"],
  }]);
  assert.equal(throttlingOn(h.throttling, "dltsmpp").length, 1, "by instance name");
  assert.equal(throttlingOn(h.throttling, "smppserver.dltsmpp").length, 1, "by full name");
  assert.equal(throttlingOn(h.throttling, "smpp").length, 0);
  assert.equal(withThrottling(base, {}).throttling, undefined, "absent stays absent: an older gateway");
});

const v151 = {
  ...base,
  db_admission: "OK", db_latency_ms: 12, db_pool_wait_ms: 3, db_refused_total: 0, dlr_store_buffer: 0,
  cdr: { enabled: true, sink: "postgres", written: 1, failed: 0, spill_over_cap: false },
} as Health;

const pools: PoolsReport = {
  metrics: { host: "192.168.1.101:5432", size: 8, open: 3, idle: 2, waiting: 0, lastReadMs: 128 },
  config: { host: "192.168.1.101:5432", size: 4, open: 1, idle: 1, waiting: 0, lastReadMs: null },
};

test("without health.database there is no gateway block, and the pool wait stays under Admission", () => {
  const b = dbCardBlocks(v151, pools);
  assert.deepEqual(b.gateway, []);
  assert.equal(b.admission?.value, "OK");
  assert.deepEqual(b.checks.map((r) => r.key), ["latency", "pool", "refused", "dlr-buffer", "spill"]);
  assert.equal(b.checks[0].value, "12 ms (degraded above 500, refusing above 2,000)");
  assert.equal(b.checks[3].value, "0 waiting");
  //nothing of the gateway's own is drawn as a dash
  assert.ok(b.checks.every((r) => !r.value.includes("—")));
});

test("with health.database the gateway block reads it, and the probe carries the pool wait", () => {
  const b = dbCardBlocks({
    ...v151,
    database: {
      host: "db.internal", ip: "10.128.0.2", port: 5432, name: "fireflo", server_version: "18.6", schema_version: "1.122.0",
      connected_since: "2026-10-30T07:41:00Z",
      pool: { max: 16, active: 3, idle: 13, waiting: 0, acquisition_timeout_ms: 5000 },
      lanes: { lease: { max: 2, active: 0 }, control: { max: 2, active: 1 } },
      probe_ms: 12, pool_wait_ms: 0,
    },
  }, pools);
  const by = Object.fromEntries(b.gateway.map((r) => [r.key, r]));
  assert.deepEqual(b.gateway.map((r) => r.key), ["gw-server", "gw-version", "gw-schema", "gw-pool", "gw-since", "gw-probe"]);
  assert.equal(by["gw-server"].value, "db.internal (10.128.0.2):5432 · fireflo");
  assert.equal(by["gw-pool"].value, "3 of 16 in use · 0 waiting · lanes lease 0/2, control 1/2");
  assert.equal(by["gw-since"].at, true);
  assert.equal(by["gw-probe"].value, "12 ms · pool wait 0 ms");
  assert.deepEqual(b.checks.map((r) => r.key), ["latency", "refused", "dlr-buffer", "spill"], "pool wait not said twice");
});

test("a partial database block draws only what it has; a waiting caller is a warning", () => {
  const b = dbCardBlocks({ ...v151, database: { host: "10.0.0.5", ip: "10.0.0.5", pool: { max: 16, active: 16, waiting: 4 } } }, null);
  assert.deepEqual(b.gateway.map((r) => [r.key, r.value]), [["gw-server", "10.0.0.5"], ["gw-pool", "16 of 16 in use · 4 waiting"]]);
  assert.equal(b.gateway[1].tone, "warning");
  assert.deepEqual(b.panel, [], "the pools route has not answered");
});

test("the panel block names each pool's server, size and last read; an unset URL says so", () => {
  const b = dbCardBlocks(base, { ...pools, config: { host: null, size: 4, open: 0, idle: 0, waiting: 0, lastReadMs: null } });
  assert.deepEqual(b.panel.map((r) => [r.label, r.value]), [
    ["Reports", "192.168.1.101:5432 · 8 connections · last read 128 ms"],
    ["Settings", "not configured"],
  ]);
  assert.equal(b.admission, null);
  assert.deepEqual(b.checks, []);
});

test("the pools report carries host, size, counts and last read, and never a credential", async () => {
  const saved = { m: process.env.METRICS_DATABASE_URL, c: process.env.CONFIG_DATABASE_URL };
  process.env.METRICS_DATABASE_URL = "postgres://reader:hunter2@10.0.0.9:5433/fireflo?sslmode=require";
  delete process.env.CONFIG_DATABASE_URL;
  resetEndpointLabels();
  try {
    const report = await poolsReport({
      //the route's own label: endpointLabel over the URL's host and port, nothing else of it
      label: poolLabel,
      stats: (pool) => (pool === "metrics" ? { max: 8, total: 3, idle: 2, waiting: 1 } : { max: 4, total: 0, idle: 0, waiting: 0 }),
      lastReadMs: (pool) => (pool === "metrics" ? 127.6 : null),
    });
    assert.deepEqual(report, {
      metrics: { host: "10.0.0.9:5433", size: 8, open: 3, idle: 2, waiting: 1, lastReadMs: 128 },
      config: { host: null, size: 4, open: 0, idle: 0, waiting: 0, lastReadMs: null },
    });
    const text = JSON.stringify(report);
    assert.ok(!text.includes("hunter2") && !text.includes("reader") && !text.includes("fireflo"), "no user, password or database name");
  } finally {
    process.env.METRICS_DATABASE_URL = saved.m;
    process.env.CONFIG_DATABASE_URL = saved.c;
    if (saved.m === undefined) delete process.env.METRICS_DATABASE_URL;
    if (saved.c === undefined) delete process.env.CONFIG_DATABASE_URL;
    resetEndpointLabels();
  }
});

test("a label that fails leaves the host null rather than failing the report", async () => {
  const report = await poolsReport({
    label: async () => { throw new Error("dns"); },
    stats: () => ({ max: 8, total: 0, idle: 0, waiting: 0 }),
    lastReadMs: () => null,
  });
  assert.equal(report.metrics.host, null);
});
