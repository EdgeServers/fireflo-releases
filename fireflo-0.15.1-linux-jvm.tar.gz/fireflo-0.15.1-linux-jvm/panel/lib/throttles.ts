import { query } from "@/lib/metrics-db";
import { MAX_THROTTLE_GROUPS, throttleQuery } from "@/lib/throttles-sql";
import type { RejectedFilters } from "@/lib/rejected-request";
import type { ThrottlePage } from "@/lib/throttles-types";

/**
 * SMPP throttles over a window, from `smpp_throttle_minute` on the metrics pool.
 *
 * <p>Server-only: importing this pulls `pg`. The SQL is `throttles-sql.ts`; this runs it and
 * shapes the rows. A database before V1.118.0 has no such table (`42P01`), which is an older
 * gateway rather than a fault, and reads as `unsupported`.
 */

interface ThrottleRow {
  account_id: string;
  listener: string;
  system_id: string;
  throttled: string;
  by_account: string;
  by_login: string;
  minutes: number;
  last_minute: Date;
  rate: number | null;
  total: string;
  groups: number;
}

export async function listThrottles(filters: RejectedFilters, now: Date = new Date()): Promise<ThrottlePage> {
  const built = throttleQuery(filters, now);
  if ("skipped" in built) {
    return { data: null, skipped: built.skipped };
  }
  let rows: ThrottleRow[];
  try {
    rows = await query<ThrottleRow>(built.sql, built.params);
  } catch (err) {
    if ((err as { code?: string }).code === "42P01") {
      return { data: null, unsupported: true };
    }
    throw err;
  }
  return {
    data: {
      groups: rows.slice(0, MAX_THROTTLE_GROUPS).map((r) => ({
        accountId: r.account_id,
        listener: r.listener,
        systemId: r.system_id,
        throttled: Number(r.throttled),
        byAccount: Number(r.by_account),
        byLogin: Number(r.by_login),
        minutes: r.minutes,
        lastMinute: r.last_minute.toISOString(),
        rate: r.rate,
      })),
      total: rows.length ? Number(rows[0].total) : 0,
      groupCount: rows.length ? rows[0].groups : 0,
      since: built.since.toISOString(),
      until: built.until?.toISOString() ?? null,
      clamped: built.clamped,
    },
  };
}
