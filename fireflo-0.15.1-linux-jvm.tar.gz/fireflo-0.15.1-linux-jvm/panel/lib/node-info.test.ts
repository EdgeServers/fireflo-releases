import { test } from "node:test";
import assert from "node:assert/strict";
import { initiallyOpen, nodeSummary, selfOpenReason, sortNodes } from "./node-info.ts";
import type { ClusterNode } from "./health-types.ts";

const node = (nodeId: string, alive = true, version = "0.15.1"): ClusterNode => ({ nodeId, alive, version });

test("the summary counts nodes, the live ones and the ones past the timeout", () => {
  assert.equal(nodeSummary([node("a"), node("b"), node("old", false, "0.15.0")], "a"), "3 nodes · 2 alive · 1 missed the timeout");
  assert.equal(nodeSummary([node("a"), node("b")], "a"), "2 nodes · 2 alive");
  assert.equal(nodeSummary([node("a"), node("b", true, "0.15.0")], "a"), "2 nodes · 2 alive · 2 releases");
});

test("a single gateway reads as this one", () => {
  assert.equal(nodeSummary([node("a")], "a"), "1 node · this one");
  assert.equal(nodeSummary([node("a")], "b"), "1 node · alive");
  assert.equal(nodeSummary([node("a", false)], "b"), "1 node · missed the timeout");
  assert.equal(nodeSummary([], "a"), "no nodes listed");
});

test("the section opens itself for a dead node or live nodes on different releases, never for a healthy cluster", () => {
  assert.equal(selfOpenReason([node("a"), node("b")]), null);
  assert.equal(selfOpenReason([node("a")]), null);
  //a dead node's old release is not a mismatch
  assert.equal(selfOpenReason([node("a"), node("b")].concat(node("old", false, "0.14.4"))), "dead:old|versions:");
  assert.equal(selfOpenReason([node("a"), node("b", true, "0.15.0")]), "dead:|versions:0.15.0,0.15.1");
  //a second death is a new reason, so a section closed after the first opens again
  assert.notEqual(selfOpenReason([node("a", false), node("b", false)]), selfOpenReason([node("a", false), node("b")]));
});

test("it starts open on #nodes or when remembered open", () => {
  assert.equal(initiallyOpen(null, "#nodes"), true);
  assert.equal(initiallyOpen("0", "#nodes"), true);
  assert.equal(initiallyOpen("1", ""), true);
  assert.equal(initiallyOpen("0", ""), false);
  assert.equal(initiallyOpen(null, ""), false);
});

test("live nodes first, this one first among them", () => {
  const sorted = sortNodes([node("z"), node("dead", false), node("me"), node("b")], "me");
  assert.deepEqual(sorted.map((n) => n.nodeId), ["me", "b", "z", "dead"]);
});
