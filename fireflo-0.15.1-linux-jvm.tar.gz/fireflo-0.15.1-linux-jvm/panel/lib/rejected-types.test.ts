import { test } from "node:test";
import assert from "node:assert/strict";
import {
  REJECT_REASONS,
  reasonHint,
  reasonLabel,
  refusedAfterAccepting,
  vendorStatusName,
} from "./rejected-types.ts";

/**
 * The Refused page's vocabulary.
 *
 * <p>Nothing covered this before, and two tokens the gateway has always emitted —
 * `productNotAllowed` and `queueFull` — had quietly never had an entry, so they rendered as raw
 * camelCase to an operator at 3am. These cases exist so the next one is caught by a test rather
 * than by somebody reading the page.
 */

test("every reason the gateway emits has a label and a hint", () => {
  //taken from the gateway's own reasonOf() plus the two router paths and the vendor refusal. If
  //the gateway gains a token, this list is where the panel finds out
  const emitted = [
    "headerNotApproved", "templateNotMatched", "insufficientCredit", "missingMandatoryTlv",
    "rateLimited", "queueFull", "productNotSold", "productNotAllowed", "unrated", "submitFailed",
    "maxAttempts", "filtered", "vendorRejected",
    //gateway 0.15.1: vendor backlog limits, expiry in a vendor queue, the stop, the unknown hand-off
    "vendorBacklog", "vendorUnavailable", "expiredInQueue", "shuttingDown", "outcomeUnknown",
  ];

  for (const token of emitted) {
    assert.ok(REJECT_REASONS[token], `${token} has no entry, so it renders as a raw token`);
    assert.notEqual(reasonLabel(token), token, `${token} falls through to its raw form`);
    assert.ok(reasonHint(token), `${token} has no hint`);
  }
});

test("an unknown reason keeps its raw token rather than becoming 'Unknown'", () => {
  //deliberate, and the opposite of settingLabel's rule: a token you can grep for beats a word you
  //cannot. A new gateway against an older panel must stay diagnosable
  assert.equal(reasonLabel("somethingNewTheGatewayAdded"), "somethingNewTheGatewayAdded");
  assert.equal(reasonHint("somethingNewTheGatewayAdded"), null);
});

test("a vendor refusal counts as refused after accepting", () => {
  //it was charged, sent, refused by the carrier and refunded -- the customer already had a success
  //back for it, which is the distinction this predicate exists to draw
  assert.equal(refusedAfterAccepting("vendorRejected"), true);
  assert.equal(refusedAfterAccepting("maxAttempts"), true);
  assert.equal(refusedAfterAccepting("filtered"), true);
  assert.equal(refusedAfterAccepting("headerNotApproved"), false, "refused at the door, never charged");
  //0.15.1: expiredInQueue was accepted, charged, queued and refunded; the two backlog refusals
  //and the stop are at the door
  assert.equal(refusedAfterAccepting("expiredInQueue"), true);
  for (const door of ["vendorBacklog", "vendorUnavailable", "shuttingDown"]) {
    assert.equal(refusedAfterAccepting(door), false, door);
  }
});

test("a vendor status resolves to its SMPP mnemonic", () => {
  assert.equal(vendorStatusName(196), "ESME_RINVOPTPARAMVAL");
  assert.equal(vendorStatusName(11), "ESME_RINVDSTADR");
  assert.equal(vendorStatusName(88), "ESME_RTHROTTLED");
});

test("an unnamed or absent vendor status returns null rather than a guess", () => {
  //null so the column shows the bare number. Vendors do use codes outside the spec, and inventing
  //a name sends an operator hunting for a spec entry that does not exist
  assert.equal(vendorStatusName(1024), null);
  assert.equal(vendorStatusName(null), null);
  assert.equal(vendorStatusName(undefined), null);
});

test("the vendor hint points at TLVs, which is what the 192-196 block always means", () => {
  const hint = reasonHint("vendorRejected") ?? "";

  assert.match(hint, /TLV/);
  assert.match(hint, /refunded/, "the customer was charged and refunded, and that must be said");
});
