/**
 * Results of the heavy stats -- Receipts, Usage, Revenue, Vendors -- kept for a short while and
 * shared, so that every tab polling every page does not each re-run statements that read millions
 * of records.
 *
 * <ul>
 *   <li><b>Kept per period:</b> the last hour for 30 s, a day for 60 s, a week or a month for 5 min
 *       ({@link ttlFor}). A 30-day view does not change meaningfully in a minute.</li>
 *   <li><b>One run at a time per key:</b> callers arriving while it runs wait for it (single
 *       flight), so two tabs or a poll overlapping a switch cost one statement, not two.</li>
 *   <li><b>An expired answer is served at once</b> while a fresh one is read behind it; if that read
 *       fails, the answer is marked stale with when and why rather than an error page.</li>
 *   <li><b>A first read that takes long is not waited for:</b> past `waitMs` the caller is told it
 *       is still being read (the page's "taking a breath" card) and the read carries on.</li>
 *   <li><b>At most three heavy reads at once,</b> so they can never hold the whole metrics pool.</li>
 *   <li><b>Bounded:</b> {@link StatsCache}'s `max` entries, the least recently used dropped first.</li>
 * </ul>
 *
 * <p>In memory, per panel process. Customer answers are keyed by their scope (see `stats-route.ts`),
 * so one customer's figures never answer another's request.
 *
 * <p><b>Each entry keeps the trace of the read that produced it</b> (`db-trace.ts`): the read runs
 * in a trace of its own, and whichever request is answered from it -- the one that started it,
 * one that joined it, or one a minute later -- has that read's calls copied onto its own trace,
 * marked cached when the answer was kept. So the footer says "from cache" with the original read's
 * time, rather than 0 ms, and a refresh behind a kept answer is charged to nobody.
 */

import { adoptTrace, captureTrace, type DbTrace } from "./db-trace.ts";

export interface Cached<T> {
  value: T;
  /** When the value was read, ms. */
  at: number;
  /** Set when the latest read failed and this is the last good answer. */
  stale?: { reason: string };
}

/**
 * Thrown when a first read is still going after the caller's wait: the page shows its "taking a
 * breath" card and asks again. The read carries on and fills the cache.
 */
export class StillReadingError extends Error {
  constructor() {
    super("Still reading");
    this.name = "StillReadingError";
  }
}

/** How long a period's answer is kept, ms. */
export function ttlFor(range: string): number {
  if (range === "7d" || range === "30d") return 5 * 60_000;
  if (range === "24h") return 60_000;
  return 30_000;
}

export interface GetOptions {
  /**
   * How long the caller waits for a first read before {@link StillReadingError}. Absent: until it
   * finishes. An answer already kept, even an expired one, is never waited for.
   */
  waitMs?: number;
}

type Entry = { value: unknown; at: number; failed?: string; trace?: DbTrace };

export class StatsCache {
  private entries = new Map<string, Entry>();
  private running = new Map<string, Promise<unknown>>();
  private active = 0;
  private queue: (() => void)[] = [];
  private readonly max: number;
  private readonly concurrency: number;
  private readonly now: () => number;

  /**
   * @param concurrency heavy reads at once; the rest wait their turn, so slow reads can never hold
   *     every connection of the metrics pool (eight) and starve the rest of the panel
   */
  constructor(max = 64, now: () => number = Date.now, concurrency = 3) {
    this.max = max;
    this.now = now;
    this.concurrency = concurrency;
  }

  /**
   * The answer for `key`:
   * <ul>
   *   <li>kept and younger than `ttlMs`: at once;</li>
   *   <li>kept but expired: at once, while a fresh read runs behind it (one per key); if the last
   *       such read failed, the answer is marked stale with why;</li>
   *   <li>never kept: read now, waited for up to `waitMs`, else {@link StillReadingError} while the
   *       read carries on. A failed first read is the caller's error.</li>
   * </ul>
   */
  async get<T>(key: string, ttlMs: number, run: () => Promise<T>, o: GetOptions = {}): Promise<Cached<T>> {
    const kept = this.entries.get(key);
    if (kept) {
      this.touch(key, kept);
      if (this.now() - kept.at >= ttlMs) {
        //refresh behind the answer: the failure, if any, is noted on the entry for the next caller
        void this.read(key, run).catch(() => undefined);
      }
      adoptTrace(kept.trace, true);
      return {
        value: kept.value as T,
        at: kept.at,
        ...(kept.failed ? { stale: { reason: kept.failed } } : {}),
      };
    }
    const reading = this.read(key, run);
    if (o.waitMs === undefined) {
      const value = (await reading) as T;
      return this.answered(key, value);
    }
    let timer: ReturnType<typeof setTimeout> | undefined;
    const waited = new Promise<"wait">((resolve) => {
      timer = setTimeout(() => resolve("wait"), o.waitMs);
    });
    try {
      const first = await Promise.race([reading.then((v) => ({ v })), waited]);
      if (first === "wait") {
        //the read goes on; its failure must not become an unhandled rejection
        reading.catch(() => undefined);
        throw new StillReadingError();
      }
      return this.answered(key, first.v as T);
    } finally {
      clearTimeout(timer);
    }
  }

  /** A read this request waited for: its calls are this request's, not cached ones. */
  private answered<T>(key: string, value: T): Cached<T> {
    const entry = this.entries.get(key);
    adoptTrace(entry?.trace, false);
    return { value, at: entry?.at ?? this.now() };
  }

  /** One read per key at a time, at most `concurrency` keys at once; success or failure is kept. */
  private read<T>(key: string, run: () => Promise<T>): Promise<T> {
    const going = this.running.get(key);
    if (going) {
      return going as Promise<T>;
    }
    const p = (async () => {
      await this.slot();
      try {
        //in a trace of its own, kept with the answer (see the file's note)
        const { value, trace } = await captureTrace(run);
        this.touch(key, { value, at: this.now(), trace });
        return value;
      } catch (err) {
        const last = this.entries.get(key);
        if (last) {
          last.failed = err instanceof Error ? err.message : String(err);
        }
        throw err;
      } finally {
        this.release();
        this.running.delete(key);
      }
    })();
    this.running.set(key, p);
    return p;
  }

  private slot(): Promise<void> {
    if (this.active < this.concurrency) {
      this.active++;
      return Promise.resolve();
    }
    return new Promise((resolve) => this.queue.push(() => {
      this.active++;
      resolve();
    }));
  }

  private release(): void {
    this.active--;
    this.queue.shift()?.();
  }

  /** Re-insert as the most recently used, and drop the oldest past `max`. */
  private touch(key: string, entry: Entry): void {
    this.entries.delete(key);
    this.entries.set(key, entry);
    while (this.entries.size > this.max) {
      const oldest = this.entries.keys().next().value as string;
      this.entries.delete(oldest);
    }
  }
}

/** A request's cache key: who asks (a customer by scope), what, over which period, with what. */
export function statsKey(o: { who: string; metric: string; range: string; params: URLSearchParams; scope?: readonly string[] }): string {
  const params = [...o.params.entries()]
    .filter(([k]) => k !== "range" && k !== "fresh")
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}=${v}`)
    .join("&");
  return [o.who, o.metric, o.range, params, o.scope ? [...o.scope].sort().join(",") : ""].join("|");
}
