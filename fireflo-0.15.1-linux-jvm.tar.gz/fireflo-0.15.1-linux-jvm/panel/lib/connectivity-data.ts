import {
  hourWindowLabel, listenerHour, listenerRefusal, vendorHour, type ConnectivityCounts, type CountPair, type CountsWindow,
} from "./connectivity-counts.ts";
import {
  PERSIST_LAG_MAX_DEFAULT, QUEUE_SAMPLES, queueTotal, queueTrend,
  type ClientIn, type DatabaseIn, type ListenerIn, type MapInput, type NodeIn, type NodeQueue, type QueueSample, type VendorIn,
} from "./connectivity-layout.ts";
import { serverLabel } from "./db-health.ts";
import { throttlingOn, type Health, type HealthSession, type HealthWorker } from "./health-types.ts";
import { EMPTY_LIVE_SESSIONS, foldSessions, sumCounts, type LiveSessionHistory, type SessionReading } from "./live-sessions.ts";
import { accountOfKey, loginKey, loginOfKey, UNATTRIBUTED } from "./session-groups.ts";
import type { VendorBacklog } from "./vendor-backlog.ts";
import { isOn, trafficKey, type Worker } from "./worker-types.ts";

/**
 * What the Connectivity page polls, turned into the layout's input (`lib/connectivity-layout.ts`).
 *
 * <p>Sources, all already read by other pages and none of them the database from the browser:
 * health (workers, cluster, backbone, throttling, the queues), the operator `sessions` query per
 * listener, the vendor backlog, the configured workers, and the routing tables and groups -- the last
 * two only to know which vendors something routes to, so an idle one still has its edge, and which
 * vendors a group frames. Routing comes from the gateway's memory (`routing`, capability
 * `routing_view`, `lib/gateway-routing-view.ts`) and, on an older gateway only, from the panel's two
 * config routes.
 *
 * <p>Sessions fold at the finest grain the map draws, account × source IP, and sum to the account
 * when the map is not split by IP. Folding at one grain whichever way the toggle is set means the
 * rate baselines survive the toggle: flipping it is a different sum of the same history, not a new
 * history that needs two readings before it can say anything.
 *
 * <p>The MT and DLR counts beside the rates (`lib/connectivity-counts.ts`) come two ways. Since bind:
 * the same sessions' `submitted` and `receipts`, as of the newest poll, and each vendor worker's
 * `submitted`. Last hour: the gateway's live series, per listener × account and per vendor, laid
 * over the same boxes by {@link buildMapInput}. Neither reads the database.
 */

/** One listener's rate histories: submits, and receipts sent back down. */
export interface ListenerHistory {
  submits: LiveSessionHistory;
  receipts: LiveSessionHistory;
}

export const EMPTY_LISTENER_HISTORY: ListenerHistory = { submits: EMPTY_LIVE_SESSIONS, receipts: EMPTY_LIVE_SESSIONS };

interface Fine {
  key: string;
  sessions: HealthSession[];
}

/** Sessions by account × source IP. */
function fine(rows: readonly HealthSession[]): Fine[] {
  const byKey = new Map<string, HealthSession[]>();
  for (const s of rows) {
    const key = loginKey(s.account?.trim() || UNATTRIBUTED, s.host?.trim() || UNATTRIBUTED);
    const list = byKey.get(key);
    if (list) {
      list.push(s);
    } else {
      byKey.set(key, [s]);
    }
  }
  return [...byKey.entries()].map(([key, sessions]) => ({ key, sessions }));
}

function members(sessions: readonly HealthSession[]): string {
  return sessions.map((s) => (s.session_id != null ? String(s.session_id) : `${s.host ?? ""}:${s.port ?? ""}`)).sort().join(",");
}

function total(values: readonly (number | null | undefined)[]): number | null {
  let out: number | null = null;
  for (const v of values) {
    if (v != null) {
      out = (out ?? 0) + v;
    }
  }
  return out;
}

/** Fold one poll of a listener's sessions into its histories. */
export function foldListener(previous: ListenerHistory, rows: readonly HealthSession[], now: number): ListenerHistory {
  const groups = fine(rows);
  const submits: SessionReading[] = groups.map((g) => ({
    key: g.key,
    submitted: total(g.sessions.map((s) => s.submitted)),
    tps: total(g.sessions.map((s) => s.tps_measured)),
    members: members(g.sessions),
    //the counters since bind ride the submit fold: history.submits.counts is "since bind"
    receipts: total(g.sessions.map((s) => s.receipts)),
  }));
  //receipts have no measured fallback: a first reading is a gap, not a guess
  const receipts: SessionReading[] = groups.map((g) => ({
    key: g.key,
    submitted: total(g.sessions.map((s) => s.receipts)),
    tps: null,
    members: members(g.sessions),
  }));
  return {
    submits: foldSessions(previous.submits, submits, now),
    receipts: foldSessions(previous.receipts, receipts, now),
  };
}

/**
 * A listener's clients for the map: by account, or by account × IP.
 *
 * @param throttled submits refused at a ceiling in the last minute, by account (health `throttling`)
 */
export function clientsOf(
  listener: string,
  rows: readonly HealthSession[],
  history: ListenerHistory,
  byIp: boolean,
  throttled: ReadonlyMap<string, number> = new Map()
): ClientIn[] {
  const submitRates = history.submits.samples.at(-1)?.rates ?? {};
  const receiptRates = history.receipts.samples.at(-1)?.rates ?? {};
  const out = new Map<string, ClientIn & { limits: Set<number> }>();
  for (const g of fine(rows)) {
    const account = accountOfKey(g.key);
    const ip = loginOfKey(g.key);
    const key = byIp ? g.key : account;
    const row = out.get(key) ?? {
      key,
      account,
      ip: byIp ? ip : null,
      hosts: [],
      logins: [],
      listener,
      binds: 0,
      rate: null,
      receiptRate: null,
      refusedRate: null,
      ceiling: null,
      mt: null,
      dlr: null,
      limits: new Set<number>(),
    };
    if (ip !== UNATTRIBUTED && !row.hosts.includes(ip)) {
      row.hosts.push(ip);
    }
    for (const s of g.sessions) {
      if (s.bound) {
        row.binds += 1;
      }
      if (s.system_id && !row.logins.includes(s.system_id)) {
        row.logins.push(s.system_id);
      }
      if (s.tps_limit != null) {
        row.limits.add(s.tps_limit);
      }
    }
    row.rate = total([row.rate, submitRates[g.key]]);
    row.receiptRate = total([row.receiptRate, receiptRates[g.key]]);
    out.set(key, row);
  }
  return [...out.values()].map(({ limits, ...c }) => {
    const refused = throttled.get(c.account);
    //since bind: the counters of the sessions behind the row, as of this poll
    const since = sumCounts(history.submits, (k) => (byIp ? k === c.key : accountOfKey(k) === c.account));
    c.mt = since.submitted;
    c.dlr = since.receipts;
    //a refusal rate is the account's, so split by IP it is drawn once, on the account's busiest row
    return { ...c, ceiling: limits.size === 1 ? [...limits][0] : null, refusedRate: refused ? refused / 60 : null };
  }).map((c, _i, all) => {
    if (!byIp || c.refusedRate == null) {
      return c;
    }
    const busiest = all.filter((x) => x.account === c.account).sort((a, b) => (b.rate ?? -1) - (a.rate ?? -1))[0];
    return busiest === c ? c : { ...c, refusedRate: null };
  });
}

/** Submits refused at a ceiling in the last minute, by account, for one listener. */
export function throttledOn(health: Health | null, listener: Pick<Worker, "name" | "type">): Map<string, number> {
  const out = new Map<string, number>();
  //per account across the listeners the gateway names, so an account throttled on two ports shows
  //its whole count on each: the gateway does not split it
  for (const t of throttlingOn(health?.throttling, trafficKey(listener))) {
    out.set(t.account, (out.get(t.account) ?? 0) + (t.last_minute ?? 0));
  }
  return out;
}

/**
 * As much of a routing table as the map reads: a `RouteTable` from the config routes, or a table of
 * the gateway's in-memory `routing` view (`lib/gateway-routing-view.ts`).
 */
export interface RoutingTableLike {
  enabled: boolean;
  rules: readonly { target: string; enabled: boolean }[];
}

/** As much of a route group as the map reads; `workerName` an instance or full name. */
export interface RoutingGroupLike {
  name: string;
  enabled: boolean;
  members: readonly { workerName: string; enabled: boolean }[];
}

/**
 * The vendors something routes to: targets of enabled rules in enabled tables, and the enabled
 * members of enabled groups those rules name. Instance names.
 */
export function routedVendors(tables: readonly RoutingTableLike[], groups: readonly RoutingGroupLike[]): Set<string> {
  const targets = new Set<string>();
  for (const t of tables) {
    if (!t.enabled) {
      continue;
    }
    for (const r of t.rules) {
      if (r.enabled) {
        targets.add(r.target);
      }
    }
  }
  const out = new Set(targets);
  for (const g of groups) {
    if (g.enabled && targets.has(g.name)) {
      g.members.filter((m) => m.enabled).forEach((m) => out.add(m.workerName));
    }
  }
  return out;
}

function prop(worker: Worker, key: string): string | null {
  const v = worker.properties.find((p) => p.key === key)?.value?.trim();
  return v ? v : null;
}

function positive(raw: string | null): number | null {
  const n = raw == null ? NaN : Number(raw);
  return Number.isFinite(n) && n > 0 ? n : null;
}

export interface MapSources {
  health: Health | null;
  /** The newest submit rate per worker full name, from the health poll's counter deltas. */
  workerRates: Readonly<Record<string, number | null>>;
  servers: readonly Worker[];
  vendors: readonly Worker[];
  /** Clients by listener full name. */
  clients: ReadonlyMap<string, ClientIn[]>;
  backlog: readonly VendorBacklog[];
  routed: ReadonlySet<string>;
  groups: readonly RoutingGroupLike[];
  /** The kept samples of each node's queue ({@link foldQueue}); absent, no trend is known. */
  queues?: QueueHistory;
  kafka: boolean;
  /** Which window the counts cover; "hour" draws `hour` over the boxes, "bind" the counters. */
  countsWindow: CountsWindow;
  /**
   * The last hour from the gateway's live series, and the last full minute's refusals per listener;
   * null while unread or unavailable. The refusals are drawn whichever counts window is shown.
   */
  hour: ConnectivityCounts | null;
}

const ZERO: CountPair = { mt: 0, dlr: 0 };

/**
 * The last hour's counts for one box. With an answer in hand, a key the series does not hold moved
 * nothing in the hour (zero); with none, nothing is known (null).
 */
function hourOf(hour: ConnectivityCounts | null, read: (c: ConnectivityCounts) => CountPair | null): { mt: number | null; dlr: number | null } {
  return hour ? (read(hour) ?? ZERO) : { mt: null, dlr: null };
}

/**
 * Clients with the window's counts: since bind they are what `clientsOf` folded; over the last hour
 * the series' per listener × account. Split by IP, an hour count is not known per address -- the
 * series has no address -- so the rows carry none and their group shows the port's.
 */
export function clientsInWindow(
  clients: readonly ClientIn[],
  window: CountsWindow,
  hour: ConnectivityCounts | null
): ClientIn[] {
  if (window === "bind") {
    return [...clients];
  }
  return clients.map((c) => (c.ip != null
    ? { ...c, mt: null, dlr: null }
    : { ...c, ...hourOf(hour, (h) => listenerHour(h, c.listener, c.account)) }));
}

/** Everything the layout draws, from what the page polled. */
export function buildMapInput(src: MapSources): MapInput {
  const live = new Map<string, HealthWorker>((src.health?.workers ?? []).map((w) => [w.name, w]));
  const self = answeringNode(src.health);
  const backbone = src.health?.backbone?.provider?.trim() || src.health?.cluster?.mode || "memory";
  const known = src.health?.cluster?.nodes ?? [];
  //only the answering node's queue is known; the others' are their own business
  const queue = nodeQueueOf(src.health);
  const trend = queue ? queueTrend(src.queues?.get(self) ?? []) : null;
  const mine = { queue, trend };
  const nodes: NodeIn[] = known.length
    ? known.map((n) => ({
      id: n.nodeId,
      self: n.nodeId === self,
      alive: n.alive,
      backbone,
      ...(n.nodeId === self ? mine : { queue: null, trend: null }),
    }))
    : [{ id: self, self: true, alive: src.health != null, backbone, ...mine }];
  if (!nodes.some((n) => n.id === self)) {
    nodes.push({ id: self, self: true, alive: true, backbone, ...mine });
  }

  const listeners: ListenerIn[] = src.servers
    .filter((w) => w.enabled)
    .map((w) => {
      const full = trafficKey(w);
      const h = live.get(full);
      const clients = src.clients.get(full);
      const summed = clients ? total(clients.map((c) => c.rate)) : null;
      const counts = src.countsWindow === "hour"
        ? hourOf(src.hour, (hr) => listenerHour(hr, w.name))
        : {
          //the sessions' counters, or the worker's own submit counter when no session was read
          mt: (clients ? total(clients.map((c) => c.mt)) : null) ?? h?.submitted ?? null,
          dlr: clients ? total(clients.map((c) => c.dlr)) : null,
        };
      return {
        id: full,
        name: w.name,
        port: prop(w, "srv.port"),
        bound: h?.bound ?? 0,
        rate: summed ?? h?.tps_measured ?? src.workerRates[full] ?? null,
        ceiling: positive(prop(w, "conf.maxRate.default")),
        live: h != null,
        error: !!h?.last_error && (h.bound ?? 0) === 0,
        held: isOn(w, "pause"),
        suspended: isOn(w, "suspend"),
        node: self,
        ...counts,
        refused: listenerRefusal(src.hour, w.name),
      };
    });

  //a member may be named by instance or by full name; either finds its vendor
  const groupOf = new Map<string, string>();
  for (const g of src.groups) {
    for (const m of g.members) {
      if (!groupOf.has(m.workerName)) {
        groupOf.set(m.workerName, g.name);
      }
    }
  }
  const vendors: VendorIn[] = src.vendors
    .filter((w) => w.enabled)
    .map((w) => {
      const full = trafficKey(w);
      const h = live.get(full);
      const b = src.backlog.find((x) => x.worker === full || x.worker === w.name);
      const counts = src.countsWindow === "hour"
        ? hourOf(src.hour, (hr) => vendorHour(hr, w.name))
        //a vendor's sessions count no receipts (the gateway reports null there), so DLR since bind
        //is only known from a gateway that does
        : { mt: h?.submitted ?? null, dlr: total((h?.sessions ?? []).map((s) => s.receipts)) };
      return {
        id: full,
        name: w.name,
        rate: src.workerRates[full] ?? h?.tps_measured ?? null,
        tpsLimit: h?.tps_limit ?? positive(prop(w, "tps")),
        bound: (h?.bound ?? 0) > 0,
        backlog: b ? { state: b.state, depth: b.depth } : null,
        held: isOn(w, "pause"),
        suspended: isOn(w, "suspend"),
        routed: src.routed.has(w.name) || src.routed.has(full),
        node: self,
        group: groupOf.get(w.name) ?? groupOf.get(full) ?? null,
        ...counts,
      };
    });

  return {
    clients: clientsInWindow(listeners.flatMap((l) => src.clients.get(l.id) ?? []), src.countsWindow, src.hour),
    listeners,
    nodes,
    vendors,
    kafka: src.kafka,
    database: databaseOf(src.health, self),
    countsWindow: src.countsWindow,
    //a restart inside the hour renames the window ("since restart 09:42") and says why
    ...(src.countsWindow === "hour" ? (({ label, note }) => ({ countsLabel: label, countsNote: note }))(hourWindowLabel(src.hour)) : {}),
  };
}

function finite(v: unknown): number | null {
  return typeof v === "number" && Number.isFinite(v) ? v : null;
}

/**
 * The gateway's PostgreSQL from its health snapshot, for the Database box: `health.database` (where
 * it points, the pool, the probe) with the snapshot's own fields (admission and its reason, the
 * write rate, the persistence bus, the local log, refusals since start). Null -- no box -- when the
 * snapshot has neither a database block nor `db_admission`: an older gateway, or one without a
 * database.
 *
 * @param node the answering node: the box sits beside it
 */
export function databaseOf(health: Health | null | undefined, node: string): DatabaseIn | null {
  if (!health || (!health.database && !health.db_admission)) {
    return null;
  }
  const d = health.database ?? {};
  const lane = (name: string, l: { max?: number | null; active?: number | null } | null | undefined) =>
    l && (l.active != null || l.max != null) ? `${name} ${l.active ?? "—"}/${l.max ?? "—"}` : null;
  const lanes = [lane("lease", d.lanes?.lease), lane("control", d.lanes?.control)].filter((x): x is string => x != null);
  const depth = health.persist_depth;
  const capMb = finite(health.persist_log_max_mb);
  const admission = health.db_admission;
  return {
    node,
    server: serverLabel(d),
    name: d.name?.trim() || null,
    version: d.server_version?.trim() || null,
    schema: d.schema_version?.trim() || null,
    connectedSince: d.connected_since ?? null,
    admission: admission === "OK" || admission === "DEGRADED" || admission === "REFUSING" ? admission : null,
    reason: health.db_admission_reason?.trim() || null,
    probeMs: finite(d.probe_ms) ?? finite(health.db_latency_ms),
    poolActive: finite(d.pool?.active),
    poolMax: finite(d.pool?.max),
    poolWaitMs: finite(d.pool_wait_ms) ?? finite(health.db_pool_wait_ms),
    lanes: lanes.length ? lanes.join(" · ") : null,
    writeRate: finite(health.db_write_rate),
    persistDepth: depth && typeof depth === "object" ? total(Object.values(depth).map((v) => finite(v))) : null,
    persistLagSeconds: finite(health.persist_lag_seconds),
    logBytes: finite(health.persist_log_bytes),
    logCapBytes: capMb != null && capMb > 0 ? capMb * 1024 * 1024 : null,
    logHealthy: typeof health.persist_log_healthy === "boolean" ? health.persist_log_healthy : null,
    refusedTotal: finite(health.db_refused_total),
  };
}

/** The node that answered health: its own id, else the first alive one the cluster lists, else "gateway". */
export function answeringNode(health: Health | null | undefined): string {
  return health?.node_id?.trim() || health?.cluster?.nodes.find((n) => n.alive)?.nodeId || "gateway";
}

/** The answering node's queue from its health snapshot; null without health. */
export function nodeQueueOf(health: Health | null | undefined): NodeQueue | null {
  if (!health) {
    return null;
  }
  const depth = health.persist_depth;
  const max = health.persist_lag_max_seconds;
  return {
    router: health.router_queue ?? null,
    lag: health.backbone?.routerLag ?? null,
    persist: depth && typeof depth === "object" ? total(Object.values(depth).map((v) => (typeof v === "number" ? v : null))) : null,
    persistLagSeconds: health.persist_lag_seconds ?? null,
    retry: total([health.routing_retry_queue, health.backbone?.retryDepth]),
    persistLagMax: max != null && max > 0 ? max : PERSIST_LAG_MAX_DEFAULT,
  };
}

/** The last {@link QUEUE_SAMPLES} readings of each node's queue, oldest first. */
export type QueueHistory = ReadonlyMap<string, readonly QueueSample[]>;

export const EMPTY_QUEUE_HISTORY: QueueHistory = new Map();

/**
 * One health reading into the answering node's queue history: a sample at the snapshot's own
 * `observed_at` (so a health answer read twice is one sample), the oldest dropped past
 * {@link QUEUE_SAMPLES}. A different node answering starts that node's own history.
 */
export function foldQueue(history: QueueHistory, health: Health | null | undefined): QueueHistory {
  const queue = nodeQueueOf(health);
  if (!health || !queue) {
    return history;
  }
  const node = answeringNode(health);
  const kept = history.get(node) ?? [];
  const parsed = Date.parse(health.observed_at);
  const at = Number.isFinite(parsed) ? parsed : (kept.at(-1)?.at ?? 0) + 5_000;
  if (kept.length && kept.at(-1)!.at >= at) {
    return history;
  }
  const next = new Map(history);
  next.set(node, [...kept, { at, queue: queueTotal(queue) }].slice(-QUEUE_SAMPLES));
  return next;
}
