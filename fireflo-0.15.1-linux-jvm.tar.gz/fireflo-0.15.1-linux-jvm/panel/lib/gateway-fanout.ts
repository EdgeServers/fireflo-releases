import { recordGatewayCall } from "./db-trace.ts";
import { GatewayError, LIVE_CALL_MS, PANEL_CODES, gqlData, hostOf, isSlowError, isTimeoutFailure, isUnreachableError } from "./gateway-graphql-core.ts";
import { opsUrlResolver } from "./gateway-ops-urls.ts";
import { HEALTH_API, HEALTH_CLUSTER } from "./gateway-queries.ts";
import type { ClusterNode, HealthClusterField } from "./health-types.ts";

/**
 * One read asked of every node of a cluster, for an answer only each node holds (0.15.1).
 *
 * <p>Nothing in the panel did this before: every gateway call goes to one node (`resolveOps`), which
 * is right for anything stored in the database or the backbone. The live series is held in each
 * node's memory -- a node counts what it accepted and what it decided -- so the cluster's figure is
 * the sum of every node's answer.
 *
 * <ul>
 *   <li><b>The answering node first, and directly.</b> The node `resolveOps` chose is called with no
 *       probe before it (0.15.1): it is the configured main node, and probing it first only gave a
 *       busy gateway two chances to look absent. Its failure is the caller's to handle (the stats
 *       readers fall back to the database, the live routes keep their last answer); there is no
 *       cluster figure without it. A listed peer that is the main node -- by id, or by URL when the
 *       node does not name itself -- is never asked a second time.</li>
 *   <li><b>Then every other alive node</b> the answering node lists with an `opsUrl`, in parallel,
 *       with the same read token: a {@link PROBE_MS} probe (does it answer, and does it have the
 *       capability?) and a {@link CALL_MS} call. A peer that does not answer is named in `partial`
 *       and its share is missing from the sum -- the page says so rather than showing a smaller
 *       number as if it were the whole. A peer that timed out (probe or call) is also named in
 *       `slow`: it is there, under load, and is asked again next time rather than remembered as
 *       absent.</li>
 *   <li><b>A node not alive is not asked.</b> Its heartbeat has lapsed; whatever it counted went
 *       with it.</li>
 *   <li><b>The node list outlives a slow answer.</b> When the main node cannot give its cluster
 *       list in time, the last list it gave is used, so a slow moment drops no peers.</li>
 * </ul>
 *
 * <p>Database-free and injectable ({@link FanoutDeps}), so the sum and the partial and slow marking
 * are tested without a gateway (`gateway-fanout.test.ts`).
 */

/** How long a peer may take to answer the probe before it counts as slow. */
export const PROBE_MS = 5_000;
/** How long a node may take to answer the read itself before it counts as slow. */
export const CALL_MS = LIVE_CALL_MS;
/** How long the cluster's node list is kept. */
const PEERS_TTL_MS = 30_000;

/** Another node to ask: its id and its management port. */
export interface FanoutNode {
  nodeId: string;
  opsUrl: string;
}

export interface FanoutDeps<T> {
  /** The answering node's read. Throws (a {@link GatewayError}) when it cannot be had. */
  local(): Promise<T>;
  /**
   * The answering node's id and the other alive nodes with a management port; none outside a
   * cluster. `mainUrl`, when known, is the URL the answering node is called on.
   */
  peers(): Promise<ClusterPeers>;
  /**
   * Whether a peer answers, and can answer this read, within {@link PROBE_MS}: "slow" when it
   * timed out. Never asked of the answering node.
   */
  probe(node: FanoutNode): Promise<boolean | "slow">;
  /** The read on a peer, within {@link CALL_MS}. */
  call(node: FanoutNode): Promise<T>;
}

export interface FanoutResult<T> {
  /** Every answer: the answering node's first, then each peer's that came back. */
  answers: T[];
  /** The peers that were asked and did not answer, by node id: their share is missing. */
  partial: string[];
  /** The peers in `partial` that timed out rather than refused: there, but slow. */
  slow: string[];
}

/** The cluster as the answering node lists it. */
export interface ClusterPeers {
  selfId: string | null;
  nodes: FanoutNode[];
  /** The answering node's own management URL, so a list that does not name it still skips it. */
  mainUrl?: string;
}

const sameUrl = (a: string | undefined, b: string) => !!a && a.replace(/\/+$/, "") === b.replace(/\/+$/, "");

/** The answering node's read, then every peer's; see the module comment for the rules. */
export async function fanOut<T>(deps: FanoutDeps<T>): Promise<FanoutResult<T>> {
  //the local read and the node list together: the list is cached, the read is not -- and the
  //local read is the call itself, with nothing asked of the main node before it
  const [local, peers] = await Promise.all([
    deps.local(),
    deps.peers().catch((): ClusterPeers => ({ selfId: null, nodes: [] })),
  ]);
  const others = peers.nodes.filter((n) => n.nodeId !== peers.selfId && !sameUrl(peers.mainUrl, n.opsUrl));
  type Settled = { node: FanoutNode; value: T | null; slow: boolean };
  const settled = await Promise.all(
    others.map(async (node): Promise<Settled> => {
      try {
        const probed = await deps.probe(node);
        if (probed !== true) {
          return { node, value: null, slow: probed === "slow" };
        }
        return { node, value: await deps.call(node), slow: false };
      } catch (err) {
        return { node, value: null, slow: isSlowError(err) };
      }
    })
  );
  const answers: T[] = [local];
  const partial: string[] = [];
  const slow: string[] = [];
  for (const s of settled) {
    if (s.value === null) {
      partial.push(s.node.nodeId);
      if (s.slow) {
        slow.push(s.node.nodeId);
      }
    } else {
      answers.push(s.value);
    }
  }
  return { answers, partial: partial.sort(), slow: slow.sort() };
}

/**
 * The other nodes worth asking, from the cluster list: alive, with a management port, not the
 * answering node. Pure, for the test.
 */
export function peersOf(cluster: HealthClusterField | null | undefined): ClusterPeers {
  const selfId = cluster?.nodeId?.trim() || null;
  const nodes = (cluster?.cluster?.nodes ?? [])
    .filter((n: ClusterNode) => n.alive && !!n.opsUrl?.trim() && n.nodeId !== selfId)
    .map((n) => ({ nodeId: n.nodeId, opsUrl: n.opsUrl!.trim().replace(/\/$/, "") }));
  return { selfId, nodes };
}

let peersCache: { at: number; value: ClusterPeers } | null = null;

/**
 * The answering node's view of the cluster, kept {@link PEERS_TTL_MS}: the capability map first
 * (`node_identity`), because a 0.13 gateway refuses the cluster selection and there is no cluster
 * to ask there anyway. Asked beside the main node's read, never before it. When the main node is
 * slow to give the list, or refuses it, the last list it gave is used: a slow moment must not drop
 * every peer from the sum.
 */
export async function clusterPeers(): Promise<ClusterPeers> {
  const mainUrl = await opsUrlResolver().resolve().catch(() => undefined);
  if (peersCache && Date.now() - peersCache.at < PEERS_TTL_MS) {
    return { ...peersCache.value, mainUrl };
  }
  try {
    const health = await gqlData<{ api?: Record<string, boolean> }>({ query: HEALTH_API, timeoutMs: PROBE_MS });
    const value = health?.api?.node_identity === true
      ? peersOf(await gqlData<HealthClusterField>({ query: HEALTH_CLUSTER, timeoutMs: PROBE_MS }))
      : { selfId: null, nodes: [] };
    peersCache = { at: Date.now(), value };
    return { ...value, mainUrl };
  } catch (err) {
    if (peersCache) {
      return { ...peersCache.value, mainUrl };
    }
    throw err;
  }
}

/**
 * One document on one named node, with the read token: the transport `executeGql` uses, without
 * its node resolution (the node is the point here). Throws a {@link GatewayError}.
 */
export async function postToNode<T>(
  node: FanoutNode,
  query: string,
  variables: Record<string, unknown> | undefined,
  timeoutMs: number
): Promise<T> {
  const token = process.env.GATEWAY_OPS_TOKEN?.trim();
  if (!token) {
    throw new GatewayError(503, PANEL_CODES.notConfigured, "GATEWAY_OPS_TOKEN is not set.");
  }
  let res: Response;
  let json: { data?: Record<string, unknown> | null; errors?: { message?: unknown }[] } | null;
  //for the footer's data-source stat (db-trace.ts), like executeGql: the round trip, answered or not
  const started = performance.now();
  try {
    res = await fetch(`${node.opsUrl}/graphql`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify(variables === undefined ? { query } : { query, variables }),
      signal: AbortSignal.timeout(timeoutMs),
      cache: "no-store",
    });
    json = (await res.json().catch(() => null)) as typeof json;
  } catch (err) {
    recordGatewayCall(hostOf(node.opsUrl), performance.now() - started);
    if (isTimeoutFailure(err)) {
      throw new GatewayError(502, PANEL_CODES.slow, `Node ${node.nodeId} is slow: no answer within ${timeoutMs / 1000} s.`);
    }
    throw new GatewayError(502, PANEL_CODES.unreachable, `Could not reach node ${node.nodeId}: ${err instanceof Error ? err.message : err}`);
  }
  recordGatewayCall(hostOf(node.opsUrl), performance.now() - started);
  if (!res.ok || json?.errors?.length || json?.data == null) {
    const message = typeof json?.errors?.[0]?.message === "string" ? json.errors[0].message : `Node ${node.nodeId} answered ${res.status}`;
    throw new GatewayError(502, PANEL_CODES.refused, message);
  }
  const keys = Object.keys(json.data);
  return (keys.length === 1 ? json.data[keys[0]] : json.data) as T;
}

const probes = new Map<string, { at: number; ok: boolean }>();
/** A peer that answered is not probed again for this long; one that did not, for a third of it. */
const PROBE_TTL_MS = 30_000;

/**
 * Whether a peer answers within {@link PROBE_MS} and publishes the capability; "slow" when it timed
 * out. Kept per node and URL, so a page polling every few seconds does not probe every node every
 * time -- except a slow answer, which is not kept: the peer is there and is asked again next time.
 */
export async function probeNode(node: FanoutNode, capability: string): Promise<boolean | "slow"> {
  const key = `${node.nodeId}|${node.opsUrl}|${capability}`;
  const kept = probes.get(key);
  if (kept && Date.now() - kept.at < (kept.ok ? PROBE_TTL_MS : PROBE_TTL_MS / 3)) {
    return kept.ok;
  }
  let ok = false;
  try {
    const health = await postToNode<{ api?: Record<string, boolean> }>(node, HEALTH_API, undefined, PROBE_MS);
    ok = health?.api?.[capability] === true;
  } catch (err) {
    if (isSlowError(err)) {
      return "slow";
    }
    ok = false;
  }
  probes.set(key, { at: Date.now(), ok });
  return ok;
}

/** How long a capability answer is kept: a gateway upgraded under the page is seen within it. */
const CAPABILITY_TTL_MS = 30_000;

/**
 * One capability of the main node, learnt from the calls themselves rather than from a probe before
 * them (0.15.1).
 *
 * <ul>
 *   <li><b>Unknown is yes.</b> {@link known} is null until the gateway has said either way, and a
 *       caller then makes the call: an answer is a yes.</li>
 *   <li><b>A refusal asks afterwards.</b> A call refused for any reason but slowness or absence
 *       asks the capability map ({@link PROBE_MS}) once the call is over, so a gateway without the
 *       field is told apart from one that refused it, and that answer is kept.</li>
 *   <li><b>Slow and absent are remembered apart</b> ({@link recentlyFailed}): a reader with a
 *       fallback of its own (the stats pages' database) uses it for a while instead of waiting on a
 *       busy gateway; a live route asks again on its next poll.</li>
 * </ul>
 */
export interface Capability {
  /** What the gateway last said about the capability, within the TTL; null when it has not said. */
  known(): boolean | null;
  /** Whether the last call failed slow or unreachable within the TTL. */
  recentlyFailed(): boolean;
  /** Runs one read of the main node, learning from its outcome; rethrows its failure. */
  call<T>(read: () => Promise<T>): Promise<T>;
  forget(): void;
}

export function createCapability(
  name: string,
  ask: () => Promise<Record<string, boolean> | null | undefined> = async () =>
    (await gqlData<{ api?: Record<string, boolean> }>({ query: HEALTH_API, timeoutMs: PROBE_MS }))?.api,
  now: () => number = Date.now,
  ttlMs = CAPABILITY_TTL_MS
): Capability {
  let said: { at: number; value: boolean } | null = null;
  let failed: number | null = null;
  return {
    known() {
      return said && now() - said.at < ttlMs ? said.value : null;
    },
    recentlyFailed() {
      return failed !== null && now() - failed < ttlMs;
    },
    async call<T>(read: () => Promise<T>): Promise<T> {
      try {
        const value = await read();
        said = { at: now(), value: true };
        failed = null;
        return value;
      } catch (err) {
        if (isSlowError(err) || isUnreachableError(err)) {
          failed = now();
          throw err;
        }
        //refused: is it the field this gateway does not have? Asked after the call, never before
        try {
          said = { at: now(), value: (await ask())?.[name] === true };
        } catch {
          //the map could not be had either: nothing learnt
        }
        throw err;
      }
    },
    forget() {
      said = null;
      failed = null;
    },
  };
}
