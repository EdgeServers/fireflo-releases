import type { DbPool } from "./db-trace.ts";

/**
 * The panel's own two PostgreSQL pools, as GET /api/control/database/pools reports them for the
 * Queues page's Database card ("Connection · panel → PostgreSQL", 0.15.1).
 *
 * <p>`metrics` reads the reports (METRICS_DATABASE_URL), `config` writes the settings
 * (CONFIG_DATABASE_URL). <strong>Never a credential:</strong> `host` is `endpointLabel`'s
 * "db.internal (10.128.0.2):5432", built from the URL's host and port alone, and null when the
 * variable is unset. The counts are pg's own (`totalCount`, `idleCount`, `waitingCount`); the last
 * read is the last traced call on that pool in this process (`db-trace.ts`).
 *
 * <p>Pure, given its readers, so the shape is tested without a database.
 */

export interface PoolReport {
  /** Where the pool points, without user or password; null when its URL is not set. */
  host: string | null;
  /** The pool's ceiling. */
  size: number;
  /** Connections open now, idle among them, and callers waiting for one. */
  open: number;
  idle: number;
  waiting: number;
  /** The last traced read on this pool, ms; null before the first. */
  lastReadMs: number | null;
}

export type PoolsReport = Record<DbPool, PoolReport>;

export interface PoolReaders {
  label: (pool: DbPool) => Promise<string | null>;
  stats: (pool: DbPool) => { max: number; total: number; idle: number; waiting: number };
  lastReadMs: (pool: DbPool) => number | null;
}

export async function poolsReport(readers: PoolReaders): Promise<PoolsReport> {
  const one = async (pool: DbPool): Promise<PoolReport> => {
    const s = readers.stats(pool);
    const last = readers.lastReadMs(pool);
    return {
      host: await readers.label(pool).catch(() => null),
      size: s.max,
      open: s.total,
      idle: s.idle,
      waiting: s.waiting,
      lastReadMs: last == null ? null : Math.round(last),
    };
  };
  const [metrics, config] = await Promise.all([one("metrics"), one("config")]);
  return { metrics, config };
}
