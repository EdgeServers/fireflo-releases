/**
 * The `X-FireFlo-Source` response header: where a route's answer came from and what it cost.
 *
 * <pre>
 * X-FireFlo-Source: db=10.128.0.2:5432;db_ms=128.4;db_calls=3;db_max=96.1;pool=metrics;cached=1;gw=127.0.0.1:9000;gw_ms=45.0;gw_calls=1;gw_max=45.0
 * </pre>
 *
 * <ul>
 *   <li>`db*` only when the request read PostgreSQL, `gw*` only when it called the gateway;</li>
 *   <li>`db` is the database server (`lib/db-endpoint.ts`; several pools on different servers are
 *       comma-separated), `pool` which of the panel's pools were read;</li>
 *   <li>`*_ms` the sum of the calls, `*_max` the slowest, in milliseconds to a tenth;</li>
 *   <li>`cached=1` when every database call is an earlier read's, kept and served again
 *       (`stats-cache.ts`): the times are that read's, and the footer says "from cache";
 *       `gw_cached=1` the same for the gateway calls.</li>
 * </ul>
 *
 * <p>Imported by the browser as well as the server, so it has no imports at all.
 */

export const SOURCE_HEADER = "X-FireFlo-Source";

export interface SourceSide {
  host: string;
  ms: number;
  calls: number;
  max: number;
  /** Every call on this side was served from a kept answer. */
  cached: boolean;
}

export interface SourceSummary {
  db: (SourceSide & { pools: string[] }) | null;
  gateway: SourceSide | null;
}

/** `;` and `=` delimit the header, and a newline would end it: neither can be in a value. */
function clean(v: string): string {
  return v.replace(/[;=\r\n]/g, "");
}

function ms(v: number): string {
  return (Math.round(v * 10) / 10).toFixed(1);
}

/** The header's value, or null when the request made no call worth reporting. */
export function encodeSource(s: SourceSummary): string | null {
  const parts: string[] = [];
  if (s.db) {
    parts.push(
      `db=${clean(s.db.host)}`,
      `db_ms=${ms(s.db.ms)}`,
      `db_calls=${s.db.calls}`,
      `db_max=${ms(s.db.max)}`,
      `pool=${clean(s.db.pools.join(","))}`
    );
    if (s.db.cached) {
      parts.push("cached=1");
    }
  }
  if (s.gateway) {
    parts.push(
      `gw=${clean(s.gateway.host)}`,
      `gw_ms=${ms(s.gateway.ms)}`,
      `gw_calls=${s.gateway.calls}`,
      `gw_max=${ms(s.gateway.max)}`
    );
    if (s.gateway.cached) {
      parts.push("gw_cached=1");
    }
  }
  if (!parts.length) {
    return null;
  }
  return parts.join(";");
}

function num(v: string | undefined): number {
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 ? n : 0;
}

/** The header read back; null when absent or carrying nothing recognisable. */
export function parseSource(header: string | null | undefined): SourceSummary | null {
  if (!header) {
    return null;
  }
  const f = new Map<string, string>();
  for (const part of header.split(";")) {
    const at = part.indexOf("=");
    if (at > 0) {
      f.set(part.slice(0, at).trim(), part.slice(at + 1).trim());
    }
  }
  const db = f.has("db")
    ? {
        host: f.get("db") ?? "",
        ms: num(f.get("db_ms")),
        calls: Math.max(1, Math.round(num(f.get("db_calls")))),
        max: num(f.get("db_max") ?? f.get("db_ms")),
        pools: (f.get("pool") ?? "").split(",").filter(Boolean),
        cached: f.get("cached") === "1",
      }
    : null;
  const gateway = f.has("gw")
    ? {
        host: f.get("gw") ?? "",
        ms: num(f.get("gw_ms")),
        calls: Math.max(1, Math.round(num(f.get("gw_calls")))),
        max: num(f.get("gw_max") ?? f.get("gw_ms")),
        cached: f.get("gw_cached") === "1",
      }
    : null;
  if (!db && !gateway) {
    return null;
  }
  return { db, gateway };
}
