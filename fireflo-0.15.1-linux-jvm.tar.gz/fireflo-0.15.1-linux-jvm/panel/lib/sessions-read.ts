import type { GqlOutcome } from "./gateway-graphql-core";
import { isUnknownFieldError } from "./throughput.ts";

/**
 * The operator `sessions` query, asked with the 0.15.1 fields and, from a gateway that refuses them
 * by name, without them.
 *
 * <p>`loginTpsLimit` and `limitSource` say which limit a session runs under; a gateway before 0.15.1
 * rejects the whole document over either. Asking the capability map first would be a second round
 * trip on a call the Status tab makes every five seconds per listener, so the richer document is
 * simply tried, and a refusal of a field is remembered: the next ten minutes go straight to the
 * plain one, then the richer one is tried again in case the gateway was upgraded meanwhile.
 */

/** How long a refusal is remembered before the richer document is tried again. */
export const LEGACY_MEMORY_MS = 10 * 60_000;

export type SessionsExecutor = <T>(call: { query: string; variables: Record<string, unknown>; timeoutMs?: number }) => Promise<GqlOutcome<T>>;

export function createSessionsReader(
  documents: { full: string; legacy: string },
  now: () => number = Date.now
): <T>(exec: SessionsExecutor, variables: Record<string, unknown>) => Promise<GqlOutcome<T>> {
  let legacyUntil = 0;
  return async <T,>(exec: SessionsExecutor, variables: Record<string, unknown>): Promise<GqlOutcome<T>> => {
    if (now() >= legacyUntil) {
      const full = await exec<T>({ query: documents.full, variables, timeoutMs: 10_000 });
      if (full.ok || !isUnknownFieldError(full)) {
        return full;
      }
      legacyUntil = now() + LEGACY_MEMORY_MS;
    }
    return exec<T>({ query: documents.legacy, variables, timeoutMs: 10_000 });
  };
}
