import { strict as assert } from "node:assert";
import { test } from "node:test";
import {
  accountOfKey, bindSummary, ceilingLabel, sessionCeiling, groupByLogin, groupSessions, hostsLabel, loginKey, loginOfKey, overall, receiptRate,
  UNATTRIBUTED,
} from "./session-groups.ts";
import type { HealthSession } from "./health-types.ts";

function session(over: Partial<HealthSession> = {}): HealthSession {
  return { bound: true, bind_type: "TRANSCEIVER", session_id: 1, ...over };
}

test("sessions fold by account, busiest account first", () => {
  const groups = groupSessions([
    session({ account: "globex", submitted: 10, system_id: "GLX" }),
    session({ account: "acme", submitted: 900, system_id: "ACME_TX", bind_type: "TRANSMITTER" }),
    session({ account: "acme", submitted: 40, system_id: "ACME_TX", bind_type: "TRANSMITTER" }),
    session({ account: "acme", system_id: "ACME_RX", bind_type: "RECEIVER" }),
  ]);
  assert.deepEqual(groups.map((g) => g.account), ["acme", "globex"]);
  const acme = groups[0];
  assert.equal(acme.sessions.length, 3);
  assert.deepEqual(acme.logins, ["ACME_TX", "ACME_RX"]);
  assert.deepEqual(acme.counts, { TX: 2, RX: 1, TRX: 0, unbound: 0 });
  assert.equal(acme.received, 940);
});

test("a session the gateway could not attribute groups under a dash, after every named account", () => {
  const groups = groupSessions([
    session({ account: null, submitted: 5000 }),
    session({ account: "acme", submitted: 1 }),
  ]);
  assert.equal(groups[0].account, UNATTRIBUTED);
  assert.equal(groups[0].received, 5000);
});

test("a group that counts nothing sorts after one that counted zero", () => {
  const groups = groupSessions([
    session({ account: "quiet", submitted: null }),
    session({ account: "idle", submitted: 0 }),
  ]);
  assert.deepEqual(groups.map((g) => g.account), ["idle", "quiet"]);
  assert.equal(groups[0].received, 0);
  assert.equal(groups[1].received, null);
});

test("an unbound session is counted apart from the bind kinds", () => {
  const [group] = groupSessions([
    session({ account: "acme" }),
    session({ account: "acme", bound: false, bind_type: "TRANSCEIVER" }),
  ]);
  assert.deepEqual(group.counts, { TX: 0, RX: 0, TRX: 1, unbound: 1 });
  assert.equal(bindSummary(group.counts), "1 TRX · 1 not bound");
});

test("the bind summary names only the kinds present, in TX RX TRX order", () => {
  assert.equal(bindSummary({ TX: 2, RX: 2, TRX: 0, unbound: 0 }), "2 TX · 2 RX");
  assert.equal(bindSummary({ TX: 0, RX: 0, TRX: 3, unbound: 0 }), "3 TRX");
  assert.equal(bindSummary({ TX: 0, RX: 0, TRX: 0, unbound: 0 }), "");
});

test("hosts, age, tps and the shared limit are folded across the binds", () => {
  const [group] = groupSessions([
    session({ account: "acme", host: "10.0.0.7", bound_seconds: 60, tps_measured: 1.5, tps_limit: 50 }),
    session({ account: "acme", host: "10.0.0.7", bound_seconds: 86_400, tps_measured: 2, tps_limit: 50 }),
    session({ account: "acme", host: "10.0.0.9", bound_seconds: null, tps_measured: null, tps_limit: null }),
  ]);
  assert.deepEqual(group.hosts, ["10.0.0.7", "10.0.0.9"]);
  assert.equal(hostsLabel(group.hosts), "10.0.0.7 +1");
  assert.equal(hostsLabel(["10.0.0.7"]), "10.0.0.7");
  assert.equal(hostsLabel([]), "—");
  assert.equal(group.oldest, 86_400);
  assert.equal(group.tps, 3.5);
  assert.equal(group.tpsLimit, 50);
});

test("binds with different limits give the group no single limit", () => {
  const [group] = groupSessions([
    session({ account: "acme", tps_limit: 50 }),
    session({ account: "acme", tps_limit: 20 }),
  ]);
  assert.equal(group.tpsLimit, null);
});

test("receipts sum like submits, and the rate is receipts over submits", () => {
  const [group] = groupSessions([
    session({ account: "acme", submitted: 100, receipts: 98 }),
    session({ account: "acme", submitted: 100, receipts: 90 }),
  ]);
  assert.equal(group.receipts, 188);
  assert.equal(receiptRate(group), 0.94);
  //an older gateway sends no receipts at all: null, never zero, so the column shows a dash
  const [older] = groupSessions([session({ account: "acme", submitted: 100 })]);
  assert.equal(older.receipts, null);
  assert.equal(receiptRate(older), null);
  assert.equal(receiptRate({ received: 0, receipts: 0 }), null);
});

test("overall folds every group into one row", () => {
  const groups = groupSessions([
    session({ account: "acme", submitted: 100, receipts: 90, bind_type: "TRANSMITTER" }),
    session({ account: "globex", submitted: 50, receipts: 50, bind_type: "RECEIVER" }),
  ]);
  const total = overall(groups);
  assert.equal(total.account, "Overall");
  assert.equal(total.received, 150);
  assert.equal(total.receipts, 140);
  assert.deepEqual(total.counts, { TX: 1, RX: 1, TRX: 0, unbound: 0 });
});

test("sessions fold by account and login: one row per login, binds counted, counters summed", () => {
  const rows = groupByLogin([
    session({ session_id: 1, account: "YK201", system_id: "yk201", host: "103.21.8.14", submitted: 400, receipts: 390, tps_measured: 30, bound_seconds: 7200 }),
    session({ session_id: 2, account: "YK201", system_id: "yk201", host: "103.21.8.14", submitted: 600, receipts: 600, tps_measured: 40, bound_seconds: 60 }),
    session({ session_id: 3, account: "YK201", system_id: "yk201b", host: "103.21.8.15", submitted: 50, tps_measured: 100 }),
    session({ session_id: 4, account: "233026", system_id: "otpmsg1", host: "49.37.120.9", bound: false }),
  ]);
  assert.deepEqual(rows.map((r) => [r.account, r.systemId]), [["YK201", "yk201b"], ["YK201", "yk201"], ["233026", "otpmsg1"]]);
  const yk = rows[1];
  assert.equal(yk.binds, 2);
  assert.equal(yk.submitted, 1000);
  assert.equal(yk.receipts, 990);
  assert.equal(yk.tps, 70);
  assert.equal(yk.youngest, 60, "the most recently bound session says how long the login has been fully up");
  assert.deepEqual(yk.hosts, ["103.21.8.14"]);
  assert.equal(yk.members, "1,2");
  //the unbound session is a row with no binds, and counted nothing rather than zero
  assert.equal(rows[2].binds, 0);
  assert.equal(rows[2].submitted, null);
});

test("a login's ceiling and its source are reported only when every session agrees", () => {
  const [row] = groupByLogin([
    session({ session_id: 1, account: "a", system_id: "l", tps_limit: 300, login_tps_limit: 50, limit_source: "LOGIN_MAX_TPS" }),
    session({ session_id: 2, account: "a", system_id: "l", tps_limit: 300, login_tps_limit: 50, limit_source: "LOGIN_MAX_TPS" }),
  ]);
  assert.equal(row.tpsLimit, 300);
  assert.equal(row.loginTpsLimit, 50);
  assert.equal(row.limitSource, "LOGIN_MAX_TPS");
  const [mixed] = groupByLogin([
    session({ session_id: 1, account: "a", system_id: "l", tps_limit: 300, limit_source: "ACCOUNT_OVERRIDE" }),
    session({ session_id: 2, account: "a", system_id: "l", tps_limit: 250 }),
  ]);
  assert.equal(mixed.tpsLimit, null);
  assert.equal(mixed.limitSource, "ACCOUNT_OVERRIDE");
  //an older gateway sends neither: nothing is made up
  const [old] = groupByLogin([session({ account: "a", system_id: "l", tps_limit: 300 })]);
  assert.equal(old.loginTpsLimit, null);
  assert.equal(old.limitSource, null);
});

test("a session with no account or login groups under dashes, and the key splits back into both", () => {
  const [row] = groupByLogin([session({ account: null, system_id: "  " })]);
  assert.equal(row.account, UNATTRIBUTED);
  assert.equal(row.systemId, UNATTRIBUTED);
  const key = loginKey("acct with spaces", "sys.id");
  assert.equal(accountOfKey(key), "acct with spaces");
  assert.equal(loginOfKey(key), "sys.id");
});

test("a session without a number is told apart by its far end", () => {
  const [row] = groupByLogin([
    session({ session_id: null, account: "a", system_id: "l", host: "10.0.0.2", port: 4001 }),
    session({ session_id: null, account: "a", system_id: "l", host: "10.0.0.1", port: 4000 }),
  ]);
  assert.equal(row.members, "10.0.0.1:4000,10.0.0.2:4001");
});

test("the ceiling beside a session says which setting it came from (0.15.1), bare before", () => {
  assert.equal(ceilingLabel(sessionCeiling({ tps_limit: 250, limit_source: "ACCOUNT_OVERRIDE" })!), "≤250 · override");
  assert.equal(ceilingLabel(sessionCeiling({ tps_limit: 300, login_tps_limit: 50, limit_source: "LOGIN_MAX_TPS" })!), "≤50 · login");
  assert.equal(ceilingLabel(sessionCeiling({ tps_limit: 300, limit_source: "LISTENER_DEFAULT" })!), "≤300 · default");
  assert.equal(ceilingLabel(sessionCeiling({ tps_limit: 300 })!), "≤300", "an older gateway: no source, no pill");
  assert.equal(sessionCeiling({ tps_limit: 300, limit_source: "UNLIMITED" }), null);
  assert.equal(sessionCeiling({}), null);
});

test("an account's ceiling source is the binds' agreed one, leaving out binds held by their login", () => {
  const [g] = groupSessions([
    session({ account: "A", tps_limit: 250, limit_source: "ACCOUNT_OVERRIDE" }),
    session({ account: "A", session_id: 2, tps_limit: 250, login_tps_limit: 20, limit_source: "LOGIN_MAX_TPS" }),
  ]);
  assert.equal(g.limitSource, "ACCOUNT_OVERRIDE");
  const [old] = groupSessions([session({ account: "B", tps_limit: 100 })]);
  assert.equal(old.limitSource, null);
});
