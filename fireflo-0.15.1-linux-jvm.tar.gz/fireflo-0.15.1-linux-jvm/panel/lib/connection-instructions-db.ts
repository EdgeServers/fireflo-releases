import { openOrExplain } from "@/lib/secret-box";
import { configQuery } from "@/lib/config-db";
import { getCredential } from "@/lib/credentials";
import { gatewayApiUrl } from "@/lib/playground";
import { accountLimit, type InstructionServer } from "@/lib/connection-instructions";

/**
 * What the connection-instructions mail is composed from, read in one place.
 *
 * <p>Server-only, and the one module in this panel besides `credentials.ts` that selects a login's
 * password as a value. It does so only to put it in a mail the operator has asked to send; the
 * route never returns it to the browser except for Copy, which is the operator asking for the text.
 */

/**
 * Where customers connect from outside, from the panel's environment. Empty when not set.
 *
 * <p>The REST address is `GATEWAY_API_URL`, the same customer-facing address the portal's API
 * playground and reference already print -- one setting, so the mail and the docs cannot disagree.
 */
export function publicDefaults(): { host: string; restUrl: string } {
  return {
    host: (process.env.FIREFLO_PUBLIC_HOST ?? "").trim(),
    restUrl: gatewayApiUrl() ?? "",
  };
}

export interface InstructionSource {
  credentialId: number;
  type: "SMPP" | "HTTP";
  username: string;
  /** True when the username is an HTTP login's API key, which is a secret like the password. */
  usernameIsSecret: boolean;
  password: string | null;
  /** Why the stored password could not be read (sealed, and this panel has no key), or null. */
  passwordProblem: string | null;
  allowedIps: string[];
  product: string | null;
  account: { id: string; label: string; email: string | null };
  /** Enabled listeners, each with this account's limits on it. Empty for an HTTP login. */
  servers: InstructionServer[];
}

/**
 * @returns null when the login does not exist, has no name to authenticate with, or is of a type
 *     a customer does not connect with
 */
export async function loadInstructionSource(id: number): Promise<InstructionSource | null> {
  const credential = await getCredential(id);
  if (!credential || (credential.type !== "SMPP" && credential.type !== "HTTP")) {
    return null;
  }
  const [secret] = await configQuery<{ password: string | null; api_key: string | null }>(
    "SELECT password, api_key FROM app_credential WHERE id = $1",
    [id]
  );
  //what the gateway authenticates against: the system id, or an HTTP login's API key when it has
  //one (`Credential.getLookupKey()`, mirrored by `lookupKey` here)
  const username = credential.type === "HTTP" && secret?.api_key ? secret.api_key : credential.systemId;
  if (!username) {
    return null;
  }
  //sealed at rest when FIREFLO_SECRETS_KEY is set; a value this panel cannot open is said, not shown
  const opened = openOrExplain(secret?.password || null);

  const accountId = credential.billingAccount ?? credential.accountId ?? "";
  const [account] = accountId
    ? await configQuery<{ id: string; label: string | null; email: string | null }>(
        "SELECT id, label, email FROM app_account WHERE id = $1",
        [accountId]
      )
    : [];

  return {
    credentialId: id,
    type: credential.type,
    username,
    usernameIsSecret: credential.type === "HTTP" && !!secret?.api_key,
    password: opened.value || null,
    passwordProblem: opened.problem,
    allowedIps: credential.allowedIps,
    product: credential.product,
    account: {
      id: accountId,
      label: account?.label?.trim() || accountId || username,
      email: account?.email ?? null,
    },
    servers: credential.type === "SMPP" ? await listenersFor(accountId) : [],
  };
}

/**
 * Every enabled SMPP listener that takes connections, with the limits this account meets on it.
 *
 * <p>The rate and the binds are the account's own `conf.maxRate.<account>` /
 * `conf.maxConnectionsPerUser.<account>` when there is one, else the listener's default -- and each
 * of those from the gateway-wide `outSms.default.*` row when the listener has none (`accountLimit`),
 * the order the gateway resolves them in. A listener whose port is 0 and has no TLS port does not
 * start, so it is not a server anyone can be sent to.
 */
async function listenersFor(accountId: string): Promise<InstructionServer[]> {
  const perAccount = accountId ? [`conf.maxRate.${accountId}`, `conf.maxConnectionsPerUser.${accountId}`] : [];
  const rows = await configQuery<{ name: string; key: string; value: string | null }>(
    `SELECT w.name, p.key, p.value
       FROM app_worker w
       JOIN app_worker_property p ON p.worker_name = w.name
      WHERE w.type = 'smppserver' AND w.enabled
        AND (p.key IN ('srv.public.host', 'srv.host', 'srv.port', 'srv.tls.enabled', 'srv.tls.port', 'conf.maxRate.default',
                       'conf.maxConnectionsPerUser.default', 'conf.maxPending.default')
             OR p.key = ANY($1::text[]))
      ORDER BY w.name`,
    [perAccount]
  );
  //the gateway-wide tier: one row here caps every listener that has none of its own
  const gatewayKeys = ["conf.maxRate.default", "conf.maxConnectionsPerUser.default", "conf.maxPending.default", ...perAccount]
    .map((k) => `outSms.default.${k}`);
  const gatewayRows = await configQuery<{ key: string; value: string | null }>(
    "SELECT key, value FROM app_config WHERE key = ANY($1::text[]) AND enabled",
    [gatewayKeys]
  );
  const gateway = new Map(gatewayRows.map((r) => [r.key, r.value ?? ""] as const));
  const byName = new Map<string, Map<string, string>>();
  for (const r of rows) {
    const props = byName.get(r.name) ?? new Map<string, string>();
    props.set(r.key, r.value ?? "");
    byName.set(r.name, props);
  }

  const servers: InstructionServer[] = [];
  for (const [name, p] of byName) {
    const port = positive(p.get("srv.port"));
    const tlsPort = p.get("srv.tls.enabled") === "true" ? positive(p.get("srv.tls.port")) : null;
    if (!port && !tlsPort) {
      continue;
    }
    //the listener's Public IP first: it is the one setting that exists to say this
    const publicIp = publicAddress(p.get("srv.public.host"));
    const own = publicAddress(p.get("srv.host"));
    const panel = publicDefaults().host || null;
    servers.push({
      name,
      host: publicIp ?? own ?? panel,
      hostSource: publicIp ? "public" : own ? "listener" : panel ? "panel" : null,
      port,
      tlsPort,
      maxRate: accountLimit(p, gateway, "conf.maxRate", accountId),
      maxBinds: accountLimit(p, gateway, "conf.maxConnectionsPerUser", accountId),
      maxPending: whole(p.get("conf.maxPending.default") ?? gateway.get("outSms.default.conf.maxPending.default")),
    });
  }
  return servers;
}

/**
 * A listener's `srv.public.host` or `srv.host` when it names somewhere a customer can reach: not empty, not a wildcard
 * bind address, not this machine's loopback.
 */
function publicAddress(raw: string | undefined): string | null {
  const host = (raw ?? "").trim();
  if (!host || /^(0\.0\.0\.0|::|\[::\]|\*|localhost|127\.\d+\.\d+\.\d+|::1)$/i.test(host)) {
    return null;
  }
  return host;
}

function whole(raw: string | undefined): number | null {
  if (raw === undefined || raw.trim() === "") {
    return null;
  }
  const n = Number(raw);
  return Number.isInteger(n) && n >= 0 ? n : null;
}

function positive(raw: string | undefined): number | null {
  const n = whole(raw);
  return n && n > 0 ? n : null;
}
