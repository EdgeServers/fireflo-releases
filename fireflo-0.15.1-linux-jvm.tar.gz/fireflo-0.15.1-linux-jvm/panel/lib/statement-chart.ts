/**
 * The statement's per-day chart, split like its table (0.15.1): one stacked bar segment per product
 * or login, the biggest few by money and the rest as "Other", with the day's billed total beside.
 * Database- and React-free, so the folding is tested on its own.
 */

/** Segments drawn before the rest fold into "Other": six palette colours, one kept for Other. */
export const CHART_KEYS = 5;

/** The data key a series is drawn under: never the raw key, which may be "" or any text. */
export type SeriesId = `k${number}` | "other";

export interface StackedChart {
  /** In stacking order: the biggest key first, "Other" last when there is one. */
  series: { id: SeriesId; key: string | null; label: string }[];
  /** One point per day: the day, each series' messages, and `price` (the day's billed total). */
  data: Array<{ day: string; price: number } & Partial<Record<SeriesId, number>>>;
}

/**
 * The login `''` stands for, in words. It is never one login: it is the messages that named none,
 * and -- on days the gateway summarised before it recorded logins (0.15.1, V1.115.0) -- every
 * login's traffic together. So it is labelled as that, never offered as a login to filter by.
 */
export const NO_LOGIN_LABEL = "(no login / all logins before 0.15.1)";

/** How a key is shown, as the table shows it: `''` is no product, or {@link NO_LOGIN_LABEL}. */
export function keyLabel(key: string, split: "product" | "login"): string {
  return key === "" ? (split === "login" ? NO_LOGIN_LABEL : "no product") : key;
}

/**
 * Folds the days' per-key breakdown into at most {@link CHART_KEYS} named series plus "Other",
 * choosing the named ones by their share of the money (`lines`, already biggest first).
 */
export function stackedDays(
  days: { day: string; price: number; byKey?: Record<string, { submitted: number; amount: number }> }[],
  lines: { product: string }[],
  split: "product" | "login"
): StackedChart {
  const named = lines.slice(0, CHART_KEYS).map((l) => l.product);
  const idOf = new Map<string, SeriesId>(named.map((key, i) => [key, `k${i}` as SeriesId]));
  const folded = lines.length > CHART_KEYS;
  const series: StackedChart["series"] = named.map((key, i) => ({ id: `k${i}` as SeriesId, key, label: keyLabel(key, split) }));
  if (folded) {
    series.push({ id: "other", key: null, label: "Other" });
  }
  const data = days.map((d) => {
    const point: StackedChart["data"][number] = { day: d.day, price: d.price };
    for (const [key, part] of Object.entries(d.byKey ?? {})) {
      const id = idOf.get(key) ?? "other";
      point[id] = (point[id] ?? 0) + part.submitted;
    }
    return point;
  });
  return { series, data };
}
