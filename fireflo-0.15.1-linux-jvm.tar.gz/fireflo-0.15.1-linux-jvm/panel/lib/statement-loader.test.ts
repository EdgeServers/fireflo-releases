import { strict as assert } from "node:assert";
import { test } from "node:test";

import { StatementLoader, periodQuery, type LoaderDeps, type StatementLoadState } from "./statement-loader.ts";

type Answer = { status: number; body: unknown };

/** A loader over a scripted `fetch` and hand-run timers. */
function rig(script: Answer[] | ((url: string) => Promise<Answer>)) {
  const calls: string[] = [];
  const timers: { fn: () => void; ms: number }[] = [];
  const states: StatementLoadState<unknown>[] = [];
  const deps: LoaderDeps = {
    fetch: async (url, init) => {
      calls.push(url);
      const a = typeof script === "function" ? await script(url) : script.shift()!;
      if (init.signal.aborted) {
        throw new DOMException("aborted", "AbortError");
      }
      return { ok: a.status >= 200 && a.status < 300, status: a.status, json: async () => a.body };
    },
    setTimer: (fn, ms) => {
      timers.push({ fn, ms });
      return timers.length;
    },
    clearTimer: () => undefined,
    onChange: (s) => states.push(s),
  };
  const loader = new StatementLoader<{ label: string }>(deps);
  return { loader, calls, timers, states };
}

const settle = () => new Promise((r) => setTimeout(r, 0));

test("nothing is fetched until Show", async () => {
  //picking a month or a date range only edits the draft; the page calls show() on the button
  const { loader, calls } = rig([{ status: 200, body: { data: { label: "2026-09" } } }]);
  await settle();
  assert.equal(calls.length, 0);
  loader.show("/s?month=2026-09");
  await settle();
  assert.deepEqual(calls, ["/s?month=2026-09"]);
  assert.equal(loader.current.data?.label, "2026-09");
  assert.equal(loader.current.loading, false);
});

test("a 202 keeps the breathing card up and asks again after retryAfter", async () => {
  const { loader, calls, timers } = rig([
    { status: 202, body: { busy: true, retryAfter: 15 } },
    { status: 202, body: { busy: true, retryAfter: 15 } },
    { status: 200, body: { data: { label: "2026-09" } } },
  ]);
  loader.show("/s?month=2026-09");
  await settle();
  assert.equal(loader.current.busy, true, "the breathing card");
  assert.equal(loader.current.loading, true, "and the Show button still sweeps");
  assert.equal(loader.current.error, "", "never an error");
  assert.equal(timers.at(-1)!.ms, 15_000);
  timers.at(-1)!.fn();
  await settle();
  assert.equal(loader.current.busy, true);
  timers.at(-1)!.fn();
  await settle();
  assert.equal(calls.length, 3);
  assert.equal(loader.current.busy, false);
  assert.equal(loader.current.data?.label, "2026-09");
});

test("only the newest Show lands", async () => {
  let release: (a: Answer) => void = () => undefined;
  const slow = new Promise<Answer>((r) => { release = r; });
  const { loader } = rig(async (url) =>
    url.includes("2026-08") ? slow : { status: 200, body: { data: { label: "2026-09" } } });
  loader.show("/s?month=2026-08");
  loader.show("/s?month=2026-09");
  await settle();
  release({ status: 200, body: { data: { label: "2026-08" } } });
  await settle();
  assert.equal(loader.current.data?.label, "2026-09", "the late August answer is dropped");
});

test("a different period clears the figures; the same one keeps them while it is re-read", async () => {
  const { loader } = rig([
    { status: 200, body: { data: { label: "2026-09" } } },
    { status: 202, body: { busy: true, retryAfter: 15 } },
    { status: 202, body: { busy: true, retryAfter: 15 } },
  ]);
  loader.show("/s?month=2026-09");
  await settle();
  loader.show("/s?month=2026-09");
  assert.equal(loader.current.data?.label, "2026-09", "a re-read after closing keeps the page");
  await settle();
  loader.show("/s?month=2026-08");
  assert.equal(loader.current.data, null, "September's figures never sit under August's label");
});

test("an error is the server's sentence, and clears the busy state", async () => {
  const { loader } = rig([
    { status: 202, body: { busy: true, retryAfter: 5 } },
    { status: 500, body: { error: "Could not read the statement: the database took too long." } },
  ]);
  loader.show("/s?month=2026-09");
  await settle();
  loader.show("/s?month=2026-09");
  await settle();
  assert.equal(loader.current.error, "Could not read the statement: the database took too long.");
  assert.equal(loader.current.busy, false);
  assert.equal(loader.current.loading, false);
});

test("a stale answer is passed through for the StaleNote", async () => {
  const stale = { at: "2026-10-28T10:00:00.000Z", reason: "The latest read did not finish." };
  const { loader } = rig([{ status: 200, body: { data: { label: "2026-09" }, stale } }]);
  loader.show("/s?month=2026-09");
  await settle();
  assert.deepEqual(loader.current.stale, stale);
});

test("a date range is refused beside the controls before anything is sent", () => {
  assert.deepEqual(periodQuery({ mode: "month", month: "2026-09", from: "", to: "" }), { query: "month=2026-09" });
  assert.deepEqual(periodQuery({ mode: "range", month: "", from: "2026-08-03", to: "2026-08-17" }),
    { query: "from=2026-08-03&to=2026-08-17" });
  const backwards = periodQuery({ mode: "range", month: "", from: "2026-08-17", to: "2026-08-03" });
  assert.ok("invalid" in backwards && /on or before/.test(backwards.invalid));
  const long = periodQuery({ mode: "range", month: "", from: "2026-01-01", to: "2026-06-30" });
  assert.ok("invalid" in long && /at most 92/.test(long.invalid));
  assert.ok("invalid" in periodQuery({ mode: "range", month: "", from: "", to: "" }));
});

test("each answer that lands is handed to onAnswer with its headers; a dropped one is not", async () => {
  const seen: [string, string | null][] = [];
  let release: (() => void) | null = null;
  const loader = new StatementLoader<{ label: string }>({
    fetch: async (url) => {
      if (url.includes("old")) {
        await new Promise<void>((r) => { release = r; });
      }
      return {
        ok: true, status: 200, json: async () => ({ data: { label: url } }),
        headers: { get: (n: string) => (n === "X-FireFlo-Source" ? `db=h:5432;db_ms=1;db_calls=1;db_max=1;pool=metrics;u=${url}` : null) },
      };
    },
    setTimer: () => 0,
    clearTimer: () => undefined,
    onChange: () => undefined,
    onAnswer: (url, res) => seen.push([url, res.headers?.get("X-FireFlo-Source") ?? null]),
  });
  loader.show("/s?old");
  loader.show("/s?new");
  await settle();
  (release as (() => void) | null)?.();
  await settle();
  assert.deepEqual(seen.map(([u]) => u), ["/s?new"]);
  assert.match(seen[0][1] ?? "", /u=\/s\?new/);
});
