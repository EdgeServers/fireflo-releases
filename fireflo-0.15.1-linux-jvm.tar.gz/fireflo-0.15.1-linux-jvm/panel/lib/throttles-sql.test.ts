import { test } from "node:test";
import assert from "node:assert/strict";
import { MAX_THROTTLE_GROUPS, THROTTLE_RETENTION_DAYS, throttleQuery } from "./throttles-sql.ts";

const now = new Date("2026-10-30T12:00:00Z");

test("the window defaults to the last day and is never older than the table's retention", () => {
  const q = throttleQuery({}, now);
  assert.ok(!("skipped" in q));
  if ("skipped" in q) return;
  assert.equal(q.since.toISOString(), "2026-10-29T12:00:00.000Z");
  assert.equal(q.clamped, false);
  assert.match(q.sql, /WHERE minute >= \$1/);
  assert.deepEqual(q.params, [q.since, MAX_THROTTLE_GROUPS + 1]);

  const old = throttleQuery({ since: new Date("2026-08-01T00:00:00Z"), until: new Date("2026-10-01T00:00:00Z") }, now);
  if ("skipped" in old) return assert.fail("not skipped");
  assert.equal(old.since.getTime(), now.getTime() - THROTTLE_RETENTION_DAYS * 86_400_000);
  assert.equal(old.clamped, true, "the strip says the window was cut");
  assert.match(old.sql, /minute < \$2/);
  assert.equal(old.until?.toISOString(), "2026-10-01T00:00:00.000Z");
});

test("account, login, listener and search are bound parameters, never text", () => {
  const q = throttleQuery({ accountId: "YK201", systemId: "yk201b", inGateway: "dltsmpp", search: "y%k" }, now);
  if ("skipped" in q) return assert.fail("not skipped");
  assert.match(q.sql, /account_id = \$2/);
  assert.match(q.sql, /system_id = \$3/);
  assert.match(q.sql, /\(listener = \$4 OR listener = 'smppserver\.' \|\| \$4\)/);
  assert.match(q.sql, /account_id ILIKE \$5/);
  assert.deepEqual(q.params.slice(1), ["YK201", "yk201b", "dltsmpp", "%y\\%k%", MAX_THROTTLE_GROUPS + 1]);
  assert.ok(!q.sql.includes("YK201"));
  assert.match(q.sql, /GROUP BY account_id, listener, system_id/);
  assert.match(q.sql, /LIMIT \$6/);
});

test("a filter the table cannot honour skips the strip, naming it; HTTP has its own ceiling", () => {
  assert.deepEqual(throttleQuery({ reason: "rateLimited" }, now), { skipped: "reason" });
  assert.deepEqual(throttleQuery({ ingress: "HTTP" }, now), { skipped: "ingress" });
  assert.ok(!("skipped" in throttleQuery({ ingress: "smpp" }, now)), "SMPP is this table's ingress");
  assert.deepEqual(throttleQuery({ product: "otp" }, now), { skipped: "product" });
  assert.deepEqual(throttleQuery({ destAddr: "61" }, now), { skipped: "destination" });
  assert.deepEqual(throttleQuery({ afterAccepting: true }, now), { skipped: "refused after accepting" });
  assert.ok(!("skipped" in throttleQuery({ afterAccepting: false, hasMsgId: false }, now)));
});
