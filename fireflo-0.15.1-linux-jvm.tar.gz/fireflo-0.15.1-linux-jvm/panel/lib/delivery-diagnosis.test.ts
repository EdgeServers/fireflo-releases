import { test } from "node:test";
import assert from "node:assert/strict";
import { diagnose, diagnosisSummary, rateLimitFix, type DiagnosisInput } from "./delivery-diagnosis.ts";
import { reasonLabel } from "./rejected-types.ts";
import type { RouteRule, RouteTable } from "./routing-types.ts";
import type { WhitelistSummary } from "./whitelist-types.ts";

/**
 * The report that has to get the *order* right.
 *
 * <p>Every case here is drawn from the live deployment that prompted it, where the reported symptom
 * was "routing failed" and routing had never failed once. The assertion that matters most is not
 * that a finding appears — it is that the whitelist finding outranks the routing one when the
 * evidence says so, because getting that backwards sends somebody to edit the one part of the
 * configuration that was already correct.
 */

function rule(over: Partial<RouteRule> = {}): RouteRule {
  return {
    id: null, target: "vendor1", copied: false, label: null, enabled: true,
    conditions: [], filters: [], ...over,
  };
}

function table(rules: RouteRule[], over: Partial<RouteTable> = {}): RouteTable {
  return { name: "default", targetFunction: "NORMAL", label: null, enabled: true, rules, ...over };
}

const CONDITION = { field: "to", operator: "startsWith", value: "91", negate: false };

/** A deployment with nothing wrong: catch-all last, vendor bound, no refusals, database mode. */
function healthy(): DiagnosisInput {
  return {
    accountId: null,
    readsFromDatabase: { routing: true, credentials: true, rates: true, workers: true },
    refusals: { summary: [], total: 0, hours: 24 },
    routing: { tables: [table([rule({ conditions: [CONDITION] }), rule()])] },
    workers: [{ name: "vendor1", type: "smppclient", enabled: true, bound: 3 }],
    filters: [],
  };
}

test("a healthy deployment reports nothing at all", () => {
  const findings = diagnose(healthy());

  assert.deepEqual(findings, []);
  assert.equal(diagnosisSummary(findings), null,
    "null, not '0 problems' -- a report that fires when nothing is wrong is one people stop reading");
});

test("THE case this exists for: routing is fine and the whitelist is the outage", () => {
  //the live shape. Every rule correct, vendor bound, and 9,968 messages refused for an unapproved
  //sender ID. A routing-only checker answers "healthy" here, which is how an hour gets spent on
  //the one thing that was never wrong
  const findings = diagnose({
    ...healthy(),
    refusals: {
      summary: [{ reason: "headerNotApproved", count: 9968 }],
      total: 9968,
      hours: 24,
    },
  });

  assert.equal(findings[0].stage, "evidence");
  assert.match(findings[0].headline, /Sender ID not approved/);
  assert.equal(findings[0].severity, "stopping");
  assert.ok(!findings.some((f) => f.stage === "routing"),
    "routing must contribute nothing when routing is correct");
});

test("evidence outranks configuration at the same severity", () => {
  const findings = diagnose({
    ...healthy(),
    //a real refusal happening now
    refusals: { summary: [{ reason: "insufficientCredit", count: 400 }], total: 400, hours: 24 },
    //and a table that would drop anything unmatched, which is also 'stopping'
    routing: { tables: [table([rule({ conditions: [CONDITION] })])] },
  });

  const stopping = findings.filter((f) => f.severity === "stopping");
  assert.equal(stopping[0].stage, "evidence",
    "a refusal that happened outranks one that might");
  assert.ok(stopping.some((f) => f.stage === "routing"), "and the deduced one is still reported");
});

test("a handful of refusals on healthy traffic is not called an outage", () => {
  //3 refusals out of 40,000 attempts. Sharing against refusals rather than traffic would make this
  //100% and call it an outage -- which is the modelling error this test exists to hold shut
  const findings = diagnose({
    ...healthy(),
    refusals: {
      summary: [{ reason: "rateLimited", count: 3 }], total: 3, submitted: 40_000, hours: 24,
    },
  });

  assert.equal(findings[0].severity, "degrading");
  assert.match(findings[0].rule, /100 messages, or 10% of everything attempted/,
    "a badge whose rule is hidden is a colour, not a judgement");
  assert.equal(findings[0].evidence, "3 messages of 40,003 attempted.");
});

test("the same three refusals ARE an outage when they are most of the traffic", () => {
  const findings = diagnose({
    ...healthy(),
    refusals: { summary: [{ reason: "rateLimited", count: 3 }], total: 3, submitted: 5, hours: 24 },
  });

  assert.equal(findings[0].severity, "stopping");
});

test("with no traffic count, only the absolute number is used, and the rule says so", () => {
  const findings = diagnose({
    ...healthy(),
    refusals: { summary: [{ reason: "rateLimited", count: 3 }], total: 3, hours: 24 },
  });

  assert.equal(findings[0].severity, "degrading");
  assert.match(findings[0].rule, /could not be counted/);
});

test("unreadable health is reported as unknown and silences every live-state finding", () => {
  //the regression this design exists to prevent: inferring 'not bound' from 'could not ask' would
  //report an outage every time the ops token is wrong
  const findings = diagnose({
    ...healthy(),
    healthUnavailable: "not-configured",
    workers: [{ name: "vendor1", type: "smppclient", enabled: true }],
  });

  const blind = findings.find((f) => f.key === "config:health-unavailable");
  assert.ok(blind);
  assert.equal(blind.severity, "latent", "not knowing is not an outage");
  assert.ok(!findings.some((f) => f.key.includes("not-bound")));
});

test("a vendor reporting zero sessions IS an outage, because that was actually asked", () => {
  const findings = diagnose({
    ...healthy(),
    workers: [{ name: "vendor1", type: "smppclient", enabled: true, bound: 0 }],
  });

  const down = findings.find((f) => f.key.includes("not-bound"));
  assert.ok(down);
  assert.equal(down.severity, "stopping");
  assert.equal(down.evidence, "0 sessions bound.");
});

test("file mode outranks everything, because nothing below it is in force", () => {
  const findings = diagnose({
    ...healthy(),
    readsFromDatabase: { routing: false, credentials: true, rates: true, workers: true },
    refusals: { summary: [{ reason: "headerNotApproved", count: 5000 }], total: 5000, hours: 24 },
  });

  assert.equal(findings[0].key, "config:file-mode");
  assert.equal(findings[0].severity, "stopping");
});

test("no catch-all is stopping, and offers to add one", () => {
  const findings = diagnose({
    ...healthy(),
    routing: { tables: [table([rule({ conditions: [CONDITION] })])] },
  });

  const gap = findings.find((f) => f.key.endsWith("no-catch-all"));
  assert.ok(gap);
  assert.equal(gap.severity, "stopping");
  assert.deepEqual(gap.apply, { kind: "addCatchAll", table: "default" });
  assert.match(gap.detail, /retried 20 times/);
});

test("a listener with no delivery-receipt return rule is reported, and offers the one-click fix", () => {
  //the live incident this exists to catch: a receipt for an SMPP-ingress message has nowhere to
  //route back to, burns twenty attempts, and drops -- see routing-types.ts's missingDlrReturnRules
  const findings = diagnose({
    ...healthy(),
    workers: [
      { name: "vendor1", type: "smppclient", enabled: true, bound: 3 },
      { name: "smpp", type: "smppserver", enabled: true, bound: 5 },
    ],
  });

  const gap = findings.find((f) => f.key === "routing:dlr-return:smppserver.smpp");
  assert.ok(gap, "a healthy() table has no type==18 rule for the listener, so this must fire");
  assert.equal(gap.severity, "stopping");
  assert.deepEqual(gap.apply, {
    kind: "addSystemReturnRule", workerName: "smpp", workerFullName: "smppserver.smpp",
  });
  assert.match(gap.headline, /smppserver\.smpp/);
});

test("a listener whose table already returns receipts is not reported", () => {
  const findings = diagnose({
    ...healthy(),
    workers: [{ name: "smpp", type: "smppserver", enabled: true, bound: 5 }],
    routing: {
      tables: [table([
        rule({ target: "smppserver.smpp", conditions: [{ field: "type", operator: "==", value: "18", negate: false }] }),
      ])],
    },
  });

  assert.ok(!findings.some((f) => f.key.startsWith("routing:dlr-return:")));
});

test("a catch-all above other rules is degrading, not stopping", () => {
  //it delivers -- to the wrong vendor. That is a different problem from not delivering, and
  //calling both 'stopping' would flatten the distinction an operator triages on
  const findings = diagnose({
    ...healthy(),
    routing: { tables: [table([rule(), rule({ conditions: [CONDITION] })])] },
  });

  const shadow = findings.find((f) => f.key.endsWith("catch-all-early"));
  assert.ok(shadow);
  assert.equal(shadow.severity, "degrading");
  assert.deepEqual(shadow.apply, { kind: "moveCatchAllLast", table: "default" });
});

test("a disabled target is certain where an unrecognised one hedges", () => {
  const off = diagnose({
    ...healthy(),
    workers: [{ name: "vendor1", type: "smppclient", enabled: false, bound: 0 }],
  }).find((f) => f.key.includes("disabled"));
  assert.ok(off);
  assert.equal(off.severity, "stopping");
  assert.match(off.detail, /certain/);
  assert.deepEqual(off.apply, { kind: "enableWorker", worker: "vendor1" });

  const unknown = diagnose({
    ...healthy(),
    routing: { tables: [table([rule({ conditions: [CONDITION] }), rule({ target: "nobody" })])] },
  }).find((f) => f.key.includes("unknown"));
  assert.ok(unknown);
  assert.equal(unknown.severity, "degrading", "the panel may not see every worker");
  assert.match(unknown.detail, /cannot see/);
});

test("a rule referencing a dead filter is reported as skipped whole", () => {
  const findings = diagnose({
    ...healthy(),
    routing: {
      tables: [table([rule({ filters: ["indian-mobiles"] }), rule()])],
    },
    filters: [{ name: "indian-mobiles", enabled: false, conditionCount: 3 }],
  });

  const skipped = findings.find((f) => f.key.endsWith("dead-filter"));
  assert.ok(skipped);
  assert.match(skipped.detail, /skips the whole rule/);
  assert.match(skipped.fix, /serves routing and pricing at once/,
    "re-enabling a filter is not offered as a one-click, and the report says why");
  assert.equal(skipped.apply, undefined);
});

test("a filter with no conditions counts as dead too", () => {
  const findings = diagnose({
    ...healthy(),
    routing: { tables: [table([rule({ filters: ["empty"] }), rule()])] },
    filters: [{ name: "empty", enabled: true, conditionCount: 0 }],
  });

  assert.ok(findings.some((f) => f.key.endsWith("dead-filter")));
});

/** The stages that only fire on their own input. */

test("enforcing with nothing approved is stopping, and offers REPORT", () => {
  const summaries: WhitelistSummary[] = [
    { accountId: "acct-1", product: "", headerMode: "ENFORCE", contentMode: "OFF",
      headers: 0, templates: 0 },
  ];
  const findings = diagnose({
    ...healthy(),
    whitelist: { summaries, exemptProducts: [], accounts: [{ accountId: "acct-1", product: "" }] },
  });

  const wl = findings.find((f) => f.stage === "whitelist");
  assert.ok(wl);
  assert.equal(wl.severity, "stopping");
  assert.deepEqual(wl.apply, { kind: "reportMode", accountId: "acct-1", product: "", which: "header" });
  assert.match(wl.fix, /REPORT/);
});

test("an account that is enforcing with approvals says nothing", () => {
  const summaries: WhitelistSummary[] = [
    { accountId: "acct-1", product: "", headerMode: "ENFORCE", contentMode: "OFF",
      headers: 4, templates: 0 },
  ];
  const findings = diagnose({
    ...healthy(),
    whitelist: { summaries, exemptProducts: [], accounts: [{ accountId: "acct-1", product: "" }] },
  });

  assert.ok(!findings.some((f) => f.stage === "whitelist"));
});

test("an unrated product is latent, because today it sends free rather than failing", () => {
  const findings = diagnose({
    ...healthy(),
    unratedProducts: [{ product: "in-promo", scope: "acct-1" }],
  });

  const rating = findings.find((f) => f.stage === "rating");
  assert.ok(rating);
  assert.equal(rating.severity, "latent");
  assert.match(rating.detail, /charged nothing/);
  assert.match(rating.detail, /refused outright/, "and what changes when the flag goes on");
});

test("an empty balance is stopping; a funded one says nothing", () => {
  const broke = diagnose({
    ...healthy(),
    credit: [{ accountId: "acct-1", balance: 0, currency: "INR" }],
  });
  assert.equal(broke.find((f) => f.stage === "credit")?.severity, "stopping");

  const funded = diagnose({
    ...healthy(),
    credit: [{ accountId: "acct-1", balance: 124622795, currency: "INR" }],
  });
  assert.ok(!funded.some((f) => f.stage === "credit"));
});

test("scoping to one account drops every other account's findings", () => {
  const input: DiagnosisInput = {
    ...healthy(),
    accountId: "acct-1",
    credit: [
      { accountId: "acct-1", balance: 0, currency: "INR" },
      { accountId: "acct-2", balance: 0, currency: "INR" },
    ],
    tlvGaps: [
      { accountId: "acct-1", sentence: "airtel refuses a message without peid_0x1400." },
      { accountId: "acct-2", sentence: "airtel refuses a message without peid_0x1400." },
    ],
  };

  const findings = diagnose(input);
  assert.ok(findings.every((f) => !f.key.includes("acct-2")));
  assert.ok(findings.some((f) => f.key.includes("acct-1")));
});

test("the summary counts what is stopping separately from what is not", () => {
  assert.equal(diagnosisSummary([]), null);

  const findings = diagnose({
    ...healthy(),
    refusals: { summary: [{ reason: "headerNotApproved", count: 5000 }], total: 5000, hours: 24 },
    unratedProducts: [{ product: "in-promo", scope: "acct-1" }],
  });
  const summary = diagnosisSummary(findings) ?? "";
  assert.match(summary, /1 thing stopping messages/);
  assert.match(summary, /1 other thing/);
});

test("a refusal accepted before it was refused says so", () => {
  //maxAttempts and filtered are the two the customer already had a success for, and that changes
  //what the operator tells them
  const findings = diagnose({
    ...healthy(),
    refusals: { summary: [{ reason: "maxAttempts", count: 200 }], total: 200, hours: 24 },
  });

  assert.match(findings[0].detail, /already had a success back/);
  assert.match(findings[0].fix, /This one IS routing/);
});

test("a rate limit names the ingress's own key: REST's smsg.restapi.maxRate, SMPP's conf.maxRate and the login TPS", () => {
  const http = rateLimitFix("http", "YK201");
  assert.match(http, /smsg\.restapi\.maxRate\.YK201/);
  assert.doesNotMatch(http, /conf\.maxRate/);
  const smpp = rateLimitFix("smpp", "YK201");
  assert.match(smpp, /conf\.maxRate\.YK201 on the listener/);
  assert.doesNotMatch(smpp, /restapi/);
  assert.doesNotMatch(smpp, /max_tps/, "the login's TPS is named only when a login limit threw");
  assert.match(rateLimitFix("smpp", "YK201", { byLogin: true }), /max_tps on the login/);
  assert.match(rateLimitFix("smpp", null), /conf\.maxRate\.<account>/);

  const findings = diagnose({ ...healthy(), refusals: { summary: [{ reason: "rateLimited", count: 3 }], total: 3, hours: 24 } });
  assert.match(findings[0].fix, /REST submissions \(429\)/, "rateLimited rows are HTTP's");
});

test("SMPP throttles are their own finding, degrading, linked to the account's limits", () => {
  const findings = diagnose({
    ...healthy(),
    throttles: {
      total: 8_904, hours: 24,
      top: [{ accountId: "YK201", listener: "smppserver.dltsmpp", systemId: "yk201", throttled: 8_000, byAccount: 7_900, byLogin: 100 }],
    },
  });
  const f = findings.find((x) => x.key === "evidence:smppThrottled");
  assert.ok(f);
  assert.equal(f.severity, "degrading", "a throttled client retries: late, not lost");
  assert.match(f.headline, /8,904 submits/);
  assert.match(f.detail, /dltsmpp for YK201 \(login yk201\)/);
  assert.match(f.fix, /conf\.maxRate\.YK201/);
  assert.match(f.fix, /max_tps/);
  assert.equal(f.href, "/cp/accounts/YK201/limits");
  assert.equal(diagnose({ ...healthy(), throttles: { total: 0, hours: 24, top: [] } }).some((x) => x.key === "evidence:smppThrottled"), false);
});

test("the two 0.15.1 database refusals have labels and fixes", () => {
  assert.equal(reasonLabel("dbUnavailable"), "Database not answering; try again");
  assert.equal(reasonLabel("creditPending"), "Credit being reserved; try again");
  const findings = diagnose({ ...healthy(), refusals: { summary: [{ reason: "dbUnavailable", count: 500 }], total: 500, hours: 24 } });
  assert.match(findings[0].fix, /Queues/);
});
