import { formatCount, fullCount, rateText } from "./connectivity-layout.ts";
import type { LiveCountersSum } from "./gateway-live-counters.ts";

/**
 * The Connectivity card's three live counter columns as text and tone (0.15.1,
 * `S['connectivity']` in the mockups): pure, so the abbreviation and tone rules are tested without
 * React (`connectivity-counters.test.ts`).
 *
 * <ul>
 *   <li><b>MT total</b> = ACK + NACK (submits accepted and refused at the door), the rate theirs
 *       summed. NACK is in the warning colour while its own rate is above 0.</li>
 *   <li><b>DLR total</b> = IN + OUT (receipts from vendors and pushed to clients), the rate theirs
 *       summed.</li>
 *   <li><b>PostgreSQL</b> = WRITTEN + QUEUE (every row handed to the persistence bus: written, or
 *       still waiting), the rate rows written a second. QUEUE is in the alarm colour, with ▲, when
 *       it has risen on each of the last {@link QUEUE_POLLS} polls.</li>
 * </ul>
 *
 * <p>Figures are abbreviated past 99,999 (`612k`, `1.23M`, {@link formatCount}) with the full figure
 * for the tooltip.
 */

/** How many polls the queue must have risen across, each above the last, to read as rising. */
export const QUEUE_POLLS = 5;

export type CounterTone = "warning" | "alarm" | null;

/** One figure: as shown, and in full for the tooltip. */
export interface CounterFigure {
  label: string;
  text: string;
  full: string;
  tone: CounterTone;
}

/** One column: its title and rate, the total, then the pair under it. */
export interface CounterTile {
  key: "mt" | "dlr" | "db";
  title: string;
  rate: string;
  total: CounterFigure;
  a: CounterFigure;
  b: CounterFigure;
}

function figure(label: string, n: number | null | undefined, tone: CounterTone = null, suffix = ""): CounterFigure {
  return { label, text: formatCount(n) + suffix, full: fullCount(n), tone };
}

/** NACK's tone: warning while the door is still refusing. */
export function nackTone(nackPerSecond: number | null | undefined): CounterTone {
  return nackPerSecond != null && nackPerSecond > 0 ? "warning" : null;
}

/** The queue's last {@link QUEUE_POLLS} readings, the newest last. */
export function pushQueue(history: readonly number[], queue: number): number[] {
  return [...history, queue].slice(-QUEUE_POLLS);
}

/** Whether the queue rose on every one of the last {@link QUEUE_POLLS} polls. */
export function queueRising(history: readonly number[]): boolean {
  if (history.length < QUEUE_POLLS) {
    return false;
  }
  const last = history.slice(-QUEUE_POLLS);
  return last.every((v, i) => i === 0 || v > last[i - 1]);
}

/** QUEUE's tone: the alarm colour when it is rising. */
export function queueTone(history: readonly number[]): CounterTone {
  return queueRising(history) ? "alarm" : null;
}

/** The three columns from the cluster's sum and the queue's recent readings. */
export function counterTiles(c: LiveCountersSum, queueHistory: readonly number[]): CounterTile[] {
  const r = c.rates;
  const qTone = queueTone(queueHistory);
  return [
    {
      key: "mt",
      title: "MT total",
      rate: rateText(r.mtAckPerSecond + r.mtNackPerSecond),
      total: figure("MT total", c.mt.ack + c.mt.nack),
      a: figure("ACK", c.mt.ack),
      b: figure("NACK", c.mt.nack, nackTone(r.mtNackPerSecond)),
    },
    {
      key: "dlr",
      title: "DLR total",
      rate: rateText(r.dlrInPerSecond + r.dlrOutPerSecond),
      total: figure("DLR total", c.dlr.in + c.dlr.out),
      a: figure("IN", c.dlr.in),
      b: figure("OUT", c.dlr.out),
    },
    {
      key: "db",
      title: "PostgreSQL",
      rate: rateText(r.dbWrittenPerSecond).replace(/\/s$/, " rows/s"),
      total: figure("PostgreSQL", c.db.written + c.db.queue),
      a: figure("WRITTEN", c.db.written),
      b: figure("QUEUE", c.db.queue, qTone, qTone ? " ▲" : ""),
    },
  ];
}

/**
 * The totals line's tail: `counters since restart 17:41`, with the date when the restart was not
 * today, and the nodes whose share is missing.
 */
export function sinceText(c: Pick<LiveCountersSum, "since" | "partial"> | null, now = Date.now(), timeZone?: string): string {
  if (!c) {
    return "";
  }
  const at = c.since ? new Date(c.since) : null;
  const zone = timeZone ? { timeZone } : {};
  let when = "";
  if (at && !Number.isNaN(at.getTime())) {
    const clock = at.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", hour12: false, ...zone });
    const day = (d: Date) => d.toLocaleDateString("en-GB", { day: "numeric", month: "short", ...zone });
    when = day(at) === day(new Date(now)) ? ` ${clock}` : ` ${day(at)} ${clock}`;
  }
  const missing = c.partial.length ? ` (without ${c.partial.join(", ")})` : "";
  return `counters since restart${when}${missing}`;
}
