/**
 * The statement's two statements, and the arithmetic over their rows, with no database import.
 *
 * <p>`statement-queries.ts` runs them; this module only builds them, so the window split can be
 * tested without a database and run against one by a test that has it.
 *
 * <h2>Why the old statement timed out</h2>
 *
 * <p>The summary used to be a `live` half -- one row per message over the whole period, with a
 * `cdr_final` LATERAL per row -- beside a `purged` half that took a `usage_daily` line only when
 * `NOT EXISTS` found no `cdr_submit` row on `(submitted_at AT TIME ZONE zone)::date = u.day`. No
 * index serves a function of `submitted_at`, and it defeats partition pruning, so that probe walked
 * the account's call records once per line; the live half re-read a month of raw records beside it.
 * On a production account the pair never finished inside the CDR pool's ten seconds.
 *
 * <h2>One split, at a boundary day</h2>
 *
 * <p>The window is cut at a billing day `B` ({@link STATEMENT_CUT_SQL}):
 *
 * <ul>
 *   <li><b>Days before `B`</b> are read from `usage_daily` alone. It is the billing truth for a
 *       finished day and it already covers the purged ones, so no probe of the call records is
 *       needed to find them.</li>
 *   <li><b>Days from `B` on</b> are read from `cdr_submit` alone, one row per message as before,
 *       between bare bounds on `submitted_at` -- plain binds, so the planner prunes to the month's
 *       partition and `idx_cdr_submit_account_time_covering` does the rest.</li>
 *   <li>A <b>partial day at the front</b> of the window (a period cut at the panel process's
 *       midnight rather than the billing zone's) is read live too, because no line covers only part
 *       of a day. Empty when the period starts on a billing-day boundary, which is the usual case.</li>
 * </ul>
 *
 * <p>A day is counted from one source or the other, never both: the same disjointness rule
 * `reconcile-sql.ts` and `usage-summary-sql.ts` state.
 *
 * <h2>Where `B` falls</h2>
 *
 * <p><code>B = clamp(LEAST(GREATEST(last_daily_day, newest line), (now - deadline)::date))</code>, in
 * the billing zone, clamped into the window. Read against the gateway's scheduler
 * (`UsageRollupScheduler.daily`, 0.14):
 *
 * <ul>
 *   <li><b>`usage_rollup_cursor.last_daily_day` is the day the nightly rollup RAN on</b>, not the
 *       last day it rolled: it rolls yesterday (and any day the interlock reports missing) and then
 *       stores today. So every day before it has its lines, and it is itself the first day that may
 *       not. It is only written after a rollup succeeds.</li>
 *   <li><b>The account's newest line</b> covers a deployment whose nightly rollup is the CLI's
 *       (`fireflo usage rollup`, which does not move the cursor) or a gateway before V1.91.0, which
 *       has no cursor. Taking the newest line's own day as `B` keeps one day of margin, the margin
 *       `rollupTailFrom` keeps. With neither, `B` is the start of the window and the whole period is
 *       read live -- the old behaviour, and correct, because nothing of it is summarised.</li>
 *   <li><b>The deadline term (`smsg.cdr.deadline.hours`, default 24).</b> The scheduler rolls a day
 *       once, at `smsg.usage.daily.schedule` (00:15) the morning after, and never restates it: a
 *       later run only restates delivery columns when somebody re-runs the CLI over that day. So a
 *       line's billing columns (submitted, unrated, price) are final, but its delivery columns are
 *       the outcomes as of 00:15, with whatever was still in flight counted as
 *       `pending_at_rollup`. Receipts for a day go on landing until its last message's deadline has
 *       passed. Keeping every day the deadline can still move live (yesterday and today at 24 h)
 *       shows those outcomes as they settle, and costs at most about two days of records.</li>
 * </ul>
 *
 * <p><strong>What that gives up, knowingly.</strong> A day older than `B` shows its delivery figures
 * as the nightly rollup saw them, which is what `/cp/usage` already shows for the same day. The
 * amount, the count sent and the count not billed are the line's final figures and do not move. A
 * call record committed for a day after its line was written (seconds or minutes after midnight, by
 * the buffered writer) is in the line only if it landed before the 00:15 rollup; the deadline term
 * keeps yesterday live, so in practice that window is closed before a day leaves the live tail.
 *
 * <h2>The tail in hours</h2>
 *
 * <p>Two days of a busy account is still most of a million messages, and reading them live is a
 * `DISTINCT ON` sort that spills and a `cdr_final` probe per message: 21 s for 800,000 messages on
 * .101. The gateway already keeps the same counts per UTC hour in `usage_hourly` (V1.91.0), so the
 * tail is split once more, at a seam `S` ({@link STATEMENT_HOURLY_CUT_SQL}): whole hours
 * `[B, S)` from `usage_hourly`, summed over its vendors, and only `[S, until)` from the records.
 *
 * <p><strong>Which hours are taken.</strong> Read against `UsageHourlyRollup` (gateway 0.14):
 *
 * <ul>
 *   <li>A minute <b>tick</b> adds each window's messages to its hours and leaves `rolled_up_at`
 *       alone. It is complete for the money -- only one row per message is priced -- but a message
 *       retried across a tick boundary is one message in each window, and a call record committed
 *       later than the tick's lag is in no window at all.</li>
 *   <li>A <b>restate</b> recomputes the hour whole over `[hour, min(hour + 1h, hourly_hwm))` and
 *       stamps `rolled_up_at` with its own time. The scheduler ticks in the same pass before it
 *       restates, so a restate stamped well after the hour ended counted the whole hour. It runs on
 *       a backoff -- every quarter hour for a fresh hour -- until `hour + deadline + 2h`, and the
 *       row is then frozen.</li>
 * </ul>
 *
 * <p>So an hour is trusted when it is wholly before `hourly_hwm` and every one of the account's
 * rows in it that carries traffic was computed whole at least {@link HOURLY_SETTLE_MINUTES} after
 * the hour ended (a frozen row always was). A row with no traffic -- refusals or attempts alone,
 * which the restate never re-stamps -- says nothing and is not asked. An hour with no traffic rows
 * for the account, wholly ticked, had no traffic. `S` is the first hour that is not trusted, so in
 * practice the records are read for the last hour or two only.
 *
 * <p><strong>Only where UTC hours tile billing days.</strong> An hour is put in the billing day its
 * start falls in, which is right only when the zone's offset is a whole number of hours for every
 * instant of the tail. That holds through a DST change between two whole-hour offsets (Sydney's
 * +11 to +10 moves midnight from one UTC hour boundary to another), and fails for Asia/Kolkata's
 * +05:30 or Lord Howe's half-hour shift; those keep the whole tail live. So does a gateway without
 * `usage_hourly`, an hour older than the table's first row (purged on its own retention, or before
 * the summary existed), and a tail that does not start on a UTC hour.
 *
 * <p><strong>What differs from the records.</strong> The money and the billed count are exact: the
 * restate prices one row per message, as the live read does. A message whose attempts straddle the
 * top of an hour is counted in each hour's `submitted` (the unpriced attempt as not billed), just as
 * `usage_daily` counts one straddling midnight; delivery figures are as of the hour's last restate.
 * The CSV is never read from here.
 *
 * <h2>Bind parameters</h2>
 *
 * <p>{@link STATEMENT_CUT_SQL}: `$1` account, `$2` since, `$3` until, `$4` zone, `$5` the cursor's
 * `last_daily_day` (a `date`, or null), `$6` the deadline in hours.
 *
 * <p>{@link STATEMENT_HOURLY_CUT_SQL}: `$1` account, `$2` the tail's start (`B`), `$3` until, `$4`
 * zone, `$5` {@link HOURLY_SETTLE_MINUTES}.
 *
 * <p>{@link statementSummarySql}: `$1` account, `$2` since, `$3` the head's end, `$4` zone, `$5` the
 * live tail's start (`S`, or `B` with no hourly half), `$6` until, `$7` the first whole day, `$8`
 * `B`, and with the hourly half `$9` its start (`B` again). All plain values computed by the cuts,
 * so the planner sees constants on every range.
 */

import { carriesMoney, isMessageRow, messageRows, partOne, type GrainOptions } from "./cdr-grain.ts";
import { OUTCOME_LATERAL } from "./usage-summary-sql.ts";

/**
 * Part 1 only. Redundant inside `messageRows`, which already takes part 1 alone, and kept on each
 * count so the filter survives if the FROM ever changes back to a plain table.
 */
const ONE_ROW_PER_MESSAGE = partOne();

/** The same rows, named for what a money query is asking. */
const CARRIES_MONEY = carriesMoney();

/**
 * What the live halves carry through the per-message `DISTINCT ON`: the outcome LATERAL's
 * correlation, the grouping and the money. Never `body` or the TLVs, which only widen the sort.
 */
const STATEMENT_LIVE_COLUMNS = ["gateway_msg_id", "part_no", "product", "submitted_at", "price"] as const;

/**
 * What a statement's lines are split by (0.15.1): the product, as it always was, or the login the
 * traffic was sent on (`cdr_submit.system_id`, `usage_hourly.system_id` from V1.113.0 and
 * `usage_daily.system_id` from V1.115.0). The totals are the same either way.
 */
export type StatementSplit = "product" | "login";

/** Options for {@link statementSummarySql} beyond the grain. */
export interface StatementSqlOptions {
  /** The tail's trusted hours come from `usage_hourly` (`$9` is then bound). */
  hourly?: boolean;
  split?: StatementSplit;
  /** `usage_daily.system_id` exists (V1.115.0). Without it every rolled day is the "—" login. */
  dailyLogin?: boolean;
  /** `usage_hourly.system_id` exists (V1.113.0). */
  hourlyLogin?: boolean;
}

/**
 * The key a line is grouped by, from each source. `''` -- no product, or no login recorded (a
 * summary row from before its login column, a record that named none) -- is one line, which the
 * screens call "no product" or "—".
 */
function splitKey(o: StatementSqlOptions, source: "live" | "rolled" | "hourly"): string {
  if (o.split !== "login") {
    return source === "live" ? "COALESCE(s.product, '')" : source === "rolled" ? "u.product" : "h.product";
  }
  if (source === "live") {
    return "COALESCE(s.system_id, '')";
  }
  if (source === "rolled") {
    return o.dailyLogin ? "COALESCE(u.system_id, '')" : "''::text";
  }
  return o.hourlyLogin ? "COALESCE(h.system_id, '')" : "''::text";
}

/**
 * Where the window splits, as plain values for the summary's binds. One row.
 *
 * <ul>
 *   <li>`first_full`: the first billing day starting at or after `since`;</li>
 *   <li>`boundary`: `B`, never before `first_full` and never after the day `until` falls in, unless
 *       the window is shorter than a day, when it is `first_full` and both summary days and tail are
 *       empty;</li>
 *   <li>`head_until`: where the partial leading day ends (`since` itself when there is none);</li>
 *   <li>`tail_from`: the instant `B` starts.</li>
 * </ul>
 *
 * <p>`GREATEST` and `LEAST` ignore a NULL, so a missing cursor falls back to the newest line, and
 * an account with neither reads `-infinity`, which the clamp turns into the start of the window.
 */
export const STATEMENT_CUT_SQL = `
  SELECT to_char(c.first_full, 'YYYY-MM-DD')                        AS first_full,
         to_char(c.boundary, 'YYYY-MM-DD')                          AS boundary,
         LEAST(c.until, (c.first_full::timestamp AT TIME ZONE $4))  AS head_until,
         GREATEST(c.since, (c.boundary::timestamp AT TIME ZONE $4)) AS tail_from
    FROM (SELECT w.since, w.until, w.first_full,
                 GREATEST(w.first_full, LEAST(w.end_day, w.rolled_to, w.settling_from)) AS boundary
            FROM (SELECT $2::timestamptz AS since,
                         $3::timestamptz AS until,
                         ((($2::timestamptz) AT TIME ZONE $4) - interval '1 microsecond')::date + 1 AS first_full,
                         (($3::timestamptz) AT TIME ZONE $4)::date AS end_day,
                         --the first day that may have no line: the cursor's day, else the
                         --account's newest line's day (one day of margin), else none at all
                         COALESCE(GREATEST($5::date,
                                           (SELECT max(u.day) FROM usage_daily u WHERE u.account_id = $1)),
                                  '-infinity'::date) AS rolled_to,
                         --the first day whose outcomes the deadline can still move
                         ((now() - make_interval(hours => $6::int)) AT TIME ZONE $4)::date AS settling_from
                 ) w
         ) c`;

/** The cut's one row, as {@link STATEMENT_CUT_SQL} returns it. */
export interface StatementCut {
  first_full: string;
  boundary: string;
  head_until: Date | string;
  tail_from: Date | string;
}

/**
 * How long after an hour ends its rows must have been computed whole before the statement reads the
 * hour from `usage_hourly`. A quarter of an hour: the restate's own interval, and many times the
 * tick's lag and interval (30 s and 60 s by default), so the restate that stamped the row ran after
 * a tick had carried the watermark past the hour, and late-committed records have had a restate to
 * be found by.
 */
export const HOURLY_SETTLE_MINUTES = 15;

/**
 * Where the tail's hourly half ends: the seam `S`, as an instant. One row, one column.
 *
 * <p>`S` is `B` itself -- no hourly half -- when the tail does not start on a UTC hour, when the
 * billing zone's offset is not a whole number of hours at every half hour of the tail, when the
 * tail starts before `usage_hourly`'s first row, or when there is no watermark. Otherwise it is the
 * first hour of the tail that is not trusted (see the module doc), or the end of the last whole hour
 * before `until` when every one is. `[S, until)` is then read live.
 *
 * <p>The per-hour probe is the primary key's prefix, `(account_id, hour)`: one index range per
 * hour of the tail, which is about 48 of them.
 */
export const STATEMENT_HOURLY_CUT_SQL = `
  SELECT CASE
           WHEN w.lo <> (date_trunc('hour', w.lo AT TIME ZONE 'UTC') AT TIME ZONE 'UTC') THEN w.lo
           WHEN w.hwm IS NULL OR w.first_hour IS NULL OR w.lo < w.first_hour THEN w.lo
           --a half-hour zone, or a half-hour DST shift, anywhere in the tail: hours do not tile its days
           WHEN EXISTS (SELECT 1 FROM generate_series(w.lo, w.hi, interval '30 minutes') g(t)
                         WHERE extract(epoch FROM (g.t AT TIME ZONE $4) - (g.t AT TIME ZONE 'UTC'))::bigint % 3600 <> 0)
             THEN w.lo
           ELSE COALESCE(
             (SELECT min(g.h)
                FROM generate_series(w.lo, w.lo + (w.whole - 1) * interval '1 hour', interval '1 hour') g(h)
                LEFT JOIN LATERAL (
                       SELECT min(u.rolled_up_at) AS computed
                         FROM usage_hourly u
                        WHERE u.account_id = $1 AND u.hour = g.h AND u.submitted > 0
                     ) x ON TRUE
               WHERE g.h + interval '1 hour' > w.hwm
                  OR x.computed < g.h + interval '1 hour' + make_interval(mins => $5::int)),
             w.lo + w.whole * interval '1 hour')
         END AS seam
    FROM (SELECT $2::timestamptz AS lo, $3::timestamptz AS hi,
                 --whole hours from lo that end at or before hi
                 GREATEST(floor(extract(epoch FROM ($3::timestamptz - $2::timestamptz)) / 3600), 0)::int AS whole,
                 (SELECT c.hourly_hwm FROM usage_rollup_cursor c) AS hwm,
                 (SELECT min(uh.hour) FROM usage_hourly uh) AS first_hour) w`;

/** The binds {@link statementSummarySql} takes, in order, from the request and its cuts. */
export function summaryParams(
  accountId: string,
  since: Date,
  until: Date,
  zone: string,
  cut: StatementCut,
  /** The hourly seam, when the SQL was built with the hourly half; it then opens the live tail. */
  seam?: Date | string
): unknown[] {
  const base = [accountId, since, cut.head_until, zone, seam ?? cut.tail_from, until, cut.first_full, cut.boundary];
  return seam === undefined ? base : [...base, cut.tail_from];
}

/**
 * The bill as rows per (billing day, product): the live head and tail from `cdr_submit`, the days
 * between from `usage_daily`. The counts' definitions are unchanged from the statement this
 * replaced, so a live day here is the `usage_daily` line it later becomes.
 *
 * <p>Grouped by product because that is what a customer recognises and what a tariff is set on.
 * `COALESCE(product, '')` rather than dropping the null: traffic that named no product is still
 * traffic and still costs money, and hiding it would make the lines not add up to the total. The
 * rollup writes that traffic under `''` too, so the two halves group together.
 *
 * <p>With `split: "login"` (0.15.1) the same rows are grouped by the login instead -- the column is
 * still called `product`, and holds the split's key, so every consumer of the rows reads one shape.
 * The counts and the money are untouched by the key, so the totals are the same in both modes.
 */
export function statementSummarySql(grain: GrainOptions, o: StatementSqlOptions = {}): string {
  const columns = o.split === "login" ? [...STATEMENT_LIVE_COLUMNS, "system_id"] : STATEMENT_LIVE_COLUMNS;
  const head = messageRows(
    "s.account_id = $1 AND s.submitted_at >= $2 AND s.submitted_at < $3",
    grain,
    columns
  );
  const tail = messageRows(
    "s.account_id = $1 AND s.submitted_at >= $5 AND s.submitted_at < $6",
    grain,
    columns
  );
  return `
  WITH live AS (
      SELECT (s.submitted_at AT TIME ZONE $4)::date                       AS day,
             ${splitKey(o, "live")}                                      AS product,
             count(*) FILTER (WHERE ${ONE_ROW_PER_MESSAGE})               AS submitted,
             count(*) FILTER (WHERE ${ONE_ROW_PER_MESSAGE}
                                AND o.final_state = 'DELIVERED')          AS delivered,
             count(*) FILTER (WHERE ${ONE_ROW_PER_MESSAGE}
                                AND o.final_state IN ('FAILED', 'REJECTED', 'DROPPED')) AS failed,
             count(*) FILTER (WHERE ${ONE_ROW_PER_MESSAGE}
                                AND o.final_state = 'EXPIRED')            AS expired,
             count(*) FILTER (WHERE ${ONE_ROW_PER_MESSAGE}
                                AND o.final_state IS NULL)                AS pending,
             count(*) FILTER (WHERE ${ONE_ROW_PER_MESSAGE}
                                AND s.price IS NULL)                      AS unrated,
             COALESCE(SUM(s.price) FILTER (WHERE ${CARRIES_MONEY}), 0)    AS amount,
             0                                                            AS from_summary
        --one row per message, as UsageRollup, with the account and the range inside the DISTINCT
        --ON. The amount is unchanged by it -- only that row carries a price. The head is the
        --partial leading day and is usually empty; the tail is the days from B on, or from the
        --hourly seam when the hours before it are read from the hourly summary
        FROM (SELECT * FROM ${head}
              UNION ALL
              SELECT * FROM ${tail}) s${OUTCOME_LATERAL}
       GROUP BY 1, 2
  ),
  -- the finished days. usage_daily is keyed (account_id, day, product), its day is the billing
  -- zone's, and its BILLING columns are final for a finished day -- which is what an old invoice
  -- needs, and what still exists once the call records are purged
  rolled AS (
      SELECT u.day, ${splitKey(o, "rolled")} AS product,
             u.submitted, u.delivered, u.failed, u.expired,
             u.pending_at_rollup AS pending,
             u.unrated_messages  AS unrated,
             u.price_total       AS amount,
             1                   AS from_summary
        FROM usage_daily u
       WHERE u.account_id = $1
         AND u.day >= $7::date
         AND u.day <  $8::date
  )${o.hourly ? `,
  -- the trusted whole hours of the tail, [B, S): each in the billing day its start falls in, which
  -- the hourly cut has checked is the day the whole hour falls in. Summed over vendors by the
  -- grouping below; a row of refusals or attempts alone adds zeros
  hourly AS (
      SELECT (h.hour AT TIME ZONE $4)::date AS day, ${splitKey(o, "hourly")} AS product,
             h.submitted, h.delivered, h.failed, h.expired,
             h.pending_at_rollup AS pending,
             h.unrated_messages  AS unrated,
             h.price_total       AS amount,
             0                   AS from_summary
        FROM usage_hourly h
       WHERE h.account_id = $1
         AND h.hour >= $9::timestamptz
         AND h.hour <  $5::timestamptz
  )` : ""}
  SELECT to_char(day, 'YYYY-MM-DD') AS day, product,
         SUM(submitted) AS submitted, SUM(delivered) AS delivered, SUM(failed) AS failed,
         SUM(expired) AS expired, SUM(pending) AS pending, SUM(unrated) AS unrated,
         SUM(amount) AS amount, MAX(from_summary) AS from_summary
    FROM (SELECT * FROM live UNION ALL SELECT * FROM rolled${o.hourly ? " UNION ALL SELECT * FROM hourly" : ""}) sources
   GROUP BY day, product
   ORDER BY day, product`;
}

/**
 * The messages behind the bill, one page: `$1` account, `$2` since, `$3` until, `$4` the page size,
 * and with `keyset` `$5`/`$6` the last row's `submitted_at` and `id`. See `statementDetail`.
 */
export function statementDetailSql(grain: GrainOptions, keyset: boolean): string {
  return `SELECT s.id::text, s.submitted_at, s.gateway_msg_id, s.product,
            s.dest_addr AS dst, s.source_addr AS src, s.part_count,
            o.final_state, s.price::text
       FROM cdr_submit s${OUTCOME_LATERAL}
      WHERE s.account_id = $1
        AND s.submitted_at >= $2
        AND s.submitted_at < $3
        AND ${isMessageRow("s", grain)}${keyset
    ? " AND (s.submitted_at, s.id) > ($5::timestamptz, $6::bigint)"
    : ""}
      ORDER BY s.submitted_at, s.id
      LIMIT $4`;
}

/** One row of {@link statementSummarySql}, as the driver returns it: bigints as strings. */
export interface StatementDayProductRow {
  day: string;
  product: string;
  submitted: string | number;
  delivered: string | number;
  failed: string | number;
  expired: string | number;
  pending: string | number;
  unrated: string | number;
  amount: string | number;
  from_summary: string | number;
}

export interface StatementLine {
  product: string;
  submitted: number;
  delivered: number;
  failed: number;
  expired: number;
  pending: number;
  /** Counted, never summed: these are the messages that went out with no price. */
  unrated: number;
  /** Scaled by 10,000. */
  amount: number;
}

/**
 * One billing day of the statement, for its chart. The shape `/cp/usage` plots, less the account:
 * `failed` is failed and expired together, as there, so the two charts draw the same bars.
 */
export interface StatementDay {
  /** `YYYY-MM-DD`, a billing day. */
  day: string;
  submitted: number;
  delivered: number;
  failed: number;
  pending: number;
  /** Scaled by 10,000. */
  price: number;
  /** The day by the statement's split (product or login): messages and money per key, for the stacked chart. */
  byKey: Record<string, { submitted: number; amount: number }>;
}

/**
 * The product lines, the days and the totals, all from the one set of rows -- so the chart and the
 * total can never disagree, which two queries eventually would about a retry or a refund.
 */
export function summariseStatement(rows: StatementDayProductRow[]): {
  lines: StatementLine[];
  days: StatementDay[];
  daysFromSummary: number;
} {
  const lines = new Map<string, StatementLine>();
  const days = new Map<string, StatementDay>();
  const summaryDays = new Set<string>();
  for (const r of rows) {
    const n = {
      submitted: Number(r.submitted),
      delivered: Number(r.delivered),
      failed: Number(r.failed),
      expired: Number(r.expired),
      pending: Number(r.pending),
      unrated: Number(r.unrated),
      amount: Number(r.amount),
    };
    const line = lines.get(r.product) ?? {
      product: r.product, submitted: 0, delivered: 0, failed: 0, expired: 0, pending: 0, unrated: 0, amount: 0,
    };
    line.submitted += n.submitted;
    line.delivered += n.delivered;
    line.failed += n.failed;
    line.expired += n.expired;
    line.pending += n.pending;
    line.unrated += n.unrated;
    line.amount += n.amount;
    lines.set(r.product, line);

    const day = days.get(r.day) ?? { day: r.day, submitted: 0, delivered: 0, failed: 0, pending: 0, price: 0, byKey: Object.create(null) as StatementDay["byKey"] };
    const part = day.byKey[r.product] ?? { submitted: 0, amount: 0 };
    part.submitted += n.submitted;
    part.amount += n.amount;
    day.byKey[r.product] = part;
    day.submitted += n.submitted;
    day.delivered += n.delivered;
    day.failed += n.failed + n.expired;
    day.pending += n.pending;
    day.price += n.amount;
    days.set(r.day, day);

    if (Number(r.from_summary) > 0) {
      summaryDays.add(r.day);
    }
  }
  return {
    //the biggest bill first, then by name: the order the statement has always had
    lines: [...lines.values()].sort((a, b) => b.amount - a.amount || a.product.localeCompare(b.product)),
    days: [...days.values()].sort((a, b) => a.day.localeCompare(b.day)),
    daysFromSummary: summaryDays.size,
  };
}
