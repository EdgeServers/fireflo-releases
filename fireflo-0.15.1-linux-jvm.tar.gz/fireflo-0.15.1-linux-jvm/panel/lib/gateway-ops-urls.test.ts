import { test } from "node:test";
import assert from "node:assert/strict";
import { createOpsUrlResolver, opsUrlResolver, parseOpsUrls } from "./gateway-ops-urls.ts";

/** GATEWAY_OPS_URLS: the parser, and the order nodes are tried and given up on. */

test("parses id=url pairs, trimming spaces and trailing slashes", () => {
  assert.deepEqual(parseOpsUrls(" gw-1=http://10.0.0.11:9000/ , gw-2=https://10.0.0.12:9000"), [
    { id: "gw-1", url: "http://10.0.0.11:9000" },
    { id: "gw-2", url: "https://10.0.0.12:9000" },
  ]);
});

test("skips entries that are not id=url with an http(s) url, and repeated ids", () => {
  assert.deepEqual(
    parseOpsUrls("http://bare:9000,=http://noid:9000,gw-1=ftp://x,gw-2=http://ok:9000,gw-2=http://dup:9000,,"),
    [{ id: "gw-2", url: "http://ok:9000" }]
  );
  assert.deepEqual(parseOpsUrls(undefined), []);
  assert.deepEqual(parseOpsUrls(""), []);
});

/** A probe answering from a table, recording what it was asked. */
function probeOf(up: Record<string, boolean>, asked: string[]) {
  return async (url: string) => {
    asked.push(url);
    return up[url] ?? false;
  };
}

const nodes = parseOpsUrls("gw-1=http://a:9000,gw-2=http://b:9000,gw-3=http://c:9000");

test("no list: the fallback, without probing", async () => {
  const asked: string[] = [];
  const r = createOpsUrlResolver({ nodes: [], fallback: "http://127.0.0.1:9000/", probe: probeOf({}, asked) });
  assert.equal(await r.resolve(), "http://127.0.0.1:9000");
  assert.deepEqual(asked, []);
  assert.equal(await createOpsUrlResolver({ nodes: [], probe: probeOf({}, asked) }).resolve(), undefined);
});

test("the first node that answers, in listed order", async () => {
  const asked: string[] = [];
  const r = createOpsUrlResolver({
    nodes,
    probe: probeOf({ "http://b:9000": true, "http://c:9000": true }, asked),
  });
  assert.equal(await r.resolve(), "http://b:9000");
  assert.deepEqual(asked, ["http://a:9000", "http://b:9000"]);
});

test("the kept node is called directly: no probe before a call, even past 30 s; failback runs beside it", async () => {
  let t = 0;
  const asked: string[] = [];
  const up: Record<string, boolean> = { "http://b:9000": true };
  const r = createOpsUrlResolver({ nodes, probe: probeOf(up, asked), now: () => t });
  assert.equal(await r.resolve(), "http://b:9000");
  asked.length = 0;
  t = 29_999;
  assert.equal(await r.resolve(), "http://b:9000");
  assert.deepEqual(asked, []);
  up["http://a:9000"] = true;
  t = 30_000;
  //the call in hand still goes to the kept node, at once; the earlier node is looked for beside it
  assert.equal(await r.resolve(), "http://b:9000");
  await new Promise((done) => setImmediate(done));
  assert.deepEqual(asked, ["http://a:9000"], "only the nodes before the kept one, and never the kept one");
  assert.equal(await r.resolve(), "http://a:9000", "the next call moves back to the earlier node");
  asked.length = 0;
  t = 90_000;
  assert.equal(await r.resolve(), "http://a:9000");
  await new Promise((done) => setImmediate(done));
  assert.deepEqual(asked, [], "the first listed node has nothing before it to fail back to: never probed again");
});

test("a slow main node is kept: no invalidate on a timeout, the next call goes to the same node unprobed", async () => {
  let t = 0;
  const asked: string[] = [];
  const verdicts: Record<string, "up" | "slow" | "down"> = { "http://a:9000": "up", "http://b:9000": "up" };
  const r = createOpsUrlResolver({
    nodes,
    probe: async (url) => {
      asked.push(url);
      return verdicts[url] ?? "down";
    },
    now: () => t,
  });
  assert.equal(await r.resolve(), "http://a:9000");
  //the gateway turns slow; executeGql does not invalidate on a timeout, so nothing else happens
  verdicts["http://a:9000"] = "slow";
  asked.length = 0;
  for (t = 0; t <= 120_000; t += 10_000) {
    assert.equal(await r.resolve(), "http://a:9000");
  }
  assert.deepEqual(asked, []);
});

test("nothing answers in time: the first slow node beats the fallback, a down one never does", async () => {
  const verdicts: Record<string, "up" | "slow" | "down"> = { "http://a:9000": "down", "http://b:9000": "slow", "http://c:9000": "slow" };
  const r = createOpsUrlResolver({ nodes, fallback: "http://127.0.0.1:9000", probe: async (url) => verdicts[url] });
  assert.equal(await r.resolve(), "http://b:9000");
  const allDown = createOpsUrlResolver({ nodes, fallback: "http://127.0.0.1:9000", probe: async () => "down" });
  assert.equal(await allDown.resolve(), "http://127.0.0.1:9000");
});

test("a call that finds its node gone invalidates it, and the next one moves on", async () => {
  const asked: string[] = [];
  const up: Record<string, boolean> = { "http://a:9000": true, "http://b:9000": true };
  const r = createOpsUrlResolver({ nodes, probe: probeOf(up, asked), now: () => 0 });
  assert.equal(await r.resolve(), "http://a:9000");
  up["http://a:9000"] = false;
  //invalidating a url that is not the cached one changes nothing
  r.invalidate("http://c:9000");
  assert.equal(await r.resolve(), "http://a:9000");
  r.invalidate("http://a:9000");
  asked.length = 0;
  assert.equal(await r.resolve(), "http://b:9000");
  assert.deepEqual(asked, ["http://a:9000", "http://b:9000"]);
});

test("nothing answers: the fallback, else the first node; a throwing probe counts as down", async () => {
  const asked: string[] = [];
  const throwing = async (url: string) => {
    asked.push(url);
    throw new Error("boom");
  };
  const withFallback = createOpsUrlResolver({ nodes, fallback: "http://127.0.0.1:9000", probe: throwing });
  assert.equal(await withFallback.resolve(), "http://127.0.0.1:9000");
  assert.deepEqual(asked, ["http://a:9000", "http://b:9000", "http://c:9000"]);
  const without = createOpsUrlResolver({ nodes, probe: probeOf({}, []) });
  assert.equal(await without.resolve(), "http://a:9000");
});

test("concurrent calls share one round of probes", async () => {
  const asked: string[] = [];
  const r = createOpsUrlResolver({ nodes, probe: probeOf({ "http://c:9000": true }, asked) });
  const all = await Promise.all([r.resolve(), r.resolve(), r.resolve()]);
  assert.deepEqual(all, ["http://c:9000", "http://c:9000", "http://c:9000"]);
  assert.deepEqual(asked, ["http://a:9000", "http://b:9000", "http://c:9000"]);
});

test("the default probe: a health query with the read token, 200 only", async () => {
  const seen: { url: string; auth: string | null }[] = [];
  globalThis.fetch = (async (url: string | URL | Request, init?: RequestInit) => {
    seen.push({ url: String(url), auth: new Headers(init?.headers).get("Authorization") });
    if (String(url).startsWith("http://down")) {
      throw new TypeError("fetch failed");
    }
    const status = String(url).startsWith("http://refuses") ? 404 : 200;
    return new Response("{}", { status });
  }) as typeof fetch;
  const r = opsUrlResolver({
    GATEWAY_OPS_URLS: "gw-1=http://down:9000,gw-2=http://refuses:9000,gw-3=http://up:9000",
    GATEWAY_OPS_URL: "http://127.0.0.1:9000",
    GATEWAY_OPS_TOKEN: " read-secret ",
  } as NodeJS.ProcessEnv);
  assert.equal(await r.resolve(), "http://up:9000");
  assert.deepEqual(seen, [
    { url: "http://down:9000/graphql", auth: "Bearer read-secret" },
    { url: "http://refuses:9000/graphql", auth: "Bearer read-secret" },
    { url: "http://up:9000/graphql", auth: "Bearer read-secret" },
  ]);
});

test("the default probe: a timeout is slow, a refusal is down", async () => {
  globalThis.fetch = (async (url: string | URL | Request) => {
    if (String(url).startsWith("http://slow")) {
      throw new DOMException("The operation was aborted due to timeout", "TimeoutError");
    }
    throw Object.assign(new TypeError("fetch failed"), { cause: { code: "ECONNREFUSED" } });
  }) as typeof fetch;
  const probe = opsUrlResolver({ GATEWAY_OPS_URLS: "gw-1=http://slow:9000", GATEWAY_OPS_TOKEN: "t" } as NodeJS.ProcessEnv);
  assert.equal(await probe.resolve(), "http://slow:9000", "the only node, slow: chosen, it is there");
  const { healthProbe } = await import("./gateway-ops-urls.ts");
  assert.equal(await healthProbe("t")("http://slow:9000"), "slow");
  assert.equal(await healthProbe("t")("http://refused:9000"), false);
});
