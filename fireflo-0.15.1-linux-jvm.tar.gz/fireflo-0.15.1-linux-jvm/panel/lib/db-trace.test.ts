import { test } from "node:test";
import assert from "node:assert/strict";
import {
  adoptTrace, captureTrace, currentTrace, enterTrace, hideTrace, lastReadMs, recordDbCall, recordGatewayCall, timedDb, traceTotals,
} from "./db-trace.ts";

const tick = () => new Promise((r) => setTimeout(r, 1));

test("nested awaits and parallel branches share one trace", async () => {
  const trace = await enterTrace(async () => {
    recordDbCall("metrics", 5);
    await tick();
    await Promise.all([
      (async () => { await tick(); recordDbCall("metrics", 7); })(),
      (async () => { await tick(); await tick(); recordGatewayCall("127.0.0.1:9000", 3); })(),
    ]);
    recordDbCall("config", 1);
    return currentTrace();
  });
  assert.ok(trace);
  assert.deepEqual(trace.calls.map((c) => c.ms), [5, 7, 1]);
  assert.deepEqual(trace.gateway, [{ host: "127.0.0.1:9000", ms: 3 }]);
});

test("two requests at once keep their own traces", async () => {
  const [a, b] = await Promise.all([
    enterTrace(async () => { await tick(); recordDbCall("metrics", 1); await tick(); return currentTrace(); }),
    enterTrace(async () => { recordDbCall("metrics", 2); await tick(); recordDbCall("metrics", 3); return currentTrace(); }),
  ]);
  assert.deepEqual(a?.calls.map((c) => c.ms), [1]);
  assert.deepEqual(b?.calls.map((c) => c.ms), [2, 3]);
});

test("outside a trace recording is a no-op and timedDb just runs", async () => {
  assert.equal(currentTrace(), null);
  recordDbCall("metrics", 4);
  recordGatewayCall("x:1", 4);
  hideTrace();
  assert.equal(await timedDb("metrics", async () => 42), 42);
  assert.equal(currentTrace(), null);
});

test("timedDb records a call that threw, and rethrows", async () => {
  const trace = await enterTrace(async () => {
    await assert.rejects(timedDb("config", async () => { await tick(); throw new Error("boom"); }), /boom/);
    await timedDb("metrics", async () => "ok");
    return currentTrace();
  });
  assert.deepEqual(trace?.calls.map((c) => c.pool), ["config", "metrics"]);
  assert.ok(trace!.calls.every((c) => c.ms >= 0));
});

test("totals: sums, max, count, pools; cached only when every call was", () => {
  const t = traceTotals({
    calls: [{ pool: "metrics", ms: 10 }, { pool: "metrics", ms: 30, cached: true }, { pool: "config", ms: 5 }],
    gateway: [{ host: "a:9000", ms: 4, cached: true }, { host: "a:9000", ms: 6, cached: true }],
  });
  assert.deepEqual(t.db, { pools: ["metrics", "config"], ms: 45, max: 30, calls: 3, cached: false });
  assert.deepEqual(t.gateway, { hosts: ["a:9000"], ms: 10, max: 6, calls: 2, cached: true });
  assert.deepEqual(traceTotals({ calls: [], gateway: [] }), { db: null, gateway: null });
});

test("captureTrace isolates a read from the caller, adoptTrace copies it back marked", async () => {
  const outer = await enterTrace(async () => {
    const { value, trace } = await captureTrace(async () => { recordDbCall("metrics", 9); return "v"; });
    assert.equal(value, "v");
    assert.equal(currentTrace()?.calls.length, 0);
    adoptTrace(trace, true);
    adoptTrace(trace, false);
    adoptTrace(undefined, true);
    return currentTrace();
  });
  assert.deepEqual(outer?.calls, [{ pool: "metrics", ms: 9, cached: true }, { pool: "metrics", ms: 9, cached: false }]);
});

test("hideTrace marks the request's trace", async () => {
  const t = await enterTrace(async () => { hideTrace(); return currentTrace(); });
  assert.equal(t?.hidden, true);
});

test("the last traced read per pool is kept for the Database card; an untraced one does not move it", async () => {
  await enterTrace(async () => {
    recordDbCall("config", 6);
  });
  assert.equal(lastReadMs("config"), 6);
  recordDbCall("config", 900);
  assert.equal(lastReadMs("config"), 6, "outside a request nothing is recorded");
  await enterTrace(() => timedDb("config", async () => 1));
  assert.ok((lastReadMs("config") ?? -1) >= 0 && (lastReadMs("config") ?? 99) < 900);
});
