import { strict as assert } from "node:assert";
import { after, before, describe, test } from "node:test";

import {
  breakdownQuery,
  expandable,
  filterQuery,
  grainFor,
  parseUsageFilters,
  rowKey,
  sumBuckets,
} from "./usage-grid.ts";
import { usageBucketsSql, usageRowsSql, type UsageGridOptions } from "./usage-grid-sql.ts";
import { statementSummarySql } from "./statement-sql.ts";

const norm = (sql: string) => sql.replace(/\s+/g, " ").trim();

/**
 * The owner's rule for these pages, as a test: the generated SQL never names a call record table
 * except for a window bounded at both ends on `submitted_at` (the raw edge, one row per message), and
 * a receipt only through the bounded outcome LATERAL. No `_all` view, no `cdr_final` scan.
 */
function assertOnlyBoundedRecords(sql: string, label: string) {
  const text = norm(sql);
  assert.doesNotMatch(text, /cdr_\w+_all/, `${label}: no _all view`);
  const submits = [...text.matchAll(/FROM cdr_submit s WHERE (.*?) ORDER BY s\.gateway_msg_id/g)];
  const named = (text.match(/\bcdr_submit\b/g) ?? []).length;
  //each per-message read names cdr_submit twice: the DISTINCT ON and the rival-free messageRows
  assert.equal(submits.length, named, `${label}: every cdr_submit is a bounded per-message read`);
  for (const [, where] of submits) {
    assert.match(where, /s\.submitted_at >= /, `${label}: a lower bound`);
    assert.match(where, /s\.submitted_at < /, `${label}: an upper bound`);
  }
  const finals = [...text.matchAll(/FROM cdr_final f WHERE (.*?) ORDER BY/g)];
  assert.equal(finals.length, (text.match(/\bcdr_final\b/g) ?? []).length, `${label}: cdr_final only in the outcome LATERAL`);
  for (const [, where] of finals) {
    assert.match(where, /f\.gateway_msg_id = s\.gateway_msg_id/);
    assert.match(where, /f\.final_at >= s\.submitted_at - interval '1 day'/, `${label}: the receipt bounded by its submit`);
    assert.match(where, /f\.final_at < now\(\)/);
  }
  assert.doesNotMatch(text, /\bcdr_(interim|event|rejected)\b/, `${label}: nothing else`);
}

test("Usage and the statement split never read the busy tables over a window", () => {
  for (const grain of ["hour", "day"] as const) {
    for (const dailyLogin of [true, false]) {
      const o = { grain, vendorAttempt: true, dailyLogin, hourlyLogin: dailyLogin };
      assertOnlyBoundedRecords(usageRowsSql(o), `rows ${grain}`);
      assertOnlyBoundedRecords(usageBucketsSql({ ...o, match: "filter" }), `series ${grain}`);
      assertOnlyBoundedRecords(usageBucketsSql({ ...o, match: "exact" }), `breakdown ${grain}`);
    }
  }
  for (const split of ["product", "login"] as const) {
    assertOnlyBoundedRecords(statementSummarySql({ vendorAttempt: true }, { hourly: true, split, dailyLogin: true, hourlyLogin: true }),
      `statement by ${split}`);
  }
});

test("the raw edge is only the sliver before the first whole hour and the minutes past the watermark", () => {
  const sql = norm(usageRowsSql({ grain: "day", vendorAttempt: true, dailyLogin: true, hourlyLogin: true }));
  assert.match(sql, /s\.submitted_at >= cut\.hourly_lo AND s\.submitted_at < LEAST\(cut\.first_hour, cut\.seam, cut\.until\)/);
  assert.match(sql, /s\.submitted_at >= cut\.seam AND s\.submitted_at < cut\.until/);
  assert.match(sql, /FROM cut, usage_daily u WHERE u\.day >= \(cut\.since AT TIME ZONE \$3\)::date AND u\.day < \(cut\.hourly_lo AT TIME ZONE \$3\)::date/);
  assert.match(sql, /FROM cut, usage_hourly h WHERE h\.hour >= cut\.first_hour AND h\.hour < cut\.seam/);
  //the hour grain reads no daily rows
  assert.doesNotMatch(norm(usageRowsSql({ grain: "hour", vendorAttempt: true, dailyLogin: true, hourlyLogin: true })), /usage_daily/);
});

test("without the login columns the summaries never name them, and a login filter matches only the records", () => {
  const sql = norm(usageRowsSql({ grain: "day", vendorAttempt: true, dailyLogin: false, hourlyLogin: false }));
  assert.doesNotMatch(sql, /[uh]\.system_id/);
  assert.match(sql, /NULL::text AS login/);
  assert.match(sql, /\$5::text IS NULL/);
});

test("filters, grains and keys", () => {
  assert.deepEqual(parseUsageFilters(new URLSearchParams("account= acme &product=p1")),
    { account: "acme", login: null, product: "p1", from: null, to: null });
  //'' is not one login (no login, or every login before 0.15.1): never a filter
  assert.equal((parseUsageFilters(new URLSearchParams("login=%20")) as { login: string | null }).login, null);
  assert.match(norm(usageRowsSql({ grain: "day", vendorAttempt: true, dailyLogin: true, hourlyLogin: true })),
    /\(\$5::text IS NULL OR u\.system_id = \$5::text\)/, "a login filter compares equal, so '' never matches it");
  assert.ok("error" in parseUsageFilters(new URLSearchParams("from=2026-01-01")));
  assert.ok("error" in parseUsageFilters(new URLSearchParams("from=2026-01-01&to=2026-06-01")), "over 92 days");
  assert.deepEqual(filterQuery({ account: "a", login: null, product: null, from: null, to: null }), { account: "a" });
  assert.equal(grainFor("24h", {}), "hour");
  assert.equal(grainFor("7d", {}), "day");
  assert.equal(grainFor("1h", { from: "2026-01-01", to: "2026-01-01" }), "hour", "one day: hours");
  assert.equal(grainFor("1h", { from: "2026-01-01", to: "2026-01-02" }), "day");
  assert.equal(expandable("1h", {}), false);
  assert.equal(expandable("24h", {}), true);
  assert.notEqual(rowKey({ accountId: "a", login: null, product: "p" }), rowKey({ accountId: "a", login: "", product: "p" }));
  assert.deepEqual(breakdownQuery({ accountId: "a", login: null, product: "p" }), { ra: "a", rp: "p" });
});

/**
 * Against PostgreSQL: rolled days (some from before the login column), hours (some without a
 * login) and a raw edge past the watermark. For 24 hours, 7 and 30 days the rows add up to the
 * window, each row's breakdown adds up to the row, and the window equals the call records' own count.
 */
const URL = process.env.CDR_TIER_TEST_DATABASE_URL ?? process.env.STATEMENT_TEST_DATABASE_URL;

describe("Usage rows and breakdowns against PostgreSQL", { skip: URL ? false : "CDR_TIER_TEST_DATABASE_URL is not set" }, () => {
  const SCHEMA = `usage_grid_${process.pid}`;
  let pool: import("pg").Pool;
  const run = async <T,>(sql: string, params: unknown[] = []) => (await pool.query(sql, params)).rows as T[];
  let now: Date;

  before(async () => {
    const pg = (await import("pg")).default;
    pool = new pg.Pool({ connectionString: URL, max: 1, options: `-c search_path=${SCHEMA} -c timezone=UTC` });
    await run(`CREATE SCHEMA ${SCHEMA}`);
    await run(`CREATE TABLE cdr_submit (id bigserial PRIMARY KEY, gateway_msg_id text NOT NULL, part_no int NOT NULL DEFAULT 1,
      account_id text, system_id text, product text, submitted_at timestamptz NOT NULL, price bigint, cost bigint,
      retry_count int NOT NULL DEFAULT 0, vendor_attempt int NOT NULL DEFAULT 0)`);
    await run(`CREATE TABLE cdr_final (gateway_msg_id text NOT NULL, part_no int NOT NULL DEFAULT 1, final_state text NOT NULL,
      final_at timestamptz NOT NULL, dlr_state int, err_code text)`);
    const summary = `account_id text NOT NULL, product text NOT NULL, system_id text NOT NULL DEFAULT '',
      submitted bigint NOT NULL, delivered bigint NOT NULL, failed bigint NOT NULL, expired bigint NOT NULL,
      pending_at_rollup bigint NOT NULL, price_total bigint NOT NULL`;
    await run(`CREATE TABLE usage_daily (day date NOT NULL, ${summary})`);
    await run(`CREATE TABLE usage_hourly (hour timestamptz NOT NULL, vendor text NOT NULL DEFAULT '', ${summary})`);
    await run("CREATE TABLE usage_rollup_cursor (one boolean PRIMARY KEY DEFAULT TRUE, hourly_hwm timestamptz, last_daily_day date)");

    now = new Date((await run<{ now: Date }>("SELECT now() AS now"))[0].now);
    const hwm = new Date(now.getTime() - 10 * 60_000);
    //every 47 minutes for 35 days, two accounts, two logins (and some with none), two products
    let n = 0;
    for (let t = now.getTime() - 35 * 86_400_000; t < now.getTime() - 60_000; t += 47 * 60_000) {
      n++;
      const account = n % 3 === 0 ? "beta" : "acme";
      const login = n % 7 === 0 ? null : n % 2 === 0 ? "L1" : "L2";
      const product = n % 5 === 0 ? "p2" : "p1";
      const state = n % 4 === 0 ? "FAILED" : n % 11 === 0 ? null : "DELIVERED";
      const id = `m${n}`;
      await run(`INSERT INTO cdr_submit (gateway_msg_id, account_id, system_id, product, submitted_at, price)
                 VALUES ($1, $2, $3, $4, $5, 100)`, [id, account, login, product, new Date(t)]);
      if (state) {
        await run("INSERT INTO cdr_final (gateway_msg_id, final_state, final_at) VALUES ($1, $2, $3)", [id, state, new Date(t + 60_000)]);
      }
    }
    //the cursor: hours rolled to the watermark; days before yesterday rolled, nightly
    await run("INSERT INTO usage_rollup_cursor (hourly_hwm, last_daily_day) VALUES ($1, (now() AT TIME ZONE 'UTC')::date - 1)", [hwm]);
    const counts = `count(*), count(*) FILTER (WHERE f.final_state = 'DELIVERED'),
                    count(*) FILTER (WHERE f.final_state = 'FAILED'), 0, count(*) FILTER (WHERE f.final_state IS NULL), sum(s.price)`;
    //days: those older than ten days rolled before the login column ('')
    await run(`INSERT INTO usage_daily (day, account_id, product, system_id, submitted, delivered, failed, expired, pending_at_rollup, price_total)
      SELECT (s.submitted_at AT TIME ZONE 'UTC')::date, s.account_id, s.product,
             CASE WHEN s.submitted_at < now() - interval '10 days' THEN '' ELSE COALESCE(s.system_id, '') END, ${counts}
        FROM cdr_submit s LEFT JOIN cdr_final f USING (gateway_msg_id)
       WHERE s.submitted_at < (SELECT last_daily_day FROM usage_rollup_cursor)::timestamp AT TIME ZONE 'UTC'
       GROUP BY 1, 2, 3, 4`);
    //hours: up to the watermark (the hour it falls in holds up to it); those older than three days
    //without a login, as an hourly summary from before V1.113.0 would have them
    await run(`INSERT INTO usage_hourly (hour, account_id, product, system_id, submitted, delivered, failed, expired, pending_at_rollup, price_total)
      SELECT date_trunc('hour', s.submitted_at), s.account_id, s.product,
             CASE WHEN s.submitted_at < now() - interval '3 days' THEN '' ELSE COALESCE(s.system_id, '') END, ${counts}
        FROM cdr_submit s LEFT JOIN cdr_final f USING (gateway_msg_id)
       WHERE s.submitted_at >= now() - interval '33 days' AND s.submitted_at < $1
       GROUP BY 1, 2, 3, 4`, [hwm]);
  });

  after(async () => {
    if (pool) {
      await run(`DROP SCHEMA IF EXISTS ${SCHEMA} CASCADE`).catch(() => undefined);
      await pool.end();
    }
  });

  const options = (grain: "hour" | "day"): Omit<UsageGridOptions, "match"> =>
    ({ grain, vendorAttempt: true, dailyLogin: true, hourlyLogin: true });

  for (const [label, grain, sinceSql] of [
    ["24 hours", "hour", "now() - interval '24 hours'"],
    ["7 days", "day", "date_trunc('day', now() - interval '7 days')"],
    ["30 days", "day", "date_trunc('day', now() - interval '30 days')"],
  ] as const) {
    test(`${label}: rows add up to the window, breakdowns to their rows, the window to the records`, async () => {
      const [w] = await run<{ since: Date; until: Date }>(`SELECT ${sinceSql} AS since, now() AS until`);
      const binds = [w.since, w.until, "UTC", null, null, null];
      const rows = await run<Record<string, string>>(usageRowsSql(options(grain)), [...binds, 50, 0]);
      const series = await run<Record<string, string>>(usageBucketsSql({ ...options(grain), match: "filter" }), binds);
      const n = (rs: Record<string, string>[]) => sumBuckets(rs.map((r) => ({
        submitted: Number(r.submitted), delivered: Number(r.delivered), failed: Number(r.failed),
        pending: Number(r.pending), price: Number(r.price) })));
      assert.ok(rows.length > 3 && rows.length < 50);
      assert.deepEqual(n(rows), n(series), "the rows are the window");
      const [truth] = await run<{ n: string }>(
        "SELECT count(*) AS n FROM cdr_submit WHERE submitted_at >= $1 AND submitted_at < $2", [w.since, w.until]);
      assert.equal(n(series).submitted, Number(truth.n), "the summaries and the edge are every message, once");
      assert.ok(rows.some((r) => r.login === null), "a '—' row");
      assert.ok(rows.some((r) => r.login === "L1"));
      for (const r of rows) {
        const buckets = await run<Record<string, string>>(usageBucketsSql({ ...options(grain), match: "exact" }),
          [w.since, w.until, "UTC", r.account_id, r.login, r.product]);
        assert.deepEqual(n(buckets), n([r]), `${r.account_id}/${r.login}/${r.product}: the sub-rows add up to the row`);
      }
      //one sub-row per hour or day of the window
      const first = await run<Record<string, string>>(usageBucketsSql({ ...options(grain), match: "exact" }),
        [w.since, w.until, "UTC", rows[0].account_id, rows[0].login, rows[0].product]);
      assert.equal(first.length, grain === "hour" ? 25 : (label === "7 days" ? 8 : 31));
      //per login and per product, the same whole
      const byLogin = new Map<string, number>();
      const byProduct = new Map<string, number>();
      for (const r of rows) {
        byLogin.set(String(r.login), (byLogin.get(String(r.login)) ?? 0) + Number(r.submitted));
        byProduct.set(String(r.product), (byProduct.get(String(r.product)) ?? 0) + Number(r.submitted));
      }
      const total = (m: Map<string, number>) => [...m.values()].reduce((a, b) => a + b, 0);
      assert.equal(total(byLogin), total(byProduct));
    });
  }

  test("a filter narrows rows and the window alike", async () => {
    const [w] = await run<{ since: Date; until: Date }>("SELECT date_trunc('day', now() - interval '7 days') AS since, now() AS until");
    const rows = await run<Record<string, string>>(usageRowsSql(options("day")), [w.since, w.until, "UTC", "acme", "L1", null, 50, 0]);
    assert.ok(rows.length > 0 && rows.every((r) => r.account_id === "acme" && r.login === "L1"));
    const series = await run<Record<string, string>>(usageBucketsSql({ ...options("day"), match: "filter" }),
      [w.since, w.until, "UTC", "acme", "L1", null]);
    assert.equal(series.reduce((t, b) => t + Number(b.submitted), 0), rows.reduce((t, r) => t + Number(r.submitted), 0));
  });
});
