"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowUpRight, Database } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { buttonClasses } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { formatTimestamp } from "@/lib/datetime";
import { dbCardBlocks, type DbRow } from "@/lib/db-health";
import type { PoolsReport } from "@/lib/db-pools";
import type { Health } from "@/lib/health-types";

/** Where the footer's button goes: the slow-query report lost its sidebar row to this card (0.15.1). */
const SLOW_QUERIES_HREF = "/cp/database/slow-queries";

/**
 * The database, from both ends (0.15.1), in three blocks:
 *
 * <ul>
 *   <li><strong>Connection · gateway → PostgreSQL</strong>: where the gateway points, the server
 *       and schema versions, its pool and lanes, the last probe -- from `health.database`
 *       (`db_info`). A gateway without the block gets no rows here, not dashes.</li>
 *   <li><strong>Connection · panel → PostgreSQL</strong>: this panel's two pools, from
 *       `/api/control/database/pools` (host and port only, never a credential).</li>
 *   <li><strong>Admission</strong>: latency against the thresholds, submits refused since start,
 *       the receipt store's buffer and the call-record spill alarm.</li>
 * </ul>
 *
 * <p>On Queues and Health, because a slow database is what a backlog there turns out to be more
 * often than not, and from 0.15.1 it is also what refuses new submits. The footer opens Slow queries.
 */
export function DbHealthCard({ health }: { health: Health | null | undefined }) {
  const pools = usePools(health?.observed_at ?? null);
  const blocks = dbCardBlocks(health, pools);
  const { admission } = blocks;
  if (!health && !pools) {
    return null;
  }
  return (
    <Card className={cn(admission?.tone === "destructive" && "border-destructive/50", admission?.tone === "warning" && "border-warning/50")}>
      <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0">
        <CardTitle className="flex items-center gap-2">
          <Database className="h-4 w-4 text-muted-foreground" aria-hidden />
          Database
        </CardTitle>
        {admission && (
          <Badge variant={admission.tone === "success" ? "success" : admission.tone === "default" ? "outline" : admission.tone}>
            {admission.value}
          </Badge>
        )}
        <span className="text-xs text-muted-foreground">{admission?.hint ?? "as the gateway's ingresses see it"}</span>
      </CardHeader>
      <CardContent className="space-y-4">
        <Block title="Connection · gateway → PostgreSQL" rows={blocks.gateway} />
        <Block title="Connection · panel → PostgreSQL" rows={blocks.panel} />
        <Block title="Admission" rows={blocks.checks} />
      </CardContent>
      <CardFooter bar className="justify-end">
        <span className="mr-auto text-xs text-muted-foreground">
          Statements over the slow-query threshold, from the gateway&apos;s log.
        </span>
        <Link href={SLOW_QUERIES_HREF} className={buttonClasses({ variant: "outline", size: "sm" })}>
          Slow queries
          <ArrowUpRight className="ml-1.5 h-4 w-4" aria-hidden />
        </Link>
      </CardFooter>
    </Card>
  );
}

function Block({ title, rows }: { title: string; rows: DbRow[] }) {
  if (!rows.length) {
    return null;
  }
  return (
    <div>
      <div className="mb-1.5 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">{title}</div>
      <dl className="grid gap-x-6 gap-y-1.5 text-sm sm:grid-cols-2">
        {rows.map((r) => (
          <div key={r.key} className="flex items-baseline justify-between gap-3 border-b border-border/60 py-1" title={r.title}>
            <dt className="shrink-0 text-muted-foreground">{r.label}</dt>
            <dd
              className={cn(
                "min-w-0 text-right font-medium tabular-nums [overflow-wrap:anywhere]",
                r.tone === "warning" && "text-warning",
                r.tone === "destructive" && "text-destructive",
                r.tone === "success" && "text-success"
              )}
            >
              {r.at ? formatTimestamp(r.value) : r.value}
            </dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

/**
 * The panel's own pools, re-read with each health poll (the card's clock): the route answers from
 * memory, so following the poll costs a request and no query. Null until the first answer, and kept
 * through a failed one -- the last reading beats a block that flickers out.
 */
function usePools(tick: string | null): PoolsReport | null {
  const [pools, setPools] = useState<PoolsReport | null>(null);
  useEffect(() => {
    let live = true;
    fetch("/api/control/database/pools", { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : null))
      .then((body: PoolsReport | null) => {
        if (live && body?.metrics && body?.config) {
          setPools(body);
        }
      })
      .catch(() => {
        //unreachable: the last reading stands
      });
    return () => {
      live = false;
    };
  }, [tick]);
  return pools;
}
