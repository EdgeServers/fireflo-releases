"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Gauge } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { count } from "@/lib/format";
import { formatTps } from "@/lib/tps-format";
import { listenerName } from "@/lib/throughput";
import type { ThrottlePage } from "@/lib/throttles-types";
import { noteSource } from "@/lib/page-sources";

/** Rows shown before "Show all". */
const FIRST = 10;

/**
 * "SMPP throttles (0x58)" on the Refused page: who was answered ESME_RTHROTTLED at a ceiling, per
 * account × listener × login, over the page's own window and filters.
 *
 * <p>Minute aggregates, and labelled so: the gateway keeps one row per minute per node and limiter
 * (`smpp_throttle_minute`, 0.15.1) rather than a row per refused submit, so these are not among the
 * per-message refusals above and below, and cannot be opened one by one. Absent on a database
 * before V1.118.0; a filter the table cannot answer says which one rather than showing everybody.
 *
 * @param query the page's filters as its URL carries them
 */
export function ThrottleStrip({ query }: { query: string }) {
  const [page, setPage] = useState<ThrottlePage | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [all, setAll] = useState(false);

  useEffect(() => {
    const controller = new AbortController();
    fetch(`/api/control/rejected/throttles${query ? `?${query}` : ""}`, { cache: "no-store", signal: controller.signal })
      .then(async (res) => {
        noteSource("throttles", res);
        const json = await res.json().catch(() => null);
        if (!res.ok) {
          throw new Error(json?.error ?? `Request failed (${res.status})`);
        }
        setPage(json as ThrottlePage);
        setError(null);
      })
      .catch((err) => {
        if (!controller.signal.aborted) {
          setError(err instanceof Error ? err.message : "Could not read the throttles");
        }
      });
    return () => controller.abort();
  }, [query]);

  if (error) {
    return <p className="text-xs text-destructive">SMPP throttles: {error}</p>;
  }
  if (!page || page.unsupported) {
    return null;
  }
  if (page.skipped) {
    return (
      <p className="text-xs text-muted-foreground">
        SMPP throttles (0x58) are not shown: the {page.skipped} filter does not apply to them — they are kept as minute
        counts per account, listener and login.
      </p>
    );
  }
  const data = page.data;
  if (!data) {
    return null;
  }
  const window = `${new Date(data.since).toLocaleString()} – ${data.until ? new Date(data.until).toLocaleString() : "now"}`;
  if (data.total === 0) {
    return (
      <p className="text-xs text-muted-foreground">
        No SMPP submit was throttled (0x58) in this window ({window}).
      </p>
    );
  }
  const shown = all ? data.groups : data.groups.slice(0, FIRST);
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex flex-wrap items-center gap-2">
          <Gauge className="h-4 w-4 text-warning" aria-hidden />
          SMPP throttles (0x58)
          <Badge variant="warning">{count(data.total)}</Badge>
        </CardTitle>
        <CardDescription>
          Minute aggregates, {window}{data.clamped ? " — cut to the 35 days kept" : ""}: submits answered ESME_RTHROTTLED at
          a ceiling, per account, listener and login. Not in the refusal counts on this page, which are one row per
          message; a throttled client retries, so these are attempts, not lost messages.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <TableInCard>
          <THead>
            <TR>
              <TH>Account</TH>
              <TH>Listener</TH>
              <TH>Login</TH>
              <TH align="right">Throttled</TH>
              <TH>By which limit</TH>
              <TH align="right">Minutes</TH>
              <TH>Last</TH>
              <TH align="right">Rate at the time</TH>
            </TR>
          </THead>
          <TBody>
            {shown.map((g) => (
              <TR key={`${g.accountId}|${g.listener}|${g.systemId}`}>
                <TD primary>
                  {g.accountId ? (
                    <Link href={`/cp/accounts/${encodeURIComponent(g.accountId)}/limits`} className="underline-offset-4 hover:underline">
                      {g.accountId}
                    </Link>
                  ) : "—"}
                </TD>
                <TD className="font-mono text-xs">{listenerName(g.listener)}</TD>
                <TD className="font-mono text-xs">{g.systemId || "—"}</TD>
                <TD num className="text-warning">{count(g.throttled)}</TD>
                <TD className="text-xs text-muted-foreground">
                  {[
                    g.byAccount > 0 ? `${count(g.byAccount)} account ceiling` : null,
                    g.byLogin > 0 ? `${count(g.byLogin)} login TPS` : null,
                  ].filter(Boolean).join(" · ")}
                </TD>
                <TD num>{count(g.minutes)}</TD>
                <TD className="whitespace-nowrap text-xs">{new Date(g.lastMinute).toLocaleString()}</TD>
                <TD num>{g.rate != null ? `≤${formatTps(g.rate)}/s` : "—"}</TD>
              </TR>
            ))}
          </TBody>
        </TableInCard>
        <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          {data.groupCount > data.groups.length && (
            <span>The busiest {count(data.groups.length)} of {count(data.groupCount)} shown; narrow by account or listener for the rest.</span>
          )}
          {data.groups.length > FIRST && (
            <Button variant="ghost" size="sm" onClick={() => setAll((v) => !v)}>
              {all ? "Show fewer" : `Show all ${count(data.groups.length)}`}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
