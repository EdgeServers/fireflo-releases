"use client";
import { useState } from "react";
import { useConfirmChange } from "./ConfirmProvider";

export interface PropertyWrite {
  /** The listener or vendor, by its instance name: what `/api/control/workers/<name>` takes. */
  worker: string;
  key: string;
  /** The new value; empty removes the setting. */
  value: string;
  /** The stored value now, or "" when none, for the confirm dialog's from → to line. */
  current: string;
  title: string;
  /** "msg/s" or "binds": the unit the consequence sentence names. */
  unit: string;
  /** What applies when the value is removed: "the listener default". */
  fallback?: string;
}

/**
 * One worker setting written through `PATCH /api/control/workers/<name>`, confirmed once.
 *
 * <p>Not the edit form's POST, which replaces every setting of the worker: this changes one key and
 * leaves the rest alone, and the route checks the key against its allow-list (`lib/worker-settable.ts`)
 * and the account it names. The running worker adopts it on the gateway's thirty-second config poll,
 * which the confirmation and the notice both say, so nobody waits for an instant change.
 */
export function useWorkerPropertyWrite(): {
  write: (w: PropertyWrite) => Promise<boolean>;
  busy: boolean;
  notice: string;
  error: string;
} {
  const confirm = useConfirmChange();
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  const write = async (w: PropertyWrite): Promise<boolean> => {
    setNotice("");
    setError("");
    const value = w.value.trim();
    if (value !== "" && !/^\d+$/.test(value)) {
      setError(`${w.key} takes a whole number of 0 or more, or nothing to remove it.`);
      return false;
    }
    const ok = await confirm({
      title: w.title,
      consequence: value === ""
        ? `${w.key} is removed from ${w.worker}; ${w.fallback ?? "the default"} applies again. The gateway picks it up within 30 s.`
        : `${w.key} on ${w.worker} is set to ${value === "0" ? "0 (unlimited)" : `${value} ${w.unit}`}. The gateway picks it up within 30 s.`,
      confirmLabel: value === "" ? "Remove" : "Save",
      tone: "caution",
      changes: [{ label: w.key, from: w.current || "not set", to: value || "not set" }],
    });
    if (!ok) {
      return false;
    }
    setBusy(true);
    try {
      const res = await fetch(`/api/control/workers/${encodeURIComponent(w.worker)}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ property: { key: w.key, value } }),
      }).catch(() => null);
      const json = await res?.json().catch(() => null);
      if (!res?.ok) {
        setError(json?.error ?? (res ? `Request failed (${res.status})` : "Could not reach the panel's API."));
        return false;
      }
      setNotice(`${w.key} on ${w.worker} ${value === "" ? "removed" : `set to ${value}`} — the gateway picks it up within 30 s.`);
      return true;
    } finally {
      setBusy(false);
    }
  };

  return { write, busy, notice, error };
}
