"use client";
import { Fragment, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ChevronDown, ChevronRight } from "lucide-react";
import { Bar, CartesianGrid, ComposedChart, Line, XAxis, YAxis } from "recharts";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { PageHeader } from "@/components/ui/page-header";
import { Select } from "@/components/ui/select";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import { StatTile } from "@/components/ui/stat-tile";
import { ErrorCard } from "./FormNotices";
import { RangePicker } from "./RangePicker";
import { StaleNote } from "./StaleNote";
import { BreathingCard } from "./BreathingCard";
import { useStats, type Range, RANGE_VALUES, periodLabel } from "./useControlData";
import { usePeriod } from "./usePeriod";
import { useCatalogueLookup as useLookup } from "./useCatalogueLookup";
import { validateRange } from "@/lib/date-range";
import { NO_LOGIN_LABEL } from "@/lib/statement-chart";
import { FILTER_WIDTH } from "@/lib/filter-widths";
import { count, money, percent } from "@/lib/format";
import {
  EXPAND_ALL_MAX,
  NO_FILTERS,
  USAGE_PAGE_SIZE,
  breakdownQuery,
  expandable,
  filterQuery,
  rateOf,
  rowKey,
  sumBuckets,
  type UsageBucket,
  type UsageFilters,
  type UsageGridRow,
  type UsageGridView,
} from "@/lib/usage-grid";

/**
 * How much traffic went out, whether it arrived, and who sent it -- by account, login and product.
 *
 * <p>Volume and delivery lead; money is the last column rather than the headline. The question this
 * page answers is operational -- "is the platform carrying what it should, and is it landing" -- and
 * `/cp/revenue` already answers the commercial one.
 *
 * <p><strong>Read from the summaries only</strong> (0.15.1, `usage-grid-sql.ts`): the call records
 * are touched for the last few minutes and nothing else, whatever is filtered or expanded. The
 * quick filters apply when Go is pressed and never before; a row's hours or days are read when it is
 * expanded; "Expand all" opens at most the first {@link EXPAND_ALL_MAX} rows.
 */
const ANIMATION = { isAnimationActive: false } as const;

/**
 * Delivered, failed, and the rate over the top: the same three colours the customer portal uses for
 * the same three facts.
 */
const chartConfig = {
  delivered: { label: "Delivered", color: "var(--color-chart-1)" },
  failed: { label: "Failed", color: "var(--color-destructive)" },
  rate: { label: "Delivery rate", color: "var(--color-chart-2)" },
} satisfies ChartConfig;

/** Where the applied filters are remembered in this browser. */
const FILTERS_KEY = "fireflo.usage.filters";

/** A bucket as the axis and a sub-row show it: the day, or the hour in the viewer's own clock. */
function bucketLabel(bucket: string): string {
  if (bucket.length <= 10) {
    return bucket;
  }
  const at = new Date(bucket);
  return `${at.toLocaleDateString(undefined, { month: "short", day: "numeric" })} ${at.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}`;
}

export function UsageClient({ currency }: { currency: string }) {
  //opens on the last hour like every traffic page, then on whatever its user last picked (usePeriod)
  const [range, setRange] = usePeriod<Range>("usage", RANGE_VALUES, "1h");
  const [draft, setDraft] = useState<UsageFilters>(NO_FILTERS);
  const [applied, setApplied] = useState<UsageFilters>(NO_FILTERS);
  const [invalid, setInvalid] = useState("");
  const [page, setPage] = useState(0);
  const [open, setOpen] = useState<Set<string>>(new Set());

  //the applied filters, remembered: read after mount so the first frame matches the server's
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(FILTERS_KEY);
      if (raw) {
        const stored = { ...NO_FILTERS, ...(JSON.parse(raw) as Partial<UsageFilters>) };
        //eslint-disable-next-line react-hooks/set-state-in-effect -- the stored choice is only readable after mount
        setApplied(stored);
        setDraft(stored);
      }
    } catch {
      //no storage, or something unreadable in it: no filters
    }
  }, []);

  const query = useMemo(() => ({ ...filterQuery(applied), ...(page > 0 ? { page: String(page) } : {}) }), [applied, page]);
  const { data, error, loading, switching, stale, busy } = useStats<UsageGridView>("usage-grid", range, query);
  const series = useMemo(() => (data?.series ?? []).map((b) => ({
    day: b.bucket, delivered: b.delivered, failed: b.failed,
    rate: (() => { const r = rateOf(b); return r === null ? null : Math.round(r * 1000) / 10; })(),
  })), [data]);
  const totals = useMemo(() => sumBuckets(data?.series ?? []), [data]);
  const totalRate = rateOf(totals);
  const dated = Boolean(applied.from && applied.to);
  const canExpand = expandable(range, applied);
  const breakdownBase = useMemo(() => filterQuery({ ...NO_FILTERS, from: applied.from, to: applied.to }), [applied]);

  function apply(next: UsageFilters) {
    if (next.from || next.to) {
      const problem = validateRange(next.from ?? "", next.to ?? "");
      if (problem) {
        setInvalid(problem);
        return;
      }
    }
    setInvalid("");
    setApplied(next);
    setPage(0);
    setOpen(new Set());
    try {
      window.localStorage.setItem(FILTERS_KEY, JSON.stringify(next));
    } catch {
      //remembered for this visit only
    }
  }

  function toggle(key: string) {
    setOpen((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      return next;
    });
  }

  const rows = data?.rows ?? [];
  const pages = data ? Math.max(1, Math.ceil(data.totalRows / USAGE_PAGE_SIZE)) : 1;
  const what = dated ? `${applied.from} to ${applied.to}` : periodLabel(range);

  return (
    <>
      <PageHeader
        title="Usage"
        description="How much traffic went out, whether it arrived, and who sent it: by account, login and product."
        //a date range replaces the toggle while it is set; Clear brings it back
        actions={dated ? undefined : <RangePicker value={range} onChange={(r) => { setRange(r); setPage(0); setOpen(new Set()); }} busy={switching} />}
      />

      <QuickFilters
        draft={draft}
        onDraft={setDraft}
        onGo={() => apply(draft)}
        onClear={() => { setDraft(NO_FILTERS); apply(NO_FILTERS); }}
        invalid={invalid}
        busy={switching}
        changed={JSON.stringify(draft) !== JSON.stringify(applied)}
      />

      <StaleNote stale={stale} />
      {/* still reading in the background: a calm card, never the timeout error */}
      {busy && !data && <BreathingCard what={`${what} of traffic`} />}
      <ErrorCard error={error} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile label="Sent" value={count(totals.submitted)} loading={loading} />
        <StatTile label="Delivered" value={count(totals.delivered)} tone="positive" loading={loading} />
        <StatTile label="Failed" value={count(totals.failed)} tone={totals.failed > 0 ? "negative" : "default"} loading={loading} />
        <StatTile label="Delivery rate" value={percent(totalRate)} loading={loading}
          hint={totals.pending > 0 ? `${count(totals.pending)} still awaiting a receipt` : undefined} />
      </div>

      <Card>
        <CardHeader bar>
          <CardTitle>Traffic</CardTitle>
          <p className="text-xs text-muted-foreground">
            Bars: messages that settled, per {data?.grain === "day" ? "day" : "hour"} · Line: delivery rate. Messages still
            awaiting a receipt are counted above but not drawn, so the latest bar does not read as a spike.
          </p>
        </CardHeader>
        <CardContent>
          {loading && !data ? (
            <div className="h-64" />
          ) : (
            <ChartContainer config={chartConfig} className="h-64 w-full">
              <ComposedChart data={series} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--color-border)" />
                <XAxis dataKey="day" tickLine={false} axisLine={false} interval="preserveStartEnd"
                  tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                  tickFormatter={(v: string) => (v.length > 10 ? v.slice(11, 16) : v.slice(5))} />
                <YAxis yAxisId="volume" tickLine={false} axisLine={false} width={44} allowDecimals={false}
                  tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }} />
                {/* its own axis, fixed at 0-100, so the rate is not flattened into the baseline */}
                <YAxis yAxisId="rate" orientation="right" domain={[0, 100]} tickLine={false} axisLine={false} width={38}
                  tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }} tickFormatter={(v: number) => `${v}%`} />
                <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
                <Bar {...ANIMATION} yAxisId="volume" dataKey="delivered" stackId="v" fill={chartConfig.delivered.color} radius={[0, 0, 2, 2]} />
                <Bar {...ANIMATION} yAxisId="volume" dataKey="failed" stackId="v" fill={chartConfig.failed.color} radius={[2, 2, 0, 0]} />
                <Line yAxisId="rate" dataKey="rate" stroke={chartConfig.rate.color} strokeWidth={2} dot={false} connectNulls={false} />
              </ComposedChart>
            </ChartContainer>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader bar className="flex flex-row flex-wrap items-center gap-2 space-y-0">
          <div className="min-w-0 flex-1">
            <CardTitle>By account, login and product</CardTitle>
            <p className="text-xs text-muted-foreground">
              Heaviest first.{canExpand ? ` Open a row for its ${data?.grain === "day" ? "days" : "hours"}.` : ""}
              {data && data.grain === "day" && !data.logins.daily
                ? ` Days the gateway summarised before it recorded logins (0.15.1) show ${NO_LOGIN_LABEL}: every login together.`
                : ""}
            </p>
          </div>
          {canExpand && rows.length > 0 && (
            <Button size="sm" variant="outline" onClick={() => setOpen(open.size > 0 ? new Set() :
              new Set(rows.slice(0, EXPAND_ALL_MAX).map(rowKey)))}>
              {open.size > 0 ? "Collapse all" : `Expand all${rows.length > EXPAND_ALL_MAX ? ` (first ${EXPAND_ALL_MAX})` : ""}`}
            </Button>
          )}
        </CardHeader>
        <CardContent>
          {rows.length === 0 ? (
            <p className="text-sm text-muted-foreground">{loading ? "Loading…" : "No traffic in this window."}</p>
          ) : (
            <>
              <TableInCard className="tabular-nums">
                <THead>
                  <tr>
                    {canExpand && <TH className="w-8"><span className="sr-only">Expand</span></TH>}
                    <TH>Account</TH>
                    <TH>Login</TH>
                    <TH>Product</TH>
                    <TH align="right">Sent</TH>
                    <TH align="right">Delivered</TH>
                    <TH align="right">Failed</TH>
                    <TH align="right">Pending</TH>
                    <TH align="right">Rate</TH>
                    <TH align="right">Billed</TH>
                  </tr>
                </THead>
                <TBody>
                  {rows.map((r) => {
                    const key = rowKey(r);
                    const isOpen = open.has(key);
                    return (
                      <Fragment key={key}>
                        <FigureRow row={r} currency={currency} expand={canExpand
                          ? { open: isOpen, onToggle: () => toggle(key) }
                          : undefined} />
                        {isOpen && (
                          <Breakdown range={range} query={{ ...breakdownBase, ...breakdownQuery(r) }} currency={currency} />
                        )}
                      </Fragment>
                    );
                  })}
                </TBody>
              </TableInCard>
              {pages > 1 && (
                <div className="mt-3 flex items-center justify-end gap-2 text-sm">
                  <span className="text-muted-foreground">Page {page + 1} of {pages} · {count(data?.totalRows ?? 0)} rows</span>
                  <Button size="sm" variant="outline" disabled={page === 0 || switching}
                    onClick={() => { setPage(page - 1); setOpen(new Set()); }}>Previous</Button>
                  <Button size="sm" variant="outline" disabled={page + 1 >= pages || switching}
                    onClick={() => { setPage(page + 1); setOpen(new Set()); }}>Next</Button>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </>
  );
}

/** "—" for none: traffic that named no account, a login not recorded, no product. */
function Dash() {
  return <span className="text-muted-foreground">—</span>;
}

function FigureRow({ row, currency, expand, sub = false }: {
  row: UsageGridRow | (UsageBucket & { label: string });
  currency: string;
  expand?: { open: boolean; onToggle: () => void };
  sub?: boolean;
}) {
  const rate = rateOf(row);
  const top = "accountId" in row ? row : null;
  return (
    <TR className={sub ? "bg-muted/30 text-xs" : undefined}>
      {expand !== undefined && (
        <TD>
          <button type="button" onClick={expand.onToggle} aria-expanded={expand.open}
            aria-label={expand.open ? "Hide the breakdown" : "Show the breakdown"}
            className="rounded p-0.5 text-muted-foreground hover:text-foreground">
            {expand.open ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          </button>
        </TD>
      )}
      {sub && <TD />}
      {top ? (
        <>
          <TD>
            {top.accountId ? (
              <Link href={`/cp/accounts/${encodeURIComponent(top.accountId)}`} className="font-mono text-primary hover:underline">
                {top.accountId}
              </Link>
            ) : <Dash />}
          </TD>
          {/* none is not one login: the messages that named none, and on days summarised before
              0.15.1 every login together -- said in words, and never offered as a filter */}
          <TD className="font-mono">{top.login ?? <span className="font-sans text-muted-foreground">{NO_LOGIN_LABEL}</span>}</TD>
          <TD>{top.product ?? <Dash />}</TD>
        </>
      ) : (
        <TD colSpan={3} muted>{(row as { label: string }).label}</TD>
      )}
      <TD align="right">{count(row.submitted)}</TD>
      <TD align="right">{count(row.delivered)}</TD>
      <TD align="right">{row.failed > 0 ? <span className="text-destructive">{count(row.failed)}</span> : count(0)}</TD>
      <TD align="right" muted>{count(row.pending)}</TD>
      <TD align="right">{percent(rate)}</TD>
      <TD align="right">{money(row.price, currency)}</TD>
    </TR>
  );
}

/** One row's hours or days, read when it is opened: the same summaries, that row's keys exactly. */
function Breakdown({ range, query, currency }: { range: Range; query: Record<string, string>; currency: string }) {
  const { data, error, busy } = useStats<{ grain: string; buckets: UsageBucket[] }>("usage-breakdown", range, query);
  if (!data) {
    return (
      <TR className="bg-muted/30 text-xs">
        <TD colSpan={10} muted>{error ? <span className="text-destructive">{error}</span> : busy ? "Still reading…" : "Loading…"}</TD>
      </TR>
    );
  }
  return (
    <>
      {data.buckets.map((b) => (
        <FigureRow key={b.bucket} sub currency={currency} row={{ ...b, label: bucketLabel(b.bucket) }} />
      ))}
    </>
  );
}

/**
 * The quick-filter bar: an account and a login by typeahead (the catalogue, never call records), a
 * product, and an optional date range that replaces the toggle. Nothing is read until Go.
 */
function QuickFilters({ draft, onDraft, onGo, onClear, invalid, busy, changed }: {
  draft: UsageFilters;
  onDraft: (next: UsageFilters) => void;
  onGo: () => void;
  onClear: () => void;
  invalid: string;
  busy: boolean;
  changed: boolean;
}) {
  const accounts = useLookup("account", draft.account ?? "", null);
  const logins = useLookup("login", draft.login ?? "", draft.account);
  const products = useLookup("product", "", null);
  const set = (key: keyof UsageFilters, value: string) => onDraft({ ...draft, [key]: value.trim() ? value : null });
  return (
    <form className="flex flex-wrap items-end gap-3" onSubmit={(e) => { e.preventDefault(); onGo(); }}>
      <Field label="Account" className={FILTER_WIDTH.account}>
        <Input value={draft.account ?? ""} list="usage-accounts" placeholder="any" autoComplete="off"
          onChange={(e) => set("account", e.target.value)} />
        <datalist id="usage-accounts">{accounts.map((a) => <option key={a} value={a} />)}</datalist>
      </Field>
      <Field label="Login" className={FILTER_WIDTH.account}>
        <Input value={draft.login ?? ""} list="usage-logins" placeholder="any" autoComplete="off"
          onChange={(e) => set("login", e.target.value)} />
        <datalist id="usage-logins">{logins.map((a) => <option key={a} value={a} />)}</datalist>
      </Field>
      <Field label="Product" className={FILTER_WIDTH.select}>
        <Select value={draft.product ?? ""} onChange={(e) => set("product", e.target.value)}>
          <option value="">Any product</option>
          {products.map((p) => <option key={p} value={p}>{p}</option>)}
        </Select>
      </Field>
      <Field label="From" className={FILTER_WIDTH.select}>
        <Input type="date" value={draft.from ?? ""} onChange={(e) => set("from", e.target.value)} />
      </Field>
      <Field label="To" className={FILTER_WIDTH.select}>
        <Input type="date" value={draft.to ?? ""} onChange={(e) => set("to", e.target.value)} />
      </Field>
      <Button type="submit" className="relative" aria-busy={busy || undefined}>
        Go
        {busy && <span className="tab-busy-bar inset on-fill" aria-hidden />}
      </Button>
      <Button type="button" variant="ghost" onClick={onClear}>Clear</Button>
      {invalid ? (
        <p className="pb-2 text-sm text-destructive" role="alert">{invalid}</p>
      ) : changed ? (
        <p className="pb-2 text-xs text-muted-foreground">Changed — press Go</p>
      ) : null}
    </form>
  );
}

