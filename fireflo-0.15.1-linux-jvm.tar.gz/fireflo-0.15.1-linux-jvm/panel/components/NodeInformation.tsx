"use client";
import { useEffect, useRef, useState } from "react";
import { ChevronDown, ChevronRight, RefreshCw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { HealthStrip } from "./CardBits";
import { NeedsCapability } from "./NeedsCapability";
import { useHealth } from "./useHealth";
import { NODE_IDENTITY } from "@/lib/capabilities";
import { formatClockTime, formatTimestamp } from "@/lib/datetime";
import { elapsed } from "@/lib/format";
import type { ClusterNode, Health } from "@/lib/health-types";
import {
  initiallyOpen, liveVersions, NODE_INFO_HASH, NODE_INFO_KEY, nodeSummary, selfOpenReason, sortNodes,
} from "@/lib/node-info";
import { cn } from "@/lib/utils";

/**
 * Node information, under the Gateway page's title (0.15.1): every gateway process in the cluster,
 * as the one this panel talks to sees them. It replaced the Nodes page, whose /cp/nodes now
 * redirects to `/cp/gateway#nodes`.
 *
 * <p>Read from `health.cluster.nodes` (gateway 0.14, `node_identity`), which the health poll already
 * carries, so the section costs no request of its own. In memory mode the list is the one node; on
 * Kafka it is every node that has heartbeaten within the node timeout and the dead ones still
 * remembered.
 *
 * <p>Closed by default, one line saying how many nodes and how many are alive; the choice is kept
 * per browser. It opens itself for a dead node or live nodes on different releases, and on
 * `#nodes`.
 *
 * <p>The node this panel is asking is marked, because "alive" is that node's opinion of the others
 * and an operator reading two panels against two nodes should know whose opinion they hold.
 */
export function NodeInformationSection() {
  const { health, error, loading, reload } = useHealth();
  return (
    <NeedsCapability health={health} loading={loading} error={error} name={NODE_IDENTITY} feature="its cluster nodes">
      {health && <Section health={health} reload={reload} />}
    </NeedsCapability>
  );
}

function Section({ health, reload }: { health: Health; reload: () => void }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLElement>(null);
  const lastReason = useRef<string | null>(null);
  const self = health.node_id?.trim() || null;
  const nodes = sortNodes(health.cluster?.nodes ?? [], self);
  const reason = selfOpenReason(nodes);

  //read after mount: localStorage and the hash do not exist while the page renders on the server
  useEffect(() => {
    let stored: string | null = null;
    try {
      stored = window.localStorage.getItem(NODE_INFO_KEY);
    } catch {
      //private window or blocked storage: closed stands
    }
    const hash = window.location.hash;
    setOpen(initiallyOpen(stored, hash));
    if (hash === NODE_INFO_HASH) {
      ref.current?.scrollIntoView({ block: "start" });
    }
    const onHash = () => {
      if (window.location.hash === NODE_INFO_HASH) {
        setOpen(true);
        ref.current?.scrollIntoView({ block: "start" });
      }
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  //a new alarm opens it, without remembering that: the operator's own choice is what is kept
  useEffect(() => {
    if (reason && reason !== lastReason.current) {
      setOpen(true);
    }
    lastReason.current = reason;
  }, [reason]);

  const toggle = () => setOpen((was) => {
    try {
      window.localStorage.setItem(NODE_INFO_KEY, was ? "0" : "1");
    } catch {
      //remembered for this page only
    }
    return !was;
  });

  return (
    <section ref={ref} id="nodes" className="scroll-mt-20 rounded-lg border border-border bg-card">
      <div className="flex w-full items-center gap-3 px-4 py-3">
        <button
          type="button"
          onClick={reload}
          aria-label="Refresh"
          title="Refresh node information"
          className="-ml-1.5 rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
        >
          <RefreshCw className="h-4 w-4" aria-hidden />
        </button>
        <button
          type="button"
          onClick={toggle}
          aria-expanded={open}
          aria-controls="node-information-body"
          className="flex min-w-0 flex-1 items-center gap-3 text-left"
        >
          {open
            ? <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />
            : <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />}
          <span className="text-title">Node information</span>
          {health.cluster?.mode && <Badge variant="outline" className="font-mono text-xs">{health.cluster.mode}</Badge>}
          <span className="truncate text-sm text-muted-foreground">{nodeSummary(nodes, self)}</span>
        </button>
        <span className="shrink-0 text-sm text-muted-foreground max-sm:hidden">
          read at <span className="tabular-nums">{formatClockTime(health.observed_at)}</span>
        </span>
      </div>
      {open && (
        <div id="node-information-body" className="border-t border-border">
          <NodeInformation health={health} nodes={nodes} self={self} />
        </div>
      )}
    </section>
  );
}

/** The strips, the table and the footnote: what the Nodes page showed, inside the open section. */
export function NodeInformation({ health, nodes, self }: { health: Health; nodes: ClusterNode[]; self: string | null }) {
  const dead = nodes.filter((n) => !n.alive).length;
  const versions = liveVersions(nodes);
  return (
    <>
      {dead > 0 && (
        <HealthStrip tone="destructive" className="mx-4 mt-3">
          {dead} node{dead === 1 ? " has" : "s have"} missed the node timeout. Its vendors and partitions move to the
          others; if it is not coming back, nothing more is needed.
        </HealthStrip>
      )}
      {versions.length > 1 && (
        <HealthStrip tone="warning" className="mx-4 mt-3">
          The live nodes run {versions.length} different releases ({versions.join(", ")}). A rolling restart
          in progress is fine; a cluster left like this is not.
        </HealthStrip>
      )}
      <div className="p-4 pt-3">
        {nodes.length === 0 ? (
          <p className="py-3 text-sm text-muted-foreground">The gateway lists no nodes, not even itself.</p>
        ) : (
          <TableInCard>
            <THead>
              <TR>
                <TH>Node</TH>
                <TH>Host</TH>
                <TH>Version</TH>
                <TH>Started</TH>
                <TH>Last heartbeat</TH>
                <TH>State</TH>
                <TH>Ops URL</TH>
              </TR>
            </THead>
            <TBody>
              {nodes.map((n) => (
                <NodeRow key={n.nodeId} node={n} self={n.nodeId === self} observedAt={health.observed_at ?? null} />
              ))}
            </TBody>
          </TableInCard>
        )}
      </div>
      <p className="px-4 pb-3 text-xs text-muted-foreground">
        A node&apos;s id is <code>FIREFLO_INSTANCE_ID</code> in its environment, never a setting in the database:
        two nodes sharing one row would share one name.
      </p>
    </>
  );
}

function NodeRow({ node, self, observedAt }: { node: ClusterNode; self: boolean; observedAt: string | null }) {
  return (
    <TR className={cn(!node.alive && "text-muted-foreground")}>
      <TD className="font-mono text-xs">
        {node.nodeId}
        {self && <Badge variant="outline" className="ml-2 text-2xs">this one</Badge>}
      </TD>
      <TD className="font-mono text-xs">{node.host?.trim() || "—"}</TD>
      <TD className="font-mono text-xs">{node.version?.trim() || "—"}</TD>
      <TD className="tabular-nums" title={node.startedAt ?? undefined}>{formatTimestamp(node.startedAt) || "—"}</TD>
      <TD className="tabular-nums" title={node.heartbeatAt ?? undefined}>
        {!node.heartbeatAt
          ? "—"
          : node.alive
            ? `${formatClockTime(node.heartbeatAt)} (${elapsed(ageSeconds(node.heartbeatAt, observedAt))} ago)`
            : formatTimestamp(node.heartbeatAt)}
      </TD>
      <TD>
        {node.alive ? <Badge variant="success">alive</Badge> : <Badge variant="destructive">missed the node timeout</Badge>}
      </TD>
      <TD className="font-mono text-xs">{node.opsUrl?.trim() || "—"}</TD>
    </TR>
  );
}

/** Seconds from a heartbeat to the read, by the gateway's clock on both sides rather than the browser's. */
function ageSeconds(at: string, observedAt: string | null): number | null {
  const then = Date.parse(at);
  const now = observedAt ? Date.parse(observedAt) : Date.now();
  if (Number.isNaN(then) || Number.isNaN(now)) {
    return null;
  }
  return Math.max(0, Math.round((now - then) / 1000));
}
