"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ChevronsUpDown, Maximize, Minus, Pause, Play, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { Segmented } from "@/components/ui/segmented";
import { HealthStrip } from "./CardBits";
import { ConnectivityBoxMenu, useBoxActions } from "./ConnectivityBoxMenu";
import { ConnectivityCanvas, type CanvasHandle, type FlowFilter } from "./ConnectivityCanvas";
import { ConnectivityCounters, useLiveCounters } from "./ConnectivityCounters";
import { SearchInput } from "./SearchInput";
import { useHealth } from "./useHealth";
import { usePoll } from "./usePoll";
import { useWorkers } from "./useWorkers";
import {
  buildMapInput, clientsOf, EMPTY_LISTENER_HISTORY, EMPTY_QUEUE_HISTORY, foldListener, foldQueue, routedVendors, throttledOn,
  type ListenerHistory, type QueueHistory, type RoutingGroupLike, type RoutingTableLike,
} from "@/lib/connectivity-data";
import {
  EMPTY_VIEW, fullCount, layoutMap, OTHER_PORTS, PAGE_SIZE, rateText, searchMap, totalsText, vendorGroupOpen, visiblePorts,
  type BoxAction, type ClientIn, type MapBox, type MapView,
} from "@/lib/connectivity-layout";
import type { ConnectivityCounts, CountsWindow } from "@/lib/connectivity-counts";
import { sinceText } from "@/lib/connectivity-counters";
import { isSlowAnswer, slowNote } from "@/lib/gateway-slow";
import { hasCapability, ROUTING_VIEW } from "@/lib/capabilities";
import type { RoutingMap } from "@/lib/gateway-routing-view";
import type { Health, HealthSession } from "@/lib/health-types";
import { showKafkaPage } from "@/lib/kafka-topics";
import type { VendorBacklog, VendorBacklogAnswer } from "@/lib/vendor-backlog";
import { KIND, trafficKey } from "@/lib/worker-types";
import { noteSource } from "@/lib/page-sources";

/** How often everything is read: health, the backlog, and each listener's sessions. */
const POLL_MS = 5_000;
/** How often the last hour's counts are read: an hour's sum barely moves in five seconds. */
const COUNTS_POLL_MS = 15_000;
/** The counts window, remembered in this browser. */
const COUNTS_KEY = "fireflo.connectivity.counts";
/** A failed read keeps the last hour's answer this long before the boxes show a dash. A slow gateway's does not count. */
const COUNTS_STALE_MS = 60_000;
/** A slow routing read is asked again after this long (it is otherwise read once). */
const ROUTING_RETRY_MS = 10_000;
/** The gateway's page cap for the sessions query. */
const PAGE = 200;

const FLOWS = [
  { value: "all", label: "All" },
  { value: "submits", label: "Submits" },
  { value: "receipts", label: "Receipts" },
] as const satisfies readonly { value: FlowFilter; label: string }[];

/** The last hour's counts as last read: absent (204), an answer, or a failure that keeps the last. */
interface HourState {
  /** False once the gateway said it has no live series; null until the first answer. */
  available: boolean | null;
  data: ConnectivityCounts | null;
  at: number;
  error: string;
  /** The last read found the gateway slow: `data` is the last good answer, from `at` (0.15.1). */
  slow: boolean;
}

function readWindow(): CountsWindow {
  try {
    return window.localStorage.getItem(COUNTS_KEY) === "bind" ? "bind" : "hour";
  } catch {
    return "hour";
  }
}

interface Snapshot {
  rows: ReadonlyMap<string, HealthSession[]>;
  history: ReadonlyMap<string, ListenerHistory>;
  backlog: VendorBacklog[];
  at: number;
}

/**
 * Connectivity: who is connected, through which port and node, to which vendor, and how fast each
 * link is moving right now (`S['connectivity']` in the mockups).
 *
 * <p>Every five seconds, while not paused: health (the shared poll, asked to refresh), the vendor
 * backlog, and one `sessions` read per enabled listener with anything bound -- paged at the
 * listener's bound count, so fifty clients on a port is one call. The sessions fold into per-client
 * rates exactly as the listener Status tab's do (`lib/live-sessions.ts`). Each health answer adds a
 * sample of the node's queue (the last twelve kept) for its trend. The routing tables and groups are
 * read once, for which vendors are routed to and which a group frames: from the gateway's memory
 * (`/api/control/connectivity/routing`, capability `routing_view`), or -- on an older gateway only --
 * from the config routes `/api/control/routing` and `/api/control/groups`. Nothing is stored; the
 * rates start when the page opens.
 *
 * <p>Beside the rates, MT and DLR counts over the window the Counts control picks: the last hour
 * (default) from the gateway's in-memory live series, read every fifteen seconds through
 * `/api/control/connectivity/counts`, or since bind from the session counters this page already
 * reads. A gateway without `live_series` answers 204 and "since bind" is the only choice. Neither
 * window reads the database. With `routing_view` the page reads nothing from PostgreSQL at all --
 * everything on it is the gateway's memory and goes with a restart.
 *
 * <p>Under the map, three live counters -- MT, DLR and PostgreSQL since the gateway's process
 * started, summed across the cluster -- read every 2 s on their own timer through
 * `/api/control/connectivity/counters` (capability `live_counters`), paused with the rest
 * (`ConnectivityCounters`); the totals line ends "counters since restart HH:MM". A gateway without
 * the capability answers 204 and the columns are not drawn.
 *
 * <p>The map is `lib/connectivity-layout.ts` drawn by `ConnectivityCanvas`; the boxes' actions are
 * `ConnectivityBoxMenu`, through the same routes as the listener and vendor pages.
 */
export function ConnectivityClient() {
  const { health: liveHealth, error: healthError, slow: healthSlow, at: healthAt, reload, rateHistory } = useHealth();
  const servers = useWorkers(KIND.server);
  const vendors = useWorkers(KIND.vendor);
  const [paused, setPaused] = useState(false);
  const [frozen, setFrozen] = useState<Health | null>(null);
  const [filter, setFilter] = useState<FlowFilter>("all");
  const [byIp, setByIp] = useState(false);
  const [query, setQuery] = useState("");
  const [view, setView] = useState<MapView>(EMPTY_VIEW);
  const [focusId, setFocusId] = useState<string | null>(null);
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [pollError, setPollError] = useState("");
  //the sessions reads that found the gateway slow, and when they last all answered (0.15.1)
  const [sessionsSlow, setSessionsSlow] = useState(false);
  const [sessionsAt, setSessionsAt] = useState(0);
  const [routing, setRouting] = useState<{ tables: RoutingTableLike[]; groups: RoutingGroupLike[] }>({ tables: [], groups: [] });
  const [routingError, setRoutingError] = useState("");
  const [routingSlow, setRoutingSlow] = useState(false);
  const [routingTry, setRoutingTry] = useState(0);
  const canvas = useRef<CanvasHandle>(null);
  const histories = useRef(new Map<string, ListenerHistory>());
  const ticket = useRef(0);
  const [pendingReveal, setPendingReveal] = useState<string | null>(null);
  const [chosenWindow, setChosenWindow] = useState<CountsWindow>("hour");
  const [hour, setHour] = useState<HourState>({ available: null, data: null, at: 0, error: "", slow: false });

  //the remembered window, read after mount: localStorage does not exist while the page renders on the server
  useEffect(() => {
    //eslint-disable-next-line react-hooks/set-state-in-effect -- one read of this browser's choice
    setChosenWindow(readWindow());
  }, []);
  const chooseWindow = (next: CountsWindow) => {
    setChosenWindow(next);
    try {
      window.localStorage.setItem(COUNTS_KEY, next);
    } catch {
      //remembered for this visit only
    }
  };
  const countsWindow: CountsWindow = hour.available === false ? "bind" : chosenWindow;

  //paused, the map holds the health it had: the shared poll keeps running for the rest of the shell
  const health = paused ? frozen : liveHealth;
  const workerRates = useMemo(() => (paused ? {} : rateHistory.samples.at(-1)?.mt ?? {}), [rateHistory, paused]);

  //which vendors something routes to and which a group frames: read once health says where from --
  //the gateway's memory when it has routing_view, the config routes (the database) only when not
  const routingFrom = liveHealth ? (hasCapability(liveHealth, ROUTING_VIEW) ? "gateway" : "config") : null;
  useEffect(() => {
    if (!routingFrom) {
      return;
    }
    let live = true;
    const config = async () => {
      const read = async (url: string, key: string) => {
        const res = await fetch(url, { cache: "no-store" }).catch(() => null);
        noteSource(key, res);
        return res?.ok ? ((await res.json().catch(() => null))?.data ?? null) : null;
      };
      const [t, g] = await Promise.all([read("/api/control/routing", "connectivity-routing-tables"), read("/api/control/groups", "connectivity-routing-groups")]);
      return { tables: (t?.tables ?? []) as RoutingTableLike[], groups: (g?.groups ?? []) as RoutingGroupLike[] };
    };
    const gateway = async () => {
      const res = await fetch("/api/control/connectivity/routing", { cache: "no-store" }).catch(() => null);
      noteSource("connectivity-routing", res);
      //the gateway took routing_view away (a downgrade under the page): the config routes, as on an older one
      if (res?.status === 204) {
        return config();
      }
      const json = await res?.json().catch(() => null);
      if (res?.ok && json?.data) {
        const map = json.data as RoutingMap;
        return { tables: map.tables, groups: map.groups };
      }
      throw Object.assign(new Error(json?.error ?? (res ? `routing answered ${res.status}` : "the panel's API did not answer")), {
        slow: isSlowAnswer(res?.status, json),
      });
    };
    let retry: number | undefined;
    void (routingFrom === "gateway" ? gateway() : config()).then(
      (next) => {
        if (live) {
          setRouting(next);
          setRoutingError("");
          setRoutingSlow(false);
        }
      },
      (err: unknown) => {
        if (!live) {
          return;
        }
        //a slow gateway: no strip, and asked again shortly -- the routing is otherwise read once
        if ((err as { slow?: boolean }).slow) {
          setRoutingSlow(true);
          retry = window.setTimeout(() => setRoutingTry((n) => n + 1), ROUTING_RETRY_MS);
          return;
        }
        setRoutingSlow(false);
        setRoutingError(err instanceof Error ? err.message : String(err));
      }
    );
    return () => {
      live = false;
      window.clearTimeout(retry);
    };
  }, [routingFrom, routingTry]);

  //the node's queue, one sample per health answer, for its trend: folded while rendering, the way
  //React adjusts state to a prop, so the sample lands with the health it came from
  const [queues, setQueues] = useState<{ health: Health | null; history: QueueHistory }>({ health: null, history: EMPTY_QUEUE_HISTORY });
  if (liveHealth !== queues.health) {
    setQueues({ health: liveHealth, history: foldQueue(queues.history, liveHealth) });
  }

  const load = async () => {
    const mine = ++ticket.current;
    void reload();
    const listeners = servers.workers
      .filter((w) => w.enabled)
      .map((w) => ({ full: trafficKey(w), bound: liveHealth?.workers.find((h) => h.name === trafficKey(w))?.bound ?? 0 }));
    const [backlog, ...reads] = await Promise.all([
      readBacklog(),
      ...listeners.map((l) => (l.bound > 0 ? readSessions(l.full, l.bound) : Promise.resolve({ rows: [] as HealthSession[], error: null }))),
    ]);
    if (mine !== ticket.current) {
      return;
    }
    const now = Date.now();
    const rows = new Map<string, HealthSession[]>();
    const history = new Map<string, ListenerHistory>();
    const errors: string[] = [];
    let slow = false;
    listeners.forEach((l, i) => {
      const read = reads[i];
      if (read.error) {
        //a slow gateway is a note, not an error strip: the last rows stay, and the next poll asks again
        if (read.slow) {
          slow = true;
        } else {
          errors.push(`${l.full}: ${read.error}`);
        }
        //a failed read keeps the last rows rather than drawing the port empty
        rows.set(l.full, snap?.rows.get(l.full) ?? []);
        history.set(l.full, histories.current.get(l.full) ?? EMPTY_LISTENER_HISTORY);
        return;
      }
      const next = foldListener(histories.current.get(l.full) ?? EMPTY_LISTENER_HISTORY, read.rows, now);
      rows.set(l.full, read.rows);
      history.set(l.full, next);
    });
    histories.current = history;
    setPollError(errors.join(" · "));
    setSessionsSlow(slow);
    if (!slow && errors.length === 0) {
      setSessionsAt(now);
    }
    setSnap({ rows, history, backlog: backlog ?? snap?.backlog ?? [], at: now });
  };
  usePoll(load, POLL_MS, !paused && !servers.loading, servers.workers.length);

  //the last hour's counts and the last minute's refusals: asked whenever the gateway keeps the
  //series -- the refusals are drawn in either window -- and once to learn whether it does
  const loadCounts = async () => {
    const res = await fetch("/api/control/connectivity/counts", { cache: "no-store" }).catch(() => null);
    noteSource("connectivity-counts", res);
    const now = Date.now();
    if (res?.status === 204) {
      setHour({ available: false, data: null, at: now, error: "", slow: false });
      return;
    }
    const json = await res?.json().catch(() => null);
    if (res?.ok && json?.data) {
      setHour({ available: true, data: json.data as ConnectivityCounts, at: now, error: "", slow: false });
      return;
    }
    if (isSlowAnswer(res?.status, json)) {
      //a slow gateway: the last counts stay however old, with the note instead of the strip
      setHour((h) => ({ ...h, error: "", slow: true }));
      return;
    }
    const error = json?.error ?? (res ? `counts answered ${res.status}` : "the panel's API did not answer");
    setHour((h) => ({ ...h, data: h.data && now - h.at < COUNTS_STALE_MS ? h.data : null, error, slow: false }));
  };
  usePoll(loadCounts, COUNTS_POLL_MS, !paused && hour.available !== false);
  //the live counters under the map: their own 2 s timer, paused with the page
  const counters = useLiveCounters(paused);

  const clients = useMemo(() => {
    const out = new Map<string, ClientIn[]>();
    if (!snap) {
      return out;
    }
    for (const w of servers.workers) {
      const full = trafficKey(w);
      const rows = snap.rows.get(full);
      if (rows) {
        out.set(full, clientsOf(full, rows, snap.history.get(full) ?? EMPTY_LISTENER_HISTORY, byIp, throttledOn(health, w)));
      }
    }
    return out;
  }, [snap, servers.workers, byIp, health]);

  const routed = useMemo(() => routedVendors(routing.tables, routing.groups), [routing]);
  const kafka = showKafkaPage(health);
  const input = useMemo(() => buildMapInput({
    health,
    workerRates,
    servers: servers.workers,
    vendors: vendors.workers,
    clients,
    backlog: snap?.backlog ?? [],
    routed,
    groups: routing.groups,
    kafka,
    countsWindow,
    hour: hour.data,
    queues: queues.history,
  }), [health, workerRates, servers.workers, vendors.workers, clients, snap, routed, routing.groups, kafka, countsWindow, hour.data, queues.history]);

  const layout = useMemo(() => layoutMap(input, view), [input, view]);

  //a search or a keyboard move changed the view; scroll its box in once the new layout is drawn
  useEffect(() => {
    if (pendingReveal && layout.boxes.some((b) => b.id === pendingReveal)) {
      canvas.current?.reveal(pendingReveal);
      //eslint-disable-next-line react-hooks/set-state-in-effect -- one reveal per search
      setPendingReveal(null);
    }
  }, [layout, pendingReveal]);

  const groupKeys = useMemo(() => {
    const { shown, hidden } = visiblePorts(input.listeners, view.allPorts);
    return [...shown.map((l) => l.id), ...(hidden.length ? [OTHER_PORTS] : [])];
  }, [input.listeners, view.allPorts]);
  const allOpen = groupKeys.length > 0
    && groupKeys.every((k) => view.expanded.has(k))
    && !Object.values(view.openVendorGroups).includes(false);

  const pagesOf = useCallback((key: string) => {
    const { hidden } = visiblePorts(input.listeners, view.allPorts);
    const n = key === OTHER_PORTS
      ? input.clients.filter((c) => hidden.some((l) => l.id === c.listener)).length
      : input.clients.filter((c) => c.listener === key).length;
    return Math.max(1, Math.ceil(n / PAGE_SIZE));
  }, [input, view.allPorts]);

  const toggleGroup = useCallback((key: string) => setView((v) => {
    const expanded = new Set(v.expanded);
    if (expanded.has(key)) {
      expanded.delete(key);
    } else {
      expanded.add(key);
    }
    return { ...v, expanded };
  }), []);

  const onView = useCallback((box: MapBox, action: BoxAction) => {
    const key = box.listener ?? box.ref;
    if (action === "toggle") {
      if (box.kind === "portsMore") {
        setView((v) => ({ ...v, allPorts: !v.allPorts }));
      } else if (box.kind === "vendorGroup") {
        //open by default: the toggle flips this one group between its frame and one box
        setView((v) => ({ ...v, openVendorGroups: { ...v.openVendorGroups, [box.ref]: !vendorGroupOpen(v, box.ref) } }));
      } else {
        toggleGroup(key);
      }
      return;
    }
    if (action === "next-page") {
      setView((v) => ({ ...v, pages: { ...v.pages, [key]: ((v.pages[key] ?? 0) + 1) % pagesOf(key) } }));
      return;
    }
    const sort = action === "sort-binds" ? "binds" : action === "sort-name" ? "name" : "rate";
    setView((v) => ({
      ...v,
      expanded: new Set([...v.expanded, key]),
      sorts: { ...v.sorts, [key]: sort },
      pages: { ...v.pages, [key]: 0 },
    }));
  }, [toggleGroup, pagesOf]);

  const onActivate = useCallback((box: MapBox) => {
    onView(box, box.kind === "clientMore" ? "next-page" : "toggle");
  }, [onView]);

  const actions = useBoxActions({ servers, vendors, onView });

  const runSearch = useCallback((q: string) => {
    const hit = searchMap(input, view, q);
    if (hit) {
      setView(hit.view);
      setFocusId(hit.boxId);
      setPendingReveal(hit.boxId);
    }
  }, [input, view]);

  //typing searches after a pause; Enter searches at once
  const lastSearched = useRef("");
  useEffect(() => {
    const q = query.trim();
    if (q.length < 2 || q === lastSearched.current) {
      return;
    }
    const timer = window.setTimeout(() => {
      lastSearched.current = q;
      runSearch(q);
    }, 400);
    return () => window.clearTimeout(timer);
  }, [query, runSearch]);

  const togglePause = () => {
    setFrozen(paused ? null : liveHealth);
    setPaused((p) => !p);
  };

  const expandAll = () => {
    const closed = Object.fromEntries(input.vendors.flatMap((x) => (x.group ? [[x.group, false] as const] : [])));
    setView((v) => (allOpen
      ? { ...v, expanded: new Set(), openVendorGroups: closed }
      : { ...v, expanded: new Set(groupKeys), openVendorGroups: {} }));
  };

  const totals = totalsText(input, byIp);
  const since = counters.available && counters.data ? sinceText(counters.data) : "";
  const liveText = paused ? "paused, not polling" : `live, polling every ${POLL_MS / 1000} s`;
  const focused = focusId ? layout.boxes.find((b) => b.id === focusId) : undefined;
  const error = pollError || (healthSlow ? "" : healthError) || servers.error || vendors.error;
  //a slow gateway is a note with the time of the oldest figure still shown, never an error strip
  const slowAts = [
    healthSlow ? healthAt : 0,
    sessionsSlow ? sessionsAt : 0,
    hour.slow && countsWindow === "hour" ? hour.at : 0,
    counters.slow ? counters.at : 0,
  ].filter((t) => t > 0);
  const anySlow = !paused && (healthSlow || sessionsSlow || routingSlow || (hour.slow && countsWindow === "hour") || counters.slow);
  const slowText = anySlow ? (slowAts.length ? slowNote(Math.min(...slowAts)) : "gateway slow, waiting for its answer") : "";

  return (
    <div className="space-y-4">
      <PageHeader
        title="Connectivity"
        description="Who is connected, through which port and node, to which vendor — and how fast each link is moving right now."
      />

      {error && <HealthStrip tone="destructive">{error}</HealthStrip>}
      {slowText && !error && (
        <p role="status" className="text-xs text-muted-foreground" title="The gateway is answering slowly under load; the page keeps its last figures and asks again on each poll">
          {slowText}
        </p>
      )}
      {countsWindow === "hour" && hour.error && !error && (
        <HealthStrip tone="warning">Last hour&apos;s counts: {hour.error}</HealthStrip>
      )}
      {actions.notice && <HealthStrip tone="info">{actions.notice}</HealthStrip>}
      {actions.error && actions.error !== error && <HealthStrip tone="destructive">{actions.error}</HealthStrip>}
      {routingError && <HealthStrip tone="warning">Routing could not be read, so idle vendors show no edge and no group frames: {routingError}</HealthStrip>}

      <Card>
        {/* the header holds the controls; live and Pause are icons at its right edge, the totals line is the footer */}
        <CardHeader className="flex-row flex-wrap items-center gap-x-4 gap-y-2 space-y-0 border-b border-border">
          <span className="flex flex-wrap items-center gap-2">
            <span
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  lastSearched.current = query.trim();
                  runSearch(query);
                }
              }}
            >
              <SearchInput value={query} onChange={setQuery} placeholder="account, login, IP, vendor" ariaLabel="Find on the map" className="w-56" />
            </span>
            <Segmented label="Flows" options={FLOWS} value={filter} onChange={setFilter} />
            <span className="inline-flex items-center gap-1.5">
              <span className="text-xs text-muted-foreground" aria-hidden>Counts</span>
              <Segmented
                label="Counts"
                options={[
                  {
                    value: "hour",
                    label: "Last hour",
                    disabled: hour.available === false,
                    title: hour.available === false
                      ? "This gateway keeps no live series (live_series): counts are since each bind"
                      : countsWindow === "hour" && layout.countsNote
                        ? `MT and DLR ${layout.countsLabel}: ${layout.countsNote}`
                        : "MT and DLR over the last hour, from the gateway's memory",
                  },
                  { value: "bind", label: "Since bind", title: "MT and DLR since each session bound, from its counters" },
                ]}
                value={countsWindow}
                onChange={chooseWindow}
              />
            </span>
            <span className="inline-flex gap-0.5">
              <Button variant="outline" size="icon" aria-label="Zoom out" title="Zoom out" onClick={() => canvas.current?.zoomOut()}>
                <Minus className="h-4 w-4" aria-hidden />
              </Button>
              <Button variant="outline" size="icon" aria-label="Zoom in" title="Zoom in" onClick={() => canvas.current?.zoomIn()}>
                <Plus className="h-4 w-4" aria-hidden />
              </Button>
              <Button variant="outline" size="icon" aria-label="Fit the map" title="Fit" onClick={() => canvas.current?.fit()}>
                <Maximize className="h-4 w-4" aria-hidden />
              </Button>
            </span>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={expandAll} aria-pressed={allOpen}>
              <ChevronsUpDown className="h-3.5 w-3.5" aria-hidden />
              {allOpen ? "Collapse all" : "Expand all"}
            </Button>
            <Button variant="outline" size="sm" onClick={() => setByIp((v) => !v)} aria-pressed={byIp} className={byIp ? "border-foreground" : undefined}>
              By IP
            </Button>
          </span>
        </CardHeader>
        {!health && !paused ? (
          <div className="flex h-60 items-center justify-center text-sm text-muted-foreground">
            {healthError || "Reading the gateway…"}
          </div>
        ) : (
          <div className="relative">
            <ConnectivityCanvas
              handle={canvas}
              layout={layout}
              filter={filter}
              paused={paused}
              focusId={focusId}
              onFocus={setFocusId}
              onActivate={onActivate}
              framed={false}
              label={`Connectivity map: ${totals}`}
              renderBoxUi={(ui) => (
                <ConnectivityBoxMenu {...ui} onAction={actions.run} />
              )}
            />
            <Legend />
          </div>
        )}
        <ConnectivityCounters state={counters} />
        {/* the totals line, updated every poll; the canvas's accessible name carries the same text. Live
            and Pause sit at the footer's right edge (owner 2026-10-30) */}
        <div className="flex items-center gap-3 border-t border-border px-5 py-1.5 text-xs tabular-nums text-muted-foreground">
          <span>{since ? `${totals} · ${since}` : totals}</span>
          <span className="ml-auto inline-flex items-center gap-1.5">
              <span
                role="img"
                aria-label={liveText}
                title={liveText}
                className="relative inline-flex h-8 w-8 items-center justify-center"
              >
                {!paused && <span className="absolute h-2.5 w-2.5 rounded-full bg-success opacity-60 motion-safe:animate-ping" aria-hidden />}
                <span className={paused ? "relative h-2.5 w-2.5 rounded-full bg-muted-foreground/50" : "relative h-2.5 w-2.5 rounded-full bg-success"} aria-hidden />
              </span>
              <Button
                variant="outline"
                size="icon"
                onClick={togglePause}
                aria-pressed={paused}
                aria-label={paused ? "Resume polling" : "Pause polling"}
                title={paused ? "Resume polling" : "Pause polling"}
              >
                {paused ? <Play className="h-4 w-4" aria-hidden /> : <Pause className="h-4 w-4" aria-hidden />}
              </Button>
          </span>
        </div>
      </Card>

      {focused && (
        <p className="flex flex-wrap items-center gap-2 text-sm">
          <span className="text-muted-foreground">Focused:</span>
          <span className="font-medium">{focused.lines[0].replace(/^[▸▾] /, "")}</span>
          {focused.mt != null || focused.dlr != null ? (
            //the counts in full here: the box abbreviates past 99,999
            <span className="tabular-nums text-muted-foreground">
              {rateText(focused.rate)} · MT {fullCount(focused.mt)} · DLR {fullCount(focused.dlr)} · {layout.countsLabel}
            </span>
          ) : (
            <span className="tabular-nums text-muted-foreground">{focused.lines[1]}</span>
          )}
          <Button variant="ghost" size="sm" onClick={() => setFocusId(null)}>Clear</Button>
        </p>
      )}

      <p className="text-xs text-muted-foreground">
        Clients roll up into one box per port; a group opens to its top 10 by rate, then pages ten at a time.
        Line width is the rate; a dot is up to 400 messages a second, five at most. A box opens its actions on
        hover or Enter; every change confirms once and goes through the same audited calls as the listener and
        vendor pages. Read every five seconds; nothing is stored. MT is messages submitted (on a vendor, taken) and
        DLR the receipts: over the last hour from the gateway&apos;s in-memory series, or since each bind from the
        session counters. The node&apos;s queue is router + lag + retry; it turns orange when it has risen three
        polls running or is past its line. Routing and route groups come from the gateway&apos;s memory too (from
        the configuration only on a gateway older than 0.15.1), so nothing on this page reads the database. The
        Database box is the gateway&apos;s own view of PostgreSQL from its health snapshot: orange while it is
        degraded, red round orange while it refuses, with &ldquo;refusing N/s&rdquo; when most refusals are for it. A
        red dashed edge from a port back to its clients is what it refused over the last full minute, with the
        reasons.
      </p>
      {actions.dialogs}
    </div>
  );
}

function Legend() {
  const line = (colour: string, width: number, dash = false) => (
    <svg width="28" height="8" aria-hidden>
      <path d="M0,4 H22" style={{ stroke: `var(--color-${colour})` }} strokeWidth={width} strokeDasharray={dash ? "4 3" : undefined} />
      <path d="M22,0 L28,4 L22,8 Z" style={{ fill: `var(--color-${colour})` }} />
    </svg>
  );
  return (
    <div className="pointer-events-none absolute bottom-3 left-3 z-10 hidden rounded-md border border-border bg-card/95 px-3 py-2 text-xs md:block">
      <p className="mb-1 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">Legend</p>
      <p className="flex items-center gap-2">{line("info", 3)}Submits · width = rate</p>
      <p className="flex items-center gap-2">{line("success", 1.6)}Receipts</p>
      <p className="flex items-center gap-2">{line("destructive", 1.6, true)}Refused at the door (last minute) · down</p>
      <p className="flex items-center gap-2">{line("info", 2.4)}Writes to the database · width = rows/s</p>
    </div>
  );
}

async function readBacklog(): Promise<VendorBacklog[] | null> {
  const res = await fetch("/api/control/vendors/backlog", { cache: "no-store" }).catch(() => null);
  const body = (await res?.json().catch(() => null)) as VendorBacklogAnswer | null;
  if (!res?.ok || !body) {
    return null;
  }
  return body.data ? body.data.vendors : [];
}

/** Every session of one listener: pages of its bound count, capped at the gateway's 200. */
async function readSessions(worker: string, bound: number): Promise<{ rows: HealthSession[]; error: string | null; slow?: boolean }> {
  const limit = Math.min(PAGE, Math.max(1, bound));
  const rows: HealthSession[] = [];
  for (;;) {
    const res = await fetch(
      `/api/control/workers/${encodeURIComponent(worker)}/sessions?offset=${rows.length}&limit=${limit}`,
      { cache: "no-store" }
    ).catch(() => null);
    noteSource(`sessions:${worker}`, res);
    const json = await res?.json().catch(() => null);
    if (!res?.ok || !json?.data?.rows) {
      return {
        rows,
        error: json?.error ?? (res ? `sessions answered ${res.status}` : "the panel's API did not answer"),
        slow: isSlowAnswer(res?.status, json),
      };
    }
    rows.push(...(json.data.rows as HealthSession[]));
    if (rows.length >= (json.data.total ?? 0) || json.data.rows.length === 0) {
      return { rows, error: null };
    }
  }
}
