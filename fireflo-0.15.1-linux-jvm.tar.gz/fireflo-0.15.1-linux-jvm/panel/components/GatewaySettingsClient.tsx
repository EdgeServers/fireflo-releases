"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { SaveBar } from "@/components/SaveBar";
import { SettingsSection } from "@/components/SettingsSection";
import { PageHeader } from "@/components/ui/page-header";
import { Segmented } from "@/components/ui/segmented";
import { SearchInput } from "@/components/SearchInput";
import { GatewaySettingRow } from "@/components/GatewaySettingRow";
import { useHealth } from "@/components/useHealth";
import { HealthStrip } from "@/components/CardBits";
import { Select } from "@/components/ui/select";
import { GatewayKeyTable, type KeyField, type KeyRow } from "@/components/GatewayKeyTable";
import { GatewayDiagnostics } from "@/components/GatewayDiagnostics";
import { GatewayInForce } from "@/components/GatewayInForce";
import { NodeInformationSection } from "@/components/NodeInformation";

/** The one level, and the two keys it supplies defaults for. */
const DIAGNOSTICS_KEY = "smsg.diagnostics";
const MessageTraceKey = "message.trace.mode";
const EVENTS_KEY = "smsg.cdr.events";
import { Tabs } from "@/components/ui/tabs";
import { Rail, RailCard, RailNote, railItemClass } from "@/components/ui/rail";
import {
  GATEWAY_SECTIONS,
  GATEWAY_SETTING_FIELDS,
  gatewayFieldsIn,
  type GatewaySettingField,
} from "@/lib/gateway-setting-fields";
import { isChanged, matchesQuery, rowState, type RowState, type RunningValue } from "@/lib/gateway-setting-state";
import { judgeGatewayKey, workerDefaultKey, WRITABLE_PREFIXES } from "@/lib/gateway-key-policy";
import { BUILTIN_REGISTRY, registryFrom, statusOf, type ConfigKeyRegistry, type ConfigKeyRow } from "@/lib/config-key-registry";
import { settingLabel } from "@/lib/labels";
import { SETTING_FIELDS } from "@/lib/setting-fields";

/**
 * The two configuration tiers above a worker.
 *
 * <p><strong>Why this page exists at all.</strong> The gateway has three tiers and the panel could
 * only edit the narrowest, so an operator could set a value on one listener but had no way to say
 * "every listener" or "the REST ingress" without editing a properties file or writing SQL. That is
 * also why the two ingresses drifted: `smsg.restapi.*` and a listener's own keys each configure one
 * side, and nothing put them where somebody would notice they disagree.
 *
 * <p><strong>Sections by what an operator is doing</strong> -- approval and pricing, the REST
 * ingress, receipts and callbacks, call records, diagnostics, and the vendor and listener defaults --
 * each a list of compact rows. It used to be two columns by scope, REST beside gateway-wide, which
 * made the page a wall of dropdowns and put unrelated keys side by side.
 *
 * <p><strong>What runs is shown where it is edited.</strong> The page reads the same report as the
 * In force tab and marks a row whose saved value the gateway has not picked up, or whose value comes
 * from the host's environment and so outranks this page. A strip at the top counts them.
 *
 * <p><strong>One commit point.</strong> Every edit, the diagnostics level included, is staged and
 * written only by Save, from a bar pinned to the bottom of the window while anything is unsaved.
 */
type Values = Record<string, { value: string | null; enabled: boolean }>;

/** What the running gateway reported, keyed for the rows. */
interface Running {
  at: string;
  source: string;
  byKey: Map<string, RunningValue>;
}

export function GatewaySettingsClient() {
  const [values, setValues] = useState<Values>({});
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [, setSaving] = useState<string | null>(null);
  const [withheld, setWithheld] = useState(0);
  //app_config_key as the server read it (gateway V1.61.0), so a key typed here is judged by the same
  //list the server will use. The built-in copy until the first answer arrives
  const [registry, setRegistry] = useState<ConfigKeyRegistry>(BUILTIN_REGISTRY);
  const [addingDefault, setAddingDefault] = useState("");
  const [tab, setTab] = useState<"settings" | "inForce">("settings");
  const [query, setQuery] = useState("");
  const [show, setShow] = useState<"all" | "changed" | "pending">("all");
  //the running configuration, from the same report as the In force tab. Null until it answers, and
  //left null with a reason when it cannot -- rows then simply carry no "not yet running" mark
  const [running, setRunning] = useState<Running | null>(null);
  const [runningError, setRunningError] = useState<string | null>(null);
  const { health } = useHealth();
  /**
   * Edits made but not yet written.
   *
   * <p>Nothing on this tab reaches the gateway until Save. Every key here is one value for every
   * vendor, every listener and both ingresses at once, and the previous version committed each one
   * on blur -- a gateway-wide change with no moment where anybody agreed to it. A key mapped to the
   * empty string is a pending clear, which is why this is keyed presence rather than truthiness.
   */
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [savingAll, setSavingAll] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/control/gateway-settings", { cache: "no-store" });
      const body = await res.json();
      if (!res.ok) {
        setError(body?.error ?? "Could not read gateway configuration.");
        setValues({});
      } else {
        setError(null);
        setValues(body.data ?? {});
        setWithheld(typeof body.withheld === "number" ? body.withheld : 0);
        const reg = body.registry as { source?: ConfigKeyRegistry["source"]; rows?: ConfigKeyRow[] } | undefined;
        //the server sends every row but the hidden ones; the built-in copy supplies those
        setRegistry(reg?.rows?.length
          ? registryFrom([
            ...BUILTIN_REGISTRY.rows.filter((b) => !reg.rows!.some((r) => r.scope === b.scope && r.key === b.key)),
            ...reg.rows,
          ], reg.source ?? "database")
          : BUILTIN_REGISTRY);
      }
    } catch {
      setError("Could not reach the panel's own API.");
    } finally {
      setLoading(false);
    }
  }, []);

  const loadRunning = useCallback(async () => {
    try {
      const res = await fetch("/api/control/gateway-config-resolved", { cache: "no-store" });
      const body = await res.json();
      if (!res.ok || !body?.data) {
        setRunning(null);
        setRunningError(body?.error ?? "The gateway did not answer.");
        return;
      }
      const d = body.data as { resolved_at: string; config_sources?: Record<string, string>; global: { key: string; value: string | null; tier: string }[] };
      setRunning({
        at: d.resolved_at,
        source: d.config_sources?.properties ?? "unknown",
        byKey: new Map(d.global.map((e) => [e.key, { value: e.value, tier: e.tier }])),
      });
      setRunningError(null);
    } catch {
      setRunning(null);
      setRunningError("Could not reach the panel's own API.");
    }
  }, []);

  useEffect(() => {
    void load();
    void loadRunning();
  }, [load, loadRunning]);

  /** Stage an edit. Setting a field back to what is stored clears it rather than saving a no-op. */
  const draft = useCallback((key: string, value: string, stored: string) => {
    setDrafts((prev) => {
      const next = { ...prev };
      if (value === stored) {
        delete next[key];
      } else {
        next[key] = value;
      }
      return next;
    });
  }, []);

  const save = useCallback(async (key: string, value: string): Promise<boolean> => {
    setSaving(key);
    try {
      const res = await fetch("/api/control/gateway-settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key, value }),
      });
      const body = await res.json();
      if (!res.ok) {
        setError(body?.error ?? "Could not save.");
        return false;
      }
      setError(null);
      setValues((prev) => {
        const next = { ...prev };
        if (value.trim() === "") {
          delete next[key];
        } else {
          next[key] = { value, enabled: true };
        }
        return next;
      });
      //a picked-and-now-saved default is an ordinary persisted row from here on -- values already
      //excludes it from the picker's option list, so the pending-pick flag must step aside too, or a
      //later delete of this same row can never make the key pickable again (unsetWorkerKeys would
      //keep excluding it forever on the addingDefault check alone)
      setAddingDefault((prev) => (prev && workerDefaultKey(prev) === key ? "" : prev));
      return true;
    } catch {
      setError("Could not reach the panel's own API.");
      return false;
    } finally {
      setSaving(null);
    }
  }, []);

  /**
   * Write every pending edit, then clear the ones that landed.
   *
   * <p>Sequential rather than parallel, and it stops at the first refusal. These are configuration
   * writes with an audit line each; firing them concurrently would interleave the log and, worse,
   * would leave a half-applied set with no way to say which half.
   */
  const saveAll = useCallback(async () => {
    setSavingAll(true);
    try {
      for (const [key, value] of Object.entries(drafts)) {
        const ok = await save(key, value);
        if (!ok) {
          //the failed key keeps its draft, so the error names something still on screen
          return;
        }
        setDrafts((prev) => {
          const next = { ...prev };
          delete next[key];
          return next;
        });
      }
    } finally {
      setSavingAll(false);
      void loadRunning();
    }
  }, [drafts, save, loadRunning]);

  const smsgPrefix = WRITABLE_PREFIXES[0];
  const workerPrefix = WRITABLE_PREFIXES[1];

  /** The catalogue entry for a bare (unprefixed) worker key, in the shape GatewayKeyTable renders. */
  const workerFieldFor = useCallback((bareKey: string): KeyField | undefined => {
    if (!(bareKey in SETTING_FIELDS)) {
      return undefined;
    }
    const field = SETTING_FIELDS[bareKey as keyof typeof SETTING_FIELDS];
    const { label, hint } = settingLabel(bareKey);
    return { label, hint, widget: field.widget, codedDefault: field.codedDefault };
  }, []);

  /** Same lookup, taking the full `outSms.default.<key>` form GatewayKeyTable's rows carry. */
  const resolveWorkerField = useCallback(
    (key: string): KeyField | undefined =>
      key.startsWith(workerPrefix) ? workerFieldFor(key.slice(workerPrefix.length)) : undefined,
    [workerFieldFor, workerPrefix]
  );

  /**
   * The delete button on every row in the merged table calls this, not `draft` directly.
   *
   * <p>Deleting the row that reflects an in-progress, unsaved picker selection has to do one thing
   * `draft` alone cannot: clear `addingDefault`. Without that the blank row stays force-included by
   * `workerDefaults` regardless of what happens to `drafts`, since it was never a draft to begin with
   * -- picking a default and deleting it again before typing anything stages nothing.
   */
  const removeWorkerKey = useCallback(
    (key: string, stored: string) => {
      if (key.startsWith(workerPrefix) && key.slice(workerPrefix.length) === addingDefault) {
        setAddingDefault("");
      }
      draft(key, "", stored);
    },
    [workerPrefix, addingDefault, draft]
  );

  /**
   * Every `outSms.default.*` key that is actually set, plus any the operator has just opened for
   * editing. Catalogued or not — a worker default with no field of its own is still something an
   * operator set and needs to see, which is why it lives here and not in Any other key.
   *
   * <p>Not every possible worker key: there are eighty-odd, and a wall of eighty empty fields would
   * bury the handful that matter. A default only exists once somebody sets one, so the list of set
   * ones *is* the interesting list, and the picker beneath adds to it.
   */
  const workerDefaults: KeyRow[] = useMemo(() => {
    const keys = Object.keys(values)
      .filter((k) => k.startsWith(workerPrefix))
      .map((k) => k.slice(workerPrefix.length));
    if (addingDefault && !keys.includes(addingDefault)) {
      keys.push(addingDefault);
    }
    return keys
      .sort((a, b) => settingLabel(a).label.localeCompare(settingLabel(b).label))
      .map((k) => {
        const full = workerDefaultKey(k);
        const current = values[full];
        const status = statusOf(registry, "worker", k);
        return {
          key: full,
          value: current?.value ?? null,
          enabled: current?.enabled ?? true,
          //shown and locked when another screen owns the key -- the same treatment the broker and
          //sink wiring gets below, and for the same reason: an operator needs to see that a default
          //is set far more often than they need to change it from here. Locked too when the registry
          //says the key is retired: the gateway no longer reads it (V1.88.0)
          writable: SETTING_FIELDS[k as keyof typeof SETTING_FIELDS]?.elsewhere === undefined && status.editable,
          field: workerFieldFor(k),
          status,
        };
      });
  }, [values, addingDefault, workerPrefix, workerFieldFor, registry]);

  /**
   * Uncurated `smsg.*` keys that no card above renders. `outSms.default.*` never reaches this list —
   * that whole prefix belongs to Worker defaults above, curated or not, stated explicitly here rather
   * than left as something that happens to be true of two other computations.
   */
  const extras: KeyRow[] = useMemo(() => {
    const shown = new Set([...GATEWAY_SETTING_FIELDS.map((f) => f.key), DIAGNOSTICS_KEY]);
    return Object.entries(values)
      .filter(([key]) => {
        if (!key.startsWith(smsgPrefix) || shown.has(key)) {
          return false;
        }
        const verdict = judgeGatewayKey(key, registry);
        //a curated key belongs in a card above, not here. A key that is readable but not writable --
        //the broker and sink wiring -- does belong here, shown and locked: seeing that smsg.cdr.sink
        //is set to something unexpected is exactly what an operator opens this page to find out
        return verdict.allowed ? !verdict.curated : true;
      })
      .map(([key, v]) => ({
        key,
        value: v.value,
        enabled: v.enabled,
        writable: judgeGatewayKey(key, registry).allowed,
        status: statusOf(registry, "platform", key),
      }))
      .sort((a, b) => a.key.localeCompare(b.key));
  }, [values, smsgPrefix, registry]);

  /**
   * Catalogued worker-default settings the picker may still offer.
   *
   * <p>Excludes more than just what is persisted: `addingDefault` is a pick already showing as a
   * blank row, and a curated key can now also reach `drafts` directly through the free-text Add box
   * (which used to refuse it) -- either way it is already spoken for and must not also appear as a
   * choice, or picking it twice would fight over the same row.
   */
  const unsetWorkerKeys = Object.keys(SETTING_FIELDS)
    .filter((k) => {
      const full = workerDefaultKey(k);
      //and never a key another screen owns: the picker's job is to open a blank editor, which is
      //exactly what that screen exists to be
      if (SETTING_FIELDS[k as keyof typeof SETTING_FIELDS].elsewhere !== undefined) {
        return false;
      }
      //nor a key the gateway has retired: offering it would be offering a setting that does nothing
      if (!statusOf(registry, "worker", k).editable) {
        return false;
      }
      return !(full in values) && k !== addingDefault && !(full in drafts);
    })
    .sort((a, b) => settingLabel(a).label.localeCompare(settingLabel(b).label));

  const dirty = Object.keys(drafts).length;

  //a number box holding something that is not a whole number cannot be saved; said on its row,
  //and Save stays off until it is fixed, rather than refused by the database mid-batch
  const invalid: Record<string, string> = {};
  for (const f of GATEWAY_SETTING_FIELDS) {
    const d = drafts[f.key];
    if (f.widget.kind === "number" && d !== undefined && d.trim() !== "" && !/^\d+$/.test(d.trim())) {
      invalid[f.key] = "A whole number, 0 or more.";
    }
  }
  const blocked = Object.keys(invalid).length > 0;

  //each catalogued row's state, once, for the rows, the filter, the counts and the strip
  const states = useMemo(() => {
    const out = new Map<string, RowState>();
    for (const f of GATEWAY_SETTING_FIELDS) {
      out.set(f.key, rowState({
        stored: values[f.key],
        draft: drafts[f.key],
        codedDefault: f.codedDefault,
        running: running?.byKey.get(f.key),
        startup: f.startup,
      }));
    }
    return out;
  }, [values, drafts, running]);

  const diagLevel = drafts[DIAGNOSTICS_KEY] ?? values[DIAGNOSTICS_KEY]?.value ?? "";
  const diagChanged = (values[DIAGNOSTICS_KEY]?.value ?? "") !== "" || DIAGNOSTICS_KEY in drafts;

  const changedCount = GATEWAY_SETTING_FIELDS.filter((f) => isChanged(states.get(f.key)!)).length + (diagChanged ? 1 : 0);
  const pendingKeys = GATEWAY_SETTING_FIELDS.filter((f) => states.get(f.key)!.kind === "pending");
  const visible = (f: GatewaySettingField) => {
    const st = states.get(f.key)!;
    if (show === "changed" && !isChanged(st)) return false;
    if (show === "pending" && st.kind !== "pending") return false;
    return matchesQuery(query, f);
  };
  const filtering = query.trim() !== "" || show !== "all";
  const diagVisible = show !== "pending"
    && (show !== "changed" || diagChanged)
    && matchesQuery(query, { key: DIAGNOSTICS_KEY, label: "Diagnostics level", hint: "trace events message.trace.mode smsg.cdr.events" });
  const defaultsVisible = !filtering || (show === "all" && matchesQuery(query, { key: "outSms.default", label: "Vendor and listener defaults" }));

  const sections = GATEWAY_SECTIONS.map((sec) => {
    const fields = gatewayFieldsIn(sec.id);
    return {
      ...sec,
      fields: fields.filter(visible),
      changed: fields.filter((f) => isChanged(states.get(f.key)!)).length,
    };
  });
  const nothingMatches = sections.every((sec) => sec.fields.length === 0) && !diagVisible && !defaultsVisible;

  const jump = [
    ...sections.map((sec) => ({ id: sec.id, title: sec.title, changed: sec.changed })),
    { id: "diagnostics", title: "Diagnostics", changed: diagChanged ? 1 : 0 },
    { id: "defaults", title: "Vendor and listener defaults", changed: workerDefaults.length + extras.length },
  ];

  return (
    <>
      <PageHeader
        title="Gateway"
        description="Settings that apply to every vendor, every listener and both ingresses. A vendor or listener with a value of its own keeps it."
      />

      {/* the cluster's nodes (0.15.1, the old Nodes page), closed to one line unless something is wrong */}
      <NodeInformationSection />

      <StatusStrip
        version={health?.version ?? null}
        running={running}
        runningError={runningError}
        pending={pendingKeys.length}
        onShowPending={() => {
          setTab("settings");
          setShow("pending");
        }}
      />

      {/* two tabs because there are two questions. Settings is what we have written, with the
          running value folded in where they differ; In force is the whole running configuration,
          read-only on purpose */}
      <Tabs
        label="Gateway configuration"
        active={tab}
        onSelect={setTab}
        items={[
          { id: "settings" as const, label: "Settings" },
          { id: "inForce" as const, label: "In force" },
        ]}
      />

      {tab === "inForce" ? (
        <GatewayInForce />
      ) : (
      <>
      <div className="flex flex-wrap items-center gap-2.5">
        <div className="min-w-0 flex-[1_1_280px]">
          <SearchInput
            value={query}
            onChange={setQuery}
            placeholder="Find a setting by name or key"
            ariaLabel="Find a setting"
            className="w-full"
          />
        </div>
        <Segmented
          label="Show"
          value={show}
          onChange={setShow}
          options={[
            { value: "all", label: `All` },
            { value: "changed", label: `Changed ${changedCount}` },
            { value: "pending", label: `Not yet running ${pendingKeys.length}` },
          ]}
        />
      </div>

      {error && <HealthStrip tone="destructive">{error}</HealthStrip>}

      <div className="flex flex-wrap items-start gap-6">
        {/* the jump list. A select on a phone, where a column of links would push the page down */}
        <Rail label="Sections">
          <RailCard title="Gateway-wide" what="every vendor and listener">
            {jump.filter((j) => j.id !== "defaults").map((j) => <JumpLink key={j.id} {...j} />)}
          </RailCard>
          <RailCard title="Defaults" what="until one sets its own">
            {jump.filter((j) => j.id === "defaults").map((j) => <JumpLink key={j.id} {...j} />)}
            <RailNote>Green numbers count settings changed from the gateway&apos;s default.</RailNote>
          </RailCard>
        </Rail>

        <div className="flex min-w-0 flex-[999_1_560px] flex-col gap-5">
          <label className="flex flex-col gap-1 text-xs text-muted-foreground lg:hidden">
            Jump to
            <Select
              aria-label="Jump to section"
              value=""
              onChange={(e) => {
                if (e.target.value) {
                  document.getElementById(`gw-${e.target.value}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
                }
              }}
            >
              <option value="">Choose a section…</option>
              {jump.map((j) => (
                <option key={j.id} value={j.id}>{j.title}</option>
              ))}
            </Select>
          </label>

          {nothingMatches && (
            <p className="rounded-lg border border-dashed border-border px-4 py-6 text-center text-sm text-muted-foreground">
              {show === "pending"
                ? "Nothing is waiting: the gateway is running every saved setting."
                : show === "changed"
                  ? "Nothing here is changed from the gateway's default."
                  : "No setting matches that."}
            </p>
          )}

          {sections.map((sec) => sec.fields.length > 0 && (
            <SettingsSection key={sec.id} id={sec.id} title={sec.title} description={sec.description}>
              {sec.fields.map((f) => (
                <GatewaySettingRow
                  key={f.key}
                  field={f}
                  stored={values[f.key]}
                  draft={drafts[f.key]}
                  running={running?.byKey.get(f.key)}
                  busy={savingAll || loading}
                  invalid={invalid[f.key]}
                  status={statusOf(registry, "platform", f.key)}
                  onDraft={draft}
                />
              ))}
            </SettingsSection>
          ))}

          {diagVisible && (
            <SettingsSection
              id="diagnostics"
              title="Diagnostics"
              description="How much the gateway records about individual messages."
            >
              <div className="px-5 py-4">
                <GatewayDiagnostics
                  level={diagLevel}
                  unsaved={DIAGNOSTICS_KEY in drafts}
                  //the two keys the level fronts, when either is set on its own. Reported rather than
                  //hidden: a level that reads as in force while a key outranks it is the one failure
                  //this design introduces
                  overrides={[MessageTraceKey, EVENTS_KEY]
                    .filter((k) => (values[k]?.value ?? "").trim() !== "")
                    .map((k) => ({ key: k, value: values[k]?.value ?? "" }))}
                  busy={savingAll || loading}
                  onChange={(next) => draft(DIAGNOSTICS_KEY, next, values[DIAGNOSTICS_KEY]?.value ?? "")}
                />
              </div>
            </SettingsSection>
          )}

          {defaultsVisible && (
            //full width, as before: a table of rows reads better edge to edge. Worker defaults and any
            //other key share it because they answer the same question -- what has been set beyond the
            //curated fields above
            <div id="gw-defaults" className="scroll-mt-4">
              <GatewayKeyTable
                registry={registry}
                title="Vendor and listener defaults"
                description="Inherited by every vendor and listener that sets nothing of its own. Other gateway keys with no field above are listed here too; the panel does not check their values, the gateway does."
                emptyLabel="Nothing set beyond the fields above."
                rows={[...workerDefaults, ...extras]}
                drafts={drafts}
                busy={savingAll || loading}
                onDraft={draft}
                onRemove={removeWorkerKey}
                ownCuratedPrefix={workerPrefix}
                resolveField={resolveWorkerField}
                picker={
                  <Select
                    aria-label="Setting to default"
                    value={addingDefault}
                    onChange={(e) => setAddingDefault(e.target.value)}
                  >
                    <option value="">Choose a setting…</option>
                    {unsetWorkerKeys.map((k) => (
                      <option key={k} value={k}>
                        {settingLabel(k).label}
                      </option>
                    ))}
                  </Select>
                }
              />
              {withheld > 0 && (
                //said rather than silently omitted. The count only -- naming them would undo the withholding
                <p className="mt-2 text-sm text-muted-foreground">
                  {withheld} {withheld === 1 ? "key holds" : "keys hold"} a credential and{" "}
                  {withheld === 1 ? "is" : "are"} not shown. Change {withheld === 1 ? "it" : "them"} on the host.
                </p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* the page's one commit point. Every key here is one value for every vendor, listener and
          both ingresses at once, so nothing reaches the gateway until somebody presses Save */}
      <SaveBar
        count={dirty}
        saving={savingAll}
        blocked={blocked}
        message="Nothing has reached the gateway yet. It picks changes up at its next poll."
        //a picked-but-untyped default has no draft to discard -- it only ever lived in
        //addingDefault -- so Discard has to clear both or the blank row survives its own undo
        onDiscard={() => {
          setDrafts({});
          setAddingDefault("");
        }}
        onSave={() => void saveAll()}
      />
      </>
      )}
    </>
  );
}

/**
 * What is running, in one strip: the In force tab's headline, brought to where edits happen.
 *
 * <p>Reads the same report as In force. When the gateway cannot be asked -- a licence that is not
 * current switches the report off -- it says so in one line rather than showing blanks that read as
 * "nothing is running".
 */
function StatusStrip({
  version,
  running,
  runningError,
  pending,
  onShowPending,
}: {
  version: string | null;
  running: Running | null;
  runningError: string | null;
  pending: number;
  onShowPending: () => void;
}) {
  if (!running) {
    return (
      <p className="rounded-lg border border-border bg-card px-4 py-2.5 text-sm text-muted-foreground">
        {version ? `${version}. ` : ""}
        {runningError
          ? "The gateway's running settings could not be read, so this page cannot say which saved settings it has picked up."
          : "Asking the gateway what it is running…"}
      </p>
    );
  }
  const cell = "bg-card px-4 py-3";
  return (
    <section
      aria-label="Gateway status"
      className="grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-border bg-border md:grid-cols-4"
    >
      <div className={cell}>
        <div className="text-xs text-muted-foreground">Running</div>
        <div className="font-semibold">{version ?? "Unknown version"}</div>
      </div>
      <div className={cell}>
        <div className="text-xs text-muted-foreground">Settings read from</div>
        <div className="font-semibold capitalize">{running.source}</div>
      </div>
      <div className={cell}>
        <div className="text-xs text-muted-foreground">Checked</div>
        <div className="font-semibold tabular-nums">{new Date(running.at).toLocaleTimeString()}</div>
      </div>
      {pending > 0 ? (
        <div className="bg-warning-soft px-4 py-3">
          <div className="text-xs text-warning">Saved, not yet running</div>
          <div className="font-semibold">
            {pending} {pending === 1 ? "setting" : "settings"} ·{" "}
            <button type="button" className="underline underline-offset-2" onClick={onShowPending}>show</button>
          </div>
        </div>
      ) : (
        <div className={cell}>
          <div className="text-xs text-muted-foreground">Saved, not yet running</div>
          <div className="font-semibold">None</div>
        </div>
      )}
    </section>
  );
}

/** One section in the jump list, with how many of its settings are changed from the default. */
function JumpLink({ id, title, changed }: { id: string; title: string; changed: number }) {
  return (
    <a href={`#gw-${id}`} className={railItemClass(false)}>
      {title}
      {changed > 0 && <span className="ml-auto pl-2 font-medium tabular-nums text-primary">{changed}</span>}
    </a>
  );
}
