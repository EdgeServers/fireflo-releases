"use client";
import { useEffect, useState } from "react";
import type { VendorBacklog, VendorBacklogAnswer } from "@/lib/vendor-backlog";

/** How often the pages re-read the backlog: the route keeps a reading ten seconds. */
const POLL_MS = 15_000;

/**
 * The gateway's vendor backlogs (0.15.1), read on mount and every {@link POLL_MS} while the tab is
 * visible. `unsupported` on a gateway before 0.15.1: the pages show nothing for it.
 */
export function useVendorBacklog(): {
  vendors: VendorBacklog[];
  graceSeconds: number;
  unsupported: boolean;
  error: string;
} {
  const [state, setState] = useState({ vendors: [] as VendorBacklog[], graceSeconds: 600, unsupported: false, error: "" });
  useEffect(() => {
    let stopped = false;
    async function read() {
      if (document.visibilityState === "hidden") {
        return;
      }
      try {
        const res = await fetch("/api/control/vendors/backlog", { cache: "no-store" });
        const body = (await res.json().catch(() => null)) as (VendorBacklogAnswer & { error?: string }) | null;
        if (stopped) {
          return;
        }
        if (!res.ok || !body) {
          setState((s) => ({ ...s, error: body?.error ?? `Request failed (${res.status})` }));
        } else if (body.data === null) {
          setState({ vendors: [], graceSeconds: 600, unsupported: true, error: "" });
        } else {
          setState({ vendors: body.data.vendors, graceSeconds: body.data.unboundGraceSeconds, unsupported: false, error: "" });
        }
      } catch {
        if (!stopped) {
          setState((s) => ({ ...s, error: "Could not reach the panel's API." }));
        }
      }
    }
    void read();
    const timer = setInterval(() => void read(), POLL_MS);
    return () => {
      stopped = true;
      clearInterval(timer);
    };
  }, []);
  return state;
}
