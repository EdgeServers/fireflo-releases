"use client";
import { Badge } from "@/components/ui/badge";
import { formatTps } from "@/lib/tps-format";
import { SOURCE_WORDS, type SessionCeiling } from "@/lib/session-groups";
import type { LimitSource } from "@/lib/health-types";
import { sourceChip, sourceChipText, type RateCeiling } from "@/lib/throughput";

const PILL_VARIANT: Record<LimitSource, "default" | "info" | "outline"> = {
  ACCOUNT_OVERRIDE: "default",
  LOGIN_MAX_TPS: "info",
  LISTENER_DEFAULT: "outline",
  UNLIMITED: "outline",
};

const PILL_TITLE: Record<LimitSource, string> = {
  ACCOUNT_OVERRIDE: "The account’s own conf.maxRate.<account> on this listener",
  LOGIN_MAX_TPS: "The login’s own TPS, lower than the account’s ceiling",
  LISTENER_DEFAULT: "The listener’s conf.maxRate.default (or the gateway-wide default)",
  UNLIMITED: "No ceiling",
};

/**
 * Which setting a ceiling came from, in one word (gateway 0.15.1+): override, login, default.
 * Shared by the listener Status tab and the session list, so "≤250 · override" reads the same on both.
 */
export function SourcePill({ source }: { source: LimitSource }) {
  const word = SOURCE_WORDS[source];
  return word ? <Badge variant={PILL_VARIANT[source]} title={PILL_TITLE[source]}>{word}</Badge> : null;
}

/** `≤250` and its pill; the pill is not drawn when the gateway is too old to say (no source). */
export function CeilingWithSource({ ceiling }: { ceiling: SessionCeiling }) {
  return (
    <span className="inline-flex items-center gap-1.5 whitespace-nowrap">
      <span className="font-mono text-xs tabular-nums">≤{formatTps(ceiling.value)}</span>
      {ceiling.source && <SourcePill source={ceiling.source} />}
    </span>
  );
}

/**
 * Which setting produced a ceiling, in full: the words, the key in mono, and the tier when it says
 * more than the words -- "all listeners `outSms.default.conf.maxRate.default` gateway-wide". The
 * Account › Limits tab's chip (`limitSrc` in the mockups).
 */
export function LimitSourceChip({
  ceiling,
  surface = "smpp",
}: {
  ceiling: Pick<RateCeiling, "source" | "key" | "tier">;
  surface?: "smpp" | "http";
}) {
  const chip = sourceChip(ceiling, surface);
  return (
    <span className="inline-flex flex-wrap items-center gap-x-1.5 gap-y-0.5" title={sourceChipText(ceiling, surface)}>
      <Badge variant={chip.variant}>{chip.label}</Badge>
      {chip.key && <span className="font-mono text-xs text-muted-foreground">{chip.key}</span>}
      {chip.note && <span className="text-2xs text-muted-foreground">{chip.note}</span>}
    </span>
  );
}
