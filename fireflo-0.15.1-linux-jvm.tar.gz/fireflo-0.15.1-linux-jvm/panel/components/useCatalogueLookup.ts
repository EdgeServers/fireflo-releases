"use client";
import { useEffect, useState } from "react";
import { LOOKUP_DEBOUNCE_MS, LOOKUP_MIN_CHARS } from "@/lib/usage-grid";
import { noteSource } from "@/lib/page-sources";

/**
 * Suggestions for one field: asked of the catalogue a quarter of a second after typing stops, with
 * at least two characters (products: the whole short list, once).
 *
 * <p>The Usage page's quick filters were the first reader; the listener's per-account overrides
 * editor is the second, which is why it lives on its own. The catalogue, never call records: an
 * account that has sent nothing yet is exactly the one an operator is setting a ceiling for.
 */
export function useCatalogueLookup(kind: "account" | "login" | "product", typed: string, account: string | null): string[] {
  const [values, setValues] = useState<string[]>([]);
  useEffect(() => {
    if (kind !== "product" && typed.trim().length < LOOKUP_MIN_CHARS) {
      return;
    }
    const controller = new AbortController();
    const timer = setTimeout(() => {
      const q = new URLSearchParams({ kind, q: typed.trim(), ...(account ? { account } : {}) });
      fetch(`/api/control/usage/lookup?${q}`, { signal: controller.signal })
        .then((r) => {
          noteSource(`lookup:${kind}`, r);
          return r.json();
        })
        .then((j: { data?: string[] }) => setValues(Array.isArray(j.data) ? j.data : []))
        .catch(() => undefined);
    }, kind === "product" ? 0 : LOOKUP_DEBOUNCE_MS);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [kind, typed, account]);
  return values;
}
