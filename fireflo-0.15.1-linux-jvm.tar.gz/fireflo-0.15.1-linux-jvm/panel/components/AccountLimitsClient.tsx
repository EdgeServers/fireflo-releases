"use client";
import { Fragment, useState } from "react";
import Link from "next/link";
import { Pause, Play } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { EmptyState } from "@/components/ui/empty-state";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { SettingsRow } from "@/components/ui/settings-row";
import { StatTile } from "@/components/ui/stat-tile";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { HealthStrip } from "./CardBits";
import { RateBar } from "./RateBar";
import { LimitSourceChip } from "./SourcePill";
import { usePoll } from "./usePoll";
import { useWorkerPropertyWrite } from "./useWorkerPropertyWrite";
import { useWorkers } from "./useWorkers";
import { count } from "@/lib/format";
import { formatTps } from "@/lib/tps-format";
import { cn } from "@/lib/utils";
import { KIND } from "@/lib/worker-types";
import {
  ceilingText, historySeries, listenerName, shareText,
  type AccountThroughput, type IgnoredSetting, type ListenerThroughput, type ThrottleCounts, type ThroughputAnswer,
} from "@/lib/throughput";

/** How often the figures are read: the listener Status tab's pace. */
const POLL_MS = 5_000;
/** Live TPS kept for the tile's sparkline: two minutes of five-second readings. */
const RING = 24;

type Setting = "rate" | "binds";

/**
 * Account › Limits: why this account gets the rate it gets (`S['account-limits']` in the mockups).
 *
 * <p>Per SMPP listener, the ceiling this node enforces and the setting that produced it -- the
 * account's own `conf.maxRate.<id>`, the listener's `conf.maxRate.default`, or the gateway-wide
 * `outSms.default.*` row -- with `configured × share = effective` for a cluster, live TPS against it,
 * binds against the bind limit, and how much was answered 0x58. Under each listener its logins, and
 * which limit binds them. Then HTTP, which has its own ceiling.
 *
 * <p>Everything comes from the gateway's `accountThroughput` (0.15.1): its own reading of its
 * configuration, through the code that enforces it, so this page cannot disagree with what the
 * customer meets. An older gateway has no such field, and the tab says so rather than guessing from
 * stored settings. Writes go through the worker-property PATCH, one key at a time, confirmed.
 */
export function AccountLimitsClient({ id }: { id: string }) {
  const [answer, setAnswer] = useState<ThroughputAnswer | null>(null);
  const [error, setError] = useState<string | null>(null);
  //when the answer was read: the right edge of the throttle history
  const [readAt, setReadAt] = useState(0);
  const [frozen, setFrozen] = useState(false);
  //live TPS, summed over the listeners, for the tile's line; kept per account so a tab switch to
  //another account starts afresh
  const [ring, setRing] = useState<{ account: string; values: number[] }>({ account: id, values: [] });
  const servers = useWorkers(KIND.server);
  const writer = useWorkerPropertyWrite();

  const load = async () => {
    const res = await fetch(`/api/control/accounts/${encodeURIComponent(id)}/throughput`, { cache: "no-store" }).catch(() => null);
    const json = (await res?.json().catch(() => null)) as (ThroughputAnswer & { error?: string }) | null;
    if (!res?.ok || !json) {
      setError(json?.error ?? (res ? `Could not read the limits (${res.status}).` : "Could not reach the panel's API."));
      return;
    }
    if (json.data) {
      const live = json.data.listeners.reduce((sum, l) => sum + (l.tpsMeasured ?? 0), 0);
      setRing((r) => ({ account: id, values: [...(r.account === id ? r.values : []), live].slice(-RING) }));
    }
    setError(null);
    setReadAt(Date.now());
    setAnswer(json);
  };
  usePoll(load, POLL_MS, !frozen, id);

  const data = answer?.data ?? null;
  const stored = (listener: string, key: string) =>
    servers.workers.find((w) => w.name === listener)?.properties.find((p) => p.key === key)?.value ?? "";

  if (answer?.unsupported) {
    return (
      <EmptyState>
        <span className="block max-w-xl text-left">
          This gateway does not explain its limits: the Limits tab needs gateway 0.15.1 or later (capability{" "}
          <code className="font-mono text-xs">account_throughput</code>). The ceilings still apply — an account’s{" "}
          <code className="font-mono text-xs">conf.maxRate.{id}</code> on a listener, else that listener’s{" "}
          <code className="font-mono text-xs">conf.maxRate.default</code>, narrowed by a login’s own TPS — and each
          listener’s settings show what is stored.
        </span>
      </EmptyState>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <p className="min-w-0 flex-1 text-xs text-muted-foreground">
          {data
            ? `Node ${data.node || "—"}${data.nodes > 1 ? `, one of ${data.nodes}: the ceilings below are this node’s share of the account’s` : ""}. Read every 5 seconds${data.windowSeconds ? `; TPS is averaged over ${data.windowSeconds} s` : ""}.`
            : error ?? "Reading the gateway…"}
        </p>
        <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setFrozen((f) => !f)} aria-pressed={frozen}>
          {frozen ? <Play className="h-3.5 w-3.5" aria-hidden /> : <Pause className="h-3.5 w-3.5" aria-hidden />}
          {frozen ? "Resume" : "Pause"}
        </Button>
      </div>
      {error && data && <HealthStrip tone="destructive">{error}</HealthStrip>}

      {data && <Tiles data={data} readAt={readAt} liveRing={ring.account === id ? ring.values : []} />}
      {data && <IgnoredStrips data={data} />}

      <Card>
        <CardHeader>
          <CardTitle>SMPP, per listener</CardTitle>
          <CardDescription>
            The effective ceiling is what the account may send on that listener from this node: the configured value
            times this node’s share of the account’s binds. All of the account’s logins share it; a login’s own limit
            can only narrow it.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <TableInCard>
            <THead>
              <TR>
                <TH>Listener</TH>
                <TH>Ceiling</TH>
                <TH>Source</TH>
                <TH>Configured × share</TH>
                <TH>Live TPS</TH>
                <TH align="right">Binds</TH>
                <TH align="right">
                  Throttled <span className="font-normal normal-case">1m · 5m · 1h · start</span>
                </TH>
              </TR>
            </THead>
            <TBody>
              {!data && (
                <TR>
                  <TD colSpan={7} muted>{error ?? "Reading the gateway…"}</TD>
                </TR>
              )}
              {data && !data.listeners.length && (
                <TR>
                  <TD colSpan={7} muted>No SMPP listener is enabled.</TD>
                </TR>
              )}
              {data?.listeners.map((l) => (
                <ListenerRows key={l.listener} account={id} l={l} nodes={data.nodes} />
              ))}
            </TBody>
          </TableInCard>
        </CardContent>
      </Card>

      {data && !!data.listeners.length && (
        <CeilingEditor
          account={id}
          listeners={data.listeners}
          stored={stored}
          busy={writer.busy}
          onSet={async (listener, setting, value) => {
            const key = `${setting === "rate" ? "conf.maxRate" : "conf.maxConnectionsPerUser"}.${id}`;
            const ok = await writer.write({
              worker: listener,
              key,
              value,
              current: stored(listener, key),
              title: setting === "rate" ? `Rate ceiling for ${id} on ${listener}` : `Binds for ${id} on ${listener}`,
              unit: setting === "rate" ? "msg/s" : "binds",
              fallback: "the listener default",
            });
            if (ok) {
              await servers.load();
            }
            return ok;
          }}
        />
      )}
      {writer.notice && <HealthStrip tone="info">{writer.notice}</HealthStrip>}
      {writer.error && <HealthStrip tone="destructive">{writer.error}</HealthStrip>}

      {data && (
        <Card>
          <CardHeader>
            <CardTitle>HTTP</CardTitle>
            <CardDescription>REST submissions have their own limit, answered with 429.</CardDescription>
          </CardHeader>
          <CardContent>
            <TableInCard>
              <THead>
                <TR>
                  <TH>Surface</TH>
                  <TH>Ceiling</TH>
                  <TH>Source</TH>
                  <TH align="right">Rate-limited, last hour</TH>
                </TR>
              </THead>
              <TBody>
                <TR>
                  <TD primary>REST API</TD>
                  <TD className="font-mono text-xs tabular-nums">{ceilingText(data.http.ceiling) ?? "none"}</TD>
                  <TD><LimitSourceChip ceiling={data.http.ceiling} surface="http" /></TD>
                  <TD num className={cn((data.http.rateLimitedLastHour ?? 0) > 0 && "text-warning")}>
                    {data.http.rateLimitedLastHour != null ? count(data.http.rateLimitedLastHour) : "—"}
                  </TD>
                </TR>
              </TBody>
            </TableInCard>
          </CardContent>
        </Card>
      )}

      <p className="text-xs text-muted-foreground">
        Throttle counts are per minute, kept 35 days. A login’s TPS is set on{" "}
        <Link href={`/cp/accounts/${encodeURIComponent(id)}/logins`} className="underline underline-offset-2">the login</Link>
        ; vendor limits never refuse a customer and are not shown here.
      </p>
    </div>
  );
}

function Tiles({ data, readAt, liveRing }: { data: AccountThroughput; readAt: number; liveRing: number[] }) {
  const bound = data.listeners.filter((l) => l.binds > 0);
  const busiest = [...data.listeners].sort((a, b) => (b.tpsMeasured ?? -1) - (a.tpsMeasured ?? -1) || b.binds - a.binds)[0];
  const live = data.listeners.reduce((sum, l) => sum + (l.tpsMeasured ?? 0), 0);
  const binds = data.listeners.reduce((sum, l) => sum + l.binds, 0);
  //"of N allowed" only when every listener has a limit: one unlimited listener makes the sum a lie
  const allowed = data.listeners.every((l) => l.bindLimit.value > 0)
    ? data.listeners.reduce((sum, l) => sum + l.bindLimit.value, 0)
    : null;
  const throttled5 = data.listeners.reduce((sum, l) => sum + l.throttled.last5Minutes, 0);
  const worst = [...data.listeners].sort((a, b) => b.throttled.last5Minutes - a.throttled.last5Minutes)[0];
  const history = historySeries(data.history, 60, readAt);
  return (
    <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
      <StatTile
        label="Ceiling, busiest listener"
        value={busiest ? ceilingText(busiest.ceiling) ?? "none" : "—"}
        hint={busiest ? `${listenerName(busiest.listener)} · ${sourceWords(busiest)}` : undefined}
      />
      <StatTile
        label="Live TPS"
        value={formatTps(Math.round(live * 10) / 10)}
        hint={`across ${bound.length} listener${bound.length === 1 ? "" : "s"}`}
        sparkline={liveRing.length > 1 ? liveRing : undefined}
      />
      <StatTile
        label="Binds"
        value={count(binds)}
        hint={[allowed != null ? `of ${count(allowed)} allowed` : null, `${data.listeners.length} listener${data.listeners.length === 1 ? "" : "s"}`].filter(Boolean).join(" · ")}
      />
      <StatTile
        label="Throttled 5 min"
        value={count(throttled5)}
        tone={throttled5 > 0 ? "negative" : "default"}
        chip={throttled5 > 0 ? ["0x58", "warning"] : undefined}
        hint={throttled5 > 0 && worst
          ? `${worst.throttled.byLoginLimit > worst.throttled.byAccountLimit ? "login limit" : "account limit"} on ${listenerName(worst.listener)}`
          : history ? "per minute, last hour" : undefined}
        sparkline={history && history.some((v) => v > 0) ? history : undefined}
      />
    </div>
  );
}

/** "account override", "listener default": the tile's short form of the chip. */
function sourceWords(l: ListenerThroughput): string {
  switch (l.ceiling.source) {
    case "ACCOUNT_OVERRIDE":
      return "account override";
    case "LISTENER_DEFAULT":
      return l.ceiling.tier === "GATEWAY" ? "all listeners" : "listener default";
    case "LOGIN_MAX_TPS":
      return "login";
    case "UNLIMITED":
      return "unlimited";
  }
}

/**
 * A setting that is present and passed over -- `abc` where a number belongs, a zero -- is the one
 * fault this page can name that no other can: the listener page shows the stored value as if it
 * applied. One strip per ignored key, with the way to fix it.
 */
function IgnoredStrips({ data }: { data: AccountThroughput }) {
  const rows: { where: string; listener: string | null; ignored: IgnoredSetting }[] = [];
  for (const l of data.listeners) {
    for (const ignored of l.ceiling.ignored) {
      rows.push({ where: listenerName(l.listener), listener: listenerName(l.listener), ignored });
    }
  }
  for (const ignored of data.http.ceiling.ignored) {
    rows.push({ where: "HTTP", listener: null, ignored });
  }
  return (
    <>
      {rows.map((r) => (
        <HealthStrip
          key={`${r.where}|${r.ignored.key}`}
          tone="destructive"
          action={r.listener && (
            <Link href={`/cp/servers/${encodeURIComponent(r.listener)}?tab=settings`} className="font-medium underline">
              Fix on {r.listener} →
            </Link>
          )}
        >
          <span>
            <span className="font-mono">{r.ignored.key}</span> = <span className="font-mono">{r.ignored.raw ?? "(empty)"}</span>{" "}
            on <b>{r.where}</b> is ignored: {r.ignored.why}
          </span>
        </HealthStrip>
      ))}
    </>
  );
}

function ListenerRows({ account, l, nodes }: { account: string; l: ListenerThroughput; nodes: number }) {
  const name = listenerName(l.listener);
  const share = shareText(l.ceiling);
  return (
    <Fragment>
      <TR>
        <TD primary className="whitespace-nowrap">
          <Link href={`/cp/servers/${encodeURIComponent(name)}`} className="underline-offset-4 hover:underline">{name}</Link>
          {l.port != null && <span className="ml-1.5 font-mono text-xs font-normal text-muted-foreground">:{l.port}</span>}
        </TD>
        <TD className="whitespace-nowrap font-mono text-xs font-semibold tabular-nums">{ceilingText(l.ceiling) ?? "none"}</TD>
        <TD><LimitSourceChip ceiling={l.ceiling} /></TD>
        <TD
          className="whitespace-nowrap font-mono text-xs tabular-nums"
          title={l.ceiling.share < 1 ? `This node holds ${Math.round(l.ceiling.share * 100)} % of the account’s binds${nodes > 1 ? ` across ${nodes} nodes` : ""}.` : undefined}
        >
          {share ?? <span className="text-muted-foreground">—</span>}
        </TD>
        <TD><RateBar rate={l.tpsMeasured ?? (l.binds ? 0 : null)} ceiling={l.ceiling.effective} /></TD>
        <TD num className="whitespace-nowrap" title={l.bindLimit.key ? `${l.bindLimit.key}${l.bindLimit.tier === "GATEWAY" ? " (gateway-wide)" : ""}` : undefined}>
          {l.binds} / {l.bindLimit.value > 0 ? l.bindLimit.value : "no limit"}
        </TD>
        <TD num><Throttled t={l.throttled} /></TD>
      </TR>
      {l.logins.map((g) => {
        const own = g.binding === "LOGIN_MAX_TPS";
        return (
          <TR key={`${l.listener}|${g.systemId}`} className="text-sm">
            <TD className="whitespace-nowrap pl-7">
              <span className="text-muted-foreground">↳ </span>
              <span className="font-mono text-xs">{g.systemId}</span>
            </TD>
            <TD className="whitespace-nowrap font-mono text-xs tabular-nums">{ceilingText(g.ceiling) ?? "none"}</TD>
            <TD>
              {own ? (
                <span className="flex flex-wrap items-center gap-1.5">
                  <LimitSourceChip ceiling={g.ceiling} />
                  <Badge variant="info">binds first</Badge>
                </span>
              ) : (
                <span className="text-xs text-muted-foreground">shares the account ceiling</span>
              )}
            </TD>
            <TD>
              {/* the login's own TPS is set on the login, not here: one editor per key */}
              <Link
                href={`/cp/accounts/${encodeURIComponent(account)}/logins?edit=${encodeURIComponent(g.systemId)}`}
                className="text-xs text-muted-foreground underline-offset-2 hover:underline"
              >
                login TPS…
              </Link>
            </TD>
            {/* a login under the account's ceiling is measured against the account's, which it shares */}
            <TD><RateBar rate={g.tpsMeasured} ceiling={g.ceiling.effective} hot={own ? undefined : false} /></TD>
            <TD num>{g.sessions}</TD>
            <TD num><Throttled t={g.throttled} /></TD>
          </TR>
        );
      })}
    </Fragment>
  );
}

/** 1m · 5m · 1h · since start, the hour split by which limit turned them away on hover. */
function Throttled({ t }: { t: ThrottleCounts }) {
  const parts = [t.lastMinute, t.last5Minutes, t.lastHour, t.sinceStart];
  return (
    <span
      className="whitespace-nowrap tabular-nums"
      title={`Last hour: ${count(t.byAccountLimit)} by the account ceiling, ${count(t.byLoginLimit)} by a login’s own TPS${t.lastAt ? `. Last at ${new Date(t.lastAt).toLocaleString()}` : ""}.`}
    >
      {parts.map((v, i) => (
        <Fragment key={i}>
          {i > 0 && <span className="text-muted-foreground"> · </span>}
          <span className={v > 0 ? "text-warning" : "text-muted-foreground"}>{count(v)}</span>
        </Fragment>
      ))}
    </span>
  );
}

/**
 * "Set ceiling for this account on this listener…": one key, written on the listener picked. Empty
 * removes it and the listener default applies again.
 */
function CeilingEditor({
  account,
  listeners,
  stored,
  busy,
  onSet,
}: {
  account: string;
  listeners: readonly ListenerThroughput[];
  stored: (listener: string, key: string) => string;
  busy: boolean;
  onSet: (listener: string, setting: Setting, value: string) => Promise<boolean>;
}) {
  const [listener, setListener] = useState(listenerName(listeners[0]?.listener ?? ""));
  const [setting, setSetting] = useState<Setting>("rate");
  const [value, setValue] = useState("");
  const key = `${setting === "rate" ? "conf.maxRate" : "conf.maxConnectionsPerUser"}.${account}`;
  const current = stored(listener, key);
  return (
    <div className="rounded-lg border border-border bg-card">
      <SettingsRow
        label="Set ceiling for this account on this listener…"
        help={
          <>
            Writes <code className="font-mono">{key}</code> on the listener you pick
            {current ? <> (now <span className="font-mono">{current}</span>)</> : " (not set now)"}. An empty value removes
            it, and the listener default applies again; 0 is unlimited.
          </>
        }
        wide
      >
        <form
          className="flex flex-wrap gap-2 md:justify-end"
          onSubmit={async (e) => {
            e.preventDefault();
            if (await onSet(listener, setting, value)) {
              setValue("");
            }
          }}
        >
          <Select value={listener} onChange={(e) => setListener(e.target.value)} aria-label="Listener" className="w-40">
            {listeners.map((l) => (
              <option key={l.listener} value={listenerName(l.listener)}>
                {listenerName(l.listener)}{l.port != null ? ` :${l.port}` : ""}
              </option>
            ))}
          </Select>
          <Select value={setting} onChange={(e) => setSetting(e.target.value as Setting)} aria-label="Setting" className="w-44">
            <option value="rate">Rate ceiling (msg/s)</option>
            <option value="binds">Binds per customer</option>
          </Select>
          <Input
            value={value}
            onChange={(e) => setValue(e.target.value)}
            inputMode="numeric"
            placeholder={current || (setting === "rate" ? "msg/s" : "binds")}
            aria-label="Value"
            className="w-24 font-mono"
          />
          <Button type="submit" size="sm" disabled={busy || !listener}>Set</Button>
        </form>
      </SettingsRow>
    </div>
  );
}
