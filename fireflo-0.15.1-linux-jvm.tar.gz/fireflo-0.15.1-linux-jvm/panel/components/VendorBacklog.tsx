"use client";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import { HealthStrip } from "./CardBits";
import { count } from "@/lib/format";
import { ageWords, backlogAlerts, backlogBadge, type VendorBacklog } from "@/lib/vendor-backlog";

/**
 * Each vendor's backlog against its limits (gateway 0.15.1): what waits, how old the oldest is, its
 * state, its bind, and where its traffic went instead. On the Vendors page, above the cards.
 */
export function VendorBacklogTable({ vendors }: { vendors: readonly VendorBacklog[] }) {
  if (vendors.length === 0) {
    return null;
  }
  return (
    //id="backlog": the anchor the Connectivity map's vendor menu sends you to
    <Card id="backlog">
      <CardHeader bar>
        <CardTitle>Backlogs</CardTitle>
        <p className="text-xs text-muted-foreground">
          What each vendor has been handed and not yet sent, against its limits. Past three quarters of a limit
          its traffic prefers another member of its group; past a limit it is not routed to, and a submit with no
          other route is refused. A message waiting longer than its expiry is not sent but refunded.
        </p>
      </CardHeader>
      <CardContent>
        <TableInCard className="tabular-nums">
          <THead>
            <tr>
              <TH>Vendor</TH>
              <TH align="right">Backlog</TH>
              <TH align="right">Oldest</TH>
              <TH>State</TH>
              <TH>Failover</TH>
              <TH align="right">Refused</TH>
              <TH align="right">Expired</TH>
            </tr>
          </THead>
          <TBody>
            {vendors.map((v) => {
              const badge = backlogBadge(v);
              return (
                <TR key={v.worker}>
                  <TD className="font-mono text-xs">{v.worker}</TD>
                  <TD align="right">
                    {v.depth < 0 ? "—" : count(v.depth)}
                    <span className="text-muted-foreground"> / {count(v.limit)}</span>
                  </TD>
                  <TD align="right">
                    {ageWords(v.oldestAgeSeconds)}
                    <span className="text-muted-foreground"> / {ageWords(v.maxAgeSeconds)}</span>
                  </TD>
                  <TD className="whitespace-nowrap">
                    {badge ? <Badge variant={badge.tone}>{badge.label}</Badge> : <Badge variant="success">ok</Badge>}
                    {!v.bound && v.unboundSinceSeconds != null && (
                      <span className="ml-2 text-xs text-muted-foreground">no bind for {ageWords(v.unboundSinceSeconds)}</span>
                    )}
                    {v.retentionUsedPercent != null && (
                      <span className={`ml-2 text-xs ${v.retentionUsedPercent >= 50 ? "text-destructive" : "text-muted-foreground"}`}>
                        {v.retentionUsedPercent}% of retention
                      </span>
                    )}
                  </TD>
                  <TD className="font-mono text-xs">{v.failoverTarget ?? <span className="text-muted-foreground">—</span>}</TD>
                  <TD align="right" className={v.refusedTotal > 0 ? "text-destructive" : undefined}>{count(v.refusedTotal)}</TD>
                  <TD align="right" className={v.expiredTotal > 0 ? "text-destructive" : undefined}>{count(v.expiredTotal)}</TD>
                </TR>
              );
            })}
          </TBody>
        </TableInCard>
      </CardContent>
    </Card>
  );
}

/**
 * The warning on Overview and Health: a vendor refusing, unbound past the grace after which its
 * traffic is refused, or a backlog half way through its topic's retention. Nothing otherwise, and
 * nothing on a gateway before 0.15.1.
 */
export function VendorBacklogAlert({ vendors, graceSeconds }: { vendors: readonly VendorBacklog[]; graceSeconds: number }) {
  const alerts = backlogAlerts(vendors, graceSeconds);
  if (alerts.length === 0) {
    return null;
  }
  return (
    <Card className="border-destructive/50">
      <CardHeader bar>
        <CardTitle>Vendor backlogs</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {alerts.map((a, i) => (
          <HealthStrip key={`${a.worker}-${i}`} tone={a.tone}>
            <span>
              {a.message}{" "}
              <Link href="/cp/vendors" className="underline">Vendors</Link>
            </span>
          </HealthStrip>
        ))}
      </CardContent>
    </Card>
  );
}
