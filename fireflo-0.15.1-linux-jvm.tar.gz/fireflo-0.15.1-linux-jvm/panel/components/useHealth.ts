"use client";
import { useEffect, useMemo, useSyncExternalStore } from "react";
import type { Health, HealthWorker } from "@/lib/health-types";
import { HEALTH_POLL_SECONDS, useLiveGatewayStores } from "./LiveGatewayProvider";

export { HEALTH_POLL_SECONDS };

/**
 * Live gateway state, polled, keyed by full worker name.
 *
 * <p>A subscription to the one health poll `LiveGatewayProvider` runs per page, not a poll of its
 * own: any number of call sites cost one `/health` request per interval, and the poll stops while
 * none is mounted or the tab is hidden. Same return shape as before, with `rateHistory` added for
 * the live traffic chart.
 *
 * <p>Slower than the health page's five seconds: this is a status line beside settings, not a
 * counter someone is watching tick.
 *
 * <p>An unreachable gateway is reported as an error but leaves the last snapshot in place. Blanking
 * the page on one failed poll would make a working gateway look like it disappeared, and the
 * settings beside the status are still worth reading either way.
 */
export function useHealth() {
  const { health: store } = useLiveGatewayStores();
  useEffect(() => store.acquire(), [store]);
  const state = useSyncExternalStore(store.subscribe, store.getSnapshot, store.getInitialSnapshot);

  //the snapshot reports getFullName() -- 'smppclient.vendor1' -- while app_worker.name is the
  //instance alone; see trafficKey, which exists for the same mismatch on the traffic join
  const byFullName = useMemo(
    () => new Map((state.health?.workers ?? []).map((w) => [w.name, w] as const)),
    [state.health]
  );

  return {
    health: state.health,
    error: state.error,
    /** The last poll found the gateway slow: `health` is the answer from `at` (0.15.1). */
    slow: state.slow,
    at: state.at,
    loading: state.loading,
    reload: store.refresh,
    byFullName,
    tpsHistory: state.tpsHistory,
    queueHistory: state.queueHistory,
    rateHistory: state.rateHistory,
  };
}

export type { Health, HealthWorker };
