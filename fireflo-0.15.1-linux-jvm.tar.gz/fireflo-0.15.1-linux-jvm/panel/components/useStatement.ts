"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { noteSource } from "@/lib/page-sources";
import { StatementLoader, initialLoadState, type StatementLoadState } from "@/lib/statement-loader";

/**
 * A statement's figures, fetched only when `show` is called (`lib/statement-loader.ts` has the
 * rules): the newest request wins, and a `202` keeps the breathing card up while it asks again.
 *
 * <p>No polling. A statement is a month of billing read on purpose, not a dashboard; the operator
 * presses Show again when they want it re-read.
 */
export function useStatement<T>(): [StatementLoadState<T>, (url: string) => void] {
  const [state, setState] = useState<StatementLoadState<T>>(() => initialLoadState<T>());
  const loader = useRef<StatementLoader<T> | null>(null);

  useEffect(() => {
    const l = new StatementLoader<T>({
      fetch: (url, init) => fetch(url, init),
      setTimer: (fn, ms) => setTimeout(fn, ms),
      clearTimer: (h) => clearTimeout(h as ReturnType<typeof setTimeout>),
      onChange: (s) => setState(s as StatementLoadState<T>),
      //the footer's data-source stat: one entry for the statement, the latest read
      onAnswer: (_url, res) => noteSource("statement", res),
    });
    loader.current = l;
    return () => {
      l.dispose();
      loader.current = null;
    };
  }, []);

  const show = useCallback((url: string) => {
    loader.current?.show(url);
  }, []);

  return [state, show];
}
