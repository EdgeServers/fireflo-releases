"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { useConfirmChange } from "./ConfirmProvider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Segmented } from "@/components/ui/segmented";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { StatTile } from "@/components/ui/stat-tile";
import { ErrorCard } from "./FormNotices";
import { StaleNote } from "./StaleNote";
import { BreathingCard } from "./BreathingCard";
import { useStatement } from "./useStatement";
import { usePeriod } from "./usePeriod";
import { keyLabel } from "@/lib/statement-chart";
import { StatementPerDayChart } from "./StatementPerDayChart";
import { SplitToggle } from "./StatementSplitToggle";
import { count, money, percent } from "@/lib/format";
import { recentMonths } from "@/lib/billing-period";
import { creditNoteMessage, type ClosedPeriod, type Restatement } from "@/lib/period-close";
import { periodQuery, type PeriodDraft } from "@/lib/statement-loader";
import type { StatementSplit, StatementSummary } from "@/lib/statement-queries";

const SPLITS = ["product", "login"] as const;




/** What the route returns on top of the summary itself. The days are the summary's own. */
interface StatementPayload extends StatementSummary {
  closed: ClosedPeriod[];
  closedAs: ClosedPeriod | null;
  restatement: Restatement | null;
}

interface ExportJob {
  id: string;
  status: string;
  rows?: number;
  error?: string | null;
}

const MODES = [
  { value: "month", label: "Month" },
  { value: "range", label: "Date range", title: "Any window of up to 92 days" },
] as const;

/** `2026-09` as "September 2026", for a sentence. A range is said as its two ends. */
function periodWords(draft: PeriodDraft): string {
  if (draft.mode === "range") {
    return `${draft.from} to ${draft.to}`;
  }
  const [y, m] = draft.month.split("-").map(Number);
  return new Date(y, m - 1, 1).toLocaleString(undefined, { month: "long", year: "numeric" });
}

/** Delivered over what settled, as `/cp/usage` divides: in-flight traffic is not failure. */
function deliveryRate(delivered: number, failed: number, expired: number): number | null {
  const settled = delivered + failed + expired;
  return settled > 0 ? delivered / settled : null;
}

/**
 * One account's bill for one period, with the CSV and the close action beside it.
 *
 * <p>The three things live on one screen because they are one decision: an operator reads the
 * figure, downloads it if somebody has asked for it, and closes the period once they believe it.
 * Closing on a different screen from the number being closed is how the wrong month gets invoiced.
 *
 * <p><strong>The period is read when Show is pressed, not when it is picked.</strong> A month of a
 * large account is a heavy read, and refetching on every change of the select fired one per step
 * through the list, none of them cancelled. Picking now only marks the controls "changed"; the
 * figures on screen stay those of the period they are labelled with, and the CSV and the close act
 * on that period -- never on a draft nobody has looked at. The page opens on last month, read at
 * once, as it always has.
 */
export function StatementClient({ id, currency }: { id: string; currency: string }) {
  //the month in progress is offered, and labelled -- an operator watching a postpaid account's
  //accrual wants exactly that, and it is the picker's job to say it has not finished
  const months = useMemo(() => recentMonths(new Date(), 13), []);
  const thisMonth = months[0];

  const [draft, setDraft] = useState<PeriodDraft>({
    mode: "month", month: months[1] ?? thisMonth, from: "", to: "",
  });
  //the period the figures on screen are for, or are being read for
  const [applied, setApplied] = useState<PeriodDraft | null>(null);
  const [invalid, setInvalid] = useState("");

  //Product or Login (0.15.1), remembered in this browser; switching re-reads the same period
  const [split, setSplit] = usePeriod<StatementSplit>("statement-split", SPLITS, "product");
  const [state, show] = useStatement<StatementPayload>();
  const { data, loading, busy, stale } = state;
  const [jobs, setJobs] = useState<ExportJob[]>([]);
  const [actionError, setActionError] = useState("");
  const [notice, setNotice] = useState("");
  const [acting, setActing] = useState(false);
  const confirm = useConfirmChange();

  const base = `/api/control/accounts/${encodeURIComponent(id)}/statement`;
  const appliedQuery = applied ? periodQuery(applied) : null;
  const query = appliedQuery && "query" in appliedQuery ? appliedQuery.query : null;
  const draftQuery = periodQuery(draft);
  const changed = applied !== null && ("invalid" in draftQuery || draftQuery.query !== query);

  /** Reads `next`, or says beside the controls why it cannot be read. */
  const showPeriod = useCallback((next: PeriodDraft) => {
    const asked = periodQuery(next);
    if ("invalid" in asked) {
      setInvalid(asked.invalid);
      return;
    }
    setInvalid("");
    setNotice("");
    setActionError("");
    setApplied(next);
    show(`${base}?${asked.query}${split === "login" ? "&split=login" : ""}`);
  }, [base, show, split]);

  const loadJobs = useCallback(async () => {
    try {
      const res = await fetch(`${base}?exports=1`, { cache: "no-store" });
      const json = await res.json().catch(() => null);
      setJobs(Array.isArray(json?.data) ? json.data : []);
    } catch {
      //the file list is a convenience beside the figure, never a reason to fail the page
    }
  }, [base]);

  //the first read, of last month, as the page has always opened. Every later one is a Show, or a
  //change of split, which re-reads the period on screen (showPeriod changes with the split)
  const [opened, setOpened] = useState(false);
  useEffect(() => {
    if (!opened) {
      //eslint-disable-next-line react-hooks/set-state-in-effect -- the first read, once
      setOpened(true);
      showPeriod({ mode: "month", month: months[1] ?? thisMonth, from: "", to: "" });
    } else if (applied) {
      showPeriod(applied);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- re-read on a change of split only
  }, [showPeriod]);

  useEffect(() => {
    void loadJobs();
  }, [loadJobs]);

  function edit(next: Partial<PeriodDraft>) {
    setDraft((d) => ({ ...d, ...next }));
    setInvalid("");
  }

  async function requestCsv() {
    if (!query) {
      return;
    }
    setActing(true);
    setNotice("");
    setActionError("");
    try {
      const res = await fetch(`${base}?${query}`, { method: "POST" });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setActionError(json?.error ?? "Could not prepare the file.");
        return;
      }
      setNotice("Preparing the file. It appears below when it is ready.");
      await loadJobs();
    } finally {
      setActing(false);
    }
  }

  /**
   * Closing is the one irreversible thing on this page: a closed period is the invoice, and nothing
   * reissues it. So it is asked for in the same modal every other money action uses, with the
   * figure being closed in the dialog -- the number the operator just read is the number they
   * confirm, on the same screen.
   */
  async function confirmClose() {
    if (!data) {
      return;
    }
    const amount = money(data.totalAmount, currency);
    const ok = await confirm({
      title: "Close this period?",
      consequence: `Invoices ${data.label} for ${id} at ${amount}. A closed period is never reissued; `
        + "anything landing against it afterwards shows as a restatement, not a change to this figure.",
      confirmLabel: `Close ${data.label}`,
      tone: "caution",
      changes: [
        { label: "Period", to: data.label },
        { label: "Amount", to: amount },
      ],
    });
    if (ok) {
      await close();
    }
  }

  async function close() {
    if (!query || !applied) {
      return;
    }
    setActing(true);
    setActionError("");
    setNotice("");
    try {
      const res = await fetch(`${base}?${query}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setActionError(json?.error ?? "Could not close the period.");
        return;
      }
      //re-read the same period: the closed list is never kept, so it shows as closed at once
      showPeriod(applied);
      setNotice(json?.notice ?? "Closed.");
    } finally {
      setActing(false);
    }
  }

  const label = data?.label ?? (applied ? periodWords(applied) : "");
  const isClosed = Boolean(data?.closedAs);
  //the month in progress cannot be closed, and saying why beats a disabled button with no reason
  const unfinished = applied?.mode === "month" && applied.month === thisMonth;
  const pending = data ? data.lines.reduce((n, l) => n + l.pending, 0) : 0;
  const failed = data ? data.lines.reduce((n, l) => n + l.failed, 0) : 0;
  const expired = data ? data.lines.reduce((n, l) => n + l.expired, 0) : 0;
  const rate = data ? deliveryRate(data.totalDelivered, failed, expired) : null;
  //skeletons while a read is going and nothing is on screen for it
  const tilesLoading = loading && !data;

  return (
    <>
      {/* a control row, not a Card. This is a tab, and wrapping a period picker in its own titled
          card put a heading over three inputs and pushed the figure below the fold */}
      <div className="flex flex-wrap items-end gap-3">
        <Segmented
          label="Period"
          options={MODES}
          value={draft.mode}
          onChange={(mode) => edit({ mode })}
        />
        {draft.mode === "month" ? (
          <div className="space-y-1">
            <Label htmlFor="stmt-month">Month</Label>
            <select
              id="stmt-month"
              className="h-11 rounded-md border border-input bg-background px-2 text-sm md:h-9"
              value={draft.month}
              onChange={(e) => edit({ month: e.target.value })}
            >
              {months.map((m) => (
                <option key={m} value={m}>
                  {m}
                  {m === thisMonth ? " (in progress)" : ""}
                </option>
              ))}
            </select>
          </div>
        ) : (
          <>
            <div className="space-y-1">
              <Label htmlFor="stmt-from">From</Label>
              <Input id="stmt-from" type="date" className="h-9 w-40 text-sm"
                value={draft.from} onChange={(e) => edit({ from: e.target.value })} />
            </div>
            <div className="space-y-1">
              <Label htmlFor="stmt-to">To</Label>
              <Input id="stmt-to" type="date" className="h-9 w-40 text-sm"
                value={draft.to} onChange={(e) => edit({ to: e.target.value })} />
            </div>
          </>
        )}
        {/* the one way to read a period. It carries the sweep while the read is going, as the
            range buttons do, so the thing pressed is the thing that says it is working */}
        <Button
          className="relative h-9"
          onClick={() => showPeriod(draft)}
          aria-busy={loading || undefined}
        >
          Show
          {loading && <span className="tab-busy-bar inset on-fill" aria-hidden />}
        </Button>
        {invalid ? (
          <p className="pb-2 text-sm text-destructive" role="alert">{invalid}</p>
        ) : changed && !loading ? (
          <p className="pb-2 text-xs text-muted-foreground">Changed — press Show</p>
        ) : null}
        {data && (
          <div className="ml-auto flex flex-wrap items-center gap-2">
            <Button size="sm" variant="ghost" className="h-9" disabled={acting || loading}
              onClick={() => void requestCsv()}>
              Download CSV
            </Button>
            {!isClosed && !unfinished && (
              <Button size="sm" className="h-9" disabled={acting || loading} onClick={() => void confirmClose()}>
                Close this period
              </Button>
            )}
          </div>
        )}
      </div>

      <StaleNote stale={stale} />
      {/* still reading a lot of data in the background: a calm card, never the timeout error */}
      {busy && !data && <BreathingCard what={`${label} for ${id}`} retryAfter={state.retryAfter} />}
      <ErrorCard error={state.error || actionError} />

      {(data || tilesLoading) && (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatTile label="Amount" value={data ? money(data.totalAmount, currency) : ""}
            loading={tilesLoading} hint={isClosed ? `${label} · closed` : label} />
          <StatTile label="Sent" value={data ? count(data.totalSubmitted) : ""} loading={tilesLoading} />
          <StatTile label="Delivered" value={data ? count(data.totalDelivered) : ""}
            tone="positive" loading={tilesLoading} />
          <StatTile
            label="Delivery rate"
            value={percent(rate)}
            loading={tilesLoading}
            hint={pending > 0 ? `${count(pending)} still awaiting a receipt` : undefined}
          />
          {/* only when there is some. A tile reading zero teaches an operator to ignore the tile */}
          {data && data.totalUnrated > 0 && (
            <StatTile label="Sent, not billed" value={count(data.totalUnrated)}
              tone="negative" hint="No price applied. Sent all the same." />
          )}
        </div>
      )}

      {data && data.days.length > 0 && <StatementPerDayChart days={data.days} lines={data.lines} split={data.split} />}

      {data && (
        <Card>
          <CardHeader bar className="flex flex-row flex-wrap items-center gap-2 space-y-0">
            <CardTitle className="min-w-0 flex-1">
              By {data.split === "login" ? "login" : "product"}
              <span className="ml-2 text-xs font-normal text-muted-foreground">
                {label}{isClosed ? " · closed" : ""}
              </span>
            </CardTitle>
            {/* directly above the table it splits, and the per-day chart above follows it too. Login
                needs the gateway's V1.115.0; until then it is offered disabled, the reason as its title */}
            <SplitToggle split={split} onChange={setSplit} loginSplit={data.loginSplit} busy={loading} />
          </CardHeader>
          <CardContent className="space-y-3">
            {unfinished && (
              <p className="text-xs text-muted-foreground">
                This month has not finished, so it cannot be closed. The figure moves as traffic
                arrives.
              </p>
            )}

            {data.restatement && (
              //the whole reason a closed period is stored rather than recomputed
              <p className="text-sm text-warning">
                {creditNoteMessage(data.restatement, (s) => money(s, currency))}
              </p>
            )}

            {data.lines.length > 0 ? (
              <TableInCard className="tabular-nums">
                <THead>
                  <tr>
                    <TH>{data.split === "login" ? "Login" : "Product"}</TH>
                    <TH align="right">Sent</TH>
                    <TH align="right">Delivered</TH>
                    <TH align="right">Failed</TH>
                    <TH align="right">Expired</TH>
                    <TH align="right">Pending</TH>
                    <TH align="right">Not billed</TH>
                    <TH align="right">Rate</TH>
                    <TH align="right">Billed</TH>
                  </tr>
                </THead>
                <TBody>
                  {data.lines.map((l) => (
                    <TR key={l.product || "(none)"}>
                      <TD>{l.product || <span className="text-muted-foreground">{keyLabel("", data.split)}</span>}</TD>
                      <TD align="right">{count(l.submitted)}</TD>
                      <TD align="right">{count(l.delivered)}</TD>
                      <TD align="right">
                        {l.failed > 0 ? <span className="text-destructive">{count(l.failed)}</span> : count(0)}
                      </TD>
                      <TD align="right">{count(l.expired)}</TD>
                      <TD align="right" muted>{count(l.pending)}</TD>
                      <TD align="right">{count(l.unrated)}</TD>
                      <TD align="right">{percent(deliveryRate(l.delivered, l.failed, l.expired))}</TD>
                      <TD align="right">{money(l.amount, currency)}</TD>
                    </TR>
                  ))}
                </TBody>
              </TableInCard>
            ) : (
              <p className="text-sm text-muted-foreground">No traffic in this period.</p>
            )}

            {data.split === "login" && data.lines.some((l) => l.product === "") && (
              <p className="text-xs text-muted-foreground">
                <strong>{keyLabel("", "login")}</strong> is not one login: it is the messages that named no
                login and, for days the gateway summarised before it recorded logins (0.15.1), every login&apos;s
                traffic together. It is billed all the same, and the totals are the same as by product.
              </p>
            )}
            <p className="text-xs text-muted-foreground">
              Billed on <strong>submitted</strong>, on a half-open window, so a message belongs to
              exactly one period. Delivery figures keep moving as receipts arrive; the amount does
              not. Finished days come from the nightly usage summary, the last day or two from the
              call records.
            </p>
            {notice && <p className="text-xs text-warning">{notice}</p>}
          </CardContent>
        </Card>
      )}

      {/*
        Closed periods and prepared files side by side: both are short lists beside the figure, not
        the figure. `minmax(0,1fr)`, never a bare `1fr`, for the reason MisOverviewClient records,
        and `items-start` because the two cards are guarded separately -- a fresh account has
        neither, and one must not stretch to fill the other's absence.
      */}
      {((data && data.closed.length > 0) || jobs.length > 0) && (
        <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
          {/* each cell is a wrapper that always exists. A bare `{cond && <Card/>}` renders no cell
              at all when the guard is false, and the other card would slide into its track */}
          <div className="min-w-0">
            {data && data.closed.length > 0 && (
              <Card>
                <CardHeader bar>
                  <CardTitle>Closed periods</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-1 text-sm">
                    {data.closed.map((c) => (
                      <li key={c.label} className="flex flex-wrap items-baseline gap-2">
                        {/* a click on a closed month is a request to see it, so it is read at once
                            rather than left as a draft waiting for Show */}
                        <button
                          type="button"
                          className="underline underline-offset-2 hover:text-foreground"
                          onClick={() => {
                            const next: PeriodDraft = { ...draft, mode: "month", month: c.label };
                            setDraft(next);
                            showPeriod(next);
                          }}
                        >
                          {c.label}
                        </button>
                        <span className="tabular-nums">{money(c.invoiced, currency)}</span>
                        {c.note && <span className="text-muted-foreground">{c.note}</span>}
                      </li>
                    ))}
                  </ul>
                  <p className="mt-2 text-xs text-muted-foreground">
                    A closed period is never reissued. Anything landing against one afterwards shows
                    as a credit note on the period that follows it.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
          <div className="min-w-0">
            {jobs.length > 0 && (
              <Card>
                <CardHeader bar>
                  <CardTitle>Prepared files</CardTitle>
                </CardHeader>
                <CardContent className="space-y-1.5">
                  {jobs.map((job) => (
                    <div key={job.id} className="flex flex-wrap items-center gap-2 text-sm">
                      <span className="text-muted-foreground">{job.status}</span>
                      {job.rows != null && <span className="tabular-nums">{job.rows.toLocaleString()} rows</span>}
                      {job.status === "ready" && (
                        <a className="text-primary hover:underline" href={`${base}/${job.id}`}>Download</a>
                      )}
                      {job.error && <span className="text-destructive">{job.error}</span>}
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      )}
    </>
  );
}


