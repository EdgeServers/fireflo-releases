import { DEFAULT_SCOPE, type ScopeSummary } from "./rate-types.ts";
import { tagScope } from "./tag-types.ts";

/** One level of an account's sell-price order. */
export interface PriceLevel {
  kind: "own" | "tag" | "default";
  scope: string;
  /** For a tag level: the tag, and its place in the Tags list. */
  tag?: string;
  order?: number;
  /** For a tag level: carried from a units parent rather than set on the account. */
  inherited?: boolean;
  /** Enabled prices in that scope; 0 for none. */
  prices: number;
}

/**
 * The order the gateway looks for an account's sell price: its own scope, then `tag:<t>` for each of
 * its enabled tags by (`seq`, `name`), then `*`. Pure, for the Tariff tab's "Which price applies".
 *
 * @param effective the account's enabled tags, own and inherited, already in order
 * @param tagOrder every tag in order, for each tag's position
 * @param own the account's own tags, to mark the rest as inherited (optional)
 */
export function priceLevels(
  account: string,
  effective: readonly string[],
  scopes: readonly ScopeSummary[],
  tagOrder: readonly { name: string }[],
  own?: readonly string[]
): PriceLevel[] {
  const enabled = new Map(scopes.map((s) => [s.scope, s.enabled]));
  const position = new Map(tagOrder.map((t, i) => [t.name, i + 1]));
  return [
    { kind: "own", scope: account, prices: enabled.get(account) ?? 0 },
    ...effective.map((tag): PriceLevel => ({
      kind: "tag",
      scope: tagScope(tag),
      tag,
      order: position.get(tag),
      inherited: own ? !own.includes(tag) : undefined,
      prices: enabled.get(tagScope(tag)) ?? 0,
    })),
    { kind: "default", scope: DEFAULT_SCOPE, prices: enabled.get(DEFAULT_SCOPE) ?? 0 },
  ];
}
