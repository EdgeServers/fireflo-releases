import { test } from "node:test";
import assert from "node:assert/strict";
import {
  effectiveTags,
  inUseMessage,
  isUsed,
  moveTag,
  NO_USAGE,
  reorderProblem,
  seqPlan,
  tagDiff,
  tagNameProblem,
  tagOfScope,
  tagScope,
  tagsNamedBy,
  tagUsages,
  usageLine,
} from "./tag-types.ts";
import { DEFAULT_SCOPE, conditionErrors, describeTagCondition, scopeKind, tagConditionProblem, validateScope } from "./rate-types.ts";
import { priceLevels } from "./price-order.ts";
import { TAG_COLORS, tagColorOf, tagDescriptionProblem, tagTitle, isTagPick, splitTagPicks, withTagPicks, tagPickOptions, unknownTagNames } from "./tag-types.ts";

test("a tag name follows the table's CHECK exactly", () => {
  for (const ok of ["premium", "otp", "bulk-promo", "a", "9lives", "x_y", "a".repeat(40)]) {
    assert.equal(tagNameProblem(ok), null, ok);
  }
  for (const bad of ["", "Premium", "-lead", "_lead", "has space", " premium", "premium ", "a".repeat(41), "tag:x", "ü"]) {
    assert.ok(tagNameProblem(bad), bad);
  }
});

test("a tag's price list lives under tag:<name>, and only that prefix is a tag scope", () => {
  assert.equal(tagScope("premium"), "tag:premium");
  assert.equal(tagOfScope("tag:premium"), "premium");
  assert.equal(tagOfScope("premium"), null);
  assert.equal(tagOfScope(DEFAULT_SCOPE), null);
  const known = { vendors: ["v1"], accounts: ["acme"], tags: ["premium"] };
  assert.equal(scopeKind("tag:premium", known), "tag");
  assert.equal(scopeKind("tag:gone", known), "tag");
  assert.equal(scopeKind("acme", known), "price");
  assert.equal(scopeKind("*", known), "default");
});

test("a tag price list for a tag that does not exist, or on a database without tags, is refused", () => {
  const rules = [{ id: null, amount: "0.1", product: null, currency: null, label: null, enabled: true, conditions: [], filters: [] }];
  const known = { vendors: [], accounts: [], tags: ["premium"] };
  assert.equal(validateScope({ scope: "tag:premium", rules }, known), null);
  assert.match(validateScope({ scope: "tag:gone", rules }, known) ?? "", /no tag called 'gone'/);
  assert.match(validateScope({ scope: "tag:premium", rules }, { vendors: [], accounts: [] }) ?? "", /gateway 0\.17\.0/);
});

test("which tags a condition names: one for equals, a list for startsWithAny, none for isNull", () => {
  assert.deepEqual(tagsNamedBy("equals", "premium"), ["premium"]);
  assert.deepEqual(tagsNamedBy("startsWithAny", "otp, premium,otp"), ["otp", "premium"]);
  assert.deepEqual(tagsNamedBy("isNull", ""), []);
  assert.deepEqual(tagsNamedBy("equals", " "), []);
  assert.deepEqual(tagsNamedBy("equals", "otp, premium"), ["otp", "premium"], "has all of names each");
});

test("usage is counted per rule, filter and price list, once per owner however often it names the tag", () => {
  const usage = tagUsages(
    [
      { kind: "routing", owner: "main #1 → v1", operator: "equals", value: "premium" },
      { kind: "routing", owner: "main #1 → v1", operator: "startsWithAny", value: "premium,otp" },
      { kind: "routing", owner: "main #2 → v2", operator: "startsWithAny", value: "otp" },
      { kind: "pricing", owner: "scope acme #1", operator: "equals", value: "premium" },
      { kind: "filter", owner: "filter vip", operator: "startsWithAny", value: "premium" },
      { kind: "filter", owner: "filter untagged", operator: "isNull", value: "" },
    ],
    [{ scope: "tag:premium", rules: 2 }, { scope: "tag:empty", rules: 0 }, { scope: "acme", rules: 4 }]
  );
  const premium = usage.get("premium")!;
  assert.deepEqual(
    { routeRules: premium.routeRules, priceRules: premium.priceRules, filters: premium.filters, prices: premium.prices },
    { routeRules: 1, priceRules: 1, filters: 1, prices: 2 }
  );
  assert.equal(usage.get("otp")!.routeRules, 2);
  assert.equal(usage.has("empty"), false, "an empty price list names nothing");
  assert.equal(usageLine(premium), "1 route rule · 1 price rule · 1 filter · 1 price list");
  assert.equal(usageLine(NO_USAGE), "not used");
  assert.ok(isUsed(premium));
  assert.ok(!isUsed(NO_USAGE));
});

test("a refused delete names where the tag is used", () => {
  const usage = tagUsages([{ kind: "routing", owner: "main #3 → vendor-a", operator: "equals", value: "otp" }], [])
    .get("otp")!;
  const message = inUseMessage("otp", usage);
  assert.match(message, /'otp' is used by 1 route rule/);
  assert.match(message, /main #3 → vendor-a/);
  assert.match(message, /switch the tag off instead/);
});

test("moving a tag swaps it with its neighbour, and does nothing at either end", () => {
  const order = ["otp", "premium", "bulk"];
  assert.deepEqual(moveTag(order, "premium", -1), ["premium", "otp", "bulk"]);
  assert.deepEqual(moveTag(order, "premium", 1), ["otp", "bulk", "premium"]);
  assert.deepEqual(moveTag(order, "otp", -1), order);
  assert.deepEqual(moveTag(order, "bulk", 1), order);
  assert.deepEqual(moveTag(order, "missing", 1), order);
});

test("a reorder must name every tag exactly once, and is written as 1, 2, 3", () => {
  const existing = ["otp", "premium", "bulk"];
  assert.equal(reorderProblem(["bulk", "otp", "premium"], existing), null);
  assert.ok(reorderProblem(["bulk", "otp"], existing), "a partial list");
  assert.ok(reorderProblem(["bulk", "otp", "otp"], existing), "a repeat");
  assert.ok(reorderProblem(["bulk", "otp", "new"], existing), "a tag that is not there");
  assert.deepEqual(seqPlan(["bulk", "otp"]), [{ name: "bulk", seq: 1 }, { name: "otp", seq: 2 }]);
});

test("what an account carries: own and inherited, enabled only, in the list's order, once each", () => {
  const order = [
    { name: "otp", enabled: true },
    { name: "premium", enabled: true },
    { name: "trial", enabled: false },
    { name: "bulk", enabled: true },
  ];
  assert.deepEqual(effectiveTags(["bulk", "trial"], ["premium", "bulk"], order), ["premium", "bulk"]);
  assert.deepEqual(effectiveTags([], [], order), []);
});

test("a tag change is sent as add and remove, never a replace", () => {
  assert.deepEqual(tagDiff(["otp", "premium"], ["premium", "bulk"]), { add: ["bulk"], remove: ["otp"] });
  assert.deepEqual(tagDiff(["otp"], ["otp"]), { add: [], remove: [] });
});

test("a tag condition takes only equals, startsWithAny and isNull, with tag names as values", () => {
  const c = (operator: string, value: string, negate = false) => ({ field: "tag", operator, value, negate });
  assert.equal(tagConditionProblem(c("equals", "premium")), null);
  assert.equal(tagConditionProblem(c("startsWithAny", "premium,otp", true)), null);
  assert.equal(tagConditionProblem(c("isNull", "")), null);
  assert.match(tagConditionProblem(c("startsWith", "prem")) ?? "", /cannot test an account tag/);
  assert.match(tagConditionProblem(c("matches", ".*")) ?? "", /cannot test an account tag/);
  assert.match(tagConditionProblem(c("equals", "")) ?? "", /needs a tag/);
  assert.equal(tagConditionProblem(c("equals", "otp,premium")), null, "has all of");
  assert.match(tagConditionProblem(c("equals", "otp,,premium")) ?? "", /empty entry/);
  assert.match(tagConditionProblem(c("startsWithAny", "premium,,otp")) ?? "", /empty entry/);
  assert.match(tagConditionProblem(c("equals", "Premium")) ?? "", /not a tag name/);
  assert.equal(tagConditionProblem({ field: "to", operator: "startsWith", value: "+91" }), null, "other fields untouched");
  //the shared checks that rate and routing saves run
  assert.match(conditionErrors([c("startsWith", "x")], "rule 1", "routing table") ?? "", /^Rule 1: /);
  assert.equal(conditionErrors([c("isNull", "")], "rule 1", "rate table"), null);
});

test("a tag condition reads in words, all six forms", () => {
  const c = (operator: string, value: string, negate = false) => ({ operator, value, negate });
  assert.equal(describeTagCondition(c("equals", "premium")), "the account has tag premium");
  assert.equal(describeTagCondition(c("equals", "premium", true)), "the account does not have tag premium");
  assert.equal(describeTagCondition(c("startsWithAny", "otp,premium")), "the account has any of the tags otp, premium");
  assert.equal(describeTagCondition(c("startsWithAny", "otp,premium", true)), "the account has none of the tags otp, premium");
  assert.equal(describeTagCondition(c("isNull", "")), "the account has no tag");
  assert.equal(describeTagCondition(c("isNull", "", true)), "the account has at least one tag");
});

test("the sell-price order: own, each enabled tag in order, default -- with the levels that hold prices", () => {
  const scopes = [
    { scope: "acme", rules: 0, enabled: 0, products: [] },
    { scope: "tag:premium", rules: 3, enabled: 2, products: [] },
    { scope: "*", rules: 1, enabled: 1, products: [] },
  ];
  const levels = priceLevels("acme", ["otp", "premium"], scopes, [{ name: "otp" }, { name: "premium" }], ["premium"]);
  assert.deepEqual(levels.map((l) => [l.kind, l.scope, l.prices]), [
    ["own", "acme", 0],
    ["tag", "tag:otp", 0],
    ["tag", "tag:premium", 2],
    ["default", "*", 1],
  ]);
  assert.equal(levels[1].inherited, true, "otp came from the parent");
  assert.equal(levels[2].inherited, false);
  assert.equal(levels[2].order, 2);
});

test("a filter with a tag condition the gateway would refuse is not saved", async () => {
  const { validateFilter } = await import("./filter-types.ts");
  const filter = (operator: string, value: string) =>
    ({ name: "vip", enabled: true, conditions: [{ field: "tag", operator, value, negate: false }] });
  assert.equal(validateFilter(filter("equals", "premium")), null);
  assert.match(validateFilter(filter("endsWith", "ium")) ?? "", /cannot test an account tag/);
});

// --- the owner's amendment: details, has all of, tags as filters --------------------------------


test("nine colours, the table's CHECK list, and anything else reads as gray", () => {
  assert.deepEqual([...TAG_COLORS], ["gray", "red", "orange", "yellow", "green", "teal", "blue", "purple", "pink"]);
  assert.equal(tagColorOf("teal"), "teal");
  assert.equal(tagColorOf(undefined), "gray", "a database without the column");
  assert.equal(tagColorOf("Teal"), "gray");
  assert.equal(tagDescriptionProblem("x".repeat(200)), null);
  assert.ok(tagDescriptionProblem("x".repeat(201)));
  assert.equal(tagTitle({ name: "otp", label: "One-time passwords", description: "2FA traffic" }), "One-time passwords — 2FA traffic");
  assert.equal(tagTitle({ name: "otp" }), "otp");
  assert.match(tagTitle({ name: "otp", enabled: false }), /switched off/);
});

test("has all of reads in words, and a negated list says so", () => {
  const c = (value: string, negate = false) => ({ operator: "equals", value, negate });
  assert.equal(describeTagCondition(c("otp,premium")), "the account has tags otp and premium");
  assert.equal(describeTagCondition(c("otp,premium,vip")), "the account has tags otp, premium and vip");
  assert.equal(describeTagCondition(c("otp,premium", true)), "the account does not have all of the tags otp, premium");
});

test("usage counts every name in an equals list, once per rule", () => {
  const usage = tagUsages(
    [
      { kind: "routing", owner: "main #1 → v1", operator: "equals", value: "otp,premium" },
      { kind: "routing", owner: "main #1 → v1", operator: "equals", value: "premium" },
      { kind: "filter", owner: "filter both", operator: "equals", value: "premium, otp" },
    ],
    []
  );
  assert.equal(usage.get("otp")!.routeRules, 1);
  assert.equal(usage.get("otp")!.filters, 1);
  assert.equal(usage.get("premium")!.routeRules, 1, "the same rule twice is one rule");
});

test("tags picked as filters: one tag equals <name> each, split out and put back, nothing else touched", () => {
  const cond = (field: string, operator: string, value: string, negate = false) => ({ field, operator, value, negate });
  const rule = [
    cond("to", "startsWith", "91"),
    cond("tag", "equals", "premium"),
    cond("tag", "equals", "otp,vip"),
    cond("tag", "equals", "otp", true),
    cond("tag", "equals", "premium"),
    cond("tag", "equals", "bulk"),
  ];
  assert.ok(isTagPick(cond("tag", "equals", "premium")));
  assert.ok(!isTagPick(cond("tag", "equals", "otp,vip")), "has all of is a condition, not a pick");
  assert.ok(!isTagPick(cond("tag", "equals", "otp", true)));
  const { picked, rest } = splitTagPicks(rule);
  assert.deepEqual(picked, ["premium", "bulk"]);
  assert.deepEqual(rest, [rule[0], rule[2], rule[3]]);
  assert.deepEqual(withTagPicks(rest, picked), [
    ...rest, cond("tag", "equals", "premium"), cond("tag", "equals", "bulk"),
  ], "two picks are two conditions: the account must have both");
  const tags = [{ name: "otp", enabled: true }, { name: "premium", enabled: true }, { name: "trial", enabled: false }];
  assert.deepEqual(tagPickOptions(tags, ["premium"]).map((t) => t.name), ["otp"], "enabled and not yet chosen");
  assert.deepEqual(unknownTagNames([cond("tag", "equals", "otp,gone"), cond("to", "equals", "x")], ["otp"]), ["gone"]);
});

test("an identical rule is found whatever order its conditions and filters are in", async () => {
  const { ruleMatchKey, scopeWarnings } = await import("./rate-types.ts");
  const cond = (field: string, operator: string, value: string, negate = false) => ({ field, operator, value, negate });
  const same = (a: ReturnType<typeof cond>[], b: ReturnType<typeof cond>[], fa: string[] = [], fb: string[] = []) =>
    ruleMatchKey(a, fa) === ruleMatchKey(b, fb);
  const to = cond("to", "startsWith", "91");
  //order of conditions and of filters
  assert.ok(same([to, cond("product", "equals", "x")], [cond("product", "equals", "x"), to]));
  assert.ok(same([to], [to], ["f1", "f2"], ["f2", "f1"]));
  //a tag list is a set of names
  assert.ok(same([cond("tag", "equals", "a,b")], [cond("tag", "equals", "b, a")]));
  assert.ok(same([cond("tag", "startsWithAny", "a,b", true)], [cond("tag", "startsWithAny", "b,a", true)]));
  //two picked tags mean has both, the same as has all of
  assert.ok(same([cond("tag", "equals", "a"), cond("tag", "equals", "b")], [cond("tag", "equals", "a,b")]));
  //negate changes the meaning
  assert.ok(!same([cond("tag", "equals", "a,b")], [cond("tag", "equals", "a,b", true)]));
  assert.ok(!same([to], [cond("to", "startsWith", "91", true)]));
  assert.ok(!same([cond("tag", "equals", "a,b", true)], [cond("tag", "equals", "a", true), cond("tag", "equals", "b", true)]),
    "lacks one of a, b is not lacks a and lacks b");
  assert.ok(!same([to], [to], ["f1"], ["f2"]));
  //and the price warning uses it
  const rule = (conditions: ReturnType<typeof cond>[]) =>
    ({ id: null, amount: "0.1", product: null, currency: null, label: null, enabled: true, conditions, filters: [] });
  const warnings = scopeWarnings({
    scope: "acme",
    rules: [rule([cond("tag", "equals", "a"), to]), rule([to, cond("tag", "equals", "a")]), rule([])],
  });
  assert.ok(warnings.some((w) => /Rule 2 matches exactly what an earlier rule matches/.test(w)));
});
