import { ServiceUnavailableError } from "@/lib/control-route";
import { isConfigWritable } from "@/lib/config-db";
import type { CdrFilters } from "@/lib/cdr-request";
import { accountsWithTag, tagsAvailable } from "@/lib/tags";

/**
 * Turns the Messages page's tag filter into the account set the query layer already knows how to
 * apply (`accountIn`, `s.account_id = ANY($n)` -- the customer portal's boundary). The accounts are
 * read from `app_account_tag` on the configuration side, so the reading role needs no grant on it,
 * and the set is the tag's accounts now: an export keeps the set it was requested with.
 *
 * <p>An existing `accountIn` is narrowed, never widened.
 */
export async function withTagAccounts(filters: CdrFilters): Promise<CdrFilters> {
  if (!filters.tag) {
    return filters;
  }
  if (!isConfigWritable() || !(await tagsAvailable())) {
    throw new ServiceUnavailableError("The tag filter needs gateway 0.17.0 and this panel's configuration database.");
  }
  const tagged = await accountsWithTag(filters.tag);
  const accountIn = filters.accountIn ? filters.accountIn.filter((a) => tagged.includes(a)) : tagged;
  return { ...filters, accountIn };
}
