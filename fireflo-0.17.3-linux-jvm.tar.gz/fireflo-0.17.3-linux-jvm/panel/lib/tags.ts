import type { PoolClient } from "pg";
import { configQuery, inTransaction } from "@/lib/config-db";
import { auditConfigChange } from "@/lib/config-audit";
import { ConfigRefusal } from "@/lib/config-guard";
import {
  type AccountTags,
  type Tag,
  type TagConditionRow,
  type TagInput,
  NO_USAGE,
  TAG_COLORS,
  tagColorOf,
  tagDescriptionProblem,
  effectiveTags,
  inUseMessage,
  isUsed,
  reorderProblem,
  seqPlan,
  tagLabelProblem,
  tagNameProblem,
  tagUsages,
} from "@/lib/tag-types";

/**
 * Account tags, read and written: `app_tag` and `app_account_tag` (gateway 0.17.0, V1.133.0).
 *
 * <p>Server-only: importing this pulls `pg`. The shapes and the pure parts live in `tag-types.ts`.
 *
 * <p>Against an older database the tables are absent; {@link tagsAvailable} answers false and every
 * caller shows "needs gateway 0.17.0" instead of a missing-table error -- the same way the
 * Preprocessors page treats a database before V1.62.0.
 */

type Query = <T extends Record<string, unknown>>(sql: string, params?: unknown[]) => Promise<T[]>;

const pooled: Query = (sql, params) => configQuery(sql, params ?? []);

/** Both tables exist. */
export async function tagsAvailable(): Promise<boolean> {
  const rows = await configQuery<{ ok: boolean }>(
    `SELECT to_regclass('public.app_tag') IS NOT NULL
        AND to_regclass('public.app_account_tag') IS NOT NULL AS ok`
  );
  return !!rows[0]?.ok;
}

/**
 * Whether `app_tag` has `description` and `color` (the owner's amendment to V1.133.0). A database
 * made from the first cut of that migration -- a developer's, never a release -- lacks them; reads
 * then answer '' and gray, and writes leave them out, rather than failing.
 */
export async function tagDetailsAvailable(run: Query = pooled): Promise<boolean> {
  const rows = await run<{ n: number }>(
    `SELECT count(*)::int AS n FROM information_schema.columns
      WHERE table_schema = 'public' AND table_name = 'app_tag' AND column_name IN ('description', 'color')`
  );
  return Number(rows[0]?.n ?? 0) === 2;
}

/** The two detail columns as a select list, or their fallbacks when the columns are absent. */
function detailColumns(have: boolean, alias = "t"): string {
  return have ? `${alias}.description, ${alias}.color` : "''::text AS description, 'gray'::text AS color";
}

interface TagRow {
  name: string;
  label: string;
  description: string;
  color: string;
  seq: number;
  enabled: boolean;
  updated_at: Date | null;
  accounts: number;
}

/**
 * Every condition with field `tag` in the routing, pricing and filter condition tables, and the
 * rule count of every `tag:` price list. Shaped per tag by `tagUsages`.
 *
 * <p>Read with whichever runner is passed, so the delete can make the same read inside its
 * transaction.
 */
async function readUsage(run: Query) {
  const [conditions, lists] = await Promise.all([
    run<{ kind: TagConditionRow["kind"]; owner: string; operator: string; value: string }>(
      `SELECT 'routing' AS kind,
              r.table_name || ' #' || (r.seq + 1) || ' → '
                || COALESCE(r.target_table, r.target_group, r.target_worker, r.target, '?') AS owner,
              c.operator, c.value
         FROM app_route_rule_condition c JOIN app_route_rule r ON r.id = c.rule_id
        WHERE c.field = 'tag'
       UNION ALL
       SELECT 'pricing',
              'scope ' || r.scope || ' #' || (r.seq + 1)
                || CASE WHEN r.product IS NOT NULL AND r.product <> '' THEN ' · ' || r.product ELSE '' END,
              c.operator, c.value
         FROM app_rate_rule_condition c JOIN app_rate_rule r ON r.id = c.rule_id
        WHERE c.field = 'tag'
       UNION ALL
       SELECT 'filter', 'filter ' || c.filter_name, c.operator, c.value
         FROM app_filter_condition c
        WHERE c.field = 'tag'`
    ),
    run<{ scope: string; rules: number }>(
      `SELECT scope, count(*)::int AS rules
         FROM app_rate_rule
        WHERE scope LIKE 'tag:%'
        GROUP BY scope`
    ),
  ]);
  return tagUsages(conditions, lists);
}

function viaClient(client: PoolClient): Query {
  return async (sql, params) => (await client.query(sql, params ?? [])).rows;
}

/** Every tag in order, with its account count and where it is used. */
export async function listTags(): Promise<Tag[]> {
  const details = await tagDetailsAvailable();
  const [rows, usage] = await Promise.all([
    configQuery<TagRow>(
      `SELECT t.name, t.label, ${detailColumns(details)}, t.seq, t.enabled, t.updated_at, COALESCE(a.n, 0)::int AS accounts
         FROM app_tag t
         LEFT JOIN (SELECT tag, count(*) AS n FROM app_account_tag GROUP BY tag) a ON a.tag = t.name
        ORDER BY t.seq, t.name`
    ),
    readUsage(pooled),
  ]);
  return rows.map((r) => ({
    name: r.name,
    label: r.label ?? "",
    description: r.description ?? "",
    color: tagColorOf(r.color),
    seq: r.seq,
    enabled: r.enabled,
    accounts: Number(r.accounts),
    usage: usage.get(r.name) ?? NO_USAGE,
    updatedAt: r.updated_at ? new Date(r.updated_at).toISOString() : null,
  }));
}

/** Name, label, description, colour, order and state, for pickers and chips: no usage reads. */
export async function listTagNames(): Promise<
  { name: string; label: string; description: string; color: string; seq: number; enabled: boolean }[]
> {
  const details = await tagDetailsAvailable();
  const rows = await configQuery<{ name: string; label: string; description: string; color: string; seq: number; enabled: boolean }>(
    `SELECT t.name, t.label, ${detailColumns(details)}, t.seq, t.enabled FROM app_tag t ORDER BY t.seq, t.name`
  );
  return rows.map((r) => ({ ...r, description: r.description ?? "", color: tagColorOf(r.color) }));
}

/** Why a colour cannot be stored, or null. The table's CHECK is the same list. */
function colorProblem(color: string | undefined): string | null {
  return color === undefined || (TAG_COLORS as readonly string[]).includes(color)
    ? null
    : `'${color}' is not one of the tag colours (${TAG_COLORS.join(", ")}).`;
}

/** Adds a tag at the end of the order. */
export async function createTag(input: TagInput): Promise<void> {
  const name = input.name;
  const label = input.label.trim();
  const description = (input.description ?? "").trim();
  const color = input.color ?? "gray";
  const bad = tagNameProblem(name) ?? tagLabelProblem(label) ?? tagDescriptionProblem(description) ?? colorProblem(color);
  if (bad) {
    throw new ConfigRefusal(bad);
  }
  const details = await tagDetailsAvailable();
  const rows = await configQuery<{ name: string; seq: number }>(
    details
      ? `INSERT INTO app_tag (name, label, description, color, seq, enabled, updated_at)
         VALUES ($1, $2, $3, $4, (SELECT COALESCE(max(seq), 0) + 1 FROM app_tag), true, now())
         ON CONFLICT (name) DO NOTHING
         RETURNING name, seq`
      : `INSERT INTO app_tag (name, label, seq, enabled, updated_at)
         VALUES ($1, $2, (SELECT COALESCE(max(seq), 0) + 1 FROM app_tag), true, now())
         ON CONFLICT (name) DO NOTHING
         RETURNING name, seq`,
    details ? [name, label, description, color] : [name, label]
  );
  if (!rows.length) {
    throw new ConfigRefusal(`A tag called '${name}' already exists.`);
  }
  await auditConfigChange({
    domain: "tag", name, action: "create",
    after: { label, ...(details ? { description, color } : {}), seq: rows[0].seq, enabled: true },
  });
}

/** Changes a tag's label, description, colour and whether it is on. The name never changes. */
export async function updateTag(
  name: string,
  patch: { label?: string; description?: string; color?: string; enabled?: boolean }
): Promise<boolean> {
  const label = patch.label?.trim();
  const description = patch.description?.trim();
  const bad = (label !== undefined ? tagLabelProblem(label) : null)
    ?? (description !== undefined ? tagDescriptionProblem(description) : null)
    ?? colorProblem(patch.color);
  if (bad) {
    throw new ConfigRefusal(bad);
  }
  const result = await inTransaction(async (client) => {
    const run = viaClient(client);
    const details = await tagDetailsAvailable(run);
    const was = await client.query<{ label: string; description: string; color: string; enabled: boolean }>(
      `SELECT t.label, ${detailColumns(details)}, t.enabled FROM app_tag t WHERE t.name = $1 FOR UPDATE`,
      [name]
    );
    if (!was.rows.length) {
      return null;
    }
    const before = was.rows[0];
    const next = {
      label: label ?? before.label,
      description: description ?? before.description,
      color: patch.color ?? before.color,
      enabled: patch.enabled ?? before.enabled,
    };
    if (details) {
      await client.query(
        "UPDATE app_tag SET label = $2, description = $3, color = $4, enabled = $5, updated_at = now() WHERE name = $1",
        [name, next.label, next.description, next.color, next.enabled]
      );
    } else {
      //no detail columns on this database: what can be stored is
      await client.query(
        "UPDATE app_tag SET label = $2, enabled = $3, updated_at = now() WHERE name = $1",
        [name, next.label, next.enabled]
      );
    }
    return { before, after: details ? next : { label: next.label, enabled: next.enabled } };
  });
  if (!result) {
    return false;
  }
  const onlySwitch = result.before.enabled !== result.after.enabled
    && result.before.label === result.after.label
    && (!("color" in result.after) || (result.before.color === result.after.color && result.before.description === result.after.description));
  const action = onlySwitch ? (result.after.enabled ? "enable" : "disable") : "update";
  await auditConfigChange({ domain: "tag", name, action, before: result.before, after: result.after });
  return true;
}

/**
 * Writes the order: `seq` 1, 2, 3… for the names as given. The list must name every tag once
 * (`reorderProblem`), checked against the rows locked in the same transaction.
 */
export async function reorderTags(order: readonly string[]): Promise<void> {
  const before = await inTransaction(async (client) => {
    const existing = await client.query<{ name: string }>("SELECT name FROM app_tag ORDER BY seq, name FOR UPDATE");
    const names = existing.rows.map((r) => r.name);
    const bad = reorderProblem(order, names);
    if (bad) {
      throw new ConfigRefusal(bad);
    }
    const plan = seqPlan(order);
    await client.query(
      `UPDATE app_tag t SET seq = v.seq, updated_at = now()
         FROM unnest($1::text[], $2::int[]) AS v(name, seq)
        WHERE t.name = v.name AND t.seq IS DISTINCT FROM v.seq`,
      [plan.map((p) => p.name), plan.map((p) => p.seq)]
    );
    return names;
  });
  await auditConfigChange({ domain: "tag", name: "order", action: "reorder", before: { order: before }, after: { order: [...order] } });
}

/** Thrown when a rule, filter or price list still names the tag. The message says which. */
export class TagInUse extends Error {
  constructor(readonly tagName: string, message: string) {
    super(message);
    this.name = "TagInUse";
  }
}

/**
 * Deletes a tag nothing names. Its assignments go with it (`ON DELETE CASCADE`).
 *
 * <p>The schema would let a used tag go; the panel refuses, because a routing rule, price rule or
 * filter naming a tag that no longer exists silently stops matching. The usage read runs inside the
 * transaction that deletes, after locking the row.
 *
 * @returns the number of accounts it was taken off, or null when there was no such tag
 */
export async function deleteTag(name: string): Promise<number | null> {
  const removed = await inTransaction(async (client) => {
    const row = await client.query<{ label: string; enabled: boolean }>(
      "SELECT label, enabled FROM app_tag WHERE name = $1 FOR UPDATE",
      [name]
    );
    if (!row.rows.length) {
      return null;
    }
    const usage = (await readUsage(viaClient(client))).get(name);
    if (usage && isUsed(usage)) {
      throw new TagInUse(name, inUseMessage(name, usage));
    }
    const accounts = await client.query<{ n: number }>(
      "SELECT count(*)::int AS n FROM app_account_tag WHERE tag = $1",
      [name]
    );
    await client.query("DELETE FROM app_tag WHERE name = $1", [name]);
    return { before: row.rows[0], accounts: accounts.rows[0]?.n ?? 0 };
  });
  if (!removed) {
    return null;
  }
  await auditConfigChange({
    domain: "tag", name, action: "delete", before: { ...removed.before, accounts: removed.accounts },
  });
  return removed.accounts;
}

/**
 * One account's tags: its own, what it carries from a units parent, and how many units
 * sub-accounts carry its tags. One account, so reading `account_balance` here is fine.
 */
export async function accountTags(accountId: string): Promise<AccountTags> {
  if (!(await tagsAvailable())) {
    return { available: false, own: [], inherited: null, effective: [], inheritingChildren: 0 };
  }
  const [order, own, head, kids] = await Promise.all([
    configQuery<{ name: string; enabled: boolean }>("SELECT name, enabled FROM app_tag ORDER BY seq, name"),
    configQuery<{ tag: string }>(
      `SELECT at.tag FROM app_account_tag at JOIN app_tag t ON t.name = at.tag
        WHERE at.account_id = $1 ORDER BY t.seq, t.name`,
      [accountId]
    ),
    //a units sub-account carries its parent's tags; any other child does not
    configQuery<{ parent: string | null; units: boolean }>(
      `SELECT a.parent_account_id AS parent, (b.billing_mode = 'UNITS') AS units
         FROM app_account a LEFT JOIN account_balance b ON b.account_id = a.id
        WHERE a.id = $1`,
      [accountId]
    ),
    configQuery<{ n: number }>(
      `SELECT count(*)::int AS n
         FROM app_account a JOIN account_balance b ON b.account_id = a.id
        WHERE a.parent_account_id = $1 AND b.billing_mode = 'UNITS'`,
      [accountId]
    ),
  ]);
  const ownTags = own.map((r) => r.tag);
  let inherited: AccountTags["inherited"] = null;
  const parent = head[0]?.units ? head[0].parent : null;
  if (parent) {
    const enabled = new Set(order.filter((t) => t.enabled).map((t) => t.name));
    const rows = await configQuery<{ tag: string }>(
      `SELECT at.tag FROM app_account_tag at JOIN app_tag t ON t.name = at.tag
        WHERE at.account_id = $1 ORDER BY t.seq, t.name`,
      [parent]
    );
    inherited = { parent, tags: rows.map((r) => r.tag).filter((t) => enabled.has(t)) };
  }
  return {
    available: true,
    own: ownTags,
    inherited,
    effective: effectiveTags(ownTags, inherited?.tags ?? [], order),
    inheritingChildren: Number(kids[0]?.n ?? 0),
  };
}

/**
 * Adds and removes one account's own tags, inside the caller's transaction (the account save).
 * Unknown names are refused before anything is written.
 */
export async function writeAccountTags(
  client: PoolClient,
  accountId: string,
  add: readonly string[],
  remove: readonly string[]
): Promise<void> {
  if (!add.length && !remove.length) {
    return;
  }
  for (const t of [...add, ...remove]) {
    const bad = tagNameProblem(t);
    if (bad) {
      throw new ConfigRefusal(`'${t}': ${bad}`);
    }
  }
  if (add.length) {
    const known = await client.query<{ name: string }>("SELECT name FROM app_tag WHERE name = ANY($1::text[])", [add]);
    const missing = add.filter((t) => !known.rows.some((r) => r.name === t));
    if (missing.length) {
      throw new ConfigRefusal(`No tag called ${missing.map((t) => `'${t}'`).join(", ")}. Add it on the Tags page first.`);
    }
    await client.query(
      `INSERT INTO app_account_tag (account_id, tag)
       SELECT $1, t FROM unnest($2::text[]) AS t
       ON CONFLICT DO NOTHING`,
      [accountId, add]
    );
  }
  if (remove.length) {
    await client.query("DELETE FROM app_account_tag WHERE account_id = $1 AND tag = ANY($2::text[])", [accountId, remove]);
  }
}

/** The accounts that carry a tag themselves, now. For the report filters. */
export async function accountsWithTag(tag: string): Promise<string[]> {
  const rows = await configQuery<{ account_id: string }>(
    "SELECT account_id FROM app_account_tag WHERE tag = $1 ORDER BY account_id",
    [tag]
  );
  return rows.map((r) => r.account_id);
}
