/**
 * Account tags (gateway 0.17.0, migration V1.133.0): the shapes, the name rule, and the pure
 * bookkeeping behind the Tags page. No database import, so client components and node tests can
 * use it.
 *
 * <h2>What a tag is to the gateway</h2>
 *
 * <p>A name in `app_tag`, put on accounts in `app_account_tag`. Routing rules, price rules and
 * filters can test it with the condition field `tag`, and a price list can be kept for it under
 * the rate scope `tag:<name>`. An account's sell price is looked up in its own scope, then in each
 * of its enabled tags' scopes by (`seq`, `name`), then in the default `*`. A units sub-account
 * carries its parent's tags as well as its own. A disabled tag matches nothing and prices nothing.
 * The gateway adopts changes to both tables at its next configuration poll, within 30 seconds by
 * default.
 *
 * <p>The schema lets a tag be deleted (assignments cascade). The panel refuses while any rule
 * condition, filter condition or rate scope names it, because a rule naming a missing tag stops
 * matching without anything saying so.
 */

/** `app_tag.name`'s CHECK, character for character: lower case, digits, `_` and `-`, at most 40. */
export const TAG_NAME_PATTERN = /^[a-z0-9][a-z0-9_-]{0,39}$/;

/** The rate scope prefix that holds a tag's price list. */
export const TAG_SCOPE_PREFIX = "tag:";

/** What the Tags page and pickers say on a database without the tables. */
export const TAGS_NEED_GATEWAY = "Account tags need gateway 0.17.0. This database has no tag tables yet.";

/** When a change reaches the gateway, said the same way everywhere. */
export const TAGS_TAKE_EFFECT = "A change takes effect within 30 seconds.";

/**
 * The colours a tag may take: `app_tag.color`'s CHECK, in the order the picker shows them. Drawn
 * from theme tokens (`--color-tag-<colour>` and `-soft`, light and dark), never from raw values,
 * and always beside the name: colour is a hint, never the only way to tell two tags apart.
 */
export const TAG_COLORS = ["gray", "red", "orange", "yellow", "green", "teal", "blue", "purple", "pink"] as const;

export type TagColor = (typeof TAG_COLORS)[number];

/** The words for each colour, for the picker's labels and screen readers. */
export const TAG_COLOR_LABELS: Record<TagColor, string> = {
  gray: "Gray", red: "Red", orange: "Orange", yellow: "Yellow", green: "Green",
  teal: "Teal", blue: "Blue", purple: "Purple", pink: "Pink",
};

/** A stored colour, or gray for anything else (a missing column, an unknown value). */
export function tagColorOf(value: unknown): TagColor {
  return (TAG_COLORS as readonly string[]).includes(value as string) ? (value as TagColor) : "gray";
}

/** `app_tag.description`'s CHECK: at most 200 characters. */
export const TAG_DESCRIPTION_MAX = 200;

export function tagDescriptionProblem(description: string): string | null {
  return description.length > TAG_DESCRIPTION_MAX ? `A description is at most ${TAG_DESCRIPTION_MAX} characters.` : null;
}

/** A chip's tooltip: label and description, and "off" for a switched-off tag. */
export function tagTitle(t: { name: string; label?: string; description?: string; enabled?: boolean }): string {
  const parts = [t.label?.trim(), t.description?.trim()].filter(Boolean);
  const text = parts.length ? parts.join(" — ") : t.name;
  return t.enabled === false ? `${text} (switched off: matches nothing)` : text;
}

export interface Tag {
  name: string;
  /** '' when unset. */
  label: string;
  /** '' when unset, or on a database whose `app_tag` predates the column. */
  description: string;
  /** Gray when unset, or on a database whose `app_tag` predates the column. */
  color: TagColor;
  /** Lower first. Decides whose price wins when an account has several tags with price lists. */
  seq: number;
  enabled: boolean;
  /** Accounts that carry the tag themselves (not inherited). */
  accounts: number;
  usage: TagUsage;
  updatedAt: string | null;
}

/** Everything that names one tag, by kind, with a label per item for the "used in" list. */
export interface TagUsage {
  routeRules: number;
  priceRules: number;
  filters: number;
  /** Rules in the tag's own price list, `tag:<name>`. */
  prices: number;
  items: { kind: "routing" | "pricing" | "filter" | "prices"; label: string }[];
}

export const NO_USAGE: TagUsage = { routeRules: 0, priceRules: 0, filters: 0, prices: 0, items: [] };

export interface TagInput {
  name: string;
  label: string;
  description?: string;
  color?: string;
}

/** The tags on one account, for its Settings tab. */
export interface AccountTags {
  available: boolean;
  /** Its own assignments, enabled or not, ordered as the Tags list orders them. */
  own: string[];
  /** For a units sub-account: the parent and the parent's enabled tags it carries too. */
  inherited: { parent: string; tags: string[] } | null;
  /** What rules and prices see: own plus inherited, enabled only, in order, no duplicates. */
  effective: string[];
  /** Units sub-accounts of this account, which carry its tags. */
  inheritingChildren: number;
}

/** Why a tag name cannot be used, or null. */
export function tagNameProblem(name: string): string | null {
  if (!name) {
    return "A tag needs a name.";
  }
  if (name !== name.trim()) {
    return "A tag name cannot start or end with a space.";
  }
  if (name.length > 40) {
    return "A tag name is at most 40 characters.";
  }
  if (!TAG_NAME_PATTERN.test(name)) {
    return "Use lower-case letters, digits, '-' and '_', starting with a letter or digit.";
  }
  return null;
}

/** Why a label cannot be saved, or null. The table refuses a leading or trailing space. */
export function tagLabelProblem(label: string): string | null {
  if (label.length > 200) {
    return "A label is at most 200 characters.";
  }
  return null;
}

/** The scope a tag's price list is kept under. */
export function tagScope(name: string): string {
  return `${TAG_SCOPE_PREFIX}${name}`;
}

/** The tag a scope prices, or null for any other scope. */
export function tagOfScope(scope: string): string | null {
  return scope.startsWith(TAG_SCOPE_PREFIX) ? scope.slice(TAG_SCOPE_PREFIX.length) : null;
}

/**
 * The tag names one condition value names: `equals` (has all of) and `startsWithAny` (has any of)
 * a comma list -- one name is the plain "has tag X" --
 * `isNull` none (it tests for no tag at all, so it does not depend on any one tag).
 */
export function tagsNamedBy(operator: string, value: string): string[] {
  //`equals` takes a list too: "has all of" (gateway 0.17.0, owner's amendment)
  if (operator === "equals" || operator === "startsWithAny") {
    return [...new Set(value.split(",").map((v) => v.trim()).filter(Boolean))];
  }
  return [];
}

/** One `tag` condition as read from a condition table, with the rule or filter it belongs to. */
export interface TagConditionRow {
  kind: "routing" | "pricing" | "filter";
  /** The owner as a person names it: `main #3 → vendor-a`, `scope acme #2`, a filter's name. */
  owner: string;
  operator: string;
  value: string;
}

/**
 * Shapes the raw reads into usage per tag.
 *
 * <p>A rule counts once per tag however many of its conditions name it; so does a filter. A price
 * list is the count of rules on `tag:<name>`.
 *
 * @param conditions every condition with field `tag`, from the three condition tables
 * @param priceLists rule counts per rate scope starting `tag:`
 */
export function tagUsages(
  conditions: readonly TagConditionRow[],
  priceLists: readonly { scope: string; rules: number }[]
): Map<string, TagUsage> {
  const out = new Map<string, TagUsage>();
  const seen = new Set<string>();
  const get = (tag: string) => {
    let u = out.get(tag);
    if (!u) {
      u = { routeRules: 0, priceRules: 0, filters: 0, prices: 0, items: [] };
      out.set(tag, u);
    }
    return u;
  };
  for (const c of conditions) {
    for (const tag of tagsNamedBy(c.operator, c.value)) {
      const key = `${tag}\u0000${c.kind}\u0000${c.owner}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const u = get(tag);
      if (c.kind === "routing") u.routeRules++;
      else if (c.kind === "pricing") u.priceRules++;
      else u.filters++;
      u.items.push({ kind: c.kind, label: c.owner });
    }
  }
  for (const p of priceLists) {
    const tag = tagOfScope(p.scope);
    if (!tag || p.rules <= 0) continue;
    const u = get(tag);
    u.prices += p.rules;
    u.items.push({ kind: "prices", label: `price list ${p.scope} (${p.rules} ${p.rules === 1 ? "price" : "prices"})` });
  }
  return out;
}

/** Whether anything names the tag, which is what refuses a delete. */
export function isUsed(u: TagUsage): boolean {
  return u.routeRules + u.priceRules + u.filters + u.prices > 0;
}

/** "2 route rules · 1 filter · 1 price list", or "not used". */
export function usageLine(u: TagUsage): string {
  const n = (count: number, one: string, many: string) => (count ? `${count} ${count === 1 ? one : many}` : null);
  const parts = [
    n(u.routeRules, "route rule", "route rules"),
    n(u.priceRules, "price rule", "price rules"),
    n(u.filters, "filter", "filters"),
    u.prices ? "1 price list" : null,
  ].filter(Boolean);
  return parts.length ? parts.join(" · ") : "not used";
}

/** The sentence a refused delete answers with: where the tag is used, so it can be detached. */
export function inUseMessage(name: string, u: TagUsage): string {
  const where = u.items.slice(0, 8).map((i) => i.label).join("; ");
  const more = u.items.length > 8 ? `; and ${u.items.length - 8} more` : "";
  return `'${name}' is used by ${usageLine(u)} (${where}${more}). Remove it from those first, or switch the tag off instead.`;
}

/** The order with one tag moved up (-1) or down (+1). Unchanged at either end. */
export function moveTag(order: readonly string[], name: string, by: -1 | 1): string[] {
  const at = order.indexOf(name);
  const to = at + by;
  if (at < 0 || to < 0 || to >= order.length) {
    return [...order];
  }
  const next = [...order];
  [next[at], next[to]] = [next[to], next[at]];
  return next;
}

/**
 * Why a requested order cannot be written, or null: it must name every tag exactly once. A partial
 * list would leave the rest at their old numbers, interleaved with the new ones.
 */
export function reorderProblem(requested: readonly string[], existing: readonly string[]): string | null {
  const want = new Set(requested);
  if (want.size !== requested.length) {
    return "The order names a tag twice.";
  }
  if (want.size !== existing.length || existing.some((t) => !want.has(t))) {
    return "The tag list changed while you were ordering it. Reload and try again.";
  }
  return null;
}

/** The `seq` each tag is written with: 1, 2, 3… in the order given. */
export function seqPlan(order: readonly string[]): { name: string; seq: number }[] {
  return order.map((name, i) => ({ name, seq: i + 1 }));
}

/**
 * What a units sub-account carries: its own enabled tags plus its parent's, ordered by the tag list,
 * no duplicates. The same reading the gateway's `effectiveTags` gives.
 *
 * @param order every tag, in (`seq`, `name`) order, with whether it is enabled
 */
export function effectiveTags(
  own: readonly string[],
  inherited: readonly string[],
  order: readonly { name: string; enabled: boolean }[]
): string[] {
  const has = new Set([...own, ...inherited]);
  return order.filter((t) => t.enabled && has.has(t.name)).map((t) => t.name);
}

/** The add and remove lists that turn `before` into `after`. Never a replace. */
export function tagDiff(before: readonly string[], after: readonly string[]): { add: string[]; remove: string[] } {
  const was = new Set(before);
  const now = new Set(after);
  return {
    add: [...now].filter((t) => !was.has(t)),
    remove: [...was].filter((t) => !now.has(t)),
  };
}

// --- tags picked as filters ----------------------------------------------------------------------

/** One condition, as the rule editors hold it. Structural, so this module needs no import. */
interface Cond {
  field: string;
  operator: string;
  value: string;
  negate: boolean;
}

/** `tag equals <one name>`, not negated: what choosing a tag in the filter picker writes. */
export function isTagPick(c: Cond): boolean {
  return c.field.trim() === "tag" && c.operator === "equals" && !c.negate
    && c.value.trim() !== "" && !c.value.includes(",");
}

/**
 * A rule's conditions split into the tags picked as filters (each `tag equals <name>`, shown as a
 * chip among the rule's filters) and everything else (the guided rows or the advanced editor).
 * A repeated pick is kept once.
 */
export function splitTagPicks<T extends Cond>(conditions: readonly T[]): { picked: string[]; rest: T[] } {
  const picked: string[] = [];
  const rest: T[] = [];
  for (const c of conditions) {
    if (isTagPick(c)) {
      const name = c.value.trim();
      if (!picked.includes(name)) picked.push(name);
    } else {
      rest.push(c);
    }
  }
  return { picked, rest };
}

/** The rule's conditions back: the rest, then one `tag equals <name>` per picked tag (= has all). */
export function withTagPicks(rest: readonly Cond[], picked: readonly string[]): Cond[] {
  return [...rest, ...picked.map((name) => ({ field: "tag", operator: "equals", value: name, negate: false }))];
}

/** The tags the picker offers: enabled ones not already picked, in the Tags list's order. */
export function tagPickOptions<T extends { name: string; enabled: boolean }>(tags: readonly T[], picked: readonly string[]): T[] {
  return tags.filter((t) => t.enabled && !picked.includes(t.name));
}

/** Tag names a condition list mentions that the tag list does not have, for a warning. */
export function unknownTagNames(conditions: readonly Cond[], known: readonly string[]): string[] {
  const have = new Set(known);
  const out = new Set<string>();
  for (const c of conditions) {
    if (c.field.trim() !== "tag") continue;
    for (const n of tagsNamedBy(c.operator, c.value)) {
      if (!have.has(n)) out.add(n);
    }
  }
  return [...out];
}
