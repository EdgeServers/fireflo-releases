import { test } from "node:test";
import assert from "node:assert/strict";
import { GatewayError, PANEL_CODES } from "./gateway-graphql-core.ts";
import type { LiveBucket, LiveFailure, LiveSeriesSum } from "./gateway-live-series.ts";
import { createLiveReaders, isSourced, NoDataSourceError, type LiveDeps, type SqlDeps } from "./stats-live.ts";

/**
 * The reader choice (`stats-live.ts`): which source answers, and each way back to the database.
 * The gateway and every SQL read are fakes that record what they were asked.
 */

const NOW = new Date("2026-10-30T12:02:00Z");

function bucket(at: string, n: Partial<LiveBucket> = {}): LiveBucket {
  return {
    bucket: at,
    keys: { account: "acme", login: "l1", listener: "smppserver.main", product: "p", vendor: "v1" },
    submitted: 0, refused: 0, refusedBy: [], priceSum: 0, costSum: 0, attempts: null, sent: 0, vendorRefused: 0, delivered: 0,
    failed: 0, expired: 0, pending: 0, backfilled: false,
    ...n,
  };
}

/** A gateway with traffic at 10:00 and 11:00, started at 09:20, backfilled unless told otherwise. */
function sum(over: Partial<LiveSeriesSum> = {}): LiveSeriesSum {
  return {
    nodes: ["n1"],
    partial: [],
    liveSince: "2026-10-30T09:20:00.000Z",
    backfilledThrough: "2026-10-30T09:00:00.000Z",
    deadlineHours: 24,
    buckets: [
      bucket("2026-10-30T09:00:00Z", { submitted: 100, delivered: 100, sent: 100, priceSum: 1_000 }),
      bucket("2026-10-30T10:00:00Z", { submitted: 10, delivered: 9, failed: 1, sent: 10, priceSum: 100, costSum: 40 }),
      bucket("2026-10-30T11:00:00Z", { submitted: 5, delivered: 2, pending: 3, sent: 5, priceSum: 50, costSum: 20 }),
    ],
    ...over,
  };
}

interface Rig {
  live: LiveDeps;
  sql: SqlDeps;
  calls: string[];
  logs: string[];
}

function rig(o: {
  capability?: () => Promise<boolean>;
  series?: () => Promise<LiveSeriesSum>;
  db?: boolean;
  sqlDelayMs?: number;
  failures?: () => Promise<{ since: string; rows: [] }>;
  liveFailures?: () => Promise<{ rows: LiveFailure[]; partial: string[] }>;
} = {}): Rig {
  const calls: string[] = [];
  const logs: string[] = [];
  const at = (name: string, until?: Date) => calls.push(until ? `${name} until ${until.toISOString()}` : name);
  const slow = async <T>(v: T): Promise<T> => {
    if (o.sqlDelayMs) await new Promise((r) => setTimeout(r, o.sqlDelayMs));
    return v;
  };
  const live: LiveDeps = {
    capability: o.capability ?? (async () => true),
    series: async (range, grain, groupBy) => {
      calls.push(`series ${range} ${grain} [${groupBy.join(",")}]`);
      return (o.series ?? (async () => sum()))();
    },
    receiptQuality: async () => ({
      rows: [{ node: "n1", vendor: "v1", sent: 15, accepted: 15, refused: 0, reported: 12, delivered: 11, failed: 1, expired: 0, open: 3,
        medianToOutcome: 1.5, p90ToOutcome: 4 }],
      partial: ["n2"],
    }),
    failures: async () => {
      calls.push("live failures");
      return (o.liveFailures ?? (async () => ({
        rows: [{ node: "", account: "acme", vendor: "v1", finalState: "FAILED", dlrState: 2, errCode: "0x0b", vendorErrCode: "11",
          messages: 1, lastSeen: "2026-10-30T10:12:00.000Z" }],
        partial: ["n3"],
      })))();
    },
    dbConfigured: () => o.db ?? true,
    now: () => NOW,
    log: (line) => logs.push(line),
    spliceTimeoutMs: 50,
  };
  const sql: SqlDeps = {
    traffic: async (_r, { until }) => {
      at("sql traffic", until);
      return slow([{ bucket: "2026-10-30T09:00:00Z", submitted: 7, delivered: 7, failed: 0, expired: 0, pending: 0 }]);
    },
    revenue: async (_r, { until }) => {
      at("sql revenue", until);
      return slow([{ accountId: "acme", product: "p", messages: 7, revenue: 70, cost: 7, margin: 63, pendingRevenue: 0 }]);
    },
    revenueSeries: async (_r, { until }) => {
      at("sql revenue-series", until);
      return slow([]);
    },
    vendors: async (_r, { until }) => {
      at("sql vendors", until);
      return slow([{ vendor: "v1", attempts: 7, messages: 7, delivered: 7, failed: 0, pending: 0, cost: 1, deliveryRate: 1 }]);
    },
    accounts: async (_r, _p, { until }) => {
      at("sql accounts", until);
      return slow({
        creditEnforced: true,
        accounts: [
          { accountId: "acme", systemId: "l1", product: "p", messages: 7, delivered: 7, failed: 0, pending: 0, billed: 70, cost: 7,
            deliveryRate: 1, lastSeen: "2026-10-30T09:59:00Z", balance: 5, currency: "AUD", idle: false },
          { accountId: "quiet", systemId: "q1", product: null, messages: 0, delivered: 0, failed: 0, pending: 0, billed: 0, cost: 0,
            deliveryRate: null, lastSeen: null, balance: null, currency: null, idle: true },
        ],
      });
    },
    serverTraffic: async (_r, _p, { until }) => {
      at("sql server-traffic", until);
      return slow({ range: "24h" as const, rows: [], totals: { messages: 0, delivered: 0, reported: 0 } });
    },
    receipts: async () => {
      at("sql receipts");
      return [];
    },
    usageGrid: async () => {
      at("sql usage-grid");
      return { grain: "day" as const, since: "", until: "", page: 0, pageSize: 50, totalRows: 0, rows: [], series: [], logins: { daily: true, hourly: true } };
    },
    failures: o.failures ?? (async () => {
      at("sql failures");
      return { since: "2026-10-30T00:00:00.000Z", rows: [] };
    }),
    configured: async () => {
      at("config credentials");
      return [{ accountId: "quiet", systemId: "q1", product: null }];
    },
    balances: async () => {
      at("config balances");
      return new Map([["acme", { balance: 9_999, currency: "AUD" }]]);
    },
  };
  return { live, sql, calls, logs };
}

test("7d and 30d are the database's: the gateway is not asked", async () => {
  const r = rig({ capability: async () => assert.fail("asked") });
  const got = await createLiveReaders(r.live, r.sql).traffic("7d");
  assert.equal(got.source, "database");
  assert.deepEqual(r.calls, ["sql traffic"]);
});

test("a gateway without live_series is the database's", async () => {
  const r = rig({ capability: async () => false });
  const got = await createLiveReaders(r.live, r.sql).vendors("1h");
  assert.equal(got.source, "database");
  assert.deepEqual(r.calls, ["sql vendors"]);
  assert.deepEqual(r.logs, []);
});

test("unreachable and not configured fall back quietly; any other gateway error falls back and is logged once", async () => {
  for (const code of [PANEL_CODES.unreachable, PANEL_CODES.notConfigured]) {
    const r = rig({ capability: async () => { throw new GatewayError(502, code, "nope"); } });
    const got = await createLiveReaders(r.live, r.sql).traffic("24h");
    assert.equal(got.source, "database", code);
    assert.deepEqual(r.logs, [], code);
  }
  const r = rig({ series: async () => { throw new GatewayError(400, "BAD_REQUEST", "Unknown field liveSeries"); } });
  const readers = createLiveReaders(r.live, r.sql);
  assert.equal((await readers.traffic("24h")).source, "database");
  assert.equal((await readers.traffic("24h")).source, "database");
  assert.equal(r.logs.length, 1, "at most once a minute per metric");
  assert.match(r.logs[0], /Unknown field liveSeries/);
});

test("a backfilled gateway serves the whole window: no database read at all", async () => {
  const r = rig();
  const got = await createLiveReaders(r.live, r.sql).traffic("24h");
  assert.ok(isSourced(got));
  assert.equal(got.source, "gateway");
  assert.equal(got.liveSince, "2026-10-30T09:20:00.000Z");
  assert.equal(got.backfilledThrough, "2026-10-30T09:00:00.000Z");
  assert.equal(got.spliced, false);
  assert.deepEqual(r.calls, ["series 24h HOUR []"]);
  assert.deepEqual(got.value.map((b) => b.submitted), [100, 10, 5]);
});

test("no backfill and a restart inside the window: the database's part before the seam, the series' after", async () => {
  const r = rig({ series: async () => sum({ backfilledThrough: null }) });
  const got = await createLiveReaders(r.live, r.sql).traffic("24h");
  assert.equal(got.source, "gateway");
  assert.equal(got.spliced, true);
  //started 09:20: the seam is the next whole hour, and the series' 09:00 bucket (a partial one) is dropped
  assert.deepEqual(r.calls, ["series 24h HOUR []", "sql traffic until 2026-10-30T10:00:00.000Z"]);
  assert.deepEqual(got.value.map((b) => [b.bucket, b.submitted]), [
    ["2026-10-30T09:00:00Z", 7],
    ["2026-10-30T10:00:00Z", 10],
    ["2026-10-30T11:00:00Z", 5],
  ]);
});

test("no backfill and no database: the series alone, with liveSince for the page's marker", async () => {
  const r = rig({ series: async () => sum({ backfilledThrough: null }), db: false });
  const got = await createLiveReaders(r.live, r.sql).revenue("24h");
  assert.equal(got.source, "gateway");
  assert.equal(got.spliced, false);
  assert.equal(got.liveSince, "2026-10-30T09:20:00.000Z");
  assert.equal(got.backfilledThrough, null);
  assert.deepEqual(r.calls, ["series 24h HOUR [ACCOUNT,PRODUCT]"]);
  assert.equal(got.value[0].revenue, 1_150);
});

test("a database too slow for the seam: the series alone, logged", async () => {
  const r = rig({ series: async () => sum({ backfilledThrough: null }), sqlDelayMs: 200 });
  const got = await createLiveReaders(r.live, r.sql).vendors("24h");
  assert.equal(got.source, "gateway");
  assert.equal(got.spliced, false);
  assert.equal(got.value[0].attempts, 115);
  assert.equal(r.logs.length, 1);
});

test("no database and no gateway: NoDataSourceError, the route's 503", async () => {
  const r = rig({ capability: async () => false, db: false });
  await assert.rejects(createLiveReaders(r.live, r.sql).accounts("1h"), NoDataSourceError);
  const r2 = rig({ db: false });
  await assert.rejects(createLiveReaders(r2.live, r2.sql).traffic("30d"), NoDataSourceError);
});

test("receipts: the gateway when it covers the window; across a seam the database, unless there is none", async () => {
  const r = rig();
  const got = await createLiveReaders(r.live, r.sql).receipts("24h");
  assert.equal(got.source, "gateway");
  assert.deepEqual(got.partial, ["n2"], "a node that did not answer the receipt read is named");
  assert.equal(got.value[0].medianToOutcome, 1.5);

  const seam = rig({ series: async () => sum({ backfilledThrough: null }) });
  assert.equal((await createLiveReaders(seam.live, seam.sql).receipts("24h")).source, "database");
  assert.ok(seam.calls.includes("sql receipts"));

  const alone = rig({ series: async () => sum({ backfilledThrough: null }), db: false });
  assert.equal((await createLiveReaders(alone.live, alone.sql).receipts("24h")).source, "gateway");
});

test("usage-grid: a date range is the summaries'; the hour and the day are the series' at hour grain", async () => {
  const r = rig();
  const readers = createLiveReaders(r.live, r.sql);
  const dated = await readers.usageGrid("24h", new URLSearchParams("from=2026-10-01&to=2026-10-02"));
  assert.equal(dated.source, "database");
  const live = await readers.usageGrid("24h", new URLSearchParams("account=acme&page=0"));
  assert.equal(live.source, "gateway");
  assert.equal(live.value.grain, "hour");
  assert.equal(live.value.rows[0].submitted, 115);
  assert.ok(r.calls.includes("series 24h HOUR [ACCOUNT,LOGIN,PRODUCT]"));
  await assert.rejects(readers.usageGrid("24h", new URLSearchParams("from=2026-10-01")), /From and a To/);
});

test("usage-grid: a bad filter is the caller's error (BadFilterError, answered 400), never a failed read", async () => {
  const r = rig();
  const readers = createLiveReaders(r.live, r.sql);
  const before = r.calls.length;
  for (const q of ["tag=Bad!", "from=2026-10-01"]) {
    await assert.rejects(readers.usageGrid("1h", new URLSearchParams(q)), (err: unknown) => {
      assert.ok(err instanceof Error);
      assert.equal(err.name, "BadFilterError");
      return true;
    });
  }
  await assert.rejects(readers.usageGrid("1h", new URLSearchParams("tag=Bad!")), /'Bad!' is not a tag name\./);
  assert.equal(r.calls.length, before, "nothing was read");
});

test("accounts: balances and idle credentials from the config reads, the database's rows before the seam merged", async () => {
  const r = rig({ series: async () => sum({ backfilledThrough: null }) });
  const got = await createLiveReaders(r.live, r.sql).accounts("24h", new URLSearchParams());
  assert.equal(got.source, "gateway");
  assert.ok(r.calls.includes("sql accounts until 2026-10-30T10:00:00.000Z"));
  assert.ok(r.calls.includes("config balances"));
  const acme = got.value.accounts.find((a) => a.accountId === "acme")!;
  assert.equal(acme.messages, 7 + 15, "the database's 7 before the seam and the series' 15 after");
  assert.equal(acme.balance, 9_999, "the balance is the config read's, not the database part's");
  const quiet = got.value.accounts.filter((a) => a.accountId === "quiet");
  assert.equal(quiet.length, 1, "an idle row once, from the configured credentials");
  assert.equal(quiet[0].idle, true);
  assert.equal(got.value.creditEnforced, true);
});

test("server-traffic: a bad listener name is the caller's error on either source", async () => {
  const r = rig();
  await assert.rejects(createLiveReaders(r.live, r.sql).serverTraffic("1h", new URLSearchParams("server=a b")), /Which listener/);
  const got = await createLiveReaders(r.live, r.sql).serverTraffic("24h", new URLSearchParams("server=main"));
  assert.equal(got.source, "gateway");
  assert.equal(got.value.totals.messages, 115);
});

test("overview: tiles, series, vendors and the failure rings from the gateway; failuresSince is the window's start", async () => {
  const r = rig();
  const readers = createLiveReaders(r.live, r.sql);
  const got = await readers.overview("24h", async () => assert.fail("the refresher is not used"));
  assert.equal(got.source, "gateway");
  assert.equal(got.value.source, "gateway");
  assert.equal(got.value.totals.messages, 115);
  assert.equal(got.value.totals.revenue, 1_150);
  assert.equal(got.value.vendors[0].vendor, "v1");
  assert.equal(got.value.watermark, null);
  assert.equal(got.value.settlingFrom, "2026-10-29T12:02:00.000Z");
  assert.equal(got.value.stale.failures, false);
  assert.equal(got.value.failuresSince, "2026-10-29T12:02:00.000Z");
  assert.deepEqual(got.value.failures, [
    { finalState: "FAILED", dlrState: 2, errCode: "0x0b", account: "acme", vendor: "v1", vendorErrCode: "11", messages: 1,
      lastSeen: "2026-10-30T10:12:00.000Z" },
  ]);
  assert.deepEqual(got.value.vendorAccounts.map((v) => [v.vendor, v.account, v.attempts]), [["v1", "acme", 115]]);
  assert.ok(r.calls.includes("series 24h HOUR [ACCOUNT,VENDOR]"));
  assert.ok(r.calls.includes("live failures"));
  assert.ok(!r.calls.includes("sql failures"), "the database is not asked for failures");
  assert.deepEqual(got.partial, ["n3"], "a node missing from the failures read is named");
});

test("overview failures: the database's breakdown when the gateway fails the read; stale when that fails too", async () => {
  const r = rig({ liveFailures: async () => { throw new GatewayError(400, "BAD_REQUEST", "Unknown field liveFailures"); } });
  const got = await createLiveReaders(r.live, r.sql).overview("1h", async () => assert.fail("not used"));
  assert.equal(got.source, "gateway", "the rest of the overview stays on the gateway");
  assert.ok(r.calls.includes("sql failures"));
  assert.equal(got.value.failuresSince, "2026-10-30T00:00:00.000Z", "the breakdown's own window");
  assert.equal(got.value.stale.failures, false);

  const bad = rig({
    liveFailures: async () => { throw new GatewayError(502, PANEL_CODES.unreachable, "down"); },
    failures: async () => { throw new Error("statement timeout"); },
  });
  const stale = await createLiveReaders(bad.live, bad.sql).overview("1h", async () => assert.fail("not used"));
  assert.equal(stale.value.stale.failures, true);
  assert.deepEqual(stale.value.failures, []);
});

test("overview failures across a seam: the database's breakdown with one, the gateway's alone without", async () => {
  const seam = rig({ series: async () => sum({ backfilledThrough: null }) });
  await createLiveReaders(seam.live, seam.sql).overview("24h", async () => assert.fail("not used"));
  assert.ok(seam.calls.includes("sql failures"));

  const alone = rig({ series: async () => sum({ backfilledThrough: null }), db: false });
  const got = await createLiveReaders(alone.live, alone.sql).overview("24h", async () => assert.fail("not used"));
  assert.ok(!alone.calls.includes("sql failures"));
  assert.equal(got.value.failures[0].finalState, "FAILED");
});

test("overview: a gateway without live_series is the refresher's", async () => {
  const off = rig({ capability: async () => false });
  let refresher = false;
  const on = rig();
  const db = await createLiveReaders(off.live, off.sql).overview("1h", async () => {
    refresher = true;
    return { ...(await createLiveReaders(on.live, on.sql).overview("1h", async () => assert.fail("x"))).value, source: "live" as const };
  });
  assert.equal(db.source, "database");
  assert.ok(refresher);
});
