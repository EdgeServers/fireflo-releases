/**
 * One listener's traffic over a window: messages and their outcomes, by account.
 *
 * <p>Pure, so its shape is tested without a database. The records are the only source: the hourly
 * summary has no listener column (`usage_hourly` is account x hour x product x vendor), so this reads
 * `cdr_submit` bounded by `submitted_at` and filtered to the listener's worker name -- which is why
 * the Servers picker stops at 24 hours. A week would need `server` in the summary first.
 *
 * <p>One row per message (`messageRows`, the representative attempt) and its outcome by the same
 * real-receipt-before-EXPIRED rule as every other reader (`OUTCOME_LATERAL`).
 *
 * <p>Binds: `$1` since, `$2` until, `$3` the worker name, `smppserver.<name>`.
 */
import { messageRows } from "./cdr-grain.ts";
import { OUTCOME_LATERAL } from "./usage-summary-sql.ts";

/** The periods the Servers picker offers: no rollup holds a listener, so nothing longer. */
export const SERVER_TRAFFIC_RANGES = ["1h", "24h"] as const;
export type ServerTrafficRange = (typeof SERVER_TRAFFIC_RANGES)[number];

/** Accounts shown per listener; the totals still count every one. */
export const SERVER_TRAFFIC_ACCOUNTS = 50;

export function serverTrafficSql(vendorAttempt: boolean): string {
  return `
  SELECT NULLIF(s.account_id, '')                                                  AS account_id,
         count(*)                                                                  AS messages,
         count(*) FILTER (WHERE o.final_state = 'DELIVERED')                       AS delivered,
         count(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED'))  AS failed,
         count(*) FILTER (WHERE o.final_state = 'EXPIRED')                         AS expired,
         count(*) FILTER (WHERE o.final_state IS NULL)                             AS pending,
         (sum(count(*)) OVER ())::bigint                                           AS total_messages,
         (sum(count(*) FILTER (WHERE o.final_state = 'DELIVERED')) OVER ())::bigint AS total_delivered,
         (sum(count(*) FILTER (WHERE o.final_state IS NOT NULL
                                 AND o.final_state <> 'EXPIRED')) OVER ())::bigint AS total_reported
    FROM ${messageRows(
      "s.in_gateway = $3 AND s.submitted_at >= $1 AND s.submitted_at < $2",
      { vendorAttempt },
      ["gateway_msg_id", "part_no", "account_id"]
    )}${OUTCOME_LATERAL}
   GROUP BY 1
   ORDER BY messages DESC, account_id
   LIMIT ${SERVER_TRAFFIC_ACCOUNTS}`;
}
