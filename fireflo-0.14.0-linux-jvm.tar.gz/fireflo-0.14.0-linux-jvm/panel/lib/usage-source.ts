/**
 * Which summary a windowed read leans on: `usage_hourly` while the gateway keeps it current, else
 * the daily seam (`usage_daily` plus the records).
 *
 * <p>The hourly summary is rolled every minute, so whole hours of a 24-hour or a 30-day window come
 * from it and only the minutes past its watermark are read from `cdr_submit`. The daily seam reads
 * every message of a window that holds no whole billing day -- all of a 24-hour one -- which is
 * what timed out at production volume. A watermark older than `maxAgeMs` means the rollup has
 * stopped; leaning on it would push the rest of the window onto the records unseen, so the daily
 * seam is the honest fallback.
 *
 * <p>Pure: the caller reads the watermark (`hourlyWatermark()`, null when the table is absent).
 */
export function sourceFor(watermark: Date | null, now: number, maxAgeMs: number): "hourly" | "live" {
  return watermark !== null && now - watermark.getTime() < maxAgeMs ? "hourly" : "live";
}

/** How old the hourly watermark may be and still be leaned on: the account page's three hours. */
export const HOURLY_MAX_AGE_MS = 3 * 3_600_000;
