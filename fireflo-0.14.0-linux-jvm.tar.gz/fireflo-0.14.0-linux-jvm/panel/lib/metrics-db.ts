import { AsyncLocalStorage } from "node:async_hooks";
import { Pool, type QueryResultRow } from "pg";

/**
 * Read-only access to the gateway's call-record database.
 *
 * <p>This module never issues DDL and never writes. That is not a convention to be relied on
 * alone -- the connection should use a role granted only SELECT, so a mistake here cannot damage
 * billing records. The sibling panel's Postgres helper runs a CREATE TABLE block on connect, which
 * is precisely why this is a separate module rather than a reuse of it.
 *
 * <p>Every query is parameterised. Nothing here interpolates a value, an identifier or an
 * interval into SQL.
 */
let pool: Pool | null = null;

export function isConfigured(): boolean {
  return !!process.env.METRICS_DATABASE_URL?.trim();
}

function getPool(): Pool {
  const url = process.env.METRICS_DATABASE_URL?.trim();
  if (!url) {
    throw new Error("METRICS_DATABASE_URL is not set");
  }
  if (!pool) {
    pool = new Pool({
      connectionString: url,
      max: 8,
      connectionTimeoutMillis: 5_000,
      idleTimeoutMillis: 30_000,
      //a dashboard query that has not answered in ten seconds is not going to be useful, and
      //holding the connection helps nobody
      statement_timeout: 10_000,
    });
  }
  return pool;
}

/** A longer statement limit for the reads made inside {@link withStatementTimeout}; none means the pool's 10 s. */
const limits = new AsyncLocalStorage<number>();

/**
 * Runs `read` with every statement it makes allowed `ms` rather than the pool's 10 s.
 *
 * <p>For the heavy stats only (`stats-route.ts`), which read on in the background after the page
 * has been told to wait: a month of receipts at production volume can need more than ten seconds,
 * and cutting it off means it never finishes at all. The connection's limit is set for the
 * statement and reset before it goes back to the pool, so nothing else inherits it.
 */
export function withStatementTimeout<T>(ms: number, read: () => Promise<T>): Promise<T> {
  return limits.run(ms, read);
}

export async function query<T extends QueryResultRow>(sql: string, params: unknown[] = []): Promise<T[]> {
  const ms = limits.getStore();
  if (ms === undefined) {
    const result = await getPool().query<T>(sql, params);
    return result.rows;
  }
  const client = await getPool().connect();
  try {
    await client.query(`SET statement_timeout = ${Math.max(1_000, Math.floor(ms))}`);
    const result = await client.query<T>(sql, params);
    return result.rows;
  } finally {
    await client.query("RESET statement_timeout").catch(() => undefined);
    client.release();
  }
}

/** Test and shutdown helper. */
export async function closeMetricsDb(): Promise<void> {
  const existing = pool;
  pool = null;
  await existing?.end();
}
