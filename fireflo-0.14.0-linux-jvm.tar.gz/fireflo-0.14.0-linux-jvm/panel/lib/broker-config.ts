/**
 * The Kafka backbone's settings as a form, and the `app_config` keys they are stored as.
 *
 * <p>Gateway 0.14 queues on Kafka or in process; RabbitMQ is gone, and a gateway started on
 * `smsg.queue.provider=rabbitmq` refuses to start. Kafka mode is cluster mode: every node that
 * shares the bootstrap servers shares the work, so the cluster timers live on this form too.
 *
 * <p>Three of the keys are secrets (`app_config_key`): the SASL password and the two store
 * passwords. The browser never sees them. The form carries each as `null` to keep what is stored,
 * or a string to replace it, and the view says only whether one is stored -- the same kept/change
 * protocol the worker form uses for a login's password.
 *
 * <p>Pure, no database import: the Queues page uses the types and the validation as they are.
 */

export const BROKER_KEYS = {
  provider: "smsg.queue.provider",
  bootstrap: "smsg.kafka.bootstrap.servers",
  securityProtocol: "smsg.kafka.security.protocol",
  saslMechanism: "smsg.kafka.sasl.mechanism",
  saslUsername: "smsg.kafka.sasl.username",
  saslPassword: "smsg.kafka.sasl.password",
  truststorePath: "smsg.kafka.ssl.truststore.path",
  truststorePassword: "smsg.kafka.ssl.truststore.password",
  keystorePath: "smsg.kafka.ssl.keystore.path",
  keystorePassword: "smsg.kafka.ssl.keystore.password",
  topicPrefix: "smsg.kafka.topic.prefix",
  groupPrefix: "smsg.kafka.group.prefix",
  topicsCreate: "smsg.kafka.topics.create",
  partitionsRouter: "smsg.kafka.partitions.router",
  partitionsVendor: "smsg.kafka.partitions.vendor",
  partitionsRetry: "smsg.kafka.partitions.retry",
  replicationFactor: "smsg.kafka.replication.factor",
  retentionHours: "smsg.kafka.retention.hours",
  compression: "smsg.kafka.compression",
  produceTimeoutMs: "smsg.kafka.produce.timeout.ms",
  produceBlockMs: "smsg.kafka.produce.block.ms",
  routerInflight: "smsg.kafka.router.inflight",
  vendorInflight: "smsg.kafka.vendor.inflight",
  vendorSettle: "smsg.kafka.vendor.settle",
  ingressLagHighwater: "smsg.kafka.ingress.lag.highwater",
  clusterHeartbeat: "smsg.cluster.heartbeat.seconds",
  clusterNodeTimeout: "smsg.cluster.node.timeout.seconds",
  clusterLeaseTtl: "smsg.cluster.lease.ttl.seconds",
  clusterLeaseRenew: "smsg.cluster.lease.renew.seconds",
  clusterRebalanceGrace: "smsg.cluster.rebalance.grace.seconds",
} as const;

export type BrokerKeyName = keyof typeof BROKER_KEYS;

/** The three keys whose values are write-only. */
export const BROKER_SECRET_KEYS: readonly string[] = [
  BROKER_KEYS.saslPassword,
  BROKER_KEYS.truststorePassword,
  BROKER_KEYS.keystorePassword,
];

export function isSecretBrokerKey(key: string): boolean {
  return BROKER_SECRET_KEYS.includes(key);
}

/**
 * The gateway's own defaults (`KafkaBackboneConfig`, `ClusterConfig`), shown as placeholders and
 * never written: a blank field deletes its row and the default applies.
 */
export const BROKER_DEFAULTS = {
  securityProtocol: "PLAINTEXT",
  saslMechanism: "SCRAM-SHA-512",
  topicPrefix: "fireflo.",
  groupPrefix: "fireflo-",
  topicsCreate: "true",
  partitionsRouter: "24",
  partitionsVendor: "6",
  partitionsRetry: "6",
  /** -1 is the broker's `default.replication.factor`. */
  replicationFactor: "-1",
  retentionHours: "168",
  compression: "lz4",
  produceTimeoutMs: "5000",
  produceBlockMs: "500",
  routerInflight: "1000",
  vendorInflight: "200",
  vendorSettle: "on-submit",
  ingressLagHighwater: "100000",
  clusterHeartbeat: "5",
  clusterNodeTimeout: "30",
  clusterLeaseTtl: "30",
  clusterLeaseRenew: "10",
  clusterRebalanceGrace: "60",
} as const;

export type BrokerProvider = "memory" | "kafka";
export const SECURITY_PROTOCOLS = ["PLAINTEXT", "SSL", "SASL_PLAINTEXT", "SASL_SSL"] as const;
export type SecurityProtocol = (typeof SECURITY_PROTOCOLS)[number];
export const SASL_MECHANISMS = ["PLAIN", "SCRAM-SHA-256", "SCRAM-SHA-512"] as const;
export type SaslMechanism = (typeof SASL_MECHANISMS)[number];
export const COMPRESSIONS = ["none", "lz4", "gzip"] as const;
export type Compression = (typeof COMPRESSIONS)[number];
export const VENDOR_SETTLES = ["on-submit", "on-response"] as const;
export type VendorSettle = (typeof VENDOR_SETTLES)[number];

/** The two answers to "when does a message count as handed over", in the operator's words. */
export const VENDOR_SETTLE_OPTIONS: readonly { value: VendorSettle; label: string; description: string }[] = [
  {
    value: "on-submit",
    label: "When submitted",
    description: "when submit_sm is handed to the vendor session (no resend after a node crash)",
  },
  {
    value: "on-response",
    label: "When the vendor answers",
    description: "when the vendor answers (resent after a crash; the vendor may deliver twice)",
  },
];

export function usesSasl(protocol: SecurityProtocol): boolean {
  return protocol === "SASL_PLAINTEXT" || protocol === "SASL_SSL";
}

export function usesTls(protocol: SecurityProtocol): boolean {
  return protocol === "SSL" || protocol === "SASL_SSL";
}

/**
 * The form. Every number is a string, blank meaning "the gateway's default"; `topicsCreate` is a
 * boolean because a switch has no blank. A secret is `null` to keep the stored value.
 */
export interface BrokerForm {
  provider: BrokerProvider;
  /** One `host:port` per line, or comma separated. */
  bootstrap: string;
  securityProtocol: SecurityProtocol;
  saslMechanism: SaslMechanism;
  saslUsername: string;
  saslPassword: string | null;
  truststorePath: string;
  truststorePassword: string | null;
  keystorePath: string;
  keystorePassword: string | null;
  topicPrefix: string;
  groupPrefix: string;
  topicsCreate: boolean;
  partitionsRouter: string;
  partitionsVendor: string;
  partitionsRetry: string;
  replicationFactor: string;
  retentionHours: string;
  compression: Compression;
  produceTimeoutMs: string;
  produceBlockMs: string;
  routerInflight: string;
  vendorInflight: string;
  vendorSettle: VendorSettle;
  ingressLagHighwater: string;
  clusterHeartbeat: string;
  clusterNodeTimeout: string;
  clusterLeaseTtl: string;
  clusterLeaseRenew: string;
  clusterRebalanceGrace: string;
}

export type BrokerSecret = "saslPassword" | "truststorePassword" | "keystorePassword";
export const BROKER_SECRETS: readonly BrokerSecret[] = ["saslPassword", "truststorePassword", "keystorePassword"];

/** Which secrets have a stored value: the only thing the browser learns about them. */
export type SecretsSet = Record<BrokerSecret, boolean>;

/** What the server sends the page: the form with every secret null, and which ones are stored. */
export interface BrokerView {
  form: BrokerForm;
  secretsSet: SecretsSet;
}

const HOST = /^(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)*$/;
const IPV6 = /^\[[0-9A-Fa-f:.]+\]$/;

/**
 * Reads a bootstrap list the way the Kafka client does -- `host:port`, comma separated -- and also
 * one per line, which is how the form takes it. Returns the normalised servers, or the sentence
 * that says what is wrong with them.
 *
 * <p>The port is required: the Java client refuses a bare host, and it is better refused here than
 * at the gateway's restart.
 */
export function parseBootstrap(text: string): string[] | string {
  const servers = text
    .split(/[\n,]/)
    .map((s) => s.trim())
    .filter(Boolean);
  if (servers.length === 0) {
    return "Enter at least one bootstrap server, as host:port.";
  }
  for (const server of servers) {
    const colon = server.lastIndexOf(":");
    const host = colon > 0 ? server.slice(0, colon) : "";
    const port = colon > 0 ? server.slice(colon + 1) : "";
    if (!host || !port || (server.includes("]") && !server.includes("]:"))) {
      return `'${server}' needs a port: host:port.`;
    }
    if (!inRange(port, 1, 65535)) {
      return `'${server}': the port is a number from 1 to 65535.`;
    }
    if (!HOST.test(host) && !IPV6.test(host)) {
      return `'${host}' is not a host name or IP address.`;
    }
  }
  return [...new Set(servers)];
}

/** The bootstrap servers as the gateway reads them: one line, comma separated. */
export function bootstrapForGateway(text: string): string {
  const parsed = parseBootstrap(text);
  return typeof parsed === "string" ? "" : parsed.join(",");
}

const PREFIX = /^[A-Za-z0-9._-]{1,200}$/;

/**
 * Why the form cannot be saved or tested, or null when it can.
 *
 * <p>Under the in-process provider the Kafka fields are not read, so nothing about them is
 * checked: switching the backbone off must not be blocked by a typo in the address being abandoned.
 */
export function brokerProblem(form: BrokerForm, secretsSet: SecretsSet): string | null {
  if (form.provider === "memory") {
    return null;
  }
  const servers = parseBootstrap(form.bootstrap);
  if (typeof servers === "string") {
    return servers;
  }
  if (!SECURITY_PROTOCOLS.includes(form.securityProtocol)) {
    return "The security protocol is PLAINTEXT, SSL, SASL_PLAINTEXT or SASL_SSL.";
  }
  if (usesSasl(form.securityProtocol)) {
    if (!SASL_MECHANISMS.includes(form.saslMechanism)) {
      return "The SASL mechanism is PLAIN, SCRAM-SHA-256 or SCRAM-SHA-512.";
    }
    if (!form.saslUsername.trim()) {
      return "SASL needs a user name.";
    }
    if (!hasSecret(form, secretsSet, "saslPassword")) {
      return "Enter the SASL password for this user.";
    }
  }
  if (usesTls(form.securityProtocol)) {
    if (hasSecret(form, secretsSet, "truststorePassword") && !form.truststorePath.trim()) {
      return "A truststore password needs a truststore path.";
    }
    if (hasSecret(form, secretsSet, "keystorePassword") && !form.keystorePath.trim()) {
      return "A keystore password needs a keystore path.";
    }
  }
  if (form.topicPrefix.trim() && !PREFIX.test(form.topicPrefix.trim())) {
    return "The topic prefix takes letters, digits, '.', '_' and '-'.";
  }
  if (form.groupPrefix.trim() && !PREFIX.test(form.groupPrefix.trim())) {
    return "The group prefix takes letters, digits, '.', '_' and '-'.";
  }
  if (!COMPRESSIONS.includes(form.compression)) {
    return "Compression is none, lz4 or gzip.";
  }
  if (!VENDOR_SETTLES.includes(form.vendorSettle)) {
    return "Settlement is on-submit or on-response.";
  }
  if (form.replicationFactor.trim() && form.replicationFactor.trim() !== "-1" && !inRange(form.replicationFactor, 1, 32767)) {
    return "The replication factor is a whole number of at least 1, or -1 for the broker's default.";
  }
  const numbers: [string, string, number][] = [
    [form.partitionsRouter, "Router partitions", 1],
    [form.partitionsVendor, "Vendor partitions", 1],
    [form.partitionsRetry, "Retry partitions", 1],
    [form.retentionHours, "Retention", 1],
    [form.produceTimeoutMs, "The produce timeout", 1],
    [form.produceBlockMs, "The produce block time", 0],
    [form.routerInflight, "Router in-flight", 1],
    [form.vendorInflight, "Vendor in-flight", 1],
    [form.ingressLagHighwater, "The lag high-water mark", 0],
    [form.clusterHeartbeat, "The heartbeat", 1],
    [form.clusterNodeTimeout, "The node timeout", 1],
    [form.clusterLeaseTtl, "The lease TTL", 1],
    [form.clusterLeaseRenew, "The lease renewal", 1],
    [form.clusterRebalanceGrace, "The rebalance grace", 0],
  ];
  for (const [value, label, min] of numbers) {
    if (value.trim() && !inRange(value, min, 2_147_483_647)) {
      return `${label} is a whole number of at least ${min}.`;
    }
  }
  const heartbeat = Number(form.clusterHeartbeat.trim() || BROKER_DEFAULTS.clusterHeartbeat);
  const nodeTimeout = Number(form.clusterNodeTimeout.trim() || BROKER_DEFAULTS.clusterNodeTimeout);
  if (nodeTimeout <= heartbeat) {
    return "The node timeout must be longer than the heartbeat, or every node reads as dead between beats.";
  }
  const ttl = Number(form.clusterLeaseTtl.trim() || BROKER_DEFAULTS.clusterLeaseTtl);
  const renew = Number(form.clusterLeaseRenew.trim() || BROKER_DEFAULTS.clusterLeaseRenew);
  if (renew >= ttl) {
    return "A lease must be renewed before it expires: renewal is shorter than the TTL.";
  }
  return null;
}

/** Whether a secret will be present after this form is saved: kept and stored, or newly entered. */
function hasSecret(form: BrokerForm, secretsSet: SecretsSet, name: BrokerSecret): boolean {
  const value = form[name];
  return value === null ? secretsSet[name] : value !== "";
}

function inRange(raw: string, min: number, max: number): boolean {
  const n = Number(raw.trim());
  return Number.isInteger(n) && n >= min && n <= max;
}

function oneOf<T extends string>(choices: readonly T[], raw: string | undefined, fallback: T): T {
  const v = (raw ?? "").trim();
  return (choices as readonly string[]).includes(v) ? (v as T) : fallback;
}

/** The form for what is stored. No secret is in it, only whether each is set. */
export function formFromStored(stored: Map<string, string>): BrokerView {
  const get = (name: BrokerKeyName) => stored.get(BROKER_KEYS[name]) ?? "";
  return {
    form: {
      provider: get("provider").trim().toLowerCase() === "kafka" ? "kafka" : "memory",
      bootstrap: get("bootstrap").split(",").map((s) => s.trim()).filter(Boolean).join("\n"),
      securityProtocol: oneOf(SECURITY_PROTOCOLS, get("securityProtocol").toUpperCase(), "PLAINTEXT"),
      saslMechanism: oneOf(SASL_MECHANISMS, get("saslMechanism").toUpperCase(), "SCRAM-SHA-512"),
      saslUsername: get("saslUsername"),
      saslPassword: null,
      truststorePath: get("truststorePath"),
      truststorePassword: null,
      keystorePath: get("keystorePath"),
      keystorePassword: null,
      topicPrefix: get("topicPrefix"),
      groupPrefix: get("groupPrefix"),
      topicsCreate: get("topicsCreate").trim().toLowerCase() !== "false",
      partitionsRouter: get("partitionsRouter"),
      partitionsVendor: get("partitionsVendor"),
      partitionsRetry: get("partitionsRetry"),
      replicationFactor: get("replicationFactor"),
      retentionHours: get("retentionHours"),
      compression: oneOf(COMPRESSIONS, get("compression").toLowerCase(), "lz4"),
      produceTimeoutMs: get("produceTimeoutMs"),
      produceBlockMs: get("produceBlockMs"),
      routerInflight: get("routerInflight"),
      vendorInflight: get("vendorInflight"),
      vendorSettle: oneOf(VENDOR_SETTLES, get("vendorSettle").toLowerCase(), "on-submit"),
      ingressLagHighwater: get("ingressLagHighwater"),
      clusterHeartbeat: get("clusterHeartbeat"),
      clusterNodeTimeout: get("clusterNodeTimeout"),
      clusterLeaseTtl: get("clusterLeaseTtl"),
      clusterLeaseRenew: get("clusterLeaseRenew"),
      clusterRebalanceGrace: get("clusterRebalanceGrace"),
    },
    secretsSet: {
      saslPassword: Boolean(get("saslPassword")),
      truststorePassword: Boolean(get("truststorePassword")),
      keystorePassword: Boolean(get("keystorePassword")),
    },
  };
}

/**
 * The rows a save writes: key to value, where "" means delete the row so the default applies.
 *
 * <p>Under the in-process provider only the provider is written: the Kafka settings are left as
 * they are, so switching the backbone off and on again does not lose them. A kept secret (`null`)
 * is not in the map at all, which is how it stays untouched.
 */
export function writesForForm(form: BrokerForm): Map<string, string> {
  const wanted = new Map<string, string>([[BROKER_KEYS.provider, form.provider]]);
  if (form.provider !== "kafka") {
    return wanted;
  }
  const text = (name: Exclude<BrokerKeyName, "provider" | "topicsCreate" | BrokerSecret>, value: string) =>
    wanted.set(BROKER_KEYS[name], value.trim());
  wanted.set(BROKER_KEYS.bootstrap, bootstrapForGateway(form.bootstrap));
  //a value equal to the default is still written when chosen from a list: the operator picked it
  //and a later default change must not move them
  text("securityProtocol", form.securityProtocol);
  text("saslMechanism", usesSasl(form.securityProtocol) ? form.saslMechanism : "");
  text("saslUsername", usesSasl(form.securityProtocol) ? form.saslUsername : "");
  text("truststorePath", usesTls(form.securityProtocol) ? form.truststorePath : "");
  text("keystorePath", usesTls(form.securityProtocol) ? form.keystorePath : "");
  for (const secret of BROKER_SECRETS) {
    const value = form[secret];
    if (value !== null) {
      wanted.set(BROKER_KEYS[secret], value);
    }
  }
  text("topicPrefix", form.topicPrefix);
  text("groupPrefix", form.groupPrefix);
  wanted.set(BROKER_KEYS.topicsCreate, form.topicsCreate ? "" : "false");
  text("partitionsRouter", form.partitionsRouter);
  text("partitionsVendor", form.partitionsVendor);
  text("partitionsRetry", form.partitionsRetry);
  text("replicationFactor", form.replicationFactor);
  text("retentionHours", form.retentionHours);
  text("compression", form.compression);
  text("produceTimeoutMs", form.produceTimeoutMs);
  text("produceBlockMs", form.produceBlockMs);
  text("routerInflight", form.routerInflight);
  text("vendorInflight", form.vendorInflight);
  text("vendorSettle", form.vendorSettle);
  text("ingressLagHighwater", form.ingressLagHighwater);
  text("clusterHeartbeat", form.clusterHeartbeat);
  text("clusterNodeTimeout", form.clusterNodeTimeout);
  text("clusterLeaseTtl", form.clusterLeaseTtl);
  text("clusterLeaseRenew", form.clusterLeaseRenew);
  text("clusterRebalanceGrace", form.clusterRebalanceGrace);
  return wanted;
}

/** The form from a request body, or why it is not one. */
export function parseBrokerForm(body: unknown): BrokerForm | string {
  if (!body || typeof body !== "object") {
    return "Expected a JSON body.";
  }
  const b = body as Record<string, unknown>;
  const text = (v: unknown) => (typeof v === "string" ? v : "");
  const secret = (v: unknown) => (typeof v === "string" ? v : null);
  if (b.provider !== "memory" && b.provider !== "kafka") {
    return "The provider is memory or kafka.";
  }
  return {
    provider: b.provider,
    bootstrap: text(b.bootstrap),
    securityProtocol: oneOf(SECURITY_PROTOCOLS, text(b.securityProtocol), "PLAINTEXT"),
    saslMechanism: oneOf(SASL_MECHANISMS, text(b.saslMechanism), "SCRAM-SHA-512"),
    saslUsername: text(b.saslUsername),
    saslPassword: secret(b.saslPassword),
    truststorePath: text(b.truststorePath),
    truststorePassword: secret(b.truststorePassword),
    keystorePath: text(b.keystorePath),
    keystorePassword: secret(b.keystorePassword),
    topicPrefix: text(b.topicPrefix),
    groupPrefix: text(b.groupPrefix),
    topicsCreate: b.topicsCreate !== false,
    partitionsRouter: text(b.partitionsRouter),
    partitionsVendor: text(b.partitionsVendor),
    partitionsRetry: text(b.partitionsRetry),
    replicationFactor: text(b.replicationFactor),
    retentionHours: text(b.retentionHours),
    compression: oneOf(COMPRESSIONS, text(b.compression), "lz4"),
    produceTimeoutMs: text(b.produceTimeoutMs),
    produceBlockMs: text(b.produceBlockMs),
    routerInflight: text(b.routerInflight),
    vendorInflight: text(b.vendorInflight),
    vendorSettle: oneOf(VENDOR_SETTLES, text(b.vendorSettle), "on-submit"),
    ingressLagHighwater: text(b.ingressLagHighwater),
    clusterHeartbeat: text(b.clusterHeartbeat),
    clusterNodeTimeout: text(b.clusterNodeTimeout),
    clusterLeaseTtl: text(b.clusterLeaseTtl),
    clusterLeaseRenew: text(b.clusterLeaseRenew),
    clusterRebalanceGrace: text(b.clusterRebalanceGrace),
  };
}
