/**
 * The gateway's slow-query log as the Database page reads it: the window choices, the shapes on
 * the wire and the sentences. Pure and client-safe; the gateway call is in the route.
 *
 * <p>The log is an in-memory ring on the gateway (`smsg.db.slow.ms` is the threshold), so a reading
 * is the recent past and a restart empties it. Nothing here is ever written anywhere.
 */

/** One JDBC statement that took longer than the threshold, as `slowQueries` answers it. */
export interface SlowQuery {
  startedAt: string;
  durationMs: number;
  shape: string;
  updateCount: number | null;
  caller: string;
  thread: string;
}

export interface SlowQueryShape {
  shape: string;
  count: number;
  maxMs: number;
  meanMs: number;
  lastAt: string;
}

/** `slowQuerySummary`: the threshold, how much the ring holds, and the fold by shape. */
export interface SlowQuerySummary {
  thresholdMs: number;
  kept: number;
  lastHour: number;
  shapes: SlowQueryShape[];
}

/** What the route answers: both reads, taken together so the two agree on the window. */
export interface SlowQueriesPayload {
  summary: SlowQuerySummary;
  queries: SlowQuery[];
  /** The instant the window started, or null for everything kept. */
  since: string | null;
}

/** How far back to look. `all` is everything the ring still holds. */
export const SLOW_WINDOWS = [
  { value: "1h", label: "1 hour", minutes: 60 },
  { value: "6h", label: "6 hours", minutes: 6 * 60 },
  { value: "24h", label: "24 hours", minutes: 24 * 60 },
  { value: "all", label: "Everything kept", minutes: null },
] as const;

export type SlowWindow = (typeof SLOW_WINDOWS)[number]["value"];

export function isSlowWindow(value: string): value is SlowWindow {
  return SLOW_WINDOWS.some((w) => w.value === value);
}

/** The `since` instant for a window, or null for everything kept. */
export function windowSince(window: SlowWindow, now: Date = new Date()): string | null {
  const minutes = SLOW_WINDOWS.find((w) => w.value === window)?.minutes ?? null;
  return minutes === null ? null : new Date(now.getTime() - minutes * 60_000).toISOString();
}

/** "3 slow queries in the last hour", "1 slow query in the last hour", or null when none. */
export function slowChipSentence(db: { slowLastHour: number } | null | undefined): string | null {
  if (!db || db.slowLastHour <= 0) {
    return null;
  }
  return `${db.slowLastHour.toLocaleString()} slow ${db.slowLastHour === 1 ? "query" : "queries"} in the last hour`;
}

/** Milliseconds as a person reads them: "850 ms", "2.4 s", "1 min 12 s". */
export function formatMs(ms: number): string {
  if (!Number.isFinite(ms) || ms < 0) {
    return "—";
  }
  if (ms < 1_000) {
    return `${Math.round(ms)} ms`;
  }
  if (ms < 60_000) {
    return `${(ms / 1_000).toFixed(ms < 10_000 ? 1 : 0).replace(/\.0$/, "")} s`;
  }
  const minutes = Math.floor(ms / 60_000);
  const seconds = Math.round((ms % 60_000) / 1_000);
  return seconds ? `${minutes} min ${seconds} s` : `${minutes} min`;
}

/** The shape's first keyword and table, for a column that cannot hold the whole statement. */
export function shapeHeadline(shape: string): string {
  const flat = shape.replace(/\s+/g, " ").trim();
  return flat.length > 90 ? `${flat.slice(0, 87)}…` : flat;
}
