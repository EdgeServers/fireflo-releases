/**
 * Prepaid credit, with no database import anywhere.
 *
 * <p>Split from `balance.ts` for the reason every `-types` module here is: a client component that
 * reaches a module which transitively imports `pg` does not break that page, it breaks every page.
 *
 * <p>Everything below exists to keep money exact. `account_balance.balance` is a `BIGINT` scaled by
 * 10,000, and the conversion into it is done by moving characters around rather than by arithmetic —
 * see {@link parseAmount}.
 */

//the extension is required for node --test to resolve this without a bundler, which is how
//`lib/tlv-coverage.ts` imports its own dependency too. tsc accepts it either way
import { MONEY_SCALE } from "./format.ts";

/** Four decimal places, no sign, no exponent. The same shape `AMOUNT_PATTERN` enforces for rates. */
const AMOUNT = /^\d+(\.\d{1,4})?$/;

/** How many decimal places the scale allows. `MONEY_SCALE` is 10^4, so four. */
const PLACES = String(MONEY_SCALE).length - 1;

export type BillingMode = "PREPAID" | "POSTPAID";

export interface BalanceRow {
  accountId: string;
  /** Scaled by 10,000, as stored. */
  balance: number;
  reserved: number;
  currency: string | null;
  enabled: boolean;
  billingMode: BillingMode;
  /** Scaled by 10,000. Meaningful only when POSTPAID; zero on every prepaid row. */
  creditLimit: number;
}

export function isBillingMode(value: unknown): value is BillingMode {
  return value === "PREPAID" || value === "POSTPAID";
}

/**
 * What a mode change is allowed to be, and the one refusal that costs money to get wrong.
 *
 * <p><strong>Zero is not "unlimited", and a postpaid account set to zero can send nothing.</strong>
 * That is the gateway's rule and the database's -- there is no representation of unlimited -- so the
 * form refuses it here rather than saving a limit that silently stops an account. An operator who
 * genuinely wants a postpaid account that cannot send should disable its credit, which says so.
 *
 * <p>Switching back to prepaid clears the limit, because ck_account_balance_limit requires it: a
 * stale figure left on a prepaid row would read as if it were still in force.
 */
export function validateBillingChange(mode: unknown, limit: string): string | null {
  if (!isBillingMode(mode)) {
    return "Choose either prepaid or postpaid.";
  }
  if (mode === "PREPAID") {
    return null;
  }
  const scaled = parseAmount(limit);
  if (scaled === null) {
    return `'${limit}' is not an amount. Use up to ${PLACES} decimal places, with no sign.`;
  }
  if (scaled === 0) {
    return "A postpaid account needs a credit limit above zero. Zero means no credit, not "
      + "unlimited, so this account would be unable to send anything.";
  }
  return null;
}

export interface TopUpInput {
  /** As typed: a decimal string, never a number. */
  amount: string;
  /** The operator's own receipt or transaction id. Required — it is the replay guard. */
  ref: string;
  note?: string;
}

export interface OpenBalanceInput {
  currency: string;
  enabled: boolean;
}

/**
 * A decimal string to the scaled integer that gets stored, or null when it is not a valid amount.
 *
 * <p><strong>Done by string manipulation, deliberately.</strong> The obvious implementation is
 * `Math.round(Number(text) * MONEY_SCALE)`, and it is wrong in a way that only shows up in money:
 * `0.0035 * 10000` is `34.999999999999996` in a JavaScript float. `Math.round` happens to rescue
 * that one, but `Number.parseFloat` on a longer decimal does not always land on the same side, and a
 * conversion that is right for most inputs and wrong for some is worse than one that is obviously
 * wrong. Padding the fraction to four digits and concatenating cannot be inexact, because no
 * arithmetic happens at all.
 *
 * <p>`lib/rate-types.ts` documents the same trap for rate amounts, which is where this rule came
 * from.
 */
export function parseAmount(text: string): number | null {
  const value = (text ?? "").trim();
  if (!AMOUNT.test(value)) {
    return null;
  }
  const [whole, fraction = ""] = value.split(".");
  const scaled = Number(whole + fraction.padEnd(PLACES, "0"));
  //Number.MAX_SAFE_INTEGER is 9.007e15, and the column is a BIGINT, so a large enough amount would
  //lose precision on its way through JSON before it ever reached Postgres
  return Number.isSafeInteger(scaled) ? scaled : null;
}

/** Renders a scaled amount back into the exact string it came from, with no rounding. */
export function formatAmount(scaled: number): string {
  const sign = scaled < 0 ? "-" : "";
  const digits = String(Math.abs(scaled)).padStart(PLACES + 1, "0");
  const whole = digits.slice(0, digits.length - PLACES);
  const fraction = digits.slice(digits.length - PLACES).replace(/0+$/, "");
  return fraction ? `${sign}${whole}.${fraction}` : `${sign}${whole}`;
}

/**
 * Why this top-up cannot be accepted, or null.
 *
 * <p>The reference is required rather than optional, and that is the one rule here worth defending.
 * `uq_balance_ledger_ref` is a unique index **where ref is not null**, so a blank reference switches
 * the replay guard off — and the failure mode is crediting a customer twice because somebody clicked
 * Add credit and was not sure whether it went through.
 */
export function validateTopUp(input: TopUpInput): string | null {
  const amount = (input.amount ?? "").trim();
  if (!amount) {
    return "How much? Enter an amount.";
  }
  if (parseAmount(amount) === null) {
    return `'${amount}' is not an amount. Use digits with up to ${PLACES} decimal places — 250 or `
      + "250.0000 — with no currency symbol and no thousands separator.";
  }
  if (parseAmount(amount) === 0) {
    return "A top-up of zero would record a receipt and credit nothing.";
  }
  if (!(input.ref ?? "").trim()) {
    return "A reference is required — a receipt or transaction id. It is what stops the same "
      + "payment being credited twice, and the database only enforces that when it is set.";
  }
  return null;
}

/** Currency is free text on the column, but a three-letter code is what every reader expects. */
export function validateCurrency(currency: string): string | null {
  const value = (currency ?? "").trim();
  if (!value) {
    return "A currency is required, so the balance means something when somebody reads it.";
  }
  if (!/^[A-Za-z]{3}$/.test(value)) {
    return `'${value}' is not a three-letter currency code.`;
  }
  return null;
}

/**
 * What a balance about to be opened should be denominated in, and where that was decided.
 *
 * <p>`from` is carried rather than derived from `code` because the interface has to say which it is:
 * "from the gateway" and "the same as the reseller above it" are both reasons to stop asking, and a
 * form that showed a code with no provenance is asking the reader to trust a value they cannot check.
 */
export interface InheritedCurrency {
  code: string | null;
  /**
   * `gateway`: `smsg.rates.currency` in `app_config`. `parent`: the balance one level up. `held`:
   * the one code every balance and rate rule on the gateway already carries -- the gateway's
   * `explicit_currencies` view, which its own trigger holds every new row to.
   */
  from: "gateway" | "parent" | "held" | null;
}

/**
 * The inheritance rule, as a pure decision over two candidates.
 *
 * <p><strong>Split from the queries deliberately.</strong> The lookups live in
 * `lib/platform-currency.ts`, which pulls `pg`; this is the part worth testing and it is testable
 * without a database, the same split `lib/mis-account-rules.ts` and `lib/roles.ts` use.
 *
 * <h2>Why the gateway wins</h2>
 *
 * <p>`smsg.rates.currency` is stamped onto every rated message. A balance denominated in anything
 * else could never be spent against a price, and nothing reconciles the two — so it reads correct
 * forever. The parent is a fallback for when that value cannot be read at all, which in file mode is
 * always: it lives in `smsg.properties`, which this panel does not read.
 *
 * <p><strong>A parent's currency is evidence, not authority.</strong> It is the code an operator
 * already chose for this branch of the tree, so inheriting it cannot introduce a disagreement that
 * was not already there. That is a weaker claim than the gateway's and the interface says so.
 *
 * <h2>The third step: what the gateway already holds</h2>
 *
 * <p>"Any account that has a currency" would be a guess -- whichever row came back first. What is
 * not a guess is the gateway's own `explicit_currencies` view (V1.60.0): every currency on every
 * balance and rate rule, which the gateway's trigger holds each new row to, and which it refuses
 * to mix. When that view holds exactly one code, that code is the platform's currency as surely
 * as the key would be; the key is simply not in the database on a file-mode gateway. Two codes
 * there is a state the trigger does not allow, so it resolves nothing and the page's own
 * mixed-currency warning says why. Only an empty platform -- no key, no parent, nothing priced
 * and nothing funded anywhere -- is left with null, and there typing a code really is the act of
 * choosing the platform's currency, which is why `/cp` still asks and the form says so. The
 * portal still refuses, because a customer cannot make that choice, and `openBalance` is
 * `ON CONFLICT DO NOTHING`, so a wrong code cannot be corrected by opening the account again.
 *
 * @param gateway `smsg.rates.currency`, or null when it could not be read
 * @param parent the parent account's own balance currency, or null when there is no parent, no
 *     balance row on it, or no currency on that row
 * @param held the distinct codes in `explicit_currencies`, or none; used only when it holds exactly
 *     one
 */
export function chooseCurrency(
  gateway: string | null | undefined,
  parent: string | null | undefined,
  held: readonly (string | null | undefined)[] = []
): InheritedCurrency {
  const fromGateway = (gateway ?? "").trim();
  if (fromGateway) {
    return { code: fromGateway.toUpperCase(), from: "gateway" };
  }
  const fromParent = (parent ?? "").trim();
  if (fromParent) {
    return { code: fromParent.toUpperCase(), from: "parent" };
  }
  const codes = new Set(held.map((c) => (c ?? "").trim().toUpperCase()).filter(Boolean));
  if (codes.size === 1) {
    return { code: [...codes][0], from: "held" };
  }
  return { code: null, from: null };
}
