/**
 * The Revenue page's two charts: revenue over the period, split into what it cost and what it kept,
 * and the accounts that brought it in.
 *
 * <p>Pure, so the arithmetic is tested without a browser. Amounts stay in the panel's scaled
 * integers (`money()` formats them), as everywhere else.
 */

export interface RevenueBucketLike {
  /** `YYYY-MM-DD` for a day, an ISO instant for an hour or five minutes. */
  bucket: string;
  revenue: number;
  cost: number;
}

export interface SeriesBar {
  label: string;
  revenue: number;
  /** Stacked: cost, then margin on top -- together the revenue. */
  cost: number;
  margin: number;
  /** Cost above revenue: the bar shows the cost alone and the tooltip says it was a loss. */
  loss: boolean;
}

/** `23 Oct` for a day; `14:05` for an hour or five minutes (UTC, as the buckets are). */
export function bucketLabel(bucket: string): string {
  if (bucket.length === 10) {
    const [y, m, d] = bucket.split("-").map(Number);
    return new Date(Date.UTC(y, m - 1, d)).toLocaleDateString("en-GB", { day: "numeric", month: "short", timeZone: "UTC" });
  }
  return bucket.slice(11, 16);
}

export function seriesBars(buckets: readonly RevenueBucketLike[]): SeriesBar[] {
  return buckets.map((b) => {
    const loss = b.cost > b.revenue;
    return {
      label: bucketLabel(b.bucket),
      revenue: b.revenue,
      cost: b.cost,
      //never a negative segment: a loss is drawn as its cost, and flagged
      margin: loss ? 0 : b.revenue - b.cost,
      loss,
    };
  });
}

export interface AccountBar {
  account: string;
  revenue: number;
}

/** Accounts drawn one by one; the rest are summed into "Other". */
export const TOP_ACCOUNTS = 7;

/** Revenue per account (the table's rows are account x product), busiest first, the rest as Other. */
export function topAccounts(rows: readonly { accountId: string | null; revenue: number }[]): AccountBar[] {
  const byAccount = new Map<string, number>();
  for (const r of rows) {
    const key = r.accountId ?? "No account";
    byAccount.set(key, (byAccount.get(key) ?? 0) + r.revenue);
  }
  const sorted = [...byAccount.entries()]
    .map(([account, revenue]) => ({ account, revenue }))
    .filter((a) => a.revenue > 0)
    .sort((a, b) => b.revenue - a.revenue);
  if (sorted.length <= TOP_ACCOUNTS) return sorted;
  const shown = sorted.slice(0, TOP_ACCOUNTS - 1);
  const rest = sorted.slice(shown.length);
  return [...shown, { account: `Other (${rest.length})`, revenue: rest.reduce((n, a) => n + a.revenue, 0) }];
}
