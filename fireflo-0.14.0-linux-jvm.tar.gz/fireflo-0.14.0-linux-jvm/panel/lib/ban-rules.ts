/**
 * Rules that turn the gateway's refusal ledger into fail2ban bans, and their evaluation.
 *
 * <p>Pure. Nothing here reads a file, asks the gateway or runs sudo: the runner hands it the
 * `refusalSummary` rows and the rules, and gets back the addresses to ban and why. That is what
 * makes a rule testable, and what keeps the decision in one place whether a ban comes from the
 * minute timer or from an operator pressing a button marked "run now".
 *
 * <h2>Why rules at all, when fail2ban has its own</h2>
 *
 * <p>fail2ban's jail reads the refusal log line by line and bans after `maxretry` lines in
 * `findtime`, with one threshold for every listener and every reason. The ledger is the same facts
 * folded by listener and address, and an operator looking at it wants a different rule per
 * listener -- a public one hammered by scanners, an internal one where ten bad binds is a
 * customer's typo -- and a dry run before any of it. That is this.
 *
 * <h2>What a rule may not ban on</h2>
 *
 * <p>`heldOut`, `ipLimit`, `accountLimit`, `loginLimit` and `productNotAllowed` are refusals of a
 * caller whose credential was accepted, or who is already held out by an operator: a paying
 * customer's fleet reconnecting harder than its cap allows, a hold already in force. The gateway's
 * own fail2ban filter leaves them out (`ignoreregex` in `filter.d/fireflo-gateway.conf`), and a
 * rule with no reasons of its own counts everything except those. A rule that names one of them
 * explicitly is an operator's deliberate choice and is honoured.
 */

/** The gateway's non-bannable reasons. `AuthRefusal.Reason.bannable()` is the same list, negated. */
export const NON_BANNABLE_REASONS: readonly string[] = [
  "heldOut",
  "ipLimit",
  "accountLimit",
  "loginLimit",
  "productNotAllowed",
];

/** Every reason the ledger can carry, for a rule editor to offer. */
export const KNOWN_REASONS: readonly string[] = [
  "missingCredential",
  "unknownIdentity",
  "badPassword",
  "addressNotAllowed",
  "backoff",
  ...NON_BANNABLE_REASONS,
];

export interface BanRule {
  /** Stable, chosen by the panel when the rule is created; the audit log and the run log key on it. */
  id: string;
  /** What the operator called it, for the list. */
  name: string;
  /** A listener's worker name, or `any` for every listener folded together. */
  listener: string;
  /** The reasons that count. Empty means every bannable reason. */
  reasons: string[];
  /** Refusals in the window, from one address, at or above which it is banned. */
  threshold: number;
  windowMinutes: number;
  /**
   * How long the ban is asked to last. Recorded and passed to the wrapper, which today applies the
   * jail's own `bantime` instead and says so; kept here so a wrapper that learns per-ban durations
   * needs no panel change.
   */
  banSeconds: number;
  jail: string;
  enabled: boolean;
  /** Decide and record, but do not ban. The way to try a rule on a live ledger. */
  dryRun: boolean;
}

/** One listener's fold of the ledger, as `refusalSummary` answers it. */
export interface RefusalSummaryRow {
  listener: string | null;
  port: number | null;
  total: number;
  byReason: { reason: string; count: number }[];
  byAddress: RefusalAddress[];
}

export interface RefusalAddress {
  ip: string;
  count: number;
  byReason: { reason: string; count: number }[];
  identities: string[];
  firstAt: string | null;
  lastAt: string | null;
  /** True when an operator is already holding this address out, which is already the response. */
  heldOut: boolean;
}

/** An address a rule says to ban, and the arithmetic that said so. */
export interface BanDecision {
  ip: string;
  ruleId: string;
  ruleName: string;
  jail: string;
  banSeconds: number;
  dryRun: boolean;
  /** The listener whose fold tripped the rule, or null for a rule on `any`. */
  listener: string | null;
  /** Refusals that counted, by the rule's reasons, in the rule's window. */
  count: number;
  threshold: number;
  windowMinutes: number;
  /** The reasons that contributed, with their counts, for the sentence. */
  reasons: { reason: string; count: number }[];
}

/** The reasons this rule counts. */
export function effectiveReasons(rule: Pick<BanRule, "reasons">): Set<string> {
  if (rule.reasons.length > 0) {
    return new Set(rule.reasons);
  }
  return new Set(KNOWN_REASONS.filter((r) => !NON_BANNABLE_REASONS.includes(r)));
}

/**
 * Evaluates one rule against the rows fetched for its window.
 *
 * <p>A rule on `any` sums an address across every listener before comparing, because that is what
 * "any listener" means to the operator who chose it; a rule on one listener reads that fold alone.
 * An address already held out is skipped: the hold is the response, and a ban on top would outlast
 * it. The caller filters out what is already banned and what the never-ban list covers, since both
 * are host facts this function cannot know.
 */
export function decisionsFor(rule: BanRule, rows: readonly RefusalSummaryRow[]): BanDecision[] {
  if (!rule.enabled || rule.threshold < 1) {
    return [];
  }
  const counting = effectiveReasons(rule);
  const totals = new Map<string, { count: number; reasons: Map<string, number>; heldOut: boolean }>();

  for (const row of rows) {
    if (rule.listener !== "any" && row.listener !== rule.listener) {
      continue;
    }
    for (const address of row.byAddress) {
      const entry = totals.get(address.ip) ?? { count: 0, reasons: new Map(), heldOut: false };
      entry.heldOut = entry.heldOut || address.heldOut;
      for (const { reason, count } of address.byReason) {
        if (!counting.has(reason) || count <= 0) {
          continue;
        }
        entry.count += count;
        entry.reasons.set(reason, (entry.reasons.get(reason) ?? 0) + count);
      }
      totals.set(address.ip, entry);
    }
  }

  const out: BanDecision[] = [];
  for (const [ip, entry] of totals) {
    if (entry.heldOut || entry.count < rule.threshold) {
      continue;
    }
    out.push({
      ip,
      ruleId: rule.id,
      ruleName: rule.name,
      jail: rule.jail,
      banSeconds: rule.banSeconds,
      dryRun: rule.dryRun,
      listener: rule.listener === "any" ? null : rule.listener,
      count: entry.count,
      threshold: rule.threshold,
      windowMinutes: rule.windowMinutes,
      reasons: [...entry.reasons].map(([reason, count]) => ({ reason, count })).sort((a, b) => b.count - a.count),
    });
  }
  return out.sort((a, b) => b.count - a.count || a.ip.localeCompare(b.ip));
}

/**
 * Every enabled rule against the rows for its window, one decision per address and jail.
 *
 * <p>The first rule to name an address wins, in the order the rules are listed: two rules banning
 * the same address into the same jail would be one ban and two run-log lines, and the second line
 * would read as a failure. A dry-run rule does not shadow a live one, or trying a rule would switch
 * off the one already protecting the listener.
 *
 * @param rowsByWindow the `refusalSummary` rows fetched per distinct `windowMinutes`
 */
export function evaluateRules(
  rules: readonly BanRule[],
  rowsByWindow: ReadonlyMap<number, readonly RefusalSummaryRow[]>
): BanDecision[] {
  const taken = new Set<string>();
  const out: BanDecision[] = [];
  const ordered = [...rules.filter((r) => r.enabled && !r.dryRun), ...rules.filter((r) => r.enabled && r.dryRun)];
  for (const rule of ordered) {
    const rows = rowsByWindow.get(rule.windowMinutes);
    if (!rows) {
      continue;
    }
    for (const decision of decisionsFor(rule, rows)) {
      const key = `${decision.jail} ${decision.ip}`;
      if (taken.has(key)) {
        continue;
      }
      taken.add(key);
      out.push(decision);
    }
  }
  return out;
}

/** "203.0.113.9: 14 refusals on smppserver.main in 10 min (badPassword 12, unknownIdentity 2), threshold 10" */
export function decisionSentence(d: BanDecision): string {
  const where = d.listener ? ` on ${d.listener}` : "";
  const reasons = d.reasons.map((r) => `${r.reason} ${r.count}`).join(", ");
  return `${d.ip}: ${d.count} refusals${where} in ${d.windowMinutes} min (${reasons}), threshold ${d.threshold}`;
}

/** The ceilings a rule's numbers are held to, so a typo cannot ask for a week-long window. */
export const RULE_LIMITS = {
  threshold: { min: 1, max: 100_000 },
  windowMinutes: { min: 1, max: 24 * 60 },
  banSeconds: { min: 60, max: 30 * 24 * 3600 },
} as const;

const RULE_ID = /^[A-Za-z0-9_-]{1,40}$/;
const LISTENER = /^[^\s=]{1,80}$/;

/**
 * Reads a rule out of whatever a request body held, or says what is wrong with it.
 *
 * <p>Shared by the rules route and the test, so the two agree on what a rule is. Returns a fresh
 * object with only the known fields: an unknown key is dropped rather than stored.
 */
export function normaliseRule(input: unknown, jails: readonly string[]): BanRule | { error: string } {
  const row = (input ?? {}) as Record<string, unknown>;
  const id = typeof row.id === "string" ? row.id.trim() : "";
  if (!RULE_ID.test(id)) {
    return { error: "A rule needs an id of letters, digits, - and _ (up to 40)." };
  }
  const name = typeof row.name === "string" ? row.name.trim().slice(0, 80) : "";
  const listener = typeof row.listener === "string" && row.listener.trim() ? row.listener.trim() : "any";
  if (!LISTENER.test(listener)) {
    return { error: `${id}: the listener must be a worker name (no spaces or =) or "any".` };
  }
  const reasonsRaw = Array.isArray(row.reasons) ? row.reasons : [];
  const reasons = reasonsRaw.filter((r): r is string => typeof r === "string" && /^[A-Za-z]{1,40}$/.test(r));
  if (reasons.length !== reasonsRaw.length) {
    return { error: `${id}: reasons must be the gateway's reason tokens.` };
  }
  const threshold = whole(row.threshold);
  const windowMinutes = whole(row.windowMinutes);
  const banSeconds = whole(row.banSeconds);
  for (const [field, value] of [
    ["threshold", threshold],
    ["windowMinutes", windowMinutes],
    ["banSeconds", banSeconds],
  ] as const) {
    const { min, max } = RULE_LIMITS[field];
    if (value === null || value < min || value > max) {
      return { error: `${id}: ${field} must be a whole number from ${min} to ${max}.` };
    }
  }
  const jail = typeof row.jail === "string" && row.jail.trim() ? row.jail.trim() : jails[0];
  if (!jails.includes(jail)) {
    return { error: `${id}: the jail must be one of ${jails.join(", ")}.` };
  }
  return {
    id,
    name: name || id,
    listener,
    reasons,
    threshold: threshold as number,
    windowMinutes: windowMinutes as number,
    banSeconds: banSeconds as number,
    jail,
    enabled: row.enabled === true,
    //on by default: a rule somebody forgot to switch live records what it would do and bans
    //nobody, which is the safer of the two mistakes
    dryRun: row.dryRun !== false,
  };
}

function whole(value: unknown): number | null {
  const n = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isInteger(n) ? n : null;
}

/** Operator words for the fields a rule editor shows. */
export const RULE_FIELD_LABELS: Record<keyof Omit<BanRule, "id">, string> = {
  name: "Name",
  listener: "Listener",
  reasons: "Reasons that count",
  threshold: "Refusals before a ban",
  windowMinutes: "In the last (minutes)",
  banSeconds: "Ban for (seconds)",
  jail: "Jail",
  enabled: "Enabled",
  dryRun: "Dry run (record, do not ban)",
};
