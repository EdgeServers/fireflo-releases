import { strict as assert } from "node:assert";
import { test } from "node:test";

import { smsLength } from "./sms-length.ts";

test("plain text is GSM-7, one septet a character", () => {
  assert.deepEqual(smsLength("Your code is 123456"), { chars: 19, encoding: "GSM-7", units: 19, parts: 1 });
});

test("an extension character takes two septets", () => {
  const r = smsLength("Pay €10 [ref]");
  assert.equal(r.encoding, "GSM-7");
  assert.equal(r.units, 13 + 3);
});

test("GSM-7 parts break at 160, then 153 a part", () => {
  assert.equal(smsLength("a".repeat(160)).parts, 1);
  assert.equal(smsLength("a".repeat(161)).parts, 2);
  assert.equal(smsLength("a".repeat(306)).parts, 2);
  assert.equal(smsLength("a".repeat(307)).parts, 3);
  //an extension character near the edge pushes it over
  assert.equal(smsLength("a".repeat(159) + "€").parts, 2);
});

test("anything outside the alphabet makes it Unicode: 70, then 67 a part", () => {
  const hindi = smsLength("प्रिय ग्राहक");
  assert.equal(hindi.encoding, "Unicode");
  assert.equal(smsLength("é".repeat(70)).encoding, "GSM-7", "é is in the basic table");
  assert.equal(smsLength("ê".repeat(70)).parts, 1);
  assert.equal(smsLength("ê".repeat(71)).parts, 2);
  assert.equal(smsLength("ê".repeat(134)).parts, 2);
  assert.equal(smsLength("ê".repeat(135)).parts, 3);
});

test("an emoji is one character but two UCS-2 units", () => {
  const r = smsLength("Hi 😀");
  assert.equal(r.chars, 4);
  assert.equal(r.units, 5);
});

test("an empty body takes no message", () => {
  assert.equal(smsLength("").parts, 0);
});
