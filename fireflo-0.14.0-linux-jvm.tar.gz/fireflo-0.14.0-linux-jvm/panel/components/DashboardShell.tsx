"use client";
import { useState, useEffect, type ReactNode } from "react";
import { usePathname } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import { isAdminSession } from "@/lib/roles";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Sidebar } from "./Sidebar";
import { TopBar } from "./TopBar";
import { PinsProvider, usePinsOptional } from "./usePins";
import { DEFAULT_PINS } from "@/lib/pins";
import { UserMenu } from "./UserMenu";
import { PanelFooter } from "./PanelFooter";

/** Remembered per browser, like the CDR column chooser. */
const COLLAPSED_KEY = "fireflo.sidebar.collapsed";

export function DashboardShell({
  children,
  banner,
}: {
  children: ReactNode;
  /**
   * The licence and schema notices, rendered under the top bar.
   *
   * <p>A slot rather than an import so the layout keeps deciding what warns. It used to sit above
   * this whole shell, outside the `h-screen` box, so a visible banner made the document taller
   * than the viewport and the body scrolled behind `main`. Inside the content column it takes its
   * height from the same flex that sizes `main`.
   */
  banner?: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const pathname = usePathname();
  const { data: session } = useSession();
  const operator = session?.user?.name ?? "";
  const user = { name: operator, role: session?.user?.role ?? null, admin: isAdminSession(session) };

  /**
   * The collapse preference, and a sensible first answer when there is none.
   *
   * <p>Read after mount rather than during render: `localStorage` and `matchMedia` do not exist on
   * the server, and React 19 throws on the resulting mismatch instead of patching it up. The cost is
   * one frame of the expanded rail on a tablet, which is why the width transitions.
   *
   * <p>The default differs by size on purpose. A 256px sidebar is a fifth of a desktop and a third of
   * a tablet, so a tablet starts collapsed and a desktop starts open — and either can be changed,
   * after which the stored choice wins everywhere.
   */
  useEffect(() => {
    const stored = window.localStorage.getItem(COLLAPSED_KEY);
    setCollapsed(
      stored != null ? stored === "1" : window.matchMedia("(max-width: 1023px)").matches
    );
  }, []);

  /**
   * Writes the preference, then the state.
   *
   * <p>The write is deliberately outside the state updater. An updater must be a pure function of its
   * argument — React is free to call it more than once for a single update, and does exactly that in
   * development — so a `localStorage.setItem` in there is a side effect fired an unpredictable number
   * of times. It happens to be idempotent here, which is precisely the kind of accident that stops
   * being true the moment the body grows.
   */
  function toggleCollapsed() {
    const next = !collapsed;
    window.localStorage.setItem(COLLAPSED_KEY, next ? "1" : "0");
    setCollapsed(next);
  }

  //Close the drawer when the route changes, i.e. a nav link was tapped.
  //
  //Adjusted during render rather than in an effect. An effect runs after paint, so the drawer would
  //stay open over the newly-rendered page for a frame before closing -- visible as a flicker on the
  //one device this drawer exists for.
  const [seenPathname, setSeenPathname] = useState(pathname);
  if (seenPathname !== pathname) {
    //updated first, or this branch fires again on the re-render it causes
    setSeenPathname(pathname);
    setOpen(false);
  }

  // Prevent body scroll when drawer is open on mobile
  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  return (
    <PinsProvider>
    <div className="flex h-screen overflow-hidden">
      {/* ── Desktop sidebar (always visible ≥ lg) ── */}
      {/* persistent from tablet up. Below that it is a drawer, because at phone widths even a 64px
          rail is a meaningful share of the screen */}
      <div className="relative hidden shrink-0 md:flex">
        <Sidebar collapsed={collapsed} user={user} />
        {/* on the border rather than in the footer: it is a control over the panel's edge, so it
            belongs on that edge — and it stays put whether the rail is open or shut, which a footer
            button does not. Overhangs by half its width, which is what makes it read as attached to
            the divider rather than floating in the content */}
        <button
          onClick={toggleCollapsed}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          aria-expanded={!collapsed}
          title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          className="absolute -right-3 top-[42px] z-30 flex h-6 w-6 items-center justify-center rounded-full border border-border bg-card text-muted-foreground shadow-sm transition-colors hover:bg-muted hover:text-foreground"
        >
          {collapsed ? (
            <ChevronRight className="h-3.5 w-3.5" />
          ) : (
            <ChevronLeft className="h-3.5 w-3.5" />
          )}
        </button>
      </div>

      {/* ── Mobile/tablet drawer ── */}
      {/* Backdrop */}
      <div
        className={`fixed inset-0 z-40 bg-black/50 backdrop-blur-sm transition-opacity duration-300 md:hidden ${
          open ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
        onClick={() => setOpen(false)}
        aria-hidden="true"
      />
      {/* Drawer panel */}
      <div
        className={`fixed inset-y-0 left-0 z-50 transition-transform duration-300 ease-in-out md:hidden ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <Sidebar onClose={() => setOpen(false)} user={user} />
      </div>

      {/* ── Main content area ── */}
      <div className="flex flex-1 flex-col overflow-hidden">
        <PinnedTopBar
          onMenuClick={() => setOpen(true)}
          jump
          health
          user={
            <UserMenu
              name={operator}
              role={session?.user?.role ?? null}
              //the env-fallback operator has no row, so no password of its own to change
              canChangePassword={session?.user?.userId != null}
              onSignOut={() => signOut({ callbackUrl: "/cp/login" })}
            />
          }
        />
        {banner}

        <main className="flex-1 overflow-y-auto bg-background">
          {/* the inner wrapper owns the padding and the width cap, so `main` stays the scroll
              container the sticky SaveBar and the side rails measure against */}
          <div className="mx-auto w-full max-w-[1440px] space-y-5 p-4 md:p-6">
            {children}
            {/* inside the scrolling region: this container is `overflow-hidden` and only `main`
                scrolls, so a footer after the shell would sit below the viewport with nothing able to
                reach it. The `space-y-5` above gives it its gap from the last card */}
            <PanelFooter />
          </div>
        </main>
      </div>
    </div>
    </PinsProvider>
  );
}

/** The operator's top bar, with the pages they pinned (the defaults until they pin one). */
function PinnedTopBar(props: Omit<React.ComponentProps<typeof TopBar>, "quick" | "onUnpin">) {
  const pins = usePinsOptional();
  return <TopBar {...props} quick={pins?.pins ?? DEFAULT_PINS} onUnpin={pins?.unpin} />;
}
