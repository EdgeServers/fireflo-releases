"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Archive, Download, RotateCcw, Search, TriangleAlert } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { EmptyState } from "@/components/ui/empty-state";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { PageHeader } from "@/components/ui/page-header";
import { Select } from "@/components/ui/select";
import { TBody, TD, TH, THead, TR, TableFooter, TableInCard } from "@/components/ui/table";
import { TabPanel, Tabs, useReportBusy } from "@/components/ui/tabs";
import { useWorkerNames } from "@/components/CdrFilterBar";
import { FILTER_WIDTH } from "@/lib/filter-widths";
import { RANGES } from "@/lib/cdr-request";
import { csv } from "@/lib/csv";
import { bytes, count, moneyFromBigintString } from "@/lib/format";
import { formatTimestamp } from "@/lib/datetime";
import {
  ARCHIVE_GATEWAY_RELEASE,
  ARCHIVE_STORES,
  BATCH_STORES,
  STORE_LABEL,
  selectorLine,
  type ArchiveAccountRow,
  type ArchiveBatch,
  type ArchiveCursor,
  type ArchiveEntry,
  type ArchivePartition,
} from "@/lib/archives-types";
import {
  ARCHIVE_TABS,
  EMPTY_ARCHIVE_ENTRY_FORM,
  entryFormFromQuery,
  entryFormToQuery,
  isArchiveTab,
  type ArchiveEntryForm,
  type ArchiveTab,
} from "@/lib/archives-request";

const PAGE_SIZE = 50;
const DOCS_CLI = "https://docs.fireflo.au/reference/cli/fireflo#queues";

const TAB_LABEL: Record<ArchiveTab, string> = {
  partitions: "Partitions",
  accounts: "By account",
  entries: "Entries",
  batches: "Batches",
};

/** One read of an archive route: the data, or "this gateway has no archive yet", or the error. */
type Read<T> = { state: "loading" } | { state: "missing"; release: string } | { state: "error"; error: string } | ({ state: "ok" } & T);

async function readArchive<T>(url: string): Promise<Read<T>> {
  try {
    const res = await fetch(url, { cache: "no-store" });
    const body = await res.json().catch(() => null);
    if (!res.ok) {
      return { state: "error", error: body?.error ?? `Request failed (${res.status})` };
    }
    const data = body?.data;
    if (data?.available === false) {
      return { state: "missing", release: data.release ?? ARCHIVE_GATEWAY_RELEASE };
    }
    return { state: "ok", ...(data as T) };
  } catch {
    return { state: "error", error: "Could not reach the panel's API." };
  }
}

/** Writes the tab (and the entry filters, when on Entries) back to the address. */
function writeUrl(tab: ArchiveTab, entry?: ArchiveEntryForm) {
  const params = tab === "entries" && entry ? entryFormToQuery(entry) : new URLSearchParams();
  params.set("tab", tab);
  //replaceState, as on Refused: no server round trip and no history entry per filter
  window.history.replaceState(null, "", `?${params}`);
}

/**
 * Reports → Archives: what housekeeping took off the gateway's queues, and the runs that took it.
 *
 * <p>Read-only. Cleaning a queue happens on the Queues page and the vendor and listener pages, or on
 * the command line; deleting archive months is command-line only. This page reads the archive the
 * gateway writes in the same transaction as the clean, so what it shows is what happened.
 *
 * <p>The By account tab is the reconciliation view. It reads the per-day summary the gateway keeps
 * forever, never the detail rows, so its totals do not move when old months are purged.
 */
export function ArchivesClient() {
  const [tab, setTab] = useState<ArchiveTab>("partitions");
  const [entryForm, setEntryForm] = useState<ArchiveEntryForm>(EMPTY_ARCHIVE_ENTRY_FORM);
  const [ready, setReady] = useState(false);
  const [recent, setRecent] = useState<Read<{ batches: ArchiveBatch[] }>>({ state: "loading" });

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const t = params.get("tab");
    //a ?batch= link with no tab is a link to that batch's entries
    const initialTab: ArchiveTab = isArchiveTab(t) ? t : params.get("batch") ? "entries" : "partitions";
    //eslint-disable-next-line react-hooks/set-state-in-effect -- the address is only readable after mount
    setTab(initialTab);
    setEntryForm(entryFormFromQuery(params));
    setReady(true);
    void readArchive<{ batches: ArchiveBatch[] }>("/api/control/archives/batches?limit=5").then(setRecent);
  }, []);

  //the tab whose content is being read, for the spinner on its label
  const [busyTab, setBusyTab] = useState<ArchiveTab | null>(null);
  const reportTabBusy = useCallback((busy: boolean) => setBusyTab(busy ? tab : null), [tab]);

  function choose(next: ArchiveTab) {
    setTab(next);
    writeUrl(next, entryForm);
  }

  function showBatch(batchId: string) {
    const next = { ...EMPTY_ARCHIVE_ENTRY_FORM, range: "all", batch: batchId };
    setEntryForm(next);
    setTab("entries");
    writeUrl("entries", next);
  }

  if (recent.state === "missing") {
    return (
      <>
        <PageHeader title="Archives" description="What queue housekeeping took off the gateway, and the runs that took it." />
        <Card>
          <CardContent className="space-y-2 py-5 text-sm">
            <p className="font-medium">Available from gateway {recent.release}.</p>
            <p className="text-muted-foreground">
              The queue archive arrives with that release&apos;s database update. This gateway&apos;s database has
              not had it yet, so there is nothing archived to show — and nothing here is wrong.
            </p>
          </CardContent>
        </Card>
      </>
    );
  }

  return (
    <>
      <PageHeader
        title="Archives"
        description="What queue housekeeping took off the gateway, and the runs that took it. Every archived message was ended: refunded if charged, a failed receipt where one was asked for, recorded as refused (operatorPurge)."
      />

      <RecentBatches read={recent} onShow={showBatch} />

      <Card>
        <CardContent className="space-y-4 pt-4">
          <Tabs label="Archives" items={ARCHIVE_TABS.map((id) => ({ id, label: TAB_LABEL[id] }))} active={tab} onSelect={choose} busyId={busyTab} />
          <TabPanel onBusy={reportTabBusy}>
          {ready && tab === "partitions" && <PartitionsTab />}
          {ready && tab === "accounts" && <AccountsTab />}
          {ready && tab === "entries" && (
            <EntriesTab
              form={entryForm}
              onApply={(next) => {
                setEntryForm(next);
                writeUrl("entries", next);
              }}
            />
          )}
          {ready && tab === "batches" && <BatchesTab onShow={showBatch} />}
          </TabPanel>
        </CardContent>
      </Card>

      <p className="text-sm text-muted-foreground">
        Archive months are deleted only from the command line, after each month is reconciled against the
        summary: <code className="font-mono">fireflo queue archive purge --before 2026-04</code>. The summary
        rows are kept, so By account reads the same before and after.{" "}
        <a href={DOCS_CLI} target="_blank" rel="noreferrer" className="text-primary hover:underline">
          Command reference →
        </a>
      </p>
    </>
  );
}

function Problem({ text }: { text: string }) {
  return (
    <p className="flex items-start gap-2 text-sm text-destructive">
      <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" /> {text}
    </p>
  );
}

function Missing({ release }: { release: string }) {
  return <p className="text-sm text-muted-foreground">Available from gateway {release}.</p>;
}

function RecentBatches({ read, onShow }: { read: Read<{ batches: ArchiveBatch[] }>; onShow: (id: string) => void }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>
          <Archive className="mr-2 inline h-4 w-4 text-muted-foreground" />
          Latest runs
        </CardTitle>
        <CardDescription>Cleans, archive purges and receipt re-pushes, newest first.</CardDescription>
      </CardHeader>
      <CardContent>
        {read.state === "loading" && <p className="text-sm text-muted-foreground">Loading…</p>}
        {read.state === "error" && <Problem text={read.error} />}
        {read.state === "ok" && read.batches.length === 0 && (
          <p className="text-sm text-muted-foreground">Nothing has been archived yet.</p>
        )}
        {read.state === "ok" && read.batches.length > 0 && <BatchTable batches={read.batches} onShow={onShow} />}
      </CardContent>
    </Card>
  );
}

function BatchTable({ batches, onShow }: { batches: ArchiveBatch[]; onShow: (id: string) => void }) {
  return (
    <TableInCard>
      <THead>
        <TR>
          <TH>When</TH>
          <TH>What</TH>
          <TH>Who</TH>
          <TH>Selector</TH>
          <TH align="right">Matched</TH>
          <TH align="right">Archived</TH>
          <TH align="right">Refunded</TH>
          <TH align="right">Receipts</TH>
          <TH align="right">Failed</TH>
          <TH>Note</TH>
        </TR>
      </THead>
      <TBody>
        {batches.map((b) => (
          <TR key={b.batchId} className="align-top">
            <TD muted className="whitespace-nowrap">
              <button type="button" onClick={() => onShow(b.batchId)} className="text-primary hover:underline" title={`Batch ${b.batchId}: show its entries`}>
                {formatTimestamp(b.startedAt)}
              </button>
              {!b.finishedAt && <Badge variant="outline" className="ml-2">running</Badge>}
            </TD>
            <TD>{STORE_LABEL[b.store] ?? b.store}</TD>
            <TD className="font-mono text-xs">{b.actor || "—"}</TD>
            <TD className="max-w-[18rem] break-words font-mono text-xs">{selectorLine(b.selector)}</TD>
            <TD align="right">{b.matched != null ? count(b.matched) : "—"}</TD>
            <TD align="right">{b.archived != null ? count(b.archived) : "—"}</TD>
            <TD align="right">{b.refunded != null ? count(b.refunded) : "—"}</TD>
            <TD align="right">{b.receiptsSent != null ? count(b.receiptsSent) : "—"}</TD>
            <TD align="right" className={b.failed ? "text-destructive" : undefined}>{b.failed != null ? count(b.failed) : "—"}</TD>
            <TD muted className="max-w-[16rem] break-words">{b.note || "—"}</TD>
          </TR>
        ))}
      </TBody>
    </TableInCard>
  );
}

function PartitionsTab() {
  const [read, setRead] = useState<Read<{ partitions: ArchivePartition[] }>>({ state: "loading" });
  useReportBusy(read.state === "loading");
  useEffect(() => {
    void readArchive<{ partitions: ArchivePartition[] }>("/api/control/archives/partitions").then(setRead);
  }, []);

  if (read.state === "loading") return <p className="text-sm text-muted-foreground">Loading…</p>;
  if (read.state === "error") return <Problem text={read.error} />;
  if (read.state === "missing") return <Missing release={read.release} />;

  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground">
        One row per month. A purged month has lost its detail rows and kept its summary: By account still counts
        it, and says how much of each account&apos;s total is purged.
      </p>
      <TableInCard>
        <THead>
          <TR>
            <TH>Month</TH>
            <TH align="right">Rows held</TH>
            <TH>First archived</TH>
            <TH>Last archived</TH>
            <TH align="right">Size</TH>
            <TH>Purged</TH>
          </TR>
        </THead>
        <TBody>
          {read.partitions.map((p) => (
            <TR key={p.month ?? "default"}>
              <TD className="font-mono">{p.month ?? "default"}</TD>
              <TD align="right">{p.rows != null ? count(p.rows) : "—"}</TD>
              <TD muted>{p.firstAt ? formatTimestamp(p.firstAt) : "—"}</TD>
              <TD muted>{p.lastAt ? formatTimestamp(p.lastAt) : "—"}</TD>
              <TD align="right" muted>{p.sizeBytes != null ? bytes(p.sizeBytes) : "—"}</TD>
              <TD muted>
                {p.purgedAt
                  ? `purged on ${formatTimestamp(p.purgedAt)}, ${count(p.purgedRows ?? 0)} rows`
                  : "—"}
              </TD>
            </TR>
          ))}
        </TBody>
      </TableInCard>
      {read.partitions.length === 0 && <p className="text-sm text-muted-foreground">No partitions yet.</p>}
    </div>
  );
}

function AccountsTab() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [account, setAccount] = useState("");
  const [read, setRead] = useState<Read<{ accounts: ArchiveAccountRow[] }>>({ state: "loading" });
  useReportBusy(read.state === "loading");

  const load = useCallback(async (f: string, t: string, a: string) => {
    setRead({ state: "loading" });
    const params = new URLSearchParams();
    if (f) params.set("from", f);
    if (t) params.set("to", t);
    if (a.trim()) params.set("account", a.trim());
    setRead(await readArchive<{ accounts: ArchiveAccountRow[] }>(`/api/control/archives/accounts?${params}`));
  }, []);

  useEffect(() => {
    //eslint-disable-next-line react-hooks/set-state-in-effect -- the first read, with no filters
    void load("", "", "");
  }, [load]);

  function download(rows: ArchiveAccountRow[]) {
    const header = ["account", "messages", "refunded", "receipts_sent", "price_total", "first_at", "last_at", "held", "purged"];
    const lines = [header.join(",")].concat(
      rows.map((r) =>
        [r.accountId, r.messages, r.refunded, r.receiptsSent, scaled(r.priceTotal), r.firstAt, r.lastAt, r.held, r.purged].map(csv).join(",")
      )
    );
    const blob = new Blob([`${lines.join("\r\n")}\r\n`], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `archive-by-account${from ? `-${from}` : ""}${to ? `-to-${to}` : ""}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-3">
      <form
        className="flex flex-wrap items-end gap-3"
        onSubmit={(e) => {
          e.preventDefault();
          void load(from, to, account);
        }}
      >
        <Field label="From" className={FILTER_WIDTH.select}>
          <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        </Field>
        <Field label="To" className={FILTER_WIDTH.select}>
          <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </Field>
        <Field label="Account" className={FILTER_WIDTH.account}>
          <Input value={account} onChange={(e) => setAccount(e.target.value)} placeholder="exact" />
        </Field>
        <Button type="submit" className="gap-2" disabled={read.state === "loading"}>
          <Search className="h-4 w-4" /> Show
        </Button>
        {read.state === "ok" && read.accounts.length > 0 && (
          <Button type="button" variant="outline" className="gap-2" onClick={() => download(read.accounts)}>
            <Download className="h-4 w-4" /> CSV
          </Button>
        )}
      </form>
      <p className="text-sm text-muted-foreground">
        Days in the billing zone, both ends included; empty means all time. Read from the summary the gateway keeps
        forever, so these totals are what the command line&apos;s <code className="font-mono">queue archive summary --by account</code>{" "}
        prints, before and after a purge.
      </p>
      {read.state === "loading" && <p className="text-sm text-muted-foreground">Loading…</p>}
      {read.state === "error" && <Problem text={read.error} />}
      {read.state === "missing" && <Missing release={read.release} />}
      {read.state === "ok" && read.accounts.length === 0 && (
        <p className="text-sm text-muted-foreground">Nothing was archived in this period.</p>
      )}
      {read.state === "ok" && read.accounts.length > 0 && (
        <TableInCard>
          <THead>
            <TR>
              <TH>Account</TH>
              <TH align="right">Messages</TH>
              <TH align="right">Refunded</TH>
              <TH align="right">Receipts sent</TH>
              <TH align="right">Price total</TH>
              <TH>First</TH>
              <TH>Last</TH>
              <TH align="right">Held</TH>
              <TH align="right">Purged</TH>
            </TR>
          </THead>
          <TBody>
            {read.accounts.map((r) => (
              <TR key={r.accountId ?? "(none)"}>
                <TD className="font-mono">{r.accountId ?? "—"}</TD>
                <TD align="right">{count(r.messages)}</TD>
                <TD align="right">{count(r.refunded)}</TD>
                <TD align="right">{count(r.receiptsSent)}</TD>
                <TD align="right" className="font-mono">{scaled(r.priceTotal) || "—"}</TD>
                <TD muted>{r.firstAt ? formatTimestamp(r.firstAt) : "—"}</TD>
                <TD muted>{r.lastAt ? formatTimestamp(r.lastAt) : "—"}</TD>
                <TD align="right">{count(r.held)}</TD>
                <TD align="right" muted>{count(r.purged)}</TD>
              </TR>
            ))}
          </TBody>
        </TableInCard>
      )}
    </div>
  );
}

function EntriesTab({ form, onApply }: { form: ArchiveEntryForm; onApply: (next: ArchiveEntryForm) => void }) {
  const [draft, setDraft] = useState(form);
  const [rows, setRows] = useState<ArchiveEntry[]>([]);
  const [nextCursor, setNextCursor] = useState<ArchiveCursor | null>(null);
  const [history, setHistory] = useState<(ArchiveCursor | null)[]>([null]);
  const [error, setError] = useState<string | null>(null);
  const [missing, setMissing] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  useReportBusy(loading);
  const names = useWorkerNames();

  //the form changes underneath when a batch link is followed from the strip above
  const [seen, setSeen] = useState(form);
  if (seen !== form) {
    setSeen(form);
    setDraft(form);
  }

  const load = useCallback(async (f: ArchiveEntryForm, cursor: ArchiveCursor | null) => {
    setLoading(true);
    const params = entryFormToQuery(f);
    //the default range is not written to the URL, but the route must still be told it
    params.set("range", f.range || EMPTY_ARCHIVE_ENTRY_FORM.range);
    params.set("limit", String(PAGE_SIZE));
    if (cursor) {
      params.set("cursorTs", cursor.archivedAt);
      params.set("cursorId", cursor.id);
    }
    const read = await readArchive<{ rows: ArchiveEntry[]; nextCursor: ArchiveCursor | null }>(`/api/control/archives/entries?${params}`);
    if (read.state === "ok") {
      setRows(read.rows);
      setNextCursor(read.nextCursor);
      setError(null);
      setMissing(null);
    } else {
      setRows([]);
      setNextCursor(null);
      setError(read.state === "error" ? read.error : null);
      setMissing(read.state === "missing" ? read.release : null);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    //eslint-disable-next-line react-hooks/set-state-in-effect -- a new filter set starts at page one
    setHistory([null]);
    void load(form, null);
  }, [form, load]);

  const set = <K extends keyof ArchiveEntryForm>(key: K, value: ArchiveEntryForm[K]) => setDraft((d) => ({ ...d, [key]: value }));
  const page = history.length;
  const showBody = rows.some((r) => r.body != null);

  return (
    <div className="space-y-3">
      <form
        className="flex flex-wrap items-end gap-3"
        onSubmit={(e) => {
          e.preventDefault();
          onApply(draft);
        }}
      >
        <Field label="Period" className={FILTER_WIDTH.select}>
          <Select value={draft.range} onChange={(e) => set("range", e.target.value)}>
            {Object.keys(RANGES).map((key) => (
              <option key={key} value={key}>{key === "all" ? "All time" : `Last ${key}`}</option>
            ))}
          </Select>
        </Field>
        <Field label="Account" className={FILTER_WIDTH.account}>
          <Input value={draft.account} onChange={(e) => set("account", e.target.value)} placeholder="exact" />
        </Field>
        <Field label="Vendor or listener" className={FILTER_WIDTH.text}>
          <Input value={draft.worker} onChange={(e) => set("worker", e.target.value)} placeholder="any" list="archive-workers" />
          <datalist id="archive-workers">
            {[...names.vendors, ...names.servers].map((n) => <option key={n} value={n} />)}
          </datalist>
        </Field>
        <Field label="System id" className={FILTER_WIDTH.account}>
          <Input value={draft.systemId} onChange={(e) => set("systemId", e.target.value)} placeholder="exact" />
        </Field>
        <Field label="Store" className={FILTER_WIDTH.choice}>
          <Select value={draft.store} onChange={(e) => set("store", e.target.value)}>
            <option value="">Any store</option>
            {ARCHIVE_STORES.map((s) => <option key={s} value={s}>{STORE_LABEL[s]}</option>)}
          </Select>
        </Field>
        <Field label="Batch" className={FILTER_WIDTH.text}>
          <Input value={draft.batch} onChange={(e) => set("batch", e.target.value)} placeholder="batch id" />
        </Field>
        <Field label="Message id" className={FILTER_WIDTH.text}>
          <Input value={draft.msgId} onChange={(e) => set("msgId", e.target.value)} placeholder="exact" />
        </Field>
        <Button type="submit" className="gap-2" disabled={loading}>
          <Search className="h-4 w-4" /> {loading ? "Searching…" : "Search"}
        </Button>
        <Button type="button" variant="ghost" className="gap-2" onClick={() => onApply({ ...EMPTY_ARCHIVE_ENTRY_FORM, range: draft.range })}>
          <RotateCcw className="h-4 w-4" /> Clear
        </Button>
      </form>

      {error && <Problem text={error} />}
      {missing && <Missing release={missing} />}
      {!error && !missing && !rows.length && (
        <EmptyState>{loading ? "Loading…" : "Nothing archived matches these filters in this period"}</EmptyState>
      )}

      {rows.length > 0 && (
        <>
          <TableInCard>
            <THead>
              <TR>
                <TH>Archived</TH>
                <TH>Store</TH>
                <TH>Account</TH>
                <TH>Vendor / listener</TH>
                <TH>System id</TH>
                <TH>Message</TH>
                <TH>From → To</TH>
                <TH align="right">Price</TH>
                <TH>Outcome</TH>
                <TH>Who and why</TH>
                {showBody && <TH>Text</TH>}
              </TR>
            </THead>
            <TBody>
              {rows.map((r) => {
                const id = r.gatewayMsgId || r.serial;
                return (
                  <TR key={r.id} className="align-top">
                    <TD muted className="whitespace-nowrap">{formatTimestamp(r.archivedAt)}</TD>
                    <TD className="whitespace-nowrap">
                      {STORE_LABEL[r.store] ?? r.store}
                      {r.subStore && <span className="text-muted-foreground"> · {r.subStore}</span>}
                      <div className="text-2xs text-muted-foreground">{r.kind}</div>
                    </TD>
                    <TD className="font-mono">{r.accountId || "—"}</TD>
                    <TD className="font-mono text-xs">{r.worker || "—"}</TD>
                    <TD className="font-mono text-xs">{r.systemId || "—"}</TD>
                    <TD className="font-mono text-xs">
                      {id ? (
                        <Link href={`/cp/cdrs/${encodeURIComponent(id)}`} className="text-primary hover:underline">{id}</Link>
                      ) : "—"}
                      {r.parts != null && r.parts > 1 && <span className="text-muted-foreground"> · {r.parts} parts</span>}
                    </TD>
                    <TD className="whitespace-nowrap font-mono text-xs">{r.sourceAddr || "—"} → {r.destAddr || "—"}</TD>
                    <TD align="right" className="font-mono text-xs">{scaled(r.price) || "—"}</TD>
                    <TD className="whitespace-nowrap text-xs">
                      {r.refunded ? <Badge variant="success">refunded</Badge> : <span className="text-muted-foreground">no refund</span>}
                      {r.receiptSent && <Badge variant="outline" className="ml-1">receipt sent</Badge>}
                    </TD>
                    <TD className="max-w-[16rem] text-xs">
                      <div className="font-mono">{r.actor || "—"}</div>
                      {r.note && <div className="break-words text-muted-foreground">{r.note}</div>}
                      {r.batchId && (
                        <button type="button" className="text-2xs text-primary hover:underline" onClick={() => onApply({ ...EMPTY_ARCHIVE_ENTRY_FORM, range: "all", batch: r.batchId! })}>
                          batch {r.batchId.slice(0, 8)}…
                        </button>
                      )}
                    </TD>
                    {showBody && <TD className="max-w-[18rem] break-words text-xs">{r.body ?? <span className="text-muted-foreground">not kept</span>}</TD>}
                  </TR>
                );
              })}
            </TBody>
          </TableInCard>
          <TableFooter
            from={(page - 1) * PAGE_SIZE + 1}
            to={(page - 1) * PAGE_SIZE + rows.length}
            noun="archived entries"
            onPrev={() => {
              if (history.length < 2) return;
              const trimmed = history.slice(0, -1);
              setHistory(trimmed);
              void load(form, trimmed[trimmed.length - 1]);
            }}
            onNext={() => {
              if (!nextCursor) return;
              setHistory((h) => [...h, nextCursor]);
              void load(form, nextCursor);
            }}
            prevDisabled={page < 2 || loading}
            nextDisabled={!nextCursor || loading}
          />
        </>
      )}
    </div>
  );
}

function BatchesTab({ onShow }: { onShow: (id: string) => void }) {
  const [store, setStore] = useState("");
  const [read, setRead] = useState<Read<{ batches: ArchiveBatch[] }>>({ state: "loading" });
  useReportBusy(read.state === "loading");
  useEffect(() => {
    //eslint-disable-next-line react-hooks/set-state-in-effect -- re-read when the store changes
    setRead({ state: "loading" });
    void readArchive<{ batches: ArchiveBatch[] }>(`/api/control/archives/batches?limit=100${store ? `&store=${store}` : ""}`).then(setRead);
  }, [store]);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end gap-3">
        <Field label="What" className={FILTER_WIDTH.choice}>
          <Select value={store} onChange={(e) => setStore(e.target.value)}>
            <option value="">Every run</option>
            {BATCH_STORES.map((s) => <option key={s} value={s}>{STORE_LABEL[s] ?? s}</option>)}
          </Select>
        </Field>
      </div>
      {read.state === "loading" && <p className="text-sm text-muted-foreground">Loading…</p>}
      {read.state === "error" && <Problem text={read.error} />}
      {read.state === "missing" && <Missing release={read.release} />}
      {read.state === "ok" && read.batches.length === 0 && <p className="text-sm text-muted-foreground">No runs.</p>}
      {read.state === "ok" && read.batches.length > 0 && <BatchTable batches={read.batches} onShow={onShow} />}
      <p className="text-sm text-muted-foreground">
        A receipt re-push archives nothing: its row records who re-sent which login&apos;s receipts, for which period, and
        how many went out.
      </p>
    </div>
  );
}

/**
 * A price or price total as the archive stores it -- ten-thousandths of the platform currency, the
 * same scale as `cdr_submit.price` -- shown at four places, as the command line prints it. Exact on
 * the digit string, so a large total is not rounded through a float. Empty for no value.
 */
function scaled(raw: string | number | null | undefined): string {
  if (raw == null || raw === "") {
    return "";
  }
  const text = String(raw).split(".")[0];
  return /^-?\d+$/.test(text) ? moneyFromBigintString(text, 4) : String(raw);
}
