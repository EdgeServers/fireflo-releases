"use client";
import { useCallback, useEffect, useState, type ReactNode } from "react";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Segmented } from "@/components/ui/segmented";
import { Select } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { SettingsRow, SettingsRows } from "@/components/ui/settings-row";
import { NeedsCapability } from "./NeedsCapability";
import { useHealth } from "./useHealth";
import { KAFKA_BACKBONE } from "@/lib/capabilities";
import { cn } from "@/lib/utils";
import {
  BROKER_DEFAULTS,
  BROKER_SECRETS,
  COMPRESSIONS,
  SASL_MECHANISMS,
  SECURITY_PROTOCOLS,
  VENDOR_SETTLE_OPTIONS,
  type BrokerForm,
  type BrokerProvider,
  type BrokerSecret,
  type BrokerView,
  type Compression,
  type SaslMechanism,
  type SecurityProtocol,
  type VendorSettle,
  brokerProblem,
  parseBootstrap,
  usesSasl,
  usesTls,
} from "@/lib/broker-config";

/**
 * What the gateway's `brokerTest` answers (gateway 0.14). `steps` is the connection walk; `nodes`,
 * `controller` and `topicPartitions` describe what it found. Their inner shapes are read leniently:
 * the gateway is being built beside this screen, and a field it adds must not blank the report.
 */
interface BrokerTestReport {
  connected: boolean;
  detail?: string;
  steps?: { name: string; ok?: boolean; ms: number; detail?: string }[];
  nodes?: unknown[] | null;
  controller?: unknown;
  topicPartitions?: unknown;
}

const PROVIDERS = [
  { value: "memory", label: "In process", title: "One node; queues live in this process and are gone at a restart" },
  { value: "kafka", label: "Kafka cluster", title: "Every node sharing these brokers shares the work; queues survive a restart" },
] as const;

/** Which secrets the form is replacing rather than keeping. */
type Changing = Record<BrokerSecret, boolean>;
const KEEP_ALL: Changing = { saslPassword: false, truststorePassword: false, keystorePassword: false };

/**
 * The backbone's settings on the Queues page: what is saved, and for an admin, an editor with a test.
 *
 * <p>No secret comes to the browser. The form says whether each is stored, and sends a new value
 * only when it is being changed; the server writes it and never reads it back.
 *
 * <p>The gateway connects to Kafka once, at startup. A save is therefore not in force until a
 * restart, which `restartNeeded` -- read from the gateway, not guessed here -- says.
 *
 * <p>Needs the `kafka_backbone` capability: on an older gateway the keys mean nothing, and the
 * standard sentence says so rather than offering a form that would write them anyway.
 */
export function BrokerSettings({ restartNeeded, onSaved }: { restartNeeded: boolean; onSaved: () => void }) {
  const { health, loading, error } = useHealth();
  return (
    <NeedsCapability health={health} loading={loading} error={error} name={KAFKA_BACKBONE} feature="the Kafka backbone settings">
      <BrokerSettingsForm restartNeeded={restartNeeded} onSaved={onSaved} />
    </NeedsCapability>
  );
}

function BrokerSettingsForm({ restartNeeded, onSaved }: { restartNeeded: boolean; onSaved: () => void }) {
  const [view, setView] = useState<(BrokerView & { canEdit: boolean }) | null>(null);
  const [unavailable, setUnavailable] = useState<string | null>(null);
  const [form, setForm] = useState<BrokerForm | null>(null);
  const [changing, setChanging] = useState<Changing>(KEEP_ALL);
  const [testing, setTesting] = useState(false);
  const [report, setReport] = useState<BrokerTestReport | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  //set by a save: the gateway reads app_config on its next poll, seconds away, and until then
  //restartNeeded still says no -- so the note shows from the save rather than from the poll
  const [justSaved, setJustSaved] = useState(false);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/control/queues/broker", { cache: "no-store" });
      const body = await res.json();
      if (!res.ok) {
        setUnavailable(body?.error ?? "Could not read the backbone settings.");
      } else if (!body.data) {
        setUnavailable(body.reason ?? "The backbone settings cannot be read here.");
      } else {
        setView(body.data);
      }
    } catch {
      setUnavailable("Could not reach the panel's API.");
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (unavailable) {
    return <p className="text-sm text-muted-foreground">{unavailable}</p>;
  }
  if (!view) {
    return null;
  }

  function edit() {
    setForm({ ...view!.form, saslPassword: null, truststorePassword: null, keystorePassword: null });
    setChanging(KEEP_ALL);
    setReport(null);
    setError(null);
  }

  function set<K extends keyof BrokerForm>(key: K, value: BrokerForm[K]) {
    setForm((f) => (f ? { ...f, [key]: value } : f));
    //a result describes the settings it was run with; once they change it describes nothing
    setReport(null);
  }

  if (!form) {
    return (
      <SavedView view={view} restartNeeded={restartNeeded} justSaved={justSaved} onEdit={view.canEdit ? edit : null} />
    );
  }

  //what the server will receive: a kept secret is null, a changed one is the typed value
  const sent: BrokerForm = {
    ...form,
    saslPassword: changing.saslPassword ? form.saslPassword ?? "" : null,
    truststorePassword: changing.truststorePassword ? form.truststorePassword ?? "" : null,
    keystorePassword: changing.keystorePassword ? form.keystorePassword ?? "" : null,
  };
  const problem = brokerProblem(sent, view.secretsSet);

  async function test() {
    setTesting(true);
    setError(null);
    setReport(null);
    try {
      const res = await fetch("/api/control/queues/broker/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(sent),
      });
      const body = await res.json();
      if (!res.ok) {
        setError(body?.error ?? `The test could not run (${res.status}).`);
      } else {
        setReport(body.data as BrokerTestReport);
      }
    } catch {
      setError("Could not reach the panel's API.");
    } finally {
      setTesting(false);
    }
  }

  async function save() {
    setSaving(true);
    setError(null);
    try {
      const res = await fetch("/api/control/queues/broker", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(sent),
      });
      const body = await res.json();
      if (!res.ok) {
        setError(body?.error ?? `Could not save (${res.status}).`);
        return;
      }
      setForm(null);
      setJustSaved(true);
      await load();
      onSaved();
    } catch {
      setError("Could not reach the panel's API.");
    } finally {
      setSaving(false);
    }
  }

  const kafka = form.provider === "kafka";
  const sasl = usesSasl(form.securityProtocol);
  const tls = usesTls(form.securityProtocol);
  const servers = parseBootstrap(form.bootstrap);

  const number = (key: NumberKey, id: string, label: string, help?: ReactNode, suffix?: string) => (
    <SettingsRow label={label} htmlFor={id} help={help}>
      <div className="flex items-center gap-2">
        <Input id={id} inputMode="numeric" value={form[key]} onChange={(e) => set(key, e.target.value)} placeholder={BROKER_DEFAULTS[key]} />
        {suffix && <span className="shrink-0 text-xs text-muted-foreground">{suffix}</span>}
      </div>
    </SettingsRow>
  );

  const secretField = (key: BrokerSecret, id: string, label: string, help?: ReactNode) => (
    <SettingsRow label={label} htmlFor={id} help={help}>
      {changing[key] ? (
        <div className="flex gap-2">
          <Input
            id={id}
            type="password"
            autoComplete="new-password"
            value={form[key] ?? ""}
            onChange={(e) => set(key, e.target.value)}
          />
          {view.secretsSet[key] && (
            <Button type="button" variant="ghost" size="sm" onClick={() => { setChanging((c) => ({ ...c, [key]: false })); set(key, null); }}>
              Keep stored
            </Button>
          )}
        </div>
      ) : (
        <div className="flex gap-2">
          <span className="flex-1 rounded-md border border-dashed border-input px-3 py-2 text-sm text-muted-foreground">
            {view.secretsSet[key] ? "Keep the stored password" : "None stored"}
          </span>
          <Button type="button" variant="outline" size="sm" onClick={() => { setChanging((c) => ({ ...c, [key]: true })); set(key, ""); }}>
            {view.secretsSet[key] ? "Change" : "Set"}
          </Button>
        </div>
      )}
    </SettingsRow>
  );

  return (
    <div className="space-y-4">
      <SettingsRows>
        <SettingsRow
          label="Queue on"
          help={<>SMPP and REST alike. {!kafka && "The Kafka settings below are kept, so switching back does not lose them."}</>}
        >
          <Segmented<BrokerProvider>
            label="Queue on"
            options={PROVIDERS}
            value={form.provider}
            onChange={(v) => set("provider", v)}
            fill
          />
        </SettingsRow>
      </SettingsRows>

      {kafka && (
        <>
          <Group title="Connection" description="Where the brokers are and how the gateway proves who it is.">
            <SettingsRow
              label="Bootstrap servers"
              htmlFor="broker-bootstrap"
              help={<>One <code>host:port</code> per line, or comma separated. Any one broker is enough to find the rest.</>}
            >
              <Textarea
                id="broker-bootstrap"
                rows={3}
                value={form.bootstrap}
                onChange={(e) => set("bootstrap", e.target.value)}
                placeholder={"kafka1.internal:9092\nkafka2.internal:9092"}
                className="font-mono"
              />
            </SettingsRow>
            <SettingsRow label="Security protocol" htmlFor="broker-security">
              <Select id="broker-security" value={form.securityProtocol} onChange={(e) => set("securityProtocol", e.target.value as SecurityProtocol)}>
                {SECURITY_PROTOCOLS.map((p) => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </Select>
            </SettingsRow>
            {sasl && (
              <>
                <SettingsRow label="SASL mechanism" htmlFor="broker-sasl-mechanism">
                  <Select id="broker-sasl-mechanism" value={form.saslMechanism} onChange={(e) => set("saslMechanism", e.target.value as SaslMechanism)}>
                    {SASL_MECHANISMS.map((m) => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </Select>
                </SettingsRow>
                <SettingsRow label="SASL user name" htmlFor="broker-sasl-user">
                  <Input id="broker-sasl-user" autoComplete="off" value={form.saslUsername} onChange={(e) => set("saslUsername", e.target.value)} placeholder="fireflo" />
                </SettingsRow>
                {secretField("saslPassword", "broker-sasl-password", "SASL password")}
              </>
            )}
            {tls && (
              <>
                <SettingsRow label="Truststore path" htmlFor="broker-truststore" help="On the gateway host. Blank trusts the JVM's own store.">
                  <Input id="broker-truststore" value={form.truststorePath} onChange={(e) => set("truststorePath", e.target.value)} placeholder="/etc/fireflo/kafka-truststore.p12" className="font-mono" />
                </SettingsRow>
                {secretField("truststorePassword", "broker-truststore-password", "Truststore password")}
                <SettingsRow label="Keystore path" htmlFor="broker-keystore" help="On the gateway host. Only for brokers that ask clients for a certificate.">
                  <Input id="broker-keystore" value={form.keystorePath} onChange={(e) => set("keystorePath", e.target.value)} placeholder="/etc/fireflo/kafka-keystore.p12" className="font-mono" />
                </SettingsRow>
                {secretField("keystorePassword", "broker-keystore-password", "Keystore password")}
              </>
            )}
          </Group>

          <Group title="Topics" description="How the gateway names and creates its topics. Prefixes apply after a restart.">
            <SettingsRow label="Topic prefix" htmlFor="broker-topic-prefix" help="Every topic the gateway makes starts with this. Change it and the gateway starts on fresh, empty topics.">
              <Input id="broker-topic-prefix" value={form.topicPrefix} onChange={(e) => set("topicPrefix", e.target.value)} placeholder={BROKER_DEFAULTS.topicPrefix} className="font-mono" />
            </SettingsRow>
            <SettingsRow label="Consumer group prefix" htmlFor="broker-group-prefix" help="Change it and every node starts reading from the topics' retention edge.">
              <Input id="broker-group-prefix" value={form.groupPrefix} onChange={(e) => set("groupPrefix", e.target.value)} placeholder={BROKER_DEFAULTS.groupPrefix} className="font-mono" />
            </SettingsRow>
            <SettingsRow label="Create topics at startup" labelId="broker-topics-create" help="Off when the cluster's administrator makes them, with the partition counts below.">
              <div className="flex md:justify-end">
                <Switch checked={form.topicsCreate} onChange={(v) => set("topicsCreate", v)} aria-labelledby="broker-topics-create" />
              </div>
            </SettingsRow>
            {number("partitionsRouter", "broker-partitions-router", "Router partitions", "The most any one cluster can spread routing over. More than the nodes you will ever run.")}
            {number("partitionsVendor", "broker-partitions-vendor", "Vendor partitions", "Per vendor topic.")}
            {number("partitionsRetry", "broker-partitions-retry", "Retry partitions")}
            {number("replicationFactor", "broker-replication", "Replication factor", "-1 takes the broker's default.replication.factor.")}
            {number("retentionHours", "broker-retention", "Retention", "How long a message stays on a topic after it was taken. The window a node has to come back and still find its work.", "hours")}
            <SettingsRow label="Compression" htmlFor="broker-compression">
              <Select id="broker-compression" value={form.compression} onChange={(e) => set("compression", e.target.value as Compression)}>
                {COMPRESSIONS.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </Select>
            </SettingsRow>
          </Group>

          <Group title="Flow" description="How much is in the air at once, and when a message counts as done. These apply without a restart.">
            <SettingsRow
              label="When a message counts as handed over"
              help={
                <ul className="space-y-1">
                  {VENDOR_SETTLE_OPTIONS.map((o) => (
                    <li key={o.value}>
                      <span className="font-mono">{o.value}</span> — {o.description}
                    </li>
                  ))}
                </ul>
              }
            >
              <Segmented<VendorSettle>
                label="When a message counts as handed over"
                options={VENDOR_SETTLE_OPTIONS.map((o) => ({ value: o.value, label: o.label, title: o.description }))}
                value={form.vendorSettle}
                onChange={(v) => set("vendorSettle", v)}
                fill
              />
            </SettingsRow>
            {number("routerInflight", "broker-router-inflight", "Router messages in flight", "Taken from the router topic and not yet routed, per node.")}
            {number("vendorInflight", "broker-vendor-inflight", "Vendor messages in flight", "Taken from a vendor topic and not yet handed over, per node and vendor.")}
            {number("ingressLagHighwater", "broker-lag-highwater", "Pause ingress above", "Listeners and REST stop accepting while the router topic's lag is above this. 0 never pauses.", "messages behind")}
            {number("produceTimeoutMs", "broker-produce-timeout", "Produce timeout", "How long a submit waits for the brokers to acknowledge before it is refused.", "ms")}
            {number("produceBlockMs", "broker-produce-block", "Produce block time", "How long a submit waits for room in the producer's buffer.", "ms")}
          </Group>

          <Group title="Cluster" description="How nodes notice one another. Kafka mode is cluster mode: every node on these brokers is one cluster.">
            {number("clusterHeartbeat", "broker-heartbeat", "Heartbeat every", undefined, "s")}
            {number("clusterNodeTimeout", "broker-node-timeout", "Node dead after", "No heartbeat for this long and the other nodes take its vendors and partitions.", "s")}
            {number("clusterLeaseTtl", "broker-lease-ttl", "Vendor lease TTL", "A vendor session belongs to one node at a time; its lease expires after this.", "s")}
            {number("clusterLeaseRenew", "broker-lease-renew", "Renew leases every", "Shorter than the TTL.", "s")}
            {number("clusterRebalanceGrace", "broker-rebalance-grace", "Rebalance grace", "How long a restarting node is waited for before its work moves.", "s")}
          </Group>
        </>
      )}

      {report && <TestResult report={report} />}
      {(error || problem) && <p className="text-sm text-destructive">{error ?? problem}</p>}

      <div className="flex flex-wrap items-center gap-2 border-t border-border pt-3">
        {kafka && (
          <Button type="button" variant="outline" size="sm" disabled={testing || !!problem} onClick={test}>
            {testing && <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />}
            Test connection
          </Button>
        )}
        <span className="flex-1" />
        <Button type="button" variant="ghost" size="sm" disabled={saving} onClick={() => setForm(null)}>
          Cancel
        </Button>
        <Button type="button" size="sm" disabled={saving || !!problem} onClick={save}>
          {saving && <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />}
          Save
        </Button>
      </div>
      <p className="text-xs text-muted-foreground">
        The test runs from the gateway against the {typeof servers === "string" ? "" : `${servers.length} `}
        bootstrap server{typeof servers !== "string" && servers.length === 1 ? "" : "s"} in this form, saved or not,
        and changes nothing on the cluster.
        {form.securityProtocol !== "PLAINTEXT" && " It uses the security settings the gateway is running with; new credentials are only tried at the next restart."}
        {" "}Saving after a failed test is allowed: a cluster down for maintenance is still the right address.
        Connection and topic settings apply when the gateway next restarts.
      </p>
    </div>
  );
}

/** The form's free-text numbers: a plain string field that has a gateway default to show as its placeholder. */
type NumberKey = {
  [K in keyof BrokerForm]: string extends BrokerForm[K] ? (K extends keyof typeof BROKER_DEFAULTS ? K : never) : never;
}[keyof BrokerForm];

function Group({ title, description, children }: { title: string; description?: string; children: ReactNode }) {
  return (
    <section className="space-y-2">
      <header>
        <h3 className="text-sm font-semibold">{title}</h3>
        {description && <p className="text-xs text-muted-foreground">{description}</p>}
      </header>
      <SettingsRows>{children}</SettingsRows>
    </section>
  );
}

/** The saved settings as a definition list, with no secret value in it. */
function SavedView({
  view,
  restartNeeded,
  justSaved,
  onEdit,
}: {
  view: BrokerView;
  restartNeeded: boolean;
  justSaved: boolean;
  onEdit: (() => void) | null;
}) {
  const saved = view.form;
  const kafka = saved.provider === "kafka";
  const servers = parseBootstrap(saved.bootstrap);
  const storedSecrets = BROKER_SECRETS.filter((s) => view.secretsSet[s]).length;
  return (
    <div className="space-y-2">
      <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 rounded-md border border-border px-3 py-2 text-sm">
        <dt className="text-muted-foreground">Queued on</dt>
        <dd>{kafka ? "Kafka cluster" : "In process only"}</dd>
        {kafka && (
          <>
            <dt className="text-muted-foreground">Bootstrap</dt>
            <dd className="break-all font-mono">{typeof servers === "string" ? "(not set)" : servers.join(", ")}</dd>
            <dt className="text-muted-foreground">Security</dt>
            <dd className="font-mono">
              {saved.securityProtocol}
              {usesSasl(saved.securityProtocol) && ` · ${saved.saslMechanism}${saved.saslUsername ? ` as ${saved.saslUsername}` : ""}`}
              {storedSecrets > 0 && <span className="ml-1.5 font-sans text-xs text-muted-foreground">({storedSecrets} password{storedSecrets === 1 ? "" : "s"} stored)</span>}
            </dd>
            <dt className="text-muted-foreground">Topics</dt>
            <dd className="font-mono">
              {saved.topicPrefix || BROKER_DEFAULTS.topicPrefix}* · {saved.partitionsRouter || BROKER_DEFAULTS.partitionsRouter}/
              {saved.partitionsVendor || BROKER_DEFAULTS.partitionsVendor}/{saved.partitionsRetry || BROKER_DEFAULTS.partitionsRetry} partitions
            </dd>
            <dt className="text-muted-foreground">Handed over</dt>
            <dd>{VENDOR_SETTLE_OPTIONS.find((o) => o.value === saved.vendorSettle)?.description ?? saved.vendorSettle}</dd>
          </>
        )}
      </dl>
      {(restartNeeded || justSaved) && (
        <p className="text-sm text-warning">
          These are the saved settings. The gateway connects to the cluster when it starts, so they
          apply at its next restart; until then it runs on the ones it started with.
        </p>
      )}
      {onEdit && (
        <Button type="button" variant="outline" size="sm" onClick={onEdit}>
          Edit backbone
        </Button>
      )}
    </div>
  );
}

function TestResult({ report }: { report: BrokerTestReport }) {
  const steps = report.steps ?? [];
  const total = steps.reduce((sum, s) => sum + s.ms, 0);
  const nodes = (report.nodes ?? []).map(describeNode);
  const controller = report.controller == null ? null : describeNode(report.controller);
  const topics = describeTopics(report.topicPartitions);
  return (
    <div className="overflow-hidden rounded-md border border-border text-sm">
      <div className={cn("flex items-center gap-2 bg-muted px-3 py-2 font-medium", report.connected ? "text-success" : "text-destructive")}>
        {report.connected ? `✓ Reached the cluster from the gateway in ${total} ms` : `✕ ${report.detail ?? "Could not reach the cluster from the gateway"}`}
      </div>
      {steps.map((step) => (
        <div key={step.name} className="grid grid-cols-[1.25rem_1fr_auto] gap-2 border-t border-border px-3 py-1.5">
          <span className={step.ok === true ? "text-success" : step.ok === false ? "text-destructive" : "text-muted-foreground"}>
            {step.ok === true ? "✓" : step.ok === false ? "✕" : "–"}
          </span>
          <span className={cn(step.ok === undefined && "text-muted-foreground")}>
            {step.name}
            {step.ok === undefined && " — not checked"}
            {step.detail && <span className="block text-xs text-muted-foreground">{step.detail}</span>}
          </span>
          <span className="font-mono text-xs text-muted-foreground">{step.ok !== undefined ? `${step.ms} ms` : ""}</span>
        </div>
      ))}
      {(nodes.length > 0 || controller || topics.length > 0) && (
        <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 border-t border-border px-3 py-2">
          {nodes.length > 0 && (
            <>
              <dt className="text-muted-foreground">Brokers</dt>
              <dd className="font-mono text-xs">{nodes.join(" · ")}</dd>
            </>
          )}
          {controller && (
            <>
              <dt className="text-muted-foreground">Controller</dt>
              <dd className="font-mono text-xs">{controller}</dd>
            </>
          )}
          {topics.length > 0 && (
            <>
              <dt className="text-muted-foreground">Topics</dt>
              <dd className="font-mono text-xs">
                {topics.map((t) => (
                  <span key={t} className="mr-3 inline-block">{t}</span>
                ))}
              </dd>
            </>
          )}
        </dl>
      )}
    </div>
  );
}

/** A broker as the report names it: a string, an id, or `{id, host, port}` -- whichever the gateway sends. */
function describeNode(node: unknown): string {
  if (node == null) {
    return "";
  }
  if (typeof node !== "object") {
    return String(node);
  }
  const n = node as Record<string, unknown>;
  const host = typeof n.host === "string" ? n.host : "";
  const port = n.port != null ? `:${n.port}` : "";
  const id = n.id != null ? `#${n.id}` : "";
  const rack = typeof n.rack === "string" && n.rack ? ` (${n.rack})` : "";
  return `${host}${port}${host && id ? " " : ""}${id}${rack}`.trim() || JSON.stringify(node);
}

/** Topics as the report lists them: a map of name to partitions, or a list of `{name, partitions}`. */
function describeTopics(value: unknown): string[] {
  if (value == null) {
    return [];
  }
  if (Array.isArray(value)) {
    return value.map((t) => {
      if (t && typeof t === "object") {
        const o = t as Record<string, unknown>;
        return `${o.name ?? o.topic ?? "?"} ×${o.partitions ?? "?"}`;
      }
      return String(t);
    });
  }
  if (typeof value === "object") {
    return Object.entries(value as Record<string, unknown>).map(([name, partitions]) => `${name} ×${partitions}`);
  }
  return [String(value)];
}
