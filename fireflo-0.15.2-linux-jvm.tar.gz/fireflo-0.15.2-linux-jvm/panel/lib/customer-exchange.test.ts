import { test } from "node:test";
import assert from "node:assert/strict";
import { buildCustomerExchange } from "./customer-exchange.ts";

const submit = {
  gatewayMsgId: "abc-123",
  acceptedAt: "2026-09-01T17:36:03.545Z",
  submittedAt: "2026-09-01T17:36:03.546Z",
  ingress: "smppserver",
  inGateway: "smppserver.test123",
  sourceAddr: "ABXOTP",
  destAddr: "919809089767",
};

const ev = (kind: string, at: string, over: Record<string, unknown> = {}) => ({
  at, kind, channel: "smpp", status: null, attempt: null,
  durationMs: null, endpoint: null, detail: null, ...over,
});

test("an SMPP message shows their submit and our response -- or every case below is vacuous", () => {
  const x = buildCustomerExchange(submit, []);
  assert.deepEqual(x.map((e) => e.pdu), ["submit_sm", "submit_sm_resp"]);
  assert.equal(x[0].direction, "in");
  //the id we returned is what the customer quotes back at us later
  assert.equal(x[1].detail, "abc-123");
  //accepted_at, NOT submitted_at -- the latter is when the vendor was told
  assert.equal(x[0].at, submit.acceptedAt);
});

test("a REST message is not dressed up as SMPP", () => {
  const x = buildCustomerExchange({ ...submit, ingress: "http", inGateway: null }, []);
  assert.deepEqual(x.map((e) => e.pdu), ["http_request", "http_response"]);
});

test("a delivered receipt appears as the deliver_sm it was", () => {
  const x = buildCustomerExchange(submit, [ev("receipt.sent", "2026-09-01T17:36:09.000Z")]);
  assert.equal(x[2].pdu, "deliver_sm");
  assert.equal(x[2].direction, "out");
  assert.equal(x[2].detail, null);
});

test("each way a receipt does NOT arrive is shown, with its reason", () => {
  //an absence is the whole point of this card: leaving these off would render a message that looks
  //exactly like one whose customer was told
  for (const [kind, expect] of [
    ["receipt.held", /held until this system id binds/],
    ["receipt.suppressed", /did not ask about this outcome/],
    ["receipt.failed", /could not be put on the wire/],
  ] as const) {
    const x = buildCustomerExchange(submit, [ev(kind, "2026-09-01T17:36:09.000Z", { detail: "why" })]);
    assert.equal(x[2].pdu, "deliver_sm");
    assert.match(x[2].detail ?? "", expect);
    assert.match(x[2].detail ?? "", /why/);
  }
});

test("callbacks carry their status and their redacted endpoint", () => {
  const x = buildCustomerExchange(submit, [
    ev("callback.attempt", "2026-09-01T17:36:10.000Z",
      { status: 500, endpoint: "https://h.example.com/cb", detail: "HTTP 500" }),
  ]);
  assert.equal(x[2].pdu, "callback");
  assert.equal(x[2].status, 500);
  assert.equal(x[2].endpoint, "https://h.example.com/cb");
});

test("the sequence is time-ordered, and a tie keeps the order it happened in", () => {
  const same = "2026-09-01T17:36:09.000Z";
  const x = buildCustomerExchange(submit, [
    ev("callback.attempt", same, { attempt: 1 }),
    ev("callback.attempt", same, { attempt: 2 }),
  ]);
  assert.deepEqual(x.map((e) => e.pdu), ["submit_sm", "submit_sm_resp", "callback", "callback"]);
});

test("a message with no cdr_submit row still renders whatever events exist", () => {
  const x = buildCustomerExchange(null, [ev("receipt.sent", "2026-09-01T17:36:09.000Z")]);
  assert.deepEqual(x.map((e) => e.pdu), ["deliver_sm"]);
});

//--------------------------------------------------------------------------------------------
// The receipt as the CUSTOMER saw it, derived from cdr_final rather than from a cdr_event.
//--------------------------------------------------------------------------------------------

const rcpt = (over: Record<string, unknown> = {}) => ({
  id: "abc-123", partNo: 1, kind: "outcome" as const, operatorMsgId: "vendor-9",
  finalState: null, dlrState: 2, errCode: "018", vendorErrCode: "630",
  receivedAt: "2026-09-01T17:36:09.000Z", vendor: null, forwarded: true, ...over,
});

test("the customer's deliver_sm is NOT the vendor's -- reversed addresses and our own id", () => {
  //the whole reason this is derived rather than echoed. GatewayReceipt.forState reverses from/to
  //and stamps our gateway_msg_id, so a card showing the vendor's values would be a readable lie
  const x = buildCustomerExchange(submit, [], [rcpt()]);
  const d = x.find((e) => e.pdu === "deliver_sm");
  assert.ok(d?.receipt);
  assert.equal(d.receipt.from, submit.destAddr, "from is the message's destination");
  assert.equal(d.receipt.to, submit.sourceAddr, "to is the message's source");
  assert.equal(d.receipt.messageId, "abc-123", "ours, never the carrier's operator_msg_id");
  assert.notEqual(d.receipt.messageId, "vendor-9");
});

test("the carrier's own code is kept BESIDE what we told the customer, not instead of it", () => {
  //the smalerts case: the carrier said 630 and the customer was told 018. Showing only one of them
  //is what made that investigation read as the gateway inventing a verdict
  const x = buildCustomerExchange(submit, [], [rcpt()]);
  const d = x.find((e) => e.pdu === "deliver_sm");
  assert.equal(d?.receipt?.err, "018");
  assert.equal(d?.receipt?.vendorErr, "630");
});

test("a receipt renders with NO cdr_event at all -- retrospective, and the point of deriving it", () => {
  //works on messages sent before cdr_event existed, and on a gateway that never had events on
  const x = buildCustomerExchange(submit, [], [rcpt()]);
  const d = x.find((e) => e.pdu === "deliver_sm");
  assert.ok(d, "a deliver_sm appears with no events whatsoever");
  assert.equal(d.delivery, "unrecorded");
  assert.match(d.detail ?? "", /not recorded at this level/);
});

test("the three delivery labels, and silence is never read as delivery", () => {
  const sent = buildCustomerExchange(submit, [ev("receipt.sent", "2026-09-01T17:36:09.000Z")], [rcpt()]);
  assert.equal(sent.find((e) => e.pdu === "deliver_sm")?.delivery, "sent");

  const held = buildCustomerExchange(submit, [ev("receipt.held", "2026-09-01T17:36:09.000Z")], [rcpt()]);
  const h = held.find((e) => e.pdu === "deliver_sm");
  assert.equal(h?.delivery, "not-sent");
  assert.match(h?.detail ?? "", /held until this system id binds again/);

  //the anti-vacuity half: no event must NOT collapse into "sent"
  const quiet = buildCustomerExchange(submit, [], [rcpt()]);
  assert.equal(quiet.find((e) => e.pdu === "deliver_sm")?.delivery, "unrecorded");
});

test("a receipt the gateway withheld says so even when nothing was recorded", () => {
  //forwarded === false is the gateway's own statement; it does not need an event to be believed
  const x = buildCustomerExchange(submit, [], [rcpt({ forwarded: false })]);
  const d = x.find((e) => e.pdu === "deliver_sm");
  assert.equal(d?.delivery, "not-sent");
  assert.match(d?.detail ?? "", /did not ask about this outcome/);
});

test("a message still in flight shows no deliver_sm rather than an empty one", () => {
  const x = buildCustomerExchange(submit, [], []);
  assert.equal(x.filter((e) => e.pdu === "deliver_sm").length, 0);
});

test("a progress receipt is marked non-terminal, so it is not read as the last word", () => {
  const x = buildCustomerExchange(submit, [], [rcpt({ kind: "progress", dlrState: 1 })]);
  assert.equal(x.find((e) => e.pdu === "deliver_sm")?.receipt?.terminal, false);
});

test("a callback keeps the try number and the duration it was fetched with", () => {
  //both were selected by the query and dropped by this builder, so every callback ever rendered
  //looked like a first attempt that took no time
  const x = buildCustomerExchange(submit, [
    ev("callback.attempt", "2026-09-01T17:36:10.000Z",
      { status: 500, attempt: 4, durationMs: 412 }),
  ]);
  assert.equal(x[2].attempt, 4);
  assert.equal(x[2].durationMs, 412);
});

test("the four states of a captured response stay four states", () => {
  //undefined, null, "" and a string are answered by different people -- an upgrade, a setting, the
  //endpoint itself, and nobody -- so collapsing any pair of them is what makes the cell a guess
  const of = (over: Record<string, unknown>) =>
    buildCustomerExchange(submit, [ev("callback.attempt", "2026-09-01T17:36:10.000Z", over)])[2];

  assert.equal(of({}).responseExcerpt, undefined);
  assert.equal(of({ responseExcerpt: null }).responseExcerpt, null);
  assert.equal(of({ responseExcerpt: "" }).responseExcerpt, "");
  assert.equal(of({ responseExcerpt: "{\"error\":\"nope\"}" }).responseExcerpt, "{\"error\":\"nope\"}");
  assert.equal(
    of({ responseHeaders: "content-type: application/json" }).responseHeaders,
    "content-type: application/json"
  );
});

test("a receipt row carries no callback fields to be mistaken for one", () => {
  const x = buildCustomerExchange(submit, [ev("receipt.sent", "2026-09-01T17:36:09.000Z")]);
  assert.equal(x[2].attempt, null);
  assert.equal(x[2].durationMs, null);
  assert.equal(x[2].responseExcerpt, undefined);
});

test("encoding: the customer's submit_sm as it arrived, our receipt always GSM-7", () => {
  const x = buildCustomerExchange(
    { ...submit, dcs: 8, esmClassReceived: 0, bytesReceived: 188, payloadReceived: false },
    [ev("receipt.sent", "2026-09-01T17:36:09.000Z")],
    [{
      id: "abc-123", partNo: 1, kind: "outcome", operatorMsgId: null, finalState: "DELIVERED",
      dlrState: 2, errCode: null, receivedAt: "2026-09-01T17:36:09.000Z", vendor: null, forwarded: true,
    }]
  );
  assert.equal(x[0].encoding?.label, "UCS-2 · dcs 8");
  assert.equal(x[0].encoding?.detail, "esm 0x00 · 188 bytes · short_message");
  assert.equal("encoding" in x[1], false, "our submit_sm_resp carries no text");
  const receipt = x.find((e) => e.pdu === "deliver_sm");
  assert.equal(receipt?.encoding?.label, "GSM-7 · dcs 0");
  assert.equal(receipt?.encoding?.detail, "esm 0x04 delivery receipt · always dcs 0");
});

test("encoding: an HTTP request says what it has no field for", () => {
  const x = buildCustomerExchange(
    { ...submit, ingress: "http", inGateway: null, dcs: 0, charsReceived: 12, esmClassReceived: null, bytesReceived: null, payloadReceived: null },
    []
  );
  assert.equal(x[0].pdu, "http_request");
  assert.equal(x[0].encoding?.detail, "12 characters · over HTTP: no esm_class or octets");
});

test("encoding: on a 1.123.0 database only the ingress dcs is shown", () => {
  const x = buildCustomerExchange({ ...submit, dcs: 3 }, []);
  assert.equal(x[0].encoding?.label, "Latin-1 · dcs 3");
  assert.equal(x[0].encoding?.detail, null);
});
