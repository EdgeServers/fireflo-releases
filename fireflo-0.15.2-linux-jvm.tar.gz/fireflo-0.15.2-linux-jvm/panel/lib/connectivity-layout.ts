import { COUNTS_WINDOW_LABEL, type CountsWindow, type ListenerRefusal, type ReasonCount } from "./connectivity-counts.ts";
import { bytes, localeNumber } from "./format.ts";
import { formatTps } from "./tps-format.ts";
import { formatTimestamp, zoneShortName } from "./datetime.ts";

/**
 * The Connectivity page's map as geometry: who is connected, through which port and node, to which
 * vendor -- four tiers of boxes and the right-angled edges between them (`S['connectivity']` in the
 * mockups).
 *
 * <h2>What goes in, what comes out</h2>
 *
 * <p>In: what the page already polls, reduced to plain rows -- clients per listener (rates folded
 * from the `sessions` counters by `lib/live-sessions.ts`), the enabled listeners and vendors from
 * health, the cluster's nodes. And a view: which port groups are open, on which page, sorted how;
 * whether every port is shown. Out: boxes with rectangles, edges with their points and widths, the
 * four tier bands, and the content's size. The canvas draws exactly this and hit-tests against the
 * same rectangles, so a box can never be drawn in one place and clicked in another.
 *
 * <h2>How it stays readable at 3,000 msg/s and fifty clients</h2>
 *
 * <p>Clients roll up into one box per listener; an open group shows its ten busiest (by the
 * group's sort) and a "+n more" chip that pages ten at a time. Ports beyond six collapse the
 * quietest into "+n ports", and the clients of those ports into one "other ports" group. Every
 * tier is one row, scrolled sideways rather than wrapped, which is what lets every edge leave its
 * box straight down to a bus in the gap below the tier, run along it, and drop straight into its
 * target: no edge ever crosses a box of either tier it joins. Edge width encodes rate on a log
 * scale, so 3,000/s and 3/s are both visible without one swallowing the other.
 *
 * <h2>Counts</h2>
 *
 * <p>Beside each rate, how much has moved: MT (submits; on a vendor, what it took) and DLR (receipts)
 * over the window the page picked -- the last hour from the gateway's live series, or since bind
 * from the session counters (`lib/connectivity-counts.ts`). A box's second line reads
 * `1,840/s · MT 61,204 · DLR 59,880`; groups, the ports chip, nodes and vendor groups sum their
 * members. A count nobody knows is null and draws as a dash, never as zero; a box with neither
 * keeps its old line. Edge width stays the rate's.
 *
 * <h2>The node's queue</h2>
 *
 * <p>A gateway box reads `1,007/s in · queue 0`: the queue is the router queue plus the Kafka router
 * lag plus what waits to retry (`router_queue` + `backbone.routerLag` + `routing_retry_queue` +
 * `backbone.retryDepth`), the figures `bench-drain.sh` watches. The persistence bus stays in the
 * tooltip with its lag. The box turns to the alarm tone -- a filled orange face, not only an outline
 * -- when the queue is past {@link LAG_WARN}, when the persist lag is past the gateway's
 * `smsg.persist.lag.max.seconds`, or when the queue has risen on each of the last
 * {@link RISING_STEPS} polls by at least {@link RISE_MIN} in all ({@link queueTrend}); rising also
 * puts "▲" after the figure.
 *
 * <h2>The database</h2>
 *
 * <p>When the gateway reports its PostgreSQL (`health.database`, or at least `db_admission`), a
 * Database box sits in the gateway row right beside the node that answered:
 * `PostgreSQL · db.internal (10.128.0.2):5432` over `probe 12 ms · pool 3/16 · 1,840 rows/s`. Its
 * state is the admission's: OK plain, DEGRADED the warning outline, REFUSING a red outline round
 * the alarm's filled orange face. When most of what the doors refused over the last full minute was
 * refused for the database (`dbUnavailable`, or `logCap`), a red badge on its top edge reads
 * `refusing N/s`. The node's writes to it are a `persist` edge: straight across, its width the rows
 * a second on the submits' log scale, its colour the database's state (red dashed when refusing).
 * Only the answering node's writes are known, so only its edge is drawn.
 *
 * <h2>Refused at the door</h2>
 *
 * <p>A port that refused submits over the last full minute gets a red dashed edge running back up
 * to its clients' group (the frame when open, the box when collapsed), labelled with the rate and
 * the reason mix: `312/s refused · dbUnavailable 80 % · creditPending 20 %`.
 *
 * <h2>Route groups</h2>
 *
 * <p>A route group with two or more vendors on the map is a titled frame around its members, open
 * by default; its toggle collapses it to one box (`MapView.openVendorGroups[name] === false`). The
 * node's edges go to each member while it is open and to the one box while it is collapsed; the
 * frame takes its worst member's state.
 *
 * <p>Pure and O(boxes): recomputed when the data or the view changes, never per frame.
 */

export type BoxKind =
  | "client"
  | "clientGroup"
  | "clientMore"
  | "listener"
  | "portsMore"
  | "node"
  | "vendor"
  | "vendorGroup"
  | "database";

/**
 * `alarm` is a gateway node whose queue is climbing or past its line: drawn as a filled orange face.
 * `refusing` is the database refusing new submits: the same face inside a red outline.
 */
export type BoxState = "ok" | "warn" | "alarm" | "refusing" | "down";
/** `persist` is a node's writes to the database, drawn across the gateway row. */
export type EdgeKind = "submit" | "receipt" | "refused" | "persist";
export type TierId = "clients" | "listeners" | "nodes" | "vendors";
export type ClientSort = "rate" | "binds" | "name";

/** What a box's menu and hover strip offer; `ConnectivityBoxMenu` names and runs them. */
export type BoxAction =
  //clients
  | "open-account" | "set-rate" | "set-binds" | "client-sessions" | "client-live" | "drop-binds"
  //client groups
  | "toggle" | "sort-rate" | "sort-binds" | "sort-name" | "next-page"
  //listeners
  | "open-listener" | "hold" | "release" | "default-rate" | "overrides" | "connections" | "disable"
  //gateway nodes
  | "health" | "queues" | "kafka" | "routing" | "refused"
  //the database
  | "slow-queries"
  //vendors
  | "open-vendor" | "pause" | "unpause" | "suspend" | "resume" | "restart" | "set-tps" | "backlog";

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface MapBox {
  id: string;
  kind: BoxKind;
  tier: TierId;
  rect: Rect;
  /** The title, then one line of figures. */
  lines: [string, string];
  state: BoxState;
  actions: BoxAction[];
  /** The two or three actions the hover strip offers, a subset of `actions`. */
  quick: BoxAction[];
  /** The tooltip: label and value pairs. */
  facts: [string, string][];
  /** What the box is: an account id, a listener or vendor full name, a node id, a group name. */
  ref: string;
  /** The listener a client or client group belongs to. */
  listener?: string;
  /** An open client group, drawn as a frame around its members. */
  frame?: boolean;
  /** The frame a client or chip sits in. */
  parent?: string;
  /** The box's own rate (submits per second), for the focus readout. */
  rate: number | null;
  /** Submits (a vendor: taken) and receipts over the input's window; null when not known. */
  mt: number | null;
  dlr: number | null;
  /** What a screen reader hears instead of the two lines, when the lines use a symbol (`▲`) or say less than the box. */
  speech?: string;
  /** A red badge on the box's top edge: the database's `refusing 250/s`. */
  badge?: string;
}

export interface MapEdge {
  id: string;
  /** Where the flow starts and ends: a submit runs down the tiers, a receipt up. */
  from: string;
  to: string;
  kind: EdgeKind;
  rate: number;
  width: number;
  /** Orthogonal polyline, `M x,y V ymid H x2 V y2`, in content coordinates. */
  points: [number, number][];
  /** The counts of the flow it draws -- the client's, the listener's, the vendor's -- over the window. */
  mt: number | null;
  dlr: number | null;
  /** The tooltip: `from → to`, then label and value pairs. */
  title: string;
  facts: [string, string][];
  /** Drawn on the edge: a port's `312/s refused · dbUnavailable 80 % · …`. */
  label?: string;
  /** A persist edge's colour: the database's state. */
  state?: BoxState;
}

export interface TierBand {
  id: TierId;
  label: string;
  rect: Rect;
}

export interface MapLayout {
  boxes: MapBox[];
  edges: MapEdge[];
  bands: TierBand[];
  width: number;
  height: number;
  /** The counts' window, as the tooltips name it: "last hour", "since restart 09:42" or "since bind". */
  countsLabel: string;
  /** Why the window is not the plain one, for the tooltips; null when it is. */
  countsNote: string | null;
}

export interface ClientIn {
  /** Unique within the listener: the account, or account × IP. */
  key: string;
  account: string;
  /** Set when the map is split by IP. */
  ip: string | null;
  /** Every address and login behind the row, for search and the tooltip. */
  hosts: string[];
  logins: string[];
  /** The listener's full name. */
  listener: string;
  binds: number;
  rate: number | null;
  receiptRate: number | null;
  /** Submits answered 0x58 at a ceiling, per second over the last minute (health `throttling`). */
  refusedRate: number | null;
  ceiling: number | null;
  /** Submits and receipts sent back down over the window; null when not known. */
  mt: number | null;
  dlr: number | null;
}

export interface ListenerIn {
  /** Full name, `smppserver.<name>`: what health and the sessions route call it. */
  id: string;
  /** The instance name: what the panel's own routes and pages call it. */
  name: string;
  port: string | null;
  bound: number;
  rate: number | null;
  /** `conf.maxRate.default`, when one is set. */
  ceiling: number | null;
  /** Health has it. */
  live: boolean;
  error: boolean;
  /** Stop accepting (`pause`) is on. */
  held: boolean;
  suspended: boolean;
  /** The node it runs on, an id from `nodes`. */
  node: string;
  /** Submits taken and receipts sent back down over the window; null when not known. */
  mt: number | null;
  dlr: number | null;
  /** Refused at the door over the last full minute; null or absent when none or not known. */
  refused?: ListenerRefusal | null;
}

/**
 * The gateway's PostgreSQL as its health snapshot describes it; every figure null when not said.
 * Only the answering node's view is known.
 */
export interface DatabaseIn {
  /** The node whose snapshot this is: the box sits beside it and its writes are the edge. */
  node: string;
  /** `db.internal (10.128.0.2):5432`. */
  server: string | null;
  name: string | null;
  /** PostgreSQL's `server_version`. */
  version: string | null;
  /** The newest migration applied. */
  schema: string | null;
  connectedSince: string | null;
  admission: "OK" | "DEGRADED" | "REFUSING" | null;
  /** `db_admission_reason`: which signal holds it outside OK (probe, pool, lag, log, logCap…). */
  reason: string | null;
  probeMs: number | null;
  poolActive: number | null;
  poolMax: number | null;
  poolWaitMs: number | null;
  /** The reserved lanes as text: `lease 1/2 · control 0/2`. */
  lanes: string | null;
  /** `db_write_rate`: rows a second the persistence bus last wrote. */
  writeRate: number | null;
  /** `persist_depth` summed, and the age of its oldest. */
  persistDepth: number | null;
  persistLagSeconds: number | null;
  /** The local log on disk, and its cap when the gateway says it. */
  logBytes: number | null;
  logCapBytes: number | null;
  /** Whether the log's fsync is succeeding; null when not said. */
  logHealthy: boolean | null;
  /** Submits refused for the database since start (`db_refused_total`). */
  refusedTotal: number | null;
}

/**
 * What waits on a node, from its health snapshot; each figure null when the gateway does not say.
 * Only the answering node's is known -- the others' are their own business.
 */
export interface NodeQueue {
  /** `router_queue`: the in-process router queue. */
  router: number | null;
  /** `backbone.routerLag`: the Kafka router topic not yet taken by the group. */
  lag: number | null;
  /** `persist_depth` summed over its streams: writes waiting for PostgreSQL. */
  persist: number | null;
  /** `persist_lag_seconds`: the age of the oldest of them. */
  persistLagSeconds: number | null;
  /** `routing_retry_queue` + `backbone.retryDepth`: waiting to be routed again. */
  retry: number | null;
  /** `smsg.persist.lag.max.seconds` (`persist_lag_max_seconds`), else {@link PERSIST_LAG_MAX_DEFAULT}. */
  persistLagMax: number;
}

/** How a node's queue moved over the samples the page kept ({@link queueTrend}). */
export interface QueueTrend {
  /** Up on each of the last {@link RISING_STEPS} samples, by at least {@link RISE_MIN} in all. */
  rising: boolean;
  /** Newest minus the start of the current run of increases; when the last step did not rise, that step's change (0 or less). */
  delta: number;
  /** How long that run (or step) took, in seconds. */
  seconds: number;
}

export interface NodeIn {
  id: string;
  /** The node this panel is asking. */
  self: boolean;
  alive: boolean;
  /** `kafka` or `memory`. */
  backbone: string;
  queue: NodeQueue | null;
  /** Null until the page holds enough samples to say, and on a node whose queue is not known. */
  trend: QueueTrend | null;
}

export interface VendorIn {
  id: string;
  name: string;
  rate: number | null;
  tpsLimit: number | null;
  bound: boolean;
  backlog: { state: "OK" | "PAUSED" | "THROTTLING" | "REFUSING"; depth: number } | null;
  held: boolean;
  suspended: boolean;
  /** A routing rule or a routed group names it, so an edge is drawn even while it is idle. */
  routed: boolean;
  node: string;
  /** Its route group: drawn inside the group's frame when the group has two or more vendors here. */
  group: string | null;
  /** Messages it took and receipts it reported over the window; null when not known. */
  mt: number | null;
  dlr: number | null;
}

export interface MapInput {
  clients: readonly ClientIn[];
  listeners: readonly ListenerIn[];
  nodes: readonly NodeIn[];
  vendors: readonly VendorIn[];
  /** The backbone is Kafka: the gateway box offers the Kafka page. */
  kafka: boolean;
  /** Which window the clients', listeners' and vendors' `mt`/`dlr` cover. */
  countsWindow: CountsWindow;
  /** The window's name when it is not the plain one ("since restart 09:42"), and why. */
  countsLabel?: string;
  countsNote?: string | null;
  /** The gateway's database; null or absent draws no Database box. */
  database?: DatabaseIn | null;
  /** The display zone, for the times in the tooltips; UTC when absent. */
  zone?: string;
}

export interface MapView {
  /** Open client groups, by listener full name (`+` for the other-ports group). */
  expanded: ReadonlySet<string>;
  pages: Readonly<Record<string, number>>;
  sorts: Readonly<Record<string, ClientSort>>;
  /** Show every port rather than collapsing the quietest into "+n ports". */
  allPorts: boolean;
  /**
   * Route groups by name: a group is open -- a frame around its members -- unless this says `false`,
   * when it is one box.
   */
  openVendorGroups: Readonly<Record<string, boolean>>;
}

export const EMPTY_VIEW: MapView = {
  expanded: new Set(),
  pages: {},
  sorts: {},
  allPorts: false,
  openVendorGroups: {},
};

/** Whether a route group is drawn open: the default, until its toggle closes it. */
export function vendorGroupOpen(view: MapView, name: string): boolean {
  return view.openVendorGroups[name] !== false;
}

/** Wide enough for `1,840/s · MT 61,204 · DLR 59,880` at the canvas's 10.5 px. */
export const BOX_W = 184;
/** The Database box: wide enough for `PostgreSQL · db.internal (10.128.0.2):5432`. */
export const DB_W = 280;
/** The Database box's id: there is one. */
export const DATABASE_BOX_ID = "d:database";
export const BOX_H = 44;
/** Between two boxes of one row. */
export const BOX_GAP = 16;
/** An open group's members per page. */
export const PAGE_SIZE = 10;
/** Ports shown before the quietest collapse into "+n ports". */
export const MAX_PORTS = 6;
/** A ceiling this close to reached draws the box in the warning colour. */
export const WARN_AT = 0.9;
/** A node's queue (router + lag + retry) past this many messages is the alarm tone on its box. */
export const LAG_WARN = 10_000;
/** The persist lag line when the gateway does not publish `smsg.persist.lag.max.seconds`: its default. */
export const PERSIST_LAG_MAX_DEFAULT = 60;
/** Samples of a node's queue the page keeps: a minute at the five-second poll. */
export const QUEUE_SAMPLES = 12;
/** Rising is up on each of this many consecutive polls... */
export const RISING_STEPS = 3;
/** ...by at least this much in all, so a queue wobbling at a few hundred does not flash orange. */
export const RISE_MIN = 1_000;

const BAND_X = 8;
const PAD_X = 24;
const PAD_TOP = 26;
const PAD_BOTTOM = 14;
const TIER_GAP = 56;
const GROUP_HEAD = 24;
const GROUP_PAD = 8;
const MIN_WIDTH = 720;
/** How far a receipt runs beside the submit it answers. */
export const RECEIPT_OFFSET = 7;
/** The id of the "+n ports" box and of the group holding those ports' clients. */
export const OTHER_PORTS = "+";

/** Edge width: 1.2 px under 50/s to 4 px at 2,000/s and above, on a log scale. */
export function edgeWidth(rate: number | null | undefined): number {
  return 1.2 + 2.8 * rateScale(rate);
}

/** Where a rate sits between 50/s (0) and 2,000/s (1), logarithmically; what width and dot speed share. */
export function rateScale(rate: number | null | undefined): number {
  if (rate == null || !(rate > 50)) {
    return 0;
  }
  const t = (Math.log(rate) - Math.log(50)) / (Math.log(2000) - Math.log(50));
  return Math.min(1, t);
}

/** Dots on one edge: a dot per 400/s, at most five; one still dot on a link moving nothing. */
export function dotCount(rate: number | null | undefined): number {
  return rate != null && rate > 0 ? Math.min(5, Math.ceil(rate / 400)) : 1;
}

/** Dot speed in content pixels per second: still at zero, 24 → 160 across the rate scale. */
export function dotSpeed(rate: number | null | undefined): number {
  return rate != null && rate > 0 ? 24 + 136 * rateScale(Math.max(rate, 50)) : 0;
}

/** `1,840/s`; a dash when nothing was measured. */
export function rateText(rate: number | null | undefined): string {
  return rate == null ? "—/s" : `${formatTps(rate >= 10 ? Math.round(rate) : Math.round(rate * 10) / 10)}/s`;
}

/**
 * A count as a box shows it: in full up to 99,999, then `612k`, `1.24M`. The tooltip carries the
 * full figure ({@link fullCount}).
 */
export function formatCount(n: number | null | undefined): string {
  if (n == null || !Number.isFinite(n)) {
    return "—";
  }
  const v = Math.max(0, Math.round(n));
  if (v <= 99_999) {
    return localeNumber(v);
  }
  if (v < 999_500) {
    return `${Math.round(v / 1000)}k`;
  }
  const m = v / 1_000_000;
  return `${Number(m.toFixed(m < 10 ? 2 : m < 100 ? 1 : 0))}M`;
}

/** A count in full, for a tooltip; a dash when unknown. */
export function fullCount(n: number | null | undefined): string {
  return n == null || !Number.isFinite(n) ? "—" : localeNumber(Math.max(0, Math.round(n)));
}

/** `MT 61,204 · DLR 59,880`; empty when neither is known. */
export function countsText(mt: number | null | undefined, dlr: number | null | undefined): string {
  return mt == null && dlr == null ? "" : `MT ${formatCount(mt)} · DLR ${formatCount(dlr)}`;
}

/** A box's second line: the rate and the counts, or `fallback` when no count is known. */
export function figuresLine(rate: number | null | undefined, mt: number | null | undefined, dlr: number | null | undefined, fallback: string): string {
  const counts = countsText(mt, dlr);
  return counts ? `${rateText(rate)} · ${counts}` : fallback;
}

/** The tooltip rows for two counts over the window: nothing when neither is known. */
function countFacts(mt: number | null, dlr: number | null, label: string): [string, string][] {
  return mt == null && dlr == null ? [] : [[`MT · ${label}`, fullCount(mt)], [`DLR · ${label}`, fullCount(dlr)]];
}

function sum(values: readonly (number | null)[]): number | null {
  let out: number | null = null;
  for (const v of values) {
    if (v != null) {
      out = (out ?? 0) + v;
    }
  }
  return out;
}

const STATE_RANK: Record<BoxState, number> = { ok: 0, warn: 1, alarm: 2, refusing: 3, down: 4 };

function worst(states: readonly BoxState[]): BoxState {
  return states.reduce<BoxState>((a, b) => (STATE_RANK[b] > STATE_RANK[a] ? b : a), "ok");
}

export function clientState(c: ClientIn): BoxState {
  if (c.binds <= 0) {
    return "down";
  }
  if ((c.refusedRate ?? 0) > 0 || (c.ceiling != null && c.ceiling > 0 && (c.rate ?? 0) >= c.ceiling * WARN_AT)) {
    return "warn";
  }
  return "ok";
}

export function listenerState(l: ListenerIn): BoxState {
  if (!l.live || l.error) {
    return "down";
  }
  return l.held || l.suspended ? "warn" : "ok";
}

/** Router queue + router lag + retry; null when none of them is known. */
export function queueTotal(q: NodeQueue | null | undefined): number | null {
  return q ? sum([q.router, q.lag, q.retry]) : null;
}

/** Which line a node's queue has crossed, if any: the queue's {@link LAG_WARN} or the persist lag's. */
export function queuePastLine(q: NodeQueue | null | undefined): "queue" | "persist" | null {
  if (!q) {
    return null;
  }
  if ((queueTotal(q) ?? 0) > LAG_WARN) {
    return "queue";
  }
  return q.persistLagSeconds != null && q.persistLagSeconds > q.persistLagMax ? "persist" : null;
}

/** One kept reading of a node's queue: when (ms) and the {@link queueTotal}. */
export interface QueueSample {
  at: number;
  queue: number | null;
}

/**
 * How the queue moved, from the samples the page kept (oldest first). Rising when each of the last
 * {@link RISING_STEPS} steps went up and the run of increases ending now adds up to {@link RISE_MIN}
 * or more; the delta and seconds are that whole run's, so a queue climbing for thirty seconds says
 * so. Null with fewer than two known readings.
 */
export function queueTrend(samples: readonly QueueSample[]): QueueTrend | null {
  const known = samples.filter((s): s is { at: number; queue: number } => s.queue != null);
  if (known.length < 2) {
    return null;
  }
  const last = known.length - 1;
  let start = last;
  while (start > 0 && known[start - 1].queue < known[start].queue) {
    start--;
  }
  //the last step did not rise: say how it moved instead
  const from = start === last ? last - 1 : start;
  const delta = known[last].queue - known[from].queue;
  return {
    rising: last - start >= RISING_STEPS && delta >= RISE_MIN,
    delta,
    seconds: Math.round((known[last].at - known[from].at) / 1000),
  };
}

export function nodeState(n: NodeIn): BoxState {
  if (!n.alive) {
    return "down";
  }
  return queuePastLine(n.queue) || n.trend?.rising ? "alarm" : "ok";
}

/** The node's second line: `1,007/s in · queue 0`, with `▲` while the queue is rising. */
export function nodeLine(rateIn: number | null, n: NodeIn): string {
  const q = queueTotal(n.queue);
  return `${rateText(rateIn)} in · queue ${formatCount(q)}${n.trend?.rising ? " ▲" : ""}`;
}

/** The trend as the tooltip says it: "rising 2,300 in 30 s", "steady", "falling". */
export function trendText(t: QueueTrend | null | undefined): string {
  if (!t) {
    return "—";
  }
  if (t.delta > 0) {
    return `${t.rising ? "rising" : "up"} ${fullCount(t.delta)} in ${t.seconds} s`;
  }
  return t.delta < 0 ? "falling" : "steady";
}

export function vendorState(v: VendorIn): BoxState {
  if (!v.bound || v.backlog?.state === "REFUSING") {
    return "down";
  }
  if (
    v.backlog?.state === "THROTTLING"
    || v.held
    || v.suspended
    || (v.tpsLimit != null && v.tpsLimit > 0 && (v.rate ?? 0) >= v.tpsLimit * WARN_AT)
  ) {
    return "warn";
  }
  return "ok";
}

/** The database's state: its admission's. Unknown reads as OK -- the box says "—" for what it does not know. */
/** The reasons on which the door refuses submits (0.15.1): the local log, never the database's own latency. */
export const DOOR_REASONS: ReadonlySet<string> = new Set(["logCap", "logFsync", "logUnavailable"]);

export function databaseState(d: Pick<DatabaseIn, "admission" | "reason">): BoxState {
  //since accept-and-queue (0.15.1) a slow database refuses nothing: the door refuses only for the local
  //log, which the reason names. REFUSING on its own is "slow", a warning, not a refusal
  if (DOOR_REASONS.has(d.reason ?? "")) {
    return "refusing";
  }
  return d.admission === "REFUSING" || d.admission === "DEGRADED" ? "warn" : "ok";
}

/** `1,840 rows/s`. */
function rowsText(rate: number | null | undefined): string {
  return rateText(rate).replace(/\/s$/, " rows/s");
}

/** The Database box's two lines; what is not known is left out, and a line with nothing known is a dash. */
export function databaseLines(d: DatabaseIn): [string, string] {
  const where = d.server ?? d.name;
  const parts = [
    ...(d.probeMs != null ? [`probe ${localeNumber(Math.round(d.probeMs))} ms`] : []),
    ...(d.poolActive != null ? [`pool ${d.poolActive}${d.poolMax != null ? `/${d.poolMax}` : ""}`] : []),
    ...(d.writeRate != null ? [rowsText(d.writeRate)] : []),
  ];
  return [where ? `PostgreSQL · ${where}` : "PostgreSQL", parts.length ? parts.join(" · ") : "—"];
}

/** A refusal reason the database causes: `dbUnavailable`, and the log cap's `logCap`. */
export function isDbReason(reason: string): boolean {
  return reason === "dbUnavailable" || reason === "logCap";
}

function percent(share: number): string {
  const p = Math.round(share * 100);
  return p === 0 ? "<1 %" : `${p} %`;
}

/** `dbUnavailable 80 % · creditPending 20 %`: most first, `max` named, the rest as "other". */
export function reasonMix(by: readonly ReasonCount[], max = 3): string {
  const rows = by.filter((r) => r.count > 0).sort((a, b) => b.count - a.count || a.reason.localeCompare(b.reason));
  const total = rows.reduce((n, r) => n + r.count, 0);
  if (!total) {
    return "";
  }
  const named = rows.slice(0, max).map((r) => `${r.reason} ${percent(r.count / total)}`);
  const rest = rows.slice(max).reduce((n, r) => n + r.count, 0);
  return [...named, ...(rest ? [`other ${percent(rest / total)}`] : [])].join(" · ");
}

/** A refused edge's label: `312/s refused · dbUnavailable 80 % · creditPending 20 %`. */
export function refusedLabel(r: ListenerRefusal): string {
  const mix = reasonMix(r.by);
  return `${rateText(r.rate)} refused${mix ? ` · ${mix}` : ""}`;
}

/**
 * What the doors refuse for the database, a second: the database-driven reasons' share of every
 * listener's last full minute -- but only when they are the dominant reason, so a minute mostly
 * refused for credit does not paint the database. Null otherwise, and when nothing was refused.
 */
export function databaseRefusing(listeners: readonly Pick<ListenerIn, "refused">[]): number | null {
  const by = new Map<string, number>();
  for (const l of listeners) {
    for (const r of l.refused?.by ?? []) {
      by.set(r.reason, (by.get(r.reason) ?? 0) + Math.max(0, r.count));
    }
  }
  const sorted = [...by.entries()].filter(([, n]) => n > 0).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  if (!sorted.length || !isDbReason(sorted[0][0])) {
    return null;
  }
  return sorted.filter(([r]) => isDbReason(r)).reduce((n, [, c]) => n + c, 0) / 60;
}

/** An ISO instant as the tooltip shows it, in the display zone and named; the text itself when it does not parse. */
function zonedMoment(iso: string, zone: string): string {
  const t = Date.parse(iso);
  return Number.isFinite(t) ? `${formatTimestamp(t, zone)} ${zoneShortName(zone, t)}` : iso;
}

/** The Database box's tooltip. */
function databaseFacts(d: DatabaseIn, refusing: number | null, zone: string): [string, string][] {
  const out: [string, string][] = [
    ["Server", d.version ? `PostgreSQL ${d.version}` : "—"],
    ["Address", d.server ?? "—"],
  ];
  if (d.name) {
    out.push(["Database", d.name]);
  }
  out.push(["Schema", d.schema ?? "—"]);
  if (d.connectedSince) {
    out.push(["Connected since", zonedMoment(d.connectedSince, zone)]);
  }
  out.push(
    ["Admission", d.admission ? `${d.admission}${d.reason ? ` · ${d.reason}` : ""}` : "—"],
    ["Probe", d.probeMs != null ? `${localeNumber(Math.round(d.probeMs))} ms` : "—"],
    ["Pool", d.poolActive != null
      ? `${d.poolActive}${d.poolMax != null ? ` of ${d.poolMax}` : ""}${d.poolWaitMs != null ? ` · wait ${Math.round(d.poolWaitMs)} ms` : ""}`
      : "—"],
  );
  if (d.lanes) {
    out.push(["Lanes", d.lanes]);
  }
  out.push(
    ["Writes", d.writeRate != null ? rowsText(d.writeRate) : "—"],
    ["Persistence", d.persistDepth == null
      ? "—"
      : `${fullCount(d.persistDepth)}${d.persistLagSeconds != null ? ` · ${Math.round(d.persistLagSeconds)} s behind` : ""}`],
    ["Local log", d.logBytes == null
      ? "—"
      : `${bytes(d.logBytes)}${d.logCapBytes != null && d.logCapBytes > 0 ? ` of ${bytes(d.logCapBytes)}` : ""}${d.logHealthy === false ? " · fsync failing" : ""}`],
    ["Refused for it", d.refusedTotal != null ? `${fullCount(d.refusedTotal)} since start` : "—"],
  );
  if (refusing != null) {
    out.push(["Refusing now", `${rateText(refusing)} · last minute`]);
  }
  return out;
}

/** A group's members in its sort: busiest first, most binds first, or by name; ties by name. */
export function sortClients(clients: readonly ClientIn[], sort: ClientSort): ClientIn[] {
  const name = (a: ClientIn, b: ClientIn) => a.account.localeCompare(b.account) || a.key.localeCompare(b.key);
  return [...clients].sort((a, b) => {
    if (sort === "rate") {
      return (b.rate ?? -1) - (a.rate ?? -1) || name(a, b);
    }
    if (sort === "binds") {
      return b.binds - a.binds || name(a, b);
    }
    return name(a, b);
  });
}

/** Which listeners get a box, and which collapse into "+n ports": the quietest beyond {@link MAX_PORTS}. */
export function visiblePorts(listeners: readonly ListenerIn[], allPorts: boolean): { shown: ListenerIn[]; hidden: ListenerIn[] } {
  const busiest = [...listeners].sort((a, b) => (b.rate ?? -1) - (a.rate ?? -1) || b.bound - a.bound || a.name.localeCompare(b.name));
  const keep = allPorts || busiest.length <= MAX_PORTS ? busiest : busiest.slice(0, MAX_PORTS);
  const hidden = busiest.slice(keep.length);
  //drawn in name order, so a port does not hop sideways every time its rate overtakes a neighbour's
  return { shown: keep.sort((a, b) => a.name.localeCompare(b.name)), hidden };
}

/** One client box's id. */
export function clientBoxId(listener: string, key: string): string {
  return `c:${listener}:${key}`;
}

export function groupBoxId(listener: string): string {
  return `g:${listener}`;
}

export function listenerBoxId(id: string): string {
  return `l:${id}`;
}

export function vendorBoxId(id: string): string {
  return `v:${id}`;
}

export function nodeBoxId(id: string): string {
  return `n:${id}`;
}

/** A route group's box: its frame while open, the one box while collapsed. */
export function vendorGroupBoxId(name: string): string {
  return `vg:${name}`;
}

/** A row of a tier before it is placed: its width and how to place it at x. */
interface Item {
  width: number;
  place: (x: number, y: number) => void;
}

interface Pending {
  id: string;
  from: string;
  to: string;
  kind: EdgeKind;
  rate: number;
  mt: number | null;
  dlr: number | null;
  label?: string;
  state?: BoxState;
  /** Tooltip rows after the rate and the counts. */
  facts?: [string, string][];
}

/** What an edge carries beyond its rate and counts. */
interface EdgeExtra {
  label?: string;
  state?: BoxState;
  facts?: [string, string][];
}

/** Lay the map out. */
export function layoutMap(input: MapInput, view: MapView = EMPTY_VIEW): MapLayout {
  const boxes: MapBox[] = [];
  const pending: Pending[] = [];
  const win = input.countsLabel ?? COUNTS_WINDOW_LABEL[input.countsWindow];
  const add = (box: Omit<MapBox, "rect" | "mt" | "dlr"> & { rect?: Rect; mt?: number | null; dlr?: number | null }) => {
    const full = { rect: { x: 0, y: 0, w: BOX_W, h: BOX_H }, mt: null, dlr: null, ...box } as MapBox;
    boxes.push(full);
    return full;
  };
  //an edge carries the counts of the flow it draws: the client's, the listener's or the vendor's
  const edge = (
    from: string,
    to: string,
    kind: EdgeKind,
    rate: number | null,
    counts?: { mt: number | null; dlr: number | null },
    extra: EdgeExtra = {}
  ) => {
    pending.push({ id: `${kind}:${from}>${to}`, from, to, kind, rate: Math.max(0, rate ?? 0), mt: counts?.mt ?? null, dlr: counts?.dlr ?? null, ...extra });
  };
  //a port's refusals over the last full minute, as its tooltip rows
  const refusalFacts = (r: ListenerRefusal | null | undefined): [string, string][] => (r
    ? [["Refused/s · last minute", rateText(r.rate)], ["Reasons", reasonMix(r.by) || "—"]]
    : []);

  //─── listeners first: which are shown decides how the clients group ───
  const { shown, hidden } = visiblePorts(input.listeners, view.allPorts);
  const nodeIds = new Set(input.nodes.map((n) => n.id));
  const listenerItems: Item[] = [];
  for (const l of shown) {
    const box = add({
      id: listenerBoxId(l.id),
      kind: "listener",
      tier: "listeners",
      lines: [
        `${l.name}${l.port ? ` :${l.port}` : ""}`,
        figuresLine(l.rate, l.mt, l.dlr, `${l.bound} bound · ${rateText(l.rate)}${l.ceiling ? ` · ≤${l.ceiling}/acct` : ""}`),
      ],
      state: listenerState(l),
      actions: ["open-listener", l.held ? "release" : "hold", "default-rate", "overrides", "connections", "disable"],
      quick: [l.held ? "release" : "hold", "connections", "open-listener"],
      facts: [
        ["Port", l.port ?? "—"],
        ["Bound", String(l.bound)],
        ["Messages/s", rateText(l.rate)],
        ...countFacts(l.mt, l.dlr, win),
        ["Ceiling per account", l.ceiling ? `≤${l.ceiling}/s` : "none"],
        ...refusalFacts(l.refused),
        ...(l.held ? [["State", "not accepting"] as [string, string]] : []),
        ...(!l.live ? [["State", "not running"] as [string, string]] : []),
      ],
      ref: l.id,
      rate: l.rate,
      mt: l.mt,
      dlr: l.dlr,
    });
    if (l.refused) {
      box.speech = `${box.lines.join(", ")}, refusing ${rateText(l.refused.rate)}${reasonMix(l.refused.by) ? `: ${reasonMix(l.refused.by).replaceAll(" · ", ", ")}` : ""}`;
    }
    listenerItems.push({ width: BOX_W, place: (x, y) => (box.rect = { x, y, w: BOX_W, h: BOX_H }) });
  }
  if (hidden.length) {
    const rate = sum(hidden.map((l) => l.rate));
    const mt = sum(hidden.map((l) => l.mt));
    const dlr = sum(hidden.map((l) => l.dlr));
    const box = add({
      id: listenerBoxId(OTHER_PORTS),
      kind: "portsMore",
      tier: "listeners",
      lines: [
        `+${hidden.length} port${hidden.length === 1 ? "" : "s"}`,
        figuresLine(rate, mt, dlr, `${hidden.reduce((n, l) => n + l.bound, 0)} bound · ${rateText(rate)}`),
      ],
      state: worst(hidden.map(listenerState)),
      actions: ["toggle"],
      quick: ["toggle"],
      facts: [
        ...hidden.map((l) => [l.name, `${l.bound} bound · ${rateText(l.rate)}`] as [string, string]),
        ...countFacts(mt, dlr, win),
      ],
      ref: OTHER_PORTS,
      rate,
      mt,
      dlr,
    });
    listenerItems.push({ width: BOX_W, place: (x, y) => (box.rect = { x, y, w: BOX_W, h: BOX_H }) });
  }

  //─── clients: one group per shown listener, then one for every hidden port ───
  const byListener = new Map<string, ClientIn[]>();
  for (const c of input.clients) {
    const list = byListener.get(c.listener);
    if (list) {
      list.push(c);
    } else {
      byListener.set(c.listener, [c]);
    }
  }
  //a group's counts are its members' sum; when no member knows its own (split by IP over the last
  //hour, which the series cannot cut by address) the port's own stand in
  type Group = { key: string; title: string; clients: ClientIn[]; target: string; mt: number | null; dlr: number | null };
  const groups: Group[] = shown
    .map((l) => ({ key: l.id, title: l.name, clients: byListener.get(l.id) ?? [], target: listenerBoxId(l.id), mt: l.mt, dlr: l.dlr }));
  if (hidden.length) {
    groups.push({
      key: OTHER_PORTS,
      title: "other ports",
      clients: hidden.flatMap((l) => byListener.get(l.id) ?? []),
      target: listenerBoxId(OTHER_PORTS),
      mt: sum(hidden.map((l) => l.mt)),
      dlr: sum(hidden.map((l) => l.dlr)),
    });
  }

  const clientItems: Item[] = [];
  let anyOpen = false;
  for (const g of groups) {
    if (!g.clients.length) {
      continue;
    }
    const rate = sum(g.clients.map((c) => c.rate));
    const receipts = sum(g.clients.map((c) => c.receiptRate));
    const refused = sum(g.clients.map((c) => c.refusedRate));
    const mt = sum(g.clients.map((c) => c.mt)) ?? g.mt;
    const dlr = sum(g.clients.map((c) => c.dlr)) ?? g.dlr;
    const counts = countsText(mt, dlr);
    const id = groupBoxId(g.key);
    const sort = view.sorts[g.key] ?? "rate";
    const open = view.expanded.has(g.key);
    const sortActions: BoxAction[] = ["sort-rate", "sort-binds", "sort-name"];
    const groupFacts: [string, string][] = [
      ["Clients", String(g.clients.length)],
      ["Binds", String(g.clients.reduce((n, c) => n + c.binds, 0))],
      ["Messages/s", rateText(rate)],
      ["Receipts/s", rateText(receipts)],
      ...countFacts(mt, dlr, win),
    ];
    if (!open) {
      const box = add({
        id,
        kind: "clientGroup",
        tier: "clients",
        lines: counts
          ? [`▸ ${g.title} clients · ${g.clients.length}`, `${rateText(rate)} · ${counts}`]
          : [`▸ ${g.title} clients`, `${g.clients.length} · ${rateText(rate)}`],
        state: worst(g.clients.map(clientState).map((s) => (s === "down" ? "ok" : s))),
        actions: ["toggle", ...sortActions],
        quick: ["toggle"],
        facts: groupFacts,
        ref: g.key,
        listener: g.key,
        rate,
        mt,
        dlr,
      });
      clientItems.push({ width: BOX_W, place: (x, y) => (box.rect = { x, y, w: BOX_W, h: BOX_H }) });
      edge(id, g.target, "submit", rate, { mt, dlr });
      if ((receipts ?? 0) > 0) {
        edge(g.target, id, "receipt", receipts, { mt, dlr });
      }
      if ((refused ?? 0) > 0) {
        edge(id, g.target, "refused", refused);
      }
      continue;
    }

    anyOpen = true;
    const sorted = sortClients(g.clients, sort);
    const pages = Math.max(1, Math.ceil(sorted.length / PAGE_SIZE));
    const page = Math.min(Math.max(0, view.pages[g.key] ?? 0), pages - 1);
    const members = sorted.slice(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE);
    const rest = sorted.filter((c) => !members.includes(c));
    const frame = add({
      id,
      kind: "clientGroup",
      tier: "clients",
      lines: [
        `▾ ${g.title} clients · ${g.clients.length} · ${rateText(rate)}${counts ? ` · ${counts}` : ""}`,
        `${pages > 1 ? `page ${page + 1} of ${pages} · ` : ""}sort: ${sort}`,
      ],
      state: "ok",
      actions: ["toggle", ...sortActions],
      quick: ["toggle"],
      facts: groupFacts,
      ref: g.key,
      listener: g.key,
      frame: true,
      rate,
      mt,
      dlr,
    });
    const placed: MapBox[] = [];
    for (const c of members) {
      const label = c.ip ? `${c.account} · ${c.ip}` : c.account;
      const named = c.account !== "—";
      placed.push(add({
        id: clientBoxId(g.key, c.key),
        kind: "client",
        tier: "clients",
        lines: [label, figuresLine(c.rate, c.mt, c.dlr, `${rateText(c.rate)} · ${c.binds} bind${c.binds === 1 ? "" : "s"}`)],
        state: clientState(c),
        actions: named
          ? ["open-account", "set-rate", "set-binds", "client-sessions", "client-live", "drop-binds"]
          : ["client-sessions", "drop-binds"],
        quick: named ? ["open-account", "client-live", "drop-binds"] : ["client-sessions"],
        facts: [
          ["Account", c.account],
          ...(c.ip ? [["From", c.ip] as [string, string]] : c.hosts.length ? [["From", c.hosts.join(", ")] as [string, string]] : []),
          ...(c.logins.length ? [["Logins", c.logins.join(", ")] as [string, string]] : []),
          ["Binds", String(c.binds)],
          ["Messages/s", rateText(c.rate)],
          ["Receipts/s", rateText(c.receiptRate)],
          ...countFacts(c.mt, c.dlr, win),
          ["Ceiling", c.ceiling ? `≤${c.ceiling}/s` : "none"],
          ...((c.refusedRate ?? 0) > 0 ? [["Throttled", rateText(c.refusedRate)] as [string, string]] : []),
        ],
        ref: c.account,
        listener: c.listener,
        parent: id,
        rate: c.rate,
        mt: c.mt,
        dlr: c.dlr,
      }));
      const own = { mt: c.mt, dlr: c.dlr };
      edge(clientBoxId(g.key, c.key), g.target, "submit", c.rate, own);
      if ((c.receiptRate ?? 0) > 0) {
        edge(g.target, clientBoxId(g.key, c.key), "receipt", c.receiptRate, own);
      }
      if ((c.refusedRate ?? 0) > 0) {
        edge(clientBoxId(g.key, c.key), g.target, "refused", c.refusedRate);
      }
    }
    if (rest.length) {
      const restRate = sum(rest.map((c) => c.rate));
      const restMt = sum(rest.map((c) => c.mt));
      const restDlr = sum(rest.map((c) => c.dlr));
      const last = page === pages - 1;
      const chipId = `m:${g.key}`;
      placed.push(add({
        id: chipId,
        kind: "clientMore",
        tier: "clients",
        lines: [`+${rest.length} more · ${rateText(restRate)}`, last ? "first 10 ↺" : `next ${Math.min(PAGE_SIZE, sorted.length - (page + 1) * PAGE_SIZE)} ▸`],
        state: "ok",
        actions: ["next-page", "toggle"],
        quick: ["next-page"],
        facts: [["Not shown", String(rest.length)], ["Messages/s", rateText(restRate)], ...countFacts(restMt, restDlr, win)],
        ref: g.key,
        listener: g.key,
        parent: id,
        rate: restRate,
        mt: restMt,
        dlr: restDlr,
      }));
      edge(chipId, g.target, "submit", restRate, { mt: restMt, dlr: restDlr });
      const restReceipts = sum(rest.map((c) => c.receiptRate));
      if ((restReceipts ?? 0) > 0) {
        edge(g.target, chipId, "receipt", restReceipts, { mt: restMt, dlr: restDlr });
      }
    }
    const inner = placed.length * BOX_W + (placed.length - 1) * BOX_GAP;
    const width = Math.max(inner, BOX_W * 2) + GROUP_PAD * 2;
    clientItems.push({
      width,
      place: (x, y) => {
        frame.rect = { x, y: y - GROUP_HEAD, w: width, h: GROUP_HEAD + BOX_H + GROUP_PAD };
        placed.forEach((b, i) => (b.rect = { x: x + GROUP_PAD + i * (BOX_W + BOX_GAP), y, w: BOX_W, h: BOX_H }));
      },
    });
  }

  //─── refused at the door: each refusing port's edge back up to its clients ───
  const hiddenRefused = hidden.filter((l) => l.refused && l.refused.rate > 0);
  const doors: { from: string; to: string; refusal: ListenerRefusal }[] = shown
    .filter((l) => l.refused && l.refused.rate > 0)
    .map((l) => ({ from: listenerBoxId(l.id), to: groupBoxId(l.id), refusal: l.refused! }));
  if (hiddenRefused.length) {
    const by = new Map<string, number>();
    for (const r of hiddenRefused.flatMap((l) => l.refused!.by)) {
      by.set(r.reason, (by.get(r.reason) ?? 0) + r.count);
    }
    doors.push({
      from: listenerBoxId(OTHER_PORTS),
      to: groupBoxId(OTHER_PORTS),
      refusal: {
        rate: hiddenRefused.reduce((n, l) => n + l.refused!.rate, 0),
        total: hiddenRefused.reduce((n, l) => n + l.refused!.total, 0),
        by: [...by.entries()].map(([reason, count]) => ({ reason, count })),
      },
    });
  }
  for (const d of doors) {
    edge(d.from, d.to, "refused", d.refusal.rate, undefined, {
      label: refusedLabel(d.refusal),
      facts: [["In the minute", fullCount(d.refusal.total)], ...[...d.refusal.by].sort((a, b) => b.count - a.count).map((r) => [r.reason, fullCount(r.count)] as [string, string])],
    });
  }

  //─── gateway nodes: the live ones first ───
  const nodes = [...input.nodes].sort((a, b) => Number(b.alive) - Number(a.alive) || Number(b.self) - Number(a.self) || a.id.localeCompare(b.id));
  const vendorsOn = (node: string) => input.vendors.filter((v) => v.node === node);
  const nodeItems: Item[] = [];
  for (const n of nodes) {
    const listeners = input.listeners.filter((l) => l.node === n.id);
    const rateIn = sum(listeners.map((l) => l.rate));
    //the node's totals are what its listeners took in and sent back down
    const mt = sum(listeners.map((l) => l.mt));
    const dlr = sum(listeners.map((l) => l.dlr));
    const bound = vendorsOn(n.id).filter((v) => v.bound).length;
    const q = n.queue;
    const lines: [string, string] = [`${n.id} · Router`, n.alive ? nodeLine(rateIn, n) : "missed its heartbeat"];
    const state = nodeState(n);
    const persist = q?.persist == null
      ? "—"
      : `${fullCount(q.persist)}${q.persistLagSeconds != null ? ` · ${Math.round(q.persistLagSeconds)} s behind` : ""}`;
    const box = add({
      id: nodeBoxId(n.id),
      kind: "node",
      tier: "nodes",
      //the counts move to the tooltip: the line is the rate in and the queue
      lines,
      state,
      actions: ["health", "queues", ...(input.kafka ? ["kafka" as const] : []), "routing", "refused"],
      quick: ["health", "queues"],
      facts: [
        ["Backbone", n.backbone],
        ["In", rateText(rateIn)],
        ...countFacts(mt, dlr, win),
        ["Queue", fullCount(queueTotal(q))],
        ["Router queue", fullCount(q?.router)],
        ["Router lag", fullCount(q?.lag)],
        ["Retry", fullCount(q?.retry)],
        ["Persistence", persist],
        ["Trend", trendText(n.trend)],
        ["Line", `${localeNumber(LAG_WARN)} queued · ${q?.persistLagMax ?? PERSIST_LAG_MAX_DEFAULT} s persist`],
        ...(queuePastLine(q) === "queue" ? [["Past the line", "queue"] as [string, string]] : []),
        ...(queuePastLine(q) === "persist" ? [["Past the line", "persist lag"] as [string, string]] : []),
        ["Vendors bound", String(bound)],
        ...(n.self ? [["", "the node this panel asks"] as [string, string]] : []),
      ],
      ref: n.id,
      rate: rateIn,
      mt,
      dlr,
      speech: `${lines[0]}, ${lines[1].replace(" ▲", " rising")}`,
    });
    nodeItems.push({ width: BOX_W, place: (x, y) => (box.rect = { x, y, w: BOX_W, h: BOX_H }) });
  }
  //─── the database, right beside the node whose snapshot describes it ───
  const db = input.database ?? null;
  if (db) {
    const refusing = databaseRefusing(input.listeners);
    const lines = databaseLines(db);
    const state = databaseState(db);
    const box = add({
      id: DATABASE_BOX_ID,
      kind: "database",
      tier: "nodes",
      lines,
      state,
      actions: ["queues", "health", "slow-queries"],
      quick: ["queues", "slow-queries"],
      facts: databaseFacts(db, refusing, input.zone ?? "UTC"),
      ref: db.server ?? db.name ?? "database",
      rate: db.writeRate,
      ...(refusing != null ? { badge: `refusing ${rateText(refusing)}` } : {}),
      speech: `Database ${lines[0]}, ${lines[1]}${refusing != null ? `, refusing ${rateText(refusing)}` : ""}`,
    });
    const at = nodes.findIndex((n) => n.id === db.node);
    nodeItems.splice(at < 0 ? nodeItems.length : at + 1, 0, { width: DB_W, place: (x, y) => (box.rect = { x, y, w: DB_W, h: BOX_H }) });
    if (nodeIds.has(db.node)) {
      edge(nodeBoxId(db.node), DATABASE_BOX_ID, "persist", db.writeRate, undefined, {
        state,
        facts: [
          ["Persistence depth", fullCount(db.persistDepth)],
          ["Lag", db.persistLagSeconds != null ? `${Math.round(db.persistLagSeconds)} s` : "—"],
          ["Database", db.admission ?? "—"],
        ],
      });
    }
  }

  for (const l of shown) {
    if (nodeIds.has(l.node)) {
      edge(listenerBoxId(l.id), nodeBoxId(l.node), "submit", l.rate, l);
      const receipts = sum((byListener.get(l.id) ?? []).map((c) => c.receiptRate));
      if ((receipts ?? 0) > 0) {
        edge(nodeBoxId(l.node), listenerBoxId(l.id), "receipt", receipts, l);
      }
    }
  }
  if (hidden.length) {
    for (const node of new Set(hidden.map((l) => l.node))) {
      if (nodeIds.has(node)) {
        const on = hidden.filter((l) => l.node === node);
        edge(listenerBoxId(OTHER_PORTS), nodeBoxId(node), "submit", sum(on.map((l) => l.rate)), {
          mt: sum(on.map((l) => l.mt)),
          dlr: sum(on.map((l) => l.dlr)),
        });
      }
    }
  }

  //─── vendors; a route group of two or more is a frame around them, or one box when collapsed ───
  const vendors = [...input.vendors].sort((a, b) => a.name.localeCompare(b.name));
  const groupSizes = new Map<string, number>();
  for (const v of vendors) {
    if (v.group) {
      groupSizes.set(v.group, (groupSizes.get(v.group) ?? 0) + 1);
    }
  }
  const grouped = (v: VendorIn) => v.group != null && (groupSizes.get(v.group) ?? 0) > 1;
  const vendorItems: Item[] = [];
  const doneGroups = new Set<string>();
  let anyVendorFrame = false;
  //one vendor's box and its edge from the node; `parent` is the frame it sits in
  const vendorBox = (v: VendorIn, parent?: string) => {
    const state = vendorState(v);
    const backlog = v.backlog && v.backlog.depth > 0 ? ` · backlog ${compact(v.backlog.depth)}` : "";
    const box = add({
      id: vendorBoxId(v.id),
      kind: "vendor",
      tier: "vendors",
      //bound, the counts take the line and the ceiling and backlog move to the tooltip; the box's
      //colour still says a backlog is throttling or refusing
      lines: [v.name, v.bound ? figuresLine(v.rate, v.mt, v.dlr, `${rateText(v.rate)}${v.tpsLimit ? ` · ≤${v.tpsLimit}` : ""}${backlog}`) : `unbound${backlog}`],
      state,
      actions: ["open-vendor", v.held ? "unpause" : "pause", v.suspended ? "resume" : "suspend", "restart", "set-tps", "backlog"],
      quick: [v.held ? "unpause" : "pause", v.suspended ? "resume" : "suspend", "restart"],
      facts: [
        ["Messages/s", rateText(v.rate)],
        ...countFacts(v.mt, v.dlr, win),
        ["TPS limit", v.tpsLimit ? `≤${v.tpsLimit}` : "none"],
        ["Bound", v.bound ? "yes" : "no"],
        ...(v.backlog ? [["Backlog", `${v.backlog.depth < 0 ? "—" : localeNumber(v.backlog.depth)} · ${v.backlog.state}`] as [string, string]] : []),
        ...(v.group ? [["Group", v.group] as [string, string]] : []),
        ...(v.held ? [["State", v.group ? "paused · routed around" : "sending paused"] as [string, string]] : []),
        ...(v.suspended ? [["State", "suspended"] as [string, string]] : []),
      ],
      ref: v.id,
      ...(parent ? { parent } : {}),
      rate: v.rate,
      mt: v.mt,
      dlr: v.dlr,
    });
    if (nodeIds.has(v.node) && (v.routed || v.bound || (v.rate ?? 0) > 0)) {
      edge(nodeBoxId(v.node), vendorBoxId(v.id), state === "down" ? "refused" : "submit", v.rate, v);
    }
    return box;
  };
  for (const v of vendors) {
    if (!grouped(v)) {
      const box = vendorBox(v);
      vendorItems.push({ width: BOX_W, place: (x, y) => (box.rect = { x, y, w: BOX_W, h: BOX_H }) });
      continue;
    }
    const name = v.group!;
    if (doneGroups.has(name)) {
      continue;
    }
    doneGroups.add(name);
    const members = vendors.filter((m) => m.group === name);
    const rate = sum(members.map((m) => m.rate));
    const mt = sum(members.map((m) => m.mt));
    const dlr = sum(members.map((m) => m.dlr));
    const counts = countsText(mt, dlr);
    const id = vendorGroupBoxId(name);
    const groupFacts: [string, string][] = [
      ...members.map((m) => [m.name, `${rateText(m.rate)}${m.bound ? "" : " · unbound"}`] as [string, string]),
      ...countFacts(mt, dlr, win),
    ];
    //the frame, open or closed, is as bad as its worst member
    const state = worst(members.map(vendorState));
    if (vendorGroupOpen(view, name)) {
      anyVendorFrame = true;
      const bound = members.filter((m) => m.bound).length;
      const frame = add({
        id,
        kind: "vendorGroup",
        tier: "vendors",
        lines: [
          `▾ ${name} · ${members.length} vendors · ${rateText(rate)}${counts ? ` · ${counts}` : ""}`,
          `${bound} of ${members.length} bound`,
        ],
        state,
        actions: ["toggle"],
        quick: ["toggle"],
        facts: groupFacts,
        ref: name,
        frame: true,
        rate,
        mt,
        dlr,
      });
      const placed = members.map((m) => vendorBox(m, id));
      const width = placed.length * BOX_W + (placed.length - 1) * BOX_GAP + GROUP_PAD * 2;
      vendorItems.push({
        width,
        place: (x, y) => {
          frame.rect = { x, y: y - GROUP_HEAD, w: width, h: GROUP_HEAD + BOX_H + GROUP_PAD };
          placed.forEach((b, i) => (b.rect = { x: x + GROUP_PAD + i * (BOX_W + BOX_GAP), y, w: BOX_W, h: BOX_H }));
        },
      });
      continue;
    }
    const box = add({
      id,
      kind: "vendorGroup",
      tier: "vendors",
      lines: counts
        ? [`▸ ${name} · ${members.length}`, `${rateText(rate)} · ${counts}`]
        : [`▸ ${name}`, `${members.length} vendors · ${rateText(rate)}`],
      state,
      actions: ["toggle"],
      quick: ["toggle"],
      facts: groupFacts,
      ref: name,
      rate,
      mt,
      dlr,
    });
    vendorItems.push({ width: BOX_W, place: (x, y) => (box.rect = { x, y, w: BOX_W, h: BOX_H }) });
    //collapsed, the node's edge lands on the one box (its top centre: the box's only neighbour above)
    for (const node of new Set(members.map((m) => m.node))) {
      const on = members.filter((m) => m.node === node && (m.routed || m.bound || (m.rate ?? 0) > 0));
      if (on.length && nodeIds.has(node)) {
        const down = on.every((m) => vendorState(m) === "down");
        edge(nodeBoxId(node), id, down ? "refused" : "submit", sum(on.map((m) => m.rate)), {
          mt: sum(on.map((m) => m.mt)),
          dlr: sum(on.map((m) => m.dlr)),
        });
      }
    }
  }

  //─── place the rows, each centred in the widest ───
  const rows: { id: TierId; label: string; items: Item[]; head: number }[] = [
    { id: "clients", label: `Clients · ${input.clients.length}`, items: clientItems, head: anyOpen ? GROUP_HEAD : 0 },
    { id: "listeners", label: `Listener ports · ${input.listeners.length}`, items: listenerItems, head: 0 },
    { id: "nodes", label: `Gateway · ${input.nodes.length} node${input.nodes.length === 1 ? "" : "s"}`, items: nodeItems, head: 0 },
    { id: "vendors", label: `Vendors · ${input.vendors.length}`, items: vendorItems, head: anyVendorFrame ? GROUP_HEAD : 0 },
  ];
  const rowWidth = (items: Item[]) => items.reduce((w, it) => w + it.width, 0) + Math.max(0, items.length - 1) * BOX_GAP;
  const width = Math.max(MIN_WIDTH, ...rows.map((r) => rowWidth(r.items) + 2 * (PAD_X + BAND_X)));
  const bands: TierBand[] = [];
  const buses: number[] = [];
  let y = 12;
  for (const row of rows) {
    const h = PAD_TOP + row.head + BOX_H + (row.head ? GROUP_PAD : 0) + PAD_BOTTOM;
    bands.push({ id: row.id, label: row.label, rect: { x: BAND_X, y, w: width - 2 * BAND_X, h } });
    let x = (width - rowWidth(row.items)) / 2;
    for (const item of row.items) {
      item.place(x, y + PAD_TOP + row.head);
      x += item.width + BOX_GAP;
    }
    y += h;
    buses.push(y + TIER_GAP / 2);
    y += TIER_GAP;
  }
  const height = y - TIER_GAP + 12;

  return { boxes, edges: routeEdges(boxes, pending, buses, win), bands, width, height, countsLabel: win, countsNote: input.countsNote ?? null };
}

const TIER_INDEX: Record<TierId, number> = { clients: 0, listeners: 1, nodes: 2, vendors: 3 };

/** What an edge's rate is, in its tooltip. */
const EDGE_RATE: Record<EdgeKind, string> = { submit: "Submits/s", receipt: "Receipts/s", refused: "Refused/s", persist: "Rows written/s" };

/**
 * Points for every edge. Each box hands out slots along its bottom (to the tier below) and its top
 * (to the tier above), one per neighbour, ordered by the neighbour's x so two edges leaving one box
 * never cross each other on the way out. A receipt takes its submit's slot, {@link RECEIPT_OFFSET}
 * to the right, and runs along the bus a few pixels above it; any other edge running up (a port's
 * refusals back to its clients) the same distance to the left, a few pixels below it. A persist
 * edge joins two boxes of one row side by side: one straight segment between them.
 */
function routeEdges(boxes: readonly MapBox[], pending: readonly Pending[], buses: readonly number[], win: string): MapEdge[] {
  const byId = new Map(boxes.map((b) => [b.id, b] as const));
  const centre = (b: MapBox) => b.rect.x + b.rect.w / 2;
  const name = (b: MapBox) => b.lines[0].replace(/^[▸▾] /, "").split(" · ")[0];
  const finish = (p: Pending, points: [number, number][], from: MapBox, to: MapBox): MapEdge => ({
    id: p.id,
    from: p.from,
    to: p.to,
    kind: p.kind,
    rate: p.rate,
    width: edgeWidth(p.rate),
    points,
    mt: p.mt,
    dlr: p.dlr,
    title: `${name(from)} → ${name(to)}`,
    facts: [[EDGE_RATE[p.kind], rateText(p.rate)], ...countFacts(p.mt, p.dlr, win), ...(p.facts ?? [])],
    ...(p.label ? { label: p.label } : {}),
    ...(p.state ? { state: p.state } : {}),
  });
  const across = pending
    .filter((p) => p.kind === "persist")
    .flatMap((p) => {
      const a = byId.get(p.from);
      const b = byId.get(p.to);
      if (!a || !b) {
        return [];
      }
      const y = Math.round(a.rect.y + a.rect.h / 2);
      const points: [number, number][] = a.rect.x < b.rect.x
        ? [[a.rect.x + a.rect.w, y], [b.rect.x, y]]
        : [[a.rect.x, y], [b.rect.x + b.rect.w, y]];
      return [finish(p, points, a, b)];
    });
  //each edge as its upper and lower box: a submit runs upper → lower, a receipt lower → upper
  const ends = pending
    .filter((p) => p.kind !== "persist")
    .map((p) => {
      const a = byId.get(p.from);
      const b = byId.get(p.to);
      if (!a || !b || a.tier === b.tier) {
        return null;
      }
      const [upper, lower] = TIER_INDEX[a.tier] < TIER_INDEX[b.tier] ? [a, b] : [b, a];
      return { p, upper, lower };
    })
    .filter((e): e is NonNullable<typeof e> => e != null);

  //slots per box side, one per neighbour (a submit and its receipt share one)
  const bottom = new Map<string, string[]>();
  const top = new Map<string, string[]>();
  for (const { upper, lower } of ends) {
    const down = bottom.get(upper.id) ?? [];
    if (!down.includes(lower.id)) {
      down.push(lower.id);
    }
    bottom.set(upper.id, down);
    const up = top.get(lower.id) ?? [];
    if (!up.includes(upper.id)) {
      up.push(upper.id);
    }
    top.set(lower.id, up);
  }
  const slotX = (box: MapBox, neighbours: string[], other: string) => {
    const sorted = [...neighbours].sort((a, b) => centre(byId.get(a)!) - centre(byId.get(b)!) || a.localeCompare(b));
    const i = sorted.indexOf(other);
    const left = box.rect.x + 10;
    const right = box.rect.x + box.rect.w - 10 - RECEIPT_OFFSET;
    if (sorted.length === 1) {
      return Math.round(centre(box) - RECEIPT_OFFSET / 2);
    }
    return Math.round(left + ((right - left) * i) / (sorted.length - 1));
  };
  //a target's index in its tier, so the buses into different targets sit a few pixels apart
  const tierOrder = new Map<string, number>();
  for (const tier of Object.keys(TIER_INDEX) as TierId[]) {
    boxes
      .filter((b) => b.tier === tier && !b.frame)
      .sort((a, b) => a.rect.x - b.rect.x)
      .forEach((b, i) => tierOrder.set(b.id, i));
  }

  return [...ends.map(({ p, upper, lower }) => {
    const ux = slotX(upper, bottom.get(upper.id)!, lower.id);
    const lx = slotX(lower, top.get(lower.id)!, upper.id);
    const lane = ((tierOrder.get(lower.id) ?? 0) % 5) - 2;
    const bus = buses[TIER_INDEX[upper.tier]] + lane * 3;
    const ub = upper.rect.y + upper.rect.h;
    const lt = lower.rect.y;
    const up = p.from === lower.id;
    const points: [number, number][] = p.kind === "receipt"
      ? [[lx + RECEIPT_OFFSET, lt], [lx + RECEIPT_OFFSET, bus - 5], [ux + RECEIPT_OFFSET, bus - 5], [ux + RECEIPT_OFFSET, ub]]
      : up
        ? [[lx - RECEIPT_OFFSET, lt], [lx - RECEIPT_OFFSET, bus + 5], [ux - RECEIPT_OFFSET, bus + 5], [ux - RECEIPT_OFFSET, ub]]
        : [[ux, ub], [ux, bus], [lx, bus], [lx, lt]];
    const from = p.from === upper.id ? upper : lower;
    const to = from === upper ? lower : upper;
    return finish(p, points, from, to);
  }), ...across];
}

/** `41k`, `1.2M`. */
function compact(n: number): string {
  if (n >= 1_000_000) {
    return `${(n / 1_000_000).toFixed(1)}M`;
  }
  return n >= 1000 ? `${Math.round(n / 1000)}k` : String(n);
}

/** Route groups drawn as a group: two or more of the map's vendors name them. */
export function vendorGroupCount(vendors: readonly VendorIn[]): number {
  const sizes = new Map<string, number>();
  for (const v of vendors) {
    if (v.group) {
      sizes.set(v.group, (sizes.get(v.group) ?? 0) + 1);
    }
  }
  return [...sizes.values()].filter((n) => n > 1).length;
}

/**
 * The map card's title row, and the canvas's accessible name after "Connectivity map: ":
 * `1,007/s · 1 clients · 2 ports · 1 node · 2 vendors`, with ` · N groups` when any. The rate is the
 * listeners' summed; the counts are clients (client addresses when split by IP), listener ports,
 * alive nodes and enabled vendors -- what the map draws.
 */
export function totalsText(input: MapInput, byIp = false): string {
  const alive = input.nodes.filter((n) => n.alive).length;
  const groups = vendorGroupCount(input.vendors);
  return [
    rateText(sum(input.listeners.map((l) => l.rate))),
    `${input.clients.length} ${byIp ? "client addresses" : "clients"}`,
    `${input.listeners.length} ports`,
    `${alive} ${alive === 1 ? "node" : "nodes"}`,
    `${input.vendors.length} vendors`,
    ...(groups ? [`${groups} ${groups === 1 ? "group" : "groups"}`] : []),
  ].join(" · ");
}

/** An SVG-style path for one edge: `M x,y V ymid H x2 V y2`. */
export function edgePath(points: readonly [number, number][]): string {
  if (!points.length) {
    return "";
  }
  const [[x0, y0], ...rest] = points;
  let d = `M ${x0},${y0}`;
  let [px, py] = [x0, y0];
  for (const [x, y] of rest) {
    d += x === px ? ` V ${y}` : y === py ? ` H ${x}` : ` L ${x},${y}`;
    [px, py] = [x, y];
  }
  return d;
}

/** Total length of a polyline. */
export function polylineLength(points: readonly [number, number][]): number {
  let total = 0;
  for (let i = 1; i < points.length; i++) {
    total += Math.abs(points[i][0] - points[i - 1][0]) + Math.abs(points[i][1] - points[i - 1][1]);
  }
  return total;
}

/** The point `distance` along an orthogonal polyline. */
export function pointAt(points: readonly [number, number][], distance: number): [number, number] {
  let left = distance;
  for (let i = 1; i < points.length; i++) {
    const [ax, ay] = points[i - 1];
    const [bx, by] = points[i];
    const seg = Math.abs(bx - ax) + Math.abs(by - ay);
    if (left <= seg) {
      const t = seg ? left / seg : 0;
      return [ax + (bx - ax) * t, ay + (by - ay) * t];
    }
    left -= seg;
  }
  return points[points.length - 1] ?? [0, 0];
}

/** Whether a segment passes through a rectangle's interior (touching its edge is not crossing). */
export function segmentCrosses(a: [number, number], b: [number, number], r: Rect): boolean {
  const [x1, x2] = [Math.min(a[0], b[0]), Math.max(a[0], b[0])];
  const [y1, y2] = [Math.min(a[1], b[1]), Math.max(a[1], b[1])];
  return x2 > r.x && x1 < r.x + r.w && y2 > r.y && y1 < r.y + r.h;
}

/**
 * What a focused box lights up: itself, everything upstream of it and everything downstream, and
 * the edges between. An open group lights its members' paths too. Siblings stay dimmed -- that is
 * the point of focusing.
 */
export function focusSet(layout: MapLayout, boxId: string): { boxes: Set<string>; edges: Set<string> } {
  const tierOf = new Map(layout.boxes.map((b) => [b.id, TIER_INDEX[b.tier]] as const));
  const lit = new Set<string>([boxId]);
  const edges = new Set<string>();
  const starts = [boxId, ...layout.boxes.filter((b) => b.parent === boxId).map((b) => b.id)];
  starts.forEach((id) => lit.add(id));
  const parent = layout.boxes.find((b) => b.id === boxId)?.parent;
  if (parent) {
    lit.add(parent);
  }
  for (const direction of [1, -1]) {
    const queue = [...starts];
    const seen = new Set(queue);
    while (queue.length) {
      const id = queue.shift()!;
      for (const e of layout.edges) {
        if (e.from !== id && e.to !== id) {
          continue;
        }
        const other = e.from === id ? e.to : e.from;
        //only onward: down the tiers on the downstream pass, up them on the upstream one
        if (((tierOf.get(other) ?? 0) - (tierOf.get(id) ?? 0)) * direction <= 0) {
          continue;
        }
        edges.add(e.id);
        lit.add(other);
        if (!seen.has(other)) {
          seen.add(other);
          queue.push(other);
        }
      }
    }
  }
  //an edge across a row (a node's writes) lights with the box it leaves or reaches
  for (const e of layout.edges) {
    if (tierOf.get(e.from) === tierOf.get(e.to) && (starts.includes(e.from) || starts.includes(e.to))) {
      edges.add(e.id);
      lit.add(e.from);
      lit.add(e.to);
    }
  }
  return { boxes: lit, edges };
}

/** What a search found: the box to focus and the view that makes it visible. */
export interface SearchHit {
  boxId: string;
  view: MapView;
}

/**
 * Find an account, login, IP, listener or vendor and open whatever hides it: the port group (on the
 * page that holds it), every port when its port is collapsed, its vendor group. Clients are tried
 * first and the busiest match wins; then listeners, then vendors. Case-insensitive substring.
 */
export function searchMap(input: MapInput, view: MapView, query: string): SearchHit | null {
  const q = query.trim().toLowerCase();
  if (!q) {
    return null;
  }
  const has = (s: string | null | undefined) => !!s && s.toLowerCase().includes(q);
  const exact = (s: string | null | undefined) => !!s && s.toLowerCase() === q;
  const clients = input.clients
    .filter((c) => has(c.account) || has(c.ip) || c.hosts.some(has) || c.logins.some(has))
    .sort((a, b) => Number(exact(b.account)) - Number(exact(a.account)) || (b.rate ?? -1) - (a.rate ?? -1));
  if (clients.length) {
    const c = clients[0];
    const { hidden } = visiblePorts(input.listeners, view.allPorts);
    const inOther = hidden.some((l) => l.id === c.listener);
    //the hidden port's clients open in place when every port is shown, so show every port
    const groupKey = c.listener;
    const next: MapView = { ...view, allPorts: view.allPorts || inOther, expanded: new Set([...view.expanded, groupKey]) };
    const sorted = sortClients(input.clients.filter((x) => x.listener === groupKey), view.sorts[groupKey] ?? "rate");
    const at = sorted.findIndex((x) => x.key === c.key);
    next.pages = { ...view.pages, [groupKey]: Math.floor(Math.max(0, at) / PAGE_SIZE) };
    return { boxId: clientBoxId(groupKey, c.key), view: next };
  }
  const listener = input.listeners.find((l) => has(l.name) || exact(l.port));
  if (listener) {
    const { hidden } = visiblePorts(input.listeners, view.allPorts);
    return {
      boxId: listenerBoxId(listener.id),
      view: hidden.some((l) => l.id === listener.id) ? { ...view, allPorts: true } : view,
    };
  }
  const vendor = input.vendors.find((v) => has(v.name)) ?? input.vendors.find((v) => has(v.group));
  if (vendor) {
    return {
      boxId: vendorBoxId(vendor.id),
      view: vendor.group && !vendorGroupOpen(view, vendor.group)
        ? { ...view, openVendorGroups: { ...view.openVendorGroups, [vendor.group]: true } }
        : view,
    };
  }
  return null;
}

/**
 * The edge under a content-space point, for its tooltip: the nearest whose path passes within
 * `tolerance`, among those `keep` admits (the flow filter's). Edges are a few segments each and a
 * map holds at most a few hundred, so a scan is cheap enough for a pointer move.
 */
export function edgeAt(
  edges: readonly MapEdge[],
  x: number,
  y: number,
  tolerance = 5,
  keep: (e: MapEdge) => boolean = () => true
): MapEdge | null {
  let best: MapEdge | null = null;
  let bestD = Infinity;
  for (const e of edges) {
    if (!keep(e)) {
      continue;
    }
    for (let i = 1; i < e.points.length; i++) {
      const d = segmentDistance(e.points[i - 1], e.points[i], x, y);
      if (d <= Math.max(tolerance, e.width / 2) && d < bestD) {
        best = e;
        bestD = d;
      }
    }
  }
  return best;
}

function segmentDistance(a: readonly [number, number], b: readonly [number, number], x: number, y: number): number {
  const dx = b[0] - a[0];
  const dy = b[1] - a[1];
  const len2 = dx * dx + dy * dy;
  const t = len2 ? Math.max(0, Math.min(1, ((x - a[0]) * dx + (y - a[1]) * dy) / len2)) : 0;
  return Math.hypot(x - (a[0] + t * dx), y - (a[1] + t * dy));
}

/** Hit-testing: a uniform grid over the content, each cell listing the boxes that touch it. */
export interface HitIndex {
  cell: number;
  cells: Map<string, number[]>;
  boxes: readonly MapBox[];
}

export function hitIndex(boxes: readonly MapBox[], cell = 160): HitIndex {
  const cells = new Map<string, number[]>();
  boxes.forEach((b, i) => {
    for (let cx = Math.floor(b.rect.x / cell); cx <= Math.floor((b.rect.x + b.rect.w) / cell); cx++) {
      for (let cy = Math.floor(b.rect.y / cell); cy <= Math.floor((b.rect.y + b.rect.h) / cell); cy++) {
        const k = `${cx},${cy}`;
        const list = cells.get(k);
        if (list) {
          list.push(i);
        } else {
          cells.set(k, [i]);
        }
      }
    }
  });
  return { cell, cells, boxes };
}

/** The box under a content-space point; a group's member before the group's frame. */
export function hitTest(index: HitIndex, x: number, y: number): MapBox | null {
  const list = index.cells.get(`${Math.floor(x / index.cell)},${Math.floor(y / index.cell)}`) ?? [];
  let found: MapBox | null = null;
  for (const i of list) {
    const b = index.boxes[i];
    const r = b.rect;
    if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h && (!found || (found.frame && !b.frame))) {
      found = b;
    }
  }
  return found;
}
