import { strict as assert } from "node:assert";
import { test } from "node:test";
import type { GqlCall, GqlOutcome } from "./gateway-graphql-core.ts";
import { COMPONENT_RESTART, HEALTH_API } from "./gateway-queries.ts";
import { RESTART_UNSUPPORTED } from "./gateway-restart.ts";
import { RESTART_TIMEOUT_MS, runRestart, type RestartExecutor } from "./restart-route.ts";

const ADMIN = { name: "admin@remotiq.au", role: "admin" };
const OPERATOR = { name: "ops@remotiq.au", role: "operator" };

/** A gateway that answers health with `api` and the mutation with `answer`, recording each call. */
function gateway(api: Record<string, boolean> | null, answer: GqlOutcome<unknown> = { ok: true, data: { component: "persist", ok: true, tookMs: 120, before: {}, after: {} } }) {
  const calls: GqlCall[] = [];
  const exec: RestartExecutor = async <T,>(call: GqlCall) => {
    calls.push(call);
    if (call.query === HEALTH_API) {
      return { ok: true, data: { api } } as GqlOutcome<T>;
    }
    return answer as GqlOutcome<T>;
  };
  return { exec, calls };
}

const CAPABLE = { component_restart: true, graphql_ops: true };

test("a non-admin operator gets 404, the house rule for admin-only routes, before anything reaches the gateway", async () => {
  const g = gateway(CAPABLE);
  const out = await runRestart(g.exec, OPERATOR, { component: "persist" });
  assert.equal(out.status, 404);
  assert.equal("error" in out.body ? out.body.error : "", "Not found");
  assert.equal(out.audit, undefined);
  assert.equal(g.calls.length, 0);
});

test("an unknown component is 400 and never reaches the gateway", async () => {
  const g = gateway(CAPABLE);
  const out = await runRestart(g.exec, ADMIN, { component: "listener" });
  assert.equal(out.status, 400);
  assert.match("error" in out.body ? out.body.error : "", /Unknown part/);
  assert.equal(g.calls.length, 0);
});

test("a vendor part without its target is 400", async () => {
  const g = gateway(CAPABLE);
  for (const component of ["vendor", "vendor-feed"]) {
    const out = await runRestart(g.exec, ADMIN, { component });
    assert.equal(out.status, 400, component);
  }
  assert.equal((await runRestart(g.exec, ADMIN, null)).status, 400, "no body");
  assert.equal(g.calls.length, 0);
});

test("a gateway without component_restart is 409, and the mutation is not sent", async () => {
  for (const api of [null, {}, { component_restart: false }]) {
    const g = gateway(api);
    const out = await runRestart(g.exec, ADMIN, { component: "persist" });
    assert.equal(out.status, 409);
    assert.equal("error" in out.body ? out.body.error : "", RESTART_UNSUPPORTED);
    assert.deepEqual(g.calls.map((c) => c.query), [HEALTH_API]);
    assert.equal(out.audit, undefined);
  }
});

test("a health read that fails is passed on as it failed", async () => {
  const exec: RestartExecutor = async <T,>() => ({ ok: false, status: 502, code: "UNREACHABLE", error: "Could not reach the gateway." }) as GqlOutcome<T>;
  const out = await runRestart(exec, ADMIN, { component: "db" });
  assert.equal(out.status, 502);
});

test("the restart is sent with the admin token, the operator as by, refusals passed through", async () => {
  const g = gateway(CAPABLE);
  const out = await runRestart(g.exec, ADMIN, { component: "db", hard: true, by: "someone-else" });
  assert.equal(out.status, 200);
  const sent = g.calls[1];
  assert.equal(sent.query, COMPONENT_RESTART);
  assert.equal(sent.auth, "admin");
  assert.equal(sent.passErrors, true);
  assert.equal(sent.timeoutMs, RESTART_TIMEOUT_MS);
  assert.deepEqual(sent.variables, { component: "db", target: null, hard: true, by: "admin@remotiq.au" });
});

test("a run is audited as component action:restart with what it did", async () => {
  const g = gateway(CAPABLE, { ok: true, data: { component: "vendor", target: "smppclient.optus", ok: true, tookMs: 2100, detail: "Rebound." } });
  const out = await runRestart(g.exec, ADMIN, { component: "vendor", target: "smppclient.optus" });
  assert.equal(out.status, 200);
  assert.equal("data" in out.body ? out.body.data.tookMs : null, 2100);
  assert.deepEqual(out.audit, {
    domain: "component",
    name: "vendor smppclient.optus",
    action: "action:restart",
    after: { component: "vendor", target: "smppclient.optus", hard: false, ok: true, tookMs: 2100, detail: "Rebound." },
  });
});

test("the gateway's refusal comes back at its status with its sentence, unaudited", async () => {
  const g = gateway(CAPABLE, { ok: false, status: 409, code: "CONFLICT", error: "A restart of persist is already running; try again when it has finished." });
  const out = await runRestart(g.exec, ADMIN, { component: "persist" });
  assert.equal(out.status, 409);
  assert.deepEqual(out.body, { error: "A restart of persist is already running; try again when it has finished.", code: "CONFLICT" });
  assert.equal(out.audit, undefined);
  const nf = gateway(CAPABLE, { ok: false, status: 404, code: "NOT_FOUND", error: "No vendor nope runs on this node." });
  assert.equal((await runRestart(nf.exec, ADMIN, { component: "vendor-feed", target: "nope" })).status, 404);
});
