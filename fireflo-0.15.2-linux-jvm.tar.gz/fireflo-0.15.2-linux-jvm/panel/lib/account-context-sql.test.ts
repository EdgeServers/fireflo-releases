import assert from "node:assert/strict";
import { test } from "node:test";

import {
  SEEN_ACCOUNT_DAYS,
  VENDOR_WINDOW_DAYS,
  VENDORS_HOT_RECORDS_SQL,
  seenAccountsSql,
  vendorsFromHourlySql,
} from "./account-context-sql.ts";

//the routine reads must name no call record table and no archive view
const CDR = /\bcdr_(submit|final|interim|event|rejected)\b|_all\b/;

test("the vendor card reads the hourly summary, never the call records", () => {
  for (const attempts of [true, false]) {
    const sql = vendorsFromHourlySql(attempts);
    assert.doesNotMatch(sql, CDR);
    assert.match(sql, /FROM usage_hourly/);
    assert.match(sql, /account_id = \$1/);
    assert.match(sql, /hour >= now\(\) - \(\$2 \|\| ' days'\)::interval/);
    assert.match(sql, /vendor <> ''/, "the refused-count row is not a vendor");
    assert.match(sql, /LIMIT 10/);
  }
  assert.match(vendorsFromHourlySql(true), /sum\(attempts\)/);
  assert.match(vendorsFromHourlySql(false), /sum\(submitted\)/);
});

test("the vendor window is inside usage_hourly's default retention (35 days)", () => {
  assert.ok(VENDOR_WINDOW_DAYS <= 35);
});

test("seen accounts read usage_daily (and usage_hourly's tail), never the call records", () => {
  for (const hourly of [true, false]) {
    const sql = seenAccountsSql(hourly);
    assert.doesNotMatch(sql, CDR);
    assert.match(sql, /FROM usage_daily/);
    assert.match(sql, /day >= \(\(now\(\) AT TIME ZONE \$2\) - \(\$1 \|\| ' days'\)::interval\)::date/, "billing days, on the billing zone's calendar");
    assert.match(sql, /SELECT DISTINCT account_id/);
  }
  assert.match(seenAccountsSql(true), /FROM usage_hourly\s+WHERE hour >= now\(\) - interval '2 days'/);
  assert.doesNotMatch(seenAccountsSql(false), /usage_hourly/);
  assert.equal(SEEN_ACCOUNT_DAYS, 90);
});

test("the records fallback is bounded by a parameter on the indexed column, hot table only", () => {
  assert.match(VENDORS_HOT_RECORDS_SQL, /FROM cdr_submit\b/);
  assert.doesNotMatch(VENDORS_HOT_RECORDS_SQL, /_all\b/);
  assert.match(VENDORS_HOT_RECORDS_SQL, /account_id = \$1/);
  assert.match(VENDORS_HOT_RECORDS_SQL, /submitted_at > \$2/);
});
