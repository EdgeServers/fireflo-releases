/**
 * The home page's failures tile from the gateway's hourly failure summary, with only the minutes past
 * its watermark read from the records.
 *
 * <p>Database-free so the text can be asserted without a connection; `failureBreakdown` in
 * `metrics-queries.ts` runs it.
 *
 * <h2>Why it exists</h2>
 *
 * <p>The tile grouped the window's failed messages by final state, receipt state and error code, and
 * found them with a DISTINCT ON over every message in the window and a receipt lookup per message. On
 * a staging gateway with 1.2 million records in the window that took 27 seconds, past the panel's
 * 10-second statement timeout, every minute -- the tile sat marked "stale: failures". From gateway
 * V1.98.0 `usage_failure_hourly` holds exactly that grouping per UTC hour.
 *
 * <h2>The window</h2>
 *
 * <pre>
 *   hours in [first_hour, seam)          summary   whole hours, plus the partial hour the watermark
 *                                                  sits in, filled up to the watermark
 *   [seam, until)                        records   what the summary has not reached yet
 * </pre>
 *
 * <p><b>The window starts where the summary does, if that is later.</b> A range reaching back before
 * the summary's first row is shown from that row on, and `since` says so ("Since 7 Oct"), rather than
 * reading the gap from the records: those are driven from the receipts, and a month of non-delivered
 * receipts took 31 seconds on .101 (660 000 rows, summary begun 14 days into a 30-day range). The
 * vendor ring does read its gap, because its record read is an index range on the submit time.
 *
 * <p><b>`first_hour` is the UTC hour `since` falls in</b>, not the next one: the tile's "last day" is
 * already approximate (local midnight or 24 hours back, whichever is earlier), and reading the opening
 * part-hour from the records would mean up to an hour of them -- millions of rows at volume, the very
 * read this replaces. So the window starts at the top of that hour, and `since` reports it. It never
 * precedes the summary's first row.
 *
 * <p>The record edges are driven from the non-delivered receipts, as the gateway's rollup is: only a
 * message with one can have a failed outcome. A receipt follows its submit, so `final_at >= seam`
 * keeps every receipt of the messages the edge covers.
 *
 * <p>$1 since, $2 until, $3 the summary's watermark.
 *
 * <p><b>The window is the whole range.</b> It used to be cut to the last day
 * (`FAILURE_WINDOW_SINCE`), because without a summary the only source was the records and a week
 * of them was the scan to avoid. The summary keeps 35 days, so with it the failures follow the
 * dashboard's 24h / 7d / 30d like every other card; the cut stays on the records-only path in
 * `failureBreakdown`.
 *
 * <p>Grouped by account as well as by outcome, for the dashboard's failures-by-account ring: the
 * summary keys on the account already, and the records carry it. The reasons list sums the accounts
 * back together (`byReason` in `metrics-queries.ts`).
 *
 * <p><b>And by vendor and carrier code</b> (0.15.1), for the ring's deeper levels: the vendor of the
 * representative submit the edge already picks, and `vendor_err_code` from the outcome row it
 * already reads -- two more columns on rows already in hand, no further table. The summary keys on
 * neither (`usage_failure_hourly` has no vendor), so its rows answer both as NULL: the ring shows
 * those hours as "vendor not recorded".
 */

import { representativeKeys } from "./cdr-grain.ts";
import { OUTCOME_LATERAL } from "./usage-summary-sql.ts";

/**
 * The shared outcome LATERAL (the one rule for which receipt is a message's outcome) with the
 * carrier's own code beside the gateway's: `o.vendor_err_code`, for the dashboard's failure ring.
 * Derived from {@link OUTCOME_LATERAL} rather than written again, so the rule stays in one place;
 * the same `cdr_final` row it already probes, no further read.
 */
export const FAILURE_OUTCOME_LATERAL = (() => {
  const from = "SELECT f.final_state, f.dlr_state, f.err_code";
  if (!OUTCOME_LATERAL.includes(from)) {
    throw new Error("OUTCOME_LATERAL changed shape: FAILURE_OUTCOME_LATERAL must follow it");
  }
  return OUTCOME_LATERAL.replace(from, `${from}, f.vendor_err_code`);
})();

/**
 * The window's bounds as CTEs `base`, `cut0` and `cut`: shared by the breakdown and by
 * {@link failureWindowStartSql}, so the start the tile shows is the start it read from.
 */
const CUT = `
  base AS (
      SELECT $1::timestamptz AS since, $2::timestamptz AS until
  ),
  cut0 AS (
      SELECT b.since, b.until,
             LEAST(GREATEST($3::timestamptz, b.since), b.until) AS seam,
             --the hour since falls in, and never before the failure summary's own first row (it
             --can begin later than usage_hourly); GREATEST ignores the NULL of an empty summary
             GREATEST(date_trunc('hour', b.since AT TIME ZONE 'UTC') AT TIME ZONE 'UTC',
                      (SELECT min(hour) FROM usage_failure_hourly)) AS first_hour
        FROM base b
  ),
  cut AS (
      SELECT c.*,
             --the top of the hour since falls in, or the summary's first row when that is later
             c.first_hour AS shown_since,
             c.seam AS edge_lo
        FROM cut0 c
  )`;

/** The start of the window the breakdown reads, as `since`. Same binds. */
export function failureWindowStartSql(): string {
  return `WITH ${CUT}
  SELECT shown_since AS since FROM cut`;
}

export function failureBreakdownHourlySql(vendorAttempt: boolean): string {
  return `
  WITH ${CUT},
  bad AS (
      SELECT DISTINCT f.gateway_msg_id
        FROM cdr_final f, cut
       WHERE f.part_no = 1 AND f.final_at >= cut.edge_lo AND f.final_state <> 'DELIVERED'
  ),
  edge_msgs AS (
      SELECT DISTINCT ON (c.gateway_msg_id) c.gateway_msg_id, c.submitted_at, c.account_id, c.vendor
        FROM cdr_submit c JOIN bad USING (gateway_msg_id), cut
       WHERE c.part_no = 1
         AND c.submitted_at >= cut.seam AND c.submitted_at < cut.until
       ORDER BY c.gateway_msg_id, ${representativeKeys("c", vendorAttempt)}
  ),
  edge_outcomes AS (
      SELECT DISTINCT ON (f.gateway_msg_id) f.gateway_msg_id, f.final_state, f.dlr_state, f.err_code, f.vendor_err_code
        FROM cdr_final f JOIN bad USING (gateway_msg_id), cut
       WHERE f.part_no = 1 AND f.final_at >= cut.edge_lo
       --the outcome rule of OUTCOME_LATERAL and the gateway's rollup. Change one, change all
       ORDER BY f.gateway_msg_id, (f.final_state = 'EXPIRED'), f.final_at
  ),
  merged AS (
      SELECT o.final_state, o.dlr_state, o.err_code, m.account_id, m.vendor, o.vendor_err_code,
             COUNT(*) AS messages, MAX(m.submitted_at) AS last_seen
        FROM edge_msgs m JOIN edge_outcomes o USING (gateway_msg_id)
       WHERE o.final_state <> 'DELIVERED'
       GROUP BY 1, 2, 3, 4, 5, 6
      UNION ALL
      SELECT h.final_state, NULLIF(h.dlr_state, -1), NULLIF(h.err_code, ''), h.account_id,
             NULL::text, NULL::text,
             SUM(h.messages), MAX(h.last_seen)
        FROM usage_failure_hourly h, cut
       WHERE h.hour >= cut.first_hour AND h.hour < cut.seam
       GROUP BY 1, 2, 3, 4
  )
  SELECT final_state, dlr_state, err_code, account_id, vendor, vendor_err_code,
         SUM(messages)  AS messages,
         MAX(last_seen) AS last_seen
    FROM merged
   GROUP BY 1, 2, 3, 4, 5, 6
   ORDER BY 7 DESC`;
}

/**
 * One breakdown row as `failureBreakdown` answers it, from either statement's columns: counts as
 * numbers, the summary's and the records' "none" as null, `last_seen` as an ISO instant (the driver
 * hands back a Date for a timestamptz; an ISO string is what survives JSON either way).
 */
export function failureRowOf(r: Record<string, unknown>): {
  finalState: string;
  dlrState: number | null;
  errCode: string | null;
  account: string | null;
  vendor: string | null;
  vendorErrCode: string | null;
  messages: number;
  lastSeen: string;
} {
  const text = (v: unknown) => (typeof v === "string" && v !== "" ? v : null);
  return {
    finalState: String(r.final_state),
    dlrState: r.dlr_state === null || r.dlr_state === undefined ? null : Number(r.dlr_state),
    errCode: text(r.err_code),
    account: text(r.account_id),
    vendor: text(r.vendor),
    vendorErrCode: text(r.vendor_err_code),
    messages: Number(r.messages ?? 0),
    lastSeen: new Date(r.last_seen as string | Date).toISOString(),
  };
}

/**
 * The earliest instant the failure breakdown's RECORDS fallback (no `usage_failure_hourly`, or a
 * stalled one) can read from: `FAILURE_WINDOW_SINCE` is the later of `since` and the earlier of
 * today's midnight and `until - 24h`, and today's midnight is never more than a day before now --
 * 25 hours on the day a clock goes back. So no earlier than `min(until, now) - 26h` (an hour to
 * spare), nor than `since`.
 *
 * <p>For routing (`cdr-tier.ts`): the range's own start put 7d and 30d on the `_all` views for a
 * day of rows. `now` is taken before the statement runs, and the database's `now()` is later, so
 * the true start is never before this.
 */
export function failureFallbackRecordsFrom(since: Date, until: Date, now: number): Date {
  return new Date(Math.max(since.getTime(), Math.min(until.getTime(), now) - 26 * 3_600_000));
}
