/**
 * Timestamps as the panel's reader should read them: in one named zone, in one format.
 *
 * <p>Every date in this panel used to be rendered with a bare `toLocaleString()` -- thirty-odd call
 * sites, no options, so the format followed the browser's locale and the zone followed the browser's
 * clock. Two operators in two countries looking at the same message saw two different times and
 * nothing on the page said which zone either was in.
 *
 * <p><strong>Every formatter here takes the zone.</strong> The panel's display zone is the platform's
 * billing zone (`smsg.billing.zone`) unless the viewer picked their browser's zone or UTC from the
 * chip in the top bar; `useDisplayZone()` (components/DisplayZoneProvider.tsx) is where a component
 * gets it. A formatter that defaulted to the browser's zone would be the old bug back, one call site
 * at a time, so there is no default.
 *
 * <p><strong>One locale, `en-GB`, on a 24-hour clock.</strong> Not the browser's: the server renders
 * these too, and a server in `en-US` and a browser in `en-AU` produce different strings for the same
 * instant -- a hydration mismatch on every row. `en-GB` spells the month (no `08/09` ambiguity) and
 * puts the day first, which reads naturally everywhere this panel is used.
 *
 * <p>Day keys (`YYYY-MM-DD`) are a different thing from instants: a billing day is a name, cut by
 * the database in the billing zone, and {@link formatDay} labels it without converting it -- a day
 * key converted to an instant and back in another zone is the classic "every bar is a day early".
 *
 * <p>Database-free and not a client module, so a server route and a client component can both import it.
 */

const LOCALE = "en-GB";

/** The display zone the viewer picked: the platform's billing zone, the browser's own, or UTC. */
export type ZoneMode = "platform" | "browser" | "utc";

/** The cookie the display zone mode is remembered in, so the server renders the same zone. */
export const ZONE_COOKIE = "fireflo-tz";

/** The localStorage key holding the same choice: the cookie can be cleared without losing it. */
export const ZONE_STORAGE_KEY = "fireflo-tz";

type At = string | number | Date | null | undefined;

// ---- formatters ---------------------------------------------------------------------------------

const formatters = new Map<string, Intl.DateTimeFormat>();

/** One cached `Intl.DateTimeFormat` per zone and option set; an unknown zone falls back to UTC. */
function formatter(zone: string, options: Intl.DateTimeFormatOptions): Intl.DateTimeFormat {
  const key = `${zone}|${JSON.stringify(options)}`;
  let f = formatters.get(key);
  if (!f) {
    try {
      f = new Intl.DateTimeFormat(LOCALE, { ...options, timeZone: zone });
    } catch {
      //a zone this runtime does not know: UTC, which is at least a zone the page can name
      f = new Intl.DateTimeFormat(LOCALE, { ...options, timeZone: "UTC" });
    }
    formatters.set(key, f);
  }
  return f;
}

const DAY_MONTH_YEAR: Intl.DateTimeFormatOptions = { day: "numeric", month: "short", year: "numeric" };
const DAY_MONTH: Intl.DateTimeFormatOptions = { day: "numeric", month: "short" };
const HMS: Intl.DateTimeFormatOptions = { hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" };
const HM: Intl.DateTimeFormatOptions = { hour: "2-digit", minute: "2-digit", hourCycle: "h23" };

/**
 * The one format the tables use: `31 Oct 2026 15:11:02`.
 *
 * <p>Seconds always: two messages sent in the same minute is the ordinary case for this traffic, and
 * a column that shows them as identical cannot establish an order. The zone is not repeated on every
 * row; the column header names it once ("Submitted (IST)", see {@link zoneShortName}).
 *
 * @param value an ISO string from the API, epoch milliseconds, or a Date
 * @param zone  the IANA zone to render in, normally `useDisplayZone().zone`
 * @return the stored text unchanged when it is not a date, rather than the string "Invalid Date"
 */
export function formatTimestamp(value: At, zone: string): string {
  const at = parse(value);
  //showing what is actually stored is more use to whoever has to explain it than a formatter's
  //complaint about it
  return at === null ? asText(value) : `${formatter(zone, DAY_MONTH_YEAR).format(at)} ${formatter(zone, HMS).format(at)}`;
}

/**
 * Just the date, `31 Oct 2026`, for a column that is about a day rather than a moment.
 *
 * <p>Use sparingly. Most fields that look like dates are timestamps, and dropping the time from one
 * of those loses the ordering within a day -- which is the only ordering anybody asks a support
 * question about.
 */
export function formatDate(value: At, zone: string): string {
  const at = parse(value);
  return at === null ? asText(value) : formatter(zone, DAY_MONTH_YEAR).format(at);
}

/** `31 Oct`: an instant's day and month in the zone, for a short caption or a tick. */
export function formatDayMonth(value: At, zone: string): string {
  const at = parse(value);
  return at === null ? asText(value) : formatter(zone, DAY_MONTH).format(at);
}

/**
 * The clock time, for something that just happened -- **unless it did not**.
 *
 * <p>Live pages read better with a bare `14:32:07`: a health snapshot, a metrics read, a "saved at"
 * confirmation. All of those are always today, so the date would be noise on every render.
 *
 * <p><strong>The fallback is not decoration.</strong> The same shape is used for things that are only
 * usually recent -- a broker queue entry's enqueue time is the obvious one, and the whole reason that
 * table exists is the case where a message has been sitting there. Rendering yesterday's backlog as
 * `14:32:07` states the one thing the reader is trying to find out, incorrectly. So anything not on
 * today's date *in the zone shown* falls back to the full timestamp and is visibly wider.
 */
export function formatClockTime(value: At, zone: string, now: At = new Date()): string {
  const at = parse(value);
  if (at === null) {
    return asText(value);
  }
  const today = parse(now) ?? new Date();
  return dayKeyIn(at, zone) === dayKeyIn(today, zone) ? formatter(zone, HMS).format(at) : formatTimestamp(at, zone);
}

/**
 * A bare 24-hour clock, `15:11`, `15:11:02` or `15:11:02.441`, with no date whatever day it is.
 *
 * <p>For things that are by construction recent -- a live chart's axis, a watch log line, a "read
 * at" stamp. When the date might matter, {@link formatClockTime} is the one to use.
 */
export function formatClock(value: At, zone: string, o: { seconds?: boolean; millis?: boolean } = {}): string {
  const at = parse(value);
  if (at === null) {
    return asText(value);
  }
  const seconds = o.seconds ?? true;
  const clock = formatter(zone, seconds || o.millis ? HMS : HM).format(at);
  //every zone in use is offset by whole minutes, so the milliseconds are the instant's own
  return o.millis ? `${clock}.${String(at.getUTCMilliseconds()).padStart(3, "0")}` : clock;
}

/**
 * A moment, short: `15:11` when it falls on the same day as `now` in the zone, otherwise
 * `30 Oct 15:11`. The full one belongs in a tooltip.
 */
export function formatMoment(value: At, zone: string, now: At = new Date()): string {
  const at = parse(value);
  if (at === null) {
    return asText(value);
  }
  const ref = parse(now) ?? new Date();
  const clock = formatter(zone, HM).format(at);
  return dayKeyIn(at, zone) === dayKeyIn(ref, zone) ? clock : `${formatter(zone, DAY_MONTH).format(at)} ${clock}`;
}

/**
 * An hour bucket's label on an axis: the bucket's start in the zone, `15:00`, or `15:30` in a zone
 * half an hour off UTC.
 *
 * <p>The buckets themselves stay on UTC hours -- `usage_hourly` is a UTC-hour rollup and cannot be
 * re-cut -- so in India the bars start at :30. That is the truth about the data, and the tooltip
 * names the span ({@link formatHourSpan}) so nobody has to work it out.
 */
export function formatHour(value: At, zone: string): string {
  const at = parse(value);
  return at === null ? asText(value) : formatter(zone, HM).format(at);
}

/**
 * A bucket's span for a tooltip: `31 Oct 15:30–16:30 IST`.
 *
 * @param minutes the bucket's width: 60 for an hour, 5 for the hour range's five-minute bars
 */
export function formatHourSpan(value: At, zone: string, minutes = 60): string {
  const at = parse(value);
  if (at === null) {
    return asText(value);
  }
  const end = new Date(at.getTime() + minutes * 60_000);
  const hm = formatter(zone, HM);
  return `${formatter(zone, DAY_MONTH).format(at)} ${hm.format(at)}–${hm.format(end)} ${zoneShortName(zone, at)}`;
}

/**
 * A day key's label, `31 Oct` (or `31 Oct 2026` with `year`), **without any zone conversion**.
 *
 * <p>A billing day is cut by the database in the billing zone and arrives as `YYYY-MM-DD`. Turning
 * it into an instant and formatting that in another zone shows the day before for anyone west of
 * the cut, so the key is read as a calendar date and nothing else.
 *
 * @return the text unchanged when it is not a day key
 */
export function formatDay(dayKey: string | null | undefined, o: { year?: boolean; weekday?: boolean } = {}): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dayKey ?? "");
  if (!m) {
    return asText(dayKey);
  }
  const at = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])));
  return formatter("UTC", {
    ...(o.weekday ? { weekday: "short" as const } : {}),
    ...(o.year ? DAY_MONTH_YEAR : DAY_MONTH),
  }).format(at);
}

/** `October 2026`: a calendar month by its number, again with no zone in it. */
export function formatMonth(year: number, month: number): string {
  return formatter("UTC", { month: "long", year: "numeric" }).format(new Date(Date.UTC(year, month - 1, 1)));
}

/**
 * A chart tooltip's heading when the chart gave it nothing better: a day key as a day, an instant
 * (ISO or epoch milliseconds) as `31 Oct 15:11 IST`, anything else as it is.
 */
export function formatChartLabel(label: unknown, zone: string): string {
  if (label == null || label === "") {
    return "";
  }
  if (typeof label === "string" && /^\d{4}-\d{2}-\d{2}$/.test(label)) {
    return formatDay(label, { year: true });
  }
  const instant =
    typeof label === "number" ? (label > 1e11 ? new Date(label) : null)
    : typeof label === "string" && /^\d{4}-\d{2}-\d{2}T/.test(label) ? parse(label)
    : label instanceof Date ? label
    : null;
  if (instant === null || Number.isNaN(instant.getTime())) {
    return String(label);
  }
  return `${formatter(zone, DAY_MONTH).format(instant)} ${formatter(zone, HM).format(instant)} ${zoneShortName(zone, instant)}`;
}

// ---- zones --------------------------------------------------------------------------------------

/** Whether this is UTC under one of its many names. */
export function isUtcZone(zone: string | null | undefined): boolean {
  return /^(?:Etc\/)?(?:UTC|UCT|GMT|GMT0|GMT[+-]0|Universal|Zulu|Greenwich)$/i.test(zone ?? "");
}

/** Whether this runtime knows the zone. */
export function isValidZone(zone: string | null | undefined): boolean {
  if (!zone) {
    return false;
  }
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: zone });
    return true;
  } catch {
    return false;
  }
}

/**
 * The zone's short name at an instant: `UTC`, `IST`, `EDT` or `EST`, `AEDT`, `BST` -- and the offset,
 * `GMT+4`, for a zone with no abbreviation in common use.
 *
 * <p>Asked of `Intl` in a few English locales in turn, because each knows only its own region's
 * abbreviations: `en-US` says `GMT+5:30` for India, `en-IN` says `IST`. India is pinned regardless
 * of ICU, since it is the zone this panel is most often run in and the one header that most needs
 * to read right.
 */
export function zoneShortName(zone: string, at: At = new Date()): string {
  if (isUtcZone(zone)) {
    return "UTC";
  }
  if (zone === "Asia/Kolkata" || zone === "Asia/Calcutta") {
    return "IST";
  }
  const when = parse(at) ?? new Date();
  const key = `${zone}|${Math.floor(when.getTime() / 3_600_000)}`;
  const cached = shortNames.get(key);
  if (cached) {
    return cached;
  }
  let fallback: string | null = null;
  let found: string | null = null;
  for (const locale of ["en-US", "en-GB", "en-AU", "en-IN"]) {
    let name: string | undefined;
    try {
      name = new Intl.DateTimeFormat(locale, { timeZone: zone, timeZoneName: "short" })
        .formatToParts(when)
        .find((p) => p.type === "timeZoneName")?.value;
    } catch {
      return zone;
    }
    if (!name) {
      continue;
    }
    fallback ??= name;
    if (!/^(?:GMT|UTC)[+-−]/.test(name)) {
      found = name;
      break;
    }
  }
  const name = found ?? fallback ?? zone;
  shortNames.set(key, name);
  return name;
}

const shortNames = new Map<string, string>();

/** The chip's words: `IST · Asia/Kolkata`, or plain `UTC`. */
export function zoneLabel(zone: string, at: At = new Date()): string {
  return isUtcZone(zone) ? "UTC" : `${zoneShortName(zone, at)} · ${zone}`;
}

/**
 * The zone the browser is rendering in, e.g. `Asia/Kolkata`.
 *
 * @return null when the environment will not say
 */
export function browserTimeZone(): string | null {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || null;
  } catch {
    return null;
  }
}

/** The zone a mode means, given the billing zone and (for `browser`) the browser's zone. */
export function resolveDisplayZone(mode: ZoneMode, billingZone: string, browserZone: string | null): string {
  if (mode === "utc") {
    return "UTC";
  }
  if (mode === "browser" && browserZone && isValidZone(browserZone)) {
    return browserZone;
  }
  return isValidZone(billingZone) ? billingZone : "UTC";
}

/**
 * The cookie's value: `platform`, `utc`, or `browser:<zone>`.
 *
 * <p>The browser's zone rides along with `browser` so the server can render the page in it: without
 * it the server would render one zone and the browser repaint every time in another a moment later.
 * The browser rewrites it on each visit, so a laptop that has travelled corrects itself on the next
 * page.
 */
export function zoneCookieValue(mode: ZoneMode, browserZone: string | null): string {
  return mode === "browser" && browserZone ? `browser:${browserZone}` : mode;
}

/** The cookie read back; anything unrecognised is the default, `platform`. */
export function parseZoneCookie(raw: string | null | undefined): { mode: ZoneMode; browserZone: string | null } {
  const value = decodeSafe(raw ?? "");
  if (value === "utc" || value === "platform") {
    return { mode: value, browserZone: null };
  }
  if (value === "browser" || value.startsWith("browser:")) {
    const zone = value.slice("browser:".length);
    return { mode: "browser", browserZone: value !== "browser" && isValidZone(zone) ? zone : null };
  }
  return { mode: "platform", browserZone: null };
}

function decodeSafe(s: string): string {
  try {
    return decodeURIComponent(s);
  } catch {
    return s;
  }
}

// ---- day keys and wall times -------------------------------------------------------------------

interface Wall {
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  second: number;
}

const WALL: Intl.DateTimeFormatOptions = {
  year: "numeric", month: "2-digit", day: "2-digit",
  hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23",
};

/** The wall clock in the zone at an instant. */
function wallIn(at: Date, zone: string): Wall {
  const parts = formatter(zone, WALL).formatToParts(at);
  const n = (type: string) => Number(parts.find((p) => p.type === type)?.value ?? 0);
  return { year: n("year"), month: n("month"), day: n("day"), hour: n("hour") % 24, minute: n("minute"), second: n("second") };
}

/** The zone's offset from UTC at an instant, in minutes: 330 for India, -240 for New York in summer. */
export function zoneOffsetMinutes(zone: string, at: At = new Date()): number {
  const when = parse(at) ?? new Date();
  const w = wallIn(when, zone);
  const asUtc = Date.UTC(w.year, w.month - 1, w.day, w.hour, w.minute, w.second);
  return Math.round((asUtc - Math.floor(when.getTime() / 1000) * 1000) / 60_000);
}

/** The `YYYY-MM-DD` an instant falls on in the zone. */
export function dayKeyIn(value: At, zone: string): string {
  const at = parse(value);
  if (at === null) {
    return "";
  }
  const w = wallIn(at, zone);
  return `${w.year}-${pad(w.month)}-${pad(w.day)}`;
}

/**
 * A wall time typed in a zone, as the instant it names: `2026-10-31T15:00` in `Asia/Kolkata` is
 * `2026-10-31T09:30:00Z`.
 *
 * <p>For the `datetime-local` inputs, which hand over a wall time with no zone at all. The browser's
 * own `new Date("2026-10-31T15:00")` reads it in the browser's zone, which is the display zone only
 * when the viewer chose "My browser".
 *
 * <p>A wall time that happens twice (the hour a clock goes back) is the first of the two; one that
 * never happens (the hour it skips) is read with the offset from before the change, which lands an
 * hour later on the clock. Both are what a person who typed it would most likely mean.
 *
 * @param wall `YYYY-MM-DD`, `YYYY-MM-DDTHH:MM` or `YYYY-MM-DDTHH:MM:SS(.sss)`, `T` or a space
 * @return null when it is not a wall time
 */
export function wallTimeToInstant(wall: string | null | undefined, zone: string): Date | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,3}))?)?)?$/.exec((wall ?? "").trim());
  if (!m) {
    return null;
  }
  const [y, mo, d, h, mi, s] = [m[1], m[2], m[3], m[4] ?? "0", m[5] ?? "0", m[6] ?? "0"].map(Number);
  const ms = m[7] ? Number(m[7].padEnd(3, "0")) : 0;
  const guess = Date.UTC(y, mo - 1, d, h, mi, s, ms);
  if (Number.isNaN(guess)) {
    return null;
  }
  //the offset at the guess and at the first answer differ only near a daylight change; whichever
  //candidates really show the typed wall time, the earliest wins ("the first of the two")
  const o1 = zoneOffsetMinutes(zone, new Date(guess));
  const c1 = guess - o1 * 60_000;
  const o2 = zoneOffsetMinutes(zone, new Date(c1));
  const c2 = guess - o2 * 60_000;
  const shown = [c1, c2].filter((t) => sameWall(t, zone, guess));
  if (shown.length) {
    return new Date(Math.min(...shown));
  }
  //a time the clock skipped: the offset in force a day earlier, from before the change
  return new Date(guess - zoneOffsetMinutes(zone, new Date(guess - 86_400_000)) * 60_000);
}

function sameWall(t: number, zone: string, wallAsUtc: number): boolean {
  const w = wallIn(new Date(t), zone);
  return Date.UTC(w.year, w.month - 1, w.day, w.hour, w.minute, w.second) === Math.floor(wallAsUtc / 1000) * 1000;
}

/**
 * An instant as the `datetime-local` value showing it in the zone, `2026-10-31T15:00` -- the
 * inverse of {@link wallTimeToInstant}, for prefilling an input.
 */
export function instantToWallTime(value: At, zone: string, o: { seconds?: boolean } = {}): string {
  const at = parse(value);
  if (at === null) {
    return "";
  }
  const w = wallIn(at, zone);
  const base = `${w.year}-${pad(w.month)}-${pad(w.day)}T${pad(w.hour)}:${pad(w.minute)}`;
  return o.seconds ? `${base}:${pad(w.second)}` : base;
}

/**
 * An instant as a spreadsheet cell in the zone, `2026-10-31 15:00:02`: the wall time, no zone in it,
 * which the column's header names. For an export's `_local` columns beside the ISO UTC ones.
 */
export function formatCsvLocal(value: At, zone: string): string {
  return instantToWallTime(value, zone, { seconds: true }).replace("T", " ");
}

/** Midnight at the start of a day key in the zone, as an instant. */
export function dayStartIn(dayKey: string, zone: string): Date | null {
  return /^\d{4}-\d{2}-\d{2}$/.test(dayKey) ? wallTimeToInstant(`${dayKey}T00:00`, zone) : null;
}

/** The day key `n` calendar days after (or, negative, before) a day key. */
export function addDays(dayKey: string, n: number): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dayKey);
  if (!m) {
    return dayKey;
  }
  const at = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]) + n));
  return at.toISOString().slice(0, 10);
}

function pad(n: number): string {
  return String(n).padStart(2, "0");
}

// ---- parsing ------------------------------------------------------------------------------------

/**
 * A `since=`/`until=` query parameter as an instant, **reading a zone-less one as UTC**.
 *
 * <p>The page sends exact ISO instants (`2026-10-31T09:30:00.000Z`), converted from the display
 * zone in the browser. A hand-written link may not: `since=2026-10-31T15:00` names no zone, and
 * `new Date()` on the server would read it in the host's `TZ` -- an answer that changes with where
 * the panel is installed. The server cannot know the reader's zone, so it takes the one zone that
 * is the same everywhere and says so in the API's shape: a bare wall time, or a bare date, is UTC.
 *
 * @return null when it is not a time at all
 */
export function parseInstantParam(raw: string | null | undefined): Date | null {
  const v = (raw ?? "").trim();
  if (!v) {
    return null;
  }
  //a bare date or wall time, with no Z and no offset: UTC by rule
  if (/^\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?)?$/.test(v)) {
    return wallTimeToInstant(v, "UTC");
  }
  return parse(v);
}

/** @return null when there is nothing to format, so each caller decides what to show instead */
function parse(value: At): Date | null {
  if (value == null || value === "") {
    return null;
  }
  const at = value instanceof Date ? value : new Date(value);
  return Number.isNaN(at.getTime()) ? null : at;
}

/** What a value that is not a date renders as. See {@link formatTimestamp}. */
function asText(value: unknown): string {
  return value == null || value === "" ? "" : String(value);
}
