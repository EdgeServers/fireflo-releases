/**
 * The Security page's live watch: one client address on one SMPP listener port, read about once a
 * second. Shapes match the gateway's WatchReport.
 */

import { formatClock } from "./datetime.ts";

/** Kept in step with ClientWatches on the gateway, which clamps anything outside its own bounds. */
export const WATCH_MAX_SECONDS = 1800;
export const WATCH_DURATIONS = [300, 900, 1800] as const;

export type WatchEvent = {
  seq: number;
  at: string;
  session_id: number | null;
  peer: string | null;
  kind: "pdu" | "note";
  direction: "in" | "out" | null;
  command: string | null;
  sequence: number | null;
  status: number | null;
  text: string;
};

export type WatchReport = {
  id: string;
  worker: string;
  ip: string;
  port: number;
  running: boolean;
  started_at: string;
  ends_at: string;
  stopped_at: string | null;
  stopped_because: string | null;
  dropped: number;
  events: WatchEvent[];
  next: number;
  more: boolean;
};

/**
 * Whether this looks like an IPv4 or IPv6 address literal.
 *
 * <p>A first check only, so a typo is caught before a round trip. The gateway parses it properly and
 * never resolves a name, so anything this lets through that is not an address is refused there.
 */
export function isIpLiteral(value: string): boolean {
  const v = value.trim().replace(/^\[(.*)\]$/, "$1");
  const v4 = /^(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$/;
  if (v4.test(v)) {
    return true;
  }
  return v.includes(":") && /^[0-9a-fA-F:.]+$/.test(v) && v.length <= 45;
}

/** One event as a line: time, client, direction, then the PDU or the note. */
export function watchLine(e: WatchEvent, zone: string): string {
  //the display zone, like the rest of the card; the ISO string is UTC and read as a clock it was hours off
  const time = formatClock(e.at, zone, { millis: true });
  const who = e.peer ?? "";
  if (e.kind === "note") {
    return `${time}  ${who}  ${e.text}`.replace(/ {3,}/g, "  ");
  }
  const arrow = e.direction === "in" ? "→" : "←";
  const status = e.status ? ` status=0x${e.status.toString(16).padStart(8, "0")}` : "";
  return `${time}  ${who}  ${arrow} ${e.command} seq=${e.sequence}${status}  ${e.text}`;
}
