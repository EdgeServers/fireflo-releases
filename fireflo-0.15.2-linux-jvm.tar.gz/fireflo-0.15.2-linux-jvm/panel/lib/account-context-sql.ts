/**
 * The SQL behind the account context card's routine reads, database-free so it is tested as text.
 *
 * <p><strong>Owner rule: a routine page load reads summaries, never the call records over a
 * window.</strong> These run every time an account page or a credential form opens; the call
 * records (`cdr_submit` and its `_all` archive view) are for the report pages someone deliberately
 * opens. Incident 2026-10-31: the 90-day forms of both reads below hit the archive on a cold remote
 * disk, ten at a time, and starved the gateway's credit refills (customers saw 0x14).
 */

/**
 * How far back "where this account's traffic went" looks. Inside `usage_hourly`'s retention
 * (`smsg.usage.hourly.retention.days`, 35 by default) so the window is whole on a default install.
 */
export const VENDOR_WINDOW_DAYS = 30;

/** The records fallback's window: inside the hot tables, for a gateway without `usage_hourly`. */
export const VENDOR_HOT_FALLBACK_DAYS = 3;

/** How far back an account counts as "seen" for the rate-scope validator. */
export const SEEN_ACCOUNT_DAYS = 90;

/**
 * Per-vendor message counts for one account from the hourly summary (gateway V1.91.0).
 *
 * <p>`attempts` (V1.97.0) counts each attempt under the vendor it went to, so a retry that landed
 * on a second vendor shows both -- which is what the card asks, and why the revenue page's
 * `part_no = 1` representative is not used. Without that column, `submitted` (the vendor of the
 * representative attempt). Vendor `''` is the refused-count row and is not a vendor.
 *
 * <p>Rides `pk_usage_hourly (account_id, hour, …)`: one account's hours, at most
 * days x 24 x products x vendors x logins rows. The summary is behind live traffic by the rollup
 * tick (about a minute and a half by default); this card does not need the live edge.
 *
 * <p>Parameters: `$1` account, `$2` days.
 */
export function vendorsFromHourlySql(hasAttempts: boolean): string {
  const measure = hasAttempts ? "attempts" : "submitted";
  return `SELECT vendor, sum(${measure})::bigint AS messages
       FROM usage_hourly
      WHERE account_id = $1 AND vendor <> ''
        AND hour >= now() - ($2 || ' days')::interval
      GROUP BY vendor
     HAVING sum(${measure}) > 0
      ORDER BY 2 DESC, 1
      LIMIT 10`;
}

/**
 * The fallback for a gateway with no hourly summary (before V1.91.0): the hot `cdr_submit` table
 * only, over {@link VENDOR_HOT_FALLBACK_DAYS}, on the `(account_id, submitted_at)` index. The
 * caller runs it only when that window is inside the hot tables, so it never reaches `_all`.
 *
 * <p>Parameters: `$1` account, `$2` the window's start.
 */
export const VENDORS_HOT_RECORDS_SQL = `SELECT vendor, count(*) AS messages
       FROM cdr_submit
      WHERE account_id = $1 AND vendor IS NOT NULL
        AND submitted_at > $2
      GROUP BY vendor
      ORDER BY count(*) DESC
      LIMIT 10`;

/**
 * Accounts that have sent in the last `$1` days, from the summaries: `usage_daily` for finished
 * billing days (`idx_usage_daily_day`) and, when `withHourly`, `usage_hourly` for the last two days
 * the nightly rollup has not reached yet (`idx_usage_hourly_hour`). Both are a few rows per account
 * per day; neither touches the call records.
 *
 * <p>Parameters: `$1` days, `$2` the billing zone. `usage_daily.day` is a billing day, so "N days
 * ago" is counted on the billing zone's calendar (`now() AT TIME ZONE $2`), not the session's.
 */
export function seenAccountsSql(withHourly: boolean): string {
  const daily = `SELECT account_id FROM usage_daily
          WHERE day >= ((now() AT TIME ZONE $2) - ($1 || ' days')::interval)::date AND account_id <> ''`;
  const hourly = `SELECT account_id FROM usage_hourly
          WHERE hour >= now() - interval '2 days' AND account_id <> ''`;
  return `SELECT DISTINCT account_id FROM (
         ${daily}${withHourly ? `
         UNION ALL
         ${hourly}` : ""}
       ) seen
      ORDER BY 1`;
}
