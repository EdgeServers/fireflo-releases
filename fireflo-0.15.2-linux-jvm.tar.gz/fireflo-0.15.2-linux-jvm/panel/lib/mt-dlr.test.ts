import { strict as assert } from "node:assert";
import { test } from "node:test";

import { countOrDash, mtDlrShort, RECEIPTS_NEED_GATEWAY, receiptsTitle } from "./mt-dlr.ts";

test("the pair groups both counts", () => {
  assert.equal(mtDlrShort(12000, 11980), `${(12000).toLocaleString()} MT · ${(11980).toLocaleString()} DLR`);
  assert.equal(mtDlrShort(0, 0), "0 MT · 0 DLR");
});

test("an older gateway without receipts shows a dash, not zero, with the reason on hover", () => {
  assert.equal(mtDlrShort(5, undefined), "5 MT · — DLR");
  assert.equal(countOrDash(null), "—");
  assert.equal(receiptsTitle(undefined), RECEIPTS_NEED_GATEWAY);
  assert.equal(receiptsTitle(null), RECEIPTS_NEED_GATEWAY);
  assert.equal(receiptsTitle(0), undefined);
});
