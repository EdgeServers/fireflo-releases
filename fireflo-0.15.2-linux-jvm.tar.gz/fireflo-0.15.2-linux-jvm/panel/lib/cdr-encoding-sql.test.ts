import { test } from "node:test";
import assert from "node:assert/strict";
import {
  encodingComplete,
  encodingFields,
  encodingSupportFrom,
  ENCODING_PROBE_SQL,
  NO_ENCODING,
  receiptEncodingSelect,
  submitEncodingSelect,
  SUBMIT_ENCODING_COLUMNS,
  type ProbeRow,
} from "./cdr-encoding-sql.ts";

const VIEWS: ProbeRow[] = ["cdr_submit_all", "cdr_final_all", "cdr_interim_all"]
  .map((table_name) => ({ table_name, column_name: null }));

/** What the probe returns on a 1.124.0 database: every column, on the tables and the views. */
function v124(): ProbeRow[] {
  const rows: ProbeRow[] = [...VIEWS];
  for (const t of ["cdr_submit", "cdr_submit_all"]) {
    for (const c of SUBMIT_ENCODING_COLUMNS) rows.push({ table_name: t, column_name: c });
  }
  for (const t of ["cdr_final", "cdr_final_all", "cdr_interim", "cdr_interim_all"]) {
    rows.push({ table_name: t, column_name: "dcs_received" });
  }
  return rows;
}

test("1.123.0: none of the new columns is selected anywhere", () => {
  //the probe finds only the views -- no encoding column exists yet
  const have = encodingSupportFrom(VIEWS);
  assert.equal(submitEncodingSelect(have), "");
  assert.equal(receiptEncodingSelect(have.final, "o"), "");
  assert.equal(receiptEncodingSelect(have.interim), "");
  assert.equal(encodingComplete(have), false);
  assert.equal(submitEncodingSelect(NO_ENCODING), "");
});

test("1.124.0: every column, in a fixed order, and the receipt column on both tables", () => {
  const have = encodingSupportFrom(v124());
  assert.equal(
    submitEncodingSelect(have),
    ", s.esm_class_received, s.chars_received, s.bytes_received, s.payload_received, s.dcs_sent, s.esm_class_sent, s.bytes_sent"
  );
  assert.equal(receiptEncodingSelect(have.final, "f"), ", f.dcs_received");
  assert.equal(receiptEncodingSelect(have.interim), ", dcs_received");
  assert.equal(encodingComplete(have), true);
});

test("a column on the table but not yet on its _all view counts as absent", () => {
  //the views are SELECT * expanded at creation: an archived message is read through them, and
  //naming a column the view lacks is a hard error
  const rows = v124().filter((r) => !(r.table_name === "cdr_submit_all" && r.column_name === "dcs_sent")
    && !(r.table_name === "cdr_final_all" && r.column_name != null));
  const have = encodingSupportFrom(rows);
  assert.equal(have.submit.has("dcs_sent"), false);
  assert.equal(have.submit.has("bytes_sent"), true);
  assert.equal(have.final, false);
  assert.equal(have.interim, true);
});

test("before V1.112.0 there are no views, and the tables alone decide", () => {
  const rows = v124().filter((r) => !r.table_name.endsWith("_all"));
  const have = encodingSupportFrom(rows);
  assert.equal(have.submit.size, SUBMIT_ENCODING_COLUMNS.length);
  assert.equal(have.final && have.interim, true);
});

test("the probe names call record tables only inside literals, so it is never re-routed", () => {
  //metrics-db routes any statement naming cdr_submit outside a string literal through the views
  const outside = ENCODING_PROBE_SQL.split(/('(?:[^']|'')*')/).filter((_, i) => i % 2 === 0).join(" ");
  assert.doesNotMatch(outside, /\bcdr_/);
});

test("absent and null stay different on the row", () => {
  assert.deepEqual(encodingFields({ id: "1" }), {}, "a 1.123.0 row carries none of the keys");
  assert.deepEqual(
    encodingFields({ dcs_sent: "8", bytes_sent: null, payload_received: true, inbound_segments: "2", dcs_received: 0 }),
    { dcsSent: 8, bytesSent: null, payloadReceived: true, inboundSegments: 2, dcsReceived: 0 }
  );
  assert.equal(encodingFields({ payload_received: null }).payloadReceived, null);
  assert.equal(encodingFields({ payload_received: "f" }).payloadReceived, false);
});
