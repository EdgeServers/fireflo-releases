import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";

/*
 * The readers below import `pg` and cannot run under node:test, so their wiring is pinned by their
 * source: every routine read that saturated production on 2026-10-31 is now kept with single
 * flight and routed on the records it really reads. A change that drops either fails here, next to
 * the reason.
 */

const src = (file: string) => readFileSync(new URL(file, import.meta.url), "utf8");

/** The body of `function name(` up to the next top-level declaration. */
function body(text: string, name: string): string {
  const i = text.search(new RegExp(`(async )?function ${name}[<(]`));
  assert.ok(i >= 0, `${name} exists`);
  const rest = text.slice(i + 1);
  const j = rest.search(/\n(export |async function |function |const |\/\*\*)/);
  return j < 0 ? rest : rest.slice(0, j);
}

test("portal home: the two lists are kept 30 s per scope and start at the hot boundary", () => {
  const s = src("./mis-overview.ts");
  assert.match(s, /new FlightCache<Lists>\(\{ ttlMs: LIST_TTL_MS, maxStaleMs: LIST_TTL_MS/);
  assert.match(s, /const LIST_TTL_MS = 30_000;/);
  assert.match(body(s, "listsFor"), /listCache\(\)\.get\(\s*overviewKey\(scope, String\(days\)\)/);
  assert.match(body(s, "listStart"), /cdrHotStart\(since, await cdrBoundary\(\), Date\.now\(\)\)/);
  assert.doesNotMatch(body(s, "overviewFor"), /recentMessages\(|failedMessages\(/, "never called uncached");
  //the aggregate is routed on its raw slivers, not on the range's start
  assert.doesNotMatch(body(s, "aggregateFor"), /cdrQuery/);
  assert.match(body(s, "aggregateFor"), /usageRowsQuery/);
});

test("Billing tab: MT usage kept 60 s per account, routed on the account's own seam", () => {
  const s = src("./mt-usage-queries.ts");
  assert.match(s, /const MT_USAGE_TTL_MS = 60_000;/);
  assert.match(body(s, "mtUsageFor"), /cache\(\)\.get\(\s*`\$\{zone\}\|\$\{accountId\}`/);
  const now = body(s, "mtUsageNow");
  assert.match(now, /mtTailPlan\(/);
  assert.match(now, /\[accountId, zone, plan\.from\],\s+plan\.from\s+\)/, "routed on the tail's start, never null");
  assert.doesNotMatch(now, /,\s+null\s+\)/);
});

test("Accounts: kept 60 s per (range, account) and routed on the raw slivers", () => {
  const s = src("./metrics-queries.ts");
  assert.match(s, /const ACCOUNTS_TTL_MS = 60_000;/);
  assert.match(body(s, "accountUsage"), /accountsCache\(\)\.get\(\s*`\$\{range\}\|\$\{account \?\? ""\}`/);
  const now = body(s, "accountUsageNow");
  assert.match(now, /routedQuery<Record<string, string>>\(\{\s+build: \(slivers\) => accountUsageSql/);
  assert.match(now, /splittable: source === "hourly"/);
});

test("vendors: the summary path is routed on its edges and the refresher never scans the range", () => {
  const s = src("./metrics-queries.ts");
  const v = body(s, "vendorPerformance");
  assert.match(v, /raw: vendorRawSliversSql\(\)/);
  assert.match(v, /if \(!summarised && o\.summaryOnly && range !== "1h"\) \{\s+throw new VendorSummaryUnavailableError/);
  assert.match(src("./overview-refresher.ts"), /vendorPerformance\(range, \{ byAccount: true, summaryOnly: true \}\)/);
});

test("live traffic: shared per key, and the receipts' submits are the hot table's", () => {
  const s = src("./metrics-queries.ts");
  assert.match(body(s, "liveTraffic"), /liveCache\(\)\.get\(`\$\{kind\}\|\$\{key \?\? ""\}`, from/);
  assert.match(s, /const LIVE_TTL_MS = 10_000;/);
  const read = body(s, "liveTrafficRead");
  assert.doesNotMatch(read, /cdrTable\(|CDR_RECEIPT_REACH_MS|cdrEarlier/, "no lookup routed eight days back");
  assert.match(read, /JOIN LATERAL \(\s+SELECT s\.\$\{keyCol\} AS key\s+FROM cdr_submit s/);
});

test("the windowed readers route through usageRowsQuery, never on the window's start", () => {
  const s = src("./metrics-queries.ts");
  for (const name of ["trafficOverTime", "revenueByAccount", "revenueSeries"]) {
    const b = body(s, name);
    assert.match(b, /usageRowsQuery</, name);
    assert.doesNotMatch(b, /recordsFrom|cdrQuery/, name);
  }
  assert.match(body(s, "failureBreakdown"), /failureFallbackRecordsFrom\(since, until, Date\.now\(\)\)/);
});

test("the jump box's message lookup stays on the live days unless the id's own time is archived, and never matches segments there", () => {
  const src = readFileSync(new URL("./cdr-queries.ts", import.meta.url), "utf8");
  const fn = src.slice(src.indexOf("export async function findMessageId"), src.indexOf("/** One row of either receipt table."));
  assert.ok(fn.length > 0, "findMessageId found");
  assert.ok(!fn.includes("cdrLookupById"), "no unbounded lookup through the views");
  assert.match(fn, /cdrRouteSql\(live, new Date\(\), boundary\)/, "the first probe is routed to the live days");
  assert.match(fn, /at === null/, "an id with no time never reaches the archive");
  const archived = fn.slice(fn.indexOf("const archived"));
  assert.ok(!archived.includes("reassembled_parts"), "the archive probe is by gateway_msg_id alone");
});
