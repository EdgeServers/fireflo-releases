/**
 * The SQL behind one account's MT usage, with no database import.
 *
 * <p>Split out so the text can be asserted without a connection — see `mt-usage.test.ts`.
 */

import {
  CDR_EVERYTHING,
  CDR_HOT_FALLBACK_MS,
  CDR_TIER_MARGIN_MS,
  messageRows,
  rollupTailFrom,
  type CdrBoundary,
  type GrainOptions,
} from "./cdr-grain.ts";

export interface MtUsageSqlOptions extends GrainOptions {
  /** Whether `usage_daily.mt_parts` exists — `hasUsageMtParts()`. The gateway's V1.68.0. */
  mtParts: boolean;
  /** Whether `cdr_submit.submit_status` exists — `hasSubmitStatus()`. The gateway's V1.40.0. */
  submitStatus: boolean;
  /**
   * Bound the tail by `$3` as well (`mtTailPlan`): the account's own seam, read beforehand, which
   * is never later than the one the statement computes -- so it removes nothing -- and is a constant
   * the planner can prune partitions with; or, for an account with no line at all, the start of
   * the hot days.
   */
  bounded?: boolean;
}

/**
 * One line per day and product over the account's whole life: messages, MT parts and what was
 * charged.
 *
 * <p>The same seam the reconciliation uses (`consumedSql`): `usage_daily` for every day and product
 * it covers, and `cdr_submit` only for the ones it does not, so the two halves are disjoint and a
 * rolled-up day that still has its call records is not counted twice.
 *
 * <p>The tail counts parts exactly as the gateway's `UsageRollup` does, so a day reads the same
 * before and after it is rolled up: one row per message (`messageRows`, the rollup's own
 * `DISTINCT ON`), `part_count` from that row because segments 2..N write none, and nothing for a
 * message whose chosen attempt a vendor refused. A null status is a vendor with no such field, not a
 * refusal.
 *
 * <p><strong>The tail is bounded</strong> (Audit CP-P2): it reads from `rollupTailFrom` -- local
 * midnight of the day before the account's newest line -- so `idx_cdr_submit_account_time_covering`
 * walks a few days rather than the account's lifetime with a function of `submitted_at` in the
 * predicate. The anti-join still decides line by line inside that range. An account with no line
 * reads from the beginning of time, and carries only the columns the aggregate reads.
 *
 * <p>`mt_parts` is NULL on a line rolled up before V1.68.0 — not counted, rather than none sent —
 * and is passed through as NULL so the page can say so.
 *
 * <p>$1 is the account, $2 the billing zone, $3 (with `bounded`) the tail's start. Amounts and counts come back as text: they are BIGINT
 * and `pg` would otherwise hand back strings or lose precision silently.
 */
export function mtUsageSql(o: MtUsageSqlOptions): string {
  const sent = o.submitStatus ? "COALESCE(s.submit_status, 0) = 0" : "TRUE";
  return `
  SELECT u.day::text                                   AS day,
         u.product                                     AS product,
         u.submitted::text                             AS messages,
         ${o.mtParts ? "u.mt_parts" : "NULL"}::text AS mt_parts,
         u.price_total::text                           AS price
    FROM usage_daily u
   WHERE u.account_id = $1
  UNION ALL
  SELECT (s.submitted_at AT TIME ZONE $2)::date::text AS day,
         COALESCE(s.product, '')                       AS product,
         count(*)::text                                AS messages,
         COALESCE(SUM(s.part_count) FILTER (WHERE ${sent}), 0)::text AS mt_parts,
         COALESCE(SUM(s.price), 0)::text               AS price
    FROM ${messageRows(`s.account_id = $1
         AND s.submitted_at >= ${rollupTailFrom("$2", "$1")}${o.bounded ? `
         AND s.submitted_at >= $3::timestamptz` : ""}
         AND NOT EXISTS (
                 SELECT 1 FROM usage_daily u
                  WHERE u.account_id = s.account_id
                    AND u.day = (s.submitted_at AT TIME ZONE $2)::date
                    AND u.product = COALESCE(s.product, ''))`, o,
         ["account_id", "product", "submitted_at", "part_count", "price",
          ...(o.submitStatus ? ["submit_status"] : [])])}
   GROUP BY 1, 2`;
}

/** Today in the billing zone, so "this month" and "today" are cut where the rollup cuts days. */
export const TODAY_SQL = "SELECT (now() AT TIME ZONE $1)::date::text AS today";

/**
 * The account's seam, as `rollupTailFrom` computes it inside {@link mtUsageSql}: local midnight of
 * the day before its newest `usage_daily` line, or NULL when it has none. One probe of the primary
 * key. $1 the account, $2 the billing zone.
 */
export const MT_TAIL_FROM_SQL = `SELECT ((max(u.day) - 1)::timestamp AT TIME ZONE $2) AS tail_from
  FROM usage_daily u
 WHERE u.account_id = $1`;

/** Where the tail is read from, what it is routed on, and whether the figures are partial. */
export interface MtTailPlan {
  /** `$3`: the lower bound on the tail's `submitted_at`. */
  from: Date;
  /**
   * Set when the account has no `usage_daily` line, so only the records from `from` are counted:
   * the page says so rather than presenting them as the account's lifetime.
   */
  recordsFrom: Date | null;
}

/**
 * The tail's start for {@link mtUsageSql} with `bounded`.
 *
 * <ul>
 *   <li><b>The account has lines:</b> its seam (`tailFrom`, from {@link MT_TAIL_FROM_SQL}). The
 *       statement is routed on it -- the hot tables whenever the newest line is recent, which on a
 *       deployment whose rollup runs is always. This used to be routed on "everything" (`null`) and
 *       so always read the `_all` views (incident 2026-10-31).</li>
 *   <li><b>No line at all:</b> the account was never rolled up -- it is new, or the rollup is off.
 *       Its whole history used to be read from the records on every open of the Billing tab. Now
 *       the hot days only (the hot boundary plus its hour of margin; without tiers, or with a
 *       boundary that cannot be read, the last {@link CDR_HOT_FALLBACK_MS}), and `recordsFrom`
 *       says so. A new account's traffic is all in the hot days anyway; a deployment with the
 *       rollup off has to run it (`fireflo usage rollup`) for lifetime figures.</li>
 * </ul>
 */
export function mtTailPlan(tailFrom: Date | null, boundary: CdrBoundary, now: number): MtTailPlan {
  if (tailFrom !== null) {
    return { from: tailFrom, recordsFrom: null };
  }
  const from =
    boundary === null || boundary === CDR_EVERYTHING
      ? new Date(now - CDR_HOT_FALLBACK_MS)
      : new Date(boundary.getTime() + CDR_TIER_MARGIN_MS);
  return { from, recordsFrom: from };
}
