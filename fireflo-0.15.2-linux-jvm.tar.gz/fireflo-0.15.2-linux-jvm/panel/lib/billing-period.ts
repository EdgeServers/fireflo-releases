/**
 * The window a statement covers, as a pair of instants.
 *
 * <p>Database-free, so the customer portal and the operator panel can both import it.
 *
 * <p><strong>The shared `Range` enum is deliberately not widened to add a month.</strong> Every
 * control route consumes it — the dashboard, the metrics page, the CDR search — and adding a value
 * there would make each of them answer a question nobody asked them. A statement is the only thing
 * that thinks in calendar months, so the month lives here.
 *
 * <p><strong>Cut in the billing zone, which every caller passes.</strong> A bare date string is
 * parsed as UTC midnight by specification, so in Asia/Kolkata a month starting "2026-08-01" would
 * begin at 05:30 on the 1st and a customer would lose five and a half hours of billable traffic off
 * the front of every invoice. This used to cut in the *process's* local zone (`localDayStart`),
 * which is right in a browser and wrong on the server, where these run: there it was whatever the
 * host's `TZ` said, not `smsg.billing.zone`, so a statement and the usage page could disagree
 * about where the 1st began. {@link dayStartIn} cuts at midnight in the zone named.
 */

import { addDays, dayStartIn } from "./datetime.ts";
import {
  MAX_RANGE_DAYS,
  spanInDays,
  validateRange,
} from "./date-range.ts";

/** Half-open, always: `[since, until)`. The boundary belongs to exactly one period. */
export interface BillingPeriod {
  since: Date;
  /** Exclusive. The instant the next period starts. */
  until: Date;
  /** `2026-08` for a calendar month, or `2026-08-03..2026-08-17` for a custom window. */
  label: string;
}

const MONTH = /^(\d{4})-(\d{2})$/;

/**
 * A calendar month, from its `YYYY-MM` name.
 *
 * <p><strong>Built as "midnight on the 1st of this month to midnight on the 1st of the next", in
 * the zone, never as "the 1st plus 30 days".</strong> That one choice is what makes February, leap
 * years and daylight-saving changes need no special case at all: a month containing a DST transition
 * is 30 days and 23 hours -- exactly one month, which is what a customer is being billed for.
 *
 * @param zone the billing zone (`billingZone()`)
 * @return null when the text is not a month, or names a month that does not exist
 */
export function monthPeriod(value: string, zone: string): BillingPeriod | null {
  const match = MONTH.exec((value ?? "").trim());
  if (!match) {
    return null;
  }
  const month = Number(match[2]);
  if (month < 1 || month > 12) {
    return null;
  }
  const year = Number(match[1]);
  const next = month === 12 ? `${year + 1}-01-01` : `${match[1]}-${String(month + 1).padStart(2, "0")}-01`;
  const since = dayStartIn(`${match[1]}-${match[2]}-01`, zone);
  const until = dayStartIn(next, zone);
  if (!since || !until || until.getTime() <= since.getTime()) {
    return null;
  }
  return { since, until, label: `${match[1]}-${match[2]}` };
}

/**
 * An arbitrary window, on the same rules and the same ceiling every other date range here has.
 *
 * <p>Two `<input type="date">` values, inclusive as typed and half-open on the wire, so the day a
 * customer names as their last day is fully inside the period.
 *
 * @return the period, or a sentence saying why not — the same wording `validateRange` produces, so
 *     a customer sees one vocabulary rather than two
 */
export function customPeriod(from: string, to: string, zone: string): BillingPeriod | string {
  const invalid = validateRange(from, to);
  if (invalid) {
    return invalid;
  }
  //validateRange accepted both as YYYY-MM-DD days; they are named as typed, and cut in the zone
  const since = dayStartIn(from.trim(), zone);
  const until = dayStartIn(addDays(to.trim(), 1), zone);
  if (!since || !until) {
    return "That is not a valid date.";
  }
  return { since, until, label: `${from.trim()}..${to.trim()}` };
}

/**
 * Whether a period is small enough to query.
 *
 * <p>A calendar month is always inside {@link MAX_RANGE_DAYS}, so this only ever fires on a custom
 * window — but it is checked for both, because "the caller already validated" is exactly the
 * assumption that stops being true when a second caller appears.
 */
export function periodTooLong(period: BillingPeriod): string | null {
  const days = spanInDays(period.since, period.until);
  return days > MAX_RANGE_DAYS
    ? `That period is ${days} days. Ask for at most ${MAX_RANGE_DAYS} at a time.`
    : null;
}

/**
 * The month a date falls in, as `YYYY-MM`.
 *
 * <p>Local, matching {@link monthPeriod}. `toISOString().slice(0, 7)` is the UTC month and names
 * the previous one for anyone west of Greenwich on the 1st.
 */
export function monthOf(at: Date): string {
  return `${at.getFullYear()}-${String(at.getMonth() + 1).padStart(2, "0")}`;
}

/**
 * The last N months, newest first, for a period picker.
 *
 * <p>Includes the month in progress. A statement for a month that has not finished is a legitimate
 * thing to want — it is what an operator looks at to see whether a postpaid account is on track —
 * and labelling it is the period picker's job, not this function's.
 */
export function recentMonths(from: Date, count: number): string[] {
  const months: string[] = [];
  const cursor = new Date(from.getFullYear(), from.getMonth(), 1);
  for (let i = 0; i < count; i++) {
    months.push(monthOf(cursor));
    cursor.setMonth(cursor.getMonth() - 1);
  }
  return months;
}
