import type { CdrRow, MessageReceipt } from "./cdr-request.ts";

/**
 * What encoding crossed the wire on each leg of a message, in words.
 *
 * <p>The gateway's V1.124.0 records it per leg: what the customer sent (`cdr_submit.dcs`, which has
 * always been there, plus `esm_class_received`, `chars_received`, `bytes_received`,
 * `payload_received`), what each part went to the vendor as (`dcs_sent`, `esm_class_sent`,
 * `bytes_sent`), and the data_coding of the vendor's receipt (`cdr_final`/`cdr_interim`
 * `.dcs_received`). None of it needs the message text, so it is there even when `smsg.cdr.body`
 * is off.
 *
 * <p><strong>Three-valued, like every optional CDR field.</strong> `undefined` is a gateway whose
 * schema has no such column (so nothing was asked and nothing is shown); `null` is a row that
 * predates the column, an HTTP leg that has no such field, or an attempt that never put a PDU on
 * the wire; a number is what was recorded. They are never collapsed: a missing data_coding is not
 * GSM-7.
 *
 * <p>Database-free, so the client page and `node --test` can both import it.
 */

/** SMPP 3.4 5.2.19 data_coding values, in the names an operator reads them by. */
const DCS_NAMES: Record<number, string> = {
  0: "GSM-7",
  1: "IA5/ASCII",
  2: "8-bit",
  3: "Latin-1",
  4: "8-bit binary",
  5: "JIS",
  6: "Cyrillic",
  7: "Hebrew",
  8: "UCS-2",
};

/**
 * The data_coding the gateway puts on every receipt it sends a customer.
 *
 * <p>Fixed: `SmppServerWorker` builds each receipt `deliver_sm` with `DATA_CODING_DEFAULT`, whatever
 * the message itself was, so this leg needs no column.
 */
export const RECEIPT_OUT_DCS = 0;

/** esm_class bit 6: the short message starts with a User Data Header (a concatenation header). */
export const ESM_UDHI = 0x40;

/** The coding's name, or `dcs N` for one SMPP does not name. Null in, null out. */
export function dcsName(dcs: number | null | undefined): string | null {
  if (dcs == null) {
    return null;
  }
  return DCS_NAMES[dcs] ?? `dcs ${dcs}`;
}

/** `UCS-2 · dcs 8`: the name an operator reads, and the octet a vendor's support desk asks for. */
export function dcsLabel(dcs: number | null | undefined): string | null {
  if (dcs == null) {
    return null;
  }
  const name = DCS_NAMES[dcs];
  return name ? `${name} · dcs ${dcs}` : `dcs ${dcs}`;
}

/** `0x40`, two hex digits. */
export function esmHex(esm: number): string {
  return `0x${(esm & 0xff).toString(16).padStart(2, "0")}`;
}

/**
 * What an esm_class octet says, in words.
 *
 * <p>Three independent fields (SMPP 3.4 5.2.12): bits 0-1 the messaging mode, bits 2-5 the message
 * type, bits 6-7 the GSM features. Only what is set is named; 0x00 is "no flags", the ordinary
 * value for a plain submit_sm.
 */
export function esmClassText(esm: number | null | undefined): string | null {
  if (esm == null) {
    return null;
  }
  const notes: string[] = [];
  const type = esm & 0x3c;
  if ((type & 0x04) !== 0) {
    notes.push((type & 0x20) !== 0 ? "progress receipt" : "delivery receipt");
  } else if (type === 0x08) {
    notes.push("SME acknowledgement");
  } else if (type === 0x10) {
    notes.push("user acknowledgement");
  } else if (type === 0x18) {
    notes.push("conversation abort");
  } else if (type === 0x20) {
    notes.push("intermediate notification");
  } else if (type !== 0) {
    notes.push(`message type ${esmHex(type)}`);
  }
  if ((esm & ESM_UDHI) !== 0) {
    notes.push("UDH present");
  }
  if ((esm & 0x80) !== 0) {
    notes.push("reply path");
  }
  const mode = esm & 0x03;
  if (mode === 1) {
    notes.push("datagram mode");
  } else if (mode === 2) {
    notes.push("transaction mode");
  } else if (mode === 3) {
    notes.push("store and forward");
  }
  return notes.length ? notes.join(", ") : "no flags";
}

/**
 * The note a converted part carries: `converted from Latin-1 (dcs 3)`.
 *
 * <p>Null when nothing was converted, and when either side is unknown — "we cannot tell" is not
 * "it was converted", and it is not "it was not" either.
 */
export function convertedFrom(
  received: number | null | undefined,
  sent: number | null | undefined
): string | null {
  if (received == null || sent == null || received === sent) {
    return null;
  }
  return `converted from ${dcsName(received)} (dcs ${received})`;
}

/** One row's encoding cell: a bold coding line, a monospace detail line, and a conversion note. */
export interface LegEncoding {
  /** `UCS-2 · dcs 8`, or `not recorded` when the column exists and this row has no value. */
  label: string;
  /** `esm 0x40 UDH present · 140 bytes`, or null when there is nothing more to say. */
  detail: string | null;
  /** `converted from Latin-1 (dcs 3)` when the vendor got a different coding from the customer's. */
  convertedFrom: string | null;
  /** Why it says `not recorded`, for the cell's tooltip. */
  why?: string;
}

/** The chips under a card title. `warning` is a conversion; the rest are plain facts. */
export interface EncodingChip {
  text: string;
  tone: "neutral" | "warning";
}

export interface LegSummary {
  chips: EncodingChip[];
  /** One sentence under the chips: what was converted, or that nothing was. */
  note: string | null;
}

/** The fields of the customer's submission this module reads. All but `dcs` arrive in V1.124.0. */
export type IngressFields = Pick<CdrRow, "ingress" | "dcs"> &
  Partial<Pick<CdrRow, "esmClassReceived" | "charsReceived" | "bytesReceived" | "payloadReceived"
    | "inboundSegments" | "body">>;

/** What a vendor attempt carried. All three arrive in V1.124.0. */
export type SentFields = Pick<CdrRow, "dcs"> &
  Partial<Pick<CdrRow, "dcsSent" | "esmClassSent" | "bytesSent">>;

function overHttp(ingress: string | null | undefined): boolean {
  return (ingress ?? "").toLowerCase().includes("http");
}

function plural(n: number, one: string, many = `${one}s`): string {
  return `${n.toLocaleString("en-AU")} ${n === 1 ? one : many}`;
}

function esmPart(esm: number | null | undefined): string | null {
  if (esm == null) {
    return null;
  }
  const text = esmClassText(esm);
  return esm === 0 ? `esm ${esmHex(esm)}` : `esm ${esmHex(esm)} ${text}`;
}

/**
 * The customer's `submit_sm` (or HTTP request), as it arrived.
 *
 * <p>`dcs` has always been recorded, so this has something to say on any gateway; the octets, the
 * esm_class and which field the text was in are V1.124.0 and are SMPP-only — the gateway writes
 * NULL for them on an HTTP submission, which has no such fields, and that is said rather than
 * shown as a blank.
 */
export function ingressEncoding(first: IngressFields): LegEncoding {
  const http = overHttp(first.ingress);
  const label = dcsLabel(first.dcs) ?? "not recorded";
  const parts: string[] = [];
  if (http) {
    if (first.charsReceived != null) {
      parts.push(plural(first.charsReceived, "character"));
    }
    parts.push("over HTTP: no esm_class or octets");
  } else {
    const esm = esmPart(first.esmClassReceived);
    if (esm) {
      parts.push(esm);
    }
    if (first.bytesReceived != null) {
      parts.push(plural(first.bytesReceived, "byte"));
    }
    if (first.payloadReceived != null) {
      parts.push(first.payloadReceived ? "message_payload" : "short_message");
    }
  }
  return {
    label,
    detail: parts.length ? parts.join(" · ") : null,
    convertedFrom: null,
    ...(first.dcs == null ? { why: "this row has no data_coding recorded" } : {}),
  };
}

/** The receipt `deliver_sm` the gateway sends a customer: always dcs 0, 0x04 or 0x24 by kind. */
export function receiptOutEncoding(terminal: boolean | undefined): LegEncoding {
  const esm = terminal === false ? 0x24 : 0x04;
  return {
    label: dcsLabel(RECEIPT_OUT_DCS)!,
    detail: terminal === undefined
      ? "receipt · always dcs 0"
      : `esm ${esmHex(esm)} ${esmClassText(esm)} · always dcs 0`,
    convertedFrom: null,
  };
}

/**
 * One `submit_sm` to the vendor, as the gateway actually sent it.
 *
 * <p>Undefined on a gateway before V1.124.0 — the cell then says nothing rather than guessing that
 * the vendor got what the customer sent, which is exactly the assumption a vendor's
 * `msgType.dcs.map` breaks.
 */
export function vendorSubmitEncoding(attempt: SentFields): LegEncoding | undefined {
  if (!("dcsSent" in attempt)) {
    return undefined;
  }
  if (attempt.dcsSent == null) {
    return {
      label: "not recorded",
      //said on the cell, not only in a tooltip: each reason sends the reader somewhere else
      detail: "no submit_sm sent, a non-SMPP vendor, or an older row",
      convertedFrom: null,
      why: "no submit_sm went on the wire for this attempt, the vendor is not SMPP, or the row predates the column",
    };
  }
  const parts: string[] = [];
  const esm = esmPart(attempt.esmClassSent);
  if (esm) {
    parts.push(esm);
  }
  if (attempt.bytesSent != null) {
    parts.push(plural(attempt.bytesSent, "byte"));
  }
  return {
    label: dcsLabel(attempt.dcsSent)!,
    detail: parts.length ? parts.join(" · ") : null,
    convertedFrom: convertedFrom(attempt.dcs, attempt.dcsSent),
  };
}

/** The vendor's receipt `deliver_sm`, by its own data_coding. Undefined before V1.124.0. */
export function receiptInEncoding(
  receipt: Pick<MessageReceipt, "dcsReceived">
): LegEncoding | undefined {
  if (!("dcsReceived" in receipt)) {
    return undefined;
  }
  if (receipt.dcsReceived == null) {
    return {
      label: "not recorded",
      detail: "receipt stored before its coding was kept",
      convertedFrom: null,
      why: "the receipt was recorded before the gateway kept its data_coding",
    };
  }
  return { label: dcsLabel(receipt.dcsReceived)!, detail: "receipt", convertedFrom: null };
}

/**
 * The chips under the Customer exchange title.
 *
 * @param receiptSent whether the exchange has a receipt `deliver_sm` going out — over HTTP there is
 *     none (the customer hears by callback), and saying how a receipt was coded when none was sent
 *     would be a claim about a PDU that does not exist
 */
export function customerLegSummary(first: IngressFields, receiptSent: boolean): LegSummary {
  const http = overHttp(first.ingress);
  const bits: string[] = [`Received as ${dcsLabel(first.dcs) ?? "an unrecorded coding"}`];
  if (http) {
    bits.push("over HTTP");
    if (first.charsReceived != null) {
      bits.push(plural(first.charsReceived, "character"));
    }
  } else {
    bits.push(plural(Math.max(1, first.inboundSegments ?? 1), "submit_sm"));
    if (first.bytesReceived != null) {
      bits.push(plural(first.bytesReceived, "byte"));
    }
    if (first.payloadReceived === true) {
      bits.push("in message_payload");
    }
  }
  const chips: EncodingChip[] = [{ text: bits.join(" · "), tone: "neutral" }];
  if (receiptSent) {
    chips.push({ text: `Receipt sent as ${dcsLabel(RECEIPT_OUT_DCS)}`, tone: "neutral" });
  }
  return { chips, note: null };
}

/**
 * The chips under the Vendor exchange title, from every attempt and every receipt.
 *
 * <p>Attempts are grouped by the coding they went out in, so a failover to a vendor with a
 * different `msgType.dcs.map` shows as two codings rather than whichever attempt came first.
 */
export function vendorLegSummary(
  attempts: readonly (SentFields & Pick<CdrRow, "partNo" | "vendor"> & Partial<Pick<CdrRow, "partCount">>)[],
  receipts: readonly Pick<MessageReceipt, "dcsReceived">[]
): LegSummary {
  const chips: EncodingChip[] = [];
  const recorded = attempts.filter((a) => a.dcsSent != null);
  const notes: string[] = [];

  const byCoding = new Map<number, typeof recorded>();
  for (const a of recorded) {
    const group = byCoding.get(a.dcsSent!) ?? [];
    group.push(a);
    byCoding.set(a.dcsSent!, group);
  }
  for (const [dcs, group] of byCoding) {
    //the gateway writes one cdr_submit row per message (part 1, with part_count), not one per
    //segment, so the parts come from part_count; distinct part numbers only as a fallback
    const parts = Math.max(
      new Set(group.map((a) => a.partNo)).size,
      ...group.map((a) => (a.partCount != null && a.partCount > 0 ? a.partCount : 1))
    );
    const udh = group.some((a) => a.esmClassSent != null && (a.esmClassSent & ESM_UDHI) !== 0);
    const from = convertedFrom(group[0].dcs, dcs);
    const vendors = [...new Set(group.map((a) => a.vendor).filter((v): v is string => !!v))];
    const text = [
      `Sent as ${dcsLabel(dcs)}${from ? `, ${from}` : ""}`,
      plural(parts, "part"),
      ...(udh ? ["UDH"] : []),
      ...(byCoding.size > 1 && vendors.length ? [vendors.join(", ")] : []),
    ].join(" · ");
    chips.push({ text, tone: from ? "warning" : "neutral" });
    if (from) {
      const who = vendors.length ? `Vendor ${vendors.join(", ")}` : "The vendor";
      notes.push(
        `${who} maps the customer's dcs ${group[0].dcs} to dcs ${dcs} (its msgType.dcs.map, with ` +
        `dcs.charset.map choosing the character set)` +
        (dcs === 0 || dcs === 1 || dcs === 3
          ? `; characters ${dcsName(dcs)} cannot carry would have been replaced.`
          : ".")
      );
    }
  }

  const receiptCodings = [...new Set(receipts
    .map((r) => r.dcsReceived)
    .filter((d): d is number => d != null))];
  for (const dcs of receiptCodings) {
    chips.push({ text: `Receipt received as ${dcsLabel(dcs)}`, tone: "neutral" });
  }

  if (recorded.length > 0 && notes.length === 0) {
    notes.push("Same coding as the customer sent: nothing converted.");
  }
  return { chips, note: notes.length ? notes.join(" ") : null };
}

/** Whether any attempt went to a vendor in a different coding from the customer's. */
export function anyConverted(attempts: readonly SentFields[]): boolean {
  return attempts.some((a) => convertedFrom(a.dcs, a.dcsSent) != null);
}

/**
 * The Message card's caption: `UCS-2 · 94 characters · 2 parts`.
 *
 * <p>`chars_received` is the gateway's count as it accepted the message, so the caption is there
 * when the text is not kept. Before V1.124.0 it falls back to the stored body's length, and without
 * either it names only the coding and the parts.
 */
export function messageCaption(
  first: IngressFields & Pick<CdrRow, "partCount">,
  attempts: readonly SentFields[]
): string {
  const bits: string[] = [];
  const converted = attempts.find((a) => convertedFrom(a.dcs, a.dcsSent) != null);
  if (converted) {
    bits.push(`${dcsName(first.dcs)} in, ${dcsName(converted.dcsSent)} out`);
  } else if (first.dcs != null) {
    bits.push(dcsName(first.dcs)!);
  }
  const chars = first.charsReceived ?? (first.body ? [...first.body].length : null);
  if (chars != null) {
    bits.push(plural(chars, "character"));
  }
  bits.push(plural(first.partCount, "part"));
  return bits.join(" · ");
}
