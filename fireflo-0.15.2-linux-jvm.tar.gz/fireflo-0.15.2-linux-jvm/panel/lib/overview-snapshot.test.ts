import { strict as assert } from "node:assert";
import { test } from "node:test";

import {
  vendorsOf,
  bucketKey,
  createRefresher,
  hourFloor,
  mergeHourly,
  refreshSecondsFrom,
  WarmingUpError,
  windowStart,
  type Range,
  type SnapshotDeps,
} from "./overview-snapshot.ts";
import type { RevenueRow, TrafficBucket } from "./overview-totals.ts";

const HOUR = 3_600_000;
const MINUTE = 60_000;

/** A fake database: hourly buckets stamped with the read that produced them. */
function fakeDeps(over: Partial<SnapshotDeps> & { hourly?: boolean; hwm?: Date | null } = {}) {
  //ten to the hour, so a tick eleven minutes on slides the window without being a full rebuild
  let now = new Date("2026-10-15T10:50:00Z");
  let reads = 0;
  const calls = {
    traffic: [] as { range: Range; since?: Date; until?: Date; source: string }[],
    revenue: [] as { range: Range; since?: Date; until?: Date; source: string }[],
    failures: [] as Range[],
    vendors: [] as Range[],
    log: [] as string[],
  };
  const deps: SnapshotDeps = {
    async traffic(range, o) {
      calls.traffic.push({ range, since: o.since, until: o.until, source: o.source });
      reads++;
      if (range === "24h") {
        const since = o.since ?? windowStart(now);
        const until = o.until ?? now;
        const out: TrafficBucket[] = [];
        for (let t = hourFloor(since).getTime(); t < until.getTime(); t += HOUR) {
          //submitted carries the read number, so a test can tell a kept bucket from a re-read one
          out.push({ bucket: bucketKey(new Date(t)), submitted: reads, delivered: 1, failed: 0, expired: 0, pending: 0 });
        }
        return out;
      }
      //a day range: the finished days when until is today's start, today alone when since is. Day
      //buckets are keyed by the billing day's YYYY-MM-DD, as trafficOverTime emits them
      if (o.since) {
        return [{ bucket: "2026-10-15", submitted: 100 + reads, delivered: 50, failed: 1, expired: 0, pending: 49 }];
      }
      return [
        { bucket: "2026-10-13", submitted: 1000, delivered: 990, failed: 10, expired: 0, pending: 0 },
        { bucket: "2026-10-14", submitted: 2000, delivered: 1980, failed: 20, expired: 0, pending: 0 },
      ];
    },
    async revenue(range, o) {
      calls.revenue.push({ range, since: o.since, until: o.until, source: o.source });
      const row = (day: string, revenue: number): RevenueRow => ({
        accountId: "acct-a", product: "standard", messages: 10, revenue, cost: revenue / 2, margin: revenue / 2, pendingRevenue: 0, day,
      });
      return o.since ? [row("2026-10-15", 5)] : [row("2026-10-13", 100), row("2026-10-14", 200)];
    },
    async failures(range) {
      calls.failures.push(range);
      return { since: new Date(now.getTime() - 24 * HOUR).toISOString(), rows: [] };
    },
    async vendors(range) {
      calls.vendors.push(range);
      return [{ vendor: "smppsim", attempts: 10, messages: 10, delivered: 8, failed: 1, pending: 1, cost: 0, deliveryRate: 8 / 9 }];
    },
    async hasUsageHourly() {
      return over.hourly ?? false;
    },
    async hourlyWatermark() {
      return over.hwm ?? null;
    },
    async billingDays() {
      return { todayStart: new Date("2026-10-15T00:00:00Z"), today: "2026-10-15" };
    },
    async deadlineHours() {
      return 48;
    },
    now: () => now,
    log: (line) => calls.log.push(line),
    ...over,
  };
  return {
    deps,
    calls,
    advance(ms: number) {
      now = new Date(now.getTime() + ms);
    },
    get now() {
      return now;
    },
  };
}

//no idle eviction in the tests below: they tick without a viewer asking in between. The eviction
//has tests of its own at the end
const cfg = { refreshSeconds: 60, schedule: false, idleMs: Number.POSITIVE_INFINITY } as const;

test("the first get builds once, and concurrent gets share the build", async () => {
  const f = fakeDeps();
  const r = createRefresher(f.deps, cfg);
  const [a, b, c] = await Promise.all([r.get("24h"), r.get("24h"), r.get("24h")]);
  assert.equal(a, b);
  assert.equal(b, c);
  assert.equal(f.calls.traffic.length, 1, "one traffic read for three callers");
  assert.equal(a.traffic.length, 24, "23 whole hours and the current one");
  assert.equal(a.asOf, "2026-10-15T10:50:00.000Z");
  assert.equal(a.source, "live");
  assert.equal(a.settlingFrom, new Date(f.now.getTime() - 48 * HOUR).toISOString());
  //the second get is memory
  assert.equal(await r.get("24h"), a);
  assert.equal(f.calls.traffic.length, 1);
});

test("a tick re-reads only the hot window; frozen buckets are kept and aged-out ones dropped", async () => {
  const f = fakeDeps();
  const r = createRefresher(f.deps, cfg);
  const first = await r.get("24h");
  const firstByKey = new Map(first.traffic.map((b) => [b.bucket, b]));

  //eleven minutes on: the hour turned, so the window slides, the oldest bucket ages out and a new
  //current one appears -- and the full rebuild (fifteen minutes) is not yet due
  f.advance(11 * MINUTE);
  await r.tick();
  const second = await r.get("24h");
  assert.notEqual(second, first);

  const call = f.calls.traffic[f.calls.traffic.length - 1];
  const hotFrom = new Date(hourFloor(f.now).getTime() - 3 * HOUR);
  assert.equal(call.since?.toISOString(), hotFrom.toISOString(), "the hot window starts three whole hours back");
  assert.equal(call.until?.toISOString(), f.now.toISOString());
  assert.equal(call.source, "live");

  assert.equal(second.traffic.length, 24, "still 24 buckets");
  assert.equal(second.traffic[0].bucket, bucketKey(windowStart(f.now)), "the window's first bucket moved on an hour");
  assert.ok(!second.traffic.some((b) => b.bucket === first.traffic[0].bucket), "the oldest bucket aged out");
  for (const b of second.traffic) {
    if (b.bucket < bucketKey(hotFrom)) {
      assert.deepEqual(b, firstByKey.get(b.bucket), `${b.bucket} kept from the first read`);
      assert.equal(b.submitted, 1, "stamped by read 1");
    } else {
      assert.ok(b.submitted > 1, `${b.bucket} re-read`);
    }
  }
  assert.equal(second.asOf, f.now.toISOString(), "as-of advances with the tick");
  assert.equal(second.builtAt, first.builtAt, "built-at is the full build's");
});

test("fifteen minutes on, the whole window is read again", async () => {
  const f = fakeDeps();
  const r = createRefresher(f.deps, cfg);
  await r.get("24h");
  f.advance(5 * MINUTE);
  await r.tick();
  assert.notEqual(f.calls.traffic.at(-1)!.since!.toISOString(), windowStart(f.now).toISOString(), "a hot read");
  f.advance(10 * MINUTE);
  await r.tick();
  const call = f.calls.traffic.at(-1)!;
  assert.equal(call.since!.toISOString(), windowStart(f.now).toISOString(), "a full read");
  const snap = await r.get("24h");
  assert.equal(snap.builtAt, f.now.toISOString());
  assert.ok(snap.traffic.every((b) => b.submitted === 3), "every bucket from the third read");
});

test("failures are read per range on the first build, not on the next tick, and again after five minutes", async () => {
  const f = fakeDeps();
  const r = createRefresher(f.deps, cfg);
  await r.get("24h");
  assert.deepEqual(f.calls.failures, ["24h"]);
  f.advance(MINUTE);
  await r.tick();
  assert.deepEqual(f.calls.failures, ["24h"], "not yet due");
  //the breakdown follows the range like every other card, so a second range reads its own
  await r.get("7d");
  assert.deepEqual(f.calls.failures, ["24h", "7d"], "each range its own window");
  f.advance(4 * MINUTE);
  await r.tick();
  assert.deepEqual(f.calls.failures, ["24h", "7d", "24h"], "the 24h range is due at five minutes; 7d at its own");
});

test("vendors are a section of every tick, per range", async () => {
  const f = fakeDeps({ hourly: true, hwm: new Date("2026-10-15T10:48:30Z") });
  const r = createRefresher(f.deps, cfg);
  const snap = await r.get("7d");
  assert.deepEqual(f.calls.vendors, ["7d"]);
  assert.equal(snap.vendors[0].vendor, "smppsim");
  assert.equal(snap.watermark, "2026-10-15T10:48:30.000Z", "the cards can say the summary ran to here");
  f.advance(MINUTE);
  await r.tick();
  assert.deepEqual(f.calls.vendors, ["7d", "7d"], "re-read on the tick: it is a few milliseconds");
});

test("without a moving summary the snapshot says it read the records alone", async () => {
  const f = fakeDeps({ hourly: true, hwm: new Date("2026-10-15T01:00:00Z") });
  const snap = await createRefresher(f.deps, cfg).get("24h");
  assert.equal(snap.watermark, null, "a watermark nearly ten hours old is not leaned on");
});

test("a failed read keeps the previous section, marks it stale, and logs one line", async () => {
  const f = fakeDeps();
  const r = createRefresher(f.deps, cfg);
  const first = await r.get("24h");
  const good = f.deps.traffic;
  f.deps.traffic = async () => {
    throw new Error("connection refused");
  };
  f.advance(MINUTE);
  await r.tick();
  const snap = await r.get("24h");
  assert.deepEqual(snap.traffic, first.traffic, "the previous series stands");
  assert.deepEqual(snap.stale, { traffic: true, revenue: false, failures: false, vendors: false });
  assert.equal(snap.asOf, f.now.toISOString(), "as-of still advances: the page is told what was tried");
  assert.equal(f.calls.log.length, 1);
  assert.match(f.calls.log[0], /traffic: connection refused/);
  assert.equal(r.debug().failedTicks, 1);

  f.deps.traffic = good;
  f.advance(MINUTE);
  await r.tick();
  assert.equal((await r.get("24h")).stale.traffic, false, "clears on the next good read");
  assert.equal(f.calls.log.length, 1, "nothing more logged");
});

test("a first build whose reads fail answers empty, stale tiles and is retried by the next tick", async () => {
  const f = fakeDeps();
  const good = f.deps.traffic;
  f.deps.traffic = async () => {
    throw new Error("canceling statement due to statement timeout");
  };
  const r = createRefresher(f.deps, cfg);
  const first = await r.get("24h");
  assert.deepEqual(first.traffic, [], "nothing to show yet, but a snapshot exists");
  assert.equal(first.stale.traffic, true);
  assert.equal(first.totals.messages, 0);
  assert.equal(f.calls.log.length, 1);

  f.deps.traffic = good;
  f.advance(MINUTE);
  await r.tick();
  const next = await r.get("24h");
  assert.equal(next.stale.traffic, false, "the background tick filled it in; no request paid for it");
  assert.ok(next.traffic.length > 0);
});

test("with the hourly summary and a moving watermark the window is read whole from it every tick", async () => {
  const f = fakeDeps({ hourly: true, hwm: new Date("2026-10-15T10:19:00Z") });
  const r = createRefresher(f.deps, cfg);
  const first = await r.get("24h");
  assert.equal(first.source, "hourly");
  f.advance(MINUTE);
  await r.tick();
  const call = f.calls.traffic.at(-1)!;
  assert.equal(call.source, "hourly");
  assert.equal(call.since!.toISOString(), windowStart(f.now).toISOString(), "24 small rows, so the whole window");
  assert.equal(r.debug().watermark, "2026-10-15T10:19:00.000Z");
});

test("a watermark that stopped moving is not a seam: the range stays live and progressive", async () => {
  const f = fakeDeps({ hourly: true, hwm: new Date("2026-10-15T06:00:00Z") });
  const r = createRefresher(f.deps, cfg);
  assert.equal((await r.get("24h")).source, "live");
  f.advance(MINUTE);
  await r.tick();
  assert.equal(f.calls.traffic.at(-1)!.source, "live");
  assert.notEqual(f.calls.traffic.at(-1)!.since!.toISOString(), windowStart(f.now).toISOString());
});

test("a day range keeps its finished days and re-reads today; the two day ranges share the read", async () => {
  const f = fakeDeps();
  const r = createRefresher(f.deps, cfg);
  const week = await r.get("7d");
  assert.deepEqual(week.traffic.map((b) => b.bucket), ["2026-10-13", "2026-10-14", "2026-10-15"], "billing days by their own names");
  const finished = f.calls.traffic.find((c) => c.range === "7d" && !c.since)!;
  assert.equal(finished.until!.toISOString(), "2026-10-15T00:00:00.000Z", "finished days end where today starts");
  assert.equal(finished.source, "live", "days come from the daily summary, never from hours");
  const today = f.calls.traffic.find((c) => c.range === "7d" && c.since)!;
  assert.equal(today.since!.toISOString(), "2026-10-15T00:00:00.000Z");
  //revenue: finished days kept, today re-read, summed per account and product
  assert.equal(week.revenue.length, 1);
  assert.equal(week.revenue[0].revenue, 305, "100 + 200 finished, 5 today");
  assert.equal(week.revenue[0].margin, 152.5);
  assert.equal(week.revenue[0].day, undefined, "the day is summed away");
  assert.equal(week.totals.messages, 3000 + week.traffic[2].submitted);

  await r.get("30d");
  f.advance(MINUTE);
  const before = f.calls.traffic.length;
  const beforeRevenue = f.calls.revenue.length;
  await r.tick();
  const tickReads = f.calls.traffic.slice(before);
  assert.equal(tickReads.length, 1, "one today read serves 7d and 30d");
  assert.equal(tickReads[0].since!.toISOString(), "2026-10-15T00:00:00.000Z");
  assert.equal(f.calls.revenue.length - beforeRevenue, 1, "one today revenue read serves both");
  const week2 = await r.get("7d");
  assert.deepEqual(week2.traffic.slice(0, 2), week.traffic.slice(0, 2), "finished days kept");
  assert.notEqual(week2.traffic[2].submitted, week.traffic[2].submitted, "today re-read");
});

test("OVERVIEW_REFRESH_SECONDS=0 builds on every request", async () => {
  const f = fakeDeps();
  const r = createRefresher(f.deps, { refreshSeconds: 0 });
  await r.get("24h");
  await r.get("24h");
  assert.equal(f.calls.traffic.length, 2);
  assert.equal(f.calls.failures.length, 2);
  assert.equal(r.debug().perRequest, true);
  await r.tick();
  assert.equal(f.calls.traffic.length, 2, "a tick does nothing in per-request mode");
});

test("a first build that outlives the warm-up answers 'warming up' and finishes in the background", async () => {
  const f = fakeDeps();
  let release!: () => void;
  const gate = new Promise<void>((res) => {
    release = res;
  });
  const slow = f.deps.traffic;
  f.deps.traffic = async (range, o) => {
    await gate;
    return slow(range, o);
  };
  const r = createRefresher(f.deps, { ...cfg, warmupMs: 20 });
  await assert.rejects(r.get("24h"), WarmingUpError);
  release();
  const snap = await r.get("24h");
  assert.equal(snap.traffic.length, 24);
  assert.equal(f.calls.traffic.length, 1, "the build was shared, not repeated");
});

test("?fresh rebuilds the range whole", async () => {
  const f = fakeDeps();
  const r = createRefresher(f.deps, cfg);
  await r.get("24h");
  f.advance(MINUTE);
  const snap = await r.get("24h", { fresh: true });
  assert.equal(f.calls.traffic.at(-1)!.since!.toISOString(), windowStart(f.now).toISOString());
  assert.equal(snap.builtAt, f.now.toISOString());
});

test("mergeHourly is a replacement by key inside a sliding 24-hour window", () => {
  const until = new Date("2026-10-15T10:20:00Z");
  const prev: TrafficBucket[] = [];
  for (let h = 0; h < 24; h++) {
    const t = new Date(Date.UTC(2026, 9, 14, 10 + h));
    prev.push({ bucket: bucketKey(t), submitted: 1, delivered: 0, failed: 0, expired: 0, pending: 0 });
  }
  const hotFrom = new Date("2026-10-15T07:00:00Z");
  const fresh = ["07", "08", "09", "10"].map((hh) => ({ bucket: `2026-10-15T${hh}:00:00Z`, submitted: 2, delivered: 0, failed: 0, expired: 0, pending: 0 }));
  const merged = mergeHourly(prev, fresh, hotFrom, until);
  assert.equal(merged.length, 24);
  assert.equal(merged[0].bucket, "2026-10-14T11:00:00Z", "10:00 yesterday aged out");
  assert.equal(merged.filter((b) => b.submitted === 2).length, 4);
  assert.ok(merged.every((b, i) => i === 0 || merged[i - 1].bucket < b.bucket), "sorted");
  //a fresh bucket with no traffic is simply absent, and nothing from prev fills the hole
  const sparse = mergeHourly(prev, fresh.slice(1), hotFrom, until);
  assert.ok(!sparse.some((b) => b.bucket === "2026-10-15T07:00:00Z"));
});

test("the cadence: 60 by default, never under 15, and 0 means per request", () => {
  assert.equal(refreshSecondsFrom({}), 60);
  assert.equal(refreshSecondsFrom({ OVERVIEW_REFRESH_SECONDS: "" }), 60);
  assert.equal(refreshSecondsFrom({ OVERVIEW_REFRESH_SECONDS: "abc" }), 60);
  assert.equal(refreshSecondsFrom({ OVERVIEW_REFRESH_SECONDS: "-5" }), 60);
  assert.equal(refreshSecondsFrom({ OVERVIEW_REFRESH_SECONDS: "5" }), 15);
  assert.equal(refreshSecondsFrom({ OVERVIEW_REFRESH_SECONDS: "120" }), 120);
  assert.equal(refreshSecondsFrom({ OVERVIEW_REFRESH_SECONDS: "0" }), 0);
});

test("vendorsOf: per vendor from per vendor and account, the rate recomputed; unsplit rows as they are", () => {
  const row = (vendor: string, account: string | undefined, delivered: number, failed: number) => ({
    vendor, ...(account === undefined ? {} : { account }), attempts: delivered + failed, messages: delivered + failed,
    delivered, failed, pending: 0, cost: 1, deliveryRate: 0.123,
  });
  assert.deepEqual(vendorsOf([row("v1", "a", 3, 1), row("v2", "a", 1, 0), row("v1", "b", 5, 1)]), [
    { vendor: "v1", attempts: 10, messages: 10, delivered: 8, failed: 2, pending: 0, cost: 2, deliveryRate: 0.8 },
    { vendor: "v2", attempts: 1, messages: 1, delivered: 1, failed: 0, pending: 0, cost: 1, deliveryRate: 1 },
  ]);
  const flat = [row("v1", undefined, 1, 1)];
  assert.deepEqual(vendorsOf(flat), flat, "a per-vendor read is left alone, its rate included");
});

test("a range nobody has asked for in fifteen minutes is dropped, not refreshed", async () => {
  const f = fakeDeps();
  const r = createRefresher(f.deps, { refreshSeconds: 60, schedule: false });
  await r.get("30d");
  await r.get("24h");
  const reads = () => f.calls.traffic.length + f.calls.vendors.length;

  //the 24 hours is still being looked at; the 30 days was opened once
  for (let i = 0; i < 14; i++) {
    f.advance(MINUTE);
    await r.get("24h");
    await r.tick();
  }
  assert.ok(f.calls.vendors.filter((v) => v === "30d").length > 1, "refreshed while recently asked for");
  f.advance(MINUTE);
  await r.get("24h");
  const before30 = f.calls.vendors.filter((v) => v === "30d").length;
  await r.tick();
  assert.equal(f.calls.vendors.filter((v) => v === "30d").length, before30, "fifteen idle minutes: the 30 days is not read");
  assert.deepEqual(Object.keys(r.debug().ranges), ["24h"], "and is forgotten");

  //asked for again: built afresh
  const again = await r.get("30d");
  assert.equal(again.asOf, f.now.toISOString());
  assert.equal(f.calls.vendors.filter((v) => v === "30d").length, before30 + 1);

  //every range idle: the tick reads nothing at all
  f.advance(16 * MINUTE);
  const n = reads();
  await r.tick();
  assert.equal(reads(), n, "an idle panel reads nothing");
  assert.deepEqual(Object.keys(r.debug().ranges), []);
});

test("a range being asked for is never dropped, however long it lives", async () => {
  const f = fakeDeps();
  const r = createRefresher(f.deps, { refreshSeconds: 60, schedule: false, idleMs: 5 * MINUTE });
  await r.get("7d");
  for (let i = 0; i < 30; i++) {
    f.advance(4 * MINUTE);
    await r.get("7d");
    await r.tick();
  }
  assert.deepEqual(Object.keys(r.debug().ranges), ["7d"]);
});
