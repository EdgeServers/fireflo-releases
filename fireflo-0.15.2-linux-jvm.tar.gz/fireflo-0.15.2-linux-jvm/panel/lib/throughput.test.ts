import { test } from "node:test";
import assert from "node:assert/strict";
import {
  ceilingSummary, ceilingText, formatShare, historySeries, isUnknownFieldError, listenerName, normaliseThroughput,
  readAccountThroughput, shareText, sourceChipText, sourceWords, type GqlExecutor,
} from "./throughput.ts";

test("the source chip names the setting: override, listener default, all listeners, login, unlimited", () => {
  assert.equal(sourceChipText({ source: "ACCOUNT_OVERRIDE", key: "conf.maxRate.YK201", tier: "LISTENER" }), "account override conf.maxRate.YK201");
  assert.equal(sourceChipText({ source: "LISTENER_DEFAULT", key: "conf.maxRate.default", tier: "LISTENER" }), "listener default conf.maxRate.default");
  assert.equal(
    sourceChipText({ source: "LISTENER_DEFAULT", key: "outSms.default.conf.maxRate.default", tier: "GATEWAY" }),
    "all listeners outSms.default.conf.maxRate.default (gateway-wide)"
  );
  assert.equal(
    sourceChipText({ source: "ACCOUNT_OVERRIDE", key: "outSms.default.conf.maxRate.YK201", tier: "GATEWAY" }),
    "account override outSms.default.conf.maxRate.YK201 (all listeners)",
    "an account's key written gateway-wide is still that account's override"
  );
  assert.equal(sourceChipText({ source: "LOGIN_MAX_TPS", key: "app_credential.max_tps", tier: null }), "login (dedicated) max_tps", "0.15.2: a login's TPS is its dedicated rate");
  assert.equal(sourceChipText({ source: "UNLIMITED", key: null, tier: null }), "unlimited");
  assert.equal(sourceChipText({ source: "LISTENER_DEFAULT", key: "conf.maxRate.default", tier: "CODED" }), "listener default conf.maxRate.default (coded default)");
});

test("HTTP's default is every account's, not a listener's", () => {
  assert.equal(
    sourceChipText({ source: "LISTENER_DEFAULT", key: "smsg.restapi.maxRate.default", tier: "GATEWAY" }, "http"),
    "all accounts smsg.restapi.maxRate.default (gateway-wide)"
  );
  assert.equal(
    sourceChipText({ source: "ACCOUNT_OVERRIDE", key: "smsg.restapi.maxRate.YK201", tier: "GATEWAY" }, "http"),
    "account override smsg.restapi.maxRate.YK201"
  );
});

test("configured × share = effective, and the ceiling it reads as", () => {
  assert.equal(shareText({ configured: 600, share: 0.5, effective: 300 }), "600 × 0.5 = 300");
  assert.equal(shareText({ configured: 200, share: 1, effective: 200 }), "200 × 1 = 200");
  assert.equal(shareText({ configured: 500, share: 1 / 3, effective: 166.6666 }), "500 × 0.33 = 166.67");
  assert.equal(shareText({ configured: 1, share: 0.5, effective: 1 }), "1 × 0.5 = 1", "the gateway's floor of 1/s is shown as it enforces it");
  assert.equal(shareText({ configured: null, share: 1, effective: null }), null, "unlimited has nothing to multiply");
  assert.equal(formatShare(0.25), "0.25");
  assert.equal(ceilingText({ configured: 600, effective: 300 }), "≤300/s");
  assert.equal(ceilingText({ configured: null, effective: null }), null);
  assert.equal(listenerName("smppserver.dltsmpp"), "dltsmpp");
  assert.equal(listenerName("dltsmpp"), "dltsmpp");
});

test("the answer is normalised: Long strings to numbers, unknown enums to unlimited, absent history kept null", () => {
  const t = normaliseThroughput({
    account: "load", node: "n1", nodes: 2, windowSeconds: 5,
    listeners: [{
      listener: "smppserver.smpp", port: 22775,
      ceiling: { source: "ACCOUNT_OVERRIDE", key: "conf.maxRate.load", rawValue: "250", tier: "LISTENER", configured: 250, share: 0.5, effective: 125,
        ignored: [{ key: "conf.maxRate.default", raw: "abc", why: "not a number" }] },
      bindLimit: { key: "conf.maxConnectionsPerUser.default", value: 4, source: "LISTENER_DEFAULT", tier: "LISTENER" },
      binds: 2, tpsMeasured: 120.5,
      throttled: { lastMinute: "12", last5Minutes: "40", lastHour: "400", sinceStart: "9000", lastAt: null, byAccountLimit: "390", byLoginLimit: "10" },
      logins: [{ systemId: "loadgen", sessions: 2, ceiling: { source: "WHAT", share: 1, ignored: [] }, binding: "ACCOUNT_OVERRIDE", tpsMeasured: null, throttled: {} }],
    }],
    http: { ceiling: { source: "UNLIMITED", share: 1, ignored: [] }, rateLimitedLastHour: null },
  });
  assert.ok(t);
  assert.equal(t.listeners[0].throttled.lastHour, 400);
  assert.equal(t.listeners[0].ceiling.ignored[0].why, "not a number");
  assert.equal(t.listeners[0].logins[0].ceiling.source, "UNLIMITED");
  assert.equal(t.listeners[0].logins[0].throttled.sinceStart, 0);
  assert.equal(t.history, null);
  assert.equal(normaliseThroughput(null), null);
});

test("the throttle history fills the quiet minutes with zero, oldest first", () => {
  const now = Date.parse("2026-10-30T10:05:30Z");
  const series = historySeries([
    { minute: "2026-10-30T10:03:00Z", byAccountLimit: 5, byLoginLimit: 1 },
    { minute: "2026-10-30T10:05:00Z", byAccountLimit: 2, byLoginLimit: 0 },
  ], 5, now);
  assert.deepEqual(series, [0, 0, 6, 0, 2]);
  assert.equal(historySeries(null, 60, now), null);
});

function gateway(api: Record<string, boolean>, answer: "ok" | "unknown-field" | "down" = "ok") {
  const asked: string[] = [];
  const exec: GqlExecutor = async <T,>(call: { query: string; variables?: Record<string, unknown> }) => {
    asked.push(call.query);
    if (call.query === "H") {
      return { ok: true as const, data: { api } as T };
    }
    if (answer === "unknown-field") {
      return { ok: false as const, status: 502, code: "ValidationError", error: "Validation error (FieldUndefined@[accountThroughput]) : Field 'accountThroughput' in type 'Query' is undefined" };
    }
    if (answer === "down") {
      return { ok: false as const, status: 502, code: "UNREACHABLE", error: "Could not reach the gateway" };
    }
    return { ok: true as const, data: { account: call.variables?.account, node: "n", nodes: 1, listeners: [], http: { ceiling: { source: "UNLIMITED", share: 1, ignored: [] } }, history: [] } as T };
  };
  return { exec, asked };
}

const docs = { health: "H", throughput: "T" };
const has = (h: unknown) => (h as { api: Record<string, boolean> }).api.account_throughput === true;

test("an older gateway is told apart and never asked; one whose schema refuses the field reads the same", async () => {
  const old = gateway({ vendor_backlog: true });
  assert.deepEqual(await readAccountThroughput(old.exec, "A", docs, has), { ok: true, body: { data: null, unsupported: true } });
  assert.deepEqual(old.asked, ["H"]);
  const odd = gateway({ account_throughput: true }, "unknown-field");
  assert.deepEqual(await readAccountThroughput(odd.exec, "A", docs, has), { ok: true, body: { data: null, unsupported: true } });
  const down = gateway({ account_throughput: true }, "down");
  const read = await readAccountThroughput(down.exec, "A", docs, has);
  assert.equal(read.ok, false, "a gateway that stopped answering is an error, not an old gateway");
  const now = gateway({ account_throughput: true });
  const fresh = await readAccountThroughput(now.exec, "YK201", docs, has);
  assert.ok(fresh.ok && fresh.body.data);
  if (fresh.ok && fresh.body.data) {
    assert.equal(fresh.body.data.account, "YK201");
  }
});

test("an unknown-field refusal is recognised by its sentence whatever the code", () => {
  assert.ok(isUnknownFieldError({ code: "INTERNAL", error: "Field 'loginTpsLimit' in type 'Session' is undefined" }));
  assert.ok(isUnknownFieldError({ code: "GRAPHQL_VALIDATION_FAILED", error: "Validation error (FieldUndefined@[sessions/rows/limitSource])" }));
  assert.ok(!isUnknownFieldError({ code: "UNREACHABLE", error: "Could not reach the gateway: timeout" }));
});

test("0.15.2: the port share names the listener's tps and how many share it; a login's TPS reads dedicated", () => {
  assert.equal(
    sourceChipText({ source: "PORT_SHARE", key: null, tier: null, portLimit: 1000, activeAccounts: 5 }),
    "port share tps (1,000 ÷ 5 active)",
  );
  assert.equal(sourceChipText({ source: "PORT_SHARE", key: null, tier: null }), "port share tps", "an older answer without the figures");
  assert.equal(sourceChipText({ source: "LOGIN_MAX_TPS", key: "app_credential.max_tps", tier: null }), "login (dedicated) max_tps");
});

/** A gateway answer for the ceiling card, built through the normaliser like the route's. */
function answer(listeners: unknown[]) {
  const t = normaliseThroughput({ account: "fireflo", node: "n1", nodes: 1, windowSeconds: 5, listeners, http: {}, history: null });
  assert.ok(t);
  return t;
}

const ceiling = (source: string, configured: number | null, extra: Record<string, unknown> = {}) =>
  ({ source, configured, effective: configured, share: 1, ignored: [], ...extra });

test("ceiling card: one listener, where it is active now, busiest first; the rest are counted", () => {
  const s = ceilingSummary(answer([
    { listener: "smppserver.smpp2", port: 22776, binds: 1, tpsMeasured: 0, ceiling: ceiling("UNLIMITED", null), logins: [] },
    { listener: "smppserver.smpp", port: 22775, binds: 2, tpsMeasured: 78.4, portLimit: 240, activeAccounts: 3,
      ceiling: ceiling("PORT_SHARE", 80, { portLimit: 240, activeAccounts: 3 }), logins: [] },
    { listener: "smppserver.idle", port: 22777, binds: 0, tpsMeasured: null, ceiling: ceiling("LISTENER_DEFAULT", 100), logins: [] },
  ]));
  assert.ok(s.active);
  assert.equal(s.idle, false);
  assert.equal(s.active.name, "smpp", "the busiest by measured TPS");
  assert.equal(s.active.note, "240 ÷ 3 active · now 78.4/s · 2 binds");
  assert.equal(s.active.usage, 78.4 / 80);
  assert.equal(ceilingText(s.active.ceiling), "≤80/s");
  assert.equal(s.others, 2, "every other listener, bound or not");
  assert.equal(s.throttledLastMinute, 0);
});

test("ceiling card: a tie on TPS goes to the listener with more binds; sessions count as binds", () => {
  const s = ceilingSummary(answer([
    { listener: "smppserver.a", port: 1, binds: 1, tpsMeasured: null, ceiling: ceiling("UNLIMITED", null), logins: [] },
    { listener: "smppserver.b", port: 2, binds: 0, tpsMeasured: null, ceiling: ceiling("UNLIMITED", null),
      logins: [{ systemId: "x", sessions: 3, ceiling: ceiling("ACCOUNT_OVERRIDE", 10), binding: "ACCOUNT_OVERRIDE", tpsMeasured: null, throttled: {} }] },
  ]));
  assert.equal(s.active?.name, "b");
  assert.equal(s.active?.note, "nothing set · no traffic · 3 binds");
  assert.equal(s.active?.usage, null, "no meter for unlimited");
  assert.equal(s.others, 1);
});

test("ceiling card: an account override sits outside the split; a login with its own TPS is listed once", () => {
  const login = (systemId: string, source: string, tps: number | null, measured: number | null) =>
    ({ systemId, sessions: 1, ceiling: ceiling(source, tps), binding: source, tpsMeasured: measured, throttled: {} });
  const s = ceilingSummary(answer([
    { listener: "smppserver.smpp", port: 22775, binds: 3, tpsMeasured: 112,
      ceiling: ceiling("ACCOUNT_OVERRIDE", 200, { key: "conf.maxRate.fireflo", tier: "LISTENER" }),
      logins: [login("tlvtest", "LOGIN_MAX_TPS", 40, 30), login("bulk", "ACCOUNT_OVERRIDE", 200, 72)] },
    { listener: "smppserver.smpp2", port: 22776, binds: 1, tpsMeasured: 9.8,
      ceiling: ceiling("ACCOUNT_OVERRIDE", 200), logins: [login("tlvtest", "LOGIN_MAX_TPS", 40, 9.8)] },
  ]));
  assert.equal(s.active?.note, "outside the split · now 112/s · 3 binds");
  assert.deepEqual(s.logins, [{ systemId: "tlvtest", ceiling: 40, measured: 39.8 }], "dedicated logins from every listener");
  assert.ok(s.active);
  assert.equal(sourceWords({ ceiling: s.active.ceiling, portLimit: null, activeAccounts: null }), "account override");
});

test("ceiling card: bound nowhere, it shows the first listener as where it would bind", () => {
  const s = ceilingSummary(answer([
    { listener: "smppserver.a", port: 1, binds: 0, tpsMeasured: null, ceiling: ceiling("LISTENER_DEFAULT", 100), logins: [] },
    { listener: "smppserver.b", port: 2, binds: 0, tpsMeasured: null, ceiling: ceiling("UNLIMITED", null), logins: [] },
    { listener: "smppserver.c", port: 3, binds: 0, tpsMeasured: null, ceiling: ceiling("UNLIMITED", null), logins: [] },
  ]));
  assert.equal(s.idle, true);
  assert.equal(s.active?.name, "a");
  assert.equal(s.active?.note, "shared with the other active accounts");
  assert.equal(s.active?.usage, null, "no meter without traffic");
  assert.equal(s.others, 2);
});

test("ceiling card: bound nowhere, the listener it last used wins when a refusal dates it", () => {
  const s = ceilingSummary(answer([
    { listener: "smppserver.a", port: 1, binds: 0, tpsMeasured: null, ceiling: ceiling("UNLIMITED", null),
      throttled: { lastAt: "2026-10-30T10:00:00Z" }, logins: [] },
    { listener: "smppserver.b", port: 2, binds: 0, tpsMeasured: null, ceiling: ceiling("ACCOUNT_OVERRIDE", 50),
      throttled: { lastAt: "2026-10-31T09:00:00Z" }, logins: [] },
  ]));
  assert.equal(s.idle, true);
  assert.equal(s.active?.name, "b");
  assert.equal(s.active?.note, "outside the split", "an override is not shared");
  assert.equal(s.others, 1);
});

test("ceiling card: no SMPP listener at all", () => {
  const s = ceilingSummary(answer([]));
  assert.equal(s.active, null);
  assert.equal(s.others, 0);
});

test("ceiling card: refusals in the last minute are summed, and a rate at the ceiling says so", () => {
  const s = ceilingSummary(answer([
    { listener: "smppserver.smpp", port: 22775, binds: 2, tpsMeasured: 100,
      ceiling: ceiling("LISTENER_DEFAULT", 100, { key: "conf.maxRate.default", tier: "LISTENER" }),
      throttled: { lastMinute: "1200" }, logins: [] },
    { listener: "smppserver.smpp2", port: 22776, binds: 1, tpsMeasured: 50,
      ceiling: ceiling("LISTENER_DEFAULT", 50, { configured: 100, share: 0.5 }), throttled: { lastMinute: 298 }, logins: [] },
  ]));
  assert.equal(s.throttledLastMinute, 1498);
  assert.equal(s.active?.note, "now 100/s, at the ceiling · 2 binds");
  assert.equal(s.active?.usage, 1);
});

test("ceiling card: a cluster shows its share", () => {
  const s = ceilingSummary(answer([
    { listener: "smppserver.smpp2", port: 22776, binds: 1, tpsMeasured: 50,
      ceiling: ceiling("LISTENER_DEFAULT", 50, { configured: 100, share: 0.5 }), logins: [] },
  ]));
  assert.equal(s.active?.note, "100 × 0.5 = 50 · now 50/s, at the ceiling · 1 bind");
});
