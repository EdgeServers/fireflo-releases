import type { CdrRow, CustomerEvent, MessageReceipt } from "./cdr-request.ts";
import { dlrStateLabel } from "./labels.ts";
import { ingressEncoding, receiptOutEncoding, type IngressFields, type LegEncoding } from "./encoding.ts";

/**
 * The exchange between a customer and this gateway, as one ordered sequence.
 *
 * <p>The sibling of `smpp-exchange.ts`, which does the same for the **vendor** leg. Both are built
 * from call records rather than captured bytes — the vendor card says so on screen, and this one
 * says it too. Capturing real PDUs per message would mean persisting message content and
 * destination numbers for every message, which is a retention decision rather than a feature; the
 * gateway's capture service is deliberately in-memory and 15-minute for exactly that reason.
 *
 * <p><strong>Everything here is already stored</strong>, which is why it works on messages sent
 * before the feature existed:
 *
 * <ul>
 *   <li>the customer's `submit_sm` — `cdr_submit`'s ingress, listener, TLVs as received,
 *       `registered_delivery` and addresses, at `accepted_at`;</li>
 *   <li>our `submit_sm_resp` — the id we returned is the message's own `gateway_msg_id`, at the
 *       same moment;</li>
 *   <li>our `deliver_sm` — a `cdr_event` receipt row, or the reason there was none;</li>
 *   <li>the callback — a `cdr_event` callback attempt, for a message that arrived over REST.</li>
 * </ul>
 *
 * <p>A REST message has no `submit_sm`, so its first two events are named for what actually
 * happened rather than dressed in SMPP clothes. Calling an HTTP POST a `submit_sm` would be a
 * readable lie on the one screen an operator opens to find out what really occurred.
 */

export type CustomerPdu =
  | "submit_sm"
  | "submit_sm_resp"
  | "deliver_sm"
  | "http_request"
  | "http_response"
  | "callback";

export interface CustomerExchangeEvent {
  pdu: CustomerPdu;
  at: string;
  /** Which way it went. `in` is customer → gateway. */
  direction: "in" | "out";
  /** What the event says: a status, a reason, or null when there is nothing to add. */
  detail: string | null;
  status: number | null;
  /** Redacted by the gateway before storage. Callbacks only. */
  endpoint: string | null;
  /**
   * Which try this was, from 1, and how long it took. Callbacks only; null elsewhere.
   *
   * <p>Carried rather than summarised because the sequence is the answer: "it eventually worked, on
   * the fourth try, after two timeouts" is a shape no single row can hold, and the retry interval
   * defaults to two minutes, so four rows can span most of an hour.
   */
  attempt: number | null;
  durationMs: number | null;
  /**
   * What the endpoint answered, on the terms `CustomerEvent.responseExcerpt` documents.
   *
   * <p>Passed through with its three-valued distinction intact — `undefined`, `null` and the empty
   * string each mean something different — because collapsing them is what turns a diagnostic into
   * a guess. The view renders three different sentences for them.
   */
  responseExcerpt?: string | null;
  responseHeaders?: string | null;
  /**
   * The receipt **as the customer received it**, which is not the vendor's receipt forwarded.
   *
   * <p>`GatewayReceipt.forState` rebuilds it, and every field here differs from the vendor row on
   * the card above: the addresses are reversed because a receipt travels back the way the message
   * came, the id is ours rather than the carrier's, and the verdict is re-rendered — a vendor
   * `FAILED` and a vendor `UNDELIV` both reach the customer as `UNDELIV`. Showing the vendor's
   * values here would be a readable lie on the one screen opened to find out what really happened.
   *
   * <p>Derived from `cdr_final`/`cdr_interim`, which are billing records and always written, so this
   * renders on messages sent long before `cdr_event` existed and needs no diagnostic level.
   */
  receipt?: {
    /** Reversed: the message's destination is the receipt's source. */
    from: string | null;
    to: string | null;
    /** Ours — `gateway_msg_id` — not the carrier's `operator_msg_id`. */
    messageId: string;
    /** Re-rendered through the gateway's own state mapping, not the carrier's word. */
    stat: string;
    /** What we told the customer. */
    err: string | null;
    /** What the carrier told us, when the schema records it. `undefined` means never asked. */
    vendorErr?: string | null;
    /** True for `cdr_final`, false for a progress receipt out of `cdr_interim`. */
    terminal: boolean;
  };
  /**
   * Whether it reached the wire — and `unrecorded` is a real answer, not a missing one.
   *
   * <p>The receipt's CONTENT is always known; whether it was actually sent is a `cdr_event`, which
   * `smsg.cdr.events` gates. Absent a row we say so rather than implying delivery: reading silence
   * as success is the same mistake as reading the Refused list's "Sent on: Yes" — which means the
   * customer ASKED for a receipt — as evidence one was sent.
   */
  delivery?: "sent" | "not-sent" | "unrecorded";
  /**
   * What crossed the wire on this leg: the coding the customer's `submit_sm` (or HTTP request)
   * arrived in, or the receipt `deliver_sm` we sent back -- always GSM-7, dcs 0. Absent on our
   * responses and on callbacks, which carry no message text.
   */
  encoding?: LegEncoding;
}

/** Receipt kinds, in the order `cdr_event` names them. */
const RECEIPT_SENT = "receipt.sent";
const RECEIPT_FAILED = "receipt.failed";
const RECEIPT_HELD = "receipt.held";
const RECEIPT_SUPPRESSED = "receipt.suppressed";
const CALLBACK = "callback.attempt";

/**
 * Said when the receipt was rendered but nothing recorded whether it reached the wire.
 *
 * <p>Deliberately not silence. `smsg.cdr.events` gates the row that would say so, and its
 * `problems` mode records nothing when nothing goes wrong -- so an absent row is USUALLY a receipt
 * that went out normally. Usually is not a fact, and this card must not present it as one.
 */
const UNRECORDED = "whether it reached the wire is not recorded at this level";

/**
 * Build the sequence.
 *
 * @param first the message's first `cdr_submit` row — the acceptance, not a vendor attempt
 * @param events every `cdr_event` for the message, in the order the query returned them
 */
export function buildCustomerExchange(
  first: (Pick<CdrRow, "gatewayMsgId" | "acceptedAt" | "submittedAt" | "ingress" | "inGateway"
    | "sourceAddr" | "destAddr"> & Partial<IngressFields>) | null,
  events: readonly CustomerEvent[],
  receipts: readonly MessageReceipt[] = []
): CustomerExchangeEvent[] {
  const out: CustomerExchangeEvent[] = [];

  if (first) {
    //accepted_at is when we said yes. It is not submitted_at, which is when the VENDOR was told --
    //conflating them is how a page reports a delivery latency of zero
    const at = first.acceptedAt ?? first.submittedAt;
    const overHttp = (first.ingress ?? "").toLowerCase().includes("http");
    out.push({
      pdu: overHttp ? "http_request" : "submit_sm",
      at,
      direction: "in",
      detail: first.inGateway ? `on ${first.inGateway}` : null,
      status: null,
      endpoint: null,
      attempt: null,
      durationMs: null,
      //`dcs` has always been recorded, so this cell has something to say on any gateway
      encoding: ingressEncoding({ ...first, dcs: first.dcs ?? null }),
    });
    out.push({
      pdu: overHttp ? "http_response" : "submit_sm_resp",
      at,
      direction: "out",
      //the id we handed back is what the customer quotes in every support conversation afterwards
      detail: first.gatewayMsgId,
      status: null,
      endpoint: null,
      attempt: null,
      durationMs: null,
    });
  }

  //callbacks stand alone: they describe the REST leg and pair with no receipt
  for (const e of events) {
    if (e.kind === CALLBACK) {
      out.push({
        pdu: "callback", at: e.at, direction: "out",
        detail: e.detail, status: e.status, endpoint: e.endpoint,
        attempt: e.attempt, durationMs: e.durationMs,
        responseExcerpt: e.responseExcerpt, responseHeaders: e.responseHeaders,
      });
    }
  }

  //the receipt events, oldest first, so each can LABEL the deliver_sm it describes rather than
  //being a row of its own. The content comes from the receipt; the event says whether it went
  const statusEvents = events
    .filter((e) => e.kind === RECEIPT_SENT || e.kind === RECEIPT_FAILED
      || e.kind === RECEIPT_HELD || e.kind === RECEIPT_SUPPRESSED)
    .slice()
    .sort((a, b) => a.at.localeCompare(b.at));

  const ordered = receipts.slice().sort((a, b) => a.receivedAt.localeCompare(b.receivedAt));

  ordered.forEach((r, i) => {
    const e = statusEvents[i];
    //`forwarded === false` is the gateway saying it never sent this one, and it knows that without
    //any event being recorded -- so it decides before the event does
    const withheld = r.forwarded === false;
    const delivery: "sent" | "not-sent" | "unrecorded" =
      withheld ? "not-sent"
        : e === undefined ? "unrecorded"
          : e.kind === RECEIPT_SENT ? "sent" : "not-sent";

    out.push({
      pdu: "deliver_sm",
      at: r.receivedAt,
      direction: "out",
      detail: delivery === "not-sent"
        ? `${withheld && !e ? reasonFor(RECEIPT_SUPPRESSED) : reasonFor(e?.kind ?? "")}${e?.detail ? ` — ${e.detail}` : ""}`
        : delivery === "unrecorded" ? UNRECORDED : null,
      status: e?.status ?? null,
      endpoint: null,
      attempt: null,
      durationMs: null,
      receipt: {
        //reversed, because a receipt travels back the way the message came -- GatewayReceipt.forState
        from: first?.destAddr ?? null,
        to: first?.sourceAddr ?? null,
        messageId: r.id,
        stat: dlrStateLabel(r.dlrState),
        err: r.errCode,
        vendorErr: r.vendorErrCode,
        terminal: r.kind === "outcome",
      },
      delivery,
      encoding: receiptOutEncoding(r.kind === "outcome"),
    });
  });

  //an event with no receipt to attach to: the message has not resolved yet, or events outnumber
  //receipts. Kept as a bare row rather than dropped -- losing it would hide the very absence this
  //card exists to show
  for (const e of statusEvents.slice(ordered.length)) {
    out.push({
      pdu: "deliver_sm", at: e.at, direction: "out",
      detail: e.kind === RECEIPT_SENT
        ? null
        : `${reasonFor(e.kind)}${e.detail ? ` — ${e.detail}` : ""}`,
      status: e.status, endpoint: null, attempt: null, durationMs: null,
      delivery: e.kind === RECEIPT_SENT ? "sent" : "not-sent",
      encoding: receiptOutEncoding(undefined),
    });
  }

  //by time, then by the order they were produced, so two events sharing a millisecond keep the
  //sequence they happened in rather than being reordered by a tie-break that means nothing
  return out
    .map((e, i) => ({ e, i }))
    .sort((a, b) => a.e.at.localeCompare(b.e.at) || a.i - b.i)
    .map(({ e }) => e);
}

function reasonFor(kind: string): string {
  switch (kind) {
    case RECEIPT_FAILED:
      return "not sent — the deliver_sm could not be put on the wire";
    case RECEIPT_HELD:
      return "not sent — held until this system id binds again";
    case RECEIPT_SUPPRESSED:
      return "not sent — the customer did not ask about this outcome";
    default:
      return "not sent";
  }
}
