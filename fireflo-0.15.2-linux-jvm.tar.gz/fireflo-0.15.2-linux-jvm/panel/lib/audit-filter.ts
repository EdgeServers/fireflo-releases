import type { AuditFilter } from "@/lib/audit-log";

/**
 * The query string both audit routes accept, read the same way on both.
 *
 * <p>Its own module because a `route.ts` may export only HTTP handlers, and because the page sends
 * the same parameters to `/audit/operator` and `/audit/portal`.
 */
export function parseAuditFilter(params: URLSearchParams): AuditFilter {
  const date = (s: string | null) => {
    if (!s) return null;
    const d = new Date(s);
    return Number.isNaN(d.getTime()) ? null : d;
  };
  const dayOrInstant = (key: "from" | "to", s: string | null): Partial<AuditFilter> => {
    if (s && /^\d{4}-\d{2}-\d{2}$/.test(s)) {
      return key === "from" ? { fromDay: s } : { toDay: s };
    }
    return { [key]: date(s) };
  };
  const before = params.get("before");
  let cursor: AuditFilter["before"] = null;
  if (before) {
    const at = before.lastIndexOf(",");
    const id = Number(before.slice(at + 1));
    if (at > 0 && Number.isInteger(id)) {
      cursor = { occurredAt: before.slice(0, at), id };
    }
  }
  const user = Number(params.get("user"));
  return {
    userId: Number.isInteger(user) && user > 0 ? user : null,
    accountId: params.get("account"),
    event: params.get("event"),
    actor: params.get("actor"),
    failuresOnly: params.get("failures") === "1",
    //a day picker sends YYYY-MM-DD, a billing day; an instant (an older page, a script) is kept as one
    ...dayOrInstant("from", params.get("from")),
    ...dayOrInstant("to", params.get("to")),
    before: cursor,
    limit: Number(params.get("limit")) || undefined,
  };
}
