/**
 * The shape of a `config_changed` access-log event, and the redaction that keeps it safe to keep.
 *
 * <h2>Why one event for every configuration write</h2>
 *
 * <p>Until this existed the operator log named a handful of writes -- gateway settings, routing
 * recreated, accounts, users -- and forty-odd other mutating routes left nothing behind but an
 * `updated_at`. An operator could change a vendor's password or divert a routing table and the
 * question "who, and from where" had no answer. Giving each of those its own event name would have
 * meant a migration per feature (the `event` column is CHECK-constrained, see V1.82.0) and a new
 * place to forget. One event with a structured detail -- which domain, which object, what was done,
 * a small before and after -- covers all of them, and `lib/config-audit-coverage.test.ts` fails the
 * build when a mutating route is added without it.
 *
 * <h2>What the detail may hold</h2>
 *
 * <p>Never a secret. `before` and `after` are summaries, not rows: a credential's password or API key
 * appears only as `has_password` / `has_api_key`, and any key that looks like a secret anywhere in
 * the summary is replaced the same way by {@link redactSummary}, whichever caller forgot. Long
 * strings are clipped and the whole pair is capped at {@link MAX_SUMMARY_CHARS}, because the file
 * log drops a detail that would push a line over its atomic-append limit, and a dropped detail is
 * worse than a shortened one.
 *
 * <p>This module is pure so the redaction can be unit tested without a database; the emitting half
 * is `lib/config-audit.ts`.
 */

/** What kind of thing changed. One token per editor, used by the Access log's filter and search. */
export type ConfigDomain =
  | "credential"
  | "routing_table"
  | "route_group"
  | "worker"
  | "filter"
  | "tlv"
  | "product"
  | "rate_scope"
  | "whitelist_policy"
  | "header"
  | "template"
  | "balance"
  | "statement"
  | "reload"
  | "session"
  | "bind_hold"
  | "export"
  | "preprocessor"
  | "account"
  | "watch"
  | "tps_peak"
  /** A queue clean: archived and ended from the gateway's queues (`action:archive`). */
  | "queue"
  /** Delivery receipts re-sent to an SMPP login for a period (`action:repush`, `action:repush-cancel`). */
  | "receipt_repush"
  /**
   * An address blocked in fail2ban from the panel (`action:ban`; the name is the address). The one
   * change that reaches the HOST rather than the gateway or the database. `after.source` says
   * whether an operator pressed the button or a rule fired (`rule:<id>`). Its own event name would
   * be a migration (the column is CHECK-constrained), so it rides on `config_changed` like the rest.
   */
  | "fail2ban"
  /** The ban rules replaced as a set (`update`; the name is `rules`). */
  | "ban_rule"
  /** The slow query log cleared (`delete`; the name is `ring`): evidence forgotten, like a TPS peak. */
  | "slow_queries"
  /**
   * One internal part of the gateway restarted from the Queues page (`action:restart`; the name is
   * the part, with the vendor or stream after it: `persist`, `vendor optus`). Nothing stored
   * changes, but it is a control the gateway applied, like a worker restart.
   */
  | "component";

/**
 * What was done to it.
 *
 * <p>`action:<verb>` is for the gateway-side controls that are neither a row write nor a delete:
 * a worker's suspend/resume/hold/release/restart, a reload, a disconnect, a whitelist review.
 */
export type ConfigAction =
  | "create"
  | "update"
  | "delete"
  | "enable"
  | "disable"
  | "reorder"
  | "topup"
  | "transfer"
  | "close"
  | "request"
  | `action:${string}`;

/** A small, flat-ish description of an object's state. Values are whatever JSON holds. */
export type ConfigSummary = Record<string, unknown>;

export interface ConfigChange {
  domain: ConfigDomain;
  /** The object's own name or id: a system ID, a table name, an account id, a scope. */
  name: string;
  action: ConfigAction;
  before?: ConfigSummary | null;
  after?: ConfigSummary | null;
  /**
   * The account this change belongs to, when it has one. Goes on the detail's top level as
   * `account`, which is the key `lib/account-activity.ts` joins on, so a top-up or a login change
   * shows in that account's activity history as well as in the Access log.
   */
  account?: string | null;
}

/** The whole of `before` plus `after`, serialised. Past this they are reduced to their keys. */
export const MAX_SUMMARY_CHARS = 2048;

/** One string inside a summary. A routing rule's label, a note, a TLV list -- never a whole file. */
const MAX_STRING = 160;

/** One list inside a summary: rule targets, members, allowed IPs. */
const MAX_LIST = 40;

/** How deep a summary may nest before the rest is replaced by a marker. */
const MAX_DEPTH = 3;

/**
 * Any key that names a secret. Over-matching is the safe direction: a value that is dropped from
 * the audit log is a smaller loss than a vendor password kept in it forever.
 */
const SECRET_KEY = /password|passwd|secret|api[_-]?key|apikey|token/i;

/**
 * The event detail for one change: the identifying fields first, then the redacted, capped
 * summaries, then which top-level keys differ between them.
 */
export function configChangeDetail(change: ConfigChange): Record<string, unknown> {
  const detail: Record<string, unknown> = {
    domain: change.domain,
    name: clipString(change.name),
    action: change.action,
  };
  if (change.account) {
    detail.account = clipString(change.account);
  }
  let before = change.before ? redactSummary(change.before) : null;
  let after = change.after ? redactSummary(change.after) : null;
  const changed = before && after ? changedKeys(before, after) : [];

  if (serialisedLength(before, after) > MAX_SUMMARY_CHARS) {
    //the keys alone still say what kind of thing was there; `changed` below still says which moved
    before = before ? truncated(before) : null;
    after = after ? truncated(after) : null;
  }
  if (before) detail.before = before;
  if (after) detail.after = after;
  if (changed.length) detail.changed = changed;
  return detail;
}

/**
 * A copy with every secret-looking key replaced by `has_<key>: boolean`, strings clipped, lists
 * shortened and depth bounded. Idempotent: a `has_password` key is left alone.
 */
export function redactSummary(summary: ConfigSummary, depth = 0): ConfigSummary {
  const out: ConfigSummary = {};
  for (const [key, value] of Object.entries(summary)) {
    if (value === undefined) {
      continue;
    }
    if (!key.startsWith("has_") && SECRET_KEY.test(key)) {
      out[`has_${key}`] = present(value);
      continue;
    }
    out[key] = redactValue(value, depth + 1);
  }
  return out;
}

function redactValue(value: unknown, depth: number): unknown {
  if (value === null || typeof value === "boolean" || typeof value === "number") {
    return value;
  }
  if (typeof value === "string") {
    return clipString(value);
  }
  if (value instanceof Date) {
    return value.toISOString();
  }
  if (Array.isArray(value)) {
    const head = value.slice(0, MAX_LIST).map((v) => (depth >= MAX_DEPTH ? "…" : redactValue(v, depth + 1)));
    if (value.length > MAX_LIST) {
      head.push(`…(+${value.length - MAX_LIST} more)`);
    }
    return head;
  }
  if (typeof value === "object") {
    return depth >= MAX_DEPTH ? "…" : redactSummary(value as ConfigSummary, depth);
  }
  //a function or a symbol has no place in an audit line
  return String(value);
}

/** True when a secret is set to something, however that is represented. */
function present(value: unknown): boolean {
  if (value === null || value === undefined || value === false) return false;
  if (typeof value === "string") return value.length > 0;
  if (typeof value === "object" && "state" in (value as object)) {
    //a `SecretField`: `unset` means none, `kept` and `set` both mean there is one
    return (value as { state?: unknown }).state !== "unset";
  }
  return true;
}

/** Top-level keys whose serialised value differs. Order follows `after`, then keys only in `before`. */
export function changedKeys(before: ConfigSummary, after: ConfigSummary): string[] {
  const keys = [...Object.keys(after), ...Object.keys(before).filter((k) => !(k in after))];
  return keys.filter((k) => JSON.stringify(before[k] ?? null) !== JSON.stringify(after[k] ?? null));
}

function serialisedLength(before: ConfigSummary | null, after: ConfigSummary | null): number {
  return (before ? JSON.stringify(before).length : 0) + (after ? JSON.stringify(after).length : 0);
}

function truncated(summary: ConfigSummary): ConfigSummary {
  return { truncated: true, keys: Object.keys(summary).slice(0, MAX_LIST) };
}

function clipString(value: string): string {
  return value.length > MAX_STRING ? `${value.slice(0, MAX_STRING - 1)}…` : value;
}
