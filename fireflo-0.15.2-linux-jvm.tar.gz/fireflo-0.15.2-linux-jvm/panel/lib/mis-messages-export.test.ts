import { test } from "node:test";
import assert from "node:assert/strict";
import type { CdrRow } from "./cdr-request";
import { exportCell, exportColumns, exportHeader, exportRow } from "./mis-messages-export.ts";

/**
 * The customer CSV.
 *
 * <p>The first two tests are the ones that matter. A CSV is the most damaging place for either of
 * these to be wrong: it leaves the panel, it is kept, and it is forwarded — so a leak here outlives
 * the session it came from, and a wrong number here is reconciled against.
 */

const ids = (raw: string | null) => exportColumns(raw).map((c) => c.id);

const row = (over: Partial<CdrRow> = {}): CdrRow => ({
  id: "1",
  gatewayMsgId: "a3f9c1d2",
  partNo: 1,
  partCount: 1,
  retryCount: 0,
  submittedAt: "2026-08-15T09:02:07.441Z",
  acceptedAt: null,
  accountId: "acme-in",
  systemId: null,
  product: null,
  ingress: "smpp",
  inGateway: null,
  vendor: "vendor1",
  sourceAddr: "ACMEIN",
  destAddr: "+919820011234",
  mcc: null,
  mnc: null,
  dcs: null,
  msgType: null,
  operatorMsgId: null,
  costRate: 800,
  costUnits: 1,
  cost: 800,
  priceRate: 1250,
  billedUnits: 1,
  price: 1250,
  margin: 450,
  marginPct: 36,
  marginStatus: null,
  costRuleId: null,
  priceRuleId: null,
  currency: "INR",
  finalState: "DELIVERED",
  dlrState: 2,
  errCode: null,
  finalAt: "2026-08-15T09:02:11.000Z",
  ...over,
});

test("asking for the buy side yields a file without it", () => {
  //the attack, and it is one query-string edit long: the columns parameter is not a preference, it
  //is caller input, and cost/margin/vendor are what we pay and who we pay it to
  const asked = ids("cost,costRate,costUnits,margin,marginPct,vendor,priceRuleId,costRuleId");

  for (const forbidden of ["cost", "costRate", "costUnits", "margin", "marginPct", "vendor"]) {
    assert.ok(!asked.includes(forbidden), `${forbidden} reached the file`);
  }
});

test("a request made entirely of forbidden columns falls back to the defaults, not to nothing", () => {
  //dropping them silently must not leave an empty list, which would otherwise produce a file that
  //is a single header line and reads as "you have no messages"
  const asked = ids("cost,margin,vendor");

  assert.ok(asked.length > 0);
  assert.ok(asked.includes("submittedAt"));
  assert.ok(asked.includes("destAddr"));
});

test("allowed columns are honoured, and order comes from the catalogue", () => {
  //asked out of order and with whitespace, the way a hand-edited URL arrives
  const asked = ids(" outcome , destAddr ,price");

  assert.deepEqual(asked, ["destAddr", "price", "outcome"]);
});

test("unknown and empty ids are dropped without taking the rest with them", () => {
  assert.deepEqual(ids("destAddr,,nonsense,price"), ["destAddr", "price"]);
  assert.deepEqual(ids(""), ids(null), "no parameter and an empty one mean the same thing");
});

test("money is written at four places, whatever the panel displays totals at", () => {
  const price = exportColumns("price")[0];
  const rate = exportColumns("priceRate")[0];

  //1250 scaled by 10 000 is 0.1250. The screen showed 1250 before this work; a spreadsheet summing
  //that column would have been out by four orders of magnitude
  assert.equal(exportCell(price, row()), "0.1250");
  assert.equal(exportCell(rate, row()), "0.1250");
});

test("an amount that has not settled is empty, not zero", () => {
  const price = exportColumns("price")[0];

  //0.0000 is a claim that the message was free, which is a different fact from "not yet priced"
  assert.equal(exportCell(price, row({ price: null })), "");
});

test("a message with no receipt is written as PENDING rather than left blank", () => {
  const outcome = exportColumns("outcome")[0];

  assert.equal(exportCell(outcome, row({ finalState: null })), "PENDING");
  assert.equal(exportCell(outcome, row({ finalState: "FAILED" })), "FAILED");
});

test("timestamps are the stored ISO instant, not a localised rendering", () => {
  const submitted = exportColumns("submittedAt")[0];

  //the file may be opened in another country. A localised string with no zone marker is a
  //reconciliation hazard; this sorts as text and says which clock it is on
  assert.equal(exportCell(submitted, row()), "2026-08-15T09:02:07.441Z");
});

test("a sender id that is a spreadsheet formula is neutralised", () => {
  const source = exportColumns("sourceAddr")[0];

  //a source address is whatever the sender put there, and Excel executes a leading = or +
  assert.equal(exportCell(source, row({ sourceAddr: "=1+1" })), "'=1+1");
  assert.equal(exportCell(source, row({ sourceAddr: "+919820011234" })), "'+919820011234");
});

test("a value containing a comma or a quote does not break the row", () => {
  const product = exportColumns("product")[0];

  assert.equal(exportCell(product, row({ product: 'a,b' })), '"a,b"');
  assert.equal(exportCell(product, row({ product: 'say "hi"' })), '"say ""hi"""');
});

test("the header and a row have the same number of fields", () => {
  const columns = exportColumns("submittedAt,destAddr,price,outcome");

  const header = exportHeader(columns, "Asia/Kolkata").trim().split(",");
  const line = exportRow(row(), columns, "Asia/Kolkata").trim().split(",");

  assert.equal(header.length, 5);
  assert.equal(line.length, 5);
  assert.deepEqual(header, ["Submitted (UTC)", "To", "Billed", "Outcome", "Submitted local (Asia/Kolkata)"]);
});

test("a time stays ISO UTC, with a local copy in the requester's zone on the end", () => {
  const columns = exportColumns("submittedAt,destAddr,finalAt");
  const line = exportRow(row(), columns, "Asia/Kolkata").trim().split(",");
  assert.equal(line[0], "2026-08-15T09:02:07.441Z");
  assert.deepEqual(line.slice(-2), ["2026-08-15 14:32:07", "2026-08-15 14:32:11"]);
  const blank = exportRow(row({ finalAt: null }), columns, "UTC").trim().split(",");
  assert.equal(blank.at(-1), "", "no receipt yet, no local copy");
});
