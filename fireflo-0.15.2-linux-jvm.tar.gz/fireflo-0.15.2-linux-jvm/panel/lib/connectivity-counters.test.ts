import { strict as assert } from "node:assert";
import { test } from "node:test";
import { counterTiles, nackTone, pushQueue, queueRising, queueTone, sinceText } from "./connectivity-counters.ts";
import type { LiveCountersSum } from "./gateway-live-counters.ts";

function sum(over: Partial<LiveCountersSum> = {}): LiveCountersSum {
  return {
    nodes: ["node-1"], partial: [], since: "2026-10-30T07:41:00Z",
    mt: { total: 1_234_567, ack: 1_230_000, nack: 4_567 },
    dlr: { total: 2_318_902, in: 1_160_451, out: 1_158_451 },
    db: { written: 7_389_318, queue: 12_800 },
    rates: { mtAckPerSecond: 1_828, mtNackPerSecond: 12, dlrInPerSecond: 900, dlrOutPerSecond: 890, dbWrittenPerSecond: 9_900 },
    ...over,
  };
}

test("abbreviation: in full to 99,999, then k and M, the full figure kept for the tooltip", () => {
  const [mt, dlr, db] = counterTiles(sum({ mt: { total: 0, ack: 99_999, nack: 100_000 } }), []);
  assert.equal(mt.a.text, "99,999");
  assert.equal(mt.a.full, "99,999");
  assert.equal(mt.b.text, "100k");
  assert.equal(mt.b.full, "100,000");
  assert.equal(mt.total.text, "200k");
  assert.equal(mt.total.full, "199,999");
  assert.equal(dlr.total.text, "2.32M");
  assert.equal(dlr.total.full, "2,318,902");
  assert.equal(db.a.text, "7.39M");
});

test("tiles: totals are their pairs' sums, rates summed, PostgreSQL in rows a second", () => {
  const [mt, dlr, db] = counterTiles(sum(), []);
  assert.deepEqual([mt.title, mt.a.label, mt.b.label], ["MT total", "ACK", "NACK"]);
  assert.equal(mt.total.full, "1,234,567");
  assert.equal(mt.rate, "1,840/s");
  assert.deepEqual([dlr.title, dlr.a.label, dlr.b.label], ["DLR total", "IN", "OUT"]);
  assert.equal(dlr.rate, "1,790/s");
  assert.deepEqual([db.title, db.a.label, db.b.label], ["PostgreSQL", "WRITTEN", "QUEUE"]);
  assert.equal(db.total.full, "7,402,118");
  assert.equal(db.rate, "9,900 rows/s");
});

test("tone: NACK is warning only while its rate is above 0", () => {
  assert.equal(nackTone(0.2), "warning");
  assert.equal(nackTone(0), null);
  assert.equal(nackTone(null), null);
  assert.equal(counterTiles(sum(), [])[0].b.tone, "warning");
  const quiet = sum({ rates: { ...sum().rates, mtNackPerSecond: 0 } });
  assert.equal(counterTiles(quiet, [])[0].b.tone, null);
});

test("tone: QUEUE is alarm, with ▲, only after rising on each of the last five polls", () => {
  assert.equal(queueRising([1, 2, 3, 4]), false, "four polls are not enough");
  assert.equal(queueRising([1, 2, 3, 4, 5]), true);
  assert.equal(queueRising([9, 1, 2, 3, 4, 5]), true, "only the last five count");
  assert.equal(queueRising([1, 2, 2, 3, 4]), false, "flat is not rising");
  assert.equal(queueRising([1, 2, 3, 5, 4]), false);
  assert.equal(queueTone([10, 20, 30, 40, 50]), "alarm");
  const db = counterTiles(sum(), [100, 200, 300, 400, 12_800])[2];
  assert.equal(db.b.tone, "alarm");
  assert.equal(db.b.text, "12,800 ▲");
  assert.equal(db.b.full, "12,800");
  assert.equal(counterTiles(sum(), [5, 4, 3, 2, 1])[2].b.text, "12,800");
});

test("queue history keeps the newest five", () => {
  let h: number[] = [];
  for (const v of [1, 2, 3, 4, 5, 6, 7]) {
    h = pushQueue(h, v);
  }
  assert.deepEqual(h, [3, 4, 5, 6, 7]);
});

test("since: the clock today, the date before it, missing nodes named", () => {
  const now = Date.parse("2026-10-30T12:00:00Z");
  assert.equal(sinceText(sum(), now, "UTC"), "counters since restart 07:41");
  assert.equal(sinceText(sum({ since: "2026-10-28T23:05:00Z" }), now, "UTC"), "counters since restart 28 Oct 23:05");
  assert.equal(sinceText(sum({ since: null, partial: ["node-2"] }), now, "UTC"), "counters since restart (without node-2)");
  assert.equal(sinceText(null, now, "UTC"), "");
});
