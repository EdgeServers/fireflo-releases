import type { PreprocessorLive } from "./preprocessor-types";
import { formatTps } from "./tps-format.ts";

/**
 * The shape of `/ops/health`, and what to conclude from it.
 *
 * <p>No database import, so client components can use it. Shared rather than redeclared because the
 * health page and the vendor page read the same payload, and a field that drifts between two copies
 * of an interface is a silently absent number rather than a type error.
 */

/**
 * One bound connection: an outbound session for a vendor, a connected customer for a server.
 *
 * <p>Every field except `bound` is optional and nullable, because the gateway omits what it cannot
 * read rather than sending a placeholder — a vendor session has no `account`, a customer that bound
 * without a system_type has no `system_type`, and any session may have its counters switched off.
 */

export interface HealthSession {
  /**
   * What a disconnect names this session by, absent for a vendor's outbound sessions.
   *
   * <p>The listener's own counter and nothing more: two listeners will each have a session 3, and
   * the numbers restart with the gateway. Unique enough to key a table row and address a button,
   * worth nothing stored anywhere.
   */
  session_id?: number | null;
  bind_type?: string | null;
  bound: boolean;
  /** NORMAL, EXTRA or BACKUP — a vendor quietly running on its backup host looks identical without it. */
  role?: string | null;
  /** The far end: the host a vendor session dialled, or the address a customer bound from. */
  host?: string | null;
  port?: number | null;
  system_id?: string | null;
  account?: string | null;
  /**
   * What a customer asked to bind as, absent when the bind carried none.
   *
   * <p>Absent is a fact rather than a gap — it means the login's own product applied — so it must
   * not be filled in from the credential. This is what explains why a customer's traffic is priced
   * and whitelisted the way it is.
   */
  system_type?: string | null;
  submitted?: number | null;
  /**
   * deliver_sm the gateway sent down this session since the bind: receipts and inbound messages
   * handed to the customer (gateway 0.13.2+). Absent on an older gateway and on a vendor session,
   * null when the counters are off -- all three read as "not counted", never as zero.
   */
  receipts?: number | null;
  tps_measured?: number | null;
  tps_limit?: number | null;
  bound_seconds?: number | null;
  /**
   * The login's own `max_tps`, which can only narrow the account ceiling in `tps_limit`, and which of
   * the two limits this session runs under (gateway 0.15.1+, `Session.loginTpsLimit` /
   * `Session.limitSource`). Absent from an older gateway, which the sessions route asks without them
   * (`lib/sessions-read.ts`): the pages then show the bare `≤N` without saying where it came from.
   */
  login_tps_limit?: number | null;
  limit_source?: LimitSource | null;
}

/**
 * Which setting produced the ceiling a session is held to, as the gateway names it (0.15.1+):
 * the login's `max_tps`, the account's `conf.maxRate.<id>`, the listener's `conf.maxRate.default`,
 * or nothing at all.
 */
//PORT_SHARE (gateway 0.15.2): the account's share of the listener's tps among its active customers
export type LimitSource = "LOGIN_MAX_TPS" | "ACCOUNT_OVERRIDE" | "LISTENER_DEFAULT" | "PORT_SHARE" | "UNLIMITED";

/**
 * One account a node is throttling (answering 0x58), from health's `throttling` list (gateway
 * 0.15.1+, the ten busiest by the last minute). Per account, not per login or listener: `listeners`
 * names where, and the counts are the account's across them. Typed GraphQL rather than part of the
 * snapshot, so the health route asks for it in a document of its own (HEALTH_THROTTLING) and spells
 * it the snapshot's way.
 */
export interface ThrottlingAccount {
  account: string;
  /** The minute in progress and the one before it. */
  last_minute?: number | null;
  last5_minutes?: number | null;
  /** last_minute turned away by the account's ceiling, and by a login's own TPS. */
  by_account_limit?: number | null;
  by_login_limit?: number | null;
  /** Listener full names, `smppserver.<name>`. */
  listeners?: string[] | null;
}

/** The accounts throttled on one listener, by its full or instance name. */
export function throttlingOn(list: readonly ThrottlingAccount[] | null | undefined, listener: string): ThrottlingAccount[] {
  const full = listener.includes(".") ? listener : `smppserver.${listener}`;
  return (list ?? []).filter((t) => (t.listeners ?? []).some((l) => l === full || l === listener));
}

/**
 * The highest measured rate somewhere, and when (gateway 0.12.5+ -- V1.69.0).
 *
 * <p>Messages per second averaged over `window_seconds`, the same window as `tps_measured`, so it is
 * a figure somebody could have watched live. Kept by the gateway across restarts.
 */
export interface TpsPeak {
  tps: number;
  at: string;
  window_seconds: number;
}

export interface HealthWorker {
  name: string;
  type: string;
  accepting: boolean;
  paused: boolean;
  suspended_manually: boolean;
  suspended_automatically: boolean;
  //the gateway omits absent fields rather than sending null, so these are optional as well as
  //nullable -- and every check must be `!= null`, since `undefined !== null` is true
  bound?: number | null;
  bound_transmittable?: number | null;
  queue_depth: number;
  retry_queue_depth: number;
  /** Listener only, while Stop sending is on: inbound accepted and parked un-routed (0.9.21+). */
  held_inbound?: number | null;
  tps_limit?: number | null;
  //what it is actually pushing, where tps_limit is only what it is allowed to. Zero is REAL here:
  //bound, counting and moving nothing. Guard with `!= null`, never with truthiness, or the most
  //alarming reading this page can show becomes invisible
  tps_measured?: number | null;
  submitted?: number | null;
  /**
   * Delivery receipts since the gateway started (0.15.2+, capability `worker_receipts`): on a vendor
   * the receipts it sent us, on a listener the receipts we sent customers. Absent on an older gateway.
   */
  receipts?: number | null;
  last_error?: string | null;
  last_error_at?: string | null;
  /**
   * The submit side, separate from last_error because they are different faults.
   *
   * <p>last_error is a BIND failure: the vendor would not let us connect. This is a per-message
   * rejection from a vendor that connected fine — which used to be invisible here entirely, so a
   * lane refusing every message looked identical to a healthy one.
   */
  last_submit_error?: string | null;
  last_submit_error_at?: string | null;
  submit_rejected?: number | null;
  //A SAMPLE, not the set — at most 20 per worker. Null when this is not an SMPP worker, empty when
  //it is one with nothing bound. Health is polled every few seconds by every open dashboard, and a
  //listener with 500 binds was sending 500 rows each time.
  //
  //Never count these to answer "how many are bound": that is `bound`, and `sessions_total` says how
  //many rows exist. To show or search the whole set, use /api/control/workers/<name>/sessions.
  sessions?: HealthSession[] | null;
  //how many sessions there really are, so a sample can be told from the set
  sessions_total?: number | null;
  /** The highest `tps_measured` this worker has reached. Absent until something is measured. */
  tps_peak?: TpsPeak | null;
}

/** Which source each configuration domain was read from: `file` or `database`. */
export interface ConfigSources {
  properties?: string;
  credentials?: string;
  routing?: string;
  rates?: string;
}

/**
 * The message broker REST submissions queue through, when there is one.
 *
 * <p>Absent means this gateway is not configured to use a broker at all — which is a different fact
 * from a broker that is down, and must not be shown as "0 waiting".
 */
export interface HealthBroker {
  connected: boolean;
  queue?: string | null;
  //absent unless connected. An unreachable broker may be holding thousands
  messages?: number | null;
  consumers?: number | null;
}

/**
 * The gateway's own connection to PostgreSQL (gateway 0.15.1, `db_info`), as the Queues page's
 * Database card shows it: where it points, what answers, the pool and its two reserved lanes, and
 * the last probe. Every field optional: the block is absent on an older gateway and without a
 * database, and a field the gateway could not read is left out rather than guessed. Never the user
 * or the password.
 */
export interface HealthDatabase {
  /** The host as configured: a name or an address. */
  host?: string | null;
  /** The address the host resolved to, when it is a name. */
  ip?: string | null;
  port?: number | string | null;
  /** The database name. */
  name?: string | null;
  /** `server_version` as PostgreSQL reports it, e.g. "18.6". */
  server_version?: string | null;
  /** The newest Flyway migration applied, e.g. "1.122.0". */
  schema_version?: string | null;
  /** When the pool's current connections were first opened. */
  connected_since?: string | null;
  pool?: {
    max?: number | null;
    active?: number | null;
    idle?: number | null;
    waiting?: number | null;
    acquisition_timeout_ms?: number | null;
  } | null;
  /** Connections held back for leases and for control statements, so a busy pool cannot starve them. */
  lanes?: {
    lease?: { max?: number | null; active?: number | null } | null;
    control?: { max?: number | null; active?: number | null } | null;
  } | null;
  /** The last probe's round trip, ms. */
  probe_ms?: number | null;
  /** The last wait for a connection from the pool, ms. */
  pool_wait_ms?: number | null;
}

/** One node of the cluster, as every node's heartbeat describes it (gateway 0.14, `node_identity`). */
export interface ClusterNode {
  nodeId: string;
  host?: string | null;
  version?: string | null;
  startedAt?: string | null;
  heartbeatAt?: string | null;
  /** A heartbeat within `smsg.cluster.node.timeout.seconds`. */
  alive: boolean;
  /** The node's management port, for a panel that wants to ask it directly. */
  opsUrl?: string | null;
}

/** The cluster as the answering node sees it. `mode` is `memory` or `kafka`; Kafka mode is cluster mode. */
export interface ClusterHealth {
  mode: string;
  nodes: ClusterNode[];
}

/** The answering node's own identity: its `nodeId` and, when the cluster lists it, its row. */
export interface HealthNode {
  nodeId: string;
  self: ClusterNode | null;
}

/**
 * The Kafka backbone as the answering node sees it (gateway 0.14, `kafka_backbone`).
 *
 * <p>Absent means the gateway does not publish the field; `provider` of `memory` means it queues in
 * process. Neither is a broker that is down, which is `connected: false` -- and must not be shown
 * as "0 behind".
 */
export interface HealthBackbone {
  provider: string;
  bootstrap?: string | null;
  connected: boolean;
  routerGroup?: string | null;
  /** Messages on the router topic not yet taken by the group. */
  routerLag?: number | null;
  /** The partitions this node holds. */
  assignment?: string[] | null;
  retryDepth?: number | null;
  dlqDepth?: number | null;
  lastError?: string | null;
  lastErrorAt?: string | null;
  /**
   * What decided `provider` and `bootstrap` (gateway `queue_provider_env`): `env` is
   * FIREFLO_QUEUE_PROVIDER / FIREFLO_KAFKA_BOOTSTRAP in the gateway's fireflo.env, which win over
   * `app_config`; `stored` is the `app_config` row; `default` is neither. Absent on an older
   * gateway, which `providerSourceOf` reads as unknown -- and unknown never locks anything.
   */
  source?: string | null;
}

/** Where the gateway's queue provider came from, as `HealthBackbone.source` names it. */
export type ProviderSource = "env" | "stored" | "default";

/** The source as one of the three names, or null when absent or a name this panel does not know. */
export function providerSourceOf(backbone: { source?: string | null } | null | undefined): ProviderSource | null {
  const raw = backbone?.source?.trim().toLowerCase();
  return raw === "env" || raw === "stored" || raw === "default" ? raw : null;
}

/** The source as the Queues page puts it after the provider, or null when it is unknown. */
export function providerSourceLabel(source: ProviderSource | null | undefined): string | null {
  switch (source) {
    case "env":
      return "from fireflo.env";
    case "stored":
      return "from settings";
    case "default":
      return "default";
    default:
      return null;
  }
}

export interface Health {
  observed_at: string;
  /**
   * The release the gateway process is running.
   *
   * Optional because a gateway older than the field simply omits it, which
   * `versionPairing` treats as "nothing to compare" rather than as a fault.
   */
  version?: string | null;
  /**
   * The newest Flyway migration the database has been through, e.g. "1.90.0" (gateway 0.13+).
   *
   * "none" on a gateway with no database (file mode), "unknown" when the history table could not
   * be read, absent on a gateway older than the field. `schemaPairing` compares it with what this
   * panel was written against.
   */
  schema_version?: string | null;
  /**
   * What this build's management and operational API can do, by name, every value true. A fact
   * about the build, so identical on every node of one release. Absent on an older gateway, which
   * `hasCapability` reads as "no" for every name.
   */
  api?: (Record<string, boolean> & { worker_receipts?: boolean }) | null;
  /** Who may reach the management port (gateway 0.13+, from the GraphQL `health` field). */
  ops_allow_list?: { entries: string[]; loopbackOnly: boolean } | null;
  /** `smsg.rates.currency` as the gateway reads it, file or database; null while none is set (gateway 0.13.1+). */
  currency?: string | null;
  /** The slow-query log's threshold and last hour's count (gateway 0.13+). */
  db?: { slowThresholdMs: number; slowLastHour: number } | null;
  /** This process's node id, `FIREFLO_INSTANCE_ID` or generated (gateway 0.14). Env-only, never in app_config. */
  node_id?: string | null;
  /** The cluster as this node sees it (gateway 0.14). */
  cluster?: ClusterHealth | null;
  /** The Kafka backbone (gateway 0.14); null or absent in memory mode or on an older gateway. */
  backbone?: HealthBackbone | null;
  /** The band listeners may bind in, as the gateway parsed it ("27800-27899"); absent when unrestricted. */
  smpp_port_range?: string | null;
  router_queue: number;
  /** Messages the router parked to retry later (in memory); the Kafka retry topic is `backbone.retryDepth`. */
  routing_retry_queue?: number | null;
  /**
   * The persistence bus (0.15.1): writes waiting for PostgreSQL, by stream, and the age in seconds of
   * the oldest. Absent on an older gateway or without a database.
   */
  persist_depth?: Record<string, number | null> | null;
  persist_lag_seconds?: number | null;
  /**
   * `smsg.persist.lag.max.seconds` as the gateway reads it: past this the persist lag refuses new
   * submits. Not published by every 0.15.1 build; a reader falls back to the gateway's default, 60.
   */
  persist_lag_max_seconds?: number | null;
  /**
   * What the persistence bus's writers are doing (0.15.1): ok, slow, paused -- and from 0.15.2
   * `stalled`, while a lane has written nothing for `smsg.persist.stall.seconds` with writes waiting
   * and the database answering. Absent without the bus and on an older gateway.
   */
  persist_writer?: string | null;
  /**
   * The persistence bus's lanes (0.15.2, `component_restart`): a stream has one or more. Absent on an
   * older gateway, which the Database card reads as "no write-behind block" rather than as empty.
   */
  persist_streams?: HealthPersistLane[] | null;
  awaiting_receipt: number;
  dlr_store_persistent: boolean;
  config_sources?: ConfigSources | null;
  /** The window every `tps_measured` is averaged over, so a label need not hardcode it. */
  tps_window_seconds?: number | null;
  broker?: HealthBroker | null;
  cdr: {
    enabled: boolean;
    sink: string;
    written: number;
    failed: number;
    /** The spill directory has outgrown `smsg.cdr.spill.max.mb` (0.15.1): the database has been away too long. */
    spill_over_cap?: boolean | null;
  } | null;
  /**
   * The database as the ingresses see it (gateway 0.15.1, `DbLatencyMonitor`, every 2 s): the hot
   * writers' statement latency and the pool wait in ms, whether new submits are admitted, and the
   * submits refused `dbUnavailable` since start. Absent without a database and on an older gateway;
   * the two times also until the first sample.
   */
  db_latency_ms?: number | null;
  db_pool_wait_ms?: number | null;
  db_admission?: "OK" | "DEGRADED" | "REFUSING" | null;
  db_refused_total?: number | null;
  /**
   * Which signal holds `db_admission` outside OK (0.15.1): probe, pool, lag, log, ramp -- and, once the
   * door refuses on the local log's cap only, `logCap`. Absent while OK and on an older gateway.
   */
  db_admission_reason?: string | null;
  /** Rows a second the persistence bus last measured writing (0.15.1); null before its first measurement. */
  db_write_rate?: number | null;
  /** The persistence bus's local log on disk, bytes, and whether its fsync is succeeding (0.15.1); absent while no log is open. */
  persist_log_bytes?: number | null;
  persist_log_healthy?: boolean | null;
  /**
   * `smsg.persist.log.max.mb`, the local log's cap, should the gateway publish it; not in any 0.15.1
   * build yet, so a reader shows the log's size alone without it.
   */
  persist_log_max_mb?: number | null;
  /** Receipt-store writes buffered and not yet committed (0.15.1); absent on the MVStore store. */
  dlr_store_buffer?: number | null;
  /** The gateway's connection to PostgreSQL (0.15.1, `db_info`); absent on an older gateway or without a database. */
  database?: HealthDatabase | null;
  /** Absent entirely when sender ID and content whitelisting is switched off. */
  whitelist?: HealthWhitelist | null;
  /**
   * Routing tables that load and route, but not the way they read.
   *
   * An empty array is the healthy answer and means "checked, nothing wrong". Absent means the
   * gateway predates the check — a distinction worth keeping, because this is the only place a
   * file-sourced `routingTable.conf` gets checked at all: the panel computes the same warnings for
   * itself, but only for the tables it can read out of the database.
   */
  routing_warnings?: HealthRoutingWarning[] | null;
  workers: HealthWorker[];
  /**
   * The gateway's preprocessors and what each is doing (0.12.0+). Absent from an older gateway,
   * which is not the same as none configured (an empty list).
   */
  preprocessors?: PreprocessorLive[] | null;
  /** `smsg.preprocessor.enabled` (0.12.0+). Off by default; when off nothing runs and @name rules are skipped. */
  preprocessors_enabled?: boolean | null;
  /** The highest rate every vendor together, and every listener together, has reached. SMPP only. */
  tps_peaks?: { vendors?: TpsPeak | null; servers?: TpsPeak | null } | null;
  /**
   * Who is being throttled right now (gateway 0.15.1+). Absent from an older gateway, which is not
   * the same as an empty list: absent hides the throttle figures, empty shows them as zero.
   */
  throttling?: ThrottlingAccount[] | null;
}

/** One persistence lane, as health's `persist_streams` lists it (gateway 0.15.2). */
export interface HealthPersistLane {
  /** cdr, dlr-store or unpushed. */
  stream: string;
  lane?: number | null;
  /** Writes waiting for PostgreSQL in this lane, those in the local log included. */
  depth?: number | null;
  /** The lane writes from the local log (its queue was full, or the database paused or failed). */
  spilled?: boolean | null;
  /** How long the stall watchdog has found the lane stalled; 0 while it is not. */
  stalled_seconds?: number | null;
}

export interface HealthRoutingWarning {
  table: string;
  /** A stable token: `no-catch-all` or `unreachable-rules`. Match on this, not on `detail`. */
  cause: string;
  detail: string;
}

export interface HealthWhitelist {
  /**
   * Whether a whitelist has been loaded and may be enforced.
   *
   * <p>False while the block is present is the alarming state: the gateway was told to enforce and
   * has never read the tables, so nothing is being checked and everything is allowed. That is the
   * designed behaviour — an unloaded whitelist must not refuse traffic — but it is invisible from
   * outside without this field.
   */
  active: boolean;
  generation: number;
  scopes: number;
  header_rejects: number;
  template_rejects: number;
  /** What REPORT mode would have refused. The number an operator reads before enforcing. */
  report_only_would_reject: number;
  enforcing_with_nothing_approved: string[];
}

/**
 * Whether the gateway is reading its workers from the database at all.
 *
 * <p>When it is not, every row on the vendor and server pages is inert — stored, valid, and ignored.
 * That is invisible from the panel's own side: the switch is a bootstrap setting the gateway reads
 * before it opens the database, so it can only be reported, never queried.
 *
 * <p>Undefined when health could not be read, which is not the same as false and must not be shown
 * as reassurance.
 */
export function readsWorkersFromDatabase(health: Health | null): boolean | undefined {
  const source = health?.config_sources?.properties;
  return source == null ? undefined : source === "database";
}

/**
 * Whether the gateway is reading its **pricing** from the database.
 *
 * <p>The gateway has one switch — `smsg.config.source` — so in practice this agrees with
 * {@link readsWorkersFromDatabase}. It stays a separate function because `/ops/health` reports per
 * domain and a caller asking "is my pricing live" should not have to know that one key implies four.
 * It used to be four independent switches, and an operator who moved workers across and assumed
 * pricing had followed was looking at a page whose every row was stored, valid, and ignored.
 *
 * <p>Undefined when health could not be read, which is not the same as false and must not be shown
 * as reassurance.
 */
export function readsRatesFromDatabase(health: Health | null): boolean | undefined {
  const source = health?.config_sources?.rates;
  return source == null ? undefined : source === "database";
}

/**
 * Whether the gateway is authenticating from the database.
 *
 * <p>The third of three independent switches, and the one with the largest blast radius: with
 * `app_credential` empty and this set to `database`, the loader publishes an empty map rather than
 * ignoring it, so every bind and every REST call is refused at once and nothing in the logs names
 * the cause.
 *
 * <p>Undefined when health could not be read, which is not the same as false.
 */
export function readsCredentialsFromDatabase(health: Health | null): boolean | undefined {
  const source = health?.config_sources?.credentials;
  return source == null ? undefined : source === "database";
}

/**
 * Whether the gateway is reading its routing from the database.
 *
 * <p>The fourth of four independent switches. Included for completeness rather than because a page
 * edits routing today — nothing does — so that a future one cannot be written without the question
 * being asked.
 */
export function readsRoutingFromDatabase(health: Health | null): boolean | undefined {
  const source = health?.config_sources?.routing;
  return source == null ? undefined : source === "database";
}

/**
 * Whether sender ID and content whitelisting is switched on at all.
 *
 * <p>Not a configuration source — whitelisting is database-only and has no file form. The block is
 * absent from health when `smsg.whitelist.enabled` is unset, which means every approved sender ID
 * and template in the panel is recorded and enforcing nothing.
 *
 * <p>Undefined when health could not be read, which is not the same as false.
 */
export function whitelistEnabled(health: Health | null): boolean | undefined {
  if (!health) {
    return undefined;
  }
  return health.whitelist != null;
}

/**
 * Whether a whitelist has actually been loaded, once it is switched on.
 *
 * <p>Separate from {@link whitelistEnabled} because the two failures need different fixes: not
 * switched on is a configuration choice, switched on and never loaded is a database the gateway
 * cannot reach — and in that state nothing is being enforced despite the panel showing approvals.
 */
export function whitelistActive(health: Health | null): boolean | undefined {
  return health?.whitelist == null ? undefined : health.whitelist.active;
}

export type ConnectionState = "unloaded" | "connected" | "disconnected";

/**
 * Three states with three different fixes, which is why they are distinguished at all.
 *
 * <p><strong>`unloaded` is the one that matters</strong>: the worker is configured here and the
 * gateway has never heard of it. Reporting that as "not connected" would send someone to check a
 * password that was never used.
 *
 * <p>Note what is <em>not</em> used: `paused` from the snapshot is not an operator signal.
 * `SmppClientWorker.isPause()` returns true whenever there is no bound transmittable session, so it
 * is also true for a vendor nobody paused. Connectivity comes from `bound`, and intent comes from
 * the stored `suspend` and `pause` settings.
 */
export function connectionState(live: HealthWorker | undefined): ConnectionState {
  if (!live) {
    return "unloaded";
  }
  return (live.bound ?? 0) > 0 ? "connected" : "disconnected";
}

/**
 * Throughput as one phrase: what it is doing, and what it is allowed to do.
 *
 * <p>Shared by both pages so they cannot drift into describing the same two numbers differently.
 *
 * <p>The checks are `!= null` rather than truthiness for a reason worth stating twice: a measured
 * rate of exactly 0 on a bound, counting vendor is the single most useful thing here — it means
 * traffic has stopped — and `w.tps_measured &&` would silently drop it.
 *
 * @returns null when neither number exists, so a caller can omit the element entirely
 */
export function tpsSummary(worker: HealthWorker): string | null {
  const measured = worker.tps_measured != null ? `${formatTps(worker.tps_measured)} tps` : null;
  const limit = worker.tps_limit != null ? `\u2264${worker.tps_limit}` : null;
  if (measured && limit) {
    return `${measured} of ${limit}`;
  }
  return measured ?? (limit ? `${limit} tps` : null);
}

/**
 * How much of the configured ceiling is being used.
 *
 * @returns null when there is no ceiling, or nothing measured to compare against it
 */
export function tpsUtilisation(worker: HealthWorker): number | null {
  if (worker.tps_measured == null || worker.tps_limit == null || worker.tps_limit <= 0) {
    return null;
  }
  return worker.tps_measured / worker.tps_limit;
}

/**
 * The gateway's GraphQL `health` field (0.13+), as `lib/gateway-queries.ts` asks for it.
 *
 * <p>The typed half beside the whole old `/ops/health` object, which travels as `snapshot` with its
 * field names unchanged.
 */
export interface HealthField {
  version: string;
  observedAt: string;
  schemaVersion: string;
  api: Record<string, boolean>;
  opsAllowList: { entries: string[]; loopbackOnly: boolean };
  /** The platform currency as the gateway reads it; null while unset. Absent on 0.13.0. */
  currency?: string | null;
  db?: { slowThresholdMs: number; slowLastHour: number } | null;
  snapshot: Health;
}

/** The second health document (HEALTH_CLUSTER), sent only to a gateway whose capability map has the fields. */
export interface HealthClusterField {
  nodeId?: string | null;
  cluster?: ClusterHealth | null;
  backbone?: HealthBackbone | null;
}

/** The third health document (HEALTH_THROTTLING), camelCase as the gateway types it. */
export interface HealthThrottlingField {
  throttling?: {
    account: string;
    lastMinute?: number | string | null;
    last5Minutes?: number | string | null;
    byAccountLimit?: number | string | null;
    byLoginLimit?: number | string | null;
    listeners?: string[] | null;
  }[] | null;
}

/** Health's `throttling` spread over the snapshot, spelt the snapshot's way, Longs as numbers. */
export function withThrottling(health: Health, t: HealthThrottlingField | null | undefined): Health {
  if (!t?.throttling) {
    return health;
  }
  const n = (v: number | string | null | undefined) => (v == null || v === "" ? null : Number(v));
  return {
    ...health,
    throttling: t.throttling.map((a) => ({
      account: a.account,
      last_minute: n(a.lastMinute),
      last5_minutes: n(a.last5Minutes),
      by_account_limit: n(a.byAccountLimit),
      by_login_limit: n(a.byLoginLimit),
      listeners: a.listeners ?? [],
    })),
  };
}

/** The typed cluster fields spread over a health snapshot, under the names the pages read. */
export function withCluster(health: Health, c: HealthClusterField | null | undefined): Health {
  if (!c) {
    return health;
  }
  return { ...health, node_id: c.nodeId ?? null, cluster: c.cluster ?? null, backbone: c.backbone ?? null };
}

/**
 * The answering node's identity, or null when the gateway does not publish one. `self` is its row
 * in the cluster list when the list has it, so a caller can show host and start time without
 * searching the list itself.
 */
export function selfNode(health: Health | null | undefined): HealthNode | null {
  const nodeId = health?.node_id?.trim();
  if (!nodeId) {
    return null;
  }
  return { nodeId, self: health?.cluster?.nodes.find((n) => n.nodeId === nodeId) ?? null };
}

/**
 * The shape `/ops/health` had: the snapshot with the typed fields spread over it under the names
 * the pages already read, so a gateway that drops a field from the snapshot one day still answers
 * it here.
 */
export function flattenHealth(h: HealthField): Health {
  return {
    ...h.snapshot,
    version: h.version,
    observed_at: h.observedAt,
    schema_version: h.schemaVersion,
    api: h.api,
    ops_allow_list: h.opsAllowList,
    currency: h.currency ?? null,
    db: h.db ?? null,
  };
}
