import { strict as assert } from "node:assert";
import { test } from "node:test";
import {
  hourWindowLabel, instanceName, lastFullMinute, LISTENER_GROUPING, listenerHour, listenerRefusal, readConnectivityCounts, REFUSAL_GROUPING,
  toConnectivityCounts, toRefusals, VENDOR_GROUPING, vendorHour,
} from "./connectivity-counts.ts";
import type { LiveBucket, LiveGrain, LiveGroup, LiveKeys, LiveSeriesSum } from "./gateway-live-series.ts";

const NONE: LiveKeys = { account: null, login: null, listener: null, product: null, vendor: null };

function b(bucket: string, keys: Partial<LiveKeys>, n: Partial<LiveBucket> = {}): LiveBucket {
  return {
    bucket, keys: { ...NONE, ...keys }, backfilled: false, submitted: 0, refused: 0, refusedBy: [], priceSum: 0, costSum: 0,
    attempts: null, sent: 0, vendorRefused: 0, delivered: 0, failed: 0, expired: 0, pending: 0, ...n,
  };
}

function sum(buckets: LiveBucket[], over: Partial<LiveSeriesSum> = {}): LiveSeriesSum {
  return {
    nodes: ["node-1"], partial: [], liveSince: "2026-10-30T09:00:00Z", backfilledThrough: null, deadlineHours: 24,
    saturated: [], buckets, ...over,
  };
}

//H1 in minute bins grouped by listener: 12:10 is in progress (until 12:11), 12:09 the last full minute
const MINUTES = sum([
  b("2026-10-30T12:08:00Z", { listener: "smppserver.dltsmpp" }, { refused: 9_000, refusedBy: [{ reason: "dbUnavailable", count: 9_000 }] }),
  b("2026-10-30T12:09:00Z", { listener: "smppserver.dltsmpp" }, {
    refused: 15_000, refusedBy: [{ reason: "dbUnavailable", count: 12_000 }, { reason: "creditPending", count: 3_000 }],
  }),
  //the same listener under its bare name from another node: merged
  b("2026-10-30T12:09:00Z", { listener: "dltsmpp" }, { refused: 3_720, refusedBy: [{ reason: "dbUnavailable", count: 2_976 }, { reason: "creditPending", count: 744 }] }),
  b("2026-10-30T12:09:00Z", { listener: "smppserver.otp" }, { refused: 0, submitted: 50 }),
  b("2026-10-30T12:10:00Z", { listener: "smppserver.otp" }, { refused: 600, refusedBy: [{ reason: "throttled", count: 600 }] }),
], { until: "2026-10-30T12:11:00Z" });

//H1 in hour bins: the minute in progress and the sixty before it straddle two UTC hours
const LISTENERS = sum([
  b("2026-10-30T11:00:00Z", { listener: "smppserver.dltsmpp", account: "YK201" }, { submitted: 40_000, delivered: 38_000, failed: 1_000, pending: 1_000 }),
  b("2026-10-30T12:00:00Z", { listener: "smppserver.dltsmpp", account: "YK201" }, { submitted: 2_000, delivered: 1_500, failed: 100 }),
  b("2026-10-30T12:00:00Z", { listener: "dltsmpp", account: "ACME" }, { submitted: 500, delivered: 480 }),
  //REST traffic: no listener, no box
  b("2026-10-30T12:00:00Z", { account: "API1" }, { submitted: 9_999, delivered: 9_999 }),
]);
const VENDORS = sum([
  b("2026-10-30T11:00:00Z", { vendor: "smppclient.jio", account: "YK201" }, { submitted: 30_000, sent: 30_100, delivered: 29_000, failed: 500 }),
  b("2026-10-30T12:00:00Z", { vendor: "jio", account: "ACME" }, { submitted: 400, sent: 400, delivered: 390 }),
  b("2026-10-30T12:00:00Z", { vendor: "smppclient.otp3", account: "YK201" }, { sent: 20, delivered: 0, failed: 2 }),
], { nodes: ["node-2"], partial: ["node-3"], liveSince: "2026-10-30T10:30:00Z" });

test("listener side: MT is submitted, DLR delivered + failed, summed over the hour's bins per listener × account", () => {
  const c = toConnectivityCounts(LISTENERS, VENDORS);
  assert.deepEqual(c.listeners, [
    { listener: "dltsmpp", account: "ACME", mt: 500, dlr: 480 },
    { listener: "dltsmpp", account: "YK201", mt: 42_000, dlr: 40_600 },
  ]);
  assert.deepEqual(listenerHour(c, "smppserver.dltsmpp"), { mt: 42_500, dlr: 41_080 });
  assert.deepEqual(listenerHour(c, "dltsmpp", "YK201"), { mt: 42_000, dlr: 40_600 });
  assert.equal(listenerHour(c, "dltsmpp", "NOBODY"), null, "unknown is null, not zero");
  assert.equal(listenerHour(c, "smpp"), null);
});

test("vendor side: MT is what the vendor took (sent), DLR the receipts it reported, every account summed", () => {
  const c = toConnectivityCounts(LISTENERS, VENDORS);
  assert.deepEqual(c.vendors, [
    { vendor: "jio", mt: 30_500, dlr: 29_890 },
    { vendor: "otp3", mt: 20, dlr: 2 },
  ]);
  assert.deepEqual(vendorHour(c, "smppclient.jio"), { mt: 30_500, dlr: 29_890 });
  assert.equal(vendorHour(c, "foxip"), null);
});

test("the cluster facts of both series are carried: every node, the missing ones, the latest restart", () => {
  const c = toConnectivityCounts(LISTENERS, VENDORS);
  assert.deepEqual(c.nodes, ["node-1", "node-2"]);
  assert.deepEqual(c.partial, ["node-3"]);
  assert.equal(c.liveSince, "2026-10-30T10:30:00Z");
});

test("a negative or non-finite figure from the wire never makes a count fall", () => {
  const c = toConnectivityCounts(sum([b("x", { listener: "a" }, { submitted: -5, delivered: Number.NaN, failed: 3 })]), sum([]));
  assert.deepEqual(c.listeners, [{ listener: "a", account: null, mt: 0, dlr: 3 }]);
});

test("instance names: the prefix goes, a bare name stays", () => {
  assert.equal(instanceName("smppserver.dltsmpp", "smppserver"), "dltsmpp");
  assert.equal(instanceName("dltsmpp", "smppserver"), "dltsmpp");
  assert.equal(instanceName("smppclient.jio", "smppserver"), "smppclient.jio");
});

test("the route asks both groupings in hour bins and the listeners in minute bins, and answers the rows", async () => {
  const asked: [readonly LiveGroup[], LiveGrain][] = [];
  const out = await readConnectivityCounts({
    available: async () => true,
    series: async (g, grain) => {
      asked.push([g, grain]);
      return grain === "MINUTE" ? MINUTES : g.includes("VENDOR") ? VENDORS : LISTENERS;
    },
  });
  assert.deepEqual(asked, [[LISTENER_GROUPING, "HOUR"], [VENDOR_GROUPING, "HOUR"], [REFUSAL_GROUPING, "MINUTE"]]);
  assert.deepEqual(REFUSAL_GROUPING, ["LISTENER"]);
  assert.deepEqual(LISTENER_GROUPING, ["LISTENER", "ACCOUNT"]);
  assert.deepEqual(VENDOR_GROUPING, ["VENDOR", "ACCOUNT"], "the vendor family combines with ACCOUNT only");
  assert.equal(out.status, 200);
  assert.ok(out.status === 200 && out.body.data.listeners.length === 2);
  assert.ok(out.status === 200 && out.body.data.refusals.length === 1);
  assert.equal(out.status === 200 ? out.body.data.refusalsMinute : null, "2026-10-30T12:09:00Z");
});

test("the minute series failing costs the refusals, never the counts", async () => {
  const out = await readConnectivityCounts({
    available: async () => true,
    series: async (g, grain) => {
      if (grain === "MINUTE") {
        throw new Error("BAD_REQUEST");
      }
      return g.includes("VENDOR") ? VENDORS : LISTENERS;
    },
  });
  assert.equal(out.status, 200);
  assert.ok(out.status === 200);
  assert.deepEqual(out.body.data.refusals, []);
  assert.equal(out.body.data.refusalsMinute, null);
  assert.equal(out.body.data.listeners.length, 2);
});

test("no live_series: 204 and no series asked, so the page falls back to since bind", async () => {
  let asked = 0;
  const out = await readConnectivityCounts({
    available: async () => false,
    series: async () => {
      asked += 1;
      return LISTENERS;
    },
  });
  assert.deepEqual(out, { status: 204 });
  assert.equal(asked, 0);
});

test("a gateway that cannot be asked, or a series that fails, is a 502 with the gateway's words", async () => {
  const down = await readConnectivityCounts({
    available: async () => {
      throw new Error("the gateway did not answer in 2 s");
    },
    series: async () => LISTENERS,
  });
  assert.deepEqual(down, { status: 502, body: { error: "the gateway did not answer in 2 s" } });
  const failed = await readConnectivityCounts({
    available: async () => true,
    series: async (g) => {
      if (g.includes("VENDOR")) {
        throw new Error("BAD_REQUEST");
      }
      return LISTENERS;
    },
  });
  assert.equal(failed.status, 502);
});

test("a backfilled bucket in the window is left out, and the window is named since the restart", () => {
  const listeners = sum([
    //after a restart at 11:20, the gateway refilled 11:00 from usage_hourly: the whole hour in its first minute
    b("2026-10-30T11:00:00Z", { listener: "dltsmpp", account: "YK201" }, { backfilled: true, submitted: 90_000, delivered: 88_000 }),
    b("2026-10-30T11:00:00Z", { listener: "dltsmpp", account: "YK201" }, { submitted: 1_000, delivered: 900, failed: 50 }),
  ], { liveSince: "2026-10-30T11:20:00Z" });
  const vendors = sum([
    b("2026-10-30T11:00:00Z", { vendor: "jio", account: "YK201" }, { backfilled: true, sent: 80_000, delivered: 79_000 }),
    b("2026-10-30T12:00:00Z", { vendor: "jio", account: "YK201" }, { sent: 700, delivered: 650 }),
  ], { liveSince: null });
  const c = toConnectivityCounts(listeners, vendors);
  assert.deepEqual(listenerHour(c, "dltsmpp"), { mt: 1_000, dlr: 950 });
  assert.deepEqual(vendorHour(c, "jio"), { mt: 700, dlr: 650 });
  assert.equal(c.skippedBackfill, 2);
  assert.equal(c.restartedAt, "2026-10-30T11:20:00Z");
  const named = hourWindowLabel(c, "UTC");
  assert.equal(named.label, "since restart 11:20");
  assert.match(named.note ?? "", /restarted inside the hour/);
});

test("with nothing backfilled the window is the plain last hour, and no note", () => {
  const c = toConnectivityCounts(LISTENERS, VENDORS);
  assert.equal(c.skippedBackfill, 0);
  assert.deepEqual(hourWindowLabel(c, "UTC"), { label: "last hour", note: null });
  assert.deepEqual(hourWindowLabel(null, "UTC"), { label: "last hour", note: null });
});

test("the last full minute is the one before the minute in progress: from the nodes' until, else the clock", () => {
  const at = (iso: string) => Date.parse(iso);
  assert.equal(lastFullMinute({ until: "2026-10-30T12:11:00Z" }, 0), at("2026-10-30T12:09:00Z"));
  //an until off the boundary still names the minute it falls in
  assert.equal(lastFullMinute({ until: "2026-10-30T12:10:30Z" }, 0), at("2026-10-30T12:09:00Z"));
  assert.equal(lastFullMinute({ until: null }, at("2026-10-30T12:10:42Z")), at("2026-10-30T12:09:00Z"));
  assert.equal(lastFullMinute(null, at("2026-10-30T12:10:00Z")), at("2026-10-30T12:09:00Z"));
});

test("refusals: the last full minute per listener, names merged, reasons summed most first; the minute in progress and zero rows left out", () => {
  const { rows, minute } = toRefusals(MINUTES, 0);
  assert.equal(minute, "2026-10-30T12:09:00Z");
  assert.deepEqual(rows, [
    { listener: "dltsmpp", refused: 18_720, by: [{ reason: "dbUnavailable", count: 14_976 }, { reason: "creditPending", count: 3_744 }] },
  ]);
});

test("a backfilled minute and REST traffic are never refusals of a port", () => {
  const series = sum([
    b("2026-10-30T12:09:00Z", { listener: "dltsmpp" }, { backfilled: true, refused: 90_000, refusedBy: [{ reason: "dbUnavailable", count: 90_000 }] }),
    b("2026-10-30T12:09:00Z", { account: "API1" }, { refused: 60, refusedBy: [{ reason: "dbUnavailable", count: 60 }] }),
  ], { until: "2026-10-30T12:11:00Z" });
  assert.deepEqual(toRefusals(series, 0).rows, []);
});

test("a listener's refusal is the minute's count a second; null when it refused nothing or nothing was read", () => {
  const c = toConnectivityCounts(LISTENERS, VENDORS, MINUTES, 0);
  const r = listenerRefusal(c, "smppserver.dltsmpp");
  assert.equal(r?.total, 18_720);
  assert.equal(r?.rate, 312);
  assert.equal(r?.by[0].reason, "dbUnavailable");
  assert.equal(listenerRefusal(c, "otp"), null);
  assert.equal(listenerRefusal(toConnectivityCounts(LISTENERS, VENDORS), "dltsmpp"), null, "no minute series, no refusals");
  assert.equal(listenerRefusal(null, "dltsmpp"), null);
  //an answer from before the field: no refusals, no throw
  assert.equal(listenerRefusal({ ...c, refusals: undefined } as unknown as typeof c, "dltsmpp"), null);
});

test("a slow gateway is a 502 with code SLOW (the page keeps its last counts); a refusal that taught no live_series is a 204", async () => {
  const { GatewayError, PANEL_CODES } = await import("./gateway-graphql-core.ts");
  const slow = await readConnectivityCounts({
    available: async () => true,
    series: async () => { throw new GatewayError(502, PANEL_CODES.slow, "The gateway is slow: no answer within 10 s."); },
  });
  assert.deepEqual(slow, { status: 502, body: { error: "The gateway is slow: no answer within 10 s.", code: "SLOW" } });
  let has = true;
  const missing = await readConnectivityCounts({
    available: async () => has,
    series: async () => {
      has = false;
      throw new GatewayError(400, "BAD_REQUEST", "Field 'liveSeries' undefined");
    },
  });
  assert.deepEqual(missing, { status: 204 });
});
