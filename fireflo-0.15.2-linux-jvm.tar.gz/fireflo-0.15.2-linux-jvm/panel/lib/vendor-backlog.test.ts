import { strict as assert } from "node:assert";
import { test } from "node:test";

import { HEALTH, VENDOR_BACKLOG } from "./gateway-queries.ts";
import {
  backlogAlerts,
  backlogBadge,
  backlogSummary,
  normaliseBacklog,
  readVendorBacklog,
  type GqlExecutor,
  type VendorBacklog,
} from "./vendor-backlog.ts";

const ok = (over: Partial<VendorBacklog> = {}): VendorBacklog => ({
  ...normaliseBacklog([{ worker: "smppclient.a", depth: 10, limit: 50000, maxAgeSeconds: 600, expireSeconds: 86400,
    state: "OK", bound: true, refusedTotal: 0, expiredTotal: 0 }])[0],
  ...over,
});

test("a healthy vendor raises nothing; refusing, unbound past the grace, or half its retention does", () => {
  assert.deepEqual(backlogAlerts([ok()]), []);
  assert.deepEqual(backlogAlerts([ok({ state: "THROTTLING" })]), [], "throttling is a badge, not a warning");
  const refusing = backlogAlerts([ok({ state: "REFUSING", depth: 60000, oldestAgeSeconds: 700 })]);
  assert.equal(refusing.length, 1);
  assert.match(refusing[0].message, /past its backlog limit \(60,000 waiting, oldest 12 min\).*refused \(vendorBacklog\)/);
  const failing = backlogAlerts([ok({ state: "REFUSING", failoverTarget: "smppclient.b" })]);
  assert.match(failing[0].message, /goes to smppclient\.b/);
  assert.deepEqual(backlogAlerts([ok({ bound: false, unboundSinceSeconds: 120 })], 600), [], "inside the grace");
  assert.match(backlogAlerts([ok({ bound: false, unboundSinceSeconds: 900 })], 600)[0].message, /no bind for 15 min.*vendorUnavailable/);
  assert.equal(backlogAlerts([ok({ retentionUsedPercent: 49 })]).length, 0);
  assert.equal(backlogAlerts([ok({ retentionUsedPercent: 50 })])[0].tone, "warning");
  assert.equal(backlogAlerts([ok({ retentionUsedPercent: 85 })])[0].tone, "destructive");
});

test("the badge: refusing, unbound, throttling, or none", () => {
  assert.equal(backlogBadge(ok()), null);
  assert.equal(backlogBadge(ok({ state: "THROTTLING" }))!.label, "throttling");
  assert.equal(backlogBadge(ok({ bound: false, unboundSinceSeconds: 5 }))!.label, "unbound");
  assert.equal(backlogBadge(ok({ state: "REFUSING", bound: false, unboundSinceSeconds: 5 }))!.label, "refusing");
});

test("the collapsed summary: how many vendors, how much queued, the worst state", () => {
  assert.equal(backlogSummary([ok({ depth: 1180 }), ok({ depth: 60 })]), "Backlogs · 2 vendors · 1,240 queued · worst: OK");
  assert.equal(backlogSummary([ok({ depth: -1 })]), "Backlogs · 1 vendor · 0 queued · worst: OK", "an unread depth adds nothing");
  assert.match(backlogSummary([ok({ state: "REFUSING" }), ok({ state: "THROTTLING" })]), /worst: REFUSING$/);
  assert.match(backlogSummary([ok(), ok({ state: "THROTTLING" })]), /worst: THROTTLING$/);
});

test("Long scalars as strings and absent fields read sensibly", () => {
  const [v] = normaliseBacklog([{ worker: "w", depth: "123", limit: "5", state: "BOGUS" }]);
  assert.equal(v.depth, 123);
  assert.equal(v.state, "OK");
  assert.equal(v.oldestAgeSeconds, null);
  assert.deepEqual(normaliseBacklog(null), []);
});

function gateway(api: Record<string, boolean>) {
  const asked: string[] = [];
  const exec: GqlExecutor = async <T,>(call: { query: string }) => {
    asked.push(call.query);
    if (call.query === HEALTH) {
      return { ok: true as const, data: { version: "0.15.1", observedAt: "", schemaVersion: "1.116.0", api, snapshot: {} } as T };
    }
    if (call.query === VENDOR_BACKLOG) {
      return { ok: true as const, data: [{ worker: "smppclient.a", depth: 1, state: "OK", bound: true }] as T };
    }
    return { ok: false as const, status: 500, code: "X", error: "unexpected" };
  };
  return { exec, asked };
}

test("an older gateway is told apart and never asked the field; a 0.15.1 one answers its vendors", async () => {
  const old = gateway({ cdr_storage: true });
  assert.deepEqual(await readVendorBacklog(old.exec, 600), { ok: true, body: { data: null, unsupported: true } });
  assert.equal(old.asked.length, 1);
  const now = gateway({ vendor_backlog: true });
  const read = await readVendorBacklog(now.exec, 300);
  assert.ok(read.ok && read.body.data);
  if (read.ok && read.body.data) {
    assert.equal(read.body.data.vendors[0].worker, "smppclient.a");
    assert.equal(read.body.data.unboundGraceSeconds, 300);
  }
});
