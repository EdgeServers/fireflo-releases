/**
 * Which call record tables a summary-backed read should name, decided by where its RAW rows start
 * rather than where its window starts. Database-free, so the choice is tested without one.
 *
 * <h2>Why (incident 2026-10-31)</h2>
 *
 * <p>`cdrSql`/`cdrQuery` route a whole statement onto the `_all` views when the instant they are
 * handed is older than the hot boundary (`cdr-grain.ts`). The summary-backed readers handed them
 * the WINDOW's start -- 7 or 30 days back -- although the rows they read from the call records are
 * only the sliver the summaries do not cover: the minutes past the hourly watermark, or the days
 * since the newest `usage_daily` line. So every 7- and 30-day figure, on every poll, probed the
 * archive (cold, on a remote disk) for rows it could not hold, and production's database saturated.
 *
 * <h2>The rule</h2>
 *
 * <p>The caller reads where its slivers begin and end from the statement's own `cut` CTE
 * (`usageRawSliversSql`, `vendorRawSliversSql`) -- a few index endpoints -- and {@link planRoute}
 * decides:
 *
 * <ul>
 *   <li>every non-empty sliver inside the hot tables: the statement as written (hot);</li>
 *   <li>none of them: through the `_all` views, exactly as before;</li>
 *   <li>a head in the archive and a tail in the hot days, on a statement that can route its slivers
 *       one by one (`UsageHourlyOptions.slivers`): each on its own;</li>
 *   <li>otherwise the views -- slower, never wrong.</li>
 * </ul>
 *
 * <p><strong>Never wrong because the bounds only move later.</strong> Between the pre-read and the
 * statement the watermark and the newest line can only advance, so a sliver's real start is at or
 * after the one read, and a start found hot stays hot. Where the old routing was already right --
 * a window inside the hot days, or a raw sliver that really reaches into the archive -- the plan
 * makes the same choice, so the answer is the one the statement always gave.
 */

import { CDR_EVERYTHING, cdrRouteChosen, cdrWindowIsHot, type CdrBoundary } from "./cdr-grain.ts";

/** One raw sliver, `[from, to)`. Empty when either end is missing or `from` is not before `to`. */
export interface Sliver {
  from: Date | null;
  to: Date | null;
}

export interface RawSlivers {
  head: Sliver;
  tail: Sliver;
}

export type RoutePlan =
  | { kind: "statement"; hot: boolean }
  | { kind: "split"; head: "hot" | "all"; tail: "hot" | "all" };

/** The pre-read's row (`head_from`, `head_to`, `tail_from`, `tail_to`) as slivers. */
export function sliversOf(row: Record<string, unknown> | undefined): RawSlivers {
  const at = (v: unknown): Date | null => {
    if (v == null) {
      return null;
    }
    const d = v instanceof Date ? v : new Date(String(v));
    return Number.isFinite(d.getTime()) ? d : null;
  };
  return {
    head: { from: at(row?.head_from), to: at(row?.head_to) },
    tail: { from: at(row?.tail_from), to: at(row?.tail_to) },
  };
}

export function sliverEmpty(s: Sliver): boolean {
  return s.from === null || s.to === null || s.from.getTime() >= s.to.getTime();
}

/**
 * The routing for a statement whose raw rows are `raw`.
 *
 * @param splittable whether the statement can route its head and tail separately -- only
 *     `usageHourlySql` with `slivers`; every other reader routes as a whole
 */
export function planRoute(raw: RawSlivers, boundary: CdrBoundary, o: { splittable: boolean }): RoutePlan {
  if (boundary === null) {
    //no tiers: one set of tables, the statement as written
    return { kind: "statement", hot: true };
  }
  if (boundary === CDR_EVERYTHING) {
    return { kind: "statement", hot: false };
  }
  const head = sliverEmpty(raw.head) ? null : cdrWindowIsHot(raw.head.from, boundary);
  const tail = sliverEmpty(raw.tail) ? null : cdrWindowIsHot(raw.tail.from, boundary);
  if (head === null && tail === null) {
    //no raw rows at all: nothing is read from the call records, so nothing needs the archive
    return { kind: "statement", hot: true };
  }
  if (head !== false && tail !== false) {
    return { kind: "statement", hot: true };
  }
  if (head !== true && tail !== true) {
    return { kind: "statement", hot: false };
  }
  //one in the archive, the other in the hot days
  return o.splittable && head !== null && tail !== null
    ? { kind: "split", head: head ? "hot" : "all", tail: tail ? "hot" : "all" }
    : { kind: "statement", hot: false };
}

/**
 * The statement to run for a plan. `build` makes the statement, given the slivers' routes when the
 * plan splits them; the result carries `CDR_ROUTED`, so `metrics-db.ts` runs it as it is.
 */
export function routedSql(plan: RoutePlan, build: (slivers?: { head: "hot" | "all"; tail: "hot" | "all" }) => string): string {
  if (plan.kind === "split") {
    //each sliver already names its own tables; the rest of the statement reads none
    return cdrRouteChosen(build({ head: plan.head, tail: plan.tail }), true);
  }
  return cdrRouteChosen(build(), plan.hot);
}
