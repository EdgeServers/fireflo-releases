/**
 * EP-01 SMPP Server — Bind & Session
 * US-01.01 Bind authentication by system_id, password and allowed IP
 *
 * Every case binds a real ESME (the `smpp` package) to the rig's listener. The oracles are
 * /ops/health for what is bound and auth-failed.log for what was refused — the file fail2ban reads,
 * which is why the line counts are exact.
 */
import { expect, test } from "../../fixtures";
import { awaitGatewayAdopts } from "../../fixtures/gateway";
import { BASELINE } from "../../fixtures/seed";
import { bindAttempt } from "../../fixtures/smpp";
import { authFailedLog, gatewayLog, smppServerLog } from "../../fixtures/trace";
import { bindA, sessionsOf, waitSessions } from "../../support/flows/gateway";
import { tc } from "../../support/tc";

const LISTENER = "smpp";
const A = BASELINE.logins.a;

test.describe("SC-01.01.01 Successful bind on each bind type", () => {
  test(...tc("TC-01.01.01-P01", "Transceiver bind accepted", { requires: ["gateway"] }), async ({ tcx }) => {
    const esme = await bindA({ bind: "trx" });
    try {
      expect(esme.bindStatus).toBe(0);
      const [s] = await waitSessions(LISTENER, A.systemId, 1);
      expect((s.bind_type ?? "").toUpperCase()).toContain("TRANSCEIVER");
      tcx.note(`bind_resp 0x00; /ops/health session bind_type=${s.bind_type} system_id=${s.system_id}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-01.01.01-P02", "Transmitter-only bind accepted", { requires: ["gateway"] }), async ({ tcx }) => {
    const esme = await bindA({ bind: "tx" });
    try {
      expect(esme.bindStatus).toBe(0);
      const [s] = await waitSessions(LISTENER, A.systemId, 1);
      expect((s.bind_type ?? "").toUpperCase()).toContain("TRANSMITTER");
      tcx.note(`bind_type=${s.bind_type}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-01.01.01-P03", "Receiver-only bind accepted", { requires: ["gateway", "edgesmsc"] }), async ({ db, tcx }) => {
    const rx = await bindA({ bind: "rx" });
    const tx = await bindA({ bind: "tx" });
    try {
      expect(rx.bindStatus).toBe(0);
      const s = await waitSessions(LISTENER, A.systemId, 2);
      expect(s.some((x) => (x.bind_type ?? "").toUpperCase().includes("RECEIVER"))).toBe(true);
      // a receipt for this account arrives on the RX session
      const r = await tx.submit({ registeredDelivery: 1 });
      expect(r.status).toBe(0);
      await db.waitForRow("SELECT 1 FROM cdr_final WHERE gateway_msg_id = $1", [r.messageId], { timeoutMs: 30_000 });
      const receipt = await rx.waitReceipt((x) => x.receiptedMessageId === r.messageId || x.text.includes(r.messageId!), 30_000);
      tcx.note(`RX bound; receipt for ${r.messageId} arrived on the RX session: ${receipt.text.slice(0, 80)}`);
    } finally {
      await tx.unbind();
      await rx.unbind();
    }
  });

  test(...tc("TC-01.01.01-P04", "Bind visible on Servers card", { requires: ["gateway"] }), async ({ page, tcx }) => {
    const esme = await bindA();
    try {
      await waitSessions(LISTENER, A.systemId, 1);
      await page.goto("/cp/servers");
      const card = page.locator("section, article, div").filter({ hasText: A.systemId }).first();
      await expect(card).toBeVisible();
      await expect(page.getByText(A.systemId).first()).toBeVisible();
      const first = await sessionsOf(LISTENER, A.systemId);
      await page.waitForTimeout(2500);
      const later = await sessionsOf(LISTENER, A.systemId);
      expect(Number(later[0].bound_seconds ?? 0)).toBeGreaterThan(Number(first[0].bound_seconds ?? 0));
      tcx.note(`Servers page names ${A.systemId}; bound_seconds ${first[0].bound_seconds} → ${later[0].bound_seconds}`);
    } finally {
      await esme.unbind();
    }
  });

  test(...tc("TC-01.01.01-N01", "Wrong password is 0x0E and is logged for fail2ban", { requires: ["gateway", "trace"] }), async ({ tcx }) => {
    const mark = authFailedLog.mark();
    const r = await bindAttempt({ systemId: A.systemId, password: "not-the-password" });
    expect(r.status).toBe(0x0e);
    const line = await authFailedLog.waitFor(/auth\.refused surface=smpp reason=badPassword identity="[^"]+" ip=\S+/, mark);
    expect(line[0]).toContain(`identity="${A.systemId}"`);
    expect(authFailedLog.count(/auth\.refused/, mark), "exactly one line per refusal").toBe(1);
    tcx.note(`0x0E; ${line[0].slice(line[0].indexOf("auth.refused"))}`);
  });

  test(...tc("TC-01.01.01-N02", "Unknown system_id is 0x0F", { requires: ["gateway", "trace"] }), async ({ tcx }) => {
    const mark = authFailedLog.mark();
    const r = await bindAttempt({ systemId: "does-not-exist", password: "whatever" });
    expect(r.status).toBe(0x0f);
    const line = await authFailedLog.waitFor(/auth\.refused surface=smpp reason=unknownIdentity identity="does-not-exist"/, mark);
    tcx.note(`0x0F; ${line[0].slice(line[0].indexOf("auth.refused"))}`);
  });

  test(...tc("TC-01.01.01-N03", "Disallowed source IP is refused even with correct password", { requires: ["gateway", "trace"] }), async ({ db, seed, tcx }) => {
    const login = await seed.credential({ accountId: BASELINE.accounts.a, product: BASELINE.product, allowedIps: ["10.99.0.0/16"] });
    // adopted once the identity is known: 0x0F is "who?", anything else means the row was loaded
    await awaitGatewayAdopts(async () => { const s = (await bindAttempt(login)).status; return s !== -1 && s !== 0x0f; });
    const mark = authFailedLog.mark();
    const refused = await bindAttempt(login);
    expect(refused.status, `bind from 127.0.0.1 with allowed_ips 10.99.0.0/16 answered 0x${refused.status.toString(16)}`).toBe(0x0d);
    await authFailedLog.waitFor(/reason=addressNotAllowed/, mark);
    // the credential itself is fine: allow this address and the same password binds
    await db.q("UPDATE app_credential SET allowed_ips = $1 WHERE id = $2", [["127.0.0.1"], login.id]);
    await awaitGatewayAdopts(async () => (await bindAttempt(login)).status === 0);
    tcx.note("0x0D with addressNotAllowed from 127.0.0.1; ESME_ROK once 127.0.0.1 is allowed");
  });

  test(...tc("TC-01.01.01-N04", "Disabled credential cannot bind", { requires: ["gateway"] }), async ({ db, seed, tcx }) => {
    const login = await seed.credential({ accountId: BASELINE.accounts.a, product: BASELINE.product });
    await awaitGatewayAdopts(async () => (await bindAttempt(login)).status === 0);
    await db.q("UPDATE app_credential SET enabled = false WHERE id = $1", [login.id]);
    await awaitGatewayAdopts(async () => (await bindAttempt(login)).status !== 0, { nudge: false, timeoutMs: 30_000 });
    const r = await bindAttempt(login);
    expect(r.status).not.toBe(0);
    expect((await sessionsOf(LISTENER, login.systemId)).length).toBe(0);
    tcx.note(`after one poll the disabled login is refused 0x${r.status.toString(16)}; no session`);
  });

  test(...tc("TC-01.01.01-N05", "Empty system_id is refused with a reason, not a crash", { requires: ["gateway", "trace"] }), async ({ tcx }) => {
    const mark = authFailedLog.mark();
    const r = await bindAttempt({ systemId: "", password: "x" });
    expect(r.status).not.toBe(0);
    // an empty system_id arrives as "" rather than null, so the gateway files it as an unknown identity
    // ("-") rather than a missing credential; both are a named refusal, which is what the case asks for
    const line = await authFailedLog.waitFor(/reason=(missingCredential|unknownIdentity identity="-")/, mark).catch(() => { throw new Error(`no refusal line for the empty system_id; auth-failed.log got: ${authFailedLog.lines(mark).join(" | ").slice(0, 300) || "nothing"}`); });
    // the listener still accepts the next valid bind
    const ok = await bindAttempt(A);
    expect(ok.status).toBe(0);
    tcx.note(`empty system_id → 0x${r.status.toString(16)} (${line[0].slice(line[0].indexOf("reason="), line[0].indexOf("reason=") + 24)}); next valid bind 0x00`);
  });

  test(...tc("TC-01.01.01-N06", "Refusal line never carries the password", { requires: ["gateway", "trace"] }), async ({ tcx }) => {
    const secret = `leak-me-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
    const marks = { auth: authFailedLog.mark(), main: gatewayLog.mark(), srv: smppServerLog.mark() };
    const r = await bindAttempt({ systemId: A.systemId, password: secret });
    expect(r.status).toBe(0x0e);
    const line = (await authFailedLog.waitFor(/reason=badPassword/, marks.auth)).input;
    expect(line).toContain(`identity="${A.systemId}"`);
    expect(line).toMatch(/ ip=\S+/);
    for (const [name, text] of [["auth-failed.log", authFailedLog.since(marks.auth)], ["smsg.log", gatewayLog.since(marks.main)], ["smppserver.log", smppServerLog.since(marks.srv)]] as const) {
      expect(text, `${name} must not carry the attempted password`).not.toContain(secret);
    }
    tcx.note("the attempted password appears in none of the three logs");
  });

  test(...tc.manual("TC-01.01.01-N07", "A refusal with no peer IP writes no auth.refused line", "needs a peer whose address the listener cannot resolve (a proxy that strips it); AuthRefusalTest covers the rule at unit level"));
  // Negative · P0
  // Steps:    1. Set allowed_ips on qa-acct-a-smpp to 10.99.0.0/16. 2. From 127.0.0.1 bind with the right password, then with a wrong one. 3. Compare the two bind_resp and the two auth.refused l
  // Expected: both 0x0000000D (ESME_RBINDFAIL); both lines reason=addressNotAllowed; no 0x0E and no reason=badPassword anywhere — the address is checked before the password
  // Oracle:   bind_resp; auth-failed.log
  // Vacuity:  Before 0.12.10 the wrong password answered 0x0E and the right one 0x0D, which told a caller outside the list whether the password was right; the two answers must be indistinguishab
  test(...tc.todo("TC-01.01.01-N08", "From outside the allow list the answer is the same whatever the password"));

});

test.describe("SC-01.01.02 Constant-time credential compare gives no timing oracle", () => {
  test(...tc("TC-01.01.02-P01", "Wrong passwords that differ early and late answer in comparable time", { requires: ["gateway"] }), async ({ tcx }) => {
    const time = async (opts: { systemId: string; password: string }) => {
      const t = process.hrtime.bigint();
      await bindAttempt(opts);
      return Number(process.hrtime.bigint() - t) / 1e6;
    };
    const badPw: number[] = [];
    const badSid: number[] = [];
    for (let i = 0; i < 25; i++) {
      badPw.push(await time({ systemId: A.systemId, password: "wrong-password-timing" }));
      badSid.push(await time({ systemId: `no-such-${i}`, password: "wrong-password-timing" }));
    }
    const median = (xs: number[]) => [...xs].sort((a, b) => a - b)[Math.floor(xs.length / 2)];
    const gap = Math.abs(median(badPw) - median(badSid));
    tcx.note(`median bad-password ${median(badPw).toFixed(1)}ms vs bad-system-id ${median(badSid).toFixed(1)}ms (gap ${gap.toFixed(1)}ms, n=25 each)`);
    expect(gap, "medians within 5 ms").toBeLessThan(5);
  });
});
