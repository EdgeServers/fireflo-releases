import * as React from "react";
import { AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * The three small pieces every reorganised card is built from.
 *
 * <p>Kept together because they are always used together: a card's header carries its actions on
 * the right ({@link CardActions}), its body shows a few labelled facts ({@link FactGrid}) and a row
 * of figures ({@link Figures}), and anything wrong with it is one line with one action
 * ({@link HealthStrip}). Each existed before as a slightly different hand-rolled block on each page.
 */

/**
 * The button group at a card header's right edge.
 *
 * <p>Not `shrink-0`: that was what made six routes scroll sideways on a phone -- a group of four
 * buttons refusing to shrink pushes its card to 420-650px. Under `sm` it takes the full row below
 * the title instead, which is where a thumb expects buttons anyway.
 */
export function CardActions({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "ml-auto flex min-w-0 flex-wrap items-center justify-end gap-1 max-sm:ml-0 max-sm:basis-full max-sm:justify-start",
        className
      )}
      {...props}
    />
  );
}

export interface Fact {
  label: string;
  value: React.ReactNode;
  /** Render the value in the muted colour: "none", "any", a fallback. */
  muted?: boolean;
  /** Monospace, for ids, hosts and TLV keys. */
  mono?: boolean;
}

/**
 * Labelled facts in a three-column grid. Values truncate rather than wrap, so a card keeps its
 * height whatever an address list or a TLV value contains; the full value is the title.
 */
export function FactGrid({ facts, columns = 3, className }: { facts: Fact[]; columns?: 2 | 3; className?: string }) {
  return (
    <dl className={cn("grid gap-x-4 gap-y-1.5 text-xs", columns === 3 ? "grid-cols-3" : "grid-cols-2", className)}>
      {facts.map((f) => (
        <div key={f.label} className="min-w-0">
          <dt className="text-2xs text-muted-foreground">{f.label}</dt>
          <dd
            className={cn(
              "truncate tabular-nums",
              f.muted ? "text-muted-foreground" : "text-foreground",
              f.mono && "font-mono"
            )}
            title={typeof f.value === "string" ? f.value : undefined}
          >
            {f.value}
          </dd>
        </div>
      ))}
    </dl>
  );
}

export interface Figure {
  value: React.ReactNode;
  label: string;
  tone?: "default" | "destructive" | "warning";
}

/** A row of numbers with a caption under each: "1,204 sent today · 0 refused". */
export function Figures({ figures, className }: { figures: Figure[]; className?: string }) {
  return (
    <div className={cn("flex flex-wrap gap-x-5 gap-y-2 text-xs text-muted-foreground", className)}>
      {figures.map((f) => (
        <span key={f.label} className="min-w-0">
          <b
            className={cn(
              "block text-base font-semibold leading-tight tabular-nums",
              f.tone === "destructive" ? "text-destructive" : f.tone === "warning" ? "text-warning" : "text-foreground"
            )}
          >
            {f.value}
          </b>
          {f.label}
        </span>
      ))}
    </div>
  );
}

/**
 * One sentence about something wrong, with the one action that addresses it on the right.
 *
 * <p>Replaces the full-width amber and red cards that used to sit above a list: a warning that
 * belongs to one card goes inside it, at the top, and takes one line.
 */
export function HealthStrip({
  tone = "warning",
  children,
  action,
  className,
}: {
  tone?: "warning" | "destructive" | "info";
  children: React.ReactNode;
  action?: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      role={tone === "destructive" ? "alert" : "status"}
      className={cn(
        "flex flex-wrap items-center gap-2 rounded-md px-3 py-2 text-xs",
        tone === "destructive"
          ? "bg-destructive-soft text-destructive"
          : tone === "info"
            ? "bg-info-soft text-info"
            : "bg-warning-soft text-warning",
        className
      )}
    >
      <AlertTriangle className="h-3.5 w-3.5 shrink-0" aria-hidden />
      {/* a basis, so on a phone the action wraps below the sentence instead of squeezing it */}
      <span className="min-w-0 flex-1 basis-60">{children}</span>
      {action && <span className="ml-auto shrink-0">{action}</span>}
    </div>
  );
}
