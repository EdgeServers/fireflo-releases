"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useSession } from "next-auth/react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { PageHeader } from "@/components/ui/page-header";
import { Segmented } from "@/components/ui/segmented";
import { StatTile } from "@/components/ui/stat-tile";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import { HealthStrip } from "@/components/CardBits";
import { NeedsCapability } from "@/components/NeedsCapability";
import { Pager } from "@/components/Pager";
import { useHealth } from "@/components/useHealth";
import { usePaging } from "@/components/usePaging";
import { SLOW_QUERY_LOG } from "@/lib/capabilities";
import { formatTimestamp } from "@/lib/datetime";
import { isAdminSession } from "@/lib/roles";
import {
  SLOW_WINDOWS,
  formatMs,
  shapeHeadline,
  type SlowQueriesPayload,
  type SlowWindow,
} from "@/lib/slow-queries";

/**
 * Database → Slow queries: the statements that ran longer than the gateway's threshold.
 *
 * <p>Two readings of one ring. The fold by shape answers "which statement is slow" -- a repeated
 * flush that is always a little over the line reads differently from one checkpoint that took a
 * minute -- and the raw list answers "when, and from where", with the caller the gateway recorded.
 * The header's count comes from the health poll the rest of the panel already runs, so the chip on
 * the Health page and the figure here are the same reading.
 *
 * <p>The ring is in the gateway's memory. Clearing it forgets evidence and is an admin's.
 */

const PAGE = 50;

export function SlowQueriesClient() {
  const { data: session } = useSession();
  const admin = isAdminSession(session);
  const { health, error: healthError, loading: healthLoading } = useHealth();
  const [range, setRange] = useState<SlowWindow>("24h");
  const [caller, setCaller] = useState("");
  const [minMs, setMinMs] = useState("");
  const [data, setData] = useState<SlowQueriesPayload | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [clearing, setClearing] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const q = new URLSearchParams({ window: range });
      if (caller.trim()) q.set("caller", caller.trim());
      if (/^\d+$/.test(minMs.trim())) q.set("minMs", minMs.trim());
      const res = await fetch(`/api/control/slow-queries?${q}`, { cache: "no-store" });
      const body = await res.json().catch(() => null);
      if (!res.ok) {
        throw new Error(body?.error ?? `Could not read the slow-query log (${res.status}).`);
      }
      setData(body.data as SlowQueriesPayload);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  }, [range, caller, minMs]);

  const supported = health != null && health.api?.[SLOW_QUERY_LOG] === true;
  useEffect(() => {
    if (supported) {
      //eslint-disable-next-line react-hooks/set-state-in-effect -- the first read, once the capability is known
      void load();
    }
  }, [supported, load]);

  const queries = useMemo(() => data?.queries ?? [], [data]);
  const paged = usePaging(queries, PAGE);
  const windowLabel = SLOW_WINDOWS.find((w) => w.value === range)!.label.toLowerCase();

  async function clear() {
    if (!window.confirm("Forget every slow statement the gateway holds? The ring starts again from empty.")) {
      return;
    }
    setClearing(true);
    try {
      const res = await fetch("/api/control/slow-queries", { method: "DELETE" });
      const body = await res.json().catch(() => null);
      if (!res.ok) {
        throw new Error(body?.error ?? "The gateway did not clear the log.");
      }
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setClearing(false);
    }
  }

  return (
    <>
      <PageHeader
        title="Slow queries"
        description="Database statements the gateway ran longer than its threshold, kept in its memory until it restarts."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Segmented
              label="Window"
              options={SLOW_WINDOWS.map((w) => ({ value: w.value, label: w.label }))}
              value={range}
              onChange={(next) => {
                setRange(next);
                paged.reset();
              }}
            />
            <Button variant="outline" onClick={() => void load()} disabled={loading || !supported}>
              {loading ? "Reading…" : "Refresh"}
            </Button>
            {admin && (
              <Button variant="outline" onClick={() => void clear()} disabled={clearing || !supported}
                title="Forget every slow statement the gateway holds">
                {clearing ? "Clearing…" : "Clear"}
              </Button>
            )}
          </div>
        }
      />

      <NeedsCapability health={health} loading={healthLoading} error={healthError} name={SLOW_QUERY_LOG} feature="a slow-query log">
        {error && <HealthStrip tone="destructive">{error}</HealthStrip>}

        <div className="grid gap-4 sm:grid-cols-3">
          <StatTile
            label="Threshold"
            value={data ? formatMs(data.summary.thresholdMs) : health?.db ? formatMs(health.db.slowThresholdMs) : "—"}
            hint="smsg.db.slow.ms: a statement at or over this is kept"
            loading={loading && !data}
          />
          <StatTile
            label="Last hour"
            value={String(health?.db?.slowLastHour ?? data?.summary.lastHour ?? 0)}
            hint="from the health poll, the same figure as the Health page's chip"
            tone={(health?.db?.slowLastHour ?? 0) > 0 ? "negative" : "default"}
          />
          <StatTile
            label={`In the last ${windowLabel}`}
            value={String(data?.summary.shapes.reduce((n, s) => n + s.count, 0) ?? 0)}
            hint={data ? `${data.summary.kept.toLocaleString()} kept in the ring altogether` : undefined}
            loading={loading && !data}
          />
        </div>

        <Card>
          <CardHeader className="flex-row flex-wrap items-center gap-2 space-y-0">
            <CardTitle className="text-base font-medium">By shape</CardTitle>
            <span className="text-xs text-muted-foreground">
              literals and parameters normalised, so repeats group; in the last {windowLabel}
            </span>
          </CardHeader>
          <CardContent>
            {!data?.summary.shapes.length ? (
              <p className="text-sm text-muted-foreground">{loading ? "Reading…" : `No slow statements in the last ${windowLabel}.`}</p>
            ) : (
              <TableInCard>
                <THead>
                  <tr>
                    <TH>Shape</TH>
                    <TH align="right">Count</TH>
                    <TH align="right">Max</TH>
                    <TH align="right">Mean</TH>
                    <TH>Last seen</TH>
                  </tr>
                </THead>
                <TBody>
                  {data.summary.shapes.map((s) => (
                    <TR key={s.shape}>
                      <TD className="max-w-xl">
                        <code className="block truncate font-mono text-xs" title={s.shape}>{shapeHeadline(s.shape)}</code>
                      </TD>
                      <TD num className="font-medium">{s.count.toLocaleString()}</TD>
                      <TD num>{formatMs(s.maxMs)}</TD>
                      <TD num>{formatMs(s.meanMs)}</TD>
                      <TD muted className="whitespace-nowrap text-xs" suppressHydrationWarning>{formatTimestamp(s.lastAt)}</TD>
                    </TR>
                  ))}
                </TBody>
              </TableInCard>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex-row flex-wrap items-end gap-3 space-y-0">
            <CardTitle className="text-base font-medium">Every statement</CardTitle>
            <div className="ml-auto flex flex-wrap items-end gap-2">
              <Field label="Caller contains" htmlFor="slow-caller" className="w-56">
                <Input id="slow-caller" value={caller} placeholder="cdr.CdrWriter"
                  onChange={(e) => setCaller(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") void load(); }} />
              </Field>
              <Field label="At least (ms)" htmlFor="slow-min" className="w-32">
                <Input id="slow-min" inputMode="numeric" value={minMs} placeholder={data ? String(data.summary.thresholdMs) : ""}
                  onChange={(e) => setMinMs(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") void load(); }} />
              </Field>
              <Button variant="outline" size="sm" onClick={() => void load()} disabled={loading}>Apply</Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {!queries.length ? (
              <p className="text-sm text-muted-foreground">{loading ? "Reading…" : "Nothing matches."}</p>
            ) : (
              <>
                <TableInCard>
                  <THead>
                    <tr>
                      <TH>Started</TH>
                      <TH align="right">Took</TH>
                      <TH>Caller</TH>
                      <TH>Shape</TH>
                      <TH align="right">Rows</TH>
                      <TH>Thread</TH>
                    </tr>
                  </THead>
                  <TBody>
                    {paged.shown.map((row, i) => (
                      <TR key={`${row.startedAt}-${row.thread}-${paged.page}-${i}`}>
                        <TD muted className="whitespace-nowrap text-xs" suppressHydrationWarning>{formatTimestamp(row.startedAt)}</TD>
                        <TD num className="font-medium">{formatMs(row.durationMs)}</TD>
                        <TD className="font-mono text-xs">{row.caller}</TD>
                        <TD className="max-w-md">
                          <code className="block truncate font-mono text-xs" title={row.shape}>{shapeHeadline(row.shape)}</code>
                        </TD>
                        <TD num muted>{row.updateCount ?? "—"}</TD>
                        <TD muted className="font-mono text-xs">{row.thread}</TD>
                      </TR>
                    ))}
                  </TBody>
                </TableInCard>
                <Pager page={paged.page} pages={paged.pages} total={queries.length} noun="statements" onPage={paged.setPage} />
              </>
            )}
          </CardContent>
        </Card>
      </NeedsCapability>
    </>
  );
}
