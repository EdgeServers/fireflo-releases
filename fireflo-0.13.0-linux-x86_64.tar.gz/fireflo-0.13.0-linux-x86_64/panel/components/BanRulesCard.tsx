"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import { HealthStrip } from "@/components/CardBits";
import { RULE_FIELD_LABELS, RULE_LIMITS, type BanRule } from "@/lib/ban-rules";
import type { BanRunEntry } from "@/lib/ban-rules-db";
import { blankRule } from "@/lib/refusal-views";
import { reasonLabel } from "@/lib/security-events";

/**
 * The rules that turn the refusal ledger into fail2ban bans, and what the last runs did.
 *
 * <p>Admin only, like the route under it: a rule bans at the host with nobody pressing anything.
 * The set is edited whole and saved whole, so the rules in force are exactly the rows on screen.
 * A new rule starts off and in dry run -- the safer of the two mistakes -- and the run log
 * underneath is how a dry run is read before it is switched live.
 */

interface Payload {
  rules: BanRule[];
  runs: BanRunEntry[];
  jails: string[];
  reasons: string[];
  nonBannable: string[];
  fail2banAvailable: boolean;
}

export function BanRulesCard() {
  const [data, setData] = useState<Payload | null>(null);
  const [rules, setRules] = useState<BanRule[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/control/security/rules", { cache: "no-store" });
      const body = await res.json().catch(() => null);
      if (!res.ok) {
        throw new Error(body?.error ?? `Could not read the ban rules (${res.status}).`);
      }
      const payload = body.data as Payload;
      setData(payload);
      setRules(payload.rules);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }, []);

  useEffect(() => {
    //eslint-disable-next-line react-hooks/set-state-in-effect -- the first read
    void load();
  }, [load]);

  const dirty = useMemo(() => JSON.stringify(rules) !== JSON.stringify(data?.rules ?? []), [rules, data]);
  const runs = useMemo(
    () => [...(data?.runs ?? [])].sort((a, b) => Date.parse(b.at) - Date.parse(a.at)).slice(0, 50),
    [data]
  );

  function patch(id: string, change: Partial<BanRule>) {
    setRules((all) => all.map((r) => (r.id === id ? { ...r, ...change } : r)));
    setSaved(null);
  }

  async function save() {
    setSaving(true);
    setSaved(null);
    try {
      const res = await fetch("/api/control/security/rules", {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ rules }),
      });
      const body = await res.json().catch(() => null);
      if (!res.ok) {
        throw new Error(body?.error ?? `The rules were not saved (${res.status}).`);
      }
      await load();
      setSaved("Saved. The runner evaluates every enabled rule once a minute.");
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setSaving(false);
    }
  }

  const jails = data?.jails ?? [];
  const bannable = (data?.reasons ?? []).filter((r) => !(data?.nonBannable ?? []).includes(r));

  return (
    <Card>
      <CardHeader className="flex-row flex-wrap items-center gap-2 space-y-0">
        <CardTitle className="text-base font-medium">Ban rules</CardTitle>
        <span className="text-xs text-muted-foreground">
          addresses the host bans on its own, from the ledger above, once a minute
        </span>
        <div className="ml-auto flex items-center gap-2">
          <Button variant="outline" size="sm" disabled={!data}
            onClick={() => { setRules((all) => [...all, blankRule(all, jails[0] ?? "fireflo-gateway")]); setSaved(null); }}>
            <Plus className="size-3.5" aria-hidden /> Add rule
          </Button>
          <Button size="sm" disabled={!dirty || saving} onClick={() => void save()}>
            {saving ? "Saving…" : "Save rules"}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && <HealthStrip tone="destructive">{error}</HealthStrip>}
        {saved && <HealthStrip tone="info">{saved}</HealthStrip>}
        {data && !data.fail2banAvailable && (
          <HealthStrip tone="warning">
            fail2ban is not reachable from this panel, so a live rule decides and records but cannot ban.
            Install the panel on the gateway host with fail2ban (fireflo-panel-install --with-fail2ban).
          </HealthStrip>
        )}
        {data && (
          <p className="text-xs text-muted-foreground">
            A rule with no reasons ticked counts every bannable reason. Left out unless ticked, because the
            caller&apos;s credential was accepted or an operator already holds it out:{" "}
            {data.nonBannable.map((r) => (
              <code key={r} className="mr-1 font-mono">{r}</code>
            ))}
          </p>
        )}

        {!data ? (
          <p className="text-sm text-muted-foreground">Reading…</p>
        ) : rules.length === 0 ? (
          <p className="text-sm text-muted-foreground">No rules. The host&apos;s own fail2ban jail still applies its maxretry.</p>
        ) : (
          <div className="space-y-3">
            {rules.map((rule) => (
              <div key={rule.id} className="rounded-lg border border-border p-3">
                <div className="mb-3 flex flex-wrap items-center gap-3">
                  <span className="font-mono text-xs text-muted-foreground">{rule.id}</span>
                  <label className="flex items-center gap-2 text-sm">
                    <Switch checked={rule.enabled} onChange={(next) => patch(rule.id, { enabled: next })} aria-label={`${RULE_FIELD_LABELS.enabled} ${rule.id}`} />
                    {RULE_FIELD_LABELS.enabled}
                  </label>
                  <label className="flex items-center gap-2 text-sm">
                    <Switch checked={rule.dryRun} onChange={(next) => patch(rule.id, { dryRun: next })} aria-label={`${RULE_FIELD_LABELS.dryRun} ${rule.id}`} />
                    {RULE_FIELD_LABELS.dryRun}
                  </label>
                  {rule.enabled && !rule.dryRun && <Badge variant="destructive">live</Badge>}
                  {rule.enabled && rule.dryRun && <Badge variant="info">dry run</Badge>}
                  <Button variant="ghost" size="sm" className="ml-auto" title="Remove this rule"
                    onClick={() => { setRules((all) => all.filter((r) => r.id !== rule.id)); setSaved(null); }}>
                    <Trash2 className="size-3.5" aria-hidden /> Remove
                  </Button>
                </div>
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
                  <Field label={RULE_FIELD_LABELS.name} htmlFor={`${rule.id}-name`}>
                    <Input id={`${rule.id}-name`} value={rule.name} maxLength={80} onChange={(e) => patch(rule.id, { name: e.target.value })} />
                  </Field>
                  <Field label={RULE_FIELD_LABELS.listener} htmlFor={`${rule.id}-listener`} hint="a worker name, or any">
                    <Input id={`${rule.id}-listener`} value={rule.listener} onChange={(e) => patch(rule.id, { listener: e.target.value })} />
                  </Field>
                  <Field label={RULE_FIELD_LABELS.threshold} htmlFor={`${rule.id}-threshold`}>
                    <Input id={`${rule.id}-threshold`} inputMode="numeric" value={String(rule.threshold)}
                      min={RULE_LIMITS.threshold.min} max={RULE_LIMITS.threshold.max}
                      onChange={(e) => patch(rule.id, { threshold: Number(e.target.value) })} />
                  </Field>
                  <Field label={RULE_FIELD_LABELS.windowMinutes} htmlFor={`${rule.id}-window`}>
                    <Input id={`${rule.id}-window`} inputMode="numeric" value={String(rule.windowMinutes)}
                      onChange={(e) => patch(rule.id, { windowMinutes: Number(e.target.value) })} />
                  </Field>
                  <Field label={RULE_FIELD_LABELS.banSeconds} htmlFor={`${rule.id}-ban`} hint="the jail's own bantime applies today">
                    <Input id={`${rule.id}-ban`} inputMode="numeric" value={String(rule.banSeconds)}
                      onChange={(e) => patch(rule.id, { banSeconds: Number(e.target.value) })} />
                  </Field>
                  <Field label={RULE_FIELD_LABELS.jail} htmlFor={`${rule.id}-jail`}>
                    <Select id={`${rule.id}-jail`} value={rule.jail} onChange={(e) => patch(rule.id, { jail: e.target.value })}>
                      {jails.map((j) => <option key={j} value={j}>{j}</option>)}
                    </Select>
                  </Field>
                </div>
                <fieldset className="mt-3">
                  <legend className="mb-1.5 text-xs font-semibold">{RULE_FIELD_LABELS.reasons}</legend>
                  <div className="flex flex-wrap gap-x-4 gap-y-1.5">
                    {[...bannable, ...(data.nonBannable ?? [])].map((reason) => {
                      const excluded = data.nonBannable.includes(reason);
                      const on = rule.reasons.includes(reason);
                      return (
                        <label key={reason} className={`flex items-center gap-1.5 text-xs ${excluded ? "text-muted-foreground" : ""}`}
                          title={excluded ? "Not counted unless ticked here" : reasonLabel(reason)}>
                          <Checkbox checked={on} onChange={(e) => patch(rule.id, {
                            reasons: e.target.checked ? [...rule.reasons, reason] : rule.reasons.filter((r) => r !== reason),
                          })} />
                          <span className="font-mono">{reason}</span>
                          {excluded && <span>(excluded)</span>}
                        </label>
                      );
                    })}
                  </div>
                </fieldset>
              </div>
            ))}
          </div>
        )}

        <div>
          <h4 className="mb-2 text-sm font-semibold">Last run</h4>
          {!runs.length ? (
            <p className="text-sm text-muted-foreground">No rule has decided anything yet.</p>
          ) : (
            <TableInCard>
              <THead>
                <tr>
                  <TH>When</TH>
                  <TH>Rule</TH>
                  <TH>Address</TH>
                  <TH>Jail</TH>
                  <TH>Outcome</TH>
                  <TH>Why</TH>
                </tr>
              </THead>
              <TBody>
                {runs.map((e, i) => (
                  <TR key={`${e.at}-${e.rule}-${e.ip}-${i}`}>
                    <TD muted className="whitespace-nowrap text-xs" suppressHydrationWarning>{new Date(e.at).toLocaleString()}</TD>
                    <TD className="font-mono text-xs">{e.rule}</TD>
                    <TD className="font-mono">{e.ip}</TD>
                    <TD muted className="text-xs">{e.jail}</TD>
                    <TD>
                      {e.banned ? (
                        <Badge variant="destructive">banned</Badge>
                      ) : e.dryRun ? (
                        <Badge variant="info">would ban</Badge>
                      ) : (
                        <Badge variant="warning" title={e.error ?? undefined}>not banned</Badge>
                      )}
                    </TD>
                    <TD muted className="max-w-md text-xs">{e.error ?? e.reason}</TD>
                  </TR>
                ))}
              </TBody>
            </TableInCard>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
