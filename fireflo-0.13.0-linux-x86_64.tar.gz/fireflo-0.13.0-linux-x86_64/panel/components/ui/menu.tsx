"use client";
import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * A button that opens a short list of actions beneath it.
 *
 * <p>The account menu in the top bar is the first user; `InfoPopover` is the closest relative but
 * it is a tooltip, read and dismissed, where this holds things to click. Items are ordinary
 * buttons and links rather than `menuitem`s on purpose: the e2e suite, and anyone with a screen
 * reader, finds "Sign out" as a button, and a list of three actions does not need the roving
 * tabindex a true menu widget owes its users. Escape and a click outside close it; arrow keys
 * move between items.
 */
export function Menu({
  label,
  trigger,
  align = "end",
  className,
  children,
}: {
  /** The accessible name of the button, e.g. "Account menu". */
  label: string;
  /** What the button shows. */
  trigger: React.ReactNode;
  align?: "start" | "end";
  className?: string;
  children: React.ReactNode;
}) {
  const [open, setOpen] = React.useState(false);
  const root = React.useRef<HTMLDivElement>(null);
  const button = React.useRef<HTMLButtonElement>(null);
  const id = React.useId();

  React.useEffect(() => {
    if (!open) {
      return;
    }
    function onKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setOpen(false);
        button.current?.focus();
        return;
      }
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        const items = Array.from(
          root.current?.querySelectorAll<HTMLElement>('[data-menu-panel] a[href], [data-menu-panel] button:not([disabled])') ?? []
        );
        if (!items.length) {
          return;
        }
        event.preventDefault();
        const at = items.indexOf(document.activeElement as HTMLElement);
        const next = event.key === "ArrowDown" ? (at + 1) % items.length : (at - 1 + items.length) % items.length;
        items[next].focus();
      }
    }
    function onPointerDown(event: PointerEvent) {
      if (!root.current?.contains(event.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("keydown", onKeyDown);
    document.addEventListener("pointerdown", onPointerDown);
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.removeEventListener("pointerdown", onPointerDown);
    };
  }, [open]);

  return (
    <div ref={root} className={cn("relative", className)}>
      <button
        ref={button}
        type="button"
        aria-label={label}
        aria-haspopup="true"
        aria-expanded={open}
        aria-controls={open ? id : undefined}
        onClick={() => setOpen((v) => !v)}
        className="flex items-center rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        {trigger}
      </button>
      {open && (
        <div
          id={id}
          data-menu-panel
          //closed on any click inside: every item either navigates or opens something else
          onClick={() => setOpen(false)}
          className={cn(
            "absolute top-full z-50 mt-1.5 w-60 rounded-lg border border-border bg-popover p-1 text-sm text-popover-foreground shadow-lg",
            align === "end" ? "right-0" : "left-0"
          )}
        >
          {children}
        </div>
      )}
    </div>
  );
}

/** One row of a Menu: a button or, with `href`, a link. */
export function MenuItem({
  href,
  icon: Icon,
  destructive = false,
  onClick,
  children,
}: {
  href?: string;
  icon?: React.ElementType;
  destructive?: boolean;
  onClick?: () => void;
  children: React.ReactNode;
}) {
  const className = cn(
    "flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-left text-sm transition-colors md:py-1.5",
    destructive ? "text-destructive hover:bg-destructive-soft" : "text-foreground hover:bg-muted"
  );
  const body = (
    <>
      {Icon && <Icon className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />}
      <span className="min-w-0 flex-1 truncate">{children}</span>
    </>
  );
  return href ? (
    <a href={href} className={className} onClick={onClick}>{body}</a>
  ) : (
    <button type="button" className={className} onClick={onClick}>{body}</button>
  );
}

/** A non-interactive line at the top of a Menu: who this is, what they are. */
export function MenuHeading({ children }: { children: React.ReactNode }) {
  return <div className="border-b border-border px-2.5 pb-2 pt-1.5 text-xs leading-tight">{children}</div>;
}
