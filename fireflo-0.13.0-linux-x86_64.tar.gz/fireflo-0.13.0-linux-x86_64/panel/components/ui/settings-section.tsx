import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

/**
 * One titled card of settings, with an anchor a jump list can scroll to.
 *
 * <p>Shared by the Gateway and Error codes pages. `bodyClassName` replaces the default divided rows
 * for a section whose body is one block rather than a list of rows.
 */
export function SettingsSection({
  id,
  title,
  description,
  action,
  bodyClassName,
  children,
}: {
  /** Anchored as `gw-<id>`, the prefix the Gateway page's jump list already uses. */
  id: string;
  title: ReactNode;
  description?: ReactNode;
  /** A control that belongs in the header, at its right. */
  action?: ReactNode;
  bodyClassName?: string;
  children: ReactNode;
}) {
  return (
    <section id={`gw-${id}`} aria-labelledby={`gw-${id}-title`} className="scroll-mt-4 rounded-xl border border-border bg-card">
      <header className="flex flex-wrap items-start gap-3 border-b border-border px-4 py-3 md:px-5">
        <div className="min-w-0 flex-[1_1_240px]">
          <h2 id={`gw-${id}-title`} className="text-sm font-semibold">{title}</h2>
          {description && <div className="mt-0.5 text-xs text-muted-foreground">{description}</div>}
        </div>
        {action && <div className="flex shrink-0 flex-wrap items-center gap-2">{action}</div>}
      </header>
      <div className={cn(bodyClassName ?? "divide-y divide-border")}>{children}</div>
    </section>
  );
}
