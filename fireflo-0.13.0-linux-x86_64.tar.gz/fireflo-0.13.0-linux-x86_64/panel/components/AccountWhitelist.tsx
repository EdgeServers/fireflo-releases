"use client";
import { useState } from "react";
import { Plus, ShieldCheck, ShieldAlert, ShieldOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle,
} from "@/components/ui/card";
import { Dialog } from "@/components/ui/dialog";
import { Select } from "@/components/ui/select";
import { ErrorCard, WarningNote } from "./FormNotices";
import { HeaderForm } from "./HeaderForm";
import { TemplateForm } from "./TemplateForm";
import {
  LoginBadge, RegistrationList, StampList, TlvProposal,
} from "./RegistrationList";
import { Badge } from "@/components/ui/badge";
import { WhitelistStatusBadge } from "./WhitelistReview";
import { parseTlvCsv } from "@/lib/tlv-string";

import { SearchInput } from "./SearchInput";
import { useProducts } from "./useProducts";
import { useTlvDefinitions } from "./useTlvDefinitions";
import { useWhitelist } from "./useWhitelist";
import { useConfirmChange } from "./ConfirmProvider";
import { MoveToAccountDialog } from "./MoveToAccountDialog";
import { HealthStrip } from "./CardBits";
import {
  rowTlvGaps,
  tlvGapFixes,
  tlvGapSentence,
  vendorsForProduct,
} from "@/lib/tlv-coverage";
import {
  effectiveMode,
  enforcementReadiness,
  previewTemplate,
  type ApprovedHeader,
  type ApprovedTemplate,
  type WhitelistMode,
} from "@/lib/whitelist-types";

/**
 * One account's approved sender IDs and content, with the switch that decides whether they bite.
 *
 * <p><strong>The mode control lives next to the list it depends on, and that placement is the whole
 * design.</strong> An empty approved list with the mode at ENFORCE means the customer sends nothing
 * at all — which is the correct reading of a whitelist and also the single mistake in this feature
 * that produces a total outage. Putting the count and the switch side by side is what makes that
 * combination visible at the moment somebody reaches for it; the server refuses it as well, because
 * a warning in a form gets dismissed.
 *
 * <p><strong>The switch is in the footer of the list it governs.</strong> Two cards, one per list,
 * each carrying its own count in the title and its own mode in the footer. Earlier shapes put the
 * two switches in a third card of their own, which reads as tidier and is worse: it separated the
 * mode from the count that makes it dangerous, so the reader had to hold "ENFORCE" and "0 approved"
 * in their head across two containers. Now they are eight lines apart in the same box.
 *
 * <p>Both cards share one {@link useWhitelist} call, which is what lets each footer send the other
 * list's mode unchanged — `app_whitelist_policy` stores both on one row — and what stops the counts
 * and the lists disagreeing.
 */
export function AccountWhitelistSection({ accountId }: { accountId: string }) {
  return <Body accountId={accountId} />;
}

function Body({ accountId }: { accountId: string }) {
  const {
    headers, templates, summaries, coverage, logins: accountLogins, error, loading, busy, load,
    saveHeader, saveTemplate, removeHeader, removeTemplate, savePolicy, review, decideTlvs,
  } = useWhitelist(accountId);
  //one fetch for the section rather than one per form, the same way `CredentialForm` is handed its
  //product list rather than going for its own. Catalogue plus orphans, so a product that exists only
  //on rows is still offerable
  const { products: catalogue, orphans: productOrphans } = useProducts();
  const confirm = useConfirmChange();
  //the sender ID or template being moved to another account, and what the last move said
  const [movingRow, setMovingRow] = useState<{ kind: "headers" | "templates"; id: number; name: string; note?: string } | null>(null);
  const [movedNote, setMovedNote] = useState("");
  //one call for the section, the way useProducts is one call -- CredentialForm does the same. The
  //editors need it so a token resolves against operator-defined names as well as the built-ins
  const { definitions: tlvDefinitions, suggested: tlvSuggested } = useTlvDefinitions();
  const products = [...new Set([...catalogue.map((p) => p.name), ...productOrphans])].sort();
  //from the route's own `logins` key. It used to read coverage.logins, which loadCoverage returns
  //empty unless some listener declares a mandatory TLV -- so on most deployments the picker this
  //milestone exists for offered nothing at all
  const logins = accountLogins;

  const [editingHeader, setEditingHeader] = useState<"new" | number | null>(null);
  const [editingTemplate, setEditingTemplate] = useState<"new" | number | null>(null);
  //one query per card. A single shared box would filter a list the operator is not looking at
  const [headerQuery, setHeaderQuery] = useState("");
  const [templateQuery, setTemplateQuery] = useState("");
  //one per section, not one shared. A refusal about templates rendered under the sender ID card was
  //how the operator ended up reading an error for a control they had not touched
  const [policyError, setPolicyError] = useState({ header: "", content: "" });
  //keyed by kind and id, so a 409 on one proposal does not paint an error under every other row
  const [tlvError, setTlvError] = useState<Record<string, string>>({});
  //silent until somebody scopes a row: a badge saying "all logins" on every row of every account is
  //a column with one value in it
  const anyHeaderScoped = headers.some((h) => h.systemId);
  const anyTemplateScoped = templates.some((t) => t.systemId);

  //the outage this feature makes possible, named before somebody builds it: a login with no
  //account-wide approvals AND none of its own can send nothing at all once enforcement is on.
  //
  //Computed here from rows already fetched rather than pushed into `enforcementReadiness`, and the
  //limit is worth knowing: that function decides whether ENFORCE may be SAVED and is scoped to
  //(account, product), so it still counts a login-bound row as coverage for the whole scope. This
  //warning is what stands between an operator and that gap until the guard itself is login-aware.
  const uncovered = (rows: { systemId: string | null; status: string; enabled: boolean }[]) => {
    const live = rows.filter((r) => r.status === "APPROVED" && r.enabled);
    if (!live.length || live.some((r) => !r.systemId)) {
      return [];
    }
    const covered = new Set(live.map((r) => r.systemId));
    return logins.filter((l) => !covered.has(l));
  };
  const headerGap = uncovered(headers);
  const templateGap = uncovered(templates);

  async function decide(kind: "headers" | "templates", id: number, accept: boolean) {
    if (!(await confirm({
      title: accept ? "Accept these TLVs?" : "Decline these TLVs?",
      consequence: `${accept ? "Accepts" : "Declines"} the TLVs on this ${kind === "headers" ? "sender ID" : "content"} ` +
        `for ${accountId}.`,
      confirmLabel: accept ? "Accept" : "Decline",
    }))) {
      return;
    }
    const problem = await decideTlvs(kind, id, accept);
    setTlvError((prev) => ({ ...prev, [`${kind}:${id}`]: problem ?? "" }));
  }
  const [savedWarning, setSavedWarning] = useState({ header: "", content: "" });

  //the account-wide row. Product-specific rows are edited from the rows themselves
  const summary = summaries.find((s) => s.accountId === accountId && s.product === "");
  const headerMode = summary?.headerMode ?? "OFF";
  const contentMode = summary?.contentMode ?? "OFF";

  //the same predicate the gateway's DbWhitelistLoader uses. An approval filed under one of these
  //protects nothing, so it must not be counted towards "may this account enforce"
  const exemptProducts = catalogue.filter((p) => p.enabled && !p.whitelistEnabled).map((p) => p.name);

  //counted by the shared rule rather than here, so the number in the title, the number the footer
  //disables on and the number the server checks cannot disagree -- which is exactly what they were
  //doing: this used to be headers.filter(h => h.enabled), every product and any status, so a
  //customer's PENDING request read as approved
  const headerNow = enforcementReadiness(summaries, accountId, "", "header", headerMode, exemptProducts);
  const contentNow = enforcementReadiness(summaries, accountId, "", "content", contentMode, exemptProducts);
  const headerIfEnforced = enforcementReadiness(summaries, accountId, "", "header", "ENFORCE", exemptProducts);
  const contentIfEnforced = enforcementReadiness(summaries, accountId, "", "content", "ENFORCE", exemptProducts);

  const pendingHeaders = headers.filter((h) => h.status === "PENDING").length;
  const pendingTemplates = templates.filter((t) => t.status === "PENDING").length;

  /**
   * The mandatory tags this row will not deliver, in the operator's words.
   *
   * <p>The mode comes from `effectiveMode` for the row's own product, not from the account scope:
   * a product-scoped row is governed by the merge, and a row whose list is not checked stamps
   * nothing however well it is filled in.
   */
  function gapsFor(row: { tlvs: string | null; product: string }, kind: "header" | "content") {
    //the other list's rows for this same scope: a message is stamped by both matches, so a sender ID
    //must not be blamed for a Template ID some template already carries
    const other = kind === "header" ? "content" : "header";
    const siblingRows = (kind === "header" ? templates : headers)
      .filter((r) => r.status === "APPROVED" && r.enabled
        && (!row.product || !r.product || r.product === row.product));
    const gaps = rowTlvGaps({
      tlvs: row.tlvs,
      accountId,
      product: row.product,
      kind,
      mode: effectiveMode(summaries, accountId, row.product, kind),
      mandatory: coverage.mandatory,
      logins: coverage.logins,
      vendors: vendorsForProduct(coverage.vendors, row.product),
      siblings: {
        mode: effectiveMode(summaries, accountId, row.product, other),
        tlvs: siblingRows.map((r) => r.tlvs),
      },
    });
    return gaps.map((gap) => ({ text: tlvGapSentence(gap, kind), fixes: tlvGapFixes(gap) }));
  }

  async function setMode(which: "header" | "content", mode: WhitelistMode) {
    const current = which === "header" ? headerMode : contentMode;
    if (!(await confirm({
      title: `Change ${which === "header" ? "sender ID" : "content"} checking?`,
      consequence: mode === "ENFORCE"
        ? `${accountId} can send only ${which === "header" ? "from approved sender IDs" : "approved content"} ` +
          "from the gateway's next poll."
        : `Changes how ${accountId}'s ${which === "header" ? "sender IDs" : "content"} are checked.`,
      confirmLabel: "Change",
      tone: "caution",
      changes: [{ label: which === "header" ? "Sender ID checking" : "Content checking", from: current, to: mode }],
    }))) {
      return;
    }
    const { error: failure, warnings } = await savePolicy(accountId, "", which, mode);
    setPolicyError((prev) => ({ ...prev, [which]: failure ?? "" }));
    setSavedWarning((prev) => ({ ...prev, [which]: failure ? "" : warnings.join(" ") }));
  }

  return (
    <>
      <ErrorCard error={error} />
      {movedNote && <HealthStrip tone="info">{movedNote}</HealthStrip>}
      {movingRow && (
        <MoveToAccountDialog
          what={movingRow.kind === "headers" ? "sender ID" : "template"}
          name={movingRow.name}
          from={accountId}
          note={[movingRow.note, "Its approval is kept."].filter(Boolean).join(" ")}
          endpoint={`/api/control/whitelist/${movingRow.kind}/${movingRow.id}/move`}
          onClose={() => setMovingRow(null)}
          onMoved={(r) => {
            setMovedNote(`${movingRow.kind === "headers" ? "Sender ID" : "Template"} ${movingRow.name} moved to ${r.to}.`);
            setMovingRow(null);
            void load();
          }}
        />
      )}

      <Section
        title="Approved sender IDs"
        description="What this account may send from."
        addLabel="Approve a sender ID"
        count={headerNow.approved}
        pending={pendingHeaders}
        loading={loading}
        mode={headerMode}
        canEnforce={!headerIfEnforced.refuse}
        busy={busy === `${accountId}:header`}
        policyError={policyError.header}
        warning={savedWarning.header || headerNow.warn || ""}
        onModeChange={(m) => setMode("header", m)}
        onAdd={() => setEditingHeader("new")}
        search={headers.length > 0 ? (
          <SearchInput
            value={headerQuery}
            onChange={setHeaderQuery}
            placeholder="sender ID, product, stamp"
            ariaLabel="Search approved sender IDs"
            className="w-44"
          />
        ) : null}
      >
        {/*a dialog rather than a panel wedged above the list. The form is long enough to push the
           list out of view, and on a card whose whole point is now "the row you opened", an editor
           that appears somewhere else entirely broke that. Same move CredentialForm already made.
           Escape, the focus trap and focus return come from `Dialog`*/}
        <Dialog
          open={editingHeader !== null}
          onClose={() => setEditingHeader(null)}
          title={typeof editingHeader === "number"
            ? `Edit ${headers.find((h) => h.id === editingHeader)?.header ?? "sender ID"}`
            : "Approve a sender ID"}
        >
          <HeaderForm
            accountId={accountId}
            products={products}
            logins={logins}
            definitions={tlvDefinitions}
            suggested={tlvSuggested}
            editing={typeof editingHeader === "number"
              ? headers.find((h) => h.id === editingHeader) ?? null : null}
            busy={Boolean(busy)}
            onSave={async (input) => {
              if (!(await confirm({
                title: "Save this sender ID?",
                consequence: `Saves the sender ID for ${accountId}; the gateway checks against it from its next poll.`,
                confirmLabel: "Save",
              }))) {
                return "";
              }
              const failure = await saveHeader(input);
              if (!failure) {
                setEditingHeader(null);
              }
              return failure;
            }}
            onCancel={() => setEditingHeader(null)}
          />
        </Dialog>
        {headerGap.length > 0 && (
          <div className="mb-3">
            <WarningNote warnings={[
              `${headerGap.join(", ")} ${headerGap.length === 1 ? "has" : "have"} no approved `
              + "sender ID: every approval here is bound to another login. Under ENFORCE that login "
              + "can send nothing at all. Approve one for it, or leave an approval on every login.",
            ]} />
          </div>
        )}
        <RegistrationList<ApprovedHeader>
          rows={headers}
          query={headerQuery}
          noun="sender IDs"
          busy={busy}
          haystack={(h) =>
            [h.header, h.product, h.label ?? "", h.tlvs ?? "", h.requestedTlvs ?? "",
              h.systemId ?? "", h.requestNote ?? ""].join(" ")}
          nameOf={(h) => h.header}
          gapsOf={(h) => gapsFor(h, "header")}
          columns={[
            { id: "header", header: "Sender ID", width: "auto", sortBy: (h) => h.header,
              cell: (h) => <span className="font-mono text-primary">{h.header}</span> },
            { id: "product", header: "Product", width: "8rem", sortBy: (h) => h.product,
              cell: (h) => <ProductBadge product={h.product} /> },
            //only when at least one row is login-scoped: a column reading "all" on every row is a
            //column that costs width and says nothing
            ...(anyHeaderScoped
              ? [{ id: "login", header: "Login", width: "8rem",
                   sortBy: (h: ApprovedHeader) => h.systemId,
                   cell: (h: ApprovedHeader) => <LoginBadge systemId={h.systemId} /> }]
              : []),
            { id: "stamps", header: "Stamps", width: "5rem", align: "right" as const,
              sortBy: (h) => parseTlvCsv(h.tlvs).length,
              cell: (h) => {
                const n = parseTlvCsv(h.tlvs).length;
                return n === 0
                  ? <span className="text-warning">0</span>
                  : <span className="tabular-nums">{n}</span>;
              } },
            { id: "status", header: "Status", width: "7rem", sortBy: (h) => h.status,
              cell: (h) => <WhitelistStatusBadge status={h.status} enabled={h.enabled} /> },
          ]}
          renderDetail={(h) => (h.tlvs || h.requestedTlvs || h.label || h.requestNote ? (
            <div className="space-y-1">
              {h.requestedTlvs && (
                <TlvProposal
                  current={h.tlvs}
                  proposed={h.requestedTlvs}
                  busy={busy === String(h.id)}
                  error={tlvError[`headers:${h.id}`]}
                  onDecide={(accept) => void decide("headers", h.id, accept)}
                />
              )}
              {h.tlvs && (
                <div>
                  <FieldLabel>Stamps</FieldLabel>
                  <StampList tlvs={h.tlvs} />
                </div>
              )}
              {h.label && <p className="text-xs text-muted-foreground">{h.label}</p>}
              {/*what the customer said about it -- under DLT their registration reference, which is
                 the thing being checked before this is approved*/}
              {h.requestNote && (
                <p className="text-xs text-muted-foreground">asked for: {h.requestNote}</p>
              )}
            </div>
          ) : null)}
          deleteTitle="Withdraw this sender ID"
          deleteConfirmLabel="Withdraw"
          deleteConsequence={(h) =>
            `If this account is enforcing sender IDs, it can no longer send from '${h.header}' `
            + "once the gateway next polls."}
          emptyMessage={
            "Nothing approved. While the mode is OFF that changes nothing; under ENFORCE it means "
            + "this account can send nothing at all."
          }
          onEdit={(h) => setEditingHeader(h.id)}
          onDelete={(h) => removeHeader(h.id)}
          onMove={(h) => setMovingRow({ kind: "headers", id: h.id, name: h.header,
            note: h.systemId ? `It is scoped to the login '${h.systemId}', so it moves only once its login is cleared.` : undefined })}
          onReview={async (h, status, note) => {
            if (!(await confirm({
              title: `Mark this sender ID ${String(status).toLowerCase()}?`,
              consequence: `Records the decision on this sender ID for ${accountId}.`,
              confirmLabel: "Confirm",
            }))) {
              return;
            }
            void review("headers", h.id, status, note);
          }}
        />
      </Section>

      <Section
        title="Approved content"
        description="What this account may say."
        addLabel="Approve a template"
        count={contentNow.approved}
        pending={pendingTemplates}
        loading={loading}
        mode={contentMode}
        canEnforce={!contentIfEnforced.refuse}
        busy={busy === `${accountId}:content`}
        policyError={policyError.content}
        warning={savedWarning.content || contentNow.warn || ""}
        onModeChange={(m) => setMode("content", m)}
        onAdd={() => setEditingTemplate("new")}
        search={templates.length > 0 ? (
          <SearchInput
            value={templateQuery}
            onChange={setTemplateQuery}
            placeholder="name, wording, stamp"
            ariaLabel="Search approved content"
            className="w-44"
          />
        ) : null}
      >
        {/*wider than the sender ID dialog: a template body is a paragraph, and editing wording in a
           narrow box is how a template ends up with wrapping nobody intended*/}
        <Dialog
          open={editingTemplate !== null}
          onClose={() => setEditingTemplate(null)}
          className="max-w-2xl"
          title={typeof editingTemplate === "number"
            ? `Edit ${templates.find((t) => t.id === editingTemplate)?.name || "template"}`
            : "Approve a template"}
        >
          <TemplateForm
            accountId={accountId}
            products={products}
            logins={logins}
            definitions={tlvDefinitions}
            suggested={tlvSuggested}
            editing={typeof editingTemplate === "number"
              ? templates.find((t) => t.id === editingTemplate) ?? null : null}
            busy={Boolean(busy)}
            onSave={async (input) => {
              if (!(await confirm({
                title: "Save this content?",
                consequence: `Saves the content for ${accountId}; the gateway checks against it from its next poll.`,
                confirmLabel: "Save",
              }))) {
                return "";
              }
              const failure = await saveTemplate(input);
              if (!failure) {
                setEditingTemplate(null);
              }
              return failure;
            }}
            onCancel={() => setEditingTemplate(null)}
          />
        </Dialog>
        {templateGap.length > 0 && (
          <div className="mb-3">
            <WarningNote warnings={[
              `${templateGap.join(", ")} ${templateGap.length === 1 ? "has" : "have"} no approved `
              + "wording: every template here is bound to another login. Under ENFORCE that login "
              + "can send nothing at all.",
            ]} />
          </div>
        )}
        <RegistrationList<ApprovedTemplate>
          rows={templates}
          query={templateQuery}
          noun="templates"
          busy={busy}
          haystack={(t) =>
            [t.name ?? "", t.body, t.product, t.label ?? "", t.tlvs ?? "", t.requestedTlvs ?? "",
              t.systemId ?? "", t.requestNote ?? ""].join(" ")}
          nameOf={(t) => t.name || "Untitled"}
          gapsOf={(t) => gapsFor(t, "content")}
          columns={[
            { id: "name", header: "Name", width: "11rem", sortBy: (t) => t.name ?? "",
              cell: (t) => <span className="font-medium text-primary">{t.name || "Untitled"}</span> },
            /* the wording gets the column that absorbs the slack, and wraps rather than truncating.
               A template called "Shipment" identifies nothing -- the body is what an operator
               recognises and what the gateway actually matches, so cutting it off would hide the
               only part that matters. It does not sort: ordering messages by their first character
               is not a question anybody has */
            { id: "body", header: "Wording", width: "auto",
              cell: (t) => (
                <span className="block break-words font-mono text-sm text-foreground/80">
                  {t.body}
                </span>
              ) },
            { id: "product", header: "Product", width: "8rem", sortBy: (t) => t.product,
              cell: (t) => <ProductBadge product={t.product} /> },
            ...(anyTemplateScoped
              ? [{ id: "login", header: "Login", width: "8rem",
                   sortBy: (t: ApprovedTemplate) => t.systemId,
                   cell: (t: ApprovedTemplate) => <LoginBadge systemId={t.systemId} /> }]
              : []),
            { id: "status", header: "Status", width: "7rem", sortBy: (t) => t.status,
              cell: (t) => <WhitelistStatusBadge status={t.status} enabled={t.enabled} /> },
          ]}
          renderDetail={(t) => (
            <div className="space-y-1">
              <div>
                <FieldLabel>Accepts</FieldLabel>
                <p className="break-words font-mono text-sm text-muted-foreground">
                  {previewTemplate(t.body)}
                </p>
              </div>
              {t.requestedTlvs && (
                <TlvProposal
                  current={t.tlvs}
                  proposed={t.requestedTlvs}
                  busy={busy === String(t.id)}
                  error={tlvError[`templates:${t.id}`]}
                  onDecide={(accept) => void decide("templates", t.id, accept)}
                />
              )}
              {t.tlvs && (
                <div>
                  <FieldLabel>Stamps</FieldLabel>
                  <StampList tlvs={t.tlvs} />
                </div>
              )}
              {t.requestNote && (
                <p className="text-xs text-muted-foreground">asked for: {t.requestNote}</p>
              )}
            </div>
          )}
          deleteTitle="Withdraw this template"
          deleteConfirmLabel="Withdraw"
          deleteConsequence={() =>
            "If this account is enforcing content, messages using this wording stop being accepted "
            + "once the gateway next polls."}
          emptyMessage={
            "Nothing approved. While the mode is OFF that changes nothing; under ENFORCE it means "
            + "this account can send nothing at all."
          }
          onEdit={(t) => setEditingTemplate(t.id)}
          onDelete={(t) => removeTemplate(t.id)}
          onMove={(t) => setMovingRow({ kind: "templates", id: t.id, name: t.name ?? `#${t.id}`,
            note: t.systemId ? `It is scoped to the login '${t.systemId}', so it moves only once its login is cleared.` : undefined })}
          onReview={async (t, status, note) => {
            if (!(await confirm({
              title: `Mark this content ${String(status).toLowerCase()}?`,
              consequence: `Records the decision on this content for ${accountId}.`,
              confirmLabel: "Confirm",
            }))) {
              return;
            }
            void review("templates", t.id, status, note);
          }}
        />
      </Section>
    </>
  );
}

/**
 * The product a row is filed under, as a badge rather than loose grey text.
 *
 * <p>It is a code — `in-otp`, `standard` — and a code beside a name reads as part of the name until
 * something separates them. "All products" is the same badge in the same place, because an
 * any-product row is a scope like any other and the blank it used to render as looked like missing
 * data rather than the widest scope there is.
 */
function ProductBadge({ product }: { product: string }) {
  return (
    <Badge variant="outline" className="px-1.5 py-0 text-xs font-normal text-muted-foreground">
      {product || "all products"}
    </Badge>
  );
}

/** One label treatment for every pair in these cards, so no two drift apart. */
function FieldLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-2xs uppercase tracking-wider text-muted-foreground">{children}</p>
  );
}

/**
 * The enforcement switch for one list, in that list's footer.
 *
 * <p>ENFORCE is disabled outright when nothing is approved, and the reason is spelled out rather
 * than left to a tooltip, because the operator's next question is always "then how do I turn this
 * on". The server refuses the same combination independently
 * (`app/api/control/whitelist/policy/route.ts`) — this is the courtesy, not the guard.
 *
 * <p>No label: the card title says which list this governs, and no count either, for the same
 * reason. What is left is the state, the consequence, and the control.
 */
function EnforcementFooter({
  title,
  mode,
  canEnforce,
  busy,
  error,
  warning,
  onChange,
}: {
  title: string;
  mode: WhitelistMode;
  canEnforce: boolean;
  busy: boolean;
  error: string;
  warning: string;
  onChange: (mode: WhitelistMode) => void;
}) {
  const Icon = mode === "ENFORCE" ? ShieldCheck : mode === "REPORT" ? ShieldAlert : ShieldOff;
  //"enforcing with nothing that can protect anything" -- the same verdict the server reaches, from
  //the same function, rather than a second opinion computed from a different number
  const wouldRefuseEverything = mode === "ENFORCE" && !canEnforce;

  return (
    <CardFooter bar className="gap-3">
      <Icon className={`h-4 w-4 shrink-0 ${
        wouldRefuseEverything ? "text-destructive"
          : mode === "ENFORCE" ? "text-success"
          : mode === "REPORT" ? "text-warning" : "text-muted-foreground"}`} />
      <p className={`min-w-32 flex-1 text-xs ${
        wouldRefuseEverything ? "text-destructive" : "text-muted-foreground"}`}>
        {wouldRefuseEverything
          ? "Nothing is approved, so this account can send nothing at all."
          : mode === "ENFORCE"
            ? "Anything not on the list is refused."
            : mode === "REPORT"
              ? "Counted and logged, and sent anyway. Read the count before enforcing."
              : !canEnforce
                ? "Approve something before this can be enforced."
                : "The list is ignored until this is REPORT or ENFORCE."}
      </p>
      <Select
        value={mode}
        disabled={busy}
        onChange={(e) => onChange(e.target.value as WhitelistMode)}
        className="h-7 w-36 text-sm"
        aria-label={`${title} enforcement`}
      >
        <option value="OFF">Not checked</option>
        <option value="REPORT">Report only</option>
        <option value="ENFORCE" disabled={!canEnforce}>Enforce</option>
      </Select>
      {error && <p className="w-full text-sm text-destructive">{error}</p>}
      {/*not an error: this saved, and it stopped some traffic. `WarningNote` rather than loose amber
         text because this is four sentences ending in an instruction -- as a bare paragraph under a
         control it reads as an error message somebody forgot to style, which is exactly how it was
         reported. The box and the icon say "standing condition, act on it" without saying it*/}
      {!error && warning && (
        <div className="w-full">
          <WarningNote warnings={[warning]} />
        </div>
      )}
    </CardFooter>
  );
}

/**
 * One approved list: the count in the title, the list in the body, the switch in the footer.
 *
 * <p>The count sits in the title rather than beside it -- what the old disclosure's "N set" badge was
 * reaching for, except that here it says which list it is counting. It is suppressed while loading,
 * because a confident "· 0" beside a list that has not arrived yet reads as "nothing is approved",
 * which on an enforcing account is the difference between calm and an incident. The footer is
 * suppressed for the same reason and not merely disabled: `approved` is 0 until the fetch lands, so
 * a rendered footer would flash the red "can send nothing at all" line on every page open.
 *
 * <p>Add is an icon in the header rather than a button in the footer, because the footer now holds
 * the switch. It carries both `aria-label` and `title` -- a bare glyph with no accessible name is
 * not something this can ship as.
 */
function Section({
  title,
  description,
  addLabel,
  count,
  pending,
  loading,
  mode,
  canEnforce,
  busy,
  policyError,
  warning,
  onModeChange,
  onAdd,
  search,
  children,
}: {
  title: string;
  description: string;
  addLabel: string;
  count: number;
  pending: number;
  loading: boolean;
  mode: WhitelistMode;
  /** Whether the server would accept ENFORCE, by the same rule the server applies. */
  canEnforce: boolean;
  busy: boolean;
  policyError: string;
  warning: string;
  onModeChange: (mode: WhitelistMode) => void;
  onAdd: () => void;
  /** The search box, or null below the point where a list is worth searching. */
  search?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <Card>
      <CardHeader bar className="flex flex-row flex-wrap items-start justify-between gap-3 space-y-0">
        <div className="min-w-0 space-y-1.5">
          <CardTitle className="text-base font-medium">
            {title}
            {!loading && (
              <span className="ml-2 text-xs font-normal text-muted-foreground">
                {count} approved
                {/*a request is not an approval, and counting it as one is what this card used to do.
                   Saying both keeps the number honest without the difference looking like loss*/}
                {pending > 0 && ` · ${pending} requested`}
              </span>
            )}
          </CardTitle>
          <CardDescription>{description}</CardDescription>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          {!loading && search}
          <Button variant="outline" size="icon" className="h-8 w-8 shrink-0"
            aria-label={addLabel} title={addLabel} onClick={onAdd}>
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? <p className="text-xs text-muted-foreground">Loading…</p> : children}
      </CardContent>
      {!loading && (
        <EnforcementFooter
          title={title}
          mode={mode}
          canEnforce={canEnforce}
          busy={busy}
          error={policyError}
          warning={warning}
          onChange={onModeChange}
        />
      )}
    </Card>
  );
}
