"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Eye, Unplug } from "lucide-react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClasses } from "@/components/ui/button";
import { isAdminSession } from "@/lib/roles";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { Segmented } from "@/components/ui/segmented";
import { Select } from "@/components/ui/select";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import { HealthStrip } from "@/components/CardBits";
import { StatTile } from "@/components/ui/stat-tile";
import { SignInSummaryCard } from "@/components/SignInSummaryCard";
import { ClientWatchCard, type ClientWatchHandle } from "@/components/ClientWatchCard";
import { BindHoldsCard, ForceDisconnectDialog } from "@/components/ForceDisconnectDialog";
import { BanRulesCard } from "@/components/BanRulesCard";
import { RefusalsByPort } from "@/components/RefusalsByPort";
import { Pager } from "@/components/Pager";
import { usePaging } from "@/components/usePaging";
import {
  reasonLabel,
  surfaceLabel,
  type BlockedAddress,
  type SecurityEvent,
  type SecuritySurface,
} from "@/lib/security-events";
import { SURFACES, bucketsFor, displayIp, groupByAddress, type Bucket } from "@/lib/security-grouping";

/**
 * Who was refused, and who is blocked.
 *
 * <p>Blocked sits above the refusals because it is the actionable state and the refusals are the
 * evidence for it. The three surfaces share ONE table rather than three: the same actor moves
 * between them — the address working through system ids on 2775 is often the one trying the panel
 * afterwards — and three tables would hide exactly that.
 *
 * <p>The column is "Tried as", not "User". Nothing here authenticated, so a name in it is an
 * attempted name; rendering it as an identity would put a customer's name against somebody else's
 * attack. And the reason never says which half of a credential was wrong, because the gateway
 * compares in constant time precisely so that it does not.
 *
 * <p><strong>Every source says separately why it is empty.</strong> A gateway that cannot be
 * reached, a refusal log that is switched off, and a host with no fail2ban all produce no rows, and
 * an operator has to be able to tell which. That is why the notes below are rendered rather than
 * summarised into one "nothing to show".
 *
 * <p>The third view, <em>By server port</em>, is the gateway's own ledger (`refusalSummary`, 0.13+)
 * rather than parsed log lines: per listener, per address, with the hold and the fail2ban ban beside
 * each row, and under it the rules that ban without anybody pressing anything. See
 * `RefusalsByPort` and `BanRulesCard`.
 */

interface SourceState {
  reachable?: boolean;
  present?: boolean;
  state?: string | null;
  truncated?: boolean;
  note?: string | null;
  path?: string;
  /** True when the list came from fail2ban itself rather than from the notify action's file. */
  live?: boolean;
  historyPresent?: boolean;
  canUnban?: boolean;
  unbanCommand?: string;
}

interface Payload {
  events: SecurityEvent[];
  blocked: BlockedAddress[];
  sources: {
    gateway: SourceState;
    operator: SourceState;
    fail2ban: SourceState;
  };
}

/** Rows per page, in both views of the refusals. */
const PAGE = 25;

/** One range for the whole page: the cards, the chart, the tables and the sign-in summary agree. */
const RANGES = [
  { value: "24h", label: "24 hours", hours: 24, days: 1 },
  { value: "7d", label: "7 days", hours: 24 * 7, days: 7 },
  { value: "30d", label: "30 days", hours: 24 * 30, days: 30 },
] as const;

type RangeId = (typeof RANGES)[number]["value"];

/** A colour per surface, used by the chart, its legend and the badges alike. */
const SURFACE_TONE: Record<SecuritySurface, { bar: string; badge: string }> = {
  smpp: { bar: "bg-chart-1/80", badge: "bg-chart-1/10 text-chart-1" },
  rest: { bar: "bg-chart-3/80", badge: "bg-chart-3/10 text-chart-3" },
  panel: { bar: "bg-chart-4/80", badge: "bg-chart-4/10 text-chart-4" },
  portal: { bar: "bg-chart-2/80", badge: "bg-chart-2/10 text-chart-2" },
};

export function SecurityClient() {
  const [forcing, setForcing] = useState<{ ip?: string } | null>(null);
  const [holdsKey, setHoldsKey] = useState(0);
  const { data: session } = useSession();
  const admin = isAdminSession(session);
  const [data, setData] = useState<Payload | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [rangeId, setRangeId] = useState<RangeId>("24h");
  const [surface, setSurface] = useState<SecuritySurface | "all">("all");
  const [view, setView] = useState<"address" | "attempt" | "port">("address");
  const [busy, setBusy] = useState<string | null>(null);
  const watch = useRef<ClientWatchHandle>(null);
  /**
   * When the data on screen was read.
   *
   * <p>The range is measured from here rather than from `Date.now()` during render. Reading the
   * clock while rendering is impure -- the cutoff would move on every re-render, so a row could
   * drop out of "the last day" because something unrelated changed -- and this is also the more
   * honest reading: the range is relative to the moment these events were fetched.
   */
  const [readAt, setReadAt] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/control/security", { cache: "no-store" });
      const body = await res.json();
      if (!res.ok) {
        throw new Error(body?.error ?? "Could not read the security log.");
      }
      setData(body.data as Payload);
      setReadAt(Date.now());
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const range = RANGES.find((r) => r.value === rangeId)!;

  //everything in the range, every surface: the cards and the chart read this
  const inRange = useMemo(() => {
    const cutoff = readAt === null ? 0 : readAt - range.hours * 3_600_000;
    return (data?.events ?? []).filter((e) => {
      if (cutoff === 0 || !e.at) {
        return true;
      }
      const at = Date.parse(e.at);
      return Number.isNaN(at) || at >= cutoff;
    });
  }, [data, range.hours, readAt]);

  //and the tables, narrowed by surface
  const shown = useMemo(
    () => (surface === "all" ? inRange : inRange.filter((e) => e.surface === surface)),
    [inRange, surface]
  );
  const addresses = useMemo(() => groupByAddress(shown), [shown]);
  const buckets = useMemo(
    () => (readAt === null ? [] : bucketsFor(inRange, range.hours, readAt)),
    [inRange, range.hours, readAt]
  );
  const byAddress = usePaging(addresses, PAGE);
  const byAttempt = usePaging(shown, PAGE);

  const counts = useMemo(() => {
    const by: Record<SecuritySurface, number> = { smpp: 0, rest: 0, panel: 0, portal: 0 };
    for (const event of inRange) {
      by[event.surface] += 1;
    }
    return by;
  }, [inRange]);
  const allAddresses = useMemo(() => groupByAddress(inRange), [inRange]);
  const loginsTried = useMemo(
    () => new Set(inRange.map((e) => e.triedAs).filter(Boolean)).size,
    [inRange]
  );

  const blockedByIp = useMemo(() => {
    const map = new Map<string, BlockedAddress>();
    for (const b of data?.blocked ?? []) {
      map.set(displayIp(b.ip), b);
    }
    return map;
  }, [data]);

  const unban = useCallback(
    async (jail: string, ip: string) => {
      setBusy(`${jail} ${ip}`);
      try {
        const res = await fetch("/api/control/security/unban", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ jail, ip }),
        });
        const body = await res.json();
        if (!res.ok) {
          throw new Error(body?.error ?? "The unban did not complete.");
        }
        await load();
      } catch (err) {
        setError(err instanceof Error ? err.message : String(err));
      } finally {
        setBusy(null);
      }
    },
    [load]
  );

  const sources = data?.sources;
  const canUnban = Boolean(sources?.fail2ban.canUnban);
  const busiest = allAddresses[0];

  //one control for the three views, rendered in whichever card is showing
  const viewSwitch = (
    <Segmented
      label="View"
      options={[
        { value: "address", label: "By address", title: "One row per address: how many, which names, when" },
        { value: "attempt", label: "Every attempt", title: "Every refusal, newest first" },
        { value: "port", label: "By server port", title: "The gateway's ledger per listener, with hold and ban beside each address" },
      ]}
      value={view}
      onChange={setView}
    />
  );

  return (
    <>
      <PageHeader
        title="Security"
        description="Who was refused, from where, and who is blocked. FireFlo records the refusals; fail2ban does the blocking."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Segmented
              label="Range"
              options={RANGES.map((r) => ({ value: r.value, label: r.label }))}
              value={rangeId}
              onChange={(next) => {
                setRangeId(next);
                byAddress.reset();
                byAttempt.reset();
              }}
            />
            {/* who may sign in belongs with who was refused; it has no nav entry of its own, and only
                an admin may open it */}
            {admin && (
              <Link href="/cp/users" className={buttonClasses({ variant: "outline" })}>
                Users
              </Link>
            )}
            <Button variant="outline" className="gap-2" onClick={() => setForcing({})}
              title="Drop every SMPP session from an address, account or login, and optionally keep it out">
              <Unplug className="h-4 w-4" aria-hidden /> Force disconnect
            </Button>
            <Button variant="outline" onClick={() => void load()} disabled={loading}>
              {loading ? "Reading…" : "Refresh"}
            </Button>
          </div>
        }
      />

      {error && <HealthStrip tone="destructive">{error}</HealthStrip>}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile
          label="Refused logins"
          value={inRange.length.toLocaleString()}
          hint={SURFACES.filter((s) => counts[s] > 0).map((s) => `${surfaceLabel(s)} ${counts[s]}`).join(" · ") || "none"}
          loading={loading}
          tone={inRange.length > 0 ? "negative" : "default"}
        />
        <StatTile
          label="Addresses"
          value={allAddresses.length.toLocaleString()}
          hint={busiest ? `busiest ${busiest.ip}, ${busiest.attempts}` : "none"}
          loading={loading}
        />
        <StatTile label="Logins tried" value={loginsTried.toLocaleString()} hint="distinct names attempted" loading={loading} />
        <StatTile
          label="Blocked now"
          value={String(data?.blocked.length ?? 0)}
          hint={sources?.fail2ban.present ? (sources.fail2ban.live ? "from fail2ban" : "from recorded bans") : "fail2ban not set up"}
          loading={loading}
          tone={data && data.blocked.length > 0 ? "negative" : "default"}
        />
      </div>

      <Card>
        <CardHeader className="flex-row flex-wrap items-center gap-x-4 gap-y-2 space-y-0">
          <CardTitle className="text-base font-medium">Refusals over time</CardTitle>
          <Legend />
        </CardHeader>
        <CardContent>
          {buckets.length ? <RefusalChart buckets={buckets} hourly={range.hours <= 48} /> : (
            <p className="text-sm text-muted-foreground">{loading ? "Reading…" : "Nothing to chart."}</p>
          )}
        </CardContent>
      </Card>

      {/* attackers on the left, where the room is; the state and the tools on the right */}
      <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_24rem]">
        {view === "port" ? (
          <RefusalsByPort
            viewSwitch={viewSwitch}
            blockedByIp={blockedByIp}
            canUnban={canUnban}
            busy={busy}
            onWatch={(ip) => watch.current?.openFor(ip)}
            onHold={(ip) => setForcing({ ip })}
            onUnban={unban}
            onBanned={load}
          />
        ) : (
        <Card className="min-w-0">
          <CardHeader className="flex-row flex-wrap items-center gap-2 space-y-0">
            <CardTitle className="text-base font-medium">Refused logins</CardTitle>
            <div className="ml-auto flex flex-wrap items-center gap-2">
              {viewSwitch}
              <Select
                aria-label="Surface"
                className="w-auto"
                value={surface}
                onChange={(e) => {
                  setSurface(e.target.value as SecuritySurface | "all");
                  byAddress.reset();
                  byAttempt.reset();
                }}
              >
                <option value="all">Every surface</option>
                {SURFACES.map((s) => (
                  <option key={s} value={s}>{surfaceLabel(s)}</option>
                ))}
              </Select>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <SourceNotes sources={sources} />
            {!shown.length ? (
              <p className="text-sm text-muted-foreground">
                {loading ? "Reading…" : `No refused logins in the last ${range.label}.`}
              </p>
            ) : view === "address" ? (
              <>
                <TableInCard>
                  <THead>
                    <tr>
                      <TH>Address</TH>
                      <TH align="right">Attempts</TH>
                      <TH>Tried as</TH>
                      <TH>Last seen</TH>
                      <TH />
                    </tr>
                  </THead>
                  <TBody>
                    {byAddress.shown.map((a) => {
                      const blocked = blockedByIp.get(a.ip);
                      return (
                        <TR key={a.ip}>
                          <TD>
                            <div className="flex flex-wrap items-center gap-1.5">
                              <span className="font-mono">{a.ip}</span>
                              {blocked && <Badge variant="destructive">blocked</Badge>}
                            </div>
                            <div className="mt-1 flex flex-wrap gap-1">
                              {SURFACES.filter((s) => a.bySurface[s] > 0).map((s) => (
                                <SurfaceBadge key={s} surface={s} count={a.bySurface[s]} />
                              ))}
                            </div>
                          </TD>
                          <TD num className="font-medium">{a.attempts}</TD>
                          <TD muted className="max-w-64">
                            <span className="font-mono text-sm" title={a.triedAs.join(", ")}>
                              {a.triedAs.length === 0
                                ? "—"
                                : a.triedAs.slice(0, 3).join(", ") + (a.triedAs.length > 3 ? ` +${a.triedAs.length - 3}` : "")}
                            </span>
                          </TD>
                          <TD muted className="whitespace-nowrap text-xs" title={`first ${when(a.firstAt)}`}>
                            {short(a.lastAt)}
                          </TD>
                          <TD align="right" className="whitespace-nowrap">
                            {a.bySurface.smpp > 0 && (
                              <Button variant="ghost" size="sm" onClick={() => watch.current?.openFor(a.ip)}
                                title="Watch this address's SMPP traffic live">
                                <Eye className="size-3.5" aria-hidden />
                                Watch
                              </Button>
                            )}
                            {blocked && canUnban && (
                              <Button variant="outline" size="sm" disabled={busy === `${blocked.jail} ${blocked.ip}`}
                                onClick={() => void unban(blocked.jail, blocked.ip)}>
                                {busy === `${blocked.jail} ${blocked.ip}` ? "Releasing…" : "Unban"}
                              </Button>
                            )}
                          </TD>
                        </TR>
                      );
                    })}
                  </TBody>
                </TableInCard>
                <Pager page={byAddress.page} pages={byAddress.pages} total={addresses.length} noun="addresses"
                  onPage={byAddress.setPage} />
              </>
            ) : (
              <>
                <TableInCard>
                  <THead>
                    <tr>
                      <TH>When</TH>
                      <TH>Surface</TH>
                      <TH>Reason</TH>
                      <TH>Tried as</TH>
                      <TH>Address</TH>
                    </tr>
                  </THead>
                  <TBody>
                    {byAttempt.shown.map((event, i) => (
                      <TR key={`${event.at}-${event.ip}-${byAttempt.page}-${i}`}>
                        <TD muted className="whitespace-nowrap text-xs" title={when(event.at)}>{short(event.at)}</TD>
                        <TD><SurfaceBadge surface={event.surface} /></TD>
                        <TD className="whitespace-nowrap">{reasonLabel(event.reason)}</TD>
                        <TD muted className="font-mono">{event.triedAs ?? "—"}</TD>
                        <TD className="font-mono">{displayIp(event.ip)}</TD>
                      </TR>
                    ))}
                  </TBody>
                </TableInCard>
                <Pager page={byAttempt.page} pages={byAttempt.pages} total={shown.length} noun="refused logins"
                  onPage={byAttempt.setPage} />
              </>
            )}
          </CardContent>
        </Card>
        )}

        <div className="min-w-0 space-y-4 xl:sticky xl:top-4">
          {/* held out by an operator after a force disconnect: refused at bind, separately from
              what fail2ban blocks, and lifted here */}
          <Card>
            <CardHeader bar className="flex-row items-center gap-2 space-y-0">
              <CardTitle className="text-base font-medium">Held out</CardTitle>
              <span className="text-xs text-muted-foreground">SMPP binds refused by an operator</span>
            </CardHeader>
            <CardContent className="pt-2">
              <BindHoldsCard refreshKey={holdsKey} />
            </CardContent>
          </Card>
          <BlockedCard data={data} sources={sources} canUnban={canUnban} busy={busy} onUnban={unban} />
          {/* the database view, beside the file-and-fail2ban one: the file is what bans, the table is
              what people read, and the two agreeing is itself worth being able to see */}
          <SignInSummaryCard days={range.days} />
          <ClientWatchCard ref={watch} />
        </div>
      </div>
      {/* admin only, like its route: a rule bans at the host with nobody pressing anything */}
      {admin && <BanRulesCard />}
      {forcing && (
        <ForceDisconnectDialog
          initialKind="ip"
          initialValue={forcing.ip ?? ""}
          onClose={() => setForcing(null)}
          onDone={() => setHoldsKey((k) => k + 1)}
        />
      )}
    </>
  );
}

/** The four surfaces, as the chart colours them. */
function Legend() {
  return (
    <div className="ml-auto flex flex-wrap gap-3 text-xs text-muted-foreground">
      {SURFACES.map((s) => (
        <span key={s} className="flex items-center gap-1.5">
          <span className={`size-2.5 rounded-sm ${SURFACE_TONE[s].bar}`} aria-hidden />
          {surfaceLabel(s)}
        </span>
      ))}
    </div>
  );
}

/**
 * Refusals per hour or per day, stacked by surface.
 *
 * <p>Bars rather than a chart library: one small series, no interaction beyond a tooltip, and the
 * point is the shape of a burst -- which surface, and when -- rather than a readable value per bar.
 */
function RefusalChart({ buckets, hourly }: { buckets: Bucket[]; hourly: boolean }) {
  const peak = Math.max(...buckets.map((b) => b.total), 1);
  const label = (iso: string) =>
    hourly
      ? new Date(iso).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })
      : new Date(iso).toLocaleDateString(undefined, { day: "numeric", month: "short" });
  const ticks = [0, Math.floor(buckets.length / 2), buckets.length - 1];
  return (
    <div>
      <div className="flex h-28 items-end gap-0.5" role="img"
        aria-label={`Refusals per ${hourly ? "hour" : "day"}, peak ${peak}`}>
        {buckets.map((b) => (
          <div key={b.start} className="flex h-full flex-1 flex-col justify-end"
            title={`${label(b.start)} — ${b.total}${b.total ? ": " + SURFACES.filter((s) => b.bySurface[s]).map((s) => `${surfaceLabel(s)} ${b.bySurface[s]}`).join(", ") : ""}`}>
            {b.total === 0 ? (
              //a quiet slice still draws a hairline, so it reads as quiet rather than missing
              <div className="h-px bg-border" />
            ) : (
              SURFACES.filter((s) => b.bySurface[s] > 0).map((s) => (
                <div key={s} className={`w-full first:rounded-t-sm ${SURFACE_TONE[s].bar}`}
                  style={{ height: `${(b.bySurface[s] / peak) * 100}%` }} />
              ))
            )}
          </div>
        ))}
      </div>
      <div className="relative mt-1.5 flex justify-between text-xs text-muted-foreground" suppressHydrationWarning>
        {ticks.map((i) => <span key={i}>{label(buckets[i].start)}</span>)}
      </div>
      <p className="mt-1 text-xs text-muted-foreground">peak {peak} in {hourly ? "an hour" : "a day"}</p>
    </div>
  );
}

/** Blocked now, compact for the rail. The setup note when fail2ban is not here; the list when it is. */
function BlockedCard({
  data,
  sources,
  canUnban,
  busy,
  onUnban,
}: {
  data: Payload | null;
  sources: Payload["sources"] | undefined;
  canUnban: boolean;
  busy: string | null;
  onUnban: (jail: string, ip: string) => Promise<void>;
}) {
  return (
    <Card>
      <CardHeader bar className="flex-row items-center gap-2 space-y-0">
        <CardTitle className="text-base font-medium">Blocked now</CardTitle>
        {data && data.blocked.length > 0 && (
          <Badge variant="destructive" className="ml-auto">{data.blocked.length}</Badge>
        )}
      </CardHeader>
      <CardContent className="space-y-2 pt-3 text-sm">
        {sources && !sources.fail2ban.present ? (
          <div className="space-y-2 text-xs text-muted-foreground">
            <p>{sources.fail2ban.note}</p>
            {/* names the VERB, not the flag: `update` drops --with-fail2ban, so it cannot be the
                instruction on a host that already has an install */}
            <p>
              Set it up with <code className="font-mono">sudo fireflo-install fail2ban</code>, and fill in the
              never-ban list first: a ban is on an address, and an address usually carries a whole customer.
            </p>
            <dl className="space-y-1">
              <div><dt className="inline">Asks </dt><dd className="inline font-mono">{sources.fail2ban.unbanCommand}</dd></div>
              <div><dt className="inline">Reads </dt><dd className="inline font-mono">{sources.fail2ban.path}</dd></div>
            </dl>
          </div>
        ) : !data?.blocked.length ? (
          <p className="text-muted-foreground">Nothing is blocked.</p>
        ) : (
          <ul className="divide-y divide-border">
            {data.blocked.map((row) => (
              <li key={`${row.jail} ${row.ip}`} className="flex items-center gap-2 py-2">
                <div className="min-w-0 flex-1">
                  <p className="font-mono">{displayIp(row.ip)}</p>
                  <p className="text-xs text-muted-foreground">
                    {row.jail} · {row.failures} failures · {row.until ? `lifts ${short(row.until)}` : "does not expire"}
                  </p>
                </div>
                {canUnban && (
                  <Button variant="outline" size="sm" disabled={busy === `${row.jail} ${row.ip}`}
                    onClick={() => void onUnban(row.jail, row.ip)}>
                    {busy === `${row.jail} ${row.ip}` ? "Releasing…" : "Unban"}
                  </Button>
                )}
              </li>
            ))}
          </ul>
        )}
        {data && data.blocked.length > 0 && (
          //which source answered, because they can disagree and the live one is the truth
          <p className="text-xs text-muted-foreground">
            {sources?.fail2ban.live
              ? "Asked fail2ban directly: this is what is blocking traffic now."
              : "Reconstructed from recorded bans; a ban made outside FireFlo would not appear."}
            {!canUnban && " Unbanning from here is not set up on this host."}
          </p>
        )}
      </CardContent>
    </Card>
  );
}

/**
 * Why a source has nothing, in its own words.
 *
 * <p>Rendered rather than folded into a single message. "The gateway is unreachable", "the log is
 * switched off" and "nobody has failed to log in" are three different pieces of news, and only the
 * last one is good.
 */
function SourceNotes({ sources }: { sources: Payload["sources"] | undefined }) {
  if (!sources) {
    return null;
  }
  const notes: string[] = [];
  if (sources.gateway.reachable === false && sources.gateway.note) {
    notes.push(sources.gateway.note);
  }
  if (sources.gateway.state === "disabled" && sources.gateway.note) {
    notes.push(sources.gateway.note);
  }
  if (sources.gateway.truncated) {
    notes.push(
      "The gateway's refusal log was longer than the window read, so the oldest entries in it are "
        + "not shown here."
    );
  }
  if (sources.operator.note) {
    notes.push(sources.operator.note);
  }
  if (notes.length === 0) {
    return null;
  }
  return (
    <div className="space-y-1 rounded-md border border-border bg-muted/40 p-3 text-sm text-muted-foreground">
      {notes.map((note) => (
        <p key={note}>{note}</p>
      ))}
    </div>
  );
}

function SurfaceBadge({ surface, count }: { surface: SecuritySurface; count?: number }) {
  return (
    <span className={`whitespace-nowrap rounded px-2 py-0.5 text-xs font-medium ${SURFACE_TONE[surface].badge}`}>
      {surfaceLabel(surface)}{count !== undefined ? ` ${count}` : ""}
    </span>
  );
}

/**
 * @return a local, readable moment, or the raw string when it cannot be parsed — which is honest
 *     about a line this panel did not understand rather than showing "Invalid Date"
 */
function when(value: string | null): string {
  if (!value) {
    return "—";
  }
  const at = new Date(value);
  return Number.isNaN(at.getTime()) ? value : at.toLocaleString();
}

/** A moment, short: the time today, otherwise the date and time. The full one is in the tooltip. */
function short(value: string | null): string {
  if (!value) {
    return "—";
  }
  const at = new Date(value);
  if (Number.isNaN(at.getTime())) {
    return value;
  }
  const today = new Date().toDateString() === at.toDateString();
  return today
    ? at.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })
    : at.toLocaleString(undefined, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}
