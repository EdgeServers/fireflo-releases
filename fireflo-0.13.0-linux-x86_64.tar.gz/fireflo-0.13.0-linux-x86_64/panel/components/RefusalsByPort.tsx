"use client";

import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import { Ban, Eye, Unplug } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Segmented } from "@/components/ui/segmented";
import { Select } from "@/components/ui/select";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import { HealthStrip } from "@/components/CardBits";
import { NeedsCapability } from "@/components/NeedsCapability";
import { Pager } from "@/components/Pager";
import { useHealth } from "@/components/useHealth";
import { usePaging } from "@/components/usePaging";
import type { RefusalSummaryRow } from "@/lib/ban-rules";
import { REFUSAL_LEDGER } from "@/lib/capabilities";
import {
  BAN_DURATIONS,
  BAN_NOT_AVAILABLE,
  DEFAULT_REFUSAL_WINDOW,
  REFUSAL_WINDOWS,
  addressRows,
  isNonBannable,
  listenerLabel,
  reasonBreakdown,
  reasonsIn,
  windowMinutesOf,
  type RefusalWindow,
} from "@/lib/refusal-views";
import { reasonLabel, type BlockedAddress } from "@/lib/security-events";
import { displayIp } from "@/lib/security-grouping";

/**
 * The refusal ledger by server port: one card per listener, then every address with what it was
 * refused for and the two things an operator can do about it.
 *
 * <p>The other two views of this page are built from log lines the panel parsed. This one is the
 * gateway's own fold (`refusalSummary`), which is what a ban rule evaluates -- so what an operator
 * sees here and what the rule would ban are the same count over the same window. Reasons a rule
 * leaves out by default (a customer's fleet over its connection cap, an address already held out)
 * are marked, so a big number that is not an attack reads as what it is.
 *
 * <p>Two levers per row. <em>Hold</em> is the gateway's: binds from the address are refused on
 * every node, lifted from the Held out card. <em>Ban in fail2ban</em> is the host's: the address
 * is dropped at the firewall, for the jail's own time or the one chosen. The second needs the
 * panel on the gateway host, and says so rather than hiding the button.
 */

interface Payload {
  listeners: RefusalSummaryRow[];
  windowMinutes: number;
  jails: string[];
  fail2banAvailable: boolean;
}

const PAGE = 25;

export function RefusalsByPort({
  viewSwitch,
  blockedByIp,
  canUnban,
  busy,
  onWatch,
  onHold,
  onUnban,
  onBanned,
}: {
  /** The page's view picker, so this card's header carries the same control as the other views'. */
  viewSwitch: ReactNode;
  blockedByIp: Map<string, BlockedAddress>;
  canUnban: boolean;
  busy: string | null;
  onWatch: (ip: string) => void;
  onHold: (ip: string) => void;
  onUnban: (jail: string, ip: string) => Promise<void>;
  /** After a ban took, so the page re-reads what is blocked. */
  onBanned: () => Promise<void>;
}) {
  const { health, error: healthError, loading: healthLoading } = useHealth();
  const [range, setRange] = useState<RefusalWindow>(DEFAULT_REFUSAL_WINDOW);
  const [listener, setListener] = useState("");
  const [reason, setReason] = useState("");
  const [jail, setJail] = useState("");
  const [seconds, setSeconds] = useState<string>("");
  const [data, setData] = useState<Payload | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [banning, setBanning] = useState<string | null>(null);

  const supported = health != null && health.api?.[REFUSAL_LEDGER] === true;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const q = new URLSearchParams({ windowMinutes: String(windowMinutesOf(range)) });
      const res = await fetch(`/api/control/security/refusals?${q}`, { cache: "no-store" });
      const body = await res.json().catch(() => null);
      if (!res.ok) {
        throw new Error(body?.error ?? `Could not read the refusal ledger (${res.status}).`);
      }
      setData(body.data as Payload);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  }, [range]);

  useEffect(() => {
    if (supported) {
      //eslint-disable-next-line react-hooks/set-state-in-effect -- the first read, once the capability is known
      void load();
    }
  }, [supported, load]);

  const listeners = useMemo(() => data?.listeners ?? [], [data]);
  const reasons = useMemo(() => reasonsIn(listeners), [listeners]);
  const rows = useMemo(
    () => addressRows(listeners, { listener: listener || null, reason: reason || null }),
    [listeners, listener, reason]
  );
  const paged = usePaging(rows, PAGE);
  const jails = data?.jails ?? [];
  const chosenJail = jail || jails[0] || "";
  const canBan = Boolean(data?.fail2banAvailable) && jails.length > 0;
  const windowLabel = REFUSAL_WINDOWS.find((w) => w.value === range)!.label;

  const ban = useCallback(
    async (ip: string) => {
      setBanning(ip);
      setNote(null);
      try {
        const res = await fetch("/api/control/security/ban", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ ip, jail: chosenJail, seconds: seconds ? Number(seconds) : undefined }),
        });
        const body = await res.json().catch(() => null);
        if (!res.ok) {
          throw new Error(body?.error ?? `The ban did not complete (${res.status}).`);
        }
        setNote(`${ip} is now banned in ${chosenJail}.${body?.data?.note ? ` ${body.data.note}` : ""}`);
        await onBanned();
      } catch (err) {
        setError(err instanceof Error ? err.message : String(err));
      } finally {
        setBanning(null);
      }
    },
    [chosenJail, seconds, onBanned]
  );

  return (
    <Card className="min-w-0">
      <CardHeader className="flex-row flex-wrap items-center gap-2 space-y-0">
        <CardTitle className="text-base font-medium">Refused logins</CardTitle>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          {viewSwitch}
          <Segmented
            label="Window"
            options={REFUSAL_WINDOWS.map((w) => ({ value: w.value, label: w.label }))}
            value={range}
            onChange={(next) => {
              setRange(next);
              paged.reset();
            }}
          />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <NeedsCapability health={health} loading={healthLoading} error={healthError} name={REFUSAL_LEDGER} feature="a refusal ledger">
          {error && <HealthStrip tone="destructive">{error}</HealthStrip>}
          {note && <HealthStrip tone="info">{note}</HealthStrip>}

          {/* one card per listener: the port, how many, and the reasons -- the shape of the
              traffic before any one address is looked at */}
          {!listeners.length ? (
            <p className="text-sm text-muted-foreground">
              {loading ? "Reading…" : `No refused binds or REST credentials in the last ${windowLabel}.`}
            </p>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
              {listeners.map((row) => (
                <button
                  key={`${row.listener}|${row.port}`}
                  type="button"
                  onClick={() => {
                    setListener(listener === row.listener ? "" : (row.listener ?? ""));
                    paged.reset();
                  }}
                  aria-pressed={listener === row.listener}
                  className={`rounded-lg border p-3 text-left transition-colors hover:bg-muted/50 ${
                    listener === row.listener ? "border-primary bg-muted" : "border-border"
                  }`}
                >
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="truncate font-mono text-sm font-medium">{listenerLabel(row)}</span>
                    <span className="text-lg font-semibold tabular-nums">{row.total.toLocaleString()}</span>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {row.byAddress.length} address{row.byAddress.length === 1 ? "" : "es"}
                  </p>
                  <div className="mt-2 flex flex-wrap gap-1">
                    {[...row.byReason].sort((a, b) => b.count - a.count).map((r) => (
                      <Badge key={r.reason} variant={isNonBannable(r.reason) ? "outline" : "destructive"} title={reasonLabel(r.reason)}>
                        {r.reason} {r.count}
                      </Badge>
                    ))}
                  </div>
                </button>
              ))}
            </div>
          )}

          {listeners.length > 0 && (
            <>
              <div className="flex flex-wrap items-center gap-2">
                <Select aria-label="Listener" className="w-auto" value={listener}
                  onChange={(e) => { setListener(e.target.value); paged.reset(); }}>
                  <option value="">Every listener</option>
                  {listeners.filter((l) => l.listener).map((l) => (
                    <option key={l.listener!} value={l.listener!}>{listenerLabel(l)}</option>
                  ))}
                </Select>
                <Select aria-label="Reason" className="w-auto" value={reason}
                  onChange={(e) => { setReason(e.target.value); paged.reset(); }}>
                  <option value="">Every reason</option>
                  {reasons.map((r) => (
                    <option key={r.reason} value={r.reason}>
                      {reasonLabel(r.reason)} ({r.count}){isNonBannable(r.reason) ? " — not banned by rules" : ""}
                    </option>
                  ))}
                </Select>
                <div className="ml-auto flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                  <span>Ban into</span>
                  <Select aria-label="Jail" className="w-auto" value={chosenJail} disabled={!canBan}
                    onChange={(e) => setJail(e.target.value)}>
                    {jails.map((j) => <option key={j} value={j}>{j}</option>)}
                  </Select>
                  <Select aria-label="Ban for" className="w-auto" value={BAN_DURATIONS.some((d) => d.value === seconds) ? seconds : "custom"}
                    disabled={!canBan}
                    onChange={(e) => setSeconds(e.target.value === "custom" ? "600" : e.target.value)}>
                    {BAN_DURATIONS.map((d) => <option key={d.value} value={d.value}>{d.label}</option>)}
                    <option value="custom">Seconds…</option>
                  </Select>
                  {seconds && !BAN_DURATIONS.some((d) => d.value === seconds) && (
                    <Input aria-label="Ban seconds" inputMode="numeric" className="w-24" value={seconds}
                      onChange={(e) => setSeconds(e.target.value.replace(/\D/g, ""))} />
                  )}
                </div>
              </div>
              {data && !data.fail2banAvailable && (
                <p className="text-xs text-muted-foreground">{BAN_NOT_AVAILABLE}</p>
              )}

              {!rows.length ? (
                <p className="text-sm text-muted-foreground">Nothing matches.</p>
              ) : (
                <>
                  <TableInCard>
                    <THead>
                      <tr>
                        <TH>Address</TH>
                        <TH>Listener</TH>
                        <TH align="right">Refusals</TH>
                        <TH>Reasons</TH>
                        <TH>Tried as</TH>
                        <TH>Last seen</TH>
                        <TH />
                      </tr>
                    </THead>
                    <TBody>
                      {paged.shown.map((a) => {
                        const blocked = blockedByIp.get(displayIp(a.ip));
                        const busyKey = blocked ? `${blocked.jail} ${blocked.ip}` : "";
                        return (
                          <TR key={a.key}>
                            <TD>
                              <div className="flex flex-wrap items-center gap-1.5">
                                <span className="font-mono">{displayIp(a.ip)}</span>
                                {a.heldOut && <Badge variant="warning" title="A bind hold on this address is in force">held out</Badge>}
                                {blocked && <Badge variant="destructive" title={`banned in ${blocked.jail}`}>blocked</Badge>}
                              </div>
                            </TD>
                            <TD muted className="whitespace-nowrap font-mono text-xs">{listenerLabel(a)}</TD>
                            <TD num className="font-medium">{a.count.toLocaleString()}</TD>
                            <TD className="max-w-72 text-xs" title={reasonBreakdown(a.byReason, reasonLabel)}>
                              <div className="flex flex-wrap gap-1">
                                {[...a.byReason].sort((x, y) => y.count - x.count).map((r) => (
                                  <Badge key={r.reason} variant={isNonBannable(r.reason) ? "outline" : "destructive"} title={reasonLabel(r.reason)}>
                                    {r.reason} {r.count}
                                  </Badge>
                                ))}
                              </div>
                            </TD>
                            <TD muted className="max-w-56">
                              <span className="font-mono text-xs" title={a.identities.join(", ")}>
                                {a.identities.length === 0
                                  ? "—"
                                  : a.identities.slice(0, 3).join(", ") + (a.identities.length > 3 ? ` +${a.identities.length - 3}` : "")}
                              </span>
                            </TD>
                            <TD muted className="whitespace-nowrap text-xs" title={`first ${when(a.firstAt)}`}>{short(a.lastAt)}</TD>
                            <TD align="right" className="whitespace-nowrap">
                              <Button variant="ghost" size="sm" onClick={() => onWatch(a.ip)} title="Watch this address's SMPP traffic live">
                                <Eye className="size-3.5" aria-hidden /> Watch
                              </Button>
                              {!a.heldOut && (
                                <Button variant="ghost" size="sm" onClick={() => onHold(a.ip)}
                                  title="Drop this address's SMPP sessions and hold its binds out on the gateway">
                                  <Unplug className="size-3.5" aria-hidden /> Hold
                                </Button>
                              )}
                              {blocked ? (
                                canUnban && (
                                  <Button variant="outline" size="sm" disabled={busy === busyKey}
                                    onClick={() => void onUnban(blocked.jail, blocked.ip)}>
                                    {busy === busyKey ? "Releasing…" : "Unban"}
                                  </Button>
                                )
                              ) : (
                                <Button variant="outline" size="sm" disabled={!canBan || banning === a.ip}
                                  title={canBan ? `Ban ${displayIp(a.ip)} in ${chosenJail}` : BAN_NOT_AVAILABLE}
                                  onClick={() => void ban(a.ip)}>
                                  <Ban className="size-3.5" aria-hidden />
                                  {banning === a.ip ? "Banning…" : "Ban in fail2ban"}
                                </Button>
                              )}
                            </TD>
                          </TR>
                        );
                      })}
                    </TBody>
                  </TableInCard>
                  <Pager page={paged.page} pages={paged.pages} total={rows.length} noun="addresses" onPage={paged.setPage} />
                </>
              )}
            </>
          )}
        </NeedsCapability>
      </CardContent>
    </Card>
  );
}

function when(value: string | null): string {
  if (!value) return "—";
  const at = new Date(value);
  return Number.isNaN(at.getTime()) ? value : at.toLocaleString();
}

function short(value: string | null): string {
  if (!value) return "—";
  const at = new Date(value);
  if (Number.isNaN(at.getTime())) return value;
  const today = new Date().toDateString() === at.toDateString();
  return today
    ? at.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })
    : at.toLocaleString(undefined, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}
