"use client";
import { PageHeader } from "@/components/ui/page-header";
import { useCallback, useEffect, useState } from "react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog } from "@/components/ui/dialog";
import { MisRegistrationForm } from "./MisRegistrationForm";
import type { ApprovedHeader, ApprovedTemplate } from "@/lib/whitelist-types";
import { EmptyState } from "@/components/ui/empty-state";
import { HealthStrip } from "@/components/CardBits";

/**
 * A customer's own sender IDs or approved wording, and the modal that changes them.
 *
 * <p>One component for both because the two lists differ in one field and nothing else that matters:
 * what is registered, what state it is in, and why it was refused. Two components would be the same
 * file twice with `header` and `body` swapped, and they would drift.
 *
 * <p><strong>Nothing here approves anything.</strong> Every write lands as a request; the operator
 * decides. The list makes that visible rather than implying otherwise — a pending row is shown as
 * waiting, not as configured, because a customer who believed a submission was live would read a
 * refused message as the gateway being broken.
 */
export type RegistrationKind = "senders" | "templates";

type Row = (ApprovedHeader | ApprovedTemplate) & { header?: string; body?: string };

const COPY = {
  senders: {
    title: "Sender IDs",
    blurb: "The names your messages may be sent from. Each one is approved before it can be used.",
    empty: "No sender IDs yet.",
    add: "Request a sender ID",
    value: (r: Row) => r.header ?? "",
  },
  templates: {
    title: "Templates",
    blurb: "The wording your messages may use. Each one is approved before it can be used.",
    empty: "No templates yet.",
    add: "Request a template",
    value: (r: Row) => r.body ?? "",
  },
} as const;

export function MisRegistrationsClient({
  kind,
  account,
}: {
  kind: RegistrationKind;
  /**
   * Show only this account's rows, and request only on its behalf.
   *
   * <p>For a reseller reading one of its own accounts. Absent on `/senders` and `/templates`, which
   * show the whole scope — the reseller's own rows and its children's together.
   *
   * <p>A CLIENT-SIDE filter over the answer the route already scoped, not a narrowing of the query:
   * the route sends what `scopeFor` allows, this picks one of those out. That is safe because the
   * set it filters is already the caller's, and it means the tab needs no route of its own.
   */
  account?: string;
}) {
  const [rows, setRows] = useState<Row[]>([]);
  /**
   * The accounts this session may see: itself, plus its children when it resells.
   *
   * <p>Sent by the route rather than derived here — `scopeFor` decides it, and a second reading in
   * the browser could only disagree with the one the query actually used.
   */
  const [scope, setScope] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [editing, setEditing] = useState<Row | "new" | null>(null);

  const copy = COPY[kind];
  //the rows this view shows. Filtered rather than re-fetched -- see the `account` prop
  const shown = account ? rows.filter((r) => r.accountId === account) : rows;

  const load = useCallback(async () => {
    try {
      const res = await fetch(`/api/mis/${kind}`, { cache: "no-store" });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? "That did not load.");
        return;
      }
      setRows((json?.data?.rows ?? []) as Row[]);
      setScope((json?.data?.scope ?? []) as string[]);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "That did not load.");
    } finally {
      setLoading(false);
    }
  }, [kind]);

  useEffect(() => {
    void load();
  }, [load]);

  //the count that decides how loudly an edit is warned about: with one approved registration and
  //enforcement on, editing it stops the account sending at all
  const approvedCount = shown.filter((r) => r.status === "APPROVED" && r.enabled).length;
  //silent until something is scoped, for the reason the label itself gives
  const anyScoped = shown.some((r) => r.systemId);

  const addButton = (
    <Button size="sm" className="gap-2" onClick={() => setEditing("new")}>
      <Plus className="h-4 w-4" />
      {copy.add}
    </Button>
  );

  return (
    <>
      {/* the page title on /senders and /templates. Inside an account's Approvals tab this renders
          twice, under the account's own title, so there it is a section heading instead -- the
          same rank the operator's account tabs give their sections */}
      {account ? (
        <div className="flex flex-wrap items-center gap-2">
          <div className="min-w-0 flex-1 space-y-1">
            <h2 className="text-base font-medium">{copy.title}</h2>
            <p className="text-xs text-muted-foreground">{copy.blurb}</p>
          </div>
          <div className="ml-auto">{addButton}</div>
        </div>
      ) : (
        <PageHeader title={copy.title} description={copy.blurb} actions={addButton} />
      )}

      {notice && (
        <Card className="border-warning/40">
          <CardContent className="py-3 text-sm">{notice}</CardContent>
        </Card>
      )}
      {error && <HealthStrip tone="destructive">{error}</HealthStrip>}

      {!shown.length && !loading && (
        <EmptyState>
          {copy.empty}
        </EmptyState>
      )}

      <div className="space-y-2">
        {shown.map((row) => (
          <Card key={row.id}>
            <CardContent className="flex flex-wrap items-start justify-between gap-3 py-3">
              <div className="min-w-0 space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className={kind === "senders" ? "font-mono text-sm" : "text-sm"}>
                    {copy.value(row)}
                  </span>
                  <StatusBadge row={row} />
                  {/*whose registration this is. Only for a reseller, and only once it holds
                     somebody: on an ordinary account every row is its own and the label would be
                     the account name repeated down the page*/}
                  {scope.length > 1 && (
                    <span className="font-mono text-xs text-muted-foreground">
                      {row.accountId}
                    </span>
                  )}
                  {row.product && (
                    <span className="text-xs text-muted-foreground">for {row.product}</span>
                  )}
                  {/*only once a row is bound to one. On an account whose rows are all shared --
                     which is every account until somebody scopes one -- saying "all logins" on
                     every row is a label with one value in it*/}
                  {anyScoped && (
                    <span className="text-xs text-muted-foreground">
                      {row.systemId ? `on ${row.systemId}` : "on all your logins"}
                    </span>
                  )}
                </div>

                {/* the refusal reason, where the person who has to act on it will see it */}
                {row.status === "REJECTED" && row.reviewNote && (
                  <p className="text-sm text-destructive">{row.reviewNote}</p>
                )}
                {row.status === "PENDING" && (
                  <p className="text-sm text-muted-foreground">
                    Waiting for approval. It is not in use yet.
                  </p>
                )}
                {row.requestNote && (
                  <p className="text-xs text-muted-foreground">Your note: {row.requestNote}</p>
                )}
              </div>

              <Button variant="outline" size="sm" onClick={() => setEditing(row)}>
                Edit
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {editing && (
        <Dialog
          open
          onClose={() => setEditing(null)}
          title={editing === "new" ? copy.add : "Edit this registration"}
          description={
            editing === "new"
              ? "An operator approves it before it can be used."
              : undefined
          }
          className="max-w-2xl"
        >
          <MisRegistrationForm
            kind={kind}
            row={editing === "new" ? null : editing}
            //pinned to this account when the view is one child's, so a request made from a
            //child's Approvals tab cannot land on the reseller's own account by default
            scope={account ? [account] : scope}
            approvedCount={approvedCount}
            onCancel={() => setEditing(null)}
            onSaved={async (message) => {
              setEditing(null);
              setNotice(message);
              await load();
            }}
          />
        </Dialog>
      )}
    </>
  );
}

/**
 * Three states, and the withdrawn case folded into the first.
 *
 * <p>An approved row an operator has switched off is not in use, and saying "Approved" beside it
 * would be true and useless — what the customer needs to know is whether they can send.
 */
function StatusBadge({ row }: { row: Row }) {
  if (row.status === "PENDING") {
    return <Badge variant="warning">Waiting for approval</Badge>;
  }
  if (row.status === "REJECTED") {
    return <Badge variant="destructive">Not approved</Badge>;
  }
  if (!row.enabled) {
    return <Badge variant="outline">Withdrawn</Badge>;
  }
  return <Badge variant="success">In use</Badge>;
}
