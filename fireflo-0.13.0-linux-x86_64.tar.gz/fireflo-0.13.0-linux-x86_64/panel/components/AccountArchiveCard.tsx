"use client";
import { useState } from "react";
import { useSession } from "next-auth/react";
import { Archive, ArchiveRestore } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { HealthStrip } from "./CardBits";
import { useConfirmChange } from "./ConfirmProvider";
import type { AccountSummary } from "@/lib/account-types";
import { formatTimestamp } from "@/lib/datetime";
import { isAdminSession } from "@/lib/roles";

/**
 * Archiving an account, or bringing an archived one back. Operator surface; the buttons are an
 * admin's (the routes answer anyone else 404).
 *
 * <p>Archived (gateway V1.100.0) is retired, not paused: the logins are switched off and their binds
 * dropped, nobody can sign in to the portal for it, and it leaves the everyday account list and
 * becomes read-only. The balance, the statement and the call records stay. Unarchiving turns back
 * on exactly the logins the archive switched off.
 */
export function AccountArchiveCard({
  account,
  onArchive,
  busy,
}: {
  account: AccountSummary;
  onArchive: (archive: boolean) => Promise<{ logins: number; dropped?: number; problem?: string } | null>;
  busy: boolean;
}) {
  const { data: session } = useSession();
  const admin = isAdminSession(session);
  const confirm = useConfirmChange();
  const [said, setSaid] = useState<{ tone: "ok" | "caution"; text: string } | null>(null);
  const archived = Boolean(account.archivedAt);

  async function run(archive: boolean) {
    const ok = await confirm(archive
      ? {
          title: `Archive ${account.label || account.id}?`,
          consequence: `Its ${account.credentialCount} login${account.credentialCount === 1 ? " is" : "s are"} switched off `
            + "and any live SMPP binds are dropped; its people can no longer sign in to the portal; it leaves "
            + "the account list and becomes read-only. Its balance and history stay, and the credit the gateway "
            + "is holding for it goes back to its balance. You can unarchive it later.",
          confirmLabel: "Archive account",
          tone: "destructive",
          typeToConfirm: account.id,
        }
      : {
          title: `Unarchive ${account.label || account.id}?`,
          consequence: "It is enabled and listed again, and the logins the archive switched off are switched back on. "
            + "Customers reconnect their binds themselves.",
          confirmLabel: "Unarchive",
          tone: "caution",
        });
    if (!ok) {
      return;
    }
    const done = await onArchive(archive);
    if (!done) {
      setSaid(null);
      return;
    }
    const logins = `${done.logins} login${done.logins === 1 ? "" : "s"}`;
    setSaid(done.problem
      ? { tone: "caution", text: `Archived; ${logins} switched off. But ${done.problem}.` }
      : {
          tone: "ok",
          text: archive
            ? `Archived; ${logins} switched off${done.dropped ? `, ${done.dropped} bind${done.dropped === 1 ? "" : "s"} dropped` : ""}.`
            : `Unarchived; ${logins} switched back on.`,
        });
  }

  return (
    <Card>
      <CardHeader bar>
        <CardTitle className="text-base font-medium">{archived ? "Archived" : "Archive"}</CardTitle>
        <CardDescription>
          {archived
            ? `Archived ${account.archivedAt ? formatTimestamp(account.archivedAt) : ""}${account.archivedBy ? ` by ${account.archivedBy}` : ""}. `
              + "Its logins cannot bind or call the API, nobody can sign in for it, and it is read-only."
            : "Retire this account: no logins, no portal sign-in, out of the account list. Balance and history stay."}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {said && <HealthStrip tone={said.tone === "ok" ? "info" : "warning"}>{said.text}</HealthStrip>}
        {admin ? (
          <Button variant={archived ? "outline" : "destructive"} disabled={busy} onClick={() => void run(!archived)}>
            {archived ? <ArchiveRestore className="mr-1.5 h-4 w-4" /> : <Archive className="mr-1.5 h-4 w-4" />}
            {busy ? "Working…" : archived ? "Unarchive account" : "Archive account"}
          </Button>
        ) : (
          <p className="text-xs text-muted-foreground">Only an admin can {archived ? "unarchive" : "archive"} an account.</p>
        )}
      </CardContent>
    </Card>
  );
}
