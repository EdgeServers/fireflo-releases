import { test } from "node:test";
import assert from "node:assert/strict";
import { envOperatorAllowed, envOperatorIgnored } from "./env-operator.ts";
import { startupWarnings } from "./startup-warnings.ts";

//0.16.4 (audit F7): the env-variable operator signs in as an admin with no two-factor, so it is kept
//only for a panel with no configuration database, where it is the only way in

test("allowed only with OPERATOR_PASSWORD set and no CONFIG_DATABASE_URL", () => {
  assert.equal(envOperatorAllowed({ OPERATOR_PASSWORD: "x" }), true);
  assert.equal(envOperatorAllowed({ OPERATOR_PASSWORD: "x", CONFIG_DATABASE_URL: "  " }), true, "blank is unset, as isConfigWritable reads it");
  assert.equal(envOperatorAllowed({ OPERATOR_PASSWORD: "x", CONFIG_DATABASE_URL: "postgres://db/x" }), false);
  assert.equal(envOperatorAllowed({}), false);
  assert.equal(envOperatorAllowed({ OPERATOR_PASSWORD: "" }), false, "an empty password is no way in, not any password");
});

test("set beside a configuration database it is ignored, and startup says so", () => {
  const env = { OPERATOR_PASSWORD: "x", CONFIG_DATABASE_URL: "postgres://db/x", TRUSTED_PROXY_HOPS: "1" };
  assert.equal(envOperatorIgnored(env), true);
  const warnings = startupWarnings(env);
  assert.equal(warnings.length, 1);
  assert.match(warnings[0], /OPERATOR_PASSWORD is set but ignored/);
  assert.equal(startupWarnings({ OPERATOR_PASSWORD: "x", TRUSTED_PROXY_HOPS: "1" }).length, 0, "no database: it is in use, not ignored");
});
