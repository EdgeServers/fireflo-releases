import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { hstsByConfig, HSTS_VALUE, requestIsHttps } from "./hsts.ts";

test("the static header follows AUTH_COOKIE_SECURE, else an https AUTH_URL in production", () => {
  assert.equal(hstsByConfig({ AUTH_COOKIE_SECURE: "true" }), true);
  assert.equal(hstsByConfig({ AUTH_COOKIE_SECURE: "false", AUTH_URL: "https://panel.example.com", NODE_ENV: "production" }), false);
  assert.equal(hstsByConfig({ AUTH_URL: "https://panel.example.com", NODE_ENV: "production" }), true);
  assert.equal(hstsByConfig({ NEXTAUTH_URL: "HTTPS://panel.example.com", NODE_ENV: "production" }), true);
  assert.equal(hstsByConfig({ AUTH_URL: "http://192.0.2.10:3000", NODE_ENV: "production" }), false);
  assert.equal(hstsByConfig({ AUTH_URL: "https://panel.example.com", NODE_ENV: "development" }), false);
  assert.equal(hstsByConfig({}), false);
});

test("a request is https when the proxy says so, or its own URL is", () => {
  const req = (url: string, proto?: string) => ({ url, headers: new Headers(proto ? { "x-forwarded-proto": proto } : {}) });
  assert.equal(requestIsHttps(req("http://127.0.0.1:3000/cp", "https")), true);
  assert.equal(requestIsHttps(req("http://127.0.0.1:3000/cp", "https, http")), true, "the first hop's answer");
  assert.equal(requestIsHttps(req("http://127.0.0.1:3000/cp", "http")), false);
  assert.equal(requestIsHttps(req("http://127.0.0.1:3000/cp")), false);
  assert.equal(requestIsHttps(req("https://panel.example.com/cp")), true);
});

test("next.config.ts carries the same rule and value (copied there, not imported)", () => {
  const config = readFileSync(new URL("../next.config.ts", import.meta.url), "utf8");
  const body = (src: string) => /function hstsByConfig[^{]*\{([\s\S]*?)\n\}/.exec(src)?.[1]?.replace(/\s+/g, " ").trim();
  const lib = readFileSync(new URL("./hsts.ts", import.meta.url), "utf8");
  assert.ok(body(config), "next.config.ts defines hstsByConfig");
  assert.equal(body(config), body(lib));
  assert.ok(config.includes(`value: "${HSTS_VALUE}"`));
});
