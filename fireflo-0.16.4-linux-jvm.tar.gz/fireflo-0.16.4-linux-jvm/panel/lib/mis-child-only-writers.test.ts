import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync, statSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * A reseller writes to its children through `/api/mis/accounts/{id}/*` and `/api/mis/sub-accounts/{id}/*`,
 * never to itself.
 *
 * <p>0.16.4 (audit F3): the balance route proved the id with `assertInScope`, which lets the caller's
 * OWN id through -- right for reading one's own data, wrong for the parent's acts. A reseller could
 * switch back on the credit an operator had switched off, or change its own billing terms. Every
 * writer under these paths now goes through `childFor`, which refuses the caller's own id with the
 * same 404 as a stranger's.
 *
 * <p>A regex over the source, like `config-audit-coverage.test.ts`: every route file here that
 * exports POST, PUT, PATCH or DELETE must call `childFor(`. The reads (GET) may keep `assertInScope`.
 */

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const DIRS = [
  path.join(ROOT, "app", "api", "mis", "accounts", "[id]"),
  path.join(ROOT, "app", "api", "mis", "sub-accounts", "[id]"),
];

function routeFiles(dir: string): string[] {
  const out: string[] = [];
  for (const name of readdirSync(dir)) {
    const full = path.join(dir, name);
    if (statSync(full).isDirectory()) {
      out.push(...routeFiles(full));
    } else if (name === "route.ts") {
      out.push(full);
    }
  }
  return out;
}

const WRITER = /export\s+async\s+function\s+(POST|PUT|PATCH|DELETE)\b/;

test("every child-account writer refuses the reseller's own id through childFor", () => {
  const writers = DIRS.flatMap(routeFiles).filter((f) => WRITER.test(readFileSync(f, "utf8")));
  //the balance route and suspend/resume are the two the audit named; sub-accounts has the rest
  assert.ok(writers.length >= 2, `expected writers, found ${writers.length}`);
  for (const file of writers) {
    const source = readFileSync(file, "utf8");
    assert.ok(source.includes("childFor("), `${path.relative(ROOT, file)} writes but does not call childFor()`);
  }
});

test("childFor itself refuses the caller's own account id", () => {
  const source = readFileSync(path.join(ROOT, "lib", "mis-sub-account-route.ts"), "utf8");
  assert.match(source, /child === session\.accountId/);
});
