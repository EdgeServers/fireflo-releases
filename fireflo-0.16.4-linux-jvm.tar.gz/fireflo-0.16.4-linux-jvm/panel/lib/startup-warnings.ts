import { MAX_FAILURES_PER_EMAIL, FAILURE_WINDOW_MS } from "./signin-lockout.ts";
import { envOperatorIgnored } from "./env-operator.ts";

/**
 * What the panel says once at startup about settings that weaken sign-in protection.
 *
 * <p>Pure: it reads the environment it is given and returns sentences, so a test can hold the
 * wording to the behaviour. `instrumentation.ts` prints them.
 */
export function startupWarnings(env: Record<string, string | undefined>): string[] {
  const out: string[] = [];

  const hops = env.TRUSTED_PROXY_HOPS?.trim();
  if (!hops || hops === "0") {
    //0.16.4 (audit F5): with no client address the per-address sign-in limits are off, not shared
    out.push(
      "TRUSTED_PROXY_HOPS is not set, so the panel cannot see client addresses. Sign-in is limited "
        + `per email only (${MAX_FAILURES_PER_EMAIL} wrong passwords in ${FAILURE_WINDOW_MS / 60_000} minutes locks that `
        + "address), sign-in link requests are not limited per address, and auth-failed.log records "
        + "no address for fail2ban. Behind one proxy, set TRUSTED_PROXY_HOPS=1 in panel.env."
    );
  }

  //0.16.4 (audit F7): the env-variable operator works only without a configuration database
  if (envOperatorIgnored(env)) {
    out.push(
      "OPERATOR_PASSWORD is set but ignored, because CONFIG_DATABASE_URL is set: operators sign in "
        + "with an app_user row. Create an admin with 'fireflo user add --email you@example.com "
        + "--role admin --generate' if there is none, then remove OPERATOR_USERNAME and OPERATOR_PASSWORD "
        + "from panel.env."
    );
  }

  return out;
}
