/**
 * Strict-Transport-Security, decided twice (0.16.4, audit F6).
 *
 * <p><strong>Per request, in `proxy.ts`:</strong> when the request arrived over HTTPS -- the proxy
 * in front says so in `X-Forwarded-Proto`, or the URL itself is https. A forged header only
 * changes what the forger's own browser remembers.
 *
 * <p><strong>Statically, in `next.config.ts`:</strong> those headers are fixed when the panel is
 * BUILT and cannot see a request, so they follow configuration: `AUTH_COOKIE_SECURE` when it is set
 * either way, else on for a production build whose `AUTH_URL` (or `NEXTAUTH_URL`) is https. The
 * installer builds without panel.env loaded, so on an installed panel the proxy is what sends it.
 *
 * <p>Leaf module: no imports, so `next.config.ts`, the proxy and `node --test` can all load it.
 */
export const HSTS_HEADER = "Strict-Transport-Security";
export const HSTS_VALUE = "max-age=31536000";

export function hstsByConfig(env: Record<string, string | undefined>): boolean {
  const secure = env.AUTH_COOKIE_SECURE?.trim();
  if (secure) {
    return secure === "true";
  }
  const url = (env.AUTH_URL?.trim() || env.NEXTAUTH_URL?.trim() || "").toLowerCase();
  return env.NODE_ENV === "production" && url.startsWith("https://");
}

export function requestIsHttps(req: { headers: Headers; url: string }): boolean {
  const forwarded = req.headers.get("x-forwarded-proto");
  if (forwarded) {
    return forwarded.split(",")[0].trim().toLowerCase() === "https";
  }
  return req.url.toLowerCase().startsWith("https://");
}
