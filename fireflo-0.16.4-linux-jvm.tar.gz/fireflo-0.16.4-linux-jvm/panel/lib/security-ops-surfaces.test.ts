import { test } from "node:test";
import assert from "node:assert/strict";
import type { RefusalSummaryRow } from "./ban-rules.ts";
import { emptySurfaceCounts, parseGatewayRefusals, surfaceLabel } from "./security-events.ts";
import { SURFACES, groupByAddress } from "./security-grouping.ts";
import { attemptsFrom, ledgerRowsFrom, surfaceOfLedgerRow } from "./security-rows.ts";

/**
 * Gateway 0.16.4 writes a refused ops read token to the refusal log: `surface=metrics` for
 * `GET /q/metrics` on the messaging port, `surface=ops` for `POST /graphql` on the ops port. Before
 * this the parser dropped those lines and the ledger called their rows SMPP.
 */

const LINES = [
  '2026-11-19 09:30:00,101 WARN  auth.refused surface=metrics reason=badPassword identity="token" ip=203.0.113.9',
  '2026-11-19 09:30:01,102 WARN  auth.refused surface=ops reason=missingCredential identity="token" ip=198.51.100.4',
  '2026-11-19 09:30:02 WARN  auth.refused surface=smpp reason=badPassword identity="acme" listener=smppserver.main port=22775 ip=203.0.113.9',
];

const row = (listener: string | null): RefusalSummaryRow => ({ listener, port: 9000, total: 1, byReason: [], byAddress: [] });

test("metrics and ops refusal lines are read, not dropped", () => {
  const events = parseGatewayRefusals(LINES);
  assert.equal(events.length, 3);
  assert.deepEqual(events.map((e) => e.surface), ["metrics", "ops", "smpp"]);
  assert.equal(events[0].reason, "badPassword");
  assert.equal(events[1].ip, "198.51.100.4");
});

test("ledger rows named metrics and ops are those surfaces, not SMPP", () => {
  assert.equal(surfaceOfLedgerRow(row("metrics")), "metrics");
  assert.equal(surfaceOfLedgerRow(row("ops")), "ops");
  assert.equal(surfaceOfLedgerRow(row("smppserver.main")), "smpp");
  assert.equal(surfaceOfLedgerRow(row(null)), "rest");
  const rows = [row("metrics"), row("ops"), row("smppserver.main")];
  assert.deepEqual(ledgerRowsFrom(rows, { surface: "ops" }).map((r) => r.listener), ["ops"]);
  assert.deepEqual(ledgerRowsFrom(rows, { surface: "smpp" }).map((r) => r.listener), ["smppserver.main"]);
});

test("they are labelled plainly, counted, and offered in the surface filter", () => {
  assert.equal(surfaceLabel("metrics"), "Metrics");
  assert.equal(surfaceLabel("ops"), "Ops port");
  assert.ok(SURFACES.includes("metrics") && SURFACES.includes("ops"));
  assert.equal(emptySurfaceCounts().metrics, 0);
  assert.equal(emptySurfaceCounts().ops, 0);
  const events = parseGatewayRefusals(LINES);
  assert.equal(attemptsFrom(events, { surface: "metrics" }).length, 1);
  const byIp = groupByAddress(events).find((g) => g.ip === "203.0.113.9")!;
  assert.equal(byIp.bySurface.metrics, 1);
  assert.equal(byIp.bySurface.smpp, 1);
});
