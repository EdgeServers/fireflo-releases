/**
 * How long a sign-in lasts, for both NextAuth instances (operator and portal).
 *
 * <p>Twelve hours, renewed whenever the browser asks the session endpoint again: the operator
 * dashboard's SessionProvider does on every page load and window focus, and the portal frame does
 * the same through `MisShell`. A session nobody touches for twelve hours ends. Before 0.16.4 no
 * maxAge was set and @auth/core's default of 30 days applied, to the cookie and to the token inside
 * it (audit F6). The token stays valid after sign-out until it expires -- it is stateless -- so this
 * figure is also how long a copied cookie lasts if nobody renews it.
 */
export const SESSION_MAX_AGE_SECONDS = 12 * 60 * 60;

/** How often the portal frame renews its session: well inside the lifetime, rarely enough to cost nothing. */
export const SESSION_RENEW_MS = 5 * 60_000;
