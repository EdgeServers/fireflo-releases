import { AsyncLocalStorage } from "node:async_hooks";

/**
 * Where one request's data came from, and how long each source took: the reads it made on the
 * panel's two PostgreSQL pools and the calls it made to the gateway's GraphQL port.
 *
 * <p>The footer's "DB 192.0.2.10:5432 128 ms (3 reads)" is built from this (0.15.1): the routes a
 * page reads through are wrapped in `withSourceTrace` (`lib/source-trace-route.ts`), which runs the
 * handler inside {@link enterTrace} and writes the totals as the `X-FireFlo-Source` header.
 *
 * <p>The same pattern as `lib/request-context.ts`: an async context follows every `await` in the
 * handler's chain, so `query()` in `metrics-db.ts` deep inside a reader finds the request's trace
 * without being handed it. Outside a wrapped request there is no trace and recording is a no-op,
 * so a background job or a test pays nothing and changes nothing.
 *
 * <p>Server-only. Nothing here reaches a browser except the totals the header carries; the SQL is
 * never recorded.
 */

export type DbPool = "metrics" | "config";

export interface DbCall {
  pool: DbPool;
  /** Wall time of the pool call, connection acquisition included. */
  ms: number;
  /** The answer was kept from an earlier request's read (`stats-cache.ts`): `ms` is that read's. */
  cached?: boolean;
}

export interface GatewayCall {
  /** The ops URL's `host:port`. */
  host: string;
  ms: number;
  cached?: boolean;
}

export interface DbTrace {
  calls: DbCall[];
  gateway: GatewayCall[];
  /**
   * Set by a route whose caller must not be told where the data lives (a customer's stats): the
   * wrapper then writes no header at all.
   */
  hidden?: boolean;
}

const storage = new AsyncLocalStorage<DbTrace>();

function fresh(): DbTrace {
  return { calls: [], gateway: [] };
}

/** Runs `fn` inside a fresh trace, which {@link currentTrace} answers until it settles. */
export function enterTrace<T>(fn: () => T): T {
  return storage.run(fresh(), fn);
}

/** The trace of the request in progress, or null outside a wrapped one. */
export function currentTrace(): DbTrace | null {
  return storage.getStore() ?? null;
}

/**
 * Runs `fn` in a trace of its own and answers that trace beside the value: for a read whose cost
 * belongs to a cache entry rather than to whichever request happened to start it.
 */
export async function captureTrace<T>(fn: () => Promise<T>): Promise<{ value: T; trace: DbTrace }> {
  const trace = fresh();
  const value = await storage.run(trace, fn);
  return { value, trace };
}

/**
 * Copies `from`'s calls onto the current trace, marked `cached` when the answer was kept rather
 * than read for this request. No current trace, or nothing to copy: nothing happens.
 */
export function adoptTrace(from: DbTrace | undefined, cached: boolean): void {
  const into = currentTrace();
  if (!into || !from) {
    return;
  }
  for (const c of from.calls) {
    into.calls.push({ ...c, cached: cached || c.cached === true });
  }
  for (const g of from.gateway) {
    into.gateway.push({ ...g, cached: cached || g.cached === true });
  }
}

/**
 * The last traced read per pool in this process, ms: what the Queues page's Database card shows as
 * "last read". One number per pool, overwritten by every traced call, so it costs nothing to keep.
 * A read outside a traced request (a background job) is not timed and does not move it.
 */
const lastRead: Record<DbPool, number | null> = { metrics: null, config: null };

/** The last traced read on `pool` in this process, ms; null before the first. */
export function lastReadMs(pool: DbPool): number | null {
  return lastRead[pool];
}

/** Records one database call on the current trace; a no-op outside one. */
export function recordDbCall(pool: DbPool, ms: number): void {
  const trace = currentTrace();
  if (trace) {
    trace.calls.push({ pool, ms });
    lastRead[pool] = ms;
  }
}

/** Records one gateway call on the current trace; a no-op outside one. */
export function recordGatewayCall(host: string, ms: number): void {
  currentTrace()?.gateway.push({ host, ms });
}

/**
 * Times `fn` and records it as one call on `pool`, whether it answered or threw: a failed read
 * still cost the page its wait.
 */
export async function timedDb<T>(pool: DbPool, fn: () => Promise<T>): Promise<T> {
  if (!currentTrace()) {
    return fn();
  }
  const started = performance.now();
  try {
    return await fn();
  } finally {
    recordDbCall(pool, performance.now() - started);
  }
}

/** Marks the current request's trace as not to be reported (see {@link DbTrace.hidden}). */
export function hideTrace(): void {
  const t = currentTrace();
  if (t) {
    t.hidden = true;
  }
}

/** Sums and the slowest call, per source: what the header carries. */
export interface TraceTotals {
  db: { pools: DbPool[]; ms: number; max: number; calls: number; cached: boolean } | null;
  gateway: { hosts: string[]; ms: number; max: number; calls: number; cached: boolean } | null;
}

export function traceTotals(t: DbTrace): TraceTotals {
  const db = t.calls.length
    ? {
        pools: [...new Set(t.calls.map((c) => c.pool))],
        ms: t.calls.reduce((s, c) => s + c.ms, 0),
        max: Math.max(...t.calls.map((c) => c.ms)),
        calls: t.calls.length,
        cached: t.calls.every((c) => c.cached === true),
      }
    : null;
  const gateway = t.gateway.length
    ? {
        hosts: [...new Set(t.gateway.map((g) => g.host))],
        ms: t.gateway.reduce((s, g) => s + g.ms, 0),
        max: Math.max(...t.gateway.map((g) => g.ms)),
        calls: t.gateway.length,
        cached: t.gateway.every((g) => g.cached === true),
      }
    : null;
  return { db, gateway };
}
