/**
 * The deprecated environment-variable operator (`OPERATOR_USERNAME` / `OPERATOR_PASSWORD`).
 *
 * <p><strong>Only for a panel with no configuration database (0.16.4, audit F7).</strong> Such a
 * panel has no `app_user` table to check against, so this is its only way in, and it stays. With
 * `CONFIG_DATABASE_URL` set the fallback is off, whether or not a user row exists yet: it signs in
 * as an admin with no two-factor, and "no user row yet" was a state an install could sit in for
 * good. Such an install creates its first admin on the gateway (`fireflo user add --email
 * you@example.com --role admin --generate`, or `fireflo-panel-install update`, which moves the
 * panel.env account into the database with the same password).
 *
 * <p>A leaf module that reads only the environment it is given, so `node --test` can hold it.
 */
export function envOperatorAllowed(env: Record<string, string | undefined>): boolean {
  return !env.CONFIG_DATABASE_URL?.trim() && !!env.OPERATOR_PASSWORD;
}

/** Set but ignored: a configuration database is in use. Said once at startup. */
export function envOperatorIgnored(env: Record<string, string | undefined>): boolean {
  return !!env.CONFIG_DATABASE_URL?.trim() && !!env.OPERATOR_PASSWORD;
}
