import { test } from "node:test";
import assert from "node:assert/strict";
import {
  FAILURE_WINDOW_MS,
  MAX_FAILURES,
  MAX_FAILURES_PER_EMAIL,
  MAX_KEYS,
  lockoutKey,
  signinLockout,
} from "./signin-lockout.ts";

/**
 * Two counters behind one key: ten per origin+email, thirty per email from anywhere.
 *
 * <p>The second exists because the first is the one an attacker steps around by changing source
 * address (or by forging one, which is what a panel without `TRUSTED_PROXY_HOPS` used to allow).
 * Each case here rotates the address and asks whether the account still locks.
 */

const EMAIL = "Ops@Example.com";

function failTimes(lockout: ReturnType<typeof signinLockout>, key: string, n: number): void {
  for (let i = 0; i < n; i++) {
    lockout.noteFailure(key);
  }
}

test("ten failures from one origin lock that origin, and only that origin", () => {
  const lockout = signinLockout();
  const here = lockoutKey("203.0.113.9", EMAIL);
  const there = lockoutKey("198.51.100.7", EMAIL);

  failTimes(lockout, here, MAX_FAILURES - 1);
  assert.equal(lockout.lockedOut(here), false, "nine is still allowed");
  lockout.noteFailure(here);
  assert.equal(lockout.lockedOut(here), true, "the tenth locks");
  assert.equal(lockout.lockedOut(there), false, "the operator at another address is not locked");
});

test("rotating addresses locks the email once thirty failures have landed on it", () => {
  const lockout = signinLockout();
  //three failures from each of ten addresses: no single origin reaches ten, so the per-origin rule
  //never fires and the account would be open to a slow rotation forever
  for (let addr = 0; addr < 10; addr++) {
    failTimes(lockout, lockoutKey(`10.0.0.${addr}`, EMAIL), 3);
  }
  assert.equal(30, MAX_FAILURES_PER_EMAIL, "this test spends exactly the ceiling");
  assert.equal(lockout.lockedOut(lockoutKey("192.0.2.1", EMAIL)), true, "a never-seen address is refused too");
  assert.equal(lockout.lockedOut(lockoutKey("192.0.2.1", "someone.else@example.com")), false, "other accounts are untouched");
});

test("the email ceiling is reached one failure short, then not", () => {
  const lockout = signinLockout();
  for (let i = 0; i < MAX_FAILURES_PER_EMAIL - 1; i++) {
    lockout.noteFailure(lockoutKey(`10.1.${i}.1`, EMAIL));
  }
  assert.equal(lockout.lockedOut(lockoutKey("192.0.2.1", EMAIL)), false, "twenty-nine from anywhere is still allowed");
  lockout.noteFailure(lockoutKey("10.9.9.9", EMAIL));
  assert.equal(lockout.lockedOut(lockoutKey("192.0.2.1", EMAIL)), true);
});

test("the email half is case-folded, so changing case is not a new account", () => {
  const lockout = signinLockout();
  for (let i = 0; i < MAX_FAILURES_PER_EMAIL; i++) {
    lockout.noteFailure(lockoutKey(`10.2.${i}.1`, i % 2 ? "ops@example.com" : "OPS@EXAMPLE.COM"));
  }
  assert.equal(lockout.lockedOut(lockoutKey("192.0.2.1", "Ops@Example.Com")), true);
});

test("an unknown address is not one shared origin: only the per-email cap applies", () => {
  //what a panel with no TRUSTED_PROXY_HOPS sees: every caller is `-`. Counting that as one origin
  //let ten wrong passwords from anyone lock the admin out for everyone (0.16.4, audit F5)
  const lockout = signinLockout();
  failTimes(lockout, lockoutKey(null, EMAIL), MAX_FAILURES);
  assert.equal(lockout.lockedOut(lockoutKey(null, EMAIL)), false, "ten from unknown places do not lock");
  assert.equal(lockout.keysHeld().perOrigin, 0, "nothing is counted per origin");
  failTimes(lockout, lockoutKey(null, EMAIL), MAX_FAILURES_PER_EMAIL - MAX_FAILURES - 1);
  assert.equal(lockout.lockedOut(lockoutKey(null, EMAIL)), false, "twenty-nine still allowed");
  lockout.noteFailure(lockoutKey(null, EMAIL));
  assert.equal(lockout.lockedOut(lockoutKey(null, EMAIL)), true, "the thirtieth locks the address");
  assert.equal(lockout.lockedOut(lockoutKey("192.0.2.1", EMAIL)), true, "from anywhere");
});

test("tryAttempt with an unknown address stops at the per-email cap", () => {
  const lockout = signinLockout();
  const key = lockoutKey(null, EMAIL);
  let allowed = 0;
  for (let i = 0; i < 100; i++) {
    if (lockout.tryAttempt(key)) {
      allowed++;
    }
  }
  assert.equal(allowed, MAX_FAILURES_PER_EMAIL);
});

test("a flood of throw-away addresses does not reset the count against a real one", () => {
  //the map used to be cleared outright past ten thousand keys, which started the target's thirty
  //guesses over (0.16.4, audit F5)
  const lockout = signinLockout();
  failTimes(lockout, lockoutKey("203.0.113.9", EMAIL), MAX_FAILURES);
  for (let addr = 0; addr < 20; addr++) {
    failTimes(lockout, lockoutKey(`10.3.0.${addr}`, EMAIL), 1);
  }
  assert.equal(lockout.lockedOut(lockoutKey("192.0.2.1", EMAIL)), true, "locked before the flood");
  for (let i = 0; i < MAX_KEYS * 2; i++) {
    lockout.noteFailure(lockoutKey("198.51.100.1", `throwaway${i}@example.com`));
  }
  assert.ok(lockout.keysHeld().perEmail <= MAX_KEYS, "still bounded");
  assert.ok(lockout.keysHeld().perOrigin <= MAX_KEYS, "still bounded");
  assert.equal(lockout.lockedOut(lockoutKey("192.0.2.1", EMAIL)), true, "the address under attack stays locked");
  assert.equal(lockout.lockedOut(lockoutKey("203.0.113.9", EMAIL)), true, "and so does its origin");
});

test("eviction drops expired windows before live ones", (t) => {
  const lockout = signinLockout();
  let now = 1_000_000;
  t.mock.method(Date, "now", () => now);
  //a partly-counted address: not locked, so it is not protected by having the most failures
  failTimes(lockout, lockoutKey(null, EMAIL), 5);
  for (let i = 0; i < MAX_KEYS - 1; i++) {
    lockout.noteFailure(lockoutKey(null, `old${i}@example.com`));
  }
  now += FAILURE_WINDOW_MS + 1;
  failTimes(lockout, lockoutKey(null, "late@example.com"), 1);
  //every old key had expired, so they went and the map shrank
  assert.ok(lockout.keysHeld().perEmail < 10, `expired keys swept, ${lockout.keysHeld().perEmail} left`);
});

test("a success clears both counters", () => {
  const lockout = signinLockout();
  for (let addr = 0; addr < 10; addr++) {
    failTimes(lockout, lockoutKey(`10.0.0.${addr}`, EMAIL), 3);
  }
  assert.equal(lockout.lockedOut(lockoutKey("10.0.0.1", EMAIL)), true);
  lockout.clear(lockoutKey("10.0.0.1", EMAIL));
  assert.equal(lockout.lockedOut(lockoutKey("10.0.0.1", EMAIL)), false);
  assert.equal(lockout.lockedOut(lockoutKey("10.0.0.2", EMAIL)), false, "the email counter went too");
});

test("the window ends and both counters start over", (t) => {
  const lockout = signinLockout();
  let now = 1_000_000;
  t.mock.method(Date, "now", () => now);

  for (let addr = 0; addr < 10; addr++) {
    failTimes(lockout, lockoutKey(`10.0.0.${addr}`, EMAIL), 3);
  }
  failTimes(lockout, lockoutKey("203.0.113.9", EMAIL), MAX_FAILURES);
  assert.equal(lockout.lockedOut(lockoutKey("203.0.113.9", EMAIL)), true);
  assert.equal(lockout.lockedOut(lockoutKey("192.0.2.1", EMAIL)), true);

  now += FAILURE_WINDOW_MS + 1;
  assert.equal(lockout.lockedOut(lockoutKey("203.0.113.9", EMAIL)), false);
  assert.equal(lockout.lockedOut(lockoutKey("192.0.2.1", EMAIL)), false);
});

test("the lockout key keeps the email recoverable after any address", () => {
  assert.equal(lockoutKey("2001:db8::1", "A@B.c"), "2001:db8::1|a@b.c");
  assert.equal(lockoutKey(null, "a@b.c"), "-|a@b.c");
});

/**
 * The shape of a sign-in: check, then await the password derivation, then decide. Counted with
 * tryAttempt before the await, as `lib/auth.ts` and `lib/mis-auth.ts` now do.
 */
async function signIn(lockout: ReturnType<typeof signinLockout>, key: string, right: boolean): Promise<"refused" | "wrong" | "in"> {
  if (!lockout.tryAttempt(key)) {
    return "refused";
  }
  //the derivation: every parallel attempt is in flight here at once
  await new Promise((resolve) => setTimeout(resolve, 5));
  if (!right) {
    return "wrong";
  }
  lockout.clear(key);
  return "in";
}

test("a parallel burst of wrong passwords gets the limit's worth checked, not the burst", async () => {
  const lockout = signinLockout();
  const key = lockoutKey("203.0.113.9", EMAIL);
  const results = await Promise.all(Array.from({ length: 200 }, () => signIn(lockout, key, false)));
  assert.equal(results.filter((r) => r === "wrong").length, MAX_FAILURES, "exactly the limit reached the password check");
  assert.equal(results.filter((r) => r === "refused").length, 200 - MAX_FAILURES);
  assert.equal(lockout.lockedOut(key), true);
});

test("the old check-then-count shape let the whole burst through (the bug, kept as the reason)", async () => {
  const lockout = signinLockout();
  const key = lockoutKey("203.0.113.9", EMAIL);
  const old = async () => {
    if (lockout.lockedOut(key)) {
      return "refused";
    }
    await new Promise((resolve) => setTimeout(resolve, 5));
    lockout.noteFailure(key);
    return "wrong";
  };
  const results = await Promise.all(Array.from({ length: 200 }, old));
  assert.equal(results.filter((r) => r === "wrong").length, 200);
});

test("a success gives its counted attempt back", async () => {
  const lockout = signinLockout();
  const key = lockoutKey("198.51.100.1", EMAIL);
  for (let i = 0; i < MAX_FAILURES - 1; i++) {
    await signIn(lockout, key, false);
  }
  assert.equal(await signIn(lockout, key, true), "in");
  assert.equal(lockout.lockedOut(key), false);
  assert.equal(await signIn(lockout, key, false), "wrong", "counting starts over after a success");
});
