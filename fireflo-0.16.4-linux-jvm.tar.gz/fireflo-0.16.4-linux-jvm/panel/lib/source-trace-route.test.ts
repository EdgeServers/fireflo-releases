import { test } from "node:test";
import assert from "node:assert/strict";
import { hideTrace, recordDbCall, recordGatewayCall } from "./db-trace.ts";
import { parseSource, SOURCE_HEADER } from "./source-header.ts";
import { withSourceTrace } from "./source-trace-route.ts";
import { StatsCache } from "./stats-cache.ts";

const labels = async (pool: string) => (pool === "metrics" ? "192.0.2.10:5432" : "cfg.internal (192.0.2.11):5432");

test("withSourceTrace writes the totals of the handler's calls and passes its arguments through", async () => {
  const GET = withSourceTrace(async (a: number, b: string) => {
    recordDbCall("metrics", 20);
    await new Promise((r) => setTimeout(r, 1));
    recordDbCall("metrics", 30);
    recordGatewayCall("127.0.0.1:9000", 4);
    return Response.json({ a, b });
  }, labels);
  const res = await GET(1, "x");
  assert.deepEqual(await res.json(), { a: 1, b: "x" });
  const s = parseSource(res.headers.get(SOURCE_HEADER));
  assert.deepEqual(s, {
    db: { host: "192.0.2.10:5432", ms: 50, calls: 2, max: 30, pools: ["metrics"], cached: false },
    gateway: { host: "127.0.0.1:9000", ms: 4, calls: 1, max: 4, cached: false },
  });
});

test("two pools on two servers are both named", async () => {
  const res = await withSourceTrace(async () => {
    recordDbCall("metrics", 1);
    recordDbCall("config", 2);
    return new Response("ok");
  }, labels)();
  assert.equal(parseSource(res.headers.get(SOURCE_HEADER))?.db?.host, "192.0.2.10:5432,cfg.internal (192.0.2.11):5432");
});

test("no calls, a hidden trace or a refusal: no header", async () => {
  const none = await withSourceTrace(async () => new Response("ok"), labels)();
  assert.equal(none.headers.get(SOURCE_HEADER), null);
  const hidden = await withSourceTrace(async () => { recordDbCall("metrics", 1); hideTrace(); return new Response("ok"); }, labels)();
  assert.equal(hidden.headers.get(SOURCE_HEADER), null);
  for (const status of [401, 403, 404]) {
    const refused = await withSourceTrace(async () => { recordDbCall("config", 1); return new Response("no", { status }); }, labels)();
    assert.equal(refused.headers.get(SOURCE_HEADER), null, String(status));
  }
});

test("immutable headers do not fail the answer", async () => {
  const res = await withSourceTrace(async () => { recordDbCall("metrics", 1); return Response.redirect("http://x/", 302); }, labels)();
  assert.equal(res.status, 302);
});

test("a cached stats answer reports the read that produced it, marked cached", async () => {
  const cache = new StatsCache(8);
  const run = async () => { recordDbCall("metrics", 120); recordDbCall("metrics", 80); return "rows"; };
  const route = withSourceTrace(async () => {
    const answer = await cache.get("k", 60_000, run);
    return Response.json(answer.value);
  }, labels);
  const first = parseSource((await route()).headers.get(SOURCE_HEADER));
  assert.deepEqual(first?.db, { host: "192.0.2.10:5432", ms: 200, calls: 2, max: 120, pools: ["metrics"], cached: false });
  const second = parseSource((await route()).headers.get(SOURCE_HEADER));
  assert.deepEqual(second?.db, { host: "192.0.2.10:5432", ms: 200, calls: 2, max: 120, pools: ["metrics"], cached: true });
});

test("a refresh behind an expired answer is charged to nobody", async () => {
  let t = 0;
  const cache = new StatsCache(8, () => t);
  let n = 0;
  const run = async () => { n++; recordDbCall("metrics", n * 10); return n; };
  const route = withSourceTrace(async () => Response.json((await cache.get("k", 1_000, run)).value), labels);
  await route();
  t = 5_000;
  const res = await route();
  //the kept answer, with its own read's 10 ms; the refresh's 20 ms is not this request's
  assert.deepEqual(parseSource(res.headers.get(SOURCE_HEADER))?.db, { host: "192.0.2.10:5432", ms: 10, calls: 1, max: 10, pools: ["metrics"], cached: true });
  await new Promise((r) => setTimeout(r, 5));
  const later = await route();
  assert.equal(parseSource(later.headers.get(SOURCE_HEADER))?.db?.ms, 20);
});
