import { test } from "node:test";
import assert from "node:assert/strict";
import { startupWarnings } from "./startup-warnings.ts";

test("no TRUSTED_PROXY_HOPS is warned about by name, with the limit that still applies", () => {
  for (const hops of [undefined, "", " ", "0"]) {
    const warnings = startupWarnings({ TRUSTED_PROXY_HOPS: hops });
    const proxy = warnings.find((w) => w.includes("TRUSTED_PROXY_HOPS"));
    assert.ok(proxy, `warned for ${JSON.stringify(hops)}`);
    assert.match(proxy, /per email only \(30 wrong passwords in 15 minutes/);
  }
});

test("a configured proxy is not warned about", () => {
  assert.equal(startupWarnings({ TRUSTED_PROXY_HOPS: "1" }).some((w) => w.includes("TRUSTED_PROXY_HOPS")), false);
});
