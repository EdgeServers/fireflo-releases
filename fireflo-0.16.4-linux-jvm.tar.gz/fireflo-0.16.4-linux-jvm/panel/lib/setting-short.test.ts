import { strict as assert } from "node:assert";
import { test } from "node:test";

import { GATEWAY_SETTING_FIELDS } from "./gateway-setting-fields.ts";
import { SETTING_LABELS } from "./labels.ts";
import { PAGE_LINE_MAX, SETTING_FACTS, SETTING_SHORT, pageLine, settingFacts, settingShort } from "./setting-short.ts";

test("every line written for the page fits on it", () => {
  for (const [key, line] of Object.entries(SETTING_SHORT)) {
    assert.ok(line.length <= PAGE_LINE_MAX, `${key}: ${line.length} characters`);
    assert.match(line, /[.!?]$/, `${key} ends as a sentence`);
  }
});

test("a long Gateway setting hint has a line for the page: its own, or a first sentence that fits", () => {
  for (const field of GATEWAY_SETTING_FIELDS) {
    const shown = pageLine(field.hint, settingShort(field.key));
    assert.ok(shown.line.length <= PAGE_LINE_MAX, `${field.key}: write a line in SETTING_SHORT (${shown.line.length} shown)`);
  }
});

test("a long listener or vendor setting hint has a line for the page", () => {
  for (const [key, entry] of Object.entries(SETTING_LABELS as Record<string, { hint?: string }>)) {
    const shown = pageLine(entry.hint, settingShort(key));
    assert.ok(shown.line.length <= PAGE_LINE_MAX, `${key}: write a line in SETTING_SHORT (${shown.line.length} shown)`);
  }
});

test("no line is written for a key that does not exist", () => {
  const known = new Set<string>([
    ...GATEWAY_SETTING_FIELDS.map((f) => f.key),
    ...Object.keys(SETTING_LABELS),
  ]);
  for (const key of [...Object.keys(SETTING_SHORT), ...Object.keys(SETTING_FACTS)]) {
    assert.ok(known.has(key.replace(/@server$/, "")), `${key} is not a setting`);
  }
});

test("a hint that fits is the line, with nothing behind a button", () => {
  assert.deepEqual(pageLine("52 is SMPP 3.4", undefined), { line: "52 is SMPP 3.4", more: false });
  assert.deepEqual(pageLine(undefined, undefined), { line: "", more: false });
});

test("a long hint shows its written line, else a first sentence that fits, and keeps the rest", () => {
  const long = "Short first sentence. " + "And then a great deal more that nobody reads on the page itself, ".repeat(3);
  assert.deepEqual(pageLine(long, undefined), { line: "Short first sentence.", more: true });
  assert.deepEqual(pageLine(long, "What it is."), { line: "What it is.", more: true });
});

test("the rate and limit fields answer scope, what they limit, precedence and the refusal", () => {
  for (const key of [
    "smsg.restapi.maxRate.default", "smsg.vendor.backlog.max", "smsg.vendor.backlog.max.age.seconds",
    "tps", "conf.maxRate.default", "conf.maxConnectionsPerUser.default", "backlog.max", "backlog.max.age.seconds",
  ]) {
    const facts = settingFacts(key);
    assert.ok(facts, key);
    for (const part of ["scope", "limits", "precedence", "over"] as const) {
      assert.ok(facts[part].length > 10, `${key}.${part}`);
    }
  }
});

test("a listener's throughput limit is the port's budget, not a vendor's send rate", () => {
  assert.match(settingShort("tps", "server") ?? "", /port/);
  assert.match(settingShort("tps", "client") ?? "", /vendor/);
  assert.match(settingFacts("tps", "server")?.over ?? "", /0x58/);
});

test("one account's rate on a port has its line and its four answers", () => {
  assert.match(settingShort("conf.maxRate.YK201") ?? "", /account/);
  assert.match(settingFacts("conf.maxRate.YK201")?.over ?? "", /0x58/);
  assert.equal(settingFacts("conf.maxRate.default")?.scope.startsWith("This port, per account"), true);
});
