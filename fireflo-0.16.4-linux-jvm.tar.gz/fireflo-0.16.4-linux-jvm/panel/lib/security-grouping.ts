import { emptySurfaceCounts, type SecurityEvent, type SecuritySurface } from "./security-events.ts";
import { dayKeyIn, dayStartIn } from "./datetime.ts";

/**
 * The Security page's two views of the same refusals: who was doing it, and when.
 *
 * <p>Pure, like security-events.ts, so the rules are testable without a page.
 */

export const SURFACES: readonly SecuritySurface[] = ["smpp", "rest", "grpc", "metrics", "ops", "panel", "portal"];

/**
 * An address as a person reads it: an IPv4 client seen through an IPv6 socket loses its
 * {@code ::ffff:} prefix, so 127.0.0.1 and ::ffff:127.0.0.1 are one row rather than two.
 */
export function displayIp(ip: string): string {
  return ip.replace(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/i, "$1");
}

/** Everything one address did in the window. */
export interface AddressSummary {
  ip: string;
  attempts: number;
  bySurface: Record<SecuritySurface, number>;
  /** The names it tried, most-tried first. Attempted names, never identities. */
  triedAs: string[];
  firstAt: string | null;
  lastAt: string | null;
}

/**
 * One row per address, the busiest first, then the most recent.
 *
 * <p>An attack is one address working through names, and as one row per attempt it was the same
 * line fifty times with the one thing worth knowing -- how many, and which names -- left to count.
 */
export function groupByAddress(events: readonly SecurityEvent[]): AddressSummary[] {
  const groups = new Map<string, AddressSummary & { names: Map<string, number> }>();
  for (const e of events) {
    const ip = displayIp(e.ip);
    let g = groups.get(ip);
    if (!g) {
      g = {
        ip,
        attempts: 0,
        bySurface: emptySurfaceCounts(),
        triedAs: [],
        firstAt: null,
        lastAt: null,
        names: new Map(),
      };
      groups.set(ip, g);
    }
    g.attempts += 1;
    g.bySurface[e.surface] += 1;
    if (e.triedAs) {
      g.names.set(e.triedAs, (g.names.get(e.triedAs) ?? 0) + 1);
    }
    if (e.at) {
      if (!g.firstAt || e.at < g.firstAt) {
        g.firstAt = e.at;
      }
      if (!g.lastAt || e.at > g.lastAt) {
        g.lastAt = e.at;
      }
    }
  }
  return [...groups.values()]
    .map(({ names, ...g }) => ({
      ...g,
      triedAs: [...names.entries()].sort((a, b) => b[1] - a[1]).map(([name]) => name),
    }))
    .sort((a, b) => b.attempts - a.attempts || (b.lastAt ?? "").localeCompare(a.lastAt ?? ""));
}

/** One bar of the chart: a slice of time, counted per surface. */
export interface Bucket {
  /** ISO start of the slice. */
  start: string;
  /** For a daily slice, the billing day it is, `YYYY-MM-DD`: labelled as itself, never converted. */
  day?: string;
  total: number;
  bySurface: Record<SecuritySurface, number>;
}

/**
 * Refusals per slice across the whole window, empty slices included, so a quiet stretch reads as
 * quiet rather than as missing. Hourly up to two days, daily beyond, so thirty days is thirty bars
 * and not seven hundred.
 *
 * <p>Hourly slices are UTC hours, which the chart labels in the display zone (at :30 in India).
 * Daily slices are billing days, midnight to midnight in the billing zone, as every other day on
 * the panel is -- not the browser's days, which made "Tuesday" a different day for each viewer.
 *
 * @param windowHours the page's range
 * @param now the moment the data was read; the window ends here
 * @param billingZone the zone a day is cut in
 */
export function bucketsFor(events: readonly SecurityEvent[], windowHours: number, now: number, billingZone = "UTC"): Bucket[] {
  const step = windowHours <= 48 ? 3_600_000 : 86_400_000;
  const floor = (t: number) => {
    if (step === 3_600_000) {
      return Math.floor(t / step) * step;
    }
    return dayStartIn(dayKeyIn(t, billingZone), billingZone)?.getTime() ?? Math.floor(t / step) * step;
  };
  const first = floor(now - windowHours * 3_600_000 + 1);
  const last = floor(now);
  const buckets = new Map<number, Bucket>();
  for (let t = first; t <= last; t = floor(t + step + (step === 86_400_000 ? 3_600_000 : 0))) {
    buckets.set(t, {
      start: new Date(t).toISOString(),
      ...(step === 86_400_000 ? { day: dayKeyIn(t, billingZone) } : {}),
      total: 0,
      bySurface: emptySurfaceCounts(),
    });
    if (buckets.size > 24 * 31) {
      break;
    }
  }
  for (const e of events) {
    const at = e.at ? Date.parse(e.at) : Number.NaN;
    if (!Number.isFinite(at)) {
      continue;
    }
    const b = buckets.get(floor(at));
    if (b) {
      b.total += 1;
      b.bySurface[e.surface] += 1;
    }
  }
  return [...buckets.values()];
}
