/**
 * Ten FAILED attempts per address and peer per quarter hour, then a refusal until the window ends;
 * and thirty per address alone, whatever the peers, so rotating addresses still locks the account.
 *
 * <p>Failures, not attempts: a limiter that counted successes locked out an operator who signed in
 * from several tabs, and the e2e suite, which signs in once per test. A wrong password is what an
 * attacker produces and a right one is not. Bounded at {@link MAX_KEYS}, and when full it EVICTS
 * rather than clearing: expired windows first, then the entries with the fewest failures. It used to
 * clear the whole map, which let ten thousand sign-ins with throw-away addresses wipe the count
 * against a real one and start its thirty guesses over (0.16.4, audit F5). Throw-away addresses
 * carry one failure each, so they evict one another and an address under attack stays counted.
 *
 * <p>One per sign-in surface: the operator panel and the customer portal each make their own, so a
 * run of failures at one door never locks the other.
 *
 * <h2>Why two counters</h2>
 *
 * <p>The IP+email rule is the one an operator notices least: a stranger guessing at your address
 * from one place is locked out while you, from yours, are not. On its own it is also the one an
 * attacker steps around most cheaply -- a new source address is a new key -- and when the panel
 * cannot see the source address at all (no `TRUSTED_PROXY_HOPS`, see `lib/client-ip.ts`) the IP
 * half is a constant. Counting it then made one bucket of ten for everybody, so ten wrong passwords
 * from anyone locked that admin out for everyone -- so since 0.16.4 an unknown origin is NOT counted
 * per origin at all, and only the per-email cap applies. That cap is the deliberate floor: thirty
 * failures against one address inside the window,
 * from however many places, and that address is refused until the window ends. Thirty rather than
 * ten so a forgetful operator and a colleague retyping on their behalf do not trip it, and so the
 * cheapest denial of service -- thirty POSTs -- costs a lock of at most fifteen minutes.
 *
 * <p>Both live in process memory. A restart or a second panel instance forgets them, which is the
 * safe direction to be wrong in for a lockout but means neither is a durable record; persisting
 * failures across processes is deliberately out of scope here.
 */
export const MAX_FAILURES = 10;
export const MAX_FAILURES_PER_EMAIL = 30;
export const FAILURE_WINDOW_MS = 15 * 60_000;
/** How many keys each counter holds before it evicts. */
export const MAX_KEYS = 10_000;
/** What an eviction brings it back down to, so one does not run on every new key. */
const EVICT_TO = Math.floor(MAX_KEYS * 0.9);
/** The origin half {@link lockoutKey} writes when the address is not known. */
const UNKNOWN_ORIGIN = "-";

export interface SigninLockout {
  lockedOut(key: string): boolean;
  noteFailure(key: string): void;
  clear(key: string): void;
  /**
   * Checks and counts in one synchronous step: false when locked out, else the attempt is counted
   * now and true. Call it BEFORE the first await of a sign-in and {@link clear} it on success.
   *
   * <p>Checking first and counting after the password derivation let a burst of parallel attempts
   * all pass the check before any of them had been counted -- thousands of guesses through a limit
   * of ten. Counted up front, every attempt in flight is already in the count.
   */
  tryAttempt(key: string): boolean;
  /** For tests and diagnostics: how many keys each counter holds. */
  keysHeld(): { perOrigin: number; perEmail: number };
}

interface FailureWindow {
  count: number;
  until: number;
}

/**
 * Brings a full map back under {@link EVICT_TO}: expired windows go first, then the entries with the
 * fewest failures, oldest window first among equals. A locked entry has the most failures, so it is
 * the last to go -- a flood of new keys cannot reset the count against an address under attack.
 */
function evict(failures: Map<string, FailureWindow>, now: number): void {
  for (const [key, f] of failures) {
    if (now > f.until) {
      failures.delete(key);
    }
  }
  if (failures.size <= EVICT_TO) {
    return;
  }
  const order = [...failures.entries()].sort((a, b) => a[1].count - b[1].count || a[1].until - b[1].until);
  for (let i = 0; failures.size > EVICT_TO && i < order.length; i++) {
    failures.delete(order[i][0]);
  }
}

function counter(maxFailures: number) {
  const failures = new Map<string, FailureWindow>();
  return {
    size(): number {
      return failures.size;
    },
    locked(key: string, now: number): boolean {
      const f = failures.get(key);
      return !!f && now < f.until && f.count >= maxFailures;
    },
    note(key: string, now: number): void {
      const f = failures.get(key);
      if (!f || now > f.until) {
        if (!f && failures.size >= MAX_KEYS) {
          evict(failures, now);
        }
        failures.set(key, { count: 1, until: now + FAILURE_WINDOW_MS });
        return;
      }
      f.count += 1;
    },
    clear(key: string): void {
      failures.delete(key);
    },
  };
}

/**
 * @param key a {@link lockoutKey}: the per-origin counter is kept under the whole key and the
 *     per-address one under its email half, so callers keep passing the one string they always did
 */
export function signinLockout(): SigninLockout {
  const perOrigin = counter(MAX_FAILURES);
  const perEmail = counter(MAX_FAILURES_PER_EMAIL);
  return {
    lockedOut(key) {
      const now = Date.now();
      return (originKnown(key) && perOrigin.locked(key, now)) || perEmail.locked(emailOf(key), now);
    },
    noteFailure(key) {
      const now = Date.now();
      //an unknown origin is everybody at once: counting it would let ten wrong passwords from anyone
      //lock the address out for everyone (0.16.4). The per-email cap still counts every attempt
      if (originKnown(key)) {
        perOrigin.note(key, now);
      }
      perEmail.note(emailOf(key), now);
    },
    keysHeld() {
      return { perOrigin: perOrigin.size(), perEmail: perEmail.size() };
    },
    tryAttempt(key) {
      if (this.lockedOut(key)) {
        return false;
      }
      this.noteFailure(key);
      return true;
    },
    clear(key) {
      //a right password from anywhere clears both: the person who holds it is present, and the
      //window is short enough that an attacker gains at most another thirty guesses by their luck
      perOrigin.clear(key);
      perEmail.clear(emailOf(key));
    },
  };
}

/**
 * The key both sign-ins count failures under: where it came from, and which address it named.
 *
 * <p>`|` is the separator because no IP literal contains one (IPv6 uses `:`), so the email half can
 * be recovered by splitting at the first.
 */
export function lockoutKey(ip: string | null, email: string): string {
  return `${ip ?? UNKNOWN_ORIGIN}|${email.toLowerCase()}`;
}

function originKnown(key: string): boolean {
  return !key.startsWith(`${UNKNOWN_ORIGIN}|`);
}

function emailOf(key: string): string {
  const at = key.indexOf("|");
  return at < 0 ? key : key.slice(at + 1);
}
