import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * The control routes that hand out what the gateway admin token reads stay admin-only.
 *
 * <p>0.16.4 (audit F4): these were guarded by `requireOperator` while calling the gateway with
 * `auth: "admin"`. A pcap or a session capture holds SMPP binds with the password in clear; the
 * configuration files and the diagnostics bundle describe every customer. A regex over the source,
 * like `config-audit-coverage.test.ts`: each must call `requireAdmin(` and never `requireOperator(`.
 */

const ROOT = fileURLToPath(new URL("..", import.meta.url));

const ADMIN_ONLY = [
  "app/api/control/security/watch/[id]/pcap/route.ts",
  "app/api/control/workers/[name]/sessions/[id]/capture/file/[kind]/route.ts",
  "app/api/control/gateway-config/[name]/route.ts",
  "app/api/control/diagnostics/route.ts",
];

test("pcap, capture files, configuration files and the diagnostics bundle need an admin", () => {
  for (const file of ADMIN_ONLY) {
    const source = readFileSync(path.join(ROOT, file), "utf8");
    assert.ok(source.includes("requireAdmin("), `${file} must call requireAdmin()`);
    assert.ok(!source.includes("requireOperator("), `${file} must not settle for requireOperator()`);
  }
});

test("copying connection instructions needs an admin and is logged", () => {
  const source = readFileSync(path.join(ROOT, "app/api/control/credentials/[id]/instructions/route.ts"), "utf8");
  assert.match(source, /choice\.action === "copy" && who\.role !== ADMIN_ROLE/);
  assert.match(source, /action: "copy"/);
});
