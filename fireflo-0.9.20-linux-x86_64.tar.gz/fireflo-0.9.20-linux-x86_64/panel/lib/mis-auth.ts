import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { CUSTOMER_ROLE } from "@/lib/roles";
import { recordCustomerAccess } from "@/lib/customer-access-log";
import { redeemLoginToken } from "@/lib/login-token";
import { currentRequestContext } from "@/lib/request-context";

/**
 * Customer sign-in, for the portal at the site root.
 *
 * <p><strong>A second NextAuth instance, on its own cookie.</strong> Not a second provider on the
 * operator's: a provider shares the cookie, and a shared cookie means one token type for two kinds
 * of identity, so every operator route would be one missed check away from a customer. Separate
 * instances make the separation structural — this one cannot mint the operator role, and the
 * operator's cannot mint an account id.
 *
 * <p>The credential is a one-time token from an emailed link. There is no password anywhere in this
 * flow, which is the point: customers do not get an account here, they get proof they can read an
 * address the operator already recorded against their account.
 */
export const {
  handlers: misHandlers,
  auth: misAuth,
  signIn: misSignIn,
  signOut: misSignOut,
} = NextAuth({
  providers: [
    Credentials({
      id: "magic-link",
      name: "Sign-in link",
      credentials: { token: { label: "Token", type: "text" } },
      async authorize(credentials) {
        const token = credentials?.token;
        if (typeof token !== "string") {
          return null;
        }
        //the address arrives through an async context, because this function is handed the token
        //and nothing else. Read here rather than inside login-token.ts, which stays free of
        //ambient state -- see lib/request-context.ts
        const context = currentRequestContext();
        const ip = context?.ip ?? null;
        const userAgent = context?.userAgent ?? null;

        //spends the token. Anything falsy here -- unknown, expired, already used -- is one null,
        //because telling them apart would tell an attacker which of their guesses was close
        const accountId = await redeemLoginToken(token);
        if (!accountId) {
          //the caller still learns nothing; the log does
          void recordCustomerAccess({ event: "link_rejected", ip, userAgent });
          return null;
        }

        //the row that makes a stolen link visible: app_login_token.requested_ip says where the link
        //was asked for, this says where it was spent, and a mismatch is one query away
        void recordCustomerAccess({ event: "link_redeemed", accountId, ip, userAgent });
        return { id: accountId, name: accountId };
      },
    }),
  ],

  pages: { signIn: "/" },
  //NextAuth assumes /api/auth and builds every callback URL from it. The operator instance already
  //owns that path, so this one has to be told where it actually lives -- without it every endpoint
  //here answers "Bad request" because the route it thinks it is serving is not the route it is on
  basePath: "/api/mis/auth",
  trustHost: true,
  session: { strategy: "jwt" },

  callbacks: {
    jwt({ token, user }) {
      if (user) {
        token.role = CUSTOMER_ROLE;
        token.accountId = user.id;
      }
      return token;
    },
    session({ session, token }) {
      const t = token as { role?: string; accountId?: string };
      session.user.role = t.role ?? null;
      //the only place the account is ever established. Every portal query reads it from here and
      //nothing takes it from a request -- see require-customer.ts
      (session.user as { accountId?: string }).accountId = t.accountId;
      return session;
    },
  },

  cookies: {
    sessionToken: {
      //a different name from the operator's, which is what stops the browser sending one where the
      //other is expected
      name: "fireflo-mis.session-token",
      options: {
        httpOnly: true,
        sameSite: "lax" as const,
        path: "/",
        secure: process.env.NODE_ENV === "production",
      },
    },
  },
});
