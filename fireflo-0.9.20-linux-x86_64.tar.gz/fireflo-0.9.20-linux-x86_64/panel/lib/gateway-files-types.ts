/**
 * The shapes the gateway's file endpoints return, and the names it will answer to.
 *
 * <p>No `pg` import and no server-only code: this is read by a client component, and anything
 * pulling the database driver into that graph breaks the build rather than failing quietly.
 *
 * <p>The two name lists are duplicated from the gateway's own catalogue on purpose. They are the
 * allow-list the proxy routes check before calling upstream, so a browser cannot send an arbitrary
 * string into the gateway's URL — even though the gateway refuses unknown names itself. Two refusals
 * where one would do, because the cost is a constant and the failure is a path reaching a filesystem.
 */

/** Logs `/api/control/gateway-logs/[name]` will fetch. */
export const LOG_NAMES = ["main", "smppclient", "smppserver", "access"] as const;

/** Configuration files `/api/control/gateway-config/[name]` will fetch. */
export const CONFIG_NAMES = ["properties", "routing", "rates", "credentials"] as const;

export type LogName = (typeof LOG_NAMES)[number];
export type ConfigName = (typeof CONFIG_NAMES)[number];

export function isLogName(value: string): value is LogName {
  return (LOG_NAMES as readonly string[]).includes(value);
}

export function isConfigName(value: string): value is ConfigName {
  return (CONFIG_NAMES as readonly string[]).includes(value);
}

/**
 * Why there is nothing to show, which is never just "nothing".
 *
 * - `present` — here it is
 * - `missing` — the path is configured and there is no file at it
 * - `disabled` — the gateway is not writing this log at all, because file logging is off
 * - `not-read` — configuration comes from the database, so the file on disk is inert
 */
export type FileState = "present" | "missing" | "disabled" | "not-read";

export interface GatewayFileEntry {
  name: string;
  kind: "log" | "config";
  path: string;
  state: FileState;
  size_bytes?: number | null;
  modified?: string | null;
  note?: string | null;
}

export interface GatewayFileCatalog {
  observed_at: string;
  files: GatewayFileEntry[];
}

export interface GatewayLogTail {
  name: string;
  path: string;
  state: FileState;
  size_bytes?: number | null;
  requested_lines: number;
  returned_lines: number;
  /**
   * How much of the end of the file was read. A `filter` searched THIS, not the log — so an empty
   * result with `truncated` set means "not in the part that was read", which is a different claim
   * from "not in the log" and has to be shown as one.
   */
  window_bytes?: number | null;
  truncated: boolean;
  filter?: string | null;
  note?: string | null;
  lines: string[];
}

/**
 * One credential, as summarised by the gateway.
 *
 * <p>There is no password field and there will never be one: `credentials.yml` is projected field by
 * field on the gateway rather than redacted as text, so the secret is reported as set or missing and
 * never travels.
 */
export interface GatewayCredentialSummary {
  type: string | null;
  system_id: string | null;
  account_id: string | null;
  product: string | null;
  secret: "set" | "missing";
  allowed_ips: string[];
  default_tlvs: Record<string, string>;
}

export interface GatewayConfigView {
  name: string;
  path: string;
  /** `file` or `database` — which one is actually in force. */
  source: string;
  state: FileState;
  note?: string | null;
  /** Redacted text. Absent for `credentials`, which comes back as {@link credentials}. */
  content?: string | null;
  credentials?: GatewayCredentialSummary[] | null;
}

/**
 * What to say for a state, in the words an operator needs rather than the enum's.
 */
export function describeState(state: FileState, kind: "log" | "config"): string {
  switch (state) {
    case "present":
      return "In use";
    case "missing":
      return kind === "log" ? "Nothing written yet" : "File not found";
    case "disabled":
      return "Not being written";
    case "not-read":
      return "Not read (database mode)";
    default:
      return state;
  }
}
