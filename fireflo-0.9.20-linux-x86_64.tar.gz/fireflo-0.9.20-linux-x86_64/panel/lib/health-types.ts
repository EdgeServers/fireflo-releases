/**
 * The shape of `/ops/health`, and what to conclude from it.
 *
 * <p>No database import, so client components can use it. Shared rather than redeclared because the
 * health page and the vendor page read the same payload, and a field that drifts between two copies
 * of an interface is a silently absent number rather than a type error.
 */

/**
 * One bound connection: an outbound session for a vendor, a connected customer for a server.
 *
 * <p>Every field except `bound` is optional and nullable, because the gateway omits what it cannot
 * read rather than sending a placeholder — a vendor session has no `account`, a customer that bound
 * without a system_type has no `system_type`, and any session may have its counters switched off.
 */
export interface HealthSession {
  /**
   * What a disconnect names this session by, absent for a vendor's outbound sessions.
   *
   * <p>The listener's own counter and nothing more: two listeners will each have a session 3, and
   * the numbers restart with the gateway. Unique enough to key a table row and address a button,
   * worth nothing stored anywhere.
   */
  session_id?: number | null;
  bind_type?: string | null;
  bound: boolean;
  /** NORMAL, EXTRA or BACKUP — a vendor quietly running on its backup host looks identical without it. */
  role?: string | null;
  /** The far end: the host a vendor session dialled, or the address a customer bound from. */
  host?: string | null;
  port?: number | null;
  system_id?: string | null;
  account?: string | null;
  /**
   * What a customer asked to bind as, absent when the bind carried none.
   *
   * <p>Absent is a fact rather than a gap — it means the login's own product applied — so it must
   * not be filled in from the credential. This is what explains why a customer's traffic is priced
   * and whitelisted the way it is.
   */
  system_type?: string | null;
  submitted?: number | null;
  tps_measured?: number | null;
  tps_limit?: number | null;
  bound_seconds?: number | null;
}

export interface HealthWorker {
  name: string;
  type: string;
  accepting: boolean;
  paused: boolean;
  suspended_manually: boolean;
  suspended_automatically: boolean;
  //the gateway omits absent fields rather than sending null, so these are optional as well as
  //nullable -- and every check must be `!= null`, since `undefined !== null` is true
  bound?: number | null;
  bound_transmittable?: number | null;
  queue_depth: number;
  retry_queue_depth: number;
  tps_limit?: number | null;
  //what it is actually pushing, where tps_limit is only what it is allowed to. Zero is REAL here:
  //bound, counting and moving nothing. Guard with `!= null`, never with truthiness, or the most
  //alarming reading this page can show becomes invisible
  tps_measured?: number | null;
  submitted?: number | null;
  last_error?: string | null;
  last_error_at?: string | null;
  /**
   * The submit side, separate from last_error because they are different faults.
   *
   * <p>last_error is a BIND failure: the vendor would not let us connect. This is a per-message
   * rejection from a vendor that connected fine — which used to be invisible here entirely, so a
   * lane refusing every message looked identical to a healthy one.
   */
  last_submit_error?: string | null;
  last_submit_error_at?: string | null;
  submit_rejected?: number | null;
  //A SAMPLE, not the set — at most 20 per worker. Null when this is not an SMPP worker, empty when
  //it is one with nothing bound. Health is polled every few seconds by every open dashboard, and a
  //listener with 500 binds was sending 500 rows each time.
  //
  //Never count these to answer "how many are bound": that is `bound`, and `sessions_total` says how
  //many rows exist. To show or search the whole set, use /api/control/workers/<name>/sessions.
  sessions?: HealthSession[] | null;
  //how many sessions there really are, so a sample can be told from the set
  sessions_total?: number | null;
}

/** Which source each configuration domain was read from: `file` or `database`. */
export interface ConfigSources {
  properties?: string;
  credentials?: string;
  routing?: string;
  rates?: string;
}

/**
 * The message broker REST submissions queue through, when there is one.
 *
 * <p>Absent means this gateway is not configured to use a broker at all — which is a different fact
 * from a broker that is down, and must not be shown as "0 waiting".
 */
export interface HealthBroker {
  connected: boolean;
  queue?: string | null;
  //absent unless connected. An unreachable broker may be holding thousands
  messages?: number | null;
  consumers?: number | null;
}

export interface Health {
  observed_at: string;
  /**
   * The release the gateway process is running.
   *
   * Optional because a gateway older than the field simply omits it, which
   * `versionPairing` treats as "nothing to compare" rather than as a fault.
   */
  version?: string | null;
  router_queue: number;
  awaiting_receipt: number;
  dlr_store_persistent: boolean;
  config_sources?: ConfigSources | null;
  /** The window every `tps_measured` is averaged over, so a label need not hardcode it. */
  tps_window_seconds?: number | null;
  broker?: HealthBroker | null;
  cdr: { enabled: boolean; sink: string; written: number; failed: number } | null;
  /** Absent entirely when sender ID and content whitelisting is switched off. */
  whitelist?: HealthWhitelist | null;
  /**
   * Routing tables that load and route, but not the way they read.
   *
   * An empty array is the healthy answer and means "checked, nothing wrong". Absent means the
   * gateway predates the check — a distinction worth keeping, because this is the only place a
   * file-sourced `routingTable.conf` gets checked at all: the panel computes the same warnings for
   * itself, but only for the tables it can read out of the database.
   */
  routing_warnings?: HealthRoutingWarning[] | null;
  workers: HealthWorker[];
}

export interface HealthRoutingWarning {
  table: string;
  /** A stable token: `no-catch-all` or `unreachable-rules`. Match on this, not on `detail`. */
  cause: string;
  detail: string;
}

export interface HealthWhitelist {
  /**
   * Whether a whitelist has been loaded and may be enforced.
   *
   * <p>False while the block is present is the alarming state: the gateway was told to enforce and
   * has never read the tables, so nothing is being checked and everything is allowed. That is the
   * designed behaviour — an unloaded whitelist must not refuse traffic — but it is invisible from
   * outside without this field.
   */
  active: boolean;
  generation: number;
  scopes: number;
  header_rejects: number;
  template_rejects: number;
  /** What REPORT mode would have refused. The number an operator reads before enforcing. */
  report_only_would_reject: number;
  enforcing_with_nothing_approved: string[];
}

/**
 * Whether the gateway is reading its workers from the database at all.
 *
 * <p>When it is not, every row on the vendor and server pages is inert — stored, valid, and ignored.
 * That is invisible from the panel's own side: the switch is a bootstrap setting the gateway reads
 * before it opens the database, so it can only be reported, never queried.
 *
 * <p>Undefined when health could not be read, which is not the same as false and must not be shown
 * as reassurance.
 */
export function readsWorkersFromDatabase(health: Health | null): boolean | undefined {
  const source = health?.config_sources?.properties;
  return source == null ? undefined : source === "database";
}

/**
 * Whether the gateway is reading its **pricing** from the database.
 *
 * <p>The gateway has one switch — `smsg.config.source` — so in practice this agrees with
 * {@link readsWorkersFromDatabase}. It stays a separate function because `/ops/health` reports per
 * domain and a caller asking "is my pricing live" should not have to know that one key implies four.
 * It used to be four independent switches, and an operator who moved workers across and assumed
 * pricing had followed was looking at a page whose every row was stored, valid, and ignored.
 *
 * <p>Undefined when health could not be read, which is not the same as false and must not be shown
 * as reassurance.
 */
export function readsRatesFromDatabase(health: Health | null): boolean | undefined {
  const source = health?.config_sources?.rates;
  return source == null ? undefined : source === "database";
}

/**
 * Whether the gateway is authenticating from the database.
 *
 * <p>The third of three independent switches, and the one with the largest blast radius: with
 * `app_credential` empty and this set to `database`, the loader publishes an empty map rather than
 * ignoring it, so every bind and every REST call is refused at once and nothing in the logs names
 * the cause.
 *
 * <p>Undefined when health could not be read, which is not the same as false.
 */
export function readsCredentialsFromDatabase(health: Health | null): boolean | undefined {
  const source = health?.config_sources?.credentials;
  return source == null ? undefined : source === "database";
}

/**
 * Whether the gateway is reading its routing from the database.
 *
 * <p>The fourth of four independent switches. Included for completeness rather than because a page
 * edits routing today — nothing does — so that a future one cannot be written without the question
 * being asked.
 */
export function readsRoutingFromDatabase(health: Health | null): boolean | undefined {
  const source = health?.config_sources?.routing;
  return source == null ? undefined : source === "database";
}

/**
 * Whether sender ID and content whitelisting is switched on at all.
 *
 * <p>Not a configuration source — whitelisting is database-only and has no file form. The block is
 * absent from health when `smsg.whitelist.enabled` is unset, which means every approved sender ID
 * and template in the panel is recorded and enforcing nothing.
 *
 * <p>Undefined when health could not be read, which is not the same as false.
 */
export function whitelistEnabled(health: Health | null): boolean | undefined {
  if (!health) {
    return undefined;
  }
  return health.whitelist != null;
}

/**
 * Whether a whitelist has actually been loaded, once it is switched on.
 *
 * <p>Separate from {@link whitelistEnabled} because the two failures need different fixes: not
 * switched on is a configuration choice, switched on and never loaded is a database the gateway
 * cannot reach — and in that state nothing is being enforced despite the panel showing approvals.
 */
export function whitelistActive(health: Health | null): boolean | undefined {
  return health?.whitelist == null ? undefined : health.whitelist.active;
}

export type ConnectionState = "unloaded" | "connected" | "disconnected";

/**
 * Three states with three different fixes, which is why they are distinguished at all.
 *
 * <p><strong>`unloaded` is the one that matters</strong>: the worker is configured here and the
 * gateway has never heard of it. Reporting that as "not connected" would send someone to check a
 * password that was never used.
 *
 * <p>Note what is <em>not</em> used: `paused` from the snapshot is not an operator signal.
 * `SmppClientWorker.isPause()` returns true whenever there is no bound transmittable session, so it
 * is also true for a vendor nobody paused. Connectivity comes from `bound`, and intent comes from
 * the stored `suspend` and `pause` settings.
 */
export function connectionState(live: HealthWorker | undefined): ConnectionState {
  if (!live) {
    return "unloaded";
  }
  return (live.bound ?? 0) > 0 ? "connected" : "disconnected";
}

/**
 * Throughput as one phrase: what it is doing, and what it is allowed to do.
 *
 * <p>Shared by both pages so they cannot drift into describing the same two numbers differently.
 *
 * <p>The checks are `!= null` rather than truthiness for a reason worth stating twice: a measured
 * rate of exactly 0 on a bound, counting vendor is the single most useful thing here — it means
 * traffic has stopped — and `w.tps_measured &&` would silently drop it.
 *
 * @returns null when neither number exists, so a caller can omit the element entirely
 */
export function tpsSummary(worker: HealthWorker): string | null {
  const measured = worker.tps_measured != null ? `${worker.tps_measured} tps` : null;
  const limit = worker.tps_limit != null ? `\u2264${worker.tps_limit}` : null;
  if (measured && limit) {
    return `${measured} of ${limit}`;
  }
  return measured ?? (limit ? `${limit} tps` : null);
}

/**
 * How much of the configured ceiling is being used.
 *
 * @returns null when there is no ceiling, or nothing measured to compare against it
 */
export function tpsUtilisation(worker: HealthWorker): number | null {
  if (worker.tps_measured == null || worker.tps_limit == null || worker.tps_limit <= 0) {
    return null;
  }
  return worker.tps_measured / worker.tps_limit;
}
