/**
 * The slice of the `smpp` package (0.6.0-rc.4) the suite uses. The package ships no types; this
 * names what the fixtures call and nothing more, so an upgrade that renames something fails the
 * typecheck rather than a test.
 */
declare module "smpp" {
  import type { EventEmitter } from "node:events";
  import type { Socket } from "node:net";

  export interface Pdu {
    command: string;
    command_id: number;
    command_status: number;
    sequence_number: number;
    message_id?: string;
    system_id?: string;
    password?: string;
    system_type?: string;
    source_addr?: string;
    source_addr_ton?: number;
    source_addr_npi?: number;
    destination_addr?: string;
    dest_addr_ton?: number;
    dest_addr_npi?: number;
    short_message?: string | Buffer | { message: string | Buffer; udh?: Buffer };
    data_coding?: number;
    esm_class?: number;
    registered_delivery?: number;
    priority_flag?: number;
    validity_period?: string;
    receipted_message_id?: string;
    message_state?: number;
    [tlvOrField: string]: unknown;
    response(options?: Record<string, unknown>): Pdu;
    isResponse(): boolean;
  }

  export interface SessionOptions {
    /** an already-connected socket (server side, or a client that spoke first) */
    socket?: Socket;
    url?: string;
    host?: string;
    port?: number;
    localAddress?: string;
    auto_enquire_link_period?: number;
    connectTimeout?: number;
    debug?: boolean;
    tls?: boolean;
    rejectUnauthorized?: boolean;
  }

  export type PduCallback = (pdu: Pdu) => void;

  export class Session extends EventEmitter {
    constructor(options: SessionOptions);
    socket: Socket;
    options: SessionOptions;
    connect(): void;
    send(pdu: Pdu, responseCallback?: PduCallback, sendCallback?: () => void, failureCallback?: (e: Error) => void): boolean;
    pause(): void;
    resume(): void;
    close(callback?: () => void): void;
    destroy(callback?: () => void): void;
    bind_transceiver(params: Record<string, unknown>, cb?: PduCallback): void;
    bind_transmitter(params: Record<string, unknown>, cb?: PduCallback): void;
    bind_receiver(params: Record<string, unknown>, cb?: PduCallback): void;
    submit_sm(params: Record<string, unknown>, cb?: PduCallback): void;
    deliver_sm(params: Record<string, unknown>, cb?: PduCallback): void;
    enquire_link(params?: Record<string, unknown>, cb?: PduCallback): void;
    unbind(params?: Record<string, unknown>, cb?: PduCallback): void;
    generic_nack(params?: Record<string, unknown>, cb?: PduCallback): void;
    on(event: "pdu", listener: PduCallback): this;
    on(event: "connect" | "close" | "secureConnect", listener: () => void): this;
    on(event: "error", listener: (e: Error) => void): this;
    /** every SMPP command name ("submit_sm", "deliver_sm", "bind_transceiver", …) carries the PDU */
    on(event: string, listener: (pdu: Pdu) => void): this;
    once(event: "connect" | "close", listener: () => void): this;
    once(event: "error", listener: (e: Error) => void): this;
    emit(event: string, ...args: unknown[]): boolean;
  }

  export class Server extends EventEmitter {
    listen(port: number, host?: string, cb?: () => void): this;
    close(cb?: () => void): this;
    address(): { port: number } | string | null;
    on(event: "session", listener: (session: Session) => void): this;
    on(event: "error", listener: (e: Error) => void): this;
    on(event: string, listener: (...args: unknown[]) => void): this;
  }

  export function connect(options: SessionOptions, listener?: () => void): Session;
  export function createSession(options: SessionOptions, listener?: () => void): Session;
  export function createServer(options: Record<string, unknown>, listener?: (session: Session) => void): Server;
  export function addTLV(tag: string, options: Record<string, unknown>): void;
  export function addCommand(command: string, options: Record<string, unknown>): void;

  export const ESME_ROK: number;
  export const ESME_RINVPASWD: number;
  export const ESME_RINVSYSID: number;
  export const ESME_RBINDFAIL: number;
  export const ESME_RMSGQFUL: number;
  export const ESME_RTHROTTLED: number;
  export const ESME_RSUBMITFAIL: number;
  export const ESME_RINVDSTADR: number;
  export const ESME_RINVSRCADR: number;
  export const ESME_RALYBND: number;
  export const ESME_RINVBNDSTS: number;
  export const ESME_RSYSERR: number;
  export const ESME_RINVMSGLEN: number;
  export const errors: Record<string, number>;
  export const consts: Record<string, Record<string, number>>;
  /** field and TLV codecs; `types.tlv.string`, `types.tlv.buffer`, `types.tlv.int8/16/32` */
  export const types: { tlv: Record<string, unknown> } & Record<string, unknown>;
}
