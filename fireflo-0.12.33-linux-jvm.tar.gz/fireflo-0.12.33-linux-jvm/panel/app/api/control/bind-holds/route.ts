import { NextResponse } from "next/server";
import { callOps } from "@/lib/gateway-ops";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET /api/control/bind-holds
 *
 * <p>The IPs, accounts and logins an operator is holding out of SMPP binds, from the gateway.
 */
export async function GET(): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) return NextResponse.json({ error: "Not found" }, { status: 404 });
    throw err;
  }
  return callOps({ path: "/ops/bind-holds", timeoutMs: 5_000 });
}
