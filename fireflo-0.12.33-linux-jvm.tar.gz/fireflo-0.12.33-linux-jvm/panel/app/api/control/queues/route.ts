import { NextRequest, NextResponse } from "next/server";
import { callOps } from "@/lib/gateway-ops";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET /api/control/queues
 *
 * <p>Proxies the gateway's queue dump. The read token, not the admin one — listing a queue takes
 * nothing off it and moves nothing.
 *
 * <p>`worker` and `limit` are passed through rather than forwarded wholesale: the gateway's own
 * clamp is the authority on the limit, but building the query here rather than appending the
 * caller's string keeps anything else the browser sends out of the upstream URL.
 */
export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const params = new URLSearchParams();
  const worker = request.nextUrl.searchParams.get("worker");
  if (worker) {
    params.set("worker", worker);
  }
  const limit = request.nextUrl.searchParams.get("limit");
  if (limit && /^\d+$/.test(limit)) {
    params.set("limit", limit);
  }
  const query = params.toString();

  //the gateway walks its queues in memory; five seconds is already the diagnosis if it cannot
  return callOps({ path: `/ops/queues${query ? `?${query}` : ""}`, timeoutMs: 5_000 });
}
