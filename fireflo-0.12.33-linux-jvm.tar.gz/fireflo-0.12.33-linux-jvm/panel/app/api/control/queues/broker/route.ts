import { NextRequest, NextResponse } from "next/server";
import { logOperatorEvent } from "@/lib/access-log";
import { BROKER_KEYS, brokerProblem, maskAmqpUri, parseBrokerForm } from "@/lib/broker-config";
import { readBroker, saveBroker } from "@/lib/broker-config-db";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { isConfigWritable } from "@/lib/config-db";
import { NotOperatorError, requireAdmin, requireOperator } from "@/lib/require-operator";
import { ADMIN_ROLE } from "@/lib/roles";

/**
 * GET /api/control/queues/broker -- the broker settings as a form, without the password.
 * PUT -- saves them. Admins only: this decides where every REST submission goes.
 *
 * <p>The gateway connects to the broker when it starts, so a save takes effect at the next restart;
 * `/ops/queues` says when one is pending.
 */
export async function GET(): Promise<NextResponse> {
  let admin = false;
  try {
    admin = (await requireOperator()).role === ADMIN_ROLE;
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  if (!isConfigWritable()) {
    return NextResponse.json({ data: null, reason: "CONFIG_DATABASE_URL is not set, so the broker settings cannot be read here." });
  }
  try {
    return NextResponse.json({ data: { ...(await readBroker()), canEdit: admin } });
  } catch (err) {
    return NextResponse.json({ error: `Could not read the broker settings: ${message(err)}` }, { status: 500 });
  }
}

export async function PUT(req: NextRequest): Promise<NextResponse> {
  let actor: string;
  try {
    actor = (await requireAdmin()).name;
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  if (!isConfigWritable()) {
    return NextResponse.json({ error: "CONFIG_DATABASE_URL is not set, so editing is switched off." }, { status: 503 });
  }
  const form = parseBrokerForm(await req.json().catch(() => null));
  if (typeof form === "string") {
    return NextResponse.json({ error: form }, { status: 400 });
  }
  const current = await readBroker();
  const problem = brokerProblem(form, current.passwordSet);
  if (problem) {
    return NextResponse.json({ error: problem }, { status: 400 });
  }
  try {
    const changes = await saveBroker(form);
    for (const change of changes) {
      const mask = (v: string | null) => (v !== null && change.key === BROKER_KEYS.uri ? maskAmqpUri(v) : v);
      void logOperatorEvent({
        event: change.to === null ? "gateway_setting_cleared" : "gateway_setting_set",
        actor,
        ip: clientIp(req),
        userAgent: clientUserAgent(req),
        detail: { key: change.key, from: mask(change.from), to: mask(change.to) },
      });
    }
    return NextResponse.json({ data: { changed: changes.map((c) => c.key) } });
  } catch (err) {
    return NextResponse.json({ error: `Could not save: ${message(err)}` }, { status: 500 });
  }
}

function message(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}
