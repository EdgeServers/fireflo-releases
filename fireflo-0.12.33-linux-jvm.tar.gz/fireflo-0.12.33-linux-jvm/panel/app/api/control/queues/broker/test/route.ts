import { NextRequest, NextResponse } from "next/server";
import { BROKER_KEYS, brokerProblem, formFromStored, parseBrokerForm, uriForForm } from "@/lib/broker-config";
import { readBrokerStored } from "@/lib/broker-config-db";
import { callOps } from "@/lib/gateway-ops";
import { NotOperatorError, requireAdmin } from "@/lib/require-operator";

/**
 * POST /api/control/queues/broker/test
 *
 * <p>Asks the gateway to connect to the broker the form describes, saved or not, and report each
 * step. The URI is put together here, with the stored password when the form keeps it, so the
 * password never reaches the browser in either direction. Admins only.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    await requireAdmin();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const form = parseBrokerForm(await req.json().catch(() => null));
  if (typeof form === "string") {
    return NextResponse.json({ error: form }, { status: 400 });
  }
  if (form.provider !== "rabbitmq") {
    return NextResponse.json({ error: "There is no broker to test: REST submissions are queued in process." }, { status: 400 });
  }
  const stored = await readBrokerStored();
  const problem = brokerProblem(form, formFromStored(stored).passwordSet);
  if (problem) {
    return NextResponse.json({ error: problem }, { status: 400 });
  }
  return callOps({
    path: "/ops/queue/test",
    method: "POST",
    //the admin token: the body carries the broker's password, and this makes the gateway's host
    //dial an address of the caller's choosing
    auth: "admin",
    body: { uri: uriForForm(form, stored.get(BROKER_KEYS.uri) ?? null), queue: form.queue.trim() },
    //the gateway allows itself five seconds for TCP, five to connect and ten for the handshake
    timeoutMs: 30_000,
  });
}
