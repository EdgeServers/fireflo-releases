import { NextRequest, NextResponse } from "next/server";
import { callOps } from "@/lib/gateway-ops";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

const FIELDS = ["account", "to", "from", "product", "vendor", "content"];

/**
 * GET /api/control/rating/explain
 *
 * <p>The message tester's Pricing tab: what an account would pay, and what a vendor would charge. Proxies the gateway's `/ops/rating/explain` on the read token: it evaluates a message
 * nobody sends against the live configuration, and changes nothing.
 */
export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const params = new URLSearchParams();
  for (const field of FIELDS) {
    const value = request.nextUrl.searchParams.get(field);
    if (value) {
      params.set(field, value.slice(0, 2000));
    }
  }
  return callOps({ path: `/ops/rating/explain?${params.toString()}`, timeoutMs: 5_000 });
}
