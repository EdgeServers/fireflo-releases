import { NextResponse } from "next/server";
import { callOps } from "@/lib/gateway-ops";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET /api/control/health
 *
 * <p>Proxies the gateway's operational endpoint. A proxy rather than a direct browser call for two
 * reasons: the shared token stays on the server and never reaches a page, and the operator check
 * happens here rather than being something the gateway would have to learn about.
 */
export async function GET(): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  //the gateway is answering from memory; if it cannot do that in five seconds it is the problem
  //being diagnosed, not a slow query
  return callOps({ path: "/ops/health", timeoutMs: 5_000 });
}
