import { NextRequest, NextResponse } from "next/server";
import { callOps } from "@/lib/gateway-ops";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET /api/control/credentials/sessions?ids=a,b,c
 *
 * <p>Who is bound right now, per SMPP login, for the login cards: sessions by bind type across every
 * listener. Proxies the gateway's `/ops/sessions/summary` on the read token -- it walks the live
 * sessions and changes nothing. A login with nothing bound is absent from the answer. When the
 * gateway cannot be reached this fails, and the cards say nothing rather than "Not connected".
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const ids = (req.nextUrl.searchParams.get("ids") ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 200);
  if (!ids.length) {
    return NextResponse.json({ data: {} });
  }
  return callOps({ path: `/ops/sessions/summary?system_id=${encodeURIComponent(ids.join(","))}`, timeoutMs: 5_000 });
}
