import { NextRequest, NextResponse } from "next/server";
import { auditConfigChange } from "@/lib/config-audit";
import { callOps } from "@/lib/gateway-ops";
import { NotOperatorError, requireAdmin } from "@/lib/require-operator";

/**
 * DELETE /api/control/tps-peaks?scope=smppclient.x
 *
 * <p>Forgets one throughput peak -- a worker's, or a total (`all:vendors`, `all:servers`) -- so the
 * next measured traffic sets a new one. Admins only: it deletes a record. A scope is required here,
 * so a stray request cannot clear every peak at once; the gateway's own endpoint can.
 */
export async function DELETE(req: NextRequest): Promise<NextResponse> {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const scope = req.nextUrl.searchParams.get("scope")?.trim();
  if (!scope || scope.length > 200) {
    return NextResponse.json({ error: "Name the peak to reset." }, { status: 400 });
  }
  const res = await callOps({
    path: `/ops/tps-peaks?scope=${encodeURIComponent(scope)}`,
    method: "DELETE",
    auth: "admin",
  });
  if (res.ok) {
    //a record deleted, not configuration changed; logged under the same event because "who reset
    //the peak before the capacity review" is the same kind of question
    await auditConfigChange({ domain: "tps_peak", name: scope, action: "delete" }, admin);
  }
  return res;
}
