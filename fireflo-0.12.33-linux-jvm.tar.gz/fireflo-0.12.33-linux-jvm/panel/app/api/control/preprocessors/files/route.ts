import { NextResponse } from "next/server";
import { asOperator, gateway } from "@/lib/preprocessor-ops";

/** GET: the files in the gateway's preprocessor directory, and which preprocessors run each. */
export async function GET(): Promise<NextResponse> {
  const who = await asOperator();
  if (who instanceof NextResponse) return who;
  return gateway({ path: "/ops/preprocessors/files" });
}
