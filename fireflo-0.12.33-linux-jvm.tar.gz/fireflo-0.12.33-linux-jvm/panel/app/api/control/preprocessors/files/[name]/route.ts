import { NextRequest, NextResponse } from "next/server";
import { asAdmin, asOperator, auditCodeChange, gateway, jsonBody } from "@/lib/preprocessor-ops";

type Ctx = { params: Promise<{ name: string }> };

/** GET: one file's code, checksum and kept versions. */
export async function GET(_req: NextRequest, ctx: Ctx): Promise<NextResponse> {
  const who = await asOperator();
  if (who instanceof NextResponse) return who;
  const { name } = await ctx.params;
  return gateway({ path: `/ops/preprocessors/files/${encodeURIComponent(decodeURIComponent(name))}` });
}

/**
 * PUT: save it. `expectedSha` is the checksum the editor opened -- the gateway refuses with 409 when
 * somebody else saved in between. Live within about five seconds of a 200.
 */
export async function PUT(req: NextRequest, ctx: Ctx): Promise<NextResponse> {
  const who = await asAdmin();
  if (who instanceof NextResponse) return who;
  const { name } = await ctx.params;
  const file = decodeURIComponent(name);
  const body = await jsonBody(req);
  if (typeof body?.content !== "string") {
    return NextResponse.json({ error: "Expected { content, expectedSha }." }, { status: 400 });
  }
  const res = await gateway({
    path: `/ops/preprocessors/files/${encodeURIComponent(file)}`,
    method: "PUT",
    auth: "admin",
    body: { content: body.content, expectedSha: typeof body.expectedSha === "string" ? body.expectedSha : "", actor: who.name },
  });
  return auditCodeChange(req, who, "preprocessor_code_saved", res, {
    file,
    previousSha: typeof body.expectedSha === "string" && body.expectedSha ? body.expectedSha : null,
  });
}
