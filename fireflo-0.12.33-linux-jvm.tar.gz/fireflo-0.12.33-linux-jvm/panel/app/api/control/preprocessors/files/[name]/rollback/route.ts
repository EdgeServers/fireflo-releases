import { NextRequest, NextResponse } from "next/server";
import { asAdmin, auditCodeChange, gateway, jsonBody } from "@/lib/preprocessor-ops";

/** POST { sha }: put a kept version back. The restore is itself a version, so it can be undone. */
export async function POST(req: NextRequest, ctx: { params: Promise<{ name: string }> }): Promise<NextResponse> {
  const who = await asAdmin();
  if (who instanceof NextResponse) return who;
  const file = decodeURIComponent((await ctx.params).name);
  const body = await jsonBody(req);
  if (typeof body?.sha !== "string") {
    return NextResponse.json({ error: "Expected { sha }." }, { status: 400 });
  }
  const res = await gateway({
    path: `/ops/preprocessors/files/${encodeURIComponent(file)}/rollback`,
    method: "POST",
    auth: "admin",
    body: { sha: body.sha, actor: who.name },
  });
  return auditCodeChange(req, who, "preprocessor_code_restored", res, { file, restoredSha: body.sha });
}
