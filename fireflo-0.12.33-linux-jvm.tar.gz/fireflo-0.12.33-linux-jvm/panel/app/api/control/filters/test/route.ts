import { NextRequest, NextResponse } from "next/server";
import { callOps } from "@/lib/gateway-ops";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

const FIELDS = ["to", "from", "product", "account", "type"];

/**
 * GET /api/control/filters/test
 *
 * <p>The message tester's Filters tab: every named filter against one message. Proxies the gateway's `/ops/filters/test` on the read token: it evaluates a message
 * nobody sends against the live configuration, and changes nothing.
 */
export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const params = new URLSearchParams();
  for (const field of FIELDS) {
    const value = request.nextUrl.searchParams.get(field);
    if (value) {
      params.set(field, value.slice(0, 2000));
    }
  }
  return callOps({ path: `/ops/filters/test?${params.toString()}`, timeoutMs: 5_000 });
}
