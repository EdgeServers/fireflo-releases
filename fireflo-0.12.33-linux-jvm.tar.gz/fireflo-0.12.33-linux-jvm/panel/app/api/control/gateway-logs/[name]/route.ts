import { NextRequest, NextResponse } from "next/server";
import { callOps } from "@/lib/gateway-ops";
import { isLogName, LOG_NAMES } from "@/lib/gateway-files-types";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

type Params = { params: Promise<{ name: string }> };

/**
 * GET /api/control/gateway-logs/[name]?lines=&contains=
 *
 * <p>The tail of one of the gateway's logs.
 *
 * <p><strong>The name is checked against the allow-list before it is put in a URL.</strong> The
 * gateway resolves names through its own catalogue and never touches a caller-supplied path, so this
 * is the second of two refusals rather than the only one — but a route that interpolates browser
 * input into an upstream URL should be the one place that cannot be talked into it.
 *
 * <p>The two query parameters are rebuilt into a fresh `URLSearchParams` rather than forwarded
 * wholesale, so nothing else the browser sends reaches the gateway.
 */
export async function GET(request: NextRequest, { params }: Params): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const { name } = await params;
  if (!isLogName(name)) {
    return NextResponse.json(
      { error: `No such log. Readable logs are: ${LOG_NAMES.join(", ")}` },
      { status: 404 }
    );
  }

  const query = new URLSearchParams();
  const lines = request.nextUrl.searchParams.get("lines");
  if (lines && /^\d+$/.test(lines)) {
    //the gateway's own clamp is the authority on how many; this only keeps the parameter numeric
    query.set("lines", lines);
  }
  const contains = request.nextUrl.searchParams.get("contains");
  if (contains && contains.trim()) {
    query.set("contains", contains.trim());
  }
  const suffix = query.toString();

  //one seek and a megabyte, however large the log. Ten seconds is generous and covers a cold cache
  return callOps({
    path: `/ops/logs/${name}${suffix ? `?${suffix}` : ""}`,
    auth: "admin",
    timeoutMs: 10_000,
  });
}
