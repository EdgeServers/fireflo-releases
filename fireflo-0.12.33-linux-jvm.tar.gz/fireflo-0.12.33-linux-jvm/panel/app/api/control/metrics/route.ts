import { NextResponse } from "next/server";
import { callOpsText } from "@/lib/gateway-ops";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { toSnapshot } from "@/lib/runtime-metrics";

/**
 * GET /api/control/metrics
 *
 * <p>The gateway's `/q/metrics`, parsed and grouped. Parsing happens here rather than in the browser
 * for two reasons: it keeps 20 KB of exposition text off the wire on every poll, and it puts the one
 * piece of real logic in a single place instead of in a component.
 *
 * <p>Uses `callOpsText`, not `callOps`. The latter calls `res.json()` and would turn this
 * `text/plain` body into an HTTP 200 carrying `data: null` — an empty dashboard with no error
 * anywhere to explain it.
 *
 * <p>Note the gateway does not require a token for `/q/metrics` even though the rest of that port
 * does; the read token is sent regardless, so tightening it later needs no change here.
 */
export async function GET(): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  //reading its own counters; five seconds is already generous
  const result = await callOpsText({ path: "/q/metrics", timeoutMs: 5_000 });
  if ("failed" in result) {
    return result.failed;
  }

  return NextResponse.json({ data: toSnapshot(result.text, new Date().toISOString()) });
}
