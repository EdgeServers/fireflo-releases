import { NextResponse } from "next/server";
import { callOps } from "@/lib/gateway-ops";
import { NotCustomerError, requireCustomer } from "@/lib/require-customer";
import type { LicenseState } from "@/lib/license-state";

/**
 * One boolean, for a customer: are changes on this platform being applied right now.
 *
 * <h2>Why this is not `/api/control/license` with a customer session</h2>
 *
 * <p>Because a customer must not learn what that route returns. The licence state names the
 * install, the licence id, the tier, the address it was issued against and the licence server's
 * URL — the operator's commercial relationship with us, none of which is a customer's business and
 * some of which identifies the platform by name on a portal that has been deliberately
 * white-labelled. This route reduces all of it to the single fact a customer could act on, and the
 * reduction happens on the server so the rest never crosses the network.
 *
 * <p><strong>The word "licence" does not appear in the response, and must not.</strong> Same
 * reason: on a branded portal the customer believes their provider runs this. Telling them
 * otherwise is the one thing `portalBrand` exists to prevent.
 *
 * <h2>Fails open</h2>
 *
 * <p>A gateway that cannot be reached answers `false` — not restricted. The alternative is a
 * customer-facing warning that appears because of a network fault at the operator's end, on a
 * portal where nobody can explain it to them. An alarm nobody can act on is worse than none.
 */
export async function GET(): Promise<NextResponse> {
  try {
    //the session is required but not otherwise used: this is a platform-wide fact, identical for
    //every customer. The check is here so the endpoint is not an unauthenticated probe for whether
    //an operator's licence has lapsed
    await requireCustomer();

    //callOps answers a NextResponse rather than data, so the reduction happens by reading its body
    //back here. Deliberate: it keeps every ops call going through the one place that resolves the
    //base URL and the token, and this route is not hot -- once per portal page load
    const res = await callOps({ path: "/ops/license" });
    if (!res.ok) {
      return NextResponse.json({ data: { restricted: false } });
    }
    const json = (await res.json()) as { data?: LicenseState };
    return NextResponse.json({
      data: { restricted: json.data?.configuration_adopted === false },
    });
  } catch (err) {
    if (err instanceof NotCustomerError) {
      //404 rather than 403, the rule this panel follows everywhere: a refusal that distinguishes
      //"you may not" from "there is nothing here" tells an unauthenticated caller something
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    return NextResponse.json({ data: { restricted: false } });
  }
}
