/**
 * Closing a billing period, and what a closed one means afterwards.
 *
 * <p>Database-free: the reference format and the restatement rule, so the query layer, the routes
 * and the UI all say the same thing about a period nobody may change.
 *
 * <h2>A closed period is immutable</h2>
 *
 * <p>Closing writes one `BILL` row recording what was invoiced. It is <strong>never rewritten</strong>.
 * A refund that lands afterwards, a late receipt, a rate corrected in arrears — none of them restate
 * a closed period. The panel re-runs the summary, compares it against the stored figure, and shows
 * the difference as a <em>credit note against the next period</em>.
 *
 * <p>That is the whole reason this exists rather than the statement simply being a live query.
 * Silently restating a closed period destroys the customer's ability to reconcile: the invoice they
 * paid last month stops matching the invoice the panel shows this month, with nothing anywhere
 * recording that it moved or why.
 *
 * <h2>Why the BILL row moves no money</h2>
 *
 * <p>`delta` records the amount invoiced, negative because it is what the account consumed — but the
 * row is <strong>inert</strong>. The gateway's recharge poll selects only `RECHARGE` and `TRANSFER`,
 * so nothing ever applies a `BILL`. Arrears never enter `account_balance.balance`, which keeps its
 * non-negative constraint and its one meaning.
 *
 * <p>What the row IS load-bearing for is the window: `PostpaidAllowance` reads
 * `max(created_at) WHERE entry_type = 'BILL'` as the start of the unbilled period, so closing is
 * what returns a postpaid account's headroom.
 */

/**
 * The idempotency key for one account's period.
 *
 * <p>`uq_balance_ledger_ref` is unique where not null, so this is what makes closing the same period
 * twice a conflict rather than a second invoice. Deterministic on purpose — two operators clicking
 * at once must collide, and a retried request must not produce a duplicate.
 */
export function billReference(accountId: string, label: string): string {
  return `bill:${accountId}:${label}`;
}

/** Parses a reference back, for showing which period a ledger row closed. */
export function parseBillReference(ref: string | null): { accountId: string; label: string } | null {
  if (!ref || !ref.startsWith("bill:")) {
    return null;
  }
  //the label may not contain a colon (it is YYYY-MM or a date span), so the LAST colon splits them
  //and an account id containing colons still round-trips
  const cut = ref.lastIndexOf(":");
  if (cut <= "bill:".length) {
    return null;
  }
  return { accountId: ref.slice("bill:".length, cut), label: ref.slice(cut + 1) };
}

export interface ClosedPeriod {
  label: string;
  /** Scaled by 10,000, positive: what was invoiced. Stored negative, shown as an amount owed. */
  invoiced: number;
  closedAt: string;
  note: string | null;
}

/**
 * What a closed period looks like now versus what it was invoiced at.
 *
 * <p>`difference` is positive when the recomputed figure is HIGHER than the invoice — the customer
 * was under-charged and owes more — and negative when they were over-charged and are owed a credit.
 */
export interface Restatement {
  label: string;
  invoiced: number;
  recomputed: number;
  difference: number;
}

/** Below this, a difference is not worth a credit note. One ten-thousandth is rounding, not money. */
const MATERIAL = 1;

/**
 * <strong>Only call this with a figure that could actually be recomputed.</strong>
 *
 * <p>`recomputed` is trusted completely: a zero here means "this period now computes to nothing",
 * and against a closed invoice that reads as a full credit note. It does not, and cannot, know the
 * difference between a period where everything was refunded and a period whose evidence has been
 * deleted.
 *
 * <p>That distinction is what `fireflo usage purge` destroys. `statementSummary` read `cdr_submit`
 * alone, so every period older than the retention window recomputed to zero, and this function
 * dutifully reported the whole paid invoice as owed back. It now reads `usage_daily` for purged days
 * and carries `recomputable`; the caller checks that flag before calling this at all.
 */
export function restatementOf(closed: ClosedPeriod, recomputed: number): Restatement | null {
  const difference = recomputed - closed.invoiced;
  if (Math.abs(difference) < MATERIAL) {
    return null;
  }
  return { label: closed.label, invoiced: closed.invoiced, recomputed, difference };
}

/**
 * How a credit note reads, in the one place both surfaces take it from.
 *
 * <p>Deliberately says the closed invoice STANDS. An operator reading "this period is now 12.5000"
 * would reasonably reissue it; the whole point is that they must not.
 */
export function creditNoteMessage(r: Restatement, money: (scaled: number) => string): string {
  const owed = r.difference > 0;
  return (
    `${r.label} was invoiced at ${money(r.invoiced)} and now computes to ${money(r.recomputed)}. `
    + `That invoice stands — closed periods are never restated. `
    + (owed
      ? `${money(r.difference)} was under-charged and carries forward to the next period.`
      : `${money(-r.difference)} is owed back and carries forward as a credit on the next period.`)
  );
}
