import { test } from "node:test";
import assert from "node:assert/strict";
import { mtProducts, mtSeries, summariseMtUsage, type MtUsageLine } from "./mt-usage.ts";
import { mtUsageSql } from "./mt-usage-sql.ts";

const line = (day: string, product: string, messages: number, mtParts: number | null, price = 0): MtUsageLine =>
  ({ day, product, messages, mtParts, price });

const LINES = [
  line("2026-08-30", "sms", 10, 30, 1_000),
  line("2026-09-30", "sms", 5, 5, 500),
  line("2026-10-01", "sms", 4, 8, 400),
  line("2026-10-01", "otp", 2, 2, 200),
  line("2026-10-13", "sms", 3, 6, 300),
];

test("lifetime, month and today are cut from today in the billing zone", () => {
  const u = summariseMtUsage(LINES, "2026-10-13");
  assert.deepEqual(u.lifetime, { messages: 24, mtParts: 51, price: 2_400 });
  assert.deepEqual(u.month, { messages: 9, mtParts: 16, price: 900 });
  assert.deepEqual(u.todaySoFar, { messages: 3, mtParts: 6, price: 300 });
  assert.deepEqual(u.week, { messages: 3, mtParts: 6, price: 300 });
  assert.equal(u.uncountedDays, 0);
});

test("a day rolled up before parts were counted is not counted, rather than counted as none", () => {
  const u = summariseMtUsage([...LINES, line("2026-07-01", "sms", 100, null)], "2026-10-13");
  assert.equal(u.uncountedDays, 1);
  assert.equal(u.lifetime.mtParts, 51, "nothing invented for the uncounted day");
});

test("the series has every day of the window, quiet ones as zero and uncounted ones as a gap", () => {
  const s = mtSeries([...LINES, line("2026-10-12", "sms", 1, null)], "2026-10-13", 7);
  assert.equal(s.length, 7);
  assert.equal(s[0].day, "2026-10-07");
  assert.deepEqual(s.at(-1), { day: "2026-10-13", mtParts: 6, messages: 3 });
  assert.equal(s.at(-2)?.mtParts, null);
  assert.equal(s[0].mtParts, 0);
});

test("products sum over the window only, most parts first", () => {
  const p = mtProducts(LINES, "2026-10-13", 30);
  assert.deepEqual(p.map((r) => [r.product, r.messages, r.mtParts]), [["sms", 12, 19], ["otp", 2, 2]]);
});

test("the tail counts parts as the rollup does, and a gateway without the column reads NULL", () => {
  const sql = mtUsageSql({ vendorAttempt: true, mtParts: true, submitStatus: true });
  assert.match(sql, /SUM\(s\.part_count\) FILTER \(WHERE COALESCE\(s\.submit_status, 0\) = 0\)/);
  assert.match(sql, /u\.mt_parts::text AS mt_parts/);
  //the seam: a rolled-up day must not also be read from cdr_submit
  assert.match(sql, /NOT EXISTS \(\s+SELECT 1 FROM usage_daily u/);
  assert.match(sql, /u\.product = COALESCE\(s\.product, ''\)/);

  const old = mtUsageSql({ vendorAttempt: false, mtParts: false, submitStatus: false });
  assert.match(old, /NULL::text AS mt_parts/);
  assert.doesNotMatch(old, /submit_status|vendor_attempt|u\.mt_parts/);
});

test("CP-P2 the tail is bounded to the seam and carries only what it reads", () => {
  const sql = mtUsageSql({ vendorAttempt: true, mtParts: true, submitStatus: true });
  //the bound comes BEFORE the anti-join: idx_cdr_submit_account_time_covering walks a few days
  //rather than the account's lifetime with a function of submitted_at in the predicate
  assert.match(sql, /s\.account_id = \$1\s+AND s\.submitted_at >= \(SELECT COALESCE\(\(\(max\(u\.day\) - 1\)::timestamp AT TIME ZONE \$2\), '-infinity'::timestamptz\)\s+FROM usage_daily u\s+WHERE u\.account_id = \$1\)\s+AND NOT EXISTS/);
  assert.doesNotMatch(sql, /s\.\*/, "no body or TLVs through the per-message sort");
  assert.match(sql, /DISTINCT ON \(s\.gateway_msg_id\) s\.account_id, s\.product, s\.submitted_at, s\.part_count, s\.price, s\.submit_status/);
  //and the column is not named against a gateway that lacks it
  const old = mtUsageSql({ vendorAttempt: false, mtParts: false, submitStatus: false });
  assert.match(old, /s\.part_count, s\.price\s+FROM cdr_submit/);
});
