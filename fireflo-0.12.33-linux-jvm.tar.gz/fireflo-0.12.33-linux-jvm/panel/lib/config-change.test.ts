import { test } from "node:test";
import assert from "node:assert/strict";
import { MAX_SUMMARY_CHARS, changedKeys, configChangeDetail, redactSummary } from "./config-change.ts";

/**
 * What a `config_changed` line may and may not carry.
 *
 * <p>The one that matters is the first: the access log is kept forever and shown on a screen, so a
 * vendor password that reaches it once is there for good. The redaction has to hold for keys the
 * caller never thought about -- a worker setting named `smpp.password`, an `api_key` column copied
 * straight from a row -- not only for the two the credential editor knows.
 */

test("a secret-looking key is reported as presence, never as its value", () => {
  const out = redactSummary({
    password: "hunter2",
    api_key: "",
    apiKey: null,
    "smpp.password": "x",
    "http.auth.token": "t",
    secret_box: { state: "kept" },
    unset_secret: { state: "unset" },
    label: "fine",
  });
  assert.deepEqual(out, {
    has_password: true,
    has_api_key: false,
    has_apiKey: false,
    "has_smpp.password": true,
    "has_http.auth.token": true,
    has_secret_box: true,
    has_unset_secret: false,
    label: "fine",
  });
  assert.doesNotMatch(JSON.stringify(out), /hunter2/);
});

test("redaction reaches nested objects and leaves has_ keys alone", () => {
  const out = redactSummary({
    properties: { password: "p", host: "smsc.example" },
    has_password: true,
  });
  assert.deepEqual(out, { properties: { has_password: true, host: "smsc.example" }, has_password: true });
});

test("long strings and long lists are clipped", () => {
  const out = redactSummary({ note: "x".repeat(500), ips: Array.from({ length: 60 }, (_, i) => `10.0.0.${i}`) });
  assert.ok((out.note as string).length < 200);
  assert.ok((out.note as string).endsWith("…"));
  const ips = out.ips as string[];
  assert.equal(ips.length, 41);
  assert.equal(ips[40], "…(+20 more)");
});

test("the detail leads with domain, name and action and lists what changed", () => {
  const detail = configChangeDetail({
    domain: "credential",
    name: "SMPP acme",
    action: "update",
    account: "acme",
    before: { enabled: true, maxTps: 10, has_password: true },
    after: { enabled: true, maxTps: 50, has_password: true },
  });
  assert.deepEqual(Object.keys(detail).slice(0, 4), ["domain", "name", "action", "account"]);
  assert.deepEqual(detail.changed, ["maxTps"]);
  assert.deepEqual(detail.after, { enabled: true, maxTps: 50, has_password: true });
});

test("a secret that was replaced shows as changed without either value", () => {
  const detail = configChangeDetail({
    domain: "worker",
    name: "telstra",
    action: "update",
    before: { properties: { password: "old" } },
    after: { properties: { password: "new" } },
  });
  //both present, so presence alone cannot tell them apart; the caller says so with its own flag.
  //What this asserts is that neither value leaks, whatever else happens
  assert.doesNotMatch(JSON.stringify(detail), /old|new/);
});

test("a pair of summaries past the cap is reduced to its keys, and the line still says what moved", () => {
  const big = Object.fromEntries(Array.from({ length: 30 }, (_, i) => [`rule${i}`, "t".repeat(100)]));
  const detail = configChangeDetail({
    domain: "routing_table",
    name: "default",
    action: "update",
    before: big,
    after: { ...big, rule3: "changed" },
  });
  assert.ok(JSON.stringify(detail).length < MAX_SUMMARY_CHARS + 400);
  assert.deepEqual(detail.changed, ["rule3"]);
  assert.equal((detail.before as { truncated: boolean }).truncated, true);
  assert.ok(Array.isArray((detail.after as { keys: string[] }).keys));
});

test("no before means no changed list, and absent summaries are left out", () => {
  const detail = configChangeDetail({ domain: "reload", name: "gateway", action: "action:reload" });
  assert.deepEqual(detail, { domain: "reload", name: "gateway", action: "action:reload" });
});

test("changedKeys compares by value and sees keys only one side has", () => {
  assert.deepEqual(changedKeys({ a: [1, 2], b: 1, gone: true }, { a: [1, 2], b: 2, added: 1 }), ["b", "added", "gone"]);
});
