/**
 * Which mandatory TLVs an approved row will fail to put on the wire, and why.
 *
 * <p>Database-free, so both the account page and the index pages call the same function rather than
 * each deciding for itself — the discipline `whitelist-types.ts` was written to enforce after three
 * places disagreed about what "approved" counted as.
 *
 * <p><strong>This is a report, never a guard.</strong> A login is not bound to a listener and the
 * route rules decide the vendor, so nothing here can be certain a given message meets a given
 * listener or vendor. Refusing a save on this would block configurations that work. Every sentence
 * it produces therefore names the listener or the vendor rather than generalising, and says that a
 * client sending the tag itself makes the whole question moot.
 *
 * <p>The gateway's submit path, which this models, in order:
 *
 * <ol>
 *   <li>`TlvUtil.extractTlvs` — what the caller sent. Invisible from here.
 *   <li>`applyCredentialDefaultTlvs` — `app_credential.default_tlvs`, assign-if-absent
 *   <li>`applyWhitelist` — the matched row's `tlvs`, in the listener's {@link StampMode}
 *   <li>`validateMandatoryTlvs` — refuses with `Mandatory tlv <token> is not set.`
 *   <li>`SmppClientWorker` — `effective.keySet().retainAll(registered)`, so the chosen vendor drops
 *       any tag it did not register, *after* the call record has already noted it as present
 * </ol>
 */

//one runtime import, and a leaf: this module is reached by `node --experimental-strip-types`,
//which will not resolve a deeper graph without extensions on every hop
import { parseTlvCsv, tlvTag } from "./tlv-string.ts";
import type { WhitelistKind, WhitelistMode } from "./whitelist-types";

/** Mirrors the gateway's `TlvStampMode`. Unset or unparseable is `off`, as it is there. */
export type StampMode = "off" | "assign" | "replace";

/** One ingress that refuses a message missing a tag, and what a matched row can do about it there. */
export interface MandatorySource {
  /** Listener name. The empty string is the REST ingress, which has no listener. */
  listener: string;
  /** Declared tags, first-wins by tag, as `TlvUtil.parseDeclarations` reads them. */
  tags: readonly { tag: number; token: string }[];
  /** `conf.whitelist.enabled`. Absent means true. Always true for REST. */
  checksWhitelist: boolean;
  /** `whitelist.tlvs.mode`. Absent means `off` on a listener, `replace` on REST. */
  stamps: StampMode;
}

/** What one login puts on every message it carries. Secret-free by construction. */
export interface LoginDefaults {
  accountId: string;
  /** The empty string when the login names no product. */
  product: string;
  /** For naming it in a sentence. Null for an HTTP login keyed on its API key. */
  systemId: string | null;
  /** Tags whose default value is non-empty. An empty default supplies nothing. */
  tags: readonly number[];
}

/** A vendor, and the tags it will let through. */
export interface VendorTlvs {
  name: string;
  /** `registered.tlvs.submit`. A tag missing here is dropped on the way out. */
  registered: readonly number[];
  /** Whether any enabled route rule names it. An unreachable vendor is not a gap. */
  reachable: boolean;
}

/**
 * A vendor as the route table describes it, before a row's product narrows the field.
 *
 * <p>`products` is null when an enabled rule names this vendor without keying on a product, which
 * means it can carry anything. Where every rule naming it does key on a product, those products are
 * listed and traffic on any other never reaches it.
 */
export interface VendorReach {
  name: string;
  registered: readonly number[];
  products: readonly string[] | null;
}

/**
 * Which vendors this row's traffic can actually reach.
 *
 * <p>Route conditions can key on destination, MCC/MNC or a named filter, none of which is decidable
 * from configuration — so this narrows only on `product`, and treats anything else as reachable.
 * That over-reports rather than under-reports, which is the right direction for a warning: a vendor
 * named in a gap that never carries this traffic costs a second of the operator's attention, where a
 * silently dropped registration identifier costs a carrier relationship.
 */
export function vendorsForProduct(
  vendors: readonly VendorReach[],
  product: string
): VendorTlvs[] {
  return vendors.map((v) => ({
    name: v.name,
    registered: v.registered,
    //a row filed under no product serves every product, so every reachable vendor is in play
    reachable: v.products === null || !product || v.products.includes(product),
  }));
}

export type GapReason =
  /** Neither the row nor any login carries the tag. */
  | "nothingSupplies"
  /** Some logins on this scope carry it and others do not, so it fails intermittently. */
  | "someLogins"
  /** The row carries it, but the listener's stamping mode is off. */
  | "notStamped"
  /** The row carries it, but this list is not checked, so nothing is matched or stamped. */
  | "notChecked"
  /** The row names a token that carries no tag, so it stamps nothing. */
  | "unparseable"
  /** The row names the tag with no value, and an empty value stamps nothing. */
  | "emptyValue"
  /** Something supplies it, and the vendor it would be routed to does not carry it. */
  | "vendorDrops";

export interface TlvGap {
  tag: number;
  /** The declaration token, which is the word the gateway's refusal uses verbatim. */
  token: string;
  /** Listeners that refuse without it. The empty string renders as "the HTTP API". */
  requiredBy: readonly string[];
  reason: GapReason;
  /** For `unparseable`, the token the operator actually typed. */
  wrote?: string;
  /** For `someLogins`. */
  coveredLogins?: readonly string[];
  uncoveredLogins?: readonly string[];
  /** For `vendorDrops`. */
  vendors?: readonly string[];
  /**
   * Only a template supplies it, and on SMPP a concatenated message is not matched against a
   * template at submit time — the body is still a fragment there. It is matched, and stamped, once
   * the segments are reassembled, so a multipart message is not refused for being multipart. What
   * differs is when: every segment was already acknowledged, so a refusal arrives as a drop, a
   * refund and a `cdr_rejected` row rather than as an error on the `submit_sm_resp`.
   *
   * <p>**Never set.** Reaching the branch that would set it needs `offer.has` true with
   * `rowCanStamp` true, and that combination is `rowSupplies`, which returns earlier. The field is
   * left declared, and the sentence `describeGap` builds from it left in place, because the timing
   * it describes is real and the flag is the intended way to say it — but nothing renders today.
   */
  multipartOnly?: boolean;
}

export interface CoverageInput {
  tlvs: string | null;
  accountId: string;
  /** The empty string means every product, matching the column. */
  product: string;
  kind: WhitelistKind;
  /** From `effectiveMode`. Passed in, never re-derived — one merge rule, not two. */
  mode: WhitelistMode;
  mandatory: readonly MandatorySource[];
  logins: readonly LoginDefaults[];
  vendors?: readonly VendorTlvs[];
  /**
   * The approved rows of the OTHER kind that serve this same scope, and their mode.
   *
   * <p>A message is stamped by both matches, not one: `applyWhitelist` runs the header and the
   * content check in turn and each stamps what it matched. Without this a sender ID would be blamed
   * for not carrying the Template ID — which is never a sender ID's job, and would put a false
   * warning on every header row in a DLT deployment.
   */
  siblings?: { mode: WhitelistMode; tlvs: readonly (string | null)[] };
}

/**
 * Which logins can carry this row's traffic.
 *
 * <p>The scoping `WhitelistSnapshot.whitelistFor` uses: a row filed under no product faces every
 * login on the account, a row on product P faces only logins on exactly P.
 */
function relevantLogins(input: CoverageInput): LoginDefaults[] {
  return input.logins.filter((l) =>
    l.accountId === input.accountId && (!input.product || l.product === input.product));
}

function nameOf(login: LoginDefaults): string {
  return login.systemId ?? "an API-key login";
}

/**
 * What the row itself does with one tag, ignoring where it will end up.
 *
 * <p>Returns null when the row has nothing to say about this tag at all, which is the ordinary case
 * and not a problem in itself — a login may still supply it.
 */
function rowOffers(tlvs: string | null, tag: number):
    { has: false } | { has: true; problem?: "emptyValue" } {
  for (const pair of parseTlvCsv(tlvs)) {
    if (tlvTag(pair.key) !== tag) {
      continue;
    }
    return pair.value.trim() ? { has: true } : { has: true, problem: "emptyValue" };
  }
  return { has: false };
}

/**
 * A token on this row that resolves to no tag, if there is one.
 *
 * <p>Reported per row rather than per required tag: `PEID=…` fails for every tag at once, and saying
 * so once is the useful shape. `TlvUtil.parseDefaults` logs and drops such an entry, so the row
 * looks filled in and stamps nothing.
 */
function taglessToken(tlvs: string | null): string | null {
  for (const pair of parseTlvCsv(tlvs)) {
    if (pair.key.trim() && tlvTag(pair.key) === null) {
      return pair.key.trim();
    }
  }
  return null;
}

/**
 * Every mandatory tag this row will fail to deliver, one entry per tag.
 *
 * <p>Evaluated per listener and then merged, rather than over a union of the tags: two listeners can
 * require the same tag and disagree about whether a row may stamp it, and a union would silently
 * take one listener's answer for both.
 */
export function rowTlvGaps(input: CoverageInput): TlvGap[] {
  if (!input.mandatory.length) {
    return [];
  }
  const logins = relevantLogins(input);
  const tagless = taglessToken(input.tlvs);
  const byTag = new Map<number, TlvGap>();

  const record = (gap: TlvGap) => {
    const existing = byTag.get(gap.tag);
    if (!existing) {
      byTag.set(gap.tag, gap);
      return;
    }
    //one sentence per tag: an operator reads "airtel and vodafone refuse this", not the same
    //sentence twice. The first reason found wins, and the listeners accumulate
    existing.requiredBy = [...new Set([...existing.requiredBy, ...gap.requiredBy])];
  };

  for (const source of input.mandatory) {
    for (const { tag, token } of source.tags) {
      const supplyingLogins = logins.filter((l) => l.tags.includes(tag));
      const missingLogins = logins.filter((l) => !l.tags.includes(tag));

      //every relevant login supplies it, so the row never has to
      const coveredByLogins = logins.length > 0 && missingLogins.length === 0;

      //every sibling that could match, because which template matches depends on the message body:
      //if only some carry the tag, a message matching one of the others still arrives without it
      const siblingSupplies = Boolean(input.siblings?.tlvs.length)
        && input.siblings!.mode !== "OFF"
        && input.siblings!.tlvs.every((t) => {
          const o = rowOffers(t, tag);
          return o.has && !o.problem;
        });

      const offer = rowOffers(input.tlvs, tag);
      //the row can only supply it if it is matched at all and the listener writes what it matches
      const rowCanStamp = source.checksWhitelist && source.stamps !== "off" && input.mode !== "OFF";
      const rowSupplies = offer.has && !offer.problem && rowCanStamp;

      if (coveredByLogins || rowSupplies || (siblingSupplies && rowCanStamp)) {
        //supplied — but does the vendor carry it out?
        const dropping = (input.vendors ?? [])
          .filter((v) => v.reachable && !v.registered.includes(tag))
          .map((v) => v.name);
        if (dropping.length) {
          record({ tag, token, requiredBy: [source.listener], reason: "vendorDrops",
            vendors: dropping });
        }
        continue;
      }

      if (offer.has && offer.problem === "emptyValue") {
        record({ tag, token, requiredBy: [source.listener], reason: "emptyValue" });
      } else if (offer.has && !rowCanStamp) {
        record({ tag, token, requiredBy: [source.listener],
          reason: input.mode === "OFF" ? "notChecked" : "notStamped" });
      } else if (tagless) {
        record({ tag, token, requiredBy: [source.listener], reason: "unparseable", wrote: tagless });
      } else if (supplyingLogins.length > 0) {
        record({ tag, token, requiredBy: [source.listener], reason: "someLogins",
          coveredLogins: supplyingLogins.map(nameOf),
          uncoveredLogins: missingLogins.map(nameOf) });
      } else {
        record({ tag, token, requiredBy: [source.listener], reason: "nothingSupplies",
          multipartOnly: input.kind === "content" && offer.has });
      }
    }
  }
  return [...byTag.values()];
}

/** "airtel", or "the HTTP API" for the ingress with no listener. */
function ingressName(listener: string): string {
  return listener ? `\`${listener}\`` : "the HTTP API";
}

function listOf(names: readonly string[]): string {
  if (names.length === 1) {
    return names[0];
  }
  return `${names.slice(0, -1).join(", ")} and ${names[names.length - 1]}`;
}

/**
 * The sentence an operator reads, written once so the two surfaces cannot word it differently.
 *
 * <p>Each one names what refuses, what is missing, and what to do — and, for everything except a
 * plain typo, that a client sending the tag itself makes the refusal not happen. Dropping that
 * clause would have the panel claim refusals that never occur, and a warning that is wrong often
 * enough is one people stop reading.
 */
export function tlvGapSentence(gap: TlvGap, kind: WhitelistKind): string {
  const thing = kind === "header" ? "This sender ID" : "This template";
  const refusers = listOf(gap.requiredBy.map(ingressName));
  const refuses = `${refusers} refuses a message without \`${gap.token}\``;
  const unlessSent = "unless the customer sends the tag themselves";

  switch (gap.reason) {
    case "unparseable":
      return `\`${gap.wrote}\` carries no tag, so this stamps nothing — the tag is whatever follows `
        + `the last underscore, and there is no underscore here. ${refuses}; write it `
        + `\`${gap.token}=…\` instead.`;

    case "emptyValue":
      return `\`${gap.token}\` is named here with no value, and an empty value stamps nothing. `
        + `${refuses}.`;

    case "notStamped":
      //`replace`, not `assign`. This used to advise assign, which fills a tag only when the customer
      //sent none -- so a customer asserting somebody else's Entity ID keeps it, which is the exact
      //hole approving a sender ID exists to close. Assign is a real choice, but it is not the one to
      //recommend to an operator who has just been told their approved values are not being applied
      return `${thing} carries \`${gap.token}\`, but ${refusers} has \`whitelist.tlvs.mode\` set to `
        + `\`off\`, so a match stamps nothing — and ${refuses.toLowerCase()}. Set it to \`replace\` `
        + `so the approved value always wins, or \`assign\` to fill the tag only when the customer `
        + `sent none.`;

    case "notChecked":
      return `${thing} carries \`${gap.token}\`, but this list is not checked on this account, so `
        + `nothing is matched and nothing is stamped. ${refuses}.`;

    case "someLogins":
      return `${refuses}. ${listOf(gap.coveredLogins ?? [])} supplies it; `
        + `${listOf(gap.uncoveredLogins ?? [])} does not, so messages on that login are refused `
        + `while the other's go through — which reads as intermittent from the customer's side.`;

    case "vendorDrops":
      return `\`${gap.token}\` is supplied, but ${listOf((gap.vendors ?? []).map((v) => `\`${v}\``))} `
        + `does not register it, so anything routed there arrives without it even though the call `
        + `record will show it as sent. Add it to that vendor's TLVs to send.`;

    case "nothingSupplies":
    default: {
      //see TlvGap.multipartOnly: this never fires today, and the branch is kept because the timing
      //it states is true and is the thing an operator would need told if it ever did
      const multipart = gap.multipartOnly
        ? " And on SMPP a concatenated message is matched against a template only once its segments"
          + " are reassembled, so the tag is stamped after every segment has been acknowledged —"
          + " a refusal there is a drop and a refund, not an error the customer's client saw."
        : "";
      return `${refuses}. ${thing} does not supply it and no login on this scope does either, so `
        + `every message comes back \`Mandatory tlv ${gap.token} is not set.\` — ${unlessSent}.`
        + multipart;
    }
  }
}

/** A place to go and put a gap right, for a link beside its sentence. */
export interface GapFix {
  label: string;
  href: string;
}

/**
 * Where to fix a gap, when the fix is one setting on a page the panel has.
 *
 * <p>Only `notStamped` qualifies: the row is right and the listener ignores it, and the switch is
 * `whitelist.tlvs.mode` in the collapsed TLVs section of that listener's edit form, which nobody
 * finds from the sentence alone. One link per listener named. The HTTP API is left out: it has no
 * listener page, and it stamps in `replace` unless someone changed the gateway's own setting.
 */
export function tlvGapFixes(gap: TlvGap): GapFix[] {
  if (gap.reason !== "notStamped") {
    return [];
  }
  return gap.requiredBy
    .filter((listener) => listener)
    .map((listener) => ({
      label: `Fix on ${listener}`,
      href: `/cp/servers/${encodeURIComponent(listener)}?edit=1&open=tlvs`,
    }));
}

/** The condensed form for a table cell, where a paragraph will not fit. */
export function tlvGapSummary(gap: TlvGap): string {
  const refusers = listOf(gap.requiredBy.map(ingressName));
  switch (gap.reason) {
    case "vendorDrops":
      return `${listOf((gap.vendors ?? []).map((v) => `\`${v}\``))} drops \`${gap.token}\``;
    case "notStamped":
      return `${refusers} refuses this: \`${gap.token}\` is here but not stamped`;
    case "notChecked":
      return `\`${gap.token}\` is here but this list is not checked`;
    case "unparseable":
      return `\`${gap.wrote}\` carries no tag, so \`${gap.token}\` is unset`;
    case "emptyValue":
      return `\`${gap.token}\` has no value`;
    case "someLogins":
      return `${refusers} refuses this on ${listOf(gap.uncoveredLogins ?? [])}`;
    default:
      return `${refusers} refuses this: nothing supplies \`${gap.token}\``;
  }
}
