import { test } from "node:test";
import assert from "node:assert/strict";
import {
  decodeReceiptRequest,
  receiptForwards,
  receiptRequestForLevel,
  receiptRequestHex,
  receiptRequestSummary,
} from "./receipt-request.ts";

/**
 * This module is a copy of the gateway's `ReceiptRequest`, and a copy is only useful while it agrees
 * with the original. Every case below names the bit or the constant it pins, so a divergence shows
 * up as a failing test rather than as a detail page describing the wrong request.
 */

test("the receipt bits are the low two, and nothing else", () => {
  //SmppConstants.REGISTERED_DELIVERY_SMSC_RECEIPT_MASK is 0x03
  assert.equal(decodeReceiptRequest(0x00).kind, "NONE");
  assert.equal(decodeReceiptRequest(0x01).kind, "ALL");
  assert.equal(decodeReceiptRequest(0x02).kind, "FAILURE_ONLY");
  assert.equal(decodeReceiptRequest(0x03).kind, "SUCCESS_ONLY");
});

test("the intermediate notification is bit 4 of registered_delivery, not bit 5 of esm_class", () => {
  //the confusion this exists to prevent: 0x10 here, 0x20 there, different octet, same word in both
  //names. Reading 0x20 as "interim wanted" would describe a request the customer never made
  assert.equal(decodeReceiptRequest(0x10).interim, true);
  assert.equal(decodeReceiptRequest(0x20).interim, false);
  assert.equal(decodeReceiptRequest(0x11).interim, true);
  assert.equal(decodeReceiptRequest(0x11).kind, "ALL");
});

test("the SME acknowledgement bits are read and marked as not ours to honour", () => {
  //bits 3-2, mask 0x0c. The gateway parses and ignores them: it is a request to the handset, made
  //through the network, and FireFlo is not the SME. Showing it is what stops "I set it and nothing
  //happened" from being a mystery
  const ack = decodeReceiptRequest(0x04);

  assert.equal(ack.smeAck, true);
  assert.equal(ack.kind, "NONE", "0x04 asks for an acknowledgement and no receipt");
  assert.match(receiptRequestSummary(0x04), /not ours to honour/);
});

test("0x04 is the byte where the legacy boolean and the real request disagree", () => {
  //`acked` was `registered_delivery != 0`, so 0x04 said a receipt was wanted. It was not: the
  //customer asked the handset to acknowledge and asked us for nothing. The gateway keeps `acked` as
  //it was for the routing attribute and decides forwarding on the decoded request instead
  assert.notEqual(0x04, 0, "the legacy rule would call this a receipt request");
  assert.equal(decodeReceiptRequest(0x04).kind, "NONE");
  assert.equal(decodeReceiptRequest(0x04).interim, false);
});

test("every one of the 256 values decodes, and only the documented bits move the answer", () => {
  for (let raw = 0; raw <= 0xff; raw++) {
    const request = decodeReceiptRequest(raw);
    assert.equal(request.raw, raw, `raw survives for ${raw}`);
    //bits 7-5 are reserved. A value that sets them must decode exactly as the same value without
    assert.deepEqual(
      { ...request, raw: 0 },
      { ...decodeReceiptRequest(raw & 0x1f), raw: 0 },
      `reserved bits changed the reading of ${raw}`
    );
  }
});

test("a value beyond one octet is masked rather than trusted", () => {
  //the column is a smallint and Postgres will hand back whatever is in it
  assert.equal(decodeReceiptRequest(0x101).raw, 0x01);
  assert.equal(decodeReceiptRequest(0x101).kind, "ALL");
});

test("null is not zero, and the summary says so", () => {
  //zero is a claim about the customer -- they asked for nothing. Null is a claim about us: the
  //column did not exist when this row was written, so we do not know what they asked for
  assert.equal(receiptRequestSummary(null), "Not recorded");
  assert.equal(receiptRequestSummary(undefined), "Not recorded");
  assert.equal(receiptRequestSummary(0), "No receipt");
  assert.equal(receiptRequestHex(null), "—");
  assert.equal(receiptRequestHex(0), "0x00");
  assert.equal(receiptRequestHex(0x11), "0x11");
});

test("dlr-level maps onto the same request the SMPP octet produces", () => {
  //ReceiptRequest.ofLevel: 1 progress only, 2 the outcome, 3 both, and dlr=no is nothing at all
  assert.deepEqual(receiptRequestForLevel(false, 3), decodeReceiptRequest(0x00));
  assert.deepEqual(receiptRequestForLevel(true, null), decodeReceiptRequest(0x01));
  assert.deepEqual(receiptRequestForLevel(true, 2), decodeReceiptRequest(0x01));
  assert.deepEqual(receiptRequestForLevel(true, 3), decodeReceiptRequest(0x11));
});

test("level 1 alone asks for progress and not the outcome", () => {
  //deliberate, and the case most likely to be read as a bug: a caller who asked for level 1 has
  //said what they want, and adding the terminal receipt would be us overruling them
  const progress = receiptRequestForLevel(true, 1);

  assert.equal(progress.interim, true);
  assert.equal(progress.kind, "NONE");
});

test("the forwarding matrix, all four requests against both kinds of receipt", () => {
  //the table in the plan, asserted rather than described. DELIVRD is 1, FAILED is 8, ACCEPTD is 5
  const rows: [raw: number, onInterim: boolean, onSuccess: boolean, onFailure: boolean][] = [
    [0x00, false, false, false],
    [0x01, false, true, true],
    [0x02, false, false, true],
    [0x03, false, true, false],
    [0x10, true, false, false],
    [0x11, true, true, true],
  ];

  for (const [raw, onInterim, onSuccess, onFailure] of rows) {
    const request = decodeReceiptRequest(raw);
    assert.equal(receiptForwards(request, 5, false), onInterim, `interim for 0x${raw.toString(16)}`);
    assert.equal(receiptForwards(request, 1, true), onSuccess, `success for 0x${raw.toString(16)}`);
    assert.equal(receiptForwards(request, 8, true), onFailure, `failure for 0x${raw.toString(16)}`);
  }
});

test("SEEN counts as a success, because it bills as one", () => {
  //DLR_STAT_SEEN is 15 and rates as delivered. A SUCCESS_ONLY customer must hear about a message
  //they were charged for, and a FAILURE_ONLY one must not be told a delivery was a failure
  const successOnly = decodeReceiptRequest(0x03);
  const failureOnly = decodeReceiptRequest(0x02);

  assert.equal(receiptForwards(successOnly, 15, true), true);
  assert.equal(receiptForwards(failureOnly, 15, true), false);
});

test("an unknown level falls back to the outcome rather than to nothing", () => {
  //the parser refuses anything outside 1..3 with a 400, so this is unreachable from REST. It is
  //reachable from a stored byte, and the fallback direction is the same one the gateway takes
  assert.equal(receiptRequestForLevel(true, 9).kind, "ALL");
});
