import { configQuery } from "./config-db";
import { tlvTag } from "./tlv-string.ts";
import type { MandatorySource, StampMode } from "./tlv-coverage.ts";

/**
 * Which ingresses refuse a message for a missing TLV, and what a matched row may do about it there.
 *
 * <p>Reads the same three settings the gateway reads, per SMPP listener, plus the REST ingress's own
 * key. **The coded defaults are the whole risk in this file** and they point opposite ways
 * (`SmppServerWorker.java:170,177`):
 *
 * <ul>
 *   <li>`conf.whitelist.enabled` absent means <strong>true</strong> — a listener checks unless it
 *       opted out, because a deployment silently ceasing to enforce on upgrade was a real incident.
 *   <li>`whitelist.tlvs.mode` absent means <strong>off</strong> — writing TLVs onto packets crossing
 *       a port is opted into. The older `whitelist.tlvs.replace` boolean still decides when the mode
 *       is unset, exactly as `TlvStampMode.resolve` does it.
 * </ul>
 *
 * <p>Reading either backwards inverts the verdict on every listener that never set them, which is
 * most of them.
 *
 * <p>Tokens are parsed in TypeScript rather than in SQL, for the reason `scanTlvUsage` gives: the
 * tag is decimal unless prefixed `0x`, and a second parser eventually disagrees about `tlv_0100`.
 */

/** The REST ingress's equivalent of a listener's `mandatory.tlvs.submit`. */
const REST_MANDATORY_KEY = "smsg.restapi.mandatory.tlvs.submit";

/** The REST ingress's stamping mode. Unset means `replace` there — see MessageSubmissionService. */
const REST_MODE_KEY = "smsg.restapi.whitelist.tlvs.mode";

interface PropertyRow {
  worker_name: string;
  key: string;
  value: string | null;
}

/** `peid_0x1400, tmplid_0x1401` → the tags, first-wins, as `TlvUtil.parseDeclarations` reads it. */
function declarations(csv: string | null | undefined): { tag: number; token: string }[] {
  if (!csv) {
    return [];
  }
  const seen = new Set<number>();
  const out: { tag: number; token: string }[] = [];
  for (const raw of csv.split(",")) {
    const token = raw.trim();
    if (!token) {
      continue;
    }
    const tag = tlvTag(token);
    //an unparseable token is dropped rather than reported: the gateway logs and skips it, so it
    //requires nothing, and a listener demanding a tag nobody can name is not a thing that happens
    if (tag === null || seen.has(tag)) {
      continue;
    }
    seen.add(tag);
    out.push({ tag, token });
  }
  return out;
}

function stampModeOf(mode: string | undefined, legacyReplace: string | undefined): StampMode {
  const set = mode?.trim().toLowerCase();
  if (set === "assign" || set === "replace" || set === "off") {
    return set;
  }
  //unknown text reads as off, the direction TlvStampMode.of chooses: a typo must not be assumed to
  //be rewriting packets
  if (set) {
    return "off";
  }
  return legacyReplace?.trim().toLowerCase() === "true" ? "replace" : "off";
}

export async function listMandatorySources(): Promise<MandatorySource[]> {
  const [properties, config] = await Promise.all([
    configQuery<PropertyRow>(
      `SELECT p.worker_name, p.key, p.value
         FROM app_worker_property p
         JOIN app_worker w ON w.name = p.worker_name
        WHERE w.type = 'smppserver' AND w.enabled
          AND p.key IN ('mandatory.tlvs.submit', 'conf.whitelist.enabled', 'whitelist.tlvs.mode',
                        'whitelist.tlvs.replace')`
    ),
    configQuery<{ key: string; value: string | null }>(
      `SELECT key, value FROM app_config WHERE key = ANY($1::text[]) AND enabled`,
      [[REST_MANDATORY_KEY, REST_MODE_KEY]]
    ),
  ]);

  const byWorker = new Map<string, Map<string, string>>();
  for (const row of properties) {
    const settings = byWorker.get(row.worker_name) ?? new Map<string, string>();
    if (row.value !== null) {
      settings.set(row.key, row.value);
    }
    byWorker.set(row.worker_name, settings);
  }

  const sources: MandatorySource[] = [];
  for (const [listener, settings] of byWorker) {
    const tags = declarations(settings.get("mandatory.tlvs.submit"));
    //a listener demanding nothing cannot produce a gap, so it is dropped rather than carried with an
    //empty tag list -- that keeps "no source at all" the single silent case
    if (!tags.length) {
      continue;
    }
    sources.push({
      listener,
      tags,
      checksWhitelist: settings.get("conf.whitelist.enabled")?.trim().toLowerCase() !== "false",
      stamps: stampModeOf(settings.get("whitelist.tlvs.mode"),
        settings.get("whitelist.tlvs.replace")),
    });
  }

  const rest = new Map(config.map((r) => [r.key, r.value ?? ""]));
  const restTags = declarations(rest.get(REST_MANDATORY_KEY));
  if (restTags.length) {
    sources.push({
      listener: "",
      tags: restTags,
      //no listener to opt out, and stamping there is unconditional unless explicitly turned down
      checksWhitelist: true,
      stamps: stampModeOf(rest.get(REST_MODE_KEY), "true"),
    });
  }
  return sources;
}
