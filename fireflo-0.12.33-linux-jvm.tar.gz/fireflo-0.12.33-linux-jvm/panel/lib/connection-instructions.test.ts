import { test } from "node:test";
import assert from "node:assert/strict";
import { MASKED_PASSWORD, composeInstructions, instructionProblem, type InstructionInput } from "./connection-instructions.ts";

const smpp: InstructionInput = {
  accountLabel: "Acme Ltd",
  type: "SMPP",
  username: "acme1",
  password: "s3cret",
  hasPassword: true,
  allowedIps: ["203.0.113.7"],
  product: null,
  host: "smpp.example.com",
  servers: [
    { name: "main", port: 2775, tlsPort: null, maxRate: 50, maxBinds: 4, maxPending: 100 },
    { name: "backup", port: 2776, tlsPort: 3775, maxRate: 0, maxBinds: 0, maxPending: null },
  ],
  restUrl: "",
  note: "",
};

test("an SMPP mail carries host, every chosen port, system id, password and the allowed address", () => {
  const { subject, text } = composeInstructions(smpp);
  assert.equal(subject, "Your SMPP connection details: acme1");
  for (const want of ["smpp.example.com", "Port:          2775", "Port:          2776", "TLS port:      3775",
    "System ID:     acme1", "Password:      s3cret", "only from: 203.0.113.7", "Server 1", "Server 2"]) {
    assert.ok(text.includes(want), `missing ${want}`);
  }
  //a real ceiling is stated; 0 means unlimited and is not mentioned at all
  assert.ok(text.includes("up to 4 binds at once, up to 50 messages per second, window 100"));
  assert.ok(!/\b0 messages per second|no limit/.test(text));
  //listener names are the operator's, never the customer's
  assert.ok(!text.includes("main") && !text.includes("backup"));
});

test("one server is not numbered", () => {
  const { text } = composeInstructions({ ...smpp, servers: [smpp.servers[0]] });
  assert.ok(!text.includes("Server 1"));
  assert.ok(text.includes("\nServer\n"));
});

test("a password left out is explained, and a masked one is the mask", () => {
  const out = composeInstructions({ ...smpp, password: null }).text;
  assert.ok(!out.includes("s3cret") && !out.includes("Password:"));
  assert.ok(out.includes("sent to you separately"));
  assert.ok(composeInstructions({ ...smpp, password: MASKED_PASSWORD }).text.includes(MASKED_PASSWORD));
  //no password stored at all: nothing to promise
  assert.ok(!composeInstructions({ ...smpp, password: null, hasPassword: false }).text.includes("separately"));
});

test("an open login says so", () => {
  assert.ok(composeInstructions({ ...smpp, allowedIps: [] }).text.includes("from any IP address"));
});

test("an HTTP mail gives the endpoints under the address, with no trailing slash doubled", () => {
  const { subject, text } = composeInstructions({
    ...smpp, type: "HTTP", servers: [], host: "", restUrl: "https://api.example.com/", product: "premium",
  });
  assert.equal(subject, "Your HTTP API connection details: acme1");
  assert.ok(text.includes("POST https://api.example.com/secure/send"));
  assert.ok(text.includes("POST https://api.example.com/secure/sendbatch"));
  assert.ok(text.includes("curl -u 'acme1:s3cret'"));
  assert.ok(text.includes("product premium"));
  assert.ok(!text.includes("//secure"));
});

test("the note comes first, above the details", () => {
  const { text } = composeInstructions({ ...smpp, note: "Welcome aboard." });
  assert.ok(text.indexOf("Welcome aboard.") < text.indexOf("System ID"));
});

test("what is missing is named before anything is sent", () => {
  assert.equal(instructionProblem(smpp), null);
  assert.match(instructionProblem({ ...smpp, host: " " })!, /address/);
  assert.match(instructionProblem({ ...smpp, servers: [] })!, /server/);
  assert.match(instructionProblem({ ...smpp, type: "HTTP", restUrl: "api.example.com" })!, /http/);
  assert.equal(instructionProblem({ ...smpp, type: "HTTP", restUrl: "http://10.0.0.1:8081" }), null);
});
