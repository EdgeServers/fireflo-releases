/**
 * Parsing the Prometheus text exposition format.
 *
 * <p>Deliberately not named `lib/metrics-*`: `lib/metrics-db.ts` and `lib/metrics-queries.ts` already
 * mean the Postgres call-record database, and a third sense of "metrics" in that namespace is a trap
 * for whoever reads it next. This one is only about the gateway's `/q/metrics` text.
 *
 * <p>Pure functions, no imports — usable from a route handler or a test without dragging anything
 * server-only along.
 */

export type MetricType = "counter" | "gauge" | "histogram" | "summary" | "untyped";

export interface Sample {
  /** The name as emitted, which is not always the family name — see {@link parseMetrics}. */
  name: string;
  labels: Record<string, string>;
  value: number;
}

export interface MetricFamily {
  name: string;
  type: MetricType;
  help: string;
  samples: Sample[];
}

/**
 * Turns an exposition payload into one entry per declared family.
 *
 * <p><strong>A sample's name is not its family's name.</strong> Micrometer emits a counter declared
 * as `jvm_info` under `jvm_info_total`, and a summary declared as `jvm_gc_pause_seconds` under
 * `_count`, `_sum` and `_max`. So each sample is assigned to the **longest** declared name that
 * prefixes it — longest, not first, because `jvm_gc_pause_seconds_max` is itself a declared gauge as
 * well as a sample of the summary above it, and the shorter match would swallow it.
 *
 * <p>A sample matching no declaration still gets a family of its own rather than being dropped.
 * Silently losing a metric would look like a tidy dashboard rather than a bug.
 */
export function parseMetrics(text: string): MetricFamily[] {
  const families = new Map<string, MetricFamily>();
  const pending: Sample[] = [];

  const family = (name: string): MetricFamily => {
    let found = families.get(name);
    if (!found) {
      found = { name, type: "untyped", help: "", samples: [] };
      families.set(name, found);
    }
    return found;
  };

  for (const raw of text.split("\n")) {
    const line = raw.trim();
    if (!line) {
      continue;
    }
    if (line.startsWith("#")) {
      const meta = /^#\s+(HELP|TYPE)\s+(\S+)\s*(.*)$/.exec(line);
      if (!meta) {
        continue;
      }
      const [, kind, name, rest] = meta;
      if (kind === "HELP") {
        family(name).help = unescape(rest);
      } else {
        family(name).type = asType(rest.trim());
      }
      continue;
    }
    const sample = parseSample(line);
    if (sample) {
      pending.push(sample);
    }
  }

  //declared names sorted longest first, so the first prefix hit is the most specific one
  const declared = [...families.keys()].sort((a, b) => b.length - a.length);
  for (const sample of pending) {
    const owner = declared.find((name) => sample.name.startsWith(name));
    family(owner ?? sample.name).samples.push(sample);
  }

  return [...families.values()];
}

/** @returns the sample, or null for a line that is not one — never throws on odd input */
function parseSample(line: string): Sample | null {
  const open = line.indexOf("{");
  let name: string;
  let labels: Record<string, string> = {};
  let rest: string;

  if (open === -1) {
    const space = line.indexOf(" ");
    if (space === -1) {
      return null;
    }
    name = line.slice(0, space);
    rest = line.slice(space + 1);
  } else {
    name = line.slice(0, open);
    const close = closingBrace(line, open);
    if (close === -1) {
      return null;
    }
    labels = parseLabels(line.slice(open + 1, close));
    rest = line.slice(close + 1);
  }

  //a trailing timestamp is allowed by the format and ignored here: this is a live snapshot, and the
  //time that matters is when we asked, not when the gateway last touched the counter
  const value = parseValue(rest.trim().split(/\s+/)[0]);
  return value === null ? null : { name, labels, value };
}

/**
 * <p>Scans rather than regexes because a label value may contain a brace, and one has already been
 * seen to contain a quote: `id="CodeHeap 'profiled nmethods'"`.
 */
function closingBrace(line: string, open: number): number {
  let inQuotes = false;
  for (let i = open + 1; i < line.length; i++) {
    const ch = line[i];
    if (inQuotes) {
      if (ch === "\\") {
        i++;
      } else if (ch === '"') {
        inQuotes = false;
      }
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === "}") {
      return i;
    }
  }
  return -1;
}

function parseLabels(text: string): Record<string, string> {
  const labels: Record<string, string> = {};
  const pattern = /([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*"((?:[^"\\]|\\.)*)"/g;
  let match: RegExpExecArray | null;
  while ((match = pattern.exec(text)) !== null) {
    labels[match[1]] = unescape(match[2]);
  }
  return labels;
}

/**
 * @returns null for anything unparseable, and for NaN — which the format uses for "no value yet"
 *     and which would otherwise poison every sum it landed in
 */
function parseValue(token: string | undefined): number | null {
  if (!token) {
    return null;
  }
  if (token === "+Inf") {
    return Number.POSITIVE_INFINITY;
  }
  if (token === "-Inf") {
    return Number.NEGATIVE_INFINITY;
  }
  if (token === "NaN") {
    return null;
  }
  const value = Number(token);
  return Number.isNaN(value) ? null : value;
}

function unescape(text: string): string {
  return text.replace(/\\(.)/g, (_, ch: string) =>
    ch === "n" ? "\n" : ch === "t" ? "\t" : ch
  );
}

function asType(token: string): MetricType {
  switch (token) {
    case "counter":
    case "gauge":
    case "histogram":
    case "summary":
      return token;
    default:
      return "untyped";
  }
}

/**
 * Sums one family's samples, optionally only those matching every given label.
 *
 * <p>Infinite values are skipped: `jvm_memory_max_bytes` reports -1 for pools with no ceiling, and
 * an unbounded pool must not drag a heap total negative.
 */
export function sum(family: MetricFamily | undefined, match: Record<string, string> = {}): number {
  if (!family) {
    return 0;
  }
  let total = 0;
  for (const sample of family.samples) {
    if (!Number.isFinite(sample.value) || sample.value < 0) {
      continue;
    }
    if (Object.entries(match).every(([k, v]) => sample.labels[k] === v)) {
      total += sample.value;
    }
  }
  return total;
}

/** @returns the first sample's value, or null when the family is absent or empty */
export function first(family: MetricFamily | undefined): number | null {
  const value = family?.samples[0]?.value;
  return value == null || !Number.isFinite(value) ? null : value;
}

export function byName(families: MetricFamily[]): Map<string, MetricFamily> {
  return new Map(families.map((f) => [f.name, f]));
}
