/**
 * One account's MT usage — messages, MT parts, charges — from day x product lines.
 *
 * <p>No database import: the route sums the lifetime figures with it, and the billing page re-cuts
 * the recent lines into 7, 30 or 90 days without another request.
 *
 * <p>An MT part is one SMS segment handed to a vendor. A message split into three counts three.
 * Amounts stay scaled integers; dividing is `money()`'s job.
 */

export interface MtUsageLine {
  /** `YYYY-MM-DD`, cut in the billing zone. */
  day: string;
  product: string;
  messages: number;
  /** Null on a day rolled up before the gateway counted parts (V1.68.0): not counted, not zero. */
  mtParts: number | null;
  price: number;
}

export interface MtFigure {
  messages: number;
  /** The parts that were counted. Short of the truth by whatever `uncountedDays` covers. */
  mtParts: number;
  price: number;
}

export interface MtUsage {
  /** Today in the billing zone, which is what "this month" and "today" are cut from. */
  today: string;
  lifetime: MtFigure;
  month: MtFigure;
  todaySoFar: MtFigure;
  /** The last seven days, today included. */
  week: MtFigure;
  /** Days with traffic whose parts were never counted. Nonzero only after an upgrade, until a catch-up. */
  uncountedDays: number;
  /** Lines for the last {@link RECENT_DAYS} days, for the chart and the product table. */
  recent: MtUsageLine[];
}

/** The longest window the page offers. The route sends this much and the page cuts it shorter. */
export const RECENT_DAYS = 90;

const ZERO: MtFigure = { messages: 0, mtParts: 0, price: 0 };

function add(into: MtFigure, line: MtUsageLine): MtFigure {
  return {
    messages: into.messages + line.messages,
    mtParts: into.mtParts + (line.mtParts ?? 0),
    price: into.price + line.price,
  };
}

/** `day` moved by `delta` days. Plain calendar arithmetic in UTC, so no zone can shift it. */
export function shiftDay(day: string, delta: number): string {
  const at = new Date(`${day}T00:00:00Z`);
  at.setUTCDate(at.getUTCDate() + delta);
  return at.toISOString().slice(0, 10);
}

/** The lifetime, month and today figures, plus the recent lines the page draws. */
export function summariseMtUsage(lines: MtUsageLine[], today: string): MtUsage {
  const monthStart = `${today.slice(0, 7)}-01`;
  const recentFrom = shiftDay(today, -(RECENT_DAYS - 1));
  let lifetime = ZERO;
  let month = ZERO;
  let todaySoFar = ZERO;
  let week = ZERO;
  const weekFrom = shiftDay(today, -6);
  const uncounted = new Set<string>();
  const recent: MtUsageLine[] = [];
  for (const line of lines) {
    lifetime = add(lifetime, line);
    if (line.day >= monthStart && line.day <= today) {
      month = add(month, line);
    }
    if (line.day === today) {
      todaySoFar = add(todaySoFar, line);
    }
    if (line.day >= weekFrom && line.day <= today) {
      week = add(week, line);
    }
    if (line.mtParts === null && line.messages > 0) {
      uncounted.add(line.day);
    }
    if (line.day >= recentFrom && line.day <= today) {
      recent.push(line);
    }
  }
  return {
    today,
    lifetime,
    month,
    todaySoFar,
    week,
    uncountedDays: uncounted.size,
    recent,
  };
}

export interface MtDay {
  day: string;
  /** Null when any line of the day was not counted, so the chart draws a gap rather than a dip. */
  mtParts: number | null;
  messages: number;
}

/** One point per calendar day of the window, oldest first, quiet days filled with zero. */
export function mtSeries(recent: MtUsageLine[], today: string, days: number): MtDay[] {
  const byDay = new Map<string, MtDay>();
  for (let i = days - 1; i >= 0; i--) {
    const day = shiftDay(today, -i);
    byDay.set(day, { day, mtParts: 0, messages: 0 });
  }
  for (const line of recent) {
    const at = byDay.get(line.day);
    if (!at) {
      continue;
    }
    at.messages += line.messages;
    at.mtParts = at.mtParts === null || line.mtParts === null ? null : at.mtParts + line.mtParts;
  }
  return [...byDay.values()];
}

export interface MtProduct extends MtFigure {
  product: string;
  /** Whether every line behind this row had its parts counted. */
  counted: boolean;
}

/** One row per product over the window, most parts first. */
export function mtProducts(recent: MtUsageLine[], today: string, days: number): MtProduct[] {
  const from = shiftDay(today, -(days - 1));
  const byProduct = new Map<string, MtProduct>();
  for (const line of recent) {
    if (line.day < from || line.day > today) {
      continue;
    }
    const at = byProduct.get(line.product) ?? { product: line.product, ...ZERO, counted: true };
    byProduct.set(line.product, {
      ...at,
      ...add(at, line),
      counted: at.counted && (line.mtParts !== null || line.messages === 0),
    });
  }
  return [...byProduct.values()].sort((a, b) => b.mtParts - a.mtParts || a.product.localeCompare(b.product));
}
