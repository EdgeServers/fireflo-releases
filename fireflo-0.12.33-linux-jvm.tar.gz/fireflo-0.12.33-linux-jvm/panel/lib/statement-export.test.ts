import { strict as assert } from "node:assert";
import { test } from "node:test";

import { HEADERS, statementFileName, toCsvLine } from "./statement-export.ts";
import type { StatementRow } from "./statement-queries.ts";

function row(overrides: Partial<StatementRow> = {}): StatementRow {
  return {
    id: "1",
    submittedAt: "2026-08-19T04:00:00.000Z",
    gatewayMsgId: "gw-1",
    product: "otp",
    to: "61400000000",
    from: "ACMEIN",
    parts: 1,
    outcome: "DELIVERED",
    price: 1155,
    ...overrides,
  };
}

test("the header order is asserted by value, because a spreadsheet depends on it", () => {
  //not "contains these columns": whoever imports this writes =SUM(J:J) against a column letter, and
  //reordering would change what that formula adds up with nothing anywhere reporting it
  assert.deepEqual([...HEADERS], [
    "submitted_at",
    "gateway_msg_id",
    "product",
    "source_addr",
    "dest_addr",
    "parts",
    "outcome",
    "billed",
    "price",
    "price_scaled",
  ]);
});

test("every line has exactly as many fields as there are headers", () => {
  const fields = toCsvLine(row()).trimEnd().split(",");
  assert.equal(fields.length, HEADERS.length);
});

test("an amount is written both ways, and the decimal is exact", () => {
  //1155 ten-thousandths is 0.1155. Done by division that is 0.11549999999999999 on some values,
  //which is why the conversion moves characters instead
  const line = toCsvLine(row({ price: 1155 }));
  assert.match(line, /,0\.1155,1155\n$/);
  assert.match(toCsvLine(row({ price: 1 })), /,0\.0001,1\n$/);
  assert.match(toCsvLine(row({ price: 10_000 })), /,1\.0000,10000\n$/);
  assert.match(toCsvLine(row({ price: 250_000_000 })), /,25000\.0000,250000000\n$/);
});

test("an unbilled message says so rather than showing a zero", () => {
  //zero is a real price meaning free. A message that was never charged -- unrated, or refunded --
  //has to be distinguishable from one that cost nothing, or an invoice cannot be reconciled
  const line = toCsvLine(row({ price: null }));
  assert.match(line, /,false,,\n$/);
  assert.match(toCsvLine(row({ price: 0 })), /,true,0\.0000,0\n$/);
});

test("a value that would be read as a formula is neutralised", () => {
  //the guard `csv()` carries and the reason this module goes through it rather than joining strings.
  //A sender id of =cmd|... is a real thing a customer can register
  const line = toCsvLine(row({ from: "=1+1", product: "@SUM(A1)" }));
  assert.ok(!line.includes(",=1+1,"), line);
  assert.ok(!line.includes(",@SUM(A1),"), line);
});

test("a file name survives an account id with a slash in it", () => {
  assert.equal(statementFileName("acct-1001", "2026-08"), "statement-acct-1001-2026-08.csv");
  assert.equal(statementFileName("a/../b", "2026-08"), "statement-a_.._b-2026-08.csv");
});
