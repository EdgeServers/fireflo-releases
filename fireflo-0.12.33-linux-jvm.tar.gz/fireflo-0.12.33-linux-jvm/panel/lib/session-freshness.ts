/**
 * Whether a session was minted before the password it was signed in with was replaced.
 *
 * <p>A leaf module: it imports nothing, so `session-freshness.test.ts` runs on Node's own runner.
 *
 * <h2>The mechanism</h2>
 *
 * <p>Sessions are JWTs and nothing re-signs them, so until 0.12.15 a password reset left every
 * existing cookie working (CP-S4 in the 0.13 readiness audit). Now `app_user.password_changed_at`
 * is stamped whenever a password is set, reset, changed or removed, and the value as it stood at
 * sign-in rides in the token as `pwdAt`. `requireOperator` and `requireCustomer` read the column
 * fresh on every request and compare: a token whose stamp is older than the row's -- or that has no
 * stamp while the row has one -- was minted before the change and is refused, with the same 404 a
 * disabled user gets.
 *
 * <p>The token carries the ROW'S value rather than the sign-in time, so the comparison is between
 * two readings of one column and clock skew between the panel and Postgres cannot enter into it.
 *
 * <p>Milliseconds, because `pg` hands back a `Date`, which keeps milliseconds, and a JWT claim is
 * best a plain number. Both sides go through {@link passwordStamp}, so the truncation is the same
 * on both.
 */

/** The column's value as the number a token carries, or null when the password was never stamped. */
export function passwordStamp(value: Date | string | number | null | undefined): number | null {
  if (value === null || value === undefined || value === "") {
    return null;
  }
  const ms = typeof value === "number" ? value : new Date(value).getTime();
  return Number.isFinite(ms) ? Math.floor(ms) : null;
}

/**
 * True when the session must be refused: the row says the password changed after this token was
 * minted.
 *
 * <p>A row with no stamp admits every token: nothing has changed since the column arrived, and a
 * session from before the upgrade is as good as it was yesterday. A row WITH a stamp admits only a
 * token stamped at or after it -- a token with no stamp at all predates the column being written,
 * which is the same as predating the change.
 */
export function sessionPredatesPasswordChange(
  tokenStamp: number | null | undefined,
  rowChangedAt: Date | string | number | null | undefined
): boolean {
  const row = passwordStamp(rowChangedAt);
  if (row === null) {
    return false;
  }
  const token = passwordStamp(tokenStamp);
  return token === null || token < row;
}
