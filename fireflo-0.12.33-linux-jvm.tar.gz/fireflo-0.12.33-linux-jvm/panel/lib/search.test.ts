import { strict as assert } from "node:assert";
import { test } from "node:test";
import { looksLikeMessageId, rankAccounts, rankNames, toHits } from "./search.ts";

const accounts = [
  { id: "acme-au", label: "Acme Communications" },
  { id: "nbank", label: "Northern Bank" },
  { id: "kiwi-sms", label: null },
  { id: "retail-grp", label: "Acme Retail" },
];

test("prefix matches come before contains matches, ids and labels alike", () => {
  assert.deepEqual(rankAccounts(accounts, "ac").map((a) => a.id), ["acme-au", "retail-grp"]);
  assert.deepEqual(rankAccounts(accounts, "bank").map((a) => a.id), ["nbank"]);
  assert.deepEqual(rankAccounts(accounts, "ACME").map((a) => a.id), ["acme-au", "retail-grp"]);
});

test("an empty query matches nothing and the list is capped", () => {
  assert.deepEqual(rankAccounts(accounts, "  "), []);
  assert.equal(rankNames(["a1", "a2", "a3"], "a", 2).length, 2);
});

test("a message id is long, unspaced and alphanumeric", () => {
  assert.equal(looksLikeMessageId("01J9W3K8Q2ZT7V0M9"), true);
  assert.equal(looksLikeMessageId("acme-au"), false);
  assert.equal(looksLikeMessageId("two words here"), false);
});

test("hits are links, the message first", () => {
  const hits = toHits({ accounts: [{ id: "acme au", label: null }], vendors: ["telstra-a"], servers: [], message: "01J9" });
  assert.deepEqual(hits.map((h) => h.href), ["/cp/cdrs/01J9", "/cp/accounts/acme%20au", "/cp/vendors/telstra-a"]);
});
