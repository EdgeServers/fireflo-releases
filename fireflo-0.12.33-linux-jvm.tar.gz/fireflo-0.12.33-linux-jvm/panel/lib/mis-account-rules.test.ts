import { test } from "node:test";
import assert from "node:assert/strict";
import { childIdProblem, narrowChildAccount, narrowChildLogin } from "./mis-account-rules.ts";

/**
 * The reseller write boundary, pinned.
 *
 * <p>Written before anything consumed the module. Most of these cases are one shape: a request body
 * carrying a field a reseller must not set, asserted to change nothing about what is written. They
 * read as paranoid and are the entire point — the failure they guard against is not a crash, it is a
 * reseller quietly setting its own child's price, or adopting somebody else's account.
 *
 * <p>No test framework and no mocking: `mis-account-rules.ts` imports nothing, which is why it can
 * be checked this cheaply.
 */

test("a body claiming resells or a parent changes nothing that is written", () => {
  const written = narrowChildAccount(
    { label: "Acme", resells: true, parentAccountId: "someone-else", id: "not-this" },
    "acme"
  );
  assert.equal(written.id, "acme", "the id comes from the path, never the body");
  assert.deepEqual(Object.keys(written).sort(),
    ["description", "email", "enabled", "id", "label"]);
  //the two dangerous fields are absent rather than false: a caller spreading this object cannot
  //re-introduce them by accident
  assert.equal("resells" in written, false);
  assert.equal("parentAccountId" in written, false);
});

test("a login body naming a product or allowed products writes neither", () => {
  const written = narrowChildLogin({
    type: "SMPP",
    systemId: "acme1",
    product: "premium",
    allowedProducts: ["premium", "wholesale"],
    accountId: "someone-else",
  });
  assert.deepEqual(Object.keys(written).sort(),
    ["allowedIps", "enabled", "systemId", "type"]);
  assert.equal("product" in written, false, "the pricing boundary");
  assert.equal("allowedProducts" in written, false, "the pricing boundary");
  assert.equal("accountId" in written, false, "pinned to the child by the caller");
});

test("a login body supplying a secret is not honoured", () => {
  const written = narrowChildLogin({ type: "SMPP", password: "hunter2", apiKey: "k-123" });
  assert.equal("password" in written, false);
  assert.equal("apiKey" in written, false);
});

test("type is exactly SMPP or HTTP, and a lowercased value does not become SMPP", () => {
  assert.equal(narrowChildLogin({ type: "SMPP" }).type, "SMPP");
  //the case uq_app_credential_smpp cares about: 'smpp' must not resolve to the literal the index
  //compares against, or the row escapes the only unique index on the table
  assert.equal(narrowChildLogin({ type: "smpp" }).type, "HTTP");
  assert.equal(narrowChildLogin({}).type, "HTTP");
});

test("absent enabled means enabled, present false means not", () => {
  assert.equal(narrowChildAccount({}, "a").enabled, true);
  assert.equal(narrowChildAccount({ enabled: false }, "a").enabled, false);
  assert.equal(narrowChildLogin({}).enabled, true);
  assert.equal(narrowChildLogin({ enabled: false }).enabled, false);
});

test("empty text is null, not an empty string", () => {
  const written = narrowChildAccount({ label: "   ", email: "" }, "a");
  assert.equal(written.label, null);
  assert.equal(written.email, null);
});

test("text is trimmed and capped", () => {
  const written = narrowChildAccount({ label: `  ${"x".repeat(500)}  ` }, "a");
  assert.equal(written.label?.length, 200);
});

test("allowed IPs are bounded, de-duplicated and non-strings dropped", () => {
  const many = Array.from({ length: 200 }, (_, i) => `10.0.0.${i}`);
  assert.equal(narrowChildLogin({ allowedIps: many }).allowedIps.length, 50);
  assert.deepEqual(
    narrowChildLogin({ allowedIps: [" 1.1.1.1 ", "1.1.1.1", 42, null, ""] }).allowedIps,
    ["1.1.1.1"]
  );
  assert.deepEqual(narrowChildLogin({ allowedIps: "1.1.1.1" }).allowedIps, []);
});

test("an id already taken by an account or a vendor is refused", () => {
  assert.match(childIdProblem("acme", ["acme"]) ?? "", /already in use/);
  //a vendor name, which shares app_rate_rule.scope with accounts -- the collision listAccounts
  //reports as collidesWithVendor, caught before the row exists
  assert.match(childIdProblem("billbasket", ["billbasket"]) ?? "", /already in use/);
  //case-insensitively, unlike the primary key, because the id is read aloud more than it is typed
  assert.match(childIdProblem("ACME", ["acme"]) ?? "", /already in use/);
  assert.equal(childIdProblem("acme2", ["acme"]), null);
});

test("an id with an edge space is refused, and says why it would be invisible", () => {
  assert.match(childIdProblem(" acme", []) ?? "", /space at one end/);
  assert.match(childIdProblem("acme ", []) ?? "", /space at one end/);
});

test("an empty, over-long or oddly-punctuated id is refused", () => {
  assert.match(childIdProblem("", []) ?? "", /required/);
  assert.match(childIdProblem("   ", []) ?? "", /required/);
  assert.match(childIdProblem(undefined, []) ?? "", /required/);
  assert.match(childIdProblem("x".repeat(65), []) ?? "", /too long/);
  for (const bad of ["-leading", ".dot", "has space", "has/slash", "has%25"]) {
    assert.notEqual(childIdProblem(bad, []), null, `${bad} should be refused`);
  }
  for (const good of ["a", "A1", "acme-uk", "acme.uk", "acme_uk", "9lives"]) {
    assert.equal(childIdProblem(good, []), null, `${good} should be allowed`);
  }
});
