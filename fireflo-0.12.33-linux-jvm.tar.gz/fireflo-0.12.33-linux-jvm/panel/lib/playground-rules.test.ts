import { test } from "node:test";
import assert from "node:assert/strict";
import {
  offeredLogins,
  productOptions,
  resolveOffered,
  resolveRotatable,
  rotatableLogins,
  rotationProblem,
  type CredentialRow,
  type RotatableLogin,
} from "./playground-rules.ts";

/**
 * Which logins the playground may use.
 *
 * <p>This is the security boundary of the whole feature. The proxy takes a login name from the
 * request body, so without these rules anyone holding a magic-link session could name another
 * customer's login and read back whether a guessed password was right.
 */

const row = (over: Partial<CredentialRow> = {}): CredentialRow => ({
  id: "7",
  accountId: "acct-in-2001",
  systemId: "sunrise-http",
  type: "HTTP",
  product: "in-otp",
  ipRestricted: false,
  hasPassword: true,
  keyIsSecret: false,
  ...over,
});

test("a login on this account is offered", () => {
  assert.deepEqual(offeredLogins([row()], "acct-in-2001").map((l) => l.lookupKey), ["sunrise-http"]);
});

test("THE RULE: another account's login is not offered", () => {
  //without this the playground tests passwords against every login on the platform
  assert.deepEqual(offeredLogins([row({ accountId: "acct-1001" })], "acct-in-2001"), []);
});

test("naming another account's login resolves to nothing", () => {
  //the same rule at the second gate, which is the one the proxy actually consults. A caller who
  //knows a login name must get the same answer as one who invents it
  const offered = offeredLogins([row()], "acct-in-2001");

  assert.equal(resolveOffered(offered, "acme-http"), null);
  assert.equal(resolveOffered(offered, "sunrise-http")?.lookupKey, "sunrise-http");
});

test("an SMPP login is not offered, because it cannot use this API at all", () => {
  //CredentialAuthenticator refuses type != HTTP with NOT_HTTP_CREDENTIAL, and that refusal reads
  //exactly like a wrong password -- so offering one would send a customer looking for a typo
  assert.deepEqual(offeredLogins([row({ type: "SMPP" })], "acct-in-2001"), []);
});

test("a login with no password is not offered", () => {
  //the gateway answers NO_PASSWORD_SET. Nothing the customer types can make this one work
  assert.deepEqual(offeredLogins([row({ hasPassword: false })], "acct-in-2001"), []);
});

test("a login whose lookup key is its api key is not offered", () => {
  //the key is itself a secret, and listing it would print a live credential on a page the operator
  //never chose to show
  assert.deepEqual(offeredLogins([row({ keyIsSecret: true })], "acct-in-2001"), []);
});

test("a login with no system id is not offered", () => {
  assert.deepEqual(offeredLogins([row({ systemId: null })], "acct-in-2001"), []);
});

test("an IP-restricted login is offered, and says so", () => {
  //offered because it may well work from the customer's own server -- the restriction is about
  //where the call comes from, and the playground calls from the panel. Flagged so the refusal can
  //say which of the two happened
  const offered = offeredLogins([row({ ipRestricted: true })], "acct-in-2001");

  assert.equal(offered.length, 1);
  assert.equal(offered[0].ipRestricted, true);
});

test("a blank or absent login resolves to nothing rather than to the first one", () => {
  //defaulting would mean an empty field silently sent as somebody's real login
  const offered = offeredLogins([row()], "acct-in-2001");

  for (const bad of ["", "   ", null, undefined]) {
    assert.equal(resolveOffered(offered, bad), null, String(bad));
  }
});

test("a login is matched exactly, not case-insensitively", () => {
  //the gateway looks a credential up by exact string, so a case-folded match here would resolve to
  //a login the gateway then refuses -- a confusing failure rather than a helpful one
  const offered = offeredLogins([row()], "acct-in-2001");

  assert.equal(resolveOffered(offered, "SUNRISE-HTTP"), null);
});

test("surrounding whitespace on a typed login is forgiven", () => {
  const offered = offeredLogins([row()], "acct-in-2001");

  assert.equal(resolveOffered(offered, "  sunrise-http  ")?.lookupKey, "sunrise-http");
});

test("an account with no usable login gets an empty list rather than someone else's", () => {
  const rows = [row({ accountId: "acct-1001" }), row({ accountId: "acct-lane-3001" })];

  assert.deepEqual(offeredLogins(rows, "acct-in-2001"), []);
});

/**
 * Which logins a customer may rotate a secret on.
 *
 * <p>A rotation is the one thing a customer can do from the portal that breaks their own
 * integration, and rotating an api key breaks it twice over — the key is the Basic username, so the
 * old one stops existing rather than merely stops working.
 */

const rotatable = (over: Partial<RotatableLogin> = {}): RotatableLogin => ({
  id: "7",
  systemId: "sunrise-http",
  hasPassword: true,
  hasApiKey: false,
  keyIsUsername: false,
  ...over,
});

test("an api-key-keyed login IS offered for rotation, unlike for the playground", () => {
  //offeredLogins excludes it because listing it would print a live credential. Rotation is the
  //opposite need: that key is exactly the one somebody wants to replace
  const rows = [row({ keyIsSecret: true, hasApiKey: true })];

  assert.deepEqual(offeredLogins(rows, "acct-in-2001"), [], "not offered for sending");
  assert.equal(rotatableLogins(rows, "acct-in-2001").length, 1, "but offered for rotation");
});

test("a rotatable login is labelled by its system id, never by its key", () => {
  //the api key is a secret; putting it on screen as the label would defeat the point of rotating it
  const found = rotatableLogins([row({ keyIsSecret: true, hasApiKey: true })], "acct-in-2001");

  assert.equal(found[0].systemId, "sunrise-http");
  assert.ok(!JSON.stringify(found[0]).includes("api"), "no key value anywhere in the shape");
});

test("THE RULE, again: another account's login is not rotatable", () => {
  assert.deepEqual(rotatableLogins([row({ accountId: "acct-1001" })], "acct-in-2001"), []);
});

test("naming another account's credential id resolves to nothing", () => {
  //an id is a number somebody can guess, so this is the whole guard
  const mine = rotatableLogins([row()], "acct-in-2001");

  assert.equal(resolveRotatable(mine, "8"), null);
  assert.equal(resolveRotatable(mine, "7")?.id, "7");
});

test("an SMPP login is not rotatable here", () => {
  //this is the REST credential surface; an SMPP password is a different conversation
  assert.deepEqual(rotatableLogins([row({ type: "SMPP" })], "acct-in-2001"), []);
});

test("a login with no system id is excluded, because it cannot be named on screen", () => {
  //a customer choosing between two blanks is a customer about to rotate the wrong one
  assert.deepEqual(rotatableLogins([row({ systemId: null })], "acct-in-2001"), []);
});

test("a blank id resolves to nothing rather than to the first login", () => {
  const mine = rotatableLogins([row()], "acct-in-2001");

  for (const bad of ["", "   ", null, undefined]) {
    assert.equal(resolveRotatable(mine, bad), null, String(bad));
  }
});

test("keyIsUsername marks the rotation that changes who the customer is", () => {
  //with an api key set it IS the Basic username, so rotating it does not replace a secret -- it
  //replaces an identity, and the old one stops existing
  const withKey = rotatableLogins([row({ keyIsSecret: true, hasApiKey: true })], "acct-in-2001");
  const without = rotatableLogins([row()], "acct-in-2001");

  assert.equal(withKey[0].keyIsUsername, true);
  assert.equal(without[0].keyIsUsername, false);
});

test("rotating a password that does not exist is refused, not silently created", () => {
  const problem = rotationProblem(rotatable({ hasPassword: false }), "password");

  assert.match(problem ?? "", /no password to replace/);
});

test("rotating an api key onto a login with none is refused", () => {
  //adding one would change the username, because the key becomes the lookup key the moment it
  //exists. That is a different act from replacing one, and nobody clicking rotate asked for it
  const problem = rotationProblem(rotatable({ hasApiKey: false }), "apiKey");

  assert.match(problem ?? "", /change the username/);
});

test("a rotation the login can do is not refused", () => {
  assert.equal(rotationProblem(rotatable(), "password"), null);
  assert.equal(rotationProblem(rotatable({ hasApiKey: true }), "apiKey"), null);
});

test("the picker offers the product the login already carries", () => {
  //the gateway allows it without consulting the allow list at all, so a login with a product and no
  //opt-ins still has exactly one thing it may name -- and used to be told it could name nothing
  assert.deepEqual(
    productOptions({ product: "otp", allowedProducts: [] }),
    ["otp"]
  );
});

test("its own product leads, then whatever the operator allowed", () => {
  assert.deepEqual(
    productOptions({ product: "otp", allowedProducts: ["promo", "transactional"] }),
    ["otp", "promo", "transactional"]
  );
});

test("an operator who also listed the login's own product gets it once", () => {
  assert.deepEqual(
    productOptions({ product: "otp", allowedProducts: ["otp", "promo"] }),
    ["otp", "promo"]
  );
});

test("a login carrying no product and allowed none has nothing to offer", () => {
  //the anti-vacuity half: this is the case the read-only note exists for, and it has to stay
  //reachable or the note becomes unreachable code
  assert.deepEqual(productOptions({ product: null, allowedProducts: [] }), []);
  assert.deepEqual(productOptions(undefined), []);
});

test("blank and whitespace product values are not offered as choices", () => {
  //an empty string in either place would render a blank option indistinguishable from the "your
  //login's own product" one, and send `product=""` if picked
  assert.deepEqual(productOptions({ product: "  ", allowedProducts: ["", " ", "promo"] }), ["promo"]);
});
