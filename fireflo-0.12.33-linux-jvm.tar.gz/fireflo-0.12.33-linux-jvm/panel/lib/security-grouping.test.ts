import { test } from "node:test";
import assert from "node:assert/strict";
import { bucketsFor, displayIp, groupByAddress } from "./security-grouping.ts";
import type { SecurityEvent } from "./security-events.ts";

const ev = (ip: string, at: string, surface: SecurityEvent["surface"], triedAs: string | null): SecurityEvent =>
  ({ ip, at, surface, triedAs, reason: "badPassword" });

test("an IPv4 address seen through an IPv6 socket is the same address", () => {
  assert.equal(displayIp("::ffff:10.0.0.7"), "10.0.0.7");
  assert.equal(displayIp("2001:db8::1"), "2001:db8::1");
  assert.equal(displayIp("10.0.0.7"), "10.0.0.7");
});

test("refusals group by address, busiest first, with the names each tried", () => {
  const rows = groupByAddress([
    ev("::ffff:10.0.0.7", "2026-10-13T10:00:00Z", "smpp", "acme"),
    ev("10.0.0.7", "2026-10-13T11:00:00Z", "smpp", "acme"),
    ev("10.0.0.7", "2026-10-13T12:00:00Z", "rest", "billing"),
    ev("10.0.0.9", "2026-10-13T13:00:00Z", "portal", null),
  ]);
  assert.equal(rows.length, 2);
  assert.equal(rows[0].ip, "10.0.0.7");
  assert.equal(rows[0].attempts, 3);
  assert.deepEqual(rows[0].triedAs, ["acme", "billing"]);
  assert.equal(rows[0].bySurface.smpp, 2);
  assert.equal(rows[0].firstAt, "2026-10-13T10:00:00Z");
  assert.equal(rows[0].lastAt, "2026-10-13T12:00:00Z");
  assert.deepEqual(rows[1].triedAs, []);
});

test("a day's window is hourly bars, empty hours included; a month's is daily", () => {
  const now = Date.parse("2026-10-13T12:30:00Z");
  const hourly = bucketsFor([ev("10.0.0.7", "2026-10-13T12:05:00Z", "smpp", "a")], 24, now);
  assert.ok(hourly.length >= 24 && hourly.length <= 25, String(hourly.length));
  assert.equal(hourly.reduce((n, b) => n + b.total, 0), 1);
  assert.equal(hourly[hourly.length - 1].bySurface.smpp, 1);

  const daily = bucketsFor([], 24 * 30, now);
  assert.ok(daily.length >= 30 && daily.length <= 31, String(daily.length));
});
