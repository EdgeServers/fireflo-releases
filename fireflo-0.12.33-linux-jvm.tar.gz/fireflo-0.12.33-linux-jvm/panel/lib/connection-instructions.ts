/**
 * The mail that tells a customer how to connect: where, as whom, and within what limits.
 *
 * <p>Pure on purpose. The route reads the login, its secrets and the listeners, and hands them here;
 * this only turns facts into text. That keeps the one part with an opinion about wording testable
 * without a database, and keeps the password out of every code path but the two that must hold it.
 *
 * <h2>Why the password is a parameter that can be masked</h2>
 *
 * <p>The preview is rendered in the operator's browser, and a bind password has no business there
 * (`listWorkers` and `listCredentials` both refuse to send one). So the preview is composed with
 * {@link MASKED_PASSWORD} in its place, and only the mail itself -- composed on the server, sent from
 * the server -- carries the real value. Copy is the one exception, because copying is the operator
 * asking for the text that goes out.
 */

export const MASKED_PASSWORD = "••••••••";

/** One SMPP listener the customer may bind to. */
export interface InstructionServer {
  /** The listener's worker name: what the operator picks by, never shown to the customer. */
  name: string;
  /**
   * The address a customer reaches this listener at: its Public IP (`srv.public.host`), else its own
   * `srv.host` when that is a real address, otherwise the panel's FIREFLO_PUBLIC_HOST. Null when none
   * says.
   */
  host: string | null;
  /** Where {@link host} came from, for the dialog to say. */
  hostSource: "public" | "listener" | "panel" | null;
  /** Plain SMPP port. Null when the listener only takes TLS. */
  port: number | null;
  /** SMPP over TLS, when the listener has it switched on. */
  tlsPort: number | null;
  /** Messages per second this account may submit on it. 0 or null is unlimited and not mentioned. */
  maxRate: number | null;
  /** Binds this login may hold at once. 0 is unlimited. */
  maxBinds: number | null;
  /** Submits the customer may have awaiting a response. */
  maxPending: number | null;
}

export interface InstructionInput {
  accountLabel: string;
  type: "SMPP" | "HTTP";
  /** What the customer authenticates as: the system id, or for an HTTP login with a key, the key. */
  username: string;
  /** The real password, {@link MASKED_PASSWORD}, or null to leave it out. */
  password: string | null;
  /** True when the login has a password at all, so a left-out one can be explained. */
  hasPassword: boolean;
  allowedIps: string[];
  product: string | null;
  /** Public host customers connect to. */
  host: string;
  /** SMPP only: the listeners chosen in the dialog, in the order shown. */
  servers: InstructionServer[];
  /** HTTP only: the REST base URL, without a trailing slash. */
  restUrl: string;
  /** Free text from the operator, placed above the details. */
  note: string;
}

export interface InstructionMail {
  subject: string;
  text: string;
}

/** Why the mail cannot be composed yet, as a sentence for the dialog. Null when it can. */
export function instructionProblem(input: InstructionInput): string | null {
  if (input.type === "SMPP") {
    if (!input.host.trim()) {
      return "Enter the address customers connect to.";
    }
    if (input.servers.length === 0) {
      return "Choose at least one server.";
    }
  } else if (!/^https?:\/\/\S+$/i.test(input.restUrl.trim())) {
    return "Enter the API address, starting with http:// or https://.";
  }
  return null;
}

export function composeInstructions(input: InstructionInput): InstructionMail {
  const lines: string[] = [];
  const note = input.note.trim();

  lines.push("Hello,", "");
  if (note) {
    lines.push(note, "");
  }
  lines.push(
    input.type === "SMPP"
      ? `Here are the SMPP connection details for ${input.accountLabel}.`
      : `Here are the HTTP API connection details for ${input.accountLabel}.`,
    ""
  );

  if (input.type === "SMPP") {
    lines.push(...smppSection(input));
  } else {
    lines.push(...httpSection(input));
  }

  lines.push("", "Access", "------");
  lines.push(
    input.allowedIps.length
      ? `Connections are accepted only from: ${input.allowedIps.join(", ")}`
      : "Connections are accepted from any IP address."
  );
  lines.push(
    input.allowedIps.length
      ? "Tell us before you connect from another address, or the connection will be refused."
      : "Tell us which addresses you send from, and we can restrict this login to them."
  );

  if (input.password === null && input.hasPassword) {
    lines.push("", "Your password will be sent to you separately.");
  }
  lines.push(
    "",
    "Keep these details private. Anyone holding them can send messages that are billed to you.",
    "",
    "Reply to this mail if anything does not connect."
  );

  const what = input.type === "SMPP" ? "SMPP" : "HTTP API";
  return { subject: `Your ${what} connection details: ${input.username}`, text: lines.join("\n") };
}

function smppSection(input: InstructionInput): string[] {
  const out = ["Login", "-----", `System ID:     ${input.username}`];
  if (input.password !== null) {
    out.push(`Password:      ${input.password}`);
  }
  out.push("Bind as:       transceiver, transmitter or receiver");

  const many = input.servers.length > 1;
  out.push("", many ? "Servers" : "Server", many ? "-------" : "------");
  if (many) {
    out.push("Bind to any of these. Spreading binds across them keeps you sending if one is down.");
  }
  input.servers.forEach((s, i) => {
    if (many) {
      out.push("", `Server ${i + 1}`);
    }
    out.push(`Host:          ${input.host.trim()}`);
    if (s.port) {
      out.push(`Port:          ${s.port}`);
    }
    if (s.tlsPort) {
      out.push(`TLS port:      ${s.tlsPort}${s.port ? " (SMPP over TLS)" : ""}`);
    }
    const limits = [
      limit(s.maxBinds, "binds at once"),
      limit(s.maxRate, "messages per second"),
      s.maxPending ? `window ${s.maxPending}` : null,
    ].filter(Boolean);
    if (limits.length) {
      out.push(`Limits:        ${limits.join(", ")}`);
    }
  });
  return out;
}

function httpSection(input: InstructionInput): string[] {
  const base = input.restUrl.trim().replace(/\/+$/, "");
  const out = [
    "Login",
    "-----",
    `Username:      ${input.username}`,
  ];
  if (input.password !== null) {
    out.push(`Password:      ${input.password}`);
  }
  out.push(
    "Auth:          HTTP Basic",
    "",
    "Endpoints",
    "---------",
    `One message:   POST ${base}/secure/send`,
    `Many messages: POST ${base}/secure/sendbatch`,
    `Balance:       GET  ${base}/secure/balance`,
    "",
    "Example",
    "-------",
    `curl -u '${input.username}:${input.password ?? "<password>"}' \\`,
    "  -H 'Content-Type: application/json' \\",
    `  -d '{"to":"61400000000","from":"Sender","content":"Hello"}' \\`,
    `  ${base}/secure/send`
  );
  if (input.product) {
    out.push("", `Your messages are sent as product ${input.product}.`);
  }
  return out;
}

/** Only a real ceiling is worth a line: 0 means unlimited, and "no limit" reads as an invitation. */
function limit(value: number | null, unit: string): string | null {
  return value ? `up to ${value} ${unit}` : null;
}
