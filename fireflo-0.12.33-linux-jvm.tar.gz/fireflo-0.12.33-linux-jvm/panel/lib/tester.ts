/**
 * The message tester: shapes of the gateway's answers, and the hand-off to an editor when a test
 * finds nothing to match.
 *
 * <p>No database import and no React, so the rules for what is suggested can be tested on their own.
 */

import type { ConditionInput } from "./rate-types.ts";
import type { ProductFrom } from "./routing-types.ts";

/**
 * The product the gateway tested the message with, and where it came from.
 *
 * <p>A real message carries the login's product (or the bind's `system_type`) whether or not anyone
 * typed one, so the gateway fills a blank Product box from the account's logins. Every tester
 * endpoint reports the same three facts; older gateways report none, and the panel then says nothing.
 */
export interface ProductUsed {
  product?: string | null;
  product_from?: ProductFrom;
  login_products?: string[];
  /** The account's logins that carry no product (gateway 0.12.14 and later). */
  logins_without_product?: string[];
}

/** One price or cost rule as `/ops/rating/explain` reports it. Amounts are decimal strings. */
export interface RatedRule {
  rule_id: number;
  scope: string;
  /** The account had no rule of its own and Default answered. */
  fallback: boolean;
  product: string | null;
  seq: number;
  conditions: string[];
  rate: string;
  currency: string | null;
  total: string;
}

export interface RatingAnswer extends ProductUsed {
  /** False when the gateway has no rates loaded at all. */
  active: boolean;
  parts: number;
  /** The products that rules on this account or on Everyone are restricted to. */
  products_with_rules?: string[];
  price: RatedRule | null;
  vendor: string | null;
  cost: RatedRule | null;
  margin?: string;
  margin_pct?: string | null;
}

export interface FilterOutcome {
  name: string;
  enabled: boolean;
  conditions: string[];
  matched: boolean;
  mismatch: string | null;
  used_by: string[];
}

export type TesterTab = "routing" | "pricing" | "filters";

/** What a test is run with. Kept in the address so a link reopens the same test. */
export interface TesterInput {
  account: string;
  to: string;
  from: string;
  product: string;
  ingateway: string;
  type: string;
  content: string;
}

export const BLANK_INPUT: TesterInput = { account: "", to: "", from: "", product: "", ingateway: "", type: "", content: "" };

/**
 * One line saying which product the test ran as, shown over every tab once a result is in. Null
 * when the gateway did not say (an older one) or nothing was tested.
 */
export function productUsedText(used: ProductUsed | null | undefined, account: string): string | null {
  if (!used?.product_from) return null;
  const who = account.trim() || "the account";
  switch (used.product_from) {
    case "typed": return `Tested as product '${used.product}', as typed.`;
    case "login": return `Tested as product '${used.product}', from ${who}'s login — what its messages carry.`;
    case "ambiguous": return `${who}'s logins carry several products (${(used.login_products ?? []).join(", ")}); tested with none. Choose one in Product.`;
    default: return account.trim() ? `Tested with no product: ${who}'s logins carry none.` : "Tested with no product.";
  }
}

/**
 * The logins this answer does NOT describe: the account's logins that carry no product. Their
 * messages have none and meet only any-product rules, so a product-specific price shown above does
 * not apply to their traffic — the split behind "the tester prices it, the messages come out blank".
 * Null when there is nothing to say, or the gateway is too old to say it.
 */
export function bareLoginsText(used: ProductUsed | null | undefined, account: string): string | null {
  const bare = used?.logins_without_product ?? [];
  if (!bare.length || !used?.product) return null;
  const who = account.trim() || "the account";
  const list = bare.join(", ");
  return `${bare.length === 1 ? "Login" : "Logins"} ${list} on ${who} ${bare.length === 1 ? "carries" : "carry"} no product, so `
    + `${bare.length === 1 ? "its" : "their"} messages meet only any-product rules and this price does not apply to them. `
    + "Set the product under Accounts → Logins; an SMPP client already bound picks it up on gateways from 0.12.14, older ones after it rebinds.";
}

/**
 * Why there is no price, in the order that matters: a choice to make, then rules that exist but
 * are for another product (the "everything else on test-pro" trap), then no rule at all.
 */
export function missingPriceText(answer: RatingAnswer, account: string): string {
  const who = account.trim();
  if (!who) {
    return answer.active
      ? "Everyone has no default rule for it, so an account without pricing of its own sends it unrated. Enter an account to see its own price."
      : "Choose an account to see its price.";
  }
  if (answer.product_from === "ambiguous") {
    return `${who}'s logins carry several products (${(answer.login_products ?? []).join(", ")}). Choose one in Product to see its price.`;
  }
  const withRules = (answer.products_with_rules ?? []).filter((p) => p !== answer.product);
  if (withRules.length) {
    const carried = answer.product ? `product '${answer.product}'` : "no product";
    return `No rule prices a message with ${carried} for ${who}, but rules exist for ${withRules.map((p) => `'${p}'`).join(", ")}. `
      + `A rule saved under a product only prices messages carrying it: set the product on ${who}'s login under Accounts, `
      + "or have the customer bind with that system_type.";
  }
  return `Neither ${who}'s own pricing nor Everyone has a rule for it. It is sent unrated.`;
}

/**
 * The prefix a "create one" suggestion starts from: the country code as typed, with its '+' if it
 * had one -- `+447700900123` gives `+44`, `919812345678` gives `91`. A guess for a person to
 * correct in the editor, never saved without them.
 */
export function suggestPrefix(number: string): string {
  const trimmed = number.trim();
  const plus = trimmed.startsWith("+") ? "+" : "";
  const digits = trimmed.replace(/^\+/, "").replace(/^00/, "");
  if (!digits) return "";
  //one-digit country codes (1, 7) are common enough that two digits would be wrong for them
  const width = digits.startsWith("1") || digits.startsWith("7") ? 1 : 2;
  return plus + digits.slice(0, width);
}

/** The one condition an editor opens pre-filled with, as address parameters. */
export function prefillParams(condition: ConditionInput, extra: Record<string, string> = {}): string {
  const params = new URLSearchParams({ new: "1", ...extra });
  params.set("wf", condition.field);
  params.set("wo", condition.operator);
  params.set("wv", condition.value);
  return params.toString();
}

/** The condition back out of the address, or null when there is none to open with. */
export function prefillFrom(params: { get(name: string): string | null }): ConditionInput | null {
  const field = params.get("wf");
  const operator = params.get("wo");
  const value = params.get("wv");
  if (!field || !operator || value === null) return null;
  return { field, operator, value, negate: false };
}

/** The destination condition a suggestion writes for a number. */
export function destinationCondition(number: string): ConditionInput {
  return { field: "to", operator: "startsWith", value: suggestPrefix(number), negate: false };
}

/**
 * Where a routing explanation leads next: a target that names a routing table is followed (the
 * real router continues there); anything else is where the message ends up.
 */
export function nextTable(target: string | null | undefined, tables: readonly string[]): string | null {
  return target && tables.includes(target) ? target : null;
}

/**
 * The vendor a final target names, for costing. Rules name a vendor by its short name
 * (`smppsim`) or its full one (`smppclient.smppsim`); a preprocessor (`@dnd`) or a listener
 * (`smppserver.x`, a receipt going back to a customer) is not one. The gateway resolves either
 * spelling to the scope its costs are kept under.
 */
export function vendorOf(target: string | null | undefined, tables: readonly string[] = []): string | null {
  if (!target || target.startsWith("@") || target.startsWith("smppserver.") || tables.includes(target)) return null;
  return target;
}

/**
 * The rule that decides where a message goes, by the router's own rule: the first matching rule,
 * except that a preprocessor rule (`@name`) never delivers and never stops the scan -- the message
 * comes back and carries on below it. Null when nothing past the preprocessors matches.
 */
export function deciding<R extends { matched: boolean; evaluable: boolean; target: string }>(rules: readonly R[]): R | null {
  return rules.find((r) => r.evaluable && r.matched && !r.target.startsWith("@")) ?? null;
}


/**
 * The table a filter's "used by" line names -- `routing: sample · rule 1014` gives `sample` -- when
 * that table is one nothing routes to, so the tester can say the rule never runs. Null for a price
 * line, or a table a message can reach.
 */
export function neverRunsIn(usedBy: string, unreached: readonly string[]): string | null {
  const table = /^routing: (.+?) · /.exec(usedBy)?.[1];
  return table && unreached.includes(table) ? table : null;
}
