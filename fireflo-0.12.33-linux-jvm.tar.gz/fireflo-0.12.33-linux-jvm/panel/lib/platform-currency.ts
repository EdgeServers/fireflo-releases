import { configQuery } from "@/lib/config-db";
import { chooseCurrency, type InheritedCurrency } from "@/lib/balance-types";

/** The property the gateway reads. There is exactly one, and it is not per account. */
export const CURRENCY_KEY = "smsg.rates.currency";

/**
 * The one currency this platform has.
 *
 * <p>FireFlo never converts. `smsg.rates.currency` is stamped onto every rated message, and the
 * per-rule `currency` column is an override that `ConfigImportWriter` deliberately writes as NULL
 * so that changing the global still applies. So a currency typed into a form somewhere else is not
 * a second currency — it is a chance to disagree with the only one that counts, on a row nothing
 * reconciles.
 *
 * <p>Returns null when it cannot be read, which is not the same as "no currency": in file mode the
 * value lives in `smsg.properties`, which this panel does not read at all. Callers must tell the
 * two apart rather than presenting an empty string as the answer.
 */
export async function platformCurrency(): Promise<string | null> {
  const rows = await configQuery<{ value: string | null }>(
    `SELECT value FROM app_config WHERE key = $1 AND enabled`,
    [CURRENCY_KEY]
  );
  const value = rows[0]?.value?.trim();
  return value ? value.toUpperCase() : null;
}

/**
 * What a balance about to be opened for this account should be denominated in.
 *
 * <p>The gateway's `smsg.rates.currency` first; failing that, the currency already on the **parent
 * account's** balance. The rule and the reasoning are in `chooseCurrency` — this is the two lookups
 * it decides between, kept here because they need `pg` and it does not.
 *
 * <p><strong>The parent query runs only when the gateway gave nothing</strong>, which on a
 * database-mode deployment is never. So the ordinary case is one query, unchanged from before this
 * existed.
 *
 * <p>Only the *parent's* balance is consulted, never a sibling's and never the account's own: an
 * account with its own balance row has nothing left to open, and a sibling's code is a fact about a
 * different account that happens to be nearby.
 */
export async function currencyForNewBalance(accountId: string): Promise<InheritedCurrency> {
  const gateway = await platformCurrency();
  if (gateway) {
    return chooseCurrency(gateway, null);
  }

  const id = (accountId ?? "").trim();
  if (!id) {
    return chooseCurrency(null, null);
  }
  //one join from the account to its parent's balance. An account with no parent, a parent with no
  //balance row, and a balance row with no currency all fall out as no row here -- which is the same
  //answer, and correctly so: none of them is evidence of anything
  const rows = await configQuery<{ currency: string | null }>(
    `SELECT b.currency
       FROM app_account a
       JOIN account_balance b ON b.account_id = a.parent_account_id
      WHERE a.id = $1 AND a.parent_account_id IS NOT NULL`,
    [id]
  );
  return chooseCurrency(null, rows[0]?.currency);
}

/** The key both the gateway's rollup and this panel cut billing days on. */
export const BILLING_ZONE_KEY = "smsg.billing.zone";

/**
 * The time zone a billing day starts in.
 *
 * <p><strong>Read from `app_config`, not from an environment variable, because two readers need the
 * same answer.</strong> `UsageCommand` slices `usage_daily` on this zone and the reconciliation
 * slices the live tail on it; if they disagree, a sliver of one day is counted twice or not at all
 * and the discrepancy is exactly as large as the traffic in that sliver. An env var on the gateway
 * host is invisible to this panel, so it could not be that.
 *
 * <p>UTC when unset, matching the gateway's own fallback. A deployment that never sets it is
 * consistent, which is what matters — the wrong zone consistently applied is a reporting choice,
 * whereas two different zones is a bug.
 *
 * <p><strong>Held for {@link ZONE_TTL_MS}</strong>, the same way `config-key-registry-db.ts` holds
 * the key registry. Every windowed aggregate asks for the zone, and the home page used to ask three
 * times per poll per open tab for a value that changes when an operator reconfigures the platform,
 * not between two polls. A failed read is not cached: the UTC fallback is for one answer, and the
 * next caller asks again rather than cutting days in the wrong zone for half a minute.
 */
export async function billingZone(): Promise<string> {
  if (zoneCache && Date.now() - zoneCache.at < ZONE_TTL_MS) {
    return zoneCache.zone;
  }
  try {
    const rows = await configQuery<{ value: string | null }>(
      "SELECT value FROM app_config WHERE key = $1",
      [BILLING_ZONE_KEY]
    );
    const set = rows[0]?.value?.trim();
    const zone = set ? set : "UTC";
    zoneCache = { at: Date.now(), zone };
    return zone;
  } catch {
    //a diagnostic must not fail because a configuration row could not be read
    return "UTC";
  }
}

const ZONE_TTL_MS = 30_000;
let zoneCache: { at: number; zone: string } | null = null;

/** For tests, and for nothing else. */
export function resetBillingZoneCache(): void {
  zoneCache = null;
}
