import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { isSealed, open, openOrExplain, seal, sealingEnabled, SealedWithoutKey } from "./secret-box.ts";

/**
 * The panel's half of a contract with the gateway's `SecretBox`: same format, same key derivation,
 * so a password either side seals the other opens. The vector below is checked by the gateway's
 * `SecretBoxTest` too.
 */

const SEALED_WITH_TEST_KEY = "enc:v1:SP5gqmEXb6Io57YQyxbnaPYhEiRUWE1z_5Cjf9yRL3eP";

beforeEach(() => {
  delete process.env.FIREFLO_SECRETS_KEY;
  delete process.env.FIREFLO_SECRETS_KEY_NEXT;
});

test("the shared vector opens with the shared key", () => {
  process.env.FIREFLO_SECRETS_KEY = "test-key";
  assert.equal(open(SEALED_WITH_TEST_KEY), "hello");
});

test("seals with a fresh nonce each time and opens both", () => {
  process.env.FIREFLO_SECRETS_KEY = "test-key";
  assert.ok(sealingEnabled());
  const once = seal("s3cret")!;
  const twice = seal("s3cret")!;
  assert.ok(isSealed(once));
  assert.notEqual(once, twice);
  assert.equal(open(once), "s3cret");
  assert.equal(open(twice), "s3cret");
  assert.equal(seal(once), once, "a sealed value is not sealed twice");
});

test("32 bytes of base64 are the key as given; anything else is hashed", () => {
  process.env.FIREFLO_SECRETS_KEY = "dGVzdC1rZXktMzItYnl0ZXMtbG9uZy1leGFjdGx5ISE=";
  const byRaw = seal("x")!;
  process.env.FIREFLO_SECRETS_KEY = "a passphrase an operator typed";
  const byPassphrase = seal("x")!;
  assert.equal(open(byPassphrase), "x");
  assert.throws(() => open(byRaw), SealedWithoutKey);
});

test("with no key nothing is sealed and a sealed value is refused by name, never by value", () => {
  assert.equal(sealingEnabled(), false);
  assert.equal(seal("plain"), "plain");
  assert.equal(seal(null), null);
  assert.throws(() => open(SEALED_WITH_TEST_KEY), (err: unknown) =>
    err instanceof SealedWithoutKey && /FIREFLO_SECRETS_KEY/.test(err.message) && !/hello/.test(err.message));
  const explained = openOrExplain(SEALED_WITH_TEST_KEY);
  assert.equal(explained.value, null);
  assert.match(explained.problem ?? "", /cannot be read/);
});

test("a rotation: the next key opens, only the current one seals", () => {
  process.env.FIREFLO_SECRETS_KEY = "old-key";
  const sealedByOld = seal("pw")!;
  process.env.FIREFLO_SECRETS_KEY = "new-key";
  process.env.FIREFLO_SECRETS_KEY_NEXT = "old-key";
  assert.equal(open(sealedByOld), "pw");
  const sealedNow = seal("pw")!;
  delete process.env.FIREFLO_SECRETS_KEY_NEXT;
  assert.equal(open(sealedNow), "pw");
  assert.throws(() => open(sealedByOld), SealedWithoutKey);
});

test("a value that is not sealed passes through", () => {
  process.env.FIREFLO_SECRETS_KEY = "test-key";
  assert.equal(open("plain"), "plain");
  assert.equal(open(null), null);
  assert.equal(openOrExplain("plain").value, "plain");
});
