import nodemailer from "nodemailer";
//nodemailer 10 is a TypeScript rewrite that ships its own declarations, and its default export is a
//value rather than a namespace -- `nodemailer.Transporter` no longer resolves as a type. The type
//is a named export from the package root instead. @types/nodemailer is gone from devDependencies
//for the same reason: DefinitelyTyped stops at 8.x, and leaving it installed shadows the real ones
import type { Transporter } from "nodemailer";

/**
 * Outbound email: sign-in links, and the connection details a login is sent to its customer.
 *
 * <p>Server-only. One transport, created once and reused — nodemailer pools connections and
 * building a transport per message reconnects to the SMTP server on every request.
 *
 * <p><strong>Unconfigured means unavailable, not "silently drop".</strong> If the SMTP settings are
 * missing, {@link sendLoginLink} throws rather than returning quietly, so the operator sees a
 * failure in the log instead of customers reporting that the link never arrives. The public route
 * still answers the caller identically — see the note there about enumeration — but the truth is on
 * the server where somebody can act on it.
 */

let cached: Transporter | null = null;

export function mailerConfigured(): boolean {
  return !!process.env.FIREFLO_SMTP_HOST && !!process.env.FIREFLO_SMTP_FROM;
}

function transport(): Transporter {
  if (cached) {
    return cached;
  }
  const host = process.env.FIREFLO_SMTP_HOST;
  const from = process.env.FIREFLO_SMTP_FROM;
  if (!host || !from) {
    throw new Error(
      "FIREFLO_SMTP_HOST and FIREFLO_SMTP_FROM are not set, so no mail can be sent."
    );
  }
  const port = Number(process.env.FIREFLO_SMTP_PORT ?? 587);
  const user = process.env.FIREFLO_SMTP_USER;
  const pass = process.env.FIREFLO_SMTP_PASSWORD;

  const secure = wantsImplicitTls(port);

  cached = nodemailer.createTransport({
    host,
    port,
    //implicit TLS on 465, STARTTLS above it
    secure,
    //without this, nodemailer will happily fall back to an unencrypted session when the relay does
    //not advertise STARTTLS. The body of this mail is a sign-in link, which IS the credential -- a
    //silent downgrade hands it to anybody on the path. Failing to send is the better outcome, and
    //the failure says so in the log
    requireTLS: !secure,
    auth: user && pass ? { user, pass } : undefined,
  });
  return cached;
}

/**
 * Whether to open the connection with implicit TLS.
 *
 * <p>Parsed rather than compared against the literal `"true"`, because the previous form made the
 * setting actively dangerous: the ternary tested for *presence*, so `FIREFLO_SMTP_SECURE=1` on port
 * 465 evaluated to `false` and **overrode** the port inference — turning an implicit-TLS relay into
 * a plaintext one by writing what looks like an affirmative value. Anything unrecognised now falls
 * back to the port rather than to plaintext, and says so.
 */
function wantsImplicitTls(port: number): boolean {
  const raw = process.env.FIREFLO_SMTP_SECURE?.trim().toLowerCase();
  if (!raw) {
    return port === 465;
  }
  if (["true", "1", "yes", "on"].includes(raw)) {
    return true;
  }
  if (["false", "0", "no", "off"].includes(raw)) {
    return false;
  }
  console.error(
    `FIREFLO_SMTP_SECURE is "${raw}", which is not a yes or a no. Falling back to the port: `
      + `${port === 465 ? "implicit TLS" : "STARTTLS"}. Set it to true or false.`
  );
  return port === 465;
}

/**
 * What actually went wrong, in the fields an operator can act on.
 *
 * <p>A failed send used to reach the log as one opaque sentence plus a stack trace, which answers
 * "did it fail" and not "why". Nodemailer puts the useful part on the error object rather than in
 * its message: `code` says whether the socket, the greeting or the login failed, `responseCode` and
 * `response` carry what the relay actually said, and `command` says at which point in the
 * conversation. `EAUTH` with `535` is a wrong password; `ECONNREFUSED` is the wrong host or port;
 * `ESOCKET` after `STARTTLS` is a relay that will not do TLS on a connection we require it on.
 *
 * <p>Bounded and shallow on purpose. This lands in a database column and in the journal, so it
 * takes named fields rather than the whole error, and truncates the relay's response — an SMTP
 * server that answers with a wall of text should not be able to fill the log through us.
 *
 * <p>The SMTP password is never among these fields. Nodemailer does not put credentials on the
 * error, and nothing here reads the environment.
 */
export function describeMailError(err: unknown): Record<string, string> {
  if (!(err instanceof Error)) {
    return { message: String(err).slice(0, 300) };
  }
  const e = err as Error & {
    code?: unknown;
    command?: unknown;
    responseCode?: unknown;
    response?: unknown;
  };
  const out: Record<string, string> = { message: e.message.slice(0, 300) };
  for (const [key, value] of [
    ["code", e.code],
    ["command", e.command],
    ["responseCode", e.responseCode],
    ["response", e.response],
  ] as const) {
    if (value !== undefined && value !== null && value !== "") {
      out[key] = String(value).slice(0, 300);
    }
  }
  return out;
}

/**
 * Sends one sign-in link.
 *
 * <p>The link is the whole credential, so the body says so and says how long it lasts. No branding,
 * no tracking pixel, nothing that would make a mail client rewrite the URL — a rewritten link is a
 * link somebody else fetched, and fetching it spends it.
 */
export async function sendLoginLink(to: string, url: string, accountLabel: string): Promise<void> {
  const from = process.env.FIREFLO_SMTP_FROM!;
  await transport().sendMail({
    from,
    to,
    subject: "Your sign-in link",
    text: [
      `Here is your sign-in link for ${accountLabel}:`,
      "",
      url,
      "",
      "It works once and expires in 15 minutes.",
      "If you did not ask for it, you can ignore this — it was not used.",
    ].join("\n"),
  });
}

/**
 * Sends a login's connection details, composed by `lib/connection-instructions.ts`.
 *
 * <p>Plain text, like the sign-in link, and for the same reason: an HTML part invites a mail client
 * to rewrite what is in it, and a host, port or password that arrives altered is worse than one that
 * arrives plain. `requireTLS` on the transport matters more here than anywhere -- this body can be a
 * bind password.
 *
 * @param replyTo the operator who sent it, so the customer's "it does not connect" reaches a person
 */
export async function sendConnectionInstructions(
  to: string[],
  subject: string,
  text: string,
  replyTo?: string
): Promise<void> {
  const from = process.env.FIREFLO_SMTP_FROM!;
  await transport().sendMail({ from, to, subject, text, replyTo: replyTo || undefined });
}
