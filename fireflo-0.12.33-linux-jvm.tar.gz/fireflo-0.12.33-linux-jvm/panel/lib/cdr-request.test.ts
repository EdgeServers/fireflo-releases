import { test } from "node:test";
import assert from "node:assert/strict";
import { EMPTY_FILTERS, MAX_TEXT_FILTER, cursorFromQuery, escapeLike, isFilterError, listHref, messageIdClause, parseFilters, restoreHistory, fromQuery, toQuery } from "./cdr-request.ts";
import { MAX_RANGE_DAYS } from "./date-range.ts";

/**
 * The filters on the wire, for the two surfaces that share this parser.
 *
 * <p>Both the operator page and the customer portal reach `parseFilters` with a query string the
 * browser did not have to have produced. The portal is the one that matters: it parses a
 * session-holder's parameters before the route narrows them to that session's accounts, so anything
 * unbounded here is unbounded for a customer.
 */

test("the message-text box lands on the body column, not on a parameter of its own", () => {
  const filters = parseFilters(new URLSearchParams("text=verification code"));
  assert.ok(!isFilterError(filters));
  //"text" is what a reader searching message content would call it; `body` is the schema's word.
  //If these ever drift apart the box silently filters nothing, which reads as "no such message"
  assert.equal(filters.body, "verification code");
});

test("a phrase longer than any body the gateway records is refused rather than run", () => {
  const params = new URLSearchParams();
  params.set("text", "x".repeat(MAX_TEXT_FILTER + 1));

  const filters = parseFilters(params);
  assert.ok(isFilterError(filters), "an over-long phrase should not reach the database");
  assert.match(filters.error, /longer than 1600 characters/);
});

test("a phrase exactly as long as the longest possible body is allowed", () => {
  //the boundary is inclusive on purpose: 1,600 characters is a real concatenated multipart message,
  //so somebody pasting one back in to find it is doing the obvious thing, not attacking anything
  const phrase = "x".repeat(MAX_TEXT_FILTER);
  const filters = parseFilters(new URLSearchParams([["text", phrase]]));
  assert.ok(!isFilterError(filters));
  assert.equal(filters.body, phrase);
});

test("the bound covers every text filter, not only the substring one", () => {
  //`text` is the only ILIKE, but an identifier field is still a string sent to the database, and a
  //ceiling that only guards the field somebody remembered is the kind that stops guarding
  const params = new URLSearchParams();
  params.set("dest", "9".repeat(MAX_TEXT_FILTER + 1));

  const filters = parseFilters(params);
  assert.ok(isFilterError(filters));
  assert.match(filters.error, /'dest'/);
});

test("whitespace around a phrase is not what makes it too long", () => {
  //the length test runs on the trimmed value, so a pasted phrase with a trailing newline is not
  //refused for a character the searcher cannot see and did not intend to type
  const params = new URLSearchParams();
  params.set("text", `  ${"x".repeat(MAX_TEXT_FILTER)}  `);

  const filters = parseFilters(params);
  assert.ok(!isFilterError(filters), "trimming happens before the ceiling is applied");
});

const NOW = new Date("2026-10-15T12:00:00.000Z");

function daysAgo(days: number): string {
  return new Date(NOW.getTime() - days * 86_400_000).toISOString();
}

test("a text search over all time is refused, in a sentence the page can show", () => {
  //`range=all` drops the lower bound, and `body ILIKE '%x%'` without one is a scan of every message
  //ever sent -- a bitmap-and-recheck with the trigram index, the whole heap without it. The export
  //shares this parser, so the same request cannot be queued as a CSV either
  const value = parseFilters(new URLSearchParams("range=all&text=verification"), NOW);
  assert.ok(isFilterError(value), "an unbounded ILIKE should not reach the database");
  assert.equal(value.error, "Choose a period to search the message text.");
});

test("the prefix scans and the outcome need a period for the same reason", () => {
  for (const [query, sentence] of [
    ["range=all&dest=6141", "Choose a period to search by destination number."],
    ["range=all&source=ACME", "Choose a period to search by source number."],
    ["range=all&outcome=FAILED", "Choose a period to filter by outcome."],
  ]) {
    const value = parseFilters(new URLSearchParams(query), NOW);
    assert.ok(isFilterError(value), `${query} should be refused`);
    assert.equal(value.error, sentence);
  }
});

test("the same text search with a period is allowed", () => {
  const filters = parseFilters(new URLSearchParams("range=24h&text=verification"), NOW);
  assert.ok(!isFilterError(filters));
  assert.equal(filters.body, "verification");
  assert.ok(filters.since, "and it carries the bound that makes it safe");
});

test("wildcards in a phrase are text, not syntax", () => {
  //what the query layer wraps in %...% before binding. A phrase like "100% off" or "my_code" must
  //match rows containing exactly that; unescaped, % matches anything and _ any one character
  assert.equal(escapeLike("100% off"), "100\\% off");
  assert.equal(escapeLike("my_code"), "my\\_code");
  assert.equal(escapeLike("back\\slash"), "back\\\\slash");
  assert.equal(escapeLike("plain words"), "plain words");
});

test("identifier filters over all time stay allowed: the e2e suite pages through exactly that", () => {
  //account, product, vendor and system id are equality matches an index serves from the newest
  //row; US-21.08 opens /cp/cdrs?range=all&account=... and walks its pages. Only the scans are refused
  const filters = parseFilters(
    new URLSearchParams("range=all&account=acct-1&product=p&vendor=v&systemId=s&msgId=gw-1"),
    NOW
  );
  assert.ok(!isFilterError(filters), `expected filters, got ${JSON.stringify(filters)}`);
  assert.equal(filters.since, undefined);
  assert.equal(filters.accountId, "acct-1");
  assert.equal(filters.gatewayMsgId, "gw-1");
});

test("the ingress server travels as 'server' and lands on in_gateway, exact", () => {
  const filters = parseFilters(new URLSearchParams("range=24h&server=smppserver.smpp&vendor=smppclient.v1"), NOW);
  assert.ok(!isFilterError(filters));
  assert.equal(filters.inGateway, "smppserver.smpp");
  assert.equal(filters.vendor, "smppclient.v1");
  const form = fromQuery(new URLSearchParams("server=smppserver.smpp"));
  assert.equal(form.server, "smppserver.smpp");
  assert.equal(toQuery(form).get("server"), "smppserver.smpp");
});

test("a typed window wider than the export limit is refused on the list too", () => {
  //the browser is not what enforces it: this is a plain GET anybody with a session can edit, and a
  //two-year window is `range=all` with a different spelling. Measured to now when there is no To
  const tooWide = parseFilters(
    new URLSearchParams(`range=all&since=${daysAgo(MAX_RANGE_DAYS + 1)}`),
    NOW
  );
  assert.ok(isFilterError(tooWide));
  assert.equal(tooWide.error, `That is ${MAX_RANGE_DAYS + 1} days. Ask for at most ${MAX_RANGE_DAYS} at a time.`);

  const bothEnds = parseFilters(
    new URLSearchParams(`range=all&since=${daysAgo(200)}&until=${daysAgo(10)}`),
    NOW
  );
  assert.ok(isFilterError(bothEnds));
  assert.match(bothEnds.error, /That is 190 days/);

  //the limit itself is allowed, and so is every shortcut the dropdown offers
  const atLimit = parseFilters(new URLSearchParams(`range=all&since=${daysAgo(MAX_RANGE_DAYS)}`), NOW);
  assert.ok(!isFilterError(atLimit));
  assert.ok(!isFilterError(parseFilters(new URLSearchParams("range=30d&text=code"), NOW)));
});

test("a message id matches its own row and any segment it was assembled from", () => {
  //the customer holds one id per submit_sm they sent, and quotes whichever is on the receipt they
  //are chasing. Only the first is gateway_msg_id; before the segment list, the rest found nothing
  const clause = messageIdClause("$3", true);

  assert.match(clause, /s\.gateway_msg_id = \$3/, "the message's own id still matches");
  assert.match(clause, /s\.reassembled_parts @> ARRAY\[\$3\]/, "and so does a segment's");
});

test("the id clause is bracketed, so an OR cannot escape the account scope", () => {
  //THE ONE THAT MATTERS. Callers AND these fragments together and one of them is the portal's
  //`account_id = ANY(...)`. Unbracketed, `A AND B OR C` binds as `(A AND B) OR C`, and C on its own
  //returns any message on the platform whose segment list holds an id the caller guessed -- a
  //cross-customer read reachable from the customer portal's own message-id box.
  const clause = messageIdClause("$1", true);

  assert.ok(clause.startsWith("("), "an unbracketed OR here is a data leak, not a formatting nit");
  assert.ok(clause.endsWith(")"));
});

test("against a gateway without the column, the clause names only what exists", () => {
  //naming reassembled_parts before V1.34.0 is a hard error, and it would take out id search
  //altogether rather than costing the extra half of it
  const clause = messageIdClause("$2", false);

  assert.equal(clause, "s.gateway_msg_id = $2");
  assert.ok(!clause.includes("reassembled_parts"));
});

test("the clause carries a placeholder, never a value", () => {
  //the query layer's standing promise: no caller string reaches the SQL text. An id is the most
  //tempting one to interpolate, because it looks like an opaque token rather than user input
  const clause = messageIdClause("$1", true);

  assert.ok(!clause.includes("'"), "no quoting means nothing was interpolated");
});

test("the list's address carries the filters and the current page, and reads them back", () => {
  const form = { ...EMPTY_FILTERS, account: "omni", product: "test-pro" };
  const cursor = { submittedAt: "2026-10-14T17:31:22.000Z", id: "42" };
  const href = listHref(form, cursor);
  assert.equal(href, "/cp/cdrs?account=omni&product=test-pro&cursorTs=2026-10-14T17%3A31%3A22.000Z&cursorId=42");
  const params = new URL(href, "http://x").searchParams;
  assert.deepEqual(cursorFromQuery(params), cursor);
  assert.equal(listHref(EMPTY_FILTERS, null), "/cp/cdrs", "nothing set, nothing in the address");
  assert.equal(cursorFromQuery(new URLSearchParams("cursorTs=only")), null, "half a cursor is no cursor");
});

test("the Previous stack comes back only for the same list, ending on this page", () => {
  const p2 = { submittedAt: "2026-10-14T17:31:22.000Z", id: "42" };
  const p3 = { submittedAt: "2026-10-14T17:00:00.000Z", id: "7" };
  const saved = JSON.stringify({ query: "account=omni", history: [null, p2, p3] });

  assert.deepEqual(restoreHistory(saved, "account=omni", { ...p3 }), [null, p2, p3], "back on page 3: Previous still reaches page 2");
  assert.deepEqual(restoreHistory(saved, "account=acme", p3), [null, p3], "another list: only page 1 is behind this page");
  assert.deepEqual(restoreHistory(saved, "account=omni", p2), [null, p2], "browser Back onto page 2: the stack is cut back to it");
  assert.deepEqual(restoreHistory(saved, "account=omni", null), [null], "page 1 has nothing behind it");
  assert.deepEqual(restoreHistory(saved, "account=omni", { submittedAt: "x", id: "9" }), [null, { submittedAt: "x", id: "9" }],
    "a page the stack never visited: only page 1 is behind it");
  assert.deepEqual(restoreHistory("{not json", "account=omni", p2), [null, p2]);
  assert.deepEqual(restoreHistory(null, "", null), [null]);
});
