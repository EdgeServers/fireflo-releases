import { NextResponse } from "next/server";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { isConfigured } from "@/lib/metrics-db";

/**
 * The `controlRoute` preamble, without the range.
 *
 * <p>`controlRoute` cannot be reused for the CDR routes: its handler signature is
 * `(range) => Promise<T>` and the request is never passed through, so there is no way to reach the
 * filters. Rather than copy the guard into each of the three routes that need it -- which is what
 * `workers/route.ts` did, and which is why the 404-not-403 reasoning now exists in two places --
 * the shared part lives here.
 *
 * @returns a response to send back, or null to carry on
 */
export async function guardCdrRoute(): Promise<NextResponse | null> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      //404, not 403: a 403 confirms there is something here to be forbidden from
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  if (!isConfigured()) {
    return NextResponse.json(
      { error: "METRICS_DATABASE_URL is not set; this panel has no data source." },
      { status: 503 }
    );
  }
  return null;
}

/** The message can name a missing table or a permission failure — an operator needs that, and no one else can reach it. */
export function queryFailed(context: string, err: unknown): NextResponse {
  console.error(`${context} failed`, err);
  return NextResponse.json(
    { error: err instanceof Error ? err.message : "Query failed" },
    { status: 500 }
  );
}
