/**
 * One line of an account's activity history, as the account page's Activity card shows it.
 *
 * <p>Merged from three places that each record a different kind of fact: the customer access log
 * (somebody signing in to the portal), the operator access log (somebody here changing the account
 * or its logins), and the balance ledger (money moving). None of them knew about the others, which
 * is why "what happened to this account" had no single answer.
 */
export type ActivityFilter = "all" | "signins" | "changes" | "money";

export interface ActivityItem {
  /** Unique within a page: which log, and that log's own id. */
  key: string;
  at: string;
  source: "customer" | "operator" | "ledger";
  event: string;
  /** Who: the address typed or signed in with, or the operator. Null for money and anonymous refusals. */
  actor: string | null;
  ip: string | null;
  detail: Record<string, unknown> | null;
  /** Ledger rows only: the scaled amount as a string, never a float. */
  delta: string | null;
  /** Ledger transfers only: the other account. */
  counterparty: string | null;
  /** Ledger rows only: the account the row is written against, which is the payer on a transfer. */
  ledgerAccount: string | null;
}

export interface ActivityPage {
  items: ActivityItem[];
  /** Pass as `before` for the next page; null when there is nothing older. */
  next: string | null;
  /** The account's balance currency, for the money lines; null when it has no balance row. */
  currency: string | null;
}
