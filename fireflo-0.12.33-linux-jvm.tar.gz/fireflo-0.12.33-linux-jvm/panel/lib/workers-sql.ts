import type { WorkerType } from "./worker-types";

/**
 * The two reads behind `listWorkers`, as text and parameters, with no database import so the shape
 * can be asserted in a unit test.
 *
 * <p>The point of the pair (CP-P8): the properties read used to fetch <b>every</b> worker's
 * settings whatever `type` was asked for, and filter in JavaScript by joining onto the worker list.
 * Most pages ask for one kind -- vendors, or listeners -- so the other kind's rows were read,
 * redacted and thrown away on every load. With `type` given, both statements carry the predicate
 * and the properties statement joins `app_worker` to apply it before a single property is read.
 */
export interface SqlStatement {
  text: string;
  values: string[];
}

export function workerRowsSql(type?: WorkerType): SqlStatement {
  return type
    ? { text: "SELECT name, type, enabled, label FROM app_worker WHERE type = $1 ORDER BY name", values: [type] }
    : { text: "SELECT name, type, enabled, label FROM app_worker ORDER BY name", values: [] };
}

export function workerPropertiesSql(type?: WorkerType): SqlStatement {
  return type
    ? {
        text: `SELECT p.worker_name, p.key, p.value
       FROM app_worker_property p
       JOIN app_worker w ON w.name = p.worker_name
      WHERE w.type = $1
      ORDER BY p.worker_name, p.key`,
        values: [type],
      }
    : {
        text: "SELECT worker_name, key, value FROM app_worker_property ORDER BY worker_name, key",
        values: [],
      };
}
