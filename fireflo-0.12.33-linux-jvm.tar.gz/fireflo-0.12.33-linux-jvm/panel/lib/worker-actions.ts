/**
 * The controls the gateway will act on immediately.
 *
 * <p>Kept free of any server import so both the proxy route and the client components can use it —
 * the list has to agree on both sides of the wire, and the gateway's own
 * {@code OpsWorkerActionService} is the third copy it must match.
 *
 * <p>Each writes one configuration property on the gateway, which then takes effect through the
 * listeners already watching it. They are not a separate control plane, just a way of not waiting
 * for the poll.
 */
export const WORKER_ACTIONS = [
  "enable",
  "disable",
  "suspend",
  "resume",
  "hold",
  "release",
  "restart",
] as const;

export type WorkerAction = (typeof WORKER_ACTIONS)[number];

/**
 * `suspend` — Stop sending. On a vendor: excluded from routing, its queue HELD until resume (not
 * drained anywhere; new traffic fails over). On a listener: inbound messages are accepted but
 * PARKED un-routed, while receipts keep flowing to bound customers.
 */
export const SUSPEND_ACTIONS = { on: "suspend", off: "resume" } as const;

/**
 * `pause` — Hold. On a listener: refuses every submit at the door (RMSGQFUL, pre-charge — clients
 * retry, so release resumes traffic) AND holds receipts in queue. Offered on listeners only; the
 * vendor card carries Restart instead.
 */
export const PAUSE_ACTIONS = { on: "hold", off: "release" } as const;

/** `restart` bounces a worker: disable-then-enable, sessions torn down and re-dialled. */
export const RESTART_ACTION = "restart" as const;

export const ENABLE_ACTIONS = { on: "enable", off: "disable" } as const;
