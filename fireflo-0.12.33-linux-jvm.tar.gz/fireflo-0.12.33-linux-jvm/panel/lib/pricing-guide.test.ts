import { test } from "node:test";
import assert from "node:assert/strict";
import { describePriceWhen, groupByProduct, isFallback, moveWithinProduct, priceChanged, scopeChangeCount } from "./pricing-guide.ts";
import { fromCsv } from "./pricing-csv.ts";
import type { RateRuleInput } from "./rate-types.ts";

const rule = (amount: string, patch: Partial<RateRuleInput> = {}): RateRuleInput => ({
  id: null, amount, product: null, currency: null, label: null, enabled: true, conditions: [], filters: [], ...patch,
});
const to91 = { field: "to", operator: "startsWith", value: "+91", negate: false };

test("a price reads as a sentence", () => {
  assert.equal(describePriceWhen(rule("1")), "Everything else");
  assert.equal(describePriceWhen(rule("1", { conditions: [to91] })), "When destination starts with +91");
  assert.equal(describePriceWhen(rule("1", { filters: ["in_txn"] })), "When filter in_txn matches");
  assert.ok(isFallback(rule("1")));
  assert.ok(!isFallback(rule("1", { filters: ["f"] })));
});

test("rules group by product, any product last, each flagged for a fallback", () => {
  const rules = [rule("1"), rule("2", { product: "txn", conditions: [to91] }), rule("3", { product: "txn" }), rule("4", { product: "promo", conditions: [to91] })];
  const groups = groupByProduct(rules);
  assert.deepEqual(groups.map((g) => g.product), ["txn", "promo", null]);
  assert.deepEqual(groups[0].items.map((i) => i.index), [1, 2]);
  assert.deepEqual(groups.map((g) => g.hasFallback), [true, false, true]);
  //a retired fallback catches nothing
  assert.equal(groupByProduct([rule("1", { enabled: false })])[0].hasFallback, false);
});

test("a move stays inside its product", () => {
  const rules = [rule("a", { product: "txn" }), rule("b"), rule("c", { product: "txn" })];
  assert.deepEqual(moveWithinProduct(rules, 2, -1).map((r) => r.amount), ["c", "b", "a"]);
  assert.equal(moveWithinProduct(rules, 1, 1), rules);
});

test("a staged scope counts additions, edits, moves within a product and removals", () => {
  const stored = [rule("1", { id: 1, product: "txn" }), rule("2", { id: 2 }), rule("3", { id: 3, product: "txn" })];
  assert.equal(scopeChangeCount(stored, stored), 0);
  //moving an any-product rule past a txn one changes nothing the gateway reads
  assert.equal(scopeChangeCount(stored, [stored[1], stored[0], stored[2]]), 0);
  //swapping the two txn rules is two moves
  const swapped = [stored[2], stored[1], stored[0]];
  assert.equal(scopeChangeCount(stored, swapped), 2);
  assert.ok(priceChanged(stored, swapped, stored[2]));
  const edited = [{ ...stored[0], amount: "9" }, rule("new")];
  assert.equal(scopeChangeCount(stored, edited), 1 + 1 + 2);
});

test("a whole-pricing file may name any product", () => {
  const csv = "scope,seq,rule_id,amount,product,currency,label,enabled,filters,conditions\n"
    + "acme,0,,0.0400,txn,,,true,,to:startsWith:+91\nacme,1,,0.0500,promo,,,true,,\n";
  const rows = fromCsv(csv, null);
  assert.ok(Array.isArray(rows));
  assert.deepEqual(rows.map((r) => r.product), ["txn", "promo"]);
  //a product's own import still refuses other products
  assert.equal(typeof fromCsv(csv, "txn"), "string");
});
