import { strict as assert } from "node:assert";
import { test } from "node:test";
import { type KnownScopes, type RateRuleInput, scopeWarnings, unratedPairs, validateScope } from "./rate-types.ts";

/**
 * Creating pricing that stores nothing.
 *
 * <p>The whole-scope save path has nothing to insert when the rule list is empty, so creating a new
 * scope that way wrote no rows, answered 200, and refreshed the list unchanged. "Add pricing" looked
 * like a dead button — which is how a platform ends up with no default price and nobody able to set
 * one, having deleted the old one.
 *
 * <p>The distinction the fix rests on: an **existing** scope may legitimately be emptied. That is
 * how the last rule is removed, and the CSV import relies on it. Only creation is refused.
 */

const KNOWN: KnownScopes = { vendors: ["vendor1"], accounts: ["acct-1001"] };

const rule = (over: Partial<RateRuleInput> = {}): RateRuleInput => ({
  id: null,
  amount: "0.0100",
  product: null,
  currency: null,
  label: null,
  enabled: true,
  conditions: [],
  filters: [],
  ...over,
});

test("creating a scope with no rules is refused, and says why nothing would be stored", () => {
  const problem = validateScope({ scope: "acct-1001", isNew: true, rules: [] }, KNOWN);

  assert.ok(problem, "an empty new scope used to save cleanly and store nothing");
  assert.match(problem!, /at least one rule/);
});

test("emptying a scope that already exists is still allowed", () => {
  //removing the last rule, and what the CSV import does when a scope drops out of the file
  assert.equal(validateScope({ scope: "acct-1001", rules: [] }, KNOWN), null);
  assert.equal(validateScope({ scope: "acct-1001", isNew: false, rules: [] }, KNOWN), null);
});

test("the reserved default scope is creatable, which is the case that started this", () => {
  //'*' is neither a vendor nor an account, and it must not need the unknown-scope confirmation
  assert.equal(validateScope({ scope: "*", isNew: true, rules: [rule({ product: "promo" })] }, KNOWN), null);
});

test("an empty new scope is refused before the scope name is even plausible", () => {
  //the two refusals are independent: a blank scope is still reported as a blank scope
  const problem = validateScope({ scope: "", isNew: true, rules: [] }, KNOWN);

  assert.match(problem!, /A scope is required/);
});

test("a new scope with one good rule saves", () => {
  assert.equal(validateScope({ scope: "vendor1", isNew: true, rules: [rule()] }, KNOWN), null);
});

test("a new scope whose only rule has no amount is refused for the amount, not the count", () => {
  //the operator added a row and left it blank, which is a different mistake and deserves its own
  //sentence -- 'needs at least one rule' would be false and unactionable
  const problem = validateScope({ scope: "vendor1", isNew: true, rules: [rule({ amount: "" })] }, KNOWN);

  assert.match(problem!, /needs an amount/);
});

/**
 * The rating finding, which until now could not fire at all.
 *
 * <p>`ratingFindings` was complete and nothing populated `unratedProducts`. Wiring it up made the
 * false positive below the thing to guard: an account priced entirely by the `*` default scope is
 * priced, and reporting it would send an operator hunting for a rule that is working.
 */

const covering = (...pairs: [string, string][]) =>
  pairs.map(([scope, product]) => ({ scope, product }));

test("an account priced only by the default scope is not reported", () => {
  //rulesForPrice appends '*' to every account's own rules, so this pair is priced
  assert.deepEqual(unratedPairs({ "acct-1001": ["promo"] }, covering(["*", "promo"])), []);
});

test("a bare catch-all on the default scope prices every product", () => {
  //product '' is a rule carrying no product, which rulesFor returns for any product asked for
  assert.deepEqual(unratedPairs({ "acct-1001": ["promo", "otp"] }, covering(["*", ""])), []);
});

test("a default priced for one product does not price another", () => {
  assert.deepEqual(
    unratedPairs({ "acct-1001": ["promo", "otp"] }, covering(["*", "promo"])),
    [{ scope: "acct-1001", product: "otp" }]
  );
});

test("an account's own catch-all covers everything it carries", () => {
  assert.deepEqual(unratedPairs({ "acct-1001": ["promo", "otp"] }, covering(["acct-1001", ""])), []);
});

test("a price for one account says nothing about another", () => {
  assert.deepEqual(
    unratedPairs({ "acct-1001": ["promo"], "acct-1002": ["promo"] }, covering(["acct-1001", "promo"])),
    [{ scope: "acct-1002", product: "promo" }]
  );
});

test("with nothing priced at all, every pair is reported once", () => {
  //duplicated products on two logins are one pair, not two findings about the same thing
  assert.deepEqual(
    unratedPairs({ "acct-1001": ["promo", "promo", "otp"] }, []),
    [{ scope: "acct-1001", product: "otp" }, { scope: "acct-1001", product: "promo" }]
  );
});

test("an account whose logins carry no product produces nothing", () => {
  //nothing to be unrated FOR. The message would carry no product and match a catch-all or nothing,
  //which is a different diagnosis and belongs to the traffic-side pre-flight
  assert.deepEqual(unratedPairs({ "acct-1001": [] }, []), []);
});

test("the default scope is never reported against itself", () => {
  //an account cannot be named '*', and rulesForPrice does not append the default to itself
  assert.deepEqual(unratedPairs({ "*": ["promo"] }, []), []);
});

/**
 * "Everything else on test-pro" on Everyone, and no login anywhere carrying test-pro: the rule is
 * correct and prices nothing, every message is recorded with a blank price. The account-scope
 * warning already said so for an account; the default scope said nothing.
 */
test("a default rule for a product no login carries is warned about", () => {
  const known: KnownScopes = { ...KNOWN, carriedProducts: { "acct-1001": ["sms"] } };
  const [warning, ...rest] = scopeWarnings({ scope: "*", rules: [rule({ product: "test-pro" })] }, known);
  assert.equal(rest.length, 0);
  assert.match(warning, /No login on any account carries the product 'test-pro'/);
  assert.match(warning, /Logins carry: sms/);
  //one that is carried somewhere is reachable, and a rule for any product always is
  assert.deepEqual(scopeWarnings({ scope: "*", rules: [rule({ product: "sms" }), rule()] }, known), []);
  //the logins were not read: no opinion rather than a false alarm
  assert.deepEqual(scopeWarnings({ scope: "*", rules: [rule({ product: "test-pro" })] }, KNOWN), []);
});
