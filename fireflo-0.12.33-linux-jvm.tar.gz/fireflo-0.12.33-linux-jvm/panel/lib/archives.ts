import { query } from "@/lib/metrics-db";
import { hasQueueArchive } from "@/lib/metrics-schema";
import type { ArchiveAccountFilters, ArchiveEntryFilters } from "@/lib/archives-request";
import {
  PARTITION_CATALOG_SQL,
  PARTITION_COUNTS_SQL,
  PURGED_MONTHS_SQL,
  accountsSql,
  batchesSql,
  entriesSql,
  mergePartitions,
  type PartitionCatalogRow,
  type PartitionCountRow,
  type PurgedMonthRow,
} from "@/lib/archives-sql";
import {
  ARCHIVE_GATEWAY_RELEASE,
  type ArchiveAccountRow,
  type ArchiveAnswer,
  type ArchiveBatch,
  type ArchiveCursor,
  type ArchiveEntriesPage,
  type ArchiveEntry,
  type ArchivePartition,
} from "@/lib/archives-types";

/**
 * The Archives report's reads, on the metrics database's read-only role.
 *
 * <p>Server-only: importing this pulls `pg`. Every function asks {@link hasQueueArchive} first and
 * answers `available: false` on a gateway older than V1.93.0, so the page says "available from
 * gateway 0.12.19" instead of surfacing a missing-relation error.
 *
 * <p>Read-only by construction: cleaning and purging are gateway actions (the admin endpoint and the
 * command line), never a write from this panel to these tables.
 */

const UNAVAILABLE = { available: false as const, release: ARCHIVE_GATEWAY_RELEASE };

const iso = (v: Date | string | null | undefined): string | null =>
  v == null ? null : v instanceof Date ? v.toISOString() : new Date(v).toISOString();
const num = (v: string | number | null | undefined): number | null => (v == null ? null : Number(v));

export async function listArchivePartitions(): Promise<ArchiveAnswer<{ partitions: ArchivePartition[] }>> {
  if (!(await hasQueueArchive())) {
    return UNAVAILABLE;
  }
  const [catalog, counts, purged] = await Promise.all([
    query<PartitionCatalogRow>(PARTITION_CATALOG_SQL),
    query<PartitionCountRow>(PARTITION_COUNTS_SQL),
    query<PurgedMonthRow>(PURGED_MONTHS_SQL),
  ]);
  return { available: true, partitions: mergePartitions(catalog, counts, purged) };
}

interface AccountDbRow {
  account_id: string | null;
  messages: string;
  refunded: string | null;
  receipts_sent: string | null;
  price_total: string | null;
  first_at: Date | null;
  last_at: Date | null;
  held: string;
  purged: string;
}

export async function listArchiveAccounts(
  filters: ArchiveAccountFilters
): Promise<ArchiveAnswer<{ accounts: ArchiveAccountRow[] }>> {
  if (!(await hasQueueArchive())) {
    return UNAVAILABLE;
  }
  const { sql, params } = accountsSql(filters);
  const rows = await query<AccountDbRow>(sql, params);
  return {
    available: true,
    accounts: rows.map((r) => ({
      accountId: r.account_id,
      messages: Number(r.messages ?? 0),
      refunded: Number(r.refunded ?? 0),
      receiptsSent: Number(r.receipts_sent ?? 0),
      priceTotal: r.price_total,
      firstAt: iso(r.first_at),
      lastAt: iso(r.last_at),
      held: Number(r.held ?? 0),
      purged: Number(r.purged ?? 0),
    })),
  };
}

interface EntryDbRow {
  archive_id: string;
  archived_at: Date;
  batch_id: string | null;
  store: string;
  sub_store: string | null;
  kind: string;
  worker: string | null;
  account_id: string | null;
  system_id: string | null;
  gateway_msg_id: string | null;
  serial: string | null;
  source_addr: string | null;
  dest_addr: string | null;
  product: string | null;
  price: string | null;
  parts: number | null;
  body: string | null;
  retries: number | null;
  created_at: Date | null;
  reason: string | null;
  note: string | null;
  actor: string | null;
  refunded: boolean | null;
  receipt_sent: boolean | null;
}

export async function listArchiveEntries(
  filters: ArchiveEntryFilters,
  opts: { limit: number; cursor?: ArchiveCursor | null }
): Promise<ArchiveAnswer<ArchiveEntriesPage>> {
  if (!(await hasQueueArchive())) {
    return UNAVAILABLE;
  }
  const { sql, params } = entriesSql(filters, opts);
  const rows = await query<EntryDbRow>(sql, params);
  const size = Math.max(1, Math.floor(opts.limit));
  const page = rows.slice(0, size).map(toEntry);
  const last = page[page.length - 1];
  return {
    available: true,
    rows: page,
    nextCursor: rows.length > size && last ? { archivedAt: last.archivedAt, id: last.id } : null,
  };
}

function toEntry(r: EntryDbRow): ArchiveEntry {
  return {
    id: r.archive_id,
    archivedAt: iso(r.archived_at)!,
    batchId: r.batch_id,
    store: r.store,
    subStore: r.sub_store,
    kind: r.kind,
    worker: r.worker,
    accountId: r.account_id,
    systemId: r.system_id,
    gatewayMsgId: r.gateway_msg_id,
    serial: r.serial,
    sourceAddr: r.source_addr,
    destAddr: r.dest_addr,
    product: r.product,
    price: r.price,
    parts: r.parts,
    body: r.body,
    retries: r.retries,
    createdAt: iso(r.created_at),
    reason: r.reason,
    note: r.note,
    actor: r.actor,
    refunded: r.refunded,
    receiptSent: r.receipt_sent,
  };
}

interface BatchDbRow {
  batch_id: string;
  started_at: Date;
  finished_at: Date | null;
  store: string;
  selector: Record<string, unknown> | null;
  actor: string | null;
  reason: string | null;
  note: string | null;
  matched: string | number | null;
  archived: string | number | null;
  refunded: string | number | null;
  receipts_sent: string | number | null;
  failed: string | number | null;
}

export async function listArchiveBatches(opts: {
  store?: string | null;
  batchId?: string | null;
  limit: number;
}): Promise<ArchiveAnswer<{ batches: ArchiveBatch[] }>> {
  if (!(await hasQueueArchive())) {
    return UNAVAILABLE;
  }
  const { sql, params } = batchesSql(opts);
  const rows = await query<BatchDbRow>(sql, params);
  return {
    available: true,
    batches: rows.map((r) => ({
      batchId: r.batch_id,
      startedAt: iso(r.started_at)!,
      finishedAt: iso(r.finished_at),
      store: r.store,
      selector: r.selector,
      actor: r.actor,
      reason: r.reason,
      note: r.note,
      matched: num(r.matched),
      archived: num(r.archived),
      refunded: num(r.refunded),
      receiptsSent: num(r.receipts_sent),
      failed: num(r.failed),
    })),
  };
}
