/**
 * The shape the gateway reports its licence in, and how to render it.
 *
 * <h2>There is no check in this file, and there must never be one</h2>
 *
 * <p><strong>This panel's source ships to customers.</strong> Any licence check written here is
 * three lines somebody deletes and rebuilds, so writing one would be theatre — worse than theatre,
 * because it would suggest to the next reader that the boundary lives here when it does not.
 *
 * <p>The boundary is in the gateway's compiled artefact: `DbConfigPoller.pollOnce` refuses to adopt
 * a new configuration snapshot while unlicensed, and `/ops` answers 402. Delete every licence line
 * in this panel and rebuild it, and the gateway is still frozen — because the gateway never asked
 * the panel anything.
 *
 * <p>What lives here is presentation: a type, and a rule for which colour a banner is. Both exist
 * so the banner and the verify page say the same thing rather than two slightly different things.
 */

/** Mirrors `LicenseVerdict` on the gateway, lowercased as `LicenseState` serialises it. */
export type LicenseVerdict =
  | "active"
  | "grace"
  | "setup"
  | "expired"
  | "wrong_install"
  | "malformed"
  | "none";

/** Mirrors `LicenseState.java`. Carries no secret — see that record for why. */
export interface LicenseState {
  verdict: LicenseVerdict;
  license_id: string | null;
  tier: string | null;
  install_id: string | null;
  bound_ip: string | null;
  not_after: string | null;
  grace_ends_at: string | null;
  days_until_frozen: number;
  last_refreshed_at: string | null;
  /** Whether the gateway is currently taking up configuration changes. The fact that matters. */
  configuration_adopted: boolean;
  server_url: string;
  /**
   * Whether this process started on configuration changed while its licence was not current.
   *
   * <p>Three-valued, and `null` means unknown rather than fine — an install with nothing recorded
   * to compare against says nothing rather than giving a clean bill of health nobody checked.
   * Absent entirely on a gateway older than 0.8.5, which reads as `undefined` and is treated the
   * same way.
   */
  configuration_changed_while_unlicensed?: boolean | null;
  message: string;
}

/**
 * What `/cp/verify` should lead with.
 *
 * <p>`details` — this gateway is licensed. Say so, and put everything else away.
 * <p>`activate` — it is not, and pasting a key is the way out.
 * <p>`transfer` — a half-finished move. The two steps, in order, are the whole answer.
 */
export type LicenseLead = "details" | "activate" | "transfer";

export interface LicenseScreen {
  lead: LicenseLead;
  /** The activate form is still reachable, but collapsed and not the main event. */
  activateIsSecondary: boolean;
  /** Whether clearing the licence this machine holds is offered at all. */
  offerRelease: boolean;
  /** Whether asking the licence server again could tell us anything new. */
  offerRevalidate: boolean;
}

/**
 * Which of those three a verdict deserves.
 *
 * <h2>The bug this exists to end</h2>
 *
 * <p>`/cp/verify` rendered the activation form on every verdict, so a licensed gateway looked
 * exactly like one that had never been activated — an operator returning to a working install was
 * shown a form asking them to do the thing they had already done. Whether a page leads with "here
 * is your licence" or "paste a key" is a decision, and it is made here rather than in the
 * component's JSX so the seven verdicts are decided in one place and can be tested without a
 * browser.
 *
 * <p><strong>Still presentation.</strong> Nothing here decides entitlement; it decides layout. The
 * gateway has already made every judgement this reads — see the note at the top of this file.
 *
 * <p>`offerRelease` is driven by the verdict rather than by whether `license_id` is set, because
 * `malformed` and `none` both have a null id and want opposite answers: an unreadable licence is
 * still a licence on disk worth clearing, and a machine that never had one has nothing to clear.
 */
export function licenseScreen(state: LicenseState | null): LicenseScreen {
  //never offer a destructive act against a box whose state could not be read. "I could not ask" is
  //not "there is nothing there"
  if (!state) {
    return {
      lead: "activate",
      activateIsSecondary: false,
      offerRelease: false,
      offerRevalidate: false,
    };
  }
  switch (state.verdict) {
    case "active":
    case "grace":
      //grace is licensed and working. Leading with a key field would imply the key is wrong when
      //what lapsed is the term -- and the fix for that is a refresh, not a re-activation
      return {
        lead: "details",
        activateIsSecondary: true,
        offerRelease: true,
        offerRevalidate: true,
      };
    case "wrong_install":
      //this verdict IS a transfer done backwards: released here, or activated on a rebuilt box,
      //without the other half. Naming the two steps in order is more useful than either a form or
      //a detail card
      return {
        lead: "transfer",
        activateIsSecondary: false,
        offerRelease: true,
        offerRevalidate: true,
      };
    case "expired":
    case "malformed":
      return {
        lead: "activate",
        activateIsSecondary: false,
        offerRelease: true,
        offerRevalidate: true,
      };
    case "setup":
    case "none":
      //nothing on disk to clear, so offering to clear it would be a button that does nothing and
      //reads as a way to reset something
      return {
        lead: "activate",
        activateIsSecondary: false,
        offerRelease: false,
        offerRevalidate: false,
      };
  }
}

export type BannerTone = "none" | "info" | "warning" | "danger";

/**
 * How loudly to say it.
 *
 * <p>Nothing at all when the licence is active — a banner an operator sees every day is a banner
 * they stop reading, and it would be sitting above the screens they use to run a carrier.
 *
 * <p>The split is by consequence rather than by verdict name: `setup` and `grace` are both "still
 * working, act before a date", so both are quiet. Everything else means configuration changes are
 * already being ignored, which the operator needs to know before they wonder why their edit did
 * nothing.
 */
export function bannerTone(state: LicenseState | null): BannerTone {
  if (!state || state.verdict === "active") {
    return "none";
  }
  if (state.verdict === "setup") {
    return "info";
  }
  if (state.verdict === "grace") {
    //warning rather than danger: everything still works, and crying wolf during grace is how the
    //real freeze a week later gets ignored
    return "warning";
  }
  return "danger";
}

/** A short line for the banner. The gateway's own sentence is the long one. */
export function bannerHeadline(state: LicenseState): string {
  switch (state.verdict) {
    case "setup":
      return "This gateway has not been activated yet";
    case "grace":
      return state.days_until_frozen > 0
        ? `Licence lapsed — ${state.days_until_frozen} day${
            state.days_until_frozen === 1 ? "" : "s"
          } before configuration changes stop being adopted`
        : "Licence lapsed — configuration changes stop being adopted today";
    case "wrong_install":
      return "This licence belongs to a different installation";
    case "malformed":
      return "This gateway's licence could not be read";
    default:
      return "Configuration changes are not being adopted";
  }
}
