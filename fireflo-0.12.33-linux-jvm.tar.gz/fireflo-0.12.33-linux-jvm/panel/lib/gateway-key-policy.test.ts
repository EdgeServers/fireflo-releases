import { test } from "node:test";
import assert from "node:assert/strict";
import {
  denialMessage,
  isReadable,
  isWritable,
  judgeGatewayKey,
  looksSensitive,
} from "./gateway-key-policy.ts";

/**
 * The security boundary, pinned.
 *
 * <p>Written before anything consumed the module, because "the security boundary" had zero tests
 * for the whole of its previous life as a one-line membership check.
 *
 * <p>Two of these cases stand for bugs this codebase has already shipped once: the ops tokens
 * reaching the browser through a `key LIKE 'smsg.%'` select, and `ShowCommand` printing both of them
 * to a terminal because it asked whether the column *label* looked sensitive. Neither was caught by
 * reading the call; both were caught by looking at the output.
 */

test("both ops tokens are unreadable and unwritable", () => {
  for (const key of ["smsg.ops.token", "smsg.ops.admin.token"]) {
    assert.equal(isWritable(key), false, `${key} must not be writable`);
    //the half that was actually broken: the GET handler returned these to the browser
    assert.equal(isReadable(key), false, `${key} must not be readable`);
    assert.deepEqual(judgeGatewayKey(key), { allowed: false, reason: "secret" });
  }
});

test("a credential-shaped key nobody listed is denied anyway", () => {
  //the point of the shape rule: none of these are in DENIED, and all of them must fail closed
  for (const key of [
    "smsg.some.future.password",
    "smsg.vendor.api_key",
    "smsg.thing.secret.value",
    "outSms.default.password",
    "smsg.tls.keystore.path",
    "smsg.tls.truststore",
    "smsg.signing.private.key",
  ]) {
    assert.equal(isWritable(key), false, `${key} looks like a credential and must be refused`);
    assert.equal(isReadable(key), false, `${key} must not be rendered either`);
  }
});

test("the shape rule outranks the prefix rule, so the refusal names the real reason", () => {
  //denied either way -- but an operator told "wrong prefix" about a password would fix the prefix
  const verdict = judgeGatewayKey("postgres.password");
  assert.deepEqual(verdict, { allowed: false, reason: "secret" });
});

test("url and uri are not treated as secrets in general", () => {
  //deliberately narrow: smsg.dlr.forward.url is an ordinary setting somebody has a reason to change
  assert.equal(looksSensitive("smsg.dlr.forward.url"), false);
  assert.equal(isWritable("smsg.dlr.forward.url"), true);
  //but the one URI that carries a password in its userinfo is named explicitly
  assert.equal(isWritable("smsg.queue.amqp.uri"), false);
  assert.equal(isReadable("smsg.queue.amqp.uri"), false);
});

test("the keys that decide where configuration comes from are readable but not writable", () => {
  for (const key of [
    "smsg.config.source",
    "smsg.properties.file.path",
    "smsg.rates.file.path",
    "smsg.routing.file.path",
  ]) {
    assert.equal(isWritable(key), false, `${key} must not be writable`);
    //seeing which source is in force is the whole point of the audit view
    assert.equal(isReadable(key), true, `${key} should still be visible`);
  }
});

test("the credentials path is masked, even though its value is only a filename", () => {
  //`smsg.credentials.file.path` contains "credential", so the shape rule takes it. Its value is
  //conf/credentials.yml -- a path, not a secret -- so this is the shape rule being blunter than it
  //strictly needs to be, and it is kept rather than special-cased for two reasons. The gateway's
  //own SensitiveLogSanitizer has the same substring, so ConfigRedactor already blanks this key in
  ///ops/config; a panel that showed it would disagree with the gateway about the same row. And the
  //exception would have to be written as "except when the key ends in .path", which is exactly the
  //kind of narrowing that lets the next credential through
  assert.equal(isReadable("smsg.credentials.file.path"), false);
  assert.equal(isWritable("smsg.credentials.file.path"), false);
});

test("wiring keys are shown and not written", () => {
  for (const key of [
    "smsg.cdr.sink",
    "smsg.webhook.private.targets",
    "smsg.webhook.schemes",
  ]) {
    assert.equal(isWritable(key), false);
    assert.equal(isReadable(key), true);
  }
});

test("keys the panel edits elsewhere are refused here", () => {
  for (const key of ["smsg.rates.currency", "smsg.money.scale", "smsg.billing.zone", "smsg.queue.provider"]) {
    assert.deepEqual(judgeGatewayKey(key), { allowed: false, reason: "elsewhere" });
  }
});

test("anything outside the two namespaces is refused on prefix", () => {
  for (const key of ["postgres.url", "outSms.instance.airtel.tps", "randomkey", "outSms.default"]) {
    assert.deepEqual(
      judgeGatewayKey(key),
      { allowed: false, reason: "prefix" },
      `${key} should be refused on prefix`
    );
  }
});

test("a bare prefix is not a key", () => {
  assert.equal(isWritable("smsg."), false);
  assert.equal(isWritable(""), false);
  assert.equal(isWritable("   "), false);
});

test("an uncurated key in the right namespace is writable, and says it has no field", () => {
  //this is the whole feature: a key with no entry in the catalogue can now be set
  const verdict = judgeGatewayKey("smsg.whitelist.max.variable");
  assert.deepEqual(verdict, { allowed: true, curated: false });
});

test("a curated key reports itself as curated so the page puts it in a card", () => {
  assert.deepEqual(judgeGatewayKey("smsg.whitelist.enabled"), { allowed: true, curated: true });
  assert.deepEqual(judgeGatewayKey("smsg.restapi.billing.units"), { allowed: true, curated: true });
  //a worker default the vendor form already knows how to render
  assert.deepEqual(judgeGatewayKey("outSms.default.windowSize"), { allowed: true, curated: true });
});

test("a worker default for a key no form knows is still writable, just uncurated", () => {
  assert.deepEqual(
    judgeGatewayKey("outSms.default.some.unknown.knob"),
    { allowed: true, curated: false }
  );
});

test("keys are trimmed before judging, so a pasted key with whitespace behaves", () => {
  assert.equal(isWritable("  smsg.whitelist.enabled  "), true);
  assert.equal(isWritable("  smsg.ops.admin.token  "), false);
});

test("every refusal says what to do instead", () => {
  const reasons =
    ["secret", "config-source", "wiring", "elsewhere", "licensing", "prefix"] as const;
  for (const reason of reasons) {
    const message = denialMessage("smsg.example", reason);
    assert.ok(message.includes("smsg.example"), "the message names the key");
    assert.ok(message.length > 40, `${reason} should explain itself, not just refuse`);
  }
  //an empty key still produces a sentence rather than a dangling one
  assert.ok(denialMessage("", "prefix").includes("(empty)"));
});

test("the licensing namespace is readable but not writable", () => {
  //ANTI-VACUITY. Both of these start with `smsg.` and neither looks like a credential, so before
  //the namespace rule existed the free-form editor accepted them -- assert the general rule still
  //would, or this test passes against a key that was never reachable in the first place
  for (const key of ["smsg.license.server.url", "smsg.license.directory"]) {
    assert.ok(key.startsWith("smsg."), "still inside the writable prefix");
    assert.equal(looksSensitive(key), false, "not caught by the shape rule either");

    assert.deepEqual(judgeGatewayKey(key), { allowed: false, reason: "licensing" });
    assert.equal(isWritable(key), false);
    //readable on purpose: an operator debugging an install that will not activate should be able
    //to see which server it is asking
    assert.equal(isReadable(key), true);
  }
});

test("the namespace covers keys nobody has added yet", () => {
  //the reason this is a prefix and not two entries. A bearer credential added here later is
  //denied on the day it is added rather than the day somebody notices
  assert.deepEqual(
    judgeGatewayKey("smsg.license.key"),
    { allowed: false, reason: "licensing" }
  );
  assert.equal(isWritable("  smsg.license.server.url  "), false, "trimmed before judging");
});

test("a neighbouring key is not swept up by the namespace", () => {
  //`smsg.licence`/`smsg.licensed` are not `smsg.license.` -- the rule matches the dot, so an
  //unrelated key that merely starts with the same letters stays ordinary
  assert.deepEqual(
    judgeGatewayKey("smsg.licensing.notes"),
    { allowed: true, curated: false }
  );
});

test("message.trace.mode is settable, and nothing else gained entry with it", () => {
  //it was never denied on purpose: an ordinary global diagnostic toggle that predates the smsg.
  //convention and was caught by the prefix rule incidentally, which cost an operator a psql session
  //on a live gateway mid-incident
  assert.deepEqual(judgeGatewayKey("message.trace.mode"), { allowed: true, curated: false });

  //the anti-vacuity half: the exception is one name, not a new namespace
  assert.equal(judgeGatewayKey("message.trace").allowed, false);
  assert.equal(judgeGatewayKey("message.anything.else").allowed, false);
  assert.equal(judgeGatewayKey("postgres.url").allowed, false);
});

test("the deliberate denials are untouched by the legacy exception", () => {
  //these are checked before the prefix rule, so widening that rule must not have reached them
  assert.equal(judgeGatewayKey("smsg.ops.admin.token").reason, "secret");
  assert.equal(judgeGatewayKey("smsg.config.source").allowed, false);
  assert.equal(judgeGatewayKey("smsg.license.server.url").reason, "licensing");
});

test("smsg.diagnostics is writable, so the level can be set from the panel", () => {
  assert.equal(judgeGatewayKey("smsg.diagnostics").allowed, true);
});
