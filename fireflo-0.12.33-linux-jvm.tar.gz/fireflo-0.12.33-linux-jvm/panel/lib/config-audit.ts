import type { Session } from "next-auth";
import { logOperatorEvent } from "@/lib/access-log";
import { auth } from "@/lib/auth";
import { type ConfigChange, configChangeDetail } from "@/lib/config-change";
import { requestContext } from "@/lib/request-context";
import { isOperatorSession } from "@/lib/roles";

/**
 * Records one configuration change as a `config_changed` operator event.
 *
 * <h2>Called from the lib save functions, not from the routes</h2>
 *
 * <p>`saveCredential`, `saveRouteTable`, `topUp` and the rest call this themselves after their write
 * has gone through. A route that reaches one of them cannot forget to audit, and a new route built on
 * an existing save function is audited before its author has thought about it. Only the handful of
 * routes that have no lib function -- a reload, a disconnect, a bind-hold lift, a worker control --
 * call this directly, and `lib/config-audit-coverage.test.ts` names them.
 *
 * <h2>Who the actor is</h2>
 *
 * <p>The lib functions are not handed the operator -- most routes go through `guardConfigWrite`,
 * which checks the session and throws it away -- so this reads the same session `requireOperator`
 * does, without the fresh role read: the write it describes has already been admitted. The address
 * comes from `requestContext()`, which falls back to Next's request headers when there is no
 * wrapped context, the same way the customer log finds it.
 *
 * <p><strong>A customer's session is skipped on purpose.</strong> `topUp`, `openBalance` and the
 * balance setters are also reached from the reseller portal (`/api/mis/accounts/[id]/balance`),
 * where `lib/customer-access-log.ts` already records `child_credit_changed` against the acting
 * customer. Writing an operator row for a customer act would put a customer in the operator log
 * under an address no `app_user` row explains. No session at all -- a script, a test -- is logged
 * with a null actor rather than dropped: the change still happened.
 *
 * <h2>It must never break a write</h2>
 *
 * <p>Everything here is wrapped and the promise always resolves. The write it describes has been
 * committed by the time this runs; failing the request afterwards would report a change as refused
 * while leaving it in place. Callers `await` it rather than `void` it only so the session and headers
 * are read while the request is still alive -- the cost is one JWT decode.
 *
 * @param actor who did it, when the caller already knows (a route holding `requireOperator()`'s
 *     result). Otherwise read from the session.
 */
export async function auditConfigChange(change: ConfigChange, actor?: AuditActor | null): Promise<void> {
  try {
    const who = actor === undefined ? await sessionActor() : actor;
    if (who === SKIP) {
      return;
    }
    const { ip, userAgent } = await requestContext();
    await logOperatorEvent({
      event: "config_changed",
      actor: who?.name ?? null,
      userId: who?.userId ?? null,
      ip,
      userAgent,
      detail: configChangeDetail(change),
    });
  } catch (err) {
    console.error("config audit: could not record a change, continuing", err);
  }
}

/** The operator a change is attributed to. `OperatorIdentity` satisfies it. */
export interface AuditActor {
  /** The address they signed in with. */
  name: string;
  /** The `app_user` row, or null for the env-fallback operator. */
  userId: number | null;
}

/** A customer's session: the change is theirs and the customer log has it. */
const SKIP = Symbol("customer-session");

async function sessionActor(): Promise<AuditActor | null | typeof SKIP> {
  let session: Session | null = null;
  try {
    //`auth()` is overloaded (middleware, route wrapper, plain call); the plain call is a Session
    session = (await auth()) as Session | null;
  } catch {
    //outside a request: a script or a test. The change is still worth a line, with no actor
    return null;
  }
  if (!session?.user) {
    return null;
  }
  if (!isOperatorSession(session)) {
    return SKIP;
  }
  const userId = session.user.userId == null ? null : Number(session.user.userId);
  return { name: session.user.name ?? "", userId: Number.isFinite(userId as number) ? userId : null };
}
