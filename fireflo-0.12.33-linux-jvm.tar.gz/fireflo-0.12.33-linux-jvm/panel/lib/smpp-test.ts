import { randomBytes } from "node:crypto";
import smpp, { type Pdu, type Session } from "smpp";
import { DATA_CODING, autoEncoding, countSms, encodeSms, type SmsEncoding } from "@/lib/sms-text";
import { tlvTag } from "@/lib/tlv-string";
import type { BindKind, SmppSubmitResult, SmppTestEvent, SmppTestState } from "@/lib/smpp-test-types";

/**
 * The SMPP test tool's sessions: an ESME the panel's own server binds to a gateway listener, exactly
 * as a customer's client would, driven from the browser through the routes under
 * `app/api/control/accounts/[id]/smpp-test`.
 *
 * <p>Server-only, and the reason this exists rather than a client-side tool: a browser cannot open a
 * TCP connection, and SMPP is nothing else. Nothing here touches the gateway beyond binding to it.
 *
 * <h2>Bounded on every side</h2>
 *
 * <ul>
 *   <li>At most {@link MAX_SESSIONS} at once, across the panel.
 *   <li>Each keeps its newest {@link KEEP_EVENTS} log lines.
 *   <li>One idle for {@link IDLE_MS} is unbound and closed: the modal closes its session when it
 *       closes, and this is the backstop for a tab that died without saying so.
 * </ul>
 *
 * <p>The registry hangs off `globalThis` so a dev-server hot reload does not orphan open sockets.
 */

export const MAX_SESSIONS = 3;
export const KEEP_EVENTS = 2_000;
export const IDLE_MS = 10 * 60_000;
const BIND_TIMEOUT_MS = 10_000;
const SUBMIT_TIMEOUT_MS = 30_000;

interface TestSession {
  id: string;
  operator: string;
  accountId: string;
  systemId: string;
  host: string;
  port: number;
  bindType: BindKind;
  session: Session;
  bound: boolean;
  closedBecause: string | null;
  events: SmppTestEvent[];
  nextSeq: number;
  lastTouched: number;
}

const registry: Map<string, TestSession> =
  ((globalThis as { __firefloSmppTests?: Map<string, TestSession> }).__firefloSmppTests ??= new Map());

/**
 * The idle sweep on a timer of its own, once per process: without it the 10-minute close ran only
 * when somebody next used the tool, so a session whose tab died stayed bound to the gateway until
 * then. Unref'd, so it never keeps the process alive on its own.
 */
const sweeper = globalThis as { __firefloSmppSweep?: ReturnType<typeof setInterval> };
sweeper.__firefloSmppSweep ??= setInterval(() => sweep(), 60_000);
sweeper.__firefloSmppSweep.unref?.();

/** Status names, from the codec's own table, for a log a person can read. */
const STATUS_NAMES: Map<number, string> = new Map(
  Object.entries((smpp as unknown as { errors: Record<string, number> }).errors).map(([name, code]) => [code, name])
);

export function statusText(status: number): string {
  const hex = `0x${status.toString(16).padStart(8, "0")}`;
  const name = STATUS_NAMES.get(status);
  return name ? `${hex} ${name}` : hex;
}

function log(s: TestSession, dir: SmppTestEvent["dir"], command: string | null, tone: SmppTestEvent["tone"], text: string) {
  s.events.push({ seq: s.nextSeq++, at: new Date().toISOString(), dir, command, tone, text });
  if (s.events.length > KEEP_EVENTS) {
    s.events.splice(0, s.events.length - KEEP_EVENTS);
  }
}

/** Fields worth printing, from a PDU: no methods, no empty values, and never the password. */
function describe(pdu: Pdu): string {
  const skip = new Set(["command", "command_id", "command_length", "command_status", "sequence_number"]);
  const parts: string[] = [`seq=${pdu.sequence_number}`];
  if (pdu.command_status || pdu.command.endsWith("_resp")) {
    parts.push(`status=${statusText(pdu.command_status)}`);
  }
  for (const [key, value] of Object.entries(pdu)) {
    if (skip.has(key) || typeof value === "function" || value === undefined || value === null || value === "") {
      continue;
    }
    if (key === "password") {
      parts.push("password=***");
      continue;
    }
    if (key === "short_message" || key === "message_payload") {
      parts.push(`${key}="${messageText(value, pdu.data_coding)}"`);
      continue;
    }
    if (Buffer.isBuffer(value)) {
      parts.push(`${key}=hex:${value.toString("hex")}`);
      continue;
    }
    if (typeof value === "object") {
      parts.push(`${key}=${JSON.stringify(value)}`);
      continue;
    }
    parts.push(`${key}=${String(value)}`);
  }
  return parts.join(" ");
}

function messageText(value: unknown, dataCoding: number | undefined): string {
  const raw = value && typeof value === "object" && !Buffer.isBuffer(value) && "message" in (value as object)
    ? (value as { message: unknown }).message
    : value;
  if (typeof raw === "string") {
    return raw;
  }
  if (Buffer.isBuffer(raw)) {
    return dataCoding === 8 ? Buffer.from(raw).swap16().toString("utf16le") : raw.toString("latin1");
  }
  return String(raw);
}

function isReceipt(pdu: Pdu): boolean {
  return (((pdu.esm_class as number) ?? 0) & 0x04) !== 0;
}

export interface OpenRequest {
  operator: string;
  accountId: string;
  host: string;
  port: number;
  bindType: BindKind;
  systemId: string;
  password: string;
  systemType: string;
  addrTon: number;
  addrNpi: number;
  addressRange: string;
  interfaceVersion: number;
}

export class SmppTestRefused extends Error {}

/**
 * Connects and binds. A refused bind is not an error: it is returned, logged, and the socket closed,
 * so the modal can show why and keep the form.
 */
export async function openSession(req: OpenRequest): Promise<{ id: string; bound: boolean; status: number | null; reason: string | null }> {
  sweep();
  if ([...registry.values()].filter((s) => s.bound).length >= MAX_SESSIONS) {
    throw new SmppTestRefused(`There are already ${MAX_SESSIONS} test sessions open, which is the limit. Close one first.`);
  }
  const id = randomBytes(8).toString("hex");
  const session = smpp.connect({ host: req.host, port: req.port, auto_enquire_link_period: 30_000, connectTimeout: BIND_TIMEOUT_MS });
  const s: TestSession = {
    id, operator: req.operator, accountId: req.accountId, systemId: req.systemId, host: req.host, port: req.port,
    bindType: req.bindType, session, bound: false, closedBecause: null, events: [], nextSeq: 1, lastTouched: Date.now(),
  };
  registry.set(id, s);
  log(s, "note", null, null, `Connecting to ${req.host}:${req.port} …`);

  session.on("send", (pdu: Pdu) => log(s, "out", pdu.command, null, `→ ${pdu.command} ${describe(pdu)}`));
  session.on("pdu", (pdu: Pdu) => {
    const tone = pdu.command === "deliver_sm" ? (isReceipt(pdu) ? "receipt" : "mo")
      : pdu.command_status ? "error" : null;
    log(s, "in", pdu.command, tone, `← ${pdu.command} ${describe(pdu)}`);
  });
  //answered automatically: an unanswered deliver_sm is retried by the gateway, and an unanswered
  //enquire_link ends the session
  session.on("deliver_sm", (pdu: Pdu) => {
    session.send(pdu.response());
    if (isReceipt(pdu)) {
      const text = messageText(pdu.short_message, pdu.data_coding);
      const id2 = (pdu.receipted_message_id as string | undefined) ?? /id:(\S+)/.exec(text)?.[1] ?? "?";
      const stat = /stat:(\S+)/.exec(text)?.[1] ?? "?";
      log(s, "note", null, "receipt", `Receipt for ${id2}: ${stat}`);
    } else {
      log(s, "note", null, "mo", `Incoming message from ${pdu.source_addr}: "${messageText(pdu.short_message, pdu.data_coding)}"`);
    }
  });
  session.on("enquire_link", (pdu: Pdu) => session.send(pdu.response()));
  session.on("unbind", (pdu: Pdu) => {
    session.send(pdu.response());
    finish(s, "the gateway unbound the session");
  });
  session.on("close", () => finish(s, s.closedBecause ?? "the connection closed"));
  session.on("error", (e: Error) => log(s, "note", null, "error", `Error: ${e.message}`));

  try {
    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error(`could not connect to ${req.host}:${req.port} within ${BIND_TIMEOUT_MS / 1000}s`)), BIND_TIMEOUT_MS);
      session.once("connect", () => { clearTimeout(timer); resolve(); });
      session.once("error", (e) => { clearTimeout(timer); reject(e); });
    });
    const bind = req.bindType === "tx" ? session.bind_transmitter : req.bindType === "rx" ? session.bind_receiver : session.bind_transceiver;
    const resp = await new Promise<Pdu>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error(`no bind response within ${BIND_TIMEOUT_MS / 1000}s`)), BIND_TIMEOUT_MS);
      bind.call(session, {
        system_id: req.systemId,
        password: req.password,
        system_type: req.systemType,
        interface_version: req.interfaceVersion,
        addr_ton: req.addrTon,
        addr_npi: req.addrNpi,
        address_range: req.addressRange,
      }, (pdu: Pdu) => { clearTimeout(timer); resolve(pdu); });
    });
    if (resp.command_status !== 0) {
      const reason = statusText(resp.command_status);
      log(s, "note", null, "error", `Bind refused: ${reason}. Connection closed.`);
      s.closedBecause = `bind refused: ${reason}`;
      session.destroy();
      return { id, bound: false, status: resp.command_status, reason };
    }
    s.bound = true;
    log(s, "note", null, "ok", `Bound as ${req.systemId} · ${req.bindType.toUpperCase()}`);
    return { id, bound: true, status: 0, reason: null };
  } catch (err) {
    const reason = err instanceof Error ? err.message : String(err);
    log(s, "note", null, "error", `Could not bind: ${reason}`);
    s.closedBecause = reason;
    session.destroy();
    return { id, bound: false, status: null, reason };
  }
}

function finish(s: TestSession, because: string) {
  if (s.bound || !s.closedBecause) {
    s.bound = false;
    s.closedBecause = because;
    log(s, "note", null, null, `Session ended: ${because}.`);
  }
}

/** The session, if it is this operator's and on this account. */
function own(id: string, operator: string, accountId: string): TestSession | null {
  const s = registry.get(id);
  return s && s.operator === operator && s.accountId === accountId ? s : null;
}

export function readSession(id: string, operator: string, accountId: string, after: number): SmppTestState | null {
  sweep();
  const s = own(id, operator, accountId);
  if (!s) {
    return null;
  }
  s.lastTouched = Date.now();
  const events = s.events.filter((e) => e.seq > after).slice(0, 500);
  return {
    id: s.id, systemId: s.systemId, host: s.host, port: s.port, bindType: s.bindType, bound: s.bound,
    closedBecause: s.closedBecause, events, next: events.length ? events[events.length - 1].seq : after,
  };
}

export interface SubmitRequest {
  source: string;
  dest: string;
  text: string;
  encoding: SmsEncoding | "auto";
  registeredDelivery: number;
  sourceTon: number;
  sourceNpi: number;
  destTon: number;
  destNpi: number;
  tlvs: { key: string; value: string }[];
}

const registeredTlvs = new Set<string>();

/** A TLV row as the codec wants it: a name registered once per tag, and the value's bytes. */
function tlvParam(key: string, value: string): [string, Buffer] {
  const tag = tlvTag(key);
  if (tag == null) {
    throw new SmppTestRefused(`'${key}' does not name a TLV tag. Write it as name_0x1400 or name_5120.`);
  }
  const name = `tlv_${tag.toString(16).padStart(4, "0")}`;
  if (!registeredTlvs.has(name)) {
    smpp.addTLV(name, { id: tag, type: (smpp as unknown as { types: { tlv: Record<string, unknown> } }).types.tlv.buffer });
    registeredTlvs.add(name);
  }
  const v = value.trim();
  if (/^hex:/i.test(v)) {
    const hex = v.slice(4).replace(/\s+/g, "");
    if (!/^([0-9a-fA-F]{2})*$/.test(hex)) {
      throw new SmppTestRefused(`'${value}' is not hex: an even number of 0-9 and a-f after "hex:".`);
    }
    return [name, Buffer.from(hex, "hex")];
  }
  return [name, Buffer.from(value, "utf8")];
}

export async function submit(id: string, operator: string, accountId: string, req: SubmitRequest): Promise<SmppSubmitResult> {
  const s = own(id, operator, accountId);
  if (!s || !s.bound) {
    throw new SmppTestRefused("This session is not bound any more. Bind again.");
  }
  if (s.bindType === "rx") {
    throw new SmppTestRefused("A receiver bind cannot send. Bind as TRX or TX to send.");
  }
  s.lastTouched = Date.now();
  const encoding = req.encoding === "auto" ? autoEncoding(req.text) : req.encoding;
  let bytes: Buffer;
  try {
    bytes = Buffer.from(encodeSms(req.text, encoding));
  } catch (e) {
    throw new SmppTestRefused(e instanceof Error ? e.message : String(e));
  }
  const count = countSms(req.text, encoding);
  //one submit_sm whatever the length: up to 254 octets in short_message, beyond that in the
  //message_payload TLV, which the gateway splits for the vendor itself
  const body: Record<string, unknown> = bytes.length <= 254
    ? { short_message: bytes }
    : { short_message: Buffer.alloc(0), message_payload: bytes };
  const params: Record<string, unknown> = {
    source_addr: req.source,
    source_addr_ton: req.sourceTon,
    source_addr_npi: req.sourceNpi,
    destination_addr: req.dest,
    dest_addr_ton: req.destTon,
    dest_addr_npi: req.destNpi,
    data_coding: DATA_CODING[encoding],
    registered_delivery: req.registeredDelivery,
    ...body,
  };
  for (const row of req.tlvs) {
    if (!row.key.trim()) {
      continue;
    }
    const [name, value] = tlvParam(row.key, row.value);
    params[name] = value;
  }
  log(s, "note", null, null,
    `Sending ${count.units} ${encoding === "gsm7" ? "GSM-7" : encoding === "ucs2" ? "UCS-2" : "ASCII"} characters, ` +
    `${count.parts} part${count.parts === 1 ? "" : "s"}, registered_delivery=${req.registeredDelivery}`);
  const resp = await new Promise<Pdu>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`no submit_sm_resp within ${SUBMIT_TIMEOUT_MS / 1000}s`)), SUBMIT_TIMEOUT_MS);
    s.session.submit_sm(params, (pdu: Pdu) => { clearTimeout(timer); resolve(pdu); });
  });
  return { status: resp.command_status, statusText: statusText(resp.command_status), messageId: resp.message_id ?? null };
}

/**
 * Unbinds, waiting a moment for unbind_resp, then closes. Idempotent.
 *
 * @param keep keep the log readable afterwards (the Unbind button); otherwise the session is
 *     forgotten (closing the modal)
 */
export async function closeSession(id: string, operator: string, accountId: string, keep = false): Promise<boolean> {
  const s = own(id, operator, accountId);
  if (!s) {
    return false;
  }
  await shut(s, keep ? "unbound from the panel" : "the test window was closed", keep);
  return true;
}

async function shut(s: TestSession, because: string, keep = false) {
  if (!keep) {
    registry.delete(s.id);
  }
  s.lastTouched = Date.now();
  if (s.bound) {
    s.closedBecause = because;
    await new Promise<void>((resolve) => {
      const timer = setTimeout(resolve, 2_000);
      try {
        s.session.unbind({}, () => { clearTimeout(timer); resolve(); });
      } catch {
        clearTimeout(timer);
        resolve();
      }
    });
  }
  s.bound = false;
  try {
    s.session.close();
  } catch {
    //already gone
  }
}

/** The whole log as text, for the download. */
export function sessionLog(id: string, operator: string, accountId: string): string | null {
  const s = own(id, operator, accountId);
  if (!s) {
    return null;
  }
  const head = `SMPP client test · ${s.systemId} @ ${s.host}:${s.port} · ${s.bindType.toUpperCase()}\n`;
  return head + s.events.map((e) => `${e.at}  ${e.text}`).join("\n") + "\n";
}

/** Closes sessions idle past {@link IDLE_MS}, and forgets ones that ended long ago. */
function sweep() {
  const now = Date.now();
  for (const s of [...registry.values()]) {
    if (now - s.lastTouched > IDLE_MS) {
      void shut(s, `idle for ${IDLE_MS / 60_000} minutes`);
    }
  }
}
