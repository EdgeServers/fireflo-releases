/**
 * Who a session belongs to, and the predicates that decide it.
 *
 * <p><strong>A leaf module on purpose: it imports nothing.</strong> The decisions it encodes are the
 * boundaries between an admin, an operator and a customer, and a boundary worth testing has to be
 * reachable without dragging NextAuth, the database pool and half of Next.js in behind it. Keeping it
 * free of imports is what lets `roles.test.ts` run on Node's built-in runner with no test framework
 * at all.
 */

/**
 * Runs the gateway and, alone, manages who else may sign in.
 *
 * <p>Stamped only by the operator provider in `lib/auth.ts`, from an `app_user` row whose
 * `account_id` is null.
 */
export const ADMIN_ROLE = "admin";

/**
 * Runs the gateway. Everything an admin can do except touch `/cp/users`.
 *
 * <p>Stamped only by the operator provider in `lib/auth.ts`. The customer portal runs a separate
 * NextAuth instance on its own cookie and cannot mint this or {@link ADMIN_ROLE}.
 */
export const OPERATOR_ROLE = "operator";

/** Stamped only by the portal's instance in `lib/mis-auth.ts`. */
export const CUSTOMER_ROLE = "customer";

/**
 * The roles that open the control routes. {@link CUSTOMER_ROLE} is never in this list.
 *
 * <p>"Reseller" is deliberately not a role at all: it is `app_account.resells`, read fresh on every
 * portal request by `requireCustomer`, because a stored copy would go stale the moment an operator
 * cleared the flag.
 */
export const OPERATOR_ROLES: readonly string[] = [ADMIN_ROLE, OPERATOR_ROLE];

/** As much of a session as the decision needs. */
export interface RoleBearing {
  user?: { name?: string | null; role?: string | null } | null;
}

/**
 * Whether this session may reach the control routes.
 *
 * <p>This used to be "does the session have a name", which was right while an operator was the only
 * identity the application could issue. The customer portal ended that: a customer holds a real,
 * signed, valid session, and under a presence check it would have opened every control route --
 * margin, vendor names, every account's messages, credential editing.
 *
 * <p>So it is membership in {@link OPERATOR_ROLES} -- an equality against a closed list -- and never
 * a truthiness test on the role. A truthy check would admit any future role somebody adds without
 * thinking about this line.
 */
export function isOperatorSession(session: RoleBearing | null | undefined): boolean {
  const role = session?.user?.role;
  return !!session?.user?.name && typeof role === "string" && OPERATOR_ROLES.includes(role);
}

/** Whether this session may manage users. An operator is refused; only the exact role passes. */
export function isAdminSession(session: RoleBearing | null | undefined): boolean {
  return !!session?.user?.name && session?.user?.role === ADMIN_ROLE;
}
