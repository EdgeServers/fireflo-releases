import { configQuery } from "@/lib/config-db";
import { hashPassword } from "@/lib/password-hash";
import { ADMIN_ROLE, CUSTOMER_ROLE, OPERATOR_ROLE } from "@/lib/roles";
import { passwordStamp } from "@/lib/session-freshness";
import { type NewUserInput, type PublicUser, type Role, normaliseEmail } from "@/lib/user-types";

/**
 * The `app_user` table, from the operator's side.
 *
 * <p>Server-only: importing this pulls `pg`. The reseller's view of users -- scoped to the accounts
 * beneath it -- is `lib/mis-users.ts`, the way `accounts.ts` and `mis-accounts.ts` split the same
 * table. Only the two leaf modules, `password-hash.ts` and `user-types.ts`, are shared.
 *
 * <h2>The surface is in the WHERE clause</h2>
 *
 * <p>{@link findLoginUser} takes which door was knocked on and encodes it in SQL: the operator panel
 * sees only rows with no account and a panel role, the portal only customer rows with one. A row can
 * therefore never cross from one surface to the other, whatever the role check downstream does --
 * the two NextAuth instances stay separate at the query, not only at the cookie.
 */

const COLUMNS = `id, email, role, account_id, enabled, (password_hash IS NOT NULL) AS has_password,
  created_at, updated_at, last_login_at`;

interface Row {
  id: number | string;
  email: string;
  role: Role;
  account_id: string | null;
  enabled: boolean;
  has_password: boolean;
  created_at: Date | string;
  updated_at: Date | string;
  last_login_at: Date | string | null;
}

function toPublic(r: Row): PublicUser {
  return {
    id: Number(r.id),
    email: r.email,
    role: r.role,
    accountId: r.account_id,
    enabled: r.enabled,
    hasPassword: r.has_password,
    createdAt: new Date(r.created_at).toISOString(),
    updatedAt: new Date(r.updated_at).toISOString(),
    lastLoginAt: r.last_login_at ? new Date(r.last_login_at).toISOString() : null,
  };
}

export async function listUsers(filter: { accountId?: string | null; role?: Role | null } = {}): Promise<PublicUser[]> {
  const where: string[] = [];
  const params: unknown[] = [];
  if (filter.accountId) {
    params.push(filter.accountId);
    where.push(`account_id = $${params.length}`);
  }
  if (filter.role) {
    params.push(filter.role);
    where.push(`role = $${params.length}`);
  }
  const rows = await configQuery<Row>(
    `SELECT ${COLUMNS} FROM app_user ${where.length ? `WHERE ${where.join(" AND ")}` : ""}
     ORDER BY role, lower(email)`,
    params
  );
  return rows.map(toPublic);
}

export async function getUserById(id: number): Promise<PublicUser | null> {
  const rows = await configQuery<Row>(`SELECT ${COLUMNS} FROM app_user WHERE id = $1`, [id]);
  return rows.length ? toPublic(rows[0]) : null;
}

/** What `authorize` needs and nothing a response may carry. */
export interface LoginUser {
  id: number;
  email: string;
  role: Role;
  accountId: string | null;
  passwordHash: string | null;
  /** `password_changed_at` as the token stamp -- see lib/session-freshness.ts. */
  passwordChangedAt: number | null;
}

/**
 * The row a sign-in attempt names, if the door it came through may see it.
 *
 * <p>Enabled only, and for the portal the account must be enabled too. A disabled user is
 * indistinguishable from an unknown one to the caller, which is the point.
 */
export async function findLoginUser(email: string, surface: "operator" | "portal"): Promise<LoginUser | null> {
  const address = normaliseEmail(email);
  if (!address) {
    return null;
  }
  const rows = surface === "operator"
    ? await configQuery<LoginRow>(
      `SELECT id, email, role, account_id, password_hash, password_changed_at FROM app_user
        WHERE lower(email) = lower($1) AND enabled AND account_id IS NULL AND role IN ($2, $3)`,
      [address, ADMIN_ROLE, OPERATOR_ROLE]
    )
    : await configQuery<LoginRow>(
      `SELECT u.id, u.email, u.role, u.account_id, u.password_hash, u.password_changed_at FROM app_user u
         JOIN app_account a ON a.id = u.account_id
        WHERE lower(u.email) = lower($1) AND u.enabled AND a.enabled AND u.role = $2`,
      [address, CUSTOMER_ROLE]
    );
  if (!rows.length) {
    return null;
  }
  const r = rows[0];
  return {
    id: Number(r.id),
    email: r.email,
    role: r.role,
    accountId: r.account_id,
    passwordHash: r.password_hash,
    passwordChangedAt: passwordStamp(r.password_changed_at),
  };
}

interface LoginRow {
  id: number | string;
  email: string;
  role: Role;
  account_id: string | null;
  password_hash: string | null;
  password_changed_at: Date | string | null;
}

/**
 * Is this user still allowed in? Read fresh per request by `requireOperator`, like `requireCustomer`
 * does. `passwordChangedAt` is compared against the token's stamp there -- see
 * lib/session-freshness.ts.
 */
export async function liveRole(id: number): Promise<{ role: Role; enabled: boolean; passwordChangedAt: Date | string | null } | null> {
  const rows = await configQuery<{ role: Role; enabled: boolean; password_changed_at: Date | string | null }>(
    "SELECT role, enabled, password_changed_at FROM app_user WHERE id = $1",
    [id]
  );
  return rows.length ? { role: rows[0].role, enabled: rows[0].enabled, passwordChangedAt: rows[0].password_changed_at } : null;
}

export async function countEnabledAdmins(): Promise<number> {
  const rows = await configQuery<{ n: string }>(
    "SELECT count(*) AS n FROM app_user WHERE role = $1 AND enabled AND account_id IS NULL",
    [ADMIN_ROLE]
  );
  return Number(rows[0]?.n ?? 0);
}

/**
 * Whether any admin or operator row exists, enabled or not -- the question the env fallback asks.
 *
 * <p>Answers false, not a throw, when the table is missing (SQL state 42P01): the panel was upgraded
 * before the gateway ran V1.52.0, and the env operator is the only way in until it does.
 */
export async function panelUsersExist(): Promise<boolean> {
  try {
    const rows = await configQuery<{ n: string }>(
      "SELECT count(*) AS n FROM app_user WHERE account_id IS NULL AND role IN ($1, $2)",
      [ADMIN_ROLE, OPERATOR_ROLE]
    );
    return Number(rows[0]?.n ?? 0) > 0;
  } catch (err) {
    if ((err as { code?: string })?.code === "42P01") {
      return false;
    }
    throw err;
  }
}

export class DuplicateUserError extends Error {
  constructor(email: string) {
    super(`${email} already has a user.`);
    this.name = "DuplicateUserError";
  }
}

/** Inserts the row. The caller has already validated the shape and judged the password. */
export async function createUser(input: NewUserInput): Promise<PublicUser> {
  const email = normaliseEmail(input.email);
  if (!email) {
    throw new Error("Enter an email address.");
  }
  const hash = input.password ? await hashPassword(input.password) : null;
  try {
    const rows = await configQuery<Row>(
      `INSERT INTO app_user (email, role, account_id, password_hash) VALUES ($1, $2, $3, $4)
       RETURNING ${COLUMNS}`,
      [email, input.role, input.role === CUSTOMER_ROLE ? input.accountId?.trim() || null : null, hash]
    );
    return toPublic(rows[0]);
  } catch (err) {
    if ((err as { code?: string })?.code === "23505") {
      throw new DuplicateUserError(email);
    }
    throw err;
  }
}

/**
 * Sets the password and stamps `password_changed_at`, which signs out every session minted before
 * this moment on its next request (lib/session-freshness.ts).
 *
 * @return the new stamp, for a caller changing its OWN password to re-mint its session with, or
 *     null when there is no such row
 */
export async function setPassword(id: number, password: string): Promise<number | null> {
  const rows = await configQuery<{ password_changed_at: Date | string }>(
    `UPDATE app_user SET password_hash = $2, updated_at = now(), password_changed_at = now()
      WHERE id = $1 RETURNING password_changed_at`,
    [id, await hashPassword(password)]
  );
  return rows.length ? passwordStamp(rows[0].password_changed_at) : null;
}

export async function setEnabled(id: number, enabled: boolean): Promise<boolean> {
  const rows = await configQuery<{ id: number }>(
    "UPDATE app_user SET enabled = $2, updated_at = now() WHERE id = $1 RETURNING id",
    [id, enabled]
  );
  return rows.length > 0;
}

/** Between the two panel roles only: a customer cannot become an operator, nor the reverse. */
export async function setRole(id: number, role: typeof ADMIN_ROLE | typeof OPERATOR_ROLE): Promise<boolean> {
  const rows = await configQuery<{ id: number }>(
    `UPDATE app_user SET role = $2, updated_at = now()
      WHERE id = $1 AND account_id IS NULL AND role IN ($3, $4) RETURNING id`,
    [id, role, ADMIN_ROLE, OPERATOR_ROLE]
  );
  return rows.length > 0;
}

export async function touchLastLogin(id: number): Promise<void> {
  await configQuery("UPDATE app_user SET last_login_at = now() WHERE id = $1", [id]);
}

/**
 * Makes sure the address on an account can sign in to the portal.
 *
 * <p>Transitional: operators and resellers grant portal access today by typing an email into the
 * account editor, and until the users page replaces that gesture it has to keep meaning what it
 * meant. Insert-if-absent and never a delete -- clearing the email on the account does not remove a
 * person, and an address already held by a user on another account is left alone (the unique index
 * says no, and this says nothing).
 */
export async function ensureCustomerUser(accountId: string, email: string | null | undefined): Promise<void> {
  const address = email ? normaliseEmail(email) : null;
  if (!address) {
    return;
  }
  await configQuery(
    `INSERT INTO app_user (email, role, account_id) VALUES ($1, $2, $3)
     ON CONFLICT (lower(email)) DO NOTHING`,
    [address, CUSTOMER_ROLE, accountId]
  );
}

/**
 * Sets the portal password of the login at `email` on `accountId`, creating the login if the
 * address is new to the account -- the account editor's "set the portal password" box.
 *
 * <p>Refused, not redirected, when the address belongs to a user on another account: the unique
 * index says so and the operator is told, rather than one account quietly changing another's key.
 */
export async function setCustomerPassword(accountId: string, email: string, password: string): Promise<void> {
  const address = normaliseEmail(email);
  if (!address) {
    throw new Error("Enter an email address before setting a portal password.");
  }
  await ensureCustomerUser(accountId, address);
  const rows = await configQuery<{ id: number }>(
    `UPDATE app_user SET password_hash = $3, updated_at = now(), password_changed_at = now()
      WHERE lower(email) = lower($1) AND account_id = $2 AND role = $4 RETURNING id`,
    [address, accountId, await hashPassword(password), CUSTOMER_ROLE]
  );
  if (!rows.length) {
    throw new DuplicateUserError(address);
  }
}

/**
 * Sets or removes the password of one portal login, named by id and checked against the account, so
 * an id from another account changes nothing. Null removes it: that login signs in by link again.
 */
export async function setAccountUserPassword(accountId: string, userId: number, password: string | null): Promise<string | null> {
  const rows = await configQuery<{ email: string }>(
    `UPDATE app_user SET password_hash = $3, updated_at = now(), password_changed_at = now()
      WHERE id = $1 AND account_id = $2 AND role = $4 RETURNING email`,
    [userId, accountId, password ? await hashPassword(password) : null, CUSTOMER_ROLE]
  );
  return rows[0]?.email ?? null;
}

/** Turns one portal login on or off, checked against the account like the password above. */
export async function setAccountUserEnabled(accountId: string, userId: number, enabled: boolean): Promise<string | null> {
  const rows = await configQuery<{ email: string }>(
    `UPDATE app_user SET enabled = $3, updated_at = now()
      WHERE id = $1 AND account_id = $2 AND role = $4 RETURNING email`,
    [userId, accountId, enabled, CUSTOMER_ROLE]
  );
  return rows[0]?.email ?? null;
}

/** A signed-in customer, with the hash a password change has to check the current one against. */
export async function customerLogin(id: number): Promise<{ email: string; passwordHash: string | null } | null> {
  const rows = await configQuery<{ email: string; password_hash: string | null }>(
    "SELECT email, password_hash FROM app_user WHERE id = $1 AND role = $2 AND enabled",
    [id, CUSTOMER_ROLE]
  );
  return rows.length ? { email: rows[0].email, passwordHash: rows[0].password_hash } : null;
}

/**
 * A customer setting their own password from the portal. By id, from the session, never by address.
 *
 * @return the new `password_changed_at` stamp, so the route can re-mint the session that made the
 *     change rather than sign it out with the rest; null when there is no such row
 */
export async function setOwnPassword(id: number, password: string): Promise<number | null> {
  const rows = await configQuery<{ password_changed_at: Date | string }>(
    `UPDATE app_user SET password_hash = $2, updated_at = now(), password_changed_at = now()
      WHERE id = $1 AND role = $3 AND enabled RETURNING password_changed_at`,
    [id, await hashPassword(password), CUSTOMER_ROLE]
  );
  return rows.length ? passwordStamp(rows[0].password_changed_at) : null;
}
