/**
 * Timestamps as the person reading them would write them.
 *
 * <p>Every date in this panel was rendered with a bare `toLocaleString()` — thirty-odd call sites,
 * no options, so the format followed the browser's locale and varied between `8/15/2026, 2:32:07 PM`
 * and `15/08/2026, 14:32:07` for the same instant. Fine on its own; less fine in a table where a
 * column of them has to be scanned, and not fine at all on the customer portal, which rendered the
 * raw ISO string instead.
 *
 * <p>Database-free, so a client component can import it.
 */

/**
 * The one format the tables use.
 *
 * <p>`medium` on both parts rather than `short`: short drops the seconds, and two messages sent in
 * the same minute is the ordinary case for this traffic — a column that shows them as identical is
 * a column that cannot be used to establish an order. It also spells the month, which removes the
 * day/month ambiguity that makes `08/09` unreadable to half the audience.
 *
 * <p>The zone is the reader's own and is deliberately not repeated on every row; the table names it
 * once. See {@link browserTimeZone}.
 *
 * @param value an ISO string from the API, or a Date
 * @return the stored text unchanged when it is not a date, rather than the string "Invalid Date"
 */
export function formatTimestamp(value: string | Date | null | undefined): string {
  const at = parse(value);
  //showing what is actually stored is more use to whoever has to explain it than a formatter's
  //complaint about it
  return at === null
    ? asText(value)
    : at.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "medium" });
}

/**
 * Just the date, for a column that is about a day rather than a moment.
 *
 * <p>Use sparingly. Most fields that look like dates are timestamps, and dropping the time from one
 * of those loses the ordering within a day — which is the only ordering anybody asks a support
 * question about.
 */
export function formatDate(value: string | Date | null | undefined): string {
  const at = parse(value);
  return at === null ? asText(value) : at.toLocaleDateString(undefined, { dateStyle: "medium" });
}

/**
 * The clock time, for something that just happened — **unless it did not**.
 *
 * <p>Live pages read better with a bare `14:32:07`: a health snapshot, a metrics read, a "saved at"
 * confirmation. All of those are always today, so the date would be noise on every render.
 *
 * <p><strong>The fallback is not decoration.</strong> The same shape is used for things that are
 * only usually recent — a broker queue entry's enqueue time is the obvious one, and the whole reason
 * that table exists is the case where a message has been sitting there. Rendering yesterday's
 * backlog as `14:32:07` states the one thing the reader is trying to find out, incorrectly. So
 * anything not on today's local date falls back to the full timestamp and is visibly wider.
 */
export function formatClockTime(value: string | Date | null | undefined): string {
  const at = parse(value);
  if (at === null) {
    return asText(value);
  }
  const now = new Date();
  const today =
    at.getFullYear() === now.getFullYear()
    && at.getMonth() === now.getMonth()
    && at.getDate() === now.getDate();

  return today
    ? at.toLocaleTimeString(undefined, { timeStyle: "medium" })
    : formatTimestamp(at);
}

/** @return null when there is nothing to format, so each caller decides what to show instead */
function parse(value: string | Date | null | undefined): Date | null {
  if (value == null || value === "") {
    return null;
  }
  const at = value instanceof Date ? value : new Date(value);
  return Number.isNaN(at.getTime()) ? null : at;
}

/** What a value that is not a date renders as. See {@link formatTimestamp}. */
function asText(value: string | Date | null | undefined): string {
  return value == null || value === "" ? "" : String(value);
}

/**
 * The zone the browser is rendering in, e.g. `Asia/Kolkata`.
 *
 * <p>Named once beside a table rather than appended to every row. A localised timestamp with no zone
 * is a guess the reader has to make, and on the customer portal the reader is frequently not in the
 * same country as the operator — so "14:32" and "09:02" are the same message and nobody can tell.
 *
 * @return null when the environment will not say, which includes the server render
 */
export function browserTimeZone(): string | null {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || null;
  } catch {
    return null;
  }
}
