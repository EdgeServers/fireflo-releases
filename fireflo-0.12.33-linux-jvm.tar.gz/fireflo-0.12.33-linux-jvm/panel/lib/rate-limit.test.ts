import { test } from "node:test";
import assert from "node:assert/strict";
import { limiter } from "./rate-limit.ts";

/**
 * The counter in front of the one endpoint anybody can reach without signing in.
 *
 * <p>Its job is narrow: keep a flood from reaching a four-connection database pool that the whole
 * panel shares. So the properties worth pinning are that it actually refuses, that one caller
 * cannot spend another's allowance, and that it cannot grow without bound — not that it is precise.
 */

test("a key gets exactly its allowance and then stops", () => {
  const gate = limiter(3, 60_000);

  assert.equal(gate.allow("a"), true);
  assert.equal(gate.allow("a"), true);
  assert.equal(gate.allow("a"), true);
  assert.equal(gate.allow("a"), false, "the fourth is refused");
  assert.equal(gate.allow("a"), false, "and stays refused");
});

test("keys do not spend each other's allowance", () => {
  //the property that matters for an IP bucket: one noisy address must not lock out an office
  const gate = limiter(1, 60_000);

  assert.equal(gate.allow("1.2.3.4"), true);
  assert.equal(gate.allow("1.2.3.4"), false);
  assert.equal(gate.allow("5.6.7.8"), true, "a different origin is unaffected");
});

test("the window expires, and the allowance comes back", () => {
  const gate = limiter(1, 1);

  assert.equal(gate.allow("a"), true);
  assert.equal(gate.allow("a"), false);

  const until = Date.now() + 5;
  while (Date.now() < until) {
    //a 1ms window, spun rather than slept so the test stays synchronous
  }
  assert.equal(gate.allow("a"), true);
});

test("the map is bounded, and clearing it errs towards letting people in", () => {
  //cleared wholesale rather than swept: a bounded map that cannot leak beats an exact one that
  //can, and the cost is that everybody gets a fresh allowance at the moment it happens
  const gate = limiter(1, 60_000, 4);

  //the clear fires when the map is already PAST its ceiling, so it takes one more key than the
  //ceiling to trigger it. Worth writing down: the map's high-water mark is maxKeys + 1, not maxKeys
  for (const key of ["a", "b", "c", "d", "e", "f"]) {
    assert.equal(gate.allow(key), true);
  }
  //"a" went with the rest when the map was dropped, so it has a fresh allowance
  assert.equal(gate.allow("a"), true);
});

test("an allowance of zero refuses everything, rather than one through", () => {
  //not a configuration anything uses, but a limiter whose first call slips past its own limit is
  //the kind of off-by-one that only shows up when somebody sets it to zero to switch a route off
  const gate = limiter(0, 60_000);

  assert.equal(gate.allow("a"), false);
});
