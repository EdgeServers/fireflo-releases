import { test } from "node:test";
import assert from "node:assert/strict";
import type { RouteRule } from "./routing-types.ts";
import {
  lockedReceiptListener,
  lockedRuleProblem,
  reconcileReceiptRules,
  type Listener,
} from "./system-routes.ts";

/**
 * The receipt rules the panel keeps for itself.
 *
 * <p>The starting point most of these use is the gateway's own bootstrap: outbound types to
 * `MESSAGE`, then one unqualified `type == 18 → smppserver.smpp`, with ids from 1000. That is the
 * table on localhost when a second listener, ThinkPad, was added and got no receipts.
 */

const smpp: Listener = { name: "smpp", type: "smppserver", enabled: true };
const thinkpad: Listener = { name: "ThinkPad", type: "smppserver", enabled: true };

function rule(partial: Partial<RouteRule>): RouteRule {
  return { id: null, target: "MESSAGE", copied: false, label: null, enabled: true, conditions: [], filters: [], ...partial };
}

const type = (value: string) => ({ field: "type", operator: "==", value, negate: false });
const from = (fullName: string) => ({ field: "ingateway", operator: "equals", value: fullName, negate: false });

function bootstrap(): RouteRule[] {
  return [
    ...["0", "11", "14", "17", "10"].map((t, i) => rule({ id: 1000 + i, conditions: [type(t)] })),
    rule({ id: 1005, target: "smppserver.smpp", conditions: [type("18")] }),
  ];
}

function receiptRuleFor(rules: RouteRule[], listeners: Listener[], who: Listener): RouteRule[] {
  return rules.filter((r) => lockedReceiptListener(r, listeners) === who);
}

test("one listener: the bootstrap's bare rule is its locked rule, and nothing changes", () => {
  const { rules, changes } = reconcileReceiptRules(bootstrap(), [smpp]);

  assert.deepEqual(changes, []);
  assert.deepEqual(rules, bootstrap(), "same rules, same ids, same order -- and the same metrics key");
  assert.equal(lockedReceiptListener(bootstrap()[5], [smpp]), smpp);
});

test("a second listener: the bare rule is narrowed in place and the new one gets its own", () => {
  const listeners = [smpp, thinkpad];
  const { rules, changes } = reconcileReceiptRules(bootstrap(), listeners);

  assert.equal(changes.length, 2, changes.join("\n"));
  const narrowed = rules.find((r) => r.id === 1005)!;
  assert.deepEqual(narrowed.conditions, [type("18"), from("smppserver.smpp")]);
  const added = receiptRuleFor(rules, listeners, thinkpad);
  assert.equal(added.length, 1);
  assert.deepEqual(added[0].conditions, [type("18"), from("smppserver.ThinkPad")]);
  assert.equal(added[0].target, "smppserver.ThinkPad");
  assert.equal(added[0].label, "system:dlr-return:ThinkPad");
  //with the outbound rules first in this table, the new rule goes straight after the other receipt
  //rule rather than to the top, so the order an operator set is left alone
  assert.equal(rules.indexOf(added[0]), rules.indexOf(narrowed) + 1);
});

test("a third listener adds one more and touches nothing else", () => {
  const two = reconcileReceiptRules(bootstrap(), [smpp, thinkpad]).rules;
  const third: Listener = { name: "edge", type: "smppserver", enabled: true };
  const { rules, changes } = reconcileReceiptRules(two, [smpp, thinkpad, third]);

  assert.equal(changes.length, 1);
  assert.equal(rules.length, two.length + 1);
  assert.equal(receiptRuleFor(rules, [smpp, thinkpad, third], third).length, 1);
});

test("a table with no receipt rule at all gets them at the top", () => {
  const outbound = bootstrap().slice(0, 5);
  const { rules } = reconcileReceiptRules(outbound, [smpp]);

  assert.equal(rules[0].target, "smppserver.smpp");
  assert.deepEqual(rules[0].conditions, [type("18"), from("smppserver.smpp")], "a new rule is always qualified");
});

test("a disabled listener keeps its rule, so enabling it needs nothing", () => {
  const off = { ...thinkpad, enabled: false };
  const { rules } = reconcileReceiptRules(bootstrap(), [smpp, off]);

  assert.equal(receiptRuleFor(rules, [smpp, off], off).length, 1);
});

test("a locked rule found switched off is switched back on", () => {
  const stored = bootstrap();
  stored[5] = { ...stored[5], enabled: false };
  const { rules, changes } = reconcileReceiptRules(stored, [smpp]);

  assert.equal(rules[5].enabled, true);
  assert.equal(changes.length, 1);
});

test("running it twice changes nothing the second time", () => {
  const once = reconcileReceiptRules(bootstrap(), [smpp, thinkpad]).rules;
  const twice = reconcileReceiptRules(once, [smpp, thinkpad]);

  assert.deepEqual(twice.changes, []);
  assert.deepEqual(twice.rules, once);
});

test("a receipt rule that does more than return receipts is not a locked rule", () => {
  const listeners = [smpp];
  assert.equal(lockedReceiptListener(rule({ target: "smpp", conditions: [type("18")], copied: true }), listeners), null);
  assert.equal(lockedReceiptListener(rule({ target: "smpp", conditions: [type("18")], filters: ["x"] }), listeners), null);
  assert.equal(lockedReceiptListener(rule({ target: "smpp", conditions: [type("18"), type("0")] }), listeners), null);
  assert.equal(lockedReceiptListener(rule({ target: "MESSAGE", conditions: [type("18")] }), listeners), null);
  assert.equal(lockedReceiptListener(rule({ target: "smpp", conditions: [type("18")] }), listeners), smpp,
    "the bare spelling of the target counts");
});

test("with two listeners a bare rule belongs to nobody until it is narrowed", () => {
  assert.equal(lockedReceiptListener(bootstrap()[5], [smpp, thinkpad]), null);
});

const twoListeners = () => reconcileReceiptRules(bootstrap(), [smpp, thinkpad]).rules
  .map((r, i) => (r.id == null ? { ...r, id: 2000 + i } : r));

test("a save that leaves a locked rule out is refused", () => {
  const stored = twoListeners();
  const after = stored.filter((r) => r.target !== "smppserver.ThinkPad");

  assert.match(lockedRuleProblem(stored, after, [smpp, thinkpad]) ?? "", /ThinkPad.*can't be deleted/);
});

test("switching one off, retargeting it, changing its conditions or its note is refused", () => {
  const stored = twoListeners();
  const listeners = [smpp, thinkpad];
  const at = stored.findIndex((r) => r.target === "smppserver.ThinkPad");
  const edit = (change: Partial<RouteRule>) => stored.map((r, i) => (i === at ? { ...r, ...change } : r));

  assert.match(lockedRuleProblem(stored, edit({ enabled: false }), listeners) ?? "", /switched off/);
  assert.match(lockedRuleProblem(stored, edit({ target: "MESSAGE" }), listeners) ?? "", /can't be changed/);
  assert.match(lockedRuleProblem(stored, edit({ conditions: [type("18")] }), listeners) ?? "", /can't be changed/);
  assert.match(lockedRuleProblem(stored, edit({ label: "mine" }), listeners) ?? "", /note/);
});

test("moving a locked rule, or editing any other rule, is allowed", () => {
  const stored = twoListeners();
  const listeners = [smpp, thinkpad];

  assert.equal(lockedRuleProblem(stored, [...stored].reverse(), listeners), null);
  const retargeted = stored.map((r) => (r.id === 1000 ? { ...r, target: "vendor-b" } : r));
  assert.equal(lockedRuleProblem(stored, retargeted, listeners), null);
  assert.equal(lockedRuleProblem(stored, stored.filter((r) => r.id !== 1000), listeners), null);
});
