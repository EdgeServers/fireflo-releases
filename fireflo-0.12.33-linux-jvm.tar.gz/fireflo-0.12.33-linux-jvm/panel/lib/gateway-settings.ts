import { configQuery, inTransaction } from "@/lib/config-db";

/**
 * Gateway-wide configuration: the two tiers above a worker's own settings.
 *
 * <h2>Three tiers, and this file owns the top two</h2>
 *
 * <p>The gateway resolves configuration in three widening steps, and until now the panel could only
 * see and write the narrowest:
 *
 * <ul>
 *   <li>`outSms.instance.&lt;name&gt;.&lt;key&gt;` — one worker. `app_worker_property`, edited by
 *       the vendor and listener forms through {@code setWorkerProperty}.
 *   <li>`outSms.default.&lt;key&gt;` — every vendor and listener. Resolved by
 *       `FireFloConfigurationHandler.get()`, which rewrites an unresolved `.instance.` key into a
 *       `.default.` one and looks again.
 *   <li>`smsg.*` — the whole gateway, both ingresses. Includes `smsg.restapi.*`, which is the REST
 *       endpoint's own configuration.
 * </ul>
 *
 * <p>Both of the upper tiers live in `app_config`, keyed exactly as the gateway reads them, and
 * `DbConfigPoller` merges them into the same snapshot as worker rows. So there is nothing to
 * translate here: the key an operator sets is the key the gateway looks up.
 *
 * <h2>This is the panel's first write to app_config</h2>
 *
 * <p>It had never written this table — only read a handful of keys for display. Everything
 * gateway-level was hand-edited or SQL. That is why callers must go through a curated catalogue
 * rather than passing arbitrary keys: `smsg.ops.token` and `smsg.ops.admin.token` are credentials
 * and the database keys will stop the gateway reading its own configuration. See
 * `lib/gateway-setting-fields.ts` — an editor for a credential is how a credential leaks.
 */

/** One gateway-level value as stored. */
export interface GatewaySetting {
  key: string;
  value: string | null;
  enabled: boolean;
}

/**
 * Every gateway-level key currently set, by key.
 *
 * <p>Returns **null when it cannot be read at all**, which is not the same as an empty map. In file
 * mode the gateway's configuration lives in `smsg.properties` and this panel does not read it; an
 * empty map would say "nothing is set" when the truth is "this panel cannot see". The same honesty
 * `refusesUnrated` documents at more length, for the same reason: a screen that reports a default
 * it did not read is worse than one that admits it does not know.
 *
 * <p>Disabled rows are returned rather than filtered. The gateway ignores them —
 * `DbConfigPoller` selects `WHERE enabled` — and an operator needs to see a row that is present but
 * switched off, or "I set that and nothing happened" has no visible cause.
 */
export async function readGatewaySettings(prefixes: string[]): Promise<Map<string, GatewaySetting> | null> {
  if (!prefixes.length) {
    return new Map();
  }
  try {
    const rows = await configQuery<{ key: string; value: string | null; enabled: boolean }>(
      `SELECT key, value, enabled
         FROM app_config
        WHERE ${prefixes.map((_, i) => `key LIKE $${i + 1}`).join(" OR ")}`,
      prefixes.map((p) => `${p}%`)
    );
    return new Map(rows.map((r) => [r.key, { key: r.key, value: r.value, enabled: r.enabled }]));
  } catch {
    //cannot be read, which the caller must not render as "not set"
    return null;
  }
}

/**
 * Sets one gateway-level key, or clears it.
 *
 * <p><strong>An empty value deletes the row rather than storing `''`.</strong> This is the whole
 * reason inheritance is expressible: a worker key resolves upwards only when it is absent, and the
 * same is true one tier up — an `outSms.default.<key>` of `''` would shadow the coded default with
 * a blank rather than stepping out of the way. {@code setWorkerProperty} already does exactly this
 * for the tier below, and the two must agree or "clear" means different things at different depths.
 *
 * <p>Returns the previous value so a caller can write an audit line that says what changed rather
 * than only that something did. Null means there was no row.
 */
export async function setGatewaySetting(key: string, value: string): Promise<{ previous: string | null }> {
  return inTransaction(async (client) => {
    const before = await client.query<{ value: string | null }>(
      "SELECT value FROM app_config WHERE key = $1",
      [key]
    );
    const previous = before.rows.length ? before.rows[0].value : null;

    if (value.trim() === "") {
      await client.query("DELETE FROM app_config WHERE key = $1", [key]);
      return { previous };
    }

    //enabled is reset to true on write. A row an operator is deliberately editing is one they mean
    //to take effect, and leaving it disabled would save a value the gateway then ignores -- the
    //failure this panel has spent a lot of comments trying not to have
    await client.query(
      `INSERT INTO app_config (key, value, enabled, updated_at)
            VALUES ($1, $2, true, now())
       ON CONFLICT (key) DO UPDATE
            SET value = EXCLUDED.value, enabled = true, updated_at = now()`,
      [key, value]
    );
    return { previous };
  });
}
