/**
 * The home page's figures from rows it already has, with no database import.
 *
 * <p>Split out of `metrics-queries.ts` so the snapshot module (`overview-snapshot.ts`), which is
 * pure and tested without a database, can derive the tile from the series and the revenue rows the
 * same way the route always did.
 */

export interface TrafficBucket {
  /** A UTC instant as `YYYY-MM-DDTHH:MM:SSZ`: the hour, or the start of the billing day. */
  bucket: string;
  submitted: number;
  delivered: number;
  failed: number;
  expired: number;
  pending: number;
}

export interface RevenueRow {
  accountId: string | null;
  product: string | null;
  messages: number;
  revenue: number;
  cost: number;
  margin: number;
  pendingRevenue: number;
  /** The billing day, `YYYY-MM-DD`, when the rows were asked for by day; absent otherwise. */
  day?: string;
}

export interface Totals {
  messages: number;
  delivered: number;
  failed: number;
  pending: number;
  revenue: number;
  cost: number;
  margin: number;
  deliveryRate: number | null;
}

/**
 * The headline figures, from the series and the revenue rows the page already has.
 *
 * <p>Pure, so the overview route runs `trafficOverTime` once and derives the tile from it rather
 * than asking the database the same question twice a minute per open tab (Audit CP-P1).
 */
export function totalsOf(traffic: TrafficBucket[], revenue: RevenueRow[]): Totals {
  const messages = sum(traffic, (t) => t.submitted);
  const delivered = sum(traffic, (t) => t.delivered);
  const failed = sum(traffic, (t) => t.failed) + sum(traffic, (t) => t.expired);
  const settled = delivered + failed;

  return {
    messages,
    delivered,
    failed,
    pending: sum(traffic, (t) => t.pending),
    revenue: sum(revenue, (r) => r.revenue),
    cost: sum(revenue, (r) => r.cost),
    margin: sum(revenue, (r) => r.margin),
    deliveryRate: settled === 0 ? null : delivered / settled,
  };
}

/**
 * Revenue rows summed per (account, product), dropping the day.
 *
 * <p>How the snapshot turns "finished days, kept" plus "today, re-read" back into the rows the
 * page shows. The margin is recomputed from the two sums, as `revenueByAccount` computes it, so a
 * merge cannot carry a row-set mistake into it. Ordered by revenue, heaviest first, as the query is.
 */
export function sumRevenueByAccount(rows: readonly RevenueRow[]): RevenueRow[] {
  const byKey = new Map<string, RevenueRow>();
  for (const r of rows) {
    //JSON, not a joined string: an id is free text and a separator could be in it
    const key = JSON.stringify([r.accountId, r.product]);
    const acc = byKey.get(key);
    if (acc) {
      acc.messages += r.messages;
      acc.revenue += r.revenue;
      acc.cost += r.cost;
      acc.pendingRevenue += r.pendingRevenue;
      acc.margin = acc.revenue - acc.cost;
    } else {
      byKey.set(key, {
        accountId: r.accountId,
        product: r.product,
        messages: r.messages,
        revenue: r.revenue,
        cost: r.cost,
        margin: r.revenue - r.cost,
        pendingRevenue: r.pendingRevenue,
      });
    }
  }
  return [...byKey.values()].sort((a, b) => b.revenue - a.revenue);
}

function sum<T>(rows: readonly T[], pick: (row: T) => number): number {
  return rows.reduce((acc, row) => acc + pick(row), 0);
}
