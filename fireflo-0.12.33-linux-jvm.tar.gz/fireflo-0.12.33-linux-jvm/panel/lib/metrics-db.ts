import { Pool, type QueryResultRow } from "pg";

/**
 * Read-only access to the gateway's call-record database.
 *
 * <p>This module never issues DDL and never writes. That is not a convention to be relied on
 * alone -- the connection should use a role granted only SELECT, so a mistake here cannot damage
 * billing records. The sibling panel's Postgres helper runs a CREATE TABLE block on connect, which
 * is precisely why this is a separate module rather than a reuse of it.
 *
 * <p>Every query is parameterised. Nothing here interpolates a value, an identifier or an
 * interval into SQL.
 */
let pool: Pool | null = null;

export function isConfigured(): boolean {
  return !!process.env.METRICS_DATABASE_URL?.trim();
}

function getPool(): Pool {
  const url = process.env.METRICS_DATABASE_URL?.trim();
  if (!url) {
    throw new Error("METRICS_DATABASE_URL is not set");
  }
  if (!pool) {
    pool = new Pool({
      connectionString: url,
      max: 8,
      connectionTimeoutMillis: 5_000,
      idleTimeoutMillis: 30_000,
      //a dashboard query that has not answered in ten seconds is not going to be useful, and
      //holding the connection helps nobody
      statement_timeout: 10_000,
    });
  }
  return pool;
}

export async function query<T extends QueryResultRow>(sql: string, params: unknown[] = []): Promise<T[]> {
  const result = await getPool().query<T>(sql, params);
  return result.rows;
}

/** Test and shutdown helper. */
export async function closeMetricsDb(): Promise<void> {
  const existing = pool;
  pool = null;
  await existing?.end();
}
