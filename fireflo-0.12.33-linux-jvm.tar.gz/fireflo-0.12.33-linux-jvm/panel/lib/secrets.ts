/**
 * How a secret crosses the boundary between the browser and the database.
 *
 * <p>The existing convention — substitute `********` on read, and on write treat that exact string
 * as "leave it alone" — works, and it has two flaws that only matter once the secret is a bind
 * password rather than a vendor setting:
 *
 * <ol>
 *   <li><strong>A placeholder for a key with nothing stored resolves to empty and is then skipped.</strong>
 *       For a worker property that silently restores a coded default. For a credential it produces a
 *       row that fails `Credential.isValid()`, which the gateway's poller skips with a warning and no
 *       error — so the credential exists, is enabled, and is not in the map. The customer cannot bind
 *       and the panel shows a healthy row.</li>
 *   <li><strong>Someone whose password genuinely is `********` is indistinguishable from the
 *       placeholder.</strong> Improbable, and not something to leave to probability in an
 *       authentication path.</li>
 * </ol>
 *
 * <p>Both disappear if the control signal stops sharing a channel with the value. A read says only
 * whether something is stored; a write says what to do, and carries a value only when there is one.
 *
 * <p>Client-safe: no database import, so a form can hold these types.
 */

/**
 * The old placeholder, still used by the worker editor.
 *
 * <p>Lives here so there is one definition rather than two while `lib/workers.ts` continues to use
 * the older convention. Moving that over means changing `WorkerForm` and re-testing vendor editing,
 * which is a separate change.
 */
export const REDACTED = "********";

/** What a read reports. Never the value. */
export type SecretState = "unset" | "stored";

/**
 * What a write asks for.
 *
 * <p>`kept` with nothing stored is an error the caller must raise, not a silent unset — that is the
 * whole point of distinguishing it from `unset`.
 */
export type SecretField =
  | { state: "unset" }
  | { state: "kept" }
  | { state: "set"; value: string };

export function isSecretField(value: unknown): value is SecretField {
  if (!value || typeof value !== "object") {
    return false;
  }
  const field = value as Record<string, unknown>;
  if (field.state === "unset" || field.state === "kept") {
    return true;
  }
  return field.state === "set" && typeof field.value === "string";
}

/**
 * Applies a {@link SecretField} against what is currently stored.
 *
 * <p>Deliberately not forgiving. A `kept` with nothing behind it is the exact case the old
 * convention swallowed, and swallowing it here would put an unbindable credential into the database
 * while telling the operator it saved.
 *
 * @param stored the value already in the database, or null
 * @returns the value to write, or null to clear it
 * @throws Error with a sentence for the caller to return as a 400
 */
export function resolveSecret(field: SecretField, stored: string | null, what: string): string | null {
  switch (field.state) {
    case "unset":
      return null;
    case "set":
      //never trimmed. The gateway compares a bind password byte for byte, so trimming here would
      //silently store something other than what the customer was given
      return field.value;
    case "kept":
      if (stored == null || stored === "") {
        throw new Error(
          `There is no ${what} stored on this credential, so there is nothing to keep. Type one, or `
          + "set it to none."
        );
      }
      return stored;
  }
}
