import { test } from "node:test";
import assert from "node:assert/strict";
import { verifyOutcome, authError } from "./verify-outcome.ts";

const ORIGIN = "https://panel.example.com";
const SIGNED_IN = { user: { accountId: "acme" } };
const REJECTED_URL = `${ORIGIN}/?error=CredentialsSignin&code=credentials`;
const ACCEPTED_URL = `${ORIGIN}/`;

test("a rejected token with a session already open is still rejected", () => {
  //THE DEFECT, in one assertion. The old check was `res.ok && session?.user?.accountId`; fetch
  //follows next-auth's 302 so res.ok is true, and a browser that is already signed in has a
  //session, so a SPENT link reported success and the customer was sent to the overview. Provoked
  //in a browser before this existed: the server logged link_rejected while the screen showed the
  //dashboard
  assert.equal(verifyOutcome(REJECTED_URL, ORIGIN, SIGNED_IN), "rejected");
});

test("a rejected token with no session is rejected", () => {
  assert.equal(verifyOutcome(REJECTED_URL, ORIGIN, null), "rejected");
});

test("an accepted token with a session signs in", () => {
  //the anti-vacuity half: a function that answered "rejected" for everything would pass all three
  //tests above and break every sign-in on the platform
  assert.equal(verifyOutcome(ACCEPTED_URL, ORIGIN, SIGNED_IN), "signed-in");
});

test("an accepted callback with no session is rejected rather than assumed", () => {
  //no error and no session should not be read as success -- the session cookie is the thing that
  //actually carries the sign-in, so its absence means nothing was established
  assert.equal(verifyOutcome(ACCEPTED_URL, ORIGIN, null), "rejected");
});

test("a blank or absent accountId does not count as signed in", () => {
  assert.equal(verifyOutcome(ACCEPTED_URL, ORIGIN, { user: { accountId: "" } }), "rejected");
  assert.equal(verifyOutcome(ACCEPTED_URL, ORIGIN, { user: null }), "rejected");
  assert.equal(verifyOutcome(ACCEPTED_URL, ORIGIN, {}), "rejected");
});

test("any error value rejects, not just the one next-auth happens to send today", () => {
  assert.equal(verifyOutcome(`${ORIGIN}/?error=Configuration`, ORIGIN, SIGNED_IN), "rejected");
  assert.equal(verifyOutcome(`${ORIGIN}/?error=AccessDenied`, ORIGIN, SIGNED_IN), "rejected");
});

test("a relative final URL is resolved against the origin", () => {
  assert.equal(authError("/?error=CredentialsSignin", ORIGIN), "CredentialsSignin");
  assert.equal(verifyOutcome("/?error=CredentialsSignin", ORIGIN, SIGNED_IN), "rejected");
});

test("an unreadable URL falls through to the session rather than inventing a rejection", () => {
  //deliberate: failing a sign-in that may have worked, because a URL could not be parsed, is the
  //worse of the two mistakes here
  assert.equal(authError("::::", "::::"), null);
  assert.equal(verifyOutcome("::::", "::::", SIGNED_IN), "signed-in");
  assert.equal(verifyOutcome("::::", "::::", null), "rejected");
});

test("the error parameter beats the session even when both are present", () => {
  assert.equal(authError(REJECTED_URL, ORIGIN), "CredentialsSignin");
});
