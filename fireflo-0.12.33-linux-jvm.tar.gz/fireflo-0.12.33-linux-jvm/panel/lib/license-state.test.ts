import { strict as assert } from "node:assert";
import { test } from "node:test";
import { licenseScreen, type LicenseScreen, type LicenseState, type LicenseVerdict } from "./license-state.ts";

/**
 * Which screen each verdict gets.
 *
 * The table is typed `Record<LicenseVerdict, ...>` on purpose, following
 * `gateway-key-policy.test.ts`: an eighth verdict added to the union becomes a COMPILE error here
 * rather than an untested branch that quietly falls through. A verdict nobody decided is the exact
 * shape of the bug this whole change exists to fix.
 */
const EXPECTED: Record<LicenseVerdict, LicenseScreen> = {
  active: { lead: "details", activateIsSecondary: true, offerRelease: true, offerRevalidate: true },
  grace: { lead: "details", activateIsSecondary: true, offerRelease: true, offerRevalidate: true },
  wrong_install: {
    lead: "transfer", activateIsSecondary: false, offerRelease: true, offerRevalidate: true,
  },
  expired: {
    lead: "activate", activateIsSecondary: false, offerRelease: true, offerRevalidate: true,
  },
  malformed: {
    lead: "activate", activateIsSecondary: false, offerRelease: true, offerRevalidate: true,
  },
  setup: {
    lead: "activate", activateIsSecondary: false, offerRelease: false, offerRevalidate: false,
  },
  none: {
    lead: "activate", activateIsSecondary: false, offerRelease: false, offerRevalidate: false,
  },
};

function stateWith(verdict: LicenseVerdict): LicenseState {
  return {
    verdict,
    license_id: verdict === "none" || verdict === "setup" ? null : "lic_123",
    tier: null,
    install_id: "ins_abc123def456",
    bound_ip: null,
    not_after: null,
    grace_ends_at: null,
    days_until_frozen: 0,
    last_refreshed_at: null,
    configuration_adopted: verdict === "active" || verdict === "grace" || verdict === "setup",
    server_url: "https://verify.fireflo.au",
    message: "",
  };
}

for (const verdict of Object.keys(EXPECTED) as LicenseVerdict[]) {
  test(`licenseScreen: ${verdict}`, () => {
    assert.deepEqual(licenseScreen(stateWith(verdict)), EXPECTED[verdict]);
  });
}

test("a licensed gateway never leads with the activation form", () => {
  //the reported bug, stated as an assertion. /cp/verify showed the activate form on every verdict,
  //so a working install looked identical to one that had never been activated
  for (const verdict of ["active", "grace"] as LicenseVerdict[]) {
    const screen = licenseScreen(stateWith(verdict));
    assert.equal(screen.lead, "details");
    assert.equal(screen.activateIsSecondary, true);
  }
});

test("release is offered only where there is something to release", () => {
  //driven by verdict, not by license_id: malformed and none both have a null id and want opposite
  //answers -- an unreadable licence is still a licence on disk
  const offered = (Object.keys(EXPECTED) as LicenseVerdict[])
    .filter((v) => licenseScreen(stateWith(v)).offerRelease);
  assert.deepEqual(offered.sort(), ["active", "expired", "grace", "malformed", "wrong_install"]);
});

test("a state that could not be read offers nothing destructive", () => {
  //"the panel could not ask this gateway" is not "this gateway has no licence", and a release
  //button on that screen would act on a machine whose state nobody established
  const screen = licenseScreen(null);
  assert.equal(screen.offerRelease, false);
  assert.equal(screen.offerRevalidate, false);
  assert.equal(screen.lead, "activate");
});
