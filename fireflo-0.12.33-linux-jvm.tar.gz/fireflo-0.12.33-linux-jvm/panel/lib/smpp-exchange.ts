import { vendorStatusName } from "./rejected-types.ts";
import { dlrStateLabel } from "./labels.ts";
import type { CdrRow, MessageReceipt } from "./cdr-request.ts";

/**
 * The SMPP exchange for one message, as one ordered sequence rather than three separate tables.
 *
 * <p>What this is built from, and what it is not. `cdr_submit` carries one row per attempt --
 * `submit_sm` out, and (when the gateway is past V1.40.0) `submit_sm_resp`'s status back, on the
 * same row. `cdr_final`/`cdr_interim` carry `deliver_sm`, the vendor's receipt. There is no
 * `deliver_sm_resp` anywhere in this system: nothing captures it, nothing logs it, and this module
 * does not pretend otherwise -- see {@link SmppExchangeEvent.pdu} and the caller-facing note this
 * exports beside it.
 *
 * <p>Database-free and unit-tested on its own: the ordering rule below is the part worth getting
 * right without a database in the loop, because it is where a retry storm either reads as one or
 * reads as noise.
 */

export type SmppPdu = "submit_sm" | "submit_sm_resp" | "deliver_sm";

export interface SmppExchangeEvent {
  pdu: SmppPdu;
  partNo: number;
  /**
   * Which submit_sm this was to the vendor for this part -- `retryCount` (the router's re-routing
   * counter) and, when the gateway records it, the finer-grained vendor-attempt count within one
   * routing pass. Absent on a `deliver_sm` event, which has no attempt of its own.
   */
  attempt?: { retryCount: number };
  at: string;
  /**
   * Which worker this event belongs to. On `submit_sm`/`submit_sm_resp` it is the vendor the
   * attempt went to; on `deliver_sm` it is recorded only for a progress receipt (`cdr_final` has no
   * vendor column at all), so an outcome row is null here even though it plainly came from one.
   */
  vendor: string | null;
  /** The vendor's own message id, when one exists yet. */
  operatorMsgId: string | null;
  /**
   * A short verdict for the row: the status mnemonic for a `submit_sm_resp`, the DLR state's plain
   * label for a `deliver_sm`, or null for a `submit_sm` -- the request itself has no verdict, only
   * its response does.
   */
  status: string | null;
  /** True for the `deliver_sm` that closed the message. Never true for anything else. */
  terminal: boolean;
  /**
   * Which routing rule sent this attempt to this vendor — `table:label`, else `table:seq`.
   *
   * <p>On `submit_sm` only: the rule chose where the request went, and the response and the
   * receipt did not get a say. Per attempt, so a re-route that matched a different rule shows as a
   * second row naming a different one — which is the case worth seeing.
   *
   * <p>`undefined` where the gateway has no such column; `null` where it has one and this row
   * predates it, or the attempt reached a vendor without matching a rule. Never "no rule".
   */
  routeRule?: string | null;
}

/**
 * One message's `submit_sm`/`submit_sm_resp` pairs and its `deliver_sm` receipts, merged into
 * arrival order.
 *
 * <p>Two attempts sharing a part are ordered by `retryCount`, so a re-route is visible as a second
 * pass rather than an unordered pile; a receipt is placed by `receivedAt` among them, which is what
 * lets a retry storm and the receipt that eventually closed it read as one sequence instead of two
 * cards that have to be cross-referenced by hand.
 */
export function buildSmppExchange(
  attempts: readonly CdrRow[],
  receipts: readonly MessageReceipt[]
): SmppExchangeEvent[] {
  const events: SmppExchangeEvent[] = [];

  for (const a of attempts) {
    events.push({
      pdu: "submit_sm",
      partNo: a.partNo,
      attempt: { retryCount: a.retryCount },
      //the request has no timestamp of its own answer; submittedAt is when it went out, which is
      //also the only time this event could plausibly claim
      at: a.submittedAt,
      vendor: a.vendor,
      operatorMsgId: null,
      status: null,
      terminal: false,
    });
    //absent means this gateway predates V1.40.0: say nothing rather than imply the attempt is
    //still open, which "no resp event at all" would otherwise read as
    if ("submitStatus" in a && a.submitStatus != null) {
      events.push({
        pdu: "submit_sm_resp",
        partNo: a.partNo,
        attempt: { retryCount: a.retryCount },
        //acceptedAt when the vendor gave one; otherwise the request's own time, so a resp with no
        //timestamp of its own does not silently sort before the request it is answering
        at: a.acceptedAt ?? a.submittedAt,
        vendor: a.vendor,
        operatorMsgId: a.operatorMsgId,
        status: vendorStatusName(a.submitStatus) ?? String(a.submitStatus),
        terminal: false,
      });
    }
  }

  for (const r of receipts) {
    events.push({
      pdu: "deliver_sm",
      partNo: r.partNo,
      at: r.receivedAt,
      vendor: r.vendor,
      operatorMsgId: r.operatorMsgId,
      status: r.dlrState == null ? r.errCode : dlrStateLabel(r.dlrState),
      terminal: r.kind === "outcome",
    });
  }

  return events
    .sort((x, y) =>
      x.partNo - y.partNo ||
      x.at.localeCompare(y.at) ||
      //stable within the same instant: request before its own response, and both before a receipt
      //that happens to share a timestamp -- the reading order a person expects, not sort noise
      PDU_ORDER[x.pdu] - PDU_ORDER[y.pdu]);
}

const PDU_ORDER: Record<SmppPdu, number> = { submit_sm: 0, submit_sm_resp: 1, deliver_sm: 2 };
