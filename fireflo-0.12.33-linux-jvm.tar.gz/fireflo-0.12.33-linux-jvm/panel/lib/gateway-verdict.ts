import { KIND } from "./worker-types.ts";
import type { Health, HealthWorker } from "./health-types.ts";

export type GatewayTone = "success" | "warning" | "destructive";

/**
 * One word for the whole gateway, for the pill in the top bar.
 *
 * <p>The health snapshot speaks per worker and never sums itself up; the pages that need a verdict
 * each compute their own. This is the one the chrome shows on every page, so it errs towards
 * calm: a vendor that is disabled on purpose, or paused by an operator, is not a problem, and a
 * listener with nobody bound is Tuesday. What counts is a vendor that should be carrying traffic
 * and is not, and a broker the gateway cannot reach.
 */
export interface GatewayVerdict {
  tone: GatewayTone;
  label: "Healthy" | "Degraded" | "Down" | "Unreachable";
  /** The sentence behind the word, for the tooltip. */
  detail: string;
  /** Messages per second across every vendor that reports a rate, or null when none does. */
  tps: number | null;
}

/** A vendor the gateway is meant to be sending through right now. */
function inService(w: HealthWorker): boolean {
  return w.type === KIND.vendor && w.accepting && !w.paused && !w.suspended_manually;
}

export function gatewayVerdict(health: Health | null, error: string | null): GatewayVerdict {
  if (!health) {
    return {
      tone: "destructive",
      label: "Unreachable",
      detail: error ? `The gateway did not answer: ${error}` : "Waiting for the first health reading.",
      tps: null,
    };
  }
  const vendors = health.workers.filter(inService);
  const unbound = vendors.filter((w) => (w.bound ?? 0) === 0);
  const brokerDown = health.broker != null && health.broker.connected === false;
  const tps = vendorTps(health.workers);

  if (vendors.length && unbound.length === vendors.length) {
    return { tone: "destructive", label: "Down", detail: "No vendor is bound: nothing can be sent.", tps };
  }
  if (brokerDown) {
    return { tone: "destructive", label: "Degraded", detail: "The message broker is not connected.", tps };
  }
  if (unbound.length) {
    const names = unbound.map((w) => w.name).join(", ");
    return {
      tone: "warning",
      label: "Degraded",
      detail: `${unbound.length === 1 ? "A vendor has" : `${unbound.length} vendors have`} no bind: ${names}.`,
      tps,
    };
  }
  if (error) {
    //a stale snapshot: the last poll failed but the one before it was fine
    return { tone: "warning", label: "Degraded", detail: `The last health poll failed: ${error}`, tps };
  }
  return {
    tone: "success",
    label: "Healthy",
    detail: vendors.length ? `${vendors.length} ${vendors.length === 1 ? "vendor" : "vendors"} bound.` : "No vendor is configured.",
    tps,
  };
}

/** The gateway's outbound rate: every vendor's measured tps added up. Null when none reports one. */
export function vendorTps(workers: readonly HealthWorker[]): number | null {
  let total = 0;
  let any = false;
  for (const w of workers) {
    if (w.type === KIND.vendor && w.tps_measured != null) {
      total += w.tps_measured;
      any = true;
    }
  }
  return any ? total : null;
}

/**
 * The same sum over a history of per-worker samples, so the pill can draw a line.
 *
 * <p>Each worker's history is the same length, newest last; a sample is null where that worker
 * reported nothing. A position where no vendor reported stays null, so the sparkline leaves a gap
 * rather than drawing zero.
 */
export function vendorTpsHistory(
  history: ReadonlyMap<string, readonly (number | null)[]>,
  workers: readonly HealthWorker[]
): (number | null)[] {
  const vendors = new Set(workers.filter((w) => w.type === KIND.vendor).map((w) => w.name));
  let length = 0;
  for (const [name, samples] of history) {
    if (vendors.has(name)) {
      length = Math.max(length, samples.length);
    }
  }
  const out: (number | null)[] = Array.from({ length }, () => null);
  for (const [name, samples] of history) {
    if (!vendors.has(name)) {
      continue;
    }
    samples.forEach((v, i) => {
      if (v != null) {
        out[i] = (out[i] ?? 0) + v;
      }
    });
  }
  return out;
}
