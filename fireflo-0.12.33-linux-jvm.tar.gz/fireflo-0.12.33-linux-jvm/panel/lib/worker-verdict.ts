import { connectionState, tpsUtilisation, type HealthWorker } from "./health-types.ts";
import { KIND, isOn, trafficKey, type Worker, type WorkerType } from "./worker-types.ts";

/**
 * One sentence about whether a connection is working, from the four facts that decide it.
 *
 * <p>These cards used to render up to five badges at once — enabled, connected, pending, not
 * accepting, holding — each true, none ranked, and a reader had to assemble the answer themselves.
 * They also overlap: a disabled worker is always unloaded, so "disabled" and "not loaded by the
 * gateway" were both shown and the second one read like a fault. This collapses them into the single
 * most specific true statement, in severity order.
 *
 * <p>Database-free, so the client components can use it.
 */

export type VerdictTone = "success" | "warning" | "destructive" | "outline";

export interface WorkerVerdict {
  tone: VerdictTone;
  label: string;
  /** The reason, when the label alone would leave someone guessing what to do. */
  detail?: string;
  /**
   * True when what is stored and what the gateway is doing disagree.
   *
   * <p>Normally they agree within a second, because every control pushes its change. A lasting
   * disagreement means the push did not land and the thirty-second poll has not caught up — which is
   * worth saying rather than showing a stale badge as the truth.
   */
  pending: boolean;
}

export function workerVerdict({
  type,
  live,
  enabled,
  suspended,
  paused,
}: {
  type: WorkerType;
  live: HealthWorker | undefined;
  enabled: boolean;
  suspended: boolean;
  paused: boolean;
}): WorkerVerdict {
  const state = connectionState(live);
  const isVendor = type === KIND.vendor;
  const pending =
    (!enabled && state !== "unloaded")
    || (enabled && state === "unloaded")
    || (suspended && live?.accepting === true);

  //config first: a disabled worker being unloaded is the intended outcome, not a second problem
  if (!enabled) {
    return {
      tone: "outline",
      label: "Disabled",
      detail: state !== "unloaded" ? "The gateway is still running it — it stops within one poll." : undefined,
      pending,
    };
  }

  if (state === "unloaded") {
    return {
      tone: "warning",
      label: "Not loaded",
      detail:
        "The gateway has never heard of this one. Either it has not reloaded since it was added, or "
        + "it is not reading workers from the database.",
      pending,
    };
  }

  if (state === "disconnected") {
    //a vendor with no session is broken; a listener with no customers is merely quiet, and painting
    //that red sends someone chasing a fault that does not exist
    return isVendor
      ? { tone: "destructive", label: "Not connected", detail: live?.last_error ?? undefined, pending }
      : { tone: "outline", label: "Listening", detail: "Nobody bound.", pending };
  }

  //connected, so the remaining question is whether it is actually moving traffic
  if (suspended) {
    return {
      tone: "warning",
      label: "Not accepting",
      detail: "Bound, but not taking traffic — new messages reroute elsewhere and anything already queued is held until resume.",
      pending,
    };
  }
  if (paused) {
    return {
      tone: "warning",
      label: "Holding",
      detail: "Bound and accepting, but not sending. The queue grows until released.",
      pending,
    };
  }

  return {
    tone: "success",
    label: isVendor
      ? live?.bound === 1
        ? "Connected"
        : `Connected · ${live?.bound} binds`
      : `${live?.bound} bound`,
    pending,
  };
}

/**
 * The verdict for a stored worker, given whatever the gateway is reporting.
 *
 * <p>{@link workerVerdict} takes the four facts already teased apart; this takes the worker and the
 * health map, which is what every caller actually holds. Both pages, the rail and the summary need
 * the same three lines, and four copies of "which property means suspended" is three too many.
 */
export function verdictFor(
  worker: Worker,
  live: Map<string, HealthWorker>,
  type: WorkerType
): WorkerVerdict {
  return workerVerdict({
    type,
    live: live.get(trafficKey(worker)),
    enabled: worker.enabled,
    suspended: isOn(worker, "suspend"),
    paused: isOn(worker, "pause"),
  });
}

/**
 * How much attention a worker needs, lowest first.
 *
 * <p>The sort key for the card list and the rail alike, so the two orders cannot disagree —
 * a rail whose third row is the page's first card is worse than no rail.
 *
 * <p>`outline` sorts last rather than with `success` on purpose: it covers "disabled" and a quiet
 * listener, which are both states somebody chose. A deliberate state is the least urgent thing on
 * the page, below a working one.
 */
export const SEVERITY: Record<VerdictTone, number> = {
  destructive: 0,
  warning: 1,
  success: 2,
  outline: 3,
};

/** True when this worker is one of the ones the page is warning about. */
export function needsAttention(verdict: WorkerVerdict): boolean {
  return SEVERITY[verdict.tone] < SEVERITY.success;
}

/**
 * How a number reads, not how it looks.
 *
 * <p>`plain` is the default and stays the default: a counter is a counter. Colouring every stat
 * would make the palette decoration, and the red that currently means "this vendor has stopped
 * carrying traffic" would stop meaning anything the moment four cards next to it were also red.
 */
export type StatTone = "good" | "warn" | "bad" | "plain";

export interface LiveStat {
  label: string;
  value: number;
  tone: StatTone;
  /** Why it is not plain. Shown under the number, so a colour never has to be interpreted. */
  note?: string;
}

/**
 * How many binds the configuration asks for, and whether that number is a floor or a ceiling.
 *
 * <p>The distinction is the whole reason this is not a bare number. A vendor's
 * `connections.transceivers` is a <strong>target</strong>: it says "open five", so four is a fault
 * worth colouring. A listener's `srv.maxConnections` is a <strong>ceiling</strong>: it says "let at
 * most fifty in", so twelve is not a shortfall, it is a Tuesday. Passing one integer and letting the
 * tile guess would report every quiet listener as broken.
 */
export type BindCapacity =
  | { kind: "target"; value: number }
  | { kind: "ceiling"; value: number };

/**
 * The live numbers worth a card each, in the order they answer questions.
 *
 * <p>Each tone is a claim about the deployment rather than a style choice, and every one of them is
 * a case that is genuinely worth a second look:
 *
 * <ul>
 *   <li>a vendor with no binds is broken; a listener with none is merely quiet</li>
 *   <li>sessions that cannot transmit are the difference between "bound" and "working"</li>
 *   <li>a queue is normal — a queue while the worker is <em>held</em> only grows</li>
 *   <li>nothing moving while something is queued is a stall, and it is invisible in every other
 *       view because both numbers look unremarkable on their own</li>
 * </ul>
 */
export function liveStats(
  live: HealthWorker | undefined,
  isVendor: boolean,
  paused = false,
  capacity: BindCapacity | null = null
): LiveStat[] {
  if (!live) {
    return [];
  }
  const stats: LiveStat[] = [];
  const queued = live.queue_depth ?? 0;

  if (live.bound != null) {
    stats.push({
      label: isVendor ? "Binds" : "Bound customers",
      value: live.bound,
      tone: boundTone(live.bound, isVendor, capacity),
      note: boundNote(live.bound, isVendor, capacity),
    });
  }

  if (isVendor && live.bound_transmittable != null && live.bound_transmittable !== live.bound) {
    stats.push({
      label: "Can send",
      value: live.bound_transmittable,
      tone: live.bound_transmittable === 0 ? "bad" : "warn",
      note: "Receive-only sessions cannot carry traffic out",
    });
  }

  if (live.queue_depth != null) {
    stats.push({
      label: "Queued",
      value: queued,
      tone: queued > 0 && paused ? "warn" : "plain",
      note: queued > 0 && paused ? "Held, so this only grows" : undefined,
    });
  }

  if (live.retry_queue_depth) {
    stats.push({
      label: "Retrying",
      value: live.retry_queue_depth,
      tone: "warn",
      note: "Failed at least once",
    });
  }

  if (live.submit_rejected) {
    //a different fault from a bind failure, and easy to miss because the bind looks perfect: the
    //session is up, the queue is moving, and the vendor is refusing the messages. It had no tile of
    //its own -- only a line of prose inside ConnectionStatus that reads as commentary on the badge
    stats.push({
      label: "Refused by vendor",
      value: live.submit_rejected,
      tone: "bad",
      note: live.last_submit_error ?? "Bound and connected, but these were not accepted",
    });
  }

  if (live.submitted != null) {
    //a counter, and counters have no opinion
    stats.push({
      label: submittedLabel(isVendor),
      value: live.submitted,
      tone: "plain",
      note: "Resets when a bind drops",
    });
  }

  return stats;
}

/**
 * What the worker-level `submitted` counter is actually counting.
 *
 * <p>Two things were wrong with the label this replaces, "Sent this session".
 *
 * <p><strong>It named the wrong session.</strong> `OpsHealthService.scan()` sums the per-session
 * SMPP counters, so this figure <em>is</em> the Sent column of the bind table underneath it, added
 * up — and the word "session" was doing different work in the two places, three lines apart. The
 * counters live on the session and restart at zero on rebind, which is why the note says so: a
 * vendor whose binds flapped an hour ago shows a small number that otherwise reads as light traffic.
 *
 * <p><strong>And on a listener it named the wrong direction.</strong> `Sessions.submitted()` picks
 * `getRxSubmitSM()` for an inbound session and `getTxSubmitSM()` for an outbound one. A listener's
 * figure is therefore submit_sm this gateway <em>received from</em> customers; calling that "sent"
 * described the opposite of what happened.
 */
export function submittedLabel(isVendor: boolean): string {
  return isVendor ? "Sent on these binds" : "Received on these binds";
}

/**
 * A bind count against what was asked for — a fault on a vendor, ordinary on a listener.
 *
 * <p>See {@link BindCapacity} for why the two are not the same comparison. A vendor short of its
 * target is amber rather than red: sessions are up and traffic is moving, just not on as many binds
 * as configured, and colouring that the same as "nothing is bound" would send someone to the wrong
 * problem.
 */
function boundTone(bound: number, isVendor: boolean, capacity: BindCapacity | null): StatTone {
  if (bound === 0) {
    return isVendor ? "bad" : "plain";
  }
  if (capacity?.kind === "target" && bound < capacity.value) {
    return "warn";
  }
  return "good";
}

function boundNote(
  bound: number,
  isVendor: boolean,
  capacity: BindCapacity | null
): string | undefined {
  if (bound === 0 && isVendor) {
    return "Nothing can be sent";
  }
  if (!capacity) {
    return undefined;
  }
  if (capacity.kind === "ceiling") {
    return `of ${capacity.value} allowed`;
  }
  return bound < capacity.value
    ? `${capacity.value - bound} of ${capacity.value} configured ${
        capacity.value - bound === 1 ? "bind is" : "binds are"
      } not up`
    : `of ${capacity.value} configured`;
}

/**
 * Whether throughput is worth colouring, and why.
 *
 * <p>Separate from {@link liveStats} because it is the one figure that is not a plain count — it
 * carries a ceiling alongside it and `tpsSummary` already renders the pair.
 */
export function throughputTone(
  live: HealthWorker | undefined,
  paused: boolean,
  windowSeconds?: number | null
): { tone: StatTone; note?: string } {
  if (!live || live.tps_measured == null) {
    return { tone: "plain" };
  }
  const queued = live.queue_depth ?? 0;

  //the reading no other view surfaces: both numbers look ordinary alone, and together they mean
  //messages are waiting and none of them are moving
  if (live.tps_measured === 0 && queued > 0 && !paused) {
    return { tone: "bad", note: `${queued} waiting and nothing moving` };
  }
  const used = tpsUtilisation(live);
  if (used != null && used >= 0.9) {
    return { tone: "warn", note: "At the configured ceiling" };
  }
  //the averaging window, which the card printed nothing about while /cp/health said "Averaged over
  //the last Ns" from the same field. A rate with no window behind it cannot be read: an operator
  //cannot tell an instantaneous sample from a ten-second mean, and the two disagree constantly
  return { tone: "plain", note: windowSeconds ? `Mean over ${windowSeconds}s` : undefined };
}
