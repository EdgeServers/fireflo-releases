import { test } from "node:test";
import assert from "node:assert/strict";
import {
  rowTlvGaps,
  tlvGapSentence,
  tlvGapSummary,
  tlvGapFixes,
  type CoverageInput,
  type LoginDefaults,
  type MandatorySource,
  type VendorTlvs,
} from "./tlv-coverage.ts";

/**
 * Which mandatory TLVs an approved row fails to deliver.
 *
 * <p>Every case names the gateway behaviour it pins, because this module is only useful while it
 * agrees with `BasicSubmitSmProcessor`. The scenario most of these use is the live dev config, where
 * listener `airtel` requires `peid_0x1400,tmplid_0x1401`, `acct-in-2001` has three approved sender
 * IDs with no TLVs at all, and two of its three products have a login carrying `peid_0x1400` as a
 * credential default — leaving `in-promo` with no supplier of any kind.
 */

const PEID = 0x1400;
const TMPLID = 0x1401;

const airtel: MandatorySource = {
  listener: "airtel",
  tags: [{ tag: PEID, token: "peid_0x1400" }, { tag: TMPLID, token: "tmplid_0x1401" }],
  checksWhitelist: true,
  stamps: "replace",
};

const login = (product: string, tags: number[], systemId = `login-${product}`): LoginDefaults => ({
  accountId: "acct-in-2001", product, systemId, tags,
});

function gaps(over: Partial<CoverageInput> = {}) {
  return rowTlvGaps({
    tlvs: null,
    accountId: "acct-in-2001",
    product: "in-promo",
    kind: "header",
    mode: "ENFORCE",
    mandatory: [airtel],
    logins: [],
    ...over,
  });
}

test("no listener requires anything, so nothing is reported at all", () => {
  //the ordinary deployment. The feature has to be completely invisible, not a card reading "0 gaps"
  assert.deepEqual(gaps({ mandatory: [] }), []);
});

test("the live in-promo case: nothing supplies peid, so every message is refused", () => {
  const found = gaps({ logins: [login("in-otp", [PEID]), login("in-txn", [PEID])] });

  const peid = found.find((g) => g.tag === PEID);
  assert.equal(peid?.reason, "nothingSupplies");
  assert.deepEqual(peid?.requiredBy, ["airtel"]);
  //the logins that do carry it are on other products, and a product-scoped row never sees them
  assert.match(tlvGapSentence(peid!, "header"), /Mandatory tlv peid_0x1400 is not set/);
  assert.match(tlvGapSentence(peid!, "header"), /unless the customer sends the tag themselves/);
});

test("the live in-otp case: a login on that product supplies it, so there is no gap", () => {
  const found = gaps({ product: "in-otp", logins: [login("in-otp", [PEID, TMPLID])] });

  assert.equal(found.length, 0, "a credential default is one of the three suppliers, not a bystander");
});

test("a row on no product faces every login on the account", () => {
  //WhitelistSnapshot.whitelistFor: an any-product row serves traffic from every login there is
  const found = gaps({ product: "", logins: [login("in-otp", [PEID, TMPLID])] });

  assert.equal(found.length, 0, "one login, and it carries both tags");

  const split = gaps({ product: "", logins: [login("in-otp", [PEID, TMPLID]), login("in-txn", [])] });
  assert.ok(split.length > 0, "add a login carrying neither and the any-product row is exposed");
});

test("a product-scoped row is not covered by a login on a different product", () => {
  const found = gaps({ product: "in-txn", logins: [login("in-otp", [PEID, TMPLID])] });

  assert.equal(found.length, 2, "both required tags are unsupplied on in-txn");
});

test("two logins on one product, one carrying it, reads as intermittent", () => {
  const found = gaps({
    product: "in-otp",
    tlvs: "tmplid_0x1401=110716",
    logins: [login("in-otp", [PEID], "sunrise-smpp"), login("in-otp", [], "sunrise-bulk")],
  });

  const peid = found.find((g) => g.tag === PEID);
  assert.equal(peid?.reason, "someLogins");
  assert.deepEqual(peid?.coveredLogins, ["sunrise-smpp"]);
  assert.deepEqual(peid?.uncoveredLogins, ["sunrise-bulk"]);
  //the payload: one login works and the other does not, which is the hardest shape to diagnose
  assert.match(tlvGapSentence(peid!, "header"), /intermittent/);
});

test("a row carrying the tag covers it when the listener stamps", () => {
  const found = gaps({ tlvs: "peid_0x1400=110177,tmplid_0x1401=110716" });

  assert.equal(found.length, 0);
});

test("assign and replace both cover, because the mandatory check only asks whether it is present", () => {
  for (const stamps of ["assign", "replace"] as const) {
    const found = gaps({
      tlvs: "peid_0x1400=110177,tmplid_0x1401=110716",
      mandatory: [{ ...airtel, stamps }],
    });
    assert.equal(found.length, 0, `${stamps} should satisfy the mandatory check`);
  }
});

test("with the stamping mode off, a row carrying the tag still delivers nothing", () => {
  //SmppServerWorker:177 -- whitelist.tlvs.mode defaults to off, so this is the common case and the
  //one that reads as working when it is not
  const found = gaps({
    tlvs: "peid_0x1400=110177,tmplid_0x1401=110716",
    mandatory: [{ ...airtel, stamps: "off" }],
  });

  assert.equal(found.length, 2);
  assert.equal(found[0].reason, "notStamped");
  assert.match(tlvGapSentence(found[0], "header"), /whitelist\.tlvs\.mode/);
  assert.match(tlvGapSentence(found[0], "header"), /assign/, "and it must name the fix");
});

test("with the list not checked, a row carrying the tag is never matched, so never stamped", () => {
  //BasicSubmitSmProcessor:135 -- stamping happens inside mode.isChecked()
  const found = gaps({ tlvs: "peid_0x1400=110177,tmplid_0x1401=110716", mode: "OFF" });

  assert.equal(found[0].reason, "notChecked");
});

test("a listener that does not check the whitelist cannot be rescued by a row either", () => {
  const found = gaps({
    tlvs: "peid_0x1400=110177,tmplid_0x1401=110716",
    mandatory: [{ ...airtel, checksWhitelist: false }],
  });

  assert.equal(found[0].reason, "notStamped");
});

test("a token carrying no tag is reported as the typo it is, naming what was written", () => {
  //the live defect: PEID has no underscore, parseTag returns null, parseDefaults drops the entry
  const found = gaps({ tlvs: "PEID=1401778070000018542" });

  const peid = found.find((g) => g.tag === PEID);
  assert.equal(peid?.reason, "unparseable");
  assert.equal(peid?.wrote, "PEID");
  const sentence = tlvGapSentence(peid!, "header");
  assert.match(sentence, /carries no tag/);
  assert.match(sentence, /peid_0x1400=/, "and it must give the corrected form");
});

test("a tag named with no value stamps nothing, and reads differently from an absent one", () => {
  //MessageFlexValue.getValueFor returns null for "", and validateMandatoryTlvs treats empty as unset
  const found = gaps({ tlvs: "peid_0x1400=,tmplid_0x1401=110716" });

  const peid = found.find((g) => g.tag === PEID);
  assert.equal(peid?.reason, "emptyValue");
  assert.match(tlvGapSentence(peid!, "header"), /no value/);
});

test("two listeners requiring one tag produce one gap naming both", () => {
  const vodafone: MandatorySource = { ...airtel, listener: "vodafone", tags: [{ tag: PEID, token: "peid_0x1400" }] };
  const found = gaps({ mandatory: [airtel, vodafone] });

  const peid = found.filter((g) => g.tag === PEID);
  assert.equal(peid.length, 1, "one sentence per tag, not one per listener");
  assert.deepEqual(peid[0].requiredBy, ["airtel", "vodafone"]);
  assert.match(tlvGapSentence(peid[0], "header"), /`airtel` and `vodafone`/);
});

test("the REST ingress has no listener name and reads as the HTTP API", () => {
  const rest: MandatorySource = {
    listener: "", tags: [{ tag: PEID, token: "peid_0x1400" }], checksWhitelist: true, stamps: "replace",
  };
  //REST stamping is unconditional, so a row's TLVs do cover it there
  assert.equal(gaps({ mandatory: [rest], tlvs: "peid_0x1400=110177" }).length, 0);

  const found = gaps({ mandatory: [rest] });
  assert.match(tlvGapSentence(found[0], "header"), /the HTTP API refuses/);
});

test("a reachable vendor that does not register the tag drops it after the CDR records it", () => {
  //SmppClientWorker:854 -- effective.keySet().retainAll(registered)
  const vendors: VendorTlvs[] = [
    { name: "in-sim", registered: [PEID, TMPLID], reachable: true },
    { name: "vendor1", registered: [], reachable: true },
  ];
  const found = gaps({ tlvs: "peid_0x1400=110177,tmplid_0x1401=110716", vendors });

  assert.equal(found.length, 2);
  assert.equal(found[0].reason, "vendorDrops");
  assert.deepEqual(found[0].vendors, ["vendor1"], "and only the vendor that actually drops it");
  assert.match(tlvGapSentence(found[0], "header"), /call record will show it as sent/);
});

test("a vendor no enabled rule names, or one that carries the tag, is silent", () => {
  const vendors: VendorTlvs[] = [
    { name: "in-sim", registered: [PEID, TMPLID], reachable: true },
    { name: "smppsim", registered: [], reachable: false },
  ];

  assert.deepEqual(gaps({ tlvs: "peid_0x1400=110177,tmplid_0x1401=110716", vendors }), [],
    "an unreachable vendor drops nothing, because nothing is routed to it");
});

test("the vendor question is only asked once something supplies the tag", () => {
  //no point telling an operator the vendor would drop a tag that was never going to be set
  const vendors: VendorTlvs[] = [{ name: "vendor1", registered: [], reachable: true }];
  const found = gaps({ vendors });

  assert.ok(found.every((g) => g.reason === "nothingSupplies"),
    "fix the supply first; the vendor is the next question, not this one");
});

test("the summary form stays short enough for a table cell", () => {
  const found = gaps();
  for (const gap of found) {
    assert.ok(tlvGapSummary(gap).length < 80, tlvGapSummary(gap));
  }
});

test("a template that supplies the tag says multipart never gets it", () => {
  //BasicSubmitSmProcessor: a concatenated message skips the content check, so it skips the stamp
  const found = gaps({
    kind: "content",
    tlvs: "tmplid_0x1401=110716",
    mandatory: [{ ...airtel, stamps: "off" }],
  });

  assert.ok(found.length > 0);
  assert.match(tlvGapSentence(found[0], "content"), /template/);
});

test("a sender ID is not blamed for the Template ID a template already carries", () => {
  //applyWhitelist runs both checks and each stamps what it matched, so the supply set is the union.
  //Without this every header row in a DLT deployment carried a false warning about tmplid_0x1401 --
  //a tag that is never a sender ID's job
  const found = gaps({
    product: "in-otp",
    tlvs: "peid_0x1400=110177",
    siblings: { mode: "ENFORCE", tlvs: ["tmplid_0x1401=110716"] },
  });

  assert.deepEqual(found, [], "both tags are supplied, one by each row");
});

test("a sibling that is not checked supplies nothing either", () => {
  const found = gaps({
    product: "in-otp",
    tlvs: "peid_0x1400=110177",
    siblings: { mode: "OFF", tlvs: ["tmplid_0x1401=110716"] },
  });

  assert.equal(found.length, 1);
  assert.equal(found[0].tag, TMPLID, "content is not checked, so no template is matched or stamped");
});

test("only some siblings carrying the tag is not coverage", () => {
  //which template matches depends on the message body, so a message matching the other one arrives
  //without the tag. The same reasoning as the two-logins case
  const found = gaps({
    product: "in-otp",
    tlvs: "peid_0x1400=110177",
    siblings: { mode: "ENFORCE", tlvs: ["tmplid_0x1401=110716", null] },
  });

  assert.equal(found.length, 1);
  assert.equal(found[0].tag, TMPLID);
});

test("a gap that is the listener's stamping mode links to that listener's TLVs section", () => {
  const gap = { tag: 0x1400, token: "peid_0x1400", requiredBy: ["smpp", "", "in 2"], reason: "notStamped" as const };
  assert.deepEqual(tlvGapFixes(gap), [
    { label: "Fix on smpp", href: "/cp/servers/smpp?edit=1&open=tlvs" },
    { label: "Fix on in 2", href: "/cp/servers/in%202?edit=1&open=tlvs" },
  ], "one per listener, the HTTP API left out, the name encoded");
  assert.deepEqual(tlvGapFixes({ ...gap, reason: "nothingSupplies" }), [],
    "nothing to link when the fix is not a listener setting");
});
