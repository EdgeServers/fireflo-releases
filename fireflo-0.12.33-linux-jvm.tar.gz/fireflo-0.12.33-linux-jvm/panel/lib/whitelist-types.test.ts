import { strict as assert } from "node:assert";
import { test } from "node:test";
//with the extension, because `node --test` reads neither tsconfig paths nor extensionless specifiers
import {
  MAX_VARIABLE,
  PLACEHOLDER_TYPES,
  describeGroups,
  templateGroups,
  VARIABLE,
  foldWhitespace,
  hasRepeatingSegments,
  previewTemplate,
  scanTemplate,
  splitTemplate,
  validateTemplate,
} from "./whitelist-types.ts";

/**
 * This module's own header says a disagreement with the gateway's `ContentTemplate` would be worse
 * than no preview, because it would confidently describe behaviour that never happens — and until
 * now nothing tested that. The cases below mirror the Java ones one for one, so the drift the module
 * warns about is something a test can catch rather than something a customer reports.
 */

test("whitespace folds the way the gateway folds it", () => {
  assert.equal(foldWhitespace("a\nb"), "a b");
  assert.equal(foldWhitespace("a\r\nb"), "a b");
  assert.equal(foldWhitespace("a\tb"), "a b");
  assert.equal(foldWhitespace("a\u00A0b"), "a b", "U+00A0 is what a PDF paste carries");
  assert.equal(foldWhitespace("a  b"), "a b");
  assert.equal(foldWhitespace("  a b  "), "a b");
  assert.equal(foldWhitespace("   "), "");
  //the safety property: a run folds to one space, never to nothing
  assert.equal(foldWhitespace("foo \n\t bar"), "foo bar");
  assert.notEqual(foldWhitespace("foo \n\t bar"), "foobar");
});

test("the reported template splits the same folded way the gateway splits it", () => {
  const body = "Use OTP {#var#} to verify {#var#}. Do not share this code with anyone.\n"
    + "BillBasket Solutions";
  const { parts, names } = scanTemplate(body);

  assert.deepEqual(names, ["var", "var"]);
  assert.equal(parts.length, 3);
  //the newline is gone from the tail, which is exactly why the message with a space now matches
  assert.equal(parts[2], ". Do not share this code with anyone. BillBasket Solutions");
});

test("all three placeholder types are recognised", () => {
  assert.deepEqual(Object.keys(PLACEHOLDER_TYPES), ["var", "num", "alp"]);
  for (const name of ["var", "num", "alp"]) {
    assert.equal(validateTemplate(`Your code is {#${name}#} now`), null, name);
  }
  assert.deepEqual(scanTemplate("Dear {#alp#}, OTP {#num#}!").names, ["alp", "num"]);
});

test("an unrecognised type is refused HERE even though the gateway loads it", () => {
  //not a contradiction: the gateway's job on a row already in the database is to keep the account
  //enforcing and say what it did; the panel's is to stop the row being written. Strict at
  //authoring, forgiving but loud at load
  for (const bad of ["Your OTP is {#VAR#}", "Your OTP is {# var #}", "Your OTP is {#xyz#}"]) {
    const problem = validateTemplate(bad);
    assert.ok(problem, bad);
    assert.ok(problem.includes("{#num#}"), `${bad}: names the alternatives`);
  }
});

test("a brace with no hash is ordinary text and is not called a placeholder", () => {
  assert.equal(validateTemplate("Your code is {code}"), null);
  assert.deepEqual(scanTemplate("Your code is {code}").names, []);
});

test("the three refusals the gateway still makes are refused here too", () => {
  assert.ok(validateTemplate(VARIABLE), "nothing but a variable");
  assert.ok(validateTemplate("OTP {#var#}{#num#} ends"), "{#var#} touching a typed placeholder");
  assert.ok(validateTemplate("{#var#} {#var#}"), "nothing but a group");
  assert.ok(validateTemplate("   "), "blank after folding");
  assert.ok(validateTemplate(""), "empty");
});

test("the preview satisfies each gap's own type", () => {
  //filling a {#num#} with letters would show the operator a message their template refuses
  const preview = previewTemplate("Dear {#alp#}, your OTP is {#num#}.");

  const [, name, otp] = /^Dear (.+), your OTP is (.+)\.$/.exec(preview) ?? [];
  //\p{L} alone was always too narrow -- it excludes the combining marks the gateway has
  //accepted since {#alp#} shipped -- and it is now also missing spaces and name punctuation
  assert.ok(name && /^[\p{L}\p{M} '\u2019.\u2010-]+$/u.test(name), `alp sample was "${name}"`);
  assert.ok(otp && /^\d+$/.test(otp), `num sample was "${otp}"`);
});

test("the preview shows the folded text, because that is what gets compared", () => {
  const preview = previewTemplate("Use OTP {#num#}.\nBillBasket Solutions");

  assert.ok(!preview.includes("\n"), "a preview containing a newline is not what is matched");
  assert.ok(preview.endsWith(". BillBasket Solutions"));
});

test("splitTemplate still answers, since other callers use it", () => {
  assert.deepEqual(splitTemplate("a{#var#}b"), ["a", "b"]);
});

test("repeating segments are still detected, on the folded parts", () => {
  assert.equal(hasRepeatingSegments("a{#var#}-{#var#}-z"), true);
  assert.equal(hasRepeatingSegments("Your OTP is {#var#}, valid"), false);
  //folding matters here too: these are the same template written two ways
  assert.equal(hasRepeatingSegments("a{#var#}-{#var#}-z"),
    hasRepeatingSegments("a{#var#}-{#var#}-z\n"));
});

test("the default ceiling still matches the gateway's default", () => {
  //not the whole story any more -- the gateway reads smsg.whitelist.max.variable and reports the
  //ceiling in force on /ops/health -- but this is what an unchanged deployment uses
  assert.equal(MAX_VARIABLE, 30);
});

test("touching variables are one group, and a space between them is optional", () => {
  //the gateway's ContentTemplate.group, mirrored: same shapes accepted, same one refused
  assert.equal(validateTemplate("Your OTP is {#var#}{#var#}{#var#} ok"), null);
  assert.equal(validateTemplate("Ref {#num#} {#num#}{#alp#} end"), null);
  assert.deepEqual(templateGroups("Your OTP is {#var#}{#var#}{#var#} ok"),
    [[{ name: "var", members: 3, spacedJoins: 0 }]]);
  assert.deepEqual(templateGroups("Ref {#num#} {#num#}{#alp#} end"),
    [[{ name: "num", members: 2, spacedJoins: 1 }, { name: "alp", members: 1, spacedJoins: 0 }]]);
  assert.deepEqual(templateGroups("a {#var#}, b {#num#}"),
    [[{ name: "var", members: 1, spacedJoins: 0 }], [{ name: "num", members: 1, spacedJoins: 0 }]]);
  const refusal = validateTemplate("Hi {#var#} {#num#} bye");
  assert.ok(refusal && refusal.includes("cannot be told apart"), String(refusal));
});

test("the form says what a group accepts, and nothing for an ordinary template", () => {
  assert.equal(describeGroups("Your OTP is {#var#}, valid"), null);
  assert.equal(describeGroups("Your OTP is {#var#}{#var#}{#var#} ok"), "3 × {#var#} as one: up to 90 characters");
  assert.equal(describeGroups("Ref {#num#} {#num#}{#alp#} end"),
    "2 × {#num#} as one: up to 60 digits, with or without the space, then {#alp#}: up to 30 letters");
  //the preview of a group is still a message the template accepts
  assert.equal(validateTemplate("Your OTP is {#var#}{#var#}{#var#} ok"), null);
});

