import { test } from "node:test";
import assert from "node:assert/strict";
import { formatClockTime, formatDate, formatTimestamp } from "./datetime.ts";

/**
 * The panel's one set of date formats.
 *
 * <p>These assert **relationships and fallbacks**, never literal strings. The output depends on the
 * runtime's locale data, so pinning `15 Aug 2026, 14:32:07` would be a test of whichever ICU build
 * happens to be installed rather than of anything this module decides.
 */

const AT = "2026-08-15T09:02:07.441Z";

test("nothing to format renders as nothing, not as the word null", () => {
  for (const empty of [null, undefined, ""]) {
    assert.equal(formatTimestamp(empty), "");
    assert.equal(formatClockTime(empty), "");
    assert.equal(formatDate(empty), "");
  }
});

test("a value that is not a date shows what is stored, not 'Invalid Date'", () => {
  //whoever has to explain the row is better served by the actual contents of the column than by a
  //formatter's complaint about them
  assert.equal(formatTimestamp("not a date"), "not a date");
  assert.equal(formatClockTime("not a date"), "not a date");
  assert.equal(formatDate("not a date"), "not a date");
});

test("a timestamp carries both the date and the time", () => {
  const full = formatTimestamp(AT);
  const dateOnly = formatDate(AT);

  assert.ok(full.length > dateOnly.length, "the time is present as well as the date");
  assert.ok(full.includes(String(new Date(AT).getFullYear())));
  //medium, not short: seconds are what separate two messages sent in the same minute
  assert.match(full, /\d{1,2}[:.]\d{2}[:.]\d{2}/);
});

test("a date is rendered without a time", () => {
  assert.doesNotMatch(formatDate(AT), /\d{1,2}[:.]\d{2}[:.]\d{2}/);
});

test("something that happened today is just the clock", () => {
  const now = new Date();
  const clock = formatClockTime(now);

  assert.match(clock, /\d{1,2}[:.]\d{2}[:.]\d{2}/);
  assert.ok(
    clock.length < formatTimestamp(now).length,
    "the date would be noise on a page that only ever shows today"
  );
});

test("something that did NOT happen today falls back to the full timestamp", () => {
  //the regression this exists for: a broker queue entry sitting since yesterday rendered as
  //"14:32:07" states the one thing the reader opened the table to find out, incorrectly
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);

  assert.equal(formatClockTime(yesterday), formatTimestamp(yesterday));
  assert.ok(formatClockTime(yesterday).length > formatClockTime(new Date()).length);
});

test("the boundary is the local calendar day, not twenty-four hours", () => {
  //00:00:01 today is "today" however few seconds ago it was; 23:59:59 yesterday is not, however
  //few seconds ago it was. That is the distinction a reader makes, so it is the one to implement
  const justAfterMidnight = new Date();
  justAfterMidnight.setHours(0, 0, 1, 0);
  assert.ok(formatClockTime(justAfterMidnight).length < formatTimestamp(justAfterMidnight).length);

  const justBeforeMidnight = new Date();
  justBeforeMidnight.setHours(0, 0, 1, 0);
  justBeforeMidnight.setSeconds(justBeforeMidnight.getSeconds() - 2);
  assert.equal(formatClockTime(justBeforeMidnight), formatTimestamp(justBeforeMidnight));
});

test("a Date and its ISO string format identically", () => {
  //call sites pass whichever they have; they must not produce two different renderings of one instant
  const at = new Date(AT);
  assert.equal(formatTimestamp(at), formatTimestamp(AT));
  assert.equal(formatDate(at), formatDate(AT));
});

test("the rendering is the reader's local time, not UTC", () => {
  const at = new Date(AT);
  const rendered = formatTimestamp(at);

  //the hour shown is the local hour. On a UTC host these coincide, which is why the assertion is on
  //the local getter rather than on a fixed number
  const hour = at.getHours();
  const twelve = hour % 12 === 0 ? 12 : hour % 12;
  assert.ok(
    rendered.includes(String(hour).padStart(2, "0"))
    || rendered.includes(String(hour))
    || rendered.includes(String(twelve)),
    `expected the local hour ${hour} in ${rendered}`
  );
});
