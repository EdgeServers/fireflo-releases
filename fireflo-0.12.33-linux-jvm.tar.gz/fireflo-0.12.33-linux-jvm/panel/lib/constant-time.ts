import { createHash, timingSafeEqual } from "node:crypto";

/**
 * Compares two strings without revealing, through timing, how much of them matched -- including
 * whether they were the same length.
 *
 * <p>`timingSafeEqual` throws on buffers of different lengths, so the obvious wrapper has to check
 * the lengths first, and that early return is itself a signal: a guess of the right length takes
 * measurably longer than one of the wrong length. Until 0.12.15 the deprecated `OPERATOR_PASSWORD`
 * compare did exactly that (CP-S6). Hashing both sides to a fixed width first removes the branch:
 * two SHA-256 digests are always 32 bytes, and the comparison is one constant-time pass whatever
 * was typed.
 *
 * <p>SHA-256 here is not password storage -- the stored side is the plain value from `panel.env`,
 * which is the deprecation's whole problem -- it is only a way to give both inputs the same length.
 */
export function constantTimeEquals(a: string, b: string): boolean {
  const left = createHash("sha256").update(a, "utf8").digest();
  const right = createHash("sha256").update(b, "utf8").digest();
  return timingSafeEqual(left, right);
}
