/**
 * The band of ports SMPP listeners may bind, and where the next free one is.
 *
 * <p>Types and arithmetic only, no `pg` import: this is read by the worker form in the browser as
 * well as by the route that serves it, and anything reaching into the database from here drags the
 * driver into the client bundle.
 *
 * <p><strong>The band is the gateway's to declare, not the panel's.</strong> It arrives on
 * `/ops/health` as the text the gateway parsed, so there is one authority and no second copy in the
 * panel's own environment to fall out of step. When the gateway declares nothing, this offers
 * nothing and validates nothing — the same permissive answer the gateway gives.
 *
 * <p>The parsing rules deliberately match `SmppPortRange` on the gateway side, including the two
 * odd ones: a backwards range is read the way it was meant, and an unparseable one checks nothing
 * rather than refusing everything. A panel that rejected what the gateway would accept would be a
 * form nobody could get past.
 */

export interface PortRange {
  low: number;
  high: number;
}

/**
 * @param raw the band as the gateway reported it, or null when none is declared
 * @returns the band, or null when nothing is to be enforced
 */
export function parsePortRange(raw: string | null | undefined): PortRange | null {
  if (!raw || !raw.trim()) {
    return null;
  }
  const text = raw.trim();
  const dash = text.indexOf("-");
  const lowText = dash < 0 ? text : text.slice(0, dash).trim();
  const highText = dash < 0 ? text : text.slice(dash + 1).trim();
  if (!/^\d+$/.test(lowText) || !/^\d+$/.test(highText)) {
    return null;
  }
  let low = Number(lowText);
  let high = Number(highText);
  if (low > high) {
    [low, high] = [high, low];
  }
  if (low < 1 || high > 65535) {
    return null;
  }
  return { low, high };
}

/**
 * The lowest port in the band that nothing is already listening on.
 *
 * <p>Lowest rather than random, so a deployment's listeners end up contiguous and the firewall rule
 * that covers them stays the obvious one. Returns null when the band is full, which the form has to
 * say out loud — silently offering a port already in use produces two listeners that both start and
 * one that never sees a connection.
 *
 * @param range the declared band, or null when there is none
 * @param used ports already assigned to a listener
 * @returns a free port, or null when there is no band or no room left in it
 */
export function nextFreePort(range: PortRange | null, used: readonly number[]): number | null {
  if (!range) {
    return null;
  }
  const taken = new Set(used);
  for (let port = range.low; port <= range.high; port++) {
    if (!taken.has(port)) {
      return port;
    }
  }
  return null;
}

/**
 * @returns why this port cannot be used, or null when it can
 */
export function describePortProblem(
  port: number,
  range: PortRange | null,
  used: readonly number[],
): string | null {
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    return "A port is a whole number between 1 and 65535.";
  }
  if (used.includes(port)) {
    return `Port ${port} already belongs to another listener.`;
  }
  if (range && (port < range.low || port > range.high)) {
    //the gateway refuses to bind this, so accepting it here would write a listener that never
    //starts -- and the reason would only surface in the log, after the save looked like it worked
    return `Port ${port} is outside ${range.low}-${range.high}, the range this gateway allows. `
      + "A listener outside it refuses to bind, so this would save and never start.";
  }
  return null;
}

/**
 * @returns the band in the words the form should show above the field
 */
export function describeRange(range: PortRange | null): string {
  if (!range) {
    return "This gateway does not restrict listener ports.";
  }
  if (range.low === range.high) {
    return `This gateway allows one listener port: ${range.low}.`;
  }
  return `This gateway allows ports ${range.low}-${range.high}.`;
}
