import { strict as assert } from "node:assert";
import { test } from "node:test";
import { type Account, mergeAccountInput, newAccountIdProblem, validateAccount } from "./account-types.ts";

const taken = ["acme-au", "telstra-a"];

test("a new id must survive a URL, a rate scope and a system id unchanged", () => {
  assert.match(newAccountIdProblem("bad id!", taken) ?? "", /letters, digits, dots, dashes and underscores/);
  assert.match(newAccountIdProblem(" acme", taken) ?? "", /space at one end/);
  assert.match(newAccountIdProblem("x".repeat(65), taken) ?? "", /too long/);
  assert.match(newAccountIdProblem("", taken) ?? "", /required/);
});

test("a vendor's name is refused whatever its case, so a rate scope never names two things", () => {
  assert.match(newAccountIdProblem("telstra-a", taken) ?? "", /already in use/);
  assert.match(newAccountIdProblem("TELSTRA-A", taken) ?? "", /already in use/);
  assert.match(newAccountIdProblem("Acme-AU", taken) ?? "", /already in use/);
});

test("a free, well-formed id passes", () => {
  assert.equal(newAccountIdProblem("acme-nz", taken), null);
  assert.equal(newAccountIdProblem("acct_1002.v2", taken), null);
});

test("an existing row keeps the lenient rule: adopted ids are whatever the wire carries", () => {
  assert.equal(validateAccount({ id: "bad id!", email: null, enabled: true }), null);
  assert.match(validateAccount({ id: " acme", email: null, enabled: true }) ?? "", /space at one end/);
});

const stored = {
  id: "child-a", label: "Child A", description: "kept", enabled: false, resells: false,
  parentAccountId: "reseller-1", email: "ops@child.test",
} as unknown as Account;

test("a field the body leaves out keeps what is stored", () => {
  //the "Name this account" form sends a label alone; it must not blank the rest of a real row
  assert.deepEqual(mergeAccountInput(stored, { id: "child-a", label: "Renamed" }), {
    label: "Renamed", description: "kept", email: "ops@child.test", enabled: false,
    resells: false, parentAccountId: "reseller-1",
  });
});

test("a field the body carries means what it says, empty and null included", () => {
  const out = mergeAccountInput(stored, { id: "child-a", email: "", description: null, parentAccountId: null, enabled: true });
  assert.equal(out.email, "");
  assert.equal(out.description, null);
  assert.equal(out.parentAccountId, null);
  assert.equal(out.enabled, true);
  assert.equal(out.label, "Child A");
});

test("a new row gets the defaults: enabled, not reselling, top-level", () => {
  assert.deepEqual(mergeAccountInput(null, { id: "fresh", label: "Fresh" }), {
    label: "Fresh", description: null, email: null, enabled: true, resells: false, parentAccountId: null,
  });
});
