import type { Health } from "./health-types";

/** How far back the MT/s line reaches. Matches the live traffic chart's window. */
export const RATE_HISTORY_MS = 15 * 60_000;

/** One health poll: when it arrived, and each worker's submit rate over the poll before it. */
export interface RateSample {
  t: number;
  /** Messages per second by full worker name; `null` where the worker gave nothing to measure. */
  mt: Readonly<Record<string, number | null>>;
}

export interface RateHistory {
  readonly samples: readonly RateSample[];
  /** Each worker's last cumulative counter, the baseline the next delta is taken from. */
  readonly last: Readonly<Record<string, { at: number; submitted: number }>>;
}

export const EMPTY_RATES: RateHistory = { samples: [], last: {} };

/**
 * Fold one health snapshot into the running submit-rate history: counter deltas, per second.
 *
 * <h2>Why a counter delta and not the call records</h2>
 *
 * <p>The live traffic chart used to draw MT/s from `cdr_submit` -- fifteen minutes of rows,
 * re-aggregated every ten seconds by every open tab (CP-P6). The gateway already counts
 * `submit_sm` per worker: `/ops/health` carries each worker's cumulative `submitted`, and two
 * readings of it are a rate with no database in the loop. (`/q/metrics` has no per-worker traffic
 * counter at all -- `FireFloMetrics` says so and why -- so health, which this panel polls anyway,
 * is the source.)
 *
 * <h2>What the counter does and does not promise</h2>
 *
 * <p>Per the gateway's `HealthSnapshot.Worker`: it is "submit_sm counted by the sessions: sent to
 * the vendor for a connection, received from customers for a listener" -- and "it restarts at zero
 * when a session rebinds", and for a listener it is the sum over the sessions connected right now.
 * So a <b>drop</b> is a rebind or a disconnect, not negative traffic; that poll falls back to the
 * gateway's own `tps_measured` where it reports one, and is otherwise a gap. The same fallback
 * covers the first poll, which is a baseline and not yet a rate, and a worker whose counters are
 * switched off.
 *
 * <p>Pure and folded at the fetch, like `appendTps` and `appendQueue`, for the same reasons. Bounded
 * by time, not count, like the queue history.
 */
export function appendRates(previous: RateHistory, health: Health, now: number): RateHistory {
  const mt: Record<string, number | null> = {};
  const last: Record<string, { at: number; submitted: number }> = {};
  for (const worker of health.workers) {
    const before = previous.last[worker.name];
    const submitted = worker.submitted ?? null;
    let rate: number | null = null;
    if (submitted != null && before && submitted >= before.submitted && now > before.at) {
      rate = ((submitted - before.submitted) * 1000) / (now - before.at);
    } else if (worker.tps_measured != null) {
      rate = worker.tps_measured;
    }
    mt[worker.name] = rate;
    if (submitted != null) {
      last[worker.name] = { at: now, submitted };
    } else if (before) {
      last[worker.name] = before;
    }
  }
  //a worker missing from this snapshot keeps its baseline, so a gateway that briefly stops
  //reporting one leaves a gap rather than restarting its counter from the next reading
  for (const [name, baseline] of Object.entries(previous.last)) {
    if (!(name in last) && baseline.at >= now - RATE_HISTORY_MS) {
      last[name] = baseline;
    }
  }
  return {
    samples: [...previous.samples.filter((s) => s.t >= now - RATE_HISTORY_MS), { t: now, mt }],
    last,
  };
}

/**
 * The combined rate of every worker `match` accepts, or `null` when none of them reported one --
 * a line drawn at zero for "nothing measured" would claim an idle gateway.
 */
export function rateOf(sample: RateSample, match: (name: string) => boolean): number | null {
  let total = 0;
  let any = false;
  for (const [name, rate] of Object.entries(sample.mt)) {
    if (rate != null && match(name)) {
      total += rate;
      any = true;
    }
  }
  return any ? total : null;
}
