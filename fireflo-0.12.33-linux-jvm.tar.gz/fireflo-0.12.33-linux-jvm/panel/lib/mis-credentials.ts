import { seal } from "@/lib/secret-box";
import { randomBytes } from "crypto";
import { configQuery, inTransaction } from "@/lib/config-db";
import { BILLING_KEY } from "@/lib/billing-key";
import {
  resolveRotatable,
  rotatableLogins,
  rotationProblem,
  type CredentialRow,
  type RotatableLogin,
} from "@/lib/playground-rules";

/**
 * The one thing a customer may write to `app_credential`: a new secret on their own login.
 *
 * <p>Server-only. Deliberately **not** `lib/credentials.ts`, which is the operator's whole-row
 * editor — a customer path that could reach `saveCredential` could reach `account_id`,
 * `allowed_ips` and `enabled` with it. Separate module, separate rules, one statement, mirroring
 * why `lib/mis-whitelist.ts` is separate from `lib/whitelist.ts`.
 *
 * <p>The rules live in `lib/playground-rules.ts`, which has no database import and is where the
 * tests are. This file is the query and the transaction.
 *
 * <h2>What a rotation actually costs</h2>
 *
 * <p>`DbConfigPoller` reloads credentials on a poll — `smsg.config.db.poll.seconds`, default 30. So
 * for up to that long the **old** secret still works and the **new** one does not. A customer who
 * rotates and immediately switches their configuration gets 401s until the poll lands. Every caller
 * has to say so; it is the likeliest support call this feature will generate.
 */

export type { RotatableLogin };

/** Which secret is being replaced. Named rather than boolean, because they are not symmetric. */
export type RotatableSecret = "password" | "apiKey";

const PROJECTION = `id::text AS id,
        ${BILLING_KEY} AS account_id,
        system_id,
        type,
        NULLIF(btrim(COALESCE(product, '')), '') AS product,
        (allowed_ips IS NOT NULL AND array_length(allowed_ips, 1) > 0) AS ip_restricted,
        (password IS NOT NULL AND password <> '') AS has_password,
        (COALESCE(api_key, '') <> '') AS key_is_secret,
        (api_key IS NOT NULL AND api_key <> '') AS has_api_key`;

interface Row {
  id: string;
  account_id: string | null;
  system_id: string | null;
  type: string;
  product: string | null;
  ip_restricted: boolean;
  has_password: boolean;
  key_is_secret: boolean;
  has_api_key: boolean;
}

async function rows(): Promise<CredentialRow[]> {
  const found = await configQuery<Row>(
    `SELECT ${PROJECTION} FROM app_credential WHERE enabled ORDER BY id`
  );
  return found.map((r) => ({
    id: r.id,
    accountId: r.account_id,
    systemId: r.system_id,
    type: r.type,
    product: r.product,
    ipRestricted: r.ip_restricted,
    hasPassword: r.has_password,
    keyIsSecret: r.key_is_secret,
    hasApiKey: r.has_api_key,
  }));
}

/** The logins this account may rotate a secret on. Neither secret is in the projection. */
export async function listRotatableLogins(accountId: string): Promise<RotatableLogin[]> {
  return rotatableLogins(await rows(), accountId);
}

/**
 * A new secret: 24 bytes of `randomBytes`, base64url.
 *
 * <p>Same construction as the portal's sign-in tokens (`lib/login-token.ts`). Not a passphrase and
 * not derived from anything — this is compared byte for byte by the gateway, so width is the only
 * property that matters and a CSPRNG is the only acceptable source.
 */
function mint(): string {
  return randomBytes(24).toString("base64url");
}

export type RotationResult =
  | { ok: true; secret: string; login: string; changesUsername: boolean }
  | { ok: false; problem: string }
  /** Not this account's login, or no such login. Answered as a 404 — see `resolveRotatable`. */
  | { ok: false; notFound: true; problem: string };

/**
 * Replaces one secret on one login, and returns the new value exactly once.
 *
 * <p>Ownership is proved twice: once against the account's own list before any write, and again
 * inside the transaction with `FOR UPDATE`, because between those two moments an operator may have
 * moved or disabled the row. The second check is what makes the write safe rather than merely
 * likely to be safe.
 *
 * <p>Rotating an **api key** also changes the Basic username, since the key is the lookup key when
 * it is set. The clash check that `saveCredential` makes is repeated here for the same reason it
 * exists there: two enabled credentials resolving to one lookup key means the gateway keeps one of
 * them and a customer stops working. A generated key will not collide; the check costs nothing and
 * the invariant is worth asserting rather than assuming.
 */
export async function rotateSecret(
  accountId: string,
  id: string,
  secret: RotatableSecret
): Promise<RotationResult> {
  const login = resolveRotatable(await listRotatableLogins(accountId), id);
  if (!login) {
    return { ok: false, notFound: true, problem: "Not found" };
  }
  const problem = rotationProblem(login, secret);
  if (problem) {
    return { ok: false, problem };
  }

  const value = mint();
  return inTransaction(async (client) => {
    //re-read under a lock: the list above is a snapshot, and an operator may have moved, disabled
    //or deleted this row since. Checking only the snapshot would be checking the past
    const current = await client.query<{ account_id: string | null; enabled: boolean }>(
      `SELECT ${BILLING_KEY} AS account_id, enabled
         FROM app_credential WHERE id = $1 FOR UPDATE`,
      [id]
    );
    if (!current.rows.length || current.rows[0].account_id !== accountId
        || !current.rows[0].enabled) {
      return { ok: false, notFound: true, problem: "Not found" } as RotationResult;
    }

    if (secret === "apiKey") {
      //the key becomes the lookup key, so a collision would take another customer offline rather
      //than merely fail this write
      const clash = await client.query<{ id: string }>(
        `SELECT id::text FROM app_credential
          WHERE enabled AND id <> $1
            AND COALESCE(NULLIF(api_key, ''), system_id) = $2`,
        [id, value]
      );
      if (clash.rows.length) {
        return {
          ok: false,
          problem: "That key collided with an existing one, which should not happen. Try again.",
        } as RotationResult;
      }
    }

    await client.query(
      secret === "apiKey"
        ? `UPDATE app_credential SET api_key = $2, updated_at = now() WHERE id = $1`
        : `UPDATE app_credential SET password = $2, updated_at = now() WHERE id = $1`,
      //a password is sealed at rest when FIREFLO_SECRETS_KEY is set; the key is the login's name
      [id, secret === "apiKey" ? value : seal(value)]
    );

    return {
      ok: true,
      secret: value,
      login: login.systemId,
      //true only for an api key on a login where it is the username. The UI needs this to choose
      //between "update your password" and "update both halves of your configuration"
      changesUsername: secret === "apiKey" && login.keyIsUsername,
    } as RotationResult;
  });
}
