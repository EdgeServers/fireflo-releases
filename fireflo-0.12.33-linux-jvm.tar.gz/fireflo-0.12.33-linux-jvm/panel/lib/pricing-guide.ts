import { describeCondition } from "./filter-guide.ts";
import type { RateRuleInput, ScopeKind } from "./rate-types.ts";

/**
 * Prices in plain language, and the bookkeeping the two-column Pricing page needs: rules grouped by
 * the product they price, moves that stay inside a product, and what a staged edit changed.
 *
 * <p>Pure and client-safe. Within a scope the gateway tries rules in `seq` order and the first match
 * for the message's product wins, so a scope reads as one list per product, each in seq order.
 */

/** "Everything else", or "When destination starts with +91 and filter in_txn matches". */
export function describePriceWhen(rule: Pick<RateRuleInput, "conditions" | "filters">): string {
  const parts = [
    ...rule.conditions.map(describeCondition),
    ...rule.filters.map((f) => `filter ${f} matches`),
  ];
  return parts.length ? `When ${parts.join(" and ")}` : "Everything else";
}

/** A rule with nothing narrowing it: the "everything else" price of its product. */
export function isFallback(rule: Pick<RateRuleInput, "conditions" | "filters">): boolean {
  return !rule.conditions.length && !rule.filters.length;
}

const productOf = (r: Pick<RateRuleInput, "product">) => (r.product ?? "").trim() || null;

export interface ProductGroup<T> {
  /** null for rules that price any product. */
  product: string | null;
  items: { rule: T; index: number }[];
  /** An enabled rule with no conditions catches what the others do not. */
  hasFallback: boolean;
}

/** The scope's rules by product, products in the order they first appear, "any product" last. */
export function groupByProduct<T extends RateRuleInput>(rules: readonly T[]): ProductGroup<T>[] {
  const groups = new Map<string | null, ProductGroup<T>>();
  rules.forEach((rule, index) => {
    const product = productOf(rule);
    if (!groups.has(product)) groups.set(product, { product, items: [], hasFallback: false });
    const g = groups.get(product)!;
    g.items.push({ rule, index });
    if (rule.enabled && isFallback(rule)) g.hasFallback = true;
  });
  return [...groups.values()].sort((a, b) => Number(a.product === null) - Number(b.product === null));
}

/**
 * Moves the rule at `index` one place up or down among the rules of the same product, leaving every
 * other product's rules where they are. The same array back when there is nowhere to go.
 */
export function moveWithinProduct<T extends Pick<RateRuleInput, "product">>(rules: readonly T[], index: number, by: -1 | 1): T[] {
  const product = productOf(rules[index]);
  let to = index + by;
  while (to >= 0 && to < rules.length && productOf(rules[to]) !== product) {
    to += by;
  }
  if (to < 0 || to >= rules.length) {
    return rules as T[];
  }
  const next = [...rules];
  [next[index], next[to]] = [next[to], next[index]];
  return next;
}

const ruleKey = (r: RateRuleInput) =>
  JSON.stringify([r.amount.trim(), productOf(r), r.currency ?? null, r.label ?? null, r.enabled, r.conditions, r.filters]);

/** Where a rule sits among the rules of its own product: the only order the gateway reads. */
function placeInProduct(rules: readonly RateRuleInput[], rule: RateRuleInput): number {
  return rules.filter((r) => productOf(r) === productOf(rule)).findIndex((r) => r.id === rule.id);
}

/** Whether a rule in the draft is new, edited, or moved among its product's rules. */
export function priceChanged(stored: readonly RateRuleInput[], draft: readonly RateRuleInput[], rule: RateRuleInput): boolean {
  if (rule.id == null) return true;
  const was = stored.find((s) => s.id === rule.id);
  return !was || ruleKey(was) !== ruleKey(rule) || placeInProduct(stored, was) !== placeInProduct(draft, rule);
}

/** How many separate changes a staged scope makes: prices added, edited, moved and removed. */
export function scopeChangeCount(stored: readonly RateRuleInput[], draft: readonly RateRuleInput[]): number {
  const kept = new Set(draft.map((r) => r.id).filter((id) => id != null));
  return draft.filter((r) => priceChanged(stored, draft, r)).length
    + stored.filter((r) => r.id != null && !kept.has(r.id)).length;
}

/** What a scope's amounts mean, said the way the page says it. */
export const SCOPE_KIND_LABEL: Record<ScopeKind, string> = {
  price: "Account · what they pay us",
  cost: "Vendor · what it charges us",
  default: "Default · every account without its own",
  unknown: "Matches nothing",
};
