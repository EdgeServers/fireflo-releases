/**
 * Which logins the playground may offer, and which one a request resolves to.
 *
 * <p>Split out of `lib/playground.ts` so it can be tested without a database, because this is where
 * the security rule lives. The proxy accepts a login name from the request body — the one kind of
 * value `lib/require-customer.ts` warns about — and everything that stops it being a
 * credential-testing oracle against other customers is in {@link resolveOffered}.
 *
 * <p>No `pg` import, so a test can reach it.
 */

export interface PlaygroundLogin {
  /** The Basic username: the system id, for the logins this offers. */
  lookupKey: string;
  accountId: string;
  product: string | null;
  /**
   * Whether this login restricts the addresses it may be used from.
   *
   * <p>The reason the playground can fail for a customer whose own integration works: the gateway
   * checks the source address, and a call proxied through this panel arrives from the panel's
   * address rather than theirs. Knowing it up front is what lets the refusal say so.
   */
  ipRestricted: boolean;
  /**
   * Products this login may name on a send, beyond {@link product}.
   *
   * <p>Empty means the `product` field is refused outright, which is every login until an operator
   * opts one in. The playground shows a dropdown when there is something to choose and a read-only
   * chip when there is not, rather than offering a control that would always 403.
   */
  allowedProducts: string[];
}

/** One `app_credential` row, in the terms the projection returns it. */
export interface CredentialRow {
  /** The primary key, needed to name one row for a write. Never used to authorise one. */
  id?: string;
  accountId: string | null;
  systemId: string | null;
  type: string;
  product: string | null;
  ipRestricted: boolean;
  allowedProducts?: string[];
  hasPassword: boolean;
  /** True when the lookup key is the api key, which is itself a secret. */
  keyIsSecret: boolean;
  hasApiKey?: boolean;
}

/** A login a customer may rotate a secret on. Carries neither secret, only whether one is set. */
export interface RotatableLogin {
  id: string;
  /** The label. Always the system id — never the api key, which is a secret. */
  systemId: string;
  hasPassword: boolean;
  hasApiKey: boolean;
  /** True when rotating the api key would also change the username this login authenticates with. */
  keyIsUsername: boolean;
}

/**
 * The logins this account may use here.
 *
 * <p>Four exclusions, each for its own reason:
 *
 * <ul>
 *   <li><strong>Another account's.</strong> The rule the whole feature rests on.</li>
 *   <li><strong>SMPP.</strong> `CredentialAuthenticator` refuses one outright with
 *       `NOT_HTTP_CREDENTIAL`, so offering it would be offering a guaranteed failure that reads
 *       exactly like a wrong password.</li>
 *   <li><strong>No password.</strong> An api-key-only credential cannot authenticate against this
 *       API at all — the gateway answers `NO_PASSWORD_SET`.</li>
 *   <li><strong>A login whose key is its api key.</strong> That key is a secret, and listing it
 *       would print a credential on a page the operator never chose to show.</li>
 * </ul>
 */
export function offeredLogins(rows: readonly CredentialRow[], accountId: string): PlaygroundLogin[] {
  return rows
    .filter((r) => r.accountId === accountId)
    .filter((r) => r.type === "HTTP")
    .filter((r) => !!r.systemId)
    .filter((r) => r.hasPassword)
    .filter((r) => !r.keyIsSecret)
    .map((r) => ({
      lookupKey: r.systemId as string,
      accountId: r.accountId as string,
      product: r.product,
      ipRestricted: r.ipRestricted,
      //the login's own product is implicitly allowed by the gateway and is deliberately not folded
      //in here: the picker offers it separately, and merging the two would make an operator's list
      //look longer than what they configured
      allowedProducts: r.allowedProducts ?? [],
    }));
}

/**
 * What the `product` picker may offer for one login, most-likely first.
 *
 * <p>The login's own product leads, because the gateway allows it without consulting the allow list
 * at all: `CredentialFileWatcher.mayName` returns true on a candidate equal to the credential's own
 * product before it looks at `allowedProducts`. So naming it can never be the 403 the allow list
 * exists to produce.
 *
 * <p>This is where the two are joined, and {@link offeredLogins} deliberately still does not fold
 * one into the other: `allowedProducts` has to keep meaning exactly what an operator typed into
 * "Products it may name on a send", or the credential editor would show a shorter list than the
 * playground and neither would look wrong.
 *
 * <p>Empty means the field really is refused -- a login carrying no product, opted into nothing.
 * That is the only case the read-only note should appear for.
 */
export function productOptions(
  login: Pick<PlaygroundLogin, "product" | "allowedProducts"> | undefined
): string[] {
  if (!login) {
    return [];
  }
  const own = login.product?.trim();
  //a Set rather than a filter, so an operator who also listed the login's own product gets it once
  //and still gets it first
  const out = new Set<string>(own ? [own] : []);
  for (const p of login.allowedProducts) {
    const trimmed = p?.trim();
    if (trimmed) {
      out.add(trimmed);
    }
  }
  return [...out];
}

/**
 * The logins this account may rotate a secret on.
 *
 * <p>A wider set than {@link offeredLogins}, and deliberately so. That one excludes a login whose
 * lookup key is its api key, because listing it would print a live credential on screen. Rotation
 * has the opposite need: those are exactly the logins whose key somebody wants to replace. They are
 * included here and labelled by their **system id**, never by the key.
 *
 * <p>Still HTTP only and still this account only. A login with no system id is excluded because
 * there would be nothing to call it on screen, and a customer choosing between two blanks is a
 * customer about to rotate the wrong one.
 */
export function rotatableLogins(
  rows: readonly CredentialRow[],
  accountId: string
): RotatableLogin[] {
  return rows
    .filter((r) => r.accountId === accountId)
    .filter((r) => r.type === "HTTP")
    .filter((r) => !!r.systemId && !!r.id)
    .map((r) => ({
      id: r.id as string,
      systemId: r.systemId as string,
      hasPassword: r.hasPassword,
      hasApiKey: r.hasApiKey === true,
      //when an api key is set it IS the Basic username, so rotating it changes who the customer is
      //rather than only what they prove it with. The UI has to warn about that far more loudly
      keyIsUsername: r.keyIsSecret,
    }));
}

/**
 * The login with this id, but only if this account may rotate it.
 *
 * <p>An id is a number somebody can guess, so this is the whole guard. Returns null rather than
 * throwing so the caller answers with the 404 an unauthenticated call gets — naming another
 * account's credential must not confirm that it exists.
 */
export function resolveRotatable(
  logins: readonly RotatableLogin[],
  id: string | null | undefined
): RotatableLogin | null {
  const wanted = (id ?? "").trim();
  if (!wanted) {
    return null;
  }
  return logins.find((l) => l.id === wanted) ?? null;
}

/**
 * Whether this rotation is one the login can actually do.
 *
 * <p>Rotating an api key onto a login that has none would silently *change its username*, since the
 * key becomes the lookup key the moment it exists. That is a different act from replacing one, and
 * a customer clicking "rotate" has not asked for it.
 *
 * @return the reason it is refused, or null when it may go ahead
 */
export function rotationProblem(login: RotatableLogin, secret: "password" | "apiKey"): string | null {
  if (secret === "password") {
    return login.hasPassword ? null
      : "This login has no password to replace. Ask your operator to set one.";
  }
  return login.hasApiKey ? null
    : "This login has no API key. Adding one would change the username it authenticates with, so "
      + "your operator has to do it.";
}

/**
 * The named login, but only if this account may use it.
 *
 * <p>Returns null rather than throwing, so the caller answers with the same 404 an unauthenticated
 * call gets. Naming somebody else's login must not reveal that it exists — the same reasoning
 * `assertInScope` uses for a foreign account.
 *
 * <p>Scoped to the account itself and deliberately **not** to a reseller's children. A reseller may
 * read a child's records; sending as one is a different act, and nothing asks for it.
 */
export function resolveOffered(
  offered: readonly PlaygroundLogin[],
  lookupKey: string | null | undefined
): PlaygroundLogin | null {
  const wanted = (lookupKey ?? "").trim();
  if (!wanted) {
    return null;
  }
  //exact match, never case-insensitive: the gateway looks a credential up by exact string, so a
  //case-folded match here would resolve to a login the gateway would then refuse
  return offered.find((l) => l.lookupKey === wanted) ?? null;
}
