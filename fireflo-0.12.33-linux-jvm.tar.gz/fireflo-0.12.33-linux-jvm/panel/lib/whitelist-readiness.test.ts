import { test } from "node:test";
import assert from "node:assert/strict";
import {
  effectiveMode,
  enforcementReadiness,
  type WhitelistSummary,
} from "./whitelist-types.ts";

/**
 * The rule that decides whether an account may be switched to ENFORCE.
 *
 * <p>These cases exist because the previous rule — "count the one scope you were handed, refuse if
 * it is zero" — refused a configuration that runs perfectly well, and an operator lost an afternoon
 * to a card that said "1 approved" beside an error saying nothing was. The rule has to model what
 * `WhitelistSnapshot` does, so the cases below are written from the gateway's merge and not from the
 * shape of the table.
 *
 * <p>The two that matter most are `exempt products protect nothing` and `no product is served by the
 * account scope alone`: both are ways for a sum to be reassuring and wrong.
 */

function summary(
  accountId: string,
  product: string,
  headers: number,
  headerMode: "OFF" | "REPORT" | "ENFORCE" = "OFF"
): WhitelistSummary {
  return { accountId, product, headerMode, contentMode: "OFF", headers, templates: 0 };
}

const ACCT = "acme";

test("the reported case: approved under a product, enforcing at account level, is allowed", () => {
  //exactly the live data -- nothing at the account scope, one approved sender ID under 'in-otp'.
  //The gateway unions the product scope over the account scope, so 'in-otp' traffic IS checked
  //against a list containing it. The old rule refused this outright
  const summaries = [summary(ACCT, "in-otp", 1)];
  const r = enforcementReadiness(summaries, ACCT, "", "header", "ENFORCE");

  assert.equal(r.refuse, null, "a viable configuration must not be refused");
  assert.equal(r.approved, 1);
  assert.match(r.warn ?? "", /in-otp/, "the warning has to name the product that is covered");
  assert.match(r.warn ?? "", /no product set/, "and the logins that cannot be rescued by it");
});

test("nothing approved anywhere is still refused", () => {
  //the case the guard was written for, and it must survive the fix
  const r = enforcementReadiness([summary(ACCT, "", 0)], ACCT, "", "header", "ENFORCE");

  assert.match(r.refuse ?? "", /stop it sending anything at all/);
  assert.equal(r.warn, null, "a refusal is not also a warning");
  assert.equal(r.approved, 0);
});

test("approvals only under an exempt product protect nothing, so enforcing is refused", () => {
  //whitelistFor returns OFF for an exempt product before any merge, so this account's only approval
  //is inert. Counting it would wave through the outage the guard exists to prevent
  const summaries = [summary(ACCT, "in-otp", 3)];
  const r = enforcementReadiness(summaries, ACCT, "", "header", "ENFORCE", ["in-otp"]);

  assert.match(r.refuse ?? "", /not checked at all/);
  assert.match(r.refuse ?? "", /protect nothing/);
});

test("an approval at the account scope covers every product, so there is nothing to warn about", () => {
  //the account list merges into every product, so no product can be starved
  const summaries = [summary(ACCT, "", 2), summary(ACCT, "in-otp", 1)];
  const r = enforcementReadiness(summaries, ACCT, "", "header", "ENFORCE");

  assert.equal(r.refuse, null);
  assert.equal(r.warn, null, "nothing starves when the account itself has approvals");
  assert.equal(r.approved, 3);
});

test("a product scope inherits the account's approvals through the merge", () => {
  //setting ENFORCE on 'in-otp' which has none of its own, under an account that has two
  const summaries = [summary(ACCT, "", 2), summary(ACCT, "in-otp", 0)];
  const r = enforcementReadiness(summaries, ACCT, "in-otp", "header", "ENFORCE");

  assert.equal(r.refuse, null);
  assert.equal(r.approved, 2);
});

test("a product scope with nothing anywhere is refused", () => {
  const r = enforcementReadiness([summary(ACCT, "in-otp", 0)], ACCT, "in-otp", "header", "ENFORCE");
  assert.match(r.refuse ?? "", /in-otp/);
});

test("setting a product that is exempt says so rather than pretending it took effect", () => {
  const summaries = [summary(ACCT, "", 5)];
  const r = enforcementReadiness(summaries, ACCT, "in-otp", "header", "ENFORCE", ["in-otp"]);

  assert.equal(r.refuse, null, "it is storable, it just does nothing");
  assert.match(r.warn ?? "", /never consulted/);
});

test("REPORT is never refused, whatever is approved", () => {
  //REPORT is the intended first step: it refuses nothing, so it cannot stop anybody sending
  const r = enforcementReadiness([], ACCT, "", "header", "REPORT");
  assert.equal(r.refuse, null);
  assert.equal(r.warn, null);
});

test("templates are counted separately from sender IDs", () => {
  //an account with sender IDs and no templates must not be told its templates are ready
  const summaries: WhitelistSummary[] = [
    { accountId: ACCT, product: "", headerMode: "ENFORCE", contentMode: "OFF", headers: 4, templates: 0 },
  ];
  assert.equal(enforcementReadiness(summaries, ACCT, "", "header", "ENFORCE").refuse, null);
  assert.match(
    enforcementReadiness(summaries, ACCT, "", "content", "ENFORCE").refuse ?? "",
    /templates/
  );
});

test("effectiveMode: a product row sitting at OFF under an enforcing account is enforcing", () => {
  //the merge takes the product's mode only when it is not OFF. Reporting this as "not enforced" is
  //the same blind spot the guard had, in a place an operator reads to decide whether it is safe
  const summaries = [summary(ACCT, "", 1, "ENFORCE"), summary(ACCT, "in-otp", 1, "OFF")];

  assert.equal(effectiveMode(summaries, ACCT, "in-otp", "header"), "ENFORCE");
  assert.equal(effectiveMode(summaries, ACCT, "", "header"), "ENFORCE");
});

test("effectiveMode: a product's own mode wins when it is set", () => {
  const summaries = [summary(ACCT, "", 1, "ENFORCE"), summary(ACCT, "in-otp", 1, "REPORT")];
  assert.equal(effectiveMode(summaries, ACCT, "in-otp", "header"), "REPORT");
});

test("effectiveMode: an account nobody has configured is OFF, not enforcing", () => {
  //the only safe default -- an unknown account must not begin refusing traffic because a row is
  //missing, which is the gateway's own reasoning in whitelistFor
  assert.equal(effectiveMode([], ACCT, "in-otp", "header"), "OFF");
});
