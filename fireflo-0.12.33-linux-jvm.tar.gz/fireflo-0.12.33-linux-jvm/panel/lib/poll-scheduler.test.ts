import { strict as assert } from "node:assert";
import { test } from "node:test";
import { createPollScheduler, type PollTimers } from "./poll-scheduler.ts";

/** Hand-cranked timers: `tick()` fires every live interval once. */
function fakeTimers() {
  const live = new Map<number, () => void>();
  let next = 1;
  const timers: PollTimers = {
    setInterval(fn) {
      const id = next++;
      live.set(id, fn);
      return id;
    },
    clearInterval(handle) {
      live.delete(handle as number);
    },
  };
  return {
    timers,
    tick: () => [...live.values()].forEach((fn) => fn()),
    get intervals() {
      return live.size;
    },
  };
}

function rig(visible = true) {
  let runs = 0;
  const clock = fakeTimers();
  const scheduler = createPollScheduler(() => runs++, 10_000, { visible, timers: clock.timers });
  return { scheduler, clock, runs: () => runs };
}

test("the first consumer starts the poll with an immediate run; later ones add nothing", () => {
  const { scheduler, clock, runs } = rig();
  assert.equal(runs(), 0);
  assert.equal(scheduler.running, false);

  const a = scheduler.acquire();
  assert.equal(runs(), 1, "first acquire fetches at once");
  assert.equal(clock.intervals, 1);

  const b = scheduler.acquire();
  const c = scheduler.acquire();
  //three cards on one page: still one interval and no extra request (the CP-P7 fan-out)
  assert.equal(runs(), 1);
  assert.equal(clock.intervals, 1);
  assert.equal(scheduler.consumers, 3);

  clock.tick();
  assert.equal(runs(), 2, "one tick is one request however many consumers");
  a();
  b();
  c();
});

test("polling stops when the last consumer releases, and not before", () => {
  const { scheduler, clock } = rig();
  const a = scheduler.acquire();
  const b = scheduler.acquire();
  a();
  assert.equal(scheduler.running, true, "one consumer is still mounted");
  b();
  assert.equal(scheduler.running, false);
  assert.equal(clock.intervals, 0);
});

test("a release called twice does not drive the count negative", () => {
  const { scheduler } = rig();
  const a = scheduler.acquire();
  a();
  a();
  assert.equal(scheduler.consumers, 0);
  //a fresh consumer must still start it: a count of -1 would leave this one silently unpolled
  const b = scheduler.acquire();
  assert.equal(scheduler.running, true);
  b();
});

test("a hidden tab polls nothing; showing it again fetches at once and resumes the interval", () => {
  const { scheduler, clock, runs } = rig();
  const release = scheduler.acquire();
  assert.equal(runs(), 1);

  scheduler.setVisible(false);
  assert.equal(scheduler.running, false);
  clock.tick();
  clock.tick();
  assert.equal(runs(), 1, "nothing fetched while hidden");

  scheduler.setVisible(true);
  assert.equal(runs(), 2, "an immediate fetch on return, so the page is fresh when looked at");
  assert.equal(clock.intervals, 1);
  clock.tick();
  assert.equal(runs(), 3);
  release();
});

test("a consumer mounting in a hidden tab waits for the tab to be shown", () => {
  const { scheduler, runs } = rig(false);
  const release = scheduler.acquire();
  assert.equal(runs(), 0);
  assert.equal(scheduler.running, false);
  scheduler.setVisible(true);
  assert.equal(runs(), 1);
  release();
});

test("visibility with no consumers starts nothing", () => {
  const { scheduler, runs } = rig(false);
  scheduler.setVisible(true);
  scheduler.setVisible(false);
  scheduler.setVisible(true);
  assert.equal(runs(), 0);
  assert.equal(scheduler.running, false);
});

test("repeating the same visibility is a no-op rather than a re-fetch", () => {
  const { scheduler, runs } = rig();
  const release = scheduler.acquire();
  scheduler.setVisible(true);
  scheduler.setVisible(true);
  assert.equal(runs(), 1);
  release();
});
