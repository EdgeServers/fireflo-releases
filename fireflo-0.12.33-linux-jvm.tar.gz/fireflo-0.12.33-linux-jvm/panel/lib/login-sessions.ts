/**
 * An SMPP login's live connection, as the login cards show it.
 *
 * <p>No database import and no React, so the wording and the limit arithmetic can be tested alone.
 */

import type { SessionLimits } from "./credential-types.ts";

/** One session, as `/ops/sessions/summary` lists it (the gateway's session row). */
export interface LiveSession {
  session_id: number | null;
  bind_type: string | null;
  host: string | null;
  port: number | null;
  submitted: number | null;
  bound_seconds: number | null;
}

/** Sessions by bind type. */
export interface BindCounts {
  sessions: number;
  tx: number;
  rx: number;
  trx: number;
}

/** One login's summary from the gateway. Absent from the answer when nothing is bound. */
export interface SessionSummary extends BindCounts {
  listeners: string[];
  /** The same counts per listener: a login's own limits apply on each listener separately. */
  by_listener: Record<string, BindCounts>;
  hosts: string[];
  oldest_bound_seconds: number | null;
  submitted: number | null;
  rows: LiveSession[];
}

export interface BindCount {
  key: "TX" | "RX" | "TRX";
  /** Across every listener. */
  count: number;
  /** The login's own limit for this bind type, or null when it has none. */
  limit: number | null;
  /** At or past its limit on some listener: the next bind of this type there is refused. */
  full: boolean;
}

export interface ConnectionView {
  connected: boolean;
  sessions: number;
  /** The login's own session limit, or null. */
  limit: number | null;
  /** Bound on more than one listener, so a limit reads "per listener" rather than against the total. */
  perListener: boolean;
  full: boolean;
  binds: BindCount[];
  /** "TRX is at its limit: the next TRX bind is refused.", or null. */
  note: string | null;
}

/**
 * What a card shows for a login, from its summary (absent when nothing is bound) and its limits.
 *
 * <p>Limits are checked against the busiest listener, not the total: the gateway enforces a login's
 * own limits per listener, so five sessions split across two listeners is not at a limit of five.
 */
export function connectionView(summary: SessionSummary | undefined, limits: SessionLimits | null | undefined): ConnectionView {
  const sessions = summary?.sessions ?? 0;
  const perListener = Object.values(summary?.by_listener ?? {});
  const busiest = (pick: (c: BindCounts) => number) =>
    perListener.length ? Math.max(...perListener.map(pick)) : summary ? pick(summary) : 0;
  const limit = limits?.maxSessions ?? null;
  const bind = (key: BindCount["key"], pick: (c: BindCounts) => number, max: number | null | undefined): BindCount => ({
    key, count: summary ? pick(summary) : 0, limit: max ?? null, full: max != null && busiest(pick) >= max,
  });
  const binds = [
    bind("TX", (c) => c.tx, limits?.maxTx),
    bind("RX", (c) => c.rx, limits?.maxRx),
    bind("TRX", (c) => c.trx, limits?.maxTrx),
  ];
  const full = limit != null && busiest((c) => c.sessions) >= limit;
  const fullBinds = binds.filter((b) => b.full).map((b) => b.key);
  const where = perListener.length > 1 ? " on a listener" : "";
  let note: string | null = null;
  if (full) {
    note = `At its limit of ${limit} ${limit === 1 ? "session" : "sessions"}${where}: the next bind there is refused.`;
  } else if (fullBinds.length) {
    note = `${fullBinds.join(" and ")} ${fullBinds.length === 1 ? "is" : "are"} at ${fullBinds.length === 1 ? "its" : "their"} limit${where}: `
      + `the next ${fullBinds.join(" or ")} bind there is refused.`;
  }
  return { connected: sessions > 0, sessions, limit, perListener: perListener.length > 1, full, binds, note };
}

/** "2 h 14 m", "36 m", "45 s", "5 d 3 h": how long a session has been bound. */
export function boundFor(seconds: number | null | undefined): string {
  if (seconds == null || seconds < 0) return "—";
  if (seconds < 60) return `${Math.floor(seconds)} s`;
  const m = Math.floor(seconds / 60);
  if (m < 60) return `${m} m`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} h ${m % 60} m`;
  return `${Math.floor(h / 24)} d ${h % 24} h`;
}

/** The gateway's bind-type name in the panel's three letters. */
export function bindLabel(bindType: string | null | undefined): string {
  switch (bindType) {
    case "TRANSMITTER": return "TX";
    case "RECEIVER": return "RX";
    case "TRANSCEIVER": return "TRX";
    default: return "binding";
  }
}
