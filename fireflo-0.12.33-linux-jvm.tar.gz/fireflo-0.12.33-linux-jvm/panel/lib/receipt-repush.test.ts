import { test } from "node:test";
import assert from "node:assert/strict";
import {
  DEFAULT_REPUSH_TPS,
  REPUSH_STATES,
  dryRunSentence,
  finishedSentence,
  isJobId,
  isRunning,
  progressPercent,
  readJobId,
  readRepushDryRun,
  readRepushStatus,
  repushBody,
  repushPath,
  repushProblem,
  statusLine,
  type RepushForm,
} from "./receipt-repush.ts";

/**
 * Re-sending receipts to an SMPP login: the request the gateway is sent, the dry-run sentence, and
 * how a job's progress is read. The dialog is a thin shell over these.
 */

const NOW = new Date("2026-10-16T12:00:00Z");
const ALL = REPUSH_STATES.map((s) => s.value as string);

function form(over: Partial<RepushForm> = {}): RepushForm {
  return {
    since: "2026-10-01T09:00:00.000Z",
    until: "2026-10-01T12:00:00.000Z",
    states: [...ALL],
    includeProgress: false,
    tps: String(DEFAULT_REPUSH_TPS),
    note: "customer lost receipts in their outage",
    ...over,
  };
}

test("the gateway paths", () => {
  assert.equal(repushPath(), "/ops/receipts/repush");
  assert.equal(repushPath("job-1"), "/ops/receipts/repush/job-1");
  assert.ok(isJobId("6f1c2d3e-4a5b-4c6d-8e7f-0123456789ab"));
  assert.ok(!isJobId("../../ops/reload"));
  assert.ok(!isJobId(""));
});

test("the request body: the plan's fields, states left out when every outcome is ticked", () => {
  assert.deepEqual(repushBody("acme01", form(), { dryRun: true, actor: "ops@example.com" }), {
    systemId: "acme01",
    since: "2026-10-01T09:00:00.000Z",
    until: "2026-10-01T12:00:00.000Z",
    tps: 50,
    dryRun: true,
    note: "customer lost receipts in their outage",
    actor: "ops@example.com",
  });
  const some = repushBody("acme01", form({ states: ["DELIVERED", "FAILED"], includeProgress: true, tps: "5" }), { dryRun: false });
  assert.deepEqual(some.states, ["DELIVERED", "FAILED"]);
  assert.equal(some.includeProgress, true);
  assert.equal(some.tps, 5);
  assert.equal(some.dryRun, false);
});

test("problems: period order, at most 31 days, an outcome, a whole rate, a note", () => {
  assert.equal(repushProblem(form(), NOW), null);
  assert.match(repushProblem(form({ until: "2026-10-01T08:00:00Z" }), NOW) ?? "", /ends before it starts/);
  assert.match(repushProblem(form({ since: "2026-08-01T00:00:00Z", until: "2026-09-15T00:00:00Z" }), NOW) ?? "", /at most 31/);
  assert.equal(repushProblem(form({ since: "2026-09-01T00:00:00Z", until: "2026-10-02T00:00:00Z" }), NOW), null, "31 days exactly is allowed");
  assert.match(repushProblem(form({ states: [] }), NOW) ?? "", /at least one outcome/);
  assert.match(repushProblem(form({ states: ["DELIVRD"] }), NOW) ?? "", /Unknown outcome/);
  assert.match(repushProblem(form({ tps: "2.5" }), NOW) ?? "", /whole number/);
  assert.match(repushProblem(form({ tps: "0" }), NOW) ?? "", /whole number/);
  assert.match(repushProblem(form({ note: "  " }), NOW) ?? "", /note/);
  assert.match(repushProblem(form({ since: "2026-11-01T00:00:00Z", until: "2026-11-02T00:00:00Z" }), NOW) ?? "", /future/);
});

test("the dry-run sentence, bound and unbound", () => {
  const bound = readRepushDryRun({ messages: 1790, receipts: 1842, byState: { DELIVERED: 1700, FAILED: 90 }, bound: true, sessions: 2, etaSeconds: 37 });
  assert.equal(dryRunSentence(bound, 50), "1,842 receipts for 1,790 messages, login bound on 2 sessions, about 37 s at 50/s");
  const unbound = readRepushDryRun({ byState: { DELIVERED: 20 }, bound: false });
  assert.equal(unbound.messages, 20, "the total falls back to the per-state counts");
  assert.equal(unbound.receipts, 20);
  assert.equal(
    dryRunSentence(unbound, 5),
    "20 receipts for 20 messages, login not bound — they are stored and replayed on its next bind, about 4 s at 5/s"
  );
  assert.equal(readRepushDryRun({ sessions: 0 }).bound, false);
  assert.equal(readRepushDryRun({}).bound, null);
});

test("job status: the plan's fields, progress, and when to stop polling", () => {
  const s = readRepushStatus({ state: "running", total: 100, sent: 40, storedForReplay: 10, skippedPending: 3, failed: 0, startedAt: "2026-10-16T11:59:00Z", eta: 12 });
  assert.equal(progressPercent(s), 50);
  assert.ok(isRunning(s.state));
  assert.equal(statusLine(s), "40 sent · 10 stored for replay · 3 skipped (still pending) of 100");
  assert.equal(s.eta, 12);

  const done = readRepushStatus({ state: "done", total: 100, sent: 100 });
  assert.ok(!isRunning(done.state));
  assert.equal(progressPercent(done), 100);
  assert.equal(finishedSentence(done), "Finished.");
  assert.match(finishedSentence(readRepushStatus({ state: "cancelled" })), /already sent stay sent/);
  assert.match(finishedSentence(readRepushStatus({ state: "interrupted" })), /restarted/);
  assert.equal(readRepushStatus(null).state, "unknown");
  assert.ok(!isRunning("unknown"), "an unreadable state stops the polling rather than spinning forever");
});

test("the job id is read from {jobId}, and only a safe one", () => {
  assert.equal(readJobId({ jobId: "j-42" }), "j-42");
  assert.equal(readJobId({ jobId: "a/b" }), null);
  assert.equal(readJobId(null), null);
});
