import { strict as assert } from "node:assert";
import { test } from "node:test";

import {
  billReference,
  creditNoteMessage,
  parseBillReference,
  restatementOf,
  type ClosedPeriod,
} from "./period-close.ts";

const money = (scaled: number) => (scaled / 10_000).toFixed(4);

function closed(overrides: Partial<ClosedPeriod> = {}): ClosedPeriod {
  return { label: "2026-08", invoiced: 100_000, closedAt: "2026-09-01T00:00:00Z", note: null, ...overrides };
}

test("the reference is deterministic, so closing twice collides", () => {
  //uq_balance_ledger_ref is what stops a second invoice for the same period. It only works if two
  //operators clicking at the same moment produce the same string
  assert.equal(billReference("acct-1001", "2026-08"), "bill:acct-1001:2026-08");
  assert.equal(billReference("acct-1001", "2026-08"), billReference("acct-1001", "2026-08"));
  assert.notEqual(billReference("acct-1001", "2026-08"), billReference("acct-1001", "2026-09"));
  assert.notEqual(billReference("acct-1001", "2026-08"), billReference("acct-1002", "2026-08"));
});

test("a reference round-trips, including an account id containing a colon", () => {
  //split on the LAST colon, because the label never contains one and an account id might
  assert.deepEqual(parseBillReference("bill:acct-1001:2026-08"), { accountId: "acct-1001", label: "2026-08" });
  assert.deepEqual(parseBillReference("bill:a:b:2026-08"), { accountId: "a:b", label: "2026-08" });
  const custom = billReference("acct-1001", "2026-08-01..2026-08-15");
  assert.deepEqual(parseBillReference(custom), { accountId: "acct-1001", label: "2026-08-01..2026-08-15" });
});

test("something that is not a bill reference parses to nothing", () => {
  assert.equal(parseBillReference(null), null);
  assert.equal(parseBillReference("receipt-88"), null);
  assert.equal(parseBillReference("bill:"), null);
  assert.equal(parseBillReference("bill:acct-1001"), null);
});

test("a period that has not moved produces no credit note", () => {
  assert.equal(restatementOf(closed(), 100_000), null);
});

test("rounding is not money", () => {
  //one ten-thousandth either way is the smallest representable amount, and issuing a credit note
  //for it would bury the ones that matter
  assert.equal(restatementOf(closed(), 100_000), null);
  assert.notEqual(restatementOf(closed(), 100_001), null);
  assert.notEqual(restatementOf(closed(), 99_999), null);
});

test("a refund after close is a credit forward, never a restatement", () => {
  //the case the whole module exists for: a refund lands in September for a message sent in August
  const r = restatementOf(closed({ invoiced: 100_000 }), 95_000);
  assert.ok(r);
  assert.equal(r.difference, -5_000);
  const message = creditNoteMessage(r, money);
  assert.match(message, /invoice stands/);
  assert.match(message, /0\.5000 is owed back/);
  assert.match(message, /carries forward/);
  //it must NOT tell the operator the period is now a different number to reissue
  assert.ok(!/reissue/i.test(message), message);
});

test("an under-charge carries forward too, and says which direction", () => {
  const r = restatementOf(closed({ invoiced: 100_000 }), 112_500);
  assert.ok(r);
  assert.equal(r.difference, 12_500);
  assert.match(creditNoteMessage(r, money), /1\.2500 was under-charged/);
});

// ---------------------------------------------------------------------------
// Test plan M15. Cases above predate the plan; these fill the gaps it names.
// ---------------------------------------------------------------------------

test("M15.4 the reference is a pure function of its two inputs", () => {
  //determinism IS the idempotency guarantee: uq_balance_ledger_ref turns a second close into a
  //conflict rather than a second invoice, and that only works if the same period always names
  //the same reference. Any clock, counter or random component here silently breaks it
  const a = billReference("acct-1001", "2026-08");
  for (let i = 0; i < 50; i++) {
    assert.equal(billReference("acct-1001", "2026-08"), a);
  }
  assert.notEqual(billReference("acct-1002", "2026-08"), a, "a different account differs");
  assert.notEqual(billReference("acct-1001", "2026-09"), a, "so does a different period");
});

test("M15.6 an account id containing colons round-trips, because the LAST colon splits", () => {
  const parsed = parseBillReference(billReference("acct:with:colons", "2026-08"));
  assert.deepEqual(parsed, { accountId: "acct:with:colons", label: "2026-08" });
});

test("M15.6 EDGE a label containing a colon does not round-trip", () => {
  //the module's own comment says the label may not contain a colon. Nothing enforces that, so the
  //split lands in the wrong place and the accountId absorbs part of the label. Pinned as a known
  //limit: if date-span labels ever grow a colon, this is what breaks and where
  const ref = billReference("acct-1001", "2026-08:2026-09");
  assert.deepEqual(parseBillReference(ref), {
    accountId: "acct-1001:2026-08",
    label: "2026-09",
  });
});

test("M15 malformed references parse to nothing rather than to something wrong", () => {
  for (const bad of ["", "bill:", "bill:x", "notabill:x:y", "acct:2026-08", "BILL:x:y"]) {
    assert.equal(parseBillReference(bad), null, `${JSON.stringify(bad)} must not parse`);
  }
  assert.equal(parseBillReference(null), null);
});

test("M15.1 restatementOf never returns a new invoiced figure to write back", () => {
  //the guard on immutability at this layer: whatever it returns, `invoiced` is untouched, so a
  //caller cannot accidentally treat the result as a corrected invoice
  const r = restatementOf(closed(), 90_000);
  assert.ok(r);
  assert.equal(r.invoiced, 100_000, "the invoice as it was closed");
  assert.equal(r.recomputed, 90_000);
  assert.equal(r.difference, -10_000);
});

test("M15.2 FINDING: MATERIAL reads like a tolerance and behaves as exact equality", () => {
  //`Math.abs(difference) < MATERIAL` with MATERIAL = 1, over integer ten-thousandths, means only a
  //difference of zero is suppressed. But the constant's own comment says "One ten-thousandth is
  //rounding, not money" -- which describes `<=`, not `<`.
  //
  //So a one-unit difference raises a credit note the comment says it should not. Pinned as current
  //behaviour, not endorsed. The identical off-by-one is in reconcile.ts, which suggests one shared
  //decision rather than two slips -- worth settling in one place.
  assert.equal(restatementOf(closed(), 100_000), null, "no movement at all is suppressed");
  assert.ok(restatementOf(closed(), 100_001), "but one unit up DOES raise a note");
  assert.ok(restatementOf(closed(), 99_999), "and one unit down does too");
  assert.equal(restatementOf(closed(), 100_001)?.difference, 1);
});

test("M15.2 the credit note says the invoice stands, in both directions", () => {
  const over = restatementOf(closed(), 90_000);
  assert.ok(over);
  const overText = creditNoteMessage(over, money);
  assert.match(overText, /invoice stands/i);
  assert.match(overText, /2026-08/);

  const under = restatementOf(closed(), 130_000);
  assert.ok(under);
  const underText = creditNoteMessage(under, money);
  assert.match(underText, /invoice stands/i);
  assert.notEqual(overText, underText, "the two directions do not read the same");
});

test("M15 anti-vacuity: a restatement that always returned null would fail these", () => {
  //still correct AS A PROPERTY OF THIS FUNCTION: a period where everything was genuinely refunded
  //does compute to zero and is a full credit. What was wrong was the caller -- statementSummary
  //read cdr_submit alone, so a PURGED period also arrived here as zero and a paid invoice was
  //reported as entirely owed back. The summary now carries `recomputable` and the route checks it
  //before calling this at all; see the javadoc on restatementOf
  assert.ok(restatementOf(closed(), 0), "a period recomputing to zero is a full credit");
  assert.ok(restatementOf(closed(), 900_000), "and a large under-charge is one too");
});

test("M15 restatementOf does not mutate the closed period it was given", () => {
  const c = closed();
  const before = JSON.stringify(c);
  restatementOf(c, 90_000);
  assert.equal(JSON.stringify(c), before);
});
