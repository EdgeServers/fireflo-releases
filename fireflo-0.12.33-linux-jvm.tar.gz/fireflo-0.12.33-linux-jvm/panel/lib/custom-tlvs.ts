/**
 * The `custom_tlvs` grammar, as the gateway's REST ingress actually reads it.
 *
 * <p>The panel's copy of `SendRequestParser.readCustomTlvs` and `TlvUtil.parseTag`, and it has to
 * agree with them exactly — same argument `tlv-string.ts` makes for its own format: the panel's job
 * is to show a customer what the gateway will do with what they typed, and a parser that disagreed
 * would confidently describe behaviour that never happens.
 *
 * <p><strong>This is NOT the format `tlv-string.ts` handles</strong>, and the difference is the
 * reason this file exists rather than reusing it. That module parses the comma-joined
 * `name_tag=value` string stored in `app_header.tlvs`, and two of its rules are actively wrong here:
 *
 * <ul>
 *   <li>It refuses a value containing a comma, because nothing in that format is escaped. In JSON a
 *       comma in a value is ordinary.
 *   <li>It calls a token with no underscore a mistake. Here `0x1400` is the documented, correct
 *       form — the underscore is the optional half.
 * </ul>
 *
 * <p>Wiring those validators to this field would produce amber warnings about correct payloads,
 * which is worse than no warning at all.
 *
 * <p>Database-free, so a client component can import it.
 */

/** The wire encodings a key may pin, spelled as the gateway's `TlvUtil.TlvType` tokens. */
export const TLV_TYPES = [
  "OctetString",
  "COctetString",
  "Int1",
  "Int2",
  "Int4",
  "Int8",
] as const;

export type TlvTypeToken = (typeof TLV_TYPES)[number];

/** What the gateway assumes when a key pins nothing. */
export const DEFAULT_TLV_TYPE: TlvTypeToken = "OctetString";

/**
 * How many octets each integer type occupies.
 *
 * <p><strong>Octets, not bits.</strong> `Int8` is an eight-byte field, which is the SMPP convention
 * and the one the gateway implements — an India DLT template id around 1.4e18 fits nowhere smaller.
 * Read as bits it would look like a one-byte field, and the resulting refusal would be baffling.
 */
const INT_WIDTHS: Record<string, number> = { Int1: 1, Int2: 2, Int4: 4, Int8: 8 };

export interface CustomTlv {
  /** The tag token alone — `0x1401`, `5121`, `tmid_0x1401`. The type is held separately. */
  tag: string;
  type: TlvTypeToken;
  value: string;
}

export function emptyCustomTlv(): CustomTlv {
  return { tag: "", type: DEFAULT_TLV_TYPE, value: "" };
}

/**
 * The tag a token names, or null when it names none.
 *
 * <p>A transcription of `TlvUtil.parseTag`, including the two decisions in it that surprise people:
 *
 * <ul>
 *   <li>The tag is what follows the <strong>last</strong> underscore, so `tmid_0x1401` is tag
 *       0x1401 and the name in front is decoration the gateway keeps for its own logs.
 *   <li>Hex only when asked for with `0x`. A bare `1401` is <strong>decimal</strong> 1401, which is
 *       tag 0x0579 — not the 0x1401 almost everyone means. The Java avoids `Integer.decode`
 *       specifically so that a leading zero is not read as octal.
 * </ul>
 */
export function customTlvTag(token: string): number | null {
  const trimmed = (token ?? "").trim();
  const lastSeparator = trimmed.lastIndexOf("_");
  let tagPart = lastSeparator < 0 ? trimmed : trimmed.slice(lastSeparator + 1);
  if (!tagPart) {
    return null;
  }

  let radix = 10;
  if (tagPart.length > 2 && (tagPart.startsWith("0x") || tagPart.startsWith("0X"))) {
    tagPart = tagPart.slice(2);
    radix = 16;
  }
  //parseInt stops at the first character it cannot read, so "12ab" would become 12 -- the Java's
  //Integer.parseInt throws instead, and this has to agree with the Java
  const pattern = radix === 16 ? /^[0-9a-fA-F]+$/ : /^\d+$/;
  if (!pattern.test(tagPart)) {
    return null;
  }
  const tag = parseInt(tagPart, radix);
  return tag >= 0 && tag <= 0xffff ? tag : null;
}

/** The canonical key the gateway stores the value under, whatever spelling arrived. */
export function canonicalTag(tag: number): string {
  return `0x${tag.toString(16).toUpperCase().padStart(4, "0")}`;
}

/**
 * What is wrong with one row, in the customer's terms, or null.
 *
 * <p>Two kinds of finding, and the second is the point of having this at all. Most of these mirror a
 * refusal the gateway would issue anyway — saying it here just saves a round trip. But the
 * bare-decimal warning has no gateway equivalent: `1401` parses perfectly and means a tag nobody
 * intended, so the gateway sends it, the carrier ignores it, and the message is delivered without
 * the parameter it was meant to carry. That one is only catchable here.
 */
export function customTlvProblem(row: CustomTlv): string | null {
  const tagToken = (row.tag ?? "").trim();
  if (!tagToken) {
    return null;
  }

  const tag = customTlvTag(tagToken);
  if (tag === null) {
    return `'${tagToken}' names no tag. Write the number — 0x1401, or 5121 in decimal — optionally `
      + `with a name in front, as in tmid_0x1401. A name on its own is not enough: the gateway `
      + `matches on the number.`;
  }

  //The ambiguous shape: it parses, so nothing downstream complains, and it parses as the reading
  //only some people meant. Decimal tags ARE legal and some vendors publish them that way, so this
  //says what the number resolves to rather than telling anyone they are wrong -- the customer who
  //meant decimal reads a confirmation, and the one who meant hex sees their mistake in the same
  //sentence. A message that assumed the mistake would be wrong half the time it appeared.
  if (!tagToken.includes("_") && /^\d+$/.test(tagToken)) {
    const asHex = customTlvTag(`0x${tagToken}`);
    if (asHex !== null && asHex !== tag) {
      return `'${tagToken}' is read as decimal, so this is tag ${canonicalTag(tag)}. `
        + `Write 0x${tagToken} if you meant that hex tag instead.`;
    }
  }

  const width = INT_WIDTHS[row.type];
  if (width) {
    const text = (row.value ?? "").trim();
    if (!text) {
      return `${row.type} needs a number. Leave the type as OctetString to send text.`;
    }
    if (!/^-?\d+$/.test(text)) {
      return `${row.type} needs a whole number, and this is not one. Leave the type as OctetString `
        + `to send it as text.`;
    }
    //two's complement in `width` octets, matching TlvUtil.encodeTyped, which refuses rather than
    //truncating -- a silently narrowed identifier is worse than a refused message.
    //
    //BigInt(2) ** rather than a `1n` literal: this file's target predates BigInt literal syntax,
    //and the values genuinely exceed Number.MAX_SAFE_INTEGER -- a DLT template id is ~1.4e18
    const limit = BigInt(2) ** BigInt(width * 8 - 1);
    const number = BigInt(text);
    if (number >= limit || number < -limit) {
      return `${text} does not fit ${row.type}, which is ${width} ${width === 1 ? "byte" : "bytes"} `
        + `— note that the number is octets, not bits. Try Int8 for a long identifier.`;
    }
  }
  return null;
}

/**
 * Tags named more than once, however they were spelled.
 *
 * <p>The gateway refuses the whole request for this rather than picking one, so two rows that look
 * different and resolve to one tag are worth saying out loud before the request is made.
 */
export function duplicateCustomTlvTags(rows: readonly CustomTlv[]): number[] {
  const seen = new Map<number, number>();
  for (const row of rows) {
    const tag = customTlvTag(row.tag);
    if (tag !== null) {
      seen.set(tag, (seen.get(tag) ?? 0) + 1);
    }
  }
  return [...seen.entries()].filter(([, n]) => n > 1).map(([tag]) => tag);
}

/**
 * The object the API wants, or undefined when there is nothing to send.
 *
 * <p>Undefined rather than `{}`: an empty object is a field the customer did not fill in, and
 * sending it would put `"custom_tlvs": {}` into every generated code sample as though it were part
 * of the request.
 *
 * <p>The key carries the type only when one is pinned, because that is how the gateway's own
 * documentation writes it and a sample full of `:OctetString` would read as required.
 */
export function buildCustomTlvs(rows: readonly CustomTlv[]): Record<string, string> | undefined {
  const out: Record<string, string> = {};
  for (const row of rows) {
    const tag = (row.tag ?? "").trim();
    if (!tag) {
      continue;
    }
    const key = row.type && row.type !== DEFAULT_TLV_TYPE ? `${tag}:${row.type}` : tag;
    out[key] = row.value ?? "";
  }
  return Object.keys(out).length ? out : undefined;
}
