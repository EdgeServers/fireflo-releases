/**
 * What a TLV tag means, so a number can be shown with a name beside it.
 *
 * <p>Database-free and client-safe: this is imported by the worker form, the credential form and the
 * message detail view. It must never reach `config-db` or `metrics-db` — the `cdr-request.ts` /
 * `cdr-queries.ts` split is the precedent, and the failure mode is not one broken page but every
 * page returning 500 on a `dns` resolution the bundler cannot satisfy.
 *
 * <p><strong>This is a naming aid and never a validator.</strong> The gateway accepts any tag from
 * 0x0000 to 0xFFFF and treats names as cosmetic — `TlvUtil.parseDeclarations` logs and skips a token
 * it cannot parse and never fails. So a tag nobody has named is perfectly legal, and nothing here may
 * refuse one, mark one invalid, or stop one being saved.
 *
 * <p>{@link tlvSuggestions} does take a curation map, and that is not a softening of the above. It
 * decides what a `<datalist>` offers, and a datalist is non-binding: a tag left out of it can still
 * be typed into the same field, still resolves to its name, still validates and still saves. What is
 * curated is the offer, never the field.
 *
 * <p>Three layers, and the operator can see which one an answer came from:
 *
 * <ol>
 *   <li><strong>Spec</strong> — {@link SPEC_TAGS}, the 63 optional parameters cloudhopper knows.</li>
 *   <li><strong>Convention</strong> — {@link CONVENTION_TAGS}, tags the industry uses by agreement
 *       rather than by specification.</li>
 *   <li><strong>Operator</strong> — passed in by the caller. This module never fetches.</li>
 * </ol>
 */
import { humanise } from "./labels";
//re-exported rather than defined here: `tlv-string` owns the `<name>_<tag>` format, and this
//module is about what the tags MEAN. Importers were already reaching for it here, so the name
//stays available at both addresses
export { tlvTag } from "./tlv-string";

export type TlvProvenance = "spec" | "convention" | "operator";

export interface TlvDefinition {
  tag: number;
  /** The conventional token name, as it appears in a `<name>_<tag>` declaration. */
  name: string;
  /** English, when the name alone does not read as a sentence. */
  label?: string;
  /** A caveat worth carrying to the screen. */
  note?: string;
  /** Free prose from an operator definition — what a vendor expects, how it is encoded. */
  description?: string;
}

export interface ResolvedTlv {
  tag: number;
  name: string;
  label: string;
  note?: string;
  provenance: TlvProvenance;
  /** What this definition covers up, when an operator has renamed a tag the spec already names. */
  shadows?: { name: string; provenance: TlvProvenance };
}

/**
 * The SMPP optional parameters, from `com.cloudhopper.smpp.SmppConstants.TAG_NAME_MAP` in
 * cloudhopper-smpp 7.2.3 — dumped from the jar rather than transcribed.
 *
 * <p><strong>The same source the gateway already uses.</strong> `SmppClientSessionHandler` and
 * `SmppServerSessionHandler` both resolve PDU log names from that map, so a name shown here is the
 * name that appears in the gateway's own logs for the same tag.
 *
 * <p>Two things the map itself cannot tell you. `source_telematics_id` is 0x0010, which cloudhopper
 * also exposes as `TAG_SOURCE_TELE_ID` — one tag, two constant names, and the map keeps one.
 * `orig_msc_addr` and `dest_msc_addr` are 0x8081 and 0x8082, which are negative as Java shorts;
 * they are written unsigned here, which is what `tlvTag` produces.
 */
export const SPEC_TAGS: readonly TlvDefinition[] = [
  { tag: 0x0005, name: "dest_addr_subunit" },
  { tag: 0x0006, name: "dest_network_type" },
  { tag: 0x0007, name: "dest_bearer_type" },
  { tag: 0x0008, name: "dest_telematics_id" },
  { tag: 0x000D, name: "source_addr_subunit" },
  { tag: 0x000E, name: "source_network_type" },
  { tag: 0x000F, name: "source_bearer_type" },
  { tag: 0x0010, name: "source_telematics_id" },
  { tag: 0x0017, name: "qos_time_to_live" },
  { tag: 0x0019, name: "payload_type" },
  { tag: 0x001D, name: "additional_status_info" },
  { tag: 0x001E, name: "receipted_message_id" },
  { tag: 0x0030, name: "ms_msg_wait_facilities" },
  { tag: 0x0201, name: "privacy_indicator" },
  { tag: 0x0202, name: "source_subaddr" },
  { tag: 0x0203, name: "dest_subaddr" },
  { tag: 0x0204, name: "user_message_reference" },
  { tag: 0x0205, name: "user_response_code" },
  { tag: 0x020A, name: "source_port" },
  { tag: 0x020B, name: "dest_port" },
  { tag: 0x020C, name: "sar_msg_ref_num" },
  { tag: 0x020D, name: "lang_indicator" },
  { tag: 0x020E, name: "sar_total_segments" },
  { tag: 0x020F, name: "sar_segment_seqnum" },
  { tag: 0x0210, name: "sc_interface_version" },
  { tag: 0x0302, name: "callback_num_pres_ind" },
  { tag: 0x0303, name: "callback_num_atag" },
  { tag: 0x0304, name: "num_msgs_in_mailbox" },
  { tag: 0x0381, name: "callback_num" },
  { tag: 0x0420, name: "dpf_result" },
  { tag: 0x0421, name: "set_dpf" },
  { tag: 0x0422, name: "ms_avail_status" },
  { tag: 0x0423, name: "network_error_code" },
  { tag: 0x0424, name: "message_payload" },
  { tag: 0x0425, name: "delivery_failure_reason" },
  { tag: 0x0426, name: "more_msgs_to_follow" },
  { tag: 0x0427, name: "message_state" },
  { tag: 0x0428, name: "congestion_state" },
  { tag: 0x0501, name: "ussd_service_op" },
  { tag: 0x0600, name: "broadcast_channel_indicator" },
  { tag: 0x0601, name: "broadcast_content_type" },
  { tag: 0x0602, name: "broadcast_content_type_info" },
  { tag: 0x0603, name: "broadcast_message_class" },
  { tag: 0x0604, name: "broadcast_rep_num" },
  { tag: 0x0605, name: "broadcast_frequency_interval" },
  { tag: 0x0606, name: "broadcast_area_identifier" },
  { tag: 0x0607, name: "broadcast_error_status" },
  { tag: 0x0608, name: "broadcast_area_success" },
  { tag: 0x0609, name: "broadcast_end_time" },
  { tag: 0x060A, name: "broadcast_service_group" },
  { tag: 0x060B, name: "billing_identification" },
  { tag: 0x060D, name: "source_network_id" },
  { tag: 0x060E, name: "dest_network_id" },
  { tag: 0x060F, name: "source_node_id" },
  { tag: 0x0610, name: "dest_node_id" },
  { tag: 0x1201, name: "display_time" },
  { tag: 0x1203, name: "sms_signal" },
  { tag: 0x1204, name: "ms_validity" },
  { tag: 0x130C, name: "alert_on_msg_delivery" },
  { tag: 0x1380, name: "its_reply_type" },
  { tag: 0x1383, name: "its_session_info" },
  { tag: 0x8081, name: "orig_msc_addr" },
  { tag: 0x8082, name: "dest_msc_addr" },
];

/**
 * Tags the industry agrees on without anything reserving them.
 *
 * <p>Kept apart from {@link SPEC_TAGS} rather than merged, because the distinction is the useful
 * part: the docs' own warning is that "nothing reserves these tags and aggregators do differ, so
 * confirm them with your vendor before relying on them". A name shown without that caveat is a
 * claim this panel is not entitled to make.
 *
 * <p>Verified disjoint from {@link SPEC_TAGS} — SMPP 3.4 reserves 0x1400–0x3FFF for vendor use and
 * cloudhopper names nothing in that range. {@link tlvCatalogueIsDisjoint} keeps it that way.
 */
export const CONVENTION_TAGS: readonly TlvDefinition[] = [
  {
    tag: 0x1400,
    name: "peid",
    label: "Principal Entity ID (TRAI DLT)",
    note:
      "Industry convention for Indian DLT, not the SMPP spec — confirm it with your vendor. "
      + "Note the gateway emits this same tag as source_network_id (MCC/MNC) on outbound "
      + "deliver_sm: a different PDU travelling the other way, so nothing collides, but do not read "
      + "one as the other in a PDU log.",
  },
  {
    tag: 0x1401,
    name: "tmplid",
    label: "Content Template ID (TRAI DLT)",
    note:
      "Industry convention, not the SMPP spec. Identifies the approved template a message was sent "
      + "against, so it belongs to the individual message — giving it a default at any level "
      + "mislabels every message that omitted it.",
  },
  {
    tag: 0x1402,
    name: "tmid",
    label: "Telemarketer ID (TRAI DLT)",
    note: "Industry convention, not the SMPP spec. Your own registration with the vendor.",
  },
];

/** Every built-in definition, spec first. */
const BUILT_IN: readonly (TlvDefinition & { provenance: TlvProvenance })[] = [
  ...SPEC_TAGS.map((d) => ({ ...d, provenance: "spec" as const })),
  ...CONVENTION_TAGS.map((d) => ({ ...d, provenance: "convention" as const })),
];

/**
 * What a tag means, or null when nothing has named it.
 *
 * <p>Null is an ordinary answer, not a failure — most of the 65,536 tags mean nothing to anyone, and
 * a vendor using one is doing something completely legal.
 *
 * @param operator definitions the operator has recorded. Passed in rather than fetched, which is what
 *     keeps this module free of any database import and testable without one
 */
export function resolveTlv(
  tag: number | null,
  operator: readonly TlvDefinition[] = []
): ResolvedTlv | null {
  if (tag == null) {
    return null;
  }
  const own = operator.find((d) => d.tag === tag);
  const builtIn = BUILT_IN.find((d) => d.tag === tag);

  if (own) {
    return {
      ...own,
      label: own.label ?? humanise(own.name),
      provenance: "operator",
      //surfaced, never swallowed: renaming a tag the spec already names is the one way this feature
      //can quietly mislead someone reading a PDU log beside the panel
      shadows: builtIn ? { name: builtIn.name, provenance: builtIn.provenance } : undefined,
    };
  }
  if (builtIn) {
    return { ...builtIn, label: builtIn.label ?? humanise(builtIn.name) };
  }
  return null;
}

/**
 * What a token field offers, as `<name>_0x….`
 *
 * <p>The panel knows 66 tags and a deployment typically uses four, so an uncurated list buries the
 * four that matter among sixty that will never appear here.
 *
 * <p><strong>An offer, not a restriction.</strong> A tag left out is still typeable into the same
 * field, still resolves through {@link resolveTlv}, still validates and still saves — which is why
 * the filter lives here and never in the resolver.
 *
 * @param suggested decisions keyed by tag. A tag with no entry has never been considered and is
 *     offered, so an empty map is the whole catalogue rather than none of it
 */
export function tlvSuggestions(
  operator: readonly TlvDefinition[] = [],
  suggested: Record<number, boolean> = {}
): string[] {
  const seen = new Map<number, string>();
  for (const d of [...BUILT_IN, ...operator.map((d) => ({ ...d, provenance: "operator" as const }))]) {
    if (suggested[d.tag] ?? true) {
      seen.set(d.tag, `${d.name}_0x${d.tag.toString(16).toUpperCase().padStart(4, "0")}`);
    }
  }
  return [...seen.values()].sort();
}

/**
 * Whether the two built-in layers name any tag in common.
 *
 * <p>They must not. Keeping them disjoint means there is no precedence rule to write between spec and
 * convention, and no case for anyone to get wrong later — eliminating the situation rather than
 * ordering it. Asserted by the catalogue check rather than left as a comment.
 */
export function tlvCatalogueIsDisjoint(): boolean {
  const spec = new Set(SPEC_TAGS.map((d) => d.tag));
  return CONVENTION_TAGS.every((d) => !spec.has(d.tag));
}

/**
 * Whether a definition can be stored, or the sentence saying why not.
 *
 * <p>Mirrors the database CHECK rather than relying on it: the constraint's message would name a
 * regular expression, and the reason a comma is refused is worth saying in words. `,` and `=` cannot
 * appear because the settings this name is written into are comma-joined with `=` between a name and
 * its value, and nothing is escaped anywhere in the format.
 *
 * <p>Note what is <strong>not</strong> checked: whether the tag is one anybody has heard of. Every
 * tag from 0x0000 to 0xFFFF is legal, and naming one nobody has named is the entire point.
 */
export function validateTlvDefinition(input: { tag: unknown; name: unknown }): string | null {
  const tag = Number(input.tag);
  if (!Number.isInteger(tag) || tag < 0 || tag > 0xffff) {
    return "A tag is a whole number from 0 to 65535 (0x0000 to 0xFFFF).";
  }
  if (typeof input.name !== "string" || input.name.trim() === "") {
    return "A name is required — it is what gets prefilled into a token.";
  }
  if (/[,=\s]/.test(input.name.trim())) {
    return "A name cannot contain a comma, an equals sign or a space: these settings are stored as "
      + "one comma-joined string with '=' between a name and its value, and nothing is escaped.";
  }
  return null;
}
