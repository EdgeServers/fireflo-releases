/**
 * Whether a sign-in link was actually accepted.
 *
 * <p>Pure, so the rule can be tested without a browser, a server or a session. It exists because
 * the check it replaces was wrong in the dangerous direction and nothing could catch that: the
 * logic lived inside a React effect, where it could only be exercised by clicking a real link in a
 * real browser with a real prior session.
 *
 * <h3>Why neither obvious signal works on its own</h3>
 *
 * <p><strong>The status does not say.</strong> next-auth answers a rejected token with a 302 to
 * {@code ?error=CredentialsSignin}, and {@code fetch} follows redirects, so the response is 200 and
 * {@code res.ok} is true whether the token was good or not.
 *
 * <p><strong>The session does not say either.</strong> A browser that is already signed in has one
 * regardless of what this token did. Reading it alone reports a <em>spent</em> link as a successful
 * sign-in — which is the case that matters, because a link is only re-followed by somebody who
 * already used it, or by somebody who should not have it at all.
 *
 * <p>So the error parameter decides, and the session is consulted only after the callback has said
 * the token was accepted.
 */
export type VerifyOutcome = "signed-in" | "rejected";

export interface VerifySession {
  user?: { accountId?: string | null } | null;
}

export function verifyOutcome(
  finalUrl: string,
  origin: string,
  session: VerifySession | null | undefined
): VerifyOutcome {
  if (authError(finalUrl, origin)) {
    return "rejected";
  }
  return session?.user?.accountId ? "signed-in" : "rejected";
}

/**
 * The error parameter on the URL the callback finally landed on, or null.
 *
 * <p>An unparseable URL is treated as carrying no error rather than as a failure: the session check
 * behind it is the conservative half, and inventing a rejection from a URL we could not read would
 * fail a sign-in that may well have worked.
 */
export function authError(finalUrl: string, origin: string): string | null {
  try {
    return new URL(finalUrl, origin).searchParams.get("error");
  } catch {
    return null;
  }
}
