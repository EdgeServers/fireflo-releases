/**
 * The `dlr.errcodes` grammar, as the gateway actually parses it.
 *
 * <h2>This is a second copy of a rule the gateway owns</h2>
 *
 * <p>The authority is {@code SmppClientWorker.configDlrsErrorCodeMapping} — it splits the value on
 * `,`, then each entry on `_`, requires two non-empty halves, and requires the right half to parse
 * as an integer. Everything here mirrors that and **nothing here is stricter**.
 *
 * <p>That direction matters more than it looks. A panel that refuses what the gateway accepts is a
 * worse bug than the typo this module exists to catch: the operator cannot save a configuration
 * that would have worked, and there is no way round it from the UI. Being *laxer* fails safely by
 * comparison — the gateway skips the entry and warns, which is what happens today.
 *
 * <p>If that parser changes, change this, and vice versa. Each rule below names its counterpart.
 *
 * <h2>Why the panel duplicates it at all</h2>
 *
 * <p>The gateway's handling is already graceful — a malformed entry is skipped, the others still
 * apply, and it logs. But its own comment records what that costs: "every receipt carried the wrong
 * error code and the only evidence was one WARN at startup, or none at all." The value of having
 * the rule here is not correctness, which the gateway already has. It is timing: the refusal
 * arrives while the operator is looking at the field rather than weeks later in a support ticket.
 */

export interface ErrorCodePair {
  /** What the carrier sends. Free text — a carrier's private numbering, which no catalogue holds. */
  carrier: string;
  /** What the customer receives. Numeric, because the gateway calls `Integer.parseInt` on it. */
  ours: string;
}

/**
 * Parse a stored value into pairs, keeping exactly what the gateway would keep.
 *
 * <p>Faithful to the parser's quirks rather than to what the grammar ought to be:
 *
 * <ul>
 *   <li>the ENTRY is trimmed, the two halves are not — so `630_ 16` has a right half of " 16",
 *       which `Integer.parseInt` rejects, so the gateway drops it and so does this;</li>
 *   <li>an empty entry between commas is skipped rather than being an error, so a trailing comma
 *       is harmless;</li>
 *   <li>a later entry for the same carrier code wins, because the gateway builds a HashMap and
 *       `put` overwrites.</li>
 * </ul>
 *
 * <p>Malformed entries are dropped here exactly as the gateway drops them. The editor shows what
 * survived, which is the honest thing: it is what the running gateway is using.
 */
export function parseErrorCodes(csv: string | null | undefined): ErrorCodePair[] {
  if (!csv || !csv.trim()) {
    return [];
  }
  const byCarrier = new Map<string, string>();
  for (const raw of csv.split(",")) {
    const entry = raw.trim();
    if (!entry) {
      continue;
    }
    const halves = entry.split("_");
    if (halves.length !== 2 || !halves[0] || !halves[1]) {
      continue;
    }
    if (!isGatewayInteger(halves[1])) {
      continue;
    }
    //last one wins, matching HashMap.put
    byCarrier.set(halves[0], halves[1]);
  }
  return [...byCarrier].map(([carrier, ours]) => ({ carrier, ours }));
}

/** Render pairs back into the stored form. Blank rows are dropped rather than written as `_`. */
export function formatErrorCodes(pairs: ErrorCodePair[]): string {
  return pairs
    .filter((p) => p.carrier.trim() && p.ours.trim())
    .map((p) => `${p.carrier.trim()}_${p.ours.trim()}`)
    .join(",");
}

/**
 * What is wrong with one row, or null.
 *
 * <p>The editor's own check, applied to fields a person is typing rather than to a stored string.
 * It is deliberately the same three refusals `configDlrsErrorCodeMapping` makes — a missing half,
 * an empty half, a non-numeric right half — and no fourth of its own invention.
 *
 * <p>A row that is entirely blank is not a problem: it is the empty row at the bottom of the table
 * waiting to be filled in, and `formatErrorCodes` drops it.
 */
export function errorCodeProblem(pair: ErrorCodePair): string | null {
  const carrier = pair.carrier.trim();
  const ours = pair.ours.trim();

  if (!carrier && !ours) {
    return null;
  }
  if (!carrier) {
    return "Enter the code the carrier sends.";
  }
  if (!ours) {
    return "Enter the code the customer should receive.";
  }
  //`_` and `,` are the grammar's own separators, so one inside a value would split the entry into
  //something the gateway reads as a different pair -- or as malformed and drops
  if (carrier.includes("_") || carrier.includes(",")) {
    return "A carrier code cannot contain an underscore or a comma.";
  }
  if (!isGatewayInteger(ours)) {
    return "The code the customer receives has to be a whole number.";
  }
  return null;
}

/** Every carrier code appearing more than once. A later row silently replaces an earlier one. */
export function duplicateCarrierCodes(pairs: ErrorCodePair[]): string[] {
  const seen = new Set<string>();
  const twice = new Set<string>();
  for (const pair of pairs) {
    const carrier = pair.carrier.trim();
    if (!carrier) {
      continue;
    }
    if (seen.has(carrier)) {
      twice.add(carrier);
    }
    seen.add(carrier);
  }
  return [...twice];
}

/**
 * What `Integer.parseInt` accepts, and only that.
 *
 * <p>Optional sign, digits, and inside the signed 32-bit range. Deliberately NOT "a sensible error
 * code": the gateway would accept `-1` and `9999`, so refusing them here would be the panel being
 * stricter than the thing it configures. Rejecting `16.0` and `016 ` is not strictness — those
 * genuinely throw `NumberFormatException` and the gateway genuinely drops them.
 */
function isGatewayInteger(value: string): boolean {
  if (!/^[+-]?\d+$/.test(value)) {
    return false;
  }
  const n = Number(value);
  return Number.isSafeInteger(n) && n >= -2147483648 && n <= 2147483647;
}
