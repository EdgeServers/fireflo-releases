/**
 * What happened to each optional parameter, from arrival to the wire.
 *
 * <p>A message's TLVs are a **union** of four sources — the request, the account's defaults, the
 * approved sender ID and the content template — with one winner per tag, not a merged value. Then
 * the vendor decides: its own defaults fill any gap, and its registered-tag list decides what it
 * will carry. The CDR records three points on that pipeline; this turns them into one row per tag
 * with a verdict, so nobody has to diff three JSON blobs by eye.
 *
 * <p>Database-free, so a client component can import it.
 */

export type TlvVerdict =
  /** Arrived and went out untouched. The uninteresting and most common case. */
  | "unchanged"
  /** Arrived with one value and left with another: an account, sender ID or template overwrote it. */
  | "replaced"
  /** Not sent by the customer; the gateway added it from a default, sender ID or template. */
  | "added"
  /** On the message and not on the wire: this vendor does not register the tag. */
  | "dropped"
  /** Not on the message; the vendor supplied it from its own `default.tlvs.submit`. */
  | "vendor-default"
  /** The vendor changed the value it was given. Unusual — worth looking at. */
  | "vendor-overrode";

export interface TlvProvenanceRow {
  /** Canonical `0x%04X`, as every column is keyed. */
  tag: string;
  received: string | null;
  resolved: string | null;
  sent: string | null;
  verdict: TlvVerdict;
}

export interface TlvProvenance {
  rows: TlvProvenanceRow[];
  /**
   * Whether the wire column can be reasoned about at all.
   *
   * <p>False when `tlvs_sent` is null: a message that never reached a vendor, a non-SMPP vendor, or
   * a record written before the column existed. Every verdict about the wire is withheld rather
   * than guessed, because "we did not record it" and "the vendor dropped it" look identical
   * otherwise and only one of them is a problem.
   */
  sentRecorded: boolean;
  /** True when any row needs attention — a drop, or a value the vendor changed. */
  hasFindings: boolean;
}

/**
 * Parses one of the three columns.
 *
 * @return null when there is nothing to read or it does not parse. A record that cannot be read is
 *     still evidence, so callers show the raw text rather than throwing — see the detail view.
 */
export function parseTlvColumn(raw: string | null | undefined): Record<string, string> | null {
  if (!raw) {
    return null;
  }
  try {
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      return null;
    }
    const out: Record<string, string> = {};
    for (const [tag, value] of Object.entries(parsed as Record<string, unknown>)) {
      out[tag] = String(value);
    }
    return out;
  } catch {
    return null;
  }
}

/**
 * One row per tag seen at any stage, with what happened to it.
 *
 * <p>Ordered by tag so two messages compare, and so the table does not reshuffle when a stage adds
 * one. Every tag from every stage appears: a tag the vendor supplied by itself is as interesting as
 * one it discarded, and a union of the three key sets is the only way to see both.
 */
export function tlvProvenance(
  receivedRaw: string | null | undefined,
  resolvedRaw: string | null | undefined,
  sentRaw: string | null | undefined
): TlvProvenance {
  const received = parseTlvColumn(receivedRaw);
  const resolved = parseTlvColumn(resolvedRaw);
  const sent = parseTlvColumn(sentRaw);
  const sentRecorded = sent !== null;

  const tags = [
    ...new Set([
      ...Object.keys(received ?? {}),
      ...Object.keys(resolved ?? {}),
      ...Object.keys(sent ?? {}),
    ]),
  ].sort();

  const rows = tags.map<TlvProvenanceRow>((tag) => {
    const a = received?.[tag] ?? null;
    const b = resolved?.[tag] ?? null;
    const c = sent?.[tag] ?? null;
    return { tag, received: a, resolved: b, sent: c, verdict: verdictFor(a, b, c, sentRecorded) };
  });

  return {
    rows,
    sentRecorded,
    hasFindings: rows.some((r) => r.verdict === "dropped" || r.verdict === "vendor-overrode"),
  };
}

/**
 * The verdict for one tag.
 *
 * <p>Ordered so the wire is judged first: a tag that was dropped is the finding, whatever happened
 * to it earlier. Only then does the ingress comparison matter.
 */
function verdictFor(
  received: string | null,
  resolved: string | null,
  sent: string | null,
  sentRecorded: boolean
): TlvVerdict {
  if (sentRecorded) {
    if (resolved !== null && sent === null) {
      return "dropped";
    }
    if (resolved === null && sent !== null) {
      return "vendor-default";
    }
    //the vendor's own default only applies where the message had no value, so a changed value here
    //is not the ordinary path and is worth surfacing rather than folding into "unchanged"
    if (resolved !== null && sent !== null && resolved !== sent) {
      return "vendor-overrode";
    }
  }
  if (received === null && resolved !== null) {
    return "added";
  }
  if (received !== null && resolved !== null && received !== resolved) {
    return "replaced";
  }
  return "unchanged";
}

/** What to tell the operator about one row, in their terms. */
export function verdictSentence(row: TlvProvenanceRow, vendor: string | null): string {
  switch (row.verdict) {
    case "dropped":
      return `${vendor ?? "This vendor"} does not list this tag in registered.tlvs.submit, so it `
        + "was not sent.";
    case "vendor-default":
      return `Supplied by ${vendor ?? "the vendor"}'s own default; the message carried no value.`;
    case "vendor-overrode":
      return `${vendor ?? "The vendor"} sent a different value from the one the message carried.`;
    case "replaced":
      return "An account default, approved sender ID or content template replaced what was sent.";
    case "added":
      return "Not sent by the customer; added by an account default, sender ID or template.";
    default:
      return "Arrived and went out unchanged.";
  }
}
