import type { ConditionInput, RateRuleInput, ScopeInput } from "@/lib/rate-types";

/**
 * An unknown request body into a {@link ScopeInput}, or the reason it is not one.
 *
 * <p>Structural only — `validateScope` decides whether the rules make sense. The one rule enforced
 * here rather than there is that **an amount must arrive as a string**: a JSON number is an IEEE
 * double, and accepting one would let 0.0035 arrive as something that is not 0.0035 before any
 * validator ever saw it.
 *
 * <p>Lives in `lib/` rather than beside the whole-scope route because there are now two endpoints
 * that accept rules — that one and the product-scoped one — and they must disagree about nothing.
 * A route importing another route would work and would drag a whole handler module along with it.
 */
export function parseScopeBody(scope: string, body: unknown): ScopeInput | string {
  if (!body || typeof body !== "object") {
    return "Expected an object.";
  }
  const raw = body as Record<string, unknown>;
  if (!Array.isArray(raw.rules)) {
    return "Expected { rules: [...] }.";
  }

  const rules: RateRuleInput[] = [];
  for (let i = 0; i < raw.rules.length; i++) {
    const entry = raw.rules[i];
    if (!entry || typeof entry !== "object") {
      return `Rule ${i + 1} is not an object.`;
    }
    const r = entry as Record<string, unknown>;

    if (typeof r.amount !== "string") {
      return `Rule ${i + 1}'s amount must be sent as a string. A JSON number is a floating point `
        + "value and this is money — 0.0035 would not survive the trip intact.";
    }
    if (r.id != null && typeof r.id !== "number") {
      return `Rule ${i + 1} has an id that is not a number.`;
    }

    const conditions = parseConditions(r.conditions, i + 1);
    if (typeof conditions === "string") {
      return conditions;
    }

    rules.push({
      id: typeof r.id === "number" ? r.id : null,
      amount: r.amount.trim(),
      product: typeof r.product === "string" && r.product.trim() ? r.product : null,
      currency: typeof r.currency === "string" && r.currency.trim() ? r.currency.trim() : null,
      label: typeof r.label === "string" && r.label.trim() ? r.label.trim() : null,
      enabled: r.enabled === undefined ? true : r.enabled === true,
      conditions,
      filters: Array.isArray(r.filters) ? r.filters.filter((f): f is string => typeof f === "string") : [],
    });
  }

  return {
    scope,
    scopeConfirmed: raw.scopeConfirmed === true,
    //the caller's word for it, and it only ever makes a save refuse MORE. A client that omits it or
    //lies gets what these routes did before: an empty rule list on a scope that does not exist
    //stores nothing and answers 200. Deriving it would cost a query to tell a caller what it knew
    isNew: raw.isNew === true,
    rules,
  };
}

function parseConditions(value: unknown, n: number): ConditionInput[] | string {
  if (value === undefined) {
    return [];
  }
  if (!Array.isArray(value)) {
    return `Rule ${n}'s conditions must be an array.`;
  }
  const out: ConditionInput[] = [];
  for (const entry of value) {
    if (!entry || typeof entry !== "object") {
      return `A condition on rule ${n} is not an object.`;
    }
    const c = entry as Record<string, unknown>;
    if (typeof c.field !== "string" || typeof c.operator !== "string") {
      return `A condition on rule ${n} needs a field and an operator.`;
    }
    //the '!' never belongs in the operator column -- negation is its own boolean, which is the whole
    //point of having normalised it away from the file grammar
    if (c.operator.startsWith("!")) {
      return `A condition on rule ${n} has '!' in its operator. Send negate: true instead.`;
    }
    out.push({
      field: c.field,
      operator: c.operator,
      value: typeof c.value === "string" ? c.value : "",
      negate: c.negate === true,
    });
  }
  return out;
}
