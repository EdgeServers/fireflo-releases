import type { HealthWorker } from "@/lib/health-types";
import { trafficKey, type Worker } from "@/lib/worker-types";

/**
 * The ports a client can connect to on the listeners running now, from their settings: plain, and
 * TLS or PROXY where on. Running means enabled and present in the gateway's live health snapshot.
 */
export function listenerPorts(workers: Worker[], live: Map<string, HealthWorker>): { port: number; label: string }[] {
  const out = new Map<number, string>();
  for (const w of workers) {
    if (!w.enabled || !live.has(trafficKey(w))) {
      continue;
    }
    const get = (k: string) => w.properties.find((p) => p.key === k)?.value ?? "";
    const add = (raw: string, what: string) => {
      const n = Number(raw);
      if (Number.isInteger(n) && n > 0 && !out.has(n)) {
        out.set(n, `${w.name}${what}`);
      }
    };
    add(get("srv.port"), "");
    if (get("srv.tls.enabled") === "true") {
      add(get("srv.tls.port"), " (TLS)");
    }
    if (get("srv.proxy.enabled") === "true") {
      add(get("srv.proxy.port"), " (PROXY)");
    }
  }
  return [...out.entries()].map(([port, label]) => ({ port, label }));
}
