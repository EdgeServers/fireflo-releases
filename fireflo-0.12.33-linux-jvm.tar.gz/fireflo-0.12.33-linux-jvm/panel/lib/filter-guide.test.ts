import { test } from "node:test";
import assert from "node:assert/strict";
import {
  blankGuided,
  containsOf,
  describeCondition,
  describeConditions,
  duplicateMap,
  duplicatesOf,
  filterTopics,
  fromConditions,
  nameClash,
  prefixPattern,
  prefixesOf,
  prefixListOf,
  sameConditions,
  suggestName,
  toConditions,
} from "./filter-guide.ts";
import type { ConditionInput } from "./rate-types.ts";

const c = (field: string, operator: string, value: string, negate = false): ConditionInput => ({ field, operator, value, negate });

test("a filter sits under every topic its conditions touch", () => {
  assert.deepEqual(filterTopics([c("to", "startsWith", "+91"), c("product", "equals", "txn")]), ["destination", "product"]);
  assert.deepEqual(filterTopics([c("field3", "equals", "x")]), ["other"]);
  assert.deepEqual(filterTopics([]), ["other"]);
});

test("conditions read as one sentence", () => {
  assert.equal(
    describeConditions([c("to", "startsWith", "+91"), c("product", "equals", "transactional")]),
    "Destination starts with +91 and product is transactional."
  );
  assert.equal(describeConditions([c("from", "equals", "ACME", true)]), "Sender ID is not ACME.");
  assert.equal(describeConditions([c("to", "matches", prefixPattern(["+91", "+92"]))]), "Destination starts with +91 or +92.");
  assert.equal(describeConditions([c("body", "matches", ".*OTP.*")]), "Message text contains “OTP”.");
  assert.equal(describeConditions([c("cnetwork", "==i", "405")]), "Destination network is 405.");
  assert.equal(describeConditions([]), "");
});

test("duplicates ignore order, repeats, case where the operator does, and spacing", () => {
  const a = [c("to", "startsWith", "+91"), c("product", "equals", "txn")];
  assert.ok(sameConditions(a, [c("product", "equals", "txn "), c("to", "startsWith", "+91")]));
  assert.ok(sameConditions([c("from", "equalsIgnoreCase", "ACME")], [c("from", "equalsIgnoreCase", "acme")]));
  assert.ok(!sameConditions([c("from", "equals", "ACME")], [c("from", "equals", "acme")]));
  assert.ok(!sameConditions([c("to", "startsWith", "+91")], [c("to", "startsWith", "+91", true)]));

  const filters = [
    { name: "in_txn", conditions: a },
    { name: "india", conditions: [c("to", "startsWith", "+91")] },
    { name: "in_in", conditions: [c("to", "startsWith", "+91")] },
    { name: "empty1", conditions: [] },
    { name: "empty2", conditions: [] },
  ];
  assert.deepEqual(duplicatesOf([c("to", "startsWith", "+91")], filters).map((f) => f.name), ["india", "in_in"]);
  //editing a filter never reports itself
  assert.deepEqual(duplicatesOf([c("to", "startsWith", "+91")], filters, "india").map((f) => f.name), ["in_in"]);
  //empty filters are unfinished, not twins
  assert.deepEqual(duplicatesOf([], filters), []);
  const map = duplicateMap(filters);
  assert.deepEqual(map.get("india"), ["in_in"]);
  assert.equal(map.has("empty1"), false);
  assert.equal(map.has("in_txn"), false);
});

test("a name that differs only in case is a clash", () => {
  assert.equal(nameClash("IN_TXN", [{ name: "in_txn" }]), "in_txn");
  assert.equal(nameClash("other", [{ name: "in_txn" }]), null);
});

test("guided fields write the conditions the gateway reads, and read them back", () => {
  const fields = [
    { ...blankGuided("destination"), mode: "prefixes" as const, values: ["+91", "+92"] },
    { ...blankGuided("product"), values: ["transactional"] },
    { ...blankGuided("sender"), mode: "exact" as const, values: ["ACME"], except: true },
    { ...blankGuided("text"), values: ["OTP (code)"] },
    { ...blankGuided("network"), values: ["405"] },
    { ...blankGuided("account"), values: [""] },
  ];
  const conditions = toConditions(fields);
  assert.deepEqual(conditions, [
    c("to", "startsWithAny", "+91,+92"),
    c("product", "equals", "transactional"),
    c("from", "equals", "ACME", true),
    c("body", "matches", ".*OTP \\(code\\).*"),
    c("cnetwork", "==", "405"),
  ]);
  const back = fromConditions(conditions)!;
  assert.deepEqual(toConditions(back), conditions);
  //a literal list, not a regex. The ^(a|b) pattern this used to write passed a JavaScript
  //RegExp.test -- a search -- while the gateway's matches is a whole-string match, so it never
  //matched a real number there
  assert.equal(conditions[0].value.split(",").length, 2);
  //one prefix is a plain startsWith
  assert.deepEqual(toConditions([{ ...blankGuided("destination"), values: ["+61"] }]), [c("to", "startsWith", "+61")]);
});

test("a prefix list saved the old way still reads back, and reads as the list it was", () => {
  const old = c("to", "matches", "^(\\+91|91)");
  assert.deepEqual(prefixListOf(old), ["+91", "91"]);
  assert.equal(describeCondition(old), "destination starts with +91 or 91");
  assert.deepEqual(fromConditions([old])![0].values, ["+91", "91"]);
  assert.deepEqual(prefixListOf(c("to", "startsWithAny", "+91, 91")), ["+91", "91"]);
  assert.equal(describeCondition(c("to", "startsWithAny", "+91,91")), "destination starts with +91 or 91");
  assert.equal(describeCondition(c("to", "startsWithAny", "+91,91", true)), "destination does not start with +91 or 91");
});

test("what the guided form cannot express opens in the advanced editor", () => {
  assert.equal(fromConditions([c("field3", "equals", "x")]), null);
  assert.equal(fromConditions([c("to", "endsWith", "0")]), null);
  assert.equal(fromConditions([c("to", "matches", "^\\+9[12]")]), null);
  assert.equal(fromConditions([c("to", "startsWith", "+91"), c("to", "startsWith", "+92")]), null);
  assert.equal(prefixesOf("^(+91)"), null);
  assert.equal(containsOf(".*a.*b.*"), null);
});

test("a suggested name comes from the values and avoids taken ones", () => {
  assert.equal(suggestName([c("to", "startsWith", "+91"), c("product", "equals", "Transactional")]), "to_91_transactional");
  assert.equal(suggestName([c("to", "startsWith", "+91")], [{ name: "to_91" }]), "to_91_2");
  assert.equal(suggestName([]), "filter");
});
