import type { Health } from "./health-types";

/**
 * What the gateway's API can do, read from `/ops/health`'s `api` map (gateway 0.13+).
 *
 * <p>A capability is a fact about the build, published by name and never withdrawn while the
 * feature exists. Screens ask for a name rather than reasoning from the version string, because a
 * version says when something shipped and a name says whether it is there -- which is the question.
 * A gateway older than the map answers no to everything, and that is the right answer: none of the
 * named features existed.
 */

/** Whether this gateway's API has the named capability. False on an older gateway or no health. */
export function hasCapability(health: Health | null | undefined, name: string): boolean {
  return health?.api?.[name] === true;
}

/** The capabilities this gateway declares, sorted, so two gateways' lists can be read side by side. */
export function capabilityNames(health: Health | null | undefined): string[] {
  return Object.entries(health?.api ?? {})
    .filter(([, on]) => on === true)
    .map(([name]) => name)
    .sort();
}

/**
 * One sentence for a verify or status screen, or null when the gateway publishes no map at all --
 * which a caller shows as "not reported" rather than as an empty list, since those differ.
 */
export function apiLevelSentence(health: Health | null | undefined): string | null {
  if (health?.api == null) {
    return null;
  }
  const names = capabilityNames(health);
  return names.length
    ? `This gateway answers API level ${names.join(", ")}.`
    : "This gateway answers API level with no capabilities declared.";
}
