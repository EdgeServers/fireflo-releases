import type { RejectedRow } from "./rejected-types";
//with the extension, because `node --test` runs this module directly and does not read tsconfig
//paths or resolve extensionless specifiers. The type-only import above is erased and needs neither
import { csv } from "./csv.ts";
import { reasonLabel, refusedAfterAccepting, vendorStatusName } from "./rejected-types.ts";

/**
 * What a refusals CSV contains, and how each row becomes a line.
 *
 * <p>The sibling of `cdr-export.ts`, database-free for the same reason: the shape of the file is
 * worth asserting directly rather than by reading a route and believing it. The query is wired in
 * the route.
 *
 * <p><strong>Every column, always, whatever the chooser is showing.</strong> Letting the file follow
 * the on-screen columns is how two people export the same filters and get different files — and the
 * one who gets the shorter file has no way to know.
 */

/**
 * Column order, fixed and append-only.
 *
 * <p>Whoever imports this into a spreadsheet builds formulas against column letters, so a column
 * added later goes on the end. The three derived columns are here deliberately: this file is read by
 * people with no panel open, and `templateNotMatched` beside "Content not approved" is the
 * difference between a report somebody can act on and one they have to come back and ask about.
 *
 * <p>The two free-text fields are last, matching the call-record file's rule about unbounded values.
 */
export const HEADERS = [
  "rejected_at",
  "reason",
  "reason_label",
  "refused_after_accepting",
  "account_id",
  "system_id",
  "product",
  "ingress",
  "in_gateway",
  "source_addr",
  "dest_addr",
  "gateway_msg_id",
  "vendor_status",
  "vendor_status_name",
  "dcs",
  "parts",
  "id",
  "detail",
  "body_excerpt",
] as const;

export function toCsvLine(row: RejectedRow): string {
  return (
    [
      row.rejectedAt,
      row.reason,
      reasonLabel(row.reason),
      //written as true/false rather than left blank when false: the question this column answers is
      //"was this charged and refunded", and an empty cell reads as unknown
      refusedAfterAccepting(row.reason),
      row.accountId,
      row.systemId,
      row.product,
      row.ingress,
      row.inGateway,
      row.sourceAddr,
      row.destAddr,
      //the gateway stores '' rather than NULL for a refusal that never reached a message. Both are
      //written as empty, because in a file there is no difference worth drawing
      row.gatewayMsgId || null,
      row.vendorStatus,
      row.vendorStatus == null ? null : vendorStatusName(row.vendorStatus),
      //raw integers, INCLUDING zero, unlike the table -- the file is a calculation surface, and what
      //a zero means is documented in the panel rather than encoded by blanking a cell
      row.dcs,
      row.parts,
      row.id,
      row.detail,
      row.bodyExcerpt,
    ]
      .map(csv)
      .join(",") + "\n"
  );
}

/**
 * Names the job, the manifest and the file. Here rather than in the route because two routes need
 * it — the one that queues an export and the one that hands it back — and they must not disagree.
 */
export const REJECTED_EXPORT_KIND = "rejected";
