/**
 * Refused messages, with no database import anywhere.
 *
 * <p>Split from `rejected.ts` for the usual reason: a client component that reaches a module which
 * transitively imports `pg` does not break that page, it breaks every page.
 */

export interface RejectedRow {
  id: string;
  rejectedAt: string;
  reason: string;
  detail: string | null;
  accountId: string | null;
  systemId: string | null;
  product: string | null;
  ingress: string | null;
  inGateway: string | null;
  sourceAddr: string | null;
  destAddr: string | null;
  bodyExcerpt: string | null;
  /**
   * The data coding the message declared.
   *
   * <p>Recorded since the table was created and selected by nothing until now, so it existed only in
   * Postgres. `0` is GSM 7-bit and is a real, common value — not a blank.
   */
  dcs: number | null;
  /**
   * How many segments the message was going to be.
   *
   * <p>`0` rather than null when the refusal happened before anything counted them — the gateway
   * writes a Java primitive, so there is no NULL to write. No real message has zero parts, which is
   * what lets the panel read `0` as "never computed" and say so.
   */
  parts: number | null;
  /**
   * The message this refusal is about, when there is one.
   *
   * <p>Null for a refusal at the door — nothing was submitted, so there is no message to point at,
   * and that is most rows. Set for the refusals that happen after acceptance, where the message has
   * a call record and this is what joins the two.
   */
  gatewayMsgId: string | null;
  /**
   * The SMPP command_status the vendor answered with, when a vendor was asked.
   *
   * <p>Null for every refusal at the door — an unapproved sender, an empty balance, a rate limit —
   * because those happen before a vendor sees the message. Set only for `vendorRejected`.
   */
  vendorStatus: number | null;
  /**
   * What became of the delivery receipt this refusal owed the customer.
   *
   * `n/a` for a refusal at the door -- the client was told in the response it was already waiting
   * on. Null on every row written before the gateway recorded this, which is honest rather than a
   * gap: back-filling a guess about whether somebody was told would be worse than an empty cell.
   */
  receipt: string | null;
}

export interface RejectedSummary {
  reason: string;
  count: number;
}

//RejectedPage lives in `rejected-request.ts`: it describes a response rather than the domain, it
//carries a cursor, and this module is imported by the diagnosis engine, which has no business
//knowing how a page of refusals is fetched

/**
 * Plain-language for each reason the gateway records.
 *
 * <p>The stored value is the same token the gateway logs (`reason=headerNotApproved`), which is the
 * right thing to store and the wrong thing to show an operator at 3am. An unknown reason falls back
 * to the raw token rather than to "Unknown", because a token you can grep for beats a word you
 * cannot.
 */
export const REJECT_REASONS: Record<string, { label: string; hint: string }> = {
  headerNotApproved: {
    label: "Sender ID not approved",
    hint: "The sender ID is not on this account's approved list for the product it sent under.",
  },
  templateNotMatched: {
    label: "Content not approved",
    hint: "The message body matched none of the account's approved templates. A single changed "
      + "word is enough — the comparison is exact outside the {#var#} placeholders.",
  },
  insufficientCredit: {
    label: "Out of credit",
    hint: "Prepaid credit would not cover the message. Note the first send after a gateway "
      + "restart can report this while credit is being reserved, even on a funded account.",
  },
  missingMandatoryTlv: {
    label: "Required parameter missing",
    hint: "A TLV the listener or the HTTP ingress requires was absent, and nothing — neither the "
      + "caller, an approved template, nor a credential default — supplied it.",
  },
  rateLimited: {
    label: "Rate limit exceeded",
    hint: "The account went over its configured messages per second.",
  },
  submitFailed: {
    label: "Could not be queued",
    hint: "Accepted by the checks but the gateway could not hand it on — usually the broker.",
  },
  productNotSold: {
    label: "Product not sold",
    hint: "The login named a product with no enabled row in the catalogue, or named none at all "
      + "while the ingress required one.",
  },
  unrated: {
    label: "No price configured",
    hint: "No sell-side rate rule matched this account and product, and the gateway is set to "
      + "refuse rather than send unbilled. Add a rate, or unset smsg.rating.unrated.refuse.",
  },
  //the two below are refusals AFTER acceptance -- the message was charged, queued and then never
  //sent. They are the only reasons here that carry a message id, because they are the only ones
  //where a message existed to carry one
  maxAttempts: {
    label: "Never routed",
    hint: "The gateway accepted it, then found no enabled rule to send it under and gave up after "
      + "its attempt limit. Any charge was refunded. Check the route table for the account's "
      + "product — a message with no product matches only product:isNull: rules.",
  },
  vendorRejected: {
    label: "Vendor refused it",
    hint: "The gateway accepted, charged and sent it, and the carrier refused the submit outright. "
      + "The code beside it is the carrier's own reason. Any charge was refunded. The 192–196 "
      + "codes are always about TLVs — on an India DLT lane, usually a missing or unstamped "
      + "entity or template id.",
  },
  //two tokens the gateway has always emitted with nothing here to name them, so they rendered as
  //raw camelCase on the page
  productNotAllowed: {
    label: "Product not allowed for this login",
    hint: "The request named a product this login may not send on. Either omit the field to use "
      + "the product the login carries, or add it under 'Products it may name on a send'.",
  },
  queueFull: {
    label: "Queue full",
    hint: "The router queue was at its capacity and the gateway refused rather than growing the "
      + "heap. Raise smsg.queue.capacity, or find why the queue is not draining.",
  },
  filtered: {
    label: "Dropped by a filter",
    hint: "A routing filter decided this message should not go. The detail names which one. Any "
      + "charge was refunded.",
  },
};

/**
 * Whether this refusal happened after the message was accepted.
 *
 * <p>Worth distinguishing on the page: a refusal at the door means the customer was told no and
 * nothing was charged, while these two mean the customer was told yes, was charged, was refunded,
 * and is waiting for a message that will never arrive. Only the second kind produces a support
 * ticket that starts with a message id.
 */
export function refusedAfterAccepting(reason: string): boolean {
  return (REFUSED_AFTER_ACCEPTING as readonly string[]).includes(reason);
}

/**
 * The reasons that happen *after* the customer was told yes.
 *
 * <p>A list rather than three literals inside the predicate above, because the filter bar binds it
 * straight into SQL (`reason = ANY($n)`). Two copies of this set would disagree the first time a
 * fourth reason joined it, and the disagreement would read as the filter being broken rather than
 * as the list being stale.
 */
export const REFUSED_AFTER_ACCEPTING = ["maxAttempts", "filtered", "vendorRejected"] as const;

/**
 * What a vendor's SMPP `command_status` means.
 *
 * <p>A deliberate mirror of the gateway's own `SmppStatus` table. The duplication is safe in one
 * direction only, and that is why it is acceptable: the gateway also writes the sentence into the
 * row's `detail`, so a code this map has not caught up with still shows its meaning from the row
 * itself. This only ever adds a short mnemonic beside the number.
 *
 * <p>Unknown codes fall back to the raw number, matching `reasonLabel` and `labelFor` rather than
 * `settingLabel` — vendors do use codes outside the spec, and inventing a name for one would send
 * an operator hunting for a spec entry that does not exist.
 */
export const VENDOR_STATUS: Record<number, string> = {
  1: "ESME_RINVMSGLEN",
  8: "ESME_RSYSERR",
  10: "ESME_RINVSRCADR",
  11: "ESME_RINVDSTADR",
  14: "ESME_RINVPASWD",
  20: "ESME_RMSGQFUL",
  67: "ESME_RINVESMCLASS",
  69: "ESME_RSUBMITFAIL",
  88: "ESME_RTHROTTLED",
  100: "ESME_RX_T_APPN",
  101: "ESME_RX_P_APPN",
  192: "ESME_RINVOPTPARSTREAM",
  193: "ESME_ROPTPARNOTALLWD",
  194: "ESME_RINVPARLEN",
  195: "ESME_RMISSINGOPTPARAM",
  196: "ESME_RINVOPTPARAMVAL",
  254: "ESME_RDELIVERYFAILURE",
  255: "ESME_RUNKNOWNERR",
};

/** The mnemonic for a vendor status, or null when it is not one the spec names. */
export function vendorStatusName(status: number | null | undefined): string | null {
  return status == null ? null : VENDOR_STATUS[status] ?? null;
}

export function reasonLabel(reason: string): string {
  return REJECT_REASONS[reason]?.label ?? reason;
}

export function reasonHint(reason: string): string | null {
  return REJECT_REASONS[reason]?.hint ?? null;
}

/**
 * What the gateway recorded about the receipt, in words rather than a token.
 *
 * <p>Deliberately not a yes/no. "The customer was not told" has several causes and they need
 * different responses: one is our bug, two are their configuration, and one is them getting exactly
 * what they asked for. Collapsing them into a red cross would send an operator chasing all four.
 *
 * <p>Null means the row predates the gateway recording this. Said plainly rather than shown as "no",
 * because a guess about whether somebody was told is worse than admitting the row cannot say.
 */
export function receiptLabel(receipt: string | null | undefined): string | null {
  if (receipt == null || receipt === "") return null;
  switch (receipt) {
    case "n/a":
      return "Told at submit";
    case "sent-smpp":
      return "Receipt sent";
    case "sent-webhook":
      return "Webhook sent";
    case "not-requested":
      return "Did not ask";
    case "no-destination":
      return "No dlr-url set";
    case "already-closed":
      return "Told earlier";
    case "unavailable":
      return "Could not send";
    default:
      return receipt;
  }
}
