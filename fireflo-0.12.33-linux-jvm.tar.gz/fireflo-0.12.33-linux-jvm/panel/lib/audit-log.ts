import { configQuery } from "@/lib/config-db";

/**
 * Reading the two access logs back, for the screens that show them.
 *
 * <p>Server-only: importing this pulls `pg`. Writing is elsewhere -- `lib/access-log.ts` for the
 * operator table and `lib/customer-access-log.ts` for the customer one -- and stays fire-and-forget.
 * This module is the first reader either table has had: until it existed the operator log was a file
 * no screen opened, and the customer log was written and never shown to the operator.
 *
 * <h2>Cursor paging on (occurred_at, id)</h2>
 *
 * <p>Both tables are append-only and indexed on time, so "the page before this row" is one indexed
 * range scan however many rows there are. OFFSET paging on a log that only grows would get slower
 * every day it is used.
 */

export interface AuditFilter {
  /** Only rows about this user. */
  userId?: number | null;
  /** Only rows about this account (customer log). */
  accountId?: string | null;
  /** Only this event. */
  event?: string | null;
  /** Substring match on the actor or email. */
  actor?: string | null;
  /** Only refused sign-ins and other failures. */
  failuresOnly?: boolean;
  from?: Date | null;
  to?: Date | null;
  /** The last row of the previous page. */
  before?: { occurredAt: string; id: number } | null;
  limit?: number;
}

export interface OperatorAuditRow {
  id: number;
  occurredAt: string;
  event: string;
  userId: number | null;
  actor: string | null;
  ip: string | null;
  userAgent: string | null;
  detail: Record<string, unknown> | null;
}

export interface CustomerAuditRow {
  id: number;
  occurredAt: string;
  event: string;
  userId: number | null;
  accountId: string | null;
  email: string | null;
  ip: string | null;
  userAgent: string | null;
  detail: Record<string, unknown> | null;
}

export interface AuditPage<T> {
  rows: T[];
  /** Pass back as `before` for the next page; null when this was the last. */
  next: { occurredAt: string; id: number } | null;
}

const MAX_LIMIT = 500;
const OPERATOR_FAILURES = ["signin_failed", "link_denied", "link_rejected"];
const CUSTOMER_FAILURES = ["link_denied", "link_rejected", "password_signin_failed"];

export async function listOperatorEvents(filter: AuditFilter = {}): Promise<AuditPage<OperatorAuditRow>> {
  const limit = clampLimit(filter.limit);
  const where: string[] = [];
  const params: unknown[] = [];
  const add = (sql: string, value: unknown) => {
    params.push(value);
    where.push(sql.replace("?", `$${params.length}`));
  };
  if (filter.userId) add("user_id = ?", filter.userId);
  if (filter.event) add("event = ?", filter.event);
  if (filter.actor) add("actor ILIKE ?", `%${filter.actor}%`);
  if (filter.failuresOnly) add("event = ANY(?::text[])", OPERATOR_FAILURES);
  if (filter.from) add("occurred_at >= ?", filter.from);
  if (filter.to) add("occurred_at < ?", filter.to);
  if (filter.before) {
    params.push(filter.before.occurredAt, filter.before.id);
    where.push(`(occurred_at, id) < ($${params.length - 1}, $${params.length})`);
  }
  params.push(limit + 1);
  const rows = await configQuery<{
    id: string; occurred_at: Date; event: string; user_id: string | null; actor: string | null;
    ip: string | null; user_agent: string | null; detail: Record<string, unknown> | null;
  }>(
    `SELECT id, occurred_at, event, user_id, actor, ip, user_agent, detail FROM app_operator_access_log
     ${where.length ? `WHERE ${where.join(" AND ")}` : ""}
     ORDER BY occurred_at DESC, id DESC LIMIT $${params.length}`,
    params
  );
  const page = rows.slice(0, limit).map((r) => ({
    id: Number(r.id),
    occurredAt: new Date(r.occurred_at).toISOString(),
    event: r.event,
    userId: r.user_id === null ? null : Number(r.user_id),
    actor: r.actor,
    ip: r.ip,
    userAgent: r.user_agent,
    detail: r.detail,
  }));
  return { rows: page, next: nextCursor(page, rows.length > limit) };
}

export async function listCustomerEvents(filter: AuditFilter = {}): Promise<AuditPage<CustomerAuditRow>> {
  const limit = clampLimit(filter.limit);
  const where: string[] = [];
  const params: unknown[] = [];
  const add = (sql: string, value: unknown) => {
    params.push(value);
    where.push(sql.replace("?", `$${params.length}`));
  };
  if (filter.userId) add("user_id = ?", filter.userId);
  if (filter.accountId) add("account_id = ?", filter.accountId);
  if (filter.event) add("event = ?", filter.event);
  if (filter.actor) add("email ILIKE ?", `%${filter.actor}%`);
  if (filter.failuresOnly) add("event = ANY(?::text[])", CUSTOMER_FAILURES);
  if (filter.from) add("occurred_at >= ?", filter.from);
  if (filter.to) add("occurred_at < ?", filter.to);
  if (filter.before) {
    params.push(filter.before.occurredAt, filter.before.id);
    where.push(`(occurred_at, id) < ($${params.length - 1}, $${params.length})`);
  }
  params.push(limit + 1);
  const rows = await configQuery<{
    id: string; occurred_at: Date; event: string; user_id: string | null; account_id: string | null;
    email: string | null; ip: string | null; user_agent: string | null; detail: Record<string, unknown> | null;
  }>(
    `SELECT id, occurred_at, event, user_id, account_id, email, ip, user_agent, detail
       FROM app_customer_access_log
     ${where.length ? `WHERE ${where.join(" AND ")}` : ""}
     ORDER BY occurred_at DESC, id DESC LIMIT $${params.length}`,
    params
  );
  const page = rows.slice(0, limit).map((r) => ({
    id: Number(r.id),
    occurredAt: new Date(r.occurred_at).toISOString(),
    event: r.event,
    userId: r.user_id === null ? null : Number(r.user_id),
    accountId: r.account_id,
    email: r.email,
    ip: r.ip,
    userAgent: r.user_agent,
    detail: r.detail,
  }));
  return { rows: page, next: nextCursor(page, rows.length > limit) };
}

/** Sign-in outcomes across both doors for the Security page: counts per day, per surface. */
export interface SignInSummary {
  surface: "panel" | "portal";
  day: string;
  succeeded: number;
  failed: number;
}

export async function signInSummary(days: number): Promise<SignInSummary[]> {
  const rows = await configQuery<{ surface: "panel" | "portal"; day: Date; succeeded: string; failed: string }>(
    `SELECT 'panel' AS surface, date_trunc('day', occurred_at) AS day,
            count(*) FILTER (WHERE event IN ('signin', 'link_redeemed')) AS succeeded,
            count(*) FILTER (WHERE event IN ('signin_failed', 'link_rejected', 'link_denied')) AS failed
       FROM app_operator_access_log
      WHERE occurred_at > now() - ($1 || ' days')::interval
        AND event IN ('signin', 'link_redeemed', 'signin_failed', 'link_rejected', 'link_denied')
      GROUP BY 1, 2
     UNION ALL
     SELECT 'portal', date_trunc('day', occurred_at),
            count(*) FILTER (WHERE event IN ('link_redeemed', 'password_signin')),
            count(*) FILTER (WHERE event IN ('link_rejected', 'link_denied', 'password_signin_failed'))
       FROM app_customer_access_log
      WHERE occurred_at > now() - ($1 || ' days')::interval
        AND event IN ('link_redeemed', 'password_signin', 'link_rejected', 'link_denied', 'password_signin_failed')
      GROUP BY 1, 2
     ORDER BY 2 DESC, 1`,
    [String(days)]
  );
  return rows.map((r) => ({
    surface: r.surface,
    day: new Date(r.day).toISOString().slice(0, 10),
    succeeded: Number(r.succeeded),
    failed: Number(r.failed),
  }));
}

function clampLimit(limit: number | undefined): number {
  if (!limit || !Number.isFinite(limit)) return 100;
  return Math.max(1, Math.min(MAX_LIMIT, Math.floor(limit)));
}

function nextCursor<T extends { occurredAt: string; id: number }>(page: T[], more: boolean) {
  if (!more || !page.length) return null;
  const last = page[page.length - 1];
  return { occurredAt: last.occurredAt, id: last.id };
}
