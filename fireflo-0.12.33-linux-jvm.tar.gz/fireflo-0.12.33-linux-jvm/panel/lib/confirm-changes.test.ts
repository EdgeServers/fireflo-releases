import { strict as assert } from "node:assert";
import { test } from "node:test";

import { DELETE_WORD, stagedSummary, typedMatches, workerChanges } from "./confirm-changes.ts";

test("only the exact word confirms a delete", () => {
  assert.equal(typedMatches("DELETE"), true);
  for (const nearly of ["delete", "Delete", "DELET", "DELETE ", " DELETE", "DELETED", ""]) {
    assert.equal(typedMatches(nearly), false, JSON.stringify(nearly));
  }
  assert.equal(DELETE_WORD, "DELETE");
});

test("a worker save lists only what changed, never a secret's value", () => {
  const lines = workerChanges(
    { host: "10.0.0.1", port: "2775", password: "old", tps: "100" },
    { host: "10.0.0.2", port: "2775", password: "new", "dest.addr.convert": "true" },
    new Set(["password"])
  );
  assert.deepEqual(lines, [
    { label: "dest.addr.convert", from: "(default)", to: "true" },
    { label: "host", from: "10.0.0.1", to: "10.0.0.2" },
    { label: "password", to: "changed" },
    { label: "tps", from: "100", to: "(default)" },
  ]);
  assert.deepEqual(workerChanges({ host: "a" }, { host: " a " }), [], "whitespace alone is not a change");
});

test("a staged table's changes are counted once each", () => {
  type R = { id: string; v: string };
  const before: R[] = [{ id: "a", v: "1" }, { id: "b", v: "1" }, { id: "c", v: "1" }, { id: "d", v: "1" }];
  const after: R[] = [{ id: "b", v: "2" }, { id: "a", v: "1" }, { id: "c", v: "1" }, { id: "e", v: "1" }];
  assert.equal(
    stagedSummary(before, after, (r) => r.id, (r) => r.v),
    "1 rule edited, 2 moved, 1 removed, 1 added"
  );
  assert.equal(stagedSummary(before, before, (r) => r.id, (r) => r.v), "");
  assert.equal(stagedSummary([], [{ id: "x", v: "1" }], (r) => r.id, (r) => r.v, ["group", "groups"]), "1 group added");
});
