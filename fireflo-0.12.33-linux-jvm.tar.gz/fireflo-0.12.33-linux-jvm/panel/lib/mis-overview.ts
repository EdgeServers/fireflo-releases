import { isMessageRow, type GrainOptions } from "./cdr-grain";
import { getBalance } from "@/lib/balance";
import { query } from "@/lib/metrics-db";
import { billingDays } from "@/lib/metrics-queries";
import { hasBodyColumn, hasUsageHourly, hasVendorAttempt, hourlyWatermark } from "@/lib/metrics-schema";
import { createSnapshotCache, overviewKey, type SnapshotCache } from "@/lib/mis-overview-snapshot";
import { billingZone, platformCurrency } from "@/lib/platform-currency";
import { OUTCOME_LATERAL, usageHourlySql, usageWindowSql } from "@/lib/usage-summary-sql";

/**
 * What the portal's landing page shows a customer about their own traffic.
 *
 * <p>One module, three shapes, one range — a dashboard that fires four requests is four chances to
 * paint half a page, and four places for the range to disagree with itself.
 *
 * <p><strong>Every query here is bounded twice</strong>: by the range, and by the accounts the
 * session may see. The scope arrives from `scopeFor(session)` and is never taken from the request,
 * for the reason `CdrFilters.accountIn` documents — a boundary that a query string can widen is not
 * a boundary.
 *
 * <h2>Where the figures come from</h2>
 *
 * <p>The series, the tiles and the outcome counts used to be three scans of the call records over
 * the whole window -- seven to ninety days -- on every load. They are now <b>one read of the usage
 * summaries</b>, the same seam the operator's pages use (`usage-summary-sql.ts`): finished billing
 * days from `usage_daily`, today from `usage_hourly` where the gateway keeps it (V1.91.0) or from
 * the records where it does not. The aggregate is held per (scope, range) for a minute
 * (`mis-overview-snapshot.ts`), so a customer's three tabs are one build and the page says when
 * it was built.
 *
 * <p>Three things stay live on every request, because a minute would be a lie for them: the two
 * short lists (an index walk with `LIMIT 6`), and the balance, which must never lag a top-up.
 *
 * <p>What the summaries cannot say, and the page therefore no longer claims: a day summarised by
 * the gateway does not distinguish a message the platform refused (REJECTED, DROPPED) from one a
 * carrier failed to deliver, so the outcome donut shows <b>delivered, failed and awaiting receipt</b>
 * and "failed" covers both. The failures list beneath still names each message's own reason.
 *
 * <p>Server-only: importing this pulls `pg`.
 */

/** One day of traffic. `rate` is null on a day with nothing sent, rather than a misleading zero. */
export interface TrafficDay {
  day: string;
  sent: number;
  delivered: number;
  failed: number;
  pending: number;
  /** Delivered as a percentage of those that have an outcome. Null while nothing has resolved. */
  rate: number | null;
}

export interface OutcomeSlice {
  outcome: "delivered" | "failed" | "pending";
  messages: number;
}

export interface OverviewTiles {
  sent: number;
  delivered: number;
  /** Delivered over resolved, as a percentage. Null when nothing has resolved yet. */
  rate: number | null;
  /** Scaled by 10 000 like every amount in this schema. */
  spend: number;
  /** Live, not for the period — and null when credit is not enforced for this account. */
  balance: number | null;
  currency: string | null;
}

/**
 * A row in the latest-messages strip.
 *
 * <p>`body` is null on every row unless the gateway is recording content — see `smsg.cdr.body`,
 * which ships off. The strip renders without it; it is a nicety, not the point of the row.
 */
export interface RecentMessage {
  gatewayMsgId: string;
  submittedAt: string;
  destAddr: string | null;
  finalState: string | null;
  body: string | null;
}

/**
 * A message that did not arrive, and what is known about why.
 *
 * <p>A superset of {@link RecentMessage} rather than a variant of it: the two panels sit beside each
 * other and a reader comparing them should be reading the same columns in the same order.
 */
export interface FailedMessage extends RecentMessage {
  /** The raw SMPP receipt state, which `DLR_STATES` in `labels.ts` turns into a sentence. */
  dlrState: number | null;
  /** The vendor's own code. Free-form, vendor-specific, and shown verbatim because it must be. */
  errCode: string | null;
}

export interface Overview {
  tiles: OverviewTiles;
  traffic: TrafficDay[];
  outcomes: OutcomeSlice[];
  recent: RecentMessage[];
  /**
   * The most recent messages that did not arrive.
   *
   * <p>Empty is the good outcome here, and the surface says so — an empty list beside a full one
   * reads as broken unless the page states which it is.
   */
  failed: FailedMessage[];
  /** How many failed in the whole range, so the panel can say "6 of 214" rather than imply 6. */
  failedTotal: number;
  /** True while some of the range has no receipt yet, so the percentages are still moving. */
  settling: boolean;
  /** When the series, tiles and outcomes were built. The lists and the balance are live. */
  asOf: string;
  /** True when the last build failed and the aggregate shown is the one before it. */
  stale: boolean;
  /** The window, as ISO instants: whole billing days, `until` the start of tomorrow. */
  since: string;
  until: string;
}

/** The part of the page that is cached: everything the summaries answer. */
interface Aggregate {
  traffic: TrafficDay[];
  outcomes: OutcomeSlice[];
  sent: number;
  delivered: number;
  resolved: number;
  spend: number;
  failedTotal: number;
  settling: boolean;
}

/**
 * One message is one row, as UsageRollup.
 *
 * <p>Every vendor attempt is its own `cdr_submit` row and every one of them joins the message's
 * receipt, so a message that failed over once used to read here as two sent and two delivered. The
 * summaries count one row per message already; the two short lists take `isMessageRow`, the same
 * choice as a predicate, so they keep their index walk. Neither has a retry term: the accepted
 * attempt is not the first one after a failover. See `lib/cdr-grain.ts`.
 */
async function grain(): Promise<GrainOptions> {
  return { vendorAttempt: await hasVendorAttempt() };
}

/**
 * What the failures panel means by "failed", in one place because two places would drift.
 *
 * <p>**Anything with an outcome that is not `DELIVERED`** — so `FAILED`, `EXPIRED`, `REJECTED` and
 * `DROPPED` together: a customer whose sender ID started being rejected must not look at an empty
 * list and conclude nothing was wrong.
 *
 * <p>`IS NOT NULL` matters: a message with no receipt yet is pending, not failed, and every recent
 * message is pending for a while.
 *
 * <p>The same set the summaries' `failed + expired` covers, so the count above the panel (from the
 * summary) and the rows inside it (from this predicate) cannot disagree about what counts.
 */
const NOT_DELIVERED = "o.final_state IS NOT NULL AND o.final_state <> 'DELIVERED'";

/** Rows in each dashboard panel. Both the same, so the two cards stand the same height. */
const PANEL_ROWS = 6;

/** A watermark older than this is not a seam to lean on: the rollup has stopped. */
const WATERMARK_MAX_AGE_MS = 3 * 3_600_000;

const slot = globalThis as { __firefloMisOverviewCache?: SnapshotCache<Aggregate> };
/** One cache per process, surviving `next dev`'s re-evaluation (the `lib/smpp-test.ts` pattern). */
function cache(): SnapshotCache<Aggregate> {
  return (slot.__firefloMisOverviewCache ??= createSnapshotCache<Aggregate>());
}

/**
 * @param scope every account this session may see — a reseller's children included
 * @param ownAccountId the session's own account, and the only one whose balance is theirs. Summing
 *     a reseller's children into one figure would answer a question nobody asked; each child's
 *     balance is on its own page
 * @param days whole billing days back from today, today included
 */
export async function overviewFor(scope: string[], ownAccountId: string, days: number): Promise<Overview> {
  //whole billing days, so the first and last bars are not stubs of a partial day at one end only;
  //`until` is the start of tomorrow, so today is included and complete as it fills in
  const bounds = await billingDays(days);
  const [agg, recent, failed, credit] = await Promise.all([
    cache().get(overviewKey(scope, String(days)), () => aggregateFor(scope, bounds)),
    recentMessages(scope, bounds.since, bounds.until),
    failedMessages(scope, bounds.since, bounds.until),
    //live, and deliberately not filtered by the range: a balance is what is there now. Read through
    //the existing helper because `account_balance` lives in the CONFIG database, not the metrics one
    //-- and null when there is no row, meaning credit is not enforced for this account rather than
    //"out of money"
    getBalance(ownAccountId).catch(() => null),
  ]);
  const a = agg.value;
  //the summaries carry no currency; the platform has exactly one, and the balance is denominated
  //in it. The ordinary case asks nothing more than the balance already did
  const currency = credit?.currency ?? (await platformCurrency().catch(() => null));

  return {
    tiles: {
      sent: a.sent,
      delivered: a.delivered,
      rate: a.resolved ? Math.round((a.delivered / a.resolved) * 1000) / 10 : null,
      spend: a.spend,
      balance: credit?.enabled === false ? null : credit?.balance ?? null,
      currency,
    },
    traffic: a.traffic,
    outcomes: a.outcomes,
    recent,
    failed,
    //from the same rows the slices came from, so "6 of 214" cannot be a lie
    failedTotal: a.failedTotal,
    //said rather than left to be inferred from a rate that keeps climbing: most of today's traffic
    //has no receipt yet at any given moment, and a customer comparing two page loads deserves to
    //know why the number moved
    settling: a.settling,
    asOf: agg.asOf,
    stale: agg.stale,
    since: bounds.since.toISOString(),
    until: bounds.until.toISOString(),
  };
}

/**
 * The series, the counts and the spend, from the summaries.
 *
 * <p>Finished days come from `usage_daily` through `usageWindowSql`, scoped with `= ANY($4)`.
 * Today comes from the same read where the gateway keeps no hourly summary, or from
 * `usageHourlySql` over today alone where it does and its watermark is moving -- hours are UTC and
 * do not sum to a billing day in every zone, so the hourly seam is never asked for more than today.
 */
async function aggregateFor(
  scope: string[],
  bounds: { since: Date; todayStart: Date; until: Date; today: string }
): Promise<Aggregate> {
  const [g, zone, hourly] = await Promise.all([grain(), billingZone(), hourlySeam()]);
  const scoped = { ...g, account: false, accounts: true } as const;
  const select = `
     SELECT to_char(day, 'YYYY-MM-DD') AS day,
            SUM(submitted)             AS sent,
            SUM(delivered)             AS delivered,
            SUM(failed + expired)      AS failed,
            SUM(pending)               AS pending,
            SUM(price)                 AS spend
       FROM usage_rows
      GROUP BY 1`;
  const reads = hourly
    ? [
        query<Record<string, string>>(`${usageWindowSql({ ...scoped, bucket: "day", wholeDays: false })}${select}`,
          [bounds.since, bounds.todayStart, zone, scope]),
        query<Record<string, string>>(`${usageHourlySql({ ...scoped, bucket: "day" })}${select}`,
          [bounds.todayStart, bounds.until, zone, scope]),
      ]
    : [
        query<Record<string, string>>(`${usageWindowSql({ ...scoped, bucket: "day", wholeDays: false })}${select}`,
          [bounds.since, bounds.until, zone, scope]),
      ];
  const rows = (await Promise.all(reads)).flat();

  //every day of the window, so a day with no traffic is a gap in the chart rather than closed
  //up, which would draw a smooth line over an outage
  const byDay = new Map(rows.map((r) => [r.day, r]));
  const traffic: TrafficDay[] = [];
  const totals = { sent: 0, delivered: 0, failed: 0, pending: 0, spend: 0 };
  for (const day of dayStrings(bounds.today, bounds.since, bounds.until)) {
    const r = byDay.get(day);
    const delivered = num(r?.delivered);
    const failed = num(r?.failed);
    const resolved = delivered + failed;
    traffic.push({
      day,
      sent: num(r?.sent),
      delivered,
      failed,
      pending: num(r?.pending),
      //over what has RESOLVED, not over what was sent. Dividing by sent makes every recent day look
      //like a failure, because its receipts have not arrived yet
      rate: resolved ? Math.round((delivered / resolved) * 1000) / 10 : null,
    });
    totals.sent += num(r?.sent);
    totals.delivered += delivered;
    totals.failed += failed;
    totals.pending += num(r?.pending);
    totals.spend += num(r?.spend);
  }

  return {
    traffic,
    outcomes: [
      { outcome: "delivered", messages: totals.delivered },
      { outcome: "failed", messages: totals.failed },
      { outcome: "pending", messages: totals.pending },
    ],
    sent: totals.sent,
    delivered: totals.delivered,
    resolved: totals.delivered + totals.failed,
    spend: totals.spend,
    failedTotal: totals.failed,
    settling: totals.pending > 0,
  };
}

/** Whether today may be read from `usage_hourly`: the table exists and its watermark is moving. */
async function hourlySeam(): Promise<boolean> {
  if (!(await hasUsageHourly())) {
    return false;
  }
  const hwm = await hourlyWatermark();
  return hwm !== null && Date.now() - hwm.getTime() < WATERMARK_MAX_AGE_MS;
}

/**
 * The `YYYY-MM-DD` of every billing day in `[since, until)`, oldest first, ending on today.
 *
 * <p>Counted back from today's own string by calendar arithmetic in UTC, which is zone-free: the
 * window is whole days by construction and the database already placed today in the zone.
 */
function dayStrings(today: string, since: Date, until: Date): string[] {
  const days = Math.max(1, Math.round((until.getTime() - since.getTime()) / 86_400_000));
  const [y, m, d] = today.split("-").map(Number);
  const out: string[] = [];
  for (let i = days - 1; i >= 0; i--) {
    out.push(new Date(Date.UTC(y, m - 1, d - i)).toISOString().slice(0, 10));
  }
  return out;
}

/**
 * The most recent handful, so the page shows something concrete under the aggregates.
 *
 * <p>Bounded by the same range as everything else on the page rather than being "the last few ever":
 * a range button that moves three charts and leaves this list alone would be lying about what it
 * selects.
 *
 * <p>`ORDER BY submitted_at DESC LIMIT n` rides `idx_cdr_submit_submitted_at`, which is what makes
 * this cheap on a table this size — but only with the range in the WHERE clause, so the planner has
 * a bound to walk backwards from.
 */
async function recentMessages(
  scope: string[],
  since: Date,
  until: Date
): Promise<RecentMessage[]> {
  const g = await grain();
  const rows = await query<Record<string, string | null>>(
    //one row per message, as UsageRollup -- as a predicate rather than a DISTINCT ON subquery, so
    //the index walk described above survives: a subquery would sort the whole range first
    `SELECT s.gateway_msg_id, s.submitted_at, s.dest_addr, o.final_state,
            ${await bodyExpression()} AS body
       FROM cdr_submit s${OUTCOME_LATERAL}
      WHERE ${isMessageRow("s", g)}
        AND s.submitted_at >= $2 AND s.submitted_at < $3
        AND s.account_id = ANY($1)
      ORDER BY s.submitted_at DESC
      LIMIT ${PANEL_ROWS}`,
    [scope, since.toISOString(), until.toISOString()]
  );

  return rows.map(toRecent);
}

/**
 * The same, for messages that did not arrive.
 *
 * <p>**The cost is different from the query above and worth knowing.** That one stops after the
 * first few rows the index hands back; this one filters on the LATERAL's output, so the planner
 * walks backwards through submissions until it has accumulated {@link PANEL_ROWS} failures. On an
 * account failing 0.5% of its traffic that is a walk of about a thousand rows — bounded, because the
 * date range is still in the WHERE clause, and the walk stops at the start of the range whether or
 * not it found six. An account with no failures at all scans its whole range and returns nothing,
 * which is the worst case and is exactly the case where the range is smallest in rows.
 *
 * <p>No `count(*) OVER ()` for the total: that would make the query evaluate every failure in the
 * range rather than stopping at six. The summaries already count them, with the same meaning.
 */
async function failedMessages(
  scope: string[],
  since: Date,
  until: Date
): Promise<FailedMessage[]> {
  const g = await grain();
  const rows = await query<Record<string, string | null>>(
    //one row per message, as UsageRollup, by the same predicate as recentMessages and for the same
    //reason. Without it a failed-over message that then failed was listed once per attempt
    `SELECT s.gateway_msg_id, s.submitted_at, s.dest_addr,
            o.final_state, o.dlr_state, o.err_code,
            ${await bodyExpression()} AS body
       FROM cdr_submit s${OUTCOME_LATERAL}
      WHERE ${isMessageRow("s", g)}
        AND ${NOT_DELIVERED}
        AND s.submitted_at >= $2 AND s.submitted_at < $3
        AND s.account_id = ANY($1)
      ORDER BY s.submitted_at DESC
      LIMIT ${PANEL_ROWS}`,
    [scope, since.toISOString(), until.toISOString()]
  );

  return rows.map((r) => ({
    ...toRecent(r),
    dlrState: r.dlr_state == null ? null : num(r.dlr_state),
    errCode: r.err_code ?? null,
  }));
}

/**
 * The message text, or a literal null where the column does not exist.
 *
 * <p>The landing page must not be the one that needs the newest migration. Against a gateway that
 * has not applied V1.31.0 there is no `body` column, and naming it would take the whole dashboard
 * down for a field that is off by default and null on every row even where it exists.
 */
async function bodyExpression(): Promise<string> {
  return (await hasBodyColumn()) ? "left(s.body, 160)" : "NULL::text";
}

function toRecent(r: Record<string, string | null>): RecentMessage {
  return {
    gatewayMsgId: String(r.gateway_msg_id ?? ""),
    submittedAt: new Date(r.submitted_at as string).toISOString(),
    destAddr: r.dest_addr ?? null,
    finalState: r.final_state ?? null,
    body: r.body ?? null,
  };
}

function num(value: unknown): number {
  const n = Number(value ?? 0);
  return Number.isFinite(n) ? n : 0;
}
