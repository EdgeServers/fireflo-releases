/**
 * The REST API, described once.
 *
 * <p>Two customer-facing surfaces read this file: the playground builds its form controls from it,
 * and the reference page generates its parameter tables and code samples from it. That is the whole
 * point of it existing. A reference that is written separately from the thing a customer can click
 * drifts, and the drift is invisible until somebody integrates against the wrong half.
 *
 * <h2>Written from the parsers, not from the swagger file</h2>
 *
 * <p>`fireflo-sms-gateway/api/send-sms.swagger.json` is hand-maintained and wrong in places a
 * customer meets on their first day: it documents `custom_tlvs` as an array of pairs when the parser
 * wants an object, types `validity-period` as a string when it must be an integer, and describes a
 * `sendbatch` body whose keys the parser silently ignores. Everything here comes instead from
 * `SendRequestParser`, `BatchRequestParser`, `FieldNormaliser`, `MsisdnReader`, `ScheduleAtParser`
 * and the outcome switch in `SendResource`.
 *
 * <p>Database-free and import-free, so both pages and the tests can read it.
 */

/**
 * The destination number every example falls back to.
 *
 * <p>An Australian test MSISDN, and wrong for most customers — which is why it is only the default.
 * `panel.examples.msisdn` in `app_config` replaces it platform-wide; see `lib/platform-example-
 * number.ts`. It stays here so this module keeps its no-database, no-import promise, and so a page
 * that never resolves the setting still renders a complete example rather than an empty field.
 */
export const FALLBACK_MSISDN = "61491570006";

/**
 * One field's example, with the destination replaced by the platform's own.
 *
 * <p>Matched on the field NAME rather than on the value: substituting by string equality would also
 * rewrite any other field that happened to carry the same digits, and would silently stop working
 * the day someone edited the fallback in one of the two places it is declared.
 */
export function exampleValue(field: ApiField, msisdn?: string | null): string | undefined {
  if (field.name === "to" && field.example !== undefined && msisdn) {
    return msisdn;
  }
  return field.example;
}

/** How the playground renders a field. Separate from `type`, which is what the API accepts. */
export type Control =
  "text" | "textarea" | "number" | "select" | "senderId" | "product" | "pairs" | "messages";

export interface ApiField {
  /** Canonical spelling, underscored — the form a customer is most likely to type. */
  name: string;
  type: "string" | "integer" | "object" | "array";
  /** `"either"` where two fields satisfy one requirement between them. */
  required: boolean | "either";
  /** What the gateway assumes when the field is absent. Omitted when there is no default. */
  fallback?: string;
  /** One sentence for the table cell and the form hint. Says the consequence, not the rule. */
  note: string;
  control: Control;
  /** What the playground prefills. */
  example?: string;
  choices?: { value: string; label: string }[];
  /** True for fields behind the playground's disclosure, so the common case stays four controls. */
  advanced?: boolean;
}

export interface ApiError {
  status: number;
  message: string;
  when: string;
}

export type EndpointId = "send" | "sendbatch" | "balance" | "rate" | "ping";

export interface ApiEndpoint {
  id: EndpointId;
  method: "GET" | "POST";
  path: string;
  /** Sentence case, verb first — this is a tab label and a heading. */
  title: string;
  blurb: string;
  /** False only for /ping. Everything under /secure/ is Basic-authenticated. */
  secured: boolean;
  /** Query parameters for a GET, body fields for a POST. */
  fields: ApiField[];
  /** A real success body, pretty-printed. */
  success: string;
  /** Errors particular to this endpoint. The shared ones are listed once, below. */
  errors: ApiError[];
}

/**
 * The `data_coding` values the gateway has an alphabet for.
 *
 * <p>Anything else in 0–14 is accepted and decoded as UTF-8; 15 and above is a 400. The value is
 * passed to the carrier unchanged, so this chooses how the body is encoded, not merely how it is
 * counted.
 */
export const CODINGS: { value: string; label: string }[] = [
  { value: "0", label: "0 — SMSC default" },
  { value: "1", label: "1 — ASCII" },
  { value: "2", label: "2 — octet, unspecified" },
  { value: "3", label: "3 — Latin-1" },
  { value: "4", label: "4 — octet" },
  { value: "6", label: "6 — Cyrillic" },
  { value: "7", label: "7 — Hebrew" },
  { value: "8", label: "8 — UCS-2" },
];

/**
 * The fields a single message accepts, shared by `/secure/send` and by each element of a batch.
 *
 * <p>Order is the order the form shows them in, which is roughly how often they are used.
 */
const MESSAGE_FIELDS: ApiField[] = [
  {
    name: "to",
    type: "string",
    required: true,
    //MsisdnReader accepts an integral JSON number too, but a bare number has already lost any
    //leading zero by the time the parser sees it -- so the documentation says "quote it" rather
    //than "a number also works", which would be true and harmful
    note: "Destination in international format. Quote it — an unquoted number loses leading zeros.",
    control: "text",
    example: FALLBACK_MSISDN,
  },
  {
    name: "content",
    type: "string",
    required: "either",
    note: "The message text. Give this or hex_content, never both.",
    control: "textarea",
    example: "Your OTP is 4417, valid for 10 minutes.",
  },
  {
    name: "from",
    type: "string",
    required: false,
    fallback: "your login name",
    note: "Sender ID. Must be one approved for your account, or the send is refused with 403.",
    control: "senderId",
  },
  {
    name: "coding",
    type: "integer",
    required: false,
    fallback: "0",
    note: "SMPP data_coding. Use 8 for anything outside GSM-7, which halves the segment length.",
    control: "select",
    choices: CODINGS,
  },
  {
    name: "priority",
    type: "integer",
    required: false,
    fallback: "0",
    note: "0 to 3. The gateway has two levels, so 0 and 1 are normal, 2 and 3 are high.",
    control: "select",
    choices: [
      { value: "0", label: "0 — normal" },
      { value: "1", label: "1 — normal" },
      { value: "2", label: "2 — high" },
      { value: "3", label: "3 — high" },
    ],
  },
  {
    name: "dlr",
    type: "string",
    required: false,
    fallback: "no",
    note: "Set to yes to receive a delivery receipt. Requires dlr_url.",
    control: "select",
    choices: [
      { value: "no", label: "no" },
      { value: "yes", label: "yes" },
    ],
    advanced: true,
  },
  {
    name: "dlr_url",
    type: "string",
    required: false,
    note: "Where the receipt is POSTed. Mandatory once dlr is yes.",
    control: "text",
    advanced: true,
  },
  {
    name: "dlr_level",
    type: "integer",
    required: false,
    fallback: "2",
    //a control at last. It was refused with a 400 for anything but 2 until the gateway learned to
    //forward interim receipts; the test beside this file used to assert it was NOT offered, and
    //that assertion is now inverted rather than deleted -- the reason it existed still matters
    note: "Which receipts you want: 1 progress only, 2 the outcome, 3 both. Level 1 alone does not "
      + "send the outcome.",
    control: "select",
    choices: [
      { value: "1", label: "1 — progress only" },
      { value: "2", label: "2 — the outcome" },
      { value: "3", label: "3 — both" },
    ],
    advanced: true,
  },
  {
    name: "hex_content",
    type: "string",
    required: "either",
    note: "The body as hex octets, decoded with the charset for your coding. An odd length is a 400.",
    control: "text",
    advanced: true,
  },
  {
    name: "validity_period",
    type: "integer",
    required: false,
    note: "Minutes the carrier should keep trying. A whole number — not a duration string.",
    control: "number",
    advanced: true,
  },
  {
    name: "sdt",
    type: "string",
    required: false,
    note: "Scheduled delivery time, passed to the carrier unchanged and not validated here.",
    control: "text",
    advanced: true,
  },
  {
    name: "product",
    type: "string",
    required: false,
    fallback: "the product your login carries",
    //the only field here that changes what a message COSTS, which is why it is not free text
    note: "Prices this message on a different product. Only products your operator has allowed for "
      + "this login; anything else is refused, and most logins are allowed none.",
    control: "product",
    advanced: true,
  },
  {
    name: "custom_tlvs",
    type: "object",
    required: false,
    //The field most likely to be got wrong, and the one place the aliasing rule does not apply.
    //
    //The note stays one sentence because it is a form hint; the grammar in full is on the reference
    //page, which is where somebody who has hit a 400 goes looking. What it must carry is the shape,
    //because that is what the gateway's error cannot say: it answers "has an invalid value" and
    //quotes back JSON the customer can see is valid.
    note: "Extra SMPP parameters as a JSON object — {\"0x1401\": \"…\"} — not a list of pairs and "
      + "not a quoted string. Add :Int8 to a key to send a long number as eight bytes.",
    control: "pairs",
    advanced: true,
  },
];

/** The errors any secured call can return, so they are stated once rather than per endpoint. */
export const SHARED_ERRORS: ApiError[] = [
  {
    status: 401,
    message: "Authentication required",
    when: "No Authorization header. The response carries a WWW-Authenticate challenge.",
  },
  {
    status: 401,
    message: "Invalid token",
    when: "The header is not Basic, is not valid Base64, or has no colon in it.",
  },
  {
    status: 403,
    message: "Authentication failure",
    when: "Unknown login, wrong password, or an SMPP login — those cannot use this API.",
  },
  {
    status: 403,
    message: "Authorization failure",
    when: "Your login has an IP allow list and the request did not come from one of them.",
  },
  {
    status: 415,
    message: "This API supports JSON media type only.",
    when: "An Accept header that excludes JSON. Omitting Accept entirely is fine.",
  },
  {
    status: 429,
    message: "Rate limit exceeded",
    when: "Over your account's messages per second. There is no Retry-After — back off and retry.",
  },
];

export const ENDPOINTS: ApiEndpoint[] = [
  {
    id: "send",
    method: "POST",
    path: "/secure/send",
    title: "Send one message",
    blurb: "Queues a single message to one destination and returns the id you will see on its receipt.",
    secured: true,
    fields: MESSAGE_FIELDS,
    success: '{\n  "data": {\n    "messageId": "7a2a5b6c-3ec3-44e0-b2a6-9b056b887c46"\n  }\n}',
    errors: [
      {
        status: 400,
        message: "Mandatory argument to is not found.",
        when: "to was absent or blank. The same shape names content, dlr_url and the rest.",
      },
      {
        status: 400,
        message: "Unknown argument: <name>",
        when: "A field the API does not have — including username or password, which belong in the header.",
      },
      {
        status: 400,
        message: "Argument <name> has an invalid value: <value>.",
        when: "A field of the right name and the wrong shape, such as a non-numeric coding.",
      },
      {
        status: 402,
        message: "Insufficient credit",
        when: "Your prepaid balance will not cover the message. Nothing was sent or charged.",
      },
      {
        status: 403,
        message: "'<id>' is not an approved sender ID for this account.",
        when: "The from you sent has not been approved. Request it under Sender IDs.",
      },
      {
        status: 403,
        message: "The message content does not match any approved template for this account.",
        when: "Your account sends only approved wording, and this body matched none of it.",
      },
      {
        status: 412,
        message: "Got unparseable json data: <body>",
        when: "The body was empty, was not JSON, or was a bare array rather than an object.",
      },
      {
        status: 500,
        message: "Cannot send message",
        when: "The gateway accepted the request and could not queue it. Any charge is reversed.",
      },
    ],
  },
  {
    id: "sendbatch",
    method: "POST",
    path: "/secure/sendbatch",
    title: "Send a batch",
    blurb: "Queues many messages in one call. The response confirms acceptance only — per-message "
      + "results arrive on your errback URL.",
    secured: true,
    fields: [
      {
        name: "messages",
        type: "array",
        required: true,
        note: "One object per message, each taking the fields above. Its to may also be an array.",
        control: "messages",
      },
      {
        name: "globals",
        type: "object",
        required: false,
        note: "Defaults merged under every message, so a field set on a message wins.",
        control: "pairs",
        advanced: true,
      },
      {
        name: "batch_config",
        type: "object",
        required: false,
        note: "schedule_at, callback_url and errback_url. Other keys here are ignored, not refused.",
        control: "pairs",
        advanced: true,
      },
    ],
    success: '{\n  "data": {\n    "batchId": "c0ffee12-9f3a-4a1e-8d55-1b2c3d4e5f60",\n'
      + '    "messageCount": 3,\n    "scheduled": "3600s"\n  }\n}',
    errors: [
      {
        status: 400,
        message: "Mandatory argument messages is not found.",
        when: "messages was absent, was not an array, or was empty.",
      },
      {
        status: 400,
        message: "Argument messages has an invalid value: a batch may expand to at most 10000 messages.",
        when: "Array-valued destinations multiplied out past the cap.",
      },
      {
        status: 412,
        message: "Got unknown format: <value>, correct formats are …",
        when: "schedule_at was neither 3600s nor YYYY-MM-DD HH:MM:SS. A past date is refused too.",
      },
    ],
  },
  {
    id: "balance",
    method: "GET",
    path: "/secure/balance",
    title: "Check your balance",
    blurb: "What is left on the account this login bills to.",
    secured: true,
    fields: [],
    success: '{\n  "data": {\n    "balance": 4182.6,\n    "sms_count": "ND"\n  }\n}',
    errors: [],
  },
  {
    id: "rate",
    method: "GET",
    path: "/secure/rate",
    title: "Price a message",
    blurb: "What a message would cost. Sends nothing, charges nothing, and counts against no rate limit.",
    secured: true,
    fields: [
      {
        name: "to",
        type: "string",
        required: true,
        note: "Destination. Pricing can differ by country and network, so this is not optional.",
        control: "text",
        example: FALLBACK_MSISDN,
      },
      {
        name: "content",
        type: "string",
        required: false,
        note: "The body. Only its length matters here — it decides the segment count.",
        control: "textarea",
        example: "Your OTP is 4417, valid for 10 minutes.",
      },
      {
        name: "coding",
        type: "integer",
        required: false,
        fallback: "0",
        note: "Changes how many segments the same text occupies, so it changes the price.",
        control: "select",
        choices: CODINGS,
      },
      {
        name: "product",
        type: "string",
        required: false,
        fallback: "the product your login carries",
        note: "Prices against a different product, from the same allow list a send uses — so a "
          + "quote and a send cannot disagree about what you may name.",
        control: "product",
        advanced: true,
      },
      {
        name: "from",
        type: "string",
        required: false,
        note: "Accepted, and does not affect the price.",
        control: "senderId",
        advanced: true,
      },
    ],
    success: '{\n  "data": {\n    "unit_rate": 0.045,\n    "submit_sm_count": 1\n  }\n}',
    errors: [
      {
        status: 400,
        message: "Mandatory argument to is not found.",
        when: "to was absent or blank.",
      },
      {
        status: 403,
        message: "This login may not send on '<product>'.",
        when: "You named a product your operator has not allowed for this login.",
      },
    ],
  },
  {
    id: "ping",
    method: "GET",
    path: "/ping",
    title: "Ping",
    blurb: "Liveness. The one endpoint that needs no credentials — useful for a monitor.",
    secured: false,
    fields: [],
    success: '{\n  "data": {\n    "status": "ok"\n  }\n}',
    errors: [],
  },
];

export function endpoint(id: EndpointId): ApiEndpoint {
  const found = ENDPOINTS.find((e) => e.id === id);
  if (!found) {
    throw new Error(`No endpoint '${id}'`);
  }
  return found;
}

/**
 * What the gateway POSTs to a `dlr_url`.
 *
 * <p>Not a request field, so it is not an `ApiField` — this is the one direction where the customer
 * is the server. Null fields are omitted entirely rather than sent as null.
 */
export const DLR_FIELDS: { name: string; note: string }[] = [
  { name: "id", note: "The messageId the send returned. This is how you correlate." },
  { name: "stat", note: "DELIVRD, EXPIRED, DELETED, UNDELIV, ACCEPTD, UNKNOWN, REJECTD, FAILED, BUFFRED or SEEN." },
  {
    name: "level",
    note: "2 for the outcome, 1 for progress. A level 1 receipt does not mean the message is "
      + "finished — ACCEPTD and BUFFRED both arrive as 1 and another receipt follows.",
  },
  { name: "sub_date", note: "When you submitted it, ISO-8601. Omitted when unknown." },
  { name: "done_date", note: "When this receipt was raised, ISO-8601. On a level 2 receipt that is when the message finished." },
  { name: "to", note: "The destination, as you gave it." },
  { name: "from", note: "The sender ID that was used." },
  { name: "operator_msg_id", note: "The carrier's own reference, for raising a query with them." },
  { name: "account_id", note: "The account billed." },
  { name: "system_id", note: "The login that submitted it." },
  { name: "parts", note: "Segment count. Omitted when it is not known." },
];

export function dlrExample(msisdn: string = FALLBACK_MSISDN): string {
  return `{
  "id": "7a2a5b6c-3ec3-44e0-b2a6-9b056b887c46",
  "stat": "DELIVRD",
  "level": 2,
  "sub_date": "2026-08-13T08:58:59.672Z",
  "done_date": "2026-08-13T08:59:07.104Z",
  "to": "${msisdn}",
  "from": "SUNOTP",
  "operator_msg_id": "a1b2c3",
  "account_id": "acct-in-2001",
  "system_id": "sunrise-http",
  "parts": 1
}`;
}

/** What a batch callback carries. A bare GET with a query string, and no body at all. */
export const BATCH_CALLBACK_PARAMS: { name: string; note: string }[] = [
  { name: "batchId", note: "The batchId the sendbatch call returned." },
  { name: "to", note: "The one destination this result is about." },
  { name: "status", note: "1 when the message was accepted, 0 when it was refused." },
  { name: "statusText", note: "The messageId on success; the refusal in words on failure." },
];

/**
 * Whether these two spellings of a field name are the same field to the gateway.
 *
 * <p>`FieldNormaliser` rewrites every `_` to `-` before anything reads the body, so `dlr_url` and
 * `dlr-url` are one field — and supplying **both** is a 400 rather than a last-one-wins. The single
 * exception is `custom_tlvs`, which keeps its underscore, making `custom-tlvs` an unknown argument.
 *
 * <p>Exported because it is the rule most likely to surprise someone porting from another gateway,
 * and because a test can then pin it against the parser rather than against prose.
 */
export function sameField(a: string, b: string): boolean {
  const canon = (s: string) => (s === "custom_tlvs" || s === "custom-tlvs" ? s : s.replace(/_/g, "-"));
  return canon(a) === canon(b);
}

export const CODE_LANGUAGES = ["curl", "Node", "PHP", "Python"] as const;
export type CodeLanguage = (typeof CODE_LANGUAGES)[number];

export interface SampleContext {
  /** The messaging base URL, no trailing slash. */
  baseUrl: string;
  /** The customer's login, used as the Basic username. */
  login: string;
}

/**
 * A runnable example of one call.
 *
 * <p>The password is always a placeholder. Filling in a real one would put a live credential in a
 * page the customer might screenshot, paste into a ticket, or leave open — and it buys nothing,
 * because they have to move it into their own configuration anyway.
 */
export function codeSample(
  language: CodeLanguage,
  ep: ApiEndpoint,
  values: Record<string, unknown>,
  ctx: SampleContext
): string {
  const url = ctx.baseUrl + ep.path;
  const body = ep.method === "POST" ? values : null;
  const query = ep.method === "GET" ? queryString(values) : "";
  const full = url + query;

  switch (language) {
    case "curl":
      return curlSample(ep, full, body, ctx);
    case "Node":
      return nodeSample(ep, full, body, ctx);
    case "PHP":
      return phpSample(ep, full, body, ctx);
    case "Python":
      return pythonSample(ep, full, body, ctx);
  }
}

function queryString(values: Record<string, unknown>): string {
  const parts = Object.entries(values)
    .filter(([, v]) => v !== undefined && v !== null && v !== "")
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`);
  return parts.length ? `?${parts.join("&")}` : "";
}

function curlSample(ep: ApiEndpoint, url: string, body: unknown, ctx: SampleContext): string {
  const args: string[] = [];
  if (ep.secured) {
    args.push(`-u ${ctx.login}:$PASSWORD`);
  }
  if (body) {
    args.push("-H 'Content-Type: application/json'");
    args.push(`-d '${JSON.stringify(body, null, 2)}'`);
  }
  args.push(`'${url}'`);
  return `curl \\\n  ${args.join(" \\\n  ")}`;
}

function nodeSample(ep: ApiEndpoint, url: string, body: unknown, ctx: SampleContext): string {
  const headers = [ep.secured ? `    Authorization: "Basic " + auth,` : null,
    body ? `    "Content-Type": "application/json",` : null].filter(Boolean).join("\n");
  return [
    ep.secured
      ? `const auth = Buffer.from(\`${ctx.login}:\${process.env.SMS_PASSWORD}\`).toString("base64");\n`
      : "",
    `const res = await fetch("${url}", {`,
    `  method: "${ep.method}",`,
    headers ? `  headers: {\n${headers}\n  },` : "",
    body ? `  body: JSON.stringify(${JSON.stringify(body, null, 2).replace(/\n/g, "\n  ")}),` : "",
    `});`,
    ``,
    `const { data, message } = await res.json();`,
    `if (!res.ok) throw new Error(message);`,
  ].filter((l) => l !== "").join("\n");
}

function phpSample(ep: ApiEndpoint, url: string, body: unknown, ctx: SampleContext): string {
  const lines = [`$ch = curl_init('${url}');`, `curl_setopt_array($ch, [`];
  lines.push(`  CURLOPT_RETURNTRANSFER => true,`);
  if (ep.secured) {
    lines.push(`  CURLOPT_USERPWD => '${ctx.login}:' . getenv('SMS_PASSWORD'),`);
  }
  if (body) {
    lines.push(`  CURLOPT_POST => true,`);
    lines.push(`  CURLOPT_HTTPHEADER => ['Content-Type: application/json'],`);
    lines.push(`  CURLOPT_POSTFIELDS => json_encode(${phpArray(body as Record<string, unknown>)}),`);
  }
  lines.push(`]);`, ``, `$out = json_decode(curl_exec($ch), true);`);
  return lines.join("\n");
}

function phpArray(values: Record<string, unknown>, indent = "    "): string {
  const entries = Object.entries(values).map(
    ([k, v]) => `${indent}'${k}' => ${phpValue(v, indent)}`
  );
  return `[\n${entries.join(",\n")}\n${indent.slice(2)}]`;
}

/**
 * One value as PHP.
 *
 * <p>Recursive, and it has to be: `custom_tlvs` is an object and `messages` is a list of them, so
 * the flat version emitted `'custom_tlvs' => {"0x1401":"634"}` — a JSON literal dropped into PHP
 * source, which is a parse error. Nobody noticed because until the playground was fixed those
 * fields only ever arrived as strings, and a string renders fine. Making the payload correct is
 * what exposed the sample being wrong.
 */
function phpValue(value: unknown, indent: string): string {
  if (typeof value === "string") {
    return `'${value.replace(/\\/g, "\\\\").replace(/'/g, "\\'")}'`;
  }
  if (Array.isArray(value)) {
    const inner = value.map((v) => `${indent}  ${phpValue(v, `${indent}  `)}`);
    return `[\n${inner.join(",\n")}\n${indent}]`;
  }
  if (value && typeof value === "object") {
    return phpArray(value as Record<string, unknown>, `${indent}  `);
  }
  return JSON.stringify(value);
}

function pythonSample(ep: ApiEndpoint, url: string, body: unknown, ctx: SampleContext): string {
  const lines = ["import os, requests", ""];
  const args = [`"${url}"`];
  if (ep.secured) {
    args.push(`auth=("${ctx.login}", os.environ["SMS_PASSWORD"])`);
  }
  if (body) {
    args.push(`json=${pythonDict(body as Record<string, unknown>)}`);
  }
  lines.push(`r = requests.${ep.method.toLowerCase()}(${args.join(", ")})`);
  lines.push(`r.raise_for_status()`);
  lines.push(`print(r.json()["data"])`);
  return lines.join("\n");
}

function pythonDict(values: Record<string, unknown>): string {
  const entries = Object.entries(values).map(([k, v]) =>
    `    "${k}": ${typeof v === "string" ? JSON.stringify(v) : JSON.stringify(v)}`);
  return `{\n${entries.join(",\n")}\n}`;
}
