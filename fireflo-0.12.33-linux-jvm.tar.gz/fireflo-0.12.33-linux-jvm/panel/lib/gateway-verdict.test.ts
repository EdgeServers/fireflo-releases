import { strict as assert } from "node:assert";
import { test } from "node:test";
import { gatewayVerdict, vendorTps, vendorTpsHistory } from "./gateway-verdict.ts";
import type { Health, HealthWorker } from "./health-types.ts";

function worker(over: Partial<HealthWorker> = {}): HealthWorker {
  return {
    name: "v", type: "smppclient", accepting: true, paused: false, suspended_manually: false,
    suspended_automatically: false, bound: 2, queue_depth: 0, retry_queue_depth: 0, tps_measured: 10,
    ...over,
  };
}
function health(workers: HealthWorker[], over: Partial<Health> = {}): Health {
  return { observed_at: "", router_queue: 0, awaiting_receipt: 0, dlr_store_persistent: true, cdr: null, workers, ...over };
}

test("no snapshot is unreachable, with the error in the detail", () => {
  const v = gatewayVerdict(null, "timeout");
  assert.equal(v.label, "Unreachable");
  assert.equal(v.tone, "destructive");
  assert.match(v.detail, /timeout/);
  assert.equal(v.tps, null);
});

test("every in-service vendor bound is healthy, and the rate is their sum", () => {
  const v = gatewayVerdict(health([worker({ name: "a", tps_measured: 10 }), worker({ name: "b", tps_measured: 5 })]), null);
  assert.equal(v.label, "Healthy");
  assert.equal(v.tps, 15);
});

test("a vendor with no bind degrades the gateway and is named", () => {
  const v = gatewayVerdict(health([worker({ name: "a" }), worker({ name: "intl", bound: 0 })]), null);
  assert.equal(v.label, "Degraded");
  assert.equal(v.tone, "warning");
  assert.match(v.detail, /intl/);
});

test("every vendor unbound is down", () => {
  const v = gatewayVerdict(health([worker({ bound: 0 }), worker({ name: "b", bound: null })]), null);
  assert.equal(v.label, "Down");
  assert.equal(v.tone, "destructive");
});

test("a disabled, paused or suspended vendor does not count, nor does a listener", () => {
  const v = gatewayVerdict(health([
    worker({ name: "ok" }),
    worker({ name: "off", accepting: false, bound: 0 }),
    worker({ name: "paused", paused: true, bound: 0 }),
    worker({ name: "held", suspended_manually: true, bound: 0 }),
    worker({ name: "smpp-1", type: "smppserver", bound: 0 }),
  ]), null);
  assert.equal(v.label, "Healthy");
});

test("a disconnected broker is degraded even with every vendor bound", () => {
  const v = gatewayVerdict(health([worker()], { broker: { connected: false, queue: 0, messages: 0, consumers: 0 } }), null);
  assert.equal(v.label, "Degraded");
  assert.equal(v.tone, "destructive");
});

test("a failed poll on top of a good snapshot is a warning, not an outage", () => {
  const v = gatewayVerdict(health([worker()]), "503");
  assert.equal(v.label, "Degraded");
  assert.equal(v.tone, "warning");
});

test("the rate is null when no vendor measures one, and zero is a real reading", () => {
  assert.equal(vendorTps([worker({ tps_measured: null }), worker({ type: "smppserver", tps_measured: 9 })]), null);
  assert.equal(vendorTps([worker({ tps_measured: 0 })]), 0);
});

test("the history sums vendors sample by sample and leaves unreported positions null", () => {
  const history = new Map<string, (number | null)[]>([
    ["a", [1, null, 3]],
    ["b", [2, null, 4]],
    ["smpp-1", [100, 100, 100]],
  ]);
  const workers = [worker({ name: "a" }), worker({ name: "b" }), worker({ name: "smpp-1", type: "smppserver" })];
  assert.deepEqual(vendorTpsHistory(history, workers), [3, null, 7]);
});
