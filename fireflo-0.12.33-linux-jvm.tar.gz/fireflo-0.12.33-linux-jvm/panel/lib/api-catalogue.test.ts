import { test } from "node:test";
import assert from "node:assert/strict";
import {
  CODE_LANGUAGES,
  CODINGS,
  DLR_FIELDS,
  ENDPOINTS,
  SHARED_ERRORS,
  FALLBACK_MSISDN,
  codeSample,
  dlrExample,
  endpoint,
  exampleValue,
  sameField,
} from "./api-catalogue.ts";

/**
 * The one description both customer-facing pages are generated from.
 *
 * <p>Every case pins something in the gateway's parsers, because this file is only useful while it
 * agrees with them — and the shipped `api/send-sms.swagger.json` is the proof that a
 * separately-maintained description drifts. Several tests below name a specific way that file is
 * wrong, so that this one cannot go the same way quietly.
 */

const ctx = { baseUrl: "https://api.example.com", login: "sunrise-http" };

test("every field a message may carry is described, and nothing that is not", () => {
  //SendRequestParser.KNOWN, exactly. Anything outside it is a 400 'Unknown argument', so listing a
  //field this API does not have would document a request that cannot succeed
  const known = [
    "to", "from", "content", "hex_content", "coding", "priority", "sdt",
    "validity_period", "dlr", "dlr_url", "dlr_level", "dlr_method", "tags", "custom_tlvs",
    //accepted, but only from a login whose operator has allowed the value -- see
    //MessageSubmissionService.resolveProduct. Being in KNOWN is not being permitted
    "product",
  ];
  const described = endpoint("send").fields.map((f) => f.name);

  for (const name of described) {
    assert.ok(known.includes(name), `${name} is not a field the gateway accepts`);
  }
  assert.equal(new Set(described).size, described.length, "each field appears once");
});

test("the two fields that are accepted and do nothing are not offered as controls", () => {
  //tags is in KNOWN and never read; dlr_method is accepted and inert because the receipt format is
  //a gateway-wide setting. A form control for either would invite a customer to configure something
  //that has no effect
  const described = endpoint("send").fields.map((f) => f.name);

  for (const inert of ["tags", "dlr_method"]) {
    assert.ok(!described.includes(inert), `${inert} should not be a playground control`);
  }
});

test("dlr_level is a control, and offers all three levels the parser now accepts", () => {
  //this list used to contain dlr_level, because SendRequestParser refused anything but 2 -- there
  //was one receipt level and offering a choice would have been offering a 400. The gateway now
  //forwards interim receipts, so the assertion is inverted rather than deleted: the reason it
  //existed is exactly the reason it has to change with the parser
  const field = endpoint("send").fields.find((f) => f.name === "dlr_level");

  assert.ok(field, "dlr_level is not described");
  assert.equal(field.control, "select", "free text here is a 400 waiting to happen");
  assert.deepEqual(field.choices?.map((c) => c.value), ["1", "2", "3"]);
  //validateDlrOptions refuses < 1 and > 3, and an omitted level is level 2
  assert.equal(field.fallback, "2");
  assert.equal(field.required, false, "an existing caller must not have to send it");
});

test("the receipt example documents both levels, not just the outcome", () => {
  //ForwardDlrService sends level 1 for a progress receipt and level 2 for an outcome. The note used
  //to say "always 2", which was already untrue -- an ACCEPTD was forwarded labelled 2 and taken by
  //the receiver as the last word on the message
  const level = DLR_FIELDS.find((f) => f.name === "level");

  assert.match(level?.note ?? "", /\b1\b/);
  assert.match(level?.note ?? "", /\b2\b/);
  assert.ok(!/always 2/i.test(level?.note ?? ""), "a level 1 receipt exists now");
});

test("to is required on both the endpoints that take a destination", () => {
  for (const id of ["send", "rate"] as const) {
    const to = endpoint(id).fields.find((f) => f.name === "to");
    assert.equal(to?.required, true, id);
  }
});

test("content and hex_content are one requirement between them", () => {
  //SendRequestParser: neither is 'Mandatory argument content is not found', both is an invalid
  //value. Marking either one `required: true` would make the table say something false
  const fields = endpoint("send").fields;

  assert.equal(fields.find((f) => f.name === "content")?.required, "either");
  assert.equal(fields.find((f) => f.name === "hex_content")?.required, "either");
});

test("from documents that it falls back to the login name", () => {
  //SendResource passes caller.getLogin() as defaultFrom, so an omitted from is not "no sender ID"
  const from = endpoint("send").fields.find((f) => f.name === "from");

  assert.equal(from?.fallback, "your login name");
});

test("validity_period is an integer, which is where the shipped swagger file is wrong", () => {
  //send-sms.swagger.json types it as a string; SendRequestParser requires an integral number >= 0.
  //A customer following that file sends "60" and gets a 400
  const field = endpoint("send").fields.find((f) => f.name === "validity_period");

  assert.equal(field?.type, "integer");
});

test("custom_tlvs is an object, which is the other place that file is wrong", () => {
  //documented there as an array of [tag, value] pairs with an example tag of "peid" -- which
  //TlvUtil.parseTag rejects outright, since a tag is the part after the last underscore
  const field = endpoint("send").fields.find((f) => f.name === "custom_tlvs");
  const note = field?.note ?? "";

  assert.equal(field?.type, "object");
  //a hex tag rather than one particular tag: the note is a form hint and which example it uses is
  //not a fact worth pinning. That it shows the hex FORM is, because a bare decimal means a
  //different tag and the whole grammar turns on the distinction
  assert.match(note, /0x[0-9A-Fa-f]{4}/);
  assert.match(note, /not a list of pairs/);
  //the shape that actually produced a support question: the playground sent the textarea's text, so
  //the gateway got a string where an object belongs and answered with the customer's own valid JSON
  //quoted back. The hint has to name that case, because the gateway's error cannot
  assert.match(note, /not a quoted string/);
});

test("a TLV object reaches the generated samples as an object, not as a quoted string", () => {
  //THE regression, and it is one line of output. The playground used to hand `custom_tlvs` through
  //as the literal text of a textarea, so every sample a customer copied carried
  //  "custom_tlvs": "{\"0x1401\":\"…\"}"
  //-- a string where an object belongs. They then pasted it into a terminal and got a 400 quoting
  //back JSON they could see was valid. The payload builder is what was fixed; this asserts the
  //visible consequence, because the sample is what people actually copy.
  const payload = { to: "919216217231", content: "hi", custom_tlvs: { "0x1401": "63463456346734734" } };

  for (const language of CODE_LANGUAGES) {
    const sample = codeSample(language, endpoint("send"), payload, ctx);
    //the tag, without assuming a quote style: PHP writes '0x1401' and the rest write "0x1401"
    assert.ok(
      sample.includes("0x1401"),
      `${language} sample does not carry the tag: ${sample}`
    );
    assert.ok(
      !sample.includes('\\"0x1401\\"'),
      `${language} sample escapes the TLV object, so it is a string: ${sample}`
    );
  }
});

test("a nested object renders as PHP, not as JSON dropped into PHP source", () => {
  //found by generating the sample and running `php -l` on it. The PHP builder was one level deep,
  //so a nested value fell through to JSON.stringify and emitted
  //  'custom_tlvs' => {"0x1401":"634"}
  //which is a parse error. It went unnoticed because until the payload builder was fixed these
  //fields only ever arrived as strings, and a string renders fine -- making the payload correct is
  //what exposed the sample being wrong.
  const sample = codeSample("PHP", endpoint("send"), {
    to: "9", custom_tlvs: { "0x1401": "634" },
  }, ctx);

  assert.match(sample, /'0x1401' => '634'/);
  assert.ok(!sample.includes('=> {"'), `a JSON object leaked into PHP source: ${sample}`);
});

test("a list of objects renders as PHP too, which sendbatch needs", () => {
  const sample = codeSample("PHP", endpoint("sendbatch"), {
    messages: [{ to: "1", content: "one" }],
  }, ctx);

  assert.match(sample, /'to' => '1'/);
  assert.ok(!sample.includes('=> [{"'), `a JSON array leaked into PHP source: ${sample}`);
});

test("the batch body is the three keys the parser actually reads", () => {
  //not the top-level sdt/callback_url/errback_url the swagger file lists, which BatchRequestParser
  //silently ignores -- the worst kind of wrong, because it fails without an error
  const names = endpoint("sendbatch").fields.map((f) => f.name);

  assert.deepEqual(names, ["messages", "globals", "batch_config"]);
});

test("the batch response documents all three fields it can carry", () => {
  //BatchResponseData is {batchId, messageCount, scheduled}, not {batchId} as documented elsewhere
  const success = endpoint("sendbatch").success;

  for (const key of ["batchId", "messageCount", "scheduled"]) {
    assert.match(success, new RegExp(key), key);
  }
});

test("underscore and hyphen are the same field, and custom_tlvs is the exception", () => {
  //FieldNormaliser rewrites every _ to - before anything reads the body, except for custom_tlvs
  assert.ok(sameField("dlr_url", "dlr-url"));
  assert.ok(sameField("validity_period", "validity-period"));
  assert.ok(sameField("hex_content", "hex-content"));

  //custom-tlvs is an unknown argument, not another spelling of custom_tlvs
  assert.ok(!sameField("custom_tlvs", "custom-tlvs"));

  assert.ok(!sameField("to", "from"), "the rule must not collapse unrelated names");
});

test("the coding table stops at 8 and starts at 0", () => {
  //CodingCharsets has an alphabet for 0,1,2,3,4,6,7,8. Everything else up to 14 is accepted and
  //decoded as UTF-8, so offering it as a labelled choice would be inventing a meaning
  assert.deepEqual(CODINGS.map((c) => c.value), ["0", "1", "2", "3", "4", "6", "7", "8"]);
  assert.ok(CODINGS.every((c) => c.label.startsWith(c.value)));
});

test("ping is the one endpoint that needs no credentials", () => {
  //ApiPaths.isSecured is "first segment is secure", so /ping is open and everything else is not
  for (const ep of ENDPOINTS) {
    assert.equal(ep.secured, ep.path.startsWith("/secure/"), ep.path);
  }
  assert.equal(endpoint("ping").secured, false);
});

test("the shared errors cover the four a caller most needs to tell apart", () => {
  const statuses = SHARED_ERRORS.map((e) => e.status);

  //401 no credentials, 403 wrong ones, 415 wrong Accept, 429 too fast. Merging any two of these
  //is what makes an empty wallet indistinguishable from a wrong password
  for (const status of [401, 403, 415, 429]) {
    assert.ok(statuses.includes(status), String(status));
  }
});

test("the 429 says there is no Retry-After, because there is not", () => {
  //ApiExceptionMapper sets only the status, content type and entity. A client written to wait for
  //the header waits forever
  const limited = SHARED_ERRORS.find((e) => e.status === 429);

  assert.match(limited?.when ?? "", /back off/i);
});

test("insufficient credit is 402 and not 403", () => {
  //the one distinction SendResource's own comment calls out: reusing 403 would make an empty wallet
  //look like a wrong password
  const credit = endpoint("send").errors.find((e) => e.message === "Insufficient credit");

  assert.equal(credit?.status, 402);
});

test("the curl sample is exactly what a customer would paste", () => {
  const sample = codeSample("curl", endpoint("send"), { to: "61491570006", content: "Hi" }, ctx);

  assert.equal(sample, [
    "curl \\",
    "  -u sunrise-http:$PASSWORD \\",
    "  -H 'Content-Type: application/json' \\",
    `  -d '{`,
    `  "to": "61491570006",`,
    `  "content": "Hi"`,
    `}' \\`,
    "  'https://api.example.com/secure/send'",
  ].join("\n"));
});

test("a real password never reaches a sample, in any language", () => {
  //the examples are on a page a customer might screenshot into a support ticket
  for (const language of ["curl", "Node", "PHP", "Python"] as const) {
    const sample = codeSample(language, endpoint("send"), { to: "1" }, ctx);
    assert.ok(!sample.includes("hunter2"), language);
    assert.match(sample, /PASSWORD/, `${language} should point at an environment variable`);
  }
});

test("a GET puts its values on the query string rather than in a body", () => {
  const sample = codeSample("curl", endpoint("rate"), { to: "61491570006", coding: 8 }, ctx);

  assert.match(sample, /\/secure\/rate\?to=61491570006&coding=8/);
  assert.ok(!sample.includes("-d "), "a GET has no body");
});

test("an empty value is left out rather than sent blank", () => {
  //an empty from is not the same as no from: the gateway substitutes the login for the second and
  //would whitelist-check an empty string for the first
  const sample = codeSample("curl", endpoint("rate"), { to: "1", from: "" }, ctx);

  assert.ok(!sample.includes("from="));
});

test("ping needs no credentials in its sample either", () => {
  const sample = codeSample("curl", endpoint("ping"), {}, ctx);

  assert.ok(!sample.includes("-u "), "a -u here would teach the wrong thing about /ping");
});

test("every endpoint has a success body that parses", () => {
  //these are shown as the documented 200. One with a stray comma would be copied into a test fixture
  for (const ep of ENDPOINTS) {
    assert.doesNotThrow(() => JSON.parse(ep.success), ep.id);
  }
});

test("every field carries a note, because the table has a column for it", () => {
  for (const ep of ENDPOINTS) {
    for (const field of ep.fields) {
      assert.ok(field.note.trim().length > 10, `${ep.id}.${field.name}`);
    }
  }
});

test("product is offered on both send and rate, so a quote cannot disagree with a send", () => {
  //the two go through the same per-credential allow list in the gateway. Describing it on one and
  //not the other would send somebody to quote a product they can send on, or the reverse
  for (const id of ["send", "rate"] as const) {
    const field = endpoint(id).fields.find((f) => f.name === "product");
    assert.ok(field, `${id} does not describe product`);
    assert.equal(field.required, false, "an existing caller must not have to send it");
    assert.equal(field.control, "product", "free text would invite a guaranteed 403");
    assert.ok(field.fallback, "the reader has to be told what happens when it is omitted");
  }
});

test("the platform's own example number replaces the fallback on `to`", () => {
  //what a customer outside Australia should be copying. The catalogue keeps the fallback so a page
  //that never resolves the setting still renders a complete example
  const to = endpoint("send").fields.find((f) => f.name === "to")!;

  assert.equal(exampleValue(to, "919876543210"), "919876543210");
  assert.equal(exampleValue(to, null), FALLBACK_MSISDN);
  assert.equal(exampleValue(to, ""), FALLBACK_MSISDN, "an empty setting is not a number");
});

test("substituting the destination does not rewrite any other field", () => {
  //matched on the field name, not the value: matching by string equality would rewrite anything
  //that happened to carry the same digits
  const content = endpoint("send").fields.find((f) => f.name === "content")!;

  assert.equal(exampleValue(content, "919876543210"), content.example);
});

test("the substituted number reaches the pasteable sample", () => {
  //the assertion that matters: a number shown in the form and absent from the curl block would be
  //two examples, and the one a customer copies is the wrong one
  const sample = codeSample("curl", endpoint("send"), { to: "919876543210", content: "Hi" }, ctx);

  assert.match(sample, /"to": "919876543210"/);
  assert.ok(!sample.includes(FALLBACK_MSISDN), "the Australian default must not survive");
});

test("the delivery receipt example carries the same number", () => {
  assert.match(dlrExample("919876543210"), /"to": "919876543210"/);
  assert.match(dlrExample(), new RegExp(`"to": "${FALLBACK_MSISDN}"`), "and falls back on its own");
});
