import { test } from "node:test";
import assert from "node:assert/strict";
import {
  BATCH_LIMIT,
  EMPTY_SELECTOR,
  applyBatch,
  batchHref,
  confirmationPhrase,
  confirmationSentence,
  confirms,
  housekeepingBody,
  housekeepingPath,
  matchSummary,
  nextLimit,
  parseOlderThan,
  readHousekeepingResult,
  recheck,
  selectorProblem,
  startLoop,
  stopSentence,
  type HousekeepingResult,
} from "./queue-clean.ts";

/**
 * Queue cleaning from the panel: the request the gateway is sent, the sentence the operator reads,
 * the phrase they type, and when the batch loop stops. The dialog is a thin shell over these.
 */

function result(over: Partial<HousekeepingResult> = {}): HousekeepingResult {
  return {
    batchId: null, dryRun: false, matched: 0, archived: 0, refunded: 0, receiptsSent: 0, failed: [],
    byWorker: {}, byAccount: {}, refundTotal: null, sample: [], more: false, ...over,
  };
}

test("the gateway paths are the four stores under /ops/housekeeping", () => {
  assert.equal(housekeepingPath("worker"), "/ops/housekeeping/worker");
  assert.equal(housekeepingPath("routing"), "/ops/housekeeping/routing");
  assert.equal(housekeepingPath("receipts"), "/ops/housekeeping/receipts");
  assert.equal(housekeepingPath("callbacks"), "/ops/housekeeping/callbacks");
});

test("older than: units, empty for any age, and a sentence for anything else", () => {
  assert.equal(parseOlderThan("2h"), 7200);
  assert.equal(parseOlderThan(" 3d "), 259_200);
  assert.equal(parseOlderThan("90s"), 90);
  assert.equal(parseOlderThan("30m"), 1800);
  assert.equal(parseOlderThan(""), null);
  assert.deepEqual(parseOlderThan("2 hours"), { error: "Older than takes a number and a unit: 90s, 30m, 2h or 3d." });
  assert.ok(typeof parseOlderThan("0h") === "object");
});

test("the request body: the plan's field names, empty fields left out, limit clamped", () => {
  const body = housekeepingBody(
    { ...EMPTY_SELECTOR, store: "worker", subStore: "held", worker: " smppclient.acme ", olderThan: "2h" },
    { dryRun: false, limit: 50_000, note: " stuck after vendor outage ", actor: "ops@example.com" }
  );
  assert.deepEqual(body, {
    limit: BATCH_LIMIT,
    dryRun: false,
    subStore: "held",
    worker: "smppclient.acme",
    olderThanSeconds: 7200,
    note: "stuck after vendor outage",
    actor: "ops@example.com",
  });
  const dry = housekeepingBody({ ...EMPTY_SELECTOR, store: "receipts", systemId: "acme01", all: true }, { dryRun: true });
  assert.deepEqual(dry, { limit: BATCH_LIMIT, dryRun: true, systemId: "acme01", all: true });
});

test("selector problems: unscoped worker and routing need Every account; receipts need a login or account", () => {
  assert.match(selectorProblem({ ...EMPTY_SELECTOR, store: "worker" }) ?? "", /Every account/);
  assert.equal(selectorProblem({ ...EMPTY_SELECTOR, store: "worker", all: true }), null);
  assert.equal(selectorProblem({ ...EMPTY_SELECTOR, store: "routing", subStore: "failed", account: "acme" }), null);
  assert.match(selectorProblem({ ...EMPTY_SELECTOR, store: "receipts", all: true }) ?? "", /system id or an account/);
  assert.equal(selectorProblem({ ...EMPTY_SELECTOR, store: "callbacks" }), null, "callbacks may be cleaned wholesale");
  assert.match(selectorProblem({ ...EMPTY_SELECTOR, store: "worker", subStore: "failed", all: true }) ?? "", /not part of worker/);
  assert.match(selectorProblem({ ...EMPTY_SELECTOR, store: "worker", account: "ac me" }) ?? "", /no spaces/);
  assert.match(selectorProblem({ ...EMPTY_SELECTOR, store: "worker", account: "acme", olderThan: "soon" }) ?? "", /number and a unit/);
});

test("the answer is read from the plan's fields; per-account refunds are summed only when every entry has one", () => {
  const r = readHousekeepingResult({
    batchId: "b1", dryRun: true, matched: 12, archived: 0, refunded: 0, receiptsSent: 0, failed: [],
    byWorker: { "smppclient.acme": 12 },
    byAccount: { acme: { count: 10, refund: "0.10" }, beta: { count: 2, refund: 0.02 } },
    sample: [{ serial: "S1", account_id: "acme", source_addr: "FIRE", dest_addr: "61400000000", queued_at: "2026-10-16T00:00:00Z", retries: 2 }],
    more: true,
  });
  assert.equal(r.matched, 12);
  assert.deepEqual(r.byAccount, { acme: 10, beta: 2 });
  assert.equal(r.refundTotal, "0.12");
  assert.equal(r.sample[0].account, "acme");
  assert.equal(r.sample[0].from, "FIRE");
  assert.equal(r.sample[0].retries, 2);
  assert.equal(r.more, true);

  const plain = readHousekeepingResult({ matched: 3, byAccount: { acme: 3 }, more: false });
  assert.equal(plain.refundTotal, null, "never invented from counts");
  assert.equal(readHousekeepingResult({ refundTotal: "1.5", byAccount: { a: 1 } }).refundTotal, "1.5");
  assert.equal(readHousekeepingResult(null).matched, 0);
});

test("the dry-run line: matches, accounts and the refund — no refund for receipts", () => {
  const r = result({ matched: 1204, byAccount: { a: 1, b: 2, c: 3 }, refundTotal: "12.04" });
  assert.equal(matchSummary("worker", r), "1,204 match · 3 accounts · refund 12.04");
  assert.equal(matchSummary("receipts", r), "1,204 match · 3 accounts");
  assert.equal(matchSummary("routing", result({ matched: 1, byAccount: { a: 1 } })), "1 match · 1 account · refund total not reported");
});

test("the confirmation: CLEAN <n> exactly, and the sentence names refunds, receipts, operatorPurge and no undo", () => {
  assert.equal(confirmationPhrase(1204), "CLEAN 1204");
  assert.ok(confirms(" CLEAN 1204 ", 1204));
  assert.ok(!confirms("clean 1204", 1204));
  assert.ok(!confirms("CLEAN 1,204", 1204));
  assert.ok(!confirms("CLEAN 1205", 1204));
  assert.ok(!confirms("CLEAN 0", 0), "nothing to confirm at zero");

  const s = confirmationSentence("worker", 5, result({ byAccount: { acme: 3, beta: 2 }, refundTotal: "0.05" }));
  assert.equal(
    s,
    "Archive and end 5 messages? This refunds 0.05 to 2 accounts; sends a failed receipt where one was asked for; "
      + "records each as REJECTED (operatorPurge); and cannot be undone."
  );
  assert.match(confirmationSentence("receipts", 1, result()), /^Archive and remove 1 receipt\? They carry no money/);
});

test("batch loop: never asks for more than was confirmed", () => {
  const s = startLoop(25_000);
  assert.equal(nextLimit(s), BATCH_LIMIT);
  const after2 = applyBatch(applyBatch(s, result({ archived: 10_000, more: true })), result({ archived: 10_000, more: true }));
  assert.equal(after2.stopped, null);
  assert.equal(nextLimit(after2), 5_000);
});

test("batch loop: stops when the gateway says nothing more matches", () => {
  const s = applyBatch(startLoop(100), result({ batchId: "b1", archived: 40, refunded: 30, receiptsSent: 20, more: false }));
  assert.equal(s.stopped, "finished");
  assert.deepEqual(s.batchIds, ["b1"]);
  assert.equal(s.refunded, 30);
  assert.match(stopSentence(s, "worker"), /^40 messages archived\. Nothing more matches\.$/);
});

test("batch loop: stops at the confirmed count even when more match", () => {
  const s = applyBatch(startLoop(10), result({ archived: 10, more: true }));
  assert.equal(s.stopped, "confirmed-reached");
});

test("batch loop: failures stop the run first, whatever else is true", () => {
  const s = applyBatch(startLoop(10), result({ archived: 10, more: true, failed: [{ serial: "x" }] }));
  assert.equal(s.stopped, "failed");
  assert.match(stopSentence(s, "worker"), /could not archive/);
});

test("batch loop: a batch that archives nothing stops rather than asking forever", () => {
  const s = applyBatch(startLoop(10), result({ archived: 0, more: true }));
  assert.equal(s.stopped, "no-progress");
});

test("a count that moved before the first batch is confirmed again", () => {
  assert.deepEqual(recheck(5, result({ matched: 5 })), { ok: true });
  assert.deepEqual(recheck(5, result({ matched: 7 })), { ok: false, matched: 7 });
  assert.deepEqual(recheck(5, result({ matched: 3 })), { ok: false, matched: 3 });
});

test("a batch links to its entries on Reports → Archives", () => {
  assert.equal(batchHref("6f1c"), "/cp/archives?tab=entries&range=all&batch=6f1c");
});
