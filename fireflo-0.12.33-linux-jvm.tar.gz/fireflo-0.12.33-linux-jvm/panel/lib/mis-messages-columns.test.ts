import { test } from "node:test";
import assert from "node:assert/strict";
import {
  MIS_COLUMNS,
  MIS_DEFAULT_COLUMN_IDS,
  isLockedMisColumn,
  resolveMisColumns,
} from "./mis-messages-columns.ts";
import type { ColumnChoice } from "./table-columns.ts";

/**
 * The customer table's column choice.
 *
 * <p>Two of these tests are about the chooser being useful and one is about it being safe. The safe
 * one is the last: a customer's catalogue must not contain a column the API is not allowed to send,
 * and the cheapest way for that to happen is somebody adding an id here by hand.
 */

const ids = (choice: ColumnChoice | null) => resolveMisColumns(choice).map((c) => c.id);

test("with no stored choice, the defaults are shown in catalogue order", () => {
  const shown = ids(null);

  assert.deepEqual(shown, [...MIS_DEFAULT_COLUMN_IDS]);
  assert.ok(shown.includes("submittedAt"));
  assert.ok(shown.includes("gatewayMsgId"), "the id a customer quotes on a ticket");
  //this is the difference from inheriting the operator's flags, which would have offered vendor
  assert.ok(!shown.includes("vendor"));
});

test("a locked column is shown however the stored choice votes", () => {
  //the chooser disables these boxes, but a preference written by an older release -- or by hand --
  //is not bound by what today's chooser allows
  const hostile: ColumnChoice = {
    v: 1,
    on: [],
    off: ["submittedAt", "destAddr", "outcome"],
  };

  const shown = ids(hostile);
  assert.ok(shown.includes("submittedAt"));
  assert.ok(shown.includes("destAddr"));
  assert.ok(shown.includes("outcome"));
});

test("turning every box off still leaves a table worth looking at", () => {
  //an empty table reads as "no messages", which is a different and much more alarming answer than
  //"no columns" -- and it is the one a customer would report as an outage. The locks are what make
  //that unreachable, so this is the floor rather than an error case
  const nothing: ColumnChoice = { v: 1, on: [], off: MIS_COLUMNS.map((c) => c.id) };

  assert.deepEqual(ids(nothing), ["submittedAt", "destAddr", "outcome"]);
});

test("a column added upstream later still appears for someone who has used the chooser", () => {
  //the property the on/off storage shape exists for. Somebody who once ticked a box has an explicit
  //record of THAT decision and nothing else, so a new default-on column is not silently withheld
  const oldChoice: ColumnChoice = { v: 1, on: ["mcc"], off: ["sourceAddr"] };
  const shown = ids(oldChoice);

  assert.ok(shown.includes("mcc"), "explicitly on");
  assert.ok(!shown.includes("sourceAddr"), "explicitly off");
  assert.ok(shown.includes("gatewayMsgId"), "never decided, so it falls back to its own default");
});

test("order comes from the catalogue, never from the order boxes were ticked", () => {
  //two people who chose the same columns must be looking at the same table
  const a: ColumnChoice = { v: 1, on: ["errCode", "product"], off: [] };
  const b: ColumnChoice = { v: 1, on: ["product", "errCode"], off: [] };

  assert.deepEqual(ids(a), ids(b));
  const shown = ids(a);
  assert.ok(shown.indexOf("product") < shown.indexOf("errCode"), "Route group precedes Outcome");
});

test("exactly three columns are locked, and each of them exists", () => {
  const locked = MIS_COLUMNS.filter((c) => isLockedMisColumn(c.id)).map((c) => c.id);

  //a locked id that matched no column would be a lock that silently does nothing
  assert.deepEqual(locked, ["submittedAt", "destAddr", "outcome"]);
});

test("the catalogue offers nothing the customer API would refuse to send", () => {
  //the one security-shaped assertion here. MIS_COLUMNS is derived from CUSTOMER_CDR_COLUMNS, so
  //this holds by construction -- and it is worth pinning, because the cheap way to break it is to
  //stop deriving and start listing
  //`vendorErrCode` joins the buy-side list for the same reason `vendor` is on it: a carrier's own
  //failure numbering identifies who we bought the route from, and the customer already has the
  //code that was meant for them. It is on the operator catalogue only, and this pins that
  for (const forbidden of [
    "cost", "costRate", "costUnits", "margin", "marginPct", "vendor", "vendorErrCode",
  ]) {
    assert.ok(
      !MIS_COLUMNS.some((c) => c.id === forbidden),
      `${forbidden} is our buy side and must not be offered to a customer`
    );
  }
});

test("every default is a real column", () => {
  for (const id of MIS_DEFAULT_COLUMN_IDS) {
    assert.ok(MIS_COLUMNS.some((c) => c.id === id), `${id} is not in the catalogue`);
  }
});
