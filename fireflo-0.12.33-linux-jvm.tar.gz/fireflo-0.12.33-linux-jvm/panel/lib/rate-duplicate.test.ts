import { strict as assert } from "node:assert";
import { test } from "node:test";
import { scopeWarnings, type RateRuleInput, type ScopeInput } from "./rate-types.ts";

/**
 * The "matches exactly what an earlier rule matches" warning, and the shape it must not fire on.
 *
 * A filter's conditions are ANDed with the rule's own at load time, so two rules differing only by
 * which filter they carry match different messages. Calling one of them unreachable is not a
 * harmless false positive: it is advice to delete a live per-country tariff.
 */

function rule(over: Partial<RateRuleInput>): RateRuleInput {
  return {
    id: null,
    amount: "1.0000",
    product: "sms",
    currency: null,
    label: null,
    enabled: true,
    conditions: [],
    filters: [],
    ...over,
  };
}

function duplicates(...rules: RateRuleInput[]): string[] {
  const input = { scope: "acct-1001", rules } as ScopeInput;
  return scopeWarnings(input).filter((w) => w.includes("matches exactly what an earlier rule"));
}

test("two rules alike but for their filters are both reachable", () => {
  //the per-country tariff: same product, same amount, one filter each
  const warnings = duplicates(
    rule({ filters: ["india"] }),
    rule({ filters: ["australia"] })
  );
  assert.deepEqual(warnings, []);
});

test("a rule carrying a filter does not duplicate the bare rule it is otherwise identical to", () => {
  assert.deepEqual(duplicates(rule({ filters: [] }), rule({ filters: ["india"] })), []);
});

test("genuinely identical rules are still called out", () => {
  const warnings = duplicates(rule({ filters: ["india"] }), rule({ filters: ["india"] }));
  assert.equal(warnings.length, 1);
  assert.match(warnings[0], /Rule 2/);
});

test("the same filters in a different order are the same rule", () => {
  //both expand to the same ANDed set of conditions, so the second really is unreachable
  const warnings = duplicates(
    rule({ filters: ["india", "premium"] }),
    rule({ filters: ["premium", "india"] })
  );
  assert.equal(warnings.length, 1);
});

test("filters do not paper over a difference in conditions", () => {
  const conditions = [{ field: "to", operator: "startsWith", value: "61", negate: false }];
  assert.deepEqual(duplicates(rule({ conditions }), rule({ filters: ["australia"] })), []);
});

test("identical bare rules are still duplicates, filters or no filters", () => {
  const warnings = duplicates(rule({}), rule({}));
  assert.equal(warnings.length, 1);
});
