import { ADMIN_ROLE, CUSTOMER_ROLE, OPERATOR_ROLE } from "@/lib/roles";

/**
 * The shapes a user takes between the database, the API and the browser.
 *
 * <p>A leaf module (it imports only `roles.ts`, itself a leaf), so client components can type
 * against it without pulling `pg`. {@link PublicUser} is the only shape that ever leaves the server
 * and it has no `password_hash` field to leak.
 */

export type Role = typeof ADMIN_ROLE | typeof OPERATOR_ROLE | typeof CUSTOMER_ROLE;

export const ROLES: readonly Role[] = [ADMIN_ROLE, OPERATOR_ROLE, CUSTOMER_ROLE];

export function isRole(value: unknown): value is Role {
  return typeof value === "string" && (ROLES as readonly string[]).includes(value);
}

/** The roles the operator panel admits. `customer` signs in at the portal, never here. */
export const PANEL_ROLES: readonly Role[] = [ADMIN_ROLE, OPERATOR_ROLE];

export interface PublicUser {
  id: number;
  email: string;
  role: Role;
  /** Null for admins and operators. */
  accountId: string | null;
  enabled: boolean;
  /** Whether a password is set. A customer without one signs in by emailed link only. */
  hasPassword: boolean;
  createdAt: string;
  updatedAt: string;
  lastLoginAt: string | null;
}

export interface NewUserInput {
  email: string;
  role: Role;
  accountId?: string | null;
  /** Optional for customers, who may sign in by link; required for panel roles. */
  password?: string | null;
}

/** Trimmed; a bare name gains `@control.local`, the suffix `fireflo user` and the old env operator both used. */
export function normaliseEmail(raw: string): string | null {
  const email = raw.trim();
  if (!email) {
    return null;
  }
  const withDomain = email.includes("@") ? email : `${email}@control.local`;
  const at = withDomain.indexOf("@");
  if (at < 1 || at !== withDomain.lastIndexOf("@") || withDomain.endsWith("@") || /\s/.test(withDomain)) {
    return null;
  }
  return withDomain;
}

/** The one sentence a bad create is refused with, or null. Password strength is judged separately. */
export function validateNewUser(input: NewUserInput): string | null {
  if (!normaliseEmail(input.email)) {
    return "Enter an email address.";
  }
  if (!isRole(input.role)) {
    return "Role must be admin, operator or customer.";
  }
  const account = input.accountId?.trim() || null;
  if (input.role === CUSTOMER_ROLE && !account) {
    return "A customer belongs to an account.";
  }
  if (input.role !== CUSTOMER_ROLE && account) {
    return `An ${input.role} has no account.`;
  }
  if (input.role !== CUSTOMER_ROLE && !input.password) {
    return "Admins and operators need a password. Only customers may sign in by link alone.";
  }
  return null;
}
