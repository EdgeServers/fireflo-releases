import { test } from "node:test";
import assert from "node:assert/strict";
import {
  emptyPreprocessor,
  joinOnError,
  runnerFor,
  splitOnError,
  validatePreprocessor,
} from "./preprocessor-types.ts";
import { describeRouteRule, routeTableWarnings, targetKind, type RouteRule, type RouteTableInput } from "./routing-types.ts";

function rule(over: Partial<RouteRule> = {}): RouteRule {
  return { id: null, target: "vendor1", copied: false, label: null, enabled: true, conditions: [], filters: [], ...over };
}

function table(rules: RouteRule[]): RouteTableInput {
  return { name: "MESSAGE", targetFunction: "NORMAL", enabled: true, rules };
}

const WORKERS = [{ name: "vendor1", type: "smppclient", enabled: true }];

test("the file is a name in the preprocessor directory, never a path or a command", () => {
  const ok = { ...emptyPreprocessor(), name: "dnd", run: "dnd.py" };
  assert.equal(validatePreprocessor(ok), null);
  for (const run of ["../dnd.py", "/usr/bin/python3", "sub/dnd.py", ".hidden"]) {
    assert.notEqual(validatePreprocessor({ ...ok, run }), null, run);
  }
  assert.notEqual(validatePreprocessor({ ...ok, fields: ["to", "password"] }), null);
});

test("on_error round-trips through the editor's two controls", () => {
  assert.deepEqual(splitOnError("reject:DND"), { kind: "reject", status: "DND" });
  assert.equal(joinOnError("reject", "DND"), "reject:DND");
  assert.equal(joinOnError("reject", ""), "reject");
  assert.equal(joinOnError("hold", "ignored"), "hold");
});

test("the extension decides what runs it", () => {
  assert.equal(runnerFor("dnd.py"), "python3");
  assert.equal(runnerFor("Score.java"), "java (single-file source)");
  assert.equal(runnerFor("score.jar"), "java -jar");
});

test("an @target is a preprocessor, and a catch-all one hides nothing below it", () => {
  assert.equal(targetKind("@dnd", [], WORKERS), "preprocessor");
  const warnings = routeTableWarnings(table([rule({ target: "@audit" }), rule()]), ["default"], WORKERS);
  assert.deepEqual(warnings, [], "it always carries on, so the vendor rule below is reached");
});

test("a table whose only catch-all is a preprocessor still has no catch-all", () => {
  const warnings = routeTableWarnings(
    table([rule({ conditions: [{ field: "to", operator: "startsWith", value: "91", negate: false }] }), rule({ target: "@audit" })]),
    ["default"], WORKERS);
  assert.ok(warnings.some((w) => w.includes("No catch-all")));
});

test("the rule reads as handing over and carrying on", () => {
  assert.match(describeRouteRule(rule({ target: "@dnd" }), "NORMAL", [], WORKERS), /dnd preprocessor, then carries on/);
});
