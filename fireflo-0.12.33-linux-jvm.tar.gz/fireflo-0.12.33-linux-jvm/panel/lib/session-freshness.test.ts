import { test } from "node:test";
import assert from "node:assert/strict";
import { passwordStamp, sessionPredatesPasswordChange } from "./session-freshness.ts";

/**
 * The password-change comparison `requireOperator` and `requireCustomer` make on every request
 * (CP-S4). Written against the token shapes that actually exist: one from before the column, one
 * from before the change, one from after.
 */

const changed = new Date("2026-10-15T10:00:00.000Z");

test("a row that was never stamped admits any token, stamped or not", () => {
  assert.equal(sessionPredatesPasswordChange(null, null), false);
  assert.equal(sessionPredatesPasswordChange(undefined, null), false);
  assert.equal(sessionPredatesPasswordChange(changed.getTime(), null), false);
});

test("a token with no stamp is refused once the row has one", () => {
  assert.equal(
    sessionPredatesPasswordChange(null, changed),
    true,
    "a session from before the upgrade predates any change made after it"
  );
  assert.equal(sessionPredatesPasswordChange(undefined, changed), true);
});

test("a token minted before the change is refused", () => {
  assert.equal(sessionPredatesPasswordChange(changed.getTime() - 1, changed), true);
  assert.equal(sessionPredatesPasswordChange(new Date("2026-10-14T00:00:00Z").getTime(), changed), true);
});

test("a token minted at or after the change is admitted", () => {
  assert.equal(sessionPredatesPasswordChange(changed.getTime(), changed), false, "the sign-in right after the reset");
  assert.equal(sessionPredatesPasswordChange(changed.getTime() + 1, changed), false);
});

test("the row value may arrive as a Date, an ISO string or a number", () => {
  const ms = changed.getTime();
  assert.equal(passwordStamp(changed), ms);
  assert.equal(passwordStamp(changed.toISOString()), ms);
  assert.equal(passwordStamp(ms), ms);
  assert.equal(passwordStamp(null), null);
  assert.equal(passwordStamp(""), null);
  assert.equal(passwordStamp("not a date"), null);
  assert.equal(sessionPredatesPasswordChange(ms, changed.toISOString()), false);
});

test("fractional milliseconds on either side cannot make an equal pair unequal", () => {
  assert.equal(sessionPredatesPasswordChange(passwordStamp(changed.getTime() + 0.6), changed), false);
});
