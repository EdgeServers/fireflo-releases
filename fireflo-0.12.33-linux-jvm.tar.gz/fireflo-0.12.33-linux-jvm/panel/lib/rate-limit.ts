/**
 * A fixed-window counter held in this process.
 *
 * <p>For the case where the work being limited is expensive and the limit does not need to be
 * exact: refusing early costs one map lookup, and the thing being protected is a database round
 * trip or a call to the gateway.
 *
 * <h2>What it is not</h2>
 *
 * <p><strong>Not a distributed quota.</strong> Two panel instances behind a load balancer allow the
 * limit twice, and a restart forgets everything. Both are acceptable for the job — bounding a flood
 * to something a database can absorb — and neither is acceptable for a quota somebody is billed
 * against, which is why nothing here is used for one.
 *
 * <p><strong>Not a sliding window.</strong> Twice the limit can pass across a window boundary. That
 * is the standard trade for a counter this cheap, and it is stated rather than discovered.
 *
 * <p>Two older copies of this shape exist inline — `allowAttempt` in `lib/playground.ts` and the
 * dedup map in `lib/require-customer.ts`. They are deliberately left alone here: moving them is a
 * behaviour change to paths that are working, and belongs in its own commit.
 */
export interface Limiter {
  /**
   * @return false when this key has spent its allowance, in which case the caller must refuse
   *     without doing the work the limit exists to protect
   */
  allow(key: string): boolean;
}

/**
 * @param max requests allowed per key per window
 * @param windowMs how long a window lasts
 * @param maxKeys the point at which the whole map is dropped rather than swept. Cleared wholesale
 *     for the reason `require-customer.ts` gives about its own map: a bounded map that cannot leak
 *     beats an exact one that can. The cost of clearing is that everybody gets a fresh allowance,
 *     which is the safe direction to be wrong in
 */
export function limiter(max: number, windowMs: number, maxKeys = 10_000): Limiter {
  const seen = new Map<string, { count: number; until: number }>();
  return {
    allow(key: string): boolean {
      const now = Date.now();
      const found = seen.get(key);
      if (!found || now > found.until) {
        if (seen.size > maxKeys) {
          seen.clear();
        }
        seen.set(key, { count: 1, until: now + windowMs });
        //`1 <= max`, not a bare true: a limiter configured to allow nothing must allow nothing,
        //and returning true here let exactly one request through every window
        return 1 <= max;
      }
      found.count += 1;
      return found.count <= max;
    },
  };
}
