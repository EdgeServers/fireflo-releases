/**
 * What counts as an acceptable password, decided once for the form and the API alike.
 *
 * <p>A leaf module on purpose, like `lib/roles.ts`: it imports nothing, so the strength meter in the
 * browser and the check in every route that accepts a password run the identical function, and
 * `password-policy.test.ts` runs on Node's own runner. A meter that says "strong" for a password the
 * server then refuses is worse than no meter.
 *
 * <h2>What it measures</h2>
 *
 * <p>Length first, because length is what resists a guess; then variety, then the things that make a
 * long password short in practice -- a word from the list everyone tries first, the user's own
 * address, a run of one character, a keyboard walk. The score is 0 to 4 and the server refuses below
 * {@link MIN_SCORE}. It is an estimate, not entropy, and says so in its name.
 */

export const MIN_LENGTH = 12;
/** `pbkdf2` happily hashes a megabyte; nothing else about a password that long is a good idea. */
export const MAX_LENGTH = 1024;
/** The lowest score the server accepts. */
export const MIN_SCORE = 2;

export type Strength = 0 | 1 | 2 | 3 | 4;

export interface PasswordVerdict {
  /** 0 unusable … 4 strong. */
  score: Strength;
  /** One short phrase for the meter. */
  label: "Too weak" | "Weak" | "Fair" | "Good" | "Strong";
  /** Why it is not stronger, for the form. Empty when nothing is wrong. */
  warnings: string[];
  /** Whether the server will take it. */
  acceptable: boolean;
}

const LABELS: PasswordVerdict["label"][] = ["Too weak", "Weak", "Fair", "Good", "Strong"];

/** The handful that appear at the top of every breach list. Lower-cased; matched as a whole or a stem. */
const COMMON = [
  "password", "passw0rd", "letmein", "welcome", "qwerty", "iloveyou", "admin", "administrator",
  "changeme", "monkey", "dragon", "sunshine", "princess", "football", "baseball", "superman",
  "trustno1", "master", "hello", "freedom", "whatever", "fireflo", "operator", "secret", "abc123",
  "123456", "12345678", "1234567890",
];

const WALKS = ["qwertyuiop", "asdfghjkl", "zxcvbnm", "1234567890", "0987654321", "abcdefghijklmnopqrstuvwxyz"];

/**
 * @param password what was typed
 * @param email the account it is for, so the address and its local part are refused as passwords
 */
export function assessPassword(password: string, email?: string | null): PasswordVerdict {
  const warnings: string[] = [];
  if (password.length === 0) {
    return { score: 0, label: LABELS[0], warnings: [], acceptable: false };
  }
  if (password.length > MAX_LENGTH) {
    return { score: 0, label: LABELS[0], warnings: [`Longer than ${MAX_LENGTH} characters.`], acceptable: false };
  }

  const lower = password.toLowerCase();
  let score = 0;

  //length is the backbone: 12 is the floor, and 16, 20 and 24 each earn one more. A four-word
  //passphrase reaches the top on length alone, which is the behaviour worth rewarding
  if (password.length >= MIN_LENGTH) score += 1;
  if (password.length >= 16) score += 1;
  if (password.length >= 20) score += 1;
  if (password.length >= 24) score += 1;
  if (password.length < MIN_LENGTH) warnings.push(`Use at least ${MIN_LENGTH} characters.`);

  //variety: four classes, one point for three of them
  const classes = [/[a-z]/, /[A-Z]/, /[0-9]/, /[^A-Za-z0-9]/].filter((re) => re.test(password)).length;
  if (classes >= 3) score += 1;
  else if (password.length < 20) warnings.push("Mix letters, capitals, digits or symbols.");

  //the penalties: each one takes a point, and some make it unusable outright
  const stripped = lower.replace(/[^a-z0-9]/g, "");
  //a top-list word with a few digits bolted on is still the top-list word: Password12345! is the
  //first thing tried after password
  const commonStem = COMMON.some((w) => {
    if (!stripped.startsWith(w)) return false;
    const rest = stripped.slice(w.length);
    return rest.length <= 6 && /^[0-9]*$/.test(rest);
  });
  if (commonStem) {
    warnings.push("That is one of the most common passwords.");
    score = 0;
  }
  if (email) {
    const address = email.trim().toLowerCase();
    const local = address.split("@")[0] ?? "";
    if (lower === address || (local.length >= 4 && lower.includes(local))) {
      warnings.push("Do not use your email address.");
      score = Math.min(score, 1);
    }
  }
  if (/^(.)\1+$/.test(password)) {
    warnings.push("One repeated character.");
    score = 0;
  } else if (/(.)\1{3,}/.test(password)) {
    warnings.push("Avoid long runs of one character.");
    score = Math.max(0, score - 1);
  }
  if (WALKS.some((w) => w.includes(stripped) && stripped.length >= 6) || hasWalk(stripped)) {
    warnings.push("Avoid keyboard and alphabet runs.");
    score = Math.max(0, score - 1);
  }
  if (/^(..+)\1+$/.test(lower)) {
    warnings.push("A short pattern repeated is still short.");
    score = Math.max(0, score - 1);
  }

  if (password.length < MIN_LENGTH) score = Math.min(score, 1);
  const clamped = Math.max(0, Math.min(4, score)) as Strength;
  return {
    score: clamped,
    label: LABELS[clamped],
    warnings,
    acceptable: password.length >= MIN_LENGTH && password.length <= MAX_LENGTH && clamped >= MIN_SCORE,
  };
}

/** Six or more consecutive characters from a keyboard row or the alphabet, anywhere in the string. */
function hasWalk(s: string): boolean {
  if (s.length < 6) return false;
  for (let i = 0; i + 6 <= s.length; i++) {
    const piece = s.slice(i, i + 6);
    if (WALKS.some((w) => w.includes(piece) || [...w].reverse().join("").includes(piece))) return true;
  }
  return false;
}

/**
 * The one sentence the server answers with, or null when the password is fine.
 *
 * <p>Routes call this; the form shows the meter. Both come from {@link assessPassword}.
 */
export function passwordProblem(password: string, email?: string | null): string | null {
  const v = assessPassword(password, email);
  if (v.acceptable) return null;
  if (password.length < MIN_LENGTH) return `The password needs at least ${MIN_LENGTH} characters.`;
  if (password.length > MAX_LENGTH) return `The password is longer than ${MAX_LENGTH} characters.`;
  return `That password is too easy to guess. ${v.warnings[0] ?? ""}`.trim();
}
