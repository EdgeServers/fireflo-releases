import { NextRequest, NextResponse } from "next/server";
import { logOperatorEvent, type OperatorEvent } from "@/lib/access-log";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { callOps, type OpsCall } from "@/lib/gateway-ops";
import { NotOperatorError, requireAdmin, requireOperator, type OperatorIdentity } from "@/lib/require-operator";

/**
 * The panel's half of the preprocessor workbench: who may call what, and the audit line.
 *
 * <p>Reading code needs an operator. Checking, test-running, saving and restoring need an admin --
 * the gateway enforces the same line with its admin token, so this is the panel saying no before
 * the gateway has to, not the only thing saying it.
 */
export async function asOperator(): Promise<OperatorIdentity | NextResponse> {
  try {
    return await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) return NextResponse.json({ error: "Not found" }, { status: 404 });
    throw err;
  }
}

export async function asAdmin(): Promise<OperatorIdentity | NextResponse> {
  try {
    return await requireAdmin();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Only an admin can change or run preprocessor code." }, { status: 403 });
    }
    throw err;
  }
}

/** The gateway's own status and sentence come through: "changed since you opened it" is the point. */
export function gateway(call: OpsCall): Promise<NextResponse> {
  return callOps({ passErrors: true, ...call });
}

/** Records a code change after the gateway accepted it. Never the code -- the file and checksums. */
export async function auditCodeChange(
  req: NextRequest,
  who: OperatorIdentity,
  event: Extract<OperatorEvent, "preprocessor_code_saved" | "preprocessor_code_restored">,
  res: NextResponse,
  detail: Record<string, unknown>
): Promise<NextResponse> {
  if (res.ok) {
    const body = await res.clone().json().catch(() => null);
    if (body?.data?.changed !== false) {
      void logOperatorEvent({
        event,
        actor: who.name,
        userId: who.userId,
        ip: clientIp(req),
        userAgent: clientUserAgent(req),
        detail: { ...detail, sha: body?.data?.sha ?? null },
      });
    }
  }
  return res;
}

export async function jsonBody(req: NextRequest): Promise<Record<string, unknown> | null> {
  try {
    return (await req.json()) as Record<string, unknown>;
  } catch {
    return null;
  }
}
