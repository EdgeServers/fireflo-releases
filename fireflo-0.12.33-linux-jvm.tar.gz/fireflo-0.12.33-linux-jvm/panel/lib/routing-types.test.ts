import { test } from "node:test";
import assert from "node:assert/strict";
import {
  buildDlrReturnRule,
  buildMoRouteRule,
  buildMoRouteRuleDraft,
  buildMtRules,
  defaultRoutingPlan,
  isRoutingCatchAll,
  missingDlrReturnRules,
  missingMoRouteRules,
  receiptRoutingProblem,
  missingMtTypes,
  routeTableWarnings,
  ruleDirection,
  targetKind,
  validateRouteTable,
  MT_MESSAGE_TYPES,
  type RouteRule,
  type RouteTableInput,
} from "./routing-types.ts";
import type { Worker } from "./worker-types.ts";

/**
 * The two ways a routing table silently sends nothing.
 *
 * <p>Both are invisible at runtime, which is what makes them worth an editor warning rather than a
 * log line: a NORMAL table stops at the first match, so a message that matches nothing is not
 * refused and not logged — it is requeued twenty times and dropped, with the customer already
 * holding an `ESME_ROK` for it. The rates page has checked its own version of this for a while;
 * routing never has.
 */

function rule(over: Partial<RouteRule> = {}): RouteRule {
  return {
    id: null, target: "vendor1", copied: false, label: null, enabled: true,
    conditions: [], filters: [], ...over,
  };
}

function table(rules: RouteRule[], over: Partial<RouteTableInput> = {}): RouteTableInput {
  //deliberately NOT "default": that name carries entry-point semantics the gateway enforces, and
  //the checks below are about an ordinary business table. The default table gets its own tests
  return { name: "MESSAGE", targetFunction: "NORMAL", enabled: true, rules, ...over };
}

const WORKERS = [{ name: "vendor1", type: "smppclient", enabled: true }];

const CONDITION = { field: "to", operator: "startsWith", value: "91", negate: false };

test("a table whose every rule is narrowed warns that nothing catches the rest", () => {
  const warnings = routeTableWarnings(
    table([rule({ conditions: [CONDITION] })]), ["default"], WORKERS);

  assert.ok(warnings.some((w) => w.includes("No catch-all")));
  assert.ok(warnings.some((w) => w.includes("dropped after 20 attempts")),
    "the consequence is the point -- 'no catch-all' alone reads as a style note");
});

test("a catch-all last is the correct shape and warns about nothing", () => {
  const warnings = routeTableWarnings(
    table([rule({ conditions: [CONDITION] }), rule()]), ["default"], WORKERS);

  assert.deepEqual(warnings, [], "a warning on a correct table is a warning nobody reads");
});

test("a catch-all above other rules says how many are dead", () => {
  const warnings = routeTableWarnings(
    table([rule(), rule({ conditions: [CONDITION] }), rule({ conditions: [CONDITION] })]),
    ["default"], WORKERS);

  const dead = warnings.find((w) => w.includes("never be reached"));
  assert.ok(dead);
  assert.match(dead, /Rule 1 matches everything/);
  assert.match(dead, /2 rules/, "counted, so it is obvious how much is dead");
});

test("a COPIED catch-all kills nothing below it", () => {
  //copy-and-continue adds its target and keeps scanning. Warning here would be simply wrong, and
  //this is the case that makes the check need `copied` rather than just an index
  const warnings = routeTableWarnings(
    table([rule({ copied: true }), rule({ conditions: [CONDITION] })]), ["default"], WORKERS);

  assert.ok(!warnings.some((w) => w.includes("never be reached")));
  assert.ok(!warnings.some((w) => w.includes("No catch-all")), "it still catches everything");
});

test("a rule narrowed only by a filter is not a catch-all", () => {
  //the rule the rates side already records: filters count. Calling this a catch-all is how a table
  //with no real fallback comes to look like it has one
  assert.equal(isRoutingCatchAll(rule({ filters: ["indian-mobiles"] })), false);
  assert.equal(isRoutingCatchAll(rule()), true);

  const warnings = routeTableWarnings(
    table([rule({ filters: ["indian-mobiles"] })]), ["default"], WORKERS);
  assert.ok(warnings.some((w) => w.includes("No catch-all")));
});

test("an LCR table is not held to any of this", () => {
  //the whole table is scanned and the cheapest wins, so first-match ordering does not apply
  const warnings = routeTableWarnings(
    table([rule({ conditions: [CONDITION] })], { targetFunction: "LCR" }), ["default"], WORKERS);

  assert.ok(!warnings.some((w) => w.includes("catch-all")));
});

test("disabled rules are not counted as the catch-all", () => {
  const warnings = routeTableWarnings(
    table([rule({ conditions: [CONDITION] }), rule({ enabled: false })]), ["default"], WORKERS);

  assert.ok(warnings.some((w) => w.includes("No catch-all")),
    "switching the catch-all off is exactly how somebody removes the fallback by accident");
});

/**
 * A target that is switched off, which the page could always have known and never showed.
 */

test("a disabled worker is its own state, not 'not recognised'", () => {
  assert.equal(targetKind("vendor1", [], [{ name: "vendor1", type: "smppclient", enabled: false }]),
    "disabled");
  assert.equal(targetKind("vendor1", [], WORKERS), "worker");
  assert.equal(targetKind("nobody", [], WORKERS), "unknown");
});

test("a worker with no enabled flag is treated as enabled", () => {
  //absent is not false: a caller with no worker state to hand must not make every rule look broken
  assert.equal(targetKind("vendor1", [], [{ name: "vendor1", type: "smppclient" }]), "worker");
});

test("the disabled warning is certain where the unrecognised one hedges", () => {
  const off = routeTableWarnings(
    table([rule()]), ["default"], [{ name: "vendor1", type: "smppclient", enabled: false }]);
  assert.ok(off.some((w) => w.includes("switched off")));
  assert.ok(off.some((w) => w.includes("certain")), "unlike 'unless it is one this panel cannot see'");

  const missing = routeTableWarnings(table([rule({ target: "nobody" })]), ["default"], WORKERS);
  assert.ok(missing.some((w) => w.includes("matches no routing table")));
});

test("a regex in a literal operator now warns on the routing page too", () => {
  //it warned on /filters and on the rate scope form and nowhere here, so a routing condition
  //written this way matched nothing and said so nowhere
  const warnings = routeTableWarnings(
    table([
      rule({ conditions: [{ field: "to", operator: "startsWith", value: "^91[6-9]", negate: false }] }),
      rule(),
    ]),
    ["default"], WORKERS);

  assert.ok(warnings.some((w) => w.includes("regular expression")));
});

test("the same bad condition on two rules is reported once", () => {
  const twice = { field: "to", operator: "startsWith", value: "^91[6-9]", negate: false };
  const warnings = routeTableWarnings(
    table([rule({ conditions: [twice] }), rule({ conditions: [twice] }), rule()]),
    ["default"], WORKERS);

  assert.equal(warnings.filter((w) => w.includes("regular expression")).length, 1);
});

test("a numeric operator on a text field is refused before it can be saved", () => {
  //the loop this closes: the panel saved it, the gateway then refused the WHOLE table set and kept
  //the previous one, so the page showed one thing and the gateway routed another.
  //`from:==:MyBrand` is the exact shape conf.example/routingTable.conf warns about
  const bad = validateRouteTable({
    name: "default",
    targetFunction: "NORMAL",
    rules: [{
      target: "vendor1",
      conditions: [{ field: "from", operator: "==", value: "MyBrand", negate: false }],
      filters: [],
    }],
  } as Parameters<typeof validateRouteTable>[0]);

  assert.ok(bad, "this must not save");
  assert.match(bad ?? "", /routing table/, "it must name what the gateway refuses, not the rate table");
  assert.match(bad ?? "", /compares numbers/);
});

test("a sound rule still saves", () => {
  //the anti-vacuity half: a validator that refuses everything is not a validator
  const ok = validateRouteTable({
    name: "default",
    targetFunction: "NORMAL",
    rules: [{
      target: "vendor1",
      conditions: [{ field: "product", operator: "equals", value: "in-otp", negate: false }],
      filters: [],
    }],
  } as Parameters<typeof validateRouteTable>[0]);

  assert.equal(ok, null);
});

test("a malformed rule from the API is a bad request, not a crash", () => {
  //app/api/control/routing/route.ts accepts `raw.rules` on an Array.isArray check alone, so the
  //elements are attacker-shaped. Before this, a rule with no `conditions` threw inside the loop and
  //the operator saw a 500 -- indistinguishable from the panel being down
  const shapes = [
    { target: "vendor1" },
    { target: "vendor1", conditions: [{ field: "product", operator: "equals" }] },
    { conditions: [] },
  ];

  for (const rule of shapes) {
    const table = {
      name: "t", targetFunction: "NORMAL" as const, label: null, enabled: true,
      rules: [rule as never],
    };
    assert.doesNotThrow(() => validateRouteTable(table), `${JSON.stringify(rule)} threw`);
    assert.ok(validateRouteTable(table), `${JSON.stringify(rule)} was accepted`);
  }
});

/**
 * Default routing — the incident this exists to catch: a delivery receipt for an SMPP-ingress
 * message has no rule sending it back to its own listener, so it burns twenty routing attempts and
 * is dropped as `maxAttempts`. The gateway's own shipped example carries the rule this detection is
 * checking for: `smppserver.smpp:type:==:18`.
 */

function worker(over: Partial<Worker> = {}): Worker {
  return { name: "smpp", type: "smppserver", enabled: true, label: null, properties: [], ...over };
}

const DLR_CONDITION = { field: "type", operator: "==", value: "18", negate: false };
//no `type` condition, and that absence is the point: an inbound MO carries type 0 for GSM-7 and
//type 11 for UCS-2, so a rule narrowed by type silently drops every Unicode MO into the outbound
//lane, where it is submitted back out to a vendor as charged traffic
const MO_CONDITIONS = [
  { field: "ingateway", operator: "equals", value: "smppclient.billbasket", negate: false },
];
const MO_SHARED_CONDITION = {
  field: "ingateway", operator: "startsWith", value: "smppclient.", negate: false,
};

test("a listener with no return rule at all is reported missing", () => {
  const gaps = missingDlrReturnRules([table([])], [worker()]);

  assert.equal(gaps.length, 1);
  assert.deepEqual(gaps[0], { kind: "dlr-return", workerName: "smpp", workerFullName: "smppserver.smpp" });
});

test("the shipped example's own rule satisfies the check", () => {
  const gaps = missingDlrReturnRules(
    [table([rule({ target: "smppserver.smpp", conditions: [DLR_CONDITION] })])],
    [worker()]
  );

  assert.equal(gaps.length, 0);
});

test("a disabled return rule still counts as missing -- the gateway never sees it", () => {
  const gaps = missingDlrReturnRules(
    [table([rule({ target: "smppserver.smpp", conditions: [DLR_CONDITION], enabled: false })])],
    [worker()]
  );

  assert.equal(gaps.length, 1);
});

test("a rule pointed at the wrong listener does not satisfy a different one", () => {
  const gaps = missingDlrReturnRules(
    [table([rule({ target: "smppserver.other", conditions: [DLR_CONDITION] })])],
    [worker({ name: "smpp" })]
  );

  assert.equal(gaps.length, 1, "smpp's own rule is still missing");
});

test("a second, unrelated listener is checked and reported independently", () => {
  //qualified, as a two-listener gateway needs: an unqualified rule would cover neither
  const gaps = missingDlrReturnRules(
    [table([rule({ target: "smppserver.smpp", conditions: [DLR_CONDITION,
      { field: "ingateway", operator: "equals", value: "smppserver.smpp", negate: false }] })])],
    [worker({ name: "smpp" }), worker({ name: "reseller1" })]
  );

  assert.equal(gaps.length, 1);
  assert.equal(gaps[0].workerName, "reseller1");
});

test("with two listeners, an unqualified receipt rule does not cover its listener", () => {
  const gaps = missingDlrReturnRules(
    [table([rule({ target: "smppserver.smpp", conditions: [DLR_CONDITION] })])],
    [worker({ name: "smpp" }), worker({ name: "smpp2" })]
  );
  //it takes both listeners' receipts, so both count as missing until it is narrowed
  assert.deepEqual(gaps.map((g) => g.workerName), ["smpp", "smpp2"]);
});

test("rebuild narrows the shipped receipt rule in place and adds the second listener's", () => {
  const original = rule({ id: 7, target: "smppserver.smpp", conditions: [DLR_CONDITION] });
  const plan = defaultRoutingPlan(
    [table([original], { name: "default" })],
    [worker({ name: "smpp" }), worker({ name: "smpp2" })],
    [],
    { mtTarget: "", moTarget: "" }
  );
  const receipts = plan.table.rules.filter((r) => r.conditions.some((c) => c.value === "18"));
  assert.equal(receipts.length, 2);
  //the original keeps its id, now narrowed to its own listener
  assert.equal(receipts[0].id, 7);
  assert.deepEqual(receipts[0].conditions.map((c) => `${c.field}=${c.value}`), ["type=18", "ingateway=smppserver.smpp"]);
  assert.equal(receipts[1].target, "smppserver.smpp2");
  assert.deepEqual(receipts[1].conditions.map((c) => `${c.field}=${c.value}`), ["type=18", "ingateway=smppserver.smpp2"]);
  assert.ok(plan.changes.some((c) => c.startsWith("Narrows the receipt rule for smppserver.smpp")));
  //and running it again changes nothing
  const again = defaultRoutingPlan([plan.table], [worker({ name: "smpp" }), worker({ name: "smpp2" })], [],
    { mtTarget: "", moTarget: "" });
  assert.deepEqual(again.changes, []);
});

test("with one listener the unqualified rule is left exactly as it is", () => {
  const plan = defaultRoutingPlan(
    [table([rule({ id: 7, target: "smppserver.smpp", conditions: [DLR_CONDITION] })], { name: "default" })],
    [worker({ name: "smpp" }), worker({ name: "off", enabled: false })],
    [],
    { mtTarget: "", moTarget: "" }
  );
  assert.deepEqual(plan.changes, []);
  assert.equal(plan.table.rules[0].conditions.length, 1);
});

test("mo.route off means no rule is needed -- not a warning", () => {
  const vendor = worker({ name: "billbasket", type: "smppclient", properties: [] });

  const gaps = missingMoRouteRules([table([])], [vendor]);

  assert.equal(gaps.length, 0);
});

test("mo.route on with nothing matching it is reported missing", () => {
  const vendor = worker({
    name: "billbasket", type: "smppclient",
    properties: [{ key: "mo.route", value: "true" }],
  });

  const gaps = missingMoRouteRules([table([])], [vendor]);

  assert.equal(gaps.length, 1);
  assert.deepEqual(gaps[0], {
    kind: "mo-route", workerName: "billbasket", workerFullName: "smppclient.billbasket",
  });
});

test("mo.route on and a matching rule present is not reported", () => {
  const vendor = worker({
    name: "billbasket", type: "smppclient",
    properties: [{ key: "mo.route", value: "true" }],
  });

  const gaps = missingMoRouteRules(
    [table([rule({ target: "smppserver.smpp", conditions: MO_CONDITIONS })])],
    [vendor]
  );

  assert.equal(gaps.length, 0);
});

test("a rule missing the ingateway condition does not satisfy the MO check", () => {
  //type==0 alone would catch every vendor's MOs indiscriminately, which is not what "a rule for
  //THIS vendor" means -- the gap must stay reported until both conditions are there
  const vendor = worker({
    name: "billbasket", type: "smppclient",
    properties: [{ key: "mo.route", value: "true" }],
  });

  const gaps = missingMoRouteRules(
    [table([rule({
      target: "smppserver.smpp",
      conditions: [{ field: "type", operator: "==", value: "0", negate: false }],
    })])],
    [vendor]
  );

  assert.equal(gaps.length, 1);
});

test("the value is read case- and whitespace-tolerantly, matching isOn everywhere else", () => {
  const vendor = worker({
    name: "billbasket", type: "smppclient",
    properties: [{ key: "mo.route", value: " True " }],
  });

  assert.equal(missingMoRouteRules([table([])], [vendor]).length, 1);
});

test("buildDlrReturnRule produces exactly what missingDlrReturnRules would then accept", () => {
  const gap = { kind: "dlr-return" as const, workerName: "smpp", workerFullName: "smppserver.smpp" };
  const built = buildDlrReturnRule(gap);

  const gaps = missingDlrReturnRules([table([built])], [worker()]);
  assert.equal(gaps.length, 0, "the built rule must close the gap it was built to close");
  assert.equal(built.label, "system:dlr-return:smpp");
  assert.equal(built.enabled, true);
});

test("buildMoRouteRuleDraft selects on ingateway alone, with an empty target", () => {
  const gap = {
    kind: "mo-route" as const, workerName: "billbasket", workerFullName: "smppclient.billbasket",
  };
  const draft = buildMoRouteRuleDraft(gap);

  assert.equal(draft.target, "", "the target is a business decision, not this function's to make");
  assert.deepEqual(draft.conditions, MO_CONDITIONS);
  assert.ok(!draft.conditions.some((c) => c.field === "type"),
    "a type condition here is what used to leak every Unicode MO into the billed outbound lane");
});

test("ruleDirection reads Receipt, Inbound and Outbound off a rule's own conditions", () => {
  assert.equal(ruleDirection(rule({ conditions: [DLR_CONDITION] })), "receipt");
  assert.equal(ruleDirection(rule({ conditions: [MO_SHARED_CONDITION] })), "inbound");
  assert.equal(ruleDirection(rule({ conditions: MO_CONDITIONS })), "inbound",
    "the per-vendor shape is the same direction as the shared one");
  //the regression this function existed to cause: type 0 is MSG_TEXT, which is what an ordinary
  //outbound message carries. Reading type first labelled every shipped MESSAGE:type:==:0 "Inbound"
  assert.equal(
    ruleDirection(rule({ conditions: [{ field: "type", operator: "==", value: "0", negate: false }] })),
    "outbound",
    "type 0 is ordinary outbound text -- an MO is told apart by ingateway, not by type"
  );
  assert.equal(
    ruleDirection(rule({
      conditions: [{ field: "product", operator: "equals", value: "otp", negate: false }],
    })),
    "outbound"
  );
  assert.equal(ruleDirection(rule({ conditions: [] })), "outbound", "an ordinary catch-all is outbound");
});

test("ruleDirection still reads the type off a rule qualified by something else", () => {
  //a hand-authored rule combining type==18 with a second condition is unusual but not invalid, and
  //the label answers "which direction", which is still true
  const qualified = rule({
    conditions: [DLR_CONDITION, { field: "account", operator: "equals", value: "acme", negate: false }],
  });

  assert.equal(ruleDirection(qualified), "receipt");
});

/**
 * Recreating default routing after the `default` table is lost.
 *
 * <p>The gateway refuses a routing configuration with no `default` table — `StandardRoutingManager`
 * throws "no default routing table in new targets!" and keeps its last in-memory copy, so the
 * damage is invisible until a restart, at which point nothing routes at all. These cover the three
 * lanes that have to come back, and the ordering between them, which is load-bearing rather than
 * cosmetic.
 */

const MT_TARGET = "MESSAGE";
const MO_TARGET = "smppserver.smpp";

function defaultTable(rules: RouteRule[]): RouteTableInput {
  return table(rules, { name: "default" });
}

function moVendor(name = "billbasket"): Worker {
  return worker({
    name, type: "smppclient", properties: [{ key: "mo.route", value: "true" }],
  });
}

test("the shared MO rule closes every vendor's gap at once", () => {
  const vendors = [moVendor("billbasket"), moVendor("airtel")];
  const shared = buildMoRouteRule(MO_TARGET);

  assert.equal(missingMoRouteRules([defaultTable([shared])], vendors).length, 0);
  assert.equal(shared.label, "system:mo-route");
});

test("a Unicode MO is covered by the shared rule and was not by the old shape", () => {
  //the rule this module used to generate, verbatim
  const legacy = rule({
    target: MO_TARGET,
    conditions: [
      { field: "type", operator: "==", value: "0", negate: false },
      { field: "ingateway", operator: "==", value: "smppclient.billbasket", negate: false },
    ],
  });

  //it still counts as present -- the vendor's GSM-7 MOs really are routed, and reporting it as
  //absent would flag every deployment carrying it
  assert.equal(missingMoRouteRules([defaultTable([legacy])], [moVendor()]).length, 0);

  //but it is called out, because type 11 falls straight past it into the outbound lane
  const warnings = routeTableWarnings(defaultTable([legacy]), [], WORKERS);
  assert.ok(warnings.some((w) => w.includes("only catches the GSM-7 ones")),
    "the narrowing is the whole defect and must be visible on the table it is on");
});

test("a per-vendor MO rule covers its own vendor and not another", () => {
  const scoped = rule({ target: MO_TARGET, conditions: MO_CONDITIONS });
  const gaps = missingMoRouteRules([defaultTable([scoped])], [moVendor(), moVendor("airtel")]);

  assert.equal(gaps.length, 1);
  assert.equal(gaps[0].workerName, "airtel");
});

test("one listener keeps the bare rule; two get the ingateway qualifier", () => {
  const gap = { kind: "dlr-return" as const, workerName: "smpp", workerFullName: "smppserver.smpp" };

  const bare = buildDlrReturnRule(gap);
  assert.equal(bare.conditions.length, 1, "narrowing a single-listener rule would move its metrics key");

  const qualified = buildDlrReturnRule(gap, { qualify: true });
  assert.deepEqual(qualified.conditions[1],
    { field: "ingateway", operator: "equals", value: "smppserver.smpp", negate: false });

  //both shapes must satisfy the check, or upgrading would report every existing rule as missing
  for (const built of [bare, qualified]) {
    assert.equal(missingDlrReturnRules([defaultTable([built])], [worker()]).length, 0);
  }
});

test("missingMtTypes counts an absent table as covering nothing", () => {
  assert.deepEqual(missingMtTypes(undefined), [...MT_MESSAGE_TYPES]);
  assert.deepEqual(missingMtTypes(defaultTable(buildMtRules(MT_TARGET))), []);
});

test("an MO rule does not count as covering the outbound lane", () => {
  //it selects on ingateway, so it takes inbound traffic of the same content type and leaves
  //outbound exactly as uncovered as before
  assert.deepEqual(missingMtTypes(defaultTable([buildMoRouteRule(MO_TARGET)])), [...MT_MESSAGE_TYPES]);
});

test("the default table is not told to add a catch-all, but is told which types have no rule", () => {
  const partial = defaultTable(buildMtRules(MT_TARGET).slice(0, 2));
  const warnings = routeTableWarnings(partial, [MT_TARGET], WORKERS);

  assert.ok(!warnings.some((w) => w.includes("No catch-all")),
    "the shipped entry-point table has none on purpose -- advising one reads as a failed recreate");
  const uncovered = warnings.find((w) => w.includes("No rule for outbound message"));
  assert.ok(uncovered);
  assert.match(uncovered, /11, 14, 17/);
});

test("recreating from nothing produces all three lanes, in an order that works", () => {
  const plan = defaultRoutingPlan([], [worker()], [moVendor()],
    { mtTarget: MT_TARGET, moTarget: MO_TARGET });

  assert.equal(plan.created, true);
  assert.ok(plan.changes[0].includes("Creates the 'default' table"));

  const directions = plan.table.rules.map(ruleDirection);
  assert.deepEqual(directions,
    ["receipt", "inbound", "outbound", "outbound", "outbound", "outbound", "outbound"]);
  //an MO carries the same message type as an outbound message, so an MO rule below the outbound
  //lane never sees one
  assert.ok(directions.indexOf("inbound") < directions.indexOf("outbound"));
  assert.equal(missingMtTypes(plan.table).length, 0);
  assert.equal(missingDlrReturnRules([plan.table], [worker()]).length, 0);
  assert.equal(missingMoRouteRules([plan.table], [moVendor()]).length, 0);
  assert.ok(plan.table.rules.every((r) => r.id === null),
    "generated rules must be inserts, or saveRouteTable's stale-id guard rejects the whole write");
});

test("running it a second time changes nothing", () => {
  const targets = { mtTarget: MT_TARGET, moTarget: MO_TARGET };
  const first = defaultRoutingPlan([], [worker()], [moVendor()], targets);
  const second = defaultRoutingPlan([first.table], [worker()], [moVendor()], targets);

  assert.deepEqual(second.changes, [], "an idempotent action is what makes it safe to offer twice");
  assert.equal(second.created, false);
  assert.equal(second.table.rules.length, first.table.rules.length);
});

test("an operator's own rules survive, keep their ids and keep their relative order", () => {
  const first = rule({ id: 7, target: "vendor1", conditions: [CONDITION], label: "india" });
  const second = rule({ id: 8, target: "vendor2", conditions: [CONDITION], label: "australia" });
  const plan = defaultRoutingPlan([defaultTable([first, second])], [worker()], [],
    { mtTarget: MT_TARGET, moTarget: MO_TARGET });

  const kept = plan.table.rules.filter((r) => r.id !== null);
  assert.deepEqual(kept.map((r) => r.label), ["india", "australia"]);
  assert.deepEqual(kept.map((r) => r.id), [7, 8]);
  assert.deepEqual(kept.map((r) => r.target), ["vendor1", "vendor2"],
    "nothing an operator wrote is retargeted");
});

test("an existing catch-all is moved last rather than left swallowing the new rules", () => {
  const catchAll = rule({ id: 3, target: "vendor1" });
  const plan = defaultRoutingPlan([defaultTable([catchAll])], [worker()], [moVendor()],
    { mtTarget: MT_TARGET, moTarget: MO_TARGET });

  assert.equal(plan.table.rules.at(-1)?.id, 3);
  assert.ok(plan.changes.some((c) => c.includes("Moves the receipt and inbound rules above")));
});

test("a lane with no target chosen is skipped rather than written blank", () => {
  //a rule pointing at "" resolves to nothing and silently sends nowhere, which is worse than the
  //gap it would be closing
  const plan = defaultRoutingPlan([], [worker()], [moVendor()], { mtTarget: "", moTarget: "" });

  assert.deepEqual(plan.table.rules.map(ruleDirection), ["receipt"]);
  assert.ok(plan.table.rules.every((r) => r.target.trim() !== ""));
});

test("no vendor routing MOs means no MO rule is invented", () => {
  const quiet = worker({ name: "billbasket", type: "smppclient", properties: [] });
  const plan = defaultRoutingPlan([], [worker()], [quiet],
    { mtTarget: MT_TARGET, moTarget: MO_TARGET });

  assert.ok(!plan.table.rules.some((r) => ruleDirection(r) === "inbound"));
});

test("a return rule targeting the bare instance name is recognised", () => {
  //the gateway registers each worker under both `smpp` and `smppserver.smpp`, and the seed script
  //that sets up a real traffic lane writes the bare one. Reading only the full name reported a
  //correctly-configured listener as missing -- and a recreate would then have appended a duplicate
  const bare = rule({
    target: "smpp", conditions: [DLR_CONDITION], label: "DLR to the bound session",
  });

  assert.equal(missingDlrReturnRules([defaultTable([bare])], [worker()]).length, 0);
});

test("a rule targeting a different listener's bare name still leaves a gap", () => {
  const other = rule({ target: "reseller1", conditions: [DLR_CONDITION] });

  assert.equal(missingDlrReturnRules([defaultTable([other])], [worker({ name: "smpp" })]).length, 1);
});

/**
 * The receipt-routing probe, which exists because "a rule is present" and "a receipt arrives" are
 * different questions — and the incident that produced this code passed the first while failing the
 * second in two different ways, the second of which cost money.
 */
test("a receipt landing on its own listener is not a problem -- or every case below is vacuous", () => {
  assert.equal(receiptRoutingProblem("smppserver.test123", "smppserver.test123").severity, "none");
});

test("a receipt routed to a VENDOR is danger, not a warning", () => {
  //this is the one that leaves the platform as billed traffic, so it must not read the same as a
  //receipt that merely goes nowhere
  const p = receiptRoutingProblem("smppserver.test123", "smppclient.in-smsc");
  assert.equal(p.severity, "danger");
  assert.match(p.message, /VENDOR/);
  assert.match(p.message, /billed/);
});

test("a receipt routed to the WRONG listener warns, and says what is missing", () => {
  const p = receiptRoutingProblem("smppserver.test123", "smppserver.smpp");
  assert.equal(p.severity, "warn");
  assert.match(p.message, /ingateway/);
  //the position, not only the condition -- getting that wrong is what turned this into billed traffic
  assert.match(p.message, /above/);
});

test("a receipt matching nothing warns rather than passing silently", () => {
  assert.equal(receiptRoutingProblem("smppserver.smpp", null).severity, "warn");
  assert.equal(receiptRoutingProblem("smppserver.smpp", "").severity, "warn");
});

test("a disabled listener is not reported as missing a return rule", () => {
  const tables = [{ name: "default", targetFunction: "NORMAL" as const, rules: [] }];
  const off = [{ name: "test123", type: "smppserver" as const, enabled: false }];
  const on = [{ name: "test123", type: "smppserver" as const, enabled: true }];
  assert.equal(missingDlrReturnRules(tables, off).length, 0);
  //and the anti-vacuity half: enabling it makes the gap appear, so the filter is not hiding everything
  assert.equal(missingDlrReturnRules(tables, on).length, 1);
});
