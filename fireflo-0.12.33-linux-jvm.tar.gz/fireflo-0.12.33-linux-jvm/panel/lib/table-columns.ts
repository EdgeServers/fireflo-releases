/**
 * Choosing, ordering and remembering the columns of a table.
 *
 * <p>Extracted from `cdr-columns.ts`, where all of this was written for call records and none of it
 * was actually about them. `/cdrs` and `/accounts` now share it; a third table would too.
 *
 * <p>Database-free, so a client component can import it.
 */

export interface TableColumn<Row, Group extends string = string> {
  id: string;
  header: string;
  /** Grouping in the chooser only; it has no effect on the table. */
  group: Group;
  from: (row: Row) => unknown;
  align?: "right";
  /**
   * Whether this column is on for someone who has never opened the chooser.
   *
   * <p>Set these to exactly what the table rendered before it had a chooser, so nobody's view
   * changes on upgrade.
   */
  defaultOn: boolean;
  /** Columns that make no sense to sort by — a rendered link, a badge cluster. */
  unsortable?: boolean;
}

export type SortDirection = "asc" | "desc";

/**
 * A stored choice, recorded as decisions rather than as a result.
 *
 * <p><strong>`on`/`off` rather than a flat list of enabled ids</strong>, and the difference is not
 * cosmetic. With a flat list, a column added in a later release is absent from every stored
 * preference and therefore never appears for anyone who has ever opened the chooser — permanently,
 * silently, and nobody would connect it to the release. Recording what was decided means an unseen
 * column falls back to its own `defaultOn`.
 *
 * <p>`sort` and `pageSize` are optional and validated independently of the columns, so a preference
 * written before either existed still reads cleanly and simply has neither.
 */
export interface ColumnChoice {
  v: 1;
  on: string[];
  off: string[];
  sort?: { id: string; dir: SortDirection };
  pageSize?: number;
}

export function resolveColumns<Row, Group extends string>(
  catalogue: readonly TableColumn<Row, Group>[],
  choice: ColumnChoice | null
): TableColumn<Row, Group>[] {
  if (!choice) {
    return catalogue.filter((c) => c.defaultOn);
  }
  const on = new Set(choice.on);
  const off = new Set(choice.off);
  return catalogue.filter((c) => (on.has(c.id) ? true : off.has(c.id) ? false : c.defaultOn));
}

/** Reads a stored choice, tolerating anything at all in that slot. */
export function readColumnChoice(raw: string | null): ColumnChoice | null {
  if (!raw) {
    return null;
  }
  try {
    const parsed = JSON.parse(raw);
    if (parsed?.v === 1 && Array.isArray(parsed.on) && Array.isArray(parsed.off)) {
      return {
        v: 1,
        on: parsed.on.filter((id: unknown) => typeof id === "string"),
        off: parsed.off.filter((id: unknown) => typeof id === "string"),
        sort: readSort(parsed.sort),
        pageSize: typeof parsed.pageSize === "number" && parsed.pageSize > 0
          ? Math.floor(parsed.pageSize)
          : undefined,
      };
    }
  } catch {
    //a corrupt or hand-edited value falls back to the defaults rather than breaking the page
  }
  return null;
}

function readSort(value: unknown): ColumnChoice["sort"] {
  if (
    value && typeof value === "object"
    && typeof (value as { id?: unknown }).id === "string"
    && ((value as { dir?: unknown }).dir === "asc" || (value as { dir?: unknown }).dir === "desc")
  ) {
    return value as { id: string; dir: SortDirection };
  }
  return undefined;
}

const BLANK: ColumnChoice = { v: 1, on: [], off: [] };

export function toggleColumn(choice: ColumnChoice | null, id: string, enabled: boolean): ColumnChoice {
  const base = choice ?? BLANK;
  return {
    ...base,
    v: 1,
    on: enabled ? [...new Set([...base.on, id])] : base.on.filter((c) => c !== id),
    off: enabled ? base.off.filter((c) => c !== id) : [...new Set([...base.off, id])],
  };
}

/** Clicking the sorted column reverses it; clicking any other sorts by it ascending. */
export function nextSort(choice: ColumnChoice | null, id: string): ColumnChoice {
  const base = choice ?? BLANK;
  const dir: SortDirection = base.sort?.id === id && base.sort.dir === "asc" ? "desc" : "asc";
  return { ...base, v: 1, sort: { id, dir } };
}

export function setPageSize(choice: ColumnChoice | null, pageSize: number): ColumnChoice {
  return { ...(choice ?? BLANK), v: 1, pageSize };
}

/**
 * Sorts by one column's raw value, **nulls last in both directions**.
 *
 * <p>Not an oversight and not merely tidy: the empty values are the uninteresting rows, and letting
 * them lead an ascending sort pushes every row worth looking at off the first page — which is the
 * only page most people read. Descending already puts them last, so holding them there in ascending
 * too is what makes the two clicks symmetrical.
 *
 * <p>Numbers compare numerically and everything else by locale string, so "10" sorts after "9" in a
 * count column and names sort the way a reader expects.
 */
export function sortRows<Row, Group extends string>(
  rows: Row[],
  column: TableColumn<Row, Group> | undefined,
  dir: SortDirection
): Row[] {
  if (!column) {
    return rows;
  }
  const sign = dir === "asc" ? 1 : -1;
  return [...rows].sort((a, b) => {
    const x = column.from(a);
    const y = column.from(b);
    const xEmpty = x == null || x === "";
    const yEmpty = y == null || y === "";
    if (xEmpty || yEmpty) {
      return xEmpty && yEmpty ? 0 : xEmpty ? 1 : -1;
    }
    if (typeof x === "number" && typeof y === "number") {
      return (x - y) * sign;
    }
    return String(x).localeCompare(String(y), undefined, { numeric: true }) * sign;
  });
}
