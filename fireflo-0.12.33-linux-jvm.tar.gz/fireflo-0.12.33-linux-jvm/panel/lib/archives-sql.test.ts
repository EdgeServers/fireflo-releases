import { test } from "node:test";
import assert from "node:assert/strict";
import {
  accountsSql,
  batchesSql,
  entriesSql,
  mergePartitions,
  monthOfBound,
  partitionLine,
  MAX_ENTRY_BATCH,
} from "./archives-sql.ts";
import {
  EMPTY_ARCHIVE_ENTRY_FORM,
  entryFormFromQuery,
  entryFormToQuery,
  isRequestError,
  parseArchiveAccountFilters,
  parseArchiveEntryFilters,
  parseBatchFilters,
} from "./archives-request.ts";
import { selectorLine } from "./archives-types.ts";

/**
 * The Archives report's SQL and filters, asserted without a database.
 *
 * <p>The column names are the gateway's V1.93.0; this is where a rename on that side shows up first.
 */

const NOW = new Date("2026-10-16T12:00:00Z");
const BATCH = "6f1c2d3e-4a5b-4c6d-8e7f-0123456789ab";

test("entries: every filter is a bind parameter, newest first, keyset on (archived_at, archive_id)", () => {
  const { sql, params } = entriesSql(
    { since: NOW, accountId: "acme'; drop table x", worker: "smppclient.acme", systemId: "acme01", store: "worker", batchId: BATCH },
    { limit: 50, cursor: { archivedAt: "2026-10-16T10:00:00.000Z", id: "42" } }
  );
  assert.doesNotMatch(sql, /drop table/);
  assert.match(sql, /FROM queue_archive\b/);
  assert.match(sql, /account_id = \$2/);
  assert.match(sql, /worker = \$3/);
  assert.match(sql, /system_id = \$4/);
  assert.match(sql, /store = \$5/);
  assert.match(sql, /batch_id = \$6::uuid/);
  assert.match(sql, /\(archived_at, archive_id\) < \(\$7::timestamptz, \$8::bigint\)/);
  assert.match(sql, /ORDER BY archived_at DESC, archive_id DESC/);
  assert.match(sql, /LIMIT \$9/);
  assert.equal(params[8], 51, "one extra row tells the page there is more");
  assert.equal(params.length, 9);
});

test("entries: a message id matches either the gateway id or the serial, with one parameter", () => {
  const { sql, params } = entriesSql({ gatewayMsgId: "01JC8" }, { limit: 10 });
  assert.match(sql, /\(gateway_msg_id = \$1 OR serial = \$1\)/);
  assert.deepEqual(params, ["01JC8", 11]);
});

test("entries: the limit is clamped, never unbounded", () => {
  const { params } = entriesSql({}, { limit: 1e9 });
  assert.equal(params[params.length - 1], MAX_ENTRY_BATCH + 1);
});

test("entry filters: all time needs an identifier; a long unscoped window is refused", () => {
  const all = parseArchiveEntryFilters(new URLSearchParams("range=all"), NOW);
  assert.ok(isRequestError(all));
  assert.match(all.error, /name an account/);

  const scoped = parseArchiveEntryFilters(new URLSearchParams(`range=all&batch=${BATCH}`), NOW);
  assert.ok(!isRequestError(scoped));
  assert.equal(scoped.batchId, BATCH);
  assert.equal(scoped.since, undefined);

  const long = parseArchiveEntryFilters(new URLSearchParams("range=1h&since=2026-01-01T00:00:00Z"), NOW);
  assert.ok(isRequestError(long));
  assert.match(long.error, /at most 92/);
});

test("entry filters: a bad batch id or store is a sentence, not a 500", () => {
  const bad = parseArchiveEntryFilters(new URLSearchParams("batch=not-a-uuid"), NOW);
  assert.ok(isRequestError(bad));
  assert.match(bad.error, /not a batch id/);
  const store = parseArchiveEntryFilters(new URLSearchParams("store=broker"), NOW);
  assert.ok(isRequestError(store));
});

test("entry filters: the default range is the last 7 days", () => {
  const f = parseArchiveEntryFilters(new URLSearchParams(""), NOW);
  assert.ok(!isRequestError(f));
  assert.equal(f.since?.toISOString(), "2026-10-09T12:00:00.000Z");
});

test("the entry form round-trips through the URL, and only what is set is written", () => {
  const form = { ...EMPTY_ARCHIVE_ENTRY_FORM, account: "acme", batch: BATCH };
  const q = entryFormToQuery(form);
  assert.equal(q.toString(), `account=acme&batch=${BATCH}`);
  assert.deepEqual(entryFormFromQuery(q), form);
});

test("by account: read from the summary, grouped per account, held and purged split by purged_at", () => {
  const { sql, params } = accountsSql({ from: "2026-01-01", to: "2026-10-31", accountId: "acme" });
  assert.match(sql, /FROM queue_archive_summary/);
  assert.doesNotMatch(sql, /FROM queue_archive\b(?!_summary)/, "never the detail rows: a purge must not move these totals");
  assert.match(sql, /day >= \$1::date/);
  assert.match(sql, /day <= \$2::date/);
  assert.match(sql, /account_id = \$3/);
  assert.match(sql, /FILTER \(WHERE purged_at IS NULL\)/);
  assert.match(sql, /FILTER \(WHERE purged_at IS NOT NULL\)/);
  assert.match(sql, /GROUP BY account_id/);
  assert.deepEqual(params.slice(0, 3), ["2026-01-01", "2026-10-31", "acme"]);
});

test("by account filters: dates must be days, and in order", () => {
  assert.ok(isRequestError(parseArchiveAccountFilters(new URLSearchParams("from=2026-13-45x"))));
  assert.ok(isRequestError(parseArchiveAccountFilters(new URLSearchParams("from=2026-10-02&to=2026-10-01"))));
  const ok = parseArchiveAccountFilters(new URLSearchParams("from=2026-10-01"));
  assert.ok(!isRequestError(ok));
  assert.equal(ok.from, "2026-10-01");
});

test("batches: newest first, store and batch bound, repush and purge are stores too", () => {
  const { sql, params } = batchesSql({ store: "repush", batchId: BATCH, limit: 500 });
  assert.match(sql, /FROM queue_archive_batch/);
  assert.match(sql, /store = \$1/);
  assert.match(sql, /batch_id = \$2::uuid/);
  assert.match(sql, /ORDER BY started_at DESC/);
  assert.equal(params[2], 200, "clamped");
  assert.ok(!isRequestError(parseBatchFilters(new URLSearchParams("store=repush"))));
  assert.ok(!isRequestError(parseBatchFilters(new URLSearchParams("store=purge"))));
  assert.ok(isRequestError(parseBatchFilters(new URLSearchParams("store=nope"))));
});

test("partition bounds give their month; DEFAULT gives none", () => {
  assert.equal(monthOfBound("FOR VALUES FROM ('2026-10-01 00:00:00+00') TO ('2026-11-01 00:00:00+00')"), "2026-10");
  assert.equal(monthOfBound("DEFAULT"), null);
});

test("partitions and purged months merge: newest first, default last, a purged month keeps its count", () => {
  const merged = mergePartitions(
    [
      { relname: "queue_archive_default", bound: "DEFAULT", size: "8192" },
      { relname: "queue_archive_2026_09", bound: "FOR VALUES FROM ('2026-09-01 00:00:00+00') TO ('2026-10-01 00:00:00+00')", size: "16384" },
      { relname: "queue_archive_2026_10", bound: "FOR VALUES FROM ('2026-10-01 00:00:00+00') TO ('2026-11-01 00:00:00+00')", size: "32768" },
    ],
    [{ relname: "queue_archive_2026_10", rows: "5", first_at: "2026-10-02T00:00:00Z", last_at: "2026-10-03T00:00:00Z" }],
    [{ month: "2026-03", purged_at: "2026-10-15T00:00:00Z", rows: "1200" }]
  );
  assert.deepEqual(merged.map((p) => p.month), ["2026-10", "2026-09", "2026-03", null]);
  assert.equal(merged[0].rows, 5);
  assert.equal(merged[1].rows, 0, "an empty partition holds zero rows, not unknown");
  assert.equal(merged[2].rows, null);
  assert.equal(merged[2].purgedRows, 1200);
  assert.equal(partitionLine(merged[2]), "purged on 2026-10-15, 1200 rows");
});

test("a selector reads as one line, empty values left out", () => {
  assert.equal(selectorLine({ worker: "smppclient.acme", subStore: "held", account: null, all: false, olderThanSeconds: 7200 }),
    "worker=smppclient.acme subStore=held olderThanSeconds=7200");
  assert.equal(selectorLine(null), "—");
});
