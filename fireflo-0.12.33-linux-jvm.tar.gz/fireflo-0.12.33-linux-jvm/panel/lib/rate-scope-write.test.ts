import { test } from "node:test";
import assert from "node:assert/strict";
import type { RateRuleInput } from "./rate-types.ts";
import { type ExistingRule, planProductWrite } from "./rate-scope-write.ts";

/**
 * What a product-scoped save must not do to the rest of the scope.
 *
 * <p>The interesting assertions here are all absences: a rule that is not mentioned is still there
 * afterwards, in the same relative position, priced the same. That is the failure `saveScope` would
 * have produced from the product page — following the page's own instruction to set a `*` default
 * for one product would have deleted `*` for every other product, from a screen that never named
 * them and with a 200 in reply.
 */

const rule = (over: Partial<RateRuleInput> = {}): RateRuleInput => ({
  id: null,
  amount: "0.0100",
  product: null,
  currency: null,
  label: null,
  enabled: true,
  conditions: [],
  filters: [],
  ...over,
});

/** `*` priced for two products and carrying a catch-all, which is the realistic shape. */
const twoProducts: ExistingRule[] = [
  { id: 11, seq: 0, product: "promo" },
  { id: 22, seq: 1, product: "transactional" },
  { id: 33, seq: 2, product: null },
];

test("rules of another product are neither deleted nor reordered", () => {
  //THE assertion. Everything else in this file is a way of getting here honestly
  const plan = planProductWrite(twoProducts, "promo", [rule({ amount: "0.0200" })]);

  assert.deepEqual(plan.deleteIds, [11], "only this product's replaced rule goes");
  assert.deepEqual(
    plan.keep,
    [{ id: 22, seq: 0 }, { id: 33, seq: 1 }],
    "the other product and the catch-all survive, in the order they had"
  );
});

test("a rule replaced in place keeps its id", () => {
  //cdr_submit.price_rule_id points at it and there are no foreign keys anywhere to complain. A
  //delete-and-reinsert would issue a fresh BIGSERIAL and make "which rule charged this?" unanswerable
  const plan = planProductWrite(twoProducts, "promo", [rule({ id: 11, amount: "0.0200" })]);

  assert.deepEqual(plan.deleteIds, []);
  assert.deepEqual(plan.writes.map((w) => w.rule.id), [11]);
});

test("this product's rules are placed after everything the save is not touching", () => {
  //seq is unique per scope and the constraint is not deferrable, so the positions have to be
  //allocated across the whole scope even though only one bucket is being written
  const plan = planProductWrite(twoProducts, "promo", [rule(), rule({ amount: "0.0300" })]);

  assert.deepEqual(plan.keep.map((k) => k.seq), [0, 1]);
  assert.deepEqual(plan.writes.map((w) => w.seq), [2, 3]);
});

test("the submitted order is the order the gateway will try them in", () => {
  const plan = planProductWrite([], "promo", [
    rule({ amount: "0.0500", label: "premium" }),
    rule({ amount: "0.0100", label: "the rest" }),
  ]);

  assert.deepEqual(plan.writes.map((w) => w.rule.label), ["premium", "the rest"]);
  assert.deepEqual(plan.writes.map((w) => w.seq), [0, 1]);
});

test("emptying one product leaves the rest of the scope alone", () => {
  //deleting a product's pricing is legitimate; deleting the scope with it is not
  const plan = planProductWrite(twoProducts, "promo", []);

  assert.deepEqual(plan.deleteIds, [11]);
  assert.equal(plan.keep.length, 2);
  assert.deepEqual(plan.writes, []);
});

test("a scope that prices nothing yet is a create, not an error", () => {
  //the case the product page exists to serve: no default at all, and one has to be settable
  const plan = planProductWrite([], "promo", [rule()]);

  assert.deepEqual(plan.deleteIds, []);
  assert.deepEqual(plan.keep, []);
  assert.deepEqual(plan.writes.map((w) => w.seq), [0]);
});

test("a rule belonging to another product cannot be edited through this product", () => {
  //adopting it would move it into this bucket -- repricing whatever it priced, and removing it from
  //the page that shows it, both silently
  assert.throws(
    () => planProductWrite(twoProducts, "promo", [rule({ id: 22, amount: "0.9999" })]),
    /prices 'transactional' in this scope/
  );
});

test("a catch-all cannot be adopted either, and is described as what it is", () => {
  assert.throws(
    () => planProductWrite(twoProducts, "promo", [rule({ id: 33 })]),
    /prices every product in this scope/
  );
});

test("a rule that has since been deleted is refused rather than recreated", () => {
  //the concurrent-edit case. Recreating it under a new id would resurrect a price somebody removed
  assert.throws(
    () => planProductWrite(twoProducts, "promo", [rule({ id: 999 })]),
    /Reload the page/
  );
});

test("the same rule twice is refused", () => {
  assert.throws(
    () => planProductWrite(twoProducts, "promo", [rule({ id: 11 }), rule({ id: 11 })]),
    /appears twice/
  );
});

test("an empty product is refused, because the any-product bucket is a catch-all", () => {
  //"the rules with no product" is what a catch-all is. Rewriting it under the name of a product
  //would be a different operation wearing this one's name
  assert.throws(() => planProductWrite(twoProducts, "  ", [rule()]), /needs a product/);
});

test("a product is matched exactly, whitespace and all", () => {
  //app_rate_rule.product is compared with = in every query the gateway runs, so ' promo' is a
  //different product. Trimming it here would make this save adopt rules the page never showed
  const spaced: ExistingRule[] = [{ id: 7, seq: 0, product: " promo" }];
  const plan = planProductWrite(spaced, "promo", [rule()]);

  assert.deepEqual(plan.deleteIds, [], "' promo' is not 'promo'");
  assert.deepEqual(plan.keep, [{ id: 7, seq: 0 }]);
});
