//with the extension, because `node --test` runs this module directly and does not resolve
//extensionless specifiers. Everything imported is pure data, so this stays importable by a client
//component and by the seed script alike
import { GATEWAY_SETTING_FIELDS } from "./gateway-setting-fields.ts";
import { SETTING_FIELDS, type SettingWidget } from "./setting-fields.ts";
import { settingLabel, type SettingKey } from "./labels.ts";

/**
 * What every gateway configuration key is -- the one list both the gateway and this panel read.
 *
 * <h2>Why it is a table</h2>
 *
 * <p>Whether a key is a credential, whether the panel may show or edit it, and what shape its value
 * has used to be written down five times: the gateway's `SensitiveLogSanitizer`, this panel's
 * `DENIED` map and substring list, its separate `SECRET_KEYS` for worker settings, the `secret`
 * widget kind in the setting catalogues, and the gateway's lenient value parsers. Two of those
 * disagreeing is how `smsg.ops.token` once reached the browser. Since gateway migration V1.61.0 the
 * facts live in `app_config_key`, the gateway masks what it says is secret, and this panel reads it
 * on the server and hands the verdicts to its screens.
 *
 * <h2>What stays in code, and why</h2>
 *
 * <ul>
 *   <li>{@link BUILTIN_REGISTRY}, below: what `app_config_key` was seeded from, and what this panel
 *       falls back to when it cannot read the table -- a gateway in file mode, or a role without the
 *       grant. It is generated from the same catalogues the forms render, so the two cannot drift;
 *       `scripts/config-key-registry-sql.ts` prints it as the migration's seed.</li>
 *   <li>The substring rule in `gateway-key-policy.ts` and the gateway's `isSensitiveKey`. A list
 *       only covers the keys somebody listed; a key nobody listed must still be caught by its name,
 *       the day it is added.</li>
 *   <li>Labels, hints and form layout. Those are this panel's presentation, not facts about the
 *       gateway; the registry carries a label only so a database reader can tell keys apart.</li>
 * </ul>
 */

/**
 * Why the panel will not write a key. The same reasons `gateway-key-policy.ts` has always given, plus
 * `retired` (gateway V1.88.0): the gateway no longer reads the key, so writing it changes nothing.
 */
export type DenialReason = "secret" | "config-source" | "wiring" | "elsewhere" | "licensing" | "prefix" | "retired";

/**
 * Whether the gateway still reads a key (`app_config_key.status`, gateway V1.88.0).
 *
 * <p>`current` is the default. `deprecated` is still read, but a better key exists and
 * `replacedBy` names it. `retired` is never read any more: setting it does nothing, and the panel
 * neither edits nor offers it. A registry read from a gateway older than V1.88.0 has no such
 * column, and every row then reads as `current` -- see {@link rowFromRecord}.
 */
export type KeyStatus = "current" | "deprecated" | "retired";

/** Where the key lives: `app_config` (platform), or a worker property (`app_worker_property`, and `outSms.default.<key>`). */
export type KeyScope = "platform" | "worker";

/** What the panel may do with it. */
export type KeyAccess = "editable" | "read-only" | "hidden";

export type KeyKind = SettingWidget["kind"];

export interface ConfigKeyRow {
  scope: KeyScope;
  key: string;
  kind: KeyKind;
  /** The values an `enum` accepts; null otherwise. */
  choices: string[] | null;
  /** `ms`, `s` or `min` for a number that is a duration; null otherwise. */
  unit: string | null;
  /** The literal the gateway parses when the key is absent; null when it has not been verified. */
  codedDefault: string | null;
  secret: boolean;
  access: KeyAccess;
  /** Why it is not editable; null when it is. */
  reason: DenialReason | null;
  label: string | null;
  /** Whether the gateway still reads it. `current` on every row from before V1.88.0. */
  status: KeyStatus;
  /** The key to use instead of a deprecated or retired one, when there is one. */
  replacedBy: string | null;
}

/**
 * Keys denied by name, with the reason. Moved here from `gateway-key-policy.ts` so the code holds one
 * list, and that list is the registry's seed; every entry is one `gateway-setting-fields.ts` argues
 * for in its header, and the key literals were read from the gateway source.
 */
const DENIED_PLATFORM: readonly {
  key: string;
  reason: DenialReason;
  label: string;
  /** For a key whose value is one of a few: the choices, and the first is the coded default. */
  choices?: string[];
}[] = [
  //the two secrets guarding the endpoint the panel authenticates to
  { key: "smsg.ops.token", reason: "secret", label: "Ops API token" },
  { key: "smsg.ops.admin.token", reason: "secret", label: "Ops API admin token" },
  //carries a password in its userinfo -- the conf.example line is literally amqp://fireflo:secret@host
  { key: "smsg.queue.amqp.uri", reason: "secret", label: "Message broker address" },

  { key: "smsg.config.source", reason: "config-source", label: "Where configuration is read from" },
  { key: "smsg.properties.file.path", reason: "config-source", label: "Properties file" },
  { key: "smsg.credentials.file.path", reason: "config-source", label: "Credentials file" },
  { key: "smsg.rates.file.path", reason: "config-source", label: "Rates file" },
  { key: "smsg.routing.file.path", reason: "config-source", label: "Routing file" },

  //set on the Queues page since V1.67.0, which also made it a checked choice
  { key: "smsg.queue.provider", reason: "elsewhere", label: "Message broker", choices: ["memory", "rabbitmq"] },
  { key: "smsg.cdr.sink", reason: "wiring", label: "Where call records go" },
  //loosening an SSRF guard from a web form is not an operator convenience
  { key: "smsg.webhook.private.targets", reason: "wiring", label: "Webhooks to private addresses" },
  { key: "smsg.webhook.schemes", reason: "wiring", label: "Webhook URL schemes" },

  { key: "smsg.rates.currency", reason: "elsewhere", label: "Platform currency" },
  { key: "smsg.money.scale", reason: "elsewhere", label: "Decimal places shown" },
  { key: "smsg.billing.zone", reason: "elsewhere", label: "Billing time zone" },

  //the licensing namespace is denied as a prefix in gateway-key-policy.ts; these are the two keys in
  //it today, listed so a database reader sees them
  { key: "smsg.license.server.url", reason: "licensing", label: "Licence server" },
  { key: "smsg.license.directory", reason: "licensing", label: "Licence directory" },
];

/** Settable despite carrying neither writable prefix -- see `LEGACY_WRITABLE` in gateway-key-policy.ts. */
const LEGACY_PLATFORM: readonly { key: string; label: string; kind: KeyKind; choices: string[] | null; codedDefault: string | null }[] = [
  { key: "message.trace.mode", label: "Message trace", kind: "text", choices: null, codedDefault: null },
];

/**
 * The rows gateway migration V1.88.0 added: keys the gateway warns about and never (or no longer)
 * reads. Carried here so a panel talking to a database from before that migration still knows them
 * -- they are the same three `DEAD_KEYS` the worker form has refused for years, plus the one switch
 * V1.38.0 translated into `whitelist.tlvs.mode`.
 */
const STATUS_WORKER: readonly {
  key: string; kind: KeyKind; codedDefault: string | null; label: string; status: KeyStatus; replacedBy: string | null;
}[] = [
  { key: "srv.host", kind: "text", codedDefault: null, label: "Listener bind address (never had an effect)", status: "retired", replacedBy: null },
  { key: "srv.tls.host", kind: "text", codedDefault: null, label: "TLS listener bind address (never had an effect)", status: "retired", replacedBy: null },
  { key: "conf.sleepWindow", kind: "number", codedDefault: null, label: "Sleep window (never had an effect)", status: "retired", replacedBy: null },
  { key: "whitelist.tlvs.replace", kind: "boolean", codedDefault: "false", label: "Replace approved TLVs (old switch)", status: "deprecated", replacedBy: "whitelist.tlvs.mode" },
];

function shape(widget: SettingWidget): Pick<ConfigKeyRow, "kind" | "choices" | "unit"> {
  return {
    kind: widget.kind,
    choices: widget.kind === "enum" ? widget.options.map((o) => o.value) : null,
    unit: widget.kind === "number" ? widget.unit ?? null : null,
  };
}

function build(): ConfigKeyRow[] {
  const rows: ConfigKeyRow[] = [];
  for (const d of DENIED_PLATFORM) {
    rows.push({
      scope: "platform", key: d.key, kind: d.choices ? "enum" : "text", choices: d.choices ?? null, unit: null,
      codedDefault: d.choices?.[0] ?? null,
      secret: d.reason === "secret",
      //a secret is withheld in both directions; every other denial is shown and not written
      access: d.reason === "secret" ? "hidden" : "read-only",
      reason: d.reason, label: d.label, status: "current", replacedBy: null,
    });
  }
  for (const f of GATEWAY_SETTING_FIELDS) {
    rows.push({
      scope: "platform", key: f.key, ...shape(f.widget), codedDefault: f.codedDefault,
      secret: f.widget.kind === "secret", access: f.widget.kind === "secret" ? "hidden" : "editable",
      reason: f.widget.kind === "secret" ? "secret" : null, label: f.label, status: "current", replacedBy: null,
    });
  }
  for (const l of LEGACY_PLATFORM) {
    rows.push({
      scope: "platform", key: l.key, kind: l.kind, choices: l.choices, unit: null, codedDefault: l.codedDefault,
      secret: false, access: "editable", reason: null, label: l.label, status: "current", replacedBy: null,
    });
  }
  for (const key of Object.keys(SETTING_FIELDS) as SettingKey[]) {
    const f = SETTING_FIELDS[key];
    const secret = f.widget.kind === "secret";
    rows.push({
      scope: "worker", key, ...shape(f.widget), codedDefault: f.codedDefault ?? null,
      secret,
      //a worker secret is written through the worker form's own kept/set protocol and never shown;
      //a key another screen owns is still editable -- that is the screen's business, not a denial
      access: secret ? "hidden" : "editable",
      reason: secret ? "secret" : null,
      label: settingLabel(key).label,
      status: "current", replacedBy: null,
    });
  }
  for (const w of STATUS_WORKER) {
    //a retired key is shown and not offered (read-only, reason retired); a deprecated one still
    //works and stays editable, exactly as the migration seeds them
    const retired = w.status === "retired";
    rows.push({
      scope: "worker", key: w.key, kind: w.kind, choices: null, unit: null, codedDefault: w.codedDefault,
      secret: false, access: retired ? "read-only" : "editable", reason: retired ? "retired" : null,
      label: w.label, status: w.status, replacedBy: w.replacedBy,
    });
  }
  return rows;
}

/**
 * One `app_config_key` row as the database returns it, in either shape the table has had.
 *
 * <p>Before gateway V1.88.0 the table had no `status` or `replaced_by`; a panel reading such a table
 * sees neither column, and every key is then `current` with no successor. Tolerating the absence
 * here, rather than failing the whole read, is what keeps the registry (and so the secret masking it
 * drives) working across a gateway update that has not happened yet.
 */
export function rowFromRecord(r: Record<string, unknown>): ConfigKeyRow {
  const status = r.status;
  return {
    scope: r.scope as KeyScope,
    key: String(r.key),
    kind: r.kind as KeyKind,
    choices: Array.isArray(r.choices) ? (r.choices as string[]) : null,
    unit: typeof r.unit === "string" ? r.unit : null,
    codedDefault: typeof r.coded_default === "string" ? r.coded_default : null,
    secret: r.secret === true,
    access: r.access as KeyAccess,
    reason: (r.reason as DenialReason | null | undefined) ?? null,
    label: typeof r.label === "string" ? r.label : null,
    status: status === "deprecated" || status === "retired" ? status : "current",
    replacedBy: typeof r.replaced_by === "string" && r.replaced_by.trim() !== "" ? r.replaced_by : null,
  };
}

/** What a screen does about a key's status: the chip to show, and whether an editor may be offered. */
export interface StatusVerdict {
  status: KeyStatus;
  replacedBy: string | null;
  /** False only for a retired key: the gateway no longer reads it, so an editor would be a lie. */
  editable: boolean;
  /** The sentence beside the key, or null for a current key, which says nothing. */
  notice: string | null;
}

const CURRENT: StatusVerdict = { status: "current", replacedBy: null, editable: true, notice: null };

/**
 * The status verdict for a key, by scope.
 *
 * <p>A worker key may be asked for by its bare name (`srv.host`) or as its gateway-wide default
 * (`outSms.default.srv.host`); both answer the same. A key the registry has never heard of is
 * current: the registry says when a key is retired, never that an unknown one is.
 */
export function statusOf(registry: ConfigKeyRegistry, scope: KeyScope, key: string): StatusVerdict {
  const bare = scope === "worker" && key.startsWith("outSms.default.") ? key.slice("outSms.default.".length) : key;
  const row = (scope === "platform" ? registry.platform : registry.worker).get(bare.trim());
  return row ? statusVerdict(row) : CURRENT;
}

/** The verdict for one row. Pure, so the sentence is decided once for every screen. */
export function statusVerdict(row: Pick<ConfigKeyRow, "status" | "replacedBy">): StatusVerdict {
  switch (row.status) {
    case "retired":
      return {
        status: "retired", replacedBy: row.replacedBy, editable: false,
        notice: row.replacedBy ? `Retired — has no effect. Use ${row.replacedBy}.` : "Retired — has no effect",
      };
    case "deprecated":
      return {
        status: "deprecated", replacedBy: row.replacedBy, editable: true,
        notice: row.replacedBy ? `Deprecated: use ${row.replacedBy}` : "Deprecated",
      };
    default:
      return CURRENT;
  }
}

/** The registry as an index, which is the shape every reader wants. */
export interface ConfigKeyRegistry {
  rows: readonly ConfigKeyRow[];
  platform: ReadonlyMap<string, ConfigKeyRow>;
  worker: ReadonlyMap<string, ConfigKeyRow>;
  /** Where these rows came from, so a screen can say when it is showing the fallback. */
  source: "database" | "builtin";
}

export function registryFrom(rows: readonly ConfigKeyRow[], source: ConfigKeyRegistry["source"]): ConfigKeyRegistry {
  return {
    rows,
    platform: new Map(rows.filter((r) => r.scope === "platform").map((r) => [r.key, r])),
    worker: new Map(rows.filter((r) => r.scope === "worker").map((r) => [r.key, r])),
    source,
  };
}

/** What `app_config_key` was seeded from, and the fallback when it cannot be read. */
export const BUILTIN_REGISTRY: ConfigKeyRegistry = registryFrom(build(), "builtin");

/** Whether a worker setting key holds a credential, by the registry -- the replacement for `SECRET_KEYS`. */
export function isSecretWorkerKey(registry: ConfigKeyRegistry, key: string): boolean {
  return registry.worker.get(key)?.secret ?? false;
}
