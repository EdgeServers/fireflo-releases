import { listLoginDefaults } from "./credentials";
import { listMandatorySources } from "./mandatory-tlvs";
import { listRouteTables } from "./routing";
import { listWorkers } from "./workers";
import { tlvTag } from "./tlv-string";
import type { LoginDefaults, MandatorySource, VendorReach } from "./tlv-coverage";

/**
 * Everything `rowTlvGaps` needs, assembled once for a page rather than three times.
 *
 * <p>Server-only. Rides along on the whitelist endpoints beside `summaries`, for the reason those
 * routes already give about summaries: a list of approved rows with no indication that they supply
 * nothing reads as protection that is not there.
 *
 * <p>All four reads are small config tables and none of them is on any message path.
 */
export interface CoveragePayload {
  mandatory: MandatorySource[];
  logins: LoginDefaults[];
  vendors: VendorReach[];
}

/**
 * The vendors an enabled rule can send to, and the tags each will carry.
 *
 * <p>A vendor's `registered.tlvs.submit` is the list `SmppClientWorker` keeps after
 * `effective.keySet().retainAll(...)` — anything absent is dropped on the way out, after the call
 * record has already noted it as present.
 *
 * <p>Reachability narrows on `product` only, and only where a rule says `product equals X` or
 * `product in X,Y`. Everything else — destination prefixes, MCC/MNC, named filters — is treated as
 * "could be anything", which over-reports rather than hiding a real drop.
 */
async function vendorReach(): Promise<VendorReach[]> {
  const [vendors, tables] = await Promise.all([
    listWorkers("smppclient"),
    listRouteTables(),
  ]);

  //product conditions per vendor: null once any rule reaches it without keying on product
  const products = new Map<string, Set<string> | null>();
  for (const table of tables) {
    if (!table.enabled) {
      continue;
    }
    for (const rule of table.rules) {
      if (!rule.enabled) {
        continue;
      }
      const keyed = rule.conditions
        .filter((c) => c.field === "product" && !c.negate
          && (c.operator === "equals" || c.operator === "in"))
        .flatMap((c) => c.value.split(",").map((v) => v.trim()).filter(Boolean));

      const current = products.get(rule.target);
      if (!keyed.length) {
        products.set(rule.target, null);
      } else if (current !== null) {
        products.set(rule.target, new Set([...(current ?? []), ...keyed]));
      }
    }
  }

  return vendors
    .filter((v) => v.enabled)
    //a vendor no enabled rule names carries nothing, so it can drop nothing
    .filter((v) => products.has(v.name))
    .map((v) => {
      const declared = v.properties.find((p) => p.key === "registered.tlvs.submit")?.value ?? "";
      const registered = declared
        .split(",")
        .map((token) => tlvTag(token.trim()))
        .filter((tag): tag is number => tag !== null);
      const scoped = products.get(v.name);
      return { name: v.name, registered, products: scoped ? [...scoped] : null };
    });
}

export async function loadCoverage(accountId?: string): Promise<CoveragePayload> {
  const [mandatory, logins, vendors] = await Promise.all([
    listMandatorySources(),
    listLoginDefaults(accountId),
    vendorReach(),
  ]);
  //nothing requires a tag, so nothing can be missing one. Returning the other two anyway would ship
  //a login list to the browser that no sentence could ever use
  return mandatory.length ? { mandatory, logins, vendors } : { mandatory: [], logins: [], vendors: [] };
}
