import { strict as assert } from "node:assert";
import { test } from "node:test";

import {
  DISMISS_RETENTION_DAYS,
  dismiss,
  failureKey,
  isDismissed,
  prune,
  readDismissals,
  restore,
  type Dismissals,
} from "./failure-dismissals.ts";

function row(over: Partial<{ finalState: string; dlrState: number | null; errCode: string | null;
  messages: number; lastSeen: string }> = {}) {
  return {
    finalState: "FAILED",
    dlrState: 8,
    errCode: "069",
    messages: 12,
    lastSeen: "2026-08-19T10:00:00.000Z",
    ...over,
  };
}

test("a dismissed row comes back when the failure happens again", () => {
  //THE TEST THIS MODULE EXISTS FOR. Everything else here is bookkeeping; if this passes for the
  //wrong reason the card silently stops reporting a live delivery problem. Same key, same map --
  //the only thing that changes is that the failure occurred once more
  const at = new Date("2026-08-19T11:00:00.000Z");
  const dismissals = dismiss({}, row(), at);

  assert.equal(isDismissed(row(), dismissals), true, "hidden while nothing new has happened");
  assert.equal(
    isDismissed(row({ lastSeen: "2026-08-19T11:30:00.000Z" }), dismissals),
    false,
    "one more occurrence after the dismissal must bring it back"
  );
});

test("dismissing hides a failure that has only just happened", () => {
  //the ordinary case, and the reason the comparison is >= rather than >: an operator dismisses a
  //row seconds after reading it, and lastSeen can be the same instant at second resolution
  const same = "2026-08-19T10:00:00.000Z";
  const dismissals = dismiss({}, row({ lastSeen: same }), new Date(same));
  assert.equal(isDismissed(row({ lastSeen: same }), dismissals), true);
});

test("a dismissal is scoped to one failure kind, not to a state", () => {
  //dismissing "the carrier rejected these with 069" must not hide "the carrier rejected these with
  //208" -- a different vendor error is a different problem that happens to share a final state
  const dismissals = dismiss({}, row({ errCode: "069" }), new Date("2026-08-19T11:00:00.000Z"));
  assert.equal(isDismissed(row({ errCode: "069" }), dismissals), true);
  assert.equal(isDismissed(row({ errCode: "208" }), dismissals), false);
  assert.equal(isDismissed(row({ dlrState: 2 }), dismissals), false);
  assert.equal(isDismissed(row({ finalState: "EXPIRED" }), dismissals), false);
});

test("a missing receipt state and a missing vendor error do not collide", () => {
  //`FAILED` with no receipt state must not share a key with `FAILED|8` -- otherwise dismissing the
  //vague one hides the specific one
  assert.notEqual(
    failureKey({ finalState: "FAILED", dlrState: null, errCode: null }),
    failureKey({ finalState: "FAILED", dlrState: 8, errCode: null })
  );
  assert.equal(failureKey({ finalState: "FAILED", dlrState: null, errCode: null }), "FAILED||");
});

test("restore forgets the dismissal rather than recording a second flag", () => {
  const dismissals = dismiss({}, row(), new Date("2026-08-19T11:00:00.000Z"));
  const after = restore(dismissals, row());
  assert.equal(isDismissed(row(), after), false);
  assert.deepEqual(after, {}, "no tombstone left behind to reason about later");
});

test("prune drops what can no longer be hiding anything, and keeps the rest", () => {
  const now = new Date("2026-08-19T12:00:00.000Z");
  const old = new Date(now.getTime() - (DISMISS_RETENTION_DAYS + 1) * 86_400_000).toISOString();
  const recent = new Date(now.getTime() - 86_400_000).toISOString();
  const pruned = prune({ "FAILED||069": old, "EXPIRED||": recent, junk: "not a date" }, now);
  assert.deepEqual(pruned, { "EXPIRED||": recent });
});

test("a corrupt or hostile stored value shows everything rather than throwing", () => {
  //failing towards visible is the only safe direction: a spurious row is noise, a wrongly hidden
  //one is a delivery problem nobody sees. Private-mode browsers and half-written values are real
  for (const raw of [null, "", "{", "[]", "null", '"a string"', "42"]) {
    assert.deepEqual(readDismissals(raw), {}, `input ${JSON.stringify(raw)}`);
  }
  assert.deepEqual(
    readDismissals('{"FAILED||069":"2026-08-19T11:00:00.000Z","bad":{"nested":1},"n":7}'),
    { "FAILED||069": "2026-08-19T11:00:00.000Z" },
    "non-string values are dropped, the usable entry survives"
  );
});

test("an unparseable instant on either side shows the row", () => {
  const dismissals: Dismissals = { "FAILED|8|069": "yesterday afternoon" };
  assert.equal(isDismissed(row(), dismissals), false);
  assert.equal(
    isDismissed(row({ lastSeen: "whenever" }), { "FAILED|8|069": "2026-08-19T11:00:00.000Z" }),
    false
  );
});
