import { test } from "node:test";
import assert from "node:assert/strict";
import { autoEncoding, countSms, encodeSms, isGsm7 } from "./sms-text.ts";

test("plain text is GSM-7 and one part up to 160", () => {
  assert.equal(autoEncoding("Your OTP is 4821"), "gsm7");
  assert.deepEqual(countSms("a".repeat(160), "gsm7"), { encoding: "gsm7", units: 160, perPart: 160, parts: 1 });
  assert.deepEqual(countSms("a".repeat(161), "gsm7"), { encoding: "gsm7", units: 161, perPart: 153, parts: 2 });
});

test("extension characters count two and encode with ESC", () => {
  assert.equal(countSms("€[]", "gsm7").units, 6);
  assert.deepEqual([...encodeSms("A€", "gsm7")], [0x41, 0x1b, 0x65]);
  assert.deepEqual([...encodeSms("@£", "gsm7")], [0x00, 0x01]);
});

test("a character outside GSM-7 means UCS-2, 70 a part", () => {
  assert.equal(isGsm7("नमस्ते"), false);
  assert.equal(autoEncoding("hello 😀"), "ucs2");
  assert.deepEqual(countSms("a".repeat(71), "ucs2"), { encoding: "ucs2", units: 71, perPart: 67, parts: 2 });
  assert.deepEqual([...encodeSms("Aé", "ucs2")], [0x00, 0x41, 0x00, 0xe9]);
});

test("forcing GSM-7 on text it cannot carry is refused, not sent as '?'", () => {
  assert.throws(() => encodeSms("नमस्ते", "gsm7"), /not in the GSM-7 alphabet/);
});
