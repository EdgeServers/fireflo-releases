import type { HealthSession } from "./health-types";
import { count, duration } from "./format.ts";

/**
 * What a set of binds looks like at a glance, without opening the table.
 *
 * <h2>Why this exists at all</h2>
 *
 * <p>The bind list used to be a `<details>` whose summary read "5 sessions" and nothing else, while
 * the snapshot behind it — polled every ten seconds — was used only as a boolean to decide whether
 * to render the disclosure. Every field in it was thrown away, and opening the disclosure then made
 * a second request for the same rows. The summary could not say anything because nobody had asked
 * it to.
 *
 * <p>These are the readings that were being discarded: whether the binds are the kind that can
 * carry traffic, whether any landed on a backup address, how long the oldest has held, and whether
 * the load is spread across them or resting on one. Each of those is a different fault, and a bind
 * count answers none of them.
 *
 * <h2>Pure on purpose</h2>
 *
 * <p>No React and no fetching, so the phrasing can be tested against a session array rather than
 * against a rendered card. The two kinds of worker get different sentences because they hold
 * genuinely different facts — see {@link summariseBinds}.
 */

/** How the {@link HealthSession} array is worded under a section heading. */
export function summariseBinds(sessions: readonly HealthSession[], isVendor: boolean): string {
  if (!sessions.length) {
    return "";
  }
  return (isVendor ? vendorParts(sessions) : listenerParts(sessions)).filter(Boolean).join(" · ");
}

/**
 * A vendor's binds are its own outbound connections, so the questions are about capability and
 * placement: can they transmit, did any fall back to a secondary address, how settled are they.
 */
function vendorParts(sessions: readonly HealthSession[]): string[] {
  const bound = sessions.filter((s) => s.bound);
  const transceivers = bound.filter((s) => s.bind_type === "TRANSCEIVER").length;
  const receiveOnly = bound.filter((s) => s.bind_type === "RECEIVER").length;
  //`role` is absent on older gateways, and "NORMAL" is the primary. Only the contrast is worth
  //saying: a column of "Primary" teaches nobody anything, one backup means the primary refused
  const offPrimary = bound.filter((s) => s.role && s.role !== "NORMAL").length;

  return [
    transceivers > 0 ? `${transceivers} transceiver${transceivers === 1 ? "" : "s"}` : "",
    receiveOnly > 0 ? `${receiveOnly} receive-only` : "",
    offPrimary > 0 ? `${offPrimary} on a backup host` : "",
    loadShape(bound),
    oldestUp(bound),
  ];
}

/**
 * A listener's binds belong to customers, so the questions are about who: how many distinct
 * accounts, how many cannot submit, and which one is carrying the traffic.
 */
function listenerParts(sessions: readonly HealthSession[]): string[] {
  const bound = sessions.filter((s) => s.bound);
  const accounts = new Set(bound.map((s) => s.account).filter(Boolean));
  const receiveOnly = bound.filter((s) => s.bind_type === "RECEIVER").length;
  const busiest = [...bound]
    .filter((s) => (s.submitted ?? 0) > 0)
    .sort((a, b) => (b.submitted ?? 0) - (a.submitted ?? 0))[0];

  return [
    accounts.size > 0 ? `${accounts.size} account${accounts.size === 1 ? "" : "s"}` : "",
    receiveOnly > 0 ? `${receiveOnly} receive-only` : "",
    busiest?.account ? `busiest is ${busiest.account}` : "",
    oldestUp(bound),
  ];
}

/**
 * Whether the work is spread or resting on one bind.
 *
 * <p>The reading a bind count cannot give: five sessions each carrying a fifth, and five sessions
 * where one carries everything, are the same "5 binds". The second is a vendor about to be a
 * single point of failure, or four binds that are quietly dead.
 *
 * <p>Silent below two counting sessions, and silent when nothing has been sent — "evenly loaded"
 * across a set of zeroes would be true and useless.
 */
function loadShape(sessions: readonly HealthSession[]): string {
  const counting = sessions.filter((s) => s.submitted != null);
  if (counting.length < 2) {
    return "";
  }
  const total = counting.reduce((n, s) => n + (s.submitted ?? 0), 0);
  if (total === 0) {
    return "";
  }
  const top = Math.max(...counting.map((s) => s.submitted ?? 0));
  //two thirds on one bind out of three or more is the point where "spread across the binds" stops
  //being a fair description of what is happening
  return top / total >= 0.66 && counting.length > 2 ? "one bind carrying most of it" : "evenly loaded";
}

function oldestUp(sessions: readonly HealthSession[]): string {
  const ages = sessions.map((s) => s.bound_seconds).filter((n): n is number => n != null);
  return ages.length ? `oldest up ${duration(Math.max(...ages))}` : "";
}

/**
 * How much of the worker's traffic went over one bind, as a fraction.
 *
 * @returns null when there is nothing to divide by, so the caller renders no bar rather than a
 *     bar of zero — "carried none of it" and "nothing was carried" are different statements
 */
export function shareOf(submitted: number | null | undefined, total: number): number | null {
  if (submitted == null || total <= 0) {
    return null;
  }
  return submitted / total;
}

/** The submit_sm counted across the sample, which is what a share is a share of. */
export function bindTotal(sessions: readonly HealthSession[]): number {
  return sessions.reduce((n, s) => n + (s.submitted ?? 0), 0);
}

/**
 * Whether the snapshot's session array is the whole set or a sample of it.
 *
 * <p>`/ops/health` caps the array at twenty rows per worker and reports the real count separately,
 * so for a five-bind vendor the array already <em>is</em> every session and fetching them again
 * over the network buys nothing. A listener holding four hundred customers is the case the paged
 * browser exists for.
 *
 * <p>Compares against the array length rather than against the cap, so raising or lowering the
 * gateway's cap needs no corresponding change here.
 */
export function sessionsAreComplete(
  total: number | null | undefined,
  sampleLength: number
): boolean {
  return total == null || total <= sampleLength;
}

/** Session counts as a phrase, for the fallback case where the table is showing a sample. */
export function sampleNote(total: number, shown: number): string {
  return total > shown ? `${count(shown)} of ${count(total)} shown` : "";
}
