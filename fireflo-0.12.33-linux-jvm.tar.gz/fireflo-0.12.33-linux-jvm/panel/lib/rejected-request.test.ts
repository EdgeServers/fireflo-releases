import { test } from "node:test";
import assert from "node:assert/strict";
import {
  EMPTY_REJECTED_FILTERS,
  NO_ALL_TIME_REFUSALS,
  SUMMARY_SAMPLE,
  fromQuery,
  hasActiveFilters,
  isRejectedFilterError,
  parseRejectedFilters,
  toQuery,
  type RejectedFilterForm,
} from "./rejected-request.ts";
import { MAX_RANGE_DAYS } from "./date-range.ts";

/**
 * The Refused page's filters, as they travel.
 *
 * <p>Two of these guard links that already exist in the wild and would fail silently: the Delivery
 * check builds `/cp/rejected?reason=<token>` from whatever the database contained, and the page this
 * replaced took its window from `?hours=`. Both must keep landing somewhere sensible.
 */

const NOW = new Date("2026-08-18T12:00:00.000Z");

function hoursBefore(at: Date | null | undefined): number {
  assert.ok(at, "expected a window");
  return Math.round((NOW.getTime() - at.getTime()) / 3_600_000);
}

function parsed(query: string) {
  const value = parseRejectedFilters(new URLSearchParams(query), NOW);
  assert.ok(!isRejectedFilterError(value), `expected filters, got ${JSON.stringify(value)}`);
  return value;
}

test("a Delivery-check deep link keeps its reason and gets the default window", () => {
  //those links carry no range at all. Defaulting to "everything" would scan the whole table; not
  //defaulting at all would show an empty page for a finding that just said there were refusals
  const filters = parsed("reason=headerNotApproved");
  assert.equal(filters.reason, "headerNotApproved");
  assert.equal(hoursBefore(filters.since), 24);
});

test("an unknown reason token passes through rather than 400ing the page", () => {
  //the gateway writes these, not us. Validating against a known set would break the page and the
  //link that produced it on the day a new refusal reason shipped
  const filters = parsed("reason=somethingNewTheGatewayAdded");
  assert.equal(filters.reason, "somethingNewTheGatewayAdded");
});

test("an unknown range is refused, because a silently ignored one shows the wrong period", () => {
  const value = parseRejectedFilters(new URLSearchParams("range=lastfortnight"), NOW);
  assert.ok(isRejectedFilterError(value));
  assert.match(value.error, /Unknown range/);
});

test("the retired hours parameter still selects a window", () => {
  assert.equal(hoursBefore(parsed("hours=1").since), 1);
  assert.equal(hoursBefore(parsed("hours=168").since), 168);
  //and a range, when both are present, wins -- `hours` is the compatibility path, not a second
  //source of truth
  assert.equal(hoursBefore(parsed("range=1h&hours=168").since), 1);
});

test("hours also lights up the matching button, so a legacy link does not look ignored", () => {
  assert.equal(fromQuery(new URLSearchParams("hours=168")).range, "7d");
  assert.equal(fromQuery(new URLSearchParams("hours=1")).range, "1h");
  //no shortcut matches 3 hours, so the form keeps its default rather than inventing a button
  assert.equal(fromQuery(new URLSearchParams("hours=3")).range, "24h");
});

test("there is no all-time view of refusals: the period is capped, in a sentence the page shows", () => {
  //`q` is an ILIKE '%x%' across seven columns and the summary is an aggregate over the window;
  //neither has anything to walk without rejected_at. The query layer used to substitute 24 hours
  //silently, which showed one day under a heading that said "All time"
  const value = parseRejectedFilters(new URLSearchParams("range=all"), NOW);
  assert.ok(isRejectedFilterError(value));
  assert.equal(value.error, NO_ALL_TIME_REFUSALS);
  assert.equal(value.error, `Choose a period of at most ${MAX_RANGE_DAYS} days. Refusals cannot be listed over all time.`);

  //and the retired parameter cannot reopen it: hours=0 was its spelling of "everything"
  assert.ok(isRejectedFilterError(parseRejectedFilters(new URLSearchParams("hours=0"), NOW)));
});

test("a typed window is capped at the same width as every other export", () => {
  const daysAgo = (days: number) => new Date(NOW.getTime() - days * 86_400_000).toISOString();

  const tooWide = parseRejectedFilters(new URLSearchParams(`since=${daysAgo(MAX_RANGE_DAYS + 8)}`), NOW);
  assert.ok(isRejectedFilterError(tooWide));
  assert.equal(tooWide.error, `That is ${MAX_RANGE_DAYS + 8} days. Ask for at most ${MAX_RANGE_DAYS} at a time.`);

  //the limit itself, the longest shortcut, and a search inside one are all fine
  assert.ok(!isRejectedFilterError(parseRejectedFilters(new URLSearchParams(`since=${daysAgo(MAX_RANGE_DAYS)}`), NOW)));
  assert.equal(parsed("range=30d&q=shipped").search, "shipped");
});

test("the first-page summary is a bounded sample, within what the query layer will honour", () => {
  //`summariseRejected` clamps sampleLimit to 100,000 and wraps the scan in `LIMIT n`; a constant
  //above that would make the route claim a sample size it did not get. And it must resolve at
  //least what the Delivery check resolves, or the Refused page would be the less informative of
  //the two views of the same table
  assert.ok(Number.isInteger(SUMMARY_SAMPLE) && SUMMARY_SAMPLE > 0);
  assert.ok(SUMMARY_SAMPLE <= 100_000, "summariseRejected's ceiling");
  //5,000 is `REFUSAL_SAMPLE` in delivery-check.ts, which cannot be imported here: it opens a pool
  assert.ok(SUMMARY_SAMPLE >= 5_000, "no coarser than the Delivery check");
});

test("an over-long search is refused rather than truncated", () => {
  //a silently shortened phrase returns rows that do not contain what was typed, and the searcher
  //has no way to tell that from a real match
  const value = parseRejectedFilters(new URLSearchParams(`q=${"x".repeat(1601)}`), NOW);
  assert.ok(isRejectedFilterError(value));
  assert.match(value.error, /longer than 1600/);
});

test("a vendor status must be the decimal an operator reads on the page", () => {
  assert.equal(parsed("vendorStatus=69").vendorStatus, 69);
  const value = parseRejectedFilters(new URLSearchParams("vendorStatus=0x45"), NOW);
  assert.ok(isRejectedFilterError(value), "0x45 would otherwise match every refusal in the window");
});

test("the two flags are only on when explicitly set", () => {
  assert.equal(parsed("hasMsgId=1").hasMsgId, true);
  assert.equal(parsed("afterAccepting=1").afterAccepting, true);
  assert.equal(parsed("hasMsgId=0&afterAccepting=false").hasMsgId, undefined);
  assert.equal(parsed("").afterAccepting, undefined);
});

test("a bad timestamp is refused rather than becoming an Invalid Date in the SQL", () => {
  const value = parseRejectedFilters(new URLSearchParams("since=yesterday"), NOW);
  assert.ok(isRejectedFilterError(value));
});

test("every form field round trips through the query string", () => {
  const form: RejectedFilterForm = {
    range: "7d",
    reason: "vendorRejected",
    account: "acct-1",
    systemId: "sys-1",
    product: "india-tr",
    ingress: "SMPP",
    inGateway: "smppserver.in",
    source: "ACME",
    dest: "9199",
    msgId: "gw-1",
    vendorStatus: "69",
    hasMsgId: "1",
    afterAccepting: "1",
    q: "shipped",
  };

  assert.deepEqual(fromQuery(toQuery(form)), form);
});

test("only what is set reaches the URL, so a shared link reads as what was chosen", () => {
  const params = toQuery({ ...EMPTY_REJECTED_FILTERS, reason: "filtered" });
  assert.equal(params.toString(), "reason=filtered");
  assert.equal(toQuery(EMPTY_REJECTED_FILTERS).toString(), "");
});

test("the default window alone does not count as an active filter", () => {
  //what a "clear filters" button keys off. Counting the range would leave it permanently visible
  assert.equal(hasActiveFilters(EMPTY_REJECTED_FILTERS), false);
  assert.equal(hasActiveFilters({ ...EMPTY_REJECTED_FILTERS, range: "7d" }), false);
  assert.equal(hasActiveFilters({ ...EMPTY_REJECTED_FILTERS, account: "acct-1" }), true);
});
