import { test } from "node:test";
import assert from "node:assert/strict";
import {
  duplicateTlvKeys,
  formatTlvCsv,
  parseTlvCsv,
  proposedTlvs,
  tlvCsvProblem,
  tlvPairProblem,
  tlvTokenProblem,
} from "./tlv-string.ts";

/**
 * The stored stamp format, which the gateway parses with `TlvUtil.parseDefaults`.
 *
 * <p>These cases are written from the Java rather than from what looks reasonable, because the two
 * have to agree: an editor that accepted something the gateway discards produces a setting that
 * looks saved and does nothing, which is exactly the live bug that prompted this work — a real
 * account carrying `PEID=1401778070000018542`, a token with no parseable tag, attaching nothing to
 * any message and saying so nowhere.
 */

test("round-trips the ordinary form", () => {
  const csv = "peid_0x1400=1101,tmid_0x1402=ABC";
  assert.deepEqual(parseTlvCsv(csv), [
    { key: "peid_0x1400", value: "1101" },
    { key: "tmid_0x1402", value: "ABC" },
  ]);
  assert.equal(formatTlvCsv(parseTlvCsv(csv)), csv);
});

test("empty in, empty out, and null rather than an empty string", () => {
  assert.deepEqual(parseTlvCsv(null), []);
  assert.deepEqual(parseTlvCsv(""), []);
  assert.equal(formatTlvCsv([]), null);
  //a pair with no key is not a pair
  assert.equal(formatTlvCsv([{ key: "  ", value: "x" }]), null);
});

test("splits on the FIRST equals, so a value may contain one", () => {
  //parseDefaults uses indexOf, not split -- a base64 value ending in '=' has to survive
  assert.deepEqual(parseTlvCsv("k_1=a=b"), [{ key: "k_1", value: "a=b" }]);
});

test("an entry with no equals is kept, not silently dropped", () => {
  //the gateway discards it; an editor that also discarded it would delete what the operator typed
  //in front of them, leaving nothing to correct
  assert.deepEqual(parseTlvCsv("peid_0x1400"), [{ key: "peid_0x1400", value: "" }]);
});

test("whitespace around entries and around the equals is not significant", () => {
  assert.deepEqual(parseTlvCsv(" a_1 = x , b_2 = y "), [
    { key: "a_1", value: "x" },
    { key: "b_2", value: "y" },
  ]);
});

test("a value containing a comma is refused rather than silently truncated", () => {
  //nothing is escaped, so storing this would produce two entries and the gateway would drop the
  //second for having no '='. The operator has to know before saving
  const problem = tlvPairProblem({ key: "k_1", value: "a,b" });
  assert.match(problem ?? "", /comma/);
  assert.match(problem ?? "", /hex:/, "and be told what to use instead");

  assert.equal(tlvPairProblem({ key: "k_1", value: "plain" }), null);
});

test("duplicate keys are reported, because the gateway keeps the first and says nothing", () => {
  assert.deepEqual(
    duplicateTlvKeys([
      { key: "peid_0x1400", value: "1" },
      { key: "PEID_0x1400", value: "2" },
    ]),
    ["PEID_0x1400"]
  );
  assert.deepEqual(duplicateTlvKeys([{ key: "a_1", value: "" }, { key: "b_2", value: "" }]), []);
});

test("the live broken stamp survives a round trip so it can be corrected", () => {
  //'PEID' has no underscore, so parseTag cannot read a tag out of it and the gateway logs and
  //ignores the entry. This module's job is not to judge that -- TlvTokenInput does, from the
  //catalogue -- but it must not mangle it on the way to the editor
  const pairs = parseTlvCsv("PEID=1401778070000018542");
  assert.deepEqual(pairs, [{ key: "PEID", value: "1401778070000018542" }]);
  assert.equal(tlvPairProblem(pairs[0]), null, "the format is fine; the tag is the problem");
  assert.equal(formatTlvCsv(pairs), "PEID=1401778070000018542");
});

/**
 * What a customer may put in `requested_tlvs`.
 *
 * <p>This is the one place in the panel where text a customer typed becomes a configuration value,
 * so the refusals matter more than usual — and every one of them has to be a rule the *format*
 * imposes rather than a judgement about the tag, because a proposal is inert until an operator
 * accepts it and the catalogue it would be judged against can change under it.
 */

test("a proposal is normalised to the shape the operator's editor produces", () => {
  const result = proposedTlvs("  peid_0x1400 = 1401778070000018542 ,, tmplid_0x1401=1234 ");
  assert.deepEqual(result, { value: "peid_0x1400=1401778070000018542,tmplid_0x1401=1234" });
});

test("nothing proposed is null, not an empty string, so the column has one empty value", () => {
  assert.deepEqual(proposedTlvs(undefined), { value: null });
  assert.deepEqual(proposedTlvs(null), { value: null });
  assert.deepEqual(proposedTlvs(""), { value: null });
  assert.deepEqual(proposedTlvs("   "), { value: null }, "whitespace is nothing too");
});

test("a value with a comma is refused rather than silently split", () => {
  const result = proposedTlvs("peid_0x1400=one,two");
  //parseTlvCsv splits on the comma first, so this arrives as a second entry with no '=' -- the
  //refusal comes from that entry having no name, which is the same outcome and a clearer sentence
  assert.ok("error" in result, "a comma in a value has to be refused somewhere");
});

test("a duplicate name is refused, because the gateway keeps the first and says nothing", () => {
  const result = proposedTlvs("peid_0x1400=1,PEID_0x1400=2");
  assert.ok("error" in result);
  assert.match((result as { error: string }).error, /twice/);
});

test("an entry with no name is refused", () => {
  assert.ok("error" in proposedTlvs("=1234"));
});

test("a customer's proposal is held to the same token grammar as an operator's", () => {
  //This asserted the opposite until a live sender ID turned up stamping `1401=...` -- tag 1401
  //rather than 0x1401 -- with nothing anywhere having said so. The old reasoning was that the
  //CATALOGUE may change under a stored value, which is true and is still why nothing here judges
  //whether a tag is *known*. The grammar cannot change, and this is a grammar rule.
  //
  //One rule for both sides on purpose: the operator's field and the customer's proposal having
  //different validation is exactly how they came to disagree in the first place.
  assert.ok("error" in proposedTlvs("PEID=1401778070000018542"));
  assert.ok("error" in proposedTlvs("1401=1401778070000018542"));
  assert.deepEqual(proposedTlvs("peid_0x1400=1401778070000018542"),
    { value: "peid_0x1400=1401778070000018542" });
});

test("something that is not a string is refused rather than coerced", () => {
  assert.ok("error" in proposedTlvs(42));
  assert.ok("error" in proposedTlvs({ peid_0x1400: "1" }));
  assert.ok("error" in proposedTlvs(["peid_0x1400=1"]));
});

test("an absurdly long proposal is refused before it reaches the column", () => {
  const long = Array.from({ length: 200 }, (_, i) => `t_${i}=${"9".repeat(20)}`).join(",");
  const result = proposedTlvs(long);
  assert.ok("error" in result, "text is unbounded and this is the only gate");
});

test("tlvCsvProblem passes null through, so 'nothing proposed' is never an error", () => {
  assert.equal(tlvCsvProblem(null), null);
});

/**
 * The token grammar, refused rather than warned about.
 *
 * <p>Every case here is a real shape this deployment has held: `1401=…` was live on a sender ID and
 * stamping tag 1401 rather than 0x1401, and `PEID=…` before it stamped nothing at all. The rule is
 * only safe to make a refusal because it blocks no meaning — each one is still reachable, spelled so
 * that it reads one way.
 */

test("a bare-digit token is refused, and the message names both readings", () => {
  const problem = tlvTokenProblem("1401");
  assert.ok(problem, "the live misconfiguration would still save");
  assert.match(problem, /tag 1401/, "it has to say what it actually resolves to");
  assert.match(problem, /5121/, "and what the other reading would be");
  assert.match(problem, /name_0x1401/, "and the shape to write instead");
  assert.match(problem, /tlv_1401/, "and the escape hatch, or this refuses a legitimate intent");
});

test("the same token inside a whole csv is refused", () => {
  const problem = tlvCsvProblem("1401=1401778070000018542");
  assert.ok(problem);
  assert.match(problem, /name_0x1401/);
});

test("a token carrying no tag at all is refused", () => {
  //the older live shape: parseTag finds no digits, the gateway logs and skips, and the stamp has
  //been attaching nothing to any message
  const problem = tlvTokenProblem("PEID");
  assert.ok(problem);
  assert.match(problem, /carries no tag/);
  assert.match(problem, /peid_0x1400/);
  assert.ok(tlvCsvProblem("PEID=1401778070000018542"));
});

test("both unambiguous spellings are accepted", () => {
  assert.equal(tlvTokenProblem("tmplid_0x1401"), null);
  assert.equal(tlvTokenProblem("tlv_1401"), null, "decimal 1401 must stay reachable");
  assert.equal(tlvCsvProblem("tmplid_0x1401=1234"), null);
  assert.equal(tlvCsvProblem("peid_0x1400=1,tmplid_0x1401=2"), null);
});

test("a named token whose tag does not parse is still refused", () => {
  //an underscore is not enough on its own -- `foo_bar` has one and yields no tag
  assert.ok(tlvTokenProblem("foo_bar"));
});

test("a bare hex tag is refused for having no name", () => {
  //unambiguous, so this is the strict end of the rule: it reads one way, but a call record showing
  //a bare 0x1400 tells nobody what it was for
  const problem = tlvTokenProblem("0x1400");
  assert.ok(problem);
  assert.match(problem, /name_0x1400/);
});

test("an empty token is not the token rule's problem", () => {
  //`tlvCsvProblem` already refuses an entry with no name before the token is looked at, and two
  //messages for one mistake is worse than one
  assert.equal(tlvTokenProblem(""), null);
  assert.equal(tlvTokenProblem("   "), null);
});
