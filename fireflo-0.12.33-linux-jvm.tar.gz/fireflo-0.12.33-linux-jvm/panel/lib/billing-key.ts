/**
 * The billing key a credential resolves to, in SQL.
 *
 * <p>Mirrors `billingOf()` in `credential-types.ts`, which mirrors the gateway: an explicit account
 * wins; otherwise SMPP — and HTTP without an api key — bill to the system id. HTTP with an api key
 * bills to the key itself, which is a secret and must never appear in a listing, so it resolves to
 * NULL here and simply does not count towards any account.
 *
 * <p>The fallback is not a convenience. `BasicSmppSessionContext` derives `accountId` from
 * `system_id` whenever `account_id` is blank, so a login with no explicit account still bills, still
 * has rates matched against it, and still appears in call records — under a name that exists nowhere
 * in `app_credential.account_id`. A query that reads that column raw sees an account that is not
 * there.
 *
 * <p>Its own module because three call sites now need it and a third hand-written copy is a third
 * chance to drift from the gateway. No `pg` import, so this stays usable from anywhere.
 */
export const BILLING_KEY = `CASE
  WHEN account_id IS NOT NULL AND btrim(account_id) <> '' THEN btrim(account_id)
  WHEN type = 'SMPP' THEN NULLIF(btrim(COALESCE(system_id, '')), '')
  WHEN api_key IS NOT NULL AND btrim(api_key) <> '' THEN NULL
  ELSE NULLIF(btrim(COALESCE(system_id, '')), '')
END`;
