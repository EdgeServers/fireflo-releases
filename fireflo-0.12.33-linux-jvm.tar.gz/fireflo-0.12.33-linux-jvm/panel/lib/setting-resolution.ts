/**
 * Where a worker setting's value actually comes from.
 *
 * <h2>The gateway has three tiers and the panel used to see one</h2>
 *
 * <p>`FireFloConfigurationHandler.get()` resolves a worker property in order: the worker's own key,
 * then a gateway-wide default, then the literal compiled into the Java. The middle tier is the one
 * that was invisible here — when a listener has no value of its own, the handler rewrites
 * `outSms.instance.<name>.<prop>` into `outSms.default.<prop>` and looks again.
 *
 * <p>So "not set" never meant "the coded default". It meant "ask the tier above", and this panel
 * answered for that tier by reading a snapshot of a Java file — right until somebody set a gateway
 * default, at which point every unset field on every worker was quietly wrong. Three separate
 * components said in their own comments that they could not read those keys and guessed anyway.
 *
 * <p>One reader, because two things deciding the same thing is how they come to disagree. Pure and
 * database-free so the rule can be tested without a gateway, a Postgres or a worker.
 */

/** Which tier answered. Ordered widest-last, the way the gateway resolves. */
export type SettingSource = "worker" | "gateway" | "coded";

export interface ResolvedSetting {
  /** The value the gateway will actually parse. */
  value: string;
  source: SettingSource;
  /**
   * The gateway-wide value, whatever won.
   *
   * <p>Carried separately so a field can say "inheriting `replace`" while an overridden one says
   * "set to `off`, the gateway default is `replace`" — the second is the sentence an operator needs
   * when they are looking at a kill switch and wondering what it is killing.
   */
  gatewayDefault: string | null;
}

/**
 * Resolves one setting the way the gateway would.
 *
 * <p><strong>Blank is not a value.</strong> An empty string at any tier means "nothing set here" and
 * falls through, which is the same rule `setWorkerProperty` enforces by deleting a row rather than
 * storing `''`. Without that, "inherit" cannot be expressed at all — only "set to blank" — and the
 * kill switch has nothing to switch back to.
 *
 * @param workerValue the worker's own value, or null/blank when it has none
 * @param gatewayDefault the `outSms.default.<key>` value, or null when unset **or unreadable**.
 *     The caller must have already decided which — see `lib/gateway-settings.ts`, where null means
 *     "could not be read" and is deliberately not the same as "off"
 * @param codedDefault the literal from the gateway source, which is a snapshot and never written
 */
export function resolveSetting(
  workerValue: string | null | undefined,
  gatewayDefault: string | null | undefined,
  codedDefault: string
): ResolvedSetting {
  const gateway = blankToNull(gatewayDefault);
  const own = blankToNull(workerValue);

  if (own !== null) {
    return { value: own, source: "worker", gatewayDefault: gateway };
  }
  if (gateway !== null) {
    return { value: gateway, source: "gateway", gatewayDefault: gateway };
  }
  return { value: codedDefault, source: "coded", gatewayDefault: null };
}

/**
 * Whether this worker is overriding a gateway default rather than merely setting a value.
 *
 * <p>The distinction the UI needs: setting a value where no default exists is ordinary
 * configuration, and setting one that contradicts a default is a deliberate exception — a kill
 * switch, usually — and worth showing as such.
 */
export function overridesGatewayDefault(resolved: ResolvedSetting): boolean {
  return (
    resolved.source === "worker" &&
    resolved.gatewayDefault !== null &&
    resolved.gatewayDefault !== resolved.value
  );
}

/**
 * What a field falls back to when the worker sets nothing.
 *
 * <p>The same chain as {@link resolveSetting} asked one tier down: the gateway-wide value if there
 * is one, otherwise the literal from the gateway source. Exists so the worker form's three "not
 * set" renderings -- an enum label, an input placeholder, a toggle's target -- go through this
 * module instead of each writing `inherited ?? codedDefault` for themselves. That is how the rule
 * came to be written in three places to begin with.
 */
export function fallbackFor(
  gatewayDefault: string | null | undefined,
  codedDefault: string
): { value: string; inherited: boolean } {
  const gateway = blankToNull(gatewayDefault);
  return gateway !== null
    ? { value: gateway, inherited: true }
    : { value: codedDefault, inherited: false };
}

function blankToNull(value: string | null | undefined): string | null {
  if (value === null || value === undefined) return null;
  return value.trim() === "" ? null : value;
}
