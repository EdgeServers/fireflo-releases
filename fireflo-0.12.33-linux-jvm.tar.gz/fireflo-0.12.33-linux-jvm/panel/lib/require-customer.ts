import { misAuth } from "@/lib/mis-auth";
import { CUSTOMER_ROLE } from "@/lib/roles";
import { configQuery } from "@/lib/config-db";
import { recordCustomerAccess } from "@/lib/customer-access-log";
import { requestContext } from "@/lib/request-context";
import { sessionPredatesPasswordChange } from "@/lib/session-freshness";

/**
 * The gate on every portal route, and the rule that decides what a session may see.
 *
 * <p>Server-only: importing this pulls `pg`.
 *
 * <h2>The invariant</h2>
 *
 * <p><strong>The account comes from the session. Never from a parameter, a header or a body.</strong>
 *
 * <p>That reads as obvious and is the single easiest thing to get wrong here, because the query
 * layer already accepts an account filter: `searchCdrs` takes `accountId` in its filters, and the
 * portal parses the same query string the operator page does. Merging a parsed filter over the
 * session's account would let `?account=someone-else` widen the scope. Every route therefore
 * *overwrites* the field after parsing rather than defaulting it.
 *
 * <p>A reseller may legitimately name one of its own accounts. That still does not relax the rule —
 * it goes through {@link assertInScope}, which checks the named account against the session's scope
 * before anything is done with it.
 */

export interface CustomerSession {
  /** The account that signed in. */
  accountId: string;
  /** The person who signed in: the `app_user` row. */
  userId: number;
  /** Whether it holds other accounts beneath it. */
  resells: boolean;
}

export class NotCustomerError extends Error {
  constructor() {
    super("Not found");
    this.name = "NotCustomerError";
  }
}

/**
 * @throws NotCustomerError which routes turn into a 404, matching `requireOperator` -- a 403
 *     confirms the endpoint exists, which is more than an anonymous caller needs to know
 */
export async function requireCustomer(): Promise<CustomerSession> {
  const session = await misAuth();
  const user = session?.user;
  if (!user?.accountId || user.role !== CUSTOMER_ROLE || user.userId == null) {
    throw new NotCustomerError();
  }
  const userId = Number(user.userId);

  //read fresh rather than trusted from the token: a session outlives a change, and an account that
  //stopped reselling -- or was disabled -- an hour ago must not still be acting as one. The person
  //is checked the same way: a user disabled by their reseller is out on the next request
  const rows = await configQuery<{
    resells: boolean;
    enabled: boolean;
    user_enabled: boolean | null;
    password_changed_at: Date | string | null;
  }>(
    `SELECT a.resells, a.enabled, u.enabled AS user_enabled, u.password_changed_at
       FROM app_account a
       LEFT JOIN app_user u ON u.id = $2 AND u.account_id = a.id AND u.role = 'customer'
      WHERE a.id = $1`,
    [user.accountId, userId]
  );
  if (!rows.length || !rows[0].enabled || !rows[0].user_enabled) {
    throw new NotCustomerError();
  }
  //signed in under a password that has since been set, changed or removed -- by the customer, their
  //reseller or an operator: refused like a disabled login (CP-S4; lib/session-freshness.ts)
  if (sessionPredatesPasswordChange(user.passwordChangedAt, rows[0].password_changed_at)) {
    throw new NotCustomerError();
  }

  await notePortalAccess(user.accountId, userId);
  return { accountId: user.accountId, userId, resells: rows[0].resells };
}

/**
 * As {@link requireCustomer}, and additionally that this account holds others beneath it.
 *
 * <p>Refused with the same {@link NotCustomerError} rather than a distinct one, so an account that
 * does not resell has no business learning that the reseller routes exist. That is the rule
 * `/api/mis/transfer` already applies by hand — this is the same decision in one place, now that
 * six routes make it.
 *
 * <p>`resells` comes from {@link requireCustomer}, which reads it fresh from the row rather than
 * from the token: a session outlives a change, and an account whose reseller flag was cleared an
 * hour ago must not still be acting as one.
 *
 * @throws NotCustomerError which routes turn into a 404
 */
export async function requireReseller(): Promise<CustomerSession> {
  const session = await requireCustomer();
  if (!session.resells) {
    throw new NotCustomerError();
  }
  return session;
}

/**
 * Which account a write is *for*: the caller's own, or a child it named.
 *
 * <p>For the routes a reseller may use on a customer's behalf — a sender ID or a template requested
 * while onboarding somebody. The field is optional and absent means "me", so an ordinary customer's
 * request is unchanged and cannot accidentally acquire a subject.
 *
 * <p><strong>A named account still goes through {@link assertInScope}.</strong> That is the whole
 * mechanism: the id arrives from the request, so it is proved against the session's own children
 * before it is used for anything at all, and a stranger's id answers the same 404 an unauthenticated
 * call gets.
 *
 * @throws NotCustomerError when the named account is not one of this session's children
 */
export async function subjectAccount(
  session: CustomerSession,
  asked: unknown
): Promise<string> {
  const wanted = typeof asked === "string" ? asked.trim() : "";
  if (!wanted || wanted === session.accountId) {
    return session.accountId;
  }
  await assertInScope(session, wanted);
  return wanted;
}

/**
 * How recently this account was seen from this address, so the table records visits and not requests.
 *
 * <p>`requireCustomer` runs on every portal route, and the portal polls. One row per XHR would be
 * thousands a day per customer and unreadable; one row per account per address per hour is a usable
 * record of who was there.
 *
 * <p>Bounded rather than unbounded: the map is cleared wholesale when it grows past a few thousand
 * keys, which costs at most one duplicate row per account and cannot become a memory leak on a
 * process that stays up for months.
 */
const PORTAL_WINDOW_MS = 60 * 60 * 1000;
const PORTAL_KEYS_MAX = 5_000;
const seen = new Map<string, number>();

async function notePortalAccess(accountId: string, userId: number): Promise<void> {
  const context = await requestContext();
  const ip = context.ip;
  const key = `${accountId}|${userId}|${ip ?? "-"}`;
  const now = Date.now();
  const last = seen.get(key);
  if (last && now - last < PORTAL_WINDOW_MS) {
    return;
  }
  if (seen.size >= PORTAL_KEYS_MAX) {
    seen.clear();
  }
  seen.set(key, now);
  void recordCustomerAccess({
    event: "portal_access",
    accountId,
    userId,
    ip,
    userAgent: context.userAgent,
  });
}

/**
 * Every account this session may see: itself, plus its children when it resells.
 *
 * <p>One query and no recursion, because the schema is two levels by construction — a composite
 * foreign key forces a parent to be a reseller and a CHECK stops a child reselling, so there is no
 * deeper tree to walk and no cycle to guard against.
 */
export async function scopeFor(session: CustomerSession): Promise<string[]> {
  if (!session.resells) {
    return [session.accountId];
  }
  const rows = await configQuery<{ id: string }>(
    "SELECT id FROM app_account WHERE parent_account_id = $1 ORDER BY id",
    [session.accountId]
  );
  return [session.accountId, ...rows.map((r) => r.id)];
}

/**
 * Confirms a named account is one this session may act on.
 *
 * <p>For the routes that legitimately take an account — a reseller transferring balance to one of
 * its own, or editing that account's approved senders. The id arrives from the request, so it is
 * checked against the scope before it is used for anything at all.
 *
 * <p>Refused with the same {@link NotCustomerError} as an unauthenticated call, so that naming
 * somebody else's account cannot be used to discover that it exists.
 *
 * @throws NotCustomerError when the account is not the session's own or one of its children
 */
export async function assertInScope(session: CustomerSession, accountId: string): Promise<void> {
  const wanted = (accountId ?? "").trim();
  if (!wanted) {
    throw new NotCustomerError();
  }
  if (wanted === session.accountId) {
    return;
  }
  if (!session.resells) {
    throw new NotCustomerError();
  }
  const rows = await configQuery<{ id: string }>(
    "SELECT id FROM app_account WHERE id = $1 AND parent_account_id = $2",
    [wanted, session.accountId]
  );
  if (!rows.length) {
    throw new NotCustomerError();
  }

  //a reseller reading a child's data. Rare, legitimate, and the single most useful row in the
  //table: it is the only place one customer's identity touches another's records
  const context = await requestContext();
  void recordCustomerAccess({
    event: "cross_account_access",
    accountId: session.accountId,
    ip: context.ip,
    userAgent: context.userAgent,
    detail: { reached: wanted },
  });
}
