/**
 * The message broker's settings as a form, and the AMQP URI they are stored as.
 *
 * <p>The gateway keeps the broker in `app_config` as one URI, `smsg.queue.amqp.uri`, with the
 * password inside it. That key is a secret (app_config_key), so the browser never sees it: the
 * form carries host, port, vhost and user, the password only when it is being changed, and the
 * URI is put together on the server.
 *
 * <p>Pure, no database import: the Queues page uses the types and the validation as they are.
 */

export const BROKER_KEYS = {
  provider: "smsg.queue.provider",
  uri: "smsg.queue.amqp.uri",
  queue: "smsg.queue.amqp.queue",
  prefetch: "smsg.queue.amqp.prefetch",
  channels: "smsg.queue.amqp.channels",
  highwater: "smsg.queue.amqp.highwater",
  confirmMs: "smsg.queue.amqp.publish.confirm.ms",
} as const;

/** The gateway's own defaults (`AmqpQueueBridge`), shown as placeholders and never written. */
export const BROKER_DEFAULTS = {
  queue: "fireflo.submit",
  prefetch: "200",
  channels: "8",
  highwater: "100000",
  confirmMs: "5000",
} as const;

export type BrokerProvider = "memory" | "rabbitmq";

export interface BrokerForm {
  provider: BrokerProvider;
  tls: boolean;
  host: string;
  /** Blank is the scheme's default: 5672, or 5671 over TLS. */
  port: string;
  /** As `rabbitmqctl list_vhosts` prints it: `/` is the default, `/fireflo` is not `fireflo`. */
  vhost: string;
  user: string;
  /** A new password, or null to keep the stored one. */
  password: string | null;
  queue: string;
  prefetch: string;
  channels: string;
  highwater: string;
  confirmMs: string;
}

/** What the server sends the page: the form without any password, and whether one is stored. */
export interface BrokerView {
  form: BrokerForm;
  passwordSet: boolean;
}

export interface AmqpParts {
  tls: boolean;
  host: string;
  port: string;
  vhost: string;
  user: string;
  password: string;
}

/**
 * Reads an AMQP URI the way the RabbitMQ Java client does, or null when it is not one.
 *
 * <p>The vhost is the path with its leading slash taken off and then decoded, so `/%2Ffireflo` is
 * the vhost `/fireflo` and `/fireflo` is `fireflo`. No path at all is the default vhost, `/`.
 */
export function parseAmqpUri(uri: string): AmqpParts | null {
  let url: URL;
  try {
    url = new URL(uri.trim());
  } catch {
    return null;
  }
  if (url.protocol !== "amqp:" && url.protocol !== "amqps:") {
    return null;
  }
  const decode = (s: string) => {
    try {
      return decodeURIComponent(s);
    } catch {
      return s;
    }
  };
  return {
    tls: url.protocol === "amqps:",
    host: url.hostname.replace(/^\[(.*)\]$/, "$1"),
    port: url.port,
    vhost: url.pathname === "" ? "/" : decode(url.pathname.slice(1)),
    user: decode(url.username),
    password: decode(url.password),
  };
}

/** The URI for a set of parts. Every part is encoded, so a vhost or password may hold anything. */
export function buildAmqpUri(parts: AmqpParts): string {
  const host = parts.host.includes(":") ? `[${parts.host}]` : parts.host;
  const port = parts.port.trim() ? `:${parts.port.trim()}` : "";
  const auth = parts.user
    ? `${encodeURIComponent(parts.user)}${parts.password ? `:${encodeURIComponent(parts.password)}` : ""}@`
    : "";
  return `${parts.tls ? "amqps" : "amqp"}://${auth}${host}${port}/${encodeURIComponent(parts.vhost)}`;
}

/** A URI with its password replaced, for showing or logging. */
export function maskAmqpUri(uri: string): string {
  const parts = parseAmqpUri(uri);
  if (!parts) {
    return "(not an AMQP address)";
  }
  return buildAmqpUri({ ...parts, password: parts.password ? "****" : "" }).replace(":****@", ":••••@");
}

/**
 * Why the form cannot be saved or tested, or null when it can.
 *
 * <p>Under the in-process provider the broker fields are not read, so nothing about them is
 * checked: switching a broker off must not be blocked by a typo in the address being abandoned.
 */
export function brokerProblem(form: BrokerForm, passwordSet: boolean): string | null {
  if (form.provider === "memory") {
    return null;
  }
  const host = form.host.trim();
  if (!host) {
    return "Enter the broker's host.";
  }
  if (!/^[A-Za-z0-9.\-:]+$/.test(host)) {
    return `'${host}' is not a host name or IP address.`;
  }
  if (form.port.trim() && !inRange(form.port, 1, 65535)) {
    return "The port is a number from 1 to 65535.";
  }
  if (!form.vhost) {
    return "Enter the virtual host. The broker's default one is /.";
  }
  if (form.password !== null && form.password !== "" && !form.user.trim()) {
    return "A password needs a user name.";
  }
  if (form.password === null && !passwordSet && form.user.trim()) {
    return "Enter the password for this user.";
  }
  if (form.queue.trim() && !/^[A-Za-z0-9._:\-]{1,255}$/.test(form.queue.trim())) {
    return "The queue name takes letters, digits, '.', '_', ':' and '-'.";
  }
  const numbers: [string, string, number][] = [
    [form.prefetch, "Prefetch", 1],
    [form.channels, "Channels", 1],
    [form.highwater, "The high-water mark", 0],
    [form.confirmMs, "The publish confirm timeout", 100],
  ];
  for (const [value, label, min] of numbers) {
    if (value.trim() && !inRange(value, min, 2_147_483_647)) {
      return `${label} is a whole number of at least ${min}.`;
    }
  }
  return null;
}

function inRange(raw: string, min: number, max: number): boolean {
  const n = Number(raw.trim());
  return Number.isInteger(n) && n >= min && n <= max;
}

/** The form for what is stored. The password is never in it. */
export function formFromStored(stored: Map<string, string>): BrokerView {
  const parts = parseAmqpUri(stored.get(BROKER_KEYS.uri) ?? "");
  return {
    form: {
      provider: (stored.get(BROKER_KEYS.provider) ?? "").trim().toLowerCase() === "rabbitmq" ? "rabbitmq" : "memory",
      tls: parts?.tls ?? false,
      host: parts?.host ?? "",
      port: parts?.port ?? "",
      vhost: parts?.vhost ?? "/",
      user: parts?.user ?? "",
      password: null,
      queue: stored.get(BROKER_KEYS.queue) ?? "",
      prefetch: stored.get(BROKER_KEYS.prefetch) ?? "",
      channels: stored.get(BROKER_KEYS.channels) ?? "",
      highwater: stored.get(BROKER_KEYS.highwater) ?? "",
      confirmMs: stored.get(BROKER_KEYS.confirmMs) ?? "",
    },
    passwordSet: Boolean(parts?.password),
  };
}

/**
 * The URI the form describes, taking the stored password when the form keeps it.
 *
 * @param storedUri what `smsg.queue.amqp.uri` holds now, for its password
 */
export function uriForForm(form: BrokerForm, storedUri: string | null): string {
  const kept = form.password === null ? parseAmqpUri(storedUri ?? "")?.password ?? "" : form.password;
  return buildAmqpUri({
    tls: form.tls,
    host: form.host.trim(),
    port: form.port.trim(),
    vhost: form.vhost,
    user: form.user.trim(),
    password: form.user.trim() ? kept : "",
  });
}

/** The form from a request body, or why it is not one. */
export function parseBrokerForm(body: unknown): BrokerForm | string {
  if (!body || typeof body !== "object") {
    return "Expected a JSON body.";
  }
  const b = body as Record<string, unknown>;
  const text = (v: unknown) => (typeof v === "string" ? v : "");
  if (b.provider !== "memory" && b.provider !== "rabbitmq") {
    return "The provider is memory or rabbitmq.";
  }
  return {
    provider: b.provider,
    tls: b.tls === true,
    host: text(b.host),
    port: text(b.port),
    vhost: text(b.vhost),
    user: text(b.user),
    password: typeof b.password === "string" ? b.password : null,
    queue: text(b.queue),
    prefetch: text(b.prefetch),
    channels: text(b.channels),
    highwater: text(b.highwater),
    confirmMs: text(b.confirmMs),
  };
}
