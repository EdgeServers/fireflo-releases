//with the extension, because `node --test` runs these modules directly and does not read tsconfig
//paths or resolve extensionless specifiers
import { MAX_TEXT_FILTER, RANGES } from "./cdr-request.ts";
import { MAX_RANGE_DAYS, spanInDays } from "./date-range.ts";
import { ARCHIVE_STORES, BATCH_STORES } from "./archives-types.ts";

/**
 * The Archives report's filters as they travel: query string in, query string out.
 *
 * <p>Client-safe, like `rejected-request.ts`, and for the same reason: `archives.ts` opens a pool,
 * so the browser must reach the vocabulary without reaching the driver.
 *
 * <p>Identifiers are matched exactly — an account, a worker, a login, a batch — because each is a
 * key the gateway wrote verbatim and each has an index behind it; a fragment would be a scan.
 */

/** Which tab is open. In the URL, so a link to one batch's entries opens on the entries. */
export const ARCHIVE_TABS = ["partitions", "accounts", "entries", "batches"] as const;
export type ArchiveTab = (typeof ARCHIVE_TABS)[number];

export function isArchiveTab(value: string | null | undefined): value is ArchiveTab {
  return !!value && (ARCHIVE_TABS as readonly string[]).includes(value);
}

/** What the browser holds for the Entries tab. Every field a string, so one loop serialises it. */
export interface ArchiveEntryForm {
  range: string;
  account: string;
  /** A vendor (`smppclient.<n>`) or a listener (`smppserver.<n>`), as the archive row carries it. */
  worker: string;
  systemId: string;
  store: string;
  batch: string;
  msgId: string;
}

export const EMPTY_ARCHIVE_ENTRY_FORM: ArchiveEntryForm = {
  range: "7d",
  account: "",
  worker: "",
  systemId: "",
  store: "",
  batch: "",
  msgId: "",
};

/** What the query layer takes. */
export interface ArchiveEntryFilters {
  since?: Date | null;
  until?: Date | null;
  accountId?: string | null;
  worker?: string | null;
  systemId?: string | null;
  store?: string | null;
  batchId?: string | null;
  gatewayMsgId?: string | null;
}

/** The By account tab's period: whole days, inclusive at both ends, either may be open. */
export interface ArchiveAccountFilters {
  from?: string | null;
  to?: string | null;
  accountId?: string | null;
  store?: string | null;
}

const TEXT_FIELDS: [keyof ArchiveEntryForm, keyof ArchiveEntryFilters][] = [
  ["account", "accountId"],
  ["worker", "worker"],
  ["systemId", "systemId"],
  ["msgId", "gatewayMsgId"],
];

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const DAY = /^\d{4}-\d{2}-\d{2}$/;

export function isBatchId(value: string): boolean {
  return UUID.test(value);
}

/** Only what is set, so a shared link carries exactly the filters chosen. */
export function entryFormToQuery(form: ArchiveEntryForm): URLSearchParams {
  const params = new URLSearchParams();
  for (const key of Object.keys(EMPTY_ARCHIVE_ENTRY_FORM) as (keyof ArchiveEntryForm)[]) {
    const value = form[key].trim();
    if (value && value !== EMPTY_ARCHIVE_ENTRY_FORM[key]) {
      params.set(key, value);
    }
  }
  return params;
}

export function entryFormFromQuery(params: URLSearchParams): ArchiveEntryForm {
  const form = { ...EMPTY_ARCHIVE_ENTRY_FORM };
  for (const key of Object.keys(EMPTY_ARCHIVE_ENTRY_FORM) as (keyof ArchiveEntryForm)[]) {
    const value = params.get(key);
    if (value != null) {
      form[key] = value;
    }
  }
  return form;
}

/**
 * Query string to entry filters, or the sentence saying why not.
 *
 * <p>Refuses rather than falls back, as the Refused page does: a filter silently ignored labels the
 * rows as something they are not.
 *
 * <p><strong>All time is allowed only with an identifier.</strong> The archive has no index on
 * `archived_at` alone — its indexes lead with the account, the worker, the login or the batch — so
 * an unscoped all-time list is a sort of every partition, while "everything ever archived for this
 * account" walks one index.
 */
export function parseArchiveEntryFilters(
  params: URLSearchParams,
  now: Date = new Date()
): ArchiveEntryFilters | { error: string } {
  const filters: ArchiveEntryFilters = {};

  const range = params.get("range") ?? EMPTY_ARCHIVE_ENTRY_FORM.range;
  if (!(range in RANGES)) {
    return { error: `Unknown range '${range}'. Expected one of ${Object.keys(RANGES).join(", ")}.` };
  }
  const hours = RANGES[range];
  if (hours > 0) {
    filters.since = new Date(now.getTime() - hours * 3_600_000);
  }
  for (const key of ["since", "until"] as const) {
    const raw = params.get(key);
    if (raw) {
      const at = new Date(raw);
      if (Number.isNaN(at.getTime())) {
        return { error: `'${key}' is not a valid timestamp.` };
      }
      filters[key] = at;
    }
  }

  for (const [param, field] of TEXT_FIELDS) {
    const value = params.get(param)?.trim();
    if (value && value.length > MAX_TEXT_FILTER) {
      return { error: `'${param}' is longer than ${MAX_TEXT_FILTER} characters.` };
    }
    if (value) {
      (filters as Record<string, unknown>)[field] = value;
    }
  }

  const store = params.get("store")?.trim();
  if (store) {
    if (!(ARCHIVE_STORES as readonly string[]).includes(store)) {
      return { error: `Unknown store '${store}'. Expected one of ${ARCHIVE_STORES.join(", ")}.` };
    }
    filters.store = store;
  }

  const batch = params.get("batch")?.trim();
  if (batch) {
    //bound as ::uuid -- a stray value would be a query error surfacing as a 500
    if (!isBatchId(batch)) {
      return { error: "'batch' is not a batch id (a UUID, as the Batches tab shows it)." };
    }
    filters.batchId = batch;
  }

  const scoped = !!(filters.accountId || filters.worker || filters.systemId || filters.batchId || filters.gatewayMsgId);
  if (!filters.since && !scoped) {
    return {
      error: `Choose a period of at most ${MAX_RANGE_DAYS} days, or name an account, vendor, listener, login, batch or message to list all time.`,
    };
  }
  if (filters.since && !scoped) {
    const days = spanInDays(filters.since, filters.until ?? now);
    if (days > MAX_RANGE_DAYS) {
      return { error: `That is ${days} days. Ask for at most ${MAX_RANGE_DAYS} at a time.` };
    }
  }
  return filters;
}

/** The By account tab's query string, or the sentence saying why not. */
export function parseArchiveAccountFilters(params: URLSearchParams): ArchiveAccountFilters | { error: string } {
  const filters: ArchiveAccountFilters = {};
  for (const key of ["from", "to"] as const) {
    const raw = params.get(key)?.trim();
    if (raw) {
      if (!DAY.test(raw) || Number.isNaN(new Date(`${raw}T00:00:00Z`).getTime())) {
        return { error: `'${key}' is not a date (YYYY-MM-DD).` };
      }
      filters[key] = raw;
    }
  }
  if (filters.from && filters.to && filters.from > filters.to) {
    return { error: "The period ends before it starts." };
  }
  const account = params.get("account")?.trim();
  if (account) {
    if (account.length > MAX_TEXT_FILTER) {
      return { error: `'account' is longer than ${MAX_TEXT_FILTER} characters.` };
    }
    filters.accountId = account;
  }
  const store = params.get("store")?.trim();
  if (store) {
    if (!(ARCHIVE_STORES as readonly string[]).includes(store)) {
      return { error: `Unknown store '${store}'.` };
    }
    filters.store = store;
  }
  return filters;
}

/** The Batches tab: an optional store (`repush` and `purge` included) and a page size. */
export function parseBatchFilters(params: URLSearchParams): { store: string | null; batchId: string | null; limit: number } | { error: string } {
  const store = params.get("store")?.trim() || null;
  if (store && !(BATCH_STORES as readonly string[]).includes(store)) {
    return { error: `Unknown store '${store}'. Expected one of ${BATCH_STORES.join(", ")}.` };
  }
  const batch = params.get("batch")?.trim() || null;
  if (batch && !isBatchId(batch)) {
    return { error: "'batch' is not a batch id." };
  }
  const raw = Number(params.get("limit") ?? 50);
  const limit = Number.isFinite(raw) && raw >= 1 ? Math.min(Math.floor(raw), 200) : 50;
  return { store, batchId: batch, limit };
}

export function isRequestError<T extends object>(value: T | { error: string }): value is { error: string } {
  return "error" in value;
}
