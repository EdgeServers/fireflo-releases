import { createPollScheduler, type PollTimers } from "./poll-scheduler";

/**
 * One polled endpoint, held once and read by any number of components.
 *
 * <p>The shape `useSyncExternalStore` wants -- `subscribe` and `getSnapshot` -- around a
 * {@link PollScheduler}. Each poll folds the response into a new state object (`fold` is pure, so a
 * history such as the queue line can be kept here, at the fetch, where a new snapshot is known to be
 * new); a failed poll reports the error and keeps the last state, because a working gateway must not
 * look like it vanished on one lost request.
 *
 * <p>No React import: the provider and the hooks live in `components/`, and this stays testable on
 * its own.
 */
export interface PollStore<S> {
  subscribe(listener: () => void): () => void;
  getSnapshot(): S;
  /** The state before any poll, a stable reference for server rendering. */
  getInitialSnapshot(): S;
  /** A consumer is mounted; polling runs while at least one is. @returns the release */
  acquire(): () => void;
  /** Fetches now, regardless of the interval. */
  refresh(): Promise<void>;
  setVisible(visible: boolean): void;
}

export interface PollStoreOptions<S> {
  initial: S;
  intervalMs: number;
  /** Runs one fetch and folds it into the state; throws to report a failed poll. */
  poll: (state: S) => Promise<S>;
  /** Folds a failure into the state -- the error message beside the last good snapshot. */
  onError: (state: S, message: string) => S;
  visible?: boolean;
  timers?: PollTimers;
}

export function createPollStore<S>(options: PollStoreOptions<S>): PollStore<S> {
  const listeners = new Set<() => void>();
  let state = options.initial;
  let inFlight: Promise<void> | null = null;

  const set = (next: S) => {
    if (next === state) {
      return;
    }
    state = next;
    for (const listener of listeners) {
      listener();
    }
  };

  const refresh = (): Promise<void> => {
    //one request at a time: a slow gateway must not have a backlog of identical polls queued
    //behind it, each arriving to overwrite the one before
    if (inFlight) {
      return inFlight;
    }
    inFlight = options
      .poll(state)
      .then(set, (err: unknown) => {
        set(options.onError(state, err instanceof Error ? err.message : "Could not reach the gateway"));
      })
      .finally(() => {
        inFlight = null;
      });
    return inFlight;
  };

  const scheduler = createPollScheduler(() => void refresh(), options.intervalMs, {
    visible: options.visible,
    timers: options.timers,
  });

  return {
    subscribe(listener) {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
    getSnapshot: () => state,
    getInitialSnapshot: () => options.initial,
    acquire: () => scheduler.acquire(),
    refresh,
    setVisible: (visible) => scheduler.setVisible(visible),
  };
}
