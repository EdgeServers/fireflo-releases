/**
 * Approved sender IDs and approved message content, with no database import anywhere.
 *
 * <p>Split from `whitelist.ts` for the reason every `-types` module here is: a client component that
 * reaches a module which transitively imports `pg` does not break that page, it breaks every page.
 *
 * <p>This one carries more than types. **The template splitter below has to agree exactly with the
 * gateway's `ContentTemplate`**, because the panel's job is to tell an operator what a template will
 * accept before it is saved — and a preview that disagreed with the matcher would be worse than no
 * preview, since it would confidently describe behaviour that never happens.
 */

/** How hard a whitelist is applied. Mirrors the gateway's `WhitelistMode`. */
export type WhitelistMode = "OFF" | "REPORT" | "ENFORCE";

export const WHITELIST_MODES: readonly WhitelistMode[] = ["OFF", "REPORT", "ENFORCE"];

/** The placeholder, exactly. `{#VAR#}` and `{# var #}` are not it — the gateway matches them as this
 * one and reports them as degraded, and the panel refuses them outright. */
export const VARIABLE = "{#var#}";

/**
 * The three DLT placeholders, and what each stands for. Mirrors the gateway's `PlaceholderType`.
 *
 * <p>A typed placeholder is strictly tighter than `{#var#}` — the same length limit, fewer
 * characters allowed — so choosing one can only ever narrow what a template accepts.
 */
export const PLACEHOLDER_TYPES = {
  var: "anything",
  num: "digits 0–9",
  alp: "letters, spaces and name punctuation",
} as const;

export type PlaceholderName = keyof typeof PLACEHOLDER_TYPES;

/**
 * How much text one variable may stand for, **by default**.
 *
 * <p>No longer the whole story: the gateway reads `smsg.whitelist.max.variable` and reports the
 * ceiling actually in force as `max_variable` on `/ops/health`. This is what a deployment that has
 * not changed it uses, which is what the form should assume when it has no better answer.
 */
export const MAX_VARIABLE = 30;

/**
 * The gateway's whitespace folding, so that a preview here says what the matcher will do.
 *
 * <p>Mirrors `WhitespaceFold`: any run of space, tab, CR, LF or U+00A0 is one space, and both ends
 * are trimmed. **Not** a `\s` character class, which would exclude U+00A0 in some engines and
 * include characters the gateway does not fold in others — and U+00A0 is the whole point, because it
 * is what survives a paste out of a PDF, which is how DLT registrations arrive.
 */
export function foldWhitespace(text: string): string {
  return text.replace(/[ \t\r\n\u00A0]+/g, " ").trim();
}

export interface WhitelistPolicy {
  accountId: string;
  /** The empty string means every product, matching the column default. */
  product: string;
  headerMode: WhitelistMode;
  contentMode: WhitelistMode;
  updatedBy: string | null;
  updatedAt: string | null;
}

/**
 * Where a registration sits in the approval workflow.
 *
 * <p>Separate from `enabled`, which is the operator withdrawing something already approved. A row is
 * served by the gateway only when it is `enabled` AND `APPROVED` -- see DbWhitelistLoader, which is
 * the only place that decision is made.
 *
 * <p>`REJECTED` rows are kept rather than deleted so the customer can be told why.
 */
export type ApprovalStatus = "PENDING" | "APPROVED" | "REJECTED";

export const APPROVAL_STATUSES: readonly ApprovalStatus[] = ["PENDING", "APPROVED", "REJECTED"];

/** The review fields both registrations carry, kept in one place so the two cannot drift. */
export interface ApprovalFields {
  status: ApprovalStatus;
  /** The account that asked. Null when an operator created the row directly. */
  requestedBy: string | null;
  /** The customer's own words -- under DLT, their registration reference. Never a TLV. */
  requestNote: string | null;
  reviewedBy: string | null;
  reviewedAt: string | null;
  /** Why it was refused. Shown to the customer, so it is written to be read by them. */
  reviewNote: string | null;
}

export interface ApprovedHeader extends ApprovalFields {
  id: number;
  accountId: string;
  product: string;
  header: string;
  /** Comma-joined `name_tag=value`, the same form `default.tlvs.submit` uses. */
  tlvs: string | null;
  /** What the customer has asked {@link tlvs} to become. Never served -- see {@link RequestedTlvs}. */
  requestedTlvs: string | null;
  /**
   * The login this approval is for, or null for every login on the account.
   *
   * <p>Null is what every row meant before the column existed, so an untouched deployment matches
   * exactly as it did. A row bound to one login is not matched for another on the same account —
   * which is the point, and also the new way to build an outage: a login with neither its own rows
   * nor any account-wide ones can send nothing under ENFORCE.
   */
  systemId: string | null;
  label: string | null;
  enabled: boolean;
  updatedBy: string | null;
  updatedAt: string | null;
}

export interface ApprovedTemplate extends ApprovalFields {
  id: number;
  accountId: string;
  product: string;
  name: string | null;
  body: string;
  tlvs: string | null;
  requestedTlvs: string | null;
  /**
   * The login this approval is for, or null for every login on the account.
   *
   * <p>Null is what every row meant before the column existed, so an untouched deployment matches
   * exactly as it did. A row bound to one login is not matched for another on the same account —
   * which is the point, and also the new way to build an outage: a login with neither its own rows
   * nor any account-wide ones can send nothing under ENFORCE.
   */
  systemId: string | null;
  label: string | null;
  enabled: boolean;
  updatedBy: string | null;
  updatedAt: string | null;
}

/**
 * Why there are two TLV columns rather than one editable by everybody.
 *
 * <p>`tlvs` is what the gateway stamps onto the wire. Under `REPLACE` -- the recommended mode
 * wherever a registration is enforced, and the REST default -- it overwrites whatever the client
 * asserted, and that overwrite *is* the approval. A customer able to write it could assert somebody
 * else's registration while sending approved wording, and the call record would then report the
 * value they chose as approved.
 *
 * <p>So a customer writes `requestedTlvs`, which nothing on the message path reads, and an operator
 * either moves it across or clears it. `RequestedTlvsNeverServedTest` in the gateway is what holds
 * that line; this note is here so the next person to add a TLV field knows which column to touch.
 *
 * <p>The payoff for the customer: a proposal **does not suspend the row**. Every other edit forces
 * `PENDING`, because changing approved wording under an existing approval is what approval exists to
 * stop. A proposal changes nothing that is served, so the approved row keeps working meanwhile.
 */
export type RequestedTlvs = string | null;

export interface HeaderInput {
  id?: number | null;
  accountId: string;
  product?: string;
  header: string;
  tlvs?: string | null;
  /** Empty or absent means every login on the account, which is the default the forms offer. */
  systemId?: string | null;
  label?: string | null;
  enabled: boolean;
  /**
   * Whether this is approved, and therefore whether the gateway may serve it.
   *
   * <p>Writes `status` **and** records the reviewer, the way the review PATCH does. That is a change
   * of behaviour, not just a label: this tick used to write only `enabled`, and ticking it on a
   * PENDING row left the row PENDING and inert while looking approved.
   *
   * <p>Unticking writes `enabled = false` and leaves `status` alone. Withdrawing something is not
   * un-approving it — they are separate columns for that reason, and a withdrawn row put back into
   * service should not need approving again.
   *
   * <p>Refusing is not here. It needs a reason the customer is shown, so it stays on the review path.
   */
  approved: boolean;
}

export interface TemplateInput {
  id?: number | null;
  accountId: string;
  product?: string;
  name?: string | null;
  body: string;
  tlvs?: string | null;
  systemId?: string | null;
  label?: string | null;
  enabled: boolean;
  /**
   * Whether this is approved, and therefore whether the gateway may serve it.
   *
   * <p>Writes `status` **and** records the reviewer, the way the review PATCH does. That is a change
   * of behaviour, not just a label: this tick used to write only `enabled`, and ticking it on a
   * PENDING row left the row PENDING and inert while looking approved.
   *
   * <p>Unticking writes `enabled = false` and leaves `status` alone. Withdrawing something is not
   * un-approving it — they are separate columns for that reason, and a withdrawn row put back into
   * service should not need approving again.
   *
   * <p>Refusing is not here. It needs a reason the customer is shown, so it stays on the review path.
   */
  approved: boolean;
}

/** One account's counts, for the index pages and the account detail sections. */
export interface WhitelistSummary {
  accountId: string;
  product: string;
  headerMode: WhitelistMode;
  contentMode: WhitelistMode;
  headers: number;
  templates: number;
}

/**
 * Splits a template body into the literal text around its variables.
 *
 * <p>The panel's copy of `ContentTemplate.split`. Deliberately the same plain `indexOf` loop rather
 * than a regex, so that the two cannot drift: whatever this returns is what the gateway will match
 * against.
 */
export function splitTemplate(body: string): string[] {
  return scanTemplate(body).parts;
}

/** The literal segments, plus the name inside each placeholder in order. */
export interface TemplateScan {
  parts: string[];
  /** `var`, `num`, `alp`, or whatever else was written between `{#` and `#}`. */
  names: string[];
}

/**
 * The panel's copy of `ContentTemplate.scan`, folding first exactly as the gateway does.
 *
 * <p>Folding here and not only in the gateway is what keeps the preview honest: a template pasted
 * with a line break before its signature is matched folded, so a preview built from the raw text
 * would show a message that is not the one being compared.
 */
export function scanTemplate(body: string): TemplateScan {
  const folded = foldWhitespace(body);
  const parts: string[] = [];
  const names: string[] = [];
  let from = 0;
  for (;;) {
    const open = folded.indexOf("{#", from);
    if (open < 0) {
      break;
    }
    const close = folded.indexOf("#}", open + 2);
    if (close < 0) {
      //an opening with no closing is ordinary text, exactly as `{code}` is
      break;
    }
    parts.push(folded.slice(from, open));
    names.push(folded.slice(open + 2, close));
    from = close + 2;
  }
  parts.push(folded.slice(from));
  return { parts, names };
}

/**
 * Why this template cannot be enforced, or null when it can.
 *
 * <p>Every rejection here mirrors one the gateway makes at load time. Doing it in the panel is not
 * belt and braces: a template the gateway refuses is silently dropped from that account's approved
 * list, so an operator who saved one would see it in the panel and watch it enforce nothing.
 */
export function validateTemplate(body: string): string | null {
  if (!body || !body.trim()) {
    return "A template needs the wording it approves.";
  }
  if (body.length > MAX_TEMPLATE) {
    return `A template is at most ${MAX_TEMPLATE} characters — longer than any message it could `
      + "approve.";
  }
  const scan = scanTemplate(body);
  //strict here, deliberately, even though the GATEWAY now loads an unrecognised type as a generic
  //variable rather than dropping the row. The two are not in conflict: the gateway's job on a row
  //already in the database is to keep the account enforcing and say what it did, and the panel's is
  //to stop the row being written in the first place. Strict at authoring, forgiving but loud at load
  const unknown = scan.names.find((name) => !(name in PLACEHOLDER_TYPES));
  if (unknown !== undefined) {
    return `'{#${unknown}#}' is not a placeholder. Write ${VARIABLE} for anything, {#num#} for `
      + "digits or {#alp#} for names and phrases. Write the token itself lower case with no "
      + "spaces inside it — that is the spelling, not what it accepts. Anything else is "
      + "matched as "
      + `${VARIABLE}, which accepts more than you meant.`;
  }
  const suspect = suspectPlaceholder(body);
  if (suspect) {
    return `'${suspect}' looks like a placeholder and is not one. Write ${VARIABLE}, {#num#} or `
      + "{#alp#} — the characters around it are matched literally, so this template would only "
      + "approve a message that carries them exactly as written.";
  }

  const parts = scan.parts;
  if (parts.length === 1) {
    return null;
  }
  //placeholders that touch are one group (see templateGroups); the only touching shape the gateway
  //refuses is {#var#} next to a typed run, because {#var#} takes digits and letters too
  for (const gap of templateGroups(body)) {
    for (let r = 1; r < gap.length; r++) {
      if (gap[r].name === "var" || gap[r - 1].name === "var") {
        return `${VARIABLE} next to {#num#} or {#alp#} cannot be told apart: ${VARIABLE} takes `
          + "digits and letters too, so nobody can say where one ends. Put wording between them, "
          + "or use one type for the whole value.";
      }
    }
  }
  //a space between two variables does not count as wording: it is optional in the message
  if (parts.every((p) => p.trim() === "")) {
    return `A template of nothing but ${VARIABLE} accepts every message, which is the same as not `
      + "having one. Add the wording around the variable.";
  }
  return null;
}

/**
 * One run of touching placeholders of the same type: what part of a gap stands for.
 *
 * @property spacedJoins joins inside the run that had whitespace in the template; that many spaces
 *     are free in the message, and the run accepts a space where they were
 */
export interface PlaceholderRun {
  name: string;
  members: number;
  spacedJoins: number;
}

/**
 * The panel's copy of `ContentTemplate.group`: each gap of the template as runs of one type.
 *
 * <p>Placeholders touch when nothing, or only whitespace, separates them. A run of touching
 * placeholders of one type is one variable as long as all of them together — `{#var#}{#var#}{#var#}`
 * stands for 1 to 3 × 30 characters, DLT's way of writing a long value — and a space between them in
 * the template is optional in the message. Runs of different types may touch when they share no
 * character (`{#num#}{#alp#}`: digits then letters).
 */
export function templateGroups(body: string): PlaceholderRun[][] {
  const { parts, names } = scanTemplate(body);
  const gaps: PlaceholderRun[][] = [];
  let i = 0;
  while (i < names.length) {
    const runs: PlaceholderRun[] = [{ name: names[i], members: 1, spacedJoins: 0 }];
    let j = i;
    while (j + 1 < names.length && parts[j + 1].trim() === "") {
      const name = names[j + 1];
      const last = runs[runs.length - 1];
      if (last.name === name) {
        last.members += 1;
        if (parts[j + 1] !== "") {
          last.spacedJoins += 1;
        }
      } else {
        runs.push({ name, members: 1, spacedJoins: 0 });
      }
      j += 1;
    }
    gaps.push(runs);
    i = j + 1;
  }
  return gaps;
}

/**
 * What the variables of a template accept, in words: one line per gap that is a group.
 *
 * <p>Null when no gap is a group, so the form says nothing new about an ordinary template.
 */
export function describeGroups(body: string, maxVariable = MAX_VARIABLE): string | null {
  const lines: string[] = [];
  for (const gap of templateGroups(body)) {
    if (gap.length === 1 && gap[0].members === 1) {
      continue;
    }
    const said = gap.map((run) => {
      const token = `{#${run.name}#}`;
      const kind = run.name === "num" ? "digits" : run.name === "alp" ? "letters" : "characters";
      const spaces = run.spacedJoins > 0 ? `, with or without the space${run.spacedJoins > 1 ? "s" : ""}` : "";
      return run.members === 1
        ? `${token}: up to ${maxVariable} ${kind}`
        : `${run.members} × ${token} as one: up to ${run.members * maxVariable} ${kind}${spaces}`;
    });
    lines.push(said.join(", then "));
  }
  return lines.length ? lines.join("; ") : null;
}

/**
 * Text that was meant to be the placeholder and is not.
 *
 * <p>What reaches here is narrower than it once was. `{#VAR#}` and `{# var #}` are well-formed
 * `{#…#}` tokens with an unrecognised name, so `scanTemplate` sees them and the check above this one
 * refuses them first. This catches what that scan does not see as a placeholder at all: a token
 * carrying a `#` that is not `{#…#}` — `{#VAR}` with no closing `#}`, or `{{#var#}}`, where the
 * outer braces are ordinary characters the message would have to contain literally.
 *
 * <p>The gateway does not drop either shape. `ContentTemplate.scan` breaks on an unclosed `{#` and
 * treats it as literal text, and reads `{{#var#}}` as a real `{#var#}` between two literal braces —
 * so such a template loads and enforces, matching only messages that carry those characters, which
 * is not what whoever wrote it meant. Refusing it at authoring is deliberate and is the same
 * division as for an unrecognised name: strict where the row is written, forgiving but loud where it
 * is loaded.
 */
function suspectPlaceholder(body: string): string | null {
  const known = new Set(Object.keys(PLACEHOLDER_TYPES).map((n) => `{#${n}#}`));
  let from = 0;
  for (;;) {
    const open = body.indexOf("{", from);
    if (open < 0) {
      return null;
    }
    const close = body.indexOf("}", open);
    if (close < 0) {
      return null;
    }
    const token = body.slice(open, close + 1);
    if (!known.has(token) && token.includes("#")) {
      return token;
    }
    from = close + 1;
  }
}

/**
 * An example message this template accepts.
 *
 * <p>The highest-value thing on the template form. An operator cannot tell by looking whether
 * `{#VAR#}` is the token, and the consequence of getting it wrong is a template that saves cleanly
 * and matches nothing for as long as nobody checks.
 */
export function previewTemplate(body: string, sample = "123456"): string {
  const { parts, names } = scanTemplate(body);
  //a sample per gap, chosen to satisfy that gap's type. Filling a {#num#} with the same string as a
  //{#alp#} would show the operator a message their own template refuses, which is worse than no
  //preview -- the whole reason this module mirrors the gateway rather than approximating it
  let out = parts[0] ?? "";
  for (let i = 1; i < parts.length; i++) {
    const name = names[i - 1];
    out += name === "alp" ? "Priya" : name === "num" ? "123456" : sample;
    out += parts[i];
  }
  return out.slice(0, 400);
}

/**
 * Whether greedy matching could reject a message a backtracking engine would accept.
 *
 * <p>Mirrors `ContentTemplate.hasRepeatingSegments`. A warning rather than a refusal: such a
 * template is usually still correct, and this is the matcher's one invisible failure mode, so the
 * point is to make it visible.
 */
export function hasRepeatingSegments(body: string): boolean {
  const parts = splitTemplate(body);
  for (let i = 1; i < parts.length - 1; i++) {
    if (parts[i] === "") {
      continue;
    }
    if (parts.slice(i + 1).join("").includes(parts[i])) {
      return true;
    }
  }
  return false;
}

/**
 * The longest sender ID this will store.
 *
 * <p>Generous rather than correct on purpose. SMPP caps `source_addr` at 21 octets, so anything
 * past that cannot actually be delivered over a bind — but refusing at 21 here would also refuse
 * edits to rows that already exist, and turning "you cannot deliver this" into "you cannot save
 * this" is a different decision from bounding the column.
 *
 * <p>What this IS for: the field had no ceiling at all, and App Router applies no default body
 * limit, so a customer could store a multi-megabyte sender ID that then landed in the operator's
 * review queue and was read by the gateway's whitelist loader on every configuration poll.
 */
const MAX_HEADER = 64;

/**
 * The longest template body.
 *
 * <p>Ten SMS segments and change. A template longer than the message it approves cannot match one,
 * so this bounds the column without bounding anything anybody would write. Matches the ceiling
 * `tlvCsvProblem` already puts on the other free-text field a customer can submit.
 */
const MAX_TEMPLATE = 2_000;

/** Sender IDs are compared case-insensitively and stored as printable ASCII. */
export function validateHeader(header: string): string | null {
  const value = header ?? "";
  if (!value.trim()) {
    return "A sender ID is required.";
  }
  if (value.length > MAX_HEADER) {
    return `A sender ID is at most ${MAX_HEADER} characters. SMPP allows 21, so anything near this `
      + "could be stored and never delivered.";
  }
  if (value !== value.trim()) {
    return `'${value}' has a space at one end. A sender ID is compared exactly, and a trailing space `
      + "is invisible everywhere it is shown.";
  }
  if (!/^[\x20-\x7E]+$/.test(value)) {
    return "A sender ID must be printable ASCII. Comparison is case-insensitive, and folding the "
      + "case of other alphabets depends on the server's locale — the same row would match on one "
      + "deployment and not another.";
  }
  return null;
}

/**
 * Which of the two whitelists is being asked about. `content` is templates; the policy column is
 * `content_mode`, so the word is kept rather than renamed to `template`.
 */
export type WhitelistKind = "header" | "content";

function countIn(summary: WhitelistSummary, kind: WhitelistKind): number {
  return kind === "header" ? summary.headers : summary.templates;
}

function modeIn(summary: WhitelistSummary, kind: WhitelistKind): WhitelistMode {
  return kind === "header" ? summary.headerMode : summary.contentMode;
}

function nouns(kind: WhitelistKind): { one: string; many: string } {
  return kind === "header"
    ? { one: "sender ID", many: "sender IDs" }
    : { one: "template", many: "templates" };
}

function scopeOf(
  summaries: readonly WhitelistSummary[],
  accountId: string,
  product: string
): WhitelistSummary | undefined {
  return summaries.find((s) => s.accountId === accountId && s.product === product);
}

/**
 * The mode that actually governs traffic on this product.
 *
 * <p>**The gateway merges; it does not look one scope up.** `AccountWhitelist.merge` takes the
 * product's own mode unless that mode is `OFF`, in which case the account's applies. So a product
 * row sitting at `OFF` beneath an enforcing account is enforcing, and reporting it as "not enforced"
 * — which is what an `exact ?? fallback` lookup does — is wrong in the direction that matters.
 */
export function effectiveMode(
  summaries: readonly WhitelistSummary[],
  accountId: string,
  product: string,
  kind: WhitelistKind
): WhitelistMode {
  const account = scopeOf(summaries, accountId, "");
  const accountMode = account ? modeIn(account, kind) : "OFF";
  if (!product) {
    return accountMode;
  }
  const specific = scopeOf(summaries, accountId, product);
  const specificMode = specific ? modeIn(specific, kind) : "OFF";
  return specificMode === "OFF" ? accountMode : specificMode;
}

export interface EnforcementReadiness {
  /** Non-null means do not save: enforcing would refuse every message this account sends. */
  refuse: string | null;
  /** Non-null means save, and say this: some traffic will be refused entirely. */
  warn: string | null;
  /** How many approvals the gateway would actually have in this scope. */
  approved: number;
}

/**
 * Whether this account can be switched to ENFORCE, counted the way the gateway counts.
 *
 * <h2>Why this is not `count > 0` on one scope</h2>
 *
 * <p>It used to be, and it refused a configuration that works. `WhitelistSnapshot` buckets rows by
 * `(account, product)` and then merges each product scope **over** the account's any-product scope:
 * the two header lists are unioned. So an account-level ENFORCE with the only approval filed under
 * `in-otp` checks `in-otp` traffic against a list containing that approval. Counting the account
 * scope alone said "nothing is approved" about a setup that was ready to run.
 *
 * <h2>The two things that make it more than a sum</h2>
 *
 * <p><strong>Exempt products protect nothing.</strong> `whitelistFor` returns `OFF` outright for a
 * product with `whitelist_enabled = false`, before any merge. Counting an approval filed under one
 * would wave through an account whose approvals are all inert — creating exactly the outage this
 * guard exists to prevent, by way of the fix for it.
 *
 * <p><strong>Traffic with no product is served by the account scope alone.</strong> No
 * product-scoped approval can ever reach it. So an account-level ENFORCE with an empty account list
 * stops every login whose credential names no product, however many product approvals exist — which
 * is why that case warns loudly rather than passing in silence.
 */
export function enforcementReadiness(
  summaries: readonly WhitelistSummary[],
  accountId: string,
  product: string,
  kind: WhitelistKind,
  mode: WhitelistMode,
  exemptProducts: readonly string[] = []
): EnforcementReadiness {
  const noun = nouns(kind);
  const exempt = new Set(exemptProducts);
  const atAccount = countIn(
    scopeOf(summaries, accountId, "") ?? blank(accountId, ""),
    kind
  );

  if (product) {
    //a product scope inherits the account's list through the merge, so both count
    const approved = atAccount + countIn(scopeOf(summaries, accountId, product) ?? blank(accountId, product), kind);
    return {
      approved,
      refuse:
        mode === "ENFORCE" && approved === 0
          ? `No ${noun.many} are approved for '${product}' or for the account as a whole, so `
            + `enforcing here would refuse every message on that product. Approve at least one `
            + `first, or use REPORT to see what would be refused.`
          : null,
      warn:
        exempt.has(product)
          ? `'${product}' is not checked at all — its traffic is exempt — so this setting is stored `
            + `and never consulted.`
          : null,
    };
  }

  const productScopes = summaries.filter(
    (s) => s.accountId === accountId && s.product !== "" && countIn(s, kind) > 0
  );
  const covered = productScopes.filter((s) => !exempt.has(s.product)).map((s) => s.product);
  const inert = productScopes.filter((s) => exempt.has(s.product)).map((s) => s.product);
  const protecting = atAccount + covered.length;
  const anywhere = atAccount + productScopes.length;

  let refuse: string | null = null;
  if (mode === "ENFORCE" && protecting === 0) {
    refuse = anywhere > 0
      ? `The only approved ${noun.many} are under ${list(inert)}, and that traffic is not checked `
        + `at all, so those approvals protect nothing. Enforcing here would refuse everything else. `
        + `Approve a ${noun.one} for the account, or for a product that is checked.`
      : `Nothing is approved for this account, so enforcing ${noun.many} would stop it sending `
        + `anything at all. Approve at least one ${noun.one} first, or use REPORT to see what would `
        + `be refused.`;
  }

  return {
    approved: anywhere,
    refuse,
    //the compensating control for allowing what the old guard refused: this configuration DOES run,
    //and it DOES stop some traffic dead, and only naming which makes that a decision rather than a
    //surprise. The no-product half is not a detail -- a credential with no product set can never be
    //rescued by a product-scoped approval
    warn:
      !refuse && mode === "ENFORCE" && atAccount === 0 && covered.length > 0
        ? `Only traffic on ${list(covered)} is covered: every ${noun.one} approved here is filed `
          + `under a product, and a product's list applies to that product alone. Any other `
          + `product — and any login with no product set — is refused while ${noun.many} are `
          + `enforced. To cover them all, approve one with the product left blank.`
        : null,
  };
}

function blank(accountId: string, product: string): WhitelistSummary {
  return { accountId, product, headerMode: "OFF", contentMode: "OFF", headers: 0, templates: 0 };
}

function list(items: readonly string[]): string {
  if (items.length <= 1) {
    return items[0] ?? "";
  }
  return `${items.slice(0, -1).join(", ")} and ${items[items.length - 1]}`;
}

/**
 * The product options for one whitelist row: the catalogue, plus whatever this row already has.
 *
 * <p>The second half is the load-bearing one. A product retired from the catalogue is still on the
 * rows that named it, and a `<Select>` that cannot show the current value silently rewrites it to
 * the first option on save — changing which traffic the approval covers, with nothing said.
 * `CredentialForm` solves the same problem the same way.
 */
/**
 * The logins offerable for a registration, including one it already names.
 *
 * <p>Same shape and same reason as {@link productOptions}: a row may name a login that has since
 * been deleted or disabled, and dropping it from the list would silently rewrite that row to
 * "every login" the next time somebody saved the form -- widening an approval by accident, which is
 * the direction that matters.
 */
export function loginOptions(logins: readonly string[], current: string): string[] {
  const all = new Set(logins.filter(Boolean));
  if (current.trim()) {
    all.add(current.trim());
  }
  return [...all].sort();
}

export function productOptions(catalogue: readonly string[], current: string): string[] {
  const c = current.trim();
  return c && !catalogue.includes(c) ? [...catalogue, c] : [...catalogue];
}
