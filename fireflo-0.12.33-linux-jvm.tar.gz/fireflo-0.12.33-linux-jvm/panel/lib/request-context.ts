import { AsyncLocalStorage } from "node:async_hooks";
import { clientIp, clientUserAgent } from "@/lib/client-ip";

/**
 * The current request's address, reachable from code that was never handed the request.
 *
 * <h2>Why this exists</h2>
 *
 * <p>NextAuth's `authorize()` receives credentials and nothing else — no request, no headers (see
 * `lib/auth.ts` and `lib/mis-auth.ts`). It is also the only place that knows whether a sign-in
 * succeeded or failed. So the one fact an access log most needs, the caller's IP, is not available
 * at the one point that knows what happened.
 *
 * <p>The alternative was to log from the route wrapper and infer the outcome from the response —
 * classifying a 302 by whether its `Location` carries `error=` and whether a session cookie came
 * back. That reads NextAuth's internals from the outside and breaks quietly on a version bump.
 * Passing the address down an async context instead lets each side do what it is good at: the route
 * knows the connection, `authorize` knows the verdict.
 *
 * <p><strong>This works because `authorize` runs inside the awaited handler call.</strong> An async
 * context follows `await`, so anything the handler does synchronously or asynchronously in that
 * chain sees the same store. It would not survive being handed to a queue or a timer that outlives
 * the request, and nothing here does that.
 */
export interface RequestContext {
  ip: string | null;
  userAgent: string | null;
  /**
   * Set by `authorize()` when it has recorded a verdict for this request.
   *
   * <p>The route wrapper uses it as a secondary net: a credential POST that never reached
   * `authorize` — a stale CSRF token, a malformed body — would otherwise fail with nothing written
   * anywhere, which is exactly the attempt worth seeing.
   */
  handled: boolean;
}

const storage = new AsyncLocalStorage<RequestContext>();

/**
 * Runs `fn` with this request's address available to {@link currentRequestContext}.
 */
export function runWithRequestContext<T>(req: { headers: Headers }, fn: () => T): T {
  return storage.run({ ip: clientIp(req), userAgent: clientUserAgent(req), handled: false }, fn);
}

/**
 * @return the context, or null when called outside a wrapped request. Null rather than a throw:
 *     a missing IP degrades one field of one log line, and must never be the reason a sign-in fails
 */
export function currentRequestContext(): RequestContext | null {
  return storage.getStore() ?? null;
}

/** Records that a verdict has been logged for this request, so the wrapper does not log a second. */
export function markRequestHandled(): void {
  const store = storage.getStore();
  if (store) {
    store.handled = true;
  }
}

/**
 * The same facts for callers that can await, working without a wrapper.
 *
 * <p>Only the two NextAuth routes are wrapped, because only they have a synchronous `authorize()`
 * to feed. Everything else — `requireCustomer`, `assertInScope`, and any route handler — can reach
 * Next's own request headers directly, so wrapping a dozen more routes would buy nothing.
 *
 * <p>Prefers the async-context store when there is one, so a call inside a wrapped request sees the
 * same values rather than two subtly different readings of one request.
 */
export async function requestContext(): Promise<{ ip: string | null; userAgent: string | null }> {
  const store = storage.getStore();
  if (store) {
    return { ip: store.ip, userAgent: store.userAgent };
  }
  try {
    const { headers } = await import("next/headers");
    const h = await headers();
    return { ip: clientIp({ headers: h }), userAgent: clientUserAgent({ headers: h }) };
  } catch {
    //outside a request — a script, a test. A missing address is one empty field, never a failure
    return { ip: null, userAgent: null };
  }
}
