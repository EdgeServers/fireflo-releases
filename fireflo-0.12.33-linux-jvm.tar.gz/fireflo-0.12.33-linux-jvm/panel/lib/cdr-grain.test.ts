import { strict as assert } from "node:assert";
import { test } from "node:test";

import {
  attemptRows,
  carriesMoney,
  isMessageRow,
  messageRows,
  outcomeForRepresentative,
  partOne,
  representativeKeys,
  rollupTailFrom,
} from "./cdr-grain.ts";

const norm = (sql: string) => sql.replace(/\s+/g, " ").trim();

test("the part-1 predicate carries no retry term", () => {
  //the accepted attempt -- the one carrying money -- is not the retry_count = 0 one after a
  //failover. Adding `AND retry_count = 0` keeps the refusal and drops the charged, delivered row
  assert.equal(partOne(), "s.part_no = 1");
  assert.ok(!partOne().includes("retry_count"));
});

test("money is summed over every part-1 row, deliberately", () => {
  //only one row per message has a price, so no deduplication is needed to sum it
  assert.equal(carriesMoney(), partOne());
  assert.equal(carriesMoney("x"), partOne("x"));
  assert.equal(partOne(""), "part_no = 1");
});

test("the representative is chosen exactly as UsageRollup chooses it", () => {
  //UsageRollup.ROLLUP_SQL: ORDER BY c.gateway_msg_id, (c.price IS NULL), c.retry_count DESC,
  //c.vendor_attempt DESC -- the money row first, else the latest attempt. id DESC is a tiebreak
  //the unique key makes unreachable
  assert.equal(
    representativeKeys("c"),
    "(c.price IS NULL), c.retry_count DESC, c.vendor_attempt DESC, c.id DESC"
  );
  //a gateway before V1.40.0 has no vendor_attempt, and naming it there is a hard error
  assert.ok(!representativeKeys("c", false).includes("vendor_attempt"));
});

test("one row per message is a DISTINCT ON with the caller's filters inside it", () => {
  const sql = norm(messageRows("s.account_id = $1", { vendorAttempt: true }));
  assert.match(sql, /^\(SELECT DISTINCT ON \(s\.gateway_msg_id\) s\.\* FROM cdr_submit s/);
  assert.match(sql, /WHERE s\.part_no = 1 AND s\.account_id = \$1 ORDER BY s\.gateway_msg_id, \(s\.price IS NULL\)/);
  assert.match(sql, /\) s$/, "aliased s so the caller's outcome LATERAL still correlates");
  assert.ok(!norm(messageRows("", { vendorAttempt: false })).includes("vendor_attempt"));
});

test("attempts keep every row and flag the representative", () => {
  const sql = norm(attemptRows("s.submitted_at >= $1", { vendorAttempt: true }));
  assert.ok(!sql.includes("DISTINCT ON"), "every attempt is traffic for its vendor");
  assert.match(sql, /row_number\(\) OVER \(PARTITION BY s\.gateway_msg_id ORDER BY \(s\.price IS NULL\)/);
  assert.match(sql, /AS represents/);
});

test("an outcome is credited to the representative attempt only", () => {
  const lateral = `LEFT JOIN LATERAL (SELECT f.final_state FROM cdr_final f
     WHERE f.gateway_msg_id = s.gateway_msg_id AND f.part_no = s.part_no LIMIT 1) o ON TRUE`;
  assert.match(outcomeForRepresentative(lateral), /f\.part_no = s\.part_no AND s\.represents/);
  //and the progress receipts, whose alias is i
  assert.match(
    outcomeForRepresentative("WHERE i.gateway_msg_id = s.gateway_msg_id AND i.part_no = s.part_no"),
    /i\.part_no = s\.part_no AND s\.represents$/
  );
  //a lateral that does not correlate the expected way must fail loudly, not credit every attempt
  assert.throws(() => outcomeForRepresentative("LEFT JOIN LATERAL (SELECT 1) o ON TRUE"));
});

test("the list predicate ranks the same keys, best as smallest", () => {
  const sql = norm(isMessageRow("s", { vendorAttempt: true }));
  assert.match(sql, /^\(s\.part_no = 1 AND NOT EXISTS/);
  assert.match(sql,
    /\(\(rival\.price IS NULL\)::int, -rival\.retry_count, -rival\.vendor_attempt, -rival\.id\) < \(\(s\.price IS NULL\)::int, -s\.retry_count, -s\.vendor_attempt, -s\.id\)/);
  assert.ok(!isMessageRow("s", { vendorAttempt: false }).includes("vendor_attempt"));
});

test("CP-P1 a named projection replaces s.* and is identifiers only", () => {
  const sql = norm(messageRows("s.account_id = $1", { vendorAttempt: true }, ["gateway_msg_id", "part_no", "price"]));
  assert.match(sql, /^\(SELECT DISTINCT ON \(s\.gateway_msg_id\) s\.gateway_msg_id, s\.part_no, s\.price FROM cdr_submit s/);
  assert.doesNotMatch(sql, /s\.\*/);
  //an empty list is "everything", not "nothing"
  assert.match(norm(messageRows("", { vendorAttempt: true }, [])), /s\.\* FROM/);
  //a column name is interpolated, so it is checked as an identifier -- a value here is a bug
  assert.throws(() => messageRows("", { vendorAttempt: true }, ["price; DROP TABLE x"]));
  assert.throws(() => messageRows("", { vendorAttempt: true }, ["s.price"]));
});

test("CP-P2 the live tail starts the day before the rollup's newest line, or at the beginning of time", () => {
  const one = norm(rollupTailFrom("$2", "$1"));
  assert.equal(one,
    "(SELECT COALESCE(((max(u.day) - 1)::timestamp AT TIME ZONE $2), '-infinity'::timestamptz) FROM usage_daily u WHERE u.account_id = $1)");
  //deployment-wide: no account filter, so idx_usage_daily_day answers it
  assert.doesNotMatch(norm(rollupTailFrom("$3", null)), /account_id/);
});
