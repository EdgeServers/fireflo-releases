import { strict as assert } from "node:assert";
import { test } from "node:test";
import {
  type ScopeInput,
  conditionWarnings,
  looksLikeRegex,
  regexInLiteralOperator,
  scopeWarnings,
} from "./rate-types.ts";

/**
 * A regular expression given to an operator that compares literal text.
 *
 * The failure it names is the quiet kind: the condition is stored exactly as typed, every page shows
 * it correctly, and it can never be true. Found in the field on a filter reading
 * `to startsWith ^(?:\+91|91|0)?[6-9]\d{9}$`, which priced nothing for as long as it existed.
 *
 * **Half these tests are about staying silent.** A check that fires on `+91` — an ordinary, correct
 * startsWith value — teaches an operator to scroll past warnings, and then the next real one is
 * invisible too. The false-positive cases matter more than the true-positive ones.
 */

const REAL = "^(?:\\+91|91|0)?[6-9]\\d{9}$";

test("the pattern that actually shipped is caught", () => {
  const warning = regexInLiteralOperator("startsWith", REAL);
  assert.ok(warning, "the value that priced nothing in production must warn");
  //the fix, not the diagnosis: an operator who reads only one clause should still know what to do
  assert.match(warning, /matches/);
  //and the consequence, since "that is a regex" is the part they already know
  assert.match(warning, /never/);
});

test("ordinary literal values stay silent", () => {
  //every one of these is a correct value somebody would really type
  for (const value of ["+91", "91", "0", "INFO", "INFO-", "61400000000", "AU", "sms"]) {
    assert.equal(
      regexInLiteralOperator("startsWith", value), null,
      `'${value}' is a plain literal and must not warn`
    );
  }
  assert.equal(regexInLiteralOperator("endsWith", ".com"), null);
  assert.equal(regexInLiteralOperator("equals", "premium"), null);
});

test("matches is silent whatever the value, because matches is the operator that compiles it", () => {
  assert.equal(regexInLiteralOperator("matches", REAL), null);
  assert.equal(regexInLiteralOperator("matches", "^91.*"), null);
});

test("negation does not smuggle a pattern past the check", () => {
  //the policy string packs the ! in, so reading it as part of the operator name would miss this
  assert.ok(regexInLiteralOperator("!startsWith", REAL));
  //and the negated pattern operator is still the pattern operator
  assert.equal(regexInLiteralOperator("!matches", REAL), null);
});

test("each signal is enough on its own", () => {
  assert.ok(regexInLiteralOperator("startsWith", "^91"), "leading ^");
  assert.ok(regexInLiteralOperator("endsWith", "91$"), "trailing $");
  assert.ok(regexInLiteralOperator("startsWith", "\\d5"), "an escape");
  assert.ok(regexInLiteralOperator("startsWith", "[69]1"), "a character class");
  assert.ok(regexInLiteralOperator("startsWith", "(91|61)"), "a group");
  assert.ok(regexInLiteralOperator("startsWith", "9{2}"), "a quantifier");
  assert.ok(regexInLiteralOperator("startsWith", "91.*"), ".*");
});

test("an empty value says nothing, because emptiness is a different complaint", () => {
  //validateFilter and validateConditions own that one; two warnings for one mistake is noise
  assert.equal(regexInLiteralOperator("startsWith", ""), null);
});

test("looksLikeRegex is the predicate alone, with no view about the operator", () => {
  assert.equal(looksLikeRegex(REAL), true);
  assert.equal(looksLikeRegex("+91"), false);
});

/**
 * The predicate reaching the two places a condition is written.
 *
 * `scopeWarnings` is the rate editor's; `conditionWarnings` is the filter form's. Both are the same
 * check applied to the same shape, and both were missing it.
 */

test("scopeWarnings reports a rule whose own condition is a pattern in a literal operator", () => {
  const warnings = scopeWarnings({
    scope: "acct-1001",
    scopeConfirmed: true,
    rules: [{
      id: 1, amount: "0.0900", product: null, currency: null, label: null, enabled: true,
      conditions: [{ field: "to", operator: "startsWith", value: REAL, negate: false }],
      filters: [],
    }],
  } as ScopeInput);
  const named = warnings.filter((w) => w.includes("literal text"));
  assert.equal(named.length, 1);
  //numbered, because a scope with six rules needs to say which one
  assert.match(named[0], /^Rule 1:/);
});

test("a correct startsWith rule produces no such warning", () => {
  const warnings = scopeWarnings({
    scope: "acct-1001",
    scopeConfirmed: true,
    rules: [{
      id: 1, amount: "0.0900", product: null, currency: null, label: null, enabled: true,
      conditions: [{ field: "to", operator: "startsWith", value: "+91", negate: false }],
      filters: [],
    }],
  } as ScopeInput);
  assert.deepEqual(warnings.filter((w) => w.includes("literal text")), []);
});

test("conditionWarnings says one thing about one mistake, however many conditions repeat it", () => {
  const warnings = conditionWarnings([
    { field: "to", operator: "startsWith", value: REAL, negate: false },
    { field: "from", operator: "startsWith", value: REAL, negate: false },
  ]);
  assert.equal(warnings.length, 1);
});
