import { test } from "node:test";
import assert from "node:assert/strict";
import {
  FAILURE_WINDOW_MS,
  MAX_FAILURES,
  MAX_FAILURES_PER_EMAIL,
  lockoutKey,
  signinLockout,
} from "./signin-lockout.ts";

/**
 * Two counters behind one key: ten per origin+email, thirty per email from anywhere.
 *
 * <p>The second exists because the first is the one an attacker steps around by changing source
 * address (or by forging one, which is what a panel without `TRUSTED_PROXY_HOPS` used to allow).
 * Each case here rotates the address and asks whether the account still locks.
 */

const EMAIL = "Ops@Example.com";

function failTimes(lockout: ReturnType<typeof signinLockout>, key: string, n: number): void {
  for (let i = 0; i < n; i++) {
    lockout.noteFailure(key);
  }
}

test("ten failures from one origin lock that origin, and only that origin", () => {
  const lockout = signinLockout();
  const here = lockoutKey("203.0.113.9", EMAIL);
  const there = lockoutKey("198.51.100.7", EMAIL);

  failTimes(lockout, here, MAX_FAILURES - 1);
  assert.equal(lockout.lockedOut(here), false, "nine is still allowed");
  lockout.noteFailure(here);
  assert.equal(lockout.lockedOut(here), true, "the tenth locks");
  assert.equal(lockout.lockedOut(there), false, "the operator at another address is not locked");
});

test("rotating addresses locks the email once thirty failures have landed on it", () => {
  const lockout = signinLockout();
  //three failures from each of ten addresses: no single origin reaches ten, so the per-origin rule
  //never fires and the account would be open to a slow rotation forever
  for (let addr = 0; addr < 10; addr++) {
    failTimes(lockout, lockoutKey(`10.0.0.${addr}`, EMAIL), 3);
  }
  assert.equal(30, MAX_FAILURES_PER_EMAIL, "this test spends exactly the ceiling");
  assert.equal(lockout.lockedOut(lockoutKey("192.0.2.1", EMAIL)), true, "a never-seen address is refused too");
  assert.equal(lockout.lockedOut(lockoutKey("192.0.2.1", "someone.else@example.com")), false, "other accounts are untouched");
});

test("the email ceiling is reached one failure short, then not", () => {
  const lockout = signinLockout();
  for (let i = 0; i < MAX_FAILURES_PER_EMAIL - 1; i++) {
    lockout.noteFailure(lockoutKey(`10.1.${i}.1`, EMAIL));
  }
  assert.equal(lockout.lockedOut(lockoutKey("192.0.2.1", EMAIL)), false, "twenty-nine from anywhere is still allowed");
  lockout.noteFailure(lockoutKey("10.9.9.9", EMAIL));
  assert.equal(lockout.lockedOut(lockoutKey("192.0.2.1", EMAIL)), true);
});

test("the email half is case-folded, so changing case is not a new account", () => {
  const lockout = signinLockout();
  for (let i = 0; i < MAX_FAILURES_PER_EMAIL; i++) {
    lockout.noteFailure(lockoutKey(`10.2.${i}.1`, i % 2 ? "ops@example.com" : "OPS@EXAMPLE.COM"));
  }
  assert.equal(lockout.lockedOut(lockoutKey("192.0.2.1", "Ops@Example.Com")), true);
});

test("a null address shares one origin, which makes the per-origin rule a per-email one", () => {
  //what a panel with no TRUSTED_PROXY_HOPS sees: every caller is `-`. Ten failures lock the email
  //for everyone, which is the stricter direction and the intended one
  const lockout = signinLockout();
  failTimes(lockout, lockoutKey(null, EMAIL), MAX_FAILURES);
  assert.equal(lockout.lockedOut(lockoutKey(null, EMAIL)), true);
});

test("a success clears both counters", () => {
  const lockout = signinLockout();
  for (let addr = 0; addr < 10; addr++) {
    failTimes(lockout, lockoutKey(`10.0.0.${addr}`, EMAIL), 3);
  }
  assert.equal(lockout.lockedOut(lockoutKey("10.0.0.1", EMAIL)), true);
  lockout.clear(lockoutKey("10.0.0.1", EMAIL));
  assert.equal(lockout.lockedOut(lockoutKey("10.0.0.1", EMAIL)), false);
  assert.equal(lockout.lockedOut(lockoutKey("10.0.0.2", EMAIL)), false, "the email counter went too");
});

test("the window ends and both counters start over", (t) => {
  const lockout = signinLockout();
  let now = 1_000_000;
  t.mock.method(Date, "now", () => now);

  for (let addr = 0; addr < 10; addr++) {
    failTimes(lockout, lockoutKey(`10.0.0.${addr}`, EMAIL), 3);
  }
  failTimes(lockout, lockoutKey("203.0.113.9", EMAIL), MAX_FAILURES);
  assert.equal(lockout.lockedOut(lockoutKey("203.0.113.9", EMAIL)), true);
  assert.equal(lockout.lockedOut(lockoutKey("192.0.2.1", EMAIL)), true);

  now += FAILURE_WINDOW_MS + 1;
  assert.equal(lockout.lockedOut(lockoutKey("203.0.113.9", EMAIL)), false);
  assert.equal(lockout.lockedOut(lockoutKey("192.0.2.1", EMAIL)), false);
});

test("the lockout key keeps the email recoverable after any address", () => {
  assert.equal(lockoutKey("2001:db8::1", "A@B.c"), "2001:db8::1|a@b.c");
  assert.equal(lockoutKey(null, "a@b.c"), "-|a@b.c");
});
