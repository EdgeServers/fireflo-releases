import { strict as assert } from "node:assert";
import { test } from "node:test";

import { consumptionIsDurable, reconcile, type ReconcileInput } from "./reconcile.ts";

const money = (scaled: number) => (scaled / 10_000).toFixed(4);

function input(overrides: Partial<ReconcileInput> = {}): ReconcileInput {
  //the shape a healthy account actually has, taken from the dev database: credited equals
  //balance + reserved to the unit, and reserved covers consumption with some block left over
  return {
    accountId: "acct-1001",
    credited: 1_000_000,
    consumed: 300_000,
    balance: 600_000,
    reserved: 400_000,
    spent: 0,
    pendingCredit: 0,
    unratedMessages: 0,
    daysMissingRollup: 0,
    ...overrides,
  };
}

test("the money identity is credited = balance + reserved, and consumption is not in it", () => {
  //THE CORRECTION. The obvious equation subtracts consumption from the left, and it is wrong:
  //consumption never touches either column. Reserving moves an amount from balance to reserved and
  //spending happens in memory, so every movement the database sees leaves the sum unchanged.
  //Verified against three real accounts before this was written -- drift 0 on all of them
  const r = reconcile(input(), money);
  assert.equal(r.moneyDrift, 0);
  assert.equal(r.residual, 0);
  assert.equal(r.balanced, true);
});

test("from gateway V1.95.0 settled spending is the third column of the identity", () => {
  //the same account after the gateway settles: 350,000 of the 400,000 reserved moved to spent.
  //Without the third column this read as 350,000 of credit lost
  const r = reconcile(input({ reserved: 50_000, spent: 350_000, consumed: 340_000 }), money);
  assert.equal(r.moneyDrift, 0, "credited = balance + reserved + spent");
  assert.equal(r.balanced, true);
  assert.equal(r.heldUnspent, 60_000, "reserved + spent − consumed: still the credit held and not yet spent");
});

test("consumption shows up as reserved minus consumed, not as a money gap", () => {
  const r = reconcile(input(), money);
  assert.equal(r.heldUnspent, 100_000);
  assert.ok(r.attributions.some((a) => a.code === "heldUnspent"));
  //and it does NOT make the account unbalanced -- a block held mid-send is the normal state
  assert.equal(r.balanced, true);
});

test("credit nobody put in is reported, and named as the worse direction", () => {
  const r = reconcile(input({ credited: 900_000 }), money);
  assert.equal(r.residual, -100_000);
  assert.equal(r.balanced, false);
  const line = r.attributions.find((a) => a.code === "creditMinted")!;
  assert.equal(line.amount, 100_000);
  assert.match(line.message, /nobody put in/);
});

test("credit that vanished is reported the other way round", () => {
  const r = reconcile(input({ credited: 1_100_000 }), money);
  assert.equal(r.residual, 100_000);
  assert.equal(r.balanced, false);
  assert.ok(r.attributions.some((a) => a.code === "creditLost"));
});

test("B2 a pending top-up causes no money gap at all, and is still named", () => {
  //THE CORRECTION. This case used to pass `credited: 1_500_000` WITH `pendingCredit: 500_000` --
  //credited including the pending amount -- and the query layer cannot produce that: CREDITED_SQL
  //splits applied from pending with a FILTER, so `credited` is applied-only. So is
  //`balance + reserved`, because a pending entry is one the gateway has not applied. The pending
  //amount is absent from both sides and cancels itself.
  //
  //The old input was the only shape in which subtracting it was correct, which is why the bug
  //survived: the test constructed the world the code assumed instead of the world it runs in.
  //With a real input the subtraction produced a residual of -P and reported a pending top-up as
  //creditMinted, permanently, on exactly the entry applyPendingRecharges deliberately leaves
  //pending.
  const r = reconcile(input({ credited: 1_000_000, pendingCredit: 500_000 }), money);
  assert.equal(r.moneyDrift, 0, "a pending entry is on neither side of the identity");
  assert.equal(r.residual, 0, "so there is nothing to explain");
  assert.equal(r.balanced, true);
  const line = r.attributions.find((a) => a.code === "pendingCredit")!;
  assert.equal(line.amount, 500_000, "but it is still worth saying it is coming");
});

test("B1 a pending transfer OUT is named as leaving, not arriving", () => {
  //CREDITED_SQL counts a transfer negatively for the payer, so its pending half is negative too.
  //Before B1 the payee's side of a transfer was not counted at all and this could not arise; now
  //it can, and a reseller who has just funded a child must not be told credit is arriving
  const r = reconcile(input({ pendingCredit: -70_000 }), money);
  assert.equal(r.residual, 0, "a pending transfer is on neither side either");
  assert.equal(r.balanced, true);
  const line = r.attributions.find((a) => a.code === "pendingCredit")!;
  assert.match(line.message, /Transfers out/, "named as leaving, not as credit arriving");
  assert.equal(line.amount, -70_000, "and the amount stays the signed contribution");
  //ReconcileCard renders `amount` in front of the message, so the message must not restate the
  //figure: a positive magnitude beside a negative sign reads as a contradiction
  assert.doesNotMatch(line.message, /[0-9]/);
});

test("traffic charged with nothing reserved is named, with the benign cause first", () => {
  //what acct-1001 on the dev database actually looks like: 74.0400 consumed, zero reserved,
  //because prepaid credit has never been switched on there
  const r = reconcile(input({ consumed: 740_400, reserved: 0, balance: 1_000_000 }), money);
  assert.equal(r.heldUnspent, -740_400);
  const line = r.attributions.find((a) => a.code === "chargedWithoutReserving")!;
  assert.equal(line.amount, 740_400);
  assert.match(line.message, /smsg\.balance\.enabled has been off/);
  //still balanced: the MONEY identity holds. Consumption without reservation is a different fault
  assert.equal(r.balanced, true);
});

test("a missing rollup is named but does not lose the consumption", () => {
  //the tail still counts it today. What it means is that the purge would take it
  const missing = input({ daysMissingRollup: 3 });
  assert.equal(consumptionIsDurable(missing), false);
  assert.equal(consumptionIsDurable(input()), true);
  const r = reconcile(missing, money);
  assert.match(r.attributions.find((a) => a.code === "missingRollup")!.message, /rollup --catch-up/);
  assert.equal(r.balanced, true);
});

test("unrated messages are counted, never summed into either identity", () => {
  //the arithmetic error this guards: subtracting a COUNT from an AMOUNT
  const r = reconcile(input({ unratedMessages: 1200 }), money);
  assert.equal(r.residual, 0);
  assert.equal(r.attributions.find((a) => a.code === "unrated")!.amount, null);
});

test("rounding is not a discrepancy", () => {
  assert.equal(reconcile(input({ credited: 1_000_000 }), money).balanced, true);
  assert.equal(reconcile(input({ credited: 1_000_002 }), money).balanced, false);
});

// ---------------------------------------------------------------------------
// Test plan M14. Cases above predate the plan; these fill the gaps it names.
// ---------------------------------------------------------------------------

test("M14.3 the naive equation is wrong by exactly the consumption, on a healthy account", () => {
  //the anti-regression. Someone will eventually "simplify" the two identities back into one, and
  //this is the case that must stop them: on an account that balances, the naive form is out by
  //precisely what was consumed -- which is why it reported a false discrepancy on every account
  const i = input({ consumed: 300_000 });
  const naive = i.credited - i.consumed - (i.balance + i.reserved);

  assert.equal(reconcile(i, money).moneyDrift, 0, "the correct identity holds");
  assert.equal(naive, -i.consumed, "the naive one is out by the consumption, every time");
  assert.notEqual(naive, 0);
});

test("M14.3 the naive equation is wrong for any consumption, not just this fixture", () => {
  //a property rather than an example, so nobody can fix the case by changing the numbers
  for (const consumed of [1, 7, 55_555, 300_000, 999_999]) {
    const i = input({ consumed });
    assert.equal(reconcile(i, money).moneyDrift, 0);
    assert.equal(i.credited - consumed - (i.balance + i.reserved), -consumed);
  }
});

test("M14.8 reconciliation is lifetime: the input carries no period at all", () => {
  //not decoration. A shorter window needs an opening balance nothing records, and a wrong opening
  //figure invents a discrepancy every run. The absence of a date field is the design, so pin it
  const keys = Object.keys(input()).sort();
  assert.deepEqual(keys, [
    "accountId", "balance", "consumed", "credited",
    "daysMissingRollup", "pendingCredit", "reserved", "spent", "unratedMessages",
  ]);
  //an allowlist rather than a pattern: "pending" contains "end", and a clever regex here would
  //fail for a reason that has nothing to do with what the case is asserting
  const bounds = ["from", "to", "since", "until", "startDate", "endDate", "month", "period", "range"];
  for (const b of bounds) {
    assert.ok(!keys.includes(b), `${b} is a period bound, and reconciliation has no period`);
  }
});

test("M14 reconcile never mutates its input", () => {
  //the module's own doc says nothing here writes anything. The cheapest form of that guarantee
  const i = input({ pendingCredit: 50_000, unratedMessages: 3, daysMissingRollup: 2 });
  const before = JSON.stringify(i);
  reconcile(i, money);
  assert.equal(JSON.stringify(i), before);
});

test("M14 an untouched account balances with nothing to say", () => {
  const r = reconcile(input({
    credited: 0, consumed: 0, balance: 0, reserved: 0,
  }), money);
  assert.equal(r.balanced, true);
  assert.equal(r.residual, 0);
  assert.deepEqual(r.attributions, []);
});

test("M14 balanced means exactly zero drift, because every amount is an integer", () => {
  //`Math.abs(residual) < MATERIAL` with MATERIAL = 1 over integer ten-thousandths means only a
  //residual of 0 balances. Worth pinning explicitly: the constant reads like a tolerance and is not
  assert.equal(reconcile(input(), money).balanced, true);
  assert.equal(reconcile(input({ credited: 1_000_001 }), money).balanced, false);
  assert.equal(reconcile(input({ credited: 999_999 }), money).balanced, false);
});

test("M14 FINDING: a one-unit drift is unbalanced and unexplained", () => {
  //`balanced` uses `< MATERIAL` while the attributions use `> MATERIAL`, so a residual of exactly
  //±1 falls between them: the account is reported as not balancing, with nothing said about why.
  //The existing "rounding is not a discrepancy" case checks 0 and 2 and steps over this boundary.
  //
  //Pinned as current behaviour, not endorsed. Either the attribution thresholds should be >= /
  //<= MATERIAL so a one-unit drift is named, or `balanced` should be <= so it is tolerated. It
  //cannot be right to flag it and then have nothing to say.
  for (const credited of [1_000_001, 999_999]) {
    const r = reconcile(input({ credited }), money);
    assert.equal(Math.abs(r.residual), 1);
    assert.equal(r.balanced, false, "flagged as not balancing");

    //nothing in the list is about the residual. Whatever else the account has to say -- a normal
    //held-unspent block, say -- the one number that made it unbalanced goes unmentioned
    const aboutTheResidual = r.attributions
      .filter((a) => a.code === "creditLost" || a.code === "creditMinted");
    assert.deepEqual(aboutTheResidual, [], "and unexplained -- this is the inconsistency");
  }
});

test("M14 pending credit never closes a real gap, in either direction", () => {
  //the half of the original case that was always right: pendingCredit must not be counted as money
  //that arrived. It is now not counted as ANYTHING arithmetic, so a genuine 50,000 gap stays a
  //genuine 50,000 gap whatever is pending -- which is the property that matters. Before, a pending
  //amount of the same size silently cancelled a real discrepancy and reported the account balanced
  const r = reconcile(input({ credited: 1_050_000, pendingCredit: 50_000 }), money);
  assert.equal(r.moneyDrift, 50_000, "the raw gap");
  assert.equal(r.residual, 50_000, "and it survives an unrelated pending entry of the same size");
  assert.equal(r.balanced, false, "a real gap must not be explained away by a coincidence");
  assert.ok(r.attributions.some((a) => a.code === "creditLost"));
  assert.ok(r.attributions.some((a) => a.code === "pendingCredit"));
});

test("M14 anti-vacuity: forcing balanced true would fail the cases that matter", () => {
  //if reconcile() were rewritten to return balanced:true unconditionally, these must break
  const minted = reconcile(input({ credited: 900_000 }), money);
  const lost = reconcile(input({ credited: 1_100_000 }), money);
  assert.equal(minted.balanced, false);
  assert.equal(lost.balanced, false);
  assert.notDeepEqual(minted.attributions, []);
  assert.notDeepEqual(lost.attributions, []);
});

test("M14.7 consumption is only durable once every day is rolled up", () => {
  assert.equal(consumptionIsDurable(input({ daysMissingRollup: 0 })), true);
  assert.equal(consumptionIsDurable(input({ daysMissingRollup: 1 })), false);
});
