//server-only by convention: node:crypto, and nothing a client component imports
import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";

/**
 * Seals a stored secret the way the gateway does, so a copy of the database alone does not give
 * it away. The panel writes customer passwords and reads them back (connection instructions, the
 * SMPP test), so it has to speak the gateway's format exactly.
 *
 * <p><strong>The format is the gateway's `SecretBox`:</strong> `enc:v1:` then base64url, without
 * padding, of a 12-byte nonce, the AES-256-GCM ciphertext and its 16-byte tag. The key is
 * `FIREFLO_SECRETS_KEY`, the same value as in the gateway's `fireflo.env`: 32 bytes of base64 used
 * as they are, anything else SHA-256'd to 32 bytes. `FIREFLO_SECRETS_KEY_NEXT` is tried on open and
 * never used to seal.
 *
 * <p>With no key set nothing is sealed, and a sealed value cannot be opened: `open` throws
 * {@link SealedWithoutKey}, whose message is safe to show an operator. Callers that only need to
 * carry a stored value through unchanged (the "keep the stored one" write) never open it.
 */

export const SEALED_PREFIX = "enc:v1:";
const NONCE_BYTES = 12;
const TAG_BYTES = 16;

export class SealedWithoutKey extends Error {
  constructor(message: string) {
    super(message);
    this.name = "SealedWithoutKey";
  }
}

/** 32 bytes of base64 are the key; anything else is hashed to 32 bytes. Same rule as the gateway. */
function deriveKey(setting: string): Buffer {
  const trimmed = setting.trim();
  //base64 only when the whole string is one: Buffer.from ignores trailing junk, which would make a
  //passphrase that happens to start with base64 characters derive differently from the gateway
  if (/^[A-Za-z0-9+/]+={0,2}$/.test(trimmed)) {
    const decoded = Buffer.from(trimmed, "base64");
    if (decoded.length === 32 && decoded.toString("base64").replace(/=+$/, "") === trimmed.replace(/=+$/, "")) {
      return decoded;
    }
  }
  return createHash("sha256").update(trimmed, "utf8").digest();
}

function keys(): Buffer[] {
  return [process.env.FIREFLO_SECRETS_KEY, process.env.FIREFLO_SECRETS_KEY_NEXT]
    .filter((k): k is string => typeof k === "string" && k.trim() !== "")
    .map(deriveKey);
}

/** Whether a key is configured, so {@link seal} does anything. */
export function sealingEnabled(): boolean {
  return keys().length > 0;
}

/** Whether a stored value is one the gateway or this panel sealed. */
export function isSealed(value: string | null | undefined): value is string {
  return typeof value === "string" && value.startsWith(SEALED_PREFIX);
}

/**
 * The value as it should be stored: sealed when a key is configured, as given when not. Null and
 * empty stay as they are, and a value already sealed is not sealed twice.
 */
export function seal(plain: string | null): string | null {
  if (!plain || isSealed(plain)) {
    return plain;
  }
  const [key] = keys();
  if (!key) {
    return plain;
  }
  const nonce = randomBytes(NONCE_BYTES);
  const cipher = createCipheriv("aes-256-gcm", key, nonce, { authTagLength: TAG_BYTES });
  const body = Buffer.concat([cipher.update(plain, "utf8"), cipher.final(), cipher.getAuthTag()]);
  return SEALED_PREFIX + Buffer.concat([nonce, body]).toString("base64url");
}

/**
 * The stored value as the gateway uses it: opened when sealed, as stored when not.
 *
 * @throws SealedWithoutKey when the value is sealed and no configured key opens it
 */
export function open(stored: string | null): string | null {
  if (!isSealed(stored)) {
    return stored;
  }
  const candidates = keys();
  if (!candidates.length) {
    throw new SealedWithoutKey("the value is encrypted and FIREFLO_SECRETS_KEY is not set on this panel");
  }
  const raw = Buffer.from(stored.slice(SEALED_PREFIX.length), "base64url");
  if (raw.length <= NONCE_BYTES + TAG_BYTES) {
    throw new SealedWithoutKey("the value is marked encrypted but is too short to be");
  }
  const nonce = raw.subarray(0, NONCE_BYTES);
  const body = raw.subarray(NONCE_BYTES, raw.length - TAG_BYTES);
  const tag = raw.subarray(raw.length - TAG_BYTES);
  for (const key of candidates) {
    try {
      const decipher = createDecipheriv("aes-256-gcm", key, nonce, { authTagLength: TAG_BYTES });
      decipher.setAuthTag(tag);
      return Buffer.concat([decipher.update(body), decipher.final()]).toString("utf8");
    } catch {
      //the next key, if there is one: a rotation in progress
    }
  }
  throw new SealedWithoutKey(
    "the value is encrypted with a key that is not this panel's FIREFLO_SECRETS_KEY"
    + (candidates.length > 1 ? " or FIREFLO_SECRETS_KEY_NEXT" : "")
  );
}

/**
 * Opens a value for display or use, and says why when it cannot, without throwing: for the places
 * that show a password or dial with one and have a sentence to put in its place.
 */
export function openOrExplain(stored: string | null): { value: string | null; problem: string | null } {
  try {
    return { value: open(stored), problem: null };
  } catch (err) {
    if (err instanceof SealedWithoutKey) {
      return { value: null, problem: `The stored password cannot be read: ${err.message}.` };
    }
    throw err;
  }
}
