/**
 * What an account owes for a period, and the messages it owes it for.
 *
 * <p>Server-only. Reads through `metrics-db`, which exposes `query()` and nothing else — a
 * statement is a report, and nothing here writes anything.
 *
 * <h2>The invoice is a query, not a counter</h2>
 *
 * <p>Everything below is a pure function of the call records over a half-open window. It never reads
 * `account_balance`, never reads `balance_ledger`, and never reads the gateway's in-memory
 * enforcement figures. That is the whole design: the limit check is allowed to be stale, the
 * invoice is not, and keeping them apart means the only thing that can make a bill wrong is a
 * missing or extra record.
 *
 * <h2>...and `cdr_submit` is not the only place those records live</h2>
 *
 * <p><strong>`fireflo usage purge` deletes `cdr_submit` past the retention window.</strong> Reading
 * that table alone, a statement for a purged period recomputed to **zero** — and the panel then
 * compared that zero against the closed invoice and rendered "the full invoice is owed back and
 * carries forward as a credit". A correct, paid invoice presented as entirely refundable, on every
 * period older than the window, for ever.
 *
 * <p>`usage_daily` exists precisely to stop this: `docs/13` says no statement older than the window
 * can ever be reissued, and the summary table is what was supposed to make that true. It was written
 * every night and this file never read it.
 *
 * <p>So a day is taken from `cdr_submit` when its rows are still there and from `usage_daily` when
 * they are not — **never both**, which is the same disjointness rule `reconcile-sql.ts` states, and
 * for the same reason. The live path is unchanged: while an account has call records for a day, that
 * day is billed from them exactly as before.
 *
 * <h2>One row per message, as UsageRollup</h2>
 *
 * <p>Every vendor attempt is its own `cdr_submit` row, and all of them share the message's receipt,
 * so counting rows billed a message that failed over once as two submitted and two delivered -- and
 * its refused attempt as an unrated message. The counts here take one row per message by the
 * rollup's own `DISTINCT ON` (money row first, else the latest attempt), which is also what makes a
 * live day agree with the `usage_daily` line it later becomes. The money needed no change: only one
 * row per message ever carries a price. `lib/cdr-grain.ts` holds the rule.
 *
 */

import type { BillingPeriod } from "./billing-period";
import { carriesMoney, isMessageRow, messageRows, partOne } from "./cdr-grain";
import { parseBillReference, type ClosedPeriod } from "./period-close";
import { OUTCOME_LATERAL } from "./metrics-queries";
import { query } from "./metrics-db";
import { hasVendorAttempt } from "./metrics-schema";

/**
 * Part 1 only. Redundant inside `messageRows`, which already takes part 1 alone, and kept on each
 * count so the filter survives if the FROM ever changes back to a plain table.
 */
const ONE_ROW_PER_MESSAGE = partOne();

/** The same rows, named for what a money query is asking. */
const CARRIES_MONEY = carriesMoney();

export interface StatementLine {
  product: string;
  submitted: number;
  delivered: number;
  failed: number;
  expired: number;
  pending: number;
  /** Counted, never summed: these are the messages that went out with no price. */
  unrated: number;
  /** Scaled by 10,000. */
  amount: number;
}

export interface StatementSummary {
  accountId: string;
  since: string;
  until: string;
  label: string;
  currency: string | null;
  lines: StatementLine[];
  totalSubmitted: number;
  totalDelivered: number;
  totalUnrated: number;
  /** Scaled by 10,000. The figure being invoiced. */
  totalAmount: number;
  /**
   * Whether this period can still be recomputed at all.
   *
   * <p>False when the call records for the period are gone AND no rollup covers it, which makes
   * `totalAmount` zero for want of evidence rather than because nothing was sent. **A caller
   * comparing a recomputed figure against a closed invoice must not compare this one** -- that is
   * how a paid invoice came to be reported as fully refundable. See `restatementOf`.
   */
  recomputable: boolean;
  /** Days in the period taken from `usage_daily` because their call records have been purged. */
  daysFromSummary: number;
}

export interface StatementRow {
  id: string;
  submittedAt: string;
  gatewayMsgId: string;
  product: string | null;
  to: string | null;
  from: string | null;
  parts: number;
  outcome: string;
  /** Scaled by 10,000, or null for a message that went out unrated or was refunded. */
  price: number | null;
}

/**
 * The bill, one line per product.
 *
 * <p>Grouped by product because that is what a customer recognises and what a tariff is set on.
 * `COALESCE(product, '')` rather than dropping the null: traffic that named no product is still
 * traffic and still costs money, and hiding it would make the lines not add up to the total.
 *
 * <p><strong>Billed on `submitted_at`, never `accepted_at`.</strong> `accepted_at` is nullable, and
 * a period boundary drawn on a nullable column silently loses every row where it is missing.
 * `submitted_at` is NOT NULL, is the gateway's own clock, and never moves once written.
 */
export async function statementSummary(
  accountId: string,
  period: BillingPeriod,
  currency: string | null,
  zone: string
): Promise<StatementSummary> {
  const grain = { vendorAttempt: await hasVendorAttempt() };
  const rows = await query<{
    product: string;
    submitted: string;
    delivered: string;
    failed: string;
    expired: string;
    pending: string;
    unrated: string;
    amount: string;
    from_summary: string;
  }>(
    `WITH live AS (
         SELECT COALESCE(s.product, '')                                      AS product,
                count(*) FILTER (WHERE ${ONE_ROW_PER_MESSAGE})               AS submitted,
                count(*) FILTER (WHERE ${ONE_ROW_PER_MESSAGE}
                                   AND o.final_state = 'DELIVERED')          AS delivered,
                count(*) FILTER (WHERE ${ONE_ROW_PER_MESSAGE}
                                   AND o.final_state IN ('FAILED', 'REJECTED', 'DROPPED')) AS failed,
                count(*) FILTER (WHERE ${ONE_ROW_PER_MESSAGE}
                                   AND o.final_state = 'EXPIRED')            AS expired,
                count(*) FILTER (WHERE ${ONE_ROW_PER_MESSAGE}
                                   AND o.final_state IS NULL)                AS pending,
                count(*) FILTER (WHERE ${ONE_ROW_PER_MESSAGE}
                                   AND s.price IS NULL)                      AS unrated,
                COALESCE(SUM(s.price) FILTER (WHERE ${CARRIES_MONEY}), 0)    AS amount,
                0                                                            AS from_summary
           --one row per message, as UsageRollup, with the account and period inside the DISTINCT
           --ON. The amount is unchanged by it -- only that row carries a price
           FROM ${messageRows(
             "s.account_id = $1 AND s.submitted_at >= $2 AND s.submitted_at < $3",
             grain
           )}${OUTCOME_LATERAL}
          GROUP BY COALESCE(s.product, '')
     ),
     -- the purged tail. usage_daily is keyed (account_id, day, product) and its BILLING columns are
     -- final for a finished day, which is exactly what an old invoice needs. Taken only for days
     -- the call records no longer cover, so the two sources can never both count one day
     purged AS (
         SELECT u.product,
                SUM(u.submitted)                                             AS submitted,
                SUM(u.delivered)                                             AS delivered,
                SUM(u.failed)                                                AS failed,
                SUM(u.expired)                                               AS expired,
                SUM(u.pending_at_rollup)                                     AS pending,
                SUM(u.unrated_messages)                                      AS unrated,
                SUM(u.price_total)                                           AS amount,
                count(DISTINCT u.day)                                        AS from_summary
           FROM usage_daily u
          WHERE u.account_id = $1
            AND u.day >= ($2 AT TIME ZONE $4)::date
            AND u.day <= ($3 AT TIME ZONE $4)::date
            AND NOT EXISTS (
                    SELECT 1 FROM cdr_submit s2
                     WHERE s2.account_id = u.account_id
                       AND (s2.submitted_at AT TIME ZONE $4)::date = u.day)
          GROUP BY u.product
     )
     SELECT product,
            SUM(submitted) AS submitted, SUM(delivered) AS delivered, SUM(failed) AS failed,
            SUM(expired) AS expired, SUM(pending) AS pending, SUM(unrated) AS unrated,
            SUM(amount) AS amount, SUM(from_summary) AS from_summary
       FROM (SELECT * FROM live UNION ALL SELECT * FROM purged) sources
      GROUP BY product
      ORDER BY 8 DESC, 1`,
    [accountId, period.since, period.until, zone]
  );

  const lines: StatementLine[] = rows.map((r) => ({
    product: r.product,
    submitted: Number(r.submitted),
    delivered: Number(r.delivered),
    failed: Number(r.failed),
    expired: Number(r.expired),
    pending: Number(r.pending),
    unrated: Number(r.unrated),
    amount: Number(r.amount),
  }));
  const daysFromSummary = rows.reduce((n, r) => n + Number(r.from_summary), 0);

  return {
    accountId,
    since: period.since.toISOString(),
    until: period.until.toISOString(),
    label: period.label,
    currency,
    lines,
    totalSubmitted: lines.reduce((n, l) => n + l.submitted, 0),
    totalDelivered: lines.reduce((n, l) => n + l.delivered, 0),
    totalUnrated: lines.reduce((n, l) => n + l.unrated, 0),
    totalAmount: lines.reduce((n, l) => n + l.amount, 0),
    //a period with no lines at all is only "nothing was sent" if the evidence still exists. With
    //the call records purged and no rollup covering them there is nothing left to recompute FROM,
    //and reporting that as a total of zero is what turned a paid invoice into a full credit note
    recomputable: lines.length > 0,
    daysFromSummary,
  };
}

/** Where a page of the detail left off. `submitted_at` alone is not unique enough to page on. */
export interface StatementCursor {
  submittedAt: string;
  id: string;
}

/**
 * The messages behind the bill, keyset-paged.
 *
 * <p><strong>Keyset rather than OFFSET.</strong> An account's month can be millions of rows, and
 * `OFFSET 500000` makes PostgreSQL walk and discard half a million of them for every page — the
 * export of a large account would spend most of its time re-reading rows it had already written.
 *
 * <p>Every message is listed, not only the priced ones, because a customer reconciling an invoice
 * against their own send log needs to find the message they are looking for. The price column is
 * what distinguishes a message that was charged, and it is the same column the total is summed from.
 *
 * <p><strong>One row per message, as UsageRollup</strong> -- not one per vendor attempt. A failover
 * used to list the message twice, the refused attempt carrying the message's own DELIVERED receipt
 * and no price, which reads to a customer as a delivered message they were not charged for. Taken
 * by `isMessageRow` rather than a `DISTINCT ON` subquery, so each keyset page still walks the index
 * instead of sorting the whole period. Vendor attempts are an operator's question, and the operator
 * message browser still shows them.
 */
export async function statementDetail(
  accountId: string,
  period: BillingPeriod,
  cursor: StatementCursor | null,
  limit: number
): Promise<{ rows: StatementRow[]; nextCursor: StatementCursor | null }> {
  const grain = { vendorAttempt: await hasVendorAttempt() };
  const params: unknown[] = [accountId, period.since, period.until, limit];
  let keyset = "";
  if (cursor) {
    params.push(cursor.submittedAt, cursor.id);
    keyset = ` AND (s.submitted_at, s.id) > ($${params.length - 1}::timestamptz, $${params.length}::bigint)`;
  }

  const rows = await query<{
    id: string;
    submitted_at: string;
    gateway_msg_id: string;
    product: string | null;
    dst: string | null;
    src: string | null;
    part_count: number;
    final_state: string | null;
    price: string | null;
  }>(
    `SELECT s.id::text, s.submitted_at, s.gateway_msg_id, s.product,
            s.dest_addr AS dst, s.source_addr AS src, s.part_count,
            o.final_state, s.price::text
       FROM cdr_submit s${OUTCOME_LATERAL}
      WHERE s.account_id = $1
        AND s.submitted_at >= $2
        AND s.submitted_at < $3
        AND ${isMessageRow("s", grain)}${keyset}
      ORDER BY s.submitted_at, s.id
      LIMIT $4`,
    params
  );

  const mapped: StatementRow[] = rows.map((r) => ({
    id: r.id,
    submittedAt: r.submitted_at,
    gatewayMsgId: r.gateway_msg_id,
    product: r.product,
    to: r.dst,
    from: r.src,
    parts: r.part_count,
    //"Pending" rather than empty: a message with no receipt yet is a state, not a missing value
    outcome: r.final_state ?? "PENDING",
    price: r.price === null ? null : Number(r.price),
  }));

  const last = rows[rows.length - 1];
  return {
    rows: mapped,
    //a short page is the last page. Asking for one more to find out would double the query count
    nextCursor:
      last && rows.length === limit ? { submittedAt: last.submitted_at, id: last.id } : null,
  };
}

/**
 * The periods already closed for an account, newest first.
 *
 * <p>Reads `BILL` rows, which `idx_balance_ledger_human` covers — they are human entries by the
 * negative predicate, which is exactly the property V1.35.0 was written for.
 *
 * <p>`delta` is stored negative (consumption); it is returned positive, because every surface asks
 * "what was this invoiced at" rather than "which way did it move".
 */
export async function closedPeriods(accountId: string): Promise<ClosedPeriod[]> {
  const rows = await query<{ ref: string | null; delta: string; created_at: string; note: string | null }>(
    `SELECT ref, delta::text, created_at, note
       FROM balance_ledger
      WHERE account_id = $1 AND entry_type = 'BILL'
      ORDER BY created_at DESC, id DESC
      LIMIT 24`,
    [accountId]
  );
  return rows.flatMap((r) => {
    const parsed = parseBillReference(r.ref);
    //a BILL row with an unparseable ref is not shown rather than shown under a guessed period: an
    //invoice attributed to the wrong month is worse than one nobody can see
    return parsed
      ? [{ label: parsed.label, invoiced: Math.abs(Number(r.delta)), closedAt: r.created_at, note: r.note }]
      : [];
  });
}
