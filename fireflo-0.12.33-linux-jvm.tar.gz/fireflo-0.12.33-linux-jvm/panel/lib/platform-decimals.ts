import { configQuery } from "@/lib/config-db";
import { clampScale, DEFAULT_MONEY_SCALE } from "@/lib/format";

/** The property the gateway reads. Platform-wide, like the currency, and not per account. */
export const MONEY_SCALE_KEY = "smsg.money.scale";

/**
 * How many decimal places a **total** is shown with.
 *
 * <p>Totals only. A per-message rate keeps four places wherever it is rendered — `0.0450` shown as
 * `0.05` is 11% out on every message, and a customer reconciling an invoice against `/secure/rate`
 * would be wrong. `lib/exports.ts` keeps four for the same reason: a CSV column is summed by
 * somebody's spreadsheet, and rounding before the sum introduces drift.
 *
 * <p>Returns `DEFAULT_MONEY_SCALE` rather than null when it cannot be read. That differs from
 * `platformCurrency`, deliberately: there is no sensible way to render an amount with "unknown"
 * decimal places, and file mode — where this panel cannot see `smsg.properties` at all — has the
 * gateway using the same default. So the fallback is the answer, not a failure to answer.
 */
export async function platformDecimals(): Promise<number> {
  try {
    const rows = await configQuery<{ value: string | null }>(
      `SELECT value FROM app_config WHERE key = $1 AND enabled`,
      [MONEY_SCALE_KEY]
    );
    return clampScale(rows[0]?.value);
  } catch {
    //a page that renders amounts must not fail because one configuration row could not be read
    return DEFAULT_MONEY_SCALE;
  }
}

export { clampScale, DEFAULT_MONEY_SCALE, MAX_MONEY_SCALE } from "@/lib/format";
