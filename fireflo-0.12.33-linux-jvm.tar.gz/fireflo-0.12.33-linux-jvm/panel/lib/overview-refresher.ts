import { configQuery } from "@/lib/config-db";
import {
  billingDays,
  failureBreakdown,
  revenueByAccount,
  trafficOverTime,
} from "@/lib/metrics-queries";
import { hasUsageHourly, hourlyWatermark } from "@/lib/metrics-schema";
import {
  createRefresher,
  refreshSecondsFrom,
  type Refresher,
  type SnapshotDeps,
} from "@/lib/overview-snapshot";

/**
 * The one home-page refresher per process, wired to the real queries.
 *
 * <p>Held on `globalThis` rather than in a module variable (the pattern `lib/smpp-test.ts` uses for
 * its session registry) because `next dev` re-evaluates modules on every edit, and a refresher per
 * evaluation would be a timer per edit, each reading the database once a minute. Server-only:
 * importing this pulls `pg`.
 *
 * <p>Nothing starts until the first request for the overview: a panel nobody opens reads nothing,
 * and a panel with no metrics database never gets here (the route answers its 503 first).
 */

const slot = globalThis as { __firefloOverviewRefresher?: Refresher };

export function getOverviewRefresher(): Refresher {
  return (slot.__firefloOverviewRefresher ??= createRefresher(realDeps(), {
    refreshSeconds: refreshSecondsFrom(process.env),
  }));
}

/** For `instrumentation.ts`: let the timer go when the process is asked to stop. */
export function stopOverviewRefresher(): void {
  slot.__firefloOverviewRefresher?.stop();
}

const hooks = globalThis as { __firefloOverviewHooks?: boolean };

/**
 * Stops the refresher on SIGTERM and before a natural exit. Installed once per process however
 * many times `instrumentation.ts` runs under `next dev`; Next keeps its own SIGTERM handler, this
 * one only adds to it. The timer is unref'd and would not keep the process alive by itself, but a
 * tick that starts during shutdown would open a database read the pool is about to close under.
 */
export function installShutdownHook(): void {
  if (hooks.__firefloOverviewHooks) {
    return;
  }
  hooks.__firefloOverviewHooks = true;
  const stop = () => stopOverviewRefresher();
  process.once("SIGTERM", stop);
  process.once("beforeExit", stop);
}

function realDeps(): SnapshotDeps {
  return {
    traffic: (range, o) => trafficOverTime(range, o),
    revenue: (range, o) => revenueByAccount(range, o),
    //the breakdown covers the same 24 hours whatever the range (FAILURE_WINDOW_SINCE), so the
    //refresher reads it once; the 24h range is the one whose own window equals it
    failures: () => failureBreakdown("24h"),
    hasUsageHourly,
    hourlyWatermark,
    billingDays: () => billingDays(0),
    deadlineHours,
    now: () => new Date(),
    log: (line) => console.warn(line),
  };
}

const DEADLINE_KEY = "smsg.cdr.deadline.hours";
/** CdrExpirySweeper's DEFAULT_DEADLINE_HOURS, for a deployment whose config cannot be read. */
const DEADLINE_DEFAULT_HOURS = 24;
const DEADLINE_TTL_MS = 5 * 60_000;
let deadline: { at: number; hours: number } | null = null;

/**
 * How long the gateway waits for a receipt before closing a message as EXPIRED: the instant
 * `now - deadline` is where the page starts drawing buckets as still settling. Read from
 * `app_config` and held for five minutes; the coded default when the key is unset, when the config
 * database is not configured for this panel, or when the read fails.
 */
async function deadlineHours(): Promise<number> {
  if (deadline && Date.now() - deadline.at < DEADLINE_TTL_MS) {
    return deadline.hours;
  }
  let hours = DEADLINE_DEFAULT_HOURS;
  try {
    const rows = await configQuery<{ value: string | null }>(
      "SELECT value FROM app_config WHERE key = $1 AND enabled",
      [DEADLINE_KEY]
    );
    const n = Number(rows[0]?.value?.trim());
    if (Number.isFinite(n) && n > 0) {
      hours = n;
    }
  } catch {
    //no config database, or no grant: the default is the gateway's own
  }
  deadline = { at: Date.now(), hours };
  return hours;
}
