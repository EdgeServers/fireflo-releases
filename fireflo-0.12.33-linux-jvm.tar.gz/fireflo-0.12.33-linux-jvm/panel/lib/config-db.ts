import { Pool, type PoolClient, type QueryResultRow } from "pg";

/**
 * Write access to the gateway's configuration tables.
 *
 * <p>Deliberately separate from `metrics-db`, which documents that it never writes and is meant to
 * run as a SELECT-only role. Folding a write path into it would quietly retract that promise for
 * every query in the panel. Two modules means the read side can keep a read-only role while this
 * one is pointed at a user that may write, and it is obvious from the import which a caller is.
 *
 * <p>Fails closed: with `CONFIG_DATABASE_URL` unset there is no vendor or server editing at all. Enabling
 * writes against billing-adjacent configuration should be a decision someone made, not something
 * that happens to be on because a read URL exists.
 *
 * <p>This touches the configuration tables only — `app_worker` and `app_worker_property` for vendors
 * and servers, `app_product` for the product catalogue, and `app_rate_rule` with its
 * `app_rate_rule_condition` children for pricing. It never issues DDL, and it never goes near
 * `cdr_*`, `account_balance` or `balance_ledger`. That second half matters more now than it did when
 * only workers were editable: pricing decides what a message is charged, and the record of what it
 * *was* charged stays out of reach from here.
 *
 * <p>Note that none of these tables reach the gateway until it runs with `smsg.config.source=db`.
 * That one switch covers workers, logins, routing and rates together — it used to be four, one per
 * domain, and keeping them in agreement by hand is what it exists to stop.
 */
let pool: Pool | null = null;

export function isConfigWritable(): boolean {
  return !!process.env.CONFIG_DATABASE_URL?.trim();
}

function getPool(): Pool {
  const url = process.env.CONFIG_DATABASE_URL?.trim();
  if (!url) {
    throw new Error("CONFIG_DATABASE_URL is not set");
  }
  if (!pool) {
    pool = new Pool({
      connectionString: url,
      //small: this is operator-driven editing, not dashboard traffic
      max: 4,
      connectionTimeoutMillis: 5_000,
      idleTimeoutMillis: 30_000,
      statement_timeout: 10_000,
    });
  }
  return pool;
}

export async function configQuery<T extends QueryResultRow>(
  sql: string,
  params: unknown[] = []
): Promise<T[]> {
  const result = await getPool().query<T>(sql, params);
  return result.rows;
}

/**
 * Runs `work` in a transaction, rolling back on any error.
 *
 * <p>A vendor is a row in one table plus its properties in another. Writing them without a
 * transaction can leave a worker with half its settings — which the gateway would happily start,
 * because a missing property silently falls back to its coded default. A half-configured vendor
 * that runs is worse than one that was never created.
 */
export async function inTransaction<T>(work: (client: PoolClient) => Promise<T>): Promise<T> {
  const client = await getPool().connect();
  try {
    await client.query("BEGIN");
    const result = await work(client);
    await client.query("COMMIT");
    return result;
  } catch (err) {
    await client.query("ROLLBACK").catch(() => undefined);
    throw err;
  } finally {
    client.release();
  }
}

/** Test and shutdown helper. */
export async function closeConfigDb(): Promise<void> {
  const existing = pool;
  pool = null;
  await existing?.end();
}
