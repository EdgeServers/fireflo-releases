/**
 * The cross-origin check every mutating `/api/control` and `/api/mis` request passes through, from
 * `proxy.ts` (CP-S9 in the 0.13 readiness audit).
 *
 * <p>A leaf module: it imports nothing, so `origin-check.test.ts` runs on Node's own runner and
 * `proxy.ts` can import it without dragging the database in.
 *
 * <h2>What it defends</h2>
 *
 * <p>The session cookies are `SameSite=Lax` and the write routes take JSON bodies, which together
 * already stop a plain cross-site form post from carrying a session. This is the second layer: a
 * browser puts an `Origin` header on every cross-origin request and on every POST, and a value that
 * is not this panel's own origin is a request no page of ours made. It is answered 403 before any
 * route runs, so no route has to remember to ask.
 *
 * <h2>What "this panel's origin" is</h2>
 *
 * <p>`AUTH_URL`, when set -- the public origin the operator panel is told it lives at, and the same
 * value next-auth builds its redirects from. Without it, the request's own `Host` (or
 * `X-Forwarded-Host`, when a proxy in front rewrote it), compared by host alone because the scheme
 * on the wire behind a TLS-terminating proxy is not the one the browser saw.
 *
 * <p><strong>The consequence for a mis-set `AUTH_URL`:</strong> a panel whose `AUTH_URL` says
 * `https://panel.example.com` but is being used at `http://10.0.0.5:3000` now refuses every write
 * from the browser with the sentence {@link crossOriginRefusal} returns, which names both origins
 * and the variable. Reads keep working, because a same-origin GET carries no `Origin` header.
 */

const MUTATING = new Set(["POST", "PUT", "PATCH", "DELETE"]);

/** What the check needs from a request, so it can be tested without one. */
export interface OriginCheckInput {
  method: string;
  /** The `Origin` header, or null when the request had none. */
  origin: string | null;
  /** The `Host` header. */
  host: string | null;
  /** The `X-Forwarded-Host` header, or null. */
  forwardedHost?: string | null;
  /** `process.env.AUTH_URL`, or undefined. */
  authUrl?: string | null;
}

/**
 * @return null when the request may proceed, else the sentence to refuse it with
 */
export function crossOriginRefusal(input: OriginCheckInput): string | null {
  if (!MUTATING.has(input.method.toUpperCase())) {
    return null;
  }
  const origin = input.origin?.trim();
  //no Origin: not a browser making a cross-site request. curl, a script, a same-origin GET -- the
  //cookie rules and the route's own session check decide those, as they always did
  if (!origin) {
    return null;
  }
  const sent = parseOrigin(origin);
  if (!sent) {
    //"null" (a sandboxed frame, a redirect from a data: URL) or garbage: not ours
    return `Cross-origin request refused: the browser sent Origin "${origin}", which is not a web origin.`;
  }

  const expected = expectedOrigin(input.authUrl);
  if (expected) {
    if (sent.origin === expected.origin) {
      return null;
    }
    return `Cross-origin request refused: this request came from ${sent.origin}, and this panel is `
      + `${expected.origin} (AUTH_URL). If the panel really is at ${sent.origin}, set AUTH_URL to that in panel.env and restart it.`;
  }

  //no AUTH_URL: compare the host the browser was talking to, scheme aside
  const hosts = [input.host, input.forwardedHost]
    .map((h) => h?.trim().toLowerCase())
    .filter((h): h is string => !!h);
  if (hosts.some((h) => h === sent.host)) {
    return null;
  }
  return `Cross-origin request refused: this request came from ${sent.origin}, and this panel is being `
    + `served as ${hosts[0] ?? "an unknown host"}. Set AUTH_URL in panel.env to the origin the browser uses.`;
}

function parseOrigin(raw: string): { origin: string; host: string } | null {
  try {
    const url = new URL(raw);
    if (url.protocol !== "http:" && url.protocol !== "https:") {
      return null;
    }
    return { origin: url.origin.toLowerCase(), host: url.host.toLowerCase() };
  } catch {
    return null;
  }
}

/** `AUTH_URL` as an origin, or null when unset or not a URL (lib/auth.ts already warns about that). */
function expectedOrigin(authUrl: string | null | undefined): { origin: string } | null {
  const raw = authUrl?.trim();
  if (!raw) {
    return null;
  }
  const parsed = parseOrigin(raw);
  return parsed ? { origin: parsed.origin } : null;
}
