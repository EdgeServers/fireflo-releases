import { CUSTOMER_CDR_COLUMNS } from "./customer-cdr-columns.ts";
import type { CdrColumn } from "./cdr-columns.ts";
import { type ColumnChoice, resolveColumns } from "./table-columns.ts";

/**
 * Which of their own columns a customer sees, and which they may not turn off.
 *
 * <p>A third catalogue on top of two that already exist, and each layer answers a different
 * question. `cdr-columns.ts` says what a column *is*; `customer-cdr-columns.ts` says whether a
 * customer may *see* it, which is the security boundary; this says what a customer sees *by
 * default* and what they may not hide, which is a usability decision and nothing more. Merging the
 * last two would put a preference in the same list as the allow-list, and the allow-list is the one
 * thing here that must stay boring.
 *
 * <p>Database-free, so a client component can import it.
 */

/**
 * Where the choice is kept.
 *
 * <p><strong>Its own key, never `fireflo.cdrs.columns`.</strong> An operator who also holds a
 * customer login uses both tables in one browser; one key would mean choosing a column on the
 * operator page silently rearranged the portal, and the two tables do not even offer the same
 * columns.
 */
export const MIS_COLUMN_STORAGE_KEY = "fireflo.mis.messages.columns";

/**
 * Columns that are always on.
 *
 * <p>Without a timestamp, a destination and an outcome, a row of this table does not answer any
 * question anybody opens it to ask — and a chooser that lets someone reach that state produces a
 * support call, not a preference. Three is deliberately the smallest set that keeps the table
 * meaningful; locking more would leave the chooser looking decorative.
 */
const LOCKED = new Set<string>(["submittedAt", "destAddr", "outcome"]);

/**
 * What someone who has never opened the chooser sees.
 *
 * <p>Not the operator table's `defaultOn` flags, which is what this page would inherit for free.
 * Those were chosen to preserve the operator's pre-chooser view and include `vendor` — a column a
 * customer is not allowed to see at all — while omitting the message id, which is the first thing a
 * customer quotes when they raise a ticket.
 */
const DEFAULT_ON = new Set<string>([
  "submittedAt",
  "destAddr",
  "sourceAddr",
  "gatewayMsgId",
  "accountId",
  "price",
  "outcome",
]);

/**
 * The customer catalogue, re-flagged for this page.
 *
 * <p>Derived from {@link CUSTOMER_CDR_COLUMNS} rather than redeclared, so a header, formatter or
 * accessor edited once lands on the operator table and this one together. Only `defaultOn` differs.
 */
export const MIS_COLUMNS: readonly CdrColumn[] = CUSTOMER_CDR_COLUMNS.map((column) => ({
  ...column,
  defaultOn: DEFAULT_ON.has(column.id),
}));

/** The chooser's own grouping. `Money` is in the list; a customer's `price` is their invoice line. */
export const MIS_COLUMN_GROUPS = ["Message", "Route", "Money", "Outcome"] as const;

export function isLockedMisColumn(id: string): boolean {
  return LOCKED.has(id);
}

/**
 * The columns to render, from a stored choice.
 *
 * <p>Two guarantees on top of {@link resolveColumns}, both about ending up somewhere useless:
 *
 * <ol>
 *   <li>A locked column is present however the stored choice votes. The chooser disables those
 *       boxes, but a preference written by an older release — or by hand — is not bound by what the
 *       current chooser allows.
 *   <li>An empty result falls back to the defaults. While anything is locked this cannot happen —
 *       turning every box off leaves the locked three — so it is a backstop against a future where
 *       {@link LOCKED} is emptied, not a case that fires today. An empty table reads as "no
 *       messages", which is a different and much more alarming answer than "no columns".
 * </ol>
 *
 * <p>Order always comes from the catalogue, never from the order boxes were ticked, so two people
 * who chose the same columns are looking at the same table.
 */
export function resolveMisColumns(choice: ColumnChoice | null): CdrColumn[] {
  const chosen = new Set(resolveColumns(MIS_COLUMNS, choice).map((c) => c.id));
  const columns = MIS_COLUMNS.filter((c) => LOCKED.has(c.id) || chosen.has(c.id));
  return columns.length ? [...columns] : MIS_COLUMNS.filter((c) => c.defaultOn);
}

/**
 * The default set as ids, for a caller with no stored choice to hand — the export route, which is
 * asked for a CSV before the browser has told it anything about columns.
 */
export const MIS_DEFAULT_COLUMN_IDS: readonly string[] = MIS_COLUMNS.filter((c) => c.defaultOn).map(
  (c) => c.id
);
