import type { Health } from "./health-types";

/** How many polls to keep. Twelve ten-second samples is two minutes, which fits a sparkline. */
export const TPS_HISTORY_DEPTH = 12;

/** Measured throughput per full worker name, oldest first. `null` where a worker reported none. */
export type TpsHistory = ReadonlyMap<string, readonly (number | null)[]>;

/**
 * Fold one health snapshot into the running throughput history.
 *
 * <h2>Why keep any history at all</h2>
 *
 * <p>A snapshot is an instant. "0 tps" is the same three characters whether a vendor has been idle
 * all week or stopped forty seconds ago, and those are very different mornings. A short tail of
 * previous polls is the cheapest way to tell them apart, and nothing else on the page holds one —
 * each poll replaces the last with no memory of it.
 *
 * <h2>Pure, and folded at the fetch</h2>
 *
 * <p>This runs where the snapshot arrives rather than during a render. Appending in an effect would
 * cost a second render per tick to store a number the first render already had; appending into a
 * ref during render is what `react-hooks/refs` exists to stop. Doing it in the fetch callback is
 * both, avoided — and it makes the append a pure function of (previous, snapshot), which is
 * testable without mounting anything.
 *
 * <p>Returns a new map, so React sees a changed reference and the sparkline redraws.
 *
 * <p>Workers absent from this snapshot keep their existing tail rather than being dropped: a
 * gateway that briefly stops reporting one should leave a gap, not erase two minutes of history.
 */
export function appendTps(previous: TpsHistory, health: Health): TpsHistory {
  const next = new Map(previous);
  for (const worker of health.workers) {
    const past = next.get(worker.name) ?? [];
    //bounded, or a tab left open overnight holds eight thousand samples per worker to draw twelve
    next.set(worker.name, [...past, worker.tps_measured ?? null].slice(-TPS_HISTORY_DEPTH));
  }
  return next;
}
