import { test } from "node:test";
import assert from "node:assert/strict";
import { HEADERS, toCsvLine } from "./rejected-export.ts";
import { parseCsv } from "./csv.ts";
import type { RejectedRow } from "./rejected-types.ts";

/** A vendor refusal: the only shape that carries a status, a message id and a detail. */
const VENDOR_REFUSAL: RejectedRow = {
  id: "412",
  rejectedAt: "2026-08-18T12:00:00.000Z",
  reason: "vendorRejected",
  detail: "ESME_RSUBMITFAIL: the vendor refused the submit without saying why",
  accountId: "acct-1",
  systemId: "sys-1",
  product: "india-tr",
  ingress: "SMPP",
  inGateway: "smppserver.in",
  sourceAddr: "ACME",
  destAddr: "919999999999",
  bodyExcerpt: "Dear Priya, your order has shipped",
  dcs: 0,
  parts: 1,
  gatewayMsgId: "gw-1",
  vendorStatus: 69,
};

test("the column order is fixed, and new columns go on the end", () => {
  //somebody's spreadsheet formulas. Reordering breaks them silently, in a file nobody re-reads
  assert.deepEqual(
    [...HEADERS],
    [
      "rejected_at", "reason", "reason_label", "refused_after_accepting", "account_id",
      "system_id", "product", "ingress", "in_gateway", "source_addr", "dest_addr",
      "gateway_msg_id", "vendor_status", "vendor_status_name", "dcs", "parts", "id",
      "detail", "body_excerpt",
    ]
  );
});

test("a row writes exactly as many fields as there are headers", () => {
  //the classic failure: a header is appended and the value forgotten, so every column after it
  //shifts by one and the file still looks plausible
  const parsed = parseCsv(toCsvLine(VENDOR_REFUSAL));
  assert.equal(parsed.length, 1);
  assert.equal(parsed[0].length, HEADERS.length);
});

test("the derived columns are written out, for a reader with no panel open", () => {
  const cells = parseCsv(toCsvLine(VENDOR_REFUSAL))[0];
  assert.equal(cells[HEADERS.indexOf("reason")], "vendorRejected");
  assert.equal(cells[HEADERS.indexOf("reason_label")], "Vendor refused it");
  assert.equal(cells[HEADERS.indexOf("vendor_status")], "69");
  assert.equal(cells[HEADERS.indexOf("vendor_status_name")], "ESME_RSUBMITFAIL");
  assert.equal(cells[HEADERS.indexOf("refused_after_accepting")], "true");
});

test("zeros are written as zeros, unlike the table", () => {
  //the file is a calculation surface. `parts = 0` means "refused before anything counted them" and
  //`dcs = 0` is GSM 7-bit -- the panel draws that distinction, the CSV records the number
  const cells = parseCsv(toCsvLine({ ...VENDOR_REFUSAL, dcs: 0, parts: 0 }))[0];
  assert.equal(cells[HEADERS.indexOf("dcs")], "0");
  assert.equal(cells[HEADERS.indexOf("parts")], "0");
});

test("a door refusal writes empty for the message id, whether it was '' or NULL", () => {
  //StandardMessage.serial initialises to "" and is written through unchecked, so most rows that
  //never reached a message carry an empty string rather than NULL. In a file the two are one thing
  const empty = parseCsv(toCsvLine({ ...VENDOR_REFUSAL, gatewayMsgId: "" }))[0];
  const nulled = parseCsv(toCsvLine({ ...VENDOR_REFUSAL, gatewayMsgId: null }))[0];
  assert.equal(empty[HEADERS.indexOf("gateway_msg_id")], "");
  assert.equal(nulled[HEADERS.indexOf("gateway_msg_id")], "");
});

test("a door refusal has no vendor status and says so with a blank, not a zero", () => {
  //0 is ESME_ROK. Writing it for "no vendor was ever asked" would claim every door refusal was
  //accepted by a carrier
  const cells = parseCsv(toCsvLine({ ...VENDOR_REFUSAL, reason: "headerNotApproved", vendorStatus: null }))[0];
  assert.equal(cells[HEADERS.indexOf("vendor_status")], "");
  assert.equal(cells[HEADERS.indexOf("vendor_status_name")], "");
  assert.equal(cells[HEADERS.indexOf("refused_after_accepting")], "false");
});

test("a message excerpt that looks like a formula is neutralised", () => {
  //the body is whatever a customer sent. Without the guard, exporting refusals is a way to run
  //someone else's spreadsheet formula on your own machine
  const line = toCsvLine({ ...VENDOR_REFUSAL, bodyExcerpt: "=cmd|'/c calc'!A1" });
  assert.ok(line.includes("'=cmd"), `not guarded: ${line}`);
});

test("a detail containing a comma survives the round trip", () => {
  const detail = 'refused, and the vendor said "no"';
  const cells = parseCsv(toCsvLine({ ...VENDOR_REFUSAL, detail }))[0];
  assert.equal(cells[HEADERS.indexOf("detail")], detail);
  assert.equal(cells.length, HEADERS.length);
});
