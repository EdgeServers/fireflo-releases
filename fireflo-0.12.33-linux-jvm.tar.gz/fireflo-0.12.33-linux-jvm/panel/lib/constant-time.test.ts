import { test } from "node:test";
import assert from "node:assert/strict";
import { constantTimeEquals } from "./constant-time.ts";

test("equal strings compare equal, including empty and non-ASCII ones", () => {
  assert.equal(constantTimeEquals("", ""), true);
  assert.equal(constantTimeEquals("operator", "operator"), true);
  assert.equal(constantTimeEquals("pässwörd ✓", "pässwörd ✓"), true);
});

test("different strings compare unequal whatever their lengths", () => {
  assert.equal(constantTimeEquals("operator", "Operator"), false);
  assert.equal(constantTimeEquals("abc", "abcd"), false, "a length mismatch is a plain false, not a throw");
  assert.equal(constantTimeEquals("abcd", "abc"), false);
  assert.equal(constantTimeEquals("", "x"), false);
});

test("a length mismatch does not throw, which is what the old compare had to branch around", () => {
  assert.doesNotThrow(() => constantTimeEquals("short", "a much longer string than that"));
});
