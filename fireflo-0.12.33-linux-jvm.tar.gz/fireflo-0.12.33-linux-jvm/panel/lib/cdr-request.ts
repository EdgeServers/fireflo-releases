/**
 * The filter set as it travels: query string in, query string out — plus the vocabulary both sides
 * need to describe one.
 *
 * <p><b>This module must never import `cdr-queries.ts`</b>, and the dependency runs the other way for
 * a reason. `cdr-queries.ts` opens a database pool, so anything importing it is server-only; a client
 * component reaching in for the list of outcomes would pull `pg` into the browser bundle, and the
 * symptom is not a scoped error — the bundler fails on `dns`, the shared client chunk dies, and every
 * page in the app returns 500 at once. So the filter vocabulary lives here, where the browser, both
 * routes and the export worker can all reach it.
 *
 * <p>Parsing in one place also means a filter that says one thing on screen cannot mean another in
 * the CSV.
 */

//with the extension, because `node --test` runs these modules directly and does not read tsconfig
//paths or resolve extensionless specifiers. `date-range.ts` is database-free, like this module
import { MAX_RANGE_DAYS, spanInDays } from "./date-range.ts";

/** Terminal outcomes the gateway writes. Anything else from a client is rejected, not ignored. */
export const FINAL_STATES = ["DELIVERED", "FAILED", "REJECTED", "DROPPED", "EXPIRED"] as const;
export type FinalState = (typeof FINAL_STATES)[number];

/**
 * `PENDING` is included deliberately: from the operator's side it is one of the choices in the same
 * dropdown, even though in the schema it is the absence of a `cdr_final` row rather than a value.
 */
export type OutcomeFilter = FinalState | "PENDING";

export function isOutcomeFilter(value: string): value is OutcomeFilter {
  return value === "PENDING" || (FINAL_STATES as readonly string[]).includes(value);
}

/** What the query layer takes. Dates here, strings on the wire. */
export interface CdrFilters {
  since?: Date | null;
  until?: Date | null;
  accountId?: string | null;
  /**
   * Restricts the whole query to this set of accounts, and cannot be widened by anything else.
   *
   * <p>For the customer portal, where the accounts a session may see are decided by the session and
   * never by the request. Kept separate from `accountId` rather than overloading it: `accountId`
   * comes from a query string on the operator page, and one field that is sometimes a filter and
   * sometimes a boundary is a field somebody will eventually merge a parsed value into.
   *
   * <p>ANDs with `accountId`, so a reseller narrowing to one of its own accounts still cannot reach
   * outside the set.
   */
  accountIn?: string[] | null;
  systemId?: string | null;
  vendor?: string | null;
  product?: string | null;
  ingress?: string | null;
  /** The listener the message came in on, as `cdr_submit.in_gateway` names it (`smppserver.<name>`). */
  inGateway?: string | null;
  destAddr?: string | null;
  sourceAddr?: string | null;
  gatewayMsgId?: string | null;
  /**
   * A phrase from the message text.
   *
   * <p>The only substring filter here; everything else is an identifier somebody pasted. It is
   * always ANDed with the date range, and it finds nothing at all unless the gateway is recording
   * content — `smsg.cdr.body`, which is off by default.
   */
  body?: string | null;
  outcome?: OutcomeFilter | null;
  /**
   * When true, retries and later segments are hidden, so one message is one row.
   *
   * <p>Despite the name, the row kept is not the first attempt: it is the message's representative,
   * chosen as the gateway's `UsageRollup` chooses it — the attempt carrying money, else the latest.
   * After a failover that is the accepted attempt, which is the one whose receipt it is. See
   * `isMessageRow` in `lib/cdr-grain.ts`.
   *
   * <p>Defaults to true because it is what someone browsing traffic means. Turning it off is how you
   * see the attempt history of a message that was retried across vendors -- which is exactly the
   * view you want when diagnosing one, and exactly the view that makes volume look inflated.
   */
  firstAttemptOnly?: boolean;
}

/** What the UI offers as a time window, and what each means in hours. */
export const RANGES: Record<string, number> = {
  "1h": 1,
  "24h": 24,
  "7d": 24 * 7,
  "30d": 24 * 30,
  all: 0,
};

/**
 * The longest a text filter may be.
 *
 * <p>1,600 is the longest body the gateway records — a full concatenated multipart message — so a
 * phrase longer than that cannot match any row by definition, and every other filter here is an
 * identifier far shorter still. One ceiling for all of them rather than a per-field table: the
 * number is a bound on what the database is asked to compare, not a claim about each field's shape.
 *
 * <p>It matters most on `text`, the only substring search: it becomes `ILIKE '%…%'`, which the
 * planner cannot index, so the pattern is compared against every row the date range admits. The
 * portal reaches this with a customer's session, which is why refusing is worth a branch.
 *
 * <p>Refused rather than truncated. A silently shortened phrase returns rows that do not contain
 * what was typed, and the searcher has no way to tell that from a real match.
 */
export const MAX_TEXT_FILTER = 1600;

/**
 * Neutralises the wildcards in a LIKE pattern.
 *
 * <p>Without this a destination of `%` matches every message in the table -- not an injection, but
 * the same surprise: a filter that appears to be typed text turning out to be syntax. Postgres's
 * default LIKE escape character is the backslash, which is what this emits.
 *
 * <p>Here rather than in either query module so that it is one function, tested once, and so the
 * pattern a filter becomes can be asserted without opening a database pool.
 */
export function escapeLike(value: string): string {
  return value.replace(/[\\%_]/g, (c) => `\\${c}`);
}

/**
 * The filters that cannot be run without a time bound, with the sentence that refuses each.
 *
 * <p>`range=all` is a valid period on the operator's Messages page: with only equality filters
 * (account, product, vendor, system id) it is an index walk from the newest row, and the e2e suite
 * pages through exactly that. These four are different. The body is an `ILIKE '%…%'`, the two
 * numbers are prefix scans and the outcome lives on the joined receipt, so without `since` each one
 * is a scan of every message ever sent -- on a pool of eight connections behind a 10-second
 * statement timeout. Refused with a sentence the page shows, worded the way `validateRange` words
 * its refusals: what to do, not what went wrong.
 */
const NEEDS_PERIOD: [keyof CdrFilters, string][] = [
  ["body", "Choose a period to search the message text."],
  ["destAddr", "Choose a period to search by destination number."],
  ["sourceAddr", "Choose a period to search by source number."],
  ["outcome", "Choose a period to filter by outcome."],
];

/**
 * The WHERE fragment that matches a message by any id the gateway ever gave it.
 *
 * <p>A concatenated message is acknowledged once per segment, so the customer holds several ids and
 * quotes whichever is on the receipt they are chasing. Only the first is `gateway_msg_id`; the rest
 * live in `reassembled_parts`, the gateway's V1.34.0.
 *
 * <p><strong>The outer parentheses are a security boundary, not formatting.</strong> Callers join
 * every clause with AND, and one of those clauses is the customer portal's account scope. Unbracketed,
 * `account_id = ANY($1) AND gateway_msg_id = $2 OR reassembled_parts @> ARRAY[$2]` binds as
 * `(A AND B) OR C`, and C on its own would return any message on the platform whose segment list held
 * an id the caller guessed. That is the whole reason this is a named function with a test rather than
 * a ternary at the call site.
 *
 * <p>Lives here rather than in `cdr-queries.ts` so it can be tested without opening a database pool —
 * see this module's own note on why the dependency runs this way.
 *
 * @param placeholder the bind marker the caller has already allocated, e.g. `$3`. Never a value: no
 *     caller string reaches the SQL text, which is the promise the query layer makes.
 * @param canSearchSegments false against a gateway short of V1.34.0, where naming the column is a
 *     hard error rather than an empty result
 */
export function messageIdClause(placeholder: string, canSearchSegments: boolean): string {
  return canSearchSegments
    ? `(s.gateway_msg_id = ${placeholder} `
      + `OR s.reassembled_parts @> ARRAY[${placeholder}]::text[])`
    : `s.gateway_msg_id = ${placeholder}`;
}

/** The plain-text filters, as [query parameter, filter field]. One list, so the two directions agree. */
const TEXT_FIELDS: [string, keyof CdrFilters][] = [
  ["account", "accountId"],
  ["systemId", "systemId"],
  ["vendor", "vendor"],
  ["product", "product"],
  ["ingress", "ingress"],
  //"server" in the URL: the Ingress server column, the worker name the record carries
  ["server", "inGateway"],
  ["dest", "destAddr"],
  ["source", "sourceAddr"],
  ["msgId", "gatewayMsgId"],
  //"text" rather than "body" in the URL: this is a shared link, and what an operator is searching is
  //the message text. The column it lands on is `body`, which is the schema's word, not the reader's
  ["text", "body"],
];

/** What the browser holds, before any of it becomes a Date. */
export interface CdrFilterForm {
  range: string;
  /**
   * An explicit window, as the browser's `datetime-local` strings ("2026-10-12T09:30"), shown when
   * the period is {@link CUSTOM_RANGE}. Either end may be empty. Sent as `range=all` plus the
   * dates, so the server sees only a window it already understands.
   */
  since: string;
  until: string;
  account: string;
  systemId: string;
  vendor: string;
  product: string;
  ingress: string;
  /** The ingress server (listener) the message came in on, exact worker name. */
  server: string;
  dest: string;
  source: string;
  msgId: string;
  /** A phrase from the message text. Empty unless the gateway is recording content. */
  text: string;
  outcome: string;
  /** "first" hides retries and later segments; "all" shows every attempt row. */
  attempts: "first" | "all";
}

/** The period choice that means "the From and To dates below", which the server never sees. */
export const CUSTOM_RANGE = "custom";

export const EMPTY_FILTERS: CdrFilterForm = {
  range: "24h",
  since: "",
  until: "",
  account: "",
  systemId: "",
  vendor: "",
  product: "",
  ingress: "",
  server: "",
  dest: "",
  source: "",
  msgId: "",
  text: "",
  outcome: "",
  attempts: "first",
};

/** Whether anything beyond the default window is set — for a "clear filters" button that knows to appear. */
export function hasActiveFilters(form: CdrFilterForm): boolean {
  return (Object.keys(EMPTY_FILTERS) as (keyof CdrFilterForm)[]).some(
    (key) => key !== "range" && form[key] !== EMPTY_FILTERS[key]
  );
}

/** Only what is set, so the URL stays readable and a shared link carries exactly the filters chosen. */
export function toQuery(form: CdrFilterForm): URLSearchParams {
  const params = new URLSearchParams();
  const custom = form.range === CUSTOM_RANGE;
  for (const key of Object.keys(EMPTY_FILTERS) as (keyof CdrFilterForm)[]) {
    let value = form[key];
    //the dates travel as UTC instants, because the server that parses them may sit in another zone
    //from the browser that typed them. They are only sent for the custom period, and that period
    //itself goes as "all": the shortcut and the window are the same parameter on the server
    if (key === "since" || key === "until") {
      value = custom && value ? localToIso(value) : "";
    } else if (key === "range" && custom) {
      value = "all";
    }
    if (value && value !== EMPTY_FILTERS[key]) {
      params.set(key, value);
    }
  }
  return params;
}

export function fromQuery(params: URLSearchParams): CdrFilterForm {
  const form = { ...EMPTY_FILTERS };
  for (const key of Object.keys(EMPTY_FILTERS) as (keyof CdrFilterForm)[]) {
    const value = params.get(key);
    if (value != null) {
      //the cast is safe because every field of CdrFilterForm is a string; `attempts` is narrowed
      //below rather than trusted
      (form as Record<string, string>)[key] =
        key === "since" || key === "until" ? isoToLocal(value) : value;
    }
  }
  form.attempts = form.attempts === "all" ? "all" : "first";
  //a link carrying dates was made with the custom period, whatever range= says beside them
  if (form.since || form.until) {
    form.range = CUSTOM_RANGE;
  }
  return form;
}

/**
 * The list page's address for a set of filters and the page that starts at `cursor`.
 *
 * <p>The URL is the list's state: filters and the current page both live in it, so opening a
 * message and coming back, the browser's own Back, a reload of the tab and a shared link all land
 * on the same page of the same list. Only the current page's cursor travels; the stack behind
 * "Previous" cannot be computed from a keyset cursor and is kept in `sessionStorage` instead, see
 * {@link restoreHistory}.
 */
export function listHref(form: CdrFilterForm, cursor: CdrCursor | null): string {
  const params = toQuery(form);
  if (cursor) {
    params.set("cursorTs", cursor.submittedAt);
    params.set("cursorId", cursor.id);
  }
  const query = params.toString();
  return query ? `/cp/cdrs?${query}` : "/cp/cdrs";
}

export function cursorFromQuery(params: URLSearchParams): CdrCursor | null {
  const submittedAt = params.get("cursorTs");
  const id = params.get("cursorId");
  return submittedAt && id ? { submittedAt, id } : null;
}

/** What `sessionStorage` holds for the Previous stack: the filters it belongs to, and the stack. */
export interface SavedHistory {
  query: string;
  history: (CdrCursor | null)[];
}

export const CDR_HISTORY_KEY = "fireflo.cdrs.history";
/** The list's last address, so a bare `/cp/cdrs` (the sidebar, "All messages") returns to it. */
export const CDR_LAST_KEY = "fireflo.cdrs.last";

/**
 * The Previous stack for the page `cursor` of the list `query`, from what an earlier visit saved.
 *
 * <p>The saved stack is trusted only when it is for the same filters and this page is on it; it is
 * cut back to this page, since the browser's Back after a Previous lands on a page the stack has
 * already walked past. Anything else means the address was typed, shared or filtered since, and
 * the stack would walk back through pages of a different list. Then a page that is not the first
 * still gets a Previous, which can only go to the first page -- the honest fallback for a keyset
 * cursor, and better than a page with no way back.
 */
export function restoreHistory(saved: string | null, query: string, cursor: CdrCursor | null): (CdrCursor | null)[] {
  if (saved) {
    try {
      const parsed = JSON.parse(saved) as Partial<SavedHistory>;
      const history = Array.isArray(parsed.history) ? parsed.history : [];
      const at = parsed.query === query ? history.findIndex((c) => sameCursor(c ?? null, cursor)) : -1;
      if (at >= 0) {
        return history.slice(0, at + 1);
      }
    } catch {
      //a mangled entry: start the stack afresh below
    }
  }
  return cursor ? [null, cursor] : [null];
}

function sameCursor(a: CdrCursor | null, b: CdrCursor | null): boolean {
  return a === b || (!!a && !!b && a.submittedAt === b.submittedAt && a.id === b.id);
}

/** "2026-10-12T09:30" in the browser's zone → an ISO instant. Not a date → left as typed, so the server says so. */
export function localToIso(local: string): string {
  const at = new Date(local);
  return Number.isNaN(at.getTime()) ? local : at.toISOString();
}

/** An ISO instant → what a `datetime-local` input shows for it in the browser's zone, to the minute. */
export function isoToLocal(iso: string): string {
  const at = new Date(iso);
  if (Number.isNaN(at.getTime())) {
    return "";
  }
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${at.getFullYear()}-${pad(at.getMonth() + 1)}-${pad(at.getDate())}T${pad(at.getHours())}:${pad(at.getMinutes())}`;
}

/**
 * Query string to database filters, or a message saying why not.
 *
 * <p>Rejects rather than falls back. An unknown outcome silently ignored would show every message
 * under a heading claiming they were all rejected -- the kind of wrong that gets believed.
 *
 * @param now injected so the export worker can pin the window to when the request was made, rather
 *     than sliding it every time a batch runs and re-reading rows it already wrote
 */
export function parseFilters(
  params: URLSearchParams,
  now: Date = new Date()
): CdrFilters | { error: string } {
  const filters: CdrFilters = {};

  const range = params.get("range") ?? "24h";
  if (!(range in RANGES)) {
    return { error: `Unknown range '${range}'. Expected one of ${Object.keys(RANGES).join(", ")}.` };
  }
  const hours = RANGES[range];
  if (hours > 0) {
    filters.since = new Date(now.getTime() - hours * 3_600_000);
  }

  //an explicit window beats the shortcut, which is how a link to a specific incident stays pinned
  for (const [key, field] of [
    ["since", "since"],
    ["until", "until"],
  ] as const) {
    const raw = params.get(key);
    if (raw) {
      const at = new Date(raw);
      if (Number.isNaN(at.getTime())) {
        return { error: `'${key}' is not a valid timestamp.` };
      }
      filters[field] = at;
    }
  }

  for (const [param, field] of TEXT_FIELDS) {
    const value = params.get(param)?.trim();
    if (value && value.length > MAX_TEXT_FILTER) {
      return { error: `'${param}' is longer than ${MAX_TEXT_FILTER} characters.` };
    }
    if (value) {
      //assigning through a narrowed record: every one of these fields is `string | null | undefined`
      (filters as Record<string, unknown>)[field] = value;
    }
  }

  const outcome = params.get("outcome")?.trim();
  if (outcome) {
    if (!isOutcomeFilter(outcome)) {
      return { error: `Unknown outcome '${outcome}'.` };
    }
    filters.outcome = outcome as OutcomeFilter;
  }

  //the two bounds on the window, after every filter is known so that the refusal can name the one
  //that needs it. Here rather than in the routes because four routes share this parser and the
  //customer portal is one of them: a bound that lives in a route is a bound one route forgets
  if (!filters.since) {
    const unbounded = NEEDS_PERIOD.find(([field]) => filters[field]);
    if (unbounded) {
      return { error: unbounded[1] };
    }
  } else {
    //a hand-typed window is the same request as `range=all` with a different spelling once it is
    //wide enough, and the browser is not what enforces it -- this is a plain GET anybody can edit.
    //Measured to `now` when there is no To, which is what the query runs against
    const days = spanInDays(filters.since, filters.until ?? now);
    if (days > MAX_RANGE_DAYS) {
      return { error: `That is ${days} days. Ask for at most ${MAX_RANGE_DAYS} at a time.` };
    }
  }

  filters.firstAttemptOnly = params.get("attempts") !== "all";
  return filters;
}

export function isFilterError(value: CdrFilters | { error: string }): value is { error: string } {
  return "error" in value;
}

/**
 * The last row of a page, as the next page's starting point.
 *
 * <p>Lives here rather than beside the query for the reason at the top of this file: the table
 * component needs the shape and cannot reach into `cdr-queries.ts` for it. `cdr-queries.ts`
 * re-exports both of these, so a server-side caller still has one import.
 */
export interface CdrCursor {
  submittedAt: string;
  id: string;
}

/**
 * One row of `cdr_submit`, joined to its earliest delivery receipt.
 *
 * <p>Every field the list query selects, and the detail view selects the rest. There used to be a
 * second, narrower copy of this interface inside `CdrsClient` that silently dropped five fields the
 * API was already sending — which is exactly the drift that happens when a wire shape is declared
 * twice.
 *
 * <p>Amounts are scaled by 10 000, like every amount in this schema. Dividing is the caller's
 * problem, and {@link money} is the only place that does it.
 */
export interface CdrRow {
  id: string;
  gatewayMsgId: string;
  partNo: number;
  partCount: number;
  retryCount: number;
  submittedAt: string;
  acceptedAt: string | null;
  accountId: string | null;
  systemId: string | null;
  product: string | null;
  ingress: string;
  /** Which listener or REST ingress instance took it in. */
  inGateway: string | null;
  /** The ingress listener's port as configured now -- see `IN_GATEWAY_PORT` in cdr-queries. */
  inGatewayPort?: number | null;
  vendor: string | null;
  sourceAddr: string | null;
  destAddr: string | null;
  mcc: number | null;
  mnc: number | null;
  dcs: number | null;
  msgType: number | null;
  operatorMsgId: string | null;
  costRate: number | null;
  costUnits: number | null;
  cost: number | null;
  priceRate: number | null;
  billedUnits: number | null;
  price: number | null;
  margin: number | null;
  /** A percentage as written, not scaled: `NUMERIC(7,4)` straight out of the column. */
  marginPct: number | null;
  marginStatus: string | null;
  costRuleId: string | null;
  priceRuleId: string | null;
  currency: string | null;
  /** null means PENDING -- no outcome has arrived and none may ever. A progress receipt may have. */
  finalState: string | null;
  /**
   * The latest progress receipt (`cdr_interim.dlr_state`) -- ACCEPTD or BUFFRED -- or null when none
   * arrived. Absent on a gateway before V1.33.0, which has no such table.
   *
   * <p>What keeps "Awaiting receipt" honest: a vendor that answered ACCEPTD and nothing since has
   * sent a receipt, just not an outcome, and the detail page shows it.
   */
  progressState?: number | null;
  dlrState: number | null;
  errCode: string | null;
  /**
   * The carrier's own failure code, before translation. See {@link MessageReceipt.vendorErrCode}
   * for what each of the three values means — in particular, that `null` never means "the same as
   * errCode".
   */
  vendorErrCode?: string | null;
  finalAt: string | null;
  /**
   * The TLVs recorded on submission, as the raw JSON text the gateway wrote.
   *
   * <p>Only present on the detail and export paths. Unbounded TEXT multiplied by two hundred rows a
   * page is not something the list query should be carrying, and nobody would attribute the
   * slowdown to a column chooser.
   */
  tlvs?: string | null;
  /**
   * The optional parameters as they arrived, before the account defaults, the approved sender ID or
   * the content template touched them. Compare with {@link tlvs} to see what replaced what.
   */
  tlvsReceived?: string | null;
  /**
   * The optional parameters the vendor actually put on the wire, after its own defaults filled any
   * gap and its registered-tag list decided what it would carry.
   *
   * <p>Null means nothing recorded it — including every non-SMPP vendor — which is a different
   * answer from `{}`, meaning the vendor sent none.
   */
  tlvsSent?: string | null;
  /**
   * The SMPP `registered_delivery` octet as the customer sent it.
   *
   * <p>Absent when the gateway has not applied V1.33.0; null when the column exists and this row
   * predates it, or when the ingress has no such concept. **Neither is zero.** Zero is a claim about
   * the customer — they asked for no receipt — and inferring it from a missing value would put words
   * in their mouth on exactly the question a receipt dispute turns on.
   *
   * <p>Stored raw and decoded by `receipt-request.ts`, because the octet carries three independent
   * requests and only some of them are acted on.
   */
  registeredDelivery?: number | null;
  /**
   * The vendor's `submit_sm_resp` status for this attempt, or null when nothing recorded one.
   *
   * <p>Absent when the gateway has not applied V1.40.0; null when the column exists and this row
   * predates it, or the vendor is not SMPP and never had a status to report. **Neither is zero.**
   * Zero is ESME_ROK -- the vendor accepted it -- and inferring success from a missing value would
   * be exactly the claim this column exists to stop being implicit.
   */
  submitStatus?: number | null;
  /**
   * Which routing rule sent this attempt where it went — `table:label`, else `table:seq`.
   *
   * <p>Three-valued, like `vendorErrCode` and for the same reason: a string is the rule; `null` is
   * unrecorded (a row from before V1.47.0, or an attempt that reached a vendor without matching a
   * rule) and never "no rule"; `undefined` is a gateway whose schema has no such column, so nothing
   * was asked.
   *
   * <p>Per ATTEMPT, so a re-route that matched a different rule reads as one.
   */
  routeRule?: string | null;
  /**
   * The message text, when the gateway was asked to keep it.
   *
   * <p>Absent when the query did not select it, null when nothing recorded it — the gateway's
   * `smsg.cdr.body` is off by default, and rows written before it existed can never have it. Those
   * two are different answers and the UI has to be able to tell them apart: "not shown" is a column
   * chooser away, "not recorded" is a gateway setting away.
   *
   * <p>The operator's list carries the first 160 characters; the detail view and the customer's own
   * view carry the whole thing.
   */
  body?: string | null;
}

/**
 * One receipt, from either table.
 *
 * <p>A vendor sends several for one message: ACCEPTD when it takes it, ENROUTE while it carries it,
 * then the outcome. Only the last is an outcome, and only the last is in `cdr_final` — the rest are
 * in `cdr_interim`, kept apart so that every reader taking the earliest `cdr_final` row still gets
 * the outcome rather than the first sign of life. The detail view is the one place they are merged
 * back into a single list, because a person diagnosing a message wants the whole sequence.
 *
 * <p>Two `cdr_final` rows can still exist for the same part — there is no uniqueness constraint —
 * and the detail view says so where every other view silently shows the earliest.
 */
/**
 * One customer-side event: what the gateway told this customer, or why it did not.
 *
 * <p>The rest of this page describes the vendor leg — what we sent out and what came back. These
 * describe the leg the customer actually experiences, which until `cdr_event` existed had no record
 * at all: a withheld receipt, a held one, or a callback that failed left nothing but a log line.
 *
 * <p>`endpoint` arrives **already redacted by the gateway** — scheme, host and path, query string
 * removed, because a `dlr-url` routinely carries an API key. There is no unredacted form stored, so
 * the panel can neither show one nor be asked to. That has no opt-out and is unaffected by anything
 * below.
 *
 * <p>What the endpoint *answered* is a separate matter, and arrives only from a gateway on V1.48.0
 * or later that has `smsg.cdr.events.response` switched on — a bounded excerpt plus a fixed list of
 * headers, never the whole response. Off is the default, so the usual value is null.
 */
export interface CustomerEvent {
  at: string;
  kind: string;
  channel: string;
  status: number | null;
  attempt: number | null;
  durationMs: number | null;
  endpoint: string | null;
  detail: string | null;
  /**
   * What the customer's endpoint wrote back, on a `callback.attempt`.
   *
   * <p>Three-valued, and the three are different findings:
   *
   * <ul>
   *   <li>a string — this is what they answered, bounded at 500 characters by the gateway;</li>
   *   <li>the empty string — they answered with no body at all, which is a normal 204 and is not
   *       the same as not knowing;</li>
   *   <li>`null` — the gateway did not capture it: `smsg.cdr.events.response` is off, or there was
   *       no response to read because the request was refused or threw;</li>
   *   <li>`undefined` — this gateway's schema has no such column, so nothing was even asked.</li>
   * </ul>
   */
  responseExcerpt?: string | null;
  /**
   * Allow-listed response headers as `name: value; name: value`, on the same terms.
   *
   * <p>An allow-list held by the gateway — content type, length, encoding, retry-after, location
   * and request id. A `set-cookie` or an `authorization` the endpoint sent is not absent because
   * the panel hides it; nothing ever copied it.
   */
  responseHeaders?: string | null;
}

export interface MessageReceipt {
  id: string;
  partNo: number;
  /**
   * Which table this came from, and therefore whether it closed the message.
   *
   * <p>`outcome` is `cdr_final`, `progress` is `cdr_interim`. Not derived from `dlrState` on the
   * reading side even though the gateway's `isTerminal` would agree: which table the gateway *put*
   * it in is the fact worth showing, and a disagreement between the two is itself a bug worth being
   * able to see.
   */
  kind: "outcome" | "progress";
  operatorMsgId: string | null;
  /** Null on a progress receipt. `cdr_interim` has no `final_state` column, deliberately. */
  finalState: string | null;
  dlrState: number | null;
  errCode: string | null;
  /**
   * The carrier's own failure code, before we translated it — `cdr_final.vendor_err_code`.
   *
   * <p>Three-valued, and each value is a different statement:
   *
   * <ul>
   *   <li>a string — this is what the carrier actually sent;</li>
   *   <li>`null` — the carrier reported nothing, or this row predates the column. The gateway
   *       deliberately did not backfill, because copying `err_code` across would manufacture
   *       evidence, so null NEVER means "the same as err_code";</li>
   *   <li>`undefined` — this gateway's schema has no such column, so nothing was even asked.</li>
   * </ul>
   *
   * <p>Always undefined on a progress receipt: `cdr_interim` has no `vendor_err_code`.
   */
  vendorErrCode?: string | null;
  /** `cdr_final.final_at` or `cdr_interim.received_at`. The merge key for the timeline. */
  receivedAt: string;
  /** Recorded on progress receipts only — `cdr_final` has no vendor column. */
  vendor: string | null;
  /**
   * Whether this receipt was forwarded to the customer.
   *
   * <p>Derived, not stored: the gateway records every receipt and forwards only what the customer
   * asked for, so this is `registeredDelivery` applied to this row's state. Null when the request
   * was never recorded — a row written before V1.33.0, where "we do not know" is the honest answer.
   */
  forwarded: boolean | null;
}

/** What the detail route returns. */
export interface MessageRecord {
  /** The id the message is filed under, which is not always the one that was asked for. */
  gatewayMsgId: string;
  /**
   * The id the operator actually typed or clicked.
   *
   * <p>Differs from {@link gatewayMsgId} when a concatenated message was looked up by a later
   * segment's id. The page says so rather than silently answering about a different id — the two
   * look nothing alike, and appearing to change the subject reads as a bug.
   */
  askedFor: string;
  /**
   * Which segment of the message {@link askedFor} was, 1-based, or null when it is not a segment id
   * at all — an ordinary single-part message, or a gateway short of V1.34.0.
   */
  segmentNo: number | null;
  attempts: CdrRow[];
  /** True when the attempt list was capped — a message with unlimited retries can have thousands. */
  more: boolean;
  /** Both tables, merged and time-ordered. */
  receipts: MessageReceipt[];
  /**
   * Whether this gateway records progress receipts at all.
   *
   * <p>False against one that has not applied V1.33.0, and the page has to say which: "no ENROUTE
   * was ever sent for this message" and "this gateway does not keep them" send a reader in opposite
   * directions, and an empty list looks identical for both.
   */
  progressRecorded: boolean;
  /** What the gateway told the customer, or why it did not. Empty when nothing was recorded. */
  events: CustomerEvent[];
  /**
   * Whether this gateway can record customer-side events at all.
   *
   * <p>False against one short of V1.46.0. The same distinction {@link progressRecorded} draws, for
   * the same reason: "nothing went wrong" and "this build cannot tell you" are opposite answers and
   * an empty list looks identical for both — so the card is hidden rather than shown empty.
   */
  eventsRecorded: boolean;
  /**
   * Whether this gateway can capture what a callback endpoint answered — its V1.48.0.
   *
   * <p>Separate from {@link eventsRecorded} because the remedy differs. False means the gateway is
   * too old and the answer is an upgrade; true with a null excerpt means it is able to and was not
   * asked, which is one configuration line. Telling somebody to set a key their build does not read
   * is the worst of the three things this page could say.
   */
  responsesRecordable: boolean;
  /** Rule labels from the config database, when it could be reached. Absent ids render bare. */
  ruleNames: Record<string, string>;
}
