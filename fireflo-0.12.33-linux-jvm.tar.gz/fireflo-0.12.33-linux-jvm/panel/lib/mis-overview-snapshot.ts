/**
 * A small per-key cache for the portal's landing page: one entry per (account set, range), held
 * for a minute, built once however many requests arrive together, and let go when nobody asks.
 *
 * <p>The operator's home page has three ranges and one audience, so it can be rebuilt on a timer
 * (`overview-snapshot.ts`). The portal has one entry per customer -- a reseller's scope is its
 * children too -- and most of them are never looked at, so nothing here runs on its own: an entry
 * is built on the request that needs it and refreshed by the first request after its TTL. Three
 * tabs of one customer are one build; a customer who left an hour ago costs nothing.
 *
 * <p>On a failed build the previous value is returned marked `stale` rather than an error page,
 * because a dashboard that 500s teaches somebody to stop opening it; with no previous value the
 * error is the caller's to show. Database-free: the loader is the caller's.
 */

export interface SnapshotEntry<T> {
  value: T;
  /** When the value was built, as an ISO instant. */
  asOf: string;
  /** True when the last build failed and this is the one before it. */
  stale: boolean;
}

export interface SnapshotCacheOptions {
  /** How long a value is served without rebuilding. Default 60 s. */
  ttlMs?: number;
  /** The most entries kept; the least recently used goes first. Default 200. */
  cap?: number;
  /** An entry nobody has asked for in this long is dropped by the sweeper. Default 10 min. */
  idleMs?: number;
  /** How often the sweeper runs. Default 60 s. */
  sweepMs?: number;
  /** The clock, epoch ms. Tests inject one. */
  now?: () => number;
  /** Whether the sweeper timer is started. Tests pass false and call `sweep()`. */
  schedule?: boolean;
}

export interface SnapshotCache<T> {
  get(key: string, load: () => Promise<T>): Promise<SnapshotEntry<T>>;
  /** Drop idle entries. The timer calls this; tests may. */
  sweep(): void;
  size(): number;
  stop(): void;
}

interface Entry<T> {
  value: T;
  builtAt: number;
  lastUsed: number;
  inflight: Promise<SnapshotEntry<T>> | null;
}

export function createSnapshotCache<T>(o: SnapshotCacheOptions = {}): SnapshotCache<T> {
  const ttlMs = o.ttlMs ?? 60_000;
  const cap = o.cap ?? 200;
  const idleMs = o.idleMs ?? 10 * 60_000;
  const sweepMs = o.sweepMs ?? 60_000;
  const now = o.now ?? Date.now;
  //a Map keeps insertion order; moving an entry to the end on use makes the first one the LRU
  const entries = new Map<string, Entry<T>>();
  const pending = new Map<string, Promise<SnapshotEntry<T>>>();
  let timer: ReturnType<typeof setInterval> | null = null;

  function touch(key: string, e: Entry<T>): void {
    e.lastUsed = now();
    entries.delete(key);
    entries.set(key, e);
  }

  function evictOverCap(): void {
    while (entries.size > cap) {
      const oldest = entries.keys().next().value;
      if (oldest === undefined) {
        return;
      }
      entries.delete(oldest);
    }
  }

  async function build(key: string, load: () => Promise<T>, prev: Entry<T> | undefined): Promise<SnapshotEntry<T>> {
    try {
      const value = await load();
      const at = now();
      const e: Entry<T> = { value, builtAt: at, lastUsed: at, inflight: null };
      entries.delete(key);
      entries.set(key, e);
      evictOverCap();
      return { value, asOf: new Date(at).toISOString(), stale: false };
    } catch (err) {
      if (prev) {
        touch(key, prev);
        return { value: prev.value, asOf: new Date(prev.builtAt).toISOString(), stale: true };
      }
      throw err;
    }
  }

  function get(key: string, load: () => Promise<T>): Promise<SnapshotEntry<T>> {
    const e = entries.get(key);
    if (e && now() - e.builtAt < ttlMs) {
      touch(key, e);
      return Promise.resolve({ value: e.value, asOf: new Date(e.builtAt).toISOString(), stale: false });
    }
    //single flight: a second request for the same key while it builds waits for the first
    let p = pending.get(key);
    if (!p) {
      p = build(key, load, e).finally(() => {
        pending.delete(key);
      });
      pending.set(key, p);
    }
    return p;
  }

  function sweep(): void {
    const t = now();
    for (const [key, e] of entries) {
      if (t - e.lastUsed >= idleMs) {
        entries.delete(key);
      }
    }
  }

  if (o.schedule !== false) {
    timer = setInterval(sweep, sweepMs);
    //never the reason the process stays up
    timer.unref?.();
  }

  return {
    get,
    sweep,
    size: () => entries.size,
    stop() {
      if (timer) {
        clearInterval(timer);
        timer = null;
      }
    },
  };
}

/**
 * The cache key for a portal overview: the accounts the session may see, order-free, and the
 * range. JSON rather than a joined string, because an account id is free text on the wire and a
 * separator could be in it.
 */
export function overviewKey(scope: readonly string[], range: string): string {
  return JSON.stringify([[...scope].sort(), range]);
}
