/**
 * Which hosts the SMPP test tool may bind to (CP-S8 in the 0.13 readiness audit).
 *
 * <p>A leaf module: it imports nothing, so `smpp-test-hosts.test.ts` runs on Node's own runner.
 *
 * <p>The tool is an ESME the panel's server runs on an admin's behalf, and until 0.12.15 the
 * "Other host:port…" field let it connect to any address with the account's stored bind
 * credentials -- an internal port probe and a way to send a customer's SMPP password to a host of
 * the caller's choosing. It is admin-only, and an admin can read the password anyway, but the panel
 * should still not be the thing that carries it off the box.
 *
 * <p>So a typed host has to be one the panel already knows as this gateway's: the host the ops and
 * REST URLs point at, `SMPP_TEST_HOST`, `FIREFLO_PUBLIC_HOST`, the listeners' own `srv.host` and
 * `srv.public.host` values -- plus whatever `SMPP_TEST_ALLOWED_HOSTS` adds for an install whose
 * gateway sits behind another name. The route assembles that list; this module decides membership.
 */

/** A host as compared: lower-cased, trimmed, IPv6 brackets off, no trailing dot. */
export function normaliseHost(raw: string | null | undefined): string {
  return (raw ?? "")
    .trim()
    .toLowerCase()
    .replace(/^\[(.*)\]$/, "$1")
    .replace(/\.$/, "");
}

/** `SMPP_TEST_ALLOWED_HOSTS`: comma, semicolon or whitespace separated; blanks ignored. */
export function parseAllowedHostsEnv(raw: string | null | undefined): string[] {
  return (raw ?? "")
    .split(/[\s,;]+/)
    .map(normaliseHost)
    .filter((h) => h.length > 0);
}

/** Hosts a URL-valued setting names, or nothing when it is not a URL. */
export function hostOfUrl(raw: string | null | undefined): string | null {
  const value = raw?.trim();
  if (!value) {
    return null;
  }
  try {
    const host = new URL(value).hostname;
    return host ? normaliseHost(host) : null;
  } catch {
    return null;
  }
}

/**
 * The allow-list from its sources, de-duplicated and normalised. Empty strings and nulls drop out,
 * so a caller can pass every candidate it has without checking each one.
 */
export function allowedSmppHosts(candidates: Iterable<string | null | undefined>): Set<string> {
  const out = new Set<string>();
  for (const c of candidates) {
    const h = normaliseHost(c);
    if (h) {
      out.add(h);
    }
  }
  return out;
}

/**
 * @return null when `host` may be bound to, else the sentence to refuse it with
 */
export function smppHostRefusal(host: string, allowed: ReadonlySet<string>): string | null {
  const wanted = normaliseHost(host);
  if (!wanted) {
    return "Enter a host.";
  }
  if (allowed.has(wanted)) {
    return null;
  }
  return `'${host.trim()}' is not one of this gateway's hosts, so the test tool will not send a login's `
    + "password there. To test against it anyway, add it to SMPP_TEST_ALLOWED_HOSTS in panel.env and restart the panel.";
}
