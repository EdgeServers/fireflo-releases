import type { Headline } from "./runtime-metrics";
import { bytes, count, latency, ratio } from "./format";

/**
 * Turning the gateway's runtime numbers into statements an operator can act on.
 *
 * <p>Separate from the raw grouping in `runtime-metrics.ts` because it answers a different question.
 * That module says what the gateway reported; this one says whether it is a problem. Kept out of the
 * component so the thresholds are one list rather than conditions scattered through JSX.
 *
 * <p><strong>Every threshold is published on screen.</strong> A coloured badge whose rule is invisible
 * is decoration — the reader cannot tell whether "watch" means 70% or 95%, so they cannot decide
 * whether to disagree with it. These numbers are judgement, not measurement, and they are meant to be
 * argued with once the gateway has been seen under real load.
 */

export type Verdict = "good" | "watch" | "high" | "unknown";

export interface Area {
  key: string;
  /** What this is, in words an SMS operator uses rather than JVM vocabulary. */
  title: string;
  /** One sentence: what is happening right now. */
  summary: string;
  /** Why it matters, and what going wrong would look like. */
  meaning: string;
  /** The rule behind the verdict, spelled out. */
  rule: string;
  verdict: Verdict;
  /** 0..1 for a fill bar, or null when the area has no meaningful ceiling. */
  fraction: number | null;
  detail: string;
}

export const VERDICT_LABELS: Record<Verdict, string> = {
  good: "Healthy",
  watch: "Worth watching",
  high: "Under pressure",
  unknown: "Not reported",
};

export function areasFrom(h: Headline): Area[] {
  return [memory(h), processor(h), capacity(h), requests(h), background(h)];
}

function memory(h: Headline): Area {
  const fraction = h.heapMax > 0 ? h.heapUsed / h.heapMax : null;
  return {
    key: "memory",
    title: "Memory",
    summary:
      fraction == null
        ? "The gateway did not report a memory ceiling."
        : `Using ${bytes(h.heapUsed)} of the ${bytes(h.heapMax)} it is allowed.`,
    meaning:
      "Memory that keeps climbing and never falls back after a cleanup is how a leak looks. "
      + "Run out entirely and the gateway stops accepting messages.",
    rule: "Healthy below 75% of the ceiling, worth watching to 90%, under pressure above that.",
    verdict: band(fraction, 0.75, 0.9),
    fraction,
    detail:
      h.gcPauseCount > 0
        ? `${count(h.gcPauseCount)} cleanup pauses so far, ${latency(h.gcPauseTotal)} of paused time in total`
        : "No cleanup pauses yet",
  };
}

function processor(h: Headline): Area {
  return {
    key: "cpu",
    title: "Processor",
    summary:
      h.processCpu == null
        ? "The gateway did not report processor use."
        : `The gateway is using ${ratio(h.processCpu)} of this machine's processing power.`,
    meaning:
      "Sustained high use means throughput is limited by this machine rather than by the vendor. "
      + "Brief spikes during a burst are normal.",
    rule: "Healthy below 70%, worth watching to 90%, under pressure above that.",
    verdict: band(h.processCpu, 0.7, 0.9),
    fraction: h.processCpu,
    detail:
      h.loadAverage != null && h.cpuCount != null
        ? `Whole machine ${ratio(h.systemCpu)} · ${h.loadAverage.toFixed(2)} of work queued across ${count(h.cpuCount)} cores`
        : `Whole machine ${ratio(h.systemCpu)}`,
  };
}

function capacity(h: Headline): Area {
  const fraction =
    h.openFiles != null && h.maxFiles != null && h.maxFiles > 0 ? h.openFiles / h.maxFiles : null;
  return {
    key: "capacity",
    title: "Connection capacity",
    summary:
      h.openFiles == null
        ? "The gateway did not report connection capacity."
        : `${count(h.openFiles)} connections and files open, out of ${count(h.maxFiles ?? 0)} allowed.`,
    //the single most operationally useful line on the page: this limit bites before anything else
    meaning:
      "Every SMPP session, database connection and open file counts against this. Reach the limit "
      + "and the gateway refuses new vendor and customer connections before any other symptom shows.",
    rule: "Healthy below 70% of the limit, worth watching to 85%, under pressure above that.",
    verdict: band(fraction, 0.7, 0.85),
    fraction,
    detail:
      h.threadsLive != null
        ? `${count(h.threadsLive)} tasks running inside the gateway, most ever ${count(h.threadsPeak ?? 0)}`
        : "",
  };
}

function requests(h: Headline): Area {
  //not a rate: a running total and a running sum, so this is the average since the gateway started.
  //Useful for "this endpoint is slow in general", useless for a spike five minutes ago
  const slow = h.httpMeanLatency != null && h.httpMeanLatency > 1;
  const watch = h.httpMeanLatency != null && h.httpMeanLatency > 0.25;
  return {
    key: "requests",
    title: "API requests",
    summary:
      h.httpRequests === 0
        ? "No HTTP requests since the gateway started."
        : `${count(h.httpRequests)} requests handled, typically in ${latency(h.httpMeanLatency)}.`,
    meaning:
      "Messages submitted over HTTP, plus this panel's own calls. Slow responses here point at the "
      + "gateway or its database, not at a vendor.",
    rule: "Healthy under 250 ms average, worth watching to 1 second, under pressure above that.",
    verdict: h.httpMeanLatency == null ? "unknown" : slow ? "high" : watch ? "watch" : "good",
    fraction: null,
    detail: h.httpActive != null ? `${count(h.httpActive)} being handled right now` : "",
  };
}

function background(h: Headline): Area {
  const active = h.workerActive ?? 0;
  const idle = h.workerIdle ?? 0;
  const total = active + idle;
  const fraction = total > 0 ? active / total : null;
  const queued = h.workerQueued ?? 0;
  return {
    key: "background",
    //NOT "worker pool". "Worker" means an SMPP connection on every other page of this panel, and
    //reusing it here for a thread pool sent readers looking for a vendor that does not exist
    title: "Internal task queue",
    summary:
      total === 0
        ? "The gateway did not report its internal task pool."
        : `${count(active)} of ${count(total)} internal task slots busy, ${count(queued)} waiting.`,
    meaning:
      "The gateway's own background work — database writes, receipt handling — not vendor "
      + "connections. Work waiting here that never clears means it is arriving faster than it "
      + "can be done.",
    rule: "Healthy below 70% of slots busy with nothing waiting; anything queued is worth watching.",
    verdict: total === 0 ? "unknown" : queued > 0 ? "watch" : band(fraction, 0.7, 0.9),
    fraction,
    detail:
      h.workerRejected != null && h.workerRejected > 0
        ? `${count(h.workerRejected)} tasks turned away — that is work the gateway could not do`
        : "Nothing turned away",
  };
}

function band(fraction: number | null, good: number, watch: number): Verdict {
  if (fraction == null || !Number.isFinite(fraction)) {
    return "unknown";
  }
  if (fraction < good) {
    return "good";
  }
  return fraction < watch ? "watch" : "high";
}
