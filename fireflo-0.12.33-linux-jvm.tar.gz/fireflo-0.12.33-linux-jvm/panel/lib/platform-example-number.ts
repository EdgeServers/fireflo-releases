import { configQuery } from "@/lib/config-db";

/**
 * The property this panel reads for the example destination number.
 *
 * <p>Namespaced `panel.` rather than `smsg.` on purpose. `app_config` is the gateway's own property
 * store, and a `smsg.*` key the gateway never reads is exactly the dead-key trap closed in #349 —
 * a setting that looks like it changes how messages are handled and changes nothing. This one is a
 * display default for the playground and the API reference, and the prefix says so.
 */
export const EXAMPLE_MSISDN_KEY = "panel.examples.msisdn";

/**
 * The destination number shown in every example, or null when none is set.
 *
 * <p>A number rather than a country: rendering a plausible example from a dialling code means
 * encoding each country's subscriber-number length and its reserved test range, which is wrong for
 * every country nobody maintained. One operator sets one number once and it is right. A
 * country-to-sample catalogue can sit behind this same accessor later without touching a caller.
 *
 * <p>Null is "not configured", not "no example" — callers fall back to the catalogue's own
 * {@link ApiField.example}, so an unset key leaves every surface exactly as it was. In file mode
 * this panel does not read the gateway's properties at all, so null is also what an operator who
 * set it somewhere else will see.
 */
export async function platformExampleMsisdn(): Promise<string | null> {
  const rows = await configQuery<{ value: string | null }>(
    `SELECT value FROM app_config WHERE key = $1 AND enabled`,
    [EXAMPLE_MSISDN_KEY]
  );
  const value = rows[0]?.value?.trim();
  return value ? value : null;
}
