import type { UsageDay } from "@/lib/metrics-queries";

/**
 * Turning day x account rows into the two things the usage page draws.
 *
 * <p>No database import, so the arithmetic that decides what an operator reads can be tested
 * without one. The query is the part that needs a container; none of this does.
 *
 * <p>Every amount stays a scaled integer. Dividing by 10 000 is `money()`'s job and doing it here
 * would round money away before it reached the screen.
 */

export interface UsagePoint {
  day: string;
  delivered: number;
  failed: number;
  /**
   * Percent delivered of what has settled, or `null` when nothing has.
   *
   * <p>`null` rather than 0 or 100, and the distinction is the whole point: a day with no traffic
   * has no delivery rate, and drawing it as zero puts a cliff in the chart that never happened.
   * The line is drawn with `connectNulls={false}` so the gap shows as a gap.
   */
  rate: number | null;
}

export interface UsageAccountRow {
  accountId: string | null;
  submitted: number;
  delivered: number;
  failed: number;
  pending: number;
  rate: number | null;
  price: number;
}

export interface UsageTotals {
  submitted: number;
  delivered: number;
  failed: number;
  pending: number;
  price: number;
  rate: number | null;
}

/**
 * Delivered against failed per day, with the delivery rate over the top.
 *
 * <p>Accounts collapse into one series. Stacking every account separately would need a colour per
 * customer and stops being legible somewhere around six of them; the per-account split is the table
 * underneath, where it can be sorted and read.
 *
 * <p><strong>Pending is not in the bars.</strong> Today's traffic is largely pending, so including
 * it would make the most recent bar the tallest on every chart regardless of what happened — which
 * reads as a spike. It is in the table and in the totals, where it is a number rather than a shape.
 */
export function toSeries(rows: UsageDay[]): UsagePoint[] {
  const byDay = new Map<string, { delivered: number; failed: number }>();
  for (const r of rows) {
    const at = byDay.get(r.day) ?? { delivered: 0, failed: 0 };
    at.delivered += r.delivered;
    at.failed += r.failed;
    byDay.set(r.day, at);
  }
  return [...byDay.entries()]
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([day, at]) => ({ day, delivered: at.delivered, failed: at.failed, rate: rateOf(at) }));
}

/** One row per account over the whole window, heaviest sender first. */
export function toAccountRows(rows: UsageDay[]): UsageAccountRow[] {
  //keyed on `string | null` rather than on a sentinel string. A Map takes null as a key natively,
  //so traffic that named no account cannot collide with an account genuinely called "null" -- and
  //there is no magic value to get wrong. The previous sentinel was a literal NUL byte, which did
  //work, and also made this file binary to grep
  const byAccount = new Map<string | null, UsageAccountRow>();
  for (const r of rows) {
    const key = r.accountId;
    const at = byAccount.get(key) ?? {
      accountId: r.accountId,
      submitted: 0,
      delivered: 0,
      failed: 0,
      pending: 0,
      rate: null,
      price: 0,
    };
    at.submitted += r.submitted;
    at.delivered += r.delivered;
    at.failed += r.failed;
    at.pending += r.pending;
    at.price += r.price;
    byAccount.set(key, at);
  }
  return [...byAccount.values()]
    .map((a) => ({ ...a, rate: rateOf(a) }))
    .sort((a, b) => b.submitted - a.submitted);
}

/** The headline figures, summed from the same rows the chart and the table use. */
export function usageTotals(rows: UsageDay[]): UsageTotals {
  const t = rows.reduce(
    (acc, r) => ({
      submitted: acc.submitted + r.submitted,
      delivered: acc.delivered + r.delivered,
      failed: acc.failed + r.failed,
      pending: acc.pending + r.pending,
      price: acc.price + r.price,
    }),
    { submitted: 0, delivered: 0, failed: 0, pending: 0, price: 0 }
  );
  return { ...t, rate: rateOf(t) };
}

/**
 * Delivered as a percentage of what has settled.
 *
 * <p>The denominator is delivered + failed, not submitted. Dividing by submitted counts every
 * message still in flight as a failure, so the rate on a busy afternoon reads as a collapse and
 * recovers by itself overnight — an alarm that fires on traffic rather than on trouble.
 */
function rateOf({ delivered, failed }: { delivered: number; failed: number }): number | null {
  const settled = delivered + failed;
  if (settled === 0) {
    return null;
  }
  return Math.round((delivered / settled) * 1000) / 10;
}
