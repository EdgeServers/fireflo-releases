import { test } from "node:test";
import assert from "node:assert/strict";
import { fallbackFor, overridesGatewayDefault, resolveSetting } from "./setting-resolution.ts";

/**
 * The three-tier chain, pinned against what the gateway actually does.
 *
 * <p>Every case names the `FireFloConfigurationHandler.get()` behaviour it stands for. This module
 * is only useful while it agrees with that method: worker key, then the `.instance.` → `.default.`
 * rewrite, then the literal from the Java.
 */

test("a worker's own value wins, and the gateway default is still reported", () => {
  const r = resolveSetting("off", "replace", "");
  assert.equal(r.value, "off");
  assert.equal(r.source, "worker");
  //carried even though it lost: "off, and the gateway default is replace" is the sentence an
  //operator needs when they are looking at a kill switch and wondering what it is killing
  assert.equal(r.gatewayDefault, "replace");
  assert.ok(overridesGatewayDefault(r), "this is the kill switch, and it should read as one");
});

test("an unset worker inherits the gateway default", () => {
  const r = resolveSetting(null, "replace", "");
  assert.equal(r.value, "replace");
  assert.equal(r.source, "gateway");
});

test("with no gateway default the coded literal answers", () => {
  const r = resolveSetting(null, null, "");
  assert.equal(r.value, "");
  assert.equal(r.source, "coded");
  //null, not "": there is no gateway default to report, and an empty string would read as one
  assert.equal(r.gatewayDefault, null);
});

test("blank is not a value at any tier", () => {
  //the rule setWorkerProperty already enforces by DELETING a row rather than storing ''. Without
  //it, "inherit" cannot be expressed -- only "set to blank" -- and the kill switch has nothing to
  //switch back to
  assert.equal(resolveSetting("", "replace", "off").source, "gateway");
  assert.equal(resolveSetting("   ", "replace", "off").source, "gateway");
  assert.equal(resolveSetting(null, "", "off").source, "coded");
  assert.equal(resolveSetting(null, "   ", "off").source, "coded");
});

test("agreeing with the gateway default is not an override", () => {
  //setting a value where no default exists is ordinary configuration; contradicting one is a
  //deliberate exception. Only the second is worth flagging
  const agrees = resolveSetting("replace", "replace", "");
  assert.equal(agrees.source, "worker");
  assert.ok(!overridesGatewayDefault(agrees));

  const noDefault = resolveSetting("replace", null, "");
  assert.ok(!overridesGatewayDefault(noDefault), "nothing to override");

  const inherited = resolveSetting(null, "replace", "");
  assert.ok(!overridesGatewayDefault(inherited), "inheriting is not overriding");
});

test("the stamp mode chain, end to end", () => {
  //the case this was built for. Gateway says stamp; one listener must not, because its vendor
  //rejects the tag. Both listeners read the same key and get different answers
  const estateWide = "replace";
  assert.equal(resolveSetting(null, estateWide, "").value, "replace");
  assert.equal(resolveSetting("off", estateWide, "").value, "off");
  //and with no estate-wide value set, both fall to the coded default, which is off for a listener
  assert.equal(resolveSetting(null, null, "").value, "");
});

test("fallbackFor is what a field shows when the worker sets nothing", () => {
  //the worker form asks this three times per field -- an enum label, an input placeholder and a
  //toggle's target -- and each used to answer it with its own `inherited ?? codedDefault`
  const inherited = fallbackFor("replace", "");
  assert.equal(inherited.value, "replace");
  assert.ok(inherited.inherited, "so the field can say 'inheriting' rather than claim a default");

  const coded = fallbackFor(null, "off");
  assert.equal(coded.value, "off");
  assert.ok(!coded.inherited, "nothing above it, so this is the compiled literal");

  //blank at the gateway tier is not a value, exactly as in resolveSetting
  assert.equal(fallbackFor("", "off").value, "off");
  assert.equal(fallbackFor("   ", "off").inherited, false);
});
