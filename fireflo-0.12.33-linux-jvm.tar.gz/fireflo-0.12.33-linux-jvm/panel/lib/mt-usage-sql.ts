/**
 * The SQL behind one account's MT usage, with no database import.
 *
 * <p>Split out so the text can be asserted without a connection — see `mt-usage.test.ts`.
 */

import { messageRows, rollupTailFrom, type GrainOptions } from "./cdr-grain.ts";

export interface MtUsageSqlOptions extends GrainOptions {
  /** Whether `usage_daily.mt_parts` exists — `hasUsageMtParts()`. The gateway's V1.68.0. */
  mtParts: boolean;
  /** Whether `cdr_submit.submit_status` exists — `hasSubmitStatus()`. The gateway's V1.40.0. */
  submitStatus: boolean;
}

/**
 * One line per day and product over the account's whole life: messages, MT parts and what was
 * charged.
 *
 * <p>The same seam the reconciliation uses (`consumedSql`): `usage_daily` for every day and product
 * it covers, and `cdr_submit` only for the ones it does not, so the two halves are disjoint and a
 * rolled-up day that still has its call records is not counted twice.
 *
 * <p>The tail counts parts exactly as the gateway's `UsageRollup` does, so a day reads the same
 * before and after it is rolled up: one row per message (`messageRows`, the rollup's own
 * `DISTINCT ON`), `part_count` from that row because segments 2..N write none, and nothing for a
 * message whose chosen attempt a vendor refused. A null status is a vendor with no such field, not a
 * refusal.
 *
 * <p><strong>The tail is bounded</strong> (Audit CP-P2): it reads from `rollupTailFrom` -- local
 * midnight of the day before the account's newest line -- so `idx_cdr_submit_account_time_covering`
 * walks a few days rather than the account's lifetime with a function of `submitted_at` in the
 * predicate. The anti-join still decides line by line inside that range. An account with no line
 * reads from the beginning of time, and carries only the columns the aggregate reads.
 *
 * <p>`mt_parts` is NULL on a line rolled up before V1.68.0 — not counted, rather than none sent —
 * and is passed through as NULL so the page can say so.
 *
 * <p>$1 is the account, $2 the billing zone. Amounts and counts come back as text: they are BIGINT
 * and `pg` would otherwise hand back strings or lose precision silently.
 */
export function mtUsageSql(o: MtUsageSqlOptions): string {
  const sent = o.submitStatus ? "COALESCE(s.submit_status, 0) = 0" : "TRUE";
  return `
  SELECT u.day::text                                   AS day,
         u.product                                     AS product,
         u.submitted::text                             AS messages,
         ${o.mtParts ? "u.mt_parts" : "NULL"}::text AS mt_parts,
         u.price_total::text                           AS price
    FROM usage_daily u
   WHERE u.account_id = $1
  UNION ALL
  SELECT (s.submitted_at AT TIME ZONE $2)::date::text AS day,
         COALESCE(s.product, '')                       AS product,
         count(*)::text                                AS messages,
         COALESCE(SUM(s.part_count) FILTER (WHERE ${sent}), 0)::text AS mt_parts,
         COALESCE(SUM(s.price), 0)::text               AS price
    FROM ${messageRows(`s.account_id = $1
         AND s.submitted_at >= ${rollupTailFrom("$2", "$1")}
         AND NOT EXISTS (
                 SELECT 1 FROM usage_daily u
                  WHERE u.account_id = s.account_id
                    AND u.day = (s.submitted_at AT TIME ZONE $2)::date
                    AND u.product = COALESCE(s.product, ''))`, o,
         ["account_id", "product", "submitted_at", "part_count", "price",
          ...(o.submitStatus ? ["submit_status"] : [])])}
   GROUP BY 1, 2`;
}

/** Today in the billing zone, so "this month" and "today" are cut where the rollup cuts days. */
export const TODAY_SQL = "SELECT (now() AT TIME ZONE $1)::date::text AS today";
