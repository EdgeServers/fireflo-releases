import { test } from "node:test";
import assert from "node:assert/strict";
import { MIN_LENGTH, MIN_SCORE, assessPassword, passwordProblem } from "./password-policy.ts";

test("short is unacceptable whatever else it has", () => {
  const v = assessPassword("Ab1!Ab1!Ab1");
  assert.equal(v.acceptable, false);
  assert.ok(v.warnings.some((w) => w.includes(`${MIN_LENGTH}`)));
  assert.match(passwordProblem("Ab1!Ab1!Ab1") ?? "", /at least 12/);
});

test("twelve mixed characters reach the floor", () => {
  const v = assessPassword("Tr0ub4dor&3x");
  assert.ok(v.score >= MIN_SCORE, v.label);
  assert.equal(v.acceptable, true);
  assert.equal(passwordProblem("Tr0ub4dor&3x"), null);
});

test("a long passphrase is strong without symbols", () => {
  const v = assessPassword("correct horse battery staple");
  assert.equal(v.score, 4);
  assert.equal(v.acceptable, true);
});

test("the usual suspects are refused however long", () => {
  for (const p of ["password1234", "Password12345!", "qwertyuiop12", "123456789012", "aaaaaaaaaaaa", "abcabcabcabc"]) {
    const v = assessPassword(p);
    assert.equal(v.acceptable, false, `${p} → ${v.label} ${v.warnings.join(" / ")}`);
  }
});

test("the user's own address is not a password", () => {
  const v = assessPassword("ops.team@example.com", "ops.team@example.com");
  assert.equal(v.acceptable, false);
  assert.ok(v.warnings.some((w) => /email/.test(w)));
  //and the local part on its own drags the score down
  assert.equal(assessPassword("ops.team-2026!", "ops.team@example.com").acceptable, false);
});

test("the labels climb with the score", () => {
  assert.equal(assessPassword("").label, "Too weak");
  assert.equal(assessPassword("short").label, "Too weak");
  assert.equal(assessPassword("correct horse battery staple").label, "Strong");
});
