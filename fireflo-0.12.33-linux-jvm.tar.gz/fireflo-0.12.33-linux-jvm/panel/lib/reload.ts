/**
 * What "Apply now" tells the operator, from what the gateway answered.
 *
 * <p>No React and no fetch, so the wording can be tested on its own. The gateway's answer is the
 * `/ops/reload` envelope: each domain and where it came from, and since 0.12.13 whether the
 * configuration was adopted at all -- a gateway whose licence has lapsed reloads and changes
 * nothing, which from the outside looks exactly like success.
 */

export interface ReloadResult {
  observed_at?: string;
  reloaded?: Record<string, string>;
  /** Absent on a gateway older than 0.12.13, which cannot say. */
  adopted?: boolean;
  reason?: string | null;
}

export type ReloadTone = "ok" | "warning" | "error";

export interface ReloadNotice {
  tone: ReloadTone;
  text: string;
  /** Where to go about it, when there is somewhere. */
  href?: string;
  hrefLabel?: string;
}

export const LICENCE_HREF = "/cp/verify";

export function reloadNotice(result: ReloadResult | null, error?: string | null): ReloadNotice {
  if (error) {
    return { tone: "error", text: error };
  }
  if (!result) {
    return { tone: "error", text: "The gateway did not answer." };
  }
  if (result.adopted === false) {
    return {
      tone: "warning",
      text: "Reloaded, but not adopted: this gateway's licence is not current, so configuration changes are frozen until it is.",
      href: LICENCE_HREF,
      hrefLabel: "Licence",
    };
  }
  //a domain the gateway reads from a file is not changed by anything saved in the panel; say so
  //rather than "applied", which is the exact confusion the reload page warns about
  const fromFile = Object.entries(result.reloaded ?? {})
    .filter(([, source]) => source === "file")
    .map(([domain]) => domain);
  if (fromFile.length) {
    return {
      tone: "warning",
      text: `Applied. Note that the gateway reads ${fromFile.join(", ")} from a file, so changes saved here to ${fromFile.length === 1 ? "that domain" : "those domains"} do not reach it.`,
    };
  }
  return { tone: "ok", text: "Applied — the gateway re-read its configuration." };
}
