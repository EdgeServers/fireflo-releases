import { test } from "node:test";
import assert from "node:assert/strict";
import { MAX_RANGE_DAYS, localDayEndExclusive, localDayStart, validateRange } from "./date-range.ts";

/**
 * The date arithmetic behind the portal's custom range.
 *
 * <p>Everything here is about one property: a customer asking for the 1st to the 15th gets the
 * whole of both days **in their own timezone**, and neither end is quietly clipped. The two ways to
 * get that wrong are both a few characters long and neither shows up as an error — the table simply
 * comes back short.
 *
 * <p>These run in whatever zone the test host is in, so they assert relationships (local midnight,
 * exactly one day apart) rather than fixed UTC instants. The one absolute check is pinned with TZ
 * in the verification notes.
 */

test("a From date is local midnight, not UTC midnight", () => {
  const at = localDayStart("2026-08-01");
  assert.ok(at);

  //the whole point: read back through the LOCAL getters, which is how the customer means it
  assert.equal(at.getFullYear(), 2026);
  assert.equal(at.getMonth(), 7);
  assert.equal(at.getDate(), 1);
  assert.equal(at.getHours(), 0);
  assert.equal(at.getMinutes(), 0);
  assert.equal(at.getSeconds(), 0);
  assert.equal(at.getMilliseconds(), 0);
});

test("east of Greenwich, local midnight is NOT the UTC midnight of the same date", () => {
  //the regression this file exists for. new Date("2026-08-01") is 2026-08-01T00:00:00Z; in
  //Asia/Kolkata that is 05:30 local, so a customer asking for the 1st loses its first 5.5 hours
  const local = localDayStart("2026-08-01")!;
  const naive = new Date("2026-08-01");

  const offset = local.getTimezoneOffset();
  if (offset === 0) {
    //UTC host: the two genuinely coincide, and there is nothing to tell apart
    assert.equal(local.getTime(), naive.getTime());
    return;
  }
  assert.notEqual(
    local.getTime(),
    naive.getTime(),
    "a bare date string was parsed as UTC and would shift the window by the whole offset"
  );
  assert.equal(local.getTime() - naive.getTime(), offset * 60_000);
});

test("a To date covers the whole day, by ending at the start of the next one", () => {
  const end = localDayEndExclusive("2026-08-15")!;

  assert.equal(end.getDate(), 16, "exclusive: the query is submitted_at < until");
  assert.equal(end.getHours(), 0);

  //the property that matters more than the number: nothing between them is excluded, so a message
  //at 23:59:59.999 on the 15th is inside the window
  const lastMoment = new Date(2026, 7, 15, 23, 59, 59, 999);
  assert.ok(lastMoment.getTime() < end.getTime());
});

test("month, year and leap-day ends roll over rather than needing a special case", () => {
  assert.equal(localDayEndExclusive("2026-01-31")!.getMonth(), 1, "31 Jan -> 1 Feb");
  assert.equal(localDayEndExclusive("2026-12-31")!.getFullYear(), 2027, "31 Dec -> 1 Jan");

  const afterLeapDay = localDayEndExclusive("2028-02-29")!;
  assert.equal(afterLeapDay.getMonth(), 2);
  assert.equal(afterLeapDay.getDate(), 1);
});

test("a day that does not exist is rejected, not rolled forward", () => {
  //new Date(2026, 1, 31) is 3 March. Accepting it would answer a question nobody asked
  assert.equal(localDayStart("2026-02-31"), null);
  assert.equal(localDayStart("2026-13-01"), null);
  assert.equal(localDayStart("2026-00-10"), null);
  assert.equal(localDayStart("not a date"), null);
  assert.equal(localDayStart(""), null);
  assert.equal(localDayStart("15/08/2026"), null);
});

test("a two-digit year is not silently moved to the twentieth century", () => {
  //new Date(99, 0, 1) is 1999. The regex accepts "0099", so the constructor has to be corrected
  const at = localDayStart("0099-01-01");
  assert.ok(at);
  assert.equal(at.getFullYear(), 99);
});

test("an incomplete or inverted range is refused with a reason", () => {
  assert.match(validateRange("", "2026-08-15")!, /both/i);
  assert.match(validateRange("2026-08-15", "")!, /both/i);
  assert.match(validateRange("2026-08-20", "2026-08-15")!, /on or before/i);
  assert.match(validateRange("nonsense", "2026-08-15")!, /valid date/i);
});

test("a single day is a legal range", () => {
  //From and To on the same date is the common case -- "what did I send today" -- and an exclusive
  //end makes it a 24-hour window rather than an empty one
  assert.equal(validateRange("2026-08-15", "2026-08-15"), null);
});

test("the span is capped, and the message says by how much it was exceeded", () => {
  assert.equal(validateRange("2026-01-01", "2026-03-01"), null, "60 days is fine");

  const refused = validateRange("2026-01-01", "2026-12-31");
  assert.ok(refused);
  assert.match(refused, new RegExp(String(MAX_RANGE_DAYS)));
  assert.match(refused, /365 days/);
});

test("the boundary is inclusive: exactly the maximum is allowed", () => {
  //MAX_RANGE_DAYS days means the exclusive end is that many days after the start, so a To date
  //MAX_RANGE_DAYS - 1 days later is the last accepted one
  const start = new Date(2026, 0, 1);
  const last = new Date(2026, 0, 1 + MAX_RANGE_DAYS - 1);
  const past = new Date(2026, 0, 1 + MAX_RANGE_DAYS);

  const iso = (d: Date) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

  assert.equal(validateRange(iso(start), iso(last)), null);
  assert.ok(validateRange(iso(start), iso(past)), "one day past the cap is refused");
});
