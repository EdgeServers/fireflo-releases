import { StreamLanguage, type StreamParser } from "@codemirror/language";

/**
 * Bash highlighting for the preprocessor workbench: comments, strings, variables, keywords and
 * the helper's own functions.
 *
 * <p>Written here rather than taken from `@codemirror/legacy-modes`, which is a whole package of
 * modes for one of them. This is a highlighter, not a parser -- the gateway's `bash -n` is what
 * says whether a script is valid, and its answer is drawn over the top as diagnostics.
 */

const KEYWORDS = new Set([
  "if", "then", "else", "elif", "fi", "for", "while", "until", "do", "done", "case", "esac", "in",
  "function", "select", "time", "return", "break", "continue", "local", "declare", "readonly",
  "export", "unset", "shift", "source", "set", "trap", "exit",
]);

const BUILTINS = new Set([
  "echo", "printf", "read", "test", "cd", "pwd", "eval", "exec", "let", "mapfile", "readarray",
  "true", "false", "stat", "dirname", "basename",
]);

interface State {
  /** Inside a double-quoted string that runs past the end of a line. */
  inString: boolean;
}

function variable(stream: Parameters<StreamParser<State>["token"]>[0]): string {
  //${...} as one token, braces and all; $name, $1, $?, $@ and friends otherwise
  if (stream.eat("{")) {
    let depth = 1;
    while (!stream.eol() && depth > 0) {
      const ch = stream.next();
      if (ch === "{") depth++;
      else if (ch === "}") depth--;
    }
  } else if (!stream.match(/^[A-Za-z_][A-Za-z0-9_]*/)) {
    stream.eat(/[0-9?@*#$!-]/);
  }
  return "variableName.special";
}

function doubleQuoted(stream: Parameters<StreamParser<State>["token"]>[0], state: State): string {
  while (!stream.eol()) {
    const ch = stream.peek();
    if (ch === "\\") {
      stream.next();
      stream.next();
      continue;
    }
    if (ch === '"') {
      stream.next();
      state.inString = false;
      return "string";
    }
    if (ch === "$") {
      //leave the variable for the next call, so it is coloured inside the string
      if (stream.current()) return "string";
      stream.next();
      return variable(stream);
    }
    stream.next();
  }
  state.inString = true;
  return "string";
}

const parser: StreamParser<State> = {
  name: "shell",
  startState: () => ({ inString: false }),
  token(stream, state) {
    if (state.inString) return doubleQuoted(stream, state);
    if (stream.eatSpace()) return null;

    const ch = stream.peek();
    if (ch === "#" && (stream.sol() || /\s/.test(stream.string.charAt(stream.pos - 1)))) {
      stream.skipToEnd();
      return "comment";
    }
    if (ch === '"') {
      stream.next();
      return doubleQuoted(stream, state);
    }
    if (ch === "'") {
      stream.next();
      if (stream.skipTo("'")) stream.next();
      else stream.skipToEnd();
      return "string";
    }
    if (ch === "$") {
      stream.next();
      if (stream.eat("(")) return "keyword";
      return variable(stream);
    }
    if (stream.match(/^-?\d+\b/)) return "number";
    if (stream.match(/^[A-Za-z_][A-Za-z0-9_-]*/)) {
      const word = stream.current();
      if (KEYWORDS.has(word)) return "keyword";
      if (word.startsWith("fireflo_")) return "function(variableName)";
      if (BUILTINS.has(word)) return "variableName.standard";
      if (stream.peek() === "(" && stream.string.slice(stream.pos, stream.pos + 2) === "()") return "function(definition)";
      return null;
    }
    if (stream.match(/^(\[\[|\]\]|&&|\|\||;;|[|&;<>()[\]{}=!])/)) return "operator";
    stream.next();
    return null;
  },
  languageData: { commentTokens: { line: "#" } },
};

export const shellLanguage = StreamLanguage.define(parser);
