import { test } from "node:test";
import assert from "node:assert/strict";
import { LICENCE_HREF, reloadNotice } from "./reload.ts";

const db = { properties: "database", credentials: "database", routing: "database", rates: "database" };

test("a reload that was adopted is 'applied'", () => {
  const n = reloadNotice({ reloaded: db, adopted: true });
  assert.equal(n.tone, "ok");
  assert.match(n.text, /^Applied/);
});

test("a lapsed licence reloads nothing and the button must not claim otherwise", () => {
  const n = reloadNotice({ reloaded: db, adopted: false, reason: "licence" });
  assert.equal(n.tone, "warning");
  assert.match(n.text, /not adopted/);
  assert.equal(n.href, LICENCE_HREF);
});

test("an older gateway that cannot say is taken as applied", () => {
  assert.equal(reloadNotice({ reloaded: db }).tone, "ok");
});

test("a domain read from a file is named, since a panel save never reaches it", () => {
  const n = reloadNotice({ reloaded: { ...db, rates: "file" }, adopted: true });
  assert.equal(n.tone, "warning");
  assert.match(n.text, /reads rates from a file/);
});

test("errors are shown as the gateway or the request put them", () => {
  assert.deepEqual(reloadNotice(null, "Request failed (503)"), { tone: "error", text: "Request failed (503)" });
  assert.equal(reloadNotice(null).tone, "error");
});
