/**
 * How a message text goes on the wire: which alphabet, how many characters it counts as, how many
 * parts. Shared by the SMPP test tool's live counter and its encoder, so the number the form shows is
 * the number that is sent.
 *
 * <p>Pure and browser-safe: no Node imports, so the client component can use it as it is.
 */

/** GSM 03.38 default alphabet, in code order: the character at index n has code n. */
const GSM_BASIC =
  "@£$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞ\u001bÆæßÉ !\"#¤%&'()*+,-./0123456789:;<=>?" +
  "¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà";

/** The extension table: each is sent as ESC (0x1B) then this code, so counts as two. */
const GSM_EXTENDED: Record<string, number> = {
  "\f": 0x0a, "^": 0x14, "{": 0x28, "}": 0x29, "\\": 0x2f, "[": 0x3c, "~": 0x3d, "]": 0x3e, "|": 0x40, "€": 0x65,
};

export type SmsEncoding = "gsm7" | "ucs2" | "ascii";

/** The data_coding byte each encoding goes out with. */
export const DATA_CODING: Record<SmsEncoding, number> = { gsm7: 0, ascii: 1, ucs2: 8 };

export interface SmsCount {
  encoding: SmsEncoding;
  /** Characters as the encoding counts them: an extension character is two in GSM-7, an emoji two in UCS-2. */
  units: number;
  /** The most one part holds, or each part of a multipart message holds. */
  perPart: number;
  parts: number;
}

/** Whether every character is in the GSM-7 alphabet, basic or extended. */
export function isGsm7(text: string): boolean {
  for (const ch of text) {
    if (ch !== "\u001b" && !GSM_BASIC.includes(ch) && !(ch in GSM_EXTENDED)) {
      return false;
    }
  }
  return true;
}

/**
 * The encoding "auto" picks: GSM-7 when every character fits, otherwise UCS-2.
 */
export function autoEncoding(text: string): SmsEncoding {
  return isGsm7(text) ? "gsm7" : "ucs2";
}

/** Counts a text in an encoding: units, the limit per part, and parts (0 for an empty text). */
export function countSms(text: string, encoding: SmsEncoding): SmsCount {
  let units = 0;
  if (encoding === "gsm7") {
    for (const ch of text) {
      units += ch in GSM_EXTENDED ? 2 : 1;
    }
  } else if (encoding === "ucs2") {
    //UTF-16 code units: a character outside the basic plane is a surrogate pair, two units
    units = text.length;
  } else {
    units = text.length;
  }
  const single = encoding === "ucs2" ? 70 : 160;
  const multi = encoding === "ucs2" ? 67 : 153;
  const parts = units === 0 ? 0 : units <= single ? 1 : Math.ceil(units / multi);
  return { encoding, units, perPart: parts > 1 ? multi : single, parts };
}

/**
 * The bytes for a text in an encoding: unpacked GSM-7 septets (one octet each, the SMPP default
 * alphabet), UCS-2 big-endian, or ASCII. Throws for a GSM-7 or ASCII text holding a character that
 * encoding does not have, rather than sending a question mark.
 */
export function encodeSms(text: string, encoding: SmsEncoding): Uint8Array {
  if (encoding === "ucs2") {
    const out = new Uint8Array(text.length * 2);
    for (let i = 0; i < text.length; i++) {
      const code = text.charCodeAt(i);
      out[i * 2] = code >> 8;
      out[i * 2 + 1] = code & 0xff;
    }
    return out;
  }
  if (encoding === "ascii") {
    const out: number[] = [];
    for (const ch of text) {
      const code = ch.charCodeAt(0);
      if (code > 0x7f) {
        throw new Error(`'${ch}' is not ASCII; choose UCS-2 or Auto.`);
      }
      out.push(code);
    }
    return Uint8Array.from(out);
  }
  const out: number[] = [];
  for (const ch of text) {
    const basic = GSM_BASIC.indexOf(ch);
    if (basic >= 0) {
      out.push(basic);
    } else if (ch in GSM_EXTENDED) {
      out.push(0x1b, GSM_EXTENDED[ch]);
    } else {
      throw new Error(`'${ch}' is not in the GSM-7 alphabet; choose UCS-2 or Auto.`);
    }
  }
  return Uint8Array.from(out);
}
