import { test } from "node:test";
import assert from "node:assert/strict";
import {
  buildCustomTlvs,
  canonicalTag,
  customTlvProblem,
  customTlvTag,
  duplicateCustomTlvTags,
  type CustomTlv,
} from "./custom-tlvs.ts";

/**
 * The `custom_tlvs` grammar.
 *
 * <p>Every case here is taken from the gateway's own parser or its tests
 * (`SendRequestParserTest.java:222-284`, `TlvUtil.parseTag`). This file exists because the panel now
 * builds that payload for the customer, and a builder that disagreed with the parser would produce
 * requests that are refused with no clue as to why — which is the bug that prompted the work.
 */

const row = (tag: string, type: CustomTlv["type"] = "OctetString", value = "x"): CustomTlv =>
  ({ tag, type, value });

test("a hex tag reads as hex, and a bare number reads as decimal", () => {
  //the whole footgun, in two lines. 0x1401 is 5121; a bare 1401 is 1401, which is 0x0579
  assert.equal(customTlvTag("0x1401"), 0x1401);
  assert.equal(customTlvTag("5121"), 0x1401);
  assert.equal(customTlvTag("1401"), 0x0579);
  assert.equal(customTlvTag("0X1401"), 0x1401, "uppercase X, as the Java accepts");
});

test("the tag is what follows the last underscore", () => {
  assert.equal(customTlvTag("tmid_0x1401"), 0x1401);
  assert.equal(customTlvTag("peid_0x1400"), 0x1400);
  assert.equal(customTlvTag("acct_1403"), 1403, "still decimal after the underscore");
  assert.equal(customTlvTag("a_b_0x1401"), 0x1401, "LAST underscore, not the first");
});

test("a name on its own names no tag", () => {
  //the gateway answers '(not a tag)'. Its catalogue of names is for its own declarations, and this
  //ingress never consults it
  assert.equal(customTlvTag("peid"), null);
  assert.equal(customTlvTag("operator"), null);
  assert.equal(customTlvTag(""), null);
  assert.equal(customTlvTag("   "), null);
  assert.equal(customTlvTag("tmid_"), null, "an underscore with nothing after it");
});

test("a tag outside the 16-bit range is not a tag", () => {
  assert.equal(customTlvTag("0x10000"), null);
  assert.equal(customTlvTag("65536"), null);
  assert.equal(customTlvTag("0xFFFF"), 0xffff, "and the top of the range still is");
});

test("a half-numeric token is refused rather than silently truncated", () => {
  //parseInt would read "12ab" as 12. Integer.parseInt in the Java throws, and this has to agree --
  //a typo that quietly became tag 12 would send the wrong parameter and never say so
  assert.equal(customTlvTag("12ab"), null);
  assert.equal(customTlvTag("0xZZ"), null);
});

test("the canonical key is the four-digit upper-case hex the gateway stores", () => {
  assert.equal(canonicalTag(0x1401), "0x1401".toUpperCase().replace("0X", "0x"));
  assert.equal(canonicalTag(0x0579), "0x0579");
  assert.equal(canonicalTag(5), "0x0005");
});

test("a bare decimal says what it resolves to, without assuming a mistake", () => {
  //the one finding with no gateway equivalent: 1401 parses, so the message is sent carrying a tag
  //nobody meant, the carrier ignores it, and nothing anywhere reports a problem.
  //
  //But decimal tags are legal and some vendors publish them that way, so the sentence states the
  //resolution and offers the other reading. Written as an accusation it would be wrong half the
  //time it appeared -- which is how this test read on its first draft
  const problem = String(customTlvProblem(row("1401")));
  assert.match(problem, /read as decimal/);
  assert.match(problem, /tag 0x0579/, "says what it actually resolves to");
  assert.match(problem, /0x1401/, "and offers the other reading");

  //a customer who correctly typed the decimal for 0x1401 gets the same sentence, and for them it
  //reads as a confirmation
  assert.match(String(customTlvProblem(row("5121"))), /tag 0x1401/);
});

test("an unambiguous tag says nothing at all", () => {
  assert.equal(customTlvProblem(row("0x1401")), null);
  assert.equal(customTlvProblem(row("tmid_0x1401")), null);
  //a single digit reads the same in both bases, so there is nothing to point out
  assert.equal(customTlvProblem(row("5")), null);
});

test("a name with no number says what to write instead", () => {
  const problem = customTlvProblem(row("peid"));
  assert.match(String(problem), /names no tag/);
  assert.match(String(problem), /tmid_0x1401/);
});

test("an empty row is not a problem, it is an empty row", () => {
  assert.equal(customTlvProblem(row("")), null);
});

test("IntN is octets, not bits", () => {
  //Int8 is eight bytes. A DLT template id near 1.4e18 fits in it and in nothing smaller, which is
  //the case this type exists for
  assert.equal(customTlvProblem({ tag: "0x1401", type: "Int8", value: "1401778070000018542" }), null);
  const problem = customTlvProblem({ tag: "0x1400", type: "Int1", value: "256" });
  assert.match(String(problem), /does not fit Int1/);
  assert.match(String(problem), /octets, not bits/);
  //255 is the largest unsigned byte, but the encoding is two's complement, so 127 is the ceiling
  assert.equal(customTlvProblem({ tag: "0x1400", type: "Int1", value: "127" }), null);
  assert.notEqual(customTlvProblem({ tag: "0x1400", type: "Int1", value: "128" }), null);
  assert.equal(customTlvProblem({ tag: "0x1400", type: "Int1", value: "-128" }), null);
});

test("an integer type with text in it says to use OctetString", () => {
  const problem = customTlvProblem({ tag: "0x1400", type: "Int4", value: "not-a-number" });
  assert.match(String(problem), /whole number/);
  assert.match(String(problem), /OctetString/);
  //and text under the default type is exactly what OctetString is for
  assert.equal(customTlvProblem({ tag: "0x1400", type: "OctetString", value: "not-a-number" }), null);
});

test("two spellings of one tag are flagged, because the gateway refuses the whole request", () => {
  assert.deepEqual(duplicateCustomTlvTags([row("0x1400"), row("5120")]), [0x1400]);
  assert.deepEqual(duplicateCustomTlvTags([row("0x1400"), row("peid_0x1400")]), [0x1400]);
  assert.deepEqual(duplicateCustomTlvTags([row("0x1400"), row("0x1401")]), []);
  //an unparseable tag is somebody else's problem; it must not be counted as a duplicate of another
  assert.deepEqual(duplicateCustomTlvTags([row("peid"), row("operator")]), []);
});

test("the built object is what the parser wants", () => {
  assert.deepEqual(buildCustomTlvs([{ tag: "0x1401", type: "OctetString", value: "63463456346734734" }]), {
    "0x1401": "63463456346734734",
  });
});

test("a pinned type joins the key, and the default one does not", () => {
  //`0x1401:OctetString` is legal but reads as required, and every generated code sample would
  //carry it. The gateway assumes OctetString when nothing is pinned
  assert.deepEqual(buildCustomTlvs([{ tag: "0x1401", type: "Int8", value: "42" }]), {
    "0x1401:Int8": "42",
  });
  assert.deepEqual(buildCustomTlvs([{ tag: "0x1401", type: "OctetString", value: "42" }]), {
    "0x1401": "42",
  });
});

test("nothing to send is undefined, not an empty object", () => {
  //`"custom_tlvs": {}` in every code sample would read as part of the request
  assert.equal(buildCustomTlvs([]), undefined);
  assert.equal(buildCustomTlvs([{ tag: "  ", type: "OctetString", value: "x" }]), undefined);
});

test("a row with a tag and no value is kept, as an empty TLV", () => {
  //the gateway reads a null value as "", so an empty value is a real thing to send rather than an
  //incomplete row to drop
  assert.deepEqual(buildCustomTlvs([{ tag: "0x1401", type: "OctetString", value: "" }]), {
    "0x1401": "",
  });
});
