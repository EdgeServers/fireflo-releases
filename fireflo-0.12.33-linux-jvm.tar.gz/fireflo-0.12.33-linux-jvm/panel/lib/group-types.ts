/**
 * Vendor groups: the shapes, and everything true about how the gateway treats them.
 *
 * <p>A group is another name a routing rule's single target can resolve to. The rule grammar does
 * not change — resolution is table, then group, then worker — which is what keeps groups and
 * per-rule weights from becoming two ways to express one split.
 *
 * <p>Server-free on purpose, like `routing-types.ts`: the editor and the API route share these, and
 * a rule the panel enforces in only one of the two places is a rule the other can violate.
 */

export const GROUP_POLICIES = ["ROUND_ROBIN", "WEIGHTED", "FAILOVER"] as const;
export type GroupPolicy = (typeof GROUP_POLICIES)[number];

/**
 * What each policy does, in words the gateway's own behaviour justifies.
 *
 * <p>The differences are not cosmetic: they change which of `weight` and order is read at all, and
 * saying so here is what stops an operator setting a weight on a group that ignores it.
 */
export const GROUP_POLICY_MEANING: Record<GroupPolicy, string> = {
  ROUND_ROBIN:
    "Each message goes to the next member in turn. Weights are not read — every member that is up "
    + "carries an equal share.",
  WEIGHTED:
    "Traffic divides in proportion to the weights. The split is exact and interleaved rather than "
    + "sent in blocks, so 70/30 really is 70 and 30 out of every hundred.",
  FAILOVER:
    "Always the first member that is up, in the order below. The rest are standbys and carry "
    + "nothing until the ones above them stop accepting.",
};

/** Whether a policy reads the weight column at all. Everything else about weights follows from it. */
export function policyReadsWeight(policy: GroupPolicy): boolean {
  return policy === "WEIGHTED";
}

export interface RouteGroupMember {
  workerName: string;
  /** Read only by WEIGHTED. Always ≥ 1: the database CHECKs it, and 0 would silently mute a member. */
  weight: number;
  enabled: boolean;
}

export interface RouteGroupInput {
  name: string;
  policy: GroupPolicy;
  label: string | null;
  enabled: boolean;
  /** In preference order, which is what FAILOVER reads. Position is the stored `seq`. */
  members: RouteGroupMember[];
}

export type RouteGroup = RouteGroupInput;

/**
 * Everything that would make the gateway refuse the group, or route it in a way nobody meant.
 *
 * @returns the first problem, or null. One at a time deliberately: a form that lists five errors at
 *     once teaches people to stop reading them.
 */
export function validateRouteGroup(
  input: RouteGroupInput,
  tableNames: readonly string[] = [],
  workerNames: readonly string[] = []
): string | null {
  const name = (input?.name ?? "").trim();
  if (!name) {
    return "A group needs a name. Rules send to it by that name.";
  }
  if (name !== (input.name ?? "")) {
    return `'${input.name}' has a space at one end. Targets are matched exactly and a trailing `
      + "space is invisible everywhere it is shown, so no rule would ever reach it.";
  }
  //the gateway refuses the WHOLE table set on a name that means two things, because resolution is
  //table-then-group-then-worker and one of the two would be silently unreachable. Refused here so
  //it cannot be saved rather than discovered when routing stops
  if (tableNames.includes(name)) {
    return `'${name}' is already a routing table. A rule targeting it would reach the table and `
      + "never this group, so the gateway refuses the whole routing configuration until one of "
      + "them is renamed.";
  }
  if (workerNames.includes(name)) {
    return `'${name}' is already a vendor. A rule targeting it would reach the group and never the `
      + "vendor, so the gateway refuses the whole routing configuration until one of them is "
      + "renamed.";
  }
  if (!GROUP_POLICIES.includes(input.policy)) {
    return `'${input.policy}' is not a policy. Choose ${GROUP_POLICIES.join(", ")}.`;
  }
  if (!Array.isArray(input.members)) {
    return "A group needs a list of members, even an empty one.";
  }

  const seen = new Set<string>();
  for (const member of input.members) {
    const worker = (member?.workerName ?? "").trim();
    if (!worker) {
      return "Every member needs a vendor.";
    }
    //PRIMARY KEY (group_name, worker_name): the insert would fail anyway, but a duplicate here also
    //means somebody thinks they have doubled that vendor's share, which they have not
    if (seen.has(worker)) {
      return `'${worker}' is in this group twice. Listing a vendor again does not double its share `
        + "— use its weight for that.";
    }
    seen.add(worker);
    if (!Number.isInteger(member.weight) || member.weight < 1) {
      return `'${worker}' has a weight of ${member.weight}. Weights are whole numbers of 1 or more; `
        + "0 would leave the vendor listed but never sent to, which reads as a fault rather than "
        + "as a setting.";
    }
  }
  return null;
}

/**
 * Things worth saying that are not worth refusing.
 *
 * <p>Each of these is a configuration the gateway accepts and runs, and each is one where what
 * happens differs from what the screen appears to promise.
 */
export function routeGroupWarnings(input: RouteGroupInput): string[] {
  const warnings: string[] = [];
  const live = (input.members ?? []).filter((m) => m.enabled);

  if (!live.length) {
    warnings.push(
      "No members are switched on, so every rule sending here routes nothing — the message falls "
      + "through to the rule below, and is dropped if there is none."
    );
  }
  if (live.length === 1 && input.policy === "FAILOVER") {
    warnings.push(
      "One member in a failover group is just that vendor. Failover needs something to fail over "
      + "to."
    );
  }
  //the gateway logs routing.group.weight-ignored for exactly this, and the point of repeating it
  //here is that the panel is where the number was typed
  if (!policyReadsWeight(input.policy) && (input.members ?? []).some((m) => m.weight !== 1)) {
    warnings.push(
      `Weights are set, but ${input.policy === "ROUND_ROBIN" ? "round robin" : "failover"} does not `
      + "read them — traffic will not split in those proportions. Switch to weighted, or clear "
      + "them so the screen matches what happens."
    );
  }
  if (input.policy === "WEIGHTED" && live.length > 1 && live.every((m) => m.weight === live[0].weight)) {
    warnings.push(
      "Every weight is the same, which is round robin with extra steps. That is fine — but if you "
      + "meant to split unevenly, the numbers have not been changed yet."
    );
  }
  return warnings;
}

/** The share of traffic each member actually receives, as a percentage. */
export function memberShares(input: RouteGroupInput): Map<string, number> {
  const shares = new Map<string, number>();
  //only members that are up: a suspended vendor's share is re-proportioned across the rest rather
  //than left unsent, and showing it a share it is not receiving would be a lie at the worst moment
  const live = (input.members ?? []).filter((m) => m.enabled);
  if (!live.length) {
    return shares;
  }
  if (input.policy === "FAILOVER") {
    shares.set(live[0].workerName, 100);
    for (const member of live.slice(1)) {
      shares.set(member.workerName, 0);
    }
    return shares;
  }
  const total = policyReadsWeight(input.policy)
    ? live.reduce((sum, m) => sum + m.weight, 0)
    : live.length;
  for (const member of live) {
    const own = policyReadsWeight(input.policy) ? member.weight : 1;
    shares.set(member.workerName, (own / total) * 100);
  }
  return shares;
}
