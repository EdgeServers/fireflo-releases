import { test } from "node:test";
import assert from "node:assert/strict";
import { parseTlvColumn, tlvProvenance, verdictSentence } from "./tlv-provenance.ts";

/**
 * The two questions this exists to answer, asked as tests.
 *
 * <p>"Did an account, sender ID or template replace what the customer sent?" and "did the tag the
 * telco requires actually go out?" Both were unanswerable while the CDR recorded only the middle of
 * the pipeline.
 */

const json = (o: Record<string, string>) => JSON.stringify(o);

test("a tag the whitelist overwrote is reported as replaced, with both values", () => {
  const { rows } = tlvProvenance(
    json({ "0x1400": "customer-said-9999" }),
    json({ "0x1400": "template-said-1234" }),
    json({ "0x1400": "template-said-1234" })
  );

  assert.equal(rows.length, 1);
  assert.equal(rows[0].verdict, "replaced");
  assert.equal(rows[0].received, "customer-said-9999");
  assert.equal(rows[0].sent, "template-said-1234");
});

test("a tag the vendor does not register is reported as dropped, and counts as a finding", () => {
  //the case that used to be invisible: present on the message, absent from the wire, mentioned
  //nowhere above DEBUG
  const p = tlvProvenance(json({ "0x1401": "peid" }), json({ "0x1401": "peid" }), json({}));

  assert.equal(p.rows[0].verdict, "dropped");
  assert.equal(p.rows[0].sent, null);
  assert.ok(p.hasFindings, "a dropped tag must be surfaced, not just recorded");
});

test("a tag the vendor supplied itself appears even though no stage before it had one", () => {
  //the union of all three key sets is what makes this visible; iterating only the resolved map
  //would miss it entirely
  const { rows } = tlvProvenance(json({}), json({}), json({ "0x1402": "vendor-default" }));

  assert.equal(rows.length, 1);
  assert.equal(rows[0].tag, "0x1402");
  assert.equal(rows[0].verdict, "vendor-default");
});

test("a tag added by the gateway is distinguished from one the customer sent", () => {
  const { rows } = tlvProvenance(json({}), json({ "0x1400": "from-the-template" }), json({ "0x1400": "from-the-template" }));

  assert.equal(rows[0].verdict, "added");
});

test("an untouched tag is unchanged and is not a finding", () => {
  const p = tlvProvenance(json({ "0x1400": "v" }), json({ "0x1400": "v" }), json({ "0x1400": "v" }));

  assert.equal(p.rows[0].verdict, "unchanged");
  assert.equal(p.hasFindings, false);
});

test("when the wire was never recorded, no verdict claims anything about it", () => {
  //THE guard. tlvs_sent is null for a non-SMPP vendor, a message that never reached one, and every
  //row written before the column existed. Reporting those as "dropped" would invent an outage
  const p = tlvProvenance(json({ "0x1400": "v" }), json({ "0x1400": "v" }), null);

  assert.equal(p.sentRecorded, false);
  assert.equal(p.rows[0].verdict, "unchanged");
  assert.equal(p.hasFindings, false, "an unrecorded wire is not evidence of a drop");
});

test("an empty sent set is recorded, and is not the same as an unrecorded one", () => {
  //`{}` means the vendor registered nothing and sent nothing -- which IS a drop
  const empty = tlvProvenance(json({ "0x1400": "v" }), json({ "0x1400": "v" }), json({}));
  const absent = tlvProvenance(json({ "0x1400": "v" }), json({ "0x1400": "v" }), null);

  assert.equal(empty.sentRecorded, true);
  assert.equal(empty.rows[0].verdict, "dropped");
  assert.equal(absent.sentRecorded, false);
  assert.equal(absent.rows[0].verdict, "unchanged");
});

test("a vendor changing a value it was given is called out rather than folded into unchanged", () => {
  //the vendor default is documented as gap-fill only, so this should not happen -- which is exactly
  //why it deserves a name when it does
  const p = tlvProvenance(json({ "0x1400": "a" }), json({ "0x1400": "a" }), json({ "0x1400": "b" }));

  assert.equal(p.rows[0].verdict, "vendor-overrode");
  assert.ok(p.hasFindings);
});

test("the drop verdict wins over the ingress comparison", () => {
  //replaced AND dropped: the drop is the actionable fact, so it is the one reported
  const { rows } = tlvProvenance(json({ "0x1400": "a" }), json({ "0x1400": "b" }), json({}));

  assert.equal(rows[0].verdict, "dropped");
});

test("rows are ordered by tag so two messages compare", () => {
  const { rows } = tlvProvenance(
    json({ "0x1402": "c", "0x1400": "a" }),
    json({ "0x1401": "b" }),
    null
  );

  assert.deepEqual(rows.map((r) => r.tag), ["0x1400", "0x1401", "0x1402"]);
});

test("unreadable or absent columns yield null rather than throwing", () => {
  //a record that cannot be parsed is still evidence; the caller falls back to showing it raw
  assert.equal(parseTlvColumn(null), null);
  assert.equal(parseTlvColumn(""), null);
  assert.equal(parseTlvColumn("not json"), null);
  assert.equal(parseTlvColumn("[1,2]"), null, "an array is not a tag map");
  assert.deepEqual(parseTlvColumn('{"0x1400":1234}'), { "0x1400": "1234" }, "numbers become text");
});

test("a message with no TLVs at any stage produces no rows", () => {
  const p = tlvProvenance(null, null, null);

  assert.deepEqual(p.rows, []);
  assert.equal(p.hasFindings, false);
});

test("the sentence names the vendor when there is one", () => {
  const [row] = tlvProvenance(json({ "0x1400": "v" }), json({ "0x1400": "v" }), json({})).rows;

  assert.match(verdictSentence(row, "smppclient.vendor1"), /smppclient\.vendor1/);
  assert.match(verdictSentence(row, null), /This vendor/);
});
