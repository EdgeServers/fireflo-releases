import { configQuery } from "@/lib/config-db";
import type { ActivityFilter, ActivityItem, ActivityPage } from "@/lib/account-activity-types";

/**
 * An account's activity history, newest first, from the three logs that record it.
 *
 * <p>Server-only. One UNION rather than three requests merged in the browser, so a page is exactly
 * `limit` lines in true time order and the cursor means one thing.
 *
 * <p><strong>What is left out, on purpose.</strong> `portal_access` -- a signed-in customer opening
 * pages -- would bury everything else. And the ledger's per-message rows (RESERVE, RELEASE) run to
 * one or two per message sent; the account's Statement is where those belong. What remains is what
 * somebody did: signed in, changed something, moved money.
 */
const CUSTOMER_SIGNIN_EVENTS = [
  "link_requested", "link_denied", "link_redeemed", "link_rejected",
  "password_signin", "password_signin_failed",
];
const MONEY_ENTRIES = ["RECHARGE", "TRANSFER", "ADJUSTMENT", "BILL"];

export async function accountActivity(
  accountId: string,
  filter: ActivityFilter,
  before: string | null,
  limit: number
): Promise<ActivityPage> {
  const parts: string[] = [];
  //customer log: sign-ins under "signins", everything else it records (a customer setting their
  //password, a reseller adding a person) under "changes"
  if (filter === "all" || filter === "signins" || filter === "changes") {
    const which = filter === "signins" ? "AND event = ANY($4)" : filter === "changes" ? "AND NOT (event = ANY($4))" : "";
    //the address typed, or for a redeemed link -- which records the person, not an address -- theirs
    parts.push(`SELECT 'customer' AS source, c.id, c.occurred_at AS at, c.event,
                       COALESCE(NULLIF(c.email, ''), u.email) AS actor, c.ip, c.detail,
                       NULL::bigint AS delta, NULL::text AS counterparty, NULL::text AS ledger_account
                  FROM app_customer_access_log c
                  LEFT JOIN app_user u ON u.id = c.user_id
                 WHERE c.account_id = $1 AND c.event <> 'portal_access' ${which.replace("event", "c.event")}`);
  }
  //operator log: anything an operator did that names this account
  if (filter === "all" || filter === "changes") {
    parts.push(`SELECT 'operator' AS source, id, occurred_at AS at, event, actor, ip, detail,
                       NULL::bigint AS delta, NULL::text AS counterparty, NULL::text AS ledger_account
                  FROM app_operator_access_log
                 WHERE detail->>'account' = $1`);
  }
  if (filter === "all" || filter === "money") {
    parts.push(`SELECT 'ledger' AS source, id, created_at AS at, lower(entry_type) AS event,
                       NULL::text AS actor, NULL::text AS ip,
                       jsonb_strip_nulls(jsonb_build_object('note', note, 'ref', ref, 'applied', applied)) AS detail,
                       delta, counterparty_account_id AS counterparty, account_id AS ledger_account
                  FROM balance_ledger
                 WHERE entry_type = ANY($5)
                   AND (account_id = $1 OR counterparty_account_id = $1)`);
  }

  const rows = await configQuery<{
    source: ActivityItem["source"]; id: number | string; at: Date | string; event: string;
    actor: string | null; ip: string | null; detail: Record<string, unknown> | null;
    delta: string | number | null; counterparty: string | null; ledger_account: string | null;
  }>(
    `SELECT * FROM (${parts.join("\n UNION ALL \n")}) activity
      WHERE ($2::timestamptz IS NULL OR at < $2::timestamptz)
        --both lists are always sent and always referenced: node-postgres refuses a parameter the
        --statement does not use, and which branches are present depends on the filter
        AND cardinality($4::text[]) >= 0 AND cardinality($5::text[]) >= 0
      ORDER BY at DESC, source, id DESC
      LIMIT $3`,
    [accountId, before, limit + 1, CUSTOMER_SIGNIN_EVENTS, MONEY_ENTRIES]
  );
  const currency = await configQuery<{ currency: string | null }>(
    "SELECT currency FROM account_balance WHERE account_id = $1",
    [accountId]
  ).catch(() => []);

  const more = rows.length > limit;
  const page = rows.slice(0, limit);
  const items: ActivityItem[] = page.map((r) => ({
    key: `${r.source}-${r.id}`,
    at: new Date(r.at).toISOString(),
    source: r.source,
    event: r.event,
    actor: r.actor,
    ip: r.ip,
    detail: r.detail,
    delta: r.delta == null ? null : String(r.delta),
    counterparty: r.counterparty,
    ledgerAccount: r.ledger_account,
  }));
  return {
    items,
    next: more && items.length ? items[items.length - 1].at : null,
    currency: currency[0]?.currency ?? null,
  };
}
