import { strict as assert } from "node:assert";
import { test } from "node:test";
import { workerPropertiesSql, workerRowsSql } from "./workers-sql.ts";

/**
 * String assertions, like `whitelist-sql.test.ts`: the panel has no database-backed test, so what
 * these pin is the shape -- that a `type` filter reaches the properties read as SQL rather than
 * being applied after every worker's settings have been fetched (CP-P8).
 */

test("with a type, the properties read joins app_worker and filters on its type", () => {
  const sql = workerPropertiesSql("smppclient");
  assert.match(sql.text, /JOIN\s+app_worker\s+w\s+ON\s+w\.name\s*=\s*p\.worker_name/);
  assert.match(sql.text, /WHERE\s+w\.type\s*=\s*\$1/);
  assert.deepEqual(sql.values, ["smppclient"]);
});

test("with a type, the worker rows read filters on it too", () => {
  const sql = workerRowsSql("smppserver");
  assert.match(sql.text, /WHERE\s+type\s*=\s*\$1/);
  assert.deepEqual(sql.values, ["smppserver"]);
});

test("without a type, neither read carries a predicate or a parameter", () => {
  for (const sql of [workerRowsSql(), workerPropertiesSql()]) {
    assert.doesNotMatch(sql.text, /WHERE/);
    assert.doesNotMatch(sql.text, /\$1/);
    assert.deepEqual(sql.values, []);
  }
});

test("every parameter placeholder has a value, and vice versa", () => {
  for (const sql of [workerRowsSql("smppclient"), workerPropertiesSql("smppclient"), workerRowsSql(), workerPropertiesSql()]) {
    const placeholders = new Set(sql.text.match(/\$\d+/g) ?? []);
    assert.equal(placeholders.size, sql.values.length, sql.text);
  }
});

test("both reads keep the column names listWorkers maps from", () => {
  //the mapping reads row.worker_name / key / value and name / type / enabled / label; a column
  //renamed by an alias here would come back as undefined, not as an error
  assert.match(workerPropertiesSql("smppclient").text, /SELECT\s+p\.worker_name,\s+p\.key,\s+p\.value/);
  assert.match(workerRowsSql("smppclient").text, /SELECT\s+name,\s+type,\s+enabled,\s+label/);
});
