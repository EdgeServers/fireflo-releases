/**
 * What the Archives report shows: the queue archive the gateway writes when an operator cleans a
 * queue, the runs that wrote it, and the per-day summary that outlives a purge.
 *
 * <p>Types and constants only, no `pg` import: a client component reads this, and anything that
 * reaches into the database from here drags the driver into the browser bundle.
 *
 * <p>The tables are the gateway's (V1.93.0): `queue_archive` partitioned by month on `archived_at`,
 * `queue_archive_batch` one row per run (a clean, a purge, a receipt re-push), and
 * `queue_archive_summary` one row per day, account, store, kind and worker, kept forever.
 */

/** The gateway release that brings the archive tables. Said on the page when they are absent. */
export const ARCHIVE_GATEWAY_RELEASE = "0.12.19";

/** Where an archived entry was waiting. The gateway's CHECK on `queue_archive.store`. */
export const ARCHIVE_STORES = ["worker", "routing", "receipts", "callbacks", "spill"] as const;
export type ArchiveStore = (typeof ARCHIVE_STORES)[number];

/** What a run did. `queue_archive_batch.store` also carries `purge` and `repush`. */
export const BATCH_STORES = [...ARCHIVE_STORES, "purge", "repush"] as const;
export type BatchStore = (typeof BATCH_STORES)[number];

export const STORE_LABEL: Record<string, string> = {
  worker: "Vendor / listener queue",
  routing: "Routing",
  receipts: "Unpushed receipts",
  callbacks: "Callback retries",
  spill: "Spill file",
  purge: "Archive purge",
  repush: "Receipt re-push",
};

/**
 * Every answer from an archive route. `available: false` is a gateway older than V1.93.0 — the
 * page says which release brings the report instead of showing an error.
 */
export type ArchiveAnswer<T> = ({ available: true } & T) | { available: false; release: string };

/** One monthly partition, or a month whose detail rows were purged and only the summary remains. */
export interface ArchivePartition {
  /** `YYYY-MM`, or null for the default partition (rows outside every monthly range). */
  month: string | null;
  /** Detail rows still held. Null for a purged month. */
  rows: number | null;
  firstAt: string | null;
  lastAt: string | null;
  /** Bytes on disk, table plus indexes. Null for a purged month. */
  sizeBytes: number | null;
  /** When the purge ran, for a month whose detail rows are gone. */
  purgedAt: string | null;
  /** How many detail rows the purge removed — the summary's message count for that month. */
  purgedRows: number | null;
}

/** Per account, over a period: the reconciliation view, read from the summary so it survives a purge. */
export interface ArchiveAccountRow {
  accountId: string | null;
  messages: number;
  refunded: number;
  receiptsSent: number;
  /** Numeric as text: summed prices, never rounded through a float. */
  priceTotal: string | null;
  firstAt: string | null;
  lastAt: string | null;
  /** Of `messages`, how many still have their detail rows, and how many were purged. */
  held: number;
  purged: number;
}

export interface ArchiveEntry {
  id: string;
  archivedAt: string;
  batchId: string | null;
  store: string;
  subStore: string | null;
  kind: string;
  worker: string | null;
  accountId: string | null;
  systemId: string | null;
  gatewayMsgId: string | null;
  serial: string | null;
  sourceAddr: string | null;
  destAddr: string | null;
  product: string | null;
  price: string | null;
  parts: number | null;
  /** Only when the gateway stored it (`smsg.cdr.body`); null otherwise. */
  body: string | null;
  retries: number | null;
  createdAt: string | null;
  reason: string | null;
  note: string | null;
  actor: string | null;
  refunded: boolean | null;
  receiptSent: boolean | null;
}

export interface ArchiveCursor {
  archivedAt: string;
  id: string;
}

export interface ArchiveEntriesPage {
  rows: ArchiveEntry[];
  nextCursor: ArchiveCursor | null;
}

export interface ArchiveBatch {
  batchId: string;
  startedAt: string;
  finishedAt: string | null;
  store: string;
  /** The selector the run was given, as the gateway stored it. */
  selector: Record<string, unknown> | null;
  actor: string | null;
  reason: string | null;
  note: string | null;
  matched: number | null;
  archived: number | null;
  refunded: number | null;
  receiptsSent: number | null;
  failed: number | null;
}

/** The selector as one short line: `worker=smppclient.acme sub=held older=7200s`. */
export function selectorLine(selector: Record<string, unknown> | null): string {
  if (!selector) {
    return "—";
  }
  const parts: string[] = [];
  for (const [key, value] of Object.entries(selector)) {
    if (value == null || value === "" || value === false) {
      continue;
    }
    parts.push(`${key}=${Array.isArray(value) ? value.join(",") : typeof value === "object" ? JSON.stringify(value) : String(value)}`);
  }
  return parts.length ? parts.join(" ") : "—";
}
