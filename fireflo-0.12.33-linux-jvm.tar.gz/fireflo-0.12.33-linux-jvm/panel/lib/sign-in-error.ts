/**
 * What the login form says when sign-in fails, by the error Auth.js hands back.
 *
 * <p>One message for every failure sent operators after the password when the password was never
 * the problem. Auth.js reports a dropped CSRF cookie as `MissingCSRF`, before `authorize` runs at
 * all: the browser was given the cookie and did not send it back. Behind that, almost always, is a
 * panel reached over plain http:// whose AUTH_URL says https://, so the cookie came marked
 * HTTPS-only and the browser kept it to itself. A reset password changes nothing there, and the
 * only place that said so was the server's journal.
 *
 * <p>A wrong username or password is still not broken down further -- the server does not say which
 * half was wrong, and neither does this.
 */
export function signInErrorMessage(
  error: string | undefined,
  page: { protocol: string; origin: string },
): string {
  if (error === "MissingCSRF") {
    const lead =
      "Sign-in was refused before the password was checked: the browser did not send back the " +
      "panel's sign-in cookie.";
    if (page.protocol === "http:") {
      return (
        `${lead} This page is plain HTTP, and the panel marks that cookie HTTPS-only when ` +
        "AUTH_URL starts with https://. Open the panel over HTTPS, or, on a test server, set " +
        `AUTH_URL=${page.origin} and AUTH_COOKIE_SECURE=false in panel.env and restart it.`
      );
    }
    return (
      `${lead} Clear this site's cookies and try again. If it persists, check that AUTH_URL in ` +
      `panel.env is ${page.origin} and that the proxy in front passes cookies through.`
    );
  }
  if (error === "CredentialsSignin" || error === undefined) {
    return (
      "Sign-in failed. Check the username and password. If nobody can sign in, an admin can reset a " +
      "password from the server with: fireflo user passwd --email you@example.com --generate"
    );
  }
  return (
    `Sign-in could not be completed (${error}). The panel's service log says why: ` +
    "journalctl -u followed by the panel's unit name."
  );
}
