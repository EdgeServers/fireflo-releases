import type { Health } from "./health-types";

/** How long the queue line reaches back. Matches the live traffic chart's MT/DLR window. */
export const QUEUE_HISTORY_MS = 15 * 60_000;

/** One health poll: when it arrived, and each worker's queued messages (waiting + scheduled retries). */
export interface QueueSample {
  t: number;
  depth: Readonly<Record<string, number>>;
}

export type QueueHistory = readonly QueueSample[];

/**
 * Fold one health snapshot into the running queue history.
 *
 * <p>The gateway keeps no history of queue depth -- it exists only in the snapshot -- so the only
 * way to draw it as a line is to remember the polls this page has seen. Folded at the fetch, like
 * `appendTps`, and for the same reasons: one render per poll, and a pure function of
 * (previous, snapshot, now).
 *
 * <p>Bounded by time, not by count: a tab left open overnight keeps fifteen minutes, and a tab
 * hidden for an hour comes back to a gap rather than to a line drawn across the hour it missed.
 */
export function appendQueue(previous: QueueHistory, health: Health, now: number): QueueHistory {
  const depth: Record<string, number> = {};
  for (const worker of health.workers) {
    depth[worker.name] = Math.max(0, worker.queue_depth ?? 0) + Math.max(0, worker.retry_queue_depth ?? 0);
  }
  return [...previous.filter((s) => s.t >= now - QUEUE_HISTORY_MS), { t: now, depth }];
}
