/**
 * What the customer asked to be told, read back out of the octet they sent.
 *
 * <p>`cdr_submit.registered_delivery` is the SMPP field stored raw. The gateway decodes it into a
 * `ReceiptRequest` to decide what to forward; this decodes the same byte into English so the record
 * can answer the question that used to be unanswerable from the panel: *did we owe this customer a
 * receipt at all.*
 *
 * <p><strong>The two decoders must agree, and this one is the copy.</strong>
 * `core/message/ReceiptRequest.java` is the original — bits 1–0 for which receipts, bits 3–2 for SME
 * acknowledgement, bit 4 for the intermediate notification. The test beside this file pins each
 * bit against the constants that file uses, so a divergence is a failing test rather than a page
 * that confidently describes the wrong thing.
 *
 * <p>Database-free, so a client component can import it.
 */

/** Which outcomes a receipt was wanted for. The gateway's `ReceiptRequest.Kind`. */
export type ReceiptKind = "NONE" | "ALL" | "FAILURE_ONLY" | "SUCCESS_ONLY";

export interface ReceiptRequest {
  kind: ReceiptKind;
  /** Bit 4: progress as well as the outcome. Jasmin's level 1, SMPP's intermediate notification. */
  interim: boolean;
  /**
   * Bits 3–2: the customer asked the *handset* to acknowledge.
   *
   * <p>Parsed and never acted on, which is correct rather than lazy — it is a request to the
   * network, not to us; FireFlo is not the SME. Surfaced because a customer who set it and saw
   * nothing happen deserves to see that we read it and that it was not ours to honour.
   */
  smeAck: boolean;
  /** The octet as stored, for the reader comparing against their own client's configuration. */
  raw: number;
}

const RECEIPT_MASK = 0x03;
const SME_ACK_MASK = 0x0c;
const INTERMEDIATE_MASK = 0x10;

/**
 * Decodes one octet.
 *
 * <p>Unrecognised receipt bits resolve to `ALL`, matching the gateway. That is the opposite
 * direction from every other "unknown value" default in this panel and it is deliberate: the bad
 * outcome here is silently ceasing to deliver receipts somebody relies on, which looks to them like
 * messages vanishing.
 */
export function decodeReceiptRequest(raw: number): ReceiptRequest {
  const byte = raw & 0xff;
  const bits = byte & RECEIPT_MASK;
  const kind: ReceiptKind =
    bits === 0x00 ? "NONE" :
    bits === 0x02 ? "FAILURE_ONLY" :
    bits === 0x03 ? "SUCCESS_ONLY" :
    "ALL";
  return {
    kind,
    interim: (byte & INTERMEDIATE_MASK) !== 0,
    smeAck: (byte & SME_ACK_MASK) !== 0,
    raw: byte,
  };
}

/**
 * Whether a receipt in this state reached the customer.
 *
 * <p>The mirror of `ReceiptRequest.forwards`, and the reason the panel can answer "why did my system
 * not get a receipt?" without reading a gateway log. It says only whether the customer was *told* —
 * every routed message is in the call record whatever they asked to hear about it.
 *
 * @param terminal whether this state closed the message. `isTerminalDlrState` in `labels.ts` decides
 *     that from the state; here it is passed in, because the detail view knows something better —
 *     which table the gateway actually wrote the row to
 */
export function receiptForwards(
  request: ReceiptRequest,
  dlrState: number | null,
  terminal: boolean
): boolean {
  if (!terminal) {
    return request.interim;
  }
  //DELIVRD and SEEN. SEEN bills as a delivery, so it must count as one here too, or a
  //SUCCESS_ONLY customer would be told nothing about a message they were charged for
  const delivered = dlrState === 1 || dlrState === 15;
  switch (request.kind) {
    case "NONE":
      return false;
    case "ALL":
      return true;
    case "FAILURE_ONLY":
      return !delivered;
    case "SUCCESS_ONLY":
      return delivered;
  }
}

/** The receipt request as a short phrase, for a table cell. */
export const RECEIPT_KIND_LABELS: Record<ReceiptKind, string> = {
  NONE: "No receipt",
  ALL: "Every outcome",
  FAILURE_ONLY: "Failures only",
  SUCCESS_ONLY: "Successes only",
};

/**
 * One line describing everything the octet asked for.
 *
 * @param raw the stored value, or null when the column is absent or the row predates it — which is
 *     not the same as zero. Zero is a claim about the customer; null is a claim about us
 */
export function receiptRequestSummary(raw: number | null | undefined): string {
  if (raw == null) {
    return "Not recorded";
  }
  const request = decodeReceiptRequest(raw);
  const parts = [RECEIPT_KIND_LABELS[request.kind]];
  if (request.interim) {
    parts.push("plus progress");
  }
  if (request.smeAck) {
    parts.push("handset acknowledgement (not ours to honour)");
  }
  return parts.join(", ");
}

/** `0x11`, so it can be compared against whatever the customer's own client is configured with. */
export function receiptRequestHex(raw: number | null | undefined): string {
  if (raw == null) {
    return "—";
  }
  return `0x${(raw & 0xff).toString(16).padStart(2, "0")}`;
}

/**
 * The REST vocabulary, where two fields say what one octet says on SMPP.
 *
 * <p>Mirrors `ReceiptRequest.ofLevel`: `dlr` is the master switch and `dlr-level` refines it,
 * following Jasmin — 1 progress, 2 the outcome, 3 both. Level 1 alone deliberately does *not* send
 * the outcome; a caller who said what they want is not overruled.
 */
export function receiptRequestForLevel(requested: boolean, level: number | null): ReceiptRequest {
  if (!requested) {
    return decodeReceiptRequest(0x00);
  }
  switch (level ?? 2) {
    case 1:
      return decodeReceiptRequest(0x10);
    case 3:
      return decodeReceiptRequest(0x11);
    default:
      return decodeReceiptRequest(0x01);
  }
}
