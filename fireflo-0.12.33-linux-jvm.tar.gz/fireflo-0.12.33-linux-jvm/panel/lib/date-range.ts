/**
 * A pair of `<input type="date">` values as the window the query layer wants.
 *
 * <p>Three lines of arithmetic that are wrong in three different ways if written inline, which is
 * why they live here with tests rather than in the component.
 *
 * <p>Database-free, so a client component can import it.
 */

/**
 * How far apart the two dates may be.
 *
 * <p>The CDR pool is eight connections behind a 10-second `statement_timeout`, shared with the
 * dashboard's polling. `app/api/mis/messages/route.ts` already refuses `range=all` on exactly this
 * reasoning; a hand-typed two-year window is the same request with a different spelling.
 */
export const MAX_RANGE_DAYS = 92;

const MILLIS_PER_DAY = 86_400_000;

const YMD = /^(\d{4})-(\d{2})-(\d{2})$/;

/**
 * The start of that day **where the reader is sitting**.
 *
 * <p><strong>Not `new Date("2026-08-01")`.</strong> A bare date string is parsed as UTC midnight by
 * specification, so in Asia/Kolkata it lands at 05:30 local — and a customer asking for the 1st
 * silently loses the first five and a half hours of it. The multi-argument constructor is the one
 * that means local time, and it is the only reason this function exists.
 *
 * @return null when the text is not a date, or names a day that does not exist (`2026-02-31`)
 */
export function localDayStart(value: string): Date | null {
  const match = YMD.exec(value.trim());
  if (!match) {
    return null;
  }
  const [, year, month, day] = match.map(Number);
  const at = new Date(year, month - 1, day, 0, 0, 0, 0);
  //two-digit years map to 1900-1999 in this constructor, and the regex above happily accepts 0099
  at.setFullYear(year);

  //`new Date(2026, 1, 31)` is the 3rd of March rather than an error, so a day that did not survive
  //construction was never a real day
  if (at.getFullYear() !== year || at.getMonth() !== month - 1 || at.getDate() !== day) {
    return null;
  }
  return at;
}

/**
 * The start of the **following** day, locally.
 *
 * <p>Exclusive on purpose: `searchCdrs` renders `until` as `submitted_at < $n`, so this is what
 * makes a To of the 15th include the whole of the 15th. The `+ "T23:59:59"` idiom used elsewhere in
 * this repo loses the last second of the day, and a message sent at 23:59:59.400 is not a message
 * anyone expects to have to ask for separately.
 *
 * <p>Day overflow normalises, so month ends, year ends and leap days need no special case.
 */
export function localDayEndExclusive(value: string): Date | null {
  const start = localDayStart(value);
  if (!start) {
    return null;
  }
  const end = new Date(start);
  end.setDate(end.getDate() + 1);
  return end;
}

/**
 * Why this range cannot be run, in a sentence the customer can act on.
 *
 * @return null when the range is fine
 */
export function validateRange(from: string, to: string): string | null {
  if (!from.trim() || !to.trim()) {
    return "Choose both a From and a To date.";
  }
  const start = localDayStart(from);
  const end = localDayEndExclusive(to);
  if (!start || !end) {
    return "That is not a valid date.";
  }
  if (end.getTime() <= start.getTime()) {
    return "The From date must be on or before the To date.";
  }

  //rounded, because a range spanning a daylight-saving change is 23 or 25 hours long on one of its
  //days and a floor would report 91.96 days as 91
  const days = Math.round((end.getTime() - start.getTime()) / MILLIS_PER_DAY);
  if (days > MAX_RANGE_DAYS) {
    return `That is ${days} days. Ask for at most ${MAX_RANGE_DAYS} at a time.`;
  }
  return null;
}

/**
 * An instant back into what an `<input type="date">` will accept, in local terms.
 *
 * <p>Not `toISOString().slice(0, 10)`, which is the UTC date and so names yesterday for anyone west
 * of Greenwich for part of their day. This is the inverse of {@link localDayStart} and has to agree
 * with it, or a shared link round-trips to a different window than the one that was shared.
 */
export function toDateInput(at: Date): string {
  const month = String(at.getMonth() + 1).padStart(2, "0");
  const day = String(at.getDate()).padStart(2, "0");
  return `${at.getFullYear()}-${month}-${day}`;
}

/**
 * The last day **inside** an exclusive window, as a date input value.
 *
 * <p>`until` on the wire is the start of the day after the one the customer asked for. Reading it
 * straight back would put the 16th in a box the customer typed the 15th into, and each reload of a
 * bookmarked link would push the window one day further out.
 */
export function inclusiveEndFromExclusive(until: Date): string {
  const last = new Date(until);
  last.setDate(last.getDate() - 1);
  return toDateInput(last);
}

/** The span in whole days, for a caller that has already validated. Used by the export route. */
export function spanInDays(since: Date, until: Date): number {
  return Math.round((until.getTime() - since.getTime()) / MILLIS_PER_DAY);
}
