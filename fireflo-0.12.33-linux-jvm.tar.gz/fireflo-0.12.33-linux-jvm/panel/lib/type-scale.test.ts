import { strict as assert } from "node:assert";
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
import { test } from "node:test";

/**
 * The type scale in `components/ui/card.tsx`, held where a class string can break it.
 *
 * <p>Each rule is one that drifted before it was written down: sizes picked by the pixel, textareas
 * that styled themselves at three sizes, and monospace set smaller than the text around it.
 */

function sources(dir: string): string[] {
  return readdirSync(dir).flatMap((name) => {
    const path = join(dir, name);
    if (statSync(path).isDirectory()) {
      return sources(path);
    }
    return /\.tsx?$/.test(name) && !name.endsWith(".test.ts") ? [path] : [];
  });
}

/** Each source line that is code rather than a comment, with where it came from. */
const LINES = ["components", "app"].flatMap(sources).flatMap((file) =>
  readFileSync(file, "utf8")
    .split("\n")
    .map((text, i) => ({ where: `${file}:${i + 1}`, text }))
    .filter(({ text }) => !/^\s*(\*|\/\/|\/\*)/.test(text))
);

test("no font size outside the scale", () => {
  const off = LINES.filter(({ text }) => /\btext-\[\d+(\.\d+)?(px|rem|em)\]/.test(text)).map((l) => l.where);
  assert.deepEqual(off, [], "use a size from the scale: text-2xs, xs, sm, base, lg, xl or 2xl");
});

test("every textarea is the Textarea primitive", () => {
  const raw = LINES.filter(({ where, text }) => /<textarea\b/.test(text) && !where.startsWith(join("components", "ui", "textarea.tsx")))
    .map((l) => l.where);
  assert.deepEqual(raw, [], "use <Textarea> from components/ui/textarea, which matches <Input>");
});

test("monospace is never set under 12px", () => {
  const small = LINES.filter(({ text }) =>
    /\bfont-mono\b[^"`]*\btext-2xs\b|\btext-2xs\b[^"`]*\bfont-mono\b/.test(text) ||
    //a Badge is text-2xs, so a monospace one has to say its size
    (/<Badge\b[^>]*\bfont-mono\b/.test(text) && !/<Badge\b[^>]*\btext-(xs|sm)\b/.test(text))
  ).map((l) => l.where);
  assert.deepEqual(small, [], "monospace takes the size of its text: text-sm for content, text-xs only for a caption");
});
