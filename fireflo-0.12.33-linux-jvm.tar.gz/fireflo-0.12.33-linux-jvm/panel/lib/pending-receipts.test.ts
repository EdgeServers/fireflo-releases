import { test } from "node:test";
import assert from "node:assert/strict";
import { pendingBadge, pendingSummary } from "./labels.ts";
import { projectForCustomer } from "./customer-cdr-columns.ts";

test("a message the carrier answered with ACCEPTD is not 'Awaiting receipt'", () => {
  assert.equal(pendingBadge(5).label, "Accepted by the carrier");
  assert.equal(pendingBadge(5, true).label, "Accepted");
  assert.equal(pendingBadge(9, true).label, "Held");
  assert.match(pendingBadge(5).title, /ACCEPTD: a progress receipt/);
  //nothing arrived, or a gateway with no cdr_interim at all: the old wording, which is then true
  assert.equal(pendingBadge(null).label, "Awaiting receipt");
  assert.equal(pendingBadge(undefined).label, "Awaiting receipt");
});

test("the summary counts the carrier-acknowledged ones apart", () => {
  const delivered = { finalState: "DELIVERED", progressState: 5 };
  const accepted = { finalState: null, progressState: 5 };
  const silent = { finalState: null, progressState: null };
  assert.equal(pendingSummary([delivered]), null);
  assert.match(pendingSummary([delivered, accepted, silent])!,
    /^2 of these 3 have no final outcome yet, 1 of them acknowledged by the carrier/);
  assert.match(pendingSummary([accepted, accepted])!, /, all acknowledged by the carrier/);
  assert.match(pendingSummary([silent])!, /^1 of these 1 has no final outcome yet\. That is normal/);
});

test("a customer's row keeps the progress state its outcome badge reads", () => {
  const row = projectForCustomer({ finalState: null, progressState: 5, vendor: "secret-vendor" });
  assert.equal(row.progressState, 5);
  assert.equal("vendor" in row, false);
});

test("a throughput peak reads as one short line, and says how it was measured", async () => {
  const { peakLine } = await import("./labels.ts");
  const line = peakLine({ tps: 1436, at: "2026-10-13T02:58:18Z", window_seconds: 5 }, () => "13 Oct, 02:58");
  assert.equal(line.text, `Peak ${(1436).toLocaleString()}/s · 13 Oct, 02:58`);
  assert.match(line.title, /5-second window, kept across restarts/);
  assert.equal(peakLine(null, String).text, "No peak measured yet");
});
