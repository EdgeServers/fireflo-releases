import {
  buildDlrReturnRule,
  returnReceiptsPerListener,
  ruleDirection,
  type RouteRule,
} from "./routing-types.ts";
import { trafficKey, type Worker } from "./worker-types.ts";

/**
 * The receipt rules the panel keeps for itself: one per SMPP listener, created with the listener,
 * removed with it, and not editable in between.
 *
 * <p>Zero database imports, so the decisions are testable; `lib/routing.ts` applies them inside the
 * write that needs them.
 *
 * <p><strong>Why only receipts.</strong> A delivery receipt has exactly one correct destination,
 * the listener its message arrived on, which the gateway stamps as `ingateway = smppserver.<name>`.
 * So a receipt rule is never a business decision, and leaving it to the operator only ever produced
 * the two failures it exists to prevent: a listener added later with no rule, so its customers get
 * no receipts; and the first listener's unqualified rule taking every listener's receipts. Where
 * outbound and inbound traffic goes is a choice, so those rules stay editable.
 *
 * <p>The gateway also returns a receipt no rule placed to its own listener, so a missing rule here
 * costs a log line rather than a customer's receipts. These rules are still kept, because the table
 * is what an operator reads, and a rule that is there says what happens where a fallback does not.
 */

/** An SMPP listener as these functions need it. Disabled ones count: they keep their rule. */
export type Listener = Pick<Worker, "name" | "type"> & { enabled?: boolean };

const RECEIPT = "18";

function isReceiptCondition(c: RouteRule["conditions"][number]): boolean {
  return c.field === "type" && c.operator === "==" && c.value === RECEIPT && !c.negate;
}

/**
 * The listener this rule is the locked receipt rule for, or null.
 *
 * <p>By shape, not by label: the rule the gateway's bootstrap writes carries no label, and it is the
 * one most installs have. Two shapes count:
 *
 * <ul>
 *   <li>`type == 18 & ingateway equals smppserver.<name>` → that listener, always;
 *   <li>`type == 18` alone → that listener, but only while it is the only listener. With a second
 *       one it takes every listener's receipts and is not anybody's rule until it is narrowed.
 * </ul>
 *
 * <p>The target may be spelled bare or in full; the gateway registers every worker under both.
 */
export function lockedReceiptListener(rule: RouteRule, listeners: readonly Listener[]): Listener | null {
  const target = rule.target.trim();
  const listener = listeners.find((l) => l.name === target || trafficKey(l) === target);
  if (!listener || rule.copied || rule.filters.length) {
    return null;
  }
  const receipts = rule.conditions.filter(isReceiptCondition);
  if (receipts.length !== 1) {
    return null;
  }
  if (rule.conditions.length === 1) {
    return listeners.length === 1 ? listener : null;
  }
  const qualifier = rule.conditions.find((c) => !isReceiptCondition(c));
  return rule.conditions.length === 2 && qualifier !== undefined && qualifier.field === "ingateway"
    && (qualifier.operator === "equals" || qualifier.operator === "==")
    && qualifier.value === trafficKey(listener) && !qualifier.negate
    ? listener
    : null;
}

export interface ReceiptReconcile {
  rules: RouteRule[];
  /** One sentence per change, for the audit line and for the caller to show. Empty: nothing to do. */
  changes: string[];
}

/**
 * The `default` table's rules with exactly one enabled receipt rule per listener.
 *
 * <p>Additive, and idempotent — run twice, the second run changes nothing:
 *
 * <ul>
 *   <li>an unqualified receipt rule is narrowed to its own listener once there are two or more,
 *       in place, keeping its id and position;
 *   <li>a listener with a locked rule that is switched off has it switched back on;
 *   <li>a listener with none gets one, qualified, placed after the last receipt rule (or first),
 *       which is where a receipt is looked for before anything that would swallow it.
 * </ul>
 *
 * <p>Nothing is removed here. A listener's rule goes when the listener does, in `deleteWorker`,
 * because only that knows the worker is gone rather than merely missing from a stale list.
 */
export function reconcileReceiptRules(
  rules: readonly RouteRule[],
  listeners: readonly Listener[]
): ReceiptReconcile {
  if (!listeners.length) {
    return { rules: [...rules], changes: [] };
  }
  //every listener, enabled or not, because a disabled one keeps its rule: enabling it must not
  //depend on somebody remembering to add one
  const narrowed = returnReceiptsPerListener(rules, listeners.map((l) => ({ ...l, enabled: true })));
  const out = [...narrowed.rules];
  const changes = [...narrowed.changes];

  for (const listener of listeners) {
    const fullName = trafficKey(listener);
    const index = out.findIndex((r) => lockedReceiptListener(r, listeners) === listener);
    if (index >= 0) {
      if (!out[index].enabled) {
        out[index] = { ...out[index], enabled: true };
        changes.push(`Switches the receipt rule for ${fullName} back on: receipts for its customers had nowhere to go.`);
      }
      continue;
    }
    const rule = buildDlrReturnRule(
      { kind: "dlr-return", workerName: listener.name, workerFullName: fullName },
      { qualify: true }
    );
    let at = 0;
    out.forEach((r, i) => {
      if (ruleDirection(r) === "receipt") {
        at = i + 1;
      }
    });
    out.splice(at, 0, rule);
    changes.push(`Adds the receipt rule for ${fullName}, so receipts for messages that arrived on it go back to it.`);
  }
  return { rules: out, changes };
}

function sameConditions(a: RouteRule, b: RouteRule): boolean {
  return JSON.stringify(a.conditions) === JSON.stringify(b.conditions);
}

/**
 * Why a save of the `default` table would break a locked receipt rule, or null when it would not.
 *
 * <p>Compared by id against the rules as stored: removing one, switching it off, or changing what it
 * matches, where it sends, or its note. Moving it is allowed — order among the receipt rules does
 * not matter, since each matches only its own listener. A rule the save leaves unchanged is fine
 * however it arrived.
 */
export function lockedRuleProblem(
  before: readonly RouteRule[],
  after: readonly RouteRule[],
  listeners: readonly Listener[]
): string | null {
  const incoming = new Map(after.filter((r) => r.id != null).map((r) => [r.id, r]));
  for (const stored of before) {
    const listener = lockedReceiptListener(stored, listeners);
    if (!listener || !stored.enabled) {
      continue;
    }
    const name = trafficKey(listener);
    const next = incoming.get(stored.id);
    if (!next) {
      return `The receipt rule for ${name} is a system rule and can't be deleted. It goes when the listener `
        + "is deleted.";
    }
    if (!next.enabled) {
      return `The receipt rule for ${name} is a system rule and can't be switched off: its customers would `
        + "get no delivery receipts.";
    }
    if (next.target.trim() !== stored.target.trim() || next.copied !== stored.copied
      || !sameConditions(next, stored) || JSON.stringify(next.filters) !== JSON.stringify(stored.filters)) {
      return `The receipt rule for ${name} is a system rule and can't be changed: a receipt has only one `
        + "place to go, the listener its message arrived on.";
    }
    if ((next.label?.trim() || null) !== (stored.label?.trim() || null)) {
      return `The receipt rule for ${name} is a system rule, so its note can't be changed.`;
    }
  }
  return null;
}
