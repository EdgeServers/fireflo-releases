import { test } from "node:test";
import assert from "node:assert/strict";
import {
  BUILTIN_REGISTRY, registryFrom, isSecretWorkerKey, rowFromRecord, statusOf, statusVerdict, type ConfigKeyRow,
} from "./config-key-registry.ts";
import { GATEWAY_SETTING_FIELDS } from "./gateway-setting-fields.ts";
import { SETTING_FIELDS } from "./setting-fields.ts";
import { judgeGatewayKey, isReadable, denialMessage } from "./gateway-key-policy.ts";

test("every catalogued key is in the registry, with the catalogue's kind, choices and default", () => {
  for (const f of GATEWAY_SETTING_FIELDS) {
    const row = BUILTIN_REGISTRY.platform.get(f.key);
    assert.ok(row, `${f.key} is catalogued but not in the registry`);
    assert.equal(row.kind, f.widget.kind, f.key);
    assert.equal(row.codedDefault, f.codedDefault, f.key);
    if (f.widget.kind === "enum") {
      assert.deepEqual(row.choices, f.widget.options.map((o) => o.value), f.key);
    }
  }
  for (const [key, f] of Object.entries(SETTING_FIELDS)) {
    const row = BUILTIN_REGISTRY.worker.get(key);
    assert.ok(row, `${key} is catalogued but not in the registry`);
    assert.equal(row.kind, f.widget.kind, key);
    assert.equal(row.secret, f.widget.kind === "secret", key);
  }
});

test("the usage summary keys (gateway V1.91.0) are catalogued, editable, with the gateway's defaults", () => {
  const expected: Record<string, string> = {
    "smsg.usage.hourly.enabled": "true",
    "smsg.usage.hourly.interval.seconds": "60",
    "smsg.usage.hourly.lag.seconds": "30",
    "smsg.usage.hourly.restate.minutes": "15",
    "smsg.usage.hourly.retention.days": "35",
    "smsg.usage.daily.schedule": "00:15",
  };
  for (const [key, dflt] of Object.entries(expected)) {
    const row = BUILTIN_REGISTRY.platform.get(key);
    assert.ok(row, key);
    assert.equal(row.codedDefault, dflt, key);
    assert.equal(row.access, "editable", key);
    assert.equal(row.secret, false, key);
    assert.equal(judgeGatewayKey(key).allowed, true, key);
  }
  assert.equal(BUILTIN_REGISTRY.platform.get("smsg.usage.hourly.enabled")?.kind, "boolean");
  assert.equal(BUILTIN_REGISTRY.platform.get("smsg.usage.hourly.interval.seconds")?.unit, "s");
  assert.equal(BUILTIN_REGISTRY.platform.get("smsg.usage.hourly.restate.minutes")?.unit, "min");
});

test("smsg.cdr.body (gateway V1.92.0) is an editable enum, off by default, with the gateway's three values", () => {
  const row = BUILTIN_REGISTRY.platform.get("smsg.cdr.body");
  assert.ok(row);
  assert.equal(row.kind, "enum");
  assert.deepEqual([...(row.choices ?? [])], ["off", "excerpt", "full"]);
  assert.equal(row.codedDefault, "off");
  assert.equal(row.access, "editable");
  assert.equal(judgeGatewayKey("smsg.cdr.body").allowed, true);
});

test("smsg.queue.archive.retention.days (gateway V1.93.0) is an editable number, 0 = never deleted automatically", () => {
  const row = BUILTIN_REGISTRY.platform.get("smsg.queue.archive.retention.days");
  assert.ok(row);
  assert.equal(row.kind, "number");
  assert.equal(row.codedDefault, "0");
  assert.equal(row.access, "editable");
  assert.equal(row.secret, false);
  assert.equal(judgeGatewayKey("smsg.queue.archive.retention.days").allowed, true);
});

test("dest.addr.convert and dest.addr.country (gateway V1.94.0) are editable vendor keys, conversion off by default", () => {
  const convert = BUILTIN_REGISTRY.worker.get("dest.addr.convert");
  assert.ok(convert);
  assert.equal(convert.kind, "boolean");
  assert.equal(convert.codedDefault, "false");
  assert.equal(convert.access, "editable");
  const country = BUILTIN_REGISTRY.worker.get("dest.addr.country");
  assert.ok(country);
  assert.equal(country.kind, "text");
  assert.equal(country.codedDefault, "");
  assert.equal(country.access, "editable");
});

test("the registry keeps app_config_key's own rules: a secret is hidden, a denial has a reason", () => {
  for (const r of BUILTIN_REGISTRY.rows) {
    if (r.secret) assert.equal(r.access, "hidden", `${r.scope}:${r.key}`);
    assert.equal(r.access === "editable", r.reason === null, `${r.scope}:${r.key}`);
    assert.equal(r.kind === "enum", r.choices !== null, `${r.scope}:${r.key}`);
  }
});

test("the built-in registry reproduces the denials the code used to hold", () => {
  assert.deepEqual(judgeGatewayKey("smsg.queue.amqp.uri"), { allowed: false, reason: "secret" });
  assert.deepEqual(judgeGatewayKey("smsg.cdr.sink"), { allowed: false, reason: "wiring" });
  assert.deepEqual(judgeGatewayKey("smsg.billing.zone"), { allowed: false, reason: "elsewhere" });
  assert.equal(judgeGatewayKey("smsg.whitelist.enabled").allowed, true);
  assert.equal(isSecretWorkerKey(BUILTIN_REGISTRY, "password"), true);
  assert.equal(isSecretWorkerKey(BUILTIN_REGISTRY, "host"), false);
});

test("a registry read from the database decides, beyond what the code knew", () => {
  //a key whose name says nothing, made a secret by the table -- the case the table exists for
  const extra: ConfigKeyRow = {
    scope: "platform", key: "smsg.partner.endpoint", kind: "text", choices: null, unit: null,
    codedDefault: null, secret: true, access: "hidden", reason: "secret", label: "Partner endpoint",
    status: "current", replacedBy: null,
  };
  const worker: ConfigKeyRow = {
    scope: "worker", key: "bind.code", kind: "secret", choices: null, unit: null,
    codedDefault: null, secret: true, access: "hidden", reason: "secret", label: "Bind code",
    status: "current", replacedBy: null,
  };
  const db = registryFrom([...BUILTIN_REGISTRY.rows, extra, worker], "database");

  assert.equal(judgeGatewayKey("smsg.partner.endpoint").allowed, true, "the code alone allows it");
  assert.deepEqual(judgeGatewayKey("smsg.partner.endpoint", db), { allowed: false, reason: "secret" });
  assert.equal(isReadable("smsg.partner.endpoint", db), false, "a secret is not shown");
  //a worker secret is a secret as a gateway-wide default too
  assert.deepEqual(judgeGatewayKey("outSms.default.bind.code", db), { allowed: false, reason: "secret" });
  assert.equal(isSecretWorkerKey(db, "bind.code"), true);
});

test("the name rule still decides for a key no registry lists", () => {
  const empty = registryFrom([], "database");
  assert.deepEqual(judgeGatewayKey("smsg.vendor.api_key", empty), { allowed: false, reason: "secret" });
});

test("a row from a table older than V1.88.0 reads as current, and one from a newer table keeps its status", () => {
  const base = {
    scope: "worker", key: "srv.host", kind: "text", choices: null, unit: null, coded_default: null,
    secret: false, access: "read-only", reason: "retired", label: "Listener bind address",
  };
  //no status or replaced_by column at all: the older table
  const older = rowFromRecord(base);
  assert.equal(older.status, "current");
  assert.equal(older.replacedBy, null);
  assert.equal(older.key, "srv.host");
  assert.equal(older.codedDefault, null);
  assert.equal(older.secret, false);

  const newer = rowFromRecord({ ...base, status: "retired", replaced_by: null });
  assert.equal(newer.status, "retired");
  const deprecated = rowFromRecord({
    ...base, key: "whitelist.tlvs.replace", access: "editable", reason: null,
    status: "deprecated", replaced_by: "whitelist.tlvs.mode",
  });
  assert.equal(deprecated.status, "deprecated");
  assert.equal(deprecated.replacedBy, "whitelist.tlvs.mode");
  //a value the panel does not know is read as current rather than trusted
  assert.equal(rowFromRecord({ ...base, status: "sunset" }).status, "current");
  assert.equal(rowFromRecord({ ...base, replaced_by: "  " }).replacedBy, null);
});

test("status decides the verdict: retired is shown and not edited, deprecated names its successor", () => {
  const retired = statusVerdict({ status: "retired", replacedBy: null });
  assert.equal(retired.editable, false);
  assert.equal(retired.notice, "Retired — has no effect");
  const retiredFor = statusVerdict({ status: "retired", replacedBy: "srv.new" });
  assert.match(retiredFor.notice ?? "", /^Retired — has no effect\. Use srv\.new\.$/);

  const deprecated = statusVerdict({ status: "deprecated", replacedBy: "whitelist.tlvs.mode" });
  assert.equal(deprecated.editable, true, "a deprecated key still works, so it stays editable");
  assert.equal(deprecated.notice, "Deprecated: use whitelist.tlvs.mode");
  assert.equal(statusVerdict({ status: "deprecated", replacedBy: null }).notice, "Deprecated");

  const current = statusVerdict({ status: "current", replacedBy: null });
  assert.equal(current.editable, true);
  assert.equal(current.notice, null, "a current key says nothing");
});

test("statusOf answers by scope, by bare key or by its outSms.default. form, and current for a stranger", () => {
  assert.equal(statusOf(BUILTIN_REGISTRY, "worker", "srv.host").status, "retired");
  assert.equal(statusOf(BUILTIN_REGISTRY, "worker", "outSms.default.srv.host").status, "retired");
  assert.equal(statusOf(BUILTIN_REGISTRY, "worker", "whitelist.tlvs.replace").replacedBy, "whitelist.tlvs.mode");
  assert.equal(statusOf(BUILTIN_REGISTRY, "worker", "srv.port").status, "current");
  assert.equal(statusOf(BUILTIN_REGISTRY, "platform", "srv.host").status, "current", "scope matters");
  assert.equal(statusOf(BUILTIN_REGISTRY, "platform", "smsg.nobody.knows").notice, null);
});

test("a retired key is refused for writing, under either name, with a sentence that says why", () => {
  assert.deepEqual(judgeGatewayKey("outSms.default.srv.host"), { allowed: false, reason: "retired" });
  assert.equal(isReadable("outSms.default.srv.host"), true, "shown greyed, not withheld");
  //a platform key retired by the table, which no code list knows about
  const retiredPlatform: ConfigKeyRow = {
    scope: "platform", key: "smsg.old.switch", kind: "boolean", choices: null, unit: null,
    codedDefault: null, secret: false, access: "read-only", reason: "retired", label: "Old switch",
    status: "retired", replacedBy: "smsg.new.switch",
  };
  const db = registryFrom([...BUILTIN_REGISTRY.rows, retiredPlatform], "database");
  assert.deepEqual(judgeGatewayKey("smsg.old.switch", db), { allowed: false, reason: "retired" });
  assert.equal(judgeGatewayKey("smsg.old.switch").allowed, true, "the code alone allows it");
  assert.match(denialMessage("smsg.old.switch", "retired"), /retired/);
  assert.match(denialMessage("smsg.old.switch", "retired"), /no effect/);
});
