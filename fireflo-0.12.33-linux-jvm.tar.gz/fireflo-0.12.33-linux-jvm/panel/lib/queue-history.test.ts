import { strict as assert } from "node:assert";
import { test } from "node:test";
import { appendQueue, QUEUE_HISTORY_MS, type QueueHistory } from "./queue-history.ts";
import type { Health, HealthWorker } from "./health-types.ts";

function snapshot(workers: Partial<HealthWorker>[]): Health {
  return {
    observed_at: "t",
    router_queue: 0,
    awaiting_receipt: 0,
    dlr_store_persistent: false,
    cdr: { enabled: false },
    workers: workers.map((w) => ({
      name: "smppclient.v1", type: "smppclient", accepting: true, paused: false,
      suspended_manually: false, suspended_automatically: false, queue_depth: 0, retry_queue_depth: 0, ...w,
    })),
  } as Health;
}

test("a sample counts waiting and scheduled retries together, per worker", () => {
  const history = appendQueue([], snapshot([
    { name: "smppclient.v1", queue_depth: 40, retry_queue_depth: 2 },
    { name: "smppserver.s1", queue_depth: 3 },
  ]), 1_000);
  assert.deepEqual(history, [{ t: 1_000, depth: { "smppclient.v1": 42, "smppserver.s1": 3 } }]);
});

test("samples older than the window are dropped, so a tab left open stays bounded", () => {
  let history: QueueHistory = [];
  history = appendQueue(history, snapshot([{ queue_depth: 1 }]), 0);
  history = appendQueue(history, snapshot([{ queue_depth: 2 }]), QUEUE_HISTORY_MS / 2);
  history = appendQueue(history, snapshot([{ queue_depth: 3 }]), QUEUE_HISTORY_MS + 1);
  assert.deepEqual(history.map((s) => s.depth["smppclient.v1"]), [2, 3]);
});
