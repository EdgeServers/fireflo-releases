import { isRoutingCatchAll, missingDlrReturnRules, routeTableWarnings, targetKind } from "./routing-types.ts";
import type { RouteTable, TargetWorker } from "./routing-types.ts";
import { reasonHint, reasonLabel, refusedAfterAccepting } from "./rejected-types.ts";
import type { RejectedSummary } from "./rejected-types.ts";
import { effectiveMode, enforcementReadiness } from "./whitelist-types.ts";
import type { WhitelistSummary } from "./whitelist-types.ts";

/**
 * Why messages are not being delivered, answered in the order the gateway asks the questions.
 *
 * <h2>Why this is not a routing checker</h2>
 *
 * <p>The reported symptom is almost always "routing failed", and on the deployment this was written
 * against routing had **never** failed once: every message was dying on a whitelist refusal or an
 * empty balance, both of which happen long before a route table is consulted. A routing-only tool
 * would have answered "routing is healthy" during the exact outage that prompted it, and sent
 * somebody to edit the one part of the configuration that was already correct.
 *
 * <p>So the walk is bind → whitelist → TLVs → rating → credit → routing → vendor, and **evidence
 * comes before opinion**: what `cdr_rejected` actually recorded is reported before anything this
 * module deduces from configuration. A refusal that happened outranks a refusal that might.
 *
 * <h2>What it deliberately will not do</h2>
 *
 * <p>It does not evaluate a route condition against real traffic. That needs the message, and a
 * guess would be confident and wrong. It reports rules that **cannot** match — a regex handed to a
 * literal operator, a positive operator against a field the message does not carry — and stops.
 *
 * <p>It is a report, never a guard. Nothing here refuses a save.
 */

/** Where in the path a finding sits. The order of this union is the order of the walk. */
export type Stage =
  | "config"
  | "evidence"
  | "whitelist"
  | "tlv"
  | "rating"
  | "credit"
  | "routing"
  | "vendor";

/**
 * How much this is costing right now.
 *
 * <p>Three, not five. `stopping` means traffic is not flowing because of this; `degrading` means
 * some of it is; `latent` means nothing is wrong today and something will be. The distinction that
 * matters is the first one — an operator in an incident needs the subset they can act on now.
 */
export type Severity = "stopping" | "degrading" | "latent";

const SEVERITY_RANK: Record<Severity, number> = { stopping: 0, degrading: 1, latent: 2 };

export const SEVERITY_LABEL: Record<Severity, string> = {
  stopping: "Stopping messages",
  degrading: "Stopping some messages",
  latent: "Not biting yet",
};

/**
 * A fix this report is willing to apply itself, once confirmed.
 *
 * <p>Four, and the shortness of the list is the point. Each is a change whose correct form is
 * unambiguous *given the finding* — a reorder, a boolean, an enum. Everything else this report can
 * see needs a judgement it does not have: which registrations to approve, how much credit to add,
 * what a rate should be. Those get a link and a sentence.
 */
export type ApplyAction =
  | { kind: "moveCatchAllLast"; table: string }
  | { kind: "addCatchAll"; table: string }
  | { kind: "enableWorker"; worker: string }
  | { kind: "reportMode"; accountId: string; product: string; which: "header" | "content" }
  //the DLR-return rule's correct form has no free choice at all -- see buildDlrReturnRule -- so
  //this needs only which listener, unlike addCatchAll which still needs a target from the operator.
  //Both fields rather than just the full name so the route never has to parse `smppserver.smpp`
  //back apart to build the rule's label
  | { kind: "addSystemReturnRule"; workerName: string; workerFullName: string }
  //the one action that writes more than a single rule. Both targets are free choices the operator
  //makes in the dialog -- a receipt has one correct listener, but where ordinary outbound traffic
  //chains to and which listener owns inbound MOs are business decisions no finding can derive
  | { kind: "recreateDefaultRouting"; mtTarget: string; moTarget: string };

export interface Finding {
  /** Stable across runs, so React keys and the apply handler agree on what this is. */
  key: string;
  stage: Stage;
  severity: Severity;
  /** One line. What is wrong. */
  headline: string;
  /** What refuses, and what is missing. */
  detail: string;
  /** The imperative. What to go and do. */
  fix: string;
  /**
   * Why this was judged the way it was.
   *
   * <p>Published for the reason `runtime-verdicts` publishes its thresholds: a verdict whose rule is
   * hidden is a colour rather than a judgement, and cannot be argued with by somebody who knows
   * more about this deployment than the panel does.
   */
  rule: string;
  /** Present only when `cdr_rejected` or live health actually observed this. */
  evidence?: string;
  /** Deep link to the form that fixes it. */
  href?: string;
  apply?: ApplyAction;
}

/** A worker as the diagnosis needs it: stored intent plus, where known, what the gateway reports. */
export interface WorkerState extends TargetWorker {
  /**
   * Live session count, or **undefined for "could not ask"**.
   *
   * <p>Not `0`. The whole reason this is a separate value is that an unreadable `/ops/health` and a
   * vendor with no sessions are different facts, and collapsing them makes the report claim an
   * outage whenever the ops token is wrong.
   */
  bound?: number;
}

export interface RefusalWindow {
  summary: readonly RejectedSummary[];
  /** Every refusal in the window, across all reasons. */
  total: number;
  /**
   * How many recent refusals these counts were taken over, when they are a sample.
   *
   * <p>Undefined means the counts cover the whole window and `total` is a true total. A number
   * means the aggregate was capped at the most recent N refusals, because counting the window
   * outright reads the table once it grows — and the sentence explaining the finding must say so.
   * A sampled number presented as a total is worse than no number.
   */
  sampledOver?: number;
  /**
   * Messages ACCEPTED in the same window, when it could be counted.
   *
   * <p>The severity share is against this, not against `total`. Share-of-refusals is meaningless —
   * a deployment with one failure mode always has one reason at 100% of its refusals, so every
   * platform with three throttled messages would report an outage. Share of traffic is the question
   * actually being asked: how much of what people tried to send did not go.
   */
  submitted?: number;
  hours: number;
}

/** Everything the route gathered. Plain data, so this module needs no database and no network. */
export interface DiagnosisInput {
  /** Set when checking one customer rather than the platform. */
  accountId: string | null;
  /**
   * `undefined` on any domain means the gateway could not be asked — never assume `true`.
   * `false` means it is reading that domain from a file, so the panel is describing something the
   * gateway is not using.
   */
  readsFromDatabase: { routing?: boolean; credentials?: boolean; rates?: boolean; workers?: boolean };
  /** Why live state is missing, when it is. */
  healthUnavailable?: "not-configured" | "unreachable" | "refused";
  refusals?: RefusalWindow;
  routing?: { tables: readonly RouteTable[] };
  workers?: readonly WorkerState[];
  /** Named filters, so a rule referencing a dead one can be reported as skipped. */
  filters?: readonly { name: string; enabled: boolean; conditionCount: number }[];
  whitelist?: {
    summaries: readonly WhitelistSummary[];
    exemptProducts: readonly string[];
    /** Accounts to judge. Platform-wide this is every account carrying a policy. */
    accounts: readonly { accountId: string; product: string }[];
  };
  /** Pre-rendered by the caller with `tlvGapSentence`, so this module needs no TLV parser. */
  tlvGaps?: readonly { accountId: string; sentence: string }[];
  /** Products with no enabled sell-side rule that would price them. */
  unratedProducts?: readonly { product: string; scope: string }[];
  /** Set only where a balance is actually being enforced. */
  credit?: readonly { accountId: string; balance: number; currency: string }[];
}

/**
 * A reason is called `stopping` at either of these, and the threshold is published on screen.
 *
 * <p>Without one, three throttled messages on a healthy platform render the same red as a total
 * outage, and the report becomes something people close. With one, the rule is arguable — which is
 * the intent.
 */
const STOPPING_SHARE = 0.1;
const STOPPING_COUNT = 100;

export function diagnose(input: DiagnosisInput): Finding[] {
  const findings: Finding[] = [];

  //config first, because everything after it is conditional on the panel describing what is running
  configFindings(input, findings);
  //then evidence, before any opinion derived from configuration
  evidenceFindings(input, findings);
  whitelistFindings(input, findings);
  tlvFindings(input, findings);
  ratingFindings(input, findings);
  creditFindings(input, findings);
  routingFindings(input, findings);

  //stable sort, so the build order above survives within a severity: that is what puts an observed
  //refusal above a deduced one without needing a second sort key
  return [...findings].sort((a, b) => SEVERITY_RANK[a.severity] - SEVERITY_RANK[b.severity]);
}

/**
 * One sentence for the top of the report, or null when there is nothing to say.
 *
 * <p>Null rather than "0 problems found": a report that renders on a healthy deployment is one
 * people learn to scroll past, which is the same argument `product-readiness` makes.
 */
export function diagnosisSummary(findings: readonly Finding[]): string | null {
  if (!findings.length) {
    return null;
  }
  const stopping = findings.filter((f) => f.severity === "stopping").length;
  const rest = findings.length - stopping;
  if (!stopping) {
    return `${count(rest, "thing")} worth fixing, none of it stopping messages right now.`;
  }
  const tail = rest ? `, and ${count(rest, "other thing")} worth fixing` : "";
  return `${count(stopping, "thing")} stopping messages${tail}.`;
}

function configFindings(input: DiagnosisInput, out: Finding[]): void {
  const fileMode = Object.entries(input.readsFromDatabase)
    .filter(([, live]) => live === false)
    .map(([domain]) => domain);

  if (fileMode.length) {
    out.push({
      key: "config:file-mode",
      stage: "config",
      severity: "stopping",
      headline: "The gateway is not reading this configuration.",
      detail:
        `It is reading ${list(fileMode)} from files rather than the database, so what this panel `
        + "shows is stored, valid and ignored. Everything below describes a configuration that is "
        + "not in force.",
      fix:
        "Compare the files against these tables before restarting with FIREFLO_CONFIG_SOURCE=db — "
        + "one switch moves all four domains together.",
      rule: "Reported by the gateway itself on /ops/health, not inferred.",
      href: "/cp/health",
    });
  }

  if (input.healthUnavailable) {
    const why = {
      "not-configured": "GATEWAY_OPS_URL and GATEWAY_OPS_TOKEN are not both set",
      unreachable: "the gateway did not answer",
      refused: "the gateway answered 404 — the token may be wrong, or the ops endpoint switched off",
    }[input.healthUnavailable];
    out.push({
      key: "config:health-unavailable",
      stage: "config",
      severity: "latent",
      headline: "This check ran partly blind.",
      detail:
        `Live state could not be read: ${why}. Nothing below reports whether a vendor is actually `
        + "connected, because not knowing and not being connected are different facts and only one "
        + "of them is an outage.",
      fix: "Set the ops URL and read token in panel.env to get the rest of this check.",
      rule: "No finding that depends on live state is emitted while this is true.",
      href: "/cp/health",
    });
  }
}

function evidenceFindings(input: DiagnosisInput, out: Finding[]): void {
  const window = input.refusals;
  if (!window || !window.summary.length) {
    return;
  }
  for (const row of window.summary) {
    //share of ATTEMPTED traffic, and only when that was countable. Falling back to the absolute
    //count rather than to a share of refusals, which would call every single-cause deployment an
    //outage regardless of size
    const attempted = window.submitted == null ? null : window.submitted + window.total;
    const share = attempted ? row.count / attempted : null;
    const severity: Severity =
      row.count >= STOPPING_COUNT || (share != null && share >= STOPPING_SHARE)
        ? "stopping"
        : "degrading";
    const hint = reasonHint(row.reason);
    out.push({
      key: `evidence:${row.reason}`,
      stage: "evidence",
      severity,
      headline: `${reasonLabel(row.reason)} — ${count(row.count, "message")} refused.`,
      detail:
        (hint ?? "The gateway refused these and recorded the reason.")
        + (refusedAfterAccepting(row.reason)
          ? " These were accepted first, so the customer already had a success back for them and "
            + "only ever learns from a delivery receipt."
          : ""),
      fix: fixFor(row.reason),
      rule:
        (window.sampledOver
          ? `Counted from the most recent ${window.sampledOver.toLocaleString()} refusals in the `
            + `last ${window.hours} hours -- a sample, so these are not totals. `
          : `Counted from cdr_rejected over the last ${window.hours} hours. `)
        + `A reason is called `
        + `stopping at ${STOPPING_COUNT} messages`
        + (attempted
          ? `, or ${Math.round(STOPPING_SHARE * 100)}% of everything attempted, whichever comes `
            + "first."
          : ". Accepted traffic could not be counted, so only the absolute number was used."),
      evidence: attempted
        ? `${count(row.count, "message")} of ${attempted.toLocaleString()} attempted.`
        : `${count(row.count, "message")} of ${window.total.toLocaleString()} refused.`,
      href: `/cp/rejected?reason=${encodeURIComponent(row.reason)}`,
    });
  }
}

/** What to do about a refusal, which is not the same as what the refusal means. */
function fixFor(reason: string): string {
  switch (reason) {
    case "headerNotApproved":
      return "Approve the sender ID on the account, or set that account to REPORT while you sort it "
        + "out — REPORT logs what it would refuse and refuses nothing.";
    case "templateNotMatched":
      return "Approve the wording the customer is actually sending. A single changed word is a "
        + "different template.";
    case "insufficientCredit":
      return "Top the account up, or switch prepaid credit off for it.";
    case "missingMandatoryTlv":
      return "Supply the tag: as a stamp on the approved registration, as a credential default, or "
        + "by having the customer send it.";
    case "maxAttempts":
      return "This one IS routing: no enabled rule produced a usable target. Check the default "
        + "table has a catch-all last and that its target is bound.";
    case "filtered":
      return "A routing filter dropped these deliberately. Check the filter is doing what you think.";
    case "unrated":
      return "Add a sell-side rate rule for that account and product, or turn "
        + "smsg.rating.unrated.refuse off.";
    case "productNotSold":
      return "Enable the product in the catalogue, or correct the product on the login.";
    case "rateLimited":
      return "Raise smsg.restapi.maxRate for the account, or ask the customer to slow down.";
    case "vendorRejected":
      return "The carrier refused these, not the gateway. The code on each row is their reason -- "
        + "192 to 196 are always about TLVs, and on a DLT lane that is usually a missing or "
        + "unstamped entity or template id.";
    case "productNotAllowed":
      return "Either omit the product field so the login uses the one it carries, or add it under "
        + "'Products it may name on a send' on that credential.";
    case "queueFull":
      return "The router queue hit its capacity. Raise smsg.queue.capacity, or find why it is not "
        + "draining -- usually a vendor that has stopped accepting.";
    case "submitFailed":
      return "Accepted by every check and then not handed on. Check the broker, and the router "
        + "queue depth on the dashboard.";
    default:
      return "Open the Refused page for the detail recorded against each message.";
  }
}

function whitelistFindings(input: DiagnosisInput, out: Finding[]): void {
  const wl = input.whitelist;
  if (!wl) {
    return;
  }
  for (const { accountId, product } of wl.accounts) {
    if (input.accountId && accountId !== input.accountId) {
      continue;
    }
    for (const kind of ["header", "content"] as const) {
      const mode = effectiveMode(wl.summaries, accountId, product, kind);
      if (mode !== "ENFORCE") {
        continue;
      }
      const readiness = enforcementReadiness(
        wl.summaries, accountId, product, kind, mode, wl.exemptProducts);
      if (!readiness.refuse) {
        continue;
      }
      out.push({
        key: `whitelist:${accountId}:${product}:${kind}`,
        stage: "whitelist",
        severity: "stopping",
        headline: `${accountId} is enforcing ${kind === "header" ? "sender IDs" : "content"} with `
          + "nothing approved.",
        detail: readiness.refuse,
        fix:
          "Approve at least one, or set this back to REPORT — which logs what it would refuse and "
          + "refuses nothing, so traffic flows while you work through the list.",
        rule:
          "Counted the way the gateway merges: an account-wide list applies to every product, and "
          + "approvals filed under an exempt product protect nothing.",
        href: `/cp/accounts/${encodeURIComponent(accountId)}`,
        apply: { kind: "reportMode", accountId, product, which: kind },
      });
    }
  }
}

function tlvFindings(input: DiagnosisInput, out: Finding[]): void {
  for (const gap of input.tlvGaps ?? []) {
    if (input.accountId && gap.accountId !== input.accountId) {
      continue;
    }
    out.push({
      key: `tlv:${gap.accountId}:${gap.sentence.slice(0, 40)}`,
      stage: "tlv",
      severity: "stopping",
      headline: `${gap.accountId} will be refused for a missing TLV.`,
      detail: gap.sentence,
      fix: "Stamp the tag on the registration, or set it as a credential default on the login.",
      rule:
        "A listener declares mandatory.tlvs.submit; this checks what the approved rows and the "
        + "account's logins supply. It cannot see what a client sends for itself.",
      href: `/cp/accounts/${encodeURIComponent(gap.accountId)}`,
    });
  }
}

function ratingFindings(input: DiagnosisInput, out: Finding[]): void {
  for (const row of input.unratedProducts ?? []) {
    if (input.accountId && row.scope !== input.accountId) {
      continue;
    }
    out.push({
      key: `rating:${row.scope}:${row.product}`,
      stage: "rating",
      severity: "latent",
      headline: `${row.product} has no enabled price for ${row.scope}.`,
      detail:
        "Messages on it match no sell-side rate rule, so today they are sent and charged nothing. "
        + "With smsg.rating.unrated.refuse switched on they are refused outright instead.",
      fix: `Add a rate rule for ${row.scope} on ${row.product}, or one on the default scope.`,
      rule:
        "The four places a customer price can come from, the way RateSnapshot.rulesForPrice reads "
        + "them: this account's rules for the product, its rules for any product, and the same two "
        + "on the default scope '*'. Zero enabled rules across all four is unrated. A rule carrying "
        + "conditions or filters counts as covered here, because whether it matches depends on the "
        + "message — so this reports a price that cannot exist, not one that might not apply.",
      //both, so the pricing page opens the form on the pair this is about rather than on the scope
      //and leaving the product to be re-chosen
      href: `/cp/pricing?scope=${encodeURIComponent(row.scope)}`
        + `&product=${encodeURIComponent(row.product)}`,
    });
  }
}

function creditFindings(input: DiagnosisInput, out: Finding[]): void {
  for (const row of input.credit ?? []) {
    if (input.accountId && row.accountId !== input.accountId) {
      continue;
    }
    if (row.balance > 0) {
      continue;
    }
    out.push({
      key: `credit:${row.accountId}`,
      stage: "credit",
      severity: "stopping",
      headline: `${row.accountId} has no credit left.`,
      detail:
        "Prepaid credit is enforced and this balance is at zero, so every message from this "
        + "account is refused with 0x402 until it is topped up.",
      fix: "Add credit on the account page.",
      rule: "Balance at or below zero while prepaid credit is being enforced.",
      href: `/cp/accounts/${encodeURIComponent(row.accountId)}`,
    });
  }
}

function routingFindings(input: DiagnosisInput, out: Finding[]): void {
  const tables = input.routing?.tables;
  if (!tables) {
    return;
  }
  const names = tables.map((t) => t.name);
  const workers = input.workers ?? [];
  const deadFilters = new Set(
    (input.filters ?? [])
      .filter((f) => !f.enabled || f.conditionCount === 0)
      .map((f) => f.name)
  );

  //cross-table, not per-table: the gap this reports is "no rule anywhere returns this listener's
  //receipts", which no single table's own warnings can see. Same detection the routing page's
  //Default routing section uses, so a message trace and the page it links to never disagree
  //WorkerState.type is a bare string (this module has no reason to import WorkerType just to
  //narrow it), so the servers list is rebuilt rather than filtered in place
  const servers = workers
    .filter((w) => w.type === "smppserver")
    .map((w) => ({ name: w.name, type: "smppserver" as const }));
  for (const gap of missingDlrReturnRules(tables, servers)) {
    out.push({
      key: `routing:dlr-return:${gap.workerFullName}`,
      stage: "routing",
      severity: "stopping",
      headline: `Delivery receipts on ${gap.workerFullName} have no way back.`,
      detail:
        `A receipt for a message accepted on ${gap.workerFullName} is routed like any other `
        + "message, and no enabled rule sends type == 18 back to this listener. It burns twenty "
        + "routing attempts and is dropped — the customer is charged, delivered, and never told, "
        + "because the failure happens after the vendor already confirmed the message.",
      fix: "Add the return rule from the Default routing section on the routing page.",
      rule: "Every configured SMPP listener needs an enabled rule sending type == 18 to itself.",
      href: "/cp/routing",
      apply: { kind: "addSystemReturnRule", workerName: gap.workerName, workerFullName: gap.workerFullName },
    });
  }

  for (const table of tables) {
    if (!table.enabled) {
      continue;
    }
    const live = table.rules.filter((r) => r.enabled);
    const catchAllAt = live.findIndex(isRoutingCatchAll);
    const stopsAt = live.findIndex((r) => isRoutingCatchAll(r) && !r.copied);

    if (table.targetFunction === "NORMAL" && live.length && catchAllAt < 0) {
      out.push({
        key: `routing:${table.name}:no-catch-all`,
        stage: "routing",
        severity: "stopping",
        headline: `'${table.name}' has no catch-all.`,
        detail:
          "Every rule here is narrowed, so a message matching none of them has nowhere to go. It is "
          + "not refused and not logged at submit — it is retried 20 times and dropped, with the "
          + "customer already holding a success for it.",
        fix: "Add a rule with no conditions and no filters, last, pointing at a bound vendor.",
        rule: "A NORMAL table stops at the first match. Filters count as narrowing.",
        href: "/cp/routing",
        apply: { kind: "addCatchAll", table: table.name },
      });
    }

    if (table.targetFunction === "NORMAL" && stopsAt >= 0 && stopsAt < live.length - 1) {
      const dead = live.length - stopsAt - 1;
      out.push({
        key: `routing:${table.name}:catch-all-early`,
        stage: "routing",
        severity: "degrading",
        headline: `'${table.name}' has a catch-all above other rules.`,
        detail:
          `Rule ${stopsAt + 1} matches everything and stops the scan, so the ${count(dead, "rule")} `
          + "below it can never be reached. Traffic those rules were written for is going to the "
          + "catch-all's target instead — which delivers, and to the wrong place.",
        fix: "Move it last.",
        rule: "First match wins in a NORMAL table. A copy-and-continue rule is exempt.",
        href: "/cp/routing",
        apply: { kind: "moveCatchAllLast", table: table.name },
      });
    }

    for (const rule of live) {
      const skipped = rule.filters.filter((f) => deadFilters.has(f));
      if (skipped.length) {
        out.push({
          key: `routing:${table.name}:${rule.id ?? rule.target}:dead-filter`,
          stage: "routing",
          severity: "stopping",
          headline: `A rule in '${table.name}' is skipped entirely.`,
          detail:
            `It references ${list(skipped)}, which ${skipped.length === 1 ? "is" : "are"} disabled `
            + "or carries no conditions. The gateway skips the whole rule rather than loading it "
            + "with fewer conditions, because dropping conditions would make it match more.",
          fix:
            "Re-enable the filter, or give it conditions — but check what else uses it first, "
            + "because one filter serves routing and pricing at once.",
          rule: "A filter with no conditions is treated as disabled at load.",
          href: "/cp/filters",
        });
      }

      const kind = targetKind(rule.target, names, workers);
      if (kind === "unknown") {
        out.push({
          key: `routing:${table.name}:${rule.target}:unknown`,
          stage: "vendor",
          severity: "degrading",
          headline: `'${rule.target}' is not a table or a worker.`,
          detail:
            `A rule in '${table.name}' sends there. Unless it is one this panel cannot see, the `
            + "gateway skips the rule and it sends nothing.",
          fix: "Correct the target, or remove the rule.",
          rule: "Matched against this panel's routing tables and app_worker, both name forms.",
          href: "/cp/routing",
        });
        continue;
      }
      if (kind === "disabled") {
        out.push({
          key: `routing:${table.name}:${rule.target}:disabled`,
          stage: "vendor",
          severity: "stopping",
          headline: `'${rule.target}' is switched off.`,
          detail:
            `A rule in '${table.name}' sends there, and the gateway never registers a disabled `
            + "worker. Unlike an unrecognised name this is certain — the row is right there with "
            + "enabled = false.",
          fix: `Switch ${rule.target} back on.`,
          rule: "app_worker.enabled is false for this target.",
          href: "/cp/vendors",
          apply: { kind: "enableWorker", worker: rule.target },
        });
        continue;
      }

      //live state only, and only when it was actually readable
      const worker = workers.find(
        (w) => w.name === rule.target || `${w.type}.${w.name}` === rule.target);
      if (kind === "worker" && worker && worker.bound === 0) {
        out.push({
          key: `routing:${table.name}:${rule.target}:not-bound`,
          stage: "vendor",
          severity: "stopping",
          headline: `'${rule.target}' is enabled but not connected.`,
          detail:
            `A rule in '${table.name}' sends there and it currently holds no sessions, so nothing `
            + "routed to it can leave.",
          fix: "Check the vendor's host, port and credentials, then use Test connection.",
          rule: "Session count from the gateway's own /ops/health, not inferred from silence.",
          evidence: "0 sessions bound.",
          href: "/cp/vendors",
        });
      }
    }

    //everything else the editor already knows how to say, taken verbatim rather than reworded
    for (const warning of routeTableWarnings(table, names, workers)) {
      if (isCoveredAbove(warning)) {
        continue;
      }
      out.push({
        key: `routing:${table.name}:${warning.slice(0, 40)}`,
        stage: "routing",
        severity: "latent",
        headline: `'${table.name}' has a rule that cannot do what it looks like it does.`,
        detail: warning,
        fix: "Open the table and correct the rule.",
        rule: "The same check the routing editor makes when you open the table.",
        href: "/cp/routing",
      });
    }
  }
}

/** The four warnings this module already reports with more context of its own. */
function isCoveredAbove(warning: string): boolean {
  return warning.includes("No catch-all")
    || warning.includes("never be reached")
    || warning.includes("switched off")
    || warning.includes("matches no routing table");
}

function count(n: number, noun: string): string {
  return `${n.toLocaleString()} ${noun}${n === 1 ? "" : "s"}`;
}

function list(items: readonly string[]): string {
  if (items.length <= 1) {
    return items[0] ?? "";
  }
  return `${items.slice(0, -1).join(", ")} and ${items[items.length - 1]}`;
}
