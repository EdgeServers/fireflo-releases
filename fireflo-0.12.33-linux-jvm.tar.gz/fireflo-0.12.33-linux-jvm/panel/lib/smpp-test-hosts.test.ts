import { test } from "node:test";
import assert from "node:assert/strict";
import { allowedSmppHosts, hostOfUrl, normaliseHost, parseAllowedHostsEnv, smppHostRefusal } from "./smpp-test-hosts.ts";

/** The SMPP test tool's host allow-list (CP-S8): what gets in, and the sentence for what does not. */

test("hosts compare case-insensitively, without brackets or a trailing dot", () => {
  assert.equal(normaliseHost(" SMPP.Example.COM. "), "smpp.example.com");
  assert.equal(normaliseHost("[::1]"), "::1");
  assert.equal(normaliseHost(null), "");
});

test("the env list splits on commas, semicolons and whitespace", () => {
  assert.deepEqual(parseAllowedHostsEnv("a.example, b.example;c.example  d.example"), ["a.example", "b.example", "c.example", "d.example"]);
  assert.deepEqual(parseAllowedHostsEnv(""), []);
  assert.deepEqual(parseAllowedHostsEnv(undefined), []);
  assert.deepEqual(parseAllowedHostsEnv(" , "), []);
});

test("a URL setting contributes its hostname and a non-URL contributes nothing", () => {
  assert.equal(hostOfUrl("http://127.0.0.1:9000"), "127.0.0.1");
  assert.equal(hostOfUrl("https://API.example.com/v1"), "api.example.com");
  assert.equal(hostOfUrl("http://[::1]:9000"), "::1");
  assert.equal(hostOfUrl("9000"), null);
  assert.equal(hostOfUrl(""), null);
  assert.equal(hostOfUrl(undefined), null);
});

test("the allow-list drops blanks and duplicates", () => {
  const allowed = allowedSmppHosts(["127.0.0.1", null, "", "Smpp.Example.com", "smpp.example.com", undefined]);
  assert.deepEqual([...allowed].sort(), ["127.0.0.1", "smpp.example.com"]);
});

test("a listed host is allowed however it is spelled", () => {
  const allowed = allowedSmppHosts(["127.0.0.1", "smpp.example.com", "2001:db8::5"]);
  assert.equal(smppHostRefusal("127.0.0.1", allowed), null);
  assert.equal(smppHostRefusal("SMPP.example.com", allowed), null);
  assert.equal(smppHostRefusal("[2001:db8::5]", allowed), null);
});

test("a host off the list is refused with the sentence that says how to add it", () => {
  const allowed = allowedSmppHosts(["127.0.0.1"]);
  const why = smppHostRefusal("10.0.0.9", allowed);
  assert.ok(why);
  assert.match(why!, /'10\.0\.0\.9' is not one of this gateway's hosts/);
  assert.match(why!, /SMPP_TEST_ALLOWED_HOSTS/);
  assert.equal(smppHostRefusal("localhost", allowed) !== null, true, "loopback by another name is still not on the list");
});

test("an empty host is refused rather than matched against nothing", () => {
  assert.equal(smppHostRefusal("  ", allowedSmppHosts([""])), "Enter a host.");
});
