import { NextResponse } from "next/server";
import { NotCustomerError } from "@/lib/require-customer";

/**
 * The two things every customer route repeats.
 *
 * <p>In their own module rather than exported from a route file: a route module may export only the
 * HTTP method handlers, and a stray helper beside them is a build error rather than a style
 * question.
 */

/**
 * Turns a failed `requireCustomer` into the answer, and rethrows anything else.
 *
 * <p>**404 and never 403.** A 403 confirms there is something here to be forbidden from, which for a
 * portal keyed by account is a way of asking whether an account exists.
 */
export function notFoundOrThrow(err: unknown): NextResponse {
  if (err instanceof NotCustomerError) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  throw err;
}

/**
 * Free text a customer writes and an operator reads: trimmed, capped, null when empty.
 *
 * <p>Capped because nothing else bounds it — the column is `text` and this is the only gate between
 * a form field and the database.
 */
export function note(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value.trim().slice(0, 500) : null;
}

/** A row id from a path segment, or null when it is not one. Ids are guessable, so callers scope. */
export function rowId(raw: string): number | null {
  return /^\d+$/.test(raw) ? Number(raw) : null;
}
