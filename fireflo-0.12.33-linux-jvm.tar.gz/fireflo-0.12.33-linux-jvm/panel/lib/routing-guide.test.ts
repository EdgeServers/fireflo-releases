import { test } from "node:test";
import assert from "node:assert/strict";
import {
  describeRuleWhen,
  isSystemRule,
  moveRule,
  reachability,
  ruleChanged,
  sendsInto,
  tableChangeCount,
  targetKindLabel,
  targetOptions,
  unreachableRules,
  unreachedNote,
} from "./routing-guide.ts";
import type { ConditionInput } from "./rate-types.ts";
import type { RouteRule, RouteTable } from "./routing-types.ts";

const c = (field: string, operator: string, value: string, negate = false): ConditionInput => ({ field, operator, value, negate });
const rule = (target: string, patch: Partial<RouteRule> = {}): RouteRule => ({
  id: null, target, copied: false, label: null, enabled: true, conditions: [], filters: [], ...patch,
});
const table = (name: string, rules: RouteRule[], patch: Partial<RouteTable> = {}): RouteTable => ({
  name, targetFunction: "NORMAL", label: null, enabled: true, rules, ...patch,
});

test("a rule reads as a sentence, routing's own fields included", () => {
  assert.equal(describeRuleWhen(rule("v")), "Every message");
  assert.equal(
    describeRuleWhen(rule("v", { conditions: [c("to", "startsWith", "+91"), c("product", "equals", "txn")] })),
    "When destination starts with +91 and product is txn"
  );
  assert.equal(describeRuleWhen(rule("v", { conditions: [c("type", "==", "18")] })), "When it is a delivery receipt");
  assert.equal(describeRuleWhen(rule("v", { conditions: [c("type", "==", "11")] })), "When it is a Unicode message");
  assert.equal(describeRuleWhen(rule("v", { conditions: [c("ingateway", "startsWith", "smppclient.")] })), "When it came in from a vendor");
  assert.equal(
    describeRuleWhen(rule("v", { conditions: [c("ingateway", "equals", "smppclient.v1")], filters: ["in_txn"] })),
    "When it arrived through smppclient.v1 and filter in_txn matches"
  );
});

test("system rules are the ones default routing labelled", () => {
  assert.ok(isSystemRule(rule("x", { label: "system:dlr-return:smpp" })));
  assert.ok(!isSystemRule(rule("x", { label: "India" })));
  assert.ok(!isSystemRule(rule("x")));
});

test("rules below a catch-all that stops are unreachable; a copy or an LCR table stops nothing", () => {
  const rules = [rule("a", { conditions: [c("to", "startsWith", "+91")] }), rule("b"), rule("c"), rule("d", { enabled: false })];
  assert.deepEqual([...unreachableRules({ targetFunction: "NORMAL", rules })], [2]);
  assert.deepEqual([...unreachableRules({ targetFunction: "NORMAL", rules: [rule("a", { copied: true }), rule("b")] })], []);
  assert.deepEqual([...unreachableRules({ targetFunction: "LCR", rules })], []);
  assert.deepEqual([...unreachableRules({ targetFunction: "NORMAL", rules: [rule("a", { filters: ["f"] }), rule("b")] })], []);
});

test("moving a rule skips over the other kind", () => {
  const rules = [rule("s1", { label: "system:a" }), rule("b1"), rule("s2", { label: "system:b" }), rule("b2")];
  assert.deepEqual(moveRule(rules, 3, -1).map((r) => r.target), ["s1", "b2", "s2", "b1"]);
  assert.deepEqual(moveRule(rules, 0, 1).map((r) => r.target), ["s2", "b1", "s1", "b2"]);
  //nowhere to go: the same array back
  assert.equal(moveRule(rules, 1, -1), rules);
});

test("a staged table counts additions, edits, moves, removals and settings", () => {
  const stored = table("t", [rule("a", { id: 1 }), rule("b", { id: 2 }), rule("c", { id: 3 })]);
  assert.equal(tableChangeCount(stored, { ...stored }), 0);
  //a swap moves two rules
  const swapped = [stored.rules[1], stored.rules[0], stored.rules[2]];
  assert.equal(tableChangeCount(stored, { ...stored, rules: swapped }), 2);
  assert.ok(ruleChanged(stored.rules, swapped[0], 0));
  assert.ok(!ruleChanged(stored.rules, swapped[2], 2));
  //an edit, an addition and a removal
  const edited = [{ ...stored.rules[0], enabled: false }, stored.rules[1], rule("new")];
  assert.equal(tableChangeCount(stored, { ...stored, rules: edited }), 3);
  //the settings each count once
  assert.equal(tableChangeCount(stored, { ...stored, label: "x", enabled: false, targetFunction: "LCR" }), 3);
});

test("targets are grouped, listeners by their full name, and the table itself left out", () => {
  const groups = targetOptions(
    [{ name: "default" }, { name: "MESSAGE" }],
    [{ name: "pool" }],
    [{ name: "v1", type: "smppclient", enabled: true }, { name: "v2", type: "smppclient", enabled: false }, { name: "smpp", type: "smppserver" }],
    "MESSAGE"
  );
  assert.deepEqual(groups.map((g) => g.label), ["Vendors", "Vendor groups", "Routing tables", "Listeners (receipts and inbound)"]);
  assert.deepEqual(groups[0].options.map((o) => o.label), ["v1", "v2 (switched off)"]);
  assert.deepEqual(groups[2].options.map((o) => o.value), ["default"]);
  assert.deepEqual(groups[3].options.map((o) => o.value), ["smppserver.smpp"]);

  const workers = [{ name: "v1", type: "smppclient" }, { name: "smpp", type: "smppserver" }];
  assert.equal(targetKindLabel("smppserver.smpp", [], workers, []).label, "Listener");
  assert.equal(targetKindLabel("v1", [], workers, []).label, "Vendor");
  assert.equal(targetKindLabel("pool", [], workers, ["pool"]).label, "Vendor group");
  assert.equal(targetKindLabel("nope", [], workers, []).label, "Not recognised");
});

test("the chain follows enabled rules from default and names what nothing reaches", () => {
  const tables = [
    table("default", [rule("MESSAGE"), rule("MESSAGE"), rule("smpp")]),
    table("MESSAGE", [rule("cheapest"), rule("old", { enabled: false })]),
    table("cheapest", [rule("v1")], { targetFunction: "LCR" }),
    table("old", [rule("v1")]),
  ];
  assert.deepEqual(sendsInto(tables[0], tables.map((t) => t.name)), ["MESSAGE"]);
  assert.deepEqual(reachability(tables), { reached: ["default", "MESSAGE", "cheapest"], unreached: ["old"] });
});

test("a table nothing reaches says why, and names the missing link in a chain", () => {
  const tables = [
    table("default", [rule("MESSAGE")]),
    table("MESSAGE", [rule("smppsim"), rule("off", { enabled: false })]),
    table("sample", [rule("smppsim", { conditions: [c("to", "startsWithAny", "+91,91")] })]),
    table("a", [rule("b")]),
    table("b", [rule("v1"), rule("v2")]),
    table("off", [rule("v1")]),
  ];
  assert.equal(unreachedNote("default", tables), null);
  assert.equal(unreachedNote("MESSAGE", tables), null);
  assert.match(unreachedNote("sample", tables)!, /^Nothing routes to this table, so its rule never runs/);
  //b is targeted, but only from a, which nothing reaches
  assert.equal(unreachedNote("b", tables), "Only a sends here, and nothing reaches it either, so its 2 rules never run.");
  //a disabled rule's target does not count as a way in
  assert.match(unreachedNote("off", tables)!, /^Nothing routes to this table/);
});
