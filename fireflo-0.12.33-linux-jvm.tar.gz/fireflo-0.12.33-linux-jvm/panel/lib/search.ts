/**
 * The ranking behind the jump box, kept pure so it can be tested without a database.
 *
 * <p>Prefix matches first, then anything containing the text, each group in the order the source
 * gave them; case-insensitive throughout. An account matches on its id or its label, and the id
 * wins ties because it is what an operator types from memory.
 */

export interface SearchHit {
  kind: "account" | "vendor" | "server" | "message";
  id: string;
  label?: string | null;
  href: string;
}

export interface SearchResult {
  accounts: { id: string; label: string | null }[];
  vendors: string[];
  servers: string[];
  /** The message's own id when `q` names one, or null. */
  message: string | null;
}

export const MAX_PER_KIND = 8;

function rank<T>(items: readonly T[], keys: (item: T) => (string | null | undefined)[], q: string, max: number): T[] {
  const needle = q.trim().toLowerCase();
  if (!needle) {
    return [];
  }
  const prefix: T[] = [];
  const contains: T[] = [];
  for (const item of items) {
    const fields = keys(item).map((k) => (k ?? "").toLowerCase());
    if (fields.some((f) => f.startsWith(needle))) {
      prefix.push(item);
    } else if (fields.some((f) => f.includes(needle))) {
      contains.push(item);
    }
  }
  return [...prefix, ...contains].slice(0, max);
}

export function rankAccounts<T extends { id: string; label: string | null }>(accounts: readonly T[], q: string, max = MAX_PER_KIND): T[] {
  return rank(accounts, (a) => [a.id, a.label], q, max);
}

export function rankNames(names: readonly string[], q: string, max = MAX_PER_KIND): string[] {
  return rank(names, (n) => [n], q, max);
}

/**
 * Whether the text could be a gateway message id, so the metrics database is only asked when it
 * might answer: ids are long, unspaced and alphanumeric, and nothing else an operator jumps to is.
 */
export function looksLikeMessageId(q: string): boolean {
  return /^[A-Za-z0-9_-]{12,64}$/.test(q.trim());
}

/** The rows the box shows, in the order it shows them, as links. */
export function toHits(result: SearchResult, base = "/cp"): SearchHit[] {
  const hits: SearchHit[] = [];
  if (result.message) {
    hits.push({ kind: "message", id: result.message, href: `${base}/cdrs/${encodeURIComponent(result.message)}` });
  }
  for (const a of result.accounts) {
    hits.push({ kind: "account", id: a.id, label: a.label, href: `${base}/accounts/${encodeURIComponent(a.id)}` });
  }
  for (const v of result.vendors) {
    hits.push({ kind: "vendor", id: v, href: `${base}/vendors/${encodeURIComponent(v)}` });
  }
  for (const s of result.servers) {
    hits.push({ kind: "server", id: s, href: `${base}/servers/${encodeURIComponent(s)}` });
  }
  return hits;
}
