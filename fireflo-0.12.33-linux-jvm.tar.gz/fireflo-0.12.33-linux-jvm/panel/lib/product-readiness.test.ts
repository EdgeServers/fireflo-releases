import { test } from "node:test";
import assert from "node:assert/strict";
import {
  productGapSentence,
  productGapSummary,
  productGaps,
  type LoginProduct,
} from "./product-readiness.ts";

/**
 * Which logins would be refused once a listener requires a product.
 *
 * <p>Every case names the gateway behaviour it pins, because this is only useful while it agrees
 * with `SmppServerBindHandler.checkProduct` and `ProductCatalogue.check`.
 */

const login = (over: Partial<LoginProduct> = {}): LoginProduct => ({
  accountId: "acct-in-2001",
  systemId: "sunrise-smpp",
  type: "SMPP",
  product: "in-otp",
  ...over,
});

function gaps(logins: LoginProduct[], catalogue = ["in-otp", "in-txn"], disabled: string[] = []) {
  return productGaps({ logins, catalogue, disabled });
}

test("a login on a listed product is not reported at all", () => {
  assert.deepEqual(gaps([login()]), []);
});

test("a login with no product is the common case, and the one that sends free", () => {
  //RateSnapshot.rulesFor shows a product-less message only the product-less rules, so nothing
  //matches, hasPrice() is false, and chargeCredit returns without debiting
  const found = gaps([login({ product: "" })]);

  assert.equal(found.length, 1);
  assert.equal(found[0].problem, "blank");
  assert.match(productGapSentence(found[0]), /without being charged/);
  assert.match(productGapSentence(found[0]), /Set a product on the login/);
});

test("whitespace is not a product", () => {
  //app_credential.product has no CHECK, unlike app_header, so a space really can be stored
  assert.equal(gaps([login({ product: "   " })])[0].problem, "blank");
});

test("a name with no catalogue row reads as the typo it usually is", () => {
  const found = gaps([login({ product: "in-otpp" })]);

  assert.equal(found[0].problem, "unknown");
  const sentence = productGapSentence(found[0]);
  assert.match(sentence, /'in-otpp'/);
  //both fixes, because the panel cannot know which one is meant
  assert.match(sentence, /typo/);
  assert.match(sentence, /needs creating/);
});

test("an unlisted product is refused too, but has its own fix", () => {
  //DbConfigPoller loads SELECT name FROM app_product WHERE enabled, so a disabled row is simply
  //absent from the catalogue the gateway checks against
  const found = gaps([login({ product: "in-txn" })], ["in-otp", "in-txn"], ["in-txn"]);

  assert.equal(found[0].problem, "disabled");
  assert.match(productGapSentence(found[0]), /Re-enable the product/);
});

test("disabled beats unknown when a name is both listed and unlisted", () => {
  //an unlisted row still exists, and telling an operator to create a product they already have
  //would send them round a loop
  const found = gaps([login({ product: "retired" })], ["retired"], ["retired"]);

  assert.equal(found[0].problem, "disabled");
});

test("the worst problems come first", () => {
  const found = gaps([
    login({ systemId: "c", product: "gone" }, ),
    login({ systemId: "b", product: "nonsense" }),
    login({ systemId: "a", product: "" }),
  ], ["in-otp", "gone"], ["gone"]);

  assert.deepEqual(found.map((g) => g.problem), ["blank", "unknown", "disabled"]);
});

test("logins with the same problem are ordered so the list is stable", () => {
  const found = gaps([login({ systemId: "z", product: "" }), login({ systemId: "a", product: "" })]);

  assert.deepEqual(found.map((g) => g.systemId), ["a", "z"]);
});

test("a product is matched after trimming, as the gateway matches it", () => {
  assert.deepEqual(gaps([login({ product: " in-otp " })]), []);
});

test("an empty catalogue fails everything, which is a real state and not a bug", () => {
  //a deployment that has created no products sells nothing, and requiring a product there refuses
  //every bind. Better said here than discovered at the flag flip
  const found = gaps([login()], []);

  assert.equal(found.length, 1);
  assert.equal(found[0].problem, "unknown");
});

test("a healthy deployment says nothing at all", () => {
  //no card, no zero count. A report that renders on every healthy install is one people scroll past
  assert.equal(productGapSummary([], true), null);
});

test("the summary carries the system_type caveat whenever SMPP is in scope", () => {
  const found = gaps([login({ product: "" })]);
  const summary = productGapSummary(found, true) ?? "";

  assert.match(summary, /1 login would stop connecting/);
  //the honest limit: BasicSmppSessionContext resolves system_type over the credential's product,
  //and system_type is free text this cannot see
  assert.match(summary, /system_type/);
  assert.match(summary, /will not show up here/);
});

test("an HTTP-only deployment gets no caveat, because there it is exact", () => {
  //CredentialAuthenticator has no bind and no system_type, so the credential's product is the only
  //source and this report is the whole answer
  const found = gaps([login({ type: "HTTP", systemId: "acme-http", product: "" })]);
  const summary = productGapSummary(found, false) ?? "";

  assert.doesNotMatch(summary, /system_type/);
});

test("the caveat is given even when every login passes, if any is SMPP", () => {
  //the case where the caveat matters most: a clean report is exactly what would be over-trusted
  assert.equal(productGapSummary([], true), null, "but only alongside something to report");
});
