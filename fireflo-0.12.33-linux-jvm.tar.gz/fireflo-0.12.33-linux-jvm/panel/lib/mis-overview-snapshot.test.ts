import { strict as assert } from "node:assert";
import { test } from "node:test";

import { createSnapshotCache, overviewKey } from "./mis-overview-snapshot.ts";

function clock(start = 1_000_000) {
  let t = start;
  return { now: () => t, advance: (ms: number) => { t += ms; } };
}

test("a value is built once and served from memory until its TTL lapses", async () => {
  const c = clock();
  const cache = createSnapshotCache<number>({ ttlMs: 60_000, now: c.now, schedule: false });
  let builds = 0;
  const load = async () => ++builds;
  const first = await cache.get("k", load);
  assert.equal(first.value, 1);
  assert.equal(first.stale, false);
  assert.equal(first.asOf, new Date(1_000_000).toISOString());
  c.advance(59_000);
  assert.equal((await cache.get("k", load)).value, 1, "still fresh");
  c.advance(1_000);
  const rebuilt = await cache.get("k", load);
  assert.equal(rebuilt.value, 2, "rebuilt once the minute is up");
  assert.equal(rebuilt.asOf, new Date(1_060_000).toISOString());
  assert.equal(builds, 2);
});

test("requests that arrive while a build runs share it", async () => {
  const cache = createSnapshotCache<string>({ schedule: false });
  let builds = 0;
  let release!: () => void;
  const gate = new Promise<void>((r) => { release = r; });
  const load = async () => { builds++; await gate; return "v"; };
  const a = cache.get("k", load);
  const b = cache.get("k", load);
  release();
  assert.equal((await a).value, "v");
  assert.equal((await b).value, "v");
  assert.equal(builds, 1);
});

test("a failed build returns the previous value marked stale, or throws when there is none", async () => {
  const c = clock();
  const cache = createSnapshotCache<number>({ ttlMs: 1_000, now: c.now, schedule: false });
  await assert.rejects(cache.get("k", async () => { throw new Error("db down"); }), /db down/);
  await cache.get("k", async () => 7);
  c.advance(2_000);
  const stale = await cache.get("k", async () => { throw new Error("db down"); });
  assert.equal(stale.value, 7);
  assert.equal(stale.stale, true);
  assert.equal(stale.asOf, new Date(1_000_000).toISOString(), "as-of is the value's own time, not now");
  //and a later good build clears it
  const good = await cache.get("k", async () => 8);
  assert.equal(good.value, 8);
  assert.equal(good.stale, false);
});

test("the least recently used entry goes first when the cap is reached", async () => {
  const cache = createSnapshotCache<number>({ cap: 2, schedule: false });
  await cache.get("a", async () => 1);
  await cache.get("b", async () => 2);
  await cache.get("a", async () => 0); //a used again: b is now the oldest
  await cache.get("c", async () => 3);
  assert.equal(cache.size(), 2);
  let rebuilt = 0;
  await cache.get("b", async () => { rebuilt++; return 2; });
  assert.equal(rebuilt, 1, "b was evicted");
  await cache.get("a", async () => { rebuilt++; return 1; });
  assert.equal(rebuilt, 2, "a went to make room for b's rebuild");
  await cache.get("c", async () => { rebuilt++; return 3; });
  assert.equal(rebuilt, 3, "and c to make room for a's; b, used most recently, survives");
  await cache.get("a", async () => { rebuilt++; return 1; });
  assert.equal(rebuilt, 3, "a is fresh");
});

test("the sweeper drops what nobody has asked for in ten minutes", async () => {
  const c = clock();
  const cache = createSnapshotCache<number>({ idleMs: 600_000, now: c.now, schedule: false });
  await cache.get("old", async () => 1);
  c.advance(300_000);
  await cache.get("young", async () => 2);
  c.advance(300_000);
  cache.sweep();
  assert.equal(cache.size(), 1, "old went, young stays");
  let rebuilt = 0;
  await cache.get("young", async () => { rebuilt++; return 2; });
  assert.equal(rebuilt, 1, "young had lapsed its TTL by then and rebuilt, from memory of the key");
});

test("the key is order-free over the scope and safe for odd ids", () => {
  assert.equal(overviewKey(["b", "a"], "7d"), overviewKey(["a", "b"], "7d"));
  assert.notEqual(overviewKey(["a"], "7d"), overviewKey(["a"], "30d"));
  assert.notEqual(overviewKey(["a,b"], "7d"), overviewKey(["a", "b"], "7d"), "a comma in an id is not a separator");
});
