/**
 * The comma-joined `name_tag=value` form that `app_header.tlvs` and `app_template.tlvs` hold.
 *
 * <p>This is the panel's copy of the gateway's `TlvUtil.parseDefaults`, and it has to agree with it
 * exactly, for the same reason the template splitter does: the panel's job is to show an operator
 * what the gateway will do with what they typed, and a parser that disagreed would confidently
 * describe behaviour that never happens.
 *
 * <p>The two rules worth knowing before editing this format at all, both from the Java:
 *
 * <ul>
 *   <li><strong>Nothing is escaped.</strong> Entries are split on `,` and the pair on the first `=`,
 *       so a value containing a comma cannot be represented — it silently becomes two entries, the
 *       second of which has no `=` and is discarded. {@link tlvPairProblem} refuses it instead.
 *   <li><strong>Duplicate tags are first-wins.</strong> `parseDefaults` uses `putIfAbsent`, so a
 *       second entry for the same tag is dropped without a word. Two rows that look different and
 *       resolve to one tag are worth saying out loud.
 * </ul>
 *
 * <p>Credentials store the same idea as jsonb and have their own converter pair in `credentials.ts`.
 * These tables store a string, which is why this exists rather than that being reused.
 */

export interface TlvPair {
  key: string;
  value: string;
}

/**
 * Splits the stored string into editable pairs.
 *
 * <p>An entry with no `=` is kept as a pair with an empty value rather than dropped. The gateway
 * discards it, and an editor that also discarded it would silently delete text the operator typed —
 * they need to see the broken entry in order to fix it.
 */
export function parseTlvCsv(csv: string | null | undefined): TlvPair[] {
  if (!csv) {
    return [];
  }
  return csv
    .split(",")
    .map((entry) => entry.trim())
    .filter((entry) => entry.length > 0)
    .map((entry) => {
      const separator = entry.indexOf("=");
      return separator < 0
        ? { key: entry, value: "" }
        : { key: entry.slice(0, separator).trim(), value: entry.slice(separator + 1).trim() };
    });
}

/**
 * Joins pairs back into the stored form, or null when there is nothing to store.
 *
 * <p>Null rather than an empty string so the column matches what `saveHeader` already writes for an
 * empty input, and so "no stamps" is one value in the database rather than two.
 */
export function formatTlvCsv(pairs: readonly TlvPair[]): string | null {
  const joined = pairs
    .map((p) => ({ key: p.key.trim(), value: p.value.trim() }))
    .filter((p) => p.key.length > 0)
    .map((p) => `${p.key}=${p.value}`)
    .join(",");
  return joined.length > 0 ? joined : null;
}

/**
 * What is wrong with one pair, in the operator's terms, or null.
 *
 * <p>Only the two problems the format itself creates. Whether the KEY resolves to a tag is a
 * different question with a different answer — `TlvTokenInput` already says so, in amber, using the
 * catalogue — and duplicating that judgement here would give two components a chance to disagree.
 */
export function tlvPairProblem(pair: TlvPair): string | null {
  if (pair.value.includes(",")) {
    return "A value cannot contain a comma — the list is comma-separated and nothing is escaped, so "
      + "this would be stored as two entries and the second discarded. Use hex: for raw bytes.";
  }
  if (pair.key.includes(",")) {
    return "A name cannot contain a comma.";
  }
  return null;
}

/**
 * What is wrong with a whole stored string, or null. The server's copy of the editor's judgement.
 *
 * <p>Exists because a customer can now write one of these ({@link ../lib/mis-whitelist}'s
 * `requested_tlvs`), and a customer's browser is not where validation lives. It answers the same
 * three questions the editor asks, in the same words, so a proposal refused by the route reads
 * exactly like the amber line that should have stopped it.
 *
 * <p>It **does** now judge the token's grammar, which this deliberately did not do before. The
 * distinction that makes the reversal safe: the *catalogue* can change under a stored value — an
 * operator may define a name tomorrow — and is no basis for a refusal. The *grammar* cannot. A token
 * with no underscore reads one way for ever, and on this deployment it has been reading the wrong
 * way in production. See {@link tlvTokenProblem}.
 */
export function tlvCsvProblem(csv: string | null): string | null {
  if (csv === null) {
    return null;
  }
  if (csv.length > 2000) {
    return "That is too long. The whole list has to fit in one configuration value.";
  }
  //over the raw entries rather than the parsed pairs, because parsing is where the information is
  //lost: `peid_0x1400=one,two` splits into a good pair and a second entry with no `=`, which the
  //gateway discards silently. That is the comma-in-a-value case, and it has to be caught here --
  //`tlvPairProblem` cannot see it once the split has happened
  const entries = csv.split(",").map((e) => e.trim()).filter((e) => e.length > 0);
  for (const entry of entries) {
    const separator = entry.indexOf("=");
    if (separator < 0) {
      return `'${entry}' has no '=' — every entry is name=value, and a value cannot contain a `
        + "comma because nothing is escaped. Use hex: for raw bytes.";
    }
    if (!entry.slice(0, separator).trim()) {
      return "Every entry needs a name before the '='.";
    }
  }
  const pairs = parseTlvCsv(csv);
  for (const pair of pairs) {
    const token = tlvTokenProblem(pair.key);
    if (token) {
      return token;
    }
  }
  const duplicates = duplicateTlvKeys(pairs);
  if (duplicates.length) {
    return `'${duplicates[0]}' is listed twice. The gateway keeps the first and drops the rest `
      + "without logging it.";
  }
  return null;
}

/**
 * Why a token cannot be stored, or null.
 *
 * <p><strong>A token with no underscore is refused.</strong> The tag is whatever follows the last
 * underscore, decimal unless written `0x` — and with no underscore the whole token is the tag. That
 * is not a subtlety anybody carries in their head: a live sender ID here has been stamping
 * `1401=…`, which is tag 1401 (0x0579), not the DLT template id 0x1401 (5121). It did that silently
 * for as long as the field had no validation.
 *
 * <p>The refusal cannot block a legitimate intent, which is what makes it safe to refuse rather than
 * warn: every meaning is still available, spelled unambiguously. Decimal 1401 is `tlv_1401`; tag
 * 0x1401 is `tmplid_0x1401` or any other `name_0x1401`. What is refused is only the spelling that
 * means two things.
 *
 * <p>Deliberately catalogue-free. Naming the token the way `resolveTlv` would is nicer, and
 * `TlvTokenInput` does exactly that beside the field — but importing the catalogue here would make a
 * cycle, since it re-exports {@link tlvTag} from this module. The rule is about grammar; the name is
 * about the catalogue; they belong on opposite sides of that import.
 */
export function tlvTokenProblem(token: string): string | null {
  const trimmed = (token ?? "").trim();
  if (!trimmed) {
    return null;
  }
  const tag = tlvTag(trimmed);
  if (tag === null) {
    return `'${trimmed}' carries no tag, so the gateway logs it and skips it — this would stamp `
      + "nothing at all. The tag is what follows the last underscore: write it as "
      + "name_0x1400, for example peid_0x1400.";
  }
  if (trimmed.includes("_")) {
    return null;
  }
  //bare digits are the dangerous shape: they parse, so nothing downstream complains, and they parse
  //as the reading almost nobody meant
  if (/^\d+$/.test(trimmed)) {
    const asHex = parseInt(trimmed, 16);
    return `'${trimmed}' has no underscore, so the whole token is the tag and it is read as `
      + `decimal — tag ${tag}, not 0x${trimmed}. If you meant 0x${trimmed} (${asHex}), write it as `
      + `name_0x${trimmed}. If you really do mean decimal ${tag}, write tlv_${tag}.`;
  }
  return `'${trimmed}' is a tag with no name. Write it as name_${trimmed} — the name is what makes `
    + "it identifiable in a call record and in this panel.";
}

/**
 * The TLVs a customer is proposing, normalised, or the refusal to send back.
 *
 * <p>Lives here rather than beside the routes because it is pure, and because it is the one place
 * where text a customer typed becomes a value in the configuration database. Parsed and re-joined
 * rather than stored as typed, so what lands in the column is the same shape the operator's own
 * editor produces — whitespace and empty entries gone, one canonical form.
 *
 * <p>Undefined and empty both mean "none proposed". There is deliberately no third state meaning
 * "leave whatever was there": the field arrives from a form that always sends it, and an absent
 * value that quietly kept an old proposal alive would be a proposal nobody could withdraw.
 */
export function proposedTlvs(value: unknown): { value: string | null } | { error: string } {
  if (value === undefined || value === null || value === "") {
    return { value: null };
  }
  if (typeof value !== "string") {
    return { error: "Expected the stamps as a string." };
  }
  const problem = tlvCsvProblem(value);
  if (problem) {
    return { error: problem };
  }
  return { value: formatTlvCsv(parseTlvCsv(value)) };
}

/**
 * The keys that appear more than once, resolved to the same tag by first-wins.
 *
 * <p>Compared case-insensitively on the whole token, which is a deliberate under-approximation:
 * `peid_0x1400` and `other_0x1400` are also one tag to the gateway, and catching that needs the
 * catalogue. This catches the copy-paste case, which is the one that happens.
 */
export function duplicateTlvKeys(pairs: readonly TlvPair[]): string[] {
  const seen = new Set<string>();
  const duplicates = new Set<string>();
  for (const { key } of pairs) {
    const k = key.trim().toLowerCase();
    if (!k) {
      continue;
    }
    if (seen.has(k)) {
      duplicates.add(key.trim());
    }
    seen.add(k);
  }
  return [...duplicates];
}

/**
 * Resolves a `<name>_<tag>` TLV token to its tag, or null.
 *
 * <p>Reimplements `TlvUtil.parseTag`, including the two things about it that are not guessable: the
 * tag is whatever follows the **last** underscore, and it is decimal unless prefixed `0x` — so
 * `tlv_0100` is tag 100, not 64. A leading zero is not octal here.
 */
export function tlvTag(token: string): number | null {
  const trimmed = (token ?? "").trim();
  if (!trimmed) {
    return null;
  }
  const cut = trimmed.lastIndexOf("_");
  const raw = cut >= 0 ? trimmed.slice(cut + 1) : trimmed;
  if (!raw) {
    return null;
  }
  const hex = /^0[xX][0-9a-fA-F]+$/.test(raw);
  if (!hex && !/^\d+$/.test(raw)) {
    return null;
  }
  const tag = hex ? parseInt(raw.slice(2), 16) : parseInt(raw, 10);
  return Number.isFinite(tag) && tag >= 0 && tag <= 0xffff ? tag : null;
}
