import { test } from "node:test";
import assert from "node:assert/strict";
import {
  GROUP_POLICIES,
  memberShares,
  policyReadsWeight,
  routeGroupWarnings,
  validateRouteGroup,
} from "./group-types.ts";

/**
 * Vendor groups.
 *
 * <p>The rules worth testing here are the ones where the gateway's behaviour and the screen's
 * appearance can disagree: a weight that is set but never read, a name that means two things, and
 * the share a suspended member is not receiving.
 */

const base = {
  name: "asia", policy: "WEIGHTED" as const, label: null, enabled: true,
  members: [
    { workerName: "vendor1", weight: 70, enabled: true },
    { workerName: "vendor2", weight: 30, enabled: true },
  ],
};

test("a valid group saves", () => {
  assert.equal(validateRouteGroup(base), null);
});

test("a name that is also a routing table or a vendor is refused before it can be saved", () => {
  //the gateway refuses the WHOLE routing configuration on this, so it must not be reachable from
  //the panel -- the failure mode is "routing stopped updating", which is far from the cause
  assert.match(validateRouteGroup(base, ["asia"]) ?? "", /already a routing table/);
  assert.match(validateRouteGroup(base, [], ["asia"]) ?? "", /already a vendor/);
});

test("a vendor listed twice is refused, because it does not double its share", () => {
  const twice = { ...base, members: [...base.members, { workerName: "vendor1", weight: 10, enabled: true }] };

  assert.match(validateRouteGroup(twice) ?? "", /twice/);
});

test("a weight below one is refused rather than silently muting the member", () => {
  const zero = { ...base, members: [{ workerName: "vendor1", weight: 0, enabled: true }] };

  assert.match(validateRouteGroup(zero) ?? "", /never sent to/);
});

test("a weight set on a policy that ignores it is warned about, not refused", () => {
  //the gateway logs routing.group.weight-ignored for exactly this. The panel is where the number
  //was typed, so it is where the warning is most useful
  const rr = { ...base, policy: "ROUND_ROBIN" as const };

  assert.equal(validateRouteGroup(rr), null, "it is legal, just misleading");
  assert.match(routeGroupWarnings(rr).join(" "), /does not read them/);
});

test("a group with nothing switched on says what happens to the traffic", () => {
  const off = { ...base, members: base.members.map((m) => ({ ...m, enabled: false })) };

  assert.match(routeGroupWarnings(off).join(" "), /falls through to the rule below/);
});

test("a one-member failover group is called out", () => {
  const solo = {
    ...base, policy: "FAILOVER" as const,
    members: [{ workerName: "vendor1", weight: 1, enabled: true }],
  };

  assert.match(routeGroupWarnings(solo).join(" "), /something to fail over to/);
});

test("shares are the proportions traffic actually takes", () => {
  const shares = memberShares(base);

  assert.equal(shares.get("vendor1"), 70);
  assert.equal(shares.get("vendor2"), 30);
});

test("a suspended member shows no share, and the rest re-proportion", () => {
  //this is what the gateway does -- a suspended member's share goes to the others rather than
  //being left unsent -- and showing it a share it is not receiving would mislead at the worst
  //possible moment
  const down = {
    ...base,
    members: [
      { workerName: "vendor1", weight: 70, enabled: true },
      { workerName: "vendor2", weight: 30, enabled: false },
    ],
  };

  const shares = memberShares(down);
  assert.equal(shares.get("vendor1"), 100);
  assert.equal(shares.get("vendor2"), undefined);
});

test("failover shows all of it on the first member and none on the standbys", () => {
  const shares = memberShares({ ...base, policy: "FAILOVER" });

  assert.equal(shares.get("vendor1"), 100);
  assert.equal(shares.get("vendor2"), 0);
});

test("round robin ignores weights when computing shares, exactly as the gateway does", () => {
  const shares = memberShares({ ...base, policy: "ROUND_ROBIN" });

  assert.equal(shares.get("vendor1"), 50);
  assert.equal(shares.get("vendor2"), 50);
});

test("only weighted reads a weight", () => {
  assert.equal(policyReadsWeight("WEIGHTED"), true);
  assert.equal(GROUP_POLICIES.filter(policyReadsWeight).length, 1);
});

test("a malformed group from the API is a bad request, not a crash", () => {
  for (const bad of [{}, { name: "a" }, { name: "a", policy: "WEIGHTED", members: [{}] }]) {
    assert.doesNotThrow(() => validateRouteGroup(bad as never));
    assert.ok(validateRouteGroup(bad as never));
  }
});
