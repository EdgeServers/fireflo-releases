/**
 * The approval half of the two whitelist upserts, as SQL fragments.
 *
 * <p>Database-free on purpose. `lib/whitelist.ts` imports `pg`, which `node --test` cannot load, so
 * anything living there is untestable — and these four strings shipped a statement that failed to
 * parse on every call precisely because nothing could assert anything about them. Same reason
 * `rejected-request.ts` and `custom-tlvs.ts` are separate from their query layers.
 *
 * <p>Approving from the editor, rather than only from the review buttons: the tick used to be
 * labelled "Approved" and write only `enabled`, which left a customer's PENDING row PENDING and
 * inert while the panel looked like it had approved something.
 *
 * <p><strong>Only ever forwards.</strong> Ticking sets `APPROVED` and records who and when, exactly
 * as the review PATCH does. Unticking leaves `status` alone and only clears `enabled` — withdrawing
 * a registration is not un-approving it, and a withdrawn row put back into service should not need a
 * second approval. Refusing is not reachable from here at all: it needs a reason the customer is
 * shown.
 *
 * <p>The header and template shapes differ only by their parameter numbers — `$6`/`$7` against
 * `$7`/`$8` — which is why they are four constants rather than two.
 */

/**
 * <strong>Every column on the right of an `ELSE` is qualified with its table name, and it has to
 * be.</strong>
 *
 * <p>This fragment is interpolated into an `INSERT ... ON CONFLICT DO UPDATE`, where the target
 * table and the `excluded` pseudo-relation are BOTH in scope. A bare `status` there resolves
 * ambiguously and PostgreSQL refuses the whole statement with `column reference "status" is
 * ambiguous` — at parse time, not at execution, so it fired on every operator save rather than only
 * when a conflict actually occurred, and no sender ID could be added at all.
 *
 * <p>Qualifying is equally valid in the plain `UPDATE` this is also interpolated into, which is what
 * lets one constant still serve both call sites. An alias would not work: `ON CONFLICT` addresses
 * the target by its own name.
 *
 * <p>Note the asymmetry the test pins: the column being assigned, on the LEFT of each `=`, must
 * stay bare. PostgreSQL rejects a qualified target in a `SET` clause, so "qualify everything"
 * is not the fix — it just trades one parse error for another.
 */
export const APPROVAL_SET =
  "status = CASE WHEN $6 THEN 'APPROVED' ELSE app_header.status END, "
  + "reviewed_by = CASE WHEN $6 THEN $7 ELSE app_header.reviewed_by END, "
  + "reviewed_at = CASE WHEN $6 THEN now() ELSE app_header.reviewed_at END";

export const APPROVAL_INSERT =
  "CASE WHEN $6 THEN 'APPROVED' ELSE 'PENDING' END, "
  + "CASE WHEN $6 THEN $7 END, CASE WHEN $6 THEN now() END";

/**
 * Qualified for the same reason as {@link APPROVAL_SET}, though `saveTemplate` has no `ON CONFLICT`
 * today and so has never hit the error. Left bare it is a trap set for whoever adds one.
 */
export const APPROVAL_SET_TEMPLATE =
  "status = CASE WHEN $7 THEN 'APPROVED' ELSE app_template.status END, "
  + "reviewed_by = CASE WHEN $7 THEN $8 ELSE app_template.reviewed_by END, "
  + "reviewed_at = CASE WHEN $7 THEN now() ELSE app_template.reviewed_at END";

export const APPROVAL_INSERT_TEMPLATE =
  "CASE WHEN $7 THEN 'APPROVED' ELSE 'PENDING' END, "
  + "CASE WHEN $7 THEN $8 END, CASE WHEN $7 THEN now() END";
