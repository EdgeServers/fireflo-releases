import { configQuery } from "@/lib/config-db";
import { REFUSE_UNRATED_KEY } from "@/lib/unrated-preflight";

/**
 * Whether the gateway is refusing messages it cannot price.
 *
 * <p><strong>One key for both ingresses, on purpose.</strong> `SmppServerWorker` reads the bare
 * property rather than copying it per listener, because a per-listener version would let one port
 * bill what another gives away — the same account, the same product, two answers depending on which
 * socket it happened to use.
 *
 * <p>Returns null when it cannot be read, which is **not** the same as off. In file mode the value
 * lives in `smsg.properties`, which this panel does not read at all; the row simply being absent
 * means the coded default, which is off. A caller must not render null as "off" — the whole point of
 * showing this beside a pre-flight is to be honest about what is known.
 */
export async function refusesUnrated(): Promise<boolean | null> {
  const rows = await configQuery<{ value: string | null }>(
    `SELECT value FROM app_config WHERE key = $1 AND enabled`,
    [REFUSE_UNRATED_KEY]
  );
  if (!rows.length) {
    return null;
  }
  return (rows[0].value ?? "").trim().toLowerCase() === "true";
}
