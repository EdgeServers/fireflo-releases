/**
 * Preprocessors: programs the gateway runs that a routing rule hands matching messages to.
 *
 * <p>Client-safe shapes and checks; `preprocessors.ts` is the server half. The checks here are the
 * gateway's own (`PreprocessorDefinition.fromSettings`) and the V1.62.0 table's, written a third
 * time so the editor can say what is wrong before a save is refused.
 *
 * <p>What a row is and is not: it names a FILE in the gateway's preprocessor directory and how to
 * run it. It never holds code, a path or a command line -- a panel login can choose which installed
 * program sees which traffic, and cannot make the gateway run anything new. That is the gateway's
 * rule, and the editor says so rather than offering a box that looks like it could hold a command.
 */

/** What a rule's target starts with when it sends to a preprocessor. */
export const PREPROCESSOR_PREFIX = "@";

export const DEFAULT_FIELDS = ["to", "from", "systemId", "product"] as const;

/** What a program may be sent, in the gateway's words. Mirrors `SENDABLE_FIELDS`. */
export const SENDABLE_FIELDS: readonly { id: string; label: string; hint?: string }[] = [
  { id: "to", label: "Destination" },
  { id: "from", label: "Sender" },
  { id: "systemId", label: "Login" },
  { id: "account", label: "Account" },
  { id: "product", label: "Product" },
  { id: "serial", label: "Message id" },
  { id: "type", label: "Message type" },
  { id: "dcs", label: "Encoding (dcs)" },
  { id: "ingateway", label: "Arrived on" },
  { id: "body", label: "Message text", hint: "only send it if the program needs to read the message" },
  { id: "tlvs", label: "TLVs", hint: "the message's optional parameters, keyed 0xNNNN; a test sample writes them as 0x1400=value;0x1401=value" },
  ...Array.from({ length: 10 }, (_, i) => ({ id: `field${i + 1}`, label: `field${i + 1}` })),
];

export type OnErrorKind = "continue" | "hold" | "drop" | "reject";

export const ON_ERROR: readonly { id: OnErrorKind; label: string; hint: string }[] = [
  { id: "continue", label: "Carry on routing", hint: "as if the rule were not there — the safe default" },
  { id: "reject", label: "Refuse the message", hint: "fail closed, for a check that must never be skipped" },
  { id: "hold", label: "Try again later", hint: "after the routing backoff, counting an attempt" },
  { id: "drop", label: "Drop it", hint: "discarded, refunded and recorded" },
];

export interface Preprocessor {
  name: string;
  run: string;
  workers: number;
  timeoutMs: number;
  inflight: number;
  /** As stored: `continue`, `hold`, `drop`, `reject` or `reject:<status>`. */
  onError: string;
  fields: string[];
  label: string | null;
  enabled: boolean;
  updatedAt: string | null;
  /** The rules that send to it, `table #seq`, so a delete or disable can say what it affects. */
  usedBy: { table: string; seq: number; enabled: boolean }[];
}

export type PreprocessorInput = Omit<Preprocessor, "updatedAt" | "usedBy">;

/** One preprocessor as `/ops/health` reports it. Mirrors `PreprocessorStatus`. */
export interface PreprocessorLive {
  name: string;
  run: string;
  state: "running" | "retiring" | "unavailable" | "off";
  problem?: string | null;
  ready: number;
  workers: number;
  waiting: number;
  inflight: number;
  timeout_ms: number;
  on_error: string;
  submitted: number;
  refused: number;
  timeouts: number;
  bad_responses: number;
  late: number;
  restarts: number;
  p50_ms?: number | null;
  p99_ms?: number | null;
  actions: Record<string, number>;
}

export function emptyPreprocessor(): PreprocessorInput {
  return {
    name: "",
    run: "",
    workers: 2,
    timeoutMs: 200,
    inflight: 1000,
    onError: "continue",
    fields: [...DEFAULT_FIELDS],
    label: null,
    enabled: true,
  };
}

export function splitOnError(value: string): { kind: OnErrorKind; status: string } {
  const v = value.trim();
  if (v.toLowerCase().startsWith("reject")) {
    return { kind: "reject", status: v.length > "reject:".length ? v.slice("reject:".length).trim() : "" };
  }
  const kind = (["continue", "hold", "drop"] as const).find((k) => k === v.toLowerCase());
  return { kind: kind ?? "continue", status: "" };
}

export function joinOnError(kind: OnErrorKind, status: string): string {
  return kind === "reject" ? (status.trim() ? `reject:${status.trim()}` : "reject") : kind;
}

/** What runs the file, by its extension -- the gateway's rule, said where it is chosen. */
export function runnerFor(run: string): string {
  const r = run.trim().toLowerCase();
  if (r.endsWith(".py")) return "python3";
  if (r.endsWith(".java")) return "java (single-file source)";
  if (r.endsWith(".sh")) return "bash";
  if (r.endsWith(".jar")) return "java -jar";
  return r ? "run directly — the file must be executable" : "";
}

/** The first thing wrong with a preprocessor, or null. */
export function validatePreprocessor(p: PreprocessorInput): string | null {
  if (!/^[A-Za-z0-9_.-]{1,64}$/.test(p.name.trim())) {
    return "The name is 1 to 64 letters, digits, '.', '_' or '-'. Rules send to it as @name.";
  }
  const run = p.run.trim();
  if (!run) {
    return "Name the file to run.";
  }
  if (run.includes("/") || run.includes("\\") || run.startsWith(".") || run.length > 255) {
    return "The file is a plain name inside the gateway's preprocessor directory, never a path.";
  }
  if (!Number.isInteger(p.workers) || p.workers < 1 || p.workers > 64) {
    return "Copies running is between 1 and 64.";
  }
  if (!Number.isInteger(p.timeoutMs) || p.timeoutMs < 1 || p.timeoutMs > 60000) {
    return "The time limit is between 1 ms and 60 000 ms.";
  }
  if (!Number.isInteger(p.inflight) || p.inflight < 1 || p.inflight > 100000) {
    return "Messages waiting is between 1 and 100 000.";
  }
  if (!/^(continue|hold|drop|reject(:.+)?)$/i.test(p.onError.trim())) {
    return "When it cannot answer: carry on, refuse, try again later or drop.";
  }
  const known = new Set(SENDABLE_FIELDS.map((f) => f.id));
  const unknown = p.fields.find((f) => !known.has(f));
  if (unknown) {
    return `'${unknown}' is not a field the gateway can send.`;
  }
  return null;
}
