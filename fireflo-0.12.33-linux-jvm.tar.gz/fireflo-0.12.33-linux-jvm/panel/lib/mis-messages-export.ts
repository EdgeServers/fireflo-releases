import { CDR_COLUMNS, type CdrColumn } from "./cdr-columns.ts";
import type { CdrRow } from "./cdr-request";
import { csv } from "./csv.ts";
import { allowedForCustomer } from "./customer-cdr-columns.ts";
import { MIS_DEFAULT_COLUMN_IDS } from "./mis-messages-columns.ts";

/**
 * What a customer's CSV contains, and what it must not.
 *
 * <p>In `lib/` rather than private to the route because one of these two functions is the security
 * boundary of the export and the other is money. Both are pure, so both can be asserted directly
 * instead of by reading the route and believing it.
 *
 * <p>Database-free.
 */

/**
 * The columns to write, from a caller-supplied `columns` parameter.
 *
 * <p><strong>Intersected with the customer allow-list, never trusted.</strong> The parameter comes
 * from a URL that anybody holding a session can edit, and the failure mode is not a broken page —
 * it is a file containing our buy price that somebody keeps and forwards.
 *
 * <p>Unknown and forbidden ids are dropped rather than rejected: a stale bookmark naming a column
 * that has since been renamed should still produce the rest of the file, and a 400 would send
 * someone to read a URL to work out why. An empty result falls back to the table's own defaults, so
 * a caller who supplies nothing usable gets a real file rather than a header row on its own.
 *
 * <p>Ordered by the catalogue rather than by the parameter, so two downloads of the same columns
 * have the same shape whatever order the browser sent them in.
 */
export function exportColumns(raw: string | null | undefined): CdrColumn[] {
  const asked = (raw ?? "")
    .split(",")
    .map((id) => id.trim())
    .filter((id) => id && allowedForCustomer(id));

  const wanted = new Set(asked.length ? asked : MIS_DEFAULT_COLUMN_IDS);
  return CDR_COLUMNS.filter((c) => wanted.has(c.id));
}

/** The header row, already escaped. */
export function exportHeader(columns: readonly CdrColumn[]): string {
  return `${columns.map((c) => csv(c.header)).join(",")}\n`;
}

export function exportRow(row: CdrRow, columns: readonly CdrColumn[]): string {
  return `${columns.map((column) => exportCell(column, row)).join(",")}\n`;
}

/**
 * One value as it belongs in a file rather than on a screen.
 *
 * <p>Three deliberate differences from the table:
 *
 * <ul>
 *   <li>Amounts are written as a decimal at <strong>four places, always</strong>, whatever
 *       `smsg.money.scale` says. That setting is a choice about a total somebody reads; a CSV column
 *       is what a spreadsheet sums, and rounding every row before it is added up introduces drift
 *       that grows with the row count.
 *   <li>Timestamps stay as stored — ISO 8601 in UTC, which sorts correctly as text and carries its
 *       own zone. The screen is localised because a person is reading it; the file is the canonical
 *       copy and may be opened in another country.
 *   <li>A message with no receipt yet is written as `PENDING` rather than left blank. An empty cell
 *       reads as missing data, and most rows have no receipt at any given moment.
 * </ul>
 */
export function exportCell(column: CdrColumn, row: CdrRow): string {
  const value = column.from(row);

  if (column.id === "outcome") {
    return csv(value ?? "PENDING");
  }
  if (column.format === "money" || column.format === "rate") {
    return value == null ? "" : (Number(value) / 10_000).toFixed(4);
  }
  return csv(value);
}
