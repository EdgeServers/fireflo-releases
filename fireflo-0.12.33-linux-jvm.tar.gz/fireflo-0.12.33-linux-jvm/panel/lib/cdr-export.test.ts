import { test } from "node:test";
import assert from "node:assert/strict";
import { HEADERS, toCsvLine } from "./cdr-export.ts";
import { parseCsv } from "./csv.ts";
import type { CdrRow } from "./cdr-request.ts";

/**
 * The call-record CSV, pinned.
 *
 * <p>These columns are somebody's spreadsheet. Reordering them, or inserting one in the middle,
 * breaks every formula written against a column letter — silently, in a file nobody re-reads. The
 * list below exists so that a change to the order fails here rather than three weeks later in a
 * reconciliation.
 *
 * <p>Written when the header array moved out of `exports.ts`, which is exactly the kind of change
 * that could have reordered it by accident.
 */

test("the column order is fixed, and new columns go on the end", () => {
  assert.deepEqual(
    [...HEADERS],
    [
      "submitted_at", "gateway_msg_id", "part_no", "part_count", "retry_count", "account_id",
      "system_id", "product", "ingress", "vendor", "source_addr", "dest_addr", "mcc", "mnc",
      "operator_msg_id", "final_state", "dlr_state", "err_code", "final_at", "cost", "price",
      "margin", "currency", "accepted_at", "in_gateway", "dcs", "msg_type", "cost_rate",
      "cost_units", "price_rate", "billed_units", "margin_pct", "margin_status", "cost_rule_id",
      "price_rule_id", "tlvs", "tlvs_received", "tlvs_sent",
    ]
  );
});

test("a row writes exactly as many fields as there are headers", () => {
  //the classic failure: a header is appended and the value is forgotten, so every column after it
  //shifts by one and the file still looks plausible
  const row = {
    submittedAt: "2026-08-18T12:00:00.000Z",
    gatewayMsgId: "gw-1",
    partNo: 1,
    partCount: 1,
    retryCount: 0,
    accountId: "acct-1",
    systemId: "sys-1",
    product: "india-tr",
    ingress: "SMPP",
    vendor: "billbasket",
    sourceAddr: "ACME",
    destAddr: "919999999999",
    mcc: 404,
    mnc: 45,
    operatorMsgId: "op-1",
    finalState: null,
    dlrState: null,
    errCode: null,
    finalAt: null,
    cost: 900,
    price: 1100,
    margin: 200,
    currency: "INR",
    acceptedAt: "2026-08-18T11:59:59.000Z",
    inGateway: "smppserver.in",
    dcs: 0,
    msgType: 0,
    costRate: 900,
    costUnits: 1,
    priceRate: 1100,
    billedUnits: 1,
    marginPct: 18.18,
    marginStatus: "OK",
    costRuleId: "c1",
    priceRuleId: "p1",
    tlvs: null,
    tlvsReceived: null,
    tlvsSent: null,
  } as unknown as CdrRow;

  const parsed = parseCsv(toCsvLine(row));
  assert.equal(parsed.length, 1);
  assert.equal(parsed[0].length, HEADERS.length);
});

test("money is four decimal places, whatever the display scale says", () => {
  //a CSV column is a calculation surface. Rounding each row before a spreadsheet sums them
  //introduces drift that grows with the row count, and the reconciliation people do is against
  //this file rather than against the panel's own totals
  const row = { cost: 900, price: 1100, margin: 200, partNo: 1, partCount: 1, retryCount: 0 } as unknown as CdrRow;
  const cells = parseCsv(toCsvLine(row))[0];
  assert.equal(cells[HEADERS.indexOf("cost")], "0.0900");
  assert.equal(cells[HEADERS.indexOf("price")], "0.1100");
});

test("a message with no receipt is written PENDING rather than left blank", () => {
  //an empty cell reads as missing data, and most rows have no receipt at any given moment
  const row = { finalState: null, partNo: 1, partCount: 1, retryCount: 0 } as unknown as CdrRow;
  const cells = parseCsv(toCsvLine(row))[0];
  assert.equal(cells[HEADERS.indexOf("final_state")], "PENDING");
});

test("a sender ID that looks like a formula is neutralised", () => {
  //source addresses come off the wire. Without the guard, exporting call records is a way to run
  //someone else's spreadsheet formula on your own machine
  const row = { sourceAddr: "=HYPERLINK(\"http://evil\")", partNo: 1, partCount: 1, retryCount: 0 } as unknown as CdrRow;
  const line = toCsvLine(row);
  assert.ok(line.includes("'=HYPERLINK"), `not guarded: ${line}`);
});
