import type { FailureRow } from "./metrics-queries";

/**
 * Hiding a failure the operator has already dealt with, without hiding it happening again.
 *
 * <p>Database-free, so it can be tested directly.
 *
 * <h2>Why this is not a "hide this row" flag</h2>
 *
 * <p>The dashboard's failure card is range-correct: it lists what actually failed inside the window
 * the header selects. So a fixed problem keeps appearing for the rest of that window, which is
 * accurate and useless — the operator already knows.
 *
 * <p>The temptation is a flag that hides the row. The problem with a flag is the case that matters:
 * the same failure starting again a day later. A flag hides that too, silently, and the card exists
 * precisely to surface what nobody is looking for yet.
 *
 * <p>So a dismissal records <strong>an instant</strong>, and a row is hidden only while its newest
 * occurrence is older than that instant. Nothing has to expire it and nobody has to remember to
 * undo it: one more occurrence makes {@link FailureRow.lastSeen} newer than the dismissal and the
 * row comes back on its own.
 *
 * <h2>Why not the count</h2>
 *
 * <p>Storing the count at dismissal and re-showing when it moves looks equivalent and is not. The
 * range is a <em>rolling</em> window recomputed on every request, and the card re-polls every 60
 * seconds — so counts drift as old traffic falls out of the window even when nothing new happens.
 * Rows would resurrect themselves for no reason, and an operator who learns that dismissal does not
 * stick stops using it.
 */
export type Dismissals = Record<string, string>;

/** Where the map lives. `fireflo.*`, matching every other client-side preference in this panel. */
export const FAILURE_DISMISS_KEY = "fireflo.overview.failures.dismissed";

/**
 * How long a dismissal is kept.
 *
 * <p>Thirty days is the widest range the picker offers, so a dismissal older than that can no
 * longer be hiding anything: every row it could match has left every window. Without a bound the
 * map grows for the life of the browser profile on a platform with churny vendor error codes.
 */
export const DISMISS_RETENTION_DAYS = 30;

/**
 * The identity of a failure kind.
 *
 * <p>The same triple the card groups by, so a dismissal is scoped exactly as narrowly as the row an
 * operator was looking at: `FAILED`+`069` from one vendor does not hide `FAILED`+`208` from
 * another. Null and absent collapse to the same empty string, which is right — a row either has a
 * receipt state or it does not, and there is no third case to tell apart.
 */
export function failureKey(row: Pick<FailureRow, "finalState" | "dlrState" | "errCode">): string {
  return `${row.finalState}|${row.dlrState ?? ""}|${row.errCode ?? ""}`;
}

/**
 * Whether this row is currently hidden.
 *
 * <p>The comparison is the whole design. `lastSeen` is the newest occurrence in the window; the
 * stored value is when the operator dismissed it. Dismissing something that has just happened
 * hides it immediately, because the dismissal is later than every occurrence so far. The next
 * occurrence is later than the dismissal, and the row returns.
 *
 * <p>Unparseable or missing entries are treated as not dismissed. Failing towards showing the row
 * is the only safe direction: the cost of a spurious row is noise, and the cost of a wrongly hidden
 * one is a delivery problem nobody sees.
 */
export function isDismissed(row: FailureRow, dismissals: Dismissals): boolean {
  const at = dismissals[failureKey(row)];
  if (!at) {
    return false;
  }
  const dismissedAt = Date.parse(at);
  const lastSeen = Date.parse(row.lastSeen);
  if (Number.isNaN(dismissedAt) || Number.isNaN(lastSeen)) {
    return false;
  }
  return dismissedAt >= lastSeen;
}

/** Records a dismissal at `now`, leaving the rest of the map alone. */
export function dismiss(dismissals: Dismissals, row: FailureRow, now: Date): Dismissals {
  return { ...dismissals, [failureKey(row)]: now.toISOString() };
}

/** Undoes one, by forgetting it entirely rather than by storing a second flag. */
export function restore(dismissals: Dismissals, row: FailureRow): Dismissals {
  const next = { ...dismissals };
  delete next[failureKey(row)];
  return next;
}

/** Drops entries too old to be hiding anything. See {@link DISMISS_RETENTION_DAYS}. */
export function prune(dismissals: Dismissals, now: Date): Dismissals {
  const floor = now.getTime() - DISMISS_RETENTION_DAYS * 86_400_000;
  const next: Dismissals = {};
  for (const [key, at] of Object.entries(dismissals)) {
    const when = Date.parse(at);
    if (!Number.isNaN(when) && when >= floor) {
      next[key] = at;
    }
  }
  return next;
}

/**
 * Reads the map out of whatever `localStorage` held.
 *
 * <p>Total by design: a null, a corrupt string, an array, a JSON object whose values are not
 * strings all come back as an empty map rather than throwing. A browser preference is never worth
 * a blank dashboard, and the failure mode of returning empty is that everything is visible.
 */
export function readDismissals(raw: string | null): Dismissals {
  if (!raw) {
    return {};
  }
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      return {};
    }
    const out: Dismissals = {};
    for (const [key, value] of Object.entries(parsed as Record<string, unknown>)) {
      if (typeof value === "string") {
        out[key] = value;
      }
    }
    return out;
  } catch {
    return {};
  }
}
