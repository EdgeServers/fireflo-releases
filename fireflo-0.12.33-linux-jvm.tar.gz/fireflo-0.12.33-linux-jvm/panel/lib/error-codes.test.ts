import assert from "node:assert/strict";
import { test } from "node:test";
import {
  duplicateCarrierCodes,
  errorCodeProblem,
  formatErrorCodes,
  parseErrorCodes,
} from "./error-codes.ts";

/**
 * These assert one thing above all: **the panel is not stricter than the gateway.**
 *
 * <p>`SmppClientWorker.configDlrsErrorCodeMapping` is the authority. Where a case below looks
 * lenient — a trailing comma, a negative right half — it is lenient because the gateway is, and a
 * refusal here would stop somebody saving a configuration that would have worked.
 */

test("a well-formed pair is accepted -- the check that stops every refusal below being vacuous", () => {
  //without this, a validator that returned a problem for everything would pass all six refusals
  assert.equal(errorCodeProblem({ carrier: "630", ours: "16" }), null);
  assert.deepEqual(parseErrorCodes("630_16"), [{ carrier: "630", ours: "16" }]);
  assert.equal(formatErrorCodes([{ carrier: "630", ours: "16" }]), "630_16");
});

test("the round trip preserves every entry the gateway would have kept", () => {
  const csv = "630_16,1000_1,45_69";
  assert.equal(formatErrorCodes(parseErrorCodes(csv)), csv);
});

test("the shapes the gateway tolerates survive, because refusing them would be stricter", () => {
  //entries are trimmed before splitting, so surrounding space is fine
  assert.deepEqual(parseErrorCodes(" 630_16 , 1000_1 "), [
    { carrier: "630", ours: "16" },
    { carrier: "1000", ours: "1" },
  ]);
  //an empty entry is skipped rather than fatal, so a trailing comma is harmless
  assert.deepEqual(parseErrorCodes("630_16,,"), [{ carrier: "630", ours: "16" }]);
  assert.deepEqual(parseErrorCodes("630_16,"), [{ carrier: "630", ours: "16" }]);
  //Integer.parseInt takes a sign, and the gateway does not judge whether the number is sensible
  assert.equal(errorCodeProblem({ carrier: "630", ours: "-1" }), null);
  assert.equal(errorCodeProblem({ carrier: "630", ours: "+7" }), null);
  //a carrier code is free text: letters are not our business, only the separators are
  assert.equal(errorCodeProblem({ carrier: "E630", ours: "16" }), null);
});

test("a malformed entry is dropped and the rest still apply -- the gateway's own behaviour", () => {
  //the gateway's comment records this being fixed: one bad entry used to abandon the whole map,
  //losing the good entries BEFORE it too
  assert.deepEqual(parseErrorCodes("630_16,rubbish,1000_1"), [
    { carrier: "630", ours: "16" },
    { carrier: "1000", ours: "1" },
  ]);
  //three halves is not two
  assert.deepEqual(parseErrorCodes("630_16_2"), []);
  //an empty half either side
  assert.deepEqual(parseErrorCodes("_16"), []);
  assert.deepEqual(parseErrorCodes("630_"), []);
  //the halves are NOT trimmed by the gateway, so " 16" reaches Integer.parseInt and throws
  assert.deepEqual(parseErrorCodes("630_ 16"), []);
});

test("a non-numeric target is dropped, because it could never have been applied", () => {
  assert.deepEqual(parseErrorCodes("630_sixteen"), []);
  assert.deepEqual(parseErrorCodes("630_16.0"), []);
  assert.equal(
    errorCodeProblem({ carrier: "630", ours: "sixteen" }),
    "The code the customer receives has to be a whole number."
  );
  //past Integer.MAX_VALUE it stops being an int
  assert.deepEqual(parseErrorCodes("630_2147483648"), []);
  assert.deepEqual(parseErrorCodes("630_2147483647"), [{ carrier: "630", ours: "2147483647" }]);
});

test("the separators are refused inside a carrier code, since they would split the entry", () => {
  assert.match(errorCodeProblem({ carrier: "6_30", ours: "16" }) ?? "", /underscore or a comma/);
  assert.match(errorCodeProblem({ carrier: "6,30", ours: "16" }) ?? "", /underscore or a comma/);
});

test("a half-filled row is named, an empty one is not", () => {
  assert.match(errorCodeProblem({ carrier: "630", ours: "" }) ?? "", /customer should receive/);
  assert.match(errorCodeProblem({ carrier: "", ours: "16" }) ?? "", /carrier sends/);
  //the empty row at the foot of the table is not an error, and `format` drops it
  assert.equal(errorCodeProblem({ carrier: "", ours: "" }), null);
  assert.equal(formatErrorCodes([{ carrier: "", ours: "" }]), "");
});

test("a repeated carrier code keeps the last, matching HashMap.put -- and is reported", () => {
  assert.deepEqual(parseErrorCodes("630_16,630_1"), [{ carrier: "630", ours: "1" }]);
  assert.deepEqual(duplicateCarrierCodes([
    { carrier: "630", ours: "16" },
    { carrier: "630", ours: "1" },
  ]), ["630"]);
  assert.deepEqual(duplicateCarrierCodes([
    { carrier: "630", ours: "16" },
    { carrier: "1000", ours: "1" },
  ]), []);
});

test("an absent value is an empty list rather than a thrown error", () => {
  assert.deepEqual(parseErrorCodes(null), []);
  assert.deepEqual(parseErrorCodes(undefined), []);
  assert.deepEqual(parseErrorCodes(""), []);
  assert.deepEqual(parseErrorCodes("   "), []);
});
