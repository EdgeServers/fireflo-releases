/**
 * CSV in both directions.
 *
 * <p>The writer lived privately inside `lib/exports.ts`; it moved here when a second exporter
 * appeared, and gained a reader.
 *
 * <p>No filesystem and no database imports, so a route can use it directly.
 */

/** Characters that make a spreadsheet treat a cell as a formula rather than as text. */
const DANGEROUS = /^[=+\-@\t\r]/;

/**
 * One value as a CSV field.
 *
 * <p>RFC 4180 quoting, plus a leading apostrophe on anything starting `=`, `+`, `-`, `@`, TAB or CR.
 * Excel and Sheets execute those, and these values come off the wire — a source address is whatever
 * the customer put there.
 */
export function csv(value: unknown): string {
  if (value == null) {
    return "";
  }
  let text = String(value);
  if (DANGEROUS.test(text)) {
    text = `'${text}`;
  }
  return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

/**
 * Undoes {@link csv}'s guard apostrophe — and only where it was ours to undo.
 *
 * <p>This is the most important function in this file. The exporter writes `+61` as `'+61`; reading
 * that straight back stores a condition value of `'+61`, which is a phone-prefix that matches
 * nothing, so the traffic falls through to the catch-all at the catch-all's price. Entirely
 * self-inflicted, entirely silent, and the numbers still look plausible.
 *
 * <p>There is no test runner in this project, so it is protected structurally instead: {@link
 * parseCsv} returns rows already unguarded and there is no path that hands a raw cell to a caller.
 */
export function unguard(cell: string): string {
  return cell.startsWith("'") && DANGEROUS.test(cell.slice(1)) ? cell.slice(1) : cell;
}

/**
 * RFC 4180: quoted fields, doubled quotes inside them, CRLF or LF, embedded newlines.
 *
 * <p>Cells come back **already unguarded** — see {@link unguard} for why that is not optional.
 *
 * @throws Error naming the line when a quoted field is never closed
 */
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  let line = 1;
  //nothing was written yet on this row, so a trailing newline does not produce a phantom empty row
  let started = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];

    if (quoted) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          cell += '"';
          i++;
        } else {
          quoted = false;
        }
      } else {
        if (ch === "\n") {
          line++;
        }
        cell += ch;
      }
      continue;
    }

    if (ch === '"' && cell === "") {
      quoted = true;
      started = true;
    } else if (ch === ",") {
      row.push(unguard(cell));
      cell = "";
      started = true;
    } else if (ch === "\r") {
      //swallowed; the \n that follows ends the row
    } else if (ch === "\n") {
      line++;
      if (started || cell !== "") {
        row.push(unguard(cell));
        rows.push(row);
      }
      row = [];
      cell = "";
      started = false;
    } else {
      cell += ch;
      started = true;
    }
  }

  if (quoted) {
    throw new Error(`A quoted value is never closed — check line ${line}.`);
  }
  if (started || cell !== "") {
    row.push(unguard(cell));
    rows.push(row);
  }
  return rows;
}
