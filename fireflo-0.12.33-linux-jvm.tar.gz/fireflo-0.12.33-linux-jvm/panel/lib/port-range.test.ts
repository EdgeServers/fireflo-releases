import { strict as assert } from "node:assert";
import { test } from "node:test";
import {
  describePortProblem,
  describeRange,
  nextFreePort,
  parsePortRange,
} from "./port-range.ts";

/**
 * The panel's copy of the gateway's parsing rules, and the tests exist mostly to keep the two from
 * drifting. A panel that rejected a port the gateway would accept is a form nobody can get past; one
 * that accepted a port the gateway refuses saves a listener that never starts.
 */

test("no band declared means nothing is offered and nothing is refused", () => {
  for (const raw of [null, undefined, "", "   "]) {
    assert.equal(parsePortRange(raw), null);
  }
  assert.equal(nextFreePort(null, []), null);
  //the port an existing deployment is already on
  assert.equal(describePortProblem(27777, null, []), null);
  assert.match(describeRange(null), /does not restrict/);
});

test("a band parses, including the ends", () => {
  const range = parsePortRange("2775-2799");

  assert.deepEqual(range, { low: 2775, high: 2799 });
  assert.equal(describePortProblem(2775, range, []), null);
  assert.equal(describePortProblem(2799, range, []), null);
  assert.match(describePortProblem(2800, range, [])!, /outside 2775-2799/);
  assert.match(describePortProblem(27777, range, [])!, /never start/);
});

test("a backwards band is read the way it was meant", () => {
  //matches SmppPortRange on the gateway: refusing to understand 2799-2775 would cost a listener
  //over the order of two numbers
  assert.deepEqual(parsePortRange("2799-2775"), { low: 2775, high: 2799 });
});

test("an unparseable band checks nothing rather than refusing everything", () => {
  assert.equal(parsePortRange("two thousand"), null);
  assert.equal(parsePortRange("0-100"), null);
  assert.equal(parsePortRange("2775-70000"), null);
});

test("a single port is a band of one", () => {
  const range = parsePortRange("2775");

  assert.deepEqual(range, { low: 2775, high: 2775 });
  assert.equal(nextFreePort(range, []), 2775);
  assert.equal(nextFreePort(range, [2775]), null);
  assert.match(describeRange(range), /one listener port: 2775/);
});

test("the next free port is the lowest, so listeners stay contiguous", () => {
  const range = parsePortRange("2775-2779");

  assert.equal(nextFreePort(range, []), 2775);
  assert.equal(nextFreePort(range, [2775, 2776]), 2777);
  //a gap left by a deleted listener is reused before the band grows
  assert.equal(nextFreePort(range, [2775, 2777, 2778]), 2776);
});

test("a full band offers nothing rather than something already taken", () => {
  const range = parsePortRange("2775-2777");

  assert.equal(nextFreePort(range, [2775, 2776, 2777]), null);
});

test("a port already in use is refused even inside the band", () => {
  const range = parsePortRange("2775-2799");

  assert.match(describePortProblem(2775, range, [2775])!, /already belongs/);
});

test("a nonsense port is refused before the band is consulted", () => {
  assert.match(describePortProblem(0, null, [])!, /between 1 and 65535/);
  assert.match(describePortProblem(70000, null, [])!, /between 1 and 65535/);
  assert.match(describePortProblem(1.5, null, [])!, /whole number/);
});
