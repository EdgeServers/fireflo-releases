import { afterEach, test } from "node:test";
import assert from "node:assert/strict";
import { clientIp, clientUserAgent } from "./client-ip.ts";

/**
 * Which entry of `X-Forwarded-For` is the caller, and whether the header is read at all.
 *
 * <p>This took the left-most entry until an audit pointed out the comment justifying it had the
 * reasoning backwards. Left-most is only trustworthy under `$remote_addr`, which overwrites; the
 * common `$proxy_add_x_forwarded_for` appends, so left-most was whatever the client typed — and
 * both access logs, plus the stolen-link detection that compares a request address against a
 * redemption address, were recording forged values.
 *
 * <p>A second audit (CP-S3) pointed out that with no proxy in front, EVERY entry is what the client
 * typed, and the right-most one is just a different forgery. So the header is now read only when
 * `TRUSTED_PROXY_HOPS` says a proxy exists.
 *
 * <p>Every case here is written from an attacker's side of it: the header always contains a
 * plausible forgery, and the test is whether that forgery is what comes back.
 */

function req(headers: Record<string, string>): { headers: Headers } {
  return { headers: new Headers(headers) };
}

const saved = process.env.TRUSTED_PROXY_HOPS;

function hops(value: string | undefined): void {
  if (value === undefined) {
    delete process.env.TRUSTED_PROXY_HOPS;
  } else {
    process.env.TRUSTED_PROXY_HOPS = value;
  }
}

afterEach(() => hops(saved));

test("with no proxy configured, a forwarding header is the visitor's and is ignored", () => {
  hops(undefined);
  //a LAN install: the panel's port is exposed directly, so nobody but the caller wrote these. Were
  //either honoured, a caller could choose a fresh lockout key per request and feed fail2ban an
  //arbitrary address to ban
  assert.equal(clientIp(req({ "x-forwarded-for": "1.2.3.4, 203.0.113.9" })), null);
  assert.equal(clientIp(req({ "x-real-ip": "203.0.113.9" })), null);
});

test("an empty or zero TRUSTED_PROXY_HOPS is the same as none", () => {
  //the e2e rig pins the variable empty to keep .env.local out; it must read as "no proxy"
  hops("");
  assert.equal(clientIp(req({ "x-forwarded-for": "203.0.113.9" })), null);
  hops("0");
  assert.equal(clientIp(req({ "x-forwarded-for": "203.0.113.9" })), null);
});

test("a value that is not a whole number is treated as no proxy, never as one", () => {
  hops("yes");
  assert.equal(clientIp(req({ "x-forwarded-for": "203.0.113.9" })), null);
  hops("-1");
  assert.equal(clientIp(req({ "x-forwarded-for": "203.0.113.9" })), null);
});

test("with one hop configured, the forged entry a client prepends is not what comes back", () => {
  hops("1");
  //what nginx produces with $proxy_add_x_forwarded_for when the client sent its own header
  const ip = clientIp(req({ "x-forwarded-for": "1.2.3.4, 203.0.113.9" }));

  assert.equal(ip, "203.0.113.9", "the hop nginx observed, not the one the client claimed");
});

test("a whole forged chain still yields the address the proxy saw", () => {
  hops("1");
  const ip = clientIp(req({
    "x-forwarded-for": "10.0.0.1, 10.0.0.2, 10.0.0.3, 198.51.100.7",
  }));

  assert.equal(ip, "198.51.100.7");
});

test("N hops configured takes the Nth entry from the right", () => {
  //a CDN in front of nginx: the CDN appended the client's address, nginx appended the CDN's
  hops("2");
  assert.equal(
    clientIp(req({ "x-forwarded-for": "1.2.3.4, 203.0.113.9, 192.0.2.10" })),
    "203.0.113.9",
    "the entry the outermost trusted proxy observed"
  );
  hops("3");
  assert.equal(clientIp(req({ "x-forwarded-for": "1.2.3.4, 203.0.113.9, 192.0.2.10" })), "1.2.3.4");
});

test("an overwriting proxy leaves one entry, which is both ends at once", () => {
  hops("1");
  //proxy_set_header X-Forwarded-For $remote_addr — the recipe the old comment assumed
  assert.equal(clientIp(req({ "x-forwarded-for": "203.0.113.9" })), "203.0.113.9");
});

test("whitespace and empty entries do not shift which hop is chosen", () => {
  hops("1");
  assert.equal(clientIp(req({ "x-forwarded-for": " 1.2.3.4 ,  , 203.0.113.9 " })), "203.0.113.9");
});

test("a chain shorter than the configured trust falls back rather than returning nothing", () => {
  //a misconfiguration, not an attack: fewer proxies than configured means the left-most entry is
  //the closest thing to an answer, and returning null would lose the address entirely
  hops("2");
  assert.equal(clientIp(req({ "x-forwarded-for": "203.0.113.9" })), "203.0.113.9");
});

test("x-real-ip is the fallback, and only when there is no chain", () => {
  hops("1");
  assert.equal(clientIp(req({ "x-real-ip": "203.0.113.9" })), "203.0.113.9");
  assert.equal(
    clientIp(req({ "x-forwarded-for": "1.2.3.4, 203.0.113.9", "x-real-ip": "9.9.9.9" })),
    "203.0.113.9",
    "a chain-aware header wins, so a forged x-real-ip cannot displace it"
  );
});

test("no headers at all is null, not a guess", () => {
  hops("1");
  assert.equal(clientIp(req({})), null);
  assert.equal(clientIp(req({ "x-forwarded-for": "  ,  " })), null);
});

test("a user agent is truncated so one request cannot break an append", () => {
  assert.equal(clientUserAgent(req({ "user-agent": "curl/8.0" })), "curl/8.0");
  assert.equal(clientUserAgent(req({})), null);

  const long = clientUserAgent(req({ "user-agent": "x".repeat(500) })) ?? "";
  assert.equal(long.length, 256);
  assert.ok(long.endsWith("..."));
});
