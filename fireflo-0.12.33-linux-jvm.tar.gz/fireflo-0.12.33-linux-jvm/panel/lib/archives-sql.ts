import type { ArchiveAccountFilters, ArchiveEntryFilters } from "./archives-request.ts";
import type { ArchiveCursor, ArchivePartition } from "./archives-types.ts";

/**
 * The SQL the Archives report reads, with no database import — so `archives-sql.test.ts` can assert
 * it without a connection, as `reconcile-sql.ts` is asserted.
 *
 * <p>Every caller value is a bind parameter; nothing a browser sends reaches the SQL text. The column
 * names are the gateway's V1.93.0 (`queue_archive`, `queue_archive_batch`, `queue_archive_summary`),
 * and this file is the one place they are spelled.
 */

/** The most entry rows one call may return. The route clamps a browser page far below this. */
export const MAX_ENTRY_BATCH = 1_000;

/** By account is grouped from the summary, which is small; this only bounds a pathological answer. */
export const MAX_ACCOUNT_ROWS = 1_000;

interface Built {
  sql: string;
  params: unknown[];
}

function binder(params: unknown[]) {
  return (value: unknown): string => {
    params.push(value);
    return `$${params.length}`;
  };
}

/**
 * One page of archived entries, newest first, keyset on `(archived_at, archive_id)`.
 *
 * <p>The time bound is what lets Postgres prune to the months asked for; the identifier filters are
 * what reach the `(account_id|worker|system_id, archived_at)` indexes and `(batch_id)`.
 */
export function entriesSql(
  filters: ArchiveEntryFilters,
  opts: { limit: number; cursor?: ArchiveCursor | null }
): Built {
  const params: unknown[] = [];
  const bind = binder(params);
  const where: string[] = [];

  if (filters.since) {
    where.push(`archived_at >= ${bind(filters.since)}`);
  }
  if (filters.until) {
    where.push(`archived_at < ${bind(filters.until)}`);
  }
  for (const [column, value] of [
    ["account_id", filters.accountId],
    ["worker", filters.worker],
    ["system_id", filters.systemId],
    ["store", filters.store],
  ] as const) {
    if (value) {
      where.push(`${column} = ${bind(value)}`);
    }
  }
  if (filters.batchId) {
    where.push(`batch_id = ${bind(filters.batchId)}::uuid`);
  }
  if (filters.gatewayMsgId) {
    //either id: the archive keeps the gateway's message id and the serial it travelled under, and
    //an operator pasting one from a customer's complaint does not know which it is
    const n = bind(filters.gatewayMsgId);
    where.push(`(gateway_msg_id = ${n} OR serial = ${n})`);
  }
  if (opts.cursor) {
    const ts = bind(opts.cursor.archivedAt);
    const id = bind(opts.cursor.id);
    where.push(`(archived_at, archive_id) < (${ts}::timestamptz, ${id}::bigint)`);
  }
  const size = Math.min(Math.max(1, Math.floor(opts.limit)), MAX_ENTRY_BATCH);
  const limit = bind(size + 1);

  return {
    sql: `SELECT archive_id::text AS archive_id, archived_at, batch_id::text AS batch_id, store, sub_store, kind,
            worker, account_id, system_id, gateway_msg_id, serial, source_addr, dest_addr, product,
            price::text AS price, parts, body, retries, created_at, reason, note, actor, refunded, receipt_sent
       FROM queue_archive
      ${where.length ? `WHERE ${where.join(" AND ")}` : ""}
      ORDER BY archived_at DESC, archive_id DESC
      LIMIT ${limit}`,
    params,
  };
}

/**
 * The monthly partitions as the catalogue lists them: name, bound and size. The default partition
 * is among them, with the bound `DEFAULT`.
 */
export const PARTITION_CATALOG_SQL = `SELECT c.relname AS relname,
        pg_get_expr(c.relpartbound, c.oid) AS bound,
        pg_total_relation_size(c.oid)::text AS size
   FROM pg_inherits i
   JOIN pg_class c ON c.oid = i.inhrelid
  WHERE i.inhparent = 'queue_archive'::regclass`;

/**
 * Rows, first and last per partition, in one pass grouped by `tableoid` rather than one statement per
 * partition — no partition name is ever spliced into SQL text.
 */
export const PARTITION_COUNTS_SQL = `SELECT c.relname AS relname, s.n::text AS rows, s.first_at, s.last_at
   FROM (SELECT tableoid, count(*) AS n, min(archived_at) AS first_at, max(archived_at) AS last_at
           FROM queue_archive GROUP BY tableoid) s
   JOIN pg_class c ON c.oid = s.tableoid`;

/**
 * Months whose detail rows were purged, from the summary the purge stamps and keeps.
 *
 * <p>The row count is the summary's message count for the month, not a sum of `purged_rows`: the
 * purge only proceeds when the partition's count equals that sum (it reconciles first), so the two
 * are the same number, and this one does not depend on how `purged_rows` is spread across the
 * month's summary rows.
 */
export const PURGED_MONTHS_SQL = `SELECT to_char(date_trunc('month', day), 'YYYY-MM') AS month,
        max(purged_at) AS purged_at, sum(messages)::text AS rows
   FROM queue_archive_summary
  WHERE purged_at IS NOT NULL
  GROUP BY 1`;

/** `YYYY-MM` from a partition bound, or null for `DEFAULT` and anything unrecognised. */
export function monthOfBound(bound: string | null | undefined): string | null {
  const m = /FROM\s*\('(\d{4}-\d{2})-\d{2}/i.exec(bound ?? "");
  return m ? m[1] : null;
}

export interface PartitionCatalogRow {
  relname: string;
  bound: string | null;
  size: string | null;
}

export interface PartitionCountRow {
  relname: string;
  rows: string;
  first_at: Date | string | null;
  last_at: Date | string | null;
}

export interface PurgedMonthRow {
  month: string;
  purged_at: Date | string | null;
  rows: string | null;
}

const iso = (v: Date | string | null | undefined): string | null =>
  v == null ? null : v instanceof Date ? v.toISOString() : new Date(v).toISOString();

/**
 * Partitions and purged months as one list, newest month first, the default partition last.
 *
 * <p>A month with a partition that the summary also calls purged keeps its partition row — the
 * detail is still there, whatever the summary says — and the purge stamp rides along so the page
 * can show both.
 */
export function mergePartitions(
  catalog: PartitionCatalogRow[],
  counts: PartitionCountRow[],
  purged: PurgedMonthRow[]
): ArchivePartition[] {
  const byName = new Map(counts.map((c) => [c.relname, c]));
  const purgedByMonth = new Map(purged.map((p) => [p.month, p]));
  const out: ArchivePartition[] = [];
  const seen = new Set<string>();

  for (const part of catalog) {
    const month = monthOfBound(part.bound);
    const count = byName.get(part.relname);
    const stamp = month ? purgedByMonth.get(month) : undefined;
    if (month) {
      seen.add(month);
    }
    out.push({
      month,
      rows: count ? Number(count.rows) : 0,
      firstAt: iso(count?.first_at),
      lastAt: iso(count?.last_at),
      sizeBytes: part.size != null ? Number(part.size) : null,
      purgedAt: stamp ? iso(stamp.purged_at) : null,
      purgedRows: stamp?.rows != null ? Number(stamp.rows) : null,
    });
  }
  for (const p of purged) {
    if (seen.has(p.month)) {
      continue;
    }
    out.push({
      month: p.month,
      rows: null,
      firstAt: null,
      lastAt: null,
      sizeBytes: null,
      purgedAt: iso(p.purged_at),
      purgedRows: p.rows != null ? Number(p.rows) : null,
    });
  }
  return out.sort((a, b) => {
    if (a.month == null) return 1;
    if (b.month == null) return -1;
    return b.month.localeCompare(a.month);
  });
}

/**
 * Per account over a period, from `queue_archive_summary` — never from the detail rows, so the totals
 * are the same before and after a purge. Held and purged split the message count by whether the
 * day's detail rows still exist.
 */
export function accountsSql(filters: ArchiveAccountFilters): Built {
  const params: unknown[] = [];
  const bind = binder(params);
  const where: string[] = [];
  if (filters.from) {
    where.push(`day >= ${bind(filters.from)}::date`);
  }
  if (filters.to) {
    where.push(`day <= ${bind(filters.to)}::date`);
  }
  if (filters.accountId) {
    where.push(`account_id = ${bind(filters.accountId)}`);
  }
  if (filters.store) {
    where.push(`store = ${bind(filters.store)}`);
  }
  const limit = bind(MAX_ACCOUNT_ROWS);
  return {
    sql: `SELECT account_id,
            sum(messages)::text AS messages,
            sum(refunded)::text AS refunded,
            sum(receipts_sent)::text AS receipts_sent,
            sum(price_total)::text AS price_total,
            min(first_at) AS first_at,
            max(last_at) AS last_at,
            coalesce(sum(messages) FILTER (WHERE purged_at IS NULL), 0)::text AS held,
            coalesce(sum(messages) FILTER (WHERE purged_at IS NOT NULL), 0)::text AS purged
       FROM queue_archive_summary
      ${where.length ? `WHERE ${where.join(" AND ")}` : ""}
      GROUP BY account_id
      ORDER BY sum(messages) DESC, account_id
      LIMIT ${limit}`,
    params,
  };
}

/** The latest runs, newest first: cleans, purges and receipt re-pushes. */
export function batchesSql(opts: { store?: string | null; batchId?: string | null; limit: number }): Built {
  const params: unknown[] = [];
  const bind = binder(params);
  const where: string[] = [];
  if (opts.store) {
    where.push(`store = ${bind(opts.store)}`);
  }
  if (opts.batchId) {
    where.push(`batch_id = ${bind(opts.batchId)}::uuid`);
  }
  const limit = bind(Math.min(Math.max(1, Math.floor(opts.limit)), 200));
  return {
    sql: `SELECT batch_id::text AS batch_id, started_at, finished_at, store, selector, actor, reason, note,
            matched, archived, refunded, receipts_sent, failed
       FROM queue_archive_batch
      ${where.length ? `WHERE ${where.join(" AND ")}` : ""}
      ORDER BY started_at DESC
      LIMIT ${limit}`,
    params,
  };
}

/** The partition-tab sentence for one row, shared by the page and its test. */
export function partitionLine(p: ArchivePartition): string {
  if (p.rows == null) {
    return `purged${p.purgedAt ? ` on ${p.purgedAt.slice(0, 10)}` : ""}, ${p.purgedRows ?? 0} rows`;
  }
  return `${p.rows} rows`;
}
