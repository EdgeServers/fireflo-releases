import { strict as assert } from "node:assert";
import { test } from "node:test";
import { liveStats, submittedLabel, throughputTone } from "./worker-verdict.ts";
import type { HealthWorker } from "./health-types.ts";

function worker(over: Partial<HealthWorker> = {}): HealthWorker {
  return { name: "smppclient.v1", type: "smppclient", accepting: true, paused: false,
    suspended_manually: false, suspended_automatically: false, queue_depth: 0, ...over };
}

function tile(stats: ReturnType<typeof liveStats>, label: string) {
  return stats.find((s) => s.label === label);
}

test("the submitted counter names the direction the gateway actually counted", () => {
  //Sessions.submitted() reads getTxSubmitSM outbound and getRxSubmitSM inbound, so a listener's
  //figure is traffic arriving from customers. Calling it "sent" described the opposite
  assert.equal(submittedLabel(true), "Sent on these binds");
  assert.equal(submittedLabel(false), "Received on these binds");
});

test("the counter says it resets, because it is a per-session gauge", () => {
  const stats = liveStats(worker({ submitted: 4_200 }), true);
  const sent = tile(stats, "Sent on these binds");
  assert.equal(sent?.value, 4_200);
  assert.match(sent?.note ?? "", /[Rr]esets/);
});

test("a vendor short of its configured binds is amber, not red", () => {
  const stats = liveStats(worker({ bound: 3 }), true, false, { kind: "target", value: 5 });
  const binds = tile(stats, "Binds");
  assert.equal(binds?.tone, "warn");
  assert.match(binds?.note ?? "", /2 of 5 configured binds are not up/);
});

test("a vendor at its configured bind count is good", () => {
  const stats = liveStats(worker({ bound: 5 }), true, false, { kind: "target", value: 5 });
  assert.equal(tile(stats, "Binds")?.tone, "good");
  assert.match(tile(stats, "Binds")?.note ?? "", /of 5 configured/);
});

test("one missing bind reads as singular", () => {
  const stats = liveStats(worker({ bound: 4 }), true, false, { kind: "target", value: 5 });
  assert.match(tile(stats, "Binds")?.note ?? "", /1 of 5 configured bind is not up/);
});

test("a quiet listener under its ceiling is not a shortfall", () => {
  //srv.maxConnections is a limit, not a target -- treating it like one would report every
  //listener that is not full as broken
  const stats = liveStats(worker({ bound: 12 }), false, false, { kind: "ceiling", value: 50 });
  const bound = tile(stats, "Bound customers");
  assert.equal(bound?.tone, "good");
  assert.equal(bound?.note, "of 50 allowed");
});

test("a vendor with no binds is still the loudest reading", () => {
  const stats = liveStats(worker({ bound: 0 }), true, false, { kind: "target", value: 5 });
  assert.equal(tile(stats, "Binds")?.tone, "bad");
  assert.equal(tile(stats, "Binds")?.note, "Nothing can be sent");
});

test("a listener with no customers bound is merely quiet", () => {
  const stats = liveStats(worker({ bound: 0 }), false);
  assert.equal(tile(stats, "Bound customers")?.tone, "plain");
});

test("with no capacity configured the tile says nothing about one", () => {
  const stats = liveStats(worker({ bound: 5 }), true);
  assert.equal(tile(stats, "Binds")?.tone, "good");
  assert.equal(tile(stats, "Binds")?.note, undefined);
});

test("throughput carries its averaging window", () => {
  const { tone, note } = throughputTone(worker({ tps_measured: 40, tps_limit: 500 }), false, 10);
  assert.equal(tone, "plain");
  assert.equal(note, "Mean over 10s");
});

test("a stall outranks the window note", () => {
  //both numbers look ordinary alone; together they mean messages are waiting and none are moving
  const { tone, note } = throughputTone(
    worker({ tps_measured: 0, queue_depth: 900 }), false, 10
  );
  assert.equal(tone, "bad");
  assert.match(note ?? "", /900 waiting and nothing moving/);
});

test("a gateway that reports no window still renders the tile", () => {
  const { tone, note } = throughputTone(worker({ tps_measured: 40, tps_limit: 500 }), false, null);
  assert.equal(tone, "plain");
  assert.equal(note, undefined);
});
