import type { PoolClient } from "pg";
import { configQuery, inTransaction } from "@/lib/config-db";
import { auditConfigChange } from "@/lib/config-audit";
import { ConfigRefusal } from "@/lib/config-guard";
import { PRODUCT_SLUG_MAX, type Product, type ProductInput, type ProductSummary } from "@/lib/product-types";

/**
 * The product catalogue.
 *
 * <p>Server-only: importing this pulls `pg`. The types live in `product-types.ts` so a client
 * component can hold them without dragging a Postgres driver into the browser.
 *
 * <p>The gateway reads two things here. `enabled`: the enabled rows are its catalogue, and a product
 * with no enabled row is refused as unknown when a listener requires a product -- the guard against
 * `system_type: premum`. And `whitelist_enabled`, which decides whether this product's traffic is
 * checked against the sender ID and content whitelists at all. Label and description are for people.
 *
 * <p>Since gateway migration V1.56.0 every product a login, rate rule, sender ID, template or policy
 * names is a foreign key to this table, ON DELETE RESTRICT. Names that were in use without a row were
 * backfilled DISABLED, which left every verdict exactly as it was.
 */

interface ProductRow {
  name: string;
  label: string | null;
  description: string | null;
  enabled: boolean;
  whitelist_enabled: boolean;
  rule_count: number;
  scope_count: number;
  credential_count: number;
  updated_at: Date | null;
}

/**
 * Refuses a write that names a product the catalogue does not have.
 *
 * <p>Since gateway migration V1.56.0 every product a login, rate rule, sender ID, template or policy
 * names is a foreign key to `app_product`, so the write would fail anyway; asking first is what turns
 * a constraint name into a sentence. Deliberately no "create it for them": the catalogue is what
 * catches `premum` for `premium`, and a write that quietly added it would undo that.
 *
 * <p>Blank names are skipped -- `''` means "any product" or "no product", depending on the table.
 *
 * @param client the transaction's client when the caller is in one, so the check sees its writes
 * @throws ConfigRefusal naming every product that is missing
 */
export async function assertProductsCatalogued(
  names: Iterable<string | null | undefined>,
  client?: PoolClient
): Promise<void> {
  const wanted = [...new Set([...names].map((n) => n?.trim() ?? "").filter(Boolean))];
  if (!wanted.length) {
    return;
  }
  const sql = `SELECT n FROM unnest($1::text[]) AS n WHERE NOT EXISTS (SELECT 1 FROM app_product WHERE name = n)`;
  const missing = client
    ? (await client.query<{ n: string }>(sql, [wanted])).rows.map((r) => r.n)
    : (await configQuery<{ n: string }>(sql, [wanted])).map((r) => r.n);
  if (missing.length) {
    const list = missing.map((m) => `'${m}'`).join(", ");
    throw new ConfigRefusal(
      `${missing.length === 1 ? `There is no product ${list}` : `There are no products ${list}`} in the catalogue. `
        + "Add it under Products first, or choose one that is there."
    );
  }
}

/** Whether a delete went through, and if not, why not. */
export type DeleteResult =
  | { kind: "deleted" }
  | { kind: "not-found" }
  | { kind: "in-use"; rules: number; scopes: number; credentials: number; allowedBy: number; registrations: number };

/**
 * The catalogue, with how much is riding on each row.
 *
 * <p>The counts are the point: a product with three rate rules across two scopes and a credential
 * pointing at it is not the same object as one somebody typed and forgot, and the list has to say
 * which is which before anyone reaches for delete.
 *
 * <p>`rule_count` counts only rules *restricted* to this product. Rules with no product price it as
 * well — they price everything — and are deliberately not counted here, because counting them would
 * make every product look equally busy.
 */
export async function listProducts(): Promise<ProductSummary[]> {
  const rows = await configQuery<ProductRow>(
    `SELECT p.name, p.label, p.description, p.enabled, p.whitelist_enabled, p.updated_at,
            COALESCE(r.rules, 0)::int  AS rule_count,
            COALESCE(r.scopes, 0)::int AS scope_count,
            COALESCE(c.creds, 0)::int  AS credential_count
       FROM app_product p
       LEFT JOIN (SELECT product, count(*) AS rules, count(DISTINCT scope) AS scopes
                    FROM app_rate_rule
                   WHERE product IS NOT NULL AND product <> ''
                   GROUP BY product) r ON r.product = p.name
       LEFT JOIN (SELECT product, count(*) AS creds
                    FROM app_credential
                   WHERE product IS NOT NULL AND product <> ''
                   GROUP BY product) c ON c.product = p.name
      ORDER BY p.name`
  );
  return rows.map(toSummary);
}

/**
 * Products in use that have no catalogue row.
 *
 * <p>This is the compensating control for deliberately having no foreign key from
 * `app_rate_rule.product`. Without it, a product that exists only as a string on a rule or a
 * credential is invisible to this panel — which on day one is every product there is.
 *
 * <p>Never sourced from `cdr_submit`: a customer binding with a typo'd `system_type` writes that typo
 * onto every message they send, and listing it here would present their mistake as our
 * configuration.
 */
export async function listOrphanProducts(): Promise<string[]> {
  const rows = await configQuery<{ product: string }>(
    `SELECT product FROM (
       SELECT DISTINCT product FROM app_rate_rule WHERE product IS NOT NULL AND product <> ''
       UNION
       SELECT DISTINCT product FROM app_credential WHERE product IS NOT NULL AND product <> ''
       EXCEPT
       SELECT name FROM app_product
     ) t ORDER BY product`
  );
  return rows.map((r) => r.product);
}

export async function getProduct(name: string): Promise<Product | null> {
  const rows = await configQuery<ProductRow>(
    `SELECT name, label, description, enabled, whitelist_enabled, updated_at,
            0 AS rule_count, 0 AS scope_count, 0 AS credential_count
       FROM app_product WHERE name = $1`,
    [name]
  );
  return rows.length ? toSummary(rows[0]) : null;
}

/**
 * Creates a product, giving it a code nothing else is using.
 *
 * <p>The code is reserved and inserted in one transaction, so two operators creating a product at
 * the same moment cannot be handed the same one.
 *
 * <p><strong>The taken set is the catalogue plus the orphans</strong>, compared case-insensitively.
 * Both halves are load bearing. A product that exists only as a string on rate rules has no
 * catalogue row and is completely real to the gateway — slugging a new product onto it would mean
 * the new product silently inherits an existing tariff from the moment it is created, priced by
 * rules nobody associated with it. And case matters because the gateway treats `premium` and
 * `Premium` as two products while a human scanning a list sees one.
 *
 * @param base the code the operator previewed or overrode; a suffix is added only if it is taken
 * @returns the code actually used, which the caller must show — it may not be the one asked for
 */
export async function createProduct(input: ProductInput, base: string): Promise<string> {
  return inTransaction(async (client) => {
    const taken = await client.query<{ taken: string }>(
      `SELECT lower(name) AS taken FROM app_product
       UNION
       SELECT DISTINCT lower(btrim(product)) FROM app_rate_rule
        WHERE btrim(coalesce(product, '')) <> ''
       UNION
       SELECT DISTINCT lower(btrim(product)) FROM app_credential
        WHERE btrim(coalesce(product, '')) <> ''`
    );
    const used = new Set(taken.rows.map((r) => r.taken));
    const name = nextFree(base, used);

    await client.query(
      `INSERT INTO app_product (name, label, description, enabled, whitelist_enabled, updated_at)
       VALUES ($1, $2, $3, $4, $5, now())`,
      //an empty box means "unset", not "set to the empty string", as saveWorker already has it
      [name, input.label?.trim() || null, input.description?.trim() || null, input.enabled,
        input.whitelistEnabled]
    );
    return name;
  }).then(async (name) => {
    await auditConfigChange({ domain: "product", name, action: "create", after: productSummary(input) });
    return name;
  });
}

function productSummary(input: ProductInput): Record<string, unknown> {
  return {
    label: input.label?.trim() || null,
    description: input.description?.trim() || null,
    enabled: input.enabled,
    whitelistEnabled: input.whitelistEnabled,
  };
}

/**
 * Describes the product at this name, creating the row if there is not one.
 *
 * <p><strong>Never renames.</strong> `name` is the value every rate rule, every credential and every
 * historical call record compares against, and none of them is a foreign key that could cascade —
 * so a "rename" would leave the rules on a product that no longer exists and give the new one
 * nothing. The name comes from the URL and is written as given.
 *
 * <p><strong>An upsert, not an update, and that is the whole point.</strong> A product can be in use
 * with no row here at all: `app_product` is optional decoration over strings the gateway resolves
 * without it, so anything imported, bootstrapped or left behind by a delete exists only on a rule or
 * a login. Those are exactly the ones {@link listOrphanProducts} surfaces for the operator to
 * describe — and while this was an UPDATE, describing one matched no row and answered "Nothing named
 * 'x'." The one button whose purpose is describing a row-less product failed for the reason it
 * existed.
 *
 * <p>Creating here rather than routing that button to {@code createProduct} is deliberate: create
 * derives the code from the display name and reserves the first free one, which for an adoption would
 * mint a *second* product and leave every rule still pointing at the first. The name has to survive
 * byte for byte.
 *
 * @returns true always; the boolean is kept so the route can go on distinguishing a write from a
 *     failure, and so PATCH's genuine 404 keeps its meaning
 */
export async function updateProduct(input: ProductInput): Promise<boolean> {
  const rows = await configQuery<{ name: string; created: boolean }>(
    `INSERT INTO app_product (name, label, description, enabled, whitelist_enabled, updated_at)
     VALUES ($1, $2, $3, $4, $5, now())
     ON CONFLICT (name) DO UPDATE
        SET label = EXCLUDED.label, description = EXCLUDED.description,
            enabled = EXCLUDED.enabled, whitelist_enabled = EXCLUDED.whitelist_enabled,
            updated_at = now()
      RETURNING name, (xmax = 0) AS created`,
    [input.name.trim(), input.label?.trim() || null, input.description?.trim() || null,
      input.enabled, input.whitelistEnabled]
  );
  if (!rows.length) {
    return false;
  }
  await auditConfigChange({
    domain: "product",
    name: input.name.trim(),
    //an adoption of a row-less product is a create, and the line should say so
    action: rows[0].created ? "create" : "update",
    after: productSummary(input),
  });
  return true;
}

/**
 * The first free code at or after `base`, keeping the total within {@link PRODUCT_SLUG_MAX}.
 *
 * <p>The base is shortened to make room for the suffix rather than the suffix being allowed to run
 * over, because the length is the point: `premium` becomes `premiu2`, then `premi10`.
 */
function nextFree(base: string, used: Set<string>): string {
  const seed = base.toLowerCase();
  if (!used.has(seed)) {
    return seed;
  }
  for (let n = 2; n < 1000; n++) {
    const suffix = String(n);
    const trimmed = seed.slice(0, PRODUCT_SLUG_MAX - suffix.length).replace(/-+$/g, "");
    const candidate = `${trimmed}${suffix}`;
    if (!used.has(candidate)) {
      return candidate;
    }
  }
  throw new Error(
    `Could not find a free code near '${base}'. Type one explicitly.`
  );
}

/**
 * @returns false when there is no such product, so the route can answer 404
 */
export async function setProductEnabled(name: string, enabled: boolean): Promise<boolean> {
  const rows = await configQuery<{ name: string }>(
    `UPDATE app_product SET enabled = $2, updated_at = now() WHERE name = $1 RETURNING name`,
    [name, enabled]
  );
  if (!rows.length) {
    return false;
  }
  await auditConfigChange({ domain: "product", name, action: enabled ? "enable" : "disable", after: { enabled } });
  return true;
}

/**
 * Removes a product, unless a rate rule still prices it.
 *
 * <p>This check is the whole of the referential integrity for `app_rate_rule.product`, since the
 * schema deliberately has no foreign key. Deleting a catalogue row does not stop those rules
 * charging — the gateway never reads this table — so the danger is not a broken rule but a live one
 * nobody can find any more.
 *
 * <p><strong>The race is real and is not closed here.</strong> A rate rule inserted between the count
 * and the delete slips through, because `count(*)` takes no lock. Closing it properly needs the
 * foreign key we chose not to have. For a single-operator panel that is an acceptable trade, but it
 * is a trade rather than a guarantee.
 */
export async function deleteProduct(name: string): Promise<DeleteResult> {
  return inTransaction(async (client) => {
    //logins as well as rules. The catalogue page has always SHOWN the credential count -- "N
    //credentials default to it" -- and the guard ignored it, so a product no rule priced but a login
    //still selected deleted without a word. It is not cosmetic either: the gateway reads app_product
    //for the whitelist exemptions, so removing the row of an exempt product puts that login's traffic
    //back under enforcement, where it can start refusing sender IDs nobody approved
    //and since gateway V1.56.0 everything else that can name a product, because each is now a
    //foreign key ON DELETE RESTRICT: counted here so the refusal says what to move, rather than
    //surfacing whichever constraint Postgres happened to check first
    const inUse = await client.query<Record<"rules" | "scopes" | "credentials" | "allowed" | "registrations", string>>(
      `SELECT
         (SELECT count(*) FROM app_rate_rule WHERE product = $1) AS rules,
         (SELECT count(DISTINCT scope) FROM app_rate_rule WHERE product = $1) AS scopes,
         (SELECT count(*) FROM app_credential WHERE product = $1) AS credentials,
         (SELECT count(*) FROM app_credential WHERE $1 = ANY(allowed_products)) AS allowed,
         (SELECT count(*) FROM app_header WHERE product = $1)
           + (SELECT count(*) FROM app_template WHERE product = $1)
           + (SELECT count(*) FROM app_whitelist_policy WHERE product = $1) AS registrations`,
      [name]
    );
    const row = inUse.rows[0];
    const rules = Number(row?.rules ?? 0);
    const credentials = Number(row?.credentials ?? 0);
    const allowedBy = Number(row?.allowed ?? 0);
    const registrations = Number(row?.registrations ?? 0);
    if (rules > 0 || credentials > 0 || allowedBy > 0 || registrations > 0) {
      return {
        kind: "in-use",
        rules,
        scopes: Number(row?.scopes ?? 0),
        credentials,
        allowedBy,
        registrations,
      } as const;
    }
    const gone = await client.query<{ name: string; label: string | null; enabled: boolean }>(
      `DELETE FROM app_product WHERE name = $1 RETURNING name, label, enabled`,
      [name]
    );
    if (!gone.rows.length) {
      return { kind: "not-found" } as const;
    }
    await auditConfigChange({
      domain: "product",
      name,
      action: "delete",
      before: { label: gone.rows[0].label, enabled: gone.rows[0].enabled },
    });
    return { kind: "deleted" } as const;
  });
}

function toSummary(row: ProductRow): ProductSummary {
  return {
    name: row.name,
    label: row.label,
    description: row.description,
    enabled: row.enabled,
    whitelistEnabled: row.whitelist_enabled,
    ruleCount: row.rule_count,
    scopeCount: row.scope_count,
    credentialCount: row.credential_count,
    updatedAt: row.updated_at ? row.updated_at.toISOString() : null,
  };
}
