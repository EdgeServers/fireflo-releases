import type { ConditionInput } from "./rate-types.ts";

/**
 * Filters in plain language: which topic a filter is about, what it says as a sentence, whether it
 * repeats another, and the guided fields that build one without the gateway's grammar.
 *
 * <p>Pure and client-safe. Everything here is a reading of {@link ConditionInput}s; nothing changes
 * what is stored, so a filter written by hand, by the import, or by an older panel reads the same.
 */

// --- topics ----------------------------------------------------------------------------------

export const FILTER_TOPICS = [
  { id: "destination", label: "Destination" },
  { id: "sender", label: "Sender ID" },
  { id: "product", label: "Product and login" },
  { id: "account", label: "Account" },
  { id: "content", label: "Message content" },
  { id: "other", label: "Other" },
] as const;

export type FilterTopic = (typeof FILTER_TOPICS)[number]["id"];

const TOPIC_BY_FIELD: Record<string, FilterTopic> = {
  to: "destination",
  cnetwork: "destination",
  from: "sender",
  onetwork: "sender",
  product: "product",
  systemId: "product",
  owner_id: "account",
  body: "content",
  binbody: "content",
  parts: "content",
  type: "content",
  dcs: "content",
};

export function topicOf(field: string): FilterTopic {
  return TOPIC_BY_FIELD[field.trim()] ?? "other";
}

/** Every topic a filter's conditions touch. A filter with none sits under Other. */
export function filterTopics(conditions: readonly ConditionInput[]): FilterTopic[] {
  const topics = new Set(conditions.map((c) => topicOf(c.field)));
  return topics.size ? FILTER_TOPICS.map((t) => t.id).filter((id) => topics.has(id)) : ["other"];
}

// --- sentences -------------------------------------------------------------------------------

const FIELD_WORDS: Record<string, string> = {
  to: "destination",
  from: "sender ID",
  cnetwork: "destination network",
  onetwork: "sender network",
  product: "product",
  systemId: "login",
  owner_id: "account",
  body: "message text",
  parts: "number of parts",
  type: "message type",
  dcs: "data coding",
};

const OPERATOR_WORDS: Record<string, [yes: string, no: string]> = {
  equals: ["is", "is not"],
  equalsIgnoreCase: ["is, in any case,", "is not, in any case,"],
  startsWith: ["starts with", "does not start with"],
  startsWithAny: ["starts with any of", "starts with none of"],
  endsWith: ["ends with", "does not end with"],
  matches: ["matches", "does not match"],
  greaterThan: ["sorts after", "does not sort after"],
  greaterEqual: ["sorts at or after", "sorts before"],
  lessThan: ["sorts before", "sorts at or after"],
  lessEqual: ["sorts at or before", "sorts after"],
  isNull: ["is empty", "is not empty"],
  isTrue: ["is set", "is not set"],
  isFalse: ["is not set", "is set"],
  "==": ["is", "is not"],
  ">": ["is more than", "is not more than"],
  ">=": ["is at least", "is less than"],
  "<": ["is less than", "is not less than"],
  "<=": ["is at most", "is more than"],
};

const VALUELESS = new Set(["isNull", "isTrue", "isFalse"]);

/** One condition as words: "destination starts with +91". */
export function describeCondition(c: ConditionInput): string {
  const field = FIELD_WORDS[c.field.trim()] ?? c.field.trim();
  const bare = c.operator.replace(/^(==|>=|<=|>|<)[ilfscb]$/, "$1");
  //a prefix list the guided form wrote reads as the list it was, not as a pattern
  const prefixes = prefixListOf(c);
  if (prefixes) {
    return `${field} ${c.negate ? "does not start with" : "starts with"} ${prefixes.join(" or ")}`;
  }
  const contains = c.operator === "matches" ? containsOf(c.value) : null;
  if (contains !== null) {
    return `${field} ${c.negate ? "does not contain" : "contains"} “${contains}”`;
  }
  const words = OPERATOR_WORDS[bare];
  const verb = words ? words[c.negate ? 1 : 0] : `${c.negate ? "not " : ""}${c.operator}`;
  return VALUELESS.has(bare) ? `${field} ${verb}` : `${field} ${verb} ${c.value}`;
}

/** Every condition joined into one sentence, capitalised. "" for none. */
export function describeConditions(conditions: readonly ConditionInput[]): string {
  if (!conditions.length) {
    return "";
  }
  const text = conditions.map(describeCondition).join(" and ");
  return text.charAt(0).toUpperCase() + text.slice(1) + ".";
}

// --- duplicates ------------------------------------------------------------------------------

/** One condition, normalised so two ways of writing the same test compare equal. */
export function conditionKey(c: ConditionInput): string {
  const op = c.operator.trim();
  const value = op === "equalsIgnoreCase" ? c.value.trim().toLowerCase() : c.value.trim();
  return `${c.negate ? "!" : ""}${c.field.trim()}\u0000${op}\u0000${VALUELESS.has(op) ? "" : value}`;
}

/** The whole condition set, order-free and without repeats: what the gateway actually tests. */
export function conditionsKey(conditions: readonly ConditionInput[]): string {
  return [...new Set(conditions.map(conditionKey))].sort().join("\u0001");
}

export function sameConditions(a: readonly ConditionInput[], b: readonly ConditionInput[]): boolean {
  return conditionsKey(a) === conditionsKey(b);
}

/**
 * The other filters that test exactly what `conditions` tests.
 *
 * <p>Empty filters never count as duplicates of each other: an empty filter is a filter still being
 * built, and the page warns about it on its own terms.
 */
export function duplicatesOf<T extends { name: string; conditions: readonly ConditionInput[] }>(
  conditions: readonly ConditionInput[],
  filters: readonly T[],
  exceptName?: string
): T[] {
  if (!conditions.length) {
    return [];
  }
  const key = conditionsKey(conditions);
  return filters.filter((f) => f.name !== exceptName && f.conditions.length > 0 && conditionsKey(f.conditions) === key);
}

/** For each filter that has a twin, the names of its twins. */
export function duplicateMap<T extends { name: string; conditions: readonly ConditionInput[] }>(
  filters: readonly T[]
): Map<string, string[]> {
  const byKey = new Map<string, string[]>();
  for (const f of filters) {
    if (!f.conditions.length) continue;
    const key = conditionsKey(f.conditions);
    byKey.set(key, [...(byKey.get(key) ?? []), f.name]);
  }
  const out = new Map<string, string[]>();
  for (const names of byKey.values()) {
    if (names.length < 2) continue;
    for (const n of names) out.set(n, names.filter((m) => m !== n));
  }
  return out;
}

/** An existing filter whose name differs from `name` only in case or surrounding space. */
export function nameClash(name: string, existing: readonly { name: string }[]): string | null {
  const wanted = name.trim().toLowerCase();
  if (!wanted) return null;
  return existing.find((f) => f.name.trim().toLowerCase() === wanted)?.name ?? null;
}

// --- guided fields ---------------------------------------------------------------------------

/** What step 1 offers. Each maps onto exactly one condition. */
export const GUIDED_KINDS = [
  { id: "destination", label: "Destination number", hint: "by prefix or exact number" },
  { id: "network", label: "Destination network", hint: "by network code" },
  { id: "sender", label: "Sender ID", hint: "exact or by prefix" },
  { id: "product", label: "Product", hint: "from the catalogue" },
  { id: "login", label: "Customer login", hint: "an SMPP or HTTP login" },
  { id: "account", label: "Account", hint: "who the message bills to" },
  { id: "text", label: "Message text", hint: "contains a word or phrase" },
] as const;

export type GuidedKind = (typeof GUIDED_KINDS)[number]["id"];

/** How a destination or sender is compared. */
export type MatchMode = "prefix" | "exact" | "prefixes";

export interface GuidedField {
  kind: GuidedKind;
  mode: MatchMode;
  /** The value, or for "prefixes" the list. */
  values: string[];
  /** "except": the condition is negated. */
  except: boolean;
}

const KIND_FIELD: Record<GuidedKind, string> = {
  destination: "to",
  network: "cnetwork",
  sender: "from",
  product: "product",
  login: "systemId",
  account: "owner_id",
  text: "body",
};

/** A blank field of this kind, as step 2 first shows it. */
export function blankGuided(kind: GuidedKind): GuidedField {
  return { kind, mode: kind === "destination" || kind === "sender" ? "prefix" : "exact", values: [""], except: false };
}

const escapeRegex = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** `^(\+91|\+92)`: the pattern a prefix list becomes, since a filter's conditions cannot say "or". */
export function prefixPattern(prefixes: readonly string[]): string {
  return `^(${prefixes.map(escapeRegex).join("|")})`;
}

/** The prefixes back out of a pattern this module wrote. Null for any other pattern. */
export function prefixesOf(pattern: string): string[] | null {
  const m = /^\^\((.*)\)$/.exec(pattern);
  if (!m) return null;
  const parts = m[1].split("|").map((p) => p.replace(/\\(.)/g, "$1"));
  //only a pattern that re-escapes to itself was ours; anything cleverer stays a pattern
  return parts.length && parts.every(Boolean) && prefixPattern(parts) === pattern ? parts : null;
}

/**
 * The prefixes of a prefix-list condition: `startsWithAny 91,+91`, or the older
 * `matches ^(\+91|91)` this module used to write (which never matched -- `matches` is a
 * whole-string match -- and which gateway V1.72.0 rewrites). Null for anything else.
 */
export function prefixListOf(c: Pick<ConditionInput, "operator" | "value">): string[] | null {
  if (c.operator === "startsWithAny") {
    const parts = c.value.split(",").map((p) => p.trim()).filter(Boolean);
    return parts.length ? parts : null;
  }
  return c.operator === "matches" ? prefixesOf(c.value) : null;
}

/** `.*word.*`, the pattern "contains" becomes. */
export function containsPattern(text: string): string {
  return `.*${escapeRegex(text)}.*`;
}

export function containsOf(pattern: string): string | null {
  const m = /^\.\*([\s\S]*)\.\*$/.exec(pattern);
  if (!m) return null;
  const text = m[1].replace(/\\(.)/g, "$1");
  return text && containsPattern(text) === pattern ? text : null;
}

/** The conditions a set of guided fields stands for. Fields with no value are left out. */
export function toConditions(fields: readonly GuidedField[]): ConditionInput[] {
  const out: ConditionInput[] = [];
  for (const f of fields) {
    const values = f.values.map((v) => v.trim()).filter(Boolean);
    if (!values.length) continue;
    const field = KIND_FIELD[f.kind];
    let operator: string;
    let value: string;
    if (f.kind === "text") {
      operator = "matches";
      value = containsPattern(values[0]);
    } else if (f.kind === "network") {
      operator = "==";
      value = values[0];
    } else if ((f.kind === "destination" || f.kind === "sender") && f.mode === "prefixes" && values.length > 1) {
      //a literal prefix list, not a regex: `matches` is a whole-string match, so the ^(a|b) this
      //used to write never matched a real number
      operator = "startsWithAny";
      value = values.join(",");
    } else if ((f.kind === "destination" || f.kind === "sender") && f.mode !== "exact") {
      operator = "startsWith";
      value = values[0];
    } else {
      operator = "equals";
      value = values[0];
    }
    out.push({ field, operator, value, negate: f.except });
  }
  return out;
}

/**
 * The guided fields that would write exactly these conditions, or null when one of them cannot be
 * expressed that way -- an unusual field, an operator the guided form never writes, or two
 * conditions on one field. The page then opens the filter in the advanced editor.
 */
export function fromConditions(conditions: readonly ConditionInput[]): GuidedField[] | null {
  const out: GuidedField[] = [];
  const seen = new Set<GuidedKind>();
  for (const c of conditions) {
    const kind = (Object.keys(KIND_FIELD) as GuidedKind[]).find((k) => KIND_FIELD[k] === c.field.trim());
    if (!kind || seen.has(kind)) return null;
    seen.add(kind);
    let field: GuidedField | null = null;
    if (kind === "text") {
      const t = c.operator === "matches" ? containsOf(c.value) : null;
      field = t === null ? null : { kind, mode: "exact", values: [t], except: c.negate };
    } else if (kind === "network") {
      field = c.operator === "==" ? { kind, mode: "exact", values: [c.value], except: c.negate } : null;
    } else if (kind === "destination" || kind === "sender") {
      if (c.operator === "startsWith") field = { kind, mode: "prefix", values: [c.value], except: c.negate };
      else if (c.operator === "equals") field = { kind, mode: "exact", values: [c.value], except: c.negate };
      else if (c.operator === "matches" || c.operator === "startsWithAny") {
        const p = prefixListOf(c);
        field = p ? { kind, mode: "prefixes", values: p, except: c.negate } : null;
      }
    } else if (c.operator === "equals") {
      field = { kind, mode: "exact", values: [c.value], except: c.negate };
    }
    if (!field) return null;
    out.push(field);
  }
  return out;
}

// --- names -----------------------------------------------------------------------------------

/** A name from the values: "to_91_transactional". Lower case, letters, digits and underscores. */
export function suggestName(conditions: readonly ConditionInput[], taken: readonly { name: string }[] = []): string {
  const bits = conditions.map((c) => {
    const prefixes = prefixListOf(c);
    const text = c.operator === "matches" ? containsOf(c.value) : null;
    const raw = prefixes ? prefixes.join("_") : text ?? c.value;
    const head = c.field === "to" ? "to_" : c.field === "from" ? "from_" : "";
    return `${c.negate ? "not_" : ""}${head}${raw}`;
  });
  let base = bits.join("_").toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 40)
    || "filter";
  base = base.replace(/_+$/, "");
  let name = base;
  for (let i = 2; nameClash(name, taken); i++) name = `${base}_${i}`;
  return name;
}
