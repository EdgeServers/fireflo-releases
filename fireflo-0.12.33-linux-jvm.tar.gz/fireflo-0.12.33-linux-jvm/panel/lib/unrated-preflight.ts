/**
 * What `smsg.rating.unrated.refuse` would refuse if it were switched on right now.
 *
 * <p>The flag is a one-line change with a blast radius nobody can see from the settings page: it
 * turns traffic that flows today into `0x418` over SMPP and `403` over REST, per message. On a
 * platform that has been running unpriced traffic — which is the platform that most needs the flag —
 * that is an outage arriving at the speed of a configuration poll.
 *
 * <p>So the switch is offered next to a count. The difference between "turn it on and find out" and
 * "turn it on knowing it refuses 4,000 messages a day from two accounts you have not priced" is the
 * whole reason this file exists.
 *
 * <h2>What counts as unrated</h2>
 *
 * <p>A message whose CDR carries **no price rule id**, not one whose price is zero. The gateway
 * makes exactly that distinction: `applyPrice` refuses only when no rule matched, so a rule
 * deliberately set to 0 sends free and keeps sending free once the flag is on. Counting on `price`
 * instead would report every free route as about to break.
 */

/**
 * The gateway property that decides it.
 *
 * <p>Declared in this module rather than beside the query that reads it, because the component
 * naming it is a client one and that module imports `pg` — a constant is not worth shipping a
 * database driver to a browser for.
 */
export const REFUSE_UNRATED_KEY = "smsg.rating.unrated.refuse";

/** One account and product whose recent traffic carried no price. */
export interface UnratedGroup {
  accountId: string;
  /** Empty when the messages carried no product at all, which is its own diagnosis. */
  product: string;
  messages: number;
}

export interface UnratedPreflight {
  /** Most traffic first. */
  groups: UnratedGroup[];
  /** Messages counted, across every group. */
  total: number;
  /** How far back the count looks. */
  hours: number;
  /**
   * The gateway's own running total, from `fireflo_rating_unrated`.
   *
   * <p>A second opinion from a different place: the CDR count is what was recorded, this is what the
   * gateway counted as it happened. Null when the gateway could not be read — which is worth showing
   * as unknown rather than as zero.
   */
  gauge: number | null;
}

/**
 * The pre-flight as one sentence, in the words the consequence is felt in.
 *
 * <p>Deliberately states the refusal in the present tense of the traffic, not of the setting: the
 * operator is deciding whether to break something that is working, and "nothing would be refused" is
 * as important an answer as a number.
 */
export function preflightSentence(preflight: UnratedPreflight): string {
  const { groups, total, hours } = preflight;
  if (!total) {
    return `Nothing in the last ${hours} hours would have been refused. Every message that arrived `
      + "matched a price.";
  }

  const accounts = new Set(groups.map((g) => g.accountId)).size;
  const worst = groups[0];
  return `${plural(total, "message")} in the last ${hours} hours carried no price and would have `
    + `been refused, from ${plural(accounts, "account")}. `
    + `The most affected is ${describe(worst)}.`;
}

/** One group as a phrase, naming the no-product case for what it is. */
export function describe(group: UnratedGroup): string {
  return group.product
    ? `${group.accountId} on ${group.product} (${plural(group.messages, "message")})`
    : `${group.accountId} with no product on the message (${plural(group.messages, "message")})`;
}

/**
 * What to do about it, which is not always "switch the flag on".
 *
 * <p>Setting a default price is the softer fix and is usually the right one: with `*` in place the
 * flag has nothing left to refuse except products nobody has priced at all. Saying so here means the
 * page offers a way forward rather than only a reason to hesitate.
 */
export function preflightAdvice(preflight: UnratedPreflight): string {
  if (!preflight.total) {
    return "Switching it on now would change nothing about today's traffic, and would refuse any "
      + "future account somebody onboards without a price. That is the point of it.";
  }
  const noProduct = preflight.groups.filter((g) => !g.product);
  const productAdvice = noProduct.length
    ? " Some of these carry no product at all, which no rate rule can match — those need a product "
      + "on the login or listener before any price will apply to them."
    : "";
  return "Price these before switching it on, or they stop sending the moment the gateway next "
    + `polls. Setting a default for each product is the quickest way to cover all of them.${productAdvice}`;
}

/** `1 message` / `4,102 messages`, in the locale the panel is read in. */
function plural(n: number, noun: string): string {
  return `${n.toLocaleString()} ${noun}${n === 1 ? "" : "s"}`;
}
