import type { NextResponse } from "next/server";
import { callOps } from "@/lib/gateway-ops";
import { housekeepingPath, type CleanStore, type HousekeepingRequest } from "@/lib/queue-clean";
import { repushPath, type RepushRequest } from "@/lib/receipt-repush";

/**
 * The gateway calls behind queue cleaning and receipt re-push — and only those.
 *
 * <p>Server-only (the admin token is read from the environment). Kept apart from the routes so the
 * paths, tokens and timeouts the gateway's housekeeping endpoints need are in one small file: the
 * routes decide who may ask, these decide how the gateway is asked.
 *
 * <p>`passErrors` on all of them: the gateway's refusals here are sentences addressed to the operator
 * — "unscoped", "broker-backed", "a re-push is already running for this login", a 503 when the
 * archive could not be written and everything was put back — and flattening them to "could not
 * reach the gateway" would hide the one thing that says what to do next.
 */

/** `POST /ops/housekeeping/{store}`, admin token. A dry run claims nothing. */
export function runHousekeeping(store: CleanStore, body: HousekeepingRequest): Promise<NextResponse> {
  return callOps({
    path: housekeepingPath(store),
    method: "POST",
    auth: "admin",
    body,
    //a batch of ten thousand is archived in one transaction and then closed out one by one
    timeoutMs: 120_000,
    passErrors: true,
  });
}

/** `POST /ops/receipts/repush`, admin token: a dry run's counts, or `{jobId}`. */
export function startRepush(body: RepushRequest): Promise<NextResponse> {
  return callOps({ path: repushPath(), method: "POST", auth: "admin", body, timeoutMs: 60_000, passErrors: true });
}

/** `GET /ops/receipts/repush/{jobId}`, read token. */
export function repushStatus(jobId: string): Promise<NextResponse> {
  return callOps({ path: repushPath(jobId), timeoutMs: 10_000, passErrors: true });
}

/** `DELETE /ops/receipts/repush/{jobId}`, admin token. */
export function cancelRepush(jobId: string): Promise<NextResponse> {
  return callOps({ path: repushPath(jobId), method: "DELETE", auth: "admin", timeoutMs: 10_000, passErrors: true });
}
