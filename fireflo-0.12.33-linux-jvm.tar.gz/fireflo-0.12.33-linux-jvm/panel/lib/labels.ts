/**
 * Every machine identifier this product shows a person, and its English name.
 *
 * <p>One module, and deliberately **data rather than JSX**. Identifiers are the part of the
 * interface that cannot be translated in place — a component cannot guess that
 * `connections.transceivers` means "Transceiver binds" — so they live here as catalogues a locale
 * layer could later sit in front of. Adding a language would mean adding a sibling catalogue and a
 * resolver, not revisiting thirty components.
 *
 * <p><strong>This does not make the panel multilingual.</strong> Sentences written into components
 * are still English. What moved here is the layer that was previously impossible to translate at all
 * because it was never written down.
 */

/**
 * Words that look wrong in sentence case, because they are acronyms rather than words.
 *
 * <p>Consulted by {@link humanise} only. A curated label spells its own case.
 */
const ACRONYMS = new Set([
  "tps", "tlv", "tlvs", "ton", "npi", "dcs", "ssl", "tls", "url", "ip", "id", "ids",
  "mo", "dlr", "dlrs", "pdu", "pdus", "smpp", "sms", "jmx", "hlr", "esm", "ucs2", "gsm",
  "kpi", "utc", "api",
]);

/**
 * The settings worth a hand-written name, and why they matter.
 *
 * <p>Roughly the fifty an operator actually touches, out of about a hundred and seventy the gateway
 * will accept. Everything else falls through to {@link humanise}, which is why this list can stay a
 * list of the useful ones rather than an obligation to write prose about `kpi.fail.statuses`.
 */
export const SETTING_LABELS = {
  // --- identity and connection ---------------------------------------------------------------
  host: { label: "Host" },
  port: { label: "Port" },
  username: { label: "System ID", hint: "The username the vendor issued for this bind" },
  password: { label: "Password" },
  systemType: { label: "System type", hint: "Left empty unless the vendor asked for a value" },
  "extra.hosts": { label: "Additional hosts", hint: "Extra addresses to bind in parallel" },
  "backup.hosts": { label: "Backup hosts", hint: "Used only when the primary cannot be reached" },
  "local.bind.host": { label: "Outbound address", hint: "Which local address to dial from" },
  interfaceVersion: { label: "SMPP version", hint: "52 is SMPP 3.4" },

  // --- how many binds ------------------------------------------------------------------------
  "connections.transceivers": { label: "Transceiver binds", hint: "Send and receive on one session. Usually 1" },
  "connections.transmitters": { label: "Transmitter binds", hint: "Send only" },
  "connections.receivers": { label: "Receiver binds", hint: "Receive only" },
  "reconnection.threads": { label: "Reconnect threads" },
  windowSize: { label: "Window size", hint: "Messages allowed in flight per session before waiting" },

  // --- rate and retry ------------------------------------------------------------------------
  tps: { label: "Throughput limit", hint: "Messages per second. 0 means no limit" },
  maxRetries: {
    label: "Attempts per message",
    hint: "Total sends this carrier may see for one message, including re-routes back here. 0 means keep trying forever",
  },
  threadCount: { label: "Sending threads" },
  suspend: { label: "Stopped", hint: "Not accepting messages; anything already queued is held until resume" },
  pause: { label: "Held", hint: "Still accepting, but not sending. The queue grows" },
  debug: { label: "Debug logging" },

  // --- timers --------------------------------------------------------------------------------
  "enquire.link.interval.millis": {
    label: "Keepalive interval",
    hint: "Milliseconds between enquire_link probes. Default 30000, which is 30 seconds",
  },
  "reconnect.interval.millis": {
    label: "Reconnect interval",
    hint: "Milliseconds between reconnect attempts. Default 60000, which is 60 seconds",
  },
  "con.tout": { label: "Connect timeout", hint: "Milliseconds to wait for the TCP connection" },
  "request.tout": { label: "Response timeout", hint: "Milliseconds to wait for a submit_sm response" },
  "window.offer.timeout.ms": { label: "Window-slot wait", hint: "Milliseconds a send waits for a free window slot before the message goes back on the queue; the gateway counts these waits. Also how long a vendor may stop reading before its connection is dropped and re-dialled" },
  "unbind.timeout.millis": { label: "Unbind timeout" },
  "window.monitor.interval.millis": { label: "Window check interval" },
  "reconnection.stability.threshold.millis": {
    label: "Stable-connection threshold",
    hint: "How long a session must hold before it counts as stable",
  },
  "pause.sleep.ms": { label: "Pause poll interval" },

  // --- addressing ----------------------------------------------------------------------------
  "src.addr.ton": { label: "Sender type of number" },
  "src.addr.npi": { label: "Sender numbering plan" },
  "src.addr.autodetect": { label: "Detect sender type automatically" },
  "dest.addr.ton": { label: "Recipient type of number" },
  "dest.addr.npi": { label: "Recipient numbering plan" },
  "dest.addr.convert": {
    label: "Convert recipient automatically",
    hint: "Rewrites each number into the form Recipient type of number asks for: international digits for 1, "
      + "national digits for 2. Numbers it cannot read are sent as they came",
  },
  "dest.addr.country": {
    label: "Recipient default country",
    hint: "Two-letter ISO code, e.g. AU or IN, for numbers written without a country code. "
      + "Used only when Convert recipient automatically is on",
  },
  addressRange: { label: "Address range" },

  // --- encoding ------------------------------------------------------------------------------
  "dcs.charset.map": { label: "Encoding map", hint: "Which character set each data coding means" },
  "dcs.charset.ext": { label: "Extra encodings" },
  "dlr.charset.fixed": { label: "Receipt encoding", hint: "Force one character set for delivery receipts" },
  "ccat.8bit": { label: "8-bit concatenation" },
  "esm.class": { label: "ESM class" },
  "esm.class.override": { label: "Override ESM class" },

  // --- TLVs ----------------------------------------------------------------------------------
  //no example here any more: the field resolves each tag against the TLV catalogue and shows what
  //it means, which is what the example was standing in for
  "registered.tlvs.submit": { label: "TLVs to send" },
  "registered.tlvs.dlr": { label: "TLVs to read from receipts" },
  "registered.tlvs.mo": { label: "TLVs to read from inbound messages" },
  "default.tlvs.submit": { label: "Default TLV values", hint: "Used when a message carries none" },
  "mandatory.tlvs.submit": { label: "Required TLVs", hint: "A message without these is rejected" },
  "whitelist.tlvs.mode": {
    label: "Stamp approved TLVs",
    hint: "What a matched sender ID or template does with the TLVs it carries. Replace is what "
      + "makes an approved registration binding; assign only fills a tag the customer omitted",
  },
  /*
   * `whitelist.tlvs.replace` is deliberately absent. SettingKey is `keyof typeof SETTING_LABELS`,
   * so a label here is what obliges setting-fields.ts to carry an editor -- and an editor is exactly
   * what this key must not have. Gateway migration V1.38.0 translates it into the mode above and
   * drops it; a file-mode listener can still carry one, and the gateway warns at startup for those,
   * which is the only side that can see a properties file.
   *
   * `lib/mandatory-tlvs.ts` reads the key as a plain string when computing coverage and needs no
   * label to do it. If it ever reaches a screen, the humanising fallback below handles it.
   */

  // --- failure handling ----------------------------------------------------------------------
  "status.retry.worker": { label: "Statuses to retry here" },
  "status.retry.router": { label: "Statuses to reroute" },
  "status.fail": { label: "Statuses to fail immediately" },
  "status.default": { label: "Default action on rejection" },
  "suspension.policy": { label: "Suspension policy" },
  "suspension.stopMessages.ms": { label: "Stop accepting after", hint: "Milliseconds suspended. -1 never" },
  "suspension.disable.ms": { label: "Disable after", hint: "Milliseconds suspended. -1 never" },

  // --- diagnostics ---------------------------------------------------------------------------
  counters: { label: "Session counters", hint: "Off means throughput cannot be measured" },
  "log.pdus": { label: "Log PDUs", hint: "Verbose; includes message content" },
  "log.bytes": { label: "Log raw bytes" },
  "print.msgs": { label: "Log messages" },
  "connection.healthcheck": { label: "Connection health check" },
  "forward.mo.url": { label: "Inbound message webhook" },
  "forward.mo.format": { label: "Webhook format" },

  // --- listener ------------------------------------------------------------------------------
  //srv.host is deliberately absent: the gateway loads it and never applies it, so offering it as
  //"Listen address" was the panel teaching a setting that does nothing. See DEAD_KEYS.
  "srv.port": { label: "Listen port" },
  "srv.public.host": {
    label: "Public IP (optional)",
    hint: "The address customers connect to; used in connection instructions. The gateway does not bind to it.",
  },
  "srv.enabled": { label: "Listener enabled" },
  "srv.systemId": { label: "Advertised system ID", hint: "What this gateway calls itself when a customer binds" },
  "srv.maxConnections": { label: "Maximum binds" },
  "srv.maxConnectionsPerIP": { label: "Maximum binds per IP" },
  "srv.bind.backoff.enabled": {
    label: "Bind backoff",
    hint: "After five refused binds in a minute an address waits thirty seconds before its next bind is looked at",
  },
  "srv.maxInactivityTime": { label: "Idle timeout", hint: "Seconds before a silent bind is dropped" },
  "srv.bindTimeout": { label: "Bind timeout" },
  "srv.tls.enabled": { label: "TLS enabled" },
  "srv.tls.port": { label: "TLS port" },
  "srv.tls.keystore.path": { label: "TLS keystore" },
  "srv.tls.keystore.alias": { label: "TLS certificate alias" },
  "srv.tls.keystore.password": { label: "TLS keystore password" },
  "srv.proxy.enabled": { label: "PROXY protocol", hint: "For a load balancer that preserves the client address" },
  "srv.proxy.port": { label: "PROXY protocol port" },
  "conf.whitelist.enabled": {
    label: "Check approved sender IDs and content",
    hint: "Off exempts this listener only. The same account sending over the API is still checked",
  },
  "conf.dlr.multipart": {
    label: "Receipts per concatenated message",
    hint: "Counts the ids the customer submitted, not the segments we sent the carrier. All three "
      + "report the same outcome and differ only in the id they quote",
  },
  "conf.product.required": {
    label: "Require a product on every connection",
    hint: "Refuses a bind whose product is blank or not in the catalogue. Since gateway 0.12.16 a system_type the login may not name is ignored and the login's product applies; this setting still catches a login whose own product is blank or misspelt",
  },
  "conf.maxRate.default": { label: "Default rate ceiling", hint: "Messages per second per customer. 0 is unlimited" },
  "conf.maxConnectionsPerUser.default": { label: "Default binds per customer" },
  "conf.maxPending.default": { label: "Default in-flight limit" },
  "conf.responseTout.default": { label: "Default response timeout" },
  "conf.window.wait.ms": { label: "Receive-window wait" },
  "srv.out.queue": { label: "Outbound queue size" },
  "ptrn.valid.receiver": { label: "Accepted recipient pattern" },
  "forward.dlrs": { label: "Forward delivery receipts" },
  "reassembling.timeoutMillis": { label: "Multipart reassembly timeout" },
  "dlr.errcodes": {
    label: "Translate this carrier's error codes",
    hint:
      "<carrier code>_<FireFlo code>, comma separated: 630_16,1000_1. Note the underscore. A code " +
      "you list becomes the code you chose, so the same number means the same cause whichever " +
      "carrier a message went through.",
  },
  "dlr.errcodes.passthrough": {
    label: "Pass through codes you have not listed",
    hint:
      "Off, a code missing from the table above reaches the customer as 018, unknown — which " +
      "destroys the only clue there is. On, it reaches them exactly as the carrier sent it. Off by " +
      "default because turning it on changes the error code in receipts your customers already " +
      "parse. Either way, what the carrier said is kept on the message record.",
  },
} satisfies Record<string, { label: string; hint?: string }>;

/**
 * Every setting this panel has an English name for.
 *
 * <p>`satisfies` above rather than a type annotation, so the literal keys survive into this union
 * instead of widening to `string`. That is what lets `SETTING_FIELDS` be a `Record<SettingKey, …>`
 * and fail to compile in both directions — a field for a key with no label, and a labelled key with
 * no field.
 */
export type SettingKey = keyof typeof SETTING_LABELS;

/**
 * The English name for a setting, always.
 *
 * <p>Falls back to {@link humanise} rather than the key, so **no raw identifier can reach the
 * screen**. That guarantee is the point: the alternative is a list that reads fine until someone
 * sets a property nobody anticipated.
 */
export function settingLabel(key: string): { label: string; hint?: string } {
  //the cast is the price of `satisfies`: an arbitrary string is not a SettingKey, and the ?? is
  //exactly the check that makes the lookup safe
  return SETTING_LABELS[key as SettingKey] ?? { label: humanise(key) };
}

/**
 * Best-effort English for an identifier nobody wrote a name for.
 *
 * <p>`srv.maxConnectionsPerIP` becomes "Max connections per IP"; `enquire.link.consecutiveErrors`
 * becomes "Enquire link consecutive errors". It will be clumsy for some keys — clumsy is the floor
 * this sets, not the target. The curated catalogue above is what makes the common cases read well.
 */
export function humanise(key: string): string {
  const words = key
    //a leading srv./conf. only says which subsystem owns the setting, which the page already implies
    .replace(/^(srv|conf)\./, "")
    .replace(/\.default$/, "")
    .split(/[._]/)
    //camelCase and consecutive capitals: maxConnectionsPerIP -> max Connections Per IP
    .flatMap((part) => part.replace(/([a-z0-9])([A-Z])/g, "$1 $2").split(" "))
    .filter(Boolean)
    .map((word) => (ACRONYMS.has(word.toLowerCase()) ? word.toUpperCase() : word.toLowerCase()));

  if (!words.length) {
    return key;
  }
  const [head, ...tail] = words;
  const first = ACRONYMS.has(head.toLowerCase()) ? head : head[0].toUpperCase() + head.slice(1);
  return [first, ...tail].join(" ");
}

/**
 * What a bound session can do, in the abbreviations the SMPP specification uses.
 *
 * <p>The rest of this file prefers plain English over protocol vocabulary, and this is the
 * deliberate exception. Whoever reads a bind table is comparing it against a carrier's own
 * documentation or a `bind_transceiver` in a log, and both say TRX — translating to "Send and
 * receive" made the panel the one place using different words for the thing being checked.
 *
 * <p>The full term stays on the cell as a `title`, so the abbreviation is hoverable rather than
 * something to already know.
 */
export const BIND_TYPE_LABELS: Record<string, string> = {
  TRANSCEIVER: "TRX",
  TRANSMITTER: "TX",
  RECEIVER: "RX",
};

/**
 * Which of a vendor's configured addresses a session landed on.
 *
 * <p>"Primary" rather than "normal", because the useful reading is the contrast: a session on a
 * backup means the primary could not be reached.
 */
export const ROLE_LABELS: Record<string, string> = {
  NORMAL: "Primary",
  EXTRA: "Additional",
  BACKUP: "Backup",
};

/** How a message finished, from `cdr_final.final_state`. */
export const FINAL_STATE_LABELS: Record<string, string> = {
  DELIVERED: "Delivered",
  FAILED: "Failed at the vendor",
  REJECTED: "Rejected on submission",
  DROPPED: "Dropped before sending",
  EXPIRED: "No receipt within the deadline",
};

/**
 * The same outcomes in one or two words, for a badge in a narrow column.
 *
 * <p>The catalogue above is sentences, which is right nearly everywhere — "Failed at the vendor"
 * and "Rejected on submission" are different problems and the difference is the useful part. But a
 * sentence inside a pill in a half-width panel wraps to three lines, and the surfaces that use these
 * put the full version on the line beneath anyway. Shortening the catalogue itself would cost five
 * other views their precision, so this is a second one rather than a replacement.
 */
export const SHORT_FINAL_STATE_LABELS: Record<string, string> = {
  DELIVERED: "Delivered",
  FAILED: "Failed",
  REJECTED: "Rejected",
  DROPPED: "Dropped",
  //not "Expired": the message did not expire, our wait for a receipt did
  EXPIRED: "No receipt",
};

/**
 * The raw SMPP receipt states, as the mnemonic a carrier's documentation uses and as English.
 *
 * <p>`cdr_final.dlr_state` and `cdr_interim.dlr_state` are integers, and the panel rendered them as
 * integers — a column headed "Receipt state" reading `9` told a reader nothing, and `9` is the one
 * that used to be recorded as a failure. Both are shown: the mnemonic because it is what a reader is
 * comparing against a carrier's own logs, the sentence because nobody should have to already know
 * what BUFFRED means.
 *
 * <p><strong>`terminal` is the panel's copy of `SmppServerUtil.isTerminal`</strong>, and the split it
 * describes is the whole point of there being two tables. ACCEPTD and BUFFRED report progress; every
 * other state is an outcome and closes the message. The five USER states are vendor-defined and
 * counted as outcomes, matching the gateway's `default -> true`.
 */
export const DLR_STATES: Record<number, { code: string; label: string; terminal: boolean }> = {
  1: { code: "DELIVRD", label: "Delivered to the handset", terminal: true },
  2: { code: "EXPIRED", label: "The carrier gave up before delivering", terminal: true },
  3: { code: "DELETED", label: "Cancelled at the carrier", terminal: true },
  4: { code: "UNDELIV", label: "Undeliverable", terminal: true },
  5: { code: "ACCEPTD", label: "Accepted by the carrier", terminal: false },
  6: { code: "UNKNOWN", label: "The carrier does not know", terminal: true },
  7: { code: "REJECTD", label: "Rejected by the carrier", terminal: true },
  8: { code: "FAILED", label: "Failed at the carrier", terminal: true },
  9: { code: "BUFFRED", label: "Held, still being attempted", terminal: false },
  10: { code: "USER1", label: "Vendor-defined state 1", terminal: true },
  11: { code: "USER2", label: "Vendor-defined state 2", terminal: true },
  12: { code: "USER3", label: "Vendor-defined state 3", terminal: true },
  13: { code: "USER4", label: "Vendor-defined state 4", terminal: true },
  14: { code: "USER5", label: "Vendor-defined state 5", terminal: true },
  15: { code: "SEEN", label: "Read by the recipient", terminal: true },
};

/** The mnemonic, or the number when it is one the gateway does not define. */
export function dlrStateCode(state: number | null | undefined): string {
  if (state == null) {
    return "—";
  }
  return DLR_STATES[state]?.code ?? String(state);
}

/** The sentence. Falls back to naming the number rather than to silence. */
export function dlrStateLabel(state: number | null | undefined): string {
  if (state == null) {
    return "—";
  }
  return DLR_STATES[state]?.label ?? `Unrecognised state ${state}`;
}

/**
 * What a message with no outcome yet is waiting on, for its badge.
 *
 * <p>"Awaiting receipt" was said for every message with no `cdr_final` row -- including one whose
 * vendor had already answered ACCEPTD, which the detail page then showed as a receipt. A progress
 * receipt is named instead; only a message nobody has answered at all is still awaiting one.
 *
 * @param progressState the latest `cdr_interim.dlr_state`, or null/undefined when none arrived
 * @param compact the short form, for a column too narrow for the sentence
 */
export function pendingBadge(
  progressState: number | null | undefined,
  compact = false
): { label: string; title: string } {
  if (progressState == null) {
    return { label: "Awaiting receipt", title: "No receipt from the carrier yet" };
  }
  const short: Record<number, string> = { 5: "Accepted", 9: "Held" };
  return {
    label: compact ? short[progressState] ?? dlrStateCode(progressState) : dlrStateLabel(progressState),
    title: `${dlrStateCode(progressState)}: a progress receipt. No final outcome yet.`,
  };
}

/**
 * The line above a page of messages saying how many have no outcome yet, or null when none.
 *
 * <p>Counts the ones a carrier has already answered with a progress receipt separately, because those
 * are the rows whose detail page shows a receipt -- a sentence calling them all "awaiting a receipt"
 * is what made the list and the detail page look like they disagreed.
 */
export function pendingSummary(
  rows: readonly { finalState: string | null; progressState?: number | null }[]
): string | null {
  const open = rows.filter((r) => !r.finalState);
  if (!open.length) {
    return null;
  }
  const answered = open.filter((r) => r.progressState != null).length;
  const of = `${open.length} of these ${rows.length} ${open.length === 1 ? "has" : "have"} no final outcome yet`;
  const who = answered === open.length ? (open.length === 1 ? "" : "all ") : `${answered} of them `;
  const progress = answered ? `, ${who}acknowledged by the carrier with a progress receipt` : "";
  return `${of}${progress}. That is normal — the gateway closes anything still open at its expiry deadline.`;
}

/**
 * Whether this state closed the message.
 *
 * <p>Unknown states count as terminal, exactly as the gateway does — the asymmetry matters: treating
 * an unrecognised outcome as progress would leave a finished message open until the sweeper expired
 * it, which loses a real outcome. Treating an unrecognised progress state as an outcome merely
 * closes it early.
 */
export function isTerminalDlrState(state: number | null | undefined): boolean {
  if (state == null) {
    return false;
  }
  return DLR_STATES[state]?.terminal ?? true;
}

/**
 * @returns the mapped name, or the raw value when it is one this catalogue has not met. Showing the
 *     unknown value is right here — unlike a setting key, an unexpected enum is usually the answer
 *     someone is looking for
 */
export function labelFor(catalogue: Record<string, string>, value: string | null | undefined): string {
  if (!value) {
    return "—";
  }
  return catalogue[value] ?? value;
}

/**
 * A throughput peak as one short line, and the sentence that says how it was measured.
 *
 * @param peak null/undefined when nothing has been measured
 * @param format renders the instant; passed in so this stays testable and the caller's zone rules
 */
export function peakLine(
  peak: { tps: number; at: string; window_seconds: number } | null | undefined,
  format: (iso: string) => string
): { text: string; title: string } {
  if (!peak) {
    return { text: "No peak measured yet", title: "Recorded from the first SMPP traffic measured" };
  }
  return {
    text: `Peak ${peak.tps.toLocaleString()}/s · ${format(peak.at)}`,
    title: `The highest rate measured over a ${peak.window_seconds}-second window, kept across restarts`,
  };
}
