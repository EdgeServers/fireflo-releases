/**
 * Which of the two panels a component is rendering inside.
 *
 * <p>This application serves two audiences from one codebase: the operator control panel at `/cp`,
 * and the customer portal at the site root. They have separate sessions, separate cookies and
 * separate API namespaces, and for most of the panel that is the end of it — a page belongs to one
 * or the other and imports what it needs.
 *
 * <p><strong>The account screens are the exception.</strong> A reseller managing the accounts
 * beneath it wants the same table, the same column chooser, the same form and the same login list an
 * operator uses. Those components are already shaped for it: they take props and import only UI
 * primitives and types. What tied them to `/cp` was twelve hardcoded strings — `/api/control/…`
 * inside three hooks, and `/cp/accounts/…` inside six components. This module is those strings,
 * named.
 *
 * <h2>Why module state and not a context</h2>
 *
 * <p>The same answer `lib/format.ts` gives for `setMoneyScale`, and for the same reason: threading a
 * prop through nine client components would be a large diff whose only failure mode is silence — one
 * missed hand-off and a component fetches the operator's API from inside the portal, gets a 404, and
 * renders as empty rather than as broken.
 *
 * <p>There is exactly one surface per rendered page, decided by which layout is above it, so there
 * is nothing for a context to vary. {@link PanelSurface} assigns it during render for the reason
 * that component documents: an effect would run only on the client and only after first paint, so
 * the server would render against one surface and the browser against another.
 *
 * <h2>`pricing` is a capability, not an `isOperator`</h2>
 *
 * <p>Deliberately phrased as what the surface *may show* rather than who is looking. A negative like
 * `isCustomer` invites a reader to add a feature and forget the check; a positive named for the
 * thing being protected makes `!surface().pricing` read as "this is the price boundary" at every
 * call site. It gates the tariff and statement tabs, the rate-scope badge, the price-rule count, and
 * `useRates` — which fetches nothing at all rather than fetching something that would 404.
 */

export interface Surface {
  /** Prefix for every API call the shared account components make. No trailing slash. */
  apiBase: string;
  /** Prefix for every account link they render. No trailing slash. */
  linkBase: string;
  /**
   * Whether this surface may show what an account is charged.
   *
   * <p>False in the customer portal. A reseller creates and manages the accounts beneath it and does
   * not set or see their pricing — that stays the operator's, and the reseller's own margin is
   * settled off-platform.
   */
  pricing: boolean;
}

/**
 * The operator panel, which is what every one of these components did before this module existed.
 *
 * <p>The default, so a component rendered outside either layout — a test, a Storybook-style harness,
 * a page nobody has migrated — behaves exactly as it used to rather than pointing at nothing.
 */
export const OPERATOR_SURFACE: Surface = {
  apiBase: "/api/control",
  linkBase: "/cp/accounts",
  pricing: true,
};

/** The customer portal, where a reseller manages the accounts beneath it. */
export const RESELLER_SURFACE: Surface = {
  apiBase: "/api/mis",
  linkBase: "/accounts",
  pricing: false,
};

let current: Surface = OPERATOR_SURFACE;

/** Called during render by {@link PanelSurface}, and by nothing else. */
export function setSurface(surface: Surface): void {
  current = surface;
}

export function surface(): Surface {
  return current;
}

/**
 * One account's page, on whichever surface is current.
 *
 * <p>Its own function because six components built this string by hand and each encoded the id — one
 * of them differently. An account id may contain a dot or a dash, which are safe, but the encoding
 * is what makes the comparison in `AccountShell`'s tab bar work against a pathname, so it has to be
 * the same call in both places.
 */
export function accountHref(id: string, tab = ""): string {
  const base = `${current.linkBase}/${encodeURIComponent(id)}`;
  return tab ? `${base}/${tab}` : base;
}
