/**
 * One account's MT usage, read from the gateway's database.
 *
 * <p>Server-only and read-only. The arithmetic is `mt-usage.ts`; the SQL is `mt-usage-sql.ts`.
 */

import { query } from "./metrics-db";
import { hasSubmitStatus, hasUsageMtParts, hasVendorAttempt } from "./metrics-schema";
import { mtUsageSql, TODAY_SQL } from "./mt-usage-sql";
import { summariseMtUsage, type MtUsage } from "./mt-usage";

/**
 * @param zone must match `FIREFLO_BILLING_ZONE` on the gateway, or the tail is cut into days
 *     differently from the rollup and a day near midnight is counted on the wrong side
 */
export async function mtUsageFor(accountId: string, zone: string): Promise<MtUsage> {
  const [vendorAttempt, mtParts, submitStatus] = await Promise.all([
    hasVendorAttempt(),
    hasUsageMtParts(),
    hasSubmitStatus(),
  ]);
  const [rows, today] = await Promise.all([
    query<{ day: string; product: string; messages: string; mt_parts: string | null; price: string }>(
      mtUsageSql({ vendorAttempt, mtParts, submitStatus }),
      [accountId, zone]
    ),
    query<{ today: string }>(TODAY_SQL, [zone]),
  ]);
  return summariseMtUsage(
    rows.map((r) => ({
      day: r.day,
      product: r.product,
      messages: Number(r.messages),
      mtParts: r.mt_parts === null ? null : Number(r.mt_parts),
      price: Number(r.price),
    })),
    today[0].today
  );
}
