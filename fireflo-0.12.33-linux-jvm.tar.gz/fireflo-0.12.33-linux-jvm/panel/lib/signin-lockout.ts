/**
 * Ten FAILED attempts per address and peer per quarter hour, then a refusal until the window ends;
 * and thirty per address alone, whatever the peers, so rotating addresses still locks the account.
 *
 * <p>Failures, not attempts: a limiter that counted successes locked out an operator who signed in
 * from several tabs, and the e2e suite, which signs in once per test. A wrong password is what an
 * attacker produces and a right one is not. Bounded like `rate-limit.ts` -- cleared wholesale rather
 * than swept, and the cost of clearing is a fresh allowance, which is the safe direction.
 *
 * <p>One per sign-in surface: the operator panel and the customer portal each make their own, so a
 * run of failures at one door never locks the other.
 *
 * <h2>Why two counters</h2>
 *
 * <p>The IP+email rule is the one an operator notices least: a stranger guessing at your address
 * from one place is locked out while you, from yours, are not. On its own it is also the one an
 * attacker steps around most cheaply -- a new source address is a new key -- and when the panel
 * cannot see the source address at all (no `TRUSTED_PROXY_HOPS`, see `lib/client-ip.ts`) the IP
 * half is a constant and the rule degenerates into "ten per email" anyway. The second counter makes
 * that degenerate case the deliberate one: thirty failures against one address inside the window,
 * from however many places, and that address is refused until the window ends. Thirty rather than
 * ten so a forgetful operator and a colleague retyping on their behalf do not trip it, and so the
 * cheapest denial of service -- thirty POSTs -- costs a lock of at most fifteen minutes.
 *
 * <p>Both live in process memory. A restart or a second panel instance forgets them, which is the
 * safe direction to be wrong in for a lockout but means neither is a durable record; persisting
 * failures across processes is deliberately out of scope here.
 */
export const MAX_FAILURES = 10;
export const MAX_FAILURES_PER_EMAIL = 30;
export const FAILURE_WINDOW_MS = 15 * 60_000;

export interface SigninLockout {
  lockedOut(key: string): boolean;
  noteFailure(key: string): void;
  clear(key: string): void;
}

interface FailureWindow {
  count: number;
  until: number;
}

function counter(maxFailures: number) {
  const failures = new Map<string, FailureWindow>();
  return {
    locked(key: string, now: number): boolean {
      const f = failures.get(key);
      return !!f && now < f.until && f.count >= maxFailures;
    },
    note(key: string, now: number): void {
      const f = failures.get(key);
      if (!f || now > f.until) {
        if (failures.size > 10_000) {
          failures.clear();
        }
        failures.set(key, { count: 1, until: now + FAILURE_WINDOW_MS });
        return;
      }
      f.count += 1;
    },
    clear(key: string): void {
      failures.delete(key);
    },
  };
}

/**
 * @param key a {@link lockoutKey}: the per-origin counter is kept under the whole key and the
 *     per-address one under its email half, so callers keep passing the one string they always did
 */
export function signinLockout(): SigninLockout {
  const perOrigin = counter(MAX_FAILURES);
  const perEmail = counter(MAX_FAILURES_PER_EMAIL);
  return {
    lockedOut(key) {
      const now = Date.now();
      return perOrigin.locked(key, now) || perEmail.locked(emailOf(key), now);
    },
    noteFailure(key) {
      const now = Date.now();
      perOrigin.note(key, now);
      perEmail.note(emailOf(key), now);
    },
    clear(key) {
      //a right password from anywhere clears both: the person who holds it is present, and the
      //window is short enough that an attacker gains at most another thirty guesses by their luck
      perOrigin.clear(key);
      perEmail.clear(emailOf(key));
    },
  };
}

/**
 * The key both sign-ins count failures under: where it came from, and which address it named.
 *
 * <p>`|` is the separator because no IP literal contains one (IPv6 uses `:`), so the email half can
 * be recovered by splitting at the first.
 */
export function lockoutKey(ip: string | null, email: string): string {
  return `${ip ?? "-"}|${email.toLowerCase()}`;
}

function emailOf(key: string): string {
  const at = key.indexOf("|");
  return at < 0 ? key : key.slice(at + 1);
}
