/**
 * When a poll runs: while somebody is looking, and only then.
 *
 * <p>Pure, with no React and no `document`, so the two rules it enforces can be tested without a
 * browser:
 *
 * <ul>
 *   <li><b>Reference counting.</b> Each consumer `acquire`s on mount and releases on unmount. The
 *       first acquire starts the poll and the last release stops it, so three cards on one page
 *       reading the same endpoint cost one request per interval rather than three (CP-P7: the
 *       routing and pricing pages hit `/health` two to three times a cycle).</li>
 *   <li><b>Visibility.</b> A hidden tab polls nothing. Coming back runs a fetch at once and restarts
 *       the interval, so the page is fresh the moment it is looked at rather than up to one
 *       interval stale.</li>
 * </ul>
 *
 * <p>`run` is called immediately on each transition into the running state -- first consumer,
 * tab shown again -- and then once per interval. A consumer joining a scheduler that is already
 * running triggers nothing: whatever the last run produced is already in hand.
 */

export interface PollTimers {
  setInterval(fn: () => void, ms: number): unknown;
  clearInterval(handle: unknown): void;
}

export interface PollScheduler {
  /** Registers a consumer. @returns its release, safe to call more than once */
  acquire(): () => void;
  /** The tab's visibility, as `document.visibilityState === "visible"`. */
  setVisible(visible: boolean): void;
  /** Whether the interval is currently ticking. */
  readonly running: boolean;
  /** How many consumers hold the scheduler. */
  readonly consumers: number;
}

const DEFAULT_TIMERS: PollTimers = {
  setInterval: (fn, ms) => setInterval(fn, ms),
  clearInterval: (handle) => clearInterval(handle as ReturnType<typeof setInterval>),
};

export function createPollScheduler(
  run: () => void,
  intervalMs: number,
  options: { visible?: boolean; timers?: PollTimers } = {}
): PollScheduler {
  const timers = options.timers ?? DEFAULT_TIMERS;
  let visible = options.visible ?? true;
  let consumers = 0;
  let handle: unknown = null;

  const sync = () => {
    const shouldRun = consumers > 0 && visible;
    if (shouldRun && handle === null) {
      //an immediate run on every start, which is what makes a tab shown again fresh at once
      run();
      handle = timers.setInterval(run, intervalMs);
    } else if (!shouldRun && handle !== null) {
      timers.clearInterval(handle);
      handle = null;
    }
  };

  return {
    acquire() {
      consumers += 1;
      sync();
      //idempotent: React Strict Mode and a cleanup that runs twice must not drive the count negative
      let released = false;
      return () => {
        if (released) {
          return;
        }
        released = true;
        consumers -= 1;
        sync();
      };
    },
    setVisible(next: boolean) {
      if (next === visible) {
        return;
      }
      visible = next;
      sync();
    },
    get running() {
      return handle !== null;
    },
    get consumers() {
      return consumers;
    },
  };
}
