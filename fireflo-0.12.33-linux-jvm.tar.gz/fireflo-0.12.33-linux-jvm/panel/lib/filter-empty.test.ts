import { strict as assert } from "node:assert";
import { test } from "node:test";
import { emptyFilterWarning, validateFilter, type FilterInput } from "./filter-types.ts";

/**
 * What an empty filter does, said the way the gateway does it.
 *
 * `DbFilterLoader` puts a filter with no conditions into the disabled set, and both `DbRateLoader`
 * and `DbRoutingLoader` skip every rule referencing a disabled filter. So an empty filter removes
 * rules from the running snapshot; the warning must not describe it as widening them.
 */

function filter(...conditions: FilterInput["conditions"]): FilterInput {
  return { name: "india", enabled: true, conditions };
}

const CONDITION = { field: "to", operator: "startsWith", value: "91", negate: false };

test("an empty filter is warned about", () => {
  assert.notEqual(emptyFilterWarning(filter()), null);
});

test("the warning says the rules are skipped, not that they match on their own", () => {
  const warning = emptyFilterWarning(filter()) ?? "";
  assert.match(warning, /skipped/);
  //the consequence, which is what makes it worth reading: that traffic is priced or routed by
  //whatever the rule would have won against
  assert.match(warning, /falls through to whatever matches next/);
  //and never the old claim, which was the opposite of what the loader does
  assert.doesNotMatch(warning, /narrows nothing|own conditions alone|matches everything/);
});

test("a filter with a condition is silent", () => {
  assert.equal(emptyFilterWarning(filter(CONDITION)), null);
});

test("an empty filter still saves, because it is a warning and not a refusal", () => {
  //one is built up a condition at a time, and refusing the first save would make that impossible
  assert.equal(validateFilter(filter()), null);
});
