import { strict as assert } from "node:assert";
import { test } from "node:test";
import {
  type UnratedPreflight,
  describe,
  preflightAdvice,
  preflightSentence,
} from "./unrated-preflight.ts";

/**
 * The sentence an operator reads before switching on a flag that refuses live traffic.
 *
 * <p>Its job is to be specific enough to act on. "Some traffic may be affected" and "4,102 messages
 * from 2 accounts" lead to different decisions, and only one of them is a decision.
 */

const preflight = (over: Partial<UnratedPreflight> = {}): UnratedPreflight => ({
  groups: [],
  total: 0,
  hours: 24,
  gauge: null,
  ...over,
});

test("nothing unpriced is stated as nothing, not as an empty list", () => {
  //the answer that makes the flag safe to switch on, and the one a count of zero renders as a blank
  //panel if nobody writes the sentence
  const sentence = preflightSentence(preflight());

  assert.match(sentence, /Nothing in the last 24 hours would have been refused/);
});

test("a real gap names the count, the accounts and the worst offender", () => {
  const sentence = preflightSentence(preflight({
    total: 4102,
    groups: [
      { accountId: "acme-in", product: "promo", messages: 4000 },
      { accountId: "beta-co", product: "promo", messages: 102 },
    ],
  }));

  assert.match(sentence, /4,102 messages/);
  assert.match(sentence, /2 accounts/);
  assert.match(sentence, /acme-in on promo \(4,000 messages\)/);
});

test("one message and one account are singular", () => {
  const sentence = preflightSentence(preflight({
    total: 1,
    groups: [{ accountId: "acme-in", product: "promo", messages: 1 }],
  }));

  assert.match(sentence, /1 message in the last/);
  assert.match(sentence, /from 1 account\./);
});

test("the same account under two products counts once as an account", () => {
  //the number that decides how much work the fix is. Counting rows instead would say two accounts
  //need pricing when one does
  const sentence = preflightSentence(preflight({
    total: 30,
    groups: [
      { accountId: "acme-in", product: "promo", messages: 20 },
      { accountId: "acme-in", product: "otp", messages: 10 },
    ],
  }));

  assert.match(sentence, /from 1 account\./);
});

test("messages with no product are described as that, not as a blank", () => {
  //a different diagnosis with a different fix: no rate rule can ever match a message with no
  //product, so pricing harder will not help -- the login or listener has to name one
  assert.match(
    describe({ accountId: "acme-in", product: "", messages: 12 }),
    /with no product on the message/
  );
});

test("the advice for a clean pre-flight says what switching it on still buys", () => {
  //"nothing would be refused" could read as "there is no reason to do this". There is: the next
  //account somebody onboards without a price
  assert.match(preflightAdvice(preflight()), /future account somebody onboards without a price/);
});

test("the advice offers the default as the quicker fix", () => {
  const advice = preflightAdvice(preflight({
    total: 10,
    groups: [{ accountId: "acme-in", product: "promo", messages: 10 }],
  }));

  assert.match(advice, /default for each product/);
  assert.doesNotMatch(advice, /no product at all/);
});

test("a group with no product adds the warning that pricing cannot fix it", () => {
  const advice = preflightAdvice(preflight({
    total: 10,
    groups: [{ accountId: "acme-in", product: "", messages: 10 }],
  }));

  assert.match(advice, /no product at all, which no rate rule can match/);
});
