/**
 * The five figures {@link reconcile} needs, gathered in one round trip.
 *
 * <p>Server-only, read-only. Nothing here writes, and the module has no write counterpart — see
 * `reconcile.ts` for why posting an adjusting entry for the residual is the one thing this feature
 * must never do.
 */

import { query } from "./metrics-db";
import { hasVendorAttempt } from "./metrics-schema";
import {
  consumedAllSql,
  consumedSql,
  CREDITED_ALL_SQL,
  CREDITED_SQL,
  MISSING_ROLLUP_SQL,
} from "./reconcile-sql";
import { reconcile, type ReconcileInput, type Reconciliation } from "./reconcile";

/**
 * `account_balance.spent` (gateway V1.95.0), or 0 on a schema without it. Read through the row's JSON
 * so the same text runs on both: naming a column that does not exist fails the whole statement.
 */
const SPENT_COLUMN = "COALESCE((to_jsonb(b) ->> 'spent')::bigint, 0)::text";

/**
 * Reconciles one account over its whole lifetime.
 *
 * @param zone must match `FIREFLO_BILLING_ZONE` on the gateway, or the tail is sliced differently
 *     from the rollup and the two disagree at the seam
 */
export async function reconcileAccount(
  accountId: string,
  zone: string,
  money: (scaled: number) => string
): Promise<Reconciliation | null> {
  const grain = { vendorAttempt: await hasVendorAttempt() };
  const [balances, credits, consumption, missing] = await Promise.all([
    query<{ balance: string; reserved: string; spent: string }>(
      `SELECT balance::text, reserved::text, ${SPENT_COLUMN} AS spent FROM account_balance b WHERE account_id = $1`,
      [accountId]
    ),
    query<{ credited: string; pending: string }>(CREDITED_SQL, [accountId]),
    query<{ consumed: string; unrated: string }>(consumedSql(grain), [accountId, zone]),
    query<{ days: string }>(MISSING_ROLLUP_SQL, [accountId, zone]),
  ]);

  const row = balances[0];
  if (!row) {
    //no balance row is not a discrepancy, it is an account nobody opened for credit
    return null;
  }

  const input: ReconcileInput = {
    accountId,
    credited: Number(credits[0]?.credited ?? 0),
    consumed: Number(consumption[0]?.consumed ?? 0),
    balance: Number(row.balance),
    reserved: Number(row.reserved),
    spent: Number(row.spent),
    pendingCredit: Number(credits[0]?.pending ?? 0),
    unratedMessages: Number(consumption[0]?.unrated ?? 0),
    daysMissingRollup: Number(missing[0]?.days ?? 0),
  };
  return reconcile(input, money);
}

/**
 * Every account that does not add up, for the platform-wide list.
 *
 * <p>Three grouped queries for the whole page (Audit F15), where this used to loop
 * {@link reconcileAccount} — 200 accounts made 801 serialised round trips on the shared read pool,
 * four lifetime scans EACH, and the page was on course for `statement_timeout` at scale. The
 * grouped SQL restates the per-account arithmetic under GROUP BY; the per-account text stays the
 * authority (and stays byte-identical for the single-account endpoint and the archive
 * cross-reference), and `reconcile-sql.test.ts` holds the two variants together.
 *
 * <p>All three queries derive their account set from the same `ORDER BY account_id LIMIT`, so
 * they describe the same page. They are still sequential, not parallel, for the reason the loop
 * was: this is a diagnostic on a shared pool of eight connections.
 */
export async function reconcileAll(
  zone: string,
  money: (scaled: number) => string,
  limit = 200
): Promise<Reconciliation[]> {
  const balances = await query<{ account_id: string; balance: string; reserved: string; spent: string }>(
    `SELECT account_id, balance::text, reserved::text, ${SPENT_COLUMN} AS spent
       FROM account_balance b ORDER BY account_id LIMIT $1`,
    [limit]
  );
  const credits = await query<{ account_id: string; credited: string; pending: string }>(
    CREDITED_ALL_SQL,
    [limit]
  );
  const consumption = await query<{
    account_id: string;
    consumed: string;
    unrated: string;
    days: string;
  }>(consumedAllSql({ vendorAttempt: await hasVendorAttempt() }), [zone, limit]);

  const creditsBy = new Map(credits.map((r) => [r.account_id, r]));
  const consumptionBy = new Map(consumption.map((r) => [r.account_id, r]));

  const out: Reconciliation[] = [];
  for (const row of balances) {
    const credit = creditsBy.get(row.account_id);
    const consumed = consumptionBy.get(row.account_id);
    const input: ReconcileInput = {
      accountId: row.account_id,
      credited: Number(credit?.credited ?? 0),
      consumed: Number(consumed?.consumed ?? 0),
      balance: Number(row.balance),
      reserved: Number(row.reserved),
      spent: Number(row.spent),
      pendingCredit: Number(credit?.pending ?? 0),
      unratedMessages: Number(consumed?.unrated ?? 0),
      daysMissingRollup: Number(consumed?.days ?? 0),
    };
    const result = reconcile(input, money);
    if (result && !result.balanced) {
      out.push(result);
    }
  }
  return out;
}
