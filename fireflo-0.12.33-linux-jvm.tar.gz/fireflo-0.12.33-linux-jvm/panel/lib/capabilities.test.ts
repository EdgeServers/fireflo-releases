import { test } from "node:test";
import assert from "node:assert/strict";
import { apiLevelSentence, capabilityNames, hasCapability } from "./capabilities.ts";
import type { Health } from "./health-types.ts";

const base = { observed_at: "", router_queue: 0, awaiting_receipt: 0, dlr_store_persistent: true, cdr: null, workers: [] };

test("a capability is a named true in the api map, and nothing else", () => {
  const health: Health = { ...base, api: { reload_adopted: true, send_client_ref: false } };
  assert.equal(hasCapability(health, "reload_adopted"), true);
  assert.equal(hasCapability(health, "send_client_ref"), false, "false is false");
  assert.equal(hasCapability(health, "never_heard_of"), false);
});

test("an older gateway, or no health at all, has no capabilities", () => {
  assert.equal(hasCapability({ ...base }, "reload_adopted"), false);
  assert.equal(hasCapability(null, "reload_adopted"), false);
  assert.equal(hasCapability(undefined, "reload_adopted"), false);
  assert.deepEqual(capabilityNames({ ...base }), []);
  assert.equal(apiLevelSentence({ ...base }), null, "no map is not an empty map");
});

test("the sentence lists the true names, sorted", () => {
  const health: Health = { ...base, api: { send_client_ref: true, config_key_status: true, schema_version: false } };
  assert.deepEqual(capabilityNames(health), ["config_key_status", "send_client_ref"]);
  assert.equal(apiLevelSentence(health), "This gateway answers API level config_key_status, send_client_ref.");
  assert.match(apiLevelSentence({ ...base, api: {} }) ?? "", /no capabilities declared/);
});
