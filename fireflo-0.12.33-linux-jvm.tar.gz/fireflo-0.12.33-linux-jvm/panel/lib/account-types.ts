/**
 * What a billing account is, with no database import anywhere.
 *
 * <p>Split from `accounts.ts` for the reason every `-types` module here is: a client component that
 * reaches a module which transitively imports `pg` does not break that page, it breaks every page.
 */

import { childIdProblem } from "./mis-account-rules.ts";

export interface Account {
  id: string;
  label: string | null;
  description: string | null;
  /**
   * Whether this account may send at all.
   *
   * <p><strong>From gateway 0.9.13 this stops traffic.</strong> `DbConfigPoller.loadCredentials`
   * left-joins `app_account` and withholds every credential whose account is disabled, so those
   * logins cannot bind and their submissions are refused, within one configuration poll
   * (`smsg.config.db.poll.seconds`, 30 by default). The gateway logs how many credentials it is
   * withholding and why, so traffic stopping is explained rather than mysterious.
   *
   * <p><strong>Against an older gateway it is still panel-side only</strong> and this field lies if
   * read casually: that gateway never reads `app_account`, so a disabled account keeps binding,
   * keeps sending and keeps being priced. On a mixed estate, disable the credentials as well.
   *
   * <p>Stopping credit is a separate switch, and stays one: `account_balance.enabled`. An account
   * can be enabled and out of credit, or disabled with credit intact, and neither implies the
   * other.
   */
  enabled: boolean;
  /**
   * Whether this account may hold other accounts beneath it and move balance to and from them.
   *
   * <p>Set by the operator; a reseller cannot promote itself. Clearing it while children exist is
   * refused by the database, not by this panel -- detach them first, which is the right order
   * anyway, since the alternative orphans accounts whose parent no longer has the right to hold
   * them.
   */
  resells: boolean;
  /**
   * The reseller this account belongs to, or null for a top-level account.
   *
   * <p>Exactly two levels, enforced in SQL: a composite foreign key forces a parent to be a
   * reseller, and a CHECK stops a child from reselling. So there are no sub-resellers, no cycles,
   * and nothing here has to walk a tree.
   */
  parentAccountId: string | null;
  /**
   * Where magic-link sign-in and notifications will send, once either exists.
   *
   * <p>Nothing reads this yet — the panel has no mailer and no second auth provider. It is stored
   * now so the address is already there when one is built, and because unique-per-account is a
   * property far cheaper to declare on an empty column than to retrofit onto a full one.
   *
   * <p>Unique case-insensitively (`uq_app_account_email` on `lower(email)`), but stored with
   * whatever case was typed: the local part of an address is case-sensitive per RFC 5321.
   */
  email: string | null;
  updatedAt: string | null;
}

export interface AccountSummary extends Account {
  /** Accounts sitting beneath this one. Always 0 unless {@link Account.resells}. */
  childCount: number;
  /** Logins whose billing resolves here, including by the system-id fallback. */
  credentialCount: number;
  /** Rules on this account's own price scope. */
  ruleCount: number;
  /** True when a vendor of the same name exists, which makes the rate scope ambiguous. */
  collidesWithVendor: boolean;
}

export interface AccountInput {
  id: string;
  label?: string | null;
  description?: string | null;
  email?: string | null;
  enabled: boolean;
  resells?: boolean;
  parentAccountId?: string | null;
  /**
   * Sets the portal password of the login at `email`. Write-only: never read back, never stored
   * anywhere but as a hash on the app_user row. Absent or empty means "leave it".
   */
  portalPassword?: string | null;
}

/** The id is compared by value against `msg.owner_id` and `app_rate_rule.scope`, so it is exact. */
/**
 * Whether an id nobody has used before may become an account.
 *
 * <p>`validateAccount` is the rule for a row -- lenient on purpose, because an ADOPTED id is
 * whatever the wire already bills to and must be nameable as it is. A freshly typed id has no such
 * excuse: it must survive being a URL segment, a rate scope and an SMPP system id unchanged, and it
 * must not be a vendor's name, because `app_rate_rule.scope` holds both kinds in one column. The
 * portal's `childIdProblem` already says all of that for a reseller's new customer; this is the same
 * sentence through the operator's door.
 *
 * @param taken every id already spoken for, accounts and vendors together (`takenAccountIds`)
 */
export function newAccountIdProblem(id: string, taken: readonly string[]): string | null {
  return childIdProblem(id, taken);
}

export function validateAccount(input: AccountInput): string | null {
  const id = input.id ?? "";
  if (!id.trim()) {
    return "An account id is required. It is what credentials, rate rules and balances all point at.";
  }
  if (id !== id.trim()) {
    return `'${id}' has a space at one end. Account ids are matched exactly and a trailing space is `
      + "invisible everywhere it is shown, so this would match nothing the gateway ever sends.";
  }
  const email = input.email?.trim() ?? "";
  if (email && !looksLikeEmail(email)) {
    return `'${email}' does not look like an email address. It needs something, an @, something, a `
      + "dot and something.";
  }
  return null;
}

/**
 * A shape check, deliberately loose.
 *
 * <p>Something, `@`, something, a dot, something — no character classes, no length caps, no
 * attempt at RFC 5322. The authority on whether an address works is a message that arrives, and
 * every strict email regex ever written rejects addresses that are valid. This exists to catch the
 * typo, not to adjudicate.
 */
function looksLikeEmail(value: string): boolean {
  const at = value.indexOf("@");
  if (at <= 0 || at !== value.lastIndexOf("@") || /\s/.test(value)) {
    return false;
  }
  const domain = value.slice(at + 1);
  const dot = domain.indexOf(".");
  return dot > 0 && dot < domain.length - 1;
}

/**
 * An account id in use with no catalogue row, and where it was found.
 *
 * <p>The two sources are not equally certain. A credential's billing key *is* an account. A bare
 * rate scope might be a vendor that was deleted — `app_rate_rule.scope` holds both kinds — so a
 * rate-scope-only orphan is a question rather than a finding, and the UI has to ask it rather than
 * assume.
 */
export interface OrphanAccount {
  id: string;
  fromCredential: boolean;
  fromRateScope: boolean;
}

/** The fields a catalogue write carries, apart from the id and the write-only portal password. */
export type AccountFields = Required<Omit<AccountInput, "id" | "portalPassword">>;

/**
 * What a catalogue write stores, given the row as it stands and the body as received.
 *
 * <p><strong>A field the body does not carry keeps the stored value.</strong> The write is one
 * upsert, and it used to read every absent field as null or false. The Settings tab's "Name this
 * account" form sends only a label, and it showed for a moment on every account while the
 * catalogue was still loading -- so saving it on an account that existed blanked its email and
 * description, and reset `resells` and `parentAccountId`, which detached a child from its
 * reseller. Absent now means "leave it"; a field that is present keeps its meaning, so an empty
 * string still clears.
 *
 * <p>A new row (no `before`) gets the defaults it always got: enabled, not reselling, top-level.
 */
export function mergeAccountInput(before: Account | null, body: Record<string, unknown>): AccountFields {
  const has = (key: string) => Object.prototype.hasOwnProperty.call(body, key) && body[key] !== undefined;
  const str = (key: string) => (typeof body[key] === "string" ? (body[key] as string) : null);
  return {
    label: has("label") ? str("label") : before?.label ?? null,
    description: has("description") ? str("description") : before?.description ?? null,
    email: has("email") ? str("email") : before?.email ?? null,
    enabled: has("enabled") ? body.enabled !== false : before ? before.enabled : true,
    resells: has("resells") ? body.resells === true : before?.resells ?? false,
    parentAccountId: has("parentAccountId") ? str("parentAccountId") : before?.parentAccountId ?? null,
  };
}
