import path from "node:path";

/**
 * Where this install may write, resolved in exactly one place.
 *
 * <p>The service runs under `ProtectSystem=strict` with `ReadWritePaths=` naming only the
 * application and data directories, so a path outside them does not fail at review — it fails at
 * runtime, on a customer's machine, the first time somebody tries to write. Everything that touches
 * disk goes through here so there is one answer to "where is that allowed to go".
 */

/**
 * Prepared CSV exports.
 *
 * <p>`turbopackIgnore` because this path is MEANT to be outside the project: a packaged install
 * writes to the service's data directory, chosen at install time and nowhere near the build.
 * Without the hint the bundler sees a filesystem path it cannot resolve statically, assumes it must
 * ship whatever might be there, and traces the entire project into the server output.
 */
export function exportDir(): string {
  return path.resolve(/*turbopackIgnore: true*/ process.env.CDR_EXPORT_DIR?.trim() || "./tmp/exports");
}

/**
 * The access log, a sibling of the exports rather than a directory of its own naming.
 *
 * <p>Derived rather than configured, deliberately. `fireflo-panel-install` recovers the data
 * directory by stripping `/exports` off `CDR_EXPORT_DIR` (`data_dir_from_env`), and the unit's
 * `ReadWritePaths=$DATA_DIR` already covers everything beneath it. A sibling therefore works on
 * every install that already exists, with no new variable to add to `panel.env` and no `service`
 * re-run — where a new variable would be absent from every deployed environment and the failure
 * mode is an audit trail that silently is not there.
 *
 * <p>It also inherits {@link exportDir}'s `turbopackIgnore`: a second `process.env` feeding
 * `path.resolve` would need its own hint, and forgetting it re-trips the whole-project tracing
 * described above.
 *
 * <p>The cost is that `CDR_EXPORT_DIR` is now load-bearing for two features. Moving it moves the
 * access log too, which is the right behaviour but worth knowing before someone changes it.
 */
export function accessLogDir(): string {
  return path.resolve(exportDir(), "..", "access");
}
