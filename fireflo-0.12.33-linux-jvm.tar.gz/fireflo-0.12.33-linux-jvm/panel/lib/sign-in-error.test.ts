import { test } from "node:test";
import assert from "node:assert/strict";
import { signInErrorMessage } from "./sign-in-error.ts";

const http = { protocol: "http:", origin: "http://smsc.example.com" };
const https = { protocol: "https:", origin: "https://smsc.example.com" };

test("a wrong username or password is not broken down into which half", () => {
  const message = signInErrorMessage("CredentialsSignin", https);
  assert.match(message, /^Sign-in failed\. Check the username and password\./);
  assert.doesNotMatch(message.toLowerCase(), /password (is|was) (wrong|incorrect)|unknown user|no such user/);
  //the way back in when nobody can sign in is named, because the old message named OPERATOR_PASSWORD
  //and that variable no longer decides anything
  assert.match(message, /fireflo user passwd/);
});

test("a dropped sign-in cookie on plain HTTP says so, and names this page's address", () => {
  //found on a fresh install: the operator reset the password twice before the journal showed
  //MissingCSRF, which no password could fix
  const message = signInErrorMessage("MissingCSRF", http);
  assert.match(message, /before the password was checked/);
  assert.match(message, /plain HTTP/);
  assert.match(message, /AUTH_URL=http:\/\/smsc\.example\.com/);
  assert.match(message, /AUTH_COOKIE_SECURE=false/);
  assert.doesNotMatch(message, /Check the credentials/);
});

test("a dropped sign-in cookie over HTTPS points at the cookies and the proxy instead", () => {
  const message = signInErrorMessage("MissingCSRF", https);
  assert.match(message, /before the password was checked/);
  assert.match(message, /AUTH_URL in panel\.env is https:\/\/smsc\.example\.com/);
  assert.doesNotMatch(message, /plain HTTP/);
});

test("a server-side fault names its type rather than blaming the credentials", () => {
  const message = signInErrorMessage("Configuration", https);
  assert.match(message, /\(Configuration\)/);
  assert.match(message, /journalctl/);
  assert.doesNotMatch(message, /Check the credentials/);
});
