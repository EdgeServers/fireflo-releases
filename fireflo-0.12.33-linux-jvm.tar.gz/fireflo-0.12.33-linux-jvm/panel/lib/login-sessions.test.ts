import { test } from "node:test";
import assert from "node:assert/strict";
import { bindLabel, boundFor, connectionView, type SessionSummary } from "./login-sessions.ts";

const summary = (patch: Partial<SessionSummary> = {}): SessionSummary => ({
  sessions: 3, tx: 1, rx: 1, trx: 1, listeners: ["smppserver.main"], hosts: ["10.0.0.4"],
  by_listener: {}, oldest_bound_seconds: 8040, submitted: 1284, rows: [], ...patch,
});
const noLimits = { maxSessions: null, maxTx: null, maxRx: null, maxTrx: null, maxTps: null };

test("a login with no limits of its own shows counts and no 'of N'", () => {
  const v = connectionView(summary(), noLimits);
  assert.equal(v.connected, true);
  assert.equal(v.sessions, 3);
  assert.equal(v.limit, null);
  assert.deepEqual(v.binds.map((b) => [b.key, b.count, b.limit, b.full]), [["TX", 1, null, false], ["RX", 1, null, false], ["TRX", 1, null, false]]);
  assert.equal(v.note, null);
});

test("only the limits that are set appear, and a full bind type says so", () => {
  const v = connectionView(summary({ sessions: 4, trx: 2 }), { ...noLimits, maxSessions: 5, maxTrx: 2 });
  assert.equal(v.limit, 5);
  assert.equal(v.full, false);
  assert.deepEqual(v.binds.map((b) => b.limit), [null, null, 2]);
  assert.equal(v.binds[2].full, true);
  assert.equal(v.note, "TRX is at its limit: the next TRX bind there is refused.");
});

test("at the session limit, that is the sentence", () => {
  const v = connectionView(summary({ sessions: 5 }), { ...noLimits, maxSessions: 5 });
  assert.equal(v.full, true);
  assert.equal(v.note, "At its limit of 5 sessions: the next bind there is refused.");
});

test("limits are per listener: a total split across two listeners is not at the limit", () => {
  const split = summary({
    sessions: 4, tx: 0, rx: 0, trx: 4, listeners: ["smppserver.a", "smppserver.b"],
    by_listener: { "smppserver.a": { sessions: 2, tx: 0, rx: 0, trx: 2 }, "smppserver.b": { sessions: 2, tx: 0, rx: 0, trx: 2 } },
  });
  const v = connectionView(split, { ...noLimits, maxSessions: 4, maxTrx: 3 });
  assert.equal(v.perListener, true);
  assert.equal(v.full, false);
  assert.equal(v.binds[2].count, 4);
  assert.equal(v.binds[2].full, false);
  assert.equal(v.note, null);
  //one listener at its TRX limit is
  const w = connectionView(split, { ...noLimits, maxTrx: 2 });
  assert.equal(w.note, "TRX is at its limit on a listener: the next TRX bind there is refused.");
});

test("absent from the gateway's answer is not connected", () => {
  const v = connectionView(undefined, { ...noLimits, maxSessions: 2 });
  assert.equal(v.connected, false);
  assert.equal(v.sessions, 0);
  assert.equal(v.full, false);
  assert.equal(v.note, null);
});

test("durations and bind names read the way the card shows them", () => {
  assert.equal(boundFor(45), "45 s");
  assert.equal(boundFor(36 * 60), "36 m");
  assert.equal(boundFor(8040), "2 h 14 m");
  assert.equal(boundFor(5 * 86400 + 3 * 3600), "5 d 3 h");
  assert.equal(boundFor(null), "—");
  assert.equal(bindLabel("TRANSCEIVER"), "TRX");
  assert.equal(bindLabel(null), "binding");
});
