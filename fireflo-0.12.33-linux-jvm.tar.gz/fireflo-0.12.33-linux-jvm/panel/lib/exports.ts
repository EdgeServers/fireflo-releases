import { createHash, randomUUID } from "node:crypto";
import { appendFile, mkdir, readFile, readdir, rm, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import { auditConfigChange } from "@/lib/config-audit";
import { exportDir } from "@/lib/data-dir";

/**
 * CSV exports as requests that are processed and then collected, rather than a download that streams
 * for four minutes and dies when a laptop lid closes.
 *
 * <p><b>No database table, deliberately.</b> The CDR database is documented as read-only from this
 * panel, and the export queue is state only the panel owns. Putting it in the gateway's schema would
 * couple the two projects together for the sake of a CSV, and would need a migration in the other
 * repo every time this feature changed.
 *
 * <p>So: one directory, one JSON manifest and one CSV per request. The manifest is written before
 * the work starts and rewritten at each checkpoint, which means a crashed process leaves a request
 * marked `running` that never finishes -- {@link listExports} detects and reports that rather than
 * letting it sit there looking busy forever.
 *
 * <p><strong>Generic over the row type.</strong> Everything here — the manifest, the retention
 * sweep, the interrupted-job detection, the path guard, the batching — is about running a long job
 * and handing back a file, and none of it was ever about call records. What was specific to them
 * moved to `cdr-export.ts`; refusals supply the same three things from `rejected-export.ts`. The
 * split is worth stating beside the opposite decision made for the cell renderers: generalise where
 * the row type never appears, fork where it appears in every branch.
 *
 * <h3>Known limit</h3>
 *
 * <p>This is local disk. It is correct for one panel process and wrong the moment there are two
 * behind a load balancer: a request served by instance A produces a file instance B cannot find, and
 * the symptom is an intermittent 404 on a download button that works when you retry it. Stated
 * rather than designed around, because this panel is single-instance today.
 */

export type ExportStatus = "queued" | "running" | "ready" | "failed";

export interface ExportJob {
  id: string;
  /**
   * Which export this is: `cdrs`, `rejected`.
   *
   * <p>Written into the manifest and into the filename, so it must stay stable once it has shipped.
   * {@link load} defaults a missing one to `cdrs` — manifests written before this field existed are
   * on disk right now, and without that default every one of them would vanish from the list.
   */
  kind: string;
  status: ExportStatus;
  requestedAt: string;
  finishedAt: string | null;
  /** Rows written so far — the only progress signal there is, since the total is not known up front. */
  rows: number;
  /** Human-readable summary of the filters, so a list of requests is not a list of identical rows. */
  label: string;
  filters: SerialisedFilters;
  error: string | null;
  /** Bytes on disk, once finished. */
  bytes: number | null;
}

/** Dates as ISO strings, because a manifest round-trips through JSON. */
export type SerialisedFilters = Record<string, string | boolean>;

/**
 * What one kind of export has to supply. Everything else is this module's problem.
 *
 * @param Row what `page` yields and `toCsvLine` writes
 * @param Filters the query layer's filter shape for that row
 */
export interface ExportSource<Row, Filters> {
  /** Stable across releases: it names the file and identifies the job. */
  kind: string;
  /**
   * Column order, fixed and append-only.
   *
   * <p>Whoever imports this into a spreadsheet builds formulas against column letters. Reordering
   * later breaks those silently, so new columns go on the end — in every export, not just the first.
   */
  headers: readonly string[];
  /** One row, already terminated with a newline. */
  toCsvLine(row: Row): string;
  /** One batch, keyset-paged. The cursor is opaque here: only the source knows its shape. */
  page(
    filters: Filters,
    cursor: unknown,
    batch: number
  ): Promise<{ rows: Row[]; nextCursor: unknown }>;
  serialise(filters: Filters): SerialisedFilters;
}

/** Rows per query. Small enough to stay inside the pool's 10s `statement_timeout`, large enough not to thrash. */
const BATCH = 5_000;

/** A request older than this is deleted on the next list call. Without it the directory grows until the disk fills. */
const RETENTION_DAYS = 7;

/** A single export must not walk the whole table forever; at this point something is wrong with the filters. */
const MAX_ROWS = 2_000_000;

/** Jobs started by this process, so a second click cannot start the same work twice. */
const running = new Set<string>();

//exportDir now lives in lib/data-dir.ts, with the turbopackIgnore reasoning intact. It moved when
//the access log needed a directory beside this one: two modules resolving CDR_EXPORT_DIR
//independently is how the two end up disagreeing about where the data directory is.

/**
 * Resolves a job's file, refusing anything that escapes the export directory.
 *
 * <p>The id comes from a URL. Even though every id this module creates is a UUID, the check is on
 * the resolved path rather than on the shape of the id, because a validator that accepts what looks
 * safe is how `..%2f` gets through.
 */
function resolveWithin(dir: string, name: string): string | null {
  const resolved = path.resolve(dir, name);
  //the separator matters: without it `/exports-evil` passes a `startsWith('/exports')` check
  return resolved === dir || resolved.startsWith(dir + path.sep) ? resolved : null;
}

function manifestPath(id: string): string | null {
  return resolveWithin(exportDir(), `${id}.json`);
}

export function csvPath(id: string): string | null {
  return resolveWithin(exportDir(), `${id}.csv`);
}

/**
 * Records the request and starts the work.
 *
 * <p>Returns as soon as the manifest exists. The work continues on the process's event loop; the
 * caller is expected to poll {@link listExports}.
 */
export async function requestExport<Row, Filters>(
  source: ExportSource<Row, Filters>,
  filters: Filters,
  label: string
): Promise<ExportJob> {
  const dir = exportDir();
  await mkdir(dir, { recursive: true });

  const job: ExportJob = {
    id: randomUUID(),
    kind: source.kind,
    status: "queued",
    requestedAt: new Date().toISOString(),
    finishedAt: null,
    rows: 0,
    label,
    filters: source.serialise(filters),
    error: null,
    bytes: null,
  };
  await save(job);

  //not awaited: the point of this endpoint is to answer immediately. The rejection handler is not
  //optional -- an unhandled rejection here would take the whole process down in Node
  void runExport(job.id, source, filters).catch((err) => {
    console.error(`${source.kind} export crashed`, err);
  });
  //the request, with its filters; the download itself is a separate `download` event when it
  //happens, and the two together say who asked for which records and who took them
  await auditConfigChange({
    domain: "export",
    name: `${source.kind} ${job.id}`,
    action: "request",
    after: { label, filters: job.filters },
  });
  return job;
}

/**
 * The worker: pages the same keyset query the browser uses, appending as it goes.
 *
 * <p>Batching is what keeps each query inside the 10-second `statement_timeout` and stops one export
 * monopolising a pool of eight connections shared with the dashboard's polling. It is also what
 * makes progress visible: a single enormous query would show nothing until it either finished or
 * timed out.
 */
async function runExport<Row, Filters>(
  id: string,
  source: ExportSource<Row, Filters>,
  filters: Filters
): Promise<void> {
  if (running.has(id)) {
    return;
  }
  running.add(id);
  try {
    const file = csvPath(id);
    const job = await load(id);
    if (!file || !job) {
      return;
    }

    job.status = "running";
    await save(job);
    await writeFile(file, `${source.headers.join(",")}\n`, "utf8");

    let cursor: unknown = null;
    let rows = 0;
    for (;;) {
      //the CSV is the complete record, whatever the table on screen is showing
      const page = await source.page(filters, cursor, BATCH);
      if (page.rows.length) {
        await appendFile(file, page.rows.map(source.toCsvLine).join(""), "utf8");
        rows += page.rows.length;
      }
      cursor = page.nextCursor;

      //checkpoint on the manifest, not on every row: this is what the progress column reads
      if (job.rows !== rows) {
        job.rows = rows;
        await save(job);
      }
      if (!cursor) {
        break;
      }
      if (rows >= MAX_ROWS) {
        throw new Error(
          `Stopped at ${MAX_ROWS.toLocaleString()} rows. Narrow the time range or add a filter.`
        );
      }
    }

    job.status = "ready";
    job.finishedAt = new Date().toISOString();
    job.bytes = await sizeOf(file);
    await save(job);
  } catch (err) {
    const job = await load(id);
    if (job) {
      job.status = "failed";
      job.finishedAt = new Date().toISOString();
      //kept rather than swallowed: "failed" with no reason sends someone to read server logs they
      //may not have
      job.error = err instanceof Error ? err.message : String(err);
      await save(job);
    }
  } finally {
    running.delete(id);
  }
}

/**
 * Every request, newest first, with expired ones deleted on the way past.
 *
 * <p>Retention runs here rather than on a timer because this process has no scheduler and a
 * `setInterval` in a module that Next may evaluate more than once is a good way to get four of them.
 */
export async function listExports(kind?: string): Promise<ExportJob[]> {
  const dir = exportDir();
  let names: string[];
  try {
    names = await readdir(dir);
  } catch {
    //nothing has been exported yet, which is not an error
    return [];
  }

  const cutoff = Date.now() - RETENTION_DAYS * 86_400_000;
  const jobs: ExportJob[] = [];
  for (const name of names) {
    if (!name.endsWith(".json")) {
      continue;
    }
    const job = await load(name.slice(0, -5));
    if (!job) {
      continue;
    }
    //retention runs BEFORE the kind filter, so every kind is swept whichever page called. Filtering
    //first would mean a page that never lists refusal exports is the reason they live forever
    if (new Date(job.requestedAt).getTime() < cutoff) {
      await discard(job.id);
      continue;
    }
    if (kind && job.kind !== kind) {
      continue;
    }
    //a job marked running that this process is not running was interrupted by a restart. Reporting
    //it as still working would leave a spinner turning until the retention window expires
    if ((job.status === "running" || job.status === "queued") && !running.has(job.id)) {
      job.status = "failed";
      job.error = "Interrupted — the panel restarted while this export was being prepared.";
      job.finishedAt = job.finishedAt ?? new Date().toISOString();
      await save(job);
    }
    jobs.push(job);
  }
  jobs.sort((a, b) => b.requestedAt.localeCompare(a.requestedAt));
  return jobs;
}

export async function getExport(id: string): Promise<ExportJob | null> {
  return load(id);
}

/** Removes both files. Missing files are not an error — this also runs as retention cleanup. */
export async function discard(id: string): Promise<void> {
  for (const file of [manifestPath(id), csvPath(id)]) {
    if (file) {
      await rm(file, { force: true });
    }
  }
}

async function load(id: string): Promise<ExportJob | null> {
  const file = manifestPath(id);
  if (!file) {
    return null;
  }
  try {
    const parsed = JSON.parse(await readFile(file, "utf8"));
    if (!parsed || typeof parsed !== "object" || parsed.id !== id) {
      return null;
    }
    //THE migration, and it is one line. Manifests written before `kind` existed are on disk in every
    //deployment; without this default they would fail no check and simply stop being listed, which
    //reads as every past export having been deleted
    return { kind: "cdrs", ...parsed } as ExportJob;
  } catch {
    return null;
  }
}

async function save(job: ExportJob): Promise<void> {
  const file = manifestPath(job.id);
  if (file) {
    await writeFile(file, JSON.stringify(job, null, 2), "utf8");
  }
}

/** Null rather than a throw: a missing size makes the list slightly less informative, not broken. */
async function sizeOf(file: string): Promise<number | null> {
  try {
    return (await stat(file)).size;
  } catch {
    return null;
  }
}

/**
 * The default `serialise` for a filter object of scalars and Dates, which is what both sources have.
 *
 * <p>On {@link ExportSource} rather than applied here, so a source with a filter shape this does not
 * suit can say so instead of silently writing `[object Object]` into a manifest an operator reads.
 */
export function serialiseFilters(filters: object): SerialisedFilters {
  const out: SerialisedFilters = {};
  for (const [key, value] of Object.entries(filters)) {
    if (value == null || value === "") {
      continue;
    }
    out[key] = value instanceof Date ? value.toISOString() : (value as string | boolean);
  }
  return out;
}

/**
 * Stable name for the downloaded file, so two exports do not both land as `cdrs.csv`.
 *
 * <p>Keyed off `job.kind`, which is what keeps a call-record export producing byte-identical
 * filenames to the ones this panel has always produced.
 */
export function downloadName(job: ExportJob): string {
  const stamp = job.requestedAt.slice(0, 19).replace(/[:T]/g, "-");
  const tag = createHash("sha256").update(job.id).digest("hex").slice(0, 6);
  return `fireflo-${job.kind}-${stamp}-${tag}.csv`;
}
