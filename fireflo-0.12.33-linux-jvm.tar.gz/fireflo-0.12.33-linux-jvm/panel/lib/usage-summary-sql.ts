/**
 * One window of traffic and money, read from `usage_daily` where it can be and `cdr_submit` where it
 * must be, with no database import.
 *
 * <p>The dashboard aggregates used to read every range straight from the call records: a
 * `DISTINCT ON (gateway_msg_id) s.*` over the whole window, sorted by a key no index orders, then a
 * LATERAL into `cdr_final` per row. At seven and thirty days that is a sort of every wide row in the
 * window, and it runs once per open tab per minute (Audit CP-P1). The gateway already maintains the
 * same figures at the same grain -- one `usage_daily` line per account, product and billing day --
 * so a finished day is read from there and only the open end of the window from the records.
 *
 * <h2>The window-split rule</h2>
 *
 * <p>Days are billing days, cut in `smsg.billing.zone` exactly as `UsageRollup` cuts them. Given
 * `[since, until)`:
 *
 * <ul>
 *   <li><b>Rolled:</b> every `usage_daily` line whose day lies <em>wholly</em> inside the window.
 *       Today is never one of them: `until` is at most now, and now is inside today.</li>
 *   <li><b>Live:</b> `cdr_submit` from `GREATEST(since, LEAST(tail_from, end of the last full day))`
 *       to `until`, where `tail_from` is {@link rollupTailFrom}: local midnight of the day before
 *       the rollup's newest line. Inside that range a row on a full day is skipped when its
 *       (account, day, product) line exists -- it is already counted in Rolled -- and a row on the
 *       trailing partial day (today) is always taken, however stale a line for today may be. A
 *       partial day at the <em>front</em> of the window, when the caller did not ask for whole days,
 *       is read live too, with no anti-join, because Rolled never includes it.</li>
 * </ul>
 *
 * <p>The two halves are disjoint by construction, as `consumedSql`'s are: a line is counted from
 * `usage_daily` or its rows from `cdr_submit`, never both. What is given up, deliberately, is a day
 * older than `tail_from` that has traffic and no line -- the rollup's purge interlock exists to make
 * that impossible for any day old enough to be purged, and `fireflo usage rollup --catch-up` closes
 * it for the rest. The bound is what lets `idx_cdr_submit_time` and the account covering index do
 * the work instead of a scan of the window.
 *
 * <h2>What the summary table cannot say</h2>
 *
 * <p>`usage_daily` has no hour, no login (`system_id`), no vendor and no failure reason, and it
 * cannot tell a vendor-refused message from an unrated one. So:
 *
 * <ul>
 *   <li>An <b>hourly</b> series is live over its whole window from {@link usageWindowSql}; a
 *       gateway with the hourly summary (V1.91.0, `usage_hourly`) serves it through
 *       {@link usageHourlySql} instead, which has its own seam rule below.</li>
 *   <li>The <b>failure breakdown</b> (final state, DLR state, error code) is live and limited to the
 *       tail -- today in the billing zone, or the last 24 hours, whichever is longer; see
 *       {@link FAILURE_WINDOW_SINCE}.</li>
 *   <li><b>Logins</b> are carried on live rows only, and a caller that merges rolled days drops
 *       them, so one account is one row rather than a rolled row beside a row per login.</li>
 *   <li><b>Refused</b> messages are excluded from a rolled day's count as 0, not as the true figure:
 *       the line's `submitted` includes them. <b>Pending revenue</b> on a rolled day reads 0 for a
 *       better reason: the sweeper closes anything older than 48 hours as EXPIRED, and `tail_from`
 *       is never later than yesterday's midnight, so in-flight money is in the live half.</li>
 * </ul>
 *
 * <h2>Bind parameters</h2>
 *
 * <p>`$1` since, `$2` until (both `timestamptz`), `$3` the billing zone, and `$4` the account id when
 * {@link UsageWindowOptions.account} is set, or a `text[]` of account ids when
 * {@link UsageWindowOptions.accounts} is. Every caller appends its own `SELECT` over the CTE
 * `usage_rows`, whose columns are {@link USAGE_ROW_COLUMNS}. {@link usageHourlySql} takes the same
 * binds and yields the same CTE.
 */

import { messageRows, rollupTailFrom, type GrainOptions } from "./cdr-grain.ts";

/**
 * The outcome of a message, deduplicated.
 *
 * <p>Here rather than in `metrics-queries.ts` so a module with no database import can build the
 * live half; `metrics-queries.ts` re-exports it, and `statement-queries.ts` reads it from there. A
 * second copy would drift, and the drift would be a delivery count on an invoice disagreeing with
 * the delivery count on the dashboard beside it.
 *
 * <p>Taken as a LATERAL rather than a grouped join so it uses `idx_cdr_final_msg_part` and returns
 * exactly one row however many receipts arrived. Ordered by `final_at` so the first terminal
 * outcome wins -- the expiry sweeper only writes EXPIRED for messages that never had one, so it
 * cannot displace a real receipt.
 */
export const OUTCOME_LATERAL = `
  LEFT JOIN LATERAL (
    SELECT f.final_state, f.dlr_state, f.err_code
      FROM cdr_final f
     WHERE f.gateway_msg_id = s.gateway_msg_id AND f.part_no = s.part_no
     --A real receipt outranks a swept EXPIRED, whichever landed first: EXPIRED is synthetic,
     --written by the gateway's expiry sweep, and a genuine receipt can still arrive after it
     --because the correlation index outlives the deadline. false sorts before true.
     --SAME RULE IN UsageRollup.java AND THREE OTHER lib/ QUERIES. Change one, change all five.
     ORDER BY (f.final_state = 'EXPIRED'), f.final_at
     LIMIT 1
  ) o ON TRUE`;

/**
 * What the live half carries through the per-message `DISTINCT ON`: the correlation keys for the
 * outcome LATERAL, the grouping dimensions, and the two money columns. Never `body` or the TLVs.
 */
export const LIVE_COLUMNS = [
  "gateway_msg_id",
  "part_no",
  "account_id",
  "system_id",
  "product",
  "submitted_at",
  "price",
  "cost",
] as const;

/** The columns of `usage_rows`, in order, for both halves. */
export const USAGE_ROW_COLUMNS = [
  "bucket",
  "day",
  "account_id",
  "system_id",
  "product",
  "submitted",
  "delivered",
  "failed",
  "expired",
  "pending",
  "price",
  "cost",
  "pending_price",
  "refused",
  "last_seen",
] as const;

/**
 * `date_trunc('hour', x)` as a UTC hour, whatever the session's time zone.
 *
 * <p>`date_trunc` on a `timestamptz` truncates in the session zone, and a session in a half-hour
 * zone (Asia/Kolkata is +05:30) cuts its hours at :30. The hourly summary's rows are UTC hours by
 * CHECK constraint, and the home page's snapshot merges buckets by their UTC key, so every hourly
 * bucket here is cut the same way. Same expression as the gateway's rollup.
 */
export function hourUtc(expr: string): string {
  return `(date_trunc('hour', ${expr} AT TIME ZONE 'UTC') AT TIME ZONE 'UTC')`;
}

export interface UsageWindowOptions extends GrainOptions {
  /** `hour` buckets are UTC hours, live by construction (see the module doc); `day` buckets are billing days. */
  bucket: "hour" | "day";
  /** Filter both halves to the account in `$4`, and take the rollup horizon from its own lines. */
  account: boolean;
  /**
   * Filter both halves to the accounts in `$4`, a `text[]`, and take the rollup horizon from their
   * lines. For the portal, whose boundary is a session's scope rather than one id. Exclusive with
   * {@link account}; `account` wins when both are set.
   */
  accounts?: boolean;
  /**
   * Widen `since` back to the start of its billing day.
   *
   * <p>The named ranges are `now() - N days`, an instant in the middle of a day, and a partial
   * leading day could only be served live -- a day's scan to show a sliver. Whole days make the
   * leading day a full one, so it comes from the summary. A statement passes its own boundaries
   * and leaves this off.
   */
  wholeDays: boolean;
  /** Keep `system_id` on live rows. Rolled rows never have one. */
  logins?: boolean;
  /** Count vendor-refused messages on live rows, by probing `cdr_rejected` per message. */
  refused?: boolean;
}

/**
 * The `WITH` prelude: `cut`, `rolled`, `live` and `usage_rows`. The caller appends its `SELECT`.
 */
export function usageWindowSql(o: UsageWindowOptions): string {
  const acct = accountBind(o);
  const since = o.wholeDays
    ? "(($1::timestamptz AT TIME ZONE $3)::date::timestamp AT TIME ZONE $3)"
    : "$1::timestamptz";
  const bucket =
    o.bucket === "hour"
      ? hourUtc("s.submitted_at")
      : "((s.submitted_at AT TIME ZONE $3)::date::timestamp AT TIME ZONE $3)";

  //the live half's anti-join, at the summary's own grain -- (account, day, product), with the
  //rollup's COALESCE so unattributed traffic matches the '' line it was summarised under -- applied
  //only to rows on a day Rolled could hold. Today's rows are taken whether or not a line for today
  //exists: the rollup writes today's line while the day is still open
  const covered = `(s.submitted_at >= cut.end_full_at
                 OR NOT EXISTS (
                        SELECT 1 FROM usage_daily u
                         WHERE u.account_id = COALESCE(s.account_id, '')
                           AND u.day = (s.submitted_at AT TIME ZONE $3)::date
                           AND u.product = COALESCE(s.product, '')))`;
  const mine = acct ? ` AND s.account_id = ${acct}` : "";

  //the tail: from the seam to the end of the window, one index range
  const tail = messageRows(
    `s.submitted_at >= GREATEST(cut.since, cut.first_full_at, LEAST(cut.tail_from, cut.end_full_at))
         AND s.submitted_at < cut.until${mine}
         AND ${covered}`,
    o,
    LIVE_COLUMNS
  );
  //a partial day at the front of the window, when the caller kept its own `since`: nothing of it is
  //in Rolled, so all of it is read. Empty when `since` is a billing-day boundary
  const head = o.wholeDays
    ? ""
    : `
             SELECT * FROM ${messageRows(
               `s.submitted_at >= cut.since
         AND s.submitted_at < LEAST(cut.until, cut.first_full_at)${mine}`,
               o,
               LIVE_COLUMNS
             )}
             UNION ALL`;

  return `
  WITH cut AS (
      SELECT w.since, w.until, w.first_day, w.end_day,
             (w.first_day::timestamp AT TIME ZONE $3) AS first_full_at,
             (w.end_day::timestamp AT TIME ZONE $3)   AS end_full_at,
             ${rollupTailFrom("$3", acct)} AS tail_from
        FROM (SELECT b.since, b.until,
                     --the first billing day that starts at or after since, and the day until falls
                     --in: days [first_day, end_day) lie wholly inside the window
                     ((b.since AT TIME ZONE $3) - interval '1 microsecond')::date + 1 AS first_day,
                     (b.until AT TIME ZONE $3)::date                                   AS end_day
                FROM (SELECT ${since} AS since, $2::timestamptz AS until) b) w
  ),
  rolled AS (
      SELECT (u.day::timestamp AT TIME ZONE $3) AS bucket,
             u.day                              AS day,
             NULLIF(u.account_id, '')           AS account_id,
             NULL::text                         AS system_id,
             NULLIF(u.product, '')              AS product,
             u.submitted, u.delivered, u.failed, u.expired,
             u.pending_at_rollup                AS pending,
             u.price_total                      AS price,
             u.cost_total                       AS cost,
             0::bigint                          AS pending_price,
             0::bigint                          AS refused,
             --day precision is all a line has: the start of the day stands for "seen that day"
             (u.day::timestamp AT TIME ZONE $3) AS last_seen
        FROM cut, usage_daily u
       WHERE u.day >= cut.first_day AND u.day < cut.end_day${acct ? ` AND u.account_id = ${acct}` : ""}
  ),
  live AS (
      ${liveSelect(bucket, o)}
        --one row per message, as UsageRollup, over the live range only
        FROM cut, LATERAL (${head}
             SELECT * FROM ${tail}
        ) s${OUTCOME_LATERAL}
       GROUP BY 1, 2, 3, 4, 5
  ),
  ${usageRowsUnion()}`;
}

/** The bind the account filter compares to: one id, a set, or nothing. */
function accountBind(o: Pick<UsageWindowOptions, "account" | "accounts">): string | null {
  return o.account ? "$4" : o.accounts ? "ANY($4)" : null;
}

/** The live half's SELECT list: the same aggregate, whichever table the rolled half came from. */
function liveSelect(bucket: string, o: Pick<UsageWindowOptions, "logins" | "refused">): string {
  return `SELECT ${bucket}                                                   AS bucket,
             (s.submitted_at AT TIME ZONE $3)::date                      AS day,
             s.account_id                                                AS account_id,
             ${o.logins ? "s.system_id" : "NULL::text"}                  AS system_id,
             s.product                                                   AS product,
             count(*)                                                    AS submitted,
             count(*) FILTER (WHERE o.final_state = 'DELIVERED')          AS delivered,
             count(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED')) AS failed,
             count(*) FILTER (WHERE o.final_state = 'EXPIRED')            AS expired,
             count(*) FILTER (WHERE o.final_state IS NULL)                AS pending,
             COALESCE(SUM(s.price), 0)                                    AS price,
             COALESCE(SUM(s.cost), 0)                                     AS cost,
             COALESCE(SUM(s.price) FILTER (WHERE o.final_state IS NULL), 0) AS pending_price,
             ${
               o.refused
                 ? //asked of cdr_rejected rather than of final_state, which cannot tell a vendor's
                   //refusal from a carrier's REJECTD receipt on a message that WAS accepted and is
                   //legitimately billed. Served by idx_cdr_rejected_msg
                   `count(*) FILTER (WHERE EXISTS (SELECT 1 FROM cdr_rejected r
                                                    WHERE r.gateway_msg_id = s.gateway_msg_id
                                                      AND r.reason = 'vendorRejected'))`
                 : "0::bigint"
             } AS refused,
             max(s.submitted_at)                                         AS last_seen`;
}

function usageRowsUnion(): string {
  return `usage_rows AS (
      SELECT ${USAGE_ROW_COLUMNS.join(", ")} FROM rolled
      UNION ALL
      SELECT ${USAGE_ROW_COLUMNS.join(", ")} FROM live
  )`;
}

/** The options {@link usageHourlySql} takes: the window's, less `wholeDays`, which is a day idea. */
export type UsageHourlyOptions = Omit<UsageWindowOptions, "wholeDays">;

/**
 * The same `usage_rows` CTE, with the rolled half read from the gateway's <b>hourly</b> summary
 * (`usage_hourly`, V1.91.0) instead of the daily one.
 *
 * <h2>The seam is an instant, not an anti-join</h2>
 *
 * <p>The gateway's tick brings `usage_hourly` up to `usage_rollup_cursor.hourly_hwm` and commits the
 * counts and the cursor together, so the summary holds exactly the messages submitted before that
 * instant and nothing after it. Given `[since, until)` and the watermark `hwm`:
 *
 * <ul>
 *   <li><b>Rolled:</b> every `usage_hourly` row with `first_hour <= hour < seam`, where `first_hour`
 *       is the first whole UTC hour at or after `since` and `seam` is `hwm` clamped into the window.
 *       That includes the partial row for the hour `hwm` falls in, which holds `[hour, hwm)`.</li>
 *   <li><b>Live head:</b> `cdr_submit` from `since` up to the earlier of `first_hour` and `seam`.
 *       Empty when `since` is on the hour; otherwise the sliver before the first whole hour, so a
 *       billing day that starts at :30 is never served by a UTC hour that straddles it.</li>
 *   <li><b>Live tail:</b> `cdr_submit` from `seam` to `until`. With the rollup ticking every minute
 *       that is a minute or two of records.</li>
 * </ul>
 *
 * <p>All three are half-open on the same instants, so a message is counted from one of them. The
 * one exception is the gateway's own: a message retried across the seam has an attempt on each
 * side and may count twice until the gateway's quarter-hour restatement recomputes the hour whole.
 * No watermark (no cursor row yet, or the rollup switched off) puts the seam at `since` and reads
 * everything live. A watermark past `until` moves the seam back to the hour `until` falls in, so no
 * rolled row reaches beyond the window.
 *
 * <p>Meant for a window within one billing day (the hourly series, or today's tail of a day range).
 * Hours are UTC and billing days are not, so a window of several days should take its whole days
 * from {@link usageWindowSql} and only today from here. On a rolled row `pending_price` reads 0 --
 * the summary counts what was pending at its tick and not its money -- and `refused` is the
 * gateway's count of vendor refusals by the hour they were refused in, additive and never restated.
 */
export function usageHourlySql(o: UsageHourlyOptions): string {
  const acct = accountBind(o);
  const mine = acct ? ` AND s.account_id = ${acct}` : "";
  const bucket =
    o.bucket === "hour"
      ? hourUtc("s.submitted_at")
      : "((s.submitted_at AT TIME ZONE $3)::date::timestamp AT TIME ZONE $3)";
  const rolledBucket =
    o.bucket === "hour" ? "h.hour" : "((h.hour AT TIME ZONE $3)::date::timestamp AT TIME ZONE $3)";

  const head = messageRows(
    `s.submitted_at >= cut.since
         AND s.submitted_at < LEAST(cut.until, cut.first_hour, cut.seam)${mine}`,
    o,
    LIVE_COLUMNS
  );
  const tail = messageRows(
    `s.submitted_at >= GREATEST(cut.seam, cut.since)
         AND s.submitted_at < cut.until${mine}`,
    o,
    LIVE_COLUMNS
  );

  return `
  WITH cut AS (
      SELECT w.since, w.until,
             --the first whole UTC hour at or after since
             CASE WHEN w.floor_since < w.since THEN w.floor_since + interval '1 hour' ELSE w.floor_since END AS first_hour,
             --the watermark clamped into the window; back to the hour until falls in when the
             --summary has moved past until, so no rolled row reaches beyond the window
             GREATEST(w.since, LEAST(w.hwm, CASE WHEN w.hwm >= w.until THEN ${hourUtc("w.until")} ELSE w.until END)) AS seam
        FROM (SELECT b.since, b.until,
                     ${hourUtc("b.since")} AS floor_since,
                     COALESCE((SELECT c.hourly_hwm FROM usage_rollup_cursor c), b.since) AS hwm
                FROM (SELECT $1::timestamptz AS since, $2::timestamptz AS until) b) w
  ),
  rolled AS (
      SELECT ${rolledBucket}                   AS bucket,
             (h.hour AT TIME ZONE $3)::date    AS day,
             NULLIF(h.account_id, '')          AS account_id,
             NULL::text                        AS system_id,
             NULLIF(h.product, '')             AS product,
             h.submitted, h.delivered, h.failed, h.expired,
             h.pending_at_rollup               AS pending,
             h.price_total                     AS price,
             h.cost_total                      AS cost,
             0::bigint                         AS pending_price,
             h.refused                         AS refused,
             h.hour                            AS last_seen
        FROM cut, usage_hourly h
       WHERE h.hour >= cut.first_hour AND h.hour < cut.seam${acct ? ` AND h.account_id = ${acct}` : ""}
  ),
  live AS (
      ${liveSelect(bucket, o)}
        --one row per message, as UsageRollup, over the two live slivers only
        FROM cut, LATERAL (
             SELECT * FROM ${head}
             UNION ALL
             SELECT * FROM ${tail}
        ) s${OUTCOME_LATERAL}
       GROUP BY 1, 2, 3, 4, 5
  ),
  ${usageRowsUnion()}`;
}

/**
 * Where the failure breakdown's live read starts: the later of `since` and the earlier of today's
 * midnight (billing zone) and 24 hours before `until`.
 *
 * <p>`usage_daily` has no failure reason, so this view is the records or nothing. Over a week or a
 * month that is the scan this module exists to stop, so the window is cut to the tail -- today, and
 * never less than the 24-hour range shows, or picking a longer range would show fewer failures.
 * Callers report the instant beside the rows, so the page can say what period the breakdown is of.
 *
 * <p>`$1` since, `$2` until, `$3` zone -- the same binds as {@link usageWindowSql}.
 */
export const FAILURE_WINDOW_SINCE =
  "GREATEST($1::timestamptz, LEAST(((now() AT TIME ZONE $3)::date::timestamp AT TIME ZONE $3), $2::timestamptz - interval '24 hours'))";
