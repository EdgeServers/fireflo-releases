import { strict as assert } from "node:assert";
import { test } from "node:test";
import { portalBrand, portalCopyright, portalMark } from "./brand.ts";

function withEnv(vars: Record<string, string | undefined>, run: () => void) {
  const before = { ...process.env };
  for (const [k, v] of Object.entries(vars)) {
    if (v === undefined) delete process.env[k]; else process.env[k] = v;
  }
  try { run(); } finally { process.env = before; }
}

test("unbranded: FireFlo's name, copyright and mark", () => {
  withEnv({ MIS_PANEL_BRAND: undefined, MIS_PANEL_LOGO_URL: undefined }, () => {
    assert.equal(portalBrand(), "FireFlo");
    assert.match(portalCopyright(), /FireFlo by RemotIQ/);
    assert.deepEqual(portalMark(), { src: "/fireflo-mark.svg" });
  });
});

test("branded with no logo: the brand's initial, never the flame", () => {
  withEnv({ MIS_PANEL_BRAND: " acme messaging ", MIS_PANEL_LOGO_URL: undefined }, () => {
    assert.equal(portalBrand(), "acme messaging");
    assert.deepEqual(portalMark(), { letter: "A" });
    assert.doesNotMatch(portalCopyright(), /FireFlo/);
  });
});

test("branded with a logo: that image", () => {
  withEnv({ MIS_PANEL_BRAND: "Acme", MIS_PANEL_LOGO_URL: " https://acme.example/logo.svg " }, () => {
    assert.deepEqual(portalMark(), { src: "https://acme.example/logo.svg" });
  });
});

test("a logo without a brand changes nothing: FireFlo's portal keeps FireFlo's mark", () => {
  withEnv({ MIS_PANEL_BRAND: undefined, MIS_PANEL_LOGO_URL: "https://acme.example/logo.svg" }, () => {
    assert.deepEqual(portalMark(), { src: "/fireflo-mark.svg" });
  });
});
