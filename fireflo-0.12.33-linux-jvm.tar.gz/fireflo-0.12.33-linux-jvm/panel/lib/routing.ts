import type { PoolClient } from "pg";
import { ConfigRefusal } from "@/lib/config-guard";
import { configQuery, inTransaction } from "@/lib/config-db";
import { auditConfigChange } from "@/lib/config-audit";
import type { ConfigSummary } from "@/lib/config-change";
import type { ConditionInput } from "@/lib/rate-types";
import {
  DEFAULT_TABLE_NAME,
  type RouteRule,
  type RouteTable,
  type RouteTableInput,
  type TargetFunction,
} from "@/lib/routing-types";
import {
  lockedReceiptListener,
  lockedRuleProblem,
  reconcileReceiptRules,
  type Listener,
} from "@/lib/system-routes";

/**
 * Routing tables and their ordered rules.
 *
 * <p>Server-only: importing this pulls `pg`. The shapes and every statement about behaviour live in
 * `routing-types.ts`.
 *
 * <p>These tables have been readable by `DbRoutingLoader` since V1.4.0 and populated by
 * `fireflo import routing`, but nothing could edit them — which is why the gateway in this
 * deployment still reads `conf/routingTable.conf`. Editing them is what makes flipping
 * `FIREFLO_CONFIG_SOURCE=db` a reasonable thing to do rather than a one-way door.
 */

interface TableRow {
  name: string;
  target_function: string;
  label: string | null;
  enabled: boolean;
}

interface RuleRow {
  id: string;
  table_name: string;
  target: string;
  copied: boolean;
  label: string | null;
  enabled: boolean;
}

/**
 * Every table with its rules in order.
 *
 * <p>Four queries rather than one join, for the reason `listScope` gives: joining the rules to both
 * their conditions and their filters at once multiplies each rule by the product of the two.
 */
export async function listRouteTables(): Promise<RouteTable[]> {
  const [tables, rules] = await Promise.all([
    configQuery<TableRow>(
      "SELECT name, target_function, label, enabled FROM app_route_table ORDER BY name"
    ),
    configQuery<RuleRow>(
      `SELECT id::text, table_name, target, copied, label, enabled
         FROM app_route_rule ORDER BY table_name, seq`
    ),
  ]);

  const ids = rules.map((r) => r.id);
  const [conditions, filters] = ids.length
    ? await Promise.all([
        configQuery<{ rule_id: string; field: string; operator: string; value: string; negate: boolean }>(
          `SELECT rule_id::text, field, operator, value, negate
             FROM app_route_rule_condition WHERE rule_id = ANY($1::bigint[]) ORDER BY rule_id, seq`,
          [ids]
        ),
        configQuery<{ rule_id: string; filter_name: string }>(
          `SELECT rule_id::text, filter_name
             FROM app_route_rule_filter WHERE rule_id = ANY($1::bigint[]) ORDER BY rule_id, seq`,
          [ids]
        ),
      ])
    : [[], []];

  const conditionsByRule = new Map<string, ConditionInput[]>();
  for (const c of conditions) {
    const list = conditionsByRule.get(c.rule_id) ?? [];
    list.push({ field: c.field, operator: c.operator, value: c.value, negate: c.negate });
    conditionsByRule.set(c.rule_id, list);
  }
  const filtersByRule = new Map<string, string[]>();
  for (const f of filters) {
    const list = filtersByRule.get(f.rule_id) ?? [];
    list.push(f.filter_name);
    filtersByRule.set(f.rule_id, list);
  }

  const rulesByTable = new Map<string, RouteRule[]>();
  for (const r of rules) {
    const list = rulesByTable.get(r.table_name) ?? [];
    list.push({
      id: Number(r.id),
      target: r.target,
      copied: r.copied,
      label: r.label,
      enabled: r.enabled,
      conditions: conditionsByRule.get(r.id) ?? [],
      filters: filtersByRule.get(r.id) ?? [],
    });
    rulesByTable.set(r.table_name, list);
  }

  return tables.map((t) => ({
    name: t.name,
    //the column is CHECK-constrained to these two, but a cast is still a claim about data. A row
    //written before V1.28.0 dropped RC lands on NORMAL here, which is what RC always did anyway
    targetFunction: (["NORMAL", "LCR"].includes(t.target_function)
      ? t.target_function
      : "NORMAL") as TargetFunction,
    label: t.label,
    enabled: t.enabled,
    rules: rulesByTable.get(t.name) ?? [],
  }));
}

/**
 * Creates or rewrites one table and every rule in it.
 *
 * <h3>The position constraint is deferred for the transaction</h3>
 *
 * <p>`uq_app_route_rule_seq UNIQUE (table_name, seq)` is deferrable since gateway migration V1.75.0,
 * so `SET CONSTRAINTS ... DEFERRED` moves its check to commit and each rule's seq can be written
 * straight to its new position, swaps included. Before V1.75.0 the constraint was checked per row
 * and this code parked every survivor at a negative seq first; `saveScope` did the same, and the
 * two are still worth keeping in step.
 *
 * <p>Rules that survive are UPDATEd rather than deleted and recreated, so their ids are stable and
 * nothing cascades. Conditions and filters are delete-and-reinsert per rule, which is safe: both are
 * keyed on `(rule_id, seq)`, nothing references either, and the parent id does not move.
 */
export async function saveRouteTable(input: RouteTableInput): Promise<string[]> {
  const name = input.name.trim();
  let before: ConfigSummary | null = null;
  let written: RouteRule[] = input.rules;
  const changes = await inTransaction(async (client) => {
    //read before the write, on the same connection, so the audit line's "before" is the state this
    //save replaced and not whatever another operator committed in between
    const stored = await readRulesIn(client, name);
    const table = await client.query<TableRow>(
      "SELECT name, target_function, label, enabled FROM app_route_table WHERE name = $1",
      [name]
    );
    before = table.rows.length ? tableSummary(table.rows[0], stored) : null;

    if (name !== DEFAULT_TABLE_NAME) {
      await writeRouteTable(client, input);
      return [];
    }
    //the receipt rules are the panel's, not the operator's: a save may move them but not remove or
    //change them, and whatever is missing is put back in the same write
    //one connection runs one query at a time, so these are sequential rather than Promise.all
    const listeners = await listenersIn(client);
    const problem = lockedRuleProblem(stored, input.rules, listeners);
    if (problem) {
      throw new ConfigRefusal(problem);
    }
    const { rules, changes } = reconcileReceiptRules(input.rules, listeners);
    written = rules;
    await writeRouteTable(client, { ...input, rules });
    return changes;
  });
  await auditConfigChange({
    domain: "routing_table",
    name,
    action: before ? "update" : "create",
    before,
    after: tableSummary(
      { name, target_function: input.targetFunction, label: input.label?.trim() || null, enabled: input.enabled },
      written
    ),
  });
  return changes;
}

/**
 * A routing table as the audit line shows it: its header and its rules in order, each as the
 * target with a `-` for disabled and a `+` for copied -- the file notation, which is what an
 * operator reading "diverted to where?" will recognise. Conditions are counted, not listed; the
 * line has a size cap and the targets are what matter.
 */
function tableSummary(table: TableRow, rules: readonly RouteRule[]): ConfigSummary {
  return {
    targetFunction: table.target_function,
    label: table.label,
    enabled: table.enabled,
    rules: rules.map((r) => `${r.enabled ? "" : "-"}${r.copied ? "+" : ""}${r.target}`
      + (r.conditions.length || r.filters.length ? `[${r.conditions.length + r.filters.length}]` : "")),
  };
}

/**
 * Every SMPP listener, enabled or not, as the receipt rules need them.
 */
async function listenersIn(client: PoolClient): Promise<Listener[]> {
  const rows = await client.query<{ name: string; enabled: boolean }>(
    "SELECT name, enabled FROM app_worker WHERE type = 'smppserver' ORDER BY name"
  );
  return rows.rows.map((r) => ({ name: r.name, type: "smppserver", enabled: r.enabled }));
}

/**
 * One table's rules in order, read on the transaction's own connection so a check and the write it
 * guards see the same rows. Empty when the table does not exist.
 */
async function readRulesIn(client: PoolClient, table: string): Promise<RouteRule[]> {
  const rules = await client.query<RuleRow>(
    `SELECT id::text, table_name, target, copied, label, enabled
       FROM app_route_rule WHERE table_name = $1 ORDER BY seq FOR UPDATE`,
    [table]
  );
  const ids = rules.rows.map((r) => r.id);
  if (!ids.length) {
    return [];
  }
  const conditions = await client.query<{ rule_id: string; field: string; operator: string; value: string; negate: boolean }>(
    `SELECT rule_id::text, field, operator, value, negate
       FROM app_route_rule_condition WHERE rule_id = ANY($1::bigint[]) ORDER BY rule_id, seq`,
    [ids]
  );
  const filters = await client.query<{ rule_id: string; filter_name: string }>(
    `SELECT rule_id::text, filter_name
       FROM app_route_rule_filter WHERE rule_id = ANY($1::bigint[]) ORDER BY rule_id, seq`,
    [ids]
  );
  return rules.rows.map((r) => ({
    id: Number(r.id),
    target: r.target,
    copied: r.copied,
    label: r.label,
    enabled: r.enabled,
    conditions: conditions.rows.filter((c) => c.rule_id === r.id)
      .map((c) => ({ field: c.field, operator: c.operator, value: c.value, negate: c.negate })),
    filters: filters.rows.filter((f) => f.rule_id === r.id).map((f) => f.filter_name),
  }));
}

/**
 * Puts the receipt rules in `default` right, inside a caller's transaction.
 *
 * <p>For a listener being created or saved: it gets its rule in the same commit as itself, and an
 * older listener saved again gets the one it never had. Nothing happens when there is no `default`
 * table -- a gateway with none routes nothing until it is rebuilt, which is a different problem
 * with its own button.
 *
 * @returns what changed, one sentence each; empty when nothing did
 */
export async function reconcileReceiptRulesIn(client: PoolClient): Promise<string[]> {
  const table = await client.query<TableRow>(
    "SELECT name, target_function, label, enabled FROM app_route_table WHERE name = $1",
    [DEFAULT_TABLE_NAME]
  );
  if (!table.rows.length) {
    return [];
  }
  const stored = await readRulesIn(client, DEFAULT_TABLE_NAME);
  const listeners = await listenersIn(client);
  const { rules, changes } = reconcileReceiptRules(stored, listeners);
  if (changes.length) {
    const t = table.rows[0];
    await writeRouteTable(client, {
      name: t.name,
      targetFunction: t.target_function === "LCR" ? "LCR" : "NORMAL",
      label: t.label,
      enabled: t.enabled,
      rules,
    });
  }
  return changes;
}

/**
 * Removes a listener's receipt rule, inside the transaction that deletes the listener.
 *
 * <p>The rule would otherwise block the delete: a rule's target is a foreign key to the worker.
 * Only the locked rule goes; any other rule naming the listener still refuses the delete, with the
 * sentence that says where it is.
 */
export async function dropReceiptRuleIn(client: PoolClient, listener: string): Promise<void> {
  const stored = await readRulesIn(client, DEFAULT_TABLE_NAME);
  const listeners = await listenersIn(client);
  const ids = stored
    .filter((r) => lockedReceiptListener(r, listeners)?.name === listener)
    .map((r) => r.id);
  if (ids.length) {
    await client.query("DELETE FROM app_route_rule WHERE table_name = $1 AND id = ANY($2::bigint[])",
      [DEFAULT_TABLE_NAME, ids]);
  }
}

/** The whole-table rewrite itself, on a caller's transaction. */
async function writeRouteTable(client: PoolClient, input: RouteTableInput): Promise<void> {
  const name = input.name.trim();
  await client.query(
    `INSERT INTO app_route_table (name, target_function, label, enabled, updated_at)
     VALUES ($1, $2, $3, $4, now())
     ON CONFLICT (name) DO UPDATE
       SET target_function = EXCLUDED.target_function, label = EXCLUDED.label,
           enabled = EXCLUDED.enabled, updated_at = now()`,
    [name, input.targetFunction, input.label?.trim() || null, input.enabled]
  );

  //checked at commit rather than per row, so positions can be rewritten in any order
  await client.query("SET CONSTRAINTS uq_app_route_rule_seq DEFERRED");
  const existing = await client.query<{ id: string; seq: number }>(
    "SELECT id::text, seq FROM app_route_rule WHERE table_name = $1 ORDER BY seq FOR UPDATE",
    [name]
  );

  const live = new Set(existing.rows.map((r) => r.id));
  const keep = input.rules.map((r) => r.id).filter((id): id is number => id != null).map(String);
  for (const id of keep) {
    if (!live.has(id)) {
      throw new Error(
        `Rule ${id} is not part of '${name}' any more. Reload the page — someone else has changed `
        + "this table since it was opened."
      );
    }
  }

  await client.query(
    "DELETE FROM app_route_rule WHERE table_name = $1 AND NOT (id = ANY($2::bigint[]))",
    [name, keep]
  );

  for (let i = 0; i < input.rules.length; i++) {
    const rule = input.rules[i];
    const values = [
      i, rule.target.trim(), rule.copied, rule.label?.trim() || null, rule.enabled,
    ];

    let id: string;
    if (rule.id != null) {
      const updated = await client.query<{ id: string }>(
        `UPDATE app_route_rule
            SET seq = $3, target = $4, copied = $5, label = $6, enabled = $7, updated_at = now()
          WHERE id = $2 AND table_name = $1
          RETURNING id::text`,
        [name, rule.id, ...values]
      );
      id = updated.rows[0].id;
      await client.query("DELETE FROM app_route_rule_condition WHERE rule_id = $1", [id]);
      await client.query("DELETE FROM app_route_rule_filter WHERE rule_id = $1", [id]);
    } else {
      const created = await client.query<{ id: string }>(
        `INSERT INTO app_route_rule (table_name, seq, target, copied, label, enabled, updated_at)
         VALUES ($1, $2, $3, $4, $5, $6, now())
         RETURNING id::text`,
        [name, ...values]
      );
      id = created.rows[0].id;
    }

    for (let c = 0; c < rule.conditions.length; c++) {
      const condition = rule.conditions[c];
      await client.query(
        `INSERT INTO app_route_rule_condition (rule_id, seq, field, operator, value, negate)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [id, c, condition.field, condition.operator, condition.value ?? "", condition.negate]
      );
    }

    //deduplicated for the same reason as a rate rule's: the same filter twice would apply its
    //conditions twice and inflate every usage count the filter library shows
    const names = [...new Set(rule.filters.map((f) => f.trim()).filter(Boolean))];
    for (let f = 0; f < names.length; f++) {
      await client.query(
        "INSERT INTO app_route_rule_filter (rule_id, filter_name, seq) VALUES ($1, $2, $3)",
        [id, names[f], f]
      );
    }
  }
}

/**
 * Turns one rule on or off, without touching the order or anything else about it.
 *
 * <p>Separate from the whole-table PUT for the reason `setRuleEnabled` in `lib/rates.ts` is separate
 * from `saveScope`: retiring a rule is the thing an operator does in a hurry during an incident, and
 * it should not require re-sending every other rule in the table to do it. `saveRouteTable`'s
 * deferred constraint and its "someone else changed this table" guard both exist because a
 * whole-table write can race a concurrent edit; a single-column update on one row cannot.
 */
export async function setRouteRuleEnabled(
  tableName: string,
  id: number,
  enabled: boolean
): Promise<boolean> {
  return inTransaction(async (client) => {
    if (!enabled && tableName === DEFAULT_TABLE_NAME) {
      const stored = await readRulesIn(client, tableName);
      const listeners = await listenersIn(client);
      const rule = stored.find((r) => r.id === id);
      const listener = rule ? lockedReceiptListener(rule, listeners) : null;
      if (listener) {
        throw new ConfigRefusal(`The receipt rule for smppserver.${listener.name} is a system rule and can't be `
          + "switched off: its customers would get no delivery receipts.");
      }
    }
    const rows = await client.query<{ id: string; target: string }>(
      `UPDATE app_route_rule SET enabled = $3, updated_at = now()
        WHERE id = $2 AND table_name = $1 RETURNING id::text, target`,
      [tableName, id, enabled]
    );
    return rows.rows[0] ?? null;
  }).then(async (rule) => {
    if (!rule) {
      return false;
    }
    await auditConfigChange({
      domain: "routing_table",
      name: tableName,
      action: enabled ? "enable" : "disable",
      after: { ruleId: id, target: rule.target, enabled },
    });
    return true;
  });
}

/**
 * Removes a table and its rules, if no other table jumps to it.
 *
 * <p>Its own rules cascade. A rule in *another* table that chains into this one used to be left
 * pointing at nothing; since gateway migration V1.58.0 a rule's target is resolved into a foreign
 * key (`target_table`), so that delete would fail at commit. Asking first names the tables to fix.
 *
 * @throws ConfigRefusal naming the tables that still jump here
 */
export async function deleteRouteTable(name: string): Promise<boolean> {
  const into = await configQuery<{ table_name: string }>(
    "SELECT DISTINCT table_name FROM app_route_rule WHERE target = $1 AND table_name <> $1 ORDER BY table_name",
    [name]
  );
  if (into.length) {
    throw new ConfigRefusal(
      `'${name}' is still the target of rules in ${into.map((r) => `'${r.table_name}'`).join(", ")}. `
        + "Point those rules somewhere else first."
    );
  }
  const rows = await configQuery<{ name: string; label: string | null; enabled: boolean; rules: number }>(
    `DELETE FROM app_route_table WHERE name = $1
      RETURNING name, label, enabled,
                (SELECT count(*)::int FROM app_route_rule WHERE table_name = $1) AS rules`,
    [name]
  );
  if (!rows.length) {
    return false;
  }
  await auditConfigChange({
    domain: "routing_table",
    name,
    action: "delete",
    before: { label: rows[0].label, enabled: rows[0].enabled, rules: Number(rows[0].rules) },
  });
  return true;
}
