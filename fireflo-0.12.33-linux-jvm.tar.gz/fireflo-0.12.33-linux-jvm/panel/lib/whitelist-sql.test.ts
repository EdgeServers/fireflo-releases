import { strict as assert } from "node:assert";
import { test } from "node:test";
//with the extension, because `node --test` runs this directly and reads neither tsconfig paths nor
//extensionless specifiers
import {
  APPROVAL_INSERT,
  APPROVAL_INSERT_TEMPLATE,
  APPROVAL_SET,
  APPROVAL_SET_TEMPLATE,
} from "./whitelist-sql.ts";

/**
 * The bug these pin: `APPROVAL_SET` carried a bare `ELSE status`, and it is interpolated into an
 * `INSERT ... ON CONFLICT DO UPDATE` where `app_header` and `excluded` are both in scope. PostgreSQL
 * refused the statement at parse time with `column reference "status" is ambiguous`, so every
 * operator attempt to add a sender ID failed — not just the conflicting ones.
 *
 * <p>These are string assertions rather than a database round trip, and that is a real limitation:
 * they cannot catch a column that does not exist or a type that will not cast. What they can catch
 * is this specific shape, which shipped because the panel has no database-backed test at all. The
 * live `PREPARE` in the verification notes is what covers the rest.
 */

const SET_FRAGMENTS = [
  { name: "APPROVAL_SET", sql: APPROVAL_SET, table: "app_header" },
  { name: "APPROVAL_SET_TEMPLATE", sql: APPROVAL_SET_TEMPLATE, table: "app_template" },
];

test("every ELSE column is qualified, so ON CONFLICT cannot read it as ambiguous", () => {
  for (const { name, sql, table } of SET_FRAGMENTS) {
    const elses = [...sql.matchAll(/\bELSE\s+(\S+?)\s+END/g)].map((m) => m[1]);
    //anti-vacuity: if the regex stopped finding anything, the loop below would pass on nothing
    assert.equal(elses.length, 3, `${name}: expected three ELSE branches, found ${elses.length}`);
    for (const column of elses) {
      assert.ok(
        column.startsWith(`${table}.`),
        `${name}: 'ELSE ${column}' is ambiguous under ON CONFLICT — write '${table}.${column}'`
      );
    }
  }
});

test("the assigned column stays bare, because PostgreSQL refuses a qualified SET target", () => {
  //the other half of the trap. Somebody reading the fix as "qualify everything" would write
  //`SET app_header.status = ...`, which is its own parse error -- one error traded for another
  for (const { name, sql, table } of SET_FRAGMENTS) {
    const targets = [...sql.matchAll(/(?:^|,\s*)(\S+?)\s*=/g)].map((m) => m[1]);
    assert.deepEqual(targets, ["status", "reviewed_by", "reviewed_at"], `${name}: assigned columns`);
    assert.ok(!sql.includes(`${table}.status =`), `${name}: SET target must not be qualified`);
  }
});

test("approval only ever moves forwards", () => {
  //unticking withdraws (enabled) without un-approving (status), so no ELSE may write a literal --
  //every one of them has to carry the existing value through untouched
  for (const { name, sql } of SET_FRAGMENTS) {
    assert.ok(!/\bELSE\s+'/.test(sql), `${name}: an ELSE writing a literal would rewrite status`);
  }
  assert.ok(APPROVAL_SET.includes("'APPROVED'"), "the THEN branch still approves");
});

test("a row inserted without the tick starts PENDING, with no reviewer recorded", () => {
  for (const [name, sql] of [
    ["APPROVAL_INSERT", APPROVAL_INSERT],
    ["APPROVAL_INSERT_TEMPLATE", APPROVAL_INSERT_TEMPLATE],
  ] as const) {
    assert.ok(sql.includes("ELSE 'PENDING'"), `${name}: an unticked insert must be PENDING`);
    //no ELSE on the reviewer and timestamp: they stay NULL rather than recording a review that
    //nobody performed
    assert.equal((sql.match(/\bELSE\b/g) ?? []).length, 1, `${name}: only the status has an ELSE`);
  }
});

test("the header and template fragments use their own parameter numbers", () => {
  //they differ only by this, which is the entire reason there are four constants and not two. A
  //copy-paste between them binds the operator name to the approved flag and silently misfiles who
  //approved what
  assert.ok(APPROVAL_SET.includes("$6") && !APPROVAL_SET.includes("$8"), "header uses $6/$7");
  assert.ok(
    APPROVAL_SET_TEMPLATE.includes("$8") && !APPROVAL_SET_TEMPLATE.includes("$6"),
    "template uses $7/$8"
  );
});
