import { strict as assert } from "node:assert";
import { test } from "node:test";

import { vendorPerformanceHourlySql } from "./vendor-performance-sql.ts";

const sql = vendorPerformanceHourlySql(true);

test("whole hours come from the summary, only the edges from the records", () => {
  //the timeout this exists for was a read of every record in the range. The records may be read
  //only in the opening part-hour and past the watermark
  assert.match(sql, /c\.submitted_at >= cut\.since AND c\.submitted_at < LEAST\(cut\.first_hour, cut\.seam\)/);
  assert.match(sql, /c\.submitted_at >= cut\.seam AND c\.submitted_at < cut\.until/);
  assert.match(sql, /FROM usage_hourly h, cut\s+WHERE h\.hour >= cut\.first_hour AND h\.hour < cut\.seam/);
});

test("the watermark is clamped into the range, so a stale or future one cannot double count", () => {
  assert.match(sql, /LEAST\(GREATEST\(\$3::timestamptz, \$1::timestamptz\), \$2::timestamptz\) AS seam/);
});

test("attempts are by the vendor each attempt went to; outcomes by the vendor that carried the message", () => {
  assert.match(sql, /SUM\(h\.attempts\) AS attempts/);
  assert.match(sql, /SUM\(h\.submitted\) AS messages/);
  assert.match(sql, /SELECT DISTINCT ON \(gateway_msg_id\)/, "the edges pick the representative attempt");
  assert.match(sql, /SUM\(h\.failed \+ h\.expired\) AS failed/, "expired counts as failed, as the records read it");
});

test("the summary's refusal-only rows under vendor '' add no empty vendor", () => {
  assert.match(sql, /NULLIF\(vendor, ''\) AS vendor/);
  assert.match(sql, /HAVING SUM\(attempts\) > 0 OR SUM\(messages\) > 0/);
});

test("hours before the summary's first row are read from the records, not counted as empty", () => {
  //an install that enabled the hourly rollup late: summary hours start after the range does
  assert.match(sql, /GREATEST\(\(date_trunc\('hour'[\s\S]*\(SELECT min\(hour\) FROM usage_hourly\)\) AS first_hour/);
});
