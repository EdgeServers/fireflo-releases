/**
 * What one gateway setting row says about itself, worked out once and away from the markup.
 *
 * <p>Client-safe and pure, so the decisions the page makes -- "is this the default", "has the
 * gateway picked it up", "does the host's environment outrank it" -- can be tested as a table
 * rather than by clicking.
 */

/** A row as stored in `app_config`. Absent when nothing is stored. */
export interface StoredValue {
  value: string | null;
  enabled: boolean;
}

/** The running gateway's answer for one key, from the In force report. */
export interface RunningValue {
  value: string | null;
  /** memory (database or file), store (environment), overridden_default, coded_default */
  tier: string;
}

export type RowState =
  /**
   * Nothing stored and nothing staged: a default applies.
   *
   * <p>`host` is set when the running value comes from the host rather than the code -- an
   * environment variable, or the packaged application.properties, which ships a line for several
   * keys (`smsg.cdr.body=${FIREFLO_CDR_BODY:off}`). It is informational: a value stored here still
   * wins, because the gateway reads its memory tier (the database) before its store tier.
   */
  | { kind: "default"; host?: string }
  /** Stored, enabled, and (as far as anyone can tell) running. */
  | { kind: "set" }
  /** An edit staged in this browser. `was` is what it replaces, for the chip. */
  | { kind: "unsaved"; was: string }
  /** Saved, but the running gateway still holds another value. */
  | { kind: "pending"; running: string; startup: boolean }
  /** A stored row with `enabled = false`: present, and ignored by the gateway. */
  | { kind: "disabled" };

export interface RowInput {
  stored: StoredValue | undefined;
  /** The staged edit, or undefined. An empty string is a staged clear. */
  draft: string | undefined;
  /** What the gateway uses when the key is absent. Null when nobody has verified it. */
  codedDefault: string | null;
  /** The running value, or undefined when the gateway could not be asked. */
  running: RunningValue | undefined;
  /** Read only at startup, so a saved change waits for a restart. */
  startup?: boolean;
}

const norm = (v: string | null | undefined) => (v ?? "").trim();

/**
 * The value the row's control shows: the staged edit, else what is stored, else the default.
 *
 * <p>A switch or a segmented control has to show *something* selected, and the default is what the
 * gateway is actually doing when nothing is stored. A text box shows the stored value only and puts
 * the default in its placeholder, which is why this is separate from {@link storedText}.
 */
export function effectiveValue(input: Pick<RowInput, "stored" | "draft" | "codedDefault">): string {
  if (input.draft !== undefined) {
    return input.draft === "" ? norm(input.codedDefault) : input.draft;
  }
  if (input.stored && input.stored.enabled && norm(input.stored.value) !== "") {
    return input.stored.value!;
  }
  return norm(input.codedDefault);
}

/** What a text control holds: the staged edit, else the stored value, never the default. */
export function storedText(input: Pick<RowInput, "stored" | "draft">): string {
  return input.draft ?? input.stored?.value ?? "";
}

export function rowState(input: RowInput): RowState {
  const { stored, draft, running } = input;

  if (draft !== undefined) {
    const was = stored && norm(stored.value) !== "" ? norm(stored.value) : norm(input.codedDefault);
    return { kind: "unsaved", was: was === "" ? "empty" : was };
  }

  //a running value at the store tier -- an env var, or the packaged application.properties -- is
  //NOT a lock. FireFloConfigurationHandler.get reads memory (the database) before the store, so a
  //value saved here overrides it on the next poll. This used to return a locked "host" state, which
  //made every key application.properties ships a line for impossible to set from the panel

  if (stored && !stored.enabled) {
    return { kind: "disabled" };
  }

  const isStored = !!stored && norm(stored.value) !== "";
  if (running) {
    //what the gateway should be running once it has caught up with the database
    const expected = isStored ? norm(stored!.value) : norm(input.codedDefault);
    const actual = norm(running.value);
    //a null default was never verified, so an unset key has nothing to compare against
    const comparable = isStored || input.codedDefault !== null;
    if (comparable && actual !== expected) {
      return { kind: "pending", running: actual === "" ? "empty" : actual, startup: !!input.startup };
    }
  }

  if (isStored) {
    return { kind: "set" };
  }
  //say where the default comes from when it is the host's rather than the code's
  if (running && running.tier === "store" && norm(running.value) !== "") {
    return { kind: "default", host: norm(running.value) };
  }
  return { kind: "default" };
}

/** True for the states the "Changed" filter and the section counts include. */
export function isChanged(state: RowState): boolean {
  return state.kind !== "default";
}

/**
 * The first sentence of a hint, and the rest.
 *
 * <p>The row shows one line and puts the rest behind "More". Split on the first full stop followed by
 * a space and a capital, so "e.g. this" and "0.5 seconds" do not end a sentence early.
 */
export function splitHint(hint: string | undefined): { lead: string; more: string } {
  const text = (hint ?? "").trim();
  const m = /^(.+?[.!?])\s+(?=[A-Z`"'(])/.exec(text);
  if (!m) {
    return { lead: text, more: "" };
  }
  return { lead: m[1], more: text.slice(m[0].length).trim() };
}

/** "Replace — the approved value always wins" becomes "Replace", for a segmented button. */
export function shortOptionLabel(label: string): string {
  return label.split(" — ")[0].trim();
}

/** The words for a value in a chip: "on" and "off" for booleans, the value otherwise. */
export function describeValue(value: string, kind: string): string {
  if (kind === "boolean") {
    return value === "true" ? "on" : value === "false" ? "off" : value;
  }
  return value === "" ? "empty" : value;
}

/** A list setting's items. Stored as one comma-joined string. */
export function listItems(value: string): string[] {
  return value.split(",").map((v) => v.trim()).filter(Boolean);
}

/** Whether a row matches the search box: label, key, or any of its hint. */
export function matchesQuery(q: string, field: { key: string; label: string; hint?: string }): boolean {
  const needle = q.trim().toLowerCase();
  if (!needle) {
    return true;
  }
  return [field.label, field.key, field.hint ?? ""].some((s) => s.toLowerCase().includes(needle));
}
