import { strict as assert } from "node:assert";
import { test } from "node:test";
import { scopeWarnings, type KnownScopes, type ScopeInput } from "./rate-types.ts";

/**
 * The warning for a rule priced for a product no login on the account carries.
 *
 * The failure it names is silent and looks like success: the rule is present, enabled, scoped to a
 * real account and priced, and every message is recorded with no price. Rating only ever offers a
 * message the rules whose product matches its own.
 */

const KNOWN: KnownScopes = {
  vendors: ["vendor1"],
  accounts: ["acct-1001", "acct-2002"],
  carriedProducts: { "acct-1001": ["sms"] },
};

function scope(scopeName: string, ...products: (string | null)[]): ScopeInput {
  return {
    scope: scopeName,
    rules: products.map((product, i) => ({
      id: i + 1,
      product,
      amount: "1.0000",
      currency: null,
      label: null,
      enabled: true,
      conditions: [],
      filters: [],
    })),
  } as ScopeInput;
}

function unreachable(warnings: string[]): string[] {
  return warnings.filter((w) => w.includes("carries the product"));
}

test("a rule for a product no login carries is called out", () => {
  const warnings = unreachable(scopeWarnings(scope("acct-1001", "premium"), KNOWN));
  assert.equal(warnings.length, 1);
  assert.match(warnings[0], /'premium'/);
  //says what IS carried, so the fix is visible without opening another page
  assert.match(warnings[0], /sms/);
  //and names the other way out, because system_type overrides the login per session
  assert.match(warnings[0], /system_type/);
});

test("a rule for the product the login does carry is silent", () => {
  assert.deepEqual(unreachable(scopeWarnings(scope("acct-1001", "sms"), KNOWN)), []);
});

test("a rule with no product is reachable and is not warned about", () => {
  //rating offers a product-carrying message the no-product rules too, so this one fires
  assert.deepEqual(unreachable(scopeWarnings(scope("acct-1001", null), KNOWN)), []);
});

test("an account whose logins were not read gets no opinion", () => {
  //acct-2002 is a known account with no entry in carriedProducts: not "carries nothing", but
  //"not looked at". Warning on that would fire on every account with a file-based credential
  assert.deepEqual(unreachable(scopeWarnings(scope("acct-2002", "premium"), KNOWN)), []);
});

test("an account whose logins carry no product is warned about every product-specific rule", () => {
  //the cloud report: product and rule created, no login given the product, every message blank
  const known: KnownScopes = { ...KNOWN, carriedProducts: { ...KNOWN.carriedProducts, "acct-2002": [] } };
  const warnings = unreachable(scopeWarnings(scope("acct-2002", "premium", null), known));
  assert.equal(warnings.length, 1);
  assert.match(warnings[0], /No login on 'acct-2002' carries the product 'premium'/);
  assert.match(warnings[0], /Its logins carry no product\./);
});

test("a vendor scope is never warned about", () => {
  //a vendor has no logins at all; its rules are what the carrier charges us
  const known: KnownScopes = { ...KNOWN, carriedProducts: { vendor1: [] } };
  assert.deepEqual(unreachable(scopeWarnings(scope("vendor1", "premium"), known)), []);
});

test("with no KnownScopes at all the check is skipped rather than throwing", () => {
  //scopeWarnings is called without it in places that have no scope catalogue loaded yet
  assert.deepEqual(unreachable(scopeWarnings(scope("acct-1001", "premium"))), []);
});

test("each missing product is named once, however many rules use it", () => {
  const warnings = unreachable(
    scopeWarnings(scope("acct-1001", "premium", "premium", "gold"), KNOWN)
  );
  assert.equal(warnings.length, 2);
});
