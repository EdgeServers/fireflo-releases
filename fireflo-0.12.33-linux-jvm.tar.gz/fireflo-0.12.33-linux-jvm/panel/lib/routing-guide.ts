import { describeCondition } from "./filter-guide.ts";
import type { ConditionInput } from "./rate-types.ts";
import {
  DEFAULT_TABLE_NAME,
  isRoutingCatchAll,
  targetKind,
  type RouteRule,
  type RouteTable,
  type RouteTableInput,
  type TargetWorker,
} from "./routing-types.ts";

/**
 * Routing rules in plain language, and the bookkeeping the two-column routing page needs: which
 * rules are the gateway's own, which can never be reached, what a staged edit changed.
 *
 * <p>Pure and client-safe, like `filter-guide.ts`. Nothing here changes what is stored; every
 * reading is of the same {@link RouteRule}s the API returns and accepts.
 */

// --- sentences -------------------------------------------------------------------------------

/** The content types `StandardMessage` declares, by the value a `type` condition carries. */
const MESSAGE_TYPES: Record<string, string> = {
  "0": "text",
  "10": "binary",
  "11": "Unicode",
  "14": "flash",
  "17": "push",
};

const IS = /^==[ilfscb]?$/;

/**
 * One condition as words, with the two fields routing leans on that a filter rarely does: `type`,
 * where 18 is a delivery receipt, and `ingateway`, which says how the message came in.
 */
export function describeRoutingCondition(c: ConditionInput): string {
  const field = c.field.trim();
  const value = c.value.trim();
  if (field === "type" && IS.test(c.operator.trim())) {
    if (value === "18") {
      return c.negate ? "it is not a delivery receipt" : "it is a delivery receipt";
    }
    if (MESSAGE_TYPES[value]) {
      return `it is ${c.negate ? "not " : ""}a ${MESSAGE_TYPES[value]} message`;
    }
  }
  if (field === "ingateway") {
    const op = c.operator.trim();
    if (op === "startsWith" && value === "smppclient.") {
      return c.negate ? "it did not come in from a vendor" : "it came in from a vendor";
    }
    if (op === "startsWith" && value === "smppserver.") {
      return c.negate ? "it was not sent through an SMPP listener" : "it was sent through an SMPP listener";
    }
    if (op === "equals" || IS.test(op)) {
      return `it ${c.negate ? "did not arrive" : "arrived"} through ${value}`;
    }
  }
  return describeCondition(c);
}

/** "Every message", or "When destination starts with +91 and it passes filter in_txn". */
export function describeRuleWhen(rule: Pick<RouteRule, "conditions" | "filters">): string {
  const parts = [
    ...rule.conditions.map(describeRoutingCondition),
    ...rule.filters.map((f) => `filter ${f} matches`),
  ];
  return parts.length ? `When ${parts.join(" and ")}` : "Every message";
}

// --- system rules ----------------------------------------------------------------------------

/**
 * A rule the panel's default routing wrote: delivery receipts back to their listener, inbound to a
 * listener, and the outbound content types into the business tables. They carry a `system:` label
 * so they can be folded away from the rules an operator writes.
 */
export function isSystemRule(rule: Pick<RouteRule, "label">): boolean {
  return (rule.label ?? "").startsWith("system:");
}

// --- order -----------------------------------------------------------------------------------

/**
 * The positions of the rules an In-order table can never reach: every enabled rule below the first
 * enabled catch-all that stops the scan. A copy-and-continue catch-all stops nothing.
 */
export function unreachableRules(table: Pick<RouteTableInput, "targetFunction" | "rules">): Set<number> {
  const out = new Set<number>();
  if (table.targetFunction !== "NORMAL") {
    return out;
  }
  const stop = table.rules.findIndex((r) => r.enabled && !r.copied && isRoutingCatchAll(r));
  if (stop < 0) {
    return out;
  }
  table.rules.forEach((r, i) => {
    if (i > stop && r.enabled) out.add(i);
  });
  return out;
}

/**
 * Moves the rule at `index` one place up (`by` = -1) or down (1), past the system rules: a business
 * rule swaps with the next business rule, a system rule with the next system rule, so moving one
 * kind never shuffles the other. Returns the same array when there is nowhere to go.
 */
export function moveRule<T extends Pick<RouteRule, "label">>(rules: readonly T[], index: number, by: -1 | 1): T[] {
  const system = isSystemRule(rules[index]);
  let to = index + by;
  while (to >= 0 && to < rules.length && isSystemRule(rules[to]) !== system) {
    to += by;
  }
  if (to < 0 || to >= rules.length) {
    return rules as T[];
  }
  const next = [...rules];
  [next[index], next[to]] = [next[to], next[index]];
  return next;
}

// --- staged edits ----------------------------------------------------------------------------

const ruleKey = (r: RouteRule) =>
  JSON.stringify([r.target.trim(), r.copied, r.label ?? null, r.enabled, r.conditions, r.filters]);

/**
 * Whether the rule now at `index` differs from what is stored: new, edited, or moved. Moved counts
 * because order is the priority in an In-order table, so a move is as real a change as an edit.
 */
export function ruleChanged(stored: readonly RouteRule[], rule: RouteRule, index: number): boolean {
  if (rule.id == null) {
    return true;
  }
  const at = stored.findIndex((s) => s.id === rule.id);
  return at !== index || ruleKey(stored[at]) !== ruleKey(rule);
}

/** How many separate things a staged table changes: settings, rules added, edited, moved, removed. */
export function tableChangeCount(stored: RouteTable, draft: RouteTableInput): number {
  let n = 0;
  if ((stored.label ?? "") !== (draft.label ?? "")) n++;
  if (stored.enabled !== draft.enabled) n++;
  if (stored.targetFunction !== draft.targetFunction) n++;
  draft.rules.forEach((r, i) => {
    if (ruleChanged(stored.rules, r, i)) n++;
  });
  const kept = new Set(draft.rules.map((r) => r.id).filter((id) => id != null));
  n += stored.rules.filter((r) => r.id != null && !kept.has(r.id)).length;
  return n;
}

// --- targets ---------------------------------------------------------------------------------

export interface TargetOption {
  value: string;
  label: string;
}

export interface TargetOptionGroup {
  label: string;
  options: TargetOption[];
}

/**
 * Everything a rule can send to, grouped the way an operator thinks of them. A listener is offered
 * under its `<type>.<name>`, the form a receipt rule must use. The table being edited is left out:
 * a table sending into itself loops.
 */
export function targetOptions(
  tables: readonly Pick<RouteTable, "name">[],
  groups: readonly { name: string }[],
  workers: readonly (TargetWorker & { enabled?: boolean })[],
  current?: string,
  preprocessors: readonly { name: string; enabled?: boolean }[] = []
): TargetOptionGroup[] {
  const off = (w: { enabled?: boolean }) => (w.enabled === false ? " (switched off)" : "");
  const out: TargetOptionGroup[] = [
    {
      label: "Vendors",
      options: workers.filter((w) => w.type === "smppclient")
        .map((w) => ({ value: w.name, label: `${w.name}${off(w)}` })),
    },
    { label: "Vendor groups", options: groups.map((g) => ({ value: g.name, label: g.name })) },
    {
      label: "Routing tables",
      options: tables.filter((t) => t.name !== current).map((t) => ({ value: t.name, label: t.name })),
    },
    {
      label: "Listeners (receipts and inbound)",
      options: workers.filter((w) => w.type !== "smppclient")
        .map((w) => ({ value: `${w.type}.${w.name}`, label: `${w.type}.${w.name}${off(w)}` })),
    },
    {
      //not a destination: the message goes to the program, comes back with its answer, and routing
      //carries on below this rule
      label: "Preprocessors (then carry on)",
      options: preprocessors.map((p) => ({ value: `@${p.name}`, label: `@${p.name}${off(p)}` })),
    },
  ];
  return out.filter((g) => g.options.length > 0);
}

/** What to call a target's kind on a chip. */
export function targetKindLabel(
  target: string,
  tableNames: readonly string[],
  workers: readonly TargetWorker[],
  groupNames: readonly string[]
): { kind: ReturnType<typeof targetKind>; label: string; listener: boolean } {
  const kind = targetKind(target, tableNames, workers, groupNames);
  const listener = kind === "worker" && workers.some((w) => w.type !== "smppclient"
    && (`${w.type}.${w.name}` === target.trim() || w.name === target.trim()));
  const label = kind === "table" ? "Table"
    : kind === "preprocessor" ? "Preprocessor"
    : kind === "group" ? "Vendor group"
    : kind === "disabled" ? "Switched off"
    : kind === "unknown" ? "Not recognised"
    : listener ? "Listener" : "Vendor";
  return { kind, label, listener };
}

// --- the chain -------------------------------------------------------------------------------

/** The tables a table's enabled rules send into, in rule order and without repeats. */
export function sendsInto(table: Pick<RouteTable, "name" | "rules">, tableNames: readonly string[]): string[] {
  return [...new Set(table.rules
    .filter((r) => r.enabled && tableNames.includes(r.target.trim()) && r.target.trim() !== table.name)
    .map((r) => r.target.trim()))];
}

/**
 * The tables a message can reach, starting from `default` and following rules that send into
 * another table, and the ones nothing reaches. An unreached table routes nothing however its rules
 * read.
 */
export function reachability(tables: readonly Pick<RouteTable, "name" | "rules" | "enabled">[]): {
  reached: string[];
  unreached: string[];
} {
  const names = tables.map((t) => t.name);
  const reached: string[] = [];
  const queue = names.includes(DEFAULT_TABLE_NAME) ? [DEFAULT_TABLE_NAME] : [];
  while (queue.length) {
    const name = queue.shift()!;
    if (reached.includes(name)) continue;
    reached.push(name);
    const table = tables.find((t) => t.name === name)!;
    if (!table.enabled) continue;
    queue.push(...sendsInto(table, names).filter((n) => !reached.includes(n)));
  }
  return { reached, unreached: names.filter((n) => !reached.includes(n)) };
}

/**
 * Why a table's rules never run, in a sentence, or null when a message can reach it. The entry
 * table is always reached. A table that only an unreached table sends into is named as such, so the
 * operator is pointed at the link that is actually missing rather than at this table.
 */
export function unreachedNote(
  name: string,
  tables: readonly Pick<RouteTable, "name" | "rules" | "enabled">[]
): string | null {
  const { unreached } = reachability(tables);
  if (!unreached.includes(name)) return null;
  const table = tables.find((t) => t.name === name);
  const live = table?.rules.filter((r) => r.enabled).length ?? 0;
  const its = live === 1 ? "its rule never runs" : live ? `its ${live} rules never run` : "anything added here never runs";
  const senders = tables
    .filter((t) => t.name !== name && t.rules.some((r) => r.enabled && r.target.trim() === name))
    .map((t) => t.name);
  if (!senders.length) {
    return `Nothing routes to this table, so ${its}. No rule in ${DEFAULT_TABLE_NAME}, or in a table it `
      + `leads to, sends here. Point a rule at ${name}, or move ${live === 1 ? "the rule" : "the rules"} `
      + `into a table that is reached.`;
  }
  return `Only ${senders.join(", ")} ${senders.length === 1 ? "sends" : "send"} here, and nothing reaches `
    + `${senders.length === 1 ? "it" : "them"} either, so ${its}.`;
}
