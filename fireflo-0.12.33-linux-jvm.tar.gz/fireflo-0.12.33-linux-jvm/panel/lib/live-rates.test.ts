import { strict as assert } from "node:assert";
import { test } from "node:test";
import { appendRates, EMPTY_RATES, RATE_HISTORY_MS, rateOf } from "./live-rates.ts";
import type { Health, HealthWorker } from "./health-types.ts";

function snapshot(workers: Partial<HealthWorker>[]): Health {
  return {
    observed_at: "t",
    router_queue: 0,
    awaiting_receipt: 0,
    dlr_store_persistent: false,
    cdr: { enabled: false },
    workers: workers.map((w) => ({
      name: "smppclient.v1", type: "smppclient", accepting: true, paused: false,
      suspended_manually: false, suspended_automatically: false, queue_depth: 0, retry_queue_depth: 0, ...w,
    })),
  } as Health;
}

test("two readings of the counter ten seconds apart are a per-second rate", () => {
  let h = appendRates(EMPTY_RATES, snapshot([{ submitted: 1000 }]), 0);
  h = appendRates(h, snapshot([{ submitted: 1250 }]), 10_000);
  assert.equal(h.samples.length, 2);
  assert.equal(h.samples[1].mt["smppclient.v1"], 25);
});

test("the first reading is a baseline, not a rate", () => {
  const h = appendRates(EMPTY_RATES, snapshot([{ submitted: 1000 }]), 0);
  assert.equal(h.samples[0].mt["smppclient.v1"], null);
  assert.deepEqual(h.last["smppclient.v1"], { at: 0, submitted: 1000 });
});

test("the gateway's own measured tps stands in where no delta can be taken", () => {
  //first poll, counters switched off, or a counter that just reset: tps_measured is still honest
  let h = appendRates(EMPTY_RATES, snapshot([{ submitted: 1000, tps_measured: 7 }]), 0);
  assert.equal(h.samples[0].mt["smppclient.v1"], 7);
  h = appendRates(h, snapshot([{ submitted: null, tps_measured: 3 }]), 10_000);
  assert.equal(h.samples[1].mt["smppclient.v1"], 3);
});

test("a counter that fell -- a rebind or a dropped customer -- is never a negative rate", () => {
  let h = appendRates(EMPTY_RATES, snapshot([{ submitted: 5000 }]), 0);
  h = appendRates(h, snapshot([{ submitted: 40 }]), 10_000);
  assert.equal(h.samples[1].mt["smppclient.v1"], null, "a gap, not -496/s");
  //and the new, lower reading becomes the baseline, so the next delta is right again
  h = appendRates(h, snapshot([{ submitted: 140 }]), 20_000);
  assert.equal(h.samples[2].mt["smppclient.v1"], 10);
});

test("the interval is measured, not assumed: a late poll does not inflate the rate", () => {
  let h = appendRates(EMPTY_RATES, snapshot([{ submitted: 0 }]), 0);
  h = appendRates(h, snapshot([{ submitted: 600 }]), 30_000);
  assert.equal(h.samples[1].mt["smppclient.v1"], 20);
});

test("the history is bounded to the chart's window", () => {
  let h = EMPTY_RATES;
  for (let i = 0; i <= 120; i++) {
    h = appendRates(h, snapshot([{ submitted: i * 100 }]), i * 10_000);
  }
  const now = 120 * 10_000;
  assert.ok(h.samples.every((s) => s.t >= now - RATE_HISTORY_MS));
  assert.equal(h.samples.length, RATE_HISTORY_MS / 10_000 + 1);
});

test("a worker missing from one snapshot keeps its baseline", () => {
  let h = appendRates(EMPTY_RATES, snapshot([
    { name: "smppclient.a", submitted: 100 },
    { name: "smppclient.b", submitted: 100 },
  ]), 0);
  h = appendRates(h, snapshot([{ name: "smppclient.a", submitted: 200 }]), 10_000);
  h = appendRates(h, snapshot([
    { name: "smppclient.a", submitted: 300 },
    { name: "smppclient.b", submitted: 400 },
  ]), 20_000);
  //b: 300 more over the twenty seconds it was unseen, against its old baseline
  assert.equal(h.samples[2].mt["smppclient.b"], 15);
  assert.equal(h.samples[1].mt["smppclient.b"], undefined, "not reported, not invented");
});

test("rateOf sums the matching workers and is null when none measured anything", () => {
  const sample = {
    t: 0,
    mt: { "smppclient.a": 10, "smppclient.b": 2.5, "smppserver.in": 12, "smppclient.c": null },
  };
  assert.equal(rateOf(sample, (n) => n.startsWith("smppclient.")), 12.5);
  assert.equal(rateOf(sample, (n) => n === "smppserver.in"), 12);
  assert.equal(rateOf(sample, (n) => n === "smppclient.c"), null);
  assert.equal(rateOf(sample, () => false), null);
});

test("the previous history is not mutated, so React sees a new reference", () => {
  const before = appendRates(EMPTY_RATES, snapshot([{ submitted: 1 }]), 0);
  const after = appendRates(before, snapshot([{ submitted: 2 }]), 1000);
  assert.notEqual(before, after);
  assert.equal(before.samples.length, 1);
  assert.equal(after.samples.length, 2);
});
