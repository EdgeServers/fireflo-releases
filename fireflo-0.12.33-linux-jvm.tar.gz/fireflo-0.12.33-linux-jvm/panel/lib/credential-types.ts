import type { SecretField, SecretState } from "@/lib/secrets";
import { ALL_FIELDS } from "@/lib/rate-types";

/**
 * A credential: how a customer connects, and which account their traffic is billed to.
 *
 * <p>Zero database imports — see the note at the top of `rate-types.ts` for what happens otherwise.
 *
 * <p>This is the one editor in the panel that touches authentication, and `app_credential` is
 * unusually unguarded: no CHECK on `type` before V1.7.0, no unique index for HTTP at all, no
 * whitespace constraints, and a loader that responds to one bad row by discarding every credential
 * and retaining the previous snapshot. Most of what is below exists because of that.
 */

export const CREDENTIAL_TYPES = ["SMPP", "HTTP"] as const;
export type CredentialType = (typeof CREDENTIAL_TYPES)[number];

/**
 * One SMPP login's own limits (gateway V1.66.0), each null when it has none and the listener's and
 * account's settings decide. They narrow, never widen: the account's connection limit and TPS still
 * apply, so a login can be held below its account but not lifted above it.
 */
export interface SessionLimits {
  /** Sessions this login may hold on one listener, of any bind type. */
  maxSessions: number | null;
  maxTx: number | null;
  maxRx: number | null;
  maxTrx: number | null;
  /** Messages per second across all of this login's sessions on one listener. */
  maxTps: number | null;
}

export const NO_LIMITS: SessionLimits = { maxSessions: null, maxTx: null, maxRx: null, maxTrx: null, maxTps: null };

export function hasLimits(limits: SessionLimits | null | undefined): boolean {
  return !!limits && Object.values(limits).some((v) => v != null);
}

/** "4 sessions (2 TX, 2 RX), 50 TPS", for the summary line. */
export function limitsSummary(limits: SessionLimits): string {
  const types = [
    limits.maxTx != null ? `${limits.maxTx} TX` : null,
    limits.maxRx != null ? `${limits.maxRx} RX` : null,
    limits.maxTrx != null ? `${limits.maxTrx} TRX` : null,
  ].filter(Boolean);
  const parts = [
    limits.maxSessions != null || types.length
      ? `${limits.maxSessions != null ? `${limits.maxSessions} session${limits.maxSessions === 1 ? "" : "s"}` : "sessions"}`
        + (types.length ? ` (${types.join(", ")})` : "")
      : null,
    limits.maxTps != null ? `${limits.maxTps} TPS` : null,
  ].filter(Boolean);
  return parts.join(", ");
}

export interface Credential {
  id: number;
  /** A string rather than CredentialType: an existing row may hold anything, and this must say so. */
  type: string;
  systemId: string | null;
  accountId: string | null;
  product: string | null;
  allowedIps: string[];
  /**
   * Products this login may name on a REST send, beyond its own.
   *
   * <p>Empty is the meaningful default and it is fail-closed: a login with nothing here may not name
   * a product at all. That is the opposite of {@link allowedIps}, where empty means "from anywhere",
   * and the asymmetry is deliberate -- the product selects the rate, so a caller free to choose one
   * is a caller free to choose their own price.
   *
   * <p>The login's own {@link product} is always allowed and is not stored here. Copying it in would
   * freeze the default at whatever it was the day somebody added a second entry.
   */
  allowedProducts: string[];
  defaultTlvs: { key: string; value: string }[];
  limits: SessionLimits;
  enabled: boolean;
  updatedAt: string | null;

  password: SecretState;
  apiKey: SecretState;

  /**
   * What the gateway keys its credential map on — null when that would be the api key.
   *
   * <p>`getLookupKey()` returns the api key for an HTTP credential that has one, so sending it to a
   * browser would leak the secret through the back door. The UI says "the API key" instead, and
   * collision detection for those rows happens only on the server.
   */
  lookupKey: string | null;
  lookupKeyIsSecret: boolean;

  /** `billingAccountOf()`, with the fallback that produced it named. */
  billingAccount: string | null;
  billingAccountFallback: "none" | "systemId" | "apiKey";
}

export interface CredentialInput {
  id: number | null;
  type: string;
  systemId: string | null;
  password: SecretField;
  apiKey: SecretField;
  accountId: string | null;
  product: string | null;
  allowedIps: string[];
  /**
   * Products this login may name on a REST send, beyond its own.
   *
   * <p>Empty is the meaningful default and it is fail-closed: a login with nothing here may not name
   * a product at all. That is the opposite of {@link allowedIps}, where empty means "from anywhere",
   * and the asymmetry is deliberate -- the product selects the rate, so a caller free to choose one
   * is a caller free to choose their own price.
   *
   * <p>The login's own {@link product} is always allowed and is not stored here. Copying it in would
   * freeze the default at whatever it was the day somebody added a second entry.
   */
  allowedProducts: string[];
  /**
   * Ordered pairs, not a Record.
   *
   * <p>A Record cannot hold two entries whose keys resolve to the same TLV tag long enough for the
   * validator to complain about them — it drops one on the way in, which is precisely the mistake
   * being checked for.
   */
  defaultTlvs: { key: string; value: string }[];
  /**
   * SMPP only. Absent (as from the customer portal, which may not set them) leaves a row's limits
   * as they are on an update and empty on a create.
   */
  limits?: SessionLimits;
  enabled: boolean;
  /** Said out loud, matching `ScopeInput.scopeConfirmed`. */
  productConfirmed?: boolean;
  billingConfirmed?: boolean;
}

/** Everything the validator needs that lives in other tables. */
export interface CredentialContext {
  /** Catalogue names plus orphans, so an existing credential is never refused for its own product. */
  products: string[];
  disabledProducts: string[];
  /** Lookup keys already in use, by another enabled row. */
  conflicts: { key: string; id: number; type: string; enabled: boolean }[];
}

/** The gateway's own key, reproduced exactly. SMPP: systemId. HTTP: apiKey if set, else systemId. */
export function lookupKeyOf(input: CredentialInput, hasApiKey: boolean): string | null {
  if (input.type === "SMPP") {
    return input.systemId?.trim() || null;
  }
  return hasApiKey ? null : input.systemId?.trim() || null;
}

/**
 * Which account this credential bills to, and how that was decided.
 *
 * <p>The two fallbacks are genuinely different code paths in the gateway — SMPP falls back to
 * `systemId`, HTTP to `getLookupKey()` — and the HTTP one is the reason an api-key credential with
 * no account bills to the secret itself.
 */
export function billingOf(
  type: string,
  accountId: string | null,
  systemId: string | null,
  hasApiKey: boolean
): { account: string | null; fallback: Credential["billingAccountFallback"] } {
  const explicit = accountId?.trim();
  if (explicit) {
    return { account: explicit, fallback: "none" };
  }
  if (type === "SMPP") {
    return { account: systemId?.trim() || null, fallback: "systemId" };
  }
  return hasApiKey
    ? { account: null, fallback: "apiKey" }
    : { account: systemId?.trim() || null, fallback: "systemId" };
}

/**
 * Re-exported so existing callers keep one import.
 *
 * <p>The parser itself moved to `tlv-catalogue.ts`, which is where every other consumer of it now
 * lives. There must be exactly one: a second implementation drifting means the panel and the gateway
 * disagree about which tag a setting names, and the disagreement is silent.
 */
export { tlvTag } from "./tlv-catalogue";
import { tlvTag } from "./tlv-catalogue";

/** Anything that is not a plain IPv4 or IPv6 literal will never string-match a peer address. */
function looksLikeAddress(value: string): boolean {
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(value)) {
    return value.split(".").every((part) => Number(part) <= 255);
  }
  //deliberately loose on IPv6: the gateway compares strings, so the only real question is whether a
  //human could have meant this as one address
  return /^[0-9a-fA-F:]+$/.test(value) && value.includes(":");
}

/**
 * Everything that must stop a save, as one human sentence.
 *
 * @returns the reason, or null
 */
export function validateCredential(
  input: CredentialInput,
  context: CredentialContext
): string | null {
  //exactly, not case-insensitively. valueOf() upper-cases so 'smpp' would load and behave as SMPP,
  //but uq_app_credential_smpp compares type = 'SMPP' literally, so the row would escape the only
  //unique index on the table
  if (!(CREDENTIAL_TYPES as readonly string[]).includes(input.type)) {
    return `'${input.type}' is not SMPP or HTTP. The gateway turns this column into an enum, and an `
      + "unrecognised value makes the whole credential load throw — which it responds to by keeping "
      + "the previous set, so nothing breaks until the next restart and nothing connects the two.";
  }

  const identifiers: [string, string | null][] = [
    ["System ID", input.systemId],
    ["Account", input.accountId],
    ["Product", input.product],
  ];
  for (const [what, value] of identifiers) {
    if (value != null && value !== value.trim()) {
      return `${what} has a space at one end. There are no trim checks on this table and the lookup `
        + "is exact string equality, so the customer would connect with what looks like the right "
        + "value, be refused, and nothing would say why.";
    }
  }

  const hasPassword = input.password.state !== "unset";
  const hasApiKey = input.apiKey.state !== "unset";
  const systemId = input.systemId?.trim() ?? "";

  if (input.type === "SMPP") {
    if (!systemId) {
      return "An SMPP credential needs a system ID. It is what the client binds with and what the "
        + "gateway looks it up by.";
    }
    if (!hasPassword) {
      return "An SMPP credential needs a password. Without one the gateway considers the row invalid, "
        + "skips it with a warning and no error, and the customer cannot bind — the credential "
        + "exists, is enabled, and is simply not there.";
    }
    if (input.password.state === "set" && input.password.value === "") {
      return "An empty password is not the same as no password. The gateway's check is for absence, "
        + "not for blankness, so this row loads and sits in the map — and then no bind can ever "
        + "match it, which presents as the customer having the wrong password.";
    }
  } else {
    if (!hasApiKey && !(systemId && hasPassword)) {
      return "An HTTP credential needs either an API key, or a system ID and a password. With "
        + "neither the gateway skips the row with a warning and no error.";
    }
    if (input.apiKey.state === "set" && input.apiKey.value === "") {
      return "An empty API key is not the same as no API key.";
    }
  }

  const key = lookupKeyOf(input, hasApiKey);
  if (key) {
    const clash = context.conflicts.find((c) => c.key === key && c.enabled && c.id !== input.id);
    if (clash) {
      return `'${key}' is already the lookup key of credential #${clash.id} (${clash.type}). The `
        + "gateway loads every credential into one map keyed on it, ordered by id, and resolves a "
        + "duplicate by keeping the later row — so one of these two customers stops working, and "
        + "which one depends on which id is higher.";
    }
  }

  const product = input.product?.trim();
  if (product && !context.products.includes(product) && !input.productConfirmed) {
    return `'${product}' is not in the catalogue and nothing else uses it. Products are matched by `
      + "exact string, so an unrecognised one loads fine, matches no product-specific rate rule, and "
      + "the traffic is billed by whatever any-product catch-all exists — at that price. Tick the "
      + "confirmation if you are about to create it.";
  }

  //an api-key credential with no account bills to the lookup key, which IS the api key -- so the
  //secret would land in cdr_submit.account_id, the revenue figures, and every CDR export
  if (!input.accountId?.trim() && input.type === "HTTP" && hasApiKey && !input.billingConfirmed) {
    return "With no account, billing falls back to this credential's lookup key — which here is the "
      + "API key itself. The secret would appear in every call record, in the revenue figures, and "
      + "in every CSV export of them. Set an account, or tick the confirmation.";
  }

  const seenTags = new Map<number, string>();
  for (const tlv of input.defaultTlvs) {
    const tag = tlvTag(tlv.key);
    if (tag == null) {
      return `'${tlv.key}' carries no TLV tag in the range 0x0000-0xFFFF. The gateway logs it and `
        + "drops it, so the default you meant to set would simply not be sent — and if that tag is "
        + "one the listener requires, every message from this customer is rejected at ingress.";
    }
    const already = seenTags.get(tag);
    if (already != null) {
      return `'${tlv.key}' and '${already}' are the same TLV tag (0x${tag.toString(16).toUpperCase()}). `
        + "The gateway keeps the first and drops the second without saying so.";
    }
    seenTags.set(tag, tlv.key);
  }

  const limits = input.limits;
  if (limits && hasLimits(limits)) {
    if (input.type !== "SMPP") {
      return "Session and TPS limits are for SMPP logins. A REST login's rate is its account's.";
    }
    const counts: [keyof SessionLimits, string][] = [
      ["maxSessions", "Sessions"], ["maxTx", "Transmitter sessions"], ["maxRx", "Receiver sessions"],
      ["maxTrx", "Transceiver sessions"],
    ];
    for (const [key, label] of counts) {
      const v = limits[key];
      if (v != null && (!Number.isInteger(v) || v < 1 || v > 10_000)) {
        return `${label} must be a whole number from 1 to 10000, or empty for no limit of its own.`;
      }
    }
    if (limits.maxTps != null && (!Number.isFinite(limits.maxTps) || limits.maxTps <= 0 || limits.maxTps > 100_000)) {
      return "TPS must be more than 0 and at most 100000, or empty for the account's.";
    }
    if (limits.maxTps != null && Math.round(limits.maxTps * 100) !== limits.maxTps * 100) {
      return "TPS takes at most two decimal places.";
    }
    for (const [key, label] of counts.slice(1)) {
      const v = limits[key];
      if (v != null && limits.maxSessions != null && v > limits.maxSessions) {
        return `${label} (${v}) cannot be more than the login's sessions in total (${limits.maxSessions}).`;
      }
    }
  }

  for (const ip of input.allowedIps) {
    if (ip.includes("/")) {
      return `'${ip}' is matched as an exact string, not as a range — so it would allow nothing. And `
        + "a list that allows nothing is not a closed door, because it is not empty: it refuses every "
        + "connection including the legitimate one.";
    }
    if (ip.trim() && !looksLikeAddress(ip.trim())) {
      return `'${ip}' is not an IP address. The gateway compares the peer address as a string, so a `
        + "hostname or a wildcard never matches anything.";
    }
  }

  return null;
}

/** Worth saying, not worth blocking. */
export function credentialWarnings(
  input: CredentialInput,
  context: CredentialContext
): string[] {
  const warnings: string[] = [];
  const hasApiKey = input.apiKey.state !== "unset";
  const hasPassword = input.password.state !== "unset";

  if (!input.allowedIps.length) {
    warnings.push("No IP restriction, so this credential works from anywhere. An empty list is "
      + "allow-all, not deny-all.");
  }
  if (input.type === "HTTP" && hasApiKey && !hasPassword) {
    warnings.push("An API key with no password is valid configuration that cannot sign in: the REST "
      + "API authenticates with HTTP Basic and the key is the username, so every request is refused "
      + "with 403.");
  }
  if (!input.accountId?.trim() && !(input.type === "HTTP" && hasApiKey)) {
    const fallback = billingOf(input.type, null, input.systemId, hasApiKey).account ?? "its lookup key";
    warnings.push(`With no account, billing falls back to '${fallback}'. Rate scopes and prepaid `
      + "balances are both keyed on the account, and no balance row exists under that name unless "
      + "somebody created one — an account with no balance row is not at zero, it has no balance.");
  }
  const product = input.product?.trim();
  if (product && context.disabledProducts.includes(product)) {
    warnings.push(`'${product}' is unlisted in the catalogue. That is a panel-side flag only — the `
      + "gateway never reads it, so its rate rules go on pricing this traffic exactly as before.");
  }
  if (product && input.type === "SMPP") {
    warnings.push("For SMPP this is only a fallback: the system_type on the bind wins. A customer "
      + `binding with a mistyped system_type is priced as whatever they typed, and this field will `
      + "not save them.");
  }
  for (const tlv of input.defaultTlvs) {
    if (tlv.value.startsWith("MESSAGE:")) {
      const field = tlv.value.slice("MESSAGE:".length);
      if (!(ALL_FIELDS as readonly string[]).includes(field)) {
        warnings.push(`'${tlv.value}' names no message field, so it is sent as that literal text.`);
      }
    }
  }
  if (input.defaultTlvs.length) {
    warnings.push("Default TLVs are snapshotted when a client binds, so a change here reaches an "
      + "SMPP customer on their next bind rather than on the gateway's next poll.");
  }
  return warnings;
}
