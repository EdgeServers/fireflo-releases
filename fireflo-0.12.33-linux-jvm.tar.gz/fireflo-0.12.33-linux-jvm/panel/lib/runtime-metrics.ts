import { byName, first, parseMetrics, sum, type MetricFamily } from "./prometheus";

/**
 * Turning the gateway's `/q/metrics` into something an operator can read.
 *
 * <p><strong>This is runtime health, not SMS traffic.</strong> The endpoint carries stock JVM, HTTP,
 * Vert.x and Netty metrics and no FireFlo ones at all — nothing counts messages, deliveries or
 * per-vendor throughput. Those questions are answered by the call records and by `/ops/health`, and
 * saying so on the page is the only thing that stops this being read as an SMS dashboard.
 *
 * <p>The grouping is by hand rather than by prefix. `jvm` alone is 23 families covering three
 * unrelated concerns, and "everything beginning with jvm_" is not a thing anyone wants to look at.
 */

export interface MetricGroup {
  key: string;
  label: string;
  hint: string;
  families: MetricFamily[];
}

export interface Headline {
  heapUsed: number;
  heapMax: number;
  /** 0..1, or null when the JVM has not reported it yet */
  processCpu: number | null;
  systemCpu: number | null;
  loadAverage: number | null;
  cpuCount: number | null;
  threadsLive: number | null;
  threadsDaemon: number | null;
  threadsPeak: number | null;
  /** cumulative; a rate needs two readings, which the client does */
  httpRequests: number;
  /** seconds, averaged over every request since start */
  httpMeanLatency: number | null;
  httpActive: number | null;
  workerActive: number | null;
  workerIdle: number | null;
  workerQueued: number | null;
  workerRejected: number | null;
  uptimeSeconds: number | null;
  gcPauseTotal: number;
  gcPauseCount: number;
  openFiles: number | null;
  maxFiles: number | null;
}

export interface RuntimeSnapshot {
  observedAt: string;
  groups: MetricGroup[];
  headline: Headline;
  familyCount: number;
  /**
   * table -> rule key -> messages sent through it since the gateway last started.
   *
   * <p>The one FireFlo business metric on this endpoint, kept out of {@link groups} on purpose:
   * this file's own opening note says `/q/metrics` carries no traffic numbers, and merging this in
   * among the JVM families would make that statement false by omission. It exists here rather than
   * a second fetch because parsing already happened for the JVM headline and the payload is the
   * same one request either way. `/cp/routing` is the only reader.
   */
  routingRuleMatches: RuleMatchCounts;
  /**
   * `fireflo_smpp_bind_refused_total` by reason — why binds were refused since restart. Empty on
   * an older gateway or one with no meter registry; the card renders nothing then, because "no
   * counter" and "no refusals" must not look alike only when a refusal is being investigated.
   */
  bindRefusals: Record<string, number>;
}

/** table -> rule key -> count. The rule key is `RoutingExplanation`'s: a label, or `table:seq`. */
export interface RuleMatchCounts {
  [table: string]: { [rule: string]: number };
}

/**
 * Which families belong to which group, longest prefix first so `jvm_gc` is not eaten by `jvm_`.
 *
 * <p>Every family must land somewhere. Anything unmatched falls into "Other" rather than being
 * dropped — a metric the gateway grew and this file has not heard of should appear, not vanish.
 */
const GROUPS: { key: string; label: string; hint: string; prefixes: string[] }[] = [
  {
    key: "memory",
    label: "Memory",
    hint: "Memory that keeps climbing after a cleanup is the shape of a leak.",
    prefixes: ["jvm_memory", "jvm_gc", "jvm_buffer"],
  },
  {
    key: "threads",
    label: "Tasks and loaded code",
    hint: "Running tasks growing without bound usually means something is not being shut down.",
    prefixes: ["jvm_threads", "jvm_classes", "jvm_info"],
  },
  {
    key: "system",
    label: "Processor and host",
    hint: "Open files approaching the limit will refuse new SMPP connections before anything else fails.",
    prefixes: ["process_", "system_"],
  },
  {
    key: "http",
    label: "API requests",
    hint: "Messages submitted over HTTP, and this panel's own calls, by route.",
    prefixes: ["http_"],
  },
  {
    key: "worker",
    label: "Internal task queue",
    hint: "The gateway's own background work -- NOT vendor connections. Work that never clears is arriving faster than it can be done.",
    prefixes: ["worker_"],
  },
  {
    key: "netty",
    label: "Network transport",
    hint: "Memory buffers and threads inside the SMPP networking layer. Rarely actionable.",
    prefixes: ["netty_"],
  },
];

export function toSnapshot(text: string, observedAt: string): RuntimeSnapshot {
  const families = parseMetrics(text);
  return {
    observedAt,
    groups: group(families),
    headline: headline(families),
    familyCount: families.length,
    routingRuleMatches: routingRuleMatches(families),
    bindRefusals: bindRefusals(families),
  };
}

/**
 * Reads the bind-refusal counters (gateway I3). Prometheus renders the counter family as
 * `fireflo_smpp_bind_refused_total` with one sample per `reason` label.
 */
function bindRefusals(families: MetricFamily[]): Record<string, number> {
  const family = byName(families).get("fireflo_smpp_bind_refused_total") ??
    byName(families).get("fireflo_smpp_bind_refused");
  const out: Record<string, number> = {};
  if (!family) {
    return out;
  }
  for (const s of family.samples) {
    const reason = s.labels.reason;
    if (reason && Number.isFinite(s.value) && s.value > 0) {
      out[reason] = s.value;
    }
  }
  return out;
}

/**
 * Reads `fireflo_routing_rule_matches`, the counter `AbstractRoutingManager.recordRuleMatch`
 * registers per (table, rule) the first time that rule actually sends a message.
 *
 * <p>Absent entirely on a gateway with no meter registry, or before any rule in a table has ever
 * matched -- both ordinary, and both render as "0 since restart" rather than an error.
 */
function routingRuleMatches(families: MetricFamily[]): RuleMatchCounts {
  const family = byName(families).get("fireflo_routing_rule_matches");
  const out: RuleMatchCounts = {};
  if (!family) {
    return out;
  }
  for (const s of family.samples) {
    const table = s.labels.table;
    const rule = s.labels.rule;
    if (!table || !rule || !Number.isFinite(s.value)) {
      continue;
    }
    (out[table] ??= {})[rule] = s.value;
  }
  return out;
}

function group(families: MetricFamily[]): MetricGroup[] {
  const groups: MetricGroup[] = GROUPS.map((g) => ({ ...g, families: [] }));
  const other: MetricFamily[] = [];

  for (const family of families) {
    const index = GROUPS.findIndex((g) => g.prefixes.some((p) => family.name.startsWith(p)));
    if (index === -1) {
      other.push(family);
    } else {
      groups[index].families.push(family);
    }
  }

  for (const g of groups) {
    g.families.sort((a, b) => a.name.localeCompare(b.name));
  }
  if (other.length) {
    //not silently discarded: a family this file has never heard of is exactly the one worth seeing
    groups.push({
      key: "other",
      label: "Other",
      hint: "Families this page does not have a home for yet.",
      families: other.sort((a, b) => a.name.localeCompare(b.name)),
    });
  }
  return groups;
}

function headline(families: MetricFamily[]): Headline {
  const m = byName(families);
  const requestCount = sumWhere(m.get("http_server_requests_seconds"), "_count");
  const requestSeconds = sumWhere(m.get("http_server_requests_seconds"), "_sum");

  return {
    heapUsed: sum(m.get("jvm_memory_used_bytes"), { area: "heap" }),
    heapMax: sum(m.get("jvm_memory_max_bytes"), { area: "heap" }),
    processCpu: first(m.get("process_cpu_usage")),
    systemCpu: first(m.get("system_cpu_usage")),
    loadAverage: first(m.get("system_load_average_1m")),
    cpuCount: first(m.get("system_cpu_count")),
    threadsLive: first(m.get("jvm_threads_live_threads")),
    threadsDaemon: first(m.get("jvm_threads_daemon_threads")),
    threadsPeak: first(m.get("jvm_threads_peak_threads")),
    httpRequests: requestCount,
    //mean since start, not a live latency: a summary carries a running total and a count, nothing
    //windowed. Useful for spotting a route that is slow in general, useless for a spike
    httpMeanLatency: requestCount > 0 ? requestSeconds / requestCount : null,
    httpActive: first(m.get("http_server_active_requests")),
    workerActive: first(m.get("worker_pool_active")),
    workerIdle: first(m.get("worker_pool_idle")),
    workerQueued: first(m.get("worker_pool_queue_size")),
    workerRejected: first(m.get("worker_pool_rejected")),
    uptimeSeconds: first(m.get("process_uptime_seconds")),
    gcPauseTotal: sumWhere(m.get("jvm_gc_pause_seconds"), "_sum"),
    gcPauseCount: sumWhere(m.get("jvm_gc_pause_seconds"), "_count"),
    openFiles: first(m.get("process_files_open_files")),
    maxFiles: first(m.get("process_files_max_files")),
  };
}

/**
 * Sums only the samples whose emitted name ends with this suffix.
 *
 * <p>A summary family holds `_count` and `_sum` samples side by side, so summing the family whole
 * would add a duration to a quantity and produce a number that means nothing.
 */
function sumWhere(family: MetricFamily | undefined, suffix: string): number {
  if (!family) {
    return 0;
  }
  return family.samples
    .filter((s) => s.name.endsWith(suffix) && Number.isFinite(s.value))
    .reduce((total, s) => total + s.value, 0);
}
