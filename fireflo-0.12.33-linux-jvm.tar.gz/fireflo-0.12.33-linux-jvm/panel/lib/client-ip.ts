/**
 * The caller's address, as far as we can tell.
 *
 * <p>One implementation, because two would drift and an access log whose IP means something
 * different depending on which route wrote it is worse than one with no IP at all.
 *
 * <h2>Right-most, not left-most, and the reasoning that got this wrong</h2>
 *
 * <p>This used to take the **left-most** `X-Forwarded-For` entry, justified by "that is the one
 * nginx wrote and anything a client forged is pushed to the right of it". That is only true of
 * `proxy_set_header X-Forwarded-For $remote_addr`, which **overwrites**. The near-universal recipe
 * is `$proxy_add_x_forwarded_for`, which **appends** — so with it the left-most entry is whatever
 * the client sent, and every address in both access logs was chosen by the visitor.
 *
 * <p>That is not a cosmetic error. `lib/mis-auth.ts` names `link_requested.requested_ip` against
 * `link_redeemed.ip` as the row that makes a stolen sign-in link visible, and a forgeable field
 * cannot do that. `notePortalAccess` also dedups on `accountId|ip`, so a varying forged value
 * defeats its one-row-per-hour bound.
 *
 * <p>So: **count from the right**, which is correct under both recipes. Appending leaves the hop
 * your proxy observed at the end; overwriting leaves exactly one entry, which is both ends at once.
 *
 * <h2>Forwarding headers are only read when an operator said there is a proxy</h2>
 *
 * <p>Counting from the right is still a statement of trust in whoever wrote the right-most entry.
 * With the panel's port exposed directly -- a LAN install, which the README allows -- nobody wrote
 * it but the visitor, and a caller could then set a fresh `X-Forwarded-For` on every request: a new
 * key for the sign-in lockout and the link limiter each time, and an arbitrary address pushed into
 * the file fail2ban bans from. The 0.13 readiness audit (CP-S3) named exactly that.
 *
 * <p>The right fix is to honour the headers only when the socket peer is a proxy we were told
 * about. Route handlers in this Next version cannot do that: the request is a web `Request`, and
 * `NextRequest.ip` was removed in 15.0 (see `node_modules/next/dist/docs/.../next-request.md`), so
 * the peer address is simply not available where this runs. What IS available is whether the
 * operator configured a proxy at all. So the rule is:
 *
 * <ul>
 *   <li>`TRUSTED_PROXY_HOPS` set to a positive number: there is a proxy, and that many right-hand
 *       entries were written by it. Read the chain (and `X-Real-IP` as a fallback) as before.
 *   <li>`TRUSTED_PROXY_HOPS` unset, empty, or `0`: there is no proxy we know of, so the headers are
 *       the visitor's and are ignored. The address is `null`, which the sign-in lockout treats as
 *       one shared origin per email (stricter, not weaker) and the fail2ban feed skips.
 * </ul>
 *
 * <p>That closes the LAN case, which by definition has no hops configured. It also means <strong>a
 * panel behind nginx that never set `TRUSTED_PROXY_HOPS` now records no client address at all</strong>
 * -- before this change it took the default of one hop and got the right answer by luck of the
 * common recipe. Such an install must set `TRUSTED_PROXY_HOPS=1` (the value `conf.example/panel.env`
 * shows commented out) to get addresses back; until it does, the access logs show `-`, fail2ban
 * sees nothing to ban, and every visitor shares one link-request budget.
 */

/**
 * How many entries at the right-hand end were written by infrastructure you control, or `0` when
 * nothing says a proxy exists.
 *
 * <p>One nginx on loopback appends one entry. A CDN in front of it appends another, so that
 * deployment sets `2` -- and setting it too high hands the choice back to the client, which is why
 * it is a deliberate number rather than something guessed from the chain.
 *
 * <p>Read per call rather than once at import: it is one env lookup, and a value fixed at import
 * cannot be exercised by a test. A set-but-unparseable value is reported once and treated as no
 * proxy, the safe direction: it never hands the visitor the choice of address.
 */
let warnedBadHops = false;

function trustedHops(): number {
  const raw = process.env.TRUSTED_PROXY_HOPS?.trim();
  if (!raw) {
    return 0;
  }
  const n = Number(raw);
  if (!Number.isInteger(n) || n < 0) {
    if (!warnedBadHops) {
      warnedBadHops = true;
      console.error(
        `TRUSTED_PROXY_HOPS=${JSON.stringify(raw)} is not a whole number; forwarding headers are being `
          + "ignored and no client address is recorded. Set it to the number of proxies in front of the panel."
      );
    }
    return 0;
  }
  return n;
}

export function clientIp(req: { headers: Headers }): string | null {
  const trusted = trustedHops();
  if (trusted === 0) {
    //no proxy declared, so every forwarding header is the visitor's own writing. The peer address
    //is not reachable from a route handler (see the file comment), so the honest answer is none
    return null;
  }
  const forwarded = req.headers.get("x-forwarded-for");
  if (forwarded) {
    const hops = forwarded.split(",").map((h) => h.trim()).filter(Boolean);
    //the entry the outermost trusted proxy observed. Clamped rather than returning null on a short
    //chain: a request that reached us through fewer proxies than configured is a misconfiguration,
    //and the left-most entry is the closest thing to an answer it has
    const at = Math.max(0, hops.length - trusted);
    if (hops[at]) {
      return hops[at];
    }
  }
  //some proxies send only this one. Checked second so a chain-aware header always wins
  return req.headers.get("x-real-ip")?.trim() || null;
}

/**
 * @return the user agent, truncated. Long enough to tell browsers apart, short enough that one
 *     request cannot push an access-log line past the size that keeps appends atomic
 */
export function clientUserAgent(req: { headers: Headers }): string | null {
  const ua = req.headers.get("user-agent")?.trim();
  if (!ua) {
    return null;
  }
  return ua.length > 256 ? `${ua.slice(0, 253)}...` : ua;
}
