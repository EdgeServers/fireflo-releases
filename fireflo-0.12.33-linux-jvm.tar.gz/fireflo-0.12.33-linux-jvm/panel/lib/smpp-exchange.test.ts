import { test } from "node:test";
import assert from "node:assert/strict";
import { buildSmppExchange } from "./smpp-exchange.ts";
import type { CdrRow, MessageReceipt } from "./cdr-request.ts";

/**
 * The exchange view's ordering rule -- the part that matters is not any one row, it is what a
 * retry storm and multipart submission read as once merged.
 */

function attempt(over: Partial<CdrRow> = {}): CdrRow {
  return {
    id: "1", gatewayMsgId: "gw-1", partNo: 1, partCount: 1, retryCount: 0,
    submittedAt: "2026-08-24T10:00:00.000Z", acceptedAt: null,
    accountId: null, systemId: null, product: null, ingress: "smpp", inGateway: null, vendor: null,
    sourceAddr: null, destAddr: null, mcc: null, mnc: null, dcs: null, msgType: null,
    operatorMsgId: null,
    costRate: null, costUnits: null, cost: null,
    priceRate: null, billedUnits: null, price: null,
    margin: null, marginPct: null, marginStatus: null,
    costRuleId: null, priceRuleId: null, currency: null,
    finalState: null, dlrState: null, errCode: null, finalAt: null,
    ...over,
  } as CdrRow;
}

function receipt(over: Partial<MessageReceipt> = {}): MessageReceipt {
  return {
    id: "r1", partNo: 1, kind: "outcome", operatorMsgId: null,
    finalState: "DELIVERED", dlrState: 2, errCode: null,
    receivedAt: "2026-08-24T10:00:05.000Z", vendor: null, forwarded: null,
    ...over,
  } as MessageReceipt;
}

test("a plain send is submit_sm, its resp, then the receipt, in that order", () => {
  const events = buildSmppExchange(
    [attempt({ submittedAt: "2026-08-24T10:00:00.000Z", acceptedAt: "2026-08-24T10:00:01.000Z",
      submitStatus: 0 } as CdrRow)],
    [receipt({ receivedAt: "2026-08-24T10:00:05.000Z" })]
  );

  assert.deepEqual(events.map((e) => e.pdu), ["submit_sm", "submit_sm_resp", "deliver_sm"]);
  assert.equal(events[2].terminal, true);
});

test("a retryable nack with no schema support for submit_status emits only the request", () => {
  //the CdrRow simply lacks the key -- an older gateway, before V1.40.0 -- and this must not
  //invent a resp event the database never recorded
  const events = buildSmppExchange([attempt()], []);

  assert.deepEqual(events.map((e) => e.pdu), ["submit_sm"]);
});

test("a retry storm reads as N request/response pairs, ordered by attempt", () => {
  //the case this module exists for: three attempts to the same vendor, same part, same
  //retry_count is not what happens here -- vendor_attempt is folded into "attempt" already via
  //retryCount in this fixture set, but the ordering rule is what is under test: time order wins
  const events = buildSmppExchange(
    [
      attempt({ retryCount: 0, submittedAt: "2026-08-24T10:00:00.000Z",
        acceptedAt: "2026-08-24T10:00:00.100Z", submitStatus: 88 } as CdrRow),
      attempt({ retryCount: 1, submittedAt: "2026-08-24T10:00:01.000Z",
        acceptedAt: "2026-08-24T10:00:01.100Z", submitStatus: 88 } as CdrRow),
      attempt({ retryCount: 2, submittedAt: "2026-08-24T10:00:02.000Z",
        acceptedAt: "2026-08-24T10:00:02.100Z", submitStatus: 0 } as CdrRow),
    ],
    [receipt({ receivedAt: "2026-08-24T10:00:07.000Z" })]
  );

  assert.deepEqual(events.map((e) => e.pdu),
    ["submit_sm", "submit_sm_resp", "submit_sm", "submit_sm_resp", "submit_sm", "submit_sm_resp",
      "deliver_sm"]);
  assert.deepEqual(events.map((e) => e.attempt?.retryCount),
    [0, 0, 1, 1, 2, 2, undefined]);
  assert.equal(events[1].status, "ESME_RTHROTTLED");
  assert.equal(events[5].status, "0",
    "status 0 (ESME_ROK) has no mnemonic in the vendor table, so it falls back to the raw number");
});

test("multipart interleaves by part, not by submission order", () => {
  const events = buildSmppExchange(
    [
      attempt({ partNo: 1, submittedAt: "2026-08-24T10:00:00.000Z" }),
      attempt({ partNo: 2, submittedAt: "2026-08-24T10:00:00.050Z" }),
    ],
    []
  );

  assert.deepEqual(events.map((e) => e.partNo), [1, 2]);
});

test("a progress receipt is never terminal; the outcome that follows it is", () => {
  const events = buildSmppExchange(
    [attempt()],
    [
      receipt({ id: "p1", kind: "progress", dlrState: 1, receivedAt: "2026-08-24T10:00:02.000Z" }),
      receipt({ id: "f1", kind: "outcome", dlrState: 2, receivedAt: "2026-08-24T10:00:05.000Z" }),
    ]
  );

  const [progress, outcome] = events.filter((e) => e.pdu === "deliver_sm");
  assert.equal(progress.terminal, false);
  assert.equal(outcome.terminal, true);
});

test("deliver_sm_resp is never emitted -- nothing records it", () => {
  const events = buildSmppExchange([attempt()], [receipt()]);

  assert.ok(!events.some((e) => e.pdu === "deliver_sm_resp"));
});
