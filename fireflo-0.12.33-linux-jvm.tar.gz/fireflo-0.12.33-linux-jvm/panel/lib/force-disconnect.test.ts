import { test } from "node:test";
import assert from "node:assert/strict";
import { bindSummary, holdRemaining, holdTarget, HOLD_CHOICES, previewSentence, targetProblem, type MatchedSession } from "./force-disconnect.ts";

const row = (system_id: string, host: string, bind_type: string): MatchedSession =>
  ({ listener: "smppserver.smpp", session_id: 1, bind_type, system_id, account: "acct", host, bound_seconds: 5 });

test("targets are checked before anything is sent", () => {
  assert.equal(targetProblem("ip", ""), "Enter the ip address to disconnect.");
  assert.equal(targetProblem("ip", "10.0.0.4"), null);
  assert.equal(targetProblem("ip", "::1"), null);
  assert.equal(targetProblem("ip", "acme"), "That is not an IP address.");
  assert.equal(targetProblem("system_id", "ac me"), "No spaces: the gateway matches exactly what you enter.");
  assert.equal(targetProblem("account", "acct-1"), null);
});

test("the preview says how many and who", () => {
  assert.equal(previewSentence([]), "Nothing is bound like that right now.");
  assert.equal(previewSentence([row("acme", "10.0.0.4", "TRANSMITTER"), row("acme", "10.0.0.4", "RECEIVER"),
    row("acme", "10.0.0.9", "TRANSCEIVER")]), "Drops 3 sessions: 2 as acme from 10.0.0.4, 1 as acme from 10.0.0.9.");
  assert.equal(bindSummary([row("a", "h", "TRANSMITTER"), row("a", "h", "TRANSCEIVER"), row("a", "h", "TRANSCEIVER")]),
    "TX 1 · TRX 2");
});

test("hold choices map to what the gateway takes", () => {
  assert.deepEqual(HOLD_CHOICES.map((c) => c.hold), [null, "900", "3600", "86400", "forever"]);
});

test("a hold reads as what it holds and for how long", () => {
  const now = Date.parse("2026-10-14T10:00:00Z");
  assert.equal(holdTarget({ kind: "ip", value: "10.0.0.4" }), "IP 10.0.0.4");
  assert.equal(holdRemaining(null, now), "until lifted");
  assert.equal(holdRemaining("2026-10-14T10:12:00Z", now), "for 12 more minutes");
  assert.equal(holdRemaining("2026-10-14T13:00:00Z", now), "for 3 more hours");
  assert.equal(holdRemaining("2026-10-14T09:00:00Z", now), "expired");
});
