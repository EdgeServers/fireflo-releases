/**
 * Which logins would stop binding if a listener began requiring a product.
 *
 * <p>`conf.product.required` refuses a bind whose resolved product is blank, or names no enabled row
 * in `app_product`. That is worth switching on — an unset or misspelt product matches only the rate
 * rules that carry no product, so it prices at nothing and `chargeCredit` sends it for free — but
 * switching it on blind refuses whatever is already wrong, all at once, with no warning.
 *
 * <p>So: the same rule the gateway applies, asked ahead of time against the logins that exist.
 * Database-free, so the server route, the listener page and the account page share one function
 * rather than three readings of it.
 *
 * <h2>The limit, which the wording has to carry</h2>
 *
 * <p>For an SMPP login this checks the credential's product, and `system_type` on the bind
 * <em>overrides</em> it per session. A customer binding with a mistyped `system_type` is invisible
 * here and will start failing at the flag flip — which is the point of the check, but not something
 * this report can claim to have caught. HTTP has no bind and no override, so there it is exact.
 */

/** What is wrong with a login's product, in the order an operator would fix it. */
export type ProductProblem =
  /** No product at all. Over SMPP a bind with no `system_type` resolves to this. */
  | "blank"
  /** A name with no row in the catalogue — a typo, or a product nobody created. */
  | "unknown"
  /**
   * A real product that has been unlisted. The gateway loads `WHERE enabled`, so it refuses this
   * exactly as it refuses an unknown one — but the fix is different, so it reads differently.
   */
  | "disabled";

export interface LoginProduct {
  accountId: string;
  systemId: string | null;
  /** SMPP logins carry the `system_type` caveat; HTTP ones do not. */
  type: "SMPP" | "HTTP";
  product: string;
}

export interface ProductGap extends LoginProduct {
  problem: ProductProblem;
}

export interface ProductReadinessInput {
  /** Enabled logins only. A disabled one binds nothing, so it neither passes nor fails. */
  logins: readonly LoginProduct[];
  /** Every name in `app_product`, enabled or not. */
  catalogue: readonly string[];
  /** The subset that is unlisted, which the gateway will not accept. */
  disabled: readonly string[];
}

/**
 * The logins that would be refused, most-broken first.
 *
 * <p>Ordered blank, then unknown, then disabled: a login with no product at all is both the most
 * likely to exist and the least likely to be deliberate, while a disabled product is usually
 * somebody halfway through retiring something.
 */
export function productGaps(input: ProductReadinessInput): ProductGap[] {
  const catalogue = new Set(input.catalogue.map((p) => p.trim()));
  const disabled = new Set(input.disabled.map((p) => p.trim()));

  const gaps: ProductGap[] = [];
  for (const login of input.logins) {
    const product = login.product?.trim() ?? "";
    if (!product) {
      gaps.push({ ...login, problem: "blank" });
    } else if (disabled.has(product)) {
      gaps.push({ ...login, problem: "disabled" });
    } else if (!catalogue.has(product)) {
      gaps.push({ ...login, problem: "unknown" });
    }
  }

  const order: Record<ProductProblem, number> = { blank: 0, unknown: 1, disabled: 2 };
  return gaps.sort((a, b) =>
    order[a.problem] - order[b.problem]
    || a.accountId.localeCompare(b.accountId)
    || (a.systemId ?? "").localeCompare(b.systemId ?? ""));
}

/**
 * What is wrong with this one login, and what to do about it.
 *
 * <p>Names the fix rather than the rule. "Not in the catalogue" tells an operator what the gateway
 * decided; it does not tell them whether to create the product or correct the login, and those are
 * opposite actions.
 */
export function productGapSentence(gap: ProductGap): string {
  const login = gap.systemId ? `${gap.systemId}` : "This login";
  switch (gap.problem) {
    case "blank":
      return `${login} has no product, so every message it sends is priced only by rate rules that `
        + "carry no product — today that usually means no rule at all, and an unpriced message is "
        + "sent without being charged. Set a product on the login.";
    case "unknown":
      return `${login} names '${gap.product}', which is not in the product catalogue. `
        + "Either it is a typo, or the product needs creating — until one of those, its traffic "
        + "matches no product-specific rate rule.";
    case "disabled":
      return `${login} names '${gap.product}', which exists but is unlisted. The gateway loads only `
        + "enabled products, so it will refuse this bind. Re-enable the product, or move the login "
        + "to one that is selling.";
  }
}

/**
 * One line for the whole set, or null when there is nothing to say.
 *
 * <p>Silent on an empty set deliberately. A report that renders "0 logins would fail" on every
 * healthy deployment is a report people learn to scroll past, and this one needs to be read exactly
 * once — on the day somebody is about to turn the setting on.
 */
export function productGapSummary(gaps: readonly ProductGap[], smppPresent: boolean): string | null {
  if (!gaps.length) {
    return null;
  }
  const one = gaps.length === 1;
  const head = `${gaps.length} ${one ? "login" : "logins"} would stop connecting if a listener `
    + "began requiring a product.";
  //said whenever any SMPP login is in scope, not only when one is failing: the caveat is about what
  //this cannot see, so a clean report is exactly when it matters most
  const caveat = smppPresent
    ? " This checks what each login is configured with; an SMPP client can override it with the "
      + "system_type on its bind, and a mistyped one will not show up here."
    : "";
  return head + caveat;
}
