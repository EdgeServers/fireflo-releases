import { strict as assert } from "node:assert";
import { test } from "node:test";
import {
  type BrokerForm,
  brokerProblem,
  buildAmqpUri,
  formFromStored,
  maskAmqpUri,
  parseAmqpUri,
  uriForForm,
} from "./broker-config.ts";

test("the vhost is read as the Java client reads it", () => {
  assert.equal(parseAmqpUri("amqp://guest:pw@localhost:5672/%2Ffireflo")?.vhost, "/fireflo");
  assert.equal(parseAmqpUri("amqp://guest:pw@localhost:5672/fireflo")?.vhost, "fireflo");
  assert.equal(parseAmqpUri("amqp://localhost")?.vhost, "/");
  assert.equal(parseAmqpUri("http://localhost"), null);
});

test("a URI survives being taken apart and put back", () => {
  for (const uri of [
    "amqp://guest:pw@localhost:5672/%2Ffireflo",
    "amqps://fire%40flo:p%3Aw%2F@rabbit.internal:5671/%2F",
    "amqp://u:p@[2001:db8::1]:5672/v",
  ]) {
    const parts = parseAmqpUri(uri);
    assert.ok(parts, uri);
    assert.equal(buildAmqpUri(parts), uri);
  }
});

test("the mask hides the password and nothing else", () => {
  assert.equal(maskAmqpUri("amqp://guest:secret@localhost:5672/%2Ffireflo"), "amqp://guest:••••@localhost:5672/%2Ffireflo");
});

const stored = new Map([
  ["smsg.queue.provider", "RabbitMQ"],
  ["smsg.queue.amqp.uri", "amqp://guest:secret@localhost:5672/%2Ffireflo"],
  ["smsg.queue.amqp.queue", "fireflo.submit"],
]);

test("the stored settings become a form with no password in it", () => {
  const { form, passwordSet } = formFromStored(stored);
  assert.equal(form.provider, "rabbitmq");
  assert.equal(form.vhost, "/fireflo");
  assert.equal(form.password, null);
  assert.equal(passwordSet, true);
  assert.ok(!JSON.stringify(form).includes("secret"));
});

test("a kept password comes from the stored URI, a new one replaces it", () => {
  const { form } = formFromStored(stored);
  assert.equal(uriForForm(form, stored.get("smsg.queue.amqp.uri")!), "amqp://guest:secret@localhost:5672/%2Ffireflo");
  assert.equal(uriForForm({ ...form, password: "n3w" }, null), "amqp://guest:n3w@localhost:5672/%2Ffireflo");
});

test("the form is checked only when a broker is in use", () => {
  const { form } = formFromStored(stored);
  const bad: BrokerForm = { ...form, host: "" };
  assert.match(brokerProblem(bad, true) ?? "", /host/);
  assert.equal(brokerProblem({ ...bad, provider: "memory" }, true), null);
  assert.match(brokerProblem({ ...form, port: "70000" }, true) ?? "", /port/);
  assert.match(brokerProblem({ ...form, prefetch: "0" }, true) ?? "", /Prefetch/);
  assert.match(brokerProblem({ ...form, password: null }, false) ?? "", /password/);
  assert.equal(brokerProblem(form, true), null);
});
