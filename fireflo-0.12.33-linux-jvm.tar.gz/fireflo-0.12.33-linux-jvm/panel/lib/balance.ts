import { configQuery, inTransaction } from "@/lib/config-db";
import { auditConfigChange } from "@/lib/config-audit";
import type { BalanceRow, BillingMode } from "@/lib/balance-types";
import { billReference } from "@/lib/period-close";

/**
 * Writing prepaid credit.
 *
 * <p><strong>Everything here goes through `configQuery`, the write pool.</strong> The read side lives
 * in `account-context.ts` and uses the read-only metrics pool, which is correct for reading and
 * cannot be used here.
 *
 * <p>This module reverses a decision that used to be stated in six places across both repositories:
 * that nothing in FireFlo may mint credit, and a top-up may only arrive as a `RECHARGE` row written
 * by an external billing system. That held while there was a billing system. Without one there was
 * no way to open a prepaid account at all except hand-written SQL — and the `account_balance` row it
 * needs was created by nothing, anywhere.
 *
 * <p>What did not change: the gateway still applies the money. This writes a ledger row and the
 * gateway credits it on its next recharge poll, so the panel never touches `balance` directly. The
 * audit trail is the same one the billing system would have written.
 */

interface Row {
  account_id: string;
  balance: string;
  reserved: string;
  currency: string | null;
  enabled: boolean;
  billing_mode: string;
  credit_limit: string;
}

/** Thrown when a period is closed for an account that was never opened for credit. */
export class NoBalanceRow extends Error {
  constructor(public readonly accountId: string) {
    super(`${accountId} has no account_balance row.`);
    this.name = "NoBalanceRow";
  }
}

/** Thrown when the reference has been used before, which is the replay guard doing its job. */
export class DuplicateReference extends Error {
  constructor(public readonly ref: string) {
    super(`Reference '${ref}' has already been recorded.`);
    this.name = "DuplicateReference";
  }
}

/** Postgres unique-violation. Distinguished so a replay reads as a conflict, not a server error. */
export function isUniqueViolation(err: unknown): boolean {
  return typeof err === "object" && err !== null && (err as { code?: string }).code === "23505";
}

export async function getBalance(accountId: string): Promise<BalanceRow | null> {
  const rows = await configQuery<Row>(
    `SELECT account_id, balance::text, reserved::text, currency, enabled,
            billing_mode, credit_limit::text
       FROM account_balance WHERE account_id = $1`,
    [accountId]
  );
  const row = rows[0];
  return row
    ? {
        accountId: row.account_id,
        balance: Number(row.balance),
        reserved: Number(row.reserved),
        currency: row.currency,
        enabled: row.enabled,
        billingMode: row.billing_mode === "POSTPAID" ? "POSTPAID" : "PREPAID",
        creditLimit: Number(row.credit_limit),
      }
    : null;
}

/**
 * Switches an account between prepaid and postpaid, and sets the limit in the same statement.
 *
 * <p>One UPDATE rather than two, because the database will not accept the halfway state:
 * `ck_account_balance_limit` requires a prepaid row to carry a zero limit, so setting the mode and
 * the limit separately would fail on whichever went first. Switching back to prepaid therefore
 * clears the limit here rather than leaving a stale figure that reads as if it were in force.
 *
 * <p><strong>This does not touch `balance`.</strong> The gateway is still the only writer of the
 * live figure, exactly as it is for a top-up. A postpaid account's balance simply stops being used.
 *
 * @return false when the account has no balance row, which is a different problem from a failure
 */
export async function setBillingMode(
  accountId: string,
  mode: BillingMode,
  creditLimit: number
): Promise<boolean> {
  const rows = await configQuery<{ account_id: string; billing_mode: string; credit_limit: string }>(
    `UPDATE account_balance
        SET billing_mode = $2,
            credit_limit = CASE WHEN $2 = 'POSTPAID' THEN $3::bigint ELSE 0 END,
            updated_at = now()
      WHERE account_id = $1
      RETURNING account_id, billing_mode, credit_limit::text`,
    [accountId, mode, creditLimit]
  );
  if (!rows.length) {
    return false;
  }
  //no before: the row's previous mode is not read here and a second query for the log alone is not
  //worth a lock. The ledger and the previous audit line between them say what it was
  await auditConfigChange({
    domain: "balance",
    name: accountId,
    action: "update",
    account: accountId,
    after: { billingMode: rows[0].billing_mode, creditLimit: Number(rows[0].credit_limit) },
  });
  return true;
}

/**
 * Creates the balance row, at zero.
 *
 * <p>The missing onboarding step. Until this existed, a `RECHARGE` for an account with no row
 * updated nothing — and the gateway marked it applied anyway, so the money vanished. The gateway
 * side of that is fixed too, but a row that exists is the thing that makes a top-up land at all.
 *
 * <p>`DO NOTHING` rather than `DO UPDATE`: opening an account that is already open must not silently
 * change its currency or re-enable credit somebody switched off.
 */
export async function openBalance(
  accountId: string,
  currency: string,
  enabled: boolean
): Promise<boolean> {
  const rows = await configQuery<{ account_id: string }>(
    `INSERT INTO account_balance (account_id, balance, reserved, currency, enabled)
     VALUES ($1, 0, 0, $2, $3)
     ON CONFLICT (account_id) DO NOTHING
     RETURNING account_id`,
    [accountId.trim(), currency.trim().toUpperCase(), enabled]
  );
  if (!rows.length) {
    return false;
  }
  await auditConfigChange({
    domain: "balance",
    name: accountId.trim(),
    action: "create",
    account: accountId.trim(),
    after: { currency: currency.trim().toUpperCase(), enabled },
  });
  return true;
}

/**
 * Switches credit on or off for an account.
 *
 * <p>Off is a real kill switch, unlike `app_account.enabled`: `RESERVE_SQL` in the gateway carries
 * `AND enabled`, so a disabled account can reserve nothing and stops sending as soon as the block it
 * already holds runs out.
 */
export async function setCreditEnabled(accountId: string, enabled: boolean): Promise<boolean> {
  const rows = await configQuery<{ account_id: string }>(
    `UPDATE account_balance SET enabled = $2, updated_at = now()
      WHERE account_id = $1 RETURNING account_id`,
    [accountId, enabled]
  );
  if (!rows.length) {
    return false;
  }
  await auditConfigChange({
    domain: "balance",
    name: accountId,
    action: enabled ? "enable" : "disable",
    account: accountId,
    after: { enabled },
  });
  return true;
}

/**
 * Records a top-up.
 *
 * <p>**One transaction, and the order matters.** The balance row is ensured first, then the ledger
 * row is written — so the panel cannot create the exact situation the gateway fix exists to survive:
 * a `RECHARGE` pointing at an account that has no balance to credit.
 *
 * <p>The money is not added here. `applied` stays false and the gateway credits it on its next
 * recharge poll, within thirty seconds. That keeps one writer for `balance` and leaves this an audit
 * record, which is what a ledger is for.
 *
 * @param scaled the amount already converted to the stored scale, by `parseAmount` — never by
 *     arithmetic on a float
 * @throws DuplicateReference when this reference has been recorded before
 */
export async function topUp(
  accountId: string,
  scaled: number,
  ref: string,
  note: string | null,
  operator: string
): Promise<void> {
  try {
    await inTransaction(async (client) => {
      //no currency to guess here: an account being topped up for the first time gets a row with a
      //null currency rather than a wrong one, and the panel asks for it on the open-for-credit form
      await client.query(
        `INSERT INTO account_balance (account_id, balance, reserved)
         VALUES ($1, 0, 0) ON CONFLICT (account_id) DO NOTHING`,
        [accountId]
      );
      await client.query(
        `INSERT INTO balance_ledger (account_id, delta, entry_type, ref, note, applied)
         VALUES ($1, $2, 'RECHARGE', $3, $4, FALSE)`,
        [accountId, scaled, ref.trim(), noteWithOperator(note, operator)]
      );
    });
  } catch (err) {
    if (isUniqueViolation(err)) {
      throw new DuplicateReference(ref.trim());
    }
    throw err;
  }
  //the ledger row has the money and the note names the operator; this adds the address and the
  //moment to the one record an operator cannot edit from the panel. `amount` is the stored scale
  await auditConfigChange({
    domain: "balance",
    name: accountId,
    action: "topup",
    account: accountId,
    after: { amount: scaled, ref: ref.trim(), note: note?.trim() || null },
  });
}

/**
 * Who did it, kept with the entry.
 *
 * <p>`balance_ledger` has no `updated_by`, and adding one would be a migration for something the
 * `note` column already holds. A top-up is the one write in this panel that moves money, so the name
 * is not optional.
 */
function noteWithOperator(note: string | null, operator: string): string {
  const text = (note ?? "").trim();
  return text ? `${text} — added by ${operator}` : `Added by ${operator}`;
}

/**
 * Closes a billing period, recording what was invoiced.
 *
 * <p>One `BILL` row, written `applied = TRUE` because there is nothing to apply: the gateway's
 * recharge poll selects only `RECHARGE` and `TRANSFER`, so a `BILL` never moves `balance`. Arrears
 * do not live in that column — `ck_account_balance_nonneg` stays intact and the column keeps its one
 * meaning.
 *
 * <p>`delta` is NEGATIVE, recording consumption. Inert, but signed the way the column's comment says
 * so that anyone reading the ledger reads it correctly.
 *
 * <p><strong>`uq_balance_ledger_ref` is the whole concurrency story.</strong> The reference is
 * deterministic in the account and the period, so two operators closing the same month at the same
 * moment collide on the index and the second gets a {@link DuplicateReference} rather than a second
 * invoice. No lock, no read-then-write window.
 *
 * <p>What this also does, and the reason a postpaid account needs it: `PostpaidAllowance` reads
 * `max(created_at) WHERE entry_type = 'BILL'` as the start of the unbilled window, so closing is
 * what gives the account its headroom back.
 *
 * @param invoiced scaled by 10 000, non-negative, as the statement computed it
 * @throws DuplicateReference when this period has already been closed
 */
export async function closePeriod(
  accountId: string,
  label: string,
  invoiced: number,
  note: string | null,
  operator: string
): Promise<void> {
  try {
    await inTransaction(async (client) => {
      //the row is refused rather than created when the account has no balance row: closing a period
      //for an account nobody has opened would record an invoice against nothing
      const found = await client.query(
        "SELECT 1 FROM account_balance WHERE account_id = $1",
        [accountId]
      );
      if (found.rowCount === 0) {
        throw new NoBalanceRow(accountId);
      }
      await client.query(
        `INSERT INTO balance_ledger (account_id, delta, entry_type, ref, note, applied)
         VALUES ($1, $2, 'BILL', $3, $4, TRUE)`,
        [accountId, -Math.abs(invoiced), billReference(accountId, label), noteWithOperator(note, operator)]
      );
    });
  } catch (err) {
    if (isUniqueViolation(err)) {
      throw new DuplicateReference(billReference(accountId, label));
    }
    throw err;
  }
  await auditConfigChange({
    domain: "statement",
    name: `${accountId} ${label}`,
    action: "close",
    account: accountId,
    after: { period: label, invoiced: Math.abs(invoiced), ref: billReference(accountId, label), note: note?.trim() || null },
  });
}
