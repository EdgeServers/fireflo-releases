import { test } from "node:test";
import assert from "node:assert/strict";
import { idleSummary, splitOutgoing } from "./queue-rows.ts";

interface Row { name: string; depth: number; retries: number; server?: boolean }
const facts = (selected = "") => ({
  depth: (r: Row) => r.depth,
  retries: (r: Row) => r.retries,
  selected: (r: Row) => r.name === selected,
  isServer: (r: Row) => !!r.server,
});

const ROWS: Row[] = [
  { name: "a", depth: 0, retries: 0 },
  { name: "b", depth: 310, retries: 0 },
  { name: "c", depth: 42, retries: 0 },
  { name: "d", depth: 5, retries: 38 },
  { name: "e", depth: 0, retries: 0 },
  { name: "srv", depth: 0, retries: 0, server: true },
];

test("retries outrank depth, then the deepest first; the idle keep their order", () => {
  const { active, idle } = splitOutgoing(ROWS, facts());
  assert.deepEqual(active.map((r) => r.name), ["d", "b", "c"]);
  assert.deepEqual(idle.map((r) => r.name), ["a", "e", "srv"]);
});

test("a selected idle row stays listed, so it never vanishes from under the operator", () => {
  const { active, idle } = splitOutgoing(ROWS, facts("e"));
  assert.ok(active.some((r) => r.name === "e"));
  assert.ok(!idle.some((r) => r.name === "e"));
});

test("the folded line names each kind only when there is one", () => {
  const isServer = (r: Row) => !!r.server;
  assert.equal(idleSummary(ROWS.filter((r) => !r.depth && !r.retries), isServer, false), "2 idle vendors, 1 idle server");
  assert.equal(idleSummary([ROWS[0]], isServer, false), "1 idle vendor");
  assert.equal(idleSummary(ROWS.filter((r) => !r.depth && !r.retries), isServer, true), "All 2 vendors and 1 server are idle");
  assert.equal(idleSummary([ROWS[5]], isServer, true), "The server is idle");
});
