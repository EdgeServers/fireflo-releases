import { strict as assert } from "node:assert";
import { test } from "node:test";

import {
  customPeriod,
  monthOf,
  monthPeriod,
  periodTooLong,
  recentMonths,
  type BillingPeriod,
} from "./billing-period.ts";

function period(value: string): BillingPeriod {
  const p = monthPeriod(value);
  assert.ok(p, `${value} should be a month`);
  return p;
}

/** Whole days, which is what the calendar questions below are actually about. */
function days(p: BillingPeriod): number {
  return Math.round((p.until.getTime() - p.since.getTime()) / 86_400_000);
}

test("a month runs from its 1st to the next 1st, so February needs no special case", () => {
  assert.equal(days(period("2026-01")), 31);
  assert.equal(days(period("2026-02")), 28);
  assert.equal(days(period("2026-04")), 30);
});

test("a leap February is 29 days, with no leap-year arithmetic anywhere", () => {
  //2028 is a leap year; 2100 is not, despite being divisible by four. Both fall out of "the 1st of
  //the next month" for free, which is the whole reason the period is built that way
  assert.equal(days(period("2028-02")), 29);
  assert.equal(days(period("2100-02")), 28);
});

test("December rolls into January of the next year", () => {
  const december = period("2026-12");
  assert.equal(december.until.getFullYear(), 2027);
  assert.equal(december.until.getMonth(), 0);
  assert.equal(december.until.getDate(), 1);
  assert.equal(days(december), 31);
});

test("a month begins at local midnight, not UTC midnight", () => {
  //the failure this is really about: new Date("2026-08-01") is UTC midnight, which in Asia/Kolkata
  //is 05:30 on the 1st -- so five and a half hours of billable traffic would fall off the front of
  //every invoice, every month, with nothing anywhere saying so
  const august = period("2026-08");
  assert.equal(august.since.getHours(), 0);
  assert.equal(august.since.getMinutes(), 0);
  assert.equal(august.since.getDate(), 1);
  assert.equal(august.until.getHours(), 0);
});

test("adjacent months meet exactly, with nothing in the gap and nothing counted twice", () => {
  //the boundary property the whole statement rests on. Half-open means the instant one period ends
  //is the instant the next begins, so a message sent at that instant belongs to exactly one of them
  const january = period("2026-01");
  const february = period("2026-02");
  assert.equal(january.until.getTime(), february.since.getTime());
});

test("a month that does not exist is not a month", () => {
  assert.equal(monthPeriod("2026-13"), null);
  assert.equal(monthPeriod("2026-00"), null);
  assert.equal(monthPeriod("2026-1"), null);
  assert.equal(monthPeriod("2026"), null);
  assert.equal(monthPeriod("august"), null);
  assert.equal(monthPeriod(""), null);
});

test("a custom period includes the last day the customer typed", () => {
  //typed inclusive, sent half-open. A customer asking for the 1st to the 3rd means three whole days
  const result = customPeriod("2026-08-01", "2026-08-03");
  assert.ok(typeof result !== "string", result as string);
  assert.equal(days(result), 3);
  assert.equal(result.until.getDate(), 4);
  assert.equal(result.label, "2026-08-01..2026-08-03");
});

test("a custom period is refused in the same words every other range is", () => {
  assert.match(customPeriod("2026-08-03", "2026-08-01") as string, /on or before/);
  assert.match(customPeriod("", "2026-08-01") as string, /both a From and a To/);
  assert.match(customPeriod("2026-02-31", "2026-03-01") as string, /not a valid date/);
  assert.match(customPeriod("2026-01-01", "2026-12-31") as string, /at most 92/);
});

test("a calendar month is never too long, and a long custom window is", () => {
  assert.equal(periodTooLong(period("2026-01")), null);
  assert.equal(periodTooLong(period("2026-02")), null);
  const long = { since: new Date(2026, 0, 1), until: new Date(2026, 11, 1), label: "long" };
  assert.match(periodTooLong(long) ?? "", /at most 92/);
});

test("monthOf is the local month, and round-trips through monthPeriod", () => {
  //the pair has to agree: a picker offers monthOf, and the route parses it back with monthPeriod
  const at = new Date(2026, 7, 19, 23, 45);
  assert.equal(monthOf(at), "2026-08");
  assert.equal(period(monthOf(at)).since.getMonth(), 7);
});

test("recentMonths walks backwards across a year boundary", () => {
  assert.deepEqual(recentMonths(new Date(2026, 1, 15), 4), ["2026-02", "2026-01", "2025-12", "2025-11"]);
});

test("recentMonths does not skip a month when today is the 31st", () => {
  //the classic: setMonth on the 31st of March lands in May, because April has no 31st. The cursor
  //starts on the 1st for exactly this reason, and this is the test that keeps it there
  assert.deepEqual(recentMonths(new Date(2026, 2, 31), 3), ["2026-03", "2026-02", "2026-01"]);
});
