import type { CdrRow } from "./cdr-request";
//with the extension, because `node --test` runs this module directly and does not read tsconfig
//paths or resolve extensionless specifiers. The type-only import above is erased and needs neither
import { csv } from "./csv.ts";

/**
 * What a call-record CSV contains, and how each row becomes a line.
 *
 * <p>A pure move out of `exports.ts` when a second export appeared. **The header array is unchanged,
 * in order, deliberately** -- a reviewer should be able to diff it and find nothing, and
 * `cdr-export.test.ts` pins it by value. Whoever imports this into a spreadsheet builds formulas
 * against column letters, so reordering breaks them silently and new columns go on the end.
 *
 * <p>The private `csv()` that used to live beside it is gone: `lib/csv.ts` had an identical copy,
 * and two implementations of a formula-injection guard is one more than anybody wants to audit.
 */


/**
 * Column order, fixed.
 *
 * <p>Whoever imports this into a spreadsheet builds formulas against column letters. Reordering
 * these later breaks those silently, so new columns go on the end.
 */
export const HEADERS = [
  "submitted_at",
  "gateway_msg_id",
  "part_no",
  "part_count",
  "retry_count",
  "account_id",
  "system_id",
  "product",
  "ingress",
  "vendor",
  "source_addr",
  "dest_addr",
  "mcc",
  "mnc",
  "operator_msg_id",
  "final_state",
  "dlr_state",
  "err_code",
  "final_at",
  "cost",
  "price",
  "margin",
  "currency",
  //appended, in this order, because whoever built a formula against column Y must still find margin
  //there. accepted_at was always selected and never written out, which was simply an omission
  "accepted_at",
  "in_gateway",
  "dcs",
  "msg_type",
  "cost_rate",
  "cost_units",
  "price_rate",
  "billed_units",
  "margin_pct",
  "margin_status",
  "cost_rule_id",
  "price_rule_id",
  //last, because these are the only unbounded fields and a spreadsheet is happier with them on the
  //end. Appended in this order for the same reason the block above is: a formula written against
  //column AJ must keep finding tlvs there
  "tlvs",
  "tlvs_received",
  "tlvs_sent",
] as const;

export function toCsvLine(row: CdrRow): string {
  return (
    [
      row.submittedAt,
      row.gatewayMsgId,
      row.partNo,
      row.partCount,
      row.retryCount,
      row.accountId,
      row.systemId,
      row.product,
      row.ingress,
      row.vendor,
      row.sourceAddr,
      row.destAddr,
      row.mcc,
      row.mnc,
      row.operatorMsgId,
      //PENDING written out rather than left blank: an empty cell reads as missing data, and 93% of
      //rows currently have no receipt
      row.finalState ?? "PENDING",
      row.dlrState,
      row.errCode,
      row.finalAt,
      money(row.cost),
      money(row.price),
      money(row.margin),
      row.currency,
      row.acceptedAt,
      row.inGateway,
      row.dcs,
      row.msgType,
      money(row.costRate),
      row.costUnits,
      money(row.priceRate),
      row.billedUnits,
      row.marginPct,
      row.marginStatus,
      row.costRuleId,
      row.priceRuleId,
      row.tlvs ?? null,
      row.tlvsReceived ?? null,
      row.tlvsSent ?? null,
    ]
      .map(csv)
      .join(",") + "\n"
  );
}

/**
 * Amounts are BIGINT scaled by 10 000. Written as a decimal here because a spreadsheet will sum
 * this column.
 *
 * <p>**Four places, always, whatever `smsg.money.scale` says.** That setting is a display choice for
 * a total somebody reads; a CSV column is a calculation surface, and rounding every row before a
 * spreadsheet adds them up introduces drift that grows with the row count. The panel's own totals
 * and this file are allowed to differ in the last places, and the reconciliation people do is
 * against this one.
 */
function money(value: number | null): string {
  return value == null ? "" : (value / 10_000).toFixed(4);
}

/**
 * Names the job, the manifest and the file. Here rather than in the route because two routes need
 * it — the one that queues an export and the one that hands it back — and they must not disagree.
 */
export const CDR_EXPORT_KIND = "cdrs";
