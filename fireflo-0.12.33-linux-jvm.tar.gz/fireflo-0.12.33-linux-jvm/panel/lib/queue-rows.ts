/**
 * Which outgoing queues the Queues page lists, and in what order.
 *
 * <p>The strip used to list every vendor and server, so each one added a row and the card grew
 * without limit -- twenty vendors made it several screens tall, and the Broker and Router tiles beside
 * it stopped lining up with anything. Only the queues with something in them are listed now; the idle
 * rest fold into one line. No React and no database, so the rule can be tested on its own.
 */

/** How a row's figures are read. Accessors, so this does not need the page's own row type. */
export interface RowFacts<T> {
  depth: (row: T) => number;
  retries: (row: T) => number;
  /** Whether the row's queue, or its retries queue, is the one open below the strip. */
  selected: (row: T) => boolean;
  isServer: (row: T) => boolean;
}

/**
 * Splits rows into the ones worth a line and the idle rest.
 *
 * <p>Active: something waiting, something scheduled to retry, or open below -- a selected row never
 * vanishes from under the operator. Retries first, because a queue retrying is one that is failing;
 * then the deepest. Ties keep the order given, which is the gateway's, vendors before servers.
 */
export function splitOutgoing<T>(rows: readonly T[], facts: RowFacts<T>): { active: T[]; idle: T[] } {
  const active: { row: T; at: number }[] = [];
  const idle: T[] = [];
  rows.forEach((row, at) => {
    if (facts.depth(row) > 0 || facts.retries(row) > 0 || facts.selected(row)) {
      active.push({ row, at });
    } else {
      idle.push(row);
    }
  });
  active.sort((a, b) =>
    Number(facts.retries(b.row) > 0) - Number(facts.retries(a.row) > 0) ||
    facts.depth(b.row) - facts.depth(a.row) ||
    a.at - b.at);
  return { active: active.map((a) => a.row), idle };
}

/**
 * The folded line's words: "14 idle vendors, 1 idle server", or "All 18 vendors and 2 servers are
 * idle" when nothing is active.
 */
export function idleSummary<T>(idle: readonly T[], isServer: (row: T) => boolean, allIdle: boolean): string {
  const servers = idle.filter(isServer).length;
  const vendors = idle.length - servers;
  const v = (n: number) => `${n} vendor${n === 1 ? "" : "s"}`;
  const s = (n: number) => `${n} server${n === 1 ? "" : "s"}`;
  if (allIdle) {
    const what = [vendors ? v(vendors) : "", servers ? s(servers) : ""].filter(Boolean).join(" and ");
    return idle.length === 1 ? `The ${what.replace(/^1 /, "")} is idle` : `All ${what} are idle`;
  }
  return [vendors ? `${vendors} idle vendor${vendors === 1 ? "" : "s"}` : "",
    servers ? `${servers} idle server${servers === 1 ? "" : "s"}` : ""].filter(Boolean).join(", ");
}
