import { SMPP_SYSTEM_TYPE_MAX } from "@/lib/rate-types";

/**
 * A product: the tariff a customer's traffic is sold under.
 *
 * <p>It reaches the gateway as the `system_type` on an SMPP bind, falling back to the credential's
 * product when the bind carries none. So a product is not something the panel assigns — it is a
 * string a customer sends, and the catalogue exists to say what that string is supposed to mean.
 *
 * <p>Zero database imports, so a client component can hold these types. See the note at the top of
 * `rate-types.ts` for what happens otherwise.
 */

export interface Product {
  name: string;
  label: string | null;
  description: string | null;
  enabled: boolean;
  /**
   * Whether traffic sold under this product is checked against the sender ID and content
   * whitelists. True — the column default — is the checked, unsurprising state.
   *
   * <p>The one field on a product the gateway actually reads. False exempts every account on this
   * product whatever their own policy rows say, which is the point: "this traffic does not need a
   * registered sender ID" is a property of what is being sold, not of each customer buying it.
   */
  whitelistEnabled: boolean;
}

export interface ProductSummary extends Product {
  /** Rate rules restricted to this product. Rules with no product price it too, and are not counted. */
  ruleCount: number;
  scopeCount: number;
  credentialCount: number;
  updatedAt: string | null;
}

export interface ProductInput {
  name: string;
  label?: string | null;
  description?: string | null;
  enabled: boolean;
  whitelistEnabled: boolean;
}

/**
 * How long a generated product code may be.
 *
 * <p>Eight, and not the twelve SMPP would allow, because this is a string a customer types into
 * their own client configuration and reads back off an invoice. Four characters of headroom under
 * the protocol limit also leaves room for a hand-picked override.
 *
 * <p>A convention, not a constraint: there is no CHECK on the column, and there should not be. The
 * real limit binds SMPP only — an HTTP-only product resolves through `credential.product()` with no
 * limit at all — so encoding 8 in the schema would state a preference as a fact.
 */
export const PRODUCT_SLUG_MAX = 8;

export const SLUG_PATTERN = /^[a-z0-9][a-z0-9-]*$/;

/** Printable ASCII, since this arrives over the wire and is compared byte for byte. */
const NAME_PATTERN = /^[\x20-\x7E]{1,64}$/;

/**
 * The code a display name derives to, before collision handling.
 *
 * <p>Pure and client-safe, so the form can show the result as the operator types. Uniqueness is
 * decided on the server, which is the only place that can.
 *
 * <p>The NFKD step matters more than it looks: without it `Prémium` loses the accented character
 * entirely and yields `prmium`, which is a code an operator would read three times without seeing
 * what was wrong.
 *
 * @returns "" when nothing usable remains, which callers must treat as an error rather than
 *     substituting something generated — a code nobody can read back over the phone is worse than
 *     being asked to type one
 */
export function slugify(label: string): string {
  const ascii = (label ?? "")
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  //truncating can leave a trailing separator, so trim again after
  return ascii.slice(0, PRODUCT_SLUG_MAX).replace(/-+$/g, "");
}

/**
 * @param isNew so the rules introduced with generated codes cannot make an existing row unsavable
 * @returns why this product cannot be saved, or null
 */
export function validateProduct(input: ProductInput, isNew: boolean): string | null {
  const name = input.name ?? "";
  if (!name) {
    return isNew
      ? "A product needs a code. It is derived from the display name, and it is the exact string a "
        + "customer's bind sends as system_type."
      : "A product needs a name.";
  }
  if (name !== name.trim()) {
    return "A product code cannot begin or end with a space. The gateway compares it exactly, so a "
      + "trailing space produces a product that nothing can ever select and no error will explain.";
  }

  if (isNew) {
    if (!input.label?.trim()) {
      return "A product needs a display name. The code customers send is derived from it.";
    }
    if (name.length > PRODUCT_SLUG_MAX) {
      return `'${name}' is ${name.length} characters. A product code is at most ${PRODUCT_SLUG_MAX}: `
        + "it is what a customer types into their own SMPP client and reads back off an invoice.";
    }
    if (!SLUG_PATTERN.test(name)) {
      return "A product code is lowercase letters, digits and hyphens, starting with a letter or "
        + "digit. This value arrives from a customer's bind and is compared byte for byte, so mixed "
        + "case is the likeliest transcription error — and it produces no error, only the wrong price.";
    }
    return null;
  }

  //an existing product may hold anything that was typed before codes were generated
  if (!NAME_PATTERN.test(name)) {
    return "A product name must be 1-64 printable characters. It travels over SMPP as a fixed-width "
      + "C string, so anything outside plain ASCII arrives as something else.";
  }
  return null;
}

/**
 * Worth saying, not worth blocking.
 *
 * @param isNew existing products get a different sentence — their name is history, not a mistake
 */
export function productWarnings(input: ProductInput, isNew: boolean): string[] {
  const warnings: string[] = [];
  const name = input.name ?? "";
  const label = input.label ?? "";

  if (isNew) {
    //silent truncation of a customer-facing identifier is exactly the failure this feature exists to
    //avoid, so it is said out loud rather than left for the operator to notice
    const ideal = slugify(label);
    if (name && label && name === ideal && ideal !== label.toLowerCase().replace(/[^a-z0-9]+/g, "-")) {
      warnings.push(`The code is '${name}', not '${label}'. That is the string a customer has to `
        + "send; the display name is only for this panel.");
    }
    if (!label.trim()) {
      warnings.push("Without a display name, this product shows as its code everywhere it appears.");
    }
    return warnings;
  }

  if (name.length > PRODUCT_SLUG_MAX) {
    warnings.push(`'${name}' predates generated product codes. It cannot be changed — every rate `
      + "rule, credential and past call record compares against this exact string and none of them "
      + "would follow a rename. To move to a shorter code: create it, re-point the rules, then "
      + "delete this one.");
  }
  if (name.length > SMPP_SYSTEM_TYPE_MAX) {
    warnings.push(`'${name}' is ${name.length} characters. An SMPP bind selects a product through `
      + `system_type, which holds at most ${SMPP_SYSTEM_TYPE_MAX}, so a customer told to bind with `
      + "this gets a truncated one instead. Only HTTP callers can reach it as written.");
  }
  if (name && !SLUG_PATTERN.test(name)) {
    warnings.push("This code contains characters a generated one would not. It is legal, but the "
      + "value arrives from a customer's bind and a mismatch produces no error — only the wrong price.");
  }
  if (!input.label?.trim()) {
    warnings.push("Without a display name, this product shows as its code everywhere it appears.");
  }
  return warnings;
}
