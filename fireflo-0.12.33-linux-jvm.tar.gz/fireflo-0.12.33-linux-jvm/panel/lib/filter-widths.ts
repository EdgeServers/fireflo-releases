/**
 * How wide a filter field is, decided by what goes in it rather than per screen.
 *
 * <p>The three filter bars — CDRs, refusals and the customer's messages — are the same shape: a
 * Card, a form, and a `flex flex-wrap items-end gap-3` row of {@code Field}s. What they did not
 * share was the widths, so the same field was a different size depending on which page you were on:
 * Period was `w-36` on two screens and `w-40` on the third, To number was `w-44` here and `w-40`
 * there, Message id `w-56` and `w-52`. Six widths across three files, none of them wrong on its own
 * and no two agreeing.
 *
 * <p>They are named for their contents because that is the only thing that should decide them. A
 * period select holds "Last 24 hours"; a phone number holds fifteen digits; a message id holds a
 * long opaque string. Reach for the one that describes the value, and a fourth filter bar comes out
 * consistent without anybody comparing it to the other three.
 *
 * <p>Pixel figures are at the browser's default 16px root — `app/globals.css` sets no root
 * font-size, so a reader who has asked for larger text gets proportionally wider fields, which is
 * the intent. Do not convert these to px.
 */
export const FILTER_WIDTH = {
  /** A short select: a period, a direction. "Last 24 hours" fits without truncating. */
  select: "w-40",
  /** A phone number, national or international. 176px holds +COUNTRY plus fifteen digits. */
  phone: "w-44",
  /** An account or login picker, sized to the longest label a catalogue realistically holds. */
  account: "w-48",
  /** A select whose options are sentences — an outcome, a refusal reason, an ingress. */
  choice: "w-52",
  /** Free text: a message id, body search, "anything". The widest, and the only one that scrolls. */
  text: "w-56",
} as const;
