import { strict as assert } from "node:assert";
import { test } from "node:test";
import { appendTps, TPS_HISTORY_DEPTH, type TpsHistory } from "./tps-history.ts";
import type { Health, HealthWorker } from "./health-types.ts";

function snapshot(at: string, workers: Partial<HealthWorker>[]): Health {
  return {
    observed_at: at,
    router_queue: 0,
    awaiting_receipt: 0,
    dlr_store_persistent: false,
    cdr: { enabled: false },
    workers: workers.map((w) => ({
      name: "smppclient.v1", type: "smppclient", accepting: true, paused: false,
      suspended_manually: false, suspended_automatically: false, queue_depth: 0, ...w,
    })),
  } as Health;
}

test("each snapshot appends one sample per worker", () => {
  let history: TpsHistory = new Map();
  history = appendTps(history, snapshot("t1", [{ tps_measured: 10 }]));
  history = appendTps(history, snapshot("t2", [{ tps_measured: 20 }]));
  history = appendTps(history, snapshot("t3", [{ tps_measured: 0 }]));
  assert.deepEqual(history.get("smppclient.v1"), [10, 20, 0]);
});

test("a worker reporting no rate leaves a gap rather than a zero", () => {
  //zero means "bound and sending nothing", which is a real reading. Absent means the gateway did
  //not measure -- plotting that as zero would draw a cliff that never happened
  const history = appendTps(new Map(), snapshot("t1", [{ tps_measured: undefined }]));
  assert.deepEqual(history.get("smppclient.v1"), [null]);
});

test("history is bounded, keeping the most recent samples", () => {
  let history: TpsHistory = new Map();
  for (let i = 0; i < TPS_HISTORY_DEPTH + 8; i++) {
    history = appendTps(history, snapshot(`t${i}`, [{ tps_measured: i }]));
  }
  const kept = history.get("smppclient.v1")!;
  assert.equal(kept.length, TPS_HISTORY_DEPTH);
  assert.equal(kept.at(-1), TPS_HISTORY_DEPTH + 7);
  assert.equal(kept[0], 8);
});

test("a worker missing from one snapshot keeps its tail", () => {
  //a gateway that briefly stops reporting one worker should leave a gap, not erase two minutes
  let history: TpsHistory = new Map();
  history = appendTps(history, snapshot("t1", [
    { name: "smppclient.a", tps_measured: 5 },
    { name: "smppclient.b", tps_measured: 9 },
  ]));
  history = appendTps(history, snapshot("t2", [{ name: "smppclient.a", tps_measured: 6 }]));
  assert.deepEqual(history.get("smppclient.a"), [5, 6]);
  assert.deepEqual(history.get("smppclient.b"), [9]);
});

test("the previous map is not mutated, so React sees a new reference", () => {
  const before = appendTps(new Map(), snapshot("t1", [{ tps_measured: 1 }]));
  const after = appendTps(before, snapshot("t2", [{ tps_measured: 2 }]));
  assert.notEqual(before, after);
  assert.deepEqual(before.get("smppclient.v1"), [1]);
  assert.deepEqual(after.get("smppclient.v1"), [1, 2]);
});

test("workers are tracked by their full name, which is the health snapshot's key", () => {
  //'smppclient.vendor1', not 'vendor1' -- see trafficKey, which exists for this mismatch
  const history = appendTps(new Map(), snapshot("t1", [
    { name: "smppclient.vendor1", tps_measured: 3 },
  ]));
  assert.equal(history.get("smppclient.vendor1")?.length, 1);
  assert.equal(history.get("vendor1"), undefined);
});
