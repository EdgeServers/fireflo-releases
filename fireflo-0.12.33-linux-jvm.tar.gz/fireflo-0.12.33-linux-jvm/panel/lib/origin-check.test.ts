import { test } from "node:test";
import assert from "node:assert/strict";
import { crossOriginRefusal } from "./origin-check.ts";

/**
 * The Origin check `proxy.ts` runs on every mutating control and portal request (CP-S9). The cases
 * are the ones a deployment actually produces: a same-origin write, a forged one, a curl, a panel
 * whose AUTH_URL is wrong, and a panel with no AUTH_URL behind a proxy.
 */

const panel = "https://panel.example.com";

test("a same-origin POST with AUTH_URL set is allowed", () => {
  assert.equal(crossOriginRefusal({ method: "POST", origin: panel, host: "panel.example.com", authUrl: panel }), null);
  assert.equal(crossOriginRefusal({ method: "PUT", origin: "HTTPS://Panel.Example.com", host: "x", authUrl: panel }), null, "origins compare case-insensitively");
  assert.equal(crossOriginRefusal({ method: "DELETE", origin: panel, host: "panel.example.com", authUrl: `${panel}/` }), null, "a trailing slash on AUTH_URL is not a different origin");
});

test("a POST from another origin is refused with a sentence naming both sides", () => {
  const why = crossOriginRefusal({ method: "POST", origin: "https://evil.example", host: "panel.example.com", authUrl: panel });
  assert.ok(why, "refused");
  assert.match(why!, /https:\/\/evil\.example/);
  assert.match(why!, /https:\/\/panel\.example\.com/);
  assert.match(why!, /AUTH_URL/);
});

test("a request with no Origin header is never refused here", () => {
  assert.equal(crossOriginRefusal({ method: "POST", origin: null, host: "panel.example.com", authUrl: panel }), null, "curl and scripts carry no Origin; the session check decides them");
  assert.equal(crossOriginRefusal({ method: "POST", origin: "", host: "panel.example.com", authUrl: panel }), null);
});

test("reads are never refused, whatever their Origin", () => {
  for (const method of ["GET", "HEAD", "OPTIONS", "get"]) {
    assert.equal(crossOriginRefusal({ method, origin: "https://evil.example", host: "panel.example.com", authUrl: panel }), null, method);
  }
});

test("the method is matched case-insensitively", () => {
  assert.ok(crossOriginRefusal({ method: "post", origin: "https://evil.example", host: "panel.example.com", authUrl: panel }));
  assert.ok(crossOriginRefusal({ method: "Patch", origin: "https://evil.example", host: "panel.example.com", authUrl: panel }));
});

test("a wrong AUTH_URL refuses the browser's own writes and says so", () => {
  //the deployment mistake this check makes visible: the panel is reached at one address and
  //AUTH_URL names another. The sentence tells the operator which variable to fix
  const why = crossOriginRefusal({ method: "POST", origin: "http://10.0.0.5:3000", host: "10.0.0.5:3000", authUrl: panel });
  assert.ok(why);
  assert.match(why!, /http:\/\/10\.0\.0\.5:3000/);
  assert.match(why!, /set AUTH_URL to that in panel\.env/);
});

test("without AUTH_URL the request's own Host decides, scheme aside", () => {
  assert.equal(crossOriginRefusal({ method: "POST", origin: "http://localhost:3000", host: "localhost:3000" }), null);
  assert.equal(crossOriginRefusal({ method: "POST", origin: "https://panel.example.com", host: "panel.example.com" }), null, "https in the browser, plain http behind the proxy: the host still matches");
  assert.equal(crossOriginRefusal({ method: "POST", origin: "http://LOCALHOST:3000", host: "localhost:3000" }), null);
  const why = crossOriginRefusal({ method: "POST", origin: "http://evil.example", host: "localhost:3000" });
  assert.ok(why);
  assert.match(why!, /localhost:3000/);
  assert.match(why!, /Set AUTH_URL/);
});

test("without AUTH_URL, X-Forwarded-Host is accepted as the host too", () => {
  assert.equal(
    crossOriginRefusal({ method: "POST", origin: "https://panel.example.com", host: "127.0.0.1:3000", forwardedHost: "panel.example.com" }),
    null
  );
});

test("an AUTH_URL that is not a URL falls back to the Host comparison rather than refusing everything", () => {
  assert.equal(crossOriginRefusal({ method: "POST", origin: "http://localhost:3000", host: "localhost:3000", authUrl: "not a url" }), null);
});

test("an Origin that is not a web origin is refused", () => {
  assert.ok(crossOriginRefusal({ method: "POST", origin: "null", host: "panel.example.com", authUrl: panel }), "a sandboxed frame");
  assert.ok(crossOriginRefusal({ method: "POST", origin: "file://", host: "panel.example.com", authUrl: panel }));
  assert.ok(crossOriginRefusal({ method: "POST", origin: "garbage", host: "panel.example.com", authUrl: panel }));
});

test("a different port is a different origin", () => {
  assert.ok(crossOriginRefusal({ method: "POST", origin: "https://panel.example.com:8443", host: "panel.example.com", authUrl: panel }));
  assert.ok(crossOriginRefusal({ method: "POST", origin: "http://localhost:3001", host: "localhost:3000" }));
});
