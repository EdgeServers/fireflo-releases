/**
 * The SMPP test tool's shapes, shared by its routes and its modal. See lib/smpp-test.ts.
 */
export type BindKind = "trx" | "tx" | "rx";

export interface SmppTestEvent {
  seq: number;
  at: string;
  /** in: from the gateway; out: from this tool; note: the tool's own line. */
  dir: "in" | "out" | "note";
  /** For a PDU, its command; for a note, null. */
  command: string | null;
  /** "receipt", "mo", "error" or null, for colouring the line. */
  tone: "receipt" | "mo" | "error" | "ok" | null;
  text: string;
}

export interface SmppTestState {
  id: string;
  systemId: string;
  host: string;
  port: number;
  bindType: BindKind;
  bound: boolean;
  /** Why it is no longer bound, once it is not. */
  closedBecause: string | null;
  events: SmppTestEvent[];
  next: number;
}

export interface SmppSubmitResult {
  status: number;
  statusText: string;
  messageId: string | null;
}
