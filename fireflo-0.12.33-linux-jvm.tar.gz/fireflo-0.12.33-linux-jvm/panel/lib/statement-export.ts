/**
 * A statement as a file, for the operator side.
 *
 * <p>Mirrors `rejected-export.ts` exactly: a fixed append-only header list, one `toCsvLine` that
 * goes through `csv()`, and a stable `kind` that names the file. Reusing the shape rather than
 * inventing one means the formula-injection guard, the quoting rules and the retention sweep are
 * already right here.
 *
 * <p><strong>Both the scaled integer and the decimal string, for every amount.</strong> The rule
 * `rejected-export.ts` established: a CSV is a calculation surface. The decimal is what a person
 * reads and what goes on an invoice; the integer is what reconciles exactly against the database
 * with no float in the path, which is the column to sum if the two ever disagree.
 */

import { csv } from "./csv.ts";
import { MONEY_SCALE } from "./format.ts";
import type { StatementRow } from "./statement-queries";

/** Stable across releases: it names the file and identifies the job. */
export const KIND = "statement";

/**
 * Column order, fixed and append-only.
 *
 * <p>Whoever imports this into a spreadsheet writes formulas against column letters. Reordering
 * breaks those silently, so anything new goes on the end.
 *
 * <p>`price` and `price_scaled` sit together so a reader can see they are the same number twice.
 */
export const HEADERS = [
  "submitted_at",
  "gateway_msg_id",
  "product",
  "source_addr",
  "dest_addr",
  "parts",
  "outcome",
  "billed",
  "price",
  "price_scaled",
] as const;

/**
 * The scaled integer as a decimal string, without arithmetic.
 *
 * <p>`scaled / 10000` is a float division and `(1155 / 10000).toFixed(4)` is not reliably `0.1155`
 * across every value. Slicing the digits cannot be inexact, which is the same rule `parseAmount`
 * follows in the other direction.
 */
function decimal(scaled: number): string {
  const places = String(MONEY_SCALE).length - 1;
  const negative = scaled < 0;
  const digits = String(Math.abs(scaled)).padStart(places + 1, "0");
  const whole = digits.slice(0, digits.length - places);
  const fraction = digits.slice(digits.length - places);
  return `${negative ? "-" : ""}${whole}.${fraction}`;
}

export function toCsvLine(row: StatementRow): string {
  return (
    [
      row.submittedAt,
      row.gatewayMsgId,
      row.product,
      row.from,
      row.to,
      row.parts,
      row.outcome,
      //true/false rather than blank, because the question is "was this charged" and an empty cell
      //reads as unknown. A message can be sent and not billed -- unrated traffic, and refunds
      row.price !== null,
      row.price === null ? null : decimal(row.price),
      //the raw column, so a total computed in the spreadsheet can be checked against the database
      //without a decimal conversion sitting between the two
      row.price,
    ]
      .map(csv)
      .join(",") + "\n"
  );
}

/**
 * What the file is called.
 *
 * <p>Account and period in the name, because a person downloading twelve of these needs to tell
 * them apart in a downloads folder six months later.
 */
export function statementFileName(accountId: string, label: string): string {
  const safe = accountId.replace(/[^A-Za-z0-9._-]/g, "_");
  return `statement-${safe}-${label}.csv`;
}
