import type { SecurityEvent, SecuritySurface } from "./security-events.ts";

/**
 * The Security page's two views of the same refusals: who was doing it, and when.
 *
 * <p>Pure, like security-events.ts, so the rules are testable without a page.
 */

export const SURFACES: readonly SecuritySurface[] = ["smpp", "rest", "panel", "portal"];

/**
 * An address as a person reads it: an IPv4 client seen through an IPv6 socket loses its
 * {@code ::ffff:} prefix, so 127.0.0.1 and ::ffff:127.0.0.1 are one row rather than two.
 */
export function displayIp(ip: string): string {
  return ip.replace(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/i, "$1");
}

/** Everything one address did in the window. */
export interface AddressSummary {
  ip: string;
  attempts: number;
  bySurface: Record<SecuritySurface, number>;
  /** The names it tried, most-tried first. Attempted names, never identities. */
  triedAs: string[];
  firstAt: string | null;
  lastAt: string | null;
}

/**
 * One row per address, the busiest first, then the most recent.
 *
 * <p>An attack is one address working through names, and as one row per attempt it was the same
 * line fifty times with the one thing worth knowing -- how many, and which names -- left to count.
 */
export function groupByAddress(events: readonly SecurityEvent[]): AddressSummary[] {
  const groups = new Map<string, AddressSummary & { names: Map<string, number> }>();
  for (const e of events) {
    const ip = displayIp(e.ip);
    let g = groups.get(ip);
    if (!g) {
      g = {
        ip,
        attempts: 0,
        bySurface: { smpp: 0, rest: 0, panel: 0, portal: 0 },
        triedAs: [],
        firstAt: null,
        lastAt: null,
        names: new Map(),
      };
      groups.set(ip, g);
    }
    g.attempts += 1;
    g.bySurface[e.surface] += 1;
    if (e.triedAs) {
      g.names.set(e.triedAs, (g.names.get(e.triedAs) ?? 0) + 1);
    }
    if (e.at) {
      if (!g.firstAt || e.at < g.firstAt) {
        g.firstAt = e.at;
      }
      if (!g.lastAt || e.at > g.lastAt) {
        g.lastAt = e.at;
      }
    }
  }
  return [...groups.values()]
    .map(({ names, ...g }) => ({
      ...g,
      triedAs: [...names.entries()].sort((a, b) => b[1] - a[1]).map(([name]) => name),
    }))
    .sort((a, b) => b.attempts - a.attempts || (b.lastAt ?? "").localeCompare(a.lastAt ?? ""));
}

/** One bar of the chart: a slice of time, counted per surface. */
export interface Bucket {
  /** ISO start of the slice. */
  start: string;
  total: number;
  bySurface: Record<SecuritySurface, number>;
}

/**
 * Refusals per slice across the whole window, empty slices included, so a quiet stretch reads as
 * quiet rather than as missing. Hourly up to two days, daily beyond, so thirty days is thirty bars
 * and not seven hundred.
 *
 * @param windowHours the page's range
 * @param now the moment the data was read; the window ends here
 */
export function bucketsFor(events: readonly SecurityEvent[], windowHours: number, now: number): Bucket[] {
  const step = windowHours <= 48 ? 3_600_000 : 86_400_000;
  const floor = (t: number) => {
    if (step === 3_600_000) {
      return Math.floor(t / step) * step;
    }
    //days in local time, so "Tuesday" is the operator's Tuesday
    const d = new Date(t);
    d.setHours(0, 0, 0, 0);
    return d.getTime();
  };
  const first = floor(now - windowHours * 3_600_000 + 1);
  const last = floor(now);
  const buckets = new Map<number, Bucket>();
  for (let t = first; t <= last; t = floor(t + step + (step === 86_400_000 ? 3_600_000 : 0))) {
    buckets.set(t, { start: new Date(t).toISOString(), total: 0, bySurface: { smpp: 0, rest: 0, panel: 0, portal: 0 } });
    if (buckets.size > 24 * 31) {
      break;
    }
  }
  for (const e of events) {
    const at = e.at ? Date.parse(e.at) : Number.NaN;
    if (!Number.isFinite(at)) {
      continue;
    }
    const b = buckets.get(floor(at));
    if (b) {
      b.total += 1;
      b.bySurface[e.surface] += 1;
    }
  }
  return [...buckets.values()];
}
