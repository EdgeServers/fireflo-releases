import { test } from "node:test";
import assert from "node:assert/strict";
import { ITERATIONS, hashPassword, needsRehash, verifyPassword } from "./password-hash.ts";

/**
 * The string both halves of the product must agree on.
 *
 * <p>Pinned in the gateway's `PasswordHashTest.java` as `SHARED_VECTOR`: password
 * "correct horse battery staple", salt bytes 00..0f, 600 000 rounds. If this fails, the panel can no
 * longer read what `fireflo user` writes.
 */
const SHARED_VECTOR = "$pbkdf2-sha256$600000$AAECAwQFBgcICQoLDA0ODw==$7xdxRO7JQgy8EJPSqLNEqSvFBtDU7JwCjdGfgyTYweY=";
const OLD_VECTOR = "$pbkdf2-sha256$1000$AAECAwQFBgcICQoLDA0ODw==$ppsXnjrdPB4KryJ6DrOqKqhkWrhv7PbKAMF1Eml8cZ4=";
const PASSWORD = "correct horse battery staple";

test("the Node derivation matches the Java vector", async () => {
  assert.equal(await verifyPassword(PASSWORD, SHARED_VECTOR), true);
  assert.equal(await verifyPassword(PASSWORD, OLD_VECTOR), true);
  assert.equal(await verifyPassword("correct horse battery stable", SHARED_VECTOR), false);
});

test("round trip with a fresh salt", async () => {
  const stored = await hashPassword("a long enough password");
  assert.ok(stored.startsWith(`$pbkdf2-sha256$${ITERATIONS}$`));
  assert.match(stored, /^\$pbkdf2-sha256\$[0-9]+\$[A-Za-z0-9+/]+=*\$[A-Za-z0-9+/]+=*$/);
  assert.equal(await verifyPassword("a long enough password", stored), true);
  assert.equal(await verifyPassword("a long enough passwore", stored), false);
  assert.equal(needsRehash(stored), false);
});

test("two hashes of one password differ", async () => {
  assert.notEqual(await hashPassword("same twice"), await hashPassword("same twice"));
});

test("anything that is not one of our strings verifies false and never throws", async () => {
  for (const bad of [null, undefined, "", "plaintext", "$bcrypt$x$y$z", "$pbkdf2-sha256$0$AA==$AA==",
    "$pbkdf2-sha256$x$AA==$AA==", "$pbkdf2-sha256$1000$not base64!$AA==", `${SHARED_VECTOR}$extra`]) {
    assert.equal(await verifyPassword(PASSWORD, bad), false, String(bad));
    assert.equal(needsRehash(bad), true, String(bad));
  }
});

test("an older iteration count asks for a rehash", () => {
  assert.equal(needsRehash(OLD_VECTOR), true);
  assert.equal(needsRehash(SHARED_VECTOR), false);
});
