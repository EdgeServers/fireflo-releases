import { configQuery } from "@/lib/config-db";
import {
  BUILTIN_REGISTRY,
  registryFrom,
  rowFromRecord,
  type ConfigKeyRegistry,
} from "@/lib/config-key-registry";

/**
 * `app_config_key`, read from the gateway's database. Server-only: importing this pulls `pg`.
 *
 * <p>The table (gateway migration V1.61.0) is the one list of what every configuration key is; see
 * `config-key-registry.ts` for why. This returns it as a registry, or {@link BUILTIN_REGISTRY} when it
 * cannot be read -- a gateway in file mode has no such table to read, and a role built from an older
 * grant block cannot see it. The fallback is the same list the table was seeded from, so falling back
 * only loses keys added to the table since.
 *
 * <p>Held for {@link TTL_MS}: it changes when the gateway is upgraded, not while an operator works, and
 * every settings request asking the database for 118 rows it already has would be waste.
 *
 * <p>`status` and `replaced_by` (gateway V1.88.0) are selected only when `information_schema.columns`
 * says the table has them, so a panel ahead of its gateway still reads the registry rather than
 * failing the whole query on an undefined column; every row then reads as current. Should the probe
 * itself be wrong -- a role that may read the table but not the catalogue -- the undefined-column
 * error (SQLSTATE 42703) is caught and the older shape read instead.
 */

const TTL_MS = 30_000;

let cached: { at: number; registry: ConfigKeyRegistry } | null = null;
let warned = false;

const BASE_COLUMNS = "scope, key, kind, choices, unit, coded_default, secret, access, reason, label";

/** Whether `app_config_key` has been through V1.88.0. Null means the catalogue could not be asked. */
async function hasStatusColumns(): Promise<boolean | null> {
  try {
    const found = await configQuery<{ column_name: string }>(
      `SELECT column_name FROM information_schema.columns
        WHERE table_name = 'app_config_key' AND column_name IN ('status', 'replaced_by')`
    );
    return found.length === 2;
  } catch {
    return null;
  }
}

async function readRows(withStatus: boolean): Promise<Record<string, unknown>[]> {
  const columns = withStatus ? `${BASE_COLUMNS}, status, replaced_by` : BASE_COLUMNS;
  return configQuery<Record<string, unknown>>(`SELECT ${columns} FROM app_config_key ORDER BY scope, key`);
}

export async function loadConfigKeyRegistry(): Promise<ConfigKeyRegistry> {
  if (cached && Date.now() - cached.at < TTL_MS) {
    return cached.registry;
  }
  let registry: ConfigKeyRegistry;
  try {
    const probed = await hasStatusColumns();
    let rows: Record<string, unknown>[];
    try {
      //an unanswerable probe optimistically asks for the newer shape, and the catch below steps back
      rows = await readRows(probed !== false);
    } catch (err) {
      if (probed === null && (err as { code?: string })?.code === "42703") {
        rows = await readRows(false);
      } else {
        throw err;
      }
    }
    registry = rows.length ? registryFrom(rows.map(rowFromRecord), "database") : BUILTIN_REGISTRY;
  } catch (err) {
    //once, not per request: the cause is a deployment fact (file mode, a missing grant) that a log
    //repeating it every thirty seconds would only bury
    if (!warned) {
      warned = true;
      console.warn(`app_config_key could not be read, using the panel's built-in copy: ${err instanceof Error ? err.message : err}`);
    }
    registry = BUILTIN_REGISTRY;
  }
  cached = { at: Date.now(), registry };
  return registry;
}
