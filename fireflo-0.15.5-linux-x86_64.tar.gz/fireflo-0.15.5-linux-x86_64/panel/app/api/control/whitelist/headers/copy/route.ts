import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { requireOperator } from "@/lib/require-operator";
import { copyWhitelistRows } from "@/lib/account-archive";
import { parseCopyRequest } from "@/lib/account-archive-rules";

/**
 * Copies sender IDs to several accounts: `{ "ids": [12, 13], "to": ["acme", "beta"], "status":
 * "keep" | "pending", "widenScope": false }`. Answers `{ data: [{ to, copied, skipped: [{ id, text,
 * reason }] }] }`, one entry per target. Nothing already in a target is changed.
 *
 * <p>Refused (400) for a target that is not an account or is archived, a product not in the
 * catalogue, or more than 500 rows / 50 targets. The same guard as move: operator or admin.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite("app_header");
  if (refused) {
    return refused;
  }
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const parsed = parseCopyRequest(body, "sender IDs");
  if ("error" in parsed) {
    return NextResponse.json({ error: parsed.error }, { status: 400 });
  }
  try {
    const { name: operator } = await requireOperator();
    const data = await copyWhitelistRows("header", parsed.ids, parsed.to,
      { status: parsed.status, widenScope: parsed.widenScope }, operator);
    return NextResponse.json({ data });
  } catch (err) {
    return configFailed("copy sender IDs", err);
  }
}
