"use client";

import { forwardRef, useCallback, useEffect, useImperativeHandle, useState } from "react";
import { History, KeyRound, LogIn, Pencil, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select } from "@/components/ui/select";
import { formatTimestamp } from "@/lib/datetime";
import { moneyFromBigintString, moneyScale } from "@/lib/format";
import type { ActivityFilter, ActivityItem, ActivityPage } from "@/lib/account-activity-types";
import { useDisplayZone } from "@/components/DisplayZoneProvider";

const FILTERS: { value: ActivityFilter; label: string }[] = [
  { value: "all", label: "All" },
  { value: "signins", label: "Sign-ins" },
  { value: "changes", label: "Changes" },
  { value: "money", label: "Money" },
];

/** Lets the page ask for a reload after something on it changed the account. */
export interface AccountActivityHandle {
  reload: () => void;
}

/**
 * What has happened to this account, newest first: portal sign-ins, changes made here or by the
 * customer, and money moving. See lib/account-activity.ts for where each line comes from and what
 * is left out.
 */
export const AccountActivityCard = forwardRef<AccountActivityHandle, { id: string }>(function AccountActivityCard(
  { id },
  ref
) {
  const [filter, setFilter] = useState<ActivityFilter>("all");
  const [items, setItems] = useState<ActivityItem[]>([]);
  const [next, setNext] = useState<string | null>(null);
  const [currency, setCurrency] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchPage = useCallback(
    async (before: string | null) => {
      setLoading(true);
      setError(null);
      try {
        const q = new URLSearchParams({ filter });
        if (before) {
          q.set("before", before);
        }
        const res = await fetch(`/api/control/accounts/${encodeURIComponent(id)}/activity?${q}`, { cache: "no-store" });
        const json = await res.json().catch(() => null);
        if (!res.ok || !json?.data) {
          setError(json?.error ?? "Could not read the activity.");
          return;
        }
        const page = json.data as ActivityPage;
        setItems((prev) => (before ? prev.concat(page.items) : page.items));
        setNext(page.next);
        setCurrency(page.currency);
      } catch {
        setError("Could not reach the panel.");
      } finally {
        setLoading(false);
      }
    },
    [id, filter]
  );

  useEffect(() => {
    void fetchPage(null);
  }, [fetchPage]);

  useImperativeHandle(ref, () => ({ reload: () => void fetchPage(null) }), [fetchPage]);

  return (
    <Card>
      <CardHeader bar className="flex flex-row flex-wrap items-center gap-2 space-y-0">
        <CardTitle className="flex items-center gap-2">
          <History className="size-4 text-muted-foreground" aria-hidden />
          Activity
        </CardTitle>
        <Select
          aria-label="Show"
          className="ml-auto w-auto"
          value={filter}
          onChange={(e) => setFilter(e.target.value as ActivityFilter)}
        >
          {FILTERS.map((f) => (
            <option key={f.value} value={f.value}>{f.label}</option>
          ))}
        </Select>
      </CardHeader>
      <CardContent className="pt-1">
        {error && <p className="py-2 text-sm text-destructive">{error}</p>}
        {!loading && !error && items.length === 0 && (
          <p className="py-6 text-center text-sm text-muted-foreground">Nothing recorded yet.</p>
        )}
        <ol className="divide-y divide-border">
          {items.map((item) => (
            <ActivityLine key={item.key} item={item} accountId={id} currency={currency} />
          ))}
        </ol>
        {(next || loading) && (
          <div className="pt-3 text-center">
            <Button size="sm" variant="ghost" disabled={loading} onClick={() => void fetchPage(next)}>
              {loading ? "Reading…" : "Older"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
});

function ActivityLine({ item, accountId, currency }: { item: ActivityItem; accountId: string; currency: string | null }) {
  const { zone } = useDisplayZone();
  const { icon: Icon, text, tone, sub } = describe(item, accountId, currency);
  return (
    <li className="flex gap-3 py-2.5 text-sm">
      <Icon className={`mt-0.5 size-4 shrink-0 ${tone === "bad" ? "text-destructive" : "text-muted-foreground"}`} aria-hidden />
      <div className="min-w-0 flex-1">
        <p className={`break-words ${tone === "bad" ? "text-destructive" : ""}`}>{text}</p>
        {sub && <p className="truncate text-xs text-muted-foreground" title={sub}>{sub}</p>}
        {/* under the line on a phone, where beside it the two collide */}
        <time className="text-xs tabular-nums text-muted-foreground sm:hidden" dateTime={item.at} suppressHydrationWarning>
          {formatTimestamp(item.at, zone)}
        </time>
      </div>
      <time className="hidden shrink-0 text-xs tabular-nums text-muted-foreground sm:block" dateTime={item.at}
        suppressHydrationWarning>
        {formatTimestamp(item.at, zone)}
      </time>
    </li>
  );
}

const FIELD_NAMES: Record<string, string> = {
  label: "name",
  description: "notes",
  email: "address",
  enabled: "listing",
  resells: "reselling",
  parentAccountId: "parent",
};

function shown(v: unknown): string {
  if (v === null || v === undefined || v === "") {
    return "none";
  }
  if (typeof v === "boolean") {
    return v ? "on" : "off";
  }
  const s = String(v);
  return s.length > 40 ? `${s.slice(0, 40)}…` : s;
}

/** One line in words. Unknown events still show, by their name, rather than being dropped. */
function describe(
  item: ActivityItem,
  accountId: string,
  currency: string | null
): { icon: typeof History; text: string; tone?: "bad"; sub?: string } {
  const d = (item.detail ?? {}) as Record<string, unknown>;
  const who = item.actor ?? "Somebody";
  const where = item.ip ? `from ${item.ip.replace(/^::ffff:/, "")}` : undefined;

  if (item.source === "ledger") {
    const amount = item.delta ? moneyFromBigintString(item.delta.replace(/^-/, ""), moneyScale()) : "";
    const cur = currency ? ` ${currency}` : "";
    const negative = item.delta?.startsWith("-");
    const pending = d.applied === false ? " (pending)" : "";
    const sub = [d.note, d.ref].filter(Boolean).join(" · ") || undefined;
    switch (item.event) {
      case "recharge":
        return { icon: Wallet, text: `Recharge +${amount}${cur}${pending}`, sub };
      case "transfer":
        return item.ledgerAccount === accountId
          ? { icon: Wallet, text: `Transfer to ${item.counterparty} −${amount}${cur}${pending}`, sub }
          : { icon: Wallet, text: `Transfer from ${item.ledgerAccount} +${amount}${cur}${pending}`, sub };
      case "bill":
        return { icon: Wallet, text: `Period billed −${amount}${cur}`, sub };
      case "debit":
        //the stored delta is positive and the type is the direction; the reason is the note
        return { icon: Wallet, text: `Debit −${amount}${cur}${d.note ? ` · ${String(d.note)}` : ""}`, sub: d.ref ? String(d.ref) : undefined };
      default:
        return { icon: Wallet, text: `Adjustment ${negative ? "−" : "+"}${amount}${cur}${pending}`, sub };
    }
  }

  if (item.source === "customer") {
    switch (item.event) {
      case "password_signin":
        return { icon: LogIn, text: `${who} signed in with a password`, sub: where };
      case "password_signin_failed":
        return { icon: LogIn, text: `Failed password sign-in as ${who}`, tone: "bad", sub: where };
      case "link_redeemed":
        return { icon: LogIn, text: `${who === "Somebody" ? "Signed in" : `${who} signed in`} by emailed link`, sub: where };
      case "link_rejected":
        return { icon: LogIn, text: "A sign-in link was refused", tone: "bad", sub: where };
      case "link_requested":
        return { icon: LogIn, text: `${who} asked for a sign-in link`, sub: where };
      case "link_denied":
        return { icon: LogIn, text: `A sign-in link for ${who} was not sent`, tone: "bad", sub: where };
      case "password_set":
        return { icon: KeyRound, text: `${who} ${d.changed ? "changed" : "set"} their portal password`, sub: where };
      default:
        return { icon: History, text: `${who}: ${item.event.replace(/_/g, " ")}`, sub: where };
    }
  }

  //operator
  const subject = typeof d.subject === "string" ? d.subject : "a login";
  switch (item.event) {
    case "account_updated": {
      if (d.created) {
        return { icon: Pencil, text: `${who} created the account` };
      }
      const changed = (d.changed ?? {}) as Record<string, { from: unknown; to: unknown }>;
      const fields = Object.keys(changed);
      return {
        icon: Pencil,
        text: `${who} changed the ${fields.map((f) => FIELD_NAMES[f] ?? f).join(", ") || "account"}`,
        sub: fields.map((f) => `${FIELD_NAMES[f] ?? f}: ${shown(changed[f].from)} → ${shown(changed[f].to)}`).join(" · "),
      };
    }
    case "user_password_set":
      return { icon: KeyRound, text: d.cleared ? `${who} removed the portal password of ${subject}` : `${who} set the portal password of ${subject}` };
    case "user_created":
      return { icon: KeyRound, text: `${who} added portal login ${subject}${d.password ? " with a password" : ""}` };
    case "user_updated":
      return { icon: KeyRound, text: `${who} turned ${subject} ${d.enabled === false ? "off" : "on"}` };
    case "config_changed": {
      //a login, a top-up, a sender ID or a pricing scope of this account: domain, name and verb
      const verb = String(d.action ?? "").replace(/^action:/, "").replace(/_/g, " ");
      const what = `${String(d.domain ?? "").replace(/_/g, " ")} ${String(d.name ?? "")}`.trim();
      const changed = Array.isArray(d.changed) && d.changed.length ? `changed: ${d.changed.join(", ")}` : undefined;
      return { icon: Pencil, text: `${who}: ${verb} ${what}`, sub: changed };
    }
    default:
      return { icon: History, text: `${who}: ${item.event.replace(/_/g, " ")}` };
  }
}
