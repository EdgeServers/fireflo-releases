"use client";
import { useId, useMemo, useRef, useState } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { HealthStrip } from "./CardBits";
import { useAccounts } from "./useAccounts";
import {
  type CopyPick,
  type CopyStatusChoice,
  type CopyTargetResult,
  copyResultLine,
  copySummary,
  dltCopyWarning,
  loginOnlyCopyNote,
  mergeCopyResults,
} from "@/lib/account-archive-rules";

/** How many suggestions the typeahead lists at once. */
const SUGGESTIONS = 8;

/**
 * Copies the selected sender IDs and templates to several accounts.
 *
 * <p>Shared by Account › Approvals (headers and templates together, two calls whose results are
 * merged per account) and Assets › Headers / Templates (one kind, rows from any number of accounts).
 * The server decides (`copyWhitelistRows`): nothing a target already has is changed, and a missing or
 * archived target refuses the whole copy with the sentence shown here as it came.
 */
export function CopyToAccountsDialog({
  rows,
  source,
  onClose,
  onCopied,
}: {
  /** The ticked rows. Rejected ones are left out of the copy (and the counts). */
  rows: readonly CopyPick[];
  /** The account the rows come from, when they all do: it is not offered as a target. */
  source?: string;
  onClose: () => void;
  /** After a copy that wrote anything, so the caller can reload. */
  onCopied?: (results: CopyTargetResult[]) => void;
}) {
  const { accounts } = useAccounts();
  const [chosen, setChosen] = useState<string[]>([]);
  const [query, setQuery] = useState("");
  const [focused, setFocused] = useState(false);
  const [highlight, setHighlight] = useState(0);
  const [status, setStatus] = useState<CopyStatusChoice>("keep");
  const [widen, setWiden] = useState(false);
  const [error, setError] = useState("");
  const [copying, setCopying] = useState(false);
  const [results, setResults] = useState<CopyTargetResult[] | null>(null);
  const input = useRef<HTMLInputElement>(null);
  const ids = useId();

  const live = rows.filter((r) => r.status !== "REJECTED");
  const headerIds = live.filter((r) => r.kind === "header").map((r) => r.id);
  const templateIds = live.filter((r) => r.kind === "template").map((r) => r.id);
  const loginNote = loginOnlyCopyNote(live);
  const dlt = dltCopyWarning(live);

  //the catalogue's accounts are the non-archived ones; archived accounts arrive in a list of their own
  const options = useMemo(() => {
    const q = query.trim().toLowerCase();
    return accounts
      .filter((a) => a.id !== source && !chosen.includes(a.id))
      .filter((a) => !q || a.id.toLowerCase().includes(q) || (a.label ?? "").toLowerCase().includes(q))
      .slice(0, SUGGESTIONS);
  }, [accounts, source, chosen, query]);
  const open = focused && options.length > 0;
  const active = Math.min(highlight, Math.max(0, options.length - 1));

  function add(id: string) {
    setChosen((prev) => (prev.includes(id) ? prev : [...prev, id]));
    setQuery("");
    setHighlight(0);
    input.current?.focus();
  }

  async function post(kind: "headers" | "templates", list: number[]): Promise<CopyTargetResult[]> {
    const res = await fetch(`/api/control/whitelist/${kind}/copy`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids: list, to: chosen, status, widenScope: widen }),
    });
    const json = await res.json().catch(() => null);
    if (!res.ok) {
      throw new Error(json?.error ?? `Request failed (${res.status})`);
    }
    return (json?.data ?? []) as CopyTargetResult[];
  }

  async function copy() {
    setCopying(true);
    setError("");
    const parts: CopyTargetResult[][] = [];
    try {
      if (headerIds.length) {
        parts.push(await post("headers", headerIds));
      }
      if (templateIds.length) {
        parts.push(await post("templates", templateIds));
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Request failed";
      //the sender IDs may have landed before the templates were refused: say so, rather than
      //leaving the operator to guess whether to try the whole thing again
      setError(parts.length ? `The sender IDs were copied; the templates were not. ${message}` : message);
    } finally {
      setCopying(false);
    }
    if (parts.length) {
      const merged = mergeCopyResults(...parts);
      setResults(merged);
      if (merged.some((r) => r.copied > 0)) {
        onCopied?.(merged);
      }
    }
  }

  return (
    <Dialog open onClose={onClose} title="Copy to accounts" className="max-w-xl">
      {results ? (
        <div className="space-y-3 text-sm">
          <p><span className="font-medium">Copied.</span> Recorded in the audit log, one entry per row.</p>
          {error && <HealthStrip tone="destructive">{error}</HealthStrip>}
          <ul className="space-y-1.5">
            {results.map((r) => {
              const [head, ...notes] = copyResultLine(r).split(" · ");
              return (
                <li key={r.to} className="flex flex-wrap justify-between gap-2 border-t border-border pt-1.5">
                  <span className="font-mono font-medium">{r.to}</span>
                  <span>
                    {head}
                    {notes.length > 0 && <span className="text-muted-foreground"> · {notes.join(" · ")}</span>}
                  </span>
                </li>
              );
            })}
          </ul>
          <div className="flex justify-end">
            <Button type="button" onClick={onClose}>Done</Button>
          </div>
        </div>
      ) : (
        <form
          className="space-y-4 text-sm"
          onSubmit={(e) => {
            e.preventDefault();
            if (chosen.length && live.length && !copying) {
              void copy();
            }
          }}
        >
          <p>{copySummary(headerIds.length, templateIds.length, chosen)}</p>

          <div className="space-y-1">
            <span id={`${ids}-label`} className="block text-sm font-medium">Target accounts</span>
            <div
              className="relative flex flex-wrap gap-1.5 rounded-md border border-input bg-background p-1.5"
              onClick={() => input.current?.focus()}
            >
              {chosen.map((a) => (
                <span key={a} className="inline-flex items-center gap-1 rounded-full bg-primary/10 py-0.5 pl-2.5 pr-1 font-mono text-xs text-primary">
                  {a}
                  <button type="button" aria-label={`Remove ${a}`} className="rounded-full px-1 hover:bg-primary/20"
                    onClick={() => setChosen((prev) => prev.filter((x) => x !== a))}>
                    <X className="h-3 w-3" aria-hidden="true" />
                  </button>
                </span>
              ))}
              <input
                ref={input}
                role="combobox"
                aria-labelledby={`${ids}-label`}
                aria-expanded={open}
                aria-controls={`${ids}-list`}
                aria-activedescendant={open ? `${ids}-opt-${active}` : undefined}
                aria-autocomplete="list"
                autoComplete="off"
                autoFocus
                placeholder="Type an account name or id"
                className="min-w-36 flex-1 bg-transparent px-1 py-0.5 outline-none"
                value={query}
                onChange={(e) => { setQuery(e.target.value); setHighlight(0); }}
                onFocus={() => setFocused(true)}
                onBlur={() => setFocused(false)}
                onKeyDown={(e) => {
                  if (e.key === "ArrowDown") {
                    e.preventDefault();
                    setHighlight(Math.min(active + 1, options.length - 1));
                  } else if (e.key === "ArrowUp") {
                    e.preventDefault();
                    setHighlight(Math.max(active - 1, 0));
                  } else if (e.key === "Enter") {
                    //Enter adds; it never submits the form from this box
                    e.preventDefault();
                    if (open && options[active]) {
                      add(options[active].id);
                    }
                  } else if (e.key === "Backspace" && !query && chosen.length) {
                    setChosen((prev) => prev.slice(0, -1));
                  }
                }}
              />
              {open && (
                <div id={`${ids}-list`} role="listbox"
                  className="absolute inset-x-0 top-full z-10 mt-1 max-h-52 overflow-auto rounded-md border border-border bg-popover shadow-lg">
                  {options.map((a, i) => (
                    <div
                      key={a.id}
                      id={`${ids}-opt-${i}`}
                      role="option"
                      aria-selected={i === active}
                      className={`flex cursor-pointer justify-between gap-2 px-2.5 py-1.5 ${i === active ? "bg-muted" : "hover:bg-muted"}`}
                      //mousedown, not click: a click lands after the input's blur has closed the list
                      onMouseDown={(e) => { e.preventDefault(); add(a.id); }}
                      onMouseEnter={() => setHighlight(i)}
                    >
                      <span className="font-mono">{a.id}</span>
                      {a.label && <span className="truncate text-xs text-muted-foreground">{a.label}</span>}
                    </div>
                  ))}
                </div>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              Add as many as you need: type, then Enter or click. Backspace removes the last. Archived
              accounts are not offered.
            </p>
          </div>

          <fieldset className="space-y-1.5">
            <legend className="mb-1 text-sm font-medium">Status in the target accounts</legend>
            <label className="flex items-start gap-2">
              <input type="radio" name={`${ids}-status`} className="mt-1" checked={status === "keep"}
                onChange={() => setStatus("keep")} />
              <span>
                <span className="font-medium">Keep approval</span>
                <span className="block text-xs text-muted-foreground">
                  An approved row is approved in each target at once and applies within about 30
                  seconds; a pending row stays pending.
                </span>
              </span>
            </label>
            <label className="flex items-start gap-2">
              <input type="radio" name={`${ids}-status`} className="mt-1" checked={status === "pending"}
                onChange={() => setStatus("pending")} />
              <span>
                <span className="font-medium">Copy as pending</span>
                <span className="block text-xs text-muted-foreground">
                  Every copy waits for approval on the target account&apos;s Approvals page.
                </span>
              </span>
            </label>
          </fieldset>

          {loginNote && (
            <div className="space-y-1">
              <label className="flex items-center gap-2">
                <input type="checkbox" className="h-3.5 w-3.5 accent-primary" checked={widen}
                  onChange={(e) => setWiden(e.target.checked)} />
                <span>Copy login-only rows to the whole account</span>
              </label>
              <p className="text-xs text-muted-foreground">{loginNote}</p>
            </div>
          )}

          {dlt && <HealthStrip tone="warning">{dlt}</HealthStrip>}
          {error && <HealthStrip tone="destructive">{error}</HealthStrip>}

          <div className="flex flex-wrap items-center gap-2">
            <Button type="submit" disabled={copying || !chosen.length || !live.length}>
              {copying ? "Copying…" : "Copy"}
            </Button>
            <Button type="button" variant="outline" onClick={onClose} disabled={copying}>Cancel</Button>
            <span className="text-xs text-muted-foreground">Nothing already in a target account is changed.</span>
          </div>
        </form>
      )}
    </Dialog>
  );
}
