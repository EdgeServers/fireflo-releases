"use client";
import { useState } from "react";
import { Inbox } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { count } from "@/lib/format";
import type { Health } from "@/lib/health-types";
import {
  ageLabel, appendDepth, custodyExplainer, custodyPill, rateLabel, receiptsWaiting,
} from "@/lib/receipt-custody";
import { Figures } from "./CardBits";
import { Sparkline } from "./Sparkline";

/**
 * Receipts waiting to be matched (gateway 0.15.3, `receipt_custody`).
 *
 * <p>A vendor's receipt is taken into custody -- Kafka `fireflo.receipts.in`, or the local log in
 * memory mode -- and the vendor told OK before the receipt store has it; the matcher then records it
 * at the database's pace. This card is that queue: how many wait, how old the oldest is, the rate in
 * against the rate matched, a sparkline of the waiting count over the polls this page has seen, and
 * each vendor's share. OK, Slow or Backing up is the gateway's own verdict.
 *
 * <p>Absent on an older gateway, which has no such queue: a receipt it could not record in time was
 * refused back to the vendor instead.
 */
export function ReceiptsWaitingCard({ health }: { health: Health | null | undefined }) {
  const r = receiptsWaiting(health);
  //the sparkline's history: one reading per health poll this page has seen, kept in the browser
  //only. Appended while rendering when the poll's time moves, React's pattern for state derived
  //from a changing prop (an effect would paint each reading one frame late)
  const [ring, setRing] = useState<{ at: string | null; values: number[] }>({ at: null, values: [] });
  const at = health?.observed_at ?? null;
  if (r && at && at !== ring.at) {
    setRing({ at, values: appendDepth(ring.values, r.depth) });
  }
  if (!r) {
    return null;
  }
  const pill = custodyPill(r.state);
  const tone = r.state === "BACKING_UP" ? "destructive" : r.state === "SLOW" ? "warning" : "default";
  const kafka = (health?.backbone?.provider ?? "").toLowerCase() === "kafka";

  return (
    <Card className={cn(r.state === "BACKING_UP" && "border-destructive/50", r.state === "SLOW" && "border-warning")}>
      <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0">
        <CardTitle className="flex items-center gap-2">
          <Inbox className="h-4 w-4 text-muted-foreground" aria-hidden />
          Receipts waiting to be matched
        </CardTitle>
        <Badge variant={pill.tone}>{pill.label}</Badge>
      </CardHeader>
      <CardContent className="space-y-3">
        <Figures
          figures={[
            { value: count(r.depth), label: "waiting", tone },
            { value: ageLabel(r.oldestAgeSeconds), label: "oldest", tone },
            { value: rateLabel(r.inPerSecond, r.matchedPerSecond), label: "in / matched per s" },
          ]}
        />
        <div className={cn(tone === "destructive" ? "text-destructive" : tone === "warning" ? "text-warning" : "text-primary")}>
          <Sparkline values={ring.values} className="h-12 w-full" />
          <p className="text-xs text-muted-foreground">
            {ring.values.length < 2
              ? "Waiting receipts over time: drawn from the next poll on."
              : `Waiting receipts over the last ${ring.values.length} polls, while this page is open.`}
          </p>
        </div>
        {r.vendors.length > 0 && (
          <ul className="divide-y divide-border rounded-md border border-border text-sm">
            {r.vendors.map((v) => (
              <li key={v.worker} className="flex flex-wrap items-baseline gap-x-3 px-3 py-1.5 tabular-nums">
                <span className="min-w-0 flex-1 truncate font-mono text-xs">{v.worker}</span>
                <span className="font-medium">{count(v.depth)}</span>
                <span className="text-xs text-muted-foreground">oldest {ageLabel(v.oldestAgeSeconds)}</span>
              </li>
            ))}
          </ul>
        )}
        <p className="text-xs text-muted-foreground">{custodyExplainer(kafka)}</p>
      </CardContent>
    </Card>
  );
}
