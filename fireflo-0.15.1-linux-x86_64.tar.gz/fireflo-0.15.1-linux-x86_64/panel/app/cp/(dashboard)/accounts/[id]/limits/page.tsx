import { AccountLimitsClient } from "@/components/AccountLimitsClient";

/**
 * Why this account gets the rate it gets: its ceiling on every listener and the setting behind it,
 * live TPS against it, binds and throttles. Operator only -- not among the reseller tabs.
 */
export default async function AccountLimitsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <AccountLimitsClient id={decodeURIComponent(id)} />;
}
