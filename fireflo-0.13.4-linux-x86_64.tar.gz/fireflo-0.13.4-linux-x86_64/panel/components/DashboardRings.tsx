"use client";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { SunburstChart } from "recharts";
import { AlertTriangle, Server } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { RANGES, type Range } from "./useControlData";
import type { VendorRow } from "./VendorTraffic";
import { count, percent } from "@/lib/format";
import { FINAL_STATE_LABELS, labelFor } from "@/lib/labels";
import { byAccount, byReason, reasonKey, type FailureCell } from "@/lib/failure-groups";

/**
 * The dashboard's two sunbursts, side by side: why messages failed (accounts inside, their failure
 * reasons outside) and what each vendor sent (vendors inside, delivered / failed / pending outside).
 *
 * <p>Click an account or vendor to zoom into it -- its own breakdown then fills the circle -- and the
 * breadcrumb or the centre to come back out. The centre names whatever is under the pointer. Colours
 * are fixed hues rather than theme tokens on purpose: a reason keeps one colour wherever it appears,
 * across both themes.
 */

/** Failure reasons, by their rank in the period: the biggest reason is always the first colour. */
const REASON_COLOURS = ["#2a78d6", "#eb6834", "#008300", "#e34948", "#6250d6"];
const REST_COLOUR = "#9a988f";
/** The inner rings: accounts on the left, vendors on the right. */
const SLICE_COLOURS = ["#6250d6", "#e87ba4", "#1baf7a", "#c98500", "#2a78d6", "#eb6834"];
const OTHER_COLOUR = "#b4b2a9";
const FAILED_COLOUR = "#e34948";
const PENDING_COLOUR = "#c9c7bd";

/** Whether each card's table is open. Closed until asked for; the choice is remembered per browser. */
const FAILURE_TABLE_KEY = "fireflo.overview.failureTable";
const VENDOR_TABLE_KEY = "fireflo.overview.vendorTable";

/** A Show table / Hide table switch, closed by default and remembered under `key`. */
function useTableToggle(key: string): [boolean, () => void] {
  const [open, setOpen] = useState(false);
  //read after mount: localStorage does not exist while the page renders on the server
  useEffect(() => {
    try {
      setOpen(window.localStorage.getItem(key) === "1");
    } catch {
      //private window or blocked storage: closed stands
    }
  }, [key]);
  const toggle = () => setOpen((was) => {
    try {
      window.localStorage.setItem(key, was ? "0" : "1");
    } catch {
      //remembered for this page only
    }
    return !was;
  });
  return [open, toggle];
}

function TableToggle({ open, onToggle }: { open: boolean; onToggle: () => void }) {
  return (
    <Button variant="outline" size="sm" className="h-7" onClick={onToggle} aria-pressed={open}>
      {open ? "Hide table" : "Show table"}
    </Button>
  );
}

/** One sector of a sunburst: a leaf with its value, or a parent whose value is its children's sum. */
interface Node {
  name: string;
  value: number;
  fill: string;
  /** What the centre and the hover say, when it is not just the name. */
  label?: string;
  children?: Node[];
}

function reasonName(row: Pick<FailureCell, "finalState" | "dlrState" | "errCode">): string {
  const state = labelFor(FINAL_STATE_LABELS, row.finalState);
  return row.errCode ? `${state} · error ${row.errCode}` : row.dlrState !== null ? `${state} · receipt ${row.dlrState}` : state;
}

/** `hex` lightened towards white by `amount` (0..1): a vendor's delivered share in its own colour. */
function tint(hex: string, amount: number): string {
  const n = parseInt(hex.slice(1), 16);
  const mix = (c: number) => Math.round(c + (255 - c) * amount);
  return `#${[(n >> 16) & 255, (n >> 8) & 255, n & 255].map((c) => mix(c).toString(16).padStart(2, "0")).join("")}`;
}

/** A parent made from its children: its value is their sum, so every ring lines up with the next. */
function parent(name: string, fill: string, children: Node[], label?: string): Node {
  return { name, fill, label, children, value: children.reduce((n, c) => n + c.value, 0) };
}

/**
 * A zoomable sunburst. `root`'s children are the inner ring, theirs the outer one. Clicking a slice
 * with children makes it the root; the breadcrumb goes back. The library labels every sector with its
 * value, which on a thin slice is noise, so its labels are hidden and the centre says it instead.
 */
function Sunburst({ root, total, ariaLabel }: { root: Node; total: string; ariaLabel: string }) {
  const [focus, setFocus] = useState<string | null>(null);
  const [hover, setHover] = useState<Node | null>(null);
  const zoomed = focus ? root.children?.find((c) => c.name === focus) ?? null : null;
  const shown = zoomed ? parent(zoomed.name, zoomed.fill, zoomed.children ?? [], zoomed.label) : root;
  const centre = hover
    ? { title: hover.label ?? hover.name, value: count(hover.value) }
    : zoomed
      ? { title: zoomed.label ?? zoomed.name, value: count(zoomed.value) }
      : { title: total, value: "" };
  return (
    <div className="space-y-1">
      <nav className="flex min-h-5 flex-wrap items-center gap-1 text-xs text-muted-foreground" aria-label="Where the chart is zoomed">
        {zoomed ? (
          <>
            <button type="button" className="underline-offset-2 hover:text-foreground hover:underline" onClick={() => { setFocus(null); setHover(null); }}>
              {total}
            </button>
            <span aria-hidden="true">›</span>
            <span className="font-medium text-foreground">{zoomed.label ?? zoomed.name}</span>
          </>
        ) : (
          <span>Click a slice to zoom in</span>
        )}
      </nav>
      <div className="relative mx-auto aspect-square w-full max-w-60" role="img" aria-label={ariaLabel}>
        <SunburstChart
          data={shown}
          responsive
          width="100%"
          height="100%"
          innerRadius={44}
          padding={1}
          ringPadding={1}
          stroke="var(--color-card)"
          textOptions={{ fill: "transparent", stroke: "none" }}
          onClick={(node) => {
            if (!zoomed && node.children?.length) {
              setFocus(node.name);
              setHover(null);
            }
          }}
          onMouseEnter={(node) => setHover(node as Node)}
          onMouseLeave={() => setHover(null)}
          style={{ cursor: zoomed ? "default" : "pointer" }}
        />
        {/* the centre: what is under the pointer, else the zoomed slice, else the total. A button
            when zoomed, so the middle of the chart is also the way back out */}
        <button
          type="button"
          disabled={!zoomed}
          onClick={() => { setFocus(null); setHover(null); }}
          className="absolute left-1/2 top-1/2 flex h-20 w-20 -translate-x-1/2 -translate-y-1/2 flex-col items-center justify-center rounded-full text-center disabled:cursor-default"
          aria-label={zoomed ? "Zoom back out" : undefined}
          tabIndex={zoomed ? 0 : -1}
        >
          <span className="line-clamp-2 px-1 text-2xs leading-tight text-muted-foreground">{centre.title}</span>
          {centre.value && <span className="text-sm font-medium tabular-nums">{centre.value}</span>}
        </button>
      </div>
    </div>
  );
}

/** "summary to 14:02, live after", or "live records" -- what the figures were read from. */
function sourceNote(watermark: string | null | undefined): string {
  if (!watermark) {
    return "live records";
  }
  const at = new Date(watermark).toLocaleTimeString(undefined, { hourCycle: "h23", hour: "2-digit", minute: "2-digit" });
  return `summary to ${at}, live after`;
}

function Swatch({ colour, opacity }: { colour: string; opacity?: number }) {
  return <span className="inline-block h-2.5 w-2.5 shrink-0 rounded-sm" style={{ background: colour, opacity }} aria-hidden="true" />;
}

/**
 * Why messages failed: the failures of the period by account, each account split by reason. The
 * tables are on demand -- "Show table" opens a per-account summary and the reasons list with its
 * dismiss controls, which the caller renders and passes as `reasonsTable`.
 */
export function FailureRingCard({
  rows,
  since,
  watermark,
  loading,
  reasonsTable,
}: {
  rows: FailureCell[];
  since?: string;
  /** The summary's watermark the read leaned on, or null when it read the records alone. */
  watermark?: string | null;
  loading: boolean;
  reasonsTable: ReactNode;
}) {
  const [table, toggle] = useTableToggle(FAILURE_TABLE_KEY);

  const { slices, reasons, total, inner, tree } = useMemo(() => {
    const reasonsRanked = byReason(rows);
    const colourOf = new Map(reasonsRanked.map((r, i) => [reasonKey(r), REASON_COLOURS[i] ?? REST_COLOUR]));
    const accountSlices = byAccount(rows, 4);
    return {
      slices: accountSlices,
      reasons: reasonsRanked,
      total: reasonsRanked.reduce((n, r) => n + r.messages, 0),
      inner: accountSlices.map((s, i) => ({
        name: s.account ?? (s.accounts > 1 ? `Other (${s.accounts} accounts)` : "No account"),
        value: s.messages,
        fill: s.account === null ? OTHER_COLOUR : SLICE_COLOURS[i % SLICE_COLOURS.length],
      })),
      tree: parent("all", OTHER_COLOUR, accountSlices.map((s, i) => {
        const name = s.account ?? (s.accounts > 1 ? `Other (${s.accounts} accounts)` : "No account");
        return parent(name, s.account === null ? OTHER_COLOUR : SLICE_COLOURS[i % SLICE_COLOURS.length],
          s.reasons.map((r): Node => ({
            //names are the library's keys for a sector, so they carry the account and stay unique
            name: `${name} · ${r.key}`,
            label: `${name} · ${reasonName(r.row)}`,
            value: r.messages,
            fill: colourOf.get(r.key) ?? REST_COLOUR,
          })));
      })),
    };
  }, [rows]);

  return (
    <Card className="min-w-0">
      <CardHeader className="flex-row flex-wrap items-start gap-2 space-y-0">
        <div className="min-w-0 flex-1 space-y-1.5">
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            Why messages failed
          </CardTitle>
          <CardDescription>
            {since ? <>Since {new Date(since).toLocaleString()}</> : "This period"}
            {" · "}{sourceNote(watermark)}
            {total > 0 && <> · {count(total)} failed across {slices.reduce((n, s) => n + s.accounts, 0)} account{slices.reduce((n, s) => n + s.accounts, 0) === 1 ? "" : "s"}</>}
          </CardDescription>
        </div>
        <TableToggle open={table} onToggle={toggle} />
      </CardHeader>
      <CardContent className="space-y-3">
        {total === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">{loading ? "Loading…" : "No failures in this period"}</p>
        ) : (
          <>
            <Sunburst root={tree} total={`${count(total)} failed`}
              ariaLabel={`Failed messages by account, then by reason: ${inner.map((d) => `${d.name} ${d.value}`).join(", ")}`} />
            <div className="flex flex-wrap justify-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
              {reasons.slice(0, REASON_COLOURS.length).map((r, i) => (
                <span key={reasonKey(r)} className="flex items-center gap-1.5"><Swatch colour={REASON_COLOURS[i]} />{reasonName(r)}</span>
              ))}
              {reasons.length > REASON_COLOURS.length && (
                <span className="flex items-center gap-1.5"><Swatch colour={REST_COLOUR} />{reasons.length - REASON_COLOURS.length} more</span>
              )}
            </div>
            {table && <table className="w-full text-xs">
              <thead>
                <tr className="text-muted-foreground"><th className="py-1 text-left font-normal">Account</th><th className="py-1 text-right font-normal">Failed</th><th className="py-1 pl-3 text-left font-normal">Top reason</th></tr>
              </thead>
              <tbody>
                {slices.map((s, i) => (
                  <tr key={s.account ?? "other"} className="border-t border-border">
                    <td className="py-1.5"><span className="flex items-center gap-1.5"><Swatch colour={inner[i].fill} /><span className="truncate font-mono">{inner[i].name}</span></span></td>
                    <td className="py-1.5 text-right tabular-nums">{count(s.messages)}</td>
                    <td className="py-1.5 pl-3 text-muted-foreground [overflow-wrap:anywhere]">{s.reasons[0] ? reasonName(s.reasons[0].row) : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>}
          </>
        )}
        {table && <div className="border-t border-border pt-3">{reasonsTable}</div>}
      </CardContent>
    </Card>
  );
}

/**
 * What each vendor sent in the period, each vendor split into delivered, failed and still pending.
 *
 * <p>Its rows are a section of the overview snapshot, built in the background per range like the
 * traffic chart's, so an open dashboard costs the database nothing of its own: this card used to
 * poll `/api/control/vendors` every 30 seconds per tab, a 1.3-second read on .101.
 */
export function VendorRingCard({
  rows: data,
  range,
  watermark,
  loading,
  error,
}: {
  rows: VendorRow[];
  range: Range;
  watermark?: string | null;
  loading: boolean;
  error?: string;
}) {
  const [table, toggle] = useTableToggle(VENDOR_TABLE_KEY);
  const period = RANGES.find((r) => r.value === range)?.label ?? range;
  const { vendors, sent, inner, tree } = useMemo(() => {
    const rows = (data ?? []).filter((v) => v.messages > 0).sort((a, b) => b.messages - a.messages);
    const shown = rows.length > 6 ? rows.slice(0, 5) : rows;
    const rest = rows.slice(shown.length);
    const merged = rest.length
      ? [...shown, rest.reduce<VendorRow>((acc, v) => ({
        ...acc,
        messages: acc.messages + v.messages, delivered: acc.delivered + v.delivered,
        failed: acc.failed + v.failed, pending: acc.pending + v.pending,
      }), { ...rest[0], vendor: `Other (${rest.length})`, messages: 0, delivered: 0, failed: 0, pending: 0 })]
      : shown;
    const colour = (i: number) => (i < shown.length ? SLICE_COLOURS[i % SLICE_COLOURS.length] : OTHER_COLOUR);
    return {
      vendors: merged.map((v, i) => ({ ...v, colour: colour(i) })),
      sent: rows.reduce((n, v) => n + v.messages, 0),
      inner: merged.map((v, i) => ({ name: v.vendor ?? "No vendor", value: v.messages, fill: colour(i) })),
      //the outcomes are credited to one attempt per message, so they can sum to a little less than
      //the messages handed over; each vendor's slice is drawn from its outcomes, which is what it shows
      tree: parent("all", OTHER_COLOUR, merged.map((v, i) => {
        const name = v.vendor ?? "No vendor";
        return parent(name, colour(i), [
          { name: `${name} · delivered`, value: v.delivered, fill: tint(colour(i), 0.55) },
          { name: `${name} · failed`, value: v.failed, fill: FAILED_COLOUR },
          { name: `${name} · pending`, value: v.pending, fill: PENDING_COLOUR },
        ].filter((d) => d.value > 0));
      }).filter((v) => v.value > 0)),
    };
  }, [data]);

  return (
    <Card className="min-w-0">
      <CardHeader className="flex-row flex-wrap items-start gap-2 space-y-0">
        <div className="min-w-0 flex-1 space-y-1.5">
          <CardTitle className="flex items-center gap-2">
            <Server className="h-4 w-4 text-muted-foreground" />
            Sent by vendor
          </CardTitle>
          <CardDescription>
            Last {period}{sent > 0 ? ` · ${count(sent)} messages` : ""} · {sourceNote(watermark)}
          </CardDescription>
        </div>
        <TableToggle open={table} onToggle={toggle} />
      </CardHeader>
      <CardContent className="space-y-3">
        {error ? (
          <p className="py-6 text-center text-sm text-destructive">{error}</p>
        ) : sent === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">{loading ? "Loading…" : "Nothing sent in this period"}</p>
        ) : (
          <>
            <Sunburst root={tree} total={`${count(sent)} sent`}
              ariaLabel={`Messages by vendor, then by outcome: ${inner.map((d) => `${d.name} ${d.value}`).join(", ")}`} />
            <div className="flex flex-wrap justify-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
              <span>Outer band:</span>
              <span className="flex items-center gap-1.5"><Swatch colour={tint(SLICE_COLOURS[0], 0.55)} />delivered (vendor&apos;s colour)</span>
              <span className="flex items-center gap-1.5"><Swatch colour={FAILED_COLOUR} />failed</span>
              <span className="flex items-center gap-1.5"><Swatch colour={PENDING_COLOUR} />pending</span>
            </div>
            {table && <table className="w-full text-xs">
              <thead>
                <tr className="text-muted-foreground"><th className="py-1 text-left font-normal">Vendor</th><th className="py-1 text-right font-normal">Sent</th><th className="py-1 text-right font-normal">Delivered</th><th className="py-1 text-right font-normal">Failed</th></tr>
              </thead>
              <tbody>
                {vendors.map((v) => {
                  const settled = v.delivered + v.failed;
                  return (
                    <tr key={v.vendor ?? "none"} className="border-t border-border">
                      <td className="py-1.5"><span className="flex items-center gap-1.5"><Swatch colour={v.colour} /><span className="truncate font-mono">{v.vendor ?? "No vendor"}</span></span></td>
                      <td className="py-1.5 text-right tabular-nums">{count(v.messages)}</td>
                      <td className="py-1.5 text-right tabular-nums">{count(v.delivered)}</td>
                      <td className={"py-1.5 text-right tabular-nums" + (v.failed > 0 ? " text-destructive" : "")}>
                        {count(v.failed)}{settled > 0 && v.failed > 0 ? ` · ${percent(v.failed / settled)}` : ""}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>}
          </>
        )}
      </CardContent>
    </Card>
  );
}
