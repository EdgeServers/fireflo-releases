"use client";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { TlvStamps } from "@/components/TlvStamps";
import type { AccountColumn, AccountLoginRow } from "@/lib/account-columns";
import { formatTimestamp } from "@/lib/datetime";
import { accountHref } from "@/lib/panel-surface";

/**
 * One cell of the account/login tables, rendered by the format its column declares.
 *
 * <p>Shared by the `/accounts` index and the "Logins that bill here" card, which read the same
 * catalogue -- the card just narrows it to the Login group. A second copy of this switch would drift
 * from the first the moment either gained a format.
 */
export function AccountTableCell({
  column,
  row,
  onOpenLogin,
}: {
  column: AccountColumn;
  row: AccountLoginRow;
  onOpenLogin: (loginId: number) => void;
}) {
  if (column.format === "account") {
    return (
      <>
        <Link href={accountHref(row.id)} className="hover:underline">
          {row.label ? (
            <>
              <span className="font-medium">{row.label}</span>{" "}
              <span className="font-mono text-sm text-muted-foreground">{row.id}</span>
            </>
          ) : (
            <span className="font-mono">{row.id}</span>
          )}
        </Link>
        <Flags row={row} />
        {row.note && <span className="block text-xs text-muted-foreground">{row.note}</span>}
      </>
    );
  }
  if (column.format === "flags") {
    return <Flags row={row} bare />;
  }

  //the system id is the login's name, so it is the login's door -- the same way the account name is
  //the account's. A separate "Open" column was doing the job of two cells that were already there
  if (column.id === "systemId" && row.loginId != null && row.systemId) {
    return (
      <button
        type="button"
        onClick={() => onOpenLogin(row.loginId!)}
        className="font-mono text-sm text-primary hover:underline"
      >
        {row.systemId}
      </button>
    );
  }

  //an empty allowed-IP list is "connect from anywhere", which is the opposite of unset -- and a
  //dash here would read as "not configured", which sounds harmless and is not
  if (column.format === "ips" && row.loginId != null && !row.allowedIps.length) {
    return <span className="text-muted-foreground">any</span>;
  }

  const value = column.from(row);
  if (value == null || value === "") {
    //a product of "—" is a login that names none, which is a real state rather than missing data
    return <span className="text-muted-foreground">—</span>;
  }

  //the count is the door to the tariff, the same way the system id is the door to the login. A zero
  //links too -- "no rules yet" is exactly when somebody wants to go and set some
  if (column.id === "rules") {
    return (
      <Link
        href={accountHref(row.id, "tariff")}
        className="tabular-nums text-primary hover:underline"
      >
        {String(value)}
      </Link>
    );
  }

  switch (column.format) {
    case "product":
    case "ips":
      return <span className="font-mono text-sm">{String(value)}</span>;

    //every pair, one per line. A row with four TLVs is four lines tall, which is the cost of not
    //hiding what a login stamps behind a count
    case "tlvs":
      //a chip that opens the pairs, so a long entity id does not set the column's width
      return <TlvStamps pairs={row.tlvs} subject={row.systemId ?? undefined} />;

    case "billsTo":
      return (
        <span className="whitespace-nowrap text-sm">
          {String(value)}
          {row.billsToFallback === "systemId" && (
            <span className="block text-xs text-muted-foreground">from the system ID</span>
          )}
        </span>
      );
    case "type":
      return <Badge variant="outline">{String(value)}</Badge>;
    case "auth":
      //a login with neither a password nor an api key authenticates nothing
      return value === "none"
        ? <Badge variant="destructive">no secret</Badge>
        : <span className="text-sm text-muted-foreground">{String(value)}</span>;
    case "loginStatus":
      return value === "disabled"
        ? <Badge variant="outline">disabled</Badge>
        : <span className="text-sm text-muted-foreground">enabled</span>;
    case "time":
      return (
        <span className="whitespace-nowrap tabular-nums" suppressHydrationWarning>
          {formatTimestamp(String(value))}
        </span>
      );
    case "number":
      return <span className="tabular-nums">{String(value)}</span>;
    default:
      return <span>{String(value)}</span>;
  }
}

export function Flags({ row, bare = false }: { row: AccountLoginRow; bare?: boolean }) {
  const badges = (
    <>
      {!row.catalogued && <Badge variant="outline">unnamed</Badge>}
      {!row.listed && <Badge variant="outline">disabled</Badge>}
      {row.collides && <Badge variant="destructive">also a vendor</Badge>}
    </>
  );
  if (bare) {
    return <span className="inline-flex flex-wrap gap-1.5">{badges}</span>;
  }
  return <span className="ml-2 inline-flex flex-wrap gap-1.5 align-middle">{badges}</span>;
}
