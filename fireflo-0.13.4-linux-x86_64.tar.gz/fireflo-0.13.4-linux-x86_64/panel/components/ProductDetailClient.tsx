"use client";
import { useEffect, useState } from "react";
import { Pager } from "@/components/Pager";
import { usePaging } from "@/components/usePaging";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";
import { Figures, HealthStrip } from "./CardBits";
import { useConfirmChange, useConfirmDelete } from "./ConfirmProvider";
import { scopeHref } from "./PricingShell";
import { useProductsData } from "./ProductsShell";
import { StatTile } from "@/components/ui/stat-tile";
import { useCredentials } from "./useCredentials";
import type { ProductSummary } from "@/lib/product-types";
import { DEFAULT_SCOPE, scopeKind, type KnownScopes, type ProductScopeSummary } from "@/lib/rate-types";
import { cn } from "@/lib/utils";

/**
 * One product: what it is, who pays for it and what it costs, and the logins that select it.
 *
 * <p>The pricing here is a summary from one count-only request. The prices themselves are edited on
 * the Pricing page narrowed to this product -- one editor, not two that can disagree about how a
 * scope is saved.
 */
export function ProductDetailClient({ name }: { name: string }) {
  const data = useProductsData();
  const router = useRouter();
  const confirm = useConfirmChange();
  const confirmDelete = useConfirmDelete();
  const product = data.products.find((p) => p.name === name);

  if (!product) {
    return data.loading
      ? <p className="text-sm text-muted-foreground">Loading…</p>
      : (
        <EmptyState>
          No product is described as <code className="font-mono">{name}</code>.{" "}
          <Link href="/cp/products" className="text-primary hover:underline">All products →</Link>
        </EmptyState>
      );
  }

  const wired = product.ruleCount > 0 || product.credentialCount > 0;
  const busy = data.busy === product.name;
  return (
    <>
      <section className={cn("min-w-0 rounded-xl border border-border bg-card", !product.enabled && "opacity-80")}>
        <header className="flex flex-wrap items-center gap-2.5 border-b border-border px-4 py-3 sm:px-5">
          {/* the code is the identity: it is what a bind sends and what every rule names */}
          <span className={cn("rounded-md px-2 py-0.5 font-mono text-xs font-bold", product.enabled ? "bg-success-soft text-success" : "bg-muted text-muted-foreground")}>
            {product.name}
          </span>
          <h2 className="text-entity">{product.label || product.name}</h2>
          <span className="ml-auto flex flex-wrap gap-1.5">
            <Button variant="outline" size="sm" onClick={() => data.edit(product)}>Edit</Button>
            {data.advanced && (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  disabled={busy}
                  onClick={async () => {
                    const ok = await confirm({
                      title: product.enabled ? `Unlist ${product.name}` : `List ${product.name}`,
                      consequence: product.enabled
                        ? `${product.name} is marked unlisted in the catalogue and the panel warns when a login names it. `
                          + "A panel-side flag only: the gateway goes on accepting and pricing traffic for it."
                        : `${product.name} is listed in the catalogue again.`,
                      confirmLabel: product.enabled ? "Unlist" : "List",
                      tone: "caution",
                    });
                    if (ok) await data.setEnabled(product.name, !product.enabled);
                  }}
                >
                  {product.enabled ? "Unlist" : "List"}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-destructive"
                  disabled={busy}
                  onClick={async () => {
                    const ok = await confirmDelete({
                      title: `Delete product ${product.name}`,
                      consequence: describeProductRemoval(product),
                      confirmLabel: "Delete this product",
                    });
                    if (ok && await data.remove(product.name)) router.push("/cp/products");
                  }}
                >
                  Delete
                </Button>
              </>
            )}
          </span>
        </header>
        <div className="space-y-3 px-4 py-3 sm:px-5">
          <p className="text-sm text-muted-foreground">{product.description || "No description yet."}</p>
          <div className="flex flex-wrap gap-1">
            <Badge variant={product.enabled ? "success" : "outline"}>{product.enabled ? "Listed" : "Unlisted"}</Badge>
            {/* traffic deliberately going unchecked is worth seeing, and only while it is actually in
                effect -- an unlisted product is not exempt */}
            {product.enabled && (
              <Badge variant={product.whitelistEnabled ? "success" : "warning"}>
                {product.whitelistEnabled ? "Whitelist checked" : "Not whitelist checked"}
              </Badge>
            )}
            {!wired && <Badge variant="outline">Nothing prices or selects it</Badge>}
          </div>
          <Figures
            figures={[
              { value: product.ruleCount, label: product.ruleCount === 1 ? "rule" : "rules" },
              { value: product.scopeCount, label: product.scopeCount === 1 ? "scope" : "scopes" },
              { value: product.credentialCount, label: product.credentialCount === 1 ? "login" : "logins" },
            ]}
          />
        </div>
      </section>

      <PricingSummary name={product.name} />
      <ProductLogins name={product.name} />
    </>
  );
}

/** Who pays for the product and what it costs, with the way into the Pricing page narrowed to it. */
function PricingSummary({ name }: { name: string }) {
  const [state, setState] = useState<{ scopes: ProductScopeSummary[]; known: KnownScopes } | null>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    let live = true;
    fetch(`/api/control/products/${encodeURIComponent(name)}/pricing`, { cache: "no-store" })
      .then(async (res) => {
        const json = await res.json();
        if (!live) return;
        if (res.ok) setState({ scopes: json.data.scopes, known: json.data.known });
        else setFailed(true);
      })
      .catch(() => live && setFailed(true));
    return () => {
      live = false;
    };
  }, [name]);

  const loading = state === null && !failed;
  const scopes = state?.scopes ?? [];
  const known = state?.known ?? { vendors: [], accounts: [] };
  const kind = (s: string) => scopeKind(s, known);
  const priced = new Set(scopes.map((s) => s.scope));
  const noCost = known.vendors.filter((v) => !priced.has(v));
  const accountsPriced = scopes.filter((s) => kind(s.scope) === "price").length;
  const dflt = scopes.find((s) => s.scope === DEFAULT_SCOPE);
  const pricingHref = `/cp/pricing?product=${encodeURIComponent(name)}`;

  return (
    <section className="min-w-0 rounded-xl border border-border bg-card">
      <header className="flex flex-wrap items-baseline gap-2 border-b border-border px-4 py-3 sm:px-5">
        <h2 className="text-title">Pricing</h2>
        <span className="text-xs text-muted-foreground">for {name}</span>
        <Link href={pricingHref} className="ml-auto text-sm text-primary hover:underline">Open in Pricing →</Link>
      </header>
      <div className="space-y-3 px-4 py-4 sm:px-5">
        {failed ? (
          <p className="text-sm text-muted-foreground">The pricing summary could not be read. <Link href={pricingHref} className="text-primary hover:underline">Open in Pricing →</Link></p>
        ) : (
          <div className="grid gap-3 sm:grid-cols-3">
            <StatTile
              label={`Default for ${name}`}
              value={dflt ? (dflt.specificToProduct ? `${dflt.rules} ${dflt.rules === 1 ? "price" : "prices"}` : "Any product") : "Not set"}
              loading={loading}
              tone={dflt ? "default" : "negative"}
            />
            <StatTile label="Accounts with their own price" value={`${accountsPriced} of ${known.accounts.length}`} loading={loading} />
            <StatTile
              label="Vendors with a cost"
              value={`${known.vendors.length - noCost.length} of ${known.vendors.length}`}
              loading={loading}
              tone={noCost.length ? "negative" : "default"}
            />
          </div>
        )}
        {!loading && !failed && !dflt && (
          <HealthStrip tone="destructive"
            action={<Link href={scopeHref(DEFAULT_SCOPE, { new: true, product: name })} className="text-sm font-semibold text-primary hover:underline">Set what everyone pays →</Link>}>
            Nothing sets a default for {name}, so an account without its own price sends it <strong>unpriced and uncharged</strong>.
          </HealthStrip>
        )}
      </div>
    </section>
  );
}

const LOGINS_PAGE_SIZE = 12;

/** The logins whose default product this is -- what a bind gets when it names none. */
function ProductLogins({ name }: { name: string }) {
  const { credentials, loading, disabled } = useCredentials();
  const logins = credentials.filter((c) => c.product === name);
  //a product carried by a hundred logins listed them all on one page; same page size as the other lists
  const { page, pages, shown, setPage } = usePaging(logins, LOGINS_PAGE_SIZE);
  return (
    <section className="min-w-0 rounded-xl border border-border bg-card">
      <header className="flex flex-wrap items-baseline gap-2 border-b border-border px-4 py-3 sm:px-5">
        <h2 className="text-title">Logins that select it</h2>
        <span className="text-xs text-muted-foreground">their default product</span>
        <Link href={`/cp/cdrs?product=${encodeURIComponent(name)}`} className="ml-auto text-sm text-primary hover:underline">
          Messages sent under {name} →
        </Link>
      </header>
      {disabled ? (
        <p className="px-4 py-3 text-sm text-muted-foreground sm:px-5">Logins are not kept in this panel&rsquo;s database.</p>
      ) : loading ? (
        <p className="px-4 py-3 text-sm text-muted-foreground sm:px-5">Loading…</p>
      ) : !logins.length ? (
        <p className="px-4 py-3 text-sm text-muted-foreground sm:px-5">No login has {name} as its default product. A message is priced under {name} only when its login carries it, so until a login does, rules for {name} price nothing. Set it under Accounts → Logins.</p>
      ) : (
        <>
        <ul className="divide-y divide-border">
          {shown.map((c) => (
            <li key={c.id} className={cn("flex flex-wrap items-center gap-2 px-4 py-2.5 text-sm sm:px-5", !c.enabled && "opacity-60")}>
              <span className="font-mono">{c.systemId ?? `#${c.id}`}</span>
              <Badge variant="outline">{c.type}</Badge>
              {!c.enabled && <Badge variant="outline">Disabled</Badge>}
              {c.billingAccount && <span className="text-muted-foreground">account <span className="font-mono">{c.billingAccount}</span></span>}
              {c.billingAccount && (
                <Link href={`/cp/accounts/${encodeURIComponent(c.billingAccount)}/logins`} className="ml-auto text-primary hover:underline">Logins →</Link>
              )}
            </li>
          ))}
        </ul>
        {pages > 1 && (
          <div className="border-t border-border px-4 py-2 sm:px-5">
            <Pager page={page} pages={pages} total={logins.length} noun="logins" onPage={setPage} />
          </div>
        )}
        </>
      )}
    </section>
  );
}

/**
 * What deleting a product actually costs.
 *
 * <p>Counts logins as well as rules. This once counted rules alone while the card above it displayed
 * the credential count, so a product no rule priced but a login still selected was offered for
 * deletion with nothing said — and the server allowed it.
 *
 * <p>The whitelist exemption is stated whenever it is in effect, not only when a rule happens to
 * price the product: losing the exemption is about traffic, and traffic comes from the logins.
 */
function describeProductRemoval(product: ProductSummary): string {
  const users = [
    product.ruleCount ? `prices ${product.ruleCount} rule(s)` : null,
    product.credentialCount ? `is the default product on ${product.credentialCount} login(s)` : null,
  ].filter(Boolean).join(", and ");

  //since gateway V1.56.0 those are foreign keys, so the server refuses the delete while they exist
  const still = users
    ? `'${product.name}' still ${users}, so it cannot be deleted until those use another product. `
      + "Unlisting it stops it being sold without deleting it. "
    : "";
  const whitelist = product.whitelistEnabled
    ? ""
    : "It is exempt from sender ID and content checking, and deleting it ends that: this traffic "
      + "goes back under the whitelist and may start being refused.";

  return `${still}${whitelist}` || "Only the description goes; nothing prices or selects it.";
}
