"use client";
import { useEffect, useSyncExternalStore } from "react";
import { useLiveGatewayStores, type HistoryPoint } from "./LiveGatewayProvider";

export type { HistoryPoint };

/**
 * The gateway's runtime metrics, polled.
 *
 * <p>A subscription to the one `/q/metrics` poll `LiveGatewayProvider` runs per page, like
 * {@link useHealth}: a fixed endpoint with no range, a short interval, a pause while the tab is
 * hidden, and — importantly — **the last snapshot is kept when a poll fails**. Blanking the page on
 * one failed request would make a working gateway look like it had disappeared.
 *
 * <p>It also keeps a small rolling history, which is the only way to draw a trend or turn a
 * cumulative counter into a rate: the exposition format carries totals, not rates. That history
 * starts when the first consumer on the page subscribes and is gone when the page closes, so
 * anything drawn from it must say so.
 */
export function useRuntimeMetrics() {
  const { runtime: store } = useLiveGatewayStores();
  useEffect(() => store.acquire(), [store]);
  const state = useSyncExternalStore(store.subscribe, store.getSnapshot, store.getInitialSnapshot);
  return {
    snapshot: state.snapshot,
    history: state.history,
    error: state.error,
    loading: state.loading,
    reload: store.refresh,
  };
}
