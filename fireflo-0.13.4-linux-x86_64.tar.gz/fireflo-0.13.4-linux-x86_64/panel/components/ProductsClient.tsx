"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { EmptyState } from "@/components/ui/empty-state";
import { productHref, useProductsData } from "./ProductsShell";

/**
 * `/cp/products`: opens the first product, so the right-hand column is never an empty frame. With
 * none described yet it says so; Add product and the "Not described" card are beside it.
 */
export function ProductsClient() {
  const { products, loading } = useProductsData();
  const router = useRouter();
  const first = products[0]?.name;
  useEffect(() => {
    if (first) router.replace(productHref(first));
  }, [first, router]);

  if (loading || first) return <p className="text-sm text-muted-foreground">Loading…</p>;
  return <EmptyState>No products described yet. Add one, or describe a name already in use.</EmptyState>;
}
