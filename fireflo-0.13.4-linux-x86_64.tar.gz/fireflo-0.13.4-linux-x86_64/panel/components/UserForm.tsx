"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { SettingsSection } from "@/components/ui/settings-section";
import { SettingsRow } from "@/components/ui/settings-row";
import { ErrorCard } from "@/components/FormNotices";
import { PasswordFields } from "@/components/PasswordFields";
import { ADMIN_ROLE, CUSTOMER_ROLE, OPERATOR_ROLE } from "@/lib/roles";
import { type NewUserInput, type Role, validateNewUser } from "@/lib/user-types";

/**
 * Creating one user.
 *
 * <p>The role decides the rest of the form: a customer needs an account and may have no password
 * (they can sign in by emailed link); an admin or operator has no account and must have one. The
 * password is typed twice with the meter, and the admin hands it over out of band -- nothing here
 * shows it again.
 */
export function UserForm({
  fixedAccountId,
  onCreate,
  onDone,
  onCancel,
}: {
  /** When set, the form is on an account page: role is customer and the account is this one. */
  fixedAccountId?: string | null;
  onCreate: (input: NewUserInput) => Promise<string | null>;
  onDone: () => void;
  onCancel: () => void;
}) {
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<Role>(fixedAccountId ? CUSTOMER_ROLE : OPERATOR_ROLE);
  const [accountId, setAccountId] = useState(fixedAccountId ?? "");
  const [password, setPassword] = useState("");
  const [passwordReady, setPasswordReady] = useState(false);
  const [withPassword, setWithPassword] = useState(!fixedAccountId);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const isCustomer = role === CUSTOMER_ROLE;
  const needsPassword = !isCustomer || withPassword;
  const input: NewUserInput = {
    email,
    role,
    accountId: isCustomer ? accountId : null,
    password: needsPassword ? password : null,
  };
  const shapeProblem = validateNewUser(input);
  const canSubmit = !shapeProblem && (!needsPassword || passwordReady) && !saving;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (shapeProblem) {
      setError(shapeProblem);
      return;
    }
    setSaving(true);
    setError("");
    const failed = await onCreate(input);
    setSaving(false);
    if (failed) {
      setError(failed);
      return;
    }
    onDone();
  }

  return (
    <form onSubmit={submit} className="max-w-3xl">
      <SettingsSection
        id="new-user"
        title="New user"
        action={
          <>
            <Button type="button" size="sm" variant="ghost" onClick={onCancel}>Cancel</Button>
            <Button type="submit" size="sm" disabled={!canSubmit}>{saving ? "Creating…" : "Create user"}</Button>
          </>
        }
      >
          <SettingsRow label="Email" htmlFor="user-email" help="This is what they sign in with.">
            <Input
              id="user-email"
              type="email"
              value={email}
              autoFocus
              autoComplete="off"
              onChange={(e) => setEmail(e.target.value)}
            />
          </SettingsRow>

          {!fixedAccountId && (
            <SettingsRow
              label="Role"
              htmlFor="user-role"
              help={
                role === ADMIN_ROLE
                  ? "Runs the gateway and manages who else may sign in."
                  : role === OPERATOR_ROLE
                    ? "Runs the gateway. Cannot see or change users."
                    : "Signs in to the customer portal for one account."
              }
            >
              <Select id="user-role" value={role} onChange={(e) => setRole(e.target.value as Role)}>
                <option value={OPERATOR_ROLE}>Operator</option>
                <option value={ADMIN_ROLE}>Admin</option>
                <option value={CUSTOMER_ROLE}>Customer</option>
              </Select>
            </SettingsRow>
          )}

          {isCustomer && !fixedAccountId && (
            <SettingsRow label="Account" htmlFor="user-account" help="The account id, as on the Accounts page.">
              <Input id="user-account" value={accountId} onChange={(e) => setAccountId(e.target.value)} />
            </SettingsRow>
          )}

          {isCustomer && (
            <SettingsRow
              label="Set a password now"
              labelId="user-with-password"
              help="Without one they sign in by emailed link, and can set a password from the portal."
            >
              <div className="flex md:justify-end">
                <Switch checked={withPassword} onChange={setWithPassword} aria-labelledby="user-with-password" />
              </div>
            </SettingsRow>
          )}

          {needsPassword && (
            <SettingsRow label="Password" labelId="user-password" help="At least 12 characters. A sentence works well." wide>
            <PasswordFields
              value={password}
              email={email}
              labels={{ password: "Password", confirm: "Confirm password" }}
              onChange={(pw, ready) => {
                setPassword(pw);
                setPasswordReady(ready);
              }}
            />
            </SettingsRow>
          )}

          {error && <div className="p-4"><ErrorCard error={error} /></div>}
      </SettingsSection>
    </form>
  );
}
