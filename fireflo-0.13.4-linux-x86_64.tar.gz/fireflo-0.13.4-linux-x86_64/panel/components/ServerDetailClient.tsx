"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft, Unplug } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClasses } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Tabs } from "@/components/ui/tabs";
import { AdvancedToggle } from "./AdvancedToggle";
import { CardActions, FactGrid, Figures, HealthStrip } from "./CardBits";
import { BindList, ConnectionStatus, LiveTrafficControls, useConfirmEnabled } from "./ConnectionStatus";
import { useConfirmChange, useConfirmDelete } from "./ConfirmProvider";
import { CleanQueueButton } from "./QueueCleanDialog";
import { ForceDisconnectDialog } from "./ForceDisconnectDialog";
import { ListenerAccountTraffic } from "./ListenerAccountTraffic";
import { ProductReadiness } from "./ProductReadiness";
import { SettingsList } from "./SettingsList";
import { WorkerForm } from "./WorkerForm";
import { useHealth } from "./useHealth";
import { useWorkers } from "./useWorkers";
import { useAdvanced } from "@/hooks/useAdvanced";
import { cn } from "@/lib/utils";
import { verdictFor } from "@/lib/worker-verdict";
import { KIND, isOn, trafficKey } from "@/lib/worker-types";
import { SECTIONS, type SectionId } from "@/lib/setting-fields";
import { EmptyState } from "@/components/ui/empty-state";
import { PeakLine } from "./PeakLine";
import { formatTps } from "@/lib/tps-format";

type Tab = "status" | "settings" | "sessions";

/**
 * One listener, in full -- the server twin of {@link VendorDetailClient}, with the same shape:
 * the traffic controls in the header, tabs on the left, a rail of what identifies it on the right.
 * No cost rates and no error codes, because a listener is charged nothing and dials nobody.
 */
export function ServerDetailClient({ name }: { name: string }) {
  const {
    workers, error, errorFor, loading, busy, busyLabel,
    load, setEnabled, setProperty, restart, remove,
  } = useWorkers(KIND.server);
  const { health, byFullName, tpsHistory, reload: reloadHealth } = useHealth();
  const [tab, setTab] = useState<Tab>("status");
  const [editing, setEditing] = useState(false);
  const [advanced, setAdvanced] = useAdvanced("server");
  const [forcing, setForcing] = useState(false);
  const [focus, setFocus] = useState<SectionId | undefined>();
  const confirm = useConfirmChange();
  const confirmDelete = useConfirmDelete();
  const confirmEnabled = useConfirmEnabled();

  //Restart drops every bound client: confirmed wherever it is offered, after a save as well
  const confirmRestart = (listener: string, bound?: number | null) => confirm({
    title: `Restart ${listener}?`,
    consequence: `Every client bound to it${bound ? ` (${bound} now)` : ""} is disconnected and must reconnect, on the saved settings — the listen port among them. Messages in flight are kept.`,
    confirmLabel: `Restart ${listener}`,
    tone: "caution",
  });

  //`?edit=1&open=tlvs`: arrive in the edit form with one section open, which is where a warning's
  //Fix link sends you. Read once and taken out of the address, so a reload shows the page itself
  useEffect(() => {
    const q = new URLSearchParams(window.location.search);
    if (q.get("edit") !== "1") {
      return;
    }
    const open = q.get("open");
    //eslint-disable-next-line react-hooks/set-state-in-effect -- the address is only readable after mount
    setFocus(SECTIONS.some((s) => s.id === open) ? (open as SectionId) : undefined);
    setEditing(true);
    window.history.replaceState(null, "", window.location.pathname);
  }, []);

  const worker = workers.find((w) => w.name === name);

  if (!worker) {
    return (
      <div className="space-y-5">
        <Link href="/cp/servers" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Servers
        </Link>
        <EmptyState>
          {loading ? "Loading…" : error || `No listener called '${name}'.`}
        </EmptyState>
      </div>
    );
  }

  if (editing) {
    return (
      <WorkerForm
        type={KIND.server}
        worker={worker}
        focus={focus}
        onCancel={() => setEditing(false)}
        onSaved={async () => {
          setEditing(false);
          await load();
        }}
        onRestart={async () => {
          if (!(await confirmRestart(worker.name))) {
            return;
          }
          setEditing(false);
          await restart(worker.name);
        }}
      />
    );
  }

  const key = trafficKey(worker);
  const live = byFullName.get(key);
  const verdict = verdictFor(worker, byFullName, KIND.server);
  const suspended = isOn(worker, "suspend");
  const paused = isOn(worker, "pause");
  const port = prop(worker, "srv.port");
  const ceiling = Number(prop(worker, "srv.maxConnections"));
  const capacity = Number.isFinite(ceiling) && ceiling > 0 ? { kind: "ceiling" as const, value: ceiling } : null;

  const tabs: { id: Tab; label: string }[] = [
    { id: "status", label: "Status" },
    { id: "settings", label: `Listener settings · ${worker.properties.length}` },
    { id: "sessions", label: `Connections · ${live?.sessions?.length ?? 0}` },
  ];

  return (
    <div className="space-y-5">
      <Link href="/cp/servers" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Servers
      </Link>

      <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_300px]">
      <Card className={cn("min-w-0", verdict.tone === "destructive" && "border-destructive")}>
        <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
          <span className="text-entity">{worker.name}</span>
          {port && <span className="font-mono text-xs text-muted-foreground">port {port}</span>}
          <Badge variant={verdict.tone}>{verdict.label}</Badge>
          {worker.label && <span className="text-xs text-muted-foreground">{worker.label}</span>}
          <CardActions>
            <AdvancedToggle on={advanced} onChange={setAdvanced} />
            <Link href={`/cp/cdrs?systemId=${encodeURIComponent(worker.name)}`} className={buttonClasses({ variant: "outline", size: "sm" })}>
              Messages →
            </Link>
            {advanced && (
              <Button
                variant="ghost"
                size="sm"
                className="text-destructive hover:text-destructive"
                disabled={busy === worker.name}
                onClick={async () => {
                  const ok = await confirmDelete({
                    title: `Delete the listener ${worker.name}?`,
                    consequence: `${worker.name} and its settings are deleted, and every customer bound to it is disconnected.`,
                    confirmLabel: `Delete ${worker.name}`,
                  });
                  if (!ok) {
                    return;
                  }
                  await remove(worker.name);
                  window.location.assign("/cp/servers");
                }}
              >
                Delete
              </Button>
            )}
          </CardActions>
        </CardHeader>
        <CardContent className="space-y-4 pt-3">
          {errorFor === worker.name && error && <HealthStrip tone="destructive">{error}</HealthStrip>}

          <Tabs label="Listener" items={tabs} active={tab} onSelect={setTab} />

          {tab === "status" && (
            <div className="space-y-3">
              <ConnectionStatus
                type={KIND.server}
                live={live}
                verdict={verdict}
                paused={paused}
                capacity={capacity}
                windowSeconds={health?.tps_window_seconds}
                tpsHistory={tpsHistory.get(key)}
              />
              {/* who is on the listener and whether their receipts are coming back: the reading an
                  operator brings here, which the bind counts above cannot give */}
              <ListenerAccountTraffic health={health} live={live} />
              {/* what would stop binding if this listener began requiring a product: the decision is
                  made in its settings, so the answer sits beside them */}
              <ProductReadiness />
            </div>
          )}

          {tab === "settings" && (
            <div className="space-y-4">
              <SettingsList
                type={KIND.server}
                properties={worker.properties}
                empty="No settings — the gateway will use its own defaults, including the listen port."
              />
              {advanced && !!worker.properties.length && (
                <div className="border-t border-dashed border-border pt-3">
                  <p className="mb-2 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">Every stored key</p>
                  <FactGrid facts={worker.properties.map((p) => ({ label: p.key, value: p.value, mono: true }))} />
                </div>
              )}
            </div>
          )}

          {tab === "sessions" && <BindList type={KIND.server} live={live} />}
        </CardContent>
        {/* actions on the listener as a whole sit at the foot, as on the vendor page: Edit and
            Disable on the left, and the traffic controls take the rest of the row and right-align
            themselves */}
        <CardFooter className="border-t border-border pt-3">
          <Button variant="outline" size="sm" onClick={() => setEditing(true)}>Edit</Button>
          {/* Disable closes the listener and drops every bound customer, so it is drawn as the
              danger it is; Enable only starts it, and stays an ordinary button */}
          <Button
            variant={worker.enabled ? "destructive" : "outline"}
            size="sm"
            disabled={busy === worker.name}
            onClick={async () => {
              if (await confirmEnabled(worker.name, KIND.server, !worker.enabled)) {
                await setEnabled(worker.name, !worker.enabled);
              }
            }}
          >
            {worker.enabled ? "Disable" : "Enable"}
          </Button>
          {/* Restart is the only way a listen port, TLS or thread setting reaches a running listener
              (the gateway reads them when it builds the server). It is not among the traffic
              controls because it drops every bound client: a confirmed action, not a toggle */}
          {worker.enabled && (
            <Button
              variant="outline"
              size="sm"
              disabled={busy === worker.name}
              onClick={async () => {
                if (await confirmRestart(worker.name, live?.bound)) {
                  await restart(worker.name);
                }
              }}
            >
              {busy === worker.name && busyLabel === "Restart" ? "Restarting…" : "Restart"}
            </Button>
          )}
          {/* beside Restart, the other action that drops customers: an act on the listener's
              binds, so it sits with the listener's actions rather than in the header */}
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setForcing(true)}
            title="Drop every session of an IP, an account or a login on this listener, and optionally keep them out">
            <Unplug className="h-3.5 w-3.5" aria-hidden /> Force disconnect
          </Button>
          <CleanQueueButton
            worker={key}
            listener
            waiting={!!live && ((live.queue_depth ?? 0) + (live.retry_queue_depth ?? 0) + (live.held_inbound ?? 0) > 0 || suspended || paused)}
            onDone={reloadHealth}
          />
          <LiveTrafficControls
            name={worker.name}
            type={KIND.server}
            live={live}
            verdict={verdict}
            suspended={suspended}
            paused={paused}
            busy={busy === worker.name}
            busyLabel={busyLabel}
            onSuspend={(on) => setProperty(worker.name, "suspend", on, on ? "Stop sending" : "Resume sending")}
            onPause={(on) => setProperty(worker.name, "pause", on, on ? "Hold" : "Release hold")}
          />
        </CardFooter>
      </Card>

      <div className="min-w-0 space-y-4 xl:sticky xl:top-4">
        <Card>
          <CardHeader className="flex flex-row items-center gap-2 space-y-0 border-b border-border">
            <span className="text-sm font-medium">Right now</span>
            <span className="text-xs text-muted-foreground">refreshed every 10s</span>
          </CardHeader>
          <CardContent className="space-y-3 pt-3">
            <Badge variant={verdict.tone}>{verdict.label}</Badge>
            {verdict.detail && <p className="text-xs text-muted-foreground">{verdict.detail}</p>}
            <Figures
              figures={[
                { value: live?.bound ?? "—", label: capacity ? `connected of ${capacity.value}` : "connected" },
                { value: live?.held_inbound ?? "—", label: "held inbound", tone: live?.held_inbound ? "warning" : "default" },
                { value: live?.tps_measured != null ? formatTps(live.tps_measured) : "—", label: "tps now" },
              ]}
            />
            <PeakLine peak={live?.tps_peak} scope={live?.name} onReset={reloadHealth} />
            {live?.last_error && (
              <HealthStrip tone="destructive">
                <span className="line-clamp-3">{live.last_error}</span>
              </HealthStrip>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center gap-2 space-y-0 border-b border-border">
            <span className="text-sm font-medium">Listener</span>
          </CardHeader>
          <CardContent className="pt-3">
            <FactGrid
              columns={2}
              facts={[
                //the address customers are told, not a bind address: the listener binds every interface
                { label: "Public IP", value: prop(worker, "srv.public.host") || "not set", mono: !!prop(worker, "srv.public.host"), muted: !prop(worker, "srv.public.host") },
                { label: "Port", value: port || "default", mono: !!port, muted: !port },
                { label: "Max connections", value: prop(worker, "srv.maxConnections") || "default", muted: !prop(worker, "srv.maxConnections") },
                { label: "Per IP", value: prop(worker, "srv.maxConnectionsPerIP") || "default", muted: !prop(worker, "srv.maxConnectionsPerIP") },
                { label: "System ID", value: prop(worker, "srv.systemId") || "—", mono: !!prop(worker, "srv.systemId"), muted: !prop(worker, "srv.systemId") },
                //a stored 0 is the gateway's "unlimited", and so is nothing stored at all
                { label: "Rate limit", value: Number(prop(worker, "tps")) > 0 ? `${prop(worker, "tps")} tps` : "none", muted: !(Number(prop(worker, "tps")) > 0) },
                { label: "TLS", value: prop(worker, "srv.tls.enabled") === "true" ? `on, port ${prop(worker, "srv.tls.port") || "?"}` : "off", muted: prop(worker, "srv.tls.enabled") !== "true" },
                { label: "Stop sending", value: suspended ? "on" : "off", muted: !suspended },
                { label: "Enabled", value: worker.enabled ? "yes" : "no", muted: !worker.enabled },
              ]}
            />
          </CardContent>
        </Card>
      </div>
      </div>
      {forcing && <ForceDisconnectDialog listener={worker.name} onClose={() => setForcing(false)} />}
    </div>
  );
}

function prop(worker: { properties: { key: string; value: string }[] }, key: string): string {
  return worker.properties.find((p) => p.key === key)?.value ?? "";
}
