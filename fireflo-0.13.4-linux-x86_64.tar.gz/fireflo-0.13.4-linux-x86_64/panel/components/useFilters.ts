"use client";
import { useCallback, useEffect, useState } from "react";
import type { Filter, FilterInput } from "@/lib/filter-types";

/**
 * The filter library.
 *
 * <p>Shaped like `useProducts`, with one difference worth naming: a change here **does** reach the
 * gateway. `app_filter` is read by `DbFilterLoader` on every configuration poll, so saving a filter
 * changes how rules match within thirty seconds — unlike the product or account catalogues, which
 * the gateway never reads at all.
 */
export function useFilters() {
  const [filters, setFilters] = useState<Filter[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/control/filters", { cache: "no-store" });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      setFilters(json.data.filters as Filter[]);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const save = useCallback(
    async (input: FilterInput): Promise<string | null> => {
      setBusy(input.name);
      try {
        const res = await fetch("/api/control/filters", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(input),
        });
        const json = await res.json().catch(() => null);
        if (!res.ok) {
          return json?.error ?? `Request failed (${res.status})`;
        }
        await load();
        return null;
      } finally {
        setBusy("");
      }
    },
    [load]
  );

  const remove = useCallback(
    async (name: string): Promise<string | null> => {
      setBusy(name);
      try {
        const res = await fetch(`/api/control/filters/${encodeURIComponent(name)}`, {
          method: "DELETE",
        });
        const json = await res.json().catch(() => null);
        if (!res.ok) {
          //the 409 from a filter still in use is the common case, not an exception
          return json?.error ?? `Request failed (${res.status})`;
        }
        await load();
        return null;
      } finally {
        setBusy("");
      }
    },
    [load]
  );

  return { filters, error, loading, busy, load, save, remove, setError };
}
