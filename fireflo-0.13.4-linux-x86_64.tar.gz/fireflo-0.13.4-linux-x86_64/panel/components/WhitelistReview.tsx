"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import type { ApprovalStatus } from "@/lib/whitelist-types";

/**
 * Approving or refusing what a customer asked for, beside the thing they asked for.
 *
 * <p>Deliberately not a queue page. A sender ID is approved or refused in the context of the
 * account's other registrations and its enforcement mode, and a central list would mean deciding
 * without either in view. The cost of that choice is real and worth knowing: nothing announces a
 * request, so it waits until somebody opens the account.
 *
 * <p>Refusing asks for a reason before it will send. The customer is shown that text and nothing
 * else about the decision, so a blank one leaves them with a registration that does not work and no
 * idea what to change. The route enforces this too — a form is not a place to keep a rule.
 */
export function WhitelistReview({
  status,
  busy,
  onDecide,
}: {
  status: ApprovalStatus;
  busy: boolean;
  onDecide: (status: "APPROVED" | "REJECTED", reviewNote?: string) => void | Promise<void>;
}) {
  const [refusing, setRefusing] = useState(false);
  const [reason, setReason] = useState("");

  if (status !== "PENDING") {
    return null;
  }

  if (refusing) {
    return (
      <span className="flex flex-wrap items-center gap-1.5">
        <Input
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          className="h-6 w-56 text-sm"
          placeholder="Why? The customer sees this."
          autoFocus
        />
        <Button
          variant="destructive"
          size="sm"
          className="h-6 px-2"
          disabled={busy || !reason.trim()}
          onClick={() => onDecide("REJECTED", reason.trim())}
        >
          {busy ? "…" : "Refuse"}
        </Button>
        <Button variant="ghost" size="sm" className="h-6 px-2" onClick={() => setRefusing(false)}>
          Cancel
        </Button>
      </span>
    );
  }

  return (
    <span className="flex items-center gap-1.5">
      <Button size="sm" className="h-6 px-2" disabled={busy}
        onClick={() => onDecide("APPROVED")}>
        {busy ? "…" : "Approve"}
      </Button>
      <Button variant="ghost" size="sm" className="h-6 px-2 text-destructive"
        disabled={busy} onClick={() => setRefusing(true)}>
        Refuse
      </Button>
    </span>
  );
}

/**
 * What state a registration is in, from the operator's side.
 *
 * <p>Says nothing for an ordinary approved-and-enabled row: that is the resting state and a badge on
 * every line would be noise that hides the two that matter.
 */
export function WhitelistStatusBadge({
  status,
  enabled,
}: {
  status: ApprovalStatus;
  enabled: boolean;
}) {
  if (status === "PENDING") {
    return <Badge variant="warning">requested</Badge>;
  }
  if (status === "REJECTED") {
    return <Badge variant="destructive">refused</Badge>;
  }
  if (!enabled) {
    return <Badge variant="outline">withdrawn</Badge>;
  }
  return null;
}

/** Requests first, then refusals, then what is in use. A pending row must not be scrolled past. */
export function pendingFirst<T extends { status: ApprovalStatus }>(rows: T[]): T[] {
  const rank = (s: ApprovalStatus) => (s === "PENDING" ? 0 : s === "REJECTED" ? 1 : 2);
  return [...rows].sort((a, b) => rank(a.status) - rank(b.status));
}
