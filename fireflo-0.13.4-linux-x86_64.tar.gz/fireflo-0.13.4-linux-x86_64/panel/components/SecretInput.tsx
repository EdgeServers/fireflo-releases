"use client";
import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { SecretField, SecretState } from "@/lib/secrets";

/**
 * A password or API key, edited without its value ever reaching the browser.
 *
 * <p>Three states, and they are the three the server understands. A stored secret shows as dots and
 * offers **Replace** and **Remove**; the value box only exists once Replace has been pressed. No
 * placeholder string crosses the wire in either direction, which is what makes "leave this alone"
 * and "set it to this text" impossible to confuse.
 */
export function SecretInput({
  id,
  label,
  stored,
  value,
  onChange,
  hint,
  bare = false,
}: {
  id: string;
  label: string;
  /** What the server says is on the row today. */
  stored: SecretState;
  value: SecretField;
  onChange: (next: SecretField) => void;
  hint?: string;
  /** Inside a SettingsRow, which carries the label and the hint itself. */
  bare?: boolean;
}) {
  const [visible, setVisible] = useState(false);

  return (
    <div>
      {!bare && <Label htmlFor={id} className="mb-1.5 block">{label}</Label>}

      {value.state === "kept" ? (
        <div className="flex items-center gap-2">
          <Input id={id} value="••••••••" readOnly disabled className="font-mono" />
          <Button type="button" variant="outline" size="sm"
            onClick={() => onChange({ state: "set", value: "" })}>
            Replace
          </Button>
          <Button type="button" variant="ghost" size="sm"
            onClick={() => onChange({ state: "unset" })}>
            Remove
          </Button>
        </div>
      ) : value.state === "set" ? (
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Input
              id={id}
              type={visible ? "text" : "password"}
              value={value.value}
              onChange={(e) => onChange({ state: "set", value: e.target.value })}
              className="pr-9 font-mono"
              autoComplete="new-password"
            />
            <button
              type="button"
              onClick={() => setVisible((v) => !v)}
              tabIndex={-1}
              aria-label={visible ? `Hide ${label}` : `Show ${label}`}
              className="absolute inset-y-0 right-0 flex w-9 items-center justify-center rounded-r-md text-muted-foreground transition-colors hover:text-foreground"
            >
              {visible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          {stored === "stored" && (
            <Button type="button" variant="ghost" size="sm" onClick={() => onChange({ state: "kept" })}>
              Keep the old one
            </Button>
          )}
        </div>
      ) : (
        <div className="flex items-center gap-2">
          <Input id={id} value="" readOnly disabled placeholder="none" />
          <Button type="button" variant="outline" size="sm"
            onClick={() => onChange({ state: "set", value: "" })}>
            Set
          </Button>
          {stored === "stored" && (
            <Button type="button" variant="ghost" size="sm" onClick={() => onChange({ state: "kept" })}>
              Keep the stored one
            </Button>
          )}
        </div>
      )}

      {hint && !bare && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
      {value.state === "unset" && stored === "stored" && (
        <p className="mt-1 text-xs text-destructive">
          Saving will remove the stored {label.toLowerCase()}.
        </p>
      )}
    </div>
  );
}
