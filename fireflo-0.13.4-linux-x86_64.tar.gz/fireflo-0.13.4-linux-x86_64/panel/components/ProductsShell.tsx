"use client";
import { createContext, useContext, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PageHeader } from "@/components/ui/page-header";
import { Rail, RailCard, RailNote, railItemClass } from "@/components/ui/rail";
import { Select } from "@/components/ui/select";
import { AdvancedToggle } from "./AdvancedToggle";
import { HealthStrip } from "./CardBits";
import { ProductForm } from "./ProductForm";
import { useProducts } from "./useProducts";
import { useAdvanced } from "@/hooks/useAdvanced";
import type { ProductInput, ProductSummary } from "@/lib/product-types";
import { cn } from "@/lib/utils";

/**
 * The product catalogue: every product down the left, the open one beside it.
 *
 * <p>A product is the tariff a customer's bind selects, through `system_type`. The gateway learns it
 * from the wire and never from this table -- so nothing here changes behaviour. What it changes is
 * whether anyone can tell what `premium` was supposed to mean. Prices are kept on the Pricing page,
 * narrowed to the product; this section links there rather than holding a second editor.
 */
export interface ProductsData {
  products: ProductSummary[];
  /** Names in use -- priced or selected by a login -- that no product describes. */
  orphans: string[];
  loading: boolean;
  busy: string;
  advanced: boolean;
  /** Opens the form in the right-hand column. */
  edit: (product: ProductSummary) => void;
  setEnabled: (name: string, enabled: boolean) => Promise<boolean>;
  remove: (name: string) => Promise<boolean>;
}

const Ctx = createContext<ProductsData | null>(null);

export function useProductsData(): ProductsData {
  const value = useContext(Ctx);
  if (!value) throw new Error("useProductsData is used outside the Products layout.");
  return value;
}

export function productHref(name: string): string {
  return `/cp/products/${encodeURIComponent(name)}`;
}

const blank = (name = ""): ProductInput => ({ name, label: "", description: "", enabled: true, whitelistEnabled: true });

export function ProductsShell({ children }: { children: ReactNode }) {
  const { products, orphans, error, loading, busy, load, setEnabled, remove } = useProducts();
  //tied to the page it was opened on, so choosing another product in the rail closes it
  const [opened, setEditing] = useState<{ input: ProductInput; isNew: boolean; at: string } | null>(null);
  const [advanced, setAdvanced] = useAdvanced("products");
  const router = useRouter();
  const pathname = usePathname();
  const editing = opened?.at === pathname ? opened : null;
  const open = pathname.startsWith("/cp/products/") ? decodeURIComponent(pathname.slice("/cp/products/".length)) : null;

  const data: ProductsData = {
    products,
    orphans,
    loading,
    busy,
    advanced,
    edit: (p) => setEditing({
      input: { name: p.name, label: p.label, description: p.description, enabled: p.enabled, whitelistEnabled: p.whitelistEnabled },
      isNew: false,
      at: pathname,
    }),
    setEnabled,
    remove,
  };

  return (
    <Ctx.Provider value={data}>
      <PageHeader
        title="Products"
        description={
          <>
            A product is what a customer&rsquo;s bind asks for as <code className="text-xs">system_type</code>.
            The gateway learns it from the wire; this is where it gets a name and a price.
          </>
        }
        actions={
          <>
            <AdvancedToggle on={advanced} onChange={setAdvanced} />
            <Button onClick={() => setEditing({ input: blank(), isNew: true, at: pathname })} className="gap-2">
              <Plus className="h-4 w-4" />
              Add product
            </Button>
          </>
        }
      />
      {error && <HealthStrip tone="destructive">{error}</HealthStrip>}
      <div className="flex flex-wrap items-start gap-6">
        <ProductsNav
          products={products}
          orphans={orphans}
          loading={loading}
          open={editing?.isNew ? null : open}
          onAdd={() => setEditing({ input: blank(), isNew: true, at: pathname })}
          onDescribe={(name) => setEditing({ input: blank(name), isNew: true, at: pathname })}
        />
        <div className="flex min-w-0 flex-[999_1_560px] flex-col gap-5">
          {editing ? (
            <ProductForm
              key={editing.input.name || "new"}
              initial={editing.input}
              isNew={editing.isNew}
              onSaved={async () => {
                const saved = editing;
                setEditing(null);
                await load();
                //a new product opens on its own page; an edit stays where it was
                if (saved.isNew && saved.input.name) router.push(productHref(saved.input.name));
              }}
              onCancel={() => setEditing(null)}
            />
          ) : children}
        </div>
      </div>
    </Ctx.Provider>
  );
}

function ProductsNav({
  products,
  orphans,
  loading,
  open,
  onAdd,
  onDescribe,
}: {
  products: ProductSummary[];
  orphans: string[];
  loading: boolean;
  open: string | null;
  onAdd: () => void;
  onDescribe: (name: string) => void;
}) {
  const router = useRouter();
  const [find, setFind] = useState("");
  const q = find.trim().toLowerCase();
  const shown = products.filter((p) => !q || p.name.toLowerCase().includes(q) || (p.label ?? "").toLowerCase().includes(q));

  const chip = (p: ProductSummary) => !p.enabled
    ? <Chip>Unlisted</Chip>
    : p.credentialCount
      ? <Chip tone="ok">{p.credentialCount} {p.credentialCount === 1 ? "login" : "logins"}</Chip>
      : p.ruleCount ? <Chip>{p.ruleCount} {p.ruleCount === 1 ? "rule" : "rules"}</Chip> : <Chip>Unused</Chip>;

  return (
    <>
      {/* a select on a phone, where a column of cards would push the product a screen down */}
      <label className="flex w-full flex-col gap-1 text-xs text-muted-foreground lg:hidden">
        Product
        <Select aria-label="Product to show" value={open ?? ""} onChange={(e) => e.target.value && router.push(productHref(e.target.value))}>
          {!open && <option value="">Choose a product</option>}
          {products.map((p) => (
            <option key={p.name} value={p.name}>{p.name}{p.label && p.label !== p.name ? ` · ${p.label}` : ""}{p.enabled ? "" : " · unlisted"}</option>
          ))}
        </Select>
      </label>

      <Rail label="Products">
        <Input aria-label="Find a product" placeholder="Find a product" value={find} onChange={(e) => setFind(e.target.value)} />

        <RailCard title="Products" what="what a bind asks for" count={loading ? null : products.length}>
          {loading && <RailNote>Loading…</RailNote>}
          {shown.map((p) => (
            <Link
              key={p.name}
              href={productHref(p.name)}
              aria-current={open === p.name ? "page" : undefined}
              className={railItemClass(open === p.name, cn(!p.enabled && "opacity-65"))}
            >
              <span className="flex min-w-0 flex-col">
                <span className="truncate font-mono">{p.name}</span>
                {p.label && p.label !== p.name && <span className="truncate text-xs font-normal text-muted-foreground">{p.label}</span>}
              </span>
              <span className="ml-auto shrink-0">{chip(p)}</span>
            </Link>
          ))}
          {!loading && !shown.length && <RailNote>{q ? "No product matches." : "No products described yet."}</RailNote>}
          <button type="button" onClick={onAdd} className={railItemClass(false, "gap-1.5 font-semibold text-primary")}>
            <Plus className="h-3.5 w-3.5" aria-hidden="true" /> Add product
          </button>
        </RailCard>

        {/* the compensating control for having no foreign key on app_rate_rule.product: on a fresh
            install this is where every product that actually exists shows up, one click each */}
        {orphans.length > 0 && (
          <RailCard title="Not described" what="in use, no name yet" count={orphans.length}>
            {orphans.map((name) => (
              <button key={name} type="button" onClick={() => onDescribe(name)} className={railItemClass(false)}>
                <span className="truncate font-mono">{name}</span>
                <span className="ml-auto shrink-0"><Chip tone="warn">Describe</Chip></span>
              </button>
            ))}
          </RailCard>
        )}
      </Rail>
    </>
  );
}

function Chip({ tone = "muted", children }: { tone?: "ok" | "warn" | "muted"; children: ReactNode }) {
  return (
    <span className={cn(
      "rounded-full px-2 py-px text-2xs font-medium",
      tone === "ok" && "bg-success-soft text-success",
      tone === "warn" && "bg-warning-soft text-warning",
      tone === "muted" && "border border-border text-muted-foreground"
    )}>
      {children}
    </span>
  );
}
