"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { ArrowDown, ArrowUp, Plus, Settings2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ApplyNowButton } from "./ApplyNowButton";
import { Button, buttonClasses } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { HealthStrip } from "./CardBits";
import { useConfirmChange, useConfirmDelete } from "./ConfirmProvider";
import { ErrorNote } from "./FormNotices";
import { PriceRuleDialog } from "./PriceRuleDialog";
import { scopeHref, scopeTitle, usePricingData } from "./PricingShell";
import { SaveBar } from "./SaveBar";
import { describePriceWhen, groupByProduct, isFallback, moveWithinProduct, priceChanged, scopeChangeCount, SCOPE_KIND_LABEL } from "@/lib/pricing-guide";
import { DEFAULT_SCOPE, scopeKind, scopeWarnings, validateScope, type RateRule, type RateRuleInput } from "@/lib/rate-types";
import { cn } from "@/lib/utils";
import { prefillFrom } from "@/lib/tester";
import { stagedSummary } from "@/lib/confirm-changes";

/**
 * One scope's prices -- an account's, a vendor's, or the default -- grouped by product.
 *
 * <p>Within a scope the gateway tries rules in order and the first match for the message's product
 * wins, so each product is its own short list and a move stays inside it. Edits, additions, moves
 * and switching a price on or off are staged and saved together, through the same whole-scope PUT
 * the old form used, which keeps every rule's id.
 */

interface DraftRule {
  key: string;
  rule: RateRuleInput;
}

let nextKey = 0;
const wrap = (rule: RateRuleInput): DraftRule => ({ key: `p${nextKey++}`, rule });
/** A rule's identity across a save: its id, or for one not yet saved, its place in the draft. */
const ruleKey = (rule: RateRuleInput, at: number) => (rule.id === null ? `new:${at}` : `id:${rule.id}`);
/** What a rule says, without where it sits: two rules with the same print are the same price. */
const rulePrint = (rule: RateRuleInput) => JSON.stringify([
  rule.amount, rule.product, rule.currency, rule.label, rule.enabled, rule.conditions, rule.filters,
]);

const BLANK: RateRuleInput = { id: null, amount: "", product: null, currency: null, label: null, enabled: true, conditions: [], filters: [] };

export function ScopePricingClient({ scope }: { scope: string }) {
  const data = usePricingData();
  const router = useRouter();
  const confirm = useConfirmChange();
  const confirmDelete = useConfirmDelete();
  const params = useSearchParams();
  const [stored, setStored] = useState<RateRule[] | null>(null);
  const [fallback, setFallback] = useState<RateRule[] | null>(null);
  const [rules, setRules] = useState<DraftRule[]>([]);
  const [editing, setEditing] = useState<{ index: number | null; rule: RateRuleInput } | null>(null);
  const [menu, setMenu] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  //the moment people wait for the gateway: a save landed and the poll is up to 30 s away
  const [justSaved, setJustSaved] = useState(false);
  const kind = scopeKind(scope, data.known);
  const title = scopeTitle(scope);

  const { loadScope } = data;
  const read = useCallback(async () => {
    const got = await loadScope(scope);
    setStored(got ?? []);
    setRules((got ?? []).map(wrap));
    setError("");
  }, [loadScope, scope]);

  useEffect(() => {
    //eslint-disable-next-line react-hooks/set-state-in-effect -- loading the open scope's rules
    void read();
  }, [read]);

  //an account with no pricing of its own pays the default: show what that is
  useEffect(() => {
    if (kind !== "price" || stored === null || stored.length) return;
    let live = true;
    void loadScope(DEFAULT_SCOPE).then((r) => live && setFallback(r ?? []));
    return () => {
      live = false;
    };
  }, [kind, stored, loadScope]);

  //?new=1 from Add pricing, and the product page's "Add pricing" carrying its product: arrive with a
  //new price already open. Once, then the address is cleaned so a reload does not reopen it
  const wantsNew = params.get("new") === "1";
  const wantsProduct = params.get("product");
  //the message tester's "Create price": one condition to open with, e.g. to startsWith +44
  const prefillKey = params.get("wf") ? `${params.get("wf")}|${params.get("wo")}|${params.get("wv")}` : "";
  useEffect(() => {
    if (!wantsNew || stored === null) return;
    const prefill = prefillFrom(new URLSearchParams(window.location.search));
    //eslint-disable-next-line react-hooks/set-state-in-effect -- a one-shot hand-off from the link
    setEditing({ index: null, rule: { ...BLANK, product: wantsProduct, conditions: prefill ? [prefill] : [] } });
    //keep ?product: past the hand-off it is the narrowing, not just the new price's product
    router.replace(scopeHref(scope, { product: wantsProduct }));
  }, [wantsNew, wantsProduct, prefillKey, stored, router, scope]);

  if (stored === null) {
    return <p className="text-sm text-muted-foreground">Loading…</p>;
  }

  const draft = rules.map((r) => r.rule);
  const count = scopeChangeCount(stored, draft);
  const isNew = stored.length === 0;
  const input = { scope, scopeConfirmed: true, isNew, rules: draft };
  const warnings = draft.length ? scopeWarnings(input, data.known) : [];
  //narrowed to a product: its own prices, and the everything-else ones that reach it too. The draft
  //still holds the whole scope -- a save replaces the scope wholesale, so hiding is all this does
  const narrow = data.product;
  const allGroups = groupByProduct(draft);
  const groups = narrow ? allGroups.filter((g) => g.product === narrow || g.product === null) : allGroups;
  const hidden = allGroups.filter((g) => !groups.includes(g)).reduce((n, g) => n + g.items.length, 0);
  const ownerHref = kind === "price" ? `/cp/accounts/${encodeURIComponent(scope)}` : kind === "cost" ? `/cp/vendors/${encodeURIComponent(scope)}` : null;

  function move(index: number, by: -1 | 1) {
    setRules((cur) => {
      const moved = moveWithinProduct(cur.map((r) => ({ ...r, product: r.rule.product })), index, by);
      return moved.map(({ key, rule }) => ({ key, rule }));
    });
  }

  async function save() {
    const invalid = validateScope(input, data.known);
    if (invalid) {
      setError(invalid);
      return;
    }
    //once, for everything staged: the moves, toggles and edits above were deliberately unconfirmed
    const summary = stagedSummary(
      stored!.map((r, at) => ({ k: ruleKey(r, at), r })),
      draft.map((r, at) => ({ k: ruleKey(r, at), r })),
      (x) => x.k,
      (x) => rulePrint(x.r),
      ["price", "prices"]
    );
    const ok = await confirm({
      title: `Save prices for ${title}`,
      consequence: `${summary || `${count} change(s)`}. The gateway reads them at its next poll, `
        + "and every message priced after that is charged by the new list.",
      confirmLabel: "Save prices",
    });
    if (!ok) return;
    setSaving(true);
    setError("");
    const failure = await data.saveScope(scope, draft, true, isNew);
    setSaving(false);
    if (failure) setError(failure);
    else {
      await read();
      setJustSaved(true);
    }
  }

  const description = kind === "cost" ? "What this vendor charges us per message."
    : kind === "default" ? "What every account pays unless its own pricing says otherwise. An account's own price always wins, its everything-else price included."
    : kind === "price" ? "What this account pays us per message."
    : "Neither a configured vendor nor a known account, so these prices load and match nothing.";

  return (
    <>
      <section className="min-w-0 rounded-xl border border-border bg-card">
        <header className="flex flex-wrap items-center gap-2 border-b border-border px-4 py-3 sm:px-5">
          <h2 className={cn("text-title", scope !== DEFAULT_SCOPE && "font-mono")}>{title}</h2>
          <Badge variant={kind === "unknown" ? "destructive" : kind === "default" ? "default" : "outline"}>{SCOPE_KIND_LABEL[kind]}</Badge>
          <span className="ml-auto flex gap-1.5">
            {ownerHref && (
              <Link href={ownerHref} className={buttonClasses({ variant: "outline", size: "sm" })}>
                {kind === "price" ? "Account page" : "Vendor page"}
              </Link>
            )}
            {!isNew && (
              <Button variant="outline" size="sm" aria-label="More" onClick={() => setMenu(true)}>
                <Settings2 className="h-3.5 w-3.5" aria-hidden="true" />
              </Button>
            )}
          </span>
        </header>

        <p className="px-4 pt-3 text-sm text-muted-foreground sm:px-5">
          {description}{draft.length > 0 && " Within each product, the first matching price wins."}
        </p>

        {(warnings.length > 0 || error) && (
          <div className="space-y-2 px-4 pt-3 sm:px-5">
            {warnings.map((w) => <HealthStrip key={w}>{w}</HealthStrip>)}
            <ErrorNote error={error} />
          </div>
        )}
        {justSaved && count === 0 && !error && (
          <div className="px-4 pt-3 sm:px-5"><ApplyNowButton compact /></div>
        )}

        {draft.length === 0 && (
          <div className="px-4 pt-3 sm:px-5">
            {kind === "price" ? (
              <p className="rounded-lg border border-dashed border-border px-4 py-3 text-sm text-muted-foreground">
                No pricing of its own, so {title} pays the default
                {fallback === null ? "…" : fallback.length
                  ? <>: {fallback.filter((r) => r.enabled).map((r, i) => (
                    <span key={r.id}>{i > 0 && "; "}<span className="font-semibold tabular-nums text-foreground">{r.amount}</span>{r.product ? ` on ${r.product}` : ""} {describePriceWhen(r).toLowerCase()}</span>
                  ))}.</>
                  : <>, and nothing is set there either. <Link href={scopeHref(DEFAULT_SCOPE)} className="text-primary hover:underline">Set the default →</Link></>}
              </p>
            ) : kind === "cost" ? (
              <HealthStrip tone="destructive">No cost set. Messages through {title} have no recorded cost, so their margin looks better than it is.</HealthStrip>
            ) : kind === "default" ? (
              <HealthStrip>Nothing is set, so an account without pricing of its own is not charged at all.</HealthStrip>
            ) : null}
          </div>
        )}

        {groups.map((g) => (
          <div key={g.product ?? "*any"} className="mx-4 mt-3 overflow-hidden rounded-lg border border-border sm:mx-5">
            <div className="flex flex-wrap items-center gap-2 bg-muted/60 px-3 py-2 text-sm">
              {g.product ? <>Product <span className="font-mono font-semibold">{g.product}</span></> : <span className="font-semibold">Any product</span>}
              <span className="text-xs text-muted-foreground">{g.items.length} {g.items.length === 1 ? "price" : "prices"}</span>
              {!g.hasFallback && <Badge variant="warning">No “everything else” price</Badge>}
            </div>
            <ol className="divide-y divide-border">
              {g.items.map((item, i) => (
                <PriceRow
                  key={rules[item.index].key}
                  rule={item.rule}
                  seq={i + 1}
                  first={i === 0}
                  last={i === g.items.length - 1}
                  changed={priceChanged(stored, draft, item.rule)}
                  //below an enabled everything-else price of the same product: the save refuses it
                  unreachable={item.rule.enabled && g.items.slice(0, i).some((x) => x.rule.enabled && isFallback(x.rule))}
                  onToggle={(on) => setRules((cur) => cur.map((r, n) => (n === item.index ? { ...r, rule: { ...r.rule, enabled: on } } : r)))}
                  onEdit={() => setEditing({ index: item.index, rule: item.rule })}
                  onMove={(by) => move(item.index, by)}
                />
              ))}
            </ol>
          </div>
        ))}

        {narrow && hidden > 0 && (
          <p className="mx-4 mt-3 text-xs text-muted-foreground sm:mx-5">
            {hidden} {hidden === 1 ? "price" : "prices"} on other products {hidden === 1 ? "is" : "are"} not shown.{" "}
            <Link href={scopeHref(scope)} className="text-primary hover:underline">Show all of {title}’s pricing</Link>
          </p>
        )}

        <div className="mt-3 flex flex-wrap items-center gap-3 border-t border-border px-4 py-3 sm:px-5">
          <Button variant={draft.length ? "outline" : "default"} size="sm" className="gap-1.5" onClick={() => setEditing({ index: null, rule: { ...BLANK, product: narrow } })}>
            <Plus className="h-3.5 w-3.5" aria-hidden="true" />
            {narrow ? `Add a price for ${narrow}` : draft.length ? "Add a price" : kind === "cost" ? "Set its cost" : kind === "price" ? "Give it its own price" : "Add a price"}
          </Button>
          {draft.length > 0 && <span className="text-xs text-muted-foreground">Changes wait for Save.</span>}
        </div>
      </section>

      <SaveBar count={count} saving={saving} message={`Nothing has reached ${title} yet.`} onDiscard={() => { setRules(stored.map(wrap)); setError(""); }} onSave={() => void save()} inset />

      {editing && (
        <PriceRuleDialog
          rule={editing.rule}
          position={editing.index === null ? null
            : (groups.find((g) => g.items.some((x) => x.index === editing.index))?.items.findIndex((x) => x.index === editing.index) ?? 0) + 1}
          scopeTitle={title}
          kind={kind}
          rules={draft}
          catalogue={data.catalogue}
          filters={data.filters}
          onClose={() => setEditing(null)}
          onDelete={editing.index === null ? null : async () => {
            const at = editing.index!;
            //a delete, though staged: it asks for the word here, and the Save that sends it asks again
            const ok = await confirmDelete({
              title: `Remove this price from ${title}`,
              consequence: `The ${editing.rule.amount || "unpriced"}${editing.rule.product ? ` ${editing.rule.product}` : ""} price `
                + `(${describePriceWhen(editing.rule).toLowerCase()}) is taken out of the list when you save. `
                + "Messages it priced fall through to the next price that matches, or to none.",
              confirmLabel: "Remove price",
            });
            if (!ok) return;
            setRules((cur) => cur.filter((_, n) => n !== at));
            setEditing(null);
          }}
          onDone={(next) => {
            if (editing.index === null) setRules((cur) => [...cur, wrap(next)]);
            else setRules((cur) => cur.map((r, n) => (n === editing.index ? { ...r, rule: next } : r)));
            setEditing(null);
          }}
        />
      )}

      {menu && (
        <Dialog open onClose={() => setMenu(false)} title={title}>
          <div className="space-y-4">
            <div className="text-sm font-medium">Delete</div>
            <Button
              type="button"
              variant="ghost"
              className="text-destructive"
              disabled={data.busy === scope}
              onClick={async () => {
                const ok = await confirmDelete({
                  title: `Delete all prices for ${title}`,
                  consequence: `All ${stored.length} price(s) for '${title}' go. `
                    + (kind === "cost" ? "Messages through it will have no recorded cost, so margin on them becomes unknown."
                      : kind === "price" ? "It goes back to paying the default."
                      : "Messages for it will have no price."),
                  confirmLabel: "Delete these prices",
                });
                if (ok && await data.removeScope(scope)) {
                  setMenu(false);
                  router.push("/cp/pricing");
                }
              }}
            >
              {data.busy === scope ? "Deleting…" : `Delete all ${stored.length} prices`}
            </Button>
            <div className="flex justify-end border-t border-border pt-4">
              <Button type="button" variant="outline" onClick={() => setMenu(false)}>Close</Button>
            </div>
          </div>
        </Dialog>
      )}
    </>
  );
}

function PriceRow({
  rule,
  seq,
  first,
  last,
  changed,
  unreachable,
  onToggle,
  onEdit,
  onMove,
}: {
  rule: RateRuleInput;
  seq: number;
  first: boolean;
  last: boolean;
  changed: boolean;
  unreachable: boolean;
  onToggle: (on: boolean) => void;
  onEdit: () => void;
  onMove: (by: -1 | 1) => void;
}) {
  return (
    <li className={cn(
      "grid grid-cols-[1.5rem_minmax(0,1fr)] gap-x-2 gap-y-2 px-3 py-3 sm:grid-cols-[1.5rem_minmax(0,1fr)_auto]",
      changed && "shadow-[inset_3px_0_0_var(--color-primary)]",
      unreachable && "bg-warning-soft/60"
    )}>
      <span className="pt-0.5 text-sm tabular-nums text-muted-foreground">{seq}</span>
      <div className={cn("min-w-0", !rule.enabled && "opacity-50")}>
        <p className="text-sm">{describePriceWhen(rule)}</p>
        <div className="mt-1 flex flex-wrap items-center gap-1.5">
          <span className="text-sm font-semibold tabular-nums">{rule.amount}</span>
          <span className="text-xs text-muted-foreground">{rule.currency ? `${rule.currency} ` : ""}per message</span>
          {!rule.enabled && <Badge variant="outline">Retired</Badge>}
          {changed && <Badge>Unsaved</Badge>}
        </div>
        {rule.label && <p className="mt-0.5 text-xs text-muted-foreground">{rule.label}</p>}
        {unreachable && <p className="mt-0.5 text-xs text-warning">Never reached: an “everything else” price above takes every message. Move it up.</p>}
      </div>
      <div className="col-start-2 flex flex-wrap items-center gap-2 sm:col-start-3 sm:justify-end">
        <Switch checked={rule.enabled} onChange={onToggle} aria-label={rule.enabled ? "Price in use" : "Price retired"} />
        <Button variant="outline" size="sm" onClick={onEdit}>Edit</Button>
        <span className="flex">
          <Button variant="ghost" size="sm" className="h-8 w-8 px-0" aria-label="Move up" disabled={first} onClick={() => onMove(-1)}>
            <ArrowUp className="h-4 w-4" aria-hidden="true" />
          </Button>
          <Button variant="ghost" size="sm" className="h-8 w-8 px-0" aria-label="Move down" disabled={last} onClick={() => onMove(1)}>
            <ArrowDown className="h-4 w-4" aria-hidden="true" />
          </Button>
        </span>
      </div>
    </li>
  );
}
