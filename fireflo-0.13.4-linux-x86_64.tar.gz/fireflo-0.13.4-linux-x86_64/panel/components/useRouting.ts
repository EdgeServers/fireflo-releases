"use client";
import { useCallback, useEffect, useState } from "react";
import type { RouteTable, RouteTableInput } from "@/lib/routing-types";

/**
 * The routing tables.
 *
 * <p>A change here reaches the gateway on its next configuration poll — but only under
 * `FIREFLO_CONFIG_SOURCE=db`. On `file` it reads `conf/routingTable.conf` and everything written
 * from this page is stored and ignored, which is what the `GatewayIgnores` banner on the page says.
 */
export function useRouting() {
  const [tables, setTables] = useState<RouteTable[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/control/routing", { cache: "no-store" });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      setTables(json.data.tables as RouteTable[]);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const save = useCallback(
    async (input: RouteTableInput): Promise<string | null> => {
      setBusy(input.name);
      try {
        const res = await fetch("/api/control/routing", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(input),
        });
        const json = await res.json().catch(() => null);
        if (!res.ok) {
          return json?.error ?? `Request failed (${res.status})`;
        }
        await load();
        return null;
      } finally {
        setBusy("");
      }
    },
    [load]
  );

  const remove = useCallback(
    async (name: string): Promise<string | null> => {
      setBusy(name);
      try {
        const res = await fetch(`/api/control/routing/${encodeURIComponent(name)}`, {
          method: "DELETE",
        });
        const json = await res.json().catch(() => null);
        if (!res.ok) {
          return json?.error ?? `Request failed (${res.status})`;
        }
        await load();
        return null;
      } finally {
        setBusy("");
      }
    },
    [load]
  );

  const toggleRule = useCallback(
    async (tableName: string, id: number, enabled: boolean): Promise<string | null> => {
      const key = `${tableName}:${id}`;
      setBusy(key);
      try {
        const res = await fetch(
          `/api/control/routing/${encodeURIComponent(tableName)}/rules/${id}`,
          {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ enabled }),
          }
        );
        const json = await res.json().catch(() => null);
        if (!res.ok) {
          return json?.error ?? `Request failed (${res.status})`;
        }
        await load();
        return null;
      } finally {
        setBusy("");
      }
    },
    [load]
  );

  return { tables, error, loading, busy, load, save, remove, toggleRule };
}
