"use client";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Antenna, ListTree, Search, Server, Wallet } from "lucide-react";
import { Dialog } from "@/components/ui/dialog";
import { toHits, type SearchHit, type SearchResult } from "@/lib/search";
import { cn } from "@/lib/utils";

const KIND_ICON = { account: Wallet, vendor: Antenna, server: Server, message: ListTree } as const;
const KIND_WORD = { account: "Account", vendor: "Vendor", server: "Server", message: "Message" } as const;

/**
 * Type a few letters, land on the page: accounts, vendors, servers and message ids.
 *
 * <p>Opened from the top bar or with ⌘K / Ctrl+K. One request per pause in typing, against
 * `/api/control/search`, which ranks for us; this only draws the list and moves the highlight.
 * Enter follows the highlighted row, and the dialog primitive owns focus and Escape.
 *
 * <p>Labelled "Jump to", not "Search": the catalogue page has a box called "Search accounts" that
 * the e2e suite finds by that name, and a second one would match it too.
 */
export function JumpBox({ open, onClose }: { open: boolean; onClose: () => void }) {
  const router = useRouter();
  const [q, setQ] = useState("");
  const [hits, setHits] = useState<SearchHit[]>([]);
  const [at, setAt] = useState(0);
  const [busy, setBusy] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const seq = useRef(0);

  useEffect(() => {
    if (open) {
      //the dialog mounts in a portal after this render; focus once it exists
      const t = window.setTimeout(() => input.current?.focus(), 0);
      return () => window.clearTimeout(t);
    }
  }, [open]);

  //cleared on the way out rather than in an effect on `open`, so the next opening starts empty
  //without a render that still shows the last list
  function close() {
    setQ("");
    setHits([]);
    setAt(0);
    onClose();
  }

  const needle = q.trim();
  useEffect(() => {
    if (!needle) {
      return;
    }
    const mine = ++seq.current;
    const t = window.setTimeout(async () => {
      setBusy(true);
      try {
        const res = await fetch(`/api/control/search?q=${encodeURIComponent(needle)}`, { cache: "no-store" });
        const json = (await res.json()) as { data?: SearchResult };
        if (mine === seq.current && json.data) {
          setHits(toHits(json.data));
          setAt(0);
        }
      } catch {
        //a failed lookup shows nothing rather than an error: the operator is still typing
      } finally {
        if (mine === seq.current) {
          setBusy(false);
        }
      }
    }, 150);
    return () => window.clearTimeout(t);
  }, [needle]);

  //what the list shows: nothing until there is something to look for, whatever was fetched last
  const shown = needle ? hits : [];

  function go(hit: SearchHit | undefined) {
    if (!hit) {
      return;
    }
    close();
    router.push(hit.href);
  }

  return (
    <Dialog open={open} onClose={close} title="Jump to" className="max-w-lg">
      <div className="space-y-2">
        <label className="relative block">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <input
            ref={input}
            aria-label="Jump to"
            role="combobox"
            aria-expanded={shown.length > 0}
            aria-controls="jump-results"
            aria-activedescendant={shown[at] ? `jump-${at}` : undefined}
            autoComplete="off"
            placeholder="account, vendor, server or message id"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "ArrowDown") {
                e.preventDefault();
                setAt((i) => Math.min(i + 1, Math.max(shown.length - 1, 0)));
              } else if (e.key === "ArrowUp") {
                e.preventDefault();
                setAt((i) => Math.max(i - 1, 0));
              } else if (e.key === "Enter") {
                e.preventDefault();
                go(shown[at]);
              }
            }}
            className="h-11 w-full rounded-md border border-border bg-card pl-9 pr-3 text-sm md:h-10"
          />
        </label>
        <ul id="jump-results" role="listbox" aria-label="Matches" className="max-h-80 overflow-y-auto">
          {shown.map((hit, i) => {
            const Icon = KIND_ICON[hit.kind];
            return (
              <li
                key={`${hit.kind}:${hit.id}`}
                id={`jump-${i}`}
                role="option"
                aria-selected={i === at}
                onMouseEnter={() => setAt(i)}
                onMouseDown={(e) => { e.preventDefault(); go(hit); }}
                className={cn(
                  "flex cursor-pointer items-center gap-3 rounded-md px-2.5 py-2 text-sm",
                  i === at ? "bg-muted" : "hover:bg-muted/60"
                )}
              >
                <Icon className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />
                <span className="min-w-0 flex-1 truncate">
                  <span className={cn(hit.kind === "account" && hit.label ? "" : "font-mono")}>{hit.label || hit.id}</span>
                  {hit.kind === "account" && hit.label && (
                    <span className="ml-2 font-mono text-xs text-muted-foreground">{hit.id}</span>
                  )}
                </span>
                <span className="text-xs text-muted-foreground">{KIND_WORD[hit.kind]}</span>
              </li>
            );
          })}
          {!shown.length && needle && !busy && (
            <li className="px-2.5 py-6 text-center text-sm text-muted-foreground">Nothing matches “{needle}”.</li>
          )}
          {!needle && (
            <li className="px-2.5 py-6 text-center text-xs text-muted-foreground">
              Type part of an account, a vendor or server name, or paste a message id.
            </li>
          )}
        </ul>
      </div>
    </Dialog>
  );
}
