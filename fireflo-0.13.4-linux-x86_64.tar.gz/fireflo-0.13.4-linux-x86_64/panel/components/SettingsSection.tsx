/** Kept so the three settings pages' imports keep resolving; the primitive now lives in ui/. */
export { SettingsSection } from "@/components/ui/settings-section";
