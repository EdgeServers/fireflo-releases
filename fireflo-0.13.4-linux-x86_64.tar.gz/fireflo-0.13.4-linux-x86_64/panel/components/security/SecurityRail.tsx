"use client";

import { useEffect, useState, type RefObject } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ClientWatchCard, type ClientWatchHandle } from "@/components/ClientWatchCard";
import type { SignInSummary } from "@/lib/audit-log";
import { holdRemaining, holdTarget, type BindHold } from "@/lib/force-disconnect";
import type { BlockedAddress } from "@/lib/security-events";
import { short } from "@/lib/security-format";
import { displayIp } from "@/lib/security-grouping";
import { RailBox, RailRow, RailRows, RailText } from "./RailBox";
import type { Sources } from "./RefusalsCard";

/**
 * The rail beside the refusals: the two states an address can be in, the database's count of
 * sign-ins, and the live watch. State and tools, while the card on the left is evidence.
 */
export function SecurityRail({
  blocked,
  holds,
  holdsError,
  sources,
  canUnban,
  busy,
  now,
  days,
  rangeLabel,
  onUnban,
  onLift,
  watch,
}: {
  blocked: BlockedAddress[];
  holds: BindHold[];
  holdsError: string | null;
  sources: Sources | undefined;
  canUnban: boolean;
  busy: string | null;
  now: number;
  /** The page's range in whole days, for the sign-in summary. */
  days: number;
  rangeLabel: string;
  onUnban: (jail: string, ip: string) => void;
  onLift: (holdId: number) => void;
  watch: RefObject<ClientWatchHandle | null>;
}) {
  return (
    <div className="min-w-0 space-y-4 xl:sticky xl:top-4">
      <BlockedBox blocked={blocked} sources={sources} canUnban={canUnban} busy={busy} now={now} onUnban={onUnban} />
      <HeldOutBox holds={holds} error={holdsError} now={now} busy={busy} onLift={onLift} />
      <SignInsBox days={days} rangeLabel={rangeLabel} />
      <ClientWatchCard ref={watch} />
    </div>
  );
}

/** Blocked now: the setup note when fail2ban is not here; the list when it is. */
function BlockedBox({
  blocked,
  sources,
  canUnban,
  busy,
  now,
  onUnban,
}: {
  blocked: BlockedAddress[];
  sources: Sources | undefined;
  canUnban: boolean;
  busy: string | null;
  now: number;
  onUnban: (jail: string, ip: string) => void;
}) {
  return (
    <RailBox title="Blocked now" what="by fail2ban"
      aside={blocked.length > 0 ? <Badge variant="destructive">{blocked.length}</Badge> : undefined}>
      {sources && !sources.fail2ban.present ? (
        <RailText>
          <p>{sources.fail2ban.note}</p>
          {/* names the VERB, not the flag: `update` drops --with-fail2ban, so it cannot be the
              instruction on a host that already has an install */}
          <p>
            Set it up with <code className="font-mono">sudo fireflo-install fail2ban</code>, and fill in the
            never-ban list first: a ban is on an address, and an address usually carries a whole customer.
          </p>
          <dl className="space-y-1">
            <div><dt className="inline">Asks </dt><dd className="inline font-mono">{sources.fail2ban.unbanCommand}</dd></div>
            <div><dt className="inline">Reads </dt><dd className="inline font-mono">{sources.fail2ban.path}</dd></div>
          </dl>
        </RailText>
      ) : !blocked.length ? (
        <RailText>{sources ? "Nothing is blocked." : "Reading…"}</RailText>
      ) : (
        <>
          <RailRows>
            {blocked.map((row) => {
              const key = `${row.jail} ${row.ip}`;
              return (
                <RailRow key={key} action={canUnban && (
                  <Button variant="outline" size="sm" disabled={busy === key} onClick={() => onUnban(row.jail, row.ip)}>
                    {busy === key ? "Releasing…" : "Unban"}
                  </Button>
                )}>
                  <p className="font-mono">{displayIp(row.ip)}</p>
                  <p className="text-xs text-muted-foreground">
                    {row.jail}{row.failures ? ` · ${row.failures} failures` : ""} · {row.until ? `lifts ${short(row.until, now)}` : "does not expire"}
                  </p>
                </RailRow>
              );
            })}
          </RailRows>
          {/* which source answered, because they can disagree and the live one is the truth */}
          <RailText className="border-t border-border">
            {sources?.fail2ban.live
              ? "Asked fail2ban directly: this is what is blocking traffic now."
              : "Reconstructed from recorded bans; a ban made outside FireFlo would not appear."}
            {!canUnban && " Unbanning from here is not set up on this host."}
          </RailText>
        </>
      )}
    </RailBox>
  );
}

/** Held out by an operator after a force disconnect: refused at bind, separately from what fail2ban blocks, and lifted here. */
function HeldOutBox({
  holds,
  error,
  now,
  busy,
  onLift,
}: {
  holds: BindHold[];
  error: string | null;
  now: number;
  busy: string | null;
  onLift: (holdId: number) => void;
}) {
  return (
    <RailBox title="Held out" what="SMPP binds refused by an operator"
      aside={holds.length > 0 ? <Badge variant="warning">{holds.length}</Badge> : undefined}>
      {error && <RailText className="text-destructive">{error}</RailText>}
      {!holds.length ? (
        !error && <RailText>Nobody is held out.</RailText>
      ) : (
        <RailRows>
          {holds.map((h) => {
            const key = `hold ${h.id}`;
            return (
              <RailRow key={h.id} action={
                <Button variant="outline" size="sm" disabled={busy === key} onClick={() => onLift(h.id)}>
                  {busy === key ? "Lifting…" : "Lift"}
                </Button>
              }>
                <p className="font-mono font-medium">{holdTarget(h)}</p>
                <p className="text-xs text-muted-foreground">
                  {holdRemaining(h.until, now)}{h.listener ? ` · ${h.listener}` : " · every listener"}
                  {h.created_by ? ` · by ${h.created_by}` : ""}{h.reason ? ` · “${h.reason}”` : ""}
                </p>
              </RailRow>
            );
          })}
        </RailRows>
      )}
    </RailBox>
  );
}

/**
 * Sign-ins and refusals per door from the two database logs, for the page's range.
 *
 * <p>Beside the cards built from the refusal files and fail2ban. Those are what gets an address
 * banned; this is what people read. Both are shown so the moments they disagree -- a file that
 * stopped being written, a database the panel could not reach -- are visible rather than silent.
 */
function SignInsBox({ days, rangeLabel }: { days: number; rangeLabel: string }) {
  const [rows, setRows] = useState<SignInSummary[] | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/control/audit/signins?days=${days}`, { cache: "no-store" })
      .then(async (res) => {
        const json = await res.json().catch(() => null);
        if (cancelled) {
          return;
        }
        if (!res.ok) {
          setError(json?.error ?? `Request failed (${res.status})`);
          return;
        }
        setRows(json.data.rows as SignInSummary[]);
        setError("");
      })
      .catch((err) => {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : "Request failed");
        }
      });
    return () => {
      cancelled = true;
    };
  }, [days]);

  const totals = (rows ?? []).reduce(
    (acc, r) => {
      acc[r.surface].succeeded += r.succeeded;
      acc[r.surface].failed += r.failed;
      return acc;
    },
    { panel: { succeeded: 0, failed: 0 }, portal: { succeeded: 0, failed: 0 } }
  );

  return (
    <RailBox title="Sign-ins" what={`last ${rangeLabel}, from the database`}>
      {error ? (
        <RailText className="text-destructive">{error}</RailText>
      ) : rows === null ? (
        <RailText>Reading…</RailText>
      ) : (
        <RailRows>
          <Door name="Operator panel" {...totals.panel} />
          <Door name="Customer portal" {...totals.portal} />
        </RailRows>
      )}
    </RailBox>
  );
}

function Door({ name, succeeded, failed }: { name: string; succeeded: number; failed: number }) {
  return (
    <RailRow>
      <div className="flex items-baseline justify-between gap-3">
        <span>{name}</span>
        <span className="whitespace-nowrap text-xs text-muted-foreground">
          <span className="font-medium tabular-nums text-foreground">{succeeded}</span> in ·{" "}
          <span className={`font-medium tabular-nums ${failed ? "text-destructive" : "text-foreground"}`}>{failed}</span> refused
        </span>
      </div>
    </RailRow>
  );
}
