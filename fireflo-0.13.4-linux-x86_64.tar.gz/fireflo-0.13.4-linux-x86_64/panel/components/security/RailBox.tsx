import type { ReactNode } from "react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

/**
 * One card of the Security page's right-hand rail: a titled bar, then rows or a note.
 *
 * <p>The same header shape as {@link RailCard} -- title, a few words of what, something small at
 * the right -- but for state rather than navigation: the thing at the right is a count chip or a
 * status, and the rows under it carry a button each. Four of these sit in the rail, and one
 * component is what keeps their headers on one line.
 */
export function RailBox({
  title,
  what,
  aside,
  className,
  children,
}: {
  title: string;
  /** A few words after the title: "SMPP binds refused by an operator". */
  what?: string;
  /** The chip or status at the right of the header. */
  aside?: ReactNode;
  className?: string;
  children: ReactNode;
}) {
  return (
    <Card className={cn("min-w-0 overflow-hidden", className)}>
      <div className="flex flex-wrap items-center gap-x-2 gap-y-1 border-b border-border px-3.5 py-2.5">
        <span className="text-sm font-medium">{title}</span>
        {what && <span className="text-xs text-muted-foreground">{what}</span>}
        {aside && <span className="ml-auto flex items-center">{aside}</span>}
      </div>
      {children}
    </Card>
  );
}

/** The rows of a {@link RailBox}: hairlines between, no border around. */
export function RailRows({ children }: { children: ReactNode }) {
  return <ul className="divide-y divide-border text-sm">{children}</ul>;
}

/** One row: what it is on the left, a button on the right. */
export function RailRow({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <li className="flex items-center gap-2 px-3.5 py-2">
      <div className="min-w-0 flex-1">{children}</div>
      {action}
    </li>
  );
}

/** A line of explanation inside a box, where rows would otherwise be. */
export function RailText({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("space-y-1.5 px-3.5 py-2.5 text-xs text-muted-foreground", className)}>{children}</div>;
}
