"use client";

import { useState } from "react";
import { Ban } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EditPanel } from "@/components/ui/card";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { BAN_DURATIONS, BAN_NOT_AVAILABLE } from "@/lib/refusal-views";

/**
 * The ban, in place: jail and length, one sentence on what it does, Ban and Cancel.
 *
 * <p>Opens under the table from a row's "Ban…" rather than banning on the press, because the two
 * choices -- which jail, for how long -- were a pair of selects in the filter row that applied to
 * whichever row was pressed next, which is the kind of thing that bans the wrong address for a day.
 * Here they sit beside the address they are about to act on.
 */
export function BanPanel({
  ip,
  jails,
  canBan,
  busy,
  onBan,
  onCancel,
}: {
  ip: string;
  jails: readonly string[];
  /** False when the panel is not on the gateway host: the form shows, the button says why not. */
  canBan: boolean;
  busy: boolean;
  onBan: (jail: string, seconds: number | null) => void;
  onCancel: () => void;
}) {
  const [jail, setJail] = useState(jails[0] ?? "");
  const [seconds, setSeconds] = useState<string>("");
  const custom = seconds !== "" && !BAN_DURATIONS.some((d) => d.value === seconds);

  return (
    <EditPanel className="space-y-3" aria-label={`Ban ${ip}`}>
      <p className="text-sm font-medium">Ban <span className="font-mono">{ip}</span> in fail2ban</p>
      <div className="grid gap-3 sm:grid-cols-2 lg:max-w-md">
        <Field label="Jail" htmlFor="ban-jail">
          <Select id="ban-jail" value={jail} disabled={!canBan} onChange={(e) => setJail(e.target.value)}>
            {jails.map((j) => <option key={j} value={j}>{j}</option>)}
          </Select>
        </Field>
        <Field label="For" htmlFor="ban-for">
          <div className="flex gap-2">
            <Select id="ban-for" value={custom ? "custom" : seconds} disabled={!canBan}
              onChange={(e) => setSeconds(e.target.value === "custom" ? "600" : e.target.value)}>
              {BAN_DURATIONS.map((d) => <option key={d.value} value={d.value}>{d.label}</option>)}
              <option value="custom">Seconds…</option>
            </Select>
            {custom && (
              <Input aria-label="Ban seconds" inputMode="numeric" className="w-28" value={seconds}
                onChange={(e) => setSeconds(e.target.value.replace(/\D/g, ""))} />
            )}
          </div>
        </Field>
      </div>
      <p className="text-xs text-muted-foreground">
        {canBan
          ? "Blocks every port at the host's firewall for the time chosen, or the jail's own bantime. Unban on the row lifts it early."
          : BAN_NOT_AVAILABLE}
      </p>
      <div className="flex flex-wrap gap-2">
        <Button variant="destructive" size="sm" disabled={!canBan || busy || !jail || (custom && !Number(seconds))}
          onClick={() => onBan(jail, seconds ? Number(seconds) : null)}>
          <Ban className="size-3.5" aria-hidden />
          {busy ? "Banning…" : "Ban"}
        </Button>
        <Button variant="ghost" size="sm" onClick={onCancel} disabled={busy}>Cancel</Button>
      </div>
    </EditPanel>
  );
}
