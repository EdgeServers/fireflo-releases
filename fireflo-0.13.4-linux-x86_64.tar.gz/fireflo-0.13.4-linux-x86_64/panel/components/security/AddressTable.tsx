"use client";

import type { ReactNode } from "react";
import { Ban, Eye, Unplug } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import { Pager } from "@/components/Pager";
import { usePaging } from "@/components/usePaging";
import { BAN_NOT_AVAILABLE, isNonBannable } from "@/lib/refusal-views";
import { reasonLabel } from "@/lib/security-events";
import { firstFew, short, when } from "@/lib/security-format";
import { portLabel, type AddressRow } from "@/lib/security-rows";
import { SURFACES } from "@/lib/security-grouping";
import { SurfaceBadge } from "./RefusalChart";

/** What a row can do, wired by the page so every action re-reads everything. */
export interface RowActions {
  onWatch: (ip: string) => void;
  onHold: (ip: string) => void;
  onUnban: (jail: string, ip: string) => void;
  onLift: (holdId: number) => void;
  /** Opens the ban panel for the address. */
  onBan: (ip: string) => void;
  /** The address or hold being acted on, so its button says so and the rest stay pressable. */
  busy: string | null;
  canUnban: boolean;
  /** Whether a ban can be asked for at all; the button is shown either way and says why not. */
  canBan: boolean;
}

/**
 * One row per address: where, why, how often, as whom, when, and what to do about it.
 *
 * <p>The column is "Tried as", not "User". Nothing here authenticated, so a name in it is an
 * attempted name; rendering it as an identity would put a customer's name against somebody else's
 * attack. And the reason never says which half of a credential was wrong, because the gateway
 * compares in constant time precisely so that it does not.
 */
export function AddressTable({
  rows,
  pageSize,
  now,
  loading,
  empty,
  actions,
  under,
}: {
  rows: AddressRow[];
  pageSize: number;
  /** When the rows were read; "last seen" is relative to it. */
  now: number;
  loading: boolean;
  /** What to say when there are no rows. */
  empty: string;
  actions: RowActions;
  /** Rendered between the table and its pager: the ban panel for the row that asked for it. */
  under?: ReactNode;
}) {
  const paged = usePaging(rows, pageSize);

  if (!rows.length) {
    return (
      <div className="p-4">
        <EmptyState>{loading ? "Reading…" : empty}</EmptyState>
      </div>
    );
  }

  return (
    <>
      <TableInCard>
        <THead>
          <tr>
            <TH>Address</TH>
            <TH>Port</TH>
            <TH>Reasons</TH>
            <TH align="right">Attempts</TH>
            <TH>Tried as</TH>
            <TH>Last seen</TH>
            <TH />
          </tr>
        </THead>
        <TBody>
          {paged.shown.map((a) => {
            const blocked = a.blocked;
            const unbanKey = blocked ? `${blocked.jail} ${blocked.ip}` : "";
            const liftKey = a.hold ? `hold ${a.hold.id}` : "";
            return (
              <TR key={a.ip}>
                <TD>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="font-mono">{a.ip}</span>
                    {blocked && <Badge variant="destructive" title={`banned in ${blocked.jail}`}>blocked</Badge>}
                    {a.heldOut && <Badge variant="warning" title="A bind hold on this address is in force">held out</Badge>}
                  </div>
                  <div className="mt-1 flex flex-wrap gap-1">
                    {SURFACES.filter((s) => a.bySurface[s] > 0).map((s) => (
                      <SurfaceBadge key={s} surface={s} count={a.bySurface[s]} />
                    ))}
                  </div>
                </TD>
                <TD className="max-w-56">
                  {a.ports.length === 0 ? (
                    <span className="text-xs text-muted-foreground">—</span>
                  ) : (
                    <div className="flex flex-wrap gap-1">
                      {a.ports.map((p) => (
                        <Badge key={`${p.listener}|${p.port}`} variant="outline" title={`${p.count} on this listener`}>
                          {portLabel(p)}
                        </Badge>
                      ))}
                    </div>
                  )}
                </TD>
                <TD className="max-w-72">
                  <div className="flex flex-wrap gap-1">
                    {a.reasons.map((r) => (
                      <Badge key={r.reason} variant={isNonBannable(r.reason) ? "outline" : "destructive"} title={reasonLabel(r.reason)}>
                        {r.reason} {r.count}
                      </Badge>
                    ))}
                  </div>
                </TD>
                <TD num className="font-medium">{a.attempts.toLocaleString()}</TD>
                <TD muted className="max-w-56">
                  <span className="font-mono text-xs" title={a.triedAs.join(", ")}>{firstFew(a.triedAs)}</span>
                </TD>
                <TD muted className="whitespace-nowrap text-xs" title={`first ${when(a.firstAt)}`}>{short(a.lastAt, now)}</TD>
                <TD align="right" className="whitespace-nowrap">
                  {a.canWatch && (
                    <Button variant="ghost" size="sm" onClick={() => actions.onWatch(a.ip)} title="Watch this address's SMPP traffic live">
                      <Eye className="size-3.5" aria-hidden /> Watch
                    </Button>
                  )}
                  {!a.heldOut && (
                    <Button variant="ghost" size="sm" onClick={() => actions.onHold(a.ip)}
                      title="Drop this address's SMPP sessions and hold its binds out on the gateway">
                      <Unplug className="size-3.5" aria-hidden /> Hold
                    </Button>
                  )}
                  {blocked ? (
                    actions.canUnban && (
                      <Button variant="outline" size="sm" disabled={actions.busy === unbanKey}
                        onClick={() => actions.onUnban(blocked.jail, blocked.ip)}>
                        {actions.busy === unbanKey ? "Releasing…" : "Unban"}
                      </Button>
                    )
                  ) : a.hold ? (
                    <Button variant="outline" size="sm" disabled={actions.busy === liftKey}
                      title="Lift the hold so this address may bind again" onClick={() => actions.onLift(a.hold!.id)}>
                      {actions.busy === liftKey ? "Lifting…" : "Lift"}
                    </Button>
                  ) : (
                    <Button variant="outline" size="sm" disabled={!actions.canBan}
                      title={actions.canBan ? `Ban ${a.ip} in fail2ban` : BAN_NOT_AVAILABLE}
                      onClick={() => actions.onBan(a.ip)}>
                      <Ban className="size-3.5" aria-hidden /> Ban…
                    </Button>
                  )}
                </TD>
              </TR>
            );
          })}
        </TBody>
      </TableInCard>
      {under && <div className="px-4 pt-3">{under}</div>}
      <div className="px-4 pb-1">
        <Pager page={paged.page} pages={paged.pages} total={rows.length} noun="addresses" onPage={paged.setPage} />
      </div>
    </>
  );
}
