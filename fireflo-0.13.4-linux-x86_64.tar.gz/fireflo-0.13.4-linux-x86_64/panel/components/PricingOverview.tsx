"use client";
import { useEffect } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { HealthStrip } from "./CardBits";
import { scopeHref, usePricingData } from "./PricingShell";
import { StatTile } from "@/components/ui/stat-tile";
import { UnratedPreflight } from "./UnratedPreflight";
import { useHealth } from "./useHealth";
import { readsRatesFromDatabase } from "@/lib/health-types";
import { DEFAULT_SCOPE, scopeKind } from "@/lib/rate-types";

/**
 * The Pricing overview: how much is priced, and what is wrong with it.
 *
 * <p>Also where old links land. `/cp/pricing?scope=&product=` is how the product page, the delivery
 * check and bookmarks open one scope; it now forwards to that scope's own page, opening a new price
 * for the product when one is named.
 */
export function PricingOverview() {
  const data = usePricingData();
  const { health } = useHealth();
  const router = useRouter();
  const params = useSearchParams();

  const linkedScope = params.get("scope");
  //?product= alone narrows the section rather than forwarding: the shell reads it
  const linkedProduct = params.get("product");
  useEffect(() => {
    if (linkedScope) router.replace(scopeHref(linkedScope, { new: !!linkedProduct, product: linkedProduct }));
  }, [linkedScope, linkedProduct, router]);

  const kind = (s: string) => scopeKind(s, data.known);
  if (data.product) return <ProductOverview product={data.product} />;
  const priced = new Set(data.scopes.map((s) => s.scope));
  const vendorsPriced = data.known.vendors.filter((v) => priced.has(v));
  const noCost = data.known.vendors.filter((v) => !priced.has(v));
  const accountsPriced = data.scopes.filter((s) => kind(s.scope) === "price").length;
  const unknown = data.scopes.filter((s) => kind(s.scope) === "unknown").map((s) => s.scope);
  const dflt = data.scopes.find((s) => s.scope === DEFAULT_SCOPE);
  const nothingStored = readsRatesFromDatabase(health) === true && !data.loading && !data.scopes.length;

  return (
    <>
      {nothingStored && (
        <HealthStrip tone="destructive">
          <strong>The gateway is reading pricing from this database, and there is none.</strong>{" "}
          Every message is accepted with no price and no cost. Import a file, or add pricing, now.
        </HealthStrip>
      )}

      <div className="grid gap-4 sm:grid-cols-3">
        <StatTile
          label="Vendors with a cost"
          value={`${vendorsPriced.length} of ${data.known.vendors.length}`}
          hint={noCost.length ? "A vendor without a cost makes its margin look better than it is" : "Every vendor has a cost"}
          loading={data.loading}
          tone={noCost.length ? "negative" : "default"}
        />
        <StatTile
          label="Accounts with their own price"
          value={`${accountsPriced} of ${data.known.accounts.length}`}
          hint={data.known.accounts.length - accountsPriced > 0 ? "The rest pay the default" : "Every account has its own pricing"}
          loading={data.loading}
        />
        <StatTile
          label="Default"
          value={dflt ? `${dflt.rules} ${dflt.rules === 1 ? "price" : "prices"}` : "Not set"}
          hint={dflt ? "What every account without its own pays" : "An account without its own pricing is not charged"}
          loading={data.loading}
          tone={dflt ? "default" : "negative"}
        />
      </div>

      {noCost.length > 0 && (
        <HealthStrip action={<Link href={scopeHref(noCost[0], { new: true })} className="text-sm font-semibold text-primary hover:underline">Set a cost →</Link>}>
          {noCost.join(", ")} {noCost.length === 1 ? "has" : "have"} no cost, so margin on {noCost.length === 1 ? "its" : "their"} traffic looks better than it is.
        </HealthStrip>
      )}
      {unknown.length > 0 && (
        <HealthStrip tone="destructive">
          {unknown.join(", ")} {unknown.length === 1 ? "is" : "are"} neither a configured vendor nor a known account, so {unknown.length === 1 ? "its" : "their"} prices
          load and match nothing. Open {unknown.length === 1 ? "it" : "them"} from the left to fix or delete.
        </HealthStrip>
      )}

      <UnratedPreflight />
    </>
  );
}

/**
 * The overview narrowed to one product: who has a cost for it, who has their own price, and whether
 * a default covers the rest. What the product page used to say, on the pricing page.
 */
function ProductOverview({ product }: { product: string }) {
  const data = usePricingData();
  const loading = data.loading || data.productScopes === null;
  const scopes = data.productScopes ?? [];
  const kind = (s: string) => scopeKind(s, data.known);
  const priced = new Set(scopes.map((s) => s.scope));
  const noCost = data.known.vendors.filter((v) => !priced.has(v));
  const accountsPriced = scopes.filter((s) => kind(s.scope) === "price").length;
  const dflt = scopes.find((s) => s.scope === DEFAULT_SCOPE);

  return (
    <>
      <div className="grid gap-4 sm:grid-cols-3">
        <StatTile
          label={`Vendors with a cost for ${product}`}
          value={`${data.known.vendors.length - noCost.length} of ${data.known.vendors.length}`}
          hint={noCost.length ? "A vendor without one makes margin look better than it is" : "Every vendor has a cost"}
          loading={loading}
          tone={noCost.length ? "negative" : "default"}
        />
        <StatTile
          label="Accounts with their own price"
          value={`${accountsPriced} of ${data.known.accounts.length}`}
          hint={data.known.accounts.length - accountsPriced > 0 ? `The rest pay the default for ${product}` : "Every account has its own price"}
          loading={loading}
        />
        <StatTile
          label={`Default for ${product}`}
          value={dflt ? (dflt.specificToProduct ? `${dflt.rules} ${dflt.rules === 1 ? "price" : "prices"}` : "Any product") : "Not set"}
          hint={dflt ? (dflt.specificToProduct ? "What every account without its own pays" : "A price for every product covers it") : `An account without its own price sends ${product} uncharged`}
          loading={loading}
          tone={dflt ? "default" : "negative"}
        />
      </div>

      {!loading && !dflt && (
        <HealthStrip tone="destructive"
          action={<Link href={scopeHref(DEFAULT_SCOPE, { new: true, product })} className="text-sm font-semibold text-primary hover:underline">Set what everyone pays →</Link>}>
          Nothing sets a default for {product}, so an account without its own price sends it <strong>unpriced and uncharged</strong> rather than being refused.
        </HealthStrip>
      )}
      {!loading && noCost.length > 0 && (
        <HealthStrip action={<Link href={scopeHref(noCost[0], { new: true, product })} className="text-sm font-semibold text-primary hover:underline">Set a cost →</Link>}>
          {noCost.join(", ")} {noCost.length === 1 ? "has" : "have"} no cost for {product}, so margin on {noCost.length === 1 ? "its" : "their"} traffic looks better than it is.
        </HealthStrip>
      )}
    </>
  );
}
