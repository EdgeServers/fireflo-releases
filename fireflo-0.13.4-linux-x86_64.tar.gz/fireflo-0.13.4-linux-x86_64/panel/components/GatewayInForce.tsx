"use client";
import { useCallback, useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SearchInput } from "@/components/SearchInput";
import { HealthStrip } from "@/components/CardBits";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";

/**
 * What the gateway has actually adopted, as opposed to what we have written.
 *
 * <p><strong>These are different questions and the panel has only ever answered the first.</strong>
 * The Settings tab reads `app_config`; this reads the running process. They disagree whenever a row
 * is saved but switched off, whenever the gateway has not polled since an edit, whenever a value
 * arrives from an environment variable no database row can override, and always in file mode, where
 * nothing the panel writes is read at all.
 *
 * <p>Read-only, deliberately. A screen that both reports the truth and lets you change it stops
 * being a reliable answer to "what is actually running".
 *
 * <p>Secrets arrive already blanked. This component does not decide what is sensitive and could not
 * — the value never leaves the gateway process.
 */

interface ResolvedEntry {
  key: string;
  value: string | null;
  tier: string;
  inherited: boolean;
  masked: boolean;
  /** `deprecated` or `retired` (gateway V1.88.0); absent on a current key and on an older gateway. */
  status?: string | null;
  replaced_by?: string | null;
}

interface ResolvedConfig {
  resolved_at: string;
  config_sources: Record<string, string>;
  global: ResolvedEntry[];
  workers: Record<string, ResolvedEntry[]>;
  masked_count: number;
}

export function GatewayInForce() {
  const [data, setData] = useState<ResolvedConfig | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/control/gateway-config-resolved", { cache: "no-store" });
      const body = await res.json();
      if (!res.ok) {
        //the distinction that matters on this tab: an empty table would read as "nothing is
        //configured", which is a claim about the gateway rather than about our ability to ask it
        setError(
          body?.error
            ?? "The gateway did not answer. This tab reports what it is running, so it has nothing "
              + "to show rather than nothing to report."
        );
        setData(null);
      } else {
        setError(null);
        setData(body.data ?? null);
      }
    } catch {
      setError("Could not reach the panel's own API.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  if (loading) {
    return <p className="text-sm text-muted-foreground">Asking the gateway…</p>;
  }

  if (error) {
    return <HealthStrip tone="destructive">{error}</HealthStrip>;
  }

  if (!data) {
    return null;
  }

  const source = data.config_sources?.properties ?? "unknown";
  const match = (e: ResolvedEntry) =>
    query.trim() === ""
    || e.key.toLowerCase().includes(query.trim().toLowerCase())
    || (e.value ?? "").toLowerCase().includes(query.trim().toLowerCase());

  const global = data.global.filter(match);
  const workerNames = Object.keys(data.workers);

  return (
    <>
      <div className="flex flex-wrap items-center gap-3">
        <p className="text-sm text-muted-foreground">
          Read from the running gateway at {new Date(data.resolved_at).toLocaleTimeString()}.
          Reading configuration from <span className="font-medium">{source}</span>.
        </p>
        <div className="ml-auto w-full sm:w-64">
          <SearchInput
            value={query}
            onChange={setQuery}
            placeholder="Search keys and values"
            ariaLabel="Search resolved configuration"
            className="w-full"
          />
        </div>
      </div>

      <EntryCard
        title="Gateway-wide"
        note="Every smsg.* key the process resolved."
        entries={global}
        total={data.global.length}
      />

      {workerNames.map((name) => {
        const entries = data.workers[name].filter(match);
        return (
          <EntryCard
            key={name}
            title={name}
            note="Resolved through this worker's own keys, then the gateway defaults."
            entries={entries}
            total={data.workers[name].length}
          />
        );
      })}

      {data.masked_count > 0 && (
        //said rather than left to inference: a column of asterisks could equally mean "no secrets
        //are set", and those are very different states to be in
        <p className="text-sm text-muted-foreground">
          {data.masked_count} {data.masked_count === 1 ? "value is" : "values are"} hidden because
          the key names a credential. The gateway blanks {data.masked_count === 1 ? "it" : "them"}
          {" "}before sending, so the panel never receives {data.masked_count === 1 ? "it" : "them"}.
        </p>
      )}
    </>
  );
}

function EntryCard({
  title,
  note,
  entries,
  total,
}: {
  title: string;
  note: string;
  entries: readonly ResolvedEntry[];
  total: number;
}) {
  return (
    <Card>
      <CardHeader>
        <div className="flex flex-wrap items-baseline gap-2">
          <CardTitle>{title}</CardTitle>
          <span className="ml-auto text-xs text-muted-foreground">
            {entries.length === total
              ? `${total} ${total === 1 ? "key" : "keys"}`
              : `${entries.length} of ${total}`}
          </span>
        </div>
        <p className="text-xs text-muted-foreground">{note}</p>
      </CardHeader>
      <CardContent>
        {entries.length === 0 ? (
          <p className="text-sm text-muted-foreground">Nothing matches.</p>
        ) : (
          <TableInCard>
            <THead>
              <TR>
                <TH>Key</TH>
                <TH>Value in force</TH>
                <TH>Came from</TH>
              </TR>
            </THead>
            <TBody>
              {entries.map((e) => (
                <TR key={e.key}>
                  <TD className="align-top">
                    <code className="font-mono text-sm break-all">{e.key}</code>
                    {/* the registry's word on the key, as the gateway reports it. A retired key in
                        force is still worth seeing: it is set, and it is doing nothing */}
                    {e.status === "retired" && (
                      <p className="mt-0.5 text-xs text-muted-foreground">Retired — has no effect</p>
                    )}
                    {e.status === "deprecated" && (
                      <p className="mt-0.5 text-xs text-warning">
                        Deprecated{e.replaced_by ? `: use ${e.replaced_by}` : ""}
                      </p>
                    )}
                  </TD>
                  <TD className="align-top">
                    <code
                      className={
                        e.masked
                          ? "font-mono text-sm tracking-widest text-muted-foreground"
                          : "font-mono text-sm break-all"
                      }
                    >
                      {e.value ?? "—"}
                    </code>
                  </TD>
                  <TD className="align-top whitespace-nowrap">
                    <Badge variant="outline">{sourceLabel(e)}</Badge>
                  </TD>
                </TR>
              ))}
            </TBody>
          </TableInCard>
        )}
      </CardContent>
    </Card>
  );
}

/**
 * Where the value came from, in words.
 *
 * <p>`inherited` is checked before the tier, and that ordering carries the meaning: a worker key
 * answered by `outSms.default.` is *inheriting*, and which physical map that default happened to sit
 * in is a detail nobody is asking about. Two workers showing the same value are in genuinely
 * different states when one carries it and the other inherits it — only the second changes when the
 * default changes, and that is the whole reason this column exists.
 */
function sourceLabel(entry: ResolvedEntry): string {
  if (entry.inherited) {
    return "gateway default";
  }
  switch (entry.tier) {
    case "memory":
      return "database or file";
    case "store":
      return "host (env var or application.properties)";
    case "overridden_default":
      return "startup override";
    case "coded_default":
      return "coded default";
    default:
      return entry.tier;
  }
}
