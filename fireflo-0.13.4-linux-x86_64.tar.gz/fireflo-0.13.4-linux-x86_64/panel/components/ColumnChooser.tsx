"use client";
import { Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import type { TableColumn } from "@/lib/table-columns";

/**
 * Which columns a table shows, as a grouped list of checkboxes.
 *
 * <p>Lifted out of `CdrsClient` when `/accounts` needed the same thing. Nothing here knows what a
 * call record or an account is — it takes a catalogue and reports toggles.
 *
 * <p>The groups are the chooser's own idea of order and have no effect on the table; a column's
 * position there comes from the catalogue. That is worth knowing before wondering why dragging does
 * nothing.
 */
export function ColumnChooser<Row, Group extends string>({
  columns,
  groups,
  enabled,
  locked,
  onToggle,
  onReset,
  note,
}: {
  columns: readonly TableColumn<Row, Group>[];
  groups: readonly Group[];
  /** Ids currently shown. A set rather than the resolved column list, so this stays comparison-free. */
  enabled: Set<string>;
  /**
   * Ids that cannot be turned off, drawn ticked and disabled.
   *
   * <p>Presentational only. The table's own resolver is what actually guarantees them — a disabled
   * checkbox stops a click, and does nothing about a preference written by an older release or by
   * hand, which is the case that would otherwise produce a table with no timestamp in it.
   */
  locked?: (id: string) => boolean;
  onToggle: (id: string, on: boolean) => void;
  onReset: () => void;
  note?: string;
}) {
  return (
    <Card>
      <CardContent className="space-y-4 py-4">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {groups.map((group) => (
            <div key={group} className="space-y-1.5">
              <p className="text-sm font-medium text-muted-foreground">{group}</p>
              {columns.filter((c) => c.group === group).map((column) => {
                const fixed = locked?.(column.id) ?? false;
                return (
                  <label
                    key={column.id}
                    className={`flex items-center gap-2 text-sm ${fixed ? "text-muted-foreground" : ""}`}
                    /* said rather than left to be discovered by clicking a box that does not move */
                    title={fixed ? "Always shown" : undefined}
                  >
                    <Checkbox
                      checked={fixed || enabled.has(column.id)}
                      disabled={fixed}
                      onChange={(e) => onToggle(column.id, e.target.checked)}
                    />
                    {column.header}
                    {fixed && <Lock className="h-3 w-3" aria-label="Always shown" />}
                  </label>
                );
              })}
            </div>
          ))}
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <Button type="button" variant="ghost" size="sm" onClick={onReset}>
            Reset to default
          </Button>
          <p className="text-sm text-muted-foreground">
            Kept in this browser.{note ? ` ${note}` : ""}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
