"use client";
import { useCallback, useEffect, useState } from "react";
import type { Credential, CredentialContext, CredentialInput } from "@/lib/credential-types";
import { surface } from "@/lib/panel-surface";

const EMPTY: CredentialContext = { products: [], disabledProducts: [], conflicts: [] };

/**
 * Loading and editing the logins.
 *
 * <p>Shaped like `useProducts`, with one difference worth knowing: a change here reaches the gateway
 * on its next configuration poll — up to thirty seconds — and there is no `/ops` verb that reloads
 * credentials sooner. The forms say so rather than implying it is instant.
 */
export function useCredentials() {
  const [credentials, setCredentials] = useState<Credential[]>([]);
  const [context, setContext] = useState<CredentialContext>(EMPTY);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<number | null>(null);
  /** Set when the write database is not configured at all, which is a different thing from an error. */
  const [disabled, setDisabled] = useState(false);

  const load = useCallback(async () => {
    try {
      const res = await fetch(`${surface().apiBase}/credentials`, { cache: "no-store" });
      const json = await res.json().catch(() => null);
      if (res.status === 503) {
        setDisabled(true);
        setError("");
        return;
      }
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        setCredentials([]);
        return;
      }
      setCredentials(json.data.credentials as Credential[]);
      setContext(json.data.context as CredentialContext);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const act = useCallback(
    async (id: number, run: () => Promise<Response>) => {
      setBusy(id);
      try {
        const res = await run();
        if (!res.ok) {
          const json = await res.json().catch(() => null);
          setError(json?.error ?? `Request failed (${res.status})`);
          return false;
        }
        setError("");
        await load();
        return true;
      } finally {
        setBusy(null);
      }
    },
    [load]
  );

  const setEnabled = useCallback(
    (id: number, enabled: boolean) =>
      act(id, () =>
        fetch(`${surface().apiBase}/credentials/${id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ enabled }),
        })
      ),
    [act]
  );

  const remove = useCallback(
    (id: number) => act(id, () => fetch(`${surface().apiBase}/credentials/${id}`, { method: "DELETE" })),
    [act]
  );

  /** @returns the server's message when it refused, or null — the form keeps unsaved work on screen */
  const save = useCallback(
    async (input: CredentialInput): Promise<string | null> => {
      const res = await fetch(
        input.id == null
          ? `${surface().apiBase}/credentials`
          : `${surface().apiBase}/credentials/${input.id}`,
        {
          method: input.id == null ? "POST" : "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(input),
        }
      );
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        return json?.error ?? `Request failed (${res.status})`;
      }
      await load();
      return null;
    },
    [load]
  );

  return { credentials, context, error, loading, busy, disabled, load, save, setEnabled, remove, setError };
}
