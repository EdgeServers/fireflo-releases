"use client";
import { useEffect, useRef } from "react";
import { createPollScheduler } from "@/lib/poll-scheduler";

/**
 * Runs `load` now and every `intervalMs` while `enabled`, pausing while the tab is hidden and
 * resuming with an immediate fetch when it is shown again.
 *
 * <p>For a component that is the only reader of its endpoint -- the queues page, the live traffic
 * chart -- where a shared store would be a store with one subscriber. Shared endpoints go through
 * `LiveGatewayProvider` instead. Same scheduler underneath (`lib/poll-scheduler.ts`), so the
 * visibility rule is written once.
 *
 * <p>`load` is read from the latest render on each tick, so a caller need not memoise it -- but a
 * change to `intervalMs`, `enabled` or `restartOn` restarts the schedule, with an immediate fetch.
 *
 * @param restartOn what the fetch depends on besides time -- a page size, a filter -- so that a
 *     change to it is read at once rather than on the next tick
 */
export function usePoll(
  load: () => void | Promise<void>,
  intervalMs: number,
  enabled = true,
  restartOn: unknown = null
) {
  //the ref pattern, by hand: an effect that depended on `load` would restart the interval -- and
  //fetch again -- on every render that produced a new closure
  const latest = useLatest(load);
  useEffect(() => {
    if (!enabled) {
      return;
    }
    const scheduler = createPollScheduler(() => void latest.current(), intervalMs, {
      visible: document.visibilityState === "visible",
    });
    const release = scheduler.acquire();
    const onVisibility = () => scheduler.setVisible(document.visibilityState === "visible");
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      release();
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [enabled, intervalMs, latest, restartOn]);
}

function useLatest<T>(value: T) {
  const ref = useRef(value);
  useEffect(() => {
    ref.current = value;
  });
  return ref;
}
