"use client";
import { useState } from "react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { InfoPopover } from "@/components/ui/popover";
import type { RejectedColumn } from "@/lib/rejected-columns";
import type { RejectedRow } from "@/lib/rejected-types";
import { reasonLabel, refusedAfterAccepting, vendorStatusName } from "@/lib/rejected-types";
import { formatTimestamp } from "@/lib/datetime";

/**
 * One cell of the refusals table, rendered by the format its column declares.
 *
 * <p><strong>A sibling of `CdrCell`, not a generalisation of it</strong>, and the decision is worth
 * stating because the opposite is the obvious move. Three things argue against merging them.
 * `CdrCell` is not actually generic-shaped: its `time` and `outcome` branches read `CdrRow` fields
 * directly rather than through `column.from`, so generalising means passing those in as a callback
 * bag — more machinery than the file it would replace. The two format vocabularies barely intersect;
 * a merged union would let `format: "money"` typecheck on a refusal column, which is exactly the
 * kind of nonsense a type is supposed to prevent. And the repository already has a second renderer
 * over the same shared `table-columns.ts` in `AccountTableCell`, so this is the established shape
 * rather than a new one.
 *
 * <p>What IS shared is the part with no row type in it: the catalogue machinery, the chooser, and
 * the stored choice.
 */
export function RejectedCell({
  column,
  row,
  detailHref,
}: {
  column: RejectedColumn;
  row: RejectedRow;
  /** Where this refusal's message lives, or null for a surface with no detail view. */
  detailHref?: (row: RejectedRow) => string | null;
}) {
  const value = column.from(row);

  //Handled BEFORE the blank check below, because for these formats the falsy values are the
  //content. `false` is an answer, `0` is a number, and a refusal with no detail still needs its
  //badge -- CdrCell short-circuits `outcome` first for the same reason.
  switch (column.format) {
    case "reason":
      return <ReasonBadge row={row} detailHref={detailHref} />;
    case "vendorStatus":
      return <VendorStatus status={row.vendorStatus} />;
    case "yesno":
      return value ? (
        <Badge variant="outline">Yes</Badge>
      ) : (
        <span className="text-muted-foreground">No</span>
      );
    case "countOrUnknown":
      //the gateway writes a primitive, so "not counted" arrives as 0 rather than NULL. Printing it
      //would claim a message with no parts, which is not a thing
      return value ? (
        <span className="tabular-nums">{String(value)}</span>
      ) : (
        <span className="text-muted-foreground" title="Refused before the segments were counted">
          —
        </span>
      );
    default:
      break;
  }

  if (value == null || value === "") {
    return <span className="text-muted-foreground">—</span>;
  }

  switch (column.format) {
    case "time":
      //suppressHydrationWarning: the server renders in the host's zone and the browser in the
      //viewer's, and React 19 throws on the mismatch rather than patching it up
      return (
        <span className="whitespace-nowrap tabular-nums text-sm" suppressHydrationWarning>
          {formatTimestamp(String(value))}
        </span>
      );

    case "ingress": {
      //the listener beside the protocol, which is how this cell has always read: "SMPP" alone does
      //not say which of three listeners took it
      const via = String(value);
      return (
        <span className="whitespace-nowrap text-sm text-muted-foreground">
          {via}
          {row.inGateway ? ` · ${row.inGateway}` : ""}
        </span>
      );
    }

    case "msgid": {
      const href = detailHref?.(row);
      const id = String(value);
      return href ? (
        <Link href={href} className="font-mono text-sm text-primary hover:underline">
          {id}
        </Link>
      ) : (
        <span className="font-mono text-sm">{id}</span>
      );
    }

    case "excerpt":
      return <LongText value={String(value)} />;

    case "number":
      return <span className="tabular-nums">{String(value)}</span>;

    case "id":
      return <span className="font-mono text-sm">{String(value)}</span>;

    default:
      return <span className="text-sm">{String(value)}</span>;
  }
}

/**
 * The refusal itself: what happened, why, and — when there is one — the message it happened to.
 *
 * <p>Exported so the narrow-screen cards can use it without inventing a column to pass in.
 */
export function ReasonBadge({
  row,
  detailHref,
}: {
  row: RejectedRow;
  detailHref?: (row: RejectedRow) => string | null;
}) {
  const href = row.gatewayMsgId ? detailHref?.(row) : null;
  const label = reasonLabel(row.reason);
  //the badge alone in the row, and what it means behind the i: the full sentence used to sit under
  //every badge and made each refusal five lines tall, so a page of fifty was mostly prose
  return (
    <span className="inline-flex items-center gap-1.5 whitespace-nowrap">
      <Badge variant="destructive">{label}</Badge>
      {(row.detail || row.gatewayMsgId) && (
        <InfoPopover label={label}>
          <span className="block text-xs font-semibold text-muted-foreground">{label}</span>
          {row.detail && <span className="mt-1 block break-words">{row.detail}</span>}
          {/* only the refusals that happened after acceptance have a message to point at, and those
              are the ones somebody arrives here holding an id for */}
          {row.gatewayMsgId && (
            <span className="mt-2 block border-t border-border pt-2 text-xs text-muted-foreground">
              {href ? (
                <Link href={href} className="font-mono text-primary hover:underline">{row.gatewayMsgId}</Link>
              ) : (
                <span className="font-mono text-foreground">{row.gatewayMsgId}</span>
              )}
              {refusedAfterAccepting(row.reason) && (
                <span className="mt-0.5 block">Accepted, then never sent. Any charge was refunded.</span>
              )}
            </span>
          )}
        </InfoPopover>
      )}
    </span>
  );
}

/**
 * The carrier's own number, kept visible beside the mnemonic rather than replaced by it.
 *
 * <p>The number is what a vendor's support desk will ask for; the mnemonic is what makes it mean
 * something here. Null for every refusal at the door, because those happen before a vendor sees the
 * message at all.
 */
export function VendorStatus({ status }: { status: number | null }) {
  if (status == null) {
    return <span className="text-muted-foreground">—</span>;
  }
  const name = vendorStatusName(status);
  return (
    <span className="whitespace-nowrap text-sm">
      <span className="font-mono">{status}</span>
      {name && <span className="ml-1.5 text-muted-foreground">{name}</span>}
    </span>
  );
}

/**
 * Free text in a table cell: one line until asked otherwise.
 *
 * <p>Both fields this renders are capped by the gateway — a refusal detail is a sentence and the
 * excerpt is 160 characters — but fifty rows of either still turns a table into a wall. Clicking
 * toggles rather than navigating, because this page has no detail view of its own to send anyone to.
 */
function LongText({ value }: { value: string }) {
  const [open, setOpen] = useState(false);
  //cheap enough to be worth avoiding a button that does nothing
  if (value.length <= 60) {
    return <span className="text-sm break-words text-muted-foreground">{value}</span>;
  }
  return (
    <button
      type="button"
      onClick={() => setOpen((v) => !v)}
      title={open ? "Show less" : "Show all of it"}
      aria-expanded={open}
      className={`max-w-xs cursor-pointer text-left text-sm break-words text-muted-foreground hover:text-foreground ${
        open ? "" : "line-clamp-2"
      }`}
    >
      {value}
    </button>
  );
}
