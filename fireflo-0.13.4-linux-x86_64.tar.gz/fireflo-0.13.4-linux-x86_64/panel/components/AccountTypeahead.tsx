"use client";
import { useId, useMemo, useRef, useState } from "react";
import { Search, X } from "lucide-react";
import { cn } from "@/lib/utils";

export interface AccountOption {
  id: string;
  label?: string | null;
  /** Shown as a hint beside the id, e.g. "sent in the last 15 minutes". */
  note?: string | null;
}

/** How many suggestions to list. Past this the operator is better served by typing one more letter. */
const MAX_SHOWN = 8;

/**
 * Pick one account by typing part of its id or name, or leave it empty for every account.
 *
 * <p>A dropdown stops working somewhere past thirty accounts: the list is longer than the screen
 * and the one you want is wherever the alphabet put it. Typing narrows it to the few that match.
 *
 * <p>Follows the ARIA 1.2 combobox pattern -- the input owns a listbox, arrow keys move the active
 * option, Enter picks it, Escape closes -- so it works from the keyboard and reads correctly.
 *
 * @param value the picked account id, or "" for all
 * @param allLabel what the empty value means, shown as the placeholder
 */
export function AccountTypeahead({
  value,
  onChange,
  options,
  allLabel = "All accounts",
  className,
}: {
  value: string;
  onChange: (id: string) => void;
  options: AccountOption[];
  allLabel?: string;
  className?: string;
}) {
  const listId = useId();
  const inputRef = useRef<HTMLInputElement>(null);
  const [text, setText] = useState(value);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);

  const term = text.trim().toLowerCase();
  const matches = useMemo(() => {
    const hits = term
      ? options.filter((o) => o.id.toLowerCase().includes(term) || o.label?.toLowerCase().includes(term))
      : options;
    //an id that starts with what was typed is almost always the one meant, so it goes first
    return [...hits]
      .sort((a, b) => Number(!a.id.toLowerCase().startsWith(term)) - Number(!b.id.toLowerCase().startsWith(term)))
      .slice(0, MAX_SHOWN);
  }, [options, term]);

  function pick(id: string) {
    onChange(id);
    setText(id);
    setOpen(false);
  }

  function clear() {
    onChange("");
    setText("");
    setOpen(false);
    inputRef.current?.focus();
  }

  return (
    <div className={cn("relative w-full sm:w-64", className)}>
      <Search className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
      <input
        ref={inputRef}
        type="text"
        role="combobox"
        aria-expanded={open && matches.length > 0}
        aria-controls={listId}
        aria-autocomplete="list"
        aria-activedescendant={open && matches[active] ? `${listId}-${active}` : undefined}
        aria-label="Show one account"
        autoComplete="off"
        spellCheck={false}
        value={text}
        placeholder={allLabel}
        onChange={(e) => {
          setText(e.target.value);
          setActive(0);
          setOpen(true);
          //emptying the box is the way back to every account; no separate "All" option to find
          if (!e.target.value.trim()) {
            onChange("");
          }
        }}
        onFocus={() => setOpen(true)}
        //on blur, a half-typed id that matches nothing would leave the box saying one thing and the
        //chart showing another, so the box snaps back to what is actually picked
        onBlur={() => {
          setOpen(false);
          setText(value);
        }}
        onKeyDown={(e) => {
          if (e.key === "ArrowDown") {
            e.preventDefault();
            setOpen(true);
            setActive((i) => Math.min(i + 1, matches.length - 1));
          } else if (e.key === "ArrowUp") {
            e.preventDefault();
            setActive((i) => Math.max(i - 1, 0));
          } else if (e.key === "Enter") {
            if (open && matches[active]) {
              e.preventDefault();
              pick(matches[active].id);
            }
          } else if (e.key === "Escape") {
            setOpen(false);
            setText(value);
          }
        }}
        className="h-11 w-full rounded-md border border-border bg-background pl-8 pr-8 font-mono text-sm placeholder:font-sans focus:border-primary focus:outline-none md:h-9"
      />
      {value && (
        <button
          type="button"
          onClick={clear}
          aria-label={`Clear, show ${allLabel.toLowerCase()}`}
          className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground hover:bg-accent hover:text-foreground"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      )}
      {open && (
        <ul
          id={listId}
          role="listbox"
          className="absolute right-0 z-20 mt-1 max-h-72 w-full min-w-56 overflow-auto rounded-md border border-border bg-card py-1 shadow-lg"
        >
          {matches.length === 0 ? (
            <li className="px-3 py-2 text-sm text-muted-foreground">No account matches “{text.trim()}”</li>
          ) : (
            matches.map((o, i) => (
              <li
                key={o.id}
                id={`${listId}-${i}`}
                role="option"
                aria-selected={o.id === value}
                //mousedown, not click: click fires after the input's blur, which has already closed
                //the list and reset the text
                onMouseDown={(e) => {
                  e.preventDefault();
                  pick(o.id);
                }}
                onMouseEnter={() => setActive(i)}
                className={cn(
                  "flex cursor-pointer items-baseline gap-2 px-3 py-1.5 text-sm",
                  i === active && "bg-accent",
                  o.id === value && "font-semibold"
                )}
              >
                <span className="font-mono">{o.id}</span>
                {o.label && o.label !== o.id && <span className="truncate text-muted-foreground">{o.label}</span>}
                {o.note && <span className="ml-auto shrink-0 text-2xs text-muted-foreground">{o.note}</span>}
              </li>
            ))
          )}
        </ul>
      )}
    </div>
  );
}
