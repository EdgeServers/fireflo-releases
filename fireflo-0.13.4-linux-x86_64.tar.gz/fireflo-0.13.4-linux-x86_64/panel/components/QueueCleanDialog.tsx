"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { count } from "@/lib/format";
import { isAdminSession } from "@/lib/roles";
import {
  EMPTY_SELECTOR,
  SUB_STORE_LABEL,
  applyBatch,
  batchHref,
  confirmationPhrase,
  confirmationSentence,
  confirms,
  holdsMessages,
  matchSummary,
  nextLimit,
  noun,
  readHousekeepingResult,
  recheck,
  selectorProblem,
  startLoop,
  stopSentence,
  type CleanSelector,
  type HousekeepingResult,
  type LoopState,
} from "@/lib/queue-clean";

/**
 * One call to the panel's clean route. Dry run unless told otherwise; the route sets the actor.
 *
 * @returns the gateway's answer, or the sentence that explains why there is none
 */
export async function cleanCall(
  selector: CleanSelector,
  opts: { dryRun: boolean; limit?: number; note?: string }
): Promise<{ result: HousekeepingResult } | { error: string }> {
  try {
    const res = await fetch("/api/control/queues/clean", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...selector, ...opts }),
    });
    const json = await res.json().catch(() => null);
    if (!res.ok) {
      return { error: json?.error ?? `The gateway refused (${res.status}).` };
    }
    return { result: readHousekeepingResult(json?.data) };
  } catch {
    return { error: "Could not reach the panel's API." };
  }
}

type Stage = "scope" | "confirm" | "running" | "done";

/**
 * Archive & clean, confirmed. Shared by the Queues page and the vendor and listener pages, so the
 * consequence sentence, the typed confirmation and the batch loop exist once.
 *
 * <p><strong>The number typed is the number archived, at most.</strong> The dialog dry-runs again
 * just before the first batch; if the count moved, it shows the new one and asks again. Each batch
 * then asks the gateway for no more than what is left of the confirmed count, so new traffic that
 * arrived since is never swept up unconfirmed.
 *
 * <p>The loop runs in this browser tab, one batch (at most ten thousand) per call, until the gateway
 * says nothing more matches, the confirmed count is reached, a batch reports failures, a batch
 * archives nothing, or the operator presses Stop — which lets the batch in flight finish, because a
 * batch is one transaction on the gateway and is never cut in half.
 *
 * @param choices sub-stores to offer as radio buttons (the vendor and listener pages); omitted, the
 *     selector is used as given (the Queues page, which has its own filter bar)
 */
export function QueueCleanDialog({
  selector: initial,
  title,
  choices,
  onClose,
  onDone,
}: {
  selector: CleanSelector;
  title: string;
  choices?: string[];
  onClose: () => void;
  onDone?: () => void;
}) {
  const [selector, setSelector] = useState<CleanSelector>(initial);
  const [stage, setStage] = useState<Stage>(choices ? "scope" : "confirm");
  const [counts, setCounts] = useState<Record<string, number | null>>({});
  const [dry, setDry] = useState<HousekeepingResult | null>(null);
  const [confirmed, setConfirmed] = useState(0);
  const [note, setNote] = useState("");
  const [typed, setTyped] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [loop, setLoop] = useState<LoopState | null>(null);
  const stopRequested = useRef(false);

  //the sub-store counts on the vendor and listener pages: one dry run each, in parallel. Keyed on the
  //list's text rather than its identity, so a caller passing an inline array does not re-count
  //on every render
  const choiceKey = choices?.join(",") ?? "";
  useEffect(() => {
    if (!choiceKey) {
      return;
    }
    let live = true;
    void Promise.all(
      choiceKey.split(",").map(async (sub) => {
        const r = await cleanCall({ ...initial, subStore: sub }, { dryRun: true });
        return [sub, "result" in r ? r.result.matched : null] as const;
      })
    ).then((pairs) => {
      if (live) {
        setCounts(Object.fromEntries(pairs));
      }
    });
    return () => {
      live = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- counted once per list, for the selector the dialog opened with
  }, [choiceKey]);

  //the Queues page opens straight on the confirmation, with a fresh dry run of its selector
  useEffect(() => {
    if (choices) {
      return;
    }
    void check(initial);
    // eslint-disable-next-line react-hooks/exhaustive-deps -- once, for the selector the dialog opened with
  }, []);

  async function check(sel: CleanSelector) {
    const problem = selectorProblem(sel);
    if (problem) {
      setError(problem);
      return;
    }
    setBusy(true);
    setError("");
    const r = await cleanCall(sel, { dryRun: true });
    setBusy(false);
    if ("error" in r) {
      setError(r.error);
      return;
    }
    setDry(r.result);
    setConfirmed(r.result.matched);
    setTyped("");
    setStage("confirm");
  }

  async function run() {
    setBusy(true);
    setError("");
    setNotice("");
    //read again: if the count moved since the operator agreed to it, they agree to the new one
    const fresh = await cleanCall(selector, { dryRun: true });
    if ("error" in fresh) {
      setBusy(false);
      setError(fresh.error);
      return;
    }
    const same = recheck(confirmed, fresh.result);
    if (!same.ok) {
      setBusy(false);
      setDry(fresh.result);
      setConfirmed(same.matched);
      setTyped("");
      setNotice(`The count changed while you were reading: ${count(same.matched)} match now. Confirm the new number.`);
      return;
    }

    stopRequested.current = false;
    let state = startLoop(confirmed);
    setLoop(state);
    setStage("running");
    while (!state.stopped) {
      const limit = nextLimit(state);
      if (limit <= 0) {
        state = { ...state, stopped: "confirmed-reached" };
        break;
      }
      const r = await cleanCall(selector, { dryRun: false, limit, note });
      if ("error" in r) {
        setError(r.error);
        state = { ...state, stopped: state.stopped ?? "failed" };
        break;
      }
      state = applyBatch(state, r.result);
      if (!state.stopped && stopRequested.current) {
        state = { ...state, stopped: "cancelled" };
      }
      setLoop(state);
    }
    setLoop(state);
    setBusy(false);
    setStage("done");
    onDone?.();
  }

  const store = selector.store;
  const phrase = confirmationPhrase(confirmed);

  return (
    <Dialog open onClose={stage === "running" ? () => {} : onClose} title={title} className="max-w-lg">
      <div className="space-y-4 text-sm">
        {stage === "scope" && choices && (
          <>
            <p className="text-muted-foreground">
              Stop sending or Hold first if you only need it to stop. Cleaning ends messages for good: each is archived,
              refunded if charged, and recorded as refused.
            </p>
            <fieldset className="space-y-1.5">
              <legend className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">What</legend>
              {choices.map((sub) => (
                <label key={sub} className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="sub-store"
                    checked={selector.subStore === sub}
                    onChange={() => setSelector((s) => ({ ...s, subStore: sub }))}
                  />
                  <span>{SUB_STORE_LABEL[sub] ?? sub}</span>
                  <span className="ml-auto tabular-nums text-muted-foreground">
                    {counts[sub] === undefined ? "…" : counts[sub] == null ? "?" : count(counts[sub]!)}
                  </span>
                </label>
              ))}
            </fieldset>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Account" hint="Optional: only this account's messages.">
                <Input value={selector.account} onChange={(e) => setSelector((s) => ({ ...s, account: e.target.value }))} placeholder="any" />
              </Field>
              <Field label="Older than" hint="Optional: 90s, 30m, 2h, 3d.">
                <Input value={selector.olderThan} onChange={(e) => setSelector((s) => ({ ...s, olderThan: e.target.value }))} placeholder="any age" />
              </Field>
            </div>
            {error && <p className="text-destructive">{error}</p>}
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
              <Button size="sm" disabled={busy || !selector.subStore} onClick={() => check(selector)}>
                {busy ? "Checking…" : "Check"}
              </Button>
            </div>
          </>
        )}

        {stage === "confirm" && !dry && (
          <p className="text-muted-foreground">
            {busy ? <><Loader2 className="mr-2 inline h-4 w-4 animate-spin" />Counting what matches…</> : error || "…"}
          </p>
        )}

        {stage === "confirm" && dry && (
          <>
            <p className="font-medium">{matchSummary(store, dry)}</p>
            {confirmed === 0 ? (
              <p className="text-muted-foreground">Nothing matches, so there is nothing to clean.</p>
            ) : (
              <>
                <p className="text-destructive">{confirmationSentence(store, confirmed, dry)}</p>
                {Object.keys(dry.byWorker).length > 0 && (
                  <p className="text-xs text-muted-foreground">
                    {Object.entries(dry.byWorker).map(([w, n]) => `${w} ${count(n)}`).join(" · ")}
                  </p>
                )}
                <Field label="Note" hint="Why. Recorded on every archived entry and in the operator log.">
                  <Textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2} placeholder="stuck after vendor outage" />
                </Field>
                <Field label={`Type ${phrase} to confirm`}>
                  <Input value={typed} onChange={(e) => setTyped(e.target.value)} placeholder={phrase} autoComplete="off" />
                </Field>
              </>
            )}
            {notice && <p className="text-warning">{notice}</p>}
            {error && <p className="text-destructive">{error}</p>}
            <div className="flex justify-end gap-2">
              {choices && (
                <Button variant="ghost" size="sm" disabled={busy} onClick={() => setStage("scope")}>Back</Button>
              )}
              <Button variant="outline" size="sm" disabled={busy} onClick={onClose}>Cancel</Button>
              <Button
                size="sm"
                disabled={busy || confirmed === 0 || !note.trim() || !confirms(typed, confirmed)}
                onClick={run}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                {busy ? "Checking…" : `Archive and end ${count(confirmed)}`}
              </Button>
            </div>
          </>
        )}

        {(stage === "running" || stage === "done") && loop && (
          <>
            <div className="h-2 overflow-hidden rounded-full bg-muted" aria-hidden>
              <div
                className="h-full bg-destructive transition-all"
                style={{ width: `${loop.confirmed ? Math.min(100, (loop.archived / loop.confirmed) * 100) : 100}%` }}
              />
            </div>
            <p className="tabular-nums">
              {count(loop.archived)} of {count(loop.confirmed)} {noun(store, loop.confirmed)} archived
              {holdsMessages(store) && ` · ${count(loop.refunded)} refunded · ${count(loop.receiptsSent)} failed receipts sent`}
              {` · ${loop.calls} batch${loop.calls === 1 ? "" : "es"}`}
            </p>
            {stage === "done" && <p>{stopSentence(loop, store)}</p>}
            {error && <p className="text-destructive">{error}</p>}
            {stage === "done" && loop.batchIds.length > 0 && (
              <p className="flex flex-wrap gap-x-3 text-xs">
                {loop.batchIds.map((id) => (
                  <Link key={id} href={batchHref(id)} className="text-primary hover:underline">
                    Batch {id.slice(0, 8)}… on Reports → Archives
                  </Link>
                ))}
              </p>
            )}
            <div className="flex justify-end gap-2">
              {stage === "running" ? (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    stopRequested.current = true;
                    setNotice("Stopping after the batch in flight…");
                  }}
                >
                  <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" /> Stop
                </Button>
              ) : (
                <Button size="sm" onClick={onClose}>Close</Button>
              )}
            </div>
            {notice && stage === "running" && <p className="text-xs text-muted-foreground">{notice}</p>}
          </>
        )}
      </div>
    </Dialog>
  );
}


const VENDOR_CHOICES = ["held", "pending", "retry"];
const LISTENER_CHOICES = ["held", "pending", "retry", "parked"];

/**
 * "Clean queue…" in a vendor's or a listener's footer, beside Stop sending, Hold and Restart. Shown
 * to admins, and only while the worker has something waiting — a button that opens onto "nothing
 * matches" is noise in a footer read during an incident.
 *
 * @param worker the full name the gateway uses, `smppclient.<n>` or `smppserver.<n>`
 */
export function CleanQueueButton({
  worker,
  listener,
  waiting,
  onDone,
}: {
  worker: string;
  listener: boolean;
  waiting: boolean;
  onDone?: () => void;
}) {
  const { data: session } = useSession();
  const [open, setOpen] = useState(false);
  if (!isAdminSession(session) || !waiting) {
    return null;
  }
  return (
    <>
      <Button
        variant="ghost"
        size="sm"
        className="text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
        title="Archive and end what is waiting here: refunded, failed receipts sent, recorded as refused. Stop sending or Hold first if you only need it to stop."
        onClick={() => setOpen(true)}
      >
        Clean queue…
      </Button>
      {open && (
        <QueueCleanDialog
          selector={{ ...EMPTY_SELECTOR, store: "worker", worker, subStore: "held" }}
          title={`Clean ${worker}`}
          choices={listener ? LISTENER_CHOICES : VENDOR_CHOICES}
          onClose={() => setOpen(false)}
          onDone={onDone}
        />
      )}
    </>
  );
}
