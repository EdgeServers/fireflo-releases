"use client";
import { platformOf } from "@/lib/account-columns";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Wallet } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { BackLink } from "./BackLink";
import { useAccountContext } from "./useAccountContext";
import { useAccounts } from "./useAccounts";
import { useRates } from "./useRates";
import { scopeKind } from "@/lib/rate-types";
import { money } from "@/lib/format";
import { accountHref, surface } from "@/lib/panel-surface";

/**
 * The frame every account tab sits in: who this account is, and the way between its tabs.
 *
 * <p>One page held twelve cards and fired nine requests to paint them. Splitting it into tabs is
 * the obvious fix; making the tabs <strong>routes</strong> rather than client state is what makes it
 * worth doing. Each tab loads only when it is opened, without a single `if (tab === …)`; the two
 * pages that were already separate routes — the tariff and the statement — keep their URLs and stop
 * being links out of a page into nowhere; and a tab can be sent to somebody.
 *
 * <p><strong>The id comes from the URL and nothing here requires a catalogue row.</strong> That is
 * not a fallback: an account exists the moment a login names it or a message arrives for it, and
 * `app_account` is a label bolted on afterwards.
 */
export function AccountShell({ id, children }: { id: string; children: React.ReactNode }) {
  const pathname = usePathname();
  const { accounts, archived } = useAccounts();
  //what this surface may show about what an account is charged. False in the customer portal, where
  //a reseller manages the accounts beneath it and never sees their pricing -- see
  //lib/panel-surface.ts. Four things below hang off it, and each is a different kind of leak
  const { pricing } = surface();
  //fetched on both surfaces now: the portal has its own scoped context route, and the balance in
  //this header is the figure a reseller opens a child's page for. What that route does NOT return
  //is the rate scopes and the carriers -- see app/api/mis/accounts/[id]/context
  const { context } = useAccountContext(id);
  const { known } = useRates();

  const catalogued = accounts.find((a) => a.id === id) ?? archived.find((a) => a.id === id) ?? null;
  const kind = scopeKind(id, known);
  const balance = context?.balance ?? null;
  const postpaid = balance?.billingMode === "POSTPAID";
  const tabs = TABS.filter((tab) => pricing || RESELLER_TABS.includes(tab.slug));

  return (
    //space-y-5 at the root, the main's own rhythm — this one was wearing a tab body's space-y-4
    //and so put the same 16px between the back link, the header, the tab bar and the content,
    //leaving the tabs reading as part of the page rather than as chrome above it
    <div className="space-y-5">
      {/* the chrome, held together at its own tighter rhythm so it reads as one block and the
          step down to the content is the largest gap on the page */}
      <div className="space-y-4">
      <BackLink href={surface().linkBase}>All accounts</BackLink>

      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
          <Wallet className="h-5 w-5 shrink-0 text-muted-foreground" />
          <h1 className="text-page max-sm:text-entity">{catalogued?.label || id}</h1>
          {catalogued?.label && (
            <span className="font-mono text-sm text-muted-foreground">{id}</span>
          )}
          {/* a rate-scope collision, so it is a pricing fact and reads as one -- and `known` is
              empty on a surface that fetched no rates, so this could never fire there anyway */}
          {pricing && kind === "cost" && <Badge variant="destructive">also a vendor name</Badge>}
          {catalogued?.archivedAt
            ? <Badge variant="destructive">archived</Badge>
            : catalogued && !catalogued.enabled && <Badge variant="outline">disabled</Badge>}
          {catalogued?.resells && <Badge>reseller</Badge>}
          {catalogued?.externalRef && (
            <Badge variant="outline" title={`Managed by ${catalogued.externalRef}`}>
              Managed by {platformOf(catalogued.externalRef)}
            </Badge>
          )}
          {!catalogued && <Badge variant="warning">not in the catalogue</Badge>}

          {/* prepaid shows what it holds, postpaid what it may owe. Reading a credit limit as a
              balance is the one misreading that costs money, so they are never both called the
              same thing */}
          {balance && (
            <span className="ml-auto min-w-0 text-sm text-muted-foreground">
              {postpaid ? "Limit" : "Balance"}{" "}
              <span className="tabular-nums text-foreground">
                {money(postpaid ? balance.creditLimit : balance.balance, balance.currency ?? "")}
              </span>
            </span>
          )}
        </div>
      </div>

      <AccountTabs id={id} pathname={pathname} tabs={tabs} />
      </div>

      {children}
    </div>
  );
}

const TABS = [
  { slug: "", label: "Overview" },
  { slug: "settings", label: "Settings" },
  { slug: "logins", label: "Logins" },
  { slug: "approvals", label: "Approvals" },
  { slug: "billing", label: "Billing" },
  { slug: "tariff", label: "Tariff" },
  { slug: "statement", label: "Statement" },
] as const;

/**
 * What a surface without pricing gets. An allow-list, not a denial list.
 *
 * <p>Positive on purpose: a tab added to `TABS` later appears on the operator panel and nowhere else
 * until somebody decides it belongs here. A denial list would have the opposite default, and the
 * cost of forgetting to add to it is a customer seeing an operator's screen.
 *
 * <p><strong>Tariff is the only one left out</strong>, and it is the whole point: a reseller manages
 * the accounts beneath it and does not set what they are charged. Its own margin is settled
 * off-platform.
 *
 * <p>The other five are here, but two of them are NOT the operator's component behind the same
 * slug, because the operator's carries a verb that is not a reseller's:
 *
 * <ul>
 *   <li><strong>Approvals</strong> — the operator renders `AccountWhitelistSection`, whose verbs are
 *       approve and reject. The whole point of the approval flow is that the party sending is not
 *       the party deciding. The portal's page renders the child's registrations and lets a reseller
 *       request one on their behalf; it lands PENDING like any other request.</li>
 *   <li><strong>Statement</strong> — the operator renders `StatementClient`, which closes a period.
 *       That is an irreversible write that mints an invoice, and it belongs to whoever does the
 *       invoicing. The portal's page renders the same read-only statement a customer sees of its
 *       own, scoped to the child.</li>
 * </ul>
 *
 * <p>Overview and Billing ARE the operator's components, with the pricing pieces inside them gated
 * off the same flag — see `AccountsClient`'s cost column and `AccountOverviewClient`'s carrier list.
 */
const RESELLER_TABS: readonly string[] = ["", "settings", "logins", "approvals", "billing", "statement"];

function AccountTabs({
  id,
  pathname,
  tabs,
}: {
  id: string;
  pathname: string;
  tabs: readonly { slug: string; label: string }[];
}) {
  const base = accountHref(id);
  //the encoded id is what is in the URL, so compare against the encoded base rather than the raw
  //one -- an account id with a slash or a space in it would never match otherwise
  const current = pathname.startsWith(base) ? pathname.slice(base.length).replace(/^\//, "") : "";

  return (
    //scrolls rather than wraps: seven tabs on a phone would otherwise take three lines and push the
    //content the operator came for below the fold
    <nav className="-mb-px flex gap-1 overflow-x-auto border-b border-border" aria-label="Account">
      {tabs.map((tab) => {
        const active = current === tab.slug;
        return (
          <Link
            key={tab.slug}
            href={tab.slug ? `${base}/${tab.slug}` : base}
            aria-current={active ? "page" : undefined}
            className={`whitespace-nowrap border-b-2 px-3 py-2 text-sm transition-colors ${
              active
                ? "border-foreground text-foreground"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab.label}
          </Link>
        );
      })}
    </nav>
  );
}
