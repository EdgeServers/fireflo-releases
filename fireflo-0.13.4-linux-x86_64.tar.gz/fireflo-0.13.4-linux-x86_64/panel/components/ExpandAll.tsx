"use client";
import { useCallback, useMemo, useState } from "react";
import { ChevronsDownUp, ChevronsUpDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { HealthSession } from "@/lib/health-types";
import { accountsIn } from "./SessionList";

/**
 * Which account groups of a session table are open, and the button that opens them all.
 *
 * <p>The set lives with whoever owns the rows rather than inside the table, because the rows are
 * redrawn under it: every ten seconds by the health poll, and on every Refresh and page turn in the
 * browser. A table that kept its own open set would close on each of those. "Expand all" opens the
 * accounts in the <em>current</em> view — the page, or the search result — and reads "Collapse
 * all" while every one of them is open.
 */
export interface ExpandedAccounts {
  /** The accounts in the current rows, busiest first — what Expand all opens. */
  names: string[];
  expanded: ReadonlySet<string>;
  /** Whether every current account is open, which is when the button offers to collapse. */
  allOpen: boolean;
  toggle: (account: string) => void;
  expandAll: () => void;
  collapseAll: () => void;
}

export function useExpandedAccounts(sessions: readonly HealthSession[]): ExpandedAccounts {
  const [expanded, setExpanded] = useState<ReadonlySet<string>>(() => new Set());
  const names = useMemo(() => accountsIn(sessions), [sessions]);
  const allOpen = names.length > 0 && names.every((name) => expanded.has(name));

  const toggle = useCallback((account: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(account)) {
        next.delete(account);
      } else {
        next.add(account);
      }
      return next;
    });
  }, []);
  //adds to what is open rather than replacing it: an account opened on page one stays open when
  //page two is expanded and the operator comes back
  const expandAll = useCallback(() => {
    setExpanded((prev) => new Set([...prev, ...names]));
  }, [names]);
  const collapseAll = useCallback(() => {
    setExpanded(() => new Set());
  }, []);

  return { names, expanded, allOpen, toggle, expandAll, collapseAll };
}

export function ExpandAllButton({ accounts }: { accounts: ExpandedAccounts }) {
  const { names, allOpen, expandAll, collapseAll } = accounts;
  const Icon = allOpen ? ChevronsDownUp : ChevronsUpDown;
  return (
    <Button
      variant="outline"
      size="sm"
      className="h-8 gap-1.5"
      disabled={names.length === 0}
      aria-pressed={allOpen}
      title={allOpen ? "Close every account in this view" : "Open every account in this view"}
      onClick={allOpen ? collapseAll : expandAll}
    >
      <Icon className="h-3.5 w-3.5" aria-hidden />
      {allOpen ? "Collapse all" : "Expand all"}
    </Button>
  );
}
