"use client";
import { useCallback, useEffect, useState } from "react";
import type { TlvDefinition } from "@/lib/tlv-catalogue";

/** One TLV declaration found somewhere in the configuration. */
export interface TlvUsage {
  tag: number;
  name: string;
  where: string;
  setting: string;
}

/**
 * Operator-defined TLV names, and where TLVs are declared in this deployment.
 *
 * <p>Same shape as `useProducts`, minus the gateway push: the gateway never reads
 * `app_tlv_definition`, so a change here is complete the moment the row is written and there is no
 * "within thirty seconds" to explain.
 *
 * <p><strong>Degrades to nothing rather than to an error.</strong> Every consumer of this is a form
 * or a detail page whose real job is something else, and a definitions lookup that fails must not put
 * a red banner on a page about a message. An empty list is the correct fallback — tags simply render
 * without operator names, which is what stage one did on purpose.
 */
export function useTlvDefinitions({ enabled = true }: { enabled?: boolean } = {}) {
  const [definitions, setDefinitions] = useState<TlvDefinition[]>([]);
  /**
   * Decisions about which tags are offered, keyed by tag.
   *
   * <p>Named `suggested` rather than `enabled` on purpose, and not only to avoid colliding with this
   * hook's own `enabled` fetch gate: the flag controls a dropdown and nothing else, and a word that
   * implied a tag was switched off would be a claim about the gateway that is not true.
   */
  const [suggested, setSuggestedMap] = useState<Record<number, boolean>>({});
  const [usage, setUsage] = useState<TlvUsage[] | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(enabled);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    if (!enabled) {
      return;
    }
    try {
      const res = await fetch("/api/control/tlvs", { cache: "no-store" });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        //kept for the reference page, which does want to say why. The forms ignore it
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      setDefinitions(json.data.definitions as TlvDefinition[]);
      setSuggestedMap((json.data.suggestions as Record<number, boolean>) ?? {});
      setUsage((json.data.usage as TlvUsage[] | null) ?? null);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setLoading(false);
    }
  }, [enabled]);

  useEffect(() => {
    load();
  }, [load]);

  const save = useCallback(
    async (input: { tag: number; name: string; label?: string; description?: string }) => {
      setBusy(true);
      try {
        const res = await fetch("/api/control/tlvs", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(input),
        });
        const json = await res.json().catch(() => null);
        if (!res.ok) {
          setError(json?.error ?? `Request failed (${res.status})`);
          return false;
        }
        setError("");
        await load();
        return true;
      } finally {
        setBusy(false);
      }
    },
    [load]
  );

  /** One tag or many. The reference page passes whatever the search box currently matches. */
  const setSuggested = useCallback(
    async (tags: readonly number[], value: boolean) => {
      if (!tags.length) {
        return;
      }
      setBusy(true);
      try {
        const res = await fetch("/api/control/tlvs", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ tags, suggested: value }),
        });
        if (!res.ok) {
          const json = await res.json().catch(() => null);
          setError(json?.error ?? `Request failed (${res.status})`);
          return;
        }
        setError("");
        await load();
      } finally {
        setBusy(false);
      }
    },
    [load]
  );

  const remove = useCallback(
    async (tag: number) => {
      setBusy(true);
      try {
        const res = await fetch(`/api/control/tlvs/${tag}`, { method: "DELETE" });
        if (!res.ok) {
          const json = await res.json().catch(() => null);
          setError(json?.error ?? `Request failed (${res.status})`);
          return;
        }
        setError("");
        await load();
      } finally {
        setBusy(false);
      }
    },
    [load]
  );

  return { definitions, suggested, usage, error, loading, busy, load, save, setSuggested, remove };
}
