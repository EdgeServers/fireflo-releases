"use client";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

/**
 * The one commit point on a page of staged edits, pinned to the bottom of the window while anything
 * is unsaved.
 *
 * <p>Shared by the Gateway and Error codes pages so the two behave alike: nothing reaches the
 * gateway until Save, Discard throws every staged edit away, and a value that cannot be saved keeps
 * Save off and says why.
 */
export function SaveBar({
  count,
  saving,
  blocked = false,
  message = "Nothing has reached the gateway yet.",
  blockedMessage = "Fix the highlighted value before saving.",
  onDiscard,
  onSave,
  inset = false,
}: {
  count: number;
  saving: boolean;
  blocked?: boolean;
  message?: string;
  blockedMessage?: string;
  onDiscard: () => void;
  onSave: () => void;
  /**
   * Draw as a floating card inside its column rather than a full-width bar. For a page whose
   * content sits in a column beside a list, where an edge-to-edge bar would start mid-page.
   */
  inset?: boolean;
}) {
  if (count === 0) {
    return null;
  }
  return (
    <div
      className={cn(
        "sticky bottom-0 z-10 flex flex-wrap items-center gap-3 bg-card/95 py-3 backdrop-blur",
        inset
          ? "mb-2 rounded-xl border border-border px-4"
          : "-mx-4 border-t border-border px-4 md:-mx-6 md:px-6"
      )}
    >
      <p className="min-w-0 flex-[1_1_320px] text-sm">
        <span className="font-semibold">
          {count} unsaved {count === 1 ? "change" : "changes"}.
        </span>{" "}
        <span className="text-muted-foreground">{blocked ? blockedMessage : message}</span>
      </p>
      <div className="flex w-full gap-2 sm:w-auto">
        <Button type="button" variant="outline" className="flex-1 sm:flex-none" disabled={saving} onClick={onDiscard}>
          Discard
        </Button>
        <Button type="button" className="flex-1 sm:flex-none" disabled={saving || blocked} onClick={onSave}>
          {saving ? "Saving…" : `Save ${count === 1 ? "1 change" : `${count} changes`}`}
        </Button>
      </div>
    </div>
  );
}
