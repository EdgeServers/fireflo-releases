"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useConfirmChange, useConfirmDelete } from "./ConfirmProvider";
import { PasswordFields } from "./PasswordFields";
import { formatTimestamp } from "@/lib/datetime";
import type { PublicUser } from "@/lib/user-types";

/**
 * Everybody who can sign in to the portal for this account, and how.
 *
 * <p>One row per login, each with its own state read back from the database after every change --
 * "Password set" or "Link only", when it last signed in, whether it is on. This replaces a card that
 * edited the account's own address alone, and so could show "no address" and "1 more login" at once.
 *
 * @param onChanged called after any change, so the page's activity history can show it
 */
export function PortalAccessCard({ id, onChanged }: { id: string; onChanged: () => void }) {
  const [logins, setLogins] = useState<PublicUser[] | null>(null);
  const [accountEmail, setAccountEmail] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);

  const url = `/api/control/accounts/${encodeURIComponent(id)}/portal-logins`;

  const load = useCallback(async () => {
    try {
      const res = await fetch(url, { cache: "no-store" });
      const json = await res.json().catch(() => null);
      if (res.ok && json?.data) {
        setLogins(json.data.logins as PublicUser[]);
        setAccountEmail(json.data.accountEmail ?? null);
        setError(null);
      } else {
        setError(json?.error ?? "Could not read the portal logins.");
      }
    } catch {
      setError("Could not reach the panel.");
    }
  }, [url]);

  useEffect(() => {
    void load();
  }, [load]);

  const changed = useCallback(() => {
    void load();
    onChanged();
  }, [load, onChanged]);

  return (
    <Card>
      <CardHeader bar className="flex flex-row items-center gap-2 space-y-0">
        <CardTitle>Portal access</CardTitle>
        {logins && <span className="ml-auto text-xs text-muted-foreground">{logins.length} login{logins.length === 1 ? "" : "s"}</span>}
      </CardHeader>
      <CardContent className="space-y-3 text-sm">
        {error && <p className="text-xs text-destructive">{error}</p>}
        {logins && logins.length === 0 && !adding && (
          <p className="text-muted-foreground">Nobody can sign in to the portal for this account yet.</p>
        )}
        {logins?.map((login) => (
          <LoginRow
            key={login.id}
            url={url}
            login={login}
            isAccountEmail={!!accountEmail && accountEmail.toLowerCase() === login.email.toLowerCase()}
            onChanged={changed}
          />
        ))}
        {/* the login is the account's own email: set in Organisation, never typed again here.
            Saving that email already creates its login, so this only appears when it is missing */}
        {logins && (!accountEmail ? (
          <p className="text-xs text-muted-foreground">
            Set the account&rsquo;s email under Organisation to give it a portal login.
          </p>
        ) : logins.some((l) => l.email.toLowerCase() === accountEmail.toLowerCase()) ? null : adding ? (
          <AddLogin url={url} email={accountEmail} onDone={(added) => { setAdding(false); if (added) changed(); }} />
        ) : (
          <Button size="sm" variant="outline" onClick={() => setAdding(true)}>
            <Plus className="size-3.5" aria-hidden />
            Create a login for {accountEmail}
          </Button>
        ))}
      </CardContent>
    </Card>
  );
}

function LoginRow({
  url,
  login,
  isAccountEmail,
  onChanged,
}: {
  url: string;
  login: PublicUser;
  isAccountEmail: boolean;
  onChanged: () => void;
}) {
  const [settingPassword, setSettingPassword] = useState(false);
  const [password, setPassword] = useState("");
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const confirm = useConfirmChange();
  const confirmDelete = useConfirmDelete();

  async function patch(body: Record<string, unknown>) {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(url, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: login.id, ...body }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? "Not saved.");
        return;
      }
      setSettingPassword(false);
      setPassword("");
      setReady(false);
      onChanged();
    } catch {
      setError("Could not reach the panel.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-2 border-t border-border pt-3 first:border-t-0 first:pt-0">
      <div className="flex flex-wrap items-center gap-1.5">
        <span className="min-w-0 break-all font-medium">{login.email}</span>
        {isAccountEmail && <Badge variant="outline">account address</Badge>}
        {!login.enabled && <Badge variant="destructive">off</Badge>}
      </div>
      <dl className="space-y-1 text-xs">
        <div className="flex justify-between gap-3">
          <dt className="text-muted-foreground">Signs in with</dt>
          <dd suppressHydrationWarning>
            {login.hasPassword
              ? <span className="text-success">Password, or emailed link</span>
              : "Emailed link only"}
          </dd>
        </div>
        <div className="flex justify-between gap-3">
          <dt className="text-muted-foreground">Last sign-in</dt>
          <dd suppressHydrationWarning>{login.lastLoginAt ? formatTimestamp(login.lastLoginAt) : "never"}</dd>
        </div>
      </dl>

      {settingPassword && (
        <PasswordFields
          value={password}
          email={login.email}
          labels={{ password: "Portal password", confirm: "Confirm portal password" }}
          onChange={(pw, ok) => {
            setPassword(pw);
            setReady(ok);
          }}
        />
      )}
      {error && <p className="text-xs text-destructive">{error}</p>}

      <div className="flex flex-wrap items-center gap-1.5">
        {settingPassword ? (
          <>
            <Button size="sm" disabled={busy || !ready} onClick={async () => {
              if (!(await confirm({
                title: login.hasPassword ? "Change this password?" : "Set this password?",
                consequence: `${login.email} signs in to the portal with the new password from now on.`,
                confirmLabel: "Save password",
                tone: "caution",
              }))) {
                return;
              }
              void patch({ password });
            }}>
              {busy ? "Saving…" : "Save password"}
            </Button>
            <Button size="sm" variant="ghost" disabled={busy} onClick={() => { setSettingPassword(false); setPassword(""); }}>
              Cancel
            </Button>
          </>
        ) : (
          <>
            <Button size="sm" variant="outline" disabled={busy} onClick={() => setSettingPassword(true)}>
              {login.hasPassword ? "Change password" : "Set password"}
            </Button>
            {login.hasPassword && (
              <Button size="sm" variant="ghost" disabled={busy}
                className="text-destructive hover:text-destructive"
                onClick={async () => {
                  if (!(await confirmDelete({
                    title: "Remove this password?",
                    consequence: `${login.email} signs in by emailed link until a password is set again.`,
                    confirmLabel: "Remove password",
                  }))) {
                    return;
                  }
                  void patch({ clearPassword: true });
                }}>
                Remove password
              </Button>
            )}
            <Button size="sm" variant="ghost" disabled={busy} onClick={async () => {
              if (!(await confirm({
                title: login.enabled ? "Turn this portal login off?" : "Turn this portal login on?",
                consequence: login.enabled
                  ? `${login.email} can no longer sign in to the portal.`
                  : `${login.email} can sign in to the portal again.`,
                confirmLabel: login.enabled ? "Turn off" : "Turn on",
                tone: "caution",
              }))) {
                return;
              }
              void patch({ enabled: !login.enabled });
            }}>
              {login.enabled ? "Turn off" : "Turn on"}
            </Button>
          </>
        )}
      </div>
    </div>
  );
}

function AddLogin({ url, email, onDone }: { url: string; email: string; onDone: (added: boolean) => void }) {
  const [withPassword, setWithPassword] = useState(false);
  const [password, setPassword] = useState("");
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const confirm = useConfirmChange();

  async function add() {
    if (!(await confirm({
      title: "Add this portal login?",
      consequence: `${email.trim()} can sign in to the portal${withPassword ? " with the password set here" : " by emailed link"}.`,
      confirmLabel: "Add login",
      tone: "caution",
    }))) {
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim(), password: withPassword ? password : null }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? "Not added.");
        return;
      }
      onDone(true);
    } catch {
      setError("Could not reach the panel.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-3 border-t border-border pt-3">
      <p className="text-sm">Signs in as <span className="font-mono">{email}</span>, the account&rsquo;s email.</p>
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={withPassword} onChange={(e) => setWithPassword(e.target.checked)}
          className="h-4 w-4 rounded border-input accent-primary" />
        Set a password now
      </label>
      {withPassword && (
        <PasswordFields
          value={password}
          email={email}
          labels={{ password: "Portal password", confirm: "Confirm portal password" }}
          onChange={(pw, ok) => {
            setPassword(pw);
            setReady(ok);
          }}
        />
      )}
      {!withPassword && (
        <p className="text-xs text-muted-foreground">Without one, they sign in by emailed link and can set a password from the portal.</p>
      )}
      {error && <p className="text-xs text-destructive">{error}</p>}
      <div className="flex gap-1.5">
        <Button size="sm" disabled={busy || !email.trim() || (withPassword && !ready)} onClick={() => void add()}>
          {busy ? "Adding…" : "Add login"}
        </Button>
        <Button size="sm" variant="ghost" disabled={busy} onClick={() => onDone(false)}>Cancel</Button>
      </div>
    </div>
  );
}
