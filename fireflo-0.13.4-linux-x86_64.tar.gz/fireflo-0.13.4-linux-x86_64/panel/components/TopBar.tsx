"use client";
import { useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu as MenuIcon, Search } from "lucide-react";
import { FireFloMark } from "./FireFloMark";
import type { PortalMark } from "@/lib/brand";
import { ThemeToggle } from "./ThemeToggle";
import { HealthPill } from "./HealthPill";
import { JumpBox } from "./JumpBox";
import { cn } from "@/lib/utils";

export interface QuickLink {
  href: string;
  label: string;
}

/** The four pages an operator opens most, also in the sidebar; here they are one click from anywhere. */
export const OPERATOR_QUICK_LINKS: QuickLink[] = [
  { href: "/cp/cdrs", label: "Messages" },
  { href: "/cp/vendors", label: "Vendors" },
  { href: "/cp/servers", label: "Servers" },
  { href: "/cp/accounts", label: "Accounts" },
];

/**
 * The bar above every page.
 *
 * <p>It replaces two headers -- a phone one with the brand and a desktop one that was empty but
 * for the health icon -- with one that earns its height: the pages that matter as tabs, a box
 * that jumps anywhere, the gateway's state as a word, and the person as a menu. Below `lg` the
 * tabs go (the sidebar has them); below `md` the jump box becomes an icon and the brand appears,
 * because the sidebar is a drawer and nothing else names the product.
 *
 * <p>The portal uses the same bar with its own links and no gateway health; `trailing` is where
 * its balance goes.
 */
export function TopBar({
  onMenuClick,
  quick,
  brand = "FireFlo",
  mark,
  jump = false,
  health = false,
  trailing,
  user,
}: {
  onMenuClick: () => void;
  quick: QuickLink[];
  brand?: string;
  /** The portal's mark; absent draws FireFlo's. */
  mark?: PortalMark;
  /** Show the ⌘K jump box (operator only: it searches the operator API). */
  jump?: boolean;
  /** Show the gateway health pill (operator only). */
  health?: boolean;
  trailing?: ReactNode;
  user: ReactNode;
}) {
  const pathname = usePathname();
  const [jumpOpen, setJumpOpen] = useState(false);

  useEffect(() => {
    if (!jump) {
      return;
    }
    function onKeyDown(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setJumpOpen(true);
      }
    }
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [jump]);

  return (
    <header className="flex h-14 shrink-0 items-center gap-2 border-b border-border bg-card px-3 md:gap-3 md:px-6">
      <button
        type="button"
        onClick={onMenuClick}
        className="-ml-1 rounded-md p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground md:hidden"
        aria-label="Open menu"
      >
        <MenuIcon className="h-5 w-5" />
      </button>
      <span className="flex items-center gap-2 md:hidden">
        <FireFloMark className="h-5 w-5" mark={mark} />
        <span className="text-sm font-semibold tracking-tight">{brand}</span>
      </span>

      <nav aria-label="Quick navigation" className="hidden items-center gap-0.5 lg:flex">
        {quick.map((q) => {
          const active = pathname.startsWith(q.href);
          return (
            <Link
              key={q.href}
              href={q.href}
              aria-current={active ? "page" : undefined}
              className={cn(
                "rounded-md px-3 py-1.5 text-sm transition-colors",
                active ? "bg-muted font-semibold text-foreground" : "font-medium text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              {q.label}
            </Link>
          );
        })}
      </nav>

      {jump && (
        <>
          <button
            type="button"
            onClick={() => setJumpOpen(true)}
            className="hidden h-9 w-full max-w-[280px] items-center gap-2 rounded-md border border-border bg-background px-2.5 text-sm text-muted-foreground transition-colors hover:bg-muted md:flex lg:ml-4"
          >
            <Search className="h-3.5 w-3.5 shrink-0" aria-hidden />
            <span className="truncate">Jump to account, vendor, message id</span>
            <kbd className="ml-auto rounded border border-border px-1 font-mono text-xs">⌘K</kbd>
          </button>
          <button
            type="button"
            onClick={() => setJumpOpen(true)}
            className="ml-auto rounded-md p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground md:hidden"
            aria-label="Jump to"
          >
            <Search className="h-5 w-5" />
          </button>
          <JumpBox open={jumpOpen} onClose={() => setJumpOpen(false)} />
        </>
      )}

      {/* always against the right edge. The jump box sits beside the tabs and no longer carries the
          auto margin: at desktop width `lg:mx-4` replaced it, which left this cluster floating with a
          gap after it. On a phone the search icon is the one pushed right, and this follows it */}
      <div className={cn("flex items-center gap-1.5", jump ? "md:ml-auto" : "ml-auto")}>
        {health && <HealthPill />}
        {trailing}
        <ThemeToggle />
        {user}
      </div>
    </header>
  );
}
