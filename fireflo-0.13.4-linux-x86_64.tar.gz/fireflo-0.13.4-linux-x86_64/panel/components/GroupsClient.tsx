"use client";
import { useCallback, useEffect, useState } from "react";
import { ArrowDown, ArrowUp, Loader2, Plus, Trash2, TriangleAlert, Users } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { useConfirmChange, useConfirmDelete } from "./ConfirmProvider";
import { buttonClasses } from "@/components/ui/button";
import { useWorkers } from "@/components/useWorkers";
import {
  GROUP_POLICIES,
  GROUP_POLICY_MEANING,
  memberShares,
  policyReadsWeight,
  routeGroupWarnings,
  validateRouteGroup,
  type GroupPolicy,
  type RouteGroup,
  type RouteGroupMember,
} from "@/lib/group-types";

/**
 * Vendor groups.
 *
 * <p>A group answers the two questions a single-target rule cannot: what happens when this vendor
 * is down, and how do I split traffic between two of them. It sits under the routing tables because
 * that is the only thing that sends to it.
 *
 * <p>The share column is the point of the screen. Weights are a configuration input; the share is
 * what the traffic actually does, and the two differ in exactly the cases worth catching — a weight
 * set on a policy that ignores it, and a suspended member whose share has gone to the others.
 */
/** A member as the confirmation lists it: name, weight, and off when it is. */
const memberText = (m: RouteGroupMember) => `${m.workerName}×${m.weight}${m.enabled ? "" : " (off)"}`;

export function GroupsClient() {
  const { workers: clients } = useWorkers("smppclient");
  const [groups, setGroups] = useState<RouteGroup[]>([]);
  const [editing, setEditing] = useState<RouteGroup | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const confirm = useConfirmChange();

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/control/groups", { cache: "no-store" });
      const body = await res.json();
      if (!res.ok) {
        setError(body?.error ?? "Could not load groups.");
      } else {
        setError(null);
        setGroups(body.data.groups as RouteGroup[]);
      }
    } catch {
      setError("Could not reach the panel's API.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function save(group: RouteGroup) {
    const invalid = validateRouteGroup(group, [], clients.map((w) => w.name));
    if (invalid) {
      setError(invalid);
      return;
    }
    const before = groups.find((g) => g.name === group.name);
    const ok = await confirm({
      title: before ? `Save group ${group.name}` : `Create group ${group.name}`,
      consequence: `${group.policy} across ${group.members.length} vendor(s)`
        + `${group.enabled ? "" : ", switched off"}. Every rule that sends to ${group.name} picks its vendor `
        + "this way from the gateway's next poll.",
      confirmLabel: before ? "Save group" : "Create group",
      tone: before && before.enabled && !group.enabled ? "caution" : "primary",
      changes: before ? [
        ...(before.policy !== group.policy ? [{ label: "Policy", from: before.policy, to: group.policy }] : []),
        ...(before.enabled !== group.enabled ? [{ label: "Enabled", from: String(before.enabled), to: String(group.enabled) }] : []),
        ...(JSON.stringify(before.members) !== JSON.stringify(group.members)
          ? [{ label: "Members", from: before.members.map(memberText).join(", ") || "(none)",
              to: group.members.map(memberText).join(", ") || "(none)" }] : []),
      ] : undefined,
    });
    if (!ok) return;
    const res = await fetch("/api/control/groups", {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(group),
    });
    const body = await res.json();
    if (!res.ok) {
      setError(body?.error ?? "Could not save.");
      return;
    }
    setEditing(null);
    setError(null);
    await load();
  }

  async function remove(group: RouteGroup) {
    const res = await fetch(`/api/control/groups?name=${encodeURIComponent(group.name)}`, {
      method: "DELETE",
    });
    const body = await res.json();
    if (!res.ok) {
      setError(body?.error ?? "Could not delete.");
      return;
    }
    //a group a rule still sends to is refused by the server (gateway V1.58.0), so a success here
    //leaves nothing pointing at nothing
    setError(null);
    await load();
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-4 w-4 text-muted-foreground" />
          Vendor groups
          {loading && <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />}
        </CardTitle>
        <CardDescription>
          A rule can send to a group instead of one vendor. The group skips any member that is
          suspended or not accepting — which is the failover a single-target rule cannot do. Every
          message still goes to exactly one member.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {error && (
          <p className="flex items-start gap-2 text-sm text-destructive">
            <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" /> {error}
          </p>
        )}

        {!groups.length && !editing && !loading && (
          <p className="text-sm text-muted-foreground">
            No groups yet. Rules send to one vendor each, so a vendor going down means those
            messages are retried and then dropped.
          </p>
        )}

        {groups.map((group) => (
          <GroupRow
            key={group.name}
            group={group}
            editing={editing?.name === group.name}
            vendors={clients.map((w) => w.name)}
            onEdit={() => setEditing(group)}
            onCancel={() => setEditing(null)}
            onSave={save}
            onDelete={() => remove(group)}
          />
        ))}

        {editing && !groups.some((g) => g.name === editing.name) && (
          <GroupRow
            group={editing}
            editing
            vendors={clients.map((w) => w.name)}
            onEdit={() => undefined}
            onCancel={() => setEditing(null)}
            onSave={save}
            onDelete={() => setEditing(null)}
          />
        )}

        {!editing && (
          <button
            onClick={() => setEditing({
              name: "", policy: "ROUND_ROBIN", label: null, enabled: true, members: [],
            })}
            className={buttonClasses({ variant: "outline", size: "sm" })}
          >
            <Plus className="mr-1.5 h-3.5 w-3.5" /> Add a group
          </button>
        )}
      </CardContent>
    </Card>
  );
}

function GroupRow({ group, editing, vendors, onEdit, onCancel, onSave, onDelete }: {
  group: RouteGroup;
  editing: boolean;
  vendors: string[];
  onEdit: () => void;
  onCancel: () => void;
  onSave: (g: RouteGroup) => void;
  onDelete: () => void;
}) {
  const [draft, setDraft] = useState<RouteGroup>(group);
  useEffect(() => setDraft(group), [group]);
  const confirmDelete = useConfirmDelete();

  const shown = editing ? draft : group;
  const shares = memberShares(shown);
  const warnings = routeGroupWarnings(shown);

  function moveMember(from: number, to: number) {
    if (to < 0 || to >= draft.members.length) {
      return;
    }
    const members = [...draft.members];
    const [moved] = members.splice(from, 1);
    members.splice(to, 0, moved);
    setDraft({ ...draft, members });
  }

  return (
    <div className="rounded-lg border border-border p-3">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        {editing ? (
          <input
            value={draft.name}
            onChange={(e) => setDraft({ ...draft, name: e.target.value })}
            placeholder="Group name, e.g. asia"
            aria-label="Group name"
            className="h-11 w-full rounded-md border border-border bg-background px-2 font-mono text-sm sm:w-auto md:h-9"
          />
        ) : (
          <span className="font-mono text-sm font-medium">{shown.name}</span>
        )}
        <div className="flex flex-wrap items-center gap-2">
          {editing ? (
            <select
              value={draft.policy}
              onChange={(e) => setDraft({ ...draft, policy: e.target.value as GroupPolicy })}
              aria-label="Policy"
              className="h-11 rounded-md border border-border bg-background px-2 text-sm md:h-9"
            >
              {GROUP_POLICIES.map((p) => <option key={p} value={p}>{p.toLowerCase().replace("_", " ")}</option>)}
            </select>
          ) : (
            <Badge variant="outline" className="text-xs">
              {shown.policy.toLowerCase().replace("_", " ")}
            </Badge>
          )}
          {!shown.enabled && <Badge variant="outline" className="text-xs">off</Badge>}
        </div>
      </div>

      <p className="mt-1 text-sm text-muted-foreground">{GROUP_POLICY_MEANING[shown.policy]}</p>

      <TableInCard className="mt-3">
        <THead>
          <TR>
            <TH>Vendor</TH>
            {policyReadsWeight(shown.policy) && <TH>Weight</TH>}
            {/* what the traffic does, beside what was configured. They differ exactly where it
                matters: an ignored weight, and a suspended member whose share went elsewhere */}
            <TH>Share</TH>
            <TH>On</TH>
            {editing && <TH />}
          </TR>
        </THead>
        <TBody>
          {shown.members.map((member, i) => (
            <TR key={member.workerName || i}>
              <TD className="font-mono">
                {editing ? (
                  <select
                    value={member.workerName}
                    onChange={(e) => {
                      const members = [...draft.members];
                      members[i] = { ...member, workerName: e.target.value };
                      setDraft({ ...draft, members });
                    }}
                    aria-label={`Member ${i + 1}`}
                    className="h-11 rounded-md border border-border bg-background px-2 text-sm md:h-9"
                  >
                    <option value="">Choose a vendor…</option>
                    {vendors.map((v) => <option key={v} value={v}>{v}</option>)}
                  </select>
                ) : member.workerName}
              </TD>
              {policyReadsWeight(shown.policy) && (
                <TD>
                  {editing ? (
                    <input
                      type="number"
                      min={1}
                      value={member.weight}
                      onChange={(e) => {
                        const members = [...draft.members];
                        members[i] = { ...member, weight: Number(e.target.value) };
                        setDraft({ ...draft, members });
                      }}
                      aria-label={`Weight for ${member.workerName || i + 1}`}
                      className="h-11 w-full rounded-md border border-border bg-background px-2 text-sm sm:w-20 md:h-9"
                    />
                  ) : <span className="font-mono text-sm">{member.weight}</span>}
                </TD>
              )}
              <TD className="tabular-nums">
                {member.enabled
                  ? `${(shares.get(member.workerName) ?? 0).toFixed(0)}%`
                  : <span className="text-muted-foreground">—</span>}
              </TD>
              <TD>
                <input
                  type="checkbox"
                  checked={member.enabled}
                  disabled={!editing}
                  onChange={(e) => {
                    const members = [...draft.members];
                    members[i] = { ...member, enabled: e.target.checked };
                    setDraft({ ...draft, members });
                  }}
                  aria-label={`${member.workerName} enabled`}
                />
              </TD>
              {editing && (
                <TD align="right">
                  {/* order is the failover preference, so it has to be editable rather than
                      whatever order the rows happened to be added in */}
                  <button onClick={() => moveMember(i, i - 1)} aria-label="Move up"
                    className="px-1 text-muted-foreground hover:text-foreground">
                    <ArrowUp className="h-3.5 w-3.5" />
                  </button>
                  <button onClick={() => moveMember(i, i + 1)} aria-label="Move down"
                    className="px-1 text-muted-foreground hover:text-foreground">
                    <ArrowDown className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => setDraft({
                      ...draft, members: draft.members.filter((_, j) => j !== i),
                    })}
                    aria-label={`Remove ${member.workerName}`}
                    className="px-1 text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </TD>
              )}
            </TR>
          ))}
        </TBody>
      </TableInCard>

      {warnings.map((w) => (
        <p key={w} className="mt-2 flex items-start gap-2 text-sm text-warning">
          <TriangleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {w}
        </p>
      ))}

      <div className="mt-3 flex flex-wrap items-center gap-2">
        {editing ? (
          <>
            <button
              onClick={() => setDraft({
                ...draft, members: [...draft.members, { workerName: "", weight: 1, enabled: true }],
              })}
              className={buttonClasses({ variant: "outline", size: "sm" })}
            >
              <Plus className="mr-1.5 h-3.5 w-3.5" /> Add a vendor
            </button>
            <label className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <input
                type="checkbox"
                checked={draft.enabled}
                onChange={(e) => setDraft({ ...draft, enabled: e.target.checked })}
              />
              Group is on
            </label>
            <span className="grow" />
            <button onClick={onCancel} className={buttonClasses({ variant: "ghost", size: "sm" })}>
              Cancel
            </button>
            <button onClick={() => onSave(draft)} className={buttonClasses({ size: "sm" })}>
              Save
            </button>
          </>
        ) : (
          <>
            <button onClick={onEdit} className={buttonClasses({ variant: "outline", size: "sm" })}>
              Edit
            </button>
            <button
              onClick={async () => {
                const ok = await confirmDelete({
                  title: `Delete group ${group.name}`,
                  consequence: `${group.name} and its ${group.members.length} member(s) go. Refused while any routing `
                    + "rule still sends to this group; point those rules elsewhere first.",
                  confirmLabel: "Delete this group",
                });
                if (ok) onDelete();
              }}
              className={buttonClasses({ variant: "ghost", size: "sm", className: "text-destructive" })}
            >
              Delete
            </button>
          </>
        )}
      </div>
    </div>
  );
}
