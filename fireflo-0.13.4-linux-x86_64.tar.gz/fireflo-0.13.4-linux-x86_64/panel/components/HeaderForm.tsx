"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { SettingsRow, SettingsRows } from "@/components/ui/settings-row";
import { TlvPairsEditor } from "@/components/TlvPairsEditor";
import { RegistrationScopeNotes } from "@/components/RegistrationScopeNotes";
import { formatTlvCsv, parseTlvCsv, tlvCsvProblem, type TlvPair } from "@/lib/tlv-string";
import type { TlvDefinition } from "@/lib/tlv-catalogue";
import {
  loginOptions, productOptions, validateHeader,
  type ApprovedHeader, type HeaderInput,
} from "@/lib/whitelist-types";

/**
 * The editor for one approved sender ID.
 *
 * <p>Two rows and then the stamps: <em>Sender ID · Approved</em>, <em>Product · Login</em>, TLVs
 * across the full width. The two scoping controls sit together because they are one decision —
 * which traffic this covers — and the stamps get the width because a 19-digit entity id in a
 * half-column is unreadable.
 */
export function HeaderForm({
  accountId,
  editing,
  products,
  logins,
  definitions,
  suggested,
  busy,
  onSave,
  onCancel,
}: {
  accountId: string;
  editing: ApprovedHeader | null;
  /** The catalogue plus orphans, from the one `useProducts` call the section makes. */
  products: string[];
  /** This account's enabled logins, so an approval can be scoped to one of them. */
  logins: string[];
  /** Operator-defined TLV names, from the section's one `useTlvDefinitions` call. */
  definitions: readonly TlvDefinition[];
  suggested: Record<number, boolean>;
  busy: boolean;
  onSave: (input: HeaderInput) => Promise<string | null>;
  onCancel: () => void;
}) {
  const [header, setHeader] = useState(editing?.header ?? "");
  const [pairs, setPairs] = useState<TlvPair[]>(() => parseTlvCsv(editing?.tlvs));
  const [product, setProduct] = useState(editing?.product ?? "");
  const [systemId, setSystemId] = useState(editing?.systemId ?? "");
  //a new row starts approved -- an operator adding one has decided. An existing row starts wherever
  //it is, so opening a customer's request shows it unticked and ticking it is the approval
  const [approved, setApproved] = useState(
    editing ? editing.status === "APPROVED" && editing.enabled : true
  );
  const [error, setError] = useState("");

  const tlvs = formatTlvCsv(pairs);
  const invalid = header.trim() ? validateHeader(header) : null;
  const tlvProblem = tlvCsvProblem(tlvs);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const refusal = validateHeader(header) ?? tlvCsvProblem(tlvs);
    if (refusal) {
      setError(refusal);
      return;
    }
    const failure = await onSave({
      id: editing?.id ?? null,
      accountId,
      product: product.trim(),
      systemId: systemId.trim() || null,
      header: header.trim(),
      tlvs,
      enabled: approved,
      approved,
    });
    setError(failure ?? "");
  }

  return (
    <form onSubmit={submit} className="space-y-3">
      <SettingsRows>
        <SettingsRow label="Sender ID" htmlFor="hdr-value" help={<>Case-insensitive, so this also allows <code className="font-mono">acmein</code>.</>}>
          <Input id="hdr-value" value={header} onChange={(e) => setHeader(e.target.value)}
            className="font-mono" placeholder="ACMEIN" />
        </SettingsRow>
        {/*this writes `status` and records the reviewer, not just `enabled`. It was called
           Approved once while writing only `enabled`, which meant ticking it on a request left
           the row PENDING and inert -- the label is back, so the write had to be made true*/}
        <SettingsRow label="Approved" labelId="hdr-approved" help="Switched off, it is withdrawn; it stays approved.">
          <div className="flex items-center gap-3 md:justify-end">
            <span className="text-sm text-muted-foreground">{approved ? "Approved and in service" : "Not approved"}</span>
            <Switch checked={approved} onChange={setApproved} aria-labelledby="hdr-approved" />
          </div>
        </SettingsRow>
        <SettingsRow label="Product" htmlFor="hdr-product" help="Narrows it to one product’s traffic.">
          <Select id="hdr-product" value={product} onChange={(e) => setProduct(e.target.value)}>
            <option value="">Every product</option>
            {productOptions(products, product).map((p) => (
              <option key={p} value={p}>{p}</option>
            ))}
          </Select>
        </SettingsRow>
        <SettingsRow label="Login" htmlFor="hdr-login" help="Which of this account’s logins may send from it.">
          <Select id="hdr-login" value={systemId} onChange={(e) => setSystemId(e.target.value)}>
            <option value="">Every login on the account</option>
            {loginOptions(logins, systemId).map((l) => (
              <option key={l} value={l}>{l}</option>
            ))}
          </Select>
        </SettingsRow>
        <SettingsRow
          label={<>TLVs to stamp <span className="font-normal text-muted-foreground">name_tag = value</span></>}
          help={<>Written onto every message from this sender ID, <strong>replacing</strong> what the customer
            sent for the same tag — so the value here is the approval. Needs{" "}
            <code className="font-mono">whitelist.tlvs.mode</code> set on the server the traffic arrives
            through.</>}
          wide
        >
          <TlvPairsEditor
            pairs={pairs}
            onChange={setPairs}
            definitions={definitions}
            suggested={suggested}
            addLabel="Add a stamp"
            valuePlaceholder="1101234567890123456"
            disabled={busy}
          />
        </SettingsRow>
      </SettingsRows>

      <RegistrationScopeNotes
        noun="sender ID"
        name={header.trim() || "this sender ID"}
        accountId={accountId}
        systemId={systemId.trim()}
        product={product.trim()}
        logins={logins}
      />

      {(invalid || tlvProblem || error) && (
        <p className="text-sm text-destructive">{invalid ?? tlvProblem ?? error}</p>
      )}

      <div className="flex gap-2">
        <Button type="submit" size="sm"
          disabled={busy || Boolean(invalid) || Boolean(tlvProblem) || !header.trim()}>
          {busy ? "Saving…" : "Save"}
        </Button>
        <Button type="button" size="sm" variant="ghost" onClick={onCancel}>Cancel</Button>
      </div>
    </form>
  );
}
