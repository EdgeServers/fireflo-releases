"use client";
import * as React from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * A modal, with the parts that make one usable rather than just visible.
 *
 * <p>The visible half — a backdrop and a centred panel — is the easy half and is not what this file
 * is for. The rest is what separates a dialog from a `<div>` on top of the page:
 *
 * <ul>
 *   <li><strong>Focus moves in and comes back.</strong> Opening focuses the panel; closing returns
 *       focus to whatever opened it, so the keyboard does not land back at the top of the document.</li>
 *   <li><strong>Tab is trapped.</strong> Without this, tabbing past the last field walks into the
 *       page behind — which is still there, still focusable, and now unreachable by mouse.</li>
 *   <li><strong>Escape closes</strong>, because every other dialog a person has used does.</li>
 *   <li><strong>The page behind does not scroll.</strong> `DashboardShell` already does this for the
 *       mobile drawer; the same reasoning applies.</li>
 * </ul>
 *
 * <p>Rendered through a portal rather than in place. Fixed positioning is resolved against the
 * nearest ancestor with a transform, filter or backdrop-filter, and this panel has several — so a
 * dialog opened inside one would be centred on that element rather than the viewport, which is the
 * kind of bug that appears later and looks inexplicable.
 */
/** Open dialogs, oldest first; the last one is on top and is the only one that handles keys. */
const OPEN_DIALOGS: symbol[] = [];

export function Dialog({
  open,
  onClose,
  title,
  description,
  className,
  role = "dialog",
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: React.ReactNode;
  className?: string;
  /**
   * `alertdialog` for a confirmation that interrupts to ask one question, `dialog` for a form.
   *
   * <p>The distinction is what lets a test, or a screen reader, tell the confirm modal from the
   * form it opened over: both are modal, both have a Cancel button, and "the last dialog on the
   * page" was the form whenever the form refused before asking.
   */
  role?: "dialog" | "alertdialog";
  children: React.ReactNode;
}) {
  const panel = React.useRef<HTMLDivElement>(null);
  const titleId = React.useId();
  const [mounted, setMounted] = React.useState(false);

  /**
   * The latest `onClose`, without it being a dependency of the effect below.
   *
   * <p>Callers pass an inline arrow, so `onClose` is a new function every render. As a dependency it
   * would tear down and rebuild the effect each time — re-locking scroll, and calling the cleanup's
   * `restoreTo.focus()`, which would yank focus back to the trigger button mid-typing.
   *
   * <p>Assigned in an effect rather than during render: a ref is mutable state, and writing to one
   * while rendering is the rule React 19 enforces.
   */
  const close = React.useRef(onClose);
  React.useEffect(() => {
    close.current = onClose;
  });

  React.useEffect(() => setMounted(true), []);

  React.useEffect(() => {
    if (!open) {
      return;
    }
    const me = Symbol("dialog");
    OPEN_DIALOGS.push(me);
    const restoreTo = document.activeElement as HTMLElement | null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    function onKeyDown(event: KeyboardEvent) {
      //only the topmost dialog answers the keyboard. A confirmation raised from inside another
      //dialog (removing a rule from a rule editor) used to close both on one Escape, and the tab
      //trap of the one underneath fought the one on top
      if (OPEN_DIALOGS[OPEN_DIALOGS.length - 1] !== me) {
        return;
      }
      if (event.key === "Escape") {
        close.current();
        return;
      }
      if (event.key !== "Tab" || !panel.current) {
        return;
      }
      const focusable = panel.current.querySelectorAll<HTMLElement>(
        'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), '
          + 'textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
      );
      if (!focusable.length) {
        return;
      }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }

    document.addEventListener("keydown", onKeyDown);
    return () => {
      const at = OPEN_DIALOGS.lastIndexOf(me);
      if (at >= 0) {
        OPEN_DIALOGS.splice(at, 1);
      }
      document.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = previousOverflow;
      restoreTo?.focus?.();
    };
  }, [open]);

  if (!mounted || !open) {
    return null;
  }

  return createPortal(
    <div className="fixed inset-0 z-[60] flex items-start justify-center overflow-y-auto p-4 sm:items-center sm:p-6">
      <div
        className="fixed inset-0 bg-black/50 backdrop-blur-sm"
        onClick={() => close.current()}
        aria-hidden="true"
      />
      <div
        ref={panel}
        role={role}
        aria-modal="true"
        aria-labelledby={titleId}
        //-1 so the panel itself can hold focus on open without becoming a tab stop of its own
        tabIndex={-1}
        className={cn(
          "relative z-10 my-auto w-full max-w-lg rounded-xl border border-border bg-card shadow-lg",
          className
        )}
      >
        <div className="flex items-start justify-between gap-4 border-b border-border px-5 py-4">
          <div className="min-w-0">
            <h2 id={titleId} className="text-title">{title}</h2>
            {description && (
              <p className="mt-1 text-xs text-muted-foreground">{description}</p>
            )}
          </div>
          <button
            type="button"
            onClick={() => close.current()}
            aria-label="Close"
            className="shrink-0 rounded-md p-1 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="px-5 pb-5 pt-4">{children}</div>
      </div>
    </div>,
    document.body
  );
}
