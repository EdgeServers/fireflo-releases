import * as React from "react";
import { cn } from "@/lib/utils";

type BadgeVariant = "default" | "success" | "warning" | "destructive" | "info" | "outline";

interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: BadgeVariant;
}

//a pill is a soft ground with the status colour as text and no border, the way the sample draws
//Healthy / Degraded / Primary. `outline` is the one neutral tag and keeps its hairline
const variantClasses: Record<BadgeVariant, string> = {
  default: "bg-primary-soft text-foreground",
  success: "bg-success-soft text-success",
  warning: "bg-warning-soft text-warning",
  destructive: "bg-destructive-soft text-destructive",
  info: "bg-info-soft text-info",
  outline: "border border-border text-muted-foreground",
};

export function Badge({ className, variant = "default", ...props }: BadgeProps) {
  return (
    <div
      className={cn(
        "inline-flex items-center rounded-full px-2 py-0.5 text-2xs font-semibold leading-4 transition-colors",
        variantClasses[variant],
        className
      )}
      {...props}
    />
  );
}
