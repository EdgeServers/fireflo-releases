import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * A multi-line text field, drawn exactly like {@link Input}: body size, the same border, padding,
 * ground, focus ring and disabled look.
 *
 * <p>Nine textareas used to style themselves, at three sizes (12, 14 and 16px), on two grounds and
 * with two paddings -- so a form's notes field read larger than the inputs above it, and its text
 * started four pixels left of theirs. Add `font-mono` for code or keys; it keeps the body size.
 */
export const Textarea = React.forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement>>(
  ({ className, ...props }, ref) => (
    <textarea
      ref={ref}
      className={cn(
        "flex min-h-20 w-full rounded-md border border-input bg-card px-3 py-2 text-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 read-only:bg-muted/40",
        className
      )}
      {...props}
    />
  )
);
Textarea.displayName = "Textarea";
