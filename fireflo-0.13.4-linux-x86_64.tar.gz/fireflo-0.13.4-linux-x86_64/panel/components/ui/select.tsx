import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * A plain `<select>`, styled to match {@link Input}.
 *
 * <p>Promoted here from `CdrFilterBar`, where it lived as a module-private component with a comment
 * noting there was no select primitive. The pricing form needs the same control in three places, so
 * the alternative was a second copy of identical markup. Moving it removes a duplicate rather than
 * introducing an abstraction — same classes, same behaviour, no new decisions.
 *
 * <p>No `"use client"`: it has no hooks, exactly like `ui/input.tsx` and `ui/card.tsx`. Only
 * `ui/button.tsx` needs it.
 */
export const Select = React.forwardRef<HTMLSelectElement, React.SelectHTMLAttributes<HTMLSelectElement>>(
  ({ className, ...props }, ref) => (
    <select
      ref={ref}
      className={cn(
        "flex h-11 w-full rounded-md border border-input bg-card px-3 py-1 text-sm transition-colors md:h-9 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
        className
      )}
      {...props}
    />
  )
);
Select.displayName = "Select";
