import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * The box that stands where a list would be: "No vendors yet", "Loading…", "No listener called x".
 *
 * <p>One component because the audit found fourteen hand-rolled copies at four different paddings
 * (`p-12`, `p-10`, `p-8`, `p-6`) and two text sizes. Body size, muted, centred; the padding steps
 * down on a phone so a 358px-wide card does not spend 96px of it on gutter.
 */
export function EmptyState({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("rounded-xl border border-border p-8 text-center text-sm text-muted-foreground sm:p-10", className)}
      {...props}
    />
  );
}
