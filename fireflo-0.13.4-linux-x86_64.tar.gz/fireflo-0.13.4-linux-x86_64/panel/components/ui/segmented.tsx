"use client";
import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * A choice of two or three, all visible at once.
 *
 * <p>A radio group drawn as buttons: arrow keys move between options, as a native radio group's do,
 * and each option carries its long description as a title so the short label can stay short. More
 * than three options, or long labels, belong in a select.
 */
export function Segmented<T extends string>({
  options,
  value,
  onChange,
  disabled,
  label,
  className,
  fill = false,
}: {
  options: readonly { value: T; label: string; title?: string }[];
  value: T;
  onChange: (next: T) => void;
  disabled?: boolean;
  /** The group's accessible name. */
  label: string;
  className?: string;
  /** Stretch the options to the container's width, for a phone. */
  fill?: boolean;
}) {
  const refs = React.useRef<(HTMLButtonElement | null)[]>([]);

  function move(from: number, step: number) {
    const next = (from + step + options.length) % options.length;
    onChange(options[next].value);
    refs.current[next]?.focus();
  }

  return (
    <div
      role="radiogroup"
      aria-label={label}
      className={cn(
        "gap-0.5 rounded-lg bg-muted p-[3px]",
        fill ? "grid" : "inline-flex",
        className
      )}
      style={fill ? { gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))` } : undefined}
    >
      {options.map((o, i) => {
        const selected = o.value === value;
        return (
          <button
            key={o.value}
            ref={(el) => {
              refs.current[i] = el;
            }}
            type="button"
            role="radio"
            aria-checked={selected}
            title={o.title}
            //one tab stop for the group, on the selected option, as a native radio group has
            tabIndex={selected ? 0 : -1}
            disabled={disabled}
            onClick={() => onChange(o.value)}
            onKeyDown={(e) => {
              if (e.key === "ArrowRight" || e.key === "ArrowDown") {
                e.preventDefault();
                move(i, 1);
              } else if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
                e.preventDefault();
                move(i, -1);
              }
            }}
            className={cn(
              "min-h-9 rounded-md px-3 text-sm transition-colors",
              //a filled group shares its width, so a long label wraps rather than overflowing
              fill ? "whitespace-normal py-1.5 leading-5" : "whitespace-nowrap",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
              "disabled:cursor-not-allowed disabled:opacity-50",
              selected
                ? "bg-card font-semibold text-foreground ring-1 ring-border"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}
