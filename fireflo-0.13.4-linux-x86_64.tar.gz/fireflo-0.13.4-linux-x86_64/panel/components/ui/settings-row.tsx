import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

/**
 * One setting: what it is on the left, the control on the right.
 *
 * <p>The form grammar the redesign settles on. Label and help text take the first column, the
 * control the second, and the hairline between rows comes from the parent (`SettingsSection`'s
 * `divide-y`), so a row carries no border of its own. Below `md` the two columns stack, label
 * first, which is the order a phone reader expects.
 *
 * <p>Replaces the stacked `Field` grids: a label above a control reads fine for three fields and
 * badly for thirty, because the eye has to find the labels again on every row. A fixed left column
 * lines them up.
 *
 * <p>`tone` tints the whole row: an unsaved value, one the gateway has not picked up yet, or one
 * it would refuse. The tint is the only thing that says so at a glance, which is why it is on the
 * row and not on the chip.
 */
export function SettingsRow({
  label,
  help,
  keyName,
  chips,
  tone,
  htmlFor,
  labelId,
  wide = false,
  stacked = false,
  id,
  className,
  children,
}: {
  label: ReactNode;
  /** One sentence under the label. A row with none keeps its height from the control. */
  help?: ReactNode;
  /** The stored key, in mono under the help, for the pages whose rows map to a config key. */
  keyName?: string;
  /** Badges beside the label: inherited, in force, unsaved. Already-rendered nodes. */
  chips?: ReactNode;
  tone?: "unsaved" | "pending" | "invalid";
  /** Forwarded to the label so clicking it focuses the control. */
  htmlFor?: string;
  /** An id for the label text, for a control that is labelled by it (`aria-labelledby`). */
  labelId?: string;
  /** Let the control take the whole column: a condition editor, a textarea, a list. */
  wide?: boolean;
  /**
   * The control under the label, across the whole row, at every width. For the one control a
   * half-row cramps: free text that is read as a paragraph (an account's notes), where a column
   * 1.4 parts wide shows four words a line and the rest wraps. Implies `wide`.
   */
  stacked?: boolean;
  id?: string;
  className?: string;
  children: ReactNode;
}) {
  return (
    <div
      id={id}
      className={cn(
        "grid gap-2 px-4 py-4 md:items-start md:gap-6 md:px-5",
        stacked ? "md:grid-cols-1 md:gap-2" : "md:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)]",
        tone === "unsaved" && "bg-info-soft/40",
        tone === "pending" && "bg-warning-soft/50",
        tone === "invalid" && "bg-destructive-soft/40",
        className
      )}
    >
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-2">
          {htmlFor ? (
            <label htmlFor={htmlFor} id={labelId} className="text-sm font-medium">{label}</label>
          ) : (
            <span id={labelId} className="text-sm font-medium">{label}</span>
          )}
          {chips}
        </div>
        {help && <p className="mt-1 text-xs text-muted-foreground">{help}</p>}
        {keyName && <p className="mt-1 font-mono text-xs text-placeholder">{keyName}</p>}
      </div>
      {/* the control hugs the right edge on a wide screen and is capped so a lone text input does
          not stretch to half the page; a child that needs the full width passes its own max */}
      {/* a column, not a row: a control with something under it -- the rule editor's switch and its
          conditions, a select and its badge line -- passes them as siblings, and in a row they were
          squeezed side by side and stretched to the tallest one's height */}
      {/* a bare switch keeps its own size: stretched to the column it reads as a long pill */}
      <div className={cn("min-w-0 md:flex md:flex-col md:items-end md:[&>*]:w-full md:[&>[role=switch]]:w-11", !wide && !stacked && "md:[&>*]:max-w-sm")}>{children}</div>
    </div>
  );
}

/**
 * The box rows sit in when they are not inside a `SettingsSection`: a dialog, a form card.
 *
 * <p>Hairline between rows, hairline around, no shadow. A `fieldset` when the whole group can be
 * disabled at once, which is what a locked rule needs.
 */
export function SettingsRows({
  as: Tag = "div",
  disabled,
  className,
  children,
}: {
  as?: "div" | "fieldset";
  disabled?: boolean;
  className?: string;
  children: ReactNode;
}) {
  return (
    <Tag disabled={Tag === "fieldset" ? disabled : undefined} className={cn("min-w-0 divide-y divide-border rounded-lg border border-border", className)}>
      {children}
    </Tag>
  );
}
