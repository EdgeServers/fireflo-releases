import type { ReactNode } from "react";
import { Badge } from "@/components/ui/badge";
import { Sparkline } from "@/components/Sparkline";
import { cn } from "@/lib/utils";

/**
 * A number worth a glance: label, value, and what to make of it.
 *
 * <p>Replaces `StatCard`. The lucide icon in the corner is gone -- it named the metric a second
 * time, in a vocabulary nobody learned -- and its place is taken by an optional sparkline, which
 * says whether the number is heading somewhere. The uppercase label is the one piece of micro
 * type in the tile, so the value can be large and the hint can be a sentence.
 *
 * <p>`tone` colours the value only when it carries a verdict: a failed count red, a delivery rate
 * green. A plain figure stays in the foreground colour; most figures are plain.
 */
export function StatTile({
  label,
  value,
  hint,
  chip,
  tone = "default",
  sparkline,
  loading,
  error,
  footnote,
  className,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  /** A pill under the value: `["healthy", "success"]`. Already-chosen words, already-chosen tone. */
  chip?: readonly [string, "default" | "success" | "warning" | "destructive" | "info" | "outline"];
  tone?: "default" | "positive" | "negative";
  sparkline?: readonly (number | null)[];
  loading?: boolean;
  error?: string;
  footnote?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("min-w-0 rounded-xl border border-border bg-card px-4 py-3.5", className)}>
      <p className="text-2xs font-semibold uppercase tracking-wide text-muted-foreground">{label}</p>
      {loading ? (
        <div className="mt-1.5 h-9 w-24 animate-pulse rounded bg-muted" />
      ) : error ? (
        <p className="mt-1 text-sm text-destructive">{error}</p>
      ) : (
        <>
          <div className="mt-1.5 flex items-end justify-between gap-3">
            <p
              className={cn(
                "text-figure tabular-nums",
                tone === "positive" && "text-success",
                tone === "negative" && "text-destructive"
              )}
            >
              {value}
            </p>
            {sparkline && sparkline.length > 1 && (
              <Sparkline values={[...sparkline]} className="mb-1.5 h-6 w-20 shrink-0 text-muted-foreground" />
            )}
          </div>
          {(chip || hint) && (
            <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              {chip && <Badge variant={chip[1]}>{chip[0]}</Badge>}
              {hint && <span>{hint}</span>}
            </div>
          )}
          {footnote && <div className="mt-1">{footnote}</div>}
        </>
      )}
    </div>
  );
}
