import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * The page tier — the heading that names the whole screen. One per page, never inside a Card.
 *
 * <p>See the tier table in {@link ../ui/card.tsx}. This is the top rank: `text-page` (28/36 semibold),
 * the largest size on any screen. Below it the entity, card and section titles each step down about
 * 1.2, so the heading that names the screen is the one that looks like it does.
 *
 * <p>It exists because the tier was written down long before it was applied. Six of thirty-nine
 * pages emitted it and the rest had no page title at all, so "one per page" was aspirational and
 * every new page copied whichever neighbour it was pasted from. Four portal pages had drifted to
 * their own `h1`, split between `font-medium` and `font-semibold` at the same rank. The 0.11.4.4
 * audit found it at ten of thirty-seven routes and put it on the rest.
 *
 * <p>The actions wrap under the title below `sm`: a range picker plus two buttons is wider than a
 * phone, and a `shrink-0` row there was one of the things that made pages scroll sideways.
 *
 * <p>`h1` rather than the `h2` the operator pages used. There is no `h1` above it on the page —
 * the shell renders navigation, not a document title — so starting at `h2` skipped a level for
 * anything reading the outline.
 *
 * @param description one sentence under the title, for what the screen is for. Not a place for
 *     instructions; if a control needs explaining, explain it at the control.
 * @param actions controls that act on the whole page — an export, a range picker. They sit on the
 *     title's baseline rather than below it, so the heading and the thing that changes it are read
 *     together.
 */
export function PageHeader({
  title,
  description,
  actions,
  back,
  className,
}: {
  title: React.ReactNode;
  description?: React.ReactNode;
  actions?: React.ReactNode;
  /** A link to the list this page came from, above the title. */
  back?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-wrap items-start justify-between gap-3", className)}>
      {/* basis-0: the title block's natural width is its longest sentence, which on a page with a
          long description pushed the actions onto their own row even at 1280px */}
      <div className="min-w-0 flex-1 basis-0 space-y-1.5">
        {back}
        <h1 className="text-page max-sm:text-entity">{title}</h1>
        {description && (
          <p className="text-sm text-muted-foreground">{description}</p>
        )}
      </div>
      {actions && <div className="flex min-w-0 flex-wrap items-center gap-2 max-sm:basis-full">{actions}</div>}
    </div>
  );
}
