"use client";
import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * A plain checkbox, styled to match {@link Input}, that can also render a third state.
 *
 * <p>The markup was already repeated four times before the worker forms added fifteen more, so this
 * removes a duplicate rather than introducing an abstraction — same classes, same behaviour.
 *
 * <p><strong>Unlike the other `ui/` primitives this needs `"use client"` and a ref effect.</strong>
 * `indeterminate` is a DOM property with no HTML attribute behind it, so React cannot set it from
 * JSX; it has to be assigned to the element after render. `ui/select.tsx` makes a point of not
 * needing the directive, and the difference is worth naming rather than looking like an oversight.
 *
 * <p>The third state is not decoration. A worker setting that has never been given a value is not
 * the same as one set to false: the gateway falls back to its own default, which for several keys
 * is `true`. A two-state box would draw an empty tick beside a setting that is switched on.
 */
export const Checkbox = React.forwardRef<
  HTMLInputElement,
  Omit<React.InputHTMLAttributes<HTMLInputElement>, "type"> & { indeterminate?: boolean }
>(({ className, indeterminate = false, ...props }, forwarded) => {
  const inner = React.useRef<HTMLInputElement | null>(null);

  React.useEffect(() => {
    if (inner.current) {
      inner.current.indeterminate = indeterminate;
    }
  }, [indeterminate]);

  return (
    <input
      type="checkbox"
      ref={(node) => {
        inner.current = node;
        if (typeof forwarded === "function") {
          forwarded(node);
        } else if (forwarded) {
          forwarded.current = node;
        }
      }}
      className={cn(
        "h-4 w-4 shrink-0 rounded border-input accent-primary disabled:cursor-not-allowed disabled:opacity-50",
        className
      )}
      {...props}
    />
  );
});
Checkbox.displayName = "Checkbox";
