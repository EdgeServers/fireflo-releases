import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * The one data table.
 *
 * <p>Before this there were four: Messages (striped, a tinted header), Refused (uppercase header,
 * no stripes), the access log (plain) and Metrics (striped with grouped bodies). Each was right on
 * the day it was written and they had drifted into four ways of saying "rows". This is the shape
 * the "Tailwind Control Panel Design" sample draws: a bordered surface, an 11px uppercase header,
 * 44px rows separated by hairlines only, the first column in the text colour and the rest muted,
 * and a footer that says what it is showing.
 *
 * <p>Real `&lt;table&gt;` elements rather than the sample's CSS grid: the e2e suite finds rows by
 * `tr`, screen readers get a table, and column widths still come from content. `TR` keeps
 * `border-b last:border-0` so a table of several `&lt;tbody&gt;` groups rules between them too.
 */

export function Table({
  className,
  children,
  footer,
  ...props
}: React.HTMLAttributes<HTMLDivElement> & {
  /** A {@link TableFooter}, drawn under the scrolling part so it never scrolls with the columns. */
  footer?: React.ReactNode;
}) {
  return (
    <div className={cn("overflow-hidden rounded-xl border border-border bg-card", className)} {...props}>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">{children}</table>
      </div>
      {footer}
    </div>
  );
}

/** A table that sits inside a Card already: no second border, the card's edge is its edge. */
export function TableInCard({ className, children }: { className?: string; children: React.ReactNode }) {
  return (
    <div className={cn("overflow-x-auto", className)}>
      <table className="w-full text-sm">{children}</table>
    </div>
  );
}

export function THead({ className, ...props }: React.HTMLAttributes<HTMLTableSectionElement>) {
  return <thead className={cn("border-b border-border", className)} {...props} />;
}

export function TBody(props: React.HTMLAttributes<HTMLTableSectionElement>) {
  return <tbody {...props} />;
}

export function TH({
  className,
  align,
  ...props
}: React.ThHTMLAttributes<HTMLTableCellElement> & { align?: "left" | "right" | "center" }) {
  return (
    <th
      className={cn(
        "whitespace-nowrap px-4 py-2.5 text-left text-2xs font-semibold uppercase tracking-[0.06em] text-muted-foreground",
        align === "right" && "text-right",
        align === "center" && "text-center",
        className
      )}
      {...props}
    />
  );
}

export function TR({ className, ...props }: React.HTMLAttributes<HTMLTableRowElement>) {
  return (
    <tr
      className={cn("border-b border-border transition-colors last:border-0 hover:bg-muted/50", className)}
      {...props}
    />
  );
}

export function TD({
  className,
  align,
  primary,
  muted,
  num,
  ...props
}: React.TdHTMLAttributes<HTMLTableCellElement> & {
  align?: "left" | "right" | "center";
  /** The column that names the row: text colour, semibold. */
  primary?: boolean;
  /** Secondary detail: the muted colour. */
  muted?: boolean;
  /** A number: right-aligned, tabular figures. */
  num?: boolean;
}) {
  return (
    <td
      className={cn(
        //11px above and below a 22px line: a 44px row, the touch target, at body size
        "px-4 py-[11px] align-middle",
        primary && "font-semibold text-foreground",
        muted && "text-muted-foreground",
        num && "text-right tabular-nums",
        align === "right" && "text-right",
        align === "center" && "text-center",
        className
      )}
      {...props}
    />
  );
}

/**
 * "Showing 1–50" on the left, Prev / Next on the right.
 *
 * <p>`total` is optional on purpose: the big tables page by cursor and never count the whole
 * filtered set, because COUNT(*) is the one query that stops being fast as they grow. Without it
 * the footer says what is on screen and no more.
 */
export function TableFooter({
  from,
  to,
  total,
  noun,
  onPrev,
  onNext,
  prevDisabled,
  nextDisabled,
  children,
}: {
  from: number;
  to: number;
  total?: number | null;
  noun?: string;
  onPrev?: () => void;
  onNext?: () => void;
  prevDisabled?: boolean;
  nextDisabled?: boolean;
  /** Extra controls on the right, before Prev. */
  children?: React.ReactNode;
}) {
  const range = to < from ? "nothing" : from === to ? `${from}` : `${from}–${to}`;
  return (
    <div className="flex flex-wrap items-center gap-2 border-t border-border px-4 py-2.5 text-xs text-muted-foreground">
      <span>
        Showing {range}
        {total != null ? ` of ${total}` : ""}
        {noun ? ` ${noun}` : ""}
      </span>
      <span className="ml-auto flex items-center gap-1">
        {children}
        {onPrev && (
          <button type="button" onClick={onPrev} disabled={prevDisabled} className={chip}>
            Prev
          </button>
        )}
        {onNext && (
          <button type="button" onClick={onNext} disabled={nextDisabled} className={cn(chip, "text-foreground")}>
            Next
          </button>
        )}
      </span>
    </div>
  );
}

const chip =
  "h-7 rounded-sm border border-border bg-card px-2.5 text-xs transition-colors hover:bg-muted disabled:pointer-events-none disabled:opacity-50";

/** The empty row every table shows the same way. */
export function TableEmpty({ colSpan, children }: { colSpan: number; children: React.ReactNode }) {
  return (
    <tr>
      <td colSpan={colSpan} className="px-4 py-10 text-center text-sm text-muted-foreground">
        {children}
      </td>
    </tr>
  );
}
