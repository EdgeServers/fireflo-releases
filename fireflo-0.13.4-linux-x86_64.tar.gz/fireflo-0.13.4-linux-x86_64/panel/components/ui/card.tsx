import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * The panel's container and heading vocabulary. Three containers, four heading tiers.
 *
 * <h2>Containers</h2>
 *
 * <pre>
 *   Card         bordered, elevated, bg-card    a subject
 *   CardSection  flat, hairline rule            a labelled group inside a Card
 *   EditPanel    muted, no shadow, transient    a form that appeared in place
 * </pre>
 *
 * <p><strong>A Card never goes inside a Card.</strong> Not a style preference — it does not work
 * here. `--color-card` and `--color-background` are the same colour in light mode and 2% apart in
 * dark, so a nested Card has no tonal separation; and `--radius-lg` and `--radius-xl` are both
 * `0.75rem`, so two concentric boxes have no usable corner delta either. All a nested Card buys is
 * a second border and shadow that read as a stray sibling. Use {@link CardSection}.
 *
 * <p>The padding is why: a nested card would put 32px between its text and the column edge — a
 * sixth of a `col-span-3` column spent on gutter.
 *
 * <h2>Padding</h2>
 *
 * <pre>
 *   CardHeader   px-5 py-3.5        phone: px-4 py-3        bar: + border-b bg-muted/40
 *   CardContent  px-5 pb-5 pt-0     phone: px-4 pb-4        pt-0 because the header's py-3.5 is the gap
 *   CardFooter   px-5 pb-5 pt-0     bar: px-5 py-3.5
 *   EditPanel    p-5
 * </pre>
 *
 * <p>One density. There used to be two: `p-6` on every card older than 0.11.4.3 and `px-4 py-3`
 * on every card since, which the audit measured as thirteen distinct inner paddings across the
 * panel and 48px of a 358px phone card spent on gutter. The denser one won because it is what the
 * sample this panel is styled after uses, and because a card is a frame around content, not a
 * poster. A caller that passes `py-3` or `pb-2` on a header is saying nothing the default does not;
 * leave the class off.
 *
 * <p>Sizes here are quoted at a 16px root, which is the browser default and what the panel now
 * renders at. `app/globals.css` deliberately sets no root font-size, so a reader who has asked for
 * larger text scales all of this with them — quote rem, or say "at a 16px root", and never bake a
 * pixel number into a rule. Three earlier versions of this comment were arithmetic against a 21px
 * and an 18px root that had already been deleted.
 *
 * <h2>Type tiers</h2>
 *
 * <p>The sizes are tokens in `app/globals.css`, set for Noto Sans; a heading's class names its
 * role, and the token carries size, line height, weight and tracking together, so a heading needs
 * no `font-*` or `leading-*` beside it.
 *
 * <pre>
 *   page       PageHeader   text-page     28/36  one per route, every route, never in a Card
 *   entity     h2           text-entity   22/30  the page's subject (AccountShell)   at most one
 *   card       CardTitle    text-title     17/24  every Card                          many
 *   section    CardSection  text-section  15/22  a labelled group inside a card      many
 *   body                    text-sm       14/22  tables, prose, controls, labels (font-medium)
 *   secondary               text-xs       13/20  text-muted-foreground: help, captions, timestamps
 *   micro                   text-2xs      11/16  uppercase tracking-wide: FactGrid labels, eyebrows
 *   figure     StatTile     text-figure   30/36  the big number, tabular-nums
 * </pre>
 *
 * <p>Each step is about 1.2 times the one under it, so a section title is never smaller than the
 * text it heads -- the fault the old scale had, where card titles and body were both 14px. Every
 * control -- input, select, textarea, button, a checkbox's label -- is body size. `text-2xs` is the
 * only size under `text-xs`; there is no `text-[10px]` or `text-[11px]` anywhere. `text-base` and
 * the stock `text-lg`..`text-3xl` are not tiers; reaching for one means a role is missing.
 *
 * <p>Weight: headings are semibold through their tokens, labels `font-medium`, and `font-bold`
 * marks only the FireFlo wordmark.
 *
 * <p><strong>A component that can be embedded never emits an entity title.</strong> `text-entity`
 * is reserved for the subject of the page. A child that renders it inside somebody else's card
 * produces headings larger than the card title above them.
 *
 * <h2>Borders</h2>
 *
 * <pre>
 *   border-border      + pt-4   section rules, and rows in a list
 *   border-border/40           row rules inside a dense data grid only
 *   border-dashed              never. Dashed means "drop zone"; nothing here is one.
 * </pre>
 */

export function Card({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("rounded-xl border border-border bg-card text-card-foreground", className)}
      {...props}
    />
  );
}

/**
 * The title block.
 *
 * <p>`bar` fills it and rules it off from the content — a titled bar across the top of the card
 * rather than text floating above it. It carries its own `mb-4`, so {@link CardContent}'s `pt-0`
 * still lines up underneath; a caller that also passes `pb-3` will fight it, and should not.
 *
 * <p>The fill is `bg-muted/40`, the same shade {@link EditPanel} and the `striped` tables use, so a
 * card gains a header bar without introducing a fourth surface colour.
 */
export function CardHeader({
  bar = false,
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement> & { bar?: boolean }) {
  return (
    <div
      className={cn(
        "flex flex-col space-y-1 px-5 py-3.5 max-sm:px-4 max-sm:py-3",
        bar && "mb-5 border-b border-border max-sm:mb-4",
        className
      )}
      {...props}
    />
  );
}

export function CardTitle({ className, ...props }: React.HTMLAttributes<HTMLHeadingElement>) {
  return (
    <h3 className={cn("text-title", className)} {...props} />
  );
}

/**
 * The sentence under a title.
 *
 * <p>`text-xs` rather than the `text-base` this arrived with. That is the sanctioned help-text token
 * — one step below the smallest label, introduced so hints stop matching the weight of the thing
 * they explain — and every card in this panel had been hand-rolling
 * `<p className="mt-1 text-xs text-muted-foreground">` instead of importing this. No margin class
 * is needed: {@link CardHeader}'s `space-y-1.5` supplies the gap.
 */
export function CardDescription({ className, ...props }: React.HTMLAttributes<HTMLParagraphElement>) {
  return <p className={cn("text-xs text-muted-foreground", className)} {...props} />;
}

export function CardContent({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("px-5 pb-5 pt-0 max-sm:px-4 max-sm:pb-4", className)} {...props} />;
}

/**
 * The row of actions at the foot of a card.
 *
 * <p>For actions that act on the card as a whole -- add one of these, open that page, stop this
 * worker. A control that only scopes what the card is *showing*, like a search box or a range
 * picker, belongs in the header instead: it is a question about the contents, not a thing done to
 * them, and a filter at the bottom of a list reads as an action on the list.
 *
 * <p>`bar` fills it and rules it off, matching {@link CardHeader}'s `bar`. Use them together or
 * neither, or the card ends up with one finished edge and one loose one.
 */
export function CardFooter({
  bar = false,
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement> & { bar?: boolean }) {
  return (
    <div
      className={cn(
        "flex flex-wrap items-center gap-2 px-5 max-sm:px-4",
        bar ? "border-t border-border py-3.5 max-sm:py-3" : "pb-5 pt-0 max-sm:pb-4",
        className
      )}
      {...props}
    />
  );
}

/**
 * A labelled group inside a {@link CardContent}. The panel's sub-card.
 *
 * <p>Flat on purpose: a hairline rule and a small muted label, no border of its own, no background,
 * no extra padding. See the file comment for why a nested Card is not an option here.
 *
 * <p>The title is `text-section` (15/22 semibold, foreground): one step under a card title and one
 * over the body it heads. It used to be muted 14px medium, the same size as the text under it, so a
 * group's name read as one more line of its content.
 *
 * <p>`first:` resets mean the rule appears between sections and never above the first one, so a
 * caller can add and remove sections without thinking about separators.
 *
 * @param action a control belonging to this group — an Add button, a range picker. It sits beside
 *     the label rather than below the content, so it is always adjacent to the words that say what
 *     it acts on
 */
export function CardSection({
  title,
  description,
  action,
  className,
  children,
}: {
  title: string;
  description?: React.ReactNode;
  action?: React.ReactNode;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <section className={cn("space-y-3 border-t border-border pt-5 first:border-t-0 first:pt-0", className)}>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h4 className="text-section">{title}</h4>
        {action}
      </div>
      {description && <CardDescription>{description}</CardDescription>}
      {children}
    </section>
  );
}

/**
 * A form that appeared in place — approving a sender ID, topping up a balance.
 *
 * <p>The one thing that legitimately needs to detach from its surroundings: you have to see what you
 * are editing and where Cancel is. It gets a muted fill rather than a Card, because a Card here
 * would read as a peer of the card containing it.
 *
 * <p>`bg-muted/40` is already the vocabulary — the `striped` table utility uses the same shade — and
 * since a top-level Card never has a muted background, this can never be mistaken for one.
 */
export function EditPanel({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("space-y-4 rounded-md border border-border bg-muted/40 p-5 max-sm:p-4", className)}
      {...props}
    />
  );
}
