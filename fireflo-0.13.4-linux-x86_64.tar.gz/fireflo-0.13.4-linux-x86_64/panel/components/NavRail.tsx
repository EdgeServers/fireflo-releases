"use client";
import Link from "next/link";
import { cn } from "@/lib/utils";

/**
 * The two pieces both navs are built from.
 *
 * <p>Extracted when the portal grew a dashboard and its nav went from three flat links to six in
 * groups — the shape the operator panel had already settled on. The alternative was a second copy
 * of the accent bar, the collapsed tooltip rule and the `aria-current` handling, which is exactly
 * the kind of duplication that is identical on the day it is written and subtly different a month
 * later.
 *
 * <p><strong>What is deliberately not shared is which link is active.</strong> The operator matches
 * by prefix so a detail page keeps its section lit; the portal matches exactly, because its root is
 * a prefix of every other route it has. Both rules are right for their own app and neither
 * generalises, so the caller decides and passes a boolean.
 */

/**
 * A group's label, or the rule that stands in for it on the rail.
 *
 * <p>The rail cannot show the word, but it still needs the grouping — without some mark the icons
 * read as one undifferentiated column. A hairline costs no width and keeps the same rhythm.
 */
export function NavGroupHeading({ label, collapsed }: { label: string; collapsed: boolean }) {
  if (collapsed) {
    return <div className="mx-2 my-2 border-t border-border/70" aria-hidden />;
  }
  return (
    <p className="px-2.5 pb-1.5 pt-4 text-2xs font-semibold uppercase tracking-[0.08em] text-muted-foreground">
      {label}
    </p>
  );
}

/**
 * One nav row.
 *
 * <p>At module scope rather than inside a shell: a component declared during render is a new
 * component type on every render, so React unmounts and remounts the whole nav each time — losing
 * focus and any transient state with it.
 */
export function NavLink({ href, label, icon: Icon, collapsed, active, count }: {
  href: string;
  label: string;
  icon: React.ElementType;
  collapsed: boolean;
  /** Computed by the caller — see the note above about why this is not decided here. */
  active: boolean;
  /** A number at the row's right edge, the way the sample shows "Domains 12". */
  count?: number | string | null;
}) {
  return (
    <Link
      href={href}
      //the name is the tooltip when it is not on screen, so a rail is still navigable without
      //learning the icons
      title={collapsed ? label : undefined}
      aria-label={collapsed ? label : undefined}
      //the one thing a screen reader cannot infer from styling
      aria-current={active ? "page" : undefined}
      className={cn(
        //py-2.5 below md:, so a nav row clears the 44px a thumb needs. They drop back to py-2 on a
        //pointer device, where the smaller target was never the problem. The breakpoint is md: and
        //not sm: because that is where the nav becomes a drawer -- between 640 and 768 the drawer
        //is still showing and the device is still being touched. See ui/button.tsx.
        //32px rows on a pointer device (the sample's), 44 below md: where the nav is a drawer and
        //the device is being touched. See ui/button.tsx for why the breakpoint is md:
        "group relative flex min-h-11 items-center rounded-md border-l-2 text-sm transition-colors duration-150 md:min-h-9 md:py-0",
        collapsed ? "justify-center px-0" : "gap-2.5 pl-2 pr-2.5",
        //the active row is a soft tint of the accent with the accent as its text, and weight does
        //the rest -- the sample's treatment. It replaced a left-edge bar plus a primary/10 alpha
        //the active row is a muted tint with a 2px rule on its left edge and the foreground colour,
        //bold; no hue, so the one green on the page stays the mark
        active
          ? "border-primary bg-muted font-semibold text-foreground"
          : "border-transparent font-medium text-foreground hover:bg-muted"
      )}
    >
      <Icon className={cn("h-4 w-4 shrink-0", active ? "text-foreground" : "text-muted-foreground")} />
      {!collapsed && <span className="truncate">{label}</span>}
      {!collapsed && count != null && (
        <span className="ml-auto text-2xs tabular-nums text-muted-foreground">
          {count}
        </span>
      )}
    </Link>
  );
}
