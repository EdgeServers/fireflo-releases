import * as React from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

/**
 * The pieces both sign-in pages are built from, so the operator's door and the customer's cannot
 * drift apart: they did, to the point of different card widths, heading sizes and link styles.
 */

/** The white card the form sits in, on either page. */
export function AuthCard({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={cn("w-full rounded-xl border border-border bg-card p-6 text-card-foreground sm:p-8", className)}>
      {children}
    </div>
  );
}

/** The page heading and the one line under it. */
export function AuthHeading({ title, children }: { title: string; children?: React.ReactNode }) {
  return (
    <div className="mb-6 space-y-1">
      <h1 className="text-page">{title}</h1>
      {children && <p className="text-sm text-muted-foreground">{children}</p>}
    </div>
  );
}

/** The rule between the main way in and the other one. */
export function OrRule() {
  return (
    <div className="my-4 flex items-center gap-2.5 text-xs text-muted-foreground">
      <span className="h-px flex-1 bg-border" />
      or
      <span className="h-px flex-1 bg-border" />
    </div>
  );
}

/**
 * The other way in, under the rule. Allowed to wrap: "No password, or forgotten it? Email me a
 * sign-in link" ran off the card on a phone when it was a one-line button.
 */
export function AuthAlternative({ onClick, children }: { onClick: () => void; children: React.ReactNode }) {
  return (
    <Button type="button" variant="outline" className="h-auto min-h-11 w-full whitespace-normal py-2 md:h-auto md:min-h-9" onClick={onClick}>
      {children}
    </Button>
  );
}

/**
 * The other way in, as a sentence with only its action as the link: "No password, or forgotten
 * it? <u>Email me a sign-in link</u>". A whole sentence as one button read as a second primary
 * action and gave the click target to words that are not the action.
 */
export function AuthSwitch({ onClick, link, children }: { onClick: () => void; link: string; children: React.ReactNode }) {
  return (
    <p className="mt-5 text-center text-sm text-muted-foreground">
      {children}{" "}
      <button
        type="button"
        onClick={onClick}
        className="rounded-sm font-medium text-primary underline-offset-4 hover:underline focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
      >
        {link}
      </button>
    </p>
  );
}
