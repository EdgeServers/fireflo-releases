"use client";
import { useState } from "react";
import Link from "next/link";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AccountsClient } from "./AccountsClient";
import { DeliveryCheck } from "./DeliveryCheck";
import { RangePicker } from "./RangePicker";
import type { Range } from "./useControlData";
import { useAccountContext } from "./useAccountContext";
import { useRates } from "./useRates";
import { scopeKind } from "@/lib/rate-types";
import { surface } from "@/lib/panel-surface";

/**
 * What this account has been doing, and whether anything is wrong with it.
 *
 * <p>The landing tab, so it answers the question somebody arriving actually has — "they say their
 * messages are failing" — before any of the configuration tabs they would otherwise open one by one
 * looking for the cause.
 */
export function AccountOverviewClient({ id }: { id: string }) {
  const { context } = useAccountContext(id);
  const { known } = useRates();
  const [range, setRange] = useState<Range>("7d");
  const kind = scopeKind(id, known);
  //what this surface may show about what an account is charged, and who carries it -- see
  //lib/panel-surface.ts
  const { pricing } = surface();

  return (
    //traffic left, the two things you check about it right. The vendor list and the delivery check
    //were both stacked above a table that is the reason anyone opens this tab, so they pushed it
    //down without being read; beside it they are glanceable and the table keeps the width
    <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_20rem]">
      <Card className="min-w-0">
        <CardHeader bar className="flex flex-row flex-wrap items-center gap-2 space-y-0">
          <div className="min-w-0 space-y-1.5">
            <CardTitle>Traffic</CardTitle>
            <CardDescription>
              Derived from the messages that actually arrived, split by login and product.
            </CardDescription>
          </div>
          <div className="ml-auto">
            <RangePicker value={range} onChange={setRange} />
          </div>
        </CardHeader>
        <CardContent>
          <AccountsClient account={id} chrome={false} range={range} onRangeChange={setRange} />
        </CardContent>
      </Card>

      <div className="min-w-0 space-y-4">
        {/* the customer-shaped question -- "they say their messages are failing" -- answered
            beside the traffic rather than above it.

            Operator-only: it diagnoses the ROUTING TABLE and offers to write a fix to it, which is
            the operator's configuration and not a fact about this account at all */}
        {pricing && <DeliveryCheck accountId={id} />}

        {pricing && kind === "cost" && (
          <Card className="border-destructive">
            <CardContent className="py-3 text-sm text-destructive">
              A vendor is also called <code>{id}</code>. Rating matches a rate scope by name alone,
              so this account&apos;s rules are read as <strong>our cost for that vendor</strong> as
              well as its price. Rename one before pricing either.
            </CardContent>
          </Card>
        )}

        {/* which carriers this account's traffic actually went out over. A reseller's customer
            being told which carrier its operator buys from is a commercial disclosure, so the
            portal's context route does not send this either -- the gate here is the second lock */}
        {pricing && context?.vendors?.length ? (
          <Card>
            <CardHeader bar>
              <CardTitle>Where it went</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <ul className="space-y-1">
                {context.vendors.map((v) => (
                  <li key={v.vendor} className="font-mono">{v.vendor}</li>
                ))}
              </ul>
              <Link href={`/cp/cdrs?account=${encodeURIComponent(id)}`}
                className="inline-block text-primary hover:underline">
                See the messages
              </Link>
            </CardContent>
          </Card>
        ) : null}
      </div>
    </div>
  );
}
