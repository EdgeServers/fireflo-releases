"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { RefreshCw, Unplug } from "lucide-react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { Button, buttonClasses } from "@/components/ui/button";
import { PageHeader } from "@/components/ui/page-header";
import { Segmented } from "@/components/ui/segmented";
import { StatTile } from "@/components/ui/stat-tile";
import { HealthStrip } from "@/components/CardBits";
import type { ClientWatchHandle } from "@/components/ClientWatchCard";
import { ForceDisconnectDialog } from "@/components/ForceDisconnectDialog";
import { useHealth } from "@/components/useHealth";
import { RefusalsCard, type Sources } from "@/components/security/RefusalsCard";
import type { RulesPayload } from "@/components/security/AutomaticBans";
import { SecurityRail } from "@/components/security/SecurityRail";
import { REFUSAL_LEDGER, hasCapability } from "@/lib/capabilities";
import type { BindHold } from "@/lib/force-disconnect";
import { isAdminSession } from "@/lib/roles";
import { surfaceLabel, type BlockedAddress, type SecurityEvent, type SecuritySurface } from "@/lib/security-events";
import { SURFACES, bucketsFor, groupByAddress } from "@/lib/security-grouping";
import type { LedgerPayload } from "@/lib/security-rows";

/**
 * Who was refused, from where, and who is blocked. One range for everything on the page.
 *
 * <p>One `load()` per range reads the four things the page shows -- the refusal log tail and the
 * fail2ban state, the gateway's ledger (where the gateway has one), the bind holds, and the rules
 * (admin) -- in parallel, and every action that changes the host or the gateway (a ban, an unban, a
 * hold, a lift) re-runs it, so the tiles, the table and the rail never disagree about one address.
 *
 * <p>The composition lives here; the pieces are under `components/security/`: the card of refused
 * logins with its tabs and the rules, and the rail of states and tools beside it.
 */

/** What `/api/control/security` answers. */
interface SecurityPayload {
  events: SecurityEvent[];
  blocked: BlockedAddress[];
  sources: Sources;
}

/** Everything one read of the page returned, stamped with the range it was read for. */
interface Loaded {
  rangeId: RangeId;
  /**
   * When the data on screen was read.
   *
   * <p>The range is measured from here rather than from `Date.now()` during render. Reading the
   * clock while rendering is impure -- the cutoff would move on every re-render, so a row could
   * drop out of "the last day" because something unrelated changed -- and this is also the more
   * honest reading: the range is relative to the moment these events were fetched.
   */
  readAt: number;
  security: SecurityPayload;
  ledger: LedgerPayload | null;
  ledgerError: string | null;
  holds: BindHold[];
  holdsError: string | null;
  rules: RulesPayload | null;
  rulesError: string | null;
}

/** One range for the whole page: the tiles, the chart, every tab and the sign-in summary agree. */
const RANGES = [
  { value: "1h", label: "1h", long: "hour", hours: 1 },
  { value: "6h", label: "6h", long: "6 hours", hours: 6 },
  { value: "24h", label: "24h", long: "24 hours", hours: 24 },
  { value: "7d", label: "7d", long: "7 days", hours: 24 * 7 },
  { value: "30d", label: "30d", long: "30 days", hours: 24 * 30 },
] as const;

type RangeId = (typeof RANGES)[number]["value"];

async function readJson<T>(url: string, fallback: string): Promise<T> {
  const res = await fetch(url, { cache: "no-store" });
  const body = await res.json().catch(() => null);
  if (!res.ok) {
    throw new Error(body?.error ?? `${fallback} (${res.status}).`);
  }
  return body.data as T;
}

function message(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}

export function SecurityClient() {
  const { data: session } = useSession();
  const admin = isAdminSession(session);
  const { health, error: healthError, loading: healthLoading } = useHealth();
  const ledgerSupported = hasCapability(health, REFUSAL_LEDGER);

  const [rangeId, setRangeId] = useState<RangeId>("24h");
  const [loaded, setLoaded] = useState<Loaded | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [banBusy, setBanBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [problem, setProblem] = useState<string | null>(null);
  const [forcing, setForcing] = useState<{ ip?: string } | null>(null);
  const watch = useRef<ClientWatchHandle>(null);
  //the newest read wins: a slow 30-day read must not land on top of a quick 1-hour one
  const seq = useRef(0);

  const range = RANGES.find((r) => r.value === rangeId)!;
  const days = Math.max(1, Math.ceil(range.hours / 24));

  /**
   * Reads everything for the range, and touches no state: the result is handed to {@link apply}
   * from a callback, which is what lets the effect below subscribe to it without a synchronous
   * setState. Null when a newer read has started since, so a slow 30-day read cannot land on top
   * of a quick 1-hour one. The "reading" state is derived rather than set (see `loading`).
   */
  const read = useCallback(async (): Promise<Loaded | { error: string } | null> => {
    const mine = ++seq.current;
    const [security, ledger, holds, rules] = await Promise.allSettled([
      readJson<SecurityPayload>("/api/control/security", "Could not read the security log"),
      ledgerSupported
        ? readJson<LedgerPayload>(`/api/control/security/refusals?windowMinutes=${range.hours * 60}`, "Could not read the refusal ledger")
        : Promise.resolve(null),
      readJson<BindHold[]>("/api/control/bind-holds", "Could not read the bind holds"),
      admin
        ? readJson<RulesPayload>("/api/control/security/rules", "Could not read the ban rules")
        : Promise.resolve(null),
    ]);
    if (mine !== seq.current) {
      return null;
    }
    if (security.status === "rejected") {
      return { error: message(security.reason) };
    }
    return {
      rangeId: range.value,
      readAt: Date.now(),
      security: security.value,
      ledger: ledger.status === "fulfilled" ? ledger.value : null,
      ledgerError: ledger.status === "rejected" ? message(ledger.reason) : null,
      holds: holds.status === "fulfilled" ? (holds.value ?? []) : [],
      holdsError: holds.status === "rejected" ? message(holds.reason) : null,
      rules: rules.status === "fulfilled" ? rules.value : null,
      rulesError: rules.status === "rejected" ? message(rules.reason) : null,
    };
  }, [range, ledgerSupported, admin]);

  const apply = useCallback((result: Awaited<ReturnType<typeof read>>) => {
    if (result === null) {
      return;
    }
    if ("error" in result) {
      setError(result.error);
      return;
    }
    setError(null);
    setLoaded(result);
  }, []);

  /** One read of everything, applied: what every action runs after it took. */
  const load = useCallback(() => read().then(apply), [read, apply]);

  useEffect(() => {
    let live = true;
    read().then((result) => {
      if (live) {
        apply(result);
      }
    });
    return () => {
      live = false;
    };
  }, [read, apply]);

  const loading = refreshing || (loaded === null ? error === null : loaded.rangeId !== rangeId);
  const data = loaded?.security;
  const now = loaded?.readAt ?? 0;

  //everything in the range, every surface: the tiles, the chart and the card read this
  const inRange = useMemo(() => {
    if (!loaded) {
      return [];
    }
    const cutoff = loaded.readAt - range.hours * 3_600_000;
    return loaded.security.events.filter((e) => {
      if (!e.at) {
        return true;
      }
      const at = Date.parse(e.at);
      return Number.isNaN(at) || at >= cutoff;
    });
  }, [loaded, range.hours]);
  const buckets = useMemo(
    () => (loaded ? bucketsFor(inRange, range.hours, loaded.readAt) : []),
    [inRange, range.hours, loaded]
  );
  const counts = useMemo(() => {
    const by: Record<SecuritySurface, number> = { smpp: 0, rest: 0, panel: 0, portal: 0 };
    for (const event of inRange) {
      by[event.surface] += 1;
    }
    return by;
  }, [inRange]);
  const addresses = useMemo(() => groupByAddress(inRange), [inRange]);
  const busiest = addresses[0];

  const blocked = useMemo(() => data?.blocked ?? [], [data]);
  const holds = useMemo(() => loaded?.holds ?? [], [loaded]);
  const sources = data?.sources;
  const canUnban = Boolean(sources?.fail2ban.canUnban);

  const act = useCallback(
    async (key: string, run: () => Promise<string | null>) => {
      setBusy(key);
      setProblem(null);
      try {
        const said = await run();
        setNotice(said);
        await load();
        return true;
      } catch (err) {
        setProblem(message(err));
        return false;
      } finally {
        setBusy(null);
      }
    },
    [load]
  );

  const unban = useCallback(
    (jail: string, ip: string) =>
      act(`${jail} ${ip}`, async () => {
        const res = await fetch("/api/control/security/unban", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ jail, ip }),
        });
        const body = await res.json().catch(() => null);
        if (!res.ok) {
          throw new Error(body?.error ?? "The unban did not complete.");
        }
        return `${ip} is no longer banned in ${jail}.`;
      }),
    [act]
  );

  const lift = useCallback(
    (holdId: number) =>
      act(`hold ${holdId}`, async () => {
        const res = await fetch(`/api/control/bind-holds/${holdId}`, { method: "DELETE" });
        if (!res.ok) {
          const body = await res.json().catch(() => null);
          throw new Error(body?.error ?? "The hold could not be lifted.");
        }
        return "The hold is lifted; they may bind again.";
      }),
    [act]
  );

  const ban = useCallback(
    async (ip: string, jail: string, seconds: number | null) => {
      setBanBusy(true);
      try {
        return await act(`ban ${ip}`, async () => {
          const res = await fetch("/api/control/security/ban", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ ip, jail, seconds: seconds ?? undefined }),
          });
          const body = await res.json().catch(() => null);
          if (!res.ok) {
            throw new Error(body?.error ?? `The ban did not complete (${res.status}).`);
          }
          return `${ip} is now banned in ${jail}.${body?.data?.note ? ` ${body.data.note}` : ""}`;
        });
      } finally {
        setBanBusy(false);
      }
    },
    [act]
  );

  const refresh = () => {
    setRefreshing(true);
    void load().finally(() => setRefreshing(false));
  };

  return (
    <>
      <PageHeader
        title="Security"
        description="Who was refused, from where, and who is blocked. One range for everything on this page; FireFlo records the refusals, fail2ban does the blocking."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Segmented
              label="Range"
              options={RANGES.map((r) => ({ value: r.value, label: r.label, title: `The last ${r.long}` }))}
              value={rangeId}
              onChange={setRangeId}
            />
            {/* who may sign in belongs with who was refused; it has no nav entry of its own, and only
                an admin may open it */}
            {admin && (
              <Link href="/cp/users" className={buttonClasses({ variant: "outline" })}>
                Users
              </Link>
            )}
            <Button variant="outline" className="gap-2" onClick={() => setForcing({})}
              title="Drop every SMPP session from an address, account or login, and optionally keep it out">
              <Unplug className="h-4 w-4" aria-hidden /> Force disconnect
            </Button>
            <Button variant="outline" size="icon" onClick={refresh} disabled={loading} title="Refresh" aria-label="Refresh">
              <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} aria-hidden />
            </Button>
          </div>
        }
      />

      {error && <HealthStrip tone="destructive">{error}</HealthStrip>}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile
          label="Refused logins"
          value={inRange.length.toLocaleString()}
          hint={SURFACES.filter((s) => counts[s] > 0).map((s) => `${surfaceLabel(s)} ${counts[s]}`).join(" · ") || "none"}
          loading={loading && !loaded}
          tone={inRange.length > 0 ? "negative" : "default"}
        />
        <StatTile
          label="Addresses"
          value={addresses.length.toLocaleString()}
          hint={busiest ? `busiest ${busiest.ip}, ${busiest.attempts}` : "none"}
          loading={loading && !loaded}
        />
        <StatTile
          label="Blocked now"
          value={String(blocked.length)}
          hint={sources?.fail2ban.present ? (sources.fail2ban.live ? "from fail2ban" : "from recorded bans") : "fail2ban not set up"}
          loading={loading && !loaded}
          tone={blocked.length > 0 ? "negative" : "default"}
        />
        <StatTile
          label="Held out"
          value={String(holds.length)}
          hint={
            holds.length === 0
              ? "none"
              : holds.every((h) => !h.until)
                ? "by an operator, until lifted"
                : "by an operator, some for a while"
          }
          loading={loading && !loaded}
          tone={holds.length > 0 ? "negative" : "default"}
        />
      </div>

      {/* attackers on the left, where the room is; the state and the tools on the right */}
      <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1fr)_22rem]">
        <RefusalsCard
          rangeLabel={range.long}
          hourly={range.hours <= 48}
          events={inRange}
          buckets={buckets}
          ledger={loaded?.ledger ?? null}
          ledgerSupported={ledgerSupported}
          ledgerError={loaded?.ledgerError ?? null}
          health={health}
          healthLoading={healthLoading}
          healthError={healthError}
          blocked={blocked}
          holds={holds}
          sources={sources}
          now={now}
          loading={loading}
          notice={notice}
          problem={problem}
          rowActions={{
            onWatch: (ip) => watch.current?.openFor(ip),
            onHold: (ip) => setForcing({ ip }),
            onUnban: (jail, ip) => void unban(jail, ip),
            onLift: (id) => void lift(id),
            busy,
            canUnban,
          }}
          banBusy={banBusy}
          onBan={ban}
          admin={admin}
          rules={loaded?.rules ?? null}
          rulesError={loaded?.rulesError ?? null}
          onReload={load}
        />
        <SecurityRail
          blocked={blocked}
          holds={holds}
          holdsError={loaded?.holdsError ?? null}
          sources={sources}
          canUnban={canUnban}
          busy={busy}
          now={now}
          days={days}
          rangeLabel={range.long}
          onUnban={(jail, ip) => void unban(jail, ip)}
          onLift={(id) => void lift(id)}
          watch={watch}
        />
      </div>

      {forcing && (
        <ForceDisconnectDialog
          initialKind="ip"
          initialValue={forcing.ip ?? ""}
          onClose={() => setForcing(null)}
          onDone={() => void load()}
        />
      )}
    </>
  );
}
