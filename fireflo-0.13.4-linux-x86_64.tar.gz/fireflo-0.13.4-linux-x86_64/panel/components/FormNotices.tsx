import { AlertTriangle, Check } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

/**
 * The two cards every form in this panel ends with.
 *
 * <p>Not in `ui/`: these know the panel's conventions — amber for "this is legal and probably not
 * what you meant", destructive for "the server refused" — and `ui/` here is style only. Four forms
 * had byte-identical copies of both before this existed.
 */

/**
 * Legal-but-suspicious values, listed rather than blocked.
 *
 * <p>Never disables submit. A sub-second reconnect interval is a real thing to want while testing a
 * reconnect loop; the panel only knows the value is unusual, not that it is wrong.
 */
export function WarningCard({ warnings }: { warnings: string[] }) {
  if (!warnings.length) {
    return null;
  }
  return (
    <Card className="border-warning/40">
      <CardContent className="space-y-2 py-4">
        <WarningList warnings={warnings} />
      </CardContent>
    </Card>
  );
}

/**
 * The same warnings, flat, for a form that is already inside a card.
 *
 * <p>The amber border is what a Card was being used for here, and a bordered box inside a box with
 * the same background reads as a stray sibling rather than as a note about the field above it. The
 * icon carries the tone instead.
 */
export function WarningNote({ warnings }: { warnings: string[] }) {
  return warnings.length ? (
    <div className="space-y-2 rounded-md border border-warning/40 bg-warning-soft/40 p-3">
      <WarningList warnings={warnings} />
    </div>
  ) : null;
}

function WarningList({ warnings }: { warnings: string[] }) {
  return (
    <>
      {warnings.map((warning) => (
        <p key={warning} className="flex items-start gap-2 text-sm">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning" />
          <span>{warning}</span>
        </p>
      ))}
    </>
  );
}

/**
 * What the server said when it refused, for an error already inside a card.
 *
 * <p>The flat sibling of {@link ErrorCard}. A Card inside a Card has no tonal separation in this
 * theme and reads as a stray sibling, so a section that wants to report a failure in place uses this
 * and keeps the Card for page level.
 */
export function ErrorNote({ error }: { error: string }) {
  return error ? <p className="text-sm text-destructive">{error}</p> : null;
}

/** What the server said when it refused. Page level; use {@link ErrorNote} inside a card. */
export function ErrorCard({ error }: { error: string }) {
  if (!error) {
    return null;
  }
  return (
    <Card>
      <CardContent className="py-4 text-sm text-destructive">{error}</CardContent>
    </Card>
  );
}

/**
 * Confirmation that a write landed, with the time it landed.
 *
 * <p>The time is the point. A form that keeps its fields after saving looks identical before and
 * after, so "Saved" alone is indistinguishable from a stale message left over from ten minutes ago —
 * and the operator is left reading their own inputs wondering whether they are stored values or
 * pending ones. A clock that moves says which.
 *
 * <p>Emerald because that is this panel's success colour, in `Badge` and in the live stat cards.
 * Amber would read as "legal but probably not what you meant", which is the opposite of the message.
 *
 * <p>The caller must clear this the moment anything is edited again. A confirmation sitting beside
 * unsaved changes is worse than no confirmation at all.
 */
export function SavedNote({ at, detail }: { at: string | null; detail?: string }) {
  if (!at) {
    return null;
  }
  return (
    <p className="flex items-start gap-1.5 text-xs text-success">
      <Check className="mt-px h-3.5 w-3.5 shrink-0" />
      <span>
        <strong>Saved at {at}.</strong> The fields below are what is now stored.{detail ? ` ${detail}` : ""}
      </span>
    </p>
  );
}
