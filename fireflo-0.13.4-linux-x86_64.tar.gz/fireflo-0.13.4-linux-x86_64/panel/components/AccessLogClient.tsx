"use client";
import { useState } from "react";
import { useSearchParams } from "next/navigation";
import { useSession } from "next-auth/react";
import { EmptyState } from "@/components/ui/empty-state";
import { PageHeader } from "@/components/ui/page-header";
import { Tabs } from "@/components/ui/tabs";
import { AuditLogClient } from "@/components/AuditLogClient";
import { isAdminSession } from "@/lib/roles";

type Door = "portal" | "operator";

/**
 * The two access logs, as a report.
 *
 * <p>Portal first: who reached a customer account is the question support asks, and every operator
 * may read it. The operator door is the record of the people who can edit the database and is the
 * admin's alone -- the tab is there for everyone so the page does not look different per role, but
 * an operator opening it is told why it is empty rather than shown an empty table.
 *
 * <p>`?account=ID` and `?user=ID` pre-fill the filters, which is how the Users page and an account
 * link into it.
 */
export function AccessLogClient() {
  const params = useSearchParams();
  const { data: session } = useSession();
  const admin = isAdminSession(session);
  const user = Number(params.get("user")) || null;
  const account = params.get("account");
  const [door, setDoor] = useState<Door>(user ? "operator" : "portal");

  return (
    <>
      <PageHeader
        title="Access log"
        description="Who signed in, who was refused, and what they did -- the customer portal and the operator panel."
      />
      <Tabs
        label="Door"
        items={[
          { id: "portal", label: account ? `Customer portal · ${account}` : "Customer portal" },
          { id: "operator", label: "Operator panel" },
        ]}
        active={door}
        onSelect={setDoor}
      />
      {door === "portal" && <AuditLogClient surface="portal" accountId={account} />}
      {door === "operator" && !admin && (
        <EmptyState>
          The operator panel&rsquo;s log is readable by admins only. It records what the people who can change this
          database did.
        </EmptyState>
      )}
      {door === "operator" && admin && <AuditLogClient surface="operator" userId={user} />}
    </>
  );
}
