import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import type { SettingWidget } from "@/lib/setting-fields";

/**
 * The one control a setting's widget kind renders as.
 *
 * <p>Extracted out of `GatewaySettingsClient`'s stacked `Field` so the same enum/boolean/text
 * branching can also render inside a table cell, on `GatewayKeyTable`'s unified Worker defaults
 * row — a curated setting keeps its dropdown wherever it is shown, rather than degrading to a bare
 * text box the moment it moves out of its original stacked-field layout.
 */
export function SettingControl({
  widget,
  codedDefault,
  id,
  value,
  disabled,
  onChange,
}: {
  widget: SettingWidget;
  /** Null where no default was read out of the gateway source, so nothing is claimed. */
  codedDefault: string | null;
  id?: string;
  value: string;
  disabled: boolean;
  onChange: (value: string) => void;
}) {
  if (widget.kind === "enum") {
    return (
      <Select id={id} value={value} disabled={disabled} onChange={(e) => onChange(e.target.value)}>
        <option value="">{notSetLabel(codedDefault)}</option>
        {widget.options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </Select>
    );
  }
  if (widget.kind === "boolean") {
    return (
      <Select id={id} value={value} disabled={disabled} onChange={(e) => onChange(e.target.value)}>
        <option value="">{notSetLabel(codedDefault)}</option>
        <option value="true">On</option>
        <option value="false">Off</option>
      </Select>
    );
  }
  return (
    <Input
      id={id}
      value={value}
      disabled={disabled}
      placeholder={codedDefault ?? "not set"}
      className="font-mono"
      onChange={(e) => onChange(e.target.value)}
    />
  );
}

/**
 * What "not set" means for this key.
 *
 * <p>Only claims a default where one was actually read out of the gateway source. A null
 * `codedDefault` says nothing rather than guessing.
 */
export function notSetLabel(codedDefault: string | null): string {
  if (codedDefault === null) {
    return "Not set";
  }
  if (codedDefault === "") {
    return "Not set — the gateway's default is empty";
  }
  return `Not set — the gateway's default is ${codedDefault}`;
}
