"use client";
import { useCallback, useEffect, useRef, useState } from "react";

/**
 * One card open at a time, and the scrolling that goes with it.
 *
 * <p>Shared by the vendor and server pages so the two cannot drift into behaving differently — they
 * are the same page with a different noun, and they have drifted before.
 *
 * <p><strong>Which card opens on arrival is the interesting decision.</strong> The list is already
 * sorted worst-first, so the first entry is the one that needs attention, and opening it means the
 * page arrives showing the problem rather than showing whichever instance happens to sort first
 * alphabetically.
 *
 * <p>It is chosen <em>once</em>, guarded by a ref rather than by comparing state. Health is polled
 * every ten seconds and the sort is derived from it, so the first entry can change under a
 * long-running page — without the guard, a vendor recovering while somebody is reading a different
 * card would silently close the card they were reading.
 */
export function useAccordion(ordered: { name: string }[]) {
  const [open, setOpen] = useState<string | null>(null);
  const chosen = useRef(false);
  const nodes = useRef(new Map<string, HTMLElement>());

  const first = ordered[0]?.name ?? null;

  useEffect(() => {
    if (chosen.current || first == null) {
      return;
    }
    chosen.current = true;
    setOpen(first);
  }, [first]);

  const toggle = useCallback((name: string) => {
    setOpen((current) => (current === name ? null : name));
  }, []);

  /** From the rail: open it and bring it into view, even if it was already open. */
  const select = useCallback((name: string) => {
    setOpen(name);
    //the header is rendered whether the card is open or not, so there is nothing to wait for —
    //scrolling in the same tick lands on the right element. `block: "start"` against <main>, which
    //is the scroll container here rather than the window
    nodes.current.get(name)?.scrollIntoView({ block: "start", behavior: "smooth" });
  }, []);

  const cardRef = useCallback((name: string) => (node: HTMLElement | null) => {
    if (node) {
      nodes.current.set(name, node);
    } else {
      //deleted on unmount, or the map holds a node for every worker ever rendered and keeps its
      //DOM alive for the life of the page
      nodes.current.delete(name);
    }
  }, []);

  return { open, toggle, select, cardRef };
}
