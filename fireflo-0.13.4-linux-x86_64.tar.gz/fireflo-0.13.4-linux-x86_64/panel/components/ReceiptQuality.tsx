"use client";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { RangePicker } from "./RangePicker";
import { useControlData, type Range } from "./useControlData";
import { count, elapsed, percent } from "@/lib/format";
import { EmptyState } from "@/components/ui/empty-state";

/**
 * Whether each vendor tells us what happened, and how quickly.
 *
 * <p>A different question from the one Vendors already answers. That page shows a delivery rate —
 * delivered over *reported* — and a vendor reporting on 40% of the traffic it carries can show 95%
 * there while three messages in five have no outcome at all. Both numbers are true; only one of them
 * is about the vendor's behaviour, and the panel used to show only the flattering one.
 *
 * <p><strong>The comparison is the point</strong>, which is why this is a page rather than a card on
 * each vendor. "Two and a half minutes to an outcome" means nothing alone and everything beside a
 * vendor doing the same job in nine seconds.
 */

/** Mirrors `ReceiptQualityRow` in `lib/receipt-queries.ts`. */
export interface ReceiptQualityRow {
  vendor: string | null;
  sent: number;
  reported: number;
  expired: number;
  open: number;
  delivered: number;
  medianToOutcome: number | null;
  p90ToOutcome: number | null;
  progressReceipts: number | null;
  messagesWithProgress: number | null;
  medianToFirstSign: number | null;
  /** Set when the timings and progress figures come from a sample; the counts never do. */
  sampled?: { size: number; of: number } | null;
}

/** Settled messages the vendor actually reported on. Open traffic is not counted as silence. */
export function reportingRate(row: ReceiptQualityRow): number | null {
  const settled = row.reported + row.expired;
  return settled === 0 ? null : row.reported / settled;
}

export function ReceiptQualityClient() {
  const [range, setRange] = useState<Range>("24h");
  const { data, error, loading } = useControlData<ReceiptQualityRow[]>("receipts", range);
  const rows = data ?? [];
  //null on every row means the gateway has no cdr_interim, not that no vendor sends progress
  const progressRecorded = rows.some((r) => r.progressReceipts !== null);

  return (
    <>
      <PageHeader
        title="Receipts"
        description="How often each vendor reports an outcome, and how long it takes to arrive."
        actions={<RangePicker value={range} onChange={setRange} />}
      />

      {error && (
        <Card>
          <CardContent className="py-4 text-sm text-destructive">{error}</CardContent>
        </Card>
      )}

      {!error && !rows.length && (
        <EmptyState>
          {loading ? "Loading…" : "No traffic in this period"}
        </EmptyState>
      )}

      {!!rows.length && (
        <Card>
          <CardHeader>
            <CardTitle>By vendor</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <TableInCard className="tabular-nums">
              <THead>
                <tr>
                  <TH>Vendor</TH>
                  <TH align="right">Sent</TH>
                  <TH align="right">Reported</TH>
                  <TH align="right">Reporting rate</TH>
                  <TH align="right">Gave up on</TH>
                  <TH align="right">Still open</TH>
                  <TH align="right">Delivered</TH>
                  <TH align="right">Median</TH>
                  <TH align="right">90th</TH>
                  <TH align="right">Progress</TH>
                </tr>
              </THead>
              <TBody>
                {rows.map((row) => (
                  <TR key={row.vendor ?? "none"}>
                    <TD primary>
                      {row.vendor ?? <span className="text-muted-foreground">no vendor</span>}
                    </TD>
                    <TD align="right">{count(row.sent)}</TD>
                    <TD align="right">{count(row.reported)}</TD>
                    <TD align="right">
                      <ReportingBadge rate={reportingRate(row)} />
                    </TD>
                    <TD align="right">{count(row.expired)}</TD>
                    <TD align="right">{count(row.open)}</TD>
                    <TD align="right">
                      {row.reported === 0
                        ? "—"
                        : percent(row.delivered / row.reported)}
                    </TD>
                    <TD align="right">{elapsed(row.medianToOutcome)}</TD>
                    <TD align="right">{elapsed(row.p90ToOutcome)}</TD>
                    <TD align="right">
                      {row.progressReceipts === null
                        ? <span className="text-muted-foreground" title="not recorded">·</span>
                        : count(row.progressReceipts)}
                    </TD>
                  </TR>
                ))}
              </TBody>
            </TableInCard>

            {/* a long range is timed over a sample of its messages: say so, with the numbers, so
                nobody reads a median as computed over every message when it was not */}
            {rows.some((r) => r.sampled) && (
              <p className="text-xs text-muted-foreground">
                Timings and progress receipts are read from a sample of{" "}
                {count(rows.reduce((n, r) => n + (r.sampled?.size ?? 0), 0))} of{" "}
                {count(rows.reduce((n, r) => n + (r.sampled?.of ?? 0), 0))} messages, the same
                messages on every load; progress counts are scaled up from it. Sent, reported, gave
                up on, open and delivered are exact.
              </p>
            )}

            <div className="space-y-1 text-sm text-muted-foreground">
              <p>
                <strong>Reporting rate</strong> is outcomes the vendor sent, over the messages that
                have settled one way or another. Messages still in flight are left out of the
                denominator entirely — traffic sent a minute ago has not had its chance yet, and
                counting it as silence would make every vendor look worse the sooner you looked.
              </p>
              <p>
                <strong>Gave up on</strong> is our own sweeper writing EXPIRED because no receipt
                ever arrived. Those are not counted as reported, which is the difference between
                this table and the delivery rate on Vendors: that one is computed over a denominator
                the vendor itself chose.
              </p>
              <p>
                <strong>Delivered</strong> is a share of what was reported, so it says nothing about
                the messages in the two columns before it.
              </p>
              {progressRecorded ? (
                <p>
                  <strong>Progress</strong> counts non-terminal receipts — ACCEPTD, BUFFRED — that
                  say a message is moving without saying how it ended. A vendor sending none is not
                  at fault; it simply will not tell you anything before the end.
                </p>
              ) : (
                <p>
                  <strong>Progress is not recorded by this gateway.</strong> <code>cdr_interim</code>
                  {" "}arrives in V1.33.0, and until it does a non-terminal receipt leaves no trace,
                  so the column is blank rather than zero.
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </>
  );
}

/**
 * How often this vendor says anything at all, on the same scale the delivery badge uses.
 *
 * <p>Coloured, unlike most numbers in this panel, because it is the one an operator is looking for:
 * a vendor below 70% is losing the platform its own view of what happened to paid traffic.
 */
function ReportingBadge({ rate }: { rate: number | null }) {
  if (rate === null) {
    return <span className="text-muted-foreground">—</span>;
  }
  return (
    <Badge variant={rate >= 0.95 ? "success" : rate >= 0.7 ? "outline" : "destructive"}>
      {percent(rate)}
    </Badge>
  );
}

/**
 * How well this vendor reports back, under its card on `/cp/vendors`.
 *
 * <p>This used to render four of `ReceiptQualityRow`'s eleven fields on the reasoning that the
 * card should prompt someone to open the full report rather than duplicate it. The four it chose
 * were the right four, but the seven it dropped were fetched on every poll and thrown away, and
 * two of them are the ones that make the first four checkable:
 *
 * <ul>
 *   <li><strong>the denominators.</strong> "Reports outcomes 98%" is a ratio with its terms
 *       hidden. `sent`, `reported` and `open` are what it is a ratio of, and without them a
 *       reassuring percentage over eleven settled messages looks the same as one over fifty
 *       thousand</li>
 *   <li><strong>time to the first sign of life</strong>, as distinct from time to a final
 *       outcome. A vendor that acknowledges in a second and settles in ten minutes and one that
 *       says nothing for ten minutes have the same median to outcome and are not the same vendor</li>
 *   <li><strong>progress coverage</strong> — how much of the traffic reports intermediate state at
 *       all, which is what says whether the previous figure describes the traffic or a corner of it</li>
 * </ul>
 *
 * <p>Still not a copy of the report: the per-vendor table on `/cp/receipts` compares vendors
 * against each other, which is a different question from how this one is behaving.
 */
export function ReceiptQualityLine({ row }: { row: ReceiptQualityRow | undefined }) {
  if (!row) {
    //not zeros. Nothing was measured, which is different from measuring nothing
    return null;
  }
  const rate = reportingRate(row);

  return (
    <div className="space-y-2 border-t border-border pt-3">
      <p className="text-xs text-muted-foreground">Delivery receipts</p>
      <dl className="grid gap-x-6 gap-y-2 text-sm sm:grid-cols-2 lg:grid-cols-4">
        <div className="flex items-center justify-between gap-2 sm:block">
          <dt className="text-muted-foreground">Reports outcomes</dt>
          <dd className="font-medium tabular-nums">
            <ReportingBadge rate={rate} />
          </dd>
        </div>
        <Stat label="Sent" value={count(row.sent)} />
        <Stat label="Reported" value={count(row.reported)} />
        <Stat label="Still open" value={count(row.open)} />
        {/* first sign beside final outcome, in that order: they are the same clock read at two
            points, and the gap between them is the reading */}
        <Stat label="Median to first sign" value={elapsed(row.medianToFirstSign)} />
        <Stat label="Median to outcome" value={elapsed(row.medianToOutcome)} />
        <Stat label="90th percentile" value={elapsed(row.p90ToOutcome)} />
        <Stat
          label="Never reported"
          value={count(row.expired)}
          note={row.expired > 0 ? "swept as expired" : undefined}
        />
      </dl>
      {/* one sentence rather than two more tiles: the pair only means anything together, and the
          share is what says whether the median above describes the traffic or a corner of it */}
      {row.progressReceipts != null && row.messagesWithProgress != null && (
        <p className="text-sm text-muted-foreground">
          Progress receipts{" "}
          <span className="font-medium tabular-nums text-foreground">
            {count(row.progressReceipts)}
          </span>{" "}
          across{" "}
          <span className="font-medium tabular-nums text-foreground">
            {count(row.messagesWithProgress)}
          </span>{" "}
          messages
          {row.sent > 0 && (
            <> · {percent(row.messagesWithProgress / row.sent)} of traffic reports intermediate state</>
          )}
        </p>
      )}
    </div>
  );
}

function Stat({ label, value, note }: { label: string; value: string; note?: string }) {
  return (
    <div className="flex items-center justify-between gap-2 sm:block">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="font-medium tabular-nums">
        {value}
        {note && <span className="ml-1 font-normal text-muted-foreground">{note}</span>}
      </dd>
    </div>
  );
}
