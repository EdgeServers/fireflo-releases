"use client";
import { useEffect, useState } from "react";
import { AlertTriangle, ChevronDown, ChevronRight } from "lucide-react";
import type { ProductGap } from "@/lib/product-readiness";
export type { ProductGap };
import { productGapSentence } from "@/lib/product-readiness";

interface Readiness {
  gaps: ProductGap[];
  summary: string | null;
  checked: number;
}

/**
 * What would stop connecting if a listener began requiring a product.
 *
 * <p>Sits with the listener settings because that is where the decision is made: "Require a product
 * on every connection" is one tick box away, and this is the answer to what that tick costs. An
 * operator should not have to turn it on to find out.
 *
 * <p><strong>Renders nothing when there is nothing wrong.</strong> No zero count, no green tick. A
 * panel that reports success on every healthy deployment trains people to scroll past it, and this
 * needs to be read on exactly one day.
 *
 * <p>Collapsed to the summary by default. The count and the caveat are what decide whether to look
 * further; the per-login sentences are what you read once you have decided to fix them.
 */
/** The report, for a page that places each gap on the login it names rather than in one banner. */
export function useProductReadiness(account?: string): Readiness | null {
  const [readiness, setReadiness] = useState<Readiness | null>(null);
  useEffect(() => {
    let live = true;
    const url = account
      ? `/api/control/product-readiness?account=${encodeURIComponent(account)}`
      : "/api/control/product-readiness";
    fetch(url, { cache: "no-store" })
      .then((res) => res.json())
      .then((json) => {
        if (live && json?.data) {
          setReadiness(json.data as Readiness);
        }
      })
      .catch(() => undefined);
    return () => {
      live = false;
    };
  }, [account]);
  return readiness;
}

export function ProductReadiness({ account }: { account?: string }) {
  const [readiness, setReadiness] = useState<Readiness | null>(null);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    let live = true;
    const url = account
      ? `/api/control/product-readiness?account=${encodeURIComponent(account)}`
      : "/api/control/product-readiness";
    fetch(url, { cache: "no-store" })
      .then((res) => res.json())
      .then((json) => {
        if (live && json?.data) {
          setReadiness(json.data as Readiness);
        }
      })
      //a report that could not load is not a report that found nothing, but it is also not worth an
      //error banner over settings that are readable without it
      .catch(() => undefined);
    return () => {
      live = false;
    };
  }, [account]);

  if (!readiness?.summary || !readiness.gaps.length) {
    return null;
  }

  return (
    <div className="rounded-md border border-warning/40 bg-warning-soft/40 p-3">
      <button
        type="button"
        className="flex w-full items-start gap-2 text-left text-sm"
        aria-expanded={open}
        onClick={() => setOpen(!open)}
      >
        <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning" />
        <span className="flex-1">{readiness.summary}</span>
        {open
          ? <ChevronDown className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
          : <ChevronRight className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />}
      </button>

      {open && (
        <ul className="mt-3 space-y-2 border-t border-warning/20 pt-3">
          {readiness.gaps.map((gap, i) => (
            <li key={`${gap.accountId}:${gap.systemId}:${i}`}
              className="text-xs text-muted-foreground">
              {/*the account, because one login name means nothing on a page listing every listener
                 on the gateway*/}
              <span className="font-mono text-foreground/80">{gap.accountId}</span>
              {" — "}
              {productGapSentence(gap)}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
