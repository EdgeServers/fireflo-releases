"use client";
import { useState } from "react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AdvancedToggle } from "./AdvancedToggle";
import { CredentialsClient } from "./CredentialsClient";
import { useAdvanced } from "@/hooks/useAdvanced";
import { useSession } from "next-auth/react";
import { SmppTestTool } from "./SmppTestTool";
import { isAdminSession } from "@/lib/roles";
import { surface } from "@/lib/panel-surface";

/**
 * Who may connect as this account.
 *
 * <p>One card per login now, under a header row that says how many there are and holds the Add
 * button where it is looked for. The table that was here carried eight columns and a chooser, and
 * the question operators bring -- "is this login right, and is it alive" -- was answered across a
 * row too wide to read. A card answers it in three facts and three figures; the rest is behind
 * Advanced.
 */
export function AccountLoginsClient({ id }: { id: string }) {
  const [adding, setAdding] = useState(false);
  const [advanced, setAdvanced] = useAdvanced("logins");
  //the SMPP test tool sends real traffic as the customer, so it is an admin's, and the operator
  //panel's only: the portal renders this component too, without pricing
  const { data: session } = useSession();
  const canTest = surface().pricing && isAdminSession(session);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="min-w-0 flex-1 space-y-0.5">
          <h3 className="text-title">Logins that bill here</h3>
          <p className="text-xs text-muted-foreground">
            A message carries its own account id, so pricing still applies to traffic that arrives
            under it from a login this panel never saw.
          </p>
        </div>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          <AdvancedToggle on={advanced} onChange={setAdvanced} />
          {canTest && <SmppTestTool accountId={id} />}
          <Button size="sm" className="gap-2" onClick={() => setAdding(true)}>
            <Plus className="h-4 w-4" />
            Add login
          </Button>
        </div>
      </div>
      <CredentialsClient
        account={id}
        chrome={false}
        advanced={advanced}
        addOpen={adding}
        onAddHandled={() => setAdding(false)}
      />
    </div>
  );
}
