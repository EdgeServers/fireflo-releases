"use client";
import Link from "next/link";
import { X } from "lucide-react";
import { Select } from "@/components/ui/select";
import type { Filter } from "@/lib/filter-types";

/**
 * The filters on one rule: chips for what is chosen, a dropdown for what else exists.
 *
 * <p><strong>A filter the rule already carries stays listed even when it has been disabled or has
 * vanished from the library.</strong> Dropping it would silently detach it on the next save, and a
 * rule that loses a filter does not stop working — it starts matching more traffic, at whatever
 * amount it was charging. Same reasoning as the product Select.
 *
 * <p>No inline create. A filter is shared by several rules, so making one is a decision about the
 * library rather than about the rule in front of you; the link goes to the page that owns it.
 */
export function FilterPicker({
  chosen,
  library,
  onChange,
}: {
  chosen: string[];
  library: Filter[];
  onChange: (next: string[]) => void;
}) {
  const known = new Map(library.map((f) => [f.name, f]));
  //everything selectable: enabled filters not already on this rule
  const available = library.filter((f) => f.enabled && !chosen.includes(f.name));

  return (
    <div className="space-y-1">
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-sm text-muted-foreground">Filters</span>
        {chosen.map((name) => {
          const filter = known.get(name);
          return (
            <span
              key={name}
              className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 font-mono text-xs ${
                filter && filter.enabled
                  ? "border-border bg-muted/40"
                  : "border-warning/40 bg-warning-soft/40"}`}
              title={filter
                ? filter.enabled
                  ? filter.conditions.map((c) => `${c.field} ${c.operator} ${c.value}`).join(" and ")
                  : "This filter is switched off, so the gateway skips this rule entirely."
                : "No filter of this name exists any more."}
            >
              {name}
              {filter && !filter.enabled && " (off)"}
              {!filter && " (missing)"}
              <button type="button" aria-label={`Remove ${name}`}
                onClick={() => onChange(chosen.filter((c) => c !== name))}>
                <X className="h-3 w-3" />
              </button>
            </span>
          );
        })}
        <Select
          value=""
          aria-label="Add a filter"
          className="h-7 w-44 text-sm"
          onChange={(e) => e.target.value && onChange([...chosen, e.target.value])}
        >
          <option value="">add a filter…</option>
          {available.map((f) => (
            <option key={f.name} value={f.name}>{f.name}</option>
          ))}
        </Select>
        {!available.length && !chosen.length && (
          <Link href="/cp/filters" className="text-xs text-primary hover:underline">
            No filters defined yet
          </Link>
        )}
      </div>
    </div>
  );
}

