"use client";
import { Badge } from "@/components/ui/badge";
import { count, money, percent } from "@/lib/format";

/** One row of `vendorPerformance`, keyed by the worker's full name. */
export interface VendorRow {
  vendor: string | null;
  attempts: number;
  messages: number;
  delivered: number;
  failed: number;
  pending: number;
  cost: number;
  deliveryRate: number | null;
}

/**
 * A vendor's traffic for the selected period.
 *
 * <p>Rendered beside its settings rather than on a page of its own, so a vendor is one thing you
 * configure and monitor together.
 *
 * <p>Nothing here is derived from the settings — delivery is credited to the vendor that made the
 * <em>last</em> attempt, while cost counts every attempt, so the two numbers answer different
 * questions and a difference between them is the retry pressure rather than an inconsistency.
 */
export function VendorTraffic({ row }: { row: VendorRow | undefined }) {
  if (!row) {
    //deliberately not zeros: nothing was measured, which is different from measuring nothing
    return (
      <p className="text-sm text-muted-foreground">No traffic in this period.</p>
    );
  }

  const retries = row.attempts - row.messages;

  return (
    <div className="space-y-3">
      {/* three lead, three supporting, rather than six of equal weight. Cost used to sit at the
          same rank as In flight, so a card of seven identical figures had no entry point. Nothing
          is dropped by the ranking -- every field below was rendered before and still is */}
      <dl className="grid gap-3 sm:grid-cols-3">
        <Lead label="Messages" value={count(row.messages)} />
        <div>
          <dt className="text-xs text-muted-foreground">Delivered</dt>
          <dd className="flex flex-wrap items-baseline gap-2">
            <span className="text-figure tabular-nums">
              {count(row.delivered)}
            </span>
            {/* the count and its own rate, together. They used to be entries three and six of a
                six-column row with Failed and In flight between them -- a number and the
                percentage OF that number, separated by two unrelated figures */}
            {row.deliveryRate !== null && (
              <Badge
                variant={
                  row.deliveryRate >= 0.9
                    ? "success"
                    : row.deliveryRate >= 0.7
                      ? "outline"
                      : "destructive"
                }
              >
                {percent(row.deliveryRate)}
              </Badge>
            )}
          </dd>
        </div>
        <Lead label="Cost" value={money(row.cost)} />
      </dl>

      <dl className="grid gap-x-6 gap-y-1 text-sm sm:grid-cols-3">
        <Stat
          label="Attempts"
          value={count(row.attempts)}
          note={retries > 0 ? `+${count(retries)} retried` : undefined}
        />
        <Stat label="Failed" value={count(row.failed)} />
        <Stat label="In flight" value={count(row.pending)} />
      </dl>
    </div>
  );
}

/** A figure the eye should land on first. Three per block, no more, or none of them leads. */
function Lead({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs text-muted-foreground">{label}</dt>
      <dd className="text-figure tabular-nums">{value}</dd>
    </div>
  );
}

function Stat({ label, value, note }: { label: string; value: string; note?: string }) {
  return (
    <div className="flex items-center justify-between gap-2 sm:block">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="font-medium tabular-nums">
        {value}
        {note && <span className="ml-1 font-normal text-muted-foreground">({note})</span>}
      </dd>
    </div>
  );
}
