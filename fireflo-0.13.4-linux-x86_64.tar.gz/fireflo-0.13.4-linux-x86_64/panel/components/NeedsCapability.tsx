"use client";
import type { ReactNode } from "react";
import { HealthStrip } from "@/components/CardBits";
import { hasCapability } from "@/lib/capabilities";
import type { Health } from "@/lib/health-types";

/**
 * Renders a screen only on a gateway whose API declares the capability it needs.
 *
 * <p>The capability map (`health.api`) is a fact about the build, published by name; a screen asks
 * for the name rather than reasoning from the version string. While health has not arrived the
 * children are held back rather than flashed, and a gateway that cannot be reached shows that
 * error instead of a misleading "needs 0.13".
 *
 * @param name the capability, from `lib/capabilities.ts`
 * @param feature what the screen shows, for the sentence: "the slow-query log"
 */
export function NeedsCapability({
  health,
  loading,
  error,
  name,
  feature,
  children,
}: {
  health: Health | null;
  loading: boolean;
  error: string | null;
  name: string;
  feature: string;
  children: ReactNode;
}) {
  if (!health) {
    if (error) {
      return <HealthStrip tone="destructive">{error}</HealthStrip>;
    }
    return <p className="text-sm text-muted-foreground">{loading ? "Reading the gateway…" : "The gateway has not answered yet."}</p>;
  }
  if (!hasCapability(health, name)) {
    return (
      <HealthStrip tone="info">
        This gateway does not publish {feature} ({health.version?.trim() || "version not reported"}); it needs
        gateway 0.13 or newer, which declares the <code className="font-mono">{name}</code> capability.
      </HealthStrip>
    );
  }
  return <>{children}</>;
}
