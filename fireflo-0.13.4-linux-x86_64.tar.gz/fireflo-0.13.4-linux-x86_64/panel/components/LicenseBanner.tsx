"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { bannerHeadline, bannerTone, type LicenseState } from "@/lib/license-state";
import { useHealthOnce } from "@/components/GatewayPairing";
import { schemaPairing } from "@/lib/version-pairing";

/**
 * One line above the dashboard when the licence needs attention.
 *
 * <h2>Nothing at all when the licence is fine</h2>
 *
 * <p>A banner an operator sees every day is a banner they stop reading, and this one would be
 * sitting above the screens they use to run a carrier. It renders nothing on an active licence and
 * nothing while it is still loading — a bar that flashes in and out on every navigation is worse
 * than one that appears a moment late.
 *
 * <h2>It is a signal, not a gate</h2>
 *
 * <p>There is deliberately no redirect. An operator with a lapsed licence still needs to read call
 * records, chase a stuck vendor and answer a customer — and bouncing them to an activation screen
 * from whichever page they opened would obstruct exactly the work a lapse does not actually stop.
 * The gateway is what withholds configuration changes; this says so and offers the way out.
 *
 * <p>Deleting this file changes nothing about enforcement. See `lib/license-state.ts`.
 *
 * <h2>And one line for a database the panel was not written for</h2>
 *
 * <p>The gateway reports the newest migration its database has been through (`schema_version`,
 * 0.13+). A schema older than `EXPECTED_SCHEMA_VERSION` means this panel's next query may ask for
 * a column that is not there, which until now surfaced as a failed page with no cause named; it is
 * said here, once, above every page, with the fix. A newer schema is only mentioned. A gateway too
 * old to report one says nothing, as with the licence.
 */
export function LicenseBanner() {
  const [state, setState] = useState<LicenseState | null>(null);
  const { health } = useHealthOnce();
  const schema = schemaPairing(health?.schema_version);

  useEffect(() => {
    let cancelled = false;
    //failures are swallowed: this is a banner, and a gateway that cannot be reached already shows
    //itself on every page that needs it. Turning that into a second red bar helps nobody
    fetch("/api/control/license", { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : null))
      .then((json: { data?: LicenseState } | null) => {
        if (!cancelled && json?.data) {
          setState(json.data);
        }
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, []);

  const tone = bannerTone(state);
  const schemaLine = schema.message ? (
    <div
      className={`flex flex-wrap items-center justify-between gap-2 border-b px-4 py-2 text-sm ${
        schema.verdict === "older"
          ? "border-destructive/40 bg-destructive/10 text-destructive"
          : "border-warning/40 bg-warning-soft text-warning"
      }`}
      data-schema={schema.verdict}
    >
      <span>{schema.message}</span>
      <Link href="/cp/verify" className="underline underline-offset-2">
        Details
      </Link>
    </div>
  ) : null;
  if (!state || tone === "none") {
    return schemaLine;
  }

  //RED FOR EVERY STATE THAT NEEDS ATTENTION, not the three-step scale bannerTone still computes.
  //
  //Asked for directly, and the reasoning is worth keeping: the graded version treated setup as
  //informational grey, on the argument that crying wolf during grace is how the real freeze gets
  //ignored. That argument is about a licence that is WORKING and will lapse later. It does not
  //cover an install nobody has activated at all -- which is not a mild state from the operator's
  //side, it is an unstarted job with a countdown already running, and grey is how it stayed
  //unstarted.
  //
  //bannerTone is left alone rather than rewritten: it still answers "how bad is this", which the
  //sentence below uses, and a shared rule that two screens read differently is worse than one
  //screen deciding its own colour.
  const classes = "border-destructive/40 bg-destructive/10 text-destructive";

  return (
    <>
      <div className={`flex flex-wrap items-center justify-between gap-2 border-b px-4 py-2 text-sm ${classes}`}>
        <span>
          <strong className="font-medium">{bannerHeadline(state)}.</strong>{" "}
          <span className="opacity-90">
            {/* said on every tone, because it is the thing an operator most needs to know and least
                expects: their traffic is fine */}
            Messages are unaffected.
          </span>
        </span>
        <Link href="/cp/verify" className="underline underline-offset-2">
          Licence
        </Link>
      </div>
      {schemaLine}
    </>
  );
}
