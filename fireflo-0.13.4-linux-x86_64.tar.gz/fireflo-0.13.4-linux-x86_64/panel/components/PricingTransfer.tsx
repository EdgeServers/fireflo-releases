"use client";
import { useRef, useState } from "react";
import { Upload } from "lucide-react";
import { Button, buttonClasses } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { useConfirmChange } from "./ConfirmProvider";
import { ErrorNote } from "./FormNotices";
import { COLUMNS, type ImportPlan, type RulePlan } from "@/lib/pricing-csv";
import { DEFAULT_SCOPE, type ScopeSummary } from "@/lib/rate-types";
import { cn } from "@/lib/utils";

/**
 * Pricing out to a spreadsheet and back, for every account and vendor at once.
 *
 * <p>The same file as a product's export: one row per price, keyed by `rule_id`. An import is
 * previewed before anything is written, and the prices it would remove -- every rule of a named scope
 * that the file leaves out -- are listed one by one and have to be confirmed, because "3 removed" is
 * the line nobody reads before pressing Apply.
 */

type Which = "all" | "accounts" | "vendors" | "scope";

export function PricingExportDialog({
  scope,
  scopes,
  onClose,
}: {
  scope: string | null;
  /** What is priced now, so an export that can only be the header row says so before it downloads. */
  scopes: ScopeSummary[];
  onClose: () => void;
}) {
  const [which, setWhich] = useState<Which>(scope ? "scope" : "all");
  const options: { id: Which; title: string; hint: string }[] = [
    { id: "all", title: "Everything", hint: "every account, vendor and the default" },
    { id: "accounts", title: "Accounts", hint: "what customers pay, the default included" },
    { id: "vendors", title: "Vendors", hint: "what carriers charge us" },
    ...(scope ? [{ id: "scope" as const, title: scope === DEFAULT_SCOPE ? "Everyone" : scope, hint: "only the one open now" }] : []),
  ];
  const priced = scopes.reduce((sum, s) => sum + s.rules, 0);
  const href = `/api/control/pricing/export?which=${which}${which === "scope" && scope ? `&scope=${encodeURIComponent(scope)}` : ""}`;

  return (
    <Dialog open onClose={onClose} title="Export pricing" className="max-w-2xl">
      <div className="space-y-4">
        <div className="grid gap-2 sm:grid-cols-2">
          {options.map((o) => (
            <button key={o.id} type="button" aria-pressed={which === o.id} onClick={() => setWhich(o.id)}
              className={cn(
                "rounded-lg border p-3 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                which === o.id ? "border-primary bg-primary-soft/50 ring-1 ring-primary" : "border-border hover:border-muted-foreground/40"
              )}>
              <span className={cn("block font-semibold", o.id === "scope" && scope !== DEFAULT_SCOPE && "font-mono")}>{o.title}</span>
              <span className="block text-sm text-muted-foreground">{o.hint}</span>
            </button>
          ))}
        </div>
        <p className="text-sm text-muted-foreground">
          A CSV with one row per price: <code className="font-mono">{COLUMNS.join(", ")}</code>.
          Edit it in a spreadsheet and import it back here. Keep <code className="font-mono">rule_id</code>:
          it is how a row finds the price it changes, and a blank one adds a new price. Downloads are
          recorded in the access log.
        </p>
        {priced === 0 && (
          <p className="rounded-lg border border-warning/40 bg-warning-soft/40 px-4 py-3 text-sm">
            <strong>Nothing is priced yet</strong>, so the file will have the header row only. Use it as a
            template: add one row per price beneath the header, leave <code className="font-mono">rule_id</code>{" "}
            blank, and import it back.
          </p>
        )}
        <div className="flex flex-wrap justify-end gap-2 border-t border-border pt-4">
          <Button type="button" variant="ghost" className="mr-auto" onClick={onClose}>Close</Button>
          <a href={href} download className={buttonClasses({})}>Download CSV</a>
        </div>
      </div>
    </Dialog>
  );
}

/** Matches the route's ceiling; a browser should not upload what the server will refuse. */
const MAX_BYTES = 2 * 1024 * 1024;

export function PricingImportDialog({ onClose, onApplied }: { onClose: () => void; onApplied: () => Promise<void> }) {
  const input = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<{ name: string; text: string } | null>(null);
  const [plan, setPlan] = useState<ImportPlan | null>(null);
  const confirm = useConfirmChange();
  const [confirmRemovals, setConfirmRemovals] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<string | null>(null);

  async function post(text: string, dryRun: boolean): Promise<ImportPlan | null> {
    const q = dryRun ? "?dryRun=1" : confirmRemovals ? "?confirmRemovals=1" : "";
    const res = await fetch(`/api/control/pricing/import${q}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ csv: text }),
    });
    const json = await res.json().catch(() => null);
    if (!res.ok) {
      setError(json?.error ?? `Request failed (${res.status})`);
      return null;
    }
    return json.data as ImportPlan;
  }

  async function choose(f: File) {
    setError("");
    setPlan(null);
    setConfirmRemovals(false);
    if (f.size > MAX_BYTES) {
      setError(`That file is larger than ${MAX_BYTES / 1024 / 1024} MB.`);
      return;
    }
    const text = await f.text();
    setFile({ name: f.name, text });
    setBusy(true);
    try {
      setPlan(await post(text, true));
    } finally {
      setBusy(false);
    }
  }

  async function apply() {
    if (!file) return;
    //after the preview, which said what the file does; this is the moment it is done
    if (plan) {
      const ok = await confirm({
        title: `Apply ${file.name}`,
        consequence: `${plan.scopes.length} ${plan.scopes.length === 1 ? "scope is" : "scopes are"} replaced wholesale: `
          + `${plan.added.length} price(s) added, ${plan.changed.length} changed, ${plan.removed.length} removed. `
          + "The gateway prices by them from its next configuration poll.",
        confirmLabel: "Apply prices",
        tone: "caution",
        changes: plan.scopes.map((sc) => ({ label: sc })),
      });
      if (!ok) return;
    }
    setBusy(true);
    setError("");
    try {
      const result = await post(file.text, false);
      if (result) {
        await onApplied();
        setDone(`Applied to ${result.scopes.length} ${result.scopes.length === 1 ? "scope" : "scopes"}. Prices reach the gateway on its next configuration poll.`);
        setPlan(null);
      }
    } finally {
      setBusy(false);
    }
  }

  const total = plan ? plan.added.length + plan.changed.length + plan.removed.length : 0;
  const perScope = plan ? plan.scopes.map((scope) => ({
    scope,
    added: plan.added.filter((r) => r.scope === scope).length,
    changed: plan.changed.filter((r) => r.scope === scope).length,
    removed: plan.removed.filter((r) => r.scope === scope).length,
  })) : [];

  return (
    <Dialog open onClose={onClose} title={plan ? "Import pricing · preview" : "Import pricing"} className="max-w-2xl">
      <div className="space-y-4">
        <input ref={input} type="file" accept=".csv,text/csv" className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            e.target.value = "";
            if (f) void choose(f);
          }} />

        {done ? (
          <p className="rounded-lg border border-success/40 bg-success-soft/40 px-4 py-3 text-sm">{done}</p>
        ) : !plan ? (
          <>
            <div className="flex flex-col items-center gap-2 rounded-lg border border-dashed border-border px-4 py-8 text-center">
              <span className="font-semibold">{file ? file.name : "Choose a pricing CSV"}</span>
              <span className="text-sm text-muted-foreground">Up to 2 MB. Start from an Export.</span>
              <Button type="button" className="gap-2" disabled={busy} onClick={() => input.current?.click()}>
                <Upload className="h-4 w-4" aria-hidden="true" /> {busy ? "Reading…" : file ? "Choose another file" : "Choose file"}
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">
              <strong className="text-foreground">Each account or vendor named in the file is replaced by the file&apos;s rows</strong>;
              any not named is left as it is. Nothing changes until you check the preview and press Apply.
            </p>
          </>
        ) : (
          <>
            <p className="text-sm text-muted-foreground">
              <code className="font-mono">{file?.name}</code> · {plan.scopes.length} {plan.scopes.length === 1 ? "scope" : "scopes"}
              {plan.unchanged > 0 && ` · ${plan.unchanged} unchanged`}
            </p>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <th className="py-1.5 pr-3 font-semibold">Scope</th>
                    <th className="px-2 font-semibold">Added</th>
                    <th className="px-2 font-semibold">Changed</th>
                    <th className="px-2 font-semibold">Removed</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {perScope.map((s) => (
                    <tr key={s.scope}>
                      <td className="py-1.5 pr-3 font-mono">{s.scope === DEFAULT_SCOPE ? "* (everyone)" : s.scope}</td>
                      <td className="px-2 tabular-nums">{s.added || "—"}</td>
                      <td className="px-2 tabular-nums">{s.changed || "—"}</td>
                      <td className={cn("px-2 tabular-nums", s.removed && "font-semibold text-destructive")}>{s.removed || "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {plan.changed.length > 0 && (
              <PlanList title="Changed" items={plan.changed} render={(r) => (
                <>
                  <span className="font-mono">{r.scope}</span> rule {r.ruleId}:{" "}
                  {r.changes.map((c) => `${c.field} ${c.from || "—"} → ${c.to || "—"}`).join(", ")}
                </>
              )} />
            )}
            {plan.added.length > 0 && (
              <PlanList title="Added" items={plan.added} render={(r) => (
                <><span className="font-mono">{r.scope}</span>: {r.describe}</>
              )} />
            )}
            {plan.removed.length > 0 && (
              <div className="space-y-2 rounded-lg border border-destructive/50 px-4 py-3 text-sm">
                <div className="font-semibold text-destructive">Removed, because the file does not list them</div>
                <ul className="space-y-0.5 text-muted-foreground">
                  {plan.removed.map((r) => (
                    <li key={`${r.scope}:${r.ruleId}`}><span className="font-mono">{r.scope}</span> rule {r.ruleId}: {r.describe}</li>
                  ))}
                </ul>
                <label className="flex items-center gap-3">
                  <Switch checked={confirmRemovals} onChange={setConfirmRemovals} aria-label="Confirm the removals" />
                  Delete {plan.removed.length === 1 ? "this price" : `these ${plan.removed.length} prices`}
                </label>
              </div>
            )}
            {total === 0 && <p className="text-sm text-muted-foreground">The file matches what is stored. There is nothing to apply.</p>}
            <p className="text-xs text-muted-foreground">
              Every other account and vendor is left as it is. Each scope is saved on its own, so if one
              fails the ones before it are already applied.
            </p>
          </>
        )}

        <ErrorNote error={error} />

        <div className="flex flex-wrap items-center gap-2 border-t border-border pt-4">
          {plan && !done && (
            <Button type="button" variant="outline" disabled={busy} onClick={() => input.current?.click()}>Choose another file</Button>
          )}
          <span className="mr-auto" />
          <Button type="button" variant="ghost" onClick={onClose}>{done ? "Close" : "Cancel"}</Button>
          {plan && !done && (
            <Button type="button" disabled={busy || total === 0 || (plan.removed.length > 0 && !confirmRemovals)} onClick={() => void apply()}>
              {busy ? "Applying…" : `Apply ${total} ${total === 1 ? "change" : "changes"}`}
            </Button>
          )}
        </div>
      </div>
    </Dialog>
  );
}

function PlanList({ title, items, render }: { title: string; items: RulePlan[]; render: (r: RulePlan) => React.ReactNode }) {
  return (
    <div className="space-y-1 rounded-lg border border-border px-4 py-3 text-sm">
      <div className="font-semibold">{title}</div>
      <ul className="space-y-0.5 text-muted-foreground">
        {items.slice(0, 50).map((r, i) => <li key={`${r.scope}:${r.ruleId ?? `n${i}`}`}>{render(r)}</li>)}
        {items.length > 50 && <li>and {items.length - 50} more</li>}
      </ul>
    </div>
  );
}
