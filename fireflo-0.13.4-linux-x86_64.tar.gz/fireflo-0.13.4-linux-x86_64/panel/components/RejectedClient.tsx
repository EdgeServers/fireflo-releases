"use client";
import { useCallback, useEffect, useState } from "react";
import { Columns3, ShieldX, TriangleAlert } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { EmptyState } from "@/components/ui/empty-state";
import { PageHeader } from "@/components/ui/page-header";
import { TBody, TD, TH, THead, TR, TableFooter, TableInCard } from "@/components/ui/table";
import { InfoPopover } from "@/components/ui/popover";
import { ColumnChooser } from "@/components/ColumnChooser";
import { RejectedCell } from "@/components/RejectedCell";
import { RejectedFilterBar } from "@/components/RejectedFilterBar";
import { ExportsCard } from "@/components/ExportsCard";
import { count } from "@/lib/format";
import { reasonHint, reasonLabel, type RejectedRow, type RejectedSummary } from "@/lib/rejected-types";
import {
  EMPTY_REJECTED_FILTERS,
  type RejectedCursor,
  type RejectedFilterForm,
  type RejectedPage,
  fromQuery,
  toQuery,
} from "@/lib/rejected-request";
import {
  REJECTED_COLUMNS,
  REJECTED_COLUMN_GROUPS,
  REJECTED_COLUMN_STORAGE_KEY,
  type ColumnChoice,
  readColumnChoice,
  resolveColumns,
  toggleColumn,
} from "@/lib/rejected-columns";

const PAGE_SIZE = 50;

/**
 * Where a refusal's message lives — for the few that have one.
 *
 * <p>Guarded on the id being non-empty, because the gateway stores `''` rather than NULL for the
 * refusals that never got as far as a message.
 */
const detailHref = (row: RejectedRow) =>
  row.gatewayMsgId ? `/cp/cdrs/${encodeURIComponent(row.gatewayMsgId)}` : null;

/**
 * Messages the gateway refused.
 *
 * <p>This page exists because refusals were the one thing the panel could not show. A customer
 * reporting "my messages are not arriving" produced nothing on `/cdrs` — not a failed row, an
 * absent one — because a refused message is never submitted and so never becomes a call record.
 * The only evidence was a line in the gateway's log and a counter on `/ops/health` that says how
 * many and never which.
 *
 * <p>The summary leads, not the table. The first question is "is this one account or everybody, one
 * reason or several", and a list of fifty rows answers that far worse than six counts do.
 *
 * <p><strong>The summary survives paging and ignores the reason filter.</strong> Both are about
 * keeping those cards a comparison: the route computes them only for a cursor-less request, so the
 * numbers do not shift under someone turning pages, and it computes them with `reason` dropped, so
 * choosing one highlights a card instead of deleting the other five.
 *
 * <p>Filters live in the URL and are written back with `replaceState` — not `router.push`, which
 * would mean a server round trip and a history entry per search. Paging is keyset, so Previous is
 * something this page remembers rather than computes; see `CdrsClient` for why reversing the sort
 * instead is a trap on a table being written to.
 */
export function RejectedClient() {
  const [filters, setFilters] = useState<RejectedFilterForm>(EMPTY_REJECTED_FILTERS);
  const [rows, setRows] = useState<RejectedRow[]>([]);
  const [nextCursor, setNextCursor] = useState<RejectedCursor | null>(null);
  //one entry per page already visited; the last is the page currently shown
  const [history, setHistory] = useState<(RejectedCursor | null)[]>([null]);
  //held apart from the rows, because it describes the window and the rows describe a page
  const [summary, setSummary] = useState<RejectedSummary[] | null>(null);
  const [total, setTotal] = useState(0);
  //set when the first-page summary was taken over a sample rather than the whole window: the rule
  //in lib/rejected.ts is that a caller who samples says so on screen
  const [sampledOver, setSampledOver] = useState<number | null>(null);
  const [matching, setMatching] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [choice, setChoice] = useState<ColumnChoice | null>(null);
  const [chooserOpen, setChooserOpen] = useState(false);

  //read after mount, never in a lazy initialiser: localStorage does not exist while the page is
  //rendered on the server, and React 19 throws on the resulting mismatch rather than patching it up
  useEffect(() => {
    setChoice(readColumnChoice(window.localStorage.getItem(REJECTED_COLUMN_STORAGE_KEY)));
  }, []);

  function choose(id: string, enabled: boolean) {
    const next = toggleColumn(choice, id, enabled);
    setChoice(next);
    window.localStorage.setItem(REJECTED_COLUMN_STORAGE_KEY, JSON.stringify(next));
  }

  function resetColumns() {
    setChoice(null);
    window.localStorage.removeItem(REJECTED_COLUMN_STORAGE_KEY);
  }

  const columns = resolveColumns(choice);

  const load = useCallback(async (form: RejectedFilterForm, cursor: RejectedCursor | null) => {
    setLoading(true);
    try {
      const params = toQuery(form);
      params.set("limit", String(PAGE_SIZE));
      if (cursor) {
        params.set("cursorTs", cursor.rejectedAt);
        params.set("cursorId", cursor.id);
      }
      const res = await fetch(`/api/control/rejected?${params}`, { cache: "no-store" });
      const body = await res.json();
      if (!res.ok) {
        throw new Error(body?.error ?? `Request failed (${res.status})`);
      }
      const page = body.data as RejectedPage;
      setRows(page.rows);
      setNextCursor(page.nextCursor);
      //absent on a paged request, and the previous one stays on screen. That is the point: an
      //aggregate recomputed per page would visibly shift under a reader who only pressed Next
      if (page.summary) {
        setSummary(page.summary);
        setTotal(page.total ?? 0);
        setSampledOver(page.sampledOver ?? null);
      }
      setMatching(page.matching ?? null);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not read refused messages");
      setRows([]);
      setNextCursor(null);
    } finally {
      setLoading(false);
    }
  }, []);

  /**
   * The first load honours the query string.
   *
   * <p>Which is what makes a Delivery-check finding's `?reason=` link work, and what makes a filtered
   * view shareable at all. Read in an effect rather than a `useState` initialiser: `window` does not
   * exist while this renders on the server, and React 19 throws on the mismatch instead of patching
   * it up.
   */
  useEffect(() => {
    const initial = fromQuery(new URLSearchParams(window.location.search));
    setFilters(initial);
    void load(initial, null);
  }, [load]);

  function apply(next: RejectedFilterForm) {
    //a filter change resets paging. Keeping the cursor would ask for "the page after this timestamp"
    //under a different filter, which lands somewhere arbitrary in the new result set
    setFilters(next);
    setHistory([null]);
    const params = toQuery(next);
    //replaceState rather than router.push: no server round trip, no scroll jump, and no history
    //entry per search to press Back through
    window.history.replaceState(null, "", params.size ? `?${params}` : window.location.pathname);
    void load(next, null);
  }

  function forward() {
    if (!nextCursor) {
      return;
    }
    setHistory((h) => [...h, nextCursor]);
    void load(filters, nextCursor);
  }

  function back() {
    if (history.length < 2) {
      return;
    }
    const trimmed = history.slice(0, -1);
    setHistory(trimmed);
    void load(filters, trimmed[trimmed.length - 1]);
  }

  const page = history.length;
  const shownOf = filters.reason ? matching ?? total : total;

  return (
    <>
      <PageHeader title="Refused" description="Messages the gateway would not send, and why." />

      <Card>
        <CardHeader>
          <CardTitle>By reason</CardTitle>
          <CardDescription>
            Most were refused at the door and never became call records — nothing sent, nothing
            charged. Two reasons are different: <strong>never routed</strong> and{" "}
            <strong>dropped by a filter</strong> happen after the customer was told yes, so those
            carry a message id and their charge was refunded.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <p className="flex items-center gap-2 text-sm text-destructive">
              <TriangleAlert className="h-4 w-4 shrink-0" /> {error}
            </p>
          )}

          {summary && summary.length === 0 && !error && (
            <p className="text-sm text-muted-foreground">
              Nothing matches in this window. If you expected refusals, check that whitelisting is
              switched on at all: an unloaded whitelist allows everything by design.
            </p>
          )}

          {summary && summary.length > 0 && (
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
              {/* four across, so the whole reason breakdown is one row on a desktop rather than
                  two — comparing reasons is the point of it, and a wrapped grid makes the fourth
                  reason read as a footnote to the first three.
                  One line each, for the same reason: the hint under each count used to be four
                  times the height of the count, which pushed the numbers being compared apart. It
                  is still worth reading, just not all of it all of the time */}
              {summary.map((s) => (
                /* the info trigger is a SIBLING of the card's button, not a child of it: a button
                   inside a button is invalid, and a browser that hoists the inner one out breaks
                   both the layout and the click */
                <div
                  key={s.reason}
                  className={`flex min-w-0 items-center gap-1.5 rounded-lg border px-3 py-2 transition-colors ${
                    s.reason === filters.reason
                      ? "border-primary bg-primary/5"
                      : "border-border hover:bg-accent/50"
                  }`}
                >
                  <button
                    type="button"
                    /* through `apply`, the same path the filter bar uses, so the URL and the bar's
                       dropdown stay in step with the highlighted card */
                    onClick={() =>
                      apply({
                        ...filters,
                        reason: s.reason === filters.reason ? "" : s.reason,
                      })
                    }
                    aria-pressed={s.reason === filters.reason}
                    className="flex min-w-0 flex-1 items-center justify-between gap-2 text-left"
                  >
                    <span className="truncate text-sm font-medium">{reasonLabel(s.reason)}</span>
                    <span className="text-figure tabular-nums">
                      {count(s.count)}
                    </span>
                  </button>
                  {reasonHint(s.reason) && (
                    <InfoPopover label={reasonLabel(s.reason)}>{reasonHint(s.reason)}</InfoPopover>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <RejectedFilterBar value={filters} onApply={apply} busy={loading} />

      {!error && !rows.length && (
        <EmptyState>
          {loading ? "Loading…" : "No refusals match these filters in this period"}
        </EmptyState>
      )}

      {rows.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>
              <ShieldX className="mr-2 inline h-4 w-4 text-muted-foreground" />
              {count(rows.length)} shown of {count(shownOf)}
              {filters.reason && ` with this reason`}
              {sampledOver != null && !filters.reason && ` (the latest ${count(sampledOver)} summarised)`}
            </CardTitle>
            <CardDescription>
              Newest first. The message excerpt is the first 160 characters, kept unconditionally —
              unlike the body on a call record — because a content refusal cannot be diagnosed
              without seeing what was sent.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <TableInCard>
              <THead>
                <tr>
                  {columns.map((column) => (
                    <TH key={column.id} align={column.align === "right" ? "right" : undefined}>
                      {column.header}
                    </TH>
                  ))}
                </tr>
              </THead>
              <TBody>
                {rows.map((r) => (
                  <TR key={r.id} className="align-top">
                    {columns.map((column, i) => (
                      <TD key={column.id} primary={i === 0} align={column.align === "right" ? "right" : undefined} className="align-top">
                        <RejectedCell column={column} row={r} detailHref={detailHref} />
                      </TD>
                    ))}
                  </TR>
                ))}
              </TBody>
            </TableInCard>
            <TableFooter
              from={(page - 1) * PAGE_SIZE + 1}
              to={(page - 1) * PAGE_SIZE + rows.length}
              noun="refusals"
              onPrev={back}
              onNext={forward}
              prevDisabled={page < 2 || loading}
              nextDisabled={!nextCursor || loading}
            >
              <button
                type="button"
                onClick={() => setChooserOpen((v) => !v)}
                aria-expanded={chooserOpen}
                className="mr-1 inline-flex h-7 items-center gap-1.5 rounded-sm border border-border bg-card px-2.5 text-xs transition-colors hover:bg-muted"
              >
                <Columns3 className="h-3.5 w-3.5" />
                Columns
              </button>
            </TableFooter>

            {chooserOpen && (
              <ColumnChooser
                columns={REJECTED_COLUMNS}
                groups={REJECTED_COLUMN_GROUPS}
                enabled={new Set(columns.map((c) => c.id))}
                onToggle={choose}
                onReset={resetColumns}
              />
            )}
          </CardContent>
        </Card>
      )}

      <ExportsCard
        endpoint="/api/control/rejected/export"
        params={toQuery(filters)}
        description={
          <>
            Prepared in the background and kept for seven days. The CSV carries every column of every
            refusal whatever is chosen above, plus the plain-English reason and carrier code — it is
            read by people with no panel open, and two exports of the same filters must produce the
            same file.
          </>
        }
      />
    </>
  );
}
