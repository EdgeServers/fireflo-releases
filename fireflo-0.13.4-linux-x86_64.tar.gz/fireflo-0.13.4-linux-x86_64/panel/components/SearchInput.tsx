"use client";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";

/**
 * The small search box that sits in a card header above a table.
 *
 * <p>Lifted from the three places that had drifted apart by a width and a placeholder. The icon is
 * inside the field rather than beside it so the control reads as one thing at this size.
 *
 * <p>`aria-label` is required rather than optional: this renders no visible label, and "search" on a
 * page with two searchable cards tells a screen reader nothing about which list it filters.
 */
export function SearchInput({
  value,
  onChange,
  placeholder,
  ariaLabel,
  className = "w-56",
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  ariaLabel: string;
  className?: string;
}) {
  return (
    <span className="relative shrink-0">
      <Search className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
      <Input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        aria-label={ariaLabel}
        className={`h-8 pl-7 text-sm ${className}`}
      />
    </span>
  );
}
