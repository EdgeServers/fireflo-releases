"use client";
import { Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { SPEC_TAGS, CONVENTION_TAGS } from "@/lib/tlv-catalogue";
import {
  TLV_TYPES,
  canonicalTag,
  customTlvProblem,
  customTlvTag,
  duplicateCustomTlvTags,
  emptyCustomTlv,
  type CustomTlv,
} from "@/lib/custom-tlvs";

/**
 * Rows of tag / type / value, for the `custom_tlvs` field on the send API.
 *
 * <p>Shaped like `TlvPairsEditor` and deliberately not it. That editor is for the operator's
 * comma-joined `name_tag=value` strings, and two of its rules are wrong here — it refuses a comma in
 * a value, and it calls a token with no underscore a mistake. Both are correct for that format and
 * would produce warnings about perfectly good payloads in this one. The grammar this obeys lives in
 * `lib/custom-tlvs.ts`, which is the panel's copy of the gateway's own parser.
 *
 * <p><strong>Rows rather than a JSON box, because a JSON box could not be sent at all.</strong> The
 * playground passed the textarea's text through as a string, so the gateway received
 * `"custom_tlvs": "{\"0x1401\":\"…\"}"` — a string where an object belongs — and refused every
 * attempt with an error about a value the customer could see was valid JSON. Rows make that shape
 * unrepresentable rather than merely explained.
 *
 * <p>The type dropdown is the other half of the point: `Int8` is the only way to send an India DLT
 * template id as a number, and it appeared in no interface a customer could find.
 */
export function CustomTlvsEditor({
  rows,
  onChange,
}: {
  rows: readonly CustomTlv[];
  onChange: (rows: CustomTlv[]) => void;
}) {
  const duplicates = new Set(duplicateCustomTlvTags(rows));
  const replace = (i: number, patch: Partial<CustomTlv>) =>
    onChange(rows.map((r, n) => (n === i ? { ...r, ...patch } : r)));

  return (
    <div className="space-y-2">
      {rows.map((row, i) => {
        const problem = customTlvProblem(row);
        const tag = customTlvTag(row.tag);
        const duplicate = tag !== null && duplicates.has(tag);
        return (
          <div key={i} className="space-y-1">
            <div className="flex items-start gap-2">
              {/* min-w-0 is load-bearing: a flex child defaults to min-width:auto and refuses to
                  shrink below its content, which is what makes three fields on one line wrap */}
              <div className="min-w-0 flex-1">
                <Input
                  value={row.tag}
                  onChange={(e) => replace(i, { tag: e.target.value })}
                  list="custom-tlv-tags"
                  aria-label="TLV tag"
                  placeholder="0x1401"
                  className="font-mono"
                  spellCheck={false}
                />
              </div>
              <Select
                value={row.type}
                onChange={(e) => replace(i, { type: e.target.value as CustomTlv["type"] })}
                aria-label="Wire encoding"
                className="w-36 shrink-0 font-mono text-sm"
              >
                {TLV_TYPES.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </Select>
              <div className="min-w-0 flex-1">
                <Input
                  value={row.value}
                  onChange={(e) => replace(i, { value: e.target.value })}
                  aria-label="TLV value"
                  placeholder="what the carrier expects"
                  className="font-mono"
                  spellCheck={false}
                />
              </div>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={() => onChange(rows.filter((_, n) => n !== i))}
                aria-label="Remove this TLV"
                className="h-9 w-9 shrink-0"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            {problem && <p className="text-xs text-warning">{problem}</p>}
            {duplicate && !problem && (
              <p className="text-xs text-warning">
                Another row also names {canonicalTag(tag!)}. The gateway refuses the whole request
                rather than choosing one.
              </p>
            )}
          </div>
        );
      })}

      {/* one list for every row: the catalogue's names are a hint about which tag to type, not a
          closed set -- this ingress accepts any tag at all and a vendor's own number is common */}
      <datalist id="custom-tlv-tags">
        {[...SPEC_TAGS, ...CONVENTION_TAGS].map((d) => (
          <option key={d.tag} value={`${d.name}_${canonicalTag(d.tag)}`}>
            {d.label ?? d.name}
          </option>
        ))}
      </datalist>

      <Button
        type="button"
        variant="outline"
        size="sm"
        onClick={() => onChange([...rows, emptyCustomTlv()])}
        className="gap-1.5"
      >
        <Plus className="h-3.5 w-3.5" />
        Add a TLV
      </Button>
    </div>
  );
}
