"use client";
import { Fragment, useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { BackLink } from "./BackLink";
import { PageHeader } from "@/components/ui/page-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import type { CdrRow, CustomerEvent } from "@/lib/cdr-queries";
import { buildCustomerExchange, type CustomerExchangeEvent } from "@/lib/customer-exchange";
import { DisclosureSection } from "./DisclosureSection";
import { CDR_COLUMNS, ingressServer } from "@/lib/cdr-columns";
import type { MessageReceipt, MessageRecord } from "@/lib/cdr-request";
import { dlrStateCode, dlrStateLabel, FINAL_STATE_LABELS, labelFor } from "@/lib/labels";
import { buildSmppExchange } from "@/lib/smpp-exchange";
import { elapsed, money } from "@/lib/format";
import {
  decodeReceiptRequest,
  RECEIPT_KIND_LABELS,
  receiptRequestHex,
} from "@/lib/receipt-request";
import { resolveTlv, tlvTag, type TlvDefinition } from "@/lib/tlv-catalogue";
import { tlvProvenance, verdictSentence, type TlvVerdict } from "@/lib/tlv-provenance";
import { TlvSourceChip } from "./TlvTokenInput";
import { useTlvDefinitions } from "./useTlvDefinitions";
import { formatTimestamp } from "@/lib/datetime";

/**
 * One message, end to end.
 *
 * <p>The only page in this panel that shows more than one row of `cdr_submit` at a time on purpose:
 * a multipart message that was retried is several rows, and every summary elsewhere collapses them.
 *
 * <p><strong>The money figures are sourced to match the aggregates exactly</strong>, or this page
 * would quietly contradict Revenue for the same message. Price comes from the first attempt of part
 * one, which is the row every aggregate filters to. Cost is summed over <em>all</em> part-one rows
 * including retries, because a message retried across two vendors genuinely cost twice.
 */
export function CdrDetailClient({ gatewayMsgId }: { gatewayMsgId: string }) {
  const [record, setRecord] = useState<MessageRecord | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [rawOpen, setRawOpen] = useState(false);
  //so a tag the operator named resolves to that name here too. The hook degrades to an empty list
  //rather than an error, which is why a page about a message can afford to ask for it
  const { definitions: tlvDefinitions } = useTlvDefinitions();

  const load = useCallback(async () => {
    try {
      const res = await fetch(
        `/api/control/cdrs/message/${encodeURIComponent(gatewayMsgId)}`,
        { cache: "no-store" }
      );
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      setRecord(json.data as MessageRecord);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setLoading(false);
    }
  }, [gatewayMsgId]);

  useEffect(() => {
    void load();
  }, [load]);

  if (loading) {
    return <p className="text-sm text-muted-foreground">Loading…</p>;
  }
  if (error || !record) {
    return (
      <>
        <BackLink href="/cp/cdrs">All messages</BackLink>
        <Card>
          <CardContent className="py-4 text-sm text-destructive">{error || "Not found."}</CardContent>
        </Card>
      </>
    );
  }

  const { attempts, receipts, more, progressRecorded, ruleNames, askedFor, segmentNo,
    events, eventsRecorded, responsesRecordable } = record;
  //the id the record is actually filed under, which is what every other id on this page belongs to.
  //Falls back to the URL's for a gateway that predates the resolution
  const messageId = record.gatewayMsgId || gatewayMsgId;
  //only worth saying when the two differ. Asking by the message's own id resolves to segment 1 of
  //its own list, which is true and not worth a sentence
  const viaSegment = askedFor && askedFor !== messageId ? segmentNo : null;
  const first = attempts.find((a) => a.partNo === 1 && a.retryCount === 0) ?? attempts[0];
  const partCount = first.partCount;
  const partOne = attempts.filter((a) => a.partNo === 1);
  const cost = sum(partOne.map((a) => a.cost));
  const price = first.price;
  const vendors = [...new Set(attempts.map((a) => a.vendor).filter(Boolean))];
  //outcomes only, for both. A progress receipt is not the message's state and two of them are not a
  //duplicate — the badge and the warning below both used to be computed over every receipt, which
  //was harmless while cdr_final was the only table and is not any more
  const outcomes = receipts.filter((r) => r.kind === "outcome");
  const earliest = outcomes.find((r) => r.partNo === 1);
  const duplicated = outcomes.filter((r) => r.partNo === 1).length > 1;
  const progress = receipts.filter((r) => r.kind === "progress");
  const exchange = buildSmppExchange(attempts, receipts);

  return (
    <>
      <PageHeader
        title={
          <span className="flex flex-wrap items-center gap-3">
            <span className="font-mono">{messageId}</span>
            {earliest ? (
              <Badge variant={earliest.finalState === "DELIVERED" ? "success" : "destructive"}>
                {labelFor(FINAL_STATE_LABELS, earliest.finalState)}
              </Badge>
            ) : (
              <Badge variant="outline">Awaiting receipt</Badge>
            )}
          </span>
        }
        description={
          <span suppressHydrationWarning>
            Submitted {formatTimestamp(first.submittedAt)} ·{" "}
            {partCount} part{partCount === 1 ? "" : "s"} · {attempts.length} attempt
            {attempts.length === 1 ? "" : "s"} · {receipts.length} receipt
            {receipts.length === 1 ? "" : "s"}
            {progress.length > 0 && `, ${progress.length} of them progress`}
          </span>
        }
        back={<BackLink href="/cp/cdrs">All messages</BackLink>}
      />

      {(askedFor && askedFor !== messageId) || more || duplicated ? (
        <div className="space-y-2 text-sm">
          {askedFor && askedFor !== messageId && (
            <p>
              You asked for <span className="font-mono text-sm">{askedFor}</span>, which is{" "}
              {viaSegment ? `part ${viaSegment} of` : "one of the segments of"} this message. It was
              sent as several SMPP messages and acknowledged once for each, so the gateway issued a
              separate id per part — all of them find this record.
            </p>
          )}
          {more && (
            <p className="text-warning">
              Only the first 500 attempts are listed. With <code>maxRetries</code> at 0 the gateway
              retries indefinitely, so there may be many more.
            </p>
          )}
          {duplicated && (
            <p className="text-warning">
              More than one receipt arrived for part one. <code>cdr_final</code> has no uniqueness
              constraint, so this is allowed; every other view shows only the earliest, and the
              exchange below shows them all.
            </p>
          )}
        </div>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle>Route</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-x-8 gap-y-2 text-sm sm:grid-cols-2 lg:grid-cols-3">
          <Fact label="Account" value={first.accountId} />
          <Fact label="System ID" value={first.systemId} />
          <Fact label="Product" value={first.product} />
          <Fact label="Ingress" value={first.ingress} />
          <Fact label="Ingress server" value={ingressServer(first)} />
          <Fact
            label="Vendor"
            value={
              vendors.length > 1
                ? `${vendors.length} vendors — see the timeline`
                : vendors[0] ?? null
            }
          />
          <Fact label="From" value={first.sourceAddr} />
          <Fact label="To" value={first.destAddr} />
          <Fact
            label="Network"
            value={first.mcc == null && first.mnc == null ? null : `${first.mcc ?? "?"} / ${first.mnc ?? "?"}`}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Money</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="grid gap-x-8 gap-y-2 sm:grid-cols-3">
            <Fact
              label="Billed"
              value={price == null ? null : `${money(price, first.currency ?? "")}`}
              detail={
                first.priceRate == null
                  ? undefined
                  : `${rate(first.priceRate)} × ${first.billedUnits ?? "?"} units`
              }
            />
            <Fact
              label="Cost"
              value={cost == null ? null : money(cost, first.currency ?? "")}
              detail={
                first.costRate == null
                  ? undefined
                  : `${rate(first.costRate)} × ${first.costUnits ?? "?"} units`
                    + (partOne.length > 1 ? `, summed over ${partOne.length} attempts` : "")
              }
            />
            <Fact
              label="Margin"
              value={first.margin == null ? null : money(first.margin, first.currency ?? "")}
              detail={first.marginPct == null ? first.marginStatus ?? undefined : `${first.marginPct.toFixed(2)}%`}
            />
          </div>
          <div className="flex flex-wrap gap-x-8 gap-y-1 text-sm text-muted-foreground">
            <span>
              Priced by {ruleNames[first.priceRuleId ?? ""] ?? first.priceRuleId ?? "no rule"}
            </span>
            <span>Costed by {ruleNames[first.costRuleId ?? ""] ?? first.costRuleId ?? "no rule"}</span>
          </div>
          {partCount > 1 && (
            <p className="text-sm text-muted-foreground">
              Only part one carries money. Segments two onward are written <code>UNRATED</code> with
              no amounts, so the blank cells below are correct rather than missing.
            </p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Vendor exchange</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <p className="text-sm text-muted-foreground">
            The leg between this gateway and the <strong>vendor</strong>. Every <code>submit_sm</code>
            this message caused, the vendor&apos;s own answer to each,
            and every <code>deliver_sm</code> receipt that followed — in the order they happened,
            not grouped by table. These are call records the gateway derived from the exchange, not
            captured wire bytes; there is no <code>deliver_sm_resp</code> event because nothing in
            this system records one.
          </p>
          <TableInCard className="tabular-nums">
            <THead>
              <tr>
                <TH>Part</TH>
                <TH>PDU</TH>
                <TH>Attempt</TH>
                <TH>Vendor</TH>
                <TH>Rule</TH>
                <TH>Operator ID</TH>
                <TH>Status</TH>
                <TH>At</TH>
              </tr>
            </THead>
            <TBody>
              {exchange.map((e, i) => (
                <TR key={i}>
                  <TD>{e.partNo}</TD>
                  <TD>
                    <span className="font-mono text-sm">{e.pdu}</span>
                    {e.terminal && <Badge className="ml-2">closed</Badge>}
                  </TD>
                  <TD>
                    {e.attempt ? e.attempt.retryCount : "—"}
                  </TD>
                  <TD>{e.vendor ?? "—"}</TD>
                  {/* which rule chose this vendor, per ATTEMPT -- a re-route shows a second row
                      naming a different rule. Absent column and unrecorded row are different
                      answers and are never collapsed: neither of them means "no rule" */}
                  <TD className="whitespace-nowrap">
                    {!("routeRule" in e) ? (
                      <span className="text-muted-foreground" title="this gateway is older than V1.47.0">—</span>
                    ) : e.routeRule == null ? (
                      <span className="text-muted-foreground" title="written before the column existed, or no rule matched">
                        not recorded
                      </span>
                    ) : (
                      <code className="text-xs">{e.routeRule}</code>
                    )}
                  </TD>
                  <TD className="font-mono">{e.operatorMsgId ?? "—"}</TD>
                  <TD>{e.status ?? "—"}</TD>
                  <TD className="whitespace-nowrap" suppressHydrationWarning>
                    {formatTimestamp(e.at)}
                  </TD>
                </TR>
              ))}
            </TBody>
          </TableInCard>
          {attempts.length > 0 && !attempts.some((a) => "submitStatus" in a) && (
            <p className="text-xs text-muted-foreground">
              This gateway predates the version that records the vendor&apos;s <code>submit_sm_resp</code>{" "}
              status on every attempt, so a retry that was not the last one shows no status here —
              only that it happened.
            </p>
          )}
        </CardContent>
      </Card>

      {/* the other leg. Rendered only when the gateway can record it: a panel is routinely pointed
          at a gateway older than itself, and an empty card would read as "nothing happened" rather
          than "this build cannot tell you" */}
      {/* no longer gated on eventsRecorded: the receipt's CONTENT comes from cdr_final, which is a
          billing record and always written, so this card now says something on a gateway too old to
          have cdr_event at all -- and on every message sent before events were switched on */}
      <CustomerExchange
        events={events}
        first={first}
        receipts={receipts}
        eventsRecorded={eventsRecorded}
        responsesRecordable={responsesRecordable}
      />

      <Receipts
        receipts={receipts}
        submittedAt={first.submittedAt}
        registeredDelivery={first.registeredDelivery}
        progressRecorded={progressRecorded}
        fallbackVendor={vendors.length === 1 ? vendors[0] ?? null : null}
      />

      {/* the whole message, where the list shows its first 160 characters. Null and empty are
          different answers and the card says which: nothing recorded it, or it said nothing */}
      <Card>
        <CardContent className="space-y-2 py-4">
          <CardTitle>Message</CardTitle>
          {first.body
            ? <p className="whitespace-pre-wrap break-words text-sm">{first.body}</p>
            : (
              <p className="text-xs text-muted-foreground">
                No message text was recorded. The gateway keeps it only when
                <code className="mx-1 text-xs">smsg.cdr.body</code>
                is set to <code className="text-xs">excerpt</code> or
                <code className="mx-1 text-xs">full</code>; it is off by default, and a message sent
                before it was switched on can never have it.
              </p>
            )}
        </CardContent>
      </Card>

      <Tlvs
        received={first.tlvsReceived ?? null}
        resolved={first.tlvs ?? null}
        sent={first.tlvsSent ?? null}
        vendor={vendors[0] ?? null}
        definitions={tlvDefinitions}
      />

      <DisclosureSection
        title="Raw record"
        set={0}
        open={rawOpen}
        onToggle={() => setRawOpen((v) => !v)}
        note="Every column of the first attempt, as stored."
      >
        <dl className="grid gap-x-8 gap-y-1 text-sm sm:grid-cols-2 lg:grid-cols-3">
          {CDR_COLUMNS.map((column) => (
            <div key={column.id} className="flex min-w-0 justify-between gap-4 border-b border-border/40 py-1">
              <dt className="text-muted-foreground">{column.header}</dt>
              <dd className="font-mono">{display(column.from(first))}</dd>
            </div>
          ))}
        </dl>
      </DisclosureSection>

      <p className="text-sm text-muted-foreground">
        The message itself is not here, and neither is most of what surrounded it: a call record
        stores no body, no external id, no metadata or attributes, none of the ten user fields, and
        neither the expiry nor the deferred-delivery time. The in-flight state is not recorded
        either — only the outcome. Those live on the message while it is being handled and are gone
        once it is.
      </p>
    </>
  );
}

/**
 * Every receipt for this message, at every level, in the order they arrived.
 *
 * <p>Two tables merged into one list. `cdr_final` holds outcomes — one per part, in principle — and
 * `cdr_interim` holds the progress reports that precede them: ACCEPTD when the carrier takes the
 * message, BUFFRED while it retries. They are stored apart so that every aggregate in this panel
 * reading `cdr_final` still gets the outcome rather than the first sign of life; this is the one page
 * that puts them back together, because a person diagnosing a message wants the whole sequence.
 *
 * <p><strong>The row that closed the message is marked</strong>, which is the question this card
 * exists to answer without SQL: several receipts arrived, they may disagree, and exactly one of them
 * decided what the invoice says.
 *
 * <p>Above the table, what the customer asked to be told. That is what makes "why did my system not
 * get a receipt?" answerable from the record rather than from a gateway log — and it is a genuine
 * answer in both directions, because the gateway records every receipt whether or not it forwards
 * one.
 */
function Receipts({
  receipts,
  submittedAt,
  registeredDelivery,
  progressRecorded,
  fallbackVendor,
}: {
  receipts: MessageReceipt[];
  submittedAt: string;
  /** Absent against a gateway before V1.33.0; null when the row predates the column. */
  registeredDelivery?: number | null;
  progressRecorded: boolean;
  /** `cdr_final` has no vendor column, so an outcome borrows the vendor when there was only one. */
  fallbackVendor: string | null;
}) {
  const submitted = Date.parse(submittedAt);
  //the earliest outcome per part: the one every other view in this panel shows, and the one the
  //price was settled against. A second outcome for the same part is visible below it and marked as
  //not counting, rather than hidden
  const closing = new Set<string>();
  for (const part of new Set(receipts.map((r) => r.partNo))) {
    const first = receipts.find((r) => r.partNo === part && r.kind === "outcome");
    if (first) {
      closing.add(first.id);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Delivery receipts</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 text-sm">
        <ReceiptRequestFact raw={registeredDelivery} />

        {receipts.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No receipt has arrived for this message.
          </p>
        ) : (
          <TableInCard className="tabular-nums">
            <THead>
              <tr>
                <TH>Part</TH>
                <TH>After</TH>
                <TH>At</TH>
                <TH>State</TH>
                <TH>Error</TH>
                <TH>Vendor</TH>
                <TH>Sent on</TH>
                <TH>Operator ID</TH>
              </tr>
            </THead>
            <TBody>
              {receipts.map((r) => (
                <TR key={`${r.kind}-${r.id}`} className="align-top">
                  <TD className="align-top">{r.partNo}</TD>
                  <TD className="align-top whitespace-nowrap">
                    {elapsed(
                      Number.isFinite(submitted)
                        ? (Date.parse(r.receivedAt) - submitted) / 1000
                        : null
                    )}
                  </TD>
                  <TD className="align-top whitespace-nowrap" suppressHydrationWarning>
                    {formatTimestamp(r.receivedAt)}
                  </TD>
                  <TD className="align-top">
                    <span className="font-medium whitespace-nowrap">
                      {dlrStateCode(r.dlrState)}
                    </span>
                    <span className="block text-xs text-muted-foreground">
                      {dlrStateLabel(r.dlrState)}
                    </span>
                    {closing.has(r.id) ? (
                      <Badge variant="outline" className="mt-1 text-xs">
                        Closed the message
                        {r.finalState ? ` · ${labelFor(FINAL_STATE_LABELS, r.finalState)}` : ""}
                      </Badge>
                    ) : r.kind === "outcome" ? (
                      //a second cdr_final row. Allowed by the schema, counted by nothing
                      <span className="mt-1 block text-xs text-warning">
                        A later outcome, not the one that was billed
                      </span>
                    ) : (
                      <span className="mt-1 block text-xs text-muted-foreground">
                        Progress — the message stayed open
                      </span>
                    )}
                  </TD>
                  <TD className="align-top">
                    <span className="whitespace-nowrap">{r.errCode ?? "—"}</span>
                    <CarrierCode terminal={r.kind === "outcome"} vendorErrCode={r.vendorErrCode} errCode={r.errCode} />
                  </TD>
                  <TD className="align-top">{r.vendor ?? fallbackVendor ?? "—"}</TD>
                  <TD className="align-top">
                    <Forwarded forwarded={r.forwarded} kind={r.kind} />
                  </TD>
                  <TD className="align-top font-mono">{r.operatorMsgId ?? "—"}</TD>
                </TR>
              ))}
            </TBody>
          </TableInCard>
        )}

        {!progressRecorded && (
          <p className="text-sm text-muted-foreground">
            This gateway is not recording progress receipts — <code>cdr_interim</code> does not
            exist, which means it has not applied V1.33.0. Only outcomes are listed above, and an
            ACCEPTD or BUFFRED for this message would not appear even if one arrived.
          </p>
        )}
      </CardContent>
    </Card>
  );
}

/** What the customer asked to be told, decoded from the octet they sent. */
function ReceiptRequestFact({ raw }: { raw?: number | null }) {
  if (raw === undefined) {
    return (
      <p className="text-sm text-muted-foreground">
        What the customer asked for is not recorded on this gateway.{" "}
        <code>cdr_submit.registered_delivery</code> arrives in V1.33.0, and until then the record
        cannot say whether a receipt was owed.
      </p>
    );
  }
  if (raw === null) {
    //deliberately not rendered as 0x00. Zero is a claim about the customer; this is a gap in ours
    return (
      <p className="text-sm text-muted-foreground">
        What the customer asked for was not recorded for this message — it predates the column, or
        arrived on an ingress that has no such field. That is not the same as asking for nothing.
      </p>
    );
  }

  const request = decodeReceiptRequest(raw);
  return (
    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
      <span className="text-muted-foreground">The customer asked for</span>
      <Badge variant={request.kind === "NONE" ? "outline" : "default"}>
        {RECEIPT_KIND_LABELS[request.kind]}
      </Badge>
      {request.interim && <Badge variant="default">Progress too</Badge>}
      {request.smeAck && (
        <span className="text-muted-foreground" title="A request to the handset, not to us">
          and a handset acknowledgement, which is not ours to give
        </span>
      )}
      <code className="text-muted-foreground">
        registered_delivery {receiptRequestHex(raw)}
      </code>
    </div>
  );
}

/** Whether one receipt reached the customer, and why not when it did not. */
/**
 * What the carrier said, under what we turned it into.
 *
 * <p>Subordinate to the translated code rather than a column of its own: the two are only useful
 * read together, and this table already scrolls sideways. A seventh column would put them three
 * cells apart and cost the width on every row, for a value that is empty on most of them.
 *
 * <p>Renders nothing at all on a progress receipt. `cdr_interim` has no `vendor_err_code` column,
 * so "not recorded" there would describe the schema rather than the receipt, and would read as a
 * gap in the data instead of a fact about where progress receipts are stored.
 */
function CarrierCode(
  { terminal, vendorErrCode, errCode }:
  { terminal: boolean; vendorErrCode?: string | null; errCode: string | null }
) {
  if (!terminal || vendorErrCode === undefined) {
    return null;
  }
  if (vendorErrCode === null) {
    //not "—", and not a repeat of errCode: the gateway's own column comment is explicit that NULL
    //means the carrier reported none OR the row predates the column, and never "same as err_code"
    return <span className="block text-xs text-muted-foreground">not recorded</span>;
  }
  //`translated` is the whole point of the pair -- it is the one case where an operator can see
  //their mapping took effect. Equal codes mean nothing was translated, so they are not marked
  const translated = vendorErrCode !== errCode;
  return (
    <span
      className={`block whitespace-nowrap text-xs ${
        translated ? "text-primary" : "text-muted-foreground"
      }`}
    >
      carrier {vendorErrCode}
      {translated ? " · mapped" : ""}
    </span>
  );
}

function Forwarded({ forwarded, kind }: { forwarded: boolean | null; kind: "outcome" | "progress" }) {
  if (forwarded === null) {
    return <span className="text-muted-foreground" title="the request was not recorded">·</span>;
  }
  if (forwarded) {
    //the level a receiver sees on the webhook and in the esm_class, so it can be matched against
    //what they logged at their end
    return <span>Yes · level {kind === "outcome" ? 2 : 1}</span>;
  }
  return <span className="text-muted-foreground">Held — not asked for</span>;
}

/**
 * What happened to each optional parameter, from arrival to the wire.
 *
 * <p>Three columns, three points on one pipeline. The gateway resolves a union of the request, the
 * account's defaults, the approved sender ID and the content template; then the vendor fills gaps
 * from its own defaults and drops anything it has not registered. Reading that as three JSON blobs
 * is what this card used to ask of an operator, under a footnote conceding that a tag shown "did
 * not necessarily reach the wire". The verdict column is that footnote, answered per tag.
 *
 * <p>Shown raw when the JSON does not parse — a record that cannot be read is still evidence, and
 * throwing here would take the page down over a diagnostic column.
 */
function Tlvs({
  received,
  resolved,
  sent,
  vendor,
  definitions,
}: {
  received: string | null;
  resolved: string | null;
  sent: string | null;
  vendor: string | null;
  definitions: readonly TlvDefinition[];
}) {
  const { rows, sentRecorded, hasFindings } = tlvProvenance(received, resolved, sent);

  if (!rows.length) {
    //nothing at any stage. The unparseable case still has something to show
    const unreadable = [received, resolved, sent].filter(Boolean) as string[];
    if (!unreadable.length) {
      return null;
    }
    return (
      <Card>
        <CardHeader>
          <CardTitle>TLVs</CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="overflow-x-auto rounded bg-muted p-3 text-sm">{unreadable.join("\n")}</pre>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>TLVs</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 text-sm">
        <TableInCard>
          <THead>
            <tr>
              <TH>Tag</TH>
              <TH>Name</TH>
              <TH>Received</TH>
              <TH>Resolved</TH>
              <TH>Sent</TH>
              <TH>What happened</TH>
            </tr>
          </THead>
          <TBody>
            {rows.map((row) => {
              //operator definitions passed in, so a tag the operator named resolves here too --
              //it used to render as a dash even though useTlvDefinitions exists to supply them
              const named = resolveTlv(tlvTag(row.tag), definitions);
              return (
                <TR key={row.tag} className="align-top">
                  <TD className="align-top font-mono whitespace-nowrap">
                    {row.tag}
                    <span className="block text-xs text-muted-foreground tabular-nums">
                      {decimalTag(row.tag)}
                    </span>
                  </TD>
                  <TD className="align-top">
                    {named ? (
                      <span className="flex flex-wrap items-center gap-1.5">
                        {named.label}
                        <TlvSourceChip provenance={named.provenance} />
                      </span>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TD>
                  <Value value={row.received} />
                  <Value value={row.resolved} />
                  <Value value={row.sent} unknown={!sentRecorded} />
                  <TD className="align-top">
                    <TlvVerdictLabel verdict={row.verdict} />
                    <span className="block text-xs text-muted-foreground">
                      {verdictSentence(row, vendor)}
                    </span>
                  </TD>
                </TR>
              );
            })}
          </TBody>
        </TableInCard>

        {!sentRecorded && (
          <p className="text-sm text-muted-foreground">
            What reached the wire was not recorded for this message, so the Sent column is blank and
            no verdict claims anything about it. That is the case for a message that never reached a
            vendor, for a non-SMPP vendor, and for anything submitted before the gateway began
            recording it.
          </p>
        )}
        {hasFindings && vendor && (
          <p className="text-sm text-warning">
            A tag on this message did not go out as it stood. Check{" "}
            <Link href="/cp/vendors" className="text-primary hover:underline">{vendor}</Link>
            &rsquo;s <em>TLVs to send</em> — only tags listed there reach the carrier.
          </p>
        )}
      </CardContent>
    </Card>
  );
}

/** One stage's value. Blank and unknown look different on purpose. */
function Value({ value, unknown }: { value: string | null; unknown?: boolean }) {
  return (
    <TD className="align-top font-mono break-all">
      {unknown ? (
        <span className="text-muted-foreground" title="not recorded">·</span>
      ) : value === null ? (
        <span className="text-muted-foreground">—</span>
      ) : (
        value
      )}
    </TD>
  );
}

/** The verdict as a word, coloured only where it needs attention. */
function TlvVerdictLabel({ verdict }: { verdict: TlvVerdict }) {
  const tone =
    verdict === "dropped" || verdict === "vendor-overrode"
      ? "text-warning"
      : "text-foreground";
  const text: Record<TlvVerdict, string> = {
    unchanged: "Unchanged",
    replaced: "Replaced",
    added: "Added",
    dropped: "Dropped",
    "vendor-default": "Vendor default",
    "vendor-overrode": "Vendor overrode",
  };
  return <span className={`font-medium ${tone}`}>{text[verdict]}</span>;
}

/** `0x1400` and `1400` are both written by different paths; only the first is unambiguous. */
function decimalTag(tag: string): string {
  const n = tag.startsWith("0x") || tag.startsWith("0X") ? Number(tag) : Number.parseInt(tag, 10);
  return Number.isFinite(n) ? String(n) : "—";
}

function Fact({ label, value, detail }: { label: string; value: string | number | null; detail?: string }) {
  return (
    <div className="flex min-w-0 justify-between gap-4 border-b border-border/40 py-1">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-right">
        {value == null || value === "" ? <span className="text-muted-foreground">—</span> : value}
        {detail && <span className="block text-sm text-muted-foreground">{detail}</span>}
      </span>
    </div>
  );
}

/** null when every value was null — "we have no figure" rather than a total of zero. */
function sum(values: (number | null)[]): number | null {
  const present = values.filter((v): v is number => v != null);
  return present.length ? present.reduce((a, b) => a + b, 0) : null;
}

/** A per-message rate, so all four places are kept before trimming: 0.0450 reads 0.045, not 0.05. */
function rate(value: number): string {
  return money(value, "", 4);
}

function display(value: unknown): string {
  return value == null || value === "" ? "—" : String(value);
}

/**
 * What the gateway told this customer, or why it did not.
 *
 * <p>The card above is the vendor leg. This is the one the customer actually experiences, and it is
 * the half that had no record at all until `cdr_event`: a receipt withheld because their
 * `registered_delivery` asked for less than they meant, one held because they were not connected, or
 * a callback that failed, each left nothing behind but a log line.
 *
 * <p><strong>An empty table here is a real answer, not a missing one.</strong> `smsg.cdr.events`
 * defaults to `off`, and its `problems` mode deliberately records nothing when nothing goes wrong —
 * so "no events" most often means the receipt went out normally. The copy says so, because a reader
 * who takes it for missing data will go looking for a fault that is not there.
 */
function CustomerExchange({ events, first, receipts, eventsRecorded, responsesRecordable }: {
  events: CustomerEvent[];
  first: CdrRow | undefined;
  receipts: MessageReceipt[];
  /** Whether this gateway HAS a cdr_event table -- not whether it wrote to it. */
  eventsRecorded: boolean;
  /** Whether it has the V1.48.0 response columns -- again, not whether it filled them. */
  responsesRecordable: boolean;
}) {
  const exchange = buildCustomerExchange(first ?? null, events, receipts);
  //by row index rather than by id: these rows are derived and have none, and the sequence is stable
  //for a given record
  const [openResponses, setOpenResponses] = useState<ReadonlySet<number>>(new Set());
  const toggleResponse = (index: number) => setOpenResponses((open) => {
    const next = new Set(open);
    if (!next.delete(index)) {
      next.add(index);
    }
    return next;
  });
  return (
    <Card>
      <CardHeader>
        <CardTitle>Customer exchange</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        <p className="text-sm text-muted-foreground">
          The leg between this gateway and the <strong>customer</strong>: what they sent us, what we
          answered, the receipt we sent back or the reason we did not, and every attempt at their
          callback. Derived from call records like the vendor exchange above, not captured bytes.
          Callback addresses are stored without their query string, so an API key in a{" "}
          <code>dlr-url</code> is never kept here — and that has no setting. What an endpoint{" "}
          <em>answered</em> does: it is kept only where the gateway has{" "}
          <code>smsg.cdr.events.response</code> switched on, and then as a bounded excerpt plus a
          fixed list of headers, never the whole response.
        </p>
        {exchange.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            Nothing recorded. On the default <code>problems</code> setting that usually means the
            receipt went out normally — events are written when something does not go as asked.
          </p>
        ) : (
          <TableInCard className="tabular-nums">
            <THead>
              <tr>
                <TH>At</TH>
                <TH />
                <TH>PDU</TH>
                <TH>Try</TH>
                <TH>Status</TH>
                <TH>What we sent them</TH>
                <TH>Endpoint</TH>
                <TH>Response</TH>
                <TH>Detail</TH>
              </tr>
            </THead>
            <TBody>
              {exchange.map((e, i) => (
                <Fragment key={`${e.at}-${i}`}>
                <TR>
                  <TD className="whitespace-nowrap">{stampOf(e.at)}</TD>
                  {/* the arrow is the fastest way to read a two-party exchange: which way did this
                      one go. `in` is the customer talking to us */}
                  <TD className="text-muted-foreground">
                    {e.direction === "in" ? "\u2192" : "\u2190"}
                  </TD>
                  <TD className="whitespace-nowrap">
                    <code>{e.pdu}</code>
                  </TD>
                  {/* the retry sequence IS the answer for a callback: at the default two-minute
                      interval four attempts span most of an hour, and "it worked on the fourth
                      try" is a different fault from "it worked" */}
                  <TD className="whitespace-nowrap">
                    {e.attempt === null ? (
                      <span className="text-muted-foreground">{"\u00b7"}</span>
                    ) : (
                      <span>
                        #{e.attempt}
                        {e.durationMs !== null && (
                          <span className="ml-1.5 text-xs text-muted-foreground">
                            {e.durationMs} ms
                          </span>
                        )}
                      </span>
                    )}
                  </TD>
                  <TD>
                    {e.status === null ? (
                      <span className="text-muted-foreground" title="this event has no status">
                        {"\u00b7"}
                      </span>
                    ) : (
                      e.status
                    )}
                  </TD>
                  {/* the customer's own copy of the receipt, which is NOT the vendor's row above:
                      reversed addresses, our message id, and the verdict re-rendered -- a vendor
                      FAILED and a vendor UNDELIV both reach the customer as UNDELIV */}
                  <TD className="whitespace-nowrap">
                    {e.receipt ? (
                      <span className="space-x-1.5">
                        <code>{e.receipt.stat}</code>
                        {e.receipt.err && <span>err {e.receipt.err}</span>}
                        {/* the same component the vendor card uses: beside, never instead of.
                            It keeps the undefined/null distinction an inline copy would lose */}
                        <CarrierCode
                          terminal={e.receipt.terminal}
                          vendorErrCode={e.receipt.vendorErr}
                          errCode={e.receipt.err}
                        />
                        {!e.receipt.terminal && (
                          <span className="text-muted-foreground">{"\u00b7"} progress</span>
                        )}
                        <span className="block text-xs text-muted-foreground">
                          {e.receipt.from ?? "?"} {"\u2192"} {e.receipt.to ?? "?"} {"\u00b7"}{" "}
                          <code>{e.receipt.messageId}</code>
                        </span>
                      </span>
                    ) : (
                      <span className="text-muted-foreground">{"\u00b7"}</span>
                    )}
                  </TD>
                  <TD className="whitespace-nowrap">
                    {e.endpoint ? (
                      //said on the cell rather than only in the paragraph above: somebody looking
                      //for the `?key=` they registered needs to know the panel did not lose it
                      <span title="the gateway stores the query string nowhere -- a dlr-url carries an API key, so only scheme, host and path are kept">
                        {e.endpoint}
                      </span>
                    ) : (
                      <span className="text-muted-foreground">{"\u00b7"}</span>
                    )}
                  </TD>
                  <TD className="whitespace-nowrap">
                    <ResponseCell
                      event={e}
                      recordable={responsesRecordable}
                      open={openResponses.has(i)}
                      onToggle={() => toggleResponse(i)}
                    />
                  </TD>
                  <TD className="text-muted-foreground">
                    {/* an unrecorded delivery is a real answer and must not read as a failure */}
                    {e.delivery === "unrecorded" && (
                      <span
                        className="mr-1.5 rounded bg-muted px-1 py-0.5 text-xs"
                        title={eventsRecorded
                          ? "smsg.cdr.events did not record this one -- `problems` writes nothing when nothing goes wrong"
                          : "this gateway is older than cdr_event, so it cannot record delivery at all"}
                      >
                        {eventsRecorded ? "not recorded" : "not available"}
                      </span>
                    )}
                    {e.delivery === "sent" && (
                      <span className="mr-1.5 text-xs text-primary">sent</span>
                    )}
                    {e.detail ?? ""}
                  </TD>
                </TR>
                {openResponses.has(i) && (
                  <TR className="bg-muted/30">
                    <TD colSpan={9}>
                      <ResponseBody event={e} />
                    </TD>
                  </TR>
                )}
                </Fragment>
              ))}
            </TBody>
          </TableInCard>
        )}
      </CardContent>
    </Card>
  );
}

/**
 * Whether there is a response to read, and if not, whose problem that is.
 *
 * <p>Five states and they lead to five different next steps, which is the whole reason they are not
 * collapsed into a blank cell: an operator told to switch a setting on cannot do it if their gateway
 * has no such setting, and one told nothing at all goes looking for a fault in their own endpoint.
 */
function responseState(
  event: CustomerExchangeEvent,
  recordable: boolean
): "none" | "unavailable" | "unanswered" | "off" | "empty" | "captured" {
  if (event.pdu !== "callback") {
    return "none";
  }
  //undefined means the column was never asked for, which only happens when it does not exist
  if (!recordable || event.responseExcerpt === undefined) {
    return "unavailable";
  }
  if (event.responseExcerpt === null) {
    //no status means no response came back at all -- refused or thrown before an answer -- and
    //switching capture on would not have changed that, so it must not be told to
    return event.status === null ? "unanswered" : "off";
  }
  return event.responseExcerpt === "" ? "empty" : "captured";
}

/** The cell: a toggle when there is something to show, and a reason when there is not. */
function ResponseCell({ event, recordable, open, onToggle }: {
  event: CustomerExchangeEvent;
  recordable: boolean;
  open: boolean;
  onToggle: () => void;
}) {
  const state = responseState(event, recordable);
  if (state === "none") {
    return <span className="text-muted-foreground">{"\u00b7"}</span>;
  }
  if (state === "captured") {
    return (
      <button type="button" onClick={onToggle} className="text-primary underline-offset-2 hover:underline">
        {open ? "hide" : "show"}
      </button>
    );
  }
  const text = {
    //an upgrade, not a setting -- naming the setting here would be advice their build cannot take
    unavailable: "not available",
    unanswered: "no response",
    off: "not captured",
    empty: "no body",
  }[state];
  const why = {
    unavailable: "this gateway predates the response columns, so it cannot capture one at all",
    unanswered: "the request was refused or failed before the endpoint answered, so there was nothing to keep",
    off: "this gateway can capture responses; smsg.cdr.events.response is off, so it did not",
    empty: "the endpoint answered with no body at all, which is normal for a 204",
  }[state];
  return (
    <span className="rounded bg-muted px-1 py-0.5 text-xs text-muted-foreground" title={why}>
      {text}
    </span>
  );
}

/** The expanded row: the allow-listed headers, then what they wrote. */
function ResponseBody({ event }: { event: CustomerExchangeEvent }) {
  return (
    <div className="space-y-1.5">
      {event.responseHeaders ? (
        <p className="font-mono text-sm text-muted-foreground">{event.responseHeaders}</p>
      ) : (
        <p className="text-xs text-muted-foreground">
          None of the recorded headers were present on the response.
        </p>
      )}
      {/* the response is a THIRD PARTY's text arriving from outside the gateway, so it is rendered
          as preformatted text and never as markup */}
      <pre className="max-h-64 overflow-auto rounded bg-background p-2 font-mono text-sm whitespace-pre-wrap break-all">
        {event.responseExcerpt}
      </pre>
      <p className="text-xs text-muted-foreground">
        The first 500 characters, as stored. The gateway keeps no more of it than this.
      </p>
    </div>
  );
}

/** The timestamp as the rest of this page writes them. */
function stampOf(iso: string): string {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : d.toISOString().replace("T", " ").slice(0, 19);
}
