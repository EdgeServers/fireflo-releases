"use client";
import { Button } from "@/components/ui/button";

/**
 * Previous / Next with a count, for a table that pages in the browser.
 *
 * <p>Renders nothing at one page. A pair of permanently disabled buttons under a three-row table is
 * furniture that says "there is more" when there is not.
 *
 * <p>The count is on the left because it answers the question the buttons raise — *more than what?*
 * — and a page number with no total is the one thing worse than no page number.
 */
export function Pager({
  page,
  pages,
  total,
  noun,
  busy = false,
  onPage,
}: {
  /** Zero-based, already clamped by `usePaging`. Displayed one-based. */
  page: number;
  pages: number;
  total: number;
  /** Plural, for the count: "rows", "sender IDs". */
  noun: string;
  busy?: boolean;
  onPage: (page: number) => void;
}) {
  if (pages <= 1) {
    return null;
  }
  return (
    <div className="mt-3 flex items-center justify-between border-t border-border pt-3 text-xs text-muted-foreground">
      <span>
        {total} {noun} · page {page + 1} of {pages}
      </span>
      <span className="flex gap-2">
        <Button variant="outline" size="sm" className="h-7"
          disabled={page === 0 || busy} onClick={() => onPage(page - 1)}>
          Previous
        </Button>
        <Button variant="outline" size="sm" className="h-7"
          disabled={page >= pages - 1 || busy} onClick={() => onPage(page + 1)}>
          Next
        </Button>
      </span>
    </div>
  );
}
