"use client";
import { InfoPopover } from "@/components/ui/popover";
import type { TlvPair } from "@/lib/tlv-string";

/**
 * The TLVs a header, template or login stamps onto its messages, as a chip that opens the list.
 *
 * <p>Printed inline they were one unbreakable mono string -- a 19-digit entity id and a template id
 * side by side -- and the table column grew to fit it, pushing Account and Product off the screen.
 * The count is what a scanning eye needs; the pairs are one click away. Searching and sorting
 * still read the full text, so nothing becomes harder to find.
 */
export function TlvStamps({ pairs, subject }: { pairs: TlvPair[]; subject?: string }) {
  if (!pairs.length) {
    return null;
  }
  const count = `${pairs.length} stamp${pairs.length === 1 ? "" : "s"}`;
  return (
    <InfoPopover label={subject ? `the TLVs ${subject} stamps` : "the TLVs stamped"} chip={count}>
      <ul className="space-y-1 font-mono text-xs">
        {pairs.map((t) => (
          <li key={t.key} className="break-all">
            {t.key}
            <span className="text-muted-foreground"> = {t.value || "(empty)"}</span>
          </li>
        ))}
      </ul>
    </InfoPopover>
  );
}
