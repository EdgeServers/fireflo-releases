"use client";
import { FILTER_WIDTH } from "@/lib/filter-widths";
import { useState } from "react";
import { Filter, RotateCcw, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Select } from "@/components/ui/select";
import { Field } from "@/components/ui/field";
import { RANGES } from "@/lib/cdr-request";
import {
  EMPTY_REJECTED_FILTERS,
  type RejectedFilterForm,
  hasActiveFilters,
} from "@/lib/rejected-request";
import { REJECT_REASONS, reasonLabel } from "@/lib/rejected-types";

/**
 * The refusal filter form.
 *
 * <p>Holds a draft and only lifts it on submit, for the reason `CdrFilterBar` gives: filtering as you
 * type fires a query per keystroke against a pool of eight connections, and the results flicker
 * between four answers before settling on the one you meant. The page this replaced did search live
 * on a 250ms debounce; that was affordable when the search was the only filter and is not now.
 *
 * <p>The reason list is a dropdown rather than free text, which is the one place this differs from
 * the Messages page's approach. Reasons are a small closed vocabulary the operator did not choose
 * and cannot guess the spelling of — `templateNotMatched` is not a phrase anyone types. A reason the
 * catalogue has not caught up with still arrives from the summary cards and from a Delivery-check
 * link, and the form carries it through rather than dropping it.
 */
export function RejectedFilterBar({
  value,
  onApply,
  busy,
}: {
  value: RejectedFilterForm;
  onApply: (next: RejectedFilterForm) => void;
  busy: boolean;
}) {
  const [draft, setDraft] = useState<RejectedFilterForm>(value);
  const [open, setOpen] = useState(false);

  //the bar is not the only thing that sets a filter -- the summary cards set `reason` too -- so the
  //draft follows the applied value when it changes underneath. Without this, clicking a card and
  //then pressing Search would silently put the old reason back
  const [seen, setSeen] = useState(value);
  if (seen !== value) {
    setSeen(value);
    setDraft(value);
  }

  const set = <K extends keyof RejectedFilterForm>(key: K, next: RejectedFilterForm[K]) =>
    setDraft((d) => ({ ...d, [key]: next }));

  function submit(e: React.FormEvent) {
    e.preventDefault();
    onApply(draft);
  }

  function clear() {
    //the range survives a clear: resetting it as well would look like the filters failed to apply
    //rather than that they were removed
    const next = { ...EMPTY_REJECTED_FILTERS, range: draft.range };
    setDraft(next);
    onApply(next);
  }

  //a reason the catalogue does not know still has to be selectable, or a Delivery-check link to a
  //new token would land with the dropdown showing "Any reason" while the page is filtered
  const reasons = Object.keys(REJECT_REASONS);
  if (draft.reason && !reasons.includes(draft.reason)) {
    reasons.push(draft.reason);
  }

  return (
    <Card>
      <CardContent className="p-4">
        <form onSubmit={submit} className="space-y-4">
          <div className="flex flex-wrap items-end gap-3">
            <Field label="Period" className={FILTER_WIDTH.select}>
              <Select value={draft.range} onChange={(e) => set("range", e.target.value)}>
                {Object.keys(RANGES).map((key) => (
                  <option key={key} value={key}>
                    {key === "all" ? "All time" : `Last ${key}`}
                  </option>
                ))}
              </Select>
            </Field>

            <Field label="Why" className={FILTER_WIDTH.choice}>
              <Select value={draft.reason} onChange={(e) => set("reason", e.target.value)}>
                <option value="">Any reason</option>
                {reasons.map((token) => (
                  <option key={token} value={token}>
                    {reasonLabel(token)}
                  </option>
                ))}
              </Select>
            </Field>

            <Field label="Account" className={FILTER_WIDTH.account}>
              <Input
                value={draft.account}
                onChange={(e) => set("account", e.target.value)}
                placeholder="exact"
              />
            </Field>

            <Field label="To number" className={FILTER_WIDTH.phone}>
              <Input
                value={draft.dest}
                onChange={(e) => set("dest", e.target.value)}
                placeholder="starts with…"
                inputMode="tel"
              />
            </Field>

            {/* the widest net here, and the one this page has always had. It looks inside the
                account, sender, destination, product, login, refusal detail and message excerpt --
                everything the table can show, so a result is explainable without knowing which
                columns the reader happens to have ticked */}
            <Field label="Anything" className={FILTER_WIDTH.text}>
              <Input
                value={draft.q}
                onChange={(e) => set("q", e.target.value)}
                placeholder="contains…"
              />
            </Field>

            <Button type="submit" disabled={busy} className="gap-2">
              <Search className="h-4 w-4" />
              {busy ? "Searching…" : "Search"}
            </Button>

            <Button type="button" variant="ghost" onClick={() => setOpen((o) => !o)} className="gap-2">
              <Filter className="h-4 w-4" />
              {open ? "Fewer filters" : "More filters"}
            </Button>

            {hasActiveFilters(draft) && (
              <Button type="button" variant="ghost" onClick={clear} className="gap-2">
                <RotateCcw className="h-4 w-4" />
                Clear
              </Button>
            )}
          </div>

          {open && (
            <div className="grid gap-3 border-t border-border pt-4 sm:grid-cols-2 lg:grid-cols-3">
              <Field label="Bind name (system id)">
                <Input value={draft.systemId} onChange={(e) => set("systemId", e.target.value)} placeholder="exact" />
              </Field>
              <Field label="Product">
                <Input value={draft.product} onChange={(e) => set("product", e.target.value)} placeholder="exact" />
              </Field>
              <Field label="Came in via">
                <Input value={draft.ingress} onChange={(e) => set("ingress", e.target.value)} placeholder="SMPP, HTTP…" />
              </Field>
              <Field label="Listener" hint="Which of your SMPP servers took it. Empty for everything that arrived over HTTP.">
                <Input value={draft.inGateway} onChange={(e) => set("inGateway", e.target.value)} placeholder="exact" />
              </Field>
              <Field label="From number">
                <Input value={draft.source} onChange={(e) => set("source", e.target.value)} placeholder="starts with…" />
              </Field>
              <Field label="Message id">
                <Input value={draft.msgId} onChange={(e) => set("msgId", e.target.value)} placeholder="exact" />
              </Field>

              <Field
                label="Carrier status"
                hint="The SMPP number the carrier answered with, in decimal — 69 is ESME_RSUBMITFAIL. Only vendor refusals carry one."
              >
                <Input
                  value={draft.vendorStatus}
                  onChange={(e) => set("vendorStatus", e.target.value)}
                  placeholder="69"
                  inputMode="numeric"
                />
              </Field>

              <Field
                label="Stage"
                hint="Most refusals happen at the door: nothing was sent and nothing was charged. The rest were accepted first, so they carry a message id and their charge was refunded."
                className="sm:col-span-2 lg:col-span-2"
              >
                <Select
                  value={draft.afterAccepting ? "after" : draft.hasMsgId ? "withId" : ""}
                  onChange={(e) =>
                    setDraft((d) => ({
                      ...d,
                      afterAccepting: e.target.value === "after" ? "1" : "",
                      hasMsgId: e.target.value === "withId" ? "1" : "",
                    }))
                  }
                >
                  <option value="">Refused at any stage</option>
                  <option value="after">Accepted first, then refused</option>
                  <option value="withId">Anything carrying a message id</option>
                </Select>
              </Field>
            </div>
          )}
        </form>
      </CardContent>
    </Card>
  );
}
