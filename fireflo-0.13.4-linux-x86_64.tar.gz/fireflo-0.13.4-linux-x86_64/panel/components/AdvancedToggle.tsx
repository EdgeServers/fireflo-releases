"use client";
import { cn } from "@/lib/utils";

/**
 * The labelled switch that reveals a page's rarely-used fields. State comes from `useAdvanced`.
 *
 * <p>A real `role="switch"` button with its label beside it, so it reads as a setting rather than
 * as an action, and keyboard and screen-reader users get on/off rather than "pressed".
 */
export function AdvancedToggle({
  on,
  onChange,
  label = "Advanced",
  className,
}: {
  on: boolean;
  onChange: (on: boolean) => void;
  label?: string;
  className?: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      onClick={() => onChange(!on)}
      className={cn(
        "inline-flex h-8 items-center gap-2 rounded-md px-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring",
        className
      )}
    >
      <span
        aria-hidden
        className={cn(
          "relative inline-block h-3.5 w-[26px] rounded-full transition-colors",
          on ? "bg-primary" : "bg-border"
        )}
      >
        <span
          className={cn(
            "absolute top-[2px] h-2.5 w-2.5 rounded-full bg-card transition-[left]",
            on ? "left-[14px]" : "left-[2px]"
          )}
        />
      </span>
      {label}
    </button>
  );
}
