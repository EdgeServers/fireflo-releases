"use client";
import { useState } from "react";
import { settingLabel } from "@/lib/labels";
import { SUMMARY_KEYS, sectionTitle } from "@/lib/setting-fields";
import { REDACTED, type WorkerProperty, type WorkerType } from "@/lib/worker-types";

/**
 * A worker's stored settings, named rather than keyed, and no longer all at once.
 *
 * <p>One component for both vendors and servers — this was the same markup twice, and the copy on
 * each page printed the database key straight out, so a reader got `connections.transceivers` where
 * the form two clicks away called it "Transceiver binds".
 *
 * <p><strong>Summarised rather than dumped.</strong> Listing every stored property was fine when the
 * editor offered sixteen fields and a worker typically had three or four; the editor now offers
 * eighty, so a fully configured vendor rendered fifty rows of key/value and pushed the live state —
 * the reason anyone opened the page — off the top of the card. A handful of identifying settings
 * stay inline and the rest go behind a count, grouped by the same sections the form uses.
 *
 * <p>The raw key stays in the `title`. Someone comparing this against `smsg.properties` or a gateway
 * log line still needs it; they just should not have to read it to find out what the setting is.
 */
export function SettingsList({
  type,
  properties,
  empty,
}: {
  type: WorkerType;
  properties: WorkerProperty[];
  empty: string;
}) {
  const [open, setOpen] = useState(false);

  if (!properties.length) {
    return <p className="text-xs text-muted-foreground">{empty}</p>;
  }

  const summaryKeys = SUMMARY_KEYS[type] as readonly string[];
  const summary = summaryKeys
    .map((key) => properties.find((p) => p.key === key))
    .filter((p): p is WorkerProperty => p != null);
  const rest = properties.filter((p) => !summaryKeys.includes(p.key));

  //grouped by the form's own sections, so "where would I go to change this" has one answer
  const grouped = new Map<string, WorkerProperty[]>();
  for (const property of rest) {
    const title = sectionTitle(property.key);
    grouped.set(title, [...(grouped.get(title) ?? []), property]);
  }

  return (
    <div className="space-y-2">
      {summary.length > 0 && <Grid properties={summary} />}

      {rest.length > 0 && (
        <div>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            className="text-sm text-muted-foreground hover:text-foreground"
          >
            {open ? "Hide" : "Show"} {rest.length} more setting{rest.length === 1 ? "" : "s"}
          </button>
          {open && (
            <div className="mt-2 space-y-2">
              {[...grouped].map(([title, group]) => (
                <div key={title}>
                  <p className="mb-1 text-sm font-medium text-muted-foreground">{title}</p>
                  <Grid properties={group} />
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Grid({ properties }: { properties: WorkerProperty[] }) {
  return (
    <dl className="grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2 lg:grid-cols-3">
      {properties.map((p) => (
        <div key={p.key} className="flex justify-between gap-2" title={p.key}>
          <dt className="truncate text-muted-foreground">{settingLabel(p.key).label}</dt>
          <dd className="truncate font-medium tabular-nums">
            {/* the server sends a placeholder in place of a stored secret; rendering the asterisks
                verbatim would read as somebody's actual password being eight stars */}
            {p.value === REDACTED ? <span className="text-muted-foreground">set</span> : p.value}
          </dd>
        </div>
      ))}
    </dl>
  );
}
