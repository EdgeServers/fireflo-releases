"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { FlaskConical, Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClasses } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs } from "@/components/ui/tabs";
import { useGuidedOptions } from "./GuidedConditionRow";
import { useWorkers } from "./useWorkers";
import { DEFAULT_SCOPE } from "@/lib/rate-types";
import { reachability } from "@/lib/routing-guide";
import type { RouteTable, RoutingExplanation } from "@/lib/routing-types";
import type { Worker } from "@/lib/worker-types";
import {
  BLANK_INPUT,
  destinationCondition,
  type FilterOutcome,
  neverRunsIn,
  nextTable,
  prefillParams,
  type RatingAnswer,
  bareLoginsText,
  missingPriceText,
  productUsedText,
  suggestPrefix,
  type TesterInput,
  type TesterTab,
  deciding,
  vendorOf,
} from "@/lib/tester";
import { cn } from "@/lib/utils";

/** Where the last test's inputs are kept, so reopening the tester carries on from it. */
const REMEMBER = "fireflo.tester.input";

const TABS: { id: TesterTab; label: string }[] = [
  { id: "routing", label: "Routing" },
  { id: "pricing", label: "Pricing" },
  { id: "filters", label: "Filters" },
];

const TYPES = [
  { value: "", label: "Ordinary message" },
  { value: "0", label: "Inbound (MO)" },
  { value: "18", label: "Delivery receipt" },
];

/**
 * What the tester needs from the page, when the page already has it.
 *
 * <p>The Routing section loads its tables and listeners once in its layout; opening the tester
 * there used to fetch both again (CP-P8). Either may be left out -- the Pricing and Filters pages
 * have neither -- and the modal then fetches that one for itself.
 */
export interface TesterData {
  tables?: RouteTable[];
  servers?: Worker[];
}

/** The Routing, Pricing and Filters pages' "Test a message" button, opening on its own tab. */
export function TesterButton({ tab, data }: { tab: TesterTab; data?: TesterData }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button variant="outline" size="sm" className="gap-2" onClick={() => setOpen(true)}>
        <FlaskConical className="h-4 w-4" />
        Test a message
      </Button>
      {open && <TesterModal initialTab={tab} onClose={() => setOpen(false)} data={data} />}
    </>
  );
}

interface Results {
  routing: { steps: RoutingExplanation[]; target: string | null } | null;
  pricing: RatingAnswer | null;
  filters: FilterOutcome[] | null;
  errors: Partial<Record<TesterTab, string>>;
}

const NO_RESULTS: Results = { routing: null, pricing: null, filters: null, errors: {} };

/**
 * One message, three questions: which rule routes it, what it is charged and costs, and which
 * named filters it meets. Every answer is the gateway's own -- the same matchers live traffic
 * uses -- and numbers are compared exactly as typed. When a tab finds nothing, it offers to create
 * what is missing, opening that page's editor pre-filled from the test.
 */
export function TesterModal({ initialTab, onClose, data }: { initialTab: TesterTab; onClose: () => void; data?: TesterData }) {
  //a hook cannot be conditional, so the listener list is fetched by an inner component only when
  //the page did not bring one
  if (data?.servers) {
    return <TesterModalBody initialTab={initialTab} onClose={onClose} servers={data.servers} tables={data.tables} />;
  }
  return <TesterModalLoadingServers initialTab={initialTab} onClose={onClose} tables={data?.tables} />;
}

function TesterModalLoadingServers(props: { initialTab: TesterTab; onClose: () => void; tables?: RouteTable[] }) {
  const { workers: servers } = useWorkers("smppserver");
  return <TesterModalBody {...props} servers={servers} />;
}

function TesterModalBody({
  initialTab,
  onClose,
  servers,
  tables: given,
}: {
  initialTab: TesterTab;
  onClose: () => void;
  servers: Worker[];
  tables?: RouteTable[];
}) {
  const options = useGuidedOptions();
  const [tab, setTab] = useState<TesterTab>(initialTab);
  const [input, setInput] = useState<TesterInput>(BLANK_INPUT);
  const [tables, setTables] = useState<string[]>([]);
  //the same list as a promise, for a Test clicked before the fetch has answered: following a
  //route needs to know which targets are tables, and without the list a table looked like a vendor
  const tablesLoaded = useRef<Promise<string[]>>(Promise.resolve([]));
  //the tables nothing routes to, so a filter's "used by" can say which of its rules never run
  const [unreached, setUnreached] = useState<string[]>([]);
  const [results, setResults] = useState<Results>(NO_RESULTS);
  const [running, setRunning] = useState(false);

  useEffect(() => {
    try {
      const saved = window.sessionStorage.getItem(REMEMBER);
      //the product is NOT restored: a product typed for one test silently became "typed" for every
      //later one, pricing an account under a product its logins never carried
      //eslint-disable-next-line react-hooks/set-state-in-effect -- read once after mount: storage is browser-only
      if (saved) setInput({ ...BLANK_INPUT, ...(JSON.parse(saved) as Partial<TesterInput>), product: "" });
    } catch {
      //private browsing or a mangled entry: start blank
    }
    const take = (all: RouteTable[]) => {
      const names = all.map((t) => t.name);
      setTables(names);
      setUnreached(reachability(all).unreached);
      return names;
    };
    tablesLoaded.current = given
      ? Promise.resolve(take(given))
      : fetch("/api/control/routing", { cache: "no-store" })
          .then((r) => (r.ok ? r.json() : null))
          .then((body) => take((body?.data?.tables ?? []) as RouteTable[]))
          .catch(() => [] as string[]);
    //the page's copy is read once, on open: the tester is modal, and the list cannot change under it
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const set = (key: keyof TesterInput) => (value: string) => setInput((i) => ({ ...i, [key]: value }));
  //the same product on all three tabs: every endpoint resolves it the same way, so any one answer
  //will do, and the price's is the one that explains a missing price
  const lastStep = results.routing?.steps[results.routing.steps.length - 1];
  const productLine = productUsedText(results.pricing
    ?? (lastStep ? { product: lastStep.product, product_from: lastStep.productFrom, login_products: lastStep.loginProducts } : null), input.account);
  const bareLine = bareLoginsText(results.pricing, input.account);

  async function run() {
    setRunning(true);
    try {
      window.sessionStorage.setItem(REMEMBER, JSON.stringify(input));
    } catch {
      //not remembered; the test still runs
    }
    const errors: Results["errors"] = {};
    const known = tables.length ? tables : await tablesLoaded.current;
    const routing = await followRouting(input, known).catch((e: Error) => {
      errors.routing = e.message;
      return null;
    });
    const vendor = vendorOf(routing?.target, known);
    const [pricing, filters] = await Promise.all([
      get<RatingAnswer>("/api/control/rating/explain", { ...pick(input, ["account", "to", "from", "product", "content"]), vendor: vendor ?? "" })
        .catch((e: Error) => {
          errors.pricing = e.message;
          return null;
        }),
      get<{ filters: FilterOutcome[] }>("/api/control/filters/test", pick(input, ["to", "from", "product", "account", "type"]))
        .then((r) => r.filters)
        .catch((e: Error) => {
          errors.filters = e.message;
          return null;
        }),
    ]);
    setResults({ routing, pricing, filters, errors });
    setRunning(false);
  }

  return (
    <Dialog open onClose={onClose} title="Test a message" description="What the gateway would do with it. Nothing is sent."
      className="max-w-[920px]">
      <div className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Account" hint="Its pricing, and rules on account">
            <Input list="tester-accounts" value={input.account} onChange={(e) => set("account")(e.target.value)} placeholder="any account" className="font-mono" />
            <datalist id="tester-accounts">{options.accounts.map((a) => <option key={a.value} value={a.value}>{a.label}</option>)}</datalist>
          </Field>
          <Field label="Destination number" hint={input.to ? `Compared exactly: "${input.to}"` : "Compared exactly as typed"}>
            <Input value={input.to} onChange={(e) => set("to")(e.target.value)} placeholder="+919812345678" className="font-mono" />
          </Field>
          <Field label="Header (sender ID)">
            <Input value={input.from} onChange={(e) => set("from")(e.target.value)} placeholder="FireFlo" />
          </Field>
          <Field label="Product">
            <Input list="tester-products" value={input.product} onChange={(e) => set("product")(e.target.value)} placeholder="(from the account's login)" />
            <datalist id="tester-products">{options.products.map((p) => <option key={p.value} value={p.value}>{p.label}</option>)}</datalist>
          </Field>
        </div>
        <div className="flex flex-wrap items-end gap-3">
          {tab === "routing" && (
            <>
              <Field label="Arrived on" className="w-56">
                <select value={input.ingateway} onChange={(e) => set("ingateway")(e.target.value)}
                  className="h-9 w-full rounded-md border border-input bg-background px-2 text-sm">
                  <option value="">— an HTTP-origin message</option>
                  {servers.map((w) => <option key={w.name} value={`smppserver.${w.name}`}>smppserver.{w.name}</option>)}
                </select>
              </Field>
              <Field label="Message type" className="w-48">
                <select value={input.type} onChange={(e) => set("type")(e.target.value)}
                  className="h-9 w-full rounded-md border border-input bg-background px-2 text-sm">
                  {TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                </select>
              </Field>
            </>
          )}
          {tab === "pricing" && (
            <Field label="Message text (for parts)" className="min-w-64 flex-1">
              <Input value={input.content} onChange={(e) => set("content")(e.target.value)} placeholder="Leave empty for one part" />
            </Field>
          )}
          <Button className="ml-auto gap-2" disabled={running || !input.to.trim()} onClick={() => void run()}>
            {running && <Loader2 className="h-4 w-4 animate-spin" />}
            Test
          </Button>
        </div>

        {productLine && <p className="text-sm text-muted-foreground">{productLine}</p>}
        {bareLine && <p className="text-sm text-warning">{bareLine}</p>}

        <Tabs items={TABS} active={tab} onSelect={setTab} label="What to test" />

        <div className="max-h-[52vh] overflow-y-auto pr-1">
          {results.errors[tab] ? (
            <p className="text-sm text-destructive">{results.errors[tab]}</p>
          ) : tab === "routing" ? (
            <RoutingResult result={results.routing} input={input} onNavigate={onClose} />
          ) : tab === "pricing" ? (
            <PricingResult result={results.pricing} input={input} onNavigate={onClose} />
          ) : (
            <FiltersResult result={results.filters} input={input} unreached={unreached} onNavigate={onClose} />
          )}
        </div>
      </div>
    </Dialog>
  );
}

/** Explains the entry table, and follows a rule whose target is another table, as the router does. */
async function followRouting(input: TesterInput, tables: readonly string[]) {
  const steps: RoutingExplanation[] = [];
  let table: string | null = "default";
  let target: string | null = null;
  for (let hop = 0; table && hop < 5; hop++) {
    const step: RoutingExplanation = await get<RoutingExplanation>("/api/control/routing/explain",
      { table, ...pick(input, ["to", "from", "product", "ingateway", "type", "account"]) });
    steps.push(step);
    //not step.matchedIndex: that is the first match, and a preprocessor rule matching first only
    //runs the preprocessor -- the message carries on to the rules below it
    target = deciding(step.rules)?.target ?? null;
    table = nextTable(target, tables);
    if (table && steps.some((s) => s.table === table)) break;
  }
  return { steps, target };
}

function RoutingResult({ result, input, onNavigate }: { result: Results["routing"]; input: TesterInput; onNavigate: () => void }) {
  if (!result) return <Empty />;
  const last = result.steps[result.steps.length - 1];
  const routed = result.target != null;
  const catchAll = last?.rules.some((r) => !r.mismatch && r.matched) ?? false;
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        {routed ? <Badge variant="success">Routed</Badge> : <Badge variant="destructive">Not routed</Badge>}
        <span className="text-title">{routed ? result.target : "No rule matches"}</span>
        {!routed && last && (
          <span className="text-sm text-muted-foreground">
            {last.tableFound ? `${last.table} has no rule for it, so it would be retried and then dropped.` : `Table ${last.table} does not exist.`}
          </span>
        )}
      </div>
      <div className="overflow-hidden rounded-lg border border-border">
        {result.steps.flatMap((step) => step.rules.map((r) => {
          const won = deciding(step.rules)?.index === r.index;
          const passes = r.matched && r.evaluable && r.target.startsWith("@") && (deciding(step.rules)?.index ?? Infinity) > r.index;
          return (
            <div key={`${step.table}-${r.index}`} className={cn("grid grid-cols-[2rem_minmax(0,1.3fr)_minmax(0,1fr)_minmax(0,1.8fr)] gap-2 border-t border-border px-3 py-2 text-sm first:border-t-0", won && "bg-primary-soft")}>
              <span className="tabular-nums text-muted-foreground">{r.index}</span>
              <span className="min-w-0 truncate">{step.table} · {r.label || `rule ${r.index}`}</span>
              <span className="min-w-0 truncate font-mono text-xs">{r.target}</span>
              <span className="min-w-0 text-xs text-muted-foreground">
                {!r.evaluable ? "depends on a vendor's live state" : won ? <Badge variant="success">✓ matched</Badge>
                  : passes ? <><Badge variant="outline">✓ runs {r.target}</Badge> then carries on below</>
                  : r.matched ? "matches, but an earlier rule won" : <Mismatch text={r.mismatch} />}
              </span>
            </div>
          );
        }))}
      </div>
      {!routed && last?.tableFound && (
        <Suggest
          onNavigate={onNavigate}
          title={`Create a routing rule for ${suggestPrefix(input.to) || "this number"}`}
          body={`In table ${last.table}: destination starts with ${suggestPrefix(input.to)} → a vendor you choose.`}
          href={`/cp/routing/tables/${encodeURIComponent(last.table)}?${prefillParams(destinationCondition(input.to))}`}
          action="Create routing rule"
          alt={catchAll ? undefined : { label: "Add a catch-all instead", href: `/cp/routing/tables/${encodeURIComponent(last.table)}?new=1` }}
        />
      )}
    </div>
  );
}

function PricingResult({ result, input, onNavigate }: { result: RatingAnswer | null; input: TesterInput; onNavigate: () => void }) {
  if (!result) return <Empty />;
  const condition = destinationCondition(input.to);
  const product: Record<string, string> = input.product.trim() ? { product: input.product.trim() } : {};
  return (
    <div className="space-y-3">
      {!result.active && <p className="text-sm text-warning">This gateway has no pricing loaded at all, so nothing is rated.</p>}
      <div className="grid gap-3 md:grid-cols-2">
        <RatedBox kind="Price" title={input.account ? `What ${input.account} pays` : "What Everyone pays by default"} rule={result.price} parts={result.parts}
          missing={missingPriceText(result, input.account)} />
        <RatedBox kind="Cost" title={result.vendor ? `What ${result.vendor} charges us` : "Cost"} rule={result.cost} parts={result.parts}
          missing={result.vendor ? `${result.vendor} has no cost rule for it, so margin can't be worked out.` : "Routing picked no vendor, so there is no cost to look up."} />
      </div>
      {result.margin != null && (
        <div className="flex justify-between rounded-lg border border-border px-3 py-2 text-sm font-semibold">
          <span>Margin</span><span className="tabular-nums">{result.margin}{result.margin_pct != null ? ` · ${result.margin_pct}%` : ""}</span>
        </div>
      )}
      {!result.price && input.account && (
        <Suggest
          onNavigate={onNavigate}
          title={`Create a price for ${suggestPrefix(input.to) || "this number"}`}
          body={`For ${input.account}${input.product ? `, product ${input.product}` : ""}: destination starts with ${condition.value} → a rate.`}
          href={`/cp/pricing/scope/${encodeURIComponent(input.account)}?${prefillParams(condition, product)}`}
          action={`Create price for ${input.account}`}
          alt={{ label: "On Everyone instead", href: `/cp/pricing/scope/${encodeURIComponent(DEFAULT_SCOPE)}?${prefillParams(condition, product)}` }}
        />
      )}
      {!result.cost && result.vendor && (
        <Suggest
          onNavigate={onNavigate}
          title={`Create ${result.vendor}'s cost for ${condition.value || "this number"}`}
          body={`Vendor ${result.vendor}${input.product ? `, product ${input.product}` : ""}: destination starts with ${condition.value} → a cost.`}
          href={`/cp/pricing/scope/${encodeURIComponent(result.vendor)}?${prefillParams(condition, product)}`}
          action="Create vendor cost"
        />
      )}
    </div>
  );
}

function RatedBox({ kind, title, rule, parts, missing }: { kind: string; title: string; rule: RatingAnswer["price"]; parts: number; missing: string }) {
  return (
    <div className="rounded-lg border border-border p-3">
      <div className="flex flex-wrap items-center gap-2">
        {rule ? <Badge variant="success">{kind}</Badge> : <Badge variant={kind === "Price" ? "destructive" : "warning"}>No {kind.toLowerCase()}</Badge>}
        <span className="font-semibold">{title}</span>
      </div>
      {rule ? (
        <dl className="mt-2 grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 text-sm">
          <dt className="text-muted-foreground">Answered by</dt><dd>{rule.scope === DEFAULT_SCOPE ? "Everyone" : rule.scope}{rule.fallback ? " (no rule of its own)" : ""}</dd>
          <dt className="text-muted-foreground">Rule</dt><dd className="font-mono text-xs">{rule.conditions.length ? rule.conditions.join(" and ") : "every message"}{rule.product ? ` · ${rule.product}` : ""}</dd>
          <dt className="text-muted-foreground">Rate</dt><dd className="tabular-nums">{rule.rate} {rule.currency ?? ""}</dd>
          <dt className="text-muted-foreground">Parts</dt><dd className="tabular-nums">{parts}</dd>
          <dt className="text-muted-foreground">Total</dt><dd className="font-semibold tabular-nums">{rule.total} {rule.currency ?? ""}</dd>
        </dl>
      ) : (
        <p className="mt-2 text-sm text-muted-foreground">{missing}</p>
      )}
    </div>
  );
}

function FiltersResult({ result, input, unreached, onNavigate }: {
  result: FilterOutcome[] | null;
  input: TesterInput;
  unreached: readonly string[];
  onNavigate: () => void;
}) {
  if (!result) return <Empty />;
  const matched = result.filter((f) => f.matched && f.enabled).length;
  const condition = destinationCondition(input.to);
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        {matched ? <Badge variant="success">{`${matched} of ${result.length} matched`}</Badge> : <Badge variant="outline">None matched</Badge>}
        <span className="text-sm text-muted-foreground">Named filters, tried against this message</span>
      </div>
      {result.length > 0 && (
        <div className="overflow-hidden rounded-lg border border-border">
          {result.map((f) => (
            <div key={f.name} className="grid grid-cols-[minmax(0,1.2fr)_minmax(0,1.4fr)_minmax(0,1.2fr)] gap-2 border-t border-border px-3 py-2 text-sm first:border-t-0">
              <span className="min-w-0">
                <span className="font-mono">{f.name}</span>
                {!f.enabled && <Badge variant="outline" className="ml-2">off</Badge>}
                <span className="block text-xs text-muted-foreground">{f.conditions.join(" and ")}</span>
              </span>
              <span className="min-w-0 text-xs">{f.matched ? <Badge variant="success">✓ matched</Badge> : <Mismatch text={f.mismatch} />}</span>
              <span className="min-w-0 text-xs text-muted-foreground">
                {f.used_by.length ? f.used_by.map((u, i) => {
                  const dead = neverRunsIn(u, unreached);
                  return (
                    <span key={u} className="block">
                      {u}
                      {dead && <span className="text-warning">{` — never runs, nothing routes to ${dead}`}</span>}
                      {i < f.used_by.length - 1 && <span className="sr-only">;</span>}
                    </span>
                  );
                }) : "not used by any rule"}
              </span>
            </div>
          ))}
        </div>
      )}
      {!matched && (
        <Suggest
          onNavigate={onNavigate}
          title={`Create a filter for ${condition.value || "this number"}`}
          body={`A named filter on destination starts with ${condition.value}, ready for routing and price rules to use.`}
          href={`/cp/filters?${prefillParams(condition)}`}
          action="Create filter"
        />
      )}
    </div>
  );
}

/** "to:startsWith:+61 actual=+9198..." as a sentence: what was asked, and what was compared. */
function Mismatch({ text }: { text: string | null }) {
  if (!text) return <span>did not match</span>;
  const at = text.lastIndexOf(" actual=");
  const rule = at < 0 ? text : text.slice(0, at);
  const actual = at < 0 ? null : text.slice(at + " actual=".length);
  return (
    <span>
      <span className="font-medium text-foreground">{rule.replace(/:/g, " ")}</span>
      {actual != null && <> — compared <span className="font-mono">“{actual}”</span></>}
    </span>
  );
}

function Suggest({ title, body, href, action, alt, onNavigate }: {
  title: string; body: string; href: string; action: string; alt?: { label: string; href: string };
  /** Closes the tester: the editor opens on the page behind it, which may be this same page. */
  onNavigate: () => void;
}) {
  return (
    <div className="flex flex-wrap items-center gap-3 rounded-lg border border-dashed border-primary bg-primary-soft px-3 py-2.5">
      <div className="min-w-56 flex-1">
        <p className="text-sm font-semibold">{title}</p>
        <p className="text-xs text-muted-foreground">{body} Opens the editor pre-filled; nothing is saved until you do.</p>
      </div>
      {alt && <Link href={alt.href} onClick={onNavigate} className={buttonClasses({ variant: "outline", size: "sm" })}>{alt.label}</Link>}
      <Link href={href} onClick={onNavigate} className={buttonClasses({ size: "sm" })}>{action}</Link>
    </div>
  );
}

function Empty() {
  return <p className="py-6 text-center text-sm text-muted-foreground">Enter a number and press Test.</p>;
}

function Field({ label, hint, className, children }: { label: string; hint?: string; className?: string; children: React.ReactNode }) {
  return (
    <div className={cn("min-w-0", className)}>
      <Label className="mb-1 block text-xs">{label}</Label>
      {children}
      {hint && <p className="mt-1 truncate text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

function pick(input: TesterInput, keys: (keyof TesterInput)[]): Record<string, string> {
  return Object.fromEntries(keys.map((k) => [k, input[k].trim()]).filter(([, v]) => v));
}

async function get<T>(path: string, params: Record<string, string>): Promise<T> {
  const query = new URLSearchParams(Object.entries(params).filter(([, v]) => v));
  const res = await fetch(`${path}?${query}`, { cache: "no-store" });
  const body = await res.json().catch(() => null);
  if (!res.ok) throw new Error(body?.error ?? body?.message ?? `The gateway answered ${res.status}.`);
  return body.data as T;
}
