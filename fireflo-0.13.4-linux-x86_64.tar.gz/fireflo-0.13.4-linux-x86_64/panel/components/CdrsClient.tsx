"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { ChevronLeft, ChevronRight, Columns3, RefreshCw } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { TBody, TD, TH, THead, TR, Table, TableFooter } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { CdrCell, Outcome } from "./CdrCell";
import { pendingSummary } from "@/lib/labels";
import { ColumnChooser } from "./ColumnChooser";
import { CdrFilterBar } from "./CdrFilterBar";
import { ExportsCard } from "./ExportsCard";
import {
  CDR_HISTORY_KEY,
  CDR_LAST_KEY,
  EMPTY_FILTERS,
  type CdrCursor,
  type CdrFilterForm,
  type CdrRow,
  cursorFromQuery,
  fromQuery,
  listHref,
  restoreHistory,
  toQuery,
} from "@/lib/cdr-request";
import {
  CDR_COLUMNS,
  CDR_COLUMN_GROUPS,
  COLUMN_STORAGE_KEY,
  HEAVY_CDR_COLUMN_IDS,
  type ColumnChoice,
  readColumnChoice,
  resolveColumns,
  toggleColumn,
} from "@/lib/cdr-columns";
import { formatTimestamp } from "@/lib/datetime";
import { money } from "@/lib/format";
import { EmptyState } from "@/components/ui/empty-state";

const PAGE_SIZE = 50;

/** Where a row's full history lives. Passed to {@link CdrCell}; the customer table has no equivalent. */
const detailHref = (row: CdrRow) => `/cp/cdrs/${encodeURIComponent(row.gatewayMsgId)}`;

/**
 * Individual call records, which no other page in this panel can show — everything else here is a
 * GROUP BY aggregate, and "what happened to this one message" is not a question an aggregate answers.
 *
 * <p>Paging is keyset, so Next is a cursor rather than an offset. That makes Previous something the
 * page has to remember rather than compute: the stack below holds the cursor each page started from.
 * The alternative — reversing the sort to page backwards — returns the right rows in the wrong order
 * and is the classic source of a "Previous" that skips a row every time the table is being written
 * to, which for a live gateway is always.
 *
 * <p>Which columns are shown is a per-operator choice kept in `localStorage`, not in the URL: the
 * query string is the filters' home and is meant to be shared, and a shared link should not impose
 * the sharer's columns on whoever opens it.
 *
 * <p>The filters and the current page are written back to the URL as they change, and the Previous
 * stack to `sessionStorage`, so opening a message and returning, the browser's Back and a reload all
 * land on the page the operator was on. They used to live only in React state, and every way back
 * to this page was page one of an unfiltered list.
 */
export function CdrsClient() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [filters, setFilters] = useState<CdrFilterForm>(EMPTY_FILTERS);
  const [rows, setRows] = useState<CdrRow[]>([]);
  const [nextCursor, setNextCursor] = useState<CdrCursor | null>(null);
  //one entry per page already visited; the last is the page currently shown
  const [history, setHistory] = useState<(CdrCursor | null)[]>([null]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [choice, setChoice] = useState<ColumnChoice | null>(null);
  const [chooserOpen, setChooserOpen] = useState(false);

  //read after mount, never in a lazy initialiser: localStorage does not exist while the page is
  //rendered on the server, and React 19 throws on the resulting mismatch rather than patching it up
  useEffect(() => {
    setChoice(readColumnChoice(window.localStorage.getItem(COLUMN_STORAGE_KEY)));
  }, []);

  function choose(id: string, enabled: boolean) {
    const next = toggleColumn(choice, id, enabled);
    setChoice(next);
    window.localStorage.setItem(COLUMN_STORAGE_KEY, JSON.stringify(next));
  }

  function resetColumns() {
    setChoice(null);
    window.localStorage.removeItem(COLUMN_STORAGE_KEY);
  }

  const columns = resolveColumns(choice);

  const columnIds = columns.map((c) => c.id);

  /**
   * @param ids the columns on screen, so the route knows whether to select the unbounded TLV
   *     columns. Passed in rather than closed over, which would make `load` change identity every
   *     time the chooser did — and the mount effect below depends on it, so that would re-run
   *     `setFilters(initial)` and silently reset the operator's filters back to the query string.
   */
  const load = useCallback(async (form: CdrFilterForm, cursor: CdrCursor | null, ids: string[]) => {
    setLoading(true);
    try {
      const params = toQuery(form);
      params.set("limit", String(PAGE_SIZE));
      //what the chooser is showing, so the route knows whether to select the unbounded TLV columns.
      //Without it they were never fetched and a ticked TLV column rendered blank
      params.set("columns", ids.join(","));
      if (cursor) {
        params.set("cursorTs", cursor.submittedAt);
        params.set("cursorId", cursor.id);
      }
      const res = await fetch(`/api/control/cdrs?${params}`);
      const body = await res.json();
      if (!res.ok) {
        throw new Error(body?.error ?? `Request failed (${res.status})`);
      }
      setRows(body.data?.rows ?? []);
      setNextCursor(body.data?.nextCursor ?? null);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not read call records");
      setRows([]);
      setNextCursor(null);
    } finally {
      setLoading(false);
    }
  }, []);

  /**
   * The query string this component last wrote or read, so the effect below can tell its own
   * navigation (nothing to do) from one that arrived from outside: the first render, a link into
   * this page, the browser's Back and Forward.
   */
  const synced = useRef<string | null>(null);

  /**
   * Every load starts from the URL: the first render, a link into this page, Back and Forward.
   *
   * <p>`fromQuery` existed and nothing called it, so every link into this page — "Messages sent
   * under this product", the vendor and server cards — landed on an unfiltered list showing all
   * traffic. That reads as the filter having been applied and matched everything, which is worse than
   * an obvious failure. A bare address, which is what the sidebar and "All messages" give, returns to
   * the list's last address instead of page one of everything.
   *
   * <p>Storage is read in the effect rather than in a `useState` initialiser: `window` does not
   * exist while this renders on the server, and React 19 throws on the mismatch.
   */
  useEffect(() => {
    let query = searchParams.toString();
    if (query === synced.current) {
      return;
    }
    if (!query) {
      try {
        const last = window.sessionStorage.getItem(CDR_LAST_KEY);
        if (last) {
          query = last;
          synced.current = last;
          router.replace(`/cp/cdrs?${last}`, { scroll: false });
        }
      } catch {
        //no storage: page one
      }
    }
    synced.current = query;
    try {
      //an address arrived at by Back, Forward or a link is the list's last address too
      window.sessionStorage.setItem(CDR_LAST_KEY, query);
    } catch {
      //not remembered
    }
    const params = new URLSearchParams(query);
    const initial = fromQuery(params);
    const cursor = cursorFromQuery(params);
    let saved: string | null = null;
    try {
      saved = window.sessionStorage.getItem(CDR_HISTORY_KEY);
    } catch {
      //no storage: Previous reaches page one only
    }
    setFilters(initial);
    setHistory(restoreHistory(saved, toQuery(initial).toString(), cursor));
    //the default columns carry nothing heavy, so the first load asks for no TLV column. An operator
    //whose saved choice includes one gets it from the effect below, once localStorage has been read
    void load(initial, cursor, []);
  }, [searchParams, router, load]);

  /**
   * Writes the list's state where the effect above and a later visit will find it: the current page
   * into the URL, the Previous stack into session storage. Paging pushes, so the browser's Back
   * walks the pages; a filter change replaces, since the pages of the old list are no longer
   * reachable from the new one.
   *
   * @param remember the stack to keep, when longer than the one shown: Previous cuts the shown
   *     stack but keeps the pages ahead on record, so the browser's Forward finds them again
   */
  function sync(form: CdrFilterForm, stack: (CdrCursor | null)[], push: boolean, remember = stack) {
    const href = listHref(form, stack[stack.length - 1]);
    const query = href.includes("?") ? href.slice(href.indexOf("?") + 1) : "";
    synced.current = query;
    try {
      window.sessionStorage.setItem(CDR_HISTORY_KEY, JSON.stringify({ query: toQuery(form).toString(), history: remember }));
      window.sessionStorage.setItem(CDR_LAST_KEY, query);
    } catch {
      //not remembered; the page still works
    }
    if (push) {
      router.push(href, { scroll: false });
    } else {
      router.replace(href, { scroll: false });
    }
  }

  /**
   * Re-fetches when a heavy column is ticked or unticked.
   *
   * <p>Only the heavy ones: every other column is already in the rows on screen, so toggling it is a
   * render and not a round trip. The TLV columns are the exception — they are selected only when
   * asked for, so ticking one would otherwise show a column of blanks until the next search, which
   * looks exactly like the data being missing.
   */
  const heavyChosen = HEAVY_CDR_COLUMN_IDS.filter((id) => columnIds.includes(id)).join(",");
  useEffect(() => {
    //nothing heavy on screen means nothing extra to fetch -- which is also the state at mount, so
    //this cannot race the effect above, and unticking needs no round trip either
    if (!heavyChosen) {
      return;
    }
    void load(filters, history[history.length - 1], heavyChosen.split(","));
  }, [heavyChosen]);   // eslint-disable-line react-hooks/exhaustive-deps

  function apply(next: CdrFilterForm) {
    //a filter change resets paging. Keeping the cursor would ask for "the page after this timestamp"
    //under a different filter, which lands somewhere arbitrary in the new result set
    setFilters(next);
    setHistory([null]);
    sync(next, [null], false);
    void load(next, null, columnIds);
  }

  function forward() {
    if (!nextCursor) {
      return;
    }
    const grown = [...history, nextCursor];
    setHistory(grown);
    sync(filters, grown, true);
    void load(filters, nextCursor, columnIds);
  }

  function back() {
    if (history.length < 2) {
      return;
    }
    const trimmed = history.slice(0, -1);
    setHistory(trimmed);
    sync(filters, trimmed, true, history);
    void load(filters, trimmed[trimmed.length - 1], columnIds);
  }

  const page = history.length;
  const pending = pendingSummary(rows);

  //the same page again, with the same filters and columns. Receipts land seconds after a message is
  //sent and nothing else re-reads the list, so without this a row stayed "Awaiting receipt" while its
  //detail page, opened later, already showed the outcome
  function refresh() {
    void load(filters, history[history.length - 1], columnIds);
  }

  return (
    <>
      <PageHeader
        title="Messages"
        description="Every message the gateway handled, one call record each, with what happened to it."
      />

      {/* the bar keeps its own draft; a filter set that arrived from outside (a link into the page, a
          restored address, Back/Forward) replaces it by remounting, or the bar kept showing 24h
          while the list was filtered */}
      <CdrFilterBar key={toQuery(filters).toString()} value={filters} onApply={apply} busy={loading} />

      {error && (
        <Card>
          <CardContent className="py-4 text-sm text-destructive">{error}</CardContent>
        </Card>
      )}

      {!error && !rows.length && (
        <EmptyState>
          {loading ? "Loading…" : "No messages match these filters in this period"}
        </EmptyState>
      )}

      {!!rows.length && (
        <>
          {/* said plainly rather than left to be inferred from a column of dashes: most traffic has
              no receipt yet at any given moment, and a table that looks half-empty reads as broken */}
          <div className="flex flex-wrap items-center gap-2">
            <p className="min-w-0 flex-1 text-sm text-muted-foreground">{pending}</p>
            <Button size="sm" variant="outline" onClick={refresh} disabled={loading}
              title="Read this page again, for receipts that arrived since">
              <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </Button>
          </div>

          <div className="hidden md:block">
            <Table
              //no total and no page count: both need a COUNT(*) over the whole filtered set, which
              //is the one query that does not stay fast as this table grows
              footer={
                    <TableFooter
                      from={(page - 1) * PAGE_SIZE + 1}
                      to={(page - 1) * PAGE_SIZE + rows.length}
                      noun="messages"
                      onPrev={back}
                      onNext={forward}
                      prevDisabled={page < 2 || loading}
                      nextDisabled={!nextCursor || loading}
                    >
                      <button
                        type="button"
                        onClick={() => setChooserOpen((v) => !v)}
                        aria-expanded={chooserOpen}
                        className="mr-1 inline-flex h-7 items-center gap-1.5 rounded-sm border border-border bg-card px-2.5 text-xs transition-colors hover:bg-muted"
                      >
                        <Columns3 className="h-3.5 w-3.5" />
                        Columns
                      </button>
                    </TableFooter>
              }
            >
              <THead>
                <tr>
                  {columns.map((column) => (
                    <TH key={column.id} align={column.align === "right" ? "right" : undefined}>
                      {column.header}
                    </TH>
                  ))}
                </tr>
              </THead>
              <TBody>
                {rows.map((r) => (
                  <TR key={r.id}>
                    {columns.map((column, i) => (
                      <TD key={column.id} primary={i === 0} align={column.align === "right" ? "right" : undefined}>
                        <CdrCell column={column} row={r} detailHref={detailHref} />
                      </TD>
                    ))}
                  </TR>
                ))}
              </TBody>
            </Table>
          </div>

          <div className="flex flex-col gap-3 md:hidden">
            {rows.map((r) => (
              <Card key={r.id}>
                <CardContent className="space-y-2 py-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-medium tabular-nums">{r.destAddr ?? "—"}</p>
                      <Link
                        href={detailHref(r)}
                        className="text-sm text-muted-foreground hover:text-foreground"
                        suppressHydrationWarning
                      >
                        {formatTimestamp(r.submittedAt)}
                      </Link>
                    </div>
                    <Outcome row={r} />
                  </div>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                    <span className="text-muted-foreground">From</span>
                    <span className="text-right tabular-nums">{r.sourceAddr ?? "—"}</span>
                    <span className="text-muted-foreground">Account</span>
                    <span className="text-right">{r.accountId ?? "—"}</span>
                    <span className="text-muted-foreground">Vendor</span>
                    <span className="text-right">{r.vendor ?? "—"}</span>
                    <span className="text-muted-foreground">Billed</span>
                    <span className="text-right tabular-nums">
                      {r.price == null ? "—" : money(r.price)}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* below md: the cards above, and the same paging as the table's footer */}
          <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground md:hidden">
            <span>Page {page}</span>
            <span className="ml-auto flex flex-wrap gap-1">
              <Button variant="outline" size="sm" onClick={() => setChooserOpen((v) => !v)} aria-expanded={chooserOpen}>
                <Columns3 className="h-4 w-4" />
                Columns
              </Button>
              <Button variant="outline" size="sm" onClick={back} disabled={page < 2 || loading}>
                <ChevronLeft className="h-4 w-4" />
                Previous
              </Button>
              <Button variant="outline" size="sm" onClick={forward} disabled={!nextCursor || loading}>
                Next
                <ChevronRight className="h-4 w-4" />
              </Button>
            </span>
          </div>

          {chooserOpen && (
            <ColumnChooser
              columns={CDR_COLUMNS}
              groups={CDR_COLUMN_GROUPS}
              enabled={new Set(columns.map((c) => c.id))}
              onToggle={choose}
              onReset={resetColumns}
              /* a chooser that silently does nothing on a phone is worse than no chooser */
              note="On a narrow screen the cards below the table keep their fixed summary and ignore this."
            />
          )}
        </>
      )}

      <ExportsCard
        endpoint="/api/control/cdrs/export"
        params={toQuery(filters)}
        description={
          <>
            Prepared in the background and kept for seven days. The CSV carries every column of the
            record whatever is chosen above — two people exporting the same filters must get the same
            file, because spreadsheets address columns by letter.
          </>
        }
      />
    </>
  );
}

