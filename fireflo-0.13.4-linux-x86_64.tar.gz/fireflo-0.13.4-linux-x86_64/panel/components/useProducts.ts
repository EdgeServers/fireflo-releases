"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import type { ProductSummary } from "@/lib/product-types";

/**
 * Loading and editing the product catalogue.
 *
 * <p>Same shape as `useWorkers`, minus the gateway push: there is nothing to tell the gateway about.
 * It never reads `app_product`, so a change here is complete the moment the row is written and there
 * is no "within 30 seconds" to explain.
 */
export function useProducts() {
  const [products, setProducts] = useState<ProductSummary[]>([]);
  const [orphans, setOrphans] = useState<string[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/control/products", { cache: "no-store" });
      const json = await res.json();
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        setProducts([]);
      } else {
        setProducts(json.data.products as ProductSummary[]);
        setOrphans(json.data.orphans as string[]);
        setError("");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const act = useCallback(
    async (name: string, run: () => Promise<Response>) => {
      setBusy(name);
      try {
        const res = await run();
        if (!res.ok) {
          const json = await res.json().catch(() => null);
          setError(json?.error ?? `Request failed (${res.status})`);
          return false;
        }
        setError("");
        await load();
        return true;
      } catch (err) {
        setError(err instanceof Error ? err.message : "Request failed");
        return false;
      } finally {
        setBusy("");
      }
    },
    [load]
  );

  const setEnabled = useCallback(
    (name: string, enabled: boolean) =>
      act(name, () =>
        fetch(`/api/control/products/${encodeURIComponent(name)}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ enabled }),
        })
      ),
    [act]
  );

  const remove = useCallback(
    (name: string) =>
      act(name, () =>
        fetch(`/api/control/products/${encodeURIComponent(name)}`, { method: "DELETE" })
      ),
    [act]
  );

  return { products, orphans, error, loading, busy, load, setEnabled, remove, setError };
}

/**
 * Just the product names, for a dropdown.
 *
 * <p>Catalogue **and** orphans. An orphan is a product some login or rate already names without a
 * row in `app_product` — which is the normal state of anything imported, and precisely the product
 * an operator is most likely to be pricing. Offering the catalogue alone leaves it unpickable while
 * being visibly in use elsewhere. `AccountWhitelist` already merged the two by hand; this is that
 * line, named.
 *
 * <p>A component rendered once per row should not call this — it fetches on mount, so sixty vendor
 * cards would be sixty requests. Call it in the parent and pass the array down.
 */
export function useProductCatalogue(): string[] {
  const { products, orphans } = useProducts();
  return useMemo(
    () => [...new Set([...products.map((p) => p.name), ...orphans])].sort(),
    [products, orphans]
  );
}
