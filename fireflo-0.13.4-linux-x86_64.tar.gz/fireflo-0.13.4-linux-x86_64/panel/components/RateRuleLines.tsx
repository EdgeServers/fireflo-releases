"use client";
import type { ReactNode } from "react";
import { Badge } from "@/components/ui/badge";
import { type RateRule, describeRule } from "@/lib/rate-types";

/**
 * A scope's rate rules as sentences, in the order the gateway reads them.
 *
 * <p>The read-only half of every rate editor. Extracted because the pricing page and the vendor card
 * are the same list at two sizes, and a rule that renders differently depending on where it is read
 * is a rule two people will describe differently on a call about a bill.
 *
 * <p><strong>Sequence is shown, not implied by position.</strong> First match wins, so the number is
 * the rule's meaning rather than decoration — and a disabled rule keeps its place in the list because
 * removing it would silently renumber everything a reader is comparing against the gateway.
 */
export function RateRuleLines({
  rules,
  action,
}: {
  rules: RateRule[];
  /**
   * Per-row controls, when the surrounding page can change a rule.
   *
   * <p>A render prop rather than a `Rule -> void` callback because the vendor card needs three
   * different controls on a row and the pricing page needs none.
   */
  action?: (rule: RateRule, index: number) => ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      {rules.map((rule, index) => (
        <div
          key={rule.id}
          className="flex flex-wrap items-baseline gap-2 border-t border-border/50 py-1.5 text-sm first:border-t-0"
        >
          <span className="w-6 shrink-0 text-sm text-muted-foreground">{rule.seq}</span>
          <span className={rule.enabled ? "" : "text-muted-foreground line-through"}>
            {describeRule(rule)}
          </span>
          {!rule.enabled && <Badge variant="outline">retired</Badge>}
          {/* a named filter narrows this rule from somewhere else, so the sentence alone is not the
              whole condition -- see describeRule, which says so rather than reading as a catch-all */}
          {rule.filters.map((filter) => (
            <Badge key={filter} variant="default">{filter}</Badge>
          ))}
          {rule.label && <span className="text-sm text-muted-foreground">— {rule.label}</span>}
          {action && <span className="ml-auto flex shrink-0 items-center gap-1">{action(rule, index)}</span>}
        </div>
      ))}
    </div>
  );
}
