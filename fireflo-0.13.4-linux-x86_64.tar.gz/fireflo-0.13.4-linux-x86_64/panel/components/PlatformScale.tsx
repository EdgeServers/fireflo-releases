"use client";
import { setMoneyScale } from "@/lib/format";

/**
 * Tells `lib/format` how many decimal places this platform shows totals at.
 *
 * <p>Rendered near the top of both layouts, with the value read from `app_config` by the server
 * component above it. It renders nothing.
 *
 * <p><strong>The assignment is during render, on purpose.</strong> An effect would run only on the
 * client and only after the first paint, so the server would send four places, the browser would
 * hydrate at four, and then every amount on the page would reflow to two — a visible flicker on the
 * one number a customer opened the page to read. Doing it during render means the value is in place
 * before anything below this calls `money()`, on both sides, so the two agree.
 *
 * <p>It is a side effect in a render function, which React normally forbids for good reasons: React
 * may call a render more than once, and may discard the result. Both are fine here because the
 * assignment is idempotent and the value is the same every time — there is exactly one of these per
 * platform, the same argument `platform-currency.ts` makes about the currency. See `lib/format.ts`
 * for why this is module state rather than a context.
 */
export function PlatformScale({ scale }: { scale: number }) {
  setMoneyScale(scale);
  return null;
}
