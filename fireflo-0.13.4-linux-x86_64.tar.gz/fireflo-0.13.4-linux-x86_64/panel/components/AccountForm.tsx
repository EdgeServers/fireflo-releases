"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { SettingsRow, SettingsRows } from "@/components/ui/settings-row";
import { DisclosureSection } from "./DisclosureSection";
import { useConfirmChange } from "./ConfirmProvider";
import type { ChangeLine } from "@/lib/confirm-changes";
import type { AccountInput } from "@/lib/account-types";

/**
 * Who an account is, and the three switches that decide where it sits.
 *
 * <p>Six controls. It used to read as far more than that because each one carried a three-line
 * paragraph explaining a consequence — the prose ran to twice the length of the form, and the two
 * fields somebody actually edits were the two hardest to find. The explanations are all still true,
 * so none of them are deleted: the one-liner stays visible and the full version moves to `title`.
 *
 * <p>Name, email and notes are always open because they are what changes. Listing, reselling and
 * the parent are behind {@link DisclosureSection} — each is a decision made once at onboarding, and
 * two of them are dangerous to nudge while looking for the name field.
 *
 * <p>The badge on that section counts what is <em>set</em> rather than what is present, so a
 * collapsed section still tells you an account is unlisted or belongs to a reseller. Hiding that
 * silently is exactly how a form loses a setting.
 */
export function AccountForm({
  id,
  label: initialLabel,
  description: initialDescription,
  email: initialEmail,
  enabled: initialEnabled,
  resells: initialResells,
  parentAccountId: initialParent,
  childCount,
  busy,
  allowHierarchy = true,
  onSave,
  onReload,
}: {
  id: string;
  label: string;
  description: string;
  email: string;
  enabled: boolean;
  resells: boolean;
  parentAccountId: string | null;
  childCount: number;
  busy: boolean;
  /**
   * Whether to offer the Advanced section at all: listing, reselling and the parent.
   *
   * <p>False in the customer portal. Those are the three fields the write path pins rather than
   * accepts — `parent_account_id` is set from the session, `resells` is written FALSE as a literal,
   * and listing is changed by Suspend, which does the operational half as well. Rendering controls
   * the server would ignore is how a form comes to lie about what it did.
   *
   * <p>Defaults to true, so every operator caller is unchanged and stays that way on purpose.
   */
  allowHierarchy?: boolean;
  onSave: (input: AccountInput) => Promise<boolean>;
  onReload: () => void;
}) {
  //one object rather than six useStates. The old form kept six, and its Cancel reset four of them
  //-- `resells` and the parent survived a discard and were saved on the next click, which is a
  //silent wrong write on the two fields with database constraints behind them. Resetting one value
  //cannot go out of step with the fields the way six assignments did
  const seed = {
    label: initialLabel,
    description: initialDescription,
    email: initialEmail,
    enabled: initialEnabled,
    resells: initialResells,
    parent: initialParent ?? "",
  };
  const [form, setForm] = useState(seed);
  const confirm = useConfirmChange();
  const set = <K extends keyof typeof seed>(key: K, value: (typeof seed)[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  const dirty = (Object.keys(seed) as (keyof typeof seed)[]).some((k) => form[k] !== seed[k]);
  const canSave = !busy;
  //what the collapsed section is hiding, counted as "not the default" rather than "not empty":
  //unlisted is a set state even though the value is false
  const advancedSet = (form.enabled ? 0 : 1) + (form.resells ? 1 : 0) + (form.parent.trim() ? 1 : 0);
  const [advancedOpen, setAdvancedOpen] = useState(advancedSet > 0);

  return (
    <div className="space-y-4">
      <SettingsRows>
        <SettingsRow label="Name" htmlFor="acct-label">
          <Input id="acct-label" value={form.label} placeholder="Acme Communications"
            onChange={(e) => set("label", e.target.value)} />
        </SettingsRow>
        <SettingsRow
          label="Email"
          htmlFor="acct-email"
          help={allowHierarchy
            ? "The account's contact address, and a portal login. Passwords are set under Portal access."
            : "The customer's portal login. Without it, they cannot sign in."}
        >
          <Input id="acct-email" type="email" value={form.email} placeholder="ops@acme.com"
            title="The customer signs in to the portal with this address: by password, or by a
                   single-use link mailed to it. One account per address, ignoring case: a second
                   account with the same address is refused."
            onChange={(e) => set("email", e.target.value)} />
        </SettingsRow>
        {/* a note is read as a paragraph, so it runs under its label across the whole row rather
            than in the control column, where it showed four words a line (the user's call, 2026-10-22) */}
        <SettingsRow label="Notes" htmlFor="acct-desc" stacked>
          <Textarea
            id="acct-desc"
            rows={3}
            value={form.description}
            onChange={(e) => set("description", e.target.value)}
            placeholder="Anything the next operator should know"
          />
        </SettingsRow>
      </SettingsRows>

      {allowHierarchy && (
      <DisclosureSection
        title="Advanced"
        set={advancedSet}
        open={advancedOpen}
        onToggle={() => setAdvancedOpen((o) => !o)}
        note="Listing, reselling and the hierarchy. Set once at onboarding and rarely again."
      >
        <SettingsRows>
          <SettingsRow
            label="Enabled"
            labelId="acct-enabled"
            help="Off pauses the account: the gateway stops serving its logins within one configuration poll (30 s by default) and nobody can sign in to the portal for it. Binds already open stay up until they drop. To retire it for good, archive it instead (below)."
          >
            <div className="flex md:justify-end">
              <Switch checked={form.enabled} onChange={(v) => set("enabled", v)} aria-labelledby="acct-enabled" />
            </div>
          </SettingsRow>

          {/*
            An account either holds others or belongs to one — the database refuses the combination
            outright. Offering both and letting the save fail would be a form that invites a
            rejection, so each half disables the other.
          */}
          <SettingsRow
            label="Resells services"
            labelId="acct-resells"
            help={`Lets it hold other accounts and move balance to and from them.${childCount > 0
              ? ` Holds ${childCount} account${childCount === 1 ? "" : "s"}, so it cannot be switched off until they move.` : ""}`}
          >
            <div className="flex md:justify-end">
              <Switch checked={form.resells} disabled={form.parent.trim() !== ""} onChange={(v) => set("resells", v)} aria-labelledby="acct-resells" />
            </div>
          </SettingsRow>

          <SettingsRow
            label="Belongs to"
            htmlFor="acct-parent"
            help={form.resells
              ? "Unavailable while this account resells."
              : "The reseller above it, which must already be marked as reselling. Empty means top-level; there are exactly two levels."}
          >
            <Input id="acct-parent" value={form.parent} placeholder="reseller-a" className="font-mono"
              disabled={form.resells}
              onChange={(e) => set("parent", e.target.value)} />
          </SettingsRow>
        </SettingsRows>
      </DisclosureSection>
      )}

      {dirty && (
        <div className="flex gap-2">
          <Button disabled={!canSave}
            onClick={async () => {
              //what the save changes, named the way the form labels it
              const names: Record<keyof typeof seed, string> = {
                label: "Name", description: "Notes", email: "Email", enabled: "Enabled",
                resells: "Resells services", parent: "Belongs to",
              };
              const shown = (v: string | boolean) =>
                typeof v === "boolean" ? (v ? "yes" : "no") : v.trim() === "" ? "(empty)" : v;
              const changes: ChangeLine[] = (Object.keys(seed) as (keyof typeof seed)[])
                .filter((k) => form[k] !== seed[k])
                .map((k) => ({ label: names[k], from: shown(seed[k]), to: shown(form[k]) }));
              if (!(await confirm({
                title: "Save this account?",
                consequence: `Updates account ${id}.`,
                confirmLabel: "Save",
                changes,
              }))) {
                return;
              }
              if (await onSave({
                id,
                label: form.label,
                description: form.description,
                email: form.email,
                enabled: form.enabled,
                resells: form.resells,
                parentAccountId: form.parent.trim() || null,
              })) {
                onReload();
              }
            }}>
            {busy ? "Saving…" : "Save"}
          </Button>
          {/* one assignment, so a field added above cannot be forgotten here */}
          <Button variant="outline" disabled={busy} onClick={() => {
            setForm(seed);
          }}>
            Cancel
          </Button>
        </div>
      )}
    </div>
  );
}
