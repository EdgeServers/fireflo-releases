"use client";
import { useEffect, useRef, useState } from "react";
import { CardSection } from "@/components/ui/card";
import type { Health, HealthSession, HealthWorker } from "@/lib/health-types";
import { count, duration, percent } from "@/lib/format";
import { formatTps } from "@/lib/tps-format";
import { bindTotal, sessionsAreComplete, shareOf } from "@/lib/bind-summary";
import { hasCapability, SESSION_RECEIPTS } from "@/lib/capabilities";
import { groupSessions, overall, receiptRate, type AccountGroup } from "@/lib/session-groups";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { BindChips, Share } from "./SessionList";

/** The gateway's page cap for the sessions query; asking for more is clamped to this. */
const PAGE = 200;

/**
 * What each connected account is doing on this listener, right now.
 *
 * <p>MT is what the customer submitted on its binds and DLR is what the gateway delivered back
 * down them — receipts, and inbound messages — both counted by the gateway on the session since it
 * bound. The two sit side by side because the question an operator brings to a listener is
 * usually "is this customer getting their receipts", which neither the bind table nor the Messages
 * page answers at a glance: the one has no receipts column, the other is a period, not a now.
 *
 * <p>Overall first, so the listener's total reads before any one account's share of it. An account
 * row carries every bind of that account, open or receive-only, which is why its tps can be set
 * against the account's limit while a single bind's cannot.
 *
 * <p>Counters reset when a bind reconnects, and the health snapshot carries at most twenty
 * sessions per worker; a listener with more is walked through the paged query, on the same tick as
 * the snapshot, so the block never shows a sample as if it were the set.
 */
export function ListenerAccountTraffic({
  health,
  live,
}: {
  health: Health | null;
  live: HealthWorker | undefined;
}) {
  const supported = hasCapability(health, SESSION_RECEIPTS);
  const sessions = useAllSessions(live, health?.observed_at, supported);
  //nothing until the first health poll lands: without health there is no capability list, and
  //"needs gateway 0.13.2" would be said of every gateway for the first moment on the page
  if (!health) {
    return null;
  }
  if (!supported) {
    return (
      <CardSection title="Traffic by account">
        <p className="text-sm text-muted-foreground">
          Needs gateway 0.13.2 or later, which counts the receipts delivered down each bind.
        </p>
      </CardSection>
    );
  }
  if (!live || !sessions.length) {
    return null;
  }

  const groups = groupSessions(sessions);
  const total = overall(groups);
  const denominator = bindTotal(sessions);

  return (
    <CardSection
      title="Traffic by account"
      description="Counted on the binds since each one connected — MT is what the customer submitted, DLR is receipts delivered back to them."
    >
      <TableInCard>
        <THead>
          <TR>
            <TH>Account</TH>
            <TH>Binds</TH>
            <TH align="right">MT received</TH>
            <TH align="right">DLR delivered</TH>
            <TH align="right">tps</TH>
            <TH>Share</TH>
          </TR>
        </THead>
        <TBody className="tabular-nums">
          <Row group={total} denominator={denominator} overall />
          {groups.map((group) => (
            <Row key={group.account} group={group} denominator={denominator} />
          ))}
        </TBody>
      </TableInCard>
      <p className="text-xs text-muted-foreground">
        Resets when a bind reconnects
        {total.oldest != null && ` · oldest bind up ${duration(total.oldest)}`}
        {" · "}for a period, see Messages.
      </p>
    </CardSection>
  );
}

function Row({
  group,
  denominator,
  overall: isOverall = false,
}: {
  group: AccountGroup;
  denominator: number;
  overall?: boolean;
}) {
  const rate = receiptRate(group);
  const accounts = isOverall ? group.sessions.length : 0;
  return (
    <TR className={isOverall ? "bg-muted/40 font-medium" : undefined} data-account={group.account}>
      <TD className={isOverall ? "font-semibold" : "font-medium"}>
        {group.account}
        {isOverall && (
          <span className="font-normal text-muted-foreground">
            {" "}· {groupCount(group)} account{groupCount(group) === 1 ? "" : "s"}, {accounts} bind{accounts === 1 ? "" : "s"}
          </span>
        )}
      </TD>
      <TD><BindChips counts={group.counts} /></TD>
      <TD align="right">{group.received != null ? count(group.received) : "—"}</TD>
      <TD align="right">
        {group.receipts != null ? count(group.receipts) : "—"}
        {/* the rate only once something was submitted: "100%" of nothing is not a reading */}
        {rate != null && <span className="ml-1.5 text-muted-foreground">{percent(rate)}</span>}
      </TD>
      <TD align="right">
        {group.tps != null ? formatTps(group.tps) : "—"}
        {!isOverall && group.tpsLimit != null && (
          <span className="text-muted-foreground"> / ≤{group.tpsLimit}</span>
        )}
      </TD>
      <TD>
        <Share value={isOverall ? (denominator > 0 ? 1 : null) : shareOf(group.received, denominator)} />
      </TD>
    </TR>
  );
}

/** How many accounts an Overall row folds: the distinct names behind its sessions. */
function groupCount(group: AccountGroup): number {
  return new Set(group.sessions.map((s) => s.account?.trim() || "—")).size;
}

/**
 * Every session of the worker, whichever path it takes to get them.
 *
 * <p>When the snapshot already holds the whole set, that is the answer and nothing is fetched.
 * Above the snapshot's cap the paged query is walked, re-run on every change of `observedAt` so it
 * moves with the health poll rather than on a clock of its own; a stale walk is dropped when a
 * newer one lands, the same ticket pattern the session browser uses.
 */
function useAllSessions(
  live: HealthWorker | undefined,
  observedAt: string | undefined,
  enabled: boolean
): HealthSession[] {
  const sample = live?.sessions ?? [];
  const complete = !live || sessionsAreComplete(live.sessions_total, sample.length);
  const [walked, setWalked] = useState<{ worker: string; rows: HealthSession[] } | null>(null);
  const ticket = useRef(0);
  const worker = live?.name;

  useEffect(() => {
    if (!enabled || complete || !worker) {
      return;
    }
    const mine = ++ticket.current;
    let cancelled = false;
    (async () => {
      const rows: HealthSession[] = [];
      for (let offset = 0; ; offset += PAGE) {
        const res = await fetch(
          `/api/control/workers/${encodeURIComponent(worker)}/sessions?offset=${offset}&limit=${PAGE}`,
          { cache: "no-store" }
        ).catch(() => null);
        const json = await res?.json().catch(() => null);
        if (!res?.ok || !json?.data?.rows) {
          return;
        }
        rows.push(...(json.data.rows as HealthSession[]));
        if (rows.length >= (json.data.total ?? 0) || json.data.rows.length === 0) {
          break;
        }
      }
      if (!cancelled && mine === ticket.current) {
        setWalked({ worker, rows });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [enabled, complete, worker, observedAt]);

  if (complete) {
    return sample;
  }
  //until the first walk lands, the sample is a better answer than nothing: it is labelled by
  //the count beside it, and the walk replaces it within a tick
  return walked && walked.worker === worker ? walked.rows : sample;
}
