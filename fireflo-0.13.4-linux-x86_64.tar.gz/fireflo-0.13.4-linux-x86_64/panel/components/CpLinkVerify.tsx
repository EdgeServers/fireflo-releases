"use client";
import { useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { Card, CardContent } from "@/components/ui/card";
import { buttonClasses } from "@/components/ui/button";
import { OPERATOR_ROLES } from "@/lib/roles";

/**
 * Spends an operator's one-time link and signs the browser in -- when they press the button, not
 * when the page loads.
 *
 * <p>The operator twin of `MisVerify`, for the same reasons: mail link scanners open links in a
 * browser that runs JavaScript, so a page that redeemed on load spent the token before the person
 * clicked. Posts to this instance's own callback (`/api/auth`), never the portal's.
 */
export function CpLinkVerify() {
  const params = useSearchParams();
  const token = params.get("token");
  const [failed, setFailed] = useState(!token);
  const [busy, setBusy] = useState(false);
  const started = useRef(false);

  async function redeem() {
    if (started.current || !token) {
      return;
    }
    started.current = true;
    setBusy(true);
    try {
      const { csrfToken } = (await (await fetch("/api/auth/csrf")).json()) as { csrfToken: string };
      const res = await fetch("/api/auth/callback/magic-link", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ csrfToken, token, redirect: "false" }),
      });
      //fetch follows next-auth's redirect, so a rejected token shows as ?error= on the final URL,
      //and only a session with an operator role is a sign-in
      const error = new URL(res.url, window.location.origin).searchParams.get("error");
      const session = (await (await fetch("/api/auth/session")).json()) as { user?: { role?: string | null } | null };
      const role = session?.user?.role;
      if (!error && typeof role === "string" && OPERATOR_ROLES.includes(role)) {
        //a full navigation, like the login form: the dashboard shell reads the session server-side
        window.location.assign("/cp");
        return;
      }
      setFailed(true);
    } catch {
      setFailed(true);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="flex min-h-dvh items-center justify-center px-4">
      <Card className="w-full max-w-md">
        <CardContent className="space-y-3 py-8 text-center text-sm">
          {failed ? (
            <>
              <p className="font-medium">That link did not work.</p>
              <p className="text-muted-foreground">
                Sign-in links work once and expire after 15 minutes. Ask for a new one, or sign in with your password.
              </p>
              <Link href="/cp/login" className={buttonClasses({ variant: "outline", size: "sm" })}>
                Back to sign in
              </Link>
            </>
          ) : (
            <>
              <p className="font-medium">Finish signing in to the control panel.</p>
              <p className="text-muted-foreground">This link works once and expires after 15 minutes.</p>
              <button type="button" onClick={redeem} disabled={busy} className={buttonClasses({ className: "w-full" })}>
                {busy ? "Signing you in…" : "Sign in"}
              </button>
            </>
          )}
        </CardContent>
      </Card>
    </main>
  );
}
