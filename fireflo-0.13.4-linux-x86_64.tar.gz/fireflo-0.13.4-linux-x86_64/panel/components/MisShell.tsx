"use client";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { Activity, BookOpen, ChevronLeft, ChevronRight, FileText, MessageSquare, Receipt, Signature, Terminal, Users } from "lucide-react";
import { cn } from "@/lib/utils";
import { Sidebar, type NavGroup } from "./Sidebar";
import { TopBar, type QuickLink } from "./TopBar";
import { UserMenu } from "./UserMenu";
import { moneyFromBigintString, moneyScale } from "@/lib/format";
import { PortalNotice } from "@/components/PortalNotice";
import type { PortalMark } from "@/lib/brand";

/**
 * The portal frame: the same sidebar and top bar as the operator panel, with the customer's map.
 *
 * <p>It used to be its own layout -- a header, a nav card and an account card stacked in a column --
 * which meant two shells to keep in step. Now the pieces are shared and only the data differs:
 * the groups, the landing link, the brand (white-labelled), no version string (a fingerprint of
 * the platform underneath), the balance where the operator sees a person, and no gateway health
 * because a customer has no gateway page. Sign-out stays this file's: a CSRF-protected POST to the
 * portal's own auth endpoint, because `signOut` from next-auth/react is bound to the operator
 * instance's base path.
 */

export interface MisSummary {
  accountId: string;
  label: string | null;
  resells: boolean;
  children: { id: string; label: string | null }[];
  balance: { balance: string; currency: string | null } | null;
}

const overviewLink = { href: "/overview", label: "Overview", icon: Activity };

/**
 * What a customer can reach, in groups. Messages first inside its group: it is what they signed in
 * for. Customers, for an account that holds others, sits above Messaging because onboarding somebody
 * is a different visit from checking whether a message went out.
 */
function groupsFor(resells: boolean): NavGroup[] {
  return [
    ...(resells ? [{ label: "Customers", links: [{ href: "/accounts", label: "Accounts", icon: Users }] }] : []),
    {
      label: "Messaging",
      links: [
        { href: "/messages", label: "Messages", icon: MessageSquare },
        { href: "/senders", label: "Sender IDs", icon: Signature },
        { href: "/templates", label: "Templates", icon: FileText },
      ],
    },
    { label: "Billing", links: [{ href: "/statement", label: "Statement", icon: Receipt }] },
    {
      label: "Developer",
      links: [
        { href: "/playground", label: "API playground", icon: Terminal },
        { href: "/api-docs", label: "REST API reference", icon: BookOpen },
      ],
    },
  ];
}

/** The pages worth a tab in the top bar. Accounts only for a reseller: a non-reseller has no such link anywhere. */
function quickFor(resells: boolean): QuickLink[] {
  return [
    { href: "/messages", label: "Messages" },
    { href: "/statement", label: "Statement" },
    ...(resells ? [{ href: "/accounts", label: "Accounts" }] : []),
  ];
}

/**
 * Exact throughout the portal, unlike the operator panel's prefix rule: every page here is a leaf
 * with nothing below it, so a prefix match would only ever light the wrong row. Accounts is the
 * one exception, the only link with pages beneath it.
 */
function portalActive(href: string, pathname: string): boolean {
  return href === "/accounts" ? pathname.startsWith("/accounts") : pathname === href;
}

/** Remembered per browser. Its own key: a person who is both operator and customer keeps two choices. */
const COLLAPSED_KEY = "fireflo.mis.sidebar.collapsed";

export function MisShell({
  children,
  brand = "FireFlo",
  mark,
  copyright = "",
}: {
  children: React.ReactNode;
  /** Resolved on the server by the portal layout — see `lib/brand.ts`. */
  brand?: string;
  /** Resolved beside it: the operator's logo, the brand's initial, or FireFlo's flame. */
  mark?: PortalMark;
  /**
   * The footer notice, already resolved — see `portalCopyright`. Empty renders no footer.
   */
  copyright?: string;
}) {
  const [summary, setSummary] = useState<MisSummary | null>(null);
  const [collapsed, setCollapsed] = useState(false);
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  //closed when a link is followed, during render rather than in an effect -- see the same rule in
  //DashboardShell, where an effect left the menu open over the new page for a frame
  const [seenPathname, setSeenPathname] = useState(pathname);
  if (seenPathname !== pathname) {
    setSeenPathname(pathname);
    setOpen(false);
  }
  const scale = moneyScale();

  useEffect(() => {
    fetch("/api/mis/summary", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => setSummary(j?.data ?? null))
      .catch(() => setSummary(null));
  }, []);

  useEffect(() => {
    //read after mount, not during render: localStorage and matchMedia do not exist on the server
    const stored = window.localStorage.getItem(COLLAPSED_KEY);
    setCollapsed(stored != null ? stored === "1" : window.matchMedia("(max-width: 1023px)").matches);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  function toggleCollapsed() {
    const next = !collapsed;
    window.localStorage.setItem(COLLAPSED_KEY, next ? "1" : "0");
    setCollapsed(next);
  }

  const resells = summary?.resells ?? false;
  const groups = groupsFor(resells);
  const account = summary?.label ?? summary?.accountId ?? "…";
  const balance = summary?.balance
    ? `${moneyFromBigintString(summary.balance.balance, scale)} ${summary.balance.currency ?? ""}`.trim()
    : null;

  //the sidebar's footer: the account and what it has left, which is the thing the portal is opened
  //for. No row and zero are different states, and saying "0.0000" for the first is a confident lie
  const footer = (rail: boolean) => (
    <div className={cn("border-t border-border p-3", rail && "text-center")}>
      {rail ? (
        <p className="text-xs tabular-nums text-muted-foreground" title={balance ? `Balance ${balance}` : "Not on prepaid credit"}>
          {summary?.balance ? moneyFromBigintString(summary.balance.balance, 0) : "—"}
        </p>
      ) : (
        <>
          <p className="truncate text-xs font-semibold">{account}</p>
          <p className="font-mono text-xs text-muted-foreground">{summary?.accountId}</p>
          <p className="mt-2 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">Balance</p>
          {balance ? (
            <p className="text-title tabular-nums">{balance}</p>
          ) : (
            <p className="text-sm text-muted-foreground">Not on prepaid credit</p>
          )}
          {resells && summary && (
            <>
              <p className="mt-2 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">Your accounts</p>
              {summary.children.length ? (
                <ul className="mt-0.5 space-y-0.5">
                  {summary.children.map((c) => (
                    <li key={c.id} className="truncate text-xs">{c.label ?? c.id}</li>
                  ))}
                </ul>
              ) : (
                <p className="text-xs text-muted-foreground">None yet.</p>
              )}
            </>
          )}
        </>
      )}
    </div>
  );

  const sidebarProps = { groups, overview: overviewLink, brand, mark, version: "", isActive: portalActive };

  return (
    <div className="flex h-screen overflow-hidden">
      <div className="relative hidden shrink-0 md:flex">
        <Sidebar {...sidebarProps} collapsed={collapsed} footer={footer(collapsed)} />
        <button
          onClick={toggleCollapsed}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          aria-expanded={!collapsed}
          title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          className="absolute -right-3 top-[42px] z-30 flex h-6 w-6 items-center justify-center rounded-full border border-border bg-card text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
        >
          {collapsed ? <ChevronRight className="h-3.5 w-3.5" /> : <ChevronLeft className="h-3.5 w-3.5" />}
        </button>
      </div>

      <div
        className={`fixed inset-0 z-40 bg-black/50 backdrop-blur-sm transition-opacity duration-300 md:hidden ${
          open ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
        onClick={() => setOpen(false)}
        aria-hidden="true"
      />
      <div
        className={`fixed inset-y-0 left-0 z-50 transition-transform duration-300 ease-in-out md:hidden ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <Sidebar {...sidebarProps} onClose={() => setOpen(false)} footer={footer(false)} />
      </div>

      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <TopBar
          onMenuClick={() => setOpen(true)}
          quick={quickFor(resells)}
          brand={brand}
          mark={mark}
          trailing={
            <span className="hidden items-center gap-2 rounded-full border border-border px-3 py-1 text-xs md:flex">
              <span className="text-muted-foreground">Balance</span>
              <span className="font-semibold tabular-nums">{balance ?? "—"}</span>
            </span>
          }
          user={
            <UserMenu
              name={summary?.label ?? summary?.accountId ?? "Account"}
              role="customer"
              passwordHref="/password"
              healthHref={null}
              onSignOut={() => void signOut()}
            />
          }
        />
        {/* the phone's balance: one line, always in view, where the sidebar is a drawer */}
        <div className="flex items-baseline gap-3 border-b border-border bg-card px-4 py-2 text-sm md:hidden">
          <span className="min-w-0 truncate font-medium">{account}</span>
          <span className="ml-auto tabular-nums">
            {balance ? (
              <>
                <span className="text-2xs font-semibold uppercase tracking-wide text-muted-foreground">Balance </span>
                <span className="font-semibold">{balance}</span>
              </>
            ) : (
              <span className="text-muted-foreground">Not on prepaid credit</span>
            )}
          </span>
        </div>

        <main className="flex-1 overflow-y-auto bg-background">
          <div className="mx-auto w-full max-w-[1440px] space-y-5 p-4 md:p-6">
            {/* above the page content rather than in the chrome: a customer reads down from here */}
            <PortalNotice />
            {children}
            {/* no version here: on a white-labelled portal a version string is a fingerprint that
                identifies the platform underneath — the one thing this surface is built not to do */}
            {copyright && (
              <footer className="border-t border-border pt-4 text-xs text-muted-foreground">
                {copyright}
              </footer>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

/**
 * Ends the session properly: a CSRF-protected POST, not a link.
 *
 * <p>`signOut` from `next-auth/react` is bound to the operator instance's base path and would ask
 * the wrong endpoint. A plain `<a href>` to the signout route is a GET, which NextAuth answers with
 * a confirmation page rather than by clearing anything.
 */
async function signOut() {
  const { csrfToken } = await (await fetch("/api/mis/auth/csrf")).json();
  await fetch("/api/mis/auth/signout", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ csrfToken, callbackUrl: "/" }),
  });
  window.location.href = "/";
}
