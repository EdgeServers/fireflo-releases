"use client";
import { Fragment, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ArrowRight, ChevronDown, ChevronRight, ShieldAlert, ShieldCheck, ShieldOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from "@/components/ui/card";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { ErrorCard } from "./FormNotices";
import { ConfirmDialog } from "./ConfirmDialog";
import { Pager } from "./Pager";
import { SearchInput } from "./SearchInput";
import { GatewayIgnores } from "./GatewayIgnores";
import { useWhitelist } from "./useWhitelist";
import { WhitelistReview, WhitelistStatusBadge } from "./WhitelistReview";
import { TlvStamps } from "@/components/TlvStamps";
import { parseTlvCsv } from "@/lib/tlv-string";
import { rowTlvGaps, tlvGapFixes, tlvGapSummary, vendorsForProduct } from "@/lib/tlv-coverage";
import {
  MAX_VARIABLE, effectiveMode, previewTemplate, scanTemplate,
  type ApprovedHeader, type ApprovedTemplate, type TemplateScan, type WhitelistMode,
} from "@/lib/whitelist-types";
import type { WhitelistStatusFilter } from "@/lib/whitelist";
import { smsLength } from "@/lib/sms-length";
import { formatDate, formatTimestamp } from "@/lib/datetime";
import { StampList, TlvProposal } from "./RegistrationList";

const PAGE_SIZES = [25, 50, 100] as const;

/**
 * Every approved sender ID, or every approved template, across all accounts.
 *
 * <p>This page answers the question the account page cannot: *who else has this?*
 *
 * <h2>It used to be read-only, and that was two mistakes rather than one</h2>
 *
 * <p>The recorded reason was that approving belongs beside the enforcement switch and the count that
 * says whether enforcing is safe. Both of those are on this page now — the **Enforced** column is on
 * every row, and so are the TLV gap lines — so the objection has been answered by the page itself
 * rather than overruled.
 *
 * <p>The second mistake was quieter and was a live defect: this list never filtered to approved rows
 * and never showed the status, so a customer's *request* rendered here indistinguishable from an
 * approval. A page that exists to say who else has a sender ID was counting requests as answers.
 * That is why the badge and the pending filter arrive together with the review buttons: showing the
 * state is the fix, and deciding it here is what an operator does next.
 *
 * <p>Bulk **approve** only. A refusal has to carry a reason the customer is shown, so there is
 * nothing to apply in bulk — and the bulk path loops the same per-row PATCH rather than adding an
 * endpoint of its own, so each decision is recorded against its own reviewer and timestamp.
 */
export function WhitelistIndexClient({ kind }: { kind: "headers" | "templates" }) {
  const [query, setQuery] = useState("");
  //the request waits for a pause in typing: every keystroke would otherwise be a query
  const [asked, setAsked] = useState("");
  const [status, setStatus] = useState<WhitelistStatusFilter>("all");
  const [account, setAccount] = useState("");
  const [size, setSize] = useState<number>(PAGE_SIZES[0]);
  const [page, setPage] = useState(0);
  const [open, setOpen] = useState<Set<number>>(new Set());
  useEffect(() => {
    const t = setTimeout(() => setAsked(query.trim()), 300);
    return () => clearTimeout(t);
  }, [query]);
  //paged, filtered and ordered (pending first) by the server: this list is every account's, and it
  //grows without bound
  const { headers, templates, summaries, coverage, error, loading, busy, review, decideTlvs, meta } =
    useWhitelist(undefined, { kind, q: asked, status, account: account || null, page, size });
  const [picked, setPicked] = useState<Set<number>>(new Set());
  const [confirming, setConfirming] = useState(false);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [bulkError, setBulkError] = useState("");
  const [tlvError, setTlvError] = useState<Record<number, string>>({});

  const all = useMemo(() => {
    //`effectiveMode`, not an exact-then-fallback lookup: the gateway merges, so a product row
    //sitting at OFF under an enforcing account is enforcing. This page used to get that wrong
    const modeOf = (accountId: string, product: string) =>
      effectiveMode(summaries, accountId, product, kind === "headers" ? "header" : "content");

    //what a row will fail to put on the wire, so an operator can find every such row across every
    //account -- the question this page exists for and the account page cannot answer
    const gapsOf = (accountId: string, product: string, tlvs: string | null) => rowTlvGaps({
      tlvs, accountId, product,
      kind: kind === "headers" ? "header" : "content",
      mode: modeOf(accountId, product),
      //a message is stamped by both matches, so the other list counts as a supplier here too
      siblings: {
        mode: effectiveMode(summaries, accountId, product,
          kind === "headers" ? "content" : "header"),
        //the other list's approved, enabled rows on this page's accounts, which the server sends
        //beside the page since the page no longer holds that list
        tlvs: meta.siblings
          .filter((r) => r.accountId === accountId
            && (!product || !r.product || r.product === product))
          .map((r) => r.tlvs),
      },
      mandatory: coverage.mandatory,
      logins: coverage.logins,
      vendors: vendorsForProduct(coverage.vendors, product),
    });

    const common = (r: ApprovedHeader | ApprovedTemplate) => ({
      id: r.id,
      accountId: r.accountId,
      accountLabel: meta.accountLabels[r.accountId] ?? null,
      product: r.product,
      systemId: r.systemId,
      label: r.label,
      tlvs: r.tlvs,
      requestedTlvs: r.requestedTlvs,
      gaps: gapsOf(r.accountId, r.product, r.tlvs),
      enabled: r.enabled,
      status: r.status,
      mode: modeOf(r.accountId, r.product),
      requestedBy: r.requestedBy,
      requestNote: r.requestNote,
      reviewedBy: r.reviewedBy,
      reviewedAt: r.reviewedAt,
      reviewNote: r.reviewNote,
      updatedBy: r.updatedBy,
      updatedAt: r.updatedAt,
    });
    //already pending first, from the server, so a request is never paged out of sight
    return kind === "headers"
      ? headers.map((h) => ({ ...common(h), key: `h-${h.id}`, primary: h.header, body: null as string | null }))
      : templates.map((t) => ({ ...common(t), key: `t-${t.id}`, primary: t.name || "Untitled", body: t.body }));
  }, [kind, headers, templates, summaries, coverage, meta.siblings, meta.accountLabels]);

  const counts = meta.counts;
  //one page, as the server filtered it. Search covers the account, the sender ID or the template's
  //name and body, the stamps, the login and the product; a TLV gap is worked out per row from
  //configuration, so it is shown on the row but is not something the database can search
  const rows = all;
  const pages = Math.max(1, Math.ceil(meta.total / size));
  const reset = () => setPage(0);
  const noun = kind === "headers" ? "sender ID" : "template";

  //the summary strip's last figure: of the accounts with anything on this list, how many enforce it
  const enforcing = useMemo(() => {
    const which = kind === "headers" ? "header" : "content";
    const listed = summaries.filter((s) => (kind === "headers" ? s.headers : s.templates) > 0);
    const accounts = new Set(listed.map((s) => s.accountId));
    const on = new Set(listed
      .filter((s) => effectiveMode(summaries, s.accountId, s.product, which) === "ENFORCE")
      .map((s) => s.accountId));
    return { on: on.size, of: accounts.size };
  }, [kind, summaries]);
  const accountChoices = useMemo(
    () => [...new Set(summaries.map((s) => s.accountId))].sort(),
    [summaries]
  );

  //only pending rows can be picked, so the count on the button is always the number that will change
  const pickable = rows.filter((r) => r.status === "PENDING");
  const chosen = pickable.filter((r) => picked.has(r.id));
  const accounts = [...new Set(chosen.map((r) => r.accountId))].sort();

  function toggle(id: number) {
    setPicked((prev) => {
      const next = new Set(prev);
      if (!next.delete(id)) {
        next.add(id);
      }
      return next;
    });
  }

  function toggleOpen(id: number) {
    setOpen((prev) => {
      const next = new Set(prev);
      if (!next.delete(id)) {
        next.add(id);
      }
      return next;
    });
  }

  /**
   * One PATCH per row, in order, stopping at the first refusal.
   *
   * <p>Sequential rather than concurrent: each call refreshes the list, and a refusal part way
   * through has to leave the operator looking at what actually landed. Stopping means the rows
   * already approved stay approved and the rest keep their tick, so retrying is the same action.
   */
  async function approveChosen() {
    setBulkBusy(true);
    setBulkError("");
    for (const row of chosen) {
      const failure = await review(kind, row.id, "APPROVED");
      if (failure) {
        setBulkError(`${row.primary} on ${row.accountId}: ${failure}`);
        setBulkBusy(false);
        return;
      }
      setPicked((prev) => {
        const next = new Set(prev);
        next.delete(row.id);
        return next;
      });
    }
    setBulkBusy(false);
    setConfirming(false);
  }

  async function decide(id: number, accept: boolean) {
    const problem = await decideTlvs(kind, id, accept);
    setTlvError((prev) => ({ ...prev, [id]: problem ?? "" }));
  }

  const chips: { value: WhitelistStatusFilter; label: string; count: number }[] = [
    { value: "all", label: "All", count: counts.all },
    { value: "PENDING", label: "Waiting", count: counts.PENDING },
    { value: "REJECTED", label: "Refused", count: counts.REJECTED },
    { value: "APPROVED", label: "Approved", count: counts.APPROVED },
    { value: "WITHDRAWN", label: "Withdrawn", count: counts.WITHDRAWN },
  ];
  const columns = 7;

  return (
    <>
      <GatewayIgnores domain="whitelist" />
      <ErrorCard error={error} />

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
        <Figure label={kind === "headers" ? "Sender IDs" : "Templates"} value={counts.all} />
        <Figure label="Waiting" value={counts.PENDING} tone={counts.PENDING ? "warning" : undefined} />
        <Figure label="Refused" value={counts.REJECTED} />
        <Figure label="Withdrawn" value={counts.WITHDRAWN} />
        <Figure label="Accounts enforcing" value={`${enforcing.on} / ${enforcing.of}`} />
      </div>

      <Card>
        <CardHeader className="space-y-3">
          <div className="space-y-1.5">
            <CardTitle>
              {kind === "headers" ? "Approved sender IDs" : "Approved content"}
            </CardTitle>
            <CardDescription>
              {kind === "headers"
                ? "Every sender ID any account has had approved. A customer sending from anything else is refused, once their account is set to enforce."
                : "Every message body any account has had approved. Content that does not match one of these is refused, once their account is set to enforce."}
              {" "}Approve or refuse a request here, open a row for its history, or open the account for the full picture.
            </CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {/*the counts are on the chips rather than behind them: nobody should have to filter to
               find out that nothing is waiting*/}
            {chips.map((c) => (
              <Button key={c.value} type="button" size="sm"
                variant={status === c.value ? "default" : "outline"}
                aria-pressed={status === c.value}
                onClick={() => { setStatus(c.value); reset(); }}>
                {c.label}
                <span className="ml-1.5 tabular-nums opacity-80">{c.count}</span>
              </Button>
            ))}
            <div className="ml-auto flex flex-wrap items-center gap-2">
              <select
                aria-label="Account"
                className="h-8 rounded-md border border-input bg-background px-2 text-sm"
                value={account}
                onChange={(e) => { setAccount(e.target.value); reset(); }}
              >
                <option value="">Every account</option>
                {accountChoices.map((a) => <option key={a} value={a}>{a}</option>)}
              </select>
              <SearchInput
                value={query}
                onChange={(next) => { setQuery(next); reset(); }}
                placeholder={`account, ${noun} or stamp`}
                ariaLabel={`Search approved ${kind}`}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {chosen.length > 0 && (
            <div className="flex flex-wrap items-center gap-3 rounded-md border border-border bg-muted/40 px-3 py-2 text-sm">
              <span>
                {chosen.length} {chosen.length === 1 ? "request" : "requests"} selected
                {accounts.length > 1 && <> across {accounts.length} accounts</>}
              </span>
              <Button size="sm" className="h-6 px-2" disabled={bulkBusy}
                onClick={() => { setBulkError(""); setConfirming(true); }}>
                Approve selected
              </Button>
              <Button size="sm" variant="ghost" className="h-6 px-2"
                onClick={() => setPicked(new Set())}>
                Clear
              </Button>
              {/*no bulk refuse, and this says why rather than leaving somebody hunting for the button*/}
              <span className="text-muted-foreground">
                Refusing needs a reason the customer is shown, so it stays per row.
              </span>
            </div>
          )}

          {!rows.length ? (
            <p className="py-6 text-center text-sm text-muted-foreground">
              {loading
                ? "Loading…"
                : status !== "all" || account || asked
                  ? `No ${noun}s match these filters.`
                  : `No ${noun}s have been approved yet. Open an account to approve one.`}
            </p>
          ) : (
            <TableInCard>
              <THead>
                <TR>
                  <TH className="w-8" />
                  <TH>{kind === "headers" ? "Sender ID" : "Template"}</TH>
                  <TH>Account</TH>
                  {kind === "headers" ? <TH>Scope</TH> : <TH>Variables</TH>}
                  {kind === "headers" ? <TH>Stamps</TH> : <TH>Length</TH>}
                  <TH>Asked by</TH>
                  <TH>Review</TH>
                </TR>
              </THead>
              <TBody>
                {rows.map((r) => {
                  const expanded = open.has(r.id);
                  const scan = r.body !== null ? scanTemplate(r.body) : null;
                  const length = r.body !== null ? smsLength(previewTemplate(r.body)) : null;
                  return (
                    <Fragment key={r.key}>
                      {/*a template's text runs on the row under it, full width: squeezed into its
                         own column it wrapped a word a line*/}
                      <TR className={scan ? "border-b-0" : undefined}>
                        <TD>
                          {r.status === "PENDING" ? (
                            <input
                              type="checkbox"
                              className="h-3.5 w-3.5 rounded border-input accent-primary"
                              checked={picked.has(r.id)}
                              onChange={() => toggle(r.id)}
                              aria-label={`Select ${r.primary} on ${r.accountId}`}
                            />
                          ) : (
                            <button type="button" onClick={() => toggleOpen(r.id)}
                              aria-expanded={expanded}
                              aria-label={`${expanded ? "Hide" : "Show"} details of ${r.primary}`}
                              className="text-muted-foreground hover:text-foreground">
                              {expanded
                                ? <ChevronDown className="h-4 w-4" aria-hidden="true" />
                                : <ChevronRight className="h-4 w-4" aria-hidden="true" />}
                            </button>
                          )}
                        </TD>
                        <TD>
                          <button type="button" onClick={() => toggleOpen(r.id)}
                            className="text-left hover:underline">
                            <span className={kind === "headers" ? "font-mono" : "font-medium"}>
                              {r.primary}
                            </span>
                          </button>
                          {/*says nothing for an ordinary approved row, so only the states that
                             matter carry a badge*/}
                          <span className="ml-2 inline-block align-middle">
                            <WhitelistStatusBadge status={r.status} enabled={r.enabled} />
                          </span>
                          {r.label && <span className="block text-xs text-muted-foreground">{r.label}</span>}
                          {r.gaps.length > 0 && (
                            <span className="block text-xs text-warning">
                              {r.gaps.length === 1 ? "1 stamp missing" : `${r.gaps.length} stamps missing`}
                            </span>
                          )}
                        </TD>
                        <TD>
                          <Link href={`/cp/accounts/${encodeURIComponent(r.accountId)}`}
                            className="whitespace-nowrap font-mono text-sm hover:underline">
                            {r.accountId}
                          </Link>
                          {r.accountLabel && (
                            <span className="block whitespace-nowrap text-xs text-muted-foreground">{r.accountLabel}</span>
                          )}
                          <span className="block"><ModeBadge mode={r.mode} small /></span>
                        </TD>
                        {kind === "headers" ? (
                          <TD>
                            <span className="whitespace-nowrap text-sm">{r.product || "all products"}</span>
                            <span className="block whitespace-nowrap font-mono text-xs text-muted-foreground">
                              {r.systemId ? `login ${r.systemId} only` : "every login"}
                            </span>
                          </TD>
                        ) : (
                          <TD>
                            <span className="tabular-nums">{scan?.names.length ?? 0}</span>
                            {scan && scan.names.length > 0 && (
                              <span className="block text-xs text-muted-foreground">
                                {[...new Set(scan.names.map(variableKind))].join(", ")}
                              </span>
                            )}
                          </TD>
                        )}
                        {kind === "headers" ? (
                          <TD>
                            {r.tlvs
                              ? <TlvStamps pairs={parseTlvCsv(r.tlvs)} subject={r.primary} />
                              : <span className="text-xs text-muted-foreground">none</span>}
                            {r.requestedTlvs && (
                              <span className="block text-xs text-warning">change proposed</span>
                            )}
                          </TD>
                        ) : (
                          <TD>
                            {length && (
                              <>
                                <span className="whitespace-nowrap tabular-nums">{length.chars} chars</span>
                                <span className={`block whitespace-nowrap text-xs ${length.encoding === "Unicode" || length.parts > 1 ? "text-warning" : "text-muted-foreground"}`}>
                                  {length.encoding} · {length.parts} {length.parts === 1 ? "part" : "parts"}
                                </span>
                              </>
                            )}
                          </TD>
                        )}
                        <TD>
                          <span className="text-sm">{r.requestedBy ?? "operator"}</span>
                          <span className="block text-xs text-muted-foreground">
                            {r.requestedBy ? "the customer asked" : "added here"}
                          </span>
                        </TD>
                        <TD>
                          {r.status === "PENDING" ? (
                            <WhitelistReview
                              status={r.status}
                              busy={busy === String(r.id)}
                              onDecide={async (next, note) => {
                                //the refusal lands in the hook's own error, which ErrorCard renders
                                //at the top of the page -- there is nowhere in a table row to put it
                                await review(kind, r.id, next, note);
                              }}
                            />
                          ) : (
                            <>
                              <span className="text-sm">{r.reviewedAt ? formatDate(r.reviewedAt) : "—"}</span>
                              <span className="block text-xs text-muted-foreground">
                                {r.reviewedBy ?? (r.status === "APPROVED" ? "approved when added" : "")}
                              </span>
                              {r.status === "REJECTED" && r.reviewNote && (
                                <span className="block text-xs text-destructive">“{r.reviewNote}”</span>
                              )}
                            </>
                          )}
                        </TD>
                      </TR>
                      {scan && (
                        <TR>
                          <TD />
                          <TD colSpan={columns - 1} className="pt-0">
                            <TemplateBody scan={scan} clamp={!expanded} />
                          </TD>
                        </TR>
                      )}
                      {expanded && (
                        <TR>
                          <TD colSpan={columns} className="bg-muted/40">
                            <RowDetail
                              row={r}
                              kind={kind}
                              busy={busy === String(r.id)}
                              tlvError={tlvError[r.id]}
                              onDecideTlvs={(accept) => void decide(r.id, accept)}
                            />
                          </TD>
                        </TR>
                      )}
                    </Fragment>
                  );
                })}
              </TBody>
            </TableInCard>
          )}

          <div className="flex flex-wrap items-center justify-between gap-2">
            <Pager page={meta.page} pages={pages} total={meta.total} noun={`${noun}s`} busy={loading} onPage={setPage} />
            <label className="flex items-center gap-2 text-xs text-muted-foreground">
              Rows per page
              <select
                className="h-7 rounded-md border border-input bg-background px-1.5 text-xs"
                value={size}
                onChange={(e) => { setSize(Number(e.target.value)); reset(); }}
              >
                {PAGE_SIZES.map((n) => <option key={n} value={n}>{n}</option>)}
              </select>
            </label>
          </div>

          <p className="text-sm text-muted-foreground">
            These are the only catalogues in this panel the gateway actually reads. A change here
            reaches it on its next configuration poll and can stop a customer sending — unlike
            products, TLV names or account labels, which are for the people reading this panel.
          </p>
        </CardContent>
      </Card>

      <ConfirmDialog
        open={confirming}
        title={`Approve ${chosen.length} ${chosen.length === 1 ? noun : `${noun}s`}`}
        consequence={
          `${chosen.length} ${chosen.length === 1 ? "registration" : "registrations"} on `
          + `${accounts.join(", ")} go into service at the gateway's next configuration poll. `
          + "Each is recorded against you individually."
        }
        confirmLabel="Approve"
        tone="primary"
        busy={bulkBusy}
        error={bulkError}
        onConfirm={approveChosen}
        onCancel={() => setConfirming(false)}
      />
    </>
  );
}

/** A figure for the whole list, above the table. */
function Figure({ label, value, tone }: { label: string; value: number | string; tone?: "warning" }) {
  return (
    <div className="rounded-md border border-border bg-card px-3 py-2">
      <span className="block text-xs text-muted-foreground">{label}</span>
      <span className={`block text-title font-medium tabular-nums ${tone === "warning" ? "text-warning" : ""}`}>
        {typeof value === "number" ? value.toLocaleString() : value}
      </span>
    </div>
  );
}

/** What a `{#…#}` gap accepts, in a word. */
function variableKind(name: string): string {
  return name === "num" ? `digits ≤ ${MAX_VARIABLE}` : name === "alp" ? `letters ≤ ${MAX_VARIABLE}` : `text ≤ ${MAX_VARIABLE}`;
}

/** The body as the gateway matches it, each gap marked where it sits. */
function TemplateBody({ scan, clamp = false }: { scan: TemplateScan; clamp?: boolean }) {
  return (
    <span className={`block break-words font-mono text-xs text-muted-foreground ${clamp ? "line-clamp-2" : ""}`}>
      {scan.parts.map((part, i) => (
        <Fragment key={i}>
          {part}
          {i < scan.names.length && (
            <span className="rounded bg-primary/10 px-1 text-primary">{`{#${scan.names[i]}#}`}</span>
          )}
        </Fragment>
      ))}
    </span>
  );
}

interface DetailRow {
  primary: string;
  accountId: string;
  status: string;
  enabled: boolean;
  tlvs: string | null;
  requestedTlvs: string | null;
  requestedBy: string | null;
  requestNote: string | null;
  reviewedBy: string | null;
  reviewedAt: string | null;
  reviewNote: string | null;
  updatedBy: string | null;
  updatedAt: string | null;
  gaps: ReturnType<typeof rowTlvGaps>;
}

/** Everything a row knows, opened under it: the request, the stamps on the wire, the history. */
function RowDetail({ row, kind, busy, tlvError, onDecideTlvs }: {
  row: DetailRow;
  kind: "headers" | "templates";
  busy: boolean;
  tlvError?: string;
  onDecideTlvs: (accept: boolean) => void;
}) {
  return (
    <div className="grid gap-4 py-1 md:grid-cols-3">
      <div className="min-w-0 space-y-1">
        <p className="text-xs uppercase tracking-wide text-muted-foreground">Request</p>
        {row.requestedBy ? (
          <>
            <p className="text-sm">Asked for by {row.requestedBy}</p>
            {row.requestNote
              ? <p className="text-sm">“{row.requestNote}”</p>
              : <p className="text-xs text-muted-foreground">No note with the request.</p>}
          </>
        ) : (
          <p className="text-sm">Added by an operator{row.updatedBy ? ` (${row.updatedBy})` : ""}.</p>
        )}
      </div>
      <div className="min-w-0 space-y-1.5">
        <p className="text-xs uppercase tracking-wide text-muted-foreground">Stamps on the wire</p>
        {row.tlvs ? <StampList tlvs={row.tlvs} /> : (
          <p className="text-xs text-muted-foreground">None: this {kind === "headers" ? "sender ID" : "template"} stamps no TLVs.</p>
        )}
        {row.requestedTlvs && (
          <TlvProposal current={row.tlvs} proposed={row.requestedTlvs} busy={busy}
            error={tlvError || undefined} onDecide={onDecideTlvs} />
        )}
        {row.gaps.map((gap) => (
          <p key={`${gap.tag}-${gap.reason}`} className="text-xs text-warning">
            {tlvGapSummary(gap)}
            {tlvGapFixes(gap).map((fix) => (
              <Link key={fix.href} href={fix.href}
                className="ml-1.5 font-semibold text-primary underline-offset-2 hover:underline">
                {fix.label} →
              </Link>
            ))}
          </p>
        ))}
      </div>
      <div className="min-w-0 space-y-1">
        <p className="text-xs uppercase tracking-wide text-muted-foreground">History</p>
        {row.reviewedAt && (
          <p className="text-sm">
            {row.status === "REJECTED" ? "Refused" : "Approved"} {formatTimestamp(row.reviewedAt)}
            {row.reviewedBy ? ` by ${row.reviewedBy}` : ""}
          </p>
        )}
        {row.reviewNote && <p className="text-sm">“{row.reviewNote}”</p>}
        {row.updatedAt && (
          <p className="text-sm">
            Last changed {formatTimestamp(row.updatedAt)}{row.updatedBy ? ` by ${row.updatedBy}` : ""}
          </p>
        )}
        <p className="text-xs text-muted-foreground">
          {row.status === "APPROVED" && row.enabled
            ? "In service: the gateway serves it."
            : row.status === "APPROVED"
              ? "Withdrawn: approved, but the gateway does not serve it."
              : row.status === "PENDING"
                ? "Waiting: stored, and inert until approved."
                : "Refused: the gateway does not serve it."}
        </p>
        <Link href={`/cp/accounts/${encodeURIComponent(row.accountId)}`}
          className="inline-flex items-center whitespace-nowrap text-sm text-primary hover:underline">
          Manage on the account
          <ArrowRight className="ml-1 inline h-3 w-3" aria-hidden="true" />
        </Link>
      </div>
    </div>
  );
}

function ModeBadge({ mode, small = false }: { mode: WhitelistMode; small?: boolean }) {
  const size = small ? "text-xs" : "text-sm";
  if (mode === "ENFORCE") {
    return (
      <span className={`inline-flex items-center gap-1.5 whitespace-nowrap ${size}`}>
        <ShieldCheck className="h-3.5 w-3.5 text-success" />
        Enforced
      </span>
    );
  }
  if (mode === "REPORT") {
    return (
      <span className={`inline-flex items-center gap-1.5 whitespace-nowrap ${size}`}>
        <ShieldAlert className="h-3.5 w-3.5 text-warning" />
        Report only
      </span>
    );
  }
  return (
    <span className={`inline-flex items-center gap-1.5 whitespace-nowrap text-muted-foreground ${size}`}>
      <ShieldOff className="h-3.5 w-3.5" />
      Not checked
    </span>
  );
}
