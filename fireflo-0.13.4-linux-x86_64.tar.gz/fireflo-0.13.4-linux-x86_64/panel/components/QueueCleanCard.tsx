"use client";
import { useState } from "react";
import { useSession } from "next-auth/react";
import { Archive, Search, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import { useWorkerNames } from "@/components/CdrFilterBar";
import { QueueCleanDialog, cleanCall } from "@/components/QueueCleanDialog";
import { FILTER_WIDTH } from "@/lib/filter-widths";
import { count } from "@/lib/format";
import { formatTimestamp } from "@/lib/datetime";
import { isAdminSession } from "@/lib/roles";
import {
  CLEAN_STORES,
  EMPTY_SELECTOR,
  SUB_STORE_LABEL,
  matchSummary,
  selectorProblem,
  type CleanSelector,
  type CleanStore,
  type HousekeepingResult,
} from "@/lib/queue-clean";

/** The Store control's choices: a store, or a store and one of its sub-stores. */
const STORE_CHOICES: { value: string; label: string }[] = [
  ...CLEAN_STORES.worker.map((sub) => ({ value: `worker:${sub}`, label: `Vendor / listener · ${SUB_STORE_LABEL[sub]}` })),
  { value: "worker:", label: "Vendor / listener · everything waiting" },
  ...CLEAN_STORES.routing.map((sub) => ({ value: `routing:${sub}`, label: `Routing · ${SUB_STORE_LABEL[sub]}` })),
  { value: "receipts:", label: "Unpushed receipts" },
  { value: "callbacks:", label: "Callback retries" },
];

/**
 * Clean up on the Queues page: pick what, see exactly what matches (a dry run — nothing is taken),
 * then Archive & clean in the confirm dialog. The same endpoint the command line uses.
 *
 * <p>Anyone who may read the queues may run the dry run; the button that ends messages is shown to
 * admins only, and the route refuses everyone else regardless.
 */
export function QueueCleanCard() {
  const { data: session } = useSession();
  const admin = isAdminSession(session);
  const names = useWorkerNames();
  const [selector, setSelector] = useState<CleanSelector>(EMPTY_SELECTOR);
  const [shown, setShown] = useState<{ selector: CleanSelector; result: HousekeepingResult } | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [cleaning, setCleaning] = useState(false);

  const set = <K extends keyof CleanSelector>(key: K, value: CleanSelector[K]) => setSelector((s) => ({ ...s, [key]: value }));

  async function show(sel: CleanSelector) {
    const problem = selectorProblem(sel);
    if (problem) {
      setError(problem);
      setShown(null);
      return;
    }
    setBusy(true);
    setError("");
    const r = await cleanCall(sel, { dryRun: true });
    setBusy(false);
    if ("error" in r) {
      setError(r.error);
      setShown(null);
    } else {
      setShown({ selector: sel, result: r.result });
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          <Archive className="mr-2 inline h-4 w-4 text-muted-foreground" />
          Clean up
        </CardTitle>
        <CardDescription>
          Archive and end messages that will never be sent. Each is refunded if charged, gets a failed receipt where
          one was asked for, and is recorded as refused (operatorPurge) — for good. Stop sending or Hold on the vendor
          is the first tool if you only need it to stop. Show is a dry run: it takes nothing.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <form
          className="flex flex-wrap items-end gap-3"
          onSubmit={(e) => {
            e.preventDefault();
            void show(selector);
          }}
        >
          <Field label="Store" className="w-72">
            <Select
              value={`${selector.store}:${selector.subStore}`}
              onChange={(e) => {
                const [store, sub] = e.target.value.split(":");
                setSelector((s) => ({ ...s, store: store as CleanStore, subStore: sub ?? "" }));
              }}
            >
              {STORE_CHOICES.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
            </Select>
          </Field>
          <Field label="Vendor or listener" className={FILTER_WIDTH.text}>
            <Input value={selector.worker} onChange={(e) => set("worker", e.target.value)} placeholder="any" list="clean-workers" />
            <datalist id="clean-workers">
              {[...names.vendors, ...names.servers].map((n) => <option key={n} value={n} />)}
            </datalist>
          </Field>
          <Field label="Account" className={FILTER_WIDTH.account}>
            <Input value={selector.account} onChange={(e) => set("account", e.target.value)} placeholder="exact" />
          </Field>
          <Field label="System id" className={FILTER_WIDTH.account}>
            <Input value={selector.systemId} onChange={(e) => set("systemId", e.target.value)} placeholder="exact" />
          </Field>
          <Field label="Older than" className={FILTER_WIDTH.select}>
            <Input value={selector.olderThan} onChange={(e) => set("olderThan", e.target.value)} placeholder="2h, 3d…" />
          </Field>
          <label className="flex h-9 items-center gap-2 text-sm">
            <input type="checkbox" checked={selector.all} onChange={(e) => set("all", e.target.checked)} />
            Every account
          </label>
          <Button type="submit" variant="outline" className="gap-2" disabled={busy}>
            <Search className="h-4 w-4" /> {busy ? "Counting…" : "Show"}
          </Button>
          {admin && (
            <Button
              type="button"
              className="gap-2 bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={!shown || shown.result.matched === 0 || busy}
              onClick={() => setCleaning(true)}
            >
              Archive &amp; clean…
            </Button>
          )}
        </form>

        {error && (
          <p className="flex items-start gap-2 text-sm text-destructive">
            <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" /> {error}
          </p>
        )}

        {shown && (
          <>
            <p className="text-sm font-medium">{matchSummary(shown.selector.store, shown.result)}</p>
            {shown.result.sample.length > 0 && (
              <TableInCard>
                <THead>
                  <TR>
                    <TH>Queued</TH>
                    <TH>Account</TH>
                    <TH>Where</TH>
                    <TH>From</TH>
                    <TH>To</TH>
                    <TH>Tries</TH>
                    <TH align="right">Price</TH>
                  </TR>
                </THead>
                <TBody>
                  {shown.result.sample.map((e, i) => (
                    <TR key={`${e.serial ?? ""}-${i}`}>
                      <TD muted className="whitespace-nowrap">{e.queuedAt ? formatTimestamp(e.queuedAt) : "—"}</TD>
                      <TD className="font-mono">{e.account || "—"}</TD>
                      <TD className="font-mono text-xs">
                        {e.worker || e.systemId || "—"}
                        {e.subStore && <span className="text-muted-foreground"> · {e.subStore}</span>}
                      </TD>
                      <TD className="font-mono">{e.from || "—"}</TD>
                      <TD className="font-mono">{e.to || "—"}</TD>
                      <TD>{e.retries ?? "—"}</TD>
                      <TD align="right" className="font-mono">{e.price ?? "—"}</TD>
                    </TR>
                  ))}
                </TBody>
              </TableInCard>
            )}
            {shown.result.matched > shown.result.sample.length && shown.result.sample.length > 0 && (
              <p className="text-xs text-muted-foreground">
                A sample of {count(shown.result.sample.length)} of the {count(shown.result.matched)} that match. The queue
                keeps moving while you read, so the dialog counts again before anything is archived.
              </p>
            )}
            {!admin && shown.result.matched > 0 && (
              <p className="text-xs text-muted-foreground">Archiving is for admins: ask one to run it.</p>
            )}
          </>
        )}
      </CardContent>

      {cleaning && shown && (
        <QueueCleanDialog
          selector={shown.selector}
          title="Archive & clean"
          onClose={() => setCleaning(false)}
          onDone={() => void show(shown.selector)}
        />
      )}
    </Card>
  );
}
