"use client";
import { useState } from "react";

/**
 * Client-side paging over a list already in hand.
 *
 * <p>The same eight lines were written out in `WhitelistIndexClient`, `ProductDetailClient`,
 * `AccountsCatalogueClient` and `ProductPricingTable`, and one of the four had a fix the others
 * lacked. This is that one.
 *
 * <p><strong>The clamp is the whole reason to share it.</strong> A page index is state, and the row
 * count is not: type into a search box while on page 3 and the list can shrink to one page, leaving
 * `page` pointing past the end and the table rendering nothing at all — a blank card that reads as
 * "no matches" for a query that matched. Clamping on read rather than resetting on change keeps the
 * operator's place when the list grows back.
 *
 * <p>Deliberately does not own the filtering. What counts as a match differs per table, and a hook
 * that took a predicate would end up taking a comparator and a key extractor too.
 */
export function usePaging<T>(rows: readonly T[], size: number) {
  const [page, setPage] = useState(0);

  const pages = Math.max(1, Math.ceil(rows.length / size));
  //read-time clamp, so a filter that shrinks the list cannot strand the reader on an empty page
  const clamped = Math.min(page, pages - 1);
  const shown = rows.slice(clamped * size, (clamped + 1) * size);

  return {
    /** Already clamped: render this, not the raw state. */
    page: clamped,
    pages,
    shown,
    setPage,
    /** For a filter change, where staying on page 4 of 1 would be worse than losing the place. */
    reset: () => setPage(0),
  };
}
