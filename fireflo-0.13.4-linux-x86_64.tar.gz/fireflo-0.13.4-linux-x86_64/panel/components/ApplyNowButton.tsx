"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { reloadNotice, type ReloadNotice, type ReloadResult } from "@/lib/reload";

/** How long the answer stays beside the button. */
const NOTICE_MS = 8_000;

/**
 * Asks the gateway to re-read its configuration now rather than at its next poll.
 *
 * <p>The gateway replaces its routing, pricing, filter and login snapshots every thirty seconds;
 * this is the same reload the Servers and Vendors pages offer, for the pages where people wait
 * for a rule to take effect. There is no cache to clear -- a reload is one poll, done now -- and
 * on a gateway whose licence has lapsed it says so instead of claiming success.
 *
 * <p>`compact` is the form that follows a save: a sentence with the button inside it.
 */
export function ApplyNowButton({ compact = false, className }: { compact?: boolean; className?: string }) {
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<ReloadNotice | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);

  async function apply() {
    setBusy(true);
    setNotice(null);
    let next: ReloadNotice;
    try {
      const res = await fetch("/api/control/reload", { method: "POST" });
      const json = (await res.json().catch(() => null)) as { data?: ReloadResult; error?: string } | null;
      next = res.ok ? reloadNotice(json?.data ?? null) : reloadNotice(null, json?.error ?? `Request failed (${res.status})`);
    } catch (err) {
      next = reloadNotice(null, err instanceof Error ? err.message : "Request failed");
    }
    setBusy(false);
    setNotice(next);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setNotice(null), NOTICE_MS);
  }

  const button = (
    <Button variant="outline" size={compact ? "sm" : "default"} className="gap-2" onClick={() => void apply()} disabled={busy}
      title="The gateway re-reads routing, pricing, filters and logins now instead of at its next poll (every 30 s).">
      <RefreshCw className={cn("h-4 w-4", busy && "animate-spin")} aria-hidden="true" />
      {busy ? "Reloading…" : "Apply now"}
    </Button>
  );

  return (
    <span className={cn("inline-flex flex-wrap items-center gap-2", className)}>
      {compact && !notice && <span className="text-sm text-muted-foreground">Saved. The gateway applies it within 30 s —</span>}
      {button}
      {notice && <NoticeText notice={notice} />}
    </span>
  );
}

function NoticeText({ notice }: { notice: ReloadNotice }) {
  return (
    <span role="status" className={cn("text-sm",
      notice.tone === "ok" ? "text-success" : notice.tone === "warning" ? "text-warning" : "text-destructive")}>
      {notice.text}
      {notice.href && <> <Link href={notice.href} className="underline">{notice.hrefLabel ?? "Open"}</Link></>}
    </span>
  );
}
