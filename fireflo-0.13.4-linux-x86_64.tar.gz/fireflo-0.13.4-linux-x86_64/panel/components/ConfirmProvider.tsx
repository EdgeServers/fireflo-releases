"use client";
import { createContext, useCallback, useContext, useRef, useState } from "react";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { DELETE_WORD, type ChangeLine } from "@/lib/confirm-changes";

/**
 * Every change on the vendor, server, account, pricing and routing screens is confirmed in a modal
 * before it is sent, and every delete there asks for {@link DELETE_WORD} to be typed.
 *
 * <p>One dialog for the whole panel, raised by `await confirm({...})` immediately before the request
 * a handler already makes -- so a handler gains one line and keeps its shape, rather than every
 * button growing its own open/closed state. Cancel resolves false and nothing is sent.
 */
export interface ConfirmOptions {
  title: string;
  /** What happens, named: which vendor, which account, what stops. */
  consequence: string;
  confirmLabel: string;
  /** Primary for an ordinary change, caution for traffic and money, destructive for a delete. */
  tone?: "primary" | "caution" | "destructive";
  changes?: readonly ChangeLine[];
  /** The word to type before confirming; `useConfirmDelete` sets it to DELETE for every delete. */
  typeToConfirm?: string;
}

type Ask = (options: ConfirmOptions) => Promise<boolean>;

const ConfirmContext = createContext<Ask | null>(null);

export function ConfirmProvider({ children }: { children: React.ReactNode }) {
  const [current, setCurrent] = useState<ConfirmOptions | null>(null);
  const resolver = useRef<((ok: boolean) => void) | null>(null);

  const ask = useCallback<Ask>((options) => {
    //a second confirmation while one is open answers the first "no": two at once is not a state
    //worth being able to reach, and the newer one is what the operator just clicked
    resolver.current?.(false);
    setCurrent(options);
    return new Promise<boolean>((resolve) => {
      resolver.current = resolve;
    });
  }, []);

  const settle = (ok: boolean) => {
    resolver.current?.(ok);
    resolver.current = null;
    setCurrent(null);
  };

  return (
    <ConfirmContext.Provider value={ask}>
      {children}
      <ConfirmDialog
        //a new key per request, so the typed word never carries over from the last delete
        key={current ? `${current.title}|${current.confirmLabel}` : "closed"}
        open={current !== null}
        title={current?.title ?? ""}
        consequence={current?.consequence ?? ""}
        confirmLabel={current?.confirmLabel ?? ""}
        tone={current?.tone ?? "primary"}
        changes={current?.changes}
        typeToConfirm={current?.typeToConfirm}
        onConfirm={() => settle(true)}
        onCancel={() => settle(false)}
      />
    </ConfirmContext.Provider>
  );
}

/**
 * `const confirm = useConfirmChange(); if (!(await confirm({...}))) return;`
 *
 * <p>Outside a provider it refuses rather than passing: a screen rendered somewhere nobody mounted
 * the provider must not start saving without asking.
 */
export function useConfirmChange(): Ask {
  const ask = useContext(ConfirmContext);
  return ask ?? (async () => false);
}

/** The delete form: destructive, and the operator types DELETE. */
export function useConfirmDelete(): (options: Omit<ConfirmOptions, "tone" | "typeToConfirm">) => Promise<boolean> {
  const ask = useConfirmChange();
  return useCallback((options) => ask({ ...options, tone: "destructive", typeToConfirm: DELETE_WORD }), [ask]);
}
