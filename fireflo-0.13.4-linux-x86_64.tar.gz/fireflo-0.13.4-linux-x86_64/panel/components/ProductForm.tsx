"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { SettingsRow } from "@/components/ui/settings-row";
import { SettingsSection } from "@/components/ui/settings-section";
import { ErrorCard, WarningCard } from "@/components/FormNotices";
import { useConfirmChange } from "@/components/ConfirmProvider";
import {
  PRODUCT_SLUG_MAX,
  type ProductInput,
  productWarnings,
  slugify,
  validateProduct,
} from "@/lib/product-types";

/**
 * Creating or describing one product.
 *
 * <p>The name is disabled on an existing product, and unlike the worker form that is not only about
 * key stability: this value is compared by every rate rule, every credential and every historical
 * call record, none of which is a foreign key that could follow a rename.
 */
export function ProductForm({
  initial,
  isNew,
  onSaved,
  onCancel,
}: {
  initial: ProductInput;
  isNew: boolean;
  onSaved: () => Promise<void>;
  onCancel: () => void;
}) {
  const [label, setLabel] = useState(initial.label ?? "");
  const [description, setDescription] = useState(initial.description ?? "");
  const [enabled, setEnabled] = useState(initial.enabled);
  const [whitelistEnabled, setWhitelistEnabled] = useState(initial.whitelistEnabled);
  const [override, setOverride] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const confirm = useConfirmChange();

  //on create the code follows the display name until the operator takes it over; on edit it is
  //simply what it already is, and cannot change
  const name = isNew ? (override ?? slugify(label)) : initial.name;
  const input: ProductInput = { name, label, description, enabled, whitelistEnabled };
  const warnings = productWarnings(input, isNew);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const invalid = validateProduct(input, isNew);
    if (invalid) {
      setError(invalid);
      return;
    }
    const was = (v: string | null | undefined) => (v ?? "").trim() || "(none)";
    const ok = await confirm({
      title: isNew ? `Create product ${name}` : `Save product ${name}`,
      consequence: isNew
        ? `${name} is added to the catalogue${enabled ? " and listed" : ", unlisted"}. Logins and price rules can name it from now on.`
        : `Every login and price rule that names ${name} sees the new details at once.`,
      confirmLabel: isNew ? "Create product" : "Save product",
      tone: !isNew && initial.enabled && !enabled ? "caution" : "primary",
      changes: isNew ? undefined : [
        ...(was(initial.label) !== was(label) ? [{ label: "Name", from: was(initial.label), to: was(label) }] : []),
        ...(was(initial.description) !== was(description)
          ? [{ label: "Description", from: was(initial.description), to: was(description) }] : []),
        ...(initial.enabled !== enabled ? [{ label: "Listed", from: String(initial.enabled), to: String(enabled) }] : []),
        ...(initial.whitelistEnabled !== whitelistEnabled
          ? [{ label: "Whitelist check", from: String(initial.whitelistEnabled), to: String(whitelistEnabled) }] : []),
      ],
    });
    if (!ok) return;
    setSaving(true);
    setError("");
    try {
      const res = await fetch(
        isNew ? "/api/control/products" : `/api/control/products/${encodeURIComponent(name)}`,
        {
          method: isNew ? "POST" : "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(input),
        }
      );
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      //the server reserves the code, so it may not be the one previewed -- say so rather than
      //letting the operator find out from the list
      if (isNew && json?.data?.name && json.data.name !== name) {
        setError("");
        alert(`'${name}' was already taken, so this product's code is '${json.data.name}'.`);
      }
      await onSaved();
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <SettingsSection
        id="product"
        title={isNew ? "New product" : `Editing ${initial.name}`}
        action={
          <>
            <Button type="button" size="sm" variant="ghost" onClick={onCancel}>Cancel</Button>
            <Button type="submit" size="sm" disabled={saving || !name.trim()}>
              {saving ? "Saving…" : isNew ? "Create product" : "Save changes"}
            </Button>
          </>
        }
      >
        <SettingsRow label="Display name" htmlFor="label" help="For this panel only. The code customers send is derived from it.">
          <Input
            id="label"
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            placeholder="Premium AU mobile"
            autoFocus={isNew}
          />
        </SettingsRow>

        <SettingsRow
          label="Code"
          htmlFor="code"
          help={isNew ? (
            <>
              What a customer sends as <code className="font-mono">system_type</code>, up to {PRODUCT_SLUG_MAX}{" "}
              characters.{" "}
              {override === null ? (
                <button type="button" onClick={() => setOverride(name)} className="underline underline-offset-2">
                  Choose it yourself
                </button>
              ) : (
                <button type="button" onClick={() => setOverride(null)} className="underline underline-offset-2">
                  Go back to deriving it
                </button>
              )}{" "}
              It cannot be changed afterwards — every rule, credential and past call record compares
              against this exact string and none of them would follow a rename.
            </>
          ) : (
            "Fixed. To move to a different code: create it, re-point the rules, then delete this one."
          )}
        >
          <Input
            id="code"
            value={name}
            onChange={(e) => setOverride(e.target.value)}
            readOnly={isNew && override === null}
            disabled={!isNew}
            placeholder={isNew ? "from the display name" : undefined}
            className="font-mono"
          />
        </SettingsRow>

        <SettingsRow label="What the customer is buying" htmlFor="description" wide>
          <Textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            placeholder="Sender ID preserved, direct routes only, delivery receipts within 30s."
          />
        </SettingsRow>

        {/* the opposite of what enabled means on a vendor, so it has to be said here */}
        <SettingsRow
          label="Listed"
          labelId="product-enabled"
          help="Mostly this panel’s lists: unlisting a product does not stop its rate rules pricing traffic. It does end any whitelist exemption below, which puts that traffic back under checking."
        >
          <div className="flex md:justify-end">
            <Switch checked={enabled} onChange={setEnabled} aria-labelledby="product-enabled" />
          </div>
        </SettingsRow>

        {/* the one field here the gateway acts on, so it is the one worth spelling out */}
        <SettingsRow
          label="Check sender IDs and content"
          labelId="product-whitelist"
          help="On, every account sending under this product is held to its approved sender IDs and content templates. Off exempts all of them at once, whatever their own settings say — for traffic where a registered sender ID is not the point, such as one-time passwords on a shortcode. Traffic with no product, or naming a product that does not exist here, is always checked."
        >
          <div className="flex md:justify-end">
            <Switch checked={whitelistEnabled} onChange={setWhitelistEnabled} aria-labelledby="product-whitelist" />
          </div>
        </SettingsRow>
      </SettingsSection>

      <WarningCard warnings={warnings} />
      <ErrorCard error={error} />
    </form>
  );
}
