"use client";
import { useState } from "react";
import { useSession } from "next-auth/react";
import { formatTimestamp } from "@/lib/datetime";
import type { TpsPeak } from "@/lib/health-types";
import { peakLine } from "@/lib/labels";
import { isAdminSession } from "@/lib/roles";

/**
 * The highest throughput reached, in small text: "Peak 1,436/s · 13 Oct, 02:58".
 *
 * <p>The gateway keeps the figure (`tps_peak` on a worker, `tps_peaks` for the totals), so it
 * survives a restart and a page reload alike. `scope` adds a Reset for admins -- after a test burst
 * the old figure no longer describes the platform -- and is the worker's full name or one of the two
 * totals, `all:vendors` and `all:servers`.
 */
export function PeakLine({ peak, scope, onReset }: {
  peak: TpsPeak | null | undefined;
  scope?: string;
  /** Called after a reset, so the page can re-read health rather than wait for its next poll. */
  onReset?: () => void;
}) {
  const { data: session } = useSession();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const line = peakLine(peak, (iso) => formatTimestamp(iso));

  async function reset() {
    if (!scope || !window.confirm("Forget this peak? The next measured traffic sets a new one.")) {
      return;
    }
    setBusy(true);
    setError("");
    try {
      const res = await fetch(`/api/control/tps-peaks?scope=${encodeURIComponent(scope)}`, { method: "DELETE" });
      if (!res.ok) {
        const body = await res.json().catch(() => null);
        setError(body?.error ?? `Could not reset (${res.status})`);
        return;
      }
      onReset?.();
    } finally {
      setBusy(false);
    }
  }

  return (
    <p className="text-xs text-muted-foreground" title={line.title}>
      <span className="tabular-nums" suppressHydrationWarning>{line.text}</span>
      {peak && scope && isAdminSession(session) && (
        <>
          {" · "}
          <button type="button" disabled={busy} onClick={() => void reset()}
            className="underline underline-offset-2 hover:text-foreground disabled:opacity-50">
            reset
          </button>
        </>
      )}
      {error && <span className="ml-2 text-destructive">{error}</span>}
    </p>
  );
}
