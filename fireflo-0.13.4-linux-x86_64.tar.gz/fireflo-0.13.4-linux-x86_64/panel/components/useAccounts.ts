"use client";
import { useCallback, useEffect, useState } from "react";
import type { AccountInput, AccountSummary, OrphanAccount } from "@/lib/account-types";
import { surface } from "@/lib/panel-surface";

/**
 * The account catalogue, and the ids in use that are not in it.
 *
 * <p>Shaped like `useProducts`. Since gateway 0.9.13 the gateway does read `app_account`: a
 * disabled or archived account's logins are withheld within one configuration poll.
 *
 * <p>Archived accounts (V1.100.0) come back apart, in `archived`, and only on the operator's surface.
 */
export function useAccounts() {
  const [accounts, setAccounts] = useState<AccountSummary[]>([]);
  const [orphans, setOrphans] = useState<OrphanAccount[]>([]);
  const [archived, setArchived] = useState<AccountSummary[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");

  const load = useCallback(async () => {
    try {
      const res = await fetch(`${surface().apiBase}/accounts/catalogue`, { cache: "no-store" });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      setAccounts(json.data.accounts as AccountSummary[]);
      setOrphans(json.data.orphans as OrphanAccount[]);
      setArchived((json.data.archived ?? []) as AccountSummary[]);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const save = useCallback(
    async (input: AccountInput): Promise<boolean> => {
      setBusy(input.id);
      try {
        const res = await fetch(`${surface().apiBase}/accounts/catalogue`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(input),
        });
        const json = await res.json().catch(() => null);
        if (!res.ok) {
          setError(json?.error ?? `Request failed (${res.status})`);
          return false;
        }
        setError("");
        await load();
        return true;
      } finally {
        setBusy("");
      }
    },
    [load]
  );

  const remove = useCallback(
    async (id: string) => {
      setBusy(id);
      try {
        const res = await fetch(
          `${surface().apiBase}/accounts/catalogue/${encodeURIComponent(id)}`,
          { method: "DELETE" }
        );
        if (!res.ok) {
          const json = await res.json().catch(() => null);
          setError(json?.error ?? `Request failed (${res.status})`);
          return;
        }
        setError("");
        await load();
      } finally {
        setBusy("");
      }
    },
    [load]
  );

  /**
   * Archives or unarchives one account (admin only). Resolves to what the gateway side reported --
   * how many logins were switched off and binds dropped, and any problem reaching it -- or null
   * when it was refused, with the reason in `error`.
   */
  const setArchivedState = useCallback(
    async (id: string, archive: boolean): Promise<{ logins: number; dropped?: number; problem?: string } | null> => {
      setBusy(id);
      try {
        const res = await fetch(
          `${surface().apiBase}/accounts/${encodeURIComponent(id)}/${archive ? "archive" : "unarchive"}`,
          { method: "POST" }
        );
        const json = await res.json().catch(() => null);
        if (!res.ok) {
          setError(json?.error ?? `Request failed (${res.status})`);
          return null;
        }
        setError("");
        await load();
        return json.data;
      } finally {
        setBusy("");
      }
    },
    [load]
  );

  return { accounts, orphans, archived, error, loading, busy, load, save, remove, setArchivedState };
}
