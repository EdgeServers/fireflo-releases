"use client";
import { useMemo, useState } from "react";
import { AlertTriangle, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { ConditionEditor } from "./ConditionEditor";
import { GuidedConditionRow, useGuidedOptions } from "./GuidedConditionRow";
import { ErrorNote, WarningNote } from "./FormNotices";
import {
  blankGuided,
  describeConditions,
  duplicatesOf,
  fromConditions,
  GUIDED_KINDS,
  nameClash,
  suggestName,
  toConditions,
  type GuidedField,
  type GuidedKind,
} from "@/lib/filter-guide";
import { emptyFilterWarning, usedByTotal, validateFilter, type Filter, type FilterInput } from "@/lib/filter-types";
import { conditionWarnings, type ConditionInput } from "@/lib/rate-types";
import { cn } from "@/lib/utils";

/**
 * Making a filter in three steps, in words rather than in the gateway's grammar.
 *
 * <ol>
 *   <li><strong>What to match</strong> -- destination, sender, product, login, account, network or
 *       message text, ticked as cards.</li>
 *   <li><strong>The values</strong> -- a prefix or an exact number, a product from the catalogue, a
 *       login or an account from their lists, with the filter read back as a sentence as it is
 *       built.</li>
 *   <li><strong>A name</strong> -- suggested from the values, with a review.</li>
 * </ol>
 *
 * <p>From step 2 on, the panel says when another filter already tests exactly the same thing, and
 * offers to show that one instead. It never blocks: two names for one clause is sometimes wanted, but
 * it should always be chosen. A filter the guided fields cannot express -- an unusual field or
 * operator -- opens in the advanced editor, the same `ConditionEditor` the pricing form uses.
 */

export type WizardMode =
  //`conditions`: the message tester's "Create filter", opening with its condition filled in
  | { kind: "new"; conditions?: ConditionInput[] }
  | { kind: "edit"; filter: Filter }
  | { kind: "copy"; filter: Filter };

const STEPS = ["What to match", "Values", "Name"] as const;

export function FilterWizard({
  mode,
  filters,
  onSave,
  onClose,
  onShow,
}: {
  mode: WizardMode;
  filters: Filter[];
  onSave: (input: FilterInput) => Promise<string | null>;
  onClose: () => void;
  /** "Use <name> instead": close, and point at that filter in the list. */
  onShow: (name: string) => void;
}) {
  const source = mode.kind === "new" ? null : mode.filter;
  const prefilled = mode.kind === "new" && mode.conditions?.length ? mode.conditions : null;
  const guidedStart = source ? fromConditions(source.conditions) : prefilled ? fromConditions(prefilled) : [];

  const [step, setStep] = useState<1 | 2 | 3>(source || prefilled ? 2 : 1);
  const [fields, setFields] = useState<GuidedField[]>(guidedStart ?? []);
  const [advanced, setAdvanced] = useState(source !== null && guidedStart === null);
  const [raw, setRaw] = useState<ConditionInput[]>((source?.conditions ?? prefilled ?? []).map((c) => ({ ...c })));
  const [name, setName] = useState(
    mode.kind === "edit" ? mode.filter.name : mode.kind === "copy" ? `${mode.filter.name}_copy` : ""
  );
  const [nameTouched, setNameTouched] = useState(mode.kind !== "new");
  const [label, setLabel] = useState(source?.label ?? "");
  const [enabled, setEnabled] = useState(source?.enabled ?? true);
  const options = useGuidedOptions();
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);


  const conditions = useMemo(() => (advanced ? raw : toConditions(fields)), [advanced, raw, fields]);
  const sentence = describeConditions(conditions);
  const exceptName = mode.kind === "edit" ? mode.filter.name : undefined;
  const twins = duplicatesOf(conditions, filters, exceptName);
  const clash = mode.kind === "edit" ? null : nameClash(name, filters);
  const uses = mode.kind === "edit" ? usedByTotal(mode.filter) : 0;

  //a suggestion follows the values until somebody types a name of their own
  const suggested = suggestName(conditions, filters.filter((f) => f.name !== exceptName));
  const shownName = nameTouched ? name : suggested;

  const input: FilterInput = { name: shownName, label, enabled, conditions };
  const warnings = [
    emptyFilterWarning(input),
    ...conditionWarnings(conditions),
    !enabled && uses > 0
      ? `Switching this off skips ${uses} rule${uses === 1 ? "" : "s"}: a disabled filter does not `
        + "become a catch-all, and that traffic falls through to whatever matches next."
      : null,
  ].filter((w): w is string => w != null);

  const picked = new Set(fields.map((f) => f.kind));
  function toggleKind(kind: GuidedKind) {
    setFields((cur) => (cur.some((f) => f.kind === kind) ? cur.filter((f) => f.kind !== kind) : [...cur, blankGuided(kind)]));
  }
  function update(kind: GuidedKind, patch: Partial<GuidedField>) {
    setFields((cur) => cur.map((f) => (f.kind === kind ? { ...f, ...patch } : f)));
  }

  function toAdvanced() {
    setRaw(conditions.map((c) => ({ ...c })));
    setAdvanced(true);
  }
  const backToGuided = advanced ? fromConditions(raw) : null;

  async function submit() {
    const invalid = validateFilter(input);
    if (invalid || clash) {
      setError(invalid ?? `A filter named ${clash} already exists. Choose another name.`);
      return;
    }
    setSaving(true);
    setError("");
    const failure = await onSave(input);
    setSaving(false);
    if (failure) setError(failure);
  }

  const title = mode.kind === "edit" ? `Edit ${mode.filter.name}` : mode.kind === "copy" ? `Copy of ${mode.filter.name}` : "New filter";
  const canNext = step === 1 ? fields.length > 0 || advanced : conditions.length > 0;

  return (
    <Dialog open onClose={onClose} title={title} className="max-w-3xl">
      <div className="space-y-5">
        <ol className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm" aria-label="Steps">
          {STEPS.map((s, i) => {
            const n = (i + 1) as 1 | 2 | 3;
            const done = n < step;
            return (
              <li key={s} aria-current={n === step ? "step" : undefined} className={cn("flex items-center gap-2", n === step ? "font-semibold text-foreground" : "text-muted-foreground")}>
                <span className={cn(
                  "flex h-6 w-6 items-center justify-center rounded-full text-xs font-semibold",
                  n === step ? "bg-primary text-primary-foreground" : done ? "bg-primary-soft text-foreground" : "bg-muted text-muted-foreground"
                )}>
                  {done ? <Check className="h-3.5 w-3.5" aria-hidden="true" /> : n}
                </span>
                {s}
              </li>
            );
          })}
        </ol>

        {step === 1 && (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Tick everything a message must match. Every one you tick has to hold, so each narrows
              the filter further.
            </p>
            <div className="grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
              {GUIDED_KINDS.map((k) => {
                const on = picked.has(k.id);
                return (
                  <button key={k.id} type="button" aria-pressed={on} onClick={() => { setAdvanced(false); toggleKind(k.id); }}
                    className={cn(
                      "flex items-start gap-2.5 rounded-lg border p-3 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                      on ? "border-primary bg-primary-soft/50 ring-1 ring-primary" : "border-border bg-card hover:border-muted-foreground/40"
                    )}>
                    <span className={cn("mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border", on ? "border-primary bg-primary text-primary-foreground" : "border-input")}>
                      {on && <Check className="h-3 w-3" aria-hidden="true" />}
                    </span>
                    <span>
                      <span className="block font-semibold">{k.label}</span>
                      <span className="block text-sm text-muted-foreground">{k.hint}</span>
                    </span>
                  </button>
                );
              })}
              <button type="button" aria-pressed={advanced}
                onClick={() => { setFields([]); setAdvanced((a) => !a); }}
                className={cn(
                  "flex items-start gap-2.5 rounded-lg border border-dashed p-3 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                  advanced ? "border-primary bg-primary-soft/50" : "border-border hover:border-muted-foreground/40"
                )}>
                <span className={cn("mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border", advanced ? "border-primary bg-primary text-primary-foreground" : "border-input")}>
                  {advanced && <Check className="h-3 w-3" aria-hidden="true" />}
                </span>
                <span>
                  <span className="block font-semibold">Something else</span>
                  <span className="block text-sm text-muted-foreground">any field, in the advanced editor</span>
                </span>
              </button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            {advanced ? (
              <div className="space-y-2">
                <ConditionEditor conditions={raw} onChange={setRaw} filterCount={1} />
                <p className="text-xs text-muted-foreground">
                  The gateway&apos;s own fields and operators. Every condition must hold.{" "}
                  {backToGuided && (
                    <button type="button" className="text-primary hover:underline" onClick={() => { setFields(backToGuided); setAdvanced(false); }}>
                      Back to the guided fields
                    </button>
                  )}
                </p>
              </div>
            ) : (
              <>
                {fields.map((f) => (
                  <GuidedConditionRow key={f.kind} field={f} options={options} onChange={(p) => update(f.kind, p)} onRemove={() => toggleKind(f.kind)} />
                ))}
                <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm">
                  <button type="button" className="text-primary hover:underline" onClick={() => setStep(1)}>+ Match something else</button>
                  <button type="button" className="text-muted-foreground hover:text-foreground hover:underline" onClick={toAdvanced}>Edit as conditions</button>
                </div>
              </>
            )}

            <div className="rounded-lg border border-border bg-muted/40 px-4 py-3 text-sm">
              <span className="text-muted-foreground">Matches a message when: </span>
              <span className="font-medium">{sentence || "nothing yet. Fill in a value above."}</span>
            </div>

            <TwinAlert twins={twins} onShow={onShow} />
            <WarningNote warnings={conditionWarnings(conditions)} />
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Name" htmlFor="fw-name" hint={mode.kind === "edit" ? "Fixed: rules reference the filter by it." : "Suggested from the values. Rules reference the filter by it, and it is fixed once created."}>
                <Input id="fw-name" className="font-mono" value={shownName} disabled={mode.kind === "edit"}
                  onChange={(e) => { setNameTouched(true); setName(e.target.value); }} aria-invalid={!!clash || undefined} />
              </Field>
              <Field label="Description" htmlFor="fw-label" hint="Optional. What this clause is for.">
                <Input id="fw-label" value={label} placeholder="India, transactional" onChange={(e) => setLabel(e.target.value)} />
              </Field>
            </div>
            {clash && (
              <p className="text-sm text-destructive">A filter named <code className="font-mono">{clash}</code> already exists. Names are matched exactly, so choose another.</p>
            )}

            <div className="flex items-center gap-4 rounded-lg border border-border px-4 py-3">
              <div className="min-w-0 flex-1">
                <div id="fw-enabled" className="font-semibold">Enabled</div>
                <p className="text-sm text-muted-foreground">
                  {uses > 0
                    ? `Used by ${uses} rule${uses === 1 ? "" : "s"}. Switching it off skips every one of them.`
                    : "Used by nothing yet, so switching it off changes nothing."}
                </p>
              </div>
              <Switch checked={enabled} onChange={setEnabled} aria-labelledby="fw-enabled" />
            </div>

            <div className="rounded-lg border border-border bg-muted/40 px-4 py-3 text-sm">
              <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Review</div>
              <p className="mt-1"><code className="font-mono">{shownName || "?"}</code> matches a message when: <span className="font-medium">{sentence}</span></p>
            </div>

            <TwinAlert twins={twins} onShow={onShow} creating />
            <WarningNote warnings={warnings} />
            <ErrorNote error={error} />
          </div>
        )}

        <div className="flex flex-wrap items-center justify-end gap-2 border-t border-border pt-4">
          <Button type="button" variant="ghost" className="mr-auto" onClick={onClose}>Cancel</Button>
          {step > 1 && <Button type="button" variant="outline" onClick={() => setStep((s) => (s - 1) as 1 | 2)}>Back</Button>}
          {step < 3 ? (
            <Button type="button" disabled={!canNext} onClick={() => setStep((s) => (s + 1) as 2 | 3)}>Next</Button>
          ) : (
            <Button type="button" disabled={saving || !shownName.trim() || !!clash} onClick={() => void submit()}>
              {saving ? "Saving…" : mode.kind === "edit" ? "Save changes" : twins.length ? "Create anyway" : "Create filter"}
            </Button>
          )}
        </div>
      </div>
    </Dialog>
  );
}

/** "Another filter already tests exactly this", with a way to go and use it instead. */
function TwinAlert({ twins, onShow, creating = false }: { twins: Filter[]; onShow: (name: string) => void; creating?: boolean }) {
  if (!twins.length) return null;
  const first = twins[0];
  const uses = usedByTotal(first);
  return (
    <div role="status" className="flex flex-wrap items-start gap-3 rounded-lg border border-warning/40 bg-warning-soft/40 px-4 py-3 text-sm">
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning" aria-hidden="true" />
      <div className="min-w-0 flex-1">
        <p>
          <code className="font-mono font-semibold">{first.name}</code>
          {twins.length > 1 && ` and ${twins.length - 1} more`} already {twins.length > 1 ? "test" : "tests"} exactly
          these conditions{uses > 0 ? `, and ${uses} rule${uses === 1 ? " uses" : "s use"} it` : ""}.
        </p>
        <p className="text-muted-foreground">
          {creating
            ? "Rules reference a filter by name, so a copy is a second thing to keep in step."
            : "You can use it instead, or carry on to make a second copy."}
        </p>
      </div>
      <Button type="button" size="sm" variant="outline" onClick={() => onShow(first.name)}>Use {first.name} instead</Button>
    </div>
  );
}
