"use client";

/**
 * What this registration will actually cover, said once, only when there is something to say.
 *
 * <p>Shared by both editors so the two cannot describe the same three controls differently.
 *
 * <h2>Both halves are conditional, and that is the point</h2>
 *
 * <p>The ENFORCE warning is worth its three lines — a login with nothing approved for it can send
 * nothing at all — but only once a login is actually chosen. On the default it is a paragraph about
 * a situation that does not exist, and a warning shown on every form is a warning operators learn to
 * scroll past. It names the logins that would be left out rather than describing the shape in the
 * abstract, because "some other login" is not something anybody can act on.
 *
 * <p>The summary is the only place the three scopes are read together, which is what makes it worth
 * having at all — and equally why it stays silent on the every-login, every-product row: there it
 * would restate three controls that are visible directly above it.
 */
export function RegistrationScopeNotes({
  noun,
  name,
  accountId,
  systemId,
  product,
  logins,
}: {
  /** "sender ID" or "template", for the sentence. */
  noun: string;
  /** What is being approved, already trimmed. */
  name: string;
  accountId: string;
  /** Empty for every login. */
  systemId: string;
  /** Empty for every product. */
  product: string;
  /** Every login on the account, so the warning can name the ones left out. */
  logins: string[];
}) {
  const scoped = Boolean(systemId || product);
  if (!scoped) {
    return null;
  }

  const others = systemId ? logins.filter((l) => l && l !== systemId) : [];

  return (
    <div className="space-y-2">
      {others.length > 0 && (
        <p className="rounded-md border border-warning/40 bg-warning-soft/40 px-3 py-2 text-xs text-warning">
          Only messages arriving on <span className="font-mono">{systemId}</span> may use it.{" "}
          <span className="font-mono">{others.join(", ")}</span>{" "}
          {others.length === 1 ? "cannot" : "cannot"}, unless something else approves it for{" "}
          {others.length === 1 ? "it" : "them"} — and a login with nothing approved at all can send
          nothing under ENFORCE.
        </p>
      )}
      <p className="border-t border-border pt-2 text-xs text-muted-foreground">
        <span className="mb-1 block text-2xs font-semibold uppercase tracking-wide">
          This approval will
        </span>
        Let <strong className="font-mono text-foreground/80">{systemId || "every login"}</strong>{" "}
        {systemId ? "alone " : ""}on{" "}
        <span className="font-mono">{accountId}</span> use{" "}
        <strong className="font-mono text-foreground/80">{name}</strong>, on{" "}
        <strong className="text-foreground/80">{product || "any product"}</strong>.
        <span className="sr-only"> This is a {noun}.</span>
      </p>
    </div>
  );
}
