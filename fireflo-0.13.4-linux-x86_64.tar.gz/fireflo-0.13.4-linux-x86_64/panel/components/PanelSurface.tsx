"use client";
import { setSurface, type Surface } from "@/lib/panel-surface";

/**
 * Tells `lib/panel-surface` which of the two panels everything below this is rendering inside.
 *
 * <p>Rendered near the top of both layouts, beside {@link PlatformScale}, whose shape this copies
 * exactly. It renders nothing.
 *
 * <p><strong>The assignment is during render, on purpose.</strong> An effect would run only on the
 * client and only after the first paint, so the server would render this subtree against the
 * operator surface — the module default — and the browser would then re-render it against the
 * portal's. For a money format that is a visible flicker; here it is a request to the wrong API
 * namespace and a link to a page the customer cannot open.
 *
 * <p>It is a side effect in a render function, which React normally forbids for good reasons: React
 * may call a render more than once, and may discard the result. Both are fine here because the
 * assignment is idempotent and the value is the same every time — there is exactly one surface per
 * rendered page, decided by which layout is above it. Same argument as `PlatformScale`, and see
 * `lib/panel-surface.ts` for why this is module state rather than a context.
 */
export function PanelSurface({ surface }: { surface: Surface }) {
  setSurface(surface);
  return null;
}
