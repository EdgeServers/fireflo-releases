"use client";
import type { ReactNode } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { ConditionEditor } from "./ConditionEditor";
import { FilterPicker } from "./FilterPicker";
import type { Filter } from "@/lib/filter-types";
import type { RateRuleInput } from "@/lib/rate-types";

/**
 * The fields of a single rate rule.
 *
 * <p>Extracted from `ScopeForm` so that one rule can be edited on its own. The whole-scope form still
 * renders this once per rule, which is the point: a rule edited from a vendor card and the same rule
 * edited from the pricing page get the same validation, the same product list and the same statement
 * of what it charges for. Two editors for one row would eventually disagree, and the thing they would
 * disagree about is money.
 *
 * @param rules every rule in the scope, used only to build the product dropdown — a product already
 *     in use on a sibling rule must stay offered even when it is not in the catalogue
 * @param actions row controls the surrounding form owns, such as reorder and remove. The one-at-a-time
 *     editor has none; the whole-scope form has three
 */
export function RateRuleFields({
  rule,
  rules,
  catalogue,
  library,
  index,
  fixedProduct,
  actions,
  onChange,
}: {
  rule: RateRuleInput;
  rules: RateRuleInput[];
  catalogue: string[];
  library: Filter[];
  /**
   * The product this rule prices, when the surrounding page has already decided it.
   *
   * <p>Shown as a statement rather than a dropdown, because the endpoint behind those forms writes
   * every rule into this product's bucket whatever the field says — the product is the address the
   * request is sent to. A dropdown that could be changed and then ignored is worse than no dropdown.
   */
  fixedProduct?: string;
  /** Shown as `#n` when the rule sits in a numbered list. Omitted when it is the only one on screen. */
  index?: number;
  actions?: ReactNode;
  onChange: (patch: Partial<RateRuleInput>) => void;
}) {
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end gap-3">
        {index != null && <span className="pb-2 text-sm text-muted-foreground">#{index}</span>}

        <div className="w-32">
          <Label className="mb-1.5 block">Amount</Label>
          <Input
            value={rule.amount}
            onChange={(e) => onChange({ amount: e.target.value })}
            placeholder="0.0450"
            inputMode="decimal"
            className="tabular-nums"
          />
        </div>

        <div className="w-40">
          <Label className="mb-1.5 block">Product</Label>
          {fixedProduct ? (
            <p className="flex h-9 items-center font-mono text-sm">{fixedProduct}</p>
          ) : (
            <Select
              value={rule.product ?? ""}
              onChange={(e) => onChange({ product: e.target.value || null })}
            >
              <option value="">Any product</option>
              {/* the catalogue, plus anything already in use here, so an unfamiliar product on an
                  imported rule is never silently dropped by the dropdown */}
              {productOptions(catalogue, rules, rule.product).map((p) => (
                <option key={p} value={p}>{p}</option>
              ))}
            </Select>
          )}
        </div>

        <div className="min-w-40 flex-1">
          <Label className="mb-1.5 block">Note</Label>
          <Input
            value={rule.label ?? ""}
            onChange={(e) => onChange({ label: e.target.value || null })}
            placeholder="what this rule is for"
          />
        </div>

        <label className="flex items-center gap-1.5 pb-2 text-sm">
          <input
            type="checkbox"
            checked={rule.enabled}
            onChange={(e) => onChange({ enabled: e.target.checked })}
            className="h-4 w-4 rounded border-input accent-primary"
          />
          Active
        </label>

        {actions}
      </div>

      <ConditionEditor
        conditions={rule.conditions}
        filterCount={rule.filters.length}
        onChange={(conditions) => onChange({ conditions })}
      />

      <FilterPicker
        chosen={rule.filters}
        library={library}
        onChange={(filters) => onChange({ filters })}
      />

      {/* the only place the combined effect is visible. A rule's filters and its own conditions are
          ANDed at load time, so reading either half alone misstates what it charges for */}
      <p className="text-xs text-muted-foreground">{effectOf(rule, library)}</p>
    </div>
  );
}

export function productOptions(
  catalogue: string[],
  rules: RateRuleInput[],
  current: string | null
): string[] {
  const products = new Set<string>(catalogue);
  rules.forEach((r) => r.product && products.add(r.product));
  if (current) {
    products.add(current);
  }
  return [...products].sort();
}

/**
 * What this rule actually tests, filters and inline conditions together.
 *
 * <p>The gateway ANDs a rule's own conditions with every condition of every filter it references, so
 * reading either half on its own misstates what the rule charges for.
 */
export function effectOf(rule: RateRuleInput, library: Filter[]): string {
  const known = new Map(library.map((f) => [f.name, f]));
  const parts: string[] = [];

  for (const name of rule.filters) {
    const filter = known.get(name);
    if (!filter) {
      return `'${name}' is not in the filter library, so the gateway skips this rule entirely.`;
    }
    if (!filter.enabled) {
      return `'${name}' is switched off, so the gateway skips this rule entirely — this amount is `
        + "not charged to anything.";
    }
    for (const c of filter.conditions) {
      parts.push(`${c.field} ${c.negate ? "not " : ""}${c.operator} ${c.value}`.trim());
    }
  }
  for (const c of rule.conditions) {
    parts.push(`${c.field} ${c.negate ? "not " : ""}${c.operator} ${c.value}`.trim());
  }

  if (!parts.length) {
    return "No filters and no conditions, so this charges for every message the scope is asked about.";
  }
  return `Charges when ${parts.join(" and ")}.`;
}
