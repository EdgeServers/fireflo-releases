"use client";
import { useCallback, useState } from "react";
import Link from "next/link";
import { ChevronDown, ChevronUp, Pencil, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DisclosureSection } from "./DisclosureSection";
import { useConfirmChange, useConfirmDelete } from "./ConfirmProvider";
import { ErrorNote, SavedNote, WarningNote } from "@/components/FormNotices";
import { RateRuleFields } from "./RateRuleFields";
import { RateRuleLines } from "./RateRuleLines";
import { useFilters } from "./useFilters";
import { useRates } from "./useRates";
import {
  type RateRule,
  type RateRuleInput,
  scopeWarnings,
  validateRule,
  validateScope,
} from "@/lib/rate-types";
import { formatClockTime } from "@/lib/datetime";

const BLANK: RateRuleInput = {
  id: null,
  amount: "",
  product: null,
  currency: null,
  label: null,
  enabled: true,
  conditions: [],
  filters: [],
};

/**
 * What this vendor charges us, edited one rule at a time.
 *
 * <p>Cost was only reachable from a product's pricing page, which listed every scope pricing that
 * product — so finding one vendor's rates meant scrolling past every account. The transpose is the
 * useful view: one scope, all products, which is also the only shape `saveScope` can write.
 *
 * <p><strong>The scope is the bare instance name.</strong> `vendor1`, never `smppclient.vendor1`.
 * The gateway binds cost with `getInstanceName()`, while call records store the full name — so the
 * two correct-looking options differ by a prefix and only one of them ever matches. Getting it wrong
 * stores fine, loads fine, displays fine and matches nothing, which reads as a vendor with no cost
 * and a margin that looks wonderful.
 *
 * <p>Loads on expand rather than with the card. A vendor list is one query; sixty vendors' rate
 * scopes is sixty, and almost nobody opens more than one.
 *
 * <h2>One rule at a time</h2>
 *
 * <p>The resting state is sentences, and exactly one rule is ever open. That is not only
 * presentation — it bounds what a save can change. The gateway has no per-rule endpoint;
 * `saveScope` rewrites the whole ordered list. So a write from here is still the whole scope, but it
 * is the freshly stored scope with a single rule swapped in, rather than whatever a long form
 * happened to be holding. A tab left open can no longer put five stale rules over someone else's
 * edit; it can only resubmit the one that was being edited.
 *
 * <p><strong>Reorder and remove save immediately, with no form.</strong> First match wins, so
 * position is meaning rather than arrangement, and neither action has anything to fill in. Every
 * write is confirmed in the panel's modal first; a removal asks for DELETE to be typed.
 */
export function VendorCostRates({
  vendorName,
  catalogue,
}: {
  vendorName: string;
  /**
   * Product names for the dropdown, fetched by the parent.
   *
   * <p>A prop rather than a hook because this renders once per vendor card, and a hook here would
   * be one request per vendor for a list that is the same every time.
   */
  catalogue: string[];
}) {
  const { known, loadScope, saveScope } = useRates();
  const confirm = useConfirmChange();
  const confirmDelete = useConfirmDelete();
  const { filters: library } = useFilters();
  const [open, setOpen] = useState(false);
  const [rules, setRules] = useState<RateRule[] | null>(null);
  const [savedAt, setSavedAt] = useState<string | null>(null);
  //an index into the stored list, or its length for a rule being added. Never more than one
  const [editing, setEditing] = useState<{ index: number; rule: RateRuleInput } | null>(null);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setRules((await loadScope(vendorName)) ?? []);
  }, [vendorName, loadScope]);

  function toggle() {
    const next = !open;
    setOpen(next);
    if (next && rules === null) {
      void load();
    }
  }

  const stored: RateRuleInput[] = rules ?? [];

  //what the list becomes if the open rule is saved. The checks below are about the set -- a second
  //catch-all, a rule shadowed by an earlier one -- so they have to see the prospective list, not the
  //stored one and not the single rule in isolation
  const prospective = editing
    ? (editing.index === stored.length
        ? [...stored, editing.rule]
        : stored.map((r, i) => (i === editing.index ? editing.rule : r)))
    : stored;

  const warnings = editing
    ? scopeWarnings({ scope: vendorName, scopeConfirmed: true, rules: prospective }, known)
    : [];

  /** Write the stored list with one change applied. */
  async function persist(next: RateRuleInput[]) {
    const invalid = validateScope({ scope: vendorName, scopeConfirmed: true, rules: next }, known);
    if (invalid) {
      setError(invalid);
      return;
    }
    setSaving(true);
    setError("");
    const failure = await saveScope(vendorName, next, true);
    setSaving(false);
    if (failure) {
      //stay open: the rule being edited is still on screen, and the message says what to change
      setError(failure);
      return;
    }
    await load();
    setSavedAt(formatClockTime(new Date()));
    setEditing(null);
  }

  /**
   * Save the rule that is open.
   *
   * <p>Checked as a rule first, then as part of the set. Both matter and they fail differently: an
   * amount this operator has not typed yet is about the box in front of them, while a second
   * catch-all is about a rule they may not even be able to see. Running the set check alone named
   * the open rule by a position that is nowhere on screen — "rule 2", under a heading saying
   * "New rule".
   */
  async function saveOpen() {
    if (!editing) {
      return;
    }
    const problem = validateRule(editing.rule, "this rule");
    if (problem) {
      setError(problem);
      return;
    }
    const adding = editing.index >= stored.length;
    const ok = await confirm({
      title: adding ? `Add a cost rule to ${vendorName}?` : `Save cost rule ${editing.index + 1} of ${vendorName}?`,
      consequence: `What ${vendorName} costs us changes for the messages this rule matches, from the gateway's `
        + "next configuration poll, within thirty seconds.",
      confirmLabel: adding ? "Add rule" : "Save rule",
    });
    if (!ok) {
      return;
    }
    await persist(prospective);
  }

  function move(index: number, by: number) {
    const to = index + by;
    if (to < 0 || to >= stored.length) {
      return;
    }
    const next = [...stored];
    [next[index], next[to]] = [next[to], next[index]];
    void (async () => {
      const ok = await confirm({
        title: `Move cost rule ${index + 1} ${by < 0 ? "up" : "down"}?`,
        consequence: `First match wins, so rule ${index + 1} becoming rule ${to + 1} changes which of `
          + `${vendorName}'s messages it prices.`,
        confirmLabel: "Move rule",
      });
      if (ok) {
        await persist(next);
      }
    })();
  }

  return (
    <DisclosureSection
      title="Cost rates"
      set={rules?.length ?? 0}
      open={open}
      onToggle={toggle}
      note="What this vendor charges us, in order. First match wins."
    >
      {rules === null ? (
        <p className="text-xs text-muted-foreground">Loading…</p>
      ) : (
        <div className="space-y-3">
          <SavedNote
            at={savedAt}
            detail={"The gateway picks cost up on its next configuration poll, within thirty "
              + "seconds — Apply now does not cover rates."}
          />

          {rules.length > 0 && (
            <RateRuleLines
              rules={rules}
              action={(_rule, index) =>
                //no row controls while a rule is open. A second Edit button on screen would invite
                //exactly the thing one-at-a-time exists to prevent
                editing ? null : (
                  <>
                    <Button variant="ghost" size="icon" className="h-7 w-7" aria-label="Move up"
                      disabled={index === 0 || saving} onClick={() => move(index, -1)}>
                      <ChevronUp className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7" aria-label="Move down"
                      disabled={index === rules.length - 1 || saving} onClick={() => move(index, 1)}>
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm" className="h-7 gap-1.5" disabled={saving}
                      onClick={() => {
                        setError("");
                        setEditing({ index, rule: { ...rules[index] } });
                      }}>
                      <Pencil className="h-3.5 w-3.5" />
                      Edit
                    </Button>
                    <Button variant="ghost" size="sm" className="h-7 text-destructive hover:text-destructive"
                      disabled={saving}
                      onClick={async () => {
                        const ok = await confirmDelete({
                          title: `Remove cost rule ${index + 1} of ${vendorName}?`,
                          consequence: rules.length === 1
                            ? "The last cost rule for this vendor. Its traffic will have no recorded "
                              + "cost at all, so margin on it becomes unknown."
                            : "Messages this rule priced fall through to the next rule that matches.",
                          confirmLabel: "Remove rule",
                        });
                        if (ok) {
                          await persist(stored.filter((_, n) => n !== index));
                        }
                      }}>
                      Remove
                    </Button>
                  </>
                )
              }
            />
          )}

          {rules.length === 0 && !editing && (
            <p className="text-xs text-muted-foreground">
              No cost rates for this vendor. Its traffic is costed at nothing, so margin on it reads
              as the full sell price.
            </p>
          )}

          {editing ? (
            <div className="space-y-3 rounded-lg border border-border p-3">
              <p className="text-xs uppercase tracking-wide text-muted-foreground">
                {editing.index === stored.length ? "New rule" : `Editing rule ${editing.index + 1}`}
              </p>
              <RateRuleFields
                rule={editing.rule}
                rules={prospective}
                catalogue={catalogue}
                library={library}
                onChange={(patch) =>
                  setEditing((e) => (e ? { ...e, rule: { ...e.rule, ...patch } } : e))
                }
              />
              <WarningNote warnings={warnings} />
              <ErrorNote error={error} />
              <div className="flex flex-wrap gap-2">
                <Button size="sm" disabled={saving} onClick={saveOpen}>
                  {saving ? "Saving…" : "Save this rule"}
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  disabled={saving}
                  onClick={() => {
                    setEditing(null);
                    setError("");
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <>
              <ErrorNote error={error} />
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5"
                disabled={saving}
                onClick={() => {
                  setError("");
                  setEditing({ index: stored.length, rule: { ...BLANK } });
                }}
              >
                <Plus className="h-4 w-4" />
                Add a rule
              </Button>
            </>
          )}

          <p className="text-xs text-muted-foreground">
            Cost is one half of margin.{" "}
            <Link href="/cp/pricing" className="text-primary hover:underline">Pricing</Link> shows every
            scope at once, and{" "}
            <Link href="/cp/revenue" className="text-primary hover:underline">Revenue</Link> has what
            these rates actually produced.
          </p>
        </div>
      )}
    </DisclosureSection>
  );
}
