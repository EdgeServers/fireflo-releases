"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { ArrowRight, Loader2, RefreshCw, Search, TriangleAlert } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BrokerSettings } from "./BrokerSettings";
import { QueueCleanCard } from "./QueueCleanCard";
import { CardActions } from "./CardBits";
import { useHealth } from "./useHealth";
import { usePoll } from "./usePoll";
import { count } from "@/lib/format";
import { cn } from "@/lib/utils";
import { KIND, KIND_LABEL, type WorkerType } from "@/lib/worker-types";
import {
  diagnose,
  kindHint,
  kindLabel,
  type QueueDump,
  type QueueEntry,
  type QueueSnapshot,
} from "@/lib/queues-types";
import { formatClockTime } from "@/lib/datetime";
import { idleSummary, splitOutgoing } from "@/lib/queue-rows";

/** How often the page re-reads, when it is left to run. */
const REFRESH_MS = 5_000;

/** The URL parameter that remembers which queue is open, so a pasted link opens the same one. */
const SELECTED_PARAM = "q";

/**
 * Stands in for the broker row when the gateway lists none -- REST is queued in process -- so the
 * Broker tile can still be chosen, and its card is where a broker is set up.
 */
const NO_BROKER: QueueSnapshot = { name: "", kind: "broker", depth: 0, ordered: false, returned: 0, entries: [] };

/** A queue's identity across reads: the same worker owns a pending and a delayed queue by one name. */
function queueKey(q: Pick<QueueSnapshot, "kind" | "name">): string {
  return `${q.kind}:${q.name}`;
}

/**
 * One outgoing worker as the strip shows it: the messages waiting for its session and the ones
 * scheduled to be tried again. The gateway reports these as two queues under one full name
 * (`OpsQueueService.describeWorker`), and only lists the delayed one when it is not empty.
 */
interface Outgoing {
  fullName: string;
  type: WorkerType | null;
  name: string;
  pending: QueueSnapshot | null;
  delayed: QueueSnapshot | null;
}

function splitFullName(fullName: string): { type: WorkerType | null; name: string } {
  const dot = fullName.indexOf(".");
  const prefix = dot > 0 ? fullName.slice(0, dot) : "";
  if (prefix === KIND.vendor || prefix === KIND.server) {
    return { type: prefix, name: fullName.slice(dot + 1) };
  }
  return { type: null, name: fullName };
}

function workerHref(o: Pick<Outgoing, "type" | "name">): string | null {
  if (o.type === KIND.vendor) {
    return `/cp/vendors/${encodeURIComponent(o.name)}`;
  }
  if (o.type === KIND.server) {
    return `/cp/servers/${encodeURIComponent(o.name)}`;
  }
  return null;
}

/**
 * What is waiting inside the gateway, laid out as the path a message takes.
 *
 * <p>Live health already reports the depth of each queue. Depth alone is where a diagnosis stops:
 * four thousand messages waiting on a vendor reads the same whether it is one customer's misfired
 * batch or every account on the box, and whether they are first attempts or fifth. So the strip
 * on top answers "where is it stuck" -- broker, router, then each outgoing worker -- and the card
 * below answers "what is stuck there" for whichever stage is selected.
 *
 * <p>The broker leads because it is the one an operator cannot see any other way. RabbitMQ holds
 * REST submissions outside the process, and a backlog there shows up on Live health as a *flat*
 * router queue -- the consumer has stopped pulling -- which reads like calm rather than like a
 * queue nobody is draining.
 */
export function QueuesClient() {
  const [dump, setDump] = useState<QueueDump | null>(null);
  const [limit, setLimit] = useState(20);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [live, setLive] = useState(true);
  const [selected, setSelected] = useState<string | null>(null);
  //filtering happens here rather than at the gateway. The dump is already bounded by the limit, and
  //re-fetching per keystroke would walk every live queue again to answer a question about text
  //already in hand
  const [search, setSearch] = useState("");
  const [retriesOnly, setRetriesOnly] = useState(false);
  //whether the idle outgoing queues are unfolded. Per visit: on a healthy gateway nearly every queue
  //is idle, and the strip is for finding the one that is not
  const [showIdle, setShowIdle] = useState(false);
  //depth on the previous read, per queue, so a row can say whether it is growing. Compared read to
  //read rather than smoothed: the refresh is five seconds, and an operator watching a backlog wants
  //the direction now, not an average that lags the incident
  const previous = useRef<Map<string, number>>(new Map());
  const [trend, setTrend] = useState<Map<string, number>>(new Map());
  //preprocessors hold messages too, between the router and the outgoing queues, but /ops/queues
  //does not list them -- their counts come from health, which already polls
  const { health } = useHealth();
  const preprocessing = (health?.preprocessors ?? []).filter((p) => p.state !== "unavailable");

  useEffect(() => {
    const fromUrl = new URLSearchParams(window.location.search).get(SELECTED_PARAM);
    if (fromUrl) {
      setSelected(fromUrl);
    }
  }, []);

  const load = useCallback(async () => {
    try {
      const res = await fetch(`/api/control/queues?limit=${limit}`, { cache: "no-store" });
      const body = await res.json();
      if (!res.ok) {
        setError(body?.error ?? "Could not load the queues.");
        setDump(null);
      } else {
        setError(null);
        const next = body.data as QueueDump;
        const deltas = new Map<string, number>();
        const seen = new Map<string, number>();
        for (const q of next.queues) {
          const key = queueKey(q);
          const before = previous.current.get(key);
          if (before != null && before >= 0 && q.depth >= 0) {
            deltas.set(key, q.depth - before);
          }
          seen.set(key, q.depth);
        }
        previous.current = seen;
        setTrend(deltas);
        setDump(next);
      }
    } catch {
      setError("Could not reach the panel's API.");
    } finally {
      setLoading(false);
    }
  }, [limit]);

  //Paused still reads once -- and again when the page size changes -- so the page is never blank;
  //Live re-reads on the interval, and only while the tab is visible: a hidden tab walking every
  //queue every five seconds is load nobody is looking at (CP-P7)
  useEffect(() => {
    if (!live) {
      void load();
    }
  }, [load, live]);
  usePoll(load, REFRESH_MS, live, limit);

  const broker = dump?.queues.find((q) => q.kind === "broker") ?? null;
  const router = dump?.queues.find((q) => q.kind === "router") ?? null;

  const outgoing = useMemo<Outgoing[]>(() => {
    const byName = new Map<string, Outgoing>();
    for (const q of dump?.queues ?? []) {
      if (q.kind !== "pending" && q.kind !== "delayed") {
        continue;
      }
      let row = byName.get(q.name);
      if (!row) {
        row = { fullName: q.name, ...splitFullName(q.name), pending: null, delayed: null };
        byName.set(q.name, row);
      }
      row[q.kind] = q;
    }
    //vendors first, then the servers that hand receipts and replies back to clients; within each,
    //the order the gateway lists them, which is its own worker order
    return [...byName.values()].sort((a, b) => Number(a.type === KIND.server) - Number(b.type === KIND.server));
  }, [dump]);

  const inProcess = dump?.queues.filter((q) => q.kind !== "broker") ?? [];
  const total = inProcess.reduce((sum, q) => sum + Math.max(0, q.depth), 0);
  const deepestOut = Math.max(1, ...outgoing.map((o) => Math.max(0, o.pending?.depth ?? 0)));

  //the open queue: what the operator chose, if it still exists, otherwise the deepest one. A
  //selection that vanishes -- a delayed queue empties and the gateway stops listing it -- falls back
  //rather than leaving an empty card that reads as "this queue is fine"
  const current = ((): QueueSnapshot | null => {
    if (!dump) {
      return null;
    }
    const chosen = selected ? dump.queues.find((q) => queueKey(q) === selected) : undefined;
    if (chosen) {
      return chosen;
    }
    if (selected === queueKey(NO_BROKER) && !broker) {
      return NO_BROKER;
    }
    const deepest = [...inProcess].sort((a, b) => b.depth - a.depth)[0];
    return deepest && deepest.depth > 0 ? deepest : router ?? deepest ?? broker;
  })();

  function choose(q: QueueSnapshot) {
    const key = queueKey(q);
    setSelected(key);
    const params = new URLSearchParams(window.location.search);
    params.set(SELECTED_PARAM, key);
    //replaceState rather than router.push: no server round trip and no history entry per click
    window.history.replaceState(null, "", `?${params}`);
  }

  const currentKey = current ? queueKey(current) : null;
  const isServerRow = (o: Outgoing) => o.type === KIND.server;
  const { active, idle } = splitOutgoing(outgoing, {
    depth: (o) => Math.max(0, o.pending?.depth ?? 0),
    retries: (o) => Math.max(0, o.delayed?.depth ?? 0),
    selected: (o) =>
      (!!o.pending && queueKey(o.pending) === currentKey) || (!!o.delayed && queueKey(o.delayed) === currentKey),
    isServer: isServerRow,
  });
  const serverCount = outgoing.filter(isServerRow).length;
  const vendorCount = outgoing.length - serverCount;
  const brokerUnreachable = !!broker && broker.depth < 0;
  const brokerUnattended = !!broker && !brokerUnreachable && broker.depth > 0 && (broker.consumers ?? 0) === 0;

  return (
    <>
      <PageHeader
        title="Queues"
        description="Messages the gateway has accepted and not yet sent. Nothing here is charged twice or lost — but a queue that only grows is a customer waiting."
      />

      <Card className={cn((brokerUnreachable || brokerUnattended) && "border-destructive/50")}>
        <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
          <span className="text-title">Where messages are waiting</span>
          <CardActions>
            {dump && (
              <span className="text-sm text-muted-foreground">
                read at <span className="tabular-nums">{formatClockTime(dump.observed_at)}</span>
              </span>
            )}
            <Button
              variant="outline"
              size="sm"
              aria-pressed={live}
              onClick={() => setLive((v) => !v)}
              className={cn(live && "border-primary bg-primary-soft font-semibold text-primary")}
            >
              <span className={cn("h-1.5 w-1.5 rounded-full", live ? "bg-primary" : "bg-muted-foreground")} />
              {live ? "Live" : "Paused"}
            </Button>
            <Button variant="outline" size="sm" onClick={load}>
              <RefreshCw className="h-3.5 w-3.5" />
              Refresh
            </Button>
          </CardActions>
        </CardHeader>
        <CardContent className="space-y-3 pt-3">
          {loading && !dump && (
            <p className="text-sm text-muted-foreground">
              <Loader2 className="mr-2 inline h-4 w-4 animate-spin" />
              Reading the gateway&apos;s queues…
            </p>
          )}

          {error && (
            <p className="flex items-start gap-2 text-sm text-destructive">
              <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" />
              {error}
            </p>
          )}

          {dump && (
            //items-start, not stretch: the outgoing list is as tall as it is, and stretching made the
            //Broker and Router cells as tall too while their tiles stayed small at the top
            <div className="grid items-start gap-2.5 lg:grid-cols-[170px_auto_170px_auto_minmax(0,1fr)]">
              <Stage label="Broker">
                {broker ? (
                  <StageTile
                    selected={currentKey === queueKey(broker)}
                    bad={brokerUnreachable || brokerUnattended}
                    onClick={() => choose(broker)}
                  >
                    {/* depth is -1 when the sampler could not reach the broker. Never render that as
                        a number: a stranded queue displayed as "0 waiting" turns an incident into
                        a clean dashboard */}
                    <span className="text-figure tabular-nums">
                      {brokerUnreachable ? "unknown" : count(broker.depth)}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {brokerUnreachable
                        ? "not answering"
                        : `${count(broker.consumers ?? 0)} consumer${broker.consumers === 1 ? "" : "s"}`}
                    </span>
                    {brokerUnreachable && <Badge variant="destructive">Not answering</Badge>}
                    {brokerUnattended && <Badge variant="destructive">Nothing draining it</Badge>}
                  </StageTile>
                ) : (
                  <StageTile selected={currentKey === queueKey(NO_BROKER)} onClick={() => choose(NO_BROKER)}>
                    <span className="text-figure text-muted-foreground">None</span>
                    <span className="text-xs text-muted-foreground">REST goes straight to the router</span>
                  </StageTile>
                )}
              </Stage>

              <FlowArrow />

              <Stage label="Router">
                {router ? (
                  <StageTile selected={currentKey === queueKey(router)} onClick={() => choose(router)}>
                    <span className="text-figure tabular-nums">{count(router.depth)}</span>
                    <span className="text-xs text-muted-foreground">waiting to be routed</span>
                    <TrendMark delta={trend.get(queueKey(router))} />
                  </StageTile>
                ) : (
                  <div className="rounded-lg border border-border px-3 py-2.5 text-sm text-muted-foreground">Not reported</div>
                )}
              </Stage>

              <FlowArrow />

              <Stage
                label={`Outgoing · ${[
                  vendorCount ? `${vendorCount} vendor${vendorCount === 1 ? "" : "s"}` : "",
                  serverCount ? `${serverCount} server${serverCount === 1 ? "" : "s"}` : "",
                ].filter(Boolean).join(" · ") || "waiting · scheduled retries"}`}
              >
                {outgoing.length === 0 ? (
                  <div className="rounded-lg border border-border px-3 py-2.5 text-sm text-muted-foreground">
                    No outgoing workers are running.
                  </div>
                ) : (
                  //capped once unfolded, so even every idle queue on show cannot stretch the card
                  <div className={cn("overflow-hidden rounded-lg border border-border", showIdle && "max-h-[20rem] overflow-y-auto")}>
                    {[...active, ...(showIdle ? idle : [])].map((o) => (
                      <OutgoingRow
                        key={o.fullName}
                        row={o}
                        widthPct={((o.pending?.depth ?? 0) / deepestOut) * 100}
                        delta={o.pending ? trend.get(queueKey(o.pending)) : undefined}
                        selectedKey={currentKey}
                        onChoose={choose}
                      />
                    ))}
                    {idle.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setShowIdle((v) => !v)}
                        aria-expanded={showIdle}
                        //sticky, so "Hide idle" stays in view at the foot of the scrolled list
                        className="sticky bottom-0 flex w-full items-center gap-1.5 border-t border-border bg-card px-3 py-1.5 text-left text-xs text-muted-foreground first:border-t-0 hover:bg-accent hover:text-foreground"
                      >
                        {showIdle ? (
                          "Hide idle"
                        ) : (
                          <>
                            {active.length > 0 && "+ "}
                            {idleSummary(idle, isServerRow, active.length === 0)}
                            <span className="font-semibold text-primary">· show</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                )}
              </Stage>
            </div>
          )}

          {dump && (
            <p className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
              <span>
                <span className="font-semibold tabular-nums text-foreground">{count(total)}</span> waiting in
                the gateway
              </span>
              {broker && broker.depth > 0 && (
                <span>
                  + <span className="font-semibold tabular-nums text-foreground">{count(broker.depth)}</span> on
                  the broker
                </span>
              )}
              <span>
                {inProcess.length} in-process queue{inProcess.length === 1 ? "" : "s"}
              </span>
            </p>
          )}

          {dump && preprocessing.length > 0 && (
            <div className="flex flex-wrap items-center gap-2 border-t border-dashed border-border pt-3 text-sm">
              <span className="text-2xs font-semibold uppercase tracking-wide text-muted-foreground">With a preprocessor</span>
              {preprocessing.map((p) => (
                <Link
                  key={p.name}
                  href="/cp/preprocessors"
                  className="rounded-md border border-border px-2 py-1 hover:bg-accent"
                  title={`${p.ready}/${p.workers} copies ready · ${p.timeouts} timed out`}
                >
                  <span className="font-mono">@{p.name}</span>{" "}
                  <span className="font-semibold tabular-nums">{count(p.waiting)}</span>{" "}
                  <span className="text-muted-foreground">waiting{p.p99_ms != null ? ` · p99 ${p.p99_ms} ms` : ""}</span>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {current?.kind === "broker" && (
        <BrokerDetail broker={current === NO_BROKER ? null : current} restartNeeded={!!dump?.broker_restart_needed} onSaved={load} />
      )}
      {current && current.kind !== "broker" && (
        <QueueDetail
          queue={current}
          outgoing={outgoing.find((o) => o.fullName === current.name) ?? null}
          limit={limit}
          onLimit={setLimit}
          search={search}
          onSearch={setSearch}
          retriesOnly={retriesOnly}
          onRetriesOnly={setRetriesOnly}
        />
      )}

      {dump && inProcess.length === 0 && !error && (
        <Card>
          <CardContent className="py-4 text-sm text-muted-foreground">
            No in-process queues. Every message that arrived has already been handed to a vendor —
            which is what a healthy gateway looks like at rest.
          </CardContent>
        </Card>
      )}

      {/* last, below the reading: cleaning is the step after looking, never the first one */}
      <QueueCleanCard />
    </>
  );
}

function Stage({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="min-w-0">
      <p className="mb-1.5 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">{label}</p>
      {children}
    </div>
  );
}

function FlowArrow() {
  return (
    <ArrowRight
      aria-hidden
      //level with the middle of a tile -- the stage label above it, then half a tile -- rather than the
      //middle of the row, which the outgoing list makes as tall as it likes
      className="h-4 w-4 rotate-90 self-center justify-self-center text-muted-foreground lg:mt-[2.6rem] lg:rotate-0 lg:self-start"
    />
  );
}

function StageTile({
  selected,
  bad,
  onClick,
  children,
}: {
  selected: boolean;
  bad?: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={selected}
      className={cn(
        "flex w-full flex-col items-start gap-0.5 rounded-lg border border-border bg-card px-3 py-2.5 text-left transition-colors hover:bg-accent",
        bad && "border-destructive",
        selected && "border-primary ring-1 ring-primary"
      )}
    >
      {children}
    </button>
  );
}

/** ▲ growing, ▼ draining, · steady -- or nothing on the first read, when there is no "before". */
function TrendMark({ delta }: { delta: number | undefined }) {
  if (delta == null) {
    return null;
  }
  if (delta > 0) {
    return <span className="text-xs text-destructive" title={`${count(delta)} more than the last read`}>▲ growing</span>;
  }
  if (delta < 0) {
    return <span className="text-xs text-success" title={`${count(-delta)} fewer than the last read`}>▼ draining</span>;
  }
  return null;
}

function OutgoingRow({
  row,
  widthPct,
  delta,
  selectedKey,
  onChoose,
}: {
  row: Outgoing;
  widthPct: number;
  delta: number | undefined;
  selectedKey: string | null;
  onChoose: (q: QueueSnapshot) => void;
}) {
  const depth = row.pending?.depth ?? 0;
  const retries = row.delayed?.depth ?? 0;
  const pendingSelected = !!row.pending && selectedKey === queueKey(row.pending);
  const delayedSelected = !!row.delayed && selectedKey === queueKey(row.delayed);
  const failing = retries > 0;

  return (
    <div
      className={cn(
        "relative grid grid-cols-[minmax(0,1fr)_auto] items-center gap-x-3 border-t border-border px-3 py-1.5 first:border-t-0 sm:grid-cols-[minmax(0,1fr)_5.5rem_4.5rem_7rem]",
        (pendingSelected || delayedSelected) && "bg-primary-soft"
      )}
    >
      {/* the name and depth are one target -- the queue -- and the retries badge is a second,
          separate target. Nesting one button in another is invalid and swallows the inner click */}
      <button
        type="button"
        disabled={!row.pending}
        onClick={() => row.pending && onChoose(row.pending)}
        aria-pressed={pendingSelected}
        className="col-span-1 grid min-w-0 grid-cols-subgrid items-center text-left sm:col-span-3"
      >
        {/* one line: the name, then what it is. Wraps only when the name is too long for both */}
        <span className="flex min-w-0 flex-wrap items-baseline gap-x-2">
          <span className="truncate font-mono text-sm">{row.name}</span>
          <span className="text-2xs text-muted-foreground">
            {row.type === KIND.server ? "server → clients" : row.type ? KIND_LABEL[row.type].toLowerCase() : row.fullName}
          </span>
        </span>
        <span className="hidden text-right text-sm font-semibold tabular-nums sm:block">{count(depth)}</span>
        <span className="hidden sm:block">
          <TrendMark delta={delta} />
        </span>
      </button>
      <div className="flex items-center justify-end gap-2 sm:justify-start">
        <span className="text-sm font-semibold tabular-nums sm:hidden">{count(depth)}</span>
        {row.delayed && retries > 0 ? (
          <button
            type="button"
            onClick={() => onChoose(row.delayed!)}
            aria-pressed={delayedSelected}
            className="rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
          >
            <Badge variant="destructive" className={cn(delayedSelected && "ring-1 ring-destructive")}>
              ↻ {count(retries)} {retries === 1 ? "retry" : "retries"}
            </Badge>
          </button>
        ) : (
          <span className="text-xs text-muted-foreground">no retries</span>
        )}
      </div>
      {/* the depth bar is the row's bottom edge rather than a line of its own */}
      <div className="absolute inset-x-0 bottom-0 h-0.5 overflow-hidden" aria-hidden>
        <div
          className={cn("h-full", failing ? "bg-destructive" : "bg-primary")}
          style={{ width: `${depth > 0 ? Math.max(2, widthPct) : 0}%` }}
        />
      </div>
    </div>
  );
}

/**
 * The RabbitMQ queue REST submissions pass through. The broker does not list its messages, so the
 * detail is the two numbers and what they mean.
 */
function BrokerDetail({
  broker,
  restartNeeded,
  onSaved,
}: {
  /** Null when this gateway queues REST in process and has no broker row. */
  broker: QueueSnapshot | null;
  restartNeeded: boolean;
  onSaved: () => void;
}) {
  if (!broker) {
    return (
      <Card>
        <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
          <span className="text-title">Message broker</span>
          <Badge variant="outline">not used</Badge>
          {restartNeeded && <RestartBadge />}
        </CardHeader>
        <CardContent className="space-y-3 pt-3">
          <p className="text-sm text-muted-foreground">
            REST submissions go straight to the router queue. A RabbitMQ broker makes scheduled
            batches survive a restart and gives large batches back pressure.
          </p>
          <BrokerSettings restartNeeded={restartNeeded} onSaved={onSaved} />
        </CardContent>
      </Card>
    );
  }
  const unreachable = broker.depth < 0;
  const consumers = broker.consumers ?? 0;
  const unattended = !unreachable && broker.depth > 0 && consumers === 0;

  return (
    <Card className={cn((unreachable || unattended) && "border-destructive/50")}>
      <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
        <span className="text-title">Message broker</span>
        <Badge variant="outline" className="font-mono text-xs">{broker.name}</Badge>
        {unreachable && <Badge variant="destructive">Not answering</Badge>}
        {unattended && <Badge variant="destructive">Nothing draining it</Badge>}
        {restartNeeded && <RestartBadge />}
      </CardHeader>
      <CardContent className="space-y-3 pt-3">
        <div className="flex flex-wrap gap-6">
          <div>
            <div className="text-figure tabular-nums">
              {unreachable ? "unknown" : count(broker.depth)}
            </div>
            <div className="text-sm text-muted-foreground">Waiting on the broker</div>
          </div>
          <div>
            <div className="text-figure tabular-nums">{unreachable ? "—" : count(consumers)}</div>
            <div className="text-sm text-muted-foreground">Consumer{consumers === 1 ? "" : "s"} attached</div>
          </div>
        </div>

        {unreachable && (
          <p className="text-sm text-destructive">
            The gateway is configured to use this broker and cannot reach it. Publishes are falling
            back to the in-process queue, and whatever is already on the broker is stranded until it
            answers. The depth is unknown, not zero.
          </p>
        )}
        {unattended && (
          <p className="text-sm text-destructive">
            Messages are queued and no consumer is attached. This is not slowness — nothing is
            reading them. Check that the gateway started its consumer, and that this is the queue
            name it is consuming.
          </p>
        )}
        {broker.note && !unreachable && !unattended && <p className="text-sm text-muted-foreground">{broker.note}</p>}
        <p className="text-sm text-muted-foreground">
          Where REST submissions wait before they reach the router. A backlog here shows on Live
          health as a <em>flat</em> router queue, because the consumer stops pulling once the
          in-process queue passes its highwater mark. The broker does not list individual messages.
        </p>
        <BrokerSettings restartNeeded={restartNeeded} onSaved={onSaved} />
      </CardContent>
    </Card>
  );
}

function RestartBadge() {
  return (
    <Badge variant="outline" className="border-warning text-warning">
      Saved — restart the gateway to apply
    </Badge>
  );
}

/**
 * One in-process queue: the header carries the reading, the table carries the evidence.
 */
function QueueDetail({
  queue,
  outgoing,
  limit,
  onLimit,
  search,
  onSearch,
  retriesOnly,
  onRetriesOnly,
}: {
  queue: QueueSnapshot;
  outgoing: Outgoing | null;
  limit: number;
  onLimit: (n: number) => void;
  search: string;
  onSearch: (s: string) => void;
  retriesOnly: boolean;
  onRetriesOnly: (on: boolean) => void;
}) {
  const term = search.trim().toLowerCase();
  const filtering = term.length > 0 || retriesOnly;
  //filtered queues keep their real depth and get a filtered entry list. Rewriting depth to the
  //number of matches would answer a different question -- "how many of these are Acme's" is not
  //"how deep is this queue", and conflating them is how a filtered view gets mistaken for calm
  const entries = queue.entries.filter((entry: QueueEntry) => {
    if (retriesOnly && entry.retries === 0) {
      return false;
    }
    if (!term) {
      return true;
    }
    return [entry.account, entry.product, entry.from, entry.to, entry.serial, entry.target, entry.ingress].some(
      (field) => field?.toLowerCase().includes(term)
    );
  });
  //the reading describes the queue, so it is computed before any filter narrows it. A verdict of
  //"mostly retries" drawn from a retries-only view would be circular
  const verdict = filtering ? null : diagnose(queue);
  const failing = verdict?.startsWith("Mostly retries");
  const isServer = outgoing?.type === KIND.server;
  const title = outgoing ? outgoing.name : queue.name;
  const label =
    queue.kind === "pending" && isServer ? "Waiting for the client's session" : kindLabel(queue.kind);
  const href = outgoing ? workerHref(outgoing) : null;

  return (
    <Card>
      <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
        <span className="font-mono text-title">{title}</span>
        <Badge variant="outline">{label}</Badge>
        <span className="ml-auto flex items-baseline gap-1.5">
          <span className="text-figure tabular-nums">{count(queue.depth)}</span>
          <span className="text-sm text-muted-foreground">waiting</span>
        </span>
      </CardHeader>
      <CardContent className="space-y-3 pt-3">
        {verdict && (
          <p className={cn("rounded-md px-3 py-2 text-sm", failing ? "bg-destructive-soft text-destructive" : "bg-muted")}>
            {verdict}
          </p>
        )}
        {queue.note && <p className="text-sm text-muted-foreground">{queue.note}</p>}

        {/* these scope what the card lists, not the queue, so they sit with the list rather than in
            the footer where the card's actions go */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="search"
              value={search}
              onChange={(e) => onSearch(e.target.value)}
              placeholder="Account, sender, number, product…"
              aria-label="Search queued messages"
              className="h-11 w-full rounded-md border border-border bg-background pl-8 pr-3 text-sm focus:border-primary focus:outline-none md:h-9"
            />
          </div>
          <Button
            variant="outline"
            size="sm"
            aria-pressed={retriesOnly}
            onClick={() => onRetriesOnly(!retriesOnly)}
            className={cn(retriesOnly && "border-destructive bg-destructive-soft font-semibold text-destructive")}
          >
            Retries only
          </Button>
          <select
            value={limit}
            onChange={(e) => onLimit(Number(e.target.value))}
            aria-label="How many to list per queue"
            className="h-11 rounded-md border border-border bg-background px-3 text-sm focus:border-primary focus:outline-none md:h-9"
          >
            {[20, 50, 100, 500].map((n) => (
              <option key={n} value={n}>
                Show {n}
              </option>
            ))}
          </select>
          {/* the filter runs over what was listed, not over the whole queue. Saying so stops
              "3 matches" being read as "only 3 of this customer's messages are waiting" */}
          {filtering && (
            <span className="text-sm text-muted-foreground">
              {count(entries.length)} match{entries.length === 1 ? "" : "es"} among the {count(queue.returned)} listed
            </span>
          )}
        </div>

        {kindHint(queue.kind) && <p className="text-sm text-muted-foreground">{kindHint(queue.kind)}</p>}

        {entries.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            {filtering
              ? `Nothing listed here matches. ${queue.depth > 0 ? `${count(queue.depth)} waiting in total.` : "This queue is empty."}`
              : "Empty."}
          </p>
        ) : (
          <TableInCard>
            <THead>
              <TR>
                <TH>Queued</TH>
                <TH>Account</TH>
                <TH>Product</TH>
                <TH>From</TH>
                <TH>To</TH>
                <TH>Size</TH>
                <TH>Tries</TH>
                <TH>Via</TH>
                <TH>{queue.kind === "delayed" ? "Due" : "Next"}</TH>
              </TR>
            </THead>
            <TBody>
              {entries.map((e, i) => (
                <TR key={`${e.serial ?? e.msg_id}-${i}`}>
                  <TD muted className="whitespace-nowrap font-mono">
                    {formatClockTime(e.queued_at) || "—"}
                  </TD>
                  <TD className="font-mono">{e.account || "—"}</TD>
                  <TD className="font-mono">{e.product || "—"}</TD>
                  <TD className="font-mono">{e.from || "—"}</TD>
                  <TD className="font-mono">{e.to || "—"}</TD>
                  {/* characters and encoding, never the text. The gateway does not return it */}
                  <TD muted className="whitespace-nowrap">
                    {e.body_chars} char{e.body_chars === 1 ? "" : "s"} · {e.encoding}
                    {e.parts > 1 ? ` · ${e.parts} parts` : ""}
                  </TD>
                  <TD>
                    {e.retries > 0 ? (
                      <Badge variant="destructive">{e.retries}</Badge>
                    ) : (
                      <span className="text-muted-foreground">first</span>
                    )}
                  </TD>
                  <TD muted>{e.ingress || "—"}</TD>
                  <TD muted className="whitespace-nowrap">
                    {queue.kind === "delayed" && e.ready_in_ms != null
                      ? e.ready_in_ms <= 0
                        ? "due now"
                        : `in ${Math.round(e.ready_in_ms / 1000)}s`
                      : e.target || "—"}
                  </TD>
                </TR>
              ))}
            </TBody>
          </TableInCard>
        )}

        <p className="text-sm text-muted-foreground">
          Message text is deliberately not shown. It is not kept in call records either — operating
          the gateway never needs it, so the size and encoding stand in for it.
        </p>
      </CardContent>
      <CardFooter className="border-t border-border pt-3 text-sm text-muted-foreground">
        {/* the two numbers answer different questions, so never collapse them into one */}
        <span>
          Showing {count(Math.min(queue.returned, queue.depth))} of {count(queue.depth)}
          {!queue.ordered && queue.entries.length > 0 && " · not in send order"}
        </span>
        {href && (
          <Link href={href} className="ml-auto text-primary hover:underline">
            {title} settings →
          </Link>
        )}
      </CardFooter>
    </Card>
  );
}
