"use client";
import { useCallback, useEffect, useRef, useState } from "react";

export type Range = "24h" | "7d" | "30d";

export const RANGES: { value: Range; label: string }[] = [
  { value: "24h", label: "24 hours" },
  { value: "7d", label: "7 days" },
  { value: "30d", label: "30 days" },
];

/**
 * Thirty seconds: the overview is served from a snapshot the server refreshes on its own, so a poll
 * is a read of memory and the number of tabs no longer sets the database's load. The other control
 * endpoints still query, and a poll of them at this rate is what the snapshot route used to cost.
 */
const REFRESH_MS = 30_000;

/**
 * Fetches a control endpoint and keeps it fresh.
 *
 * <p>Polling stops while the tab is hidden and resumes with an immediate fetch, so a dashboard left
 * open overnight is not still querying a billing database every minute.
 */
export function useControlData<T>(endpoint: string, range: Range, query?: Record<string, string>) {
  //a string, so a caller's fresh object each render does not refetch
  const extra = query ? `&${new URLSearchParams(query).toString()}` : "";
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const inFlight = useRef(false);

  const load = useCallback(async () => {
    if (inFlight.current) return;
    inFlight.current = true;
    try {
      const res = await fetch(`/api/control/${endpoint}?range=${range}${extra}`, { cache: "no-store" });
      const json = await res.json();
      if (!res.ok) {
        //surface what the server said; an operator needs "permission denied for table cdr_submit"
        //rather than a generic failure
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      setData(json.data as T);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      inFlight.current = false;
      setLoading(false);
    }
  }, [endpoint, range, extra]);

  useEffect(() => {
    setLoading(true);
    load();

    let timer: ReturnType<typeof setInterval> | null = null;
    const start = () => {
      if (timer === null) timer = setInterval(load, REFRESH_MS);
    };
    const stop = () => {
      if (timer !== null) {
        clearInterval(timer);
        timer = null;
      }
    };
    const onVisibility = () => {
      if (document.hidden) {
        stop();
      } else {
        load();
        start();
      }
    };

    if (!document.hidden) start();
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      stop();
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [load]);

  return { data, error, loading, reload: load };
}
