"use client";
import { PageHeader } from "@/components/ui/page-header";
import { EmptyState } from "@/components/ui/empty-state";
import { TableInCard, TBody, TR, TD } from "@/components/ui/table";
import { HealthStrip } from "@/components/CardBits";
import { useEffect, useMemo, useState } from "react";
import {
  CheckCircle2, ChevronDown, ChevronRight, KeyRound, Loader2, Send,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { CodeBlock } from "./CodeBlock";
import { CopyButton } from "./CopyButton";
import { useApiAccess } from "./useApiAccess";
import { CustomTlvsEditor } from "./CustomTlvsEditor";
import { productOptions } from "@/lib/playground-rules";
import { buildCustomTlvs, type CustomTlv } from "@/lib/custom-tlvs";
import {
  CODE_LANGUAGES,
  ENDPOINTS,
  FALLBACK_MSISDN,
  SHARED_ERRORS,
  codeSample,
  exampleValue,
  type ApiEndpoint,
  type ApiField,
  type CodeLanguage,
  type EndpointId,
} from "@/lib/api-catalogue";

/**
 * Try the API for real, against this account.
 *
 * <p>The point is that it is real. A simulator proves nothing about the three things that actually
 * refuse a first integration — an unapproved sender ID, a missing mandatory parameter, and an empty
 * balance — and each of those returns a message that says exactly what to fix. So the response pane
 * shows the gateway's own status and body, unedited.
 *
 * <p><strong>The password lives here and nowhere else.</strong> It is component state, sent to the
 * panel's proxy on each call and never persisted — not to `localStorage`, not to a cookie, not into
 * the URL. It is deliberately not lifted into `useApiAccess`, which every page could reach.
 *
 * <p>Sends cost credit, and there is no confirmation step. That is a decision, not an omission: a
 * confirm dialog on the fourth click stops being read, and the button already says what it does.
 */
export function MisPlaygroundClient({ exampleTo }: {
  /** The platform's example destination, or null to keep the catalogue's own. */
  exampleTo?: string | null;
}) {
  const { access, loading } = useApiAccess();
  //empty means "whichever is first", resolved below rather than written into state by an effect.
  //Storing the default would mean a render where the select shows a login the request would not
  //use, and a cascading render to fix it
  const [chosen, setChosen] = useState("");
  const [password, setPassword] = useState("");
  const [checked, setChecked] = useState<null | { ok: boolean; detail: string }>(null);
  const [checking, setChecking] = useState(false);

  const [active, setActive] = useState<EndpointId>("send");
  const [values, setValues] = useState<Record<string, string>>(() => defaults(ENDPOINTS[0], exampleTo));
  //held apart from `values`, which is strings: these are rows, and flattening them to text is the
  //bug this whole change exists to remove
  const [tlvRows, setTlvRows] = useState<CustomTlv[]>([]);
  const [advanced, setAdvanced] = useState(false);
  const [language, setLanguage] = useState<CodeLanguage>("curl");

  const [sending, setSending] = useState(false);
  const [result, setResult] = useState<null | Result>(null);
  const [history, setHistory] = useState<Call[]>([]);

  const [senders, setSenders] = useState<string[]>([]);

  const endpoint = useMemo(() => ENDPOINTS.find((e) => e.id === active) ?? ENDPOINTS[0], [active]);

  const login = chosen || access?.logins[0]?.lookupKey || "";
  //derived rather than stored: the picker's contents follow the chosen login, and holding them in
  //state would mean a render where the two disagree
  const loginProducts = productOptions(access?.logins.find((l) => l.lookupKey === login));

  useEffect(() => {
    //approved sender IDs, so the commonest first failure is a dropdown rather than a 403. Only the
    //approved ones: a pending request is stored and not in use, and offering it would send a
    //customer looking for a fault in their code
    fetch("/api/mis/senders", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => setSenders(
        ((j?.data?.rows ?? []) as { header: string; status: string; enabled: boolean }[])
          .filter((r) => r.status === "APPROVED" && r.enabled)
          .map((r) => r.header)
      ))
      .catch(() => setSenders([]));
  }, []);

  function selectEndpoint(id: EndpointId) {
    setActive(id);
    setValues(defaults(ENDPOINTS.find((e) => e.id === id) ?? ENDPOINTS[0], exampleTo));
    setTlvRows([]);
    setResult(null);
    setAdvanced(false);
  }

  /**
   * Only the fields the customer actually filled in — an empty one is absent, not empty.
   *
   * <p><strong>The encoding belongs to the control, not to the field name.</strong> This used to
   * read `field.type === "integer" ? Number(raw) : raw`, a ladder with one rung, so an `object` or
   * `array` field went out as the literal text of its textarea. The gateway then answered
   * `Argument custom_tlvs has an invalid value: "{\"0x1401\":\"…\"}"` — a string where an object
   * belongs — and the customer, looking at valid JSON, had nothing to go on. `messages` on
   * `/secure/sendbatch` was unsendable for the same reason.
   *
   * <p>Keying off the control rather than the two field names is what stops a third structured
   * field reintroducing it: a new control has to say how it encodes.
   */
  const payload = useMemo(() => {
    const out: Record<string, unknown> = {};
    for (const field of endpoint.fields) {
      const raw = values[field.name];

      if (field.control === "pairs") {
        const built = buildCustomTlvs(tlvRows);
        if (built) {
          out[field.name] = built;
        }
        continue;
      }

      if (raw === undefined || raw === "") {
        continue;
      }
      if (field.control === "messages") {
        //parsed here so the code samples show a real array. An unparseable one is left out rather
        //than sent as text, and `messagesProblem` below is what tells the customer why
        const parsed = tryParse(raw);
        if (parsed !== undefined) {
          out[field.name] = parsed;
        }
        continue;
      }
      out[field.name] = field.type === "integer" ? Number(raw) : raw;
    }
    return out;
  }, [endpoint, values, tlvRows]);

  /** What is wrong with the batch textarea, or null. Shown by the field, and blocks the send. */
  const messagesProblem = useMemo(() => {
    const field = endpoint.fields.find((f) => f.control === "messages");
    const raw = field ? values[field.name] : undefined;
    if (!raw) {
      return null;
    }
    const parsed = tryParse(raw);
    if (parsed === undefined) {
      return "This is not valid JSON, so it cannot be sent. It should be a list, as in the example below.";
    }
    return Array.isArray(parsed) ? null : "This should be a list of messages, in square brackets.";
  }, [endpoint, values]);

  const sample = useMemo(
    () => codeSample(language, endpoint, payload, {
      baseUrl: access?.baseUrl ?? "https://your-gateway",
      login: login || "your-login",
    }),
    [language, endpoint, payload, access, login]
  );

  async function call(target: ApiEndpoint, quiet: boolean): Promise<Result> {
    const res = await fetch("/api/mis/playground", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        endpoint: target.id,
        login,
        password,
        payload: target.id === endpoint.id && !quiet ? payload : {},
      }),
    });
    const json = await res.json();
    if (!res.ok) {
      return { failed: json?.error ?? `Request failed (${res.status})` };
    }
    return json.data as Result;
  }

  async function check() {
    setChecking(true);
    setChecked(null);
    try {
      const out = await call(ENDPOINTS.find((e) => e.id === "balance")!, true);
      if (out.failed) {
        setChecked({ ok: false, detail: out.failed });
      } else if (out.unreachable) {
        setChecked({ ok: false, detail: out.detail ?? "The gateway could not be reached." });
      } else if (out.status === 200) {
        setChecked({ ok: true, detail: "Connected" });
      } else {
        setChecked({ ok: false, detail: out.ipHint ?? messageOf(out.body) ?? `Refused (${out.status})` });
      }
    } finally {
      setChecking(false);
    }
  }

  async function send() {
    setSending(true);
    setResult(null);
    try {
      const out = await call(endpoint, false);
      setResult(out);
      //the request that produced it, not just its outcome, so a call can be put back. Three sends
      //into narrowing down a 403 the useful thing is the body that got the 200, and the form has
      //been edited twice since
      setHistory((prev) => [
        {
          //`Date.now()` rather than an incrementing counter: two calls can resolve in the same
          //millisecond, so the key pairs it with the length, and the clock is shown as well
          at: Date.now(),
          endpoint: endpoint.id,
          method: endpoint.method,
          path: endpoint.path,
          status: out.status,
          failed: Boolean(out.failed || out.unreachable),
          ms: out.ms,
          values,
        },
        ...prev,
      ].slice(0, HISTORY_DEPTH));
    } finally {
      setSending(false);
    }
  }

  function replay(call: Call) {
    setActive(call.endpoint);
    setValues(call.values);
    setResult(null);
  }

  const header = (
    <PageHeader
      title="API playground"
      description="Real requests against your live account. A send goes to the handset and costs credit."
    />
  );

  if (loading) {
    return (
      <>
        {header}
        <EmptyState>Loading…</EmptyState>
      </>
    );
  }

  if (!access?.baseUrl) {
    return (
      <>
        {header}
        <Card>
          <CardContent className="py-4 text-sm text-muted-foreground">
            The playground is not available on this deployment — nobody has told the panel where the
            messaging API is. The reference page still describes every endpoint.
          </CardContent>
        </Card>
      </>
    );
  }

  const shown = endpoint.fields.filter((f) => advanced || !f.advanced);
  const hasAdvanced = endpoint.fields.some((f) => f.advanced);

  return (
    <>
      {header}

      {/* amber only while the credential is unproven. Once it has connected the strip goes quiet:
          a warning that never resolves is a warning nobody reads, and this page has exactly one
          thing worth an alarm colour */}
      {checked?.ok ? (
        <div className="flex flex-wrap items-center gap-2 rounded-lg bg-muted/50 px-3 py-2 text-sm">
          <CheckCircle2 className="h-4 w-4 shrink-0 text-success" />
          <span className="text-muted-foreground">Connected as</span>
          <span className="font-mono">{login}</span>
          <button type="button" onClick={() => setChecked(null)}
            className="ml-auto text-muted-foreground underline hover:text-foreground">
            Change
          </button>
        </div>
      ) : (
        <div className="rounded-lg border border-warning/40 bg-warning-soft/40 p-3">
          <div className="flex flex-wrap items-center gap-2">
            <KeyRound className="h-4 w-4 shrink-0 text-warning" />
            {/* a login name is an identifier the customer also types into their own configuration,
                so it is set like one here and in the reference page's header chip */}
            <Select value={login} onChange={(e) => { setChosen(e.target.value); setChecked(null); }}
              className="h-8 w-full font-mono text-sm sm:w-auto sm:min-w-[10rem]">
              {access.logins.length === 0 && <option value="">No API login on this account</option>}
              {access.logins.map((l) => (
                <option key={l.lookupKey} value={l.lookupKey}>{l.lookupKey}</option>
              ))}
            </Select>
            <Input type="password" value={password} placeholder="Its password"
              onChange={(e) => { setPassword(e.target.value); setChecked(null); }}
              className="h-8 w-full font-mono text-sm sm:w-44" />
            <Button variant="outline" size="sm" onClick={check}
              disabled={checking || !login || !password}>
              {checking ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
              Check
            </Button>
            {checked && !checked.ok && (
              //the gateway's own refusal, which the reference page sets in monospace in its error
              //table. The same sentence in two typefaces on two pages was the drift
              <span className="font-mono text-sm text-destructive">{checked.detail}</span>
            )}
          </div>
          <p className="mt-2 text-xs text-warning">
            Held in this tab only — never stored, never logged. It is the same password your own
            software uses, so a wrong one fails here rather than in your code.
          </p>
        </div>
      )}

      <Tabs label="Endpoints" active={active} onSelect={selectEndpoint}
        items={ENDPOINTS.map((e) => ({
          id: e.id,
          label: e.title,
          prefix: <MethodBadge method={e.method} />,
          //the path each tab actually calls. Without it the tabs name five things a customer has
          //to already know the URLs of, on the one page whose job is to teach them
          suffix: <span className="font-mono text-xs text-muted-foreground">{e.path}</span>,
        }))} />

      <p className="text-sm text-muted-foreground">{endpoint.blurb}</p>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="min-w-0 space-y-3">
          {shown.map((field) => (
            <Field key={field.name} field={field} senders={senders}
              products={loginProducts}
              exampleTo={exampleTo}
              tlvRows={tlvRows}
              onTlvRows={setTlvRows}
              messagesProblem={messagesProblem}
              value={values[field.name] ?? ""}
              onChange={(v) => setValues((prev) => ({ ...prev, [field.name]: v }))} />
          ))}

          {!endpoint.fields.length && (
            <p className="text-sm text-muted-foreground">
              Nothing to fill in — this call takes no parameters.
            </p>
          )}

          {hasAdvanced && (
            <button type="button" onClick={() => setAdvanced(!advanced)}
              className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
              {advanced ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
              Delivery receipts, validity and custom parameters
            </button>
          )}

          <div className="flex flex-wrap items-center gap-3 pt-1">
            {/* a broken batch textarea blocks the send rather than silently dropping the field: a
                request that omitted `messages` would come back as a puzzling gateway refusal about
                a field the customer can see they filled in */}
            <Button
              onClick={send}
              disabled={sending || !!messagesProblem || (endpoint.secured && (!login || !password))}
            >
              {sending
                ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
                : <Send className="mr-1.5 h-4 w-4" />}
              {endpoint.method === "POST" ? "Send" : "Call"}
            </Button>
            {endpoint.id === "send" && (
              <span className="text-xs text-muted-foreground">Charged when the gateway accepts it.</span>
            )}
          </div>
        </div>

        <div className="min-w-0 space-y-4">
          <CodeBlock
            code={sample}
            title="Request"
            copyLabel="Copy request"
            right={
              <span className="flex gap-2">
                {CODE_LANGUAGES.map((l) => (
                  <button key={l} type="button" onClick={() => setLanguage(l)}
                    className={"text-xs " + (l === language
                      ? "border-b border-foreground text-foreground"
                      : "text-muted-foreground hover:text-foreground")}>
                    {l}
                  </button>
                ))}
              </span>
            }
          />

          <Response result={result} sending={sending} endpoint={endpoint} />

          {history.length > 0 && <History calls={history} onReplay={replay} />}
        </div>
      </div>
    </>
  );
}

/** Rows a call history keeps. Shallow on purpose — see {@link History}. */
const HISTORY_DEPTH = 5;

interface Call {
  at: number;
  endpoint: EndpointId;
  method: "GET" | "POST";
  path: string;
  status?: number;
  /** The panel refused, or the gateway could not be reached — there is no status to show. */
  failed: boolean;
  ms?: number;
  /** The form as it was, so the call can be put back. */
  values: Record<string, string>;
}

/**
 * The last few calls made in this tab.
 *
 * <p>Component state and nothing else. **Not `localStorage`**, for the same reason the password is
 * not: these rows carry the request bodies, which on this page are real destinations and real
 * message text belonging to a live account. A convenience that outlives the tab is a convenience
 * that outlives the person at the keyboard.
 *
 * <p>Five rows, not fifty. This is a prompt to go back one step while narrowing down a refusal, not
 * a log — the message list is the log, and it is authoritative where this is not.
 */
function History({ calls, onReplay }: { calls: Call[]; onReplay: (call: Call) => void }) {
  return (
    <div className="rounded-lg bg-muted/50 p-1">
      <p className="px-4 py-1 text-xs text-muted-foreground">
        This tab&rsquo;s last {calls.length === 1 ? "call" : `${calls.length} calls`} — select one to
        put its request back
      </p>
      <TableInCard>
        <TBody>
          {calls.map((call, i) => (
            <TR key={`${call.at}-${i}`}>
              <TD className="w-14">
                <StatusChip status={call.status} failed={call.failed} />
              </TD>
              <TD muted className="font-mono">
                {call.method} {call.path}
              </TD>
              <TD muted num>
                {call.ms == null ? "" : `${call.ms} ms`}
              </TD>
              <TD align="right">
                <button type="button" onClick={() => onReplay(call)}
                  className="text-muted-foreground underline hover:text-foreground">
                  Load
                </button>
              </TD>
            </TR>
          ))}
        </TBody>
      </TableInCard>
    </div>
  );
}

/** An HTTP status, coloured by class. Monospace, like every other status on these two pages. */
function StatusChip({ status, failed }: { status?: number; failed?: boolean }) {
  if (status == null) {
    return (
      <span className="rounded bg-destructive/10 px-1.5 py-0.5 font-mono text-destructive">
        {failed ? "—" : "?"}
      </span>
    );
  }
  const ok = status >= 200 && status < 300;
  return (
    <span className={"rounded px-1.5 py-0.5 font-mono " + (ok
      ? "bg-success-soft/60 text-success"
      : "bg-destructive/10 text-destructive")}>
      {status}
    </span>
  );
}

interface Result {
  status?: number;
  ms?: number;
  body?: string;
  ipHint?: string | null;
  unreachable?: boolean;
  detail?: string;
  /** Set when the panel itself refused, before the gateway was called. */
  failed?: string;
}

/**
 * What came back, and what it means.
 *
 * <p><strong>The explanation is looked up in `api-catalogue.ts`</strong> — the same descriptions the
 * reference page renders in its error tables. A `402` here says "Your prepaid balance will not cover
 * the message. Nothing was sent or charged." because that sentence is already written down once, for
 * both pages. The alternative was a second copy of every refusal, in a component, drifting from the
 * documentation the customer read five minutes earlier.
 *
 * <p>Matched on status **and** the gateway's own message where there is one, because a single status
 * covers several refusals: `403` is an unapproved sender ID, an unapproved template and an IP
 * outside the allow list, and telling somebody the wrong one costs them an afternoon.
 */
function Response({ result, sending, endpoint }: {
  result: Result | null;
  sending: boolean;
  endpoint: ApiEndpoint;
}) {
  if (sending) {
    return <CodeBlock code="" title="Response" right={<span className="text-xs text-muted-foreground">waiting…</span>} />;
  }
  if (!result) {
    return <CodeBlock code="" title="Response" right={<span className="text-xs text-muted-foreground">not sent yet</span>} />;
  }
  //the panel refused before calling, or the gateway was unreachable. Neither has a status, so
  //neither gets the status line -- but both keep the block's shape, so the pane does not jump
  if (result.failed || result.unreachable) {
    return (
      <HealthStrip tone="destructive">
        <span className="block font-medium">
          {result.failed ? "The panel could not make this call" : "The gateway did not answer"}
        </span>
        <span className="block font-mono">{result.failed ?? result.detail}</span>
      </HealthStrip>
    );
  }

  const status = result.status ?? 0;
  const ok = status >= 200 && status < 300;
  const said = messageOf(result.body);
  const explained = explain(endpoint, status, said);
  const messageId = messageIdOf(result.body);

  return (
    <div className="space-y-2">
      <div className="rounded-lg border border-border p-3">
        <div className="flex flex-wrap items-center gap-2">
          <StatusChip status={status} />
          <span className="text-sm font-medium">
            {ok ? okTitle(endpoint) : said ?? "Refused"}
          </span>
          <span className="ml-auto text-xs tabular-nums text-muted-foreground">
            {result.ms} ms
          </span>
        </div>

        {explained && (
          <p className="mt-1.5 text-sm text-muted-foreground">{explained}</p>
        )}

        {/* the id a customer needs to correlate their own record with ours, next to the one control
            that gets it there intact. Reading it out of a JSON block by eye is where a transposed
            character comes from */}
        {messageId && (
          <div className="mt-2 flex flex-wrap items-center gap-2 text-sm">
            <span className="text-muted-foreground">Message ID</span>
            <span className="font-mono break-all">{messageId}</span>
            <CopyButton value={messageId} label="Copy" />
          </div>
        )}
      </div>

      <CodeBlock code={pretty(result.body ?? "")} title="Body" copyLabel="Copy response" />

      {result.ipHint && (
        <HealthStrip tone="warning">{result.ipHint}</HealthStrip>
      )}
    </div>
  );
}

/** What a 2xx from this endpoint actually did, in the endpoint's own vocabulary. */
function okTitle(endpoint: ApiEndpoint): string {
  return endpoint.id === "send" || endpoint.id === "sendbatch" ? "Queued" : "OK";
}

/**
 * The documented meaning of this status, from the catalogue both customer pages are built from.
 *
 * <p>Endpoint-specific errors first, then the shared ones, because a `403` on `/secure/send` has a
 * more useful description than the generic authorisation failure. Null when the catalogue does not
 * describe it — an undocumented status is better left to the body than glossed with a guess.
 */
function explain(endpoint: ApiEndpoint, status: number, said: string | null): string | null {
  const candidates = [...endpoint.errors, ...SHARED_ERRORS].filter((e) => e.status === status);
  if (!candidates.length) {
    return null;
  }
  //several refusals share a status, so prefer the one whose documented message the gateway actually
  //echoed. Substring rather than equality: several carry a `<name>` placeholder the gateway fills in
  const matched = said
    ? candidates.find((e) => overlaps(e.message, said))
    : undefined;
  return (matched ?? candidates[0]).when;
}

/** Whether a documented message and a returned one are the same refusal, allowing for placeholders. */
function overlaps(documented: string, said: string): boolean {
  const stem = documented.split("<")[0].trim().toLowerCase();
  return stem.length > 0 && said.toLowerCase().includes(stem);
}

/** The id a send returns, which is the one value on this page worth copying exactly. */
function messageIdOf(body: string | undefined): string | null {
  if (!body) {
    return null;
  }
  try {
    const parsed = JSON.parse(body) as { data?: { messageId?: string; batchId?: string } };
    return parsed.data?.messageId ?? parsed.data?.batchId ?? null;
  } catch {
    return null;
  }
}

function Field({
  field, value, onChange, senders, products, exampleTo, tlvRows, onTlvRows, messagesProblem,
}: {
  field: ApiField;
  value: string;
  onChange: (v: string) => void;
  senders: string[];
  /** The TLV rows, for the one control that is not a string. */
  tlvRows: CustomTlv[];
  onTlvRows: (rows: CustomTlv[]) => void;
  /** What is wrong with the batch textarea, or null. Rendered under it. */
  messagesProblem: string | null;
  /** The platform's example destination, for the one placeholder that spells a whole message out. */
  exampleTo?: string | null;
  /**
   * What this login may name on `product`, its own product first. Empty means the field is refused,
   * so it is read-only -- which is now only true of a login carrying no product at all.
   */
  products: string[];
}) {
  const id = `pg-${field.name}`;
  return (
    <div>
      <Label htmlFor={id} className="mb-1 flex items-baseline gap-1.5">
        <span className="font-mono text-sm">{field.name}</span>
        {field.required === true && <span className="text-xs text-destructive">required</span>}
        {field.required === "either" && <span className="text-xs text-muted-foreground">one of two</span>}
        {field.fallback && (
          <span className="text-xs text-muted-foreground">
            defaults to <span className="font-mono">{field.fallback}</span>
          </span>
        )}
      </Label>

      {/* every control below holds a value that goes on the wire, so every one is monospace -- the
          field NAME above them already was, and setting the name as code and the value as prose made
          one fact look like two. The JSON textareas further down have always done it this way */}
      {field.control === "textarea" ? (
        <Textarea id={id} value={value} onChange={(e) => onChange(e.target.value)} rows={3}
          className="font-mono" />
      ) : field.control === "select" ? (
        <Select id={id} value={value} onChange={(e) => onChange(e.target.value)} className="font-mono">
          {field.choices?.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
        </Select>
      ) : field.control === "senderId" ? (
        //a list, because an unapproved sender ID is the commonest first 403 -- but still typeable,
        //since approval can land between this page loading and the send
        <>
          <Input id={id} list={`${id}-approved`} value={value} className="font-mono"
            onChange={(e) => onChange(e.target.value)}
            placeholder={senders[0] ?? "your login name"} />
          <datalist id={`${id}-approved`}>
            {senders.map((s) => <option key={s} value={s} />)}
          </datalist>
        </>
      ) : field.control === "product" ? (
        //a select rather than free text, because naming something off the list is a 403 rather than
        //a typo -- and read-only only when there is genuinely nothing to choose, which is a login
        //carrying no product and opted into none. Offering an empty box there would be offering a
        //guaranteed failure
        products.length > 0 ? (
          <Select id={id} value={value} onChange={(e) => onChange(e.target.value)} className="font-mono">
            <option value="">Your login&rsquo;s own product</option>
            {products.map((p) => <option key={p} value={p}>{p}</option>)}
          </Select>
        ) : (
          <p className="text-xs text-muted-foreground">
            This login carries no product and your operator has not allowed it to name one. Sending
            this field would be refused.
          </p>
        )
      ) : field.control === "pairs" ? (
        //rows rather than a JSON box, and not for tidiness: the box could not be sent. Its text went
        //into the payload as a string, so the gateway saw a string where an object belongs and
        //refused every attempt, quoting back JSON the customer could see was valid
        <CustomTlvsEditor rows={tlvRows} onChange={onTlvRows} />
      ) : field.control === "messages" ? (
        <>
          <Textarea id={id} value={value} onChange={(e) => onChange(e.target.value)} rows={4}
            spellCheck={false}
            className="font-mono"
            placeholder={`[{"to":"${exampleTo || FALLBACK_MSISDN}","content":"one"}]`} />
          {messagesProblem && (
            <p className="mt-1 text-xs text-warning">
              {messagesProblem}
            </p>
          )}
        </>
      ) : (
        <Input id={id} type={field.control === "number" ? "number" : "text"} value={value}
          className="font-mono" onChange={(e) => onChange(e.target.value)} />
      )}

      <p className="mt-1 text-xs text-muted-foreground">{field.note}</p>
    </div>
  );
}

function MethodBadge({ method }: { method: "GET" | "POST" }) {
  return (
    <span className={"rounded px-1 py-0.5 font-mono text-xs " + (method === "POST"
      ? "bg-success-soft/60 text-success"
      : "bg-muted text-muted-foreground")}>
      {method}
    </span>
  );
}

/**
 * What the form starts with, and deliberately not more.
 *
 * <p>A field behind the disclosure is left empty even when it has choices, so it does not appear in
 * the request. Prefilling `dlr: "no"` and `priority: 0` would be harmless to send and wrong to
 * show — the example a customer copies should be the smallest thing that works, not every field set
 * to its own default. The reference table is where the defaults are stated.
 */
function defaults(endpoint: ApiEndpoint, msisdn?: string | null): Record<string, string> {
  const out: Record<string, string> = {};
  for (const field of endpoint.fields) {
    const example = exampleValue(field, msisdn);
    if (example !== undefined) {
      out[field.name] = example;
    } else if (field.choices?.length && !field.advanced) {
      out[field.name] = field.choices[0].value;
    }
  }
  return out;
}

/**
 * JSON, or undefined when it is not.
 *
 * <p>Undefined rather than a throw or a null: null is a legal JSON value, and a caller that could
 * not tell "the customer typed null" from "this did not parse" would send one as the other.
 */
function tryParse(text: string): unknown {
  try {
    return JSON.parse(text);
  } catch {
    return undefined;
  }
}

/** Pretty-print when it is JSON, and show it as it came when it is not. */
function pretty(body: string): string {
  try {
    return JSON.stringify(JSON.parse(body), null, 2);
  } catch {
    return body;
  }
}

/** The gateway's own sentence, which is the useful half of any refusal. */
function messageOf(body: string | undefined): string | null {

  if (!body) {
    return null;
  }
  try {
    const parsed = JSON.parse(body) as { message?: string };
    return parsed.message ?? null;
  } catch {
    return null;
  }
}
