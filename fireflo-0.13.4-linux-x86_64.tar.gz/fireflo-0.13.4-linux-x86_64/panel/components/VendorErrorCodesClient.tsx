"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowDownToLine, ArrowRight } from "lucide-react";
import { HealthStrip } from "@/components/CardBits";
import { ErrorCodeEditor } from "@/components/ErrorCodeEditor";
import { listHref, useErrorCodes } from "@/components/ErrorCodesShell";
import { SaveBar } from "@/components/SaveBar";
import { SettingsSection } from "@/components/SettingsSection";
import { Button, buttonClasses } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";
import { Segmented } from "@/components/ui/segmented";
import { errorCodeProblem, formatErrorCodes, parseErrorCodes, type ErrorCodePair } from "@/lib/error-codes";

/**
 * One vendor's error-code list, with the Every vendor list it replaces beneath it.
 *
 * <h2>The replacement is what this page exists to make visible</h2>
 *
 * <p>The gateway reads one value: a vendor with a list of its own does not see the Every vendor
 * list at all, so a vendor that maps only 630 silently loses every other global entry.
 * {@code FireFloConfigurationHandler.get} falls back to the default key only when the vendor's is
 * unresolved. So the global list is shown read-only below, with a control to copy each row in, and
 * a warning whenever this vendor's list would replace it.
 *
 * <h2>Three answers for an unmapped code, and all three are shown</h2>
 *
 * <p>The vendor may follow the Every vendor answer, or say on or off for itself. A checkbox showed
 * two of those and hid which one was in force; the choice now names all three.
 *
 * <p>Writes go through PATCH with one property, not the vendor's full save, which would need a
 * complete copy of the vendor, password included, just to change one mapping. An empty value
 * deletes the property, which is how "inherit" is stored.
 */
type Pass = "inherit" | "on" | "off";

export function VendorErrorCodesClient({ name }: { name: string }) {
  const data = useErrorCodes();
  const vendor = data.vendors.find((v) => v.name === name);
  const [pairs, setPairs] = useState<ErrorCodePair[]>([]);
  //whether this page is staging a list of its own -- distinct from a list that happens to be empty
  const [ownList, setOwnList] = useState(false);
  const [pass, setPass] = useState<Pass>("inherit");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const storedOwn = vendor?.own ?? null;
  const storedPass: Pass = vendor?.passthrough === null || vendor === undefined
    ? "inherit"
    : vendor.passthrough ? "on" : "off";

  const reset = () => {
    setPairs(parseErrorCodes(storedOwn));
    setOwnList(storedOwn !== null);
    setPass(storedPass);
  };
  //adopt what the layout loaded, and again after a save reloads it or another vendor is opened
  useEffect(() => {
    //eslint-disable-next-line react-hooks/set-state-in-effect -- copying the layout's data into an editable draft
    setPairs(parseErrorCodes(storedOwn));
    setOwnList(storedOwn !== null);
    setPass(storedPass);
  }, [storedOwn, storedPass]);

  if (data.loading) {
    return <p className="text-sm text-muted-foreground">Loading…</p>;
  }
  if (!vendor) {
    return (
      <EmptyState>
        There is no SMPP vendor named <code className="font-mono">{name}</code>. Error codes belong to
        whoever sent them, so there is nothing to translate here.{" "}
        <Link href={listHref(null)} className="text-primary hover:underline">
          The Every vendor list →
        </Link>
      </EmptyState>
    );
  }

  //a list is "own" once it is stored, or once somebody has started one here
  const own = ownList || pairs.length > 0;
  const targetList = own ? formatErrorCodes(pairs) : null;
  const listChanged = targetList !== storedOwn && !(targetList === "" && storedOwn === null);
  const passChanged = pass !== storedPass;
  const dirty = (listChanged ? 1 : 0) + (passChanged ? 1 : 0);
  const blocked = pairs.some((p) => errorCodeProblem(p) !== null);
  const globalCount = data.globalPairs.length;
  const inheritedAnswer = data.globalPassthrough ? "on" : "off";

  async function patch(key: string, value: string): Promise<boolean> {
    const res = await fetch(`/api/control/workers/${encodeURIComponent(name)}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ property: { key, value } }),
    });
    if (!res.ok) {
      const body = await res.json().catch(() => null);
      setError(body?.error ?? "That could not be saved.");
      return false;
    }
    return true;
  }

  async function save() {
    setSaving(true);
    setError(null);
    try {
      //an empty list of its own is stored as nothing: inheriting is the only way to have no list
      if (listChanged && !(await patch("dlr.errcodes", targetList ?? ""))) return;
      if (passChanged && !(await patch("dlr.errcodes.passthrough", pass === "inherit" ? "" : pass === "on" ? "true" : "false"))) return;
    } finally {
      setSaving(false);
      await data.reload();
    }
  }

  return (
    <>
      {(error || data.error) && <HealthStrip tone="destructive">{error ?? data.error}</HealthStrip>}

      <SettingsSection
        id="vendor"
        title={
          <span className="flex flex-wrap items-center gap-2">
            <span className="font-mono">{name}</span>
            <span className={own
              ? "rounded-full bg-primary-soft px-2 py-px text-2xs font-medium text-primary"
              : "rounded-full bg-muted px-2 py-px text-2xs font-medium text-muted-foreground"}>
              {own ? "Own list" : "Inherits"}
            </span>
          </span>
        }
        description={own
          ? "Uses its own list. The Every vendor list does not apply to this vendor."
          : "Uses the Every vendor list. Adding a mapping here starts a list of its own, which replaces it."}
        action={
          <>
            {own && (
              //back to inheriting: clearing the key is the only way to get the global list applying again
              <Button type="button" variant="outline" size="sm" disabled={saving}
                onClick={() => {
                  setPairs([]);
                  setOwnList(false);
                }}>
                Use the Every vendor list
              </Button>
            )}
            <Link href={`/cp/vendors/${encodeURIComponent(name)}`} className={buttonClasses({ variant: "ghost", size: "sm" })}>
              Vendor settings <ArrowRight className="ml-1 h-3.5 w-3.5" aria-hidden="true" />
            </Link>
          </>
        }
        bodyClassName="px-5 py-4 space-y-3"
      >
        {/* shown whenever a list exists or is being started, because that is exactly when the
            replacement bites. The gateway reads one value; it does not merge the tiers */}
        {own && globalCount > 0 && (
          <HealthStrip tone="warning">
            This list replaces the Every vendor list for {name}; it does not add to it. Its{" "}
            {globalCount} {globalCount === 1 ? "entry stops" : "entries stop"} applying here, including
            any not repeated above.
          </HealthStrip>
        )}
        <ErrorCodeEditor pairs={pairs} onChange={setPairs} disabled={saving} />
      </SettingsSection>

      <SettingsSection id="unmapped" title="Codes nobody mapped" bodyClassName="px-5 py-4 space-y-2">
        <p className="text-sm text-muted-foreground">
          How a code {name} sends that no mapping covers reaches the customer: as sent, or as 018.
          Inherit follows the Every vendor answer, which is {inheritedAnswer === "on" ? "as sent" : "as 018"} today.
        </p>
        <Segmented<Pass>
          label={`Unmapped codes from ${name}`}
          value={pass}
          onChange={setPass}
          disabled={saving}
          fill
          className="max-w-md"
          options={[
            { value: "inherit", label: `Inherit (${inheritedAnswer})` },
            { value: "on", label: "As sent" },
            { value: "off", label: "As 018" },
          ]}
        />
        {passChanged && (
          <p className="text-xs text-primary">
            Unsaved. Was {storedPass === "inherit" ? `following Every vendor (${inheritedAnswer})` : storedPass === "on" ? "as sent" : "as 018"}.
          </p>
        )}
      </SettingsSection>

      <SettingsSection
        id="every-vendor"
        title={own ? "The Every vendor list, not used here" : "Inherited today"}
        description={`${globalCount} mapped. Copy a row into this vendor's list to keep it when the list replaces the global one.`}
        action={
          <Link href={listHref(null)} className={buttonClasses({ variant: "outline", size: "sm" })}>
            Edit for every vendor
          </Link>
        }
        bodyClassName="px-5 py-2"
      >
        {globalCount === 0 ? (
          <p className="py-2 text-sm text-muted-foreground">
            Nothing is mapped for every vendor, so this vendor inherits no translations.
          </p>
        ) : (
          <ul className="divide-y divide-border/60">
            {data.globalPairs.map((pair) => {
              const copied = pairs.some((p) => p.carrier === pair.carrier);
              return (
                <li key={pair.carrier} className="flex items-center justify-between gap-3 py-1.5 text-sm">
                  <span className="font-mono text-muted-foreground">
                    {pair.carrier} → {pair.ours}
                  </span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="gap-1.5"
                    disabled={saving || copied}
                    onClick={() => setPairs((prev) => [...prev, { ...pair }])}
                  >
                    <ArrowDownToLine className="h-3.5 w-3.5" aria-hidden="true" />
                    {copied ? "In this list" : "Copy here"}
                  </Button>
                </li>
              );
            })}
          </ul>
        )}
      </SettingsSection>

      <SaveBar
        count={dirty}
        saving={saving}
        blocked={blocked}
        message={`Nothing has reached ${name} yet.`}
        blockedMessage="Fix the highlighted mapping before saving."
        onDiscard={reset}
        onSave={() => void save()}
        inset
      />
    </>
  );
}
