"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SettingsRow } from "@/components/ui/settings-row";
import { SettingsSection } from "@/components/ui/settings-section";
import { PageHeader } from "@/components/ui/page-header";
import { PasswordFields } from "./PasswordFields";

/**
 * A customer setting or changing their own portal password.
 *
 * <p>The first one needs nothing but the session -- whoever is here signed in by a link mailed to
 * the address. Changing one asks for the current password too; see app/api/mis/password.
 */
export function MisPasswordClient() {
  const [state, setState] = useState<{ email: string; hasPassword: boolean } | null>(null);
  const [current, setCurrent] = useState("");
  const [password, setPassword] = useState("");
  const [ready, setReady] = useState(false);
  //remounts the new-password fields after a save, so they clear rather than showing the old value
  const [round, setRound] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    void (async () => {
      const res = await fetch("/api/mis/password", { cache: "no-store" }).catch(() => null);
      const json = await res?.json().catch(() => null);
      if (res?.ok && json?.data) {
        setState(json.data);
      } else {
        setError("Could not read your login.");
      }
    })();
  }, []);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const res = await fetch("/api/mis/password", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ current, password }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? "Your password was not saved.");
        return;
      }
      setNotice(state?.hasPassword ? "Password changed." : "Password set. You can sign in with it next time.");
      setState(json.data);
      setCurrent("");
      setPassword("");
      setReady(false);
      setRound((r) => r + 1);
    } catch {
      setError("Could not reach the server. Try again.");
    } finally {
      setBusy(false);
    }
  }

  const needsCurrent = state?.hasPassword ?? false;

  return (
    <>
      <PageHeader title="Password" description="How you sign in to this portal." />
      <form onSubmit={save} className="max-w-3xl">
        <SettingsSection
          id="password"
          title={needsCurrent ? "Change your password" : "Set a password"}
          description={state
            ? needsCurrent
              ? `You sign in as ${state.email} with a password, or by emailed link.`
              : `You sign in as ${state.email} by emailed link. Set a password to sign in without waiting for mail.`
            : "Reading…"}
          action={state && (
            <Button type="submit" size="sm" disabled={busy || !ready || (needsCurrent && !current)}>
              {busy ? "Saving…" : needsCurrent ? "Change password" : "Set password"}
            </Button>
          )}
        >
          {state && (
            <>
              {/* the address, for password managers: they file a new password under it */}
              <input type="email" name="username" autoComplete="username" value={state.email} readOnly hidden />
              {needsCurrent && (
                <SettingsRow label="Current password" htmlFor="current-password">
                  <Input
                    id="current-password"
                    type="password"
                    autoComplete="current-password"
                    required
                    value={current}
                    onChange={(e) => setCurrent(e.target.value)}
                  />
                </SettingsRow>
              )}
              <SettingsRow label="New password" help="At least 12 characters. A sentence works well." wide>
                <PasswordFields
                  key={round}
                  value={password}
                  email={state.email}
                  labels={{ password: "New password", confirm: "Confirm new password" }}
                  onChange={(pw, ok) => {
                    setPassword(pw);
                    setReady(ok);
                  }}
                />
              </SettingsRow>
              {(error || notice) && (
                <div className="px-4 py-3 md:px-5">
                  {error && <p className="text-sm text-destructive">{error}</p>}
                  {notice && !error && <p className="text-sm text-success">{notice}</p>}
                </div>
              )}
            </>
          )}
        </SettingsSection>
      </form>
    </>
  );
}
