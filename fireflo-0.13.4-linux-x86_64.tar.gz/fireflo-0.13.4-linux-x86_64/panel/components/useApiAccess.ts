"use client";
import { useEffect, useState } from "react";
//from the rules module rather than from lib/playground, which pulls `pg` -- a type-only import is
//erased, but the path is the one a later value import would take
import type { PlaygroundLogin, RotatableLogin } from "@/lib/playground-rules";

/**
 * Which logins this customer can send with, and where.
 *
 * <p>Shared by the playground and the reference page — the reference needs the same base URL and
 * login name to fill in its examples, and fetching them twice from two shapes is how the two pages
 * would come to disagree about which login is "yours".
 *
 * <p>Note what is <strong>not</strong> here: the password. It lives in the playground's own state,
 * for the life of that component, and is passed to the proxy on each call. Putting it here would put
 * it one `useApiAccess()` away from every page that imports this.
 */

export interface ApiAccess {
  logins: PlaygroundLogin[];
  /** Wider than `logins` — includes api-key-keyed credentials, which cannot be sent with here. */
  rotatable: RotatableLogin[];
  /** Null when the deployment has not set GATEWAY_API_URL. Both pages say so rather than guess. */
  baseUrl: string | null;
}

export function useApiAccess() {
  const [access, setAccess] = useState<ApiAccess | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let live = true;
    fetch("/api/mis/logins", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => {
        if (live) {
          setAccess((j?.data as ApiAccess) ?? { logins: [], rotatable: [], baseUrl: null });
          setLoading(false);
        }
      })
      .catch(() => {
        if (live) {
          setAccess({ logins: [], rotatable: [], baseUrl: null });
          setLoading(false);
        }
      });
    return () => {
      live = false;
    };
  }, []);

  return { access, loading };
}

/**
 * The placeholder used in every documentation example, and in the playground's request preview.
 *
 * <p>One constant so the reference and the playground show the same thing. A customer who sees
 * `$PASSWORD` in the docs and something else in the playground reasonably wonders which is real.
 */
export const PASSWORD_PLACEHOLDER = "$PASSWORD";
