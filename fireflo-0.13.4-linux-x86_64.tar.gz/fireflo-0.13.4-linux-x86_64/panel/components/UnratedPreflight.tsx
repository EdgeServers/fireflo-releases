"use client";
import { useEffect, useState } from "react";
import { AlertTriangle, ChevronDown, ChevronRight, ShieldCheck } from "lucide-react";
import {
  type UnratedPreflight as Preflight,
  REFUSE_UNRATED_KEY,
  describe,
  preflightAdvice,
  preflightSentence,
} from "@/lib/unrated-preflight";

/** The pre-flight, plus what the flag is currently set to. Null when that could not be read. */
type Payload = Preflight & { refusing: boolean | null };

/**
 * What switching on "refuse messages with no price" would refuse.
 *
 * <p>Sits on the pricing page because that is where the decision is made and where the fix is. The
 * flag itself is a global gateway property (`smsg.rating.unrated.refuse`) and the panel has never
 * had an editor for those — every setting form here writes a *worker's* properties. So this shows
 * the state and the consequence and says exactly what to set, rather than offering a tick box that
 * would have to invent a global-config write path to mean anything.
 *
 * <p><strong>It renders even when the answer is "nothing".</strong> Unlike `ProductReadiness`, which
 * hides itself when clean: this is read by somebody deciding whether to switch something on, and
 * "nothing would be refused" is the answer that makes the decision easy. Hiding it would look
 * identical to the report having failed to load.
 */
export function UnratedPreflight() {
  const [payload, setPayload] = useState<Payload | null>(null);
  const [unavailable, setUnavailable] = useState("");
  const [open, setOpen] = useState(false);

  useEffect(() => {
    let live = true;
    fetch("/api/control/unrated-preflight", { cache: "no-store" })
      .then(async (res) => {
        const json = await res.json().catch(() => null);
        if (!live) {
          return;
        }
        if (!res.ok) {
          setUnavailable(json?.error ?? `Could not be counted (${res.status}).`);
          return;
        }
        setPayload(json.data as Payload);
      })
      .catch(() => live && setUnavailable("The count could not be read."));
    return () => {
      live = false;
    };
  }, []);

  if (unavailable) {
    //said rather than hidden. A silent absence here reads as "there is nothing to refuse", which is
    //the one wrong conclusion to leave somebody with
    return (
      <p className="text-xs text-muted-foreground">
        Unpriced traffic could not be counted. {unavailable}
      </p>
    );
  }
  if (!payload) {
    return null;
  }

  const clean = payload.total === 0;

  return (
    <div
      className={`rounded-md border p-3 ${
        clean ? "border-border" : "border-warning/40 bg-warning-soft/40"
      }`}
    >
      <button
        type="button"
        className="flex w-full items-start gap-2 text-left text-sm"
        aria-expanded={open}
        onClick={() => setOpen(!open)}
      >
        {clean
          ? <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
          : <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning" />}
        <span className="flex-1">
          {preflightSentence(payload)}
          <span className="mt-0.5 block text-xs text-muted-foreground">
            {stateSentence(payload.refusing)}
          </span>
        </span>
        {open
          ? <ChevronDown className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
          : <ChevronRight className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />}
      </button>

      {open && (
        <div className="mt-3 space-y-3 border-t border-border/60 pt-3 text-xs text-muted-foreground">
          <p>{preflightAdvice(payload)}</p>

          {payload.groups.length > 0 && (
            <ul className="space-y-1">
              {payload.groups.map((group) => (
                <li key={`${group.accountId}:${group.product}`}>{describe(group)}</li>
              ))}
            </ul>
          )}

          <p>
            {/* the gauge is the gateway's own count since it started, not a count over the window
                above, so the two are not expected to match and it says so */}
            {payload.gauge == null
              ? "The gateway's own unrated counter could not be read."
              : `The gateway has counted ${payload.gauge.toLocaleString()} unrated messages since it started.`}
          </p>

          <p>
            Set <code className="text-xs">{REFUSE_UNRATED_KEY}=true</code> on the gateway to refuse
            them instead — in its configuration table if it reads configuration from the database, or
            in <code className="text-xs">smsg.properties</code> with a restart. Over SMPP the
            customer gets status <code className="text-xs">0x418</code>, which is vendor-specific
            and will show in their client as an unknown error; over the REST API they get a 403.
            Nothing is charged either way — the price is settled before the balance is touched.
          </p>
        </div>
      )}
    </div>
  );
}

/** What the flag is set to, keeping "unset" and "off" apart. */
function stateSentence(refusing: boolean | null): string {
  if (refusing === true) {
    return "Refusing unpriced messages is switched on, so these are being rejected rather than sent.";
  }
  if (refusing === false) {
    return "Refusing unpriced messages is switched off, so they are sent and charged nothing.";
  }
  //the file-mode case, and the fresh-install case. Reporting it as "off" would be a guess that
  //happens to be right most of the time, which is the worst kind
  return "Whether unpriced messages are refused is not recorded in this database — in file mode it "
    + "lives in smsg.properties, which this panel does not read. Unset means off.";
}
