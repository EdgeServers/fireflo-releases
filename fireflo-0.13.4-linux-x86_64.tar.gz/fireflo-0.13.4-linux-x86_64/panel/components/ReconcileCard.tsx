"use client";
import { useCallback, useState } from "react";
import { Button } from "@/components/ui/button";
import { surface } from "@/lib/panel-surface";
import { money } from "@/lib/format";
import type { Reconciliation } from "@/lib/reconcile";

/**
 * Whether this account's credit adds up, and what explains it when it does not.
 *
 * <p><strong>Loaded on demand, not with the page.</strong> It reads the whole of an account's
 * ledger and its whole rollup history — cheap on a small account, not free on a large one — and it
 * answers a question an operator asks occasionally rather than every time they open a page.
 *
 * <p>There is no action button here on purpose. The two safe remedies live where they already are
 * (release stranded credit on the ops endpoint; re-run a stuck recharge by fixing the balance row),
 * and the residual must never be written away — an adjusting entry hides the cause and makes the
 * next drift start from a number nobody can audit.
 */
export function ReconcileCard({ accountId, currency }: { accountId: string; currency: string }) {
  const [result, setResult] = useState<Reconciliation | null>(null);
  const [notice, setNotice] = useState("");
  const [zone, setZone] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "done" | "failed">("idle");

  const run = useCallback(async () => {
    setState("loading");
    setNotice("");
    try {
      const res = await fetch(
        `${surface().apiBase}/accounts/${encodeURIComponent(accountId)}/reconcile`,
        { cache: "no-store" }
      );
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setNotice(json?.error ?? `Could not reconcile (${res.status}).`);
        setState("failed");
        return;
      }
      setResult(json?.data ?? null);
      setZone(json?.data?.zone ?? "");
      setNotice(json?.notice ?? "");
      setState("done");
    } catch (err) {
      setNotice(err instanceof Error ? err.message : "Could not reconcile.");
      setState("failed");
    }
  }, [accountId]);

  //Cleared when the account changes, so a previous account's verdict can never be read as this one's.
  //
  //Adjusted DURING RENDER rather than in an effect, which is React's documented way to reset state on
  //a prop change. An effect runs after paint, so it would show the PREVIOUS account's verdict for one
  //frame under the new account's heading before clearing it -- briefly the wrong answer about money,
  //on a card whose whole job is saying whether the money adds up.
  const [seenAccountId, setSeenAccountId] = useState(accountId);
  if (seenAccountId !== accountId) {
    //the tracker is updated first: without it this branch is taken again on the re-render it causes
    setSeenAccountId(accountId);
    setResult(null);
    setState("idle");
    setNotice("");
  }

  if (state === "idle") {
    return (
      <div className="space-y-1.5">
        <p className="text-sm text-muted-foreground">
          That every unit credited is still in the balance or reserved against it, and that what
          was reserved covers what was spent.
        </p>
        <Button size="sm" className="h-7" onClick={() => void run()}>Reconcile</Button>
      </div>
    );
  }

  if (state === "loading") {
    return <p className="text-sm text-muted-foreground">Reconciling {accountId}…</p>;
  }

  if (state === "failed" || (!result && notice)) {
    return (
      <div className="space-y-1.5">
        <p className="text-sm text-muted-foreground">{notice}</p>
        <Button size="sm" variant="ghost" className="h-7" onClick={() => void run()}>Try again</Button>
      </div>
    );
  }

  if (!result) {
    return <p className="text-sm text-muted-foreground">Nothing to reconcile.</p>;
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-baseline gap-x-6 gap-y-2">
        <div>
          <p className="text-sm text-muted-foreground">Unexplained</p>
          <p
            className={
              "text-title font-normal tabular-nums "
              + (result.balanced ? "text-muted-foreground" : "text-destructive")
            }
          >
            {money(result.residual, currency)}
          </p>
          <p className="text-xs text-muted-foreground">
            {result.balanced
              ? "Every unit credited is accounted for."
              : "Credit that no entry explains. This is the figure worth acting on."}
          </p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Reserved, not yet spent</p>
          <p className="text-title font-normal tabular-nums">{money(result.heldUnspent, currency)}</p>
          <p className="text-xs text-muted-foreground">
            {result.heldUnspent < 0
              ? "Negative: charged more than was ever reserved."
              : "Normal while an account is sending."}
          </p>
        </div>
      </div>

      {result.attributions.length > 0 && (
        <ul className="space-y-1.5">
          {result.attributions.map((a) => (
            <li key={a.code} className="text-xs text-muted-foreground">
              <span className="font-medium text-foreground">
                {a.amount === null ? "" : `${money(a.amount, currency)} — `}
              </span>
              {a.message}
            </li>
          ))}
        </ul>
      )}

      <p className="text-xs text-muted-foreground">
        Lifetime, cut in {zone || "UTC"}. Nothing here writes anything: a residual is the part
        nobody could explain, and posting an adjustment for it would hide the cause.{" "}
        <button
          type="button"
          className="underline underline-offset-2 hover:text-foreground"
          onClick={() => void run()}
        >
          Re-run
        </button>
      </p>
    </div>
  );
}
