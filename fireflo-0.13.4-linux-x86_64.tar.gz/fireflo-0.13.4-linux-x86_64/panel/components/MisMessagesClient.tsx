"use client";
import { useCallback, useEffect, useState } from "react";
import { pendingSummary } from "@/lib/labels";
import { ChevronLeft, ChevronRight, Columns3, Download } from "lucide-react";
import { Button, buttonClasses } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { TableInCard, THead, TH, TBody, TR, TD } from "@/components/ui/table";
import { CdrCell } from "./CdrCell";
import { ColumnChooser } from "./ColumnChooser";
import { MisFilterBar } from "./MisFilterBar";
import type { CdrCursor, CdrRow } from "@/lib/cdr-request";
import { browserTimeZone } from "@/lib/datetime";
import { HEAVY_CDR_COLUMN_IDS } from "@/lib/cdr-columns";
import { readColumnChoice, toggleColumn, type ColumnChoice } from "@/lib/table-columns";
import {
  MIS_COLUMNS,
  MIS_COLUMN_GROUPS,
  MIS_COLUMN_STORAGE_KEY,
  isLockedMisColumn,
  resolveMisColumns,
} from "@/lib/mis-messages-columns";
import {
  EMPTY_MIS_FILTERS,
  type MisFilterForm,
  fromMisQuery,
  toMisQuery,
} from "@/lib/mis-messages-filters";

const PAGE_SIZE = 50;

/**
 * A customer's own messages.
 *
 * <p>The same column definitions as the operator's `/cdrs` and **not** the same columns: it renders
 * {@link MIS_COLUMNS}, which derives from an allow-list, and the API projects through the same list
 * so cost, margin and vendor are absent from the JSON as well as from the screen. Two independent
 * places, because a UI-only filter is one `JSON.stringify` away from being no filter at all.
 *
 * <p>A reseller sees its own traffic and its accounts' together and can narrow to one. The narrowing
 * is a convenience — the server has already bounded the query to the session's scope, so choosing
 * "all" here cannot widen it.
 *
 * <p>Filters live in the query string so a view can be bookmarked or sent to support; columns live
 * in `localStorage`, because a shared link should carry what was being looked at and not impose the
 * sharer's column choice on whoever opens it.
 */
export function MisMessagesClient() {
  const [filters, setFilters] = useState<MisFilterForm>(EMPTY_MIS_FILTERS);
  const [rows, setRows] = useState<CdrRow[]>([]);
  const [scope, setScope] = useState<string[]>([]);
  const [nextCursor, setNextCursor] = useState<CdrCursor | null>(null);
  //one entry per page already visited; the last is the page currently shown. Keyset paging makes
  //Previous something to remember rather than compute -- reversing the sort returns the right rows
  //in the wrong order, and skips one every time the table is written to, which for a live gateway
  //is always
  const [history, setHistory] = useState<(CdrCursor | null)[]>([null]);
  const [choice, setChoice] = useState<ColumnChoice | null>(null);
  const [chooserOpen, setChooserOpen] = useState(false);
  const [zone, setZone] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  //read after mount, never in a lazy initialiser: neither localStorage nor the browser's timezone
  //exists while this renders on the server, and React 19 throws on the resulting mismatch rather
  //than patching it up
  useEffect(() => {
    setChoice(readColumnChoice(window.localStorage.getItem(MIS_COLUMN_STORAGE_KEY)));
    setZone(browserTimeZone());
  }, []);

  const columns = resolveMisColumns(choice);
  const columnIds = columns.map((c) => c.id).join(",");
  const currentColumnIds = () => resolveMisColumns(
    readColumnChoice(window.localStorage.getItem(MIS_COLUMN_STORAGE_KEY))
  ).map((c) => c.id).join(",");

  function choose(id: string, enabled: boolean) {
    const next = toggleColumn(choice, id, enabled);
    setChoice(next);
    window.localStorage.setItem(MIS_COLUMN_STORAGE_KEY, JSON.stringify(next));

    //switching on a column whose data is fetched on demand needs the data. Every other column is
    //already in hand, so only this case costs a round trip -- and showing an empty column while the
    //value exists in the database would read as "this message carried none"
    const ids = resolveMisColumns(next).map((c) => c.id);
    if (enabled && HEAVY_CDR_COLUMN_IDS.includes(id)) {
      void load(filters, history[history.length - 1], ids.join(","));
    }
  }

  function resetColumns() {
    setChoice(null);
    window.localStorage.removeItem(MIS_COLUMN_STORAGE_KEY);
  }

  //`columnIds` is a parameter and not a closed-over value: `load` is memoised with no deps, so
  //reading the chosen columns from the enclosing scope would send whatever they were on first
  //render -- and the symptom would be a TLV column that stays empty until a reload
  const load = useCallback(async (form: MisFilterForm, cursor: CdrCursor | null, columnIds: string) => {
    setLoading(true);
    setError("");
    try {
      const params = toMisQuery(form);
      params.set("limit", String(PAGE_SIZE));
      //the chosen columns, so the route can skip the unbounded TLV field on a page not showing it.
      //It is a hint about cost, never about access: the route intersects it with the customer
      //allow-list exactly as the export does
      params.set("columns", columnIds);
      if (cursor) {
        //cursorAt and cursorId, which is what this route reads. The operator client sends cursorTs
        //to a different route; copying that line would produce a Next button that silently returns
        //page one forever
        params.set("cursorAt", cursor.submittedAt);
        params.set("cursorId", cursor.id);
      }
      const res = await fetch(`/api/mis/messages?${params}`, { cache: "no-store" });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        setRows([]);
        setNextCursor(null);
        return;
      }
      setRows(json.data.rows ?? []);
      setScope(json.data.scope ?? []);
      setNextCursor(json.data.nextCursor ?? null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
      setRows([]);
      setNextCursor(null);
    } finally {
      setLoading(false);
    }
  }, []);

  //the first load honours the query string, so a bookmarked or shared window opens on itself.
  //`ready` gates the filter bar: it takes its draft from a mount-time value, so mounting it before
  //the URL has been read would show 24 hours to somebody who asked for a custom window
  useEffect(() => {
    const initial = fromMisQuery(new URLSearchParams(window.location.search));
    setFilters(initial);
    setReady(true);
    //read from localStorage rather than from `columns`: the effect above has already applied the
    //stored choice, but this callback closes over the render that queued it, where it was still the
    //default set
    void load(initial, null, currentColumnIds());
  }, [load]);

  function apply(next: MisFilterForm) {
    //a filter change resets paging: keeping the cursor asks for "the page after this timestamp"
    //under a different filter, which lands somewhere arbitrary in the new result set
    setFilters(next);
    setHistory([null]);
    void load(next, null, columnIds);

    //replaceState rather than push, so Back leaves the page instead of walking a filter history
    //nobody asked to keep
    const query = toMisQuery(next).toString();
    window.history.replaceState(null, "", query ? `?${query}` : window.location.pathname);
  }

  function forward() {
    if (!nextCursor) {
      return;
    }
    setHistory((h) => [...h, nextCursor]);
    void load(filters, nextCursor, columnIds);
  }

  function back() {
    if (history.length < 2) {
      return;
    }
    const trimmed = history.slice(0, -1);
    setHistory(trimmed);
    void load(filters, trimmed[trimmed.length - 1], columnIds);
  }

  //the same filters the table is showing, plus the columns on screen. Built as a URL rather than a
  //blob so the file never enters browser memory and the browser owns the download
  const exportParams = toMisQuery(filters);
  exportParams.set("columns", columns.map((c) => c.id).join(","));
  const exportHref = `/api/mis/messages/export?${exportParams}`;

  const page = history.length;
  const pending = pendingSummary(rows);

  return (
    <>
      <PageHeader title="Messages" description="Every message you sent, and what happened to it." />

      {ready && <MisFilterBar initial={filters} scope={scope} onApply={apply} busy={loading} />}

      <Card>
        <CardHeader bar className="flex flex-row flex-wrap items-center gap-2 space-y-0">
          <CardTitle>Messages</CardTitle>
          <div className="ml-auto flex min-w-0 flex-wrap items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5"
              onClick={() => setChooserOpen((v) => !v)}
              aria-expanded={chooserOpen}
            >
              <Columns3 className="h-4 w-4" />
              Columns
            </Button>
            {/* an anchor, not a fetch: a month of traffic is a file, and the browser is better at
                receiving one than this component is. buttonClasses exists for exactly this */}
            <a href={exportHref} download className={buttonClasses({ variant: "outline", size: "sm", className: "gap-1.5" })}>
              <Download className="h-4 w-4" />
              Download CSV
            </a>
          </div>
        </CardHeader>

        {chooserOpen && (
          <div className="border-b border-border">
            <ColumnChooser
              columns={MIS_COLUMNS}
              groups={MIS_COLUMN_GROUPS}
              enabled={new Set(columns.map((c) => c.id))}
              locked={isLockedMisColumn}
              onToggle={choose}
              onReset={resetColumns}
              note="The CSV carries whatever is ticked here."
            />
          </div>
        )}

        <CardContent>
          {error ? (
            <p className="py-6 text-sm text-destructive">{error}</p>
          ) : !rows.length ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              {loading ? "Loading…" : "No messages in this period."}
            </p>
          ) : (
            <>
              {/* said plainly rather than left to be inferred from a column of dashes: most traffic
                  has no receipt yet at any moment, and a table that looks half-empty reads as broken */}
              {pending && <p className="pb-3 pt-1 text-sm text-muted-foreground">{pending}</p>}
              <TableInCard>
                <THead>
                  <tr>
                    {columns.map((c) => (
                      <TH key={c.id} align={c.align === "right" ? "right" : undefined}>
                        {c.header}
                      </TH>
                    ))}
                  </tr>
                </THead>
                <TBody>
                  {/* keyed on what identifies an attempt, not on row.id -- the internal BIGINT is
                      deliberately not sent to a customer, so keying on it gave every row the same
                      undefined key */}
                  {rows.map((row) => (
                    <TR key={`${row.gatewayMsgId}-${row.partNo}-${row.retryCount}`}>
                      {columns.map((c) => (
                        <TD
                          key={c.id}
                          align={c.align === "right" ? "right" : undefined}
                          className="whitespace-nowrap align-top"
                        >
                          <CdrCell column={c} row={row} />
                        </TD>
                      ))}
                    </TR>
                  ))}
                </TBody>
              </TableInCard>
            </>
          )}
        </CardContent>

        <CardFooter bar>
          <span className="text-xs text-muted-foreground" suppressHydrationWarning>
            {rows.length ? `${rows.length} message${rows.length === 1 ? "" : "s"} · page ${page}` : ""}
            {/* named once here rather than appended to every row: without it a customer in another
                country cannot tell whose clock these times are on */}
            {zone ? ` · times shown in ${zone}` : ""}
          </span>
          <span className="ml-auto flex gap-2">
            <Button variant="outline" size="sm" onClick={back} disabled={page < 2 || loading} className="gap-1">
              <ChevronLeft className="h-4 w-4" />
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={forward}
              disabled={!nextCursor || loading}
              className="gap-1"
            >
              Next
              <ChevronRight className="h-4 w-4" />
            </Button>
          </span>
        </CardFooter>
      </Card>
    </>
  );
}
