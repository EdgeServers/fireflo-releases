"use client";
import { useId, useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { HealthStrip } from "./CardBits";
import { useAccounts } from "./useAccounts";

/**
 * Gives a login, sender ID or template to another account.
 *
 * <p>The account is typed or picked from the catalogue's non-archived accounts. The server decides
 * (`lib/account-archive.ts`): an archived account on either side, a login that still has sender IDs
 * or templates scoped to it, or a row scoped to a login the target does not own is refused with the
 * sentence that says what to do, shown here as it came.
 */
export function MoveToAccountDialog({
  what,
  name,
  from,
  note,
  endpoint,
  onClose,
  onMoved,
}: {
  /** "login", "sender ID", "template". */
  what: string;
  /** The thing's own name, as the dialog's title shows it. */
  name: string;
  /** The account it belongs to now. */
  from: string | null;
  /** One sentence on what else happens, e.g. that a login's binds are dropped. */
  note?: string;
  /** The move route, e.g. `/api/control/credentials/12/move`. */
  endpoint: string;
  onClose: () => void;
  onMoved: (result: { to: string; dropped: number; problem?: string }) => void;
}) {
  const { accounts } = useAccounts();
  const [to, setTo] = useState("");
  const [error, setError] = useState("");
  const [moving, setMoving] = useState(false);
  const listId = useId();
  const target = to.trim();

  async function move() {
    setMoving(true);
    setError("");
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ to: target }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      onMoved({ to: target, dropped: json?.data?.dropped ?? 0, problem: json?.data?.problem });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setMoving(false);
    }
  }

  return (
    <Dialog open onClose={onClose} title={`Move ${what} ${name}`} className="max-w-lg">
      <form
        className="space-y-4 text-sm"
        onSubmit={(e) => {
          e.preventDefault();
          if (target && target !== from) {
            void move();
          }
        }}
      >
        <p className="text-muted-foreground">
          It belongs to <span className="font-mono text-foreground">{from ?? "—"}</span> now. From the move on it
          belongs to, and bills, the account you choose. What it already did stays in{" "}
          <span className="font-mono">{from ?? "the old account"}</span>&apos;s history.
          {note ? ` ${note}` : ""}
        </p>
        <Field label="Move to account" htmlFor={`${listId}-to`}>
          <Input
            id={`${listId}-to`}
            list={listId}
            value={to}
            onChange={(e) => setTo(e.target.value)}
            placeholder="acct-1002"
            autoComplete="off"
            className="font-mono"
          />
          <datalist id={listId}>
            {accounts.filter((a) => a.id !== from).map((a) => (
              <option key={a.id} value={a.id}>{a.label ?? ""}</option>
            ))}
          </datalist>
        </Field>
        {error && <HealthStrip tone="destructive">{error}</HealthStrip>}
        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onClose} disabled={moving}>Cancel</Button>
          <Button type="submit" disabled={moving || !target || target === from}>
            {moving ? "Moving…" : `Move ${what}`}
          </Button>
        </div>
      </form>
    </Dialog>
  );
}
