"use client";

import { forwardRef, useCallback, useEffect, useImperativeHandle, useMemo, useRef, useState } from "react";
import { Download, Loader2, Maximize2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClasses } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { RailBox, RailText } from "@/components/security/RailBox";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { useHealth } from "@/components/useHealth";
import { useWorkers } from "@/components/useWorkers";
import { KIND } from "@/lib/worker-types";
import { listenerPorts } from "@/lib/listener-ports";
import {
  WATCH_DURATIONS,
  isIpLiteral,
  watchLine,
  type WatchEvent,
  type WatchReport,
} from "@/lib/client-watch";

/** About once a second: the point is to see a bind attempt as it happens, not a minute later. */
const POLL_MS = 1_000;
/** What the page holds. The gateway keeps 5 000; a browser tab does not need more than this. */
const KEEP_LINES = 2_000;
/** So a reload picks the running watch back up rather than starting a second one. */
const STORAGE_KEY = "fireflo.security.watch";

/**
 * A live watch of one client address on one SMPP listener: every PDU it sends and is sent, and the
 * binds that are refused and never become a session -- which nothing else on this page can show.
 *
 * <p>Polled rather than streamed, like every live view in this panel; the gateway hands back only
 * what is new since the last `next`.
 */
/** What the page can ask of the watch: open it, set to one address unless a watch is running. */
export interface ClientWatchHandle {
  openFor: (ip: string) => void;
}

export const ClientWatchCard = forwardRef<ClientWatchHandle>(function ClientWatchCard(_props, ref) {
  const { workers, loading: workersLoading } = useWorkers(KIND.server);
  const { byFullName, health } = useHealth();
  //the listeners the gateway is running now: a port on a stopped or disabled one has nobody to watch
  const ports = useMemo(() => listenerPorts(workers, byFullName), [workers, byFullName]);
  const portsKnown = !workersLoading && health != null;

  const [ip, setIp] = useState("");
  const [port, setPort] = useState("");
  const [seconds, setSeconds] = useState<number>(WATCH_DURATIONS[0]);
  const [watch, setWatch] = useState<Omit<WatchReport, "events"> | null>(null);
  const [events, setEvents] = useState<WatchEvent[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  //the watch shown in a wide window rather than the card, for reading a busy log
  const [inModal, setInModal] = useState(false);

  useEffect(() => {
    if (!port && ports.length > 0) {
      setPort(String(ports[0].port));
    }
  }, [port, ports]);

  const nextRef = useRef(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const followRef = useRef(true);

  const running = watch?.running ?? false;

  //"Watch" on an address row: the window opens set to that address. A running watch is left alone --
  //it is about another address, and replacing what it shows would lose it
  useImperativeHandle(ref, () => ({
    openFor: (address: string) => {
      if (!running) {
        setIp(address);
      }
      setInModal(true);
    },
  }), [running]);

  const take = useCallback((report: WatchReport) => {
    const { events: fresh, ...rest } = report;
    setWatch(rest);
    nextRef.current = report.next;
    if (fresh.length) {
      setEvents((prev) => {
        const all = prev.concat(fresh);
        return all.length > KEEP_LINES ? all.slice(all.length - KEEP_LINES) : all;
      });
    }
  }, []);

  //a reload during a watch resumes it, from the start of what the gateway still holds
  useEffect(() => {
    let saved: { id: string; ip: string; port: string } | null = null;
    try {
      saved = JSON.parse(sessionStorage.getItem(STORAGE_KEY) ?? "null");
    } catch {
      saved = null;
    }
    if (!saved?.id) {
      return;
    }
    setIp(saved.ip);
    setPort(saved.port);
    void (async () => {
      const res = await fetch(`/api/control/security/watch/${saved.id}`, { cache: "no-store" }).catch(() => null);
      const json = await res?.json().catch(() => null);
      if (res?.ok && json?.data) {
        take(json.data as WatchReport);
      } else {
        forget();
      }
    })();
  }, [take]);

  //the poll: one request in flight at most, again at once while the gateway says there is more, and
  //nothing while the tab is hidden
  useEffect(() => {
    if (!watch?.id || !running) {
      return;
    }
    let stopped = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const tick = async () => {
      if (stopped) {
        return;
      }
      if (document.visibilityState === "hidden") {
        timer = setTimeout(tick, POLL_MS);
        return;
      }
      let more = false;
      try {
        const res = await fetch(`/api/control/security/watch/${watch.id}?after=${nextRef.current}`, { cache: "no-store" });
        const json = await res.json().catch(() => null);
        if (res.ok && json?.data) {
          const report = json.data as WatchReport;
          if (!stopped) {
            take(report);
          }
          more = report.more;
          if (!report.running) {
            forget();
            return;
          }
        } else if (res.status === 404) {
          setError(json?.error ?? "The watch has ended.");
          setWatch((w) => (w ? { ...w, running: false } : w));
          forget();
          return;
        }
      } catch {
        //a failed poll is not worth a message: the next one is a second away
      }
      if (!stopped) {
        timer = setTimeout(tick, more ? 0 : POLL_MS);
      }
    };
    timer = setTimeout(tick, 0);
    return () => {
      stopped = true;
      clearTimeout(timer);
    };
  }, [watch?.id, running, take]);

  //follow the newest line, unless the reader has scrolled up to read an older one
  useEffect(() => {
    const el = scrollRef.current;
    if (el && followRef.current) {
      el.scrollTop = el.scrollHeight;
    }
    //inModal too: moving between the card and the window mounts a new log, which starts at the top
  }, [events, inModal]);

  async function start() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/control/security/watch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ip: ip.trim(), port: Number(port), seconds }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? "The gateway did not start the watch.");
        return;
      }
      const report = json.data as WatchReport;
      setEvents([]);
      nextRef.current = 0;
      followRef.current = true;
      take(report);
      try {
        sessionStorage.setItem(STORAGE_KEY, JSON.stringify({ id: report.id, ip: ip.trim(), port }));
      } catch {
        //storage blocked: a reload simply will not resume
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not reach the panel.");
    } finally {
      setBusy(false);
    }
  }

  async function stop() {
    if (!watch) {
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/control/security/watch/${watch.id}`, { method: "DELETE" });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? "The gateway did not confirm.");
        return;
      }
      setWatch((w) => (w ? { ...w, running: false, stopped_because: "stopped by an operator" } : w));
      //one last read for the lines that arrived since the previous poll, ending with "Watch ended"
      const last = await fetch(`/api/control/security/watch/${watch.id}?after=${nextRef.current}`, { cache: "no-store" });
      const lastJson = await last.json().catch(() => null);
      if (last.ok && lastJson?.data) {
        take(lastJson.data as WatchReport);
      }
      forget();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not reach the panel.");
    } finally {
      setBusy(false);
    }
  }

  const ipOk = isIpLiteral(ip);
  const portNumber = Number(port);
  const portOk = Number.isInteger(portNumber) && portNumber >= 1 && portNumber <= 65535;

  //the form and the log, which live in the window. One copy of the state, in this component, so
  //closing the window does not stop a watch and reopening it carries on where it was
  const body = () => (
    <div className="space-y-3">
      <p className="text-xs text-muted-foreground">
        Every PDU one address sends to a listener and is sent back, including binds that are refused.
        Shows decoded traffic: message content, numbers, and the password on any bind.
      </p>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Client IP" htmlFor="watch-ip">
          <Input
            id="watch-ip"
            value={ip}
            onChange={(e) => setIp(e.target.value)}
            placeholder="203.0.113.7"
            disabled={running}
            spellCheck={false}
            autoComplete="off"
            aria-invalid={ip !== "" && !ipOk}
          />
        </Field>
        <Field
          label="Server"
          htmlFor="watch-port"
          hint={portsKnown && ports.length === 0 ? "No SMPP listener is running on the gateway now." : undefined}
        >
          <Select
            id="watch-port"
            value={port}
            onChange={(e) => setPort(e.target.value)}
            disabled={running || ports.length === 0}
          >
            {ports.length === 0 && <option value="">{portsKnown ? "No active servers" : "Reading servers…"}</option>}
            {ports.map((p) => (
              <option key={p.port} value={p.port}>{p.label} · port {p.port}</option>
            ))}
            {/* a watch resumed after a reload, on a listener that has since stopped */}
            {port && !ports.some((p) => String(p.port) === port) && <option value={port}>port {port}</option>}
          </Select>
        </Field>
      </div>
      {!running && (
        <Field label="Watch for" htmlFor="watch-for">
          <Select id="watch-for" value={seconds} onChange={(e) => setSeconds(Number(e.target.value))}>
            {WATCH_DURATIONS.map((d) => (
              <option key={d} value={d}>{d / 60} minutes, or until you stop it</option>
            ))}
          </Select>
        </Field>
      )}

      {error && <p className="text-xs text-destructive">{error}</p>}

      {watch && (
        <p className="text-xs text-muted-foreground">
          {watch.ip} on port {watch.port} ({watch.worker})
          {running
            ? ` · until ${new Date(watch.ends_at).toLocaleTimeString()}`
            : watch.stopped_because
              ? ` · ${watch.stopped_because}`
              : ""}
          {/* > 0 only: "0 dropped" on every watch would train people to skip the one number that
              says lines are missing */}
          {watch.dropped > 0 && <span className="text-destructive"> · {watch.dropped.toLocaleString()} dropped</span>}
        </p>
      )}

      {/* opens on Start: before a watch there is nothing to show, and an empty box this tall only
          pushed the form's own controls apart */}
      {watch && (
      <div
        ref={scrollRef}
        onScroll={(e) => {
          const el = e.currentTarget;
          followRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 24;
        }}
        className="h-[calc(100dvh-33.25rem)] min-h-40 overflow-auto sm:h-[calc(100dvh-27.25rem)] rounded bg-muted p-2 font-mono text-sm"
        role="log"
        aria-live="polite"
      >
        {events.length === 0 ? (
          <p className="text-muted-foreground">{running ? "Waiting for traffic…" : "Nothing was seen."}</p>
        ) : (
          events.map((e) => (
            <div
              key={e.seq}
              className={
                e.kind === "note"
                  ? /refused/i.test(e.text) ? "text-destructive" : "text-warning"
                  : "whitespace-pre-wrap break-all"
              }
            >
              {watchLine(e)}
            </div>
          ))
        )}
      </div>
      )}
    </div>
  );

  const buttons = (
    <>
      {running ? (
        <Button size="sm" variant="outline" disabled={busy} onClick={() => void stop()}>
          {busy && <Loader2 className="size-3.5 animate-spin" aria-hidden />}
          Stop
        </Button>
      ) : (
        <Button size="sm" disabled={busy || !ipOk || !portOk} onClick={() => void start()}>
          {busy && <Loader2 className="size-3.5 animate-spin" aria-hidden />}
          Start
        </Button>
      )}
      {/* a plain link: the browser owns the save, and the file never passes through JavaScript */}
      {watch && (
        <a
          className={buttonClasses({ variant: "outline", size: "sm" })}
          href={`/api/control/security/watch/${watch.id}/pcap`}
          download
        >
          <Download className="size-3.5" aria-hidden />
          Download pcap
        </a>
      )}
      {watch && !running && (
        <Button size="sm" variant="ghost" onClick={() => { setEvents([]); setWatch(null); }}>Clear</Button>
      )}
    </>
  );

  //the rail's shape (see RailBox): a titled bar with the state at its right, then the words and
  //the one button. The watch itself lives in the window
  return (
    <RailBox
      title="Live SMPP watch"
      aside={
        running ? <Badge variant="success">watching</Badge>
          : watch ? <Badge variant="outline">ended</Badge>
            : <Badge variant="outline">idle</Badge>
      }
    >
      <RailText>
        <p>
          Every PDU one client address sends to a listener and is sent back, live, including binds that
          are refused, with a pcap to download for Wireshark. Start from Watch on any row.
        </p>
        {watch && (
          <p className="text-foreground">
            {watch.ip} on port {watch.port}
            <span className="text-muted-foreground">
              {running ? ` · until ${new Date(watch.ends_at).toLocaleTimeString()}` : " · ended"}
              {` · ${events.length.toLocaleString()} line${events.length === 1 ? "" : "s"}`}
            </span>
          </p>
        )}
        <div className="pt-1">
          <Button size="sm" variant="outline" onClick={() => setInModal(true)}>
            <Maximize2 className="size-3.5" aria-hidden />
            {running ? "Open watch" : watch ? "Open last watch" : "Start a watch"}
          </Button>
        </div>
      </RailText>
      <Dialog
        open={inModal}
        onClose={() => setInModal(false)}
        title="Live SMPP watch"
        className="max-w-5xl"
      >
        {/* the log takes what the window has left (see its height), so the dialog never runs past the
            bottom of the screen; long PDU lines wrap rather than widen it */}
        {inModal && (
          <div className="min-w-0 space-y-3">
            {body()}
            <div className="flex flex-wrap items-center gap-2 border-t border-border pt-3">{buttons}</div>
          </div>
        )}
      </Dialog>
    </RailBox>
  );
});

function forget() {
  try {
    sessionStorage.removeItem(STORAGE_KEY);
  } catch {
    //nothing to undo
  }
}
