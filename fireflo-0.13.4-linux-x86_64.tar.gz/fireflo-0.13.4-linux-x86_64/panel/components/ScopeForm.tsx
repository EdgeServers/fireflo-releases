"use client";
import { useId, useState } from "react";
import { ChevronDown, ChevronUp, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ErrorNote, WarningNote } from "@/components/FormNotices";
import { RateRuleFields } from "./RateRuleFields";
import { useFilters } from "./useFilters";
import type { Filter } from "@/lib/filter-types";
import {
  DEFAULT_SCOPE,
  type KnownScopes,
  type RateRuleInput,
  type ScopeInput,
  regexInLiteralOperator,
  scopeKind,
  scopeWarnings,
  validateScope,
} from "@/lib/rate-types";

const BLANK: RateRuleInput = {
  id: null,
  amount: "",
  product: null,
  currency: null,
  label: null,
  enabled: true,
  conditions: [],
  filters: [],
};

/**
 * Editing one scope's rules, in the order the gateway will try them.
 *
 * <p>Order is the whole semantics here — first match wins — so the list is explicitly ordered with
 * move buttons rather than sorted by anything. No drag library: this codebase has none, and adding
 * one for a list that is rarely longer than five entries would be a dependency in exchange for
 * nothing.
 *
 * <p>Errors block the save; warnings appear as you type and never do. That split matters: the
 * warnings here are the ones that would otherwise cost money silently — an unanchored regex, a
 * bucket with no catch-all — and burying them behind a rejected save would mean nobody saw them
 * until something was already wrong.
 */
export function ScopeForm({
  scope,
  initial,
  known,
  catalogue,
  isNew,
  locked = false,
  product,
  onSave,
  onCancel,
  onDirty,
}: {
  scope: string;
  initial: RateRuleInput[];
  known: KnownScopes;
  /** Product names from the catalogue, offered in the dropdown alongside any already in use. */
  catalogue: string[];
  isNew: boolean;
  /**
   * Every rule here prices this one product, and the endpoint receiving them writes it that way.
   *
   * <p>Set by the product page, which addresses its save to `/products/<name>/pricing` — the product
   * is part of the address, so each rule states it rather than offering a dropdown that would be
   * overridden. Left unset by the whole-scope editors, where a scope prices several products at once
   * and choosing between them is the point.
   */
  product?: string;
  /**
   * The scope is fixed by the page around this form — a vendor's own cost, an account's own price.
   *
   * <p>Hides the scope box rather than disabling it. A disabled input still says "this is a field",
   * and the one thing that must not be possible here is retargeting: typing another account's id
   * into a form opened from this one would rewrite that account's whole tariff, wholesale, from a
   * page that never mentioned it.
   *
   * <p>Also stands in for the unknown-scope confirmation, which exists to catch a typo in free text.
   * There is no free text — the page asserts the identity, and a vendor page's scope is a configured
   * vendor by construction. The vendor-versus-account collision check still runs, because a name
   * that is both is worth refusing wherever it was typed.
   */
  locked?: boolean;
  onSave: (scope: string, rules: RateRuleInput[], confirmed: boolean) => Promise<string | null>;
  onCancel: () => void;
  /**
   * Called whenever a rule is edited, added, removed or moved.
   *
   * <p>So a parent showing "Saved at 14:32" can withdraw it the moment the form stops matching what
   * was saved. Without it the confirmation outlives its truth.
   */
  onDirty?: () => void;
}) {
  const [name, setName] = useState(scope);
  const scopeListId = useId();
  const [rules, setRules] = useState<RateRuleInput[]>(initial);
  const [confirmed, setConfirmed] = useState(false);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  //loaded here rather than threaded through the three callers. The picker needs the conditions as
  //well as the names, so it can spell out what a rule actually tests
  const { filters: library } = useFilters();

  const input: ScopeInput = { scope: name, scopeConfirmed: confirmed || locked, isNew, rules };
  const kind = scopeKind(name, known);
  //scopeWarnings sees a rule's own conditions; this adds the ones it inherits from a filter. The
  //split is not cosmetic -- the mistake this catches is made on the filter page and its consequence
  //is felt here, so warning only where it was typed means nobody sees it while looking at the price
  const warnings = [...scopeWarnings(input, known), ...filterConditionWarnings(rules, library)];

  //every mutation goes through here so that "the form no longer matches what was saved" has exactly
  //one place to be noticed
  const change = (next: RateRuleInput[]) => {
    setRules(next);
    onDirty?.();
  };

  const set = (i: number, patch: Partial<RateRuleInput>) =>
    change(rules.map((r, n) => (n === i ? { ...r, ...patch } : r)));

  function move(i: number, by: number) {
    const to = i + by;
    if (to < 0 || to >= rules.length) {
      return;
    }
    const next = [...rules];
    [next[i], next[to]] = [next[to], next[i]];
    change(next);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const invalid = validateScope(input, known);
    if (invalid) {
      setError(invalid);
      return;
    }
    setSaving(true);
    setError("");
    const failure = await onSave(name, rules, confirmed || locked);
    setSaving(false);
    if (failure) {
      setError(failure);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <Card>
        <CardHeader bar>
          <CardTitle>
            {locked ? "Rules" : isNew ? "New pricing" : `Pricing for ${scope}`}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {!locked && (
            <div>
              <Label htmlFor="scope" className="mb-1.5 block">Scope</Label>
              <Input
                id="scope"
                value={name}
                onChange={(e) => setName(e.target.value)}
                //renaming a scope is really "move every rule somewhere else", which this whole-scope
                //rewrite would do by deleting and recreating -- and that discards the rule ids every
                //past call record points at
                disabled={!isNew}
                list={scopeListId}
                placeholder="a vendor name, or an account id"
              />
              {/* every scope that means something, offered rather than remembered. This box has
                  always been free text over one column with two opposite meanings, and it enumerated
                  vendors ONLY -- so the buy side was discoverable and the sell side, which is every
                  customer on the platform, was something you had to already know how to spell */}
              <datalist id={scopeListId}>
                <option value={DEFAULT_SCOPE}>every account with no pricing of its own</option>
                {known.accounts.map((a) => (
                  <option key={`a-${a}`} value={a}>account — what they pay us</option>
                ))}
                {known.vendors.map((v) => (
                  <option key={`v-${v}`} value={v}>vendor — what they charge us</option>
                ))}
              </datalist>
              <ScopeMeaning kind={kind} name={name} known={known} isNew={isNew} />
            </div>
          )}

          {!locked && kind === "unknown" && name.trim() && (
            <label className="flex items-start gap-2 rounded-lg border border-warning/40 p-3 text-sm">
              <input
                type="checkbox"
                checked={confirmed}
                onChange={(e) => setConfirmed(e.target.checked)}
                className="mt-0.5 h-4 w-4 rounded border-input accent-primary"
              />
              <span>
                Use &lsquo;{name}&rsquo; anyway
                <span className="block text-xs text-muted-foreground">
                  It matches no configured vendor and no account that has sent. Tick this if it is an
                  account you are about to onboard — otherwise it is a typo, and these rules will load
                  and match nothing at all.
                </span>
              </span>
            </label>
          )}

          {/* one hairline row per rule, not a Card each: they are rows of one list, and a Card here
              would be a Card inside a Card -- see the vocabulary note in ui/card.tsx */}
          {rules.map((rule, i) => (
            <div
              key={rule.id ?? `new-${i}`}
              className="border-t border-border pt-4 first:border-t-0"
            >
              <RateRuleFields
                rule={rule}
                rules={rules}
                catalogue={catalogue}
                library={library}
                index={i + 1}
                fixedProduct={product}
                onChange={(patch) => set(i, patch)}
                actions={
                  <div className="flex gap-1 pb-1">
                    <Button type="button" variant="ghost" size="icon" className="h-8 w-8"
                      aria-label="Move up" disabled={i === 0} onClick={() => move(i, -1)}>
                      <ChevronUp className="h-4 w-4" />
                    </Button>
                    <Button type="button" variant="ghost" size="icon" className="h-8 w-8"
                      aria-label="Move down" disabled={i === rules.length - 1} onClick={() => move(i, 1)}>
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                    <Button type="button" variant="ghost" size="icon" className="h-8 w-8"
                      aria-label="Remove this rule"
                      onClick={() => change(rules.filter((_, n) => n !== i))}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                }
              />
            </div>
          ))}

          <WarningNote warnings={warnings} />
          <ErrorNote error={error} />

          {/* the honest limit, and the one the worker form does not have to state: this panel checks
              what it can, but the authority on whether a rule is buildable is a Java constructor */}
          <p className="text-xs text-muted-foreground">
            Saved rules reach the gateway on its next configuration poll — within thirty seconds by
            default. If one turns out to be something the gateway cannot build, that poll fails and
            it keeps the prices it already had; it says so in its own log, and nothing here can show
            it.
          </p>
        </CardContent>

        <CardFooter bar className="gap-3">
          <Button type="submit" disabled={saving || !name.trim()}>
            {saving ? "Saving…" : isNew ? "Create pricing" : "Save changes"}
          </Button>
          <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
          <Button
            type="button"
            variant="outline"
            className="ml-auto gap-2"
            //a new row prices whatever this form prices. Leaving it null on a product-scoped form
            //would show "promo" beside a rule the save is about to file under it anyway
            onClick={() => change([...rules, { ...BLANK, product: product ?? null }])}
          >
            <Plus className="h-4 w-4" />
            Add a rule
          </Button>
        </CardFooter>
      </Card>
    </form>
  );
}

/** Says which of the two things this scope is, because the column cannot. */
function ScopeMeaning({
  kind,
  name,
  known,
  isNew,
}: {
  kind: ReturnType<typeof scopeKind>;
  name: string;
  known: KnownScopes;
  isNew: boolean;
}) {
  if (!name.trim()) {
    return null;
  }
  if (kind === "cost") {
    return (
      <p className="mt-1 text-xs text-muted-foreground">
        A vendor. These amounts are what <strong>{name} charges us</strong> per message.
      </p>
    );
  }
  if (kind === "price") {
    return (
      <p className="mt-1 text-xs text-muted-foreground">
        An account. These amounts are what <strong>{name} pays us</strong> per message.
      </p>
    );
  }
  if (kind === "default") {
    return (
      <p className="mt-1 text-xs text-muted-foreground">
        The default. These amounts are what <strong>every account pays</strong> unless its own
        pricing says otherwise — and an account&rsquo;s own rule always wins, including a catch-all.
        Vendor costs are never taken from here.
      </p>
    );
  }
  //both halves, because this box is one column with two opposite meanings. Naming vendors alone
  //made the buy side look like the only thing a scope could be -- and the sell side, which is every
  //customer on the platform, something you had to already know how to spell
  return (
    <p className="mt-1 text-xs text-destructive">
      Not a configured vendor and not an account that has sent.
      {isNew && known.vendors.length > 0 && ` Vendors: ${known.vendors.join(", ")}.`}
      {isNew && known.accounts.length > 0 && ` Accounts: ${namesFew(known.accounts)}.`}
      {isNew && ` Or ${DEFAULT_SCOPE} for every account with no pricing of its own.`}
    </p>
  );
}

/**
 * A few names rather than all of them.
 *
 * <p>Vendors number in the tens and are listed entire. Accounts are the customer base — on the
 * deployment this was written for, a thousand of them — and pasting the whole list into a warning
 * turns the sentence explaining the mistake into something nobody reads.
 */
function namesFew(names: string[], limit = 8): string {
  return names.length <= limit
    ? names.join(", ")
    : `${names.slice(0, limit).join(", ")} and ${names.length - limit} more`;
}

/**
 * Bad conditions a rule inherits from the filters it references.
 *
 * <p>Deduplicated by message: one filter used by six rules is one mistake, and repeating it six
 * times under the same heading buries the other warnings. The filter is named because it is not on
 * this page — the fix is a click away, on `/filters`, and the operator has to know which one.
 */
function filterConditionWarnings(rules: RateRuleInput[], library: Filter[]): string[] {
  const known = new Map(library.map((f) => [f.name, f]));
  const seen = new Map<string, string>();
  for (const rule of rules) {
    for (const name of rule.filters) {
      const filter = known.get(name);
      if (!filter) {
        continue;
      }
      for (const c of filter.conditions) {
        const warning = regexInLiteralOperator(c.negate ? `!${c.operator}` : c.operator, c.value ?? "");
        if (warning) {
          seen.set(`${name}:${warning}`, `Filter '${name}', used by a rule here: ${warning}`);
        }
      }
    }
  }
  return [...seen.values()];
}

