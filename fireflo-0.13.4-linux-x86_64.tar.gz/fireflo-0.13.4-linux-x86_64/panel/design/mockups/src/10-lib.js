<script data-bundle>
/* ───────────── Component library: each function returns an HTML string built from Tailwind classes.
   These class strings are the proposal for the matching React primitive in components/ui. ───────────── */
const S = {};                       // screen registry: id -> {title, group, render(opts)}
const h = (s) => s;                 // marker for template strings
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const icon = (name, cls = 'h-4 w-4') => `<i data-lucide="${name}" class="${cls} shrink-0"></i>`;

/* Buttons — components/ui/button.tsx. Mono: primary is the foreground colour, no green. */
const BTN_BASE = 'inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors disabled:opacity-50';
const BTN_VAR = {
  default: 'bg-primary text-primary-foreground hover:bg-primary/90',
  outline: 'border border-border bg-card text-foreground hover:bg-muted',
  ghost: 'text-foreground hover:bg-muted',
  destructive: 'bg-destructive text-white hover:bg-destructive/90',
  'ghost-destructive': 'text-destructive hover:bg-destructive-soft',
  link: 'text-foreground underline underline-offset-4 hover:text-muted-foreground',
};
const BTN_SIZE = { default: 'h-11 px-4 md:h-9', sm: 'h-11 px-3 md:h-8', icon: 'h-11 w-11 md:h-9 md:w-9', 'icon-sm': 'h-9 w-9 md:h-8 md:w-8' };
const btn = (label, { variant = 'default', size = 'default', icon: ic, cls = '' } = {}) =>
  `<button type="button" class="${BTN_BASE} ${BTN_VAR[variant]} ${BTN_SIZE[size]} ${cls}">${ic ? icon(ic) : ''}${label ? `<span>${label}</span>` : ''}</button>`;

/* Pills — components/ui/badge.tsx */
const PILL = {
  neutral: 'bg-muted text-muted-foreground', primary: 'bg-primary-soft text-foreground',
  success: 'bg-success-soft text-success', warning: 'bg-warning-soft text-warning',
  destructive: 'bg-destructive-soft text-destructive', info: 'bg-info-soft text-info',
  outline: 'border border-border text-muted-foreground',
};
const pill = (text, tone = 'neutral', dot = false) =>
  `<span class="inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-2xs font-semibold leading-4 ${PILL[tone]}">${dot ? '<span class="h-1.5 w-1.5 rounded-full bg-current"></span>' : ''}${text}</span>`;

/* Form controls — ui/input.tsx, select.tsx, switch.tsx, segmented.tsx */
const INPUT = 'h-11 w-full rounded-md border border-border bg-card px-3 text-sm text-foreground md:h-9';
const input = (ph = '', { value = '', mono = false, cls = '', type = 'text', id = '' } = {}) =>
  `<input ${id ? `id="${id}"` : ''} type="${type}" class="${INPUT} ${mono ? 'font-mono' : ''} ${cls}" placeholder="${esc(ph)}" value="${esc(value)}">`;
const select = (options, { value = options[0], cls = '', id = '' } = {}) =>
  `<select ${id ? `id="${id}"` : ''} class="${INPUT} ${cls}">${options.map((o) => `<option ${o === value ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select>`;
const textarea = (ph = '', { rows = 3, value = '', mono = false } = {}) =>
  `<textarea rows="${rows}" class="w-full rounded-md border border-border bg-card px-3 py-2 text-sm ${mono ? 'font-mono' : ''}" placeholder="${esc(ph)}">${esc(value)}</textarea>`;
const sw = (on = true) =>
  `<button type="button" role="switch" aria-checked="${on}" class="relative inline-flex h-[26px] w-11 shrink-0 items-center rounded-full transition-colors ${on ? 'bg-primary' : 'bg-muted border border-border'}"><span class="inline-block h-5 w-5 rounded-full bg-card transition-transform ${on ? 'translate-x-5' : 'translate-x-0.5'} ${on ? '' : 'shadow-[inset_0_0_0_1px_var(--color-border)]'}"></span></button>`;
const checkbox = (label, on = false) =>
  `<label class="inline-flex items-center gap-2 text-sm"><span class="grid h-4 w-4 place-items-center rounded-sm border ${on ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card'}">${on ? icon('check', 'h-3 w-3') : ''}</span>${label}</label>`;
const segmented = (options, active, { fill = false } = {}) =>
  `<div role="radiogroup" class="${fill ? 'grid' : 'inline-flex'} gap-0.5 rounded-lg bg-muted p-[3px]" ${fill ? `style="grid-template-columns:repeat(${options.length},minmax(0,1fr))"` : ''}>${options.map((o) =>
    `<button type="button" role="radio" aria-checked="${o === active}" class="min-h-9 whitespace-nowrap rounded-md px-3 text-sm transition-colors md:min-h-7 ${o === active ? 'bg-card font-medium text-foreground shadow-[0_0_0_1px_var(--color-border)]' : 'text-muted-foreground hover:text-foreground'}">${o}</button>`).join('')}</div>`;
const field = (label, control, hint = '') =>
  `<div><label class="mb-1.5 block text-xs font-semibold">${label}</label>${control}${hint ? `<p class="mt-1 text-xs text-muted-foreground">${hint}</p>` : ''}</div>`;
const searchInput = (ph, cls = 'w-56') =>
  `<label class="relative block ${cls}">${icon('search', 'pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground')}<input class="${INPUT} pl-8" placeholder="${esc(ph)}"></label>`;

/* Settings row — the new form grammar (components/ui/settings-row.tsx, proposed).
   Label + help left, control right; one column below md. No nested card. */
const settingsRow = ({ label, help = '', key = '', chips = [], control, tone = '' }) =>
  `<div class="grid gap-2 px-4 py-3.5 md:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)] md:gap-6 md:px-5 ${tone}">
    <div class="min-w-0">
      <div class="flex flex-wrap items-center gap-2"><span class="text-sm font-medium">${label}</span>${chips.map(([t, tone]) => pill(t, tone)).join('')}</div>
      ${help ? `<p class="mt-0.5 text-xs text-muted-foreground">${help}</p>` : ''}
      ${key ? `<p class="mt-1 font-mono text-2xs text-placeholder">${key}</p>` : ''}
    </div>
    <div class="min-w-0 md:flex md:justify-end md:[&>*]:max-w-sm md:[&>*]:w-full">${control}</div>
  </div>`;
const settingsSection = (title, desc, rows, { actions = '', id = '' } = {}) =>
  `<section ${id ? `id="${id}"` : ''} class="rounded-lg border border-border bg-card">
    <header class="flex flex-wrap items-start justify-between gap-3 border-b border-border px-4 py-3 md:px-5">
      <div class="min-w-0"><h3 class="text-sm font-semibold">${title}</h3>${desc ? `<p class="mt-0.5 text-xs text-muted-foreground">${desc}</p>` : ''}</div>${actions}
    </header>
    <div class="divide-y divide-border">${rows.join('')}</div>
  </section>`;

/* Card — components/ui/card.tsx: hairline, 12px radius, no shadow. */
const card = ({ title = '', desc = '', actions = '', body = '', footer = '', cls = '', pad = true }) =>
  `<section class="min-w-0 rounded-lg border border-border bg-card ${cls}">
    ${title || actions ? `<header class="flex flex-wrap items-start justify-between gap-2 px-4 py-3">
      <div class="min-w-0"><h3 class="text-sm font-semibold">${title}</h3>${desc ? `<p class="mt-0.5 text-xs text-muted-foreground">${desc}</p>` : ''}</div>
      ${actions ? `<div class="flex flex-wrap items-center gap-2">${actions}</div>` : ''}
    </header>` : ''}
    <div class="${pad ? 'px-4 pb-4' : ''} ${(title || actions) ? '' : (pad ? 'pt-4' : '')}">${body}</div>
    ${footer ? `<footer class="flex flex-wrap items-center gap-2 border-t border-border px-4 py-3 text-xs text-muted-foreground">${footer}</footer>` : ''}
  </section>`;

/* Stat tile — replaces StatCard: label, value, delta/hint, optional sparkline; no corner icon. */
const spark = (pts, { cls = 'text-foreground', w = 72, hgt = 22, fill = false } = {}) => {
  const max = Math.max(...pts), min = Math.min(...pts), rng = max - min || 1;
  const xs = pts.map((p, i) => [i * (w / (pts.length - 1)), hgt - 2 - ((p - min) / rng) * (hgt - 4)]);
  const d = xs.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  const area = fill ? `<path d="${d} L${w},${hgt} L0,${hgt} Z" fill="currentColor" opacity=".08"></path>` : '';
  return `<svg viewBox="0 0 ${w} ${hgt}" width="${w}" height="${hgt}" class="${cls} overflow-visible" aria-hidden="true">${area}<path d="${d}" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"></path><circle cx="${xs.at(-1)[0]}" cy="${xs.at(-1)[1]}" r="2" fill="currentColor"></circle></svg>`;
};
const statTile = ({ label, value, hint = '', tone = '', sparkline = null, chip = null }) =>
  `<div class="min-w-0 rounded-lg border border-border bg-card px-4 py-3">
    <p class="text-2xs font-semibold uppercase tracking-wide text-muted-foreground">${label}</p>
    <div class="mt-1 flex items-end justify-between gap-3">
      <p class="tnum text-[26px] font-semibold leading-none ${tone}">${value}</p>
      ${sparkline ? spark(sparkline, { cls: 'text-muted-foreground' }) : ''}
    </div>
    <div class="mt-2 flex items-center gap-2 text-xs text-muted-foreground">${chip ? pill(chip[0], chip[1]) : ''}${hint ? `<span>${hint}</span>` : ''}</div>
  </div>`;
const figures = (items) => `<dl class="flex flex-wrap gap-x-6 gap-y-2">${items.map(([v, k, tone = '']) => `<div><dt class="text-2xs uppercase tracking-wide text-muted-foreground">${k}</dt><dd class="tnum text-sm font-semibold ${tone}">${v}</dd></div>`).join('')}</dl>`;
const factGrid = (facts, cols = 3) => `<dl class="grid gap-x-6 gap-y-3 text-xs" style="grid-template-columns:repeat(auto-fill,minmax(${cols === 2 ? 180 : 140}px,1fr))">${facts.map(([k, v, mono]) => `<div class="min-w-0"><dt class="text-2xs text-muted-foreground">${k}</dt><dd class="truncate ${mono ? 'font-mono' : ''}">${v}</dd></div>`).join('')}</dl>`;

/* Tables — components/ui/table.tsx: 11px uppercase heads, 40px rows, numbers right. */
const table = ({ cols, rows, footer = '', cls = '', wrap = true }) => {
  const head = cols.map((c) => { const [label, align = 'left'] = Array.isArray(c) ? c : [c]; return `<th class="whitespace-nowrap px-4 py-2 text-2xs font-semibold uppercase tracking-wide text-muted-foreground ${align === 'right' ? 'text-right' : 'text-left'}">${label}</th>`; }).join('');
  const body = rows.map((r) => `<tr class="border-b border-border last:border-0 hover:bg-muted/50">${r.map((cell, i) => { const align = Array.isArray(cols[i]) ? cols[i][1] : 'left'; return `<td class="px-4 py-2.5 align-middle ${align === 'right' ? 'tnum text-right' : ''}">${cell}</td>`; }).join('')}</tr>`).join('');
  const t = `<div class="overflow-x-auto"><table class="w-full text-sm ${cls}"><thead class="border-b border-border bg-muted/40"><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>${footer ? `<div class="flex flex-wrap items-center justify-between gap-2 border-t border-border px-4 py-2 text-xs text-muted-foreground">${footer}</div>` : ''}`;
  return wrap ? `<div class="overflow-hidden rounded-lg border border-border bg-card">${t}</div>` : t;
};
const pager = (text) => `<span class="tnum">${text}</span><span class="flex gap-1">${btn('Previous', { variant: 'outline', size: 'sm' })}${btn('Next', { variant: 'outline', size: 'sm' })}</span>`;
const mono = (s, cls = '') => `<span class="font-mono text-xs ${cls}">${s}</span>`;
const link = (s) => `<a href="#" class="font-medium underline-offset-4 hover:underline">${s}</a>`;

/* Tabs — components/ui/tabs.tsx: underline, foreground colour (no green). */
const tabs = (items, active, { count = {} } = {}) =>
  `<div role="tablist" class="-mb-px flex gap-1 overflow-x-auto border-b border-border">${items.map((t) =>
    `<button type="button" role="tab" aria-selected="${t === active}" class="flex items-center gap-1.5 whitespace-nowrap border-b-2 px-3 py-2 text-sm transition-colors ${t === active ? 'border-primary font-semibold text-foreground' : 'border-transparent text-muted-foreground hover:text-foreground'}">${t}${count[t] != null ? `<span class="tnum rounded-full bg-muted px-1.5 text-2xs text-muted-foreground">${count[t]}</span>` : ''}</button>`).join('')}</div>`;

const pageHeader = (title, desc = '', actions = '', { back = '' } = {}) =>
  `<div class="flex flex-wrap items-start justify-between gap-3">
    <div class="min-w-0 flex-1 basis-0 space-y-1">
      ${back ? `<a href="#" class="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">${icon('arrow-left', 'h-3.5 w-3.5')}${back}</a>` : ''}
      <h1 class="text-xl font-semibold tracking-tight">${title}</h1>
      ${desc ? `<p class="max-w-prose text-sm text-muted-foreground">${desc}</p>` : ''}
    </div>
    ${actions ? `<div class="flex min-w-0 flex-wrap items-center gap-2 max-sm:basis-full">${actions}</div>` : ''}
  </div>`;

const strip = (text, tone = 'warning', action = '') =>
  `<div class="flex flex-wrap items-center gap-2 rounded-md px-3 py-2 text-xs ${tone === 'warning' ? 'bg-warning-soft text-warning' : tone === 'destructive' ? 'bg-destructive-soft text-destructive' : 'bg-info-soft text-info'}">${icon(tone === 'info' ? 'info' : 'triangle-alert', 'h-3.5 w-3.5')}<span class="min-w-0 flex-1">${text}</span>${action}</div>`;
const emptyState = (title, body, action = '') =>
  `<div class="rounded-lg border border-dashed border-border px-6 py-10 text-center"><p class="text-sm font-medium">${title}</p><p class="mx-auto mt-1 max-w-sm text-xs text-muted-foreground">${body}</p>${action ? `<div class="mt-3">${action}</div>` : ''}</div>`;

/* Save bar — sticky, mono. */
const saveBar = (count, msg = 'Nothing has reached the gateway yet.') =>
  `<div class="sticky bottom-0 z-10 -mx-4 flex flex-wrap items-center gap-3 border-t border-border bg-card/95 px-4 py-3 backdrop-blur md:-mx-6 md:px-6">
    <p class="min-w-0 flex-[1_1_280px] text-sm"><span class="font-semibold">${count} unsaved ${count === 1 ? 'change' : 'changes'}.</span> <span class="text-muted-foreground">${msg}</span></p>
    <div class="flex w-full gap-2 sm:w-auto">${btn('Discard', { variant: 'outline', cls: 'flex-1 sm:flex-none' })}${btn(`Save ${count} ${count === 1 ? 'change' : 'changes'}`, { cls: 'flex-1 sm:flex-none' })}</div>
  </div>`;

/* Dialog — shown inside a faux viewport so the mockup page keeps its height. */
const dialog = ({ title, desc = '', body, actions, size = 'max-w-lg' }) =>
  `<div class="flex min-h-[520px] items-center justify-center bg-foreground/40 p-4">
    <div role="dialog" class="w-full ${size} rounded-lg border border-border bg-card">
      <header class="flex items-start justify-between gap-3 border-b border-border px-5 py-4"><div><h2 class="text-base font-semibold">${title}</h2>${desc ? `<p class="mt-0.5 text-xs text-muted-foreground">${desc}</p>` : ''}</div><button class="rounded-md p-1 text-muted-foreground hover:bg-muted" aria-label="Close">${icon('x')}</button></header>
      <div class="space-y-4 px-5 py-4">${body}</div>
      <footer class="flex flex-wrap justify-end gap-2 border-t border-border px-5 py-3">${actions}</footer>
    </div>
  </div>`;

/* Simple charts — inline SVG, drawn to scale. */
const barChart = (series, { hgt = 160, labels = [], stacked = null, colors = ['text-chart-1', 'text-chart-3'] } = {}) => {
  const n = series[0].length, w = 600, gap = 4, bw = (w - gap * (n - 1)) / n;
  const totals = Array.from({ length: n }, (_, i) => series.reduce((a, s) => a + s[i], 0));
  const max = Math.max(...totals) || 1;
  let bars = '';
  for (let i = 0; i < n; i++) { let y = hgt - 18; series.forEach((s, k) => { const bh = (s[i] / max) * (hgt - 28); y -= bh; bars += `<rect x="${(i * (bw + gap)).toFixed(1)}" y="${y.toFixed(1)}" width="${bw.toFixed(1)}" height="${bh.toFixed(1)}" rx="1.5" class="${colors[k]}" fill="currentColor" ${k === 0 && i === n - 1 ? 'opacity=".45"' : ''}></rect>`; }); }
  const grid = [0.25, 0.5, 0.75, 1].map((f) => `<line x1="0" x2="${w}" y1="${(hgt - 18 - f * (hgt - 28)).toFixed(1)}" y2="${(hgt - 18 - f * (hgt - 28)).toFixed(1)}" stroke="currentColor" class="text-border" stroke-dasharray="2 4"></line>`).join('');
  const lab = labels.map((l, i) => `<text x="${(i * (bw + gap) + bw / 2).toFixed(1)}" y="${hgt - 4}" text-anchor="middle" font-size="10" fill="currentColor" class="text-muted-foreground">${l}</text>`).join('');
  return `<svg viewBox="0 0 ${w} ${hgt}" class="h-auto w-full" aria-hidden="true">${grid}${bars}${lab}<text x="0" y="10" font-size="10" fill="currentColor" class="text-muted-foreground tnum">${max.toLocaleString()}</text></svg>`;
};
const lineChart = (series, { hgt = 200, colors = ['text-chart-2', 'text-chart-1', 'text-chart-3'], labels = [] } = {}) => {
  const n = series[0].length, w = 600, max = Math.max(...series.flat()) || 1;
  const path = (s) => s.map((v, i) => `${i ? 'L' : 'M'}${(i * (w / (n - 1))).toFixed(1)},${(hgt - 18 - (v / max) * (hgt - 30)).toFixed(1)}`).join(' ');
  const grid = [0.25, 0.5, 0.75, 1].map((f) => `<line x1="0" x2="${w}" y1="${(hgt - 18 - f * (hgt - 30)).toFixed(1)}" y2="${(hgt - 18 - f * (hgt - 30)).toFixed(1)}" stroke="currentColor" class="text-border" stroke-dasharray="2 4"></line>`).join('');
  const lab = labels.map((l, i) => `<text x="${(i * (w / (labels.length - 1))).toFixed(1)}" y="${hgt - 4}" text-anchor="${i === 0 ? 'start' : i === labels.length - 1 ? 'end' : 'middle'}" font-size="10" fill="currentColor" class="text-muted-foreground">${l}</text>`).join('');
  return `<svg viewBox="0 0 ${w} ${hgt}" class="h-auto w-full" aria-hidden="true">${grid}${series.map((s, k) => `<path d="${path(s)}" fill="none" stroke="currentColor" class="${colors[k]}" stroke-width="${k === 1 ? 2 : 1.5}" ${k === 0 ? 'stroke-dasharray="4 3"' : ''}></path>`).join('')}${lab}</svg>`;
};
const legend = (items) => `<div class="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">${items.map(([l, c]) => `<span class="inline-flex items-center gap-1.5"><span class="h-2 w-2 rounded-full ${c}" style="background:currentColor"></span>${l}</span>`).join('')}</div>`;

/* Brand mark — the one green thing in the chrome. */
const mark = (cls = 'h-5 w-5') => `<svg viewBox="0 0 24 24" class="${cls} text-brand" aria-hidden="true"><rect x="2" y="2" width="20" height="20" rx="6" fill="currentColor"></rect><path d="M8 16c0-4 2-6 4-9 2 3 4 5 4 9a4 4 0 0 1-8 0z" fill="var(--color-card)"></path></svg>`;
</script>
