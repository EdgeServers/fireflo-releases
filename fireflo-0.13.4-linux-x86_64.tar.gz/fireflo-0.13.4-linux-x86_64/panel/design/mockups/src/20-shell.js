<script data-bundle>
/* ───────────── Shells ───────────── */
const CP_GROUPS = [
  { label: 'Gateway', links: [['Messages', 'list-tree'], ['Vendors', 'antenna'], ['Servers', 'server'], ['Accounts', 'users'], ['Pricing', 'coins'], ['Logs', 'stethoscope'], ['Security', 'shield']] },
  { label: 'Configuration', links: [['Gateway', 'sliders-horizontal'], ['Error codes', 'languages'], ['Filters', 'filter'], ['Preprocessors', 'cpu'], ['TLVs', 'tags']] },
  { label: 'Assets', links: [['Headers', 'signature'], ['Templates', 'file-text']] },
  { label: 'Reports', links: [['Refused', 'shield-x'], ['Access log', 'scroll-text'], ['Queues', 'layers'], ['Archives', 'archive'], ['Receipts', 'mail-check'], ['Usage', 'chart-column'], ['Revenue', 'wallet']] },
];
const QUICK = ['Messages', 'Vendors', 'Servers', 'Accounts'];

/* One nav row. Active = 2px left rule + semibold foreground, tint from muted. No accent colour. */
const navRow = (label, ic, active, collapsed = false, count = null) =>
  `<a href="#" aria-current="${active ? 'page' : 'false'}" title="${collapsed ? label : ''}" class="group flex min-h-11 items-center rounded-md border-l-2 text-sm transition-colors md:min-h-8 ${collapsed ? 'justify-center px-0' : 'gap-2.5 pl-2.5 pr-2'} ${active ? 'border-primary bg-muted font-semibold text-foreground' : 'border-transparent font-medium text-foreground/80 hover:bg-muted hover:text-foreground'}">${icon(ic, `h-4 w-4 ${active ? 'text-foreground' : 'text-muted-foreground'}`)}${collapsed ? '' : `<span class="truncate">${label}</span>${count != null ? `<span class="tnum ml-auto text-2xs text-muted-foreground">${count}</span>` : ''}`}</a>`;

const sidebar = (active, { collapsed = false, drawer = false, groups = CP_GROUPS, overview = ['Overview', 'activity'], footer = true, brand = 'FireFlo', version = '0.12.30' } = {}) =>
  `<aside class="flex h-full flex-col border-r border-border bg-card ${collapsed ? 'w-14' : 'w-[232px]'}">
    <div class="flex h-14 items-center border-b border-border ${collapsed ? 'justify-center' : 'gap-2 px-4'}">
      ${mark()}${collapsed ? '' : `<span class="truncate text-sm font-semibold tracking-tight">${brand}</span>${version ? `<span class="tnum ml-auto rounded-full bg-muted px-1.5 py-0.5 text-2xs font-medium text-muted-foreground">${version}</span>` : ''}`}
      ${drawer ? `<button class="-mr-2 ml-auto rounded-md p-2 text-muted-foreground hover:bg-muted" aria-label="Close menu">${icon('x', 'h-5 w-5')}</button>` : ''}
    </div>
    <nav class="flex-1 overflow-y-auto py-3 ${collapsed ? 'px-2' : 'px-3'}">
      <div class="space-y-0.5">${navRow(overview[0], overview[1], active === overview[0], collapsed)}</div>
      ${groups.map((g) => `<div class="mt-3 space-y-0.5">${collapsed ? '<div class="mx-2 my-2 border-t border-border"></div>' : `<p class="px-2.5 pb-1.5 pt-3 text-2xs font-semibold uppercase tracking-[0.08em] text-muted-foreground">${g.label}</p>`}${g.links.map(([l, i, c]) => navRow(l, i, active === l, collapsed, c)).join('')}</div>`).join('')}
    </nav>
    ${footer ? `<div class="border-t border-border p-3 ${collapsed ? 'flex justify-center' : ''}">
      ${collapsed ? `<span class="grid h-7 w-7 place-items-center rounded-full bg-muted text-2xs font-bold">OP</span>` : `<div class="flex items-center gap-2 px-1"><span class="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-muted text-2xs font-bold">OP</span><div class="min-w-0 leading-tight"><p class="truncate text-xs font-semibold">ops@remotiq.au</p><p class="text-2xs text-muted-foreground">admin</p></div><button class="ml-auto rounded-md p-1.5 text-muted-foreground hover:bg-muted" aria-label="Sign out">${icon('log-out')}</button></div>`}
    </div>` : ''}
  </aside>`;

/* Top bar: brand (phone only), quick-nav tabs, jump box, health + TPS, theme, user. */
const topbar = (active, { quick = QUICK, health = ['Healthy', 'success', '1,240/s'], brand = 'FireFlo', tenant = 'websmsc', user = 'OP' } = {}) =>
  `<header class="sticky top-0 z-20 flex h-14 shrink-0 items-center gap-2 border-b border-border bg-card px-3 md:gap-3 md:px-4">
    <button class="rounded-md p-2 text-muted-foreground hover:bg-muted md:hidden" aria-label="Open menu">${icon('menu', 'h-5 w-5')}</button>
    <span class="flex items-center gap-2 md:hidden">${mark()}<span class="text-sm font-semibold">${brand}</span></span>
    <span class="hidden items-center gap-1.5 text-xs text-muted-foreground md:flex">${icon('building-2', 'h-3.5 w-3.5')}<span class="font-medium text-foreground">${tenant}</span></span>
    <span class="hidden h-5 w-px bg-border md:block"></span>
    <nav class="hidden items-center gap-0.5 lg:flex" aria-label="Quick navigation">${quick.map((q) => `<a href="#" class="rounded-md px-2.5 py-1.5 text-sm transition-colors ${q === active ? 'bg-muted font-semibold text-foreground' : 'font-medium text-muted-foreground hover:bg-muted hover:text-foreground'}">${q}</a>`).join('')}</nav>
    <button class="ml-auto hidden h-9 w-full max-w-[280px] items-center gap-2 rounded-md border border-border bg-background px-2.5 text-sm text-muted-foreground hover:bg-muted md:flex lg:mx-4">${icon('search', 'h-3.5 w-3.5')}<span class="truncate">Jump to account, vendor, message id</span><kbd class="ml-auto rounded border border-border px-1 font-mono text-2xs">⌘K</kbd></button>
    <button class="rounded-md p-2 text-muted-foreground hover:bg-muted md:hidden" aria-label="Search">${icon('search', 'h-5 w-5')}</button>
    ${health ? `    <a href="#" class="ml-auto flex items-center gap-2 rounded-full border border-border py-1 pl-2 pr-2.5 text-xs md:ml-0" title="Gateway health">
      <span class="h-2 w-2 rounded-full ${health[1] === 'success' ? 'bg-success' : health[1] === 'warning' ? 'bg-warning' : 'bg-destructive'}"></span><span class="hidden font-medium sm:inline">${health[0]}</span>
      ${health[2] ? `<span class="hidden items-center gap-1.5 text-muted-foreground sm:inline-flex">${spark([3, 4, 3.6, 5, 4.4, 5.2, 6, 5.5, 6.4, 6.1], { w: 44, hgt: 14, cls: 'text-muted-foreground' })}<span class="tnum">${health[2]}</span></span>` : ''}
    </a>` : ""}
    <button class="hidden rounded-md p-2 text-muted-foreground hover:bg-muted sm:inline-flex" aria-label="Toggle theme">${icon('sun-moon', 'h-4 w-4')}</button>
    <button class="flex items-center gap-1 rounded-full" aria-label="Account menu"><span class="grid h-8 w-8 place-items-center rounded-full bg-muted text-2xs font-bold">${user}</span>${icon('chevron-down', 'hidden h-3.5 w-3.5 text-muted-foreground md:inline')}</button>
  </header>`;

/* Operator shell: sidebar persistent from md (icon rail on tablet, labels from lg), drawer below. */
const cpShell = (active, content, { drawerOpen = false, collapsed = 'auto', quick = QUICK, topbarOpts = {} } = {}) => {
  const side = collapsed === 'auto'
    ? `<div class="hidden shrink-0 md:block lg:hidden">${sidebar(active, { collapsed: true })}</div><div class="hidden shrink-0 lg:block">${sidebar(active)}</div>`
    : `<div class="hidden shrink-0 md:block">${sidebar(active, { collapsed })}</div>`;
  const drawer = drawerOpen ? `<div class="absolute inset-0 z-30 bg-foreground/50 md:hidden"></div><div class="absolute inset-y-0 left-0 z-40 md:hidden">${sidebar(active, { drawer: true })}</div>` : '';
  return `<div class="relative flex min-h-[640px] bg-background text-foreground">${side}${drawer}
    <div class="flex min-w-0 flex-1 flex-col">${topbar(active, { quick, ...topbarOpts })}
      <main class="mx-auto w-full max-w-[1440px] flex-1 space-y-5 p-4 md:p-6">${content}
        <footer class="flex flex-wrap items-center justify-between gap-2 border-t border-border pt-4 text-xs text-muted-foreground"><span>© 2026 FireFlo by RemotIQ. All rights reserved.</span><span class="tnum">v0.12.30</span></footer>
      </main></div></div>`;
};

/* MIS portal shell: same shell grammar, customer nav, balance in the sidebar footer (strip on phone). */
const MIS_GROUPS = (resells) => [
  ...(resells ? [{ label: 'Customers', links: [['Accounts', 'users', 3]] }] : []),
  { label: 'Messaging', links: [['Messages', 'message-square'], ['Sender IDs', 'signature'], ['Templates', 'file-text']] },
  { label: 'Billing', links: [['Statement', 'receipt']] },
  { label: 'Developer', links: [['API playground', 'terminal'], ['REST API reference', 'book-open']] },
];
const misShell = (active, content, { resells = true, brand = 'Acme Messaging', account = 'Acme Communications', id = 'acme-au', balance = '12,480.5500', cur = 'AUD', drawerOpen = false } = {}) => {
  const side = (collapsed) => `<div class="flex h-full flex-col">${sidebar(active, { collapsed, groups: MIS_GROUPS(resells), footer: false, brand, version: '' }).replace('</aside>', '')}
      <div class="border-t border-border p-3 ${collapsed ? 'text-center' : ''}">${collapsed ? `<p class="tnum text-xs text-muted-foreground" title="Balance ${balance} ${cur}">${balance.split('.')[0]}</p>` : `<p class="truncate text-xs font-semibold">${account}</p><p class="font-mono text-2xs text-muted-foreground">${id}</p><p class="mt-2 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">Balance</p><p class="tnum text-lg font-semibold leading-tight">${balance} <span class="text-xs font-normal text-muted-foreground">${cur}</span></p>`}</div></aside></div>`;
  const drawer = drawerOpen ? `<div class="absolute inset-0 z-30 bg-foreground/50 md:hidden"></div><div class="absolute inset-y-0 left-0 z-40 md:hidden">${sidebar(active, { drawer: true, groups: MIS_GROUPS(resells), footer: false, brand, version: '' })}</div>` : '';
  const bar = topbar(active, { quick: resells ? ['Messages', 'Statement', 'Accounts'] : ['Messages', 'Statement'], health: null, brand, tenant: account, user: 'AC' })
    .replace(/<a href="#" class="ml-auto flex items-center gap-2 rounded-full border[\s\S]*?<\/a>/, `<a href="#" class="ml-auto hidden items-center gap-2 rounded-full border border-border px-3 py-1 text-xs md:flex lg:ml-0"><span class="text-muted-foreground">Balance</span><span class="tnum font-semibold">${balance} ${cur}</span></a><button class="ml-auto rounded-md p-2 text-muted-foreground hover:bg-muted md:hidden" aria-label="Password">${icon('key-round', 'h-5 w-5')}</button>`);
  return `<div class="relative flex min-h-[640px] bg-background text-foreground"><div class="hidden shrink-0 md:block lg:hidden">${side(true)}</div><div class="hidden shrink-0 lg:block">${side(false)}</div>${drawer}
    <div class="flex min-w-0 flex-1 flex-col">${bar}
      <div class="flex items-baseline gap-3 border-b border-border bg-card px-4 py-2 text-sm md:hidden"><span class="truncate font-medium">${account}</span><span class="tnum ml-auto"><span class="text-2xs font-semibold uppercase text-muted-foreground">Balance </span><span class="font-semibold">${balance}</span> <span class="text-muted-foreground">${cur}</span></span></div>
      <main class="mx-auto w-full max-w-[1440px] flex-1 space-y-5 p-4 md:p-6">${content}
        <footer class="border-t border-border pt-4 text-xs text-muted-foreground">© 2026 ${brand}. All rights reserved.</footer>
      </main></div></div>`;
};
</script>
