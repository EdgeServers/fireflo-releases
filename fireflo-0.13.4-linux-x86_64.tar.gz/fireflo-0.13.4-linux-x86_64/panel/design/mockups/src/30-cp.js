<script data-bundle>
/* ───────────── Foundations sheet ───────────── */
S['foundations'] = { title: 'Foundations & components', group: 'Design system', render: () => {
  const swatch = (name, v) => `<div class="min-w-0"><div class="h-12 rounded-md border border-border" style="background:var(--color-${v})"></div><p class="mt-1 truncate text-xs font-medium">${name}</p><p class="truncate font-mono text-2xs text-muted-foreground">--color-${v}</p></div>`;
  const row = (t, body) => `<div class="grid gap-3 md:grid-cols-[180px_minmax(0,1fr)]"><h3 class="text-sm font-semibold">${t}</h3><div class="min-w-0 space-y-3">${body}</div></div>`;
  return `<div class="mx-auto max-w-[1100px] space-y-8 p-4 md:p-8">
    ${pageHeader('Foundations', 'Tokens keep the names from app/globals.css. Values move to a neutral slate scale: the primary is the foreground colour, green appears only on the mark and as the success state.')}
    ${row('Colour', `<div class="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">${[['Background','background'],['Card','card'],['Border','border'],['Muted','muted'],['Muted text','muted-foreground'],['Foreground','foreground'],['Primary','primary'],['Primary soft','primary-soft'],['Success','success'],['Success soft','success-soft'],['Warning','warning'],['Warning soft','warning-soft'],['Destructive','destructive'],['Destructive soft','destructive-soft'],['Info','info'],['Info soft','info-soft'],['Brand','brand'],['Placeholder','placeholder']].map(([n,v]) => swatch(n,v)).join('')}</div>`)}
    ${row('Type', `<div class="space-y-1"><p class="text-xl font-semibold tracking-tight">Page title · text-xl semibold</p><p class="text-base font-semibold">Card title · text-sm semibold (shown larger)</p><p class="text-sm">Body and controls · text-sm (14px)</p><p class="text-xs text-muted-foreground">Help text · text-xs muted (12px)</p><p class="text-2xs font-semibold uppercase tracking-wide text-muted-foreground">Labels and table heads · text-2xs uppercase (11px)</p><p class="font-mono text-xs">identifiers · font-mono text-xs</p><p class="tnum text-[26px] font-semibold leading-none">1,240,512 <span class="text-xs font-normal text-muted-foreground">stat value · 26px tabular</span></p></div>`)}
    ${row('Buttons', `<div class="flex flex-wrap items-center gap-2">${btn('Primary')}${btn('Outline', { variant: 'outline' })}${btn('Ghost', { variant: 'ghost' })}${btn('Delete', { variant: 'destructive' })}${btn('Remove', { variant: 'ghost-destructive' })}${btn('Add vendor', { icon: 'plus' })}${btn('Small', { variant: 'outline', size: 'sm' })}${btn('', { variant: 'outline', size: 'icon', icon: 'refresh-cw' })}${btn('Disabled', { cls: 'opacity-50' })}</div><p class="text-xs text-muted-foreground">One primary per view. Controls are 44px tall below md and 36px on a pointer device, as today.</p>`)}
    ${row('Inputs', `<div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">${field('Text', input('acme-smpp', { mono: true }))}${field('Select', select(['SMPP bind', 'HTTP', 'REST']))}${field('With hint', input('ops@acme.com'), 'The customer’s portal login.')}${field('Invalid', input('', { value: '0.045x', cls: 'border-destructive' }), '<span class="text-destructive">Up to 4 decimal places.</span>')}${field('Search', searchInput('account, login or product', 'w-full'))}${field('Textarea', textarea('Anything the next operator should know', { rows: 2 }))}</div><div class="flex flex-wrap items-center gap-6">${sw(true)}${sw(false)}${checkbox('Remember me on this device', true)}${checkbox('Listed')}${segmented(['24 hours', '7 days', '30 days'], '7 days')}</div>`)}
    ${row('Pills', `<div class="flex flex-wrap gap-2">${pill('bound', 'success', true)}${pill('retrying', 'warning', true)}${pill('down', 'destructive', true)}${pill('reseller', 'primary')}${pill('unlisted', 'outline')}${pill('in force', 'neutral')}${pill('Unsaved · was 50', 'info')}${pill('Awaiting receipt', 'outline')}${pill('Delivered', 'success')}${pill('Not approved', 'destructive')}</div>`)}
    ${row('Tabs', `${tabs(['Status', 'Bind settings', 'Cost rates', 'Traffic', 'Sessions'], 'Bind settings', { count: { 'Bind settings': 14, Sessions: 4 } })}`)}
    ${row('Stat tiles', `<div class="grid grid-cols-2 gap-3 lg:grid-cols-4">${statTile({ label: 'Messages', value: '2.41M', hint: '+6% vs last period', sparkline: [4,5,4,6,7,6,8,9] })}${statTile({ label: 'Delivery rate', value: '97.8%', chip: ['healthy', 'success'] })}${statTile({ label: 'Refused', value: '1,204', chip: ['3 reasons', 'warning'], tone: 'text-destructive' })}${statTile({ label: 'Margin', value: '18.2%', hint: 'AUD 4,120 billed − 3,370 cost' })}</div>`)}
    ${row('Settings rows', settingsSection('Receipts and callbacks', 'Rows replace nested cards: label and help on the left, the control on the right, one column on a phone.', [
      settingsRow({ label: 'Refuse unrated', help: 'Reject a message no price rule covers instead of sending it for free.', key: 'smsg.refuseUnrated', chips: [['Set · default is off', 'neutral']], control: `<div class="flex md:justify-end">${sw(true)}</div>` }),
      settingsRow({ label: 'Default window', help: 'Inherited by every vendor without a window of its own.', key: 'outSms.default.window', chips: [['Unsaved · was 50', 'info']], control: input('', { value: '100' }), tone: 'bg-info-soft/40' }),
      settingsRow({ label: 'Receipt callback', help: 'Where HTTP customers get delivery receipts unless the login sets its own.', key: 'rest.dlr.url', chips: [['Default', 'outline']], control: input('https://') }),
    ]))}
    ${row('Table', table({ cols: ['Vendor', ['Binds', 'right'], ['tps', 'right'], 'State', ''], rows: [['telstra-a', '4 / 4', '612', pill('bound', 'success', true), btn('Edit', { variant: 'ghost', size: 'sm' })], ['optus-wholesale', '2 / 4', '430', pill('retrying', 'warning', true), btn('Edit', { variant: 'ghost', size: 'sm' })], ['route-intl', '0 / 2', '0', pill('down', 'destructive', true), btn('Edit', { variant: 'ghost', size: 'sm' })]], footer: pager('3 vendors · page 1 of 1') }))}
    ${row('Notices', `${strip('2 vendors need attention — listed first.', 'warning', btn('Show', { variant: 'ghost', size: 'sm' }))}${strip('The gateway is reading pricing from this database, and there is none.', 'destructive', btn('Set a cost', { variant: 'outline', size: 'sm' }))}${strip('Kept in this browser. The CSV carries whatever is ticked here.', 'info')}${emptyState('No traffic in this period', 'Widen the range, or check that a vendor is bound.', btn('Open vendors', { variant: 'outline', size: 'sm' }))}`)}
    ${row('Dialog', dialog({ title: 'Save this account?', desc: 'The gateway reads it on its next poll, within 30 seconds.', body: `<div class="rounded-md bg-muted p-3 font-mono text-xs"><div class="flex gap-2"><span class="w-24 text-muted-foreground">email</span><span class="line-through text-muted-foreground">ops@acme.com</span><span>→</span><span>billing@acme.com</span></div></div>${field('Type <b>acme-au</b> to confirm', input('acme-au', { mono: true }))}`, actions: `${btn('Cancel', { variant: 'outline' })}${btn('Save account')}`, size: 'max-w-md' }))}
    <div class="relative">${saveBar(3)}</div>
  </div>`; } };

/* ───────────── Shell variants ───────────── */
S['shell-cp'] = { title: 'Operator shell', group: 'Shells', render: () => cpShell('Overview', `${pageHeader('Overview', 'Resize the device above: sidebar with labels from 1024px, icon rail on a tablet, drawer on a phone. The quick-nav tabs fold into the jump box below 1024px.')}${emptyState('Page content', 'Every operator page renders inside this frame.')}`) };
S['shell-cp-drawer'] = { title: 'Operator shell · phone drawer open', group: 'Shells', render: () => cpShell('Messages', `${pageHeader('Messages', 'Every message the gateway handled, one call record each, with what happened to it.')}${emptyState('Page content', 'Behind the drawer.')}`, { drawerOpen: true }) };
S['shell-cp-collapsed'] = { title: 'Operator shell · rail collapsed', group: 'Shells', render: () => cpShell('Vendors', `${pageHeader('Vendors', 'The rail stays collapsed when the operator chose that; the choice is remembered per browser.')}${emptyState('Page content', '')}`, { collapsed: true }) };
S['shell-mis'] = { title: 'MIS portal shell', group: 'Shells', render: () => misShell('Overview', `${pageHeader('Overview', 'Your traffic and what happened to it.')}${emptyState('Page content', 'Customer pages render here. Balance lives in the sidebar footer, the top bar, and a strip on phones.')}`) };
S['shell-mis-drawer'] = { title: 'MIS shell · phone drawer open', group: 'Shells', render: () => misShell('Messages', `${pageHeader('Messages', 'Every message you sent, and what happened to it.')}${emptyState('Page content', '')}`, { drawerOpen: true }) };

/* ───────────── 1 · Operator overview ───────────── */
S['cp-overview'] = { title: 'Overview', group: 'Operator panel', route: '/cp', render: () => cpShell('Overview', `
  ${pageHeader('Overview', 'Traffic, delivery and margin across every account for the chosen period, and why messages failed.', segmented(['24 hours', '7 days', '30 days'], '24 hours'))}
  <p class="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">as of 14:32:08 ${pill('stale: revenue', 'warning')}</p>
  <div class="grid grid-cols-2 gap-3 xl:grid-cols-4">
    ${statTile({ label: 'Messages', value: '184,210', hint: '+6% on yesterday', sparkline: [5,6,5,7,8,7,9,10,9,11] })}
    ${statTile({ label: 'Delivery rate', value: '97.8%', hint: '180,160 delivered · 4,050 failed', chip: ['healthy', 'success'] })}
    ${statTile({ label: 'In flight', value: '2,318', hint: 'Awaiting a delivery receipt' })}
    ${statTile({ label: 'Margin', value: '18.2%', hint: 'AUD 9,210 billed − 7,534 cost', chip: ['+1.1 pt', 'success'] })}
  </div>
  <div class="grid gap-3 xl:grid-cols-[1.6fr_1fr]">
    ${card({ title: 'Traffic', desc: 'Per 15 minutes. The shaded tail is still settling.', actions: legend([['Submitted', 'text-chart-2'], ['Delivered', 'text-chart-1'], ['Failed', 'text-chart-3']]), body: lineChart([[60,70,65,90,120,140,135,160,180,170,190,210,205,230,220,240],[58,68,63,88,118,137,132,156,176,166,186,206,200,225,214,236],[2,2,2,2,2,3,3,4,4,4,4,4,5,5,6,4]], { labels: ['00:00', '06:00', '12:00', '18:00', 'now'] }) })}
    ${card({ title: 'Why messages failed', desc: 'Since 00:00 — the reasons are read live from the receipts.', body: `<div class="divide-y divide-border">${[['UNDELIV', 'receipt state 5', 'vendor error 0x45', '2,104'], ['EXPIRED', 'receipt state 3', '', '1,310'], ['REJECTD', 'receipt state 6', 'vendor error 0x0b', '636']].map(([s, r, v, n]) => `<div class="flex items-center gap-3 py-2 text-sm">${pill(s, 'destructive')}<span class="text-xs text-muted-foreground">${r}</span>${v ? mono(v, 'text-muted-foreground') : ''}<span class="tnum ml-auto font-semibold">${n}</span><button class="rounded p-1 text-muted-foreground hover:bg-muted" aria-label="Dismiss">${icon('x', 'h-3.5 w-3.5')}</button></div>`).join('')}</div>`, footer: `<button class="hover:text-foreground">1 dismissed · show</button>` })}
  </div>
  <section class="space-y-3">
    <div class="flex flex-wrap items-baseline justify-between gap-2"><div><h2 class="text-sm font-semibold">Gateway health</h2><p class="text-xs text-muted-foreground">Whether the software has the room to carry what is being asked of it.</p></div>${link('Runtime detail →')}</div>
    <div class="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
      ${[['Memory', '1.9 GB', 'of 4 GB heap', [40,42,41,45,44,47,46,48]], ['Processor', '31%', '8 cores', [20,25,30,28,35,31,33,31]], ['Tasks running', '142', 'of 512 threads', [120,130,125,140,138,142,141,142]], ['API requests', '1,180/s', 'p99 42 ms', [900,1000,1100,1050,1180,1150,1200,1180]], ['Internal tasks', '36', 'queued', [10,20,15,30,25,40,36,36]], ['Uptime', '41 d 6 h', 'since 0.12.30', null]].map(([l, v, h, s]) => statTile({ label: l, value: v, hint: h, sparkline: s })).join('')}
    </div>
  </section>`) };

/* ───────────── 2 · Messages (CDRs) ───────────── */
const cdrRows = [
  ['14:31:58', '+61412 345 678', 'ACMEIN', 'acme-au', 'smpp-1', 'telstra-a', '0.0450', pill('Delivered', 'success')],
  ['14:31:57', '+61433 900 112', 'ACMEIN', 'acme-au', 'smpp-1', 'telstra-a', '0.0450', pill('Delivered', 'success')],
  ['14:31:55', '+64 21 555 019', 'INFO', 'kiwi-sms', 'http', 'route-intl', '0.0610', pill('Awaiting receipt', 'outline')],
  ['14:31:52', '+61400 221 006', 'BANKAU', 'nbank', 'smpp-2', 'optus-wholesale', '0.0420', pill('UNDELIV', 'destructive')],
  ['14:31:50', '+61477 013 998', 'ACMEIN', 'acme-au', 'smpp-1', 'telstra-a', '0.0450', pill('Delivered', 'success')],
  ['14:31:49', '+61411 777 203', 'SHOPNOW', 'retail-grp', 'rest', 'telstra-a', '0.0450', pill('EXPIRED', 'destructive')],
  ['14:31:44', '+61455 302 118', 'ACMEIN', 'acme-au', 'smpp-1', 'telstra-a', '0.0450', pill('Delivered', 'success')],
  ['14:31:40', '+61422 650 071', 'BANKAU', 'nbank', 'smpp-2', 'optus-wholesale', '0.0420', pill('Delivered', 'success')],
];
const cdrFilter = (more = false) => card({ pad: true, body: `
  <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7">
    ${field('Period', select(['Last hour', 'Last 24 hours', 'Last 7 days', 'Last 30 days', 'Date range'], { value: 'Last 24 hours' }))}
    ${field('Outcome', select(['Any outcome', 'Awaiting a receipt', 'Delivered', 'UNDELIV', 'EXPIRED', 'REJECTD']))}
    ${field('To number', input('starts with…'))}
    ${field('Ingress server', input('any listener'))}
    ${field('Vendor', input('any vendor'))}
    ${field('Message id', input('exact', { mono: true }))}
    ${field('Message text', input('contains…'))}
  </div>
  ${more ? `<div class="mt-3 grid gap-3 border-t border-border pt-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">${field('Account', input('exact', { mono: true }))}${field('Bind name', input('system id', { mono: true }))}${field('Product', input(''))}${field('Came in via', input('smpp, http…'))}${field('From number', input('starts with…'))}${field('Rows', select(['One row per message', 'Every attempt and segment']))}</div>` : ''}
  <div class="mt-3 flex flex-wrap items-center gap-2">${btn('Search', { icon: 'search' })}${btn(more ? 'Fewer filters' : 'More filters', { variant: 'ghost', icon: 'filter' })}${btn('Clear', { variant: 'ghost' })}<span class="ml-auto text-xs text-muted-foreground">Times shown in Australia/Sydney</span></div>` });
S['cp-cdrs'] = { title: 'Messages', group: 'Operator panel', route: '/cp/cdrs', render: () => cpShell('Messages', `
  ${pageHeader('Messages', 'Every message the gateway handled, one call record each, with what happened to it.', `${btn('Refresh', { variant: 'outline', icon: 'refresh-cw' })}${btn('Export these results', { variant: 'outline', icon: 'file-down' })}`)}
  ${cdrFilter(true)}
  <div class="hidden md:block">${table({ cols: ['Submitted', 'To', 'From', 'Account', 'Ingress server', 'Vendor', ['Billed', 'right'], 'Outcome'], rows: cdrRows.map((r) => [link(r[0]), r[1], mono(r[2]), mono(r[3]), mono(r[4]), mono(r[5]), r[6], r[7]]), cls: 'striped', footer: `${pager('184,210 messages · page 1 of 3,685')}${btn('Columns', { variant: 'ghost', size: 'sm', icon: 'columns-3' })}` })}</div>
  <div class="space-y-2 md:hidden">${cdrRows.slice(0, 4).map((r) => `<div class="rounded-lg border border-border bg-card p-3"><div class="flex items-center justify-between gap-2"><span class="font-medium">${r[1]}</span>${r[7]}</div><div class="mt-1 flex items-center justify-between text-xs text-muted-foreground"><span>${link(r[0])}</span><span class="tnum">AUD ${r[6]}</span></div><dl class="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs"><dt class="text-muted-foreground">From</dt><dd>${mono(r[2])}</dd><dt class="text-muted-foreground">Account</dt><dd>${mono(r[3])}</dd><dt class="text-muted-foreground">Vendor</dt><dd>${mono(r[5])}</dd></dl></div>`).join('')}<div class="flex items-center justify-between gap-2 text-xs text-muted-foreground">${pager('page 1 of 3,685')}</div></div>
  ${card({ title: 'Downloads', desc: 'Prepared in the background and kept for seven days.', body: `<div class="divide-y divide-border text-sm">${[['Messages · last 24 hours', '14:20 · 184,210 rows · 31 MB', pill('Ready', 'success'), link('Download')], ['Messages · acme-au · September', '09:02 · 2.1M rows', pill('running', 'outline'), '<span class="text-xs text-muted-foreground">42%</span>']].map((j) => `<div class="flex flex-wrap items-center gap-3 py-2"><div class="min-w-0 flex-1"><p class="font-medium">${j[0]}</p><p class="text-xs text-muted-foreground">${j[1]}</p></div>${j[2]}${j[3]}<button class="rounded p-1 text-muted-foreground hover:bg-muted" aria-label="Delete">${icon('trash-2', 'h-3.5 w-3.5')}</button></div>`).join('')}</div>` })}`) };

/* ───────────── 3 · Message detail ───────────── */
S['cp-cdr-detail'] = { title: 'Message detail', group: 'Operator panel', route: '/cp/cdrs/[msgId]', render: () => cpShell('Messages', `
  ${pageHeader(`<span class="font-mono text-lg">01J9W3K8Q2ZT7V0M9</span>`, 'Submitted 2026-10-18 14:31:58 · 1 part · 1 attempt · 1 receipt', `${pill('Delivered', 'success')}${btn('Open account', { variant: 'outline', size: 'sm' })}${btn('Re-send receipt', { variant: 'outline', size: 'sm', icon: 'mail-check' })}`, { back: 'All messages' })}
  <div class="grid gap-3 xl:grid-cols-[1fr_320px]">
    <div class="space-y-3">
      ${card({ title: 'Route', body: factGrid([['Account', 'acme-au', 1], ['System ID', 'acme-smpp', 1], ['Product', 'au-mobile'], ['Ingress', 'smpp'], ['Ingress server', 'smpp-1', 1], ['Vendor', 'telstra-a', 1], ['From', 'ACMEIN', 1], ['To', '+61412345678', 1], ['Network', 'Telstra AU · 505-01']]) })}
      ${card({ title: 'Vendor exchange', pad: false, body: table({ wrap: false, cols: ['Part', 'PDU', ['Attempt', 'right'], 'Vendor', 'Rule', 'Operator ID', 'Status', 'At'], rows: [['1', mono('submit_sm'), '1', mono('telstra-a'), link('au_routes #3'), mono('7F3A91C2'), pill('ESME_ROK', 'success'), '14:31:58.212'], ['1', mono('deliver_sm'), '—', mono('telstra-a'), '', mono('7F3A91C2'), pill('DELIVRD', 'success'), '14:32:04.871']] }) })}
      ${card({ title: 'Customer exchange', pad: false, body: table({ wrap: false, cols: ['At', 'PDU', ['Try', 'right'], 'Status', 'What we sent them', 'Endpoint'], rows: [['14:31:58.201', mono('submit_sm_resp'), '1', pill('ESME_ROK', 'success'), mono('message_id=01J9W3K8…'), mono('smpp-1')], ['14:32:04.902', mono('deliver_sm'), '1', pill('DELIVRD', 'success'), mono('id:01J9W3K8 stat:DELIVRD'), mono('bind 2 · trx')]] }) })}
      ${card({ title: 'Delivery receipts', pad: false, body: table({ wrap: false, cols: ['Part', 'After', 'At', 'State', 'Error', 'Vendor', 'Sent on', 'Operator ID'], rows: [['1', '6.7 s', '14:32:04.871', pill('DELIVRD', 'success'), mono('000'), mono('telstra-a'), mono('bind 2'), mono('7F3A91C2')]] }) })}
      ${card({ title: 'Message', body: `<p class="rounded-md bg-muted p-3 font-mono text-xs leading-relaxed">Your Acme order 48213 has shipped. Track it at https://acme.example/t/48213</p><p class="mt-2 text-xs text-muted-foreground">GSM-7 · 71 characters · 1 part</p>` })}
      ${card({ title: 'TLVs', pad: false, body: table({ wrap: false, cols: ['Tag', 'Name', 'Received', 'Resolved', 'Sent', 'What happened'], rows: [[mono('0x1403'), mono('cref'), mono('ORD-48213'), mono('ORD-48213'), mono('ORD-48213'), 'passed through'], [mono('0x1401'), mono('dlt_template'), '—', mono('1107…'), mono('1107…'), 'stamped from the approved template']] }) })}
      <details class="rounded-lg border border-border bg-card"><summary class="flex cursor-pointer items-center gap-2 px-4 py-3 text-sm font-semibold">${icon('chevron-right', 'h-4 w-4 text-muted-foreground')}Raw record<span class="ml-auto text-xs font-normal text-muted-foreground">every column of the first attempt, as stored</span></summary><div class="border-t border-border px-4 py-3">${factGrid([['id', '81930221', 1], ['msg_id', '01J9W3K8Q2ZT7V0M9', 1], ['ts', '2026-10-18 14:31:58.198', 1], ['dcs', '0', 1], ['esm_class', '0', 1], ['price', '450', 1], ['cost', '380', 1], ['currency', 'AUD', 1], ['receipt_state', '2', 1]])}</div></details>
    </div>
    <div class="space-y-3">
      ${card({ title: 'Money', body: figures([['AUD 0.0450', 'Billed'], ['AUD 0.0380', 'Cost'], ['AUD 0.0070', 'Margin', 'text-success']]) })}
      ${card({ title: 'Timeline', body: `<ol class="relative space-y-3 border-l border-border pl-4 text-xs">${[['14:31:58.198', 'Accepted on smpp-1 from acme-smpp'], ['14:31:58.201', 'Rated at AUD 0.0450 · rule acme-au #1'], ['14:31:58.205', 'Routed by au_routes #3 → telstra-a'], ['14:31:58.212', 'Sent · ESME_ROK · 7F3A91C2'], ['14:32:04.871', 'Receipt DELIVRD from telstra-a'], ['14:32:04.902', 'Receipt delivered to the customer']].map(([t, s]) => `<li class="relative"><span class="absolute -left-[21px] top-1 h-2 w-2 rounded-full bg-foreground"></span><p class="tnum font-mono text-muted-foreground">${t}</p><p>${s}</p></li>`).join('')}</ol>` })}
    </div>
  </div>`) };

/* ───────────── 4 · Vendors ───────────── */
const workerCard = ({ name, host, state, tone, figs, note = '', settings, peak }) => card({
  title: `<span class="flex items-center gap-2"><span class="h-2 w-2 rounded-full ${tone === 'success' ? 'bg-success' : tone === 'warning' ? 'bg-warning' : 'bg-destructive'}"></span>${link(name)}</span>`, desc: `<span class="font-mono">${host}</span>`,
  actions: `${pill(state, tone)}${btn('Error codes', { variant: 'outline', size: 'sm' })}${tone === 'destructive' ? btn('Test connection', { variant: 'outline', size: 'sm' }) : ''}`,
  body: `${figures(figs)}<p class="mt-2 text-2xs text-muted-foreground">${peak}</p>${note ? `<div class="mt-2">${strip(note, tone === 'warning' ? 'warning' : 'destructive')}</div>` : ''}`,
  footer: `<span class="min-w-0 flex-1 truncate font-mono">${settings}</span>${link('Open vendor →')}${btn('Edit', { variant: 'ghost', size: 'sm' })}${btn('Disable', { variant: 'ghost', size: 'sm' })}` });
S['cp-vendors'] = { title: 'Vendors', group: 'Operator panel', route: '/cp/vendors', render: () => cpShell('Vendors', `
  ${pageHeader('Vendors', 'Settings here, live connection state from the gateway, and traffic for the period.', `${segmented(['24 hours', '7 days', '30 days'], '24 hours')}${btn('Routing', { variant: 'outline' })}${btn('Apply now', { variant: 'outline', icon: 'refresh-cw' })}${btn('Add vendor', { icon: 'plus' })}`)}
  ${strip('2 vendors need attention — listed first.', 'warning')}
  <div class="grid grid-cols-2 gap-3 xl:grid-cols-4">${statTile({ label: 'Vendors', value: '5', chip: ['2 need attention', 'warning'] })}${statTile({ label: 'Bound', value: '9 / 14', hint: 'binds up of configured' })}${statTile({ label: 'Queued', value: '318', sparkline: [200,250,300,280,340,318] })}${statTile({ label: 'Throughput', value: '1,240/s', hint: 'peak 2,980/s at 09:14', sparkline: [800,900,1100,1000,1240,1200,1240] })}</div>
  ${card({ title: 'Traffic · last 15 minutes', actions: `${legend([['MT/s', 'text-chart-1'], ['DLR/s', 'text-chart-2'], ['Queued', 'text-chart-3']])}${select(['All vendors', 'telstra-a', 'optus-wholesale', 'route-intl'], { cls: 'w-44' })}`, body: lineChart([[900,950,1000,980,1100,1050,1200,1150,1240,1230,1210,1240],[880,930,990,960,1080,1040,1180,1130,1220,1210,1200,1230],[200,220,260,240,300,280,340,320,330,318,310,318]], { hgt: 180, colors: ['text-chart-1', 'text-chart-2', 'text-chart-3'], labels: ['−15 m', '−10 m', '−5 m', 'now'] }) })}
  <div class="grid gap-3 xl:grid-cols-2">
    ${workerCard({ name: 'route-intl', host: 'smpp.route-intl.example:2775', state: 'down', tone: 'destructive', figs: [['0 / 2', 'binds', 'text-destructive'], ['214', 'queued'], ['200', 'tps limit'], ['12,040', 'sent in period']], note: 'bind_transceiver refused: ESME_RINVPASWD at 14:02:11', settings: 'trx · window 20 · 200/s · retries 3', peak: 'Peak 190/s at 08:40' })}
    ${workerCard({ name: 'optus-wholesale', host: '203.0.113.40:2777', state: 'retrying', tone: 'warning', figs: [['2 / 4', 'binds', 'text-warning'], ['104', 'queued'], ['600', 'tps limit'], ['61,920', 'sent in period']], note: '2 of 4 binds reconnecting — vendor closed them at 14:28', settings: 'trx ×4 · window 50 · 600/s', peak: 'Peak 590/s at 09:14' })}
    ${workerCard({ name: 'telstra-a', host: 'smpp1.telstra.example:9000', state: 'bound', tone: 'success', figs: [['4 / 4', 'binds'], ['0', 'queued'], ['1,000', 'tps limit'], ['98,110', 'sent in period']], settings: 'trx ×4 · window 100 · 1,000/s · TLS', peak: 'Peak 980/s at 09:14' })}
    ${workerCard({ name: 'telstra-b', host: 'smpp2.telstra.example:9000', state: 'bound', tone: 'success', figs: [['2 / 2', 'binds'], ['0', 'queued'], ['500', 'tps limit'], ['8,004', 'sent in period']], settings: 'tx+rx · window 50 · 500/s · TLS', peak: 'Peak 300/s at 11:02' })}
  </div>
  <p class="text-xs text-muted-foreground"><b class="font-semibold text-foreground">Stop sending</b> keeps binds up and queues traffic. <b class="font-semibold text-foreground">Hold</b> refuses new submits with a retryable error. <b class="font-semibold text-foreground">Disable</b> drops the binds.</p>`) };

/* ───────────── 5 · Vendor detail · Bind settings ───────────── */
S['cp-vendor-detail'] = { title: 'Vendor detail · settings', group: 'Operator panel', route: '/cp/vendors/[name]', render: () => cpShell('Vendors', `
  ${pageHeader(`<span class="flex flex-wrap items-center gap-2">telstra-a ${pill('bound', 'success', true)}</span>`, '<span class="font-mono">smpp1.telstra.example:9000</span> · Primary AU route', `${checkbox('Advanced')}${btn('Restart', { variant: 'outline', icon: 'rotate-cw' })}${btn('Messages →', { variant: 'outline' })}`, { back: 'Vendors' })}
  <div class="grid gap-4 xl:grid-cols-[1fr_300px]">
    <div class="min-w-0 space-y-4">
      ${tabs(['Status', 'Bind settings', 'Cost rates', 'Traffic', 'Sessions'], 'Bind settings', { count: { 'Bind settings': 14, Sessions: 4 } })}
      ${settingsSection('Connection', 'What the gateway dials. A change here reconnects every bind.', [
        settingsRow({ label: 'Host', key: 'host', control: input('', { value: 'smpp1.telstra.example', mono: true }) }),
        settingsRow({ label: 'Port', key: 'port', control: input('', { value: '9000', mono: true }) }),
        settingsRow({ label: 'System ID', key: 'systemId', control: input('', { value: 'remotiq_prod', mono: true }) }),
        settingsRow({ label: 'Password', key: 'password', help: 'Stored encrypted. Shown only while you type a new one.', control: `<div class="flex gap-2">${input('', { value: '••••••••••', type: 'password', mono: true })}${btn('Change', { variant: 'outline' })}</div>` }),
        settingsRow({ label: 'TLS', key: 'tls', help: 'Verify the certificate against the system trust store.', chips: [['in force', 'neutral']], control: `<div class="flex md:justify-end">${sw(true)}</div>` }),
      ])}
      ${settingsSection('Binds and window', 'How many sessions, and how many PDUs each may have in flight.', [
        settingsRow({ label: 'Bind type', key: 'bindType', control: segmented(['Transceiver', 'TX + RX'], 'Transceiver', { fill: true }) }),
        settingsRow({ label: 'Transceivers', key: 'binds', chips: [['Unsaved · was 2', 'info']], control: input('', { value: '4', mono: true }), tone: 'bg-info-soft/40' }),
        settingsRow({ label: 'Window', key: 'window', help: 'Inherited from Gateway › Vendor and listener defaults unless set here.', chips: [['inherited · 50', 'outline']], control: input('gateway default', { mono: true }) }),
      ])}
      ${settingsSection('Throughput and retries', '', [
        settingsRow({ label: 'Throughput limit', key: 'throttle', help: 'Messages per second across all binds. 0 means no limit.', control: input('', { value: '1000', mono: true }) }),
        settingsRow({ label: 'Retries', key: 'retries', help: 'Attempts before a message is failed back to the customer.', chips: [['Default · 3', 'outline']], control: input('3', { mono: true }) }),
        settingsRow({ label: 'Retry delay', key: 'retryDelayMs', control: `<div class="flex items-center gap-2">${input('', { value: '2000', mono: true })}<span class="text-xs text-muted-foreground">ms</span></div>` }),
      ])}
      <div class="space-y-2">${['Timers', 'Addressing', 'Encoding', 'Messages accepted', 'TLVs', 'Failure handling', 'Traffic control', 'Inbound messages', 'PROXY protocol', 'Diagnostics'].map((t, i) => `<details class="rounded-lg border border-border bg-card"><summary class="flex cursor-pointer items-center gap-2 px-4 py-3 text-sm font-medium">${icon('chevron-right', 'h-4 w-4 text-muted-foreground')}${t}<span class="ml-auto text-xs font-normal text-muted-foreground">${[2,3,1,0,2,1,0,1,0,1][i]} set</span></summary></details>`).join('')}</div>
      ${saveBar(1)}
    </div>
    <div class="space-y-3 xl:sticky xl:top-20 xl:self-start">
      ${card({ title: 'Right now', desc: 'refreshed every 10 s', body: `${figures([['4 / 4', 'binds'], ['0', 'queued'], ['612', 'tps now']])}<p class="mt-2 text-2xs text-muted-foreground">Peak 980/s at 09:14 · <a href="#" class="underline">reset</a></p>` })}
      ${card({ title: 'Connection', body: factGrid([['Host', 'smpp1.telstra.example', 1], ['Port', '9000', 1], ['System ID', 'remotiq_prod', 1], ['System type', 'VMA', 1], ['Transceivers', '4'], ['Window', '50 · inherited'], ['Throughput limit', '1,000/s'], ['Stop sending', 'off'], ['Enabled', 'yes']], 2) })}
      ${card({ title: 'Actions', body: `<div class="flex flex-wrap gap-2">${btn('Test connection', { variant: 'outline', size: 'sm' })}${btn('Stop sending', { variant: 'outline', size: 'sm' })}${btn('Hold', { variant: 'outline', size: 'sm' })}${btn('Clean queue…', { variant: 'outline', size: 'sm' })}${btn('Disable', { variant: 'ghost', size: 'sm' })}${btn('Delete', { variant: 'ghost-destructive', size: 'sm' })}</div>` })}
    </div>
  </div>`) };

/* ───────────── 6 · Accounts list ───────────── */
S['cp-accounts'] = { title: 'Accounts', group: 'Operator panel', route: '/cp/accounts', render: () => cpShell('Accounts', `
  ${pageHeader('Accounts', 'Who bills for what. One row per login; the account holds the balance.', `<div class="flex items-center gap-2">${input('acct-1002', { mono: true, cls: 'w-40' })}${btn('Open', { variant: 'outline' })}</div>${btn('Add account', { icon: 'plus' })}`)}
  <div class="grid grid-cols-2 gap-3 xl:grid-cols-4">${statTile({ label: 'Accounts', value: '128', hint: '6 resell · 3 unlisted' })}${statTile({ label: 'Not named yet', value: '4', chip: ['name them', 'warning'] })}${statTile({ label: 'Logins', value: '211', hint: '164 SMPP · 47 HTTP' })}${statTile({ label: 'Disabled logins', value: '7', tone: 'text-destructive' })}</div>
  ${card({ title: 'All accounts', desc: 'Naming an account changes nothing the gateway does; it is for the people reading this page.', actions: `${searchInput('account, login or product')}${btn('Columns', { variant: 'outline', size: 'sm', icon: 'columns-3' })}`, pad: false, body: table({ wrap: false, cls: 'striped', cols: ['Account', 'Email', 'System ID', 'Type', 'Product', 'Allowed IPs', 'Auth', 'Status', ['Balance', 'right'], 'Price rules'], rows: [
    [`${link('Acme Communications')} ${pill('reseller', 'primary')}<br>${mono('acme-au', 'text-muted-foreground')}`, 'ops@acme.com', link('acme-smpp'), pill('SMPP', 'outline'), mono('au-mobile'), mono('203.0.113.10, .11'), 'password', pill('Enabled', 'success'), '12,480.55', '3'],
    [`${link('Acme Communications')}<br>${mono('acme-au', 'text-muted-foreground')}`, '', link('acme-api'), pill('REST', 'outline'), mono('au-mobile'), mono('any'), 'API key', pill('Enabled', 'success'), '', ''],
    [`${link('Northern Bank')}<br>${mono('nbank', 'text-muted-foreground')}`, 'sms@nbank.example', link('nbank-otp'), pill('SMPP', 'outline'), mono('au-otp'), mono('198.51.100.0/24'), 'password', pill('Enabled', 'success'), '41,002.00', '1'],
    [`${link('Kiwi SMS')} ${pill('unlisted', 'outline')}<br>${mono('kiwi-sms', 'text-muted-foreground')}`, 'hello@kiwi.example', link('kiwi-http'), pill('HTTP', 'outline'), mono('nz-mobile'), mono('any'), 'password', pill('Disabled', 'destructive'), '−12.40', 'default'],
    [`${pill('not in the catalogue', 'warning')}<br>${mono('acct-1002', 'text-muted-foreground')}`, '', link('legacy01'), pill('SMPP', 'outline'), '', mono('any'), 'password', pill('Enabled', 'success'), '', 'default'],
  ], footer: `<span>5 rows across 4 accounts · page 1 of 26</span><span class="flex items-center gap-2">${select(['25', '50', '100'], { cls: 'h-8 w-20 md:h-7' })}${btn('Previous', { variant: 'outline', size: 'sm' })}${btn('Next', { variant: 'outline', size: 'sm' })}</span>` }), footer: strip('3 HTTP logins cannot be listed here because they bill to no account.', 'warning', link('Fix →')) })}`) };

S['cp-accounts-login-dialog'] = { title: 'Accounts · login dialog', group: 'Operator panel', route: '/cp/accounts (dialog)', render: () => cpShell('Accounts', dialog({ title: 'Editing acme-smpp', desc: 'Billing to acme-au.', size: 'max-w-3xl', body: `
  <section><h3 class="mb-2 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">Connection</h3><div class="divide-y divide-border rounded-lg border border-border">
    ${settingsRow({ label: 'Connects by', control: segmented(['SMPP bind', 'HTTP', 'REST'], 'SMPP bind', { fill: true }) })}
    ${settingsRow({ label: 'Status', help: 'A disabled login is refused at bind; queued messages still drain.', control: `<div class="flex md:justify-end">${sw(true)}</div>` })}
    ${settingsRow({ label: 'System ID', control: input('acme-smpp', { value: 'acme-smpp', mono: true }) })}
    ${settingsRow({ label: 'Password', control: `<div class="flex gap-2">${input('', { value: '••••••••', type: 'password', mono: true })}${btn('Reveal', { variant: 'outline', size: 'sm', icon: 'eye' })}</div>` })}
  </div></section>
  <section><h3 class="mb-2 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">Billing and tariff</h3><div class="divide-y divide-border rounded-lg border border-border">
    ${settingsRow({ label: 'Account', help: 'Prepaid · 12,480.55 AUD available', control: mono('acme-au', 'text-sm') })}
    ${settingsRow({ label: 'Product', help: 'What this bind asks for as system_type.', control: select(['au-mobile', 'au-otp', 'nz-mobile']) })}
    ${settingsRow({ label: 'Session and TPS limits', chips: [['Advanced', 'outline']], control: `<div class="grid grid-cols-3 gap-2">${input("account's", { mono: true })}${input("account's", { mono: true })}${input("account's", { mono: true })}</div>` })}
  </div></section>
  <section><h3 class="mb-2 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">Where it may connect from</h3><div class="flex flex-wrap gap-2">${['203.0.113.10', '203.0.113.11'].map((ip) => `<span class="inline-flex items-center gap-1 rounded-md border border-border px-2 py-1 font-mono text-xs">${ip}<button class="text-muted-foreground" aria-label="Remove">${icon('x', 'h-3 w-3')}</button></span>`).join('')}${input('203.0.113.12', { mono: true, cls: 'w-44' })}${btn('Add', { variant: 'outline', size: 'sm' })}</div></section>`, actions: `${btn('Cancel', { variant: 'outline' })}${btn('Save login')}` })) };

/* ───────────── 7 · Account · Billing ───────────── */
const accountShell = (tab, body) => `
  ${pageHeader('<span class="flex flex-wrap items-center gap-2">Acme Communications <span class="font-mono text-sm font-normal text-muted-foreground">acme-au</span>' + pill('reseller', 'primary') + '</span>', '', `<span class="text-sm text-muted-foreground">Balance <span class="tnum font-semibold text-foreground">12,480.5500 AUD</span></span>${btn('Messages →', { variant: 'outline', size: 'sm' })}`, { back: 'All accounts' })}
  ${tabs(['Overview', 'Settings', 'Logins', 'Approvals', 'Billing', 'Tariff', 'Statement'], tab, { count: { Logins: 2, Approvals: 1 } })}
  ${body}`;
S['cp-account-billing'] = { title: 'Account · Billing', group: 'Operator panel', route: '/cp/accounts/[id]/billing', render: () => cpShell('Accounts', accountShell('Billing', `
  <div class="grid gap-3 lg:grid-cols-[1.15fr_1fr]">
    ${card({ body: `
      <div class="flex flex-wrap items-center gap-2"><span class="text-2xs font-semibold uppercase tracking-wide text-muted-foreground">Available</span>${pill('Prepaid', 'outline')}</div>
      <p class="tnum mt-1 text-3xl font-semibold">12,480.5500 <span class="text-sm font-normal text-muted-foreground">AUD</span></p>
      <div class="mt-3">${figures([['310.2000', 'Reserved'], ['4,120.0000', 'Spent this month'], ['5,000 · 3 Oct', 'Last top-up']])}</div>
      <div class="mt-4 flex flex-wrap gap-2">${btn('Add credit', { icon: 'plus' })}${btn('Change billing terms', { variant: 'outline' })}${btn('Switch credit off', { variant: 'ghost' })}</div>
      <div class="mt-4 rounded-lg border border-border">${settingsRow({ label: 'Amount', help: 'AUD, up to 4 decimals.', control: input('250', { mono: true }) })}<div class="border-t border-border">${settingsRow({ label: 'Reference', help: 'Shows on the statement.', control: input('receipt-1042', { mono: true }) })}</div><div class="border-t border-border">${settingsRow({ label: 'Note', control: input('optional') })}</div><div class="flex justify-end gap-2 border-t border-border px-4 py-3">${btn('Cancel', { variant: 'ghost', size: 'sm' })}${btn('Add 250.0000 AUD', { size: 'sm' })}</div></div>` })}
    ${card({ body: `<p class="text-2xs font-semibold uppercase tracking-wide text-muted-foreground">MT parts sent · lifetime</p><p class="tnum mt-1 text-3xl font-semibold">8,412,903</p><p class="text-xs text-muted-foreground">from 8,120,114 messages</p><div class="mt-3">${figures([['412,008', 'This month'], ['98,114', 'Last 7 days'], ['12,980', 'Today, so far']])}</div><p class="mt-3 text-xs text-muted-foreground">A part is what a vendor charges for; a long message is several. Days before the gateway kept daily counts are not included.</p>` })}
  </div>
  <div class="grid gap-3 xl:grid-cols-[2fr_1fr]">
    ${card({ title: 'MT usage', desc: 'Parts sent per day. Today is drawn paler because it is not over.', actions: segmented(['7 days', '30 days', '90 days'], '7 days'), body: `${barChart([[61200,58900,64100,70200,66800,59100,12980]], { hgt: 150, labels: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] })}<div class="mt-3">${table({ wrap: false, cols: ['Product', ['Messages', 'right'], ['MT parts', 'right'], ['Charged (AUD)', 'right']], rows: [[mono('au-mobile'), '371,004', '380,120', '17,105.40'], [mono('au-otp'), '22,110', '22,110', '884.40'], ['<b class="font-semibold">7 days</b>', '<b class="font-semibold">393,114</b>', '<b class="font-semibold">402,230</b>', '<b class="font-semibold">17,989.80</b>']] })}</div>` })}
    ${card({ title: 'Does the credit add up?', desc: 'Over the account’s lifetime.', body: `${figures([['0.0000', 'Unexplained', 'text-success'], ['310.2000', 'Reserved, not yet spent']])}<p class="mt-3 text-xs text-muted-foreground">Top-ups minus spending minus reserved equals the balance. Reconciled 14:30.</p>`, footer: btn('Reconcile again', { variant: 'outline', size: 'sm' }) })}
  </div>
  ${card({ title: 'Money in and out', desc: 'Recharges and transfers, newest first.', actions: searchInput('reference, note, type'), pad: false, body: table({ wrap: false, cls: 'striped', cols: ['When', ['Amount', 'right'], 'Type', 'Reference', 'State'], rows: [['3 Oct 09:12', '<span class="text-success">+5,000.0000</span>', pill('Top-up', 'neutral'), `${mono('receipt-1038')} <span class="text-xs text-muted-foreground">· bank transfer</span>`, pill('Settled', 'success')], ['1 Oct 00:00', '−4,120.0000', pill('Spend · Sep', 'neutral'), mono('statement-2026-09'), pill('Settled', 'success')], ['14 Sep 16:40', '<span class="text-success">+2,000.0000</span>', pill('Transfer in', 'neutral'), `${mono('from reseller-a')}`, pill('Settled', 'success')]], footer: pager('38 entries · page 1 of 2') }) })}`)) };

/* ───────────── 8 · Routing table ───────────── */
const ruleRow = (n, when, target, kind, flags, note, sent, on = true, locked = false) => `<li class="grid grid-cols-[28px_minmax(0,1fr)_auto] items-start gap-3 px-4 py-3 md:grid-cols-[28px_minmax(0,1fr)_auto_auto]">
  <span class="tnum pt-0.5 text-xs text-muted-foreground">${n}</span>
  <div class="min-w-0"><p class="text-sm">${when} <span class="text-muted-foreground">→</span> ${target} ${pill(kind, kind === 'table' ? 'info' : kind === 'preprocessor' ? 'primary' : 'outline')} ${flags.map(([t, tone]) => pill(t, tone)).join(' ')}</p>${note ? `<p class="mt-0.5 text-xs text-muted-foreground">${note}</p>` : ''}</div>
  <span class="tnum hidden pt-0.5 text-xs text-muted-foreground md:block">${sent} sent</span>
  <div class="flex items-center gap-1">${locked ? `<span class="text-xs text-muted-foreground">${icon('lock', 'h-3.5 w-3.5')}</span>` : sw(on)}${btn('', { variant: 'ghost', size: 'icon-sm', icon: locked ? 'eye' : 'pencil' })}<span class="hidden md:flex">${btn('', { variant: 'ghost', size: 'icon-sm', icon: 'chevron-up' })}${btn('', { variant: 'ghost', size: 'icon-sm', icon: 'chevron-down' })}</span></div></li>`;
const routingRail = (active) => `<nav class="hidden w-[260px] shrink-0 space-y-3 lg:block"><div class="rounded-lg border border-border bg-card p-1.5">${[['Start here', 'map'], ['Vendor groups · 2', 'users'], ['Test and check', 'flask-conical']].map(([l, i]) => `<a href="#" class="flex items-center gap-2 rounded-md px-2.5 py-1.5 text-sm hover:bg-muted">${icon(i, 'h-4 w-4 text-muted-foreground')}${l}</a>`).join('')}</div>
  <div class="rounded-lg border border-border bg-card"><div class="flex items-baseline gap-2 border-b border-border px-3.5 py-2.5 text-sm"><span class="font-medium">Tables</span><span class="text-xs text-muted-foreground">where messages go</span><span class="tnum ml-auto text-xs text-muted-foreground">4</span></div><div class="p-1.5">${[['default', 'Entry', 6], ['au_routes', '', 4], ['intl_lcr', 'LCR', 3], ['old_optus', 'Off', 2]].map(([n, c, k]) => `<a href="#" class="flex items-center gap-2 rounded-md px-2.5 py-1.5 font-mono text-sm ${n === active ? 'bg-muted font-semibold' : 'hover:bg-muted'}">${n}${c ? pill(c, c === 'Off' ? 'outline' : 'neutral') : ''}<span class="tnum ml-auto font-sans text-xs text-muted-foreground">${k}</span></a>`).join('')}<a href="#" class="flex items-center gap-2 rounded-md px-2.5 py-1.5 text-sm text-muted-foreground hover:bg-muted">${icon('plus', 'h-4 w-4')}New table</a></div></div></nav>`;
S['cp-routing-table'] = { title: 'Routing table', group: 'Operator panel', route: '/cp/routing/tables/[name]', render: () => cpShell('Vendors', `
  ${pageHeader('Routing', 'Which vendor each message goes to. Rules are tried top to bottom, and the first match wins.', `${btn('Test a message', { variant: 'outline', icon: 'flask-conical' })}${btn('Apply now', { variant: 'outline', icon: 'refresh-cw' })}${btn('New table', { icon: 'plus', cls: 'lg:hidden' })}`)}
  <div class="lg:hidden">${select(['default · entry', 'au_routes', 'intl_lcr', 'old_optus'], { value: 'au_routes' })}</div>
  <div class="flex gap-4">${routingRail('au_routes')}
    <div class="min-w-0 flex-1 space-y-4">
      ${card({ title: `<span class="flex flex-wrap items-center gap-2"><span class="font-mono">au_routes</span>${pill('In order', 'outline')}</span>`, desc: 'Reached from <a href="#" class="underline">default #2</a>. Australian mobile traffic by network.', actions: `${btn('Test', { variant: 'outline', size: 'sm' })}${btn('Table', { variant: 'outline', size: 'sm', icon: 'settings-2' })}`, pad: false, body: `
        <details class="border-y border-border bg-muted/40 px-4 py-2 text-xs"><summary class="cursor-pointer text-muted-foreground">2 system rules: delivery receipts, inbound from vendors</summary></details>
        <ol class="divide-y divide-border">
          ${ruleRow(1, 'destination starts with <b class="font-mono font-semibold">6141, 6142</b>', mono('telstra-a'), 'vendor', [], 'Telstra ranges', '61,204')}
          ${ruleRow(2, 'network is <b class="font-semibold">Optus AU</b>', mono('optus-grp'), 'group', [['Copy, keeps going', 'outline']], 'Weighted 70/30 with telstra-b', '22,910')}
          ${ruleRow(3, 'filter <b class="font-mono font-semibold">dnd_list</b> matches', mono('@dnd_check'), 'preprocessor', [['Unsaved', 'info']], 'Answers refuse or carry on', '0')}
          ${ruleRow(4, 'everything else', mono('telstra-a'), 'vendor', [], 'catch-all', '4,110', true)}
          ${ruleRow(5, 'delivery receipts', mono('smpp-1'), 'listener', [['System', 'outline']], '', '98,020', true, true)}
        </ol>
        <div class="flex flex-wrap items-center gap-3 border-t border-border px-4 py-3 text-xs text-muted-foreground">${btn('Add a rule', { variant: 'outline', size: 'sm', icon: 'plus' })}<span>Changes wait for Save.</span></div>` })}
      ${saveBar(1)}
    </div>
  </div>`) };
S['cp-routing-rule-dialog'] = { title: 'Routing · rule dialog', group: 'Operator panel', route: '/cp/routing/tables/[name] (dialog)', render: () => cpShell('Vendors', dialog({ title: 'Rule 3 in au_routes', desc: 'These changes wait for Save.', size: 'max-w-2xl', body: `<div class="divide-y divide-border rounded-lg border border-border">
  ${settingsRow({ label: 'Send to', help: 'A table, a vendor group, a vendor, a listener or a preprocessor.', control: `<div class="flex items-center gap-2">${select(['@dnd_check · preprocessor', 'telstra-a · vendor', 'optus-grp · group', 'intl_lcr · table'])}</div>` })}
  ${settingsRow({ label: 'When', control: segmented(['Every message', 'Only when…'], 'Only when…', { fill: true }) })}
  ${settingsRow({ label: 'Conditions', help: 'All must hold.', control: `<div class="space-y-2">
    <div class="flex items-center gap-2">${select(['Filter'], { cls: 'w-32' })}${select(['dnd_list', 'au_business_hours'], { cls: 'flex-1' })}${btn('', { variant: 'ghost', size: 'icon-sm', icon: 'x' })}</div>
    <div class="flex items-center gap-2">${select(['Product'], { cls: 'w-32' })}${select(['au-mobile', 'au-otp'], { cls: 'flex-1' })}${btn('', { variant: 'ghost', size: 'icon-sm', icon: 'x' })}</div>
    <div class="flex gap-3 text-xs">${link('+ Add a condition')}${link('Edit as conditions')}</div></div>` })}
  ${settingsRow({ label: 'After a match', control: segmented(['Stop here', 'Copy and keep going'], 'Stop here', { fill: true }) })}
  ${settingsRow({ label: 'Note', control: input('what this rule is for', { value: 'Answers refuse or carry on' }) })}
  ${settingsRow({ label: 'Active', control: `<div class="flex md:justify-end">${sw(true)}</div>` })}
  </div><p class="rounded-md bg-muted px-3 py-2 text-xs"><span class="font-semibold">Reads:</span> when filter dnd_list matches and product is au-mobile, send to @dnd_check and stop.</p>`, actions: `${btn('Remove rule', { variant: 'ghost-destructive', cls: 'mr-auto' })}${btn('Cancel', { variant: 'outline' })}${btn('Done')}` })) };

/* ───────────── 9 · Gateway settings ───────────── */
S['cp-gateway'] = { title: 'Gateway settings', group: 'Operator panel', route: '/cp/gateway', render: () => cpShell('Gateway', `
  ${pageHeader('Gateway', 'Settings that apply to every vendor, every listener and both ingresses. A vendor or listener with a value of its own keeps it.')}
  <div class="grid grid-cols-2 divide-border rounded-lg border border-border bg-card text-sm md:grid-cols-4 md:divide-x">${[['Running', '0.12.30', ''], ['Settings read from', 'database', ''], ['Checked', '14:32:08', ''], ['Saved, not yet running', '2', 'warning']].map(([k, v, t]) => `<div class="px-4 py-3 ${t ? 'bg-warning-soft/60' : ''}"><p class="text-2xs font-semibold uppercase tracking-wide text-muted-foreground">${k}</p><p class="tnum font-medium ${t ? 'text-warning' : ''}">${v}${t ? ` <a href="#" class="text-xs underline">show</a>` : ''}</p></div>`).join('')}</div>
  ${tabs(['Settings', 'In force'], 'Settings')}
  <div class="flex flex-wrap items-center gap-3">${searchInput('Find a setting by name or key', 'w-full sm:w-72')}${segmented(['All', 'Changed 1', 'Not yet running 2'], 'All')}</div>
  <div class="flex gap-4">
    <nav class="hidden w-[232px] shrink-0 lg:block"><div class="sticky top-20 rounded-lg border border-border bg-card p-1.5">${['Approval and pricing', 'REST API', 'Receipts and callbacks', 'Call records', 'Usage summaries', 'SMPP logins', 'Preprocessors', 'Diagnostics', 'Vendor and listener defaults'].map((l, i) => `<a href="#" class="flex items-center rounded-md px-2.5 py-1.5 text-sm ${i === 0 ? 'bg-muted font-semibold' : 'hover:bg-muted'}">${l}${i === 2 ? `<span class="tnum ml-auto text-2xs text-info">1</span>` : ''}</a>`).join('')}</div></nav>
    <div class="min-w-0 flex-1 space-y-4">
      ${settingsSection('Approval and pricing', 'Whether the gateway refuses what it cannot price or has not approved.', [
        settingsRow({ label: 'Refuse unrated', help: 'Reject a message no price rule covers instead of sending it for free.', key: 'smsg.refuseUnrated', chips: [['Set · default is off', 'neutral']], control: `<div class="flex md:justify-end">${sw(true)}</div>` }),
        settingsRow({ label: 'Sender ID checking', help: 'Platform-wide floor. An account may be stricter, never looser.', key: 'smsg.whitelist.mode', chips: [['Default', 'outline']], control: select(['Not checked', 'Report only', 'Enforce'], { value: 'Report only' }) }),
        settingsRow({ label: 'Variables per template', key: 'smsg.whitelist.max.variable', chips: [['pending', 'warning']], control: input('', { value: '6', mono: true }), tone: 'bg-warning-soft/40' }),
      ])}
      ${settingsSection('REST API', 'The HTTP ingress.', [
        settingsRow({ label: 'Base path', key: 'rest.basePath', control: input('', { value: '/secure', mono: true }) }),
        settingsRow({ label: 'Batch size', help: 'Messages accepted in one sendbatch call.', key: 'rest.batch.max', chips: [['Default · 1000', 'outline']], control: input('1000', { mono: true }) }),
      ])}
      ${settingsSection('Receipts and callbacks', '', [
        settingsRow({ label: 'Receipt callback', help: 'Where HTTP customers get delivery receipts unless the login sets its own.', key: 'rest.dlr.url', chips: [['Unsaved · was empty', 'info']], control: `<div>${input('', { value: 'https://hooks.acme.example/dlr', mono: true })}<div class="mt-1 flex gap-3 text-xs">${link('Undo')}${link('Reset to default')}</div></div>`, tone: 'bg-info-soft/40' }),
        settingsRow({ label: 'Callback retries', key: 'dlr.callback.retries', control: input('', { value: '5', mono: true }) }),
        settingsRow({ label: 'Receipt states forwarded', help: 'Which intermediate states reach the customer.', key: 'dlr.forward.states', control: `<div class="flex flex-wrap gap-1.5">${['DELIVRD', 'UNDELIV', 'EXPIRED', 'REJECTD'].map((s) => `<span class="inline-flex items-center gap-1 rounded-md border border-border px-2 py-0.5 font-mono text-xs">${s}<button class="text-muted-foreground" aria-label="Remove">${icon('x', 'h-3 w-3')}</button></span>`).join('')}${btn('Add', { variant: 'outline', size: 'sm' })}</div>` }),
      ])}
      ${settingsSection('Diagnostics', 'How much the gateway logs about its own decisions.', [`<div class="grid gap-2 p-4 sm:grid-cols-3">${[['Off', 'Errors only.'], ['Problems', 'Refusals, retries and vendor errors.'], ['Verbose', 'Every routing and pricing decision. Large logs.']].map(([t, d], i) => `<label class="cursor-pointer rounded-lg border p-3 ${i === 1 ? 'border-primary bg-muted' : 'border-border hover:bg-muted/50'}"><p class="text-sm font-medium">${t}</p><p class="text-xs text-muted-foreground">${d}</p></label>`).join('')}</div>`])}
      ${settingsSection('Vendor and listener defaults', 'Raw keys every vendor or listener inherits unless it sets its own.', [`<div class="p-4">${table({ wrap: false, cols: ['Key', 'Value', '', ''], rows: [[mono('outSms.default.window'), input('', { value: '50', mono: true, cls: 'max-w-[160px]' }), pill('in force', 'neutral'), btn('', { variant: 'ghost', size: 'icon-sm', icon: 'x' })], [mono('outSms.default.throttle'), input('', { value: '500', mono: true, cls: 'max-w-[160px]' }), pill('Saved, switched off', 'warning'), btn('', { variant: 'ghost', size: 'icon-sm', icon: 'x' })]] })}<div class="mt-3 flex flex-wrap gap-2">${select(['Choose a setting…', 'outSms.default.retries', 'outSms.default.enquireLink'], { cls: 'w-64' })}${input('value', { mono: true, cls: 'w-40' })}${btn('Add', { variant: 'outline' })}</div></div>`])}
      ${saveBar(1)}
    </div>
  </div>`) };

/* ───────────── 10 · Operator login ───────────── */
S['cp-login'] = { title: 'Operator login', group: 'Operator panel', route: '/cp/login', render: () => `<div class="flex min-h-[720px] items-center justify-center bg-background p-4 text-foreground">
  <div class="w-full max-w-[400px] space-y-6">
    <div class="flex items-center gap-2">${mark('h-6 w-6')}<span class="text-base font-semibold tracking-tight">FireFlo</span>${pill('Control panel', 'outline')}</div>
    <div class="rounded-lg border border-border bg-card p-6 sm:p-8">
      <h1 class="text-xl font-semibold tracking-tight">Welcome back</h1><p class="mt-1 text-sm text-muted-foreground">Sign in to your control panel.</p>
      <form class="mt-6 space-y-4" onsubmit="return false">
        ${field('Username', input('operator or you@example.com', { id: 'login-user' }))}
        ${field('Password', `<div class="relative">${input('', { type: 'password', value: 'password123', id: 'login-pass' })}<button type="button" class="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground" aria-label="Show password">${icon('eye')}</button></div>`)}
        <div>${checkbox('Remember me on this device', true)}<p class="ml-6 text-xs text-muted-foreground">Thirty days, on this browser only.</p></div>
        ${btn('Sign in', { cls: 'w-full' })}
        <div class="flex items-center gap-3 text-xs text-muted-foreground"><span class="h-px flex-1 bg-border"></span>or<span class="h-px flex-1 bg-border"></span></div>
        ${btn('Use a one-time link instead', { variant: 'outline', cls: 'w-full' })}
      </form>
    </div>
    <p class="text-center text-xs text-muted-foreground">Operator access. This is not a gateway messaging credential. · v0.12.30</p>
  </div></div>` };
</script>
