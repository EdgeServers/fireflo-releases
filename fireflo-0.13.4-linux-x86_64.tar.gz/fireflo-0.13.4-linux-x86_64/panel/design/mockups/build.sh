#!/usr/bin/env sh
# Concatenates the parts into one page. No bundler: the page loads Tailwind's play CDN and lucide.
cd "$(dirname "$0")" && cat src/00-head.html src/[1-8]*.js src/90-boot.html > index.html && echo "wrote $(wc -c < index.html) bytes to design/mockups/index.html"
