# Panel redesign mockups

Static HTML mockups of the control panel (`/cp`) and the customer portal, built with Tailwind utility
classes against the panel's own token names, so class strings can move into `components/ui` as-is.

- `src/00-head.html` — Tailwind play-CDN config and the token variables (light + dark).
- `src/10-lib.js` — the component library: button, pill, input, settings row, card, table, tabs, charts.
- `src/20-shell.js` — operator and MIS shells (sidebar, top bar).
- `src/30-cp.js`, `src/40-mis.js`, and later parts — one `S['id']` entry per screen.
- `src/90-boot.html` — the review chrome: screen picker, theme toggle, device frame.

Run `./build.sh` and open `index.html`. Not part of the Next.js build.

## Where the mockup primitives landed

| Mockup helper (`src/10-lib.js`) | Component |
| :--- | :--- |
| `settingsRow`, `settingsSection` | `components/ui/settings-row.tsx` (`SettingsRow`, `SettingsRows`), `components/ui/settings-section.tsx` |
| `statTile` | `components/ui/stat-tile.tsx` |
| `topbar`, `sidebar`, `cpShell`, `misShell` | `components/TopBar.tsx`, `components/Sidebar.tsx`, `components/DashboardShell.tsx`, `components/MisShell.tsx` |
| health pill, user menu, jump box | `components/HealthPill.tsx` (+ `lib/gateway-verdict.ts`), `components/UserMenu.tsx` (+ `components/ui/menu.tsx`), `components/JumpBox.tsx` (+ `lib/search.ts`, `app/api/control/search`) |
| tokens in `src/00-head.html` | `app/globals.css` |
