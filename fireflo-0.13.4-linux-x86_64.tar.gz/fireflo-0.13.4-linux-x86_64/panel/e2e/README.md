# FireFlo QA suite

A Playwright suite that executes the QA plan in `fireflo-sms-gateway/docs/26-qa-test-plan-0.12.xlsx`
(carried forward from the 0.11 plan: every 0.11 id is kept, 0.12 added 282 cases; the workbook is
built by `npm run qa-plan` from `scripts/qa-plan-0.12/`, see its README). Every one of the sheet's
test cases is a `test()` here, keyed by the sheet's id, one component (directory) per epic, and a run
writes its results back into a **dated copy** of the workbook — the committed workbook is never touched.

The suite is **self-contained**: global setup creates and seeds its own database, starts two
simulated vendors (EdgeSmsc), the gateway, the control panel and two SMTP sinks, and teardown stops
exactly the processes it started. Nothing it does reaches the dev gateway, the dev database or any
other service on the box.

## Running it

### Prerequisites

| Need | Why |
| --- | --- |
| Node 22+ | `scripts/e2e-*.ts` run with `--experimental-strip-types` |
| `npm install` in this repo | brings `@playwright/test`, `smpp` (ESME client + fake SMSC) and `exceljs` |
| `npx playwright install chromium` | once; the panel cases drive a real browser |
| PostgreSQL reachable from here, with a role that can `CREATE DATABASE` | setup creates the e2e database when absent |
| Java 17+ on `PATH` | EdgeSmsc (the simulated vendor) is a small Java program; also the gateway itself if you run the fast-jar |
| The gateway repo checked out beside this one and **built** | setup runs its CLI (`scripts/fireflo db migrate` / `bootstrap`), packages EdgeSmsc with `scripts/loadgen-package`, and starts the gateway from `E2E_GATEWAY_BIN` — the native runner (`fireflo-app/target/fireflo-app-<version>-runner`) or the fast-jar (`fireflo-app/target/quarkus-app/quarkus-run.jar`) |

Ports the rig binds by default, all configurable in `.env.e2e`: panel **3100**, gateway HTTP **8100**,
gateway ops **9100**, SMPP listeners **27800–27802**, EdgeSmsc A **28800/29800**, EdgeSmsc B
**28801/29801**, SMTP sinks **4465/4587**. Setup refuses to start on a port that is already in use
rather than testing whatever is there.

### Configure

```bash
cp e2e/.env.e2e.example e2e/.env.e2e
```

Then edit `E2E_DATABASE_URL` (the password, and the host if PostgreSQL is not local) and
`E2E_GATEWAY_BIN` (the artefact you built). **The database name must contain `e2e`** — setup
truncates every table in it on each run and refuses to start otherwise. Everything else in the
example is a working local default. `.env.e2e` is gitignored.

### Run

```bash
npm run e2e
```

That is the catalog check (every sheet id declared exactly once) followed by the whole suite. Expect
setup to take one to two minutes: migrate + bootstrap + seed the database, package and start
EdgeSmsc A/B, start the gateway and wait for its GraphQL `health` query to answer, build the panel once for the variant
cases, start the panel, warm it.

Narrower runs:

```bash
npm run e2e:epic -- @EP-05            # one epic — any tag works: @US-05.03, @SC-05.03.01, @P0, @negative, @load
npm run e2e:run -- --grep TC-17.01    # any Playwright filter; e2e:run skips the catalog check
npm run e2e:ui                        # the Playwright UI
npm run e2e:selftest                  # proves the reporter carries Pass / Fail / Blocked / Not run
npm run e2e:check                     # the catalog check alone; prints per-epic automated/todo/manual counts
npm run e2e:typecheck                 # tsc over the suite
```

Do **not** pass `--reporter` on the command line: it replaces the configured reporters and the
results file the write-back needs is then not written.

### Read the results

| Where | What |
| --- | --- |
| terminal | the Playwright `list` reporter as it runs |
| `e2e/.run/results.json` | one record per test case: id, Status, Actual result, error, tags |
| `e2e/report/html/` | Playwright's HTML report (`npx playwright show-report e2e/report/html`) |
| `e2e/test-results/` | traces and error contexts for failures |
| `e2e/.run/logs/` | every process the rig started: `gateway.log` (stdout), `smsg.log`, `smppserver.log`, `smppclient.log`, `auth-failed.log`, `edge-a.log`, `edge-b.log`, `panel.log`, `panel-<variant>.log` |
| `e2e/.run/state.json` | the PIDs setup recorded, the ports, whether the gateway came up |

### Write the results into the sheet

```bash
npm run e2e:writeback
```

Reads `e2e/.run/results.json` and the committed workbook, fills **Status / Actual result / Tester /
Date / Notes** on the TestCases sheet by header, and saves
`e2e/report/FireFlo-0.11-QA-Test-Plan-<yyyymmdd>.xlsx`. It re-opens the copy and checks the status
counts match the results file. Excel recalculates the Traceability sheet on open.
`-- --results other.json --out path.xlsx` overrides both paths.

Status mapping: passed → **Pass**; failed or timed out → **Fail**; skipped `manual`/`todo` → **Not
run**; skipped because the run lacked a capability, `fixme`, or interrupted → **Blocked**. The reason
lands in Notes; `tcx.note(...)` from inside a test lands in Actual result.

### Switches

| Variable | Effect |
| --- | --- |
| `E2E_START_GATEWAY=1` (default) | **mode A**: the suite starts EdgeSmsc A/B and the gateway itself |
| `E2E_START_GATEWAY=0` | **mode B**: test a gateway somebody else runs, at `E2E_GATEWAY_OPS_URL` / `E2E_GATEWAY_API_URL` / `E2E_SMPP_HOST`; cases needing EdgeSmsc, the log files (`E2E_GATEWAY_LOG` optional) or a restart come out Blocked, not missing |
| `E2E_PANEL_VARIANTS=1` (default) | build the panel once and start `next start` variants for the environment-matrix cases (missing database URLs, `AUTH_COOKIE_SECURE`, plain SMTP); `0` marks those Blocked |
| `E2E_PANEL_REBUILD=1` | force the `next build` even when one exists |
| `E2E_LOAD_SCALE=0.1` | scale for the load-shaped cases (1 = the sheet's message counts) |
| `E2E_KEEP_RIG=1` | teardown leaves the gateway, EdgeSmscs and panel running (PIDs in `e2e/.run/state.json`) |
| `E2E_REUSE_PANEL=1` | setup tests against a panel already on `E2E_PANEL_PORT` instead of refusing |
| `E2E_REPACKAGE_LOADGEN=1` | re-run `scripts/loadgen-package` even when `e2e/.run/loadgen` exists |
| `E2E_QA_WORKBOOK=path` | another workbook for the catalog and the write-back |
| `E2E_TESTER=name` | the Tester column in the write-back |

### Stopping a rig by hand

If a run is killed before teardown, the PIDs are in `e2e/.run/state.json`. Stop those, by PID —
never with a pattern kill: other SMPP services may live on this box.

## Layout — one component per epic

```
e2e/epics/EP-17-operator-panel-sign-in-and-access-control/
    US-17.01-operator-sign-in.spec.ts          one spec per story
    US-17.02-route-guards-….spec.ts            test.describe("SC-…") per scenario
    …                                          test(...tc("TC-…", "title"), body) per case
e2e/fixtures/        shared by every epic: env, state, process (tracked child processes), db, seed,
                     auth (operator + portal sessions), gateway (ops / REST / CLI), gateway-rig
                     (starts the gateway + vendors), smpp (ESME + fake SMSC), edgesmsc (the
                     controllable vendor), sinks (SMTP + webhook), trace (gateway logs), panel-variant
e2e/support/         tc.ts — the sheet contract; tags.ts; wait.ts; panel-logs.ts;
                     flows/ — journeys reused across epics (operator, portal, accounts, gateway, submit)
                     tc-catalog.json — generated from the workbook
e2e/reporters/       tc-results.ts → e2e/.run/results.json
e2e/selftest/        the anti-vacuity fakes the selftest asserts on
scripts/e2e-*.ts     catalog, catalog-check, scaffold, writeback, selftest
```

Projects in `playwright.config.ts`: `panel-operator` (EP-17..21, 4 workers, signed-in operator
storage state), `panel-portal` (EP-22..23, 2 workers), `gateway` (EP-01..16 and 24, 1 worker — the
vendors and `app_config` are process-global), `selftest`. Retries are 0 on purpose: a retry hides the
flakiness the sheet must record.

## The contract with the sheet

`tc(id, title)` answers the `[title, details]` pair `test()` takes. The id must be in
`tc-catalog.json` (regenerate with `npm run e2e:catalog` when the workbook changes) and may be
declared once; `npm run e2e:check` lists the suite and asserts every sheet id is declared exactly
once with the sheet's title. The kinds:

| declaration | sheet Status | when |
| --- | --- | --- |
| `tc(id, title)` + body | Pass / Fail | automated |
| `tc(id, title, { requires: ["gateway", "edgesmsc", "trace", "restart", "cli", "variants", "smtp"] })` | Blocked (with the reason) | the run lacks that capability |
| `tc.manual(id, title, reason)` | Not run — `manual: …` | needs a host, fail2ban, the licence server… |
| `tc.fixme(id, title, reason)` | Blocked | automated but skipped on our side |
| `tc.todo(id, title)` | Not run — `todo` | not automated yet |

Tags carried on every test: `@EP-nn @US-nn.ss @SC-nn.ss.cc @P0..P3 @positive|@negative`, plus
`@load`, `@slow`, `@serial` where a case declares them.

## Adding or changing cases

1. Change the workbook, then `npm run e2e:catalog` and commit the regenerated `tc-catalog.json`.
2. `npm run e2e:scaffold` writes a `tc.todo` for any new id into the right story file (it never
   overwrites an existing file).
3. Replace the todo with `tc(...)` + body, or `tc.manual(...)` with the reason.
4. `npm run e2e:check` — the suite cannot drift from the sheet silently.

Reuse before writing: the flows in `support/flows/` and the fixtures are where a journey used by two
epics belongs. A test body should read as the sheet's Steps and Expected, with the observed values
put into `tcx.note()`.

## What the rig is

Mode A setup, in order: the `e2e` database is created if absent → migrated with the gateway's CLI →
truncated → `bootstrap --port 27800` → the baseline is seeded (accounts `qa-acct-a/b`, `qa-portal-a`,
reseller `qa-reseller-r` with child `qa-child-c1`; SMPP and HTTP logins; product `standard`; AUD,
price 0.0100, vendor cost 0.0050; balances) → vendors `qa-sim1`/`qa-sim2` (EdgeSmsc A/B), listeners
`smpp`/`smpp2` (the second with a PROXY-protocol port), a `qa-failover` group A→B and the MESSAGE
table are written → the gateway is put inside a licence setup window (a fresh install adopts no
configuration otherwise; EP-14 overrides this deliberately) → EdgeSmsc A/B are started and set to
answer every submit with DELIVRD → the gateway starts in database mode with a 2-second config poll →
the panel builds once (variants) and starts under `next dev` on `localhost:3100` → SMTP sinks → the
operator's storage state is minted and the panel warmed.

EdgeSmsc is the gateway repo's own controllable SMSC (`fireflo-core/src/test/java/loadgen/EdgeSmsc`):
a loopback control port takes `delay`, `refuse`, `hang`, `drop`, `binds`, `dlr <STATE> <err> <ms>`,
`stats`, `reset`, and the suite can SIGKILL it for the channel-death cases because it spawned it.
The Node `smpp` fake SMSC (`fixtures/smpp.ts`) is the vendor that can inject MOs and capture the
exact PDU the gateway sent.

## Things learned the hard way, so they stay learned

- A fresh gateway install has **no licence and no setup window**; `DbConfigPoller` then refuses every
  configuration change after the first load. Every case that writes `app_config` or `app_credential`
  and expects the gateway to notice needs the window setup seeds (`seedSetupWindow`).
- The panel's control routes answer an envelope: the health snapshot is under `data`, not at the top level. The gateway itself answers only `POST /graphql` on the management port (0.13+); `/ops/*` is gone.
- A freshly spawned EdgeSmsc issues **no** receipts until told `dlr DELIVRD 000 <ms>`; setup does that.
- `next dev` serves its client bundles only to its own origin: address the panel as `localhost`, not
  `127.0.0.1`, or pages render and never hydrate.
- `next dev` and `next start` both load the repo's `.env.local` for any variable the process does not
  carry. `baselinePanelEnv()` therefore names every variable the panel reads, and "unset" is `""`.
- Chromium treats loopback as a secure context: a `Secure` cookie *is* sent over `http://127.0.0.1`.
  The case that proves it is not sent over plain http reaches the panel by the host's LAN address.
- Inside a test, `request.newContext()` inherits the project's storage state — use
  `freshRequestContext()` for a jar that must start empty.
- The portal's rate limiters are in-process and per address/origin for 15 minutes; the rate-limit
  cases run on a panel process of their own, and every link-request case uses an account of its own.
- SMPP `system_id` is at most 15 characters and a password at most 8; seeded names are short.
- `--reporter` on the CLI replaces the config's reporters; `results.json` is then never written.
- Spawned processes are detached process groups writing straight to their log files; teardown sweeps
  the whole group through `/proc`, so an `npx` wrapper exiting early cannot orphan `next-server`.

## Status

168 of 643 cases are coded (159 automated, 9 manual with a reason); the rest are scaffold todos that
report as Not run. Coded: EP-01, EP-02, EP-17, EP-23 in full; EP-03, EP-05, EP-18, EP-20, EP-22 in
part. `npm run e2e:check` prints the live per-epic count.
