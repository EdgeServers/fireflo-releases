import { MisStatementClient } from "@/components/MisStatementClient";

/**
 * What this customer has sent, and what it came to.
 *
 * <p>A shell only. The period picker refetches, so a server component would mean a full navigation
 * per click — the same reasoning the overview page gives.
 *
 * <p>The {@code PageHeader} lives inside the client component rather than here, which is the one
 * page in the portal where it does. The month picker belongs in the header's `actions` slot, and
 * the picker is the thing that refetches — rendering the header above the boundary would mean
 * either lifting the month into a second client component or a navigation per click.
 */
export const metadata = { title: "Statement" };

export default function StatementPage() {
  return <MisStatementClient />;
}
