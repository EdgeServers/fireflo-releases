import { MisApiDocsClient } from "@/components/MisApiDocsClient";
import { platformExampleMsisdn } from "@/lib/platform-example-number";

export const metadata = { title: "REST API" };

export default async function MisApiDocsPage() {
  //see the playground page: the same value, resolved the same way, so the two surfaces cannot show
  //a customer two different numbers to copy
  const exampleTo = await platformExampleMsisdn().catch(() => null);
  return <MisApiDocsClient exampleTo={exampleTo} />;
}
