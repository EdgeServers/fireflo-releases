import { MisMessagesClient } from "@/components/MisMessagesClient";

export const metadata = { title: "Messages" };

export default function MisMessagesPage() {
  return <MisMessagesClient />;
}
