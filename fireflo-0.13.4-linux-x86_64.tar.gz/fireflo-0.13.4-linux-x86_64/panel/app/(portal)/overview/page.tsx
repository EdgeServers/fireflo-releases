import { MisOverviewClient } from "@/components/MisOverviewClient";

/**
 * Where a customer lands.
 *
 * <p>Not the root: `/` is the public sign-in and the only public page this application has. A
 * signed-in customer is sent here by `MisVerify`, and the nav puts it above every group.
 *
 * <p>A shell only. Everything is fetched client-side from `/api/mis/overview`, because the range
 * buttons refetch and a server component would mean a full navigation per click.
 */
export const metadata = { title: "Overview" };

export default function OverviewPage() {
  return <MisOverviewClient />;
}
