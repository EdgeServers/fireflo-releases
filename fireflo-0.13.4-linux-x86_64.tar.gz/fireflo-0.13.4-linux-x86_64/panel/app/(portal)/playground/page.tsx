import { MisPlaygroundClient } from "@/components/MisPlaygroundClient";
import { platformExampleMsisdn } from "@/lib/platform-example-number";

export const metadata = { title: "API playground" };

export default async function MisPlaygroundPage() {
  //resolved here rather than in the client, because reading it needs the config database. Null when
  //unset or unreadable, and the catalogue's own example stands
  const exampleTo = await platformExampleMsisdn().catch(() => null);
  return <MisPlaygroundClient exampleTo={exampleTo} />;
}
