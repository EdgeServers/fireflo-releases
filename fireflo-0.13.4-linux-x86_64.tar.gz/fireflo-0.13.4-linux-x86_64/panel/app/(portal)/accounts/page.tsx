import { notFound } from "next/navigation";
import { PageHeader } from "@/components/ui/page-header";
import { AccountsCatalogueClient } from "@/components/AccountsCatalogueClient";
import { NotCustomerError, requireReseller } from "@/lib/require-customer";
import { portalBrand } from "@/lib/brand";

/**
 * The accounts this reseller holds, in the operator panel's own account table.
 *
 * <p>The same component `/cp/accounts` renders — see `lib/panel-surface.ts` for the mechanism and
 * for why sharing it beat building a second one. What differs is decided by the surface the portal
 * layout declares: the API it calls, where its links go, and the two columns it does not offer.
 *
 * <p><strong>A non-reseller gets a 404 rather than an empty table.</strong> An empty page reads as
 * "you have no customers yet" and invites somebody to look for the button that adds one; the
 * `notFound` says the page is not theirs, which is true, and matches what every route beneath it
 * answers. The nav does not offer the link either, so reaching this at all means typing the URL.
 */
export function generateMetadata() {
  return { title: `Accounts — ${portalBrand()}` };
}

export default async function PortalAccountsPage() {
  try {
    await requireReseller();
  } catch (err) {
    if (err instanceof NotCustomerError) {
      notFound();
    }
    throw err;
  }
  return (
    <>
      <PageHeader
        title="Accounts"
        description="The customers you hold. Create one, give it a login, and it can send."
      />
      <AccountsCatalogueClient />
    </>
  );
}
