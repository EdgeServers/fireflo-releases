import { MisStatementClient } from "@/components/MisStatementClient";

/**
 * What one of this reseller's accounts was charged for a month.
 *
 * <p><strong>Deliberately not the operator's `StatementClient`</strong>, which is behind the same
 * slug on `/cp`. That one closes a period — an irreversible write that mints an invoice — and
 * invoicing belongs to whoever issues it, not to a customer reading a total.
 *
 * <p>So this is the portal's own statement, the same read-only view a customer sees of its own,
 * pointed at the child. Sell-side only: `statementSummary` selects counts, outcomes and `price`, and
 * has no cost, margin or vendor column at all — which is why it can be shared rather than
 * duplicated.
 */
export default async function PortalAccountStatementPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return <MisStatementClient account={decodeURIComponent(id)} />;
}
