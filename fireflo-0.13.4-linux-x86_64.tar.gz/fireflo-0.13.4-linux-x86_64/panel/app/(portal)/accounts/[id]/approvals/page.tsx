import { MisRegistrationsClient } from "@/components/MisRegistrationsClient";

/**
 * The sender IDs and wording this account may send, and how to ask for more.
 *
 * <p><strong>Deliberately not the operator's `AccountWhitelistSection`</strong>, which is behind the
 * same slug on `/cp`. That component's verbs are approve and reject, and the whole point of the
 * approval flow is that the party sending is not the party deciding — a reseller approving its own
 * customer's sender ID would make the control a suggestion.
 *
 * <p>So this is the portal's own list, scoped to the one account. A reseller can see what is
 * approved, what is waiting and what was refused, and can request more on the customer's behalf;
 * every request lands PENDING for an operator, exactly as the customer's own would.
 *
 * <p>Two of them for one tab, because sender IDs and wording are a pair and are read together —
 * the same reason the operator's section renders two cards from one call.
 */
export default async function PortalAccountApprovalsPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const account = decodeURIComponent(id);
  return (
    <div className="space-y-5">
      <MisRegistrationsClient kind="senders" account={account} />
      <MisRegistrationsClient kind="templates" account={account} />
    </div>
  );
}
