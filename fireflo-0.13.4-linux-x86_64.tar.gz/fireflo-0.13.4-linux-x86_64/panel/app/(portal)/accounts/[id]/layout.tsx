import { notFound } from "next/navigation";
import { AccountShell } from "@/components/AccountShell";
import { assertInScope, NotCustomerError, requireReseller } from "@/lib/require-customer";

/**
 * The frame every one of this reseller's account tabs sits in.
 *
 * <p>A layout rather than a component each page renders, matching the operator's, so the header and
 * the tab bar survive a navigation between tabs — React keeps the subtree mounted, which is why
 * moving between them does not re-request the catalogue.
 *
 * <p><strong>The gate is here as well as in every route beneath it</strong>, and both are needed for
 * different reasons. This one stops the page rendering at all, so a reseller cannot land on a
 * stranger's account id and see a shell with their name at the top of it while the requests inside
 * quietly 404. The API routes repeat the check because a layout gate stops a page rendering and does
 * nothing about a fetch.
 *
 * <p>`assertInScope` answers the same `NotCustomerError` for "no such account" and "not yours", so
 * this cannot be used to discover which ids exist — and it writes the `cross_account_access` audit
 * row, which is the record of one customer's identity reaching another's.
 */
export default async function PortalAccountLayout({
  params,
  children,
}: {
  params: Promise<{ id: string }>;
  children: React.ReactNode;
}) {
  const id = decodeURIComponent((await params).id);
  try {
    await assertInScope(await requireReseller(), id);
  } catch (err) {
    if (err instanceof NotCustomerError) {
      notFound();
    }
    throw err;
  }
  return <AccountShell id={id}>{children}</AccountShell>;
}
