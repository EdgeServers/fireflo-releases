import { AccountOverviewClient } from "@/components/AccountOverviewClient";

/**
 * What one of this reseller's accounts has been doing.
 *
 * <p>The operator panel's own component. Three things inside it are gated off on this surface, and
 * each is a different disclosure rather than a styling choice: the traffic table's **Cost** column
 * (what the operator paid a vendor, so billed minus cost is the margin), the "Where it went" card
 * (which carrier carried it), and `DeliveryCheck` (which diagnoses the routing table and offers to
 * write a fix to it). The portal's own `/api/mis/accounts` route does not send the cost either, so
 * the gate in the component is the second lock rather than the only one.
 */
export default async function PortalAccountOverviewPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return <AccountOverviewClient id={decodeURIComponent(id)} />;
}
