import { AccountLoginsClient } from "@/components/AccountLoginsClient";

/**
 * Who may connect as this account, and the form that creates one.
 *
 * <p>The operator panel's own component. What it does not offer here is the product and the
 * allowed-product list — that is the price, and `lib/mis-logins.ts` writes both columns NULL
 * whatever a request asks for.
 */
export default async function PortalAccountLoginsPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return <AccountLoginsClient id={decodeURIComponent(id)} />;
}
