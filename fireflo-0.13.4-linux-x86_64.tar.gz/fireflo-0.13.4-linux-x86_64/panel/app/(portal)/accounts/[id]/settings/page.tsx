import { AccountSettingsClient } from "@/components/AccountSettingsClient";

/**
 * The landing tab for one of a reseller's accounts: its name, notes and sign-in address.
 *
 * <p>The operator panel's own component. The three fields it does not offer here — listing,
 * reselling and the parent — are hidden by `allowHierarchy`, which the client derives from the
 * surface; the write path pins all three regardless. See `lib/panel-surface.ts`.
 *
 * <p>The scope check is in the layout above, which runs for every tab rather than being repeated in
 * each of them.
 */
export default async function PortalAccountSettingsPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return <AccountSettingsClient id={decodeURIComponent(id)} />;
}
