import { MisPasswordClient } from "@/components/MisPasswordClient";

/** The signed-in customer's own portal password: set one, or change it. */
export const metadata = { title: "Password" };

export default function PasswordPage() {
  return <MisPasswordClient />;
}
