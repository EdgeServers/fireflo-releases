import { MisRegistrationsClient } from "@/components/MisRegistrationsClient";

export const metadata = { title: "Sender IDs" };

export default function MisSendersPage() {
  return <MisRegistrationsClient kind="senders" />;
}
