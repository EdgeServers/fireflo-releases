import { MisRegistrationsClient } from "@/components/MisRegistrationsClient";

export const metadata = { title: "Templates" };

export default function MisTemplatesPage() {
  return <MisRegistrationsClient kind="templates" />;
}
