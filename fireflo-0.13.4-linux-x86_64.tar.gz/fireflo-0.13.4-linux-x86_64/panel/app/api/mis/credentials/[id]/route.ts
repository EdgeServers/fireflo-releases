import { NextRequest, NextResponse } from "next/server";
import { notFoundOrThrow, rowId } from "@/lib/mis-route";
import { assertInScope, requireReseller } from "@/lib/require-customer";
import { recordCustomerAccess } from "@/lib/customer-access-log";
import { requestContext } from "@/lib/request-context";
import { listChildLogins, POLL_SECONDS, setLoginEnabled } from "@/lib/mis-logins";
import { listChildren } from "@/lib/mis-accounts";

/**
 * PATCH /api/mis/credentials/{id} — switch one of this reseller's child logins on or off.
 *
 * <p>Mirrors the operator route's path and verb so `useCredentials.setEnabled` swaps only its base —
 * see `lib/panel-surface.ts`.
 *
 * <p><strong>There is deliberately no PUT and no DELETE here</strong>, though the operator route has
 * both and the shared hook will call them if a component offers the control. Editing a whole login
 * would mean reaching `account_id`, `product` and `allowed_products` — the pricing boundary — and
 * deleting one destroys the only record that a customer's traffic was ever attributed to it. A
 * reseller disables and creates instead, which is reversible and leaves the history intact. An
 * unrouted verb answers 405 from Next.js; the components that would call them are gated off on this
 * surface, so it should never be reached.
 *
 * <p><strong>An id is a number somebody can guess</strong>, so it is resolved against this
 * reseller's own accounts before anything is written, and again inside the transaction with
 * `FOR UPDATE`. A missing login and somebody else's both answer 404 and deliberately look the same
 * from outside.
 */
type Params = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, { params }: Params): Promise<NextResponse> {
  let session;
  try {
    session = await requireReseller();
  } catch (err) {
    return notFoundOrThrow(err);
  }

  const id = rowId((await params).id);
  if (id === null) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  let body: { enabled?: unknown };
  try {
    body = (await req.json()) as typeof body;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  if (typeof body.enabled !== "boolean") {
    return NextResponse.json({ error: "Say whether the login is enabled." }, { status: 400 });
  }

  //which account this login bills to is read from the login itself and then proved to be one of
  //this reseller's -- the id from the path never names the account, so there is nothing in the
  //request that could widen the scope.
  //
  //The candidate set is the CHILDREN only, deliberately not `scopeFor`: a reseller's own login is
  //not disableable here, because switching off your own last login is a way to lock yourself out of
  //your own traffic with no way back in. It falls out as a 404 rather than needing its own branch
  const children = (await listChildren(session.accountId)).map((a) => a.id);
  const found = (await listChildLogins(children)).find((c) => c.id === id);
  if (!found?.billingAccount) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  try {
    //already implied by the query above; run anyway, because it is what writes the
    //cross_account_access row and that record is the point rather than a side effect
    await assertInScope(session, found.billingAccount);
  } catch (err) {
    return notFoundOrThrow(err);
  }

  const result = await setLoginEnabled(found.billingAccount, id, body.enabled);
  if (!result.ok) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const ctx = await requestContext();
  void recordCustomerAccess({
    event: "child_login_toggled",
    accountId: session.accountId,
    ip: ctx.ip,
    userAgent: ctx.userAgent,
    detail: {
      child: found.billingAccount,
      login: result.systemId,
      enabled: result.enabled,
      dropped: result.dropped,
    },
  });

  return NextResponse.json({
    data: {
      id,
      enabled: result.enabled,
      //the live half, reported rather than assumed. `enabled = false` is a statement about future
      //connections only, so "switched off" and "has stopped sending" are different claims
      disconnected: result.dropped,
      problem: result.problem,
      propagationSeconds: POLL_SECONDS,
    },
  });
}
