import { NextResponse } from "next/server";
import { notFoundOrThrow } from "@/lib/mis-route";
import { requireCustomer } from "@/lib/require-customer";
import { gatewayApiUrl, listPlaygroundLogins } from "@/lib/playground";
import { listRotatableLogins } from "@/lib/mis-credentials";

/**
 * The logins this customer can send with, and where to send.
 *
 * <p>Feeds the playground's connection strip and the reference's examples. Everything is derived
 * from the session — nothing in the request names an account, so there is nothing to check.
 *
 * <p>No secret is in the projection. The customer supplies the password themselves; this only says
 * which logins exist and which of them restrict the addresses they may be used from.
 */
export async function GET(): Promise<NextResponse> {
  try {
    const session = await requireCustomer();
    const [logins, rotatable] = await Promise.all([
      listPlaygroundLogins(session.accountId),
      listRotatableLogins(session.accountId),
    ]);
    return NextResponse.json({
      data: {
        logins,
        //a wider set than `logins`: it includes the api-key-keyed credentials the playground
        //excludes, because those are exactly the ones somebody wants to rotate. Labelled by system
        //id, and neither secret is in the projection
        rotatable,
        //null when the deployment has not been told where the messaging port is. The pages say so
        //rather than building examples against a URL that would not work
        baseUrl: gatewayApiUrl(),
      },
    });
  } catch (err) {
    return notFoundOrThrow(err);
  }
}
