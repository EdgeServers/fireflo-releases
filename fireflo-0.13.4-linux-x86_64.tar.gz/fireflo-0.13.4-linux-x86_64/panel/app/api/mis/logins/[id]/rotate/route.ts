import { NextRequest, NextResponse } from "next/server";
import { notFoundOrThrow } from "@/lib/mis-route";
import { requireCustomer } from "@/lib/require-customer";
import { recordCustomerAccess } from "@/lib/customer-access-log";
import { requestContext } from "@/lib/request-context";
import { rotateSecret, type RotatableSecret } from "@/lib/mis-credentials";

/**
 * Replaces one secret on one of this customer's logins, and returns it exactly once.
 *
 * <p><strong>The id comes from the path, so it is resolved against the session's account before
 * anything is written</strong> — the rule `lib/require-customer.ts` exists for, and the reason
 * `resolveRotatable` answers 404 rather than 403: naming another customer's credential must not
 * confirm that it exists.
 *
 * <p>The new value is in the response body and nowhere else. It is not logged, not stored anywhere
 * the panel can read it back, and not put in the URL — a secret in a path is a secret in an access
 * log, a browser history and a referrer header.
 *
 * <p>The caller is told the propagation window because it is the thing that will otherwise generate
 * a support call: the gateway reloads credentials on a poll, so the OLD secret keeps working for up
 * to that long and the NEW one does not work yet.
 */

/** Matches `smsg.config.db.poll.seconds`' default. Said in words, not computed — see below. */
const POLL_SECONDS = 30;

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
): Promise<NextResponse> {
  try {
    const session = await requireCustomer();
    const { id } = await context.params;

    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
    }
    const secret = (body as { secret?: unknown })?.secret;
    if (secret !== "password" && secret !== "apiKey") {
      return NextResponse.json(
        { error: "Name which secret to rotate: password or apiKey." },
        { status: 400 }
      );
    }

    const result = await rotateSecret(session.accountId, id, secret as RotatableSecret);
    if (!result.ok) {
      return NextResponse.json(
        { error: result.problem },
        { status: "notFound" in result ? 404 : 400 }
      );
    }

    const ctx = await requestContext();
    //what was rotated and on which login. Never the value, old or new -- a log that carried it
    //would be a better target than the table the secret lives in
    void recordCustomerAccess({
      event: "credential_rotated",
      accountId: session.accountId,
      ip: ctx.ip,
      userAgent: ctx.userAgent,
      detail: { secret, login: result.login },
    });

    return NextResponse.json({
      data: {
        secret: result.secret,
        login: result.login,
        changesUsername: result.changesUsername,
        //stated rather than left to be discovered. The gateway polls for credential changes, so
        //there is a window where only the OLD value works -- a customer who switches immediately
        //gets 401s and reasonably concludes the rotation failed
        propagationSeconds: POLL_SECONDS,
      },
    });
  } catch (err) {
    return notFoundOrThrow(err);
  }
}
