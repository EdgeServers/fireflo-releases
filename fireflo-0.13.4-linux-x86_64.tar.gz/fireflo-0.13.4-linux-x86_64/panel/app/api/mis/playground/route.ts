import { NextRequest, NextResponse } from "next/server";
import { notFoundOrThrow } from "@/lib/mis-route";
import { requireCustomer } from "@/lib/require-customer";
import { recordCustomerAccess } from "@/lib/customer-access-log";
import { requestContext } from "@/lib/request-context";
import { allowAttempt, gatewayApiUrl, resolveLogin } from "@/lib/playground";
import { ENDPOINTS, type EndpointId } from "@/lib/api-catalogue";

/**
 * Makes one real API call on the customer's behalf, and returns exactly what the gateway said.
 *
 * <p>A proxy rather than a browser fetch for two reasons. The gateway is not necessarily reachable
 * from the customer's network — it usually is not — and a browser call would put the password in a
 * cross-origin request the customer's own extensions can read. Here it exists for the length of one
 * fetch.
 *
 * <h2>What must not change</h2>
 *
 * <ul>
 *   <li><strong>The login is checked against the session's account</strong> before anything else.
 *       Without it this route tests passwords against every login on the platform.</li>
 *   <li><strong>The password is never written anywhere.</strong> Not to a log line, not into an
 *       error message, not to the customer access log. It is read from the body, turned into one
 *       header, and dropped.</li>
 *   <li><strong>The gateway's answer is returned verbatim</strong> — status and body. A 403 saying
 *       which sender ID was refused is the reason someone opened this page; rewording it would take
 *       away the only thing it was for.</li>
 * </ul>
 */

/** Long enough for a slow carrier ack, short enough that a hung gateway does not hold the route. */
const TIMEOUT_MS = 20_000;

export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    const session = await requireCustomer();

    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
    }
    const input = parse(body);
    if (typeof input === "string") {
      return NextResponse.json({ error: input }, { status: 400 });
    }

    const base = gatewayApiUrl();
    if (!base) {
      return NextResponse.json(
        {
          error: "This panel has not been told where the messaging API is. Ask your operator to set "
            + "GATEWAY_API_URL.",
        },
        { status: 503 }
      );
    }

    const endpoint = ENDPOINTS.find((e) => e.id === input.endpoint);
    if (!endpoint) {
      return NextResponse.json({ error: "No such endpoint." }, { status: 400 });
    }

    //the check the whole route rests on. A login that is not this account's is a 404, the same
    //answer an unauthenticated caller gets, so naming one cannot reveal that it exists
    const login = endpoint.secured ? await resolveLogin(session.accountId, input.login) : null;
    if (endpoint.secured && !login) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }

    if (!allowAttempt(session.accountId)) {
      return NextResponse.json(
        { error: "Too many playground calls in the last minute. Wait, then try again." },
        { status: 429 }
      );
    }

    const context = await requestContext();
    //what happened, never what was sent: a body here would be a customer's message content and a
    //destination number in an operator-readable table
    void recordCustomerAccess({
      event: "playground_call",
      accountId: session.accountId,
      ip: context.ip,
      userAgent: context.userAgent,
      detail: { endpoint: endpoint.id, login: login?.lookupKey ?? null },
    });

    const started = Date.now();
    const result = await call(base, endpoint.method, endpoint.path, input, login?.lookupKey);
    const ms = Date.now() - started;

    if (result.kind === "unreachable") {
      return NextResponse.json({
        data: { unreachable: true, detail: result.detail, ms },
      });
    }

    return NextResponse.json({
      data: {
        status: result.status,
        ms,
        body: result.body,
        //the failure a customer cannot diagnose from the response, because the gateway's wording
        //for it is the same as for a wrong password. Only this side knows the login has an allow
        //list and that the request came from here rather than from them
        ipHint: result.status === 403 && login?.ipRestricted
          ? "This login only accepts requests from specific addresses, and the playground calls from "
            + "this panel's address rather than yours. Your own integration may work where this does "
            + "not — try it from your own server, or ask your operator to allow this panel."
          : null,
      },
    });
  } catch (err) {
    return notFoundOrThrow(err);
  }
}

interface Input {
  endpoint: EndpointId;
  login: string;
  password: string;
  /** Body for a POST, query parameters for a GET. Passed to the gateway unaltered. */
  payload: Record<string, unknown>;
}

/**
 * An unknown body into an {@link Input}, or the reason it is not one.
 *
 * <p>Hand-written and naming the field, matching the convention the operator routes established.
 * Deliberately does **not** validate the payload: the gateway's own 400s are better than anything
 * repeated here, and reproducing them would create a second parser to keep in step with the first.
 */
function parse(body: unknown): Input | string {
  if (!body || typeof body !== "object") {
    return "Expected an object.";
  }
  const raw = body as Record<string, unknown>;
  if (typeof raw.endpoint !== "string") {
    return "Name an endpoint.";
  }
  if (raw.payload !== undefined && (typeof raw.payload !== "object" || raw.payload === null)) {
    return "The payload must be an object.";
  }
  return {
    endpoint: raw.endpoint as EndpointId,
    login: typeof raw.login === "string" ? raw.login : "",
    password: typeof raw.password === "string" ? raw.password : "",
    payload: (raw.payload as Record<string, unknown>) ?? {},
  };
}

type CallResult =
  | { kind: "answered"; status: number; body: string }
  | { kind: "unreachable"; detail: string };

async function call(
  base: string,
  method: "GET" | "POST",
  path: string,
  input: Input,
  login: string | undefined
): Promise<CallResult> {
  const query = method === "GET" ? queryString(input.payload) : "";
  const headers: Record<string, string> = { Accept: "application/json" };
  if (login) {
    //the password's entire lifetime, and the only place it appears
    headers.Authorization = "Basic " + Buffer.from(`${login}:${input.password}`).toString("base64");
  }
  if (method === "POST") {
    headers["Content-Type"] = "application/json";
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(base + path + query, {
      method,
      headers,
      body: method === "POST" ? JSON.stringify(input.payload) : undefined,
      signal: controller.signal,
      cache: "no-store",
      //a redirect from a messaging API is not a thing that should be followed with a password
      //attached, and following one would send the credential somewhere nobody configured
      redirect: "manual",
    });
    return { kind: "answered", status: res.status, body: await res.text() };
  } catch (err) {
    //the message, never the cause chain: a fetch failure can carry the request in it, and the
    //request carries the header
    return {
      kind: "unreachable",
      detail: err instanceof Error && err.name === "AbortError"
        ? `The gateway did not answer within ${TIMEOUT_MS / 1000} seconds.`
        : "The gateway could not be reached from this panel.",
    };
  } finally {
    clearTimeout(timer);
  }
}

function queryString(payload: Record<string, unknown>): string {
  const parts = Object.entries(payload)
    .filter(([, v]) => v !== undefined && v !== null && v !== "")
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`);
  return parts.length ? `?${parts.join("&")}` : "";
}
