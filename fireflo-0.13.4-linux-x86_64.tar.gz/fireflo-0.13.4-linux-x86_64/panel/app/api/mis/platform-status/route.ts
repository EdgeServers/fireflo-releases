import { NextResponse } from "next/server";
import { gqlData } from "@/lib/gateway-graphql";
import { LICENSE } from "@/lib/gateway-queries";
import { NotCustomerError, requireCustomer } from "@/lib/require-customer";

/**
 * One boolean, for a customer: are changes on this platform being applied right now.
 *
 * <h2>Why this is not `/api/control/license` with a customer session</h2>
 *
 * <p>Because a customer must not learn what that route returns. The licence state names the
 * install, the licence id, the tier, the address it was issued against and the licence server's
 * URL — the operator's commercial relationship with us, none of which is a customer's business and
 * some of which identifies the platform by name on a portal that has been deliberately
 * white-labelled. This route reduces all of it to the single fact a customer could act on, and the
 * reduction happens on the server so the rest never crosses the network.
 *
 * <p><strong>The word "licence" does not appear in the response, and must not.</strong> Same
 * reason: on a branded portal the customer believes their provider runs this. Telling them
 * otherwise is the one thing `portalBrand` exists to prevent.
 *
 * <h2>Fails open</h2>
 *
 * <p>A gateway that cannot be reached answers `false` — not restricted. The alternative is a
 * customer-facing warning that appears because of a network fault at the operator's end, on a
 * portal where nobody can explain it to them. An alarm nobody can act on is worse than none.
 */
export async function GET(): Promise<NextResponse> {
  try {
    //the session is required but not otherwise used: this is a platform-wide fact, identical for
    //every customer. The check is here so the endpoint is not an unauthenticated probe for whether
    //an operator's licence has lapsed
    await requireCustomer();

    //one field of the licence state, read through the one place that resolves the base URL and
    //the token; the rest of the state never leaves this function. A GatewayError -- unreachable,
    //refused, not configured -- is the catch below, which fails open
    const state = await gqlData<{ configurationAdopted?: boolean }>({ query: LICENSE });
    return NextResponse.json({
      data: { restricted: state?.configurationAdopted === false },
    });
  } catch (err) {
    if (err instanceof NotCustomerError) {
      //404 rather than 403, the rule this panel follows everywhere: a refusal that distinguishes
      //"you may not" from "there is nothing here" tells an unauthenticated caller something
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    return NextResponse.json({ data: { restricted: false } });
  }
}
