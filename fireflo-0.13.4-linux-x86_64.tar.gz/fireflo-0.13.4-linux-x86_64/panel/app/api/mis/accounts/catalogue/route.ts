import { NextRequest, NextResponse } from "next/server";
import { notFoundOrThrow } from "@/lib/mis-route";
import { requireReseller } from "@/lib/require-customer";
import { recordCustomerAccess } from "@/lib/customer-access-log";
import { requestContext } from "@/lib/request-context";
import {
  createChild,
  getChild,
  listChildren,
  takenAccountIds,
  updateChild,
} from "@/lib/mis-accounts";
import {
  childIdProblem,
  narrowChildAccount,
  type ChildAccountWrite,
} from "@/lib/mis-account-rules";
import { validateAccount } from "@/lib/account-types";

/**
 * GET|PUT /api/mis/accounts/catalogue — the accounts this reseller holds, and writing one.
 *
 * <p><strong>Path and envelope both mirror the operator's route exactly</strong>
 * (`app/api/control/accounts/catalogue/route.ts`), because the portal renders the operator's own
 * account components and `useAccounts` swaps only the base — see `lib/panel-surface.ts`. Matching
 * the shape is what makes that a one-line change rather than a fork of the hook.
 *
 * <p>`orphans` is always empty here, and that is the truthful answer rather than a stub: an orphan
 * is an id in use with no catalogue row, and a reseller's children are catalogue rows by
 * construction. There is nothing for it to adopt.
 *
 * <p>Every route under `/api/mis/accounts` answers **404 and never 403** to an account that does not
 * resell, the rule `/api/mis/transfer` already applies: a customer who does not resell has no
 * business learning these endpoints exist.
 */
export async function GET(): Promise<NextResponse> {
  try {
    const session = await requireReseller();
    return NextResponse.json({
      data: { accounts: await listChildren(session.accountId), orphans: [] },
    });
  } catch (err) {
    return notFoundOrThrow(err);
  }
}

/**
 * Shared by both writers: the session, the narrowed input, and the shape check.
 *
 * <p>Returns a response when it refuses, so each handler reads as its own decision rather than as a
 * pile of guards. What it deliberately does **not** decide is create-versus-update — that is the
 * whole point of there being two handlers.
 */
type WriteContext =
  | { refused: NextResponse }
  | {
      refused?: undefined;
      session: { accountId: string };
      input: ChildAccountWrite;
      /** The body as received, for `childIdProblem`, which reports on what was typed. */
      raw: Record<string, unknown>;
    };

async function readWrite(req: NextRequest): Promise<WriteContext> {
  const session = await requireReseller();

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return { refused: NextResponse.json({ error: "Expected a JSON body." }, { status: 400 }) };
  }

  const asked = typeof body.id === "string" ? body.id.trim() : "";
  //everything the reseller may set, and nothing else. `resells` and `parentAccountId` are not
  //rejected -- they are simply not read, and the writers put both in as literals. See
  //lib/mis-account-rules.ts for why narrowing beats validating on this boundary
  const input = narrowChildAccount(body, asked);

  //the shared shape check, so a reseller's address is held to the same rule an operator's is
  const invalid = validateAccount({ id: input.id, email: input.email, enabled: input.enabled });
  if (invalid) {
    return { refused: NextResponse.json({ error: invalid }, { status: 400 }) };
  }
  return { session, input, raw: body };
}

/**
 * Turns a unique violation into the sentence for the constraint that actually fired.
 *
 * <p>`app_account` has two uniques and they mean opposite things. Reporting every `23505` as an
 * email clash — which this route did — tells somebody their address was taken when what actually
 * happened was that the id was, which is a wrong answer to a question they did not ask.
 *
 * <p>Anything else returns null and is rethrown rather than being labelled with a guess.
 */
function uniqueViolation(err: unknown, email: string | null): NextResponse | null {
  const e = err as { code?: string; constraint?: string };
  if (e?.code !== "23505") {
    return null;
  }
  if (e.constraint === "uq_app_account_email") {
    //case-insensitive on `lower(email)`, so the clash may not look like one to whoever hit it
    return NextResponse.json(
      {
        error: `'${email}' is already the address on another account. An email identifies one `
          + "account, ignoring case, so a sign-in link can tell which one it is for.",
      },
      { status: 409 }
    );
  }
  if (e.constraint === "app_account_pkey") {
    //the race the pre-flight check cannot close: somebody else created this id between the check
    //and the insert. Said as the race it is, rather than as an email problem
    return NextResponse.json(
      { error: "That id was taken while you were filling this in. Pick another." },
      { status: 409 }
    );
  }
  return null;
}

/**
 * POST — creates one account beneath this reseller. **Only creates.**
 *
 * <p><strong>This is a separate verb from PUT because it is a separate intent, and conflating them
 * caused a bug.</strong> A single upsert decided create-versus-update by looking the id up, and put
 * the collision check inside only the "not found" branch — so typing the id of an account the
 * reseller <em>already held</em> skipped the check entirely and silently overwrote its name and
 * email. The refusal existed; the branch that reached it did not.
 *
 * <p>Splitting the verbs makes that unreachable rather than guarded: this handler has no update
 * path to fall through to, so forgetting a check can only ever produce a refusal, never a write to
 * the wrong row.
 *
 * <p>The id is checked against every account **and every vendor name** — not because the primary key
 * would not refuse a duplicate account, but because `app_rate_rule.scope` holds accounts and vendors
 * in one column, so an account sharing a vendor's name is priced ambiguously and no constraint says
 * so.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  let ctx;
  try {
    ctx = await readWrite(req);
  } catch (err) {
    return notFoundOrThrow(err);
  }
  if (ctx.refused) {
    return ctx.refused;
  }
  const { session, input, raw } = ctx;

  //the case the old upsert got wrong, answered first and by name. "Already in use" is true of your
  //own customer but reads as though somebody else has it, which sends people looking in the wrong
  //place -- so an account you already hold gets its own sentence
  const mine = input.id ? await getChild(session.accountId, input.id) : null;
  if (mine) {
    return NextResponse.json(
      {
        error: `You already have an account called '${input.id}'`
          + `${mine.label ? ` (${mine.label})` : ""}. Open it to change its details — creating it `
          + "again would overwrite them.",
      },
      { status: 409 }
    );
  }

  const problem = childIdProblem(raw.id, await takenAccountIds());
  if (problem) {
    return NextResponse.json({ error: problem }, { status: 400 });
  }

  try {
    await createChild(session.accountId, input);
  } catch (err) {
    const clash = uniqueViolation(err, input.email);
    if (clash) {
      return clash;
    }
    throw err;
  }

  const rc = await requestContext();
  void recordCustomerAccess({
    event: "child_created",
    accountId: session.accountId,
    ip: rc.ip,
    userAgent: rc.userAgent,
    detail: { child: input.id },
  });

  return NextResponse.json({
    data: {
      id: input.id,
      //said here rather than left to be discovered. An account exists and can be funded the moment
      //this returns, and can do neither of the two things its owner expects
      message: input.email
        ? "Created. They can sign in at this portal with that address, and can send once they have "
          + "a login."
        : "Created. Add an email address so they can sign in, and a login so they can send.",
    },
  });
}

/**
 * PUT — renames one account beneath this reseller. **Only updates.**
 *
 * <p>An id that is not already this reseller's child answers 404, whether it belongs to somebody
 * else or to nobody at all. The two look identical from outside on purpose: naming a stranger's
 * account must not confirm that it exists.
 *
 * <p>That it refuses an id belonging to <em>nobody</em> is not merely tidiness. The operator's PUT
 * is an upsert, and mirroring that here is what let a create become an update; refusing to create
 * from this verb removes the shape rather than adding a guard to it.
 *
 * <p>This is what `useAccounts.save` calls, so it is the path `AccountForm` uses on the Settings
 * tab — an ordinary edit of an account already open.
 */
export async function PUT(req: NextRequest): Promise<NextResponse> {
  let ctx;
  try {
    ctx = await readWrite(req);
  } catch (err) {
    return notFoundOrThrow(err);
  }
  if (ctx.refused) {
    return ctx.refused;
  }
  const { session, input, raw } = ctx;
  //a field the body leaves out keeps its stored value, so a label-only save cannot blank the email
  const carried = (key: string) => Object.prototype.hasOwnProperty.call(raw, key) && raw[key] !== undefined;

  let saved: boolean;
  try {
    saved = await updateChild(session.accountId, input, {
      label: carried("label"),
      description: carried("description"),
      email: carried("email"),
    });
  } catch (err) {
    const clash = uniqueViolation(err, input.email);
    if (clash) {
      return clash;
    }
    throw err;
  }
  if (!saved) {
    //no such child of this reseller. The UPDATE carries the parent as well as the id, so this also
    //covers a page left open across an operator moving the account to somebody else
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const rc = await requestContext();
  void recordCustomerAccess({
    event: "child_updated",
    accountId: session.accountId,
    ip: rc.ip,
    userAgent: rc.userAgent,
    detail: { child: input.id },
  });
  return NextResponse.json({ data: { id: input.id, message: "Saved." } });
}
