import { NextRequest, NextResponse } from "next/server";
import { notFoundOrThrow } from "@/lib/mis-route";
import { assertInScope, requireReseller } from "@/lib/require-customer";
import { recordCustomerAccess } from "@/lib/customer-access-log";
import { requestContext } from "@/lib/request-context";
import { resumeChild, suspendChild } from "@/lib/mis-accounts";

/**
 * POST /api/mis/accounts/{id} — stop one of this reseller's accounts sending, or start it again.
 *
 * <p><strong>The id comes from the path, so it is proved to be this reseller's before anything is
 * written.</strong> `assertInScope` is the line that stops a reseller reaching a stranger's account
 * by trying ids, and it answers the same 404 an unauthenticated call gets — so naming somebody
 * else's account cannot be used to discover that it exists. It also writes the
 * `cross_account_access` row, the only record of one customer's identity touching another's.
 *
 * <p>Its own verb rather than a field on the catalogue PUT, and the portal's own rather than a
 * mirror of an operator route, because the operator has no equivalent: renaming an account and
 * stopping it sending are different acts with different consequences, and a form that could do the
 * second while somebody meant the first is how a customer goes dark by accident.
 *
 * <p><strong>Suspending is not `app_account.enabled = false`.</strong> That column is panel-side
 * only — the gateway never reads `app_account`, so an account "disabled" that way still binds, still
 * sends and is still priced. `suspendChild` disables the logins, drops the binds they already hold,
 * and unlists the account, in that order. This route's job is to report what actually happened
 * rather than to say "suspended" and leave it to be believed.
 */
type Params = { params: Promise<{ id: string }> };

/** Matches `smsg.config.db.poll.seconds`' default. Said in words, as `logins/[id]/rotate` does. */
const POLL_SECONDS = 30;

export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  let session;
  let child: string;
  try {
    session = await requireReseller();
    child = decodeURIComponent((await params).id);
    await assertInScope(session, child);
  } catch (err) {
    return notFoundOrThrow(err);
  }

  let body: { action?: unknown };
  try {
    body = (await req.json()) as typeof body;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  if (body.action !== "suspend" && body.action !== "resume") {
    return NextResponse.json({ error: "Name the action: suspend or resume." }, { status: 400 });
  }

  const ctx = await requestContext();

  if (body.action === "resume") {
    const logins = await resumeChild(session.accountId, child);
    void recordCustomerAccess({
      event: "child_resumed",
      accountId: session.accountId,
      ip: ctx.ip,
      userAgent: ctx.userAgent,
      detail: { child, logins },
    });
    return NextResponse.json({
      data: {
        logins,
        //the same window a rotation has, and for the same reason: the gateway reloads credentials
        //on a poll, so a re-enabled login does not work the instant this returns
        propagationSeconds: POLL_SECONDS,
        message: logins
          ? `${logins} login${logins === 1 ? "" : "s"} switched back on. They can connect again `
            + `within ${POLL_SECONDS} seconds.`
          : "Listed again. There were no disabled logins to switch back on.",
      },
    });
  }

  const result = await suspendChild(session.accountId, child);
  if (result.problem && !result.logins && !result.dropped) {
    //suspendChild answers this when the account stopped being ours between the scope check and the
    //transaction, because an operator moved it. Not a failure to report as one
    return NextResponse.json({ error: result.problem }, { status: 404 });
  }

  void recordCustomerAccess({
    event: "child_suspended",
    accountId: session.accountId,
    ip: ctx.ip,
    userAgent: ctx.userAgent,
    detail: { child, logins: result.logins, dropped: result.dropped },
  });

  return NextResponse.json({
    data: { ...result, propagationSeconds: POLL_SECONDS, message: describe(result) },
  });
}

/**
 * What happened, not what was intended.
 *
 * <p>The bind count is the part worth showing: it is the difference between "will stop sending" and
 * "has stopped sending", and a reseller suspending a customer for non-payment is asking exactly that.
 */
function describe(result: { logins: number; dropped: number; problem?: string }): string {
  if (!result.logins) {
    return "Unlisted. There were no enabled logins to switch off, so nothing was sending anyway.";
  }
  const logins = `${result.logins} login${result.logins === 1 ? "" : "s"} switched off`;
  if (result.problem) {
    //the honest version of a partial success: the durable change landed, the live half did not
    return `${logins}. Connections already open could not be dropped (${result.problem}), so any `
      + `still up may keep sending for up to ${POLL_SECONDS} seconds.`;
  }
  const dropped = result.dropped
    ? `${result.dropped} open connection${result.dropped === 1 ? "" : "s"} dropped`
    : "no connections were open";
  return `${logins} and ${dropped}. New connections are refused within ${POLL_SECONDS} seconds.`;
}
