import { NextRequest, NextResponse } from "next/server";
import { money as formatMoney } from "@/lib/format";
import { notFoundOrThrow } from "@/lib/mis-route";
import { billingZone, platformCurrency } from "@/lib/platform-currency";
import { reconcileAccount } from "@/lib/reconcile-queries";
import { assertInScope, requireReseller } from "@/lib/require-customer";

/**
 * GET /api/mis/accounts/{id}/reconcile — whether one child's credit adds up.
 *
 * <p>Mirrors the operator route's path and shape so `ReconcileCard` swaps only its base — see
 * `lib/panel-surface.ts`.
 *
 * <p><strong>Nothing is withheld here, and that is deliberate rather than an oversight.</strong> The
 * two identities are lifetime arithmetic over the child's own ledger — every unit credited is still
 * in balance or reserved, and what was reserved covers what was spent. There is no cost, no margin
 * and no vendor anywhere in it. A reseller funds this account, so "does the money add up" is a
 * question it is entitled to ask, and the residual is the only honest answer to it.
 *
 * <p>Read-only, and there is deliberately no write counterpart — the operator route explains why at
 * length: posting an adjusting entry for a residual hides the cause and makes the next drift start
 * from a number nobody can audit.
 */
type Params = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  let child: string;
  try {
    const session = await requireReseller();
    child = decodeURIComponent((await params).id).trim();
    //the id arrives in the path, so it is proved to be this reseller's before it reaches a query
    await assertInScope(session, child);
  } catch (err) {
    return notFoundOrThrow(err);
  }

  const [currency, zone] = await Promise.all([platformCurrency(), billingZone()]);
  //the same formatter every other amount in the portal goes through, so a discrepancy is written the
  //way the balance beside it is
  const result = await reconcileAccount(child, zone, (scaled) => formatMoney(scaled, currency ?? ""));
  if (!result) {
    return NextResponse.json({
      //not an error: an account nobody opened for credit has nothing to reconcile, and saying so is
      //more use than an empty card
      data: null,
      notice: "This account has no balance row, so there is no credit to reconcile.",
    });
  }
  return NextResponse.json({ data: { ...result, zone } });
}
