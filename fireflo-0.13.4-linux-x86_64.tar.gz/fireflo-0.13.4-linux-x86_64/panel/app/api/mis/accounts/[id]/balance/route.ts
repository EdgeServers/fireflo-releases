import { NextRequest, NextResponse } from "next/server";
import { getBalance, openBalance, setBillingMode, setCreditEnabled } from "@/lib/balance";
import { formatAmount, parseAmount, validateBillingChange } from "@/lib/balance-types";
import { recordCustomerAccess } from "@/lib/customer-access-log";
import { notFoundOrThrow } from "@/lib/mis-route";
import { currencyForNewBalance } from "@/lib/platform-currency";
import { requestContext } from "@/lib/request-context";
import { postpaidHeadroom } from "@/lib/mis-accounts";
import { assertInScope, requireReseller } from "@/lib/require-customer";

/**
 * POST /api/mis/accounts/{id}/balance — the credit terms a reseller sets on one of its accounts.
 *
 * <p>Mirrors the operator route's path and body so `CreditActions` swaps only its base — see
 * `lib/panel-surface.ts`. Four of its five actions are here. The fifth is refused, and that refusal
 * is the point of the file.
 *
 * <h2>`topUp` is refused by name, not merely absent</h2>
 *
 * <p>The operator's `topUp` writes a `RECHARGE` row: an account gains credit and **nothing is
 * debited anywhere**. That is the platform issuing money, and it belongs to whoever carries the
 * receivable. A reseller funds a child by moving its own balance — a `TRANSFER`, which debits the
 * payer in the same statement that credits the payee.
 *
 * <p>Refusing by name rather than falling through to "unknown action" matters because the shared
 * component could call it: a stale client, or a future edit that forgets which surface it is on,
 * gets a sentence pointing at the transfer instead of a generic 400 that reads like a bug. Nothing
 * is written on that path — no ledger row of any kind.
 *
 * <h2>The currency is never read from the body</h2>
 *
 * <p>`open` resolves it through `currencyForNewBalance`: the gateway's `smsg.rates.currency`, then
 * this child's **parent** — which is this reseller. A customer cannot know the platform's currency
 * and must not be asked to guess at one, and `openBalance` is `ON CONFLICT DO NOTHING`, so a wrong
 * code could never be corrected by opening the account again.
 */
type Params = { params: Promise<{ id: string }> };

export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  let session;
  let child: string;
  try {
    session = await requireReseller();
    child = decodeURIComponent((await params).id).trim();
    //the id arrives in the path, so it is proved to be this reseller's before anything is written
    await assertInScope(session, child);
  } catch (err) {
    return notFoundOrThrow(err);
  }

  let body: { action?: unknown; enabled?: unknown; mode?: unknown; creditLimit?: unknown };
  try {
    body = (await req.json()) as typeof body;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const ctx = await requestContext();
  const note = (detail: Record<string, unknown>) =>
    void recordCustomerAccess({
      event: "child_credit_changed",
      accountId: session.accountId,
      ip: ctx.ip,
      userAgent: ctx.userAgent,
      detail: { child, ...detail },
    });

  if (body.action === "topUp") {
    //the whole reason this route exists rather than pointing at the operator's. See the note above
    return NextResponse.json(
      {
        error: "Credit is not created here. Move funds to this account from your own balance "
          + "instead — the transfer debits you and credits them in one step.",
      },
      { status: 400 }
    );
  }

  if (body.action === "open") {
    const inherited = await currencyForNewBalance(child);
    if (!inherited.code) {
      //neither the gateway nor this reseller's own balance could answer. Refused rather than asked:
      //the operator is the only party who can know, and a balance opened in the wrong currency
      //cannot be corrected afterwards
      return NextResponse.json(
        {
          error: "This platform has not published a currency we can read, and there is none on your "
            + "own balance to inherit. Ask your account manager to set one.",
        },
        { status: 409 }
      );
    }
    const created = await openBalance(child, inherited.code, body.enabled !== false);
    note({ opened: created, currency: inherited.code, from: inherited.from });
    return NextResponse.json({
      data: { accountId: child, created, currency: inherited.code },
      notice: created
        ? null
        : "This account already had a balance row; nothing was changed.",
    });
  }

  if (body.action === "enable" || body.action === "disable") {
    const enabled = body.action === "enable";
    const changed = await setCreditEnabled(child, enabled);
    if (!changed) {
      return NextResponse.json(
        { error: "This account has no balance row yet. Open it for credit first." },
        { status: 404 }
      );
    }
    note({ creditEnabled: enabled });
    return NextResponse.json({
      data: { accountId: child, enabled },
      //a real kill switch, unlike `app_account.enabled`: the gateway's RESERVE carries `AND enabled`,
      //so a disabled account stops sending once the block it already holds runs out
      notice: enabled
        ? null
        : "Credit is off. They stop sending once the credit already reserved runs out.",
    });
  }

  if (body.action === "billing") {
    const limit = typeof body.creditLimit === "string" ? body.creditLimit : "";
    const invalid = validateBillingChange(body.mode, limit);
    if (invalid) {
      return NextResponse.json({ error: invalid }, { status: 400 });
    }
    //narrowed by validateBillingChange, which refuses anything that is not one of the two
    const mode = body.mode as "PREPAID" | "POSTPAID";
    //scaled before the checks below, which compare against it. Zero on prepaid, which is what
    //ck_account_balance_limit requires -- a stale figure on a prepaid row reads as still in force
    const scaled = mode === "POSTPAID" ? (parseAmount(limit) ?? 0) : 0;

    if (mode === "POSTPAID") {
      //a reseller may only pass on terms it holds, and only as much of them as it has left.
      //
      //Postpaid is a credit line: the account sends against a limit rather than against money that
      //has moved, and somebody carries that until it is invoiced. A PREPAID reseller has no line
      //from the operator, so granting one here would extend credit that exists nowhere -- and the
      //gateway would honour it, because RESERVE reads `credit_limit` without asking who is behind it
      const own = await getBalance(session.accountId).catch(() => null);
      if (own?.billingMode !== "POSTPAID") {
        return NextResponse.json(
          {
            error: "Your own account is on prepaid terms, so postpaid is not yours to give. A "
              + "postpaid customer sends against a limit rather than against funds, and somebody "
              + "has to carry it until it is invoiced. Ask your account manager.",
          },
          { status: 403 }
        );
      }

      //and the AGGREGATE has to fit. Checking only this child against the reseller's own limit
      //would be one grant away from useless: five children on the full limit each is five times the
      //line, underwritten by one balance. `postpaidHeadroom` excludes this child's current limit,
      //because the write replaces it rather than adding to it
      const room = await postpaidHeadroom(session.accountId, child);
      if (scaled > room.headroom) {
        return NextResponse.json(
          {
            error: room.headroom === 0
              ? `Your credit limit of ${formatAmount(room.own)} is already fully committed to your `
                + "other accounts. Lower one of those first, or ask your account manager to raise "
                + "yours."
              : `That is more than you have left to give. Your limit is `
                + `${formatAmount(room.own)}, of which ${formatAmount(room.committed)} is already `
                + `committed to your other accounts — leaving ${formatAmount(room.headroom)} for `
                + "this one.",
          },
          { status: 409 }
        );
      }
    }

    const changed = await setBillingMode(child, mode, scaled);
    if (!changed) {
      return NextResponse.json(
        { error: "This account has no balance row yet. Open it for credit first." },
        { status: 404 }
      );
    }
    note({ billingMode: mode, creditLimit: scaled });
    return NextResponse.json({
      data: { accountId: child, mode, creditLimit: scaled },
      //said plainly because a reseller setting a child postpaid is taking on the risk itself: the
      //child sends against a limit rather than against money already moved
      notice: mode === "POSTPAID"
        ? "They can now send up to that limit without funds moving first. You carry it."
        : null,
    });
  }

  return NextResponse.json(
    { error: `'${String(body.action)}' is not an action. Use open, billing, enable or disable.` },
    { status: 400 }
  );
}
