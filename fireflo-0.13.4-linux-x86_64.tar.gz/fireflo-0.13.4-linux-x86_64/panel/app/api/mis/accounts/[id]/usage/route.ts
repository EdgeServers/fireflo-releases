import { NextRequest, NextResponse } from "next/server";
import { notFoundOrThrow } from "@/lib/mis-route";
import { mtUsageFor } from "@/lib/mt-usage-queries";
import { billingZone } from "@/lib/platform-currency";
import { assertInScope, requireReseller } from "@/lib/require-customer";

/**
 * GET /api/mis/accounts/{id}/usage — one child's messages, MT parts and charges.
 *
 * <p>Mirrors the operator route's path and shape so the billing page swaps only its base — see
 * `lib/panel-surface.ts`. Nothing is withheld: the charge is what this reseller's own child paid,
 * and there is no cost, margin or vendor in it.
 */
type Params = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  let child: string;
  try {
    const session = await requireReseller();
    child = decodeURIComponent((await params).id).trim();
    //the id arrives in the path, so it is proved to be this reseller's before it reaches a query
    await assertInScope(session, child);
  } catch (err) {
    return notFoundOrThrow(err);
  }
  return NextResponse.json({ data: await mtUsageFor(child, await billingZone()) });
}
