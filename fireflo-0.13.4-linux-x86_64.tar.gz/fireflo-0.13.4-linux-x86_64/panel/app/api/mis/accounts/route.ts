import { NextRequest, NextResponse } from "next/server";
import { isConfigured } from "@/lib/metrics-db";
import { accountUsage } from "@/lib/metrics-queries";
import { notFoundOrThrow } from "@/lib/mis-route";
import { requireReseller, scopeFor } from "@/lib/require-customer";
import { isRange, type Range } from "@/lib/metrics-queries";

/**
 * GET /api/mis/accounts?range= — traffic for this reseller's own scope, by account and login.
 *
 * <p>Mirrors the operator route's path and shape so `useControlData("accounts", range)` swaps only
 * its base — see `lib/panel-surface.ts`. It feeds the Traffic table on a child's Overview tab.
 *
 * <p><strong>Two columns the operator's answer carries are removed here, and both are money that is
 * not this customer's to see.</strong>
 *
 * <ul>
 *   <li>`cost` is what the operator paid a vendor to carry the message. The difference between it
 *       and `billed` is the margin. That is not the tariff by name, but it is the same disclosure
 *       arriving through a column instead of a page.</li>
 *   <li>`balance` and `currency` are dropped for rows that are not this reseller's own children —
 *       which, after the scope filter, is none of them. Kept in the projection deliberately rather
 *       than stripped, because a reseller funds its children and their credit is the figure it
 *       needs; the filter is what makes that safe.</li>
 * </ul>
 *
 * <p><strong>The scope filter is applied here, not in the query.</strong> `accountUsage` runs over
 * the whole deployment, which is what the operator's page wants — reusing it and filtering after
 * costs one scan that was going to happen anyway on a page an operator also loads, and avoids a
 * second nearly-identical query drifting from this one. The rows a reseller may see are decided by
 * `scopeFor`, the same function every other portal route asks.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  let scope: string[];
  try {
    scope = await scopeFor(await requireReseller());
  } catch (err) {
    return notFoundOrThrow(err);
  }

  if (!isConfigured()) {
    return NextResponse.json(
      { error: "Traffic is not available on this deployment." },
      { status: 503 }
    );
  }

  //validated rather than passed through, the same rule the operator's `controlRoute` applies: an
  //unrecognised value reads as the default rather than as an error for a query-string typo
  const asked = req.nextUrl.searchParams.get("range");
  const range: Range = isRange(asked) ? asked : "24h";

  const view = await accountUsage(range);
  const mine = new Set(scope);
  return NextResponse.json({
    data: {
      creditEnforced: view.creditEnforced,
      //`cost` is dropped by construction rather than zeroed: a zero would render as a real figure
      //in the column and read as "we pay nothing for this", which is a different lie
      accounts: view.accounts
        .filter((row) => row.accountId != null && mine.has(row.accountId))
        .map(({ cost: _cost, ...row }) => row),
    },
  });
}
