import { NextRequest, NextResponse } from "next/server";
import { isConfigured } from "@/lib/metrics-db";
import {
  assertInScope,
  NotCustomerError,
  requireCustomer,
  scopeFor,
} from "@/lib/require-customer";
import { customPeriod, monthPeriod, periodTooLong, type BillingPeriod } from "@/lib/billing-period";
import { billingZone, platformCurrency } from "@/lib/platform-currency";
import { closedPeriods, statementSummary } from "@/lib/statement-queries";
import { usageBetween } from "@/lib/metrics-queries";
import { getBalance } from "@/lib/balance";

/**
 * The customer's own statement, for the period they picked.
 *
 * <h2>What a customer is never shown</h2>
 *
 * <p>`statementSummary` selects only sell-side figures — counts, outcomes and `price`. It has no
 * `cost`, no `margin` and no `vendor` column at all, which is why it can be shared with the
 * operator route rather than duplicated. The thing that must NOT be shared is the CSV: the
 * operator's `statement-export.ts` is a fixed header list and a job store on local disk, and the
 * customer download is a separate bounded stream for exactly the reason
 * `app/api/mis/messages/export` gives.
 *
 * <h2>The account comes from the session, or from a child it is proved to hold</h2>
 *
 * <p><strong>The default has no account parameter at all.</strong> A reseller's own statement is the
 * SUM over `scopeFor`, which is the figure it is invoiced for, and nothing in the request can widen
 * that set.
 *
 * <p>`?account=` narrows it to ONE of those accounts, for the per-child statement on
 * `/accounts/{id}/statement`. That was previously called out here as a different question that this
 * route deliberately did not answer — and it is a different question, which is why it is a separate
 * parameter with its own check rather than a filter folded into the total. The id goes through
 * `assertInScope` before it reaches a query, so it can only ever narrow, never widen: a stranger's
 * id answers the same 404 an unauthenticated call gets.
 *
 * <p>The distinction the old note was protecting still holds: the unparameterised total is labelled
 * as the reseller's own and is never silently one child's traffic.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  let session;
  try {
    session = await requireCustomer();
  } catch (err) {
    if (err instanceof NotCustomerError) {
      //404 rather than 401, matching every other portal route: an unauthenticated caller learns
      //nothing about which endpoints exist
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  if (!isConfigured()) {
    return NextResponse.json(
      { error: "Statements are not available on this deployment." },
      { status: 503 }
    );
  }

  const period = readPeriod(req.nextUrl.searchParams);
  if (typeof period === "string") {
    return NextResponse.json({ error: period }, { status: 400 });
  }

  //absent means the whole scope, which is every ordinary customer's request unchanged. A named
  //account narrows to one, and only after being proved to be this session's or one of its children
  const asked = req.nextUrl.searchParams.get("account");
  let scope: string[];
  try {
    if (asked) {
      await assertInScope(session, asked);
      scope = [asked];
    } else {
      scope = await scopeFor(session);
    }
  } catch (err) {
    if (err instanceof NotCustomerError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  try {
    const [currency, zone] = await Promise.all([platformCurrency(), billingZone()]);

    //summed across the scope, one query per account. A reseller has a handful of children, not a
    //page of them -- the two-level constraint in V1.15.0 is what makes that safe to assume
    const parts = await Promise.all(
      scope.map((id) => statementSummary(id, period, currency, zone))
    );

    //the same window the total covers, day by day. Sell-side only: `UsageDay` carries counts and
    //`price`, and has no cost, margin or vendor column to leak. Summed over the scope for the same
    //reason the lines are -- a reseller is invoiced for the total, so the chart has to plot it
    const daily = await Promise.all(
      scope.map((id) => usageBetween(period.since, period.until, "day", id))
    );
    const byDay = new Map<string, { day: string; submitted: number; delivered: number;
      failed: number; pending: number; price: number }>();
    for (const row of daily.flat()) {
      const at = byDay.get(row.day)
        ?? { day: row.day, submitted: 0, delivered: 0, failed: 0, pending: 0, price: 0 };
      at.submitted += row.submitted;
      at.delivered += row.delivered;
      at.failed += row.failed;
      at.pending += row.pending;
      at.price += row.price;
      byDay.set(row.day, at);
    }
    //`accountId` is dropped on the way out. Within a reseller's own total it would be the one field
    //that splits the figure back into per-child traffic, which is the distinction this route's
    //header says the statement deliberately does not answer
    const days = [...byDay.values()].sort((a, b) => a.day.localeCompare(b.day));

    const lines = new Map<string, { product: string; submitted: number; delivered: number;
      failed: number; expired: number; pending: number; unrated: number; amount: number }>();
    for (const part of parts) {
      for (const line of part.lines) {
        const at = lines.get(line.product) ?? {
          product: line.product, submitted: 0, delivered: 0, failed: 0,
          expired: 0, pending: 0, unrated: 0, amount: 0,
        };
        at.submitted += line.submitted;
        at.delivered += line.delivered;
        at.failed += line.failed;
        at.expired += line.expired;
        at.pending += line.pending;
        at.unrated += line.unrated;
        at.amount += line.amount;
        lines.set(line.product, at);
      }
    }

    //the account the statement is ABOUT, which is the child when one was named. A reseller reading
    //a child's statement wants that child's balance and that child's closed periods beside it --
    //showing its own under a heading naming the child is the misreading this whole route guards
    const subject = asked || session.accountId;
    const [balance, closed] = await Promise.all([
      getBalance(subject).catch(() => null),
      closedPeriods(subject).catch(() => []),
    ]);

    return NextResponse.json({
      data: {
        label: period.label,
        currency,
        lines: [...lines.values()].sort((a, b) => b.amount - a.amount),
        days,
        totalSubmitted: parts.reduce((n, p) => n + p.totalSubmitted, 0),
        totalDelivered: parts.reduce((n, p) => n + p.totalDelivered, 0),
        totalUnrated: parts.reduce((n, p) => n + p.totalUnrated, 0),
        totalAmount: parts.reduce((n, p) => n + p.totalAmount, 0),
        //a postpaid customer sees what they may still run up; a prepaid one sees what is left.
        //Different questions, and showing the wrong one is how somebody plans against a number
        //that does not apply to them
        billingMode: balance?.billingMode ?? "PREPAID",
        balance: balance?.balance ?? null,
        creditLimit: balance?.billingMode === "POSTPAID" ? balance.creditLimit : null,
        closed,
      },
    });
  } catch {
    //deliberately not echoing the error: a customer-facing route must not leak a driver message
    return NextResponse.json(
      { error: "Could not prepare the statement." },
      { status: 500 }
    );
  }
}

/** `?month=YYYY-MM`, or `?from=&to=`. Both bounded by the same 92-day ceiling everything else has. */
function readPeriod(params: URLSearchParams): BillingPeriod | string {
  const month = params.get("month");
  if (month) {
    const period = monthPeriod(month);
    if (!period) {
      return `'${month}' is not a month. Use YYYY-MM.`;
    }
    return periodTooLong(period) ?? period;
  }
  const period = customPeriod(params.get("from") ?? "", params.get("to") ?? "");
  if (typeof period === "string") {
    return period;
  }
  return periodTooLong(period) ?? period;
}
