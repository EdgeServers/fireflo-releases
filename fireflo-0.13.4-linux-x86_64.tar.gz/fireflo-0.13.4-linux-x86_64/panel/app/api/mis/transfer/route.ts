import { NextRequest, NextResponse } from "next/server";
import { configQuery } from "@/lib/config-db";
import { assertInScope, NotCustomerError, requireCustomer } from "@/lib/require-customer";
import { isUniqueViolation } from "@/lib/balance";
import { parseAmount } from "@/lib/balance-types";

/**
 * Moves prepaid balance between a reseller and one of its own accounts.
 *
 * <p>Direction is the caller's, and it is not a special case in the code: pushing down writes a row
 * paying from the reseller, pulling up writes one paying from the child. The gateway applies both
 * with the same statements and the same sufficiency guard.
 *
 * <h2>What this does not do</h2>
 *
 * <p><strong>It does not move any money.</strong> It writes an unapplied `TRANSFER` row and returns.
 * `account_balance` has exactly one writer — the gateway — and it debits with `WHERE balance >= ?`
 * so that sufficiency is decided by the statement that moves the money rather than by a read taken
 * here, milliseconds before the child's traffic spends the difference.
 *
 * <p>So the honest answer to the caller is "queued", and the interface says within a minute rather
 * than pretending the balance has already changed. A transfer that cannot be applied stays pending
 * and the gateway names it in a warning.
 *
 * <h2>Replays, and why the key is namespaced</h2>
 *
 * <p>Every request carries a `ref`, and `uq_balance_ledger_ref` makes a repeat of the same one a
 * conflict rather than a second transfer. Without it a double-submitted form queued two independent
 * rows — bounded by the gateway's sufficiency check, so not value creation, but the operator's
 * top-up path has had this guard since it was written and the asymmetry was accidental.
 *
 * <p>The key is **namespaced and shape-checked** rather than taken as free text, which closes a
 * second and quieter hole: that index is shared with operator top-ups, whose refs are typed by hand
 * (`INV-2024-001`). A customer free to claim any string could sit on the references an operator
 * would later want, and the operator would meet a duplicate-reference error with no explanation.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  let session;
  try {
    session = await requireCustomer();
  } catch (err) {
    if (err instanceof NotCustomerError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  if (!session.resells) {
    //not a 403: an account that does not resell has no business knowing this endpoint exists
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  let body: { accountId?: unknown; amount?: unknown; direction?: unknown; ref?: unknown };
  try {
    body = (await req.json()) as typeof body;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const child = typeof body.accountId === "string" ? body.accountId.trim() : "";
  const direction = body.direction === "up" ? "up" : "down";

  const ref = typeof body.ref === "string" ? body.ref.trim() : "";
  if (!TRANSFER_REF.test(ref)) {
    //a page open across a deploy is the only way to get here from the portal, so the message is
    //about that rather than about a field nobody typed
    return NextResponse.json(
      { error: "This form is out of date. Reload the page and try again." },
      { status: 400 }
    );
  }

  //the id came from the request, so it is checked against the session's own children before it is
  //used for anything. This is the line that stops a reseller funding itself from a stranger
  try {
    await assertInScope(session, child);
  } catch (err) {
    if (err instanceof NotCustomerError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  if (child === session.accountId) {
    return NextResponse.json({ error: "Choose one of your accounts to move balance to." }, { status: 400 });
  }

  //money is BIGINT x10^4 everywhere in this system, and string manipulation is how it stays exact.
  //Number() on a decimal here would introduce the rounding the schema exists to avoid
  //`parseAmount`, not a second scaler of this route's own. It was one, and it had no ceiling: a
  //40-digit amount became a BigInt that overflowed `balance_ledger.delta` inside the driver and
  //surfaced as a 500. The shared one refuses anything past Number.MAX_SAFE_INTEGER, which is the
  //stricter and more useful bound because the value crosses JSON on the way here
  const raw = typeof body.amount === "string" ? body.amount : String(body.amount ?? "");
  const amount = parseAmount(raw);
  if (amount === null || amount <= 0) {
    return NextResponse.json(
      { error: "Enter an amount greater than zero, with at most four decimal places." },
      { status: 400 }
    );
  }

  const from = direction === "down" ? session.accountId : child;
  const to = direction === "down" ? child : session.accountId;

  try {
    await configQuery(
      `INSERT INTO balance_ledger
              (account_id, delta, entry_type, counterparty_account_id, ref, note, applied)
       VALUES ($1, $2, 'TRANSFER', $3, $4, $5, FALSE)`,
      [from, amount, to, ref, `mis-panel transfer by ${session.accountId}`]
    );
  } catch (err) {
    if (isUniqueViolation(err)) {
      //the replay guard doing its job: the first one landed and is already queued
      return NextResponse.json(
        { error: "That transfer has already been queued." },
        { status: 409 }
      );
    }
    throw err;
  }

  return NextResponse.json({
    data: {
      queued: true,
      from,
      to,
      message: "Queued. The gateway applies it within a minute, and refuses it if the paying "
        + "account no longer has enough.",
    },
  });
}


/**
 * The idempotency key's shape: a namespace this route owns, plus a UUID the client generates.
 *
 * <p>Namespaced so a customer cannot occupy a reference an operator would later type — see the note
 * on this file. Shape-checked so the namespace cannot be smuggled past with a longer string.
 */
const TRANSFER_REF = /^xfer:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;


