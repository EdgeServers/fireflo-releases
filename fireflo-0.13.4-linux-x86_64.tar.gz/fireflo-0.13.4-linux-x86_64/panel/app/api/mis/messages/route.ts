import { NextRequest, NextResponse } from "next/server";
import { DEFAULT_PAGE, MAX_PAGE, columnSetFor, searchCdrs } from "@/lib/cdr-queries";
import { isFilterError, parseFilters, type CdrCursor } from "@/lib/cdr-request";
import { NotCustomerError, requireCustomer, scopeFor } from "@/lib/require-customer";
import { projectForCustomer } from "@/lib/customer-cdr-columns";

/**
 * A customer's own messages.
 *
 * <p>The same query the operator page uses, with two differences that are the whole security model
 * of this endpoint:
 *
 * <ol>
 *   <li><strong>The account set is overwritten, not defaulted.</strong> `parseFilters` reads the
 *       caller's query string, which may well contain `account=somebody-else`. Assigning
 *       `accountIn` afterwards means whatever it parsed is ANDed inside the session's scope and
 *       cannot reach outside it. Defaulting instead of overwriting — `filters.accountIn ??= scope`
 *       — would be the bug: a supplied value would win.
 *   <li><strong>The rows are projected through the customer column list.</strong> The query returns
 *       whatever the shared code selects, which includes cost and margin; nothing leaves this
 *       handler that is not on {@link CUSTOMER_CDR_COLUMN_IDS}. Filtering in the component would
 *       hide it on screen and still ship it in the JSON.
 * </ol>
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  let scope: string[];
  try {
    const session = await requireCustomer();
    scope = await scopeFor(session);
  } catch (err) {
    if (err instanceof NotCustomerError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const params = req.nextUrl.searchParams;
  const parsed = parseFilters(params);
  if (isFilterError(parsed)) {
    return NextResponse.json({ error: parsed.error }, { status: 400 });
  }

  //after parsing, never before. See the class note
  parsed.accountIn = scope;

  //`range=all` drops the time bound entirely, and on a customer-facing route that is a request to
  //walk cdr_submit from the newest row until LIMIT is satisfied -- which, paired with a filter that
  //matches nothing, is the whole table under a 10-second statement timeout on a pool of eight.
  //The operator's own page keeps it: they are trusted, few, and sometimes need it
  if (!parsed.since) {
    return NextResponse.json(
      { error: "Choose a time range. The whole history is not available here." },
      { status: 400 }
    );
  }

  const cursor: CdrCursor | null =
    params.get("cursorAt") && params.get("cursorId")
      ? { submittedAt: params.get("cursorAt")!, id: params.get("cursorId")! }
      : null;

  //capped the way /api/control/cdrs caps it. Without this the portal's limit went to searchCdrs
  //unclamped, where it met MAX_BATCH (5,000) -- the export ceiling, not the browser one
  const limit = Number(params.get("limit") ?? DEFAULT_PAGE);
  if (!Number.isFinite(limit) || limit < 1) {
    return NextResponse.json({ error: "limit must be a positive number." }, { status: 400 });
  }

  //The TLV column is unbounded TEXT, so it is selected only when the caller is actually showing it.
  //`columns` names what the chooser has ticked; anything not on the customer allow-list is ignored
  //here exactly as it is on the export, so this cannot be used to widen what is fetched.
  const wanted = new Set((params.get("columns") ?? "").split(",").map((c) => c.trim()));
  //"customer": the portal gets its own content whole, where the operator's list truncates it. The
  //allow-list above has already decided what may be asked for; this only picks the projection
  const set = columnSetFor(wanted, "customer");

  const page = await searchCdrs(parsed, cursor, Math.min(limit, MAX_PAGE), set);

  return NextResponse.json({
    data: {
      ...page,
      rows: page.rows.map((r) => projectForCustomer(r as unknown as Record<string, unknown>)),
      //so the client can render a scope switcher without a second round trip, and so a reseller
      //can see at a glance which accounts it is looking at
      scope,
    },
  });
}
