import { NextRequest, NextResponse } from "next/server";
import { assertInScope, requireCustomer } from "@/lib/require-customer";
import { notFoundOrThrow, note, rowId } from "@/lib/mis-route";
import { proposedTlvs } from "@/lib/tlv-string";
import { ownerOfHeader, scopedLogin, updateOwnHeader, withdrawHeader } from "@/lib/mis-whitelist";
import { validateHeader } from "@/lib/whitelist-types";

/**
 * PUT|DELETE /api/mis/senders/{id} — change or withdraw one of the customer's own.
 *
 * <p><strong>An id is a number somebody can guess, so ownership is checked before anything is
 * touched.</strong> The row's account is read first and put through `assertInScope`, which is the
 * line that stops a customer editing a stranger's registration by trying ids. A missing row and
 * somebody else's row both answer 404, and deliberately look the same from outside.
 *
 * <p>Editing puts the row back to `PENDING`, so it stops being served until an operator approves it
 * again. That is what stops a customer changing what was approved and continuing to send under the
 * approval, and it means an edit interrupts their own traffic — the form says so before saving.
 */
type Params = { params: Promise<{ id: string }> };

export async function PUT(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const guard = await scoped(params);
  if ("response" in guard) {
    return guard.response;
  }

  let body: Record<string, unknown> | null;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const header = typeof body?.header === "string" ? body.header.trim() : "";
  const invalid = validateHeader(header);
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }

  const tlvs = proposedTlvs(body?.requestedTlvs);
  if ("error" in tlvs) {
    return NextResponse.json({ error: tlvs.error }, { status: 400 });
  }

  //the write decides whether this suspends, by comparing old against new inside the one statement,
  //and reports back which it did. Saying "sent for approval" over a save that changed only the
  //proposed stamps would teach customers to fear a control that costs them nothing
  //the row is already proved to be this account's by `scoped`, so the login is checked against the
  //same account -- a login belonging to a reseller's child is not this row's to move to
  const login = await scopedLogin([guard.accountId], body?.systemId);
  if ("error" in login) {
    return NextResponse.json({ error: login.error }, { status: 400 });
  }

  const suspended = await updateOwnHeader(
    guard.id, header, note(body?.requestNote), tlvs.value, login.value
  );
  return NextResponse.json({
    data: {
      saved: true,
      suspended,
      message: suspended
        ? "Sent for approval. It stops being used until an operator approves the change."
        : "Saved. Your operator will see what you have asked for; this one stays in service in the "
          + "meantime, because nothing it sends has changed yet.",
    },
  });
}

export async function DELETE(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const guard = await scoped(params);
  if ("response" in guard) {
    return guard.response;
  }
  await withdrawHeader(guard.id);
  return NextResponse.json({ data: { withdrawn: true } });
}

/**
 * Resolves the id and proves the caller owns it, or produces the answer.
 *
 * <p>Shared by both methods because getting it right once is the point: a check written twice is a
 * check that will eventually be written once.
 */
async function scoped(
  params: Params["params"]
): Promise<{ id: number; accountId: string } | { response: NextResponse }> {
  try {
    const session = await requireCustomer();
    const id = rowId((await params).id);
    if (id === null) {
      return { response: NextResponse.json({ error: "Not found" }, { status: 404 }) };
    }
    const owner = await ownerOfHeader(id);
    if (owner === null) {
      return { response: NextResponse.json({ error: "Not found" }, { status: 404 }) };
    }
    //throws NotCustomerError when the row belongs to somebody outside this session's scope
    await assertInScope(session, owner);
    //the OWNER, not the session's own account: a reseller editing a child's row must
    //scope the login to that child rather than to itself
    return { id, accountId: owner };
  } catch (err) {
    return { response: notFoundOrThrow(err) };
  }
}
