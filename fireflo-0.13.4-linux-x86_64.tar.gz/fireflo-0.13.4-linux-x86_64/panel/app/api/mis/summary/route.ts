import { NextResponse } from "next/server";
import { configQuery } from "@/lib/config-db";
import { getBalance } from "@/lib/balance";
import { NotCustomerError, requireCustomer, scopeFor } from "@/lib/require-customer";
//type-only, so it is erased and the client component never enters this route's module graph
import type { MisSummary } from "@/components/MisShell";

/**
 * Who is signed in, what they have left, and what they hold.
 *
 * <p>Feeds the portal sidebar. Everything here is derived from the session — nothing in the request
 * names an account, so there is nothing to check.
 *
 * <p><strong>The body is annotated `MisSummary` rather than inferred.</strong> The consumer declares
 * that shape and reads it back through `r.json()`, which is `any` — so nothing checked the two
 * against each other, and this handler sent the balance as a number to a client that formats money
 * by moving characters around. Every account with a balance got a `startsWith is not a function`
 * instead of a portal. Naming the type here is what turns that into a compile error.
 *
 * <p>The balance is read one account at a time rather than joined across the scope. `account_balance`
 * is the gateway's hot path, reserved and debited per message; a reseller with fifty children would
 * otherwise put fifty reads on it per page load. A reseller sees its own balance here and each
 * child's on demand.
 */
export async function GET(): Promise<NextResponse> {
  try {
    const session = await requireCustomer();
    const scope = await scopeFor(session);

    const rows = await configQuery<{ id: string; label: string | null; resells: boolean }>(
      "SELECT id, label, resells FROM app_account WHERE id = ANY($1) ORDER BY id",
      [scope]
    );
    const self = rows.find((r) => r.id === session.accountId);
    const balance = await getBalance(session.accountId);

    const data: MisSummary = {
      accountId: session.accountId,
      label: self?.label ?? null,
      resells: session.resells,
      //the reseller's own account is in `scope` too, and is filtered out here rather than in
      //scopeFor -- the message query wants it included, this list does not
      children: rows
        .filter((r) => r.id !== session.accountId)
        .map((r) => ({ id: r.id, label: r.label })),
      //null when prepaid credit is not enforced, or no balance row was ever opened. Those are
      //different from zero and the interface says so rather than showing a confident 0.
      //
      //A string, because money is a scaled integer everywhere in this system and the client
      //formats it by moving characters rather than by arithmetic. `getBalance` has already
      //narrowed the BIGINT to a JS number, so this is the last point at which the digits are
      //still exactly what the column held
      balance: balance
        ? { balance: String(balance.balance), currency: balance.currency }
        : null,
    };

    return NextResponse.json({ data });
  } catch (err) {
    if (err instanceof NotCustomerError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
}
