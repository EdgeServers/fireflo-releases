import type { NextRequest } from "next/server";
import { recordCustomerAccess } from "@/lib/customer-access-log";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { misHandlers } from "@/lib/mis-auth";
import { currentRequestContext, runWithRequestContext } from "@/lib/request-context";

/**
 * The portal's own NextAuth endpoint, mounted away from `/api/auth` so the two instances never
 * share a route any more than they share a cookie.
 *
 * <p>Wrapped for the same reason as the operator instance: `authorize()` redeems the sign-in link
 * and is the only place that knows an account just signed in, but it is handed the token and
 * nothing else. Without the address carried through here, a redeemed link records only `used_at` —
 * so a link redeemed by whoever intercepted the mail looks exactly like the customer using it.
 */

export async function GET(req: NextRequest): Promise<Response> {
  return runWithRequestContext(req, () => misHandlers.GET(req));
}

export async function POST(req: NextRequest): Promise<Response> {
  return runWithRequestContext(req, async () => {
    const response = await misHandlers.POST(req);
    //a password POST that Auth.js refused before authorize() ran -- a missing CSRF token, say. Only
    //those: authorize marks the ones it handled, so a wrong password is not logged twice
    if (req.nextUrl.pathname.endsWith("/callback/password") && !currentRequestContext()?.handled) {
      void recordCustomerAccess({
        event: "password_signin_failed",
        ip: clientIp(req),
        userAgent: clientUserAgent(req),
        detail: { reason: "rejected_before_authorize", status: response.status },
      });
    }
    return response;
  });
}
