import { NextRequest, NextResponse } from "next/server";
import { assertInScope, requireCustomer } from "@/lib/require-customer";
import { notFoundOrThrow, note, rowId } from "@/lib/mis-route";
import { proposedTlvs } from "@/lib/tlv-string";
import { ownerOfTemplate, scopedLogin, updateOwnTemplate, withdrawTemplate } from "@/lib/mis-whitelist";
import { validateTemplate } from "@/lib/whitelist-types";

/**
 * PUT|DELETE /api/mis/templates/{id} — change or withdraw one of the customer's own.
 *
 * <p>The sibling of the sender-ID route and the same rules apply: ownership is proved before the row
 * is touched, editing the wording returns it to `PENDING`, and `tlvs` -- the column the gateway
 * stamps from -- is not accepted from a customer. `requestedTlvs` is, and changes nothing that is
 * served, which is why it does not suspend the row.
 */
type Params = { params: Promise<{ id: string }> };

export async function PUT(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const guard = await scoped(params);
  if ("response" in guard) {
    return guard.response;
  }

  let body: Record<string, unknown> | null;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const text = typeof body?.body === "string" ? body.body.trim() : "";
  const invalid = validateTemplate(text);
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }

  const tlvs = proposedTlvs(body?.requestedTlvs);
  if ("error" in tlvs) {
    return NextResponse.json({ error: tlvs.error }, { status: 400 });
  }

  //the row is already proved to be this account's by `scoped`, so the login is checked against the
  //same account -- a login belonging to a reseller's child is not this row's to move to
  const login = await scopedLogin([guard.accountId], body?.systemId);
  if ("error" in login) {
    return NextResponse.json({ error: login.error }, { status: 400 });
  }

  const suspended = await updateOwnTemplate(
    guard.id, note(body?.name), text, note(body?.requestNote), tlvs.value, login.value
  );
  return NextResponse.json({
    data: {
      saved: true,
      suspended,
      message: suspended
        ? "Sent for approval. It stops being used until an operator approves the change."
        : "Saved. Your operator will see what you have asked for; this one stays in service in the "
          + "meantime, because nothing it sends has changed yet.",
    },
  });
}

export async function DELETE(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const guard = await scoped(params);
  if ("response" in guard) {
    return guard.response;
  }
  await withdrawTemplate(guard.id);
  return NextResponse.json({ data: { withdrawn: true } });
}

async function scoped(
  params: Params["params"]
): Promise<{ id: number; accountId: string } | { response: NextResponse }> {
  try {
    const session = await requireCustomer();
    const id = rowId((await params).id);
    if (id === null) {
      return { response: NextResponse.json({ error: "Not found" }, { status: 404 }) };
    }
    const owner = await ownerOfTemplate(id);
    if (owner === null) {
      return { response: NextResponse.json({ error: "Not found" }, { status: 404 }) };
    }
    await assertInScope(session, owner);
    //the OWNER, not the session's own account: a reseller editing a child's row must
    //scope the login to that child rather than to itself
    return { id, accountId: owner };
  } catch (err) {
    return { response: notFoundOrThrow(err) };
  }
}
