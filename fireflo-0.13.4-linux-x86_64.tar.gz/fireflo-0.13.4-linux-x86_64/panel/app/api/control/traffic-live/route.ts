import { controlRoute } from "@/lib/control-route";
import { liveTraffic } from "@/lib/metrics-queries";

/**
 * GET /api/control/traffic-live?kind=vendor|server[&since=<epoch ms>][&key=<vendor|account>]
 *
 * <p>Receipts in ten-second buckets for the live chart on the Vendors and Servers pages, and
 * submits too when `key` names one vendor or account -- the one case the gateway's own counters
 * cannot answer (see `liveTraffic`). `since` makes the read incremental: the chart keeps what it
 * has and asks only for the slice after its last read. `range` is ignored: the window is fixed,
 * because the chart's queue and MT lines come from live health polls and cannot reach further back
 * than the page has been open.
 */
export const GET = controlRoute((_range, params) => {
  const since = params.get("since");
  const key = params.get("key");
  return liveTraffic(params.get("kind") === "server" ? "server" : "vendor", {
    since: since ? Number(since) : null,
    //bounded, because it lands in a query parameter: neither a worker name nor an account id is
    //anywhere near this long
    key: key && key.length <= 200 ? key : null,
  });
});
