import { NextRequest, NextResponse } from "next/server";
import { guardCdrRoute, queryFailed } from "@/lib/cdr-guard";
import { listArchiveEntries } from "@/lib/archives";
import { isRequestError, parseArchiveEntryFilters } from "@/lib/archives-request";
import type { ArchiveCursor } from "@/lib/archives-types";

/**
 * GET /api/control/archives/entries
 *
 * <p>One page of archived entries, newest first, keyset on `(archived_at, archive_id)`.
 *
 * <p>Guarded like `/rejected` rather than through `controlRoute`, because a refused filter or cursor
 * is a 400 with the sentence, not a 500: the page shows it under the filter bar.
 */
const DEFAULT_PAGE = 50;
const MAX_PAGE = 200;

export async function GET(req: NextRequest): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  const params = new URL(req.url).searchParams;
  const filters = parseArchiveEntryFilters(params);
  if (isRequestError(filters)) {
    return NextResponse.json({ error: filters.error }, { status: 400 });
  }

  const cursorTs = params.get("cursorTs");
  const cursorId = params.get("cursorId");
  if ((cursorTs == null) !== (cursorId == null)) {
    return NextResponse.json({ error: "A cursor needs both cursorTs and cursorId." }, { status: 400 });
  }
  if (cursorId != null && !/^\d+$/.test(cursorId)) {
    return NextResponse.json({ error: "cursorId must be a whole number." }, { status: 400 });
  }
  if (cursorTs != null && Number.isNaN(new Date(cursorTs).getTime())) {
    return NextResponse.json({ error: "cursorTs is not a timestamp." }, { status: 400 });
  }
  const cursor: ArchiveCursor | null =
    cursorTs != null && cursorId != null ? { archivedAt: cursorTs, id: cursorId } : null;

  const limit = Number(params.get("limit") ?? DEFAULT_PAGE);
  if (!Number.isFinite(limit) || limit < 1) {
    return NextResponse.json({ error: "limit must be a positive number." }, { status: 400 });
  }

  try {
    return NextResponse.json({ data: await listArchiveEntries(filters, { limit: Math.min(limit, MAX_PAGE), cursor }) });
  } catch (err) {
    return queryFailed("archived entries", err);
  }
}
