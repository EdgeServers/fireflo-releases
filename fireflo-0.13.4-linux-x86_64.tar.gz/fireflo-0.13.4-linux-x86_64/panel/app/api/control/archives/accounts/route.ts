import { controlRoute } from "@/lib/control-route";
import { listArchiveAccounts } from "@/lib/archives";
import { isRequestError, parseArchiveAccountFilters } from "@/lib/archives-request";

/**
 * GET /api/control/archives/accounts?from=YYYY-MM-DD&to=YYYY-MM-DD&account=&store=
 *
 * <p>The reconciliation view: per account, messages archived, refunded, receipts sent and the price
 * total, from the summary the gateway keeps forever — so the numbers are the same before and after
 * a month's detail is purged.
 */
export const GET = controlRoute(async (_range, params) => {
  const filters = parseArchiveAccountFilters(params);
  if (isRequestError(filters)) {
    //the page's date inputs cannot produce this; a hand-made URL gets the sentence
    throw new Error(filters.error);
  }
  return listArchiveAccounts(filters);
});
