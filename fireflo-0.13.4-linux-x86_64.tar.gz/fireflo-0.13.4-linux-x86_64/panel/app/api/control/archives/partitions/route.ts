import { controlRoute } from "@/lib/control-route";
import { listArchivePartitions } from "@/lib/archives";

/**
 * GET /api/control/archives/partitions
 *
 * <p>The queue archive month by month: rows held, first and last archived, size on disk, and the
 * months whose detail was purged with the count the summary kept. Operator access, read-only; a
 * gateway before V1.93.0 answers `available: false`.
 */
export const GET = controlRoute(async () => listArchivePartitions());
