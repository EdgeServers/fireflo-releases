import { controlRoute } from "@/lib/control-route";
import { listArchiveBatches } from "@/lib/archives";
import { isRequestError, parseBatchFilters } from "@/lib/archives-request";

/**
 * GET /api/control/archives/batches?store=&batch=&limit=
 *
 * <p>The latest runs that wrote to the archive: queue cleans (from the panel or the command line),
 * archive purges and receipt re-pushes. Who, when, why, the selector and the counts.
 */
export const GET = controlRoute(async (_range, params) => {
  const filters = parseBatchFilters(params);
  if (isRequestError(filters)) {
    throw new Error(filters.error);
  }
  return listArchiveBatches(filters);
});
