import { controlRoute } from "@/lib/control-route";
import { accountUsage } from "@/lib/metrics-queries";

export const GET = controlRoute(accountUsage);
