import { NextRequest, NextResponse } from "next/server";
import { guardCdrRoute, queryFailed } from "@/lib/cdr-guard";
import { mtUsageFor } from "@/lib/mt-usage-queries";
import { billingZone } from "@/lib/platform-currency";

type Params = { params: Promise<{ id: string }> };

/**
 * GET /api/control/accounts/{id}/usage — messages, MT parts and charges, for the billing page.
 *
 * <p>Lifetime, this month and today, plus the last ninety days by day and product. Read-only.
 */
export async function GET(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  const accountId = decodeURIComponent((await params).id).trim();
  if (!accountId) {
    return NextResponse.json({ error: "No account given." }, { status: 400 });
  }

  try {
    return NextResponse.json({ data: await mtUsageFor(accountId, await billingZone()) });
  } catch (err) {
    return queryFailed("usage", err);
  }
}
