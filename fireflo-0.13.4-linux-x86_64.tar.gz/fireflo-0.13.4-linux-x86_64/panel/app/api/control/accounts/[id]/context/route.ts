import { NextRequest, NextResponse } from "next/server";
import { accountContext } from "@/lib/account-context";
import { guardCdrRoute, queryFailed } from "@/lib/cdr-guard";

type Params = { params: Promise<{ id: string }> };

/**
 * What one billing account has: balance, recharge log, rate scope, and where its traffic went.
 *
 * <p>Read-only, and there is no sibling that is not. Prepaid credit is added by the billing system
 * inserting a `balance_ledger` row; the gateway applies it. This panel shows that trail and never
 * writes to it.
 *
 * <p>Guarded by {@link guardCdrRoute} rather than the config guard: three of the four lookups are on
 * the metrics database, and without it there is nothing to say.
 */
export async function GET(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  const { id } = await params;
  const account = id.trim();
  if (!account) {
    return NextResponse.json({ error: "No account given." }, { status: 400 });
  }

  try {
    return NextResponse.json({ data: await accountContext(account) });
  } catch (err) {
    return queryFailed("account context", err);
  }
}
