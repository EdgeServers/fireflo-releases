import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardAdminWrite } from "@/lib/config-guard";
import { unarchiveAccount } from "@/lib/account-archive";

type Params = { params: Promise<{ id: string }> };

const TABLES = "app_account and app_credential";

/** Unarchives an account: enabled and listed again, and the logins the archive switched off back on. Admin only. */
export async function POST(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardAdminWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { id } = await params;
  try {
    return NextResponse.json({ data: await unarchiveAccount(decodeURIComponent(id)) });
  } catch (err) {
    return configFailed("unarchive account", err);
  }
}
