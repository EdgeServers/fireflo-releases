import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { requireOperator } from "@/lib/require-operator";
import { DuplicateReference, openBalance, setBillingMode, setCreditEnabled, topUp } from "@/lib/balance";
import { currencyForNewBalance } from "@/lib/platform-currency";
import {
  parseAmount,
  validateBillingChange,
  validateCurrency,
  validateTopUp,
  type BillingMode,
  type TopUpInput,
} from "@/lib/balance-types";

type Params = { params: Promise<{ id: string }> };

const TABLES = "account_balance and balance_ledger";

/**
 * The three things the panel may do to an account's prepaid credit.
 *
 * <p>`open` creates the balance row, `topUp` records a RECHARGE the gateway applies on its next
 * poll, and `enable` switches credit on or off. **None of them write `balance` directly** — the
 * gateway remains the only writer of the live figure, and this route only ever adds to the ledger it
 * reads.
 *
 * <p>The grant is worth knowing about before it fails: the config database user needs INSERT and
 * UPDATE on both tables. A deployment following the README's read-only guidance will not have it,
 * and the error below says so rather than surfacing a driver stack trace.
 */
export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { id } = await params;
  const accountId = decodeURIComponent(id);

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const input = body as {
    action?: string;
    currency?: string;
    enabled?: boolean;
    mode?: string;
    creditLimit?: string;
  } & TopUpInput;

  try {
    const { name: operator } = await requireOperator();

    if (input.action === "open") {
      //resolved here, not taken from the request. The gateway's smsg.rates.currency first, then the
      //PARENT account's own balance -- see chooseCurrency in lib/balance-types.ts. The form shows
      //whichever answered and sends no currency at all in that case, so this is the authority rather
      //than a duplicate of a client-side decision
      const inherited = await currencyForNewBalance(accountId);
      const asked = (input.currency ?? "").trim().toUpperCase();

      let code: string;
      if (inherited.code) {
        //a body that names a DIFFERENT code is refused rather than ignored. Ignoring it would open
        //the row in the right currency while the caller believed otherwise, which is worse than a
        //400: openBalance is ON CONFLICT DO NOTHING, so there is no second chance to notice
        if (asked && asked !== inherited.code) {
          return NextResponse.json(
            {
              error: inherited.from === "gateway"
                ? `This platform's currency is ${inherited.code}, from the gateway's `
                  + `smsg.rates.currency. A balance in ${asked} could never be spent against a `
                  + "price, because nothing converts between the two."
                : inherited.from === "held"
                  ? `Every balance and rate rule on this gateway holds ${inherited.code}, and the `
                    + `gateway refuses a second currency: a balance in ${asked} cannot be opened.`
                  : `The account above this one holds its balance in ${inherited.code}. A child in `
                    + `${asked} could never be funded from it, because nothing converts between the `
                    + "two.",
            },
            { status: 400 }
          );
        }
        code = inherited.code;
      } else {
        //nothing could answer -- in file mode the gateway's value is in smsg.properties, which this
        //panel does not read, and there may be no parent. The operator is asked, and is the only
        //party who can know
        const invalid = validateCurrency(asked);
        if (invalid) {
          return NextResponse.json({ error: invalid }, { status: 400 });
        }
        code = asked;
      }

      const created = await openBalance(accountId, code, input.enabled ?? true);
      return NextResponse.json({
        data: { accountId, created, currency: code },
        //not an error: opening an account that is already open is a no-op rather than a mistake,
        //and saying so is more use than a 409 nobody can act on
        notice: created ? null : "This account already had a balance row; nothing was changed.",
      });
    }

    if (input.action === "enable" || input.action === "disable") {
      const enabled = input.action === "enable";
      const changed = await setCreditEnabled(accountId, enabled);
      return changed
        ? NextResponse.json({ data: { accountId, enabled } })
        : NextResponse.json(
            { error: "This account has no balance row yet. Open it for credit first." },
            { status: 404 }
          );
    }

    if (input.action === "billing") {
      const limit = input.creditLimit ?? "0";
      const invalid = validateBillingChange(input.mode, limit);
      if (invalid) {
        return NextResponse.json({ error: invalid }, { status: 400 });
      }
      const mode = input.mode as BillingMode;
      //parsed, never multiplied -- a credit limit is money and gets the same treatment an amount does
      const scaled = mode === "POSTPAID" ? parseAmount(limit)! : 0;
      const changed = await setBillingMode(accountId, mode, scaled);
      return changed
        ? NextResponse.json({
            data: { accountId, mode, creditLimit: scaled },
            notice: mode === "POSTPAID"
              ? "Postpaid from now on. Nothing is debited; usage accrues against the limit and is "
                + "invoiced in arrears. The gateway applies the change on its next poll."
              : "Prepaid from now on, and the credit limit is cleared. This account spends its "
                + "balance again.",
          })
        : NextResponse.json(
            { error: "This account has no balance row yet. Open it for credit first." },
            { status: 404 }
          );
    }

    if (input.action === "topUp") {
      const invalid = validateTopUp(input);
      if (invalid) {
        return NextResponse.json({ error: invalid }, { status: 400 });
      }
      //parsed rather than multiplied, all the way from the operator's keystrokes to the column
      const scaled = parseAmount(input.amount)!;
      await topUp(accountId, scaled, input.ref, input.note ?? null, operator);
      return NextResponse.json({ data: { accountId, scaled, ref: input.ref.trim() } });
    }

    return NextResponse.json(
      { error: `'${input.action}' is not an action. Use open, topUp, billing, enable or disable.` },
      { status: 400 }
    );
  } catch (err) {
    if (err instanceof DuplicateReference) {
      return NextResponse.json(
        {
          error: `Reference '${err.ref}' has already been recorded, so this top-up was not added `
            + "again. That is the guard against crediting the same payment twice — if this is a "
            + "genuinely different payment, give it its own reference.",
        },
        { status: 409 }
      );
    }
    if (typeof err === "object" && err !== null && (err as { code?: string }).code === "42501") {
      return NextResponse.json(
        {
          error: "The panel's database user may not write account_balance or balance_ledger. Grant "
            + "INSERT and UPDATE on both to the user in CONFIG_DATABASE_URL.",
        },
        { status: 503 }
      );
    }
    return configFailed("prepaid credit", err);
  }
}
