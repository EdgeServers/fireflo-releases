import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { accountActivity } from "@/lib/account-activity";
import type { ActivityFilter } from "@/lib/account-activity-types";

type Params = { params: Promise<{ id: string }> };

const FILTERS: readonly ActivityFilter[] = ["all", "signins", "changes", "money"];
const PAGE = 30;

/**
 * GET /api/control/accounts/{id}/activity?filter=&before=
 *
 * <p>The account's activity history, a page at a time, newest first. `before` is the `next` of the
 * previous page. Operator-only, behind the same guard as the catalogue it sits beside.
 */
export async function GET(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite("app_account");
  if (refused) {
    return refused;
  }
  const { id } = await params;
  const raw = req.nextUrl.searchParams.get("filter") ?? "all";
  const filter = (FILTERS as readonly string[]).includes(raw) ? (raw as ActivityFilter) : "all";
  const beforeRaw = req.nextUrl.searchParams.get("before");
  const before = beforeRaw && !Number.isNaN(Date.parse(beforeRaw)) ? new Date(beforeRaw).toISOString() : null;
  try {
    return NextResponse.json({ data: await accountActivity(id, filter, before, PAGE) });
  } catch (err) {
    return configFailed("account activity", err);
  }
}
