import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardAdminWrite } from "@/lib/config-guard";
import { archiveAccount } from "@/lib/account-archive";
import { requireOperator } from "@/lib/require-operator";

type Params = { params: Promise<{ id: string }> };

const TABLES = "app_account and app_credential";

/**
 * Archives an account: its logins off, the account disabled and stamped archived, its binds dropped
 * and the credit the gateway holds for it returned. Admin only. Refused (400) while it still has
 * active customers of its own. See `lib/account-archive.ts`.
 */
export async function POST(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardAdminWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { id } = await params;
  try {
    const { name } = await requireOperator();
    return NextResponse.json({ data: await archiveAccount(decodeURIComponent(id), name) });
  } catch (err) {
    return configFailed("archive account", err);
  }
}
