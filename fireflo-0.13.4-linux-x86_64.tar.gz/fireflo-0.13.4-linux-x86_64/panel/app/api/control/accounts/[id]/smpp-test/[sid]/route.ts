import { NextRequest, NextResponse } from "next/server";
import { closeSession, readSession } from "@/lib/smpp-test";
import { SESSION_ID, adminOr404 } from "@/lib/smpp-test-route";

type Params = { params: Promise<{ id: string; sid: string }> };

/**
 * GET / DELETE /api/control/accounts/{id}/smpp-test/{sid}
 *
 * <p>GET: the log after `?after=`, polled while the modal is open. DELETE: unbind and close -- what
 * closing the modal does. POST is the same as DELETE, so a closing page can send it as a beacon.
 */
export async function GET(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const admin = await adminOr404();
  if (typeof admin !== "string") {
    return admin;
  }
  const { id, sid } = await params;
  if (!SESSION_ID.test(sid)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  const after = Number(req.nextUrl.searchParams.get("after") ?? 0);
  const state = readSession(sid, admin, id, Number.isFinite(after) ? after : 0);
  return state
    ? NextResponse.json({ data: state })
    : NextResponse.json({ error: "That test session has ended." }, { status: 404 });
}

async function close(params: Params["params"], keep: boolean): Promise<NextResponse> {
  const admin = await adminOr404();
  if (typeof admin !== "string") {
    return admin;
  }
  const { id, sid } = await params;
  if (!SESSION_ID.test(sid)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  const closed = await closeSession(sid, admin, id, keep);
  return NextResponse.json({ data: { closed } });
}

/** `?keep=1` is the Unbind button: unbind, and keep the log to read and download. */
export async function DELETE(req: NextRequest, { params }: Params): Promise<NextResponse> {
  return close(params, req.nextUrl.searchParams.get("keep") === "1");
}

export async function POST(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  return close(params, false);
}
