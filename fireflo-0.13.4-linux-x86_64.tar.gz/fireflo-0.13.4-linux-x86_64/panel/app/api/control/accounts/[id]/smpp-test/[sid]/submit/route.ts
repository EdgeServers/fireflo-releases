import { NextRequest, NextResponse } from "next/server";
import { SmppTestRefused, submit } from "@/lib/smpp-test";
import { SESSION_ID, adminOr404 } from "@/lib/smpp-test-route";
import type { SmsEncoding } from "@/lib/sms-text";

type Params = { params: Promise<{ id: string; sid: string }> };

const ENCODINGS = ["auto", "gsm7", "ucs2", "ascii"] as const;

/** POST /api/control/accounts/{id}/smpp-test/{sid}/submit -- one submit_sm on a bound test session. */
export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const admin = await adminOr404();
  if (typeof admin !== "string") {
    return admin;
  }
  const { id, sid } = await params;
  if (!SESSION_ID.test(sid)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const str = (v: unknown) => (typeof v === "string" ? v : "");
  const byte = (v: unknown, fallback: number) => {
    const n = v === undefined || v === "" ? fallback : Number(v);
    return Number.isInteger(n) && n >= 0 && n <= 255 ? n : fallback;
  };
  const dest = str(body.dest).trim();
  if (!dest) {
    return NextResponse.json({ error: "Enter a destination number." }, { status: 400 });
  }
  const encoding = (ENCODINGS as readonly string[]).includes(str(body.encoding)) ? str(body.encoding) : "auto";
  const tlvs = Array.isArray(body.tlvs)
    ? body.tlvs.filter((t): t is { key: string; value: string } =>
      !!t && typeof t === "object" && typeof (t as { key?: unknown }).key === "string")
      .map((t) => ({ key: t.key, value: typeof t.value === "string" ? t.value : "" }))
    : [];
  try {
    const result = await submit(sid, admin, id, {
      source: str(body.source),
      dest,
      text: str(body.text),
      encoding: encoding as SmsEncoding | "auto",
      registeredDelivery: [0, 1, 2].includes(Number(body.registeredDelivery)) ? Number(body.registeredDelivery) : 1,
      sourceTon: byte(body.sourceTon, 5),
      sourceNpi: byte(body.sourceNpi, 0),
      destTon: byte(body.destTon, 1),
      destNpi: byte(body.destNpi, 1),
      tlvs,
    });
    return NextResponse.json({ data: result });
  } catch (err) {
    if (err instanceof SmppTestRefused) {
      return NextResponse.json({ error: err.message }, { status: 409 });
    }
    return NextResponse.json({ error: err instanceof Error ? err.message : String(err) }, { status: 502 });
  }
}
