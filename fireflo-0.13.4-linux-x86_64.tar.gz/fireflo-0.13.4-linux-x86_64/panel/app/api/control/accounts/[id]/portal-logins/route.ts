import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { getAccount } from "@/lib/accounts";
import { type OperatorEvent, logOperatorEvent } from "@/lib/access-log";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { passwordProblem } from "@/lib/password-policy";
import { requireOperator } from "@/lib/require-operator";
import { CUSTOMER_ROLE } from "@/lib/roles";
import { validateNewUser } from "@/lib/user-types";
import {
  DuplicateUserError,
  createUser,
  listUsers,
  setAccountUserEnabled,
  setAccountUserPassword,
} from "@/lib/users";

type Params = { params: Promise<{ id: string }> };

/**
 * GET / POST / PATCH /api/control/accounts/{id}/portal-logins
 *
 * <p>Everybody who can sign in to the portal for this account, and what each of them can do it
 * with. The account page's Portal access card.
 *
 * <p>Every login, not only the one at the account's own address. An account may have several
 * people, and showing one of them while saying "1 more login" elsewhere was how this card used to
 * contradict itself. Each change names the login by id and is checked against the account in SQL.
 */
async function guard(): Promise<NextResponse | null> {
  return guardConfigWrite("app_account");
}

export async function GET(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guard();
  if (refused) {
    return refused;
  }
  const { id } = await params;
  try {
    const account = await getAccount(id);
    if (!account) {
      return NextResponse.json({ error: `No account '${id}'.` }, { status: 404 });
    }
    const logins = await listUsers({ accountId: id, role: CUSTOMER_ROLE });
    return NextResponse.json({ data: { accountEmail: account.email, logins } });
  } catch (err) {
    return configFailed("portal logins", err);
  }
}

/** Adds a login: `{email, password?}`. Without a password it signs in by emailed link. */
export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guard();
  if (refused) {
    return refused;
  }
  const { id } = await params;
  const body = (await req.json().catch(() => null)) as { email?: unknown; password?: unknown } | null;
  const email = typeof body?.email === "string" ? body.email.trim() : "";
  const password = typeof body?.password === "string" && body.password ? body.password : null;
  const input = { email, role: CUSTOMER_ROLE, accountId: id, password } as const;
  const invalid = validateNewUser(input);
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }
  if (password) {
    const weak = passwordProblem(password, email);
    if (weak) {
      return NextResponse.json({ error: weak }, { status: 400 });
    }
  }
  try {
    if (!(await getAccount(id))) {
      return NextResponse.json({ error: `No account '${id}'.` }, { status: 404 });
    }
    const user = await createUser(input);
    await audit(req, "user_created", { account: id, subject: user.email, password: Boolean(password) });
    return NextResponse.json({ data: user });
  } catch (err) {
    if (err instanceof DuplicateUserError) {
      return NextResponse.json({ error: `${err.message} An address can be one login, on one account.` }, { status: 409 });
    }
    return configFailed("add portal login", err);
  }
}

/** Changes one login: `{userId, password}` or `{userId, clearPassword: true}` or `{userId, enabled}`. */
export async function PATCH(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guard();
  if (refused) {
    return refused;
  }
  const { id } = await params;
  const body = (await req.json().catch(() => null)) as
    | { userId?: unknown; password?: unknown; clearPassword?: unknown; enabled?: unknown }
    | null;
  const userId = Number(body?.userId);
  if (!Number.isInteger(userId) || userId <= 0) {
    return NextResponse.json({ error: "Which login? userId is required." }, { status: 400 });
  }
  try {
    if (typeof body?.enabled === "boolean") {
      const email = await setAccountUserEnabled(id, userId, body.enabled);
      if (!email) {
        return notOnAccount(id);
      }
      await audit(req, "user_updated", { account: id, subject: email, enabled: body.enabled });
      return NextResponse.json({ data: { ok: true } });
    }
    const password = typeof body?.password === "string" && body.password ? body.password : null;
    if (!password && body?.clearPassword !== true) {
      return NextResponse.json({ error: "Nothing to change." }, { status: 400 });
    }
    if (password) {
      //checked against the address it will belong to, once that is known
      const login = (await listUsers({ accountId: id, role: CUSTOMER_ROLE })).find((u) => u.id === userId);
      if (!login) {
        return notOnAccount(id);
      }
      const weak = passwordProblem(password, login.email);
      if (weak) {
        return NextResponse.json({ error: weak }, { status: 400 });
      }
    }
    const email = await setAccountUserPassword(id, userId, password);
    if (!email) {
      return notOnAccount(id);
    }
    await audit(req, "user_password_set", { account: id, subject: email, ...(password ? {} : { cleared: true }) });
    return NextResponse.json({ data: { ok: true } });
  } catch (err) {
    return configFailed("change portal login", err);
  }
}

function notOnAccount(id: string): NextResponse {
  return NextResponse.json({ error: `That login is not on '${id}'.` }, { status: 404 });
}

async function audit(req: NextRequest, event: OperatorEvent, detail: Record<string, unknown>): Promise<void> {
  const operator = await requireOperator();
  void logOperatorEvent({
    event,
    actor: operator.name,
    userId: operator.userId,
    ip: clientIp(req),
    userAgent: clientUserAgent(req),
    detail,
  });
}
