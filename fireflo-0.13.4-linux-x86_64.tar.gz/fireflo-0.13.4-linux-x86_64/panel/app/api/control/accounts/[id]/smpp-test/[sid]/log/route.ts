import { NextRequest, NextResponse } from "next/server";
import { auditedDownload } from "@/lib/access-log";
import { sessionLog } from "@/lib/smpp-test";
import { SESSION_ID, adminOr404 } from "@/lib/smpp-test-route";

type Params = { params: Promise<{ id: string; sid: string }> };

/** GET /api/control/accounts/{id}/smpp-test/{sid}/log -- the test session's log as a text file. */
export async function GET(req: NextRequest, { params }: Params): Promise<NextResponse | Response> {
  const admin = await adminOr404();
  if (typeof admin !== "string") {
    return admin;
  }
  const { id, sid } = await params;
  if (!SESSION_ID.test(sid)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  return auditedDownload(req, { kind: "smpp-test-log", actor: admin, subject: `${id}/${sid}` }, async () => {
    const text = sessionLog(sid, admin, id);
    if (text === null) {
      return NextResponse.json({ error: "That test session has ended." }, { status: 404 });
    }
    return new Response(text, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Content-Disposition": `attachment; filename="smpp-test-${id}-${sid}.txt"`,
        "Cache-Control": "no-store",
      },
    });
  });
}
