import { NextRequest, NextResponse } from "next/server";
import { guardCdrRoute, queryFailed } from "@/lib/cdr-guard";
import { money as formatMoney } from "@/lib/format";
import { billingZone, platformCurrency } from "@/lib/platform-currency";
import { reconcileAccount } from "@/lib/reconcile-queries";

type Params = { params: Promise<{ id: string }> };

/**
 * Whether one account's credit adds up, over its whole lifetime.
 *
 * <p><strong>Read-only, and there is deliberately no write counterpart.</strong> The residual is by
 * definition the part nobody could explain; posting an adjusting entry for it would hide the cause
 * and make the next drift start from a number nobody can audit. The two safe actions this can lead
 * to — releasing stranded reserved credit, and re-running a stuck recharge — already exist as their
 * own endpoints and are named in the attribution rather than performed here.
 *
 * <p>Lifetime, never a period: credit is a running total, and any shorter window would need an
 * opening balance that nothing records.
 */
export async function GET(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  const { id } = await params;
  const accountId = decodeURIComponent(id).trim();
  if (!accountId) {
    return NextResponse.json({ error: "No account given." }, { status: 400 });
  }

  try {
    const [currency, zone] = await Promise.all([platformCurrency(), billingZone()]);
    //the same formatter every other amount on the page goes through, so a discrepancy is written
    //the way the balance beside it is
    const result = await reconcileAccount(accountId, zone, (scaled) =>
      formatMoney(scaled, currency ?? ""));
    if (!result) {
      return NextResponse.json({
        data: null,
        //not an error: an account nobody opened for credit has nothing to reconcile, and saying so
        //is more use than an empty card
        notice: "This account has no balance row, so there is no credit to reconcile.",
      });
    }
    return NextResponse.json({ data: { ...result, zone } });
  } catch (err) {
    return queryFailed("reconcile", err);
  }
}
