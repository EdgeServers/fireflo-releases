import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { AccountInUseError, deleteAccount } from "@/lib/accounts";

type Params = { params: Promise<{ id: string }> };

const TABLES = "app_account";

/**
 * Deletes an account nothing uses any more.
 *
 * <p>Since gateway migration V1.55.0 the account is referenced by foreign key from its logins,
 * balance, ledger, sender IDs, templates and policies, so this refuses (409, with what is in the
 * way) while any of those exist. Call records keep the id after the account is gone.
 */
export async function DELETE(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { id } = await params;
  try {
    const removed = await deleteAccount(decodeURIComponent(id));
    return removed
      ? NextResponse.json({ data: { id } })
      : NextResponse.json({ error: "No catalogue row for that account." }, { status: 404 });
  } catch (err) {
    if (err instanceof AccountInUseError) {
      return NextResponse.json({ error: err.message }, { status: 409 });
    }
    return configFailed("delete account", err);
  }
}
