import { NextResponse } from "next/server";
import { gql } from "@/lib/gateway-graphql";
import { HEALTH } from "@/lib/gateway-queries";
import { flattenHealth, type HealthField } from "@/lib/health-types";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET /api/control/health
 *
 * <p>Proxies the gateway's `health` field. A proxy rather than a direct browser call for two
 * reasons: the shared token stays on the server and never reaches a page, and the operator check
 * happens here rather than being something the gateway would have to learn about.
 *
 * <p>The answer keeps the shape `/ops/health` had: `flattenHealth` spreads the typed fields the
 * gateway now carries beside the snapshot over it, under the names the pages already read.
 */
export async function GET(): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  //the gateway is answering from memory; if it cannot do that in five seconds it is the problem
  //being diagnosed, not a slow query
  return gql<HealthField>({ query: HEALTH, timeoutMs: 5_000, select: flattenHealth });
}
