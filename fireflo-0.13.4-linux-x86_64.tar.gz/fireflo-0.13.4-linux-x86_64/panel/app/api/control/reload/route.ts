import { NextResponse } from "next/server";
import { auditConfigChange } from "@/lib/config-audit";
import { gql } from "@/lib/gateway-graphql";
import { RELOAD } from "@/lib/gateway-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * POST /api/control/reload
 *
 * <p>Asks the gateway to re-read its configuration now rather than at its next poll.
 *
 * <p>Still useful now that the controls push their own changes: this covers a full save, a delete,
 * and anything edited outside the panel, none of which map to a single action.
 */
export async function POST(): Promise<NextResponse> {
  let operator;
  try {
    operator = await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  //the admin token: reload applies whatever configuration has been written, so the gateway counts
  //it as changing what it is doing rather than as a read
  const res = await gql<{ observedAt: string; reloaded: Record<string, string>; adopted: boolean; reason: string | null }>({
    query: RELOAD,
    auth: "admin",
    //the shape `lib/reload.ts` reads: the one camelCase field goes back to the REST spelling
    select: (r) => ({ observed_at: r.observedAt, reloaded: r.reloaded, adopted: r.adopted, reason: r.reason }),
  });
  if (res.ok) {
    //no lib function stands between this route and the gateway, so the audit line is written here
    await auditConfigChange({ domain: "reload", name: "gateway", action: "action:reload" }, operator);
  }
  return res;
}
