import { NextResponse } from "next/server";
import { gql } from "@/lib/gateway-graphql";
import { snakeCaseKeysDeep } from "@/lib/gateway-graphql-core";
import { BIND_HOLDS } from "@/lib/gateway-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET /api/control/bind-holds
 *
 * <p>The IPs, accounts and logins an operator is holding out of SMPP binds, from the gateway. The
 * `BindHold` type is camelCase; the page reads `created_by`, so the rows are converted here.
 */
export async function GET(): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) return NextResponse.json({ error: "Not found" }, { status: 404 });
    throw err;
  }
  return gql<unknown[]>({ query: BIND_HOLDS, timeoutMs: 5_000, select: snakeCaseKeysDeep });
}
