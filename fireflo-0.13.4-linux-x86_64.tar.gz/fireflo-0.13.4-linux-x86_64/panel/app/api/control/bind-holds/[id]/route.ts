import { NextRequest, NextResponse } from "next/server";
import { auditConfigChange } from "@/lib/config-audit";
import { gql } from "@/lib/gateway-graphql";
import { BIND_HOLD_LIFT } from "@/lib/gateway-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

type Params = { params: Promise<{ id: string }> };

/**
 * DELETE /api/control/bind-holds/{id}
 *
 * <p>Lifts a hold: the client may bind again at once on this node, and on the others within ten
 * seconds. The admin token; the operator's address is recorded as who lifted it.
 */
export async function DELETE(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  let operator;
  try {
    operator = await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) return NextResponse.json({ error: "Not found" }, { status: 404 });
    throw err;
  }
  const { id } = await params;
  if (!/^-?\d+$/.test(id)) return NextResponse.json({ error: "A hold id is a number." }, { status: 400 });
  const res = await gql({
    query: BIND_HOLD_LIFT,
    variables: { id, by: operator.name },
    auth: "admin",
    timeoutMs: 10_000,
  });
  if (res.ok) {
    //lifting a hold undoes a security control, the same way an unban does; the gateway's `by` and
    //this line should agree
    await auditConfigChange({ domain: "bind_hold", name: id, action: "delete" }, operator);
  }
  return res;
}
