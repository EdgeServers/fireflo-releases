import { controlRoute } from "@/lib/control-route";
import { receiptQuality } from "@/lib/receipt-queries";

/**
 * How well each vendor reports on the traffic it carries.
 *
 * <p>One payload for both surfaces — the comparison report and the per-vendor line on `/cp/vendors`
 * — so the two cannot disagree about a vendor's reporting rate.
 */
export const GET = controlRoute(receiptQuality);
