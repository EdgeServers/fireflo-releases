import { NextResponse } from "next/server";
import { auditConfigChange } from "@/lib/config-audit";
import { startRepush } from "@/lib/housekeeping-ops";
import { NotOperatorError, requireAdmin } from "@/lib/require-operator";
import { REPUSH_STATES, readJobId, repushBody, repushProblem, type RepushForm } from "@/lib/receipt-repush";

/**
 * POST /api/control/receipts/repush
 *
 * <p>Re-sends one SMPP login's delivery receipts for a period: a dry run answers what would go and
 * whether the login is bound; otherwise the gateway starts a paced job and answers its id. Proxies
 * `POST /ops/receipts/repush` with the admin token.
 *
 * <p>Admin only, dry run included: even the count is a statement about one customer's traffic made
 * on behalf of an action only an admin may take. The actor is the signed-in user, never the browser's
 * choice, and a started job is written to the operator log.
 */
export async function POST(req: Request): Promise<NextResponse> {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const raw = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  const systemId = typeof raw?.systemId === "string" ? raw.systemId.trim() : "";
  if (!raw || !systemId || /\s/.test(systemId)) {
    return NextResponse.json({ error: "Name the SMPP login (system id) to re-send to." }, { status: 400 });
  }
  const form: RepushForm = {
    since: typeof raw.since === "string" ? raw.since : "",
    until: typeof raw.until === "string" ? raw.until : "",
    //absent means every outcome, the gateway's own default; an empty list sent on purpose is refused
    states: Array.isArray(raw.states)
      ? raw.states.filter((s): s is string => typeof s === "string")
      : REPUSH_STATES.map((s) => s.value),
    includeProgress: raw.includeProgress === true,
    tps: String(raw.tps ?? ""),
    note: typeof raw.note === "string" ? raw.note : "",
  };
  const problem = repushProblem(form);
  if (problem) {
    return NextResponse.json({ error: problem }, { status: 400 });
  }
  const dryRun = raw.dryRun !== false;
  const body = repushBody(systemId, form, { dryRun, actor: admin.name });
  const res = await startRepush(body);

  if (!dryRun && res.ok) {
    const jobId = readJobId((await res.clone().json().catch(() => null))?.data);
    await auditConfigChange(
      {
        domain: "receipt_repush",
        name: systemId,
        action: "action:repush",
        account: typeof raw.account === "string" ? raw.account : null,
        after: {
          jobId,
          since: body.since,
          until: body.until,
          states: body.states ?? "all",
          includeProgress: body.includeProgress ?? false,
          tps: body.tps,
          note: body.note ?? null,
        },
      },
      admin
    );
  }
  return res;
}
