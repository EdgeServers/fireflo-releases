import { NextResponse } from "next/server";
import { auditConfigChange } from "@/lib/config-audit";
import { cancelRepush, repushStatus } from "@/lib/housekeeping-ops";
import { NotOperatorError, requireAdmin, requireOperator } from "@/lib/require-operator";
import { isJobId } from "@/lib/receipt-repush";

/**
 * GET /api/control/receipts/repush/{jobId} — a re-push job's progress (read token; any operator).
 * DELETE — cancels it (admin token; admins only). Receipts already sent stay sent.
 */
type Params = { params: Promise<{ jobId: string }> };

function notFound(): NextResponse {
  return NextResponse.json({ error: "Not found" }, { status: 404 });
}

export async function GET(_req: Request, { params }: Params): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) return notFound();
    throw err;
  }
  const { jobId } = await params;
  if (!isJobId(jobId)) {
    return NextResponse.json({ error: "That is not a job id." }, { status: 400 });
  }
  return repushStatus(jobId);
}

export async function DELETE(_req: Request, { params }: Params): Promise<NextResponse> {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (err) {
    if (err instanceof NotOperatorError) return notFound();
    throw err;
  }
  const { jobId } = await params;
  if (!isJobId(jobId)) {
    return NextResponse.json({ error: "That is not a job id." }, { status: 400 });
  }
  const res = await cancelRepush(jobId);
  if (res.ok) {
    await auditConfigChange({ domain: "receipt_repush", name: jobId, action: "action:repush-cancel" }, admin);
  }
  return res;
}
