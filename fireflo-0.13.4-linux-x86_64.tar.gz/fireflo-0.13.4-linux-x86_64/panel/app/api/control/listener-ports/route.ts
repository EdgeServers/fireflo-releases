import { NextResponse } from "next/server";
import { gqlData } from "@/lib/gateway-graphql";
import { HEALTH } from "@/lib/gateway-queries";
import type { HealthField } from "@/lib/health-types";
import { nextFreePort, parsePortRange } from "@/lib/port-range";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { listListenerPorts } from "@/lib/workers";

/**
 * GET /api/control/listener-ports
 *
 * <p>What the listener form needs to choose a port: the band the gateway allows, the ports already
 * spoken for, and the lowest free one.
 *
 * <p>The band comes from the gateway rather than the panel's own environment, because the gateway is
 * what enforces it — a second copy here would be a number that silently disagreed the day one of
 * them was edited. The used ports come from the database, because a port belongs to a listener as
 * soon as it is configured, whether or not that listener is currently running.
 *
 * <p>An unreachable gateway is not an error here. It means no band is known, so the form falls back
 * to accepting any port — the same answer as a gateway that declares none, and better than blocking
 * the creation of a listener because the management port happened to be down.
 */
export async function GET(): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  let rangeText: string | null = null;
  try {
    const health = await gqlData<HealthField>({ query: HEALTH, timeoutMs: 5_000 });
    rangeText = health.snapshot?.smpp_port_range ?? null;
  } catch {
    //deliberately swallowed: see the note above about an unreachable gateway
  }

  let used: { name: string; port: number }[] = [];
  try {
    used = await listListenerPorts();
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Could not read the configured listeners." },
      { status: 500 }
    );
  }

  const range = parsePortRange(rangeText);
  return NextResponse.json({
    data: {
      range: rangeText,
      low: range?.low ?? null,
      high: range?.high ?? null,
      used,
      suggested: nextFreePort(range, used.map((u) => u.port)),
    },
  });
}
