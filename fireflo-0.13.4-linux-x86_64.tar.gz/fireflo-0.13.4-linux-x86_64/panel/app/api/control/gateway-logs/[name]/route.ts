import { NextRequest, NextResponse } from "next/server";
import { gql } from "@/lib/gateway-graphql";
import { snakeCaseKeys } from "@/lib/gateway-graphql-core";
import { LOG_TAIL } from "@/lib/gateway-queries";
import { isLogName, LOG_NAMES } from "@/lib/gateway-files-types";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

type Params = { params: Promise<{ name: string }> };

/**
 * GET /api/control/gateway-logs/[name]?lines=&contains=
 *
 * <p>The tail of one of the gateway's logs.
 *
 * <p><strong>The name is checked against the allow-list before it is sent.</strong> The gateway
 * resolves names through its own catalogue and never touches a caller-supplied path, so this is the
 * second of two refusals rather than the only one — but a route that forwards browser input to the
 * gateway should be the one place that cannot be talked into it.
 *
 * <p>The two query parameters are rebuilt as variables rather than forwarded wholesale, so nothing
 * else the browser sends reaches the gateway. The typed `LogTail` is camelCase; the page reads
 * `returned_lines`, so it is converted here.
 */
export async function GET(request: NextRequest, { params }: Params): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const { name } = await params;
  if (!isLogName(name)) {
    return NextResponse.json(
      { error: `No such log. Readable logs are: ${LOG_NAMES.join(", ")}` },
      { status: 404 }
    );
  }

  const variables: Record<string, unknown> = { name };
  const lines = request.nextUrl.searchParams.get("lines");
  if (lines && /^\d+$/.test(lines)) {
    //the gateway's own clamp is the authority on how many; this only keeps the parameter numeric
    variables.lines = Number(lines);
  }
  const contains = request.nextUrl.searchParams.get("contains");
  if (contains && contains.trim()) {
    variables.contains = contains.trim();
  }

  //one seek and a megabyte, however large the log. Ten seconds is generous and covers a cold cache
  return gql<Record<string, unknown>>({
    query: LOG_TAIL,
    variables,
    auth: "admin",
    timeoutMs: 10_000,
    select: snakeCaseKeys,
  });
}
