import { NextResponse } from "next/server";
import { callMetricsText } from "@/lib/gateway-graphql";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { toSnapshot } from "@/lib/runtime-metrics";

/**
 * GET /api/control/metrics
 *
 * <p>The gateway's `/q/metrics`, parsed and grouped. Parsing happens here rather than in the browser
 * for two reasons: it keeps 20 KB of exposition text off the wire on every poll, and it puts the one
 * piece of real logic in a single place instead of in a component.
 *
 * <p>Uses `callMetricsText`, not `gql`. The latter parses a GraphQL envelope and would turn this
 * `text/plain` body into an error about the envelope — or worse, an empty dashboard with nothing
 * to explain it.
 *
 * <p>Since gateway 0.13 `/q/metrics` is on the gateway's MAIN port (`GATEWAY_BASE_URL`), not the
 * management port, and is behind the ops read token. The helper knows both.
 */
export async function GET(): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  //reading its own counters; five seconds is already generous
  const result = await callMetricsText({ timeoutMs: 5_000 });
  if ("failed" in result) {
    return result.failed;
  }

  return NextResponse.json({ data: toSnapshot(result.text, new Date().toISOString()) });
}
