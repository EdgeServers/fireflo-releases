import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { deleteRouteTable } from "@/lib/routing";

const TABLES = "app_route_table";

/**
 * Removes a routing table and its rules.
 *
 * <p>Rules in *other* tables that chain into this one are left pointing at a name that no longer
 * resolves. There is no foreign key to prevent that — `target` legitimately holds worker names too —
 * so the editor flags dead targets instead.
 */
export async function DELETE(
  _req: NextRequest,
  context: { params: Promise<{ name: string }> }
): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { name } = await context.params;
  try {
    const removed = await deleteRouteTable(decodeURIComponent(name));
    if (!removed) {
      return NextResponse.json({ error: `No routing table called '${name}'.` }, { status: 404 });
    }
    return NextResponse.json({ data: { name } });
  } catch (err) {
    return configFailed("delete routing table", err);
  }
}
