import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { setRouteRuleEnabled } from "@/lib/routing";

type Params = { params: Promise<{ name: string; id: string }> };

const TABLES = "app_route_rule";

/**
 * Turns one routing rule on or off, without touching the order or any other rule in the table.
 *
 * <p>Same shape as `app/api/control/rates/[scope]/rules/[id]/route.ts` for the same reason: a rule
 * an operator needs to kill during an incident should not require re-sending the whole table through
 * `RouteTableForm` to do it.
 */
export async function PATCH(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { name, id } = await params;

  if (!/^\d+$/.test(id)) {
    return NextResponse.json({ error: "A rule id is a whole number." }, { status: 400 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const enabled = (body as Record<string, unknown>)?.enabled;
  if (typeof enabled !== "boolean") {
    return NextResponse.json({ error: "Expected { enabled: true | false }." }, { status: 400 });
  }

  try {
    //scoped by both, so a rule id from another table cannot be flipped through this path
    const found = await setRouteRuleEnabled(name, Number(id), enabled);
    return found
      ? NextResponse.json({ data: { table: name, id: Number(id), enabled } })
      : NextResponse.json({ error: `No rule ${id} in '${name}'.` }, { status: 404 });
  } catch (err) {
    return configFailed("routing", err);
  }
}
