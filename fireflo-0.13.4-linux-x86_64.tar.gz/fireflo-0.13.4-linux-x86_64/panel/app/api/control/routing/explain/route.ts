import { NextRequest, NextResponse } from "next/server";
import { gql } from "@/lib/gateway-graphql";
import { ROUTING_EXPLAIN } from "@/lib/gateway-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

const FIELDS = ["table", "from", "to", "type", "product", "ingateway", "account"];

/**
 * GET /api/control/routing/explain
 *
 * <p>Proxies the gateway's dry-run routing tester, the `routingExplain` field. The read token, not
 * the admin one — this evaluates a hypothetical message against the live table set and sends
 * nothing, exactly the reasoning `whitelistTest` is on the same token for.
 *
 * <p>Answers the gateway's own question, not this panel's guess at it: `RoutingExplanation` is built
 * from `RoutingRule.matches`/`explainMismatch`, the same two methods `StandardRoutingManager` calls
 * on real traffic, so a table edited and not yet polled or a rule this panel resolved differently
 * cannot make the two disagree.
 */
export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const variables: Record<string, string> = {};
  for (const field of FIELDS) {
    const value = request.nextUrl.searchParams.get(field);
    if (value) {
      variables[field] = value;
    }
  }

  return gql({ query: ROUTING_EXPLAIN, variables, timeoutMs: 5_000 });
}
