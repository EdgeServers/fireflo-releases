import { NextRequest, NextResponse } from "next/server";
import { gql } from "@/lib/gateway-graphql";
import { RATING_EXPLAIN } from "@/lib/gateway-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

const FIELDS = ["account", "to", "from", "product", "vendor", "content"];

/**
 * GET /api/control/rating/explain
 *
 * <p>The message tester's Pricing tab: what an account would pay, and what a vendor would charge. Proxies the gateway's `ratingExplain` field on the read token: it evaluates a message
 * nobody sends against the live configuration, and changes nothing.
 */
export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const variables: Record<string, string> = {};
  for (const field of FIELDS) {
    const value = request.nextUrl.searchParams.get(field);
    if (value) {
      variables[field] = value.slice(0, 2000);
    }
  }
  return gql({ query: RATING_EXPLAIN, variables, timeoutMs: 5_000 });
}
