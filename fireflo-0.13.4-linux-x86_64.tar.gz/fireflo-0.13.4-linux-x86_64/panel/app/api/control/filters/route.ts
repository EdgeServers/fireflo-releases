import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { listFilters, saveFilter } from "@/lib/filters";
import { type FilterInput, validateFilter } from "@/lib/filter-types";
import type { ConditionInput } from "@/lib/rate-types";

const TABLES = "app_filter, app_filter_condition";

/**
 * The filter library.
 *
 * <p>Each filter comes back with how many rate rules and routing rules reference it, because those
 * counts are what a disable or a delete has to be judged against — a filter is not an isolated
 * object, it is a clause several rules depend on.
 */
export async function GET(): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  try {
    return NextResponse.json({ data: { filters: await listFilters() } });
  } catch (err) {
    return configFailed("filters", err);
  }
}

/**
 * Creates or replaces one filter.
 *
 * <p>One verb for both, matching the account catalogue: a filter is identified by its name, so
 * creating one and rewriting one are the same write and the caller should not have to know which it
 * is doing.
 */
export async function PUT(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const raw = body as {
    name?: unknown; label?: unknown; enabled?: unknown; conditions?: unknown;
  };
  const input: FilterInput = {
    name: typeof raw.name === "string" ? raw.name : "",
    label: typeof raw.label === "string" ? raw.label : null,
    enabled: raw.enabled !== false,
    conditions: Array.isArray(raw.conditions) ? (raw.conditions as ConditionInput[]) : [],
  };

  const invalid = validateFilter(input);
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }

  try {
    await saveFilter(input);
    return NextResponse.json({ data: { name: input.name.trim() } });
  } catch (err) {
    return configFailed("save filter", err);
  }
}
