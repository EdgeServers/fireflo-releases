import { NextRequest, NextResponse } from "next/server";
import { gql } from "@/lib/gateway-graphql";
import { FILTERS_TEST } from "@/lib/gateway-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

const FIELDS = ["to", "from", "product", "account", "type"];

/**
 * GET /api/control/filters/test
 *
 * <p>The message tester's Filters tab: every named filter against one message. Proxies the gateway's `filtersTest` field on the read token: it evaluates a message
 * nobody sends against the live configuration, and changes nothing.
 */
export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const variables: Record<string, string> = {};
  for (const field of FIELDS) {
    const value = request.nextUrl.searchParams.get(field);
    if (value) {
      variables[field] = value.slice(0, 2000);
    }
  }
  return gql({ query: FILTERS_TEST, variables, timeoutMs: 5_000 });
}
