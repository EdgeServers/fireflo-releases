import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { FilterInUse, deleteFilter } from "@/lib/filters";

const TABLES = "app_filter";

/**
 * Removes a filter, if nothing references it.
 *
 * <p>The refusal is the interesting path. `app_rate_rule_filter` and `app_route_rule_filter`
 * reference `app_filter` with no `ON DELETE`, so the database blocks this — and it should, because
 * dropping the reference instead would turn a narrowed rule into one that matches everything. The
 * 409 says which rules to detach first rather than reporting a constraint name.
 */
export async function DELETE(
  _req: NextRequest,
  context: { params: Promise<{ name: string }> }
): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { name } = await context.params;
  try {
    const removed = await deleteFilter(decodeURIComponent(name));
    if (!removed) {
      return NextResponse.json({ error: `No filter called '${name}'.` }, { status: 404 });
    }
    return NextResponse.json({ data: { name } });
  } catch (err) {
    if (err instanceof FilterInUse) {
      return NextResponse.json(
        {
          error: `'${err.filterName}' is still used by at least one rule. Detach it from those rules `
            + "first — removing it here would leave them matching every message instead of the ones "
            + "the filter narrowed them to.",
        },
        { status: 409 }
      );
    }
    return configFailed("delete filter", err);
  }
}
