import { controlRoute } from "@/lib/control-route";
import { trafficOverTime } from "@/lib/metrics-queries";

//the range alone: controlRoute hands the handler the query string as a second argument, and
//trafficOverTime's second argument is its options
export const GET = controlRoute((range) => trafficOverTime(range));
