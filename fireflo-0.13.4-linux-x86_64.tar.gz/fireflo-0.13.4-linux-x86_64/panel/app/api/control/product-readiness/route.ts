import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { listLoginProducts } from "@/lib/credentials";
import { listProducts } from "@/lib/products";
import { productGapSummary, productGaps } from "@/lib/product-readiness";

const TABLES = "app_credential, app_product";

/**
 * What would stop connecting if a listener began requiring a product.
 *
 * <p>Read before switching `conf.product.required` on. That setting refuses a bind whose product is
 * blank or names no enabled row in `app_product` — worth having, because an unset or misspelt
 * product matches only the rate rules that carry no product and so sends without being charged, but
 * switching it on blind refuses everything already wrong at once.
 *
 * <p>The verdict is computed here rather than in the browser, so the catalogue does not have to
 * cross the wire to be compared against.
 *
 * <p>`?account=` narrows it to one account for the account page. Everything else is the same
 * question at a different grain, so there is one route and one rule rather than two of each.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  try {
    const account = req.nextUrl.searchParams.get("account")?.trim() || undefined;
    const [logins, catalogue] = await Promise.all([listLoginProducts(account), listProducts()]);

    const gaps = productGaps({
      logins,
      catalogue: catalogue.map((p) => p.name),
      //the gateway loads WHERE enabled, so an unlisted product is refused exactly as an unknown one
      //is -- but the fix is different, and the sentence has to say which
      disabled: catalogue.filter((p) => !p.enabled).map((p) => p.name),
    });

    const smppPresent = logins.some((l) => l.type === "SMPP");
    return NextResponse.json({
      data: { gaps, summary: productGapSummary(gaps, smppPresent), checked: logins.length },
    });
  } catch (err) {
    return configFailed("product readiness", err);
  }
}
