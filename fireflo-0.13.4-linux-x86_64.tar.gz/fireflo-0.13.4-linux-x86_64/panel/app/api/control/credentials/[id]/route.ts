import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { credentialContext, deleteCredential, saveCredential, setCredentialEnabled } from "@/lib/credentials";
import { validateCredential } from "@/lib/credential-types";
import { disconnectBindsFor } from "@/lib/gateway-sessions";
import { parse } from "../route";

type Params = { params: Promise<{ id: string }> };

const TABLES = "app_credential";

export async function PUT(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { id } = await params;
  if (!/^\d+$/.test(id)) {
    return NextResponse.json({ error: "A credential id is a whole number." }, { status: 400 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const parsed = parse(body);
  if (typeof parsed === "string") {
    return NextResponse.json({ error: parsed }, { status: 400 });
  }
  //the path is the identity; anything in the body claiming otherwise is ignored
  const input = { ...parsed, id: Number(id) };

  const invalid = validateCredential(input, await credentialContext());
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }

  try {
    await saveCredential(input);
    return NextResponse.json({ data: { id: Number(id) } });
  } catch (err) {
    if (err instanceof Error && !/relation|permission|syntax/i.test(err.message)) {
      return NextResponse.json({ error: err.message }, { status: 400 });
    }
    return configFailed("credentials", err);
  }
}

/**
 * Turns one credential on or off.
 *
 * <p>Separate from the whole-row PUT because stopping a customer is what someone does in a hurry, and
 * it must not require the browser to hold a complete and current copy of the row — which for a
 * credential would mean round-tripping decisions about its secrets to do something unrelated to them.
 *
 * <p><strong>Disabling an SMPP login also drops the binds it is already holding.</strong> Stored
 * `enabled` governs future binds and nothing else, so without this a disabled login went grey in the
 * table while the customer carried on submitting on the session they had — which is not what anyone
 * pressing that button believes they are doing.
 */
export async function PATCH(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { id } = await params;
  if (!/^\d+$/.test(id)) {
    return NextResponse.json({ error: "A credential id is a whole number." }, { status: 400 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const enabled = (body as Record<string, unknown>)?.enabled;
  if (typeof enabled !== "boolean") {
    return NextResponse.json({ error: "Expected { enabled: true | false }." }, { status: 400 });
  }

  try {
    const found = await setCredentialEnabled(Number(id), enabled);
    if (!found) {
      return NextResponse.json({ error: `No credential ${id}.` }, { status: 404 });
    }
    if (enabled || found.type !== "SMPP" || !found.systemId) {
      return NextResponse.json({ data: { id: Number(id), enabled } });
    }

    //switching a login off used to be a statement about future binds only: a customer already bound
    //kept submitting on that session until it dropped on its own. Somebody disabling a login in a
    //hurry means both, so the live binds go with it. Best effort -- the stored change is the durable
    //part and stands whatever the gateway says
    const teardown = await disconnectBindsFor(found.systemId);
    return NextResponse.json({
      data: { id: Number(id), enabled, disconnected: teardown.dropped },
      ...(teardown.problem
        ? {
            notice: `Saved, and this login will stop binding within the gateway's poll interval. `
              + `Its live sessions could not be dropped now (${teardown.problem}), so anything `
              + `already bound may keep sending until it reconnects.`,
          }
        : {}),
    });
  } catch (err) {
    //re-enabling can hit uq_app_credential_smpp, which is partial on `enabled` -- disabling a
    //credential frees its system_id, another row can take it, and turning the first back on then
    //fails with a duplicate key from a statement that looks unrelated
    if (err instanceof Error && /duplicate key/i.test(err.message)) {
      return NextResponse.json(
        {
          error: "Another enabled credential has taken this one's system ID while it was off. The "
            + "unique index only covers enabled rows, so disabling released it. Change one of the two.",
        },
        { status: 409 }
      );
    }
    return configFailed("credentials", err);
  }
}

export async function DELETE(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { id } = await params;
  if (!/^\d+$/.test(id)) {
    return NextResponse.json({ error: "A credential id is a whole number." }, { status: 400 });
  }

  try {
    const gone = await deleteCredential(Number(id));
    return gone
      ? NextResponse.json({ data: { id: Number(id), deleted: true } })
      : NextResponse.json({ error: `No credential ${id}.` }, { status: 404 });
  } catch (err) {
    return configFailed("credentials", err);
  }
}
