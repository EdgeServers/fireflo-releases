import { NextRequest, NextResponse } from "next/server";
import { logOperatorEvent } from "@/lib/access-log";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { isConfigWritable } from "@/lib/config-db";
import {
  MASKED_PASSWORD,
  composeInstructions,
  instructionProblem,
  type InstructionInput,
} from "@/lib/connection-instructions";
import { loadInstructionSource, publicDefaults, type InstructionSource } from "@/lib/connection-instructions-db";
import { describeMailError, mailerConfigured, sendConnectionInstructions } from "@/lib/mailer";
import { NotOperatorError, requireOperator, type OperatorIdentity } from "@/lib/require-operator";

/**
 * A login's connection details, as a mail to its customer.
 *
 * <p>GET is what the dialog opens with: the listeners to choose from, the address and recipient to
 * start with, and whether this panel can send mail at all. POST does one of three things with the
 * operator's choices -- `preview` (password masked), `copy` (the text as it would go out) and
 * `send`. The text is always composed here, never in the browser, so the password only leaves the
 * database for a mail or for a Copy the operator pressed.
 */

type Params = { params: Promise<{ id: string }> };

/** Enough for a customer's team; more than this is a mailing list, which this is not. */
const MAX_RECIPIENTS = 10;
const EMAIL = /^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$/;

async function guard(): Promise<OperatorIdentity | NextResponse> {
  try {
    const who = await requireOperator();
    if (!isConfigWritable()) {
      return NextResponse.json(
        { error: "CONFIG_DATABASE_URL is not set, so logins cannot be read." },
        { status: 503 }
      );
    }
    return who;
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
}

async function source(raw: string): Promise<InstructionSource | NextResponse> {
  if (!/^\d+$/.test(raw)) {
    return NextResponse.json({ error: "A credential id is a whole number." }, { status: 400 });
  }
  const found = await loadInstructionSource(Number(raw));
  if (!found) {
    return NextResponse.json(
      { error: "That login does not exist, or has no system ID a customer could connect with." },
      { status: 404 }
    );
  }
  return found;
}

/** The username as the browser may see it: an API key is a secret, a system id is not. */
function shownUsername(s: InstructionSource): string {
  return s.usernameIsSecret ? MASKED_PASSWORD : s.username;
}

export async function GET(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const who = await guard();
  if (who instanceof NextResponse) {
    return who;
  }
  const s = await source((await params).id);
  if (s instanceof NextResponse) {
    return s;
  }
  const defaults = publicDefaults();
  return NextResponse.json({
    data: {
      type: s.type,
      account: s.account,
      hasPassword: s.password !== null || s.passwordProblem !== null,
      servers: s.servers,
      host: defaults.host,
      restUrl: defaults.restUrl,
      to: s.account.email ? [s.account.email] : [],
      smtp: mailerConfigured(),
    },
  });
}

interface Choices {
  action: "preview" | "copy" | "send";
  host: string;
  restUrl: string;
  servers: string[];
  includePassword: boolean;
  note: string;
  to: string[];
}

function parse(body: unknown): Choices | string {
  if (!body || typeof body !== "object") {
    return "Expected a JSON body.";
  }
  const b = body as Record<string, unknown>;
  if (b.action !== "preview" && b.action !== "copy" && b.action !== "send") {
    return "action is preview, copy or send.";
  }
  const strings = (v: unknown) => (Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : []);
  const text = (v: unknown, max: number) => (typeof v === "string" ? v.slice(0, max) : "");
  return {
    action: b.action,
    host: text(b.host, 253).trim(),
    restUrl: text(b.restUrl, 512).trim(),
    servers: strings(b.servers),
    includePassword: b.includePassword === true,
    note: text(b.note, 2000),
    to: strings(b.to).map((t) => t.trim()).filter(Boolean),
  };
}

export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const who = await guard();
  if (who instanceof NextResponse) {
    return who;
  }
  const s = await source((await params).id);
  if (s instanceof NextResponse) {
    return s;
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const choice = parse(body);
  if (typeof choice === "string") {
    return NextResponse.json({ error: choice }, { status: 400 });
  }

  //the listeners in the order the dialog lists them, and only ones that exist and are enabled now --
  //a name the browser sends is a choice, not a fact
  //one listener, and its address from its own settings rather than anything typed in the browser:
  //the instructions name the server the customer is assigned, at the address it really answers on
  const chosen = s.servers.filter((srv) => srv.name === choice.servers[0]).slice(0, 1);
  const reveal = choice.action !== "preview";
  //a password sealed with a key this panel does not have cannot be put in a message
  if (choice.includePassword && reveal && s.passwordProblem) {
    return NextResponse.json({ error: s.passwordProblem }, { status: 400 });
  }
  const input: InstructionInput = {
    accountLabel: s.account.label,
    type: s.type,
    username: reveal ? s.username : shownUsername(s),
    password: choice.includePassword && s.password !== null ? (reveal ? s.password : MASKED_PASSWORD) : null,
    hasPassword: s.password !== null || s.passwordProblem !== null,
    allowedIps: s.allowedIps,
    product: s.product,
    host: chosen[0]?.host ?? "",
    servers: chosen,
    restUrl: choice.restUrl,
    note: choice.note,
  };

  const problem = instructionProblem(input);
  if (problem && choice.action !== "preview") {
    return NextResponse.json({ error: problem }, { status: 400 });
  }
  const mail = composeInstructions(input);
  if (choice.action !== "send") {
    return NextResponse.json({ data: { ...mail, problem } });
  }

  if (choice.to.length === 0) {
    return NextResponse.json({ error: "Add at least one recipient." }, { status: 400 });
  }
  if (choice.to.length > MAX_RECIPIENTS) {
    return NextResponse.json({ error: `Send to at most ${MAX_RECIPIENTS} addresses.` }, { status: 400 });
  }
  const bad = choice.to.find((t) => !EMAIL.test(t));
  if (bad) {
    return NextResponse.json({ error: `"${bad}" is not an email address.` }, { status: 400 });
  }
  if (!mailerConfigured()) {
    return NextResponse.json(
      { error: "This panel has no mail server set (FIREFLO_SMTP_HOST and FIREFLO_SMTP_FROM). Use Copy text instead." },
      { status: 503 }
    );
  }

  try {
    await sendConnectionInstructions(choice.to, mail.subject, mail.text, EMAIL.test(who.name) ? who.name : undefined);
  } catch (err) {
    console.error("connection instructions not sent", describeMailError(err));
    return NextResponse.json(
      { error: `The mail server refused it: ${describeMailError(err).message}` },
      { status: 502 }
    );
  }

  void logOperatorEvent({
    event: "connection_instructions_sent",
    actor: who.name,
    userId: who.userId,
    ip: clientIp(req),
    userAgent: clientUserAgent(req),
    detail: {
      credentialId: s.credentialId,
      account: s.account.id,
      //never the API key: for an HTTP login that is the username, and it is a credential
      login: s.usernameIsSecret ? `HTTP #${s.credentialId}` : s.username,
      to: choice.to,
      servers: chosen.map((c) => c.name),
      passwordIncluded: input.password !== null,
    },
  });
  return NextResponse.json({ data: { sent: choice.to } });
}
