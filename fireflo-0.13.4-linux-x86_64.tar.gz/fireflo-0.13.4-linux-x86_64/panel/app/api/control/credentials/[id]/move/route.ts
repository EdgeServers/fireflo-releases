import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { moveCredential } from "@/lib/account-archive";

type Params = { params: Promise<{ id: string }> };

/**
 * Gives a login to another account: `{ "to": "<account id>" }`. Refused (400) while a sender ID or
 * template on its old account is scoped to it, or when either account is archived. Its live binds are
 * dropped so it re-binds billing the new account.
 */
export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite("app_credential");
  if (refused) {
    return refused;
  }
  const { id } = await params;
  let to: unknown;
  try {
    to = ((await req.json()) as { to?: unknown }).to;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  if (typeof to !== "string" || !to.trim() || !Number.isInteger(Number(id))) {
    return NextResponse.json({ error: "Expected { to: \"<account id>\" }." }, { status: 400 });
  }
  try {
    return NextResponse.json({ data: await moveCredential(Number(id), to) });
  } catch (err) {
    return configFailed("move login", err);
  }
}
