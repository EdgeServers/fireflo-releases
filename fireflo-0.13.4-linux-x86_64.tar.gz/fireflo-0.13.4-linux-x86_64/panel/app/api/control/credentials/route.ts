import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { credentialContext, listCredentials, saveCredential } from "@/lib/credentials";
import { type CredentialInput, type SessionLimits, validateCredential } from "@/lib/credential-types";
import { isSecretField } from "@/lib/secrets";

const TABLES = "app_credential";

/**
 * The SMPP and HTTP logins.
 *
 * <p>The only editor in this panel that touches authentication. Secrets never leave the database —
 * the list reports whether one is stored, not what it is.
 */
export async function GET(): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  try {
    const [credentials, context] = await Promise.all([listCredentials(), credentialContext()]);
    return NextResponse.json({ data: { credentials, context } });
  } catch (err) {
    return configFailed("credentials", err);
  }
}

export async function POST(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const input = parse(body);
  if (typeof input === "string") {
    return NextResponse.json({ error: input }, { status: 400 });
  }

  const context = await credentialContext();
  const invalid = validateCredential(input, context);
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }

  try {
    const id = await saveCredential(input);
    return NextResponse.json({ data: { id } });
  } catch (err) {
    //saveCredential throws sentences for the cases the browser could not have known about -- a
    //`kept` secret with nothing stored, a lookup key taken since the form was opened
    if (err instanceof Error && !/relation|permission|syntax/i.test(err.message)) {
      return NextResponse.json({ error: err.message }, { status: 400 });
    }
    return configFailed("credentials", err);
  }
}

/**
 * An unknown body into a CredentialInput, or the reason it is not one.
 *
 * <p>Hand-written, naming the field. The one thing enforced here rather than in the validator is the
 * **shape of a secret**: it must arrive as `{state}`, never as a bare string, so that "leave it
 * alone" and "set it to this" cannot be confused for one another by a value that happens to look
 * like a placeholder.
 */
/**
 * The limits block, each value a number or null. Absent stays absent, so an update that does not
 * mention limits leaves them alone. A value that is not a number becomes NaN, for the validator to
 * refuse in words rather than be dropped here.
 */
function parseLimits(raw: unknown): SessionLimits | undefined {
  if (raw === undefined) {
    return undefined;
  }
  const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const num = (v: unknown): number | null =>
    v === null || v === undefined || v === "" ? null : typeof v === "number" ? v : Number.NaN;
  return {
    maxSessions: num(r.maxSessions),
    maxTx: num(r.maxTx),
    maxRx: num(r.maxRx),
    maxTrx: num(r.maxTrx),
    maxTps: num(r.maxTps),
  };
}

export function parse(body: unknown): CredentialInput | string {
  if (!body || typeof body !== "object") {
    return "Expected an object.";
  }
  const raw = body as Record<string, unknown>;

  if (typeof raw.type !== "string") {
    return "A type is required.";
  }
  if (raw.id != null && typeof raw.id !== "number") {
    return "The id must be a number.";
  }
  if (!isSecretField(raw.password) || !isSecretField(raw.apiKey)) {
    return "A password or API key must be sent as { state: 'unset' | 'kept' | 'set', value? }, never "
      + "as a bare string — otherwise 'leave this alone' and a password that happens to look like a "
      + "placeholder are the same message.";
  }

  const tlvs: { key: string; value: string }[] = [];
  if (raw.defaultTlvs !== undefined) {
    if (!Array.isArray(raw.defaultTlvs)) {
      return "Default TLVs must be an array of {key, value}.";
    }
    for (const entry of raw.defaultTlvs) {
      if (!entry || typeof entry !== "object") {
        return "Each default TLV must be an object with a key and a value.";
      }
      const tlv = entry as Record<string, unknown>;
      if (typeof tlv.key !== "string") {
        return "Each default TLV needs a key.";
      }
      tlvs.push({ key: tlv.key, value: typeof tlv.value === "string" ? tlv.value : "" });
    }
  }

  return {
    id: typeof raw.id === "number" ? raw.id : null,
    type: raw.type,
    systemId: typeof raw.systemId === "string" ? raw.systemId : null,
    password: raw.password,
    apiKey: raw.apiKey,
    accountId: typeof raw.accountId === "string" ? raw.accountId : null,
    product: typeof raw.product === "string" ? raw.product : null,
    //trimmed and de-duplicated here rather than trusted: this list decides what a caller may be
    //priced on, and a stray blank entry would sit in the column forever
    allowedProducts: Array.isArray(raw.allowedProducts)
      ? [...new Set(raw.allowedProducts
        .filter((p): p is string => typeof p === "string")
        .map((p) => p.trim())
        .filter(Boolean))]
      : [],
    allowedIps: Array.isArray(raw.allowedIps)
      ? raw.allowedIps.filter((ip): ip is string => typeof ip === "string" && ip.trim() !== "")
      : [],
    defaultTlvs: tlvs,
    limits: parseLimits(raw.limits),
    //absent means enabled, matching the worker and product routes
    enabled: raw.enabled === undefined ? true : raw.enabled === true,
    productConfirmed: raw.productConfirmed === true,
    billingConfirmed: raw.billingConfirmed === true,
  };
}
