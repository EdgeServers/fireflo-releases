import { NextRequest, NextResponse } from "next/server";
import { isConfigured, query } from "@/lib/metrics-db";
import { messageRows } from "@/lib/cdr-grain";
import { OUTCOME_LATERAL } from "@/lib/metrics-queries";
import { hasVendorAttempt } from "@/lib/metrics-schema";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET /api/control/credentials/figures?ids=a,b,c
 *
 * <p>Today's traffic per login, for the login cards: sent, refused, and when it was last seen. One
 * query over the call records for the system ids named, so a page of six logins costs one round
 * trip rather than six. Absent a metrics database the page shows dashes -- the cards do not need
 * these numbers to be useful, they are the glance that says "this one is live".
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  if (!isConfigured()) {
    return NextResponse.json({ data: {} });
  }
  const ids = (new URL(req.url).searchParams.get("ids") ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 200);
  if (!ids.length) {
    return NextResponse.json({ data: {} });
  }
  try {
    //one row per message, as UsageRollup: every vendor attempt is its own cdr_submit row and all of
    //them join the message's one receipt, so counting rows made a failover two "sent"
    const grain = { vendorAttempt: await hasVendorAttempt() };
    const rows = await query<{ system_id: string; sent: string; refused: string; last_seen: Date | null }>(
      `SELECT s.system_id,
              COUNT(*) AS sent,
              COUNT(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED')) AS refused,
              MAX(s.submitted_at) AS last_seen
         FROM ${messageRows("s.system_id = ANY($1::text[]) AND s.submitted_at > now() - interval '24 hours'", grain)}${OUTCOME_LATERAL}
        GROUP BY s.system_id`,
      [ids]
    );
    const data: Record<string, { sent: number; refused: number; lastSeen: string | null }> = {};
    for (const r of rows) {
      data[r.system_id] = {
        sent: Number(r.sent),
        refused: Number(r.refused),
        lastSeen: r.last_seen ? new Date(r.last_seen).toISOString() : null,
      };
    }
    return NextResponse.json({ data });
  } catch (err) {
    //the figures are a glance, not the page: a failed aggregate is dashes, not a 500
    console.error("credential figures", err);
    return NextResponse.json({ data: {} });
  }
}
