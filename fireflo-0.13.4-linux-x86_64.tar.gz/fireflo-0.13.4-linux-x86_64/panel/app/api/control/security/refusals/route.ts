import { NextRequest, NextResponse } from "next/server";
import type { RefusalSummaryRow } from "@/lib/ban-rules";
import { GatewayError, gqlData } from "@/lib/gateway-graphql";
import { REFUSAL_SUMMARY } from "@/lib/gateway-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { FIREFLO_JAILS, fail2banAvailable } from "@/lib/security-sources";

/**
 * GET /api/control/security/refusals?windowMinutes=1440&listener=
 *
 * <p>The gateway's refusal ledger folded by listener and address: what the "By server port" view
 * shows and what a ban rule evaluates. The read token; any operator. Beside the fold it says which
 * jails a ban may go into and whether this host can ban at all, so the view can offer the button or
 * the sentence without an admin-only read of the rules.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const minutes = Number(req.nextUrl.searchParams.get("windowMinutes") ?? 1440);
  if (!Number.isInteger(minutes) || minutes < 1 || minutes > 31 * 24 * 60) {
    return NextResponse.json({ error: "windowMinutes must be a whole number of minutes, up to 31 days." }, { status: 400 });
  }
  const listener = (req.nextUrl.searchParams.get("listener") ?? "").trim();

  try {
    const [listeners, available] = await Promise.all([
      gqlData<RefusalSummaryRow[]>({
        query: REFUSAL_SUMMARY,
        variables: { windowMinutes: minutes, listener: listener || undefined },
        timeoutMs: 15_000,
      }),
      fail2banAvailable(),
    ]);
    return NextResponse.json({
      data: { listeners: listeners ?? [], windowMinutes: minutes, jails: FIREFLO_JAILS, fail2banAvailable: available },
    });
  } catch (err) {
    if (err instanceof GatewayError) {
      return NextResponse.json({ error: err.message, code: err.code }, { status: err.status >= 500 ? 502 : err.status });
    }
    throw err;
  }
}
