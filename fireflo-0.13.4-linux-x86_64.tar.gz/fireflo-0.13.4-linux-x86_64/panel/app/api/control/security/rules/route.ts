import { NextRequest, NextResponse } from "next/server";
import { type BanRule, KNOWN_REASONS, NON_BANNABLE_REASONS, normaliseRule } from "@/lib/ban-rules";
import { readBanRules, readBanRuns, writeBanRules } from "@/lib/ban-rules-db";
import { auditConfigChange } from "@/lib/config-audit";
import { NotOperatorError, requireAdmin } from "@/lib/require-operator";
import { FIREFLO_JAILS, fail2banAvailable } from "@/lib/security-sources";

/**
 * GET /api/control/security/rules  — the ban rules, the run log, and what a rule may be made of.
 * PUT /api/control/security/rules  { rules: BanRule[] } — replace the set.
 *
 * <p>Admin only, both ways. A rule bans at the host without anybody pressing anything, which is a
 * bigger lever than any single ban, and reading one tells a non-admin which addresses the host
 * will cut off and at what count.
 *
 * <p>PUT replaces the whole set rather than patching one rule: the set is small, the file is
 * written atomically, and "the rules are exactly what the screen shows" is a property worth more
 * than a smaller request. Every rule must normalise or nothing is written.
 */

const MAX_RULES = 50;

async function gate(): Promise<NextResponse | null> {
  try {
    await requireAdmin();
    return null;
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
}

export async function GET(): Promise<NextResponse> {
  const refused = await gate();
  if (refused) {
    return refused;
  }
  const [rules, runs, available] = await Promise.all([readBanRules(), readBanRuns(200), fail2banAvailable()]);
  return NextResponse.json({
    data: {
      rules,
      runs,
      //what the editor offers, and the fact the page needs to say "these will only record":
      //without the wrapper a live rule decides and cannot ban
      jails: FIREFLO_JAILS,
      reasons: KNOWN_REASONS,
      nonBannable: NON_BANNABLE_REASONS,
      fail2banAvailable: available,
    },
  });
}

export async function PUT(request: NextRequest): Promise<NextResponse> {
  const refused = await gate();
  if (refused) {
    return refused;
  }

  let body: { rules?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body with a rules array." }, { status: 400 });
  }
  if (!Array.isArray(body.rules)) {
    return NextResponse.json({ error: "Expected a JSON body with a rules array." }, { status: 400 });
  }
  if (body.rules.length > MAX_RULES) {
    return NextResponse.json({ error: `At most ${MAX_RULES} rules.` }, { status: 400 });
  }

  const rules: BanRule[] = [];
  const ids = new Set<string>();
  for (const row of body.rules) {
    const rule = normaliseRule(row, FIREFLO_JAILS);
    if ("error" in rule) {
      return NextResponse.json({ error: rule.error }, { status: 400 });
    }
    if (ids.has(rule.id)) {
      return NextResponse.json({ error: `Two rules share the id ${rule.id}.` }, { status: 400 });
    }
    ids.add(rule.id);
    rules.push(rule);
  }

  const before = await readBanRules();
  await writeBanRules(rules);
  await auditConfigChange({
    domain: "ban_rule",
    name: "rules",
    action: "update",
    before: { count: before.length, enabled: before.filter((r) => r.enabled && !r.dryRun).map((r) => r.id) },
    after: { count: rules.length, enabled: rules.filter((r) => r.enabled && !r.dryRun).map((r) => r.id) },
  });
  return NextResponse.json({ data: { rules } });
}
