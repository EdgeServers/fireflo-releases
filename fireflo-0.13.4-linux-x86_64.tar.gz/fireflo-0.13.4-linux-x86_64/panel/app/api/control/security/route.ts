import { NextResponse } from "next/server";
import { gqlData, GatewayError } from "@/lib/gateway-graphql";
import { LOG_TAIL } from "@/lib/gateway-queries";
import type { GatewayLogTail } from "@/lib/gateway-files-types";
import {
  currentlyBlocked,
  parseBanEntries,
  parseGatewayRefusals,
  parsePanelRefusals,
  type SecurityEvent,
} from "@/lib/security-events";
import {
  banStateFile,
  fail2banAvailable,
  fail2banWrapper,
  liveBans,
  readPanelRefusalLines,
  tailFile,
} from "@/lib/security-sources";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET /api/control/security
 *
 * <p>Everything the Security page shows: refused logins from all three surfaces, and who fail2ban
 * is currently blocking.
 *
 * <p>Three sources, and each can be absent for its own reason — so each reports its own state
 * rather than contributing to one empty list. A gateway that cannot be reached, a refusal log that
 * is switched off, and a host with no fail2ban all look identical if the answer is just "no rows",
 * and the page has to be able to say which it is.
 *
 * <p><strong>Read-only.</strong> The unban write is a separate route, so the page an operator
 * leaves open cannot be the thing that changes the host.
 */
export async function GET(): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const [gateway, operator, bans, live, canUnban] = await Promise.all([
    gatewayRefusals(),
    readPanelRefusalLines(),
    tailFile(banStateFile()),
    liveBans(),
    fail2banAvailable(),
  ]);

  //fail2ban's own state when it can be asked, the notify action's file when it cannot. They answer
  //the same question and the live one is authoritative: the file is derived, and misses a ban made
  //before the action existed, one made by hand, or anything lost across a restart. The file is
  //still read either way, because it is the only record of RELEASES -- a lifted ban is simply not
  //in the live list any more
  const history = parseBanEntries(bans.lines);
  const blocked = live.live ? live.blocked : currentlyBlocked(history, new Date());

  const events: SecurityEvent[] = [
    ...gateway.events,
    ...parsePanelRefusals(operator.lines),
  ].sort(byNewestFirst);

  return NextResponse.json({
    data: {
      events,
      blocked,
      sources: {
        gateway: gateway.source,
        operator: {
          reachable: true,
          present: operator.present,
          truncated: operator.truncated,
          note: operator.present
            ? null
            : "No refused sign-ins recorded yet. The file is written on the first one, for the "
              + "operator panel and the customer portal alike.",
        },
        //named even when it is fine, so "no bans" and "no fail2ban" are answerable on the page
        //rather than being the same empty table
        fail2ban: {
          //"present" is now about being able to ANSWER the question at all, from either source
          present: live.live || bans.present,
          live: live.live,
          path: banStateFile(),
          historyPresent: bans.present,
          canUnban,
          unbanCommand: fail2banWrapper(),
          //the note says WHAT is wrong; the page names the paths itself. Putting one in both
          //printed the same path twice, a line apart
          note:
            live.note
            ?? (bans.present
              ? null
              : "fail2ban is not blocking anything for FireFlo on this host."),
        },
      },
    },
  });
}

interface GatewaySource {
  events: SecurityEvent[];
  source: {
    reachable: boolean;
    /** The gateway's own word for why there is nothing: disabled, missing, or present. */
    state: string | null;
    truncated: boolean;
    note: string | null;
  };
}

/**
 * The gateway's refusal log, over the management API.
 *
 * <p>Read through the gateway's `logTail` field rather than off the disk, so this works whether or
 * not the panel and the gateway share a filesystem — and so the gateway's own answer about why a
 * file is empty comes with it. That note is the difference between "nobody has attacked you" and
 * "the log is switched off and nothing is being recorded", which are not the same news.
 */
async function gatewayRefusals(): Promise<GatewaySource> {
  const unreachable = (note: string): GatewaySource => ({
    events: [],
    source: { reachable: false, state: null, truncated: false, note },
  });

  let tail: Pick<GatewayLogTail, "lines" | "state" | "truncated" | "note"> | null;
  try {
    //the typed LogTail is camelCase, and only these four fields are read, so no conversion
    tail = await gqlData<typeof tail>({
      query: LOG_TAIL,
      variables: { name: "auth", lines: 5000 },
      auth: "admin",
      timeoutMs: 10_000,
    });
  } catch (err) {
    if (err instanceof GatewayError && err.code === "UNREACHABLE") {
      return unreachable("Could not reach the gateway to read its refused-login log.");
    }
    return unreachable(
      "The gateway did not return its refused-login log. On a gateway older than 0.9.22 this log "
      + "does not exist yet, and refused logins are not recorded separately."
    );
  }
  if (!tail) {
    return unreachable("The gateway's reply could not be read.");
  }

  return {
    events: parseGatewayRefusals(tail.lines ?? []),
    source: {
      reachable: true,
      state: tail.state ?? null,
      truncated: Boolean(tail.truncated),
      note: tail.note ?? null,
    },
  };
}

/**
 * Newest first, with undated events last.
 *
 * <p>An event with no timestamp sorts to the end rather than to the top: a line the parser could
 * not date is the least trustworthy thing on the page and must not lead it.
 */
function byNewestFirst(a: SecurityEvent, b: SecurityEvent): number {
  if (!a.at) {
    return 1;
  }
  if (!b.at) {
    return -1;
  }
  const left = Date.parse(a.at);
  const right = Date.parse(b.at);
  if (Number.isNaN(left) || Number.isNaN(right)) {
    return b.at.localeCompare(a.at);
  }
  return right - left;
}
