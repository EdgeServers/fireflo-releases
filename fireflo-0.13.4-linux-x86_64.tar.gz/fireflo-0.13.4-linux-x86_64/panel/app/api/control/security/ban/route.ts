import { NextRequest, NextResponse } from "next/server";
import { DEFAULT_JAIL, banAddress, ignoreListed, isFirefloJail, isLiteralAddress } from "@/lib/fail2ban-ban";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { FIREFLO_JAILS, fail2banAvailable } from "@/lib/security-sources";

/**
 * POST /api/control/security/ban  { ip, jail?, seconds? }
 *
 * <p>Blocks one address in one FireFlo jail, next to a row the refusal ledger has shown hammering a
 * listener. The counterpart of `unban`, and the second thing in the panel that changes the host.
 *
 * <p>The guard is the gateway's `fireflo-fail2ban` wrapper (see `lib/fail2ban-ban.ts`): one literal
 * address into one of FireFlo's own jails, nothing else. Before asking it, this consults the host's
 * never-ban list the way fail2ban does and refuses an address on it with a sentence, rather than
 * letting fail2ban report "ignored" as though a ban had happened.
 *
 * <p>501 when the panel is not on the gateway host -- the same condition under which the blocked
 * list says fail2ban is not reachable -- because the feature is genuinely not implemented there:
 * fail2ban is reached through sudo on the box that runs it.
 */
export async function POST(request: NextRequest): Promise<NextResponse> {
  let operator;
  try {
    operator = await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  let body: { jail?: unknown; ip?: unknown; seconds?: unknown };
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body with an ip, and optionally a jail and seconds." }, { status: 400 });
  }

  const ip = typeof body.ip === "string" ? body.ip.trim() : "";
  const jail = typeof body.jail === "string" && body.jail.trim() ? body.jail.trim() : DEFAULT_JAIL;
  const seconds =
    body.seconds == null || body.seconds === ""
      ? null
      : typeof body.seconds === "number"
        ? body.seconds
        : Number(body.seconds);

  if (!isFirefloJail(jail)) {
    return NextResponse.json({ error: `Not a FireFlo jail. Expected one of: ${FIREFLO_JAILS.join(", ")}` }, { status: 400 });
  }
  if (!isLiteralAddress(ip)) {
    return NextResponse.json(
      { error: "That is not a literal address. Only a single IPv4 or IPv6 address can be blocked here." },
      { status: 400 }
    );
  }
  if (seconds !== null && (!Number.isInteger(seconds) || seconds <= 0)) {
    return NextResponse.json({ error: "seconds must be a whole number of seconds, or left out." }, { status: 400 });
  }

  if (!(await fail2banAvailable())) {
    return NextResponse.json(
      {
        error:
          "Banning from the panel needs the panel on the gateway host with fail2ban installed "
          + "(fireflo-panel-install --with-fail2ban). This panel is not, so there is nothing here to ask.",
      },
      { status: 501 }
    );
  }

  const ignore = await ignoreListed(ip);
  if (ignore.ignored) {
    return NextResponse.json(
      {
        error:
          `${ip} is on this host's never-ban list (/etc/fireflo/fail2ban-ignore.conf), so it was not `
          + "blocked. Remove it from that file first if the ban is meant.",
      },
      { status: 409 }
    );
  }

  //the audit line is written inside banAddress, before the call and whatever the outcome
  const result = await banAddress({ jail, ip, seconds, actor: operator, source: "operator" });
  if (!result.ok) {
    return NextResponse.json({ error: result.error }, { status: result.status });
  }
  const notes = [result.note, ignore.note].filter((n): n is string => !!n);
  return NextResponse.json({ data: { jail, ip, banned: true, note: notes.length ? notes.join(" ") : null } });
}
