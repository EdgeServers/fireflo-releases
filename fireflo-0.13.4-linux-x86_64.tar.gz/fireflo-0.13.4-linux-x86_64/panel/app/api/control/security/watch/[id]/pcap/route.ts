import { NextRequest, NextResponse } from "next/server";
import { auditedDownload } from "@/lib/access-log";
import { gqlFile } from "@/lib/gateway-graphql";
import { WATCH_FILE } from "@/lib/gateway-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET /api/control/security/watch/{id}/pcap
 *
 * <p>What a live watch holds, as a pcap Wireshark opens with its SMPP dissector -- each client
 * connection its own TCP stream. A file rather than JSON, so `gqlFile`, like the capture downloads;
 * and audited, because it carries decoded message bodies, numbers and bind passwords.
 */
type Params = { params: Promise<{ id: string }> };

export async function GET(req: NextRequest, { params }: Params): Promise<NextResponse | Response> {
  let operator: string;
  try {
    operator = (await requireOperator()).name;
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const { id } = await params;
  if (!/^[0-9a-f]{16}$/.test(id)) {
    return NextResponse.json({ error: `'${id}' is not a watch id.` }, { status: 400 });
  }
  return auditedDownload(
    req,
    { kind: "capture", actor: operator, subject: `watch-${id}.pcap` },
    () => gqlFile({ query: WATCH_FILE, variables: { id }, auth: "admin" })
  );
}
