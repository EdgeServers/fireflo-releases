import { NextRequest, NextResponse } from "next/server";
import { logOperatorEvent } from "@/lib/access-log";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { configFailed, guardAdminWrite } from "@/lib/config-guard";
import { requireAdmin } from "@/lib/require-operator";
import { ADMIN_ROLE, OPERATOR_ROLE } from "@/lib/roles";
import { countEnabledAdmins, getUserById, setEnabled, setRole } from "@/lib/users";

type Params = { params: Promise<{ id: string }> };

const TABLES = "app_user";

/**
 * Enables, disables or re-roles one user.
 *
 * <p>Two refusals guard against an admin locking everybody out, and both are the same refusal the
 * gateway's `fireflo user disable` makes: the last enabled admin cannot be disabled or demoted, and
 * an admin cannot demote themself -- the page they are on would stop existing under them, and the
 * audit row would then have been written by somebody with no right to write it.
 *
 * <p>No DELETE. A user is disabled, never removed, so the access log keeps pointing at a person.
 */
export async function PATCH(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardAdminWrite(TABLES);
  if (refused) {
    return refused;
  }
  const admin = await requireAdmin();
  const id = Number((await params).id);
  if (!Number.isInteger(id) || id < 1) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const raw = (body ?? {}) as Record<string, unknown>;
  const enabled = typeof raw.enabled === "boolean" ? raw.enabled : undefined;
  const role = raw.role === ADMIN_ROLE || raw.role === OPERATOR_ROLE ? raw.role : undefined;
  if (enabled === undefined && role === undefined) {
    return NextResponse.json({ error: "Nothing to change: send enabled and/or role." }, { status: 400 });
  }

  try {
    const target = await getUserById(id);
    if (!target) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    if (role !== undefined && target.accountId) {
      return NextResponse.json({ error: "A customer's role cannot change. Create a panel user instead." }, { status: 400 });
    }
    const demoting = role !== undefined && target.role === ADMIN_ROLE && role !== ADMIN_ROLE;
    const disabling = enabled === false && target.enabled;
    if (target.id === admin.userId && (demoting || disabling)) {
      return NextResponse.json({ error: "You cannot disable or demote yourself. Ask another admin." }, { status: 400 });
    }
    if (target.role === ADMIN_ROLE && target.enabled && (demoting || disabling) && (await countEnabledAdmins()) <= 1) {
      return NextResponse.json(
        { error: `${target.email} is the only enabled admin. Add another before changing this one.` },
        { status: 400 }
      );
    }

    if (enabled !== undefined && enabled !== target.enabled) {
      await setEnabled(id, enabled);
    }
    if (role !== undefined && role !== target.role) {
      await setRole(id, role);
    }
    const user = await getUserById(id);
    void logOperatorEvent({
      event: "user_updated",
      actor: admin.name,
      userId: admin.userId,
      ip: clientIp(req),
      userAgent: clientUserAgent(req),
      detail: {
        subject: target.email,
        ...(enabled !== undefined ? { enabled } : {}),
        ...(role !== undefined ? { role } : {}),
      },
    });
    return NextResponse.json({ data: { user } });
  } catch (err) {
    return configFailed("users", err);
  }
}
