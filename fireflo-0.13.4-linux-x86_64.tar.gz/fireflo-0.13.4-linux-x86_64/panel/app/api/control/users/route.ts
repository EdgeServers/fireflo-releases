import { NextRequest, NextResponse } from "next/server";
import { logOperatorEvent } from "@/lib/access-log";
import { configFailed, guardAdminWrite } from "@/lib/config-guard";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { passwordProblem } from "@/lib/password-policy";
import { requireAdmin } from "@/lib/require-operator";
import { CUSTOMER_ROLE } from "@/lib/roles";
import { DuplicateUserError, createUser, listUsers } from "@/lib/users";
import { type NewUserInput, type Role, isRole, validateNewUser } from "@/lib/user-types";

const TABLES = "app_user";

/**
 * Who may sign in.
 *
 * <p>Admin-only, both verbs: an operator is answered 404 like an anonymous caller, because the list
 * of people who can reach this panel is itself something an operator has no business reading.
 * `?account=ID` narrows to one account's customers, which the account page uses.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  const refused = await guardAdminWrite(TABLES);
  if (refused) {
    return refused;
  }
  const params = new URL(req.url).searchParams;
  const role = params.get("role");
  try {
    const users = await listUsers({
      accountId: params.get("account"),
      role: isRole(role) ? (role as Role) : null,
    });
    return NextResponse.json({ data: { users } });
  } catch (err) {
    return configFailed("users", err);
  }
}

/**
 * Creates a user.
 *
 * <p>The password is judged by `lib/password-policy.ts`, the same function the form's meter runs,
 * so nothing the meter called acceptable is refused here. A customer may be created with no password
 * and sign in by emailed link; an admin or operator may not.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  const refused = await guardAdminWrite(TABLES);
  if (refused) {
    return refused;
  }
  const admin = await requireAdmin();

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const raw = (body ?? {}) as Record<string, unknown>;
  const input: NewUserInput = {
    email: typeof raw.email === "string" ? raw.email : "",
    role: raw.role as Role,
    accountId: typeof raw.accountId === "string" ? raw.accountId : null,
    password: typeof raw.password === "string" && raw.password ? raw.password : null,
  };

  const invalid = validateNewUser(input);
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }
  if (input.password) {
    const weak = passwordProblem(input.password, input.email);
    if (weak) {
      return NextResponse.json({ error: weak }, { status: 400 });
    }
  }

  try {
    const user = await createUser(input);
    void logOperatorEvent({
      event: "user_created",
      actor: admin.name,
      userId: admin.userId,
      ip: clientIp(req),
      userAgent: clientUserAgent(req),
      detail: {
        subject: user.email,
        role: user.role,
        ...(user.role === CUSTOMER_ROLE ? { account: user.accountId } : {}),
        password: user.hasPassword ? "set" : "none",
      },
    });
    return NextResponse.json({ data: { user } });
  } catch (err) {
    if (err instanceof DuplicateUserError) {
      return NextResponse.json({ error: err.message }, { status: 409 });
    }
    //the FK on account_id: the account named does not exist
    if ((err as { code?: string })?.code === "23503") {
      return NextResponse.json({ error: `No account '${input.accountId}'.` }, { status: 400 });
    }
    return configFailed("users", err);
  }
}
