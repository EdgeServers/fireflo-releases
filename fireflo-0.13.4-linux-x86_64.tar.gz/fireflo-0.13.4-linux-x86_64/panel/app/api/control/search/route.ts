import { NextRequest, NextResponse } from "next/server";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { listAccounts } from "@/lib/accounts";
import { listWorkers } from "@/lib/workers";
import { findMessageId } from "@/lib/cdr-queries";
import { KIND } from "@/lib/worker-types";
import { looksLikeMessageId, rankAccounts, rankNames, type SearchResult } from "@/lib/search";

/**
 * What the jump box asks: accounts, vendors, servers and message ids that match a few letters.
 *
 * <p>Read-only, so it needs an operator and nothing else -- no config write access, no metrics
 * guard. Each source is asked independently and a source that cannot answer (no config database,
 * no metrics database, a query error) contributes nothing rather than failing the whole box:
 * the operator typed a vendor's name, and the metrics database being away is not a reason to
 * withhold it.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      //404 rather than 403 for a non-operator: a 403 confirms the endpoint exists
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const q = (req.nextUrl.searchParams.get("q") ?? "").trim();
  const empty: SearchResult = { accounts: [], vendors: [], servers: [], message: null };
  if (q.length < 2 && !looksLikeMessageId(q)) {
    return NextResponse.json({ data: empty });
  }

  const [accounts, workers, message] = await Promise.all([
    listAccounts().catch(() => []),
    listWorkers().catch(() => []),
    looksLikeMessageId(q) ? findMessageId(q).catch(() => null) : Promise.resolve(null),
  ]);

  const data: SearchResult = {
    accounts: rankAccounts(accounts, q).map((a) => ({ id: a.id, label: a.label })),
    vendors: rankNames(workers.filter((w) => w.type === KIND.vendor).map((w) => w.name), q),
    servers: rankNames(workers.filter((w) => w.type === KIND.server).map((w) => w.name), q),
    message,
  };
  return NextResponse.json({ data });
}
