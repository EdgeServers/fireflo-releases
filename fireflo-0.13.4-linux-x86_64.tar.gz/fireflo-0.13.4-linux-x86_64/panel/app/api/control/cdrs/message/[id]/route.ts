import { NextRequest, NextResponse } from "next/server";
import { guardCdrRoute, queryFailed } from "@/lib/cdr-guard";
import { messageRecord } from "@/lib/cdr-queries";
import { ruleLabels } from "@/lib/rates";

type Params = { params: Promise<{ id: string }> };

/**
 * One message, in full: every attempt, every receipt, and the rules that priced it.
 *
 * <p>Under `/message/` rather than as a bare `[id]` segment because `/cdrs/export` is already a
 * sibling of this route, and a dynamic segment there would swallow it.
 */
export async function GET(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  const { id } = await params;
  const askedFor = decodeURIComponent(id).trim();
  if (!askedFor) {
    return NextResponse.json({ error: "No message id given." }, { status: 400 });
  }

  try {
    //may answer under a different id than the one asked for: a concatenated message was
    //acknowledged once per segment, so the id on the receipt somebody is chasing is often not the
    //one the message is filed under. The record says which it resolved to and which segment the
    //asked-for id was, so the page can say so rather than appearing to change the subject
    const record = await messageRecord(askedFor);
    if (!record.attempts.length) {
      //the two reasons are genuinely different and only one of them is a mistake: the expiry sweeper
      //deletes old records, so an id that was valid last month is now correctly absent
      return NextResponse.json(
        {
          error: `No record of ${askedFor}. Either the id is wrong, or the message is older `
            + "than the gateway's retention window and has been swept.",
        },
        { status: 404 }
      );
    }

    //opportunistic, and on the other database: a rule name is nice to have and its absence must not
    //take the page down. The ids render bare when this fails
    const ids = [
      ...new Set(
        record.attempts.flatMap((a) => [a.costRuleId, a.priceRuleId]).filter((v): v is string => !!v)
      ),
    ];
    const ruleNames = ids.length ? await ruleLabels(ids).catch(() => ({})) : {};

    //record last, so its resolved gatewayMsgId wins over the one that was asked for
    return NextResponse.json({ data: { ...record, ruleNames } });
  } catch (err) {
    return queryFailed("message record", err);
  }
}
