import { NextRequest, NextResponse } from "next/server";
import { guardCdrRoute, queryFailed } from "@/lib/cdr-guard";
import { isFilterError, parseFilters } from "@/lib/cdr-request";
import { DEFAULT_PAGE, MAX_PAGE, type CdrCursor, columnSetFor, searchCdrs } from "@/lib/cdr-queries";

/**
 * One page of call records.
 *
 * <p>Its own guard rather than `controlRoute`, which cannot pass anything but a range to its handler.
 *
 * <p>The cursor arrives as two parameters rather than one opaque token on purpose: an operator
 * debugging a paging complaint can read `cursorTs` and `cursorId` straight out of the URL, and there
 * is nothing in them worth hiding.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }

  const params = new URL(req.url).searchParams;
  const filters = parseFilters(params);
  if (isFilterError(filters)) {
    //400 rather than a silent fallback: a filter that was ignored still labels the results
    return NextResponse.json({ error: filters.error }, { status: 400 });
  }

  const cursorTs = params.get("cursorTs");
  const cursorId = params.get("cursorId");
  if ((cursorTs == null) !== (cursorId == null)) {
    return NextResponse.json(
      { error: "A cursor needs both cursorTs and cursorId; one alone would skip rows." },
      { status: 400 }
    );
  }
  //the id half must be an integer -- it is bound as ::bigint and a stray value would be a query
  //error surfacing as a 500 when it is plainly a bad request
  if (cursorId != null && !/^\d+$/.test(cursorId)) {
    return NextResponse.json({ error: "cursorId must be a whole number." }, { status: 400 });
  }
  const cursor: CdrCursor | null =
    cursorTs != null && cursorId != null ? { submittedAt: cursorTs, id: cursorId } : null;

  const limit = Number(params.get("limit") ?? DEFAULT_PAGE);
  if (!Number.isFinite(limit) || limit < 1) {
    return NextResponse.json({ error: "limit must be a positive number." }, { status: 400 });
  }
  //the browser cap is enforced here, not in searchCdrs: the export worker is the other caller and it
  //legitimately asks for far more
  const size = Math.min(limit, MAX_PAGE);

  //the TLV columns are unbounded TEXT and are fetched only when the chooser has ticked one. Without
  //this the operator list selected neither, so a ticked TLV column rendered a column of blanks
  const wanted = (params.get("columns") ?? "").split(",").map((c) => c.trim());

  try {
    return NextResponse.json({ data: await searchCdrs(filters, cursor, size, columnSetFor(wanted)) });
  } catch (err) {
    return queryFailed("cdr search", err);
  }
}
