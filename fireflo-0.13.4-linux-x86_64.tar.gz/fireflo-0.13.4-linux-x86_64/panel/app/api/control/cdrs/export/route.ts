import { NextRequest, NextResponse } from "next/server";
import { guardCdrRoute, queryFailed } from "@/lib/cdr-guard";
import { isFilterError, parseFilters } from "@/lib/cdr-request";
import { CDR_EXPORT_KIND, HEADERS, toCsvLine } from "@/lib/cdr-export";
import { type CdrCursor, searchCdrs } from "@/lib/cdr-queries";
import { type ExportSource, listExports, requestExport, serialiseFilters } from "@/lib/exports";
import type { CdrFilters } from "@/lib/cdr-request";
import type { CdrRow } from "@/lib/cdr-request";

/**
 * Call records, as the generic job store consumes them.
 *
 * <p>Assembled here rather than in `cdr-export.ts` because it is the only piece that needs the query
 * layer, and that module is deliberately database-free so its CSV shape can be asserted directly —
 * the same split `mis-messages-export.ts` already uses.
 */
const CDR_EXPORT: ExportSource<CdrRow, CdrFilters> = {
  kind: CDR_EXPORT_KIND,
  headers: HEADERS,
  toCsvLine,
  //"full": the CSV is the complete record, whatever the table on screen is showing
  page: (filters, cursor, batch) => searchCdrs(filters, cursor as CdrCursor | null, batch, "full"),
  serialise: serialiseFilters,
};

/**
 * The export queue: GET lists requests, POST makes one.
 *
 * <p>POST answers as soon as the request is recorded, not when the CSV is finished. A synchronous
 * download of a month of call records would hold a connection open for minutes and lose everything
 * if the browser gave up — which is why this is a request-and-collect flow at all.
 */
export async function GET(): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  try {
    //scoped to this kind, so the refusal exports do not appear on the Messages page
    return NextResponse.json({ data: await listExports(CDR_EXPORT_KIND) });
  } catch (err) {
    return queryFailed("cdr export list", err);
  }
}

export async function POST(req: NextRequest): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }

  const params = new URL(req.url).searchParams;
  //the window is pinned to now, once. Re-deriving "last 24 hours" on every batch would slide the
  //range forward as the export runs, so the last page would be reading rows the first page's window
  //did not include
  const filters = parseFilters(params, new Date());
  if (isFilterError(filters)) {
    return NextResponse.json({ error: filters.error }, { status: 400 });
  }

  try {
    return NextResponse.json({ data: await requestExport(CDR_EXPORT, filters, describe(params)) });
  } catch (err) {
    return queryFailed("cdr export request", err);
  }
}

/**
 * The filters as a phrase, for the list of requests.
 *
 * <p>Without it every row in that list says "CDR export" and the only way to tell two apart is the
 * timestamp — which is exactly when someone downloads the wrong one.
 */
function describe(params: URLSearchParams): string {
  const parts: string[] = [];
  const range = params.get("range") ?? "24h";
  parts.push(range === "all" ? "all time" : `last ${range}`);
  for (const key of ["account", "systemId", "vendor", "product", "ingress", "dest", "source", "msgId", "outcome"]) {
    const value = params.get(key)?.trim();
    if (value) {
      parts.push(`${key} ${value}`);
    }
  }
  if (params.get("attempts") === "all") {
    parts.push("every attempt");
  }
  return parts.join(", ");
}
