import { NextResponse } from "next/server";
import { createReadStream } from "node:fs";
import { Readable } from "node:stream";
import { auditedDownload, logOperatorEvent } from "@/lib/access-log";
import { guardCdrRoute, queryFailed } from "@/lib/cdr-guard";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { requireOperator } from "@/lib/require-operator";
import { CDR_EXPORT_KIND } from "@/lib/cdr-export";
import { csvPath, discard, downloadName, getExport } from "@/lib/exports";

type Params = { params: Promise<{ id: string }> };

/**
 * Collects a finished export, or deletes one.
 *
 * <p>The file is streamed rather than read into memory: an export of a month of traffic is the case
 * this feature exists for, and `readFile` on it would hold the whole CSV in the process heap for as
 * long as the download takes.
 */
export async function GET(req: Request, { params }: Params): Promise<NextResponse | Response> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  //guardCdrRoute has already proven this succeeds; it just does not hand the name back, and
  //widening its return type for one caller would touch seven routes
  const { name: operator } = await requireOperator();
  const { id } = await params;

  const job = await getExport(id);
  //the kind check is not decoration: without it this route is a second, differently-audited way to
  //download a refusal export, and the audit line would name it a cdr-export
  if (!job || job.kind !== CDR_EXPORT_KIND) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  if (job.status !== "ready") {
    //409 rather than 404: the request exists, it is just not collectable yet, and the difference
    //decides whether the UI should keep polling or stop
    return NextResponse.json(
      { error: `This export is ${job.status}.`, status: job.status },
      { status: 409 }
    );
  }

  //resolved inside the export directory by csvPath; null means the id tried to escape it
  const file = csvPath(id);
  if (!file) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  //audited around the stream, so the 409 above -- an export that is not collectable yet -- never
  //appears in the log as a download somebody took. A 2xx here means the transfer STARTED; nothing
  //in this process can know whether the connection survived it
  return auditedDownload(
    req,
    { kind: "cdr-export", actor: operator, subject: downloadName(job) },
    async () => {
      try {
        const stream = Readable.toWeb(createReadStream(file)) as ReadableStream;
        return new Response(stream, {
          headers: {
            "Content-Type": "text/csv; charset=utf-8",
            //the filename is derived from the job, never from user input, so it needs no escaping
            "Content-Disposition": `attachment; filename="${downloadName(job)}"`,
            ...(job.bytes != null ? { "Content-Length": String(job.bytes) } : {}),
            //these are call records; nothing in front of this should keep a copy
            "Cache-Control": "private, no-store",
          },
        });
      } catch (err) {
        return queryFailed("cdr export download", err);
      }
    }
  );
}

export async function DELETE(req: Request, { params }: Params): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  const { name: operator } = await requireOperator();
  const { id } = await params;
  const job = await getExport(id);
  if (!job || job.kind !== CDR_EXPORT_KIND) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  try {
    await discard(id);
    //logged because it destroys a file of call records. A download log that records who took a copy
    //but not who removed the evidence is only half an audit trail
    void logOperatorEvent({
      event: "export_deleted",
      actor: operator,
      ip: clientIp(req),
      userAgent: clientUserAgent(req),
      detail: { id, kind: CDR_EXPORT_KIND },
    });
    return NextResponse.json({ data: { id } });
  } catch (err) {
    return queryFailed("cdr export delete", err);
  }
}
