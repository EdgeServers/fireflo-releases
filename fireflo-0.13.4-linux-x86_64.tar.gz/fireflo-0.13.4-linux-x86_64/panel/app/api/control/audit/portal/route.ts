import { NextRequest, NextResponse } from "next/server";
import { listCustomerEvents } from "@/lib/audit-log";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { parseAuditFilter } from "@/lib/audit-filter";

/**
 * GET /api/control/audit/portal
 *
 * <p>Who reached a customer account, from where, and how -- link, password, or a reseller acting on
 * a child. Any operator may read it: it is about customers, and answering "who signed in to this
 * account" is ordinary support work. `account=ID` is what the account page sends.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite("app_customer_access_log");
  if (refused) {
    return refused;
  }
  try {
    return NextResponse.json({ data: await listCustomerEvents(parseAuditFilter(new URL(req.url).searchParams)) });
  } catch (err) {
    return configFailed("audit", err);
  }
}
