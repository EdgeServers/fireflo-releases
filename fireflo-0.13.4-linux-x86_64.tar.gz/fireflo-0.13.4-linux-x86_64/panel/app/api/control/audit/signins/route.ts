import { NextRequest, NextResponse } from "next/server";
import { signInSummary } from "@/lib/audit-log";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";

/**
 * GET /api/control/audit/signins?days=7
 *
 * <p>Sign-ins and refusals per day, per door, from the two database logs. The Security page shows
 * this beside the file-and-fail2ban view it already had: the file is what gets addresses banned, the
 * table is what people read, and the two agreeing is itself worth being able to see.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite("app_operator_access_log, app_customer_access_log");
  if (refused) {
    return refused;
  }
  const days = Math.min(90, Math.max(1, Number(new URL(req.url).searchParams.get("days")) || 7));
  try {
    return NextResponse.json({ data: { days, rows: await signInSummary(days) } });
  } catch (err) {
    return configFailed("audit", err);
  }
}
