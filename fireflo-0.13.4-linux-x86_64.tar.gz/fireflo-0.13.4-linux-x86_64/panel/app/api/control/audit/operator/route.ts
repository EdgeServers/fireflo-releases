import { NextRequest, NextResponse } from "next/server";
import { listOperatorEvents } from "@/lib/audit-log";
import { parseAuditFilter } from "@/lib/audit-filter";
import { configFailed, guardAdminWrite } from "@/lib/config-guard";

/**
 * GET /api/control/audit/operator
 *
 * <p>What operators did, and who was refused at the operator door. Admin-only, like the users page
 * it sits on: this is the record of the people who can edit the database, so it is for the person
 * who manages them. Filters: `user`, `event`, `actor`, `failures=1`, `from`, `to`, `limit`, and
 * `before=<iso>,<id>` for the next page.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  const refused = await guardAdminWrite("app_operator_access_log");
  if (refused) {
    return refused;
  }
  try {
    return NextResponse.json({ data: await listOperatorEvents(parseAuditFilter(new URL(req.url).searchParams)) });
  } catch (err) {
    return configFailed("audit", err);
  }
}
