import { controlRoute } from "@/lib/control-route";
import { revenueByAccount } from "@/lib/metrics-queries";

//the range alone: controlRoute hands the handler the query string as a second argument, and
//revenueByAccount's second argument is its options
export const GET = controlRoute((range) => revenueByAccount(range));
