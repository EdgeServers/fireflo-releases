import { controlRoute } from "@/lib/control-route";
import { usageByDay } from "@/lib/metrics-queries";

export const GET = controlRoute(usageByDay);
