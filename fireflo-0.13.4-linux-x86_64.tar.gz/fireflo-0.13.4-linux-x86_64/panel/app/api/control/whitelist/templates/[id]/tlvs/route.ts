import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { requireOperator } from "@/lib/require-operator";
import { decideTemplateTlvs } from "@/lib/mis-whitelist";

type Params = { params: Promise<{ id: string }> };

/**
 * POST /api/control/whitelist/templates/{id}/tlvs — the same decision, for a template.
 *
 * <p>See the sender-ID sibling for why this is its own route. Under DLT this is the one that matters
 * most: a template's stamps carry the registered template id, and accepting a proposal here is
 * agreeing that the customer's registration reference is theirs to assert.
 */
export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite("app_template");
  if (refused) {
    return refused;
  }
  const { name: operator } = await requireOperator();
  const { id } = await params;
  if (!/^\d+$/.test(id)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  let body: Record<string, unknown> | null;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  if (typeof body?.accept !== "boolean") {
    return NextResponse.json({ error: "Expected { accept: true | false }." }, { status: 400 });
  }

  try {
    const decided = await decideTemplateTlvs(Number(id), body.accept, operator);
    return decided
      ? NextResponse.json({ data: { id, accepted: body.accept } })
      : NextResponse.json(
        { error: "There is no proposal on this template. Somebody may have answered it already." },
        { status: 409 }
      );
  } catch (err) {
    return configFailed("decide proposed template TLVs", err);
  }
}
