import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { moveWhitelistRow } from "@/lib/account-archive";

type Params = { params: Promise<{ id: string }> };

/**
 * Gives a template to another account, approval kept: `{ "to": "<account id>" }`. Refused (400)
 * when it is scoped to a login the target does not own, when the target already has it, or when
 * either account is archived.
 */
export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite("app_template");
  if (refused) {
    return refused;
  }
  const { id } = await params;
  let to: unknown;
  try {
    to = ((await req.json()) as { to?: unknown }).to;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  if (typeof to !== "string" || !to.trim() || !Number.isInteger(Number(id))) {
    return NextResponse.json({ error: "Expected { to: \"<account id>\" }." }, { status: 400 });
  }
  try {
    return NextResponse.json({ data: await moveWhitelistRow("template", Number(id), to) });
  } catch (err) {
    return configFailed("move template", err);
  }
}
