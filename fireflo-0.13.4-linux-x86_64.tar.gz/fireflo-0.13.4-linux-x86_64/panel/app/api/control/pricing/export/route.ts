import { NextRequest, NextResponse } from "next/server";
import { auditedDownload } from "@/lib/access-log";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { requireOperator } from "@/lib/require-operator";
import { listRulesForScopes, resolveKnownScopes } from "@/lib/rates";
import { toCsv } from "@/lib/pricing-csv";
import { scopeKind } from "@/lib/rate-types";

const WHICH = ["all", "accounts", "vendors", "scope"] as const;
type Which = (typeof WHICH)[number];

/**
 * Pricing as CSV, for the Pricing page: everything, every account (the default included), every
 * vendor, or one scope. The same columns as a product's export, so a file from either imports here.
 *
 * <p>Not under `/rates/`, where a static `export` segment would shadow a scope of that name.
 */
export async function GET(req: NextRequest): Promise<NextResponse | Response> {
  const refused = await guardConfigWrite("app_rate_rule");
  if (refused) {
    return refused;
  }
  const { name: operator } = await requireOperator();
  const url = new URL(req.url);
  const which = (url.searchParams.get("which") ?? "all") as Which;
  const scope = url.searchParams.get("scope") ?? "";
  if (!WHICH.includes(which) || (which === "scope" && !scope)) {
    return NextResponse.json({ error: "Expected which=all|accounts|vendors, or which=scope with a scope." }, { status: 400 });
  }
  const subject = which === "scope" ? scope : which;

  return auditedDownload(
    req,
    { kind: "pricing-export", actor: operator, subject },
    async () => {
      try {
        const known = await resolveKnownScopes();
        const keep = (s: string) => {
          const kind = scopeKind(s, known);
          return which === "all" ? true
            : which === "scope" ? s === scope
            : which === "vendors" ? kind === "cost"
            : kind === "price" || kind === "default";
        };
        const scopes = await listRulesForScopes(keep);
        const stamp = new Date().toISOString().slice(0, 10);
        //user input when it is one scope: an unescaped quote or CRLF would break out of the header
        const safe = subject === "*" ? "default" : subject.replace(/[^A-Za-z0-9._-]/g, "_");
        return new Response(toCsv(scopes), {
          headers: {
            "Content-Type": "text/csv; charset=utf-8",
            "Content-Disposition": `attachment; filename="fireflo-pricing-${safe}-${stamp}.csv"`,
            "Cache-Control": "private, no-store",
          },
        });
      } catch (err) {
        return configFailed("pricing export", err);
      }
    }
  );
}
