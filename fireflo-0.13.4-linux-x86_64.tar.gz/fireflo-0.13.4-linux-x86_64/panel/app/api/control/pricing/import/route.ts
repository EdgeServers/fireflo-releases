import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { listRulesForScopes, resolveKnownScopes, saveScope } from "@/lib/rates";
import { diffScopes, fromCsv } from "@/lib/pricing-csv";
import { scopeKind, validateScope } from "@/lib/rate-types";

/** A route reading an unbounded body as text is a denial of service one curl away. */
const MAX_BYTES = 2 * 1024 * 1024;

/**
 * Applies a pricing CSV across every product -- or, with `?dryRun=1`, says what it would do.
 *
 * <p>The Pricing page's counterpart to a product's import, with the same rules: the plan is
 * recomputed here in both modes, each scope the file names is replaced wholesale, a rule missing from
 * the file is a removal that has to be confirmed, and scopes are saved one at a time, so a failure
 * part way leaves the earlier ones applied.
 *
 * <p>One check the product import does not need: a scope that is neither a known account nor a
 * vendor, and is not already priced, is refused. A typo in a spreadsheet's scope column would
 * otherwise create a tariff that loads and matches nothing.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite("app_rate_rule and app_rate_rule_condition");
  if (refused) {
    return refused;
  }
  const url = new URL(req.url);
  const dryRun = url.searchParams.get("dryRun") === "1";
  const confirmRemovals = url.searchParams.get("confirmRemovals") === "1";

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const text = (body as Record<string, unknown>)?.csv;
  if (typeof text !== "string") {
    return NextResponse.json({ error: "Expected { csv: string }." }, { status: 400 });
  }
  if (text.length > MAX_BYTES) {
    return NextResponse.json({ error: `That file is larger than ${MAX_BYTES / 1024 / 1024} MB.` }, { status: 413 });
  }

  const rows = fromCsv(text, null);
  if (typeof rows === "string") {
    return NextResponse.json({ error: rows }, { status: 400 });
  }
  if (!rows.length) {
    //the commonest way here is an export taken while nothing is priced -- the file is the header
    //alone -- so say that, and what to put under it, rather than leave "header" sounding like a
    //fault in the header row
    return NextResponse.json(
      {
        error: "The file has the header row but no prices under it. An export is header-only when "
          + "nothing is priced yet: add one row per price beneath the header (scope, amount and "
          + "enabled at least, rule_id left blank) and import it again.",
      },
      { status: 400 }
    );
  }

  try {
    const named = new Set(rows.map((r) => r.scope));
    const [stored, known] = await Promise.all([listRulesForScopes((s) => named.has(s)), resolveKnownScopes()]);
    const priced = new Set(stored.map((s) => s.scope));
    for (const scope of named) {
      if (scopeKind(scope, known) === "unknown" && !priced.has(scope)) {
        return NextResponse.json(
          { error: `'${scope}' is not an account, a vendor or *, and is not priced yet. Check the scope column for a typo.` },
          { status: 400 }
        );
      }
    }

    const plan = diffScopes(rows, stored);
    if (typeof plan === "string") {
      return NextResponse.json({ error: plan }, { status: 400 });
    }
    for (const scope of plan.scopes) {
      const invalid = validateScope({ scope, scopeConfirmed: true, rules: plan.result[scope] }, known);
      if (invalid) {
        return NextResponse.json({ error: `In '${scope}': ${invalid}` }, { status: 400 });
      }
    }

    if (dryRun) {
      return NextResponse.json({ data: plan });
    }
    if (plan.removed.length && !confirmRemovals) {
      return NextResponse.json(
        {
          error: `This would delete ${plan.removed.length} rule(s) that are not in the file. Each scope `
            + "the file names is replaced wholesale. Confirm the removals to proceed.",
        },
        { status: 409 }
      );
    }

    const applied: string[] = [];
    for (const scope of plan.scopes) {
      await saveScope(scope, plan.result[scope]);
      applied.push(scope);
    }
    return NextResponse.json({ data: { applied, ...plan } });
  } catch (err) {
    return configFailed("pricing import", err);
  }
}
