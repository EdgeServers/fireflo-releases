import { NextRequest, NextResponse } from "next/server";
import { gql } from "@/lib/gateway-graphql";
import { SESSION_MATCH } from "@/lib/gateway-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

const KINDS = ["ip", "account", "system_id"];

/**
 * GET /api/control/sessions/match?kind=ip|account|system_id&value=…[&listener=]
 *
 * <p>Who a force disconnect would drop, for the dialog's preview. The gateway's `sessionMatch`
 * field on the read token: exact matches across every listener, changing nothing.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) return NextResponse.json({ error: "Not found" }, { status: 404 });
    throw err;
  }
  const kind = req.nextUrl.searchParams.get("kind") ?? "";
  const value = (req.nextUrl.searchParams.get("value") ?? "").trim();
  if (!KINDS.includes(kind) || !value) {
    return NextResponse.json({ error: "Name an ip, an account or a system_id." }, { status: 400 });
  }
  const listener = req.nextUrl.searchParams.get("listener");
  return gql({
    query: SESSION_MATCH,
    variables: { target: { [kind]: value }, listener: listener || undefined },
    timeoutMs: 5_000,
  });
}
