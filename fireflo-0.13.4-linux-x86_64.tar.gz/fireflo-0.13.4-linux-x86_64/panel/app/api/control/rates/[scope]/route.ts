import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { deleteScope, listManagedRules, listRules, resolveKnownScopes, saveScope } from "@/lib/rates";
import { parseScopeBody } from "@/lib/rate-request";
import { scopeKind, validateScope } from "@/lib/rate-types";

type Params = { params: Promise<{ scope: string }> };

const TABLES = "app_rate_rule and app_rate_rule_condition";

export async function GET(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { scope } = await params;

  try {
    const [rules, managed, known] = await Promise.all([listRules(scope), listManagedRules(scope), resolveKnownScopes()]);
    //managed: a platform's custom tariff (gateway V1.101.0), read-only and never part of `rules`, so
    //saving the form cannot drop it
    return NextResponse.json({ data: { scope, kind: scopeKind(scope, known), rules, managed, known } });
  } catch (err) {
    return configFailed("rates", err);
  }
}

/**
 * Replaces a scope's rules wholesale.
 *
 * <p>PUT rather than POST because that is exactly what it is: idempotent replacement of one whole
 * resource. `workers/route.ts` uses POST for the same semantics, which is a historical accident
 * rather than a pattern worth propagating.
 *
 * <p>The unit is the scope and not the rule. Rate matching is ordinal — the first rule that matches
 * wins — so a rule has no meaning apart from its neighbours, and an endpoint that accepted rule 3 on
 * its own would let someone produce an order nobody ever looked at.
 */
export async function PUT(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { scope } = await params;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const input = parseScopeBody(scope, body);
  if (typeof input === "string") {
    return NextResponse.json({ error: input }, { status: 400 });
  }

  const invalid = validateScope(input, await resolveKnownScopes());
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }

  try {
    await saveScope(scope, input.rules);
    return NextResponse.json({ data: { scope, rules: input.rules.length } });
  } catch (err) {
    return configFailed("rates", err);
  }
}

export async function DELETE(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { scope } = await params;

  try {
    const removed = await deleteScope(scope);
    return removed == null
      ? NextResponse.json({ error: `Nothing priced under '${scope}'.` }, { status: 404 })
      : NextResponse.json({ data: { scope, deleted: true, rules: removed } });
  } catch (err) {
    return configFailed("rates", err);
  }
}
