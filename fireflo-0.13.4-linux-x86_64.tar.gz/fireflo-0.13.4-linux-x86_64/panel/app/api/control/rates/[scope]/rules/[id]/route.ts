import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { setRuleEnabled } from "@/lib/rates";

type Params = { params: Promise<{ scope: string; id: string }> };

const TABLES = "app_rate_rule";

/**
 * Turns one rule on or off, without touching the order.
 *
 * <p>Separate from the whole-scope PUT because retiring a rule is the thing an operator does in a
 * hurry — usually because it is charging the wrong amount — and it should not require sending every
 * other rule back to do it. It also cannot reorder anything by accident, which the whole-scope path
 * inherently can.
 *
 * <p>This is the preferred way to stop a rule. The row and its id survive, so
 * `cdr_submit.price_rule_id` stays resolvable for every message it ever charged; a delete makes that
 * history unreadable, and nothing in the database would warn, because `cdr_submit` has no foreign
 * keys.
 */
export async function PATCH(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { scope, id } = await params;

  if (!/^\d+$/.test(id)) {
    return NextResponse.json({ error: "A rule id is a whole number." }, { status: 400 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const enabled = (body as Record<string, unknown>)?.enabled;
  if (typeof enabled !== "boolean") {
    return NextResponse.json({ error: "Expected { enabled: true | false }." }, { status: 400 });
  }

  try {
    //scoped by both, so a rule id from another scope cannot be flipped through this path
    const found = await setRuleEnabled(scope, Number(id), enabled);
    return found
      ? NextResponse.json({ data: { scope, id: Number(id), enabled } })
      : NextResponse.json({ error: `No rule ${id} in '${scope}'.` }, { status: 404 });
  } catch (err) {
    return configFailed("rates", err);
  }
}
