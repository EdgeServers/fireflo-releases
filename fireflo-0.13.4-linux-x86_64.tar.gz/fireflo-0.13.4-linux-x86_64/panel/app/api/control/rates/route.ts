import { NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { listScopes, resolveKnownScopes } from "@/lib/rates";

const TABLES = "app_rate_rule and app_rate_rule_condition";

/**
 * Every priced scope, plus what a scope is allowed to be.
 *
 * <p>`known` comes back with the list so the page can classify each scope as a vendor cost or an
 * account price. That classification is derived and never stored: the schema has one `scope` column
 * with two opposite meanings, and adding a column to record which would be a second source of truth
 * the gateway does not read.
 */
export async function GET(): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  try {
    const [scopes, known] = await Promise.all([listScopes(), resolveKnownScopes()]);
    return NextResponse.json({ data: { scopes, known } });
  } catch (err) {
    return configFailed("rates", err);
  }
}
