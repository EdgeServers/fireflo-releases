import { NextRequest, NextResponse } from "next/server";
import { auditedDownload } from "@/lib/access-log";
import { gqlFile } from "@/lib/gateway-graphql";
import { CAPTURE_FILE } from "@/lib/gateway-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET /api/control/workers/{name}/sessions/{id}/capture/file/{txt|pcap}
 *
 * <p>The two artefacts of a finished capture, decoded from the gateway's `FileResult` and served as
 * an attachment. Separate from the JSON route beside it because the answer is a file.
 *
 * <p><strong>`kind` is matched against a fixed pair, not interpolated.</strong> It becomes the
 * `CaptureKind` the gateway takes, so anything outside {@link KINDS} is refused rather than passed
 * along. The filename is the gateway's own, sanitised in `gqlFile`.
 *
 * <p>Both files contain message content and destination numbers, which is why they are behind the
 * operator check and the gateway's admin token, and why the response says `no-store`.
 */
type Params = { params: Promise<{ name: string; id: string; kind: string }> };

const KINDS: Record<string, "TEXT" | "PCAP"> = {
  txt: "TEXT",
  pcap: "PCAP",
};

export async function GET(req: NextRequest, { params }: Params): Promise<NextResponse | Response> {
  let operator: string;
  try {
    operator = (await requireOperator()).name;
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const { name, id, kind } = await params;
  const captureKind = KINDS[kind];
  if (!captureKind) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  if (!/^\d+$/.test(id)) {
    return NextResponse.json({ error: `'${id}' is not a session id.` }, { status: 400 });
  }

  //audited here rather than inside gqlFile: that helper has neither a request nor a session, and
  //this file carries decoded message bodies and destination numbers, so who took a copy is worth a
  //line even though taking one changes nothing
  return auditedDownload(
    req,
    { kind: "capture", actor: operator, subject: `${name}#${id}.${kind}` },
    () => gqlFile({ query: CAPTURE_FILE, variables: { worker: name, sessionId: id, kind: captureKind }, auth: "admin" })
  );
}
