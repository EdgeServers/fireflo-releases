import { NextResponse } from "next/server";
import { gql } from "@/lib/gateway-graphql";
import { TEST_BIND } from "@/lib/gateway-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * POST /api/control/workers/{name}/test-bind
 *
 * <p>Asks the gateway to dial this vendor once and report what came back.
 *
 * <p>The admin token, as the call below says. This once claimed the opposite — "uses the read token,
 * not the admin one" — which survived the change that moved it and made this file a trap for anyone
 * copying it as a template for a new action route. The gateway would answer such a route 404, which
 * reads as "the endpoint is switched off" rather than "you sent the wrong token".
 *
 * <p>The reasoning is on the call itself, next to the thing it justifies, so the two cannot drift
 * apart again.
 */
type Params = { params: Promise<{ name: string }> };

export async function POST(_req: Request, { params }: Params): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const { name } = await params;
  return gql({
    query: TEST_BIND,
    variables: { worker: name },
    //the admin token: this opens a real connection to a third party's SMSC, and on one that drops
    //the oldest session a second bind can cost the live one
    auth: "admin",
    //the gateway allows itself five seconds for a TCP check, five to connect and ten to bind, three
    //per enquire_link and two to unbind -- about thirty-one at worst. This has to outlast them or a
    //slow vendor looks like a panel timeout
    timeoutMs: 40_000,
  });
}
