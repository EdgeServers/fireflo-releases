import { NextRequest, NextResponse } from "next/server";
import { gql } from "@/lib/gateway-graphql";
import { snakeCaseKeysDeep } from "@/lib/gateway-graphql-core";
import { SESSIONS } from "@/lib/gateway-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

type Params = { params: Promise<{ name: string }> };

/**
 * GET /api/control/workers/[name]/sessions?q=&offset=&limit=
 *
 * <p>One worker's bound sessions, searched and paged.
 *
 * <p>The read token, not admin: this only reads, and the same separation that lets a monitoring
 * system fetch health applies here. Disconnecting one of these sessions is the admin call, and it
 * lives at the `/disconnect` leaf.
 *
 * <p><strong>The three parameters are rebuilt as variables</strong> rather than forwarded
 * wholesale, so nothing else the browser sends reaches the management port. The numbers are only
 * checked for being numbers — the gateway's own clamp is the authority on how large a page may be,
 * and duplicating that bound here would give two answers to one question.
 *
 * <p>The typed `SessionPage` is camelCase; the rows are converted to the snapshot's spelling
 * (`session_id`, `bind_type`) because the table that renders them is the one that renders the
 * health snapshot's sessions.
 */
export async function GET(request: NextRequest, { params }: Params): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const { name } = await params;
  if (!name.trim()) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const variables: Record<string, unknown> = { worker: name };
  const q = request.nextUrl.searchParams.get("q");
  if (q && q.trim()) {
    variables.q = q.trim();
  }
  for (const key of ["offset", "limit"] as const) {
    const value = request.nextUrl.searchParams.get(key);
    if (value && /^\d+$/.test(value)) {
      variables[key] = Number(value);
    }
  }

  return gql({ query: SESSIONS, variables, timeoutMs: 10_000, select: snakeCaseKeysDeep });
}
