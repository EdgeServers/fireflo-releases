import { NextResponse } from "next/server";
import { auditConfigChange } from "@/lib/config-audit";
import { gql } from "@/lib/gateway-graphql";
import { WORKER_ACTION } from "@/lib/gateway-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { WORKER_ACTIONS, type WorkerAction } from "@/lib/worker-actions";

/**
 * POST /api/control/workers/{name}/{action}
 *
 * <p>Applies one control to a worker immediately, instead of waiting up to thirty seconds for the
 * gateway to notice the stored change on its next poll.
 *
 * <p>Uses the admin token. These are the only calls the panel makes that change what the gateway is
 * doing, and the gateway will refuse them if presented with the read-only one.
 *
 * <p>The verb is checked against the known list before forwarding, so an unexpected path segment
 * cannot be passed through to the gateway.
 */
type Params = { params: Promise<{ name: string; action: string }> };

export async function POST(_req: Request, { params }: Params): Promise<NextResponse> {
  let operator;
  try {
    operator = await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const { name, action } = await params;
  if (!WORKER_ACTIONS.includes(action as WorkerAction)) {
    return NextResponse.json(
      { error: `Unknown action '${action}'. Valid actions: ${WORKER_ACTIONS.join(", ")}.` },
      { status: 400 }
    );
  }

  const res = await gql({
    query: WORKER_ACTION,
    variables: { worker: name, action },
    auth: "admin",
    //enable and disable start or stop a worker, which waits on SMPP session teardown
    timeoutMs: 30_000,
    //a frozen licence answers 402 here with a sentence, and useWorkers branches on that status:
    //while frozen the gateway adopts NO configuration, so the usual "picked up within thirty
    //seconds" promise would be a lie. The status is the only way the client can tell "gateway
    //down" (wait works) from "licence lapsed" (wait does not)
    passErrors: true,
  });
  if (res.ok) {
    //the stored flag behind suspend/hold is audited by setWorkerProperty; this is the live control
    //the gateway applied now, which is what stopped or started the traffic
    await auditConfigChange({ domain: "worker", name, action: `action:${action}` }, operator);
  }
  return res;
}
