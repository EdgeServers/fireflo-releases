import { NextRequest, NextResponse } from "next/server";
import { gql } from "@/lib/gateway-graphql";
import { FILES } from "@/lib/gateway-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET /api/control/gateway-files
 *
 * <p>What the gateway will read back, and the state of each file.
 *
 * <p>The admin token, like the other three in this group. The listing itself is harmless, but the
 * routes it advertises serve log lines carrying destination numbers and, with `print.msgs=true`,
 * message text — so the whole group sits behind the stronger secret rather than splitting the
 * catalogue away from what it catalogues.
 */
export async function GET(_request: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      //404 rather than 403: a 403 confirms there is something here worth being forbidden from
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  //stat on eight paths. If it cannot answer in five seconds the disk is the diagnosis
  return gql({ query: FILES, auth: "admin", timeoutMs: 5_000 });
}
