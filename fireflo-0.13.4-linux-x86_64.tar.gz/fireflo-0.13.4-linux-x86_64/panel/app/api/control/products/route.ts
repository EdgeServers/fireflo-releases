import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { createProduct, listOrphanProducts, listProducts } from "@/lib/products";
import { type ProductInput, slugify, validateProduct } from "@/lib/product-types";

const TABLES = "app_product";

/**
 * The product catalogue.
 *
 * <p>GET returns the orphans alongside the catalogue — products that exist as strings on a rate rule
 * or a credential with no row describing them. There is no foreign key holding those together on
 * purpose, so this list is what stops an undescribed product being invisible.
 */
export async function GET(): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  try {
    const [products, orphans] = await Promise.all([listProducts(), listOrphanProducts()]);
    return NextResponse.json({ data: { products, orphans } });
  } catch (err) {
    return configFailed("products", err);
  }
}

/**
 * Creates a product.
 *
 * <p>Create only — editing goes through `PUT /api/control/products/[name]`, because a product's name
 * is its identity and there is nothing here that could rename one safely.
 *
 * <p>The code the browser sends is a request, not a decision: it may have been taken since the form
 * was opened, so the server derives it again from the display name when none was given and reserves
 * whatever is free inside the insert. The response carries the code actually used, and the caller
 * has to show it rather than assume.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const input = parse(body);
  if (typeof input === "string") {
    return NextResponse.json({ error: input }, { status: 400 });
  }

  const base = input.name.trim() || slugify(input.label ?? "");
  if (!base) {
    return NextResponse.json(
      {
        error: `'${input.label ?? ""}' produces no usable code — a code is lowercase letters, digits `
          + "and hyphens. Type one.",
      },
      { status: 400 }
    );
  }

  const invalid = validateProduct({ ...input, name: base }, true);
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }

  try {
    const name = await createProduct(input, base);
    return NextResponse.json({ data: { name, requested: base } });
  } catch (err) {
    return configFailed("products", err);
  }
}

/**
 * An unknown body into a ProductInput, or the reason it is not one.
 *
 * <p>Exported so a test can reach it, and hand-written because the failure has to name the field
 * rather than produce a schema dump — the same argument `workers/route.ts` makes.
 */
export function parse(body: unknown): ProductInput | string {
  if (!body || typeof body !== "object") {
    return "Expected an object.";
  }
  const raw = body as Record<string, unknown>;
  //absent is legitimate on create: the server derives the code from the display name
  if (raw.name !== undefined && typeof raw.name !== "string") {
    return "The code must be text.";
  }
  return {
    name: typeof raw.name === "string" ? raw.name : "",
    label: typeof raw.label === "string" ? raw.label : null,
    description: typeof raw.description === "string" ? raw.description : null,
    //absent means enabled: creating something switched off would surprise more people than it helps
    enabled: raw.enabled === undefined ? true : raw.enabled === true,
    //absent means checked, matching the column default. This is the fail-closed direction: a caller
    //that omits the field gets whitelisting applied, never silently skipped
    whitelistEnabled: raw.whitelistEnabled === undefined ? true : raw.whitelistEnabled === true,
  };
}
