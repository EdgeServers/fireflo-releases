import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { listRulesForProduct, resolveKnownScopes, saveScope } from "@/lib/rates";
import { diffScopes, fromCsv } from "@/lib/pricing-csv";
import { validateScope } from "@/lib/rate-types";

type Params = { params: Promise<{ name: string }> };

/** A route reading an unbounded body as text is a denial of service one curl away. */
const MAX_BYTES = 2 * 1024 * 1024;

/**
 * Applies a pricing CSV — or, with `?dryRun=1`, says what it would do.
 *
 * <p>The plan is **recomputed here in both modes**. The browser never sends back what it was shown:
 * a stale plan applied against a database that has changed since is the exact thing to prevent, and
 * recomputing costs one parse.
 *
 * <p>Applying is one PUT-equivalent per scope, **sequentially and not atomic across them**. Each
 * scope is one transaction; if the third of five fails, the first two are already live. Atomicity
 * across scopes would need an endpoint that takes several, and scope-as-unit is the whole design of
 * `saveScope`.
 */
export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite("app_rate_rule and app_rate_rule_condition");
  if (refused) {
    return refused;
  }
  const { name } = await params;
  const url = new URL(req.url);
  const dryRun = url.searchParams.get("dryRun") === "1";
  const confirmRemovals = url.searchParams.get("confirmRemovals") === "1";

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const text = (body as Record<string, unknown>)?.csv;
  if (typeof text !== "string") {
    return NextResponse.json({ error: "Expected { csv: string }." }, { status: 400 });
  }
  if (text.length > MAX_BYTES) {
    return NextResponse.json(
      { error: `That file is larger than ${MAX_BYTES / 1024 / 1024} MB.` },
      { status: 413 }
    );
  }

  const rows = fromCsv(text, name);
  if (typeof rows === "string") {
    return NextResponse.json({ error: rows }, { status: 400 });
  }

  try {
    const stored = await listRulesForProduct(name);
    const plan = diffScopes(rows, stored);
    if (typeof plan === "string") {
      return NextResponse.json({ error: plan }, { status: 400 });
    }

    //the cross-rule checks -- a catch-all shadowing what is below it in the same bucket -- can only
    //run on a whole scope, and this is the shape most likely to be wrong in a hand-edited file
    const known = await resolveKnownScopes();
    for (const scope of plan.scopes) {
      const invalid = validateScope({ scope, scopeConfirmed: true, rules: plan.result[scope] }, known);
      if (invalid) {
        return NextResponse.json({ error: `In '${scope}': ${invalid}` }, { status: 400 });
      }
    }

    if (dryRun) {
      return NextResponse.json({ data: plan });
    }

    if (plan.removed.length && !confirmRemovals) {
      return NextResponse.json(
        {
          error: `This would delete ${plan.removed.length} rule(s) that are not in the file. A scope `
            + "the file mentions is replaced wholesale. Confirm the removals to proceed.",
        },
        { status: 409 }
      );
    }

    const applied: string[] = [];
    for (const scope of plan.scopes) {
      await saveScope(scope, plan.result[scope]);
      applied.push(scope);
    }
    return NextResponse.json({ data: { applied, ...plan } });
  } catch (err) {
    return configFailed("pricing import", err);
  }
}
