import { NextRequest, NextResponse } from "next/server";
import { auditedDownload } from "@/lib/access-log";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { requireOperator } from "@/lib/require-operator";
import { listRulesForProduct } from "@/lib/rates";
import { toCsv } from "@/lib/pricing-csv";

type Params = { params: Promise<{ name: string }> };

/**
 * This product's pricing as CSV, synchronously.
 *
 * <p>Not the job store `lib/exports.ts` runs. That is an asynchronous filesystem queue with a
 * retention sweep, built for a month of call records; a few hundred pricing rules is kilobytes, and
 * the machinery would buy nothing.
 *
 * <p>Guarded like the page it belongs to: it is a read, but of the configuration database, and making
 * the export reachable when the page is not would be a strange place to differ.
 */
export async function GET(req: NextRequest, { params }: Params): Promise<NextResponse | Response> {
  const refused = await guardConfigWrite("app_rate_rule");
  if (refused) {
    return refused;
  }
  //the guard has already established this succeeds; it does not return the name
  const { name: operator } = await requireOperator();
  const { name } = await params;

  return auditedDownload(
    req,
    { kind: "pricing-export", actor: operator, subject: name },
    async () => {
      try {
        const scopes = await listRulesForProduct(name);
        const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
        //the CDR export's filename comes from a generated job id and needs no escaping. This one is
        //user input: an unescaped quote breaks out of the quoted filename, and a CRLF is header
        //injection
        const safe = name.replace(/[^A-Za-z0-9._-]/g, "_");

        return new Response(toCsv(scopes), {
          headers: {
            "Content-Type": "text/csv; charset=utf-8",
            "Content-Disposition": `attachment; filename="fireflo-pricing-${safe}-${stamp}.csv"`,
            "Cache-Control": "private, no-store",
          },
        });
      } catch (err) {
        return configFailed("pricing export", err);
      }
    }
  );
}
