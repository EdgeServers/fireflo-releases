import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { copyDefaultToAccounts } from "@/lib/rates";

type Params = { params: Promise<{ name: string }> };

const TABLES = "app_rate_rule";

/**
 * Pushes a product's default price down onto every account that has none for it.
 *
 * <p>Separate from the pricing import, which replaces a scope wholesale. This only ever inserts, and
 * an account that already prices the product is reported rather than overwritten -- silently
 * replacing negotiated prices with a list price across every customer at once is the one outcome
 * this endpoint must never have.
 *
 * <p>Not required for the default to work. The gateway already applies it to any account with no
 * rule of its own; this is for operators who want each account carrying an explicit copy they can
 * then edit individually.
 */
export async function POST(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { name } = await params;
  const product = decodeURIComponent(name);

  try {
    const result = await copyDefaultToAccounts(product);
    return NextResponse.json({
      data: result,
      notice: result.skipped.length
        ? `${result.applied.length} account(s) now carry their own copy. `
          + `${result.skipped.length} already priced '${product}' and were left untouched.`
        : `${result.applied.length} account(s) now carry their own copy.`,
    });
  } catch (err) {
    return configFailed("pricing", err);
  }
}
