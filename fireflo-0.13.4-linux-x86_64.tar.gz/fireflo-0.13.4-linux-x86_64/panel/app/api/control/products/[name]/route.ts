import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { deleteProduct, setProductEnabled, updateProduct } from "@/lib/products";
import { validateProduct } from "@/lib/product-types";

type Params = { params: Promise<{ name: string }> };

const TABLES = "app_product";

/**
 * Edits a product's description and whether it is listed.
 *
 * <p>The name in the path is the identity and is never changed by this — anything in the body that
 * looks like a name is ignored. A product's code is compared by value by every rate rule, every
 * credential and every historical call record, with no foreign key that could follow it.
 */
export async function PUT(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { name } = await params;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const raw = (body ?? {}) as Record<string, unknown>;
  const input = {
    name,
    label: typeof raw.label === "string" ? raw.label : null,
    description: typeof raw.description === "string" ? raw.description : null,
    enabled: raw.enabled === undefined ? true : raw.enabled === true,
    //as on create: absent means checked, so an older client that does not know this field cannot
    //turn a product's whitelisting off by omission
    whitelistEnabled: raw.whitelistEnabled === undefined ? true : raw.whitelistEnabled === true,
  };

  const invalid = validateProduct(input, false);
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }

  try {
    const found = await updateProduct(input);
    return found
      ? NextResponse.json({ data: { name } })
      : NextResponse.json({ error: `Nothing named '${name}'.` }, { status: 404 });
  } catch (err) {
    return configFailed("products", err);
  }
}

/**
 * Retire or remove one product.
 *
 * <p>Worth knowing what `enabled` does and does not do here: disabling a product removes it from
 * this panel's lists and changes nothing about pricing. Its rate rules go on charging exactly as
 * before. That is the opposite of `app_worker.enabled` and the UI has to say so.
 *
 * <p><strong>With one real effect.</strong> The gateway reads exempt products as
 * `enabled AND NOT whitelist_enabled`, so unlisting a product that was exempt puts its traffic back
 * under the whitelist. That direction is the safe one — traffic starts being checked rather than
 * stopping — but it can begin rejecting sender IDs nobody has approved, so the UI says it.
 */
export async function PATCH(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { name } = await params;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const enabled = (body as Record<string, unknown>)?.enabled;
  if (typeof enabled !== "boolean") {
    return NextResponse.json({ error: "Expected { enabled: true | false }." }, { status: 400 });
  }

  try {
    const found = await setProductEnabled(name, enabled);
    return found
      ? NextResponse.json({ data: { name, enabled } })
      : NextResponse.json({ error: `Nothing named '${name}'.` }, { status: 404 });
  } catch (err) {
    return configFailed("products", err);
  }
}

export async function DELETE(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { name } = await params;

  try {
    const result = await deleteProduct(name);
    if (result.kind === "not-found") {
      return NextResponse.json({ error: `Nothing named '${name}'.` }, { status: 404 });
    }
    if (result.kind === "in-use") {
      //409 rather than 400: the request is well formed and it is the state that forbids it.
      //Both users are named, and separately, because they are unpicked in different places -- rules
      //under Pricing, logins on the account -- and a message that lumped them together would send
      //the operator to one of the two
      const used = [
        result.rules ? `prices ${result.rules} rule(s) across ${result.scopes} scope(s)` : null,
        result.credentials ? `is the default product on ${result.credentials} login(s)` : null,
        result.allowedBy ? `is allowed on ${result.allowedBy} login(s)` : null,
        result.registrations ? `scopes ${result.registrations} sender ID, template or whitelist row(s)` : null,
      ].filter(Boolean).join(", and ");
      //since gateway V1.56.0 every one of those is a foreign key to the product, so this is no longer
      //advice: the delete cannot happen until they point somewhere else
      return NextResponse.json(
        {
          error: `'${name}' still ${used}. Move those to another product first. To stop selling it `
            + "without deleting it, unlist it instead.",
        },
        { status: 409 }
      );
    }
    return NextResponse.json({ data: { name, deleted: true } });
  } catch (err) {
    return configFailed("products", err);
  }
}
