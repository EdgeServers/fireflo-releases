import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { listScopesForProduct, resolveKnownScopes, saveScopeForProduct } from "@/lib/rates";
import { parseScopeBody } from "@/lib/rate-request";
import { validateScope } from "@/lib/rate-types";

type Params = { params: Promise<{ name: string }> };

/**
 * Which scopes price this product, as counts.
 *
 * <p>This used to return every scope complete, because the page held them all so it could save one —
 * and it refused past two thousand rules, so at a thousand customers the page stopped loading
 * altogether. It now returns one aggregate with no ceiling, and a scope's rules are fetched through
 * `/api/control/rates/[scope]` when somebody opens that row.
 *
 * <p>The whole-scope rule has not gone anywhere: it moved to the expanded row, which still loads and
 * holds a complete scope even though it displays one product's slice of it.
 */
export async function GET(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite("app_rate_rule");
  if (refused) {
    return refused;
  }
  const { name } = await params;

  try {
    const [scopes, known] = await Promise.all([listScopesForProduct(name), resolveKnownScopes()]);
    return NextResponse.json({ data: { product: name, scopes, known } });
  } catch (err) {
    //the 413 that used to live here is gone with the reason for it: nothing loads whole scopes any
    //more, so there is no ceiling left to refuse against
    return configFailed("product pricing", err);
  }
}

/**
 * Sets what one scope charges for **this product**, and touches nothing else in that scope.
 *
 * <p>The scope arrives in the body rather than the path because the product is the resource here:
 * this is "the pricing of `promo`", addressed from the page showing it. `PUT /api/control/rates/*`
 * is the other endpoint, and it replaces the scope wholesale — correct on `/cp/pricing`, where the
 * form holds and shows the entire scope, and a data-loss trap from here. Setting a `*` default for
 * `promo` through that route would delete `*` for every other product on the platform.
 *
 * <p><strong>Every rule is written into this product's bucket regardless of what its body said.</strong>
 * The product is the address, not a field to be trusted: honouring a `product` sent by the browser
 * would let a form opened on `promo` write `transactional` prices, from a page that would then not
 * show them.
 */
export async function PUT(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite("app_rate_rule");
  if (refused) {
    return refused;
  }
  const { name } = await params;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const scope = (body as { scope?: unknown })?.scope;
  if (typeof scope !== "string" || !scope.trim()) {
    return NextResponse.json(
      { error: "Expected { scope, rules: [...] }. The scope names the account this prices, or '*' "
        + "for every account with no pricing of its own." },
      { status: 400 }
    );
  }

  const input = parseScopeBody(scope, body);
  if (typeof input === "string") {
    return NextResponse.json({ error: input }, { status: 400 });
  }

  //validated as it will be STORED, not as it arrived: the save forces every rule into this
  //product's bucket, and a validator looking at a different product would bucket the catch-all
  //check wrongly and pass an order that is dead on arrival
  const stored = { ...input, rules: input.rules.map((r) => ({ ...r, product: name })) };
  const invalid = validateScope(stored, await resolveKnownScopes());
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }

  try {
    await saveScopeForProduct(scope, name, input.rules);
    return NextResponse.json({ data: { scope, product: name, rules: input.rules.length } });
  } catch (err) {
    return configFailed("product pricing", err);
  }
}
