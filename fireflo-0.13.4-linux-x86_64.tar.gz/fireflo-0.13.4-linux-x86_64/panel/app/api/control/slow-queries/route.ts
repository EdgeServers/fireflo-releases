import { NextRequest, NextResponse } from "next/server";
import { auditConfigChange } from "@/lib/config-audit";
import { GatewayError, gql, gqlData } from "@/lib/gateway-graphql";
import { SLOW_QUERIES, SLOW_QUERIES_CLEAR, SLOW_QUERY_SUMMARY } from "@/lib/gateway-queries";
import { NotOperatorError, requireAdmin, requireOperator } from "@/lib/require-operator";
import {
  isSlowWindow,
  windowSince,
  type SlowQueriesPayload,
  type SlowQuery,
  type SlowQuerySummary,
} from "@/lib/slow-queries";

/**
 * GET /api/control/slow-queries?window=1h|6h|24h|all&minMs=&caller=&limit=
 *
 * <p>The gateway's slow-query log: the fold by shape and the raw statements, both over the same
 * window so the two agree. The read token; any operator. On a gateway without the log (older than
 * 0.13) the gateway refuses the field and the page says so from the capability map before asking.
 *
 * <p>DELETE forgets everything the ring holds. Admins only, and audited: it is the one write here.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const q = req.nextUrl.searchParams;
  const window = q.get("window") ?? "24h";
  if (!isSlowWindow(window)) {
    return NextResponse.json({ error: "window must be 1h, 6h, 24h or all." }, { status: 400 });
  }
  const since = windowSince(window);
  const minMs = Number(q.get("minMs"));
  const limit = Number(q.get("limit"));
  const caller = (q.get("caller") ?? "").trim();
  const variables: Record<string, unknown> = {
    since: since ?? undefined,
    minMs: Number.isInteger(minMs) && minMs > 0 ? minMs : undefined,
    //the gateway's own clamp is the authority; this only keeps it a positive whole number
    limit: Number.isInteger(limit) && limit > 0 ? Math.min(limit, 1_000) : undefined,
    caller: caller || undefined,
  };

  try {
    const [summary, queries] = await Promise.all([
      gqlData<SlowQuerySummary>({ query: SLOW_QUERY_SUMMARY, variables: { since: since ?? undefined }, timeoutMs: 10_000 }),
      gqlData<SlowQuery[]>({ query: SLOW_QUERIES, variables, timeoutMs: 10_000 }),
    ]);
    const data: SlowQueriesPayload = { summary, queries: queries ?? [], since };
    return NextResponse.json({ data });
  } catch (err) {
    if (err instanceof GatewayError) {
      return NextResponse.json({ error: err.message, code: err.code }, { status: err.status >= 500 ? 502 : err.status });
    }
    throw err;
  }
}

export async function DELETE(): Promise<NextResponse> {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const res = await gql({ query: SLOW_QUERIES_CLEAR, auth: "admin", timeoutMs: 10_000 });
  if (res.ok) {
    //a record forgotten rather than configuration changed, logged under the same event as the
    //TPS-peak reset for the same reason: "who cleared the evidence before the review"
    await auditConfigChange({ domain: "slow_queries", name: "ring", action: "delete" }, admin);
  }
  return res;
}
