import { NextResponse } from "next/server";
import { auditConfigChange } from "@/lib/config-audit";
import { runHousekeeping } from "@/lib/housekeeping-ops";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { ADMIN_ROLE } from "@/lib/roles";
import {
  BATCH_LIMIT,
  EMPTY_SELECTOR,
  housekeepingBody,
  isCleanStore,
  readHousekeepingResult,
  selectorProblem,
  type CleanSelector,
} from "@/lib/queue-clean";

/**
 * POST /api/control/queues/clean
 *
 * <p>Proxies one call to the gateway's housekeeping endpoint (`POST /ops/housekeeping/{store}`, admin
 * token) — the same endpoint the command line uses, so the refunds, receipts, REJECTED/operatorPurge
 * rows, archive rows and summary are identical whichever surface ran it.
 *
 * <p><strong>A dry run is an operator's; a clean is an admin's.</strong> A dry run claims nothing and
 * moves nothing, so it is the Queues page's "Show" for anyone who may read the queues. Executing ends
 * messages for good and is refused for anyone but an admin, with the same 404 every other admin-only
 * route gives. The browser never chooses the actor: it is the signed-in user's address, so the
 * gateway's archive rows and this panel's operator log name the same person. Writes are already
 * Origin-checked by the proxy.
 *
 * <p>Executing also requires a note. The gateway records it on every archived row; a clean nobody can
 * explain afterwards is the thing the archive exists to prevent.
 */
export async function POST(req: Request): Promise<NextResponse> {
  let operator;
  try {
    operator = await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const raw = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  if (!raw || typeof raw !== "object") {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const dryRun = raw.dryRun !== false;
  if (!dryRun && operator.role !== ADMIN_ROLE) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  if (!isCleanStore(raw.store)) {
    return NextResponse.json({ error: "Unknown store. Expected worker, routing, receipts or callbacks." }, { status: 400 });
  }
  const text = (key: string): string => (typeof raw[key] === "string" ? (raw[key] as string) : "");
  const selector: CleanSelector = {
    ...EMPTY_SELECTOR,
    store: raw.store,
    subStore: text("subStore"),
    worker: text("worker"),
    account: text("account"),
    systemId: text("systemId"),
    olderThan: text("olderThan"),
    all: raw.all === true,
  };
  const problem = selectorProblem(selector);
  if (problem) {
    return NextResponse.json({ error: problem }, { status: 400 });
  }
  const note = text("note").trim();
  if (!dryRun && !note) {
    return NextResponse.json({ error: "Say why in the note: it is recorded on every archived entry." }, { status: 400 });
  }
  const limit = typeof raw.limit === "number" && Number.isFinite(raw.limit) ? raw.limit : BATCH_LIMIT;

  const body = housekeepingBody(selector, { dryRun, limit, note, actor: operator.name });
  const res = await runHousekeeping(selector.store, body);

  if (!dryRun && res.ok) {
    //read off a clone: the response itself goes back to the browser untouched
    const answer = readHousekeepingResult((await res.clone().json().catch(() => null))?.data);
    await auditConfigChange(
      {
        domain: "queue",
        name: body.worker ?? body.account ?? body.systemId ?? selector.store,
        action: "action:archive",
        account: body.account ?? null,
        after: {
          store: selector.store,
          subStore: body.subStore ?? null,
          worker: body.worker ?? null,
          systemId: body.systemId ?? null,
          olderThanSeconds: body.olderThanSeconds ?? null,
          all: body.all ?? false,
          note,
          batchId: answer.batchId,
          matched: answer.matched,
          archived: answer.archived,
          refunded: answer.refunded,
          receiptsSent: answer.receiptsSent,
          failed: answer.failed.length,
        },
      },
      operator
    );
  }
  return res;
}
