import { NextRequest, NextResponse } from "next/server";
import { gql } from "@/lib/gateway-graphql";
import { QUEUES } from "@/lib/gateway-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET /api/control/queues
 *
 * <p>Proxies the gateway's queue dump. The read token, not the admin one — listing a queue takes
 * nothing off it and moves nothing.
 *
 * <p>`worker` and `limit` are passed through rather than forwarded wholesale: the gateway's own
 * clamp is the authority on the limit, but building the variables here rather than forwarding the
 * caller's query keeps anything else the browser sends away from the gateway.
 */
export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const variables: Record<string, unknown> = {};
  const worker = request.nextUrl.searchParams.get("worker");
  if (worker) {
    variables.worker = worker;
  }
  const limit = request.nextUrl.searchParams.get("limit");
  if (limit && /^\d+$/.test(limit)) {
    variables.limit = Number(limit);
  }

  //the gateway walks its queues in memory; five seconds is already the diagnosis if it cannot
  return gql({ query: QUEUES, variables, timeoutMs: 5_000 });
}
