import { NextRequest, NextResponse } from "next/server";
import { PREPROCESSOR_CHECK } from "@/lib/gateway-queries";
import { asAdmin, gateway, jsonBody } from "@/lib/preprocessor-ops";

/** POST { name, content }: syntax only, in a scratch copy on the gateway host. Nothing runs. */
export async function POST(req: NextRequest): Promise<NextResponse> {
  const who = await asAdmin();
  if (who instanceof NextResponse) return who;
  const body = await jsonBody(req);
  if (typeof body?.name !== "string" || typeof body?.content !== "string") {
    return NextResponse.json({ error: "Expected { name, content }." }, { status: 400 });
  }
  return gateway({
    query: PREPROCESSOR_CHECK,
    auth: "admin",
    timeoutMs: 15_000,
    variables: { input: { name: body.name, content: body.content } },
  });
}
