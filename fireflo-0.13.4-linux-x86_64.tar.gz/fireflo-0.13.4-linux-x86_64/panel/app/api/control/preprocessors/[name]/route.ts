import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { PreprocessorInUse, deletePreprocessor } from "@/lib/preprocessors";

export async function DELETE(
  _req: NextRequest,
  context: { params: Promise<{ name: string }> }
): Promise<NextResponse> {
  const refused = await guardConfigWrite("app_preprocessor");
  if (refused) {
    return refused;
  }
  const name = decodeURIComponent((await context.params).name);
  try {
    if (!(await deletePreprocessor(name))) {
      return NextResponse.json({ error: `No preprocessor called '${name}'.` }, { status: 404 });
    }
    return NextResponse.json({ data: { name } });
  } catch (err) {
    if (err instanceof PreprocessorInUse) {
      return NextResponse.json(
        {
          error: `'${err.preprocessorName}' is still the target of a routing rule. Change or remove those `
            + "rules first — the gateway would otherwise skip them without saying why.",
        },
        { status: 409 }
      );
    }
    return configFailed("delete preprocessor", err);
  }
}
