import { NextRequest, NextResponse } from "next/server";
import { PREPROCESSOR_TEST } from "@/lib/gateway-queries";
import { asAdmin, gateway, jsonBody } from "@/lib/preprocessor-ops";

/**
 * POST { name, content, fields, messages }: runs the DRAFT on the gateway host against sample
 * messages, in a throwaway copy of the directory, for at most ten seconds. Live traffic and the
 * running copies are untouched.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  const who = await asAdmin();
  if (who instanceof NextResponse) return who;
  const body = await jsonBody(req);
  if (typeof body?.name !== "string" || typeof body?.content !== "string" || !Array.isArray(body?.messages)) {
    return NextResponse.json({ error: "Expected { name, content, fields, messages }." }, { status: 400 });
  }
  return gateway({
    query: PREPROCESSOR_TEST,
    auth: "admin",
    timeoutMs: 20_000,
    variables: { input: { name: body.name, content: body.content, fields: body.fields ?? [], messages: body.messages } },
  });
}
