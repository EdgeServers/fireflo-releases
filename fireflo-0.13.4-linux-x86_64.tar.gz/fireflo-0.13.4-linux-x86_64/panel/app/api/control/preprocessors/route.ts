import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { listPreprocessors, preprocessorsAvailable, savePreprocessor } from "@/lib/preprocessors";
import { type PreprocessorInput, validatePreprocessor } from "@/lib/preprocessor-types";

const TABLES = "app_preprocessor";

/**
 * GET: every preprocessor with the rules that send to it. `available: false` when the database
 * predates gateway 0.12.0, so the page can say so rather than show a missing-table error.
 */
export async function GET(): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  try {
    if (!(await preprocessorsAvailable())) {
      return NextResponse.json({ data: { available: false, preprocessors: [] } });
    }
    return NextResponse.json({ data: { available: true, preprocessors: await listPreprocessors() } });
  } catch (err) {
    return configFailed("preprocessors", err);
  }
}

/** PUT: create or update one, by name. */
export async function PUT(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const num = (v: unknown, d: number) => (typeof v === "number" && Number.isFinite(v) ? Math.trunc(v) : d);
  const input: PreprocessorInput = {
    name: typeof body.name === "string" ? body.name : "",
    run: typeof body.run === "string" ? body.run : "",
    workers: num(body.workers, 2),
    timeoutMs: num(body.timeoutMs, 200),
    inflight: num(body.inflight, 1000),
    onError: typeof body.onError === "string" ? body.onError : "continue",
    fields: Array.isArray(body.fields) ? body.fields.filter((f): f is string => typeof f === "string") : [],
    label: typeof body.label === "string" ? body.label : null,
    enabled: body.enabled !== false,
  };
  const invalid = validatePreprocessor(input);
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }
  try {
    await savePreprocessor(input);
    return NextResponse.json({ data: { name: input.name.trim() } });
  } catch (err) {
    return configFailed("save preprocessor", err);
  }
}
