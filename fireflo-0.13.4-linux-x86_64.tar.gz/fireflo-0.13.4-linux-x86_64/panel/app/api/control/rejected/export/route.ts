import { NextRequest, NextResponse } from "next/server";
import { guardCdrRoute, queryFailed } from "@/lib/cdr-guard";
import {
  isRejectedFilterError,
  parseRejectedFilters,
  type RejectedCursor,
  type RejectedFilters,
} from "@/lib/rejected-request";
import { HEADERS, REJECTED_EXPORT_KIND, toCsvLine } from "@/lib/rejected-export";
import { listRejected } from "@/lib/rejected";
import type { RejectedRow } from "@/lib/rejected-types";
import { type ExportSource, listExports, requestExport, serialiseFilters } from "@/lib/exports";

/**
 * Refusals, as the generic job store consumes them.
 *
 * <p>`page` calls the ROW query, never `summariseRejected` — re-running a 24-hour aggregate for
 * every 5,000-row batch would be the most expensive available mistake here, and splitting those two
 * functions is what makes it unavailable rather than merely discouraged.
 */
const REJECTED_EXPORT: ExportSource<RejectedRow, RejectedFilters> = {
  kind: REJECTED_EXPORT_KIND,
  headers: HEADERS,
  toCsvLine,
  page: async (filters, cursor, batch) => {
    const page = await listRejected(filters, { limit: batch, cursor: cursor as RejectedCursor | null });
    return { rows: page.rows, nextCursor: page.nextCursor };
  },
  serialise: serialiseFilters,
};

/**
 * The refusal export queue: GET lists requests, POST makes one.
 *
 * <p>POST answers as soon as the request is recorded, not when the CSV is finished — a month of
 * refusals on an enforced account is exactly the case this exists for, and a synchronous download
 * would hold a connection open for minutes and lose everything if the browser gave up.
 */
export async function GET(): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  try {
    //scoped to this kind, so the Messages page's exports do not appear here and vice versa
    return NextResponse.json({ data: await listExports(REJECTED_EXPORT_KIND) });
  } catch (err) {
    return queryFailed("rejected export list", err);
  }
}

export async function POST(req: NextRequest): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }

  const params = new URL(req.url).searchParams;
  //the window is pinned to now, once. Re-deriving "last 24 hours" on every batch would slide the
  //range forward as the export runs, so the last page would be reading rows the first page's window
  //did not include
  const filters = parseRejectedFilters(params, new Date());
  if (isRejectedFilterError(filters)) {
    return NextResponse.json({ error: filters.error }, { status: 400 });
  }

  try {
    return NextResponse.json({
      data: await requestExport(REJECTED_EXPORT, filters, describe(params)),
    });
  } catch (err) {
    return queryFailed("rejected export request", err);
  }
}

/**
 * The filters as a phrase, for the list of requests.
 *
 * <p>Without it every row in that list says "refusals" and the only way to tell two apart is the
 * timestamp — which is exactly when someone downloads the wrong one.
 */
function describe(params: URLSearchParams): string {
  const parts: string[] = [];
  const range = params.get("range") ?? "24h";
  parts.push(range === "all" ? "all time" : `last ${range}`);
  for (const key of [
    "reason", "account", "systemId", "product", "ingress", "inGateway", "source", "dest",
    "msgId", "vendorStatus", "q",
  ]) {
    const value = params.get(key)?.trim();
    if (value) {
      parts.push(`${key} ${value}`);
    }
  }
  if (params.get("afterAccepting") === "1") {
    parts.push("accepted first");
  }
  if (params.get("hasMsgId") === "1") {
    parts.push("with a message id");
  }
  return parts.join(", ");
}
