import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { deleteTlvDefinition } from "@/lib/tlv-definitions";

type Params = { params: Promise<{ tag: string }> };

const TABLES = "app_tlv_definition";

/**
 * Removes one definition.
 *
 * <p>Deleting a name does not touch anything that uses the tag. Every declaration on a worker or a
 * credential goes on working exactly as before, because the gateway never read the name — all that
 * is lost is the annotation. Which is why this needs no confirmation beyond the button, unlike
 * deleting a vendor.
 */
export async function DELETE(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const { tag } = await params;
  const parsed = Number(tag);
  if (!Number.isInteger(parsed) || parsed < 0 || parsed > 0xffff) {
    return NextResponse.json({ error: "Not a tag." }, { status: 400 });
  }
  try {
    const removed = await deleteTlvDefinition(parsed);
    return removed
      ? NextResponse.json({ data: { tag: parsed } })
      : NextResponse.json({ error: "No definition for that tag." }, { status: 404 });
  } catch (err) {
    return configFailed("delete TLV definition", err);
  }
}
