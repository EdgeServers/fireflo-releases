import { NextRequest, NextResponse } from "next/server";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { runDeliveryCheck } from "@/lib/delivery-check";

/**
 * "Why are messages not being delivered?", answered on demand.
 *
 * <p>POST rather than GET because it is an action an operator takes, and because it fans out to
 * both databases and the gateway's management port — not something to run on every page load.
 *
 * <p>Read-only. It applies nothing; the four fixes it can offer go through the existing write
 * routes, so their validation and their audit trail apply unchanged.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      //404, not 403 and not the 500 a bare requireOperator() produces: the point of the 404 is that
      //an anonymous caller cannot confirm this endpoint exists, and an unhandled error confirms it
      //just as well as a forbidden would
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const account = req.nextUrl.searchParams.get("account");
  try {
    const { findings, skipped, boundVendors } = await runDeliveryCheck(account?.trim() || null);
    return NextResponse.json({ data: { findings, skipped, boundVendors } });
  } catch (err) {
    //the gatherer degrades rather than throwing, so reaching this means something unforeseen --
    //still not a 500 page, because this is the tool somebody opened *because* things are broken
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "The check could not run." },
      { status: 500 }
    );
  }
}
