import type { NextRequest } from "next/server";
import { logOperatorEvent } from "@/lib/access-log";
import { auth, handlers } from "@/lib/auth";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { currentRequestContext, runWithRequestContext } from "@/lib/request-context";

/**
 * NextAuth's own handlers, wrapped so the access log can see the caller's address.
 *
 * <p>This used to be a three-line re-export. It is a wrapper now because `authorize()` — the only
 * code that knows whether a sign-in succeeded — is handed credentials and nothing else, so the IP
 * has to be put somewhere it can reach. `runWithRequestContext` does that; see
 * `lib/request-context.ts`.
 *
 * <p>Two things `authorize` cannot cover are handled here instead:
 *
 * <ul>
 *   <li><b>Sign-out</b>, which never reaches a provider. The session is read before delegating,
 *       because afterwards the cookie is gone and with it the name worth recording.</li>
 *   <li><b>A credential POST rejected before `authorize` ran</b> — a stale CSRF token, a malformed
 *       body. Without this net those attempts are the ones that vanish, and an attacker hammering
 *       the endpoint with junk is precisely who should not be invisible.</li>
 * </ul>
 */

export async function GET(req: NextRequest): Promise<Response> {
  return runWithRequestContext(req, () => handlers.GET(req));
}

export async function POST(req: NextRequest): Promise<Response> {
  const path = req.nextUrl.pathname;

  //read before delegating: after the handler runs the cookie has been cleared
  const signingOut = path.endsWith("/signout");
  const actor = signingOut ? ((await auth())?.user?.name ?? null) : null;

  return runWithRequestContext(req, async () => {
    const response = await handlers.POST(req);

    if (signingOut && response.status < 400) {
      void logOperatorEvent({
        event: "signout",
        actor,
        ip: clientIp(req),
        userAgent: clientUserAgent(req),
      });
    }

    //the net described above. `handled` is set by authorize(), so this only fires for attempts that
    //never got that far -- otherwise every failed password would be logged twice
    if (path.endsWith("/callback/operator") && !currentRequestContext()?.handled) {
      void logOperatorEvent({
        event: "signin_failed",
        actor: null,
        ip: clientIp(req),
        userAgent: clientUserAgent(req),
        detail: { reason: "rejected_before_authorize", status: response.status },
      });
    }

    return response;
  });
}
