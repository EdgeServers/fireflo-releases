import type { Metadata } from "next";
import { cookies } from "next/headers";
import { Noto_Sans } from "next/font/google";
import { ThemeProvider } from "@/components/ThemeProvider";
import "./globals.css";

/*
 * The base font is Noto Sans, through `next/font/google`: self-hosted from our own origin, so no
 * page load reaches Google, but `next build` fetches it from fonts.googleapis.com once, which a
 * build host without internet access cannot do. A variable font, so every weight the panel uses
 * (400 to 700) is real rather than synthesised. Exposed as `--font-noto-sans`, which `--font-sans`
 * in globals.css puts first in the stack, so the system UI font still answers while it loads.
 */
const notoSans = Noto_Sans({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-noto-sans",
});

/**
 * The product is called "FireFlo SMS/SMPP Gateway" in title positions and "FireFlo" in prose.
 *
 * <p>This is a title position, so it carries the long form. The header wordmark in
 * {@code FireFloMark} keeps the short one — it sits in a fixed-height bar beside the mark, and the
 * full name would wrap there without telling anyone anything the tab title has not already said.
 */
export const metadata: Metadata = {
  title: "Control Panel — FireFlo SMS/SMPP Gateway",
  description: "Operational metrics for the FireFlo SMS/SMPP Gateway",
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  //the theme cookie is written by ThemeProvider on the client; reading it here avoids the
  //first-paint flash. No cookie means no class, and the client applies one.
  const theme = (await cookies()).get("theme")?.value;

  return (
    <html
      lang="en"
      className={`${notoSans.variable}${theme === "dark" ? " dark" : ""}`}
      suppressHydrationWarning
    >
      <body>
        {/* no SessionProvider here: it belongs to the operator dashboard alone. Mounted at the root
            it probed /api/auth/session on every page, and Auth.js answers that probe with a fresh
            CSRF cookie whenever the browser has none -- which raced the login form's own CSRF
            fetch, and the portal's, and refused good sign-ins as MissingCSRF */}
        <ThemeProvider>{children}</ThemeProvider>
      </body>
    </html>
  );
}
