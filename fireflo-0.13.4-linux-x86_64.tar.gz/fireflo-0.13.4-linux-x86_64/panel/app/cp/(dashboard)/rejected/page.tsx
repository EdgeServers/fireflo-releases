import { RejectedClient } from "@/components/RejectedClient";

export const metadata = { title: "Refused" };

export default function RejectedPage() {
  return <RejectedClient />;
}
