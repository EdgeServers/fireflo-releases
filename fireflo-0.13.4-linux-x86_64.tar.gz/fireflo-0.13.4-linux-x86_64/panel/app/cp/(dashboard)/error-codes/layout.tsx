import type { ReactNode } from "react";
import { PageHeader } from "@/components/ui/page-header";
import { ErrorCodesShell } from "@/components/ErrorCodesShell";

/**
 * Both tiers of `dlr.errcodes`: the Every vendor list and each vendor's own, side by side.
 *
 * <p>A layout rather than a page so the left column -- every list, and which vendors replace the
 * global one -- stays mounted while an operator moves between them. Under Configuration rather than
 * beside a vendor because the global list is not any one vendor's; the button on a vendor's page
 * lands on that vendor's list here.
 */
export default function ErrorCodesLayout({ children }: { children: ReactNode }) {
  return (
    <>
      <PageHeader
        title="Error codes"
        description="What a carrier's failure code becomes on the receipt the customer reads."
      />
      <ErrorCodesShell>{children}</ErrorCodesShell>
    </>
  );
}
