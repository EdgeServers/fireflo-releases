import { VendorErrorCodesClient } from "@/components/VendorErrorCodesClient";

/**
 * Next 16: route params arrive as a promise.
 *
 * <p>No PageHeader: this is a page *of* the vendor, like its detail page, so it wears that page's
 * chrome -- a back link and a card whose header names the vendor -- rather than a report title.
 */
export default async function VendorErrorCodesPage({
  params,
}: {
  params: Promise<{ vendor: string }>;
}) {
  const { vendor } = await params;
  return <VendorErrorCodesClient name={decodeURIComponent(vendor)} />;
}
