import { ErrorCodesClient } from "@/components/ErrorCodesClient";

/** The Every vendor list. The header and the list of lists come from this section's layout. */
export default function ErrorCodesPage() {
  return <ErrorCodesClient />;
}
