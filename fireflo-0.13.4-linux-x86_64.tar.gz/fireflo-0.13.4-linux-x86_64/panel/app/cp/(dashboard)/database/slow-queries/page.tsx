import { SlowQueriesClient } from "@/components/SlowQueriesClient";

export default function SlowQueriesPage() {
  return <SlowQueriesClient />;
}
