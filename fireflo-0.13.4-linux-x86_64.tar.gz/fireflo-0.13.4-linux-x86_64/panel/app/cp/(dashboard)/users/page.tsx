import { notFound } from "next/navigation";
import { auth } from "@/lib/auth";
import { isAdminSession } from "@/lib/roles";
import { UsersClient } from "@/components/UsersClient";

/**
 * Admin-only. An operator who types the URL gets the same 404 an anonymous caller does -- the API
 * behind the page answers the same way, and the nav item is not rendered for them.
 */
export default async function UsersPage() {
  const session = await auth();
  if (!isAdminSession(session)) {
    notFound();
  }
  return <UsersClient />;
}
