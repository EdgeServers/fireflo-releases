import { QueuesClient } from "@/components/QueuesClient";

export const metadata = { title: "Queues" };

export default function QueuesPage() {
  return <QueuesClient />;
}
