import { Suspense } from "react";
import { PricingOverview } from "@/components/PricingOverview";

/** The overview. Suspense because it reads `?scope=` to forward old links. */
export default function PricingPage() {
  return (
    <Suspense>
      <PricingOverview />
    </Suspense>
  );
}
