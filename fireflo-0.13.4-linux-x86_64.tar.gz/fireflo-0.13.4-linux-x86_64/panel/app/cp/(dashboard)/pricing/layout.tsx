import { Suspense, type ReactNode } from "react";
import { PricingShell } from "@/components/PricingShell";

/**
 * The default, the accounts with pricing of their own and the vendors down the left, and the open
 * one beside them. A layout so the column stays mounted while an operator moves between them.
 * Suspense because the shell reads `?product=`, which narrows the whole section to one product.
 */
export default function PricingLayout({ children }: { children: ReactNode }) {
  return (
    <Suspense>
      <PricingShell>{children}</PricingShell>
    </Suspense>
  );
}
