import { Suspense } from "react";
import { ScopePricingClient } from "@/components/ScopePricingClient";

/** One scope's prices. Next 16: route params arrive as a promise. */
export default async function ScopePricingPage({ params }: { params: Promise<{ scope: string }> }) {
  const { scope } = await params;
  const name = decodeURIComponent(scope);
  return (
    <Suspense>
      <ScopePricingClient key={name} scope={name} />
    </Suspense>
  );
}
