import type { ReactNode } from "react";
import { ProductsShell } from "@/components/ProductsShell";

/** Every product down the left and the open one beside it; a layout so the column stays mounted. */
export default function ProductsLayout({ children }: { children: ReactNode }) {
  return <ProductsShell>{children}</ProductsShell>;
}
