import { ProductDetailClient } from "@/components/ProductDetailClient";

/** One product. Next 16: route params arrive as a promise. */
export default async function ProductPage({ params }: { params: Promise<{ name: string }> }) {
  const { name } = await params;
  return <ProductDetailClient key={name} name={decodeURIComponent(name)} />;
}
