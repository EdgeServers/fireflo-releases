import { RouteTableClient } from "@/components/RouteTableClient";

/** One routing table. Next 16: route params arrive as a promise. */
export default async function RouteTablePage({ params }: { params: Promise<{ name: string }> }) {
  const { name } = await params;
  return <RouteTableClient name={decodeURIComponent(name)} />;
}
