import { GroupsClient } from "@/components/GroupsClient";

/** Vendor groups: another name a rule's target can resolve to. */
export default function RoutingGroupsPage() {
  return <GroupsClient />;
}
