import { RoutingOverview } from "@/components/RoutingOverview";

/** Start here: the rules the gateway needs, and how a message travels through the tables. */
export default function RoutingPage() {
  return <RoutingOverview />;
}
