import { redirect } from "next/navigation";

/** The delivery check now shares a card with the tester; old links land there. */
export default function RoutingDeliveryPage() {
  redirect("/cp/routing/test");
}
