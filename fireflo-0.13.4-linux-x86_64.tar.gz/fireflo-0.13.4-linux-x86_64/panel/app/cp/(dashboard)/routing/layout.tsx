import type { ReactNode } from "react";
import { RoutingShell } from "@/components/RoutingShell";

/**
 * The routing tables down the left, and the open one beside them.
 *
 * <p>A layout rather than a page so the left column -- every table, and the tools that used to be
 * tabs -- stays mounted while an operator moves between tables, and the section loads its tables,
 * vendors, groups and filters once.
 */
export default function RoutingLayout({ children }: { children: ReactNode }) {
  return <RoutingShell>{children}</RoutingShell>;
}
