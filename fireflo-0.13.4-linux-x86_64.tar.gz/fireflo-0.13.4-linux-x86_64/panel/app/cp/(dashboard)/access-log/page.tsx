import { Suspense } from "react";
import { AccessLogClient } from "@/components/AccessLogClient";

export const metadata = { title: "Access log" };

/** A report, so any operator may open it; the operator-door tab says for itself who may read it. */
export default function AccessLogPage() {
  return (
    <Suspense>
      <AccessLogClient />
    </Suspense>
  );
}
