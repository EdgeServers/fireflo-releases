import { PageHeader } from "@/components/ui/page-header";
import { WhitelistIndexClient } from "@/components/WhitelistIndexClient";

export default function HeadersPage() {
  return (
    <>
      <PageHeader title="Headers" />
      <WhitelistIndexClient kind="headers" />
    </>
  );
}
