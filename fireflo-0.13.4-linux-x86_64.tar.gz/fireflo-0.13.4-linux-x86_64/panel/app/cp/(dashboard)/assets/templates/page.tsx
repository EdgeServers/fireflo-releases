import { PageHeader } from "@/components/ui/page-header";
import { WhitelistIndexClient } from "@/components/WhitelistIndexClient";

export default function TemplatesPage() {
  return (
    <>
      <PageHeader title="Templates" />
      <WhitelistIndexClient kind="templates" />
    </>
  );
}
