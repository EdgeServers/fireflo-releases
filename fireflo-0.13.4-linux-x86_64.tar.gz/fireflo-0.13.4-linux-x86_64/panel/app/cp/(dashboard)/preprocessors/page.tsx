import { PageHeader } from "@/components/ui/page-header";
import { PreprocessorsClient } from "@/components/PreprocessorsClient";

export const metadata = { title: "Preprocessors" };

export default function PreprocessorsPage() {
  return (
    <>
      <PageHeader
        title="Preprocessors"
        description="Your own programs that a routing rule hands matching messages to. Each answers carry on, change fields, route, refuse, drop or hold."
      />
      <PreprocessorsClient />
    </>
  );
}
