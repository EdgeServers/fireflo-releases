import { PreprocessorWorkbench } from "@/components/PreprocessorWorkbench";

export const metadata = { title: "New preprocessor" };

export default function NewPreprocessorPage() {
  return <PreprocessorWorkbench name={null} />;
}
