import { PreprocessorWorkbench } from "@/components/PreprocessorWorkbench";

export default async function PreprocessorPage({ params }: { params: Promise<{ name: string }> }) {
  const { name } = await params;
  return <PreprocessorWorkbench name={decodeURIComponent(name)} />;
}
