import { HealthClient } from "@/components/HealthClient";

export default function HealthPage() {
  return <HealthClient />;
}
