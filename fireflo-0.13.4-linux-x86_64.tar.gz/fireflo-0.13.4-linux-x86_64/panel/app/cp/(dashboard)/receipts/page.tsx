import { ReceiptQualityClient } from "@/components/ReceiptQuality";

export default function ReceiptsPage() {
  return <ReceiptQualityClient />;
}
