import { ServerDetailClient } from "@/components/ServerDetailClient";

export default async function ServerPage({ params }: { params: Promise<{ name: string }> }) {
  const { name } = await params;
  return <ServerDetailClient name={decodeURIComponent(name)} />;
}
