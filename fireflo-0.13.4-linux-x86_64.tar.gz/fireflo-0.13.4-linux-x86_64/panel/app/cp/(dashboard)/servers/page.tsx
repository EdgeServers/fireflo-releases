import { ServersClient } from "@/components/ServersClient";

export default function ServersPage() {
  return <ServersClient />;
}
