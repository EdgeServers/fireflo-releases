import { Suspense } from "react";
import { CdrsClient } from "@/components/CdrsClient";

export default function CdrsPage() {
  return <Suspense><CdrsClient /></Suspense>;
}
