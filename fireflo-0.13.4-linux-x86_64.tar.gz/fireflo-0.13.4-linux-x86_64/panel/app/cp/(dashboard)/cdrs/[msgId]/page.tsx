import { CdrDetailClient } from "@/components/CdrDetailClient";

export default async function CdrDetailPage({
  params,
}: {
  params: Promise<{ msgId: string }>;
}) {
  const { msgId } = await params;
  return <CdrDetailClient gatewayMsgId={decodeURIComponent(msgId)} />;
}
