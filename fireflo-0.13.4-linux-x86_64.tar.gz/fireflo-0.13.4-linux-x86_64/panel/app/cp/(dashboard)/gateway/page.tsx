import { GatewaySettingsClient } from "@/components/GatewaySettingsClient";

export default function GatewaySettingsPage() {
  return <GatewaySettingsClient />;
}
