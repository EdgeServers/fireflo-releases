import { UsageClient } from "@/components/UsageClient";
import { platformCurrency } from "@/lib/platform-currency";

/**
 * Traffic and delivery across every account, with a way into any one of them.
 *
 * <p>The currency is resolved on the server, as it is on the statement: FireFlo has exactly one and
 * never converts, so asking the client for it would be a second place to disagree with
 * `smsg.rates.currency`.
 */
export default async function UsagePage() {
  const currency = await platformCurrency();
  return <UsageClient currency={currency ?? ""} />;
}
