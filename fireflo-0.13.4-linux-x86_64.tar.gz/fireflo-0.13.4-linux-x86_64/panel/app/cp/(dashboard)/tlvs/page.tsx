import { TlvReferenceClient } from "@/components/TlvReferenceClient";

export default function TlvsPage() {
  return <TlvReferenceClient />;
}
