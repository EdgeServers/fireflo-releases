import { PageHeader } from "@/components/ui/page-header";
import { FiltersClient } from "@/components/FiltersClient";
import { TesterButton } from "@/components/TesterModal";
import { ApplyNowButton } from "@/components/ApplyNowButton";

export default function FiltersPage() {
  return (
    <>
      <PageHeader
        title="Filters"
        description="Named conditions that routing and pricing rules reuse instead of repeating."
        actions={<><TesterButton tab="filters" /><ApplyNowButton /></>}
      />
      <FiltersClient />
    </>
  );
}
