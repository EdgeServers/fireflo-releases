import { PageHeader } from "@/components/ui/page-header";
import { AccountsCatalogueClient } from "@/components/AccountsCatalogueClient";

/**
 * The list of customers, and only that.
 *
 * <p>This page used to carry three sections: the catalogue, <em>every</em> login in the deployment,
 * and traffic grouped by account, system id and product. The two extra ones drowned it — the screen
 * you reach by asking "who are our customers" answered with a hundred logins belonging to all of
 * them, and the answer to any question about one account was somewhere in the middle of the answers
 * about the others.
 *
 * <p>Both moved to {@code /accounts/[id]}, where they are already scoped to the account you asked
 * about. Nothing was lost: the login editor is the same component with a filter and a pre-filled
 * account, and traffic is a line on the credit card plus the link to the messages it came from.
 *
 * <p>Which leaves the catalogue as the index it always should have been — searchable, paged, and
 * covering both named accounts and the ids in use that nobody has named yet.
 */
export default function AccountsPage() {
  return (
    <>
      <PageHeader title="Accounts" />
      <AccountsCatalogueClient />
    </>
  );
}
