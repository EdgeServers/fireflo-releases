import { AccountLoginsClient } from "@/components/AccountLoginsClient";

export default async function AccountLoginsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <AccountLoginsClient id={decodeURIComponent(id)} />;
}
