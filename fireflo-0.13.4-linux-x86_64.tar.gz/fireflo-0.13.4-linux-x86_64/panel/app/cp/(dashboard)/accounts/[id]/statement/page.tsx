import { StatementClient } from "@/components/StatementClient";
import { platformCurrency } from "@/lib/platform-currency";

/**
 * What one account owes for a period, and the button that closes it.
 *
 * <p>Its own page rather than a card on the account page: it carries a period picker, a table, a
 * file queue and an irreversible action, and none of those belong beside a credential form.
 *
 * <p>The currency is resolved here on the server. FireFlo has exactly one and never converts, so
 * asking the client for it would be a second place to disagree with `smsg.rates.currency`.
 */
export default async function AccountStatementPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const currency = await platformCurrency();
  return <StatementClient id={decodeURIComponent(id)} currency={currency ?? ""} />;
}
