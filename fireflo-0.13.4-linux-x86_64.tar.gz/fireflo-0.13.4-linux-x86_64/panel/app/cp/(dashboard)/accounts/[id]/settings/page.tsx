import { AccountSettingsClient } from "@/components/AccountSettingsClient";

export default async function AccountSettingsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <AccountSettingsClient id={decodeURIComponent(id)} />;
}
