import { AccountOverviewClient } from "@/components/AccountOverviewClient";

/** Next 16: route params arrive as a promise. */
export default async function AccountPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <AccountOverviewClient id={decodeURIComponent(id)} />;
}
