import { AccountWhitelistSection } from "@/components/AccountWhitelist";
import { GatewayIgnores } from "@/components/GatewayIgnores";

/**
 * Sender IDs and message content this account may send.
 *
 * <p>`AccountWhitelistSection` renders two Cards from one call — approved headers and approved
 * templates. They are a pair and were always meant to be read together.
 */
export default async function AccountApprovalsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return (
    <div className="space-y-4">
      {/* whether the gateway enforces approvals at all. Here, beside the approvals it is about,
          rather than above every account tab, where it read as a fact about the account */}
      <GatewayIgnores domain="whitelist" />
      <AccountWhitelistSection accountId={decodeURIComponent(id)} />
    </div>
  );
}
