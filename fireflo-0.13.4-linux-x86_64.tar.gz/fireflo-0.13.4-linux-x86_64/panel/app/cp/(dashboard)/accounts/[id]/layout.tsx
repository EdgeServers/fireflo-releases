import { AccountShell } from "@/components/AccountShell";

/**
 * The frame shared by every account tab.
 *
 * <p>A layout rather than a component each page renders, so the header and the tab bar survive a
 * navigation between tabs — React keeps the subtree mounted, which is why moving between tabs does
 * not re-request the catalogue and the balance every time.
 */
export default async function AccountLayout({
  params,
  children,
}: {
  params: Promise<{ id: string }>;
  children: React.ReactNode;
}) {
  const { id } = await params;
  return <AccountShell id={decodeURIComponent(id)}>{children}</AccountShell>;
}
