import { AccountTariffClient } from "@/components/AccountTariffClient";

export default async function AccountTariffPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  //no heading: the tab bar above already says which tab this is
  return <AccountTariffClient id={decodeURIComponent(id)} />;
}
