import { AccountBillingClient } from "@/components/AccountBillingClient";

export default async function AccountBillingPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <AccountBillingClient id={decodeURIComponent(id)} />;
}
