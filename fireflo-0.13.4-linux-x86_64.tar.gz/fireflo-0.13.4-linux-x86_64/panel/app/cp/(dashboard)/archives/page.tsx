import { ArchivesClient } from "@/components/ArchivesClient";

export const metadata = { title: "Archives" };

export default function ArchivesPage() {
  return <ArchivesClient />;
}
