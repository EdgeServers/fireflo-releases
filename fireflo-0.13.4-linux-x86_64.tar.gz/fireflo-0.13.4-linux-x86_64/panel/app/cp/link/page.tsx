import { Suspense } from "react";
import { CpLinkVerify } from "@/components/CpLinkVerify";

export const metadata = { title: "Sign in" };

/** Where an operator's emailed one-time link lands. `useSearchParams` needs the boundary. */
export default function LinkPage() {
  return (
    <Suspense>
      <CpLinkVerify />
    </Suspense>
  );
}
