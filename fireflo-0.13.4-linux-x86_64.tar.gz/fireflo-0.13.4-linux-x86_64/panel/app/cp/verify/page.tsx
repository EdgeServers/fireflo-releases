import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { isAdminSession, isOperatorSession } from "@/lib/roles";
import { LicenseVerify } from "@/components/LicenseVerify";

export const metadata = { title: "Licence" };

/**
 * Where an operator activates this gateway.
 *
 * <p><strong>Outside `(dashboard)` on purpose</strong>, exactly as `/cp/login` is. The dashboard
 * layout is the licensing banner's home, and a page that lived under it would be wearing the very
 * warning it exists to clear — and would inherit any future gating applied there, which is a door
 * locked from the inside.
 *
 * <p>It still requires an operator session, and changing the licence an admin one: the POST route
 * answers an operator 404, and `canChange` lets the screen say so rather than offer a form that
 * will be refused. Activating changes whether the gateway adopts configuration, which is not
 * something an anonymous caller may do; the panel is simply not where that is enforced. The
 * gateway's own admin token is the real gate behind this screen.
 */
export default async function VerifyPage() {
  const session = await auth();
  if (!isOperatorSession(session)) {
    redirect("/cp/login");
  }

  return (
    <main className="mx-auto w-full max-w-3xl px-4 py-10 sm:px-6">
      <LicenseVerify canChange={isAdminSession(session)} />
    </main>
  );
}
