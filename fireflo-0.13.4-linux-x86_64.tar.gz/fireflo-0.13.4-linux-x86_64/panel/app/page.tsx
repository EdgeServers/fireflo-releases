import { MisSignIn } from "@/components/MisSignIn";
import { portalBrand, portalMark } from "@/lib/brand";

/**
 * The portal's front door. Public, and the only page in this application that is.
 *
 * <p>No nav, no branding beyond the wordmark, and nothing that hints at what is behind it. Somebody
 * who lands here without an account should learn nothing from the page itself.
 *
 * <p>The title carries the tenant's brand rather than the product's: this page is public, so the tab
 * is readable before anybody signs in, and on a white-labelled portal the platform's name is exactly
 * what should not be in it.
 */
export function generateMetadata() {
  return { title: `Sign in — ${portalBrand()}` };
}

export default function MisPanelPage() {
  return <MisSignIn brand={portalBrand()} mark={portalMark()} />;
}
