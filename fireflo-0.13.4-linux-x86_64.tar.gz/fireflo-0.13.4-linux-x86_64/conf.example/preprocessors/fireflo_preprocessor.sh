# FireFlo preprocessor helper for bash (4.2 or later).
#
# A preprocessor is a program the gateway keeps running and hands messages to. Put your script and
# this file in the preprocessor directory (/etc/fireflo/preprocessors on a packaged install), owned
# by root or the gateway's user and writable only by its owner, then source this file, write a
# handle function and call fireflo_run with it:
#
#     source "$(dirname "$0")/fireflo_preprocessor.sh"
#
#     handle() {
#         if [[ ${MSG[to]} == +9140* ]]; then
#             fireflo_reject DND "on the do-not-disturb list"
#         fi
#     }
#
#     fireflo_run handle
#
# handle sees the fields listed in the preprocessor's `fields` setting (to, from, systemId and
# product by default) in the associative array MSG, and answers by calling one of these. Calling
# none of them answers continue.
#
#     fireflo_continue                  route on, skipping this rule
#     fireflo_set from ACME [to X ...]  change fields (name value pairs), then route on
#     fireflo_route vendorB             send to this table or vendor
#     fireflo_reject DND [detail]       refuse, with a failure receipt
#     fireflo_drop                      discard (recorded, refunded)
#     fireflo_hold                      try again after the routing backoff
#
# Fields that may be set: from, to, product, field1 .. field10.
#
# Any answer may also attach or remove optional parameters (TLVs), keyed by tag:
#
#     fireflo_tlv 0x1400 TMID-77        attach, or replace, a TLV
#     fireflo_tlv_remove 0x1401         remove one
#
# Only vendor-specific tags, 0x1400 to 0x3FFF, and a vendor sends a tag only when its
# registered.tlvs.submit names it. Add "tlvs" to the preprocessor's fields to receive the TLVs the
# message already carries; ${MSG[tlvs]} is then their JSON object, as text.
#
# If handle returns non-zero, the gateway applies the preprocessor's on_error to that message.
# Anything handle prints goes to stderr and appears in the gateway log under preprocessor.<name>:
# stdout carries the protocol, so the helper keeps it for itself.
#
# Bash starts no process per message here -- the parsing is plain bash -- but it is still the
# slowest of the three languages. It suits short rules over a list or a prefix; give anything that
# calls out to other programs per message more workers, or write it in Python.

declare -gA MSG=()
_FF_ID=null
_FF_ANSWER=
_FF_TLVS=

fireflo_continue() { _FF_ANSWER='"action":"continue"'; }
fireflo_drop() { _FF_ANSWER='"action":"drop"'; }
fireflo_hold() { _FF_ANSWER='"action":"hold"'; }

fireflo_route() {
    _ff_quote "$1"
    _FF_ANSWER='"action":"route","target":'"$_FF_Q"
}

fireflo_reject() {
    _ff_quote "$1"
    _FF_ANSWER='"action":"reject","status":'"$_FF_Q"
    if [[ -n ${2-} ]]; then
        _ff_quote "$2"
        _FF_ANSWER+=',"detail":'"$_FF_Q"
    fi
}

fireflo_set() {
    local pairs= k
    while (( $# >= 2 )); do
        _ff_quote "$1"
        k=$_FF_Q
        _ff_quote "$2"
        pairs+="${pairs:+,}$k:$_FF_Q"
        shift 2
    done
    _FF_ANSWER='"action":"set","set":{'"$pairs"'}'
}

fireflo_tlv() {
    local k
    _ff_quote "$1"
    k=$_FF_Q
    _ff_quote "$2"
    _FF_TLVS+="${_FF_TLVS:+,}$k:$_FF_Q"
}

fireflo_tlv_remove() {
    _ff_quote "$1"
    _FF_TLVS+="${_FF_TLVS:+,}$_FF_Q:null"
}

# Reads requests from the gateway until it closes stdin, answering each with the named function.
fireflo_run() {
    local handler=$1 line
    printf '{"ready":true}\n'
    while IFS= read -r line || [[ -n $line ]]; do
        [[ -z ${line//[[:space:]]/} ]] && continue
        _FF_ANSWER='"action":"continue"'
        _FF_TLVS=
        if ! _ff_parse "$line"; then
            printf 'ignored a line that is not a JSON object: %.200s\n' "$line" >&2
            continue
        fi
        # the handler runs in this shell, so it can answer; its output goes to stderr
        if ! "$handler" >&2; then
            printf 'preprocessor error for id %s: %s returned non-zero\n' "$_FF_ID" "$handler" >&2
            _FF_ANSWER='"action":"error","detail":"handler failed"'
            _FF_TLVS=
        fi
        if [[ -n $_FF_TLVS ]]; then
            printf '{"id":%s,%s,"tlvs":{%s}}\n' "$_FF_ID" "$_FF_ANSWER" "$_FF_TLVS"
        else
            printf '{"id":%s,%s}\n' "$_FF_ID" "$_FF_ANSWER"
        fi
    done
}

# --- the rest is the helper's own; nothing below is for a handler to call ----------------------

# The JSON string literal for $1, into _FF_Q. A variable, not output: $(...) would fork per call.
_ff_quote() {
    local s=$1
    s=${s//\\/\\\\}
    s=${s//\"/\\\"}
    s=${s//$'\n'/\\n}
    s=${s//$'\r'/\\r}
    s=${s//$'\t'/\\t}
    _FF_Q="\"$s\""
}

# Reads the JSON string starting at index $2 of $1 (its opening quote) into _FF_S, leaving _FF_I
# just past the closing quote.
_ff_string() {
    local s=$1 i=$(( $2 + 1 )) n=${#1} c out= hex ch
    while (( i < n )); do
        c=${s:i:1}
        if [[ $c == '"' ]]; then
            _FF_S=$out
            _FF_I=$(( i + 1 ))
            return 0
        fi
        if [[ $c == '\' ]]; then
            (( i++ ))
            c=${s:i:1}
            case $c in
                n) out+=$'\n' ;;
                t) out+=$'\t' ;;
                r) out+=$'\r' ;;
                b) out+=$'\b' ;;
                f) out+=$'\f' ;;
                u)
                    hex=${s:i+1:4}
                    printf -v ch "\\u$hex"
                    out+=$ch
                    (( i += 4 ))
                    ;;
                *) out+=$c ;;
            esac
        else
            out+=$c
        fi
        (( i++ ))
    done
    return 1
}

# Index just past the object or array that starts at index $2 of $1, into _FF_I.
_ff_skip_nested() {
    local s=$1 i=$2 n=${#1} depth=0 c
    while (( i < n )); do
        c=${s:i:1}
        case $c in
            '"') _ff_string "$s" "$i" || return 1; i=$_FF_I; continue ;;
            '{' | '[') (( depth++ )) ;;
            '}' | ']')
                (( depth-- ))
                if (( depth == 0 )); then
                    _FF_I=$(( i + 1 ))
                    return 0
                fi
                ;;
        esac
        (( i++ ))
    done
    return 1
}

# Fills MSG and _FF_ID from one request line: a flat object of strings and numbers, plus "tlvs",
# which is kept as its JSON text.
#
# The usual request -- string and number values with no escapes -- is read with bash's own regex,
# a few matches per field. Anything else (an escape, a nested object) falls back to reading it a
# character at a time, which is correct for all of it and about three times slower.
_ff_parse() {
    local s=$1 str='^[[:space:],]*"([^"\\]*)"[[:space:]]*:[[:space:]]*"([^"\\]*)"(.*)$'
    local lit='^[[:space:],]*"([^"\\]*)"[[:space:]]*:[[:space:]]*(-?[0-9][0-9.eE+-]*|true|false|null)(.*)$'
    [[ $s =~ ^[[:space:]]*\{(.*)\}[[:space:]]*$ ]] || return 1
    s=${BASH_REMATCH[1]}
    MSG=()
    _FF_ID=null
    while [[ ! $s =~ ^[[:space:],]*$ ]]; do
        if [[ $s =~ $str ]]; then
            if [[ ${BASH_REMATCH[1]} == id ]]; then
                _FF_ID="\"${BASH_REMATCH[2]}\""
            else
                MSG[${BASH_REMATCH[1]}]=${BASH_REMATCH[2]}
            fi
        elif [[ $s =~ $lit ]]; then
            if [[ ${BASH_REMATCH[1]} == id ]]; then
                _FF_ID=${BASH_REMATCH[2]}
            else
                MSG[${BASH_REMATCH[1]}]=${BASH_REMATCH[2]}
            fi
        else
            _ff_parse_slowly "$1"
            return
        fi
        s=${BASH_REMATCH[3]}
    done
    return 0
}

_ff_parse_slowly() {
    local s=$1 i=0 n=${#1} c key start
    MSG=()
    _FF_ID=null
    while (( i < n )) && [[ ${s:i:1} != '{' ]]; do (( i++ )); done
    (( i < n )) || return 1
    (( i++ ))
    while (( i < n )); do
        c=${s:i:1}
        if [[ $c == '}' ]]; then
            return 0
        fi
        if [[ $c != '"' ]]; then
            (( i++ ))
            continue
        fi
        _ff_string "$s" "$i" || return 1
        key=$_FF_S
        i=$_FF_I
        while (( i < n )) && [[ ${s:i:1} != ':' ]]; do (( i++ )); done
        (( i++ ))
        while (( i < n )) && [[ ${s:i:1} == [[:space:]] ]]; do (( i++ )); done
        start=$i
        c=${s:i:1}
        if [[ $c == '"' ]]; then
            _ff_string "$s" "$i" || return 1
            i=$_FF_I
            [[ $key == id ]] && _FF_ID=${s:start:i-start} || MSG[$key]=$_FF_S
        elif [[ $c == '{' || $c == '[' ]]; then
            _ff_skip_nested "$s" "$i" || return 1
            i=$_FF_I
            MSG[$key]=${s:start:i-start}
        else
            while (( i < n )) && [[ ${s:i:1} != [,}] ]]; do (( i++ )); done
            local raw=${s:start:i-start}
            raw=${raw%"${raw##*[![:space:]]}"}
            [[ $key == id ]] && _FF_ID=$raw || MSG[$key]=$raw
        fi
    done
    return 1
}
