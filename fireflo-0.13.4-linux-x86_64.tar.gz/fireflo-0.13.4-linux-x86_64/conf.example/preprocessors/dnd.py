"""Sample preprocessor: refuse messages to numbers on a do-not-disturb list.

dnd.txt (beside this file) holds one number per line, '#' starts a comment. It is re-read when it
changes, so the list can be updated by a cron job without restarting anything.

Wire it up in routingTable.conf (file mode):

    [preprocessor:dnd]
    run      = dnd.py
    workers  = 2
    timeout  = 100ms
    on_error = continue

    [default]
    @dnd:to:startsWith:+91
    ...the rest of the table...

or, in database mode, add a preprocessor named dnd running dnd.py in the panel and a routing rule
"Preprocessor dnd, then continue" with the filter that selects the traffic it should see.
"""
import os

from fireflo_preprocessor import CONTINUE, run

LIST = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dnd.txt")
_numbers = set()
_stamp = None


def _load():
    global _numbers, _stamp
    try:
        stamp = os.stat(LIST).st_mtime_ns
    except FileNotFoundError:
        _numbers, _stamp = set(), None
        return
    if stamp != _stamp:
        with open(LIST, encoding="utf-8") as f:
            _numbers = {ln.split("#", 1)[0].strip() for ln in f} - {""}
        _stamp = stamp


def handle(msg):
    _load()
    if msg.get("to") in _numbers:
        return {"action": "reject", "status": "DND", "detail": "on the do-not-disturb list"}
    return CONTINUE


run(handle)
