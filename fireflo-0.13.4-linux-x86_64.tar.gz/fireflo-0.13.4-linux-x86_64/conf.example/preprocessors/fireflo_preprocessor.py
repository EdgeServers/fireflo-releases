"""FireFlo preprocessor helper for Python.

A preprocessor is a program the gateway keeps running and hands messages to. Put your script and
this file in the preprocessor directory (/etc/fireflo/preprocessors on a packaged install), owned
by root or the gateway's user and writable only by its owner, then call run() with a function:

    from fireflo_preprocessor import run, CONTINUE

    def handle(msg):
        if msg.get("to", "").startswith("+9140"):
            return {"action": "reject", "status": "DND"}
        return CONTINUE

    run(handle)

handle() receives the fields listed in the preprocessor's `fields` setting (to, from, systemId and
product by default) and returns one of:

    {"action": "continue"}                              route on, skipping this rule
    {"action": "set", "set": {"from": "ACME"}}          change fields, then route on
    {"action": "route", "target": "vendorB"}            send to this table or vendor
    {"action": "reject", "status": "DND"}               refuse, with a failure receipt
    {"action": "drop"}                                  discard (recorded, refunded)
    {"action": "hold"}                                  try again after the routing backoff

Fields that may be set: from, to, product, field1 .. field10.

Any answer may also attach optional parameters (TLVs) to the message, keyed by tag:

    {"action": "continue", "tlvs": {"0x1400": "TMID-77"}}     attach, or replace, a TLV
    {"action": "continue", "tlvs": {"0x1401": None}}          remove one

Only vendor-specific tags, 0x1400 to 0x3FFF, and a vendor sends a tag only when its
registered.tlvs.submit names it. Add "tlvs" to the preprocessor's fields to receive the TLVs the
message already carries, as msg["tlvs"], keyed the same way.

If handle() raises, the gateway applies the preprocessor's on_error to that message. Anything you
print to stderr appears in the gateway log under preprocessor.<name>; never print to stdout, which
carries the protocol.

run(handle, threads=8) answers up to eight messages at once, for a handler that waits on I/O (a
database or an HTTP lookup). Answers may go back in any order; the gateway matches them by id.
"""
import json
import sys
import threading
from concurrent.futures import ThreadPoolExecutor

CONTINUE = {"action": "continue"}

_out_lock = threading.Lock()


def _send(obj):
    line = json.dumps(obj, separators=(",", ":"), ensure_ascii=False)
    with _out_lock:
        sys.stdout.write(line + "\n")
        sys.stdout.flush()


def _answer(handler, request):
    rid = request.pop("id", None)
    try:
        result = handler(request) or CONTINUE
        if not isinstance(result, dict):
            raise TypeError("handle() must return a dict, got %r" % (result,))
        result = dict(result)
    except Exception as e:  # the gateway applies on_error; say why on stderr
        print("preprocessor error for id %s: %r" % (rid, e), file=sys.stderr, flush=True)
        result = {"action": "error", "detail": str(e)[:200]}
    result["id"] = rid
    _send(result)


def run(handler, threads=1):
    """Read requests from the gateway until it closes stdin, answering each with handler()."""
    pool = ThreadPoolExecutor(max_workers=threads) if threads > 1 else None
    _send({"ready": True})
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
        except ValueError:
            print("ignored a line that is not JSON: %s" % line[:200], file=sys.stderr, flush=True)
            continue
        if pool:
            pool.submit(_answer, handler, request)
        else:
            _answer(handler, request)
    if pool:
        pool.shutdown(wait=True)
