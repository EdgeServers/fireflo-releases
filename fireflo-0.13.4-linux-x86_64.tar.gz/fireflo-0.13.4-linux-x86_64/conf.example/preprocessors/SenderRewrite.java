import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Sample FireFlo preprocessor in Java: one self-contained file, run with `java SenderRewrite.java`
 * (JDK 11 or later; nothing to compile). Copy it, rename the class and the file, and change handle().
 *
 * This one rewrites an unregistered alphanumeric sender to a registered one, and leaves everything
 * else alone:
 *
 *     [preprocessor:sender]
 *     run    = SenderRewrite.java
 *     fields = from,systemId
 *     timeout = 50ms
 *
 *     [default]
 *     @sender:from:matches:^[A-Za-z]{1,11}$
 *
 * Protocol: print {"ready":true} once, then for every request line read from stdin print one answer
 * line carrying the same "id". Answers: continue, set (with "set":{...}), route (with "target"),
 * reject (with "status"), drop, hold. Print diagnostics to stderr, never to stdout.
 */
public class SenderRewrite {

    static String handle(Map<String, String> msg) {
        String from = msg.getOrDefault("from", "");
        if (from.equalsIgnoreCase("acme")) {
            return "{\"action\":\"set\",\"set\":{\"from\":\"ACME-LTD\"}}";
        }
        return "{\"action\":\"continue\"}";
    }

    public static void main(String[] args) throws Exception {
        System.out.println("{\"ready\":true}");
        System.out.flush();
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        String line;
        while ((line = in.readLine()) != null) {
            if (line.isBlank()) {
                continue;
            }
            Map<String, String> msg = parse(line);
            String id = msg.remove("id");
            String answer;
            try {
                answer = handle(msg);
            } catch (RuntimeException e) {
                System.err.println("error for id " + id + ": " + e);
                answer = "{\"action\":\"error\"}";
            }
            //splice the id into the answer object
            System.out.println("{\"id\":" + quote(id) + "," + answer.substring(answer.indexOf('{') + 1));
            System.out.flush();
        }
    }

    /** Reads the flat request object: string and number values only, which is all the gateway sends. */
    static Map<String, String> parse(String json) {
        Map<String, String> out = new LinkedHashMap<>();
        int i = json.indexOf('{') + 1;
        while (i < json.length()) {
            i = skip(json, i);
            if (i >= json.length() || json.charAt(i) == '}') {
                break;
            }
            StringBuilder key = new StringBuilder();
            i = readString(json, i, key);
            i = skip(json, i) + 1; // ':'
            i = skip(json, i);
            StringBuilder value = new StringBuilder();
            if (json.charAt(i) == '"') {
                i = readString(json, i, value);
            } else {
                while (i < json.length() && ",}".indexOf(json.charAt(i)) < 0) {
                    value.append(json.charAt(i++));
                }
            }
            out.put(key.toString(), value.toString().trim());
            i = skip(json, i);
            if (i < json.length() && json.charAt(i) == ',') {
                i++;
            }
        }
        return out;
    }

    private static int readString(String s, int i, StringBuilder into) {
        i++; // opening quote
        while (i < s.length() && s.charAt(i) != '"') {
            char c = s.charAt(i++);
            if (c == '\\' && i < s.length()) {
                char e = s.charAt(i++);
                switch (e) {
                    case 'n' -> into.append('\n');
                    case 't' -> into.append('\t');
                    case 'u' -> {
                        into.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                        i += 4;
                    }
                    default -> into.append(e);
                }
            } else {
                into.append(c);
            }
        }
        return i + 1;
    }

    private static int skip(String s, int i) {
        while (i < s.length() && Character.isWhitespace(s.charAt(i))) {
            i++;
        }
        return i;
    }

    private static String quote(String s) {
        return s == null ? "null" : "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }
}
