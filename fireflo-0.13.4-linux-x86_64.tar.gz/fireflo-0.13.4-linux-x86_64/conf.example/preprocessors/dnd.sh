# Sample preprocessor in bash: refuse messages to numbers on a do-not-disturb list.
#
# dnd.txt (beside this file) holds one number per line, '#' starts a comment. It is re-read when it
# changes, so the list can be updated by a cron job without restarting anything.
#
# Wire it up in routingTable.conf (file mode):
#
#     [preprocessor:dnd]
#     run      = dnd.sh
#     workers  = 2
#     timeout  = 100ms
#     on_error = continue
#
#     [default]
#     @dnd:to:startsWith:+91
#     ...the rest of the table...
#
# or, in database mode, add a preprocessor named dnd running dnd.sh in the panel and a routing rule
# "Preprocessor dnd, then continue" with the filter that selects the traffic it should see.

here=$(cd "$(dirname "$0")" && pwd)
source "$here/fireflo_preprocessor.sh"

LIST="$here/dnd.txt"
declare -A numbers=()
stamp=
checked=-1

load() {
    local now line
    # at most once a second: stat is a process, and starting one per message would be most of the cost
    (( SECONDS == checked )) && return
    checked=$SECONDS
    now=$(stat -c %Y "$LIST" 2>/dev/null) || { numbers=(); stamp=; return; }
    [[ $now == "$stamp" ]] && return
    numbers=()
    while IFS= read -r line || [[ -n $line ]]; do
        line=${line%%#*}
        line=${line//[[:space:]]/}
        [[ -n $line ]] && numbers[$line]=1
    done < "$LIST"
    stamp=$now
}

handle() {
    load
    local to=${MSG[to]-}
    if [[ -n $to && -n ${numbers[$to]-} ]]; then
        fireflo_reject DND "on the do-not-disturb list"
    fi
}

fireflo_run handle
