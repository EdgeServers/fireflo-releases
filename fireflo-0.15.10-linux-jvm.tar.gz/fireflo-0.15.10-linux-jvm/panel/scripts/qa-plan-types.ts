/**
 * The change list that carries the QA workbook from one release to the next — see
 * scripts/qa-plan-0.12/README.md (0.11 → 0.12) and scripts/qa-plan-0.15/README.md (0.12 → 0.15).
 *
 * Only erasable TypeScript syntax: this runs under `node --experimental-strip-types`.
 */

export type Changed = "New" | "Updated";

export interface StoryRow {
  id: string;
  epic: string;
  story: string;
  asA: string;
  iWant: string;
  soThat: string;
  acceptance: string;
  configKeys: string;
  observable: string;
  /** The JUnit / node:test class that covers the rule today, or "—". */
  automated: string;
  changed: Changed;
}

export interface ScenarioRow {
  id: string;
  story: string;
  epic: string;
  scenario: string;
  gwt: string;
  preconditions: string;
  rig: string;
  related: string;
  dependsOn: string;
  changed: Changed;
}

/** "OMNI Panel" and "OMNI API" are FireFlo OMNI's surfaces, for the change files OMNI contributes (0.15). */
export type Surface = "SMPP" | "HTTP" | "Ops" | "CLI" | "Panel" | "Portal" | "API" | "Host" | "OMNI Panel" | "OMNI API";

/** "OMNI" is the platform's own component (fireflo-omni / fireflo-omni-js), from 0.15. */
export type Component = "Gateway" | "Control Panel" | "Cross-component" | "OMNI";

export interface CaseRow {
  id: string;
  scenario: string;
  story: string;
  epic: string;
  type: "Positive" | "Negative";
  title: string;
  steps: string;
  testData: string;
  expected: string;
  oracle: string;
  antiVacuity: string;
  priority: "P0" | "P1" | "P2";
  component: Component;
  automated: string;
  related: string;
  surface: Surface;
  changed: Changed;
  /** The release and the sentence of the release note the case comes from, e.g. "0.12.14: …". */
  changeNote: string;
}

/** Any field of a 0.11 row by its key; `id` says which row. */
export interface Update {
  id: string;
  changed: "Updated";
  changeNote: string;
  set: Partial<Omit<CaseRow, "id" | "changed" | "changeNote">> &
    Partial<Omit<ScenarioRow, "id" | "changed">> &
    Partial<Omit<StoryRow, "id" | "changed">>;
}

export interface Retire {
  id: string;
  reason: string;
}

export interface FocusRow {
  /** The release, e.g. "0.12.11". */
  item: string;
  change: string;
  scenarios: string;
  risk: string;
}

/**
 * One pattern replaced in every plan column of every Stories / Scenarios / TestCases row (0.15): for a
 * change that touches many rows the same way, such as /ops/<route> becoming a GraphQL field. Each
 * row it changes is marked Updated with `changeNote`.
 */
export interface Rewrite {
  /** a RegExp source */
  pattern: string;
  /** RegExp flags, "g" by default */
  flags?: string;
  /** the replacement, `$1` etc. allowed */
  replace: string;
  changeNote: string;
}

export interface Change {
  epic: string;
  /** a new epic only (0.15): its name, component and description on the Epics sheet */
  epicName?: string;
  /** OMNI's spelling of `epicName` (fireflo-omni-js/e2e/qa-plan/types.ts); either is read */
  epicTitle?: string;
  epicComponent?: Component;
  epicDescription?: string;
  stories?: StoryRow[];
  scenarios?: ScenarioRow[];
  cases?: CaseRow[];
  updates?: Update[];
  /** a TC (and from 0.15 a story or scenario) kept, greyed and marked Retired */
  retire?: Retire[];
  rewrites?: Rewrite[];
  focus?: FocusRow[];
}
