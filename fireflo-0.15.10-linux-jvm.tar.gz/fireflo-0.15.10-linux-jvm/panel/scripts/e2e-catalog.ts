/**
 * Generate e2e/support/tc-catalog.json from the QA workbook.
 *
 * The workbook (fireflo-sms-gateway/docs/26-qa-test-plan-0.15.xlsx) is the source of truth for
 * every test-case id, its title and its parentage. The suite refuses an id the catalog does not
 * know and the catalog check refuses a catalog id the suite does not declare, so the JSON is
 * committed and regenerated whenever the sheet changes. Two kinds of row are left out: a test case
 * marked Retired in any "Changed in …" column (it is history, not a test any more), and FireFlo
 * OMNI's rows (component "OMNI"; OMNI's own suite in fireflo-omni-js runs them):
 *
 *   npm run e2e:catalog                     # default workbook path
 *   E2E_QA_WORKBOOK=path/to.xlsx npm run e2e:catalog
 *
 * Runs under `node --experimental-strip-types`, so only erasable TypeScript syntax is used here.
 */
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import ExcelJS from "exceljs";
import type { Cell, Worksheet } from "exceljs";

const here = path.dirname(fileURLToPath(import.meta.url));
const workbookPath = path.resolve(
  process.env.E2E_QA_WORKBOOK ?? path.join(here, "..", "..", "fireflo-sms-gateway", "docs", "26-qa-test-plan-0.15.xlsx"),
);
const outPath = path.join(here, "..", "e2e", "support", "tc-catalog.json");

export interface CatalogTc {
  id: string;
  scenario: string;
  story: string;
  epic: string;
  type: "Positive" | "Negative";
  title: string;
  priority: string;
  component: string;
  newIn011: boolean;
  steps: string;
  testData: string;
  expected: string;
  oracle: string;
  antiVacuity: string;
  automatedCoverage: string;
  related: string;
}

export interface Catalog {
  generatedFrom: string;
  workbookSha256: string;
  generatedAt: string;
  epics: { id: string; name: string; component: string }[];
  stories: { id: string; epic: string; name: string }[];
  scenarios: { id: string; story: string; epic: string; name: string; rig: string }[];
  tcs: CatalogTc[];
}

/** A cell as plain text: rich text flattened, a formula replaced by its cached result, else "". */
function text(cell: Cell | undefined): string {
  if (!cell) return "";
  const v = cell.value as unknown;
  if (v == null) return "";
  if (typeof v === "string") return v.trim();
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  if (v instanceof Date) return v.toISOString();
  if (typeof v === "object") {
    const o = v as { richText?: { text: string }[]; result?: unknown; text?: string; formula?: string };
    if (Array.isArray(o.richText)) return o.richText.map((r) => r.text).join("").trim();
    if ("result" in o) return o.result == null ? "" : String(o.result).trim();
    if (typeof o.text === "string") return o.text.trim();
  }
  return String(v).trim();
}

const OMNI = "OMNI";

/** The 1-based columns whose header starts "Changed in" (0.12's, 0.15's, …). */
function changedColumns(ws: Worksheet): number[] {
  const out: number[] = [];
  ws.getRow(1).eachCell((cell, c) => {
    if (/^Changed in /.test(text(cell))) out.push(c);
  });
  return out;
}

function rows(ws: Worksheet, width: number): string[][] {
  const out: string[][] = [];
  ws.eachRow((row, n) => {
    if (n === 1) return;
    const cells: string[] = [];
    for (let c = 1; c <= width; c++) cells.push(text(row.getCell(c)));
    if (cells[0]) out.push(cells);
  });
  return out;
}

async function main() {
  const bytes = readFileSync(workbookPath);
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(bytes as unknown as ArrayBuffer);
  const sheet = (name: string) => {
    const ws = wb.getWorksheet(name);
    if (!ws) throw new Error(`workbook has no sheet '${name}'`);
    return ws;
  };

  // OMNI's epics (and so their stories, scenarios and cases) belong to OMNI's own suite
  const epics = rows(sheet("Epics"), 3).map(([id, name, component]) => ({ id, name, component })).filter((e) => e.component !== OMNI);
  const panelEpic = new Set(epics.map((e) => e.id));
  const retired = new Set<string>();
  for (const name of ["Stories", "Scenarios", "TestCases"]) {
    const ws = sheet(name);
    const cols = changedColumns(ws);
    ws.eachRow((row, n) => {
      if (n > 1 && cols.some((c) => text(row.getCell(c)) === "Retired")) retired.add(text(row.getCell(1)));
    });
  }
  const stories = rows(sheet("Stories"), 3).map(([id, epic, name]) => ({ id, epic, name })).filter((s) => panelEpic.has(s.epic) && !retired.has(s.id));
  const scenarios = rows(sheet("Scenarios"), 7).map(([id, story, epic, name, , , rig]) => ({ id, story, epic, name, rig })).filter((s) => panelEpic.has(s.epic) && !retired.has(s.id));
  const cases = sheet("TestCases");
  const tcs: CatalogTc[] = rows(cases, 16).filter((r) => !retired.has(r[0]) && r[12] !== OMNI && panelEpic.has(r[3])).map((r) => ({
    id: r[0],
    scenario: r[1],
    story: r[2],
    epic: r[3],
    type: r[4] as CatalogTc["type"],
    title: r[5],
    steps: r[6],
    testData: r[7],
    expected: r[8],
    oracle: r[9],
    antiVacuity: r[10],
    priority: r[11],
    component: r[12],
    newIn011: r[13].toUpperCase() === "Y",
    automatedCoverage: r[14],
    related: r[15],
  }));

  // the sheet's own cross-reference validation, repeated here so a broken workbook cannot become a
  // broken catalog silently
  const scenarioIds = new Set(scenarios.map((s) => s.id));
  const storyIds = new Set(stories.map((s) => s.id));
  const epicIds = new Set(epics.map((e) => e.id));
  const problems: string[] = [];
  const seen = new Set<string>();
  const idShape = /^TC-\d{2}\.\d{2}\.\d{2}-[PN]\d{2}$/;
  for (const tc of tcs) {
    if (!idShape.test(tc.id)) problems.push(`${tc.id}: id does not match TC-nn.ss.cc-Pxx/-Nxx`);
    if (seen.has(tc.id)) problems.push(`${tc.id}: duplicate id`);
    seen.add(tc.id);
    if (!scenarioIds.has(tc.scenario)) problems.push(`${tc.id}: unknown scenario ${tc.scenario}`);
    if (!storyIds.has(tc.story)) problems.push(`${tc.id}: unknown story ${tc.story}`);
    if (!epicIds.has(tc.epic)) problems.push(`${tc.id}: unknown epic ${tc.epic}`);
    if (tc.type !== "Positive" && tc.type !== "Negative") problems.push(`${tc.id}: type '${tc.type}'`);
    if (!tc.title) problems.push(`${tc.id}: empty title`);
    const expectedScenario = "SC-" + tc.id.slice(3, 11);
    if (tc.scenario !== expectedScenario) problems.push(`${tc.id}: scenario ${tc.scenario} does not match the id`);
  }
  if (problems.length) {
    console.error(problems.join("\n"));
    throw new Error(`${problems.length} problem(s) in the workbook; catalog not written`);
  }

  const catalog: Catalog = {
    generatedFrom: path.relative(path.join(here, ".."), workbookPath),
    workbookSha256: createHash("sha256").update(bytes).digest("hex"),
    generatedAt: new Date().toISOString(),
    epics,
    stories,
    scenarios,
    tcs,
  };
  writeFileSync(outPath, JSON.stringify(catalog, null, 1) + "\n");
  const byEpic = new Map<string, number>();
  for (const tc of tcs) byEpic.set(tc.epic, (byEpic.get(tc.epic) ?? 0) + 1);
  console.log(`${tcs.length} test cases, ${scenarios.length} scenarios, ${stories.length} stories, ${epics.length} epics (left out: ${retired.size} retired)`);
  console.log([...byEpic].map(([e, n]) => `${e}:${n}`).join(" "));
  console.log(`wrote ${path.relative(process.cwd(), outPath)} (workbook sha256 ${catalog.workbookSha256.slice(0, 12)}…)`);
}

main().catch((e) => {
  console.error(e instanceof Error ? e.message : e);
  process.exit(1);
});
