/**
 * Builds docs/26-qa-test-plan-0.12.xlsx from the 0.11 workbook plus the change files in
 * scripts/qa-plan-0.12/changes/, and fills the automation columns from the e2e suite.
 *
 * Usage: node --experimental-strip-types scripts/qa-plan-0.12.ts [--out path]
 *
 * The 0.11 workbook is read, never written. Every 0.11 id survives with its row; new rows are
 * inserted under their parent so the sheets stay in id order; retired rows are kept and marked.
 * See scripts/qa-plan-0.12/README.md for the change-file format and the writing rules.
 */
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import ExcelJS from "exceljs";
import type { Worksheet } from "exceljs";
import {
  EPIC, SCEN, STORY, TARGET_012, TC,
  addFocusSheet, addRigRows, applyEdits, applyNew, automationFromSuite, col, fail, fillAutomation, fillSheet, header,
  indexAll, lastRun, loadChanges, orderSheets, readmeSetter, rewriteCountFormulas, sheetsOf, text, validate,
} from "./qa-plan-lib.ts";

const here = path.dirname(fileURLToPath(import.meta.url));
const panelRoot = path.join(here, "..");
const gatewayDocs = path.join(panelRoot, "..", "fireflo-sms-gateway", "docs");
const SRC = process.env.QA_PLAN_SRC ?? path.join(gatewayDocs, "26-qa-test-plan-0.11.xlsx");
const argOut = process.argv.indexOf("--out");
const OUT = argOut > 0 ? path.resolve(process.argv[argOut + 1]) : path.join(gatewayDocs, "26-qa-test-plan-0.12.xlsx");
const CHANGES_DIR = path.join(here, "qa-plan-0.12", "changes");
const E2E_EPICS = path.join(panelRoot, "e2e", "epics");
const E2E_RESULTS = path.join(panelRoot, "e2e", ".run", "results.json");

const GATEWAY_VERSION = "0.12.14";
const PANEL_VERSION = "0.12.14.0";

// ---------------------------------------------------------------------------------------------
async function main() {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.readFile(SRC);
  const srcSha = createHash("sha256").update(readFileSync(SRC)).digest("hex");
  const sheets = sheetsOf(wb);
  const ix = indexAll(sheets);
  //QA_PLAN_ONLY=EP-09,EP-10 validates a subset while other change files are still being written
  const only = (process.env.QA_PLAN_ONLY ?? "").split(",").map((x) => x.trim()).filter(Boolean);
  const changes = await loadChanges(CHANGES_DIR, { only });
  validate(changes, ix, { base: "0.11" });

  // new columns
  header(sheets.stories, STORY.changed, "Changed in 0.12", 10);
  header(sheets.scenarios, SCEN.changed, "Changed in 0.12", 10);
  header(sheets.cases, TC.surface, "Surface", 8);
  header(sheets.cases, TC.changed, "Changed in 0.12", 10);
  header(sheets.cases, TC.changeNote, "Change note (release: why)", 40);
  header(sheets.cases, TC.automation, "Automation", 11);
  header(sheets.cases, TC.lastRun, "Last e2e run", 10);
  header(sheets.cases, TC.lastRunNote, "Last run note", 30);
  header(sheets.epics, EPIC.nChanged, "# Changed in 0.12", 9);
  header(sheets.epics, EPIC.nAuto, "# Automated", 9);
  header(sheets.epics, EPIC.nTodo, "# Todo", 7);
  header(sheets.epics, EPIC.nManual, "# Manual", 7);

  // apply, epic by epic: stories, then scenarios, then cases; each inserted under its parent; then
  // updates and retirements against the re-indexed sheets
  const added = applyNew(sheets, changes, ix, TARGET_012);
  applyEdits(sheets, changes, TARGET_012, added);
  const focus = added.focus;

  // automation and last run, every TC
  const auto = automationFromSuite(E2E_EPICS);
  const run = lastRun(E2E_RESULTS);
  const counts = fillAutomation(sheets, auto, run);

  rewriteCountFormulas(wb);
  for (const [ws, width] of [[sheets.epics, EPIC.nManual], [sheets.stories, STORY.changed], [sheets.scenarios, SCEN.changed], [sheets.cases, TC.lastRunNote]] as [Worksheet, number][]) {
    ws.autoFilter = { from: "A1", to: `${col(width)}${ws.rowCount}` };
  }

  // README
  const readme = wb.getWorksheet("README") ?? fail("no README");
  readme.getRow(1).getCell(1).value = `FireFlo ${GATEWAY_VERSION} — QA Test Plan`;
  const setReadme = readmeSetter(readme);
  setReadme("Scope", `FireFlo SMS Gateway ${GATEWAY_VERSION} (fireflo-sms-gateway) and FireFlo Control Panel ${PANEL_VERSION} (operator panel /cp and customer portal). Carried forward from the 0.11.0 plan: every 0.11 id is kept with its row; what 0.12 changed is marked, never renumbered.`);
  setReadme("New in 0.11", "History. Y marks behaviour that changed in 0.11.0; the '0.11 Focus' sheet is kept as the record of that release.");
  setReadme("Changed in 0.12", "On Stories, Scenarios and TestCases: New (added for 0.11.3 – 0.12.14), Updated (a 0.11 row whose steps or expected result changed with the behaviour; the Change note says which release and why), Retired (kept, greyed, Status N/A, reason in the note). Blank = unchanged since 0.11. See the '0.12 Focus' sheet for the release-by-release list.");
  setReadme("Automation", "Filled from the Playwright suite in fireflo-control-panel/e2e at build time: Automated (a real test() exists for the id), Todo (scaffolded, not written), Manual (needs a restart, a keystore or a real host), Fixme (written, known broken). Blank = the id is not in the suite yet (every new 0.12 id until phase 2 regenerates the catalog). 'Last e2e run' is the status from e2e/.run/results.json of the last run on the build machine, partial runs included.");
  setReadme("Surface", "What drives the case: SMPP (an ESME client), HTTP (/secure/*), Ops (/ops/*), CLI (fireflo … on the host), Panel / Portal (a browser), API (a panel /api/* route with no UI), Host (restart, keystore, real machine — stays manual).");
  setReadme("Source", `Built by fireflo-control-panel/scripts/qa-plan-0.12.ts from 26-qa-test-plan-0.11.xlsx (sha256 ${srcSha.slice(0, 12)}…) plus scripts/qa-plan-0.12/changes/EP-*.ts. Edit the change files and rebuild; do not hand-edit the plan columns.`);

  // Traceability: regenerate with whole-column formulas so added rows count
  const tr = wb.getWorksheet("Traceability") ?? fail("no Traceability");
  const f = (formula: string) => ({ formula });
  const trRows: (string | { formula: string })[][] = [
    ["Epics", f("COUNTA(Epics!A:A)-1"), "Epics sheet"],
    ["Stories", f("COUNTA(Stories!A:A)-1"), "Stories sheet"],
    ["Scenarios", f("COUNTA(Scenarios!A:A)-1"), "Scenarios sheet"],
    ["Test cases", f("COUNTA(TestCases!A:A)-1"), "TestCases sheet"],
    ["  Positive", f('COUNTIF(TestCases!E:E,"Positive")')],
    ["  Negative", f('COUNTIF(TestCases!E:E,"Negative")')],
    ["  P0", f('COUNTIF(TestCases!L:L,"P0")')],
    ["  P1", f('COUNTIF(TestCases!L:L,"P1")')],
    ["  P2", f('COUNTIF(TestCases!L:L,"P2")')],
    ["  New in 0.11 (history)", f('COUNTIF(TestCases!N:N,"Y")')],
    ["  New in 0.12", f(`COUNTIF(TestCases!${col(TC.changed)}:${col(TC.changed)},"New")`)],
    ["  Updated in 0.12", f(`COUNTIF(TestCases!${col(TC.changed)}:${col(TC.changed)},"Updated")`)],
    ["  Retired in 0.12", f(`COUNTIF(TestCases!${col(TC.changed)}:${col(TC.changed)},"Retired")`)],
    ["  Automated (e2e)", f(`COUNTIF(TestCases!${col(TC.automation)}:${col(TC.automation)},"Automated")`), "from the suite at build time"],
    ["  Todo (scaffolded)", f(`COUNTIF(TestCases!${col(TC.automation)}:${col(TC.automation)},"Todo")`)],
    ["  Manual", f(`COUNTIF(TestCases!${col(TC.automation)}:${col(TC.automation)},"Manual")`)],
    ["  Not in the suite yet", f(`COUNTA(TestCases!A:A)-1-COUNTA(TestCases!${col(TC.automation)}:${col(TC.automation)})+1`)],
    ["  TCs naming a specific unit test", f("COUNTA(TestCases!O:O)-1"), "non-blank 'Automated coverage'"],
    ["  With an anti-vacuity check", f("COUNTA(TestCases!K:K)-1")],
    ["  Gateway", f('COUNTIF(TestCases!M:M,"Gateway")')],
    ["  Control Panel", f('COUNTIF(TestCases!M:M,"Control Panel")')],
    ["  Cross-component", f('COUNTIF(TestCases!M:M,"Cross-component")')],
    ["Execution: Pass", f('COUNTIF(TestCases!Q:Q,"Pass")'), "fill Status on TestCases"],
    ["Execution: Fail", f('COUNTIF(TestCases!Q:Q,"Fail")')],
    ["Execution: Blocked", f('COUNTIF(TestCases!Q:Q,"Blocked")')],
    ["Execution: Not run", f('COUNTIF(TestCases!Q:Q,"Not run")')],
    ["Execution: % complete", f("IF(B5=0,0,(B24+B25)/B5)"), "pass+fail over total"],
    [""],
    ["Epic", "Name", "TCs", "P0", "Changed 0.12", "Automated", "Todo", "Manual", "Pass", "Fail"],
  ];
  const epicCount = sheets.epics.rowCount - 1;
  for (let i = 0; i < epicCount; i++) {
    const e = i + 2;
    const r = trRows.length + 2;
    trRows.push([f(`Epics!A${e}`), f(`Epics!B${e}`), f(`Epics!G${e}`), f(`Epics!J${e}`), f(`Epics!${col(EPIC.nChanged)}${e}`), f(`Epics!${col(EPIC.nAuto)}${e}`), f(`Epics!${col(EPIC.nTodo)}${e}`), f(`Epics!${col(EPIC.nManual)}${e}`), f(`COUNTIFS(TestCases!$D:$D,A${r},TestCases!$Q:$Q,"Pass")`), f(`COUNTIFS(TestCases!$D:$D,A${r},TestCases!$Q:$Q,"Fail")`)]);
  }
  fillSheet(tr, trRows);
  tr.getColumn(1).width = 34;
  for (let c = 4; c <= 10; c++) tr.getColumn(c).width = 10;

  // 0.12 Focus: a new sheet before 0.11 Focus
  const old = wb.getWorksheet("0.11 Focus") ?? fail("no 0.11 Focus");
  const fx = addFocusSheet(wb, "0.12 Focus", old, focus);
  old.name = "0.11 Focus (history)";

  // Coverage: the phase-2 backlog view
  const cov = wb.addWorksheet("Coverage", { views: [{ state: "frozen", ySplit: 1 }] });
  wb.worksheets.splice(wb.worksheets.indexOf(cov), 1);
  wb.worksheets.splice(wb.worksheets.indexOf(fx), 0, cov);
  const covHead = ["Epic", "Name", "Component", "TCs", "Automated", "Todo", "Manual", "Not in suite", "New in 0.12", "Updated in 0.12", "Automated %", "Phase-2 order", "Phase-2 note"];
  covHead.forEach((h, i) => {
    cov.getRow(1).getCell(i + 1).value = h;
    cov.getRow(1).getCell(i + 1).style = { ...old.getRow(1).getCell(1).style };
  });
  cov.getRow(1).height = 31.5;
  [9, 44, 15, 7, 10, 7, 8, 10, 10, 11, 11, 11, 60].forEach((w, i) => (cov.getColumn(i + 1).width = w));
  const phase2: Record<string, [number, string]> = {
    "EP-09": [1, "Rating incl. the new product story: the rig already has balance, SMPP clients and two priced vendors"],
    "EP-06": [2, "REST send: request-level, fast to write, high value"],
    "EP-19": [3, "Tester (US-19.07) and Apply now (US-19.08) first, then workers and routing editor"],
    "EP-20": [4, "Pricing page, warnings, import/export dry run"],
    "EP-21": [5, "US-21.08 Messages state first; the rest are reports"],
    "EP-08": [6, "Routing grammar and lanes: gateway-only, no browser"],
    "EP-18": [7, "Accounts and billing: half automated already"],
    "EP-03": [8, "Receipts and traffic control: the 0.12.9 per-listener rules"],
    "EP-12": [9, "Whitelisting"],
    "EP-10": [10, "CDR and usage incl. partitions"],
    "EP-15": [11, "Ops and CLI"],
    "EP-14": [12, "Licensing incl. the reload answer"],
    "EP-11": [13, "Webhooks"],
    "EP-05": [14, "Vendor outcomes"],
    "EP-04": [15, "Vendor connections"],
    "EP-07": [16, "Registrations and transfers"],
    "EP-13": [17, "Diagnostics"],
    "EP-16": [18, "Resilience and upgrade"],
    "EP-22": [19, "Portal: finish the 7 todo"],
    "EP-01": [20, "Done bar the Host cases"],
    "EP-02": [21, "Done bar the Host cases"],
    "EP-17": [22, "Done; add US-17.04 Users"],
    "EP-23": [23, "Done"],
    "EP-24": [24, "Host-bound: stays manual except the SHA/signature checks"],
  };
  const covRows: (string | number | { formula: string })[][] = [];
  for (let i = 0; i < epicCount; i++) {
    const e = i + 2;
    const r = i + 2;
    const id = text(sheets.epics.getRow(e).getCell(1));
    const [order, note] = phase2[id] ?? [99, ""];
    covRows.push([f(`Epics!A${e}`), f(`Epics!B${e}`), f(`Epics!C${e}`), f(`Epics!G${e}`), f(`Epics!${col(EPIC.nAuto)}${e}`), f(`Epics!${col(EPIC.nTodo)}${e}`), f(`Epics!${col(EPIC.nManual)}${e}`), f(`D${r}-E${r}-F${r}-G${r}-COUNTIFS(TestCases!$D:$D,A${r},TestCases!$${col(TC.automation)}:$${col(TC.automation)},"Fixme")`), f(`COUNTIFS(TestCases!$D:$D,A${r},TestCases!$${col(TC.changed)}:$${col(TC.changed)},"New")`), f(`COUNTIFS(TestCases!$D:$D,A${r},TestCases!$${col(TC.changed)}:$${col(TC.changed)},"Updated")`), f(`IF(D${r}=0,0,E${r}/D${r})`), order, note]);
  }
  fillSheet(cov, covRows);
  for (let r = 2; r <= cov.rowCount; r++) cov.getCell(`K${r}`).numFmt = "0%";
  cov.autoFilter = { from: "A1", to: `M${cov.rowCount}` };

  // Rigs & Tools: what changed since 0.11
  const rigs = wb.getWorksheet("Rigs & Tools") ?? fail("no Rigs");
  const rigRows: string[][] = [
    ["SMPPSim shipped with the release (0.12.7+)", "fireflo-install --with-smppsim · fireflo-install smppsim (existing install) · fireflo smppsim-setup", "Runs beside the gateway, routes MESSAGE to it when there is no catch-all, invents its receipts. fireflo selftest then sends one real message and reports route / price / receipt / debit as PASS/FAIL/SKIP (exit 0/1/2). Replace with a real vendor before real traffic."],
    ["The e2e rig (fireflo-control-panel/e2e)", "cp e2e/.env.e2e.example e2e/.env.e2e · npm run e2e (or e2e:epic -- @EP-09, e2e:run -- --grep TC-09.06)", "Self-contained: its own database (name must contain e2e; truncated each run), EdgeSmsc A/B on 28800/28801, gateway 8100/9100 with a 2 s config poll, SMPP 27800–27802, panel 3100, SMTP sinks 4465/4587. Seed: qa-acct-a/b, qa-portal-a, qa-reseller-r → qa-child-c1, product standard, AUD 0.0100 / cost 0.0050, vendors qa-sim1/qa-sim2, listeners smpp/smpp2, group qa-failover. Results: e2e/.run/results.json; npm run e2e:writeback copies them into a dated workbook."],
    ["Staging host 192.168.1.101 (fireflo-trial)", "ssh anshu@192.168.1.101 · gateway :8081 (HTTP) :9000 (ops) :27777 (SMPP) · panel :3000 · ~/staging/debit-test-101.sh setup|product|unproduct|state|teardown", "The 0.12.14 product/debit reproduction lives there: product test-pro, rules omni/load at 0.1100 AUD, balance enforcement on, 10 AUD per account. Every sudo step is the operator's."],
  ];
  addRigRows(rigs, rigRows);

  // sheet order: the plan, then the two views, then history and tools
  const order = ["README", "Epics", "Stories", "Scenarios", "TestCases", "Traceability", "Coverage", "0.12 Focus", "0.11 Focus (history)", "Rigs & Tools"];
  orderSheets(wb, order);

  wb.creator = "fireflo-control-panel/scripts/qa-plan-0.12.ts";
  wb.modified = new Date();
  await wb.xlsx.writeFile(OUT);

  const total = sheets.cases.rowCount - 1;
  console.log(`wrote ${path.relative(process.cwd(), OUT)}`);
  console.log(`  epics ${sheets.epics.rowCount - 1}, stories ${sheets.stories.rowCount - 1}, scenarios ${sheets.scenarios.rowCount - 1}, test cases ${total}`);
  console.log(`  added: stories ${added.stories}, scenarios ${added.scenarios}, cases ${added.cases}; updated ${added.updates}; retired ${added.retired}; focus rows ${focus.length}`);
  console.log(`  automation: automated ${counts.Automated}, todo ${counts.Todo}, manual ${counts.Manual}, fixme ${counts.Fixme}, not in suite ${counts.none}; last run ${run.at || "none"} (${run.results.size} results)`);
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});
