# QA plan 0.15: how the workbook is built

`npm run qa-plan` (= `node --experimental-strip-types scripts/qa-plan-0.15.ts`) reads the 0.12
workbook, carries the 0.12 change files forward onto it, applies every 0.15 change file — the
gateway's and the panel's in `scripts/qa-plan-0.15/changes/EP-*.ts`, then FireFlo OMNI's — fills the
automation columns from the e2e suites, and writes the 0.15 workbook. The input is never modified.
`npm run qa-plan:0.12` still builds the 0.12 workbook from the 0.11 one.

| flag | environment | default |
|---|---|---|
| `--src` | `QA_PLAN_SRC` | `../fireflo-sms-gateway/docs/26-qa-test-plan-0.12.xlsx` |
| `--out` | `QA_PLAN_OUT` | `../fireflo-sms-gateway/docs/26-qa-test-plan-0.15.xlsx` |
| `--omni` | `QA_PLAN_OMNI` | `../fireflo-omni-js/e2e/qa-plan/changes` (skipped, with a line saying so, when absent) |
| `--omni-e2e` | `QA_PLAN_OMNI_E2E` | `../fireflo-omni-js/e2e` (its `*.spec.ts` fill OMNI's Automation column) |

`QA_PLAN_ONLY=EP-09,EP-10` validates a subset while other change files are being written.

```bash
npm run qa-plan -- --src ../wt-gw-0142/docs/26-qa-test-plan-0.12.xlsx --out out/26-qa-test-plan-0.15.xlsx \
                   --omni ../wt-omni-js-e2e/e2e/qa-plan/changes
E2E_QA_WORKBOOK=out/26-qa-test-plan-0.15.xlsx npm run e2e:catalog   # then the suite follows the sheet
npm run e2e:scaffold -- --append --sync-titles                      # todos for new ids, titles of rewritten rows
npm run e2e:check
```

## What the build does, in order

1. **Carry 0.12 forward.** The committed 0.12 workbook was built before the last 0.12 change files
   were written (US-18.09, US-21.11, US-21.12 and 24 cases). Every story, scenario or case of
   `scripts/qa-plan-0.12/changes` the input lacks is added, marked in the 0.12 columns, and every
   0.12 update is re-applied (idempotent). The result equals a fresh `qa-plan:0.12` build, id by id.
2. **Apply 0.15.** New epics (EP-25 Kafka Backbone & Cluster, EP-26 Persistence Bus, Local Log &
   Database Admission, EP-27 Platform API on the Management Port), stories, scenarios and cases are
   inserted under their parents; `updates`, then `rewrites`, then `retire` are applied to the 0.12
   rows. Everything 0.15 does is marked in the columns this build appends — the 0.12 ones stay as
   history:

   | Sheet | appended column |
   |---|---|
   | Stories | O "Changed in 0.15" |
   | Scenarios | O "Changed in 0.15" |
   | TestCases | AB "Changed in 0.15", AC "Change note 0.15 (release: why)" |
   | Epics | P "# Changed in 0.15" |

   Columns A–P of TestCases are the ones the e2e catalog reads positionally; nothing before them moves.
3. **Automation** from `e2e/epics` (and OMNI's suite when it is beside this repo): Automated, Todo,
   Manual, Fixme, Blocked; **Last e2e run** from `e2e/.run/results.json`, or blank — a previous
   build's run is not carried.
4. **Views**: README rows, Traceability (0.15 counts), Coverage (rebuilt), a "0.15 Focus" sheet before
   "0.12 Focus (history)", Rigs & Tools rows for what 0.13–0.15 added.

## The change file

The 0.12 format (`scripts/qa-plan-0.12/README.md`), the type in `../qa-plan-types.ts`, plus:

```ts
const change: Change = {
  epic: "EP-25",
  epicName: "Kafka Backbone & Cluster",       // a NEW epic only: its name, component and description
  epicComponent: "Gateway",
  epicDescription: "…",
  stories: [ … ], scenarios: [ … ], cases: [ … ],
  updates: [ { id: "TC-16.06.01-P01", changed: "Updated", changeNote: "0.13.x (V1.105.0): …", set: { expected: "…" } } ],
  rewrites: [ { pattern: "/ops/health", replace: "the `health` query (POST /graphql)", changeNote: "0.13.0: …" } ],
  retire: [ { id: "US-16.02", reason: "0.14.0: RabbitMQ support is removed …" }, { id: "TC-16.02.01-P01", reason: "…" } ],
  focus: [ { item: "0.15.4", change: "…", scenarios: "SC-…", risk: "…" } ],
};
```

- **`rewrites`** replace one RegExp in every plan column of every 0.12 row (never a row this release
  added) and mark each row they change Updated with the note. EP-15 uses them for the 0.13 move from
  `/ops/*` to GraphQL: one pattern per route in `api/graphql-port.json`, ≈235 rows.
- **`retire`** takes a TC, a scenario or a story. A retired TC keeps its row (greyed, Status N/A, the
  reason in the 0.15 note) and **leaves the e2e catalog**: it is history, not a test, so its spec
  declaration is deleted too.
- **`changeNote`** is the release, then why: `"0.15.2"`, `"0.15.1 (V1.118.0)"`, `"0.15.4.0"` for a
  panel-only change, `"Unreleased (after 0.15.4): …"` for what is merged but not released.
- Components: Gateway, Control Panel, Cross-component, and **OMNI**. Surfaces: SMPP, HTTP, Ops (the
  management port, GraphQL since 0.13), CLI, Panel, Portal, API, Host, and **OMNI Panel**, **OMNI API**.

## OMNI's change files

FireFlo OMNI contributes its own change files from `fireflo-omni-js/e2e/qa-plan/changes/EP-3n.ts`,
epics **EP-30 … EP-39** only (the gateway and panel use EP-01 … EP-29; the builder refuses either
crossing over). They are loaded by path and imported for their default export, so they need nothing
from this repository: a plain object of the `Change` shape is enough —

```ts
// fireflo-omni-js/e2e/qa-plan/changes/EP-30.ts — no import needed
export default {
  epic: "EP-30",
  epicName: "OMNI Panel — Wallet and Pots",   // a new epic: name it (component defaults to "OMNI")
  epicDescription: "…",
  stories: [ … ], scenarios: [ … ],
  cases: [ { …, component: "OMNI", surface: "OMNI Panel", changeNote: "OMNI 1.2.0" } ],
};
```

— or, for the type check, `import type { Change } from "<path to fireflo-control-panel>/scripts/qa-plan-types.ts"`
(erased at run time). The same rules apply to them: ids nest and are contiguous, every scenario has
Given/When/Then, every case steps/expected/oracle, every P0 an anti-vacuity check. OMNI's rows are left
out of this repo's e2e catalog (component OMNI): OMNI's own Playwright suite declares them, and its
`tc("TC-3…")` declarations fill their Automation column when `--omni-e2e` points at it.

## Writing rules

As 0.12's (`scripts/qa-plan-0.12/README.md`), and one the owner added for 0.15: **every case that
involves a throughput field names it** — its key, its scope, what it limits and where it sits in the
order at the door:

1. the login's TPS, `app_credential.max_tps` ("Login › TPS"): one login, a dedicated rate from its own
   limiter (0.15.2), first, outside the port share, above or below the account's;
2. else the account's `conf.maxRate.<account>`: one account on one listener (gateway-wide as
   `outSms.default.conf.maxRate.<account>`), outside the split;
3. else the port share, `min(conf.maxRate.default × cluster share, tps ÷ active accounts)`, never below
   1/s, where `tps` is the listener's "Throughput limit" (the port's submit budget) and an active account
   submitted within `smsg.port.share.active.seconds` (10).

Over the ceiling a submit is **0x58** (ESME_RTHROTTLED), not charged and leaves no call record; credit
not yet in hand is **0x14** creditPending, also not charged. A vendor's `tps` limits what the gateway
sends to that vendor, never what customers submit.
