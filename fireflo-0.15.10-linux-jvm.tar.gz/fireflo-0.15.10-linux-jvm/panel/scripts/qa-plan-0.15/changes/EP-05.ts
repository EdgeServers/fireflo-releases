import type { Change } from "../../qa-plan-types.ts";

/**
 * EP-05 — SMPP Client: Submit Outcomes, Retry & Recovery, 0.12 → 0.15.4.
 *
 * 0.13.x–0.15.1 fixes on the vendor side: a vendor retry no longer sleeps on the thread that reported
 * it (a killed vendor's in-flight submits come back in seconds, not 98 s); no submit is lost when a
 * bind is torn down for failed enquire_links; a submit whose write timed out is outcome-unknown, not
 * sent twice; a connection being removed records the answers it already had; a message a vendor
 * accepted twice is priced once; a late ESME_ROK after the gateway gave up is priced once.
 */
const change: Change = {
  epic: "EP-05",
  stories: [
    {
      id: "US-05.06", epic: "EP-05", story: "Late, lost and doubled vendor answers are recorded once (0.13.4–0.15.1)", asA: "an operator",
      iWant: "every submit to a vendor to end with exactly one priced send record, whatever order its answer, its timeout and its retry arrive in",
      soThat: "a slow, dying or flapping vendor never sends a customer's message twice, never leaves it charged without a price, and never loses it",
      acceptance: "1. A late ESME_ROK after the gateway gave up (request.tout) is recorded as sent and priced unless already priced; a waiting retry is not sent again (0.15.1). 2. A message accepted twice by a vendor has one priced cdr_submit row; the second is unbilled and logged message.submit.accepted.again billed=false (0.14.3). 3. A submit whose socket write timed out is outcome-unknown: not retried, its window entry kept so a late answer is recorded once; with no answer within request.tout it is 0x000000FE for the status lists (smpp.submit.ambiguous / .resolved / smpp.submit.resp.late). 4. A connection being removed is closed first and its window reclaimed once the close completes (smpp.connection.close.pending). 5. A retryable answer, an expiry or a reclaim is a delayed requeue on the transport: fail.action.worker.sleep is not slept on the reporting thread, so a vendor killed with N in flight hands them back within seconds. 6. A bind torn down for failed enquire_links loses no submit that expired in the same window-monitor pass.",
      configKeys: "request.tout | window.offer.timeout.ms | fail.action.worker.sleep | fail.action.router.sleep | enquire.link.interval.millis", observable: "cdr_submit (price, billed) per gateway_msg_id; EdgeSmsc distinct/pdus; smsg.log smpp.submit.*, message.submit.accepted.again, vendor reclaim line; /q/metrics fireflo_smpp_submit_*", automated: "LatePricingTest, AmbiguousSubmitTest, ReclaimTimingTest", changed: "New",
    },
  ],
  scenarios: [
    { id: "SC-05.06.01", story: "US-05.06", epic: "EP-05", scenario: "A vendor that answers late, twice, or dies with submits in flight", gwt: "Given qa-sim1 with request.tout 3000 ms and fail.action.worker.sleep 500 ms. When EdgeSmsc A delays its answers past the timeout, and separately is killed with 50 submits in flight. Then each late-answered message has one priced cdr_submit row and is not sent again, and the killed vendor's 50 are handed back and re-routed within a few seconds, each delivered once.", preconditions: "rig with EdgeSmsc control and kill", rig: "EdgeSmsc delay/kill/restart; psql cdr_submit; smsg.log; EdgeSmsc stats", related: "SC-05.03.01, SC-05.01.01", dependsOn: "", changed: "New" },
  ],
  cases: [
    { id: "TC-05.06.01-P01", scenario: "SC-05.06.01", story: "US-05.06", epic: "EP-05", type: "Positive", title: "A late ESME_ROK after request.tout is priced once and the message is not resent", steps: "1. qa-sim1 request.tout = 3000 and fail.action.worker.sleep = 10000 (the retry waits 10 s); rebind. 2. EdgeSmsc A: delay 4000 (every answer after the timeout, before the retry). 3. Send 3 as qa-acct-a. 4. Wait 20 s; EdgeSmsc A: delay 0. 5. Per message: count priced cdr_submit rows; EdgeSmsc distinct vs pdus.", testData: "", expected: "Each message: exactly one cdr_submit row with price 0.0100 (no priced duplicates, no unpriced row while the customer was charged); EdgeSmsc pdus == distinct for these 3 (no resend); smsg.log smpp.submit.resp.late for each", oracle: "psql cdr_submit per gateway_msg_id; EdgeSmsc stats; smsg.log", antiVacuity: "194 of 334 charged-without-a-price on .101 came from this; 'one row' is not enough — the row must carry the price.", priority: "P0", component: "Gateway", automated: "LatePricingTest", related: "", surface: "SMPP", changed: "New", changeNote: "0.15.1" },
    { id: "TC-05.06.01-P02", scenario: "SC-05.06.01", story: "US-05.06", epic: "EP-05", type: "Positive", title: "A vendor killed with 50 in flight hands them back within seconds, not minutes", steps: "1. EdgeSmsc A: delay 30000 (hold answers); route MESSAGE to qa-failover; qa-sim1 status.retry.router = 254 (a reclaimed submit is answered 0x000000FE, and the status lists decide where it goes). 2. Send 50 as qa-acct-a. 3. SIGKILL EdgeSmsc A; note the time. 4. Watch smsg.log for the reclaim line and cdr_submit for vendor qa-sim2.", testData: "fail.action.worker.sleep 500", expected: "The reclaim line within ~5 s of the kill (not 50 × 0.5 s = 25 s or more); every one handed back to the router and sent on qa-sim2, delivered once each (with the default status lists, 0x000000FE retries on qa-sim1 instead)", oracle: "smsg.log timestamps; psql cdr_submit.vendor; cdr_final", antiVacuity: "", priority: "P1", component: "Gateway", automated: "ReclaimTimingTest", related: "TC-05.03.01-P01", surface: "SMPP", changed: "New", changeNote: "0.14.0" },
    { id: "TC-05.06.01-N01", scenario: "SC-05.06.01", story: "US-05.06", epic: "EP-05", type: "Negative", title: "A submit whose write timed out is outcome-unknown: never sent twice", steps: "1. Make the vendor socket stop reading (a fake SMSC that accepts the bind and stops reading) with a small window.offer.timeout.ms. 2. Send 20. 3. Let the vendor read again and answer. 4. Count submit_sm received per message at the vendor; cdr_submit rows.", testData: "", expected: "No message received twice; smpp.submit.ambiguous WARN then .resolved for the late answers; those with no answer within request.tout end 0x000000FE and follow the status lists", oracle: "fake SMSC captured submits; smsg.log; psql cdr_submit", antiVacuity: "", priority: "P1", component: "Gateway", automated: "AmbiguousSubmitTest", related: "", surface: "Host", changed: "New", changeNote: "0.14.3" },
  ],
  focus: [
    { item: "0.15.1", change: "A late ESME_ROK after the gateway gave up on a submit is priced once; a vendor worker cannot stall for good in memory mode.", scenarios: "SC-05.06.01", risk: "" },
    { item: "0.14.3", change: "Write-timed-out submits are outcome-unknown; a connection being removed records the answers it had; a message accepted twice is priced once.", scenarios: "SC-05.06.01", risk: "" },
  ],
};
export default change;
