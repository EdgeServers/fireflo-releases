import type { Change } from "../../qa-plan-types.ts";

/**
 * EP-20 — Operator Panel: Pricing, Gateway Settings & Approvals, 0.12 → 0.15.4.0.
 *
 * Panel 0.15.4.0: copy sender IDs and templates to several accounts at once — tick rows on Assets ›
 * Headers / Templates (or on an account's Approvals) and "Copy N to accounts…": keep their approval
 * or copy them as pending, optionally widen login-only rows to the whole account; nothing already in
 * a target is changed; one audit entry per row. POST /api/control/whitelist/{headers,templates}/copy.
 */
const change: Change = {
  epic: "EP-20",
  stories: [
    {
      id: "US-20.07", epic: "EP-20", story: "Copy sender IDs and templates to several accounts (0.15.4.0)", asA: "an operator",
      iWant: "to copy approved sender IDs and templates from one account to many in one step, choosing whether they stay approved",
      soThat: "onboarding a reseller's customers, or a second account of one customer, does not mean re-filing every sender ID",
      acceptance: "1. Assets › Headers and Templates: every row can be ticked; 'Copy N to accounts…' opens 'Copy to accounts'. Account › Approvals has 'Copy to accounts…' too. 2. The dialog: 'Copy N headers and M templates to K accounts: a, b.'; Target accounts (typeahead 'Type an account name or id', removable chips); 'Status in the target accounts': Keep approval | Copy as pending; 'Copy login-only rows to the whole account'; 'Nothing already in a target account is changed.'; Copy. 3. Result: 'Copied. Recorded in the audit log, one entry per row.' and per account 'N copied · N already there · N login-only, skipped · N rejected, skipped · N withdrawn, skipped · N already its own'. 4. Rejected rows are never copied; a row whose text and product are already in a target is skipped as already there. 5. POST /api/control/whitelist/headers/copy and /templates/copy {ids, to, status: keep|pending, widenScope} answer {data: [{to, copied, skipped: [{id, text, reason}]}]}; 400 for a target that is not an account or is archived, a product not in the catalogue, or more than 500 rows / 50 targets; operator or admin only (404 otherwise).",
      configKeys: "app_header | app_template | POST /api/control/whitelist/{headers,templates}/copy", observable: "dialog text; psql app_header/app_template rows per account; app_operator_access_log one entry per row", automated: "whitelist-copy-rules.test.ts, audit.test.ts", changed: "New",
    },
  ],
  scenarios: [
    { id: "SC-20.07.01", story: "US-20.07", epic: "EP-20", scenario: "Copy two approved sender IDs and a template from qa-acct-a to qa-acct-b and qa-portal-a", gwt: "Given qa-acct-a with sender IDs QA1 and QA2 APPROVED (QA2 already on qa-portal-a) and template 'Your code is {code}' APPROVED, and a REJECTED sender ID QAX. When the operator ticks QA1, QA2 and QAX on Assets › Headers, copies them to qa-acct-b and qa-portal-a keeping approval, and copies the template from qa-acct-a's Approvals as pending. Then qa-acct-b gets QA1 and QA2 APPROVED, qa-portal-a gets QA1 (QA2 already there), QAX is skipped as rejected everywhere, the template lands PENDING, and the audit log has one entry per copied row.", preconditions: "rig; operator session; app_header/app_template rows seeded", rig: "browser /cp/assets/headers, /cp/accounts/qa-acct-a/approvals; psql app_header, app_template, app_operator_access_log", related: "SC-20.04.01, SC-12.02.01", dependsOn: "", changed: "New" },
  ],
  cases: [
    { id: "TC-20.07.01-P01", scenario: "SC-20.07.01", story: "US-20.07", epic: "EP-20", type: "Positive", title: "Copy ticked headers to two accounts keeping approval: copied, already there and rejected each reported", steps: "1. Three accounts of the case's own: the source with headers QA1, QA2 APPROVED and QAX REJECTED; target C already has QA2. 2. /cp/assets/headers for the source: tick QA1 and QA2 (a rejected row has no tick box); 'Copy 2 to accounts…'. 3. Add targets B and C; Keep approval; Copy. 4. Read the result and app_header for both targets. 5. POST /api/control/whitelist/headers/copy with QAX to B, status keep.", testData: "", expected: "Result 'Copied. Recorded in the audit log, one entry per row.'; B '2 copied'; C '1 copied · 1 already there'; app_header: B QA1, QA2 APPROVED; C QA1 APPROVED and its own QA2 untouched (updated_at unchanged); step 5 answers 200 with copied 0 and skipped [rejected]; no QAX anywhere but the source", oracle: "dialog text; psql app_header", antiVacuity: "A copy that also copied QAX, or that touched qa-portal-a's existing QA2 (status, updated_at), fails here: compare the existing row before and after.", priority: "P0", component: "Control Panel", automated: "whitelist-copy-rules.test.ts", related: "", surface: "Panel", changed: "New", changeNote: "0.15.4.0" },
    { id: "TC-20.07.01-P02", scenario: "SC-20.07.01", story: "US-20.07", epic: "EP-20", type: "Positive", title: "From an account's Approvals, copy a template as pending", steps: "1. Seed qa-acct-a template 'Your code is {code}' APPROVED. 2. /cp/accounts/qa-acct-a/approvals: tick it; Copy to accounts…; target qa-acct-b; Copy as pending; Copy. 3. Read app_template for qa-acct-b.", testData: "", expected: "'1 copied'; qa-acct-b has the template with status PENDING; one config_changed audit row for it", oracle: "dialog; psql app_template; app_operator_access_log", antiVacuity: "", priority: "P1", component: "Control Panel", automated: "", related: "", surface: "Panel", changed: "New", changeNote: "0.15.4.0" },
    { id: "TC-20.07.01-N01", scenario: "SC-20.07.01", story: "US-20.07", epic: "EP-20", type: "Negative", title: "The copy route refuses a target that is not an account, and is not there for a customer", steps: "1. As the operator POST /api/control/whitelist/headers/copy {ids: [<QA1>], to: ['qa-nosuch']}. 2. {ids: [], to: ['qa-acct-b']}. 3. As a portal session (qa-portal-a) POST the same as 1 with to ['qa-acct-b'].", testData: "", expected: "1: 400 naming the account; 2: 400 'Choose the sender IDs to copy: expected \"ids\", a list of row ids.'; 3: 404; nothing written in any", oracle: "HTTP status/body; psql app_header count", antiVacuity: "A route that 404s everything passes step 3; steps 1 and 2 (400 for the operator) prove the route is there and judging the body.", priority: "P0", component: "Control Panel", automated: "", related: "TC-17.03.01-N01", surface: "API", changed: "New", changeNote: "0.15.4.0" },
  ],
  focus: [
    { item: "0.15.4.0", change: "Copy sender IDs and templates to several accounts (Assets › Headers / Templates, Account › Approvals; /api/control/whitelist/*/copy).", scenarios: "SC-20.07.01", risk: "" },
  ],
};
export default change;
