import type { Change } from "../../qa-plan-types.ts";

/**
 * EP-01 — SMPP Server: Bind & Session, 0.12 → 0.15.4.
 *
 * 0.13: a refused bind names its listener and port in the auth.refused line, the post-credential
 * reasons (ipLimit, accountLimit, loginLimit, backoff, productNotAllowed) are written too, the
 * meters gain a listener tag, and the last smsg.auth.ledger.keep refusals are served parsed by the
 * refusals / refusalSummary queries. 0.13.4 masked the bind password in the log (TC-01.01.01-N06
 * found it). 0.14 honoured conf.maxConnectionsPerUser.<account> (found by TC-01.02.02-*).
 */
const change: Change = {
  epic: "EP-01",
  stories: [
    {
      id: "US-01.08", epic: "EP-01", story: "Refused binds name their listener and port, and are kept in the refusal ledger (0.13)", asA: "an operator",
      iWant: "every refused bind to say which listener and port refused it and why, and to read the recent refusals already parsed",
      soThat: "a customer's 'cannot bind' is answered from the panel or the API by port and reason, and fail2ban bans only on wrong credentials",
      acceptance: "1. The auth.refused line for an SMPP bind carries listener=<worker> port=<port> before ip=: 'auth.refused surface=smpp reason=badPassword identity=\"acme\" listener=smppserver.main port=22775 ip=203.0.113.9'. 2. Reasons written: badPassword, unknownIdentity, addressNotAllowed and the post-credential ipLimit, accountLimit, loginLimit, backoff, productNotAllowed. 3. Meters fireflo_smpp_bind_refused_total{listener,reason} and fireflo_smpp_bind_backoff_total{listener} replace the untagged totals. 4. GraphQL refusals(windowMinutes, listener, surface, reason, ip, limit) and refusalSummary(windowMinutes, listener) serve the last smsg.auth.ledger.keep (50,000) refusals by listener and port, then reason and address. 5. The shipped fail2ban filter matches the old and new shape; its ignoreregex keeps post-credential reasons from adding up to a ban.",
      configKeys: "smsg.auth.ledger.keep (FIREFLO_AUTH_LEDGER_KEEP) | conf.example/fail2ban/filter.d/fireflo-gateway.conf", observable: "smsg.log / auth-failed.log auth.refused; GraphQL refusals, refusalSummary; /q/metrics fireflo_smpp_bind_refused_total", automated: "AuthRefusalTest, RefusalLedgerTest", changed: "New",
    },
  ],
  scenarios: [
    { id: "SC-01.08.01", story: "US-01.08", epic: "EP-01", scenario: "A refused bind is named by listener and port, and served by the refusal ledger", gwt: "Given listeners smpp (27800) and smpp2 (27801) and qa-acct-a's SMPP login. When a bind with a wrong password is made on smpp, one on smpp2, and a bind over the login's session limit on smpp. Then each auth.refused line names its listener and port and reason, refusals() returns them with those fields, refusalSummary() counts them per listener, the bind_refused meter rises under the right listener tag, and the session-limit refusal carries reason loginLimit.", preconditions: "rig listeners; srv.bind.backoff.enabled false (rig)", rig: "ESME bindAttempt; auth-failed.log/smsg.log (trace); GraphQL refusals/refusalSummary; /q/metrics", related: "SC-01.01.01, SC-21.05.01", dependsOn: "", changed: "New" },
  ],
  cases: [
    { id: "TC-01.08.01-P01", scenario: "SC-01.08.01", story: "US-01.08", epic: "EP-01", type: "Positive", title: "A wrong password on smpp is logged with listener=smppserver.smpp port=27800 and served by refusals()", steps: "1. Mark the logs. 2. Bind qa-acct-a-smpp with a wrong password on 127.0.0.1:27800. 3. Read the new auth.refused line. 4. Query refusals(windowMinutes: 5, listener: \"smppserver.smpp\") with the read token.", testData: "password 'wrongpw1'", expected: "bind_resp 0x0E; the line reads 'auth.refused surface=smpp reason=badPassword identity=\"qa-acct-a-smpp\" listener=smppserver.smpp port=27800 ip=127.0.0.1'; refusals() has a row with listener smppserver.smpp, port 27800, reason badPassword, ip 127.0.0.1 and that identity", oracle: "auth-failed.log / smsg.log line; GraphQL refusals[] fields", antiVacuity: "The 0.12 line had no listener or port; a check that only greps reason=badPassword passes on the old gateway — the listener= and port= fields are the 0.13 claim.", priority: "P1", component: "Gateway", automated: "AuthRefusalTest", related: "TC-01.01.01-N01", surface: "SMPP", changed: "New", changeNote: "0.13.0" },
    { id: "TC-01.08.01-P02", scenario: "SC-01.08.01", story: "US-01.08", epic: "EP-01", type: "Positive", title: "refusalSummary counts by listener and port; the meter is tagged by listener", steps: "1. Read fireflo_smpp_bind_refused_total{listener=smppserver.smpp2,reason=badPassword}. 2. Make one wrong-password bind on smpp2 (27801). 3. Query refusalSummary(windowMinutes: 5). 4. Read the meter again, and the smppserver.smpp sample.", testData: "", expected: "refusalSummary has an entry for smppserver.smpp2 (port 27801) whose badPassword count rose by 1; fireflo_smpp_bind_refused_total{listener=\"smppserver.smpp2\", reason=\"credentials\"} (the meter's word for a wrong password) rose by exactly 1 and the smppserver.smpp sample did not move", oracle: "GraphQL refusalSummary; /q/metrics on the messaging port", antiVacuity: "", priority: "P2", component: "Gateway", automated: "", related: "", surface: "SMPP", changed: "New", changeNote: "0.13.0" },
    { id: "TC-01.08.01-N01", scenario: "SC-01.08.01", story: "US-01.08", epic: "EP-01", type: "Negative", title: "A bind over the login's session limit is refused and recorded as loginLimit, not as a credential failure", steps: "1. Create a login of qa-acct-a with max sessions 1 (app_credential.max_sessions). 2. Bind it once (ok). 3. Bind it a second time. 4. Query refusals(reason: \"loginLimit\").", testData: "", expected: "Second bind refused (non-zero bind_resp); the auth.refused line has reason=loginLimit with listener and port; refusals() lists it with reason loginLimit; the shipped fail2ban filter's ignoreregex matches that line (a post-credential reason never counts toward a ban)", oracle: "bind_resp; smsg.log; GraphQL refusals; conf.example/fail2ban/filter.d/fireflo-gateway.conf ignoreregex", antiVacuity: "", priority: "P1", component: "Gateway", automated: "", related: "TC-01.02.01-N02", surface: "SMPP", changed: "New", changeNote: "0.13.0" },
  ],
  updates: [
    { id: "TC-01.02.02-N01", changed: "Updated", changeNote: "0.14.0: conf.maxConnectionsPerUser.<accountId> is honoured (it was read by nobody); found by this case", set: { expected: "5 sessions bind; 6th refused; the account's own key wins above or below the default, counts binds from every address together, and applies from the next bind (a session already up is never unbound)" } },
  ],
  focus: [
    { item: "0.13.0", change: "Refused logins name the listener and port and are kept in a ledger (refusals, refusalSummary); new post-credential reasons; tagged meters.", scenarios: "SC-01.08.01, SC-21.05.01", risk: "A fail2ban filter older than the shipped one may not match the new line shape." },
  ],
};
export default change;
