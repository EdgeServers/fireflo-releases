/**
 * What the QA-plan builders share: reading and indexing the workbook, loading and validating change
 * files, inserting rows under their parent, updates, rewrites and retirements, the automation
 * columns from the e2e suite, and the count formulas.
 *
 * Used by scripts/qa-plan-0.12.ts (0.11 → 0.12) and scripts/qa-plan-0.15.ts (0.12 → 0.15). Each
 * release's builder says which columns its "Changed in …" marks go to (a `ChangeTarget`); everything
 * else is the same engine.
 *
 * Only erasable TypeScript syntax: this runs under `node --experimental-strip-types`.
 */
import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
import ExcelJS from "exceljs";
import type { Cell, Row, Worksheet } from "exceljs";
import type { CaseRow, Change, ScenarioRow, StoryRow } from "./qa-plan-types.ts";

// ---------------------------------------------------------------------------------------------
// columns (1-based) — the 0.11 layout, which the e2e catalog reads positionally and must not move,
// then what 0.12 appended (Surface … Last run note), then what 0.15 appends (Changed in 0.15 …)
export const STORY = { id: 1, epic: 2, story: 3, asA: 4, iWant: 5, soThat: 6, acceptance: 7, configKeys: 8, observable: 9, newIn011: 10, automated: 11, nScenarios: 12, nTcs: 13, changed: 14, changed015: 15 } as const;
export const SCEN = { id: 1, story: 2, epic: 3, scenario: 4, gwt: 5, preconditions: 6, rig: 7, related: 8, dependsOn: 9, newIn011: 10, nTcs: 11, nPos: 12, nNeg: 13, changed: 14, changed015: 15 } as const;
export const TC = { id: 1, scenario: 2, story: 3, epic: 4, type: 5, title: 6, steps: 7, testData: 8, expected: 9, oracle: 10, antiVacuity: 11, priority: 12, component: 13, newIn011: 14, automated: 15, related: 16, status: 17, actual: 18, tester: 19, date: 20, notes: 21, surface: 22, changed: 23, changeNote: 24, automation: 25, lastRun: 26, lastRunNote: 27, changed015: 28, changeNote015: 29 } as const;
export const EPIC = { id: 1, epic: 2, component: 3, description: 4, nStories: 5, nScenarios: 6, nTcs: 7, nPos: 8, nNeg: 9, nP0: 10, nNew011: 11, nChanged: 12, nAuto: 13, nTodo: 14, nManual: 15, nChanged015: 16 } as const;

/** The plan columns a change file may write, by sheet. Status, automation and counts are the builder's. */
const STORY_TEXT = ["story", "asA", "iWant", "soThat", "acceptance", "configKeys", "observable", "automated"] as const;
const SCEN_TEXT = ["scenario", "gwt", "preconditions", "rig", "related", "dependsOn"] as const;
const TC_TEXT = ["title", "steps", "testData", "expected", "oracle", "antiVacuity", "related", "automated"] as const;

/** Where a release's "Changed in …" marks go. */
export interface ChangeTarget {
  /** e.g. "0.15" — used in messages */
  release: string;
  storyChanged: number;
  scenChanged: number;
  tcChanged: number;
  tcNote: number;
  /** a second note on one TC is appended (" | ") rather than replacing the first */
  appendNotes: boolean;
}
export const TARGET_012: ChangeTarget = { release: "0.12", storyChanged: STORY.changed, scenChanged: SCEN.changed, tcChanged: TC.changed, tcNote: TC.changeNote, appendNotes: false };
export const TARGET_015: ChangeTarget = { release: "0.15", storyChanged: STORY.changed015, scenChanged: SCEN.changed015, tcChanged: TC.changed015, tcNote: TC.changeNote015, appendNotes: true };

export const col = (n: number) => {
  let s = "";
  for (let x = n; x > 0; x = Math.floor((x - 1) / 26)) s = String.fromCharCode(65 + ((x - 1) % 26)) + s;
  return s;
};

// ---------------------------------------------------------------------------------------------
export function text(cell: Cell | undefined): string {
  const v = cell?.value as unknown;
  if (v == null) return "";
  if (typeof v === "string") return v;
  if (typeof v === "object") {
    const o = v as { richText?: { text: string }[]; result?: unknown; text?: string; formula?: string };
    if (Array.isArray(o.richText)) return o.richText.map((r) => r.text).join("");
    if (o.formula) return "";
    if (typeof o.text === "string") return o.text;
    if ("result" in o) return o.result == null ? "" : String(o.result);
  }
  return String(v);
}

export function fail(msg: string): never {
  throw new Error(msg);
}

/** `--name value` from argv, else the environment variable, else the default. */
export function arg(name: string, envName: string, dflt: string): string {
  const i = process.argv.indexOf(`--${name}`);
  if (i > 0 && process.argv[i + 1]) return path.resolve(process.argv[i + 1]);
  return process.env[envName] ? path.resolve(process.env[envName]!) : dflt;
}

// ---------------------------------------------------------------------------------------------
// automation status from a Playwright suite that declares its cases with tc()/tc.manual()/…
export type Kind = "Automated" | "Manual" | "Todo" | "Fixme" | "Blocked";
export function automationFromSuite(epicsDir: string, into = new Map<string, { kind: Kind; spec: string }>()): Map<string, { kind: Kind; spec: string }> {
  const walk = (dir: string) => {
    for (const name of readdirSync(dir)) {
      if (name === "node_modules") continue;
      const p = path.join(dir, name);
      if (statSync(p).isDirectory()) walk(p);
      else if (name.endsWith(".spec.ts")) {
        const src = readFileSync(p, "utf8");
        const spec = path.relative(epicsDir, p);
        for (const m of src.matchAll(/tc(?:\.(manual|todo|fixme|blocked))?\(\s*"(TC-[0-9.]+-[PN]\d+)"/g)) {
          const kind: Kind = m[1] === "manual" ? "Manual" : m[1] === "todo" ? "Todo" : m[1] === "fixme" ? "Fixme" : m[1] === "blocked" ? "Blocked" : "Automated";
          into.set(m[2], { kind, spec });
        }
      }
    }
  };
  if (existsSync(epicsDir)) walk(epicsDir);
  return into;
}

export function lastRun(resultsFile: string): { at: string; results: Map<string, { status: string; note: string }> } {
  const results = new Map<string, { status: string; note: string }>();
  if (!existsSync(resultsFile)) return { at: "", results };
  const j = JSON.parse(readFileSync(resultsFile, "utf8")) as { finishedAt?: string; results?: { id: string; status: string; actual?: string; error?: string }[] };
  for (const r of j.results ?? []) results.set(r.id, { status: r.status, note: r.actual ?? r.error ?? "" });
  return { at: j.finishedAt ?? "", results };
}

// ---------------------------------------------------------------------------------------------
/**
 * Every `EP-nn.ts` (or `.mjs` / `.js`) in `dir`, sorted, each a default-exported `Change`. Files from
 * another repository (OMNI's) are plain objects of the same shape; nothing is imported from here.
 * `only` (QA_PLAN_ONLY=EP-09,EP-10) validates a subset while other change files are being written.
 */
export async function loadChanges(dir: string, opts: { only?: string[]; label?: string } = {}): Promise<Change[]> {
  if (!existsSync(dir)) return [];
  const only = opts.only ?? [];
  const files = readdirSync(dir)
    .filter((f) => /^EP-\d\d\.(ts|mjs|js)$/.test(f))
    .filter((f) => !only.length || only.includes(f.replace(/\.(ts|mjs|js)$/, "")))
    .sort();
  const out: Change[] = [];
  for (const f of files) {
    const mod = (await import(pathToFileURL(path.join(dir, f)).href)) as { default: Change };
    const where = opts.label ? `${opts.label}/${f}` : f;
    if (!mod.default?.epic) fail(`${where}: no default export with an epic`);
    if (`${mod.default.epic}` !== f.replace(/\.(ts|mjs|js)$/, "")) fail(`${where}: declares epic ${mod.default.epic}`);
    out.push(mod.default);
  }
  return out;
}

// ---------------------------------------------------------------------------------------------
export interface Index {
  epics: Map<string, number>;
  stories: Map<string, number>;
  scenarios: Map<string, number>;
  cases: Map<string, number>;
}

export interface Sheets {
  epics: Worksheet;
  stories: Worksheet;
  scenarios: Worksheet;
  cases: Worksheet;
}

export function sheetsOf(wb: ExcelJS.Workbook): Sheets {
  return {
    epics: wb.getWorksheet("Epics") ?? fail("no Epics"),
    stories: wb.getWorksheet("Stories") ?? fail("no Stories"),
    scenarios: wb.getWorksheet("Scenarios") ?? fail("no Scenarios"),
    cases: wb.getWorksheet("TestCases") ?? fail("no TestCases"),
  };
}

export function index(ws: Worksheet): Map<string, number> {
  const m = new Map<string, number>();
  ws.eachRow((row, n) => {
    if (n > 1) {
      const id = text(row.getCell(1)).trim();
      if (id) m.set(id, n);
    }
  });
  return m;
}

export function indexAll(s: Sheets): Index {
  return { epics: index(s.epics), stories: index(s.stories), scenarios: index(s.scenarios), cases: index(s.cases) };
}

/** The row number after the last row whose column `c` equals `value`, or null. */
export function afterLast(ws: Worksheet, c: number, value: string): number | null {
  let last: number | null = null;
  ws.eachRow((row, n) => {
    if (n > 1 && text(row.getCell(c)).trim() === value) last = n;
  });
  return last == null ? null : last + 1;
}

/** The row number before which an id sorts, among rows whose column `c` equals `value`, else null. */
function beforeFirstGreater(ws: Worksheet, id: string): number | null {
  let at: number | null = null;
  ws.eachRow((row, n) => {
    if (n > 1 && at == null && text(row.getCell(1)).trim() > id) at = n;
  });
  return at;
}

type CellIn = string | number | null | { formula: string };

/** Insert a row whose cells are given by column number. */
export function insertRow(ws: Worksheet, at: number, cells: Record<number, CellIn>): Row {
  const row = ws.insertRow(at, [], "i");
  for (const [c, v] of Object.entries(cells)) {
    if (v != null && v !== "") row.getCell(Number(c)).value = v as ExcelJS.CellValue;
  }
  row.height = undefined as unknown as number;
  return row;
}

const refs = (s: string) => s.split(/[,;]\s*/).map((x) => x.trim()).filter(Boolean);

export interface ValidateOptions {
  /** what the base workbook is called in messages: "0.11", "0.12" */
  base: string;
  /** components a case may name */
  components?: readonly string[];
  /** surfaces a case may name */
  surfaces?: readonly string[];
}

const DEFAULT_COMPONENTS = ["Gateway", "Control Panel", "Cross-component"] as const;
const DEFAULT_SURFACES = ["SMPP", "HTTP", "Ops", "CLI", "Panel", "Portal", "API", "Host"] as const;

/** The rules every change list obeys; throws with every problem at once. */
export function validate(changes: Change[], ix: Index, opts: ValidateOptions): void {
  const components = new Set<string>(opts.components ?? DEFAULT_COMPONENTS);
  const surfaces = new Set<string>(opts.surfaces ?? DEFAULT_SURFACES);
  const newEpics = new Set<string>();
  const newStories = new Set<string>();
  const newScen = new Set<string>();
  const newCases = new Map<string, CaseRow>();
  const all = (id: string) => ix.epics.has(id) || ix.stories.has(id) || ix.scenarios.has(id) || ix.cases.has(id) || newEpics.has(id) || newStories.has(id) || newScen.has(id) || newCases.has(id);
  const problems: string[] = [];
  for (const ch of changes) {
    if (!/^EP-\d\d$/.test(ch.epic)) problems.push(`${ch.epic}: bad epic id`);
    if (!ix.epics.has(ch.epic)) {
      if (!ch.epicName) problems.push(`${ch.epic}: a new epic needs epicName (and epicComponent, epicDescription)`);
      newEpics.add(ch.epic);
    }
    for (const s of ch.stories ?? []) {
      if (!/^US-\d\d\.\d\d$/.test(s.id) || s.epic !== `EP-${s.id.slice(3, 5)}` || s.epic !== ch.epic) problems.push(`${s.id}: bad id or epic`);
      if (ix.stories.has(s.id) || newStories.has(s.id)) problems.push(`${s.id}: already exists`);
      if (!s.story || !s.acceptance) problems.push(`${s.id}: story and acceptance are required`);
      newStories.add(s.id);
    }
    for (const s of ch.scenarios ?? []) {
      if (!/^SC-\d\d\.\d\d\.\d\d$/.test(s.id) || s.story !== `US-${s.id.slice(3, 8)}` || s.epic !== ch.epic) problems.push(`${s.id}: bad id, story or epic`);
      if (!ix.stories.has(s.story) && !newStories.has(s.story)) problems.push(`${s.id}: story ${s.story} does not exist`);
      if (ix.scenarios.has(s.id) || newScen.has(s.id)) problems.push(`${s.id}: already exists`);
      if (!/Given[\s\S]*When[\s\S]*Then/.test(s.gwt)) problems.push(`${s.id}: needs Given / When / Then`);
      newScen.add(s.id);
    }
    for (const c of ch.cases ?? []) {
      if (!/^TC-\d\d\.\d\d\.\d\d-[PN]\d\d$/.test(c.id) || c.scenario !== `SC-${c.id.slice(3, 11)}` || c.story !== `US-${c.id.slice(3, 8)}` || c.epic !== ch.epic) problems.push(`${c.id}: bad id or parents`);
      if (!ix.scenarios.has(c.scenario) && !newScen.has(c.scenario)) problems.push(`${c.id}: scenario ${c.scenario} does not exist`);
      if (ix.cases.has(c.id) || newCases.has(c.id)) problems.push(`${c.id}: already exists`);
      if ((c.type === "Positive") !== c.id.includes("-P")) problems.push(`${c.id}: type does not match the id`);
      if (!c.steps || !c.expected || !c.oracle) problems.push(`${c.id}: steps, expected and oracle are required`);
      if (c.priority === "P0" && !c.antiVacuity) problems.push(`${c.id}: a P0 needs an anti-vacuity check`);
      if (!components.has(c.component)) problems.push(`${c.id}: component '${c.component}' is not one of ${[...components].join(", ")}`);
      if (!surfaces.has(c.surface)) problems.push(`${c.id}: surface '${c.surface}' is not one of ${[...surfaces].join(", ")}`);
      if (!c.changeNote) problems.push(`${c.id}: changeNote (the release) is required`);
      newCases.set(c.id, c);
    }
  }
  //numbering: contiguous per scenario and letter, counting the base workbook's rows
  const seq = new Map<string, number[]>();
  for (const id of [...ix.cases.keys(), ...newCases.keys()]) {
    const key = id.slice(0, 11) + id.slice(11, 13);
    (seq.get(key) ?? seq.set(key, []).get(key)!).push(Number(id.slice(13)));
  }
  for (const [key, nums] of seq) {
    nums.sort((a, b) => a - b);
    nums.forEach((n, i) => {
      if (n !== i + 1) problems.push(`${key}: numbering is not contiguous (${nums.join(",")})`);
    });
  }
  for (const ch of changes) {
    for (const u of ch.updates ?? []) if (!all(u.id) || newCases.has(u.id) || newScen.has(u.id) || newStories.has(u.id)) problems.push(`update ${u.id}: not a ${opts.base} row`);
    for (const r of ch.retire ?? []) if (!ix.cases.has(r.id) && !ix.scenarios.has(r.id) && !ix.stories.has(r.id)) problems.push(`retire ${r.id}: not a ${opts.base} row`);
    for (const rw of ch.rewrites ?? []) {
      try { new RegExp(rw.pattern, rw.flags ?? "g"); } catch (e) { problems.push(`rewrite /${rw.pattern}/: ${(e as Error).message}`); }
      if (!rw.changeNote) problems.push(`rewrite /${rw.pattern}/: changeNote is required`);
    }
    for (const s of ch.scenarios ?? []) for (const ref of [s.related, s.dependsOn]) for (const id of refs(ref)) if (!all(id)) problems.push(`${s.id}: reference ${id} does not exist`);
    for (const c of ch.cases ?? []) for (const id of refs(c.related)) if (!all(id) && !/^I\d$/.test(id)) problems.push(`${c.id}: reference ${id} does not exist`);
  }
  if (problems.length) fail(`change list has ${problems.length} problem(s):\n  ${[...new Set(problems)].join("\n  ")}`);
}

// ---------------------------------------------------------------------------------------------
export interface Applied {
  epics: number;
  stories: number;
  scenarios: number;
  cases: number;
  updates: number;
  rewritten: number;
  retired: number;
  focus: { item: string; change: string; scenarios: string; risk: string }[];
}

export function emptyApplied(): Applied {
  return { epics: 0, stories: 0, scenarios: 0, cases: 0, updates: 0, rewritten: 0, retired: 0, focus: [] };
}

/**
 * Insert every change's new epics, stories, scenarios and cases under their parent (so the sheets
 * stay in id order), marking them in `target`'s columns.
 */
export function applyNew(s: Sheets, changes: Change[], ix: Index, target: ChangeTarget, out: Applied = emptyApplied()): Applied {
  const statusValidation = s.cases.getRow(2).getCell(TC.status).dataValidation;
  for (const ch of changes) {
    let epicRow = ix.epics.get(ch.epic);
    if (epicRow == null) {
      const at = beforeFirstGreater(s.epics, ch.epic) ?? s.epics.rowCount + 1;
      insertRow(s.epics, at, { [EPIC.id]: ch.epic, [EPIC.epic]: ch.epicName ?? ch.epic, [EPIC.component]: ch.epicComponent ?? "", [EPIC.description]: ch.epicDescription ?? "" });
      const row = s.epics.getRow(at);
      row.eachCell({ includeEmpty: true }, (cell) => {
        cell.font = { name: "Arial", size: 9 };
        cell.alignment = { vertical: "top", wrapText: true };
      });
      ix.epics = index(s.epics);
      epicRow = ix.epics.get(ch.epic)!;
      out.epics++;
    } else if (ch.epicDescription) {
      s.epics.getRow(epicRow).getCell(EPIC.description).value = ch.epicDescription;
    }
    for (const st of ch.stories ?? []) {
      const at = afterLast(s.stories, STORY.epic, st.epic) ?? s.stories.rowCount + 1;
      insertRow(s.stories, at, storyCells(st, target));
      out.stories++;
    }
    for (const sc of ch.scenarios ?? []) {
      const at = afterLast(s.scenarios, SCEN.story, sc.story) ?? afterLast(s.scenarios, SCEN.epic, sc.epic) ?? s.scenarios.rowCount + 1;
      insertRow(s.scenarios, at, scenarioCells(sc, target));
      out.scenarios++;
    }
    for (const c of ch.cases ?? []) {
      const at = afterLast(s.cases, TC.scenario, c.scenario) ?? afterLast(s.cases, TC.story, c.story) ?? afterLast(s.cases, TC.epic, c.epic) ?? s.cases.rowCount + 1;
      const row = insertRow(s.cases, at, caseCells(c, target));
      if (statusValidation) row.getCell(TC.status).dataValidation = statusValidation;
      out.cases++;
    }
    out.focus.push(...(ch.focus ?? []));
  }
  return out;
}

function storyCells(st: StoryRow, target: ChangeTarget): Record<number, CellIn> {
  return {
    [STORY.id]: st.id, [STORY.epic]: st.epic, [STORY.story]: st.story, [STORY.asA]: st.asA, [STORY.iWant]: st.iWant, [STORY.soThat]: st.soThat,
    [STORY.acceptance]: st.acceptance, [STORY.configKeys]: st.configKeys, [STORY.observable]: st.observable, [STORY.newIn011]: "N",
    [STORY.automated]: st.automated || "—", [target.storyChanged]: st.changed,
  };
}

function scenarioCells(sc: ScenarioRow, target: ChangeTarget): Record<number, CellIn> {
  return {
    [SCEN.id]: sc.id, [SCEN.story]: sc.story, [SCEN.epic]: sc.epic, [SCEN.scenario]: sc.scenario, [SCEN.gwt]: sc.gwt,
    [SCEN.preconditions]: sc.preconditions, [SCEN.rig]: sc.rig, [SCEN.related]: sc.related, [SCEN.dependsOn]: sc.dependsOn,
    [SCEN.newIn011]: "N", [target.scenChanged]: sc.changed,
  };
}

function caseCells(c: CaseRow, target: ChangeTarget): Record<number, CellIn> {
  return {
    [TC.id]: c.id, [TC.scenario]: c.scenario, [TC.story]: c.story, [TC.epic]: c.epic, [TC.type]: c.type, [TC.title]: c.title,
    [TC.steps]: c.steps, [TC.testData]: c.testData, [TC.expected]: c.expected, [TC.oracle]: c.oracle, [TC.antiVacuity]: c.antiVacuity,
    [TC.priority]: c.priority, [TC.component]: c.component, [TC.newIn011]: "N", [TC.automated]: c.automated, [TC.related]: c.related,
    [TC.status]: "Not run", [TC.surface]: c.surface, [target.tcChanged]: c.changed, [target.tcNote]: c.changeNote,
  };
}

/** A content column of the sheet an id lives on, by its change-file key. */
function contentCol(id: string, key: string): number | null {
  const k = key as never;
  if (id.startsWith("TC-")) return key in TC && !["changed", "changeNote", "changed015", "changeNote015"].includes(key) ? TC[k] : null;
  if (id.startsWith("SC-")) return key in SCEN && !["changed", "changed015"].includes(key) ? SCEN[k] : null;
  if (id.startsWith("US-")) return key in STORY && !["changed", "changed015"].includes(key) ? STORY[k] : null;
  return null;
}

function sheetOf(s: Sheets, id: string): Worksheet {
  return id.startsWith("TC-") ? s.cases : id.startsWith("SC-") ? s.scenarios : s.stories;
}

function rowOf(ix: Index, id: string): number | undefined {
  return ix.cases.get(id) ?? ix.scenarios.get(id) ?? ix.stories.get(id);
}

/** Mark a base row Updated (unless this release made it New) and add the note to a TC's note. */
function markUpdated(s: Sheets, id: string, rowNo: number, target: ChangeTarget, note: string): void {
  const ws = sheetOf(s, id);
  const c = id.startsWith("TC-") ? target.tcChanged : id.startsWith("SC-") ? target.scenChanged : target.storyChanged;
  const cell = ws.getRow(rowNo).getCell(c);
  if (text(cell) !== "New") cell.value = "Updated";
  if (id.startsWith("TC-")) {
    const n = ws.getRow(rowNo).getCell(target.tcNote);
    const prior = target.appendNotes ? text(n) : "";
    if (!prior.split(" | ").includes(note)) n.value = prior ? `${prior} | ${note}` : note;
  }
}

/**
 * Updates (fields by key), rewrites (one pattern over every plan column of every row) and
 * retirements, after `applyNew` has inserted the new rows.
 */
export function applyEdits(s: Sheets, changes: Change[], target: ChangeTarget, out: Applied = emptyApplied()): Applied {
  const ix = indexAll(s);
  for (const ch of changes) {
    for (const u of ch.updates ?? []) {
      const rowNo = rowOf(ix, u.id) ?? fail(`update ${u.id}: not found`);
      for (const [key, value] of Object.entries(u.set)) {
        const c = contentCol(u.id, key) ?? fail(`update ${u.id}: '${key}' is not a column of that sheet`);
        sheetOf(s, u.id).getRow(rowNo).getCell(c).value = value as ExcelJS.CellValue;
      }
      markUpdated(s, u.id, rowNo, target, u.changeNote);
      out.updates++;
    }
  }
  // rewrites run after the explicit updates, so a rewritten phrase inside an updated field is caught too
  const rewrittenIds = new Set<string>();
  for (const ch of changes) {
    for (const rw of ch.rewrites ?? []) {
      const re = new RegExp(rw.pattern, rw.flags ?? "g");
      const sweep = (ws: Worksheet, keys: readonly string[], cols: Record<string, number>) => {
        ws.eachRow((row, n) => {
          if (n === 1) return;
          const id = text(row.getCell(1)).trim();
          if (!id) return;
          //a rewrite carries the base workbook's rows forward; this release's own rows are written new
          const changedCol = ws === s.cases ? target.tcChanged : ws === s.scenarios ? target.scenChanged : target.storyChanged;
          if (text(row.getCell(changedCol)) === "New") return;
          let touched = false;
          for (const k of keys) {
            const cell = row.getCell(cols[k]);
            const before = text(cell);
            if (!before) continue;
            re.lastIndex = 0;
            if (!re.test(before)) continue;
            re.lastIndex = 0;
            cell.value = before.replace(re, rw.replace);
            touched = true;
          }
          if (touched) {
            markUpdated(s, id, n, target, rw.changeNote);
            rewrittenIds.add(id);
          }
        });
      };
      sweep(s.stories, STORY_TEXT, STORY);
      sweep(s.scenarios, SCEN_TEXT, SCEN);
      sweep(s.cases, TC_TEXT, TC);
    }
  }
  out.rewritten += rewrittenIds.size;
  for (const ch of changes) {
    for (const r of ch.retire ?? []) {
      const rowNo = rowOf(ix, r.id) ?? fail(`retire ${r.id}: not found`);
      const ws = sheetOf(s, r.id);
      const row = ws.getRow(rowNo);
      if (r.id.startsWith("TC-")) {
        row.getCell(target.tcChanged).value = "Retired";
        row.getCell(target.tcNote).value = r.reason;
        row.getCell(TC.status).value = "N/A";
      } else {
        row.getCell(r.id.startsWith("SC-") ? target.scenChanged : target.storyChanged).value = "Retired";
      }
      row.eachCell({ includeEmpty: true }, (cell) => {
        cell.font = { ...(cell.font ?? {}), color: { argb: "FF888888" }, strike: false };
      });
      out.retired++;
    }
  }
  return out;
}

// ---------------------------------------------------------------------------------------------
export function header(ws: Worksheet, c: number, title: string, width: number) {
  const h = ws.getRow(1).getCell(c);
  h.value = title;
  const ref = ws.getRow(1).getCell(1);
  h.style = { ...ref.style };
  ws.getColumn(c).width = width;
}

export function fillAutomation(s: Sheets, auto: Map<string, { kind: Kind; spec: string }>, run: ReturnType<typeof lastRun>, extraCols: number[] = []) {
  const counts = { Automated: 0, Todo: 0, Manual: 0, Fixme: 0, Blocked: 0, none: 0 };
  s.cases.eachRow((row, n) => {
    if (n === 1) return;
    const id = text(row.getCell(TC.id)).trim();
    const a = auto.get(id);
    row.getCell(TC.automation).value = a ? a.kind : "";
    if (a) counts[a.kind]++;
    else counts.none++;
    //a previous build's run is not this build's: the columns say what results.json says, or nothing
    const r = run.results.get(id);
    row.getCell(TC.lastRun).value = r ? r.status : null;
    row.getCell(TC.lastRunNote).value = r ? r.note.slice(0, 500) : null;
    for (const c of [TC.surface, TC.changed, TC.changeNote, TC.automation, TC.lastRun, TC.lastRunNote, ...extraCols]) {
      row.getCell(c).font = { name: "Arial", size: 9 };
      row.getCell(c).alignment = { vertical: "top", wrapText: true };
    }
  });
  return counts;
}

/** Whole-column formulas, so a row added by hand later still counts. `changed` is the release's column. */
export function rewriteCountFormulas(wb: ExcelJS.Workbook, epicChangedCols: { epicCol: number; tcCol: number }[] = [{ epicCol: EPIC.nChanged, tcCol: TC.changed }]) {
  const f = (formula: string) => ({ formula }) as ExcelJS.CellValue;
  const epics = wb.getWorksheet("Epics")!;
  epics.eachRow((row, n) => {
    if (n === 1) return;
    const a = `A${n}`;
    row.getCell(EPIC.nStories).value = f(`COUNTIF(Stories!$B:$B,${a})`);
    row.getCell(EPIC.nScenarios).value = f(`COUNTIF(Scenarios!$C:$C,${a})`);
    row.getCell(EPIC.nTcs).value = f(`COUNTIF(TestCases!$D:$D,${a})`);
    row.getCell(EPIC.nPos).value = f(`COUNTIFS(TestCases!$D:$D,${a},TestCases!$E:$E,"Positive")`);
    row.getCell(EPIC.nNeg).value = f(`COUNTIFS(TestCases!$D:$D,${a},TestCases!$E:$E,"Negative")`);
    row.getCell(EPIC.nP0).value = f(`COUNTIFS(TestCases!$D:$D,${a},TestCases!$L:$L,"P0")`);
    row.getCell(EPIC.nNew011).value = f(`COUNTIFS(TestCases!$D:$D,${a},TestCases!$N:$N,"Y")`);
    for (const { epicCol, tcCol } of epicChangedCols) {
      row.getCell(epicCol).value = f(`COUNTIFS(TestCases!$D:$D,${a},TestCases!$${col(tcCol)}:$${col(tcCol)},"<>")`);
    }
    row.getCell(EPIC.nAuto).value = f(`COUNTIFS(TestCases!$D:$D,${a},TestCases!$${col(TC.automation)}:$${col(TC.automation)},"Automated")`);
    row.getCell(EPIC.nTodo).value = f(`COUNTIFS(TestCases!$D:$D,${a},TestCases!$${col(TC.automation)}:$${col(TC.automation)},"Todo")`);
    row.getCell(EPIC.nManual).value = f(`COUNTIFS(TestCases!$D:$D,${a},TestCases!$${col(TC.automation)}:$${col(TC.automation)},"Manual")`);
  });
  const stories = wb.getWorksheet("Stories")!;
  stories.eachRow((row, n) => {
    if (n === 1) return;
    row.getCell(STORY.nScenarios).value = f(`COUNTIF(Scenarios!$B:$B,A${n})`);
    row.getCell(STORY.nTcs).value = f(`COUNTIF(TestCases!$C:$C,A${n})`);
  });
  const scen = wb.getWorksheet("Scenarios")!;
  scen.eachRow((row, n) => {
    if (n === 1) return;
    row.getCell(SCEN.nTcs).value = f(`COUNTIF(TestCases!$B:$B,A${n})`);
    row.getCell(SCEN.nPos).value = f(`COUNTIFS(TestCases!$B:$B,A${n},TestCases!$E:$E,"Positive")`);
    row.getCell(SCEN.nNeg).value = f(`COUNTIFS(TestCases!$B:$B,A${n},TestCases!$E:$E,"Negative")`);
  });
}

export function fillSheet(ws: Worksheet, rows: (string | number | { formula: string })[][], startRow = 2) {
  //clear everything below the header, then write
  const last = ws.rowCount;
  if (last >= startRow) ws.spliceRows(startRow, last - startRow + 1);
  rows.forEach((r, i) => {
    const row = ws.getRow(startRow + i);
    r.forEach((v, c) => {
      row.getCell(c + 1).value = v as ExcelJS.CellValue;
      row.getCell(c + 1).font = { name: "Arial", size: 9 };
      row.getCell(c + 1).alignment = { vertical: "top", wrapText: true };
    });
    row.commit();
  });
}

export function readmeSetter(readme: Worksheet) {
  return (label: string, value: string) => {
    let found = false;
    readme.eachRow((row) => {
      if (text(row.getCell(1)) === label) {
        row.getCell(2).value = value;
        found = true;
      }
    });
    if (!found) {
      const row = readme.addRow([label, value]);
      row.getCell(1).font = { name: "Arial", size: 9, bold: true };
      row.getCell(2).font = { name: "Arial", size: 9 };
      row.getCell(2).alignment = { vertical: "top", wrapText: true };
    }
  };
}

/**
 * Newest release first; rows whose item is not a plain version ("0.12.x (never in the workbook)")
 * go after every real release rather than sorting above the newest by their letter.
 */
export function sortFocus<T extends { item: string }>(focus: T[]): T[] {
  const releaseKey = (item: string) => {
    const m = /^(\d+)\.(\d+)\.(\d+)(?:\.(\d+))?\s*$/.exec(item);
    return m ? [1, Number(m[1]), Number(m[2]), Number(m[3]), Number(m[4] ?? 0)] : [0, 0, 0, 0, 0];
  };
  return focus.sort((a, b) => {
    const ka = releaseKey(a.item);
    const kb = releaseKey(b.item);
    for (let i = 0; i < ka.length; i++) if (ka[i] !== kb[i]) return kb[i] - ka[i];
    return a.item.localeCompare(b.item);
  });
}

/** A Focus sheet placed before `before`, with the plan's header style. */
export function addFocusSheet(wb: ExcelJS.Workbook, name: string, before: Worksheet, rows: { item: string; change: string; scenarios: string; risk: string }[]): Worksheet {
  const fx = wb.addWorksheet(name, { views: [{ state: "frozen", ySplit: 1 }] });
  wb.worksheets.splice(wb.worksheets.indexOf(fx), 1);
  wb.worksheets.splice(wb.worksheets.indexOf(before), 0, fx);
  const fxHeader = fx.getRow(1);
  ["Release", "Change", "Scenarios", "Risk / note"].forEach((h, i) => {
    fxHeader.getCell(i + 1).value = h;
    fxHeader.getCell(i + 1).style = { ...before.getRow(1).getCell(1).style };
  });
  fxHeader.height = 31.5;
  [10, 90, 36, 50].forEach((w, i) => (fx.getColumn(i + 1).width = w));
  fillSheet(fx, sortFocus(rows).map((r) => [r.item, r.change, r.scenarios, r.risk]));
  fx.autoFilter = { from: "A1", to: `D${Math.max(2, fx.rowCount)}` };
  return fx;
}

/** exceljs writes the tabs by orderNo, which its typings leave off Worksheet. */
export function orderSheets(wb: ExcelJS.Workbook, order: string[]) {
  for (const ws of wb.worksheets) (ws as unknown as { orderNo: number }).orderNo = order.indexOf(ws.name) < 0 ? 99 : order.indexOf(ws.name);
}

export function addRigRows(rigs: Worksheet, rows: string[][]) {
  for (const r of rows) {
    const row = rigs.addRow(r);
    row.eachCell((cell) => {
      cell.font = { name: "Arial", size: 9 };
      cell.alignment = { vertical: "top", wrapText: true };
    });
  }
  rigs.autoFilter = { from: "A1", to: `C${rigs.rowCount}` };
}
