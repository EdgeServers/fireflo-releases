import { GatewayError, gqlData } from "@/lib/gateway-graphql";
import { DEBIT } from "@/lib/gateway-queries";
import { debitRefusal, type DebitAnswer, type DebitInput } from "@/lib/balance-types";

/**
 * Taking credit away from a prepaid account (gateway 0.15.3).
 *
 * <p><strong>Through the gateway, never a ledger row written here.</strong> A top-up can be a row the
 * gateway picks up on its next poll because adding credit cannot fail for want of it. A debit can:
 * the gateway releases the credit its running nodes hold, takes the amount only if the balance then
 * covers it, refuses a postpaid account, and writes the one `DEBIT` row in the same transaction. One
 * writer and one set of checks, the same ones OMNI's platform `debit` goes through -- which is why
 * this calls that mutation with the admin token rather than repeating any of it.
 *
 * <p>Server-only: the admin token is read from the environment.
 */

/** A refused debit, with the status the route answers and the gateway's sentence. */
export class DebitRefused extends Error {
  readonly status: number;

  constructor(status: number, message: string) {
    super(message);
    this.name = "DebitRefused";
    this.status = status;
  }
}

/**
 * Sends one debit and answers what the gateway did, `duplicate` included.
 *
 * @param input already passed through `validateDebit`
 * @param currency the platform currency the gateway checks the debit against
 * @throws DebitRefused for every refusal, carrying the gateway's own sentence
 */
export async function debitAccount(accountId: string, input: DebitInput, currency: string): Promise<DebitAnswer> {
  try {
    const answer = await gqlData<DebitAnswer>({
      query: DEBIT,
      auth: "admin",
      variables: {
        account: accountId,
        input: {
          amount: input.amount.trim(),
          currency,
          reference: input.ref.trim(),
          reason: input.reason.trim(),
        },
      },
    });
    return {
      account: answer?.account ?? accountId,
      amount: String(answer?.amount ?? input.amount.trim()),
      reference: answer?.reference ?? input.ref.trim(),
      duplicate: !!answer?.duplicate,
      balanceAfter: answer?.balanceAfter == null ? null : String(answer.balanceAfter),
    };
  } catch (err) {
    if (err instanceof GatewayError) {
      const refused = debitRefusal(err.status, err.code, err.message);
      throw new DebitRefused(refused.status, refused.error);
    }
    throw err;
  }
}
