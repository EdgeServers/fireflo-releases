import { test } from "node:test";
import assert from "node:assert/strict";
import {
  GRPC_DEFAULT_PORT,
  GRPC_RECEIPT_FIELDS,
  GRPC_SEND_FIELDS,
  GRPC_SERVICES,
  GRPC_STATUS_ROWS,
  grpcAddressFrom,
  grpcurlExample,
  pythonExample,
} from "./grpc-api-docs.ts";
import { DLR_FIELDS, ENDPOINTS } from "./api-catalogue.ts";

test("the published address: scheme decides TLS, a missing port is 443 or 8090", () => {
  assert.deepEqual(grpcAddressFrom({ GATEWAY_GRPC_ADDRESS: "https://grpc.example.com" }), { address: "grpc.example.com:443", tls: true, published: true });
  assert.deepEqual(grpcAddressFrom({ GATEWAY_GRPC_ADDRESS: "https://grpc.example.com:9443/" }), { address: "grpc.example.com:9443", tls: true, published: true });
  assert.deepEqual(grpcAddressFrom({ GATEWAY_GRPC_ADDRESS: "http://10.0.0.5:8090" }), { address: "10.0.0.5:8090", tls: false, published: true });
  assert.deepEqual(grpcAddressFrom({ GATEWAY_GRPC_ADDRESS: "gw.example.com:8090" }), { address: "gw.example.com:8090", tls: false, published: true });
  assert.deepEqual(grpcAddressFrom({ GATEWAY_GRPC_ADDRESS: "gw.example.com" }), { address: `gw.example.com:${GRPC_DEFAULT_PORT}`, tls: false, published: true });
});

test("unpublished: the REST host on the default port, plaintext, said to be a guess", () => {
  assert.deepEqual(grpcAddressFrom({ GATEWAY_API_URL: "https://api.example.com/" }), { address: "api.example.com:8090", tls: false, published: false });
  assert.deepEqual(grpcAddressFrom({ GATEWAY_API_URL: "http://[::1]:8081" }), { address: "[::1]:8090", tls: false, published: false });
  assert.equal(grpcAddressFrom({}), null);
  assert.equal(grpcAddressFrom({ GATEWAY_API_URL: "not a url" }), null);
  //the published one wins
  assert.equal(grpcAddressFrom({ GATEWAY_GRPC_ADDRESS: "grpc.example.com:8090", GATEWAY_API_URL: "https://api.example.com" })!.published, true);
});

test("the Send table mirrors every REST send field, under its proto name", () => {
  const send = ENDPOINTS.find((e) => e.id === "send")!;
  const rest = new Set(GRPC_SEND_FIELDS.map((f) => f.rest));
  for (const f of send.fields) {
    assert.ok(rest.has(f.name), `REST field ${f.name} has a gRPC row`);
  }
  //proto names are snake_case and never REST's hyphenated spelling
  for (const f of GRPC_SEND_FIELDS) {
    assert.match(f.proto, /^[a-z][a-z_]*$/, f.proto);
  }
  assert.ok(GRPC_SEND_FIELDS.some((f) => f.proto === "client_ref"));
  assert.equal(GRPC_SEND_FIELDS.find((f) => f.proto === "to")!.required, true);
});

test("the receipt table carries every webhook field plus ack_token and delivery_count", () => {
  const names = GRPC_RECEIPT_FIELDS.flatMap((f) => f.name.split(", "));
  for (const f of DLR_FIELDS) {
    assert.ok(names.includes(f.name), `webhook field ${f.name} is on the gRPC receipt`);
  }
  assert.ok(names.includes("ack_token"));
  assert.ok(names.includes("delivery_count"));
});

test("the status table follows the design's mapping", () => {
  const by = (code: string) => GRPC_STATUS_ROWS.find((r) => r.code.split(/[,;]\s*/).includes(code) || r.code.startsWith(code));
  assert.equal(by("INSUFFICIENT_CREDIT")!.grpc, "FAILED_PRECONDITION");
  assert.equal(by("RATE_LIMITED")!.grpc, "RESOURCE_EXHAUSTED");
  assert.equal(by("OUTCOME_UNKNOWN")!.grpc, "UNKNOWN", "never UNAVAILABLE: client retry policies must not resend");
  assert.equal(by("QUEUE_FULL")!.grpc, "UNAVAILABLE");
  assert.equal(by("CANNOT_SEND")!.grpc, "INTERNAL");
  assert.equal(by("SESSION_EXPIRED")!.grpc, "UNAUTHENTICATED");
  assert.equal(by("AUTH_FAILED")!.grpc, "UNAUTHENTICATED");
  assert.equal(by("AUTHORIZATION_FAILED")!.grpc, "PERMISSION_DENIED");
  assert.equal(by("GRPC_DISABLED")!.grpc, "UNAVAILABLE");
  assert.equal(by("RECEIPTS_DISABLED")!.grpc, "FAILED_PRECONDITION");
  assert.equal(by("NO_ROUTE")!.grpc, "PERMISSION_DENIED");
});

test("the examples use the address, the login, plaintext only without TLS, and never a password", () => {
  const plain = { address: "gw.example.com:8090", tls: false, published: true };
  const tls = { address: "grpc.example.com:443", tls: true, published: true };
  const curl = grpcurlExample(plain, "sunrise-http", "919216217231");
  assert.match(curl, /grpcurl -plaintext/);
  assert.match(curl, /gw\.example\.com:8090 fireflo\.v1\.AuthService\/Login/);
  assert.match(curl, /fireflo\.v1\.SendService\/Send/);
  assert.match(curl, /fireflo\.v1\.ReceiptService\/Pull/);
  assert.match(curl, /fireflo\.v1\.ReceiptService\/Ack/);
  assert.match(curl, /"system_id":"sunrise-http"/);
  assert.match(curl, /\$PASSWORD/);
  assert.doesNotMatch(grpcurlExample(tls, "x", "1"), /-plaintext/);

  const py = pythonExample(plain, "sunrise-http", "919216217231");
  assert.match(py, /grpc\.insecure_channel\("gw\.example\.com:8090"\)/);
  assert.match(py, /SMS_PASSWORD/);
  assert.match(py, /Subscribe/);
  assert.match(py, /Ack/);
  assert.match(pythonExample(tls, "x", "1"), /grpc\.secure_channel\("grpc\.example\.com:443", grpc\.ssl_channel_credentials\(\)\)/);
});

test("customer text names no internal class, table or configuration key", () => {
  const text = JSON.stringify({ GRPC_SEND_FIELDS, GRPC_STATUS_ROWS, GRPC_RECEIPT_FIELDS, GRPC_SERVICES })
    + grpcurlExample({ address: "h:1", tls: false, published: true }, "l", "1")
    + pythonExample({ address: "h:1", tls: false, published: true }, "l", "1");
  assert.doesNotMatch(text, /smsg\.|dlr_grpc_queue|au\.remotiq|Grpc[A-Z]\w+(Service|Sessions|Interceptor)|SendRequestParser|MessageSubmission/);
  for (const s of GRPC_SERVICES) {
    assert.match(s.name, /^fireflo\.v1\./);
  }
});
