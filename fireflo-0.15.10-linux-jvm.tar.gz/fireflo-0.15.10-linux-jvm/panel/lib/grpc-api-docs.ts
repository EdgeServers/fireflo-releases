/**
 * The gRPC API (gateway 0.15.9), described once for the portal's API reference.
 *
 * <p>The customer half of the gateway's `docs/28-grpc-api.md`: where to connect, how a session
 * works, the Send fields (the REST send table with the proto's names), what each status means, the
 * stream, and the receipt feed. Written from the frozen contract `api/fireflo.proto` (package
 * `fireflo.v1`) and the plan's status table, in the customer's words: no internal names, no
 * configuration keys, nothing a customer could not see on the wire.
 *
 * <p>Database-free and import-free, like `api-catalogue.ts`, so the page and the tests can read it.
 */

/** The port the gateway's installer gives the gRPC listener when an operator switches it on. */
export const GRPC_DEFAULT_PORT = 8090;

/** Where a customer's gRPC client connects, as the portal can know it. */
export interface GrpcAddress {
  /** `host:port`, what grpcurl and every client library take. */
  address: string;
  /** Whether the address speaks TLS; false means plaintext HTTP/2 (`-plaintext`, an insecure channel). */
  tls: boolean;
  /**
   * True when the operator published it (`GATEWAY_GRPC_ADDRESS`). False when it was guessed from the
   * REST address's host and the default port, which the page says rather than presents as fact.
   */
  published: boolean;
}

/**
 * The gRPC address from the panel's environment.
 *
 * <p>`GATEWAY_GRPC_ADDRESS` is `https://host[:port]` for TLS (port 443 when omitted),
 * `http://host:port` for plaintext, or a bare `host:port`, read as plaintext because that is how the
 * gateway's own listener answers when nothing sits in front of it. Unset, the REST address's host
 * with port {@link GRPC_DEFAULT_PORT}, plaintext, marked unpublished. Neither set: null.
 */
export function grpcAddressFrom(env: { GATEWAY_GRPC_ADDRESS?: string; GATEWAY_API_URL?: string }): GrpcAddress | null {
  const raw = (env.GATEWAY_GRPC_ADDRESS ?? "").trim().replace(/\/+$/, "");
  if (raw) {
    const scheme = /^(https?):\/\//i.exec(raw);
    const rest = scheme ? raw.slice(scheme[0].length) : raw;
    const tls = scheme ? scheme[1].toLowerCase() === "https" : false;
    const hostPort = rest.split("/")[0];
    if (!hostPort) {
      return null;
    }
    const hasPort = /:\d+$/.test(hostPort) && !/^\[[^\]]*\]$/.test(hostPort);
    return { address: hasPort ? hostPort : `${hostPort}:${tls ? 443 : GRPC_DEFAULT_PORT}`, tls, published: true };
  }
  const api = (env.GATEWAY_API_URL ?? "").trim();
  if (!api) {
    return null;
  }
  try {
    const host = new URL(api).hostname;
    if (!host) {
      return null;
    }
    const shown = host.includes(":") ? `[${host.replace(/^\[|\]$/g, "")}]` : host;
    return { address: `${shown}:${GRPC_DEFAULT_PORT}`, tls: false, published: false };
  } catch {
    return null;
  }
}

/** The three services, as grpcurl and reflection name them. */
export const GRPC_SERVICES: { name: string; rpcs: string; does: string }[] = [
  { name: "fireflo.v1.AuthService", rpcs: "Login · Logout", does: "Exchange your login and password for a session token." },
  { name: "fireflo.v1.SendService", rpcs: "Send · SendStream", does: "One message per call, or many on one stream." },
  { name: "fireflo.v1.ReceiptService", rpcs: "Subscribe · Pull · Ack", does: "Collect the delivery receipts of your messages." },
];

/** One field of `SendRequest`, beside the REST field it mirrors. */
export interface GrpcSendField {
  /** The proto field name. */
  proto: string;
  /** The proto type. */
  type: string;
  /** The `/secure/send` field it mirrors, or null for none. */
  rest: string | null;
  required: boolean | "either";
  fallback?: string;
  note: string;
}

/**
 * `SendRequest`, field for field the body of `POST /secure/send`.
 *
 * <p>An unset optional field takes the same default as an absent JSON key, and the same rules apply
 * (the same approvals, products, TLV grammar and limits) because both reach the same checks.
 */
export const GRPC_SEND_FIELDS: GrpcSendField[] = [
  { proto: "to", type: "string", rest: "to", required: true, note: "Destination in international format." },
  { proto: "content", type: "string", rest: "content", required: "either", note: "The message text. Give this or hex_content, never both." },
  { proto: "hex_content", type: "string", rest: "hex_content", required: "either", note: "The body as hex octets, decoded with the charset for your coding. An odd length is refused." },
  { proto: "from", type: "string", rest: "from", required: false, fallback: "your login name", note: "Sender ID. Must be one approved for your account." },
  { proto: "coding", type: "int32", rest: "coding", required: false, fallback: "0", note: "SMPP data_coding: 0 default, 8 UCS-2, as REST." },
  { proto: "priority", type: "int32", rest: "priority", required: false, fallback: "0", note: "0 to 3; 0 and 1 are normal, 2 and 3 high." },
  { proto: "validity_period", type: "int32", rest: "validity_period", required: false, note: "Minutes the carrier should keep trying." },
  { proto: "sdt", type: "string", rest: "sdt", required: false, note: "Scheduled delivery time, in the REST format." },
  {
    proto: "dlr",
    type: "bool",
    rest: "dlr",
    required: false,
    fallback: "false",
    note: "true to receive receipts: to dlr_url when you give one, otherwise to your receipt feed (Subscribe / Pull). REST's \"yes\" / \"no\".",
  },
  { proto: "dlr_level", type: "int32", rest: "dlr_level", required: false, fallback: "2", note: "1 progress only, 2 the outcome, 3 both." },
  { proto: "dlr_url", type: "string", rest: "dlr_url", required: false, note: "Receipts for this message are POSTed here instead of the feed — the webhook wins." },
  {
    proto: "custom_tlvs",
    type: "map<string, TlvValue>",
    rest: "custom_tlvs",
    required: false,
    note: "Extra SMPP parameters. Keys as REST (\"0x1401\", \"0x1401:Int8\"); each value is one of string_value, int_value or uint_value.",
  },
  { proto: "client_ref", type: "string", rest: "client_ref", required: false, note: "1 to 64 printable characters. The same reference again returns the first message (duplicate = true) and charges nothing." },
  { proto: "product", type: "string", rest: "product", required: false, fallback: "the product your login carries", note: "Only products your operator has allowed for this login." },
];

/** `SendResponse`, the REST answer's fields. */
export const GRPC_SEND_RESPONSE: { name: string; note: string }[] = [
  { name: "message_id", note: "The id you will see on every receipt (REST messageId)." },
  { name: "duplicate", note: "true when client_ref was seen before: message_id is the first send's, nothing was charged." },
  { name: "price", note: "Decimal string, 4 places, for the whole message." },
  { name: "currency", note: "The currency price is in." },
  { name: "segments", note: "How many parts it was sent as." },
  { name: "unrated", note: "true when no price applied." },
];

/** One row of the status table: what happened, what REST answers, what gRPC answers. */
export interface GrpcStatusRow {
  cause: string;
  http: string;
  grpc: string;
  /** `ErrorDetail.code`, or the notes for OK. */
  code: string;
  /** What the client should do. */
  then: string;
}

/**
 * Every outcome of a send, and of a session, as the gRPC status a client sees.
 *
 * <p>Every non-OK status carries an `ErrorDetail` in its details: the HTTP status REST would have
 * answered, REST's error code and message word for word, the retry delay where there is one, and the
 * offending field.
 */
export const GRPC_STATUS_ROWS: GrpcStatusRow[] = [
  { cause: "Accepted", http: "200", grpc: "OK", code: "—", then: "Keep message_id." },
  { cause: "Same client_ref as before", http: "200", grpc: "OK", code: "duplicate = true", then: "Nothing was sent again or charged." },
  { cause: "A field is missing or wrong", http: "400", grpc: "INVALID_ARGUMENT", code: "the REST message; field names it", then: "Fix the request." },
  { cause: "Balance will not cover it", http: "402", grpc: "FAILED_PRECONDITION", code: "INSUFFICIENT_CREDIT", then: "Top up; nothing was charged." },
  { cause: "Over your account's messages per second", http: "429", grpc: "RESOURCE_EXHAUSTED", code: "RATE_LIMITED, retry_after_seconds", then: "Back off and retry." },
  {
    cause: "Sender ID or wording not approved; product not sold or not allowed; no route",
    http: "403",
    grpc: "PERMISSION_DENIED",
    code: "HEADER_NOT_APPROVED, CONTENT_NOT_APPROVED, PRODUCT_NOT_SOLD, PRODUCT_NOT_ALLOWED, UNRATED, NO_ROUTE",
    then: "Do not retry unchanged.",
  },
  {
    cause: "The gateway is busy, stopping, or cannot reach a carrier",
    http: "503",
    grpc: "UNAVAILABLE",
    code: "QUEUE_FULL, SHUTTING_DOWN, VENDOR_BACKLOG, VENDOR_UNAVAILABLE, DB_UNAVAILABLE; retry_after_seconds",
    then: "Retry after the delay; nothing was charged.",
  },
  {
    cause: "Accepted or not is not known",
    http: "503",
    grpc: "UNKNOWN",
    code: "OUTCOME_UNKNOWN, message_id",
    then: "Retry only with the same client_ref, so a send that did go is not sent twice.",
  },
  { cause: "Accepted and could not be queued", http: "500", grpc: "INTERNAL", code: "CANNOT_SEND", then: "Any charge is reversed; retry." },
  { cause: "No session token, or a malformed one", http: "401", grpc: "UNAUTHENTICATED", code: "MISSING_CREDENTIAL", then: "Login first." },
  { cause: "Session token expired, or issued before a restart", http: "—", grpc: "UNAUTHENTICATED", code: "SESSION_EXPIRED", then: "Login again and resend the call." },
  { cause: "Login refused: unknown login, wrong password, not an HTTP login", http: "403", grpc: "UNAUTHENTICATED", code: "AUTH_FAILED", then: "Check the credential." },
  { cause: "Your address is not in the login's allowed list", http: "403", grpc: "PERMISSION_DENIED", code: "AUTHORIZATION_FAILED", then: "Call from an allowed address." },
  { cause: "gRPC is not switched on for this platform", http: "—", grpc: "UNAVAILABLE", code: "GRPC_DISABLED", then: "Use REST, or ask your operator." },
  { cause: "Receipt calls while the feed is switched off", http: "—", grpc: "FAILED_PRECONDITION", code: "RECEIPTS_DISABLED", then: "Use dlr_url webhooks." },
  { cause: "A message over the size limit (1 MB)", http: "—", grpc: "RESOURCE_EXHAUSTED", code: "raised by the transport", then: "Send it smaller." },
];

/** `ErrorDetail`, packed in every non-OK status and inline in a stream result. */
export const GRPC_ERROR_DETAIL: { name: string; note: string }[] = [
  { name: "http_status", note: "What POST /secure/send would have answered." },
  { name: "code", note: "REST's error code, e.g. RATE_LIMITED, OUTCOME_UNKNOWN, SHUTTING_DOWN." },
  { name: "message", note: "REST's error message, word for word." },
  { name: "retry_after_seconds", note: "When a retry is meaningful; also as google.rpc.RetryInfo." },
  { name: "message_id", note: "On OUTCOME_UNKNOWN: the id the message has if it did go." },
  { name: "field", note: "On INVALID_ARGUMENT: the request field at fault." },
];

/** `Receipt`: the webhook's fields, plus the two the feed adds. */
export const GRPC_RECEIPT_FIELDS: { name: string; note: string }[] = [
  { name: "id", note: "The message_id the send returned." },
  { name: "stat", note: "DELIVRD, UNDELIV, EXPIRED, REJECTD, UNKNOWN, ACCEPTD, ENROUTE…, as the webhook." },
  { name: "level", note: "2 for the outcome, 1 for progress (another receipt follows)." },
  { name: "sub_date, done_date", note: "When you submitted it, and when this receipt was raised, ISO-8601." },
  { name: "to, from", note: "The destination and the sender ID used." },
  { name: "operator_msg_id", note: "The carrier's own reference." },
  { name: "account_id, system_id", note: "The account billed and the login that sent it." },
  { name: "parts", note: "Segment count, when known." },
  { name: "err", note: "The carrier's error code, when it gave one." },
  { name: "ack_token", note: "Send it back in Ack once you have stored the receipt." },
  { name: "delivery_count", note: "1 the first time; more than 1 means this receipt was delivered before and not acknowledged." },
];

/** The examples' credential placeholder, as on the rest of the page: never a real password. */
const PASSWORD = "$PASSWORD";

/** grpcurl, with server reflection: Login, Send, Pull, Ack. */
export function grpcurlExample(where: GrpcAddress, login: string, to: string): string {
  const flag = where.tls ? "" : "-plaintext ";
  const a = where.address;
  return [
    "# 1. Log in once; keep the token",
    `TOKEN=$(grpcurl ${flag}-d '{"system_id":"${login}","password":"'"${PASSWORD}"'"}' \\`,
    `  ${a} fireflo.v1.AuthService/Login | jq -r .sessionToken)`,
    "",
    "# 2. Send; receipts go to your feed (no dlr_url)",
    `grpcurl ${flag}-H "authorization: Bearer $TOKEN" \\`,
    `  -d '{"to":"${to}","content":"Your OTP is 4417.","dlr":true,"client_ref":"order-1001"}' \\`,
    `  ${a} fireflo.v1.SendService/Send`,
    "",
    "# 3. Collect receipts, waiting up to 20 s when there are none",
    `grpcurl ${flag}-H "authorization: Bearer $TOKEN" -d '{"max":100,"wait_seconds":20}' \\`,
    `  ${a} fireflo.v1.ReceiptService/Pull`,
    "",
    "# 4. Acknowledge what you stored",
    `grpcurl ${flag}-H "authorization: Bearer $TOKEN" -d '{"ack_tokens":["<ackToken>"]}' \\`,
    `  ${a} fireflo.v1.ReceiptService/Ack`,
  ].join("\n");
}

/** Python with grpcio and stubs generated from fireflo.proto: Login, Send, then a receipt stream. */
export function pythonExample(where: GrpcAddress, login: string, to: string): string {
  const channel = where.tls
    ? `grpc.secure_channel("${where.address}", grpc.ssl_channel_credentials())`
    : `grpc.insecure_channel("${where.address}")`;
  return `# pip install grpcio grpcio-tools
# python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. fireflo.proto
import os
import grpc
import fireflo_pb2 as pb
import fireflo_pb2_grpc as rpc

channel = ${channel}
auth = rpc.AuthServiceStub(channel)
send = rpc.SendServiceStub(channel)
receipts = rpc.ReceiptServiceStub(channel)

def login():
    reply = auth.Login(pb.LoginRequest(system_id="${login}", password=os.environ["SMS_PASSWORD"]))
    return [("authorization", "Bearer " + reply.session_token)]

md = login()
try:
    sent = send.Send(pb.SendRequest(to="${to}", content="Your OTP is 4417.",
                                    dlr=True, client_ref="order-1001"), metadata=md)
    print(sent.message_id, sent.price, sent.currency)
except grpc.RpcError as e:
    if e.code() == grpc.StatusCode.UNAUTHENTICATED:
        md = login()          # SESSION_EXPIRED: log in again, then resend
    else:
        raise

# Receipts: replays anything unacknowledged first, then live ones
for r in receipts.Subscribe(pb.SubscribeRequest(window=500), metadata=md):
    print(r.id, r.stat, r.level, r.delivery_count)
    receipts.Ack(pb.AckRequest(ack_tokens=[r.ack_token]), metadata=md)`;
}
