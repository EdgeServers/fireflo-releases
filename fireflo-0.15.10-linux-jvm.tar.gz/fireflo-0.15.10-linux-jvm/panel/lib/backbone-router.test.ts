import { test } from "node:test";
import assert from "node:assert/strict";
import { routerHoldOf, type HealthBackbone } from "./health-types.ts";

const KAFKA: HealthBackbone = { provider: "kafka", connected: true };

test("nothing to say: no backbone, an older gateway, memory mode, or OK with nothing listed", () => {
  assert.equal(routerHoldOf(null), null);
  assert.equal(routerHoldOf(undefined), null);
  assert.equal(routerHoldOf(KAFKA), null);
  assert.equal(routerHoldOf({ provider: "memory", connected: true, state: null, router: null }), null);
  assert.equal(
    routerHoldOf({ ...KAFKA, state: "OK", router: { partitionsUnanchored: [], stalledPartitions: [] } }),
    null,
  );
});

test("DEGRADED with held and stalled partitions lists both", () => {
  const hold = routerHoldOf({
    ...KAFKA,
    state: "DEGRADED",
    router: { partitionsUnanchored: ["fireflo.router-5", "fireflo.router-13"], stalledPartitions: ["fireflo.router-21"] },
  });
  assert.deepEqual(hold, {
    degraded: true,
    unanchored: ["fireflo.router-5", "fireflo.router-13"],
    stalled: ["fireflo.router-21"],
  });
});

test("a partition listed counts as degraded even if the state says OK or is missing", () => {
  assert.equal(routerHoldOf({ ...KAFKA, router: { partitionsUnanchored: ["fireflo.router-0"] } })?.degraded, true);
  assert.equal(
    routerHoldOf({ ...KAFKA, state: "OK", router: { stalledPartitions: ["fireflo.router-3"] } })?.stalled[0],
    "fireflo.router-3",
  );
});

test("DEGRADED with no lists still shows degraded; blanks and lower case are tolerated", () => {
  assert.deepEqual(routerHoldOf({ ...KAFKA, state: " degraded ", router: null }), {
    degraded: true,
    unanchored: [],
    stalled: [],
  });
  assert.deepEqual(
    routerHoldOf({ ...KAFKA, state: "DEGRADED", router: { partitionsUnanchored: ["", "fireflo.router-1"] } })?.unanchored,
    ["fireflo.router-1"],
  );
});
