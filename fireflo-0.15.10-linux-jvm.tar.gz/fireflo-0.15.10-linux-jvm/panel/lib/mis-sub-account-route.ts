import { NextResponse, type NextRequest } from "next/server";
import { configQuery } from "@/lib/config-db";
import { recordCustomerAccess, type CustomerEvent } from "@/lib/customer-access-log";
import { requestContext } from "@/lib/request-context";
import { assertInScope, requireReseller, type CustomerSession } from "@/lib/require-customer";
import { NotCustomerError } from "@/lib/require-customer";
import type { Refusal } from "@/lib/reseller-rules";

/**
 * What every `/api/mis/sub-accounts/*` route repeats. A route module may export only its handlers,
 * so the shared steps live here.
 *
 * <p>Those routes are the portal's mirror of the gateway's reseller API (`/secure/accounts…`, 0.15.8):
 * the same paths under `/api/mis/sub-accounts`, the same verbs, the same refusals. When the panel can
 * call that API on the reseller's behalf, each handler becomes a pass-through and the pages above
 * them do not change.
 */

export interface ChildContext {
  session: CustomerSession;
  child: string;
}

/**
 * The reseller session and the child named in the path, proved to be its own.
 *
 * <p>A non-reseller, a stranger's child and no such account all answer the same 404, through
 * `requireReseller` and `assertInScope` -- which also writes the `cross_account_access` row.
 *
 * @returns the context, or the 404 to answer
 */
export async function childFor(params: Promise<{ id: string }>): Promise<ChildContext | NextResponse> {
  try {
    const session = await requireReseller();
    const child = decodeURIComponent((await params).id).trim();
    if (!child || child === session.accountId) {
      return notFound();
    }
    await assertInScope(session, child);
    return { session, child };
  } catch (err) {
    if (err instanceof NotCustomerError) {
      return notFound();
    }
    throw err;
  }
}

export function notFound(): NextResponse {
  return NextResponse.json({ error: "Not found" }, { status: 404 });
}

export function refusal(r: Refusal): NextResponse {
  return NextResponse.json({ error: r.error }, { status: r.status });
}

/** The JSON body as an object, or the 400 to answer. */
export async function jsonBody(req: NextRequest): Promise<Record<string, unknown> | NextResponse> {
  try {
    const body = await req.json();
    if (body && typeof body === "object" && !Array.isArray(body)) {
      return body as Record<string, unknown>;
    }
  } catch {
    //fall through
  }
  return NextResponse.json({ error: "Expected a JSON object." }, { status: 400 });
}

/**
 * Who did it, for a transfer's "By": the signed-in person's address, else the account. Read fresh,
 * not from the token, because an address can change while a session lives.
 */
export async function actorOf(session: CustomerSession): Promise<string> {
  try {
    const rows = await configQuery<{ email: string }>(
      "SELECT email FROM app_user WHERE id = $1 AND account_id = $2",
      [session.userId, session.accountId]
    );
    return rows[0]?.email ?? session.accountId;
  } catch {
    return session.accountId;
  }
}

/**
 * One audit row for a reseller's act on a child. `detail.via` is `portal`, as the gateway's API
 * writes `api`, so "who changed this and from where" is one query.
 */
export async function auditChild(
  session: CustomerSession,
  event: CustomerEvent,
  detail: Record<string, unknown>,
  fallback?: CustomerEvent
): Promise<void> {
  const ctx = await requestContext();
  void recordCustomerAccess({
    event,
    fallback,
    accountId: session.accountId,
    userId: session.userId,
    ip: ctx.ip,
    userAgent: ctx.userAgent,
    detail: { ...detail, via: "portal" },
  });
}
