import type { PoolClient } from "pg";
import { BILLING_KEY } from "@/lib/billing-key";
import { auditConfigChange } from "@/lib/config-audit";
import { configQuery, inTransaction } from "@/lib/config-db";
import { ConfigRefusal } from "@/lib/config-guard";
import { disconnectBindsFor } from "@/lib/gateway-sessions";
import { GatewayError, gqlData } from "@/lib/gateway-graphql";
import { CREDIT_RELEASE } from "@/lib/gateway-queries";
import { assertProductsCatalogued } from "@/lib/products";
import { COPY_EXISTING_SQL, COPY_INSERT_SQL, COPY_SOURCE_SQL } from "@/lib/whitelist-sql";
import {
  type CopyKind,
  type CopySkip,
  type CopySource,
  type CopyStatusChoice,
  type CopyTargetResult,
  type MoveSide,
  type ScopedRow,
  archiveRefusal,
  archivedReadOnly,
  copyKey,
  copyStamp,
  copyTargetRefusal,
  moveRefusal,
  planCopy,
  scopedLoginRefusal,
  scopedRowsRefusal,
  unarchiveRefusal,
} from "@/lib/account-archive-rules";

/**
 * Archiving an account, and moving a login, sender ID or template from one account to another.
 *
 * <p>Server-only: importing this pulls `pg`. The decisions are in `account-archive-rules.ts`.
 *
 * <p><strong>Archive is suspend, made permanent until undone.</strong> It follows `suspendChild`
 * (`lib/mis-accounts.ts`) step for step, because each of its steps closes a different door:
 * <ol>
 *   <li>Switch the logins off, chosen by {@link BILLING_KEY} so one that bills here by the
 *       system-id fallback is caught too, and remember which ({@code archived_logins}) so unarchiving
 *       turns back on exactly those.</li>
 *   <li>Stamp the account: {@code enabled = false}, {@code archived_at}, {@code archived_by}. The
 *       gateway (V1.100.0) withholds an archived account's logins on its next poll, and the portal
 *       refuses its people at sign-in and on every request, because they join on {@code enabled}.</li>
 *   <li>After the commit, drop the binds those logins hold -- a bound session outlives a disabled
 *       login -- and hand back the credit block the gateway holds for the account, so its balance
 *       reads true. Both best effort: the stored change already stands.</li>
 * </ol>
 */

/** What archiving did beyond the stored change, for the operator to read. */
export interface ArchiveResult {
  logins: number;
  dropped: number;
  /** Present when the binds or the held credit could not be reached; the archive still stands. */
  problem?: string;
}

/** Whether the account is archived; null when there is no such account. */
async function archivedState(client: PoolClient, id: string, lock = false): Promise<boolean | null> {
  const rows = await client.query<{ archived: boolean }>(
    `SELECT archived_at IS NOT NULL AS archived FROM app_account WHERE id = $1${lock ? " FOR UPDATE" : ""}`,
    [id]
  );
  return rows.rows.length ? rows.rows[0].archived : null;
}

/**
 * Refuses a write to an archived account (400, with the sentence the operator needs).
 *
 * <p>Called by every writer that changes what an account has -- its logins, sender IDs, templates,
 * balance and portal people -- so "read-only" holds whichever page the write came from. An id with
 * no account row is not refused here: adopting an id is how accounts are born.
 */
export async function assertWritableAccount(client: PoolClient | null, accountId: string | null | undefined): Promise<void> {
  const id = accountId?.trim();
  if (!id) {
    return;
  }
  const rows = client
    ? (await client.query<{ archived: boolean }>(
        "SELECT archived_at IS NOT NULL AS archived FROM app_account WHERE id = $1", [id])).rows
    : await configQuery<{ archived: boolean }>(
        "SELECT archived_at IS NOT NULL AS archived FROM app_account WHERE id = $1", [id]);
  if (rows[0]?.archived) {
    throw new ConfigRefusal(archivedReadOnly(id));
  }
}

/** Whether a credential row's billing account is archived, for writers that hold only its id. */
export async function assertWritableCredential(client: PoolClient | null, credentialId: number): Promise<void> {
  const sql = `SELECT ${BILLING_KEY} AS account FROM app_credential WHERE id = $1`;
  const rows = client
    ? (await client.query<{ account: string | null }>(sql, [credentialId])).rows
    : await configQuery<{ account: string | null }>(sql, [credentialId]);
  await assertWritableAccount(client, rows[0]?.account ?? null);
}

export async function archiveAccount(id: string, operator: string): Promise<ArchiveResult> {
  const switchedOff = await inTransaction(async (client) => {
    const state = await archivedState(client, id, true);
    const kids = await client.query<{ n: string }>(
      "SELECT count(*)::text AS n FROM app_account WHERE parent_account_id = $1 AND archived_at IS NULL",
      [id]
    );
    const refusal = archiveRefusal(id, {
      exists: state !== null,
      archived: state === true,
      activeChildren: Number(kids.rows[0]?.n ?? 0),
    });
    if (refusal) {
      throw new ConfigRefusal(refusal);
    }
    const logins = await client.query<{ id: string; system_id: string | null; type: string }>(
      `UPDATE app_credential
          SET enabled = FALSE, updated_at = now()
        WHERE enabled AND ${BILLING_KEY} = $1
        RETURNING id::text, system_id, type`,
      [id]
    );
    await client.query(
      `UPDATE app_account
          SET enabled = FALSE, archived_at = now(), archived_by = $2,
              archived_logins = $3::bigint[], updated_at = now()
        WHERE id = $1`,
      [id, operator, logins.rows.map((l) => l.id)]
    );
    return logins.rows;
  });

  await auditConfigChange({
    domain: "account",
    name: id,
    action: "action:archive",
    account: id,
    after: { archived: true, loginsSwitchedOff: switchedOff.map((l) => l.system_id ?? `#${l.id}`) },
  });

  let dropped = 0;
  let problem: string | undefined;
  //SMPP only: an HTTP login holds no session
  for (const login of switchedOff.filter((l) => l.type === "SMPP" && l.system_id)) {
    const teardown = await disconnectBindsFor(login.system_id as string);
    dropped += teardown.dropped;
    problem ??= teardown.problem;
  }
  //after the binds, so nothing spends from the block while it is being handed back. A gateway with
  //prepaid credit off answers CONFLICT (409) "nothing reserved", which is not a problem worth showing
  try {
    await gqlData({ query: CREDIT_RELEASE, variables: { account: id }, auth: "admin" });
  } catch (err) {
    if (err instanceof GatewayError && err.code === "UNREACHABLE") {
      problem ??= `the gateway is unreachable, so the credit it holds for '${id}' is returned when it restarts`;
    } else if (!(err instanceof GatewayError && err.status === 409)) {
      const status = err instanceof GatewayError ? err.status : "error";
      problem ??= `the gateway could not return the credit it holds for '${id}' (${status}); `
        + "it is returned when the gateway restarts";
    }
  }
  return { logins: switchedOff.length, dropped, problem };
}

/** Brings an archived account back: enabled, listed, and the logins the archive switched off on. */
export async function unarchiveAccount(id: string): Promise<{ logins: number }> {
  const logins = await inTransaction(async (client) => {
    const state = await archivedState(client, id, true);
    const refusal = unarchiveRefusal(id, { exists: state !== null, archived: state === true });
    if (refusal) {
      throw new ConfigRefusal(refusal);
    }
    const remembered = await client.query<{ ids: string[] | null }>(
      "SELECT archived_logins::text[] AS ids FROM app_account WHERE id = $1",
      [id]
    );
    await client.query(
      `UPDATE app_account
          SET enabled = TRUE, archived_at = NULL, archived_by = NULL, archived_logins = NULL,
              updated_at = now()
        WHERE id = $1`,
      [id]
    );
    //only those still billing here: one moved away while archived is not this account's to wake.
    //A clash with a login enabled elsewhere in the meantime (uq_app_credential_smpp) fails the whole
    //unarchive with the index's name, which is the honest answer
    const back = await client.query(
      `UPDATE app_credential
          SET enabled = TRUE, updated_at = now()
        WHERE id = ANY ($2::bigint[]) AND NOT enabled AND ${BILLING_KEY} = $1`,
      [id, remembered.rows[0]?.ids ?? []]
    );
    return back.rowCount ?? 0;
  });
  await auditConfigChange({
    domain: "account", name: id, action: "action:unarchive", account: id, after: { archived: false, loginsBack: logins },
  });
  return { logins };
}

async function side(client: PoolClient, id: string): Promise<MoveSide> {
  const state = await archivedState(client, id);
  return { id, exists: state !== null, archived: state === true };
}

/** What a move did beyond the stored change. */
export interface MoveResult {
  from: string;
  to: string;
  dropped: number;
  problem?: string;
}

/**
 * Gives a login to another account.
 *
 * <p>Alone: refused while a sender ID or template on the old account is scoped to its system ID
 * (they would name a login that is no longer there). Its live binds are dropped after the commit,
 * because a bound session keeps the account it bound with (`BasicSmppSessionContext`) and would go
 * on billing the old one. What it already sent stays in the old account's history.
 */
export async function moveCredential(credentialId: number, to: string): Promise<MoveResult> {
  const target = to.trim();
  const moved = await inTransaction(async (client) => {
    const rows = await client.query<{ type: string; system_id: string | null; account: string | null }>(
      `SELECT type, system_id, ${BILLING_KEY} AS account FROM app_credential WHERE id = $1 FOR UPDATE`,
      [credentialId]
    );
    if (!rows.rows.length) {
      throw new ConfigRefusal("Reload the page -- this login has been deleted since it was opened.");
    }
    const login = rows.rows[0];
    const from = login.account ?? "";
    const refusal = moveRefusal("login", await side(client, from), await side(client, target));
    if (refusal) {
      throw new ConfigRefusal(refusal);
    }
    if (login.system_id?.trim()) {
      const scoped = await client.query<{ kind: ScopedRow["kind"]; id: string; name: string }>(
        `SELECT 'sender ID' AS kind, id::text, header AS name FROM app_header
          WHERE account_id = $1 AND system_id = $2
         UNION ALL
         SELECT 'template', id::text, COALESCE(name, left(body, 30)) FROM app_template
          WHERE account_id = $1 AND system_id = $2
         ORDER BY 1, 2`,
        [from, login.system_id.trim()]
      );
      const blocked = scopedRowsRefusal(
        login.system_id.trim(),
        scoped.rows.map((r) => ({ kind: r.kind, id: Number(r.id), name: r.name }))
      );
      if (blocked) {
        throw new ConfigRefusal(blocked);
      }
    }
    await client.query(
      "UPDATE app_credential SET account_id = $2, updated_at = now() WHERE id = $1",
      [credentialId, target]
    );
    return { from, type: login.type, systemId: login.system_id };
  });

  await auditConfigChange({
    domain: "credential",
    name: moved.systemId?.trim() ? `${moved.type} ${moved.systemId.trim()}` : `${moved.type} #${credentialId}`,
    action: "action:move",
    account: target,
    before: { id: credentialId, account: moved.from },
    after: { id: credentialId, account: target },
  });

  let dropped = 0;
  let problem: string | undefined;
  if (moved.type === "SMPP" && moved.systemId) {
    const teardown = await disconnectBindsFor(moved.systemId);
    dropped = teardown.dropped;
    problem = teardown.problem;
  }
  return { from: moved.from, to: target, dropped, problem };
}

/** Gives a sender ID or a template to another account, approval kept. */
export async function moveWhitelistRow(kind: "header" | "template", rowId: number, to: string): Promise<MoveResult> {
  const table = kind === "header" ? "app_header" : "app_template";
  const what = kind === "header" ? "sender ID" : "template";
  const target = to.trim();
  const moved = await inTransaction(async (client) => {
    const rows = await client.query<{ account_id: string; system_id: string | null; name: string }>(
      kind === "header"
        ? "SELECT account_id, system_id, header AS name FROM app_header WHERE id = $1 FOR UPDATE"
        : "SELECT account_id, system_id, COALESCE(name, left(body, 30)) AS name FROM app_template WHERE id = $1 FOR UPDATE",
      [rowId]
    );
    if (!rows.rows.length) {
      throw new ConfigRefusal(`Reload the page -- this ${what} has been deleted since it was opened.`);
    }
    const row = rows.rows[0];
    const refusal = moveRefusal(what, await side(client, row.account_id), await side(client, target));
    if (refusal) {
      throw new ConfigRefusal(refusal);
    }
    let loginOnTarget = false;
    if (row.system_id?.trim()) {
      const owner = await client.query(
        `SELECT 1 FROM app_credential WHERE ${BILLING_KEY} = $1 AND system_id = $2`,
        [target, row.system_id.trim()]
      );
      loginOnTarget = (owner.rowCount ?? 0) > 0;
    }
    const scoped = scopedLoginRefusal(row.system_id, loginOnTarget, target);
    if (scoped) {
      throw new ConfigRefusal(scoped);
    }
    try {
      await client.query(`UPDATE ${table} SET account_id = $2, updated_at = now() WHERE id = $1`, [rowId, target]);
    } catch (err) {
      if ((err as { code?: string }).code === "23505") {
        throw new ConfigRefusal(`'${target}' already has this ${what}${row.system_id ? ` for the login '${row.system_id}'` : ""}. `
          + "Delete one of the two first.");
      }
      throw err;
    }
    return { from: row.account_id, name: row.name };
  });
  await auditConfigChange({
    domain: kind,
    name: `${target} ${moved.name}`,
    action: "action:move",
    account: target,
    before: { id: rowId, account: moved.from },
    after: { id: rowId, account: target },
  });
  return { from: moved.from, to: target, dropped: 0 };
}

/** A source row as {@link COPY_SOURCE_SQL} reads it. */
interface CopySourceRow {
  id: string;
  account_id: string;
  product: string;
  system_id: string | null;
  display: string;
  folded: string;
  status: string;
  enabled: boolean;
  header: string | null;
  name: string | null;
  body: string | null;
  tlvs: string | null;
  label: string | null;
}

function toCopySource(r: CopySourceRow): CopySource {
  return {
    id: Number(r.id),
    accountId: r.account_id,
    product: r.product ?? "",
    systemId: r.system_id,
    display: r.display,
    folded: r.folded,
    status: r.status,
    enabled: r.enabled,
  };
}

/**
 * Copies sender IDs or templates to several accounts. Nothing on the source changes, and nothing a
 * target already has is touched: a duplicate is skipped, never overwritten. The decisions are
 * `planCopy` and `copyStamp` in `account-archive-rules.ts`.
 *
 * <ul>
 *   <li><strong>Refused</strong> before anything is written: a target that is not an account or is
 *       archived, a product no longer in the catalogue, a selected row deleted since the page opened.</li>
 *   <li><strong>One transaction per target.</strong> The target's account row is locked, so two
 *       copies into one account cannot both pass the duplicate test for a template (which has no
 *       unique key); the source rows are read `FOR SHARE`.</li>
 *   <li><strong>Audited per created row</strong>, `action:copy`, against the target account.</li>
 * </ul>
 */
export async function copyWhitelistRows(
  kind: CopyKind,
  ids: readonly number[],
  targets: readonly string[],
  options: { status: CopyStatusChoice; widenScope: boolean },
  operator: string
): Promise<CopyTargetResult[]> {
  const what = kind === "header" ? "sender ID" : "template";
  const to = [...new Set(targets.map((t) => t.trim()).filter(Boolean))];

  const table = kind === "header" ? "app_header" : "app_template";
  const sources = await configQuery<{ product: string }>(
    `SELECT product FROM ${table} WHERE id = ANY($1::bigint[])`, [ids]);
  if (sources.length < ids.length) {
    const gone = ids.length - sources.length;
    throw new ConfigRefusal(`Reload the page -- ${gone} of the selected ${what}s ${gone === 1 ? "has" : "have"} `
      + "been deleted since it was opened.");
  }
  await assertProductsCatalogued(sources.map((r) => r.product));
  const accounts = await configQuery<{ id: string; archived: boolean }>(
    "SELECT id, archived_at IS NOT NULL AS archived FROM app_account WHERE id = ANY($1::text[])",
    [to]
  );
  const refusal = copyTargetRefusal(to, new Map(accounts.map((a) => [a.id, a.archived])));
  if (refusal) {
    throw new ConfigRefusal(refusal);
  }

  const results: CopyTargetResult[] = [];
  for (const target of to) {
    const done = await inTransaction(async (client) => {
      //locked for the length of this copy, and checked again: it may have been archived since
      if (await archivedState(client, target, true)) {
        const done = results.map((r) => r.to).join(", ");
        throw new ConfigRefusal(`'${target}' was archived while the copy ran, so nothing was copied to it`
          + (done ? ` or to the accounts after it. Already copied to: ${done}.` : " or to the accounts after it."));
      }
      const rows = (await client.query<CopySourceRow>(COPY_SOURCE_SQL[kind], [ids])).rows;
      const byId = new Map(rows.map((r) => [Number(r.id), r]));
      const existing = await client.query<{ product: string; system_id: string | null; folded: string }>(
        COPY_EXISTING_SQL[kind], [target]);
      const plan = planCopy(
        rows.map(toCopySource),
        target,
        new Set(existing.rows.map((e) => copyKey(e.product ?? "", e.system_id, e.folded))),
        options.widenScope
      );
      const skipped: CopySkip[] = [...plan.skipped];
      const created: { src: CopySource; id: number; systemId: string | null; status: string }[] = [];
      for (const { row, systemId } of plan.copy) {
        const full = byId.get(row.id)!;
        const stamp = copyStamp(row.status, options.status, row.accountId, operator);
        const common = [full.tlvs, full.label, full.enabled, systemId, operator,
          stamp.status, stamp.reviewedBy, stamp.reviewNote, stamp.requestNote];
        const inserted = await client.query<{ id: string }>(
          COPY_INSERT_SQL[kind],
          kind === "header"
            ? [target, row.product, full.header, ...common]
            : [target, row.product, full.name, full.body, ...common]
        );
        if (inserted.rows.length) {
          created.push({ src: row, id: Number(inserted.rows[0].id), systemId, status: stamp.status });
        } else {
          skipped.push({ id: row.id, text: row.display, reason: "already" });
        }
      }
      return { created, skipped };
    });

    for (const c of done.created) {
      await auditConfigChange({
        domain: kind,
        name: `${target} ${c.src.display}`,
        action: "action:copy",
        account: target,
        before: { id: c.src.id, account: c.src.accountId },
        after: { id: c.id, account: target, product: c.src.product || null, systemId: c.systemId, status: c.status },
      });
    }
    results.push({ to: target, copied: done.created.length, skipped: done.skipped });
  }
  return results;
}
