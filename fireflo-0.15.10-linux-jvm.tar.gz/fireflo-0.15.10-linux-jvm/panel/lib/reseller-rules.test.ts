import { test } from "node:test";
import assert from "node:assert/strict";
import {
  parseAllowedIps,
  parseLoginPatch,
  parseNewLogin,
  parseSessionLimits,
  parseSubAccountCreate,
  parseTransfer,
  readTransferNote,
  refusedFieldProblem,
  shortfallProblem,
  systemIdProblem,
  transferNote,
  transferStateProblem,
} from "./reseller-rules.ts";
import { childIdProblem } from "./mis-account-rules.ts";

/**
 * The portal's sub-account rules, which are the gateway reseller API's (0.15.8) held panel-side.
 * Each block is one rule from the plan's endpoint table; the refusals are the point.
 */

const KEY = "0b8c6f2e-4a1d-4c3e-9f7a-1d2e3f4a5b6c";

test("platform fields are refused, under every spelling, with 'set by your platform'", () => {
  for (const field of ["product", "allowedProducts", "allowed_products", "maxTps", "max_tps"]) {
    const problem = refusedFieldProblem({ [field]: "x" });
    assert.ok(problem, field);
    assert.match(problem, /set by your platform/);
  }
  assert.equal(refusedFieldProblem({ product: null }), null, "an explicit null is not a request");
});

test("secrets are generated, never accepted", () => {
  for (const field of ["password", "apiKey", "api_key", "secret"]) {
    assert.match(refusedFieldProblem({ [field]: "hunter2" }) ?? "", /generated/, field);
  }
  const login = parseNewLogin({ type: "SMPP", password: "mine" });
  assert.equal(login.ok, false);
});

test("create: opening credit is a decimal of zero or more, and resells/parent are not read", () => {
  const ok = parseSubAccountCreate({ id: "nw-sunrise", label: "Sunrise", opening: "500.00", resells: true, parentAccountId: "x" });
  assert.equal(ok.ok, true);
  assert.deepEqual(ok.ok && ok.value, { id: "nw-sunrise", label: "Sunrise", opening: 5_000_000 });
  assert.equal((parseSubAccountCreate({ id: "a" }) as { value: { opening: number } }).value.opening, 0);
  assert.equal(parseSubAccountCreate({ id: "a", opening: "-1" }).ok, false);
  assert.equal(parseSubAccountCreate({ id: "a", opening: "1.00001" }).ok, false);
  assert.equal(parseSubAccountCreate({ id: "a", product: "otp" }).ok, false);
});

test("create: the id rules, and 'new' is reserved for the page that creates one", () => {
  assert.equal(childIdProblem("nw-sunrise", []), null);
  assert.match(childIdProblem("new", []) ?? "", /reserved/);
  assert.match(childIdProblem("NW-SUNRISE", ["nw-sunrise"]) ?? "", /already in use/, "case-insensitive");
  assert.ok(childIdProblem("a".repeat(65), []));
  assert.ok(childIdProblem("-lead", []));
});

test("a chosen SMPP system id is at most 15 characters; an HTTP name at most 64", () => {
  assert.equal(systemIdProblem("SMPP", "a".repeat(15)), null);
  assert.match(systemIdProblem("SMPP", "a".repeat(16)) ?? "", /15 characters/);
  assert.equal(systemIdProblem("HTTP", "a".repeat(64)), null);
  assert.ok(systemIdProblem("HTTP", "a".repeat(65)));
  assert.ok(systemIdProblem("SMPP", "has space"));
  const parsed = parseNewLogin({ type: "SMPP", systemId: "bharatpromo1234x" });
  assert.equal(parsed.ok, false);
  assert.equal(!parsed.ok && parsed.status, 400);
});

test("a new login: type exactly SMPP or HTTP, empty name means generated", () => {
  assert.equal(parseNewLogin({ type: "smpp" }).ok, false, "never case-folded");
  const smpp = parseNewLogin({ type: "SMPP", systemId: "  " });
  assert.equal(smpp.ok && smpp.value.systemId, null);
  const http = parseNewLogin({ type: "HTTP", system_id: "nw-api" });
  assert.equal(http.ok && http.value.systemId, "nw-api");
});

test("allowed IPs: at most 50, exact addresses only, refused rather than cut short", () => {
  const fifty = Array.from({ length: 50 }, (_, i) => `10.0.0.${i + 1}`);
  assert.equal(parseAllowedIps(fifty).ok, true);
  const many = parseAllowedIps([...fifty, "10.0.1.1"]);
  assert.equal(many.ok, false);
  assert.match(!many.ok ? many.error : "", /at most 50/);
  assert.equal(parseAllowedIps(["198.51.100.0/28"]).ok, false, "a range never matches");
  assert.equal(parseAllowedIps(["gw.example.com"]).ok, false);
  const text = parseAllowedIps("203.0.113.24\n203.0.113.24\n\n2001:db8::1");
  assert.deepEqual(text.ok && text.value, ["203.0.113.24", "2001:db8::1"], "trimmed, de-duplicated");
  assert.deepEqual((parseAllowedIps(undefined) as { value: string[] }).value, []);
  assert.equal(parseAllowedIps(42).ok, false);
});

test("session limits: the operator form's ranges, per-type within the total, never maxTps", () => {
  const ok = parseSessionLimits({ maxSessions: 4, maxTx: "2", max_rx: 2, maxTrx: "" });
  assert.deepEqual(ok.ok && ok.value, { maxSessions: 4, maxTx: 2, maxRx: 2, maxTrx: null });
  assert.equal(parseSessionLimits({ maxSessions: 0 }).ok, false);
  assert.equal(parseSessionLimits({ maxSessions: 10_001 }).ok, false);
  assert.equal(parseSessionLimits({ maxSessions: 1.5 }).ok, false);
  assert.equal(parseSessionLimits({ maxSessions: 2, maxTx: 3 }).ok, false, "TX above the total");
  assert.equal(parseSessionLimits({ limits: { maxTps: 10 } }).ok, false);
  assert.equal(parseNewLogin({ type: "HTTP", maxSessions: 2 }).ok, false, "HTTP holds no sessions");
});

test("a login patch: enabled, IPs and limits only", () => {
  const ok = parseLoginPatch({ enabled: false, allowedIps: ["203.0.113.24"], limits: { maxSessions: 4 } }, "SMPP");
  assert.equal(ok.ok, true);
  assert.deepEqual(ok.ok && Object.keys(ok.value).sort(), ["allowedIps", "enabled", "limits"]);
  assert.match((parseLoginPatch({ maxTps: 100 }, "SMPP") as { error: string }).error, /set by your platform/);
  assert.equal(parseLoginPatch({ product: "otp" }, "SMPP").ok, false);
  assert.equal(parseLoginPatch({ systemId: "other" }, "SMPP").ok, false);
  assert.equal(parseLoginPatch({ accountId: "elsewhere" }, "SMPP").ok, false);
  assert.equal(parseLoginPatch({ enabled: "no" }, "SMPP").ok, false);
  assert.equal(parseLoginPatch({}, "SMPP").ok, false, "nothing to change");
  assert.equal(parseLoginPatch({ maxSessions: 2 }, "HTTP").ok, false);
  const cleared = parseLoginPatch({ allowedIps: [] }, "HTTP");
  assert.deepEqual(cleared.ok && cleared.value, { allowedIps: [] }, "an empty list clears the restriction");
});

test("a transfer: amount above zero, an idempotency key, an optional plain reference", () => {
  const ok = parseTransfer({ amount: "1000.00", idempotencyKey: KEY.toUpperCase(), reference: "Invoice NW-2211" });
  assert.deepEqual(ok.ok && ok.value, { amount: 10_000_000, reference: "Invoice NW-2211", ref: `xfer:${KEY}` });
  const legacy = parseTransfer({ amount: "1", ref: `xfer:${KEY}` });
  assert.equal(legacy.ok && legacy.value.ref, `xfer:${KEY}`);
  assert.equal(parseTransfer({ amount: "1" }).ok, false, "no key, no transfer");
  assert.equal(parseTransfer({ amount: "1", ref: "INV-2024-001" }).ok, false, "an operator's reference is not claimable");
  assert.equal(parseTransfer({ amount: "0", idempotencyKey: KEY }).ok, false);
  assert.equal(parseTransfer({ amount: "-5", idempotencyKey: KEY }).ok, false);
  assert.equal(parseTransfer({ amount: "1", idempotencyKey: KEY, reference: "a|b" }).ok, false);
  assert.equal(parseTransfer({ amount: "1", idempotencyKey: KEY, reference: "x".repeat(101) }).ok, false);
});

test("credit does not move to or from a suspended or archived child (409)", () => {
  assert.equal(transferStateProblem("c", { enabled: true, archived: false }), null);
  assert.equal(transferStateProblem("c", { enabled: false, archived: false })?.status, 409);
  assert.match(transferStateProblem("c", { enabled: true, archived: true })?.error ?? "", /archived/);
});

test("a recharge the reseller cannot cover is 402, naming what it has", () => {
  const render = (n: number) => (n / 10_000).toFixed(2);
  assert.equal(shortfallProblem(10_000_000, 10_000_000, render), null);
  const short = shortfallProblem(5_000, 10_000_000, render);
  assert.equal(short?.status, 402);
  assert.match(short?.error ?? "", /0\.50.*1000\.00/);
  assert.match(shortfallProblem(-20_000, 1, render)?.error ?? "", /\(0\.00\)/, "never a negative balance shown");
});

test("the transfer note carries who, what and the reference, and reads back", () => {
  const note = transferNote("recharge", "priya@northwind.in", "Invoice NW-2211");
  assert.deepEqual(readTransferNote(note), { via: "portal", kind: "recharge", by: "priya@northwind.in", reference: "Invoice NW-2211" });
  assert.deepEqual(readTransferNote(transferNote("opening", "a@b.c", null)), { via: "portal", kind: "opening", by: "a@b.c", reference: null });
  assert.equal(readTransferNote("mis-panel transfer by northwind").by, "northwind");
  assert.equal(readTransferNote("api transfer by northwind").via, "api");
  assert.equal(readTransferNote("typed by hand").reference, "typed by hand");
  assert.equal(readTransferNote(null).reference, null);
});
