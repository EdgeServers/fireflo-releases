import { test } from "node:test";
import assert from "node:assert/strict";
import type { Health } from "./health-types.ts";
import { grpcExplainer, grpcPill, grpcView } from "./grpc-health.ts";

const base = { workers: [] } as unknown as Health;

const ON = {
  ...base,
  grpc: {
    enabled: true,
    port: 8090,
    sessions: 12,
    streams: 5,
    receipts: {
      depth: 4210,
      oldest_age_seconds: 42.5,
      logins_at_cap: 0,
      top: [{ system_id: "sunrise-http", depth: 300 }, { system_id: "acme-api", depth: 3900 }, { system_id: "", depth: 9 }],
    },
  },
} as Health;

test("an older gateway has no grpc block: no card", () => {
  assert.equal(grpcView(base), null);
  assert.equal(grpcView(null), null);
  assert.equal(grpcView({ ...base, grpc: null } as Health), null);
});

test("streams reported by kind, as the gateway does, read as the send count", () => {
  const v = grpcView({ ...ON, grpc: { ...ON.grpc, streams: { send: 3 } } } as unknown as Health)!;
  assert.equal(v.streams, 3);
});

test("the block read for the card: enabled, port, sessions, streams, the feed, deepest first", () => {
  const v = grpcView(ON)!;
  assert.equal(v.enabled, true);
  assert.equal(v.port, 8090);
  assert.equal(v.sessions, 12);
  assert.equal(v.streams, 5);
  assert.equal(v.receipts.depth, 4210);
  assert.equal(v.receipts.oldestAgeSeconds, 42.5);
  assert.equal(v.receipts.loginsAtCap, 0);
  assert.deepEqual(v.receipts.top, [{ systemId: "acme-api", depth: 3900 }, { systemId: "sunrise-http", depth: 300 }]);
  assert.deepEqual(grpcPill(v), { tone: "success", label: "On" });
});

test("switched off: Off, no port, and the sentence names the setting that opens it", () => {
  const v = grpcView({ ...base, grpc: { enabled: false, port: 0 } } as Health)!;
  assert.equal(v.enabled, false);
  assert.equal(v.port, null);
  assert.equal(v.receipts.depth, 0);
  assert.deepEqual(grpcPill(v), { tone: "outline", label: "Off" });
  assert.match(grpcExplainer(v), /FIREFLO_GRPC_PORT/);
});

test("a login at its cap is a warning on the pill and in the sentence", () => {
  const v = grpcView({ ...ON, grpc: { ...ON.grpc, receipts: { ...ON.grpc!.receipts, logins_at_cap: 2 } } } as Health)!;
  assert.deepEqual(grpcPill(v), { tone: "warning", label: "2 logins at cap" });
  assert.match(grpcExplainer(v), /at its cap/);
});

test("missing or string numbers degrade to zero or null, never NaN", () => {
  const v = grpcView({ ...base, grpc: { enabled: true, port: "8090", sessions: null, receipts: { depth: "7" } } } as unknown as Health)!;
  assert.equal(v.port, 8090);
  assert.equal(v.sessions, 0);
  assert.equal(v.streams, 0);
  assert.equal(v.receipts.depth, 7);
  assert.equal(v.receipts.oldestAgeSeconds, null);
  assert.deepEqual(v.receipts.top, []);
});

test("platform sessions (gateway 0.15.10) read when published, null on an older gateway", () => {
  assert.equal(grpcView(ON)!.sessionsPlatform, null);
  const v = grpcView({ ...ON, grpc: { ...ON.grpc, sessions_platform: 2 } } as unknown as Health)!;
  assert.equal(v.sessionsPlatform, 2);
  assert.equal(v.sessions, 12);
});
