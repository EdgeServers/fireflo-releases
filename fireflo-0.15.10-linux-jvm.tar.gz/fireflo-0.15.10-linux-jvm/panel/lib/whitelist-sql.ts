/**
 * The approval half of the two whitelist upserts, as SQL fragments.
 *
 * <p>Database-free on purpose. `lib/whitelist.ts` imports `pg`, which `node --test` cannot load, so
 * anything living there is untestable — and these four strings shipped a statement that failed to
 * parse on every call precisely because nothing could assert anything about them. Same reason
 * `rejected-request.ts` and `custom-tlvs.ts` are separate from their query layers.
 *
 * <p>Approving from the editor, rather than only from the review buttons: the tick used to be
 * labelled "Approved" and write only `enabled`, which left a customer's PENDING row PENDING and
 * inert while the panel looked like it had approved something.
 *
 * <p><strong>Only ever forwards.</strong> Ticking sets `APPROVED` and records who and when, exactly
 * as the review PATCH does. Unticking leaves `status` alone and only clears `enabled` — withdrawing
 * a registration is not un-approving it, and a withdrawn row put back into service should not need a
 * second approval. Refusing is not reachable from here at all: it needs a reason the customer is
 * shown.
 *
 * <p>The header and template shapes differ only by their parameter numbers — `$6`/`$7` against
 * `$7`/`$8` — which is why they are four constants rather than two.
 */

/**
 * <strong>Every column on the right of an `ELSE` is qualified with its table name, and it has to
 * be.</strong>
 *
 * <p>This fragment is interpolated into an `INSERT ... ON CONFLICT DO UPDATE`, where the target
 * table and the `excluded` pseudo-relation are BOTH in scope. A bare `status` there resolves
 * ambiguously and PostgreSQL refuses the whole statement with `column reference "status" is
 * ambiguous` — at parse time, not at execution, so it fired on every operator save rather than only
 * when a conflict actually occurred, and no sender ID could be added at all.
 *
 * <p>Qualifying is equally valid in the plain `UPDATE` this is also interpolated into, which is what
 * lets one constant still serve both call sites. An alias would not work: `ON CONFLICT` addresses
 * the target by its own name.
 *
 * <p>Note the asymmetry the test pins: the column being assigned, on the LEFT of each `=`, must
 * stay bare. PostgreSQL rejects a qualified target in a `SET` clause, so "qualify everything"
 * is not the fix — it just trades one parse error for another.
 */
export const APPROVAL_SET =
  "status = CASE WHEN $6 THEN 'APPROVED' ELSE app_header.status END, "
  + "reviewed_by = CASE WHEN $6 THEN $7 ELSE app_header.reviewed_by END, "
  + "reviewed_at = CASE WHEN $6 THEN now() ELSE app_header.reviewed_at END";

export const APPROVAL_INSERT =
  "CASE WHEN $6 THEN 'APPROVED' ELSE 'PENDING' END, "
  + "CASE WHEN $6 THEN $7 END, CASE WHEN $6 THEN now() END";

/**
 * Qualified for the same reason as {@link APPROVAL_SET}, though `saveTemplate` has no `ON CONFLICT`
 * today and so has never hit the error. Left bare it is a trap set for whoever adds one.
 */
export const APPROVAL_SET_TEMPLATE =
  "status = CASE WHEN $7 THEN 'APPROVED' ELSE app_template.status END, "
  + "reviewed_by = CASE WHEN $7 THEN $8 ELSE app_template.reviewed_by END, "
  + "reviewed_at = CASE WHEN $7 THEN now() ELSE app_template.reviewed_at END";

export const APPROVAL_INSERT_TEMPLATE =
  "CASE WHEN $7 THEN 'APPROVED' ELSE 'PENDING' END, "
  + "CASE WHEN $7 THEN $8 END, CASE WHEN $7 THEN now() END";

/**
 * The statements `copyWhitelistRows` (`lib/account-archive.ts`) runs, here for the same reason as
 * the fragments above: so a test can read them without `pg`.
 *
 * <p>The source rows are read with `lower(...)` folded by PostgreSQL, not by JavaScript, so a copy's
 * duplicate test compares text exactly as the header index and the gateway's template check do.
 * `FOR SHARE` keeps them from being edited or deleted while they are copied, without blocking
 * another copy of the same rows.
 */
export const COPY_SOURCE_SQL = {
  header: `SELECT id::text, account_id, product, system_id, header AS display, lower(header) AS folded,
                  status, enabled, header, NULL::text AS name, NULL::text AS body, tlvs, label
             FROM app_header WHERE id = ANY($1::bigint[]) ORDER BY id FOR SHARE`,
  template: `SELECT id::text, account_id, product, system_id, COALESCE(name, left(body, 40)) AS display,
                    lower(body) AS folded, status, enabled, NULL::text AS header, name, body, tlvs, label
               FROM app_template WHERE id = ANY($1::bigint[]) ORDER BY id FOR SHARE`,
} as const;

/** Everything a target already has, keyed as `copyKey` keys it: product, scope, folded text. */
export const COPY_EXISTING_SQL = {
  header: `SELECT product, system_id, lower(header) AS folded FROM app_header WHERE account_id = $1`,
  template: `SELECT product, system_id, lower(body) AS folded FROM app_template WHERE account_id = $1`,
} as const;

/**
 * One copy. `reviewed_at` is stamped only when there is a reviewer, so a pending copy records no
 * review nobody performed. The header insert names its natural key's conflict target and does
 * nothing on it: the plan has already skipped what the target had, and this is the guard against a
 * row written between that read and this insert -- no row comes back, and it counts as already there.
 */
export const COPY_INSERT_SQL = {
  header: `INSERT INTO app_header
               (account_id, product, header, tlvs, label, enabled, system_id, updated_by,
                status, reviewed_by, reviewed_at, review_note, request_note)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8,
                   $9, $10, CASE WHEN $10::text IS NULL THEN NULL ELSE now() END, $11, $12)
           ON CONFLICT (account_id, product, COALESCE(system_id, ''), lower(header)) DO NOTHING
           RETURNING id::text`,
  template: `INSERT INTO app_template
                 (account_id, product, name, body, tlvs, label, enabled, system_id, updated_by,
                  status, reviewed_by, reviewed_at, review_note, request_note)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9,
                     $10, $11, CASE WHEN $11::text IS NULL THEN NULL ELSE now() END, $12, $13)
             RETURNING id::text`,
} as const;
