"use client";
import { createContext, useCallback, useContext, useEffect, useState } from "react";
import type { SubAccountDetail } from "@/lib/reseller-accounts";

/**
 * One sub-account, fetched once by the frame its tabs sit in and shared with them, so the header's
 * balance and the Balance tab's tiles are the same read and refresh together after a recharge.
 */

export type { SubAccountDetail };

export interface SubAccountState {
  id: string;
  account: SubAccountDetail | null;
  error: string;
  loading: boolean;
  reload: () => Promise<void>;
}

const SubAccountContext = createContext<SubAccountState | null>(null);

/** The portal API's JSON, or its error sentence thrown. */
export async function misJson<T>(url: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(url, {
      ...init,
      headers: init?.body ? { "Content-Type": "application/json", ...init.headers } : init?.headers,
    });
  } catch {
    throw new Error("Could not reach the portal. Nothing was changed.");
  }
  const json = await res.json().catch(() => null);
  if (!res.ok) {
    throw new Error(json?.error ?? `Request failed (${res.status})`);
  }
  return json?.data as T;
}

export function subAccountApi(id: string, path = ""): string {
  return `/api/mis/sub-accounts/${encodeURIComponent(id)}${path}`;
}

export function SubAccountProvider({ id, children }: { id: string; children: React.ReactNode }) {
  const [account, setAccount] = useState<SubAccountDetail | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  const reload = useCallback(async () => {
    try {
      setAccount(await misJson<SubAccountDetail>(subAccountApi(id)));
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    void reload();
  }, [reload]);

  return (
    <SubAccountContext.Provider value={{ id, account, error, loading, reload }}>
      {children}
    </SubAccountContext.Provider>
  );
}

export function useSubAccount(): SubAccountState {
  const value = useContext(SubAccountContext);
  if (!value) {
    throw new Error("useSubAccount outside SubAccountProvider");
  }
  return value;
}

/**
 * A v4 UUID for an idempotency key. `crypto.randomUUID` exists only in a secure context, and panels
 * are served over plain HTTP on a LAN; `getRandomValues` is available in both.
 */
export function newIdempotencyKey(): string {
  const b = crypto.getRandomValues(new Uint8Array(16));
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const h = Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}
