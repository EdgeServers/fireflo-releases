"use client";
import type { SecuritySurface } from "@/lib/security-events";
import { surfaceLabel } from "@/lib/security-events";
import { SURFACES, type Bucket } from "@/lib/security-grouping";
import { formatDay, formatHour, formatHourSpan, zoneShortName } from "@/lib/datetime";
import { useDisplayZone } from "@/components/DisplayZoneProvider";
import { DayNote } from "@/components/DayNote";

/** A colour per surface, used by the chart, its legend and the badges alike. */
export const SURFACE_TONE: Record<SecuritySurface, { bar: string; badge: string }> = {
  smpp: { bar: "bg-chart-1/80", badge: "bg-chart-1/10 text-chart-1" },
  rest: { bar: "bg-chart-3/80", badge: "bg-chart-3/10 text-chart-3" },
  grpc: { bar: "bg-chart-5/80", badge: "bg-chart-5/10 text-chart-5" },
  panel: { bar: "bg-chart-4/80", badge: "bg-chart-4/10 text-chart-4" },
  portal: { bar: "bg-chart-2/80", badge: "bg-chart-2/10 text-chart-2" },
};

export function SurfaceBadge({ surface, count }: { surface: SecuritySurface; count?: number }) {
  return (
    <span className={`whitespace-nowrap rounded px-2 py-0.5 text-xs font-medium ${SURFACE_TONE[surface].badge}`}>
      {surfaceLabel(surface)}{count !== undefined ? ` ${count}` : ""}
    </span>
  );
}

/** The five surfaces, as the chart colours them. */
export function Legend({ className = "" }: { className?: string }) {
  return (
    <div className={`flex flex-wrap gap-3 text-xs text-muted-foreground ${className}`}>
      {SURFACES.map((s) => (
        <span key={s} className="flex items-center gap-1.5">
          <span className={`size-2.5 rounded-sm ${SURFACE_TONE[s].bar}`} aria-hidden />
          {surfaceLabel(s)}
        </span>
      ))}
    </div>
  );
}

/**
 * Refusals per hour or per day, stacked by surface.
 *
 * <p>Bars rather than a chart library: one small series, no interaction beyond a tooltip, and the
 * point is the shape of a burst -- which surface, and when -- rather than a readable value per bar.
 */
export function RefusalChart({ buckets, hourly }: { buckets: Bucket[]; hourly: boolean }) {
  const { zone, billingZone } = useDisplayZone();
  const peak = Math.max(...buckets.map((b) => b.total), 1);
  //an hour by its start in the display zone; a day by its own billing-day name
  const label = (b: Bucket) => (hourly || !b.day ? formatHour(b.start, zone) : formatDay(b.day));
  const title = (b: Bucket) =>
    hourly || !b.day ? formatHourSpan(b.start, zone) : `${formatDay(b.day, { year: true })} (${zoneShortName(billingZone)} day)`;
  const ticks = [0, Math.floor(buckets.length / 2), buckets.length - 1];
  return (
    <div>
      <div className="flex h-24 items-end gap-0.5" role="img"
        aria-label={`Refusals per ${hourly ? "hour" : "day"}, peak ${peak}`}>
        {buckets.map((b) => (
          <div key={b.start} className="flex h-full flex-1 flex-col justify-end"
            title={`${title(b)} — ${b.total}${b.total ? ": " + SURFACES.filter((s) => b.bySurface[s]).map((s) => `${surfaceLabel(s)} ${b.bySurface[s]}`).join(", ") : ""}`}>
            {b.total === 0 ? (
              //a quiet slice still draws a hairline, so it reads as quiet rather than missing
              <div className="h-px bg-border" />
            ) : (
              SURFACES.filter((s) => b.bySurface[s] > 0).map((s) => (
                <div key={s} className={`w-full first:rounded-t-sm ${SURFACE_TONE[s].bar}`}
                  style={{ height: `${(b.bySurface[s] / peak) * 100}%` }} />
              ))
            )}
          </div>
        ))}
      </div>
      <div className="relative mt-1.5 flex justify-between text-xs text-muted-foreground" suppressHydrationWarning>
        {ticks.map((i) => <span key={i}>{label(buckets[i])}</span>)}
      </div>
      <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1">
        <Legend />
        <span className="ml-auto text-xs text-muted-foreground">peak {peak} in {hourly ? "an hour" : "a day"}</span>
      </div>
      {!hourly && <DayNote className="mt-1" />}
    </div>
  );
}
