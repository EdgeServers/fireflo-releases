"use client";

import { useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { EmptyState } from "@/components/ui/empty-state";
import { Select } from "@/components/ui/select";
import { Tabs } from "@/components/ui/tabs";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import { HealthStrip } from "@/components/CardBits";
import { NeedsCapability } from "@/components/NeedsCapability";
import { Pager } from "@/components/Pager";
import { usePaging } from "@/components/usePaging";
import type { RefusalSummaryRow } from "@/lib/ban-rules";
import { REFUSAL_LEDGER } from "@/lib/capabilities";
import type { BindHold } from "@/lib/force-disconnect";
import type { Health } from "@/lib/health-types";
import { FAIL2BAN_SCOPE, isNonBannable, listenerLabel } from "@/lib/refusal-views";
import { reasonLabel, surfaceLabel, type BlockedAddress, type SecurityEvent, type SecuritySurface } from "@/lib/security-events";
import { short, when } from "@/lib/security-format";
import { SURFACES, displayIp, type Bucket } from "@/lib/security-grouping";
import {
  FALLBACK_JAILS,
  addressRowsFrom,
  attemptsFrom,
  listenerOptions,
  portLabel,
  reasonOptions,
  type LedgerPayload,
  type RowFilter,
} from "@/lib/security-rows";
import { AddressTable, type RowActions } from "./AddressTable";
import { AutomaticBans, type RulesPayload } from "./AutomaticBans";
import { BanPanel } from "./BanPanel";
import { RefusalChart, SurfaceBadge } from "./RefusalChart";
import { useDisplayZone } from "@/components/DisplayZoneProvider";
import { localeNumber } from "@/lib/format";

/** What each source said about itself, from `/api/control/security`. */
export interface SourceState {
  reachable?: boolean;
  present?: boolean;
  state?: string | null;
  truncated?: boolean;
  note?: string | null;
  path?: string;
  /** True when the list came from fail2ban itself rather than from the notify action's file. */
  live?: boolean;
  historyPresent?: boolean;
  canUnban?: boolean;
  unbanCommand?: string;
}

export interface Sources {
  gateway: SourceState;
  operator: SourceState;
  fail2ban: SourceState;
}

type Tab = "address" | "port" | "attempt";

const TABS = [
  { id: "address", label: "By address" },
  { id: "port", label: "By server port" },
  { id: "attempt", label: "Every attempt" },
] as const satisfies readonly { id: Tab; label: string }[];

const PAGE_SIZES = [25, 50, 100] as const;

/**
 * The one card of refused logins: the chart, three views of the same rows, one filter row, and
 * the rules that ban without anybody pressing anything.
 *
 * <p>The three views are tabs over the same filter, not three cards: the address working through
 * system ids on 2775 is often the one trying the panel afterwards, and the question "what did this
 * address do" is answered by switching tabs with the filter still set, not by finding the address
 * again in another table.
 *
 * <p><strong>Every source says separately why it is empty.</strong> A gateway that cannot be
 * reached, a refusal log that is switched off, and a host with no fail2ban all produce no rows, and
 * an operator has to be able to tell which. That is why {@link SourceNotes} renders them rather
 * than summarising into one "nothing to show".
 */
export function RefusalsCard({
  rangeLabel,
  hourly,
  events,
  buckets,
  ledger,
  ledgerSupported,
  ledgerError,
  health,
  healthLoading,
  healthError,
  blocked,
  holds,
  sources,
  now,
  loading,
  notice,
  problem,
  rowActions,
  banBusy,
  onBan,
  admin,
  rules,
  rulesError,
  onReload,
}: {
  rangeLabel: string;
  hourly: boolean;
  /** Everything in the range, every surface. */
  events: SecurityEvent[];
  buckets: Bucket[];
  ledger: LedgerPayload | null;
  ledgerSupported: boolean;
  ledgerError: string | null;
  health: Health | null;
  healthLoading: boolean;
  healthError: string | null;
  blocked: BlockedAddress[];
  holds: BindHold[];
  sources: Sources | undefined;
  now: number;
  loading: boolean;
  /** A line about the last action that took: "203.0.113.9 is now banned in fireflo-gateway." */
  notice: string | null;
  /** A line about the last action that did not. */
  problem: string | null;
  rowActions: Omit<RowActions, "onBan" | "canBan">;
  banBusy: boolean;
  onBan: (ip: string, jail: string, seconds: number | null) => Promise<boolean>;
  admin: boolean;
  rules: RulesPayload | null;
  rulesError: string | null;
  onReload: () => Promise<void>;
}) {
  const { zone, short: zoneShort } = useDisplayZone();
  const [tab, setTab] = useState<Tab>("address");
  const [surface, setSurface] = useState<SecuritySurface | "all">("all");
  const [listener, setListener] = useState("");
  const [reason, setReason] = useState("");
  const [pageSize, setPageSize] = useState<number>(PAGE_SIZES[0]);
  const [banTarget, setBanTarget] = useState<string | null>(null);

  const listeners = useMemo(() => ledger?.listeners ?? null, [ledger]);
  const filter: RowFilter = useMemo(
    () => ({ surface, listener: listener || null, reason: reason || null }),
    [surface, listener, reason]
  );
  const rows = useMemo(() => addressRowsFrom(events, listeners, blocked, holds, filter), [events, listeners, blocked, holds, filter]);
  const attempts = useMemo(() => attemptsFrom(events, filter), [events, filter]);
  const reasons = useMemo(() => reasonOptions(events, listeners), [events, listeners]);
  const ports = useMemo(() => listenerOptions(events, listeners), [events, listeners]);
  const byAttempt = usePaging(attempts, pageSize);

  const jails = ledger?.jails ?? FALLBACK_JAILS;
  const canBan = ledger ? ledger.fail2banAvailable && jails.length > 0 : Boolean(sources?.fail2ban.canUnban);
  const actions: RowActions = { ...rowActions, canBan, onBan: setBanTarget };
  const emptyText = loading ? "Reading…" : `No refused logins in the last ${rangeLabel}${surface !== "all" || listener || reason ? " match this filter" : ""}.`;

  const banPanel = banTarget && (
    <BanPanel
      key={banTarget}
      ip={banTarget}
      jails={jails}
      canBan={canBan}
      busy={banBusy}
      onCancel={() => setBanTarget(null)}
      onBan={(jail, seconds) => {
        void onBan(banTarget, jail, seconds).then((ok) => {
          if (ok) {
            setBanTarget(null);
          }
        });
      }}
    />
  );

  return (
    <Card className="min-w-0">
      <CardHeader className="flex-row flex-wrap items-center gap-2 space-y-0">
        <CardTitle>Refused logins</CardTitle>
        {health && !ledgerSupported && (
          <Badge variant="info" title="The By server port view, the Port and Reason filters and the rules read the gateway's refusal ledger, which this gateway does not publish">
            per-port data needs gateway 0.13
          </Badge>
        )}
        <span className="ml-auto text-xs text-muted-foreground">{loading ? "Reading…" : `last ${rangeLabel}`}</span>
      </CardHeader>

      <div className="px-4 pb-3 max-sm:px-3">
        {buckets.length ? (
          <RefusalChart buckets={buckets} hourly={hourly} />
        ) : (
          <p className="text-sm text-muted-foreground">{loading ? "Reading…" : "Nothing to chart."}</p>
        )}
      </div>

      <Tabs label="Refusals view" items={TABS} active={tab} onSelect={(next) => { setTab(next); setBanTarget(null); }}
        className="px-4 max-sm:px-3" />

      {/* one filter row for every tab, so switching tabs keeps the question */}
      <div className="flex flex-wrap items-center gap-2 border-b border-border bg-muted/40 px-4 py-2.5 max-sm:px-3">
        <Select aria-label="Surface" className="w-auto" value={surface}
          onChange={(e) => { setSurface(e.target.value as SecuritySurface | "all"); byAttempt.reset(); }}>
          <option value="all">Every surface</option>
          {SURFACES.map((s) => <option key={s} value={s}>{surfaceLabel(s)}</option>)}
        </Select>
        <Select aria-label="Port" className="w-auto" value={listener} disabled={!ledgerSupported && ports.length === 0}
          title={ledgerSupported ? undefined : "Per-port data needs gateway 0.13"}
          onChange={(e) => { setListener(e.target.value); byAttempt.reset(); }}>
          <option value="">Every listener</option>
          {ports.map((p) => <option key={p.listener!} value={p.listener!}>{portLabel(p)}</option>)}
        </Select>
        <Select aria-label="Reason" className="w-auto" value={reason} disabled={!ledgerSupported}
          title={ledgerSupported ? undefined : "Per-port data needs gateway 0.13"}
          onChange={(e) => { setReason(e.target.value); byAttempt.reset(); }}>
          <option value="">Any reason</option>
          {reasons.map((r) => (
            <option key={r.reason} value={r.reason}>
              {reasonLabel(r.reason)} ({r.count}){isNonBannable(r.reason) ? " — not banned by rules" : ""}
            </option>
          ))}
        </Select>
        <Select aria-label="Rows per page" className="ml-auto w-auto" value={pageSize}
          onChange={(e) => { setPageSize(Number(e.target.value)); byAttempt.reset(); }}>
          {PAGE_SIZES.map((n) => <option key={n} value={n}>Show {n}</option>)}
        </Select>
      </div>

      {(notice || problem || ledgerError) && (
        <div className="space-y-2 px-4 pt-3 max-sm:px-3">
          {problem && <HealthStrip tone="destructive">{problem}</HealthStrip>}
          {ledgerError && <HealthStrip tone="warning">{ledgerError}</HealthStrip>}
          {notice && <HealthStrip tone="info">{notice}</HealthStrip>}
        </div>
      )}
      <SourceNotes sources={sources} />

      {tab === "address" && (
        <div className="pt-1">
          <AddressTable rows={rows} pageSize={pageSize} now={now} loading={loading} empty={emptyText} actions={actions} under={banPanel} />
        </div>
      )}

      {tab === "port" && (
        <div className="pt-1">
          <div className="px-4 pt-3 max-sm:px-3">
            <NeedsCapability health={health} loading={healthLoading} error={healthError} name={REFUSAL_LEDGER} feature="a refusal ledger">
              {!listeners?.length ? (
                <EmptyState>{loading ? "Reading…" : `No refused binds, REST credentials or gRPC logins in the last ${rangeLabel}.`}</EmptyState>
              ) : (
                <ListenerTiles rows={listeners} active={listener} onPick={(name) => setListener(listener === name ? "" : name)} />
              )}
              <p className="mt-3 text-xs text-muted-foreground" data-testid="fail2ban-scope">{FAIL2BAN_SCOPE}</p>
            </NeedsCapability>
          </div>
          {ledgerSupported && (
            <div className="pt-3">
              <AddressTable rows={rows} pageSize={pageSize} now={now} loading={loading} empty={emptyText} actions={actions} under={banPanel} />
            </div>
          )}
        </div>
      )}

      {tab === "attempt" && (
        !attempts.length ? (
          <div className="p-4"><EmptyState>{emptyText}</EmptyState></div>
        ) : (
          <div className="pt-1">
            <TableInCard>
              <THead>
                <tr>
                  <TH>When ({zoneShort})</TH>
                  <TH>Surface</TH>
                  <TH>Port</TH>
                  <TH>Reason</TH>
                  <TH>Tried as</TH>
                  <TH>Address</TH>
                </tr>
              </THead>
              <TBody>
                {byAttempt.shown.map((event, i) => (
                  <TR key={`${event.at}-${event.ip}-${byAttempt.page}-${i}`}>
                    <TD muted className="whitespace-nowrap text-xs" title={when(event.at, zone)}>{short(event.at, now, zone)}</TD>
                    <TD><SurfaceBadge surface={event.surface} /></TD>
                    <TD muted className="whitespace-nowrap font-mono text-xs">
                      {event.listener !== undefined || event.port !== undefined
                        ? portLabel({ listener: event.listener ?? null, port: event.port ?? null })
                        : "—"}
                    </TD>
                    <TD className="whitespace-nowrap">{reasonLabel(event.reason)}</TD>
                    <TD muted className="font-mono">{event.triedAs ?? "—"}</TD>
                    <TD className="font-mono">{displayIp(event.ip)}</TD>
                  </TR>
                ))}
              </TBody>
            </TableInCard>
            <div className="px-4 pb-1">
              <Pager page={byAttempt.page} pages={byAttempt.pages} total={attempts.length} noun="refused logins" onPage={byAttempt.setPage} />
            </div>
          </div>
        )
      )}

      {/* admin only, like its route: a rule bans at the host with nobody pressing anything */}
      {admin && (
        <CardContent className="mt-4 border-t border-border pt-4">
          <AutomaticBans payload={rules} error={rulesError} now={now} onReload={onReload} />
        </CardContent>
      )}
    </Card>
  );
}

/** One tile per listener: the port, how many, and the reasons -- the shape of the traffic before any one address is looked at. Click to filter. */
function ListenerTiles({ rows, active, onPick }: { rows: RefusalSummaryRow[]; active: string; onPick: (listener: string) => void }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
      {rows.map((row) => {
        const name = row.listener ?? "";
        const on = Boolean(name) && active === name;
        return (
          <button
            key={`${row.listener}|${row.port}`}
            type="button"
            onClick={() => name && onPick(name)}
            aria-pressed={on}
            disabled={!name}
            className={`rounded-lg border p-3 text-left transition-colors hover:bg-muted/50 disabled:cursor-default disabled:hover:bg-transparent ${on ? "border-primary bg-muted" : "border-border"}`}
          >
            <div className="flex items-baseline justify-between gap-2">
              <span className="truncate font-mono text-sm font-medium">{listenerLabel(row)}</span>
              <span className="text-title tabular-nums">{localeNumber(row.total)}</span>
            </div>
            <p className="mt-1 text-xs text-muted-foreground">
              {row.byAddress.length} address{row.byAddress.length === 1 ? "" : "es"}
            </p>
            <div className="mt-2 flex flex-wrap gap-1">
              {[...row.byReason].sort((a, b) => b.count - a.count).map((r) => (
                <Badge key={r.reason} variant={isNonBannable(r.reason) ? "outline" : "destructive"} title={reasonLabel(r.reason)}>
                  {r.reason} {r.count}
                </Badge>
              ))}
            </div>
          </button>
        );
      })}
    </div>
  );
}

/**
 * Why a source has nothing, in its own words.
 *
 * <p>Rendered rather than folded into a single message. "The gateway is unreachable", "the log is
 * switched off" and "nobody has failed to log in" are three different pieces of news, and only the
 * last one is good.
 */
function SourceNotes({ sources }: { sources: Sources | undefined }) {
  if (!sources) {
    return null;
  }
  const notes: string[] = [];
  if (sources.gateway.reachable === false && sources.gateway.note) {
    notes.push(sources.gateway.note);
  }
  if (sources.gateway.state === "disabled" && sources.gateway.note) {
    notes.push(sources.gateway.note);
  }
  if (sources.gateway.truncated) {
    notes.push(
      "The gateway's refusal log was longer than the window read, so the oldest entries in it are "
        + "not shown here."
    );
  }
  if (sources.operator.note) {
    notes.push(sources.operator.note);
  }
  if (notes.length === 0) {
    return null;
  }
  return (
    <div className="mx-4 mt-3 space-y-1 rounded-md border border-border bg-muted/40 p-3 text-sm text-muted-foreground max-sm:mx-3">
      {notes.map((note) => (
        <p key={note}>{note}</p>
      ))}
    </div>
  );
}
