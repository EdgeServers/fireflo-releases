/**
 * EP-17 Operator Panel — Sign-in & Access Control
 * US-17.01 Operator sign-in
 */
import { expect, test } from "../../fixtures";
import { cookieValue, freshRequestContext, OPERATOR_COOKIE, operatorSignIn, operatorSignInRaw } from "../../fixtures/auth";
import { startPanelVariant } from "../../fixtures/panel-variant";
import { panelLog } from "../../support/panel-logs";
import { lanAddress, signInOperator, signInOperatorOk, signInOperatorRefused, signOutOperator } from "../../support/flows/operator";
import { tc } from "../../support/tc";

test.describe("SC-17.01.01 Sign-in outcomes", () => {
  test(...tc("TC-17.01.01-P01", "Correct credentials land on /cp"), async ({ anonPage, anonContext, env, tcx }) => {
    const since = panelLog.mark();
    await signInOperatorOk(anonPage);
    const cookie = (await anonContext.cookies()).find((c) => c.name === OPERATOR_COOKIE);
    expect(cookie, "the operator session cookie is set").toBeTruthy();
    const line = await panelLog.waitOperator(since, (l) => l.event === "signin" && l.actor === env.operator.username);
    expect(line.ip, "the audit line names the peer address").toBeTruthy();
    tcx.note(`landed on ${anonPage.url()}; signin logged for ${line.actor} from ${line.ip}`);
  });

  test(...tc("TC-17.01.01-P02", "Sign out clears the session"), async ({ anonPage, anonContext, env, tcx }) => {
    await signInOperatorOk(anonPage);
    const since = panelLog.mark();
    await signOutOperator(anonPage);
    const cookies = await anonContext.cookies();
    expect(cookies.find((c) => c.name === OPERATOR_COOKIE), "cookie cleared").toBeFalsy();
    await anonPage.goto("/cp");
    await expect(anonPage).toHaveURL(/\/cp\/login/);
    const line = await panelLog.waitOperator(since, (l) => l.event === "signout" && l.actor === env.operator.username);
    tcx.note(`signout logged at ${line.ts}; /cp redirected to ${anonPage.url()}`);
  });

  test(...tc("TC-17.01.01-N01", "Wrong password gives a generic message and is logged once"), async ({ anonPage, operatorApi, env, tcx }) => {
    const triedAs = `qa-nobody-${Date.now().toString(36)}`;
    const since = panelLog.mark();
    const wrongPassword = await signInOperatorRefused(anonPage, { username: env.operator.username, password: "not-the-password" });
    const wrongUser = await signInOperatorRefused(anonPage, { username: triedAs, password: env.operator.password });
    expect(wrongPassword, "the message must not say which half was wrong").toBe(wrongUser);
    expect(wrongPassword.toLowerCase()).not.toMatch(/password (is|was) (wrong|incorrect)|unknown user|no such user/);
    // one operator line and one auth-failed line per refusal, no more
    await panelLog.waitOperator(since, (l) => l.event === "signin_failed" && l.actor === triedAs);
    const failed = panelLog.operator(since).filter((l) => l.event === "signin_failed");
    const refusals = panelLog.authFailed(since).filter((l) => l.surface === "panel");
    expect(failed.length, "signin_failed once per attempt").toBe(2);
    expect(refusals.length, "auth-failed once per attempt").toBe(2);
    expect(refusals.filter((l) => l.triedAs === triedAs).length).toBe(1);
    // and the Security page counts it once
    const sec = await operatorApi.get("/api/control/security");
    expect(sec.status()).toBe(200);
    const text = await sec.text();
    expect(text.split(triedAs).length - 1, "counted once on /cp/security").toBe(1);
    tcx.note(`message: "${wrongPassword}"; ${failed.length} signin_failed, ${refusals.length} panel refusals`);
  });

  test(...tc("TC-17.01.01-N02", "Unset password disables sign-in entirely", { requires: ["variants"] }), async ({ env, tcx }) => {
    // no database means no app_user rows, which is the only state in which the deprecated env
    // fallback is consulted at all -- and with OPERATOR_PASSWORD unset too, nothing is accepted
    const v = await startPanelVariant("no-operator-password", { OPERATOR_PASSWORD: undefined, CONFIG_DATABASE_URL: "" });
    try {
      const ctx = await freshRequestContext(v.url);
      const right = await operatorSignIn(ctx, env.operator, v.url);
      const empty = await operatorSignIn(ctx, { username: env.operator.username, password: "" }, v.url);
      const other = await operatorSignIn(ctx, { username: env.operator.username, password: "anything" }, v.url);
      await ctx.dispose();
      expect(right.signedIn, "the configured password is refused too").toBe(false);
      expect(empty.signedIn).toBe(false);
      expect(other.signedIn).toBe(false);
      await expect.poll(() => v.output()).toContain("OPERATOR_PASSWORD is not set");
      tcx.note("three attempts refused; 'OPERATOR_PASSWORD is not set' logged");
    } finally {
      await v.stop();
    }
  });

  test(...tc("TC-17.01.01-N03", "Unauthenticated /cp redirects, unauthenticated API is 404"), async ({ anonPage, anonContext, tcx }) => {
    await anonPage.goto("/cp/accounts");
    await expect(anonPage).toHaveURL(/\/cp\/login/);
    const res = await anonContext.request.get("/api/control/accounts");
    expect(res.status(), "never 401/403").toBe(404);
    expect(await res.json()).toEqual({ error: "Not found" });
    tcx.note(`page → ${anonPage.url()}; API ${res.status()} ${await res.text()}`);
  });
});

test.describe("SC-17.01.02 Cookie security flag", () => {
  test(...tc("TC-17.01.02-P01", "AUTH_COOKIE_SECURE=false works over http"), async ({ anonPage, env, tcx }) => {
    const ctx = await freshRequestContext();
    const { response, setCookie } = await operatorSignInRaw(ctx, env.operator);
    await ctx.dispose();
    const cookie = cookieValue(setCookie, OPERATOR_COOKIE);
    expect(cookie, "the callback sets the session cookie").toBeTruthy();
    expect(cookie!.attrs, "no Secure attribute on http with AUTH_COOKIE_SECURE=false").not.toContain("secure");
    // and the browser actually stays signed in
    await signInOperatorOk(anonPage);
    await anonPage.goto("/cp/accounts");
    await expect(anonPage).toHaveURL(/\/cp\/accounts/);
    tcx.note(`callback ${response.status()}; cookie attrs ${cookie!.attrs.join(" ")}`);
  });

  test(...tc("TC-17.01.02-P02", "Production without the variable is Secure", { requires: ["variants"] }), async ({ env, tcx }) => {
    const v = await startPanelVariant("prod-secure-default", { AUTH_COOKIE_SECURE: undefined });
    try {
      const ctx = await freshRequestContext(v.url);
      const { setCookie } = await operatorSignInRaw(ctx, env.operator, v.url);
      await ctx.dispose();
      const cookie = cookieValue(setCookie, OPERATOR_COOKIE);
      expect(cookie).toBeTruthy();
      expect(cookie!.attrs).toContain("secure");
      tcx.note(`cookie attrs ${cookie!.attrs.join(" ")}`);
    } finally {
      await v.stop();
    }
  });

  test(...tc("TC-17.01.02-N01", "AUTH_COOKIE_SECURE=true over http cannot stay signed in", { requires: ["variants"] }), async ({ anonPage, env, tcx }) => {
    const v = await startPanelVariant("secure-true-over-http", { AUTH_COOKIE_SECURE: "true" });
    try {
      // the callback answers with a Secure cookie…
      const ctx = await freshRequestContext(v.url);
      const { setCookie } = await operatorSignInRaw(ctx, env.operator, v.url);
      await ctx.dispose();
      expect(cookieValue(setCookie, OPERATOR_COOKIE)!.attrs).toContain("secure");
      // …which a browser will not send back over plain http, so the sign-in cannot stick.
      // NOT on loopback: Chromium treats 127.0.0.1 as a secure context and DOES send Secure cookies
      // there, which would pass this case for the wrong reason. The host's LAN address is not.
      const lan = lanAddress();
      test.skip(!lan, "blocked: this host has no non-loopback IPv4 address to reach the panel on");
      const url = `http://${lan}:${v.port}`;
      await signInOperator(anonPage, env.operator, url);
      await anonPage.waitForLoadState("networkidle");
      await anonPage.goto(`${url}/cp/accounts`);
      await expect(anonPage).toHaveURL(/\/cp\/login/);
      tcx.note(`via ${url}: after signing in, /cp/accounts bounced to ${anonPage.url()}`);
    } finally {
      await v.stop();
    }
  });

  test(...tc("TC-17.01.02-N02", "AUTH_URL with a path warns but does not crash", { requires: ["variants"] }), async ({ tcx }) => {
    const v = await startPanelVariant("auth-url-with-path", {});
    await v.stop();
    const v2 = await startPanelVariant("auth-url-with-path", { AUTH_URL: `http://127.0.0.1:${v.port}/cp` });
    try {
      const res = await fetch(`${v2.url}/cp/login`);
      expect(res.status).toBe(200);
      await fetch(`${v2.url}/api/auth/csrf`);
      await expect.poll(() => v2.output(), { timeout: 15_000 }).toMatch(/AUTH_URL is ".*", which has a path/);
      tcx.note("warning printed; /cp/login 200");
    } finally {
      await v2.stop();
    }
  });
});
