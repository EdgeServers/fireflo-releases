"use client";
import { useMemo, useState } from "react";
import Link from "next/link";
import { ArrowRight, ShieldAlert, ShieldCheck, ShieldOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from "@/components/ui/card";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { ErrorCard } from "./FormNotices";
import { ConfirmDialog } from "./ConfirmDialog";
import { Pager } from "./Pager";
import { SearchInput } from "./SearchInput";
import { usePaging } from "./usePaging";
import { GatewayIgnores } from "./GatewayIgnores";
import { useWhitelist } from "./useWhitelist";
import { WhitelistReview, WhitelistStatusBadge, pendingFirst } from "./WhitelistReview";
import { rowTlvGaps, tlvGapSummary, vendorsForProduct } from "@/lib/tlv-coverage";
import { effectiveMode, previewTemplate, type WhitelistMode } from "@/lib/whitelist-types";

const PAGE_SIZE = 25;

/**
 * Every approved sender ID, or every approved template, across all accounts.
 *
 * <p>This page answers the question the account page cannot: *who else has this?*
 *
 * <h2>It used to be read-only, and that was two mistakes rather than one</h2>
 *
 * <p>The recorded reason was that approving belongs beside the enforcement switch and the count that
 * says whether enforcing is safe. Both of those are on this page now — the **Enforced** column is on
 * every row, and so are the TLV gap lines — so the objection has been answered by the page itself
 * rather than overruled.
 *
 * <p>The second mistake was quieter and was a live defect: this list never filtered to approved rows
 * and never showed the status, so a customer's *request* rendered here indistinguishable from an
 * approval. A page that exists to say who else has a sender ID was counting requests as answers.
 * That is why the badge and the pending filter arrive together with the review buttons: showing the
 * state is the fix, and deciding it here is what an operator does next.
 *
 * <p>Bulk **approve** only. A refusal has to carry a reason the customer is shown, so there is
 * nothing to apply in bulk — and the bulk path loops the same per-row PATCH rather than adding an
 * endpoint of its own, so each decision is recorded against its own reviewer and timestamp.
 */
export function WhitelistIndexClient({ kind }: { kind: "headers" | "templates" }) {
  const { headers, templates, summaries, coverage, error, loading, busy, review } = useWhitelist();
  const [query, setQuery] = useState("");
  const [pendingOnly, setPendingOnly] = useState(false);
  const [picked, setPicked] = useState<Set<number>>(new Set());
  const [confirming, setConfirming] = useState(false);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [bulkError, setBulkError] = useState("");

  const all = useMemo(() => {
    //`effectiveMode`, not an exact-then-fallback lookup: the gateway merges, so a product row
    //sitting at OFF under an enforcing account is enforcing. This page used to get that wrong
    const modeOf = (accountId: string, product: string) =>
      effectiveMode(summaries, accountId, product, kind === "headers" ? "header" : "content");

    //what a row will fail to put on the wire, so an operator can find every such row across every
    //account -- the question this page exists for and the account page cannot answer
    const gapsOf = (accountId: string, product: string, tlvs: string | null) => rowTlvGaps({
      tlvs, accountId, product,
      kind: kind === "headers" ? "header" : "content",
      mode: modeOf(accountId, product),
      //a message is stamped by both matches, so the other list counts as a supplier here too
      siblings: {
        mode: effectiveMode(summaries, accountId, product,
          kind === "headers" ? "content" : "header"),
        tlvs: (kind === "headers" ? templates : headers)
          .filter((r) => r.accountId === accountId && r.status === "APPROVED" && r.enabled
            && (!product || !r.product || r.product === product))
          .map((r) => r.tlvs),
      },
      mandatory: coverage.mandatory,
      logins: coverage.logins,
      vendors: vendorsForProduct(coverage.vendors, product),
    });

    const rows = kind === "headers"
      ? headers.map((h) => ({
          key: `h-${h.id}`,
          id: h.id,
          accountId: h.accountId,
          product: h.product,
          systemId: h.systemId,
          primary: h.header,
          secondary: "",
          tlvs: h.tlvs,
          gaps: gapsOf(h.accountId, h.product, h.tlvs),
          enabled: h.enabled,
          status: h.status,
          mode: modeOf(h.accountId, h.product),
        }))
      : templates.map((t) => ({
          key: `t-${t.id}`,
          id: t.id,
          accountId: t.accountId,
          product: t.product,
          systemId: t.systemId,
          primary: t.name || "Untitled",
          secondary: previewTemplate(t.body),
          tlvs: t.tlvs,
          gaps: gapsOf(t.accountId, t.product, t.tlvs),
          enabled: t.enabled,
          status: t.status,
          mode: modeOf(t.accountId, t.product),
        }));

    //ordered before filtering and paging, so a request is never paged out of sight
    return pendingFirst(rows);
  }, [kind, headers, templates, summaries, coverage]);

  const waiting = all.filter((r) => r.status === "PENDING").length;

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return all.filter((r) =>
      (!pendingOnly || r.status === "PENDING")
      && (!q
        || r.accountId.toLowerCase().includes(q)
        || r.primary.toLowerCase().includes(q)
        || r.secondary.toLowerCase().includes(q)
        //the stamps are a column on this table and were not searchable, which is how you find every
        //registration carrying one entity ID across all accounts
        || (r.tlvs ?? "").toLowerCase().includes(q)
        || (r.systemId ?? "").toLowerCase().includes(q)
        || r.product.toLowerCase().includes(q)
        //so typing peid_0x1400 finds every row that fails to supply it, anywhere
        || r.gaps.some((g) => g.token.toLowerCase().includes(q))));
  }, [all, query, pendingOnly]);

  const { page, pages, shown, setPage, reset } = usePaging(rows, PAGE_SIZE);
  const noun = kind === "headers" ? "sender ID" : "template";

  //only pending rows can be picked, so the count on the button is always the number that will change
  const pickable = rows.filter((r) => r.status === "PENDING");
  const chosen = pickable.filter((r) => picked.has(r.id));
  const accounts = [...new Set(chosen.map((r) => r.accountId))].sort();

  function toggle(id: number) {
    setPicked((prev) => {
      const next = new Set(prev);
      if (!next.delete(id)) {
        next.add(id);
      }
      return next;
    });
  }

  /**
   * One PATCH per row, in order, stopping at the first refusal.
   *
   * <p>Sequential rather than concurrent: each call refreshes the list, and a refusal part way
   * through has to leave the operator looking at what actually landed. Stopping means the rows
   * already approved stay approved and the rest keep their tick, so retrying is the same action.
   */
  async function approveChosen() {
    setBulkBusy(true);
    setBulkError("");
    for (const row of chosen) {
      const failure = await review(kind, row.id, "APPROVED");
      if (failure) {
        setBulkError(`${row.primary} on ${row.accountId}: ${failure}`);
        setBulkBusy(false);
        return;
      }
      setPicked((prev) => {
        const next = new Set(prev);
        next.delete(row.id);
        return next;
      });
    }
    setBulkBusy(false);
    setConfirming(false);
  }

  return (
    <>
      <GatewayIgnores domain="whitelist" />
      <ErrorCard error={error} />

      <Card>
        <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0">
          <div className="min-w-0 flex-1 space-y-1.5">
            <CardTitle>
              {kind === "headers" ? "Approved sender IDs" : "Approved content"}
            </CardTitle>
            <CardDescription>
              {kind === "headers"
                ? "Every sender ID any account has had approved. A customer sending from anything else is refused, once their account is set to enforce."
                : "Every message body any account has had approved. Content that does not match one of these is refused, once their account is set to enforce."}
              {" "}Approve or refuse a request here, or open the account for the full picture.
            </CardDescription>
          </div>
          <div className="ml-auto flex flex-wrap items-center gap-2">
            {/*the count is on the toggle rather than behind it: nobody should have to filter to
               find out that nothing is waiting*/}
            <Button
              type="button"
              size="sm"
              variant={pendingOnly ? "default" : "outline"}
              aria-pressed={pendingOnly}
              disabled={!waiting && !pendingOnly}
              onClick={() => { setPendingOnly(!pendingOnly); reset(); }}
            >
              Pending approval
              <span className="ml-1.5 tabular-nums opacity-80">{waiting}</span>
            </Button>
            <SearchInput
              value={query}
              onChange={(next) => { setQuery(next); reset(); }}
              placeholder={`account, ${noun} or stamp`}
              ariaLabel={`Search approved ${kind}`}
            />
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {chosen.length > 0 && (
            <div className="flex flex-wrap items-center gap-3 rounded-md border border-border bg-muted/40 px-3 py-2 text-sm">
              <span>
                {chosen.length} {chosen.length === 1 ? "request" : "requests"} selected
                {accounts.length > 1 && <> across {accounts.length} accounts</>}
              </span>
              <Button size="sm" className="h-6 px-2" disabled={bulkBusy}
                onClick={() => { setBulkError(""); setConfirming(true); }}>
                Approve selected
              </Button>
              <Button size="sm" variant="ghost" className="h-6 px-2"
                onClick={() => setPicked(new Set())}>
                Clear
              </Button>
              {/*no bulk refuse, and this says why rather than leaving somebody hunting for the button*/}
              <span className="text-muted-foreground">
                Refusing needs a reason the customer is shown, so it stays per row.
              </span>
            </div>
          )}

          {!rows.length ? (
            <p className="py-6 text-center text-sm text-muted-foreground">
              {loading
                ? "Loading…"
                : pendingOnly
                  ? "Nothing is waiting for approval."
                  : query.trim()
                    ? `Nothing matches "${query.trim()}".`
                    : `No ${noun}s have been approved yet. Open an account to approve one.`}
            </p>
          ) : (
            <TableInCard>
              <THead>
                <TR>
                  <TH className="w-8" />
                  <TH>{kind === "headers" ? "Sender ID" : "Template"}</TH>
                  <TH>Account</TH>
                  <TH>Product</TH>
                  <TH>Enforced</TH>
                  <TH />
                </TR>
              </THead>
              <TBody>
                {shown.map((r) => (
                  <TR key={r.key}>
                    <TD>
                      {r.status === "PENDING" && (
                        <input
                          type="checkbox"
                          className="h-3.5 w-3.5 rounded border-input accent-primary"
                          checked={picked.has(r.id)}
                          onChange={() => toggle(r.id)}
                          aria-label={`Select ${r.primary} on ${r.accountId}`}
                        />
                      )}
                    </TD>
                    <TD>
                      <span className={kind === "headers" ? "font-mono" : "font-medium"}>
                        {r.primary}
                      </span>
                      {/*says nothing for an ordinary approved row, so only the states that matter
                         carry a badge. Before this, a request looked exactly like an approval*/}
                      <span className="ml-2 inline-block align-middle">
                        <WhitelistStatusBadge status={r.status} enabled={r.enabled} />
                      </span>
                      {r.secondary && (
                        <span className="block break-words font-mono text-xs text-muted-foreground">
                          {r.secondary}
                        </span>
                      )}
                      {r.tlvs && (
                        <span className="block font-mono text-xs text-muted-foreground">
                          stamps {r.tlvs}
                        </span>
                      )}
                      {r.systemId && (
                        <span className="block font-mono text-xs text-muted-foreground">
                          login {r.systemId} only
                        </span>
                      )}
                      {/*condensed, because a paragraph does not fit in a cell. The account page says
                         the whole thing, including what to do about it*/}
                      {r.gaps.map((gap) => (
                        <span key={`${gap.tag}-${gap.reason}`}
                          className="block text-xs text-amber-600 dark:text-amber-500">
                          {tlvGapSummary(gap)}
                        </span>
                      ))}
                    </TD>
                    <TD>
                      <Link href={`/cp/accounts/${encodeURIComponent(r.accountId)}`}
                        className="font-mono text-sm hover:underline">
                        {r.accountId}
                      </Link>
                    </TD>
                    <TD muted>
                      {r.product || "all"}
                    </TD>
                    <TD>
                      <ModeBadge mode={r.mode} />
                    </TD>
                    <TD>
                      <div className="flex items-center justify-end gap-3">
                        <WhitelistReview
                          status={r.status}
                          busy={busy === String(r.id)}
                          onDecide={async (status, note) => {
                            //the refusal lands in the hook's own error, which ErrorCard renders at
                            //the top of the page -- there is nowhere in a table row to put it
                            await review(kind, r.id, status, note);
                          }}
                        />
                        <Link href={`/cp/accounts/${encodeURIComponent(r.accountId)}`}
                          className="whitespace-nowrap text-sm text-primary hover:underline">
                          Manage
                          <ArrowRight className="ml-1 inline h-3 w-3" aria-hidden="true" />
                        </Link>
                      </div>
                    </TD>
                  </TR>
                ))}
              </TBody>
            </TableInCard>
          )}

          <Pager page={page} pages={pages} total={rows.length} noun={`${noun}s`} onPage={setPage} />

          <p className="text-sm text-muted-foreground">
            These are the only catalogues in this panel the gateway actually reads. A change here
            reaches it on its next configuration poll and can stop a customer sending — unlike
            products, TLV names or account labels, which are for the people reading this panel.
          </p>
        </CardContent>
      </Card>

      <ConfirmDialog
        open={confirming}
        title={`Approve ${chosen.length} ${chosen.length === 1 ? noun : `${noun}s`}`}
        consequence={
          `${chosen.length} ${chosen.length === 1 ? "registration" : "registrations"} on `
          + `${accounts.join(", ")} go into service at the gateway's next configuration poll. `
          + "Each is recorded against you individually."
        }
        confirmLabel="Approve"
        tone="primary"
        busy={bulkBusy}
        error={bulkError}
        onConfirm={approveChosen}
        onCancel={() => setConfirming(false)}
      />
    </>
  );
}

function ModeBadge({ mode }: { mode: WhitelistMode }) {
  if (mode === "ENFORCE") {
    return (
      <span className="inline-flex items-center gap-1.5 text-sm">
        <ShieldCheck className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
        Enforced
      </span>
    );
  }
  if (mode === "REPORT") {
    return (
      <span className="inline-flex items-center gap-1.5 text-sm">
        <ShieldAlert className="h-3.5 w-3.5 text-amber-500" />
        Report only
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 text-sm text-muted-foreground">
      <ShieldOff className="h-3.5 w-3.5" />
      Not checked
    </span>
  );
}
