"use client";
import { useEffect, useState } from "react";
import { Mail, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { CardActions, FactGrid, Figures, HealthStrip, type Fact } from "./CardBits";
import { OPERATOR_SURFACE, surface } from "@/lib/panel-surface";
import { ConnectionInstructionsDialog } from "./ConnectionInstructionsDialog";
import { DangerAction } from "./DangerAction";
import { CredentialForm } from "./CredentialForm";
import { Dialog } from "@/components/ui/dialog";
import { useCredentials } from "./useCredentials";
import { useHealth } from "./useHealth";
import { useProductReadiness } from "./ProductReadiness";
import { productGapSentence } from "@/lib/product-readiness";
import { readsCredentialsFromDatabase } from "@/lib/health-types";
import { type Credential, hasLimits, limitsSummary } from "@/lib/credential-types";
import { formatTimestamp } from "@/lib/datetime";
import { EmptyState } from "@/components/ui/empty-state";
import { cn } from "@/lib/utils";

/**
 * Who can connect — the SMPP and HTTP logins.
 *
 * <p>Sits above the traffic table on the Accounts page rather than replacing it. The two are keyed
 * differently and both keys are right: traffic groups by account, system id and product because that
 * is how the money splits, while a login is one row. And the traffic view has to keep working with no
 * configuration database at all, which is the ordinary case.
 */
export function CredentialsClient({
  account,
  chrome = true,
  advanced = false,
  addOpen = false,
  onAddHandled,
}: {
  account?: string;
  /** Show the rarely-touched facts on each card and the matching sections in the editor. */
  advanced?: boolean;
  /**
   * Opens the new-login form from outside.
   *
   * <p>With `chrome` off the card around this owns the "Add login" button -- it lives in the card's
   * footer, beside nothing else, where an action on the whole list belongs. That button has to be
   * able to reach this component's editing state, and this is the smallest way to let it: one
   * boolean in, one callback back when the form has taken it.
   */
  addOpen?: boolean;
  onAddHandled?: () => void;
  /**
   * Whether to render this component's own description, "Add login" button and empty-state box.
   *
   * <p>False when a card around it already supplies them -- otherwise the parent's heading and this
   * component's paragraph say the same thing twice, one under the other.
   */
  chrome?: boolean;
} = {}) {
  const { credentials: all, context, error, loading, busy, disabled, save, setEnabled, remove } =
    useCredentials();
  const { health } = useHealth();
  const [editing, setEditing] = useState<Credential | "new" | null>(null);
  const [figures, setFigures] = useState<Record<string, LoginFigures>>({});
  //the login whose connection details are being mailed. Operator only: the route reads the
  //password, and the portal has no business composing a mail that carries one
  const [instructing, setInstructing] = useState<Credential | null>(null);
  //operator-only: the report is about the tariff, and a reseller-created login carries no product
  const readiness = useProductReadiness(surface().pricing ? account : undefined);

  //adopt the parent's request to open the form, then tell it so it can reset its own flag
  useEffect(() => {
    if (addOpen) {
      setEditing("new");
      onAddHandled?.();
    }
  }, [addOpen, onAddHandled]);

  //scoped to one account when this is mounted on that account's page. `billingAccount` is resolved
  //server-side through billingOf, so this catches the logins that reach the account by the
  //system-id fallback as well -- and those are the ones worth showing, because they mention it
  //nowhere a search would find
  const credentials = account ? all.filter((c) => c.billingAccount === account) : all;

  //today's traffic per login, one request for the page. Operator surface only: the portal has no
  //metrics route, and its cards simply show no figures
  const ids = credentials.map((c) => c.systemId).filter((v): v is string => !!v).join(",");
  useEffect(() => {
    if (!ids || !surface().pricing) {
      return;
    }
    let live = true;
    fetch(`/api/control/credentials/figures?ids=${encodeURIComponent(ids)}`, { cache: "no-store" })
      .then((res) => res.json())
      .then((json) => {
        if (live && json?.data) {
          setFigures(json.data as Record<string, LoginFigures>);
        }
      })
      .catch(() => undefined);
    return () => {
      live = false;
    };
  }, [ids]);

  if (disabled) {
    return (
      <p className="text-sm text-muted-foreground">
        Editing logins is switched off — <code>CONFIG_DATABASE_URL</code> is not set.
      </p>
    );
  }


  const fromDatabase = readsCredentialsFromDatabase(health);
  //what this surface may show about what a login is charged -- see lib/panel-surface.ts
  const { pricing, apiBase } = surface();
  const canInstruct = apiBase === OPERATOR_SURFACE.apiBase;
  const gapsByLogin = new Map(
    (readiness?.gaps ?? []).map((g) => [g.systemId ?? "", productGapSentence(g)])
  );

  const form = (
    <CredentialForm
      initial={editing === "new" || editing === null ? null : editing}
      context={context}
      defaultAccountId={account}
      //product and allowed products are the price -- see CredentialForm
      allowPricing={pricing}
      advanced={advanced}
      onSave={async (input) => {
        const failure = await save(input);
        if (!failure) {
          setEditing(null);
        }
        return failure;
      }}
      onCancel={() => setEditing(null)}
    />
  );

  const list = (
    <div className="space-y-3">
      {chrome && (
        <div className="flex flex-wrap items-center gap-2">
          <p className="min-w-0 flex-1 text-sm text-muted-foreground">
            Who may connect, and which account their traffic bills to.
          </p>
          <Button onClick={() => setEditing("new")} size="sm" className="ml-auto gap-2">
            <Plus className="h-4 w-4" />
            Add login
          </Button>
        </div>
      )}

      {/* the single most destructive switch in the panel: with this table empty and the source
          flipped, no customer can connect at all, and nothing in the logs names the cause */}
      {fromDatabase === false && (
        <Card className="border-destructive">
          <CardContent className="py-4 text-sm">
            <strong>These logins are not in use.</strong> The gateway is authenticating from{" "}
            <code className="text-sm">conf/credentials.yml</code>, not the database — anything here is
            stored, valid, and ignored. Before switching it with{" "}
            <code className="text-sm">FIREFLO_CONFIG_SOURCE=db</code>, make sure this list is
            complete: an empty table refuses <em>every</em> bind and <em>every</em> REST call at once,
            with no fallback to the file. <code className="text-sm">scripts/fireflo import credentials</code>{" "}
            fills it from the file.
          </CardContent>
        </Card>
      )}

      {fromDatabase === true && !all.length && !loading && (
        <HealthStrip tone="destructive">
          <strong>The gateway is authenticating from this database, and it is empty.</strong> No
          customer can connect. Import from the file or add a login now.
        </HealthStrip>
      )}

      {error && (
        <HealthStrip tone="destructive">{error}</HealthStrip>
      )}

      {!credentials.length && !error && (
        chrome ? (
          <EmptyState>
            {loading ? "Loading…" : "No logins stored"}
          </EmptyState>
        ) : (
          <p className="py-4 text-sm text-muted-foreground">
            {loading ? "Loading…" : "No login bills to this account yet."}
          </p>
        )
      )}

      {/* one card per login. A card answers "is this login right, and is it alive" in three facts
          and three figures; the eight-column table it replaced answered it across a row too wide to
          read, and hid the facts that mattered behind a column chooser */}
      {!!credentials.length && (
        <div className="grid gap-4 xl:grid-cols-2">
          {credentials.map((c) => (
            <LoginCard
              key={c.id}
              credential={c}
              advanced={advanced}
              pricing={pricing}
              figures={c.systemId ? figures[c.systemId] : undefined}
              gap={c.systemId ? gapsByLogin.get(c.systemId) : undefined}
              busy={busy === c.id}
              onEdit={() => setEditing(c)}
              onToggle={() => setEnabled(c.id, !c.enabled)}
              onRemove={() => remove(c.id)}
              onInstruct={canInstruct && (c.type === "SMPP" || c.type === "HTTP") ? () => setInstructing(c) : undefined}
            />
          ))}
        </div>
      )}

      {instructing && (
        <ConnectionInstructionsDialog
          credential={instructing}
          apiBase={apiBase}
          onClose={() => setInstructing(null)}
        />
      )}
    </div>
  );

  /*
    Embedded, the form opens in a dialog rather than replacing the section. Swapping it out worked
    when this component owned the whole page; inside somebody else's card it would put a four-part
    form in the card's body and take the card's title away while you edited, which is the one moment
    you most want to know which account you are editing a login for.
  */
  if (editing && !chrome) {
    return (
      <>
        {list}
        <Dialog
          open
          onClose={() => setEditing(null)}
          title={editing === "new" ? "New login" : `Editing ${editing.systemId ?? `#${editing.id}`}`}
          description={account ? `Billing to ${account}.` : undefined}
          className="max-w-3xl"
        >
          {form}
        </Dialog>
      </>
    );
  }
  if (editing) {
    return form;
  }


  return list;
}

interface LoginFigures {
  sent: number;
  refused: number;
  lastSeen: string | null;
}

function LoginCard({
  credential: c,
  advanced,
  pricing,
  figures,
  gap,
  busy,
  onEdit,
  onToggle,
  onRemove,
  onInstruct,
}: {
  credential: Credential;
  advanced: boolean;
  pricing: boolean;
  figures: LoginFigures | undefined;
  /** The product-readiness sentence about this login, when there is one. */
  gap: string | undefined;
  busy: boolean;
  onEdit: () => void;
  onToggle: () => void;
  onRemove: () => void;
  /** Opens the connection-instructions mail. Absent where the card may not offer it. */
  onInstruct?: () => void;
}) {
  const auth = [
    c.password === "stored" ? "password" : null,
    c.apiKey === "stored" ? "API key" : null,
  ].filter(Boolean).join(" · ") || "none set";

  const facts: Fact[] = [
    { label: "Auth", value: auth, muted: auth === "none set" },
    ...(pricing
      ? [{ label: "Product", value: c.product ?? "— none", muted: !c.product, mono: !!c.product }]
      : []),
    {
      label: "Allowed from",
      value: c.allowedIps.length ? c.allowedIps.join(", ") : "any address",
      muted: !c.allowedIps.length,
      mono: c.allowedIps.length > 0,
    },
    //only when set: a login without limits of its own is the ordinary case and says nothing new
    ...(c.type === "SMPP" && hasLimits(c.limits)
      ? [{ label: "Limits", value: limitsSummary(c.limits) }]
      : []),
  ];
  const more: Fact[] = [
    ...(pricing && c.type !== "SMPP"
      ? [{
        label: "Allowed products",
        value: c.allowedProducts.length ? c.allowedProducts.join(", ") : "— none (field refused)",
        muted: !c.allowedProducts.length,
      }]
      : []),
    {
      label: "Default TLVs",
      value: c.defaultTlvs.length ? c.defaultTlvs.map((t) => `${t.key} = ${t.value}`).join(", ") : "—",
      muted: !c.defaultTlvs.length,
      mono: c.defaultTlvs.length > 0,
    },
    {
      label: "Bills to",
      value: `${c.billingAccount ?? "—"}${c.billingAccountFallback !== "none" ? ` · via ${c.billingAccountFallback === "apiKey" ? "API key" : "system id"}` : ""}`,
      mono: true,
    },
  ];

  return (
    <Card data-login={c.systemId ?? c.id} className={cn("min-w-0", !c.enabled && "opacity-70")}>
      <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
        {/* the system id opens the editor, the same way it does on the index */}
        <button type="button" onClick={onEdit} className="font-mono text-sm font-medium hover:underline">
          {c.systemId ?? `#${c.id}`}
        </button>
        <Badge variant="outline">{c.type}</Badge>
        <Badge variant={c.enabled ? "success" : "destructive"}>{c.enabled ? "Enabled" : "Disabled"}</Badge>
        <CardActions>
          <Button variant="outline" size="sm" onClick={onEdit}>Edit</Button>
          <Button variant="ghost" size="sm" disabled={busy}
            //disabling drops whatever this login is holding as well as refusing the next bind.
            //Stored `enabled` alone governs only future binds, so without that a login went grey
            //here while the customer carried on sending
            title={c.enabled
              ? "Refuse new binds, and drop any this login is holding now"
              : "Allow this login to bind again"}
            onClick={onToggle}>
            {c.enabled ? "Disable" : "Enable"}
          </Button>
          <DangerAction
            label="Delete"
            confirmLabel="Delete this login"
            busy={busy}
            consequence={
              `'${c.systemId ?? c.id}' stops being able to connect at the gateway's `
              + "next poll. Past call records survive, but nothing else records who "
              + "this system ID belonged to."
            }
            onConfirm={onRemove}
          />
        </CardActions>
      </CardHeader>
      <CardContent className="space-y-3 pt-3">
        {gap && (
          <HealthStrip action={<Button variant="outline" size="sm" className="h-7" onClick={onEdit}>Set a product</Button>}>
            {gap}
          </HealthStrip>
        )}
        <FactGrid facts={facts} />
        {pricing && (
          <Figures
            figures={[
              { value: figures ? figures.sent.toLocaleString() : "—", label: "sent today" },
              { value: figures ? figures.refused.toLocaleString() : "—", label: "refused", tone: figures?.refused ? "destructive" : "default" },
              { value: figures?.lastSeen ? formatTimestamp(figures.lastSeen) : "—", label: "last seen" },
            ]}
          />
        )}
        {advanced && (
          <div className="border-t border-border pt-3">
            <FactGrid facts={more} />
          </div>
        )}
        {onInstruct && (
          <div className="flex justify-end border-t border-border pt-3">
            <Button variant="outline" size="sm" className="gap-2" onClick={onInstruct}
              title="Mail this login's server, port, system ID and password to the customer">
              <Mail className="h-4 w-4" />
              Send connection instructions
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
