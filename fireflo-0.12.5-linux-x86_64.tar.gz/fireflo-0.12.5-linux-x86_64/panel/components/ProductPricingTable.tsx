"use client";
import { Fragment, useState } from "react";
import { ChevronDown, ChevronRight, ChevronLeft, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { ConditionEditor } from "./ConditionEditor";
import { type RateRule, type RulePatch, describeRule } from "@/lib/rate-types";

/** Rows are wide and an expanded editor is tall, so a bigger page pushes the pager off screen. */
const PAGE_SIZE = 25;

/**
 * One scope's rules, filtered to what prices this product, paged and editable in place.
 *
 * <p><strong>Paged in the browser, against the CdrsClient precedent and knowing it.</strong> That
 * page pages on the server because `cdr_submit` is unbounded and `COUNT(*)` over it does not stay
 * fast. Here the whole rule set is already in memory as a hard requirement of saving, so a server
 * page would be a second, smaller copy of data the component must hold anyway — and paging locally
 * gives back what keyset paging deliberately withholds: a real total and a page count.
 *
 * <p><strong>Reordering is not offered here.</strong> The list is filtered and paged, so a move
 * button would move a rule relative to rows that are not on screen, producing an order nobody looked
 * at. And it spans two buckets at once: dragging an inherited rule above a product rule looks like it
 * changes precedence and does not, because the gateway tries product rules first regardless of
 * position. Ordering lives in one place, and it is the place that can see the whole order.
 */
export function ProductPricingTable({
  product,
  scope,
  kind,
  rules,
  hidden,
  onChange,
  onToggleEnabled,
  busy,
}: {
  product: string;
  scope: string;
  kind: string;
  /** Only the rules that price this product — the parent holds the complete scope. */
  rules: RateRule[];
  /** How many of this scope's rules are not shown, so a save is never a surprise. */
  hidden: number;
  onChange: (id: number, patch: RulePatch) => void;
  onToggleEnabled: (id: number, enabled: boolean) => void;
  busy: boolean;
}) {
  const [page, setPage] = useState(0);
  //one at a time, and that is correctness rather than taste: ConditionEditor renders a <datalist>
  //with a module-global id, and duplicate ids are invalid HTML that browsers resolve unpredictably
  const [expanded, setExpanded] = useState<number | null>(null);
  const [unlocked, setUnlocked] = useState<number | null>(null);

  const pages = Math.max(1, Math.ceil(rules.length / PAGE_SIZE));
  const shown = rules.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  return (
    <div className="space-y-2">
      <TableInCard className="tabular-nums">
        <THead>
          <TR>
            <TH className="w-8">#</TH>
            <TH className="w-24">Amount</TH>
            <TH>Applies when</TH>
            <TH className="w-20">Active</TH>
            <TH className="w-8" />
          </TR>
        </THead>
        <TBody>
          {shown.map((rule) => {
            const inherited = !rule.product;
            const open = expanded === rule.id;
            return (
              //the key belongs on the fragment, not the first <tr> inside it. On the row it is
              //invisible to React, which then matches the pair positionally -- so a reorder or a
              //delete leaves the open editor and the unlock attached to whatever rule now sits at
              //that index, which is a different rule's money
              <Fragment key={rule.id}>
                <TR>
                  <TD muted>{rule.seq}</TD>
                  {/* verbatim, never through money(): that divides by 10,000 for the BIGINT-scaled
                      CDR amounts, and would render 0.0450 as 0.00 -- which reads as free */}
                  <TD className="font-mono">{rule.amount}</TD>
                  <TD>
                    <span className={rule.enabled ? "" : "text-muted-foreground line-through"}>
                      {describeRule(rule)}
                    </span>
                    {inherited && <Badge variant="outline" className="ml-2">inherited</Badge>}
                    {rule.filters.map((f) => (
                      <Badge key={f} variant="default" className="ml-1.5">{f}</Badge>
                    ))}
                  </TD>
                  <TD>
                    <input
                      type="checkbox"
                      checked={rule.enabled}
                      disabled={busy}
                      onChange={(e) => onToggleEnabled(rule.id, e.target.checked)}
                      className="h-3.5 w-3.5 rounded border-input accent-primary"
                      aria-label="Active"
                    />
                  </TD>
                  <TD>
                    <button
                      type="button"
                      onClick={() => { setExpanded(open ? null : rule.id); setUnlocked(null); }}
                      aria-label={open ? "Collapse" : "Edit"}
                      className="text-muted-foreground hover:text-foreground"
                    >
                      {open ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                    </button>
                  </TD>
                </TR>

                {open && (
                  <TR className="bg-muted/10 hover:bg-muted/10">
                    <TD colSpan={5} className="p-3">
                      {inherited && unlocked !== rule.id ? (
                        <label className="flex items-start gap-2 rounded-md border border-border bg-muted/40 p-3 text-sm">
                          <input
                            type="checkbox"
                            checked={false}
                            onChange={() => setUnlocked(rule.id)}
                            className="mt-0.5 h-3.5 w-3.5 rounded border-input accent-primary"
                          />
                          <span>
                            This rule has no product, so it prices <strong>every</strong> product in{" "}
                            {scope} — and any product with no rules of its own here. Editing it
                            changes all of them, not just {product}.
                          </span>
                        </label>
                      ) : (
                        <div className="space-y-3">
                          <div className="flex flex-wrap items-end gap-3">
                            <div className="w-full sm:w-28">
                              <label className="mb-1 block text-xs font-semibold">Amount</label>
                              <Input
                                value={rule.amount}
                                onChange={(e) => onChange(rule.id, { amount: e.target.value })}
                                inputMode="decimal"
                                className="tabular-nums"
                              />
                            </div>
                            <div className="w-full sm:w-40">
                              <label className="mb-1 block text-xs font-semibold">Product</label>
                              <Select
                                value={rule.product ?? ""}
                                onChange={(e) => onChange(rule.id, { product: e.target.value || null })}
                              >
                                <option value="">Any product (inherited)</option>
                                <option value={product}>{product}</option>
                                {rule.product && rule.product !== product && (
                                  <option value={rule.product}>{rule.product}</option>
                                )}
                              </Select>
                            </div>
                            <div className="min-w-40 flex-1">
                              <label className="mb-1 block text-xs font-semibold">Note</label>
                              <Input
                                value={rule.label ?? ""}
                                onChange={(e) => onChange(rule.id, { label: e.target.value || null })}
                              />
                            </div>
                          </div>
                          <ConditionEditor
                            conditions={rule.conditions}
                            filterCount={rule.filters.length}
                            onChange={(conditions) => onChange(rule.id, { conditions })}
                          />
                        </div>
                      )}
                    </TD>
                  </TR>
                )}
              </Fragment>
            );
          })}
        </TBody>
      </TableInCard>

      {!rules.length && (
        <p className="text-sm text-muted-foreground">
          Nothing in {kind === "cost" ? "this vendor's" : "this account's"} pricing applies to{" "}
          {product}.
        </p>
      )}

      <div className="flex flex-wrap items-center justify-between gap-2 text-sm text-muted-foreground">
        <span>
          {rules.length} rule{rules.length === 1 ? "" : "s"} for {product}
          {/* otherwise the first surprise is a save that touched rules nobody saw */}
          {hidden > 0 && `, and ${hidden} more in this scope that a save here also rewrites`}
        </span>
        {pages > 1 && (
          <span className="flex items-center gap-1">
            <Button variant="ghost" size="sm" className="h-6 px-2"
              disabled={page === 0} onClick={() => setPage(page - 1)}>
              <ChevronLeft className="h-3 w-3" />
            </Button>
            Page {page + 1} of {pages}
            <Button variant="ghost" size="sm" className="h-6 px-2"
              disabled={page >= pages - 1} onClick={() => setPage(page + 1)}>
              <ChevronRight className="h-3 w-3" />
            </Button>
          </span>
        )}
      </div>
    </div>
  );
}

/** Appended to the end of the product's bucket — unambiguous, and it can shadow nothing. */
export function AddRuleButton({ onAdd }: { onAdd: () => void }) {
  return (
    <Button type="button" variant="ghost" size="sm" className="gap-1.5" onClick={onAdd}>
      <Plus className="h-3.5 w-3.5" />
      Add a rule
    </Button>
  );
}
