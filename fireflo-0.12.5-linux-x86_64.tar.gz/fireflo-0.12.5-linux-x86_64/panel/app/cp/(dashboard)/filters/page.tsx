import { PageHeader } from "@/components/ui/page-header";
import { FiltersClient } from "@/components/FiltersClient";

export default function FiltersPage() {
  return (
    <>
      <PageHeader title="Filters" description="Named conditions that routing and pricing rules reuse instead of repeating." />
      <FiltersClient />
    </>
  );
}
