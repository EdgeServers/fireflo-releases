import { NextRequest, NextResponse } from "next/server";
import { guardConfigWrite } from "@/lib/config-guard";
import { listRouteTables, saveRouteTable } from "@/lib/routing";
import { listRouteGroups } from "@/lib/groups";
import { listWorkers, setWorkerEnabled } from "@/lib/workers";
import { listWhitelistSummaries, savePolicy } from "@/lib/whitelist";
import { requireOperator } from "@/lib/require-operator";
import { logOperatorEvent } from "@/lib/access-log";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import {
  buildDlrReturnRule,
  defaultRoutingPlan,
  isRoutingCatchAll,
  targetKind,
  validateRouteTable,
  DEFAULT_TABLE_NAME,
  type RouteRule,
} from "@/lib/routing-types";
import type { ApplyAction } from "@/lib/delivery-diagnosis";

const TABLES = "app_route_table, app_route_rule, app_worker and app_whitelist_policy";

/**
 * The four fixes the delivery check is willing to make itself.
 *
 * <h2>Why only four</h2>
 *
 * <p>Each is a change whose correct form is fully determined by the finding — a reorder, a boolean,
 * an enum, or a rule whose one free choice the operator has already made in the dialog. Everything
 * else the report can see needs a judgement it does not have: which registrations to approve, how
 * much credit to add, what a rate should be, whether a filter that serves both routing and pricing
 * should come back. Those get a link and a sentence, and that asymmetry is the safety property.
 *
 * <p><strong>Nothing here is a new write path.</strong> Each action calls the same function the
 * corresponding form calls, so validation, the config-source guard and the audit trail apply
 * unchanged — and a fix applied from here is indistinguishable afterwards from one made by hand.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  await requireOperator();

  let action: ApplyAction & { target?: string };
  try {
    action = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  try {
    switch (action.kind) {
      case "moveCatchAllLast":
        return await moveCatchAllLast(action.table);
      case "addCatchAll":
        return await addCatchAll(action.table, action.target ?? "");
      case "addSystemReturnRule":
        return await addSystemReturnRule(action.workerName, action.workerFullName);
      case "recreateDefaultRouting":
        return await recreateDefaultRouting(req, action.mtTarget ?? "", action.moTarget ?? "");
      case "enableWorker":
        await setWorkerEnabled(action.worker, true);
        return NextResponse.json({
          data: { applied: `${action.worker} is switched back on.` },
        });
      case "reportMode": {
        //savePolicy writes both modes, so the other one is re-read here rather than echoed back
        //from what the check saw. Sending a client-held mirror is how a stale value gets written
        //over somebody else's change -- a defect this panel has already had once
        const current = (await listWhitelistSummaries()).find(
          (s) => s.accountId === action.accountId && s.product === action.product);
        const header = action.which === "header" ? "REPORT" : current?.headerMode ?? "OFF";
        const content = action.which === "content" ? "REPORT" : current?.contentMode ?? "OFF";
        const { name: operator } = await requireOperator();
        await savePolicy(action.accountId, action.product, header, content, operator);
        return NextResponse.json({
          data: {
            applied:
              `${action.accountId} is now on REPORT for `
              + `${action.which === "header" ? "sender IDs" : "content"}. It logs what it would `
              + "refuse and refuses nothing, so traffic flows while you approve the backlog.",
          },
        });
      }
      default:
        return NextResponse.json({ error: "Not a fix this check can apply." }, { status: 400 });
    }
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "The fix could not be applied." },
      { status: 500 }
    );
  }
}

/**
 * Moves the terminal catch-all to the end, and changes nothing else.
 *
 * <p>Re-reads the table first rather than trusting what the report saw: a check run five minutes
 * ago describes a table somebody may have edited since, and reordering a stale copy would silently
 * revert their change.
 */
async function moveCatchAllLast(name: string): Promise<NextResponse> {
  const table = (await listRouteTables()).find((t) => t.name === name);
  if (!table) {
    return NextResponse.json({ error: `There is no routing table called '${name}'.` }, { status: 404 });
  }
  const at = table.rules.findIndex((r) => r.enabled && isRoutingCatchAll(r) && !r.copied);
  if (at < 0) {
    return NextResponse.json(
      { error: "That table has no catch-all any more. Run the check again." },
      { status: 409 }
    );
  }
  const rules = [...table.rules];
  const [rule] = rules.splice(at, 1);
  rules.push(rule);
  await saveRouteTable({ ...table, rules });
  return NextResponse.json({
    data: { applied: `The catch-all in '${name}' is now last, and the rules below it are live again.` },
  });
}

async function addCatchAll(name: string, target: string): Promise<NextResponse> {
  if (!target.trim()) {
    //the one free choice, and the panel deliberately does not make it: which vendor unmatched
    //traffic should go to is a commercial decision, not a repair
    return NextResponse.json({ error: "Choose the vendor it should send to." }, { status: 400 });
  }
  const table = (await listRouteTables()).find((t) => t.name === name);
  if (!table) {
    return NextResponse.json({ error: `There is no routing table called '${name}'.` }, { status: 404 });
  }
  if (table.rules.some((r) => r.enabled && isRoutingCatchAll(r))) {
    return NextResponse.json(
      { error: "That table already has a catch-all. Run the check again." },
      { status: 409 }
    );
  }
  const rule: RouteRule = {
    id: null,
    target: target.trim(),
    copied: false,
    label: "catch-all",
    enabled: true,
    conditions: [],
    filters: [],
  };
  await saveRouteTable({ ...table, rules: [...table.rules, rule] });
  return NextResponse.json({
    data: {
      applied:
        `'${name}' now sends anything that matches no other rule to ${target.trim()}. It reaches `
        + "the gateway on its next configuration poll.",
    },
  });
}

/**
 * Appends the delivery-receipt-return rule for one SMPP listener to the `default` table.
 *
 * <p>`default` specifically, not the caller's choice: it is the entry-point table the gateway's own
 * `RoutingFileParser` names by convention, and the shipped example carries this exact rule there
 * (`smppserver.smpp:type:==:18`). Unlike `addCatchAll`, there is nothing here for an operator to
 * decide — `buildDlrReturnRule` fully determines the rule from the listener alone — so this needs
 * no target argument and no "already has one" guard beyond the detection re-running after the save.
 */
async function addSystemReturnRule(workerName: string, workerFullName: string): Promise<NextResponse> {
  if (!workerName.trim() || !workerFullName.trim()) {
    return NextResponse.json({ error: "Which listener needs the rule?" }, { status: 400 });
  }
  const table = (await listRouteTables()).find((t) => t.name === "default");
  if (!table) {
    return NextResponse.json(
      { error: "There is no 'default' routing table to add the rule to. Create one first." },
      { status: 404 }
    );
  }
  const rule = buildDlrReturnRule({ kind: "dlr-return", workerName, workerFullName });
  await saveRouteTable({ ...table, rules: [...table.rules, rule] });
  return NextResponse.json({
    data: {
      applied:
        `Delivery receipts arriving on ${workerFullName} now route back to it. It reaches the `
        + "gateway on its next configuration poll.",
    },
  });
}

/**
 * Rebuilds default routing — the receipt, inbound and outbound lanes — in one write.
 *
 * <p>The case this exists for is the `default` table being deleted. The gateway does not degrade
 * without it: `StandardRoutingManager` refuses a snapshot with no `default` table, keeps its last
 * in-memory copy, and routes nothing at all after the next restart. Until now the only way back was
 * to rebuild it rule by rule in the editor, and `addSystemReturnRule` above would not even start —
 * it 404s when the table is missing.
 *
 * <p>Additive: `defaultRoutingPlan` never edits, retargets or drops a rule an operator wrote. It
 * appends the lanes that are missing and rearranges positions, which is a change in its own right
 * and is why the plan's `changes` are shown before this is called and recorded after.
 *
 * <p>The plan is recomputed here against a freshly-read table set rather than taken from the
 * request, for the reason the two actions above give: a client-held copy is how a concurrent edit
 * gets reverted by somebody who never saw it.
 */
async function recreateDefaultRouting(
  req: NextRequest,
  mtTarget: string,
  moTarget: string
): Promise<NextResponse> {
  const [tables, servers, vendors, groups] = await Promise.all([
    listRouteTables(),
    listWorkers("smppserver"),
    listWorkers("smppclient"),
    listRouteGroups(),
  ]);

  //resolved the gateway's way -- table, then group, then worker -- so a target that would send
  //nowhere is refused here rather than written and discovered twenty routing attempts later
  const names = tables.map((t) => t.name);
  const workers = [...servers, ...vendors];
  const groupNames = groups.map((g) => g.name);
  for (const [label, target] of [["Outbound", mtTarget], ["Inbound", moTarget]] as const) {
    if (!target.trim()) {
      continue;
    }
    const kind = targetKind(target, names, workers, groupNames);
    if (kind === "unknown") {
      return NextResponse.json(
        { error: `${label} traffic cannot go to '${target}' — no routing table, group or worker of that name exists.` },
        { status: 400 }
      );
    }
    if (kind === "disabled") {
      return NextResponse.json(
        { error: `'${target}' is switched off, so a rule sending ${label.toLowerCase()} traffic there would send nothing.` },
        { status: 400 }
      );
    }
  }

  const plan = defaultRoutingPlan(tables, servers, vendors, { mtTarget, moTarget });
  if (!plan.changes.length) {
    return NextResponse.json({
      data: { applied: "Default routing is already complete — nothing to change.", changes: [] },
    });
  }

  //the other routing actions here skip this, because each appends one rule whose shape is fixed.
  //This one writes a whole table, so it goes through the same validator the editor's save does
  const invalid = validateRouteTable(plan.table);
  if (invalid) {
    return NextResponse.json({ error: invalid }, { status: 400 });
  }

  const before = tables.find((t) => t.name === DEFAULT_TABLE_NAME)?.rules.length ?? 0;
  await saveRouteTable(plan.table);

  //recorded with the count it started from, not just the one it ended at: "what did it used to be"
  //is the question asked after a configuration change goes wrong, and routing had no audit at all
  const { name: operator } = await requireOperator();
  void logOperatorEvent({
    event: "routing_recreated",
    actor: operator,
    ip: clientIp(req),
    userAgent: clientUserAgent(req),
    detail: {
      table: DEFAULT_TABLE_NAME,
      created: plan.created,
      rulesBefore: before,
      rulesAfter: plan.table.rules.length,
      mtTarget: mtTarget.trim() || null,
      moTarget: moTarget.trim() || null,
      changes: plan.changes,
    },
  });

  return NextResponse.json({
    data: {
      applied:
        `Default routing rebuilt: ${plan.table.rules.length} rule(s) in '${DEFAULT_TABLE_NAME}'. `
        + "The gateway picks it up on its next configuration poll.",
      changes: plan.changes,
    },
  });
}
