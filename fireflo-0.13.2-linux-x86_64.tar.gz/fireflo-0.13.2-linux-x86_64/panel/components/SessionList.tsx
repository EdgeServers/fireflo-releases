"use client";
import { useState } from "react";
import { ChevronDown, ChevronRight } from "lucide-react";
import type { HealthSession } from "@/lib/health-types";
import { KIND, type WorkerType } from "@/lib/worker-types";
import { count, duration } from "@/lib/format";
import { shareOf } from "@/lib/bind-summary";
import { BIND_TYPE_LABELS, labelFor, ROLE_LABELS } from "@/lib/labels";
import { groupSessions, hostsLabel, type AccountGroup, type BindCounts } from "@/lib/session-groups";
import { Checkbox } from "@/components/ui/checkbox";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { DangerAction } from "./DangerAction";
import { CaptureSession } from "./CaptureSession";
import { formatTps } from "@/lib/tps-format";

/**
 * The individual connections behind a bind count.
 *
 * <p>Shared by the vendor page, the listener page and the health page. The count alone cannot
 * answer what usually follows it: whether a vendor landed on its primary host or fell back to a
 * backup, whether every bind is a transceiver, or whether one session has been up for days while
 * another keeps cycling.
 *
 * <p>The two kinds hold genuinely different facts, so they are two tables. A vendor's sessions are
 * its own outbound binds: one row each, with the host it dialled. A listener's sessions belong to
 * customers, and the question asked of them is "who is on this listener and how much of it is
 * theirs" — so they fold into one row per account ({@link groupSessions}), binds counted by kind,
 * and the binds themselves open under it, each identified by address <em>and</em> source port.
 * The port used to be hidden as identifying nothing, which was true of a port alone; next to the
 * address it is the only thing that tells a customer's two binds from one host apart, and it is
 * what Capture and Disconnect act on.
 *
 * @param worker the worker's full name. Supplying it turns on the per-session actions -- capture on
 *     either kind, and disconnect on a listener; leaving it out keeps the table inert
 * @param canDisconnect false suppresses Disconnect while leaving Capture, which is what `/health`
 *     wants: the same listener sessions, readable, without a lever that drops a customer
 * @param expanded which account groups are open, held by the caller so they survive a poll or a
 *     refresh; absent, the table keeps its own
 */
export function SessionList({
  type,
  sessions,
  worker,
  canDisconnect: allowDisconnect = true,
  total,
  expanded,
  onToggle,
}: {
  type: WorkerType;
  sessions: HealthSession[];
  worker?: string;
  canDisconnect?: boolean;
  /**
   * The worker's whole counted traffic, which turns each row's own count into a share of it.
   *
   * <p>Supplied only when these rows <em>are</em> the whole set. Within one page of a longer list
   * the sum is not the worker's traffic, so a percentage against it would be a share of the page —
   * a number that changes when you turn to the next one. Absent, the column is not rendered at all.
   */
  total?: number;
  expanded?: ReadonlySet<string>;
  onToggle?: (account: string) => void;
}) {
  const isVendor = type === KIND.vendor;
  if (!sessions.length) {
    return <p className="text-sm text-muted-foreground">Nothing bound.</p>;
  }
  if (isVendor) {
    return <VendorSessions sessions={sessions} worker={worker} total={total} />;
  }
  return (
    <ListenerSessions
      sessions={sessions}
      worker={worker}
      canDisconnect={allowDisconnect && !!worker}
      total={total}
      expanded={expanded}
      onToggle={onToggle}
    />
  );
}

/** Every account's name, for an Expand all over a session array. */
export function accountsIn(sessions: readonly HealthSession[]): string[] {
  return groupSessions(sessions).map((g) => g.account);
}

function VendorSessions({
  sessions,
  worker,
  total,
}: {
  sessions: HealthSession[];
  worker?: string;
  total?: number;
}) {
  const showShare = total != null && total > 0;
  //capture reads a session rather than acting on it, so it is offered on a vendor connection too
  const canCapture = !!worker;

  return (
    <TableInCard>
      <THead>
        <TR>
          <TH>Bind</TH>
          {/* the credential this bind used: a vendor with several logins could not otherwise say
              which one a given session dialled with */}
          <TH>System ID</TH>
          <TH>Host</TH>
          <TH>Up for</TH>
          <TH align="right">Sent</TH>
          <TH align="right">tps</TH>
          {showShare && <TH>Share</TH>}
          {canCapture && <TH />}
        </TR>
      </THead>
      <TBody className="tabular-nums">
        {sessions.map((session, index) => (
          //every session now carries an id, so the index fallback is only for a gateway older
          //than that change
          <TR key={session.session_id ?? index} className={session.bound ? undefined : "text-muted-foreground"}>
            <TD>
              <span title={session.bind_type ?? undefined}>
                {labelFor(BIND_TYPE_LABELS, session.bind_type)}
                {/* only when it is not the primary: on the common path this would be a column of
                    NORMAL that teaches nobody anything */}
                {session.role && session.role !== "NORMAL" && (
                  <span className="ml-1.5 rounded bg-warning-soft/60 px-1 text-warning">
                    {labelFor(ROLE_LABELS, session.role)}
                  </span>
                )}
              </span>
              {!session.bound && <span className="ml-1.5">(not bound)</span>}
            </TD>
            <TD>{session.system_id ?? "—"}</TD>
            <TD>
              {session.host
                ? `${session.host}${session.port != null ? `:${session.port}` : ""}`
                : "—"}
            </TD>
            <TD>{session.bound_seconds != null ? duration(session.bound_seconds) : "—"}</TD>
            <TD align="right">{session.submitted != null ? count(session.submitted) : "—"}</TD>
            <TD align="right">
              {/* != null, not truthiness: 0 here means bound and sending nothing, which is the
                  reading worth showing */}
              {session.tps_measured != null ? formatTps(session.tps_measured) : "—"}
            </TD>
            {showShare && (
              <TD>
                <Share value={shareOf(session.submitted, total!)} />
              </TD>
            )}
            {canCapture && (
              <TD align="right" className="align-top">
                {session.session_id != null && (
                  <CaptureSession worker={worker!} session={session} isVendor />
                )}
              </TD>
            )}
          </TR>
        ))}
      </TBody>
    </TableInCard>
  );
}

/**
 * A listener's sessions, one row per account with its binds underneath.
 *
 * <p>The open set lives with the caller when it supplies one, so that a ten-second health poll or
 * a Refresh redraws the table without closing what the operator opened. Without a caller, the
 * table keeps its own, which is enough for a page that does not refresh under it.
 */
function ListenerSessions({
  sessions,
  worker,
  canDisconnect,
  total,
  expanded: controlled,
  onToggle,
}: {
  sessions: HealthSession[];
  worker?: string;
  canDisconnect: boolean;
  total?: number;
  expanded?: ReadonlySet<string>;
  onToggle?: (account: string) => void;
}) {
  const [own, setOwn] = useState<ReadonlySet<string>>(() => new Set());
  const expanded = controlled ?? own;
  const toggle = onToggle ?? ((account: string) => setOwn((prev) => toggled(prev, account)));

  const groups = groupSessions(sessions);
  const showShare = total != null && total > 0;
  const canCapture = !!worker;
  const hasActions = canDisconnect || canCapture;
  const columns = 7 + (showShare ? 1 : 0) + (hasActions ? 1 : 0);

  return (
    <TableInCard>
      <THead>
        <TR>
          <TH>Account</TH>
          <TH>Binds</TH>
          <TH>From</TH>
          <TH>System type</TH>
          <TH>Up for</TH>
          {/* "Received": the counter behind this column is getRxSubmitSM for an inbound session,
              so it is traffic the customer sent us */}
          <TH align="right">Received</TH>
          <TH align="right">tps</TH>
          {showShare && <TH>Share</TH>}
          {hasActions && <TH />}
        </TR>
      </THead>
      <TBody className="tabular-nums">
        {groups.map((group) => {
          const open = expanded.has(group.account);
          return (
            <GroupRows
              key={group.account}
              group={group}
              open={open}
              onToggle={() => toggle(group.account)}
              worker={worker}
              canDisconnect={canDisconnect}
              canCapture={canCapture}
              total={showShare ? total : undefined}
              columns={columns}
            />
          );
        })}
      </TBody>
    </TableInCard>
  );
}

function GroupRows({
  group,
  open,
  onToggle,
  worker,
  canDisconnect,
  canCapture,
  total,
  columns,
}: {
  group: AccountGroup;
  open: boolean;
  onToggle: () => void;
  worker?: string;
  canDisconnect: boolean;
  canCapture: boolean;
  total?: number;
  columns: number;
}) {
  const hasActions = canDisconnect || canCapture;
  const Chevron = open ? ChevronDown : ChevronRight;
  const logins = group.logins.length;
  return (
    <>
      <TR
        className="cursor-pointer"
        onClick={onToggle}
        aria-expanded={open}
        data-account={group.account}
      >
        <TD className="font-medium">
          <span className="inline-flex items-center gap-1.5">
            <Chevron className="h-3.5 w-3.5 shrink-0 text-muted-foreground" aria-hidden />
            {group.account}
            {logins > 0 && (
              <span className="font-normal text-muted-foreground">
                · {logins} login{logins === 1 ? "" : "s"}
              </span>
            )}
          </span>
        </TD>
        <TD><BindChips counts={group.counts} /></TD>
        <TD className="font-mono text-xs">{hostsLabel(group.hosts)}</TD>
        <TD className="text-muted-foreground">
          {/* the system types the binds carried, de-duplicated: usually none, sometimes one */}
          {systemTypes(group) || "—"}
        </TD>
        <TD>{group.oldest != null ? duration(group.oldest) : "—"}</TD>
        <TD align="right">{group.received != null ? count(group.received) : "—"}</TD>
        <TD align="right">
          {group.tps != null ? formatTps(group.tps) : "—"}
          {group.tpsLimit != null && <span className="text-muted-foreground"> / ≤{group.tpsLimit}</span>}
        </TD>
        {total != null && (
          <TD><Share value={shareOf(group.received, total)} /></TD>
        )}
        {hasActions && <TD />}
      </TR>
      {open && group.sessions.map((session, index) => (
        <TR
          key={session.session_id ?? `${group.account}-${index}`}
          className={cn("bg-muted/30", !session.bound && "text-muted-foreground")}
          data-session={session.session_id ?? undefined}
        >
          <TD className="pl-10 font-mono text-xs">
            {/* address AND source port: the pair is what makes this one connection, and what
                the buttons at the end of the row act on */}
            {session.host ?? "—"}
            {session.port != null && <span className="text-muted-foreground">:{session.port}</span>}
            {!session.bound && <span className="ml-1.5 font-sans">(not bound)</span>}
          </TD>
          <TD>
            <span className="inline-flex items-center gap-1.5">
              <BindChip kind={labelFor(BIND_TYPE_LABELS, session.bind_type)} title={session.bind_type ?? undefined} />
              <span className="text-muted-foreground">{session.system_id ?? "—"}</span>
            </span>
          </TD>
          <TD />
          <TD>
            {session.system_type ?? (
              //absent is a fact, not a gap: the login's own product applied
              <span className="text-muted-foreground" title="No system_type on the bind — the login's own product applies">
                —
              </span>
            )}
          </TD>
          <TD>{session.bound_seconds != null ? duration(session.bound_seconds) : "—"}</TD>
          <TD align="right">{session.submitted != null ? count(session.submitted) : "—"}</TD>
          <TD align="right">
            {session.tps_measured != null ? formatTps(session.tps_measured) : "—"}
            {session.tps_limit != null && <span className="text-muted-foreground"> / ≤{session.tps_limit}</span>}
          </TD>
          {total != null && (
            <TD><Share value={shareOf(session.submitted, total)} /></TD>
          )}
          {hasActions && (
            <TD align="right" className="align-top">
              {session.session_id != null && (
                <span className="inline-flex items-start justify-end gap-1.5">
                  {canCapture && <CaptureSession worker={worker!} session={session} isVendor={false} />}
                  {canDisconnect && <DisconnectSession worker={worker!} session={session} />}
                </span>
              )}
            </TD>
          )}
        </TR>
      ))}
      {open && group.sessions.length === 0 && (
        <TR><TD colSpan={columns} className="text-muted-foreground">Nothing bound.</TD></TR>
      )}
    </>
  );
}

function systemTypes(group: AccountGroup): string {
  const types = [...new Set(group.sessions.map((s) => s.system_type).filter((t): t is string => !!t))];
  return types.join(", ");
}

function toggled(set: ReadonlySet<string>, account: string): ReadonlySet<string> {
  const next = new Set(set);
  if (next.has(account)) {
    next.delete(account);
  } else {
    next.add(account);
  }
  return next;
}

/** `2 TX · 2 RX` as chips, so the kinds read at a glance down a column. */
export function BindChips({ counts }: { counts: BindCounts }) {
  const kinds = (["TX", "RX", "TRX"] as const).filter((kind) => counts[kind] > 0);
  if (!kinds.length && !counts.unbound) {
    return <span className="text-muted-foreground">—</span>;
  }
  return (
    <span className="inline-flex flex-wrap items-center gap-1">
      {kinds.map((kind) => <BindChip key={kind} kind={kind} n={counts[kind]} />)}
      {counts.unbound > 0 && (
        <span className="rounded-full border border-border px-2 py-0.5 text-2xs font-semibold leading-4 text-muted-foreground">
          {counts.unbound} not bound
        </span>
      )}
    </span>
  );
}

const CHIP_CLASSES: Record<string, string> = {
  TX: "bg-info-soft text-info",
  RX: "bg-warning-soft text-warning",
  TRX: "bg-success-soft text-success",
};

function BindChip({ kind, n, title }: { kind: string; n?: number; title?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2 py-0.5 text-2xs font-semibold leading-4",
        CHIP_CLASSES[kind] ?? "bg-primary-soft text-foreground"
      )}
      title={title}
    >
      {n != null ? `${n} ${kind}` : kind}
    </span>
  );
}

/**
 * How much of the worker's traffic went over this one bind.
 *
 * <p>A bar rather than a percentage because the reading is comparative — five rows of "20%" is
 * harder to scan than five bars of the same length, and one long bar among four stubs is the
 * shape worth catching. The figure is in the title for anyone who wants the number.
 *
 * <p>Null renders as a dash, not an empty bar: a session with counters switched off has no share,
 * which is a different statement from having carried nothing.
 */
export function Share({ value }: { value: number | null }) {
  if (value == null) {
    return <span className="text-muted-foreground">—</span>;
  }
  return (
    <span
      className="block h-1.5 w-full min-w-8 overflow-hidden rounded-full bg-muted"
      title={`${(value * 100).toFixed(1)}% of this worker's counted traffic`}
    >
      <span
        className="block h-full rounded-full bg-muted-foreground/60"
        style={{ width: `${Math.max(value * 100, 1)}%` }}
      />
    </span>
  );
}

/**
 * Drop one customer's bind.
 *
 * <p>No refresh on success: the health poll removes the row within ten seconds, and a session list
 * that redrew from this button alone would be showing one row's worth of fresher truth than the rest
 * of the table.
 *
 * <p>The tick box is the difference between a nudge and a shut door, and it is unticked by default
 * because a disconnect is reversible in seconds and disabling a login is not.
 */
function DisconnectSession({ worker, session }: { worker: string; session: HealthSession }) {
  const [alsoDisable, setAlsoDisable] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function disconnect() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(
        `/api/control/workers/${encodeURIComponent(worker)}/sessions/${session.session_id}/disconnect`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            disable_login: alsoDisable,
            system_id: session.system_id ?? "",
          }),
        }
      );
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? "The gateway did not confirm.");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not reach the panel.");
    } finally {
      setBusy(false);
    }
  }

  const where = session.host ? `${session.host}${session.port != null ? `:${session.port}` : ""}` : "this bind";
  return (
    <span className="inline-flex flex-col items-end gap-1">
      <DangerAction
        label="Disconnect"
        confirmLabel={alsoDisable ? "Disconnect and disable" : "Disconnect"}
        consequence={
          alsoDisable
            ? `${session.system_id ?? "This login"} is switched off and the bind from ${where} is dropped.`
            : `The bind from ${where} is dropped; the account's other binds stay. A client that retries will be back within seconds.`
        }
        busy={busy}
        extra={
          <label className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Checkbox checked={alsoDisable} onChange={(e) => setAlsoDisable(e.target.checked)} />
            <span>
              Also disable this login
              <span className="block">
                Takes up to the gateway&rsquo;s poll interval, so a fast reconnect is still let in.
              </span>
            </span>
          </label>
        }
        onConfirm={disconnect}
      />
      {error && <span className="max-w-64 text-xs text-destructive">{error}</span>}
    </span>
  );
}
