import type { Change } from "../../qa-plan-types.ts";

/**
 * EP-22 — Customer Portal: Sign-in & Self-service, 0.12 → 0.15.4.0.
 *
 * The portal shares the panel's top bar and so its display time zone (0.15.2.0); the customer
 * statement reads a month on Show with the breathing card (0.15.0.0); the home lists read only the
 * live days, kept 30 s per scope (0.15.2.0).
 */
const change: Change = {
  epic: "EP-22",
  scenarios: [
    { id: "SC-22.02.02", story: "US-22.02", epic: "EP-22", scenario: "The portal statement reads on Show, and the portal's times follow the display zone", gwt: "Given qa-portal-a with usage this month and smsg.billing.zone Asia/Kolkata. When the customer opens Statement, chooses this month and presses Show, and opens Messages. Then the statement is read only on Show (with the breathing card while it reads) and lists the month's lines, and the portal's zone chip and its message times are in the billing zone.", preconditions: "rig; portal session for qa-portal-a; usage_daily rows for it", rig: "browser portal /statement, /messages; zone chip", related: "SC-21.13.01, SC-18.12.01", dependsOn: "", changed: "New" },
  ],
  cases: [
    { id: "TC-22.02.02-P01", scenario: "SC-22.02.02", story: "US-22.02", epic: "EP-22", type: "Positive", title: "The portal statement waits for Show, then lists the month", steps: "1. Seed two call records for qa-portal-a today at 0.0100 each (the live tail). 2. Portal → Statement: it opens on last month. 3. Pick this month; read the page and the network. 4. Show; read the answer.", testData: "", expected: "Opening reads last month only; picking this month says 'Changed — press Show' and reads nothing (no /api/mis/statement?month=<this month> request); after Show the month's totals as cdr_submit holds them (≥ 2 messages, ≥ 0.02 AUD) and the 'Changed' note is gone", oracle: "page; network requests; psql cdr_submit", antiVacuity: "", priority: "P2", component: "Control Panel", automated: "", related: "TC-22.02.01-P01", surface: "Portal", changed: "New", changeNote: "0.15.0.0" },
    { id: "TC-22.02.02-P02", scenario: "SC-22.02.02", story: "US-22.02", epic: "EP-22", type: "Positive", title: "The portal's zone chip reads the billing zone and its message times follow it", steps: "1. smsg.billing.zone = Asia/Kolkata (the panel holds it for 30 s); seed a qa-portal-a message at 20:00:00Z yesterday. 2. Portal → Messages; find it. 3. Read the chip and the time.", testData: "", expected: "Chip IST · Asia/Kolkata; time today 01:30:00, not 20:00:00", oracle: "zone chip; table cell", antiVacuity: "", priority: "P2", component: "Control Panel", automated: "", related: "TC-21.13.01-P01", surface: "Portal", changed: "New", changeNote: "0.15.2.0" },
  ],
  focus: [
    { item: "0.15.2.0", change: "The portal shares the display zone; home lists read the live days only.", scenarios: "SC-22.02.02", risk: "" },
  ],
};
export default change;
