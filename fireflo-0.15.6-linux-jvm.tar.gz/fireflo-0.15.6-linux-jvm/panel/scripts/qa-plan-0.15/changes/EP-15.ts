import type { Change, Rewrite } from "../../qa-plan-types.ts";

/**
 * EP-15 — Ops Management API, Configuration & CLI, 0.12 → 0.15.4.
 *
 * 0.13.0 made the management port GraphQL-only: every /ops/* route is a field of POST /graphql (the
 * mapping is api/graphql-port.json), the admin token satisfies READ fields, a refusal before the
 * document is read is HTTP 404 and a refusal inside an admitted request is 200 with
 * errors[].extensions {code, status}; /q/metrics moved to the messaging port behind the read token.
 * The 136 rows of the 0.12 plan that name an /ops route are rewritten here mechanically (each marked
 * Updated with the 0.13.0 note); the US-15.01 guard cases whose answer changed are updated by hand.
 * New: the GraphQL-only port (US-15.08), restarting one part of the gateway (0.15.2, US-15.09) and the
 * 0.14–0.15 CLI verbs (fireflo load, node, db restore; US-15.10).
 */

const NOTE_013 = "0.13.0: the management port is GraphQL-only; every /ops/* route is now a field of POST /graphql (api/graphql-port.json)";

/** Every /ops route the 0.12 plan names, with the field that replaced it (api/graphql-port.json `was`). */
const ROUTES: [method: string, path: string, field: string, kind: "query" | "mutation"][] = [
  ["GET", "/ops/workers/{name}/sessions/{sessionId}/capture.txt", "captureFile", "mutation"],
  ["GET", "/ops/workers/{name}/sessions/{sessionId}/capture.pcap", "captureFile", "mutation"],
  ["POST", "/ops/workers/{name}/sessions/{sessionId}/disconnect", "sessionDisconnect", "mutation"],
  ["POST", "/ops/workers/{name}/sessions/{sessionId}/capture", "captureStart", "mutation"],
  ["DELETE", "/ops/workers/{name}/sessions/{sessionId}/capture", "captureStop", "mutation"],
  ["GET", "/ops/workers/{name}/sessions/{sessionId}/capture", "capture", "query"],
  ["POST", "/ops/preprocessors/files/{name}/rollback", "preprocessorRollback", "mutation"],
  ["GET", "/ops/watches/{id}/watch.pcap", "watchFile", "mutation"],
  ["POST", "/ops/workers/{name}/test-bind", "testBind", "mutation"],
  ["GET", "/ops/workers/{name}/sessions", "sessions", "query"],
  ["PUT", "/ops/preprocessors/files/{name}", "preprocessorSave", "mutation"],
  ["GET", "/ops/preprocessors/files/{name}", "preprocessorFile", "query"],
  ["GET", "/ops/receipts/repush/{jobId}", "repushJob", "query"],
  ["DELETE", "/ops/receipts/repush/{jobId}", "repushCancel", "mutation"],
  ["POST", "/ops/workers/{name}/{action}", "workerAction", "mutation"],
  ["GET", "/ops/housekeeping/archive", "queueArchive", "query"],
  ["POST", "/ops/housekeeping/{store}", "housekeeping", "mutation"],
  ["GET", "/ops/preprocessors/files", "preprocessorFiles", "query"],
  ["POST", "/ops/preprocessors/check", "preprocessorCheck", "mutation"],
  ["POST", "/ops/preprocessors/test", "preprocessorTest", "mutation"],
  ["POST", "/ops/license/activate", "licenseActivate", "mutation"],
  ["POST", "/ops/license/revalidate", "licenseRevalidate", "mutation"],
  ["POST", "/ops/license/offline", "licenseOfflineRequest / licenseOfflineApply", "mutation"],
  ["POST", "/ops/license/release", "licenseRelease", "mutation"],
  ["POST", "/ops/receipts/repush", "repushStart", "mutation"],
  ["POST", "/ops/sessions/disconnect", "sessionsDisconnect", "mutation"],
  ["GET", "/ops/sessions/summary", "sessionSummary", "query"],
  ["GET", "/ops/sessions/match", "sessionMatch", "query"],
  ["DELETE", "/ops/bind-holds/{id}", "bindHoldLift", "mutation"],
  ["GET", "/ops/bind-holds", "bindHolds", "query"],
  ["GET", "/ops/routing/explain", "routingExplain", "query"],
  ["GET", "/ops/rating/explain", "ratingExplain", "query"],
  ["GET", "/ops/rates/explain", "ratingExplain", "query"],
  ["GET", "/ops/filters/explain", "filtersTest", "query"],
  ["GET", "/ops/filters/test", "filtersTest", "query"],
  ["POST", "/ops/whitelist/test", "whitelistTest", "query"],
  ["GET", "/ops/config/resolved", "resolvedConfig", "query"],
  ["GET", "/ops/config/{name}", "configFile", "query"],
  ["POST", "/ops/credit/release", "creditRelease", "mutation"],
  ["POST", "/ops/queue/test", "brokerTest", "mutation"],
  ["DELETE", "/ops/tps-peaks", "tpsPeaksClear", "mutation"],
  ["POST", "/ops/security/watch", "watchStart", "mutation"],
  ["DELETE", "/ops/watches/{id}", "watchStop", "mutation"],
  ["POST", "/ops/watches", "watchStart", "mutation"],
  ["GET", "/ops/watches/{id}", "watch", "query"],
  ["GET", "/ops/logs/{name}", "logTail", "query"],
  ["GET", "/ops/diagnostics", "diagnostics", "query"],
  ["GET", "/ops/version", "health", "query"],
  ["GET", "/ops/license", "license", "query"],
  ["GET", "/ops/queues", "queues", "query"],
  ["GET", "/ops/health", "health", "query"],
  ["POST", "/ops/reload", "reload", "mutation"],
  ["GET", "/ops/files", "files", "query"],
];

const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
/** A path parameter in the plan's prose: smppserver.smpp, :id, <id>, 42, qa.py. */
const PARAM = "[A-Za-z0-9_.:<>{}-]+";

const routeRewrites: Rewrite[] = ROUTES.map(([, p, field, kind]) => ({
  pattern: `(?:(?:GET|POST|PUT|DELETE) )?${p.split(/\{[^}]+\}/).map(esc).join(PARAM)}(?![A-Za-z0-9_/-])`,
  replace: `the \`${field}\` ${kind} (POST /graphql)`,
  changeNote: NOTE_013,
}));

const rewrites: Rewrite[] = [
  ...routeRewrites,
  // whatever /ops/… is left is the family as a whole
  { pattern: "/ops/preprocessors/\\*", replace: "the preprocessor fields (POST /graphql)", changeNote: NOTE_013 },
  { pattern: "/ops/\\*", replace: "the management port's GraphQL fields (POST /graphql; /ops/* is 404 since 0.13)", changeNote: NOTE_013 },
  { pattern: "/ops/preprocessors(?![A-Za-z0-9_/-])", replace: "the preprocessor fields (POST /graphql)", changeNote: NOTE_013 },
  { pattern: "/ops/workers/(?![A-Za-z0-9_])", replace: "the worker fields (POST /graphql) ", changeNote: NOTE_013 },
  { pattern: "/ops/watches/(?![A-Za-z0-9_])", replace: "the watch fields (POST /graphql) ", changeNote: NOTE_013 },
  { pattern: "/ops/(?![A-Za-z0-9_*])", replace: "the management port (POST /graphql) ", changeNote: NOTE_013 },
  { pattern: "X-Ops-Token", replace: "Authorization: Bearer", changeNote: "0.13.0: the tokens travel as Authorization: Bearer on POST /graphql" },
  { pattern: "(?<![A-Za-z0-9])/q/metrics(?! on the messaging port)", replace: "/q/metrics on the messaging port (read token)", changeNote: "0.13.0: GET /q/metrics moved to the messaging port behind the ops read token; on 9000 it is 404" },
];

const change: Change = {
  epic: "EP-15",
  epicDescription: "The management port (POST /graphql on 9000 since 0.13; /ops/* is gone), its two bearer tokens and the platform signature, what a refusal looks like before and inside a document, the configuration source switch and its tiers, live reload vs restart, restarting one part of a running gateway (0.15.2), and the CLI: fireflo verbs and their interlocks, fireflo load, node, db restore, user totp-reset.",
  rewrites,
  stories: [
    {
      id: "US-15.08", epic: "EP-15", story: "The management port is GraphQL-only (0.13)", asA: "an operator or a platform",
      iWant: "one guarded endpoint, POST /graphql on the management port, with the same two tokens, where every former /ops route is a typed query or mutation",
      soThat: "the panel and a platform generate against one contract, and there are no routes left to enumerate or leave unguarded",
      acceptance: "1. POST /graphql on 9000 answers `health { snapshot }` with the read token; the admin token answers every READ field too (Principal.satisfies). 2. A refusal before the document is read — no token, a wrong one, a peer outside smsg.ops.allowed.ips — is HTTP 404 {\"message\":\"Not found\"}, identical for each. 3. A field refused inside an admitted request is HTTP 200 with errors[].extensions {code, status}: the read token on an ADMIN field is NOT_FOUND 404; an unknown worker NOT_FOUND; a lapsed licence LICENCE_LAPSED 402. 4. /ops/* is 404 on both ports; GET /graphql and POST /graphql on the messaging port are 404. 5. A JSON! field answers exactly the object its route wrote under data (health.snapshot is the old /ops/health document). 6. smsg.ops.allowed.ips / FIREFLO_OPS_ALLOWED_IPS empty = loopback only; health.opsAllowList reports it.",
      configKeys: "smsg.ops.token | smsg.ops.admin.token | smsg.ops.allowed.ips (FIREFLO_OPS_ALLOWED_IPS) | FIREFLO_OPS_PORT | FIREFLO_OPS_HOST", observable: "HTTP status; errors[].extensions.code/status; health.opsAllowList; smsg.log ops.* refused lines", automated: "GraphQlGuardTest, GraphQlPortContractTest", changed: "New",
    },
    {
      id: "US-15.09", epic: "EP-15", story: "Restart one part of a running gateway (0.15.2)", asA: "an admin",
      iWant: "to restart one internal part — the persistence writers, the database pool, a vendor's binds, the jobs, the configuration — without restarting the process",
      soThat: "a stalled writer or a wedged vendor is cured without dropping every customer bind",
      acceptance: "1. `fireflo restart <part> [target] [--hard] [--by NAME]` and GraphQL componentRestart(component, target, hard, by): JSON! (admin token; capability component_restart) answer {component, target, ok, tookMs, detail, results, before, after} — the part's health figures before and after. 2. Parts: persist [stream], db [--hard], kafka-router, kafka-consumers, vendor-feed <vendor>, vendor <vendor>, jobs [name], config (= reload). 3. An unknown part is BAD_REQUEST 'Unknown part 'x'. Parts: persist, db, kafka-router, kafka-consumers, vendor-feed, vendor, jobs, config.'; a part this backbone lacks (kafka-router in memory mode) is CONFLICT; one restart of a part at a time (CONFLICT 'A restart of <part> is already running…'). 4. Every run logs one INFO `ops.restart component= target= hard= by= principal= ok= tookMs= detail=`. 5. Customer binds and accepted traffic are untouched (vendor restarts only that vendor's binds, its queue kept). 6. Exempt from the licence gate, like reload.",
      configKeys: "smsg.ops.admin.token | capability component_restart", observable: "componentRestart JSON; fireflo restart output (before -> after); smsg.log ops.restart; health persist_writer / persist_streams", automated: "OpsRestartServiceTest", changed: "New",
    },
    {
      id: "US-15.10", epic: "EP-15", story: "CLI verbs added in 0.14–0.15: load, node, db restore", asA: "an operator on the gateway host",
      iWant: "to send real SMPP traffic as a customer (fireflo load), see the node identity and the cluster (fireflo node self | list), and roll a migration back from a dump (fireflo db restore) with interlocks",
      soThat: "a load test needs no Maven checkout, a node's id is checked before it joins a cluster, and a rollback is either the dump's state or untouched",
      acceptance: "1. `fireflo load --system-id S --password-file F --tps N --count N --to 614… --yes` binds the listener as that login, paces submit_sm, reads receipts and prints a summary (accepted, refusals by status 0x58/0x14/0x45/other, verdict, p50/p95/p99, receipts delivered/failed); exit 0 completed, 1 bind/transport failure, 2 refused; without --yes it prints its intent (parts per message, charge multiplier, the first-bind IP-lock caution) and asks; `--to` has no default. 2. `fireflo node self` prints the id the binary resolves (FIREFLO_INSTANCE_ID, else the host name) without booting; `fireflo node list` prints gateway_node with heartbeat age and liveness on the database's clock. 3. `fireflo db restore DUMP` refuses while a node's heartbeat is under 90 s old and without FIREFLO_DB_RESTORE=true; when it runs, one psql --single-transaction drops what the gateway's role owns and loads the dump.",
      configKeys: "FIREFLO_INSTANCE_ID | FIREFLO_DB_RESTORE | docs/27-fireflo-load.md", observable: "CLI stdout/stderr and exit status; gateway_node; cdr_submit rows of the load", automated: "LoadCommandTest, NodeCommandTest, DbRestoreTest", changed: "New",
    },
  ],
  scenarios: [
    { id: "SC-15.08.01", story: "US-15.08", epic: "EP-15", scenario: "Tokens, refusals and the old routes on the GraphQL port", gwt: "Given the rig's gateway with read token e2e-read-token and admin token e2e-admin-token on the management port 9100 and the messaging port 8100. When health is asked with each token and none, an ADMIN field with the read token, a field naming a worker that does not exist, and /ops/health, GET /graphql and POST /graphql on the messaging port are tried. Then the tokens answer 200 with data, no or a wrong token is 404 Not found before any field runs, the refused field is 200 with errors[].extensions {code NOT_FOUND, status 404}, the unknown worker NOT_FOUND, and every old or wrong-port request is a plain 404.", preconditions: "gateway 0.13+ (rig 0.15.4); FIREFLO_OPS_PORT 9100, HTTP 8100", rig: "fetch POST /graphql; e2e fixtures/gateway.ts ops()", related: "SC-15.01.01", dependsOn: "", changed: "New" },
    { id: "SC-15.09.01", story: "US-15.09", epic: "EP-15", scenario: "Restart the persistence writers, the database pool and one vendor while a customer stays bound", gwt: "Given qa-acct-a bound on smpp and vendor qa-sim1 bound, in memory mode. When an admin restarts persist, db, db --hard, vendor qa-sim1 and config, and asks for kafka-router and a part that does not exist. Then each answers ok with health figures before and after and one ops.restart line, the customer's session id is the same afterwards and a message sent after each restart is delivered, the vendor rebinds with its queue kept, kafka-router is CONFLICT in memory mode and the unknown part BAD_REQUEST naming the parts.", preconditions: "rig gateway (memory backbone); admin token; qa-acct-a's SMPP login", rig: "GraphQL componentRestart; scripts/fireflo restart; cloudhopper/ESME; smsg.log", related: "SC-21.15.03, SC-26.04.01", dependsOn: "", changed: "New" },
    { id: "SC-15.10.01", story: "US-15.10", epic: "EP-15", scenario: "fireflo load, node and db restore against the rig", gwt: "Given the rig gateway, qa-acct-a's SMPP login and its password in an owner-only file. When fireflo load sends 10 messages at 5/s with --yes, then once with a wrong password; fireflo node self and node list run; and fireflo db restore is asked with a running gateway and without FIREFLO_DB_RESTORE. Then load exits 0 with 10 accepted and their receipts, the wrong password exits 1 naming the bind refusal, node self prints the id and node list the live row, and db restore refuses without touching the database.", preconditions: "scripts/fireflo from the 0.15.4 artefact; E2E_GATEWAY_REPO; a password file mode 600", rig: "CLI; psql cdr_submit, gateway_node", related: "SC-25.03.01", dependsOn: "", changed: "New" },
  ],
  cases: [
    // SC-15.08.01 — GraphQL-only port
    { id: "TC-15.08.01-P01", scenario: "SC-15.08.01", story: "US-15.08", epic: "EP-15", type: "Positive", title: "health answers with the read token and with the admin token", steps: "1. POST /graphql on 9100 {query: \"{ health { snapshot } }\"} with Authorization: Bearer <read token>. 2. The same with the admin token. 3. Compare data.health.snapshot with the old /ops/health keys (version, workers, config_sources).", testData: "read e2e-read-token, admin e2e-admin-token", expected: "Both HTTP 200, no errors; data.health.snapshot carries version 0.15.4, a workers array naming smppserver.smpp and smppclient.qa-sim1, and config_sources — the /ops/health document unchanged, snake_case and all", oracle: "HTTP status; JSON data.health.snapshot keys", antiVacuity: "The admin token answering READ is the 0.13 change (on /ops the two token sets were disjoint): a gateway that still kept them disjoint answers step 2 with errors NOT_FOUND, which is the half that can fail.", priority: "P0", component: "Gateway", automated: "GraphQlGuardTest", related: "TC-15.01.01-P01", surface: "Ops", changed: "New", changeNote: "0.13.0" },
    { id: "TC-15.08.01-N01", scenario: "SC-15.08.01", story: "US-15.08", epic: "EP-15", type: "Negative", title: "No token and a wrong token are 404 Not found before the document is read", steps: "1. POST /graphql {\"query\":\"{ health { snapshot } }\"} with no Authorization. 2. With Bearer nope. 3. With the read token and a body that is not JSON.", testData: "", expected: "1 and 2: HTTP 404, body {\"message\":\"Not found\"}, identical bytes; no data, no errors array. 3: an answer about the body (400 or a GraphQL error), proving the 404 in 1–2 came from the guard and not from a broken endpoint", oracle: "HTTP status and body text", antiVacuity: "An endpoint that 404s everything passes 1–2; step 3 with a valid token must get past the guard and answer something else.", priority: "P0", component: "Gateway", automated: "GraphQlGuardTest", related: "TC-15.01.01-N01", surface: "Ops", changed: "New", changeNote: "0.13.0" },
    { id: "TC-15.08.01-N02", scenario: "SC-15.08.01", story: "US-15.08", epic: "EP-15", type: "Negative", title: "The read token on an ADMIN field is HTTP 200 with errors NOT_FOUND 404, and nothing is done", steps: "1. With the read token: mutation { reload { adopted } }. 2. With the read token: { resolvedConfig }. 3. Read smsg.log for ops.reload after a mark.", testData: "", expected: "1 and 2: HTTP 200; errors[0].extensions = {code: \"NOT_FOUND\", status: 404}; data null for the field. 3: no ops.reload line (the reload did not run)", oracle: "errors[].extensions; smsg.log ops.reload absent", antiVacuity: "Asserting only 'not 200 data' would pass a 500; the code and status must be NOT_FOUND/404, and the log must show the mutation never ran.", priority: "P0", component: "Gateway", automated: "", related: "TC-15.01.01-N02", surface: "Ops", changed: "New", changeNote: "0.13.0" },
    { id: "TC-15.08.01-N03", scenario: "SC-15.08.01", story: "US-15.08", epic: "EP-15", type: "Negative", title: "/ops/* is gone on both ports, and the messaging port serves no /graphql", steps: "1. GET /ops/health on 9100 with the read token. 2. GET /ops/health on 8100. 3. GET /graphql on 9100 with the read token. 4. POST /graphql on 8100 with the admin token.", testData: "", expected: "All four HTTP 404; none returns a health document", oracle: "HTTP status", antiVacuity: "", priority: "P1", component: "Gateway", automated: "", related: "TC-15.01.01-N06", surface: "Ops", changed: "New", changeNote: "0.13.0" },
    { id: "TC-15.08.01-N04", scenario: "SC-15.08.01", story: "US-15.08", epic: "EP-15", type: "Negative", title: "A field naming something that is not there is NOT_FOUND inside a 200", steps: "1. With the read token: { sessions(worker: \"smppserver.nosuch\") { total } }. 2. With the admin token: mutation { testBind(worker: \"smppclient.nosuch\") }.", testData: "", expected: "Both HTTP 200 with errors[0].extensions.code = NOT_FOUND and status 404; the message names the worker", oracle: "errors[].extensions; message text", antiVacuity: "", priority: "P2", component: "Gateway", automated: "", related: "", surface: "Ops", changed: "New", changeNote: "0.13.0" },
    { id: "TC-15.08.01-N05", scenario: "SC-15.08.01", story: "US-15.08", epic: "EP-15", type: "Negative", title: "A peer outside smsg.ops.allowed.ips is refused 404 before its token is read", steps: "1. Bind FIREFLO_OPS_HOST to the LAN address; leave smsg.ops.allowed.ips empty. 2. From another host POST /graphql health with the admin token. 3. Add that host's address (or its /24) to smsg.ops.allowed.ips; repeat. 4. Read health.opsAllowList.", testData: "a second machine on the LAN", expected: "2: 404 Not found (empty list = loopback only); 3: 200 with data; 4: opsAllowList names the entries; smsg.log logs the refused peer at most once a minute", oracle: "HTTP status from the far host; health.opsAllowList; smsg.log", antiVacuity: "Loopback is always allowed, so this cannot be shown from the gateway host itself — the far host is the point.", priority: "P1", component: "Gateway", automated: "", related: "TC-15.01.01-N05", surface: "Host", changed: "New", changeNote: "0.13.0" },

    // SC-15.09.01 — component restart
    { id: "TC-15.09.01-P01", scenario: "SC-15.09.01", story: "US-15.09", epic: "EP-15", type: "Positive", title: "Restart persist: every writer replaced, figures before and after, the customer still bound", steps: "1. Bind qa-acct-a on smpp; note its session id in health. 2. Admin: mutation { componentRestart(component: \"persist\", by: \"qa\") }. 3. Read the answer and smsg.log after a mark. 4. Send one message on the same bind; wait for its cdr_submit row.", testData: "", expected: "ok true; detail starts 'N writers restarted' and says queued writes and the local log are kept; results lists each stream/lane (cdr, dlr-store, unpushed); before and after carry persist_writer and persist_streams; one INFO 'ops.restart component=persist target=- hard=false by=qa … ok=true'; the session id is unchanged and the message after the restart is recorded", oracle: "componentRestart JSON; smsg.log ops.restart; health sessions; cdr_submit", antiVacuity: "A restart that restarted the process would also answer ok — the unchanged session id and the message recorded after it are what prove only the writers moved.", priority: "P0", component: "Gateway", automated: "OpsRestartServiceTest", related: "", surface: "Ops", changed: "New", changeNote: "0.15.2" },
    { id: "TC-15.09.01-P02", scenario: "SC-15.09.01", story: "US-15.09", epic: "EP-15", type: "Positive", title: "Restart db and db --hard: the pool is reset and the next statement works", steps: "1. Admin: componentRestart(component: \"db\"). 2. componentRestart(component: \"db\", hard: true). 3. Send one message as qa-acct-a and wait for cdr_submit. 4. Read health database.pool before/after in each answer.", testData: "", expected: "Both ok; the hard one reports the persistence writers paused (persist_writer 'paused') then resumed within 10 s; the message after it is recorded; 'db takes no target' when a target is given", oracle: "componentRestart JSON (results, before, after); cdr_submit", antiVacuity: "", priority: "P1", component: "Gateway", automated: "", related: "", surface: "Ops", changed: "New", changeNote: "0.15.2 (db --hard pauses the writers from 0.15.4)" },
    { id: "TC-15.09.01-P03", scenario: "SC-15.09.01", story: "US-15.09", epic: "EP-15", type: "Positive", title: "Restart vendor qa-sim1 rebinds that vendor only and keeps its queue", steps: "1. Note qa-sim1's and qa-sim2's bound session ids (sessions(worker: \"smppclient.qa-sim1\")) and qa-acct-a's session. 2. Admin: componentRestart(component: \"vendor\", target: \"qa-sim1\"). 3. Wait for qa-sim1 bound again. 4. Send one message; wait for DELIVRD.", testData: "", expected: "ok, detail '1 connection(s) of smppclient.qa-sim1 closed; it binds again now. Its queue is kept …'; qa-sim1 bound again under a new session id; qa-sim2's session id unchanged; the customer's session unchanged; the message is delivered via qa-sim1", oracle: "componentRestart JSON; GraphQL sessions(worker) session ids; cdr_final", antiVacuity: "", priority: "P1", component: "Gateway", automated: "", related: "TC-04.04.01-P01", surface: "Ops", changed: "New", changeNote: "0.15.2" },
    { id: "TC-15.09.01-P04", scenario: "SC-15.09.01", story: "US-15.09", epic: "EP-15", type: "Positive", title: "fireflo restart config is reload, and prints health before -> after", steps: "1. scripts/fireflo restart config --by qa. 2. scripts/fireflo restart persist --json.", testData: "", expected: "1: exit 0, first line 'restart config: ok in N ms'; 2: exit 0 and a JSON document with component persist and ok true; each prints the 'health  before -> after' table", oracle: "CLI stdout and exit status", antiVacuity: "", priority: "P2", component: "Gateway", automated: "", related: "TC-15.01.01-P02", surface: "CLI", changed: "New", changeNote: "0.15.2" },
    { id: "TC-15.09.01-N01", scenario: "SC-15.09.01", story: "US-15.09", epic: "EP-15", type: "Negative", title: "An unknown part is BAD_REQUEST naming the parts; kafka-router in memory mode is CONFLICT", steps: "1. Admin: componentRestart(component: \"everything\"). 2. componentRestart(component: \"kafka-router\") on the memory-mode rig. 3. componentRestart(component: \"vendor\", target: \"nosuch\").", testData: "", expected: "1: errors code BAD_REQUEST, message 'Unknown part 'everything'. Parts: persist, db, kafka-router, kafka-consumers, vendor-feed, vendor, jobs, config.'; 2: CONFLICT (this backbone has no Kafka router); 3: a refusal naming the vendor; none writes an ops.restart ok=true line", oracle: "errors[].extensions.code and message; smsg.log", antiVacuity: "", priority: "P1", component: "Gateway", automated: "", related: "", surface: "Ops", changed: "New", changeNote: "0.15.2" },
    { id: "TC-15.09.01-N02", scenario: "SC-15.09.01", story: "US-15.09", epic: "EP-15", type: "Negative", title: "The read token cannot restart anything", steps: "1. With the read token: componentRestart(component: \"persist\").", testData: "", expected: "HTTP 200, errors code NOT_FOUND (an ADMIN field refused); no ops.restart line", oracle: "errors[].extensions; smsg.log", antiVacuity: "A refusal that ran the restart anyway would still answer an error; the absent ops.restart line is what proves nothing moved.", priority: "P0", component: "Gateway", automated: "", related: "TC-15.08.01-N02", surface: "Ops", changed: "New", changeNote: "0.15.2" },

    // SC-15.10.01 — CLI
    { id: "TC-15.10.01-P01", scenario: "SC-15.10.01", story: "US-15.10", epic: "EP-15", type: "Positive", title: "fireflo load sends 10 at 5/s as qa-acct-a and reads their receipts", steps: "1. Write qa-acct-a's SMPP password to a mode-600 file. 2. scripts/fireflo load --host 127.0.0.1 --port 27800 --system-id qa-acct-a-smpp --password-file F --tps 5 --count 10 --from QATEST --to 61400000001 --receipts --yes --json. 3. Count cdr_submit rows for the login since the start.", testData: "10 messages, one part each, price 0.0100", expected: "exit 0; the JSON summary offered 10, accepted 10, refused.total 0, verdict held, receipts.delivered 10, cost 'see the account statement'; 10 cdr_submit rows priced 0.0100; the balance down by 0.1000", oracle: "CLI JSON summary and exit status; cdr_submit; account_balance", antiVacuity: "A load tool that counts what it sent rather than what was answered passes 'accepted 10' on a broken bind; the 10 cdr_submit rows and the receipts are the gateway's own word.", priority: "P1", component: "Gateway", automated: "LoadCommandTest", related: "", surface: "CLI", changed: "New", changeNote: "0.15.1" },
    { id: "TC-15.10.01-N01", scenario: "SC-15.10.01", story: "US-15.10", epic: "EP-15", type: "Negative", title: "fireflo load with a wrong password exits 1; without --to it refuses before binding", steps: "1. The same command with a file holding a wrong password. 2. The same command without --to.", testData: "", expected: "1: exit 1, the bind refusal (invalid password) named, nothing sent; 2: exit 2 before anything connects, the message naming --to (it has no default); no bind attempt for the login in smsg.log", oracle: "CLI exit status and stderr; smsg.log auth.refused", antiVacuity: "", priority: "P2", component: "Gateway", automated: "", related: "", surface: "CLI", changed: "New", changeNote: "0.15.1" },
    { id: "TC-15.10.01-P02", scenario: "SC-15.10.01", story: "US-15.10", epic: "EP-15", type: "Positive", title: "fireflo node self prints the resolved id; node list shows the live row", steps: "1. scripts/fireflo node self. 2. scripts/fireflo node list. 3. Compare with health.snapshot node.id and gateway_node.", testData: "", expected: "1: the id the gateway runs under (FIREFLO_INSTANCE_ID, else the host name); 2: a row for that node with a heartbeat age under 30 s and alive; both equal health node.id", oracle: "CLI stdout; health node.id; psql gateway_node", antiVacuity: "", priority: "P2", component: "Gateway", automated: "", related: "TC-25.03.01-P01", surface: "CLI", changed: "New", changeNote: "0.14.2" },
    { id: "TC-15.10.01-N02", scenario: "SC-15.10.01", story: "US-15.10", epic: "EP-15", type: "Negative", title: "fireflo db restore refuses while a node is alive and without FIREFLO_DB_RESTORE", steps: "1. pg_dump the e2e database to a scratch file. 2. scripts/fireflo db restore FILE with the gateway running. 3. Repeat with FIREFLO_DB_RESTORE=true and the gateway running. 4. Count app_account rows before and after.", testData: "", expected: "2: refused, naming FIREFLO_DB_RESTORE=true; 3: refused, naming the live node (heartbeat under 90 s); exit non-zero both times; app_account count unchanged", oracle: "CLI exit status and stderr; psql count", antiVacuity: "A restore that half-ran would change the count; it must be byte-for-byte untouched.", priority: "P0", component: "Gateway", automated: "DbRestoreTest", related: "", surface: "CLI", changed: "New", changeNote: "0.15.0" },
  ],
  updates: [
    { id: "TC-14.01.01-N02", changed: "Updated", changeNote: "0.13.0: a lapsed licence is HTTP 200 with errors[].extensions LICENCE_LAPSED 402 on POST /graphql; a wrong token is still a plain 404", set: { title: "A lapsed licence refuses the licensed fields with LICENCE_LAPSED and the cause", steps: "1. { queues } with the read token. 2. The same with a wrong token. 3. { health { snapshot } } and { license { verdict } } with the read token.", expected: "1: HTTP 200, errors[0].extensions {code LICENCE_LAPSED, status 402}, message 'This gateway's licence is not current, so its operational controls are switched off. Messages are unaffected … Activate at /cp/verify or run 'fireflo license status'.' 2: 404 (auth before licence; a stranger learns nothing). 3: data for both (health and license are licence-exempt), health names the verdict.", oracle: "HTTP status; errors[].extensions; message" } },
    { id: "TC-15.01.01-N02", changed: "Updated", changeNote: "0.13.0: a field refused inside an admitted request is HTTP 200 with errors[].extensions, not a 404", set: { title: "Read token on an admin field is refused as NOT_FOUND inside a 200", steps: "mutation { reload { adopted } } on POST /graphql with the read token.", expected: "HTTP 200; errors[0].extensions {code NOT_FOUND, status 404}; the reload did not run", oracle: "errors[].extensions; smsg.log" } },
    { id: "TC-15.01.01-N06", changed: "Updated", changeNote: "0.13.0: the messaging port serves neither /ops nor /graphql", set: { title: "Message port serves neither /ops nor /graphql", steps: "GET :8080/ops/health; POST :8080/graphql with the admin token.", expected: "404 both" } },
    { id: "TC-15.01.01-N05", changed: "Updated", changeNote: "0.13.0: smsg.ops.allowed.ips is checked before any token; empty means loopback only", set: { steps: "1. curl from another host to :9000 with FIREFLO_OPS_HOST left at 127.0.0.1. 2. Widen FIREFLO_OPS_HOST, leave smsg.ops.allowed.ips empty, repeat with the admin token.", expected: "1: connection refused. 2: 404 Not found (peer not on the allow-list; loopback only by default)" } },
    { id: "TC-15.01.01-N07", changed: "Updated", changeNote: "0.13.0: one endpoint, POST /graphql, with an 8 MiB body limit", set: { title: "The GraphQL endpoint caps its body at 8 MiB and answers 413, with no effect", steps: "1. Build a 9 MiB JSON body (a whitelistTest query with a huge body variable). 2. POST it to /graphql with the admin token. 3. POST a 1 KiB valid whitelistTest. 4. Query license; ls the preprocessor directory.", expected: "Step 2: 413, connection closed cleanly, gateway unaffected. Step 3: 200. Step 4: licence unchanged; no file written; no WARN storm in smsg.log." } },
  ],
  focus: [
    { item: "0.13.0", change: "The management port is GraphQL-only: /ops/* is a plain 404 on both ports; every route is a field (api/graphql-port.json); the admin token satisfies READ; refusals before the document are 404, inside it 200 with errors[].extensions; /q/metrics moved to the messaging port; smsg.ops.allowed.ips (loopback only by default). 136 plan rows rewritten.", scenarios: "SC-15.08.01, SC-15.01.01", risk: "Anything that scraped /ops/health or /q/metrics on 9000 breaks; a panel older than 0.13.0.0 404s on every call." },
    { item: "0.15.2", change: "fireflo restart <part> / componentRestart: persist, db [--hard], kafka-router, kafka-consumers, vendor-feed, vendor, jobs, config — one part, not the process.", scenarios: "SC-15.09.01, SC-21.15.03", risk: "A restart that drops customer binds would be worse than the stall it cures; the session id must survive." },
    { item: "0.15.1", change: "fireflo load: SMPP traffic as a customer from the gateway binary.", scenarios: "SC-15.10.01", risk: "Real traffic: priced, charged, routed." },
  ],
};
export default change;
