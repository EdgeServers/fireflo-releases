/**
 * Builds 26-qa-test-plan-0.15.xlsx from the 0.12 workbook plus the change files in
 * scripts/qa-plan-0.15/changes/ (gateway and control panel) and, when present, FireFlo OMNI's change
 * files, and fills the automation columns from the e2e suites.
 *
 * Usage:
 *   node --experimental-strip-types scripts/qa-plan-0.15.ts [--src in.xlsx] [--out out.xlsx] [--omni DIR] [--omni-e2e DIR]
 *
 *   --src       QA_PLAN_SRC       default ../fireflo-sms-gateway/docs/26-qa-test-plan-0.12.xlsx
 *   --out       QA_PLAN_OUT       default ../fireflo-sms-gateway/docs/26-qa-test-plan-0.15.xlsx
 *   --omni      QA_PLAN_OMNI      default ../fireflo-omni-js/e2e/qa-plan/changes (skipped, with a note, when absent)
 *   --omni-e2e  QA_PLAN_OMNI_E2E  default ../fireflo-omni-js/e2e (its *.spec.ts fill OMNI's automation column)
 *
 * The 0.12 workbook is read, never written. First the 0.12 change files are carried forward: any of
 * their stories, scenarios or cases the input workbook lacks (it was built before they were written)
 * are added, and their updates re-applied (idempotent), so the input is the 0.12 plan as its change
 * files describe it. Then the 0.15 changes are applied and marked in the "Changed in 0.15" columns.
 * See scripts/qa-plan-0.15/README.md.
 */
import { createHash } from "node:crypto";
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import ExcelJS from "exceljs";
import type { Worksheet } from "exceljs";
import type { Change } from "./qa-plan-types.ts";
import {
  EPIC, SCEN, STORY, TARGET_012, TARGET_015, TC,
  addFocusSheet, addRigRows, applyEdits, applyNew, arg, automationFromSuite, col, fail, fillAutomation,
  fillSheet, header, indexAll, lastRun, loadChanges, orderSheets, readmeSetter, rewriteCountFormulas, sheetsOf, text, validate,
} from "./qa-plan-lib.ts";

const here = path.dirname(fileURLToPath(import.meta.url));
const panelRoot = path.join(here, "..");
const projects = path.join(panelRoot, "..");
const gatewayDocs = path.join(projects, "fireflo-sms-gateway", "docs");
const SRC = arg("src", "QA_PLAN_SRC", path.join(gatewayDocs, "26-qa-test-plan-0.12.xlsx"));
const OUT = arg("out", "QA_PLAN_OUT", path.join(gatewayDocs, "26-qa-test-plan-0.15.xlsx"));
const OMNI_DIR = arg("omni", "QA_PLAN_OMNI", path.join(projects, "fireflo-omni-js", "e2e", "qa-plan", "changes"));
const OMNI_E2E = arg("omni-e2e", "QA_PLAN_OMNI_E2E", path.join(projects, "fireflo-omni-js", "e2e"));
const CHANGES_012 = path.join(here, "qa-plan-0.12", "changes");
const CHANGES_015 = path.join(here, "qa-plan-0.15", "changes");
const E2E_EPICS = path.join(panelRoot, "e2e", "epics");
const E2E_RESULTS = path.join(panelRoot, "e2e", ".run", "results.json");

const GATEWAY_VERSION = "0.15.4";
const PANEL_VERSION = "0.15.4.0";
/** Epic ids FireFlo OMNI's change files may use; anything else from that directory is refused. */
const OMNI_EPICS = /^EP-3\d$/;

/** The 0.12 change files' rows the input workbook does not have yet, plus every 0.12 update. */
function carryForward(changes012: Change[], ix: ReturnType<typeof indexAll>): Change[] {
  const out: Change[] = [];
  for (const ch of changes012) {
    const stories = (ch.stories ?? []).filter((s) => !ix.stories.has(s.id));
    const scenarios = (ch.scenarios ?? []).filter((s) => !ix.scenarios.has(s.id));
    const cases = (ch.cases ?? []).filter((c) => !ix.cases.has(c.id));
    const known = (id: string) => ix.cases.has(id) || ix.scenarios.has(id) || ix.stories.has(id);
    const updates = (ch.updates ?? []).filter((u) => known(u.id));
    if (stories.length || scenarios.length || cases.length || updates.length) {
      out.push({ epic: ch.epic, stories, scenarios, cases, updates, focus: [] });
    }
  }
  return out;
}

async function main() {
  if (!existsSync(SRC)) fail(`no input workbook at ${SRC} (pass --src or QA_PLAN_SRC)`);
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.readFile(SRC);
  const srcSha = createHash("sha256").update(readFileSync(SRC)).digest("hex");
  const sheets = sheetsOf(wb);
  const before = { cases: sheets.cases.rowCount - 1 };

  // 1. the 0.12 change files, carried forward onto the input
  let ix = indexAll(sheets);
  const carried = carryForward(await loadChanges(CHANGES_012), ix);
  validate(carried.map((c) => ({ ...c, updates: [] })), ix, { base: "0.12" });
  const carriedApplied = applyNew(sheets, carried, ix, TARGET_012);
  applyEdits(sheets, carried, TARGET_012, carriedApplied);

  // 2. the 0.15 change files: the gateway and panel's own, then OMNI's
  ix = indexAll(sheets);
  //QA_PLAN_ONLY=EP-09,EP-10 validates a subset while other change files are still being written
  const only = (process.env.QA_PLAN_ONLY ?? "").split(",").map((x) => x.trim()).filter(Boolean);
  const own = await loadChanges(CHANGES_015, { only });
  for (const ch of own) if (OMNI_EPICS.test(ch.epic)) fail(`${ch.epic}: EP-30…EP-39 are OMNI's; the gateway and panel use EP-01…EP-29`);
  const omniPresent = existsSync(OMNI_DIR);
  const omni = omniPresent ? await loadChanges(OMNI_DIR, { label: path.relative(process.cwd(), OMNI_DIR), only }) : [];
  for (const ch of omni) {
    if (!OMNI_EPICS.test(ch.epic)) fail(`${OMNI_DIR}: ${ch.epic} is outside OMNI's EP-30…EP-39`);
    //a new OMNI epic is OMNI's unless it says otherwise; its name may come as epicTitle
    if (!ch.epicComponent) ch.epicComponent = "OMNI";
    if (!ch.epicName && ch.epicTitle) ch.epicName = ch.epicTitle;
  }
  const changes = [...own, ...omni];
  validate(changes, ix, {
    base: "0.12",
    components: ["Gateway", "Control Panel", "Cross-component", "OMNI"],
    surfaces: ["SMPP", "HTTP", "Ops", "CLI", "Panel", "Portal", "API", "Host", "OMNI Panel", "OMNI API"],
  });

  // the 0.15 columns, appended after everything the 0.12 build added
  header(sheets.stories, STORY.changed015, "Changed in 0.15", 10);
  header(sheets.scenarios, SCEN.changed015, "Changed in 0.15", 10);
  header(sheets.cases, TC.changed015, "Changed in 0.15", 10);
  header(sheets.cases, TC.changeNote015, "Change note 0.15 (release: why)", 40);
  header(sheets.epics, EPIC.nChanged015, "# Changed in 0.15", 9);

  const added = applyNew(sheets, changes, ix, TARGET_015);
  applyEdits(sheets, changes, TARGET_015, added);
  const focus = added.focus;

  // automation and last run, every TC: the panel suite, and OMNI's when it is beside this repo
  const auto = automationFromSuite(E2E_EPICS);
  if (existsSync(OMNI_E2E)) automationFromSuite(OMNI_E2E, auto);
  //OMNI's cases name their test in `automated` ("<spec> › <title>" or a pytest node id) rather
  //than declaring tc("TC-…"): a named test is Automated, a blank one Manual
  for (const ch of omni) for (const c of ch.cases ?? []) if (!auto.has(c.id)) auto.set(c.id, { kind: c.automated?.trim() ? "Automated" : "Manual", spec: c.automated ?? "" });
  const run = lastRun(E2E_RESULTS);
  const counts = fillAutomation(sheets, auto, run, [TC.changed015, TC.changeNote015]);

  rewriteCountFormulas(wb, [{ epicCol: EPIC.nChanged, tcCol: TC.changed }, { epicCol: EPIC.nChanged015, tcCol: TC.changed015 }]);
  for (const [ws, width] of [[sheets.epics, EPIC.nChanged015], [sheets.stories, STORY.changed015], [sheets.scenarios, SCEN.changed015], [sheets.cases, TC.changeNote015]] as [Worksheet, number][]) {
    ws.autoFilter = { from: "A1", to: `${col(width)}${ws.rowCount}` };
  }

  // README
  const readme = wb.getWorksheet("README") ?? fail("no README");
  readme.getRow(1).getCell(1).value = `FireFlo ${GATEWAY_VERSION} — QA Test Plan`;
  const setReadme = readmeSetter(readme);
  setReadme("Scope", `FireFlo SMS Gateway ${GATEWAY_VERSION} (fireflo-sms-gateway), FireFlo Control Panel ${PANEL_VERSION} (operator panel /cp and customer portal)${omni.length ? " and FireFlo OMNI (EP-30 onwards, contributed by fireflo-omni-js)" : ""}. Carried forward from the 0.12 plan: every 0.12 id is kept with its row; what 0.13.0 – 0.15.4 changed is marked, never renumbered.`);
  setReadme("Changed in 0.12", "History. On Stories, Scenarios and TestCases: what 0.11.3 – 0.12.x added (New) or changed (Updated), with the 0.12 change note. The '0.12 Focus (history)' sheet is the release-by-release record.");
  setReadme("Changed in 0.15", "On Stories, Scenarios and TestCases: New (added for 0.13.0 – 0.15.4, and the panel's 0.13.0.0 – 0.15.4.0), Updated (a 0.12 row whose steps, expected result or wording changed with the behaviour; 'Change note 0.15' says which release and why, several notes joined by ' | '), Retired (kept, greyed, Status N/A, reason in the note; no longer a test in the e2e suite). Blank = unchanged since 0.12. See the '0.15 Focus' sheet for the release-by-release list.");
  setReadme("Automation", "Filled from the Playwright suite in fireflo-control-panel/e2e (and, for OMNI's epics, fireflo-omni-js/e2e when it is beside it) at build time: Automated (a real test() exists for the id), Todo (scaffolded, not written), Manual (needs a restart, a broker, a keystore or a real host), Fixme (written, known broken), Blocked (written, the product does not ship it). 'Last e2e run' is the status from e2e/.run/results.json of the last run on the build machine, partial runs included.");
  setReadme("Surface", "What drives the case: SMPP (an ESME client), HTTP (/secure/*), Ops (the management port, POST /graphql on 9000 since 0.13), CLI (fireflo … on the host), Panel / Portal (a browser), API (a panel /api/* route with no UI), Host (restart, broker, keystore, real machine — stays manual), OMNI Panel / OMNI API (FireFlo OMNI's).");
  setReadme("Rate and limit fields", "Every case that involves a throughput field names its key, its scope, what it limits and where it sits in the order at the door: a login's TPS (app_credential.max_tps, dedicated, first) → the account's conf.maxRate.<account> (per listener, or gateway-wide outSms.default.conf.maxRate.<account>) → min(the listener's conf.maxRate.default × cluster share, the listener's tps ÷ active accounts) (the port share, 0.15.2). Over the ceiling a submit is refused 0x58 (ESME_RTHROTTLED) and not charged; a block of credit not yet in hand is 0x14 creditPending, also not charged. A vendor's tps limits what the gateway sends to that vendor, never what customers submit.");
  setReadme("Source", `Built by fireflo-control-panel/scripts/qa-plan-0.15.ts from 26-qa-test-plan-0.12.xlsx (sha256 ${srcSha.slice(0, 12)}…) plus scripts/qa-plan-0.12/changes (carried forward) and scripts/qa-plan-0.15/changes/EP-*.ts${omni.length ? `, and ${omni.length} OMNI change file(s) from fireflo-omni-js/e2e/qa-plan/changes` : ""}. Edit the change files and rebuild; do not hand-edit the plan columns.`);

  // Traceability: regenerate with whole-column formulas so added rows count
  const tr = wb.getWorksheet("Traceability") ?? fail("no Traceability");
  const f = (formula: string) => ({ formula });
  const C = col(TC.changed);
  const C15 = col(TC.changed015);
  const A = col(TC.automation);
  const trRows: (string | { formula: string })[][] = [
    ["Epics", f("COUNTA(Epics!A:A)-1"), "Epics sheet"],
    ["Stories", f("COUNTA(Stories!A:A)-1"), "Stories sheet"],
    ["Scenarios", f("COUNTA(Scenarios!A:A)-1"), "Scenarios sheet"],
    ["Test cases", f("COUNTA(TestCases!A:A)-1"), "TestCases sheet"],
    ["  Positive", f('COUNTIF(TestCases!E:E,"Positive")')],
    ["  Negative", f('COUNTIF(TestCases!E:E,"Negative")')],
    ["  P0", f('COUNTIF(TestCases!L:L,"P0")')],
    ["  P1", f('COUNTIF(TestCases!L:L,"P1")')],
    ["  P2", f('COUNTIF(TestCases!L:L,"P2")')],
    ["  New in 0.11 (history)", f('COUNTIF(TestCases!N:N,"Y")')],
    ["  New in 0.12 (history)", f(`COUNTIF(TestCases!${C}:${C},"New")`)],
    ["  Updated in 0.12 (history)", f(`COUNTIF(TestCases!${C}:${C},"Updated")`)],
    ["  New in 0.15", f(`COUNTIF(TestCases!${C15}:${C15},"New")`)],
    ["  Updated in 0.15", f(`COUNTIF(TestCases!${C15}:${C15},"Updated")`)],
    ["  Retired in 0.15", f(`COUNTIF(TestCases!${C15}:${C15},"Retired")`)],
    ["  Automated (e2e)", f(`COUNTIF(TestCases!${A}:${A},"Automated")`), "from the suites at build time"],
    ["  Todo (scaffolded)", f(`COUNTIF(TestCases!${A}:${A},"Todo")`)],
    ["  Manual", f(`COUNTIF(TestCases!${A}:${A},"Manual")`)],
    ["  Blocked (product does not ship it)", f(`COUNTIF(TestCases!${A}:${A},"Blocked")`)],
    ["  Not in a suite yet", f(`COUNTA(TestCases!A:A)-1-COUNTA(TestCases!${A}:${A})+1`)],
    ["  TCs naming a specific unit test", f("COUNTA(TestCases!O:O)-1"), "non-blank 'Automated coverage'"],
    ["  With an anti-vacuity check", f("COUNTA(TestCases!K:K)-1")],
    ["  Gateway", f('COUNTIF(TestCases!M:M,"Gateway")')],
    ["  Control Panel", f('COUNTIF(TestCases!M:M,"Control Panel")')],
    ["  Cross-component", f('COUNTIF(TestCases!M:M,"Cross-component")')],
    ["  OMNI", f('COUNTIF(TestCases!M:M,"OMNI")')],
    ["Execution: Pass", f('COUNTIF(TestCases!Q:Q,"Pass")'), "fill Status on TestCases"],
    ["Execution: Fail", f('COUNTIF(TestCases!Q:Q,"Fail")')],
    ["Execution: Blocked", f('COUNTIF(TestCases!Q:Q,"Blocked")')],
    ["Execution: Not run", f('COUNTIF(TestCases!Q:Q,"Not run")')],
  ];
  const passRow = trRows.findIndex((r) => r[0] === "Execution: Pass") + 2;
  trRows.push(["Execution: % complete", f(`IF(B5=0,0,(B${passRow}+B${passRow + 1})/B5)`), "pass+fail over total"]);
  trRows.push([""]);
  trRows.push(["Epic", "Name", "TCs", "P0", "Changed 0.15", "Automated", "Todo", "Manual", "Pass", "Fail"]);
  const epicCount = sheets.epics.rowCount - 1;
  for (let i = 0; i < epicCount; i++) {
    const e = i + 2;
    const r = trRows.length + 2;
    trRows.push([f(`Epics!A${e}`), f(`Epics!B${e}`), f(`Epics!G${e}`), f(`Epics!J${e}`), f(`Epics!${col(EPIC.nChanged015)}${e}`), f(`Epics!${col(EPIC.nAuto)}${e}`), f(`Epics!${col(EPIC.nTodo)}${e}`), f(`Epics!${col(EPIC.nManual)}${e}`), f(`COUNTIFS(TestCases!$D:$D,A${r},TestCases!$Q:$Q,"Pass")`), f(`COUNTIFS(TestCases!$D:$D,A${r},TestCases!$Q:$Q,"Fail")`)]);
  }
  fillSheet(tr, trRows);
  tr.getColumn(1).width = 34;
  for (let c = 4; c <= 10; c++) tr.getColumn(c).width = 10;

  // 0.15 Focus before the 0.12 one, which becomes history
  const old12 = wb.getWorksheet("0.12 Focus") ?? wb.getWorksheet("0.12 Focus (history)") ?? fail("no 0.12 Focus");
  const fx = addFocusSheet(wb, "0.15 Focus", old12, focus);
  old12.name = "0.12 Focus (history)";

  // Coverage: the backlog view, rebuilt for 0.15
  const prior = wb.getWorksheet("Coverage");
  if (prior) wb.removeWorksheet(prior.id);
  const cov = wb.addWorksheet("Coverage", { views: [{ state: "frozen", ySplit: 1 }] });
  wb.worksheets.splice(wb.worksheets.indexOf(cov), 1);
  wb.worksheets.splice(wb.worksheets.indexOf(fx), 0, cov);
  const covHead = ["Epic", "Name", "Component", "TCs", "Automated", "Todo", "Manual", "Not in suite", "New in 0.15", "Updated in 0.15", "Automated %", "Order", "Note"];
  covHead.forEach((h, i) => {
    cov.getRow(1).getCell(i + 1).value = h;
    cov.getRow(1).getCell(i + 1).style = { ...old12.getRow(1).getCell(1).style };
  });
  cov.getRow(1).height = 31.5;
  [9, 44, 15, 7, 10, 7, 8, 10, 10, 11, 11, 8, 60].forEach((w, i) => (cov.getColumn(i + 1).width = w));
  const notes: Record<string, [number, string]> = {
    "EP-02": [1, "The door: login TPS → account override → port share, 0x58 uncharged (US-02.09); door refusals before the charge (US-02.10)"],
    "EP-18": [2, "Account overview's SMPP ceiling card, the Limits page, Debit on Billing"],
    "EP-09": [3, "Debit (V1.126.0) and the credit-block health"],
    "EP-26": [4, "Persistence bus, local log, receipt custody: mostly Host (kill -9, a stopped PostgreSQL)"],
    "EP-15": [5, "GraphQL-only management port and component restart"],
    "EP-21": [6, "Display zone, Connectivity, Queues cards"],
    "EP-20": [7, "Copy sender IDs and templates to several accounts"],
    "EP-25": [8, "Kafka backbone and cluster: needs a broker (E2E_QUEUE_PROVIDER=kafka) or two nodes; mostly manual"],
    "EP-27": [9, "Platform API on the management port (OMNI's side of it is EP-30 onwards)"],
  };
  const covRows: (string | number | { formula: string })[][] = [];
  for (let i = 0; i < epicCount; i++) {
    const e = i + 2;
    const r = i + 2;
    const id = text(sheets.epics.getRow(e).getCell(1));
    const [order, note] = notes[id] ?? [99, ""];
    covRows.push([f(`Epics!A${e}`), f(`Epics!B${e}`), f(`Epics!C${e}`), f(`Epics!G${e}`), f(`Epics!${col(EPIC.nAuto)}${e}`), f(`Epics!${col(EPIC.nTodo)}${e}`), f(`Epics!${col(EPIC.nManual)}${e}`), f(`D${r}-E${r}-F${r}-G${r}-COUNTIFS(TestCases!$D:$D,A${r},TestCases!$${A}:$${A},"Fixme")-COUNTIFS(TestCases!$D:$D,A${r},TestCases!$${A}:$${A},"Blocked")`), f(`COUNTIFS(TestCases!$D:$D,A${r},TestCases!$${C15}:$${C15},"New")`), f(`COUNTIFS(TestCases!$D:$D,A${r},TestCases!$${C15}:$${C15},"Updated")`), f(`IF(D${r}=0,0,E${r}/D${r})`), order, note]);
  }
  fillSheet(cov, covRows);
  for (let r = 2; r <= cov.rowCount; r++) cov.getCell(`K${r}`).numFmt = "0%";
  cov.autoFilter = { from: "A1", to: `M${cov.rowCount}` };

  // Rigs & Tools: what 0.13 – 0.15 added
  const rigs = wb.getWorksheet("Rigs & Tools") ?? fail("no Rigs");
  addRigRows(rigs, [
    ["The management port is GraphQL (0.13+)", "POST /graphql on 9000 (rig 9100) with Authorization: Bearer <read|admin token>; scripts/fireflo <verb> wraps it; /q/metrics on the messaging port with the read token", "Every former /ops/* route is a field (api/graphql-port.json maps them). A refusal before the document is read is HTTP 404; inside an admitted request a refusal is 200 with errors[].extensions {code, status}."],
    ["fireflo load (0.15.1)", "fireflo load --system-id … --password-file … --tps N --count N --to 614… --yes [--json]", "Real SMPP traffic as one of the gateway's customers, from the gateway binary; priced, charged and routed. Exit 0 completed, 1 bind/transport failure, 2 refused."],
    ["fireflo restart <part> (0.15.2)", "fireflo restart persist|db [--hard]|kafka-router|kafka-consumers|vendor-feed <v>|vendor <v>|jobs [name]|config", "One part of the running gateway; answers its health figures before → after; one INFO ops.restart line each. GraphQL componentRestart, admin token."],
    ["Kafka broker for the Kafka cases", "192.168.1.101:9092 (Apache Kafka 4.4.0 KRaft) · E2E_QUEUE_PROVIDER=kafka E2E_KAFKA_BOOTSTRAP=… for the e2e rig", "EP-25 needs a broker. The e2e rig names its topics fireflo-e2e-<stamp>. and deletes them at teardown. Two-node cases need a second gateway on another FIREFLO_NODE_PORT_OFFSET."],
    ["Platform signature (0.13+)", "X-FireFlo-Timestamp / -Nonce / -Signature = HMAC-SHA256(management token, canonical string with path /graphql and the SHA-256 of the body)", "OMNI's way in; the admin bearer token also opens the PLATFORM fields, which is how the e2e rig drives them."],
  ]);

  // sheet order: the plan, then the two views, then history and tools
  orderSheets(wb, ["README", "Epics", "Stories", "Scenarios", "TestCases", "Traceability", "Coverage", "0.15 Focus", "0.12 Focus (history)", "0.11 Focus (history)", "Rigs & Tools"]);

  wb.creator = "fireflo-control-panel/scripts/qa-plan-0.15.ts";
  wb.modified = new Date();
  await wb.xlsx.writeFile(OUT);

  const total = sheets.cases.rowCount - 1;
  const byEpic = new Map<string, number>();
  for (const ch of changes) byEpic.set(ch.epic, (ch.cases ?? []).length);
  console.log(`wrote ${path.relative(process.cwd(), OUT)}`);
  console.log(`  epics ${sheets.epics.rowCount - 1}, stories ${sheets.stories.rowCount - 1}, scenarios ${sheets.scenarios.rowCount - 1}, test cases ${total} (input had ${before.cases})`);
  console.log(`  0.12 carried forward: stories ${carriedApplied.stories}, scenarios ${carriedApplied.scenarios}, cases ${carriedApplied.cases}; 0.12 updates re-applied ${carriedApplied.updates}`);
  console.log(`  0.15: epics ${added.epics}, stories ${added.stories}, scenarios ${added.scenarios}, cases ${added.cases}; updated ${added.updates}; rewritten rows ${added.rewritten}; retired ${added.retired}; focus rows ${focus.length}`);
  console.log(`  OMNI: ${omniPresent ? `${omni.length} change file(s) from ${OMNI_DIR}` : `none (${OMNI_DIR} is absent; built without OMNI)`}`);
  console.log(`  automation: automated ${counts.Automated}, todo ${counts.Todo}, manual ${counts.Manual}, fixme ${counts.Fixme}, blocked ${counts.Blocked}, not in a suite ${counts.none}; last run ${run.at || "none"} (${run.results.size} results)`);
  console.log(`  new cases by epic: ${[...byEpic].filter(([, n]) => n).map(([e, n]) => `${e}:${n}`).join(" ")}`);
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});
