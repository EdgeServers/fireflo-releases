/**
 * Receipt custody (gateway 0.15.3), as the Queues, Vendors and Database cards show it. Pure.
 *
 * <p>A vendor's delivery receipt is taken into custody -- Kafka `fireflo.receipts.in`, or the local
 * log in memory mode -- before the vendor is told OK, and matched against the receipt store at the
 * database's pace. So a slow database shows as receipts *waiting*, never as receipts a vendor was
 * asked to resend. Health's `receipts_in` says how many wait, how old the oldest is, the rates in and
 * matched, per vendor, and a state; `api.receipt_custody` says the gateway does this at all.
 */

import { RECEIPT_CUSTODY, hasCapability } from "./capabilities.ts";
import { count } from "./format.ts";
import type { Health, HealthReceiptsIn } from "./health-types";

export type CustodyState = "OK" | "SLOW" | "BACKING_UP";

/** The pill on the card: its tone and word. */
export interface CustodyPill {
  tone: "success" | "warning" | "destructive";
  label: string;
}

/** The waiting receipts as the card reads them: numbers, never undefined. */
export interface ReceiptsWaiting {
  depth: number;
  oldestAgeSeconds: number | null;
  inPerSecond: number | null;
  matchedPerSecond: number | null;
  state: CustodyState;
  vendors: { worker: string; depth: number; oldestAgeSeconds: number | null }[];
}

const num = (v: unknown): number | null => (typeof v === "number" && Number.isFinite(v) ? v : v != null && v !== "" && Number.isFinite(Number(v)) ? Number(v) : null);

/** The state as one of the three, an unknown or missing one read as OK only when nothing waits. */
export function custodyState(raw: string | null | undefined, depth = 0): CustodyState {
  const s = (raw ?? "").trim().toUpperCase().replace(/[\s-]+/g, "_");
  if (s === "OK" || s === "SLOW" || s === "BACKING_UP") {
    return s;
  }
  return depth > 0 ? "SLOW" : "OK";
}

/** OK quiet, Slow amber, Backing up red: the mockup's three pills. */
export function custodyPill(state: CustodyState): CustodyPill {
  switch (state) {
    case "SLOW":
      return { tone: "warning", label: "Slow" };
    case "BACKING_UP":
      return { tone: "destructive", label: "Backing up" };
    default:
      return { tone: "success", label: "OK" };
  }
}

/**
 * Health's `receipts_in`, read for the card, or null when the gateway publishes none -- an older
 * gateway, which hides the card rather than showing it empty.
 */
export function receiptsWaiting(health: Health | null | undefined): ReceiptsWaiting | null {
  const r: HealthReceiptsIn | null | undefined = health?.receipts_in;
  if (!r || typeof r !== "object") {
    return null;
  }
  const depth = num(r.depth) ?? 0;
  return {
    depth,
    oldestAgeSeconds: num(r.oldest_age_seconds),
    inPerSecond: num(r.in_per_second),
    matchedPerSecond: num(r.matched_per_second),
    state: custodyState(r.state, depth),
    vendors: (Array.isArray(r.vendors) ? r.vendors : [])
      .filter((v) => v && typeof v.worker === "string")
      .map((v) => ({ worker: v.worker, depth: num(v.depth) ?? 0, oldestAgeSeconds: num(v.oldest_age_seconds) })),
  };
}

/** Whether this gateway takes receipts into custody (`api.receipt_custody`, 0.15.3). */
export function hasReceiptCustody(health: Health | null | undefined): boolean {
  return hasCapability(health, RECEIPT_CUSTODY) || health?.receipts_in != null;
}

/**
 * How many of one vendor's receipts wait to be matched, or null when the gateway does not say.
 *
 * <p>Health names a worker by its full name (`smppclient.smppsim`) where `app_worker` has the
 * instance alone, so both are tried; a vendor the list leaves out has none waiting once the
 * gateway reports the block at all.
 */
export function vendorWaiting(health: Health | null | undefined, fullName: string, name?: string): number | null {
  const r = receiptsWaiting(health);
  if (!r) {
    return null;
  }
  const bare = name ?? fullName.replace(/^[^.]*\./, "");
  const row = r.vendors.find((v) => v.worker === fullName) ?? r.vendors.find((v) => v.worker === bare);
  return row ? row.depth : 0;
}

/** An age the way the card writes it: `0.2 s`, `21 s`, `4 min 2 s`, `1 h 5 min`; a dash for none. */
export function ageLabel(seconds: number | null | undefined): string {
  if (seconds == null || !Number.isFinite(seconds)) {
    return "—";
  }
  const s = Math.max(0, seconds);
  if (s < 10) {
    return `${Math.round(s * 10) / 10} s`;
  }
  if (s < 60) {
    return `${Math.round(s)} s`;
  }
  const m = Math.floor(s / 60);
  if (m < 60) {
    const rest = Math.round(s - m * 60);
    return rest ? `${m} min ${rest} s` : `${m} min`;
  }
  const h = Math.floor(m / 60);
  const restM = m - h * 60;
  return restM ? `${h} h ${restM} min` : `${h} h`;
}

/** `198 / 198`: in and matched per second, whole, grouped; a dash for a rate not measured. */
export function rateLabel(inPerSecond: number | null, matchedPerSecond: number | null): string {
  const one = (v: number | null) => (v == null ? "—" : count(Math.round(v)));
  return `${one(inPerSecond)} / ${one(matchedPerSecond)}`;
}

/** How many depth readings the card's sparkline keeps: 30 polls, five minutes at ten seconds. */
export const DEPTH_RING = 30;

/** One reading appended to the card's ring, once per health poll; the oldest falls off. */
export function appendDepth(ring: readonly number[], depth: number, size = DEPTH_RING): number[] {
  return [...ring, depth].slice(-size);
}

/** Where the receipts are held: the Kafka topic in Kafka mode, the local log in memory mode. */
export function custodyPlace(kafka: boolean): string {
  return kafka ? "Kafka (fireflo.receipts.in)" : "the gateway's local log";
}

/** The card's explanatory line, under the figures. */
export function custodyExplainer(kafka: boolean): string {
  return `Receipts the vendors sent, held in ${custodyPlace(kafka)} until the receipt store records `
    + "them. The vendor was told OK when they were taken; none is ever asked to resend because the "
    + "database is slow.";
}

/** The vendor card's line under its figures, when "waiting to match" is shown. */
export const VENDOR_WAITING_EXPLAINER =
  "DLR received counts receipts as they arrive; waiting to match is how many of them the database "
  + "has not recorded yet.";

/** The database as receipt custody sees it: answering, slow, or not answering. */
export type DbCustodyState = "ok" | "slow" | "down";

/**
 * The database's state for the custody note, from the admission the ingresses measure: OK answers
 * in time, DEGRADED is slow, REFUSING -- or a probe the gateway reports failing -- is not answering.
 * Null when the gateway reports no admission (before 0.15.1), which leaves the note out.
 */
export function dbCustodyState(health: Health | null | undefined): DbCustodyState | null {
  const a = health?.db_admission;
  if (!a) {
    return null;
  }
  if (a === "REFUSING") {
    return "down";
  }
  return a === "DEGRADED" ? "slow" : "ok";
}

/**
 * The Database card's note for each state, when the gateway holds receipts in custody.
 *
 * @param kafka Kafka mode: receipts wait in the topic. In memory mode they wait in the local log
 */
export function dbCustodyNote(state: DbCustodyState, kafka = true): string {
  switch (state) {
    case "slow":
      return `Slow to answer. Receipts are kept in ${kafka ? "Kafka" : "the local log"} and matched as it answers; `
        + "vendors are not asked to resend.";
    case "down":
      return `Not answering. Receipts and call records are kept (${kafka ? "Kafka and the local log" : "the local log"}) `
        + "and written when it is back. Nothing is lost while it is away.";
    default:
      return "Answering in time. Call records and receipts are written as they arrive.";
  }
}

/** Whether the Database card shows the "Local log (write-ahead)" row: the mode says write-ahead. */
export function isWriteAhead(health: Health | null | undefined): boolean {
  return (health?.persist_log_mode ?? "").trim().toLowerCase() === "write-ahead";
}
