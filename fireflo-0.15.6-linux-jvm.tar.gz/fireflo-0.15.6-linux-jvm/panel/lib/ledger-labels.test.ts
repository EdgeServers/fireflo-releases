import { test } from "node:test";
import assert from "node:assert/strict";
import { ledgerTypeLabel, noteInTypeLabel, signedDelta } from "./ledger-labels.ts";

test("a debit takes money away: its positive delta reads negative", () => {
  assert.equal(signedDelta("DEBIT", 1_000_000), -1_000_000);
  assert.equal(signedDelta("DEBIT", -1_000_000), -1_000_000, "already signed stays signed");
  assert.equal(signedDelta("RECHARGE", 1_000_000), 1_000_000);
  assert.equal(signedDelta("TRANSFER", 50), 50);
});

test("a debit is named with its reason; the other types in words", () => {
  assert.equal(ledgerTypeLabel("DEBIT", "Over-credit on 7 Nov top-up"), "Debit · Over-credit on 7 Nov top-up");
  assert.equal(ledgerTypeLabel("DEBIT", "  "), "Debit");
  assert.equal(ledgerTypeLabel("DEBIT", null), "Debit");
  assert.equal(ledgerTypeLabel("RECHARGE", "x"), "Top up");
  assert.equal(ledgerTypeLabel("ADJUSTMENT", null), "Adjustment");
  assert.equal(ledgerTypeLabel("SOMETHING_NEW", null), "SOMETHING_NEW", "an unknown type still shows, by its name");
  assert.equal(noteInTypeLabel("DEBIT"), true);
  assert.equal(noteInTypeLabel("RECHARGE"), false);
});
