import { test } from "node:test";
import assert from "node:assert/strict";
import { compareSchemaVersions, EXPECTED_SCHEMA_VERSION, gatewayRelease, schemaPairing, versionPairing } from "./version-pairing.ts";

/**
 * The panel/gateway pairing check.
 *
 * <p>This exists because a stale panel build is invisible: it renders perfectly, talks to the
 * gateway perfectly, and claims a version it was not built from. The case that prompted it was a
 * server showing 0.4.1.2 against a 0.4.2 gateway after an update appeared to succeed.
 */

test("a panel-only revision still pairs with the gateway it names", () => {
  //0.4.1.1 means "the panel that goes with gateway 0.4.1, first revision" -- the fourth number is
  //the panel's own and must not make the pair look mismatched
  assert.equal(versionPairing("0.4.1.1", "0.4.1").verdict, "matched");
  assert.equal(versionPairing("0.4.1+1", "0.4.1").verdict, "matched",
    "package.json spells the same thing with a plus, because npm requires valid semver");
});

test("an exact match is silent", () => {
  const p = versionPairing("0.4.2", "0.4.2");
  assert.equal(p.verdict, "matched");
  assert.equal(p.message, null, "a matched pair must say nothing at all");
});

test("the case this was built for: a stale panel against a newer gateway", () => {
  const p = versionPairing("0.4.1.2", "0.4.2");
  assert.equal(p.verdict, "mismatched");
  assert.match(p.message ?? "", /built for gateway 0\.4\.1/);
  assert.match(p.message ?? "", /talking to 0\.4\.2/);
  //the useful instruction: do not trust either screen until you know which one is behind
  assert.match(p.message ?? "", /check which/);
});

test("a newer panel against an older gateway is just as wrong", () => {
  assert.equal(versionPairing("0.5.0", "0.4.2").verdict, "mismatched");
});

test("a gateway too old to report a version is not a fault", () => {
  //the field did not exist before this change, so an older gateway simply omits it. Warning here
  //would train people to ignore the warning that matters
  for (const missing of [null, undefined, "", "   "]) {
    const p = versionPairing("0.4.2", missing);
    assert.equal(p.verdict, "unknown");
    assert.equal(p.message, null);
  }
});

test("the gateway's own fallback string is treated as no answer", () => {
  //OpsHealthService sends "unknown" in a dev run with no version configured
  const p = versionPairing("0.4.2", "unknown");
  assert.equal(p.verdict, "unknown");
  assert.equal(p.message, null);
  assert.equal(p.gateway, "unknown", "but it is still shown, rather than hidden");
});

test("the release is the first three numbers, in either spelling", () => {
  assert.equal(gatewayRelease("0.4.1"), "0.4.1");
  assert.equal(gatewayRelease("0.4.1.7"), "0.4.1");
  assert.equal(gatewayRelease("0.4.1+7"), "0.4.1");
  assert.equal(gatewayRelease("10.20.30.40"), "10.20.30");
});

test("anything that is not three numbers yields nothing to compare", () => {
  for (const bad of ["", "  ", "0.4", "unknown", "v0.4.1", "0.4.x"]) {
    assert.equal(gatewayRelease(bad), null, bad);
  }
});

test("the gateway's product prefix is stripped before comparing", () => {
  //the gateway reports "FireFlo 0.5.0" so a version read out of a log or a ticket says what it is a
  //version of. If this parser did not know that, gatewayRelease would return null, every pair would
  //degrade to "unknown", and the mismatch warning would stop appearing -- silently, and looking
  //exactly like a correctly matched pair
  assert.equal(gatewayRelease("FireFlo 0.5.0"), "0.5.0");
  assert.equal(gatewayRelease("  FireFlo 0.5.0  "), "0.5.0");
});

test("a prefixed gateway version still matches a bare panel version", () => {
  const p = versionPairing("0.5.0.1", "FireFlo 0.5.0");

  assert.equal(p.verdict, "matched");
  assert.equal(p.message, null, "a matched pair says nothing, prefix or not");
});

test("a prefixed gateway version still reports a real mismatch", () => {
  //a panel one gateway release behind, which is what 0.4.5.6 against 0.5.0 was until the panel
  //caught up. Kept as the mismatch case precisely because it really happened. The warning
  //appearing is the proof the prefix was parsed -- silence here would mean the parser broke
  const p = versionPairing("0.4.5.6", "FireFlo 0.5.0");

  assert.equal(p.verdict, "mismatched");
  assert.match(p.message ?? "", /built for gateway 0\.4\.5/);
  assert.match(p.message ?? "", /talking to 0\.5\.0/);
});

test("a product name alone is not a version", () => {
  assert.equal(gatewayRelease("FireFlo"), null);
  assert.equal(gatewayRelease("FireFlo unknown"), null);
});

test("a database at the expected schema is silent", () => {
  const p = schemaPairing(EXPECTED_SCHEMA_VERSION);
  assert.equal(p.verdict, "matched");
  assert.equal(p.message, null);
  assert.equal(schemaPairing("1.90", "1.90.0").verdict, "matched", "a missing part is zero");
});

test("an older schema says to run the gateway's update first", () => {
  const p = schemaPairing("1.85.0", "1.90.0");
  assert.equal(p.verdict, "older");
  assert.equal(p.message, "Database schema 1.85.0 is older than this panel expects (1.90.0): run the gateway's update first.");
  //numeric, not textual: 1.9.0 is older than 1.90.0 and 1.100.0 is newer
  assert.equal(schemaPairing("1.9.0", "1.90.0").verdict, "older");
  assert.equal(compareSchemaVersions("1.100.0", "1.90.0"), 1);
});

test("a newer schema is a warning that names both numbers, not a block", () => {
  const p = schemaPairing("1.92.0", "1.90.0");
  assert.equal(p.verdict, "newer");
  assert.match(p.message ?? "", /Database schema 1\.92\.0 is newer than this panel expects \(1\.90\.0\)/);
  assert.match(p.message ?? "", /keeps working/);
});

test("no schema, 'none' and 'unknown' are nothing to compare, and say nothing", () => {
  for (const reported of [null, undefined, "", "  ", "none", "unknown", "v1.90.0"]) {
    const p = schemaPairing(reported, "1.90.0");
    assert.equal(p.verdict, "unknown", String(reported));
    assert.equal(p.message, null);
  }
  //but the word is kept, so a screen can still show which the gateway said
  assert.equal(schemaPairing("none", "1.90.0").schema, "none");
  assert.equal(schemaPairing("   ", "1.90.0").schema, null);
});

test("the expected schema is a dotted number the comparison understands", () => {
  assert.equal(compareSchemaVersions(EXPECTED_SCHEMA_VERSION, EXPECTED_SCHEMA_VERSION), 0);
  assert.match(EXPECTED_SCHEMA_VERSION, /^\d+\.\d+\.\d+$/);
});

test("the 0.13 pair: panel 0.13.0.0 against gateway 0.13.0, and the schema it adds", () => {
  //the first release where the panel talks GraphQL; the fourth number is still the panel's own
  assert.equal(versionPairing("0.13.0.0", "FireFlo 0.13.0").verdict, "matched");
  //0.13.1 adds health.currency and nothing to the schema: the panel 0.13.1.0 pairs with it
  assert.equal(versionPairing("0.13.1.0", "FireFlo 0.13.1").verdict, "matched");
  //0.13.2 adds Session.receipts and the session_receipts capability, still no schema change
  assert.equal(versionPairing("0.13.2.0", "FireFlo 0.13.2").verdict, "matched");
  //0.13.3 only fixes the native image's GraphQL bundles; the panel 0.13.3.0 is the same code renumbered
  assert.equal(versionPairing("0.13.3.0", "FireFlo 0.13.3").verdict, "matched");
  //0.13.4 registers the records the operator API returns for native reflection, no schema change
  assert.equal(versionPairing("0.13.4.0", "FireFlo 0.13.4").verdict, "matched");
  assert.equal(versionPairing("0.13.3.3", "FireFlo 0.13.4").verdict, "mismatched");
  //0.13.4.1 is panel-only (filter bar, pins, fonts): still the 0.13.4 gateway's panel
  assert.equal(versionPairing("0.13.4.1", "FireFlo 0.13.4").verdict, "matched");
  //0.13.4.2 is panel-only too (the last hour first, a listener's traffic card)
  assert.equal(versionPairing("0.13.4.2", "FireFlo 0.13.4").verdict, "matched");
  //0.13.4.3 is panel-only (the stats API, loading spinners)
  assert.equal(versionPairing("0.13.4.3", "FireFlo 0.13.4").verdict, "matched");
  //0.13.4.4 is panel-only (loading glow, copy over http, heavy stats kept and charted)
  assert.equal(versionPairing("0.13.4.4", "FireFlo 0.13.4").verdict, "matched");
  assert.equal(versionPairing("0.13.2.0", "FireFlo 0.13.1").verdict, "mismatched",
    "a 0.13.2.0 panel asks for receipts a 0.13.1 gateway does not count");
  assert.equal(versionPairing("0.13.0+0", "0.13.0").verdict, "matched");
  assert.equal(versionPairing("0.12.36.0", "FireFlo 0.13.0").verdict, "mismatched",
    "a 0.12 panel cannot talk to a 0.13 gateway at all, so the pairing must say so");
  //what 0.13 expected: schema 1.102.0, which a 0.12.36 database had not reached
  assert.equal(schemaPairing("1.101.0", "1.102.0").verdict, "older", "a database from 0.12.36 has not run V1.102.0");
  assert.equal(schemaPairing("1.102.0", "1.102.0").verdict, "matched");
});

test("the 0.14 pair: panel 0.14.0.0 against gateway 0.14.0, and schema 1.109.0", () => {
  assert.equal(versionPairing("0.14.0.0", "FireFlo 0.14.0").verdict, "matched");
  assert.equal(versionPairing("0.13.5.0", "FireFlo 0.14.0").verdict, "mismatched",
    "a 0.13 panel knows nothing of balance_hold, the nodes or the Kafka backbone");
  //what 0.14.0 expected: schema 1.109.0
  assert.equal(schemaPairing("1.102.0", "1.109.0").verdict, "older", "a 0.13 database has not run V1.103.0 to V1.109.0");
  assert.equal(schemaPairing("1.108.0", "1.109.0").verdict, "older", "V1.109.0 retires the RabbitMQ keys and allows kafka");
  assert.equal(schemaPairing("1.109.0", "1.109.0").verdict, "matched");
});

test("the 0.14.3 pair: schema 1.110.0, durable REST batches", () => {
  assert.equal(schemaPairing("1.109.0", "1.110.0").verdict, "older", "a 0.14.2 database has not run V1.110.0");
  assert.equal(schemaPairing("1.110.0", "1.110.0").verdict, "matched");
});

test("the 0.14.4 pair: schema 1.111.0, crash reconcile of unsettled spending", () => {
  assert.equal(schemaPairing("1.110.0", "1.111.0").verdict, "older", "a 0.14.3 database has not run V1.111.0");
  assert.equal(schemaPairing("1.111.0", "1.111.0").verdict, "matched");
});

test("the 0.15 pair: schema 1.114.0, hot and archive call records, the hourly login, operator two-factor", () => {
  assert.equal(schemaPairing("1.110.0").verdict, "older", "a 0.14.3 database has not split the call records");
  assert.equal(schemaPairing("1.111.0").verdict, "older", "a 0.14.4 database has not run V1.112.0");
  assert.equal(schemaPairing("1.112.0").verdict, "older", "V1.113.0 adds usage_hourly.system_id");
  assert.equal(schemaPairing("1.113.0", "1.114.0").verdict, "older", "V1.114.0 adds the two-factor columns");
  assert.equal(schemaPairing("1.114.0", "1.114.0").verdict, "matched");
});

test("the 0.15.1 pair: schema 1.122.0, the daily login, vendor backlogs, throttle minutes, the index diet, the throughput keys, the writer cap and the outcome keys", () => {
  assert.equal(schemaPairing("1.114.0").verdict, "older", "a 0.15.0 database has no usage_daily.system_id");
  assert.equal(schemaPairing("1.115.0").verdict, "older", "V1.116.0 adds the vendor backlog limits");
  assert.equal(schemaPairing("1.117.0").verdict, "older", "V1.118.0 adds smpp_throttle_minute");
  assert.equal(schemaPairing("1.118.0").verdict, "older", "V1.119.0 is the receipt index migration");
  assert.equal(schemaPairing("1.119.0").verdict, "older", "V1.120.0 registers the throughput keys");
  assert.equal(schemaPairing("1.120.0").verdict, "older", "V1.121.0 registers smsg.persist.writers.max");
  assert.equal(schemaPairing("1.121.0").verdict, "older", "V1.122.0 adds the unique outcome keys");
  assert.equal(schemaPairing("1.122.0", "1.122.0").verdict, "matched");
});

test("the 0.15.2 pair: schema 1.124.0, the port-share key and the encoding columns", () => {
  assert.equal(schemaPairing("1.122.0").verdict, "older", "V1.123.0 registers smsg.port.share.active.seconds");
  assert.equal(schemaPairing("1.123.0").verdict, "older", "V1.124.0 adds the per-leg encoding columns");
  assert.equal(schemaPairing("1.124.0", "1.124.0").verdict, "matched");
});

test("the restart-components pair: schema 1.125.0, the persist stall key", () => {
  assert.equal(schemaPairing("1.124.0").verdict, "older", "V1.125.0 registers smsg.persist.stall.seconds");
  assert.equal(schemaPairing("1.125.0", "1.125.0").verdict, "matched");
});

test("the 0.15.3 pair: schema 1.127.0, the DEBIT entry type and receipt custody", () => {
  assert.equal(EXPECTED_SCHEMA_VERSION, "1.127.0");
  assert.equal(schemaPairing("1.125.0").verdict, "older", "V1.126.0 admits the DEBIT ledger entry");
  assert.equal(schemaPairing("1.126.0").verdict, "older", "V1.127.0 registers the receipt custody keys");
  assert.equal(schemaPairing("1.127.0").verdict, "matched");
});
