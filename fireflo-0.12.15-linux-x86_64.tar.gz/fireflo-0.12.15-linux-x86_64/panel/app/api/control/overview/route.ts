import { controlRoute } from "@/lib/control-route";
import { failureBreakdown, revenueByAccount, totalsOf, trafficOverTime } from "@/lib/metrics-queries";

/**
 * Headline figures, the traffic series and the failure breakdown in one round trip.
 *
 * <p>The tile is derived from the series and the revenue rows rather than queried again: `totals()`
 * used to call `trafficOverTime` a second time, once a minute per open tab (Audit CP-P1).
 *
 * <p>`failuresSince` is where the breakdown's live read started -- today in the billing zone or the
 * last 24 hours, whichever is longer -- because `usage_daily` has no failure reason and a month of
 * call records is not a 60-second poll. The series and the tile cover the whole range.
 */
export const GET = controlRoute(async (range) => {
  const [traffic, revenue, failures] = await Promise.all([
    trafficOverTime(range),
    revenueByAccount(range),
    failureBreakdown(range),
  ]);
  return {
    totals: totalsOf(traffic, revenue),
    traffic,
    failures: failures.rows,
    failuresSince: failures.since,
  };
});
