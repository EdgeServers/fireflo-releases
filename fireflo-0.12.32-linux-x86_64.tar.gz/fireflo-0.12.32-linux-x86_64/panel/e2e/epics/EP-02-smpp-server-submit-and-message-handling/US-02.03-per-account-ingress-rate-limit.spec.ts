/**
 * EP-02 SMPP Server — Submit & Message Handling
 * US-02.03 Per-account ingress rate limit
 *
 * `conf.maxRate.default` (and `conf.maxRate.<accountId>`) on the listener. Each case runs on an
 * account of its own with a large balance, offers more than the limit for a fixed window and reads
 * the accepted rate; the sheet's tolerance is ±10 %. Volumes scale with E2E_LOAD_SCALE.
 */
import { expect, test } from "../../fixtures";
import { edgeA } from "../../fixtures/edgesmsc";
import { awaitGatewayAdopts } from "../../fixtures/gateway";
import { BASELINE } from "../../fixtures/seed";
import { bindAttempt, connectEsme } from "../../fixtures/smpp";
import type { Esme } from "../../fixtures/smpp";
import { metric } from "../../support/flows/gateway";
import { gatewayLog } from "../../fixtures/trace";
import { balanceOf, setWorkerProperty } from "../../support/flows/submit";
import { tc } from "../../support/tc";
import { LOAD } from "../../support/tags";

const LISTENER = "smpp";
const LIMIT = 50;
const SECONDS = 12;

async function limitedAccount(db: import("../../fixtures").Db, seed: import("../../fixtures").Seed) {
  const account = await seed.account({ label: "QA rate-limited" });
  await seed.balance({ accountId: account, balance: 100_000_000 }); // 10,000.0000
  const login = await seed.credential({ accountId: account, product: BASELINE.product });
  await awaitGatewayAdopts(async () => (await bindAttempt(login)).status === 0);
  return { account, login };
}

/** Offer `tps` for `seconds` across the ESMEs; answer accepted/refused counts and the accepted rate. */
async function offer(esmes: Esme[], tps: number, seconds: number) {
  const perEsme = Math.max(1, Math.round((tps * seconds) / esmes.length));
  const started = Date.now();
  const results = await Promise.all(esmes.map((e) => e.submitMany(perEsme, {}, { tps: tps / esmes.length, window: 100 })));
  const elapsed = (Date.now() - started) / 1000;
  const accepted = results.reduce((n, r) => n + r.accepted, 0);
  const refused = new Map<number, number>();
  for (const r of results) for (const [k, v] of r.refused) refused.set(k, (refused.get(k) ?? 0) + v);
  const ids = results.flatMap((r) => r.ids);
  return { accepted, refused, ids, elapsed, rate: accepted / elapsed };
}

test.describe("SC-02.03.01 Limit is per account across binds", () => {
  test(...tc("TC-02.03.01-P01", "Single bind capped at the limit", { requires: ["gateway", "edgesmsc"], tags: [LOAD] }), async ({ db, seed, tcx }) => {
    test.setTimeout(180_000);
    const { login } = await limitedAccount(db, seed);
    const restore = await setWorkerProperty(db, LISTENER, "conf.maxRate.default", String(LIMIT));
    await edgeA().baseline();
    const esme = await connectEsme(login);
    try {
      const r = await offer([esme], 100, SECONDS);
      const throttled = r.refused.get(0x58) ?? 0;
      tcx.note(`offered 100/s for ${SECONDS}s: accepted ${r.accepted} (${r.rate.toFixed(1)}/s), throttled 0x58 ${throttled}, other refusals ${[...r.refused].filter(([k]) => k !== 0x58).map(([k, v]) => `0x${k.toString(16)}×${v}`).join(",") || "none"}`);
      expect(r.rate).toBeGreaterThan(LIMIT * 0.9);
      expect(r.rate).toBeLessThan(LIMIT * 1.1);
      expect(throttled).toBeGreaterThan(0);
      expect(r.accepted + throttled, "nothing lost: refused is not lost").toBe(Math.round(100 * SECONDS));
    } finally {
      await esme.unbind();
      await restore();
    }
  });

  test(...tc("TC-02.03.01-P02", "Four binds still capped at the limit", { requires: ["gateway", "edgesmsc"], tags: [LOAD] }), async ({ db, seed, tcx }) => {
    test.setTimeout(180_000);
    const { login } = await limitedAccount(db, seed);
    const restore = await setWorkerProperty(db, LISTENER, "conf.maxRate.default", String(LIMIT));
    await edgeA().baseline();
    const esmes: Esme[] = [];
    for (let i = 0; i < 4; i++) esmes.push(await connectEsme(login));
    try {
      const r = await offer(esmes, 200, SECONDS);
      tcx.note(`4 binds offering 200/s: aggregate accepted ${r.rate.toFixed(1)}/s (per-session limiting would read ~200/s)`);
      expect(r.rate, "the pre-0.10 defect: a per-session limiter reads ~200/s").toBeLessThan(LIMIT * 1.1);
      expect(r.rate).toBeGreaterThan(LIMIT * 0.9);
    } finally {
      for (const e of esmes) await e.unbind();
      await restore();
    }
  });

  test(...tc("TC-02.03.01-P03", "Per-account override", { requires: ["gateway", "edgesmsc"], tags: [LOAD] }), async ({ db, seed, tcx }) => {
    test.setTimeout(240_000);
    const fast = await limitedAccount(db, seed);
    const slow = await limitedAccount(db, seed);
    const restoreDefault = await setWorkerProperty(db, LISTENER, "conf.maxRate.default", String(LIMIT));
    const restoreOverride = await setWorkerProperty(db, LISTENER, `conf.maxRate.${fast.account}`, "500");
    await edgeA().baseline();
    const f = await connectEsme(fast.login);
    const s = await connectEsme(slow.login);
    try {
      const [rf, rs] = await Promise.all([offer([f], 300, SECONDS), offer([s], 100, SECONDS)]);
      tcx.note(`override 500 → ${rf.rate.toFixed(1)}/s accepted at 300/s offered; default → ${rs.rate.toFixed(1)}/s`);
      expect(rf.rate).toBeGreaterThan(300 * 0.85);
      expect(rs.rate).toBeLessThan(LIMIT * 1.1);
    } finally {
      await f.unbind(); await s.unbind();
      await restoreOverride(); await restoreDefault();
    }
  });

  test(...tc("TC-02.03.01-N01", "Throttled submits are 0x58 submit_sm_resp, not generic_nack", { requires: ["gateway", "edgesmsc"], tags: [LOAD] }), async ({ db, seed, tcx }) => {
    test.setTimeout(120_000);
    const { login } = await limitedAccount(db, seed);
    const restore = await setWorkerProperty(db, LISTENER, "conf.maxRate.default", String(LIMIT));
    const esme = await connectEsme(login);
    let nacks = 0;
    esme.session.on("generic_nack", () => { nacks++; });
    try {
      const r = await offer([esme], 150, 6);
      const throttled = r.refused.get(0x58) ?? 0;
      expect(throttled).toBeGreaterThan(0);
      expect(nacks, "every refusal is a submit_sm_resp, never a generic_nack").toBe(0);
      tcx.note(`${throttled} × submit_sm_resp 0x58 with the request's sequence; generic_nack ${nacks}`);
    } finally {
      await esme.unbind();
      await restore();
    }
  });

  test(...tc("TC-02.03.01-N02", "Throttled submits are not billed and write no row", { requires: ["gateway", "edgesmsc"], tags: [LOAD] }), async ({ db, seed, tcx }) => {
    test.setTimeout(120_000);
    const { account, login } = await limitedAccount(db, seed);
    const restore = await setWorkerProperty(db, LISTENER, "conf.maxRate.default", String(LIMIT));
    const before = await balanceOf(db, account);
    const esme = await connectEsme(login);
    try {
      const r = await offer([esme], 150, 6);
      await db.waitForCount("cdr_submit", "account_id = $1", [account], r.accepted, { timeoutMs: 30_000 });
      await new Promise((x) => setTimeout(x, 1500));
      const rows = await db.count("cdr_submit", "account_id = $1", [account]);
      const after = await balanceOf(db, account);
      expect(rows).toBe(r.accepted);
      // the price is 0.0100 (100 minor units): every accepted message, nothing more
      expect(before.total - after.total).toBe(r.accepted * BASELINE.price);
      tcx.note(`accepted ${r.accepted}, throttled ${r.refused.get(0x58) ?? 0}; cdr_submit ${rows}; balance −${before.total - after.total} = ${r.accepted}×${BASELINE.price}`);
    } finally {
      await esme.unbind();
      await restore();
    }
  });

  test(...tc("TC-02.03.01-N03", "0 means unlimited", { requires: ["gateway", "edgesmsc"], tags: [LOAD] }), async ({ db, seed, tcx }) => {
    test.setTimeout(120_000);
    const { login } = await limitedAccount(db, seed);
    const restore = await setWorkerProperty(db, LISTENER, "conf.maxRate.default", "0");
    const esme = await connectEsme(login);
    try {
      const r = await offer([esme], 1000, 4);
      expect(r.refused.get(0x58) ?? 0, "no 0x58 at all").toBe(0);
      tcx.note(`offered ~1000/s: accepted ${r.accepted} at ${r.rate.toFixed(0)}/s, throttled 0`);
    } finally {
      await esme.unbind();
      await restore();
    }
  });
});

test.describe("SC-02.03.02 A throttled client is named in the log and counted", () => {
  // ThrottleLog: one line per session at most every 10 s naming account, login, address and limit,
  // in place of a WARN per throttled PDU; and fireflo_smpp_throttled_total{limiter}.
  const ACCOUNT_LIMIT = 5;
  const BURST = 60;

  test(...tc("TC-02.03.02-P01", "One smpp.throttled line per session names the account, login, address and limit", { requires: ["gateway", "edgesmsc", "trace"] }), async ({ db, seed, tcx }) => {
    const { account, login } = await limitedAccount(db, seed);
    const restore = await setWorkerProperty(db, LISTENER, `conf.maxRate.${account}`, String(ACCOUNT_LIMIT));
    await edgeA().baseline();
    const mark = gatewayLog.mark();
    const esme = await connectEsme(login);
    try {
      const r = await esme.submitMany(BURST, {}, { window: 10 });
      const throttled = r.refused.get(0x58) ?? 0;
      expect(throttled, "a burst of 60 at 5/s is throttled").toBeGreaterThan(0);
      const line = (await gatewayLog.waitFor(new RegExp(`smpp\\.throttled account=${account} `), mark)).input;
      expect(line).toContain(`systemId=${login.systemId}`);
      expect(line).toMatch(/ ip=127\.0\.0\.1 /);
      expect(line).toContain(`limiter=account rate=${ACCOUNT_LIMIT}/s`);
      expect(line).toContain("(first of this session)");
      // the whole burst is well inside one window: one line, not one per 0x58
      expect(gatewayLog.count(new RegExp(`smpp\\.throttled account=${account} `), mark), "one line per session per window").toBe(1);
      expect(gatewayLog.count(/PDU throttled/, mark), "no per-PDU WARN").toBe(0);
      tcx.note(`${throttled} × 0x58 → one line: ${line.replace(/^.*smpp\.throttled/, "smpp.throttled")}`);
    } finally {
      await esme.unbind();
      await restore();
    }
  });

  test(...tc("TC-02.03.02-P02", "fireflo_smpp_throttled_total counts every 0x58 by limiter", { requires: ["gateway", "edgesmsc"] }), async ({ db, seed, tcx }) => {
    const { account, login } = await limitedAccount(db, seed);
    const restore = await setWorkerProperty(db, LISTENER, `conf.maxRate.${account}`, String(ACCOUNT_LIMIT));
    await edgeA().baseline();
    const beforeAccount = (await metric("fireflo_smpp_throttled_total", { limiter: "account" })) ?? 0;
    const beforeLogin = (await metric("fireflo_smpp_throttled_total", { limiter: "login" })) ?? 0;
    const esme = await connectEsme(login);
    try {
      const r = await esme.submitMany(BURST, {}, { window: 10 });
      const throttled = r.refused.get(0x58) ?? 0;
      expect(throttled).toBeGreaterThan(0);
      await expect.poll(async () => (await metric("fireflo_smpp_throttled_total", { limiter: "account" })) ?? 0).toBe(beforeAccount + throttled);
      expect((await metric("fireflo_smpp_throttled_total", { limiter: "login" })) ?? 0, "the login ceiling was not the one that tripped").toBe(beforeLogin);
      tcx.note(`${throttled} × 0x58; account counter ${beforeAccount} → ${beforeAccount + throttled}; login unchanged`);
    } finally {
      await esme.unbind();
      await restore();
    }
  });
});
