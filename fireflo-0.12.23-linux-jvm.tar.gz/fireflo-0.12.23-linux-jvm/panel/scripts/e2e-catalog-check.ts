/**
 * The suite cannot drift from the sheet: list every test Playwright knows about and assert that
 * every catalog id is declared exactly once, with the sheet's title, and that nothing is declared
 * the catalog does not know. Prints the per-epic split of auto / todo / manual / fixme so the
 * blocked-by-design count is visible before a run starts.
 *
 * Exit 1 on any drift. `npm run e2e` runs this first.
 */
import { execFileSync } from "node:child_process";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import type { Catalog } from "./e2e-catalog.ts";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(here, "..");
const catalog: Catalog = JSON.parse(readFileSync(path.join(root, "e2e", "support", "tc-catalog.json"), "utf8"));

interface PwSuite { title: string; file?: string; suites?: PwSuite[]; specs?: PwSpec[] }
interface PwSpec { title: string; tags: string[]; file: string; line: number; tests: { projectName: string }[] }

let json: string;
try {
  json = execFileSync(
    "npx",
    ["playwright", "test", "--config", "e2e/playwright.config.ts", "--list", "--reporter=json"],
    { cwd: root, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], env: { ...process.env, E2E_LISTING: "1" }, maxBuffer: 64 * 1024 * 1024 },
  );
} catch (e) {
  const err = e as { stdout?: string; stderr?: string; message: string };
  console.error(err.stderr || err.message);
  console.error("playwright --list failed; a tc() with an unknown or duplicate id throws at declaration — read the error above");
  process.exit(1);
}

const specs: PwSpec[] = [];
function walk(s: PwSuite) {
  for (const sp of s.specs ?? []) specs.push(sp);
  for (const c of s.suites ?? []) walk(c);
}
walk(JSON.parse(json) as PwSuite);

const declared = new Map<string, PwSpec[]>();
const idRe = /^(TC-\d{2}\.\d{2}\.\d{2}-[PN]\d{2}) (.*)$/;
const unknown: string[] = [];
for (const sp of specs) {
  // spec.file is relative to the config's rootDir (e2e/); the selftest project declares TC-00.* fakes
  if (sp.file.startsWith("selftest/") || sp.file.startsWith("selftest\\")) continue;
  const m = idRe.exec(sp.title);
  if (!m) continue;
  const id = m[1];
  if (!catalog.tcs.some((t) => t.id === id)) unknown.push(`${id} (${path.relative(root, sp.file)}:${sp.line})`);
  declared.set(id, [...(declared.get(id) ?? []), sp]);
}

const problems: string[] = [];
const kinds = { auto: 0, todo: 0, manual: 0, fixme: 0 };
const perEpic = new Map<string, typeof kinds>();
for (const tc of catalog.tcs) {
  const sps = declared.get(tc.id) ?? [];
  if (sps.length === 0) { problems.push(`${tc.id}: not declared (${tc.epic} / ${tc.story})`); continue; }
  if (sps.length > 1) problems.push(`${tc.id}: declared ${sps.length} times — ${sps.map((s) => `${path.relative(root, s.file)}:${s.line}`).join(", ")}`);
  const sp = sps[0];
  const title = idRe.exec(sp.title)![2];
  if (path.relative(root, sp.file) === "") { /* unreachable; keeps `path` in use for Windows spelling above */ }
  if (title !== tc.title) problems.push(`${tc.id}: title drift\n    spec:  ${title}\n    sheet: ${tc.title}`);
  // the JSON reporter strips the leading "@" from tags
  const tags = sp.tags.map((t) => t.replace(/^@/, ""));
  const kind: keyof typeof kinds = tags.includes("todo") ? "todo" : tags.includes("manual") ? "manual" : tags.includes("fixme") ? "fixme" : "auto";
  kinds[kind]++;
  const e = perEpic.get(tc.epic) ?? { auto: 0, todo: 0, manual: 0, fixme: 0 };
  e[kind]++;
  perEpic.set(tc.epic, e);
}
for (const u of unknown) problems.push(`${u}: declared but not in the catalog`);

for (const [epic, k] of [...perEpic].sort()) {
  const name = catalog.epics.find((e) => e.id === epic)?.name ?? "";
  console.log(`${epic}  auto ${String(k.auto).padStart(3)}  todo ${String(k.todo).padStart(3)}  manual ${String(k.manual).padStart(3)}  fixme ${String(k.fixme).padStart(2)}   ${name}`);
}
console.log(`total  auto ${kinds.auto}  todo ${kinds.todo}  manual ${kinds.manual}  fixme ${kinds.fixme}  = ${kinds.auto + kinds.todo + kinds.manual + kinds.fixme} of ${catalog.tcs.length}`);

if (problems.length) {
  console.error(`\n${problems.length} problem(s):\n` + problems.map((p) => "  " + p).join("\n"));
  process.exit(1);
}
console.log("catalog check: every sheet id is declared exactly once with its title");
