/**
 * Write a run's results into a dated COPY of the QA workbook — never into the committed one.
 *
 *   npm run e2e:writeback                       # e2e/.run/results.json → e2e/report/FireFlo-0.12-QA-Test-Plan-<yyyymmdd>.xlsx
 *   npm run e2e:writeback -- --results a.json --out path.xlsx
 *
 * Matching is by column A (TC ID) on the TestCases sheet; the five columns it fills are the ones the
 * sheet leaves for a tester — Status, Actual result, Tester, Date, Notes — found by header name so a
 * column inserted before them does not shift the write. Every other cell, formula and sheet is left
 * as it is; Excel recalculates the Traceability sheet on open.
 *
 * The round trip is checked before exit: the copy is re-read and its status counts must equal the
 * reporter's. A silent partial write would otherwise look like a clean run.
 */
import { existsSync, mkdirSync, readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import ExcelJS from "exceljs";
import type { ResultsFile, SheetStatus } from "../e2e/reporters/tc-results.ts";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(here, "..");

function arg(name: string): string | undefined {
  const i = process.argv.indexOf(name);
  return i >= 0 ? process.argv[i + 1] : undefined;
}

const workbookPath = path.resolve(
  process.env.E2E_QA_WORKBOOK ?? path.join(root, "..", "fireflo-sms-gateway", "docs", "26-qa-test-plan-0.12.xlsx"),
);
const resultsPath = path.resolve(arg("--results") ?? path.join(root, "e2e", ".run", "results.json"));
const stamp = new Date().toISOString().slice(0, 10).replace(/-/g, "");
const outPath = path.resolve(arg("--out") ?? path.join(root, "e2e", "report", `FireFlo-0.12-QA-Test-Plan-${stamp}.xlsx`));

if (path.resolve(outPath) === path.resolve(workbookPath)) {
  throw new Error("refusing to write over the committed workbook; pass --out somewhere else");
}
if (!existsSync(resultsPath)) throw new Error(`no results at ${resultsPath} — run the suite first`);

const results: ResultsFile = JSON.parse(readFileSync(resultsPath, "utf8"));
const byId = new Map(results.results.map((r) => [r.id, r]));
const runDate = results.finishedAt.slice(0, 10);

const wb = new ExcelJS.Workbook();
await wb.xlsx.readFile(workbookPath);
const ws = wb.getWorksheet("TestCases");
if (!ws) throw new Error("workbook has no TestCases sheet");

const header = ws.getRow(1);
const col = (name: string): number => {
  let found = 0;
  header.eachCell((c, n) => { if (String(c.value).trim() === name) found = n; });
  if (!found) throw new Error(`TestCases has no '${name}' column`);
  return found;
};
const C = { id: col("TC ID"), status: col("Status"), actual: col("Actual result"), tester: col("Tester"), date: col("Date"), notes: col("Notes") };

let written = 0;
const unknown: string[] = [];
const seen = new Set<string>();
ws.eachRow((row, n) => {
  if (n === 1) return;
  const id = String(row.getCell(C.id).value ?? "").trim();
  if (!id) return;
  seen.add(id);
  const r = byId.get(id);
  if (!r) return; // not in this run: leave the row exactly as it was
  row.getCell(C.status).value = r.status;
  // a leading "=" would be stored as a formula; the reporter's text can start with one ("expect(…)")
  row.getCell(C.actual).value = r.actual ? (r.actual.startsWith("=") ? " " + r.actual : r.actual) : null;
  row.getCell(C.tester).value = results.tester;
  row.getCell(C.date).value = runDate;
  const notes = [r.notes, r.retries ? `retries ${r.retries}` : "", `${r.project} · ${Math.round(r.durationMs)}ms`].filter(Boolean).join(" · ");
  row.getCell(C.notes).value = notes.startsWith("=") ? " " + notes : notes;
  written++;
});
for (const id of byId.keys()) if (!seen.has(id) && !id.startsWith("TC-00.")) unknown.push(id);

mkdirSync(path.dirname(outPath), { recursive: true });
await wb.xlsx.writeFile(outPath);

// round trip: re-read the copy and count statuses
const check = new ExcelJS.Workbook();
await check.xlsx.readFile(outPath);
const counts: Record<SheetStatus, number> = { Pass: 0, Fail: 0, Blocked: 0, "Not run": 0 };
check.getWorksheet("TestCases")!.eachRow((row, n) => {
  if (n === 1) return;
  const id = String(row.getCell(C.id).value ?? "").trim();
  if (!byId.has(id)) return;
  const s = String(row.getCell(C.status).value ?? "") as SheetStatus;
  if (s in counts) counts[s]++;
});
const want = results.counts;
const selftest = results.results.filter((r) => r.id.startsWith("TC-00.")).length;
const mismatch = (Object.keys(counts) as SheetStatus[]).filter((k) => counts[k] !== want[k] - results.results.filter((r) => r.id.startsWith("TC-00.") && r.status === k).length);
console.log(`wrote ${written} row(s) → ${path.relative(root, outPath)}`);
console.log(`round trip: Pass ${counts.Pass} · Fail ${counts.Fail} · Blocked ${counts.Blocked} · Not run ${counts["Not run"]}` + (selftest ? ` (${selftest} selftest record(s) ignored)` : ""));
if (unknown.length) console.warn(`${unknown.length} result id(s) not in the sheet: ${unknown.slice(0, 10).join(", ")}${unknown.length > 10 ? "…" : ""}`);
if (mismatch.length) {
  console.error(`round trip MISMATCH on ${mismatch.join(", ")} — the copy does not carry what the reporter counted`);
  process.exit(1);
}
