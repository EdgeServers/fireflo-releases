/**
 * Proves the reporting path carries a failure. Runs the `selftest` project — which contains a test
 * that MUST fail — with no rig, then reads e2e/.run/results.json and asserts each of the four
 * outcomes landed with the status the reporter is supposed to give it. A reporter that dropped
 * failures, or a write-back reading a stale file, would be caught here and nowhere else.
 */
import { spawnSync } from "node:child_process";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import type { ResultsFile } from "../e2e/reporters/tc-results.ts";

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const run = spawnSync(
  "npx",
  ["playwright", "test", "--config", "e2e/playwright.config.ts", "--project", "selftest"],
  { cwd: root, stdio: "inherit", env: { ...process.env, E2E_NO_RIG: "1" } },
);
// one test is meant to fail, so Playwright exits 1 — a 0 here means the failing test passed
if (run.status === 0) {
  console.error("selftest: playwright exited 0 but the inverted assertion was supposed to fail");
  process.exit(1);
}

const results: ResultsFile = JSON.parse(readFileSync(path.join(root, "e2e", ".run", "results.json"), "utf8"));
const byId = new Map(results.results.map((r) => [r.id, r]));
const expected: Record<string, { status: string; actualIncludes?: string; notesIncludes?: string }> = {
  "TC-00.00.00-N01": { status: "Fail", actualIncludes: "selftest: this assertion is meant to fail" },
  "TC-00.00.00-P01": { status: "Pass", actualIncludes: "observed 2" },
  "TC-00.00.00-P02": { status: "Not run", notesIncludes: "manual: selftest manual reason" },
  "TC-00.00.00-P03": { status: "Blocked", notesIncludes: "needs nothing (selftest)" },
};
const problems: string[] = [];
for (const [id, want] of Object.entries(expected)) {
  const got = byId.get(id);
  if (!got) { problems.push(`${id}: missing from results.json`); continue; }
  if (got.status !== want.status) problems.push(`${id}: status ${got.status}, wanted ${want.status}`);
  if (want.actualIncludes && !got.actual.includes(want.actualIncludes)) problems.push(`${id}: actual '${got.actual}' lacks '${want.actualIncludes}'`);
  if (want.notesIncludes && !got.notes.includes(want.notesIncludes)) problems.push(`${id}: notes '${got.notes}' lacks '${want.notesIncludes}'`);
}
if (problems.length) {
  console.error("selftest FAILED:\n  " + problems.join("\n  "));
  process.exit(1);
}
console.log(`selftest: results.json carries Fail, Pass, Not run and Blocked as expected (${results.results.length} records)`);
