/**
 * The change list that carries the 0.11 QA workbook to 0.12 — see scripts/qa-plan-0.12/README.md.
 *
 * Only erasable TypeScript syntax: this runs under `node --experimental-strip-types`.
 */

export type Changed = "New" | "Updated";

export interface StoryRow {
  id: string;
  epic: string;
  story: string;
  asA: string;
  iWant: string;
  soThat: string;
  acceptance: string;
  configKeys: string;
  observable: string;
  /** The JUnit / node:test class that covers the rule today, or "—". */
  automated: string;
  changed: Changed;
}

export interface ScenarioRow {
  id: string;
  story: string;
  epic: string;
  scenario: string;
  gwt: string;
  preconditions: string;
  rig: string;
  related: string;
  dependsOn: string;
  changed: Changed;
}

export type Surface = "SMPP" | "HTTP" | "Ops" | "CLI" | "Panel" | "Portal" | "API" | "Host";

export interface CaseRow {
  id: string;
  scenario: string;
  story: string;
  epic: string;
  type: "Positive" | "Negative";
  title: string;
  steps: string;
  testData: string;
  expected: string;
  oracle: string;
  antiVacuity: string;
  priority: "P0" | "P1" | "P2";
  component: "Gateway" | "Control Panel" | "Cross-component";
  automated: string;
  related: string;
  surface: Surface;
  changed: Changed;
  /** The release and the sentence of the release note the case comes from, e.g. "0.12.14: …". */
  changeNote: string;
}

/** Any field of a 0.11 row by its key; `id` says which row. */
export interface Update {
  id: string;
  changed: "Updated";
  changeNote: string;
  set: Partial<Omit<CaseRow, "id" | "changed" | "changeNote">> &
    Partial<Omit<ScenarioRow, "id" | "changed">> &
    Partial<Omit<StoryRow, "id" | "changed">>;
}

export interface Retire {
  id: string;
  reason: string;
}

export interface FocusRow {
  /** The release, e.g. "0.12.11". */
  item: string;
  change: string;
  scenarios: string;
  risk: string;
}

export interface Change {
  epic: string;
  epicDescription?: string;
  stories?: StoryRow[];
  scenarios?: ScenarioRow[];
  cases?: CaseRow[];
  updates?: Update[];
  retire?: Retire[];
  focus?: FocusRow[];
}
