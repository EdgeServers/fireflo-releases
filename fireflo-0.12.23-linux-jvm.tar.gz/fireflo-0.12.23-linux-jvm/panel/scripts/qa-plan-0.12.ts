/**
 * Builds docs/26-qa-test-plan-0.12.xlsx from the 0.11 workbook plus the change files in
 * scripts/qa-plan-0.12/changes/, and fills the automation columns from the e2e suite.
 *
 * Usage: node --experimental-strip-types scripts/qa-plan-0.12.ts [--out path]
 *
 * The 0.11 workbook is read, never written. Every 0.11 id survives with its row; new rows are
 * inserted under their parent so the sheets stay in id order; retired rows are kept and marked.
 * See scripts/qa-plan-0.12/README.md for the change-file format and the writing rules.
 */
import { createHash } from "node:crypto";
import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import ExcelJS from "exceljs";
import type { Cell, Row, Worksheet } from "exceljs";
import type { CaseRow, Change, ScenarioRow, StoryRow } from "./qa-plan-types.ts";

const here = path.dirname(fileURLToPath(import.meta.url));
const panelRoot = path.join(here, "..");
const gatewayDocs = path.join(panelRoot, "..", "fireflo-sms-gateway", "docs");
const SRC = process.env.QA_PLAN_SRC ?? path.join(gatewayDocs, "26-qa-test-plan-0.11.xlsx");
const argOut = process.argv.indexOf("--out");
const OUT = argOut > 0 ? path.resolve(process.argv[argOut + 1]) : path.join(gatewayDocs, "26-qa-test-plan-0.12.xlsx");
const CHANGES_DIR = path.join(here, "qa-plan-0.12", "changes");
const E2E_EPICS = path.join(panelRoot, "e2e", "epics");
const E2E_RESULTS = path.join(panelRoot, "e2e", ".run", "results.json");

const GATEWAY_VERSION = "0.12.14";
const PANEL_VERSION = "0.12.14.0";

// ---------------------------------------------------------------------------------------------
// columns (1-based) — the 0.11 layout, which the e2e catalog reads positionally and must not move
const STORY = { id: 1, epic: 2, story: 3, asA: 4, iWant: 5, soThat: 6, acceptance: 7, configKeys: 8, observable: 9, newIn011: 10, automated: 11, nScenarios: 12, nTcs: 13, changed: 14 } as const;
const SCEN = { id: 1, story: 2, epic: 3, scenario: 4, gwt: 5, preconditions: 6, rig: 7, related: 8, dependsOn: 9, newIn011: 10, nTcs: 11, nPos: 12, nNeg: 13, changed: 14 } as const;
const TC = { id: 1, scenario: 2, story: 3, epic: 4, type: 5, title: 6, steps: 7, testData: 8, expected: 9, oracle: 10, antiVacuity: 11, priority: 12, component: 13, newIn011: 14, automated: 15, related: 16, status: 17, actual: 18, tester: 19, date: 20, notes: 21, surface: 22, changed: 23, changeNote: 24, automation: 25, lastRun: 26, lastRunNote: 27 } as const;
const EPIC = { id: 1, epic: 2, component: 3, description: 4, nStories: 5, nScenarios: 6, nTcs: 7, nPos: 8, nNeg: 9, nP0: 10, nNew011: 11, nChanged: 12, nAuto: 13, nTodo: 14, nManual: 15 } as const;

const col = (n: number) => {
  let s = "";
  for (let x = n; x > 0; x = Math.floor((x - 1) / 26)) s = String.fromCharCode(65 + ((x - 1) % 26)) + s;
  return s;
};

// ---------------------------------------------------------------------------------------------
function text(cell: Cell | undefined): string {
  const v = cell?.value as unknown;
  if (v == null) return "";
  if (typeof v === "string") return v;
  if (typeof v === "object") {
    const o = v as { richText?: { text: string }[]; result?: unknown; text?: string; formula?: string };
    if (Array.isArray(o.richText)) return o.richText.map((r) => r.text).join("");
    if (o.formula) return "";
    if (typeof o.text === "string") return o.text;
    if ("result" in o) return o.result == null ? "" : String(o.result);
  }
  return String(v);
}

function fail(msg: string): never {
  throw new Error(msg);
}

// ---------------------------------------------------------------------------------------------
// automation status from the suite
type Kind = "Automated" | "Manual" | "Todo" | "Fixme";
function automationFromSuite(): Map<string, { kind: Kind; spec: string }> {
  const out = new Map<string, { kind: Kind; spec: string }>();
  const walk = (dir: string) => {
    for (const name of readdirSync(dir)) {
      const p = path.join(dir, name);
      if (statSync(p).isDirectory()) walk(p);
      else if (name.endsWith(".spec.ts")) {
        const src = readFileSync(p, "utf8");
        const spec = path.relative(E2E_EPICS, p);
        for (const m of src.matchAll(/tc(?:\.(manual|todo|fixme))?\(\s*"(TC-[0-9.]+-[PN]\d+)"/g)) {
          const kind: Kind = m[1] === "manual" ? "Manual" : m[1] === "todo" ? "Todo" : m[1] === "fixme" ? "Fixme" : "Automated";
          out.set(m[2], { kind, spec });
        }
      }
    }
  };
  if (existsSync(E2E_EPICS)) walk(E2E_EPICS);
  return out;
}

function lastRun(): { at: string; results: Map<string, { status: string; note: string }> } {
  const results = new Map<string, { status: string; note: string }>();
  if (!existsSync(E2E_RESULTS)) return { at: "", results };
  const j = JSON.parse(readFileSync(E2E_RESULTS, "utf8")) as { finishedAt?: string; results?: { id: string; status: string; actual?: string; error?: string }[] };
  for (const r of j.results ?? []) results.set(r.id, { status: r.status, note: r.actual ?? r.error ?? "" });
  return { at: j.finishedAt ?? "", results };
}

// ---------------------------------------------------------------------------------------------
async function loadChanges(): Promise<Change[]> {
  if (!existsSync(CHANGES_DIR)) return [];
  //QA_PLAN_ONLY=EP-09,EP-10 validates a subset while other change files are still being written
  const only = (process.env.QA_PLAN_ONLY ?? "").split(",").map((s) => s.trim()).filter(Boolean);
  const files = readdirSync(CHANGES_DIR)
    .filter((f) => /^EP-\d\d\.ts$/.test(f))
    .filter((f) => !only.length || only.includes(f.replace(/\.ts$/, "")))
    .sort();
  const out: Change[] = [];
  for (const f of files) {
    const mod = (await import(pathToFileURL(path.join(CHANGES_DIR, f)).href)) as { default: Change };
    if (!mod.default?.epic) fail(`${f}: no default export with an epic`);
    if (`${mod.default.epic}.ts` !== f) fail(`${f}: declares epic ${mod.default.epic}`);
    out.push(mod.default);
  }
  return out;
}

// ---------------------------------------------------------------------------------------------
interface Index {
  epics: Map<string, number>;
  stories: Map<string, number>;
  scenarios: Map<string, number>;
  cases: Map<string, number>;
}

function index(ws: Worksheet): Map<string, number> {
  const m = new Map<string, number>();
  ws.eachRow((row, n) => {
    if (n > 1) {
      const id = text(row.getCell(1)).trim();
      if (id) m.set(id, n);
    }
  });
  return m;
}

/** The row number after the last row whose column `c` equals `value`, or null. */
function afterLast(ws: Worksheet, c: number, value: string): number | null {
  let last: number | null = null;
  ws.eachRow((row, n) => {
    if (n > 1 && text(row.getCell(c)).trim() === value) last = n;
  });
  return last == null ? null : last + 1;
}

function insertRow(ws: Worksheet, at: number, values: (string | number | null | { formula: string })[]): Row {
  const row = ws.insertRow(at, [], "i");
  values.forEach((v, i) => {
    if (v != null && v !== "") row.getCell(i + 1).value = v as ExcelJS.CellValue;
  });
  row.height = undefined as unknown as number;
  return row;
}

const idParts = (id: string) => {
  const m = /^(TC|SC|US)-(\d\d)(?:\.(\d\d))?(?:\.(\d\d))?(?:-([PN])(\d\d))?$/.exec(id);
  return m;
};

function validate(changes: Change[], ix: Index): void {
  const newStories = new Set<string>();
  const newScen = new Set<string>();
  const newCases = new Map<string, CaseRow>();
  const all = (id: string) => ix.epics.has(id) || ix.stories.has(id) || ix.scenarios.has(id) || ix.cases.has(id) || newStories.has(id) || newScen.has(id) || newCases.has(id);
  const problems: string[] = [];
  for (const ch of changes) {
    for (const s of ch.stories ?? []) {
      if (!/^US-\d\d\.\d\d$/.test(s.id) || s.epic !== `EP-${s.id.slice(3, 5)}` || s.epic !== ch.epic) problems.push(`${s.id}: bad id or epic`);
      if (ix.stories.has(s.id) || newStories.has(s.id)) problems.push(`${s.id}: already exists`);
      if (!s.story || !s.acceptance) problems.push(`${s.id}: story and acceptance are required`);
      newStories.add(s.id);
    }
    for (const s of ch.scenarios ?? []) {
      if (!/^SC-\d\d\.\d\d\.\d\d$/.test(s.id) || s.story !== `US-${s.id.slice(3, 8)}` || s.epic !== ch.epic) problems.push(`${s.id}: bad id, story or epic`);
      if (!ix.stories.has(s.story) && !newStories.has(s.story)) problems.push(`${s.id}: story ${s.story} does not exist`);
      if (ix.scenarios.has(s.id) || newScen.has(s.id)) problems.push(`${s.id}: already exists`);
      if (!/Given[\s\S]*When[\s\S]*Then/.test(s.gwt)) problems.push(`${s.id}: needs Given / When / Then`);
      newScen.add(s.id);
    }
    for (const c of ch.cases ?? []) {
      if (!/^TC-\d\d\.\d\d\.\d\d-[PN]\d\d$/.test(c.id) || c.scenario !== `SC-${c.id.slice(3, 11)}` || c.story !== `US-${c.id.slice(3, 8)}` || c.epic !== ch.epic) problems.push(`${c.id}: bad id or parents`);
      if (!ix.scenarios.has(c.scenario) && !newScen.has(c.scenario)) problems.push(`${c.id}: scenario ${c.scenario} does not exist`);
      if (ix.cases.has(c.id) || newCases.has(c.id)) problems.push(`${c.id}: already exists`);
      if ((c.type === "Positive") !== c.id.includes("-P")) problems.push(`${c.id}: type does not match the id`);
      if (!c.steps || !c.expected || !c.oracle) problems.push(`${c.id}: steps, expected and oracle are required`);
      if (c.priority === "P0" && !c.antiVacuity) problems.push(`${c.id}: a P0 needs an anti-vacuity check`);
      newCases.set(c.id, c);
    }
  }
  //numbering: contiguous per scenario and letter, counting the 0.11 rows
  const seq = new Map<string, number[]>();
  for (const id of [...ix.cases.keys(), ...newCases.keys()]) {
    const key = id.slice(0, 11) + id.slice(11, 13);
    (seq.get(key) ?? seq.set(key, []).get(key)!).push(Number(id.slice(13)));
  }
  for (const [key, nums] of seq) {
    nums.sort((a, b) => a - b);
    nums.forEach((n, i) => {
      if (n !== i + 1) problems.push(`${key}: numbering is not contiguous (${nums.join(",")})`);
    });
  }
  for (const ch of changes) {
    for (const u of ch.updates ?? []) if (!all(u.id) || newCases.has(u.id)) problems.push(`update ${u.id}: not a 0.11 row`);
    for (const r of ch.retire ?? []) if (!ix.cases.has(r.id)) problems.push(`retire ${r.id}: not a 0.11 test case`);
    for (const s of ch.scenarios ?? []) for (const ref of [s.related, s.dependsOn]) for (const id of ref.split(/[,;]\s*/).map((x) => x.trim()).filter(Boolean)) if (!all(id)) problems.push(`${s.id}: reference ${id} does not exist`);
    for (const c of ch.cases ?? []) for (const id of c.related.split(/[,;]\s*/).map((x) => x.trim()).filter(Boolean)) if (!all(id) && !/^I\d$/.test(id)) problems.push(`${c.id}: reference ${id} does not exist`);
  }
  if (problems.length) fail(`change list has ${problems.length} problem(s):\n  ${[...new Set(problems)].join("\n  ")}`);
}

// ---------------------------------------------------------------------------------------------
function header(ws: Worksheet, c: number, title: string, width: number) {
  const h = ws.getRow(1).getCell(c);
  h.value = title;
  const ref = ws.getRow(1).getCell(1);
  h.style = { ...ref.style };
  ws.getColumn(c).width = width;
}

function rewriteCountFormulas(wb: ExcelJS.Workbook) {
  const epics = wb.getWorksheet("Epics")!;
  epics.eachRow((row, n) => {
    if (n === 1) return;
    const a = `A${n}`;
    row.getCell(EPIC.nStories).value = { formula: `COUNTIF(Stories!$B:$B,${a})` } as ExcelJS.CellValue;
    row.getCell(EPIC.nScenarios).value = { formula: `COUNTIF(Scenarios!$C:$C,${a})` } as ExcelJS.CellValue;
    row.getCell(EPIC.nTcs).value = { formula: `COUNTIF(TestCases!$D:$D,${a})` } as ExcelJS.CellValue;
    row.getCell(EPIC.nPos).value = { formula: `COUNTIFS(TestCases!$D:$D,${a},TestCases!$E:$E,"Positive")` } as ExcelJS.CellValue;
    row.getCell(EPIC.nNeg).value = { formula: `COUNTIFS(TestCases!$D:$D,${a},TestCases!$E:$E,"Negative")` } as ExcelJS.CellValue;
    row.getCell(EPIC.nP0).value = { formula: `COUNTIFS(TestCases!$D:$D,${a},TestCases!$L:$L,"P0")` } as ExcelJS.CellValue;
    row.getCell(EPIC.nNew011).value = { formula: `COUNTIFS(TestCases!$D:$D,${a},TestCases!$N:$N,"Y")` } as ExcelJS.CellValue;
    row.getCell(EPIC.nChanged).value = { formula: `COUNTIFS(TestCases!$D:$D,${a},TestCases!$${col(TC.changed)}:$${col(TC.changed)},"<>")` } as ExcelJS.CellValue;
    row.getCell(EPIC.nAuto).value = { formula: `COUNTIFS(TestCases!$D:$D,${a},TestCases!$${col(TC.automation)}:$${col(TC.automation)},"Automated")` } as ExcelJS.CellValue;
    row.getCell(EPIC.nTodo).value = { formula: `COUNTIFS(TestCases!$D:$D,${a},TestCases!$${col(TC.automation)}:$${col(TC.automation)},"Todo")` } as ExcelJS.CellValue;
    row.getCell(EPIC.nManual).value = { formula: `COUNTIFS(TestCases!$D:$D,${a},TestCases!$${col(TC.automation)}:$${col(TC.automation)},"Manual")` } as ExcelJS.CellValue;
  });
  const stories = wb.getWorksheet("Stories")!;
  stories.eachRow((row, n) => {
    if (n === 1) return;
    row.getCell(STORY.nScenarios).value = { formula: `COUNTIF(Scenarios!$B:$B,A${n})` } as ExcelJS.CellValue;
    row.getCell(STORY.nTcs).value = { formula: `COUNTIF(TestCases!$C:$C,A${n})` } as ExcelJS.CellValue;
  });
  const scen = wb.getWorksheet("Scenarios")!;
  scen.eachRow((row, n) => {
    if (n === 1) return;
    row.getCell(SCEN.nTcs).value = { formula: `COUNTIF(TestCases!$B:$B,A${n})` } as ExcelJS.CellValue;
    row.getCell(SCEN.nPos).value = { formula: `COUNTIFS(TestCases!$B:$B,A${n},TestCases!$E:$E,"Positive")` } as ExcelJS.CellValue;
    row.getCell(SCEN.nNeg).value = { formula: `COUNTIFS(TestCases!$B:$B,A${n},TestCases!$E:$E,"Negative")` } as ExcelJS.CellValue;
  });
}

function fillSheet(ws: Worksheet, rows: (string | number | { formula: string })[][], startRow = 2) {
  //clear everything below the header, then write
  const last = ws.rowCount;
  if (last >= startRow) ws.spliceRows(startRow, last - startRow + 1);
  rows.forEach((r, i) => {
    const row = ws.getRow(startRow + i);
    r.forEach((v, c) => {
      row.getCell(c + 1).value = v as ExcelJS.CellValue;
      row.getCell(c + 1).font = { name: "Arial", size: 9 };
      row.getCell(c + 1).alignment = { vertical: "top", wrapText: true };
    });
    row.commit();
  });
}

// ---------------------------------------------------------------------------------------------
async function main() {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.readFile(SRC);
  const srcSha = createHash("sha256").update(readFileSync(SRC)).digest("hex");
  const sheets = {
    epics: wb.getWorksheet("Epics") ?? fail("no Epics"),
    stories: wb.getWorksheet("Stories") ?? fail("no Stories"),
    scenarios: wb.getWorksheet("Scenarios") ?? fail("no Scenarios"),
    cases: wb.getWorksheet("TestCases") ?? fail("no TestCases"),
  };
  const ix: Index = { epics: index(sheets.epics), stories: index(sheets.stories), scenarios: index(sheets.scenarios), cases: index(sheets.cases) };
  const changes = await loadChanges();
  validate(changes, ix);

  // new columns
  header(sheets.stories, STORY.changed, "Changed in 0.12", 10);
  header(sheets.scenarios, SCEN.changed, "Changed in 0.12", 10);
  header(sheets.cases, TC.surface, "Surface", 8);
  header(sheets.cases, TC.changed, "Changed in 0.12", 10);
  header(sheets.cases, TC.changeNote, "Change note (release: why)", 40);
  header(sheets.cases, TC.automation, "Automation", 11);
  header(sheets.cases, TC.lastRun, "Last e2e run", 10);
  header(sheets.cases, TC.lastRunNote, "Last run note", 30);
  header(sheets.epics, EPIC.nChanged, "# Changed in 0.12", 9);
  header(sheets.epics, EPIC.nAuto, "# Automated", 9);
  header(sheets.epics, EPIC.nTodo, "# Todo", 7);
  header(sheets.epics, EPIC.nManual, "# Manual", 7);

  const statusValidation = sheets.cases.getRow(2).getCell(TC.status).dataValidation;

  // apply, epic by epic: stories, then scenarios, then cases; each inserted under its parent
  let added = { stories: 0, scenarios: 0, cases: 0, updates: 0, retired: 0 };
  const focus: { item: string; change: string; scenarios: string; risk: string }[] = [];
  for (const ch of changes) {
    const epicRow = ix.epics.get(ch.epic) ?? fail(`${ch.epic}: unknown epic`);
    if (ch.epicDescription) sheets.epics.getRow(epicRow).getCell(EPIC.description).value = ch.epicDescription;
    for (const s of ch.stories ?? []) {
      const at = afterLast(sheets.stories, STORY.epic, s.epic) ?? sheets.stories.rowCount + 1;
      insertRow(sheets.stories, at, [s.id, s.epic, s.story, s.asA, s.iWant, s.soThat, s.acceptance, s.configKeys, s.observable, "N", s.automated || "—", null, null, s.changed]);
      added.stories++;
    }
    for (const s of ch.scenarios ?? []) {
      const at = afterLast(sheets.scenarios, SCEN.story, s.story) ?? afterLast(sheets.scenarios, SCEN.epic, s.epic) ?? sheets.scenarios.rowCount + 1;
      insertRow(sheets.scenarios, at, [s.id, s.story, s.epic, s.scenario, s.gwt, s.preconditions, s.rig, s.related, s.dependsOn, "N", null, null, null, s.changed]);
      added.scenarios++;
    }
    for (const c of ch.cases ?? []) {
      const at = afterLast(sheets.cases, TC.scenario, c.scenario) ?? afterLast(sheets.cases, TC.story, c.story) ?? afterLast(sheets.cases, TC.epic, c.epic) ?? sheets.cases.rowCount + 1;
      const row = insertRow(sheets.cases, at, [c.id, c.scenario, c.story, c.epic, c.type, c.title, c.steps, c.testData, c.expected, c.oracle, c.antiVacuity, c.priority, c.component, "N", c.automated, c.related, "Not run", null, null, null, null, c.surface, c.changed, c.changeNote]);
      if (statusValidation) row.getCell(TC.status).dataValidation = statusValidation;
      added.cases++;
    }
    focus.push(...(ch.focus ?? []));
  }
  // re-index after inserts, then updates and retirements
  ix.stories = index(sheets.stories);
  ix.scenarios = index(sheets.scenarios);
  ix.cases = index(sheets.cases);
  const fieldCol = (id: string, key: string): [Worksheet, number] | null => {
    if (id.startsWith("TC-")) return key in TC ? [sheets.cases, TC[key as keyof typeof TC]] : null;
    if (id.startsWith("SC-")) return key in SCEN ? [sheets.scenarios, SCEN[key as keyof typeof SCEN]] : null;
    if (id.startsWith("US-")) return key in STORY ? [sheets.stories, STORY[key as keyof typeof STORY]] : null;
    return null;
  };
  for (const ch of changes) {
    for (const u of ch.updates ?? []) {
      const rowNo = ix.cases.get(u.id) ?? ix.scenarios.get(u.id) ?? ix.stories.get(u.id) ?? fail(`update ${u.id}: not found`);
      for (const [key, value] of Object.entries(u.set)) {
        const target = fieldCol(u.id, key) ?? fail(`update ${u.id}: '${key}' is not a column of that sheet`);
        target[0].getRow(rowNo).getCell(target[1]).value = value as ExcelJS.CellValue;
      }
      const target = fieldCol(u.id, "changed")!;
      target[0].getRow(rowNo).getCell(target[1]).value = "Updated";
      if (u.id.startsWith("TC-")) sheets.cases.getRow(rowNo).getCell(TC.changeNote).value = u.changeNote;
      added.updates++;
    }
    for (const r of ch.retire ?? []) {
      const rowNo = ix.cases.get(r.id)!;
      const row = sheets.cases.getRow(rowNo);
      row.getCell(TC.changed).value = "Retired";
      row.getCell(TC.changeNote).value = r.reason;
      row.getCell(TC.status).value = "N/A";
      row.eachCell({ includeEmpty: true }, (cell) => {
        cell.font = { ...(cell.font ?? {}), color: { argb: "FF888888" }, strike: false };
      });
      added.retired++;
    }
  }

  // automation and last run, every TC
  const auto = automationFromSuite();
  const run = lastRun();
  const counts = { Automated: 0, Todo: 0, Manual: 0, Fixme: 0, none: 0 };
  sheets.cases.eachRow((row, n) => {
    if (n === 1) return;
    const id = text(row.getCell(TC.id)).trim();
    const a = auto.get(id);
    row.getCell(TC.automation).value = a ? a.kind : "";
    if (a) counts[a.kind]++;
    else counts.none++;
    const r = run.results.get(id);
    if (r) {
      row.getCell(TC.lastRun).value = r.status;
      row.getCell(TC.lastRunNote).value = r.note.slice(0, 500);
    }
    for (const c of [TC.surface, TC.changed, TC.changeNote, TC.automation, TC.lastRun, TC.lastRunNote]) {
      row.getCell(c).font = { name: "Arial", size: 9 };
      row.getCell(c).alignment = { vertical: "top", wrapText: true };
    }
  });

  rewriteCountFormulas(wb);
  for (const [ws, width] of [[sheets.epics, EPIC.nManual], [sheets.stories, STORY.changed], [sheets.scenarios, SCEN.changed], [sheets.cases, TC.lastRunNote]] as [Worksheet, number][]) {
    ws.autoFilter = { from: "A1", to: `${col(width)}${ws.rowCount}` };
  }

  // README
  const readme = wb.getWorksheet("README") ?? fail("no README");
  readme.getRow(1).getCell(1).value = `FireFlo ${GATEWAY_VERSION} — QA Test Plan`;
  const setReadme = (label: string, value: string) => {
    let found = false;
    readme.eachRow((row) => {
      if (text(row.getCell(1)) === label) {
        row.getCell(2).value = value;
        found = true;
      }
    });
    if (!found) {
      const row = readme.addRow([label, value]);
      row.getCell(1).font = { name: "Arial", size: 9, bold: true };
      row.getCell(2).font = { name: "Arial", size: 9 };
      row.getCell(2).alignment = { vertical: "top", wrapText: true };
    }
  };
  setReadme("Scope", `FireFlo SMS Gateway ${GATEWAY_VERSION} (fireflo-sms-gateway) and FireFlo Control Panel ${PANEL_VERSION} (operator panel /cp and customer portal). Carried forward from the 0.11.0 plan: every 0.11 id is kept with its row; what 0.12 changed is marked, never renumbered.`);
  setReadme("New in 0.11", "History. Y marks behaviour that changed in 0.11.0; the '0.11 Focus' sheet is kept as the record of that release.");
  setReadme("Changed in 0.12", "On Stories, Scenarios and TestCases: New (added for 0.11.3 – 0.12.14), Updated (a 0.11 row whose steps or expected result changed with the behaviour; the Change note says which release and why), Retired (kept, greyed, Status N/A, reason in the note). Blank = unchanged since 0.11. See the '0.12 Focus' sheet for the release-by-release list.");
  setReadme("Automation", "Filled from the Playwright suite in fireflo-control-panel/e2e at build time: Automated (a real test() exists for the id), Todo (scaffolded, not written), Manual (needs a restart, a keystore or a real host), Fixme (written, known broken). Blank = the id is not in the suite yet (every new 0.12 id until phase 2 regenerates the catalog). 'Last e2e run' is the status from e2e/.run/results.json of the last run on the build machine, partial runs included.");
  setReadme("Surface", "What drives the case: SMPP (an ESME client), HTTP (/secure/*), Ops (/ops/*), CLI (fireflo … on the host), Panel / Portal (a browser), API (a panel /api/* route with no UI), Host (restart, keystore, real machine — stays manual).");
  setReadme("Source", `Built by fireflo-control-panel/scripts/qa-plan-0.12.ts from 26-qa-test-plan-0.11.xlsx (sha256 ${srcSha.slice(0, 12)}…) plus scripts/qa-plan-0.12/changes/EP-*.ts. Edit the change files and rebuild; do not hand-edit the plan columns.`);

  // Traceability: regenerate with whole-column formulas so added rows count
  const tr = wb.getWorksheet("Traceability") ?? fail("no Traceability");
  const f = (formula: string) => ({ formula });
  const trRows: (string | { formula: string })[][] = [
    ["Epics", f("COUNTA(Epics!A:A)-1"), "Epics sheet"],
    ["Stories", f("COUNTA(Stories!A:A)-1"), "Stories sheet"],
    ["Scenarios", f("COUNTA(Scenarios!A:A)-1"), "Scenarios sheet"],
    ["Test cases", f("COUNTA(TestCases!A:A)-1"), "TestCases sheet"],
    ["  Positive", f('COUNTIF(TestCases!E:E,"Positive")')],
    ["  Negative", f('COUNTIF(TestCases!E:E,"Negative")')],
    ["  P0", f('COUNTIF(TestCases!L:L,"P0")')],
    ["  P1", f('COUNTIF(TestCases!L:L,"P1")')],
    ["  P2", f('COUNTIF(TestCases!L:L,"P2")')],
    ["  New in 0.11 (history)", f('COUNTIF(TestCases!N:N,"Y")')],
    ["  New in 0.12", f(`COUNTIF(TestCases!${col(TC.changed)}:${col(TC.changed)},"New")`)],
    ["  Updated in 0.12", f(`COUNTIF(TestCases!${col(TC.changed)}:${col(TC.changed)},"Updated")`)],
    ["  Retired in 0.12", f(`COUNTIF(TestCases!${col(TC.changed)}:${col(TC.changed)},"Retired")`)],
    ["  Automated (e2e)", f(`COUNTIF(TestCases!${col(TC.automation)}:${col(TC.automation)},"Automated")`), "from the suite at build time"],
    ["  Todo (scaffolded)", f(`COUNTIF(TestCases!${col(TC.automation)}:${col(TC.automation)},"Todo")`)],
    ["  Manual", f(`COUNTIF(TestCases!${col(TC.automation)}:${col(TC.automation)},"Manual")`)],
    ["  Not in the suite yet", f(`COUNTA(TestCases!A:A)-1-COUNTA(TestCases!${col(TC.automation)}:${col(TC.automation)})+1`)],
    ["  TCs naming a specific unit test", f("COUNTA(TestCases!O:O)-1"), "non-blank 'Automated coverage'"],
    ["  With an anti-vacuity check", f("COUNTA(TestCases!K:K)-1")],
    ["  Gateway", f('COUNTIF(TestCases!M:M,"Gateway")')],
    ["  Control Panel", f('COUNTIF(TestCases!M:M,"Control Panel")')],
    ["  Cross-component", f('COUNTIF(TestCases!M:M,"Cross-component")')],
    ["Execution: Pass", f('COUNTIF(TestCases!Q:Q,"Pass")'), "fill Status on TestCases"],
    ["Execution: Fail", f('COUNTIF(TestCases!Q:Q,"Fail")')],
    ["Execution: Blocked", f('COUNTIF(TestCases!Q:Q,"Blocked")')],
    ["Execution: Not run", f('COUNTIF(TestCases!Q:Q,"Not run")')],
    ["Execution: % complete", f("IF(B5=0,0,(B24+B25)/B5)"), "pass+fail over total"],
    [""],
    ["Epic", "Name", "TCs", "P0", "Changed 0.12", "Automated", "Todo", "Manual", "Pass", "Fail"],
  ];
  const epicCount = sheets.epics.rowCount - 1;
  for (let i = 0; i < epicCount; i++) {
    const e = i + 2;
    const r = trRows.length + 2;
    trRows.push([f(`Epics!A${e}`), f(`Epics!B${e}`), f(`Epics!G${e}`), f(`Epics!J${e}`), f(`Epics!${col(EPIC.nChanged)}${e}`), f(`Epics!${col(EPIC.nAuto)}${e}`), f(`Epics!${col(EPIC.nTodo)}${e}`), f(`Epics!${col(EPIC.nManual)}${e}`), f(`COUNTIFS(TestCases!$D:$D,A${r},TestCases!$Q:$Q,"Pass")`), f(`COUNTIFS(TestCases!$D:$D,A${r},TestCases!$Q:$Q,"Fail")`)]);
  }
  fillSheet(tr, trRows);
  tr.getColumn(1).width = 34;
  for (let c = 4; c <= 10; c++) tr.getColumn(c).width = 10;

  // 0.12 Focus: a new sheet before 0.11 Focus
  const old = wb.getWorksheet("0.11 Focus") ?? fail("no 0.11 Focus");
  const fx = wb.addWorksheet("0.12 Focus", { views: [{ state: "frozen", ySplit: 1 }] });
  wb.worksheets.splice(wb.worksheets.indexOf(fx), 1);
  wb.worksheets.splice(wb.worksheets.indexOf(old), 0, fx);
  const fxHeader = fx.getRow(1);
  ["Release", "Change", "Scenarios", "Risk / note"].forEach((h, i) => {
    fxHeader.getCell(i + 1).value = h;
    fxHeader.getCell(i + 1).style = { ...old.getRow(1).getCell(1).style };
  });
  fxHeader.height = 31.5;
  [10, 90, 36, 50].forEach((w, i) => (fx.getColumn(i + 1).width = w));
  //newest release first; rows whose item is not a plain version ("0.12.x (never in the workbook)")
  //go after every real release rather than sorting above 0.12.14 by their letter
  const releaseKey = (item: string) => {
    const m = /^(\d+)\.(\d+)\.(\d+)(?:\.(\d+))?\s*$/.exec(item);
    return m ? [1, Number(m[1]), Number(m[2]), Number(m[3]), Number(m[4] ?? 0)] : [0, 0, 0, 0, 0];
  };
  focus.sort((a, b) => {
    const ka = releaseKey(a.item);
    const kb = releaseKey(b.item);
    for (let i = 0; i < ka.length; i++) if (ka[i] !== kb[i]) return kb[i] - ka[i];
    return a.item.localeCompare(b.item);
  });
  fillSheet(fx, focus.map((r) => [r.item, r.change, r.scenarios, r.risk]));
  fx.autoFilter = { from: "A1", to: `D${Math.max(2, fx.rowCount)}` };
  old.name = "0.11 Focus (history)";

  // Coverage: the phase-2 backlog view
  const cov = wb.addWorksheet("Coverage", { views: [{ state: "frozen", ySplit: 1 }] });
  wb.worksheets.splice(wb.worksheets.indexOf(cov), 1);
  wb.worksheets.splice(wb.worksheets.indexOf(fx), 0, cov);
  const covHead = ["Epic", "Name", "Component", "TCs", "Automated", "Todo", "Manual", "Not in suite", "New in 0.12", "Updated in 0.12", "Automated %", "Phase-2 order", "Phase-2 note"];
  covHead.forEach((h, i) => {
    cov.getRow(1).getCell(i + 1).value = h;
    cov.getRow(1).getCell(i + 1).style = { ...old.getRow(1).getCell(1).style };
  });
  cov.getRow(1).height = 31.5;
  [9, 44, 15, 7, 10, 7, 8, 10, 10, 11, 11, 11, 60].forEach((w, i) => (cov.getColumn(i + 1).width = w));
  const phase2: Record<string, [number, string]> = {
    "EP-09": [1, "Rating incl. the new product story: the rig already has balance, SMPP clients and two priced vendors"],
    "EP-06": [2, "REST send: request-level, fast to write, high value"],
    "EP-19": [3, "Tester (US-19.07) and Apply now (US-19.08) first, then workers and routing editor"],
    "EP-20": [4, "Pricing page, warnings, import/export dry run"],
    "EP-21": [5, "US-21.08 Messages state first; the rest are reports"],
    "EP-08": [6, "Routing grammar and lanes: gateway-only, no browser"],
    "EP-18": [7, "Accounts and billing: half automated already"],
    "EP-03": [8, "Receipts and traffic control: the 0.12.9 per-listener rules"],
    "EP-12": [9, "Whitelisting"],
    "EP-10": [10, "CDR and usage incl. partitions"],
    "EP-15": [11, "Ops and CLI"],
    "EP-14": [12, "Licensing incl. the reload answer"],
    "EP-11": [13, "Webhooks"],
    "EP-05": [14, "Vendor outcomes"],
    "EP-04": [15, "Vendor connections"],
    "EP-07": [16, "Registrations and transfers"],
    "EP-13": [17, "Diagnostics"],
    "EP-16": [18, "Resilience and upgrade"],
    "EP-22": [19, "Portal: finish the 7 todo"],
    "EP-01": [20, "Done bar the Host cases"],
    "EP-02": [21, "Done bar the Host cases"],
    "EP-17": [22, "Done; add US-17.04 Users"],
    "EP-23": [23, "Done"],
    "EP-24": [24, "Host-bound: stays manual except the SHA/signature checks"],
  };
  const covRows: (string | number | { formula: string })[][] = [];
  for (let i = 0; i < epicCount; i++) {
    const e = i + 2;
    const r = i + 2;
    const id = text(sheets.epics.getRow(e).getCell(1));
    const [order, note] = phase2[id] ?? [99, ""];
    covRows.push([f(`Epics!A${e}`), f(`Epics!B${e}`), f(`Epics!C${e}`), f(`Epics!G${e}`), f(`Epics!${col(EPIC.nAuto)}${e}`), f(`Epics!${col(EPIC.nTodo)}${e}`), f(`Epics!${col(EPIC.nManual)}${e}`), f(`D${r}-E${r}-F${r}-G${r}-COUNTIFS(TestCases!$D:$D,A${r},TestCases!$${col(TC.automation)}:$${col(TC.automation)},"Fixme")`), f(`COUNTIFS(TestCases!$D:$D,A${r},TestCases!$${col(TC.changed)}:$${col(TC.changed)},"New")`), f(`COUNTIFS(TestCases!$D:$D,A${r},TestCases!$${col(TC.changed)}:$${col(TC.changed)},"Updated")`), f(`IF(D${r}=0,0,E${r}/D${r})`), order, note]);
  }
  fillSheet(cov, covRows);
  for (let r = 2; r <= cov.rowCount; r++) cov.getCell(`K${r}`).numFmt = "0%";
  cov.autoFilter = { from: "A1", to: `M${cov.rowCount}` };

  // Rigs & Tools: what changed since 0.11
  const rigs = wb.getWorksheet("Rigs & Tools") ?? fail("no Rigs");
  const rigRows: string[][] = [
    ["SMPPSim shipped with the release (0.12.7+)", "fireflo-install --with-smppsim · fireflo-install smppsim (existing install) · fireflo smppsim-setup", "Runs beside the gateway, routes MESSAGE to it when there is no catch-all, invents its receipts. fireflo selftest then sends one real message and reports route / price / receipt / debit as PASS/FAIL/SKIP (exit 0/1/2). Replace with a real vendor before real traffic."],
    ["The e2e rig (fireflo-control-panel/e2e)", "cp e2e/.env.e2e.example e2e/.env.e2e · npm run e2e (or e2e:epic -- @EP-09, e2e:run -- --grep TC-09.06)", "Self-contained: its own database (name must contain e2e; truncated each run), EdgeSmsc A/B on 28800/28801, gateway 8100/9100 with a 2 s config poll, SMPP 27800–27802, panel 3100, SMTP sinks 4465/4587. Seed: qa-acct-a/b, qa-portal-a, qa-reseller-r → qa-child-c1, product standard, AUD 0.0100 / cost 0.0050, vendors qa-sim1/qa-sim2, listeners smpp/smpp2, group qa-failover. Results: e2e/.run/results.json; npm run e2e:writeback copies them into a dated workbook."],
    ["Staging host 192.168.1.101 (fireflo-trial)", "ssh anshu@192.168.1.101 · gateway :8081 (HTTP) :9000 (ops) :27777 (SMPP) · panel :3000 · ~/staging/debit-test-101.sh setup|product|unproduct|state|teardown", "The 0.12.14 product/debit reproduction lives there: product test-pro, rules omni/load at 0.1100 AUD, balance enforcement on, 10 AUD per account. Every sudo step is the operator's."],
  ];
  for (const r of rigRows) {
    const row = rigs.addRow(r);
    row.eachCell((cell) => {
      cell.font = { name: "Arial", size: 9 };
      cell.alignment = { vertical: "top", wrapText: true };
    });
  }
  rigs.autoFilter = { from: "A1", to: `C${rigs.rowCount}` };

  // sheet order: the plan, then the two views, then history and tools
  const order = ["README", "Epics", "Stories", "Scenarios", "TestCases", "Traceability", "Coverage", "0.12 Focus", "0.11 Focus (history)", "Rigs & Tools"];
  //orderNo is what exceljs writes the tabs by; its typings leave it off Worksheet
  for (const ws of wb.worksheets) (ws as unknown as { orderNo: number }).orderNo = order.indexOf(ws.name) < 0 ? 99 : order.indexOf(ws.name);

  wb.creator = "fireflo-control-panel/scripts/qa-plan-0.12.ts";
  wb.modified = new Date();
  await wb.xlsx.writeFile(OUT);

  const total = sheets.cases.rowCount - 1;
  console.log(`wrote ${path.relative(process.cwd(), OUT)}`);
  console.log(`  epics ${sheets.epics.rowCount - 1}, stories ${sheets.stories.rowCount - 1}, scenarios ${sheets.scenarios.rowCount - 1}, test cases ${total}`);
  console.log(`  added: stories ${added.stories}, scenarios ${added.scenarios}, cases ${added.cases}; updated ${added.updates}; retired ${added.retired}; focus rows ${focus.length}`);
  console.log(`  automation: automated ${counts.Automated}, todo ${counts.Todo}, manual ${counts.Manual}, fixme ${counts.Fixme}, not in suite ${counts.none}; last run ${run.at || "none"} (${run.results.size} results)`);
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});
