import type { Change } from "../../qa-plan-types.ts";

/**
 * EP-12 Whitelisting, 0.11 -> 0.12.14.
 *
 * One gateway-side change, from commit ee61bb5 (in 0.12.3; not in the release notes): product, login and template
 * wording match ignoring case. An approved sender ID was refused when the session's system_type differed from the
 * product only in case ('otp' found nothing filed under 'OTP'); the bind's system_type and a REST product now
 * resolve to the catalogue's spelling once, at the edge; per-login approvals match the login in any case; template
 * wording matches in any case; a refused sender ID names the product it was looked up under.
 *
 * Not here: US-12.04 "Lock SMPP logins to their first address" (0.12.5, smsg.smpp.whitelist.first.bind) is an SMPP
 * bind concern and belongs to EP-01. The 0.12.8.2 panel "Fix" link on the approved-TLVs-not-stamped warning is
 * panel-only and is referenced from the focus row; the gateway stamping rules (SC-12.03.01) are unchanged.
 */
const change: Change = {
  epic: "EP-12",
  scenarios: [
    { id: "SC-12.02.03", story: "US-12.02", epic: "EP-12", scenario: "Case does not refuse: product, login and template wording match ignoring case", gwt: "Given header ACME approved for qa-acct-a under product OTP (filed per login 'QA-Bind'), template 'Your OTP is {#num#}' approved under OTP, and ENFORCE. When a session binds with system_type 'otp' as login qa-bind and sends 'your otp is 123456' from ACME. Then the message is delivered and recorded under product 'OTP'; a sender not approved under that product is refused with a message naming the product searched.", preconditions: "Product OTP in app_product; whitelist on; SMPP listener smpp; REST login for the same account", rig: "cloudhopper bind with system_type; curl /secure/send; psql cdr_submit, cdr_rejected; smsg.log", related: "SC-12.02.01, SC-12.02.02, SC-07.01.01", dependsOn: "", changed: "New" },
  ],
  cases: [
    { id: "TC-12.02.03-P01", scenario: "SC-12.02.03", story: "US-12.02", epic: "EP-12", type: "Positive", title: "A bind whose system_type differs from the product only in case finds the approvals filed under the product", steps: "1. Approve ACME for qa-acct-a under product OTP (system_id NULL); account ENFORCE. 2. Bind qa-bind with system_type 'otp'; submit_sm from ACME. 3. POST /secure/send product:'otp' from ACME on the account's HTTP login (allowed_products [OTP]). 4. Read cdr_submit.", testData: "product OTP; header ACME", expected: "Both delivered (command_status 0; HTTP 200); cdr_submit.product 'OTP' on both rows, not 'otp'; fireflo_whitelist_header_rejects unchanged", oracle: "SMPP command_status; HTTP status; cdr_submit.product; /q/metrics fireflo_whitelist_header_rejects", antiVacuity: "A bind with system_type 'OTP' passes without the fix; the spelling must differ in case from the product the approval is filed under.", priority: "P0", component: "Gateway", automated: "CaseInsensitiveMatchingTest, ProductCatalogueTest", related: "TC-12.02.01-N04, TC-12.02.01-P01", surface: "SMPP", changed: "New", changeNote: "0.12.3 (commit ee61bb5, not in the release note): the bind's system_type and a REST product resolve to the catalogue's spelling once, at the edge" },
    { id: "TC-12.02.03-P02", scenario: "SC-12.02.03", story: "US-12.02", epic: "EP-12", type: "Positive", title: "A per-login approval matches the login in any case, and template wording matches in any case", steps: "1. Approve ACME for qa-acct-a with system_id 'QA-Bind'; approve template 'Your OTP is {#num#}' under OTP. 2. Bind as qa-bind (lower case) with system_type OTP; send 'your otp is 123456' from ACME. 3. Send 'YOUR OTP IS 654321'.", testData: "", expected: "Both delivered; cdr_submit rows carry the template id in tlvs_sent when stamping is on; no 0x0412/0x0415", oracle: "SMPP command_status; cdr_submit.tlvs_sent", antiVacuity: "", priority: "P1", component: "Gateway", automated: "CaseInsensitiveMatchingTest", related: "TC-12.02.02-P01, TC-12.02.02-P02", surface: "SMPP", changed: "New", changeNote: "0.12.3: per-login approvals match the login in any case; template wording matches in any case, compared rather than copied" },
    { id: "TC-12.02.03-N01", scenario: "SC-12.02.03", story: "US-12.02", epic: "EP-12", type: "Negative", title: "A sender refused under a product says which product it was looked up under; a different product still refuses", steps: "1. ACME approved under OTP only. 2. Bind with system_type 'test-pro'; submit_sm from ACME. 3. POST /secure/send product:'test-pro' from ACME (allowed_products [OTP, test-pro]).", testData: "", expected: "SMPP 0x0415; HTTP 403 with body \"'ACME' is not an approved sender ID for this account under product 'test-pro'.\"; cdr_rejected detail names product 'test-pro'; fireflo_whitelist_header_rejects +2; nothing charged", oracle: "SMPP command_status; HTTP body; cdr_rejected.detail; account_balance", antiVacuity: "", priority: "P1", component: "Gateway", automated: "", related: "TC-12.02.01-N04", surface: "SMPP", changed: "New", changeNote: "0.12.3: a refused sender ID now names the product it was looked up under" },
  ],
  updates: [
    { id: "US-12.02", changed: "Updated", changeNote: "0.12.3: case-insensitive matching", set: { acceptance: "1. Loader serves only enabled AND status='APPROVED'. 2. PENDING → refused at send under ENFORCE. 3. Approve → served on the next poll. 4. Reject → refused, row REJECTED. 5. Disable an approved row → WITHDRAWN, refused. 6. Product scoping: approved for 'standard' does not cover 'premium'. 7. Case never refuses (0.12.3): system_type and the REST product resolve to the catalogue's spelling, per-login approvals match the login in any case, template wording matches in any case; a header refusal names the product searched." } },
    { id: "TC-12.02.01-N04", changed: "Updated", changeNote: "0.12.3: a product mismatch is refused, a case difference is not", set: { expected: "0x0415, refusal naming product 'premium'; a bind with system_type 'Standard' is NOT refused (SC-12.02.03)" } },
  ],
  focus: [
    { item: "0.12.3", change: "Product, login and template wording match ignoring case; refusals name the product searched (commit ee61bb5, not in the release notes).", scenarios: "SC-12.02.03", risk: "A customer whose client binds 'otp' against approvals filed under 'OTP' was refused before; the fix also changes what cdr_submit.product records (canonical spelling), which rating (EP-09 SC-09.06.04) and routing by product read." },
    { item: "0.12.8.2", change: "Control panel adds a 'Fix' link to the warning about approved TLVs that are not stamped, opening the listener's settings at 'Stamp approved TLVs'.", scenarios: "SC-12.03.01", risk: "Panel-only; gateway stamp modes unchanged (TlvStampModeTest extended 0.12.8 for several TLVs on one row, no behaviour change). The link itself is the panel epic's case." },
    { item: "0.12.5", change: "Lock SMPP logins to their first address (smsg.smpp.whitelist.first.bind) -- a bind-time control, not sender/template whitelisting.", scenarios: "", risk: "Covered under EP-01; listed here only because the key's name says 'whitelist'." },
  ],
};
export default change;
