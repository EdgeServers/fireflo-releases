# QA plan 0.12: how the workbook is built

`npm run qa-plan` (= `node --experimental-strip-types scripts/qa-plan-0.12.ts`) reads
`../fireflo-sms-gateway/docs/26-qa-test-plan-0.11.xlsx`, applies every change file in
`scripts/qa-plan-0.12/changes/EP-*.ts`, fills the automation columns from the e2e suite, and writes
`../fireflo-sms-gateway/docs/26-qa-test-plan-0.12.xlsx`. The 0.11 workbook is never modified.

## The change file

One file per epic, `changes/EP-09.ts`, exporting a `Change` object (type in `../qa-plan-types.ts`):

```ts
import type { Change } from "../../qa-plan-types.ts";
const change: Change = {
  epic: "EP-09",
  epicDescription: "…",                 // optional: replaces the Epics sheet description
  stories: [ { id: "US-09.06", epic: "EP-09", story: "…", asA: "an operator", iWant: "…", soThat: "…",
               acceptance: "1. … 2. …", configKeys: "…", observable: "…", automated: "—", changed: "New" } ],
  scenarios: [ { id: "SC-09.06.01", story: "US-09.06", epic: "EP-09", scenario: "…", gwt: "Given … When … Then …",
                 preconditions: "…", rig: "…", related: "SC-19.07.01", dependsOn: "", changed: "New" } ],
  cases: [ { id: "TC-09.06.01-P01", scenario: "SC-09.06.01", story: "US-09.06", epic: "EP-09", type: "Positive",
             title: "…", steps: "1. … 2. …", testData: "", expected: "…", oracle: "…", antiVacuity: "…",
             priority: "P0", component: "Gateway", automated: "", related: "", surface: "SMPP",
             changed: "New", changeNote: "0.12.14" } ],
  updates: [ { id: "TC-09.01.01-P03", changed: "Updated", changeNote: "0.12.11: a message with no product sees only any-product rules",
               set: { steps: "…", expected: "…" } } ],      // any TC / SC / US field by its key below
  retire: [ { id: "TC-xx", reason: "…" } ],
  focus: [ { item: "0.12.11", change: "…", scenarios: "SC-09.06.01, SC-19.07.01", risk: "…" } ],
};
export default change;
```

Field keys map to sheet columns:

| Sheet | keys |
|---|---|
| Stories | id, epic, story, asA, iWant, soThat, acceptance, configKeys, observable, automated, changed |
| Scenarios | id, story, epic, scenario, gwt, preconditions, rig, related, dependsOn, changed |
| TestCases | id, scenario, story, epic, type (Positive/Negative), title, steps, testData, expected, oracle, antiVacuity, priority (P0/P1/P2), component (Gateway / Control Panel / Cross-component), automated (JUnit / node:test class, or blank), related, surface (SMPP / HTTP / Ops / CLI / Panel / Portal / API / Host), changed (New/Updated), changeNote |

Rules the builder enforces (it fails the build otherwise):
- ids are well formed and nest (`TC-09.06.01-P01` belongs to `SC-09.06.01`, which belongs to `US-09.06`, which belongs to `EP-09`);
- a new id does not exist in 0.11; an `updates`/`retire` id does;
- every new TC has steps, expected and oracle; every scenario has a Given/When/Then; `related`/`dependsOn` ids exist (0.11 or new);
- numbering is contiguous per scenario (P01, P02…, N01, N02…).

## Writing rules (from the brief)
- A TC is **one observable behaviour in 2–6 steps**. Not one per click, not one per page.
- A multi-step flow is **one scenario**: one positive case walks the whole flow end to end; the negatives sit at the step that can go wrong.
- Oracle says **where to look** (table.column, log line name, HTTP status, SMPP command_status, EdgeSmsc counter, page element). Never "the UI looks right".
- Anti-vacuity says what would falsely pass (the historical defect, or the half of the check that proves it can fail). Fill it on every P0.
- Steps use the e2e rig's names where they exist: accounts `qa-acct-a`/`qa-acct-b`/`qa-portal-a`, reseller `qa-reseller-r` → `qa-child-c1`; product `standard`; vendors `qa-sim1`/`qa-sim2` (EdgeSmsc A/B, control verbs on the Rigs sheet); listeners `smpp` (27800) / `smpp2`; price 0.0100, cost 0.0050, AUD. Invent only what the case needs (e.g. product `test-pro`).
- `surface` tells phase 2 what drives the case: SMPP = an ESME client, HTTP = `/secure/*`, Ops = `/ops/*`, CLI = `fireflo …` on the host, Panel/Portal = a browser, API = a panel `/api/*` route with no UI, Host = needs a restart, a keystore or a real machine (these are the ones that stay manual).
- Priority: P0 money, message loss, security boundary, or a headline 0.12 claim; P1 a function a customer relies on; P2 secondary.
