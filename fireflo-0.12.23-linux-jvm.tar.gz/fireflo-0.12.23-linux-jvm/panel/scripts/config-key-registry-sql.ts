/**
 * Prints the panel's built-in configuration key registry as SQL rows for `app_config_key`.
 *
 *   node --experimental-strip-types scripts/config-key-registry-sql.ts
 *
 * <p>This is how the gateway migration that creates the table (V1.61.0) got its seed, and how a later
 * migration adding keys should get its rows: add the key to the panel's catalogue, run this, and copy
 * the new lines. Generating rather than hand-writing is the point -- the registry and the forms that
 * render it come from one list, so they cannot disagree about a key's type, choices or secrecy.
 *
 * <p>Output is sorted by scope then key, so a diff between two runs shows exactly what changed.
 */
import { BUILTIN_REGISTRY, type ConfigKeyRow } from "../lib/config-key-registry.ts";

function lit(value: string | null): string {
  return value === null ? "NULL" : `'${value.replace(/'/g, "''")}'`;
}

function arr(values: string[] | null): string {
  return values === null ? "NULL" : `ARRAY[${values.map(lit).join(", ")}]::text[]`;
}

function row(r: ConfigKeyRow): string {
  return `    (${[lit(r.scope), lit(r.key), lit(r.kind), arr(r.choices), lit(r.unit), lit(r.codedDefault),
    r.secret ? "TRUE" : "FALSE", lit(r.access), lit(r.reason), lit(r.label), lit(r.status), lit(r.replacedBy)].join(", ")})`;
}

const rows = [...BUILTIN_REGISTRY.rows].sort((a, b) =>
  a.scope === b.scope ? a.key.localeCompare(b.key) : a.scope.localeCompare(b.scope));

//status and replaced_by exist from V1.88.0; a migration older than that drops the last two columns
console.log("INSERT INTO app_config_key (scope, key, kind, choices, unit, coded_default, secret, access, reason, label, status, replaced_by) VALUES");
console.log(rows.map(row).join(",\n") + ";");
