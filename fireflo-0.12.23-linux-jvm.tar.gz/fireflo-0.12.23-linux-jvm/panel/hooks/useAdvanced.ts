"use client";
import { useCallback, useEffect, useState } from "react";

/**
 * The Advanced switch, remembered per page.
 *
 * <p>Every reorganised page shows the few fields an operator touches daily and keeps the rest --
 * TLVs, allowed products, free-form settings, rule conditions -- behind one switch. The choice is
 * per page rather than global, because somebody who lives in routing conditions all day does not
 * also want every login card at full length.
 *
 * <p>`localStorage` is a convenience, not state: it can be absent, blocked or throw, and the page
 * renders correctly with the switch off. Read after mount, never in the initialiser, so the server
 * render and the first client render agree.
 */
export function useAdvanced(page: string): [boolean, (on: boolean) => void] {
  const key = `fireflo.advanced.${page}`;
  const [on, setOn] = useState(false);

  useEffect(() => {
    try {
      setOn(window.localStorage.getItem(key) === "1");
    } catch {
      //private window or blocked storage: off, which is the safe default
    }
  }, [key]);

  const set = useCallback(
    (next: boolean) => {
      setOn(next);
      try {
        window.localStorage.setItem(key, next ? "1" : "0");
      } catch {
        //nothing to do: the page still has the value for this visit
      }
    },
    [key]
  );

  return [on, set];
}
