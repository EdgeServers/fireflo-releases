import type { SettingWidget } from "./setting-fields";

/**
 * The gateway-wide keys this panel is willing to edit, and how to render them.
 *
 * <h2>An allow-list, not a key/value editor</h2>
 *
 * <p>There are 59 `smsg.*` keys in the gateway source. This catalogue holds the ones an operator has
 * a reason to change, and a key with no entry here cannot be written from the panel at all. That is
 * the security boundary, and it is deliberately a list rather than a filter:
 *
 * <ul>
 *   <li><strong>Credentials.</strong> `smsg.ops.token` and `smsg.ops.admin.token` are how the panel
 *       authenticates to the gateway. An editor for a credential is how a credential leaks — into a
 *       screenshot, a support ticket, a browser's autofill store.
 *   <li><strong>Anything that decides where configuration comes from.</strong> `smsg.config.source`
 *       and the four `*.file.path` keys. Editing those through a panel that reads its own
 *       configuration from the database is a way to lock everyone out of the room they are standing
 *       in.
 *   <li><strong>The broker and sink wiring.</strong> `smsg.queue.amqp.uri` can carry a password;
 *       `smsg.cdr.sink` changes where records go, mid-flight. (`smsg.queue.provider` is set on the
 *       Queues page, which says a restart is needed rather than pretending it applies at once.)
 *   <li><strong>The webhook egress guards.</strong> `smsg.webhook.private.targets` and
 *       `smsg.webhook.schemes` exist to stop the gateway being pointed at internal addresses.
 *       Loosening an SSRF guard from a web form is not an operator convenience.
 *   <li><strong>Keys the panel already edits elsewhere</strong> — currency, money scale, billing zone
 *       — because two editors for one value is how they come to disagree.
 * </ul>
 *
 * <h2>codedDefault is optional here, and that is the point</h2>
 *
 * <p>{@code SETTING_FIELDS} carries a `codedDefault` for every worker key, read out of the Java. This
 * catalogue allows null, because a default nobody has actually read is exactly the failure this whole
 * change exists to fix: the worker form has been telling operators "the gateway's default is X" from
 * a snapshot, and has been wrong whenever a gateway default was set. Null renders as "not set"
 * without a claim attached.
 *
 * <p>Every non-null value below was read from the gateway source at the call site, not from a
 * javadoc — see `smsg.restapi.billing.units`, where the two disagree.
 */
export interface GatewaySettingField {
  key: string;
  label: string;
  hint?: string;
  widget: SettingWidget;
  /** The literal the gateway parses when the key is absent, or null when it has not been verified. */
  codedDefault: string | null;
  /** Which section of the page this belongs to. */
  section: GatewaySection;
  /** Shown beside a number field, for a unit the widget's own `unit` cannot express. */
  suffix?: string;
  /** What an empty box means, as its placeholder, when that is not the coded default. */
  unsetLabel?: string;
  /**
   * Read once, when the gateway starts. Saving it changes the database at once and the running
   * gateway at its next restart, so the page says "until a restart" rather than "within one poll".
   */
  startup?: true;
}

/**
 * The page's sections, in the order they render.
 *
 * <p>By what an operator is trying to do rather than by which ingress reads the key. The page used to
 * be two columns, REST and gateway-wide, which put "may this message be sent" beside "what does a
 * receipt look like" because both happened to apply to both ingresses.
 */
export const GATEWAY_SECTIONS = [
  { id: "approval", title: "Approval and pricing", description: "What a message must pass before it is sent." },
  {
    id: "restapi",
    title: "REST API",
    description:
      "For messages arriving over HTTP. SMPP listeners keep their own copies of these under Servers; the two may differ, on purpose.",
  },
  {
    id: "receipts",
    title: "Receipts and callbacks",
    description: "How delivery receipts and batch results reach customers' endpoints.",
  },
  { id: "records", title: "Call records", description: "How long the gateway waits before closing a record." },
  {
    id: "usage",
    title: "Usage summaries",
    description: "The hourly and daily summaries the dashboards and the portal read, kept by the gateway itself.",
  },
  {
    id: "smpp",
    title: "SMPP logins",
    description: "How customers' SMPP logins are held to the addresses they bind from.",
  },
  {
    id: "preprocessors",
    title: "Preprocessors",
    description: "Your own programs that a routing rule hands matching messages to. They run on the gateway host.",
  },
] as const;

export type GatewaySection = (typeof GATEWAY_SECTIONS)[number]["id"];

export const GATEWAY_SETTING_FIELDS: readonly GatewaySettingField[] = [
  // --- preprocessors (gateway 0.12.0) ------------------------------------------------------------
  {
    key: "smsg.preprocessor.enabled",
    label: "Run preprocessors",
    hint:
      "Off unless switched on. When off, no preprocessor program runs on the gateway host, every " +
      "routing rule that sends to one is skipped, and the code workbench cannot check, test or " +
      "save. Applies within one configuration poll.",
    widget: { kind: "boolean" },
    //PreprocessorFiles.enabled -- setting(config, ENABLED_KEY, "false")
    codedDefault: "false",
    section: "preprocessors",
  },
  {
    key: "smsg.preprocessor.editable",
    label: "Edit preprocessor code from the panel",
    hint:
      "Lets an admin change, test and save the program files in the gateway's preprocessor directory " +
      "from the Preprocessors page. Off means code is deployed on the host by hand and the panel only " +
      "shows it. Every save is kept and recorded in the access log.",
    widget: { kind: "boolean" },
    //PreprocessorWorkbench.editable -- setting(config, EDITABLE_KEY, "true")
    codedDefault: "true",
    section: "preprocessors",
  },
  // --- the REST ingress's own configuration ----------------------------------------------------
  {
    key: "smsg.restapi.whitelist.tlvs.mode",
    label: "Stamp approved TLVs",
    hint:
      "What a matched sender ID or template does with the TLVs it carries, for messages arriving " +
      "over HTTP. The SMPP listeners have their own setting and default the other way — this page " +
      "is where the two can be compared.",
    widget: {
      kind: "enum",
      options: [
        { value: "off", label: "Off — a match stamps nothing" },
        { value: "assign", label: "Assign — fill the tag only when the customer sent none" },
        { value: "replace", label: "Replace — the approved value always wins" },
      ],
    },
    //MessageSubmissionService:491 -- `configured.isBlank() ? TlvStampMode.REPLACE`
    codedDefault: "replace",
    section: "restapi",
  },
  {
    key: "smsg.restapi.mandatory.tlvs.submit",
    label: "Required TLVs",
    hint:
      "A message arriving over HTTP without these is refused. Declared separately from a listener's " +
      "own list because that belongs to one listener and there may be several — set both when the " +
      "requirement is gateway-wide. They do not track each other.",
    widget: { kind: "list", itemPlaceholder: "name_0x1400", itemKind: "tlv" },
    codedDefault: "",
    section: "restapi",
  },
  {
    key: "smsg.restapi.billing.units",
    label: "Billed per",
    hint:
      "Whether a long message costs once or once per segment over HTTP. SMPP always charges per " +
      "inbound PDU, so `segment` prices the two ingresses alike and `message` makes a long message " +
      "cheaper over HTTP.",
    widget: {
      kind: "enum",
      options: [
        { value: "segment", label: "Segment — each segment is a billable unit" },
        { value: "message", label: "Message — one charge however many segments" },
      ],
    },
    //MessageSubmissionService:649 -- getPrpt(PRP_BILLING_UNITS, UNITS_SEGMENT). NOTE the javadoc on
    //PRP_BILLING_UNITS says it defaults to `message`; the code says `segment`. Taken from the code,
    //because that is what the customer is charged
    codedDefault: "segment",
    section: "restapi",
  },
  {
    key: "smsg.restapi.product.required",
    label: "A product must be named",
    hint: "Refuse an HTTP submission that does not name a product this gateway sells.",
    widget: { kind: "boolean" },
    //MessageSubmissionService -- getBlnPrpt(PRP_PRODUCT_REQUIRED, "false")
    codedDefault: "false",
    section: "restapi",
  },
  {
    key: "smsg.restapi.maxRate.default",
    label: "Default rate limit",
    hint: "Messages per second for an account with no limit of its own. Unlimited when unset.",
    widget: { kind: "number" },
    //not verified at its call site, and deliberately not guessed
    codedDefault: null,
    section: "restapi",
    suffix: "msg/s",
    unsetLabel: "Unlimited",
  },
  // --- retrying a REST send safely (gateway 0.13, V1.89.0) ---------------------------------------
  {
    key: "smsg.restapi.client.ref.window.hours",
    label: "Remember a send's client reference for",
    hint:
      "How long a repeated /secure/send with the same client_ref from the same account is answered " +
      "with the original message instead of being sent again. Remembered in memory on the node that " +
      "took the first send and looked up in the call record after that, so a retry after a restart " +
      "or on another node is still recognised. Applies within one configuration poll.",
    widget: { kind: "number" },
    //ClientRefIndex.WINDOW_KEY, read with a default of 24 (docs/06-http-api.md, Retrying safely)
    codedDefault: "24",
    section: "restapi",
    suffix: "h",
  },
  // --- the webhook retry store (gateway 0.12.15, V1.82.0) ----------------------------------------
  {
    key: "smsg.webhook.retry.pending.max",
    label: "Webhook attempts held in memory",
    hint:
      "Receipt and inbound-message callbacks waiting for their turn or their retry when there is no " +
      "broker. At this many the oldest is dropped and counted; a dropped receipt is written as a " +
      "callback event. Applies after a restart.",
    widget: { kind: "number" },
    //WebhookRetryStore.DEFAULT_PENDING_MAX
    codedDefault: "10000",
    section: "receipts",
  },
  // --- REST tokens for a platform holding the management token (gateway 0.12.6+, V1.71.0) --------
  {
    key: "smsg.restapi.token.ttl",
    label: "REST token lifetime",
    hint:
      "How long a token issued with the management token stays valid, 60 to 86400 seconds. Renewing " +
      "early never interrupts sending. Applies to tokens issued after a change.",
    widget: { kind: "number", unit: "s" },
    //ManagementResource.ttl -- smsg.restapi.token.ttl, default 3600, clamped 60..86400
    codedDefault: "3600",
    section: "restapi",
  },
  {
    key: "smsg.restapi.token.plain.http.allowed",
    label: "Allow tokens over plain HTTP from allowed addresses",
    hint:
      "Off: management requests and tokens must use HTTPS (loopback excepted). On: also plain HTTP, " +
      "but only from addresses in FIREFLO_MANAGEMENT_ALLOWED_IPS. For a private network only.",
    widget: { kind: "boolean" },
    //ManagementToken.transportAllowed -- getBlnPrpt(..., false)
    codedDefault: "false",
    section: "restapi",
  },

  // --- gateway-wide, both ingresses ------------------------------------------------------------
  {
    key: "smsg.whitelist.enabled",
    label: "Sender ID and template approval",
    hint:
      "The master switch. A listener's own flag and the product flag both have to agree before a " +
      "message is checked, so turning this off stops all approval checking everywhere.",
    widget: { kind: "boolean" },
    //WhitelistService:94 -- getBlnPrpt(ENABLED_KEY, false), and conf.example says "off by default"
    codedDefault: "false",
    section: "approval",
  },
  // --- SMPP logins (gateway 0.12.5+, V1.70.0) ----------------------------------------------------
  {
    key: "smsg.smpp.whitelist.first.bind",
    label: "Lock SMPP logins to their first address",
    hint:
      "When a login with no allowed IP addresses binds, its address is saved as the only one allowed " +
      "and later binds from anywhere else are refused. Applies to existing logins too, at their next " +
      "bind, so check none of your customers binds from more than one address. Clearing a login's " +
      "list re-arms it. Needs logins kept in the database.",
    widget: { kind: "boolean" },
    //BasicSmppAuthenticationProvider.lockToFirstAddress -- getBlnPrpt(KEY, false)
    codedDefault: "false",
    section: "smpp",
  },
  {
    key: "smsg.rating.unrated.refuse",
    label: "Refuse messages that cannot be priced",
    hint: "Otherwise an unrated message is sent and charged nothing.",
    widget: { kind: "boolean" },
    //getBlnPrpt(PRP_REFUSE_UNRATED, "false")
    codedDefault: "false",
    section: "approval",
  },
  {
    key: "smsg.dlr.forward.format",
    label: "Delivery receipt format",
    hint:
      "JSON posts a body carrying the state, both timestamps and the addresses. Kannel substitutes " +
      "%s and %d into the registered URL and issues a bare GET, which carries only what the URL was " +
      "written to hold — a URL with no placeholders gets a request with nothing in it.",
    widget: {
      kind: "enum",
      options: [
        { value: "json", label: "JSON — a posted body" },
        { value: "kannel", label: "Kannel — placeholders in the URL" },
      ],
    },
    //ForwardDlrService:203 -- getPrpt(PRP_FORMAT, FORMAT_JSON)
    codedDefault: "json",
    section: "receipts",
  },
  {
    key: "smsg.dlr.forward.fields.vendor",
    label: "Name the vendor in receipts",
    hint:
      "Off unless switched on. The field names your supplier to your customer, at an endpoint the " +
      "customer controls — the CDR surfaces already treat that as buy-side and refuse it.",
    widget: { kind: "boolean" },
    //ForwardDlrService:222 -- getBlnPrpt(PRP_SEND_VENDOR, false)
    codedDefault: "false",
    section: "receipts",
  },
  {
    key: "smsg.callback.bulk.accounts",
    label: "Accounts that get receipts and batch callbacks in bulk",
    hint:
      "For these accounts, JSON receipts and batch results go as one POSTed array of many, instead " +
      "of one request each — the difference between a receiver taking 2,000 calls a second and " +
      "taking a handful. Their receiver must accept an array. Every other account is unchanged.",
    widget: { kind: "list", itemPlaceholder: "account id" },
    //BulkPoster.isBulk -- an empty list puts no account in bulk
    codedDefault: "",
    section: "receipts",
  },
  {
    key: "smsg.callback.bulk.max",
    label: "Most receipts or results in one bulk request",
    widget: { kind: "number" },
    //BulkPoster.DEFAULT_MAX
    codedDefault: "500",
    section: "receipts",
    suffix: "items",
    startup: true,
  },
  {
    key: "smsg.callback.bulk.linger.ms",
    label: "How long a bulk request waits to fill",
    hint: "The account list above takes effect at once; this and the size take a restart.",
    widget: { kind: "number", unit: "ms" },
    //BulkPoster.DEFAULT_LINGER_MS
    codedDefault: "200",
    section: "receipts",
    startup: true,
  },
  {
    key: "smsg.cdr.events.response",
    label: "Keep what a callback endpoint answered",
    hint:
      "Off unless switched on. Records up to 500 characters of the response body and a fixed list " +
      "of headers on each callback attempt, which is where a 401 behind a proxy stops looking like " +
      "a 401 from the application. It is a separate key from the diagnostics level on purpose: a " +
      "response body is a customer's own server's content, and no level turns that on for you.",
    widget: { kind: "enum", options: [
      { value: "off", label: "Off" },
      { value: "excerpt", label: "First 500 characters" },
    ] },
    //ResponseMode.of -- null and anything unrecognised resolve to OFF
    codedDefault: "off",
    section: "receipts",
  },
  {
    key: "smsg.cdr.body",
    label: "Keep message text",
    hint:
      "Off unless switched on. Stores each message's text on its call record: the first 160 " +
      "characters, or all of it. Once on, the text is searchable on the Messages page, shown to " +
      "operators and to customers for their own messages, included in CSV exports, and kept as long " +
      "as the call record and every backup of it -- one-time passcodes included. Applies to messages " +
      "sent from the next config poll; earlier messages never gain text.",
    widget: { kind: "enum", options: [
      { value: "off", label: "Off" },
      { value: "excerpt", label: "First 160 characters" },
      { value: "full", label: "The whole message" },
    ] },
    //BodyMode.of -- null and anything unrecognised resolve to OFF
    codedDefault: "off",
    section: "records",
  },
  {
    key: "smsg.cdr.deadline.hours",
    label: "Give up waiting for a receipt after",
    hint: "The expiry sweep closes a message still PENDING for longer than this, as EXPIRED.",
    //no unit on the widget: SettingWidget offers ms, s and min, and this key is hours. The suffix
    //carries it rather than the field rendering "48 minutes" beside a value that means two days
    widget: { kind: "number" },
    //CdrExpirySweeper:49 -- DEFAULT_DEADLINE_HOURS = 48
    codedDefault: "48",
    section: "records",
    suffix: "hours",
  },
  {
    key: "smsg.cdr.event.retention.days",
    label: "Keep per-message events for",
    hint: "Receipt and callback events older than this are dropped, a month at a time (V1.80.0 partitions).",
    widget: { kind: "number" },
    //CdrExpirySweeper -- DEFAULT_EVENT_RETENTION_DAYS = 90
    codedDefault: "90",
    section: "records",
    suffix: "days",
  },
  {
    key: "smsg.cdr.rejected.retention.days",
    label: "Keep refused-message records for",
    hint: "Rows on the Refused page older than this are deleted in batches by the expiry sweep.",
    widget: { kind: "number" },
    //CdrExpirySweeper -- DEFAULT_REJECTED_RETENTION_DAYS = 90
    codedDefault: "90",
    section: "records",
    suffix: "days",
  },
  // --- the queue archive (gateway 0.12.19, V1.93.0) -------------------------------------------------
  {
    key: "smsg.queue.archive.retention.days",
    label: "Keep queue archive months for",
    hint:
      "What queue housekeeping archived (Reports → Archives). 0, the default, keeps every month until " +
      "an operator runs `fireflo queue archive purge`. Set, the expiry sweep runs that same purge for " +
      "whole months older than this: each month is reconciled against the per-day summary first and " +
      "refused on a mismatch, and the summary rows are kept, so per-account totals never change.",
    widget: { kind: "number" },
    //V1.93.0 registers it with 0 = never deleted automatically
    codedDefault: "0",
    section: "records",
    suffix: "days",
    unsetLabel: "0 — never automatically",
  },
  // --- the CDR writer (gateway 0.12.15, V1.85.0) --------------------------------------------------
  {
    key: "smsg.cdr.writers",
    label: "Call-record writer threads",
    hint: "Lanes writing call records to the database, 1 to 8. A message's rows always share one lane, so order is kept. Applies after a restart.",
    widget: { kind: "number" },
    //CdrWriter: default 2, clamped 1..8
    codedDefault: "2",
    section: "records",
  },
  {
    key: "smsg.cdr.queue.size",
    label: "Call-record queue",
    hint: "Records waiting to be written, across all lanes. Applies after a restart.",
    widget: { kind: "number" },
    codedDefault: "100000",
    section: "records",
  },
  {
    key: "smsg.cdr.batch.size",
    label: "Call-record batch",
    hint: "Records written per database round trip. Applies after a restart.",
    widget: { kind: "number" },
    codedDefault: "200",
    section: "records",
  },
  {
    key: "smsg.cdr.put.timeout.ms",
    label: "Full-queue wait",
    hint: "How long a message waits for room in the queue before its record is spilled to the JSONL file (submits and finals) or counted as lost (the rest). Applies after a restart.",
    widget: { kind: "number", unit: "ms" },
    codedDefault: "500",
    section: "records",
  },
  // --- the usage summaries (gateway 0.12.16, V1.91.0) ----------------------------------------------
  {
    key: "smsg.usage.hourly.enabled",
    label: "Keep an hourly usage summary",
    hint: "The gateway counts each hour's traffic, delivery and money per account, product and vendor as it goes, and the dashboards read those rows instead of the call records. Off, the home page and the portal read the records live.",
    widget: { kind: "boolean" },
    //UsageRollupScheduler -- on unless switched off
    codedDefault: "true",
    section: "usage",
  },
  {
    key: "smsg.usage.hourly.interval.seconds",
    label: "Count every",
    hint: "How often the hourly summary is brought up to date. The dashboards are at most this far behind the records.",
    widget: { kind: "number", unit: "s" },
    codedDefault: "60",
    section: "usage",
  },
  {
    key: "smsg.usage.hourly.lag.seconds",
    label: "Leave the newest",
    hint: "A count stops this far short of now, so records still being written by the call-record lanes are counted next time rather than missed.",
    widget: { kind: "number", unit: "s" },
    codedDefault: "30",
    section: "usage",
  },
  {
    key: "smsg.usage.hourly.restate.minutes",
    label: "Recount recent hours every",
    hint: "Receipts and expiries arrive after their hour has been counted; recent hours are recounted whole this often until they settle. A retried message can read twice until then.",
    widget: { kind: "number", unit: "min" },
    codedDefault: "15",
    section: "usage",
  },
  {
    key: "smsg.usage.hourly.retention.days",
    label: "Keep hourly rows for",
    hint: "Hours older than this are dropped; the daily summary keeps the billing truth for as long as it is kept.",
    widget: { kind: "number" },
    codedDefault: "35",
    section: "usage",
    suffix: "days",
  },
  {
    key: "smsg.usage.daily.schedule",
    label: "Summarise yesterday at",
    hint: "A local time (HH:MM, billing zone) at which the gateway writes yesterday's daily summary itself, so the nightly command is no longer needed. Empty switches the schedule off.",
    widget: { kind: "text", placeholder: "00:15" },
    codedDefault: "00:15",
    section: "usage",
  },
];

/** Fields for one section of the page, in catalogue order. */
export function gatewayFieldsIn(section: GatewaySection): GatewaySettingField[] {
  return GATEWAY_SETTING_FIELDS.filter((f) => f.section === section);
}

//`isEditableGatewayKey` used to live here, and membership of this catalogue was the security
//boundary. It no longer is: the free-form editor means an operator can name a key this catalogue has
//never heard of, so the boundary had to become a thing of its own that can be reasoned about and
//tested. It is `lib/gateway-key-policy.ts`. This file is now what it says on the front -- the keys
//that get a label, a widget and a hint -- and answers no security question at all
