import { test } from "node:test";
import assert from "node:assert/strict";
import {
  describeValue,
  effectiveValue,
  listItems,
  matchesQuery,
  rowState,
  shortOptionLabel,
  splitHint,
} from "./gateway-setting-state.ts";
import { GATEWAY_SECTIONS, GATEWAY_SETTING_FIELDS } from "./gateway-setting-fields.ts";

const on = { value: "true", enabled: true };

test("nothing stored and the gateway agrees: the default", () => {
  assert.deepEqual(rowState({ stored: undefined, draft: undefined, codedDefault: "false", running: { value: "false", tier: "coded_default" } }), { kind: "default" });
  //and with no answer from the gateway at all
  assert.deepEqual(rowState({ stored: undefined, draft: undefined, codedDefault: "false", running: undefined }), { kind: "default" });
});

test("stored and running: set", () => {
  assert.deepEqual(rowState({ stored: on, draft: undefined, codedDefault: "false", running: { value: "true", tier: "memory" } }), { kind: "set" });
});

test("a staged edit is unsaved, and says what it replaces", () => {
  assert.deepEqual(rowState({ stored: undefined, draft: "message", codedDefault: "segment", running: undefined }), { kind: "unsaved", was: "segment" });
  assert.deepEqual(rowState({ stored: { value: "omni", enabled: true }, draft: "", codedDefault: "", running: undefined }), { kind: "unsaved", was: "omni" });
});

test("saved but the gateway still runs the old value: pending, and whether it waits for a restart", () => {
  assert.deepEqual(
    rowState({ stored: { value: "1000", enabled: true }, draft: undefined, codedDefault: "500", running: { value: "500", tier: "memory" }, startup: true }),
    { kind: "pending", running: "500", startup: true }
  );
  //a key deleted here that the gateway has not yet let go of
  assert.deepEqual(
    rowState({ stored: undefined, draft: undefined, codedDefault: "false", running: { value: "true", tier: "memory" } }),
    { kind: "pending", running: "true", startup: false }
  );
});

test("an unverified default is never claimed as a difference", () => {
  assert.deepEqual(rowState({ stored: undefined, draft: undefined, codedDefault: null, running: { value: "0", tier: "coded_default" } }), { kind: "default" });
});

test("the host's environment outranks what is stored", () => {
  assert.deepEqual(rowState({ stored: on, draft: undefined, codedDefault: "false", running: { value: "false", tier: "store" } }), { kind: "host", running: "false" });
});

test("a stored row switched off is shown as such", () => {
  assert.deepEqual(rowState({ stored: { value: "true", enabled: false }, draft: undefined, codedDefault: "false", running: { value: "false", tier: "coded_default" } }), { kind: "disabled" });
});

test("the control shows the staged edit, else the stored value, else the default", () => {
  assert.equal(effectiveValue({ stored: undefined, draft: undefined, codedDefault: "replace" }), "replace");
  assert.equal(effectiveValue({ stored: { value: "assign", enabled: true }, draft: undefined, codedDefault: "replace" }), "assign");
  assert.equal(effectiveValue({ stored: { value: "assign", enabled: true }, draft: "off", codedDefault: "replace" }), "off");
  //a staged clear shows what the gateway will fall back to
  assert.equal(effectiveValue({ stored: { value: "assign", enabled: true }, draft: "", codedDefault: "replace" }), "replace");
  //a disabled row is not what runs
  assert.equal(effectiveValue({ stored: { value: "true", enabled: false }, draft: undefined, codedDefault: "false" }), "false");
});

test("a hint splits after its first sentence, not inside an abbreviation or a number", () => {
  assert.deepEqual(splitHint("Read at startup. The account list takes effect at once."), { lead: "Read at startup.", more: "The account list takes effect at once." });
  assert.deepEqual(splitHint("Waits 0.5 seconds, e.g. for a burst."), { lead: "Waits 0.5 seconds, e.g. for a burst.", more: "" });
  assert.deepEqual(splitHint(undefined), { lead: "", more: "" });
});

test("small helpers", () => {
  assert.equal(shortOptionLabel("Replace — the approved value always wins"), "Replace");
  assert.equal(shortOptionLabel("First 500 characters"), "First 500 characters");
  assert.equal(describeValue("true", "boolean"), "on");
  assert.deepEqual(listItems(" omni, omni2 ,,"), ["omni", "omni2"]);
  assert.ok(matchesQuery("bulk", { key: "smsg.callback.bulk.max", label: "Most receipts" }));
  assert.ok(matchesQuery("RECEIPT", { key: "x", label: "Most receipts" }));
  assert.ok(!matchesQuery("tls", { key: "x", label: "y", hint: "z" }));
});

test("every catalogued field lands in a section the page renders", () => {
  const ids = new Set<string>(GATEWAY_SECTIONS.map((s) => s.id));
  for (const f of GATEWAY_SETTING_FIELDS) {
    assert.ok(ids.has(f.section), `${f.key} is in section '${f.section}', which the page does not render`);
  }
});
