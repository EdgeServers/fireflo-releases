"use client";
import { useCallback, useEffect, useState } from "react";
import type { CoveragePayload } from "@/lib/tlv-coverage-payload";
import type {
  ApprovedHeader,
  ApprovedTemplate,
  HeaderInput,
  TemplateInput,
  WhitelistMode,
  WhitelistSummary,
} from "@/lib/whitelist-types";

/**
 * Approved sender IDs and content, and the modes they are held to.
 *
 * <p>Shaped like `useAccounts`, with one difference that has to be said out loud in the UI rather
 * than only here: **the gateway reads these tables**. Everything else this panel edits under a
 * catalogue heading is inert. A row saved here changes whether a customer's messages are accepted,
 * within one configuration poll.
 *
 * @param account limits the rows fetched; the summaries always cover everybody, because a screen
 *     showing one account's approved list still needs to say whether it is being enforced
 */
/** One object, so a consumer can spread it without four null checks. */
const EMPTY_COVERAGE: CoveragePayload = { mandatory: [], logins: [], vendors: [] };

/** One page of everybody's list, for the Headers and Templates pages; see `/api/control/whitelist/page`. */
export interface WhitelistIndexQuery {
  kind: "headers" | "templates";
  q: string;
  pendingOnly: boolean;
  page: number;
  size: number;
}

/** What a paged read adds: how many rows match, which page was served, and the stamps beside them. */
export interface WhitelistIndexMeta {
  total: number;
  page: number;
  pending: number;
  siblings: { accountId: string; product: string; tlvs: string | null }[];
}

const EMPTY_META: WhitelistIndexMeta = { total: 0, page: 0, pending: 0, siblings: [] };

/**
 * @param index one page of every account's list, filtered and paged by the server, in place of
 *     every row; `account` is then ignored
 */
export function useWhitelist(account?: string, index?: WhitelistIndexQuery) {
  const [headers, setHeaders] = useState<ApprovedHeader[]>([]);
  const [templates, setTemplates] = useState<ApprovedTemplate[]>([]);
  const [summaries, setSummaries] = useState<WhitelistSummary[]>([]);
  //empty until the fetch lands, and empty forever on a deployment where no listener declares a
  //mandatory TLV -- which is most of them, and is why every consumer renders nothing for []
  const [coverage, setCoverage] = useState<CoveragePayload>(EMPTY_COVERAGE);
  //this account's enabled logins, by name. Its own key rather than coverage.logins, which is empty
  //on any deployment where no listener declares a mandatory TLV
  const [logins, setLogins] = useState<string[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");
  const [meta, setMeta] = useState<WhitelistIndexMeta>(EMPTY_META);

  const query = account ? `?account=${encodeURIComponent(account)}` : "";
  //a string, so the caller's fresh object each render does not refetch
  const indexQuery = index
    ? new URLSearchParams({
        kind: index.kind,
        q: index.q,
        page: String(index.page),
        size: String(index.size),
        ...(index.pendingOnly ? { pending: "1" } : {}),
      }).toString()
    : null;

  const load = useCallback(async () => {
    if (indexQuery !== null) {
      try {
        const res = await fetch(`/api/control/whitelist/page?${indexQuery}`, { cache: "no-store" });
        const json = await res.json().catch(() => null);
        if (!res.ok) {
          setError(json?.error ?? `Request failed (${res.status})`);
          return;
        }
        setHeaders(json.data.headers as ApprovedHeader[]);
        setTemplates(json.data.templates as ApprovedTemplate[]);
        setSummaries(json.data.summaries as WhitelistSummary[]);
        setCoverage((json.data.coverage as CoveragePayload) ?? EMPTY_COVERAGE);
        setMeta({
          total: json.data.total, page: json.data.page, pending: json.data.pending,
          siblings: json.data.siblings ?? [],
        });
        setError("");
      } catch (err) {
        setError(err instanceof Error ? err.message : "Request failed");
      } finally {
        setLoading(false);
      }
      return;
    }
    try {
      const [h, t] = await Promise.all([
        fetch(`/api/control/whitelist/headers${query}`, { cache: "no-store" }),
        fetch(`/api/control/whitelist/templates${query}`, { cache: "no-store" }),
      ]);
      const hJson = await h.json().catch(() => null);
      const tJson = await t.json().catch(() => null);
      if (!h.ok || !t.ok) {
        setError(hJson?.error ?? tJson?.error ?? `Request failed (${h.status || t.status})`);
        return;
      }
      setHeaders(hJson.data.headers as ApprovedHeader[]);
      setTemplates(tJson.data.templates as ApprovedTemplate[]);
      setSummaries(hJson.data.summaries as WhitelistSummary[]);
      setCoverage((hJson.data.coverage as CoveragePayload) ?? EMPTY_COVERAGE);
      setLogins((hJson.data.logins as string[]) ?? []);
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setLoading(false);
    }
  }, [query, indexQuery]);

  useEffect(() => {
    load();
  }, [load]);

  /**
   * @param quiet keeps the failure out of the hook-wide `error`, for callers that show it
   *     themselves. Without it a policy refusal appears three times at once — the card-level
   *     `ErrorCard`, and both section footers, which share one message
   */
  const write = useCallback(
    async (
      url: string,
      method: string,
      body?: unknown,
      key = "",
      quiet = false
    ): Promise<{ error: string | null; data: Record<string, unknown> | null }> => {
      setBusy(key || url);
      try {
        const res = await fetch(url, {
          method,
          headers: body ? { "Content-Type": "application/json" } : undefined,
          body: body ? JSON.stringify(body) : undefined,
        });
        const json = await res.json().catch(() => null);
        if (!res.ok) {
          const message = json?.error ?? `Request failed (${res.status})`;
          if (!quiet) {
            setError(message);
          }
          return { error: message, data: null };
        }
        if (!quiet) {
          setError("");
        }
        await load();
        return { error: null, data: (json?.data ?? null) as Record<string, unknown> | null };
      } catch (err) {
        const message = err instanceof Error ? err.message : "Request failed";
        if (!quiet) {
          setError(message);
        }
        return { error: message, data: null };
      } finally {
        setBusy("");
      }
    },
    [load]
  );

  const saveHeader = useCallback(
    async (input: HeaderInput) =>
      (await write("/api/control/whitelist/headers", "PUT", input, input.header)).error,
    [write]
  );

  const saveTemplate = useCallback(
    async (input: TemplateInput) =>
      (await write("/api/control/whitelist/templates", "PUT", input, String(input.id ?? "new")))
        .error,
    [write]
  );

  const removeHeader = useCallback(
    async (id: number) =>
      (await write(`/api/control/whitelist/headers/${id}`, "DELETE", undefined, String(id))).error,
    [write]
  );

  /**
   * The operator's decision on a customer's request.
   *
   * <p>Approving is what puts a row into service -- the gateway serves it only when it is enabled
   * AND approved -- so until this runs a submission is stored and inert. A refusal carries the
   * reason, which is the only thing the customer is shown about the decision.
   */
  const review = useCallback(
    async (kind: "headers" | "templates", id: number, status: "APPROVED" | "REJECTED",
           reviewNote?: string) =>
      (await write(`/api/control/whitelist/${kind}/${id}`, "PATCH", { status, reviewNote },
        String(id))).error,
    [write]
  );

  /**
   * The operator's answer to a customer's proposed stamps.
   *
   * <p>A different decision from {@link review} and deliberately a different call: that one says
   * whether the registration may be used, this one says what it stamps. Accepting is the write on
   * this page with the most direct effect on traffic -- the value goes on the wire at the next
   * configuration poll -- so it is not folded into anything else.
   */
  const decideTlvs = useCallback(
    async (kind: "headers" | "templates", id: number, accept: boolean) =>
      (await write(`/api/control/whitelist/${kind}/${id}/tlvs`, "POST", { accept }, String(id)))
        .error,
    [write]
  );

  const removeTemplate = useCallback(
    async (id: number) =>
      (await write(`/api/control/whitelist/templates/${id}`, "DELETE", undefined, String(id)))
        .error,
    [write]
  );

  /**
   * Changes ONE enforcement mode.
   *
   * <p>Returns the server's refusal rather than only storing it, because the caller needs to keep
   * the operator's selection on screen next to the reason — the commonest refusal is "nothing is
   * approved yet", and that is a thing to go and fix rather than an error to dismiss. It returns the
   * warnings for the same reason: a save that succeeded and stopped some traffic has more to say
   * than a save that succeeded.
   *
   * <p><strong>One mode, not both.</strong> Sending the other one back meant re-submitting a value
   * read from a summary that may be minutes old — so a change to sender IDs could be refused for
   * templates, and could quietly write back a stale content mode on the way. The busy key carries
   * `which` so changing one select does not disable the other.
   */
  const savePolicy = useCallback(
    async (accountId: string, product: string, which: "header" | "content", mode: WhitelistMode) => {
      const result = await write(
        "/api/control/whitelist/policy",
        "PUT",
        { accountId, product, [`${which}Mode`]: mode },
        `${accountId}:${which}`,
        true
      );
      return {
        error: result.error,
        warnings: (result.data?.warnings as string[] | undefined) ?? [],
      };
    },
    [write]
  );

  return {
    headers, templates, summaries, coverage, logins, error, loading, busy, meta,
    load, saveHeader, saveTemplate, removeHeader, removeTemplate, savePolicy, review, decideTlvs,
    setError,
  };
}
