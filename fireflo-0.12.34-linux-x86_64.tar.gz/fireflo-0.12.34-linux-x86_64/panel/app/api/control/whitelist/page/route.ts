import { NextRequest, NextResponse } from "next/server";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { loadCoverage } from "@/lib/tlv-coverage-payload";
import { listWhitelistSummaries, pageWhitelist } from "@/lib/whitelist";

const TABLES = "app_header, app_template and app_whitelist_policy";

/** Rows per page unless the caller asks otherwise; `pageWhitelist` caps it at 200. */
const DEFAULT_SIZE = 25;

/**
 * One page of the Headers or Templates list, every account, filtered and paged in the database.
 *
 * <p>The account page still reads its own account whole through the `headers` and `templates`
 * routes: one customer's list is short, and that page edits it in place. These two pages list
 * everybody's, which is the list that grows without bound.
 *
 * <p>`?kind=headers|templates&page=0&size=25&q=…&pending=1`. The summaries and coverage come back
 * alongside for the reason the list routes send them: a row's Enforced column and its TLV gaps are
 * read from them.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite(TABLES);
  if (refused) {
    return refused;
  }
  const params = req.nextUrl.searchParams;
  const kind = params.get("kind") === "templates" ? "templates" : "headers";
  try {
    const [page, summaries, coverage] = await Promise.all([
      pageWhitelist({
        kind,
        q: params.get("q") ?? "",
        pendingOnly: params.get("pending") === "1",
        page: Number(params.get("page") ?? 0) || 0,
        size: Number(params.get("size") ?? DEFAULT_SIZE) || DEFAULT_SIZE,
      }),
      listWhitelistSummaries(),
      loadCoverage(),
    ]);
    return NextResponse.json({ data: { ...page, summaries, coverage } });
  } catch (err) {
    return configFailed(`approved ${kind}`, err);
  }
}
