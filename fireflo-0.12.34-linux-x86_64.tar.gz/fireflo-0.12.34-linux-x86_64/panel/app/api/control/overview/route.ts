import { controlRoute } from "@/lib/control-route";
import { getOverviewRefresher } from "@/lib/overview-refresher";
import { byReason } from "@/lib/failure-groups";

/**
 * Headline figures, the traffic series and the failure breakdown in one round trip -- from the
 * snapshot the panel keeps in the background, not from the database.
 *
 * <p>`lib/overview-snapshot.ts` says why and how. What the client gets beyond the figures:
 * `asOf`, when the panel last read the database for this range; `stale`, which sections show a
 * previous reading because their last read failed; `source`, whether the rolled part came from
 * the gateway's hourly summary; and `settlingFrom`, from which instant buckets are still receiving
 * receipts (now less `smsg.cdr.deadline.hours`).
 *
 * <p>`failuresSince` is where the breakdown's live read started -- the last 24 hours -- because
 * `usage_daily` has no failure reason and a month of call records is not a 60-second poll. The
 * series and the tile cover the whole range.
 *
 * <p>For an operator at a terminal: `?debug=1` adds the refresher's counters and the tick time
 * (roughly the latency the route used to have), `?fresh=1` rebuilds the range whole before
 * answering. `OVERVIEW_REFRESH_SECONDS=0` builds on every request, which the e2e rig relies on.
 */
export const GET = controlRoute(
  async (range, params) => {
    const refresher = getOverviewRefresher();
    const snap = await refresher.get(range, { fresh: params.get("fresh") === "1" });
    return {
      totals: snap.totals,
      traffic: snap.traffic,
      //the reasons list as it always was -- one row per failure kind, so dismissals keep their key --
      //and the same breakdown per account for the dashboard's failures-by-account ring
      failures: byReason(snap.failures),
      failuresByAccount: snap.failures,
      failuresSince: snap.failuresSince,
      asOf: snap.asOf,
      builtAt: snap.builtAt,
      stale: snap.stale,
      source: snap.source,
      settlingFrom: snap.settlingFrom,
      ...(params.get("debug") === "1" ? { debug: { tickMs: snap.tickMs, ...refresher.debug() } } : {}),
    };
  },
  //the client fetches no-store; this keeps a shared proxy honest about whose figures these are
  { headers: { "Cache-Control": "private, max-age=15" } }
);
