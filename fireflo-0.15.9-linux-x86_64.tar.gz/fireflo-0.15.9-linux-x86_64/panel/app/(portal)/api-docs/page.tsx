import { MisApiDocsClient } from "@/components/MisApiDocsClient";
import { platformExampleMsisdn } from "@/lib/platform-example-number";
import { platformCurrency } from "@/lib/platform-currency";
import { requireCustomer } from "@/lib/require-customer";

export const metadata = { title: "REST API" };

export default async function MisApiDocsPage() {
  //see the playground page: the same value, resolved the same way, so the two surfaces cannot show
  //a customer two different numbers to copy
  const exampleTo = await platformExampleMsisdn().catch(() => null);
  //read fresh, as every route does: "Managing your accounts" is for an account that resells now, not
  //one whose session says it did. The layout has already let this session in, so a failure here
  //only means the section is left off
  const resells = await requireCustomer().then((s) => s.resells).catch(() => false);
  const currency = resells ? await platformCurrency().catch(() => null) : null;
  return <MisApiDocsClient exampleTo={exampleTo} resells={resells} currency={currency} />;
}
