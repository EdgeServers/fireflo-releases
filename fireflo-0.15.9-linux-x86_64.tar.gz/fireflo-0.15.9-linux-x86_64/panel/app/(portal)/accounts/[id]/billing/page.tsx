import { AccountBillingClient } from "@/components/AccountBillingClient";

/**
 * One account's credit terms (prepaid or postpaid, credit on or off) and its ledger -- the "Credit
 * terms" tab since 0.15.8; recharge and withdraw moved to the Balance tab.
 *
 * <p>The operator panel's own component, unchanged: everything it renders comes from
 * `useAccountContext`, and the portal's context route already withholds the two fields that are not
 * a reseller's — the rate scopes and the carriers. There is nothing left in it to gate.
 *
 * <p>A reseller funds its children, so a child's balance and the transfers behind it are exactly
 * what this tab is for.
 */
export default async function PortalAccountBillingPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return <AccountBillingClient id={decodeURIComponent(id)} />;
}
