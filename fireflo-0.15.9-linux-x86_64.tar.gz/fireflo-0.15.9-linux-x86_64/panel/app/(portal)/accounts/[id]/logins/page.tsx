import { MisSubAccountLoginsClient } from "@/components/MisSubAccountLoginsClient";

/**
 * Who may connect as this sub-account: per login, enabled, allowed IPs, session limits and a new
 * password; speed and message types read-only; and adding an SMPP or HTTP login.
 *
 * <p>The portal's own component since 0.15.8, over `/api/mis/sub-accounts/{id}/logins`. Product,
 * allowed products and the TPS limit stay the platform's: the route refuses them by name.
 */
export default function PortalAccountLoginsPage() {
  return <MisSubAccountLoginsClient />;
}
