import { MisSubAccountBalanceClient } from "@/components/MisSubAccountBalanceClient";

/**
 * A sub-account's landing tab: its balance, recharge and withdraw, and the transfers between this
 * reseller and it. The scope check is in the layout above, and in every route the page calls.
 */
export default function PortalSubAccountBalancePage() {
  return <MisSubAccountBalanceClient />;
}
