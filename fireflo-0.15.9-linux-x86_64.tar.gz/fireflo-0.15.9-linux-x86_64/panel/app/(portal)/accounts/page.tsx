import { notFound } from "next/navigation";
import { MisSubAccountsClient } from "@/components/MisSubAccountsClient";
import { NotCustomerError, requireReseller } from "@/lib/require-customer";
import { portalBrand } from "@/lib/brand";

/**
 * The accounts this reseller holds: the portal's own sub-accounts list (0.15.8, the approved
 * mockup), with balance, state, logins and recent sending, over `/api/mis/sub-accounts` -- the
 * portal's mirror of the gateway's reseller API. It replaced the operator's account table here.
 *
 * <p><strong>A non-reseller gets a 404 rather than an empty table.</strong> An empty page reads as
 * "you have no customers yet" and invites somebody to look for the button that adds one; the
 * `notFound` says the page is not theirs, which is true, and matches what every route beneath it
 * answers. The nav does not offer the link either, so reaching this at all means typing the URL.
 */
export function generateMetadata() {
  return { title: `Sub-accounts — ${portalBrand()}` };
}

export default async function PortalAccountsPage() {
  try {
    await requireReseller();
  } catch (err) {
    if (err instanceof NotCustomerError) {
      notFound();
    }
    throw err;
  }
  return <MisSubAccountsClient />;
}
