import { notFound } from "next/navigation";
import { MisNewSubAccountClient } from "@/components/MisNewSubAccountClient";
import { NotCustomerError, requireReseller } from "@/lib/require-customer";
import { portalBrand } from "@/lib/brand";

/**
 * New sub-account: id, name and an opening credit, and its HTTP login's password shown once.
 *
 * <p>A static segment, so it wins over `[id]`; `childIdProblem` reserves the id `new` for that
 * reason. A non-reseller gets the same 404 as the list.
 */
export function generateMetadata() {
  return { title: `New sub-account — ${portalBrand()}` };
}

export default async function PortalNewSubAccountPage() {
  try {
    await requireReseller();
  } catch (err) {
    if (err instanceof NotCustomerError) {
      notFound();
    }
    throw err;
  }
  return <MisNewSubAccountClient />;
}
