import { NextRequest, NextResponse } from "next/server";
import { notFoundOrThrow } from "@/lib/mis-route";
import { requireReseller } from "@/lib/require-customer";
import { childIdProblem } from "@/lib/mis-account-rules";
import { parseSubAccountCreate } from "@/lib/reseller-rules";
import { takenAccountIds } from "@/lib/mis-accounts";
import { createSubAccount, listSubAccounts, POLL_SECONDS } from "@/lib/reseller-accounts";
import { actorOf, auditChild, jsonBody, refusal } from "@/lib/mis-sub-account-route";

/**
 * GET|POST /api/mis/sub-accounts -- the portal's mirror of `GET|POST /secure/accounts` (0.15.8).
 *
 * <p>GET: this reseller's sub-accounts with balance, state, logins and recent sending, plus its own
 * balance for "Available". POST: creates one with its balance row, one HTTP login (password
 * returned once) and an optional opening credit moved from the reseller (402 when it cannot cover
 * it). 404 to an account that does not resell.
 */
export async function GET(): Promise<NextResponse> {
  try {
    const session = await requireReseller();
    return NextResponse.json({ data: await listSubAccounts(session.accountId) });
  } catch (err) {
    return notFoundOrThrow(err);
  }
}

export async function POST(req: NextRequest): Promise<NextResponse> {
  let session;
  try {
    session = await requireReseller();
  } catch (err) {
    return notFoundOrThrow(err);
  }
  const body = await jsonBody(req);
  if (body instanceof NextResponse) {
    return body;
  }
  const parsed = parseSubAccountCreate(body);
  if (!parsed.ok) {
    return refusal(parsed);
  }
  const problem = childIdProblem(parsed.value.id, await takenAccountIds());
  if (problem) {
    //taken is a 409, as the API answers it; a malformed id is a 400
    return NextResponse.json({ error: problem }, { status: /already in use/.test(problem) ? 409 : 400 });
  }

  const created = await createSubAccount(session.accountId, parsed.value, await actorOf(session));
  if (!created.ok) {
    return refusal(created);
  }
  await auditChild(session, "child_created", {
    child: created.id, login: created.login.systemId, opening: created.opening?.amount ?? 0,
  });
  return NextResponse.json({
    data: {
      id: created.id,
      label: parsed.value.label,
      currency: created.currency,
      //returned here and never again: nothing can read it back out of the database
      login: created.login,
      opening: created.opening,
      propagationSeconds: POLL_SECONDS,
    },
  }, { status: 201 });
}
