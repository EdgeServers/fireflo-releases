import { NextRequest, NextResponse } from "next/server";
import { parseTransfer } from "@/lib/reseller-rules";
import { queueTransfer } from "@/lib/reseller-accounts";
import { actorOf, auditChild, childFor, jsonBody, refusal } from "@/lib/mis-sub-account-route";

type Params = { params: Promise<{ id: string }> };

/**
 * POST /api/mis/sub-accounts/{id}/recharge -- the portal's mirror of the API's
 * `POST /secure/accounts/{id}/recharge`.
 *
 * <p>Moves `amount` from the reseller to the child: a transfer down. Only the platform creates money,
 * so this is the only way a reseller funds a child. 402 when the reseller cannot cover it now.
 *
 * <p>Body: `amount` (a decimal string, at most four places), optional `reference`, and
 * `idempotencyKey` (a UUID the page made when the form opened): the same key twice is one transfer,
 * answered with the original id. A suspended or archived child is 409. Answers 202 with the
 * transfer id: the gateway applies it on its next poll, which the route nudges to run now.
 *
 * <p>Audited as `child_transfer` (gateway V1.128.0), or `child_credit_changed` with
 * `detail.event` on an older database.
 */
export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const ctx = await childFor(params);
  if (ctx instanceof NextResponse) {
    return ctx;
  }
  const body = await jsonBody(req);
  if (body instanceof NextResponse) {
    return body;
  }
  const parsed = parseTransfer(body);
  if (!parsed.ok) {
    return refusal(parsed);
  }
  const result = await queueTransfer(ctx.session.accountId, ctx.child, "recharge", parsed.value, await actorOf(ctx.session));
  if (!result.ok) {
    return refusal(result);
  }
  if (!result.duplicate) {
    await auditChild(ctx.session, "child_transfer", {
      child: ctx.child, kind: "recharge", amount: parsed.value.amount, transfer: result.transferId,
    }, "child_credit_changed");
  }
  return NextResponse.json({
    data: {
      transferId: result.transferId,
      duplicate: result.duplicate,
      problem: result.problem ?? null,
      message: result.duplicate
        ? "Already done: this is the transfer you made a moment ago, not a second one."
        : "Queued. The gateway applies it within seconds.",
    },
  }, { status: 202 });
}
