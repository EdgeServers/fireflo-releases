import { NextRequest, NextResponse } from "next/server";
import { listTransfers } from "@/lib/reseller-accounts";
import { childFor } from "@/lib/mis-sub-account-route";

type Params = { params: Promise<{ id: string }> };

/**
 * GET /api/mis/sub-accounts/{id}/transfers -- the portal's mirror of the API's
 * `GET /secure/accounts/{id}/transfers`: the recharges, withdrawals and opening credit between this
 * reseller and the child, newest first, signed from the child's side.
 */
export async function GET(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const ctx = await childFor(params);
  if (ctx instanceof NextResponse) {
    return ctx;
  }
  return NextResponse.json({ data: { transfers: await listTransfers(ctx.session.accountId, ctx.child) } });
}
