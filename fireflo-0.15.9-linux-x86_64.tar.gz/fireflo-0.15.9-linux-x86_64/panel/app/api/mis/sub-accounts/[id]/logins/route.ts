import { NextRequest, NextResponse } from "next/server";
import { parseNewLogin } from "@/lib/reseller-rules";
import { createSubAccountLogin, getSubAccount, listSubAccountLogins, nudgeConfig, POLL_SECONDS } from "@/lib/reseller-accounts";
import { auditChild, childFor, jsonBody, notFound, refusal } from "@/lib/mis-sub-account-route";

type Params = { params: Promise<{ id: string }> };

/**
 * GET|POST /api/mis/sub-accounts/{id}/logins -- the portal's mirror of the API's
 * `GET|POST /secure/accounts/{id}/logins`.
 *
 * <p>GET lists the logins billing to the child, with no secret. POST adds an SMPP or HTTP login: a
 * chosen name (SMPP at most 15 characters) checked free across every login and vendor, or a generated
 * one; allowed IPs (at most 50); SMPP session limits. The password is generated and in this answer
 * only. Speed, products and secrets in the body are refused.
 */
export async function GET(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const ctx = await childFor(params);
  if (ctx instanceof NextResponse) {
    return ctx;
  }
  return NextResponse.json({ data: { logins: await listSubAccountLogins(ctx.child) } });
}

export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const ctx = await childFor(params);
  if (ctx instanceof NextResponse) {
    return ctx;
  }
  const body = await jsonBody(req);
  if (body instanceof NextResponse) {
    return body;
  }
  const parsed = parseNewLogin(body);
  if (!parsed.ok) {
    return refusal(parsed);
  }
  const account = await getSubAccount(ctx.session.accountId, ctx.child);
  if (!account) {
    return notFound();
  }
  if (account.archived) {
    return NextResponse.json({ error: `${ctx.child} is archived; it can't take new logins.` }, { status: 409 });
  }

  const created = await createSubAccountLogin(ctx.child, parsed.value);
  if (!created.ok) {
    return refusal(created);
  }
  //what was made and where; never the password
  await auditChild(ctx.session, "child_login_created", {
    child: ctx.child, login: created.systemId, type: created.type, chosen: parsed.value.systemId != null,
  });
  const adopted = await nudgeConfig();
  return NextResponse.json({
    data: {
      id: created.id,
      type: created.type,
      systemId: created.systemId,
      password: created.password,
      //a suspended account's new login is stored enabled but cannot connect until it is resumed
      suspended: !account.enabled,
      propagationSeconds: adopted ? 0 : POLL_SECONDS,
    },
  }, { status: 201 });
}
