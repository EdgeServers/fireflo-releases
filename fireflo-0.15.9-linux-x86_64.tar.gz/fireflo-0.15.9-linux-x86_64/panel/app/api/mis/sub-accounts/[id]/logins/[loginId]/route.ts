import { NextRequest, NextResponse } from "next/server";
import { rowId } from "@/lib/mis-route";
import { parseLoginPatch } from "@/lib/reseller-rules";
import { listSubAccountLogins, nudgeConfig, POLL_SECONDS, updateSubAccountLogin } from "@/lib/reseller-accounts";
import { auditChild, childFor, jsonBody, notFound, refusal } from "@/lib/mis-sub-account-route";

type Params = { params: Promise<{ id: string; loginId: string }> };

/**
 * PATCH /api/mis/sub-accounts/{id}/logins/{loginId} -- the portal's mirror of the API's
 * `PATCH /secure/accounts/{id}/logins/{loginId}`: enabled, allowed IPs, session limits.
 *
 * <p>Product, allowed products and `maxTps` answer 400 "set by your platform"; a name, kind or
 * secret in the body is refused too. Switching an SMPP login off drops its open binds.
 *
 * <p>Audited as `child_login_updated` (gateway V1.128.0); on an older database the row lands as
 * `child_login_toggled` with `detail.event` naming it -- see `recordCustomerAccess`'s `fallback`.
 */
export async function PATCH(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const ctx = await childFor(params);
  if (ctx instanceof NextResponse) {
    return ctx;
  }
  const loginId = rowId((await params).loginId);
  if (loginId === null) {
    return notFound();
  }
  const body = await jsonBody(req);
  if (body instanceof NextResponse) {
    return body;
  }
  const stored = (await listSubAccountLogins(ctx.child)).find((l) => l.id === loginId);
  if (!stored) {
    return notFound();
  }
  const parsed = parseLoginPatch(body, stored.type);
  if (!parsed.ok) {
    return refusal(parsed);
  }

  const result = await updateSubAccountLogin(ctx.child, loginId, parsed.value);
  if (!result.ok) {
    return notFound();
  }
  await auditChild(ctx.session, "child_login_updated", {
    child: ctx.child,
    login: result.login.systemId ?? `#${loginId}`,
    changed: result.changed,
    enabled: result.login.enabled,
    dropped: result.dropped,
  }, "child_login_toggled");
  const adopted = await nudgeConfig();
  return NextResponse.json({
    data: {
      login: result.login,
      disconnected: result.dropped,
      problem: result.problem,
      propagationSeconds: adopted ? 0 : POLL_SECONDS,
    },
  });
}
