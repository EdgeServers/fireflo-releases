import { NextRequest, NextResponse } from "next/server";
import { rowId } from "@/lib/mis-route";
import { newLoginPassword, nudgeConfig, POLL_SECONDS } from "@/lib/reseller-accounts";
import { auditChild, childFor, notFound } from "@/lib/mis-sub-account-route";

type Params = { params: Promise<{ id: string; loginId: string }> };

/**
 * POST /api/mis/sub-accounts/{id}/logins/{loginId}/password -- the portal's mirror of the API's
 * `POST /secure/accounts/{id}/logins/{loginId}/password`.
 *
 * <p>A new generated password (8 characters for SMPP, the wire field's limit), in this answer only;
 * no body is read, so no password can be chosen. The old one stops working when the gateway adopts
 * the change -- at once when the reload below lands, else within {@link POLL_SECONDS}.
 */
export async function POST(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const ctx = await childFor(params);
  if (ctx instanceof NextResponse) {
    return ctx;
  }
  const loginId = rowId((await params).loginId);
  if (loginId === null) {
    return notFound();
  }
  const issued = await newLoginPassword(ctx.child, loginId);
  if (!issued.ok) {
    return notFound();
  }
  //which login, never the value
  await auditChild(ctx.session, "child_login_updated", {
    child: ctx.child, login: issued.systemId ?? `#${loginId}`, changed: ["password"],
  }, "child_login_toggled");
  const adopted = await nudgeConfig();
  return NextResponse.json({
    data: {
      systemId: issued.systemId,
      password: issued.password,
      propagationSeconds: adopted ? 0 : POLL_SECONDS,
    },
  });
}
