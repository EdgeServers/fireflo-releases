import { NextRequest, NextResponse } from "next/server";
import { resumeChild, suspendChild, updateChild } from "@/lib/mis-accounts";
import { getSubAccount, POLL_SECONDS } from "@/lib/reseller-accounts";
import { refusedFieldProblem } from "@/lib/reseller-rules";
import { auditChild, childFor, jsonBody, notFound } from "@/lib/mis-sub-account-route";

type Params = { params: Promise<{ id: string }> };

/**
 * GET|PATCH /api/mis/sub-accounts/{id} -- the portal's mirror of `GET|PATCH /secure/accounts/{id}`.
 *
 * <p>GET: one sub-account with balance, reserved, this month's spend and the reseller's own balance.
 * PATCH: `label` (rename) and `enabled` (suspend or resume -- logins off, binds dropped, unlisted; or
 * the reverse). An archived account answers 409: an operator archived it and only an operator brings
 * it back. Anything else in the body is refused rather than ignored.
 */
export async function GET(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const ctx = await childFor(params);
  if (ctx instanceof NextResponse) {
    return ctx;
  }
  const account = await getSubAccount(ctx.session.accountId, ctx.child);
  return account ? NextResponse.json({ data: account }) : notFound();
}

export async function PATCH(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const ctx = await childFor(params);
  if (ctx instanceof NextResponse) {
    return ctx;
  }
  const body = await jsonBody(req);
  if (body instanceof NextResponse) {
    return body;
  }
  const refused = refusedFieldProblem(body);
  if (refused) {
    return NextResponse.json({ error: refused }, { status: 400 });
  }
  const unknown = Object.keys(body).filter((k) => k !== "label" && k !== "enabled");
  if (unknown.length) {
    return NextResponse.json(
      { error: `'${unknown[0]}' can't be changed here. A sub-account takes a name and enabled.` },
      { status: 400 }
    );
  }
  const wantsLabel = Object.prototype.hasOwnProperty.call(body, "label");
  const wantsEnabled = Object.prototype.hasOwnProperty.call(body, "enabled");
  if (!wantsLabel && !wantsEnabled) {
    return NextResponse.json({ error: "Nothing to change. Send label or enabled." }, { status: 400 });
  }
  if (wantsEnabled && typeof body.enabled !== "boolean") {
    return NextResponse.json({ error: "'enabled' is true or false." }, { status: 400 });
  }
  if (wantsLabel && body.label !== null && typeof body.label !== "string") {
    return NextResponse.json({ error: "'label' is text." }, { status: 400 });
  }

  const { session, child } = ctx;
  const current = await getSubAccount(session.accountId, child);
  if (!current) {
    return notFound();
  }
  if (current.archived) {
    return NextResponse.json(
      { error: `${child} is archived. Your platform archived it, and only they can bring it back.` },
      { status: 409 }
    );
  }

  let message = "Saved.";
  if (wantsLabel) {
    const label = typeof body.label === "string" && body.label.trim() ? body.label.trim().slice(0, 200) : null;
    await updateChild(session.accountId, { id: child, label, description: null, email: null, enabled: true },
      { label: true, description: false, email: false });
    await auditChild(session, "child_updated", { child, label });
  }
  if (wantsEnabled && body.enabled !== current.enabled) {
    if (body.enabled) {
      const logins = await resumeChild(session.accountId, child);
      await auditChild(session, "child_resumed", { child, logins });
      message = logins
        ? `Resumed. ${logins} login${logins === 1 ? "" : "s"} can connect again within ${POLL_SECONDS} seconds.`
        : "Resumed. It had no logins to switch back on.";
    } else {
      const result = await suspendChild(session.accountId, child);
      await auditChild(session, "child_suspended", { child, logins: result.logins, dropped: result.dropped });
      message = !result.logins
        ? "Suspended. It had no enabled logins, so nothing was sending."
        : result.problem
          ? `Suspended: ${result.logins} login${result.logins === 1 ? "" : "s"} switched off, but open connections `
            + `could not be dropped (${result.problem}); they may keep sending for up to ${POLL_SECONDS} seconds.`
          : `Suspended: ${result.logins} login${result.logins === 1 ? "" : "s"} switched off and `
            + `${result.dropped} open connection${result.dropped === 1 ? "" : "s"} dropped.`;
    }
  }
  const after = await getSubAccount(session.accountId, child);
  return NextResponse.json({ data: { account: after, message } });
}
