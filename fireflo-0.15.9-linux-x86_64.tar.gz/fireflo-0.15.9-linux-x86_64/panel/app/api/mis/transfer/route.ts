import { NextRequest, NextResponse } from "next/server";
import { assertInScope, NotCustomerError, requireCustomer } from "@/lib/require-customer";
import { parseTransfer } from "@/lib/reseller-rules";
import { queueTransfer } from "@/lib/reseller-accounts";
import { actorOf, auditChild } from "@/lib/mis-sub-account-route";

/**
 * Moves prepaid balance between a reseller and one of its own accounts.
 *
 * <p>Direction is the caller's, and it is not a special case in the code: pushing down writes a row
 * paying from the reseller, pulling up writes one paying from the child. The gateway applies both
 * with the same statements and the same sufficiency guard.
 *
 * <h2>What this does not do</h2>
 *
 * <p><strong>It does not move any money.</strong> It writes an unapplied `TRANSFER` row and returns.
 * `account_balance` has exactly one writer — the gateway — and it debits with `WHERE balance >= ?`
 * so that sufficiency is decided by the statement that moves the money rather than by a read taken
 * here, milliseconds before the child's traffic spends the difference.
 *
 * <p>So the honest answer to the caller is "queued", and the interface says within a minute rather
 * than pretending the balance has already changed. A transfer that cannot be applied stays pending
 * and the gateway names it in a warning.
 *
 * <h2>Replays, and why the key is namespaced</h2>
 *
 * <p>Every request carries a `ref`, and `uq_balance_ledger_ref` makes a repeat of the same one a
 * conflict rather than a second transfer. Without it a double-submitted form queued two independent
 * rows — bounded by the gateway's sufficiency check, so not value creation, but the operator's
 * top-up path has had this guard since it was written and the asymmetry was accidental.
 *
 * <p>The key is **namespaced and shape-checked** rather than taken as free text, which closes a
 * second and quieter hole: that index is shared with operator top-ups, whose refs are typed by hand
 * (`INV-2024-001`). A customer free to claim any string could sit on the references an operator
 * would later want, and the operator would meet a duplicate-reference error with no explanation.
 *
 * <h2>0.15.8: the sub-account pages' rules</h2>
 *
 * <p>The write is now `queueTransfer` in `lib/reseller-accounts.ts`, the same one
 * `/api/mis/sub-accounts/{id}/recharge` and `/withdraw` use: a suspended or archived child is 409, a
 * push the reseller cannot cover is 402, a pull first asks the gateway to release the child's held
 * credit, and a repeated `ref` answers the original transfer rather than a 409.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  let session;
  try {
    session = await requireCustomer();
  } catch (err) {
    if (err instanceof NotCustomerError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  if (!session.resells) {
    //not a 403: an account that does not resell has no business knowing this endpoint exists
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const child = typeof body.accountId === "string" ? body.accountId.trim() : "";
  const direction = body.direction === "up" ? "up" : "down";

  //the id came from the request, so it is checked against the session's own children before it is
  //used for anything. This is the line that stops a reseller funding itself from a stranger
  try {
    await assertInScope(session, child);
  } catch (err) {
    if (err instanceof NotCustomerError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  if (child === session.accountId) {
    return NextResponse.json({ error: "Choose one of your accounts to move balance to." }, { status: 400 });
  }

  const parsed = parseTransfer(body);
  if (!parsed.ok) {
    return NextResponse.json({ error: parsed.error }, { status: parsed.status });
  }
  const kind = direction === "down" ? "recharge" : "withdraw";
  const result = await queueTransfer(session.accountId, child, kind, parsed.value, await actorOf(session));
  if (!result.ok) {
    return NextResponse.json({ error: result.error }, { status: result.status });
  }
  if (!result.duplicate) {
    await auditChild(session, "child_transfer", {
      child, kind, amount: parsed.value.amount, transfer: result.transferId,
    }, "child_credit_changed");
  }

  return NextResponse.json({
    data: {
      queued: true,
      transferId: result.transferId,
      duplicate: result.duplicate,
      from: direction === "down" ? session.accountId : child,
      to: direction === "down" ? child : session.accountId,
      problem: result.problem ?? null,
      message: result.duplicate
        ? "That transfer has already been queued."
        : "Queued. The gateway applies it within a minute, and refuses it if the paying account no "
          + "longer has enough.",
    },
  });
}
