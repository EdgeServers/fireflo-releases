import { NextRequest, NextResponse } from "next/server";
import { notFoundOrThrow } from "@/lib/mis-route";
import { assertInScope, requireReseller, scopeFor } from "@/lib/require-customer";
import { recordCustomerAccess } from "@/lib/customer-access-log";
import { requestContext } from "@/lib/request-context";
import { createLogin, listChildLogins, POLL_SECONDS } from "@/lib/mis-logins";
import { parseNewLogin } from "@/lib/reseller-rules";

/**
 * GET|POST /api/mis/credentials — the logins on this reseller's accounts, and creating one.
 *
 * <p>Path and envelope mirror `app/api/control/credentials/route.ts` so `useCredentials` swaps only
 * its base — see `lib/panel-surface.ts`. `context` comes back with **empty products**, which is not
 * a stub either: the reseller cannot set a product on a login, so there is no catalogue to offer,
 * and `conflicts` is empty because naming another customer's lookup key is refused by the writer
 * rather than warned about here. Sending the real conflict list would hand one customer the login
 * names of every other.
 *
 * <p>**404 and never 403** to an account that does not resell.
 */
export async function GET(): Promise<NextResponse> {
  try {
    const session = await requireReseller();
    const scope = await scopeFor(session);
    //the reseller's own logins are in here too. It cannot create or disable one -- those go through
    //the child routes -- but leaving them out would make the operator's shared list read as though
    //the reseller had none
    const credentials = await listChildLogins(scope);
    return NextResponse.json({
      data: { credentials, context: { products: [], disabledProducts: [], conflicts: [] } },
    });
  } catch (err) {
    return notFoundOrThrow(err);
  }
}

/**
 * Creates one login on one of this reseller's accounts.
 *
 * <p>The account is named in the body and goes through `assertInScope` before anything is written —
 * the rule `lib/require-customer.ts` exists for. It is then passed to the writer as an argument, so
 * no field of the request body can reach `account_id`.
 *
 * <p><strong>The secret is generated and returned exactly once.</strong> No secret is accepted: a
 * chosen secret is one that has been typed into a form, pasted into a chat and reused from somewhere
 * else. The value is in this response body and nowhere else — not logged, not in the audit row, and
 * not readable back through any projection this panel has.
 *
 * <p>Read through `parseNewLogin` (0.15.8), the same rules as `/api/mis/sub-accounts/{id}/logins`:
 * `product`, `allowedProducts`, `maxTps` and any secret in the body are refused with 400 rather than
 * ignored; allowed IPs past 50 are refused rather than cut short; an HTTP login gets a password.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  let session;
  try {
    session = await requireReseller();
  } catch (err) {
    return notFoundOrThrow(err);
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }

  const account = typeof body.accountId === "string" ? body.accountId.trim() : "";
  if (!account) {
    return NextResponse.json(
      { error: "Name which of your accounts this login is for." },
      { status: 400 }
    );
  }
  if (account === session.accountId) {
    //deliberately refused rather than quietly allowed. This surface is for the accounts beneath a
    //reseller; a reseller's own logins stay the operator's to create, and the reseller rotates them
    return NextResponse.json(
      {
        error: "This creates logins for the accounts beneath you. Ask your account manager for a "
          + "login on your own account.",
      },
      { status: 400 }
    );
  }
  try {
    await assertInScope(session, account);
  } catch (err) {
    return notFoundOrThrow(err);
  }

  const parsed = parseNewLogin(body);
  if (!parsed.ok) {
    return NextResponse.json({ error: parsed.error }, { status: parsed.status });
  }
  const result = await createLogin(account, parsed.value);
  if (!result.ok) {
    return NextResponse.json({ error: result.problem }, { status: result.status ?? 400 });
  }

  const ctx = await requestContext();
  //what was created and on which account. Never the value -- a log that carried it would be a
  //better target than the table the secret lives in
  void recordCustomerAccess({
    event: "child_login_created",
    accountId: session.accountId,
    ip: ctx.ip,
    userAgent: ctx.userAgent,
    detail: { child: account, login: result.id, kind: result.secretKind },
  });

  return NextResponse.json({
    data: {
      id: result.id,
      secret: result.secret,
      secretKind: result.secretKind,
      username: result.username,
      //stated rather than left to be discovered. The gateway polls for credential changes, so a
      //customer who configures this immediately is refused and reasonably concludes it did not work
      propagationSeconds: POLL_SECONDS,
    },
  });
}
