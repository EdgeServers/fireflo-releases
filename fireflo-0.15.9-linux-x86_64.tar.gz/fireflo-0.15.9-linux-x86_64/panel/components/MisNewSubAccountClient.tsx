"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Button, buttonClasses } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SettingsRow, SettingsRows } from "@/components/ui/settings-row";
import { BackLink } from "./BackLink";
import { CopyButton } from "./CopyButton";
import { ErrorNote } from "./FormNotices";
import { money } from "@/lib/format";
import { parseAmount } from "@/lib/balance-types";
import { childIdProblem } from "@/lib/mis-account-rules";
import { misJson } from "./useSubAccount";
import type { SubAccountList } from "@/lib/reseller-accounts";

interface Created {
  id: string;
  label: string | null;
  currency: string;
  login: { id: number; systemId: string; type: "HTTP"; password: string };
  opening: { amount: number; transferId: number } | null;
}

/**
 * New sub-account: id, name and an opening credit moved from the reseller's balance, and -- once it
 * exists -- its HTTP login's password, shown once beside the form (the approved mockup's screen 2).
 *
 * <p>The id's shape is checked as it is typed with the server's own rule (`childIdProblem`), without
 * the "taken" half, which only the server can answer; it says "Available" only after a create
 * succeeds, not before, so it never promises an id somebody else might take first.
 */
export function MisNewSubAccountClient() {
  const [id, setId] = useState("");
  const [label, setLabel] = useState("");
  const [opening, setOpening] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [created, setCreated] = useState<Created | null>(null);
  const [self, setSelf] = useState<SubAccountList["self"]>(null);

  useEffect(() => {
    misJson<SubAccountList>("/api/mis/sub-accounts").then((d) => setSelf(d.self)).catch(() => undefined);
  }, []);

  const idProblem = id ? childIdProblem(id, []) : null;
  const scaled = opening.trim() ? parseAmount(opening) : 0;
  const amountProblem = scaled === null || (scaled ?? 0) < 0
    ? "An amount of zero or more, with at most four decimal places."
    : null;
  const currency = self?.currency ?? created?.currency ?? "";
  const after = useMemo(
    () => (self && scaled != null ? self.spendable - scaled : null),
    [self, scaled]
  );

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (idProblem || amountProblem || !id) {
      setError(idProblem ?? amountProblem ?? "An account id is required.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const made = await misJson<Created>("/api/mis/sub-accounts", {
        method: "POST",
        body: JSON.stringify({ id, label: label.trim() || null, opening: opening.trim() || "0" }),
      });
      setCreated(made);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-5">
      <div className="space-y-2">
        <BackLink href="/accounts">Sub-accounts</BackLink>
        <h1 className="text-page max-sm:text-entity">New sub-account</h1>
      </div>

      <div className="flex flex-wrap items-start gap-7">
        <form onSubmit={submit} className="min-w-0 flex-[1_1_520px] space-y-5">
          <SettingsRows as="fieldset" disabled={busy || !!created} className="bg-card">
            <SettingsRow
              label="Account id"
              htmlFor="new-id"
              help="Letters, digits, dot, dash, underscore. Can't be changed later."
              tone={idProblem ? "invalid" : undefined}
            >
              <div className="space-y-1.5">
                <Input
                  id="new-id"
                  value={id}
                  onChange={(e) => { setId(e.target.value); setError(""); }}
                  className="font-mono"
                  autoComplete="off"
                  spellCheck={false}
                  maxLength={64}
                  required
                />
                {idProblem
                  ? <p className="text-xs text-destructive">{idProblem}</p>
                  : created && <p className="text-xs text-success">Created</p>}
              </div>
            </SettingsRow>
            <SettingsRow label="Name" htmlFor="new-label" help="What you and the customer see.">
              <Input id="new-label" value={label} onChange={(e) => setLabel(e.target.value)} maxLength={200} />
            </SettingsRow>
            <SettingsRow
              label="Opening credit"
              htmlFor="new-opening"
              help="Moved from your balance now. Leave 0 to recharge later."
              tone={amountProblem ? "invalid" : undefined}
            >
              <div className="space-y-1.5">
                <div className="flex items-center rounded-md border border-input bg-card focus-within:ring-1 focus-within:ring-ring">
                  {currency && <span className="pl-3 text-sm text-muted-foreground">{currency}</span>}
                  <input
                    id="new-opening"
                    value={opening}
                    onChange={(e) => { setOpening(e.target.value); setError(""); }}
                    inputMode="decimal"
                    placeholder="0.00"
                    className="h-11 min-w-0 flex-1 bg-transparent px-3 text-sm tabular-nums outline-none disabled:cursor-not-allowed disabled:opacity-50 md:h-9"
                  />
                </div>
                {amountProblem
                  ? <p className="text-xs text-destructive">{amountProblem}</p>
                  : after != null && (
                    <p className={after < 0 ? "text-xs text-destructive" : "text-xs text-muted-foreground"}>
                      Your balance after: {money(after, currency)}
                    </p>
                  )}
              </div>
            </SettingsRow>
          </SettingsRows>

          <p className="text-sm text-muted-foreground">
            It gets one HTTP login (for the REST API) straight away. Add SMPP logins on its Logins tab.
            Prices are your platform&apos;s; a sub-account can&apos;t resell.
          </p>
          <ErrorNote error={error} />
          {!created && (
            <div className="flex gap-2.5">
              <Button type="submit" disabled={busy}>{busy ? "Creating…" : "Create sub-account"}</Button>
              <Link href="/accounts" className={buttonClasses({ variant: "outline" })}>Cancel</Link>
            </div>
          )}
        </form>

        {created && <CreatedCard created={created} />}
      </div>
    </div>
  );
}

/**
 * The one time the HTTP password exists outside the gateway's configuration. Nothing stores it in a
 * form the panel can read back; leaving the page loses it, and the card says so.
 */
function CreatedCard({ created }: { created: Created }) {
  const name = created.label || created.id;
  const href = `/accounts/${encodeURIComponent(created.id)}`;
  return (
    <aside aria-label="Created" className="min-w-0 flex-[1_1_320px] space-y-3.5 rounded-xl border border-foreground bg-card p-5">
      <p className="text-xs text-muted-foreground">Created</p>
      <h2 className="text-title">{name} is ready</h2>
      <dl className="grid grid-cols-2 gap-x-3 gap-y-2 text-sm">
        <dt className="text-muted-foreground">HTTP login</dt>
        <dd className="font-mono">{created.login.systemId}</dd>
        <dt className="text-muted-foreground">Password</dt>
        <dd className="flex items-center gap-1 font-mono">
          <span className="break-all">{created.login.password}</span>
          <CopyButton value={created.login.password} label="Copy password" />
        </dd>
        <dt className="text-muted-foreground">Opening credit</dt>
        <dd className="tabular-nums">
          {created.opening ? `${money(created.opening.amount, created.currency)}, applied within seconds` : "None"}
        </dd>
      </dl>
      <div className="rounded-md bg-warning-soft px-3 py-2.5 text-sm text-warning">
        Copy the password now. It&apos;s shown once; you can set a new one later, never see this one again.
      </div>
      <div className="flex flex-wrap gap-2.5">
        <Link href={href} className={buttonClasses({ variant: "outline" })}>Open {name}</Link>
        <Link href={`${href}/logins`} className={buttonClasses()}>Add an SMPP login</Link>
      </div>
    </aside>
  );
}
