"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { BackLink } from "./BackLink";
import { PendingUnderline } from "./PendingMark";
import { ErrorNote } from "./FormNotices";
import { useConfirmChange } from "./ConfirmProvider";
import { StateBadge } from "./MisSubAccountsClient";
import { misJson, subAccountApi, SubAccountProvider, useSubAccount } from "./useSubAccount";
import type { SubAccountDetail } from "@/lib/reseller-accounts";

/**
 * The frame a sub-account's tabs sit in: back to the list, its name and state, Rename and
 * Suspend/Resume, and the tab bar (the approved mockup's screens 3 and 4).
 *
 * <p>The mockup draws three tabs -- Balance, Logins, Messages -- and those come first. The portal's
 * other per-account pages (approvals, the statement, credit terms and settings) stay reachable after
 * them rather than being dropped: a reseller already requests sender IDs and reads statements for its
 * customers there, and the redesign was about money and logins, not about removing those.
 */
export function MisSubAccountShell({ id, children }: { id: string; children: React.ReactNode }) {
  return (
    <SubAccountProvider id={id}>
      <Frame>{children}</Frame>
    </SubAccountProvider>
  );
}

const TABS = [
  { slug: "", label: "Balance" },
  { slug: "logins", label: "Logins" },
  { slug: "messages", label: "Messages" },
  { slug: "approvals", label: "Approvals" },
  { slug: "statement", label: "Statement" },
  { slug: "billing", label: "Credit terms" },
  { slug: "settings", label: "Settings" },
] as const;

function Frame({ children }: { children: React.ReactNode }) {
  const { id, account, error, reload } = useSubAccount();
  const pathname = usePathname();
  const base = `/accounts/${encodeURIComponent(id)}`;
  const path = pathname.startsWith(base) ? pathname.slice(base.length).replace(/^\//, "") : "";
  const current = path.split("/")[0] ?? "";

  return (
    <div className="space-y-5">
      <div className="space-y-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div className="min-w-0 space-y-1.5">
            <BackLink href="/accounts">Sub-accounts</BackLink>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
              <h1 className="text-page max-sm:text-entity">{account?.label || id}</h1>
              {account && <StateBadge account={account} />}
            </div>
            <span className="font-mono text-sm text-muted-foreground">{id}</span>
          </div>
          {account && !account.archived && <Actions account={account} reload={reload} />}
        </div>
        <ErrorNote error={error} />

        <nav className="-mb-px flex gap-1 overflow-x-auto border-b border-border" aria-label="Sub-account">
          {TABS.map((tab) => {
            const active = current === tab.slug;
            const label = tab.slug === "logins" && account ? `Logins (${account.logins})` : tab.label;
            return (
              <Link
                key={tab.slug}
                href={tab.slug ? `${base}/${tab.slug}` : base}
                aria-current={active ? "page" : undefined}
                className={`relative whitespace-nowrap border-b-2 px-3 py-2 text-sm transition-colors ${
                  active ? "border-foreground text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                {label}
                <PendingUnderline />
              </Link>
            );
          })}
        </nav>
      </div>
      {children}
    </div>
  );
}

function Actions({ account, reload }: { account: SubAccountDetail; reload: () => Promise<void> }) {
  const confirm = useConfirmChange();
  const [renaming, setRenaming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  async function toggle() {
    const suspending = account.enabled;
    const name = account.label || account.id;
    const ok = await confirm(suspending
      ? {
          title: `Suspend ${name}?`,
          consequence: "Its logins are switched off and open connections dropped, so it stops sending now. "
            + "Its balance stays where it is. You can resume it at any time.",
          confirmLabel: "Suspend",
          tone: "caution",
        }
      : {
          title: `Resume ${name}?`,
          consequence: "Its logins are switched back on and it can connect and send again within seconds.",
          confirmLabel: "Resume",
        });
    if (!ok) {
      return;
    }
    setBusy(true);
    setError("");
    try {
      const done = await misJson<{ message: string }>(subAccountApi(account.id), {
        method: "PATCH",
        body: JSON.stringify({ enabled: !suspending }),
      });
      setNotice(done.message);
      await reload();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-1.5">
      <div className="flex flex-wrap justify-end gap-2">
        <Button variant="outline" onClick={() => setRenaming(true)} disabled={busy}>Rename</Button>
        <Button variant="outline" onClick={toggle} disabled={busy}>{account.enabled ? "Suspend" : "Resume"}</Button>
      </div>
      {notice && <p role="status" className="max-w-md text-right text-xs text-muted-foreground">{notice}</p>}
      <ErrorNote error={error} />
      <RenameDialog open={renaming} account={account} onClose={() => setRenaming(false)} onSaved={reload} />
    </div>
  );
}

function RenameDialog({
  open, account, onClose, onSaved,
}: { open: boolean; account: SubAccountDetail; onClose: () => void; onSaved: () => Promise<void> }) {
  const [label, setLabel] = useState(account.label ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (open) {
      setLabel(account.label ?? "");
      setError("");
    }
  }, [open, account.label]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      await misJson(subAccountApi(account.id), { method: "PATCH", body: JSON.stringify({ label: label.trim() || null }) });
      await onSaved();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onClose={onClose} title="Rename" description={`The name you and the customer see. The id, ${account.id}, stays.`}>
      <form onSubmit={save} className="space-y-4 px-5 py-4">
        <label htmlFor="rename-label" className="sr-only">Name</label>
        <Input id="rename-label" value={label} onChange={(e) => setLabel(e.target.value)} maxLength={200} autoFocus />
        <ErrorNote error={error} />
        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
          <Button type="submit" disabled={busy}>{busy ? "Saving…" : "Save"}</Button>
        </div>
      </form>
    </Dialog>
  );
}
