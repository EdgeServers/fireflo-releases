"use client";
import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { StatTile } from "@/components/ui/stat-tile";
import { Badge } from "@/components/ui/badge";
import { TableInCard, THead, TH, TBody, TR, TD } from "@/components/ui/table";
import { ErrorNote } from "./FormNotices";
import { useDisplayZone } from "@/components/DisplayZoneProvider";
import { money } from "@/lib/format";
import { formatMoment, formatTimestamp } from "@/lib/datetime";
import { parseAmount } from "@/lib/balance-types";
import { misJson, newIdempotencyKey, subAccountApi, useSubAccount } from "./useSubAccount";
import type { TransferRow } from "@/lib/reseller-accounts";

/**
 * Balance: what the sub-account holds, recharge and withdraw, and the transfers between you
 * (the approved mockup's screen 3).
 *
 * <p>Neither form moves money itself: each queues a transfer the gateway applies within seconds, so
 * after a submit the page re-reads rather than adding the amount in the browser. A suspended or
 * archived account cannot be recharged or withdrawn from, and the forms say so instead of offering a
 * button the server would refuse.
 */
export function MisSubAccountBalanceClient() {
  const { id, account, reload } = useSubAccount();
  const [transfers, setTransfers] = useState<TransferRow[] | null>(null);
  const [error, setError] = useState("");
  const { zone } = useDisplayZone();

  const loadTransfers = useCallback(async () => {
    try {
      setTransfers((await misJson<{ transfers: TransferRow[] }>(subAccountApi(id, "/transfers"))).transfers);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }, [id]);

  useEffect(() => {
    void loadTransfers();
  }, [loadTransfers]);

  //a queued transfer lands within seconds: read again shortly after, and once more for a slow poll
  const afterTransfer = useCallback(async () => {
    await Promise.all([reload(), loadTransfers()]);
    for (const wait of [2_000, 6_000]) {
      setTimeout(() => void Promise.all([reload(), loadTransfers()]), wait);
    }
  }, [reload, loadTransfers]);

  const balance = account?.balance ?? null;
  const currency = balance?.currency ?? account?.self?.currency ?? "";
  const name = account?.label || id;
  const blocked = account?.archived
    ? `${id} is archived; no credit moves to or from it.`
    : account && !account.enabled
      ? `${name} is suspended. Resume it to recharge or withdraw.`
      : null;

  return (
    <div className="space-y-5">
      <div className="grid gap-3 sm:grid-cols-3">
        <StatTile label="Available" loading={!account} value={balance ? money(balance.balance, currency) : "—"}
          hint={balance ? undefined : "no balance yet"} />
        <StatTile label="Reserved for sending now" loading={!account}
          value={balance ? money(balance.reserved, currency) : "—"} hint="returned when it stops sending" />
        <StatTile label="Spent, this month" loading={!account}
          value={account?.spentThisMonth == null ? "—" : money(account.spentThisMonth, currency)}
          hint={account?.spentThisMonth == null ? "not summarised on this platform" : undefined} />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <TransferForm
          kind="recharge"
          title="Recharge"
          lead={`Moves credit from your balance to ${name}.`}
          currency={currency}
          available={account?.self?.spendable ?? null}
          blocked={blocked}
          onDone={afterTransfer}
        />
        <TransferForm
          kind="withdraw"
          title="Withdraw"
          lead={balance
            ? `Moves credit back to you. Credit reserved for messages being sent is freed first, so up to ${
              money(balance.balance + balance.reserved, currency)} can come back.`
            : "Moves credit back to you. Credit reserved for messages being sent is freed first."}
          currency={currency}
          available={null}
          blocked={blocked}
          onDone={afterTransfer}
        />
      </div>

      <Card>
        <CardHeader><CardTitle>Transfers</CardTitle></CardHeader>
        <CardContent className="px-0 pb-0">
          <ErrorNote error={error} />
          <TableInCard>
            <THead>
              <tr>
                <TH>When</TH>
                <TH>What</TH>
                <TH>Reference</TH>
                <TH>By</TH>
                <TH align="right">Amount</TH>
                <TH>State</TH>
              </tr>
            </THead>
            <TBody>
              {transfers && !transfers.length && (
                <tr><TD colSpan={6} muted className="py-6 text-center">No transfers yet.</TD></tr>
              )}
              {(transfers ?? []).map((t) => (
                <TR key={t.id}>
                  <TD muted title={formatTimestamp(t.at, zone)} className="whitespace-nowrap">{formatMoment(t.at, zone)}</TD>
                  <TD>{t.kind === "opening" ? "Opening credit" : t.kind === "recharge" ? "Recharge" : "Withdraw"}</TD>
                  <TD muted>{t.reference ?? "—"}</TD>
                  <TD muted>{t.via === "api" ? `API · ${t.by ?? ""}` : t.by ?? "—"}</TD>
                  <TD num className={t.amount < 0 ? "text-muted-foreground" : undefined}>
                    {t.amount >= 0 ? "+" : "−"}{money(Math.abs(t.amount), currency)}
                  </TD>
                  <TD>{t.applied ? <Badge variant="success">Applied</Badge> : <Badge variant="warning">Waiting</Badge>}</TD>
                </TR>
              ))}
            </TBody>
          </TableInCard>
        </CardContent>
      </Card>
    </div>
  );
}

function TransferForm({
  kind, title, lead, currency, available, blocked, onDone,
}: {
  kind: "recharge" | "withdraw";
  title: string;
  lead: string;
  currency: string;
  /** The reseller's spendable balance, for "you'll have … left". Recharge only. */
  available: number | null;
  blocked: string | null;
  onDone: () => Promise<void>;
}) {
  const { id } = useSubAccount();
  const [amount, setAmount] = useState("");
  const [reference, setReference] = useState("");
  //one key per intended transfer: made when the form opens and again after each success, so a
  //double click or a retry after a timeout is the same transfer, never a second one
  const [key, setKey] = useState(() => newIdempotencyKey());
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [warning, setWarning] = useState("");

  const scaled = amount.trim() ? parseAmount(amount) : null;
  const invalid = amount.trim() !== "" && (scaled === null || scaled <= 0);
  const left = available != null && scaled != null ? available - scaled : null;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (scaled === null || scaled <= 0) {
      setError("Enter an amount greater than zero, with at most four decimal places.");
      return;
    }
    setBusy(true);
    setError("");
    setNotice("");
    setWarning("");
    try {
      const done = await misJson<{ message: string; problem: string | null }>(subAccountApi(id, `/${kind}`), {
        method: "POST",
        body: JSON.stringify({ amount: amount.trim(), reference: reference.trim() || undefined, idempotencyKey: key }),
      });
      setNotice(done.message);
      setWarning(done.problem ?? "");
      setAmount("");
      setReference("");
      setKey(newIdempotencyKey());
      await onDone();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  const fieldId = (f: string) => `${kind}-${f}`;
  return (
    <Card>
      <form onSubmit={submit} aria-label={title} className="space-y-3 p-5 max-sm:p-4">
        <div>
          <h2 className="text-title">{title}</h2>
          <p className="mt-1 text-sm text-muted-foreground">{lead}</p>
        </div>
        <fieldset disabled={!!blocked || busy} className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor={fieldId("amount")}>Amount</Label>
            <div className="flex items-center rounded-md border border-input bg-card focus-within:ring-1 focus-within:ring-ring">
              {currency && <span className="pl-3 text-sm text-muted-foreground">{currency}</span>}
              <input
                id={fieldId("amount")}
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                inputMode="decimal"
                placeholder="0.00"
                aria-invalid={invalid || undefined}
                className="h-11 min-w-0 flex-1 bg-transparent px-3 text-sm tabular-nums outline-none md:h-9"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor={fieldId("ref")}>
              Reference <span className="font-normal text-muted-foreground">(optional)</span>
            </Label>
            <Input id={fieldId("ref")} value={reference} onChange={(e) => setReference(e.target.value)} maxLength={100} />
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className={left != null && left < 0 ? "text-sm text-destructive" : "text-sm text-muted-foreground"}>
              {left != null ? `You'll have ${money(left, currency)} left` : ""}
            </span>
            <Button type="submit" variant={kind === "recharge" ? "default" : "outline"}>
              {busy ? "Sending…" : kind === "recharge" && scaled && scaled > 0 ? `Recharge ${money(scaled, currency)}` : title}
            </Button>
          </div>
        </fieldset>
        {blocked && <p className="text-sm text-muted-foreground">{blocked}</p>}
        {invalid && <p className="text-xs text-destructive">An amount greater than zero, with at most four decimal places.</p>}
        <ErrorNote error={error} />
        {notice && <p role="status" className="text-sm text-success">{notice}</p>}
        {warning && <p className="text-sm text-warning">{warning}</p>}
      </form>
    </Card>
  );
}
