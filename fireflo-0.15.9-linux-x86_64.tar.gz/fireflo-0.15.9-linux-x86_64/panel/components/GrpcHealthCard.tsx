"use client";
import { Radio } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { count } from "@/lib/format";
import type { Health } from "@/lib/health-types";
import { grpcExplainer, grpcPill, grpcView } from "@/lib/grpc-health";
import { ageLabel } from "@/lib/receipt-custody";
import { Figures } from "./CardBits";

/**
 * The gRPC listener and its receipt feed (gateway 0.15.9, health's `grpc` block).
 *
 * <p>On or off and the port; the sessions and streams open on this node; the receipts waiting for
 * HTTP logins to collect them over gRPC, the age of the oldest unacknowledged one, how many logins
 * are at their cap, and the deepest queues by login. Hidden on an older gateway, which has no such
 * block; a 0.15.9 gateway with gRPC switched off shows the card as Off with the one setting that
 * opens it.
 */
export function GrpcHealthCard({ health }: { health: Health | null | undefined }) {
  const v = grpcView(health);
  if (!v) {
    return null;
  }
  const pill = grpcPill(v);
  const atCap = v.receipts.loginsAtCap > 0;

  return (
    <Card data-testid="grpc-health-card" className={cn(atCap && "border-warning")}>
      <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0">
        <CardTitle className="flex items-center gap-2">
          <Radio className="h-4 w-4 text-muted-foreground" aria-hidden />
          gRPC
        </CardTitle>
        <Badge variant={pill.tone}>{pill.label}</Badge>
        {v.enabled && v.port != null && (
          <span className="ml-auto font-mono text-xs text-muted-foreground" data-testid="grpc-port">:{v.port}</span>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        {v.enabled && (
          <Figures
            figures={[
              { value: count(v.sessions), label: "sessions" },
              { value: count(v.streams), label: "streams" },
              { value: count(v.receipts.depth), label: "receipts queued" },
              { value: ageLabel(v.receipts.oldestAgeSeconds), label: "oldest unacked" },
              { value: count(v.receipts.loginsAtCap), label: "logins at cap", tone: atCap ? "warning" : undefined },
            ]}
          />
        )}
        {v.enabled && v.receipts.top.length > 0 && (
          <ul className="divide-y divide-border rounded-md border border-border text-sm" aria-label="Deepest receipt queues">
            {v.receipts.top.map((t) => (
              <li key={t.systemId} className="flex flex-wrap items-baseline gap-x-3 px-3 py-1.5 tabular-nums">
                <span className="min-w-0 flex-1 truncate font-mono text-xs">{t.systemId}</span>
                <span className="font-medium">{count(t.depth)}</span>
              </li>
            ))}
          </ul>
        )}
        <p className="text-xs text-muted-foreground">{grpcExplainer(v)}</p>
      </CardContent>
    </Card>
  );
}
