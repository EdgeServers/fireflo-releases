"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Plus } from "lucide-react";
import { PageHeader } from "@/components/ui/page-header";
import { StatTile } from "@/components/ui/stat-tile";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Table, THead, TH, TBody, TR, TD } from "@/components/ui/table";
import { buttonClasses } from "@/components/ui/button";
import { ErrorCard } from "./FormNotices";
import { useDisplayZone } from "@/components/DisplayZoneProvider";
import { money, localeNumber } from "@/lib/format";
import { formatMoment } from "@/lib/datetime";
import { misJson } from "./useSubAccount";
import type { SubAccountList, SubAccountRow } from "@/lib/reseller-accounts";

/**
 * Sub-accounts: the accounts this reseller sells to, with what they hold and whether they send.
 *
 * <p>The approved mockup's first screen (2026-11-08): three tiles, a search and a state filter, one
 * table, and "New sub-account" at the top right. Every action here is also an API call -- the note
 * under the table says where it is documented.
 */
export function MisSubAccountsClient() {
  const [data, setData] = useState<SubAccountList | null>(null);
  const [error, setError] = useState("");
  const [q, setQ] = useState("");
  const [state, setState] = useState<"all" | "active" | "suspended">("all");
  const { zone } = useDisplayZone();

  useEffect(() => {
    misJson<SubAccountList>("/api/mis/sub-accounts")
      .then(setData)
      .catch((err) => setError(err instanceof Error ? err.message : String(err)));
  }, []);

  const rows = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return (data?.accounts ?? []).filter((a) =>
      (!needle || a.id.toLowerCase().includes(needle) || (a.label ?? "").toLowerCase().includes(needle))
      && (state === "all" || (state === "active" ? isActive(a) : !isActive(a)))
    );
  }, [data, q, state]);

  const accounts = data?.accounts ?? [];
  const active = accounts.filter(isActive).length;
  const currency = data?.currency ?? "";
  const held = accounts.reduce((sum, a) => sum + (a.balance ? a.balance.balance + a.balance.reserved : 0), 0);
  const sent = accounts.some((a) => a.sent24h != null)
    ? accounts.reduce((sum, a) => sum + (a.sent24h ?? 0), 0)
    : null;

  return (
    <div className="space-y-5">
      <PageHeader
        title="Sub-accounts"
        description="Accounts you resell to. Their credit comes from your balance."
        actions={
          <>
            {data?.self && (
              <span className="text-sm text-muted-foreground">
                Available{" "}
                <span className="font-medium tabular-nums text-foreground">
                  {money(data.self.spendable, data.self.currency ?? currency)}
                </span>
              </span>
            )}
            <Link href="/accounts/new" className={buttonClasses()}>
              <Plus className="mr-1.5 h-4 w-4" aria-hidden />
              New sub-account
            </Link>
          </>
        }
      />

      <ErrorCard error={error} />

      <div className="grid gap-3 sm:grid-cols-3">
        <StatTile
          label="Sub-accounts"
          loading={!data && !error}
          value={localeNumber(accounts.length)}
          hint={`${active} active, ${accounts.length - active} suspended`}
        />
        <StatTile
          label="Held by sub-accounts"
          loading={!data && !error}
          value={<span className="tabular-nums">{money(held, currency)}</span>}
          hint="balance plus reserved"
        />
        <StatTile
          label="Sent by sub-accounts, 24 h"
          loading={!data && !error}
          value={sent == null ? "—" : localeNumber(sent)}
          hint={sent == null ? "not summarised on this platform" : "messages"}
        />
      </div>

      <div className="flex flex-wrap items-center gap-2.5">
        <label htmlFor="sub-q" className="sr-only">Search sub-accounts</label>
        <Input
          id="sub-q"
          type="search"
          placeholder="Search by id or name"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="min-w-0 flex-1 basis-64"
        />
        <label htmlFor="sub-state" className="text-sm text-muted-foreground">State</label>
        <Select id="sub-state" value={state} onChange={(e) => setState(e.target.value as typeof state)} className="w-auto">
          <option value="all">All</option>
          <option value="active">Active</option>
          <option value="suspended">Suspended</option>
        </Select>
      </div>

      <Table>
        <THead>
          <tr>
            <TH>Sub-account</TH>
            <TH>State</TH>
            <TH align="right">Balance</TH>
            <TH align="right">Logins</TH>
            <TH>Last sent</TH>
            <TH><span className="sr-only">Actions</span></TH>
          </tr>
        </THead>
        <TBody>
          {data && !rows.length && (
            <tr>
              <TD colSpan={6} muted className="py-8 text-center">
                {accounts.length
                  ? "Nothing matches that search."
                  : "No sub-accounts yet. Create one, and it gets an HTTP login straight away."}
              </TD>
            </tr>
          )}
          {rows.map((a) => {
            const href = `/accounts/${encodeURIComponent(a.id)}`;
            return (
              <TR key={a.id}>
                <TD>
                  <Link href={href} className="font-medium hover:underline">{a.label || a.id}</Link>
                  <div className="font-mono text-xs text-muted-foreground">{a.id}</div>
                </TD>
                <TD><StateBadge account={a} /></TD>
                <TD num>{a.balance ? money(a.balance.balance, a.balance.currency ?? currency) : "—"}</TD>
                <TD num>{localeNumber(a.logins)}</TD>
                <TD muted>{a.lastSentAt ? formatMoment(a.lastSentAt, zone) : a.sent24h == null ? "—" : "Not yet"}</TD>
                <TD align="right"><Link href={href} className="hover:underline">Open</Link></TD>
              </TR>
            );
          })}
        </TBody>
      </Table>

      <p className="text-sm text-muted-foreground">
        Two levels only: a sub-account can&apos;t resell. Every change here is also available over the REST
        API (<Link href="/api-docs#managing-your-accounts" className="underline underline-offset-4">API docs › Managing your accounts</Link>).
      </p>
    </div>
  );
}

function isActive(a: SubAccountRow): boolean {
  return a.enabled && !a.archived;
}

export function StateBadge({ account }: { account: Pick<SubAccountRow, "enabled" | "archived"> }) {
  if (account.archived) {
    return <Badge variant="destructive">Archived</Badge>;
  }
  return account.enabled ? <Badge variant="success">Active</Badge> : <Badge variant="outline">Suspended</Badge>;
}
