"use client";
import { Table, THead, TH, TBody, TR, TD } from "@/components/ui/table";
import { CodeBlock } from "./CodeBlock";
import { PASSWORD_PLACEHOLDER } from "./useApiAccess";

/**
 * "Managing your accounts": the reseller API (gateway 0.15.8, `/secure/accounts…`) on the portal's
 * REST reference, shown only to an account that resells (the approved mockup's screen 5).
 *
 * <p>Mirrors the plan's endpoint table and the gateway's reseller docs: the same paths, fields and
 * refusals the portal's own sub-account pages are held to (`lib/reseller-rules.ts`). Every example is
 * filled in with this reseller's base URL and login, as the rest of the page is.
 */

export const RESELLER_SECTION = { id: "managing-your-accounts", label: "Managing your accounts" };

const ROUTES: { method: string; path: string; does: string }[] = [
  { method: "GET", path: "/secure/accounts", does: "List your sub-accounts (?limit and ?after page through them)" },
  { method: "POST", path: "/secure/accounts", does: "Create one (with an HTTP login and optional opening credit)" },
  { method: "GET · PATCH", path: "/secure/accounts/{id}", does: "Read; rename, suspend or resume" },
  { method: "GET · POST", path: "/secure/accounts/{id}/logins", does: "List; add an SMPP or HTTP login" },
  { method: "PATCH", path: "/secure/accounts/{id}/logins/{login}", does: "Enable/disable, allowed IPs, session limits" },
  { method: "POST", path: "/secure/accounts/{id}/logins/{login}/password", does: "New password, shown once" },
  { method: "POST", path: "/secure/accounts/{id}/recharge", does: "Move credit from you to it" },
  { method: "POST", path: "/secure/accounts/{id}/withdraw", does: "Move credit back to you" },
  { method: "GET", path: "/secure/accounts/{id}/transfers", does: "Its recharges and withdrawals" },
];

const FIELDS: { name: string; where: string; note: string }[] = [
  { name: "id", where: "create", note: "Letters, digits, dot, dash, underscore, starting with a letter or digit; at most 64. Free across the whole platform, ignoring case. Can't be changed later." },
  { name: "label", where: "create, PATCH", note: "The name you and the customer see." },
  { name: "opening", where: "create", note: "Optional amount moved from your balance as the account is made. 402 if you can't cover it." },
  { name: "enabled", where: "PATCH account, PATCH login", note: "false suspends: its logins are switched off and open connections dropped. true resumes." },
  { name: "type", where: "add login", note: "SMPP or HTTP, exactly." },
  { name: "system_id", where: "add login", note: "Optional. SMPP at most 15 characters, HTTP at most 64; must be free across every login. Left out, one is made." },
  { name: "allowed_ips", where: "add login, PATCH login", note: "Up to 50 single addresses; empty allows any. Ranges and hostnames never match." },
  { name: "max_sessions, max_tx, max_rx, max_trx", where: "add login, PATCH login", note: "SMPP only. Whole numbers from 1 to 10000, or null for no limit of its own; TX/RX/TRX at most the total." },
  { name: "amount", where: "recharge, withdraw", note: "A decimal string in your platform's currency, above zero, up to 4 places." },
  { name: "idempotency_key", where: "recharge, withdraw", note: "Required. The same key again returns the same transfer, never a second one." },
  { name: "reference", where: "recharge, withdraw", note: "Optional text for your own records." },
];

const ERRORS: { status: string; when: string }[] = [
  { status: "400", when: "A field is missing or wrong; the message names it. Also: speed, message types and products are set by your platform, and passwords are generated, never chosen." },
  { status: "402", when: "Your balance doesn't cover the recharge (or the opening credit). Nothing was moved." },
  { status: "404", when: "Not your sub-account, or your account doesn't resell." },
  { status: "409", when: "The id or system id is taken, or the account is suspended or archived." },
  { status: "429 · 503", when: "Too many transfers waiting, or the gateway is busy: retry with the same key." },
];

export function MisResellerApiDocs({
  baseUrl, login, currency,
}: { baseUrl: string; login: string; currency: string | null }) {
  const auth = `-u ${login}:${PASSWORD_PLACEHOLDER}`;
  return (
    <section id={RESELLER_SECTION.id} className="space-y-4 scroll-mt-4">
      <div className="space-y-2">
        <h2 className="text-title">Managing your accounts</h2>
        <p className="text-sm leading-relaxed text-muted-foreground">
          Everything on the Sub-accounts pages is also an API call. Use your own HTTP login: Basic auth,
          or a token your platform issues from <Code>POST /token</Code>. Accounts that aren&apos;t yours
          answer 404. Answers are <Code>{'{"data": …}'}</Code>; a refusal is{" "}
          <Code>{'{"message": "…"}'}</Code>.
        </p>
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <Fact label="Base URL"><span className="font-mono">{baseUrl}</span></Fact>
          <Fact label="Your login"><span className="font-mono">{login}</span></Fact>
          <Fact label="Amounts">
            decimal strings in your platform&apos;s currency{currency ? ` (${currency})` : ""}, up to 4 places
          </Fact>
        </div>
      </div>

      <Table>
        <THead>
          <tr>
            <TH className="w-24">Method</TH>
            <TH>Path</TH>
            <TH>Does</TH>
          </tr>
        </THead>
        <TBody>
          {ROUTES.map((r) => (
            <TR key={`${r.method} ${r.path}`}>
              <TD className="align-top font-mono text-xs">{r.method}</TD>
              <TD className="align-top break-all font-mono text-xs">{r.path}</TD>
              <TD muted className="min-w-[12rem] align-top">{r.does}</TD>
            </TR>
          ))}
        </TBody>
      </Table>

      <div className="space-y-2">
        <h3 className="text-sm font-semibold">Create a sub-account</h3>
        <CodeBlock
          title="Request"
          copyLabel="Copy request"
          code={`curl ${auth} -H 'Content-Type: application/json' \\
  -d '{"id":"nw-sunrise","label":"Sunrise Diagnostics","opening":"500.00"}' \\
  ${baseUrl}/secure/accounts`}
        />
        <CodeBlock
          title="201"
          code={`{"data": {"id": "nw-sunrise", "label": "Sunrise Diagnostics", "enabled": true,
  "opening": "500.0000", "login": {"system_id": "nw-sunrise", "type": "HTTP",
  "password": "Qm7v2Lx9Tk4p…"}}}`}
        />
        <p className="text-xs text-muted-foreground">The password appears only in this answer. Copy it then.</p>
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-semibold">Add an SMPP login with a chosen system id</h3>
        <CodeBlock
          title="Request"
          copyLabel="Copy request"
          code={`curl ${auth} -H 'Content-Type: application/json' \\
  -d '{"type":"SMPP","system_id":"sunriseotp","allowed_ips":["203.0.113.24"],"max_sessions":4}' \\
  ${baseUrl}/secure/accounts/nw-sunrise/logins`}
        />
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-semibold">Recharge it</h3>
        <CodeBlock
          title="Request"
          copyLabel="Copy request"
          code={`curl ${auth} -H 'Content-Type: application/json' \\
  -d '{"amount":"1000.00","idempotency_key":"inv-NW-2211","reference":"Invoice NW-2211"}' \\
  ${baseUrl}/secure/accounts/nw-sunrise/recharge`}
        />
        <p className="text-sm leading-relaxed text-muted-foreground">
          202 with a transfer id: it&apos;s applied within seconds. Send the same <Code>idempotency_key</Code>{" "}
          again and you get the same transfer back, never a second one. A withdrawal first frees the
          credit the account holds for messages being sent, so it can come back even while it sends.
        </p>
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-semibold">Fields</h3>
        <Table>
          <THead>
            <tr>
              <TH className="w-1/4">Field</TH>
              <TH className="w-1/5">On</TH>
              <TH>Meaning</TH>
            </tr>
          </THead>
          <TBody>
            {FIELDS.map((f) => (
              <TR key={f.name}>
                <TD className="align-top break-words font-mono text-xs">{f.name}</TD>
                <TD muted className="align-top text-xs">{f.where}</TD>
                <TD muted className="align-top">{f.note}</TD>
              </TR>
            ))}
          </TBody>
        </Table>
        <p className="text-xs text-muted-foreground">
          Speed (<Code>max_tps</Code>), the product and allowed products stay your platform&apos;s: sending one
          is refused with 400, not ignored.
        </p>
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-semibold">Errors</h3>
        <Table>
          <TBody>
            {ERRORS.map((e) => (
              <TR key={e.status}>
                <TD className="w-24 align-top font-mono">{e.status}</TD>
                <TD muted className="align-top">{e.when}</TD>
              </TR>
            ))}
          </TBody>
        </Table>
      </div>
    </section>
  );
}

function Fact({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded bg-muted px-2 py-1">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-foreground">{children}</span>
    </span>
  );
}

function Code({ children }: { children: React.ReactNode }) {
  return <code className="rounded bg-muted px-1 py-0.5 font-mono text-sm">{children}</code>;
}
