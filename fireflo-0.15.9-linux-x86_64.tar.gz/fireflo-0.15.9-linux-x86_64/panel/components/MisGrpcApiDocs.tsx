"use client";
import { useState } from "react";
import { Table, THead, TH, TBody, TR, TD } from "@/components/ui/table";
import { HealthStrip } from "@/components/CardBits";
import { CodeBlock } from "./CodeBlock";
import {
  GRPC_DEFAULT_PORT,
  GRPC_ERROR_DETAIL,
  GRPC_RECEIPT_FIELDS,
  GRPC_SEND_FIELDS,
  GRPC_SEND_RESPONSE,
  GRPC_SERVICES,
  GRPC_STATUS_ROWS,
  grpcurlExample,
  pythonExample,
  type GrpcAddress,
} from "@/lib/grpc-api-docs";

/**
 * "gRPC API" on the portal's API reference (gateway 0.15.9), for every customer with an HTTP login.
 *
 * <p>The customer content of the gateway's gRPC document: where to connect, Login and the session
 * token, the Send fields beside their REST names, the status each outcome maps to, SendStream, and
 * the receipt feed (Subscribe, Pull, Ack; at least once). Examples are filled in with this
 * customer's login and the address the operator published, as the rest of the page is. Generated
 * from `lib/grpc-api-docs.ts` so the tables are tested without a browser.
 */

export const GRPC_SECTION = { id: "grpc", label: "gRPC API" };

type Sample = "grpcurl" | "Python";
const SAMPLES: readonly Sample[] = ["grpcurl", "Python"];

export function MisGrpcApiDocs({
  grpc, login, exampleTo,
}: { grpc: GrpcAddress | null | undefined; login: string; exampleTo: string }) {
  const [sample, setSample] = useState<Sample>("grpcurl");
  const where: GrpcAddress = grpc ?? { address: `your-gateway:${GRPC_DEFAULT_PORT}`, tls: false, published: false };

  return (
    <section id={GRPC_SECTION.id} className="space-y-4 scroll-mt-4" data-testid="grpc-api-docs">
      <div className="space-y-2">
        <h2 className="text-title">gRPC API</h2>
        <p className="text-sm leading-relaxed text-muted-foreground">
          The same sends as REST, over HTTP/2 with a typed contract: faster at high volume, and your
          delivery receipts collected over the connection instead of a webhook. Use the same HTTP
          login and password as REST, the same allowed addresses and the same per-account rate limit
          — REST and gRPC share it.
        </p>
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <Fact label="Address"><span className="font-mono" data-testid="grpc-address">{where.address}</span></Fact>
          <Fact label="Transport">{where.tls ? "TLS" : "plaintext HTTP/2 (h2c)"}</Fact>
          <Fact label="Package"><span className="font-mono">fireflo.v1</span></Fact>
          <Fact label="Your login"><span className="font-mono">{login}</span></Fact>
        </div>
        {!where.published && (
          <HealthStrip tone="warning">
            Your operator has not published a gRPC address here, so the examples assume port{" "}
            {GRPC_DEFAULT_PORT} on the REST host without TLS. Ask them for the address, and whether
            gRPC is switched on for your platform.
          </HealthStrip>
        )}
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-semibold">Get the proto</h3>
        <p className="text-sm leading-relaxed text-muted-foreground">
          The contract is <Code>api/fireflo.proto</Code> in the gateway release bundle; ask your
          operator for a copy and generate a client in your language with <Code>protoc</Code>. It is
          frozen: fields are only ever added, never renumbered or reused. The server also answers
          reflection, so <Code>grpcurl</Code> can list and call it without the file
          (<Code>grpcurl {where.tls ? "" : "-plaintext "}{where.address} list</Code>); if your
          operator has switched reflection off, pass <Code>-proto fireflo.proto</Code>.
        </p>
        <Table>
          <THead>
            <tr>
              <TH className="w-1/3">Service</TH>
              <TH className="w-1/4">Calls</TH>
              <TH>Does</TH>
            </tr>
          </THead>
          <TBody>
            {GRPC_SERVICES.map((s) => (
              <TR key={s.name}>
                <TD className="align-top break-all font-mono text-xs">{s.name}</TD>
                <TD muted className="align-top font-mono text-xs">{s.rpcs}</TD>
                <TD muted className="align-top">{s.does}</TD>
              </TR>
            ))}
          </TBody>
        </Table>
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-semibold">Login and the session</h3>
        <p className="text-sm leading-relaxed text-muted-foreground">
          Call <Code>AuthService/Login</Code> once with <Code>system_id</Code> (your login) and{" "}
          <Code>password</Code>. It answers a <Code>session_token</Code>, when it expires at the
          latest, and the idle timeout. Send the token on every other call as the metadata{" "}
          <Code>authorization: Bearer &lt;session_token&gt;</Code>. A token is tied to the address
          you logged in from, lapses after an idle hour or a day at most (your operator may set other
          times), and does not survive a gateway restart.
        </p>
        <p className="text-sm leading-relaxed text-muted-foreground">
          When a call answers <Code>UNAUTHENTICATED</Code> with <Code>SESSION_EXPIRED</Code>, call
          Login again and repeat the call — that is the normal path after a restart, and it never
          counts against your address. A wrong password does: repeated refusals block the address on
          every port, REST and SMPP included.
        </p>
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-semibold">Send</h3>
        <p className="text-sm leading-relaxed text-muted-foreground">
          <Code>SendService/Send</Code> takes one <Code>SendRequest</Code>, field for field the body
          of <Code>POST /secure/send</Code>. A field you leave unset takes the same default as a JSON
          key you leave out, and every REST rule applies — approved sender IDs and wording, products,
          the TLV forms, the balance.
        </p>
        <Table>
          <THead>
            <tr>
              <TH className="w-1/5">Field</TH>
              <TH className="w-1/6">Type</TH>
              <TH className="w-1/6">REST</TH>
              <TH>Notes</TH>
            </tr>
          </THead>
          <TBody>
            {GRPC_SEND_FIELDS.map((f) => (
              <TR key={f.proto}>
                <TD className="align-top font-mono">
                  {f.proto}
                  {f.required === true && <span className="text-destructive"> *</span>}
                </TD>
                <TD muted className="align-top break-words font-mono text-xs">{f.type}</TD>
                <TD muted className="align-top font-mono text-xs">{f.rest ?? "—"}</TD>
                <TD muted className="align-top">
                  {f.note}
                  {f.fallback && <> Defaults to <Code>{f.fallback}</Code>.</>}
                </TD>
              </TR>
            ))}
          </TBody>
        </Table>
        <p className="text-xs text-muted-foreground">
          REST&apos;s <Code>dlr_method</Code> and <Code>tags</Code> are not carried. With{" "}
          <Code>dlr</Code> true and no <Code>dlr_url</Code>, receipts wait in your feed below; with a{" "}
          <Code>dlr_url</Code>, they go to that webhook and never to the feed.
        </p>
        <FieldTable rows={GRPC_SEND_RESPONSE} head="SendResponse" />
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-semibold">Status codes</h3>
        <p className="text-sm leading-relaxed text-muted-foreground">
          Every refusal is a gRPC status with an <Code>ErrorDetail</Code> in its details, carrying
          what REST would have said, so a REST integration&apos;s error handling carries over.{" "}
          <Code>OUTCOME_UNKNOWN</Code> is deliberately <Code>UNKNOWN</Code> rather than{" "}
          <Code>UNAVAILABLE</Code>, so a client library&apos;s automatic retry does not send the
          message twice: retry it yourself, with the same <Code>client_ref</Code>.
        </p>
        <Table>
          <THead>
            <tr>
              <TH className="w-1/4">When</TH>
              <TH className="w-12">REST</TH>
              <TH className="w-1/6">gRPC</TH>
              <TH className="w-1/4">ErrorDetail.code</TH>
              <TH>Then</TH>
            </tr>
          </THead>
          <TBody>
            {GRPC_STATUS_ROWS.map((r) => (
              <TR key={`${r.grpc}-${r.cause}`}>
                <TD className="align-top">{r.cause}</TD>
                <TD muted className="align-top font-mono">{r.http}</TD>
                <TD className="align-top break-words font-mono text-xs">{r.grpc}</TD>
                <TD muted className="align-top break-words font-mono text-xs">{r.code}</TD>
                <TD muted className="align-top">{r.then}</TD>
              </TR>
            ))}
          </TBody>
        </Table>
        <FieldTable rows={GRPC_ERROR_DETAIL} head="ErrorDetail" />
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-semibold">SendStream</h3>
        <p className="text-sm leading-relaxed text-muted-foreground">
          For volume, open one <Code>SendService/SendStream</Code> and write{" "}
          <Code>SendStreamRequest</Code>s: a <Code>correlation_id</Code> of your choosing (1 to 64
          characters) and the <Code>SendRequest</Code>. One <Code>SendStreamResult</Code> comes back
          for each, <strong>in any order</strong>, with your <Code>correlation_id</Code>, the{" "}
          <Code>code</Code> a unary Send would have returned (0 is OK), and either the{" "}
          <Code>response</Code> or the <Code>error</Code>. A refusal is a result, not the end of the
          stream. The server holds a limited number of sends in flight per stream (256 unless your
          operator says otherwise) and stops reading while it is full, so write as fast as you like
          and let flow control pace you. If the gateway stops, unanswered sends end with{" "}
          <Code>UNAVAILABLE</Code>: resend those with their <Code>client_ref</Code>.
        </p>
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-semibold">Receipts</h3>
        <p className="text-sm leading-relaxed text-muted-foreground">
          Every receipt for a message your login sent with <Code>dlr</Code> and no{" "}
          <Code>dlr_url</Code> — over gRPC or REST — waits in one queue for your login until you
          acknowledge it. Read it either way, or both; each receipt goes to one reader.
        </p>
        <ul className="list-disc space-y-1 pl-5 text-sm leading-relaxed text-muted-foreground">
          <li>
            <Code>ReceiptService/Subscribe</Code> streams them: first everything not yet acknowledged,
            then new ones as they arrive. <Code>window</Code> caps how many are delivered and not
            yet acknowledged on the stream (the server caps it too, at 1000 by default).
          </li>
          <li>
            <Code>ReceiptService/Pull</Code> returns up to <Code>max</Code> (at most 1000) at once;
            with <Code>wait_seconds</Code> (up to 20) it waits for one when there are none.
          </li>
          <li>
            <Code>ReceiptService/Ack</Code> takes up to 1000 <Code>ack_tokens</Code> and answers how
            many were removed (<Code>acked</Code>) and how many were already gone. It is safe to
            repeat, and works from any connection.
          </li>
        </ul>
        <p className="text-sm leading-relaxed text-muted-foreground">
          <strong>At least once.</strong> A receipt is removed only by its Ack. One delivered and not
          acknowledged is offered again when its lease runs out (two minutes by default) or at once
          when its stream closes, with <Code>delivery_count</Code> above 1 — so store it, then
          acknowledge it, and treat a repeat of the same <Code>id</Code>, <Code>stat</Code> and{" "}
          <Code>level</Code> as one. The order is roughly oldest first; use <Code>level</Code> and{" "}
          <Code>done_date</Code> to tell progress from the outcome. Unread receipts are kept for a
          limited time (7 days by default) and up to a limit per login, so read the feed even when
          you are not expecting any.
        </p>
        <FieldTable rows={GRPC_RECEIPT_FIELDS} head="Receipt" />
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-semibold">Examples</h3>
        <CodeBlock
          code={sample === "grpcurl" ? grpcurlExample(where, login, exampleTo) : pythonExample(where, login, exampleTo)}
          title="Login, send, collect receipts"
          copyLabel="Copy example"
          right={
            <span className="flex gap-2">
              {SAMPLES.map((l) => (
                <button key={l} type="button" onClick={() => setSample(l)}
                  className={"text-xs " + (l === sample
                    ? "border-b border-foreground text-foreground"
                    : "text-muted-foreground hover:text-foreground")}>
                  {l}
                </button>
              ))}
            </span>
          }
        />
        <p className="text-xs text-muted-foreground">
          grpcurl prints fields in camelCase (<Code>sessionToken</Code>, <Code>messageId</Code>,{" "}
          <Code>ackToken</Code>); requests take either spelling.
        </p>
      </div>
    </section>
  );
}

function FieldTable({ rows, head }: { rows: { name: string; note: string }[]; head: string }) {
  return (
    <Table>
      <THead>
        <tr>
          <TH className="w-1/4">{head}</TH>
          <TH>Meaning</TH>
        </tr>
      </THead>
      <TBody>
        {rows.map((r) => (
          <TR key={r.name}>
            <TD className="align-top break-words font-mono text-xs">{r.name}</TD>
            <TD muted className="align-top">{r.note}</TD>
          </TR>
        ))}
      </TBody>
    </Table>
  );
}

function Fact({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded bg-muted px-2 py-1">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-foreground">{children}</span>
    </span>
  );
}

function Code({ children }: { children: React.ReactNode }) {
  return <code className="rounded bg-muted px-1 py-0.5 font-mono text-sm">{children}</code>;
}
