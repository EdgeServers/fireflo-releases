"use client";
import { Fragment, useCallback, useEffect, useMemo, useState } from "react";
import { ArrowRight, RefreshCw, Save } from "lucide-react";
import { ApplyNowButton } from "@/components/ApplyNowButton";
import { BreathingCard } from "@/components/BreathingCard";
import { useConfirmChange } from "@/components/ConfirmProvider";
import { HealthStrip } from "@/components/CardBits";
import { ErrorCard, ErrorNote } from "@/components/FormNotices";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Segmented } from "@/components/ui/segmented";
import { Select } from "@/components/ui/select";
import { SettingsRow } from "@/components/ui/settings-row";
import { SettingsSection } from "@/components/ui/settings-section";
import { StatTile } from "@/components/ui/stat-tile";
import { Switch } from "@/components/ui/switch";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import {
  CDR_ARCHIVE_KEYS,
  WAITING_LABEL,
  WEEKDAYS,
  WEEKDAY_LABEL,
  archiveSettingChanges,
  archiveSettingsConsequence,
  daySpan,
  describeSchedule,
  duration,
  formFromStorage,
  outcomeTone,
  settingsReadOnlyReason,
  validateArchiveSettings,
  type ArchiveSettingsForm,
  type CdrArchiveRun,
  type CdrStorage,
} from "@/lib/cdr-storage";
import { formatTimestamp } from "@/lib/datetime";
import { bytes, count } from "@/lib/format";
import { cn } from "@/lib/utils";
import { useDisplayZone } from "@/components/DisplayZoneProvider";

type Storage = CdrStorage & { configWritable: boolean };

type Read =
  | { state: "loading" }
  | { state: "error"; error: string }
  | { state: "unsupported"; release: string }
  | { state: "ok"; storage: Storage };

/** How many move-log rows the page shows. */
const LOG_ROWS = 100;

/**
 * Reports → Archives → Call records: the hot and archive call record tables (gateway 0.15).
 *
 * <p>Top to bottom: how it works in one line, where the tables stand, the settings (editable here,
 * written through the gateway settings route and audited like every gateway setting), the days
 * waiting to move and why, and the move log. Read from the gateway's `cdrStorage`; nothing on this
 * page moves or deletes a record -- the gateway's schedule moves days, and only the manual purge on
 * the gateway host ever deletes.
 */
export function CallRecordArchive() {
  const [read, setRead] = useState<Read>({ state: "loading" });
  const [failuresOnly, setFailuresOnly] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async (failures: boolean) => {
    setRefreshing(true);
    try {
      const res = await fetch(`/api/control/archives/cdr-storage?first=${LOG_ROWS}${failures ? "&failures=1" : ""}`, { cache: "no-store" });
      const body = await res.json().catch(() => null);
      if (!res.ok) {
        setRead({ state: "error", error: body?.error ?? `Request failed (${res.status})` });
      } else if (body?.unsupported) {
        setRead({ state: "unsupported", release: body.release ?? "0.15" });
      } else {
        setRead({ state: "ok", storage: body.data as Storage });
      }
    } catch {
      setRead({ state: "error", error: "Could not reach the panel's API." });
    } finally {
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    //eslint-disable-next-line react-hooks/set-state-in-effect -- the first read, and a re-read when the log filter changes
    void load(failuresOnly);
  }, [load, failuresOnly]);

  if (read.state === "loading") {
    return <BreathingCard what="the call record tables" retryAfter={5} />;
  }
  if (read.state === "error") {
    return <ErrorCard error={read.error} />;
  }
  if (read.state === "unsupported") {
    return (
      <Card>
        <CardContent className="space-y-2 py-5 text-sm">
          <p className="font-medium">Call-record tiers arrive with gateway {read.release}.</p>
          <p className="text-muted-foreground">
            This gateway keeps every call record in one set of tables, so there is no archive to show or schedule here. The
            panel reads those tables as before; after the upgrade, this section shows the live days, the archive and every move.
          </p>
        </CardContent>
      </Card>
    );
  }

  const s = read.storage;
  return (
    <div className="space-y-4">
      <FlowStrip storage={s} />
      {!s.tiered && (
        <HealthStrip tone="info">
          This gateway&apos;s database has not split its call records yet (migration V1.112.0). The settings below are
          kept, and take effect once it has.
        </HealthStrip>
      )}
      <Problems storage={s} />
      <StatusTiles storage={s} />
      <TablesCard storage={s} onRefresh={() => void load(failuresOnly)} refreshing={refreshing} />
      <SettingsCard storage={s} onSaved={() => void load(failuresOnly)} />
      <WaitingCard storage={s} />
      <MoveLog log={s.log} failuresOnly={failuresOnly} onFilter={setFailuresOnly} busy={refreshing} />
    </div>
  );
}

/** Live (N days) → settled → archive → purge, manual only: the whole process in one line. */
function FlowStrip({ storage: s }: { storage: Storage }) {
  const steps: { title: string; detail: string; tone?: "muted" }[] = [
    { title: `Live, ${s.hotDays} days`, detail: "today and the days before it, where traffic is written" },
    { title: "Settled", detail: "receipts window closed, summarised hourly and daily" },
    { title: "Archive", detail: `moved ${describeSchedule(s.schedule).replace(/^Daily/, "daily")}; same rows, same database` },
    { title: "Purge", detail: "manual only, on the gateway host", tone: "muted" },
  ];
  return (
    <Card>
      <CardContent className="py-3">
        <ol className="flex flex-col gap-2 text-sm sm:flex-row sm:flex-wrap sm:items-center" aria-label="How call records are kept">
          {steps.map((step, i) => (
            <Fragment key={step.title}>
              {i > 0 && <ArrowRight className="hidden h-4 w-4 shrink-0 text-muted-foreground sm:block" aria-hidden />}
              <li className="min-w-0">
                <span className={cn("font-medium", step.tone === "muted" && "text-muted-foreground")}>{step.title}</span>
                <span className="text-muted-foreground"> · {step.detail}</span>
              </li>
            </Fragment>
          ))}
        </ol>
      </CardContent>
    </Card>
  );
}

/** Why nothing moves, the last failure, rows in the safety net. Absent when all is well. */
function Problems({ storage: s }: { storage: Storage }) {
  const { zone } = useDisplayZone();
  return (
    <>
      {s.refusal && <HealthStrip tone="destructive">Nothing moves right now: {s.refusal}</HealthStrip>}
      {s.lastError && (
        <HealthStrip tone="destructive">
          The last move failed{s.lastErrorAt ? ` at ${formatTimestamp(s.lastErrorAt, zone)}` : ""}: {s.lastError}. The day stayed
          live; the next run tries again.
        </HealthStrip>
      )}
      {s.hotDefaultRows > 0 && !s.refusal && (
        <HealthStrip>
          {count(s.hotDefaultRows)} rows are in the live tables&apos; default partitions (dated outside the days they hold).
          No move runs until they are dealt with.
        </HealthStrip>
      )}
      {!s.enabled && s.tiered && <HealthStrip tone="info">Moves are off: every day stays live until they are switched on.</HealthStrip>}
      {s.enabled && !s.scheduleValid && (
        <HealthStrip>The schedule &quot;{s.schedule}&quot; does not parse, so nothing moves. Set it below.</HealthStrip>
      )}
    </>
  );
}

function StatusTiles({ storage: s }: { storage: Storage }) {
  const { zone } = useDisplayZone();
  const last = s.log.find((r) => r.table === "*" || r.outcome === "moved") ?? s.log[0];
  const lastOutcome = s.lastError && (!s.lastMoveAt || (s.lastErrorAt ?? "") > s.lastMoveAt) ? "failed" : s.lastMoveAt ? "moved" : null;
  return (
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
      <StatTile
        label="Live"
        value={`${s.hotDays} days`}
        hint={s.hotFrom ? `from ${formatTimestamp(s.movingTo && s.movingTo > s.hotFrom ? s.movingTo : s.hotFrom, zone)}` : "not split yet"}
        footnote={
          <p className="text-xs text-muted-foreground">
            ≈{count(s.hot.rowsEstimate)} rows · {bytes(s.hot.bytes)}
            {s.movingTo && <Badge variant="warning" className="ml-2">moving</Badge>}
          </p>
        }
      />
      <StatTile
        label="Archive"
        value={s.archive.oldestDay ? daySpan(s.archive.oldestDay, s.archive.newestDay).replace(/^.*, /, "") : "empty"}
        hint={s.archive.oldestDay ? `${s.archive.oldestDay} → ${s.archive.newestDay}` : "nothing moved yet"}
        footnote={<p className="text-xs text-muted-foreground">≈{count(s.archive.rowsEstimate)} rows · {bytes(s.archive.bytes)}</p>}
      />
      <StatTile
        label="Last move"
        value={s.lastMoveDay ?? "none yet"}
        chip={lastOutcome ? [lastOutcome, lastOutcome === "moved" ? "success" : "destructive"] : undefined}
        hint={s.lastMoveAt ? formatTimestamp(s.lastMoveAt, zone) : s.lastRunAt ? `last run ${formatTimestamp(s.lastRunAt, zone)}` : undefined}
        footnote={last ? <p className="text-xs text-muted-foreground">took {duration(last.ms)}</p> : undefined}
      />
      <StatTile
        label="Next move"
        value={s.nextMoveAt ? formatTimestamp(s.nextMoveAt, zone) : s.enabled ? "not scheduled" : "off"}
        hint={describeSchedule(s.schedule)}
        footnote={
          s.ready.length > 0 ? (
            <p className="text-xs text-muted-foreground">ready: {s.ready.join(", ")}</p>
          ) : (
            <p className="text-xs text-muted-foreground">no settled day is old enough yet</p>
          )
        }
      />
    </div>
  );
}

/** Each table's two sides, for the operator asking where the bytes are. */
function TablesCard({ storage: s, onRefresh, refreshing }: { storage: Storage; onRefresh: () => void; refreshing: boolean }) {
  return (
    <SettingsSection
      id="cdr-tables"
      title="Tables"
      description="Rows are the planner's estimates, not counts. Days are cdr_submit's, where the money is."
      action={
        <Button variant="outline" size="sm" className="gap-2" onClick={onRefresh} disabled={refreshing}>
          <RefreshCw className={cn("h-4 w-4", refreshing && "animate-spin")} aria-hidden /> Refresh
        </Button>
      }
      bodyClassName="p-0"
    >
      <TableInCard>
        <THead>
          <TR>
            <TH>Table</TH>
            <TH align="right">Live rows ≈</TH>
            <TH align="right">Live size</TH>
            <TH>Live days</TH>
            <TH align="right">Archive rows ≈</TH>
            <TH align="right">Archive size</TH>
            <TH>Archive days</TH>
          </TR>
        </THead>
        <TBody>
          {s.tables.map((t) => (
            <TR key={t.table}>
              <TD className="font-mono text-xs">
                {t.table}
                {t.hotDefaultRows > 0 && <Badge variant="warning" className="ml-2">{count(t.hotDefaultRows)} in default</Badge>}
              </TD>
              <TD align="right">{count(t.hot.rowsEstimate)}</TD>
              <TD align="right" muted>{bytes(t.hot.bytes)}</TD>
              <TD muted className="whitespace-nowrap">{daySpan(t.hot.oldestDay, t.hot.newestDay)}</TD>
              <TD align="right">{count(t.archive.rowsEstimate)}</TD>
              <TD align="right" muted>{bytes(t.archive.bytes)}</TD>
              <TD muted className="whitespace-nowrap">{daySpan(t.archive.oldestDay, t.archive.newestDay)}</TD>
            </TR>
          ))}
          {s.tables.length === 0 && (
            <TR>
              <TD colSpan={7} muted>No call record tables reported.</TD>
            </TR>
          )}
        </TBody>
      </TableInCard>
    </SettingsSection>
  );
}

/** The four settings, editable when the gateway reads them from the database and this panel can write. */
function SettingsCard({ storage: s, onSaved }: { storage: Storage; onSaved: () => void }) {
  const { zone } = useDisplayZone();
  const confirm = useConfirmChange();
  const stored = useMemo(() => formFromStorage(s), [s]);
  const [form, setForm] = useState<ArchiveSettingsForm>(stored);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  //a fresh reading from the gateway replaces the form, as long as nothing is being edited
  const [seen, setSeen] = useState(stored);
  if (seen !== stored) {
    setSeen(stored);
    setForm(stored);
  }

  const readOnly = settingsReadOnlyReason(s, s.configWritable);
  const errors = validateArchiveSettings(form);
  const valid = Object.keys(errors).length === 0;
  const changes = valid ? archiveSettingChanges(s, form, new Date(), zone) : [];
  const set = <K extends keyof ArchiveSettingsForm>(key: K, value: ArchiveSettingsForm[K]) => {
    setSaved(false);
    setForm((f) => ({ ...f, [key]: value }));
  };

  async function save() {
    if (!valid || changes.length === 0) {
      return;
    }
    const ok = await confirm({
      title: "Change the call record archive",
      consequence: archiveSettingsConsequence(changes),
      confirmLabel: changes.length === 1 ? "Save the change" : `Save ${changes.length} changes`,
      tone: "caution",
      changes,
    });
    if (!ok) {
      return;
    }
    setSaving(true);
    setError(null);
    try {
      //one key at a time, stopping at the first refusal, as the Gateway page saves: each write is an
      //audit line, and a half-applied set must say which half
      for (const c of changes) {
        const res = await fetch("/api/control/gateway-settings", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ key: c.key, value: c.value }),
        });
        const body = await res.json().catch(() => null);
        if (!res.ok) {
          setError(`${c.label}: ${body?.error ?? `refused (${res.status})`}`);
          onSaved();
          return;
        }
      }
      setSaved(true);
      onSaved();
    } catch {
      setError("Could not reach the panel's API.");
    } finally {
      setSaving(false);
    }
  }

  const disabled = readOnly !== null || saving;
  return (
    <SettingsSection
      id="cdr-archive-settings"
      title="Archive settings"
      description={readOnly ?? "Saved to the gateway's configuration; it takes them up at its next poll (30 s), or at once with Apply now."}
      action={
        readOnly === null && (
          <Button className="gap-2" onClick={() => void save()} disabled={disabled || !valid || changes.length === 0}>
            <Save className="h-4 w-4" aria-hidden /> {saving ? "Saving…" : "Save"}
          </Button>
        )
      }
    >
      <SettingsRow
        label="Days kept live"
        htmlFor="cdr-hot-days"
        help="Today and the days before it stay in the live tables; older settled days move to the archive. At least 3: receipts arrive for two days after a message."
        keyName={CDR_ARCHIVE_KEYS.hotDays}
        tone={errors.hotDays ? "invalid" : form.hotDays !== stored.hotDays ? "unsaved" : undefined}
      >
        <Input id="cdr-hot-days" type="number" min={3} inputMode="numeric" value={form.hotDays} disabled={disabled}
          aria-invalid={errors.hotDays ? true : undefined} aria-describedby={errors.hotDays ? "cdr-hot-days-error" : undefined}
          onChange={(e) => set("hotDays", e.target.value)} />
        {errors.hotDays && <p id="cdr-hot-days-error" className="mt-1 text-xs text-destructive">{errors.hotDays}</p>}
      </SettingsRow>
      <SettingsRow
        label="Schedule"
        labelId="cdr-schedule-label"
        help="When settled days move, in UTC. A weekly move takes every settled day at once."
        keyName={CDR_ARCHIVE_KEYS.schedule}
        tone={errors.time ? "invalid" : form.cadence !== stored.cadence || form.time !== stored.time
          || (form.cadence === "weekly" && form.weekday !== stored.weekday) ? "unsaved" : undefined}
      >
        <div className="flex flex-wrap items-center gap-2 md:justify-end">
          <Segmented label="How often" value={form.cadence} disabled={disabled}
            options={[{ value: "daily", label: "Daily" }, { value: "weekly", label: "Weekly" }]}
            onChange={(v) => set("cadence", v)} />
          {form.cadence === "weekly" && (
            <Select aria-label="Weekday" value={form.weekday} disabled={disabled} className="w-36"
              onChange={(e) => set("weekday", e.target.value as ArchiveSettingsForm["weekday"])}>
              {WEEKDAYS.map((d) => <option key={d} value={d}>{WEEKDAY_LABEL[d]}</option>)}
            </Select>
          )}
          <Input aria-label="Time, UTC" type="time" className="w-32" value={form.time} disabled={disabled}
            aria-invalid={errors.time ? true : undefined} onChange={(e) => set("time", e.target.value)} />
          <span className="text-xs text-muted-foreground">UTC</span>
        </div>
        {errors.time && <p className="mt-1 text-xs text-destructive">{errors.time}</p>}
      </SettingsRow>
      <SettingsRow
        label="Move days to the archive"
        labelId="cdr-enabled-label"
        help="Off, nothing moves and the live tables keep growing. Every reader still finds every record."
        keyName={CDR_ARCHIVE_KEYS.enabled}
        tone={form.enabled !== stored.enabled ? "unsaved" : undefined}
      >
        <Switch checked={form.enabled} disabled={disabled} aria-labelledby="cdr-enabled-label" onChange={(v) => set("enabled", v)} />
      </SettingsRow>
      <SettingsRow
        label="CSV copy on each move"
        labelId="cdr-export-label"
        help={<>Each billing day whose records have all moved is also written as CSV.gz with a SHA-256 manifest, the files <code className="font-mono">fireflo cdr archive</code> writes, to <code className="break-all font-mono">{s.exportDir || "FIREFLO_ARCHIVE_DIR"}</code> on the node that moved it. The folder is set on the gateway host (FIREFLO_ARCHIVE_DIR).</>}
        keyName={CDR_ARCHIVE_KEYS.export}
        tone={form.export !== stored.export ? "unsaved" : undefined}
      >
        <Switch checked={form.export} disabled={disabled} aria-labelledby="cdr-export-label" onChange={(v) => set("export", v)} />
      </SettingsRow>
      <SettingsRow
        label="Purge"
        help={<>Nothing deletes call records automatically. The purge is run by hand on the gateway host and keeps the last {s.purgeKeepDays} days (FIREFLO_CDR_KEEP_DAYS); it refuses a day the summaries have not covered.</>}
      >
        <code className="block break-all rounded-md bg-muted px-2 py-1.5 font-mono text-xs">{s.purgeCommand}</code>
      </SettingsRow>
      {(error || saved) && (
        <div className="px-4 py-3 md:px-5">
          {error ? <ErrorNote error={error} /> : <ApplyNowButton compact />}
        </div>
      )}
    </SettingsSection>
  );
}

function WaitingCard({ storage: s }: { storage: Storage }) {
  return (
    <SettingsSection
      id="cdr-waiting"
      title="Waiting to move"
      description="Days old enough to leave the live tables that are not settled yet. Days move in order, so one waiting day holds back the ones after it."
      bodyClassName="p-0"
    >
      {s.waiting.length === 0 ? (
        <p className="px-4 py-4 text-sm text-muted-foreground md:px-5">
          {s.ready.length > 0 ? `Nothing waiting: ${s.ready.join(", ")} move at the next run.` : "Nothing waiting."}
        </p>
      ) : (
        <TableInCard>
          <THead>
            <TR>
              <TH>Day (UTC)</TH>
              <TH>Waiting for</TH>
              <TH>Detail</TH>
            </TR>
          </THead>
          <TBody>
            {s.waiting.map((w) => (
              <TR key={w.day}>
                <TD className="whitespace-nowrap font-mono">{w.day}</TD>
                <TD className="whitespace-nowrap">{WAITING_LABEL[w.reason] ?? w.reason}</TD>
                <TD muted>{w.detail}</TD>
              </TR>
            ))}
          </TBody>
        </TableInCard>
      )}
    </SettingsSection>
  );
}

function MoveLog({ log, failuresOnly, onFilter, busy }: {
  log: CdrArchiveRun[];
  failuresOnly: boolean;
  onFilter: (next: boolean) => void;
  busy: boolean;
}) {
  const { zone, short } = useDisplayZone();
  return (
    <SettingsSection
      id="cdr-move-log"
      title="Move log"
      description="Every run, newest first, one row per day and table it considered -- including the runs that moved nothing. Kept 180 days."
      action={
        <Segmented label="Which runs" value={failuresOnly ? "failed" : "all"} busy={busy}
          options={[{ value: "all", label: "All" }, { value: "failed", label: "Failures" }]}
          onChange={(v) => onFilter(v === "failed")} />
      }
      bodyClassName="p-0"
    >
      {log.length === 0 ? (
        <p className="px-4 py-4 text-sm text-muted-foreground md:px-5">
          {failuresOnly ? "No move has failed." : "No run yet. The first runs at the next scheduled time."}
        </p>
      ) : (
        <TableInCard>
          <THead>
            <TR>
              <TH>Started ({short})</TH>
              <TH>Node</TH>
              <TH>Day</TH>
              <TH>Table</TH>
              <TH align="right">Rows before</TH>
              <TH align="right">After</TH>
              <TH align="right">Time</TH>
              <TH>Outcome</TH>
            </TR>
          </THead>
          <TBody>
            {log.map((r, i) => (
              <TR key={`${r.runId ?? "run"}-${r.day ?? ""}-${r.table}-${i}`} className="align-top">
                <TD muted className="whitespace-nowrap">{r.startedAt ? formatTimestamp(r.startedAt, zone) : "—"}</TD>
                <TD className="font-mono text-xs">{r.nodeId || "—"}</TD>
                <TD className="whitespace-nowrap font-mono text-xs">{r.day ?? "—"}</TD>
                <TD className="font-mono text-xs">{r.table === "*" ? "whole run" : r.table}</TD>
                <TD align="right">{r.rowsBefore != null ? count(r.rowsBefore) : "—"}</TD>
                <TD align="right" className={r.rowsBefore != null && r.rowsAfter != null && r.rowsAfter !== r.rowsBefore ? "text-destructive" : undefined}>
                  {r.rowsAfter != null ? count(r.rowsAfter) : "—"}
                </TD>
                <TD align="right" muted className="whitespace-nowrap">{duration(r.ms)}</TD>
                <TD className="max-w-[22rem] text-xs">
                  <Badge variant={outcomeTone(r.outcome)}>{r.outcome}</Badge>
                  {r.reason && <div className="mt-1 break-words text-muted-foreground">{r.reason}</div>}
                  {r.error && <div className="mt-1 break-words text-destructive">{r.error}</div>}
                </TD>
              </TR>
            ))}
          </TBody>
        </TableInCard>
      )}
    </SettingsSection>
  );
}
