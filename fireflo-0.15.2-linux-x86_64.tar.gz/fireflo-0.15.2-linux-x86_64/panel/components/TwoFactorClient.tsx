"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { signOut } from "next-auth/react";
import { Loader2, ShieldCheck } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClasses } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { PasswordInput } from "@/components/ui/password-input";
import { formatTimestamp } from "@/lib/datetime";
import { cleanCode, TOTP_LOST } from "@/lib/totp-signin";
import { TOTP_UNAVAILABLE, TOTP_UNSEALED, type TotpSetup, type TotpView } from "@/lib/totp-view";
import { useDisplayZone } from "@/components/DisplayZoneProvider";

/**
 * The operator's two-factor screen: off, setting up (the QR code, the key, the first code), or on
 * (since when, and turning it off with the password and a code). When two-factor is required of
 * every operator and this one has none, it is the only screen they can reach until it is set up.
 */
export function TwoFactorClient() {
  const { zone } = useDisplayZone();
  const [view, setView] = useState<TotpView | null>(null);
  const [setup, setSetup] = useState<TotpSetup | null>(null);
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const res = await fetch("/api/control/me/totp", { cache: "no-store" });
    const body = await res.json().catch(() => null);
    if (!res.ok) {
      //refused: this session is no longer good (stale, or not verified with the authenticator)
      window.location.assign("/cp/login");
      return;
    }
    setView(body.data as TotpView);
  }, []);

  useEffect(() => {
    //eslint-disable-next-line react-hooks/set-state-in-effect -- the first read
    void load();
  }, [load]);

  async function act(action: "start" | "confirm" | "disable") {
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const res = await fetch("/api/control/me/totp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, code, password }),
      });
      const body = await res.json().catch(() => null);
      if (!res.ok) {
        setError(body?.error ?? `Request failed (${res.status})`);
        setCode("");
        return;
      }
      const next = body.data as TotpView & { setup?: TotpSetup; keptSignedIn?: boolean };
      setView(next);
      setCode("");
      setPassword("");
      if (action === "start") {
        setSetup(next.setup ?? null);
      } else if (action === "confirm") {
        setSetup(null);
        setNotice(next.keptSignedIn === false
          ? "Two-factor authentication is on. Sign in again, with a code, to carry on."
          : "Two-factor authentication is on. Every other browser signed in as you will be asked to sign in with a code.");
      } else {
        setNotice("Two-factor authentication is off. Signing in needs only your password again.");
      }
    } finally {
      setBusy(false);
    }
  }

  if (!view) {
    return <p className="text-sm text-muted-foreground">Loading…</p>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-page">Two-factor authentication</h1>
        {view.available && !view.enrolmentDue && (
          <Link href="/cp" className={buttonClasses({ variant: "outline", size: "sm" })}>Back to the panel</Link>
        )}
      </div>

      {!view.available ? (
        <Card>
          <CardContent className="py-5 text-sm text-muted-foreground">{TOTP_UNAVAILABLE[view.reason]}</CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-muted-foreground" aria-hidden />
              Authenticator app
              {view.enabled ? <Badge variant="success">On</Badge> : <Badge variant="outline">Off</Badge>}
              {view.required && <Badge variant="info">Required for operators</Badge>}
            </CardTitle>
            <CardDescription>
              {view.enabled
                ? `On since ${view.enabledAt ? formatTimestamp(view.enabledAt, zone) : "—"}. Signing in as ${view.email} asks for a code from your authenticator after the password or the link.`
                : "After your password (or a sign-in link), the panel also asks for a six-digit code from an authenticator app on your phone: Google Authenticator, Microsoft Authenticator, 1Password, Authy or any other."}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {view.enrolmentDue && !setup && (
              <p className="rounded-md border border-info/40 bg-info-soft p-3 text-sm">
                Your administrator requires two-factor authentication for every operator. Set it up to carry on;
                until then the rest of the panel is closed to this account.
              </p>
            )}

            {view.unsealed && (
              <p className="rounded-md border border-warning/40 bg-warning-soft p-3 text-sm text-warning" role="status">
                {TOTP_UNSEALED}
              </p>
            )}

            {!view.enabled && !setup && (
              //the password first, as a password change asks for it: a cookie left in a browser must
              //not be enough to put an authenticator on this account
              <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); void act("start"); }}>
                <Field label="Your password" htmlFor="totp-start-password">
                  <PasswordInput id="totp-start-password" autoComplete="current-password" value={password}
                    onChange={(e) => setPassword(e.target.value)} />
                </Field>
                <Button type="submit" disabled={busy || !password} className="gap-2">
                  {busy && <Loader2 className="h-4 w-4 animate-spin" />}
                  Set up an authenticator
                </Button>
              </form>
            )}

            {!view.enabled && setup && (
              <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); void act("confirm"); }}>
                <ol className="list-decimal space-y-1 pl-5 text-sm">
                  <li>Open your authenticator app and add an account.</li>
                  <li>Scan this code, or type the key below it.</li>
                  <li>Enter the six-digit code the app then shows.</li>
                </ol>
                {/* eslint-disable-next-line @next/next/no-img-element -- an inline SVG data URI drawn on the server */}
                <img src={setup.qr} alt="QR code for the authenticator app" width={192} height={192}
                  className="rounded-md border border-border bg-white p-2" />
                <div>
                  <p className="text-xs text-muted-foreground">Key, if your app cannot scan</p>
                  <p className="select-all break-all font-mono text-sm tracking-wider">{setup.key}</p>
                </div>
                <Field label="Code from the app" htmlFor="totp-confirm">
                  <Input id="totp-confirm" inputMode="numeric" autoComplete="one-time-code" placeholder="123 456"
                    className="max-w-[12rem] font-mono tracking-[0.3em]" value={code}
                    onChange={(e) => setCode(cleanCode(e.target.value))} autoFocus />
                </Field>
                <p className="text-xs text-muted-foreground">The set-up lapses after 15 minutes; start again if it does.</p>
                <div className="flex gap-2">
                  <Button type="submit" disabled={busy || code.length !== 6}>Turn on</Button>
                  <Button type="button" variant="outline" disabled={busy} onClick={() => { setSetup(null); setCode(""); }}>Cancel</Button>
                </div>
              </form>
            )}

            {view.enabled && (
              view.required ? (
                <p className="text-sm text-muted-foreground">
                  Required for every operator, so it cannot be turned off here. {TOTP_LOST}
                </p>
              ) : (
                <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); void act("disable"); }}>
                  <p className="text-sm font-medium">Turn off</p>
                  <Field label="Password" htmlFor="totp-off-password">
                    <PasswordInput id="totp-off-password" autoComplete="current-password" value={password}
                      onChange={(e) => setPassword(e.target.value)} />
                  </Field>
                  <Field label="Current code" htmlFor="totp-off-code">
                    <Input id="totp-off-code" inputMode="numeric" autoComplete="one-time-code" placeholder="123 456"
                      className="max-w-[12rem] font-mono tracking-[0.3em]" value={code}
                      onChange={(e) => setCode(cleanCode(e.target.value))} />
                  </Field>
                  <Button type="submit" variant="outline" disabled={busy || !password || code.length !== 6}>
                    Turn off two-factor authentication
                  </Button>
                </form>
              )
            )}

            {error && <p className="text-sm text-destructive" role="alert">{error}</p>}
            {notice && <p className="text-sm text-success" role="status">{notice}</p>}
          </CardContent>
        </Card>
      )}

      {view.available && view.enrolmentDue && (
        <Button variant="ghost" onClick={() => void signOut({ callbackUrl: "/cp/login" })}>Sign out</Button>
      )}
      {view.available && !view.enrolmentDue && notice && (
        <Link href="/cp" className={buttonClasses({ size: "sm" })}>Continue to the panel</Link>
      )}
    </div>
  );
}
