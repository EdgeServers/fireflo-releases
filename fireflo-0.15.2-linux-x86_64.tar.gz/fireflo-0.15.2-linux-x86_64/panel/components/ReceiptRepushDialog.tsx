"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { isoToLocal, localToIso } from "@/lib/cdr-request";
import { formatTimestamp } from "@/lib/datetime";
import {
  DEFAULT_REPUSH_TPS,
  MAX_REPUSH_DAYS,
  REPUSH_POLL_MS,
  REPUSH_STATES,
  dryRunSentence,
  finishedSentence,
  humanSeconds,
  isRunning,
  jobStorageKey,
  progressPercent,
  readJobId,
  readRepushDryRun,
  readRepushStatus,
  repushProblem,
  statusLine,
  type RepushDryRun,
  type RepushForm,
  type RepushStatus,
} from "@/lib/receipt-repush";
import { useDisplayZone } from "@/components/DisplayZoneProvider";
import { localeNumber } from "@/lib/format";

type Stage = "form" | "dry" | "job";

function remembered(systemId: string): string | null {
  try {
    return window.localStorage.getItem(jobStorageKey(systemId));
  } catch {
    return null;
  }
}

function remember(systemId: string, jobId: string | null) {
  try {
    if (jobId) {
      window.localStorage.setItem(jobStorageKey(systemId), jobId);
    } else {
      window.localStorage.removeItem(jobStorageKey(systemId));
    }
  } catch {
    //a blocked storage costs only the resume-on-reopen
  }
}

async function post(body: unknown): Promise<{ data: unknown } | { error: string }> {
  try {
    const res = await fetch("/api/control/receipts/repush", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const json = await res.json().catch(() => null);
    return res.ok ? { data: json?.data } : { error: json?.error ?? `The gateway refused (${res.status}).` };
  } catch {
    return { error: "Could not reach the panel's API." };
  }
}

/**
 * Re-send receipts… for one SMPP login: choose the period, the outcomes and the rate, read what
 * would be sent, start it, watch it, cancel it.
 *
 * <p>Admin only — the caller renders the trigger only for admins and the route refuses everyone
 * else. The job runs on the gateway, not in this tab: closing the dialog does not stop it, and
 * reopening it for the same login resumes the progress bar from the job id remembered in this
 * browser. Finished jobs are listed on Reports → Archives → Batches.
 */
export function ReceiptRepushDialog({
  systemId,
  account,
  onClose,
}: {
  systemId: string;
  account?: string | null;
  onClose: () => void;
}) {
  const { zone, short } = useDisplayZone();
  const [stage, setStage] = useState<Stage>("form");
  const [form, setForm] = useState<RepushForm>(() => {
    const now = new Date();
    return {
      since: new Date(now.getTime() - 86_400_000).toISOString(),
      until: now.toISOString(),
      states: REPUSH_STATES.map((s) => s.value),
      includeProgress: false,
      tps: String(DEFAULT_REPUSH_TPS),
      note: "",
    };
  });
  const [dry, setDry] = useState<RepushDryRun | null>(null);
  const [jobId, setJobId] = useState<string | null>(null);
  const [status, setStatus] = useState<RepushStatus | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const set = <K extends keyof RepushForm>(key: K, value: RepushForm[K]) => setForm((f) => ({ ...f, [key]: value }));

  //a job started earlier from this browser for this login: go straight to its progress
  useEffect(() => {
    const id = remembered(systemId);
    if (id) {
      //eslint-disable-next-line react-hooks/set-state-in-effect -- storage is only readable after mount
      setJobId(id);
      setStage("job");
    }
  }, [systemId]);

  const poll = useCallback(async (id: string) => {
    try {
      const res = await fetch(`/api/control/receipts/repush/${encodeURIComponent(id)}`, { cache: "no-store" });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Could not read the job (${res.status}).`);
        //a job the gateway no longer knows (it restarted) is not worth resuming next time
        if (res.status === 404 || res.status === 502) remember(systemId, null);
        return false;
      }
      const s = readRepushStatus(json?.data);
      setStatus(s);
      setError("");
      if (!isRunning(s.state)) {
        remember(systemId, null);
        return false;
      }
      return true;
    } catch {
      setError("Could not reach the panel's API.");
      return true;
    }
  }, [systemId]);

  useEffect(() => {
    if (stage !== "job" || !jobId) {
      return;
    }
    let live = true;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const tick = async () => {
      const again = await poll(jobId);
      if (live && again) {
        timer = setTimeout(tick, REPUSH_POLL_MS);
      }
    };
    void tick();
    return () => {
      live = false;
      if (timer) clearTimeout(timer);
    };
  }, [stage, jobId, poll]);

  async function dryRun() {
    const problem = repushProblem(form);
    if (problem) {
      setError(problem);
      return;
    }
    setBusy(true);
    setError("");
    const r = await post({ systemId, account, ...form, dryRun: true });
    setBusy(false);
    if ("error" in r) {
      setError(r.error);
      return;
    }
    setDry(readRepushDryRun(r.data));
    setStage("dry");
  }

  async function start() {
    setBusy(true);
    setError("");
    const r = await post({ systemId, account, ...form, dryRun: false });
    setBusy(false);
    if ("error" in r) {
      setError(r.error);
      return;
    }
    const id = readJobId(r.data);
    if (!id) {
      setError("The gateway started nothing it could name. Check Reports → Archives → Batches before trying again.");
      return;
    }
    remember(systemId, id);
    setStatus(null);
    setJobId(id);
    setStage("job");
  }

  async function cancel() {
    if (!jobId) return;
    setBusy(true);
    try {
      const res = await fetch(`/api/control/receipts/repush/${encodeURIComponent(jobId)}`, { method: "DELETE" });
      const json = await res.json().catch(() => null);
      if (!res.ok) setError(json?.error ?? `The gateway refused (${res.status}).`);
      await poll(jobId);
    } finally {
      setBusy(false);
    }
  }

  const tps = Number(form.tps) || DEFAULT_REPUSH_TPS;
  const running = !!status && isRunning(status.state);

  return (
    <Dialog open onClose={onClose} title={`Re-send receipts to ${systemId}`} className="max-w-lg">
      <div className="space-y-4 text-sm">
        {stage === "form" && (
          <>
            <p className="text-muted-foreground">
              Rebuilt from the call records with the message ids the customer was given, and sent the way a live receipt
              is: on the login&apos;s sessions if it is bound, otherwise stored and replayed when it next binds. The customer
              receives them again for messages they may already have closed. At most {MAX_REPUSH_DAYS} days per run.
            </p>
            <div className="grid gap-3 sm:grid-cols-2">
              {/* typed in the display zone, held as the instant it names */}
              <Field label={`From (${short})`}>
                <Input type="datetime-local" value={isoToLocal(form.since, zone)} onChange={(e) => set("since", localToIso(e.target.value, zone))} />
              </Field>
              <Field label={`To (${short})`}>
                <Input type="datetime-local" value={isoToLocal(form.until, zone)} onChange={(e) => set("until", localToIso(e.target.value, zone))} />
              </Field>
            </div>
            <fieldset className="space-y-1.5">
              <legend className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Outcomes</legend>
              <div className="flex flex-wrap gap-x-4 gap-y-1">
                {REPUSH_STATES.map((s) => (
                  <label key={s.value} className="flex items-center gap-1.5">
                    <input
                      type="checkbox"
                      checked={form.states.includes(s.value)}
                      onChange={(e) =>
                        set("states", e.target.checked ? [...form.states, s.value] : form.states.filter((v) => v !== s.value))
                      }
                    />
                    {s.label} <span className="font-mono text-xs text-muted-foreground">{s.stat}</span>
                  </label>
                ))}
              </div>
              <label className="flex items-center gap-1.5">
                <input type="checkbox" checked={form.includeProgress} onChange={(e) => set("includeProgress", e.target.checked)} />
                Also progress receipts (ACCEPTD, BUFFRED, ENROUTE)
              </label>
            </fieldset>
            <Field label="Rate" hint="Receipts a second. The gateway also holds it to the login's own limit.">
              <Input value={form.tps} onChange={(e) => set("tps", e.target.value)} inputMode="numeric" className="w-28" />
            </Field>
            <Field label="Note" hint="Why. Recorded with the job and in the operator log.">
              <Textarea value={form.note} onChange={(e) => set("note", e.target.value)} rows={2} placeholder="customer lost receipts in their outage" />
            </Field>
            {error && <p className="text-destructive">{error}</p>}
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
              <Button size="sm" disabled={busy} onClick={dryRun}>{busy ? "Counting…" : "Check what would be sent"}</Button>
            </div>
          </>
        )}

        {stage === "dry" && dry && (
          <>
            <p className="font-medium">{dryRunSentence(dry, tps)}.</p>
            {Object.keys(dry.byState).length > 0 && (
              <p className="text-xs text-muted-foreground">
                {Object.entries(dry.byState).map(([k, n]) => `${k} ${localeNumber(n)}`).join(" · ")}
              </p>
            )}
            {dry.skippedPending > 0 && (
              <p className="text-xs text-muted-foreground">
                {localeNumber(dry.skippedPending)} still pending are skipped: they have no outcome to report yet.
              </p>
            )}
            {error && <p className="text-destructive">{error}</p>}
            <div className="flex justify-end gap-2">
              <Button variant="ghost" size="sm" disabled={busy} onClick={() => setStage("form")}>Back</Button>
              <Button variant="outline" size="sm" disabled={busy} onClick={onClose}>Cancel</Button>
              <Button size="sm" disabled={busy || dry.receipts === 0} onClick={start}>
                {busy ? "Starting…" : `Re-send ${localeNumber(dry.receipts)}`}
              </Button>
            </div>
          </>
        )}

        {stage === "job" && (
          <>
            {!status && !error && (
              <p className="text-muted-foreground"><Loader2 className="mr-2 inline h-4 w-4 animate-spin" />Reading the job…</p>
            )}
            {status && (
              <>
                <div className="h-2 overflow-hidden rounded-full bg-muted" aria-hidden>
                  <div className="h-full bg-primary transition-all" style={{ width: `${progressPercent(status)}%` }} />
                </div>
                <p className="tabular-nums">{statusLine(status)}</p>
                <p className="text-xs text-muted-foreground">
                  {status.startedAt && `Started ${formatTimestamp(status.startedAt, zone)}. `}
                  {running && status.eta != null && (typeof status.eta === "number" ? `About ${humanSeconds(status.eta)} left.` : `Expected to finish ${formatTimestamp(status.eta, zone)}.`)}
                  {!running && finishedSentence(status)}
                </p>
              </>
            )}
            {error && <p className="text-destructive">{error}</p>}
            <p className="text-xs text-muted-foreground">
              The job runs on the gateway: closing this does not stop it. Finished runs are listed on{" "}
              <Link href="/cp/archives?tab=batches" className="text-primary hover:underline">Reports → Archives → Batches</Link>.
            </p>
            <div className="flex justify-end gap-2">
              {running && (
                <Button variant="outline" size="sm" disabled={busy} onClick={cancel}
                  className="text-destructive hover:bg-destructive/10">
                  {busy ? "Cancelling…" : "Cancel the job"}
                </Button>
              )}
              {!running && status && (
                <Button variant="ghost" size="sm" onClick={() => { setStage("form"); setJobId(null); setStatus(null); setDry(null); }}>
                  Another period
                </Button>
              )}
              <Button size="sm" onClick={onClose}>Close</Button>
            </div>
          </>
        )}
      </div>
    </Dialog>
  );
}
