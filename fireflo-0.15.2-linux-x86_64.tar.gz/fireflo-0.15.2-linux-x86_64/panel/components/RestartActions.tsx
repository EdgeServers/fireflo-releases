"use client";
import { useId, useState } from "react";
import { useSession } from "next-auth/react";
import { Loader2, Plug, PlugZap, RotateCcw, RotateCw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog } from "@/components/ui/dialog";
import { Field } from "@/components/ui/field";
import { Select } from "@/components/ui/select";
import { HealthStrip } from "./CardBits";
import { COMPONENT_RESTART, hasCapability } from "@/lib/capabilities";
import { formatClockTime } from "@/lib/datetime";
import { count } from "@/lib/format";
import { useDisplayZone } from "@/components/DisplayZoneProvider";
import type { Health } from "@/lib/health-types";
import { isAdminSession } from "@/lib/roles";
import { cn } from "@/lib/utils";
import {
  HARD_HELP,
  PERSIST_STREAMS,
  RESTART_COPY,
  STREAM_LABEL,
  figureRows,
  parseRestartResult,
  refusalSentence,
  restartCommand,
  stateTone,
  tookLabel,
  type QueuesRestartPart,
  type RestartResult,
} from "@/lib/gateway-restart";

/**
 * The Queues page's Restart rows (0.15.2): one internal part of the running gateway restarted
 * without restarting the process, from the card the part belongs to.
 *
 * <p>Shown to admins only, and only when the gateway advertises `component_restart`; a read-only
 * operator sees the same cards without them. The route refuses everyone else regardless. The words
 * -- each button's help, the confirmation's facts -- are `RESTART_COPY` in `lib/gateway-restart.ts`,
 * so what the help promises and what the confirmation promises are one text.
 */

/** Whether this viewer gets the Restart rows: an admin, on a gateway that can restart its parts. */
export function useRestartAllowed(health: Health | null | undefined): boolean {
  const { data: session } = useSession();
  return isAdminSession(session) && hasCapability(health, COMPONENT_RESTART);
}

/**
 * The Restart row a card's footer gets above its existing link: a small label, "admin only", then
 * the actions side by side from `sm` up.
 */
export function RestartRow({ children }: { children: React.ReactNode }) {
  return (
    <div className="border-t border-dashed border-border px-4 py-3">
      <div className="mb-2 flex flex-wrap items-center gap-2">
        <span className="text-2xs font-semibold uppercase tracking-wide text-muted-foreground">Restart</span>
        <Badge variant="outline">admin only</Badge>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">{children}</div>
    </div>
  );
}

const ICONS = { "rotate-cw": RotateCw, "rotate-ccw": RotateCcw, plug: Plug, "plug-zap": PlugZap } as const;

/**
 * One action: the button, under it what it does in words (owner rule: no hover-only help), and
 * under that a refusal in plain words when the gateway would not do it.
 *
 * @param target the vendor's full name for the vendor parts
 * @param queued the vendor's waiting messages, so Rebind's help can say how many are kept
 */
export function RestartAction({
  part,
  target = null,
  queued,
  nodeId,
}: {
  part: QueuesRestartPart;
  target?: string | null;
  queued?: number | null;
  nodeId?: string | null;
}) {
  const copy = RESTART_COPY[part];
  const Icon = ICONS[copy.icon];
  const [open, setOpen] = useState(false);
  const [refusal, setRefusal] = useState<string | null>(null);
  const help =
    part === "vendor" && queued != null
      ? copy.help.replace("its queued messages", `its ${count(queued)} queued message${queued === 1 ? "" : "s"}`)
      : copy.help;
  return (
    <div className="min-w-0 space-y-1.5">
      <Button
        variant="outline"
        size="sm"
        onClick={() => {
          setRefusal(null);
          setOpen(true);
        }}
      >
        <Icon className="h-3.5 w-3.5" aria-hidden />
        {copy.label}
      </Button>
      <p className="text-xs text-muted-foreground">{help}</p>
      {refusal && (
        <div className="pt-1">
          <HealthStrip tone="destructive">{refusal}</HealthStrip>
        </div>
      )}
      <RestartDialog
        open={open}
        part={part}
        target={target}
        nodeId={nodeId ?? null}
        onClose={() => setOpen(false)}
        onRefused={(sentence) => {
          setOpen(false);
          setRefusal(sentence);
        }}
      />
    </div>
  );
}

type Stage = { kind: "confirm" } | { kind: "running" } | { kind: "done"; result: RestartResult; at: string };

/** The streams the persist confirmation offers; empty is all of them. */
const ALL_STREAMS = "";

/**
 * The confirmation, then the result: what happens, whether binds drop, what is kept, how long it
 * usually takes and the audit line; once it ran, before → after from the gateway's own figures.
 * A refusal closes it and is shown under the button that was pressed.
 */
function RestartDialog({
  open,
  part,
  target,
  nodeId,
  onClose,
  onRefused,
}: {
  open: boolean;
  part: QueuesRestartPart;
  target: string | null;
  nodeId: string | null;
  onClose: () => void;
  onRefused: (sentence: string) => void;
}) {
  const copy = RESTART_COPY[part];
  const { data: session } = useSession();
  const { zone } = useDisplayZone();
  const me = session?.user?.name ?? "you";
  const [stage, setStage] = useState<Stage>({ kind: "confirm" });
  const [stream, setStream] = useState<string>(ALL_STREAMS);
  const [hard, setHard] = useState(false);
  const hardId = useId();
  const chosenTarget = part === "persist" ? stream || null : target;
  const where = [nodeId ? `gateway ${nodeId}` : "gateway", restartCommand(part, chosenTarget)].join(" · ");

  function close() {
    if (stage.kind === "running") {
      return;
    }
    onClose();
    //next time it opens as a question again, with the ordinary choices
    setStage({ kind: "confirm" });
    setStream(ALL_STREAMS);
    setHard(false);
  }

  async function run() {
    setStage({ kind: "running" });
    try {
      const res = await fetch("/api/control/restart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ component: part, target: chosenTarget, ...(part === "db" ? { hard } : {}) }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setStage({ kind: "confirm" });
        onRefused(refusalSentence(res.status, json?.error));
        return;
      }
      setStage({ kind: "done", result: parseRestartResult(json?.data), at: new Date().toISOString() });
    } catch {
      setStage({ kind: "confirm" });
      onRefused(refusalSentence(0, null));
    }
  }

  if (stage.kind === "done") {
    const { result } = stage;
    const rows = figureRows(result);
    const took = tookLabel(result.tookMs);
    const results = Object.entries(result.results);
    return (
      <Dialog
        open={open}
        onClose={close}
        title={result.ok ? copy.done : `${copy.label}: not everything restarted`}
        description={`${nodeId ? `gateway ${nodeId}` : "gateway"} · ${formatClockTime(stage.at, zone)} · by ${me}`}
      >
        <div className="space-y-3">
          <p className="flex flex-wrap items-center gap-2 text-sm">
            <Badge variant={result.ok ? "success" : "warning"}>{result.ok ? "done" : "partly done"}</Badge>
            <span>
              {took && (
                <>
                  Took <b className="tabular-nums">{took}</b>.{" "}
                </>
              )}
              {result.detail}
            </span>
          </p>
          {rows.length > 0 && <BeforeAfter rows={rows} />}
          {results.length > 0 && (
            <dl className="divide-y divide-border rounded-md border border-border text-xs">
              {results.map(([k, v]) => (
                <div key={k} className="grid gap-1 px-3 py-1.5 sm:grid-cols-[140px_1fr] sm:gap-3">
                  <dt className="font-mono text-muted-foreground">{k}</dt>
                  <dd className="[overflow-wrap:anywhere]">{v}</dd>
                </div>
              ))}
            </dl>
          )}
          <p className="text-xs text-muted-foreground">
            Read from the gateway&apos;s health just before and after the restart. The cards on this page update on
            their next read.
          </p>
          <div className="flex justify-end">
            <Button onClick={close}>Done</Button>
          </div>
        </div>
      </Dialog>
    );
  }

  const running = stage.kind === "running";
  const facts: [string, React.ReactNode][] = [
    ["Customer binds", <Bold key="c" text={copy.customerBinds} />],
    ["Vendor binds", <Bold key="v" text={copy.vendorBinds} warn={copy.dropsBinds} />],
    ["Kept", copy.kept],
    ["Usually takes", copy.usually],
    [
      "Recorded as",
      <>
        <span className="font-mono text-xs">ops.restart component={part}</span> by you (
        <span className="font-mono text-xs">{me}</span>) in the operator audit.
      </>,
    ],
  ];
  return (
    <Dialog open={open} onClose={close} title={copy.question} description={where} role="alertdialog">
      <div className="space-y-3">
        <p className="text-sm">{copy.whatHappens}</p>
        {part === "persist" && (
          <Field label="Streams" hint="Pick one stream to leave the others alone.">
            <Select value={stream} onChange={(e) => setStream(e.target.value)} disabled={running} aria-label="Streams">
              <option value={ALL_STREAMS}>All streams ({PERSIST_STREAMS.join(", ")})</option>
              {PERSIST_STREAMS.map((s) => (
                <option key={s} value={s}>
                  {s} only · {STREAM_LABEL[s]}
                </option>
              ))}
            </Select>
          </Field>
        )}
        {part === "db" && (
          <div className="rounded-md border border-border p-3">
            <label htmlFor={hardId} className="flex items-center gap-2 text-sm">
              <Checkbox id={hardId} checked={hard} onChange={(e) => setHard(e.target.checked)} disabled={running} />
              Hard: also close connections that are busy
            </label>
            <p className="mt-1.5 pl-6 text-xs text-muted-foreground">{HARD_HELP}</p>
          </div>
        )}
        {target && part !== "persist" && (
          <p className="text-sm">
            Vendor <span className="font-mono">{target}</span>
          </p>
        )}
        <dl className="divide-y divide-border rounded-md border border-border text-sm">
          {facts.map(([k, v]) => (
            <div key={k} className="grid gap-1 px-3 py-2 sm:grid-cols-[140px_1fr] sm:gap-3">
              <dt className="text-muted-foreground">{k}</dt>
              <dd>{v}</dd>
            </div>
          ))}
        </dl>
        <div className="flex flex-wrap justify-end gap-2">
          <Button variant="outline" onClick={close} disabled={running}>
            Cancel
          </Button>
          <Button onClick={run} disabled={running}>
            {running ? <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden /> : null}
            {running ? "Restarting…" : copy.label}
          </Button>
        </div>
      </div>
    </Dialog>
  );
}

/** "Not dropped. Customers keep…" with its first sentence in bold; a drop in the warning colour. */
function Bold({ text, warn = false }: { text: string; warn?: boolean }) {
  const end = text.indexOf(". ");
  const [head, tail] = end < 0 ? [text, ""] : [text.slice(0, end + 1), text.slice(end + 1)];
  return (
    <span className={cn(warn && "text-warning")}>
      <b>{head}</b>
      {tail}
    </span>
  );
}

function BeforeAfter({ rows }: { rows: ReturnType<typeof figureRows> }) {
  const cell = (value: string, state?: boolean) =>
    state && value !== "—" ? <Badge variant={stateTone(value)}>{value}</Badge> : value;
  return (
    <div className="overflow-x-auto rounded-md border border-border">
      <table className="w-full text-sm">
        <thead className="bg-muted/60 text-left text-2xs uppercase tracking-wide text-muted-foreground">
          <tr>
            <th className="px-3 py-1.5 font-semibold">
              <span className="sr-only">Figure</span>
            </th>
            <th className="px-3 py-1.5 text-right font-semibold">Before</th>
            <th className="px-1 py-1.5" aria-hidden />
            <th className="px-3 py-1.5 text-right font-semibold">After</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border">
          {rows.map((r) => (
            <tr key={r.key}>
              <td className="px-3 py-1.5 text-muted-foreground">{r.label}</td>
              <td className="px-3 py-1.5 text-right tabular-nums">{cell(r.before, r.state)}</td>
              <td className="px-1 py-1.5 text-muted-foreground" aria-hidden>
                →
              </td>
              <td className="px-3 py-1.5 text-right font-semibold tabular-nums">{cell(r.after, r.state)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
