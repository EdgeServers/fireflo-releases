"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ExpandAllButton, useExpandedAccounts } from "./ExpandAll";
import { SessionList } from "./SessionList";
import type { HealthSession } from "@/lib/health-types";
import { KIND, type WorkerType } from "@/lib/worker-types";
import { noteSource } from "@/lib/page-sources";

const PAGE_SIZE = 25;

/** How long a keystroke waits before it becomes a request. */
const DEBOUNCE_MS = 250;

interface SessionPage {
  rows: HealthSession[];
  total: number;
  matched: number;
  offset: number;
  limit: number;
}

/**
 * A worker's sessions, searched and paged against the gateway.
 *
 * <p><strong>It fetches its own data, and that is the whole reason it exists.</strong> The health
 * poll rebuilds this subtree every five seconds on `/health` and every ten on `/servers`, so a
 * search box living inside {@link SessionList} lost its value and its focus on every tick — you
 * could not finish typing a system id. State that must survive a poll has to sit above the polled
 * data, which means owning the request.
 *
 * <p>Consequently the rows here are NOT the ones in `/ops/health`. That payload carries a sample of
 * twenty per worker; this asks the endpoint that can page, and is the only place in the panel that
 * sees a listener's four hundredth bind.
 *
 * <p>No timer of its own. A session table refreshing under a cursor while somebody reads a row is
 * the behaviour that keeps the disconnect button off the health page; this reloads when the query
 * or the page changes, and offers a Refresh for when that is not enough.
 */
export function SessionBrowser({
  worker,
  type,
  canDisconnect,
  total,
}: {
  /** Full worker name, which is half the identity of a session — ids collide across workers. */
  worker: string;
  type: WorkerType;
  /**
   * Whether the rows may carry a Disconnect. Kept as a prop rather than derived from `type`,
   * because `/health` deliberately shows the same listener sessions without it.
   *
   * <p>It no longer decides whether the worker name is passed down. Capture needs that name on
   * every page, and withholding it to switch off one button switched off the other too.
   */
  canDisconnect: boolean;
  /**
   * What health said the count was, used only until the first page arrives. Without it the panel
   * shows "0 sessions" for a moment on every open, which reads as a listener with nothing bound.
   */
  total?: number | null;
}) {
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [page, setPage] = useState(0);
  const [data, setData] = useState<SessionPage | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  //which accounts are open: above the fetched page, so a Refresh or a page turn keeps them
  const accounts = useExpandedAccounts(data?.rows ?? []);

  //the request in flight, so a slow page cannot overwrite a newer one. Typing "acme" fires four
  //requests and they do not have to come back in order
  const latest = useRef(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebounced(query);
      setPage(0);
    }, DEBOUNCE_MS);
    return () => clearTimeout(timer);
  }, [query]);

  const load = useCallback(async () => {
    const ticket = ++latest.current;
    setLoading(true);
    try {
      const params = new URLSearchParams({
        offset: String(page * PAGE_SIZE),
        limit: String(PAGE_SIZE),
      });
      if (debounced.trim()) {
        params.set("q", debounced.trim());
      }
      const res = await fetch(
        `/api/control/workers/${encodeURIComponent(worker)}/sessions?${params}`,
        { cache: "no-store" }
      );
      const json = await res.json().catch(() => null);
      if (ticket !== latest.current) {
        return;
      }
      noteSource(`sessions:${worker}`, res);
      if (!res.ok) {
        setError(json?.error ?? "The sessions did not load.");
        return;
      }
      setData(json?.data ?? null);
      setError("");
    } catch (err) {
      if (ticket === latest.current) {
        setError(err instanceof Error ? err.message : "The sessions did not load.");
      }
    } finally {
      if (ticket === latest.current) {
        setLoading(false);
      }
    }
  }, [worker, debounced, page]);

  useEffect(() => {
    void load();
  }, [load]);

  const matched = data?.matched ?? total ?? 0;
  const pages = Math.max(1, Math.ceil(matched / PAGE_SIZE));
  const filtered = debounced.trim().length > 0;

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="relative">
          <Search className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="customer, system id or address"
            aria-label={`Search sessions on ${worker}`}
            className="h-8 w-64 pl-7 text-sm"
          />
        </span>
        <span className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="h-8" disabled={loading} onClick={() => void load()}>
            {loading ? "Loading…" : "Refresh"}
          </Button>
          {type === KIND.server && <ExpandAllButton accounts={accounts} />}
        </span>
      </div>

      {error && <p className="text-sm text-destructive">{error}</p>}

      {/* the empty state has to distinguish three things, because they need different actions:
          nothing bound, nothing matching, and not loaded yet */}
      {!error && !data?.rows.length && !loading && (
        <p className="text-sm text-muted-foreground">
          {filtered ? `No session matches "${debounced.trim()}".` : "Nothing bound."}
        </p>
      )}

      {!!data?.rows.length && (
        <SessionList
          type={type}
          sessions={data.rows}
          worker={worker}
          canDisconnect={canDisconnect}
          expanded={accounts.expanded}
          onToggle={accounts.toggle}
        />
      )}

      {/* both counts, always: an operator who has filtered to one customer still needs to know the
          listener is carrying four hundred binds. Reporting only the filtered number would answer a
          different question from the one on screen */}
      {(matched > 0 || filtered) && (
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
          <span>
            {filtered
              ? `${matched} of ${data?.total ?? total ?? 0} sessions match`
              : `${matched} session${matched === 1 ? "" : "s"}`}
            {type === KIND.server && accounts.names.length > 0 && ` in ${accounts.names.length} account${accounts.names.length === 1 ? "" : "s"}`}
            {pages > 1 && ` · page ${Math.min(page, pages - 1) + 1} of ${pages}`}
          </span>
          {pages > 1 && (
            <span className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="h-7"
                disabled={page === 0 || loading} onClick={() => setPage(page - 1)}>
                Previous
              </Button>
              <Button variant="outline" size="sm" className="h-7"
                disabled={page >= pages - 1 || loading} onClick={() => setPage(page + 1)}>
                Next
              </Button>
            </span>
          )}
        </div>
      )}
    </div>
  );
}
