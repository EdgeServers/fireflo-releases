"use client";

import { useMemo, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CardSection, EditPanel } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { SettingsRow, SettingsRows } from "@/components/ui/settings-row";
import { Switch } from "@/components/ui/switch";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import { HealthStrip } from "@/components/CardBits";
import { RULE_FIELD_LABELS, RULE_LIMITS, type BanRule } from "@/lib/ban-rules";
import type { BanRunEntry } from "@/lib/ban-rules-db";
import { blankRule } from "@/lib/refusal-views";
import { reasonLabel } from "@/lib/security-events";
import { lastRun, lastRunSentence, ruleSentence, short, when } from "@/lib/security-format";
import { useDisplayZone } from "@/components/DisplayZoneProvider";

/** What `/api/control/security/rules` answers. */
export interface RulesPayload {
  rules: BanRule[];
  runs: BanRunEntry[];
  jails: string[];
  reasons: string[];
  nonBannable: string[];
  fail2banAvailable: boolean;
}

/**
 * The rules that turn the refusal ledger into fail2ban bans, as settings rows at the foot of the
 * refusals card, and what the last run did.
 *
 * <p>Admin only, like the route under it: a rule bans at the host with nobody pressing anything.
 * The set is edited whole and saved whole, so the rules in force are exactly the rows on screen.
 * A new rule starts off and in dry run -- the safer of the two mistakes -- and the decisions under
 * each rule's Edit are how a dry run is read before it is switched live.
 *
 * <p>The draft is kept against the saved set it was made from. The page re-reads everything after
 * a ban or a hold, and an edit in progress must survive that; it is dropped only when the saved
 * rules themselves changed, which after a Save is the point.
 */
export function AutomaticBans({
  payload,
  error,
  now,
  onReload,
}: {
  payload: RulesPayload | null;
  error: string | null;
  now: number;
  /** After a save, so the whole page agrees with the rules in force. */
  onReload: () => Promise<void>;
}) {
  const { zone } = useDisplayZone();
  const saved = useMemo(() => payload?.rules ?? [], [payload]);
  const [draft, setDraft] = useState<{ from: string; rules: BanRule[] } | null>(null);
  const [open, setOpen] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [note, setNote] = useState<string | null>(null);
  const [problem, setProblem] = useState<string | null>(null);

  const savedKey = JSON.stringify(saved);
  const rules = draft && draft.from === savedKey ? draft.rules : saved;
  const dirty = draft !== null && draft.from === savedKey && JSON.stringify(draft.rules) !== savedKey;

  function edit(next: BanRule[]) {
    setDraft({ from: savedKey, rules: next });
    setNote(null);
  }
  function patch(id: string, change: Partial<BanRule>) {
    edit(rules.map((r) => (r.id === id ? { ...r, ...change } : r)));
  }

  async function save() {
    setSaving(true);
    setNote(null);
    setProblem(null);
    try {
      const res = await fetch("/api/control/security/rules", {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ rules }),
      });
      const body = await res.json().catch(() => null);
      if (!res.ok) {
        throw new Error(body?.error ?? `The rules were not saved (${res.status}).`);
      }
      setDraft(null);
      await onReload();
      setNote("Saved. The runner evaluates every enabled rule once a minute.");
    } catch (err) {
      setProblem(err instanceof Error ? err.message : String(err));
    } finally {
      setSaving(false);
    }
  }

  const jails = payload?.jails ?? [];
  const nonBannable = payload?.nonBannable ?? [];
  const bannable = (payload?.reasons ?? []).filter((r) => !nonBannable.includes(r));
  const runs = payload?.runs ?? [];
  const summary = lastRunSentence(lastRun(runs), now, zone);

  return (
    <CardSection
      title="Automatic bans"
      action={
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-muted-foreground">{summary}</span>
          <Button variant="outline" size="sm" disabled={!payload}
            onClick={() => { edit([...rules, blankRule(rules, jails[0] ?? "fireflo-gateway")]); }}>
            <Plus className="size-3.5" aria-hidden /> Add rule
          </Button>
          <Button size="sm" disabled={!dirty || saving} onClick={() => void save()}>
            {saving ? "Saving…" : "Save rules"}
          </Button>
        </div>
      }
    >
      {error && <HealthStrip tone="destructive">{error}</HealthStrip>}
      {problem && <HealthStrip tone="destructive">{problem}</HealthStrip>}
      {note && <HealthStrip tone="info">{note}</HealthStrip>}
      {payload && !payload.fail2banAvailable && (
        <HealthStrip tone="warning">
          fail2ban is not reachable from this panel, so a live rule decides and records but cannot ban.
          Install the panel on the gateway host with fail2ban (fireflo-panel-install --with-fail2ban).
        </HealthStrip>
      )}

      {!payload ? (
        !error && <p className="text-sm text-muted-foreground">Reading…</p>
      ) : rules.length === 0 ? (
        <p className="text-sm text-muted-foreground">
          No rules. The host&apos;s own fail2ban jail still applies its maxretry.
        </p>
      ) : (
        <SettingsRows>
          {rules.map((rule) => {
            const live = rule.enabled && !rule.dryRun;
            const expanded = open === rule.id;
            return (
              <div key={rule.id}>
                <SettingsRow
                  label={rule.name || rule.id}
                  help={ruleSentence(rule)}
                  chips={
                    live ? <Badge variant="destructive">live</Badge>
                      : rule.enabled ? <Badge variant="info">dry run</Badge>
                        : <Badge variant="outline">off</Badge>
                  }
                  wide
                >
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-2 md:justify-end">
                    <label className="flex items-center gap-2 text-sm">
                      <Switch checked={rule.enabled} onChange={(next) => patch(rule.id, { enabled: next })}
                        aria-label={`${RULE_FIELD_LABELS.enabled} ${rule.name || rule.id}`} />
                      Enabled
                    </label>
                    <label className="flex items-center gap-2 text-sm">
                      <Switch checked={rule.dryRun} onChange={(next) => patch(rule.id, { dryRun: next })}
                        aria-label={`${RULE_FIELD_LABELS.dryRun} ${rule.name || rule.id}`} />
                      Dry run
                    </label>
                    <Button variant="outline" size="sm" aria-expanded={expanded}
                      onClick={() => setOpen(expanded ? null : rule.id)}>
                      {expanded ? "Close" : "Edit"}
                    </Button>
                  </div>
                </SettingsRow>
                {expanded && (
                  <div className="px-4 pb-4 md:px-5">
                    <RuleEditor rule={rule} jails={jails} bannable={bannable} nonBannable={nonBannable}
                      runs={runs.filter((e) => e.rule === rule.id).slice(0, 50)} now={now}
                      onChange={(change) => patch(rule.id, change)}
                      onRemove={() => { edit(rules.filter((r) => r.id !== rule.id)); setOpen(null); }} />
                  </div>
                )}
              </div>
            );
          })}
        </SettingsRows>
      )}

      {payload && (
        <p className="text-xs text-muted-foreground">
          Never banned by a rule unless ticked under Edit:{" "}
          {nonBannable.map((r) => <code key={r} className="mr-1 font-mono">{r}</code>)}
          — the gateway&apos;s refusals of a caller whose credential was accepted, or who is already held
          out. A rule with no reasons ticked counts every other reason.
        </p>
      )}
    </CardSection>
  );
}

/** The fields of one rule, and the last decisions it made. */
function RuleEditor({
  rule,
  jails,
  bannable,
  nonBannable,
  runs,
  now,
  onChange,
  onRemove,
}: {
  rule: BanRule;
  jails: string[];
  bannable: string[];
  nonBannable: string[];
  runs: BanRunEntry[];
  now: number;
  onChange: (change: Partial<BanRule>) => void;
  onRemove: () => void;
}) {
  const { zone, short: zoneShort } = useDisplayZone();
  const id = `rule-${rule.id}`;
  return (
    <EditPanel>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <Field label={RULE_FIELD_LABELS.name} htmlFor={`${id}-name`}>
          <Input id={`${id}-name`} value={rule.name} maxLength={80} onChange={(e) => onChange({ name: e.target.value })} />
        </Field>
        <Field label={RULE_FIELD_LABELS.listener} htmlFor={`${id}-listener`} hint="a worker name, or any">
          <Input id={`${id}-listener`} value={rule.listener} onChange={(e) => onChange({ listener: e.target.value })} />
        </Field>
        <Field label={RULE_FIELD_LABELS.jail} htmlFor={`${id}-jail`}>
          <Select id={`${id}-jail`} value={rule.jail} onChange={(e) => onChange({ jail: e.target.value })}>
            {jails.map((j) => <option key={j} value={j}>{j}</option>)}
          </Select>
        </Field>
        <Field label={RULE_FIELD_LABELS.threshold} htmlFor={`${id}-threshold`}>
          <Input id={`${id}-threshold`} inputMode="numeric" value={String(rule.threshold)}
            min={RULE_LIMITS.threshold.min} max={RULE_LIMITS.threshold.max}
            onChange={(e) => onChange({ threshold: Number(e.target.value) })} />
        </Field>
        <Field label={RULE_FIELD_LABELS.windowMinutes} htmlFor={`${id}-window`}>
          <Input id={`${id}-window`} inputMode="numeric" value={String(rule.windowMinutes)}
            onChange={(e) => onChange({ windowMinutes: Number(e.target.value) })} />
        </Field>
        <Field label={RULE_FIELD_LABELS.banSeconds} htmlFor={`${id}-ban`} hint="the jail's own bantime applies today">
          <Input id={`${id}-ban`} inputMode="numeric" value={String(rule.banSeconds)}
            onChange={(e) => onChange({ banSeconds: Number(e.target.value) })} />
        </Field>
      </div>
      <fieldset>
        <legend className="mb-1.5 text-xs font-semibold">{RULE_FIELD_LABELS.reasons}</legend>
        <div className="flex flex-wrap gap-x-4 gap-y-1.5">
          {[...bannable, ...nonBannable].map((reason) => {
            const excluded = nonBannable.includes(reason);
            const on = rule.reasons.includes(reason);
            return (
              <label key={reason} className={`flex items-center gap-1.5 text-xs ${excluded ? "text-muted-foreground" : ""}`}
                title={excluded ? "Not counted unless ticked here" : reasonLabel(reason)}>
                <Checkbox checked={on} onChange={(e) => onChange({
                  reasons: e.target.checked ? [...rule.reasons, reason] : rule.reasons.filter((r) => r !== reason),
                })} />
                <span className="font-mono">{reason}</span>
                {excluded && <span>(excluded)</span>}
              </label>
            );
          })}
        </div>
      </fieldset>

      <div>
        <h5 className="mb-1.5 text-xs font-semibold">Last decisions</h5>
        {!runs.length ? (
          <p className="text-xs text-muted-foreground">This rule has not decided anything yet.</p>
        ) : (
          <div className="rounded-md border border-border bg-card">
            <TableInCard>
              <THead>
                <tr>
                  <TH>When ({zoneShort})</TH>
                  <TH>Address</TH>
                  <TH>Jail</TH>
                  <TH>Outcome</TH>
                  <TH>Why</TH>
                </tr>
              </THead>
              <TBody>
                {runs.map((e, i) => (
                  <TR key={`${e.at}-${e.ip}-${i}`}>
                    <TD muted className="whitespace-nowrap text-xs" title={when(e.at, zone)}>{short(e.at, now, zone)}</TD>
                    <TD className="font-mono">{e.ip}</TD>
                    <TD muted className="text-xs">{e.jail}</TD>
                    <TD>
                      {e.banned ? (
                        <Badge variant="destructive">banned</Badge>
                      ) : e.dryRun ? (
                        <Badge variant="info">would ban</Badge>
                      ) : (
                        <Badge variant="warning" title={e.error ?? undefined}>not banned</Badge>
                      )}
                    </TD>
                    <TD muted className="max-w-md text-xs">{e.error ?? e.reason}</TD>
                  </TR>
                ))}
              </TBody>
            </TableInCard>
          </div>
        )}
      </div>

      <div className="flex justify-end border-t border-border pt-3">
        <Button variant="ghost-destructive" size="sm" title="Remove this rule; Save rules makes it so" onClick={onRemove}>
          <Trash2 className="size-3.5" aria-hidden /> Remove rule
        </Button>
      </div>
    </EditPanel>
  );
}
