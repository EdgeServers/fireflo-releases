"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import {
  browserTimeZone,
  isValidZone,
  parseZoneCookie,
  resolveDisplayZone,
  ZONE_COOKIE,
  ZONE_STORAGE_KEY,
  zoneCookieValue,
  zoneLabel,
  zoneShortName,
  type ZoneMode,
} from "@/lib/datetime";

/**
 * The zone every time in the panel is shown in.
 *
 * <p>The platform's billing zone (`smsg.billing.zone`) for everyone by default, so two operators,
 * or an operator and a customer on the portal, quoting a time to each other quote the same one.
 * The chip in the top bar switches it per browser to the browser's own zone or to UTC. Days on
 * charts, usage and statements are billing days whatever is chosen -- the zone changes how an
 * instant is written, never which day a message is billed on.
 *
 * <p>Remembered like the theme: localStorage holds the choice, and a cookie carries it to the
 * server so the first paint is already in the right zone (app/layout.tsx reads it). For "My
 * browser" the cookie also carries the browser's zone, which the server cannot know otherwise;
 * until the browser has written it once, the server renders the platform's zone and the page
 * repaints in the browser's a moment later, without a hydration mismatch because the first client
 * render uses the same props the server did.
 */

export interface DisplayZone {
  /** The IANA zone to format in, e.g. `Asia/Kolkata`. Pass it to every lib/datetime formatter. */
  zone: string;
  /** `IST · Asia/Kolkata`, or `UTC`: the chip's words. */
  label: string;
  /** `IST`: for a column header, "Submitted (IST)". */
  short: string;
  mode: ZoneMode;
  setMode: (mode: ZoneMode) => void;
  /** The platform's billing zone: the zone days are cut in. */
  billingZone: string;
  /** The browser's own zone, once known; null during the server render. */
  browserZone: string | null;
}

const DisplayZoneContext = createContext<DisplayZone>({
  zone: "UTC",
  label: "UTC",
  short: "UTC",
  mode: "platform",
  setMode: () => {},
  billingZone: "UTC",
  browserZone: null,
});

function writeCookie(mode: ZoneMode, browserZone: string | null) {
  try {
    document.cookie = `${ZONE_COOKIE}=${encodeURIComponent(zoneCookieValue(mode, browserZone))}; path=/; max-age=31536000; SameSite=Lax`;
  } catch {}
}

function storedMode(): ZoneMode | null {
  try {
    const v = localStorage.getItem(ZONE_STORAGE_KEY);
    return v === "platform" || v === "browser" || v === "utc" ? v : null;
  } catch {
    return null;
  }
}

export function DisplayZoneProvider({
  billingZone,
  initialCookie,
  children,
}: {
  /** `billingZone()`, read by the root layout. */
  billingZone: string;
  /** The `fireflo-tz` cookie as the server received it. */
  initialCookie?: string;
  children: React.ReactNode;
}) {
  const initial = parseZoneCookie(initialCookie);
  const [mode, setModeState] = useState<ZoneMode>(initial.mode);
  const [browserZone, setBrowserZone] = useState<string | null>(initial.browserZone);

  //after mount, never in an initialiser: neither localStorage nor the browser's zone exists while
  //the server renders, and React 19 throws on the mismatch rather than patching it up
  useEffect(() => {
    const own = browserTimeZone();
    const chosen = storedMode() ?? initial.mode;
    setBrowserZone(own && isValidZone(own) ? own : null);
    setModeState(chosen);
    writeCookie(chosen, own);
    //once, on mount: the props are the server's view and do not change under a mounted tree
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setMode = useCallback((next: ZoneMode) => {
    setModeState(next);
    try {
      localStorage.setItem(ZONE_STORAGE_KEY, next);
    } catch {}
    writeCookie(next, browserTimeZone());
  }, []);

  const value = useMemo<DisplayZone>(() => {
    const zone = resolveDisplayZone(mode, billingZone, browserZone);
    return {
      zone,
      label: zoneLabel(zone),
      short: zoneShortName(zone),
      mode,
      setMode,
      billingZone: isValidZone(billingZone) ? billingZone : "UTC",
      browserZone,
    };
  }, [mode, billingZone, browserZone, setMode]);

  return <DisplayZoneContext.Provider value={value}>{children}</DisplayZoneContext.Provider>;
}

/** The display zone and the switch for it. */
export function useDisplayZone(): DisplayZone {
  return useContext(DisplayZoneContext);
}
