import { formatTps } from "@/lib/tps-format";
import { cn } from "@/lib/utils";

/** A ceiling this close to reached is drawn in the warning colour. */
export const WARN_AT = 0.9;

/**
 * A rate against its ceiling: the bar is the share of the ceiling used, the colour the verdict.
 * Shared by the listener Status tab and the account Limits tab, so "near the ceiling" is one rule.
 *
 * @param hot the caller's verdict when the ceiling belongs to someone else (an account ceiling a
 *     login row shares); defaults to this rate against this ceiling at {@link WARN_AT}
 */
export function RateBar({
  rate,
  ceiling,
  hot,
  note,
}: {
  rate: number | null;
  ceiling: number | null;
  hot?: boolean;
  note?: string | null;
}) {
  if (rate == null) {
    return <span className="text-muted-foreground">—</span>;
  }
  const share = ceiling ? Math.min(1, rate / ceiling) : 0;
  const warn = hot ?? (ceiling != null && ceiling > 0 && rate / ceiling >= WARN_AT);
  return (
    <span className="inline-flex items-center gap-2 whitespace-nowrap">
      {ceiling != null && (
        <span className="h-1.5 w-20 overflow-hidden rounded-full bg-muted" aria-hidden>
          <span className={cn("block h-full rounded-full", warn ? "bg-warning" : "bg-foreground/60")} style={{ width: `${(share * 100).toFixed(0)}%` }} />
        </span>
      )}
      <span className={cn("tabular-nums", warn && "font-semibold text-warning")}>{formatTps(Math.round(rate * 10) / 10)}</span>
      {note && <span className="text-2xs text-muted-foreground">{note}</span>}
    </span>
  );
}
