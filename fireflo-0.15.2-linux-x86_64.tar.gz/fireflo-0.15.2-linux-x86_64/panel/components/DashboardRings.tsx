"use client";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { SunburstChart } from "recharts";
import { AlertTriangle, ArrowDown, ArrowUp, Server } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { RANGES, type Range } from "./useControlData";
import type { VendorRow } from "./VendorTraffic";
import { count, percent } from "@/lib/format";
import { FINAL_STATE_LABELS, labelFor } from "@/lib/labels";
import { byReason, reasonKey, type FailureCell } from "@/lib/failure-groups";
import {
  EXPIRED_COLOUR,
  FAILED_COLOUR,
  PENDING_COLOUR,
  REST_COLOUR,
  SLICE_COLOURS,
  ancestors,
  buildSunburst,
  failureItems,
  findNode,
  pathRows,
  reasonColours,
  shareOfTop,
  tint,
  vendorItems,
  zoomOut,
  zoomTarget,
  type SunNode,
  type TreeItem,
} from "@/lib/sunburst-tree";
import { formatClockTime, formatTimestamp } from "@/lib/datetime";
import { useDisplayZone } from "@/components/DisplayZoneProvider";

/**
 * The dashboard's two sunbursts, side by side (0.15.1, deeper): why messages failed -- account ›
 * vendor › final state › error code › carrier code -- and what each vendor sent -- vendor › account
 * › outcome › error code. The shaping (largest first, small siblings folded into "other N", a level
 * of one merged into its parent) is `lib/sunburst-tree.ts`; this file draws it.
 *
 * <p>Click any sector with children to make it the centre; the breadcrumb goes back to any level
 * above, the centre goes up one. The centre names whatever is under the pointer: its whole path, its
 * count and its share of the account (or the vendor). Colours are fixed hues rather than theme
 * tokens on purpose: a reason keeps one colour wherever it appears, in both rings and both themes.
 */

/** Whether each card's table is open. Closed until asked for; the choice is remembered per browser. */
const FAILURE_TABLE_KEY = "fireflo.overview.failureTable";
const VENDOR_TABLE_KEY = "fireflo.overview.vendorTable";

/** A Show table / Hide table switch, closed by default and remembered under `key`. */
function useTableToggle(key: string): [boolean, () => void] {
  const [open, setOpen] = useState(false);
  //read after mount: localStorage does not exist while the page renders on the server
  useEffect(() => {
    try {
      setOpen(window.localStorage.getItem(key) === "1");
    } catch {
      //private window or blocked storage: closed stands
    }
  }, [key]);
  const toggle = () => setOpen((was) => {
    try {
      window.localStorage.setItem(key, was ? "0" : "1");
    } catch {
      //remembered for this page only
    }
    return !was;
  });
  return [open, toggle];
}

function TableToggle({ open, onToggle }: { open: boolean; onToggle: () => void }) {
  return (
    <Button variant="outline" size="sm" className="h-7" onClick={onToggle} aria-pressed={open}>
      {open ? "Hide table" : "Show table"}
    </Button>
  );
}

function reasonName(row: Pick<FailureCell, "finalState" | "dlrState" | "errCode">): string {
  const state = labelFor(FINAL_STATE_LABELS, row.finalState);
  return row.errCode ? `${state} · error ${row.errCode}` : row.dlrState !== null ? `${state} · receipt ${row.dlrState}` : state;
}

/**
 * A zoomable sunburst over a {@link SunNode} tree. The library labels every sector with its value,
 * which on a thin slice is noise, so its labels are hidden and the centre says it instead.
 */
function Sunburst({ root, total, ariaLabel }: { root: SunNode; total: string; ariaLabel: string }) {
  const [focus, setFocus] = useState<string | null>(null);
  const [hover, setHover] = useState<SunNode | null>(null);
  //a focus the new data no longer has (the period moved on) is the whole chart again
  const zoomed = focus ? findNode(root, focus) : null;
  const shown = zoomed ?? root;
  const trail = zoomed ? ancestors(root, zoomed.name) : [];
  const go = (name: string | null) => {
    setFocus(name);
    setHover(null);
  };
  const share = hover ? shareOfTop(root, hover) : null;
  const centre = hover
    ? {
        title: hover.path.join(" › "),
        value: count(hover.value),
        note: share && share.of !== hover ? `${percent(share.share)} of ${share.of.label}` : "",
      }
    : zoomed
      ? { title: zoomed.path.join(" › "), value: count(zoomed.value), note: "click to go up" }
      : { title: total, value: "", note: "" };
  return (
    <div className="space-y-1">
      <nav className="flex min-h-5 flex-wrap items-center gap-1 text-xs text-muted-foreground" aria-label="Where the chart is zoomed">
        {zoomed ? (
          <>
            <button type="button" className="underline-offset-2 hover:text-foreground hover:underline" onClick={() => go(null)}>
              {total}
            </button>
            {trail.map((n, i) => (
              <span key={n.name} className="flex items-center gap-1">
                <span aria-hidden="true">›</span>
                {i === trail.length - 1 ? (
                  <span className="font-medium text-foreground">{n.label}</span>
                ) : (
                  <button type="button" className="underline-offset-2 hover:text-foreground hover:underline" onClick={() => go(n.name)}>
                    {n.label}
                  </button>
                )}
              </span>
            ))}
          </>
        ) : (
          <span>Click a slice to zoom in</span>
        )}
      </nav>
      <div className="relative mx-auto aspect-square w-full max-w-72" role="img" aria-label={ariaLabel}>
        <SunburstChart
          data={shown}
          responsive
          width="100%"
          height="100%"
          innerRadius={46}
          padding={1}
          ringPadding={1}
          stroke="var(--color-card)"
          textOptions={{ fill: "transparent", stroke: "none" }}
          onClick={(node) => {
            const target = zoomTarget(root, String(node.name));
            if (target && target.name !== shown.name) {
              go(target.name);
            }
          }}
          onMouseEnter={(node) => setHover(findNode(root, String(node.name)))}
          onMouseLeave={() => setHover(null)}
          style={{ cursor: "pointer" }}
        />
        {/* the centre: what is under the pointer, else the zoomed sector, else the total. A button
            when zoomed, so the middle of the chart is also the way up one level */}
        <button
          type="button"
          disabled={!zoomed}
          onClick={() => go(zoomed ? zoomOut(root, zoomed.name) : null)}
          className="absolute left-1/2 top-1/2 flex h-24 w-24 -translate-x-1/2 -translate-y-1/2 flex-col items-center justify-center rounded-full text-center disabled:cursor-default"
          aria-label={zoomed ? "Zoom out one level" : undefined}
          tabIndex={zoomed ? 0 : -1}
        >
          <span className="line-clamp-3 px-1 text-2xs leading-tight text-muted-foreground [overflow-wrap:anywhere]">{centre.title}</span>
          {centre.value && <span className="text-sm font-medium tabular-nums">{centre.value}</span>}
          {centre.note && <span className="text-2xs leading-tight text-muted-foreground">{centre.note}</span>}
        </button>
      </div>
    </div>
  );
}

/**
 * Every full path the ring draws, unfolded (what "other N" holds is listed too), with its count and
 * share of the whole; sorted by count, the header reverses it.
 */
function PathTable({ items, total, noun }: { items: TreeItem[]; total: number; noun: string }) {
  const [order, setOrder] = useState<"desc" | "asc">("desc");
  const rows = useMemo(() => pathRows(items, order), [items, order]);
  return (
    <table className="w-full text-xs">
      <thead>
        <tr className="text-muted-foreground">
          <th className="py-1 text-left font-normal">Path</th>
          <th className="py-1 text-right font-normal">
            <button
              type="button"
              className="inline-flex items-center gap-1 hover:text-foreground"
              onClick={() => setOrder((o) => (o === "desc" ? "asc" : "desc"))}
              aria-label={`Sort by ${noun}, ${order === "desc" ? "smallest" : "largest"} first`}
            >
              {noun}
              {order === "desc" ? <ArrowDown className="h-3 w-3" /> : <ArrowUp className="h-3 w-3" />}
            </button>
          </th>
          <th className="py-1 pl-3 text-right font-normal">Share</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r.key} className="border-t border-border">
            <td className="py-1.5">
              <span className="flex min-w-0 items-start gap-1.5">
                <Swatch colour={r.fill} />
                <span className="[overflow-wrap:anywhere]">
                  {r.path.map((p, i) => (
                    <span key={i}>
                      {i > 0 && <span className="text-muted-foreground"> › </span>}
                      <span className={i === 0 ? "font-mono" : undefined}>{p}</span>
                    </span>
                  ))}
                </span>
              </span>
            </td>
            <td className="py-1.5 text-right tabular-nums">{count(r.value)}</td>
            <td className="py-1.5 pl-3 text-right tabular-nums text-muted-foreground">{total > 0 ? percent(r.value / total) : "—"}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

/** "summary to 14:02, live after", or "live records" -- what the figures were read from. */
function sourceNote(watermark: string | null | undefined, zone: string): string {
  if (!watermark) {
    return "live records";
  }
  const at = formatClockTime(watermark, zone);
  return `summary to ${at}, live after`;
}

function Swatch({ colour, opacity }: { colour: string; opacity?: number }) {
  return <span className="inline-block h-2.5 w-2.5 shrink-0 rounded-sm" style={{ background: colour, opacity }} aria-hidden="true" />;
}

/**
 * Why messages failed: the failures of the period five levels deep, account outermost-in. The tables
 * are on demand -- "Show table" opens every full path with its count and the reasons list with its
 * dismiss controls, which the caller renders and passes as `reasonsTable`.
 */
export function FailureRingCard({
  rows,
  since,
  watermark,
  loading,
  reasonsTable,
}: {
  rows: FailureCell[];
  since?: string;
  /** The summary's watermark the read leaned on, or null when it read the records alone. */
  watermark?: string | null;
  loading: boolean;
  reasonsTable: ReactNode;
}) {
  const { zone } = useDisplayZone();
  const [table, toggle] = useTableToggle(FAILURE_TABLE_KEY);

  const { reasons, colours, total, accounts, items, tree } = useMemo(() => {
    const colourOf = reasonColours(rows);
    const list = failureItems(rows, colourOf);
    const sum = rows.reduce((n, r) => n + r.messages, 0);
    return {
      reasons: byReason(rows),
      colours: colourOf,
      total: sum,
      accounts: new Set(rows.map((r) => r.account ?? "")).size,
      items: list,
      tree: buildSunburst(list, `${count(sum)} failed`),
    };
  }, [rows]);
  const legend = reasons.filter((r) => colours.get(reasonKey(r)) !== REST_COLOUR);

  return (
    <Card className="min-w-0">
      <CardHeader className="flex-row flex-wrap items-start gap-2 space-y-0">
        <div className="min-w-0 flex-1 space-y-1.5">
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            Why messages failed
          </CardTitle>
          <CardDescription>
            {since ? <>Since {formatTimestamp(since, zone)}</> : "This period"}
            {" · "}{sourceNote(watermark, zone)}
            {total > 0 && <> · {count(total)} failed across {accounts} account{accounts === 1 ? "" : "s"}</>}
          </CardDescription>
        </div>
        <TableToggle open={table} onToggle={toggle} />
      </CardHeader>
      <CardContent className="space-y-3">
        {total === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">{loading ? "Loading…" : "No failures in this period"}</p>
        ) : (
          <>
            <Sunburst root={tree} total={`${count(total)} failed`}
              ariaLabel={`Failed messages by account, vendor, final state, error code and carrier code: ${(tree.children ?? []).map((d) => `${d.label} ${d.value}`).join(", ")}`} />
            <p className="text-center text-2xs text-muted-foreground">Rings, inside out: account › vendor › final state › error code › carrier code</p>
            <div className="flex flex-wrap justify-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
              {legend.map((r) => (
                <span key={reasonKey(r)} className="flex items-center gap-1.5"><Swatch colour={colours.get(reasonKey(r))!} />{reasonName(r)}</span>
              ))}
              {reasons.length > legend.length && (
                <span className="flex items-center gap-1.5"><Swatch colour={REST_COLOUR} />{reasons.length - legend.length} more</span>
              )}
            </div>
            {table && <PathTable items={items} total={total} noun="Failed" />}
          </>
        )}
        {table && <div className="border-t border-border pt-3">{reasonsTable}</div>}
      </CardContent>
    </Card>
  );
}

/**
 * What each vendor sent in the period, four levels deep: vendor › account › outcome › error code
 * (for the failed and expired slices). Delivered and pending are the vendor rows'; the failed and
 * expired codes are the failure rows' for the same vendor and account.
 *
 * <p>Its rows are a section of the overview snapshot, built in the background per range like the
 * traffic chart's, so an open dashboard costs the database nothing of its own.
 */
export function VendorRingCard({
  rows: data,
  accounts,
  failures,
  range,
  watermark,
  loading,
  error,
}: {
  rows: VendorRow[];
  /** The same split by account (0.15.1); without it the account level reads "All accounts". */
  accounts?: (VendorRow & { account?: string | null })[];
  /** The failure rows, for the failed and expired codes. */
  failures?: FailureCell[];
  range: Range;
  watermark?: string | null;
  loading: boolean;
  error?: string;
}) {
  const { zone } = useDisplayZone();
  const [table, toggle] = useTableToggle(VENDOR_TABLE_KEY);
  const period = RANGES.find((r) => r.value === range)?.label ?? range;
  const { sent, total, items, tree } = useMemo(() => {
    const rows = (data ?? []).filter((v) => v.messages > 0);
    const split = (accounts ?? []).filter((v) => v.messages > 0);
    const list = vendorItems(split.length ? split : rows, failures ?? []);
    const drawn = list.reduce((n, i) => n + i.value, 0);
    return {
      sent: rows.reduce((n, v) => n + v.messages, 0),
      total: drawn,
      items: list,
      //the outcomes are credited to one attempt per message, so they can sum to a little less than
      //the messages handed over; each vendor's slice is drawn from its outcomes, which is what it shows
      tree: buildSunburst(list, "sent"),
    };
  }, [data, accounts, failures]);

  return (
    <Card className="min-w-0">
      <CardHeader className="flex-row flex-wrap items-start gap-2 space-y-0">
        <div className="min-w-0 flex-1 space-y-1.5">
          <CardTitle className="flex items-center gap-2">
            <Server className="h-4 w-4 text-muted-foreground" />
            Sent by vendor
          </CardTitle>
          <CardDescription>
            Last {period}{sent > 0 ? ` · ${count(sent)} messages` : ""} · {sourceNote(watermark, zone)}
          </CardDescription>
        </div>
        <TableToggle open={table} onToggle={toggle} />
      </CardHeader>
      <CardContent className="space-y-3">
        {error ? (
          <p className="py-6 text-center text-sm text-destructive">{error}</p>
        ) : sent === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">{loading ? "Loading…" : "Nothing sent in this period"}</p>
        ) : (
          <>
            <Sunburst root={tree} total={`${count(sent)} sent`}
              ariaLabel={`Messages by vendor, account, outcome and error code: ${(tree.children ?? []).map((d) => `${d.label} ${d.value}`).join(", ")}`} />
            <p className="text-center text-2xs text-muted-foreground">Rings, inside out: vendor › account › outcome › error code</p>
            <div className="flex flex-wrap justify-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5"><Swatch colour={tint(SLICE_COLOURS[0], 0.55)} />delivered (vendor&apos;s colour)</span>
              <span className="flex items-center gap-1.5"><Swatch colour={FAILED_COLOUR} />failed</span>
              <span className="flex items-center gap-1.5"><Swatch colour={EXPIRED_COLOUR} />expired</span>
              <span className="flex items-center gap-1.5"><Swatch colour={PENDING_COLOUR} />pending</span>
            </div>
            {table && <PathTable items={items} total={total} noun="Messages" />}
          </>
        )}
      </CardContent>
    </Card>
  );
}
