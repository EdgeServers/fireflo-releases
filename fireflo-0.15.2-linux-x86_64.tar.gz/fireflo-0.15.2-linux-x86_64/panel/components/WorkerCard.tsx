"use client";
import Link from "next/link";
import { Antenna, ChevronDown, ChevronRight, Languages, Server } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClasses } from "@/components/ui/button";
import {
  Card, CardContent, CardDescription, CardFooter, CardHeader, CardSection, CardTitle,
} from "@/components/ui/card";
import { BindList, ConnectionStatus, LiveTrafficControls } from "./ConnectionStatus";
import { DangerAction } from "./DangerAction";
import { SettingsList } from "./SettingsList";
import type { HealthWorker } from "@/lib/health-types";
import { workerVerdict, type BindCapacity } from "@/lib/worker-verdict";
import { KIND, KIND_NOUN, isOn, trafficKey, type Worker, type WorkerType } from "@/lib/worker-types";
import { localeNumber } from "@/lib/format";
import { mtDlrShort, RECEIPTS_NEED_GATEWAY } from "@/lib/mt-dlr";

/**
 * One vendor or server in a list, with everything you can do to it.
 *
 * <p>Extracted because the two pages had drifted into two copies of the same card with different
 * button orders and different confirmation wording, and this change touches every part of it.
 *
 * <p><strong>Actions are in two groups, and the split is the point.</strong> The header carries
 * configuration — edit it, enable it, delete it — and reads left to right in the order of how much
 * they cost. Live traffic controls sit inside the body under their own label, because "Stop sending"
 * reroutes production traffic the moment it is pressed and should not sit in the same undifferentiated
 * row as "Edit". Previously all five were the same size, the same `outline` variant, and split across
 * the header and the middle of the body with no rule about which went where.
 *
 * <h2>Open and closed</h2>
 *
 * <p>Every card used to be fully expanded at once, which made a six-vendor page something you
 * scrolled rather than read. It is now an accordion driven by the page.
 *
 * <p><strong>What survives collapsing is the whole safety argument for collapsing at all.</strong>
 * The header keeps the name, the address, the verdict badge and — closed only — the figure that
 * says why it matters. A vendor that has stopped carrying traffic is legible without opening
 * anything, so folding the others away hides detail and never hides a fault.
 *
 * <p>The actions go with the body. A row of Edit/Disable/Delete buttons on a closed card invites
 * deleting the wrong one, because the thing distinguishing the rows is a name and nothing else.
 */
export function WorkerCard({
  worker,
  type,
  live,
  busy,
  busyLabel,
  error,
  costRates,
  open,
  onToggle,
  onEdit,
  onToggleEnabled,
  onSetProperty,
  onRestart,
  onRemove,
  children,
  windowSeconds,
  tpsHistory,
}: {
  worker: Worker;
  type: WorkerType;
  live: HealthWorker | undefined;
  busy: boolean;
  busyLabel: string;
  /** `tps_window_seconds` from the snapshot, so the throughput figure can name its own window. */
  windowSeconds?: number | null;
  /** Recent measured rates for this worker, oldest first. The page owns the history. */
  tpsHistory?: readonly (number | null)[];
  /** Set only when the last failed action was this worker's — shown here, next to the button. */
  error?: string;
  /** Whether the body is showing. The page owns it, because the page also owns the scrolling. */
  open: boolean;
  onToggle: () => void;
  onEdit: () => void;
  onToggleEnabled: (enabled: boolean) => void;
  onSetProperty: (key: string, on: boolean, label: string) => void;
  onRestart: () => void;
  onRemove: () => void;
  /** Traffic for the period, on the vendor page only. */
  children?: React.ReactNode;
  /**
   * Cost rates, on the vendor page only.
   *
   * <p>A prop rather than something this card derives, because a server has no cost scope at all —
   * only a vendor dials out and only a vendor is charged. Absent beats empty.
   */
  costRates?: React.ReactNode;
}) {
  const isVendor = type === KIND.vendor;
  const Icon = isVendor ? Antenna : Server;
  const suspended = isOn(worker, "suspend");
  const paused = isOn(worker, "pause");
  const verdict = workerVerdict({ type, live, enabled: worker.enabled, suspended, paused });

  //the one identifying fact each kind is looked up by, in the title rather than buried in the grid
  const subtitle = isVendor
    ? [property(worker, "host"), property(worker, "port")].filter(Boolean).join(":")
    : property(worker, "srv.port") && `port ${property(worker, "srv.port")}`;

  return (
    <Card className={verdict.tone === "destructive" ? "border-destructive/40" : undefined}>
      <CardHeader className="flex flex-row flex-wrap items-start justify-between gap-3 pb-3">
        <button
          type="button"
          onClick={onToggle}
          aria-expanded={open}
          className="flex min-w-0 flex-1 items-start gap-2 text-left"
        >
          {open
            ? <ChevronDown className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
            : <ChevronRight className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />}
          <span className="min-w-0 space-y-1.5">
            <CardTitle className="flex flex-wrap items-center gap-2">
              <Icon className="h-4 w-4 shrink-0 text-muted-foreground" />
              {worker.name}
              {subtitle && (
                <span className="font-normal tabular-nums text-muted-foreground">{subtitle}</span>
              )}
              <Badge variant={verdict.tone}>{verdict.label}</Badge>
              {/* closed only: the header has to carry enough to make folding safe, and open the
                  same figure is a tile three lines below */}
              {!open && collapsedFigure(live, isVendor) && (
                <span
                  className="text-sm font-normal tabular-nums text-muted-foreground"
                  title={collapsedFigure(live, isVendor).endsWith("— DLR") ? RECEIPTS_NEED_GATEWAY : undefined}
                >
                  {collapsedFigure(live, isVendor)}
                </span>
              )}
            </CardTitle>
            {worker.label && <CardDescription>{worker.label}</CardDescription>}
          </span>
        </button>

        {/* rendered whether or not the card is open, unlike the editing actions beside it. A link
            that only appears once a card is expanded is a link nobody finds: the first version of
            this lived in the footer, and from a collapsed list the only "Error codes" on screen was
            a page-level one that went to the GLOBAL list -- same label, different destination.
            Outside the toggle button rather than inside it, or it would be a link nested in a
            button */}
        {(open || isVendor) && (
          <div className="flex flex-wrap items-center gap-1.5">
            {isVendor && (
              <Link
                href={`/cp/error-codes/${encodeURIComponent(worker.name)}`}
                className={buttonClasses({ variant: "outline", size: "sm" })}
              >
                <Languages className="h-4 w-4" />
                Error codes
              </Link>
            )}
            {open && (
              <>
            <Button variant="outline" size="sm" onClick={onEdit}>
              Edit
            </Button>
            <Button
              variant="ghost"
              size="sm"
              disabled={busy}
              onClick={() => onToggleEnabled(!worker.enabled)}
            >
              {busy && (busyLabel === "Enable" || busyLabel === "Disable")
                ? "Working…"
                : worker.enabled
                  ? "Disable"
                  : "Enable"}
            </Button>
            <DangerAction
              label="Delete"
              confirmLabel={`Delete ${worker.name}`}
              consequence={
                isVendor
                  ? "Its settings go with it, and the routing table may still name it."
                  : "Every customer bound to this listener is disconnected."
              }
              busy={busy}
              onConfirm={onRemove}
            />
              </>
            )}
          </div>
        )}
      </CardHeader>

      {!open ? null : (
      <>
      <CardContent className="space-y-3">
        {error && (
          <p className="rounded-md border border-destructive/40 bg-destructive/5 px-3 py-2 text-sm text-destructive">
            {error}
          </p>
        )}

        <ConnectionStatus
          type={type}
          live={live}
          verdict={verdict}
          paused={paused}
          capacity={bindCapacity(worker, isVendor)}
          windowSeconds={windowSeconds}
          tpsHistory={tpsHistory}
        />

        <BindList type={type} live={live} />

        <CardSection
          title={isVendor ? "Bind settings" : "Listener settings"}
          description={
            isVendor
              ? "What this vendor is configured to do."
              : "What this listener is configured to accept."
          }
        >
          <SettingsList
            type={type}
            properties={worker.properties}
            empty={
              isVendor
                ? "No settings — the gateway will use its own defaults for everything."
                : "No settings — the gateway will use its own defaults, including the listen port."
            }
          />
        </CardSection>

        {costRates && <div className="border-t border-border pt-4">{costRates}</div>}

        {children && <div className="border-t border-border pt-4">{children}</div>}
      </CardContent>

      {/* the footer is where the actions live. On a card this tall, a control in the middle of the
          body is somewhere you have to scroll back to */}
      <CardFooter className="flex flex-wrap items-center gap-3 border-t border-border pt-3">
        <Link
          href={`/cp/cdrs?${isVendor ? "vendor" : "systemId"}=${encodeURIComponent(
            isVendor ? trafficKey(worker) : worker.name
          )}`}
          className="text-sm text-primary hover:underline"
        >
          {isVendor ? `Messages through ${worker.name} →` : `Messages on ${worker.name} →`}
        </Link>
        <LiveTrafficControls
          name={worker.name}
          type={type}
          live={live}
          verdict={verdict}
          suspended={suspended}
          paused={paused}
          busy={busy}
          busyLabel={busyLabel}
          onSuspend={(on) => onSetProperty("suspend", on, on ? "Stop sending" : "Resume sending")}
          onPause={(on) => onSetProperty("pause", on, on ? "Hold" : "Release hold")}
          onRestart={isVendor ? () => onRestart() : undefined}
        />
      </CardFooter>
      </>
      )}
    </Card>
  );
}

/**
 * The one figure a closed card must still show.
 *
 * <p>A backlog is the only number anyone acts on, so it wins when there is one. Otherwise the
 * MT/DLR pair, zeros included (a quiet worker reads "0 MT · 0 DLR"), and the bind count only when
 * the gateway reports no submit count at all. Deliberately silent
 * when the gateway is not reporting this worker — the badge already says "Not loaded", and a count
 * beside it would imply a running thing with nothing in it.
 */
function collapsedFigure(live: HealthWorker | undefined, isVendor: boolean): string {
  if (!live) {
    return "";
  }
  const queued = (live.queue_depth ?? 0) + (live.retry_queue_depth ?? 0);
  if (queued > 0) {
    return `${localeNumber(queued)} queued`;
  }
  if (live.submitted != null) {
    //MT is what crossed the binds (received on a listener -- `Sessions.submitted()` reads
    //getRxSubmitSM for an inbound session -- sent on a vendor), DLR the receipts the other way
    //(gateway 0.15.2; a dash before it). See `submittedLabel`, which the open card's tile uses
    return mtDlrShort(live.submitted, live.receipts);
  }
  return live.bound != null ? `${live.bound} ${isVendor ? "bound" : "connected"}` : "";
}

function property(worker: Worker, key: string): string {
  return worker.properties.find((p) => p.key === key)?.value ?? "";
}

/**
 * What the stored settings ask of the bind count, so the live figure can be read against it.
 *
 * <p>Both numbers were already on this card — the tile from the snapshot, the setting three
 * sections below it in the grid — and nothing put them side by side. A vendor configured for five
 * transceivers with three up rendered as a plain green "3", which is exactly the case somebody
 * opens the page to find.
 *
 * <p>The two kinds mean opposite things by their number, which is why {@link BindCapacity} is
 * tagged rather than bare: `connections.transceivers` is how many to open, `srv.maxConnections` is
 * how many to allow in. Treating a listener's ceiling as a target would paint every quiet
 * listener amber.
 */
function bindCapacity(worker: Worker, isVendor: boolean): BindCapacity | null {
  const raw = property(worker, isVendor ? "connections.transceivers" : "srv.maxConnections");
  const value = Number(raw);
  //a blank setting means the gateway's own default applies, which the panel does not know here.
  //Saying "of 0 configured" would be worse than saying nothing
  if (!raw || !Number.isFinite(value) || value <= 0) {
    return null;
  }
  return { kind: isVendor ? "target" : "ceiling", value };
}

/**
 * The two controls explained once for the page, rather than once per card.
 *
 * <p>The same two sentences used to be repeated inside every card. Ten vendors meant ten copies of
 * identical prose, which is how a page teaches people to stop reading it.
 */
export function TrafficControlLegend({ type }: { type: WorkerType }) {
  const noun = KIND_NOUN[type];
  return (
    <p className="text-sm text-muted-foreground">
      <strong>Stop sending</strong> drains a {noun}&rsquo;s queue back to the router so traffic
      reroutes elsewhere; the session stays bound. <strong>Hold</strong> keeps accepting and stops
      sending, so the queue grows until released. <strong>Disable</strong> stops the {noun} entirely
      within one poll interval.
    </p>
  );
}
