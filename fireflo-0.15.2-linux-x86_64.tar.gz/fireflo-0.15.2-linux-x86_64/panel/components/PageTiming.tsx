"use client";
import { useEffect, useState, useSyncExternalStore } from "react";
import { usePathname } from "next/navigation";
import { APP_VERSION } from "./FireFloMark";
import { formatSeconds } from "@/lib/page-timing";
import {
  beginPage, serverSourcesSnapshot, sourceSections, sourcesSnapshot, sourceTooltip, subscribeSources,
} from "@/lib/page-sources";

/**
 * "Page generated in 0.42 s": how long the server took to produce the page now on screen.
 *
 * <p>Measured from the browser's own timing records rather than by the server, so nothing extra
 * travels with the page:
 *
 * <ul>
 *   <li><b>A full load</b> (address bar, reload, first visit): the navigation entry's
 *       `responseStart - requestStart`, the wait between asking for the document and its first byte
 *       -- the server's work, without the time spent downloading the answer</li>
 *   <li><b>A move inside the panel</b>: the App Router fetches the next page's server component
 *       payload (`?_rsc=`); that request's `responseEnd - startTime` is the server generating it.
 *       A prefetched page shows the time of its prefetch, which is when it was generated</li>
 * </ul>
 *
 * <p>What it does not count: the API calls a page makes after it renders, each of which has its own
 * loading state on the page. Nothing is shown until there is a reading, rather than a zero.
 *
 * <p><b>Where the page's data came from (0.15.1)</b> follows it: "· DB 192.168.1.101:5432 128 ms
 * (3 reads) · Gateway 127.0.0.1:9000 45 ms", added up from the `X-FireFlo-Source` headers of what
 * the page fetched (`lib/page-sources.ts`). A section appears only when the page made such calls,
 * so a page served by the gateway's live series shows no database at all; "from cache" when every
 * database read was a kept answer; a polling page shows its latest poll per metric. The tooltip
 * has the slowest call and each fetch.
 *
 * <p>The panel version it replaces in the footer stays one hover away, in the title.
 */
export function PageTiming() {
  const pathname = usePathname();
  const [seconds, setSeconds] = useState<number | null>(null);

  useEffect(() => {
    //after paint, so the payload's timing entry for this route has been recorded
    const id = window.setTimeout(() => {
      const reading = serverTime(pathname);
      if (reading != null) {
        setSeconds(reading);
      }
    }, 0);
    return () => window.clearTimeout(id);
  }, [pathname]);

  //a new page: what the last one fetched no longer applies
  useEffect(() => {
    beginPage(window.location.pathname);
  }, [pathname]);
  const sources = useSyncExternalStore(subscribeSources, sourcesSnapshot, serverSourcesSnapshot);
  const sections = sourceSections(sources.entries);
  const parts = [sections.db, sections.gateway].filter((p): p is string => p != null);

  return (
    <span className="flex flex-wrap items-center gap-x-1">
      <span className="tabular-nums" title={APP_VERSION ? `Control panel v${APP_VERSION}` : undefined}>
        {seconds == null ? " " : `Page generated in ${formatSeconds(seconds)} s`}
      </span>
      {parts.length > 0 && (
        <span className="tabular-nums" title={sourceTooltip(sources.entries)}>
          {parts.map((p) => `· ${p}`).join(" ")}
        </span>
      )}
    </span>
  );
}

function serverTime(pathname: string): number | null {
  if (typeof performance === "undefined") {
    return null;
  }
  //the newest server-component fetch for this route: a client-side move
  const payloads = performance
    .getEntriesByType("resource")
    .filter((e): e is PerformanceResourceTiming => {
      if (!e.name.includes("_rsc=")) {
        return false;
      }
      try {
        return new URL(e.name).pathname === pathname;
      } catch {
        return false;
      }
    });
  const last = payloads[payloads.length - 1];
  if (last && last.responseEnd > 0) {
    return (last.responseEnd - last.startTime) / 1000;
  }
  //otherwise the document itself: a full load of this route
  const [nav] = performance.getEntriesByType("navigation") as PerformanceNavigationTiming[];
  if (nav && nav.responseStart > 0 && new URL(nav.name).pathname === pathname) {
    return (nav.responseStart - nav.requestStart) / 1000;
  }
  return null;
}
