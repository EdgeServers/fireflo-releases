"use client";
import { useDisplayZone } from "@/components/DisplayZoneProvider";
import { isUtcZone } from "@/lib/datetime";
import { cn } from "@/lib/utils";

/**
 * Under a chart of days, when the viewer is reading times in a zone other than the billing zone:
 * "Days run midnight to midnight in Asia/Kolkata (the platform zone), not in UTC."
 *
 * <p>Day bars are billing days -- `usage_daily` is cut in `smsg.billing.zone` and a statement bills
 * on the same cut -- so they cannot follow the display zone. Without this the viewer who picked UTC
 * reads a bar labelled 31 Oct as their 31 Oct, which it is not. Nothing renders when the zones agree.
 */
export function DayNote({ className }: { className?: string }) {
  const { zone, billingZone } = useDisplayZone();
  if (zone === billingZone || (isUtcZone(zone) && isUtcZone(billingZone))) {
    return null;
  }
  return (
    <p className={cn("text-xs text-muted-foreground", className)} data-testid="day-note">
      Days run midnight to midnight in {billingZone} (the platform zone), not in {isUtcZone(zone) ? "UTC" : zone}.
    </p>
  );
}
