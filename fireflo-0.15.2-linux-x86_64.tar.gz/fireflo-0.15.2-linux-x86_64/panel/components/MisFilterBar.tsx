"use client";
import { useState } from "react";
import { RotateCcw, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { FINAL_STATES, MAX_TEXT_FILTER } from "@/lib/cdr-request";
import { FINAL_STATE_LABELS, labelFor } from "@/lib/labels";
import {
  CUSTOM_RANGE,
  EMPTY_MIS_FILTERS,
  type MisFilterForm,
  hasActiveMisFilters,
  validateMisFilters,
} from "@/lib/mis-messages-filters";
import { useDisplayZone } from "@/components/DisplayZoneProvider";

/** What each preset is called, rather than showing the key. */
const PERIODS: [string, string][] = [
  ["1h", "Last hour"],
  ["24h", "Last 24 hours"],
  ["7d", "Last 7 days"],
  ["30d", "Last 30 days"],
  [CUSTOM_RANGE, "Custom range…"],
];

/**
 * The filters above a customer's own messages.
 *
 * <p>Holds a draft and lifts it on submit, like the operator's `CdrFilterBar` and for the same
 * reason: filtering as you type is one database query per keystroke against a pool of eight shared
 * with the dashboard's polling, and the table flickers through four answers before settling on the
 * one that was meant. The page it replaces refetched on every keystroke in the To box.
 *
 * <p>The date boxes appear only for a custom range, and an invalid one is refused here rather than
 * sent — the route would answer 400, and a customer reading "not a valid timestamp" learns nothing
 * they can act on.
 */
export function MisFilterBar({
  initial,
  scope,
  onApply,
  busy,
}: {
  /**
   * What the boxes start on.
   *
   * <p>Read once, at mount. The parent renders this only after it has read the query string, so
   * there is no later value to synchronise — which is what keeps this from being the prop-copied-
   * into-state shape that then needs an effect to stay in step and loses whatever was half-typed
   * every time the parent re-renders.
   */
  initial: MisFilterForm;
  /** The accounts this session may see. The switcher appears only for a reseller. */
  scope: string[];
  onApply: (next: MisFilterForm) => void;
  busy: boolean;
}) {
  const { short } = useDisplayZone();
  const [draft, setDraft] = useState<MisFilterForm>(initial);

  const set = <K extends keyof MisFilterForm>(key: K, next: MisFilterForm[K]) =>
    setDraft((d) => ({ ...d, [key]: next }));

  const problem = validateMisFilters(draft);
  const custom = draft.range === CUSTOM_RANGE;

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!problem) {
      onApply(draft);
    }
  }

  function clear() {
    //the period survives a clear, as it does on the operator page: resetting it as well reads as the
    //filters having failed to apply rather than as having been removed
    const next = { ...EMPTY_MIS_FILTERS, range: draft.range, since: draft.since, until: draft.until };
    setDraft(next);
    onApply(next);
  }

  return (
    <Card>
      <CardContent className="py-4">
        <form onSubmit={submit} className="space-y-4">
          <div className="flex flex-wrap items-end gap-3">
            {scope.length > 1 && (
              <Field label="Account" className="w-full sm:w-48">
                <Select value={draft.account} onChange={(e) => set("account", e.target.value)}>
                  <option value="">All your accounts</option>
                  {scope.map((id) => (
                    <option key={id} value={id}>{id}</option>
                  ))}
                </Select>
              </Field>
            )}

            <Field label="Period" className="w-full sm:w-40">
              <Select value={draft.range} onChange={(e) => set("range", e.target.value)}>
                {PERIODS.map(([key, label]) => (
                  <option key={key} value={key}>{label}</option>
                ))}
              </Select>
            </Field>

            {custom && (
              <>
                <Field label={`From (${short})`} className="w-full sm:w-40">
                  <Input
                    type="date"
                    value={draft.since}
                    max={draft.until || undefined}
                    onChange={(e) => set("since", e.target.value)}
                  />
                </Field>
                <Field label={`To (${short})`} className="w-full sm:w-40">
                  <Input
                    type="date"
                    value={draft.until}
                    min={draft.since || undefined}
                    onChange={(e) => set("until", e.target.value)}
                  />
                </Field>
              </>
            )}

            <Field label="Outcome" className="w-full sm:w-52">
              <Select value={draft.outcome} onChange={(e) => set("outcome", e.target.value)}>
                <option value="">Any outcome</option>
                {/* first, because it is the majority of rows at any moment and the one people forget
                    exists -- most traffic has no receipt yet */}
                <option value="PENDING">Awaiting a receipt</option>
                {FINAL_STATES.map((state) => (
                  <option key={state} value={state}>{labelFor(FINAL_STATE_LABELS, state)}</option>
                ))}
              </Select>
            </Field>

            <Field label="To number" className="w-full sm:w-44">
              <Input
                value={draft.dest}
                onChange={(e) => set("dest", e.target.value)}
                placeholder="starts with…"
                inputMode="tel"
              />
            </Field>

            <Field label="Message id" className="w-full sm:w-56">
              <Input
                value={draft.msgId}
                onChange={(e) => set("msgId", e.target.value)}
                placeholder="exact"
              />
            </Field>

            {/* the only box here that looks inside a value rather than matching one, and the only one
                that can come back empty for a reason that is not "you sent no such message": content
                is recorded only when the operator has turned smsg.cdr.body on. The placeholder says
                what it searches rather than "search", so an empty result reads as a miss and not as a
                broken filter. Bounded server-side to the longest body that can exist */}
            <Field label="Message text" className="w-full sm:w-56">
              <Input
                value={draft.text}
                onChange={(e) => set("text", e.target.value)}
                placeholder="contains…"
                maxLength={MAX_TEXT_FILTER}
              />
            </Field>

            <Button type="submit" disabled={busy || !!problem} className="gap-2">
              <Search className="h-4 w-4" />
              {busy ? "Searching…" : "Search"}
            </Button>

            {hasActiveMisFilters(draft) && (
              <Button type="button" variant="ghost" onClick={clear} className="gap-2">
                <RotateCcw className="h-4 w-4" />
                Clear
              </Button>
            )}
          </div>

          {problem && <p className="text-sm text-destructive">{problem}</p>}
        </form>
      </CardContent>
    </Card>
  );
}
