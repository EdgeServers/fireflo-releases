"use client";
import { useEffect, useState } from "react";
import { ChevronDown, ChevronRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import { HealthStrip } from "./CardBits";
import { count } from "@/lib/format";
import { ageWords, backlogAlerts, backlogBadge, backlogSummary, type VendorBacklog } from "@/lib/vendor-backlog";

/** The anchor the Connectivity map's vendor menu links to (`/cp/vendors#backlog`). */
const BACKLOG_HASH = "#backlog";

/**
 * Each vendor's backlog against its limits (gateway 0.15.1): what waits, how old the oldest is, its
 * state, its bind, and where its traffic went instead. On the Vendors page, above the cards.
 *
 * <p>Closed by default behind a one-line summary, since a healthy backlog is a table of zeros. It
 * opens itself when the page is reached at `#backlog`, on load or on a later hash change, so the
 * Connectivity link lands on the table rather than on a folded card. Not {@link DisclosureSection}:
 * that one is a form section with a "N set" count, where this is a Card with a summary in its bar.
 */
export function VendorBacklogTable({ vendors }: { vendors: readonly VendorBacklog[] }) {
  const [open, setOpen] = useState(false);
  const shown = vendors.length > 0;

  useEffect(() => {
    const onHash = () => {
      if (window.location.hash === BACKLOG_HASH) {
        setOpen(true);
        document.getElementById("backlog")?.scrollIntoView({ block: "start" });
      }
    };
    onHash();
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
    //re-run when the card first renders: it is null until the backlog read answers
  }, [shown]);

  if (!shown) {
    return null;
  }
  return (
    //id="backlog": the anchor the Connectivity map's vendor menu sends you to
    <Card id="backlog" className="scroll-mt-4">
      <CardHeader bar={open} className="p-0 max-sm:p-0">
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          className="flex w-full flex-wrap items-center gap-2 px-5 py-3.5 text-left hover:bg-muted/60 max-sm:px-4 max-sm:py-3"
        >
          {open
            ? <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" />
            : <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />}
          <CardTitle className="min-w-0 flex-1 tabular-nums">{backlogSummary(vendors)}</CardTitle>
          <span className="text-xs font-semibold text-primary">{open ? "Hide" : "Show"}</span>
        </button>
      </CardHeader>
      {open && (
        <CardContent className="space-y-3">
          <p className="text-xs text-muted-foreground">
            Messages accepted for each vendor and not yet sent. A vendor over its backlog limit refuses new submits
            0x14, uncharged.
          </p>
          <p className="text-xs text-muted-foreground">
            Past three quarters of a limit its traffic prefers another member of its group; past a limit it is not
            routed to, and a submit with no other route is refused. A message waiting longer than its expiry is not
            sent but refunded.
          </p>
          <TableInCard className="tabular-nums">
            <THead>
              <tr>
                <TH>Vendor</TH>
                <TH align="right">Backlog</TH>
                <TH align="right">Oldest</TH>
                <TH>State</TH>
                <TH>Failover</TH>
                <TH align="right">Refused</TH>
                <TH align="right">Expired</TH>
              </tr>
            </THead>
            <TBody>
              {vendors.map((v) => {
                const badge = backlogBadge(v);
                return (
                  <TR key={v.worker}>
                    <TD className="font-mono text-xs">{v.worker}</TD>
                    <TD align="right">
                      {v.depth < 0 ? "—" : count(v.depth)}
                      <span className="text-muted-foreground"> / {count(v.limit)}</span>
                    </TD>
                    <TD align="right">
                      {ageWords(v.oldestAgeSeconds)}
                      <span className="text-muted-foreground"> / {ageWords(v.maxAgeSeconds)}</span>
                    </TD>
                    <TD className="whitespace-nowrap">
                      {badge ? <Badge variant={badge.tone}>{badge.label}</Badge> : <Badge variant="success">ok</Badge>}
                      {!v.bound && v.unboundSinceSeconds != null && (
                        <span className="ml-2 text-xs text-muted-foreground">no bind for {ageWords(v.unboundSinceSeconds)}</span>
                      )}
                      {v.retentionUsedPercent != null && (
                        <span className={`ml-2 text-xs ${v.retentionUsedPercent >= 50 ? "text-destructive" : "text-muted-foreground"}`}>
                          {v.retentionUsedPercent}% of retention
                        </span>
                      )}
                    </TD>
                    <TD className="font-mono text-xs">{v.failoverTarget ?? <span className="text-muted-foreground">—</span>}</TD>
                    <TD align="right" className={v.refusedTotal > 0 ? "text-destructive" : undefined}>{count(v.refusedTotal)}</TD>
                    <TD align="right" className={v.expiredTotal > 0 ? "text-destructive" : undefined}>{count(v.expiredTotal)}</TD>
                  </TR>
                );
              })}
            </TBody>
          </TableInCard>
        </CardContent>
      )}
    </Card>
  );
}

/**
 * The warning on Overview and Health: a vendor refusing, unbound past the grace after which its
 * traffic is refused, or a backlog half way through its topic's retention. Nothing otherwise, and
 * nothing on a gateway before 0.15.1.
 */
export function VendorBacklogAlert({ vendors, graceSeconds }: { vendors: readonly VendorBacklog[]; graceSeconds: number }) {
  const alerts = backlogAlerts(vendors, graceSeconds);
  if (alerts.length === 0) {
    return null;
  }
  return (
    <Card className="border-destructive/50">
      <CardHeader bar>
        <CardTitle>Vendor backlogs</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {alerts.map((a, i) => (
          <HealthStrip key={`${a.worker}-${i}`} tone={a.tone}>
            <span>
              {a.message}{" "}
              <Link href="/cp/vendors" className="underline">Vendors</Link>
            </span>
          </HealthStrip>
        ))}
      </CardContent>
    </Card>
  );
}
