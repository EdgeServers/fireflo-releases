"use client";
import { Segmented } from "@/components/ui/segmented";
import type { StatementSplit } from "@/lib/statement-sql";

/**
 * Split by: Product | Login, for the statement's table card header (operator and portal). Changing
 * it re-reads the period on screen; Login is disabled, with the reason, on a gateway without
 * `usage_daily.system_id`.
 */
export function SplitToggle({ split, onChange, loginSplit, busy = false }: {
  split: StatementSplit;
  onChange: (next: StatementSplit) => void;
  loginSplit?: { available: boolean; reason: string | null };
  busy?: boolean;
}) {
  const unavailable = loginSplit?.available === false;
  return (
    <Segmented
      label="Split by"
      options={[
        { value: "product", label: "Product" },
        {
          value: "login",
          label: "Login",
          disabled: unavailable,
          title: unavailable ? loginSplit?.reason ?? undefined : "Each login's traffic and money, the same totals",
        },
      ]}
      value={split}
      onChange={onChange}
      busy={busy}
    />
  );
}
