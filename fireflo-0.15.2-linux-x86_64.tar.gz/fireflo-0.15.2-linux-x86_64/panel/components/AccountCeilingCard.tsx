"use client";
import { useState } from "react";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { HealthStrip } from "./CardBits";
import { LimitSourceChip } from "./SourcePill";
import { usePoll } from "./usePoll";
import { count } from "@/lib/format";
import { formatTps } from "@/lib/tps-format";
import { accountHref } from "@/lib/panel-surface";
import { ceilingSummary, ceilingText, type CeilingRow, type ThroughputAnswer } from "@/lib/throughput";

/** The overview's pace: a glance, not the Limits page's five-second watch. */
const POLL_MS = 10_000;

/**
 * Overview › "SMPP ceiling": what this account may send on the listener it is active on now (or,
 * bound nowhere, the one it would bind on), the setting behind it, and the traffic against it -- the Limits page's answer in a card, with the link to the
 * page that holds the detail and the editor.
 *
 * <p>Operator only, like the throughput route it reads (which 404s for anyone else). A failed read
 * draws nothing: the card is context beside the traffic, not a gate.
 */
export function AccountCeilingCard({ id }: { id: string }) {
  const [answer, setAnswer] = useState<{ account: string; body: ThroughputAnswer } | null>(null);
  //which account's read last failed: with no good answer for it, the card stays away
  const [failedFor, setFailedFor] = useState<string | null>(null);

  const load = async () => {
    const res = await fetch(`/api/control/accounts/${encodeURIComponent(id)}/throughput`, { cache: "no-store" }).catch(() => null);
    const json = (await res?.json().catch(() => null)) as ThroughputAnswer | null;
    //a failed read keeps the last good one on screen
    if (res?.ok && json) {
      setAnswer({ account: id, body: json });
      setFailedFor(null);
    } else {
      setFailedFor(id);
    }
  };
  usePoll(load, POLL_MS, true, id);

  //a reply for the account this card showed before a navigation is not this one's
  const body = answer?.account === id ? answer.body : null;
  if (!body && failedFor === id) {
    return null;
  }

  return (
    <Card>
      <CardHeader bar className="flex flex-row items-baseline justify-between gap-2 space-y-0">
        <CardTitle>SMPP ceiling</CardTitle>
        <span className="text-xs text-muted-foreground">live</span>
      </CardHeader>
      <CardContent className="space-y-3 text-sm">
        {!body ? (
          <p className="text-xs text-muted-foreground">Reading the gateway…</p>
        ) : body.unsupported || !body.data ? (
          <p className="text-xs text-muted-foreground">Ceilings need gateway 0.15.1</p>
        ) : (
          <Summary id={id} summary={ceilingSummary(body.data)} />
        )}
        <Link href={accountHref(id, "limits")} className="inline-block text-primary hover:underline">
          Open limits →
        </Link>
      </CardContent>
    </Card>
  );
}

function Summary({ id, summary }: { id: string; summary: ReturnType<typeof ceilingSummary> }) {
  return (
    <>
      {summary.throttledLastMinute > 0 && (
        <HealthStrip>
          {count(summary.throttledLastMinute)} submits refused 0x58 in the last minute (not charged)
        </HealthStrip>
      )}

      {!summary.active ? (
        <p className="text-xs text-muted-foreground">No SMPP listener on this gateway.</p>
      ) : summary.idle ? (
        <div className="space-y-1.5">
          <p className="text-xs text-muted-foreground">
            Not bound on any listener now. When it binds on{" "}
            <strong className="font-semibold text-foreground">{summary.active.name}</strong>
            {summary.active.port != null && ` :${summary.active.port}`} its ceiling is:
          </p>
          <ListenerRow row={summary.active} />
        </div>
      ) : (
        <div className="space-y-1.5">
          <p className="text-xs text-muted-foreground">Active on</p>
          <ListenerRow row={summary.active} />
        </div>
      )}
      {summary.others > 0 && (
        <p className="text-xs text-muted-foreground">
          {summary.others} more listener{summary.others === 1 ? "" : "s"}, not active for this account ·{" "}
          <Link href={accountHref(id, "limits")} className="text-primary hover:underline">
            see all on the details page
          </Link>
        </p>
      )}

      {summary.logins.length > 0 && (
        <div className="space-y-1 border-t border-border pt-3 text-xs">
          <p className="font-medium">Logins with their own TPS</p>
          <ul className="space-y-1">
            {summary.logins.map((g) => (
              <li key={g.systemId}>
                <span className="font-mono">{g.systemId}</span> dedicated{" "}
                <strong className="tabular-nums">{g.ceiling == null ? "—" : `${formatTps(g.ceiling)}/s`}</strong>{" "}
                <span className="text-muted-foreground">
                  · login TPS, comes first · {g.measured != null && g.measured > 0 ? `now ${formatTps(g.measured)}/s` : "no traffic"}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <p className="text-xs text-muted-foreground">
        Login TPS comes first and sits outside the split; else the account’s own{" "}
        <code className="font-mono">conf.maxRate.{id}</code>; else the lower of the listener default and Throughput
        limit ÷ active accounts. Over the ceiling a submit is refused 0x58 and not charged.
      </p>
    </>
  );
}

function ListenerRow({ row }: { row: CeilingRow }) {
  const ceiling = ceilingText(row.ceiling);
  return (
    <div className="space-y-1">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <span className="min-w-0">
          <span className="font-semibold">{row.name}</span>
          {row.port != null && <span className="ml-1.5 text-xs text-muted-foreground">:{row.port}</span>}
        </span>
        <span className="text-lg font-semibold tabular-nums">{ceiling ?? "unlimited"}</span>
      </div>
      {row.usage != null && (
        <div
          className="h-1.5 overflow-hidden rounded-full bg-muted"
          role="meter"
          aria-label={`${row.name}: ${Math.round(row.usage * 100)}% of the ceiling`}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={Math.round(row.usage * 100)}
        >
          <div className="h-full bg-foreground/70" style={{ width: `${row.usage * 100}%` }} />
        </div>
      )}
      <div className="flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-xs">
        {/* the chip without the port-share figures: the note beside it carries them */}
        <LimitSourceChip ceiling={{ source: row.ceiling.source, key: row.ceiling.key, tier: row.ceiling.tier }} />
        <span className="text-muted-foreground">{row.note}</span>
      </div>
    </div>
  );
}
