"use client";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import {
  Activity, ArrowRight, Ban, ChevronsUpDown, CircleSlash, Database, Ellipsis, Gauge, Hand, ListOrdered, Network, Pause, Play,
  RotateCw, ShieldX, SlidersHorizontal, Unplug, Users, Waypoints, type LucideIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { HealthStrip } from "./CardBits";
import { useConfirmChange } from "./ConfirmProvider";
import { useConfirmEnabled } from "./ConnectionStatus";
import { ForceDisconnectDialog } from "./ForceDisconnectDialog";
import type { useWorkers } from "./useWorkers";
import type { Anchor } from "./ConnectivityCanvas";
import type { BoxAction, MapBox } from "@/lib/connectivity-layout";
import { KIND, type Worker } from "@/lib/worker-types";
import { cn } from "@/lib/utils";

type Workers = ReturnType<typeof useWorkers>;

/** How each action reads in the menu, and its icon on the hover strip. */
const META: Record<BoxAction, { label: string; icon: LucideIcon; danger?: boolean }> = {
  "open-account": { label: "Open account", icon: Users },
  "set-rate": { label: "Set rate ceiling on this port…", icon: Gauge },
  "set-binds": { label: "Set binds per customer…", icon: Network },
  "client-sessions": { label: "Show its sessions", icon: ListOrdered },
  "client-live": { label: "Live traffic for this client", icon: Activity },
  "drop-binds": { label: "Drop all binds…", icon: Unplug, danger: true },
  toggle: { label: "Open / close", icon: ChevronsUpDown },
  "sort-rate": { label: "Sort by rate", icon: ListOrdered },
  "sort-binds": { label: "Sort by binds", icon: ListOrdered },
  "sort-name": { label: "Sort by name", icon: ListOrdered },
  "next-page": { label: "Next ten", icon: ArrowRight },
  "open-listener": { label: "Open listener", icon: ArrowRight },
  hold: { label: "Stop accepting", icon: Hand },
  release: { label: "Resume accepting", icon: Play },
  "default-rate": { label: "Default rate ceiling…", icon: Gauge },
  overrides: { label: "Per-account overrides…", icon: SlidersHorizontal },
  connections: { label: "Connections", icon: ListOrdered },
  disable: { label: "Disable listener", icon: Ban, danger: true },
  health: { label: "Health", icon: Activity },
  queues: { label: "Queues", icon: ListOrdered },
  kafka: { label: "Kafka", icon: Waypoints },
  routing: { label: "Routing table", icon: Waypoints },
  refused: { label: "Refused last hour", icon: ShieldX },
  "slow-queries": { label: "Slow queries", icon: Database },
  "open-vendor": { label: "Open vendor", icon: ArrowRight },
  pause: { label: "Pause sending (queue kept)", icon: Pause },
  unpause: { label: "Resume sending", icon: Play },
  suspend: { label: "Suspend (route around it)", icon: CircleSlash },
  resume: { label: "Resume routing to it", icon: Play },
  restart: { label: "Rebind now", icon: RotateCw },
  "set-tps": { label: "Set vendor TPS…", icon: Gauge },
  backlog: { label: "Backlog and sessions", icon: ListOrdered },
};

/** The label a group's toggle reads as, now. */
function labelOf(box: MapBox, action: BoxAction): string {
  if (action === "toggle") {
    if (box.kind === "portsMore") {
      return "Show every port";
    }
    if (box.kind === "clientMore") {
      return "Close the group";
    }
    return box.frame ? "Close the group" : "Open the group";
  }
  return META[action].label;
}

/**
 * A box's actions, over the canvas: two or three icon buttons and a `⋯` on hover, and the full menu
 * under the box when `⋯` is pressed (or Enter on a focused box).
 *
 * <p>Plain buttons and links, as `ui/menu.tsx` explains; arrow keys move between the items, Escape
 * closes and hands focus back to the map.
 */
export function ConnectivityBoxMenu({
  box,
  anchor,
  menuOpen,
  openMenu,
  close,
  keep,
  onAction,
  bounds,
}: {
  box: MapBox;
  anchor: Anchor;
  menuOpen: boolean;
  openMenu: () => void;
  close: () => void;
  keep: (on: boolean) => void;
  onAction: (box: MapBox, action: BoxAction) => void;
  /** The map's visible size, so the menu stays inside it. */
  bounds: { width: number };
}) {
  const panel = useRef<HTMLDivElement>(null);
  //the map re-renders on every poll with a new `close`; the menu must not refocus its first item each time
  const closeRef = useRef(close);
  useEffect(() => {
    closeRef.current = close;
  });

  useEffect(() => {
    if (!menuOpen) {
      return;
    }
    const close = () => closeRef.current();
    panel.current?.querySelector<HTMLElement>("button")?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        close();
        return;
      }
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        const items = Array.from(panel.current?.querySelectorAll<HTMLElement>("button") ?? []);
        const at = items.indexOf(document.activeElement as HTMLElement);
        e.preventDefault();
        items[(at + (e.key === "ArrowDown" ? 1 : items.length - 1)) % items.length]?.focus();
      }
    };
    const onDown = (e: PointerEvent) => {
      if (!panel.current?.contains(e.target as Node)) {
        close();
      }
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("pointerdown", onDown);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("pointerdown", onDown);
    };
  }, [menuOpen]);

  const run = (action: BoxAction) => {
    close();
    onAction(box, action);
  };

  //the strip sits on the box's top-right corner, inside it, so the pointer reaches it without leaving
  const stripTop = anchor.top + (box.frame ? 2 : -12);
  const stripRight = Math.max(0, bounds.width - (anchor.left + anchor.width) - 2);
  const menuLeft = Math.max(4, Math.min(anchor.left + anchor.width - 220, bounds.width - 228));

  return (
    <>
      <div
        className="absolute z-30 flex gap-0.5 rounded-md border border-border bg-card p-0.5 shadow-sm"
        style={{ top: stripTop, right: stripRight }}
        onPointerEnter={() => keep(true)}
        onPointerLeave={() => keep(false)}
      >
        {box.quick.map((a) => {
          const Icon = META[a].icon;
          return (
            <button
              key={a}
              type="button"
              title={labelOf(box, a)}
              aria-label={`${labelOf(box, a)}: ${box.lines[0]}`}
              onClick={() => run(a)}
              className={cn(
                "inline-flex h-6 w-6 items-center justify-center rounded text-foreground hover:bg-accent",
                META[a].danger && "text-destructive"
              )}
            >
              <Icon className="h-3.5 w-3.5" aria-hidden />
            </button>
          );
        })}
        <button
          type="button"
          title="More"
          aria-label={`Actions for ${box.lines[0]}`}
          aria-haspopup="true"
          aria-expanded={menuOpen}
          onClick={openMenu}
          className="inline-flex h-6 w-6 items-center justify-center rounded text-foreground hover:bg-accent"
        >
          <Ellipsis className="h-3.5 w-3.5" aria-hidden />
        </button>
      </div>
      {menuOpen && (
        <div
          ref={panel}
          className="absolute z-40 w-56 rounded-lg border border-border bg-popover p-1 text-sm text-popover-foreground shadow-lg"
          style={{ top: anchor.top + anchor.height + 4, left: menuLeft }}
          onPointerEnter={() => keep(true)}
        >
          <p className="truncate px-2 py-1 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">
            {box.lines[0].replace(/^[▸▾] /, "")}
          </p>
          {box.actions.map((a) => (
            <button
              key={a}
              type="button"
              onClick={() => run(a)}
              className={cn(
                "block w-full rounded-md px-2 py-1.5 text-left hover:bg-accent focus-visible:bg-accent focus-visible:outline-none",
                META[a].danger && "text-destructive"
              )}
            >
              {labelOf(box, a)}
            </button>
          ))}
        </div>
      )}
    </>
  );
}

/** `smppserver.dltsmpp` → `dltsmpp`: what the panel's routes and pages call a worker. */
export function instanceName(full: string): string {
  const at = full.indexOf(".");
  return at < 0 ? full : full.slice(at + 1);
}

function propOf(workers: readonly Worker[], name: string, key: string): string {
  return workers.find((w) => w.name === name)?.properties.find((p) => p.key === key)?.value ?? "";
}

interface Prompt {
  worker: string;
  type: "server" | "vendor";
  key: string;
  title: string;
  description: string;
  current: string;
  unit: string;
}

/**
 * What the box actions do. Navigation goes to the page that already does the thing; every state
 * change confirms once and goes through the same audited calls the listener and vendor pages make
 * (`useWorkers`: the stored property, then the live worker action), or through the worker-property
 * PATCH for a number, or the force-disconnect dialog for Drop all binds.
 *
 * @param onView the actions that change the map itself -- open, page, sort
 */
export function useBoxActions({
  servers,
  vendors,
  onView,
}: {
  servers: Workers;
  vendors: Workers;
  onView: (box: MapBox, action: BoxAction) => void;
}): { run: (box: MapBox, action: BoxAction) => void; dialogs: ReactNode; notice: string; error: string } {
  const router = useRouter();
  const confirm = useConfirmChange();
  const confirmEnabled = useConfirmEnabled();
  const [prompt, setPrompt] = useState<Prompt | null>(null);
  const [dropping, setDropping] = useState<{ account: string; listener: string } | null>(null);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  const go = (href: string) => router.push(href);

  const run = async (box: MapBox, action: BoxAction) => {
    setNotice("");
    setError("");
    const listener = box.listener ? instanceName(box.listener) : instanceName(box.ref);
    const name = instanceName(box.ref);
    const enc = encodeURIComponent;
    switch (action) {
      case "toggle":
      case "sort-rate":
      case "sort-binds":
      case "sort-name":
      case "next-page":
        onView(box, action);
        return;
      //─── clients ───
      case "open-account":
        return go(`/cp/accounts/${enc(box.ref)}`);
      case "client-sessions":
        return go(`/cp/servers/${enc(listener)}?tab=sessions`);
      case "client-live":
        return go(`/cp/servers/${enc(listener)}?tab=status&filter=${enc(box.ref)}`);
      case "set-rate":
      case "set-binds": {
        const key = `${action === "set-rate" ? "conf.maxRate" : "conf.maxConnectionsPerUser"}.${box.ref}`;
        setPrompt({
          worker: listener,
          type: "server",
          key,
          title: action === "set-rate" ? `Rate ceiling for ${box.ref} on ${listener}` : `Binds for ${box.ref} on ${listener}`,
          description: action === "set-rate"
            ? `Messages per second this account may submit on ${listener}, shared by all of its logins. 0 is unlimited; empty falls back to the listener's default.`
            : `How many binds this account may hold on ${listener} at once. 0 is unlimited; empty falls back to the listener's default.`,
          current: propOf(servers.workers, listener, key),
          unit: action === "set-rate" ? "msg/s" : "binds",
        });
        return;
      }
      case "drop-binds":
        setDropping({ account: box.ref, listener });
        return;
      //─── listeners ───
      case "open-listener":
        return go(`/cp/servers/${enc(name)}`);
      case "connections":
        return go(`/cp/servers/${enc(name)}?tab=sessions`);
      case "default-rate":
        return go(`/cp/servers/${enc(name)}?edit=1&open=customerDefaults`);
      case "overrides":
        return go(`/cp/servers/${enc(name)}?tab=settings&focus=overrides`);
      case "hold":
      case "release": {
        const on = action === "hold";
        const ok = await confirm({
          title: on ? `Stop accepting on ${name}?` : `Resume accepting on ${name}?`,
          consequence: on
            ? `Every client bound to ${name} has its submits refused with a retryable error, and its receipts are held, until you resume. Nobody is disconnected.`
            : `${name} accepts submits again and delivers the receipts it held.`,
          confirmLabel: on ? "Stop accepting" : "Resume",
          tone: "caution",
        });
        if (ok) {
          await servers.setProperty(name, "pause", on, on ? "Stop accepting" : "Resume");
        }
        return;
      }
      case "disable":
        if (await confirmEnabled(name, KIND.server, false)) {
          await servers.setEnabled(name, false);
        }
        return;
      //─── the gateway ───
      case "health":
        return go("/cp/health");
      case "queues":
        return go("/cp/queues");
      case "kafka":
        return go("/cp/kafka");
      case "routing":
        return go("/cp/routing");
      case "refused":
        return go("/cp/rejected");
      //─── the database ───
      case "slow-queries":
        return go("/cp/database/slow-queries");
      //─── vendors ───
      case "open-vendor":
        return go(`/cp/vendors/${enc(name)}`);
      case "backlog":
        return go("/cp/vendors#backlog");
      case "pause":
      case "unpause": {
        const on = action === "pause";
        const ok = await confirm({
          title: on ? `Pause sending on ${name}?` : `Resume sending on ${name}?`,
          consequence: on
            ? `${name} stays bound and keeps its queue, but sends nothing until you resume; the queue grows for as long as it is held.`
            : `${name} sends its queue and new traffic again.`,
          confirmLabel: on ? "Pause sending" : "Resume sending",
          tone: "caution",
        });
        if (ok) {
          await vendors.setProperty(name, "pause", on, on ? "Hold" : "Release hold");
        }
        return;
      }
      case "suspend":
      case "resume": {
        const on = action === "suspend";
        const ok = await confirm({
          title: on ? `Suspend ${name}?` : `Resume routing to ${name}?`,
          consequence: on
            ? `${name} is taken out of routing: new traffic goes to the other routes, and what it already queued is held until you resume.`
            : `${name} is routed to again.`,
          confirmLabel: on ? "Suspend" : "Resume",
          tone: "caution",
        });
        if (ok) {
          await vendors.setProperty(name, "suspend", on, on ? "Stop sending" : "Resume sending");
        }
        return;
      }
      case "restart": {
        const ok = await confirm({
          title: `Rebind ${name} now?`,
          consequence: `Every connection of the vendor ${name} is closed and opened again; messages in flight are retried.`,
          confirmLabel: "Rebind",
          tone: "caution",
        });
        if (ok) {
          await vendors.restart(name);
        }
        return;
      }
      case "set-tps":
        setPrompt({
          worker: name,
          type: "vendor",
          key: "tps",
          title: `Send rate for ${name}`,
          description: "Messages per second the gateway sends to this vendor. 0 is unlimited; empty falls back to the default.",
          current: propOf(vendors.workers, name, "tps"),
          unit: "msg/s",
        });
        return;
    }
  };

  const save = async (p: Prompt, value: string) => {
    const ok = await confirm({
      title: p.title,
      consequence: value === ""
        ? `The setting is removed from ${p.worker}; the default applies. The gateway picks it up within thirty seconds.`
        : `${p.worker} is set to ${value} ${p.unit}. The gateway picks it up within thirty seconds.`,
      confirmLabel: value === "" ? "Remove" : "Save",
      tone: "caution",
      changes: [{ label: p.key, from: p.current || "not set", to: value || "not set" }],
    });
    if (!ok) {
      return false;
    }
    const res = await fetch(`/api/control/workers/${encodeURIComponent(p.worker)}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ property: { key: p.key, value } }),
    }).catch(() => null);
    const json = await res?.json().catch(() => null);
    if (!res?.ok) {
      setError(json?.error ?? (res ? `Request failed (${res.status})` : "Could not reach the panel's API."));
      return false;
    }
    setNotice(`${p.key} on ${p.worker} ${value === "" ? "removed" : `set to ${value}`} — the gateway picks it up within thirty seconds.`);
    await (p.type === "server" ? servers.load() : vendors.load());
    return true;
  };

  const dialogs = (
    <>
      {prompt && (
        <ValueDialog
          key={`${prompt.worker}|${prompt.key}`}
          prompt={prompt}
          onClose={() => setPrompt(null)}
          onSave={async (value) => {
            if (await save(prompt, value)) {
              setPrompt(null);
            }
          }}
        />
      )}
      {dropping && (
        <ForceDisconnectDialog
          initialKind="account"
          initialValue={dropping.account}
          kinds={["account"]}
          listener={dropping.listener}
          onClose={() => setDropping(null)}
        />
      )}
    </>
  );

  return { run: (box, action) => void run(box, action), dialogs, notice: notice || servers.notice || vendors.notice, error: error || servers.error || vendors.error };
}

/** One number for one setting: a whole number, or empty to remove it. */
function ValueDialog({ prompt, onClose, onSave }: { prompt: Prompt; onClose: () => void; onSave: (value: string) => Promise<void> }) {
  const [value, setValue] = useState(prompt.current);
  const [busy, setBusy] = useState(false);
  const trimmed = value.trim();
  const invalid = trimmed !== "" && !/^\d+$/.test(trimmed);
  return (
    <Dialog open onClose={onClose} title={prompt.title} description={prompt.description}>
      <form
        className="space-y-3"
        onSubmit={async (e) => {
          e.preventDefault();
          if (invalid) {
            return;
          }
          setBusy(true);
          try {
            await onSave(trimmed);
          } finally {
            setBusy(false);
          }
        }}
      >
        <label className="block space-y-1 text-sm">
          <span className="font-medium">
            {prompt.unit} <span className="font-mono text-xs text-muted-foreground">{prompt.key}</span>
          </span>
          <Input inputMode="numeric" value={value} onChange={(e) => setValue(e.target.value)} placeholder="not set" autoFocus aria-invalid={invalid} />
        </label>
        {invalid && <HealthStrip tone="destructive">A whole number of 0 or more, or nothing to remove the setting.</HealthStrip>}
        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
          <Button type="submit" disabled={busy || invalid || trimmed === prompt.current.trim()}>
            {busy ? "Saving…" : "Continue"}
          </Button>
        </div>
      </form>
    </Dialog>
  );
}
