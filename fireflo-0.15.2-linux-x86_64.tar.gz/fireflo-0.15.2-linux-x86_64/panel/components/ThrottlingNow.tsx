"use client";
import Link from "next/link";
import { Gauge } from "lucide-react";
import { HealthStrip } from "./CardBits";
import { useHealth } from "./useHealth";
import { count } from "@/lib/format";
import { listenerName } from "@/lib/throughput";

/** Accounts named before "and n more". */
const NAMED = 3;

/**
 * "Throttling now" on Overview: the accounts this node answered 0x58 in the last minute, busiest
 * first, each linked to its Limits tab (health `throttling`, gateway 0.15.1).
 *
 * <p>Only when somebody is being throttled. An account at its ceiling is often exactly what was
 * agreed, so this is a strip to notice rather than an alarm; an older gateway shows nothing.
 */
export function ThrottlingNow() {
  const { health } = useHealth();
  const busy = (health?.throttling ?? []).filter((t) => (t.last_minute ?? 0) > 0);
  if (!busy.length) {
    return null;
  }
  const total = busy.reduce((sum, t) => sum + (t.last_minute ?? 0), 0);
  return (
    <HealthStrip tone="warning" action={<Link href="/cp/rejected" className="font-medium underline">Refused →</Link>}>
      <Gauge className="h-3.5 w-3.5" aria-hidden />
      <span>
        <b>Throttling now</b>: {count(total)} submits answered 0x58 in the last minute —{" "}
        {busy.slice(0, NAMED).map((t, i) => (
          <span key={t.account}>
            {i > 0 && ", "}
            <Link href={`/cp/accounts/${encodeURIComponent(t.account)}/limits`} className="font-medium underline-offset-2 hover:underline">
              {t.account}
            </Link>{" "}
            {count(t.last_minute ?? 0)}
            {(t.listeners ?? []).length > 0 && ` on ${(t.listeners ?? []).map(listenerName).join(", ")}`}
          </span>
        ))}
        {busy.length > NAMED && `, and ${busy.length - NAMED} more`}.
      </span>
    </HealthStrip>
  );
}
