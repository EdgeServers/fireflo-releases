"use client";
import { useCallback, useMemo, useRef, useState } from "react";
import { CartesianGrid, Line, LineChart, XAxis, YAxis } from "recharts";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { AccountTypeahead, type AccountOption } from "./AccountTypeahead";
import { CardActions } from "./CardBits";
import { useAccounts } from "./useAccounts";
import { useHealth } from "./useHealth";
import { usePoll } from "./usePoll";
import { count } from "@/lib/format";
import { KIND, type WorkerType } from "@/lib/worker-types";
import type { QueueHistory } from "@/lib/queue-history";
import { rateOf } from "@/lib/live-rates";
import { formatClock, zoneShortName } from "@/lib/datetime";
import { useDisplayZone } from "@/components/DisplayZoneProvider";

/** Mirrors `LIVE_WINDOW_MS` / `LIVE_BUCKET_SECONDS` in `lib/metrics-queries.ts`, which is server-only. */
const WINDOW_MS = 15 * 60_000;
const BUCKET_MS = 10_000;
const REFRESH_MS = 10_000;
/**
 * How far behind its last read the next one starts. The CDR writer batches, so a receipt whose
 * `final_at` falls in the newest bucket can land a few seconds after the bucket was read; re-reading
 * three buckets and replacing them costs thirty seconds of rows and misses nothing.
 */
const OVERLAP_MS = 3 * BUCKET_MS;

interface LiveRow {
  t: number;
  key: string;
  /** null when the read did not touch the submits (no key): MT then comes from the gateway. */
  mt: number | null;
  dlr: number;
}

interface LiveRead {
  rows: LiveRow[];
  since: number;
  until: number;
}

interface Point {
  t: number;
  mt: number | null;
  dlr: number;
  queued: number | null;
}

const chartConfig = {
  mt: { label: "MT/s", color: "var(--color-chart-2)" },
  dlr: { label: "DLR/s", color: "var(--color-chart-1)" },
  queued: { label: "Queued", color: "var(--color-chart-3)" },
} satisfies ChartConfig;

/** A poll's time as the live charts' tooltips name it: `15:11:02 IST`, in the display zone. */
export function clock(t: number, zone: string): string {
  return `${formatClock(t, zone)} ${zoneShortName(zone, t)}`;
}

/** The axis tick: `15:11`. */
export function clockTick(t: number, zone: string): string {
  return formatClock(t, zone, { seconds: false });
}

function bucketOf(t: number): number {
  return Math.floor(t / BUCKET_MS) * BUCKET_MS;
}

/**
 * MT, DLR and queued messages over the last fifteen minutes, on the Vendors and Servers pages.
 *
 * <p>Three sources on one time axis:
 *
 * <ul>
 *   <li><b>MT/s</b> is the gateway's own `submit_sm` counter per worker, read from the health poll
 *       this page already runs, as a delta between polls (`lib/live-rates.ts`). Like the queue line
 *       it starts where the page was opened. (CP-P6: it used to be fifteen minutes of `cdr_submit`
 *       re-aggregated every ten seconds by every open tab.)</li>
 *   <li><b>DLR/s</b> comes from the call records -- nothing in the gateway counts receipts per
 *       worker -- read incrementally: the whole window once, then only the slice since the last
 *       read.</li>
 *   <li><b>Queued</b> is never stored anywhere -- it exists only in the health snapshot -- so its
 *       line is the polls this page has seen (`useHealth`'s `queueHistory`).</li>
 * </ul>
 *
 * <p>The exception is one <b>account</b>: health knows workers, never which account sent what, so
 * with an account picked both MT and DLR come from the records, filtered to it in SQL. A single
 * vendor's DLR needs the same read, because a receipt's vendor is only known through its submit.
 *
 * <p>Rates on the left axis, a count on the right: MT/s and DLR/s are comparable to the gateway's
 * TPS, a queue is a number of messages, and drawn on one axis a backlog of thousands flattens the
 * two rates into the floor.
 *
 * @param kind vendors chart per vendor (keys are full worker names, as `trafficKey`); servers chart
 *     per account, whose queue cannot be split by account
 * @param vendorKeys every configured vendor's full name, so the picker lists an idle one too
 */
export function LiveTrafficChart({
  kind,
  queueHistory,
  vendorKeys = [],
}: {
  kind: WorkerType;
  queueHistory: QueueHistory;
  vendorKeys?: string[];
}) {
  const { zone } = useDisplayZone();
  const isVendor = kind === KIND.vendor;
  const { rateHistory } = useHealth();
  const [rows, setRows] = useState<LiveRow[] | null>(null);
  //when the rows were read, taken in the fetch callback: reading the clock during render is impure,
  //and the window's right edge has to move with the data anyway
  const [readAt, setReadAt] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [picked, setPicked] = useState("");
  //what the retained rows are for and where they stop, so the next read can be a slice. Refs, not
  //state: they are bookkeeping for the fetch and must not cause a render of their own
  const kept = useRef<{ key: string; rows: LiveRow[]; until: number } | null>(null);
  //which read is the newest; an older one answering late must not overwrite it
  const generation = useRef(0);

  const load = useCallback(async () => {
    const key = picked;
    const mine = ++generation.current;
    const prior = kept.current?.key === key ? kept.current : null;
    const params = new URLSearchParams({ kind: isVendor ? "vendor" : "server" });
    if (key) {
      params.set("key", key);
    }
    if (prior) {
      params.set("since", String(prior.until - OVERLAP_MS));
    }
    try {
      const res = await fetch(`/api/control/traffic-live?${params}`, { cache: "no-store" });
      const body = await res.json();
      //the picker moved, or a newer read went out, while this was in flight: these rows answer a
      //question no longer asked
      if (mine !== generation.current) {
        return;
      }
      if (!res.ok) {
        setError(body?.error ?? `Request failed (${res.status})`);
        return;
      }
      const read = body.data as LiveRead;
      const floor = read.until - WINDOW_MS;
      //rows before the slice are kept, rows inside it are replaced by the fresh read
      const merged = [
        ...(prior?.rows ?? []).filter((r) => r.t < read.since && r.t >= floor),
        ...read.rows,
      ];
      kept.current = { key, rows: merged, until: read.until };
      setError(null);
      setRows(merged);
      setReadAt(read.until);
    } catch {
      setError("Could not reach the panel's API.");
    }
  }, [isVendor, picked]);

  //a change of key restarts the poll with an immediate full-window read
  usePoll(load, REFRESH_MS, true, picked);

  //the picker lists what is configured and what health has seen send, so an idle vendor and one
  //that only exists on the gateway both appear
  const options = useMemo(() => {
    const keys = new Set(isVendor ? vendorKeys : []);
    if (isVendor) {
      const prefix = `${kind}.`;
      for (const sample of rateHistory.samples.slice(-1)) {
        for (const name of Object.keys(sample.mt)) {
          if (name.startsWith(prefix)) keys.add(name);
        }
      }
    }
    return [...keys].sort((a, b) => a.localeCompare(b));
  }, [rateHistory, vendorKeys, isVendor, kind]);

  //a queue belongs to a server worker, and several accounts share one -- so with an account picked
  //there is no honest queue figure to draw, and a zero line would claim one
  const queueShown = isVendor || picked === "";
  //an account's MT is only in the records; a vendor's, or everything's, is in the gateway's counters
  const mtFromRows = !isVendor && picked !== "";

  const points = useMemo<Point[]>(() => {
    //the right edge is the newest thing known -- the last read or the last health poll, whichever
    //came later -- so no line is cut off by a read a few seconds older than another
    const now = Math.max(readAt, queueHistory.at(-1)?.t ?? 0, rateHistory.samples.at(-1)?.t ?? 0);
    if (now === 0) {
      return [];
    }
    const first = bucketOf(now - WINDOW_MS);
    const byBucket = new Map<number, Point>();
    for (let t = first; t <= now; t += BUCKET_MS) {
      byBucket.set(t, { t, mt: mtFromRows ? 0 : null, dlr: 0, queued: null });
    }
    for (const r of rows ?? []) {
      const p = byBucket.get(bucketOf(r.t));
      if (p) {
        p.dlr += r.dlr;
        if (mtFromRows) {
          p.mt = (p.mt ?? 0) + (r.mt ?? 0);
        }
      }
    }
    const prefix = `${kind}.`;
    const mine = picked ? (name: string) => name === picked : (name: string) => name.startsWith(prefix);
    if (!mtFromRows) {
      for (const sample of rateHistory.samples) {
        const p = byBucket.get(bucketOf(sample.t));
        if (p) {
          //the latest poll in a bucket wins; polls and buckets are both ten seconds, so this is rare
          p.mt = rateOf(sample, mine);
        }
      }
    }
    if (queueShown) {
      for (const sample of queueHistory) {
        const p = byBucket.get(bucketOf(sample.t));
        if (!p) {
          continue;
        }
        p.queued = picked
          ? sample.depth[picked] ?? 0
          : Object.entries(sample.depth).reduce((sum, [name, d]) => (name.startsWith(prefix) ? sum + d : sum), 0);
      }
    }
    return [...byBucket.values()].map((p) => ({
      ...p,
      //rows are counts per bucket; rate samples are already per second
      mt: p.mt == null ? null : Math.round((mtFromRows ? p.mt / (BUCKET_MS / 1000) : p.mt) * 10) / 10,
      dlr: Math.round((p.dlr / (BUCKET_MS / 1000)) * 10) / 10,
    }));
  }, [rows, readAt, picked, queueHistory, rateHistory, queueShown, mtFromRows, kind]);

  //the newest bucket is still filling, so the footer quotes the one before it rather than a rate
  //that reads half of what is really flowing
  const settled = points.length > 1 ? points[points.length - 2] : points[0];
  const lastQueue = [...points].reverse().find((p) => p.queued != null)?.queued ?? null;
  const quiet = rows !== null && !points.some((p) => (p.mt ?? 0) > 0 || p.dlr > 0);
  const label = (key: string) => (isVendor ? key.replace(/^smppclient\./, "") : key);

  return (
    <Card>
      <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
        <span className="text-title">Traffic · last 15 minutes</span>
        <CardActions>
          <div className="flex items-center gap-3 text-xs text-muted-foreground" aria-hidden>
            {(Object.keys(chartConfig) as (keyof typeof chartConfig)[])
              .filter((k) => k !== "queued" || queueShown)
              .map((k) => (
                <span key={k} className="flex items-center gap-1.5">
                  <span className="h-0.5 w-3 rounded" style={{ backgroundColor: chartConfig[k].color }} />
                  {chartConfig[k].label}
                </span>
              ))}
          </div>
          {isVendor ? (
            <select
              value={picked}
              onChange={(e) => setPicked(e.target.value)}
              aria-label="Show one vendor"
              className="h-11 rounded-md border border-border bg-background px-3 text-sm focus:border-primary focus:outline-none md:h-9"
            >
              <option value="">All vendors</option>
              {options.map((k) => (
                <option key={k} value={k}>
                  {label(k)}
                </option>
              ))}
            </select>
          ) : (
            <AccountPicker value={picked} onChange={setPicked} />
          )}
        </CardActions>
      </CardHeader>
      <CardContent className="pt-3">
        {error ? (
          <div className="flex h-56 items-center justify-center text-sm text-destructive">{error}</div>
        ) : (
          <div className="relative">
            <ChartContainer config={chartConfig} className="h-56 w-full">
              <LineChart data={points} margin={{ top: 8, right: 4, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--color-border)" />
                <XAxis
                  dataKey="t"
                  type="number"
                  scale="time"
                  domain={["dataMin", "dataMax"]}
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                  tickFormatter={(t: number) => clockTick(t, zone)}
                  minTickGap={40}
                />
                <YAxis
                  yAxisId="rate"
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                  width={40}
                  allowDecimals={false}
                />
                {queueShown && (
                  <YAxis
                    yAxisId="queue"
                    orientation="right"
                    tickLine={false}
                    axisLine={false}
                    tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                    width={48}
                    allowDecimals={false}
                  />
                )}
                <ChartTooltip
                  labelFormatter={(t) => clock(Number(t), zone)}
                  content={<ChartTooltipContent indicator="dot" />}
                />
                <Line yAxisId="rate" dataKey="mt" stroke={chartConfig.mt.color} strokeWidth={2} dot={false} connectNulls={false} isAnimationActive={false} />
                <Line yAxisId="rate" dataKey="dlr" stroke={chartConfig.dlr.color} strokeWidth={2} dot={false} isAnimationActive={false} />
                {queueShown && (
                  <Line
                    yAxisId="queue"
                    dataKey="queued"
                    stroke={chartConfig.queued.color}
                    strokeWidth={2}
                    strokeDasharray="5 3"
                    dot={false}
                    connectNulls={false}
                    isAnimationActive={false}
                  />
                )}
              </LineChart>
            </ChartContainer>
            {quiet && (
              <p className="pointer-events-none absolute inset-x-0 top-1/3 text-center text-sm text-muted-foreground">
                No messages in the last 15 minutes
              </p>
            )}
          </div>
        )}
      </CardContent>
      <CardFooter className="border-t border-border pt-3 text-sm text-muted-foreground">
        <span>
          MT <span className="tabular-nums text-foreground">{settled?.mt != null ? count(settled.mt) : "—"}</span>/s ·
          DLR <span className="tabular-nums text-foreground">{settled ? count(settled.dlr) : "—"}</span>/s
          {queueShown && (
            <>
              {" "}·{" "}
              <span className="tabular-nums text-foreground">{lastQueue == null ? "—" : count(lastQueue)}</span>{" "}
              queued
            </>
          )}
        </span>
        <span className="ml-auto text-xs">
          {queueShown
            ? "MT/s and queued counts from when this page was opened; the gateway keeps neither earlier."
            : "Queues belong to a server, not an account, so there is no queue line for one account."}
        </span>
      </CardFooter>
    </Card>
  );
}

/**
 * The Servers chart's account filter: a typeahead over the account catalogue.
 *
 * <p>A component of its own so the catalogue is only fetched on the page that needs it. It no
 * longer marks who is "sending now": that came from the fifteen-minute submit scan this chart
 * stopped running, and health cannot say which account a submit came from.
 */
function AccountPicker({ value, onChange }: { value: string; onChange: (id: string) => void }) {
  const { accounts } = useAccounts();
  const options = useMemo<AccountOption[]>(
    () => accounts.map((a) => ({ id: a.id, label: a.label, note: null })).sort((a, b) => a.id.localeCompare(b.id)),
    [accounts]
  );
  return <AccountTypeahead value={value} onChange={onChange} options={options} />;
}
