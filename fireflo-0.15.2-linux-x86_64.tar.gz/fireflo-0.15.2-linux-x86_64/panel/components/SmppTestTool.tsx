"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Download, Loader2, Zap } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClasses } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Segmented } from "@/components/ui/segmented";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { TlvPairsEditor } from "./TlvPairsEditor";
import { useCredentials } from "./useCredentials";
import { useHealth } from "./useHealth";
import { useTlvDefinitions } from "./useTlvDefinitions";
import { useWorkers } from "./useWorkers";
import { listenerPorts } from "@/lib/listener-ports";
import { autoEncoding, countSms, type SmsEncoding } from "@/lib/sms-text";
import type { BindKind, SmppSubmitResult, SmppTestEvent, SmppTestState } from "@/lib/smpp-test-types";
import { KIND } from "@/lib/worker-types";
import { formatClock } from "@/lib/datetime";
import { useDisplayZone } from "@/components/DisplayZoneProvider";

const POLL_MS = 1_000;
const OTHER = "other";

/**
 * The SMPP client test tool: bind as one of this account's logins -- or any credentials typed in --
 * to a gateway listener or another host, send submit_sm with the text, flags and TLVs you choose,
 * and read every PDU that goes either way.
 *
 * <p>The SMPP session itself is held by the panel's server (lib/smpp-test.ts); a browser cannot open
 * one. <strong>Closing the window unbinds and disconnects it</strong>, and so does leaving the page.
 */
export function SmppTestTool({ accountId }: { accountId: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button variant="outline" size="sm" onClick={() => setOpen(true)}>
        <Zap className="size-3.5" aria-hidden />
        SMPP client test
      </Button>
      {open && <SmppTestDialog accountId={accountId} onClose={() => setOpen(false)} />}
    </>
  );
}

function SmppTestDialog({ accountId, onClose }: { accountId: string; onClose: () => void }) {
  const { zone } = useDisplayZone();
  const base = `/api/control/accounts/${encodeURIComponent(accountId)}/smpp-test`;
  const { credentials } = useCredentials();
  const { workers } = useWorkers(KIND.server);
  const { byFullName } = useHealth();
  const { definitions, suggested } = useTlvDefinitions();
  const ports = useMemo(() => listenerPorts(workers, byFullName), [workers, byFullName]);
  const logins = useMemo(
    () => credentials.filter((c) => c.type === "SMPP" && c.billingAccount === accountId),
    [credentials, accountId]
  );

  //bind form
  const [mode, setMode] = useState<"existing" | "manual">("existing");
  const [credentialId, setCredentialId] = useState("");
  const [systemId, setSystemId] = useState("");
  const [password, setPassword] = useState("");
  const [systemType, setSystemType] = useState("");
  const [addrTon, setAddrTon] = useState("0");
  const [addrNpi, setAddrNpi] = useState("0");
  const [addressRange, setAddressRange] = useState("");
  const [version, setVersion] = useState("52");
  const [server, setServer] = useState("");
  const [otherHost, setOtherHost] = useState("");
  const [bindType, setBindType] = useState<BindKind>("trx");

  //session
  const [state, setState] = useState<Omit<SmppTestState, "events"> | null>(null);
  const [events, setEvents] = useState<SmppTestEvent[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const sidRef = useRef<string | null>(null);
  const nextRef = useRef(0);

  //send form
  const [source, setSource] = useState("FireFlo");
  const [dest, setDest] = useState("");
  const [text, setText] = useState("");
  const [encoding, setEncoding] = useState<SmsEncoding | "auto">("auto");
  const [registeredDelivery, setRegisteredDelivery] = useState("1");
  const [tlvs, setTlvs] = useState<{ key: string; value: string }[]>([]);
  const [lastResult, setLastResult] = useState<SmppSubmitResult | null>(null);

  //first login and first listener, once they arrive
  const chosenLogin = credentialId || (logins[0] ? String(logins[0].id) : "");
  const chosenServer = server || (ports[0] ? String(ports[0].port) : OTHER);
  const bound = state?.bound ?? false;

  const used = encoding === "auto" ? autoEncoding(text) : encoding;
  const count = countSms(text, used);

  const take = useCallback((s: SmppTestState) => {
    const { events: fresh, ...rest } = s;
    setState(rest);
    nextRef.current = s.next;
    if (fresh.length) {
      setEvents((prev) => prev.concat(fresh).slice(-2_000));
    }
  }, []);

  //the poll: while a session exists, once a second
  useEffect(() => {
    if (!state?.id) {
      return;
    }
    let stopped = false;
    const tick = async () => {
      if (stopped || document.visibilityState === "hidden") {
        return;
      }
      const res = await fetch(`${base}/${state.id}?after=${nextRef.current}`, { cache: "no-store" }).catch(() => null);
      const json = await res?.json().catch(() => null);
      if (!stopped && res?.ok && json?.data) {
        take(json.data as SmppTestState);
      }
    };
    const timer = setInterval(() => void tick(), POLL_MS);
    return () => {
      stopped = true;
      clearInterval(timer);
    };
  }, [state?.id, base, take]);

  //closing the window, leaving the page, or this component going away all unbind and disconnect
  useEffect(() => {
    const beacon = () => {
      if (sidRef.current) {
        navigator.sendBeacon(`${base}/${sidRef.current}`);
        sidRef.current = null;
      }
    };
    window.addEventListener("pagehide", beacon);
    return () => {
      window.removeEventListener("pagehide", beacon);
      if (sidRef.current) {
        void fetch(`${base}/${sidRef.current}`, { method: "DELETE", keepalive: true }).catch(() => undefined);
        sidRef.current = null;
      }
    };
  }, [base]);

  //follow the newest line
  const logRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = logRef.current;
    if (el) {
      el.scrollTop = el.scrollHeight;
    }
  }, [events]);

  async function bind() {
    setBusy(true);
    setError(null);
    try {
      const body: Record<string, unknown> = {
        bindType,
        systemType,
        addrTon,
        addrNpi,
        addressRange,
        interfaceVersion: version,
      };
      if (mode === "existing") {
        body.credentialId = chosenLogin;
      } else {
        body.systemId = systemId;
        body.password = password;
      }
      if (chosenServer === OTHER) {
        const m = /^(.*):(\d+)$/.exec(otherHost.trim());
        if (!m) {
          setError("Enter the other server as host:port, for example smsc.example.com:2775.");
          return;
        }
        body.host = m[1].replace(/^\[(.*)\]$/, "$1");
        body.port = m[2];
      } else {
        body.port = chosenServer;
      }
      //a fresh session's log, not the last one's
      setEvents([]);
      nextRef.current = 0;
      setLastResult(null);
      const res = await fetch(base, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? "The bind could not be started.");
        return;
      }
      const result = json.data as { id: string; bound: boolean; reason: string | null };
      sidRef.current = result.bound ? result.id : null;
      if (!result.bound) {
        setError(`Bind refused: ${result.reason}. The form is kept, so you can correct it and bind again.`);
      }
      //read the session once now, rather than wait a poll, so the log fills at once
      const first = await fetch(`${base}/${result.id}?after=0`, { cache: "no-store" });
      const firstJson = await first.json().catch(() => null);
      if (first.ok && firstJson?.data) {
        take(firstJson.data as SmppTestState);
      }
    } catch {
      setError("Could not reach the panel.");
    } finally {
      setBusy(false);
    }
  }

  async function send() {
    if (!state) {
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`${base}/${state.id}/submit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ source, dest, text, encoding, registeredDelivery, tlvs }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? "The message was not sent.");
        return;
      }
      setLastResult(json.data as SmppSubmitResult);
    } catch {
      setError("Could not reach the panel.");
    } finally {
      setBusy(false);
    }
  }

  async function unbind() {
    if (!state) {
      return;
    }
    setBusy(true);
    await fetch(`${base}/${state.id}?keep=1`, { method: "DELETE" }).catch(() => undefined);
    sidRef.current = null;
    setBusy(false);
  }

  const lines = events.length;

  return (
    <Dialog open onClose={onClose} title="SMPP client test" className="max-w-5xl">
      <div className="flex max-h-[calc(100dvh-10.25rem)] min-h-0 flex-col gap-3">
        <p className="rounded-md bg-warning-soft px-3 py-2 text-xs text-warning">
          Messages sent here are real: they are routed, delivered and billed to this account. Closing this
          window unbinds and disconnects.
        </p>

        <div className="grid min-h-0 flex-1 gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
          <div className="min-h-0 space-y-4 overflow-y-auto pr-1">
            {/* 1 · Bind */}
            <section className="space-y-3 rounded-lg border border-border p-3">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-semibold">1 · Bind</h3>
                <Badge variant={bound ? "success" : "outline"} className="ml-auto">
                  {bound ? `Bound · ${state!.bindType.toUpperCase()}` : state ? "Not bound" : "Not bound yet"}
                </Badge>
              </div>
              {bound ? (
                <p className="text-xs text-muted-foreground">
                  Bound as <span className="font-mono text-foreground">{state!.systemId}</span> to{" "}
                  <span className="font-mono">{state!.host}:{state!.port}</span>.
                </p>
              ) : (
                <>
                  <Segmented
                    label="Credentials"
                    options={[
                      { value: "existing", label: "Existing login" },
                      { value: "manual", label: "Enter details" },
                    ]}
                    value={mode}
                    onChange={setMode}
                  />
                  {mode === "existing" ? (
                    <div className="grid gap-3 sm:grid-cols-2">
                      <Field label="Login" htmlFor="st-login"
                        hint={logins.length ? "Its stored password is used on the server, never shown here." : "This account has no SMPP login. Enter details instead."}>
                        <Select id="st-login" value={chosenLogin} onChange={(e) => setCredentialId(e.target.value)} disabled={!logins.length}>
                          {logins.map((c) => (
                            <option key={c.id} value={c.id}>{c.systemId}{c.enabled ? "" : " (disabled)"}</option>
                          ))}
                        </Select>
                      </Field>
                      <Field label="System type" htmlFor="st-stype" hint="Empty uses the login's product.">
                        <Input id="st-stype" value={systemType} onChange={(e) => setSystemType(e.target.value)} />
                      </Field>
                    </div>
                  ) : (
                    <div className="grid gap-3 sm:grid-cols-3">
                      <Field label="System ID" htmlFor="st-sid">
                        <Input id="st-sid" className="font-mono" value={systemId} onChange={(e) => setSystemId(e.target.value)} autoComplete="off" />
                      </Field>
                      <Field label="Password" htmlFor="st-pw">
                        <Input id="st-pw" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" />
                      </Field>
                      <Field label="System type" htmlFor="st-stype2">
                        <Input id="st-stype2" value={systemType} onChange={(e) => setSystemType(e.target.value)} placeholder="optional" />
                      </Field>
                    </div>
                  )}
                  <details className="text-sm">
                    <summary className="cursor-pointer text-xs text-muted-foreground">More bind fields</summary>
                    <div className="mt-2 grid gap-3 sm:grid-cols-4">
                      <Field label="addr_ton" htmlFor="st-ton"><Input id="st-ton" value={addrTon} onChange={(e) => setAddrTon(e.target.value)} inputMode="numeric" /></Field>
                      <Field label="addr_npi" htmlFor="st-npi"><Input id="st-npi" value={addrNpi} onChange={(e) => setAddrNpi(e.target.value)} inputMode="numeric" /></Field>
                      <Field label="address_range" htmlFor="st-range"><Input id="st-range" value={addressRange} onChange={(e) => setAddressRange(e.target.value)} /></Field>
                      <Field label="Interface" htmlFor="st-ver">
                        <Select id="st-ver" value={version} onChange={(e) => setVersion(e.target.value)}>
                          <option value="52">3.4</option>
                          <option value="51">3.3</option>
                        </Select>
                      </Field>
                    </div>
                  </details>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <Field label="Server" htmlFor="st-server">
                      <Select id="st-server" value={chosenServer} onChange={(e) => setServer(e.target.value)}>
                        {ports.map((p) => (
                          <option key={p.port} value={p.port}>{p.label} · port {p.port}</option>
                        ))}
                        <option value={OTHER}>Other host:port…</option>
                      </Select>
                      {chosenServer === OTHER && (
                        <Input className="mt-2 font-mono" value={otherHost} onChange={(e) => setOtherHost(e.target.value)}
                          placeholder="smsc.example.com:2775" aria-label="Other host and port" />
                      )}
                    </Field>
                    <Field label="Bind type" htmlFor="st-bind">
                      <Segmented
                        label="Bind type"
                        options={[
                          { value: "trx", label: "TRX" },
                          { value: "tx", label: "TX" },
                          { value: "rx", label: "RX" },
                        ]}
                        value={bindType}
                        onChange={setBindType}
                      />
                    </Field>
                  </div>
                  <Button size="sm" disabled={busy || (mode === "existing" ? !chosenLogin : !systemId.trim())} onClick={() => void bind()}>
                    {busy && <Loader2 className="size-3.5 animate-spin" aria-hidden />}
                    Bind
                  </Button>
                </>
              )}
            </section>

            {/* 2 · Send */}
            {/* inert until bound, so the form is out of the tab order as well as greyed */}
            <section className={`space-y-3 rounded-lg border border-border p-3 ${bound && state!.bindType !== "rx" ? "" : "opacity-50"}`}
              inert={!(bound && state!.bindType !== "rx")}>
              <h3 className="text-sm font-semibold">2 · Send submit_sm</h3>
              {bound && state!.bindType === "rx" && (
                <p className="text-xs text-muted-foreground">A receiver bind cannot send. Bind as TRX or TX.</p>
              )}
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Sender ID" htmlFor="st-src">
                  <Input id="st-src" className="font-mono" value={source} onChange={(e) => setSource(e.target.value)} />
                </Field>
                <Field label="Destination" htmlFor="st-dst">
                  <Input id="st-dst" className="font-mono" value={dest} onChange={(e) => setDest(e.target.value)} placeholder="61400200011" />
                </Field>
              </div>
              <Field label="Text" htmlFor="st-text">
                <Textarea
                  id="st-text"
                  rows={3}
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                />
                {/* the same counting the server encodes with, so this is what goes out */}
                <div className="mt-1 flex justify-between text-xs text-muted-foreground">
                  <span>{used === "gsm7" ? "GSM-7" : used === "ucs2" ? "UCS-2" : "ASCII"}{encoding === "auto" && used === "ucs2" && text ? " (a character outside GSM-7)" : ""}</span>
                  <span>
                    <span className="font-medium text-foreground tabular-nums">{count.units}</span>
                    {" / "}{count.parts > 1 ? count.perPart * count.parts : count.perPart}
                    {" · "}{count.parts === 1 ? "1 part" : `${count.parts} parts${count.parts > 1 ? " (sent as message_payload)" : ""}`}
                  </span>
                </div>
              </Field>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Registered delivery" htmlFor="st-rd">
                  <Select id="st-rd" value={registeredDelivery} onChange={(e) => setRegisteredDelivery(e.target.value)}>
                    <option value="1">1 · receipt on success and failure</option>
                    <option value="0">0 · no receipt</option>
                    <option value="2">2 · receipt on failure only</option>
                  </Select>
                </Field>
                <Field label="Data coding" htmlFor="st-dc">
                  <Select id="st-dc" value={encoding} onChange={(e) => setEncoding(e.target.value as SmsEncoding | "auto")}>
                    <option value="auto">Auto (GSM-7 or UCS-2)</option>
                    <option value="gsm7">0 · GSM-7</option>
                    <option value="ucs2">8 · UCS-2</option>
                    <option value="ascii">1 · ASCII</option>
                  </Select>
                </Field>
              </div>
              <Field label="TLV attributes" htmlFor="st-tlv">
                <TlvPairsEditor
                  pairs={tlvs}
                  onChange={setTlvs}
                  definitions={definitions}
                  suggested={suggested}
                  addLabel="Add a TLV"
                  valuePlaceholder="text, or hex:…"
                />
              </Field>
              <div className="flex flex-wrap items-center gap-2">
                <Button size="sm" disabled={busy || !bound || !dest.trim()} onClick={() => void send()}>
                  {busy && <Loader2 className="size-3.5 animate-spin" aria-hidden />}
                  Send
                </Button>
                {lastResult && (
                  <span className={`text-xs ${lastResult.status === 0 ? "text-muted-foreground" : "text-destructive"}`}>
                    Last: <span className="font-medium">{lastResult.status === 0 ? "OK" : lastResult.statusText}</span>
                    {lastResult.messageId && <> · message_id <span className="font-mono">{lastResult.messageId}</span></>}
                  </span>
                )}
              </div>
            </section>
            {error && <p className="text-sm text-destructive">{error}</p>}
          </div>

          {/* Log */}
          <section className="flex min-h-64 flex-col gap-2 rounded-lg border border-border p-3">
            <h3 className="text-sm font-semibold">Log <span className="text-xs font-normal text-muted-foreground">every PDU in and out, live</span></h3>
            <div ref={logRef} role="log" aria-live="polite"
              className="min-h-0 flex-1 overflow-auto rounded bg-muted p-2 font-mono text-sm">
              {lines === 0 ? (
                <p className="text-muted-foreground">Not bound yet. Choose a login and a server, then Bind.</p>
              ) : (
                events.map((e) => (
                  <div key={e.seq} className={`whitespace-pre-wrap break-all ${
                    e.tone === "error" ? "text-destructive" : e.tone === "receipt" || e.tone === "ok" ? "text-success" : e.tone === "mo" ? "text-info" : e.dir === "note" ? "text-warning" : ""}`}>
                    {formatClock(e.at, zone)}  {e.text}
                  </div>
                ))
              )}
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {state && (
                <a className={buttonClasses({ variant: "outline", size: "sm" })} href={`${base}/${state.id}/log`} download>
                  <Download className="size-3.5" aria-hidden />
                  Download log
                </a>
              )}
              {bound && (
                <Button size="sm" variant="outline" disabled={busy} onClick={() => void unbind()}>Unbind</Button>
              )}
              <span className="ml-auto text-xs text-muted-foreground">{lines ? `${lines} lines` : ""}</span>
            </div>
          </section>
        </div>
      </div>
    </Dialog>
  );
}
