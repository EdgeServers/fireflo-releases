"use client";
import { StatTile } from "@/components/ui/stat-tile";
import { type HealthWorker, type TpsPeak } from "@/lib/health-types";
import { needsAttention, verdictFor } from "@/lib/worker-verdict";
import { KIND, isOn, trafficKey, type Worker, type WorkerType } from "@/lib/worker-types";
import { PeakLine } from "./PeakLine";
import { formatTps } from "@/lib/tps-format";
import { localeNumber } from "@/lib/format";

/**
 * The four figures that answer "is anything wrong here" without scrolling.
 *
 * <p>Neither of these pages had a summary of any kind: the only way to learn that one vendor of six
 * had stopped carrying traffic was to scroll until a red badge appeared. The cards are still the
 * detail — this is the sentence above them.
 *
 * <p>Totalled across the page's own instances rather than read from a gateway-wide figure, so what
 * it says always matches the cards underneath it. `/cp/health` answers the gateway-wide question and
 * a second, subtly different total on this page would only invite the two to be compared.
 */
export function WorkerSummary({ workers, byFullName, type, loading, error, peak, onPeakReset }: {
  workers: Worker[];
  byFullName: Map<string, HealthWorker>;
  type: WorkerType;
  loading?: boolean;
  error?: string;
  /** The gateway's peak for this kind together -- `tps_peaks.vendors` or `.servers`. */
  peak?: TpsPeak | null;
  onPeakReset?: () => void;
}) {
  const isVendor = type === KIND.vendor;
  if (!workers.length) {
    return null;
  }

  const live = workers.map((w) => byFullName.get(trafficKey(w)));
  const down = workers.filter((w) => needsAttention(verdictFor(w, byFullName, type))).length;
  const held = workers.some((w) => isOn(w, "pause") || isOn(w, "suspend"));

  const bound = sum(live.map((l) => l?.bound));
  const queued = sum(live.map((l) => l?.queue_depth)) + sum(live.map((l) => l?.retry_queue_depth));
  const measured = sum(live.map((l) => l?.tps_measured));
  const ceiling = sum(live.map((l) => l?.tps_limit));

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <StatTile
        label={isVendor ? "Vendors" : "Servers"}
        value={String(workers.length)}
        hint={down ? `${down} needing attention` : "All healthy"}
        loading={loading}
        error={error}
        tone={down ? "negative" : "default"}
      />
      <StatTile
        label={isVendor ? "Bound" : "Bound customers"}
        value={localeNumber(bound)}
        //a vendor with nothing bound cannot send at all; a listener with nobody bound is just quiet,
        //and painting that red sends somebody chasing a fault that does not exist
        hint={isVendor ? "Sessions carrying traffic out" : "Customers connected right now"}
        loading={loading}
        error={error}
        tone={isVendor && bound === 0 ? "negative" : "default"}
      />
      <StatTile
        label="Queued"
        value={localeNumber(queued)}
        hint={held ? "Something is held, so this only grows" : "Waiting to go out, including retries"}
        loading={loading}
        error={error}
        tone={queued > 0 && held ? "negative" : "default"}
      />
      <StatTile
        label="Throughput"
        //the ceiling travels with the measurement, because a bare rate cannot say whether it is
        //healthy: 180/sec is either comfortable or pinned, depending entirely on the limit
        value={ceiling ? `${formatTps(measured)} of ${localeNumber(ceiling)}` : formatTps(measured)}
        hint={measured === 0 && queued > 0 ? "Messages waiting and nothing moving" : "Messages per second"}
        loading={loading}
        error={error}
        tone={measured === 0 && queued > 0 ? "negative" : "default"}
        footnote={<PeakLine peak={peak} scope={isVendor ? "all:vendors" : "all:servers"} onReset={onPeakReset} />}
      />
    </div>
  );
}

/** Null and undefined contribute nothing, rather than turning the whole total into NaN. */
function sum(values: (number | null | undefined)[]): number {
  return values.reduce<number>((total, v) => total + (v ?? 0), 0);
}
