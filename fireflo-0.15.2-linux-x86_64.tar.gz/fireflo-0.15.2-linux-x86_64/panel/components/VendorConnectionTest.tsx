"use client";
import { useEffect, useState } from "react";
import { PlugZap, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { CardActions } from "./CardBits";
import { formatTimestamp } from "@/lib/datetime";
import { useDisplayZone } from "@/components/DisplayZoneProvider";

/** What the gateway's test-bind answers. `log` is absent from a gateway older than 0.12.1. */
export interface ConnectionTestResult {
  worker: string;
  tested: boolean;
  bound: boolean;
  detail: string;
  tested_at?: string;
  log?: string[];
}

/**
 * A live connection test against a vendor's uplink, and its log.
 *
 * <p>The gateway does the dialling: name lookup, TCP connect, a real bind with the vendor's own
 * credentials, three enquire_link round trips, unbind -- each step timed. When the vendor is
 * already bound it does not bind a second time (on an SMSC that drops the oldest session, that
 * would cost the live one); it checks the host and port and times an enquire_link on every live
 * session instead, which is the same question asked of the connection that is carrying traffic.
 *
 * <p>Split in two -- the hook and the log -- because the button belongs in the card's footer with
 * the vendor's other actions, while the log needs the page's width.
 */
export function useConnectionTest(name: string) {
  const [result, setResult] = useState<ConnectionTestResult | null>(null);
  const [error, setError] = useState("");
  const [running, setRunning] = useState(false);
  const [startedAt, setStartedAt] = useState<number | null>(null);

  async function run() {
    setRunning(true);
    setStartedAt(Date.now());
    setResult(null);
    setError("");
    try {
      const res = await fetch(`/api/control/workers/${encodeURIComponent(name)}/test-bind`, { method: "POST" });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
      } else {
        setResult(json.data as ConnectionTestResult);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setRunning(false);
    }
  }

  function clear() {
    setResult(null);
    setError("");
  }

  return { run, running, startedAt, result, error, clear, open: running || !!result || !!error };
}

export function ConnectionTestButton({ running, onRun }: { running: boolean; onRun: () => void }) {
  return (
    <Button variant="outline" size="sm" disabled={running} onClick={onRun}>
      <PlugZap className="h-3.5 w-3.5" />
      {running ? "Testing…" : "Test connection"}
    </Button>
  );
}

export function ConnectionTestLog({
  name,
  running,
  startedAt,
  result,
  error,
  onRun,
  onClose,
}: {
  name: string;
  running: boolean;
  startedAt: number | null;
  result: ConnectionTestResult | null;
  error: string;
  onRun: () => void;
  onClose: () => void;
}) {
  const { zone } = useDisplayZone();
  const elapsed = useElapsed(running, startedAt);
  //`tested: false` with `bound: true` is the probe of a live connection, which is a pass, not a
  //refusal; `tested: false` alone means nothing was dialled, which is neither pass nor fail
  const verdict = running ? { tone: "outline" as const, label: "Running" }
    : error ? { tone: "destructive" as const, label: "Could not run" }
      : !result ? null
        : result.bound ? { tone: "success" as const, label: result.tested ? "Bound" : "Live sessions answered" }
          : result.tested ? { tone: "destructive" as const, label: "Failed" }
            : { tone: "outline" as const, label: "Not tested" };
  const lines = result?.log ?? [];

  return (
    <Card>
      <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
        <span className="text-sm font-medium">Connection test</span>
        <span className="font-mono text-xs text-muted-foreground">{name}</span>
        {verdict && <Badge variant={verdict.tone}>{verdict.label}</Badge>}
        {result?.tested_at && <span className="text-xs text-muted-foreground">{formatTimestamp(result.tested_at, zone)}</span>}
        <CardActions>
          <ConnectionTestButton running={running} onRun={onRun} />
          <Button variant="ghost" size="sm" aria-label="Close the connection test" disabled={running} onClick={onClose}>
            <X className="h-3.5 w-3.5" />
          </Button>
        </CardActions>
      </CardHeader>
      <CardContent className="space-y-2 pt-3">
        {result && <p className="text-sm">{result.detail}</p>}
        {error && <p className="text-sm text-destructive">{error}</p>}
        <pre
          className="max-h-80 min-h-24 overflow-auto rounded-md border border-border bg-muted/40 p-3 font-mono text-sm"
          aria-live="polite"
        >
          {running && (
            <span className="text-muted-foreground">
              Dialling {name} from the gateway… {elapsed}s{"\n"}
              The gateway allows 5 s to connect, 10 s to bind and 3 s per enquire_link.
            </span>
          )}
          {!running && lines.map((line, i) => (
            <span key={i} className={lineTone(line)}>{line}{"\n"}</span>
          ))}
          {!running && result && !lines.length && (
            <span className="text-muted-foreground">This gateway reports the outcome only; it predates the step log.</span>
          )}
        </pre>
      </CardContent>
    </Card>
  );
}

function lineTone(line: string): string | undefined {
  if (/failed|no answer|did not complete|refused|not running/i.test(line)) return "text-destructive";
  if (/\b(bound in|answered in|tcp connect to .* in)\b/i.test(line)) return "text-success";
  return undefined;
}

/** Whole seconds since the test started, ticking while it runs. */
function useElapsed(running: boolean, startedAt: number | null): number {
  const [now, setNow] = useState(0);
  useEffect(() => {
    if (!running) return;
    const timer = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(timer);
  }, [running]);
  return startedAt == null ? 0 : Math.max(0, Math.floor((now - startedAt) / 1000));
}
