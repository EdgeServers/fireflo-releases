"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowUp, ArrowDown, Columns3, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { SettingsRow } from "@/components/ui/settings-row";
import { Select } from "@/components/ui/select";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { AccountTableCell } from "./AccountTableCell";
import { ColumnChooser } from "./ColumnChooser";
import { CredentialForm } from "./CredentialForm";
import { Dialog } from "@/components/ui/dialog";
import { useCredentials } from "./useCredentials";
import type { Credential } from "@/lib/credential-types";
import { ErrorCard } from "./FormNotices";
import { useConfirmChange } from "./ConfirmProvider";
import { StatTile } from "@/components/ui/stat-tile";
import { useAccounts } from "./useAccounts";
import { accountHref, surface } from "@/lib/panel-surface";
import {
  ACCOUNT_COLUMNS,
  ACCOUNT_COLUMN_GROUPS,
  RESELLER_ACCOUNT_COLUMNS,
  ACCOUNT_COLUMN_STORAGE_KEY,
  ACCOUNT_PAGE_SIZES,
  DEFAULT_ACCOUNT_PAGE_SIZE,
  buildLoginRows,
  isUnlistableLogin,
  matchesAccountQuery,
  resolveAccountColumnsFor,
  rowKey,
} from "@/lib/account-columns";
import {
  type ColumnChoice,
  nextSort,
  readColumnChoice,
  setPageSize,
  sortRows,
  toggleColumn,
} from "@/lib/table-columns";
import { localeNumber } from "@/lib/format";
import { useDisplayZone } from "@/components/DisplayZoneProvider";

/**
 * Every billing account this deployment knows, named or not, one row per login that bills to it.
 *
 * <p>The index that makes an account reachable without already knowing its id — which is what a
 * thousand customers needs and what a deep link alone cannot give.
 *
 * <p><strong>Orphans sit alongside the catalogue rather than beneath it.</strong> There is no
 * foreign key from a login, a rate scope or a balance to `app_account`, so an id can be doing real
 * work with nobody having named it. A list showing only named rows would report a customer base
 * smaller than the one that is billing.
 *
 * <p><strong>Paging, sorting and filtering all happen here, in the browser.</strong> Unlike `/cdrs`,
 * which pages a live unbounded table with a keyset cursor and therefore cannot offer a total or a
 * sort, this list arrives whole — so it can say exactly how many rows there are, which page of how
 * many you are on, and sort by any column. Adopting the cursor here would be work spent to lose
 * those.
 */
export function AccountsCatalogueClient() {
  const { short } = useDisplayZone();
  const router = useRouter();
  //no `save` here any more: creating goes through POST directly, and editing lives on the
  //Settings tab. Destructuring it would leave the update verb one autocomplete away from the
  //create form, which is how the two came to be confused in the first place
  const { accounts, orphans, archived, error, loading } = useAccounts();
  //archived accounts (V1.100.0) are out of the everyday list; this shows them instead of it
  const [showArchived, setShowArchived] = useState(false);
  //the same hook the account page uses. It carries `billingAccount`, resolved server-side through
  //billingOf, which is exactly the key these rows group on -- and it hands the dialog the whole
  //credential, so opening one costs no second request
  const { credentials, context, save: saveLogin, error: loginError } = useCredentials();
  const [openLogin, setOpenLogin] = useState<Credential | null>(null);
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(0);
  const [newId, setNewId] = useState("");
  const confirm = useConfirmChange();
  //the reseller create form only. The operator's card opens an id and creates nothing, so it needs
  //neither of these -- see the two cards at the foot of this file
  const [newLabel, setNewLabel] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [createError, setCreateError] = useState("");
  const [creating, setCreating] = useState(false);
  const [choice, setChoice] = useState<ColumnChoice | null>(null);
  const [chooserOpen, setChooserOpen] = useState(false);

  //read after mount, never in a lazy initialiser: localStorage does not exist while the page is
  //rendered on the server, and React 19 throws on the resulting mismatch rather than patching it up
  useEffect(() => {
    setChoice(readColumnChoice(window.localStorage.getItem(ACCOUNT_COLUMN_STORAGE_KEY)));
  }, []);

  function store(next: ColumnChoice) {
    setChoice(next);
    window.localStorage.setItem(ACCOUNT_COLUMN_STORAGE_KEY, JSON.stringify(next));
  }

  function resetColumns() {
    setChoice(null);
    window.localStorage.removeItem(ACCOUNT_COLUMN_STORAGE_KEY);
    setPage(0);
  }

  //what this surface may show about what an account is charged -- see lib/panel-surface.ts
  const { pricing } = surface();
  //the catalogue the CHOOSER offers and the choice is resolved against must be the same one, or a
  //stored choice naming a pricing column brings it back on a surface that filtered it out
  const catalogue = pricing ? ACCOUNT_COLUMNS : RESELLER_ACCOUNT_COLUMNS;
  /**
   * An account this reseller already holds under the id being typed.
   *
   * <p>A courtesy, not the rule — the route refuses it either way, and has to, because this list is
   * a snapshot and another tab may have created one since. What it buys is that the reader learns
   * it before pressing Create rather than after, and learns *which* account it is.
   *
   * <p>Case-insensitive, matching `childIdProblem`: two accounts differing only in case would be a
   * support call every time, and the id is read aloud more often than it is typed.
   */
  const alreadyHeld = newId.trim()
    ? accounts.find((a) => a.id.toLowerCase() === newId.trim().toLowerCase()) ?? null
    : null;
  const columns = resolveAccountColumnsFor(choice, pricing);
  const pageSize = choice?.pageSize ?? DEFAULT_ACCOUNT_PAGE_SIZE;
  const sort = choice?.sort;

  const rows = useMemo(() => {
    const all = (showArchived ? buildLoginRows(archived, [], credentials) : buildLoginRows(accounts, orphans, credentials))
      .filter((r) => matchesAccountQuery(r, query));
    const by = sort ? catalogue.find((c) => c.id === sort.id) : undefined;
    return by
      ? sortRows(all, by, sort!.dir)
      //no sort chosen: id, then system id, so an account's logins stay together and in a stable order
      : all.sort((a, b) => a.id.localeCompare(b.id) || (a.systemId ?? "").localeCompare(b.systemId ?? ""));
  }, [accounts, orphans, archived, showArchived, credentials, query, sort]);

  const accountCount = useMemo(() => new Set(rows.map((r) => r.id)).size, [rows]);
  //HTTP logins keyed on their own api key. They belong to an account whose id is a secret, so they
  //cannot be listed -- but they can be counted, and a login that is simply absent is worse
  const unlistable = useMemo(() => credentials.filter(isUnlistableLogin).length, [credentials]);
  //the band above the table: what the catalogue holds and what logs in through it
  const stats = useMemo(() => ({
    resellers: accounts.filter((a) => a.resells).length,
    unlisted: accounts.filter((a) => !a.enabled).length,
    archived: archived.length,
    smpp: credentials.filter((c) => c.type === "SMPP").length,
    http: credentials.filter((c) => c.type === "HTTP").length,
    disabled: credentials.filter((c) => !c.enabled).length,
  }), [accounts, archived, credentials]);
  function openById(loginId: number) {
    setOpenLogin(credentials.find((c) => c.id === loginId) ?? null);
  }

  const pages = Math.max(1, Math.ceil(rows.length / pageSize));
  const clamped = Math.min(page, pages - 1);
  const shown = rows.slice(clamped * pageSize, (clamped + 1) * pageSize);

  return (
    <>
      <ErrorCard error={error || loginError} />

      {/* counts on the left, the way to an account by id on the right, both above the table they
          summarise. The counts come from what this page already loads -- no request of their own */}
      {/* stretched rather than start-aligned, so the counts and the id card stand the same height */}
      <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_24rem]">
        <div className="grid min-w-0 grid-cols-2 gap-4 lg:grid-cols-4">
          <StatTile
            label="Accounts"
            value={localeNumber(accounts.length)}
            hint={[
              stats.resellers ? `${stats.resellers} resell` : null,
              stats.unlisted ? `${stats.unlisted} disabled` : null,
              stats.archived ? `${stats.archived} archived` : null,
            ].filter(Boolean).join(" · ") || "in the catalogue"}
            loading={loading}
          />
          <StatTile
            label="Not named yet"
            value={localeNumber(orphans.length)}
            hint={orphans.length ? "ids in use with no name" : "all named"}
            loading={loading}
          />
          <StatTile
            label="Logins"
            value={localeNumber(credentials.length)}
            hint={`${stats.smpp} SMPP · ${stats.http} HTTP`}
            loading={loading}
          />
          <StatTile
            label="Disabled logins"
            value={localeNumber(stats.disabled)}
            hint={`of ${credentials.length}`}
            loading={loading}
            tone={stats.disabled > 0 ? "negative" : "default"}
          />
        </div>
        <div className="min-w-0">
        {/*
          Its own card, in the rail above the table. Search and this used to sit eight pixels apart in
          one row while having opposite outcomes -- one filters the list in place, the other navigates
          away -- and that adjacency was a real share of what made the page hard to read.

          An id box rather than a "New account" dialog because there is nothing to create: an account
          exists the moment a login names it or a message arrives under it. This opens its page, where
          the logins, the pricing and the approvals live and where a catalogue row can be added.
        */}
        {pricing ? (
        <Card className="h-full">
          <CardHeader bar>
            <CardTitle>Open an account by id</CardTitle>
          </CardHeader>
          {/* one form spanning content and footer, so Enter in the box still submits */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const id = newId.trim();
              if (id) {
                router.push(accountHref(id));
              }
            }}
          >
            {/* the box and its button on one row, so the card stands no taller than the counts beside it */}
            <CardContent className="flex items-center gap-2 pt-3">
              <Input
                value={newId}
                onChange={(e) => setNewId(e.target.value)}
                placeholder="acct-1002"
                aria-label="Open an account by id"
                className="h-8 min-w-0 flex-1 font-mono text-sm"
              />
              <Button type="submit" variant="outline" size="sm" disabled={!newId.trim()}>Open</Button>
            </CardContent>
          </form>
        </Card>
        ) : (
        /*
          The reseller's version, and it is a different act rather than a different label.

          The operator's card above opens an id and creates nothing, on the premise its own note
          states: an account exists the moment a login names it or a message arrives under it. That is
          true of the platform and false of a reseller's customer -- nothing outside this panel can
          mint one, and the page for an id with no row is refused by the layout gate, correctly,
          because an id that is not yet a child is not this reseller's to open.

          So this one writes the row first and then navigates. The id cannot be changed afterwards --
          it is what logins, prices and call records all point at -- which is why it is asked for here
          rather than left to be edited on the page that opens next.
        */
        <Card>
          <CardHeader bar>
            <CardTitle>Add a customer</CardTitle>
            <CardDescription>
              Creates the account under you. Give it a login next, and it can send.
            </CardDescription>
          </CardHeader>
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              const id = newId.trim();
              if (!id || alreadyHeld) {
                return;
              }
              if (!(await confirm({
                title: "Add this customer?",
                consequence: `Creates account ${id} under you. Its id cannot be changed afterwards -- logins, ` +
                  "prices and call records all point at it.",
                confirmLabel: `Create ${id}`,
                changes: [
                  { label: "id", to: id },
                  ...(newLabel.trim() ? [{ label: "name", to: newLabel.trim() }] : []),
                  ...(newEmail.trim() ? [{ label: "email", to: newEmail.trim() }] : []),
                ],
              }))) {
                return;
              }
              setCreateError("");
              setCreating(true);
              try {
                //POST, deliberately NOT `useAccounts.save`, which is PUT and means update.
                //
                //This form used the shared save, and the route behind it was an upsert that decided
                //create-versus-update by looking the id up -- so typing the id of a customer you
                //already held silently overwrote its name and email instead of refusing. The verbs
                //are split now, and this one cannot reach an update path at all
                const res = await fetch(`${surface().apiBase}/accounts/catalogue`, {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    id,
                    label: newLabel.trim() || null,
                    email: newEmail.trim() || null,
                    enabled: true,
                  }),
                });
                const json = await res.json().catch(() => null);
                if (!res.ok) {
                  setCreateError(json?.error ?? `Could not create the account (${res.status}).`);
                  return;
                }
                setNewId("");
                setNewLabel("");
                setNewEmail("");
                router.push(accountHref(id));
              } catch (err) {
                setCreateError(err instanceof Error ? err.message : "Could not create the account.");
              } finally {
                setCreating(false);
              }
            }}
          >
            <div className="-mt-4 divide-y divide-border border-b border-border">
              <SettingsRow label="Id" htmlFor="new-child-id" help="Permanent. Letters, digits, dots, dashes and underscores.">
                <Input
                  id="new-child-id"
                  value={newId}
                  onChange={(e) => setNewId(e.target.value)}
                  placeholder="acme-uk"
                  className="font-mono"
                />
              </SettingsRow>
              <SettingsRow label="Name" htmlFor="new-child-label" help="What you call them. Changeable.">
                <Input
                  id="new-child-label"
                  value={newLabel}
                  onChange={(e) => setNewLabel(e.target.value)}
                  placeholder="Acme Communications"
                />
              </SettingsRow>
              <SettingsRow label="Email" htmlFor="new-child-email" help="How they sign in here. Without it, they cannot.">
                <Input
                  id="new-child-email"
                  type="email"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  placeholder="ops@acme.com"
                />
              </SettingsRow>
            </div>
            <CardFooter bar>
              <span className="min-w-0 flex-1 text-xs text-destructive">
                {alreadyHeld ? (
                  <>
                    You already have an account called{" "}
                    <span className="font-mono">{alreadyHeld.id}</span>
                    {alreadyHeld.label ? ` (${alreadyHeld.label})` : ""}.{" "}
                    <Link href={accountHref(alreadyHeld.id)} className="underline">
                      Open it
                    </Link>{" "}
                    to change its details.
                  </>
                ) : (
                  createError
                )}
              </span>
              <Button type="submit" size="sm" disabled={!newId.trim() || creating || !!alreadyHeld}>
                {creating ? "Creating…" : "Create"}
              </Button>
            </CardFooter>
          </form>
        </Card>
        )}
        </div>
      </div>


      <Card>
        <CardHeader bar className="flex flex-row flex-wrap items-center gap-2 space-y-0">
          <div className="min-w-0 flex-1 space-y-1.5">
            <CardTitle>{showArchived ? "Archived accounts" : "All accounts"}</CardTitle>
            <CardDescription>
              A billing account is what pricing, prepaid credit and every call record are keyed on. It
              has no row of its own unless somebody names it here — until then it exists only as a
              string on a login or a rate rule. One row per login, so an account with three logins is
              three rows.
            </CardDescription>
          </div>
          <span className="ml-auto flex min-w-0 flex-wrap items-center gap-2 max-sm:ml-0 max-sm:basis-full">
            <span className="relative min-w-0 flex-1 sm:flex-none">
              <Search className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => { setQuery(e.target.value); setPage(0); }}
                placeholder="account, login or product"
                aria-label="Search accounts"
                className="h-8 w-full pl-7 text-sm sm:w-56"
              />
            </span>
            {pricing && (archived.length > 0 || showArchived) && (
              <Button variant={showArchived ? "default" : "outline"} size="sm" className="h-8"
                aria-pressed={showArchived}
                onClick={() => { setShowArchived((v) => !v); setPage(0); }}>
                {showArchived ? "Back to all accounts" : `Archived (${archived.length})`}
              </Button>
            )}
            <Button variant="outline" size="sm" className="h-8 gap-1.5"
              onClick={() => setChooserOpen((v) => !v)} aria-expanded={chooserOpen}>
              <Columns3 className="h-4 w-4" />
              Columns
            </Button>
          </span>
        </CardHeader>
        <CardContent className="space-y-3">
          {!rows.length ? (
            <p className="py-6 text-center text-sm text-muted-foreground">
              {loading ? "Loading…" : query.trim() ? `Nothing matches "${query.trim()}".`
                : showArchived ? "No archived accounts." : "No accounts yet."}
            </p>
          ) : (
            <TableInCard>
              <THead>
                <TR>
                  {columns.map((column) => {
                    const active = sort?.id === column.id;
                    return (
                      <TH
                        key={column.id}
                        align={column.align === "right" ? "right" : undefined}
                        aria-sort={active ? (sort!.dir === "asc" ? "ascending" : "descending") : "none"}
                      >
                        <button
                          type="button"
                          onClick={() => { store(nextSort(choice, column.id)); setPage(0); }}
                          className={`inline-flex items-center gap-1 hover:text-foreground ${
                            active ? "text-foreground" : ""}`}
                          title={column.id === "rules"
                            ? "Rules on the whole account, not this product alone"
                            : undefined}
                        >
                          {column.header}{column.format === "time" ? ` (${short})` : ""}
                          {active && (sort!.dir === "asc"
                            ? <ArrowUp className="h-3 w-3" aria-hidden="true" />
                            : <ArrowDown className="h-3 w-3" aria-hidden="true" />)}
                        </button>
                      </TH>
                    );
                  })}
                </TR>
              </THead>
              <TBody>
                {shown.map((r) => (
                  <TR key={rowKey(r)}>
                    {columns.map((column) => (
                      <TD
                        key={column.id}
                        num={column.align === "right"}
                        muted={column.align === "right"}
                      >
                        <AccountTableCell column={column} row={r} onOpenLogin={openById} />
                      </TD>
                    ))}
                  </TR>
                ))}
              </TBody>
            </TableInCard>
          )}

          {/* the footnote lives inside the card it qualifies, rather than floating below it */}
          <p className="text-sm text-muted-foreground">
            Naming an account changes nothing the gateway does; disabling or archiving one stops its logins. The
            name is for the people reading pricing, balances and call records.
          </p>

          {/* said rather than left as an unexplained absence: these logins exist and send, and a
              table that simply omits them looks complete when it is not */}
          {unlistable > 0 && (
            <p className="text-sm text-warning">
              {unlistable} HTTP login{unlistable === 1 ? "" : "s"} bill to their own API key, so the
              account they belong to is named by a secret and cannot be listed here. Give them an
              account id on the login to bring them into this table.
            </p>
          )}
        </CardContent>
        {!!rows.length && (
          <CardFooter bar className="text-sm text-muted-foreground">
            <span className="min-w-0">
              {/* rows and accounts counted apart: they differ the moment one account sends under
                  two products, and a single number would be read as a customer count */}
              {rows.length} row{rows.length === 1 ? "" : "s"} across {accountCount} account
              {accountCount === 1 ? "" : "s"} · page {clamped + 1} of {pages}
            </span>
            <span className="ml-auto flex flex-wrap items-center gap-2">
              <Select
                value={String(pageSize)}
                onChange={(e) => { store(setPageSize(choice, Number(e.target.value))); setPage(0); }}
                aria-label="Rows per page"
                className="h-7 w-28 text-sm"
              >
                {ACCOUNT_PAGE_SIZES.map((n) => (
                  <option key={n} value={n}>{n} per page</option>
                ))}
              </Select>
              <Button variant="outline" size="sm" className="h-7" disabled={clamped === 0}
                onClick={() => setPage(clamped - 1)}>Previous</Button>
              <Button variant="outline" size="sm" className="h-7" disabled={clamped >= pages - 1}
                onClick={() => setPage(clamped + 1)}>Next</Button>
            </span>
          </CardFooter>
        )}
      </Card>

      {chooserOpen && (
        <ColumnChooser
          columns={catalogue}
          groups={ACCOUNT_COLUMN_GROUPS}
          enabled={new Set(columns.map((c) => c.id))}
          onToggle={(id, on) => store(toggleColumn(choice, id, on))}
          onReset={resetColumns}
          note="Open and Name it are always shown — a row you cannot reach is not a row."
        />
      )}

      {/*
        The whole credential is already in hand, so this opens with no second request.

        `max-w-3xl` matches the same form opened from the account page. The Dialog default is
        `max-w-lg`, which is right for a confirmation and far too narrow for a four-section form whose
        rows are deliberately paired two-up -- at that width every pair collapses to one column and
        the layout reads as a different form depending on where you opened it from.
      */}
      {openLogin && (
        <Dialog
          open
          onClose={() => setOpenLogin(null)}
          title={openLogin.systemId ?? "Login"}
          description={openLogin.billingAccount ? `Billing to ${openLogin.billingAccount}.` : undefined}
          className="max-w-3xl"
        >
          <CredentialForm
            initial={openLogin}
            context={context}
            //product and allowed products are the price -- see CredentialForm
            allowPricing={pricing}
            onSave={async (input) => {
              const failure = await saveLogin(input);
              if (!failure) {
                setOpenLogin(null);
              }
              return failure;
            }}
            onCancel={() => setOpenLogin(null)}
          />
        </Dialog>
      )}

    </>
  );
}
