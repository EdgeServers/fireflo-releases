"use client";
import { useMemo } from "react";
import { CartesianGrid, Line, LineChart, ReferenceLine, XAxis, YAxis } from "recharts";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { clock, clockTick } from "./LiveTrafficChart";
import { loginOfKey, accountOfKey } from "@/lib/session-groups";
import { TOTAL_SERIES, type LivePoint, type LiveSplit } from "@/lib/live-sessions";
import { useDisplayZone } from "@/components/DisplayZoneProvider";

/** Lines drawn at most; the rest of the clients are in the table under the chart. */
export const MAX_LINES = 6;

/** The six chart hues, in the order the busiest series take them. */
const COLOURS = [1, 2, 3, 4, 5, 6].map((n) => `var(--color-chart-${n})`);

/** Joins series keys for memoising; a record separator, which no account or login carries. */
const SEP = "\u001e";

/**
 * Messages per second on one listener, one line per account, per login, or one for the total.
 *
 * <p>The plotting of {@link LiveTrafficChart} -- Recharts lines, the rate on the left axis, the
 * same grid, ticks and tooltip -- over a different source: the per-client rates the Status tab folds
 * from the sessions query (`lib/live-sessions.ts`), not health's per-worker counters. No receipt or
 * queue line: a receipt rate per client is not counted anywhere live, and a queue belongs to the
 * listener, not to any one client on it.
 *
 * <p>`ceiling` draws the dashed limit line. Only meaningful for one account -- every account on a
 * listener has its own ceiling -- so the Status tab passes one only when an account is picked.
 */
export function ListenerLiveChart({
  points,
  series,
  split,
  ceiling,
}: {
  points: LivePoint[];
  /** Series keys, busiest first; at most {@link MAX_LINES} are drawn. */
  series: string[];
  split: LiveSplit;
  ceiling?: number | null;
}) {
  const { zone } = useDisplayZone();
  //memoised on the keys, not the array: every poll hands over a new array of the same series, and
  //neither the config nor the re-keyed rows should be rebuilt for that alone
  const shownKey = series.slice(0, MAX_LINES).join(SEP);
  const shown = useMemo(() => (shownKey ? shownKey.split(SEP) : []), [shownKey]);
  const config = useMemo<ChartConfig>(
    () => Object.fromEntries(shown.map((key, i) => [`s${i}`, { label: labelOf(key, split), color: COLOURS[i] }])),
    [shown, split]
  );
  //Recharts reads a dataKey as a path, so a series named "a.b" -- a login with a dot in it -- would
  //be looked up as a nested field. The points are re-keyed to s0..s5 for the chart alone
  const data = useMemo(
    () => points.map((p) => {
      const row: Record<string, number | null> = { t: p.t };
      shown.forEach((key, i) => {
        row[`s${i}`] = p[key] == null ? null : Math.round((p[key] as number) * 10) / 10;
      });
      return row;
    }),
    [points, shown]
  );

  return (
    <div className="space-y-2">
      <ChartContainer config={config} className="h-56 w-full">
        <LineChart data={data} margin={{ top: 8, right: 4, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--color-border)" />
          <XAxis
            dataKey="t"
            type="number"
            scale="time"
            domain={["dataMin", "dataMax"]}
            tickLine={false}
            axisLine={false}
            tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
            tickFormatter={(t: number) => clockTick(t, zone)}
            minTickGap={40}
          />
          <YAxis
            tickLine={false}
            axisLine={false}
            tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
            width={40}
            allowDecimals={false}
            //the ceiling must be on the chart even while the client is far below it
            domain={[0, (max: number) => Math.max(max, ceiling ?? 0) * 1.1 || 1]}
          />
          <ChartTooltip labelFormatter={(t) => clock(Number(t), zone)} content={<ChartTooltipContent indicator="dot" />} />
          {ceiling != null && ceiling > 0 && (
            <ReferenceLine
              y={ceiling}
              stroke="var(--color-warning)"
              strokeWidth={1.5}
              strokeDasharray="6 4"
              ifOverflow="extendDomain"
              label={{ value: `ceiling ≤${ceiling}`, position: "insideTopRight", fontSize: 11, fill: "var(--color-warning)" }}
            />
          )}
          {shown.map((_, i) => (
            <Line
              key={i}
              dataKey={`s${i}`}
              name={String(config[`s${i}`]?.label ?? "")}
              stroke={COLOURS[i]}
              strokeWidth={2}
              dot={false}
              connectNulls={false}
              isAnimationActive={false}
            />
          ))}
        </LineChart>
      </ChartContainer>
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
        {shown.map((key, i) => (
          <span key={key} className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full" style={{ backgroundColor: COLOURS[i] }} aria-hidden />
            {labelOf(key, split)}
          </span>
        ))}
        {ceiling != null && ceiling > 0 && (
          <span className="flex items-center gap-1.5">
            <span className="w-4 border-t-2 border-dashed border-warning" aria-hidden />
            ceiling
          </span>
        )}
        {series.length > MAX_LINES && <span>{series.length - MAX_LINES} quieter not drawn</span>}
      </div>
    </div>
  );
}

function labelOf(key: string, split: LiveSplit): string {
  if (split === "total") {
    return key === TOTAL_SERIES ? "All clients" : key;
  }
  return split === "login" ? `${accountOfKey(key)} · ${loginOfKey(key)}` : key;
}
