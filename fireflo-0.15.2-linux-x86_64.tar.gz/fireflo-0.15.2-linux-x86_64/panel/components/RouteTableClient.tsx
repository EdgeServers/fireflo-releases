"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowDown, ArrowRight, ArrowUp, ChevronRight, Copy, Lock, Plus, Settings2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ApplyNowButton } from "./ApplyNowButton";
import { Button, buttonClasses } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { EmptyState } from "@/components/ui/empty-state";
import { SettingsRow, SettingsRows } from "@/components/ui/settings-row";
import { Input } from "@/components/ui/input";
import { Segmented } from "@/components/ui/segmented";
import { Switch } from "@/components/ui/switch";
import { HealthStrip } from "./CardBits";
import { useConfirmChange, useConfirmDelete } from "./ConfirmProvider";
import { ErrorNote } from "./FormNotices";
import { RouteRuleDialog } from "./RouteRuleDialog";
import { tableHref, useRoutingData } from "./RoutingShell";
import { SaveBar } from "./SaveBar";
import {
  describeRuleWhen,
  isSystemRule,
  moveRule,
  ruleChanged,
  tableChangeCount,
  targetKindLabel,
  targetOptions,
  unreachableRules,
  unreachedNote,
} from "@/lib/routing-guide";
import {
  DEFAULT_TABLE_NAME,
  TARGET_FUNCTION_MEANING,
  routeTableWarnings,
  validateRouteTable,
  type RouteRule,
  type RouteTable,
  type RouteTableInput,
  type TargetFunction,
} from "@/lib/routing-types";
import type { RuntimeSnapshot } from "@/lib/runtime-metrics";
import { cn } from "@/lib/utils";
import { prefillFrom } from "@/lib/tester";
import { lockedReceiptListener } from "@/lib/system-routes";
import { stagedSummary, type ChangeLine } from "@/lib/confirm-changes";
import { localeNumber } from "@/lib/format";

/** A rule's identity across a save: its id, or for one not yet saved, its place in the draft. */
const ruleKey = (rule: RouteRule, at: number) => (rule.id === null ? `new:${at}` : `id:${rule.id}`);
/** What a rule does, without where it sits. */
const rulePrint = (rule: RouteRule) => JSON.stringify([
  rule.target, rule.copied, rule.label, rule.enabled, rule.conditions, rule.filters,
]);

/**
 * One routing table: its rules as sentences, edited in a dialog and saved together.
 *
 * <h2>Staged, like Gateway and Error codes</h2>
 *
 * <p>Editing, adding, removing, reordering and switching a rule on or off all change a draft; the
 * Save bar writes the whole table through the same PUT the old form used, which keeps every rule's
 * id. Order is the priority in an In-order table, so a reorder is saved as one decision with the
 * edits around it rather than rule by rule, half-applied.
 *
 * <h2>System rules fold away</h2>
 *
 * <p>The rules default routing wrote -- receipts back to their listener, inbound to a listener, the
 * outbound content types into the business tables -- carry a `system:` note. They are folded into
 * one line so the rules an operator writes are what the table shows, and they stay editable when
 * opened. A move skips over the other kind, so reordering business rules never shuffles them.
 */

interface DraftRule {
  /** Stable across reorders, for React; stripped before save. */
  key: string;
  rule: RouteRule;
}

let nextKey = 0;
const wrap = (rule: RouteRule): DraftRule => ({ key: `r${nextKey++}`, rule });

/**
 * A rule's traffic counter, under the key `AbstractRoutingManager.recordRuleMatch` builds: the
 * rule's label, else `table:seq` with `seq` its 1-based place in the STORED table, since the
 * gateway counted it there. A rule not saved yet has no counter.
 */
function matchCount(metrics: RuntimeSnapshot | null, table: RouteTable, rule: RouteRule): number | null {
  if (!metrics || rule.id == null) return null;
  const at = table.rules.findIndex((r) => r.id === rule.id);
  if (at < 0) return null;
  const stored = table.rules[at];
  return metrics.routingRuleMatches[table.name]?.[stored.label ?? `${table.name}:${at + 1}`] ?? null;
}

/** What deleting a table costs, naming the tables that still send into it. */
function describeTableRemoval(table: RouteTable, tables: RouteTable[]): string {
  const into = [...new Set(tables
    .filter((t) => t.name !== table.name && t.rules.some((r) => r.target === table.name))
    .map((t) => t.name))];
  return `Its ${table.rules.length} rule(s) go with it.`
    + (into.length ? ` ${into.join(", ")} still send into it, so this will be refused until those rules point somewhere else.` : "");
}

export function RouteTableClient({ name }: { name: string }) {
  const data = useRoutingData();
  const confirm = useConfirmChange();
  const confirmDelete = useConfirmDelete();
  const router = useRouter();
  const stored = data.tables.find((t) => t.name === name);
  const [rules, setRules] = useState<DraftRule[]>([]);
  const [label, setLabel] = useState("");
  const [enabled, setEnabled] = useState(true);
  const [targetFunction, setTargetFunction] = useState<TargetFunction>("NORMAL");
  const [editing, setEditing] = useState<{ index: number | null; rule: RouteRule } | null>(null);
  const [settings, setSettings] = useState(false);
  const [showSystem, setShowSystem] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  //the moment people wait for the gateway: a save landed and the poll is up to 30 s away
  const [justSaved, setJustSaved] = useState(false);

  const storedKey = stored ? JSON.stringify(stored) : "";
  const reset = () => {
    if (!stored) return;
    setRules(stored.rules.map(wrap));
    setLabel(stored.label ?? "");
    setEnabled(stored.enabled);
    setTargetFunction(stored.targetFunction);
    setError("");
  };
  //adopt what the layout loaded, and again after a save reloads it or another table is opened
  useEffect(() => {
    //eslint-disable-next-line react-hooks/set-state-in-effect -- copying the layout's data into an editable draft
    reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [storedKey]);

  //the message tester's "Create routing rule": ?new=1, with one condition to open with. Once, then
  //the address is cleaned so a reload does not reopen it
  useEffect(() => {
    if (!stored) return;
    const params = new URLSearchParams(window.location.search);
    if (params.get("new") !== "1") return;
    const prefill = prefillFrom(params);
    //eslint-disable-next-line react-hooks/set-state-in-effect -- a one-shot hand-off from the link
    setEditing({
      index: null,
      rule: { id: null, target: "", copied: false, label: null, enabled: true, conditions: prefill ? [prefill] : [], filters: [] },
    });
    router.replace(`/cp/routing/tables/${encodeURIComponent(name)}`);
  }, [stored, name, router]);

  //"Start rule" on the overview: arrive with its draft already open in the editor
  const { takePending } = data;
  useEffect(() => {
    if (!stored) return;
    const draft = takePending(name);
    //eslint-disable-next-line react-hooks/set-state-in-effect -- a one-shot hand-off from the overview
    if (draft) setEditing({ index: null, rule: draft });
  }, [stored, name, takePending]);

  const tableNames = data.tables.map((t) => t.name);
  const groupNames = data.groups.map((g) => g.name);
  const targets = useMemo(
    () => targetOptions(data.tables, data.groups, data.workers, name, data.preprocessors),
    [data.tables, data.groups, data.workers, name, data.preprocessors]
  );

  if (data.loading) {
    return <p className="text-sm text-muted-foreground">Loading…</p>;
  }
  if (!stored) {
    return (
      <EmptyState>
        There is no routing table named <code className="font-mono">{name}</code>.{" "}
        <Link href="/cp/routing" className="text-primary hover:underline">Back to routing →</Link>
      </EmptyState>
    );
  }

  const draft: RouteTableInput = { name, label, enabled, targetFunction, rules: rules.map((r) => r.rule) };
  const count = tableChangeCount(stored, draft);
  const warnings = routeTableWarnings(draft, tableNames, data.workers, data.groups);
  const dead = unreachableRules(draft);
  //against the stored tables: a draft rule here cannot make this table reachable, only one elsewhere can
  const unreached = unreachedNote(name, data.tables);
  const ordered = targetFunction === "NORMAL";
  const sendsHere = [...new Set(data.tables
    .filter((t) => t.name !== name && t.rules.some((r) => r.enabled && r.target === name))
    .map((t) => t.name))];

  //the receipt rules the panel keeps for itself, by shape: a saved rule in the entry-point table that
  //returns receipts to one listener. Shown locked; the server refuses changing them either way
  const listeners = data.workers.filter((w) => w.type === "smppserver");
  const lockedFor = (rule: RouteRule) =>
    name === DEFAULT_TABLE_NAME && rule.id != null ? lockedReceiptListener(rule, listeners) : null;
  //a locked rule counts as a system rule even without a system: note -- the bootstrap's own receipt
  //rule has none -- so it folds away with the others and moves among them
  const asSystem = (rule: RouteRule) => isSystemRule(rule) || lockedFor(rule) !== null;
  const lockedNote = (rule: RouteRule) => {
    const listener = lockedFor(rule);
    return listener
      ? `The receipt rule for listener ${listener.name}. It was created with the listener and is removed with it. `
        + "A receipt has one place to go, the listener its message arrived on, so this can't be edited, "
        + "switched off or deleted."
      : undefined;
  };
  const indexed = rules.map((r, index) => ({ ...r, index }));
  const system = indexed.filter((r) => asSystem(r.rule));
  const business = indexed.filter((r) => !asSystem(r.rule));
  const systemChanged = system.some((r) => ruleChanged(stored.rules, r.rule, r.index));

  function patch(index: number, next: RouteRule) {
    setRules((cur) => cur.map((r, i) => (i === index ? { ...r, rule: next } : r)));
  }
  function move(index: number, by: -1 | 1) {
    setRules((cur) => moveRule(
      cur.map((r) => ({ ...r, label: asSystem(r.rule) ? r.rule.label ?? "system:" : r.rule.label })), index, by
    ).map(({ key, rule }) => ({ key, rule })));
  }

  async function save() {
    const invalid = validateRouteTable(draft);
    if (invalid) {
      setError(invalid);
      return;
    }
    //once, for everything staged: the moves, toggles and edits were deliberately unconfirmed
    const summary = stagedSummary(
      stored!.rules.map((r, at) => ({ k: ruleKey(r, at), r })),
      draft.rules.map((r, at) => ({ k: ruleKey(r, at), r })),
      (x) => x.k,
      (x) => rulePrint(x.r)
    );
    const settingsChanged: ChangeLine[] = [
      ...((stored!.label ?? "") !== label ? [{ label: "Label", from: stored!.label || "(none)", to: label || "(none)" }] : []),
      ...(stored!.enabled !== enabled ? [{ label: "Enabled", from: String(stored!.enabled), to: String(enabled) }] : []),
      ...(stored!.targetFunction !== targetFunction
        ? [{ label: "Target function", from: stored!.targetFunction, to: targetFunction }] : []),
    ];
    const ok = await confirm({
      title: `Save routing table ${name}`,
      consequence: `${summary || `${count} change(s)`}. The gateway routes by the new table from its next poll, `
        + "so every message after that follows it.",
      confirmLabel: "Save table",
      tone: !enabled && stored!.enabled ? "caution" : "primary",
      changes: settingsChanged,
    });
    if (!ok) return;
    setSaving(true);
    setError("");
    const failure = await data.save(draft);
    setSaving(false);
    if (failure) setError(failure);
    else setJustSaved(true);
  }

  const row = (r: (typeof indexed)[number], seq: number, total: number) => (
    <RuleRow
      key={r.key}
      rule={r.rule}
      seq={ordered ? seq : null}
      first={seq === 1}
      last={seq === total}
      ordered={ordered}
      changed={ruleChanged(stored.rules, r.rule, r.index)}
      unreachable={unreached
        ? `Never runs: nothing routes to ${name}.`
        : dead.has(r.index) ? "Never reached: a rule above already takes every message." : null}
      count={matchCount(data.metrics, stored, r.rule)}
      metricsLoaded={data.metrics !== null}
      targetFunction={targetFunction}
      target={targetKindLabel(r.rule.target, tableNames, data.workers, groupNames)}
      lockedFor={lockedFor(r.rule)?.name ?? null}
      onToggle={(on) => patch(r.index, { ...r.rule, enabled: on })}
      onEdit={() => setEditing({ index: r.index, rule: r.rule })}
      onMove={(by) => move(r.index, by)}
    />
  );

  return (
    <>
      <section className="min-w-0 rounded-xl border border-border bg-card">
        <header className="flex flex-wrap items-center gap-2 border-b border-border px-4 py-3 sm:px-5">
          <h2 className="font-mono text-title">{name}</h2>
          {name === DEFAULT_TABLE_NAME && <Badge>Entry point</Badge>}
          <Badge variant="outline">{ordered ? "In order" : "Cheapest vendor"}</Badge>
          {!enabled && <Badge variant="destructive">Switched off</Badge>}
          {sendsHere.length > 0 && (
            <span className="text-xs text-muted-foreground">
              Reached from{" "}
              {sendsHere.map((t, i) => (
                <span key={t}>
                  {i > 0 && ", "}
                  <Link href={tableHref(t)} className="font-mono text-primary hover:underline">{t}</Link>
                </span>
              ))}
            </span>
          )}
          <span className="ml-auto flex gap-1.5">
            <Link href="/cp/routing/test" className={buttonClasses({ variant: "outline", size: "sm" })}>Test</Link>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setSettings(true)}>
              <Settings2 className="h-3.5 w-3.5" aria-hidden="true" /> Table
            </Button>
          </span>
        </header>

        <p className="px-4 pt-3 text-sm text-muted-foreground sm:px-5">
          {label.trim() ? `${label.trim()} ` : ""}
          {ordered ? "Rules are tried top to bottom, and the first match wins." : "Every matching vendor competes and the cheapest rate wins, so order does not matter."}
        </p>

        {(warnings.length > 0 || error || unreached) && (
          <div className="space-y-2 px-4 pt-3 sm:px-5">
            {unreached && (
              <HealthStrip
                action={
                  <Button variant="outline" size="sm" className="h-7"
                    title={`Opens a new rule in ${DEFAULT_TABLE_NAME} that sends into ${name}. Give it the conditions that should lead here.`}
                    onClick={() => {
                      data.startRule(DEFAULT_TABLE_NAME, {
                        id: null, target: name, copied: false, label: null, enabled: true, conditions: [], filters: [],
                      });
                      router.push(tableHref(DEFAULT_TABLE_NAME));
                    }}>
                    Add a rule in {DEFAULT_TABLE_NAME} → {name}
                  </Button>
                }
              >
                {unreached}
              </HealthStrip>
            )}
            {warnings.map((w) => <HealthStrip key={w}>{w}</HealthStrip>)}
            <ErrorNote error={error} />
          </div>
        )}
        {justSaved && count === 0 && !error && (
          <div className="px-4 pt-3 sm:px-5"><ApplyNowButton compact /></div>
        )}

        {system.length > 0 && (
          <div className="mx-4 mt-3 rounded-lg border border-border bg-muted/40 sm:mx-5">
            <button type="button" aria-expanded={showSystem} onClick={() => setShowSystem((s) => !s)}
              className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm text-muted-foreground hover:text-foreground">
              <ChevronRight className={cn("h-4 w-4 shrink-0 transition-transform", showSystem && "rotate-90")} aria-hidden="true" />
              <span className="min-w-0">
                {system.length} system {system.length === 1 ? "rule" : "rules"}: receipts back to listeners, inbound to a listener, message types into tables
              </span>
              {systemChanged && <Badge className="ml-auto shrink-0">Unsaved</Badge>}
            </button>
            {showSystem && (
              <ol className="divide-y divide-border rounded-b-lg border-t border-border bg-card">
                {system.map((r, i) => row(r, i + 1, system.length))}
              </ol>
            )}
          </div>
        )}

        {business.length > 0 ? (
          <ol className="mt-3 divide-y divide-border border-t border-border">
            {business.map((r, i) => row(r, i + 1, business.length))}
          </ol>
        ) : (
          <p className="px-4 py-6 text-sm text-muted-foreground sm:px-5">
            {system.length ? "No rules of your own yet. Add one to decide where business traffic goes." : "No rules, so this table routes nothing."}
          </p>
        )}

        <div className="flex flex-wrap items-center gap-3 border-t border-border px-4 py-3 sm:px-5">
          <Button variant="outline" size="sm" className="gap-1.5"
            onClick={() => setEditing({ index: null, rule: { id: null, target: "", copied: false, label: null, enabled: true, conditions: [], filters: [] } })}>
            <Plus className="h-3.5 w-3.5" aria-hidden="true" /> Add a rule
          </Button>
          <span className="text-xs text-muted-foreground">Changes wait for Save.</span>
        </div>
      </section>

      <SaveBar
        count={count}
        saving={saving}
        message={`Nothing has reached ${name} yet.`}
        onDiscard={reset}
        onSave={() => void save()}
        inset
      />

      {editing && (
        <RouteRuleDialog
          rule={editing.rule}
          position={editing.index === null ? null : business.findIndex((r) => r.index === editing.index) + 1
            || system.findIndex((r) => r.index === editing.index) + 1}
          tableName={name}
          targetFunction={targetFunction}
          targets={targets}
          tableNames={tableNames}
          workers={data.workers}
          groupNames={groupNames}
          filters={data.filters}
          belowCatchAll={editing.index === null
            ? unreachableRules({ targetFunction, rules: [...draft.rules, { ...editing.rule, enabled: true }] }).has(draft.rules.length)
            : dead.has(editing.index)}
          onClose={() => setEditing(null)}
          locked={lockedNote(editing.rule)}
          onDelete={editing.index === null ? null : async () => {
            const at = editing.index!;
            //a delete, though staged: it asks for the word here, and the Save that sends it asks again
            const ok = await confirmDelete({
              title: `Remove this rule from ${name}`,
              consequence: `The rule to ${editing.rule.target || "(no target)"} is taken out of ${name} when you save. `
                + "Messages it matched go on to the next rule that matches, or are not routed at all.",
              confirmLabel: "Remove rule",
            });
            if (!ok) return;
            setRules((cur) => cur.filter((_, i) => i !== at));
            setEditing(null);
          }}
          onDone={(next) => {
            if (editing.index === null) setRules((cur) => [...cur, wrap(next)]);
            else patch(editing.index, next);
            setEditing(null);
          }}
        />
      )}

      {settings && (
        <TableSettingsDialog
          table={stored}
          label={label}
          enabled={enabled}
          targetFunction={targetFunction}
          sendsHere={sendsHere}
          removal={describeTableRemoval(stored, data.tables)}
          busy={data.busy === name}
          onLabel={setLabel}
          onEnabled={setEnabled}
          onTargetFunction={setTargetFunction}
          onClose={() => setSettings(false)}
          onDelete={async () => {
            const failure = await data.remove(name);
            if (failure) {
              setError(failure);
              setSettings(false);
            } else {
              router.push("/cp/routing");
            }
          }}
        />
      )}
    </>
  );
}

function RuleRow({
  rule,
  seq,
  first,
  last,
  ordered,
  changed,
  unreachable,
  count,
  metricsLoaded,
  targetFunction,
  target,
  lockedFor,
  onToggle,
  onEdit,
  onMove,
}: {
  rule: RouteRule;
  seq: number | null;
  first: boolean;
  last: boolean;
  ordered: boolean;
  changed: boolean;
  /** Why this rule never runs, or null when it can. */
  unreachable: string | null;
  count: number | null;
  metricsLoaded: boolean;
  targetFunction: TargetFunction;
  target: ReturnType<typeof targetKindLabel>;
  /** The listener this is the locked receipt rule for, or null for a rule the operator owns. */
  lockedFor: string | null;
  onToggle: (on: boolean) => void;
  onEdit: () => void;
  onMove: (by: -1 | 1) => void;
}) {
  const warn = target.kind === "disabled" || target.kind === "unknown"
    || (targetFunction === "LCR" && (target.kind === "table" || target.kind === "group"));
  return (
    <li className={cn(
      "grid grid-cols-[1.5rem_minmax(0,1fr)] gap-x-2 gap-y-2 px-4 py-3 sm:grid-cols-[1.5rem_minmax(0,1fr)_auto] sm:px-5",
      changed && "shadow-[inset_3px_0_0_var(--color-primary)]",
      unreachable && "bg-warning-soft/60"
    )}>
      <span className="pt-0.5 text-sm tabular-nums text-muted-foreground">{seq ?? "·"}</span>
      <div className={cn("min-w-0", !rule.enabled && "opacity-50")}>
        <p className="text-sm">{describeRuleWhen(rule)}</p>
        <div className="mt-1 flex flex-wrap items-center gap-1.5 text-sm">
          {rule.copied
            ? <Copy className="h-3.5 w-3.5 text-muted-foreground" aria-label="Copy to" />
            : <ArrowRight className="h-3.5 w-3.5 text-muted-foreground" aria-label="Send to" />}
          {target.kind === "table"
            ? <Link href={tableHref(rule.target)} className="font-mono font-semibold text-primary hover:underline">{rule.target}</Link>
            : <span className="break-all font-mono font-semibold">{rule.target}</span>}
          <Badge variant={warn ? "warning" : "outline"}>
            {targetFunction === "LCR" && target.kind === "table" ? "Table · skipped by cheapest" : target.label}
          </Badge>
          {rule.copied && <Badge variant="outline">Copy, keeps going</Badge>}
          {lockedFor && (
            <Badge variant="outline" className="gap-1 bg-muted font-semibold">
              <Lock className="h-3 w-3" aria-hidden="true" /> System
            </Badge>
          )}
          {changed && <Badge>Unsaved</Badge>}
        </div>
        {lockedFor && (
          <p className="mt-0.5 text-xs text-muted-foreground">
            Created with listener {lockedFor}, removed with it. Receipts have one place to go, so this can&apos;t be
            edited or switched off.
          </p>
        )}
        {rule.label && !rule.label.startsWith("system:") && <p className="mt-0.5 text-xs text-muted-foreground">{rule.label}</p>}
        {unreachable && <p className="mt-0.5 text-xs text-warning">{unreachable}</p>}
      </div>
      <div className="col-start-2 flex flex-wrap items-center gap-2 sm:col-start-3 sm:justify-end">
        <span className="mr-auto text-xs tabular-nums text-muted-foreground sm:mr-0 sm:min-w-[5.5rem] sm:text-right"
          title="Matched since the gateway last restarted">
          {count !== null ? `${localeNumber(count)} sent` : metricsLoaded && rule.id != null ? "0 sent" : "—"}
        </span>
        {lockedFor ? (
          <span className="inline-flex items-center gap-1 text-xs text-muted-foreground"
            title="A system rule: created with its listener and removed with it">
            <Lock className="h-3.5 w-3.5" aria-hidden="true" /> Locked
          </span>
        ) : (
          <Switch checked={rule.enabled} onChange={onToggle} aria-label={rule.enabled ? "Rule on" : "Rule off"} />
        )}
        <Button variant="outline" size="sm" onClick={onEdit}>{lockedFor ? "View" : "Edit"}</Button>
        {ordered && (
          <span className="flex">
            <Button variant="ghost" size="sm" className="h-8 w-8 px-0" aria-label="Move up" disabled={first} onClick={() => onMove(-1)}>
              <ArrowUp className="h-4 w-4" aria-hidden="true" />
            </Button>
            <Button variant="ghost" size="sm" className="h-8 w-8 px-0" aria-label="Move down" disabled={last} onClick={() => onMove(1)}>
              <ArrowDown className="h-4 w-4" aria-hidden="true" />
            </Button>
          </span>
        )}
      </div>
    </li>
  );
}

/** The table's own settings, staged with its rules; and Delete, which is immediate. */
function TableSettingsDialog({
  table,
  label,
  enabled,
  targetFunction,
  sendsHere,
  removal,
  busy,
  onLabel,
  onEnabled,
  onTargetFunction,
  onClose,
  onDelete,
}: {
  table: RouteTable;
  label: string;
  enabled: boolean;
  targetFunction: TargetFunction;
  sendsHere: string[];
  removal: string;
  busy: boolean;
  onLabel: (v: string) => void;
  onEnabled: (v: boolean) => void;
  onTargetFunction: (v: TargetFunction) => void;
  onClose: () => void;
  onDelete: () => Promise<void>;
}) {
  const entry = table.name === DEFAULT_TABLE_NAME;
  const confirmDelete = useConfirmDelete();
  return (
    <Dialog open onClose={onClose} title={`Table ${table.name}`} description="These changes wait for Save, with the rules.">
      <div className="space-y-4">
        <SettingsRows>
          <SettingsRow label="Description" htmlFor="ts-label" help="Optional. What this table is for.">
            <Input id="ts-label" value={label} onChange={(e) => onLabel(e.target.value)} />
          </SettingsRow>
          <SettingsRow label="How it chooses" help={TARGET_FUNCTION_MEANING[targetFunction]}>
            <Segmented<TargetFunction>
              label="How it chooses"
              value={targetFunction}
              onChange={onTargetFunction}
              fill
              options={[{ value: "NORMAL", label: "In order" }, { value: "LCR", label: "Cheapest vendor" }]}
            />
          </SettingsRow>
          <SettingsRow
            label="Enabled"
            labelId="ts-enabled"
            help={entry
              ? "The entry point. Switched off, nothing is routed at all."
              : sendsHere.length
                ? `Switched off, ${sendsHere.join(", ")} send here and the message has nowhere to go.`
                : "Nothing sends into it, so switching it off changes nothing."}
          >
            <div className="flex md:justify-end">
              <Switch checked={enabled} onChange={onEnabled} aria-labelledby="ts-enabled" />
            </div>
          </SettingsRow>
        </SettingsRows>
        <div className="space-y-2 border-t border-border pt-4">
          <div className="text-sm font-medium">Delete</div>
          {entry ? (
            <p className="text-sm text-muted-foreground">The gateway needs a table named default, so it cannot be deleted.</p>
          ) : (
            <Button
              type="button"
              variant="ghost"
              className="text-destructive"
              disabled={busy}
              onClick={async () => {
                if (await confirmDelete({ title: `Delete routing table ${table.name}`, consequence: removal, confirmLabel: `Delete ${table.name}` })) {
                  await onDelete();
                }
              }}
            >
              {busy ? "Deleting…" : "Delete this table"}
            </Button>
          )}
        </div>
        <div className="flex justify-end border-t border-border pt-4">
          <Button type="button" onClick={onClose}>Done</Button>
        </div>
      </div>
    </Dialog>
  );
}
