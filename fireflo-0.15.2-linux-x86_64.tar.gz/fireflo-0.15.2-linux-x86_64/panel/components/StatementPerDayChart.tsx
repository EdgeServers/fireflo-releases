"use client";
import { useMemo } from "react";
import { Bar, CartesianGrid, ComposedChart, Line, XAxis, YAxis } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  ChartContainer, ChartLegend, ChartLegendContent, ChartTooltip, ChartTooltipContent, type ChartConfig,
} from "@/components/ui/chart";
import { stackedDays } from "@/lib/statement-chart";
import type { StatementSplit } from "@/lib/statement-sql";
import { formatDay, zoneShortName } from "@/lib/datetime";
import { useDisplayZone } from "@/components/DisplayZoneProvider";
import { DayNote } from "./DayNote";

/** See `UsageClient` — a Bar draws nothing at all until a frame is painted. */
const ANIMATION = { isAnimationActive: false } as const;

/** The stacked segments' colours, biggest first; Other is drawn muted. */
const SEGMENT_COLORS = [
  "var(--color-chart-1)", "var(--color-chart-2)", "var(--color-chart-3)",
  "var(--color-chart-4)", "var(--color-chart-5)", "var(--color-chart-6)",
];

/**
 * The period day by day: one stacked segment per product or login (the biggest five by money, the
 * rest as Other), with what was billed on its own axis. The days and their breakdown come from the
 * same rows as the table, so the chart and the total cannot disagree.
 */
export function StatementPerDayChart({ days, lines, split, height = "h-56" }: {
  days: { day: string; price: number; byKey?: Record<string, { submitted: number; amount: number }> }[];
  lines: { product: string }[];
  split: StatementSplit;
  height?: string;
}) {
  const { billingZone } = useDisplayZone();
  const chart = useMemo(() => stackedDays(days, lines, split), [days, lines, split]);
  const config = useMemo(() => {
    const c: ChartConfig = { price: { label: "Billed", color: "var(--color-foreground)" } };
    chart.series.forEach((s, i) => {
      c[s.id] = { label: s.label, color: s.id === "other" ? "var(--color-muted-foreground)" : SEGMENT_COLORS[i % SEGMENT_COLORS.length] };
    });
    return c;
  }, [chart]);
  return (
    <Card>
      <CardHeader bar>
        <CardTitle>Per day</CardTitle>
        <p className="text-xs text-muted-foreground">
          Bars: messages per day ({zoneShortName(billingZone)} days), by {split === "login" ? "login" : "product"} · Line: what was billed. The
          same window the total above covers; a month that is one large day and nothing else is usually a bulk
          send somebody did not expect to be billed for.
        </p>
      </CardHeader>
      <CardContent>
        <ChartContainer config={config} className={`${height} w-full`}>
          <ComposedChart data={chart.data as Array<Record<string, number | string>>} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--color-border)" />
            <XAxis dataKey="day" tickLine={false} axisLine={false}
              tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
              tickFormatter={(v: string) => formatDay(v)} interval="preserveStartEnd" />
            <YAxis yAxisId="volume" tickLine={false} axisLine={false} width={44} allowDecimals={false}
              tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }} />
            {/* its own axis: money and message counts share no scale, and on one axis a cheap
                product's line would lie flat along the bottom */}
            <YAxis yAxisId="billed" orientation="right" tickLine={false} axisLine={false} width={52}
              tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
              //the axis divides by the scale exactly once, here. The values stay scaled integers
              tickFormatter={(v: number) => (v / 10_000).toFixed(0)} />
            <ChartTooltip
              labelFormatter={(l) => `${formatDay(String(l), { year: true })} (${zoneShortName(billingZone)} day)`}
              content={<ChartTooltipContent indicator="dot" />}
            />
            <ChartLegend content={<ChartLegendContent />} />
            {chart.series.map((s, i) => (
              <Bar key={s.id} {...ANIMATION} yAxisId="volume" dataKey={s.id as string} stackId="v"
                fill={config[s.id]?.color} radius={i === chart.series.length - 1 ? [2, 2, 0, 0] : [0, 0, 0, 0]} />
            ))}
            <Line {...ANIMATION} yAxisId="billed" dataKey="price" stroke="var(--color-foreground)"
              strokeWidth={2} dot={false} />
          </ComposedChart>
        </ChartContainer>
        <DayNote className="mt-2" />
      </CardContent>
    </Card>
  );
}
