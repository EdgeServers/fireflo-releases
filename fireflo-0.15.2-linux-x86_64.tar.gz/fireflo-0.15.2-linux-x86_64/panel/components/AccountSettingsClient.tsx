"use client";
import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { AccountActivityCard, type AccountActivityHandle } from "./AccountActivityCard";
import { AccountArchiveCard } from "./AccountArchiveCard";
import { HealthStrip } from "./CardBits";
import { AccountForm } from "./AccountForm";
import { PortalAccessCard } from "./PortalAccessCard";
import { useConfirmChange } from "./ConfirmProvider";
import { useAccounts } from "./useAccounts";
import type { AccountSummary } from "@/lib/account-types";
import { formatTimestamp } from "@/lib/datetime";
import { surface } from "@/lib/panel-surface";
import { useDisplayZone } from "@/components/DisplayZoneProvider";

/**
 * The account's Settings tab: what it is called, who can sign in for it, and what has happened to it.
 *
 * <p>Laid out so each fact appears once. The name and id are in the header above the tabs; the way
 * to logins, tariff and statement is the tab bar; so the old "This account" rail, which repeated
 * all of them, is gone and the two counts it held that are not anywhere else sit under the form.
 * Left: the form, then the activity history it feeds. Right: portal access, one row per person.
 */
export function AccountSettingsClient({ id }: { id: string }) {
  const { accounts, orphans, archived, save, busy, load, error, loading, setArchivedState } = useAccounts();
  //what this surface may show about what an account is charged -- see lib/panel-surface.ts. Also
  //what decides operator-only cards here: portal access and activity are the operator's
  const { pricing } = surface();
  //an archived account (V1.100.0) is out of the everyday list but is still this page's account
  const catalogued = accounts.find((a) => a.id === id) ?? archived.find((a) => a.id === id) ?? null;
  const isArchived = Boolean(catalogued?.archivedAt);
  const orphan = orphans.find((o) => o.id === id) ?? null;
  const activity = useRef<AccountActivityHandle>(null);
  const operator = pricing && catalogued;
  //until the catalogue has answered, nothing is known about this id. Offering "Name this account"
  //in that moment put an adopt form on every account that exists, and saving it sent a label alone
  const pending = loading && !catalogued;

  return (
    //`xl` not `lg`: the form has its own two-column field grid inside, and that wraps badly in two
    //thirds of 1024px -- the same reasoning the vendors page records
    <div className={operator ? "grid items-start gap-6 xl:grid-cols-[minmax(0,1fr)_24rem]" : "max-w-3xl"}>
      <div className="min-w-0 space-y-6">
        {/* the route's refusal, which this tab used to swallow: a 400 ended the spinner and said
            nothing, so a vendor-named or badly formed id looked saved and was not */}
        {error && <HealthStrip tone="destructive">{error}</HealthStrip>}
        <Card>
          <CardHeader bar>
            <CardTitle>
              {catalogued || pending ? "Organisation" : "Name this account"}
            </CardTitle>
            {!catalogued && !pending && <CardDescription>This id is in use but has no catalogue row.</CardDescription>}
          </CardHeader>
          <CardContent>
            {pending ? (
              <p role="status" className="py-6 text-sm text-muted-foreground">Loading account…</p>
            ) : catalogued && isArchived ? (
              //read-only while archived: the writers refuse it anyway, and a form that cannot save
              //is worse than none
              <dl className="grid gap-x-6 gap-y-2 text-sm sm:grid-cols-2">
                <div><dt className="text-xs text-muted-foreground">Name</dt><dd>{catalogued.label || "—"}</dd></div>
                <div><dt className="text-xs text-muted-foreground">Email</dt><dd>{catalogued.email || "—"}</dd></div>
                <div className="sm:col-span-2"><dt className="text-xs text-muted-foreground">Description</dt><dd>{catalogued.description || "—"}</dd></div>
              </dl>
            ) : catalogued ? (
              <AccountForm
                id={id}
                label={catalogued.label ?? ""}
                description={catalogued.description ?? ""}
                email={catalogued.email ?? ""}
                enabled={catalogued.enabled}
                resells={catalogued.resells}
                parentAccountId={catalogued.parentAccountId}
                childCount={"childCount" in catalogued ? catalogued.childCount : 0}
                //listing, reselling and the parent are the operator's. On the reseller surface the
                //write path pins all three, so offering them would be a form that lies about what
                //it saved -- see AccountForm
                allowHierarchy={pricing}
                busy={busy === id}
                onSave={save}
                onReload={() => {
                  void load();
                  activity.current?.reload();
                }}
              />
            ) : (
              <NameIt id={id} orphan={orphan} busy={busy === id} onSave={(input) => void save(input)} />
            )}
          </CardContent>
          {catalogued && <Facts account={catalogued} pricing={pricing} />}
        </Card>

        {operator && (
          <AccountArchiveCard
            account={catalogued}
            busy={busy === id}
            onArchive={async (archive) => {
              const done = await setArchivedState(id, archive);
              activity.current?.reload();
              return done;
            }}
          />
        )}

        {operator && <AccountActivityCard ref={activity} id={id} />}
      </div>

      {operator && (
        <div className="min-w-0 xl:sticky xl:top-4">
          {/* remounted when the account's email changes, so the card reads the login it now means */}
          <PortalAccessCard key={catalogued.email ?? ""} id={id} onChanged={() => activity.current?.reload()} />
        </div>
      )}
    </div>
  );
}

/**
 * The two counts that are not on a tab of their own, and when the row last changed, as one line.
 *
 * <p>Logins has its own tab, but how many there are is still worth seeing without opening it; rate
 * rules are a pricing fact, so the reseller surface does not get them -- its query does not even
 * fetch them, and rendering the zero would be a confident lie.
 */
function Facts({ account, pricing }: { account: AccountSummary; pricing: boolean }) {
  const { zone } = useDisplayZone();
  const facts = [
    `${account.credentialCount} gateway login${account.credentialCount === 1 ? "" : "s"}`,
    pricing ? `${account.ruleCount} rate rule${account.ruleCount === 1 ? "" : "s"}` : null,
    account.resells ? `holds ${account.childCount} account${account.childCount === 1 ? "" : "s"}` : null,
  ].filter(Boolean);
  return (
    <CardFooter className="border-t border-border pt-3 text-xs text-muted-foreground">
      <span>{facts.join(" · ")}</span>
      <span className="ml-auto" suppressHydrationWarning>
        {account.updatedAt ? `Edited ${formatTimestamp(account.updatedAt, zone)}` : "Never edited"}
      </span>
    </CardFooter>
  );
}

/** Offers a name for an id that has one everywhere except in the catalogue. */
function NameIt({
  id,
  orphan,
  busy,
  onSave,
}: {
  id: string;
  orphan: { fromCredential: boolean; fromRateScope: boolean } | null;
  busy: boolean;
  onSave: (input: { id: string; label: string; enabled: boolean }) => void;
}) {
  const [label, setLabel] = useState("");
  const confirm = useConfirmChange();
  return (
    <div className="space-y-2">
      <p className="text-xs text-muted-foreground">
        {orphan?.fromCredential
          ? "In use by a login, but nobody has given it a name."
          : orphan?.fromRateScope
            ? "Found only as a rate scope. That column also holds vendor names, so check this is an "
              + "account before naming it — a name here does not make it one."
            : "Nothing in the configuration mentions this id yet."}
      </p>
      <div className="flex flex-wrap items-end gap-2">
        <Field label="Name" htmlFor="adopt" className="min-w-48 flex-1">
          <Input id="adopt" value={label} onChange={(e) => setLabel(e.target.value)}
            placeholder="Acme Communications" />
        </Field>
        <Button disabled={busy || !label.trim()}
          onClick={async () => {
            if (!(await confirm({
              title: "Add this account to the catalogue?",
              consequence: `Names ${id} "${label.trim()}" and lists it in this panel.`,
              confirmLabel: "Add to the catalogue",
              changes: [{ label: "Name", to: label.trim() }],
            }))) {
              return;
            }
            onSave({ id, label: label.trim(), enabled: true });
          }}>
          {busy ? "Saving…" : "Add to the catalogue"}
        </Button>
      </div>
    </div>
  );
}
