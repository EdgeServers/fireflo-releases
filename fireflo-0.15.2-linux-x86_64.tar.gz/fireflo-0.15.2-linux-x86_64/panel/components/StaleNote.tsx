"use client";
import { formatTimestamp } from "@/lib/datetime";
import { useDisplayZone } from "@/components/DisplayZoneProvider";

/**
 * Says the figures on screen are an older read, because the latest one took too long -- the stats
 * route serves the last good answer rather than an error (`lib/stats-cache.ts`). Quiet on purpose:
 * the page is still right as of that time.
 */
export function StaleNote({ stale }: { stale: { at: string; reason: string } | null }) {
  const { zone } = useDisplayZone();
  if (!stale) return null;
  return (
    <p className="text-xs text-muted-foreground" title={stale.reason} suppressHydrationWarning>
      Showing figures from {formatTimestamp(stale.at, zone)}: the latest read took too long, and the next try is
      on the next refresh.
    </p>
  );
}
