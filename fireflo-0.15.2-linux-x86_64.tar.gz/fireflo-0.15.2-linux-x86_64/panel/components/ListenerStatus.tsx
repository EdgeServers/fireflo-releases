"use client";
import { useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Pause, Play, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CardSection } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Segmented } from "@/components/ui/segmented";
import { StatTile } from "@/components/ui/stat-tile";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { AccountTypeahead, type AccountOption } from "./AccountTypeahead";
import { HealthStrip } from "./CardBits";
import { ListenerLiveChart } from "./ListenerLiveChart";
import { PeakLine } from "./PeakLine";
import { RateBar, WARN_AT } from "./RateBar";
import { CeilingWithSource } from "./SourcePill";
import { usePoll } from "./usePoll";
import { count, duration } from "@/lib/format";
import { formatTps } from "@/lib/tps-format";
import { cn } from "@/lib/utils";
import { throttlingOn, type Health, type HealthSession, type HealthWorker } from "@/lib/health-types";
import type { WorkerVerdict } from "@/lib/worker-verdict";
import { accountOfKey, groupByLogin, hostsLabel, UNATTRIBUTED, type LoginGroup } from "@/lib/session-groups";
import {
  accountRates, chartRows, EMPTY_LIVE_SESSIONS, foldSessions, peakTotal, windowSamples,
  type LiveSessionHistory, type LiveSplit, type LiveWindow,
} from "@/lib/live-sessions";
import { noteSource } from "@/lib/page-sources";

/** How often the sessions are read. Twice health's pace: a client's rate moves faster than a bind count. */
const POLL_MS = 5_000;
/** The gateway's page cap for the sessions query; asking for more is clamped to this. */
const PAGE = 200;

const SPLITS = [
  { value: "account", label: "By account" },
  { value: "login", label: "By login" },
  { value: "total", label: "Total" },
] as const satisfies readonly { value: LiveSplit; label: string }[];

const WINDOWS = [
  { value: "5m", label: "5 min" },
  { value: "15m", label: "15 min" },
  { value: "1h", label: "1 h", title: "Drawn at ten-second points" },
] as const satisfies readonly { value: LiveWindow; label: string; title?: string }[];

/**
 * A listener's Status tab: who is bound to this port, how fast each of them is sending, and against
 * which ceiling (`S['listener-status']` in the mockups).
 *
 * <p>Tiles, then a chart of messages per second by account, by login or in total, then one row per
 * account × login. Everything below the tiles comes from one source: the operator `sessions` query
 * for this listener, read every five seconds and folded by login (`groupByLogin`), its counters turned
 * into rates by `lib/live-sessions.ts`. Nothing is read from the database and nothing is kept once
 * the tab closes -- the chart starts when the page was opened, and says so.
 *
 * <p>The ceiling is the account's (`tps_limit` on the session: `conf.maxRate.<id>`, else the
 * listener's `conf.maxRate.default`), shared by every login of the account, so a row turns amber
 * when the <em>account</em> is within 10 % of it, not the login. A login held by its own `max_tps`
 * is measured against that instead -- known only once the gateway says which limit binds (0.15.1,
 * `limit_source`); until then the source pill is not drawn, and neither is anything that would need
 * the throttle counts (`health.throttling`).
 */
export function ListenerStatus({
  name,
  live,
  health,
  capacity,
  verdict,
  onPeakReset,
  initialFilter = "",
}: {
  /** The listener's configured name, as the routes and the throttle list may name it. */
  name: string;
  live: HealthWorker | undefined;
  health: Health | null;
  /** `srv.maxConnections`, when one is set. */
  capacity: number | null;
  verdict: WorkerVerdict;
  onPeakReset?: () => void;
  /** The client filter to open with: an account, when the Connectivity map sent you here. */
  initialFilter?: string;
}) {
  const router = useRouter();
  const [frozen, setFrozen] = useState(false);
  const [split, setSplit] = useState<LiveSplit>("account");
  const [span, setSpan] = useState<LiveWindow>("15m");
  const [picked, setPicked] = useState("");
  const [filter, setFilter] = useState(initialFilter);
  const { snap, error } = useListenerSessions(live?.name, live?.bound, frozen);

  const groups = useMemo(() => (snap ? groupByLogin(snap.rows) : []), [snap]);
  const latest = snap?.history.samples.at(-1);
  const byAccount = accountRates(latest);
  const rateOf = (g: LoginGroup) => latest?.rates[g.key] ?? g.tps;

  //the chart: one account when one is picked, its ceiling dashed across
  const windowed = useMemo(
    () => (snap
      ? windowSamples(snap.history, span, snap.at, picked ? (key) => accountOfKey(key) === picked : undefined)
      : []),
    [snap, span, picked]
  );
  const { points, series } = useMemo(() => chartRows(windowed, split), [windowed, split]);
  const pickedCeiling = picked ? sharedCeiling(groups.filter((g) => g.account === picked)) : null;
  const sparkline = useMemo(
    () => (snap ? chartRows(windowSamples(snap.history, "5m", snap.at), "total").points.map((p) => p.total ?? null) : []),
    [snap]
  );
  const tabPeak = snap ? peakTotal(snap.history.samples) : null;

  const accountOptions = useMemo<AccountOption[]>(
    () => [...new Set(groups.map((g) => g.account))]
      .filter((a) => a !== UNATTRIBUTED)
      .sort((a, b) => a.localeCompare(b))
      .map((id) => ({ id, label: null, note: null })),
    [groups]
  );

  //throttle counts arrive with gateway 0.15.1; absent, the tile and the column are not drawn at all
  const throttling = health?.throttling;
  //the gateway counts per account, across its logins and every listener it named: so a row shows
  //its account's count, and says so on hover
  const mine = throttlingOn(throttling, live?.name ?? name);
  const throttledOf = (g: LoginGroup) => mine.find((t) => t.account === g.account);

  const needle = filter.trim().toLowerCase();
  const rows = groups
    .filter((g) => !needle || g.account.toLowerCase().includes(needle) || g.systemId.toLowerCase().includes(needle))
    .sort((a, b) => (rateOf(b) ?? -1) - (rateOf(a) ?? -1) || a.key.localeCompare(b.key));
  const loginsOf = (account: string) => groups.filter((g) => g.account === account).length;

  return (
    <div className="space-y-4">
      {verdict.detail && <p className="text-sm text-muted-foreground">{verdict.detail}</p>}
      {verdict.pending && (
        <HealthStrip>
          Stored settings and what the gateway is running disagree. The change is saved; the push did not
          land yet, and the thirty-second poll will apply it.
        </HealthStrip>
      )}
      {live?.last_error && <HealthStrip tone="destructive">{live.last_error}</HealthStrip>}

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <StatTile
          label="Connected"
          value={live?.bound != null ? count(live.bound) : "—"}
          hint={[
            capacity ? `of ${count(capacity)}` : null,
            snap ? `${groups.length} client${groups.length === 1 ? "" : "s"}` : null,
          ].filter(Boolean).join(" · ") || undefined}
        />
        <StatTile
          label="Messages/s now"
          value={live?.tps_measured != null ? formatTps(live.tps_measured) : "—"}
          sparkline={sparkline.length > 1 ? sparkline : undefined}
        />
        <StatTile
          label="Peak"
          value={live?.tps_peak ? formatTps(live.tps_peak.tps) : "—"}
          hint={tabPeak != null ? `${formatTps(Math.round(tabPeak))}/s since this tab opened` : undefined}
          footnote={<PeakLine peak={live?.tps_peak} scope={live?.name} onReset={onPeakReset} />}
        />
        {throttling != null && (
          <StatTile
            label="Throttled 5 min"
            value={count(mine.reduce((sum, t) => sum + (t.last5_minutes ?? 0), 0))}
            tone={mine.some((t) => (t.last5_minutes ?? 0) > 0) ? "negative" : "default"}
            hint="answered 0x58, at a ceiling"
          />
        )}
      </div>

      <CardSection
        title="Messages per second on this port"
        description="Each client’s submits, counted every 5 seconds since this tab opened."
        action={
          <div className="flex flex-wrap items-center gap-2">
            <Segmented label="Lines" options={SPLITS} value={split} onChange={setSplit} />
            <Segmented label="Window" options={WINDOWS} value={span} onChange={setSpan} />
            <AccountTypeahead value={picked} onChange={setPicked} options={accountOptions} className="w-44" />
          </div>
        }
      >
        {snap && points.length > 1 ? (
          <ListenerLiveChart points={points} series={series} split={split} ceiling={pickedCeiling} />
        ) : (
          <div className="flex h-56 items-center justify-center text-sm text-muted-foreground">
            {error ?? (frozen ? "Paused." : "Measuring — a rate needs two readings, five seconds apart.")}
          </div>
        )}
      </CardSection>

      <CardSection
        title="Clients on this port"
        description="Busiest first. A row opens the account’s Limits tab."
        action={
          <div className="flex flex-wrap items-center gap-2">
            <label className="relative block w-48">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" aria-hidden />
              <Input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="account or login" aria-label="Filter by account or login" className="pl-8" />
            </label>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setFrozen((f) => !f)} aria-pressed={frozen}>
              {frozen ? <Play className="h-3.5 w-3.5" aria-hidden /> : <Pause className="h-3.5 w-3.5" aria-hidden />}
              {frozen ? "Resume" : "Pause"}
            </Button>
          </div>
        }
      >
        {error && snap && <HealthStrip tone="destructive">{error}</HealthStrip>}
        <TableInCard>
          <THead>
            <TR>
              <TH>Account</TH>
              <TH>Login</TH>
              <TH>From</TH>
              <TH align="right">Binds</TH>
              <TH>TPS now</TH>
              <TH>Ceiling</TH>
              <TH align="right">Sent since bind</TH>
              <TH align="right">Receipts</TH>
              {throttling != null && <TH align="right">Throttled 5m</TH>}
              <TH>Bound for</TH>
            </TR>
          </THead>
          <TBody>
            {!snap && (
              <TR>
                <TD colSpan={10} muted>{error ?? "Reading the sessions…"}</TD>
              </TR>
            )}
            {snap && !rows.length && (
              <TR>
                <TD colSpan={10} muted>{groups.length ? "No client matches." : "Nobody is bound to this port."}</TD>
              </TR>
            )}
            {rows.map((g) => {
              const rate = rateOf(g);
              const ceiling = ceilingOf(g);
              const accountRate = byAccount[g.account] ?? rate;
              //who the ceiling belongs to decides what is measured against it
              const measured = ceiling?.login ? rate : accountRate;
              const hot = ceiling != null && measured != null && measured / ceiling.value >= WARN_AT;
              const linked = g.account !== UNATTRIBUTED;
              const href = `/cp/accounts/${encodeURIComponent(g.account)}/limits`;
              const account = throttling != null ? throttledOf(g) : undefined;
              const throttled = account?.last5_minutes ?? 0;
              return (
                <TR
                  key={g.key}
                  data-login={g.key}
                  className={cn(linked && "cursor-pointer")}
                  onClick={linked ? () => router.push(href) : undefined}
                >
                  <TD primary>
                    {linked ? (
                      <Link href={href} onClick={(e) => e.stopPropagation()} className="underline-offset-4 hover:underline">
                        {g.account}
                      </Link>
                    ) : g.account}
                  </TD>
                  <TD className="font-mono text-xs">{g.systemId}</TD>
                  <TD className="font-mono text-xs" title={g.hosts.join(", ")}>{hostsLabel(g.hosts)}</TD>
                  <TD num>{g.binds}</TD>
                  <TD>
                    <RateBar
                      rate={rate}
                      ceiling={ceiling?.value ?? null}
                      hot={hot}
                      //an account ceiling shared with other logins: show what the account sums to
                      note={!ceiling?.login && ceiling && loginsOf(g.account) > 1 && accountRate != null
                        ? `acct ${formatTps(Math.round(accountRate))}`
                        : null}
                    />
                  </TD>
                  <TD>
                    {ceiling ? (
                      <CeilingWithSource ceiling={{ value: ceiling.value, source: g.limitSource }} />
                    ) : (
                      <span className="text-muted-foreground">none</span>
                    )}
                  </TD>
                  <TD num>{g.submitted != null ? count(g.submitted) : "—"}</TD>
                  <TD num>{g.receipts != null ? count(g.receipts) : "—"}</TD>
                  {throttling != null && (
                    <TD
                      num
                      className={cn(throttled > 0 && "text-warning")}
                      title={account
                        ? `${g.account}'s, across its logins${(account.listeners ?? []).length > 1 ? ` and on ${(account.listeners ?? []).join(", ")}` : ""}: ${count(account.by_account_limit ?? 0)} by the account ceiling, ${count(account.by_login_limit ?? 0)} by a login's TPS in the last minute`
                        : undefined}
                    >
                      {count(throttled)}
                    </TD>
                  )}
                  <TD className="whitespace-nowrap">{g.youngest != null ? duration(g.youngest) : "—"}</TD>
                </TR>
              );
            })}
          </TBody>
        </TableInCard>
        <p className="text-xs text-muted-foreground">
          One row per login: its binds are summed and its rate is the change in what they sent between two
          readings. An account ceiling is shared by all of the account’s logins, so the bar turns amber when
          the account, not the login, reaches 90 %.
        </p>
      </CardSection>
    </div>
  );
}

/**
 * The ceiling a login's row is held to: its own `max_tps` when the gateway says that is the one that
 * binds, otherwise the account's.
 */
function ceilingOf(g: LoginGroup): { value: number; login: boolean } | null {
  if (g.limitSource === "UNLIMITED") {
    return null;
  }
  if (g.limitSource === "LOGIN_MAX_TPS" && g.loginTpsLimit != null) {
    return { value: g.loginTpsLimit, login: true };
  }
  return g.tpsLimit != null ? { value: g.tpsLimit, login: false } : null;
}

/** The account ceiling every login of one account reports, or null when they disagree or report none. */
function sharedCeiling(groups: readonly LoginGroup[]): number | null {
  const limits = new Set(groups.map((g) => g.tpsLimit).filter((v): v is number => v != null));
  return limits.size === 1 ? [...limits][0] : null;
}

interface SessionsSnapshot {
  worker: string;
  rows: HealthSession[];
  history: LiveSessionHistory;
  /** When the rows were read: the right edge of every window. */
  at: number;
}

/**
 * Every session of the listener, every five seconds, folded into the rate history as it lands.
 *
 * <p>The page size is the listener's bound count (capped at the gateway's 200), so a port with fifty
 * clients is one call; a larger one walks the pages. A walk that lands after a newer one started is
 * dropped, the ticket pattern the session browser uses. Paused, nothing is fetched and the
 * history holds still; resumed, the next reading is measured against the last one, which is a mean
 * over the pause, so the first point after it is drawn as such rather than as a spike.
 */
function useListenerSessions(
  worker: string | undefined,
  bound: number | null | undefined,
  paused: boolean
): { snap: SessionsSnapshot | null; error: string | null } {
  const [snap, setSnap] = useState<SessionsSnapshot | null>(null);
  const [error, setError] = useState<string | null>(null);
  const ticket = useRef(0);
  const kept = useRef<{ worker: string; history: LiveSessionHistory } | null>(null);

  const load = async () => {
    if (!worker) {
      return;
    }
    const mine = ++ticket.current;
    const limit = Math.min(PAGE, Math.max(1, bound ?? PAGE));
    const rows: HealthSession[] = [];
    for (;;) {
      const res = await fetch(
        `/api/control/workers/${encodeURIComponent(worker)}/sessions?offset=${rows.length}&limit=${limit}`,
        { cache: "no-store" }
      ).catch(() => null);
      const json = await res?.json().catch(() => null);
      if (mine !== ticket.current) {
        return;
      }
      noteSource(`sessions:${worker}`, res);
      if (!res?.ok || !json?.data?.rows) {
        setError(json?.error ?? (res ? `Could not read the sessions (${res.status}).` : "Could not reach the panel's API."));
        return;
      }
      rows.push(...(json.data.rows as HealthSession[]));
      if (rows.length >= (json.data.total ?? 0) || json.data.rows.length === 0) {
        break;
      }
    }
    const now = Date.now();
    const prior = kept.current?.worker === worker ? kept.current.history : EMPTY_LIVE_SESSIONS;
    const history = foldSessions(
      prior,
      groupByLogin(rows).map((g) => ({ key: g.key, submitted: g.submitted, tps: g.tps, members: g.members })),
      now
    );
    kept.current = { worker, history };
    setError(null);
    setSnap({ worker, rows, history, at: now });
  };

  usePoll(load, POLL_MS, !!worker && !paused, worker);
  return { snap: snap?.worker === worker ? snap : null, error };
}
