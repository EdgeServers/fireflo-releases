"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowUpRight, Database } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { buttonClasses } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { formatTimestamp } from "@/lib/datetime";
import { dbCardBlocks, type DbRow } from "@/lib/db-health";
import type { PoolsReport } from "@/lib/db-pools";
import { bytes } from "@/lib/format";
import { secondsLabel, stalledHint, stalledNames, writeBehind, type WriteBehind } from "@/lib/gateway-restart";
import type { Health } from "@/lib/health-types";
import { HealthStrip } from "./CardBits";
import { RestartAction, RestartRow, useRestartAllowed } from "./RestartActions";
import { useDisplayZone } from "@/components/DisplayZoneProvider";
import { count } from "@/lib/format";

/** Where the footer's button goes: the slow-query report lost its sidebar row to this card (0.15.1). */
const SLOW_QUERIES_HREF = "/cp/database/slow-queries";

/**
 * The database, from both ends (0.15.1), in three blocks:
 *
 * <ul>
 *   <li><strong>Connection · gateway → PostgreSQL</strong>: where the gateway points, the server
 *       and schema versions, its pool and lanes, the last probe -- from `health.database`
 *       (`db_info`). A gateway without the block gets no rows here, not dashes.</li>
 *   <li><strong>Connection · panel → PostgreSQL</strong>: this panel's two pools, from
 *       `/api/control/database/pools` (host and port only, never a credential).</li>
 *   <li><strong>Write-behind · gateway → PostgreSQL</strong> (0.15.2): each persistence stream's
 *       waiting writes and its state, from `health.persist_streams`; a stalled stream turns the
 *       header to "Writer stalled" and says what to do. Left out on an older gateway.</li>
 *   <li><strong>Admission</strong>: latency against the thresholds, submits refused since start,
 *       the receipt store's buffer and the call-record spill alarm.</li>
 * </ul>
 *
 * <p>An admin on a gateway with `component_restart` also gets the Restart row: Restart writers
 * (`persist`) and Reconnect pool (`db`), each with its help under it.
 *
 * <p>On Queues and Health, because a slow database is what a backlog there turns out to be more
 * often than not, and from 0.15.1 it is also what refuses new submits. The footer opens Slow queries.
 */
export function DbHealthCard({ health }: { health: Health | null | undefined }) {
  const pools = usePools(health?.observed_at ?? null);
  const blocks = dbCardBlocks(health, pools);
  const { admission } = blocks;
  const behind = writeBehind(health);
  const stalled = !!behind?.stalled;
  const restart = useRestartAllowed(health);
  if (!health && !pools) {
    return null;
  }
  return (
    <Card
      className={cn(
        admission?.tone === "destructive" && "border-destructive/50",
        (admission?.tone === "warning" || stalled) && admission?.tone !== "destructive" && "border-warning"
      )}
    >
      <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0">
        <CardTitle className="flex items-center gap-2">
          <Database className="h-4 w-4 text-muted-foreground" aria-hidden />
          Database
        </CardTitle>
        {admission && (
          <Badge variant={admission.tone === "success" ? "success" : admission.tone === "default" ? "outline" : admission.tone}>
            {admission.value}
          </Badge>
        )}
        {stalled && <Badge variant="warning">Writer stalled</Badge>}
        <span className="text-xs text-muted-foreground">
          {stalled && behind ? stalledHint(behind) : admission?.hint ?? "as the gateway's ingresses see it"}
        </span>
      </CardHeader>
      <CardContent className="space-y-4">
        <Block title="Connection · gateway → PostgreSQL" rows={blocks.gateway} />
        <Block title="Connection · panel → PostgreSQL" rows={blocks.panel} />
        {behind && behind.streams.length > 0 && <WriteBehindBlock w={behind} restart={restart} />}
        <Block title="Admission" rows={blocks.checks} />
      </CardContent>
      {restart && (
        <RestartRow>
          <RestartAction part="persist" nodeId={health?.node_id} />
          <RestartAction part="db" nodeId={health?.node_id} />
        </RestartRow>
      )}
      <CardFooter bar className="justify-end">
        <span className="mr-auto text-xs text-muted-foreground">
          Statements over the slow-query threshold, from the gateway&apos;s log.
        </span>
        <Link href={SLOW_QUERIES_HREF} className={buttonClasses({ variant: "outline", size: "sm" })}>
          Slow queries
          <ArrowUpRight className="ml-1.5 h-4 w-4" aria-hidden />
        </Link>
      </CardFooter>
    </Card>
  );
}

/**
 * One row per stream the gateway writes to PostgreSQL behind the message path: what is waiting, how
 * far behind, and the state -- `stalled` in the warning colour, with the strip that says the records
 * are safe and what to press.
 */
function WriteBehindBlock({ w, restart }: { w: WriteBehind; restart: boolean }) {
  const stalled = stalledNames(w);
  //the longest-stalled stream speaks for the strip: its wait is the one the operator is asked about
  const worst = w.streams
    .filter((s) => s.state === "stalled")
    .reduce<WriteBehind["streams"][number] | null>((a, s) => (a == null || s.stalledSeconds > a.stalledSeconds ? s : a), null);
  const log =
    w.logBytes != null
      ? ` (${bytes(w.logBytes)}${w.logMaxMb != null ? ` of ${bytes(w.logMaxMb * 1024 * 1024)}` : ""})`
      : "";
  return (
    <div>
      <div className="mb-1.5 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">
        Write-behind · gateway → PostgreSQL
      </div>
      <ul className="divide-y divide-border rounded-md border border-border">
        {w.streams.map((s) => {
          const warn = s.state === "stalled";
          return (
            <li key={s.stream} className={cn("flex flex-wrap items-center gap-x-3 gap-y-1 px-3 py-2", warn && "bg-warning-soft")}>
              <span className="font-mono text-xs font-medium">{s.stream}</span>
              {s.what && <span className="text-xs text-muted-foreground">{s.what}</span>}
              <span className="ml-auto">
                <Badge variant={warn ? "warning" : s.state === "from log" ? "info" : "success"}>{s.state}</Badge>
              </span>
              <span className={cn("basis-full text-sm tabular-nums", warn && "text-warning")}>
                <b>{count(s.depth)}</b> waiting
                {warn ? ` · nothing written for ${secondsLabel(s.stalledSeconds)}` : ""}
                {s.spilled && !warn ? " · writing from the local log" : ""}
                {s.lanes > 1 ? ` · ${s.lanes} lanes` : ""}
              </span>
            </li>
          );
        })}
      </ul>
      <p className="mt-1.5 text-xs text-muted-foreground tabular-nums">
        Oldest write {w.lagSeconds == null ? "not measured" : `${secondsLabel(w.lagSeconds)} behind`} · writing{" "}
        {w.writeRate == null ? "not measured yet" : `${count(Math.round(w.writeRate))} rows/s`}, every stream
      </p>
      {stalled.length > 0 && worst && (
        <div className="mt-2">
          <HealthStrip tone="warning">
            <b>{stalled.join(", ")}</b> {stalled.length === 1 ? "has" : "have"} written nothing for{" "}
            {secondsLabel(worst.stalledSeconds)} while {count(worst.depth)} records wait. They are safe in the
            gateway&apos;s local log{log}
            {w.admitting ? " and nothing is refused yet" : ""}.{" "}
            {restart ? (
              <>
                <b>Restart writers</b> below starts a fresh writer that writes them; no bind drops.
              </>
            ) : (
              "An admin can restart the writers from this card; no bind drops."
            )}
          </HealthStrip>
        </div>
      )}
    </div>
  );
}

function Block({ title, rows }: { title: string; rows: DbRow[] }) {
  const { zone } = useDisplayZone();
  if (!rows.length) {
    return null;
  }
  return (
    <div>
      <div className="mb-1.5 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">{title}</div>
      <dl className="grid gap-x-6 gap-y-1.5 text-sm sm:grid-cols-2">
        {rows.map((r) => (
          <div key={r.key} className="flex items-baseline justify-between gap-3 border-b border-border/60 py-1" title={r.title}>
            <dt className="shrink-0 text-muted-foreground">{r.label}</dt>
            <dd
              className={cn(
                "min-w-0 text-right font-medium tabular-nums [overflow-wrap:anywhere]",
                r.tone === "warning" && "text-warning",
                r.tone === "destructive" && "text-destructive",
                r.tone === "success" && "text-success"
              )}
            >
              {r.at ? formatTimestamp(r.value, zone) : r.value}
            </dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

/**
 * The panel's own pools, re-read with each health poll (the card's clock): the route answers from
 * memory, so following the poll costs a request and no query. Null until the first answer, and kept
 * through a failed one -- the last reading beats a block that flickers out.
 */
function usePools(tick: string | null): PoolsReport | null {
  const [pools, setPools] = useState<PoolsReport | null>(null);
  useEffect(() => {
    let live = true;
    fetch("/api/control/database/pools", { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : null))
      .then((body: PoolsReport | null) => {
        if (live && body?.metrics && body?.config) {
          setPools(body);
        }
      })
      .catch(() => {
        //unreachable: the last reading stands
      });
    return () => {
      live = false;
    };
  }, [tick]);
  return pools;
}
