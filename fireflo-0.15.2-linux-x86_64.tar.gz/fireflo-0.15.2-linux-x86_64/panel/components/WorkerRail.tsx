"use client";
import type { HealthWorker } from "@/lib/health-types";
import { verdictFor, type VerdictTone } from "@/lib/worker-verdict";
import { KIND_NOUN, trafficKey, type Worker, type WorkerType } from "@/lib/worker-types";
import { localeNumber } from "@/lib/format";

/**
 * The instance list beside the cards.
 *
 * <p>Exists because these pages render one tall card per instance and a deployment with six vendors
 * is a page you scroll rather than read. The rail answers "what is here and what is wrong" without
 * scrolling, and opens the one you want.
 *
 * <p><strong>The order is the card order</strong> — the page sorts once, by `SEVERITY` in
 * `lib/worker-verdict.ts`, and hands the same array to both this and the card list. A
 * rail whose third row is the page's first card is worse than no rail — the reader stops trusting
 * either list and checks both.
 *
 * <p>Controlled: the page owns which card is open, because the page also owns the scrolling and the
 * two must not disagree about what "selected" means.
 */
export function WorkerRail({ workers, byFullName, type, selected, onSelect }: {
  workers: Worker[];
  byFullName: Map<string, HealthWorker>;
  type: WorkerType;
  selected: string | null;
  onSelect: (name: string) => void;
}) {
  if (workers.length < 2) {
    //one instance is not a list, and a rail beside a single card is furniture
    return null;
  }

  return (
    <nav aria-label={`${KIND_NOUN[type]} list`} className="rounded-xl border border-border p-2">
      <p className="px-2 pb-1 text-xs uppercase tracking-wide text-muted-foreground">
        {workers.length} {KIND_NOUN[type]}
        {workers.length === 1 ? "" : "s"}
      </p>
      <ul className="space-y-0.5">
        {workers.map((worker) => {
          const live = byFullName.get(trafficKey(worker));
          const verdict = verdictFor(worker, byFullName, type);
          const here = selected === worker.name;
          return (
            <li key={worker.name}>
              <button
                type="button"
                onClick={() => onSelect(worker.name)}
                aria-current={here ? "location" : undefined}
                className={"flex w-full items-center gap-2 rounded border-l-2 px-2 py-1 text-left text-sm "
                  + "hover:bg-accent hover:text-foreground "
                  + (here
                    ? "border-foreground/40 bg-accent/40 text-foreground"
                    : "border-transparent text-muted-foreground")}
              >
                <span
                  className={"size-1.5 shrink-0 rounded-full " + DOT[verdict.tone]}
                  //the badge text, not a colour name: a dot alone is unreadable to a screen reader
                  //and indistinguishable to anyone who cannot separate amber from green
                  aria-label={verdict.label}
                  title={verdict.label}
                />
                <span className="truncate">{worker.name}</span>
                <span className="ml-auto shrink-0 tabular-nums text-muted-foreground">
                  {figureFor(worker, live, verdict.tone)}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

const DOT: Record<VerdictTone, string> = {
  destructive: "bg-destructive",
  warning: "bg-warning",
  success: "bg-success",
  outline: "bg-muted-foreground/40",
};

/**
 * The one number worth the width.
 *
 * <p>Not a fixed column: what matters about an instance depends on what it is doing. A backlog is
 * the only figure anyone acts on, so it wins whenever there is one; otherwise the question is
 * whether anything is connected. Showing all three would need a wider rail, and the width belongs
 * to the cards.
 */
function figureFor(worker: Worker, live: HealthWorker | undefined, tone: VerdictTone): string {
  if (!worker.enabled) {
    return "off";
  }
  if (!live) {
    //stored but not running: a count would imply the gateway has an opinion about it
    return "—";
  }
  const queued = (live.queue_depth ?? 0) + (live.retry_queue_depth ?? 0);
  if (queued > 0) {
    return `${localeNumber(queued)} q`;
  }
  if (live.bound != null) {
    return live.bound === 0 && tone === "destructive" ? "0 binds" : `${live.bound} bound`;
  }
  return "—";
}
