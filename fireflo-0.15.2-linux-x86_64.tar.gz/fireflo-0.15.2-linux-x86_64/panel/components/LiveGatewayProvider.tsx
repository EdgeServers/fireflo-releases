"use client";
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Health } from "@/lib/health-types";
import type { Headline, RuntimeSnapshot } from "@/lib/runtime-metrics";
import { createPollStore, type PollStore } from "@/lib/poll-store";
import { appendTps, type TpsHistory } from "@/lib/tps-history";
import { appendQueue, type QueueHistory } from "@/lib/queue-history";
import { appendRates, EMPTY_RATES, type RateHistory } from "@/lib/live-rates";
import { isSlowAnswer } from "@/lib/gateway-slow";

/**
 * The gateway's live state -- `/ops/health` and `/q/metrics` -- polled once per page.
 *
 * <p>Before this, every `useHealth()` call site ran a poll of its own: the routing and pricing
 * pages asked `/health` two or three times a cycle because a banner, a status line and a card each
 * subscribed independently (CP-P7). Now the dashboard layout mounts this provider once, the hooks
 * subscribe to its stores, and a store polls only while at least one subscriber is mounted and the
 * tab is visible (`lib/poll-scheduler.ts`).
 *
 * <p>The hooks keep their signatures. A component that happens to render outside the provider --
 * nothing does today -- falls back to a module-level pair of stores rather than failing, so the
 * provider is an optimisation, never a precondition.
 */

const HEALTH_REFRESH_MS = 10_000;
const METRICS_REFRESH_MS = 10_000;

/** ~5 minutes of runtime metrics at the poll interval — enough for a sparkline. */
const METRICS_HISTORY = 30;

/** The same interval in seconds, for a card that says how fresh its numbers are. */
export const HEALTH_POLL_SECONDS = HEALTH_REFRESH_MS / 1000;

export interface HealthState {
  health: Health | null;
  error: string;
  /**
   * The last poll failed because the gateway was slow (`code: "SLOW"`, 0.15.1), not gone: `health`
   * is the last good answer, from {@link at}, and `error` says the gateway is slow.
   */
  slow: boolean;
  /** When `health` was read; 0 before the first answer. */
  at: number;
  loading: boolean;
  tpsHistory: TpsHistory;
  queueHistory: QueueHistory;
  /** Per-worker submit rate from counter deltas, for the live traffic chart's MT/s line. */
  rateHistory: RateHistory;
}

export interface HistoryPoint {
  at: number;
  heapUsed: number;
  processCpu: number | null;
  threadsLive: number | null;
  /** requests per second since the previous sample, null on the first one */
  httpRate: number | null;
  workerQueued: number | null;
}

export interface RuntimeState {
  snapshot: RuntimeSnapshot | null;
  history: HistoryPoint[];
  error: string;
  loading: boolean;
  /** The last request counter, which the next `httpRate` is a delta from. */
  previous: { at: number; requests: number } | null;
}

export interface LiveGatewayStores {
  health: PollStore<HealthState>;
  runtime: PollStore<RuntimeState>;
}

const INITIAL_HEALTH: HealthState = {
  health: null,
  error: "",
  slow: false,
  at: 0,
  loading: true,
  tpsHistory: new Map(),
  queueHistory: [],
  rateHistory: EMPTY_RATES,
};

const INITIAL_RUNTIME: RuntimeState = { snapshot: null, history: [], error: "", loading: true, previous: null };

function isVisible(): boolean {
  return typeof document === "undefined" || document.visibilityState === "visible";
}

async function fetchJson(url: string): Promise<{ ok: true; data: unknown } | { ok: false; error: string; slow: boolean }> {
  const res = await fetch(url, { cache: "no-store" });
  const json = await res.json().catch(() => null);
  if (!res.ok) {
    return { ok: false, error: json?.error ?? `Request failed (${res.status})`, slow: isSlowAnswer(res.status, json) };
  }
  return { ok: true, data: json?.data };
}

function createStores(): LiveGatewayStores {
  const visible = isVisible();
  const health = createPollStore<HealthState>({
    initial: INITIAL_HEALTH,
    intervalMs: HEALTH_REFRESH_MS,
    visible,
    //an unreachable gateway is reported as an error but leaves the last snapshot in place. Blanking
    //the page on one failed poll would make a working gateway look like it disappeared
    onError: (state, error) => ({ ...state, error, slow: false, loading: false }),
    poll: async (state) => {
      const result = await fetchJson("/api/control/health");
      if (!result.ok) {
        return { ...state, error: result.error, slow: result.slow, loading: false };
      }
      const snapshot = result.data as Health;
      const now = Date.now();
      //folded here rather than derived by a card, because this is the one place a new snapshot is
      //known to be new. A component cannot tell a fresh poll from a re-render
      return {
        health: snapshot,
        error: "",
        slow: false,
        at: now,
        loading: false,
        tpsHistory: appendTps(state.tpsHistory, snapshot),
        queueHistory: appendQueue(state.queueHistory, snapshot, now),
        rateHistory: appendRates(state.rateHistory, snapshot, now),
      };
    },
  });

  const runtime = createPollStore<RuntimeState>({
    initial: INITIAL_RUNTIME,
    intervalMs: METRICS_REFRESH_MS,
    visible,
    onError: (state, error) => ({ ...state, error, loading: false }),
    poll: async (state) => {
      const result = await fetchJson("/api/control/metrics");
      if (!result.ok) {
        return { ...state, error: result.error, loading: false };
      }
      const next = result.data as RuntimeSnapshot;
      const { history, previous } = appendRuntime(state, next.headline);
      return { snapshot: next, history, error: "", loading: false, previous };
    },
  });

  return { health, runtime };
}

function appendRuntime(state: RuntimeState, headline: Headline): Pick<RuntimeState, "history" | "previous"> {
  const at = Date.now();
  const last = state.previous;
  //null on the first sample, and after a restart: the counter resets, and a negative delta is not a
  //quantity of traffic. Dropping the point is better than drawing a spike that never happened
  let httpRate: number | null = null;
  if (last && headline.httpRequests >= last.requests && at > last.at) {
    httpRate = ((headline.httpRequests - last.requests) * 1000) / (at - last.at);
  }
  return {
    previous: { at, requests: headline.httpRequests },
    history: [
      ...state.history,
      {
        at,
        heapUsed: headline.heapUsed,
        processCpu: headline.processCpu,
        threadsLive: headline.threadsLive,
        httpRate,
        workerQueued: headline.workerQueued,
      },
    ].slice(-METRICS_HISTORY),
  };
}

const Ctx = createContext<LiveGatewayStores | null>(null);

let fallback: LiveGatewayStores | null = null;

/** The stores for a component rendered outside the provider; one pair per browser tab. */
function fallbackStores(): LiveGatewayStores {
  if (!fallback) {
    fallback = createStores();
    if (typeof document !== "undefined") {
      document.addEventListener("visibilitychange", () => {
        fallback?.health.setVisible(isVisible());
        fallback?.runtime.setVisible(isVisible());
      });
    }
  }
  return fallback;
}

export function useLiveGatewayStores(): LiveGatewayStores {
  return useContext(Ctx) ?? fallbackStores();
}

/**
 * Mounted once in the dashboard layout. Owns the stores and the one `visibilitychange` listener
 * that pauses both of them while the tab is hidden and fetches at once when it is shown again.
 */
export function LiveGatewayProvider({ children }: { children: ReactNode }) {
  const [stores] = useState(createStores);

  useEffect(() => {
    const onVisibility = () => {
      const visible = isVisible();
      stores.health.setVisible(visible);
      stores.runtime.setVisible(visible);
    };
    //the stores were created during render, possibly while hidden; say so once
    onVisibility();
    document.addEventListener("visibilitychange", onVisibility);
    return () => document.removeEventListener("visibilitychange", onVisibility);
  }, [stores]);

  return <Ctx.Provider value={stores}>{children}</Ctx.Provider>;
}
