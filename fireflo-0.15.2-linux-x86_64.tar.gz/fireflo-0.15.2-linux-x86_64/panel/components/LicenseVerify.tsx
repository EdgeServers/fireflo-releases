"use client";
import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { DangerAction } from "@/components/DangerAction";
import { GatewayPairingCard } from "@/components/GatewayPairing";
import { licenseScreen, type LicenseState } from "@/lib/license-state";
import { formatTimestamp } from "@/lib/datetime";
import { useDisplayZone } from "@/components/DisplayZoneProvider";

/**
 * Activate this gateway, see what state its licence is in, and move it to another machine.
 *
 * <p>Every decision here belongs to the gateway: it verifies the signature, decides the verdict and
 * refuses a licence issued to another install. This screen carries a key one way and renders a
 * sentence the other. See `lib/license-state.ts` for why there is no check on this side.
 *
 * <h2>A licensed gateway is not asked to activate</h2>
 *
 * <p>This page used to render the activation form on every verdict, so an install that was working
 * looked exactly like one that had never been activated — an operator coming back to a healthy
 * gateway was shown a form asking them to do the thing they had already done. What leads is now
 * decided by `licenseScreen`, in `lib/license-state.ts`, where all seven verdicts are settled in one
 * place and can be tested without a browser.
 *
 * <p>When licensed, everything else folds into ONE collapsed section. Three cards of things an
 * operator does not need would read as unfinished work on a screen whose whole message is "there is
 * nothing to do here".
 *
 * <p>Offline activation stays behind a disclosure rather than becoming a second tab. It is the rarer
 * path by a wide margin, and putting it level with the ordinary one would make every operator choose
 * between two things when only one of them applies.
 *
 * <p>`canChange` is whether the viewer is an admin. An operator sees the state and may ask the
 * licence server again, and in place of the forms reads one sentence saying who can change it --
 * the route would answer their POST 404, and a form that ends in "Not found" explains nothing.
 */
export function LicenseVerify({ canChange = true }: { canChange?: boolean }) {
  const { zone } = useDisplayZone();
  const [state, setState] = useState<LicenseState | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [key, setKey] = useState("");
  const [busy, setBusy] = useState(false);
  const [showOffline, setShowOffline] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showActivate, setShowActivate] = useState(false);
  const [request, setRequest] = useState("");
  const [signed, setSigned] = useState("");

  //the seven verdicts are decided in lib/, not here. See licenseScreen
  const screen = licenseScreen(state);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/control/license", { cache: "no-store" });
      const json = (await res.json()) as { data?: LicenseState; error?: string };
      if (!res.ok || !json.data) {
        setError(json.error ?? "Could not read this gateway's licence.");
        setState(null);
        return;
      }
      setError(null);
      setState(json.data);
    } catch {
      setError("Could not reach the gateway.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  /** One shape for all four actions: post, render the sentence, reload the state. */
  const act = useCallback(
    async (body: Record<string, string>, onData?: (data: unknown) => void) => {
      setBusy(true);
      setError(null);
      setNotice(null);
      try {
        const res = await fetch("/api/control/license", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(body),
        });
        const json = (await res.json()) as { data?: unknown; error?: string };
        if (!res.ok) {
          //the gateway's own sentence, forwarded rather than replaced -- it names which of six
          //things went wrong, which is the only part that tells an operator what to do
          setError(json.error ?? "That did not work.");
          return false;
        }
        onData?.(json.data);
        await load();
        return true;
      } catch {
        setError("Could not reach the gateway.");
        return false;
      } finally {
        setBusy(false);
      }
    },
    [load]
  );

  return (
    <div className="space-y-6">
      <div className="space-y-1">
        <h1 className="text-page max-sm:text-entity">Licence</h1>
        <p className="text-sm text-muted-foreground">
          This gateway keeps sending whatever its licence says. What a lapsed licence stops is
          configuration changes being adopted.
        </p>
      </div>

      {error ? (
        <div className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
          {error}
        </div>
      ) : null}
      {notice ? (
        <div className="rounded-md border border-success/40 bg-success-soft/60 px-3 py-2 text-sm">
          {notice}
        </div>
      ) : null}

      <Card>
        <CardHeader className="flex-row items-center justify-between gap-3 space-y-0">
          <CardTitle>This install</CardTitle>
          {state ? <VerdictBadge state={state} /> : null}
        </CardHeader>
        <CardContent className="space-y-4">
          {loading ? (
            <p className="text-sm text-muted-foreground">Reading…</p>
          ) : state ? (
            <>
              <p className="text-sm">{state.message}</p>
              {state.configuration_changed_while_unlicensed ? (
                <p className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm">
                  This gateway restarted onto configuration that differs from the last copy adopted
                  while licensed. A restart takes up whatever is in the database, so a change made
                  while the licence was lapsed is now in force.
                </p>
              ) : null}
              <dl className="grid gap-3 sm:grid-cols-2">
                <Detail label="Install id" value={state.install_id} mono />
                <Detail label="Licence" value={state.license_id} mono />
                <Detail label="Address as issued" value={state.bound_ip || "—"} mono />
                <Detail label="Tier" value={state.tier} />
                <Detail label="Current until" value={formatTimestamp(state.not_after, zone)} />
                <Detail label="Frozen after" value={formatTimestamp(state.grace_ends_at, zone)} />
                <Detail
                  label="Days before freezing"
                  value={state.configuration_adopted ? String(state.days_until_frozen) : "Frozen"}
                />
                <Detail label="Last refreshed" value={formatTimestamp(state.last_refreshed_at, zone)} />
                <Detail label="Licence server" value={state.server_url} mono />
              </dl>
            </>
          ) : (
            //NOT an empty card. A card with a title and nothing under it reads as "this install has
            //no licence", which is a different and far more alarming claim than "the panel could not
            //reach the gateway to ask". The same rule the health tab follows
            <p className="text-sm text-muted-foreground">
              The panel could not read this gateway&apos;s licence, so nothing below reflects its
              real state. Check that the gateway is running and that the panel&apos;s ops URL points
              at it. Messages are unaffected either way — this page only reports.
            </p>
          )}
        </CardContent>
      </Card>

      {/* the pair this install is: release, schema and API level. Here rather than on the health
          page alone because this is the page an update procedure ends on */}
      <GatewayPairingCard />

      {/* When licensed, everything below folds into one collapsed section. An operator opening this
          page on a working gateway should see "licensed, here are the details" and NOTHING that
          reads as an unfinished task -- which is exactly what an activation form did. */}
      {screen.lead === "details" ? (
        <Card>
          <CardHeader>
            <CardTitle>
              <button
                type="button"
                className="text-left hover:underline"
                onClick={() => setShowAdvanced(!showAdvanced)}
              >
                {showAdvanced ? "▾" : "▸"} Move or change this licence
              </button>
            </CardTitle>
          </CardHeader>
          {showAdvanced ? (
            <CardContent className="space-y-6">
              <TransferSteps state={state} />
              {screen.offerRelease ? <ReleaseAction busy={busy} act={act} state={state} /> : null}
            </CardContent>
          ) : null}
        </Card>
      ) : null}

      {screen.lead === "transfer" ? (
        <Card>
          <CardHeader>
            <CardTitle>Finish moving this licence</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* wrong_install IS a transfer done backwards -- released here without releasing in the
                account, or activated on a rebuilt box while the old binding still stands. The two
                steps in order are more use than either a form or a detail card */}
            <TransferSteps state={state} />
            {screen.offerRelease && canChange ? <ReleaseAction busy={busy} act={act} state={state} /> : null}
          </CardContent>
        </Card>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle>
            {screen.activateIsSecondary ? (
              <button
                type="button"
                className="text-left hover:underline"
                onClick={() => setShowActivate(!showActivate)}
              >
                {showActivate ? "▾" : "▸"} Change the licence key
              </button>
            ) : (
              "Activate"
            )}
          </CardTitle>
        </CardHeader>
        {screen.activateIsSecondary && !showActivate ? null : !canChange ? (
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Only an admin can activate, move or release this gateway&apos;s licence. Ask one of them.
          </p>
          {screen.offerRevalidate ? (
            <Button variant="outline" disabled={busy} onClick={() => void act({ action: "revalidate" })}>
              Check again
            </Button>
          ) : null}
        </CardContent>
        ) : (
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="licence-key">Licence key</Label>
            <Input
              id="licence-key"
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="FFLO-XXXXX-XXXXX-XXXXX-XXXXX"
              autoComplete="off"
              spellCheck={false}
            />
            <p className="text-xs text-muted-foreground">
              From your account on the licence server. The gateway keeps it and renews itself.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              disabled={busy || !key.trim()}
              onClick={() =>
                void act({ action: "activate", licenseKey: key.trim() }, () => {
                  setKey("");
                  setNotice("Activated. The gateway picks this up on its next configuration poll.");
                })
              }
            >
              {busy ? "Working…" : "Activate"}
            </Button>
            {screen.offerRevalidate ? (
              <Button
                variant="outline"
                disabled={busy}
                onClick={() => void act({ action: "revalidate" })}
              >
                Check again
              </Button>
            ) : null}
            {/* offered here too when the licence is broken rather than absent: clearing an
                unreadable one is a legitimate local fix, and burying it under a disclosure that
                only appears when licensed would put it out of reach exactly when it is wanted */}
            {screen.offerRelease && screen.lead === "activate" ? (
              <ReleaseAction busy={busy} act={act} state={state} inline />
            ) : null}
          </div>
        </CardContent>
        )}
      </Card>

      {canChange ? (
      <Card>
        <CardHeader>
          <CardTitle>
            <button
              type="button"
              className="text-left hover:underline"
              onClick={() => setShowOffline(!showOffline)}
            >
              {showOffline ? "▾" : "▸"} This gateway has no internet access
            </button>
          </CardTitle>
        </CardHeader>
        {showOffline ? (
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Generate a request here, carry it to any machine with a browser, and bring the signed
              licence back. Nothing needs to reach the licence server from this gateway.
            </p>

            <div className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                disabled={busy}
                onClick={() =>
                  void act({ action: "offline-request", licenseKey: key.trim() }, (data) => {
                    setRequest((data as { request?: string } | null)?.request ?? "");
                  })
                }
              >
                Generate request
              </Button>
            </div>

            {request ? (
              <div className="space-y-1.5">
                <Label htmlFor="offline-request">Copy this to the licence server</Label>
                <Textarea
                  id="offline-request"
                  readOnly
                  value={request}
                  className="h-24 font-mono"
                />
              </div>
            ) : null}

            <div className="space-y-1.5">
              <Label htmlFor="offline-license">Signed licence from the licence server</Label>
              <Textarea
                id="offline-license"
                value={signed}
                onChange={(e) => setSigned(e.target.value)}
                className="h-24 font-mono"
                spellCheck={false}
              />
            </div>
            <Button
              disabled={busy || !signed.trim()}
              onClick={() =>
                void act({ action: "offline-apply", license: signed.trim() }, () => {
                  setSigned("");
                  setRequest("");
                  setNotice("Applied. The gateway picks this up on its next configuration poll.");
                })
              }
            >
              Apply licence
            </Button>
          </CardContent>
        ) : null}
      </Card>
      ) : null}
    </div>
  );
}

/**
 * The two acts a transfer is made of, in the order that does not hurt.
 *
 * <p>Getting them the wrong way round is the whole hazard. Releasing in the account first costs
 * nothing — this gateway carries on until it is cleared here. Clearing here first freezes this
 * gateway while the licence is still bound to it, so the new machine is refused and the operator is
 * now stuck at both ends.
 */
function TransferSteps({ state }: { state: LicenseState | null }) {
  const deepLink =
    state?.server_url && state?.license_id
      ? `${state.server_url.replace(/\/$/, "")}/licenses/${state.license_id}`
      : null;

  return (
    <div className="space-y-3">
      <p className="text-sm font-medium">Moving this licence to another machine</p>
      <ol className="list-decimal space-y-2 pl-5 text-sm text-muted-foreground">
        <li>
          <span className="text-foreground">In your account</span> — release the licence there. That
          unbinds it from this installation so a new machine can activate it.
        </li>
        <li>
          <span className="text-foreground">Here</span> — clear the licence this machine has cached.
          Until you do, this gateway keeps working from the signed licence already on its disk, and
          keeps adopting configuration changes, until that licence lapses.
        </li>
      </ol>
      <p className="text-sm text-muted-foreground">
        <span className="text-foreground">Do them in that order.</span> Releasing in your account
        first costs you nothing: this gateway carries on exactly as it is until you clear it here.
        Clearing here first freezes this gateway straight away while the licence is still bound to it
        in your account, so the new machine is refused until you go back and release it there too.
      </p>
      {/* the highest-value line on the screen: it makes step 1 one click from step 2, which is what
          actually prevents the half-done transfer */}
      {deepLink ? (
        <a
          className="inline-block text-sm underline underline-offset-4"
          href={deepLink}
          target="_blank"
          rel="noreferrer"
        >
          Open this licence in your account
        </a>
      ) : null}
    </div>
  );
}

/** Clearing the licence this machine holds. Destructive, and it erases the stored key with it. */
function ReleaseAction({
  busy,
  act,
  state,
  inline,
}: {
  busy: boolean;
  act: (body: Record<string, string>, onData?: (data: unknown) => void) => Promise<boolean>;
  state: LicenseState | null;
  inline?: boolean;
}) {
  return (
    <div className={inline ? "" : "space-y-2"}>
      <DangerAction
        label="Release this machine's licence"
        confirmLabel="Yes, clear it from this machine"
        tone="destructive"
        busy={busy}
        //both consequences named, because the second one is the way this strands somebody:
        //clearLicense nulls the stored key too, so re-activating needs the key from the account
        consequence={
          "This machine stops adopting configuration changes immediately. It keeps sending on the "
          + "configuration it already has. The licence key stored here is erased as well, so "
          + "activating this machine again needs the key from your account."
        }
        onConfirm={() => void act({ action: "release" })}
      />
      {!inline && state ? (
        <p className="text-xs text-muted-foreground">
          The install id is kept, so activating this machine again is not treated as a new machine.
        </p>
      ) : null}
    </div>
  );
}

function VerdictBadge({ state }: { state: LicenseState }) {
  if (state.verdict === "active") {
    return <Badge variant="success">Active</Badge>;
  }
  if (state.verdict === "setup" || state.verdict === "grace") {
    //still working, so not the alarming colour. Crying wolf here is how the real freeze gets ignored
    return (
      <Badge variant="warning">
        {state.verdict === "setup" ? "Not activated" : "In grace"}
      </Badge>
    );
  }
  return <Badge variant="destructive">Not licensed</Badge>;
}

function Detail({ label, value, mono }: { label: string; value: string | null; mono?: boolean }) {
  return (
    <div>
      <dt className="text-xs text-muted-foreground">{label}</dt>
      {/* empty as well as null: formatTimestamp answers "" for a date the gateway did not set, and
          a blank line under a label reads as a rendering fault rather than as "not applicable" */}
      <dd className={`text-sm ${mono ? "font-mono break-all" : ""}`}>{value || "—"}</dd>
    </div>
  );
}
