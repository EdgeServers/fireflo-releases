"use client";
import { Check, ChevronDown, Clock } from "lucide-react";
import { Menu } from "@/components/ui/menu";
import { useDisplayZone } from "@/components/DisplayZoneProvider";
import { zoneLabel, type ZoneMode } from "@/lib/datetime";
import { cn } from "@/lib/utils";

/**
 * The display zone chip in the top bar, `IST · Asia/Kolkata ▾`, and the three choices under it.
 *
 * <p>Shared by the operator panel and the portal through {@link TopBar}. The choice is per browser
 * (DisplayZoneProvider); the footer says the one thing it does not change, which is the days.
 */
export function ZoneMenu() {
  const { label, short, mode, setMode, billingZone, browserZone } = useDisplayZone();
  const options: { mode: ZoneMode; title: string; hint: string; zone: string | null }[] = [
    { mode: "platform", title: "Platform zone", hint: "The billing zone. Everyone sees the same times. Default.", zone: billingZone },
    { mode: "browser", title: "My browser", hint: "Your computer's zone. Remembered on this browser.", zone: browserZone },
    { mode: "utc", title: "UTC", hint: "For matching gateway logs and exports.", zone: null },
  ];
  return (
    <Menu
      label={`Display time zone: ${label}`}
      panelClassName="w-[min(330px,calc(100vw-32px))]"
      trigger={
        <span
          className="flex h-9 items-center gap-1.5 rounded-full border border-border px-2.5 text-xs font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          title="Times on this panel are shown in this zone"
          data-testid="zone-chip"
        >
          <Clock className="h-3.5 w-3.5 shrink-0" aria-hidden />
          <span className="md:hidden">{short}</span>
          <span className="hidden whitespace-nowrap md:inline">{label}</span>
          <ChevronDown className="h-3 w-3 shrink-0" aria-hidden />
        </span>
      }
    >
      {options.map((o) => {
        const chosen = o.mode === mode;
        return (
          <button
            key={o.mode}
            type="button"
            role="menuitemradio"
            aria-checked={chosen}
            onClick={() => setMode(o.mode)}
            className={cn(
              "grid w-full grid-cols-[1rem_1fr] items-start gap-2 rounded-md px-2.5 py-2 text-left text-sm transition-colors hover:bg-muted md:py-1.5",
              chosen && "bg-muted/60"
            )}
          >
            <Check className={cn("mt-0.5 h-4 w-4", chosen ? "text-foreground" : "invisible")} aria-hidden />
            <span className="min-w-0">
              <span className="font-medium">{o.title}</span>
              {o.zone && <span className="text-muted-foreground"> ({zoneLabel(o.zone)})</span>}
              <span className="block text-xs text-muted-foreground">{o.hint}</span>
            </span>
          </button>
        );
      })}
      <p className="mt-1 border-t border-border px-2.5 pb-1.5 pt-2 text-xs text-muted-foreground">
        Days on charts, usage and statements always run midnight to midnight in the platform zone ({billingZone}), whatever you choose here.
      </p>
    </Menu>
  );
}
