"use client";
import { useCallback, useEffect, useImperativeHandle, useMemo, useRef, useState, type ReactNode, type Ref } from "react";
import {
  dotCount, dotSpeed, edgeAt, focusSet, hitIndex, hitTest, pointAt, polylineLength,
  type BoxState, type EdgeKind, type MapBox, type MapEdge, type MapLayout, type Rect,
} from "@/lib/connectivity-layout";

/** Which flows are drawn: everything, or one colour. */
export type FlowFilter = "all" | "submits" | "receipts";

/** What the page's zoom buttons and search call. */
export interface CanvasHandle {
  zoomIn(): void;
  zoomOut(): void;
  fit(): void;
  /** Scroll a box into view. */
  reveal(id: string): void;
}

/** A box's rectangle in the wrapper's own pixels: where a DOM popover goes. */
export type Anchor = { left: number; top: number; width: number; height: number };

const MIN_ZOOM = 0.3;
const MAX_ZOOM = 2.5;
const MAX_HEIGHT = 820;
const MIN_HEIGHT = 240;
/** Everything not on a focused box's path is drawn at this opacity. */
const DIM = 0.35;
/** How long the hover strip outlives the pointer leaving its box, so the pointer can reach it. */
const HOVER_GRACE_MS = 220;

interface Palette {
  card: string;
  border: string;
  muted: string;
  foreground: string;
  mutedForeground: string;
  info: string;
  success: string;
  destructive: string;
  warning: string;
  /** A node in alarm: a filled face, the same orange in either theme, with dark text on it. */
  alarm: string;
  alarmForeground: string;
  /** Text on a destructive fill: the database's "refusing N/s" badge. */
  destructiveForeground: string;
  ring: string;
  font: string;
}

/** The theme tokens from `app/globals.css`, read off the document so dark mode follows the toggle. */
function readPalette(): Palette {
  const css = getComputedStyle(document.documentElement);
  const v = (name: string, fallback: string) => css.getPropertyValue(name).trim() || fallback;
  return {
    card: v("--color-card", "#ffffff"),
    border: v("--color-border", "#e2e8f0"),
    muted: v("--color-muted", "#f1f5f9"),
    foreground: v("--color-foreground", "#020617"),
    mutedForeground: v("--color-muted-foreground", "#475569"),
    info: v("--color-info", "#0369a1"),
    success: v("--color-success", "#16a34a"),
    destructive: v("--color-destructive", "#dc2626"),
    warning: v("--color-warning", "#b45309"),
    //the theme's warning is a dark amber in light mode, too dark to carry dark text: a filled face
    //wants a bright orange whichever theme is on
    alarm: v("--color-alarm", "#f97316"),
    alarmForeground: v("--color-alarm-foreground", "#1c1917"),
    destructiveForeground: v("--color-destructive-foreground", "#ffffff"),
    ring: v("--color-ring", "#0f172a"),
    font: getComputedStyle(document.body).fontFamily || "ui-sans-serif, system-ui, sans-serif",
  };
}

/** A persist edge is the database's state: blue while OK, orange DEGRADED, red refusing. */
function edgeColour(e: Pick<MapEdge, "kind" | "state">, p: Palette): string {
  if (e.kind === "persist") {
    return e.state === "warn" ? p.warning : e.state === "refusing" || e.state === "down" ? p.destructive : p.info;
  }
  return e.kind === "receipt" ? p.success : e.kind === "refused" ? p.destructive : p.info;
}

/** Dashed: refused, and the writes into a database that is refusing. */
function dashed(e: Pick<MapEdge, "kind" | "state">): boolean {
  return e.kind === "refused" || (e.kind === "persist" && (e.state === "refusing" || e.state === "down"));
}

function shows(filter: FlowFilter, kind: EdgeKind): boolean {
  return filter === "all" || (filter === "receipts" ? kind === "receipt" : kind !== "receipt");
}

function usePalette(): Palette | null {
  const [palette, setPalette] = useState<Palette | null>(null);
  useEffect(() => {
    const read = () => setPalette(readPalette());
    read();
    //the theme toggle flips `.dark` on <html>; the system setting can change underneath it too
    const observer = new MutationObserver(read);
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ["class", "style"] });
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    media.addEventListener("change", read);
    return () => {
      observer.disconnect();
      media.removeEventListener("change", read);
    };
  }, []);
  return palette;
}

function useReducedMotion(): boolean {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const read = () => setReduced(media.matches);
    read();
    media.addEventListener("change", read);
    return () => media.removeEventListener("change", read);
  }, []);
  return reduced;
}

/** Text cut to fit `max` pixels, with an ellipsis; measured once per layout, at zoom 1. */
function fitText(ctx: CanvasRenderingContext2D, text: string, max: number): string {
  if (ctx.measureText(text).width <= max) {
    return text;
  }
  let lo = 0;
  let hi = text.length;
  while (lo < hi) {
    const mid = Math.ceil((lo + hi) / 2);
    if (ctx.measureText(`${text.slice(0, mid)}…`).width <= max) {
      lo = mid;
    } else {
      hi = mid - 1;
    }
  }
  return `${text.slice(0, lo)}…`;
}

/** A box's state as a screen reader hears it after the box. */
const STATE_WORD: Record<BoxState, string> = { ok: "ok", warn: "warning", alarm: "alarm", refusing: "refusing", down: "down" };

const TITLE = (font: string) => `600 11.5px ${font}`;
const SUB = (font: string) => `10.5px ${font}`;
const BAND = (font: string) => `600 10px ${font}`;
const BADGE = (font: string) => `700 10px ${font}`;
const LABEL = (font: string) => `600 10px ${font}`;

function roundRect(ctx: CanvasRenderingContext2D, r: Rect, radius: number) {
  ctx.beginPath();
  ctx.roundRect(r.x, r.y, r.w, r.h, radius);
}

/**
 * The Connectivity map on one `<canvas>`.
 *
 * <p>Two layers. The static one -- tier bands, edges with their arrowheads, boxes and their text --
 * is drawn into an offscreen canvas only when the layout, the viewport, the theme, the flow filter or
 * the focus changes. Over it a `requestAnimationFrame` loop draws the dots: at most five per edge,
 * moving at a speed set by the edge's rate, still on a link that moves nothing, and still altogether
 * under `prefers-reduced-motion` or while paused. The loop never touches React state, so a busy map
 * costs one `drawImage` and a hundred arcs a frame and no renders.
 *
 * <p>Zoom and the vertical pan are one transform; sideways the map is an ordinary horizontal
 * scroller (the canvas sticks to its left edge and draws whatever is scrolled into view), so a map
 * wider than the screen scrolls the way a wide table does. Drag pans both ways; ctrl + wheel zooms
 * at the pointer.
 *
 * <p>Hit-testing is a grid over the layout's own rectangles (`hitIndex`), so a box is clicked exactly
 * where it is drawn. Click focuses a box -- its path at full opacity, the rest at 35 % -- or, on a
 * group or a "+n" chip, opens it. Keyboard: Tab and Shift+Tab move between boxes and leave the map
 * past either end; Enter opens the focused box's menu, Space opens a group; Escape clears. A visually
 * hidden list mirrors the boxes for screen readers.
 */
export function ConnectivityCanvas({
  layout,
  filter,
  paused,
  focusId,
  onFocus,
  onActivate,
  renderBoxUi,
  handle,
  label,
  framed = true,
}: {
  layout: MapLayout;
  filter: FlowFilter;
  paused: boolean;
  focusId: string | null;
  onFocus: (id: string | null) => void;
  /** A click on a group, a chip or "+n ports": open it, or page it. */
  onActivate: (box: MapBox) => void;
  /** The hover strip and the menu, positioned over a box. `menu` is the open menu's box, if any. */
  renderBoxUi: (ui: {
    box: MapBox;
    anchor: Anchor;
    menuOpen: boolean;
    openMenu: () => void;
    close: () => void;
    keep: (on: boolean) => void;
    bounds: { width: number };
  }) => ReactNode;
  handle?: Ref<CanvasHandle>;
  label: string;
  /** Its own border and rounded corners; off inside a card, whose edge is the map's. */
  framed?: boolean;
}) {
  const wrap = useRef<HTMLDivElement>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const layer = useRef<HTMLCanvasElement | null>(null);
  const palette = usePalette();
  const reduced = useReducedMotion();
  const [viewW, setViewW] = useState(0);
  const [zoom, setZoom] = useState<number | null>(null);
  const [scrollX, setScrollX] = useState(0);
  const [ty, setTy] = useState(0);
  const [hoverId, setHoverId] = useState<string | null>(null);
  const [menuId, setMenuId] = useState<string | null>(null);
  //the edge under the pointer, and where its tooltip goes in the wrapper's pixels
  const [edgeTip, setEdgeTip] = useState<{ id: string; left: number; top: number } | null>(null);
  const hoverTimer = useRef<number | null>(null);
  const drag = useRef<{ x: number; y: number; left: number; ty: number; moved: boolean } | null>(null);

  const z = zoom ?? 1;
  const contentW = layout.width * z;
  const contentH = layout.height * z;
  const height = Math.round(Math.max(MIN_HEIGHT, Math.min(MAX_HEIGHT, contentH)));
  //a map narrower than the view is centred in it
  const ox = Math.max(0, (viewW - contentW) / 2);
  const minTy = Math.min(0, height - contentH);
  const clampedTy = Math.max(minTy, Math.min(0, ty));

  const index = useMemo(() => hitIndex(layout.boxes), [layout]);
  const byId = useMemo(() => new Map(layout.boxes.map((b) => [b.id, b] as const)), [layout]);
  const focus = useMemo(() => (focusId && byId.has(focusId) ? focusSet(layout, focusId) : null), [layout, focusId, byId]);
  //Tab order: tier by tier, left to right; frames before their members
  const order = useMemo(
    () => [...layout.boxes].sort((a, b) => a.rect.y - b.rect.y || a.rect.x - b.rect.x || Number(!!b.frame) - Number(!!a.frame)),
    [layout]
  );

  //labels cut to their box once per layout, not on every frame
  const labels = useMemo(() => {
    const out = new Map<string, [string, string]>();
    if (!palette || typeof document === "undefined") {
      return out;
    }
    const ctx = document.createElement("canvas").getContext("2d");
    if (!ctx) {
      return out;
    }
    for (const b of layout.boxes) {
      const max = b.frame ? b.rect.w - 20 : b.rect.w - 16;
      ctx.font = TITLE(palette.font);
      const title = fitText(ctx, b.lines[0], max);
      ctx.font = SUB(palette.font);
      out.set(b.id, [title, fitText(ctx, b.lines[1], max)]);
    }
    return out;
  }, [layout, palette]);

  //the viewport's width, followed
  useEffect(() => {
    const el = scroller.current;
    if (!el) {
      return;
    }
    const observer = new ResizeObserver(() => setViewW(el.clientWidth));
    observer.observe(el);
    setViewW(el.clientWidth);
    return () => observer.disconnect();
  }, []);

  //the first zoom fits the width, but never below 0.6 -- small text is worse than a scrollbar --
  //and a map still wider than the view opens on its middle, where the rows are centred
  useEffect(() => {
    if (zoom == null && viewW > 0 && layout.width > 0) {
      const first = Math.max(0.6, Math.min(1, viewW / layout.width));
      setZoom(first);
      requestAnimationFrame(() => {
        const el = scroller.current;
        if (el) {
          el.scrollLeft = Math.max(0, (layout.width * first - viewW) / 2);
          setScrollX(el.scrollLeft);
        }
      });
    }
  }, [zoom, viewW, layout.width]);

  const toScreen = useCallback((r: Rect): Anchor => ({
    left: r.x * z - scrollX + ox,
    top: r.y * z + clampedTy,
    width: r.w * z,
    height: r.h * z,
  }), [z, scrollX, ox, clampedTy]);

  const toWorld = (clientX: number, clientY: number): [number, number] => {
    const rect = canvas.current!.getBoundingClientRect();
    return [(clientX - rect.left + scrollX - ox) / z, (clientY - rect.top - clampedTy) / z];
  };

  const zoomTo = useCallback((next: number, at?: [number, number]) => {
    const el = scroller.current;
    const clamped = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, next));
    //keep the point under the pointer (or the view's centre) where it is
    const px = at ? at[0] : (el?.clientWidth ?? 0) / 2;
    const worldX = (px + (el?.scrollLeft ?? 0) - ox) / z;
    setZoom(clamped);
    requestAnimationFrame(() => {
      if (el) {
        el.scrollLeft = Math.max(0, worldX * clamped - px);
        setScrollX(el.scrollLeft);
      }
    });
  }, [ox, z]);

  const reveal = useCallback((id: string) => {
    const b = byId.get(id);
    const el = scroller.current;
    if (!b || !el) {
      return;
    }
    const left = b.rect.x * z;
    if (left < el.scrollLeft || left + b.rect.w * z > el.scrollLeft + el.clientWidth) {
      el.scrollLeft = Math.max(0, left - el.clientWidth / 2 + (b.rect.w * z) / 2);
      setScrollX(el.scrollLeft);
    }
    const top = b.rect.y * z + clampedTy;
    if (top < 0 || top + b.rect.h * z > height) {
      setTy(Math.max(minTy, Math.min(0, height / 2 - b.rect.y * z)));
    }
  }, [byId, z, clampedTy, height, minTy]);

  useImperativeHandle(handle, () => ({
    zoomIn: () => zoomTo(z * 1.2),
    zoomOut: () => zoomTo(z / 1.2),
    fit: () => {
      const fitted = Math.min(viewW / layout.width, MAX_HEIGHT / layout.height, 1.5);
      setZoom(Math.max(MIN_ZOOM, fitted));
      setTy(0);
      if (scroller.current) {
        scroller.current.scrollLeft = 0;
      }
      setScrollX(0);
    },
    reveal,
  }), [zoomTo, z, viewW, layout.width, layout.height, reveal]);

  //─── the static layer ───
  useEffect(() => {
    const el = canvas.current;
    if (!el || !palette || viewW <= 0) {
      return;
    }
    const dpr = window.devicePixelRatio || 1;
    const w = Math.round(viewW * dpr);
    const h = Math.round(height * dpr);
    const off = layer.current ?? document.createElement("canvas");
    layer.current = off;
    off.width = w;
    off.height = h;
    if (el.width !== w || el.height !== h) {
      el.width = w;
      el.height = h;
    }
    const ctx = off.getContext("2d");
    if (!ctx) {
      return;
    }
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, w, h);
    ctx.setTransform(dpr * z, 0, 0, dpr * z, dpr * (ox - scrollX), dpr * clampedTy);
    //what is in view, in content coordinates, for culling and for the sticky band labels
    const left = (scrollX - ox) / z;
    const right = left + viewW / z;
    const p = palette;

    for (const band of layout.bands) {
      ctx.setLineDash([6, 5]);
      ctx.strokeStyle = p.border;
      ctx.lineWidth = 1;
      roundRect(ctx, band.rect, 10);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.font = BAND(p.font);
      ctx.letterSpacing = "0.8px";
      ctx.fillStyle = p.mutedForeground;
      ctx.textAlign = "right";
      //the label rides the visible right edge when the band is wider than the view
      ctx.fillText(band.label.toUpperCase(), Math.min(band.rect.x + band.rect.w - 10, right - 12), band.rect.y + 15);
      ctx.letterSpacing = "0px";
      ctx.textAlign = "left";
    }

    const lit = (id: string) => !focus || focus.boxes.has(id);
    for (const e of layout.edges) {
      if (!shows(filter, e.kind)) {
        continue;
      }
      const xs = e.points.map(([x]) => x);
      if (Math.max(...xs) < left - 20 || Math.min(...xs) > right + 20) {
        continue;
      }
      ctx.globalAlpha = !focus || focus.edges.has(e.id) ? 1 : DIM;
      drawEdge(ctx, e, edgeColour(e, p));
    }
    ctx.globalAlpha = 1;

    for (const b of layout.boxes) {
      if (b.rect.x + b.rect.w < left - 4 || b.rect.x > right + 4) {
        continue;
      }
      ctx.globalAlpha = lit(b.id) ? 1 : DIM;
      const [title, sub] = labels.get(b.id) ?? b.lines;
      const stroke = b.state === "down" || b.state === "refusing"
        ? p.destructive
        : b.state === "warn" ? p.warning : b.state === "alarm" ? p.alarm : p.border;
      if (b.frame) {
        ctx.globalAlpha *= 0.55;
        ctx.fillStyle = p.muted;
        roundRect(ctx, b.rect, 6);
        ctx.fill();
        ctx.globalAlpha = lit(b.id) ? 1 : DIM;
        //a route group's frame takes its worst member's colour; a client group's is always plain
        ctx.strokeStyle = stroke;
        ctx.lineWidth = b.state === "ok" ? 0.9 : 1.4;
        ctx.stroke();
        ctx.fillStyle = p.foreground;
        ctx.font = TITLE(p.font);
        ctx.fillText(title, b.rect.x + 10, b.rect.y + 16);
        ctx.fillStyle = p.mutedForeground;
        ctx.font = SUB(p.font);
        const titleW = ctx.measureText(title).width;
        if (titleW + 30 < b.rect.w - 120) {
          ctx.textAlign = "right";
          ctx.fillText(sub, b.rect.x + b.rect.w - 10, b.rect.y + 16);
          ctx.textAlign = "left";
        }
      } else {
        //alarm is the whole face, not only the outline: a node whose queue is climbing must be seen
        //from across the room; a refusing database is the same face in a red outline
        const alarm = b.state === "alarm" || b.state === "refusing";
        ctx.fillStyle = alarm ? p.alarm : p.card;
        roundRect(ctx, b.rect, 3);
        ctx.fill();
        ctx.strokeStyle = stroke;
        ctx.lineWidth = b.state === "ok" ? 0.9 : b.state === "refusing" ? 2 : 1.4;
        ctx.setLineDash(b.kind === "clientMore" || b.kind === "portsMore" ? [4, 3] : []);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = alarm ? p.alarmForeground : p.foreground;
        ctx.font = TITLE(p.font);
        ctx.fillText(title, b.rect.x + 8, b.rect.y + 18);
        ctx.fillStyle = alarm
          ? p.alarmForeground
          : b.state === "down" ? p.destructive : b.state === "warn" ? p.warning : p.mutedForeground;
        ctx.font = SUB(p.font);
        ctx.fillText(sub, b.rect.x + 8, b.rect.y + 34);
      }
      if (b.badge) {
        //a red pill riding the box's top edge, right-aligned
        ctx.font = BADGE(p.font);
        const w = ctx.measureText(b.badge).width + 14;
        const r = { x: b.rect.x + b.rect.w - w - 8, y: b.rect.y - 8, w, h: 16 };
        ctx.fillStyle = p.destructive;
        roundRect(ctx, r, 8);
        ctx.fill();
        ctx.fillStyle = p.destructiveForeground;
        ctx.textAlign = "center";
        ctx.fillText(b.badge, r.x + w / 2, r.y + 11.5);
        ctx.textAlign = "left";
      }
      if (b.id === focusId) {
        ctx.globalAlpha = 1;
        ctx.strokeStyle = p.ring;
        ctx.lineWidth = 1.6;
        roundRect(ctx, { x: b.rect.x - 3, y: b.rect.y - 3, w: b.rect.w + 6, h: b.rect.h + 6 }, b.frame ? 8 : 5);
        ctx.stroke();
      }
    }

    //an edge's label -- a port's refusals -- as a pill on its first leg, just above the box it leaves
    for (const e of layout.edges) {
      if (!e.label || !shows(filter, e.kind) || e.points.length < 2) {
        continue;
      }
      const [x, y0] = e.points[0];
      if (x < left - 300 || x > right + 300) {
        continue;
      }
      ctx.globalAlpha = !focus || focus.edges.has(e.id) ? 1 : DIM;
      ctx.font = LABEL(p.font);
      const w = ctx.measureText(e.label).width + 14;
      const r = { x: x - w / 2, y: y0 - 22, w, h: 15 };
      ctx.fillStyle = p.card;
      roundRect(ctx, r, 7);
      ctx.fill();
      ctx.strokeStyle = edgeColour(e, p);
      ctx.lineWidth = 0.8;
      ctx.stroke();
      ctx.fillStyle = edgeColour(e, p);
      ctx.textAlign = "center";
      ctx.fillText(e.label, x, r.y + 11);
      ctx.textAlign = "left";
    }
    ctx.globalAlpha = 1;
  }, [layout, labels, palette, viewW, height, z, ox, scrollX, clampedTy, filter, focus, focusId]);

  //─── the dot loop, over the static layer ───
  useEffect(() => {
    const el = canvas.current;
    const off = layer.current;
    if (!el || !off || !palette || viewW <= 0) {
      return;
    }
    const ctx = el.getContext("2d");
    if (!ctx) {
      return;
    }
    const dpr = window.devicePixelRatio || 1;
    const runs = layout.edges
      .filter((e) => shows(filter, e.kind))
      .map((e) => ({
        e,
        length: polylineLength(e.points),
        n: dotCount(e.rate),
        speed: dotSpeed(e.rate),
        colour: edgeColour(e, palette),
        alpha: !focus || focus.edges.has(e.id) ? 1 : DIM,
        radius: 1.8 + e.width * 0.35,
      }));
    const still = paused || reduced;
    const frame = (t: number) => {
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, el.width, el.height);
      ctx.drawImage(off, 0, 0);
      ctx.setTransform(dpr * z, 0, 0, dpr * z, dpr * (ox - scrollX), dpr * clampedTy);
      for (const r of runs) {
        if (r.length <= 0) {
          continue;
        }
        ctx.globalAlpha = r.alpha;
        ctx.fillStyle = r.colour;
        //a still dot sits a third of the way along, where it reads as "on this link" rather than on a box
        const offset = still || r.speed === 0 ? r.length / 3 : ((t / 1000) * r.speed) % r.length;
        for (let i = 0; i < r.n; i++) {
          const [x, y] = pointAt(r.e.points, (offset + (i * r.length) / r.n) % r.length);
          ctx.beginPath();
          ctx.arc(x, y, r.radius, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      ctx.globalAlpha = 1;
    };
    const moving = !still && runs.some((r) => r.speed > 0);
    if (!moving) {
      frame(0);
      return;
    }
    let raf = requestAnimationFrame(function tick(t) {
      frame(t);
      raf = requestAnimationFrame(tick);
    });
    return () => cancelAnimationFrame(raf);
    //the static layer is redrawn by the effect above with the same dependencies, so this one
    //restarts after it and always composites the fresh layer
  }, [layout, labels, palette, viewW, height, z, ox, scrollX, clampedTy, filter, focus, focusId, paused, reduced]);

  //─── pointer and keyboard ───
  const setHover = (id: string | null) => {
    if (hoverTimer.current != null) {
      window.clearTimeout(hoverTimer.current);
      hoverTimer.current = null;
    }
    if (id) {
      setHoverId(id);
    } else {
      hoverTimer.current = window.setTimeout(() => setHoverId(null), HOVER_GRACE_MS);
    }
  };

  const onPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (e.button !== 0) {
      return;
    }
    drag.current = { x: e.clientX, y: e.clientY, left: scroller.current?.scrollLeft ?? 0, ty: clampedTy, moved: false };
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const onPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const d = drag.current;
    if (d) {
      const dx = e.clientX - d.x;
      const dy = e.clientY - d.y;
      if (Math.abs(dx) + Math.abs(dy) > 4) {
        d.moved = true;
      }
      if (d.moved && scroller.current) {
        scroller.current.scrollLeft = Math.max(0, d.left - dx);
        setScrollX(scroller.current.scrollLeft);
        setTy(Math.max(minTy, Math.min(0, d.ty + dy)));
        return;
      }
    }
    const [x, y] = toWorld(e.clientX, e.clientY);
    const hit = hitTest(index, x, y);
    setHover(hit?.id ?? null);
    //off every box, an edge under the pointer shows its rate and counts
    const line = hit || d ? null : edgeAt(layout.edges, x, y, 6 / z, (edge) => shows(filter, edge.kind));
    const at = wrap.current?.getBoundingClientRect();
    setEdgeTip(line && at ? { id: line.id, left: e.clientX - at.left, top: e.clientY - at.top } : null);
    e.currentTarget.style.cursor = hit ? "pointer" : d ? "grabbing" : "grab";
  };

  const onPointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const d = drag.current;
    drag.current = null;
    if (!d || d.moved) {
      return;
    }
    const [x, y] = toWorld(e.clientX, e.clientY);
    const hit = hitTest(index, x, y);
    setMenuId(null);
    if (!hit) {
      onFocus(null);
      return;
    }
    if (hit.kind === "clientGroup" || hit.kind === "clientMore" || hit.kind === "portsMore" || hit.kind === "vendorGroup") {
      onActivate(hit);
      return;
    }
    onFocus(hit.id === focusId ? null : hit.id);
  };

  const onWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    //the page scrolls as usual; ctrl (or a pinch, which arrives as ctrl + wheel) zooms
    if (!e.ctrlKey) {
      return;
    }
    e.preventDefault();
    const rect = canvas.current!.getBoundingClientRect();
    zoomTo(z * (e.deltaY < 0 ? 1.1 : 1 / 1.1), [e.clientX - rect.left, e.clientY - rect.top]);
  };

  //React's wheel listener is passive; ctrl + wheel must be able to stop the browser's own zoom
  useEffect(() => {
    const el = canvas.current;
    if (!el) {
      return;
    }
    const stop = (e: WheelEvent) => {
      if (e.ctrlKey) {
        e.preventDefault();
      }
    };
    el.addEventListener("wheel", stop, { passive: false });
    return () => el.removeEventListener("wheel", stop);
  }, []);

  const onKeyDown = (e: React.KeyboardEvent<HTMLCanvasElement>) => {
    if (e.key === "Tab") {
      const at = focusId ? order.findIndex((b) => b.id === focusId) : -1;
      const next = at + (e.shiftKey ? -1 : 1);
      //past either end the Tab leaves the map, as it would any other control
      if ((at === -1 && e.shiftKey) || next < 0 || next >= order.length) {
        onFocus(null);
        return;
      }
      e.preventDefault();
      const id = order[at === -1 ? 0 : next].id;
      onFocus(id);
      setMenuId(null);
      reveal(id);
      return;
    }
    if (e.key === "Escape") {
      setMenuId(null);
      onFocus(null);
      return;
    }
    const box = focusId ? byId.get(focusId) : undefined;
    if (!box) {
      return;
    }
    if (e.key === "Enter") {
      e.preventDefault();
      setMenuId(box.id);
    } else if (e.key === " ") {
      e.preventDefault();
      if (box.kind === "clientGroup" || box.kind === "clientMore" || box.kind === "portsMore" || box.kind === "vendorGroup") {
        onActivate(box);
      }
    }
  };

  //a menu or hover whose box went away with a new layout closes
  const uiId = menuId ?? hoverId ?? focusId;
  //only over a box that is in view: a strip for a box scrolled away would float outside the map
  const inView = (b: MapBox | undefined) => {
    if (!b) {
      return undefined;
    }
    const a = toScreen(b.rect);
    return a.left + a.width > 0 && a.left < viewW && a.top + a.height > 0 && a.top < height ? b : undefined;
  };
  const uiBox = inView(uiId ? byId.get(uiId) : undefined);
  const tipBox = inView(hoverId && !menuId ? byId.get(hoverId) : undefined);

  return (
    <div ref={wrap} className="relative">
      <div
        ref={scroller}
        className={framed ? "overflow-x-auto overflow-y-hidden rounded-lg border border-border bg-card" : "overflow-x-auto overflow-y-hidden rounded-b-xl bg-card"}
        onScroll={(e) => setScrollX(e.currentTarget.scrollLeft)}
      >
        <div style={{ width: Math.max(contentW, viewW), height }}>
          <canvas
            ref={canvas}
            role="img"
            aria-label={label}
            tabIndex={0}
            className="sticky left-0 block touch-none outline-none focus-visible:ring-2 focus-visible:ring-ring"
            style={{ width: viewW || "100%", height }}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerLeave={() => {
              setHover(null);
              setEdgeTip(null);
            }}
            onWheel={onWheel}
            onKeyDown={onKeyDown}
          />
        </div>
      </div>

      {tipBox && <Tooltip box={tipBox} note={layout.countsNote} anchor={toScreen(tipBox.rect)} bounds={{ width: viewW, height }} />}
      {!tipBox && !menuId && edgeTip && (() => {
        const line = layout.edges.find((x) => x.id === edgeTip.id);
        return line ? <EdgeTooltip edge={line} note={layout.countsNote} at={edgeTip} bounds={{ width: viewW, height }} /> : null;
      })()}

      {uiBox && renderBoxUi({
        box: uiBox,
        anchor: toScreen(uiBox.rect),
        menuOpen: menuId === uiBox.id,
        openMenu: () => setMenuId(uiBox.id),
        close: () => {
          setMenuId(null);
          canvas.current?.focus();
        },
        keep: (on) => setHover(on ? uiBox.id : null),
        bounds: { width: viewW },
      })}

      {/* the boxes as a list, for a screen reader: the canvas itself is one image to it */}
      <ul className="sr-only">
        {order.map((b) => (
          <li key={b.id}>
            <button
              type="button"
              onClick={() => {
                onFocus(b.id);
                setMenuId(b.id);
                reveal(b.id);
              }}
            >
              {b.speech ?? b.lines.join(", ")}
              {b.mt != null || b.dlr != null ? ` (counts ${layout.countsLabel})` : ""}
              {b.state !== "ok" ? `, ${STATE_WORD[b.state]}` : ""}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function drawEdge(ctx: CanvasRenderingContext2D, e: MapEdge, colour: string) {
  const pts = e.points;
  if (pts.length < 2) {
    return;
  }
  ctx.strokeStyle = colour;
  ctx.fillStyle = colour;
  ctx.lineWidth = e.width;
  ctx.lineJoin = "round";
  ctx.setLineDash(dashed(e) ? [4, 3] : []);
  //stop the line short of the arrowhead so a wide edge does not blunt it
  const head = 4 + e.width;
  const [ax, ay] = pts[pts.length - 2];
  const [bx, by] = pts[pts.length - 1];
  const len = Math.hypot(bx - ax, by - ay) || 1;
  const ux = (bx - ax) / len;
  const uy = (by - ay) / len;
  ctx.beginPath();
  ctx.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length - 1; i++) {
    ctx.lineTo(pts[i][0], pts[i][1]);
  }
  ctx.lineTo(bx - ux * head * 0.8, by - uy * head * 0.8);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.beginPath();
  ctx.moveTo(bx, by);
  ctx.lineTo(bx - ux * head - uy * head * 0.6, by - uy * head + ux * head * 0.6);
  ctx.lineTo(bx - ux * head + uy * head * 0.6, by - uy * head - ux * head * 0.6);
  ctx.closePath();
  ctx.fill();
}

/** A box's numbers, under it; above it when there is no room below. */
function Tooltip({ box, note, anchor, bounds }: { box: MapBox; note: string | null; anchor: Anchor; bounds: { width: number; height: number } }) {
  const below = anchor.top + anchor.height + 6;
  const style: React.CSSProperties = {
    left: Math.max(4, Math.min(anchor.left, bounds.width - (box.kind === "database" ? 294 : 230))),
    ...(below + 120 < bounds.height ? { top: below } : { bottom: bounds.height - anchor.top + 6 }),
  };
  return (
    <div role="tooltip" className={`pointer-events-none absolute z-20 ${box.kind === "database" ? "w-72" : "w-56"} rounded-md border border-border bg-popover px-3 py-2 text-xs text-popover-foreground shadow-lg`} style={style}>
      <p className="mb-1 truncate font-semibold">{box.lines[0].replace(/^[▸▾] /, "")}</p>
      <dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-0.5">
        {box.facts.map(([k, v], i) => (
          <div key={`${k}-${i}`} className="contents">
            <dt className="text-muted-foreground">{k}</dt>
            <dd className="truncate text-right tabular-nums">{v}</dd>
          </div>
        ))}
      </dl>
      {note && (box.mt != null || box.dlr != null) && <p className="mt-1.5 text-muted-foreground">{note}</p>}
    </div>
  );
}

/** One edge's rate and the counts of the flow it draws, beside the pointer. */
function EdgeTooltip({ edge, note, at, bounds }: { edge: MapEdge; note: string | null; at: { left: number; top: number }; bounds: { width: number; height: number } }) {
  const style: React.CSSProperties = {
    left: Math.max(4, Math.min(at.left + 12, bounds.width - 230)),
    ...(at.top + 110 < bounds.height ? { top: at.top + 14 } : { bottom: bounds.height - at.top + 10 }),
  };
  return (
    <div role="tooltip" className="pointer-events-none absolute z-20 w-56 rounded-md border border-border bg-popover px-3 py-2 text-xs text-popover-foreground shadow-lg" style={style}>
      <p className="mb-1 truncate font-semibold">{edge.title}</p>
      <dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-0.5">
        {edge.facts.map(([k, v], i) => (
          <div key={`${k}-${i}`} className="contents">
            <dt className="text-muted-foreground">{k}</dt>
            <dd className="truncate text-right tabular-nums">{v}</dd>
          </div>
        ))}
      </dl>
      {note && (edge.mt != null || edge.dlr != null) && <p className="mt-1.5 text-muted-foreground">{note}</p>}
    </div>
  );
}
