"use client";
import { useRef, useState } from "react";
import { usePoll } from "./usePoll";
import { counterTiles, pushQueue, type CounterFigure } from "@/lib/connectivity-counters";
import type { LiveCountersSum } from "@/lib/gateway-live-counters";
import { COUNTERS_POLL_MS, countersInterval, isSlowAnswer, shouldRead } from "@/lib/gateway-slow";
import { noteSource } from "@/lib/page-sources";

/** A failed read keeps the last answer this long (faded) before the columns go. A slow gateway's does not count. */
const STALE_MS = 10_000;

/** The counters as last read: absent (204), an answer, or a failure that keeps the last. */
export interface LiveCountersState {
  /** False once the gateway said it has no live counters; null until the first answer. */
  available: boolean | null;
  data: LiveCountersSum | null;
  /** The queue's last readings, newest last, for the rising rule. */
  queue: number[];
  /** When `data` was read. */
  at: number;
  error: string;
  /**
   * The last read found the gateway slow (`code: "SLOW"`, 0.15.1): `data` is the last good answer,
   * kept however old, and the page shows "gateway slow, showing data from HH:MM:SS" rather than an
   * error.
   */
  slow: boolean;
  /** The poll's interval now: 2 s, or 5 s while the gateway is slow. */
  intervalMs: number;
}

const EMPTY: LiveCountersState = { available: null, data: null, queue: [], at: 0, error: "", slow: false, intervalMs: COUNTERS_POLL_MS };

/**
 * The gateway's live counters (`/api/control/connectivity/counters`), read every 2 s on their own
 * timer while the page is not paused. A 204 (a gateway without `live_counters`) stops the reads.
 *
 * <p>A slow gateway (a 502 with `code: "SLOW"`) keeps the last answer, says so, and is asked again
 * on the next tick; while it is slow the poll backs off to 5 s, and an answer under 1 s brings it
 * back to 2 s (`countersInterval`). A tick is skipped while the last read is still in flight.
 */
export function useLiveCounters(paused: boolean): LiveCountersState {
  const [state, setState] = useState<LiveCountersState>(EMPTY);
  const reading = useRef({ inFlight: false, lastFinishedAt: 0 });
  const load = async () => {
    const started = Date.now();
    if (!shouldRead({ ...reading.current, now: started, intervalMs: state.intervalMs })) {
      return;
    }
    reading.current.inFlight = true;
    try {
      const res = await fetch("/api/control/connectivity/counters", { cache: "no-store" }).catch(() => null);
      noteSource("connectivity-counters", res);
      const now = Date.now();
      if (res?.status === 204) {
        setState({ ...EMPTY, available: false, at: now });
        return;
      }
      const json = await res?.json().catch(() => null);
      const slow = isSlowAnswer(res?.status, json);
      const done = Date.now();
      if (res?.ok && json?.data) {
        const data = json.data as LiveCountersSum;
        setState((s) => ({
          available: true,
          data,
          queue: pushQueue(s.queue, data.db.queue),
          at: now,
          error: "",
          slow: false,
          intervalMs: countersInterval(s.intervalMs, { slow: false, elapsedMs: done - started }),
        }));
        return;
      }
      const error = json?.error ?? (res ? `counters answered ${res.status}` : "the panel's API did not answer");
      setState((s) => ({
        ...s,
        //a slow gateway keeps the last answer however old; any other failure, for STALE_MS
        data: s.data && (slow || now - s.at < STALE_MS) ? s.data : null,
        error,
        slow: slow && s.data !== null,
        intervalMs: countersInterval(s.intervalMs, { slow, elapsedMs: done - started }),
      }));
    } finally {
      reading.current = { inFlight: false, lastFinishedAt: Date.now() };
    }
  };
  usePoll(load, state.intervalMs, !paused && state.available !== false);
  return state;
}

function Figure({ f }: { f: CounterFigure }) {
  if (f.tone === "alarm") {
    //the canvas's alarm orange, filled, with dark text: the same colour as a node whose queue climbs
    return (
      <span
        className="rounded px-1 font-semibold"
        style={{ background: "var(--color-alarm, #f97316)", color: "var(--color-alarm-foreground, #1c1917)" }}
        title={`${f.full} · rising on each of the last five reads`}
      >
        {f.label} {f.text}
      </span>
    );
  }
  return (
    <span className={f.tone === "warning" ? "text-warning" : undefined} title={f.full}>
      {f.label} <span className={f.tone === "warning" ? "font-medium" : "font-medium text-foreground"}>{f.text}</span>
    </span>
  );
}

/**
 * Three columns under the Connectivity map (`S['connectivity']` in the mockups): MT total, DLR
 * total and PostgreSQL, the gateway's counts since its process started, summed across the cluster.
 * Nothing at all until the first answer, nor on a gateway without `live_counters`.
 */
export function ConnectivityCounters({ state }: { state: LiveCountersState }) {
  if (!state.available || !state.data) {
    return null;
  }
  const tiles = counterTiles(state.data, state.queue);
  return (
    <dl
      aria-label="Live counters since restart"
      title={state.error ? (state.slow ? state.error : `Last read failed: ${state.error}`) : undefined}
      className={`grid grid-cols-1 divide-y divide-border border-t border-border sm:grid-cols-3 sm:divide-x sm:divide-y-0${state.error && !state.slow ? " opacity-60" : ""}`}
    >
      {tiles.map((t) => (
        <div key={t.key} className="grid min-w-0 grid-cols-[1fr_auto] items-baseline gap-x-4 px-5 py-3">
          <dt className="text-2xs font-semibold uppercase tracking-wide text-muted-foreground">{t.title}</dt>
          <dd className="text-2xs tabular-nums text-muted-foreground"><span className="sr-only">rate </span>{t.rate}</dd>
          <dd className="col-span-2 text-lg font-semibold leading-tight tabular-nums" title={t.total.full}>{t.total.text}</dd>
          <dd className="col-span-2 mt-0.5 text-xs tabular-nums text-muted-foreground">
            <Figure f={t.a} /> · <Figure f={t.b} />
          </dd>
        </div>
      ))}
    </dl>
  );
}
