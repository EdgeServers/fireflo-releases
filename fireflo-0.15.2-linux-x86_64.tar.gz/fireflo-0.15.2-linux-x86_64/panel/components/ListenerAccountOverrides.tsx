"use client";
import { useState } from "react";
import Link from "next/link";
import { Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { SettingsSection } from "@/components/ui/settings-section";
import { HealthStrip } from "./CardBits";
import { useCatalogueLookup } from "./useCatalogueLookup";
import { useWorkerPropertyWrite } from "./useWorkerPropertyWrite";
import { formatTps } from "@/lib/tps-format";
import { cn } from "@/lib/utils";
import { perAccountKey, perAccountKeyFor } from "@/lib/worker-settable";
import type { Worker } from "@/lib/worker-types";

type Kind = "rate" | "binds";

/**
 * A listener's per-account overrides (`S['listener-overrides']` in the mockups): one account's rate
 * ceiling (`conf.maxRate.<id>`) or bind count (`conf.maxConnectionsPerUser.<id>`) on this listener,
 * in place of the listener default.
 *
 * <p>These used to be raw keys under "Other settings", so a listener carrying ten of them looked
 * like it carried ten typos, and the one with `abc` in it looked like the others. Here each is a row
 * naming its account and saying what it does -- or that the gateway passes it over -- with Edit and
 * Remove. Every change is one audited write of one key through the worker PATCH (the route checks
 * the account exists), and the running listener adopts it on the next config poll, no restart.
 */
export function ListenerAccountOverrides({ worker, onChanged }: { worker: Worker; onChanged: () => Promise<void> | void }) {
  const writer = useWorkerPropertyWrite();
  const [account, setAccount] = useState("");
  const [kind, setKind] = useState<Kind>("rate");
  const [value, setValue] = useState("");
  const accounts = useCatalogueLookup("account", account, null);

  const prop = (key: string) => worker.properties.find((p) => p.key === key)?.value ?? "";
  const rows = worker.properties
    .map((p) => ({ ...p, parsed: perAccountKey(p.key) }))
    .filter((p): p is typeof p & { parsed: NonNullable<typeof p.parsed> } => p.parsed != null)
    .sort((a, b) => a.parsed.account.localeCompare(b.parsed.account) || a.parsed.kind.localeCompare(b.parsed.kind));
  const defaultRate = prop("conf.maxRate.default");
  const defaultBinds = prop("conf.maxConnectionsPerUser.default");

  const save = async (target: string, k: Kind, v: string) => {
    const key = perAccountKeyFor(k, target.trim());
    const ok = await writer.write({
      worker: worker.name,
      key,
      value: v,
      current: prop(key),
      title: k === "rate" ? `Rate ceiling for ${target} on ${worker.name}` : `Binds for ${target} on ${worker.name}`,
      unit: k === "rate" ? "msg/s" : "binds",
      fallback: "the listener default",
    });
    if (ok) {
      await onChanged();
    }
    return ok;
  };

  return (
    <SettingsSection
      id="listener-overrides"
      title="Per-account overrides"
      description="One account’s ceiling or bind count on this listener, in place of the listener default. The ceiling is shared by every login of the account and split across the nodes it is bound to."
    >
      <form
        className="grid gap-3 px-4 py-3.5 md:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)_7rem_auto] md:items-end md:px-5"
        onSubmit={async (e) => {
          e.preventDefault();
          if (account.trim() && (await save(account, kind, value))) {
            setValue("");
          }
        }}
      >
        <Field label="Account" htmlFor="override-account">
          <div className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" aria-hidden />
            <Input
              id="override-account"
              value={account}
              onChange={(e) => setAccount(e.target.value)}
              list="override-accounts"
              placeholder="Find an account"
              autoComplete="off"
              className="pl-8 font-mono"
            />
          </div>
          <datalist id="override-accounts">{accounts.map((a) => <option key={a} value={a} />)}</datalist>
        </Field>
        <Field label="Setting" htmlFor="override-kind">
          <Select id="override-kind" value={kind} onChange={(e) => setKind(e.target.value as Kind)}>
            <option value="rate">Rate ceiling (messages/s)</option>
            <option value="binds">Binds per customer</option>
          </Select>
        </Field>
        <Field label="Value" htmlFor="override-value">
          <Input
            id="override-value"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            inputMode="numeric"
            placeholder={account.trim() ? prop(perAccountKeyFor(kind, account.trim())) || "none" : ""}
            className="font-mono"
          />
        </Field>
        <div>
          <Button type="submit" size="sm" className="w-full md:w-auto" disabled={writer.busy || !account.trim()}>Set</Button>
        </div>
      </form>
      <div className="px-4 py-2 text-xs text-muted-foreground md:px-5">
        Listener defaults: <span className="font-mono">{readRate(defaultRate)}</span> from{" "}
        <span className="font-mono">conf.maxRate.default</span> ·{" "}
        <span className="font-mono">{readBinds(defaultBinds)}</span> from{" "}
        <span className="font-mono">conf.maxConnectionsPerUser.default</span>. An empty value removes the override; 0 is
        unlimited.
      </div>
      {(writer.notice || writer.error) && (
        <div className="px-4 py-2 md:px-5">
          <HealthStrip tone={writer.error ? "destructive" : "info"}>{writer.error || writer.notice}</HealthStrip>
        </div>
      )}
      {rows.length === 0 ? (
        <p className="px-4 py-3 text-sm text-muted-foreground md:px-5">No account has an override here: every one gets the listener defaults.</p>
      ) : (
        <ul className="divide-y divide-border">
          {rows.map((r) => {
            const bad = !/^\d+$/.test(r.value.trim());
            return (
              <li key={r.key} className={cn("flex flex-wrap items-center gap-x-3 gap-y-1 px-4 py-2.5 text-sm md:px-5", bad && "bg-destructive-soft/40")}>
                <span className="min-w-0 flex-[1_1_260px]">
                  <span className="font-mono text-xs">{r.key}</span>{" "}
                  <span className="text-xs text-muted-foreground">
                    ·{" "}
                    <Link href={`/cp/accounts/${encodeURIComponent(r.parsed.account)}/limits`} className="underline-offset-2 hover:underline">
                      {r.parsed.account}
                    </Link>
                  </span>
                </span>
                <span className={cn("w-14 font-mono text-xs tabular-nums", bad && "text-destructive")}>{r.value || "(empty)"}</span>
                <span className={cn("min-w-0 flex-[1_1_220px] text-xs", bad ? "text-destructive" : "text-muted-foreground")}>
                  {bad
                    ? `ignored: not a whole number — the listener default applies`
                    : r.parsed.kind === "rate"
                      ? `ceiling · ${readRate(r.value)}`
                      : `binds · ${readBinds(r.value)}`}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setAccount(r.parsed.account);
                    setKind(r.parsed.kind);
                    setValue(bad ? "" : r.value);
                  }}
                >
                  Edit
                </Button>
                <Button variant="ghost-destructive" size="sm" disabled={writer.busy} onClick={() => void save(r.parsed.account, r.parsed.kind, "")}>
                  Remove
                </Button>
              </li>
            );
          })}
        </ul>
      )}
    </SettingsSection>
  );
}

/** A stored rate as the gateway reads it: empty or 0 is unlimited. */
function readRate(raw: string): string {
  const n = Number(raw);
  return raw.trim() === "" || n === 0 ? "unlimited" : Number.isFinite(n) ? `≤${formatTps(n)}/s` : raw;
}

function readBinds(raw: string): string {
  const n = Number(raw);
  return raw.trim() === "" || n === 0 ? "no bind limit" : Number.isFinite(n) ? `${n} bind${n === 1 ? "" : "s"}` : raw;
}
