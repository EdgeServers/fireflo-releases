import { KafkaTopicsClient } from "@/components/KafkaTopicsClient";

export const metadata = { title: "Kafka" };

export default function KafkaPage() {
  return <KafkaTopicsClient />;
}
