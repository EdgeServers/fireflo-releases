import { AccountLimitsClient } from "@/components/AccountLimitsClient";
import { BackLink } from "@/components/BackLink";

/**
 * Why this account gets the rate it gets: its ceiling on every listener and the setting behind it,
 * live TPS against it, binds and throttles. Operator only. Not a tab: reached from the Overview's
 * "SMPP ceiling" card, so it leads back there.
 */
export default async function AccountLimitsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  //the param is still encoded, which is what the URL needs
  return (
    <div className="space-y-4">
      <BackLink href={`/cp/accounts/${id}`}>Overview</BackLink>
      <AccountLimitsClient id={decodeURIComponent(id)} />
    </div>
  );
}
