import { ConnectivityClient } from "@/components/ConnectivityClient";

export default function ConnectivityPage() {
  return <ConnectivityClient />;
}
