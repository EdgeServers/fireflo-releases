import { redirect } from "next/navigation";
import { SessionProvider } from "next-auth/react";
import { auth } from "@/lib/auth";
import { isOperatorSession } from "@/lib/roles";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { DashboardShell } from "@/components/DashboardShell";
import { LiveGatewayProvider } from "@/components/LiveGatewayProvider";
import { ConfirmProvider } from "@/components/ConfirmProvider";
import { LicenseBanner } from "@/components/LicenseBanner";
import { PlatformScale } from "@/components/PlatformScale";
import { PanelSurface } from "@/components/PanelSurface";
import { OPERATOR_SURFACE } from "@/lib/panel-surface";
import { platformDecimals } from "@/lib/platform-decimals";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  //the gate for pages; every API route repeats it for itself rather than trusting this.
  //
  //the same predicate as requireOperator, deliberately: this asked only whether a session existed,
  //which let a non-operator render the whole shell while every request inside it answered 404 --
  //a page that looks like it works and does nothing, which is worse than being sent to the login
  const session = await auth();
  if (!isOperatorSession(session)) {
    redirect("/cp/login");
  }
  //and the fresh read every route makes: disabled, signed in under an old password, or not verified
  //with the authenticator this operator now has -- back to sign in. Two-factor required and not set
  //up yet: to the set-up, which is outside this layout, and nowhere else until it is done (every
  //route refuses them too, see requireOperator)
  let gate: "ok" | "login" | "enrol" = "ok";
  try {
    gate = (await requireOperator({ allowEnrolment: true })).enrolmentDue ? "enrol" : "ok";
  } catch (err) {
    if (err instanceof NotOperatorError) {
      gate = "login";
    } else {
      //the configuration database did not answer: the shell renders on the session alone, as it did
      //before this read, and every route behind it still makes its own check and fails closed
      console.error("dashboard: the operator could not be re-read; rendering on the session alone", err);
    }
  }
  if (gate === "login") {
    redirect("/cp/login");
  }
  if (gate === "enrol") {
    redirect("/cp/two-factor");
  }
  const scale = await platformDecimals();
  return (
    <>
      <PlatformScale scale={scale} />
      {/* the operator surface is already `panel-surface`'s default, so this changes nothing today.
          Declared anyway: the account components are shared with the customer portal now, and a
          default that is only correct because nobody set it is one navigation away from being
          wrong */}
      <PanelSurface surface={OPERATOR_SURFACE} />
      {/* the only subtree that reads the session client-side (Sidebar, UsersClient). The login page
          and the customer portal sit outside it on purpose -- see app/layout.tsx */}
      <SessionProvider>
        {/* one /health and one /q/metrics poll per page, however many cards read them; see the
            provider for the reference counting and the hidden-tab pause */}
        <LiveGatewayProvider>
          {/* every change on the vendor, server, account, pricing and routing screens is confirmed in
              one modal; see ConfirmProvider */}
          <ConfirmProvider>
            {/* the banner is a signal, never a gate: no redirect, and it renders nothing on an
                active licence. Enforcement is in the gateway's compiled artefact -- see
                lib/license-state.ts. It renders inside the shell, under the top bar */}
            <DashboardShell banner={<LicenseBanner />}>{children}</DashboardShell>
          </ConfirmProvider>
        </LiveGatewayProvider>
      </SessionProvider>
    </>
  );
}
