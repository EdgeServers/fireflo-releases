import { redirect } from "next/navigation";

/**
 * The Nodes page became the Node information section on Gateway (0.15.1); old links and bookmarks
 * land there, and `#nodes` opens the section.
 */
export default function NodesPage() {
  redirect("/cp/gateway#nodes");
}
