import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { isOperatorSession } from "@/lib/roles";
import { TwoFactorClient } from "@/components/TwoFactorClient";

export const metadata = { title: "Two-factor authentication" };

/**
 * The operator's own two-factor authentication: set up an authenticator, or turn it off.
 *
 * <p><strong>Outside `(dashboard)` on purpose</strong>, as `/cp/verify` is. When two-factor is
 * required of every operator and this one has not set it up, the dashboard layout sends them here and
 * every route refuses them but this page's own (requireOperator's `allowEnrolment`); a page inside
 * the layout would redirect to itself. Signed out, or a session the routes refuse, and it is the
 * sign-in page.
 */
export default async function TwoFactorPage() {
  const session = await auth();
  if (!isOperatorSession(session)) {
    redirect("/cp/login");
  }
  return (
    <main className="mx-auto w-full max-w-xl px-4 py-10 sm:px-6">
      <TwoFactorClient />
    </main>
  );
}
