import { NextRequest, NextResponse } from "next/server";
import { MAX_BATCH, searchCdrs, type CdrColumnSet, columnSetFor } from "@/lib/cdr-queries";
import { isFilterError, parseFilters, type CdrCursor } from "@/lib/cdr-request";
import { recordCustomerAccess } from "@/lib/customer-access-log";
import { MAX_RANGE_DAYS, spanInDays } from "@/lib/date-range";
import { type CdrColumn } from "@/lib/cdr-columns";
import { exportColumns, exportHeader, exportRow } from "@/lib/mis-messages-export";
import { isValidZone } from "@/lib/datetime";
import { billingZone } from "@/lib/platform-currency";
import { NotCustomerError, requireCustomer, scopeFor } from "@/lib/require-customer";
import { requestContext } from "@/lib/request-context";

/**
 * A customer's own messages as a CSV, streamed.
 *
 * <h2>The security shape, which is the existing route's and not a variation on it</h2>
 *
 * <p>Two things, and both are repeated here deliberately rather than shared through a helper that
 * could later grow a parameter making them optional:
 *
 * <ol>
 *   <li><strong>The account set is overwritten, not defaulted.</strong> `parseFilters` reads the
 *       caller's query string, which may well contain `account=somebody-else`. Assigning
 *       `accountIn` afterwards ANDs whatever it parsed inside the session's scope.
 *   <li><strong>The columns are intersected with the customer allow-list.</strong> `columns` comes
 *       from a URL. Anything not on {@link allowedForCustomer} is dropped, so asking for
 *       `cost,margin,vendor` yields a file without them rather than a file with them. This is the
 *       more damaging of the two places to get wrong, because the result lands in a file somebody
 *       keeps and forwards.
 * </ol>
 *
 * <h2>Not the operator's export queue</h2>
 *
 * <p>`lib/exports.ts` is an asynchronous job store with a manifest, a retention sweep and local
 * disk, built because an operator export can walk two million rows. It also has a fixed `HEADERS`
 * array containing `cost`, `margin` and `vendor`. Reusing it for customers would mean reusing the
 * one component whose column list is the thing being protected against — so this streams instead,
 * bounded by a shorter window and a lower row cap.
 */

/**
 * The most rows one download may contain.
 *
 * <p>At the 92-day window this route allows, a customer sending steadily will not reach it. A
 * customer who does is asking for something a spreadsheet cannot open anyway.
 */
const MAX_EXPORT_ROWS = 100_000;

export async function GET(req: NextRequest): Promise<NextResponse | Response> {
  let scope: string[];
  let accountId: string;
  try {
    const session = await requireCustomer();
    accountId = session.accountId;
    scope = await scopeFor(session);
  } catch (err) {
    if (err instanceof NotCustomerError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const params = req.nextUrl.searchParams;
  const parsed = parseFilters(params);
  if (isFilterError(parsed)) {
    return NextResponse.json({ error: parsed.error }, { status: 400 });
  }

  //after parsing, never before. See the class note
  parsed.accountIn = scope;

  if (!parsed.since) {
    return NextResponse.json(
      { error: "Choose a time range. The whole history is not available here." },
      { status: 400 }
    );
  }

  //the window is bounded here as well as in the browser, because the browser is not what enforces
  //it -- this URL is a plain GET anybody with a session can edit
  const until = parsed.until ?? new Date();
  const days = spanInDays(parsed.since, until);
  if (days > MAX_RANGE_DAYS) {
    return NextResponse.json(
      { error: `That is ${days} days. Ask for at most ${MAX_RANGE_DAYS} at a time.` },
      { status: 400 }
    );
  }

  //intersected with the customer allow-list inside exportColumns, which is where it is tested
  const columns = exportColumns(params.get("columns"));
  //the same on-demand rule the list route uses, driven by the columns that survived the allow-list
  const set: CdrColumnSet =
    columnSetFor(columns.map((c) => c.id), "customer");

  const context = await requestContext();
  //which window and how wide, never the rows themselves. An access log recording destinations would
  //be a second copy of the traffic in a table nobody thinks of as traffic
  void recordCustomerAccess({
    event: "portal_access",
    accountId,
    ip: context.ip,
    userAgent: context.userAgent,
    detail: {
      action: "messages_export",
      since: parsed.since.toISOString(),
      until: parsed.until?.toISOString() ?? null,
      days,
      columns: columns.map((c) => c.id),
    },
  });

  //the local copies of the time columns in the zone the customer was reading the table in; the
  //billing zone when the link names none, or one this runtime does not know
  const asked = params.get("zone");
  const zone = asked && isValidZone(asked) ? asked : await billingZone();

  const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
  return new Response(rowStream(parsed, columns, set, zone), {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      //derived from a timestamp and nothing the caller supplied, so there is no quote to escape and
      //no CRLF to inject
      "Content-Disposition": `attachment; filename="fireflo-messages-${stamp}.csv"`,
      "Cache-Control": "private, no-store",
    },
  });
}

/**
 * Pages the same keyset query the table uses and writes rows as they arrive.
 *
 * <p>A stream rather than a string: the point of this endpoint is the case where the answer is
 * larger than the page on screen, and building that in memory first would hold the whole file in the
 * process heap for as long as the download takes. Batching is also what keeps each query inside the
 * pool's 10-second `statement_timeout` and stops one download monopolising eight connections shared
 * with everything else the panel does.
 */
function rowStream(
  filters: Parameters<typeof searchCdrs>[0],
  columns: readonly CdrColumn[],
  set: CdrColumnSet,
  zone: string
): ReadableStream<Uint8Array> {
  const encoder = new TextEncoder();
  let cursor: CdrCursor | null = null;
  let written = 0;
  let done = false;

  return new ReadableStream({
    start(controller) {
      controller.enqueue(encoder.encode(exportHeader(columns, zone)));
    },
    async pull(controller) {
      if (done) {
        controller.close();
        return;
      }
      try {
        //NOT "full" -- that is the operator projection, and it selects cost, margin and all three
        //TLV columns. "list+received" adds only the one a customer may see, and only when they
        //asked for it: without this the column would export empty while the value sat in the row
        const page = await searchCdrs(filters, cursor, MAX_BATCH, set);
        if (page.rows.length) {
          const text = page.rows.map((row) => exportRow(row, columns, zone)).join("");
          controller.enqueue(encoder.encode(text));
          written += page.rows.length;
        }
        cursor = page.nextCursor;

        if (!cursor) {
          done = true;
        } else if (written >= MAX_EXPORT_ROWS) {
          //the headers went out with the first byte, so there is no status code left to fail with.
          //A row saying so is the honest option: a file that simply ends is indistinguishable from
          //a complete one, and the person reading it is the one who would be misled
          controller.enqueue(
            encoder.encode(
              `# stopped at ${MAX_EXPORT_ROWS} rows. Narrow the date range or add a filter.\n`
            )
          );
          done = true;
        }
      } catch (err) {
        controller.error(err);
      }
    },
  });
}
