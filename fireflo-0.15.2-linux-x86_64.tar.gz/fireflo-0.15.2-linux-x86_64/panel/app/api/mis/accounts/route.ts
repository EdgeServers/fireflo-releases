import { statsRoute } from "@/lib/stats-route";

/** Kept for links and scripts that name it: the same answer as /api/stats/accounts (lib/stats-route.ts). */
export const GET = statsRoute("accounts", "customer");
