import { NextRequest, NextResponse } from "next/server";
import { gql } from "@/lib/gateway-graphql";
import { SESSION_SUMMARY } from "@/lib/gateway-queries";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { withSourceTrace } from "@/lib/source-trace-route";

/**
 * GET /api/control/credentials/sessions?ids=a,b,c
 *
 * <p>Who is bound right now, per SMPP login, for the login cards: sessions by bind type across every
 * listener. Proxies the gateway's `sessionSummary` field on the read token -- it walks the live
 * sessions and changes nothing. A login with nothing bound is absent from the answer. When the
 * gateway cannot be reached this fails, and the cards say nothing rather than "Not connected".
 */
export const GET = withSourceTrace(async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const ids = (req.nextUrl.searchParams.get("ids") ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 200);
  if (!ids.length) {
    return NextResponse.json({ data: {} });
  }
  return gql({ query: SESSION_SUMMARY, variables: { systemIds: ids }, timeoutMs: 5_000 });
});
