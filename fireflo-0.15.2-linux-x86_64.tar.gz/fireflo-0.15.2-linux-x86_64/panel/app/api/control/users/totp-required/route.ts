import { NextRequest, NextResponse } from "next/server";
import { logOperatorEvent } from "@/lib/access-log";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { configFailed, guardAdminWrite } from "@/lib/config-guard";
import { forgetAllLiveIdentities } from "@/lib/live-identity-cache";
import { setGatewaySetting } from "@/lib/gateway-settings";
import { requireAdmin } from "@/lib/require-operator";
import { hasTotpColumns, TOTP_REQUIRED_KEY, totpRequired } from "@/lib/totp-store";

/**
 * PUT /api/control/users/totp-required `{ required }` -- whether every operator must use an
 * authenticator (`smsg.panel.operator.totp.required`, gateway V1.114.0).
 *
 * <p>Admin-only, and the only place the key is written from the panel: the generic gateway-settings
 * route refuses it, because any operator may use that one and this switch is a security control over
 * operators. Written through the same `setGatewaySetting` as every gateway setting, and logged as
 * `totp_required_changed` with the value before and after.
 *
 * <p>On, an operator without an authenticator reaches only the set-up from their next request.
 * Nobody is signed out by it, and nothing here resets anyone's authenticator (that is
 * `fireflo user totp-reset` on the server).
 */
export async function PUT(req: NextRequest): Promise<NextResponse> {
  const refused = await guardAdminWrite("app_config");
  if (refused) {
    return refused;
  }
  const admin = await requireAdmin();
  if (!(await hasTotpColumns())) {
    return NextResponse.json({ error: "Two-factor authentication arrives with the gateway's V1.114.0 database update." }, { status: 409 });
  }
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const required = (body as { required?: unknown } | null)?.required;
  if (typeof required !== "boolean") {
    return NextResponse.json({ error: "Send { required: true } or { required: false }." }, { status: 400 });
  }
  try {
    const before = await totpRequired();
    await setGatewaySetting(TOTP_REQUIRED_KEY, required ? "true" : "false");
    //the requirement is read with each operator's row and remembered for a few seconds: apply it now
    forgetAllLiveIdentities();
    void logOperatorEvent({
      event: "totp_required_changed",
      actor: admin.name,
      userId: admin.userId,
      ip: clientIp(req),
      userAgent: clientUserAgent(req),
      detail: { key: TOTP_REQUIRED_KEY, from: before, to: required },
    });
    return NextResponse.json({ data: { required } });
  } catch (err) {
    return configFailed("two-factor requirement", err);
  }
}
