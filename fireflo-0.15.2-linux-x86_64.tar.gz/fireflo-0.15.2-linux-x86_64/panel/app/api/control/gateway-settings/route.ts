import { NextRequest, NextResponse } from "next/server";
import { logOperatorEvent } from "@/lib/access-log";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { isConfigWritable } from "@/lib/config-db";
import {
  denialMessage,
  isReadable,
  judgeGatewayKey,
  WRITABLE_PREFIXES,
} from "@/lib/gateway-key-policy";
import { loadConfigKeyRegistry } from "@/lib/config-key-registry-db";
import { readGatewaySettings, setGatewaySetting } from "@/lib/gateway-settings";
import { TOTP_REQUIRED_KEY } from "@/lib/totp-store";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * Gateway-wide configuration: the two tiers above a worker's own settings.
 *
 * <p><strong>The panel's first write to `app_config`.</strong> Every other configuration endpoint
 * writes `app_worker_property`, which is scoped to one named worker. These keys are not — a wrong
 * value here is wrong for every vendor, every listener and both ingresses at once. Hence the audit
 * line on every write, and `lib/gateway-key-policy.ts` deciding what may be touched.
 *
 * <p>GET returns what is set. PUT sets or clears exactly one key.
 *
 * <p><strong>Both verbs consult the same policy, and the reading half is the one that was wrong.</strong>
 * This endpoint used to select every row under `smsg.` and return all of them — and `smsg.ops.token`
 * and `smsg.ops.admin.token` are rows under `smsg.` whenever the gateway reads its configuration
 * from the database. The page never rendered them, so nothing looked broken, but both tokens were in
 * the response body of every load of `/cp/gateway` and of every vendor and listener form. Filtering
 * on render is not filtering.
 */

const PREFIXES = [...WRITABLE_PREFIXES];

export async function GET(): Promise<NextResponse> {
  const refused = await guard();
  if (refused) {
    return refused;
  }
  const settings = await readGatewaySettings(PREFIXES);
  if (settings === null) {
    //not an empty result. In file mode the gateway reads smsg.properties and this panel reads a
    //database -- saying "nothing is set" would be a claim about a file it has never opened
    return NextResponse.json(
      { error: "Gateway configuration could not be read from the database." },
      { status: 503 }
    );
  }
  //the filter is here, on the way out of the process, rather than in the SQL: the query asks for a
  //prefix and the policy asks about a key, and pushing the second into the first would mean encoding
  //the denylist as SQL and keeping the two in step forever
  //app_config_key (gateway V1.61.0) decides what is shown, with the panel's built-in copy as the
  //fallback -- see lib/config-key-registry-db.ts
  const registry = await loadConfigKeyRegistry();
  const visible = [...settings].filter(([key]) => isReadable(key, registry));
  return NextResponse.json({
    data: Object.fromEntries(visible.map(([key, s]) => [key, { value: s.value, enabled: s.enabled }])),
    //said rather than silently omitted, so a key that is set but missing from the page has a visible
    //cause. The count alone, never the names -- naming them would undo the point of withholding them
    withheld: settings.size - visible.length,
    //the registry, so the page judges a key the operator types by the same list the server used --
    //minus every hidden row. Naming a withheld key would undo withholding it (the count above is
    //all a browser gets), so the page lays these over its built-in copy, which already knows the
    //hidden ones, and this PUT stays the authority for anything the page could not judge
    registry: { source: registry.source, rows: registry.rows.filter((r) => r.access !== "hidden") },
  });
}

export async function PUT(req: NextRequest): Promise<NextResponse> {
  const refused = await guard();
  if (refused) {
    return refused;
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const fields = (body as Record<string, unknown> | null) ?? {};
  const key = typeof fields.key === "string" ? fields.key.trim() : "";
  const value = typeof fields.value === "string" ? fields.value : "";

  //a security control over operators, set by an admin on the Users page; any operator may use this route
  if (key === TOTP_REQUIRED_KEY) {
    return NextResponse.json(
      { error: `${key} is set by an admin on the Users page, not here.` },
      { status: 403 }
    );
  }

  const verdict = judgeGatewayKey(key, await loadConfigKeyRegistry());
  if (!verdict.allowed) {
    //deliberately says what to do instead rather than only that it refused: the alternative is an
    //operator retrying a key that can never work, or concluding the panel is broken.
    //
    //403 for a credential and 400 for the rest, because they are different answers. 400 means "that
    //is not a key I take" -- fix the key and try again. 403 means "that key exists and you may not
    //have it here", which is a boundary rather than a typo, and reads correctly in an access log
    return NextResponse.json(
      { error: denialMessage(key, verdict.reason) },
      { status: verdict.reason === "secret" ? 403 : 400 }
    );
  }

  try {
    const { previous } = await setGatewaySetting(key, value);
    const { name: operator } = await requireOperator();
    //the most consequential write this panel has: one key, every worker, both ingresses. Recorded
    //with the old value as well as the new, so the log answers "what did it used to be" -- which is
    //the question actually asked after a configuration change goes wrong
    void logOperatorEvent({
      event: value.trim() === "" ? "gateway_setting_cleared" : "gateway_setting_set",
      actor: operator,
      ip: clientIp(req),
      userAgent: clientUserAgent(req),
      detail: { key, from: previous, to: value.trim() === "" ? null : value },
    });
    return NextResponse.json({ data: { key, value: value.trim() === "" ? null : value } });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    //the registry's value check (gateway V1.61.0, and V1.112.0's rules for smsg.cdr.hot.days and
    //smsg.cdr.archive.schedule) refuses a bad value with check_violation and says why: that is the
    //operator's to fix, not a server fault
    if ((err as { code?: unknown } | null)?.code === "23514") {
      return NextResponse.json({ error: message }, { status: 400 });
    }
    return NextResponse.json({ error: `Could not save: ${message}` }, { status: 500 });
  }
}

/** Operator, and a writable configuration database. Both, or nothing happens. */
async function guard(): Promise<NextResponse | null> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      //404, not 403, like every other control route: a 403 confirms there is something here
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  if (!isConfigWritable()) {
    return NextResponse.json(
      { error: "CONFIG_DATABASE_URL is not set, so configuration cannot be read or written." },
      { status: 503 }
    );
  }
  return null;
}
