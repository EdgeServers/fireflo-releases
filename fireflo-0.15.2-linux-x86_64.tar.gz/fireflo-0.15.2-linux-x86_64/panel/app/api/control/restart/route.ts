import { NextResponse } from "next/server";
import { auditConfigChange } from "@/lib/config-audit";
import { executeGql } from "@/lib/gateway-graphql-core";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { runRestart } from "@/lib/restart-route";

/**
 * POST /api/control/restart
 *
 * <p>Restarts one internal part of the running gateway (0.15.2, `componentRestart`, admin token):
 * `{ component, target?, hard? }` with component one of persist, db, kafka-router, kafka-consumers,
 * vendor-feed, vendor, jobs, config. The Queues page's Restart rows post here; the same thing as
 * `fireflo restart <part>` on the command line.
 *
 * <p>Admin only, and only on a gateway that advertises `component_restart`: the decisions are in
 * `lib/restart-route.ts`, where they are tested. The browser never names the actor: `by` is the
 * signed-in operator, so the gateway's `ops.restart` line and this panel's access log name the same
 * person. Writes are already Origin-checked by the proxy.
 *
 * <p>Audited like a worker action: nothing stored changes, but the gateway did something now, and
 * the access log has a `config_changed` line for it (`component`, `action:restart`) whenever the
 * gateway ran the restart -- a refusal changes nothing and leaves only the gateway's own line.
 */
export async function POST(req: Request): Promise<NextResponse> {
  let operator;
  try {
    operator = await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const raw = await req.json().catch(() => null);
  const outcome = await runRestart(executeGql, operator, raw);
  if (outcome.audit) {
    await auditConfigChange(outcome.audit, operator);
  }
  return NextResponse.json(outcome.body, { status: outcome.status });
}
