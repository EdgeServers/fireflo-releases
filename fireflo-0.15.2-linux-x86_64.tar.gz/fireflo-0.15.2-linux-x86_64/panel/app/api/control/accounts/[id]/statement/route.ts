import { NextRequest, NextResponse } from "next/server";
import { guardCdrRoute, queryFailed } from "@/lib/cdr-guard";
import {
  customPeriod,
  monthPeriod,
  periodTooLong,
  type BillingPeriod,
} from "@/lib/billing-period";
import { billingZone, platformCurrency } from "@/lib/platform-currency";
import {
  closedPeriods,
  LoginSplitUnavailable,
  statementDetail,
  statementSummary,
  type StatementCursor,
  type StatementRow,
  type StatementSplit,
} from "@/lib/statement-queries";
import { closePeriod, DuplicateReference, NoBalanceRow } from "@/lib/balance";
import { guardConfigWrite } from "@/lib/config-guard";
import { requireOperator } from "@/lib/require-operator";
import { withStatementTimeout } from "@/lib/metrics-db";
import {
  STATEMENT_HEAVY_MS,
  STATEMENT_RETRY_AFTER_S,
  StillReadingError,
  cachedStatement,
  statementFailure,
  statementKey,
} from "@/lib/statement-cache";
import { restatementOf } from "@/lib/period-close";
import { HEADERS, KIND, toCsvLine } from "@/lib/statement-export";
import { type ExportSource, listExports, requestExport } from "@/lib/exports";
import { withSourceTrace } from "@/lib/source-trace-route";

type Params = { params: Promise<{ id: string }> };

/** What the export job carries between batches. Serialised into the job record, so no `Date`s. */
interface StatementFilters {
  accountId: string;
  since: string;
  until: string;
  label: string;
}

/**
 * A statement as the generic job store consumes it.
 *
 * <p>`page` calls the DETAIL query and never the summary. Re-running a whole month's aggregate for
 * every 5,000-row batch would be the most expensive available mistake, and the two being separate
 * functions is what makes it unavailable rather than merely discouraged.
 */
const STATEMENT_EXPORT: ExportSource<StatementRow, StatementFilters> = {
  kind: KIND,
  headers: HEADERS,
  toCsvLine,
  page: async (filters, cursor, batch) => {
    const period: BillingPeriod = {
      since: new Date(filters.since),
      until: new Date(filters.until),
      label: filters.label,
    };
    return statementDetail(filters.accountId, period, cursor as StatementCursor | null, batch);
  },
  //already flat strings, so there is nothing to flatten. Passed through rather than run through
  //serialiseFilters, which exists to reduce arbitrary filter objects
  serialise: (filters) => ({ ...filters }),
};

/**
 * Reads the period off the query string.
 *
 * <p>`?month=2026-08`, or `?from=&to=` for an arbitrary window. A month is checked for length too,
 * even though a calendar month is always inside the ceiling — "the caller already validated" is the
 * assumption that stops being true the moment a second caller appears.
 */
/** @param zone the billing zone: a month and a day start at its midnight, never the host's. */
function readPeriod(params: URLSearchParams, zone: string): BillingPeriod | string {
  const month = params.get("month");
  if (month) {
    const period = monthPeriod(month, zone);
    if (!period) {
      return `'${month}' is not a month. Use YYYY-MM.`;
    }
    return periodTooLong(period) ?? period;
  }
  const period = customPeriod(params.get("from") ?? "", params.get("to") ?? "", zone);
  if (typeof period === "string") {
    return period;
  }
  return periodTooLong(period) ?? period;
}

/**
 * The bill for one account and one period, and the queue of files prepared from it.
 *
 * <p>Read-only. A statement is derived from the call records and `usage_daily` when it is asked
 * for; nothing is stored, and nothing here writes. Closing a period is a separate, explicit action.
 *
 * <p>The summary is read the way the heavy stats are (`statement-cache.ts`): kept for a minute and
 * shared, allowed a minute in the background, and answered `202 { busy, retryAfter }` when the
 * first read has not finished in eight seconds. A failure is told to the operator as a sentence
 * and logged in full.
 *
 * <p>`?exports=1` lists the prepared files instead of computing the bill.
 */
export const GET = withSourceTrace(async function GET(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  const { id } = await params;
  const accountId = decodeURIComponent(id).trim();
  if (!accountId) {
    return NextResponse.json({ error: "No account given." }, { status: 400 });
  }

  const search = new URL(req.url).searchParams;

  if (search.get("exports") === "1") {
    try {
      //FILTERED TO THIS ACCOUNT. listExports(kind) is global, so without this every account's
      //statement page would list every other account's prepared files -- and the filenames carry
      //the account id, so that is a disclosure rather than only a confusing list
      const all = await listExports(KIND);
      const mine = all.filter((job) => job.filters?.accountId === accountId);
      return NextResponse.json({ data: mine });
    } catch (err) {
      return queryFailed("statement export list", err);
    }
  }

  const period = readPeriod(search, await billingZone());
  if (typeof period === "string") {
    return NextResponse.json({ error: period }, { status: 400 });
  }

  //by product unless asked by login (0.15.1). The CSV and the close are always by product
  const split: StatementSplit = search.get("split") === "login" ? "login" : "product";

  try {
    const [currency, zone, closed] = await Promise.all([
      platformCurrency(), billingZone(), closedPeriods(accountId),
    ]);
    //the summary carries its own days, from the same rows as the lines, so the chart and the total
    //cannot disagree. Kept and shared (statement-cache.ts); the closed list beside it is read fresh
    //every time, so a period closed a moment ago shows as closed at once
    const answer = await cachedStatement(
      statementKey({ who: "operator", accounts: [accountId], label: period.label, since: period.since, until: period.until, split }),
      () => statementSummary(accountId, period, currency, zone, split)
    );
    const summary = answer.value;
    const already = closed.find((c) => c.label === period.label) ?? null;
    return NextResponse.json({
      asOf: new Date(answer.at).toISOString(),
      //an older answer, because the latest read failed: the page says so rather than blanking
      ...(answer.stale
        ? { stale: { at: new Date(answer.at).toISOString(), reason: "The latest read did not finish." } }
        : {}),
      data: {
        ...summary,
        closed,
        //present only when THIS period is closed and has since moved. The invoice stands either
        //way; this is what the difference carries forward as
        closedAs: already,
        //ONLY when the period can still be recomputed. With the call records purged and no rollup
        //covering them, `totalAmount` is zero for want of evidence rather than because nothing was
        //sent -- and comparing that zero against the invoice rendered "the full invoice is owed
        //back and carries forward as a credit" on every paid period older than the retention
        //window. A closed invoice nothing can be checked against is simply the invoice
        restatement: already && summary.recomputable
          ? restatementOf(already, summary.totalAmount)
          : null,
      },
    }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (err) {
    if (err instanceof LoginSplitUnavailable) {
      return NextResponse.json({ error: err.message }, { status: 409, headers: { "Cache-Control": "private, no-store" } });
    }
    if (err instanceof StillReadingError) {
      //still reading in the background: the page shows its breathing card and asks again
      return NextResponse.json(
        { busy: true, retryAfter: STATEMENT_RETRY_AFTER_S },
        { status: 202, headers: { "Cache-Control": "private, no-store", "Retry-After": String(STATEMENT_RETRY_AFTER_S) } }
      );
    }
    console.error(`statement ${accountId} ${period.label} failed`, err);
    return NextResponse.json({ error: statementFailure(err) }, { status: 500 });
  }
});

/**
 * Closes the period, which is the only write this file has.
 *
 * <p>PUT rather than POST because POST on this path already means "prepare a CSV", and one verb
 * doing two unrelated things behind a body field is how the wrong one gets called.
 *
 * <p>The amount is recomputed HERE and never taken from the request. A client-supplied figure would
 * make the invoice a claim rather than a derivation, and the whole design rests on the bill being a
 * pure function of `cdr_submit`.
 */
export async function PUT(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardConfigWrite("balance_ledger");
  if (refused) {
    return refused;
  }
  const { id } = await params;
  const accountId = decodeURIComponent(id).trim();
  if (!accountId) {
    return NextResponse.json({ error: "No account given." }, { status: 400 });
  }

  const period = readPeriod(new URL(req.url).searchParams, await billingZone());
  if (typeof period === "string") {
    return NextResponse.json({ error: period }, { status: 400 });
  }
  if (period.until.getTime() > Date.now()) {
    //a period that has not finished would be invoiced for traffic still arriving, and closing is
    //irreversible. The operator can close it the moment it ends
    return NextResponse.json(
      { error: `${period.label} has not finished yet. A period can only be closed once it has ended.` },
      { status: 400 }
    );
  }

  let note: string | null = null;
  try {
    const body = (await req.json()) as { note?: string };
    note = typeof body?.note === "string" ? body.note.slice(0, 500) : null;
  } catch {
    //a note is optional, so an absent or unparseable body is not an error
  }

  try {
    const { name: operator } = await requireOperator();
    const [currency, zone] = await Promise.all([platformCurrency(), billingZone()]);
    //always fresh, never the page's kept answer: this is the figure that becomes the invoice. Given
    //the heavy statements' minute rather than the pool's ten seconds, and waited for in full
    const summary = await withStatementTimeout(
      STATEMENT_HEAVY_MS,
      () => statementSummary(accountId, period, currency, zone)
    );
    if (!summary.recomputable) {
      //closing on a total of zero would write a BILL row invoicing nothing, permanently, for a
      //period that may well have carried traffic. The refusal names the cause because the fix is
      //a rollup, not a retry
      return NextResponse.json({
        error: `${period.label} has no call records and no usage_daily rollup covering it, so `
          + "there is nothing to invoice from. Closing it now would record an invoice of zero. "
          + "Run 'fireflo usage rollup --catch-up' if the period is still within the retention "
          + "window; if its records have already been purged, it cannot be closed after the fact.",
      }, { status: 409 });
    }
    await closePeriod(accountId, period.label, summary.totalAmount, note, operator);
    return NextResponse.json({
      data: { accountId, label: period.label, invoiced: summary.totalAmount },
      notice: "Closed. This period is now immutable — anything that lands against it later shows "
        + "as a credit note on the next period rather than changing this invoice.",
    });
  } catch (err) {
    if (err instanceof DuplicateReference) {
      return NextResponse.json(
        { error: `${period.label} has already been closed for this account. A closed period is `
          + "never reissued; the difference carries forward instead." },
        { status: 409 }
      );
    }
    if (err instanceof NoBalanceRow) {
      return NextResponse.json(
        { error: "This account has no balance row yet. Open it for credit first." },
        { status: 404 }
      );
    }
    console.error(`close period ${accountId} ${period.label} failed`, err);
    return NextResponse.json(
      { error: statementFailure(err, "close the period") },
      { status: 500 }
    );
  }
}

/** Requests the CSV. Answers when the job is recorded, not when the file is finished. */
export async function POST(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  const { id } = await params;
  const accountId = decodeURIComponent(id).trim();
  if (!accountId) {
    return NextResponse.json({ error: "No account given." }, { status: 400 });
  }

  const period = readPeriod(new URL(req.url).searchParams, await billingZone());
  if (typeof period === "string") {
    return NextResponse.json({ error: period }, { status: 400 });
  }

  //the window is pinned once, here. Re-deriving it per batch would let it slide as the export runs
  const filters: StatementFilters = {
    accountId,
    since: period.since.toISOString(),
    until: period.until.toISOString(),
    label: period.label,
  };

  try {
    return NextResponse.json({
      data: await requestExport(STATEMENT_EXPORT, filters, `${accountId}, ${period.label}`),
    });
  } catch (err) {
    return queryFailed("statement export request", err);
  }
}
