import { NextResponse } from "next/server";
import { gqlFailed } from "@/lib/gateway-graphql";
import { executeGql } from "@/lib/gateway-graphql-core";
import { ACCOUNT_THROUGHPUT, HEALTH_API } from "@/lib/gateway-queries";
import { ACCOUNT_THROUGHPUT_VIEW } from "@/lib/capabilities";
import { readAccountThroughput } from "@/lib/throughput";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

type Params = { params: Promise<{ id: string }> };

/**
 * GET /api/control/accounts/[id]/throughput
 *
 * <p>Proxies the gateway's `accountThroughput` (0.15.1, capability `account_throughput`): the
 * account's ceiling on every SMPP listener and the setting that produced it, binds, live TPS,
 * throttles per login, the HTTP ceiling and the last hour of throttles. The Limits tab polls it
 * every five seconds.
 *
 * <p>Operator-only and the read token, like the session list: it only reads, and it reads the
 * gateway's memory (the throttle history is one indexed read of `smpp_throttle_minute` on the
 * gateway's side). An older gateway answers `{ data: null, unsupported: true }` and the tab says why
 * instead of failing.
 */
export async function GET(_req: Request, { params }: Params): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const { id } = await params;
  const account = decodeURIComponent(id).trim();
  if (!account) {
    return NextResponse.json({ error: "No account given." }, { status: 400 });
  }

  const read = await readAccountThroughput(
    executeGql,
    account,
    { health: HEALTH_API, throughput: ACCOUNT_THROUGHPUT },
    (health) => (health as { api?: Record<string, boolean> } | null)?.api?.[ACCOUNT_THROUGHPUT_VIEW] === true
  );
  if (!read.ok) {
    return gqlFailed(read.failure);
  }
  return NextResponse.json(read.body);
}
