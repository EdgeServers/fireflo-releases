import { NextRequest, NextResponse } from "next/server";
import { guardCdrRoute, queryFailed } from "@/lib/cdr-guard";
import { isRejectedFilterError, parseRejectedFilters } from "@/lib/rejected-request";
import { listThrottles } from "@/lib/throttles";
import { withSourceTrace } from "@/lib/source-trace-route";

/**
 * GET /api/control/rejected/throttles?<the Refused page's filters>
 *
 * <p>SMPP submits answered ESME_RTHROTTLED (0x58), summed per account × listener × login over the
 * window, from `smpp_throttle_minute` (gateway 0.15.1). Guarded like the refusals beside it: the
 * same reporting data and the same reader. Takes the page's own filters, so the strip and the list
 * describe the same window; a filter the table has no column for answers `skipped` instead.
 */
export const GET = withSourceTrace(async function GET(req: NextRequest): Promise<NextResponse> {
  const refused = await guardCdrRoute();
  if (refused) {
    return refused;
  }
  const filters = parseRejectedFilters(new URL(req.url).searchParams);
  if (isRejectedFilterError(filters)) {
    return NextResponse.json({ error: filters.error }, { status: 400 });
  }
  try {
    return NextResponse.json(await listThrottles(filters));
  } catch (err) {
    return queryFailed("SMPP throttles", err);
  }
});
