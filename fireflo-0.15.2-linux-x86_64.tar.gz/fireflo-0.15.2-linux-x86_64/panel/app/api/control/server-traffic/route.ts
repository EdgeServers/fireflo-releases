import { statsRoute } from "@/lib/stats-route";

/** Kept for links and scripts that name it: the same answer as /api/stats/server-traffic (lib/stats-route.ts). */
export const GET = statsRoute("server-traffic", "operator");
