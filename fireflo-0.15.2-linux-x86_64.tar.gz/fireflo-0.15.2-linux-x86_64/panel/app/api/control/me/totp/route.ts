import { NextRequest, NextResponse } from "next/server";
import QRCode from "qrcode";
import { logOperatorEvent } from "@/lib/access-log";
import { updateSession } from "@/lib/auth";
import { signClaim } from "@/lib/auth-proof";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { isConfigWritable } from "@/lib/config-db";
import { operatorLockout } from "@/lib/operator-lockout";
import { verifyPassword } from "@/lib/password-hash";
import { NotOperatorError, requireOperator, type OperatorIdentity } from "@/lib/require-operator";
import { lockoutKey } from "@/lib/signin-lockout";
import { otpauthUri, spacedSecret } from "@/lib/totp";
import { sealingEnabled } from "@/lib/secret-box";
import {
  attemptCode,
  hasTotpColumns,
  startEnrolment,
  totpRequired,
  totpStatus,
  TotpRefused,
  type CodeAttempt,
} from "@/lib/totp-store";
import { findLoginUser } from "@/lib/users";
import type { TotpView } from "@/lib/totp-view";

/**
 * The signed-in operator's own two-factor authentication (gateway V1.114.0).
 *
 * <p>GET says where they stand. POST `{ action }`:
 *
 * <ul>
 *   <li>`start` `{ password }` -- a new authenticator key, kept pending for 15 minutes, answered once
 *       as a QR code (SVG drawn here, never by a third party) and as the spaced key. The password is
 *       asked for, as a password change asks for it: a cookie left in a browser must not be enough
 *       to put an authenticator on the account that its owner does not hold, locking them out;</li>
 *   <li>`confirm` `{ code }` -- a code from the new authenticator turns it on. This session is
 *       re-minted as verified with it (a signed claim, lib/auth-proof.ts), so it carries on while
 *       every other session of this operator is refused until it signs in with a code;</li>
 *   <li>`disable` `{ password, code }` -- the password and a current code, both: a cookie left in an
 *       unattended browser must not be enough to strip the second factor. Refused while two-factor
 *       is required of every operator.</li>
 * </ul>
 *
 * <p>An operator who must still enrol (required, not set up) may reach this and nothing else. Every
 * code is checked by `attemptCode`, counted per user in the database (five wrong and the checks lock,
 * 15 minutes and doubling), and passwords and codes are counted first in the in-memory limiter too,
 * before any await. After an enrol or a disable this session is re-minted at the new
 * `totp_changed_at`; every other session of the operator is refused from its next request.
 * Every answer is `Cache-Control: no-store`: a QR code or a key must not sit in any cache. Nobody resets another operator's
 * authenticator here: that is `fireflo user totp-reset` on the server, by the owner's decision.
 */

/** Every answer from here: a key or a QR code must never be cached by anything. */
function reply(body: unknown, status = 200): NextResponse {
  return NextResponse.json(body, { status, headers: { "Cache-Control": "no-store" } });
}

async function me(): Promise<OperatorIdentity | NextResponse> {
  try {
    return await requireOperator({ allowEnrolment: true });
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return reply({ error: "Not found" }, 404);
    }
    throw err;
  }
}

async function view(identity: OperatorIdentity): Promise<TotpView> {
  if (!isConfigWritable()) {
    return { available: false, reason: "noConfig" };
  }
  if (!(await hasTotpColumns())) {
    return { available: false, reason: "olderGateway" };
  }
  if (identity.userId === null) {
    return { available: false, reason: "envOperator" };
  }
  const [status, required] = await Promise.all([totpStatus(identity.userId), totpRequired()]);
  return {
    available: true,
    email: identity.name,
    enabled: status?.enabled ?? false,
    enabledAt: status?.enabledAt ?? null,
    pending: status?.pending ?? false,
    required,
    enrolmentDue: identity.enrolmentDue,
    unsealed: !sealingEnabled(),
  };
}

/** This session, re-minted at the operator's own change: verified with the new authenticator, or none. */
async function remint(userId: number, attempt: Extract<CodeAttempt, { outcome: "ok" }>): Promise<boolean> {
  if (attempt.changed === null) {
    return false;
  }
  try {
    await updateSession({
      user: {
        mfaAt: attempt.stamp,
        mfaProof: signClaim("mfa", userId, attempt.stamp),
        tcAt: attempt.changed,
        tcProof: signClaim("tc", userId, attempt.changed),
      },
    });
    return true;
  } catch (err) {
    console.warn("two-factor changed but the session could not be re-minted; this browser will sign in again", err);
    return false;
  }
}

export async function GET(): Promise<NextResponse> {
  const identity = await me();
  if (identity instanceof NextResponse) {
    return identity;
  }
  return reply({ data: await view(identity) });
}

export async function POST(req: NextRequest): Promise<NextResponse> {
  const identity = await me();
  if (identity instanceof NextResponse) {
    return identity;
  }
  const ip = clientIp(req);
  const userAgent = clientUserAgent(req);
  //the in-memory first line, checked and counted before anything is awaited and given back only on
  //success; the database counter in attemptCode is the binding one for codes
  const lockKey = lockoutKey(ip, identity.name);
  if (!operatorLockout.tryAttempt(lockKey)) {
    return reply({ error: "Too many wrong passwords or codes. Wait a quarter of an hour and try again." }, 429);
  }

  const current = await view(identity);
  if (!current.available || identity.userId === null) {
    return reply({ error: "Two-factor authentication cannot be set up here.", data: current }, 409);
  }
  const userId = identity.userId;

  let body: Record<string, unknown>;
  try {
    body = ((await req.json()) ?? {}) as Record<string, unknown>;
  } catch {
    return reply({ error: "Expected a JSON body." }, 400);
  }
  const action = body.action;
  const code = typeof body.code === "string" ? body.code : "";
  const password = typeof body.password === "string" ? body.password : "";

  /** The signed-in operator's own password, as a password change checks it. */
  const passwordRight = async (): Promise<boolean> => {
    const login = await findLoginUser(identity.name, "operator");
    return !!login && login.id === userId && (await verifyPassword(password, login.passwordHash));
  };
  /** A refused code: logged, and the lock it caused, if any. */
  const codeRefused = (attempt: Exclude<CodeAttempt, { outcome: "ok" }>, during: string): NextResponse => {
    void logOperatorEvent({ event: "totp_failed", actor: identity.name, userId, ip, userAgent, detail: { during, outcome: attempt.outcome } });
    if (attempt.outcome === "wrong" && attempt.lockedUntil) {
      void logOperatorEvent({
        event: "totp_locked", actor: identity.name, userId, ip, userAgent,
        detail: { failures: attempt.failures, until: attempt.lockedUntil.toISOString() },
      });
    }
    if (attempt.outcome === "locked" || (attempt.outcome === "wrong" && attempt.lockedUntil)) {
      const until = attempt.outcome === "locked" ? attempt.lockedUntil : attempt.lockedUntil!;
      return reply({ error: `Too many wrong codes. Code checks for this account are locked until ${until.toISOString()}.` }, 429);
    }
    if (attempt.outcome === "none") {
      return reply({ error: during === "enrolment"
        ? "No set-up is open, or it has lapsed (15 minutes). Start again to get a new code."
        : "Two-factor authentication is not on for this account." }, 409);
    }
    return reply({ error: during === "enrolment"
      ? "That code did not match. Check the authenticator's clock and try the next code."
      : "The password or the code is wrong." }, 400);
  };

  try {
    if (action === "start") {
      if (!(await passwordRight())) {
        void logOperatorEvent({ event: "totp_failed", actor: identity.name, userId, ip, userAgent, detail: { during: "start", reason: "password" } });
        return reply({ error: "The password is wrong." }, 400);
      }
      operatorLockout.clear(lockKey);
      const secret = await startEnrolment(userId);
      const uri = otpauthUri(secret, identity.name);
      const svg = await QRCode.toString(uri, { type: "svg", errorCorrectionLevel: "M", margin: 1 });
      return reply({
        data: {
          ...current,
          pending: true,
          setup: {
            qr: `data:image/svg+xml;base64,${Buffer.from(svg).toString("base64")}`,
            key: spacedSecret(secret),
            uri,
          },
        },
      });
    }

    if (action === "confirm") {
      const attempt = await attemptCode(userId, code, "confirm");
      if (attempt.outcome !== "ok") {
        return codeRefused(attempt, "enrolment");
      }
      operatorLockout.clear(lockKey);
      void logOperatorEvent({ event: "totp_enrolled", actor: identity.name, userId, ip, userAgent });
      const keptSignedIn = await remint(userId, attempt);
      return reply({ data: { ...(await view({ ...identity, enrolmentDue: false })), keptSignedIn } });
    }

    if (action === "disable") {
      if (current.required) {
        return reply({
          error: "Two-factor authentication is required for every operator, so it cannot be turned off here. "
            + "An admin can lift the requirement on the Users page; a lost authenticator is reset on the server "
            + "with fireflo user totp-reset.",
        }, 409);
      }
      //the code is checked (and counted) only after the password, so a wrong password costs no code
      if (!(await passwordRight())) {
        void logOperatorEvent({ event: "totp_failed", actor: identity.name, userId, ip, userAgent, detail: { during: "disable", reason: "password" } });
        return reply({ error: "The password or the code is wrong." }, 400);
      }
      const attempt = await attemptCode(userId, code, "disable");
      if (attempt.outcome !== "ok") {
        return codeRefused(attempt, "disable");
      }
      operatorLockout.clear(lockKey);
      void logOperatorEvent({ event: "totp_disabled", actor: identity.name, userId, ip, userAgent });
      const keptSignedIn = await remint(userId, attempt);
      return reply({ data: { ...(await view(identity)), keptSignedIn } });
    }

    return reply({ error: "Unknown action." }, 400);
  } catch (err) {
    if (err instanceof TotpRefused) {
      return reply({ error: err.message }, 409);
    }
    console.error("two-factor", err);
    return reply({ error: "Two-factor authentication could not be changed. The panel's log says why." }, 500);
  }
}
