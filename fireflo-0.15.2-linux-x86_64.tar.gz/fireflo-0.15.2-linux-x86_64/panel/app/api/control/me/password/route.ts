import { NextRequest, NextResponse } from "next/server";
import { logOperatorEvent } from "@/lib/access-log";
import { updateSession } from "@/lib/auth";
import { signClaim } from "@/lib/auth-proof";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { configFailed, guardConfigWrite } from "@/lib/config-guard";
import { verifyPassword } from "@/lib/password-hash";
import { passwordProblem } from "@/lib/password-policy";
import { requireOperator } from "@/lib/require-operator";
import { findLoginUser, setPassword } from "@/lib/users";

/**
 * The signed-in operator or admin changes their own password.
 *
 * <p>The current password is required, and for a reason beyond ceremony: the session is a cookie,
 * and a cookie left in a browser somebody else sits down at must not be enough to take the account
 * over by setting a new password. The env-fallback operator has no row and is told to run
 * `fireflo-panel-install passwd` instead.
 *
 * <p>A change stamps `password_changed_at`, which refuses every session minted before it on its next
 * request (lib/session-freshness.ts). The session that made the change is re-minted with the new
 * stamp here, so changing your own password signs out every OTHER browser and not this one.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  const refused = await guardConfigWrite("app_user");
  if (refused) {
    return refused;
  }
  const me = await requireOperator();
  if (me.userId === null) {
    return NextResponse.json(
      { error: "This operator account lives in panel.env, not the database. Use fireflo-panel-install passwd." },
      { status: 400 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const { current, next } = (body ?? {}) as { current?: unknown; next?: unknown };
  if (typeof current !== "string" || typeof next !== "string") {
    return NextResponse.json({ error: "Send the current password and the new one." }, { status: 400 });
  }

  try {
    const user = await findLoginUser(me.name, "operator");
    if (!user || user.id !== me.userId || !(await verifyPassword(current, user.passwordHash))) {
      //one message for an unknown row and a wrong password, as at sign-in
      return NextResponse.json({ error: "The current password is wrong." }, { status: 400 });
    }
    const weak = passwordProblem(next, user.email);
    if (weak) {
      return NextResponse.json({ error: weak }, { status: 400 });
    }
    if (current === next) {
      return NextResponse.json({ error: "That is the current password." }, { status: 400 });
    }
    const stamp = await setPassword(user.id, next);
    void logOperatorEvent({
      event: "password_changed",
      actor: me.name,
      userId: me.userId,
      ip: clientIp(req),
      userAgent: clientUserAgent(req),
    });
    //keep this session: without the refreshed claim the very next request would be refused as a
    //pre-change cookie. A failure here is not a failed change -- the password IS set -- it only means
    //this browser has to sign in again, so it is logged and the answer says so
    let keptSignedIn = false;
    if (stamp !== null) {
      try {
        await updateSession({ user: { passwordChangedAt: stamp, pwdProof: signClaim("pwd", me.userId, stamp) } });
        keptSignedIn = true;
      } catch (err) {
        console.warn("password changed but the session could not be re-minted; this browser will be asked to sign in again", err);
      }
    }
    return NextResponse.json({
      data: {
        ok: true,
        keptSignedIn,
        note: keptSignedIn
          ? "Every other browser signed in as you has been signed out."
          : "Every browser signed in as you, this one included, has been signed out.",
      },
    });
  } catch (err) {
    return configFailed("password", err);
  }
}
