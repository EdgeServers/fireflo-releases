import { NextRequest, NextResponse } from "next/server";
import { isConfigured } from "@/lib/metrics-db";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { lookup, type LookupKind } from "@/lib/usage-lookup";
import { withSourceTrace } from "@/lib/source-trace-route";

/**
 * GET /api/control/usage/lookup?kind=account|login|product&q=…[&account=…]
 *
 * <p>Report > Usage's typeahead: catalogue names starting with what was typed, ten at most, kept a
 * minute (lib/usage-lookup.ts). Never reads a call record.
 */
export const GET = withSourceTrace(async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  if (!isConfigured()) {
    return NextResponse.json({ data: [] });
  }
  const params = req.nextUrl.searchParams;
  const kind = params.get("kind");
  if (kind !== "account" && kind !== "login" && kind !== "product") {
    return NextResponse.json({ error: "kind is account, login or product." }, { status: 400 });
  }
  const account = params.get("account")?.trim() || null;
  try {
    const data = await lookup(kind as LookupKind, params.get("q") ?? "", account);
    return NextResponse.json({ data }, { headers: { "Cache-Control": "private, max-age=60" } });
  } catch (err) {
    console.error("usage lookup", err);
    return NextResponse.json({ data: [] });
  }
});
