import { NextRequest, NextResponse } from "next/server";
import { gqlFailed } from "@/lib/gateway-graphql";
import { executeGql, snakeCaseKeysDeep } from "@/lib/gateway-graphql-core";
import { SESSIONS, SESSIONS_LEGACY } from "@/lib/gateway-queries";
import { createSessionsReader } from "@/lib/sessions-read";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { withSourceTrace } from "@/lib/source-trace-route";

type Params = { params: Promise<{ name: string }> };

/** Asks with the 0.15.1 limit fields, and without them from a gateway that refuses them by name. */
const readSessions = createSessionsReader({ full: SESSIONS, legacy: SESSIONS_LEGACY });

/**
 * GET /api/control/workers/[name]/sessions?q=&offset=&limit=
 *
 * <p>One worker's bound sessions, searched and paged.
 *
 * <p>The read token, not admin: this only reads, and the same separation that lets a monitoring
 * system fetch health applies here. Disconnecting one of these sessions is the admin call, and it
 * lives at the `/disconnect` leaf.
 *
 * <p><strong>The three parameters are rebuilt as variables</strong> rather than forwarded
 * wholesale, so nothing else the browser sends reaches the management port. The numbers are only
 * checked for being numbers — the gateway's own clamp is the authority on how large a page may be,
 * and duplicating that bound here would give two answers to one question.
 *
 * <p>The typed `SessionPage` is camelCase; the rows are converted to the snapshot's spelling
 * (`session_id`, `bind_type`) because the table that renders them is the one that renders the
 * health snapshot's sessions.
 *
 * <p>Rows carry `login_tps_limit` and `limit_source` from a 0.15.1 gateway; from an older one they
 * are absent and the pages draw the bare ceiling (`lib/sessions-read.ts`).
 */
export const GET = withSourceTrace(async function GET(request: NextRequest, { params }: Params): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const { name } = await params;
  if (!name.trim()) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const variables: Record<string, unknown> = { worker: name };
  const q = request.nextUrl.searchParams.get("q");
  if (q && q.trim()) {
    variables.q = q.trim();
  }
  for (const key of ["offset", "limit"] as const) {
    const value = request.nextUrl.searchParams.get(key);
    if (value && /^\d+$/.test(value)) {
      variables[key] = Number(value);
    }
  }

  const read = await readSessions(executeGql, variables);
  if (!read.ok) {
    return gqlFailed(read);
  }
  return NextResponse.json({ data: snakeCaseKeysDeep(read.data) });
});
