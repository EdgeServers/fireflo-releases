import { NextRequest, NextResponse } from "next/server";
import { ConfigRefusal } from "@/lib/config-guard";
import { isConfigWritable } from "@/lib/config-db";
import { getAccount } from "@/lib/accounts";
import { deleteWorker, setWorkerEnabled, setWorkerProperty } from "@/lib/workers";
import { settable } from "@/lib/worker-settable";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * Enable, disable or remove one vendor or server.
 *
 * <p>Separate from the create/replace endpoint because these are the things an operator does in a
 * hurry — usually to stop traffic — and none of them should require sending the whole thing back.
 * The full save replaces every setting, so it would need a complete and current copy of the worker,
 * password included, just to pause it.
 *
 * <p>PATCH takes either `{ enabled }` or `{ property: { key, value } }`, one per request; which keys
 * the second may name is `lib/worker-settable.ts`.
 */
type Params = { params: Promise<{ name: string }> };

export async function PATCH(req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guard();
  if (refused) {
    return refused;
  }
  const { name } = await params;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 });
  }
  const fields = (body as Record<string, unknown> | null) ?? {};

  if ("property" in fields) {
    const property = fields.property as Record<string, unknown> | null;
    const key = typeof property?.key === "string" ? property.key.trim() : "";
    const raw = typeof property?.value === "string" ? property.value : "";
    //not a general-purpose setting writer: this endpoint exists for the controls, and the form
    //is the way to change anything else. A typo here would otherwise create a dead setting
    const allowed = settable(key, raw);
    if (!allowed.ok) {
      return NextResponse.json({ error: allowed.error }, { status: 400 });
    }
    //the fixed keys are written as sent, as they always were; a number is written trimmed
    const value = allowed.key === "suspend" || allowed.key === "pause" || allowed.key.startsWith("dlr.") ? raw : raw.trim();
    try {
      //a per-account key for an account that does not exist is the dead setting the list prevents
      if (allowed.account != null && !(await getAccount(allowed.account))) {
        return NextResponse.json({ error: `No account '${allowed.account}'.` }, { status: 400 });
      }
      const found = await setWorkerProperty(name, key, value);
      if (!found) {
        return NextResponse.json({ error: `Nothing named '${name}'.` }, { status: 404 });
      }
      return NextResponse.json({ data: { name, key, value } });
    } catch (err) {
      return failed(err);
    }
  }

  const enabled = fields.enabled;
  if (typeof enabled !== "boolean") {
    return NextResponse.json(
      { error: "Expected either { enabled } or { property: { key, value } }." },
      { status: 400 }
    );
  }

  try {
    const found = await setWorkerEnabled(name, enabled);
    if (!found) {
      return NextResponse.json({ error: `Nothing named '${name}'.` }, { status: 404 });
    }
    return NextResponse.json({ data: { name, enabled } });
  } catch (err) {
    return failed(err);
  }
}

export async function DELETE(_req: NextRequest, { params }: Params): Promise<NextResponse> {
  const refused = await guard();
  if (refused) {
    return refused;
  }
  const { name } = await params;

  try {
    const found = await deleteWorker(name);
    if (!found) {
      return NextResponse.json({ error: `Nothing named '${name}'.` }, { status: 404 });
    }
    return NextResponse.json({ data: { name, deleted: true } });
  } catch (err) {
    return failed(err);
  }
}

async function guard(): Promise<NextResponse | null> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  if (!isConfigWritable()) {
    return NextResponse.json(
      { error: "CONFIG_DATABASE_URL is not set, so editing is switched off." },
      { status: 503 }
    );
  }
  return null;
}

function failed(err: unknown): NextResponse {
  //a refusal the operator can act on (the vendor is still routed to) is a 409, not a fault
  if (err instanceof ConfigRefusal) {
    return NextResponse.json({ error: err.message }, { status: 409 });
  }
  const message = err instanceof Error ? err.message : "Unknown error";
  console.error("workers:", message);
  return NextResponse.json({ error: message }, { status: 500 });
}
