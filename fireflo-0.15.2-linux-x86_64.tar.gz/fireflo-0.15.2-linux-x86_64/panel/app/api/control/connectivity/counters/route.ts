import { NextResponse } from "next/server";
import { fetchLiveCounters, liveCountersAvailable, readLiveCounters } from "@/lib/gateway-live-counters";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { withSourceTrace } from "@/lib/source-trace-route";

/**
 * GET /api/control/connectivity/counters
 *
 * <p>The Connectivity map's three live counters (MT, DLR, PostgreSQL): the gateway's lifetime totals
 * since its process started and their last-five-second rates, from its memory (`liveCounters`,
 * capability `live_counters`), summed across every node with `since` the earliest node's
 * (`lib/gateway-live-counters.ts`). No database read: the footer shows Gateway only.
 *
 * <p>204 when the gateway has no `live_counters` -- the page then draws no counters; 502 when it
 * could not be asked. The page asks every 2 s; one answer is shared for a second.
 */
export const GET = withSourceTrace(async function GET(): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const answer = await readLiveCounters({ available: liveCountersAvailable, read: fetchLiveCounters });
  if (answer.status === 204) {
    return new NextResponse(null, { status: 204, headers: { "Cache-Control": "no-store" } });
  }
  return NextResponse.json(answer.body, { status: answer.status, headers: { "Cache-Control": "no-store" } });
});
