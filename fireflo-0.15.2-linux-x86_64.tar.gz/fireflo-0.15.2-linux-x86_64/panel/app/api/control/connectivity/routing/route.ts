import { NextResponse } from "next/server";
import { ROUTING_VIEW } from "@/lib/capabilities";
import { CALL_MS, createCapability } from "@/lib/gateway-fanout";
import { gqlData } from "@/lib/gateway-graphql-core";
import { readRoutingView, ROUTING_VIEW_QUERY, type RoutingViewWire } from "@/lib/gateway-routing-view";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { withSourceTrace } from "@/lib/source-trace-route";

/**
 * GET /api/control/connectivity/routing
 *
 * <p>The Connectivity map's routing: the tables and route groups the gateway's router holds in
 * memory and applies now (`routing`, capability `routing_view`, gateway 0.15.1), in the shapes the
 * map reads (`lib/gateway-routing-view.ts`). The read token; no database read, so the footer shows
 * Gateway only -- with this route the page reads nothing from PostgreSQL.
 *
 * <p>204 when the gateway has no `routing_view`: the page then reads `/api/control/routing` and
 * `/api/control/groups` (the config pool), the only case it does. 502 when the gateway could not be
 * asked, with `code: "SLOW"` when it is there but slow.
 *
 * <p>The view is read directly, with the live routes' {@link CALL_MS}: the main node is not probed
 * for the capability first (0.15.1). What the reads teach is kept by `createCapability`; a refused
 * read asks the capability map afterwards, to tell a 204 from a 502.
 */
const capability = createCapability(ROUTING_VIEW);

export const GET = withSourceTrace(async function GET(): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const answer = await readRoutingView({
    available: async () => capability.known() !== false,
    view: () => capability.call(() => gqlData<RoutingViewWire | null>({ query: ROUTING_VIEW_QUERY, timeoutMs: CALL_MS })),
  });
  if (answer.status === 204) {
    return new NextResponse(null, { status: 204, headers: { "Cache-Control": "no-store" } });
  }
  return NextResponse.json(answer.body, { status: answer.status, headers: { "Cache-Control": "no-store" } });
});
