import { NextResponse } from "next/server";
import { readConnectivityCounts } from "@/lib/connectivity-counts";
import { fetchLiveSeries, liveSeriesKnown } from "@/lib/gateway-live-series";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { withSourceTrace } from "@/lib/source-trace-route";

/**
 * GET /api/control/connectivity/counts
 *
 * <p>The Connectivity map's "last hour" MT and DLR counts: the gateway's in-memory live series, H1 in
 * hour bins, grouped `[LISTENER, ACCOUNT]` and `[VENDOR, ACCOUNT]`, summed across every node
 * (`lib/connectivity-counts.ts`); and each listener's refusals over the last full minute, from
 * the same series in minute bins grouped `[LISTENER]`. No database read: the footer shows Gateway only.
 *
 * <p>204 when the gateway has no `live_series` -- the page then offers "since bind" alone, from the
 * session counters it already polls; 502 when the gateway could not be asked, with `code: "SLOW"`
 * when it is there but slow (the page keeps its last counts). The series is read directly: the main
 * node is not probed for the capability first (`createCapability`, 0.15.1). Answers are shared for
 * ten seconds with every other live-series reader (`fetchLiveSeries`), and the page asks every 15.
 */
export const GET = withSourceTrace(async function GET(): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const answer = await readConnectivityCounts({
    available: liveSeriesKnown,
    series: (groupBy, grain) => fetchLiveSeries("1h", grain, groupBy),
  });
  if (answer.status === 204) {
    return new NextResponse(null, { status: 204, headers: { "Cache-Control": "no-store" } });
  }
  return NextResponse.json(answer.body, { status: answer.status, headers: { "Cache-Control": "no-store" } });
});
