import { NextRequest, NextResponse } from "next/server";
import { BROKER_DEFAULTS, bootstrapForGateway, brokerProblem, formFromStored, parseBrokerForm } from "@/lib/broker-config";
import { readBrokerStored } from "@/lib/broker-config-db";
import { gql } from "@/lib/gateway-graphql";
import { BROKER_TEST } from "@/lib/gateway-queries";
import { NotOperatorError, requireAdmin } from "@/lib/require-operator";

/**
 * POST /api/control/queues/broker/test
 *
 * <p>Asks the gateway to reach the Kafka cluster the form describes, saved or not, and report what
 * it found: the brokers, the controller and the topics under the prefix. The gateway's own
 * connection is not touched. Admins only.
 *
 * <p>Only the bootstrap list and the topic prefix are sent: `brokerTest` takes no credentials, so
 * a SASL or TLS cluster is tested with the security settings the gateway is running on, and the
 * form says so.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    await requireAdmin();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const form = parseBrokerForm(await req.json().catch(() => null));
  if (typeof form === "string") {
    return NextResponse.json({ error: form }, { status: 400 });
  }
  if (form.provider !== "kafka") {
    return NextResponse.json({ error: "There is no cluster to test: the gateway queues in process." }, { status: 400 });
  }
  const stored = await readBrokerStored();
  const problem = brokerProblem(form, formFromStored(stored).secretsSet);
  if (problem) {
    return NextResponse.json({ error: problem }, { status: 400 });
  }
  return gql({
    query: BROKER_TEST,
    //the admin token: this makes the gateway's host dial an address of the caller's choosing
    auth: "admin",
    variables: {
      bootstrap: bootstrapForGateway(form.bootstrap),
      topic: form.topicPrefix.trim() || BROKER_DEFAULTS.topicPrefix,
    },
    //the gateway allows itself a few seconds per broker for TCP and the metadata fetch
    timeoutMs: 30_000,
  });
}
