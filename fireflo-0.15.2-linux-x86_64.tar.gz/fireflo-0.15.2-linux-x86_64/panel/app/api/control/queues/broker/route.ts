import { NextRequest, NextResponse } from "next/server";
import { logOperatorEvent } from "@/lib/access-log";
import { type BrokerView, brokerProblem, envLockProblem, isEnvLocked, isSecretBrokerKey, parseBrokerForm, withEnvLock } from "@/lib/broker-config";
import { readBroker, saveBroker } from "@/lib/broker-config-db";
import { QUEUE_PROVIDER_ENV, hasCapability } from "@/lib/capabilities";
import { executeGql } from "@/lib/gateway-graphql-core";
import { HEALTH, HEALTH_BACKBONE_SOURCE } from "@/lib/gateway-queries";
import { flattenHealth, type HealthBackbone, type HealthField, providerSourceOf } from "@/lib/health-types";
import { clientIp, clientUserAgent } from "@/lib/client-ip";
import { isConfigWritable } from "@/lib/config-db";
import { NotOperatorError, requireAdmin, requireOperator } from "@/lib/require-operator";
import { ADMIN_ROLE } from "@/lib/roles";

/**
 * GET /api/control/queues/broker -- the backbone settings as a form, without any secret.
 * PUT -- saves them. Admins only: this decides whether the gateway runs as a cluster on Kafka or
 * alone in process.
 *
 * <p>The gateway connects to Kafka when it starts, so a save takes effect at the next restart; the
 * `queues` field says when one is pending.
 *
 * <p>From gateway 0.14.2 (`queue_provider_env`), FIREFLO_QUEUE_PROVIDER and FIREFLO_KAFKA_BOOTSTRAP
 * in the gateway's fireflo.env win over the provider and bootstrap rows. GET then answers
 * `providerSource: "env"` with the form showing what the gateway runs on, and PUT refuses (409) a
 * change to either of those two; the other keys are saved as before. A gateway that does not say,
 * or does not answer, locks nothing: `providerSource` is null and the form behaves as it always has.
 */
export async function GET(): Promise<NextResponse> {
  let admin = false;
  try {
    admin = (await requireOperator()).role === ADMIN_ROLE;
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  if (!isConfigWritable()) {
    return NextResponse.json({ data: null, reason: "CONFIG_DATABASE_URL is not set, so the broker settings cannot be read here." });
  }
  try {
    return NextResponse.json({ data: { ...(await readBrokerView()), canEdit: admin } });
  } catch (err) {
    return NextResponse.json({ error: `Could not read the broker settings: ${message(err)}` }, { status: 500 });
  }
}

export async function PUT(req: NextRequest): Promise<NextResponse> {
  let actor: string;
  try {
    actor = (await requireAdmin()).name;
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  if (!isConfigWritable()) {
    return NextResponse.json({ error: "CONFIG_DATABASE_URL is not set, so editing is switched off." }, { status: 503 });
  }
  const form = parseBrokerForm(await req.json().catch(() => null));
  if (typeof form === "string") {
    return NextResponse.json({ error: form }, { status: 400 });
  }
  const current = await readBrokerView();
  const locked = envLockProblem(form, current.form, current.providerSource);
  if (locked) {
    return NextResponse.json({ error: locked }, { status: 409 });
  }
  const problem = brokerProblem(form, current.secretsSet);
  if (problem) {
    return NextResponse.json({ error: problem }, { status: 400 });
  }
  try {
    const changes = await saveBroker(form, { envLocked: isEnvLocked(current.providerSource) });
    for (const change of changes) {
      const mask = (v: string | null) => (v !== null && isSecretBrokerKey(change.key) ? "••••" : v);
      void logOperatorEvent({
        event: change.to === null ? "gateway_setting_cleared" : "gateway_setting_set",
        actor,
        ip: clientIp(req),
        userAgent: clientUserAgent(req),
        detail: { key: change.key, from: mask(change.from), to: mask(change.to) },
      });
    }
    return NextResponse.json({ data: { changed: changes.map((c) => c.key) } });
  } catch (err) {
    return NextResponse.json({ error: `Could not save: ${message(err)}` }, { status: 500 });
  }
}

/** The stored settings, with the provider and bootstrap fireflo.env decided when it decided them. */
async function readBrokerView(): Promise<BrokerView> {
  const [view, backbone] = await Promise.all([readBroker(), readBackboneSource()]);
  return withEnvLock(view, providerSourceOf(backbone), backbone);
}

/**
 * The backbone's provider, bootstrap and source, or null when the gateway does not publish the
 * source (before `queue_provider_env`) or cannot be asked. Two documents, as the health route
 * does it: the field is only named to a gateway whose capability map has it.
 */
async function readBackboneSource(): Promise<HealthBackbone | null> {
  const health = await executeGql<HealthField>({ query: HEALTH, timeoutMs: 5_000 });
  if (!health.ok || !hasCapability(flattenHealth(health.data), QUEUE_PROVIDER_ENV)) {
    return null;
  }
  const answer = await executeGql<{ backbone?: HealthBackbone | null }>({ query: HEALTH_BACKBONE_SOURCE, timeoutMs: 5_000 });
  return answer.ok ? answer.data.backbone ?? null : null;
}

function message(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}
