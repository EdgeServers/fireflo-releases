import { NextResponse } from "next/server";
import { gqlFailed } from "@/lib/gateway-graphql";
import { executeGql } from "@/lib/gateway-graphql-core";
import { HEALTH, KAFKA_TOPICS } from "@/lib/gateway-queries";
import { KAFKA_TOPICS_VIEW, hasCapability } from "@/lib/capabilities";
import { flattenHealth, type HealthField } from "@/lib/health-types";
import type { KafkaTopicsView } from "@/lib/kafka-topics";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET /api/control/kafka/topics
 *
 * <p>Proxies the gateway's `kafkaTopics`: every Kafka topic under its prefix, the consumer groups
 * reading each and who uses it (gateway 0.14.3). The read token -- the gateway asks its broker with
 * admin calls alone and consumes nothing.
 *
 * <p>Gated the way the health route gates `backbone.source`: the capability map is read first and
 * the document is sent only to a gateway that declares `kafka_topics_view`, since an older one
 * rejects the field by name. Without it the answer is `{ data: null, unsupported: true }`, which the
 * page says in a sentence rather than as an error.
 */
export async function GET(): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }

  const health = await executeGql<HealthField>({ query: HEALTH, timeoutMs: 5_000 });
  if (!health.ok) {
    return gqlFailed(health);
  }
  if (!hasCapability(flattenHealth(health.data), KAFKA_TOPICS_VIEW)) {
    return NextResponse.json({ data: null, unsupported: true });
  }
  //the gateway gives its broker three seconds and caches the answer for five; eight here leaves
  //room for the hop without letting a stuck gateway hold the page
  const topics = await executeGql<KafkaTopicsView>({ query: KAFKA_TOPICS, timeoutMs: 8_000 });
  if (!topics.ok) {
    return gqlFailed(topics);
  }
  return NextResponse.json({ data: topics.data });
}
