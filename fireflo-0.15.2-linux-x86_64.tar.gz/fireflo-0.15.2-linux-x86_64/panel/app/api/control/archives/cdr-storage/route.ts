import { NextRequest, NextResponse } from "next/server";
import { isConfigWritable } from "@/lib/config-db";
import { gqlFailed } from "@/lib/gateway-graphql";
import { executeGql } from "@/lib/gateway-graphql-core";
import { readCdrStorage } from "@/lib/cdr-storage-route";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";

/**
 * GET /api/control/archives/cdr-storage[?first=50&failures=1]
 *
 * <p>Proxies the gateway's `cdrStorage` (gateway 0.15): the hot and archive call record tables, the
 * mover's settings and next run, the days waiting to move and the move log, newest first --
 * `failures=1` keeps only the failed rows. The read token; nothing here moves anything.
 *
 * <p>An older gateway, without the `cdr_storage` capability, answers `{ data: null, unsupported:
 * true, release }` and the page says the tiers arrive with 0.15. `configWritable` says whether this
 * panel can write the settings (CONFIG_DATABASE_URL); the gateway's `configSource` says whether
 * they are database rows at all. The settings themselves are written through
 * `PUT /api/control/gateway-settings`, audited like every gateway setting.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const params = req.nextUrl.searchParams;
  const read = await readCdrStorage(executeGql, {
    first: Number(params.get("first") ?? 50),
    failuresOnly: params.get("failures") === "1",
    configWritable: isConfigWritable(),
  });
  if (!read.ok) {
    return gqlFailed(read.failure);
  }
  return NextResponse.json(read.body);
}
