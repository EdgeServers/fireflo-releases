import { NextResponse } from "next/server";
import { configPoolStats } from "@/lib/config-db";
import { poolLabel } from "@/lib/db-endpoint";
import { poolsReport } from "@/lib/db-pools";
import { lastReadMs } from "@/lib/db-trace";
import { metricsPoolStats } from "@/lib/metrics-db";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { withSourceTrace } from "@/lib/source-trace-route";

/**
 * GET /api/control/database/pools
 *
 * <p>The panel's own two PostgreSQL pools (0.15.1), for the Queues page's Database card: where each
 * points (`endpointLabel`: host and port, never the user or the password), its size, the
 * connections open, idle and waiting, and the last traced read on it in this process. Answered
 * from memory: nothing here opens a pool or reads the database.
 *
 * <p>404 rather than 403 on a failed operator check, like the other control routes: an endpoint
 * that answers "forbidden" has confirmed it exists.
 */
export const GET = withSourceTrace(async function GET(): Promise<NextResponse> {
  try {
    await requireOperator();
  } catch (err) {
    if (err instanceof NotOperatorError) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    throw err;
  }
  const report = await poolsReport({
    label: poolLabel,
    stats: (pool) => (pool === "metrics" ? metricsPoolStats() : configPoolStats()),
    lastReadMs,
  });
  return NextResponse.json(report, { headers: { "Cache-Control": "no-store" } });
});
