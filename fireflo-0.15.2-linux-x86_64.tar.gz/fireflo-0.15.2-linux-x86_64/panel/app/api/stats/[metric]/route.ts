import { statsRoute } from "@/lib/stats-route";

/** Every stat and chart, operator and portal: see lib/stats-route.ts and lib/stats-metrics.ts. */
export const GET = statsRoute();
