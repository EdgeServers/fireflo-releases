import type { Metadata } from "next";
import { cookies } from "next/headers";
import { DM_Sans, Space_Grotesk } from "next/font/google";
import { ThemeProvider } from "@/components/ThemeProvider";
import { DisplayZoneProvider } from "@/components/DisplayZoneProvider";
import { ZONE_COOKIE } from "@/lib/datetime";
import { billingZone } from "@/lib/platform-currency";
import "./globals.css";

/*
 * Two faces, through `next/font/google`: self-hosted from our own origin, so no page load reaches
 * Google, but `next build` fetches them from fonts.googleapis.com once, which a build host without
 * internet access cannot do. Both are variable fonts, so every weight used is real rather than
 * synthesised.
 *
 * - DM Sans for the body: `--font-dm-sans`, first in `--font-sans` in globals.css, so the system UI
 *   font answers while it loads.
 * - Space Grotesk for the headings: `--font-space-grotesk`, behind `--font-heading`, used by the
 *   page, entity and card title roles only -- figures, tables and labels stay in the body face.
 */
const dmSans = DM_Sans({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-dm-sans",
});

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-space-grotesk",
});

/**
 * The product is called "FireFlo SMS/SMPP Gateway" in title positions and "FireFlo" in prose.
 *
 * <p>This is a title position, so it carries the long form. The header wordmark in
 * {@code FireFloMark} keeps the short one — it sits in a fixed-height bar beside the mark, and the
 * full name would wrap there without telling anyone anything the tab title has not already said.
 */
export const metadata: Metadata = {
  title: "Control Panel — FireFlo SMS/SMPP Gateway",
  description: "Operational metrics for the FireFlo SMS/SMPP Gateway",
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  //the theme cookie is written by ThemeProvider on the client; reading it here avoids the
  //first-paint flash. No cookie means no class, and the client applies one.
  const jar = await cookies();
  const theme = jar.get("theme")?.value;
  //the display zone: the platform's billing zone unless this browser chose another (the chip in the
  //top bar). Both are known here, so the server renders times in the zone the browser will -- see
  //DisplayZoneProvider. billingZone() is cached for 30 s and answers UTC when it cannot read
  const [zone, zoneCookie] = [await billingZone(), jar.get(ZONE_COOKIE)?.value];

  return (
    <html
      lang="en"
      className={`${dmSans.variable} ${spaceGrotesk.variable}${theme === "dark" ? " dark" : ""}`}
      suppressHydrationWarning
    >
      <body>
        {/* no SessionProvider here: it belongs to the operator dashboard alone. Mounted at the root
            it probed /api/auth/session on every page, and Auth.js answers that probe with a fresh
            CSRF cookie whenever the browser has none -- which raced the login form's own CSRF
            fetch, and the portal's, and refused good sign-ins as MissingCSRF */}
        <ThemeProvider>
          <DisplayZoneProvider billingZone={zone} initialCookie={zoneCookie}>{children}</DisplayZoneProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
