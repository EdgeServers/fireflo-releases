"use client";
import { useEffect, useMemo, useState } from "react";
import { Check, Copy, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog } from "@/components/ui/dialog";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import type { InstructionServer } from "@/lib/connection-instructions";
import type { Credential } from "@/lib/credential-types";
import { copyText as toClipboard } from "@/components/CopyButton";

/**
 * Mails a login's connection details to its customer, after showing exactly what will go.
 *
 * <p>The text is composed by the server on every change and shown here with the password masked:
 * the browser never holds the real one unless the operator presses Copy text. Send goes through the
 * panel's own mail server and is recorded in the operator audit log; with no mail server set, Copy
 * text is the way out, and the dialog says so rather than offering a button that cannot work.
 */

interface Options {
  type: "SMPP" | "HTTP";
  account: { id: string; label: string; email: string | null };
  hasPassword: boolean;
  servers: InstructionServer[];
  host: string;
  restUrl: string;
  to: string[];
  smtp: boolean;
}

interface Preview {
  subject: string;
  text: string;
  problem: string | null;
}

export function ConnectionInstructionsDialog({
  credential,
  apiBase,
  onClose,
}: {
  credential: Credential;
  apiBase: string;
  onClose: () => void;
}) {
  const url = `${apiBase}/credentials/${credential.id}/instructions`;
  const [options, setOptions] = useState<Options | null>(null);
  const [loadError, setLoadError] = useState("");

  const [to, setTo] = useState("");
  const [restUrl, setRestUrl] = useState("");
  const [servers, setServers] = useState<string[]>([]);
  const [includePassword, setIncludePassword] = useState(true);
  const [note, setNote] = useState("");

  const [preview, setPreview] = useState<Preview | null>(null);
  const [busy, setBusy] = useState<"copy" | "send" | null>(null);
  const [error, setError] = useState("");
  const [done, setDone] = useState("");
  const [copied, setCopied] = useState(false);
  //what to show when the browser refuses the clipboard: the text itself, to select by hand
  const [fallbackText, setFallbackText] = useState("");

  useEffect(() => {
    let live = true;
    fetch(url, { cache: "no-store" })
      .then(async (r) => {
        const body = await r.json().catch(() => ({}));
        if (!live) return;
        if (!r.ok) {
          setLoadError(body.error ?? `Could not load this login (HTTP ${r.status}).`);
          return;
        }
        const o = body.data as Options;
        setOptions(o);
        setTo(o.to.join(", "));
        setRestUrl(o.restUrl);
        //one listener: the first, until the operator picks another
        setServers(o.servers.length ? [o.servers[0].name] : []);
        setIncludePassword(o.hasPassword);
      })
      .catch(() => live && setLoadError("Could not reach the panel."));
    return () => {
      live = false;
    };
  }, [url]);

  const choices = useMemo(
    () => ({ restUrl, servers, includePassword, note }),
    [restUrl, servers, includePassword, note]
  );

  //recomposed on the server a moment after typing stops, so the preview is the text that goes out
  useEffect(() => {
    if (!options) return;
    const controller = new AbortController();
    const timer = setTimeout(() => {
      fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "preview", ...choices }),
        signal: controller.signal,
      })
        .then((r) => r.json())
        .then((body) => body.data && setPreview(body.data as Preview))
        .catch(() => undefined);
    }, 250);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [options, choices, url]);

  const recipients = to.split(/[,;\s]+/).map((t) => t.trim()).filter(Boolean);

  async function copyText() {
    setBusy("copy");
    setError("");
    setFallbackText("");
    try {
      const r = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "copy", ...choices }),
      });
      const body = await r.json().catch(() => ({}));
      if (!r.ok) {
        setError(body.error ?? `Could not compose the text (HTTP ${r.status}).`);
        return;
      }
      const full = `Subject: ${body.data.subject}\n\n${body.data.text}`;
      //the plain-HTTP fallback too; when neither works the text is shown to copy by hand
      if (await toClipboard(full)) {
        setCopied(true);
        setTimeout(() => setCopied(false), 1600);
      } else {
        setFallbackText(full);
      }
    } finally {
      setBusy(null);
    }
  }

  async function send() {
    setBusy("send");
    setError("");
    setDone("");
    try {
      const r = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "send", ...choices, to: recipients }),
      });
      const body = await r.json().catch(() => ({}));
      if (!r.ok) {
        setError(body.error ?? `Not sent (HTTP ${r.status}).`);
        return;
      }
      setDone(`Sent to ${(body.data.sent as string[]).join(", ")}.`);
    } finally {
      setBusy(null);
    }
  }

  const name = credential.systemId ?? `#${credential.id}`;
  const problem = preview?.problem ?? null;

  return (
    <Dialog
      open
      onClose={onClose}
      title={`Send connection instructions for ${name}`}
      description={options ? `To ${options.account.label}. Check the preview before sending.` : undefined}
      className="max-w-4xl"
    >
      {loadError ? (
        <p className="text-sm text-destructive">{loadError}</p>
      ) : !options ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : (
        <div className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
          <div className="min-w-0 space-y-4">
            <Field
              label="To"
              htmlFor="ci-to"
              hint={options.account.email ? "The account's email address. Separate several with commas." : "This account has no email address stored. Separate several with commas."}
            >
              <Input id="ci-to" type="text" value={to} placeholder="customer@example.com" onChange={(e) => setTo(e.target.value)} />
            </Field>

            {options.type === "SMPP" ? (
              <>
                {/* one listener, and its address and ports from its own settings: the instructions name
                    the server this customer is assigned to, at the address it really answers on */}
                {options.servers.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No SMPP listener is enabled, so there is nothing to connect to.</p>
                ) : (
                  <Field label="Server" htmlFor="ci-server">
                    <Select id="ci-server" value={servers[0] ?? ""} onChange={(e) => setServers([e.target.value])}>
                      {options.servers.map((s) => (
                        <option key={s.name} value={s.name}>
                          {s.name} · {[s.port && `port ${s.port}`, s.tlsPort && `TLS ${s.tlsPort}`].filter(Boolean).join(" · ")}
                        </option>
                      ))}
                    </Select>
                  </Field>
                )}
                {(() => {
                  const chosen = options.servers.find((s) => s.name === servers[0]);
                  if (!chosen) {
                    return null;
                  }
                  return (
                    <dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 rounded-md border border-border px-3 py-2 text-sm">
                      <dt className="text-muted-foreground">Address</dt>
                      <dd className="font-mono">
                        {chosen.host ?? <span className="font-sans text-destructive">not set</span>}
                      </dd>
                      <dt className="text-muted-foreground">Port</dt>
                      <dd className="font-mono">
                        {[chosen.port && String(chosen.port), chosen.tlsPort && `${chosen.tlsPort} (TLS)`].filter(Boolean).join(" · ")}
                      </dd>
                      <dd className="col-span-2 text-xs text-muted-foreground">
                        {chosen.hostSource === "public"
                          ? "From this listener's Public IP."
                          : chosen.hostSource === "listener"
                            ? "The address is this listener's own srv.host."
                            : chosen.hostSource === "panel"
                              ? "This listener has no Public IP, so this is the panel's FIREFLO_PUBLIC_HOST."
                              : "Set the listener's Public IP under Servers, or FIREFLO_PUBLIC_HOST in the panel's environment."}
                      </dd>
                    </dl>
                  );
                })()}
              </>
            ) : (
              <Field
                label="API address"
                htmlFor="ci-rest"
                hint={options.restUrl ? "From GATEWAY_API_URL. Change it for this mail only." : "Set GATEWAY_API_URL in the panel's environment to fill this in."}
              >
                <Input id="ci-rest" className="font-mono" value={restUrl} placeholder="https://api.example.com" onChange={(e) => setRestUrl(e.target.value)} />
              </Field>
            )}

            <label className="flex items-start gap-2 text-sm">
              <Checkbox
                className="mt-0.5"
                checked={includePassword && options.hasPassword}
                disabled={!options.hasPassword}
                onChange={(e) => setIncludePassword(e.target.checked)}
              />
              <span>
                Include the password
                <span className="block text-xs text-muted-foreground">
                  {options.hasPassword
                    ? "Email is not a secure channel. Untick to send the password another way."
                    : "This login has no password stored."}
                </span>
              </span>
            </label>

            <Field label="Note" htmlFor="ci-note" hint="Optional. Placed above the details.">
              <Textarea
                id="ci-note"
                value={note}
                maxLength={2000}
                onChange={(e) => setNote(e.target.value)}
              />
            </Field>
          </div>

          <div className="min-w-0 space-y-2">
            <p className="text-xs font-semibold">Preview</p>
            <div className="rounded-md border border-border bg-muted/40">
              <p className="border-b border-border px-3 py-2 text-xs">
                <span className="text-muted-foreground">Subject: </span>
                {preview?.subject ?? "…"}
              </p>
              <pre className="max-h-[28rem] overflow-auto whitespace-pre-wrap break-words px-3 py-2 font-mono text-sm">
                {preview?.text ?? "Composing…"}
              </pre>
            </div>
            {includePassword && options.hasPassword && (
              //the dots are this preview's, not the mail's: they are not an encrypted password
              <p className="text-xs text-muted-foreground">
                The password is hidden in this preview only. The mail and Copy carry the actual password.
              </p>
            )}
            {fallbackText && (
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">The browser refused the clipboard. Select the text and copy it yourself.</p>
                <Textarea readOnly value={fallbackText} onFocus={(e) => e.currentTarget.select()} className="h-32 font-mono" />
              </div>
            )}
          </div>

          <div className="space-y-2 lg:col-span-2">
            {problem && <p className="text-sm text-warning">{problem}</p>}
            {!options.smtp && (
              <p className="text-sm text-muted-foreground">
                This panel has no mail server set (FIREFLO_SMTP_HOST and FIREFLO_SMTP_FROM), so it cannot send. Copy the text into your own mail instead.
              </p>
            )}
            {error && <p className="text-sm text-destructive">{error}</p>}
            {done && <p className="text-sm text-success">{done}</p>}
            <div className="flex flex-wrap justify-end gap-2">
              <Button variant="ghost" onClick={onClose}>Close</Button>
              <Button variant="outline" className="gap-2" disabled={!!problem || busy !== null} onClick={copyText}>
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                {copied ? "Copied" : "Copy text"}
              </Button>
              {options.smtp && (
                <Button className="gap-2" disabled={!!problem || busy !== null || recipients.length === 0} onClick={send}>
                  <Mail className="h-4 w-4" />
                  {busy === "send" ? "Sending…" : "Send"}
                </Button>
              )}
            </div>
          </div>
        </div>
      )}
    </Dialog>
  );
}
