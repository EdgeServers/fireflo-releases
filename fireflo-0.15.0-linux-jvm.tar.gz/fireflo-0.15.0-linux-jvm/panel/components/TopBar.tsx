"use client";
import { useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { PendingMark } from "./PendingMark";
import { usePathname } from "next/navigation";
import { Menu as MenuIcon, Search, X } from "lucide-react";
import { FireFloMark } from "./FireFloMark";
import type { PortalMark } from "@/lib/brand";
import { ThemeToggle } from "./ThemeToggle";
import { HealthPill } from "./HealthPill";
import { JumpBox } from "./JumpBox";
import { cn } from "@/lib/utils";

export interface QuickLink {
  href: string;
  label: string;
}

/**
 * The bar above every page.
 *
 * <p>It replaces two headers -- a phone one with the brand and a desktop one that was empty but
 * for the health icon -- with one that earns its height: the pages that matter as tabs, a box
 * that jumps anywhere, the gateway's state as a word, and the person as a menu. Below `lg` the
 * tabs go (the sidebar has them); below `md` the jump box becomes an icon and the brand appears,
 * because the sidebar is a drawer and nothing else names the product.
 *
 * <p>The portal uses the same bar with its own links and no gateway health; `trailing` is where
 * its balance goes.
 */
export function TopBar({
  onMenuClick,
  quick,
  brand = "FireFlo",
  mark,
  jump = false,
  health = false,
  trailing,
  user,
  onUnpin,
}: {
  onMenuClick: () => void;
  quick: QuickLink[];
  /** The operator's pins: each tab gets an unpin control. Absent (the portal) means fixed links. */
  onUnpin?: (href: string) => void;
  brand?: string;
  /** The portal's mark; absent draws FireFlo's. */
  mark?: PortalMark;
  /** Show the ⌘K jump box (operator only: it searches the operator API). */
  jump?: boolean;
  /** Show the gateway health pill (operator only). */
  health?: boolean;
  trailing?: ReactNode;
  user: ReactNode;
}) {
  const pathname = usePathname();
  const activeHref = quick
    .filter((q) => pathname === q.href || pathname.startsWith(`${q.href}/`))
    .reduce<string | null>((best, q) => (best && best.length >= q.href.length ? best : q.href), null);
  const [jumpOpen, setJumpOpen] = useState(false);

  useEffect(() => {
    if (!jump) {
      return;
    }
    function onKeyDown(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setJumpOpen(true);
      }
    }
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [jump]);

  return (
    <header className="flex h-14 shrink-0 items-center gap-2 border-b border-border bg-card px-3 md:gap-3 md:px-6">
      <button
        type="button"
        onClick={onMenuClick}
        className="-ml-1 rounded-md p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground md:hidden"
        aria-label="Open menu"
      >
        <MenuIcon className="h-5 w-5" />
      </button>
      <span className="flex items-center gap-2 md:hidden">
        <FireFloMark className="h-5 w-5" mark={mark} />
        <h2 className="font-heading font-semibold tracking-tight">{brand}</h2>
      </span>

      <nav aria-label="Quick navigation" className="hidden items-center gap-0.5 lg:flex">
        {quick.map((q) => {
          //the most specific tab wins: with Accounts and one account both pinned, the account's
          //page lights its own tab, not both
          const active = q.href === activeHref;
          return (
            <span key={q.href} className="group relative flex items-center">
              <Link
                href={q.href}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "inline-flex max-w-[12rem] items-center gap-1.5 truncate rounded-md px-3 py-1.5 text-sm transition-colors",
                  onUnpin && "group-hover:pr-7 group-focus-within:pr-7",
                  active ? "bg-muted font-semibold text-foreground" : "font-medium text-muted-foreground hover:bg-muted hover:text-foreground"
                )}
              >
                <span className="truncate">{q.label}</span>
                <PendingMark />
              </Link>
              {onUnpin && (
                <button
                  type="button"
                  onClick={() => onUnpin(q.href)}
                  aria-label={`Unpin ${q.label}`}
                  title={`Unpin ${q.label}`}
                  className="absolute right-1 rounded p-0.5 text-muted-foreground opacity-0 transition-opacity hover:bg-background hover:text-foreground focus-visible:opacity-100 group-hover:opacity-100"
                >
                  <X className="h-3 w-3" />
                </button>
              )}
            </span>
          );
        })}
      </nav>

      {jump && (
        <>
          <button
            type="button"
            onClick={() => setJumpOpen(true)}
            className="hidden h-9 w-full max-w-[280px] items-center gap-2 rounded-md border border-border bg-background px-2.5 text-sm text-muted-foreground transition-colors hover:bg-muted md:flex lg:ml-4"
          >
            <Search className="h-3.5 w-3.5 shrink-0" aria-hidden />
            <span className="truncate">Jump to account, vendor, message id</span>
            <kbd className="ml-auto rounded border border-border px-1 font-mono text-xs">⌘K</kbd>
          </button>
          <button
            type="button"
            onClick={() => setJumpOpen(true)}
            className="ml-auto rounded-md p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground md:hidden"
            aria-label="Jump to"
          >
            <Search className="h-5 w-5" />
          </button>
          <JumpBox open={jumpOpen} onClose={() => setJumpOpen(false)} />
        </>
      )}

      {/* always against the right edge. The jump box sits beside the tabs and no longer carries the
          auto margin: at desktop width `lg:mx-4` replaced it, which left this cluster floating with a
          gap after it. On a phone the search icon is the one pushed right, and this follows it */}
      <div className={cn("flex items-center gap-1.5", jump ? "md:ml-auto" : "ml-auto")}>
        {health && <HealthPill />}
        {trailing}
        <ThemeToggle />
        {user}
      </div>
    </header>
  );
}
