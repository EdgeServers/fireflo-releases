"use client";
import { Fragment, useCallback, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { Loader2, RefreshCw, TriangleAlert } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { CardActions, Figures, HealthStrip } from "./CardBits";
import { NeedsCapability } from "./NeedsCapability";
import { useHealth } from "./useHealth";
import { usePoll } from "./usePoll";
import { KAFKA_TOPICS_VIEW } from "@/lib/capabilities";
import { formatClockTime } from "@/lib/datetime";
import { count } from "@/lib/format";
import { providerSourceLabel, providerSourceOf } from "@/lib/health-types";
import {
  formatRetention,
  groupByRole,
  lagState,
  lagsByTopic,
  userHref,
  type KafkaTopic,
  type KafkaTopicsView,
  type KafkaTopicUser,
} from "@/lib/kafka-topics";
import { cn } from "@/lib/utils";

/** How often the page re-reads while Live. The gateway caches its reading for five seconds. */
const REFRESH_MS = 10_000;

/** How many users a row names before it says "+N more"; the router lists every listener. */
const USERS_SHOWN = 5;

const ROLE_BADGE: Record<string, React.ComponentProps<typeof Badge>["variant"]> = {
  router: "default",
  deliver: "info",
  vendor: "success",
  retry: "outline",
  dlq: "warning",
  webhook: "outline",
  other: "outline",
};

/**
 * Kafka: every topic the gateway keeps on its broker, what each is for and who uses it -- what an
 * operator would otherwise read from kafka-topics.sh and kafka-consumer-groups.sh (gateway 0.14.3,
 * `kafkaTopics`).
 *
 * <p>The header is `health.backbone`, which the health poll already carries; the table is the
 * gateway's topics view, read every ten seconds while Live. A lag is compared read to read, like the
 * Queues page's depths, and highlighted only when it is above zero and higher than last time: a lag
 * that is falling is a consumer catching up, not an incident.
 *
 * <p>Read-only. The gateway answers from admin calls, so opening this page consumes nothing and
 * joins no group.
 */
export function KafkaTopicsClient() {
  const { health, error: healthError, loading: healthLoading } = useHealth();
  const [view, setView] = useState<KafkaTopicsView | null>(null);
  const [unsupported, setUnsupported] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [live, setLive] = useState(true);
  //the lag each topic had on the previous read, and on the one before it for the render
  const previous = useRef<Map<string, number>>(new Map());
  const [before, setBefore] = useState<Map<string, number>>(new Map());

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/control/kafka/topics", { cache: "no-store" });
      const body = await res.json();
      if (!res.ok) {
        setError(body?.error ?? "Could not read the Kafka topics.");
        return;
      }
      setError(null);
      if (body.unsupported) {
        setUnsupported(true);
        setView(null);
        return;
      }
      const next = body.data as KafkaTopicsView;
      setBefore(previous.current);
      previous.current = lagsByTopic(next.topics);
      setUnsupported(false);
      setView(next);
    } catch {
      setError("Could not reach the panel's API.");
    } finally {
      setLoading(false);
    }
  }, []);

  //Live from the start, so the first read is the poll's; pausing keeps what is on screen and Refresh
  //still reads once
  usePoll(load, REFRESH_MS, live);

  const sections = useMemo(() => groupByRole(view?.topics ?? []), [view]);
  const backbone = health?.backbone ?? null;
  const onKafka = backbone?.provider?.trim().toLowerCase() === "kafka";
  const source = providerSourceLabel(providerSourceOf(backbone));
  const dlq = view?.topics.find((t) => t.role === "dlq") ?? null;
  const dlqDepth = backbone?.dlqDepth ?? dlq?.messages ?? null;

  return (
    <>
      <PageHeader
        title="Kafka"
        description="Every topic the gateway keeps on its broker: what it carries, who uses it, and how far behind its consumers are."
      />

      <NeedsCapability health={health} loading={healthLoading} error={healthError} name={KAFKA_TOPICS_VIEW} feature="its Kafka topics">
        {!onKafka && (
          <HealthStrip tone="info">
            This gateway queues in process ({backbone?.provider ?? "memory"}), so it has no Kafka topics. The Queues page
            shows what is waiting.
          </HealthStrip>
        )}

        <Card>
          <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
            <span className="text-title">Broker</span>
            {backbone && (
              backbone.connected ? <Badge variant="success">connected</Badge> : <Badge variant="destructive">not connected</Badge>
            )}
            {source && <Badge variant="outline">{source}</Badge>}
          </CardHeader>
          <CardContent className="space-y-3 pt-3">
            <Figures
              figures={[
                { value: <span className="font-mono text-sm">{backbone?.bootstrap?.trim() || "—"}</span>, label: "bootstrap" },
                {
                  value: backbone?.routerLag == null ? "—" : count(backbone.routerLag),
                  label: "router lag",
                  tone: (backbone?.routerLag ?? 0) > 0 ? "warning" : "default",
                },
                {
                  value: dlqDepth == null ? "—" : count(dlqDepth),
                  label: "on the dead-letter topic",
                  tone: (dlqDepth ?? 0) > 0 ? "destructive" : "default",
                },
                { value: view ? count(view.topics.length) : "—", label: `topics under ${view?.topicPrefix ?? "the prefix"}` },
              ]}
            />
            {backbone?.lastError && (
              <HealthStrip tone="destructive">
                {backbone.lastError}
                {backbone.lastErrorAt && <> at <span className="tabular-nums">{formatClockTime(backbone.lastErrorAt)}</span></>}
              </HealthStrip>
            )}
          </CardContent>
        </Card>

        <p className="text-xs text-muted-foreground">
          Servers (SMPP listeners) don&apos;t have their own topics: everything they receive goes to the router topic, and
          receipts back to their customers go through <code className="font-mono">deliver.&lt;node&gt;</code>.
        </p>

        <Card>
          <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
            <span className="text-title">Topics</span>
            {view?.groupPrefix && <Badge variant="outline" className="font-mono text-xs">groups {view.groupPrefix}*</Badge>}
            <CardActions>
              {view?.readAt && (
                <span className="text-sm text-muted-foreground">
                  read at <span className="tabular-nums">{formatClockTime(view.readAt)}</span>
                </span>
              )}
              <Button
                variant="outline"
                size="sm"
                aria-pressed={live}
                onClick={() => setLive((v) => !v)}
                className={cn(live && "border-primary bg-primary-soft font-semibold text-primary")}
              >
                <span className={cn("h-1.5 w-1.5 rounded-full", live ? "bg-primary" : "bg-muted-foreground")} />
                {live ? "Live" : "Paused"}
              </Button>
              <Button variant="outline" size="sm" onClick={load}>
                <RefreshCw className="h-3.5 w-3.5" />
                Refresh
              </Button>
            </CardActions>
          </CardHeader>
          <CardContent className="space-y-3 pt-3">
            {loading && !view && !unsupported && (
              <p className="text-sm text-muted-foreground">
                <Loader2 className="mr-2 inline h-4 w-4 animate-spin" />
                Reading the gateway&apos;s topics…
              </p>
            )}
            {error && (
              <p className="flex items-start gap-2 text-sm text-destructive">
                <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" />
                {error}
              </p>
            )}
            {unsupported && (
              <HealthStrip tone="info">This gateway does not publish its Kafka topics; it needs gateway 0.14.3 or newer.</HealthStrip>
            )}
            {view?.error && (
              <HealthStrip tone="warning">
                Part of the broker could not be read: {view.error}
              </HealthStrip>
            )}
            {view && view.available && view.topics.length === 0 && (
              <p className="py-3 text-sm text-muted-foreground">The broker lists no topics under {view.topicPrefix ?? "the prefix"}.</p>
            )}
            {sections.length > 0 && (
              <TableInCard>
                <THead>
                  <TR>
                    <TH>Topic</TH>
                    <TH>Role</TH>
                    <TH>Used by</TH>
                    <TH className="text-right">Partitions</TH>
                    <TH className="text-right">Messages kept</TH>
                    <TH>Consumer group</TH>
                    <TH className="text-right">Lag</TH>
                    <TH>Holder</TH>
                    <TH className="text-right">Retention</TH>
                  </TR>
                </THead>
                <TBody>
                  {sections.map((s) => (
                    <Fragment key={s.role}>
                      <TR className="bg-muted/40">
                        <TD colSpan={9} className="py-1.5 text-2xs font-semibold uppercase tracking-wide text-muted-foreground">
                          {s.label} <span className="font-normal tabular-nums">· {s.topics.length}</span>
                        </TD>
                      </TR>
                      {s.topics.map((t) => (
                        <TopicRow key={t.name} topic={t} previousLag={before.get(t.name) ?? null} />
                      ))}
                    </Fragment>
                  ))}
                </TBody>
              </TableInCard>
            )}
          </CardContent>
        </Card>
        <p className="text-xs text-muted-foreground">
          Messages kept is what retention still holds (latest minus earliest offset), not what is waiting; lag is what
          is waiting for the gateway&apos;s own group. The gateway reads its broker with admin calls only and answers from a
          {view ? ` ${view.cacheSeconds}-second` : ""} cache, so this page consumes nothing.
        </p>
      </NeedsCapability>
    </>
  );
}

function TopicRow({ topic, previousLag }: { topic: KafkaTopic; previousLag: number | null }) {
  const state = lagState(topic.lag, previousLag);
  const own = topic.groups.find((g) => g.expected) ?? null;
  const others = topic.groups.filter((g) => !g.expected);
  return (
    <TR className="align-top">
      <TD>
        <div className="font-mono text-xs">{topic.name}</div>
        <div className="mt-0.5 max-w-[22rem] text-2xs text-muted-foreground">{topic.purpose}</div>
      </TD>
      <TD>
        <Badge variant={ROLE_BADGE[topic.role] ?? "outline"}>
          {topic.role === "retry" && topic.subject ? `retry ${topic.subject}` : topic.role}
        </Badge>
      </TD>
      <TD>
        <UsedBy users={topic.usedBy} />
      </TD>
      <TD className="text-right tabular-nums">
        {topic.partitions ?? "—"}
        {topic.replication != null && <span className="text-2xs text-muted-foreground"> ×{topic.replication}</span>}
      </TD>
      <TD className="text-right tabular-nums">{topic.messages == null ? "—" : count(topic.messages)}</TD>
      <TD>
        {own ? (
          <div className="font-mono text-xs" title={own.state ?? undefined}>
            {own.group}
            <span className="ml-1 font-sans text-2xs text-muted-foreground">
              {own.members == null ? "not known to the broker" : `${own.members} member${own.members === 1 ? "" : "s"}`}
            </span>
          </div>
        ) : (
          <span className="text-muted-foreground">—</span>
        )}
        {others.map((g) => (
          <div key={g.group} className="font-mono text-xs text-muted-foreground" title="a group under the prefix the gateway does not use">
            {g.group} · lag {g.lag == null ? "—" : count(g.lag)}
          </div>
        ))}
      </TD>
      <TD
        className={cn(
          "text-right tabular-nums",
          state === "growing" && "font-semibold text-destructive",
          state === "behind" && "text-warning",
          state === "clear" && "text-muted-foreground"
        )}
        title={state === "growing" ? `up from ${count(previousLag ?? 0)} on the last read` : undefined}
      >
        {topic.lag == null ? "—" : count(topic.lag)}
        {state === "growing" && <span aria-label="growing"> ↑</span>}
      </TD>
      <TD className="font-mono text-xs">{topic.holderNode?.trim() || <span className="font-sans text-muted-foreground">shared</span>}</TD>
      <TD className="text-right tabular-nums">{formatRetention(topic.retentionMs)}</TD>
    </TR>
  );
}

function UsedBy({ users }: { users: KafkaTopicUser[] }) {
  if (users.length === 0) {
    return <span className="text-muted-foreground">—</span>;
  }
  const shown = users.slice(0, USERS_SHOWN);
  const rest = users.slice(USERS_SHOWN);
  return (
    <div className="flex max-w-[18rem] flex-wrap gap-1">
      {shown.map((u) => (
        <UserChip key={`${u.kind}:${u.name}`} user={u} />
      ))}
      {rest.length > 0 && (
        <span className="text-2xs text-muted-foreground" title={rest.map((u) => u.name).join(", ")}>
          +{rest.length} more
        </span>
      )}
    </div>
  );
}

function UserChip({ user }: { user: KafkaTopicUser }) {
  const href = userHref(user);
  const label = (
    <>
      <span className="text-muted-foreground">{user.kind === "server" ? "server" : user.kind === "vendor" ? "vendor" : "rest"}</span>{" "}
      {user.name}
      {user.detail && <span className="text-muted-foreground"> {user.detail}</span>}
    </>
  );
  const chip = "rounded border border-border px-1.5 py-0.5 text-2xs";
  return href ? (
    <Link href={href} className={cn(chip, "hover:bg-muted hover:underline")}>
      {label}
    </Link>
  ) : (
    <span className={chip}>{label}</span>
  );
}
