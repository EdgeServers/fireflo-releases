"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from "recharts";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { TableInCard, THead, TH, TBody, TR, TD } from "@/components/ui/table";
import {
  ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig,
} from "@/components/ui/chart";
import { money } from "@/lib/format";
import { formatDate } from "@/lib/datetime";
import { recentMonths } from "@/lib/billing-period";
import type { ClosedPeriod } from "@/lib/period-close";
import { ErrorCard } from "./FormNotices";
import { StaleNote } from "./StaleNote";
import { BreathingCard } from "./BreathingCard";
import { useStatement } from "./useStatement";

interface Line {
  product: string; submitted: number; delivered: number; failed: number;
  expired: number; pending: number; unrated: number; amount: number;
}

interface Day {
  day: string; submitted: number; delivered: number;
  failed: number; pending: number; price: number;
}

interface Payload {
  label: string;
  currency: string | null;
  lines: Line[];
  days: Day[];
  totalSubmitted: number;
  totalDelivered: number;
  totalUnrated: number;
  totalAmount: number;
  billingMode: "PREPAID" | "POSTPAID";
  balance: number | null;
  creditLimit: number | null;
  closed: ClosedPeriod[];
}

/**
 * The same recharts note the dashboard carries: with the entry animation on, a `Bar` renders no
 * shape at all until a frame has run, so anywhere `requestAnimationFrame` does not fire the chart
 * is an empty pair of axes rather than a chart that has not animated yet.
 */
const ANIMATION = { isAnimationActive: false } as const;

const chartConfig = {
  price: { label: "Billed", color: "var(--color-chart-1)" },
} satisfies ChartConfig;

/**
 * What this customer has sent in a period, and what it came to.
 *
 * <p>Same period picker as the operator's, deliberately: a customer ringing about "the August
 * invoice" and the operator looking at it should be reading the same window with the same
 * boundaries, or the conversation is about which of the two screens is wrong.
 *
 * <p><strong>The period and the present are two different questions, and the page keeps them
 * apart.</strong> Amount, sent and delivered describe the month. Balance describes this instant --
 * it moves when a top-up lands, which has nothing to do with the month being read. They used to sit
 * in one row of four, which said they were the same kind of number and invited the subtraction that
 * is never valid between them.
 *
 * <p>A POSTPAID customer sees what they may still run up; a PREPAID one sees what is left. Showing
 * the wrong one is how somebody plans against a number that does not apply to them.
 *
 * <p>This owns its own {@link PageHeader} rather than the route file doing it, because the month
 * picker belongs in the header's `actions` slot and the picker is what refetches. Putting the
 * header above a client boundary would mean either a second boundary or a navigation per click.
 *
 * <p><strong>A month is read when Show is pressed</strong>, as on the operator's statement: picking
 * one only marks it changed, and the figures and the CSV stay those of the month they are labelled
 * with. A month that takes the server long shows the breathing card while it reads on in the
 * background (`statement-cache.ts`), not an error.
 */
export function MisStatementClient({ account }: { account?: string } = {}) {
  const months = useMemo(() => recentMonths(new Date(), 13), []);
  const [month, setMonth] = useState(months[1] ?? months[0]);
  //the month the figures on screen are for, or are being read for
  const [shown, setShown] = useState<string | null>(null);
  const [state, show] = useStatement<Payload>();
  const { data, loading, busy, stale, error } = state;

  //absent for the customer's own statement, which is the whole scope summed. Present when a
  //reseller is reading one of its own accounts -- both routes put it through `assertInScope`
  //before it reaches a query, so it can only narrow. One suffix for the data and the CSV, so the
  //download beside a child's figures is never the reseller's whole book
  const forAccount = account ? `&account=${encodeURIComponent(account)}` : "";

  const showMonth = useCallback((m: string) => {
    setShown(m);
    show(`/api/mis/statement?month=${encodeURIComponent(m)}${forAccount}`);
  }, [forAccount, show]);

  //the first read, of last month, as the page has always opened. Every later one is a Show
  useEffect(() => {
    showMonth(months[1] ?? months[0]);
  }, [showMonth, months]);

  const changed = shown !== null && month !== shown;

  const currency = data?.currency ?? "";
  //nothing was sent, which is a different state from "still loading" and from "something broke".
  //Four zeroes and a paragraph about billing rules is what this used to render for an empty month
  const empty = data != null && data.totalSubmitted === 0;
  const rate = data && data.totalSubmitted > 0
    ? (data.totalDelivered / data.totalSubmitted) * 100
    : null;
  //taken from the lines rather than derived as submitted-minus-delivered-minus-failed: `expired`
  //is a fourth outcome, so the subtraction would fold expiries into "awaiting a receipt" and
  //report messages as still in flight that the gateway has already given up on.
  //
  //All three are named because together with `delivered` they exhaust `submitted` -- naming only
  //some of them leaves a customer unable to account for the rest. On a live month here that was
  //1,143 of 1,227 messages expired against a caption that said "9 failed" and stopped there
  const outcomes = data
    ? ([
        ["failed", data.lines.reduce((n, l) => n + l.failed, 0)],
        ["expired", data.lines.reduce((n, l) => n + l.expired, 0)],
        ["awaiting a receipt", data.lines.reduce((n, l) => n + l.pending, 0)],
      ] as const).filter(([, n]) => n > 0)
    : [];

  return (
    <>
      <PageHeader
        title="Statement"
        description="What you sent in a month, and what it cost."
        actions={
          <>
            <label htmlFor="mis-month" className="sr-only">Month</label>
            <select
              id="mis-month"
              className="h-11 rounded-md border border-input bg-background px-2 text-sm md:h-9"
              value={month}
              onChange={(e) => setMonth(e.target.value)}
            >
              {months.map((m) => (
                <option key={m} value={m}>{m}{m === months[0] ? " (so far)" : ""}</option>
              ))}
            </select>
            {/* carries the sweep while the month is read, so the thing pressed says it is working */}
            <Button className="relative h-11 md:h-9" onClick={() => showMonth(month)}
              aria-busy={loading || undefined}>
              Show
              {loading && <span className="tab-busy-bar inset on-fill" aria-hidden />}
            </Button>
            {changed && !loading && (
              <span className="text-xs text-muted-foreground">Changed — press Show</span>
            )}
            <a
              className="inline-flex h-11 items-center rounded-md border border-border px-3 text-sm
                         hover:bg-accent md:h-9"
              //the month on screen, never an unread draft: the file must match the figures beside it
              href={`/api/mis/statement/export?month=${shown ?? month}${forAccount}`}
            >
              Download CSV
            </a>
          </>
        }
      />

      <StaleNote stale={stale} />
      {/* still reading a lot of data in the background: a calm card, never the timeout error */}
      {busy && !data && <BreathingCard what={`${shown ?? month} of your traffic`} retryAfter={state.retryAfter} />}
      {loading && !busy && !data && <p className="text-sm text-muted-foreground">Loading…</p>}
      <ErrorCard error={error} />

      {data && (
        <>
          <Card>
            <CardHeader bar>
              <CardTitle>{data.label}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {empty ? (
                <p className="text-sm text-muted-foreground">
                  Nothing was sent in this period, so there is nothing to bill.
                </p>
              ) : (
                <>
                  <div className="grid gap-3 sm:grid-cols-3">
                    <Figure label="Amount" value={money(data.totalAmount, currency)} strong />
                    <Figure
                      label="Messages sent"
                      value={data.totalSubmitted.toLocaleString()}
                    />
                    <Figure
                      label="Delivered"
                      value={
                        data.totalDelivered.toLocaleString()
                        + (rate == null ? "" : ` · ${rate.toFixed(1)}%`)
                      }
                      //the other outcomes are computed for every line and were never shown, so a
                      //customer could see 374 of 401 delivered with no account of the other 27
                      hint={
                        outcomes.length > 0
                          ? outcomes
                              .map(([word, n]) => `${n.toLocaleString()} ${word}`)
                              .join(", ")
                          : undefined
                      }
                    />
                  </div>
                  {data.totalUnrated > 0 && (
                    <p className="text-xs text-muted-foreground">
                      {data.totalUnrated.toLocaleString()} message
                      {data.totalUnrated === 1 ? "" : "s"} went out with no price applied and
                      {data.totalUnrated === 1 ? " is" : " are"} not in the amount above.
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground">
                    Billed on messages <strong>submitted</strong>, not on delivery. Delivery figures
                    keep moving as receipts arrive; the amount does not.
                  </p>
                </>
              )}
            </CardContent>
          </Card>

          {/* its own row, and labelled as now rather than as part of the month above */}
          <Card>
            <CardContent className="flex flex-wrap items-baseline justify-between gap-3 py-3">
              {data.billingMode === "POSTPAID" ? (
                <>
                  <span className="text-sm text-muted-foreground">
                    Credit limit right now. Billed in arrears — this is how much you may run up.
                  </span>
                  <span className="text-sm tabular-nums">
                    {data.creditLimit == null ? "—" : money(data.creditLimit, currency)}
                  </span>
                </>
              ) : (
                <>
                  <span className="text-sm text-muted-foreground">
                    Credit remaining right now, not part of this period.
                  </span>
                  <span className="text-sm tabular-nums">
                    {data.balance == null ? "—" : money(data.balance, currency)}
                  </span>
                </>
              )}
            </CardContent>
          </Card>

          {data.days.length > 0 && (
            <Card>
              <CardHeader bar>
                <CardTitle>Billed per day</CardTitle>
                <p className="text-xs text-muted-foreground">
                  The same window the amount above covers, day by day.
                </p>
              </CardHeader>
              <CardContent>
                <ChartContainer config={chartConfig} className="h-40 w-full">
                  <BarChart data={data.days} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false}
                      stroke="var(--color-border)" />
                    <XAxis dataKey="day" tickLine={false} axisLine={false}
                      tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                      tickFormatter={(v: string) => v.slice(8)} interval="preserveStartEnd" />
                    {/* the axis divides by the scale exactly once, here, for the reason the
                        operator's copy of this gives: the values stay scaled integers everywhere
                        else, which is what stops a rounding step creeping in */}
                    <YAxis tickLine={false} axisLine={false} width={52}
                      tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                      tickFormatter={(v: number) => (v / 10_000).toFixed(0)} />
                    <ChartTooltip content={<ChartTooltipContent indicator="dot" />} />
                    <Bar {...ANIMATION} dataKey="price" fill={chartConfig.price.color} radius={2} />
                  </BarChart>
                </ChartContainer>
              </CardContent>
            </Card>
          )}

          {data.lines.length > 0 && (
            <Card>
              <CardHeader bar>
                <CardTitle>By product</CardTitle>
              </CardHeader>
              <CardContent>
                <TableInCard className="tabular-nums">
                  <THead>
                    <tr>
                      <TH>Product</TH>
                      <TH>Sent</TH>
                      <TH>Delivered</TH>
                      <TH>Failed</TH>
                      <TH>Expired</TH>
                      <TH>Pending</TH>
                      {/* both of these were summed in the route and thrown away. "Not billed" is
                          what reconciles a product's Sent against its Amount */}
                      <TH>Not billed</TH>
                      <TH>Amount</TH>
                    </tr>
                  </THead>
                  <TBody>
                    {data.lines.map((l) => (
                      <TR key={l.product || "(none)"}>
                        <TD>{l.product || "No product"}</TD>
                        <TD>{l.submitted.toLocaleString()}</TD>
                        <TD>{l.delivered.toLocaleString()}</TD>
                        <TD>{l.failed.toLocaleString()}</TD>
                        <TD>{l.expired.toLocaleString()}</TD>
                        <TD>{l.pending.toLocaleString()}</TD>
                        <TD>{l.unrated.toLocaleString()}</TD>
                        <TD className="font-mono">{money(l.amount, currency)}</TD>
                      </TR>
                    ))}
                  </TBody>
                  {data.lines.length > 1 && (
                    <tfoot className="border-t border-border">
                      <TR className="font-medium">
                        <TD>Total</TD>
                        <TD>{data.totalSubmitted.toLocaleString()}</TD>
                        <TD>{data.totalDelivered.toLocaleString()}</TD>
                        <TD>{sum(data.lines, "failed")}</TD>
                        <TD>{sum(data.lines, "expired")}</TD>
                        <TD>{sum(data.lines, "pending")}</TD>
                        <TD>{data.totalUnrated.toLocaleString()}</TD>
                        <TD className="font-mono">{money(data.totalAmount, currency)}</TD>
                      </TR>
                    </tfoot>
                  )}
                </TableInCard>
              </CardContent>
            </Card>
          )}

          {data.closed.length > 0 && (
            <Card>
              <CardHeader bar>
                <CardTitle>Invoiced periods</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm">
                  {data.closed.map((c) => (
                    <li key={c.label}
                      className="flex flex-wrap items-baseline justify-between gap-3 border-t
                                 border-border py-2 first:border-t-0 first:pt-0">
                      <div className="min-w-0">
                        <button type="button" className="underline underline-offset-2
                          hover:text-foreground" onClick={() => { setMonth(c.label); showMonth(c.label); }}>
                          {c.label}
                        </button>
                        {/* both were returned by closedPeriods and dropped. The date is what tells
                            a customer whether an invoice they are holding is this one */}
                        <p className="text-xs text-muted-foreground">
                          Invoiced {formatDate(c.closedAt)}
                          {c.note ? ` · ${c.note}` : ""}
                        </p>
                      </div>
                      <span className="tabular-nums">{money(c.invoiced, currency)}</span>
                    </li>
                  ))}
                </ul>
                <p className="mt-2 text-xs text-muted-foreground">
                  A closed period is final. Anything landing against one afterwards appears as an
                  adjustment on the period that follows it.
                </p>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </>
  );
}

/** Totals a column across the product lines. The route only sums the three it already exposed. */
function sum(lines: Line[], key: "failed" | "expired" | "pending"): string {
  return lines.reduce((n, l) => n + l[key], 0).toLocaleString();
}

function Figure({ label, value, hint, strong }: {
  label: string; value: string; hint?: string; strong?: boolean;
}) {
  return (
    <div className="min-w-0 rounded-md bg-muted/40 px-4 py-3">
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className={"text-figure tabular-nums" + (strong ? "" : " font-medium")}>{value}</p>
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}
