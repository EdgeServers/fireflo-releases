"use client";
import { useMemo } from "react";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, type ChartConfig } from "@/components/ui/chart";
import { money } from "@/lib/format";
import { seriesBars, topAccounts, type RevenueBucketLike, type SeriesBar } from "@/lib/revenue-chart";
import type { Range } from "./useControlData";

const ANIMATION = { isAnimationActive: false } as const;
const TICK = { fontSize: 11, fill: "var(--color-muted-foreground)" };

const seriesConfig = {
  cost: { label: "Cost", color: "var(--color-chart-1)" },
  margin: { label: "Margin", color: "var(--color-success)" },
} satisfies ChartConfig;

const accountConfig = {
  revenue: { label: "Revenue", color: "var(--color-chart-2)" },
} satisfies ChartConfig;

const STEP: Record<Range, string> = { "1h": "by 5 minutes", "24h": "by hour", "7d": "by day", "30d": "by day" };

/**
 * The two charts above the Revenue table: revenue over the period in its own steps, each bar its
 * cost with the margin on top, and the accounts that brought it in. The series comes from
 * `revenue-series` (the same seam and arithmetic as the table); the accounts from the table's rows.
 */
export function RevenueCharts({
  range,
  series,
  rows,
}: {
  range: Range;
  series: readonly RevenueBucketLike[];
  rows: readonly { accountId: string | null; revenue: number }[];
}) {
  const bars = useMemo(() => seriesBars(series), [series]);
  const accounts = useMemo(() => topAccounts(rows), [rows]);

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
      <Card className="min-w-0">
        <CardHeader>
          <CardTitle>Revenue {STEP[range]}</CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer config={seriesConfig} className="h-60 w-full">
            <BarChart data={bars} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid vertical={false} stroke="var(--color-border)" strokeDasharray="3 3" />
              <XAxis dataKey="label" tickLine={false} axisLine={false} tick={TICK} interval="preserveStartEnd" />
              <YAxis tickLine={false} axisLine={false} tick={TICK} width={64} tickFormatter={(v: number) => money(v)} />
              <ChartTooltip content={<SeriesTooltip />} />
              <Bar {...ANIMATION} dataKey="cost" stackId="r" fill={seriesConfig.cost.color} maxBarSize={28} />
              <Bar {...ANIMATION} dataKey="margin" stackId="r" fill={seriesConfig.margin.color} maxBarSize={28} radius={[3, 3, 0, 0]} />
            </BarChart>
          </ChartContainer>
          <Legend items={[seriesConfig.cost, seriesConfig.margin]} />
        </CardContent>
      </Card>

      <Card className="min-w-0">
        <CardHeader>
          <CardTitle>Top accounts</CardTitle>
        </CardHeader>
        <CardContent>
          {accounts.length === 0 ? (
            <p className="text-sm text-muted-foreground">Nothing billed in this period.</p>
          ) : (
            <ChartContainer config={accountConfig} className="w-full" style={{ height: Math.max(140, accounts.length * 30 + 30) }}>
              <BarChart data={accounts} layout="vertical" margin={{ top: 0, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid horizontal={false} stroke="var(--color-border)" strokeDasharray="3 3" />
                <XAxis type="number" tickLine={false} axisLine={false} tick={TICK} tickFormatter={(v: number) => money(v)} />
                <YAxis type="category" dataKey="account" tickLine={false} axisLine={false} tick={TICK} width={110} />
                <ChartTooltip content={<AccountTooltip />} />
                <Bar {...ANIMATION} dataKey="revenue" fill={accountConfig.revenue.color} barSize={16} radius={[0, 3, 3, 0]} />
              </BarChart>
            </ChartContainer>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

type TipProps = { active?: boolean; label?: string; payload?: { payload?: unknown }[] };
const TIP = "grid min-w-44 gap-1 rounded-lg border border-border bg-card px-2.5 py-1.5 text-xs shadow-lg";

function Row({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <span className="flex items-center gap-2">
      {color && <span className="h-2 w-2 shrink-0 rounded-sm" style={{ background: color }} aria-hidden />}
      <span className="text-muted-foreground">{label}</span>
      <span className="ml-auto font-mono tabular-nums">{value}</span>
    </span>
  );
}

function SeriesTooltip({ active, payload, label }: TipProps) {
  if (!active || !payload?.length) return null;
  const b = payload[0].payload as SeriesBar;
  return (
    <div className={TIP}>
      <span className="font-medium">{label}</span>
      <Row label="Revenue" value={money(b.revenue)} />
      <Row label="Cost" value={money(b.cost)} color={seriesConfig.cost.color} />
      <Row label={b.loss ? "Loss" : "Margin"} value={money(b.revenue - b.cost)} color={b.loss ? undefined : seriesConfig.margin.color} />
    </div>
  );
}

function AccountTooltip({ active, payload }: TipProps) {
  if (!active || !payload?.length) return null;
  const a = payload[0].payload as { account: string; revenue: number };
  return (
    <div className={TIP}>
      <span className="font-medium">{a.account}</span>
      <Row label="Revenue" value={money(a.revenue)} color={accountConfig.revenue.color} />
    </div>
  );
}

function Legend({ items }: { items: { label: string; color: string }[] }) {
  return (
    <div className="mt-2 flex flex-wrap gap-x-4 text-xs text-muted-foreground">
      {items.map((i) => (
        <span key={i.label} className="inline-flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-sm" style={{ background: i.color }} aria-hidden />
          {i.label}
        </span>
      ))}
    </div>
  );
}
