"use client";
import { useEffect, useState } from "react";
import { Check, Copy } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Copies a string, and says that it did.
 *
 * <p>The confirmation is the whole component. `navigator.clipboard.writeText` succeeds silently, so
 * without a visible change the only way to know whether a click registered is to paste somewhere and
 * look — which people do, and then click twice more.
 *
 * <p>Falls back to a hidden textarea and `execCommand("copy")` when the clipboard API is missing.
 * That API exists only in a secure context, and panels are run over plain HTTP on a LAN (the
 * staging server is), where every copy button silently did nothing. "Copied" is still only said
 * when one of the two reports success.
 */
export function CopyButton({
  value,
  className,
  label = "Copy",
}: {
  value: string;
  className?: string;
  /** What is being copied, for the accessible name — "Copy request", "Copy your login". */
  label?: string;
}) {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!copied) {
      return;
    }
    const timer = setTimeout(() => setCopied(false), 1_600);
    return () => clearTimeout(timer);
  }, [copied]);

  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={async () => {
        //no clipboard, no confirmation. Saying "copied" when nothing was is worse than saying
        //nothing, because the paste that follows is somebody else's text
        setCopied(await copyText(value));
      }}
      className={cn(
        "inline-flex items-center gap-1 rounded px-1.5 py-1 text-xs transition-colors",
        copied
          ? "text-success"
          : "text-muted-foreground hover:bg-accent hover:text-foreground",
        className
      )}
    >
      {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
      {copied ? "Copied" : null}
    </button>
  );
}

/**
 * Puts `text` on the clipboard: the clipboard API where the page is a secure context, else a hidden
 * textarea, selected and copied -- the only way that works over plain HTTP. True when it worked.
 */
export async function copyText(text: string): Promise<boolean> {
  if (window.isSecureContext && navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      //denied: try the old way below
    }
  }
  const area = document.createElement("textarea");
  area.value = text;
  area.setAttribute("readonly", "");
  //off screen, not display:none -- a hidden element cannot be selected
  area.style.position = "fixed";
  area.style.top = "-1000px";
  area.style.opacity = "0";
  document.body.appendChild(area);
  const focused = document.activeElement as HTMLElement | null;
  area.select();
  area.setSelectionRange(0, text.length);
  let ok = false;
  try {
    ok = document.execCommand("copy");
  } catch {
    ok = false;
  }
  area.remove();
  focused?.focus?.();
  return ok;
}
