"use client";
import { useLinkStatus } from "next/link";
import { Spinner } from "@/components/ui/spinner";
import { cn } from "@/lib/utils";

/**
 * The spinner for one link while its page loads -- inside the `<Link>`, where `useLinkStatus` can
 * see it. Only the clicked row turns; nothing else in the menu moves or dims. Renders `fallback`
 * (a count, say) when nothing is pending, so the spinner takes its place rather than shifting it.
 */
export function PendingMark({ fallback, className }: { fallback?: React.ReactNode; className?: string }) {
  const { pending } = useLinkStatus();
  if (!pending) {
    return <>{fallback}</>;
  }
  return <Spinner label="Opening" className={cn("text-muted-foreground", className)} />;
}

/**
 * For a link drawn as a tab: while its page loads, the tab's underline glows and sweeps
 * (`.tab-busy-bar` in globals.css) -- a spinner beside the label pushed it and broke the tab row.
 * The link must be `relative`.
 */
export function PendingUnderline() {
  const { pending } = useLinkStatus();
  return pending ? <span className="tab-busy-bar" aria-hidden /> : null;
}
