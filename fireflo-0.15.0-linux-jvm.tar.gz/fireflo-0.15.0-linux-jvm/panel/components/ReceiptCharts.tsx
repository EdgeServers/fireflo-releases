"use client";
import { useMemo } from "react";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, type ChartConfig } from "@/components/ui/chart";
import { outcomeBars, timingBars, type ChartRow } from "@/lib/receipt-chart";
import { count } from "@/lib/format";

const ANIMATION = { isAnimationActive: false } as const;
const TICK = { fontSize: 11, fill: "var(--color-muted-foreground)" };

/** The status colours keep their meaning across the panel: delivered green, failed red. */
const outcomeConfig = {
  delivered: { label: "Delivered", color: "var(--color-success)" },
  failed: { label: "Failed", color: "var(--color-destructive)" },
  gaveUp: { label: "Gave up on", color: "var(--color-chart-3)" },
  open: { label: "Still open", color: "var(--color-muted-foreground)" },
  refused: { label: "Refused", color: "var(--color-chart-1)" },
} satisfies ChartConfig;

const timingConfig = {
  median: { label: "Median", color: "var(--color-chart-2)" },
  p90: { label: "90th percentile", color: "color-mix(in srgb, var(--color-chart-2) 45%, transparent)" },
} satisfies ChartConfig;

const OUTCOMES = ["delivered", "failed", "gaveUp", "open", "refused"] as const;

function seconds(v: number): string {
  return v < 10 ? `${Math.round(v * 10) / 10}s` : `${Math.round(v)}s`;
}

/**
 * The two charts above the Receipts table: how each vendor's attempts ended, as shares of what it
 * was sent, and how long its receipts take. Drawn from the rows the table shows (`lib/receipt-chart.ts`),
 * so the two always agree; they follow the period buttons with it.
 */
export function ReceiptCharts({ rows }: { rows: readonly ChartRow[] }) {
  const outcomes = useMemo(() => outcomeBars(rows), [rows]);
  const timings = useMemo(() => timingBars(rows), [rows]);
  //a bar per vendor, 32px each, so a long list does not squash them
  const height = (n: number) => Math.max(140, n * 32 + 40);

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
      <Card className="min-w-0">
        <CardHeader>
          <CardTitle>How attempts ended, by vendor</CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer config={outcomeConfig} className="w-full" style={{ height: height(outcomes.length) }}>
            <BarChart data={outcomes} layout="vertical" margin={{ top: 0, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid horizontal={false} stroke="var(--color-border)" strokeDasharray="3 3" />
              <XAxis type="number" domain={[0, 100]} tickLine={false} axisLine={false} tick={TICK}
                tickFormatter={(v: number) => `${v}%`} />
              <YAxis type="category" dataKey="vendor" tickLine={false} axisLine={false} tick={TICK} width={110} />
              <ChartTooltip content={<OutcomeTooltip />} />
              {OUTCOMES.map((k) => (
                <Bar key={k} {...ANIMATION} dataKey={k} stackId="o" fill={outcomeConfig[k].color} barSize={18} />
              ))}
            </BarChart>
          </ChartContainer>
          <Legend config={outcomeConfig} keys={OUTCOMES} />
        </CardContent>
      </Card>

      <Card className="min-w-0">
        <CardHeader>
          <CardTitle>Time to receipt</CardTitle>
        </CardHeader>
        <CardContent>
          {timings.length === 0 ? (
            <p className="text-sm text-muted-foreground">No receipts in this period yet.</p>
          ) : (
            <>
              <ChartContainer config={timingConfig} className="w-full" style={{ height: height(timings.length) }}>
                <BarChart data={timings} layout="vertical" margin={{ top: 0, right: 8, left: 0, bottom: 0 }}>
                  <CartesianGrid horizontal={false} stroke="var(--color-border)" strokeDasharray="3 3" />
                  <XAxis type="number" tickLine={false} axisLine={false} tick={TICK} tickFormatter={seconds} />
                  <YAxis type="category" dataKey="vendor" tickLine={false} axisLine={false} tick={TICK} width={110} />
                  <ChartTooltip content={<TimingTooltip />} />
                  <Bar {...ANIMATION} dataKey="median" fill={timingConfig.median.color} barSize={8} radius={[0, 3, 3, 0]} />
                  <Bar {...ANIMATION} dataKey="p90" fill={timingConfig.p90.color} barSize={8} radius={[0, 3, 3, 0]} />
                </BarChart>
              </ChartContainer>
              <Legend config={timingConfig} keys={["median", "p90"] as const} />
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function Legend<K extends string>({ config, keys }: { config: Record<K, { label: string; color: string }>; keys: readonly K[] }) {
  return (
    <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
      {keys.map((k) => (
        <span key={k} className="inline-flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-sm" style={{ background: config[k].color }} aria-hidden />
          {config[k].label}
        </span>
      ))}
    </div>
  );
}

type TipProps = { active?: boolean; label?: string; payload?: { dataKey?: string | number; value?: unknown; payload?: unknown }[] };

const TIP = "grid min-w-44 gap-1 rounded-lg border border-border bg-card px-2.5 py-1.5 text-xs shadow-lg";

function TipRow({ color, label, value }: { color: string; label: string; value: string }) {
  return (
    <span className="flex items-center gap-2">
      <span className="h-2 w-2 shrink-0 rounded-sm" style={{ background: color }} aria-hidden />
      <span className="text-muted-foreground">{label}</span>
      <span className="ml-auto font-mono tabular-nums">{value}</span>
    </span>
  );
}

/** A vendor's split: each outcome's count and share of what it was sent. */
function OutcomeTooltip({ active, payload, label }: TipProps) {
  if (!active || !payload?.length) return null;
  const bar = payload[0].payload as ReturnType<typeof outcomeBars>[number];
  return (
    <div className={TIP}>
      <span className="font-medium">{label} · {count(bar.sent)} sent</span>
      {OUTCOMES.filter((k) => bar.counts[k] > 0).map((k) => (
        <TipRow key={k} color={outcomeConfig[k].color} label={outcomeConfig[k].label}
          value={`${count(bar.counts[k])} · ${Math.round(bar[k] * 10) / 10}%`} />
      ))}
    </div>
  );
}

function TimingTooltip({ active, payload, label }: TipProps) {
  if (!active || !payload?.length) return null;
  return (
    <div className={TIP}>
      <span className="font-medium">{label}</span>
      {payload.map((p) => {
        const k = p.dataKey as "median" | "p90";
        return <TipRow key={k} color={timingConfig[k].color} label={timingConfig[k].label} value={seconds(Number(p.value))} />;
      })}
    </div>
  );
}
