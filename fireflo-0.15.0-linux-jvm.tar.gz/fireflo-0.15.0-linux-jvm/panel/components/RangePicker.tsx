"use client";
import { cn } from "@/lib/utils";
import { RANGES, type Range } from "./useControlData";

/**
 * The period buttons. `busy` while the chosen period is being fetched: the selected button's bottom
 * edge glows and a light sweeps along it, and the group says so to a screen reader. The buttons stay live -- a
 * second click starts its own fetch and the first is dropped (see `useStats`).
 */
export function RangePicker({ value, onChange, busy = false }: { value: Range; onChange: (r: Range) => void; busy?: boolean }) {
  return (
    <div className="inline-flex rounded-lg border border-border bg-card p-0.5" aria-busy={busy || undefined}>
      {RANGES.map((r) => (
        <button
          key={r.value}
          onClick={() => onChange(r.value)}
          className={cn(
            "relative rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
            value === r.value
              ? "bg-primary text-primary-foreground"
              : "text-muted-foreground hover:text-foreground"
          )}
        >
          {r.label}
          {/* loading: the chosen button's bottom edge glows and sweeps (globals.css), no spinner
              beside the label to push it */}
          {busy && value === r.value && <span className="tab-busy-bar inset on-fill" aria-hidden />}
        </button>
      ))}
    </div>
  );
}
