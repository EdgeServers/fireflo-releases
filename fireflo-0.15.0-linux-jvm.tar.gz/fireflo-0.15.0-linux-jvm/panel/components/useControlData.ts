"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { LatestWins } from "@/lib/latest-wins";

export type Range = "1h" | "24h" | "7d" | "30d";

/** Shortest first: the last hour is the first tab, and what a page opens on until its user picks another. */
export const RANGES: { value: Range; label: string }[] = [
  { value: "1h", label: "1 hour" },
  { value: "24h", label: "24 hours" },
  { value: "7d", label: "7 days" },
  { value: "30d", label: "30 days" },
];

/** "30 days", for a sentence about the period. */
export function periodLabel(range: string): string {
  return RANGES.find((r) => r.value === range)?.label ?? range;
}

/** The values alone, once: a stable list for {@link usePeriod}. */
export const RANGE_VALUES: readonly Range[] = RANGES.map((r) => r.value);

/**
 * Thirty seconds: the overview is served from a snapshot the server refreshes on its own, so a poll
 * is a read of memory and the number of tabs no longer sets the database's load. The other control
 * endpoints still query, and a poll of them at this rate is what the snapshot route used to cost.
 */
const REFRESH_MS = 30_000;

/**
 * How often a period is polled: the last hour and the day every 30 s, a week or a month every
 * 5 min -- the server keeps those answers that long anyway (stats-cache.ts), and polling a 30-day
 * view faster only re-reads the same figures. A switch or a refresh still fetches at once.
 */
export function pollMs(range: string): number {
  return range === "7d" || range === "30d" ? 5 * 60_000 : REFRESH_MS;
}

/**
 * A stat or chart from `GET /api/stats/<metric>`, kept fresh -- the one route behind every one of
 * them, for the operator panel and the portal alike (`lib/stats-route.ts`).
 *
 * <p>Polling stops while the tab is hidden and resumes with an immediate fetch, so a dashboard left
 * open overnight is not still querying a billing database every minute.
 *
 * <p><b>Every switch is fetched, and only the newest answer lands.</b> Changing the period (or any
 * parameter) aborts the request in flight and starts one for the new choice; a late answer for the
 * old choice is dropped (`LatestWins`). This used to skip a fetch while one was in flight, so a
 * switch made during a background poll loaded nothing and the page showed the old period until the
 * next poll, up to 30 seconds later.
 *
 * @return `data` (kept on screen while the next answer loads, so the page never blanks), `loading`
 *     (the first answer is not in yet), `switching` (a change the user made is still being fetched
 *     -- what the button-group spinner shows; background polls never set it), `error`, `reload`
 */
export function useStats<T>(metric: string, range: Range | string, query?: Record<string, string>) {
  //a string, so a caller's fresh object each render does not refetch
  const extra = query ? `&${new URLSearchParams(query).toString()}` : "";
  const url = `/api/stats/${encodeURIComponent(metric)}?range=${encodeURIComponent(range)}${extra}`;
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [switching, setSwitching] = useState(false);
  //set when the server answered with an older result because its latest read failed
  const [stale, setStale] = useState<{ at: string; reason: string } | null>(null);
  //the server is still reading a lot of data: the page shows its "taking a breath" card, not an error
  const [busy, setBusy] = useState(false);
  const retry = useRef<ReturnType<typeof setTimeout> | null>(null);
  //the retry timer calls the latest fetch through this, rather than the one that scheduled it
  const again = useRef<() => void>(() => undefined);
  const gate = useRef(new LatestWins());
  const inFlight = useRef<AbortController | null>(null);

  const fetchNow = useCallback(
    async (userAsked: boolean) => {
      //a poll never interrupts an answer the user is waiting for; a switch always does
      if (!userAsked && inFlight.current) return;
      inFlight.current?.abort();
      const controller = new AbortController();
      inFlight.current = controller;
      const ticket = gate.current.begin();
      if (userAsked) setSwitching(true);
      try {
        const res = await fetch(url, { cache: "no-store", signal: controller.signal });
        const json = await res.json();
        if (!gate.current.isCurrent(ticket)) return;
        //202: still being read in the background -- ask again when the server says, no error shown
        //(a statement timeout reads the same way: the next try usually finds it kept)
        const tooSlow = !res.ok && /statement timeout/i.test(String(json?.error ?? ""));
        if (res.status === 202 || tooSlow) {
          setBusy(true);
          setError("");
          if (retry.current) clearTimeout(retry.current);
          retry.current = setTimeout(() => again.current(), (Number(json?.retryAfter) || 15) * 1000);
          return;
        }
        setBusy(false);
        if (!res.ok) {
          //surface what the server said; an operator needs "permission denied for table cdr_submit"
          //rather than a generic failure
          setError(json?.error ?? `Request failed (${res.status})`);
          return;
        }
        setData(json.data as T);
        setStale(json.stale ?? null);
        setError("");
      } catch (err) {
        if (controller.signal.aborted || !gate.current.isCurrent(ticket)) return;
        setError(err instanceof Error ? err.message : "Request failed");
      } finally {
        if (gate.current.isCurrent(ticket)) {
          inFlight.current = null;
          setLoading(false);
          setSwitching(false);
        }
      }
    },
    [url]
  );

  const reload = useCallback(() => fetchNow(true), [fetchNow]);
  useEffect(() => {
    again.current = () => void fetchNow(false);
  }, [fetchNow]);

  useEffect(() => {
    //a new url is a user's change (period, account, listener): fetched at once, with the spinner
    void fetchNow(true);
    const poll = () => void fetchNow(false);

    let timer: ReturnType<typeof setInterval> | null = null;
    const start = () => {
      if (timer === null) timer = setInterval(poll, pollMs(String(range)));
    };
    const stop = () => {
      if (timer !== null) {
        clearInterval(timer);
        timer = null;
      }
    };
    const onVisibility = () => {
      if (document.hidden) {
        stop();
      } else {
        poll();
        start();
      }
    };

    if (!document.hidden) start();
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      stop();
      document.removeEventListener("visibilitychange", onVisibility);
      inFlight.current?.abort();
      inFlight.current = null;
      if (retry.current) clearTimeout(retry.current);
    };
  }, [fetchNow, range]);

  return { data, error, loading, switching, stale, busy, reload };
}

/** The old name, kept so callers move over one at a time. */
export const useControlData = useStats;
