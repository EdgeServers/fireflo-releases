"use client";
import { FILTER_WIDTH } from "@/lib/filter-widths";
import { useEffect, useRef, useState } from "react";
import { ChevronDown, Search, SlidersHorizontal, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Select } from "@/components/ui/select";
import { Field } from "@/components/ui/field";
import { Segmented } from "@/components/ui/segmented";
import { Drawer } from "@/components/ui/drawer";
import {
  EMPTY_FILTERS,
  FINAL_STATES,
  RANGES,
  type CdrFilterForm,
  CUSTOM_RANGE,
  classifyFind,
  countHiddenFilters,
  filterChips,
  hasActiveFilters,
  withoutChip,
} from "@/lib/cdr-request";
import { FINAL_STATE_LABELS, labelFor } from "@/lib/labels";

type Set = <K extends keyof CdrFilterForm>(key: K, next: CdrFilterForm[K]) => void;

const ROWS_OPTIONS = [
  { value: "first", label: "Per message", title: "One row per message" },
  {
    value: "all",
    label: "Every attempt",
    title: "One row per vendor attempt, including retries and long-message segments",
  },
] as const;

/**
 * The filter form: one row on a desktop, a search box and a right-hand drawer on a phone.
 *
 * <p>Holds a draft and only lifts it on submit. Filtering as you type would fire a database query
 * per keystroke against a pool of eight connections shared with the dashboard's polling, and the
 * results would flicker between four different answers before settling on the one you meant. The
 * exceptions are the chips and the Rows toggle, which change one thing the reader can see changing.
 *
 * <p>Free text rather than dropdowns for every dimension — see the note in `cdr-queries.ts`. The
 * two worker dimensions, ingress server and vendor, get a datalist of the configured workers' names
 * on top of that: the value is still the exact name the record carries, but nobody has to remember
 * that a listener is `smppserver.smpp` and a vendor `smppclient.x`.
 *
 * <p>The page remounts this bar with every applied filter set, so the draft always starts from what
 * is applied; the Filters panel starts open when something behind it is set, or it would hide the
 * very filter that explains the list.
 */
export function CdrFilterBar({
  value,
  onApply,
  busy,
}: {
  value: CdrFilterForm;
  onApply: (next: CdrFilterForm) => void;
  busy: boolean;
}) {
  const [draft, setDraft] = useState<CdrFilterForm>(value);
  const [open, setOpen] = useState(() => countHiddenFilters(value) > 0);
  const [drawer, setDrawer] = useState(false);
  //what the drawer opened on, so closing it without "Show results" leaves the bar as it was
  const beforeDrawer = useRef<CdrFilterForm>(value);
  const names = useWorkerNames();

  const set: Set = (key, next) => setDraft((d) => ({ ...d, [key]: next }));

  function submit(e: React.FormEvent) {
    e.preventDefault();
    onApply(draft);
  }

  function clear() {
    //the range survives a clear: resetting it to 24h as well would look like the filters failed to
    //apply rather than that they were removed
    const next = { ...EMPTY_FILTERS, range: draft.range };
    setDraft(next);
    onApply(next);
  }

  function openDrawer() {
    beforeDrawer.current = draft;
    setDrawer(true);
  }

  function dismissDrawer() {
    setDraft(beforeDrawer.current);
    setDrawer(false);
  }

  const hidden = countHiddenFilters(draft);
  //on a phone everything but Find is in the drawer, so its badge counts all of it
  const inDrawer = hidden + (draft.outcome ? 1 : 0) + (draft.attempts === "all" ? 1 : 0)
    + (draft.range !== EMPTY_FILTERS.range ? 1 : 0);

  return (
    <Card>
      <CardContent className="py-4">
        <form onSubmit={submit} className="space-y-3">
          {/* ── desktop: one row ── */}
          <div className="hidden flex-wrap items-end gap-3 md:flex">
            <PeriodFields draft={draft} setDraft={setDraft} set={set} />
            <OutcomeField draft={draft} set={set} className={FILTER_WIDTH.choice} />
            <FindField draft={draft} setDraft={setDraft} className="min-w-56 flex-1" />
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen((o) => !o)}
              aria-expanded={open}
              className="gap-2"
            >
              <SlidersHorizontal className="h-4 w-4" />
              Filters
              {hidden > 0 && <CountBadge n={hidden} />}
            </Button>
            <Button type="submit" disabled={busy} className="gap-2">
              <Search className="h-4 w-4" />
              {busy ? "Searching…" : "Search"}
            </Button>
          </div>

          {/* ── phone: Find and the drawer's button ── */}
          <div className="flex items-end gap-2 md:hidden">
            <FindField draft={draft} setDraft={setDraft} className="min-w-0 flex-1" />
            <Button type="button" variant="outline" onClick={openDrawer} className="shrink-0 gap-1.5 px-3"
              aria-label={inDrawer ? `Filters, ${inDrawer} set` : "Filters"}>
              <SlidersHorizontal className="h-4 w-4" />
              {inDrawer > 0 && <CountBadge n={inDrawer} />}
            </Button>
            <Button type="submit" disabled={busy} size="icon" aria-label="Search" className="shrink-0">
              <Search className="h-4 w-4" />
            </Button>
          </div>

          <ChipRow value={value} onApply={onApply} onClear={clear} busy={busy} />

          {open && (
            <div className="hidden border-t border-border pt-4 md:block">
              <FilterGroups draft={draft} set={set} names={names} />
            </div>
          )}
        </form>

        <Drawer
          open={drawer}
          onClose={dismissDrawer}
          title="Filters"
          footer={
            <div className="grid grid-cols-[1fr_1.4fr] gap-2">
              <Button type="button" variant="outline" onClick={() => {
                setDrawer(false);
                clear();
              }}>
                Clear
              </Button>
              <Button type="button" disabled={busy} onClick={() => {
                setDrawer(false);
                onApply(draft);
              }}>
                Show results
              </Button>
            </div>
          }
        >
          <div className="space-y-4">
            <div className="grid gap-3">
              <PeriodFields draft={draft} setDraft={setDraft} set={set} stacked />
              <OutcomeField draft={draft} set={set} />
              <Field label="Rows">
                <Segmented
                  label="Rows"
                  fill
                  options={ROWS_OPTIONS}
                  value={draft.attempts}
                  onChange={(next) => set("attempts", next)}
                />
              </Field>
            </div>
            <FilterGroups draft={draft} set={set} names={names} collapsible />
          </div>
        </Drawer>
      </CardContent>
    </Card>
  );
}

/**
 * The applied filters as chips, and on a desktop the Rows toggle at the end of the same row.
 *
 * <p>Chips show what is applied, not the draft: they answer "why is the list this list". Removing
 * one applies at once, because the reader can see exactly what changed.
 */
function ChipRow({
  value,
  onApply,
  onClear,
  busy,
}: {
  value: CdrFilterForm;
  onApply: (next: CdrFilterForm) => void;
  onClear: () => void;
  /** The list is being fetched: the Rows toggle shows it, since that is what the reader just did. */
  busy: boolean;
}) {
  const chips = filterChips(value).filter((c) => c.key !== "attempts");
  return (
    <div className="flex items-center gap-2">
      <div className="-mx-1 flex min-w-0 flex-1 gap-1.5 overflow-x-auto px-1 md:flex-wrap md:overflow-visible">
        {/* on a phone the period is in the drawer, so the row says which one applies */}
        <span className="inline-flex shrink-0 items-center rounded-full border border-border bg-muted px-2.5 py-1 text-xs md:hidden">
          {periodLabel(value)}
        </span>
        {chips.map((chip) => (
          <span key={chip.key}
            className="inline-flex max-w-full shrink-0 items-center gap-1 rounded-full border border-border bg-muted py-0.5 pl-2.5 pr-1 text-xs">
            <span className="truncate">{chipLabel(chip.key, chip.value)}</span>
            <button
              type="button"
              aria-label={`Remove ${chipLabel(chip.key, chip.value)}`}
              onClick={() => onApply(withoutChip(value, chip.key))}
              className="rounded-full p-1 text-muted-foreground hover:bg-background hover:text-foreground"
            >
              <X className="h-3 w-3" />
            </button>
          </span>
        ))}
        {hasActiveFilters(value) && chips.length > 0 && (
          <button type="button" onClick={onClear}
            className="shrink-0 px-1 text-xs text-muted-foreground underline-offset-4 hover:text-foreground hover:underline">
            Clear all
          </button>
        )}
      </div>
      <Segmented
        label="Rows"
        className="hidden shrink-0 md:inline-flex"
        options={ROWS_OPTIONS}
        value={value.attempts}
        onChange={(next) => onApply({ ...value, attempts: next })}
        busy={busy}
      />
    </div>
  );
}

function CountBadge({ n }: { n: number }) {
  return (
    <span className="rounded-full bg-warning-soft px-1.5 text-2xs font-semibold text-warning">
      {n}
    </span>
  );
}

function PeriodFields({
  draft,
  setDraft,
  set,
  stacked = false,
}: {
  draft: CdrFilterForm;
  setDraft: React.Dispatch<React.SetStateAction<CdrFilterForm>>;
  set: Set;
  stacked?: boolean;
}) {
  return (
    <>
      <Field label="Period" className={stacked ? undefined : FILTER_WIDTH.select}>
        <Select
          value={draft.range}
          onChange={(e) => {
            const range = e.target.value;
            //leaving the custom period drops its dates, so a shortcut chosen afterwards is
            //not quietly narrowed by a window nobody can see any more
            setDraft((d) => (range === CUSTOM_RANGE ? { ...d, range } : { ...d, range, since: "", until: "" }));
          }}
        >
          {Object.keys(RANGES).map((key) => (
            <option key={key} value={key}>
              {key === "all" ? "All time" : `Last ${key}`}
            </option>
          ))}
          <option value={CUSTOM_RANGE}>Date range</option>
        </Select>
      </Field>

      {/* an explicit window, for "what happened between 2 and 3 on Tuesday". Either end alone
          works, and the dates travel as UTC instants */}
      {draft.range === CUSTOM_RANGE && (
        <>
          <Field label="From" htmlFor={stacked ? "cdr-since-m" : "cdr-since"} className={stacked ? undefined : FILTER_WIDTH.choice}>
            <Input id={stacked ? "cdr-since-m" : "cdr-since"} type="datetime-local" value={draft.since} max={draft.until || undefined}
              onChange={(e) => set("since", e.target.value)} />
          </Field>
          <Field label="To" htmlFor={stacked ? "cdr-until-m" : "cdr-until"} className={stacked ? undefined : FILTER_WIDTH.choice}>
            <Input id={stacked ? "cdr-until-m" : "cdr-until"} type="datetime-local" value={draft.until} min={draft.since || undefined}
              onChange={(e) => set("until", e.target.value)} />
          </Field>
        </>
      )}
    </>
  );
}

function OutcomeField({ draft, set, className }: { draft: CdrFilterForm; set: Set; className?: string }) {
  return (
    <Field label="Outcome" className={className}>
      <Select value={draft.outcome} onChange={(e) => set("outcome", e.target.value)}>
        <option value="">Any outcome</option>
        {/* PENDING first: it is the majority of rows and the one people forget exists */}
        <option value="PENDING">Awaiting a receipt</option>
        {FINAL_STATES.map((state) => (
          <option key={state} value={state}>
            {labelFor(FINAL_STATE_LABELS, state)}
          </option>
        ))}
      </Select>
    </Field>
  );
}

/**
 * One box for the two things people paste: a phone number (To number, starts-with) or a message id
 * (exact). `classifyFind` decides which; the chip under the bar says which it was taken as.
 */
function FindField({
  draft,
  setDraft,
  className,
}: {
  draft: CdrFilterForm;
  setDraft: React.Dispatch<React.SetStateAction<CdrFilterForm>>;
  className?: string;
}) {
  const [text, setText] = useState(draft.dest || draft.msgId);
  return (
    <Field label="Find" className={className}>
      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            const found = classifyFind(e.target.value);
            setDraft((d) => ({ ...d, ...found }));
          }}
          placeholder="To number or message id"
          aria-label="Find a to number or message id"
          className="pl-9"
        />
      </div>
    </Field>
  );
}

const GROUPS: { title: string; keys: (keyof CdrFilterForm)[] }[] = [
  { title: "Route", keys: ["server", "vendor", "ingress"] },
  { title: "Sender", keys: ["account", "systemId", "product"] },
  { title: "Message", keys: ["source", "text"] },
];

/** Route, Sender and Message: columns on a desktop, collapsible sections in the drawer. */
function FilterGroups({
  draft,
  set,
  names,
  collapsible = false,
}: {
  draft: CdrFilterForm;
  set: Set;
  names: WorkerNames;
  collapsible?: boolean;
}) {
  const fields = (keys: (keyof CdrFilterForm)[]) => (
    <div className="grid gap-3">
      {keys.map((key) => (
        <TextFilter key={key} name={key} draft={draft} set={set} names={names} />
      ))}
    </div>
  );

  if (!collapsible) {
    return (
      <div className="grid gap-6 lg:grid-cols-3 md:grid-cols-2">
        {GROUPS.map((g) => (
          <section key={g.title} aria-label={g.title}>
            <h3 className="mb-3 text-2xs font-semibold uppercase tracking-[0.06em] text-muted-foreground">{g.title}</h3>
            {fields(g.keys)}
          </section>
        ))}
      </div>
    );
  }
  return (
    <div className="divide-y divide-border border-y border-border">
      {GROUPS.map((g) => {
        const set_ = g.keys.filter((k) => draft[k] !== "").length;
        return (
          //a section with something set opens by itself: a filter the reader cannot see is the
          //one that makes the list look wrong
          <details key={g.title} open={set_ > 0} className="group py-1">
            <summary className="flex cursor-pointer list-none items-center justify-between py-2.5 text-sm font-medium">
              <span>
                {g.title}
                {set_ > 0 && <span className="ml-2 text-xs font-normal text-muted-foreground">{set_} set</span>}
              </span>
              <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform group-open:rotate-180" />
            </summary>
            <div className="pb-3 pt-1">{fields(g.keys)}</div>
          </details>
        );
      })}
    </div>
  );
}

const TEXT_FILTERS: Partial<Record<keyof CdrFilterForm, { label: string; placeholder: string; list?: "servers" | "vendors"; inputMode?: "tel" }>> = {
  server: { label: "Ingress server", placeholder: "any listener", list: "servers" },
  vendor: { label: "Vendor", placeholder: "any vendor", list: "vendors" },
  ingress: { label: "Came in via", placeholder: "smpp, http…" },
  account: { label: "Account", placeholder: "exact" },
  systemId: { label: "Bind name (system id)", placeholder: "exact" },
  product: { label: "Product", placeholder: "exact" },
  source: { label: "From number", placeholder: "starts with…", inputMode: "tel" },
  //the one box here that searches inside a value rather than matching one. It finds nothing at
  //all unless the gateway is recording message text -- smsg.cdr.body, off by default -- which is
  //why the placeholder says what it looks in rather than "search"
  text: { label: "Message text", placeholder: "contains…" },
};

function TextFilter({
  name,
  draft,
  set,
  names,
}: {
  name: keyof CdrFilterForm;
  draft: CdrFilterForm;
  set: Set;
  names: WorkerNames;
}) {
  const spec = TEXT_FILTERS[name]!;
  const listId = spec.list ? `cdr-${spec.list}` : undefined;
  return (
    <Field label={spec.label}>
      <Input
        value={draft[name] as string}
        onChange={(e) => set(name, e.target.value as never)}
        placeholder={spec.placeholder}
        inputMode={spec.inputMode}
        list={listId}
      />
      {spec.list && (
        <datalist id={listId}>
          {names[spec.list].map((n) => <option key={n} value={n} />)}
        </datalist>
      )}
    </Field>
  );
}

function periodLabel(form: CdrFilterForm): string {
  if (form.range === CUSTOM_RANGE) {
    return "Date range";
  }
  return form.range === "all" ? "All time" : `Last ${form.range}`;
}

function chipLabel(key: keyof CdrFilterForm, value: string): string {
  switch (key) {
    case "outcome":
      return value === "PENDING" ? "Awaiting a receipt" : labelFor(FINAL_STATE_LABELS, value);
    case "dest":
      return `To number ${value}…`;
    case "msgId":
      return `Message id ${value}`;
    case "text":
      return `Text contains “${value}”`;
    case "attempts":
      return "Every attempt";
    default:
      return `${TEXT_FILTERS[key]?.label ?? key}: ${value}`;
  }
}

/** Worker names as the call records carry them: `smppserver.<name>` for a listener, `smppclient.<name>` for a vendor. */
export interface WorkerNames {
  servers: string[];
  vendors: string[];
}

//one read per page load, not per search: the bar is remounted with every applied filter set
let cachedNames: WorkerNames | null = null;
let namesInFlight: Promise<WorkerNames> | null = null;

async function loadWorkerNames(): Promise<WorkerNames> {
  const read = async (type: string, prefix: string): Promise<string[]> => {
    try {
      const res = await fetch(`/api/control/workers?type=${type}`, { cache: "no-store" });
      const json = await res.json().catch(() => null);
      const rows: { name?: string }[] = res.ok && Array.isArray(json?.data) ? json.data : [];
      return rows.map((w) => (w.name ? `${prefix}.${w.name}` : "")).filter(Boolean).sort();
    } catch {
      return [];
    }
  };
  const [servers, vendors] = await Promise.all([read("smppserver", "smppserver"), read("smppclient", "smppclient")]);
  return { servers, vendors };
}

export function useWorkerNames(): WorkerNames {
  const [names, setNames] = useState<WorkerNames>(cachedNames ?? { servers: [], vendors: [] });
  useEffect(() => {
    if (cachedNames) {
      return;
    }
    let live = true;
    namesInFlight ??= loadWorkerNames().then((n) => {
      cachedNames = n;
      return n;
    });
    void namesInFlight.then((n) => {
      if (live) {
        setNames(n);
      }
    });
    return () => {
      live = false;
    };
  }, []);
  return names;
}
