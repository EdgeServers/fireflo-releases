"use client";
import { useCallback, useEffect, useState } from "react";
import { periodKey, pickPeriod } from "@/lib/period";

/**
 * A page's period, remembered in this browser until its user picks another.
 *
 * <p>Starts on `fallback` -- the last hour -- for anyone who never chose, so a busy gateway's pages
 * open on the cheapest, most current view. The stored choice is read after mount, like the column
 * chooser's, because the server renders the default and the first client frame must match it.
 * Storage that throws (private windows, a full quota) leaves the page working, just forgetful.
 */
export function usePeriod<T extends string>(
  page: string,
  options: readonly T[],
  fallback: T
): [T, (next: T) => void] {
  const [period, setPeriodState] = useState<T>(fallback);
  const optionsKey = options.join(",");

  useEffect(() => {
    try {
      setPeriodState(pickPeriod(window.localStorage.getItem(periodKey(page)), optionsKey.split(",") as T[], fallback));
    } catch {
      //no storage: the default stands
    }
  }, [page, optionsKey, fallback]);

  const setPeriod = useCallback(
    (next: T) => {
      setPeriodState(next);
      try {
        window.localStorage.setItem(periodKey(page), next);
      } catch {
        //remembered for this visit only
      }
    },
    [page]
  );

  return [period, setPeriod];
}

/**
 * The stored period for a page that keeps its filters in the URL (Refused, the portal's Messages):
 * what it opens on when the address names no period of its own. A link that does name one wins.
 */
export function storedPeriod<T extends string>(page: string, options: readonly T[], fallback: T): T {
  try {
    return pickPeriod(window.localStorage.getItem(periodKey(page)), options, fallback);
  } catch {
    return fallback;
  }
}

/** Remembers `period` for `page`; a custom date window is not a period and is not kept. */
export function rememberPeriod(page: string, period: string, options: readonly string[]): void {
  if (!options.includes(period)) {
    return;
  }
  try {
    window.localStorage.setItem(periodKey(page), period);
  } catch {
    //remembered for this visit only
  }
}
