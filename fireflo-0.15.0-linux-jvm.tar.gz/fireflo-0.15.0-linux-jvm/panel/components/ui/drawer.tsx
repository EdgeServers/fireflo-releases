"use client";
import * as React from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useModalBehaviour } from "@/components/ui/dialog";

/**
 * A panel that slides in from the right edge, full height: filters on a phone, where a centred
 * dialog would leave no room for a form and the page's own fields would push the results a screen
 * down.
 *
 * <p>Modal in every way {@link useModalBehaviour} makes the dialog modal, and portalled for the
 * same reason. The body scrolls inside the panel; the footer -- the actions -- stays put, so "Show
 * results" is reachable however many sections are open.
 */
export function Drawer({
  open,
  onClose,
  title,
  footer,
  className,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  /** Pinned under the scrolling body. */
  footer?: React.ReactNode;
  className?: string;
  children: React.ReactNode;
}) {
  const panel = React.useRef<HTMLDivElement>(null);
  const titleId = React.useId();
  const [mounted, setMounted] = React.useState(false);

  useModalBehaviour(open, onClose, panel);
  React.useEffect(() => setMounted(true), []);
  React.useEffect(() => {
    if (open) {
      panel.current?.focus();
    }
  }, [open]);

  if (!mounted || !open) {
    return null;
  }

  return createPortal(
    <div className="fixed inset-0 z-[60]">
      <div className="fixed inset-0 bg-black/50" onClick={onClose} aria-hidden="true" />
      <div
        ref={panel}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        tabIndex={-1}
        className={cn(
          "fixed inset-y-0 right-0 z-10 flex w-[88vw] max-w-[380px] flex-col border-l border-border bg-card shadow-lg outline-none",
          "animate-drawer-in motion-reduce:animate-none",
          className
        )}
      >
        <div className="flex items-center justify-between gap-4 border-b border-border px-4 py-3">
          <h2 id={titleId} className="text-title">{title}</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="shrink-0 rounded-md p-2 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto px-4 py-4">{children}</div>
        {footer && <div className="border-t border-border px-4 py-3">{footer}</div>}
      </div>
    </div>,
    document.body
  );
}
