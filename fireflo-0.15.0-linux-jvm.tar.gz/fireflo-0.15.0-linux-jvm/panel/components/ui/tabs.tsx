"use client";
import { createContext, useContext, useEffect } from "react";
import { cn } from "@/lib/utils";

/**
 * An underlined row of tabs, controlled by the caller.
 *
 * <p>Controlled rather than stateful because both callers need the selected tab for something else —
 * the playground rebuilds its form and its code sample from it, and the reference scrolls to it. A
 * component holding that state privately would mean each caller keeping a second copy in step.
 *
 * <p>Deliberately not a headless-UI dependency. This is a row of buttons and an `aria-selected`;
 * the panel's whole dependency list is nine packages and this is not the tenth.
 *
 * <p>Roving focus is left to the browser. Arrow-key navigation is the one thing a real tab widget
 * adds over this, and adding it half-correctly is worse than a plain tab order that works.
 */

export interface TabItem<T extends string> {
  id: T;
  label: string;
  /** Rendered before the label, e.g. a method badge. */
  prefix?: React.ReactNode;
  /** Rendered after it, e.g. the path a tab calls. Hidden below `sm`, where the row already wraps. */
  suffix?: React.ReactNode;
}

export function Tabs<T extends string>({
  items,
  active,
  onSelect,
  className,
  label,
  busyId,
}: {
  items: readonly TabItem<T>[];
  active: T;
  onSelect: (id: T) => void;
  className?: string;
  /** Names the set for a screen reader — "Endpoints", "Languages". */
  label: string;
  /** The tab whose content is being fetched: its underline glows and sweeps until it arrives. */
  busyId?: T | null;
}) {
  return (
    <div role="tablist" aria-label={label}
      className={cn("flex flex-wrap items-center gap-0.5 border-b border-border", className)}>
      {items.map((item) => {
        const selected = item.id === active;
        return (
          <button
            key={item.id}
            type="button"
            role="tab"
            aria-selected={selected}
            aria-busy={busyId === item.id || undefined}
            onClick={() => onSelect(item.id)}
            className={cn(
              "relative flex items-center gap-1.5 whitespace-nowrap px-3 py-2.5 text-sm transition-colors",
              //the underline sits on the button rather than on a sliding indicator: one element,
              //no measuring, and it survives the row wrapping on a narrow screen
              selected
                ? "-mb-px border-b-2 border-primary font-semibold text-foreground"
                : "border-b-2 border-transparent text-muted-foreground hover:text-foreground"
            )}
          >
            {item.prefix}
            {item.label}
            {item.suffix && <span className="hidden sm:inline">{item.suffix}</span>}
            {/* loading: the underline glows and sweeps (globals.css .tab-busy-bar), no spinner */}
            {busyId === item.id && <span className="tab-busy-bar" aria-hidden />}
          </button>
        );
      })}
    </div>
  );
}

const BusyReport = createContext<((busy: boolean) => void) | null>(null);

/**
 * Wraps a tab's content so the content can say it is fetching: `useReportBusy` inside reaches the
 * page, which passes the tab to {@link Tabs}' `busyId` and its label shows a spinner. The content
 * keeps its own loading state; it only reports it.
 */
export function TabPanel({ onBusy, children }: { onBusy: (busy: boolean) => void; children: React.ReactNode }) {
  return <BusyReport.Provider value={onBusy}>{children}</BusyReport.Provider>;
}

/** Inside a {@link TabPanel}: tells the tab bar whether this content is being fetched. A no-op outside one. */
export function useReportBusy(busy: boolean): void {
  const report = useContext(BusyReport);
  useEffect(() => {
    report?.(busy);
    return () => report?.(false);
  }, [busy, report]);
}
