import { cn } from "@/lib/utils";

/**
 * The one loading mark: a small ring that turns while the server is being asked, shown in the very
 * control that asked -- the period button, the tab, the menu row. Under reduced motion it holds
 * still and pulses its opacity instead, which still reads as "working" without the rotation.
 */
export function Spinner({ className, label = "Loading" }: { className?: string; label?: string }) {
  return (
    <span
      role="status"
      aria-label={label}
      className={cn(
        "inline-block h-3 w-3 shrink-0 rounded-full border-[1.5px] border-current border-r-transparent",
        "animate-spin motion-reduce:animate-pulse motion-reduce:border-r-current",
        className
      )}
    />
  );
}
