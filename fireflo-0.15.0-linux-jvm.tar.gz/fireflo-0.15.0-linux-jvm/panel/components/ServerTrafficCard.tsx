"use client";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Segmented } from "@/components/ui/segmented";
import { TBody, TD, TH, THead, TR, TableInCard } from "@/components/ui/table";
import { usePeriod } from "./usePeriod";
import { useStats } from "./useControlData";
import { count } from "@/lib/format";
import type { ServerTraffic } from "@/lib/metrics-queries";
import { SERVER_TRAFFIC_RANGES, type ServerTrafficRange } from "@/lib/server-traffic-sql";

const OPTIONS: { value: ServerTrafficRange; label: string; title: string }[] = [
  { value: "1h", label: "1 hour", title: "The last hour" },
  { value: "24h", label: "24 hours", title: "The last 24 hours" },
];

/**
 * What came in on this listener over the last hour or day: messages and how they ended, by account.
 *
 * <p>Opens on the last hour, and on whatever its user last picked after that. Stops at 24 hours
 * because the records are the only source -- no summary holds a listener -- see
 * `lib/server-traffic-sql.ts`.
 */
export function ServerTrafficCard({ name }: { name: string }) {
  const [range, setRange] = usePeriod<ServerTrafficRange>("server", SERVER_TRAFFIC_RANGES, "1h");
  const { data, error, loading, switching } = useStats<ServerTraffic>("server-traffic", range, { server: name });
  const rows = data?.rows ?? [];
  const totals = data?.totals;
  const reportedRate = totals && totals.reported > 0 ? totals.delivered / totals.reported : null;

  return (
    <Card>
      <CardHeader className="flex-row flex-wrap items-center justify-between gap-3 space-y-0">
        <div className="min-w-0">
          <CardTitle>Traffic</CardTitle>
          <p className="mt-1 text-xs text-muted-foreground">
            Messages that came in on this listener, by account. Up to 24 hours: longer periods need a
            summary that does not keep listeners yet.
          </p>
        </div>
        <Segmented label="Period" options={OPTIONS} value={range} onChange={setRange} busy={switching} />
      </CardHeader>
      <CardContent className="space-y-3">
        {error ? (
          <p className="text-sm text-destructive">{error}</p>
        ) : !rows.length ? (
          <p className="text-sm text-muted-foreground">
            {loading ? "Reading…" : `Nothing came in on this listener in the last ${range === "1h" ? "hour" : "24 hours"}.`}
          </p>
        ) : (
          <>
            <p className="text-sm">
              <span className="font-semibold tabular-nums">{count(totals?.messages ?? 0)}</span> messages
              {reportedRate !== null && (
                <>
                  {" · "}
                  <span className="font-semibold tabular-nums">{Math.round(reportedRate * 1000) / 10}%</span> delivered of
                  those with an outcome
                </>
              )}
            </p>
            <TableInCard>
              <THead>
                <tr>
                  <TH>Account</TH>
                  <TH align="right">Messages</TH>
                  <TH align="right">Delivered</TH>
                  <TH align="right">Failed</TH>
                  <TH align="right">Expired</TH>
                  <TH align="right">Awaiting</TH>
                </tr>
              </THead>
              <TBody>
                {rows.map((r) => (
                  <TR key={r.accountId ?? ""}>
                    <TD>
                      {r.accountId ? (
                        <Link href={`/cp/accounts/${encodeURIComponent(r.accountId)}`} className="hover:underline">
                          {r.accountId}
                        </Link>
                      ) : (
                        <span className="text-muted-foreground">No account</span>
                      )}
                    </TD>
                    <TD num className="font-medium">{count(r.messages)}</TD>
                    <TD num>{count(r.delivered)}</TD>
                    <TD num>{count(r.failed)}</TD>
                    <TD num>{count(r.expired)}</TD>
                    <TD num muted>{count(r.pending)}</TD>
                  </TR>
                ))}
              </TBody>
            </TableInCard>
          </>
        )}
      </CardContent>
    </Card>
  );
}
