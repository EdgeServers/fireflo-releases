"use client";
import { useState } from "react";
import { HeartPulse, KeyRound, LogOut, ShieldCheck } from "lucide-react";
import { Menu, MenuHeading, MenuItem } from "@/components/ui/menu";
import { ChangePasswordDialog } from "@/components/ChangePasswordDialog";

/**
 * Who is signed in and the three things about that: change the password, see live health, leave.
 *
 * <p>These lived in the sidebar's footer, where the collapsed rail reduced them to three unlabelled
 * icons. A menu under the avatar keeps the labels at every width and takes the footer back for
 * the one thing the sidebar should say about a person: their name.
 */
export function UserMenu({
  name,
  role,
  canChangePassword = true,
  passwordHref,
  healthHref = "/cp/health",
  twoFactorHref = null,
  onSignOut,
}: {
  name: string;
  role: string | null;
  /** False for the env-fallback operator, whose password lives in panel.env. */
  canChangePassword?: boolean;
  /** The portal's password page: a link instead of the operator's dialog. */
  passwordHref?: string;
  /** Null hides the live-health item (the portal has no gateway page). */
  healthHref?: string | null;
  /** The operator's two-factor screen; null (the portal, the env operator) hides the item. */
  twoFactorHref?: string | null;
  onSignOut: () => void;
}) {
  const [changingPassword, setChangingPassword] = useState(false);
  return (
    <>
      <Menu
        label="Account menu"
        trigger={
          <span className="grid h-8 w-8 place-items-center rounded-full bg-muted text-2xs font-bold" aria-hidden>
            {initials(name)}
          </span>
        }
      >
        <MenuHeading>
          <p className="truncate font-semibold">{name}</p>
          <p className="capitalize text-muted-foreground">{role ?? "operator"}</p>
        </MenuHeading>
        {passwordHref ? (
          <MenuItem icon={KeyRound} href={passwordHref}>Password</MenuItem>
        ) : canChangePassword && (
          <MenuItem icon={KeyRound} onClick={() => setChangingPassword(true)}>Change password</MenuItem>
        )}
        {twoFactorHref && <MenuItem icon={ShieldCheck} href={twoFactorHref}>Two-factor authentication</MenuItem>}
        {healthHref && <MenuItem icon={HeartPulse} href={healthHref}>Live health</MenuItem>}
        <MenuItem icon={LogOut} onClick={onSignOut}>Sign out</MenuItem>
      </Menu>
      {!passwordHref && canChangePassword && (
        <ChangePasswordDialog email={name} open={changingPassword} onClose={() => setChangingPassword(false)} />
      )}
    </>
  );
}

/** "ops@example.com" → "OP", "Jane Doe" → "JD": the two letters that stand for a person in a circle. */
export function initials(name: string): string {
  const local = name.split("@")[0] ?? name;
  const parts = local.split(/[\s._-]+/).filter(Boolean);
  const letters = parts.length >= 2 ? parts[0][0] + parts[1][0] : local.slice(0, 2);
  return letters.toUpperCase();
}
