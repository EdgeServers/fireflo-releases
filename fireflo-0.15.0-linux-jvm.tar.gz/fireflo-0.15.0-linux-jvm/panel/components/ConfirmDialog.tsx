"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { typedMatches, type ChangeLine } from "@/lib/confirm-changes";

/**
 * A destructive action confirmed in a modal, for triggers too small to arm in place.
 *
 * <p><strong>This does not replace {@link DangerAction}, and the difference is the trigger rather
 * than the danger.</strong> `DangerAction` expands in the row it lives in, which is right when the
 * trigger is a word wide enough to grow into a sentence. An icon-only trigger has nowhere to expand
 * to — a 32px button cannot become a paragraph without the table reflowing under the pointer — so
 * the sentence goes in a dialog instead.
 *
 * <p><strong>The consequence sentence is not optional.</strong> That is the whole safety posture
 * this codebase has about destructive actions: the operator is told what stops working, in the
 * specific — which sender ID, which customer — rather than being asked "are you sure?", which is a
 * question nobody has ever answered no to. A trash icon that deleted on click would be the only
 * unconfirmed destructive action in the panel.
 *
 * <p>Escape, focus return and the tab trap come from `Dialog`. Errors keep the dialog open, because
 * a failure with nowhere to appear is a failure the operator does not learn about.
 */
export function ConfirmDialog({
  open,
  title,
  consequence,
  confirmLabel,
  tone = "destructive",
  busy = false,
  error = "",
  onConfirm,
  onCancel,
  changes,
  typeToConfirm,
  children,
}: {
  open: boolean;
  title: string;
  /** What stops working, named. Not "this cannot be undone". */
  consequence: string;
  confirmLabel: string;
  /**
   * Red is the default because everything that reached for this dialog first was a deletion. Bulk
   * approval is consequential enough to confirm and not destructive at all, and a red button on it
   * would teach operators that the colour means nothing.
   */
  tone?: "destructive" | "primary" | "caution";
  busy?: boolean;
  error?: string;
  onConfirm: () => void;
  onCancel: () => void;
  /** What this changes, listed under the consequence: a setting from one value to another. */
  changes?: readonly ChangeLine[];
  /**
   * A word the operator must type before the confirm button works -- `DELETE` for every delete.
   * Exact; see {@link typedMatches}. The modal is the first deliberate act and the word the second.
   */
  typeToConfirm?: string;
  /**
   * One control the confirmation itself needs — a target to pick, say.
   *
   * <p>Deliberately narrow. A dialog that grows a form stops being a confirmation, and the whole
   * value of this component is that the operator is reading a consequence rather than filling
   * something in. Use it when the action has exactly one free choice and no sensible default.
   */
  children?: React.ReactNode;
}) {
  if (!open) {
    return null;
  }
  return (
    <ConfirmBody
      title={title}
      consequence={consequence}
      confirmLabel={confirmLabel}
      tone={tone}
      busy={busy}
      error={error}
      onConfirm={onConfirm}
      onCancel={onCancel}
      changes={changes}
      typeToConfirm={typeToConfirm}
    >
      {children}
    </ConfirmBody>
  );
}

/** The open dialog, split out so the typed word resets every time it opens. */
function ConfirmBody({
  title,
  consequence,
  confirmLabel,
  tone,
  busy,
  error,
  onConfirm,
  onCancel,
  changes,
  typeToConfirm,
  children,
}: {
  title: string;
  consequence: string;
  confirmLabel: string;
  tone: "destructive" | "primary" | "caution";
  busy: boolean;
  error: string;
  onConfirm: () => void;
  onCancel: () => void;
  changes?: readonly ChangeLine[];
  typeToConfirm?: string;
  children?: React.ReactNode;
}) {
  const [typed, setTyped] = useState("");
  const wordOk = !typeToConfirm || typedMatches(typed, typeToConfirm);
  return (
    <Dialog open role="alertdialog" onClose={busy ? () => {} : onCancel} title={title} className="max-w-md">
      <p className="text-sm text-muted-foreground">{consequence}</p>
      {changes && changes.length > 0 && (
        <ul className="mt-3 max-h-56 space-y-1 overflow-y-auto rounded-md border border-border bg-muted/40 p-2 text-xs">
          {changes.map((c, i) => (
            <li key={`${c.label}-${i}`} className="flex flex-wrap gap-x-1.5">
              <span className="font-mono font-medium">{c.label}</span>
              {c.from !== undefined && <span className="text-muted-foreground line-through">{c.from}</span>}
              {c.to !== undefined && <span>{c.from !== undefined ? "→ " : ""}{c.to}</span>}
              {c.note && <span className="basis-full text-muted-foreground">{c.note}</span>}
            </li>
          ))}
        </ul>
      )}
      {children}
      {typeToConfirm && (
        <label className="mt-4 block text-sm">
          <span className="text-muted-foreground">
            Type <span className="font-mono font-semibold text-foreground">{typeToConfirm}</span> to confirm
          </span>
          <Input
            className="mt-1.5"
            value={typed}
            onChange={(e) => setTyped(e.target.value)}
            placeholder={typeToConfirm}
            autoComplete="off"
            autoFocus
            aria-label={`Type ${typeToConfirm} to confirm`}
          />
        </label>
      )}
      {error && <p className="mt-3 text-sm text-destructive">{error}</p>}
      <div className="mt-5 flex justify-end gap-2">
        <Button variant="outline" size="sm" disabled={busy} onClick={onCancel}>
          Cancel
        </Button>
        <Button
          size="sm"
          disabled={busy || !wordOk}
          onClick={onConfirm}
          className={tone === "destructive"
            ? "bg-destructive text-destructive-foreground hover:bg-destructive/90"
            : tone === "caution"
              ? "bg-warning text-white hover:bg-warning/90"
              : undefined}
        >
          {busy ? "Working…" : confirmLabel}
        </Button>
      </div>
    </Dialog>
  );
}

/**
 * The open/closed bookkeeping for a table where each row can raise the same dialog.
 *
 * <p>One piece of state for the whole table rather than one per row: two confirmations open at once
 * is not a state worth being able to reach.
 */
export function useConfirm<T>() {
  const [pending, setPending] = useState<T | null>(null);
  return { pending, ask: setPending, dismiss: () => setPending(null) };
}
