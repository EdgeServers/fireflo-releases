"use client";
import { RefreshCw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/ui/page-header";
import { TableInCard, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { CardActions, HealthStrip } from "./CardBits";
import { NeedsCapability } from "./NeedsCapability";
import { useHealth } from "./useHealth";
import { NODE_IDENTITY } from "@/lib/capabilities";
import { formatClockTime, formatTimestamp } from "@/lib/datetime";
import { elapsed } from "@/lib/format";
import type { ClusterNode } from "@/lib/health-types";
import { cn } from "@/lib/utils";

/**
 * Nodes: every gateway process in the cluster, as the one this panel talks to sees them.
 *
 * <p>Read from `health.cluster.nodes` (gateway 0.14, `node_identity`), which the health poll already
 * carries, so the page costs no request of its own. In memory mode the list is the one node; on
 * Kafka it is every node that has heartbeaten within the node timeout and the dead ones still
 * remembered. Read-only: leases and session counts per node come later, with `vendor_leases`.
 *
 * <p>The node this panel is asking is marked, because "alive" is that node's opinion of the others
 * and an operator reading two panels against two nodes should know whose opinion they hold.
 */
export function NodesClient() {
  const { health, error, loading, reload } = useHealth();
  const cluster = health?.cluster ?? null;
  const self = health?.node_id?.trim() || null;
  const nodes = [...(cluster?.nodes ?? [])].sort(
    (a, b) => Number(b.alive) - Number(a.alive) || Number(b.nodeId === self) - Number(a.nodeId === self) || a.nodeId.localeCompare(b.nodeId)
  );
  const dead = nodes.filter((n) => !n.alive).length;
  const versions = new Set(nodes.filter((n) => n.alive).map((n) => n.version?.trim()).filter(Boolean));

  return (
    <>
      <PageHeader
        title="Nodes"
        description="Every gateway process in this cluster, as the one this panel is talking to sees them. On Kafka the nodes share the work; in process there is one."
        actions={
          <Button variant="outline" onClick={reload}>
            <RefreshCw className="mr-1.5 h-4 w-4" />
            Refresh
          </Button>
        }
      />

      <NeedsCapability health={health} loading={loading} error={error} name={NODE_IDENTITY} feature="its cluster nodes">
        {dead > 0 && (
          <HealthStrip tone="destructive">
            {dead} node{dead === 1 ? " has" : "s have"} missed the node timeout. Its vendors and partitions move to the
            others; if it is not coming back, nothing more is needed.
          </HealthStrip>
        )}
        {versions.size > 1 && (
          <HealthStrip tone="warning">
            The live nodes run {versions.size} different releases ({[...versions].join(", ")}). A rolling restart
            in progress is fine; a cluster left like this is not.
          </HealthStrip>
        )}
        <Card>
          <CardHeader className="flex flex-row flex-wrap items-center gap-2 space-y-0 border-b border-border">
            <span className="text-title">Cluster</span>
            {cluster && <Badge variant="outline" className="font-mono text-xs">{cluster.mode}</Badge>}
            <CardActions>
              {health && (
                <span className="text-sm text-muted-foreground">
                  read at <span className="tabular-nums">{formatClockTime(health.observed_at)}</span>
                </span>
              )}
            </CardActions>
          </CardHeader>
          <CardContent className="pt-0">
            {nodes.length === 0 ? (
              <p className="py-3 text-sm text-muted-foreground">The gateway lists no nodes, not even itself.</p>
            ) : (
              <TableInCard>
                <THead>
                  <TR>
                    <TH>Node</TH>
                    <TH>Host</TH>
                    <TH>Version</TH>
                    <TH>Started</TH>
                    <TH>Last heartbeat</TH>
                    <TH>State</TH>
                    <TH>Ops URL</TH>
                  </TR>
                </THead>
                <TBody>
                  {nodes.map((n) => (
                    <NodeRow key={n.nodeId} node={n} self={n.nodeId === self} observedAt={health?.observed_at ?? null} />
                  ))}
                </TBody>
              </TableInCard>
            )}
          </CardContent>
        </Card>
        <p className="text-xs text-muted-foreground">
          A node&apos;s id is <code>FIREFLO_INSTANCE_ID</code> in its environment, never a setting in the database:
          two nodes sharing one row would share one name.
        </p>
      </NeedsCapability>
    </>
  );
}

function NodeRow({ node, self, observedAt }: { node: ClusterNode; self: boolean; observedAt: string | null }) {
  return (
    <TR className={cn(!node.alive && "text-muted-foreground")}>
      <TD className="font-mono text-xs">
        {node.nodeId}
        {self && <Badge variant="outline" className="ml-2 text-2xs">this one</Badge>}
      </TD>
      <TD className="font-mono text-xs">{node.host?.trim() || "—"}</TD>
      <TD className="font-mono text-xs">{node.version?.trim() || "—"}</TD>
      <TD className="tabular-nums" title={node.startedAt ?? undefined}>{formatTimestamp(node.startedAt) || "—"}</TD>
      <TD className="tabular-nums" title={node.heartbeatAt ?? undefined}>
        {node.heartbeatAt ? `${elapsed(ageSeconds(node.heartbeatAt, observedAt))} ago` : "—"}
      </TD>
      <TD>
        {node.alive ? <Badge variant="success">alive</Badge> : <Badge variant="destructive">missed timeout</Badge>}
      </TD>
      <TD className="font-mono text-xs">{node.opsUrl?.trim() || "—"}</TD>
    </TR>
  );
}

/** Seconds from a heartbeat to the read, by the gateway's clock on both sides rather than the browser's. */
function ageSeconds(at: string, observedAt: string | null): number | null {
  const then = Date.parse(at);
  const now = observedAt ? Date.parse(observedAt) : Date.now();
  if (Number.isNaN(then) || Number.isNaN(now)) {
    return null;
  }
  return Math.max(0, Math.round((now - then) / 1000));
}
