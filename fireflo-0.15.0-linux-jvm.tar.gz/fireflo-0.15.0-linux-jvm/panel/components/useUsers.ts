"use client";
import { useCallback, useEffect, useState } from "react";
import type { NewUserInput, PublicUser, UsersTwoFactor } from "@/lib/user-types";

/**
 * Loading and editing who may sign in. Same shape as `useProducts`.
 *
 * <p>`accountId` narrows the list to one account's customers, for the account page; without it the
 * users page shows everyone.
 */
export function useUsers(accountId?: string | null) {
  const [users, setUsers] = useState<PublicUser[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<number | null>(null);
  const [twoFactor, setTwoFactor] = useState<UsersTwoFactor>({ available: false, required: false });

  const load = useCallback(async () => {
    try {
      const url = accountId ? `/api/control/users?account=${encodeURIComponent(accountId)}` : "/api/control/users";
      const res = await fetch(url, { cache: "no-store" });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setError(json?.error ?? `Request failed (${res.status})`);
        setUsers([]);
      } else {
        setUsers(json.data.users as PublicUser[]);
        setTwoFactor((json.data.twoFactor as UsersTwoFactor | undefined) ?? { available: false, required: false });
        setError("");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Request failed");
    } finally {
      setLoading(false);
    }
  }, [accountId]);

  useEffect(() => {
    load();
  }, [load]);

  const act = useCallback(
    async (id: number | null, run: () => Promise<Response>): Promise<string | null> => {
      setBusy(id ?? -1);
      try {
        const res = await run();
        const json = await res.json().catch(() => null);
        if (!res.ok) {
          const message = json?.error ?? `Request failed (${res.status})`;
          setError(message);
          return message;
        }
        setError("");
        await load();
        return null;
      } catch (err) {
        const message = err instanceof Error ? err.message : "Request failed";
        setError(message);
        return message;
      } finally {
        setBusy(null);
      }
    },
    [load]
  );

  const create = useCallback(
    (input: NewUserInput) =>
      act(null, () =>
        fetch("/api/control/users", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(input),
        })
      ),
    [act]
  );

  const patch = useCallback(
    (id: number, change: { enabled?: boolean; role?: "admin" | "operator" }) =>
      act(id, () =>
        fetch(`/api/control/users/${id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(change),
        })
      ),
    [act]
  );

  const setPassword = useCallback(
    (id: number, password: string) =>
      act(id, () =>
        fetch(`/api/control/users/${id}/password`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ password }),
        })
      ),
    [act]
  );

  return { users, error, loading, busy, load, create, patch, setPassword, twoFactor };
}
