"use client";
import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";

/**
 * Shown in place of a heavy page's figures while the server is still reading them -- a month of
 * receipts at production volume -- instead of "canceling statement due to statement timeout". The
 * read goes on in the background (stats-route.ts) and the page asks again on its own, so the card
 * says so: nobody needs to refresh.
 *
 * @param what what is being read, for the sentence: "30 days of receipts"
 * @param retryAfter seconds until the page asks again; the countdown is a courtesy, not a promise
 */
export function BreathingCard({ what, retryAfter = 15 }: { what: string; retryAfter?: number }) {
  const [left, setLeft] = useState(retryAfter);
  useEffect(() => {
    const t = setInterval(() => setLeft((n) => (n > 1 ? n - 1 : retryAfter)), 1000);
    return () => clearInterval(t);
  }, [retryAfter]);

  return (
    <Card>
      <CardContent className="flex flex-col items-center gap-3 py-8 text-center" role="status" aria-live="polite">
        <svg viewBox="0 0 180 150" width="180" height="150" aria-hidden className="text-muted-foreground">
          <ellipse className="busy-glow" cx="90" cy="128" rx="62" ry="10" fill="currentColor" opacity="0.35" />
          <g className="busy-breathe">
            <path d="M50 70 v44 c0 8 18 14 40 14 s40-6 40-14 v-44" fill="var(--color-muted)" stroke="currentColor" strokeWidth="1.5" />
            <path d="M50 92 c0 8 18 14 40 14 s40-6 40-14" fill="none" stroke="currentColor" strokeOpacity="0.6" strokeWidth="1.2" />
            <ellipse cx="90" cy="70" rx="40" ry="14" fill="var(--color-card)" stroke="currentColor" strokeWidth="1.5" />
          </g>
          {[
            { x: 74, y: 44, w: 32, h: 22, delay: "0s" },
            { x: 46, y: 48, w: 28, h: 19, delay: "1.2s" },
            { x: 108, y: 48, w: 28, h: 19, delay: "2.4s" },
          ].map((c) => (
            <g key={c.x} className="busy-rise" style={{ animationDelay: c.delay }}>
              <rect x={c.x} y={c.y} width={c.w} height={c.h} rx="4" fill="var(--color-card)" stroke="currentColor" strokeWidth="1.3" />
              <path d={`M${c.x + 2} ${c.y + 3} l${c.w / 2 - 2} ${c.h * 0.45} l${c.w / 2 - 2} -${c.h * 0.45}`} fill="none"
                stroke="currentColor" strokeOpacity="0.6" strokeWidth="1.2" />
            </g>
          ))}
        </svg>
        <p className="text-base font-medium text-foreground">That&rsquo;s a lot of messages. Taking a breath&hellip;</p>
        <p className="max-w-sm text-sm text-muted-foreground">
          {what} is millions of records. They&rsquo;re being read in the background and will appear here as soon as
          they&rsquo;re ready &mdash; no need to refresh.
        </p>
        <p className="text-xs text-muted-foreground" suppressHydrationWarning>Trying again in {left} s</p>
      </CardContent>
    </Card>
  );
}
