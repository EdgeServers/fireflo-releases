"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { DEFAULT_PINS, PINS_KEY, pinnablePath, readPins, togglePin, type Pin } from "@/lib/pins";

interface PinsValue {
  pins: Pin[];
  isPinned: (href: string) => boolean;
  toggle: (page: { href: string; label: string }) => void;
  unpin: (href: string) => void;
}

const PinsContext = createContext<PinsValue | null>(null);

/**
 * The operator's pinned pages, for the top bar and every page's pin button.
 *
 * <p>Only the operator shell provides it, so a page header in the customer portal finds no
 * provider and shows no pin. `localStorage` is read after mount, like the column chooser: the
 * server renders the defaults and so must the first client frame, or React 19 throws on the
 * mismatch. Another tab's pin arrives through the `storage` event.
 */
export function PinsProvider({ children }: { children: ReactNode }) {
  const [pins, setPins] = useState<Pin[]>(DEFAULT_PINS);
  const [note, setNote] = useState<string | null>(null);

  useEffect(() => {
    const load = () => {
      try {
        setPins(readPins(window.localStorage.getItem(PINS_KEY)));
      } catch {
        //no storage: the defaults stay
      }
    };
    load();
    const onStorage = (event: StorageEvent) => {
      if (event.key === PINS_KEY || event.key === null) {
        load();
      }
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  useEffect(() => {
    if (!note) {
      return;
    }
    const timer = setTimeout(() => setNote(null), 4_000);
    return () => clearTimeout(timer);
  }, [note]);

  const save = useCallback((next: Pin[]) => {
    setPins(next);
    try {
      window.localStorage.setItem(PINS_KEY, JSON.stringify(next));
    } catch {
      //kept for this page only
    }
  }, []);

  const toggle = useCallback(
    (page: { href: string; label: string }) => {
      const { pins: next, dropped } = togglePin(pins, page, Date.now());
      if (next === pins) {
        return;
      }
      save(next);
      const pinned = next.length >= pins.length;
      setNote(
        !pinned
          ? `Unpinned ${page.label}.`
          : dropped
            ? `Pinned ${page.label}. Unpinned ${dropped.label} to make room.`
            : `Pinned ${page.label}.`
      );
    },
    [pins, save]
  );

  const unpin = useCallback(
    (href: string) => {
      const pin = pins.find((p) => p.href === href);
      if (pin) {
        save(pins.filter((p) => p !== pin));
        setNote(`Unpinned ${pin.label}.`);
      }
    },
    [pins, save]
  );

  const value = useMemo<PinsValue>(
    () => ({
      pins,
      isPinned: (href) => {
        const path = pinnablePath(href);
        return !!path && pins.some((p) => p.href === path);
      },
      toggle,
      unpin,
    }),
    [pins, toggle, unpin]
  );

  return (
    <PinsContext.Provider value={value}>
      {children}
      {/* the bar changing under the reader is announced, and says which pin made room */}
      <div role="status" aria-live="polite" className="pointer-events-none fixed bottom-4 right-4 z-[70]">
        {note && (
          <p className="rounded-md border border-border bg-card px-3 py-2 text-sm shadow-lg">{note}</p>
        )}
      </div>
    </PinsContext.Provider>
  );
}

/** The pins, or null outside the operator shell (the portal), where nothing is pinnable. */
export function usePinsOptional(): PinsValue | null {
  return useContext(PinsContext);
}
