"use client";
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { APP_VERSION } from "@/components/FireFloMark";
import { apiLevelSentence } from "@/lib/capabilities";
import type { Health } from "@/lib/health-types";
import { EXPECTED_SCHEMA_VERSION, schemaPairing, versionPairing } from "@/lib/version-pairing";

/**
 * Whether this panel and the gateway it is talking to are the pair they claim to be, in three
 * parts: the release, the database schema, and what the gateway's API can do.
 *
 * <p>Lives beside the licence rather than under the dashboard's health provider because the two
 * screens that show it -- `/cp/verify` and the banner above every page -- are outside that
 * provider on purpose (see `app/cp/verify/page.tsx`). One read of `/api/control/health` on mount is
 * enough: a version does not change while an operator reads it.
 *
 * <p>Silent on an older gateway. A gateway that reports no `schema_version` or no `api` map is not
 * at fault; it is from before the fields, and the release pairing already says whether it is the
 * one this panel was built for.
 */
export function useHealthOnce(): { health: Health | null; failed: boolean } {
  const [health, setHealth] = useState<Health | null>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    let cancelled = false;
    fetch("/api/control/health", { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : null))
      .then((json: { data?: Health } | null) => {
        if (cancelled) {
          return;
        }
        if (json?.data) {
          setHealth(json.data);
        } else {
          setFailed(true);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setFailed(true);
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);
  return { health, failed };
}

/** The pairing card on `/cp/verify`. */
export function GatewayPairingCard() {
  const { health, failed } = useHealthOnce();
  const release = versionPairing(APP_VERSION, health?.version);
  const schema = schemaPairing(health?.schema_version);
  const api = apiLevelSentence(health);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Panel and gateway</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 text-sm" data-pairing={health ? release.verdict : "unread"}>
        {failed ? (
          <p className="text-muted-foreground">
            The panel could not reach the gateway, so it cannot say whether the two are a matched pair.
          </p>
        ) : !health ? (
          <p className="text-muted-foreground">Asking the gateway…</p>
        ) : (
          <>
            <dl className="grid gap-3 sm:grid-cols-3">
              <div>
                <dt className="text-xs text-muted-foreground">Panel</dt>
                <dd className="font-mono">{APP_VERSION || "unknown"}</dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground">Gateway</dt>
                <dd className="font-mono">
                  {health.version?.trim() || "not reported"}
                  {health.node_id?.trim() && (
                    <span className="ml-1.5 font-sans text-xs text-muted-foreground">(node {health.node_id.trim()})</span>
                  )}
                </dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground">Database schema</dt>
                <dd className="font-mono">
                  {schema.schema ?? "not reported"}
                  <span className="ml-1.5 font-sans text-xs text-muted-foreground">
                    (panel expects {EXPECTED_SCHEMA_VERSION})
                  </span>
                </dd>
              </div>
            </dl>
            {/* only when they disagree: a matched pair says nothing, and so does a gateway too old
                to report either field */}
            {release.verdict === "mismatched" && (
              <p className="rounded-md border border-warning/40 bg-warning-soft px-3 py-2 text-warning" data-schema="release-mismatch">
                {release.message}
              </p>
            )}
            {schema.message && (
              <p
                className={
                  schema.verdict === "older"
                    ? "rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-destructive"
                    : "rounded-md border border-warning/40 bg-warning-soft px-3 py-2 text-warning"
                }
                data-schema={schema.verdict}
              >
                {schema.message}
              </p>
            )}
            <p className="text-xs text-muted-foreground">
              {api ?? "This gateway predates API capability reporting, so the panel assumes none of the newer calls."}
            </p>
          </>
        )}
      </CardContent>
    </Card>
  );
}
