"use client";
import { useState } from "react";
import { signIn } from "next-auth/react";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { AuthHeading } from "@/components/AuthParts";
import { TOTP_EXPIRED, TOTP_LOST, TOTP_WRONG, cleanCode, pendingExpired } from "@/lib/totp-signin";

/**
 * The second step of an operator sign-in with an authenticator: the six digits, after the password
 * or the link was right. Sends them with the second-step token to the `operator-totp` provider; a
 * right code is a session and a full navigation to the dashboard, as the password step's is.
 *
 * @param pendingToken what the first step answered with (lib/totp-pending.ts)
 * @param onBack back to the first step; also where a lapsed token sends the operator, with `expired`
 */
export function TotpCodeStep({ pendingToken, onBack }: { pendingToken: string; onBack: (expired?: string) => void }) {
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function verify(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const res = await signIn("operator-totp", { pendingToken, code, redirect: false });
      if (res?.error) {
        if (pendingExpired(res.code)) {
          onBack(TOTP_EXPIRED);
          return;
        }
        setCode("");
        setError(TOTP_WRONG);
        return;
      }
      window.location.assign("/cp");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <AuthHeading title="Enter your authenticator code">
        Open the authenticator app on your phone and type the six-digit code it shows for FireFlo.
      </AuthHeading>
      <form onSubmit={verify} className="space-y-4">
        <Field label="Code" htmlFor="totp-code">
          <Input
            id="totp-code"
            name="code"
            inputMode="numeric"
            autoComplete="one-time-code"
            pattern="[0-9 ]*"
            placeholder="123 456"
            className="text-center font-mono text-lg tracking-[0.3em]"
            value={code}
            onChange={(e) => setCode(cleanCode(e.target.value))}
            autoFocus
          />
        </Field>
        {error && <p className="text-sm text-destructive" role="alert">{error}</p>}
        <div className="flex gap-2">
          <Button type="button" variant="outline" className="flex-1" onClick={() => onBack()} disabled={busy}>
            Back
          </Button>
          <Button type="submit" className="flex-1" disabled={busy || code.length !== 6}>
            {busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Verify
          </Button>
        </div>
      </form>
      <p className="mt-4 text-xs text-muted-foreground">{TOTP_LOST}</p>
    </>
  );
}
