/**
 * The FireFlo mark, and the product name it sits beside.
 *
 * <p>Served from `public/` as an `<img>` rather than inlined as JSX. Inlining would be tempting for
 * a 24px icon, but this export carries its own `<defs>` — four clip paths, three masks and a colour
 * matrix filter — and those ids would collide the moment two copies rendered on one page. An `<img>`
 * gives each instance its own document, costs one cached request, and keeps ~6 kB of `<path>` data
 * out of the JS bundle.
 *
 * <p>No `currentColor`: this is a fixed three-green brand mark and it must look the same in either
 * theme.
 */

import type { PortalMark } from "@/lib/brand";

/** Set from `package.json` at build time — see `next.config.ts`. */
export const APP_VERSION = process.env.NEXT_PUBLIC_APP_VERSION ?? "";

export function FireFloMark({
  className = "h-6 w-6",
  mark,
}: {
  className?: string;
  /**
   * The portal's mark, resolved on the server by `portalMark()` in lib/brand.ts: the operator's
   * logo, the brand's initial, or FireFlo's flame. Absent on the operator surfaces, which are
   * FireFlo's and draw FireFlo's flame.
   */
  mark?: PortalMark;
}) {
  if (mark && "letter" in mark) {
    //a neutral badge with the brand's initial: nothing FireFlo-shaped on a white-labelled portal
    return (
      <span
        aria-hidden="true"
        className={`grid shrink-0 place-items-center rounded-md bg-primary text-xs font-bold leading-none text-primary-foreground ${className}`}
      >
        {mark.letter}
      </span>
    );
  }
  //decorative: every place this appears, the brand is written next to it in text
  // eslint-disable-next-line @next/next/no-img-element
  return <img src={mark?.src ?? "/fireflo-mark.svg"} alt="" aria-hidden="true" className={`shrink-0 ${className}`} />;
}

/**
 * The portal's name beside the mark, as one unit.
 *
 * <p><strong>No version.</strong> Its only callers are the customer portal -- the public sign-in
 * page and the signed-in frame -- and MisShell's own rule is that a customer surface never shows
 * one: on a white-labelled portal a version string is a fingerprint that names the platform
 * underneath, and on the sign-in page it was readable by anybody, signed in or not. It used to
 * print APP_VERSION here, against that rule, from when the operator sidebar used this too. The
 * operator side carries its own version badge.
 *
 * <p>`name` exists because a tenant may run the portal under its own brand -- see
 * {@code lib/brand.ts}.
 */
export function FireFloWordmark({
  className = "",
  name = "FireFlo",
}: { className?: string; name?: string }) {
  return (
    <span className={`flex min-w-0 items-baseline gap-1.5 ${className}`}>
      <h2 className="truncate font-heading text-xl font-bold tracking-tight">{name}</h2>
    </span>
  );
}
