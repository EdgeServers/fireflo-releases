"use client";
import { usePathname } from "next/navigation";
import { Pin, PinOff } from "lucide-react";
import { usePinsOptional } from "@/components/usePins";
import { pinnablePath } from "@/lib/pins";
import { cn } from "@/lib/utils";

/**
 * Pins this page to the top bar, or unpins it -- the bookmark star, for the operator panel.
 *
 * <p>Renders nothing outside the operator shell (no provider: the portal) and on a page that cannot
 * be pinned. The path only is pinned, never the query: the operator's choice, see `lib/pins.ts`.
 */
export function PinButton({ label }: { label: string }) {
  const pins = usePinsOptional();
  const pathname = usePathname();
  if (!pins || !label.trim() || !pinnablePath(pathname)) {
    return null;
  }
  const pinned = pins.isPinned(pathname);
  const action = pinned ? "Unpin from top bar" : "Pin to top bar";
  return (
    <button
      type="button"
      onClick={() => pins.toggle({ href: pathname, label })}
      aria-pressed={pinned}
      aria-label={action}
      title={action}
      className={cn(
        "group/pin shrink-0 rounded-md p-1.5 transition-colors hover:bg-muted",
        pinned ? "text-foreground" : "text-muted-foreground hover:text-foreground"
      )}
    >
      {pinned ? (
        <>
          <Pin className="h-4 w-4 fill-current group-hover/pin:hidden" />
          <PinOff className="hidden h-4 w-4 group-hover/pin:block" />
        </>
      ) : (
        <Pin className="h-4 w-4" />
      )}
    </button>
  );
}
