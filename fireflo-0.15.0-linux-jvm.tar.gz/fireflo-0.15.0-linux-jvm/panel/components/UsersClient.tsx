"use client";
import { useState } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { useConfirmChange } from "@/components/ConfirmProvider";
import { Checkbox } from "@/components/ui/checkbox";
import { KeyRound, Plus, ShieldCheck, UserRound } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button, buttonClasses } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { TBody, TD, TH, THead, TR, Table, TableEmpty } from "@/components/ui/table";
import { PageHeader } from "@/components/ui/page-header";
import { SetPasswordDialog } from "@/components/SetPasswordDialog";
import { UserForm } from "@/components/UserForm";
import { useUsers } from "@/components/useUsers";
import { ADMIN_ROLE, CUSTOMER_ROLE, OPERATOR_ROLE } from "@/lib/roles";
import type { PublicUser, UsersTwoFactor } from "@/lib/user-types";
import { TOTP_UNSEALED } from "@/lib/totp-view";

/**
 * Who may sign in, and what they did.
 *
 * <p>Admin-only: the page's server component checks the session and the API answers 404 to anyone
 * else, so an operator never sees this and the nav item is not rendered for them. What they DID is
 * the Access log report; each row here links into it.
 */
export function UsersClient() {
  const { users, error, loading, busy, load, create, patch, setPassword, twoFactor } = useUsers();
  const { data: session } = useSession();
  const me = session?.user?.userId ? Number(session.user.userId) : null;
  const [creating, setCreating] = useState(false);
  const [resetting, setResetting] = useState<PublicUser | null>(null);

  const panel = users.filter((u) => u.role !== CUSTOMER_ROLE);
  const customers = users.filter((u) => u.role === CUSTOMER_ROLE);

  return (
    <>
      <PageHeader
        title="Users"
        description="Who may sign in to this panel and to the customer portal, and what they did."
        actions={
          !creating ? (
            <Button onClick={() => setCreating(true)} className="gap-2">
              <Plus className="h-4 w-4" />
              Add user
            </Button>
          ) : undefined
        }
      />

      {creating && (
        <UserForm
          onCreate={create}
          onDone={() => {
            setCreating(false);
            void load();
          }}
          onCancel={() => setCreating(false)}
        />
      )}

      {error && (
        <Card>
          <CardContent className="py-4 text-sm text-destructive">{error}</CardContent>
        </Card>
      )}

      {twoFactor.available && (
        <TwoFactorRequirement
          twoFactor={twoFactor}
          myTotp={panel.find((u) => u.id === me)?.totpEnabledAt ?? null}
          onChanged={() => void load()}
        />
      )}

      <Section title="Panel" hint="Admins manage users; operators run the gateway." twoFactor={twoFactor.available}>
        {panel.length === 0 && !loading && (
          <Empty>
            No admin or operator in the database yet. Sign-in is using OPERATOR_PASSWORD from panel.env, which goes
            away next release — add an admin here or with <code>fireflo user add</code>.
          </Empty>
        )}
        {panel.map((u) => (
          <UserRow
            key={u.id}
            user={u}
            isMe={u.id === me}
            busy={busy === u.id}
            onToggle={() => patch(u.id, { enabled: !u.enabled })}
            onRole={(role) => patch(u.id, { role })}
            onPassword={() => setResetting(u)}
            logHref={`/cp/access-log?user=${u.id}`}
            twoFactor={twoFactor.available}
          />
        ))}
      </Section>

      <Section twoFactor={twoFactor.available} title="Customers" hint="People who sign in to the portal. One account may have several.">
        {customers.length === 0 && !loading && <Empty>No customer users. Adding an email to an account creates one.</Empty>}
        {customers.map((u) => (
          <UserRow
            key={u.id}
            user={u}
            isMe={false}
            busy={busy === u.id}
            onToggle={() => patch(u.id, { enabled: !u.enabled })}
            onPassword={() => setResetting(u)}
            logHref={`/cp/access-log?user=${u.id}`}
            twoFactor={twoFactor.available}
          />
        ))}
      </Section>

      {resetting && (
        <SetPasswordDialog
          email={resetting.email}
          open
          onClose={() => setResetting(null)}
          onSubmit={(pw) => setPassword(resetting.id, pw)}
        />
      )}
    </>
  );
}

/**
 * The admin's switch: two-factor required of every operator. Confirmed in the panel's modal, written
 * by the admin-only route, logged as totp_required_changed. No reset button by design -- a lost
 * authenticator is reset on the server with `fireflo user totp-reset`.
 */
function TwoFactorRequirement({ twoFactor, myTotp, onChanged }: {
  twoFactor: UsersTwoFactor;
  myTotp: string | null;
  onChanged: () => void;
}) {
  const confirm = useConfirmChange();
  const [saving, setSaving] = useState(false);
  const [problem, setProblem] = useState("");

  async function change(required: boolean) {
    const ok = await confirm({
      title: required ? "Require two-factor authentication" : "Stop requiring two-factor authentication",
      consequence: required
        ? "Every admin and operator must use an authenticator app. Those who have not set one up reach only the set-up page from their next request until they do; nobody is signed out."
          + (myTotp ? "" : " You have not set one up yourself, so that includes you, straight away.")
        : "Operators may sign in with a password or a link alone again. Those who set up an authenticator keep it, and can now turn it off.",
      confirmLabel: required ? "Require it" : "Stop requiring it",
      tone: "caution",
      changes: [{ label: "smsg.panel.operator.totp.required", from: String(twoFactor.required), to: String(required) }],
    });
    if (!ok) {
      return;
    }
    setSaving(true);
    setProblem("");
    try {
      const res = await fetch("/api/control/users/totp-required", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ required }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok) {
        setProblem(json?.error ?? `Request failed (${res.status})`);
        return;
      }
      if (required && !myTotp) {
        //this admin is now one of those who must enrol: the layout sends them there
        window.location.assign("/cp/two-factor");
        return;
      }
      onChanged();
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card>
      <CardContent className="space-y-1 py-4">
        <label className="flex items-start gap-2 text-sm">
          <Checkbox className="mt-0.5" checked={twoFactor.required} disabled={saving}
            onChange={(e) => void change(e.target.checked)} />
          <span>
            <span className="font-medium">Require two-factor authentication for operators</span>
            <span className="block text-xs text-muted-foreground">
              Every admin and operator then signs in with a code from an authenticator app as well. A lost
              authenticator is reset on the server: <code>fireflo user totp-reset --email …</code>
            </span>
          </span>
        </label>
        {problem && <p className="text-sm text-destructive">{problem}</p>}
        {twoFactor.unsealed && <p className="text-sm text-warning" role="status">{TOTP_UNSEALED}</p>}
      </CardContent>
    </Card>
  );
}

function Section({ title, hint, twoFactor = false, children }: { title: string; hint: string; twoFactor?: boolean; children: React.ReactNode }) {
  return (
    <section className="space-y-2">
      <div>
        <h2 className="text-title">{title}</h2>
        <p className="text-xs text-muted-foreground">{hint}</p>
      </div>
      <Table>
        <THead>
          <tr>
            <TH>User</TH>
            <TH>Role</TH>
            <TH>Last sign-in</TH>
            {twoFactor && <TH>Two-factor</TH>}
            <TH align="right">Actions</TH>
          </tr>
        </THead>
        <TBody>{children}</TBody>
      </Table>
    </section>
  );
}

function Empty({ children }: { children: React.ReactNode }) {
  return <TableEmpty colSpan={5}>{children}</TableEmpty>;
}

export function UserRow({
  user,
  isMe,
  busy,
  onToggle,
  onRole,
  onPassword,
  logHref,
  twoFactor = false,
}: {
  user: PublicUser;
  isMe: boolean;
  busy: boolean;
  onToggle: () => void;
  onRole?: (role: "admin" | "operator") => void;
  onPassword: () => void;
  logHref?: string;
  /** Show the two-factor column (gateway V1.114.0). */
  twoFactor?: boolean;
}) {
  const Icon = user.role === ADMIN_ROLE ? ShieldCheck : UserRound;
  return (
    <TR className={!user.enabled ? "opacity-60" : undefined}>
      <TD primary>
        <span className="flex items-center gap-2.5">
          <Icon className="h-4 w-4 shrink-0 text-muted-foreground" />
          <span className="min-w-0">
            <span className="block truncate">{user.email}</span>
            {user.accountId && (
              <Link
                href={`/cp/accounts/${encodeURIComponent(user.accountId)}`}
                className="block text-xs font-normal text-muted-foreground underline-offset-2 hover:underline"
              >
                {user.accountId}
              </Link>
            )}
          </span>
        </span>
      </TD>
      <TD>
        <span className="flex flex-wrap gap-1">
          <Badge variant="outline" className="capitalize">{user.role}</Badge>
          {isMe && <Badge>you</Badge>}
          {!user.enabled && <Badge variant="destructive">disabled</Badge>}
          {!user.hasPassword && <Badge variant="warning">link only</Badge>}
        </span>
      </TD>
      <TD muted className="whitespace-nowrap">
        {user.lastLoginAt ? new Date(user.lastLoginAt).toLocaleString() : "Never"}
      </TD>
      {twoFactor && (
        <TD muted className="whitespace-nowrap">
          {user.role === CUSTOMER_ROLE
            ? "—"
            : user.totpEnabledAt
              ? <><Badge variant="success">On</Badge> since {new Date(user.totpEnabledAt).toLocaleDateString()}</>
              : "Off"}
        </TD>
      )}
      <TD align="right">
        <span className="flex flex-wrap justify-end gap-1">
          {onRole && !isMe && (
            <Button variant="outline" size="sm" disabled={busy} onClick={() => onRole(user.role === ADMIN_ROLE ? OPERATOR_ROLE : ADMIN_ROLE)}>
              {user.role === ADMIN_ROLE ? "Make operator" : "Make admin"}
            </Button>
          )}
          <Button variant="outline" size="sm" disabled={busy} onClick={onPassword}>
            <KeyRound className="h-3.5 w-3.5" />
            {user.hasPassword ? "Reset password" : "Set password"}
          </Button>
          {logHref && (
            <Link href={logHref} className={buttonClasses({ variant: "ghost", size: "sm" })}>
              History
            </Link>
          )}
          {!isMe && (
            <Button variant={user.enabled ? "ghost" : "outline"} size="sm" disabled={busy} onClick={onToggle}>
              {user.enabled ? "Disable" : "Enable"}
            </Button>
          )}
        </span>
      </TD>
    </TR>
  );
}
