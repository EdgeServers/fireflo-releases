import { test } from "node:test";
import assert from "node:assert/strict";
import { HOURLY_MAX_AGE_MS, sourceFor } from "./usage-source.ts";
import { usageHourlySql } from "./usage-summary-sql.ts";

const NOW = Date.parse("2026-10-23T12:00:00Z");

test("the hourly summary is leaned on only while the gateway keeps it current", () => {
  assert.equal(sourceFor(new Date(NOW - 60_000), NOW, HOURLY_MAX_AGE_MS), "hourly");
  assert.equal(sourceFor(new Date(NOW - 4 * 3_600_000), NOW, HOURLY_MAX_AGE_MS), "live", "a stopped rollup");
  assert.equal(sourceFor(null, NOW, HOURLY_MAX_AGE_MS), "live", "no summary table");
});

test("a day series on the hourly source reads whole hours from usage_hourly, below the seam", () => {
  const sql = usageHourlySql({ bucket: "day", account: false, vendorAttempt: true });
  assert.match(sql, /FROM cut, usage_hourly h/);
  assert.match(sql, /h\.hour >= cut\.first_hour AND h\.hour < cut\.seam/);
  assert.match(sql, /\(\(h\.hour AT TIME ZONE \$3\)::date::timestamp AT TIME ZONE \$3\)/, "hours filed under their billing day");
});
