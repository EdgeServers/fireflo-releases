/**
 * Who a stats request is answered for (`stats-route.ts`), with the two session checks passed in so
 * the order can be tested without cookies.
 *
 * <p>An alias that serves one audience (`/api/mis/…` is the portal's, `/api/control/…` the
 * operator's) resolves only that one. Trying the operator first there hid a portal session behind an
 * operator session in the same browser: `who` came out "operator" and the portal's own alias
 * answered 404 (TC-17.03.01-P01). Only the unscoped `/api/stats/<metric>` tries both, operator first.
 *
 * @param only the one audience this route serves, if any
 * @param asOperator resolves when there is an operator session, throws otherwise
 * @param asCustomer resolves when there is a customer session, throws otherwise
 * @param isRefusal whether a thrown error means "no such session" rather than a failure
 * @return the audience, or null when the caller has no session this route accepts
 */
export async function resolveAudience(
  only: "operator" | "customer" | undefined,
  asOperator: () => Promise<unknown>,
  asCustomer: () => Promise<unknown>,
  isRefusal: (err: unknown) => boolean
): Promise<"operator" | "customer" | null> {
  const attempt = async (who: "operator" | "customer"): Promise<"operator" | "customer" | null> => {
    try {
      await (who === "operator" ? asOperator() : asCustomer());
      return who;
    } catch (err) {
      if (isRefusal(err)) {
        return null;
      }
      throw err;
    }
  };
  if (only) {
    return attempt(only);
  }
  return (await attempt("operator")) ?? attempt("customer");
}
