import { type ClassValue, clsx } from "clsx";
import { extendTailwindMerge } from "tailwind-merge";

/**
 * The panel's role sizes (app/globals.css), declared to tailwind-merge as font sizes.
 *
 * <p>Without this, `twMerge` reads an unknown `text-*` as a text COLOUR, so
 * `cn("text-title", "text-muted-foreground")` would drop the size and keep the colour -- every
 * heading given a tone by its caller would fall back to body size with no error anywhere.
 */
export const ROLE_TEXT_SIZES = ["page", "entity", "title", "section", "figure"] as const;

const twMerge = extendTailwindMerge({
  extend: { theme: { text: [...ROLE_TEXT_SIZES] } },
});

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
