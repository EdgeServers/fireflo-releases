import { cdrBoundary, query } from "./metrics-db.ts";
import { cdrRouteSql, cdrTableFor, cdrWindowIsHot, messageIdTime, type CdrKind, type CdrSince } from "./cdr-grain.ts";

export { cdrBoundary };

/**
 * Which call record tables a panel reader reads: the hot ones, or the `_all` views (gateway 0.15,
 * V1.112.0). The routing rule is in `cdr-grain.ts`, database-free; the boundary is read and cached
 * in `metrics-db.ts`.
 *
 * <p>A reader passes its SQL through {@link cdrSql} with the start of its window. A window that
 * starts inside the hot tables (less the hour of margin) reads them as written; any other reads the
 * views, which hold both sides, so a statement, a reconciliation or a search over an archived month
 * gives exactly the answer it gave before the tables were split. A statement nobody routed is read
 * through the views by `metrics-db.ts` -- so routing is how a reader is made FAST, never what makes
 * it right.
 *
 * <p>Against a gateway before 0.15 there is no `cdr_tier`: every statement runs exactly as written.
 * Server-only: importing this pulls `pg`.
 */

/** `cdr_<kind>` or `cdr_<kind>_all` for a window starting at `since` (null: from the beginning). */
export async function cdrTable(kind: CdrKind, since: CdrSince): Promise<string> {
  return cdrTableFor(kind, since, await cdrBoundary());
}

/** `sql` routed for a window starting at `since`: as written, or reading the `_all` views. */
export async function cdrSql(sql: string, since: CdrSince): Promise<string> {
  return cdrRouteSql(sql, since, await cdrBoundary());
}

/** Whether a window starting at `since` is read from the hot tables alone. */
export async function cdrIsHot(since: CdrSince): Promise<boolean> {
  return cdrWindowIsHot(since, await cdrBoundary());
}

/** {@link query}, routed for a window starting at `since`. */
export async function cdrQuery<T extends Record<string, unknown>>(
  sql: string,
  params: unknown[],
  since: CdrSince
): Promise<T[]> {
  return query<T>(await cdrSql(sql, since), params);
}

/**
 * A lookup of one message by id: on the hot tables when the id's own time (UUIDv7) is inside them,
 * and again through the views if that found nothing -- an id from before 0.12.25, a clock that was
 * off. An id with no time goes straight to the views.
 *
 * @param run the query, given the SQL to execute
 * @param found whether a result is a hit; a miss on hot is retried on everything
 * @returns the result, and the window the message's other records can be read for: the id's time
 *     when it was found in the hot tables, null (everything) when it was not
 */
export async function cdrLookupById<T>(
  sql: string,
  id: string,
  run: (sql: string) => Promise<T>,
  found: (result: T) => boolean
): Promise<{ result: T; since: Date | null }> {
  const boundary = await cdrBoundary();
  const at = messageIdTime(id);
  if (boundary === null) {
    return { result: await run(cdrRouteSql(sql, at, boundary)), since: at };
  }
  if (cdrWindowIsHot(at, boundary)) {
    const result = await run(cdrRouteSql(sql, at, boundary));
    if (found(result)) {
      return { result, since: at };
    }
  }
  return { result: await run(cdrRouteSql(sql, null, boundary)), since: null };
}
