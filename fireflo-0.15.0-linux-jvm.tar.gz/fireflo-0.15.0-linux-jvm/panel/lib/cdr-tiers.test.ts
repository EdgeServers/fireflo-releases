import { strict as assert } from "node:assert";
import { test } from "node:test";

import {
  CDR_EVERYTHING,
  CDR_RECEIPT_REACH_MS,
  CDR_ROUTED,
  CDR_TIER_MARGIN_MS,
  cdrAllSql,
  cdrEarlier,
  cdrNamesTable,
  cdrRouteSql,
  cdrRouteUnmarked,
  cdrTableFor,
  cdrWindowIsHot,
  messageIdTime,
  messageRows,
  readCdrBoundary,
} from "./cdr-grain.ts";
import { OUTCOME_LATERAL } from "./usage-summary-sql.ts";

const boundary = new Date("2026-10-25T00:00:00Z");
const hour = 3_600_000;

test("a window inside the hot days reads the hot table; one starting earlier, or unbounded, the view", () => {
  assert.equal(cdrTableFor("submit", new Date(boundary.getTime() + 2 * hour), boundary), "cdr_submit");
  assert.equal(cdrTableFor("final", new Date(boundary.getTime() - 1), boundary), "cdr_final_all");
  assert.equal(cdrTableFor("rejected", null, boundary), "cdr_rejected_all");
  assert.equal(cdrTableFor("event", "", boundary), "cdr_event_all");
  assert.equal(cdrTableFor("interim", "not a date", boundary), "cdr_interim_all", "a start that does not parse reads everything");
});

test("the hour of margin: a window must start an hour inside hot to read hot alone", () => {
  //a receipt or a retry keyed to a message can carry a time a little before the message's own
  const atEdge = new Date(boundary.getTime() + CDR_TIER_MARGIN_MS);
  assert.equal(cdrWindowIsHot(atEdge, boundary), true);
  assert.equal(cdrWindowIsHot(new Date(atEdge.getTime() - 1), boundary), false);
  assert.equal(cdrWindowIsHot(atEdge.toISOString(), boundary), true, "an ISO string is a start too");
});

test("without tiers (a gateway before 0.15) every window reads the plain tables", () => {
  for (const since of [null, undefined, new Date(0), "2020-01-01T00:00:00Z"]) {
    assert.equal(cdrTableFor("submit", since, null), "cdr_submit");
    assert.equal(cdrWindowIsHot(since, null), true);
  }
  const sql = "SELECT * FROM cdr_submit s";
  assert.equal(cdrRouteSql(sql, null, null), `${CDR_ROUTED} ${sql}`);
  assert.equal(cdrRouteUnmarked(sql, null), sql, "nothing is rewritten on a database with no tiers");
});

test("an unreadable cdr_tier routes everything to the views", () => {
  assert.equal(cdrWindowIsHot(new Date(), CDR_EVERYTHING), false);
  assert.equal(cdrTableFor("submit", new Date(), CDR_EVERYTHING), "cdr_submit_all");
});

test("the rewrite names the five tables' views and nothing else", () => {
  const sql = `SELECT s.id FROM cdr_submit s
      JOIN cdr_final f ON f.gateway_msg_id = s.gateway_msg_id
      LEFT JOIN cdr_interim i ON TRUE, cdr_event e, cdr_rejected r
     WHERE EXISTS (SELECT 1 FROM cdr_submit_archive a) AND idx_cdr_submit_time IS NULL
       AND cdr_submit.id > 0 AND old_cdr_submit IS NULL AND x.cdr_final_all IS NULL`;
  const out = cdrAllSql(sql);
  assert.match(out, /FROM cdr_submit_all s/);
  assert.match(out, /JOIN cdr_final_all f/);
  assert.match(out, /cdr_interim_all i/);
  assert.match(out, /cdr_event_all e, cdr_rejected_all r/);
  assert.match(out, /cdr_submit_archive a/, "the archive keeps its name");
  assert.match(out, /idx_cdr_submit_time/, "a longer identifier is not a table");
  assert.match(out, /cdr_submit_all\.id > 0/, "a qualified column follows its table");
  assert.match(out, /old_cdr_submit/);
  assert.match(out, /x\.cdr_final_all IS NULL/, "already a view: not doubled");
  assert.equal(cdrAllSql(out), out, "idempotent");
});

test("string literals are left alone, so information_schema probes still ask about the table", () => {
  const probe = "SELECT 1 FROM information_schema.columns WHERE table_name = 'cdr_submit' AND x = 'it''s cdr_final'";
  assert.equal(cdrAllSql(probe), probe);
  assert.equal(cdrNamesTable(probe), false);
  assert.equal(cdrRouteUnmarked(probe, boundary), probe);
});

test("a statement nobody routed reads through the views; a routed one is left as routed", () => {
  const sql = `SELECT count(*) FROM cdr_submit s${OUTCOME_LATERAL}`;
  const unrouted = cdrRouteUnmarked(sql, boundary);
  assert.match(unrouted, /FROM cdr_submit_all s/);
  assert.match(unrouted, /FROM cdr_final_all f/);
  const hot = cdrRouteSql(sql, new Date(boundary.getTime() + 2 * hour), boundary);
  assert.ok(hot.startsWith(CDR_ROUTED));
  assert.equal(cdrRouteUnmarked(hot, boundary), hot, "the mark says somebody chose hot on purpose");
  assert.doesNotMatch(hot, /_all/);
  //a statement naming no call record table is never touched
  assert.equal(cdrRouteUnmarked("SELECT * FROM usage_daily", boundary), "SELECT * FROM usage_daily");
});

test("the grain helpers route like any other text", () => {
  const sql = `SELECT count(*) FROM ${messageRows("s.submitted_at >= $1", { vendorAttempt: true })}${OUTCOME_LATERAL}`;
  const all = cdrRouteSql(sql, null, boundary);
  assert.doesNotMatch(all.replace(/cdr_(submit|final)_all/g, ""), /\bcdr_(submit|final)\b/);
});

test("a table routed on its own survives the statement's routing", () => {
  //a hot window whose LATERAL looks submits up from receipts: the inner name is chosen first
  const inner = cdrTableFor("submit", cdrEarlier(new Date(boundary.getTime() + 2 * hour), CDR_RECEIPT_REACH_MS), boundary);
  assert.equal(inner, "cdr_submit_all");
  const sql = cdrRouteSql(`SELECT 1 FROM cdr_final f JOIN ${inner} s USING (gateway_msg_id)`,
    new Date(boundary.getTime() + 2 * hour), boundary);
  assert.match(sql, /FROM cdr_final f JOIN cdr_submit_all s/);
  assert.equal(cdrEarlier(null, 1), null, "unbounded stays unbounded");
});

test("an id's time comes from its UUIDv7 prefix; anything else has none", () => {
  //2026-10-28T01:02:03.456Z = 0x019a2849f5c0
  const ms = Date.parse("2026-10-28T01:02:03.456Z");
  const hex = ms.toString(16).padStart(12, "0");
  const id = `${hex.slice(0, 8)}-${hex.slice(8)}-7abc-9def-0123456789ab`;
  assert.equal(messageIdTime(id)?.toISOString(), "2026-10-28T01:02:03.456Z");
  assert.equal(messageIdTime(` ${id.toUpperCase()} `)?.getTime(), ms, "trimmed, either case");
  assert.equal(messageIdTime("550e8400-e29b-41d4-a716-446655440000"), null, "version 4: no time");
  assert.equal(messageIdTime(`${hex.slice(0, 8)}-${hex.slice(8)}-7abc-cdef-0123456789ab`), null, "wrong variant");
  assert.equal(messageIdTime("abc"), null);
  assert.equal(messageIdTime(null), null);
  //routed by that time: hot when it is inside, everything when it is not or there is none
  assert.equal(cdrTableFor("submit", messageIdTime(id), boundary), "cdr_submit");
  assert.equal(cdrTableFor("submit", messageIdTime(id), new Date(ms)), "cdr_submit_all");
  assert.equal(cdrTableFor("submit", messageIdTime("legacy-id"), boundary), "cdr_submit_all");
});

/** A runner answering the two boundary reads from a canned cdr_tier. */
function runner(o: { exists: boolean; row?: Record<string, unknown> | null; fails?: boolean }) {
  const asked: string[] = [];
  const run = async (sql: string) => {
    asked.push(sql);
    if (sql.includes("to_regclass")) {
      return [{ ok: o.exists }];
    }
    if (o.fails) {
      throw new Error("permission denied for table cdr_tier");
    }
    return o.row ? [o.row] : [];
  };
  return { run, asked };
}

test("the boundary is max(hot_from, moving_to): a move under way is the boundary already", async () => {
  const hotFrom = new Date("2026-10-25T00:00:00Z");
  const moving = new Date("2026-10-26T00:00:00Z");
  assert.deepEqual(await readCdrBoundary(runner({ exists: true, row: { hot_from: hotFrom, moving_to: null } }).run),
    { boundary: hotFrom, error: null });
  assert.deepEqual(await readCdrBoundary(runner({ exists: true, row: { hot_from: hotFrom, moving_to: moving } }).run),
    { boundary: moving, error: null });
  //a moving_to behind hot_from (never written so, but) does not pull the boundary back
  assert.deepEqual(
    await readCdrBoundary(runner({ exists: true, row: { hot_from: moving, moving_to: hotFrom.toISOString() } }).run),
    { boundary: moving, error: null });
});

test("no cdr_tier is no tiers; one that cannot be read, or has no row, is everything", async () => {
  const absent = runner({ exists: false });
  assert.deepEqual(await readCdrBoundary(absent.run), { boundary: null, error: null });
  assert.equal(absent.asked.length, 1, "the table is not named when it does not exist");
  const denied = await readCdrBoundary(runner({ exists: true, fails: true }).run);
  assert.equal(denied.boundary, CDR_EVERYTHING);
  assert.match(denied.error ?? "", /permission denied/);
  const empty = await readCdrBoundary(runner({ exists: true, row: null }).run);
  assert.equal(empty.boundary, CDR_EVERYTHING);
});
