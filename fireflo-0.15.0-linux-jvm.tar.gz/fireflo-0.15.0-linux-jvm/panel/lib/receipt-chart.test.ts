import { test } from "node:test";
import assert from "node:assert/strict";
import { MAX_VENDORS, outcomeBars, timingBars, type ChartRow } from "./receipt-chart.ts";

function row(vendor: string | null, o: Partial<ChartRow>): ChartRow {
  return { vendor, sent: 0, reported: 0, expired: 0, open: 0, delivered: 0, medianToOutcome: null, p90ToOutcome: null, ...o };
}

test("a vendor's bar splits what it was sent exactly, refusals included", () => {
  //100 sent: 80 reported (70 delivered, 10 failed), 5 swept, 5 open -> 10 refused
  const [bar] = outcomeBars([row("airtel", { sent: 100, reported: 80, delivered: 70, expired: 5, open: 5 })]);
  assert.deepEqual(bar.counts, { delivered: 70, failed: 10, gaveUp: 5, open: 5, refused: 10 });
  const total = bar.delivered + bar.failed + bar.gaveUp + bar.open + bar.refused;
  assert.ok(Math.abs(total - 100) < 1e-9);
});

test("nothing sent draws an empty bar, never a division by zero", () => {
  const [bar] = outcomeBars([row("idle", {})]);
  assert.equal(bar.delivered, 0);
  assert.equal(bar.refused, 0);
});

test("the busiest vendors are drawn, the rest folded into Other", () => {
  const rows = Array.from({ length: 11 }, (_, i) => row(`v${i}`, { sent: 100 - i, reported: 100 - i, delivered: 100 - i }));
  const bars = outcomeBars(rows);
  assert.equal(bars.length, MAX_VENDORS);
  assert.equal(bars[0].vendor, "v0");
  assert.equal(bars.at(-1)!.vendor, "Other (4)");
  assert.equal(bars.at(-1)!.sent, 93 + 92 + 91 + 90);
});

test("timings only for vendors with receipts, and no Other", () => {
  const bars = timingBars([
    row("fast", { sent: 10, medianToOutcome: 1.5, p90ToOutcome: 4 }),
    row("silent", { sent: 50 }),
  ]);
  assert.deepEqual(bars, [{ vendor: "fast", median: 1.5, p90: 4 }]);
});
