import { test } from "node:test";
import assert from "node:assert/strict";
import { METRICS, audienceFor, isMetric, pickRange, type MetricSpec } from "./stats-metrics.ts";

test("every reader's default is one of its own periods, and the operator pages open on the last hour", () => {
  for (const [name, spec] of Object.entries(METRICS) as [string, MetricSpec][]) {
    for (const who of ["operator", "customer"] as const) {
      const a = spec[who];
      if (!a) continue;
      if (a.ranges.length === 0) {
        assert.equal(a.defaultRange, "", `${name}/${who}`);
      } else {
        assert.ok(a.ranges.includes(a.defaultRange), `${name}/${who} default ${a.defaultRange}`);
        if (who === "operator") assert.equal(a.defaultRange, "1h", name);
      }
    }
    assert.ok(spec.operator || spec.customer, `${name} has nobody to answer`);
  }
});

test("an unknown metric and one the caller has no reader for look the same", () => {
  assert.equal(audienceFor("nope", "operator"), null);
  assert.equal(audienceFor("vendors", "customer"), null, "vendors is the operator's alone");
  assert.equal(audienceFor("__proto__", "operator"), null);
  assert.ok(audienceFor("accounts", "customer"));
  assert.ok(isMetric("server-traffic"));
});

test("a period the reader does not offer falls back to its default", () => {
  const op = audienceFor("vendors", "operator")!;
  assert.equal(pickRange(op, "7d"), "7d");
  assert.equal(pickRange(op, "14d"), "1h");
  assert.equal(pickRange(op, null), "1h");
  const portal = audienceFor("overview", "customer")!;
  assert.equal(pickRange(portal, "1h"), "14d", "the portal chart is by day");
  assert.equal(pickRange(audienceFor("server-traffic", "operator")!, "7d"), "1h", "no summary holds a listener");
});
