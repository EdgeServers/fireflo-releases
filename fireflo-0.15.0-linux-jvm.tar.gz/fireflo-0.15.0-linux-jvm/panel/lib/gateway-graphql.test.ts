import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import {
  ADMIN_TOKEN_HELP,
  BASE_URL_HELP,
  GATEWAY_TOO_OLD,
  GatewayError,
  PANEL_CODES,
  READ_TOKEN_HELP,
  decodeFileResult,
  executeGql,
  fetchMetricsText,
  gqlData,
  snakeCaseKeys,
  snakeCaseKeysDeep,
} from "./gateway-graphql-core.ts";

/**
 * The GraphQL client's contract with the routes: what each kind of gateway answer turns into.
 *
 * <p>Tests the core rather than `lib/gateway-graphql.ts`, which only wraps these outcomes in
 * `NextResponse`s and cannot be loaded under plain `node --test`. Global `fetch` is replaced per
 * test; each test file runs in its own process, so nothing leaks.
 */

interface Seen {
  url: string;
  init: RequestInit | undefined;
}

const seen: Seen[] = [];

/** Answers each call in turn; the last answer repeats. */
function answer(...responses: (() => Response)[]): void {
  let i = 0;
  globalThis.fetch = (async (url: string | URL | Request, init?: RequestInit) => {
    seen.push({ url: String(url), init });
    const make = responses[Math.min(i, responses.length - 1)];
    i++;
    return make();
  }) as typeof fetch;
}

const json = (status: number, body: unknown) => () =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });

beforeEach(() => {
  seen.length = 0;
  process.env.GATEWAY_OPS_URL = "http://gw:9000/";
  process.env.GATEWAY_OPS_TOKEN = "read-secret";
  process.env.GATEWAY_OPS_ADMIN_TOKEN = "admin-secret";
  process.env.GATEWAY_BASE_URL = "http://gw:8080";
  delete process.env.GATEWAY_OPS_URLS;
});

test("a success envelope answers the single root field's value", async () => {
  answer(json(200, { data: { health: { version: "FireFlo 0.13.0", snapshot: { router_queue: 2 } } } }));
  const out = await executeGql<{ version: string }>({ query: "query Health { health { version } }" });
  assert.deepEqual(out, { ok: true, data: { version: "FireFlo 0.13.0", snapshot: { router_queue: 2 } } });

  //the transport: POST /graphql on the ops base with the trailing slash dropped, bearer read token,
  //the document in the body
  assert.equal(seen.length, 1);
  assert.equal(seen[0].url, "http://gw:9000/graphql");
  assert.equal(seen[0].init?.method, "POST");
  const headers = seen[0].init?.headers as Record<string, string>;
  assert.equal(headers.Authorization, "Bearer read-secret");
  assert.deepEqual(JSON.parse(String(seen[0].init?.body)), { query: "query Health { health { version } }" });
});

test("admin sends the admin token and the variables", async () => {
  answer(json(200, { data: { reload: { adopted: true } } }));
  await executeGql({ query: "mutation Reload { reload { adopted } }", auth: "admin", variables: { a: 1 } });
  const headers = seen[0].init?.headers as Record<string, string>;
  assert.equal(headers.Authorization, "Bearer admin-secret");
  assert.deepEqual(JSON.parse(String(seen[0].init?.body)).variables, { a: 1 });
});

test("an error with extensions is forwarded at the gateway's status when passErrors is on", async () => {
  answer(
    json(200, {
      data: null,
      errors: [
        {
          message: "That licence key is not one we issued.",
          path: ["licenseActivate"],
          extensions: { code: "LICENCE_REFUSED", status: 402 },
        },
      ],
    })
  );
  const out = await executeGql({ query: "mutation X { licenseActivate(key: \"k\") { verdict } }", auth: "admin", passErrors: true });
  assert.deepEqual(out, {
    ok: false,
    status: 402,
    code: "LICENCE_REFUSED",
    error: "That licence key is not one we issued.",
  });
});

test("the same error is a 502 with a sentence when passErrors is off", async () => {
  answer(
    json(200, {
      data: null,
      errors: [{ message: "Licence lapsed", path: ["workers"], extensions: { code: "LICENCE_LAPSED", status: 402 } }],
    })
  );
  const out = await executeGql({ query: "query X { workers { name } }" });
  assert.equal(out.ok, false);
  if (out.ok) return;
  assert.equal(out.status, 502);
  assert.equal(out.code, "LICENCE_LAPSED");
  assert.match(out.error, /Licence lapsed/);
  assert.match(out.error, /licence is not current/);
});

test("a field refused for the token's level names the token, like a 404 used to", async () => {
  answer(json(200, { data: null, errors: [{ message: "Not found", path: ["reload"], extensions: { code: "NOT_FOUND", status: 404 } }] }));
  const out = await executeGql({ query: "mutation Reload { reload { adopted } }", auth: "admin" });
  assert.equal(out.ok, false);
  if (out.ok) return;
  assert.match(out.error, /smsg\.ops\.admin\.token/);
  assert.match(out.error, /GATEWAY_OPS_ADMIN_TOKEN/);
  assert.doesNotMatch(out.error, /Not found/, "the gateway's placeholder adds nothing");
});

test("HTTP 404 then /ops/health answering 200 means a 0.12.x gateway", async () => {
  answer(json(404, { message: "Not found" }), json(200, { data: { observed_at: "x" } }));
  const out = await executeGql({ query: "query Health { health { version } }" });
  assert.deepEqual(out, { ok: false, status: 502, code: PANEL_CODES.tooOld, error: GATEWAY_TOO_OLD });
  assert.equal(seen.length, 2, "exactly one probe");
  assert.equal(seen[1].url, "http://gw:9000/ops/health");
  const headers = seen[1].init?.headers as Record<string, string>;
  assert.equal(headers.Authorization, "Bearer read-secret", "the probe uses the read token whichever token the call used");
});

test("HTTP 404 with the probe also refused is the token or allow-list sentence", async () => {
  answer(json(404, { message: "Not found" }));
  const out = await executeGql({ query: "query Health { health { version } }" });
  assert.equal(out.ok, false);
  if (out.ok) return;
  assert.equal(out.status, 502);
  assert.equal(out.code, PANEL_CODES.refused);
  assert.match(out.error, /smsg\.ops\.token is unset there or does not match GATEWAY_OPS_TOKEN/);
  assert.match(out.error, /allow-list/);
  assert.equal(seen.length, 2);
});

test("a token that is not set is a 503 with the help text, and nothing is fetched", async () => {
  delete process.env.GATEWAY_OPS_TOKEN;
  answer(json(200, { data: {} }));
  const read = await executeGql({ query: "query X { health { version } }" });
  assert.deepEqual(read, { ok: false, status: 503, code: PANEL_CODES.notConfigured, error: READ_TOKEN_HELP });

  delete process.env.GATEWAY_OPS_ADMIN_TOKEN;
  const admin = await executeGql({ query: "mutation X { reload { adopted } }", auth: "admin" });
  assert.deepEqual(admin, { ok: false, status: 503, code: PANEL_CODES.notConfigured, error: ADMIN_TOKEN_HELP });
  assert.equal(seen.length, 0);
});

test("a gateway that cannot be reached is a 502 naming the fault", async () => {
  globalThis.fetch = (async () => {
    throw new Error("connect ECONNREFUSED");
  }) as typeof fetch;
  const out = await executeGql({ query: "query X { health { version } }" });
  assert.equal(out.ok, false);
  if (out.ok) return;
  assert.equal(out.status, 502);
  assert.equal(out.code, PANEL_CODES.unreachable);
  assert.match(out.error, /Could not reach the gateway: connect ECONNREFUSED/);
});

test("gqlData answers the value or throws the gateway's status and code", async () => {
  answer(json(200, { data: { license: { verdict: "active" } } }));
  assert.deepEqual(await gqlData({ query: "query L { license { verdict } }" }), { verdict: "active" });

  answer(json(200, { data: null, errors: [{ message: "No such hold", extensions: { code: "NOT_FOUND", status: 404 } }] }));
  await assert.rejects(
    gqlData({ query: "mutation X { bindHoldLift(id: 1) }", auth: "admin" }),
    (err: unknown) => {
      assert.ok(err instanceof GatewayError);
      assert.equal(err.status, 404);
      assert.equal(err.code, "NOT_FOUND");
      assert.equal(err.message, "No such hold");
      return true;
    }
  );
});

test("a file result decodes to bytes under a safe filename", () => {
  const { bytes, filename, contentType } = decodeFileResult({
    filename: "../etc/capture one.pcap",
    contentType: "application/vnd.tcpdump.pcap",
    bytesBase64: Buffer.from("hello").toString("base64"),
    size: 5,
  });
  assert.equal(Buffer.from(bytes).toString("utf8"), "hello");
  assert.equal(filename, "..-etc-capture-one.pcap");
  assert.equal(contentType, "application/vnd.tcpdump.pcap");
  assert.equal(decodeFileResult({ filename: "", contentType: "nonsense", bytesBase64: "", size: 0 }).contentType, "application/octet-stream");
});

test("metrics are read from the main port with the read token", async () => {
  answer(() => new Response("# HELP jvm_threads\njvm_threads 4\n", { status: 200 }));
  const out = await fetchMetricsText();
  assert.deepEqual(out, { text: "# HELP jvm_threads\njvm_threads 4\n" });
  assert.equal(seen[0].url, "http://gw:8080/q/metrics");
  const headers = seen[0].init?.headers as Record<string, string>;
  assert.equal(headers.Authorization, "Bearer read-secret");
});

test("metrics fall back to the customer REST address, which is the same main port", async () => {
  const before = process.env.GATEWAY_BASE_URL;
  delete process.env.GATEWAY_BASE_URL;
  process.env.GATEWAY_API_URL = "http://gw-api:8081/";
  try {
    answer(() => new Response("up 1\n", { status: 200 }));
    const out = await fetchMetricsText();
    assert.deepEqual(out, { text: "up 1\n" });
    assert.equal(seen[0].url, "http://gw-api:8081/q/metrics");
  } finally {
    delete process.env.GATEWAY_API_URL;
    if (before !== undefined) process.env.GATEWAY_BASE_URL = before;
  }
});

test("metrics without a main-port URL is the help text, not a fetch", async () => {
  delete process.env.GATEWAY_BASE_URL;
  delete process.env.GATEWAY_API_URL;
  answer(() => new Response("", { status: 200 }));
  const out = await fetchMetricsText();
  assert.ok("failed" in out);
  assert.equal(out.failed.status, 503);
  assert.equal(out.failed.error, BASE_URL_HELP);
  assert.equal(seen.length, 0);
});

test("snake_case keys keep a REST-era response shape", () => {
  assert.deepEqual(snakeCaseKeys({ daysUntilFrozen: 3, licenseId: null, verdict: "active" }), {
    days_until_frozen: 3,
    license_id: null,
    verdict: "active",
  });
});

test("deep snake_case reaches nested objects and arrays, and leaves scalars alone", () => {
  assert.deepEqual(
    snakeCaseKeysDeep({
      rows: [{ sessionId: 3, bindType: "TRX", tpsMeasured: null }],
      total: 1,
      events: [{ seq: 1, sessionId: 9, text: "bind_transceiver" }],
      lines: ["a", "b"],
      startedAt: null,
    }),
    {
      rows: [{ session_id: 3, bind_type: "TRX", tps_measured: null }],
      total: 1,
      events: [{ seq: 1, session_id: 9, text: "bind_transceiver" }],
      lines: ["a", "b"],
      started_at: null,
    }
  );
  assert.equal(snakeCaseKeysDeep(null), null);
  assert.equal(snakeCaseKeysDeep("x"), "x");
});

test("GATEWAY_OPS_URLS: calls the first node that answers, and moves on when it stops", async () => {
  process.env.GATEWAY_OPS_URLS = "gw-1=http://n1:9000,gw-2=http://n2:9000";
  let n1Up = true;
  globalThis.fetch = (async (url: string | URL | Request, init?: RequestInit) => {
    seen.push({ url: String(url), init });
    if (String(url).startsWith("http://n1") && !n1Up) {
      throw new TypeError("fetch failed");
    }
    return json(200, { data: { health: { version: "FireFlo 0.14.0" } } })();
  }) as typeof fetch;

  const first = await executeGql({ query: "query Health { health { version } }", auth: "admin" });
  assert.equal(first.ok, true);
  //one probe of gw-1 with the READ token, then the call itself there with the admin token
  assert.deepEqual(
    seen.map((s) => [s.url, new Headers(s.init?.headers).get("Authorization")]),
    [
      ["http://n1:9000/graphql", "Bearer read-secret"],
      ["http://n1:9000/graphql", "Bearer admin-secret"],
    ]
  );

  n1Up = false;
  seen.length = 0;
  const failed = await executeGql({ query: "query Health { health { version } }" });
  assert.equal(failed.ok, false);
  assert.equal((failed as { code: string }).code, PANEL_CODES.unreachable);
  //the cached node was used and not retried elsewhere: a timed-out mutation may have been applied
  assert.deepEqual(seen.map((s) => s.url), ["http://n1:9000/graphql"]);

  seen.length = 0;
  const next = await executeGql({ query: "query Health { health { version } }" });
  assert.equal(next.ok, true);
  assert.deepEqual(seen.map((s) => s.url), [
    "http://n1:9000/graphql",
    "http://n2:9000/graphql",
    "http://n2:9000/graphql",
  ]);
});
