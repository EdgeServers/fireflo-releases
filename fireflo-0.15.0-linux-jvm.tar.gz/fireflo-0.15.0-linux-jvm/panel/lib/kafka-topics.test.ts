import { test } from "node:test";
import assert from "node:assert/strict";
import {
  formatRetention,
  groupByRole,
  lagState,
  lagsByTopic,
  showKafkaPage,
  userHref,
  type KafkaTopic,
} from "./kafka-topics.ts";
import type { Health } from "./health-types.ts";

function topic(name: string, role: string, subject: string | null = null, lag: number | null = 0): KafkaTopic {
  return { name, role, subject, purpose: "", groups: [], usedBy: [], lag };
}

test("sections come in the page's order: router, deliver, vendors, retry, DLQ, webhook, other", () => {
  const sections = groupByRole([
    topic("fireflo.webhook", "webhook"),
    topic("fireflo.retry.1h", "retry", "1h"),
    topic("fireflo.vendor.b", "vendor"),
    topic("fireflo.dlq", "dlq"),
    topic("fireflo.router", "router"),
    topic("fireflo.deliver.n1", "deliver", "n1"),
    topic("fireflo.vendor.a", "vendor"),
    topic("fireflo.x", "something-new"),
  ]);
  assert.deepEqual(
    sections.map((s) => s.label),
    ["Router", "Deliver", "Vendors", "Retry", "DLQ", "Webhook", "Other"]
  );
  assert.deepEqual(sections[2].topics.map((t) => t.name), ["fireflo.vendor.a", "fireflo.vendor.b"]);
  //a role this panel does not know is shown, under Other, rather than dropped
  assert.deepEqual(sections[6].topics.map((t) => t.name), ["fireflo.x"]);
});

test("retry tiers sort shortest first, not by name", () => {
  const [retry] = groupByRole(
    ["1h", "10m", "1s", "2m", "30s", "5s"].map((t) => topic(`fireflo.retry.${t}`, "retry", t))
  );
  assert.deepEqual(retry.topics.map((t) => t.subject), ["1s", "5s", "30s", "2m", "10m", "1h"]);
});

test("empty sections are left out", () => {
  assert.deepEqual(groupByRole([topic("fireflo.router", "router")]).map((s) => s.role), ["router"]);
  assert.deepEqual(groupByRole([]), []);
});

test("retention reads in its largest whole unit", () => {
  assert.equal(formatRetention(604_800_000), "7 d");
  assert.equal(formatRetention(86_400_000), "1 d");
  assert.equal(formatRetention(7_200_000), "2 h");
  assert.equal(formatRetention(90_000), "90 s");
  assert.equal(formatRetention(1_500), "1500 ms");
  assert.equal(formatRetention(-1), "unlimited");
  assert.equal(formatRetention(null), "—");
  assert.equal(formatRetention(undefined), "—");
});

test("a lag is highlighted only when above zero and growing", () => {
  assert.equal(lagState(0, 5), "clear");
  assert.equal(lagState(null, 5), "clear");
  assert.equal(lagState(10, null), "behind");
  assert.equal(lagState(10, 10), "behind");
  assert.equal(lagState(10, 20), "behind");
  assert.equal(lagState(11, 10), "growing");
});

test("lags are kept by topic for the next refresh, unread ones left out", () => {
  const m = lagsByTopic([topic("a", "router", null, 3), topic("b", "dlq", null, null)]);
  assert.deepEqual([...m.entries()], [["a", 3]]);
});

test("listeners and vendors link to their pages; REST callers do not", () => {
  assert.equal(userHref({ kind: "server", name: "cust 1" }), "/cp/servers/cust%201");
  assert.equal(userHref({ kind: "vendor", name: "acme" }), "/cp/vendors/acme");
  assert.equal(userHref({ kind: "rest", name: "REST API" }), null);
});

test("the page is shown on a Kafka gateway that declares the view, and nowhere else", () => {
  const kafka = { api: { kafka_topics_view: true }, backbone: { provider: "kafka", connected: true } } as unknown as Health;
  const memory = { api: { kafka_topics_view: true }, backbone: { provider: "memory", connected: true } } as unknown as Health;
  const older = { api: { kafka_backbone: true }, backbone: { provider: "kafka", connected: true } } as unknown as Health;
  assert.equal(showKafkaPage(kafka), true);
  assert.equal(showKafkaPage(memory), false);
  assert.equal(showKafkaPage(older), false);
  assert.equal(showKafkaPage(null), false);
});
