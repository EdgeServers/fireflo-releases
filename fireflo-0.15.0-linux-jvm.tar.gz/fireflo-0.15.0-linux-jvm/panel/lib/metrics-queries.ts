import {
  CDR_RECEIPT_REACH_MS,
  CDR_WHOLE_DAY_MS,
  cdrEarlier,
  messageRows,
  partOne,
  representativeKeys,
  submitTimeBounds,
} from "@/lib/cdr-grain";
import { cdrQuery, cdrTable } from "@/lib/cdr-tier";
import { query } from "@/lib/metrics-db";
import { serverTrafficSql, type ServerTrafficRange } from "@/lib/server-traffic-sql";
import {
  hasUsageFailureHourly,
  hasUsageHourlyAttempts,
  hasUsageHourlyLogin,
  hasVendorAttempt,
  hourlyWatermark,
} from "@/lib/metrics-schema";
import { failureBreakdownHourlySql, failureWindowStartSql } from "@/lib/failure-breakdown-sql";
import { vendorPerformanceHourlySql } from "@/lib/vendor-performance-sql";
import { billingZone } from "@/lib/platform-currency";
import {
  FAILURE_WINDOW_SINCE,
  OUTCOME_LATERAL,
  accountUsageSql,
  usageHourlySql,
  usageWindowSql,
  type UsageBucket,
  type UsageWindowOptions,
} from "@/lib/usage-summary-sql";
import { HOURLY_MAX_AGE_MS, sourceFor } from "@/lib/usage-source";

export { OUTCOME_LATERAL };
//the figures' shapes and the tile arithmetic live in a database-free module so the home page's
//snapshot can be tested without one; re-exported here so every existing import keeps working
export { totalsOf, type RevenueRow, type Totals, type TrafficBucket } from "@/lib/overview-totals";
import { totalsOf, type RevenueRow, type Totals, type TrafficBucket } from "@/lib/overview-totals";

/**
 * Aggregates over the gateway's call records.
 *
 * <p>Four properties of that schema make the obvious query wrong, and wrong in a way that produces
 * plausible numbers rather than obvious nonsense. They are handled here, once, so no route has to
 * remember them:
 *
 * <ol>
 *   <li><b>Every vendor attempt writes its own submit row</b>, and every one of them joins the
 *       message's receipt. `COUNT(*)` counts attempts, not messages. Which of the two you want
 *       depends on the question -- vendor load is attempts, customer volume is messages -- so the
 *       message figures go through `messageRows` (one row per message, as UsageRollup) and the
 *       vendor ones count every attempt but credit the receipt to the accepted attempt only.
 *       `lib/cdr-grain.ts` has the detail.</li>
 *   <li><b>Money is on one row per message</b> -- `CdrSubmit.carriesMoney` -- and NULL on every
 *       refused attempt, so `price` and `cost` sum correctly over every part-1 row as long as no
 *       join multiplies them.</li>
 *   <li><b>`cdr_final` has no uniqueness constraint.</b> Concurrent receipts for one message append
 *       two rows by design, so a plain join multiplies the row it joins to.</li>
 * </ol>
 *
 * <p>Money is a BIGINT scaled by 10 000 and lives only on part 1; later segments are delivery rows
 * with no amounts. Everything here returns the scaled integer -- dividing is a presentation
 * concern, and doing it in the aggregate would round away money.
 */

export type Range = "1h" | "24h" | "7d" | "30d";

/** Every named range, shortest first: the last hour is what a busy gateway's pages open on. */
const RANGES: Record<Range, { hours: number; bucket: UsageBucket }> = {
  "1h": { hours: 1, bucket: "5min" },
  "24h": { hours: 24, bucket: "hour" },
  "7d": { hours: 24 * 7, bucket: "day" },
  "30d": { hours: 24 * 30, bucket: "day" },
};

export function isRange(value: string | null): value is Range {
  return value === "1h" || value === "24h" || value === "7d" || value === "30d";
}

export function resolveRange(range: Range): {
  since: Date;
  until: Date;
  bucket: UsageBucket;
} {
  const { hours, bucket } = RANGES[range];
  const until = new Date();
  const since = new Date(until.getTime() - hours * 3_600_000);
  return { since, until, bucket };
}

/**
 * The seam options every windowed aggregate shares; `metrics-schema` and `app_config` answer them.
 * The zone comes from `billingZone()`'s 30-second cache, so this costs a round trip only when the
 * cache has lapsed.
 */
async function windowOptions(
  over: Omit<UsageWindowOptions, "vendorAttempt">
): Promise<{ opts: UsageWindowOptions; zone: string }> {
  const [vendorAttempt, zone] = await Promise.all([hasVendorAttempt(), billingZone()]);
  return { opts: { ...over, vendorAttempt }, zone };
}

/**
 * Where a windowed read takes its rolled half from.
 *
 * <p>`live` is {@link usageWindowSql}: finished billing days from `usage_daily`, the rest from the
 * records. `hourly` is {@link usageHourlySql}: UTC hours from `usage_hourly` up to the gateway's
 * watermark, the last minute or two from the records. The caller decides, because only it knows
 * whether the table exists and whether its watermark is moving (`hourlyWatermark()` in
 * `metrics-schema.ts`); naming `usage_hourly` against a gateway without it is a hard error.
 */
export type UsageSource = "live" | "hourly";

/** The two seams, chosen by name. */
function windowSql(source: UsageSource | undefined, opts: UsageWindowOptions): string {
  return source === "hourly" ? usageHourlySql(opts) : usageWindowSql(opts);
}

/**
 * Where a windowed read's call records can start, for routing hot or all (`cdr-tier.ts`): its own
 * `since`, or the start of that billing day when the SQL widens to whole days.
 */
function recordsFrom(since: Date, opts: UsageWindowOptions): Date | null {
  return opts.wholeDays ? cdrEarlier(since, CDR_WHOLE_DAY_MS) : since;
}

/**
 * The hourly summary while the gateway keeps it current, else the daily seam (`usage-source.ts`).
 * What Usage and Revenue read by: on the daily seam a 24-hour window -- no whole billing day in it
 * -- was every message of the day, read from the records, which timed out at production volume.
 */
async function freshHourlySource(): Promise<UsageSource> {
  return sourceFor(await hourlyWatermark(), Date.now(), HOURLY_MAX_AGE_MS);
}

/** The start of the billing day `at` falls in, so a day range covers the same days on either seam. */
async function billingDayStart(at: Date, zone: string): Promise<Date> {
  const rows = await query<{ since: Date }>(
    "SELECT (($1::timestamptz AT TIME ZONE $2)::date::timestamp AT TIME ZONE $2) AS since",
    [at, zone]
  );
  return new Date(rows[0].since);
}

/** An instant for the wire: the bucket's true instant, not the session zone's reading of it. */
const ISO_UTC = `'YYYY-MM-DD"T"HH24:MI:SS"Z"'`;

/**
 * Today in the billing zone, as the database cuts it: the start of the day, the start of
 * `daysBack` days earlier, the start of tomorrow, and the day's `YYYY-MM-DD`.
 *
 * <p>Asked of the database rather than computed here so a caller that re-reads "today" and merges
 * it over buckets it read earlier keys both by the same instant -- the one `usageWindowSql` itself
 * produces for a day bucket. Two implementations of "where does a day start in this zone" is how a
 * half-hour zone or a daylight change ends up with a day counted twice. No table is touched.
 */
export async function billingDays(daysBack = 0): Promise<{
  since: Date;
  todayStart: Date;
  until: Date;
  today: string;
}> {
  const zone = await billingZone();
  const rows = await query<{ since: Date; today_start: Date; until: Date; today: string }>(
    `SELECT ((d.today - $1::int)::timestamp AT TIME ZONE $2) AS since,
            (d.today::timestamp AT TIME ZONE $2)             AS today_start,
            ((d.today + 1)::timestamp AT TIME ZONE $2)       AS until,
            to_char(d.today, 'YYYY-MM-DD')                   AS today
       FROM (SELECT (now() AT TIME ZONE $2)::date AS today) d`,
    [daysBack, zone]
  );
  const r = rows[0];
  return {
    since: new Date(r.since),
    todayStart: new Date(r.today_start),
    until: new Date(r.until),
    today: r.today,
  };
}

/**
 * Messages over time, bucketed by when they were accepted.
 *
 * <p>One row per message, as UsageRollup -- however many vendors it was tried on. Retry pressure is
 * a vendor question and is reported there instead.
 *
 * <p>Day buckets are billing days from `usage_daily`, with today live from the records; the hourly
 * series is live over its 24 hours unless the caller names the `hourly` source
 * (`usage-summary-sql.ts`). A day range starts at the beginning of the billing day `now() - N days`
 * falls in, so its first bar is a whole day and its last is today so far.
 *
 * <p>A caller may narrow the window: the home page's snapshot re-reads only its hot hours, or only
 * today, and keeps the rest from an earlier read. A `since` of its own is taken as given -- not
 * widened to a whole day -- and the bucket keys are the ones the full read would have produced for
 * the same instants, which is what makes the merge a replacement by key.
 *
 * @param o.since start of the window, instead of the range's; `until` likewise
 * @param o.source `hourly` reads rolled hours from `usage_hourly`; the default is the daily seam
 */
export async function trafficOverTime(
  range: Range,
  o: { since?: Date; until?: Date; source?: UsageSource } = {}
): Promise<TrafficBucket[]> {
  const r = resolveRange(range);
  const since = o.since ?? r.since;
  const until = o.until ?? r.until;
  const { opts, zone } = await windowOptions({
    bucket: r.bucket,
    account: false,
    wholeDays: r.bucket === "day" && o.since === undefined,
  });
  const rows = await cdrQuery<Record<string, string>>(
    `${windowSql(o.source, opts)}
     SELECT to_char(bucket AT TIME ZONE 'UTC', ${ISO_UTC}) AS bucket,
            SUM(submitted) AS submitted,
            SUM(delivered) AS delivered,
            SUM(failed)    AS failed,
            SUM(expired)   AS expired,
            SUM(pending)   AS pending
       FROM usage_rows
      GROUP BY usage_rows.bucket
      ORDER BY usage_rows.bucket`,
    [since, until, zone],
    recordsFrom(since, opts)
  );
  return rows.map((r) => ({
    bucket: r.bucket,
    submitted: num(r.submitted),
    delivered: num(r.delivered),
    failed: num(r.failed),
    expired: num(r.expired),
    pending: num(r.pending),
  }));
}

export interface FailureRow {
  finalState: string;
  dlrState: number | null;
  errCode: string | null;
  /** The billing account the failures came from; null when a record named none. */
  account: string | null;
  messages: number;
  /**
   * The newest occurrence of this failure kind in the window, as an ISO instant.
   *
   * <p>What makes a dismissal self-healing. `lib/failure-dismissals.ts` hides a row only while this
   * is older than when the operator dismissed it, so the same failure happening once more brings
   * the row back with nothing to expire and nothing to remember. Dismissing on the count instead
   * would resurrect rows on its own, because the window rolls.
   */
  lastSeen: string;
}

/** The breakdown and the window it is of, which is shorter than the range asked for. */
export interface FailureBreakdown {
  /** Where the live read started, as an ISO instant. */
  since: string;
  rows: FailureRow[];
}

/**
 * Why messages failed.
 *
 * <p>`dlr_state` is kept raw on purpose: EXPIRED, REJECTD and UNDELIV all bill as failures but mean
 * very different things, and collapsing them is exactly what makes a delivery problem hard to
 * diagnose.
 *
 * <p><strong>The whole range from the hourly summary; the last day without it.</strong> With the
 * gateway's `usage_failure_hourly` (V1.98.0, 35 days kept) whole hours come from the summary and
 * only the minutes past its watermark from the records, so 7d and 30d cost what 24h does. Without
 * it (or with a stalled watermark) the records are the only source, and a week or a month of them
 * is the scan to avoid: the window is then cut to `FAILURE_WINDOW_SINCE`, today in the billing
 * zone or the last 24 hours, whichever is longer. Either way the page is told `since`.
 */
export async function failureBreakdown(range: Range): Promise<FailureBreakdown> {
  const { since, until } = resolveRange(range);
  const { opts, zone } = await windowOptions({ bucket: "hour", account: false, wholeDays: false });
  //the summary when the gateway keeps one and its watermark is moving: whole hours from
  //usage_failure_hourly, only the minutes past the watermark from the records -- see
  //failure-breakdown-sql.ts. The read below visits every message in the window, which is what timed
  //out every minute on a gateway with a million records a day
  const seam = (await hasUsageFailureHourly()) ? await hourlyWatermark() : null;
  const [window, rows] = seam !== null && Date.now() - seam.getTime() < VENDOR_SUMMARY_MAX_AGE_MS
    ? await Promise.all([
      query<{ since: Date }>(failureWindowStartSql(), [since, until, seam]),
      //both record reads start at the seam (or since, when later): the hours before it are summary
      cdrQuery<Record<string, string>>(failureBreakdownHourlySql(opts.vendorAttempt), [since, until, seam],
        seam > since ? seam : since),
    ])
    : await Promise.all([
      query<{ since: Date }>(`SELECT ${FAILURE_WINDOW_SINCE} AS since`, [since, until, zone]),
      cdrQuery<Record<string, string>>(
        //max() over a group already being formed, so last_seen costs nothing beyond the aggregate.
        //One row per message, as UsageRollup: otherwise a failed-over message's failure counts twice
        `SELECT o.final_state, o.dlr_state, o.err_code, s.account_id, COUNT(*) AS messages,
                MAX(s.submitted_at) AS last_seen
           FROM ${messageRows(
             `s.submitted_at >= ${FAILURE_WINDOW_SINCE} AND s.submitted_at < $2`,
             opts,
             ["gateway_msg_id", "part_no", "submitted_at", "account_id"]
           )}${OUTCOME_LATERAL}
          WHERE o.final_state IS NOT NULL
            AND o.final_state <> 'DELIVERED'
          GROUP BY 1, 2, 3, 4
          ORDER BY 5 DESC`,
        [since, until, zone],
        //FAILURE_WINDOW_SINCE is today in the billing zone or the last 24 hours, never before since
        //by more than the day's start
        cdrEarlier(since, CDR_WHOLE_DAY_MS)
      ),
    ]);
  return {
    since: new Date(window[0].since).toISOString(),
    rows: rows.map((r) => ({
      finalState: r.final_state,
      dlrState: r.dlr_state === null ? null : num(r.dlr_state),
      errCode: r.err_code ?? null,
      account: r.account_id ?? null,
      messages: num(r.messages),
      //the driver hands back a Date for a timestamptz; an ISO string is what survives JSON either way
      lastSeen: new Date(r.last_seen).toISOString(),
    })),
  };
}

/** A watermark older than this is a stalled rollup: the records are read instead, as mis-overview does. */
const VENDOR_SUMMARY_MAX_AGE_MS = 3 * 3_600_000;

export interface VendorRow {
  vendor: string | null;
  attempts: number;
  messages: number;
  delivered: number;
  failed: number;
  pending: number;
  cost: number;
  deliveryRate: number | null;
}

/**
 * Per-vendor performance.
 *
 * <p>Two different scopes in one row, deliberately. <b>Attempts</b> cover every submit, because a
 * failed-over message really was handed to two vendors and the refusal is real load on the first.
 * <b>Delivery outcome</b> is attributed to the message's representative attempt only — the one
 * carrying money, else the latest, exactly as UsageRollup picks it — which is the attempt the vendor
 * accepted. Attributing one outcome to every vendor that tried would credit a delivery to the vendor
 * that refused it; a refused attempt stays in `attempts` and shows no outcome at all.
 *
 * <p>Only the money row has a cost, so `cost` is exact summed over every attempt -- refused ones add
 * NULL.
 */
export async function vendorPerformance(range: Range): Promise<VendorRow[]> {
  const { since, until } = resolveRange(range);
  const vendorAttempt = await hasVendorAttempt();
  //the summary when the gateway keeps attempts in it and its watermark is moving: whole hours from
  //usage_hourly, only the edges from the records -- see vendor-performance-sql.ts. The query below
  //reads every record in the range, which is what timed out on a few million rows
  const seam = (await hasUsageHourlyAttempts()) ? await hourlyWatermark() : null;
  const rows = seam !== null && Date.now() - seam.getTime() < VENDOR_SUMMARY_MAX_AGE_MS
    ? await cdrQuery<Record<string, string>>(vendorPerformanceHourlySql(vendorAttempt), [since, until, seam], since)
    : await cdrQuery<Record<string, string>>(
    `WITH attempts AS (
        SELECT vendor,
               COUNT(*)                          AS attempts,
               COUNT(DISTINCT gateway_msg_id)    AS messages,
               COALESCE(SUM(cost), 0)            AS cost
          FROM cdr_submit
         WHERE ${partOne("")}
           AND submitted_at >= $1 AND submitted_at < $2
         GROUP BY vendor
     ),
     --outcome credited to the accepted attempt only: the representative row, as UsageRollup picks
     --it. This used to order by retry_count alone, which left attempts sharing a retry_count (an
     --in-worker retry at one vendor) to chance, and could pick a refusal over the money row
     last_attempt AS (
        SELECT DISTINCT ON (gateway_msg_id)
               gateway_msg_id, part_no, vendor, submitted_at
          FROM cdr_submit
         WHERE ${partOne("")}
           AND submitted_at >= $1 AND submitted_at < $2
         ORDER BY gateway_msg_id, ${representativeKeys("", vendorAttempt)}
     ),
     outcomes AS (
        SELECT s.vendor,
               COUNT(*) FILTER (WHERE o.final_state = 'DELIVERED')          AS delivered,
               COUNT(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED','EXPIRED')) AS failed,
               COUNT(*) FILTER (WHERE o.final_state IS NULL)                AS pending
          FROM last_attempt s${OUTCOME_LATERAL}
         GROUP BY s.vendor
     )
     SELECT a.vendor,
            a.attempts, a.messages, a.cost,
            COALESCE(o.delivered, 0) AS delivered,
            COALESCE(o.failed, 0)    AS failed,
            COALESCE(o.pending, 0)   AS pending
       FROM attempts a
       LEFT JOIN outcomes o ON o.vendor IS NOT DISTINCT FROM a.vendor
      ORDER BY a.attempts DESC`,
    [since, until],
    since
  );
  return rows.map((r) => {
    const delivered = num(r.delivered);
    const failed = num(r.failed);
    const settled = delivered + failed;
    return {
      vendor: r.vendor ?? null,
      attempts: num(r.attempts),
      messages: num(r.messages),
      delivered,
      failed,
      pending: num(r.pending),
      cost: num(r.cost),
      //undefined rather than 0 while nothing has settled -- a brand-new vendor has no delivery
      //rate, which is not the same as a delivery rate of nought
      deliveryRate: settled === 0 ? null : delivered / settled,
    };
  });
}

/**
 * Money, by account and product.
 *
 * <p>Revenue, cost and the message count come from one row per message (as UsageRollup) over the
 * live tail and from `usage_daily` for finished days, which give the same money: only the one row
 * per message carries any, and the line is that row summed. The margin is computed from the two
 * sums rather than by summing the stored `margin` column, so it cannot inherit a row-set mistake.
 *
 * <p>`pendingRevenue` is billed traffic with no outcome yet: real in-flight exposure, not an error.
 * The gateway's sweeper closes it as EXPIRED after 48 hours, which is why it is a live-tail figure.
 *
 * <p>Vendor-refused messages are excluded from `messages` on live days -- counting traffic nobody
 * paid for would drag revenue per message down with nothing on screen saying why -- and cannot be
 * on rolled days, where the line's `submitted` includes them: `usage_daily` does not distinguish a
 * refunded message from an unrated one. Their money is excluded either way, as NULL.
 *
 * <p>With `groupByDay` each row is one billing day of one account and product, so a caller can
 * keep the finished days and re-read only today (the home page's snapshot); `since` narrows the
 * window to that instant, taken as given. The `hourly` source serves today's tail from
 * `usage_hourly`, on which `pendingRevenue` reads 0 for the rolled hours: the summary counts what
 * was pending and not its money, so in-flight exposure is then the live minute's alone.
 */
export async function revenueByAccount(
  range: Range,
  o: { since?: Date; until?: Date; groupByDay?: boolean; source?: UsageSource } = {}
): Promise<RevenueRow[]> {
  const r = resolveRange(range);
  const until = o.until ?? r.until;
  //a caller's own source (the overview snapshot) is taken as given; otherwise the hourly summary
  //while it is current -- see freshHourlySource
  const source = o.source ?? (await freshHourlySource());
  //a day range starts at its billing day; the hour and the 24 hours are what they say, or "the
  //last hour" would quietly become "today so far"
  const wholeDays = o.since === undefined && r.bucket === "day";
  const { opts, zone } = await windowOptions({ bucket: "day", account: false, wholeDays, refused: true });
  //the daily seam widens to the billing day itself (wholeDays); the hourly one is handed the day's
  //start, so a 7-day figure covers the same days on either
  const since = o.since ?? (wholeDays && source === "hourly" ? await billingDayStart(r.since, zone) : r.since);
  const byDay = o.groupByDay === true;
  const rows = await cdrQuery<Record<string, string>>(
    `${windowSql(source, opts)}
     SELECT account_id, product,
            ${byDay ? "to_char(day, 'YYYY-MM-DD') AS day," : ""}
            SUM(submitted - refused) AS messages,
            SUM(price)               AS revenue,
            SUM(pending_price)       AS pending_revenue,
            SUM(cost)                AS cost
       FROM usage_rows
      GROUP BY ${byDay ? "1, 2, 3" : "1, 2"}
      ORDER BY revenue DESC`,
    [since, until, zone],
    recordsFrom(since, opts)
  );
  return rows.map((row) => {
    const revenue = num(row.revenue);
    const cost = num(row.cost);
    return {
      accountId: row.account_id ?? null,
      product: row.product ?? null,
      messages: num(row.messages),
      revenue,
      cost,
      margin: revenue - cost,
      pendingRevenue: num(row.pending_revenue),
      ...(byDay ? { day: row.day } : {}),
    };
  });
}

export interface UsageDay {
  /** The bucket, `YYYY-MM-DD` for a day range and an ISO instant for the hourly one. */
  day: string;
  /** `null` for traffic that named no account — real, and not the same as an account called "". */
  accountId: string | null;
  submitted: number;
  delivered: number;
  failed: number;
  pending: number;
  /** Scaled by 10 000, like every other amount here. */
  price: number;
}

/**
 * Traffic and money at day x account, which is the grain the usage page needs and nothing had.
 *
 * <p>{@link trafficOverTime} groups by bucket with no account, and {@link revenueByAccount} groups
 * by account with no day. Composing the two client-side cannot produce this: a per-day series split
 * by account is not derivable from a total per day and a total per account.
 *
 * <p>Both figures come from one pass over the same rows, which is what makes them agree. Doing the
 * counts and the sum as separate queries is how a page ends up reporting more messages than it
 * billed for and no reason why.
 *
 * <p>`price` is summed rather than counted, so an unrated message contributes a row to `submitted`
 * and nothing to the money — NULL sums to nothing on its own and needs no extra clause. Unlike
 * {@link revenueByAccount} this does <em>not</em> exclude vendor-refused messages: this is a usage
 * view, and a message that went on the wire and was refunded is traffic that happened. The money
 * column already excludes it, because a refunded row's price is NULL.
 */
export async function usageByDay(range: Range): Promise<UsageDay[]> {
  const { since, until, bucket } = resolveRange(range);
  return usageBetween(since, until, bucket, null, await freshHourlySource());
}

/**
 * The same figures over an arbitrary window, optionally for one account.
 *
 * <p>Split out because a statement period is not one of the three named ranges — it is a calendar
 * month, or whatever two dates an operator typed. Sharing the query rather than writing a second
 * one is what makes the statement's daily chart agree with the usage page: the two are the same
 * arithmetic over a different window, and two queries would eventually disagree about a retry or a
 * refund and there would be no way to tell which was right.
 *
 * <p>The window is half-open, `[since, until)`, exactly as the statement is -- so a message belongs
 * to one period and never to two. The boundaries are the caller's own: a day at either end that is
 * only partly inside the window is read live, and whole days inside it come from `usage_daily`.
 */
export async function usageBetween(
  since: Date,
  until: Date,
  bucket: UsageBucket,
  accountId?: string | null,
  /** The daily seam unless told otherwise: a statement's calendar days are exact only there. */
  source: UsageSource = "live"
): Promise<UsageDay[]> {
  const account = accountId != null;
  const { opts, zone } = await windowOptions({ bucket, account, wholeDays: false });
  const rows = await cdrQuery<Record<string, string>>(
    //a day bucket is the billing day itself; the hourly one an instant. The account filter is a
    //separate text rather than `$4 IS NULL OR`, so the covering index on (account_id, submitted_at)
    //is usable -- and the id is bound, never concatenated into SQL
    `${windowSql(source, opts)}
     SELECT ${bucket === "day" ? "to_char(day, 'YYYY-MM-DD')" : `to_char(bucket AT TIME ZONE 'UTC', ${ISO_UTC})`} AS day,
            account_id,
            SUM(submitted)        AS submitted,
            SUM(delivered)        AS delivered,
            SUM(failed + expired) AS failed,
            SUM(pending)          AS pending,
            SUM(price)            AS price
       FROM usage_rows
      GROUP BY 1, 2
      ORDER BY 1, 2`,
    account ? [since, until, zone, accountId] : [since, until, zone],
    since
  );
  return rows.map((r) => ({
    day: r.day,
    accountId: r.account_id ?? null,
    submitted: num(r.submitted),
    delivered: num(r.delivered),
    failed: num(r.failed),
    pending: num(r.pending),
    price: num(r.price),
  }));
}

/** {@link totalsOf} over fresh queries, for a caller that has neither. */
export async function totals(range: Range): Promise<Totals> {
  const [traffic, revenue] = await Promise.all([trafficOverTime(range), revenueByAccount(range)]);
  return totalsOf(traffic, revenue);
}

export interface AccountRow {
  accountId: string | null;
  systemId: string | null;
  product: string | null;
  messages: number;
  delivered: number;
  failed: number;
  pending: number;
  billed: number;
  cost: number;
  deliveryRate: number | null;
  lastSeen: string | null;
  /** Spendable credit, or null when the account has no balance row. */
  balance: number | null;
  currency: string | null;
  /** True when the credential is configured but sent nothing in this period. */
  idle: boolean;
}

export interface AccountsView {
  /**
   * Whether prepaid credit appears to be switched on.
   *
   * <p>A heuristic, and worth naming as one: the panel cannot read the gateway's
   * `smsg.balance.enabled`, so it infers from whether any balance rows exist. An enabled gateway
   * that has never been funded looks the same as a disabled one — but both mean "no credit figure
   * to show", which is what the column needs to decide.
   */
  creditEnforced: boolean;
  accounts: AccountRow[];
}

/** A watermark older than this is not a seam to lean on: the rollup has stopped (as `mis-overview`). */
const ACCOUNT_WATERMARK_MAX_AGE_MS = 3 * 3_600_000;

/**
 * Who is using the gateway.
 *
 * <p>Built from the call records rather than the credential table, because credentials may be
 * configured from a file — in which case `app_credential` is empty and would show nothing at all.
 * Configured credentials are merged in on top when the table *is* populated, so a provisioned
 * account that has sent nothing still appears rather than silently going missing.
 *
 * <p><strong>The hour and the 24 hours split by login; the day ranges do not.</strong> `usage_daily`
 * has no `system_id`. `usage_hourly` has one from gateway V1.113.0 (`''` for hours rolled before it,
 * shown as no login), so the 24 hours read from it keeps the split; against an older gateway that
 * read is one row per account and product. The hour, and a 24 hours whose summary has stopped, are
 * read from the records and always keep it. A provisioned credential then counts as seen when its account sent anything in
 * the range. `lastSeen` on a rolled row is its day's start, or its hour's when the hourly summary
 * served it: the line knows that much, not the time.
 *
 * <p>`params` may carry `account`: one account's page asks for its own rows only, rather than the whole
 * deployment's to keep one. Without it, every account, as the Accounts page and the portal read.
 */
export async function accountUsage(range: Range, params?: URLSearchParams): Promise<AccountsView> {
  const { since, until, bucket } = resolveRange(range);
  const account = params?.get("account")?.trim() || null;
  //every range but the hour takes its whole settled hours from usage_hourly while the gateway keeps
  //it current, and reads only the edges from the records: the minutes past the watermark and the
  //sliver before the first whole hour (usageHourlySql). The 24 hours used to be all records -- every
  //message of the day with a receipt probe each, 20 s on .101's load. The hour stays on the records
  const [vendorAttempt, zone, hwm, hourlyLogin] = await Promise.all([
    hasVendorAttempt(),
    billingZone(),
    range === "1h" ? Promise.resolve(null) : hourlyWatermark(),
    hasUsageHourlyLogin(),
  ]);
  const source: UsageSource =
    hwm !== null && Date.now() - hwm.getTime() < ACCOUNT_WATERMARK_MAX_AGE_MS ? "hourly" : "live";
  //the hour and the 24 hours split by login. Read from the records they always can; read from the
  //hourly summary only once it carries the login (usage_hourly.system_id, gateway V1.113.0) -- an
  //older gateway's 24 hours from the summary is one row per account and product. usage_daily has no
  //login, so the day ranges never split
  const logins = bucket !== "day" && (source === "live" || hourlyLogin);
  //a day range covers whole billing days on either path; the hourly one is handed that instant.
  //The 24 hours is taken as it is
  const from =
    source === "hourly" && bucket === "day"
      ? (
          await query<{ since: Date }>(
            "SELECT (($1::timestamptz AT TIME ZONE $2)::date::timestamp AT TIME ZONE $2) AS since",
            [since, zone]
          )
        )[0].since
      : since;

  const [activity, configured, funded] = await Promise.all([
    cdrQuery<Record<string, string>>(
      accountUsageSql({ source, logins, scoped: account !== null, vendorAttempt, hourlyLogin }),
      account !== null ? [from, until, zone, account] : [from, until, zone],
      //the daily path widens a day range to its billing day's start in SQL
      source === "hourly" || bucket !== "day" ? from : cdrEarlier(from, CDR_WHOLE_DAY_MS)
    ),
    configuredCredentials(account),
    accountBalances(),
  ]);

  const rows: AccountRow[] = activity.map((r) => {
    const delivered = num(r.delivered);
    const failed = num(r.failed);
    const settled = delivered + failed;
    const balance = funded.get(r.account_id ?? "");
    return {
      accountId: r.account_id ?? null,
      systemId: r.system_id ?? null,
      product: r.product ?? null,
      messages: num(r.messages),
      delivered,
      failed,
      pending: num(r.pending),
      billed: num(r.billed),
      cost: num(r.cost),
      deliveryRate: settled === 0 ? null : delivered / settled,
      lastSeen: r.last_seen ?? null,
      balance: balance?.balance ?? null,
      currency: balance?.currency ?? null,
      idle: false,
    };
  });

  //a credential that is provisioned but sent nothing in this window is worth seeing, not omitting
  const seenKey = (accountId: string | null, systemId: string | null) =>
    logins ? `${accountId}|${systemId}` : `${accountId}`;
  const seen = new Set(rows.map((r) => seenKey(r.accountId, r.systemId)));
  for (const c of configured) {
    if (seen.has(seenKey(c.accountId, c.systemId))) continue;
    const balance = funded.get(c.accountId ?? "");
    rows.push({
      accountId: c.accountId,
      systemId: c.systemId,
      product: c.product,
      messages: 0,
      delivered: 0,
      failed: 0,
      pending: 0,
      billed: 0,
      cost: 0,
      deliveryRate: null,
      lastSeen: null,
      balance: balance?.balance ?? null,
      currency: balance?.currency ?? null,
      idle: true,
    });
  }

  return { creditEnforced: funded.size > 0, accounts: rows };
}

interface ConfiguredCredential {
  accountId: string | null;
  systemId: string | null;
  product: string | null;
}

/**
 * Credentials configured in the database, if any.
 *
 * <p>Note the column list: `password` and `api_key` are in this table and are never selected.
 * A secret that is not read cannot be leaked by a later change to how this is rendered.
 *
 * <p>Returns empty rather than throwing when the table is absent or unreadable — a gateway using
 * file-based credentials is a normal configuration, not a failure, and the read-only role may
 * legitimately have no grant on it.
 */
async function configuredCredentials(account: string | null = null): Promise<ConfiguredCredential[]> {
  try {
    const rows = await query<Record<string, string>>(
      `SELECT account_id, system_id, product FROM app_credential
        WHERE enabled${account !== null ? " AND account_id = $1" : ""} ORDER BY system_id`,
      account !== null ? [account] : []
    );
    return rows.map((r) => ({
      accountId: r.account_id ?? null,
      systemId: r.system_id ?? null,
      product: r.product ?? null,
    }));
  } catch {
    return [];
  }
}

async function accountBalances(): Promise<Map<string, { balance: number; currency: string | null }>> {
  const map = new Map<string, { balance: number; currency: string | null }>();
  try {
    const rows = await query<Record<string, string>>(
      `SELECT account_id, balance, currency FROM account_balance WHERE enabled`
    );
    for (const r of rows) {
      map.set(r.account_id, { balance: num(r.balance), currency: r.currency ?? null });
    }
  } catch {
    //same reasoning as above: no balance table, or no grant, is not an error worth failing on
  }
  return map;
}

/** Postgres returns BIGINT as a string, so every count and amount arrives as text. */
function num(value: string | null | undefined): number {
  return value == null ? 0 : Number(value);
}

/** The most groups a pre-flight lists. Beyond this it is a platform-wide problem, not a list. */
const UNRATED_GROUP_LIMIT = 50;

/**
 * Recent traffic that carried no price, grouped by who sent it and under what.
 *
 * <p>Answers one question: what would `smsg.rating.unrated.refuse` refuse if it were switched on
 * now. Every row here is a message that flows today and would be refused — `0x418` over SMPP, `403`
 * over REST — from the gateway's next configuration poll onward.
 *
 * <p><strong>`price_rule_id IS NULL`, not `price = 0` and not `price IS NULL`.</strong> The gateway
 * refuses only when no rule matched; a rule deliberately set to zero prices the message at nothing
 * and keeps sending once the flag is on. `price_rule_id` is the only column that records which of
 * those two happened, and getting it wrong would report every free route as about to break.
 *
 * <p>The total is a window function rather than a second query, so the number is the whole picture
 * even when the list is truncated — "50 groups" with a total covering all of them, not a total that
 * silently means "the 50 shown".
 */
export async function unratedTraffic(hours: number): Promise<{
  groups: { accountId: string; product: string; messages: number }[];
  total: number;
}> {
  const grain = { vendorAttempt: await hasVendorAttempt() };
  const rows = await cdrQuery<Record<string, string>>(
    //one row per message, as UsageRollup. Every refused attempt is written UNRATED -- its rating is
    //dropped because it carries no money -- so counting rows reported each failover of a perfectly
    //well-priced message as unrated traffic. The representative row is the money row when there is
    //one, and that has its price_rule_id
    `SELECT COALESCE(s.account_id, '')        AS account_id,
            COALESCE(s.product, '')           AS product,
            count(*)::int                     AS messages,
            (sum(count(*)) OVER ())::bigint   AS total
       FROM ${messageRows("s.submitted_at > now() - ($1 || ' hours')::interval", grain,
                          ["account_id", "product", "price_rule_id"])}
      WHERE s.price_rule_id IS NULL
      GROUP BY 1, 2
      ORDER BY messages DESC, account_id
      LIMIT ${UNRATED_GROUP_LIMIT}`,
    [String(hours)],
    new Date(Date.now() - hours * 3_600_000 - 60_000)
  );

  return {
    groups: rows.map((r) => ({
      accountId: r.account_id,
      product: r.product,
      messages: num(r.messages),
    })),
    total: num(rows[0]?.total),
  };
}

/** How far back the live traffic chart looks, and how wide each of its points is. */
export const LIVE_WINDOW_MS = 15 * 60_000;
export const LIVE_BUCKET_SECONDS = 10;

/** One point of the live chart, for one vendor or account. Counts, not rates. */
export interface LiveTrafficRow {
  /** Bucket start, epoch milliseconds. */
  t: number;
  /** A vendor's full worker name (`smppclient.x`, as `trafficKey`) or an account id; `""` for all. */
  key: string;
  /** `null` when this read did not touch the submits: MT then comes from the gateway's counters. */
  mt: number | null;
  dlr: number;
}

export interface LiveTraffic {
  rows: LiveTrafficRow[];
  /** The window this read covered, so the next read can start where it stopped. */
  since: number;
  until: number;
}

/**
 * Receipts -- and, for one key, submits -- in ten-second buckets, for the live traffic chart.
 *
 * <h2>What is read, and why so little</h2>
 *
 * <p>This used to aggregate fifteen minutes of `cdr_submit` and `cdr_final`, with a LATERAL per
 * receipt, every ten seconds for every open tab (CP-P6: ~1.8M rows a call at the target rate).
 * Two changes:
 *
 * <ul>
 *   <li><b>MT/s no longer comes from here</b> unless a key is given. The gateway counts
 *       `submit_sm` per worker and `/ops/health` carries the counter; the panel polls health
 *       anyway, and a delta of two readings is the rate (`lib/live-rates.ts`). Without a key,
 *       `cdr_submit` is not touched at all and the DLR count needs no join.</li>
 *   <li><b>The window is incremental.</b> The chart passes `since` -- where its last read stopped,
 *       less a bucket or two of overlap for receipts written late -- and only that slice is read.
 *       The full fifteen minutes is read once, when the chart opens or its key changes.</li>
 * </ul>
 *
 * <p>The account dimension exists only in the call records -- health knows workers and a sample of
 * sessions, never which account sent what -- so <b>with a key the submit path stays</b>: both
 * series come from the records, filtered to that key in SQL, over the incremental window. A vendor
 * key goes the same way because a receipt's vendor is only known through its submit.
 *
 * <p>Both count segments, not messages, so they sit on the same scale as the gateway's own TPS:
 *
 * <ul>
 *   <li><b>Vendors, MT</b> is every submit row -- every attempt, every part -- because each one is a
 *       submit_sm the vendor had to take. Load on a vendor is attempts.</li>
 *   <li><b>Accounts, MT</b> is each (message, part) once, however many vendors it was tried on: a
 *       failover is the gateway's retry, not more traffic from the customer.</li>
 *   <li><b>DLR</b> is each (message, part) with a receipt in the bucket, credited to the attempt
 *       that represents the message (`representativeKeys`). `cdr_final` can hold two rows for one
 *       part, hence the DISTINCT. A swept EXPIRED is left out: the gateway writes it with no
 *       `dlr_state` when no receipt came, so counting it would draw receipts that never arrived.</li>
 * </ul>
 *
 * <p>Buckets with nothing in them are absent; the chart fills them with zero.
 *
 * @param since epoch ms; clamped to the window. Absent reads the whole window
 * @param key a vendor's full worker name or an account id; absent reads every receipt unsplit
 */
export async function liveTraffic(
  kind: "vendor" | "server",
  options: { since?: number | null; key?: string | null } = {}
): Promise<LiveTraffic> {
  const until = new Date();
  const floor = until.getTime() - LIVE_WINDOW_MS;
  const since = new Date(
    options.since != null && Number.isFinite(options.since) ? Math.max(floor, Math.min(options.since, until.getTime())) : floor
  );
  const bin = `date_bin(interval '${LIVE_BUCKET_SECONDS} seconds', %s, $1::timestamptz)`;
  const key = options.key?.trim() || null;

  if (key === null) {
    //no join: a receipt's vendor or account is only known through its submit, and without a key
    //nobody asked. One index range on cdr_final(final_at) over the incremental slice
    const rows = await cdrQuery<Record<string, string>>(
      `SELECT (EXTRACT(EPOCH FROM ${bin.replace("%s", "f.final_at")}) * 1000)::bigint AS t,
              COUNT(DISTINCT (f.gateway_msg_id, f.part_no)) AS dlr
         FROM cdr_final f
        WHERE f.final_at >= $1 AND f.final_at < $2 AND f.dlr_state IS NOT NULL
        GROUP BY 1
        ORDER BY 1`,
      [since, until],
      since
    );
    return {
      rows: rows.map((r) => ({ t: num(r.t), key: "", mt: null, dlr: num(r.dlr) })),
      since: since.getTime(),
      until: until.getTime(),
    };
  }

  const vendorAttempt = await hasVendorAttempt();
  const keyCol = kind === "vendor" ? "vendor" : "account_id";
  const mtCount = kind === "vendor" ? "COUNT(*)" : "COUNT(DISTINCT (s.gateway_msg_id, s.part_no))";

  //a receipt in the window can be for a submit up to CDR_RECEIPT_REACH_MS older: the LATERAL looks
  //its submit up in a table routed for that, the rest is the window's own
  const submitsOfReceipts = await cdrTable("submit", cdrEarlier(since, CDR_RECEIPT_REACH_MS));
  const rows = await cdrQuery<Record<string, string>>(
    `WITH mt AS (
       SELECT ${bin.replace("%s", "s.submitted_at")} AS b, ${mtCount} AS n
         FROM cdr_submit s
        WHERE s.submitted_at >= $1 AND s.submitted_at < $2 AND s.${keyCol} = $3
        GROUP BY 1
     ), dlr AS (
       SELECT ${bin.replace("%s", "f.final_at")} AS b, COUNT(DISTINCT (f.gateway_msg_id, f.part_no)) AS n
         FROM cdr_final f
         JOIN LATERAL (
           SELECT s.${keyCol} AS key
             FROM ${submitsOfReceipts} s
            WHERE s.gateway_msg_id = f.gateway_msg_id AND s.part_no = f.part_no
              AND ${submitTimeBounds("s.submitted_at", "f.final_at")}
            ORDER BY ${representativeKeys("s", vendorAttempt)}
            LIMIT 1
         ) s ON TRUE
        WHERE f.final_at >= $1 AND f.final_at < $2 AND f.dlr_state IS NOT NULL AND s.key = $3
        GROUP BY 1
     )
     SELECT (EXTRACT(EPOCH FROM COALESCE(mt.b, dlr.b)) * 1000)::bigint AS t,
            COALESCE(mt.n, 0) AS mt,
            COALESCE(dlr.n, 0) AS dlr
       FROM mt FULL JOIN dlr ON mt.b = dlr.b
      ORDER BY 1`,
    [since, until, key],
    since
  );
  return {
    rows: rows.map((r) => ({ t: num(r.t), key, mt: num(r.mt), dlr: num(r.dlr) })),
    since: since.getTime(),
    until: until.getTime(),
  };
}

export interface ServerTrafficRow {
  accountId: string | null;
  messages: number;
  delivered: number;
  failed: number;
  expired: number;
  pending: number;
}

export interface ServerTraffic {
  /** The window actually read: the last hour or the last 24 hours (see `server-traffic-sql.ts`). */
  range: ServerTrafficRange;
  rows: ServerTrafficRow[];
  totals: { messages: number; delivered: number; reported: number };
}

/**
 * One listener's messages and outcomes over the last hour or day, by account -- the Servers page's
 * Traffic card. A longer range is answered as the 24 hours: no summary holds a listener.
 *
 * @param params `server`: the listener's name, without the `smppserver.` prefix
 */
export async function serverTraffic(range: Range, params?: URLSearchParams): Promise<ServerTraffic> {
  const name = params?.get("server")?.trim() ?? "";
  if (!/^[\w.-]{1,100}$/.test(name)) {
    throw new Error("Which listener? Pass ?server=<name>.");
  }
  const window: ServerTrafficRange = range === "1h" ? "1h" : "24h";
  const { since, until } = resolveRange(window);
  const vendorAttempt = await hasVendorAttempt();
  const rows = await cdrQuery<Record<string, string | null>>(serverTrafficSql(vendorAttempt), [
    since,
    until,
    `smppserver.${name}`,
  ], since);
  return {
    range: window,
    rows: rows.map((r) => ({
      accountId: r.account_id ?? null,
      messages: num(r.messages),
      delivered: num(r.delivered),
      failed: num(r.failed),
      expired: num(r.expired),
      pending: num(r.pending),
    })),
    totals: {
      messages: num(rows[0]?.total_messages),
      delivered: num(rows[0]?.total_delivered),
      reported: num(rows[0]?.total_reported),
    },
  };
}

export interface RevenueBucket {
  /** `YYYY-MM-DD` for a day range; an ISO instant for the hour and the 24 hours. */
  bucket: string;
  messages: number;
  /** Scaled by 10 000, like every other amount here. */
  revenue: number;
  cost: number;
}

/**
 * Revenue and cost over the period in its own steps -- five minutes, hours or billing days -- for
 * the Revenue page's chart. The same seam and the same arithmetic as {@link revenueByAccount}
 * (vendor-refused messages excluded), so the bars add up to the table below them.
 */
export async function revenueSeries(range: Range): Promise<RevenueBucket[]> {
  const r = resolveRange(range);
  const source = await freshHourlySource();
  const wholeDays = r.bucket === "day";
  const { opts, zone } = await windowOptions({ bucket: r.bucket, account: false, wholeDays, refused: true });
  const since = wholeDays && source === "hourly" ? await billingDayStart(r.since, zone) : r.since;
  const rows = await cdrQuery<Record<string, string>>(
    `${windowSql(source, opts)}
     SELECT ${r.bucket === "day" ? "to_char(day, 'YYYY-MM-DD')" : `to_char(bucket AT TIME ZONE 'UTC', ${ISO_UTC})`} AS bucket,
            SUM(submitted - refused) AS messages,
            SUM(price)               AS revenue,
            SUM(cost)                AS cost
       FROM usage_rows
      GROUP BY 1
      ORDER BY 1`,
    [since, r.until, zone],
    recordsFrom(since, opts)
  );
  return rows.map((row) => ({
    bucket: row.bucket,
    messages: num(row.messages),
    revenue: num(row.revenue),
    cost: num(row.cost),
  }));
}
