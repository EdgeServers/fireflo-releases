/**
 * Which gateway node's management port to call, for a 0.14 cluster.
 *
 * <p>`GATEWAY_OPS_URLS` is an optional failover list, `id=url` pairs separated by commas
 * (`gw-1=http://10.0.0.11:9000,gw-2=http://10.0.0.12:9000`), written by
 * `fireflo-panel-install --gateway-ops-urls`. The panel uses the first node, in listed order, that
 * answers a cheap health query within 2 s, keeps that choice for 30 s, and drops it as soon as a
 * call to it finds nothing there, so the next call re-checks from the top and lands on the next
 * node that answers. With no list -- every install before 0.14, and every single-node one -- the
 * answer is `GATEWAY_OPS_URL`, exactly as before.
 *
 * <p>Only the URL changes from node to node. The tokens are the same on every node: in db config
 * mode the gateway keeps smsg.ops.token and smsg.ops.admin.token in app_config, which every node
 * reads, so one `GATEWAY_OPS_TOKEN` / `GATEWAY_OPS_ADMIN_TOKEN` pair serves the whole cluster.
 *
 * <p>Imports nothing from Next, so it runs under plain `node --test`.
 */

export interface OpsNode {
  id: string;
  url: string;
}

/**
 * Parses `id=url,id=url`. Entries that are not `id=url` with an http(s) URL are skipped rather
 * than thrown on: the installer already refuses them, and a hand-edited panel.env with one bad
 * entry should still reach the good ones. A repeated id keeps its first entry.
 */
export function parseOpsUrls(raw: string | undefined): OpsNode[] {
  const nodes: OpsNode[] = [];
  const seen = new Set<string>();
  for (const part of (raw ?? "").split(",")) {
    const entry = part.trim();
    const eq = entry.indexOf("=");
    if (eq <= 0) {
      continue;
    }
    const id = entry.slice(0, eq).trim();
    const url = entry.slice(eq + 1).trim().replace(/\/+$/, "");
    if (!id || !/^https?:\/\/[^/]/.test(url) || seen.has(id)) {
      continue;
    }
    seen.add(id);
    nodes.push({ id, url });
  }
  return nodes;
}

/** Whether a node's management port answers, within the probe's own deadline. */
export type OpsProbe = (url: string) => Promise<boolean>;

export interface OpsUrlResolverOptions {
  nodes: OpsNode[];
  /** `GATEWAY_OPS_URL`, the last resort when no listed node answers. */
  fallback?: string;
  probe: OpsProbe;
  ttlMs?: number;
  now?: () => number;
}

export interface OpsUrlResolver {
  /** The base URL to call, or undefined when there is neither a list nor a fallback. */
  resolve(): Promise<string | undefined>;
  /** Forget the cached choice, after a call to `url` found nothing there. */
  invalidate(url: string): void;
}

export const OPS_URLS_TTL_MS = 30_000;
export const OPS_PROBE_TIMEOUT_MS = 2_000;

export function createOpsUrlResolver({
  nodes,
  fallback,
  probe,
  ttlMs = OPS_URLS_TTL_MS,
  now = Date.now,
}: OpsUrlResolverOptions): OpsUrlResolver {
  const last = fallback?.trim().replace(/\/+$/, "") || undefined;
  let cached: { url: string | undefined; at: number } | null = null;
  //one round of probes at a time: a burst of page requests must not become a burst of probes
  let inFlight: Promise<string | undefined> | null = null;

  async function choose(): Promise<string | undefined> {
    for (const node of nodes) {
      if (await probe(node.url).catch(() => false)) {
        return node.url;
      }
    }
    //nothing answered: the fallback if there is one, else the first node, so the caller's own
    //error names a real address rather than "not configured"
    return last ?? nodes[0]?.url;
  }

  return {
    async resolve() {
      if (nodes.length === 0) {
        return last;
      }
      if (cached && now() - cached.at < ttlMs) {
        return cached.url;
      }
      if (!inFlight) {
        inFlight = choose().then(
          (url) => {
            cached = { url, at: now() };
            inFlight = null;
            return url;
          },
          (err) => {
            inFlight = null;
            throw err;
          }
        );
      }
      return inFlight;
    },
    invalidate(url) {
      if (cached && cached.url === url) {
        cached = null;
      }
    },
  };
}

/**
 * The default probe: `query Health { health { version } }` with the read token, 2 s. Anything but
 * an HTTP 200 counts as not answering -- a node that refuses the token or this panel's address is
 * of no use to it, even though the port is open.
 */
export function healthProbe(token: string | undefined, timeoutMs = OPS_PROBE_TIMEOUT_MS): OpsProbe {
  return async (url) => {
    try {
      const res = await fetch(`${url}/graphql`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token ?? ""}`, "Content-Type": "application/json" },
        body: JSON.stringify({ query: "query Health { health { version } }" }),
        signal: AbortSignal.timeout(timeoutMs),
        cache: "no-store",
      });
      await res.body?.cancel().catch(() => undefined);
      return res.status === 200;
    } catch {
      return false;
    }
  };
}

let shared: { key: string; resolver: OpsUrlResolver } | null = null;

/**
 * The process-wide resolver for the current environment. Rebuilt when any of the three variables
 * it depends on changes, which only tests do.
 */
export function opsUrlResolver(env: NodeJS.ProcessEnv = process.env): OpsUrlResolver {
  const key = [env.GATEWAY_OPS_URLS ?? "", env.GATEWAY_OPS_URL ?? "", env.GATEWAY_OPS_TOKEN ?? ""].join("\n");
  if (!shared || shared.key !== key) {
    shared = {
      key,
      resolver: createOpsUrlResolver({
        nodes: parseOpsUrls(env.GATEWAY_OPS_URLS),
        fallback: env.GATEWAY_OPS_URL,
        probe: healthProbe(env.GATEWAY_OPS_TOKEN?.trim()),
      }),
    };
  }
  return shared.resolver;
}
