import { withStatementTimeout } from "@/lib/metrics-db";
import { StatsCache, StillReadingError, type Cached } from "@/lib/stats-cache";

/**
 * The statement's summary read the way the heavy stats are read (`stats-route.ts`): kept and
 * shared for a minute, one read per period at a time, allowed a minute in the background, and
 * waited for only eight seconds before the page is told to wait and ask again.
 *
 * <p>A month of a large account is millions of records even after the split in `statement-sql.ts`
 * moved most of it onto `usage_daily`, and on the pool's ten seconds a statement that would have
 * finished at twelve never finishes at all. Asking again finds it kept.
 *
 * <p>Its own cache rather than the stats route's: the keys are a different space (account and
 * period, not a metric and a named range), and an evicted Receipts answer should not cost an
 * operator their statement. In memory, per panel process, like that one.
 */
const CACHE = new StatsCache(32);

/** How long a summary may run, in the background past the page's wait. */
export const STATEMENT_HEAVY_MS = 60_000;
/** How long a page waits for a first read before it is told to ask again. */
const WAIT_MS = 8_000;
/** When the page asks again. */
export const STATEMENT_RETRY_AFTER_S = 15;
/**
 * How long an answer is kept. A minute: an operator watching the month in progress sees it move,
 * and a page re-read straight after closing a period re-reads the closed list (never cached) beside
 * a summary that the close itself read fresh.
 */
const TTL_MS = 60_000;

/** The cache key: which statement, for whom. A customer's scope is part of it, never only the id. */
export function statementKey(o: { who: string; accounts: readonly string[]; label: string; since: Date; until: Date }): string {
  return [o.who, [...o.accounts].sort().join(","), o.label, o.since.toISOString(), o.until.toISOString()].join("|");
}

/**
 * The summary for `key`, from the cache or read now under the longer statement limit.
 *
 * @throws StillReadingError when a first read is still going after the wait: answer 202
 */
export function cachedStatement<T>(key: string, read: () => Promise<T>): Promise<Cached<T>> {
  return CACHE.get(key, TTL_MS, () => withStatementTimeout(STATEMENT_HEAVY_MS, read), { waitMs: WAIT_MS });
}

/** Whether `err` is PostgreSQL cancelling a statement for running too long (SQLSTATE 57014). */
export function isStatementTimeout(err: unknown): boolean {
  if (!err || typeof err !== "object") {
    return false;
  }
  const code = (err as { code?: unknown }).code;
  const message = err instanceof Error ? err.message : "";
  return code === "57014" || /statement timeout|canceling statement/i.test(message);
}

/**
 * What a reader of the statement is told when it could not be read: a sentence, never the driver's
 * message. The raw error goes to the log, where whoever runs the panel can find it.
 */
export function statementFailure(err: unknown, what = "read the statement"): string {
  return isStatementTimeout(err)
    ? `Could not ${what}: the database took too long.`
    : `Could not ${what}. The panel's log has the details.`;
}

export { StillReadingError };
