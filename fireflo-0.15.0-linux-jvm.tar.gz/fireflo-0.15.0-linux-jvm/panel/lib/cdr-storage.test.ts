import { strict as assert } from "node:assert";
import { test } from "node:test";

import {
  CDR_ARCHIVE_KEYS,
  archiveSettingChanges,
  archiveSettingsConsequence,
  daySpan,
  describeSchedule,
  duration,
  formFromStorage,
  nextRun,
  normaliseCdrStorage,
  parseSchedule,
  scheduleText,
  settingsReadOnlyReason,
  validateArchiveSettings,
  type ArchiveSettingsForm,
  type CdrStorage,
} from "./cdr-storage.ts";
import { readCdrStorage, type GqlExecutor } from "./cdr-storage-route.ts";
import { CDR_STORAGE, HEALTH } from "./gateway-queries.ts";
import { GATEWAY_SETTING_FIELDS } from "./gateway-setting-fields.ts";

test("the schedule's two shapes, as the gateway's registry check accepts them", () => {
  assert.deepEqual(parseSchedule("daily 01:30"), { cadence: "daily", weekday: "sun", time: "01:30" });
  assert.deepEqual(parseSchedule(" Weekly  SUN 1:05 "), { cadence: "weekly", weekday: "sun", time: "01:05" });
  assert.deepEqual(parseSchedule("weekly wed 23:59"), { cadence: "weekly", weekday: "wed", time: "23:59" });
  for (const bad of ["", "daily", "daily 24:00", "daily 1:60", "weekly 01:30", "weekly sunday 01:30", "hourly 01:30", null]) {
    assert.equal(parseSchedule(bad), null, String(bad));
  }
  assert.equal(scheduleText({ cadence: "weekly", weekday: "sat", time: "02:00" }), "weekly sat 02:00");
  assert.equal(scheduleText({ cadence: "daily", weekday: "sat", time: "02:00" }), "daily 02:00", "the weekday is dropped when daily");
  assert.equal(describeSchedule("weekly sun 01:30"), "Sundays at 01:30 UTC");
  assert.equal(describeSchedule("daily 01:30"), "Daily at 01:30 UTC");
  assert.match(describeSchedule("whenever"), /not a schedule/);
});

test("the next run: later today, tomorrow, or the next chosen weekday, in UTC", () => {
  const wed = new Date("2026-10-28T10:00:00Z"); //a Wednesday
  assert.equal(nextRun({ cadence: "daily", weekday: "sun", time: "12:00" }, wed).toISOString(), "2026-10-28T12:00:00.000Z");
  assert.equal(nextRun({ cadence: "daily", weekday: "sun", time: "01:30" }, wed).toISOString(), "2026-10-29T01:30:00.000Z");
  assert.equal(nextRun({ cadence: "weekly", weekday: "sun", time: "01:30" }, wed).toISOString(), "2026-11-01T01:30:00.000Z");
  assert.equal(nextRun({ cadence: "weekly", weekday: "wed", time: "11:00" }, wed).toISOString(), "2026-10-28T11:00:00.000Z");
  assert.equal(nextRun({ cadence: "weekly", weekday: "wed", time: "09:00" }, wed).toISOString(), "2026-11-04T09:00:00.000Z");
  assert.equal(nextRun({ cadence: "weekly", weekday: "mon", time: "00:00" }, wed).toISOString(), "2026-11-02T00:00:00.000Z");
});

const base: ArchiveSettingsForm = { hotDays: "3", cadence: "daily", weekday: "sun", time: "01:30", enabled: true, export: false };

test("days kept live: a whole number, at least 3, with the reason inline", () => {
  assert.deepEqual(validateArchiveSettings(base), {});
  assert.match(validateArchiveSettings({ ...base, hotDays: "2" }).hotDays ?? "", /At least 3: receipts arrive for two days/);
  assert.match(validateArchiveSettings({ ...base, hotDays: "3.5" }).hotDays ?? "", /whole number/);
  assert.match(validateArchiveSettings({ ...base, hotDays: "" }).hotDays ?? "", /whole number/);
  assert.match(validateArchiveSettings({ ...base, hotDays: "999" }).hotDays ?? "", /At most/);
  assert.match(validateArchiveSettings({ ...base, time: "25:00" }).time ?? "", /HH:MM/);
});

const storage = (over: Partial<CdrStorage> = {}): CdrStorage => ({
  ...normaliseCdrStorage({}),
  tiered: true,
  hotDays: 3,
  schedule: "daily 01:30",
  scheduleValid: true,
  enabled: true,
  export: false,
  exportDir: "/var/lib/fireflo/archive",
  configSource: "db",
  hot: { rowsEstimate: 1000, bytes: 1 << 20, partitions: 11, oldestDay: "2026-10-22", newestDay: "2026-10-28" },
  ...over,
});

test("the form starts from what is in force; an unparseable schedule starts as daily 01:30", () => {
  assert.deepEqual(formFromStorage(storage({ hotDays: 5, schedule: "weekly fri 03:15", export: true })),
    { hotDays: "5", cadence: "weekly", weekday: "fri", time: "03:15", enabled: true, export: true });
  assert.equal(formFromStorage(storage({ schedule: "garbage" })).time, "01:30");
});

test("an unchanged form writes nothing", () => {
  assert.deepEqual(archiveSettingChanges(storage(), base), []);
  //the stored text in another spelling is the same schedule
  assert.deepEqual(archiveSettingChanges(storage({ schedule: "DAILY 1:30" }), base), []);
});

test("each change carries its key, value and what it does", () => {
  const now = new Date("2026-10-28T10:00:00Z");
  //the hot tables hold 2026-10-22..28: seven days. At 3 kept, the next move takes 4
  const lowered = archiveSettingChanges(storage({ hotDays: 5 }), { ...base, hotDays: "3" }, now);
  assert.equal(lowered.length, 1);
  assert.equal(lowered[0].key, CDR_ARCHIVE_KEYS.hotDays);
  assert.equal(lowered[0].value, "3");
  assert.deepEqual([lowered[0].from, lowered[0].to], ["5", "3"]);
  assert.match(lowered[0].note ?? "", /The next move \(2026-10-29 01:30 UTC\) will archive 4 days instead of 2/);
  assert.match(lowered[0].note ?? "", /nothing is deleted/);

  const raised = archiveSettingChanges(storage({ hot: { ...storage().hot, oldestDay: "2026-10-26" } }), { ...base, hotDays: "7" }, now);
  assert.match(raised[0].note ?? "", /will archive nothing/);

  const all = archiveSettingChanges(storage(), { ...base, cadence: "weekly", weekday: "sun", time: "02:00", enabled: false, export: true }, now);
  assert.deepEqual(all.map((c) => [c.key, c.value]), [
    [CDR_ARCHIVE_KEYS.schedule, "weekly sun 02:00"],
    [CDR_ARCHIVE_KEYS.enabled, "false"],
    [CDR_ARCHIVE_KEYS.export, "true"],
  ]);
  assert.deepEqual([all[0].from, all[0].to], ["Daily at 01:30 UTC", "Sundays at 02:00 UTC"]);
  assert.match(all[0].note ?? "", /when moves are switched on/, "moves are being switched off in the same save");
  assert.match(all[1].note ?? "", /No day moves until this is switched back on/);
  assert.match(all[2].note ?? "", /SHA-256 manifest to \/var\/lib\/fireflo\/archive/);

  const scheduled = archiveSettingChanges(storage(), { ...base, cadence: "weekly", weekday: "sun", time: "02:00" }, now);
  assert.match(scheduled[0].note ?? "", /The next move runs at 2026-11-01 02:00 UTC/);
  assert.match(archiveSettingsConsequence(all), /3 call record archive settings/);
  assert.match(archiveSettingsConsequence(scheduled), /one call record archive setting/);
});

test("read-only, with the reason, when the settings are a file or the panel cannot write", () => {
  assert.match(settingsReadOnlyReason({ configSource: "file" }, true) ?? "", /smsg\.properties/);
  assert.match(settingsReadOnlyReason({ configSource: "db" }, false) ?? "", /CONFIG_DATABASE_URL/);
  assert.equal(settingsReadOnlyReason({ configSource: "db" }, true), null);
});

test("the four keys are in the gateway settings catalogue, with the gateway's defaults", () => {
  const byKey = new Map(GATEWAY_SETTING_FIELDS.map((f) => [f.key, f]));
  assert.equal(byKey.get(CDR_ARCHIVE_KEYS.hotDays)?.codedDefault, "3");
  assert.equal(byKey.get(CDR_ARCHIVE_KEYS.schedule)?.codedDefault, "daily 01:30");
  assert.equal(byKey.get(CDR_ARCHIVE_KEYS.enabled)?.codedDefault, "true");
  assert.equal(byKey.get(CDR_ARCHIVE_KEYS.export)?.codedDefault, "false");
  for (const key of Object.values(CDR_ARCHIVE_KEYS)) {
    assert.equal(byKey.get(key)?.section, "archive", key);
  }
});

test("small words: durations, day spans, Long scalars as strings", () => {
  assert.equal(duration(412), "412 ms");
  assert.equal(duration(3_400), "3.4 s");
  assert.equal(duration(125_000), "2 min 5 s");
  assert.equal(duration(null), "—");
  assert.equal(daySpan("2026-10-22", "2026-10-28"), "2026-10-22 → 2026-10-28, 7 days");
  assert.equal(daySpan(null, null), "empty");
  const n = normaliseCdrStorage({ hotDefaultRows: "12", hot: { rowsEstimate: "9007199254740", bytes: "10" }, log: [{ ms: "5", outcome: "moved", table: "cdr_submit" }] });
  assert.equal(n.hotDefaultRows, 12);
  assert.equal(n.hot.rowsEstimate, 9007199254740);
  assert.equal(n.log[0].ms, 5);
  assert.equal(n.configSource, "db");
  assert.deepEqual(n.waiting, []);
});

/** A gateway that answers health with the capabilities given, and cdrStorage with `storage`. */
function gateway(api: Record<string, boolean>, storageAnswer: unknown = { tiered: true, hotDays: 3 }) {
  const calls: { query: string; variables?: Record<string, unknown> }[] = [];
  const exec: GqlExecutor = async <T,>(call: { query: string; variables?: Record<string, unknown> }) => {
    calls.push(call);
    if (call.query === HEALTH) {
      return { ok: true as const, data: { version: "0.15.0", observedAt: "", schemaVersion: "1.112.0", api, snapshot: {} } as T };
    }
    if (call.query === CDR_STORAGE) {
      return { ok: true as const, data: storageAnswer as T };
    }
    return { ok: false as const, status: 500, code: "X", error: "unexpected" };
  };
  return { exec, calls };
}

test("the archives route: an older gateway is told apart, never asked for cdrStorage", async () => {
  const old = gateway({ kafka_topics_view: true });
  const read = await readCdrStorage(old.exec, { configWritable: true });
  assert.deepEqual(read, { ok: true, body: { data: null, unsupported: true, release: "0.15" } });
  assert.equal(old.calls.length, 1, "only health");
});

test("the archives route: a 0.15 gateway's storage, normalised, with the panel's write ability", async () => {
  const g = gateway({ cdr_storage: true }, { tiered: true, hotDays: 4, configSource: "FILE", log: [] });
  const read = await readCdrStorage(g.exec, { first: 5000, failuresOnly: true, configWritable: false });
  assert.ok(read.ok && read.body.data);
  if (read.ok && read.body.data) {
    assert.equal(read.body.data.hotDays, 4);
    assert.equal(read.body.data.configSource, "file");
    assert.equal(read.body.data.configWritable, false);
  }
  assert.deepEqual(g.calls[1].variables, { first: 500, failuresOnly: true }, "the log is capped");
});

test("the archives route: a gateway that cannot be reached is the failure, passed on", async () => {
  const exec: GqlExecutor = async () => ({ ok: false as const, status: 503, code: "UNREACHABLE", error: "no gateway" });
  const read = await readCdrStorage(exec, { configWritable: true });
  assert.deepEqual(read, { ok: false, failure: { ok: false, status: 503, code: "UNREACHABLE", error: "no gateway" } });
});
