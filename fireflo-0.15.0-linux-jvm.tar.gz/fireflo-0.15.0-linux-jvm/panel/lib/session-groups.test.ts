import { strict as assert } from "node:assert";
import { test } from "node:test";
import {
  bindSummary, groupSessions, hostsLabel, overall, receiptRate, UNATTRIBUTED,
} from "./session-groups.ts";
import type { HealthSession } from "./health-types.ts";

function session(over: Partial<HealthSession> = {}): HealthSession {
  return { bound: true, bind_type: "TRANSCEIVER", session_id: 1, ...over };
}

test("sessions fold by account, busiest account first", () => {
  const groups = groupSessions([
    session({ account: "globex", submitted: 10, system_id: "GLX" }),
    session({ account: "acme", submitted: 900, system_id: "ACME_TX", bind_type: "TRANSMITTER" }),
    session({ account: "acme", submitted: 40, system_id: "ACME_TX", bind_type: "TRANSMITTER" }),
    session({ account: "acme", system_id: "ACME_RX", bind_type: "RECEIVER" }),
  ]);
  assert.deepEqual(groups.map((g) => g.account), ["acme", "globex"]);
  const acme = groups[0];
  assert.equal(acme.sessions.length, 3);
  assert.deepEqual(acme.logins, ["ACME_TX", "ACME_RX"]);
  assert.deepEqual(acme.counts, { TX: 2, RX: 1, TRX: 0, unbound: 0 });
  assert.equal(acme.received, 940);
});

test("a session the gateway could not attribute groups under a dash, after every named account", () => {
  const groups = groupSessions([
    session({ account: null, submitted: 5000 }),
    session({ account: "acme", submitted: 1 }),
  ]);
  assert.equal(groups[0].account, UNATTRIBUTED);
  assert.equal(groups[0].received, 5000);
});

test("a group that counts nothing sorts after one that counted zero", () => {
  const groups = groupSessions([
    session({ account: "quiet", submitted: null }),
    session({ account: "idle", submitted: 0 }),
  ]);
  assert.deepEqual(groups.map((g) => g.account), ["idle", "quiet"]);
  assert.equal(groups[0].received, 0);
  assert.equal(groups[1].received, null);
});

test("an unbound session is counted apart from the bind kinds", () => {
  const [group] = groupSessions([
    session({ account: "acme" }),
    session({ account: "acme", bound: false, bind_type: "TRANSCEIVER" }),
  ]);
  assert.deepEqual(group.counts, { TX: 0, RX: 0, TRX: 1, unbound: 1 });
  assert.equal(bindSummary(group.counts), "1 TRX · 1 not bound");
});

test("the bind summary names only the kinds present, in TX RX TRX order", () => {
  assert.equal(bindSummary({ TX: 2, RX: 2, TRX: 0, unbound: 0 }), "2 TX · 2 RX");
  assert.equal(bindSummary({ TX: 0, RX: 0, TRX: 3, unbound: 0 }), "3 TRX");
  assert.equal(bindSummary({ TX: 0, RX: 0, TRX: 0, unbound: 0 }), "");
});

test("hosts, age, tps and the shared limit are folded across the binds", () => {
  const [group] = groupSessions([
    session({ account: "acme", host: "10.0.0.7", bound_seconds: 60, tps_measured: 1.5, tps_limit: 50 }),
    session({ account: "acme", host: "10.0.0.7", bound_seconds: 86_400, tps_measured: 2, tps_limit: 50 }),
    session({ account: "acme", host: "10.0.0.9", bound_seconds: null, tps_measured: null, tps_limit: null }),
  ]);
  assert.deepEqual(group.hosts, ["10.0.0.7", "10.0.0.9"]);
  assert.equal(hostsLabel(group.hosts), "10.0.0.7 +1");
  assert.equal(hostsLabel(["10.0.0.7"]), "10.0.0.7");
  assert.equal(hostsLabel([]), "—");
  assert.equal(group.oldest, 86_400);
  assert.equal(group.tps, 3.5);
  assert.equal(group.tpsLimit, 50);
});

test("binds with different limits give the group no single limit", () => {
  const [group] = groupSessions([
    session({ account: "acme", tps_limit: 50 }),
    session({ account: "acme", tps_limit: 20 }),
  ]);
  assert.equal(group.tpsLimit, null);
});

test("receipts sum like submits, and the rate is receipts over submits", () => {
  const [group] = groupSessions([
    session({ account: "acme", submitted: 100, receipts: 98 }),
    session({ account: "acme", submitted: 100, receipts: 90 }),
  ]);
  assert.equal(group.receipts, 188);
  assert.equal(receiptRate(group), 0.94);
  //an older gateway sends no receipts at all: null, never zero, so the column shows a dash
  const [older] = groupSessions([session({ account: "acme", submitted: 100 })]);
  assert.equal(older.receipts, null);
  assert.equal(receiptRate(older), null);
  assert.equal(receiptRate({ received: 0, receipts: 0 }), null);
});

test("overall folds every group into one row", () => {
  const groups = groupSessions([
    session({ account: "acme", submitted: 100, receipts: 90, bind_type: "TRANSMITTER" }),
    session({ account: "globex", submitted: 50, receipts: 50, bind_type: "RECEIVER" }),
  ]);
  const total = overall(groups);
  assert.equal(total.account, "Overall");
  assert.equal(total.received, 150);
  assert.equal(total.receipts, 140);
  assert.deepEqual(total.counts, { TX: 1, RX: 1, TRX: 0, unbound: 0 });
});
