import { configQuery } from "@/lib/config-db";
import { BILLING_KEY } from "@/lib/billing-key";
import {
  offeredLogins,
  resolveOffered,
  type CredentialRow,
  type PlaygroundLogin,
} from "@/lib/playground-rules";

/**
 * What the playground reads from the database.
 *
 * <p>Server-only: importing this pulls `pg`. The rules it applies are in `lib/playground-rules.ts`,
 * which has no database dependency and is where the tests are — this file is the query and nothing
 * else.
 *
 * <p>Note what is deliberately absent: any read of `password` or `api_key` as a value. The customer
 * types their own password and it reaches the gateway without being compared against, or read from,
 * the column. That keeps the rule the rest of this panel follows — secrets are read as a boolean and
 * never as a value.
 */

export type { PlaygroundLogin };

/** The projection, secret-free, in the shape the rules expect. */
const PROJECTION = `${BILLING_KEY} AS account_id,
        system_id,
        type,
        NULLIF(btrim(COALESCE(product, '')), '') AS product,
        (allowed_ips IS NOT NULL AND array_length(allowed_ips, 1) > 0) AS ip_restricted,
        COALESCE(allowed_products, '{}') AS allowed_products,
        (password IS NOT NULL AND password <> '') AS has_password,
        (COALESCE(api_key, '') <> '') AS key_is_secret`;

interface Row {
  account_id: string | null;
  system_id: string | null;
  type: string;
  product: string | null;
  ip_restricted: boolean;
  allowed_products: string[];
  has_password: boolean;
  key_is_secret: boolean;
}

async function rows(): Promise<CredentialRow[]> {
  const found = await configQuery<Row>(
    `SELECT ${PROJECTION} FROM app_credential WHERE enabled ORDER BY id`
  );
  return found.map((r) => ({
    accountId: r.account_id,
    systemId: r.system_id,
    type: r.type,
    product: r.product,
    ipRestricted: r.ip_restricted,
    allowedProducts: r.allowed_products ?? [],
    hasPassword: r.has_password,
    keyIsSecret: r.key_is_secret,
  }));
}

/** The logins this account may send with here. See `offeredLogins` for what is excluded and why. */
export async function listPlaygroundLogins(accountId: string): Promise<PlaygroundLogin[]> {
  return offeredLogins(await rows(), accountId);
}

/** The named login, or null when it is not one this account may use. */
export async function resolveLogin(
  accountId: string,
  lookupKey: string
): Promise<PlaygroundLogin | null> {
  return resolveOffered(await listPlaygroundLogins(accountId), lookupKey);
}

/**
 * How many attempts an account gets before this stops answering, and over what window.
 *
 * <p>The gateway rate-limits sends and separately refuses a wrong password, but nothing there counts
 * *failed* attempts — so a script could sit on this route trying passwords for a login it is already
 * entitled to name. Cheap to add here, and this is the only place that sees the failures.
 */
const ATTEMPT_WINDOW_MS = 60_000;
const ATTEMPTS_MAX = 30;
const attempts = new Map<string, { count: number; until: number }>();

/**
 * @return false when this account has spent its attempts, in which case the caller must refuse
 *     without calling the gateway at all
 */
export function allowAttempt(accountId: string): boolean {
  const now = Date.now();
  const found = attempts.get(accountId);
  if (!found || now > found.until) {
    //cleared wholesale rather than swept, for the reason require-customer.ts gives about its own
    //map: a bounded map that cannot leak beats an exact one that can
    if (attempts.size > 2_000) {
      attempts.clear();
    }
    attempts.set(accountId, { count: 1, until: now + ATTEMPT_WINDOW_MS });
    return true;
  }
  found.count += 1;
  return found.count <= ATTEMPTS_MAX;
}

/**
 * The gateway's messaging base URL, without a trailing slash.
 *
 * <p>Deliberately a different variable from `GATEWAY_OPS_URL`. That one addresses the management
 * port, which serves `/graphql` and knows nothing about `/secure/send` — pointing this at it produces
 * 404s that look like a broken playground rather than a misconfiguration.
 */
export function gatewayApiUrl(): string | null {
  const raw = (process.env.GATEWAY_API_URL ?? "").trim();
  return raw ? raw.replace(/\/+$/, "") : null;
}
