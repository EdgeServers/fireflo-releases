import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync, statSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * Every mutating control route leaves a line in the operator access log.
 *
 * <h2>Why this test exists</h2>
 *
 * <p>Before `config_changed` the log covered a handful of writes and forty-odd others left nothing
 * behind but an `updated_at`. The fix was to emit from the lib save functions so a route cannot
 * forget -- but a NEW route can still reach the database some other way, and the person adding it
 * is thinking about the feature, not the audit trail. This test is the thing that reminds them.
 *
 * <h2>What it checks, and how little</h2>
 *
 * <p>A regex over the source, nothing cleverer. For each `app/api/control/.../route.ts` that exports
 * a POST, PUT, PATCH or DELETE, the file must either call a logger itself (`auditConfigChange`,
 * `logOperatorEvent`, `auditCodeChange`) or call one of the lib functions listed in {@link AUDITING}
 * -- and each of those is checked, in turn, to actually contain the `auditConfigChange(` call its
 * listing claims. A route that changes nothing stored (a tester, a dry run, a connectivity check)
 * goes in {@link ALLOWED} with the reason, and the test fails if such an entry goes stale.
 *
 * <p>File granularity is deliberate. A file whose PUT audits and whose DELETE does not would pass;
 * the usual way that happens is a new handler calling a new lib function, and the lib-side check
 * catches the function. The trade is a test anyone can read against one that parses TypeScript.
 */

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const ROUTES = path.join(ROOT, "app", "api", "control");

/** Lib functions that call `auditConfigChange` themselves, by file. */
const AUDITING: Record<string, string[]> = {
  "lib/credentials.ts": ["saveCredential", "setCredentialEnabled", "deleteCredential"],
  "lib/routing.ts": ["saveRouteTable", "setRouteRuleEnabled", "deleteRouteTable"],
  "lib/workers.ts": ["saveWorker", "setWorkerEnabled", "setWorkerProperty", "deleteWorker"],
  "lib/balance.ts": ["setBillingMode", "openBalance", "setCreditEnabled", "topUp", "closePeriod"],
  "lib/rates.ts": ["saveScope", "saveScopeForProduct", "setRuleEnabled", "deleteScope", "copyDefaultToAccounts"],
  "lib/filters.ts": ["saveFilter", "deleteFilter"],
  "lib/groups.ts": ["saveRouteGroup", "deleteRouteGroup"],
  "lib/tlv-definitions.ts": ["upsertTlvDefinition", "deleteTlvDefinition", "setTlvSuggested"],
  "lib/products.ts": ["createProduct", "updateProduct", "setProductEnabled", "deleteProduct"],
  "lib/whitelist.ts": ["saveHeader", "saveTemplate", "deleteHeader", "deleteTemplate", "savePolicy"],
  "lib/mis-whitelist.ts": ["reviewHeader", "reviewTemplate", "decideHeaderTlvs", "decideTemplateTlvs"],
  "lib/preprocessors.ts": ["savePreprocessor", "deletePreprocessor"],
  "lib/accounts.ts": ["deleteAccount"],
  "lib/account-archive.ts": ["archiveAccount", "unarchiveAccount", "moveCredential", "moveWhitelistRow"],
  "lib/exports.ts": ["requestExport"],
  //the ban route and the rule runner share this; the audit line is written before sudo is asked
  "lib/fail2ban-ban.ts": ["banAddress"],
};

/** A call that writes the log from the route itself. */
const ROUTE_LOGGERS = ["auditConfigChange(", "logOperatorEvent(", "auditCodeChange("];

/** Mutating routes that change nothing stored, with the reason each is exempt. */
const ALLOWED: Record<string, string> = {
  "accounts/[id]/smpp-test/route.ts": "opens a tester bind against the gateway; nothing stored changes",
  "accounts/[id]/smpp-test/[sid]/route.ts": "closes or reads a tester session",
  "accounts/[id]/smpp-test/[sid]/submit/route.ts": "sends a test message on a tester session: traffic, not configuration -- the CDR records it",
  "delivery-check/route.ts": "POST is the dry run; the apply route is the one that writes, and it logs routing_recreated",
  "preprocessors/check/route.ts": "compiles code without saving it",
  "preprocessors/test/route.ts": "runs code against a sample without saving it",
  "queues/broker/test/route.ts": "connects to the broker to test the form; nothing is stored",
  "workers/[name]/test-bind/route.ts": "dials the vendor once; nothing stored changes",
};

const MUTATING = /^export async function (POST|PUT|PATCH|DELETE)\b/m;

function routeFiles(dir: string): string[] {
  const out: string[] = [];
  for (const entry of readdirSync(dir)) {
    const full = path.join(dir, entry);
    if (statSync(full).isDirectory()) {
      out.push(...routeFiles(full));
    } else if (entry === "route.ts") {
      out.push(full);
    }
  }
  return out.sort();
}

/** The source of one top-level `export async function name(`, up to its closing brace at column 0. */
function functionBody(source: string, name: string): string | null {
  //a generic signature (`requestExport<Row, Filters>(`) is still the function
  const start = source.search(new RegExp(`^export async function ${name}\\b`, "m"));
  if (start < 0) {
    return null;
  }
  const end = source.indexOf("\n}\n", start);
  return end < 0 ? source.slice(start) : source.slice(start, end + 3);
}

test("every lib function listed as auditing really calls auditConfigChange", () => {
  for (const [file, names] of Object.entries(AUDITING)) {
    const source = readFileSync(path.join(ROOT, file), "utf8");
    for (const name of names) {
      const body = functionBody(source, name);
      assert.ok(body, `${file} no longer exports ${name}; update AUDITING in this test`);
      assert.ok(
        body.includes("auditConfigChange("),
        `${file}: ${name} is listed as auditing but does not call auditConfigChange`
      );
    }
  }
});

test("every mutating control route is audited or allow-listed", () => {
  const auditingNames = Object.values(AUDITING).flat();
  const unaudited: string[] = [];
  const stale: string[] = [];
  const seen = new Set<string>();

  for (const file of routeFiles(ROUTES)) {
    const source = readFileSync(file, "utf8");
    if (!MUTATING.test(source)) {
      continue;
    }
    const rel = path.relative(ROUTES, file).split(path.sep).join("/");
    seen.add(rel);
    const logsItself = ROUTE_LOGGERS.some((call) => source.includes(call));
    const callsAuditingLib = auditingNames.some((name) => new RegExp(`\\b${name}\\(`).test(source));
    const audited = logsItself || callsAuditingLib;

    if (rel in ALLOWED) {
      if (audited) {
        stale.push(rel);
      }
      continue;
    }
    if (!audited) {
      unaudited.push(rel);
    }
  }

  assert.deepEqual(
    unaudited,
    [],
    "These routes change something and write no access-log line. Audit from the lib save function "
      + "(add it to AUDITING here), call auditConfigChange in the route, or -- only if nothing stored "
      + "changes -- add the route to ALLOWED with the reason."
  );
  assert.deepEqual(stale, [], "These routes are allow-listed but now audit; drop them from ALLOWED.");
  for (const rel of Object.keys(ALLOWED)) {
    assert.ok(seen.has(rel), `ALLOWED names ${rel}, which is no longer a mutating route; drop it.`);
  }
});
