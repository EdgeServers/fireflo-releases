/**
 * Which `cdr_submit` rows are one message, in one place.
 *
 * <p>Database-free, so anything may import it.
 *
 * <h2>The shape of the table</h2>
 *
 * <p><strong>Every vendor attempt is its own `cdr_submit` row.</strong> Since the gateway's V1.40.0
 * (`feat(cdr): a cdr_submit row for every vendor attempt`) a refusal followed by a failover writes
 * two rows with the same `gateway_msg_id` and `part_no`, differing in `vendor_attempt` and usually
 * `retry_count` and `vendor`. Segments 2..N still write nothing: the one part-1 row per attempt
 * carries `part_count`.
 *
 * <p><strong>Exactly one of those rows carries money</strong> — `CdrSubmit.carriesMoney` is
 * `partNo == 1 && rating != null && billed`, and every other row has NULL `price`/`cost`. A refused
 * attempt has price NULL, usually no `operator_msg_id`, and a non-zero `submit_status`.
 *
 * <p><strong>Receipts carry no attempt.</strong> `cdr_final` and `cdr_interim` are keyed
 * `(gateway_msg_id, part_no)`, so the outcome LATERAL every reader uses attaches the one receipt to
 * EVERY attempt row. Counting rows therefore reported a message that failed over once as two sent
 * and two delivered.
 *
 * <h2>Three questions, three helpers</h2>
 *
 * <ul>
 *   <li><b>How many messages</b> — {@link messageRows}: one row per message, the same
 *       `DISTINCT ON` the gateway's `UsageRollup.ROLLUP_SQL` uses, so a dashboard and the
 *       `usage_daily` line it will become agree.</li>
 *   <li><b>Which attempts did each vendor see</b> — {@link attemptRows}: every attempt, with a
 *       `represents` flag so an outcome can be credited to the accepted attempt only.</li>
 *   <li><b>Show me messages, newest first</b> — {@link isMessageRow}: the same choice as a
 *       correlated predicate, for keyset-paged lists where a `DISTINCT ON` would have to sort the
 *       whole window before returning the first row.</li>
 * </ul>
 *
 * <p><strong>Money needs none of them.</strong> Only one row per message has a price, so summing
 * `price`/`cost` over every part-1 row is already exact — {@link carriesMoney} — as long as nothing
 * joins a second table that multiplies the rows.
 *
 * <h2>Why still no `retry_count = 0`</h2>
 *
 * <p>The money row is the ACCEPTED attempt, which after a failover is not the first one. Filtering
 * on `retry_count = 0` would keep the refused attempt and drop the one that was charged and
 * delivered — from the count and from the money.
 */

/**
 * The representative row's rank keys, best first, without the leading `gateway_msg_id`.
 *
 * <p>MUST match `UsageRollup.ROLLUP_SQL`'s `ORDER BY c.gateway_msg_id, (c.price IS NULL),
 * c.retry_count DESC, c.vendor_attempt DESC`: the row carrying money first, else the latest attempt.
 * `id DESC` is a final tiebreak only — `uq_cdr_submit_part (gateway_msg_id, part_no, retry_count,
 * vendor_attempt)` makes a tie impossible where `vendor_attempt` exists, and where it does not (a
 * gateway before V1.40.0) there are no per-attempt rows to tie, so it never changes the answer the
 * rollup gives — it only makes the choice deterministic.
 *
 * @param vendorAttempt false against a gateway before V1.40.0, which has no such column
 */
export function representativeKeys(alias = "s", vendorAttempt = true): string {
  const a = alias ? `${alias}.` : "";
  return [
    `(${a}price IS NULL)`,
    `${a}retry_count DESC`,
    ...(vendorAttempt ? [`${a}vendor_attempt DESC`] : []),
    `${a}id DESC`,
  ].join(", ");
}

/** Options shared by the helpers below. */
export interface GrainOptions {
  /**
   * Whether `cdr_submit.vendor_attempt` exists — `hasVendorAttempt()` in `metrics-schema.ts`.
   * Naming it against an older gateway is a hard error, not a null.
   */
  vendorAttempt: boolean;
}

/**
 * One row per message, as a FROM item aliased `s`. Same rule as `UsageRollup`.
 *
 * <p>`where` is applied INSIDE the `DISTINCT ON`, exactly as the rollup applies its date range
 * inside: it must use the alias `s`, and it may reference bind parameters, which keep their numbers
 * because they are the same placeholders in the same statement. A message whose attempts straddle
 * the window is represented on each side by its own best row there — the rollup's behaviour too.
 *
 * <p>Takes only `part_no = 1` rows, so a caller's own `part_no = 1` becomes redundant but harmless.
 *
 * <p><strong>Name the columns.</strong> The `DISTINCT ON` sorts every row in the window by
 * `gateway_msg_id`, which no index orders, so the sort is in memory or on disk and its cost is the
 * row width times the row count. `s.*` carries `body`, three TLV columns and forty others through
 * that sort for an aggregate that reads five of them; over a day of traffic that is the difference
 * between a sort that fits in `work_mem` and one that does not. `columns` narrows the projection to
 * what the caller reads -- an outcome LATERAL needs `gateway_msg_id` and `part_no`, and nothing
 * needs `body`. Omitting it keeps `s.*`, for the two readers that render a row rather than count it.
 *
 * @param where SQL over alias `s`, or "" for none
 * @param columns bare `cdr_submit` column names to carry, or nothing for `s.*`
 */
export function messageRows(where: string, opts: GrainOptions, columns?: readonly string[]): string {
  return `(SELECT DISTINCT ON (s.gateway_msg_id) ${projection(columns)}
             FROM cdr_submit s
            WHERE s.part_no = 1${where ? ` AND ${where}` : ""}
            ORDER BY s.gateway_msg_id, ${representativeKeys("s", opts.vendorAttempt)}) s`;
}

/** `s.a, s.b` from a column list, or `s.*` from none. Names are identifiers, never values. */
function projection(columns: readonly string[] | undefined): string {
  if (!columns || columns.length === 0) {
    return "s.*";
  }
  for (const c of columns) {
    if (!/^[a-z_][a-z0-9_]*$/.test(c)) {
      throw new Error(`not a column name: ${c}`);
    }
  }
  return columns.map((c) => `s.${c}`).join(", ");
}

/**
 * The instant a live read of `cdr_submit` may start from, because `usage_daily` covers what is older.
 *
 * <p>The seam between the summary table and the call records, as a bound on `submitted_at` so an
 * index on it (`idx_cdr_submit_account_time_covering`, `idx_cdr_submit_time`) does the work. Without
 * it the per-line anti-join -- `NOT EXISTS (usage_daily line for this account, day and product)` --
 * is exact but has to visit an account's <em>entire</em> lifetime to find the few days it does not
 * cover, with a function of `submitted_at` in the predicate, which no index serves (Audit CP-P2).
 *
 * <p><strong>The rule: local midnight of the day BEFORE the newest rolled-up day.</strong> The
 * rollup (`fireflo usage rollup`, nightly or scheduled in the gateway from 0.12.16) summarises
 * <em>finished</em> days only, from a few days back through yesterday, so every day older than its
 * newest line has had its chance and the purge interlock refuses to delete a day it missed. One day
 * of margin is kept all the same: a line written by a rollup from before 0.12.15 may date from
 * while its day was still open, and a gateway whose records commit late (the buffered CDR writer)
 * can still add to yesterday after a line for it exists. Traffic not in the line must be found in
 * the call records -- the anti-join on the bounded rows decides line by line, exactly as before.
 * Before this instant, a day with no line is trusted to have had no traffic. An account with no
 * line at all reads from the beginning of time, which is correct: nothing of it is summarised.
 *
 * <p>Evaluated once as an InitPlan: `max(day)` is the end of `usage_daily`'s primary key for one
 * account, or of `idx_usage_daily_day` for all.
 *
 * @param zone the bind parameter carrying the billing zone, e.g. `$2`
 * @param account what `u.account_id` must equal: the bind carrying the account id (`$4`), or
 *     `ANY($4)` for a `text[]` of them, or null for the deployment-wide horizon
 */
export function rollupTailFrom(zone: string, account: string | null): string {
  return `(SELECT COALESCE(((max(u.day) - 1)::timestamp AT TIME ZONE ${zone}), '-infinity'::timestamptz)
             FROM usage_daily u${account ? `
            WHERE u.account_id = ${account}` : ""})`;
}

/**
 * Every attempt, as a FROM item aliased `s`, each flagged with whether it is its message's
 * representative row (`s.represents`).
 *
 * <p>For vendor-facing figures: a refused attempt is real traffic for the vendor that refused it,
 * so it is counted — but the message's receipt belongs to the attempt that was accepted, and
 * {@link outcomeForRepresentative} is how a LATERAL says so. `where` is applied inside the window,
 * as in {@link messageRows}, so the representative is chosen among the same rows.
 */
export function attemptRows(where: string, opts: GrainOptions): string {
  return `(SELECT s.*,
                  row_number() OVER (PARTITION BY s.gateway_msg_id
                                     ORDER BY ${representativeKeys("s", opts.vendorAttempt)}) = 1
                    AS represents
             FROM cdr_submit s
            WHERE s.part_no = 1${where ? ` AND ${where}` : ""}) s`;
}

/**
 * Narrows an outcome LATERAL to the representative attempt, so only it is credited a receipt.
 *
 * <p>The LATERALs correlate on `f.gateway_msg_id = s.gateway_msg_id AND f.part_no = s.part_no` (or
 * `i.` for `cdr_interim`); this appends `AND s.represents` to that correlation, so for any other
 * attempt the LATERAL yields no row and the attempt reads as having no receipt — which, for a
 * refusal, is the truth.
 */
export function outcomeForRepresentative(lateral: string): string {
  //any receipt alias -- `f` for cdr_final, `i` for cdr_interim -- correlated to `s` the usual way
  const correlation = /\b(\w+)\.gateway_msg_id = s\.gateway_msg_id AND \1\.part_no = s\.part_no\b/;
  if (!correlation.test(lateral)) {
    //a silent no-op here would credit every attempt again, which is the bug this exists to fix
    throw new Error("outcome LATERAL does not use the expected correlation");
  }
  return lateral.replace(correlation, (m) => `${m} AND s.represents`);
}

/**
 * The same choice as {@link messageRows}, as a predicate on a plain `cdr_submit` alias.
 *
 * <p>For keyset-paged and `LIMIT`ed lists. A `DISTINCT ON` subquery has to read and sort the whole
 * window before the outer `ORDER BY submitted_at DESC LIMIT n` can return anything, which turns a
 * page of fifty into a scan of the range. This keeps the `(submitted_at DESC, id DESC)` index walk
 * and asks, per row, whether a better-ranked part-1 row of the same message exists — a probe of
 * `uq_cdr_submit_part`. The tuple is {@link representativeKeys} with the DESC keys negated, so
 * "smaller" means "better" throughout.
 *
 * <p>One difference from the subquery form: the rival is looked for across the whole table, not
 * only inside the caller's window. A message whose winning row falls outside the window is
 * therefore not listed inside it at all, rather than listed by a lesser attempt.
 */
export function isMessageRow(alias: string, opts: GrainOptions): string {
  const key = (t: string) =>
    [
      `(${t}.price IS NULL)::int`,
      `-${t}.retry_count`,
      ...(opts.vendorAttempt ? [`-${t}.vendor_attempt`] : []),
      `-${t}.id`,
    ].join(", ");
  return `(${alias}.part_no = 1 AND NOT EXISTS (
             SELECT 1 FROM cdr_submit rival
              WHERE rival.gateway_msg_id = ${alias}.gateway_msg_id
                AND rival.part_no = 1
                AND (${key("rival")}) < (${key(alias)})))`;
}

/**
 * Every attempt at a message's first part — NOT one row per message.
 *
 * <p>Right for per-attempt vendor traffic, and for money (see {@link carriesMoney}). Wrong for any
 * count that claims to be of messages; use {@link messageRows} for that.
 */
export function partOne(alias = "s"): string {
  return `${alias ? `${alias}.` : ""}part_no = 1`;
}

/**
 * The rows that may carry money.
 *
 * <p>Deliberately the same predicate as {@link partOne}: `CdrSubmit.carriesMoney` is
 * `partNo == 1 && rating != null && billed`, with no retry term, and every row that does not carry
 * money — a later segment, a refused attempt, a refunded message — has NULL price columns, so
 * summing them adds nothing. Exact without deduplication, provided no join multiplies the rows.
 */
export function carriesMoney(alias = "s"): string {
  return partOne(alias);
}

/*
 * ------------------------------------------------------------------------------------------------
 * Hot and archive (gateway 0.15, V1.112.0)
 * ------------------------------------------------------------------------------------------------
 */

/**
 * The five call record tables. From V1.112.0 each is a day-partitioned hot table holding the last
 * few days, a `<t>_archive` holding every older day, and a `<t>_all` view that is both.
 */
export const CDR_TABLES = ["cdr_submit", "cdr_final", "cdr_interim", "cdr_event", "cdr_rejected"] as const;

/** `submit` for `cdr_submit`, and so on. */
export type CdrKind = "submit" | "final" | "interim" | "event" | "rejected";

/**
 * Where the hot tables begin, as `cdr-tier.ts` read it from `cdr_tier`.
 *
 * <ul>
 *   <li>`null` -- no tiers: a database from before V1.112.0, where the one set of tables holds
 *       everything and every reader reads it as it always did;</li>
 *   <li>a Date -- `max(hot_from, moving_to)`: at and after it every hot table holds every row. The
 *       mover publishes `moving_to` before it moves, so a boundary read a minute ago is never later
 *       than the one in force;</li>
 *   <li>{@link CDR_EVERYTHING} -- tiers exist but cannot be read (no row, no grant): every reader
 *       reads the `_all` views, which is slow and never wrong.</li>
 * </ul>
 */
export type CdrBoundary = Date | null;

/** A boundary no window starts after: every read goes to the `_all` views. */
export const CDR_EVERYTHING: Date = new Date(8.64e15);

/**
 * How far before a window's start the hot tables must reach for it to be read there -- the
 * gateway's `CdrTables.MARGIN`. A receipt or a retry keyed to a message can carry a time a little
 * before the message's own, from a clock on another node.
 */
export const CDR_TIER_MARGIN_MS = 3_600_000;

/**
 * How long after its submit a message's receipt can still be written, in days: the gateway keeps a
 * message's receipt correlation for `smsg.dlr.retention.days` (7 by default), and a real receipt
 * arriving after the expiry sweep's EXPIRED (at `smsg.cdr.deadline.hours`, 24) still outranks it --
 * so the bound is the correlation's life, not the deadline, with a day of room. Nothing writes a
 * `cdr_final` or `cdr_interim` row for a message later than that.
 */
export const CDR_RECEIPT_REACH_DAYS = 8;

/** {@link CDR_RECEIPT_REACH_DAYS} in milliseconds, for routing ({@link cdrEarlier}). */
export const CDR_RECEIPT_REACH_MS = CDR_RECEIPT_REACH_DAYS * 86_400_000;

/**
 * The bounds a receipt lookup puts on the receipt's own time, relative to its message's submit:
 * never more than a day before it (the gateway's rule, `UsageRollup`: an outcome follows the
 * message's first attempt, and every attempt is within the retry budget), never more than
 * {@link CDR_RECEIPT_REACH_DAYS} after it, and never more than an hour in the future (another
 * node's clock; the same hour of margin as {@link CDR_TIER_MARGIN_MS}).
 *
 * <p>They change no answer -- no receipt lies outside them -- and they are what lets PostgreSQL
 * skip partitions in a per-message LATERAL: the submit's bounds at each rescan cut the day
 * partitions of the hot table and the archive to the few the receipt can be in, and `now()` (a
 * stable value, pruned once at start) cuts the empty days the gateway creates ahead. Without them
 * every probe visited every partition: eleven per message on a fresh 0.15 install.
 *
 * @param col the receipt's time, e.g. `f.final_at` or `i.received_at`
 * @param submitted the message's submit time, e.g. `s.submitted_at`
 */
export function receiptTimeBounds(col: string, submitted = "s.submitted_at"): string {
  return `${col} >= ${submitted} - interval '1 day'
       AND ${col} < ${submitted} + interval '${CDR_RECEIPT_REACH_DAYS} days'
       AND ${col} < now() + interval '1 hour'`;
}

/**
 * The same bounds seen from the receipt: the submits a receipt at `received` can belong to. For a
 * reader that starts from receipts and looks their messages up.
 */
export function submitTimeBounds(col: string, received: string): string {
  return `${col} > ${received} - interval '${CDR_RECEIPT_REACH_DAYS} days'
       AND ${col} <= ${received} + interval '1 day'`;
}

/**
 * The start of a window `ms` earlier than `since`, or null (everything) for an unbounded one.
 * For a reader whose SQL widens its own start -- a day range taken back to its billing day's
 * midnight -- or that looks up older rows from newer ones.
 */
export function cdrEarlier(since: CdrSince, ms: number): Date | null {
  const at = sinceMillis(since);
  return at === null ? null : new Date(at - ms);
}

/** A billing day's start can be up to a day and a zone offset before the instant it was taken from. */
export const CDR_WHOLE_DAY_MS = 27 * 3_600_000;

/** A window's start: a Date, an ISO string, or null for "from the beginning of time". */
export type CdrSince = Date | string | null | undefined;

function sinceMillis(since: CdrSince): number | null {
  if (since == null || since === "") {
    return null;
  }
  const ms = since instanceof Date ? since.getTime() : Date.parse(since);
  return Number.isFinite(ms) ? ms : null;
}

/**
 * Whether a window starting at `since` finds every row it needs in the hot tables. Always true
 * without tiers; never true for an unbounded window (or one whose start does not parse) with them.
 */
export function cdrWindowIsHot(since: CdrSince, boundary: CdrBoundary): boolean {
  if (boundary === null) {
    return true;
  }
  const ms = sinceMillis(since);
  return ms !== null && ms - CDR_TIER_MARGIN_MS >= boundary.getTime();
}

/** `cdr_submit` or `cdr_submit_all`, for a window starting at `since`. */
export function cdrTableFor(kind: CdrKind, since: CdrSince, boundary: CdrBoundary): string {
  const table = `cdr_${kind}`;
  return cdrWindowIsHot(since, boundary) ? table : `${table}_all`;
}

/**
 * A call record table as a statement READS it: the bare name, not a longer identifier that starts
 * with it or ends in it (`cdr_submit_archive`, `idx_cdr_submit_time`, `old_cdr_submit`) -- the word boundaries
 * and the look-arounds see to that. The panel never writes these tables, so no write target needs
 * excluding (the gateway's `CdrTables.READ_NAME` has to).
 */
const READ_NAME = /(?<![\w])cdr_(submit|final|interim|event|rejected)(?![\w])/g;

/**
 * The mark {@link cdrRouteSql} puts on a statement it has routed. `metrics-db.ts` reads a statement
 * that names a call record table WITHOUT it through the `_all` views: a reader nobody routed is
 * slower than it needs to be, never wrong.
 */
export const CDR_ROUTED = "/* cdr:routed */";

/**
 * `sql` with every call record table it reads replaced by its `_all` view. String literals are left
 * alone, so `information_schema` probes naming `'cdr_submit'` still ask about the table.
 */
export function cdrAllSql(sql: string): string {
  return sql
    .split(/('(?:[^']|'')*')/)
    .map((part, i) => (i % 2 === 1 ? part : part.replace(READ_NAME, "cdr_$1_all")))
    .join("");
}

/** Whether `sql` reads a call record table by its bare name (outside string literals). */
export function cdrNamesTable(sql: string): boolean {
  return sql.split(/('(?:[^']|'')*')/).some((part, i) => i % 2 === 0 && new RegExp(READ_NAME.source).test(part));
}

/**
 * `sql` as written when its window, starting at `since`, is inside the hot tables; otherwise with
 * every call record table it names read through the `_all` view. Unchanged without tiers.
 *
 * <p>The views are plain `UNION ALL`s with bare columns, so a predicate on the time column prunes
 * both sides and an `ORDER BY submitted_at DESC LIMIT n` still walks the two indexes in a merge.
 */
export function cdrRouteSql(sql: string, since: CdrSince, boundary: CdrBoundary): string {
  return `${CDR_ROUTED} ${cdrWindowIsHot(since, boundary) ? sql : cdrAllSql(sql)}`;
}

/**
 * A statement no reader routed: as written without tiers, through the `_all` views with them. What
 * `metrics-db.ts` applies to every statement that names a call record table and lacks
 * {@link CDR_ROUTED}, so a reader that forgot its window still sees the archive.
 */
export function cdrRouteUnmarked(sql: string, boundary: CdrBoundary): string {
  if (boundary === null || sql.includes(CDR_ROUTED) || !cdrNamesTable(sql)) {
    return sql;
  }
  return cdrAllSql(sql);
}

/**
 * Reads `max(hot_from, moving_to)` from `cdr_tier` with the query runner given: null when there is
 * no such table (a gateway before 0.15), {@link CDR_EVERYTHING} when it has no row or cannot be read.
 * Database-free itself; `metrics-db.ts` caches it.
 */
export async function readCdrBoundary(
  run: (sql: string) => Promise<Record<string, unknown>[]>
): Promise<{ boundary: CdrBoundary; error: string | null }> {
  const [exists] = await run("SELECT to_regclass('cdr_tier') IS NOT NULL AS ok");
  if (!exists?.ok) {
    return { boundary: null, error: null };
  }
  try {
    const [row] = await run("SELECT hot_from, moving_to FROM cdr_tier WHERE one");
    if (!row?.hot_from) {
      return { boundary: CDR_EVERYTHING, error: "cdr_tier has no row" };
    }
    const hot = new Date(row.hot_from as string | Date);
    const moving = row.moving_to ? new Date(row.moving_to as string | Date) : null;
    return { boundary: moving && moving.getTime() > hot.getTime() ? moving : hot, error: null };
  } catch (e) {
    return { boundary: CDR_EVERYTHING, error: e instanceof Error ? e.message : String(e) };
  }
}

/**
 * The instant a message id was made at, or null for one that does not carry it.
 *
 * <p>Message ids are UUID version 7 (the gateway's `MessageIds`, which `dlr_message.created_day`
 * relies on too): the first 48 bits are Unix milliseconds. A segment id is made with its message,
 * so the same holds for it. An id from before 0.12.25, or anything typed that is not one, has no
 * time, and its lookup reads everything.
 */
export function messageIdTime(id: string | null | undefined): Date | null {
  const s = (id ?? "").trim();
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(s)) {
    return null;
  }
  const ms = parseInt(s.slice(0, 8) + s.slice(9, 13), 16);
  return Number.isFinite(ms) ? new Date(ms) : null;
}
