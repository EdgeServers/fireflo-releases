import { type BanDecision, type RefusalSummaryRow, decisionSentence, evaluateRules } from "@/lib/ban-rules";
import { type BanRunEntry, appendBanRuns, readBanRuns, readBanRules } from "@/lib/ban-rules-db";
import { banAddress, ignoreListed } from "@/lib/fail2ban-ban";
import { gqlData } from "@/lib/gateway-graphql-core";
import { REFUSAL_SUMMARY } from "@/lib/gateway-queries";
import { liveBans } from "@/lib/security-sources";

/**
 * The minute timer that runs the ban rules.
 *
 * <p>Once per process, started from `instrumentation.ts`. Held on `globalThis` rather than in a
 * module variable (the pattern `lib/overview-refresher.ts` uses) because `next dev` re-evaluates
 * modules on every edit, and a timer per evaluation would be several runs a minute, each one able
 * to ban. The timer is unref'd so it never keeps a stopping process alive.
 *
 * <h2>Defensive on purpose</h2>
 *
 * <p>Nothing in a tick may throw out of it: a gateway that is down, a rules file that will not
 * parse, a sudo rule that is missing -- each is logged, at most once a minute so a dead gateway is
 * one line per tick rather than a page, and the next tick tries again. A tick that is still
 * running when the next is due is left alone; the next tick runs when the timer fires again.
 *
 * <p>The cheap exit is first: with no enabled rule nothing is fetched, so a panel with the
 * feature unused never talks to the gateway from here and never logs that it could not.
 */

export const TICK_MS = 60_000;

interface Slot {
  timer: NodeJS.Timeout | null;
  running: boolean;
  lastErrorAt: number;
  hooks: boolean;
}

const slot = globalThis as { __firefloBanRules?: Slot };

function state(): Slot {
  return (slot.__firefloBanRules ??= { timer: null, running: false, lastErrorAt: 0, hooks: false });
}

export function startBanRulesRunner(): void {
  const s = state();
  if (s.timer) {
    return;
  }
  s.timer = setInterval(() => void tick(), TICK_MS);
  s.timer.unref();
  if (!s.hooks) {
    s.hooks = true;
    process.once("SIGTERM", stopBanRulesRunner);
    process.once("beforeExit", stopBanRulesRunner);
  }
}

export function stopBanRulesRunner(): void {
  const s = state();
  if (s.timer) {
    clearInterval(s.timer);
    s.timer = null;
  }
}

async function tick(): Promise<void> {
  const s = state();
  if (s.running) {
    return;
  }
  s.running = true;
  try {
    await runBanRulesOnce();
  } catch (err) {
    const now = Date.now();
    if (now - s.lastErrorAt >= TICK_MS) {
      s.lastErrorAt = now;
      console.error("ban rules: a run failed, will try again next minute", err);
    }
  } finally {
    s.running = false;
  }
}

export interface RunSummary {
  /** How many enabled rules ran. Zero means nothing was fetched. */
  rules: number;
  decisions: BanDecision[];
  entries: BanRunEntry[];
}

/**
 * One evaluation of every enabled rule, with the bans it decided on, recorded.
 *
 * <p>Exported so a "run now" can share it with the timer. Throws only for the faults a tick should
 * log -- the gateway refusing the ledger, the rules file unreadable; a failed ban is an entry in
 * the run log, not an exception, since the other decisions in the same run still stand.
 */
export async function runBanRulesOnce(now = new Date()): Promise<RunSummary> {
  const rules = (await readBanRules()).filter((r) => r.enabled);
  if (rules.length === 0) {
    return { rules: 0, decisions: [], entries: [] };
  }

  const rowsByWindow = new Map<number, RefusalSummaryRow[]>();
  for (const windowMinutes of new Set(rules.map((r) => r.windowMinutes))) {
    //the read token: the ledger is a read, and the runner holds no operator's session
    const rows = await gqlData<RefusalSummaryRow[]>({
      query: REFUSAL_SUMMARY,
      variables: { windowMinutes },
      timeoutMs: 15_000,
    });
    rowsByWindow.set(windowMinutes, rows ?? []);
  }

  const decisions = evaluateRules(rules, rowsByWindow);
  if (decisions.length === 0) {
    return { rules: rules.length, decisions, entries: [] };
  }

  //what fail2ban is already blocking: a ban already in force is not re-asked for, and is not a
  //run-log line either, or the log would repeat every address every minute for an hour
  const banned = new Set<string>();
  if (decisions.some((d) => !d.dryRun)) {
    for (const b of (await liveBans()).blocked) {
      banned.add(`${b.jail} ${b.ip}`);
    }
  }

  //a dry run decides the same thing every minute for as long as the address stays in the window;
  //one line per address per window is the record, not sixty
  const lastSeen = new Map<string, number>();
  if (decisions.some((d) => d.dryRun)) {
    for (const e of await readBanRuns()) {
      const key = `${e.rule} ${e.ip}`;
      const t = Date.parse(e.at);
      if (Number.isFinite(t) && !lastSeen.has(key)) {
        lastSeen.set(key, t);
      }
    }
  }

  const entries: BanRunEntry[] = [];
  const at = now.toISOString();
  for (const d of decisions) {
    const base = { at, rule: d.ruleId, ip: d.ip, jail: d.jail, dryRun: d.dryRun, reason: decisionSentence(d) };
    if (d.dryRun) {
      const seen = lastSeen.get(`${d.ruleId} ${d.ip}`);
      if (seen === undefined || now.getTime() - seen >= d.windowMinutes * 60_000) {
        entries.push({ ...base, banned: false, error: null });
      }
      continue;
    }
    if (banned.has(`${d.jail} ${d.ip}`)) {
      continue;
    }
    const ignore = await ignoreListed(d.ip);
    if (ignore.ignored) {
      entries.push({ ...base, banned: false, error: "On the never-ban list (fail2ban-ignore.conf); not banned." });
      continue;
    }
    const result = await banAddress({
      jail: d.jail,
      ip: d.ip,
      seconds: d.banSeconds,
      actor: null,
      source: `rule:${d.ruleId}`,
    });
    entries.push(
      result.ok
        ? { ...base, banned: true, error: result.note }
        : { ...base, banned: false, error: result.error }
    );
  }

  await appendBanRuns(entries);
  return { rules: rules.length, decisions, entries };
}
