import {
  sumRevenueByAccount,
  totalsOf,
  type RevenueRow,
  type Totals,
  type TrafficBucket,
} from "./overview-totals.ts";

/**
 * The home page, built in the background and served from memory.
 *
 * <p>Every open `/cp` tab used to poll `/api/control/overview` once a minute, and every poll ran
 * three scans of the call records -- the traffic series, the revenue tail, the failure breakdown --
 * plus three reads of `app_config`. Three tabs were three times the work, and the 24-hour series was
 * a whole day of records each time because the only summary the gateway kept was daily.
 *
 * <p>This module keeps one snapshot per range, refreshed on a timer whatever the number of tabs, and
 * answers a request from memory with the instant it was built. The work per tick is small by
 * construction:
 *
 * <ul>
 *   <li><b>Progressive.</b> A full build happens every {@link RefresherConfig.fullRebuildMs} (15
 *       minutes). Between full builds a tick re-reads only what moves: for the 24-hour series the
 *       <em>hot window</em> -- the last {@link RefresherConfig.hotHours} whole hours and the current
 *       one -- and for the day ranges today alone. Older buckets are kept from the last full build
 *       and replaced by key. Revenue likewise: the finished days' rows are kept and today's are
 *       re-read, then summed per account and product.</li>
 *   <li><b>Shared.</b> The failure breakdown follows the range like everything else, read per range
 *       every {@link RefresherConfig.failuresMs} (5 minutes): from the hourly failure summary when
 *       the gateway keeps one, which holds 35 days. Today's tail is the same read for 7d and 30d,
 *       and today's revenue the same for all three, so each is read once per tick.</li>
 *   <li><b>Vendors too.</b> The dashboard's sent-by-vendor ring is a section of the snapshot rather
 *       than a route each open tab polled, read per range on every tick: the hourly summary for
 *       whole hours and an index range of records past its watermark, a few milliseconds.</li>
 *   <li><b>Cheap at the source where it can be.</b> A gateway with the hourly summary
 *       (`usage_hourly`, V1.91.0) serves whole hours from it and only the last minute or two from
 *       the records, through `usageHourlySql`. Then the 24-hour series is re-read whole every tick --
 *       24 small rows -- so the gateway's own restatements reach the page within a minute. The seam
 *       is used only while its watermark is moving; a stale watermark (the rollup switched off) puts
 *       the range back on the live, progressive path.</li>
 * </ul>
 *
 * <p>A failed read keeps the previous section, marks it `stale`, and is logged once per tick; the
 * snapshot's `asOf` still advances, because the page is told what the panel last tried rather than
 * what it last managed. Day ranges rebuild whole when the billing day turns, so yesterday's bucket
 * becomes a finished day rather than a frozen reading of 23:59.
 *
 * <p><strong>Database-free, by injection.</strong> Every read is a function in {@link SnapshotDeps}
 * and the clock is one too, so the merge, the cadence and the failure handling are tested without a
 * database (`overview-snapshot.test.ts`). `overview-refresher.ts` wires the real queries and holds
 * the one instance per process.
 */

export type Range = "1h" | "24h" | "7d" | "30d";
export type UsageSource = "live" | "hourly";

export interface FailureRowLike {
  finalState: string;
  dlrState: number | null;
  errCode: string | null;
  /** The billing account, when the breakdown is per account (the dashboard's failures ring). */
  account?: string | null;
  messages: number;
  lastSeen: string;
}

/** One vendor's share of the range, as `vendorPerformance` returns it. */
export interface VendorRowLike {
  vendor: string | null;
  attempts: number;
  messages: number;
  delivered: number;
  failed: number;
  pending: number;
  cost: number;
  deliveryRate: number | null;
}

export interface SnapshotDeps {
  /** `trafficOverTime` with a window of the caller's. */
  traffic(range: Range, o: { since?: Date; until?: Date; source: UsageSource }): Promise<TrafficBucket[]>;
  /** `revenueByAccount` by day, with a window of the caller's. */
  revenue(
    range: Range,
    o: { since?: Date; until?: Date; groupByDay: true; source: UsageSource }
  ): Promise<RevenueRow[]>;
  /** `failureBreakdown` over the range: the whole range from the hourly summary, else the last day. */
  failures(range: Range): Promise<{ since: string; rows: FailureRowLike[] }>;
  /** `vendorPerformance` over the range. */
  vendors(range: Range): Promise<VendorRowLike[]>;
  hasUsageHourly(): Promise<boolean>;
  hourlyWatermark(): Promise<Date | null>;
  /** Where today starts in the billing zone, and its `YYYY-MM-DD`. */
  billingDays(): Promise<{ todayStart: Date; today: string }>;
  /** `smsg.cdr.deadline.hours`: how long a message may stay without a receipt. */
  deadlineHours(): Promise<number>;
  now(): Date;
  log(line: string): void;
}

export interface RefresherConfig {
  /** Seconds between ticks. `0` builds on every request and keeps nothing (the e2e rig). */
  refreshSeconds: number;
  /** Every section re-read whole this often. Default 15 minutes. */
  fullRebuildMs?: number;
  /** The failure breakdown's own cadence. Default 5 minutes. */
  failuresMs?: number;
  /** How long a first request waits for its build before answering "warming up". Default 8 s. */
  warmupMs?: number;
  /** Whole hours before the current one that a live tick re-reads. Default 3. */
  hotHours?: number;
  /** A watermark older than this is not a seam to lean on. Default 3 hours. */
  watermarkMaxAgeMs?: number;
  /** Whether to start the timer on first use. Tests pass false and call `tick()` themselves. */
  schedule?: boolean;
}

export interface RangeSnapshot {
  /** When the last full build of this range finished. */
  builtAt: string;
  /** When the panel last read the database for this range, successfully or not. */
  asOf: string;
  traffic: TrafficBucket[];
  revenue: RevenueRow[];
  totals: Totals;
  failures: FailureRowLike[];
  failuresSince: string;
  /** Sent, delivered, failed and pending per vendor over the range. */
  vendors: VendorRowLike[];
  /**
   * The hourly summary's watermark when the reads leaned on it -- whole hours up to here from the
   * summary, the rest from the records -- or null when they read the records alone.
   */
  watermark: string | null;
  /** A section whose last read failed and shows its previous value. */
  stale: { traffic: boolean; revenue: boolean; failures: boolean; vendors: boolean };
  /** Buckets from this instant on are still receiving receipts: `now - smsg.cdr.deadline.hours`. */
  settlingFrom: string;
  /** Where the rolled part of the series came from on the last read. */
  source: UsageSource;
  /** How long the tick that last touched this range took. */
  tickMs: number;
}

export interface RefresherDebug {
  refreshSeconds: number;
  perRequest: boolean;
  ticks: number;
  failedTicks: number;
  lastTickMs: number;
  lastTickAt: string | null;
  source: UsageSource;
  watermark: string | null;
  ranges: Partial<Record<Range, { builtAt: string; asOf: string; buckets: number; stale: RangeSnapshot["stale"] }>>;
}

export interface Refresher {
  /**
   * The snapshot for a range: from memory when there is one; built once, shared by every caller
   * that arrives meanwhile, when there is not. Throws {@link WarmingUpError} when a first build has
   * not finished within `warmupMs` -- the build goes on, and the next request gets it.
   */
  get(range: Range, o?: { fresh?: boolean }): Promise<RangeSnapshot>;
  /** One refresh of every range in memory. Overlapping calls are skipped, not queued. */
  tick(): Promise<void>;
  stop(): void;
  debug(): RefresherDebug;
}

/** Thrown by `get` when the first build is still running. The route turns it into a 503. */
export class WarmingUpError extends Error {
  constructor() {
    super("The overview is warming up: its first read of the database has not finished yet. Try again in a few seconds.");
    this.name = "WarmingUpError";
  }
}

const DEFAULTS = {
  fullRebuildMs: 15 * 60_000,
  failuresMs: 5 * 60_000,
  warmupMs: 8_000,
  hotHours: 3,
  watermarkMaxAgeMs: 3 * 3_600_000,
} as const;

export const RANGES: readonly Range[] = ["1h", "24h", "7d", "30d"];
const HOUR_MS = 3_600_000;
const WINDOW_HOURS = 24;

/**
 * `OVERVIEW_REFRESH_SECONDS` as a cadence: 60 when unset or unreadable, never less than 15 unless
 * it is exactly 0, which means per request.
 */
export function refreshSecondsFrom(env: Record<string, string | undefined>): number {
  const raw = env.OVERVIEW_REFRESH_SECONDS?.trim();
  if (raw === undefined || raw === "") {
    return 60;
  }
  const n = Number(raw);
  if (!Number.isFinite(n) || n < 0) {
    return 60;
  }
  if (n === 0) {
    return 0;
  }
  return Math.max(15, Math.floor(n));
}

/** A bucket key as `trafficOverTime` emits it: the UTC instant without milliseconds. */
export function bucketKey(at: Date): string {
  return at.toISOString().replace(/\.\d{3}Z$/, "Z");
}

/** The start of the UTC hour `at` falls in. */
export function hourFloor(at: Date): Date {
  return new Date(Math.floor(at.getTime() / HOUR_MS) * HOUR_MS);
}

/** The 24-hour window's first bucket: 23 whole hours before the current one. */
export function windowStart(until: Date): Date {
  return new Date(hourFloor(until).getTime() - (WINDOW_HOURS - 1) * HOUR_MS);
}

/**
 * Buckets kept from the previous read, with the hot ones replaced and the aged-out ones dropped.
 *
 * <p>Pure: `prev` contributes every bucket from `windowStartKey` (inclusive) up to `hotFromKey`
 * (exclusive); `fresh` is taken whole. Keys are ISO instants, so string order is time order.
 */
export function mergeBuckets(
  prev: readonly TrafficBucket[],
  fresh: readonly TrafficBucket[],
  hotFromKey: string,
  windowStartKey: string
): TrafficBucket[] {
  const kept = prev.filter((b) => b.bucket >= windowStartKey && b.bucket < hotFromKey);
  return [...kept, ...fresh].sort((a, b) => (a.bucket < b.bucket ? -1 : a.bucket > b.bucket ? 1 : 0));
}

/** {@link mergeBuckets} for the hourly series: the window is the 24 hours ending at `until`. */
export function mergeHourly(
  prev: readonly TrafficBucket[],
  fresh: readonly TrafficBucket[],
  hotFrom: Date,
  until: Date
): TrafficBucket[] {
  return mergeBuckets(prev, fresh, bucketKey(hotFrom), bucketKey(windowStart(until)));
}

/** What a tick learns once and every range uses. */
interface TickContext {
  now: Date;
  source: UsageSource;
  watermark: Date | null;
  todayStart: Date;
  today: string;
  deadlineHours: number;
  /** Reads two ranges would otherwise both make, memoised for the tick. */
  shared: {
    dayTail?: Promise<TrafficBucket[]>;
    revenueToday?: Promise<RevenueRow[]>;
  };
  errors: string[];
}

interface RangeState {
  snap: RangeSnapshot | null;
  /** When the last full build finished, epoch ms; 0 means never. */
  fullAt: number;
  /** The billing day the last full build saw; a day range rebuilds whole when it changes. */
  fullDay: string | null;
  /** The finished days' revenue rows from the last full build, kept between ticks. */
  revenueFinished: RevenueRow[];
  /** The finished days' traffic (day ranges) from the last full build. */
  trafficFinished: TrafficBucket[];
  building: Promise<RangeSnapshot> | null;
}

interface FailuresState {
  rows: FailureRowLike[];
  since: string;
  at: number;
}

export function createRefresher(deps: SnapshotDeps, cfg: RefresherConfig): Refresher {
  const fullRebuildMs = cfg.fullRebuildMs ?? DEFAULTS.fullRebuildMs;
  const failuresMs = cfg.failuresMs ?? DEFAULTS.failuresMs;
  const warmupMs = cfg.warmupMs ?? DEFAULTS.warmupMs;
  const hotHours = cfg.hotHours ?? DEFAULTS.hotHours;
  const watermarkMaxAgeMs = cfg.watermarkMaxAgeMs ?? DEFAULTS.watermarkMaxAgeMs;
  const perRequest = cfg.refreshSeconds === 0;

  const ranges = new Map<Range, RangeState>();
  const failures = new Map<Range, FailuresState>();
  let timer: ReturnType<typeof setInterval> | null = null;
  let inTick = false;
  let ticks = 0;
  let failedTicks = 0;
  let lastTickMs = 0;
  let lastTickAt: Date | null = null;
  let lastSource: UsageSource = "live";
  let lastWatermark: Date | null = null;

  function state(range: Range): RangeState {
    let s = ranges.get(range);
    if (!s) {
      s = { snap: null, fullAt: 0, fullDay: null, revenueFinished: [], trafficFinished: [], building: null };
      ranges.set(range, s);
    }
    return s;
  }

  async function context(): Promise<TickContext> {
    const now = deps.now();
    const errors: string[] = [];
    //the seam is leaned on only while its watermark is moving: a table left behind by a rollup
    //that was switched off would otherwise push the whole window onto the live tail
    let source: UsageSource = "live";
    let watermark: Date | null = null;
    try {
      if (await deps.hasUsageHourly()) {
        watermark = await deps.hourlyWatermark();
        if (watermark && now.getTime() - watermark.getTime() < watermarkMaxAgeMs) {
          source = "hourly";
        }
      }
    } catch (err) {
      errors.push(`usage_hourly probe: ${message(err)}`);
    }
    //a tick with no billing day cannot place today, so this one is not caught: the tick fails
    //whole and the previous snapshots stand
    const day = await deps.billingDays();
    let deadlineHours = 48;
    try {
      deadlineHours = await deps.deadlineHours();
    } catch (err) {
      errors.push(`deadline: ${message(err)}`);
    }
    lastSource = source;
    lastWatermark = watermark;
    return { now, source, watermark, todayStart: day.todayStart, today: day.today, deadlineHours, shared: {}, errors };
  }

  /**
   * One section's read: its value, or the previous one and a note, never a throw.
   *
   * <p>With no previous value the section answers `empty`, stale. A first build that fails must
   * still leave a snapshot behind: the tick loop only refreshes ranges that have one, so a range
   * whose first read timed out would otherwise never be tried again in the background, and every
   * request would start a fresh build and wait on it -- the per-request path this module exists to
   * remove. Seen on a database whose last three hours held half a million rows: the first 24 h
   * read hit the statement timeout and the page sat on 503. Now it draws empty tiles marked stale,
   * and the next tick, or the hourly summary once the gateway has it, fills them.
   */
  async function section<T>(ctx: TickContext, name: string, read: () => Promise<T>, prev: T | null, empty: T): Promise<{ value: T; stale: boolean }> {
    try {
      return { value: await read(), stale: false };
    } catch (err) {
      ctx.errors.push(`${name}: ${message(err)}`);
      return { value: prev ?? empty, stale: true };
    }
  }

  async function refreshFailures(range: Range, ctx: TickContext, force: boolean): Promise<{ value: FailuresState; stale: boolean }> {
    const kept = failures.get(range) ?? null;
    const due = kept === null || force || ctx.now.getTime() - kept.at >= failuresMs;
    if (!due) {
      return { value: kept!, stale: false };
    }
    const read = await section(ctx, "failures", () => deps.failures(range), kept, { rows: [], since: ctx.now.toISOString() });
    if (!read.stale) {
      failures.set(range, { rows: read.value.rows, since: read.value.since, at: ctx.now.getTime() });
    }
    return { value: failures.get(range) ?? { rows: [], since: ctx.now.toISOString(), at: 0 }, stale: read.stale };
  }

  /** Today's traffic as day buckets, read once per tick however many day ranges ask. */
  function dayTail(ctx: TickContext, range: Range): Promise<TrafficBucket[]> {
    ctx.shared.dayTail ??= deps.traffic(range, { since: ctx.todayStart, until: ctx.now, source: ctx.source });
    return ctx.shared.dayTail;
  }

  /** Today's revenue by day, read once per tick however many ranges ask. */
  function revenueToday(ctx: TickContext, range: Range): Promise<RevenueRow[]> {
    ctx.shared.revenueToday ??= deps.revenue(range, {
      since: ctx.todayStart,
      until: ctx.now,
      groupByDay: true,
      source: ctx.source,
    });
    return ctx.shared.revenueToday;
  }

  async function refreshRange(range: Range, ctx: TickContext, wantFull: boolean): Promise<RangeSnapshot> {
    const started = Date.now();
    const s = state(range);
    const prev = s.snap;
    const dayRange = range === "7d" || range === "30d";
    const full =
      wantFull ||
      prev === null ||
      ctx.now.getTime() - s.fullAt >= fullRebuildMs ||
      //the billing day turned: yesterday is a finished day now, and the window's first day has aged out
      (dayRange && s.fullDay !== ctx.today);

    //---- traffic ----
    let traffic: { value: TrafficBucket[]; stale: boolean };
    if (range === "1h") {
      //one hour in five-minute buckets, straight from the records every tick: nothing to merge --
      //the whole window is the hot part, and no summary splits an hour
      traffic = await section(
        ctx,
        "traffic",
        () => deps.traffic(range, { source: ctx.source }),
        prev?.traffic ?? null,
        []
      );
    } else if (range === "24h") {
      const until = ctx.now;
      const start = windowStart(until);
      //with the hourly summary the whole window is 24 small rows, so it is read whole and the
      //gateway's restatements reach the page within a minute; live, only the hot hours move
      const hotFrom = full || ctx.source === "hourly" ? start : new Date(hourFloor(until).getTime() - hotHours * HOUR_MS);
      traffic = await section(
        ctx,
        "traffic",
        async () => mergeHourly(prev?.traffic ?? [], await deps.traffic(range, { since: hotFrom, until, source: ctx.source }), hotFrom, until),
        prev?.traffic ?? null,
        []
      );
    } else {
      traffic = await section(
        ctx,
        "traffic",
        async () => {
          if (full) {
            //finished days from the daily summary, never from hours: a UTC hour does not sum to a
            //billing day in every zone. Today is the one read the hourly seam serves
            s.trafficFinished = await deps.traffic(range, { until: ctx.todayStart, source: "live" });
          }
          const today = await dayTail(ctx, range);
          return mergeBuckets(s.trafficFinished, today, bucketKey(ctx.todayStart), "");
        },
        prev?.traffic ?? null,
        []
      );
    }

    //---- revenue ----
    const revenue = await section(
      ctx,
      "revenue",
      async () => {
        if (range === "1h") {
          //the hour is read whole: splitting it at the billing day would read the same rows twice
          return sumRevenueByAccount(await deps.revenue(range, { groupByDay: true, source: ctx.source }));
        }
        if (full) {
          s.revenueFinished = await deps.revenue(range, { until: ctx.todayStart, groupByDay: true, source: "live" });
        }
        const today = await revenueToday(ctx, range);
        return sumRevenueByAccount([...s.revenueFinished, ...today]);
      },
      prev?.revenue ?? null,
      []
    );

    //---- failures, per range on their own cadence; per request when nothing is kept ----
    const f = await refreshFailures(range, ctx, perRequest);

    //---- vendors: summary plus an index range of records, cheap enough for every tick ----
    const vendors = await section(ctx, "vendors", () => deps.vendors(range), prev?.vendors ?? null, []);

    const stale = { traffic: traffic.stale, revenue: revenue.stale, failures: f.stale, vendors: vendors.stale };
    //a full build whose every section succeeded resets the clock; one that leaned on a previous
    //section is tried again next tick
    if (full && !traffic.stale && !revenue.stale) {
      s.fullAt = ctx.now.getTime();
      s.fullDay = ctx.today;
    }
    const snap: RangeSnapshot = {
      builtAt: new Date(s.fullAt || ctx.now.getTime()).toISOString(),
      asOf: ctx.now.toISOString(),
      traffic: traffic.value,
      revenue: revenue.value,
      totals: totalsOf(traffic.value, revenue.value),
      failures: f.value.rows,
      failuresSince: f.value.since,
      vendors: vendors.value,
      watermark: ctx.source === "hourly" && ctx.watermark ? ctx.watermark.toISOString() : null,
      stale,
      settlingFrom: new Date(ctx.now.getTime() - ctx.deadlineHours * HOUR_MS).toISOString(),
      source: ctx.source,
      tickMs: Date.now() - started,
    };
    s.snap = snap;
    return snap;
  }

  function report(ctx: TickContext): void {
    if (ctx.errors.length) {
      failedTicks++;
      //one line per tick, however many sections failed: the cause is usually one and the same
      deps.log(`overview snapshot: ${ctx.errors.join("; ")}`);
    }
  }

  async function buildOne(range: Range, full: boolean): Promise<RangeSnapshot> {
    const started = Date.now();
    const ctx = await context();
    try {
      return await refreshRange(range, ctx, full);
    } finally {
      lastTickMs = Date.now() - started;
      lastTickAt = ctx.now;
      report(ctx);
    }
  }

  async function tick(): Promise<void> {
    if (inTick || perRequest) {
      return;
    }
    inTick = true;
    const started = Date.now();
    ticks++;
    try {
      const ctx = await context();
      for (const range of RANGES) {
        const s = ranges.get(range);
        //a range nobody has asked for is never built; one being built by a request is left to it
        if (!s || s.snap === null || s.building) {
          continue;
        }
        try {
          await refreshRange(range, ctx, false);
        } catch (err) {
          ctx.errors.push(`${range}: ${message(err)}`);
        }
      }
      lastTickAt = ctx.now;
      report(ctx);
    } catch (err) {
      failedTicks++;
      deps.log(`overview snapshot: tick failed: ${message(err)}`);
    } finally {
      lastTickMs = Date.now() - started;
      inTick = false;
    }
  }

  function ensureTimer(): void {
    if (timer || perRequest || cfg.schedule === false) {
      return;
    }
    timer = setInterval(() => {
      void tick();
    }, cfg.refreshSeconds * 1000);
    //never the reason the process stays up
    timer.unref?.();
  }

  async function get(range: Range, o: { fresh?: boolean } = {}): Promise<RangeSnapshot> {
    if (perRequest) {
      return buildOne(range, true);
    }
    ensureTimer();
    const s = state(range);
    if (o.fresh || s.snap === null) {
      //single flight: every caller that arrives while the build runs waits on the same promise
      s.building ??= buildOne(range, o.fresh === true).finally(() => {
        s.building = null;
      });
      return raceWarmup(s.building, warmupMs);
    }
    return s.snap;
  }

  function stop(): void {
    if (timer) {
      clearInterval(timer);
      timer = null;
    }
  }

  function debug(): RefresherDebug {
    const out: RefresherDebug["ranges"] = {};
    for (const [range, s] of ranges) {
      if (s.snap) {
        out[range] = { builtAt: s.snap.builtAt, asOf: s.snap.asOf, buckets: s.snap.traffic.length, stale: s.snap.stale };
      }
    }
    return {
      refreshSeconds: cfg.refreshSeconds,
      perRequest,
      ticks,
      failedTicks,
      lastTickMs,
      lastTickAt: lastTickAt?.toISOString() ?? null,
      source: lastSource,
      watermark: lastWatermark?.toISOString() ?? null,
      ranges: out,
    };
  }

  return { get, tick, stop, debug };
}

/**
 * The build, or {@link WarmingUpError} after `ms`; the build itself is never cancelled. The timer
 * is deliberately not unref'd: it is cleared the moment the build settles, and a request is
 * waiting on it.
 */
function raceWarmup<T>(build: Promise<T>, ms: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const t = setTimeout(() => reject(new WarmingUpError()), ms);
    build.then(
      (v) => {
        clearTimeout(t);
        resolve(v);
      },
      (e) => {
        clearTimeout(t);
        reject(e);
      }
    );
  });
}

function message(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}
