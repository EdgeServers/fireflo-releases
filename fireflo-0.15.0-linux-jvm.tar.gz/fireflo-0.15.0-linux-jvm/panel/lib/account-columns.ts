import type { AccountSummary, OrphanAccount } from "./account-types";
import type { Credential } from "./credential-types";
import type { TableColumn } from "./table-columns";
import { resolveColumns as resolveFrom } from "./table-columns";
import { platformOf } from "./platform-ref";

export { platformOf };

/**
 * The columns of the account index, and the row shape they read.
 *
 * <p>Database-free, so a client component can import it. The shared choosing and sorting live in
 * `table-columns.ts`; what is here is which columns exist and what each pulls out of a row.
 */

/**
 * One login, with the account it bills to — the grain this table shows.
 *
 * <p><strong>A row is a login, not an account.</strong> An account with three logins is three rows.
 * This replaced a per-account row carrying a count, because a count is the wrong answer: "3 logins"
 * says nothing about which is disabled, which has no password, or which product each is billed
 * under — and those are the questions an index of a thousand customers exists to answer.
 *
 * <p>The account-level fields — the name, the badges, {@link ruleCount} — repeat across an account's
 * rows. That is the cost of this grain and the one thing about it that misleads if read carelessly,
 * which is why the rules column says so in a tooltip and the footer counts rows and accounts
 * separately.
 *
 * <p>`loginId` is null on the one kind of row that is not a login: an account nobody has connected
 * to yet, which still has to appear in the index that exists to find it.
 */
export interface AccountLoginRow {
  id: string;
  label: string | null;
  description: string | null;
  email: string | null;
  /** Whether this account holds other accounts beneath it. */
  resells: boolean;
  /** The reseller it belongs to, or null when it is top-level. */
  parent: string | null;
  /** How many accounts sit beneath it. 0 unless it resells. */
  children: number;
  /** The platform managing it (gateway V1.101.0), e.g. OMNI; null for an account made here. */
  managedBy?: string | null;
  /** Rules on the account's whole price scope, repeated on every row of that account. */
  rules: number;
  collides: boolean;
  listed: boolean;
  catalogued: boolean;
  updatedAt: string | null;
  /** Why an uncatalogued id is here at all; empty for a catalogued account. */
  note: string;

  loginId: number | null;
  type: string | null;
  systemId: string | null;
  /** Null means a login that names no product; it bills by whatever any-product rule applies. */
  product: string | null;
  allowedIps: string[];
  /** Null on a no-logins row, so it sorts as empty rather than as "disabled". */
  loginEnabled: boolean | null;
  loginUpdatedAt: string | null;
  hasPassword: boolean;
  hasApiKey: boolean;
  /** What this login stamps onto every message it sends. Empty for most. */
  tlvs: { key: string; value: string }[];
  /** Resolved billing account and how it got there, for the column that shows the fallback. */
  billsTo: string | null;
  billsToFallback: "none" | "systemId" | "apiKey";
}

export type AccountColumnGroup = "Identity" | "Login" | "Configuration";

export type AccountFormat =
  | "account" | "text" | "product" | "number" | "flags" | "time"
  | "type" | "ips" | "auth" | "loginStatus" | "tlvs" | "billsTo";

export interface AccountColumn extends TableColumn<AccountLoginRow, AccountColumnGroup> {
  format: AccountFormat;
}

/**
 * How a login authenticates, derived rather than stored.
 *
 * <p>`none` is the interesting one: a credential with neither a password nor an api key. This is the
 * first view in the panel that surfaces that across every account at once, so it is rendered as a
 * warning rather than as a value.
 */
export function authOf(row: AccountLoginRow): string | null {
  if (row.loginId == null) {
    return null;
  }
  if (row.hasPassword && row.hasApiKey) {
    return "both";
  }
  if (row.hasPassword) {
    return "password";
  }
  return row.hasApiKey ? "API key" : "none";
}

export const ACCOUNT_COLUMNS: readonly AccountColumn[] = [
  //the row's identity and its way in. Sorts by whatever is displayed first -- the name when there is
  //one, the id when there is not -- which is the order the column visibly reads in
  { id: "account", header: "Account", group: "Identity", from: (r) => r.label ?? r.id, format: "account", defaultOn: true },
  { id: "label", header: "Name", group: "Identity", from: (r) => r.label, format: "text", defaultOn: false },
  { id: "id", header: "Id", group: "Identity", from: (r) => r.id, format: "text", defaultOn: false },
  { id: "description", header: "Notes", group: "Identity", from: (r) => r.description, format: "text", defaultOn: false },
  { id: "email", header: "Email", group: "Identity", from: (r) => r.email, format: "text", defaultOn: true },
  //the two halves of the hierarchy, and both off by default: most deployments have no resellers at
  //all, and a column of blanks on every row costs width the message columns need
  { id: "resells", header: "Reseller", group: "Identity", from: (r) => (r.resells ? `${r.children} account${r.children === 1 ? "" : "s"}` : null), format: "text", defaultOn: false },
  { id: "parent", header: "Belongs to", group: "Identity", from: (r) => r.parent, format: "account", defaultOn: false },
  //off by default for the same reason: most deployments have no platform provisioning accounts
  { id: "managed", header: "Managed by", group: "Identity", from: (r) => r.managedBy ?? null, format: "text", defaultOn: false },
  //"Account flags", not "Status": Status is the login's now, and two columns of that name on one
  //table is how a table gets misread. Sorts by how much is wrong, so a collision leads descending
  { id: "status", header: "Account flags", group: "Identity", from: (r) => (r.collides ? 3 : 0) + (r.catalogued ? 0 : 2) + (r.listed ? 0 : 1), format: "flags", defaultOn: false },

  { id: "systemId", header: "System ID", group: "Login", from: (r) => r.systemId, format: "text", defaultOn: true },
  { id: "type", header: "Type", group: "Login", from: (r) => r.type, format: "type", defaultOn: true },
  { id: "product", header: "Product", group: "Login", from: (r) => r.product, format: "product", defaultOn: true },
  { id: "allowedIps", header: "Allowed IPs", group: "Login", from: (r) => (r.loginId == null ? null : r.allowedIps.join(", ")), format: "ips", defaultOn: true },
  { id: "auth", header: "Auth", group: "Login", from: authOf, format: "auth", defaultOn: true },
  { id: "loginEnabled", header: "Status", group: "Login", from: (r) => (r.loginEnabled == null ? null : r.loginEnabled ? "enabled" : "disabled"), format: "loginStatus", defaultOn: true },
  //sorted by the joined pairs, so logins stamping the same tag group together
  { id: "tlvs", header: "Default TLVs", group: "Login", from: (r) => tlvText(r), format: "tlvs", defaultOn: true },
  //off by default: on the index the Account column already says it, and in the Logins card the card
  //title does. Its worth is the fallback annotation, which is per-login and invisible elsewhere
  { id: "billsTo", header: "Bills to", group: "Login", from: (r) => r.billsTo, format: "billsTo", defaultOn: false },
  { id: "loginUpdatedAt", header: "Login updated", group: "Login", from: (r) => r.loginUpdatedAt, format: "time", defaultOn: false },
  { id: "loginId", header: "Login id", group: "Login", from: (r) => r.loginId, format: "number", align: "right", defaultOn: false },

  { id: "rules", header: "Price rules", group: "Configuration", from: (r) => (r.catalogued ? r.rules : null), format: "number", align: "right", defaultOn: true },
  { id: "updatedAt", header: "Account updated", group: "Configuration", from: (r) => r.updatedAt, format: "time", defaultOn: false },
];

/** `key=value` per pair, joined — the sort key, and what the cell renders one per line. */
export function tlvText(row: AccountLoginRow): string {
  return row.tlvs.map((t) => `${t.key}=${t.value}`).join("\n");
}

export const ACCOUNT_COLUMN_GROUPS = ["Identity", "Login", "Configuration"] as const;

/**
 * The same catalogue, narrowed to the login's own fields.
 *
 * <p>For the "Logins that bill here" card, which is scoped to one account and so has no use for the
 * Identity or Configuration groups. A filter rather than a second catalogue: these eight definitions
 * would otherwise have to be kept in agreement with the index's by hand, forever.
 */
export const LOGIN_COLUMNS: readonly AccountColumn[] =
  ACCOUNT_COLUMNS.filter((c) => c.group === "Login");

export const LOGIN_COLUMN_GROUPS = ["Login"] as const;

/** Its own slot, so choosing columns in the card never disturbs the index. */
export const LOGIN_COLUMN_STORAGE_KEY = "fireflo.logins.columns";

export function resolveLoginColumns(
  choice: import("./table-columns").ColumnChoice | null
): AccountColumn[] {
  return resolveFrom(LOGIN_COLUMNS, choice) as AccountColumn[];
}

/** Its own slot, so choosing columns here never disturbs `/cdrs`. */
export const ACCOUNT_COLUMN_STORAGE_KEY = "fireflo.accounts.columns";

export const ACCOUNT_PAGE_SIZES = [25, 50, 100] as const;
export const DEFAULT_ACCOUNT_PAGE_SIZE = 25;

export function resolveAccountColumns(
  choice: import("./table-columns").ColumnChoice | null
): AccountColumn[] {
  return resolveFrom(ACCOUNT_COLUMNS, choice) as AccountColumn[];
}

/**
 * The columns that say what an account is charged, by id.
 *
 * <p>`rules` is the count of price rules on the account's own rate scope — a count is still a fact
 * about pricing, and its cell links straight into the tariff editor. `product` is the product the
 * login bills under, which is the lever that picks the rate.
 *
 * <p>Named as a set rather than filtered inline so the two callers below cannot drift, and so adding
 * a pricing column later is one edit here rather than a search.
 */
const PRICING_COLUMNS: readonly string[] = ["rules", "product"];

/**
 * The catalogue as a surface without pricing sees it — see `lib/panel-surface.ts`.
 *
 * <p>A filter over the one catalogue rather than a second list, the same argument
 * {@link LOGIN_COLUMNS} makes: two lists of column definitions would have to be kept in agreement by
 * hand, forever, and the one that drifts is the one nobody is looking at.
 *
 * <p>The filter is not the only lock. `listChildren` does not query the rule count and returns zero,
 * and the reseller's login projection returns `product` as it is stored — which the writer pins
 * NULL. Removing the columns is what stops an empty cell reading as "no custom pricing".
 */
export const RESELLER_ACCOUNT_COLUMNS: readonly AccountColumn[] =
  ACCOUNT_COLUMNS.filter((c) => !PRICING_COLUMNS.includes(c.id));

export const RESELLER_LOGIN_COLUMNS: readonly AccountColumn[] =
  LOGIN_COLUMNS.filter((c) => !PRICING_COLUMNS.includes(c.id));

/**
 * The account columns this surface may show, and the choice resolved against them.
 *
 * <p>One entry point rather than a `pricing ? … : …` at each call site: the stored column choice is
 * per browser and shared between surfaces, so an operator's saved choice may name `rules` — and
 * resolving it against the wrong catalogue is precisely how a hidden column comes back.
 */
export function resolveAccountColumnsFor(
  choice: import("./table-columns").ColumnChoice | null,
  pricing: boolean
): AccountColumn[] {
  const from = pricing ? ACCOUNT_COLUMNS : RESELLER_ACCOUNT_COLUMNS;
  return resolveFrom(from, choice) as AccountColumn[];
}

/** As above, for the "Logins that bill here" card. */
export function resolveLoginColumnsFor(
  choice: import("./table-columns").ColumnChoice | null,
  pricing: boolean
): AccountColumn[] {
  const from = pricing ? LOGIN_COLUMNS : RESELLER_LOGIN_COLUMNS;
  return resolveFrom(from, choice) as AccountColumn[];
}

/** A login that bills to its own api key, so the account id would be a secret. */
export function isUnlistableLogin(login: Credential): boolean {
  return login.billingAccount == null;
}

/**
 * Flattens the catalogue, the orphans and the logins into the rows the table shows.
 *
 * <p>Done here rather than in SQL so that `listAccounts` stays one row per account — two other pages
 * call `accounts.find(a => a.id === id)` on it and would not notice duplicates until something
 * counted them.
 *
 * <p><strong>An account with no logins still gets a row.</strong> Dropping it would remove a new
 * customer from the index that exists to find them, which is exactly when they are hardest to find.
 *
 * <p>Logins with no account id are skipped: those are HTTP credentials billing to their own api key,
 * so the account they belong to is named by a secret. The caller counts them and says so rather than
 * listing them — see {@link isUnlistableLogin}.
 */
export function buildLoginRows(
  accounts: readonly AccountSummary[],
  orphans: readonly OrphanAccount[],
  logins: readonly Credential[]
): AccountLoginRow[] {
  const byAccount = new Map<string, Credential[]>();
  for (const login of logins) {
    if (login.billingAccount == null) {
      continue;
    }
    const list = byAccount.get(login.billingAccount);
    if (list) {
      list.push(login);
    } else {
      byAccount.set(login.billingAccount, [login]);
    }
  }

  const rows: AccountLoginRow[] = [];

  const expand = (base: Omit<AccountLoginRow, keyof LoginFields>) => {
    const found = byAccount.get(base.id);
    if (!found?.length) {
      rows.push({ ...base, ...NO_LOGIN });
      return;
    }
    for (const login of found) {
      rows.push({ ...base, ...loginFieldsOf(login) });
    }
  };

  for (const a of accounts) {
    expand({
      id: a.id,
      label: a.label,
      description: a.description,
      email: a.email,
      resells: a.resells,
      parent: a.parentAccountId,
      children: a.childCount,
      managedBy: platformOf(a.externalRef),
      rules: a.ruleCount,
      collides: a.collidesWithVendor,
      listed: a.enabled,
      catalogued: true,
      updatedAt: a.updatedAt,
      note: "",
    });
  }

  for (const o of orphans) {
    expand({
      id: o.id,
      label: null,
      description: null,
      email: null,
      //an orphan has no app_account row at all, so it can neither resell nor belong to a reseller
      resells: false,
      parent: null,
      children: 0,
      rules: 0,
      collides: false,
      listed: true,
      catalogued: false,
      updatedAt: null,
      //a rate-scope-only id might be a vendor that was deleted; the column holds both kinds
      note: o.fromCredential ? "used by a login" : "rate scope only — may not be an account",
    });
  }

  return rows;
}

/** The half of a row that comes from the login rather than from the account. */
type LoginFields = Pick<AccountLoginRow,
  "loginId" | "type" | "systemId" | "product" | "allowedIps" | "loginEnabled"
  | "loginUpdatedAt" | "hasPassword" | "hasApiKey" | "tlvs" | "billsTo" | "billsToFallback">;

/** An account nobody has connected to yet: a real row, with no login on it. */
const NO_LOGIN: LoginFields = {
  loginId: null, type: null, systemId: null, product: null, allowedIps: [],
  loginEnabled: null, loginUpdatedAt: null, hasPassword: false, hasApiKey: false,
  tlvs: [], billsTo: null, billsToFallback: "none",
};

function loginFieldsOf(login: Credential): LoginFields {
  return {
    loginId: login.id,
    type: login.type,
    systemId: login.systemId,
    product: login.product,
    allowedIps: login.allowedIps,
    loginEnabled: login.enabled,
    loginUpdatedAt: login.updatedAt,
    hasPassword: login.password === "stored",
    hasApiKey: login.apiKey === "stored",
    tlvs: login.defaultTlvs,
    billsTo: login.billingAccount,
    billsToFallback: login.billingAccountFallback,
  };
}

/**
 * One login as a row, with the account half left blank.
 *
 * <p>For the "Logins that bill here" card, which is already scoped to an account and needs only the
 * Login group. Sharing this with {@link buildLoginRows} is what keeps the two surfaces reading the
 * same columns off the same fields.
 */
export function loginRow(login: Credential): AccountLoginRow {
  return {
    id: login.billingAccount ?? "",
    label: null, description: null, email: null, rules: 0, collides: false, listed: true,
    catalogued: true, updatedAt: null, note: "",
    //the Logins card is already scoped to one account, so the hierarchy columns are not its subject
    resells: false, parent: null, children: 0,
    ...loginFieldsOf(login),
  };
}

/** The stable identity of a row. Two logins on one account share an id, so this cannot be it. */
export function rowKey(row: AccountLoginRow): string {
  return row.loginId == null ? `account:${row.id}` : `login:${row.loginId}`;
}

/**
 * Matches the account id and name, and the login's system id, product, allowed IPs and TLVs.
 *
 * <p><strong>The TLVs searched are the ones this login is configured to stamp</strong>, not what a
 * message ends up carrying: an approved header or template stamps its own on match, and none of that
 * is stored here. The question this answers is "which login is set up to send X".
 */
export function matchesAccountQuery(row: AccountLoginRow, query: string): boolean {
  const q = query.trim().toLowerCase();
  if (!q) {
    return true;
  }
  const hit = (value: string | null) => (value ?? "").toLowerCase().includes(q);
  return hit(row.id)
    || hit(row.label)
    || hit(row.email)
    || hit(row.systemId)
    || hit(row.product)
    || row.allowedIps.some(hit)
    || row.tlvs.some((t) => hit(t.key) || hit(t.value));
}
