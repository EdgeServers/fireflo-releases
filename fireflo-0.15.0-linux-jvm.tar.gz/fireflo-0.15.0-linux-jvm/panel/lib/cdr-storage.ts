import type { ChangeLine } from "./confirm-changes.ts";

/**
 * The call record archive (gateway 0.15, `cdrStorage`, capability `cdr_storage`) and the pure
 * pieces Reports → Archives draws and edits it with: the schedule's two shapes, the settings form,
 * its checks, and the sentence each change gets in the confirmation.
 *
 * <p>Database- and React-free, so a client component imports it and a test asserts it.
 *
 * <h2>What the archive is</h2>
 *
 * <p>Live traffic writes the hot call record tables, which keep the last `smsg.cdr.hot.days` days
 * (today included, at least 3: receipts arrive for two). Each finished day that is settled -- past
 * the receipts window and the expiry sweep, summarised hourly and daily -- is moved into the archive
 * on a schedule by re-attaching its partition: the same rows in the same database, nothing copied,
 * nothing deleted. Every reader that reaches back past the hot days reads both. Only the manual
 * `fireflo usage purge` ever removes call records.
 */

/** The gateway release that brings it. */
export const CDR_TIERS_RELEASE = "0.15";

/** The four registry keys the settings card writes (V1.112.0). */
export const CDR_ARCHIVE_KEYS = {
  hotDays: "smsg.cdr.hot.days",
  schedule: "smsg.cdr.archive.schedule",
  enabled: "smsg.cdr.archive.enabled",
  export: "smsg.cdr.archive.export",
} as const;

/** The least `smsg.cdr.hot.days` the gateway takes; app_config refuses less (SQLSTATE 23514). */
export const MIN_HOT_DAYS = 3;
/** More than a year of live days defeats the point; the gateway takes up to five digits. */
export const MAX_HOT_DAYS = 400;

export const WEEKDAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"] as const;
export type Weekday = (typeof WEEKDAYS)[number];

export const WEEKDAY_LABEL: Record<Weekday, string> = {
  mon: "Monday", tue: "Tuesday", wed: "Wednesday", thu: "Thursday", fri: "Friday", sat: "Saturday", sun: "Sunday",
};

/** One side of the tables, as `CdrTierSize`. */
export interface CdrTierSize {
  /** The planner's estimate, not a count. */
  rowsEstimate: number;
  bytes: number;
  partitions: number;
  oldestDay: string | null;
  newestDay: string | null;
}

export interface CdrStorageTable {
  table: string;
  hot: CdrTierSize;
  archive: CdrTierSize;
  hotDefaultRows: number;
}

export interface CdrWaitingDay {
  day: string;
  /** receipts, summary or earlier. */
  reason: string;
  detail: string;
}

export interface CdrArchiveRun {
  runId: string | null;
  startedAt: string | null;
  finishedAt: string | null;
  nodeId: string | null;
  day: string | null;
  table: string;
  rowsBefore: number | null;
  rowsAfter: number | null;
  ms: number;
  /** moved, skipped or failed. */
  outcome: string;
  reason: string | null;
  error: string | null;
}

/** `cdrStorage` as the gateway answers it. */
export interface CdrStorage {
  tiered: boolean;
  hotDays: number;
  hotFrom: string | null;
  movingTo: string | null;
  tieredFrom: string | null;
  enabled: boolean;
  schedule: string;
  scheduleValid: boolean;
  nextMoveAt: string | null;
  export: boolean;
  exportDir: string;
  purgeKeepDays: number;
  purgeCommand: string;
  /** db or file. */
  configSource: string;
  lastRunAt: string | null;
  lastMoveAt: string | null;
  lastMoveDay: string | null;
  lastError: string | null;
  lastErrorAt: string | null;
  hotDefaultRows: number;
  refusal: string | null;
  hot: CdrTierSize;
  archive: CdrTierSize;
  tables: CdrStorageTable[];
  ready: string[];
  waiting: CdrWaitingDay[];
  log: CdrArchiveRun[];
}

/** What `/api/control/archives/cdr-storage` answers. */
export type CdrStorageAnswer =
  | { data: CdrStorage; unsupported?: false }
  /** The gateway does not declare `cdr_storage`: it is older than 0.15. */
  | { data: null; unsupported: true; release: string };

/** A schedule, taken apart. */
export interface ArchiveSchedule {
  cadence: "daily" | "weekly";
  /** Set when weekly. */
  weekday: Weekday;
  /** `HH:MM`, UTC. */
  time: string;
}

const SCHEDULE = /^(daily|weekly +(mon|tue|wed|thu|fri|sat|sun)) +([01]?[0-9]|2[0-3]):([0-5][0-9])$/;

/**
 * `daily 01:30` or `weekly sun 01:30` (UTC), as the gateway parses it -- the same pattern the
 * registry check (`config_value_problem`) refuses anything else with. Null when it does not parse.
 */
export function parseSchedule(text: string | null | undefined): ArchiveSchedule | null {
  const m = SCHEDULE.exec((text ?? "").trim().toLowerCase().replace(/\s+/g, " "));
  if (!m) {
    return null;
  }
  const weekly = m[1].startsWith("weekly");
  return {
    cadence: weekly ? "weekly" : "daily",
    weekday: (weekly ? m[2] : "sun") as Weekday,
    time: `${m[3].padStart(2, "0")}:${m[4]}`,
  };
}

/** The schedule as the key stores it. */
export function scheduleText(s: ArchiveSchedule): string {
  return s.cadence === "weekly" ? `weekly ${s.weekday} ${s.time}` : `daily ${s.time}`;
}

/** `Daily at 01:30 UTC`, `Sundays at 01:30 UTC`, or the text itself when it does not parse. */
export function describeSchedule(text: string): string {
  const s = parseSchedule(text);
  if (!s) {
    return text ? `"${text}" (not a schedule)` : "not set";
  }
  return s.cadence === "weekly" ? `${WEEKDAY_LABEL[s.weekday]}s at ${s.time} UTC` : `Daily at ${s.time} UTC`;
}

/**
 * The next run of a schedule after `now`: today's time if still ahead, else the next day (or the
 * next chosen weekday). The gateway's `CdrArchiveSchedule.nextAt`, for the confirmation's sentence.
 */
export function nextRun(s: ArchiveSchedule, now: Date): Date {
  const [h, m] = s.time.split(":").map(Number);
  const at = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), h, m));
  if (s.cadence === "daily") {
    return at.getTime() > now.getTime() ? at : new Date(at.getTime() + 86_400_000);
  }
  //getUTCDay: 0 is Sunday; WEEKDAYS starts on Monday
  const want = (WEEKDAYS.indexOf(s.weekday) + 1) % 7;
  let ahead = (want - at.getUTCDay() + 7) % 7;
  if (ahead === 0 && at.getTime() <= now.getTime()) {
    ahead = 7;
  }
  return new Date(at.getTime() + ahead * 86_400_000);
}

/** The settings card's fields, as typed. */
export interface ArchiveSettingsForm {
  hotDays: string;
  cadence: "daily" | "weekly";
  weekday: Weekday;
  time: string;
  enabled: boolean;
  export: boolean;
}

/** The form for what the gateway has in force. A schedule that does not parse starts as daily 01:30. */
export function formFromStorage(s: Pick<CdrStorage, "hotDays" | "schedule" | "enabled" | "export">): ArchiveSettingsForm {
  const schedule = parseSchedule(s.schedule) ?? { cadence: "daily", weekday: "sun", time: "01:30" };
  return {
    hotDays: String(s.hotDays),
    cadence: schedule.cadence,
    weekday: schedule.weekday,
    time: schedule.time,
    enabled: s.enabled,
    export: s.export,
  };
}

export interface ArchiveSettingsErrors {
  hotDays?: string;
  time?: string;
}

/** What is wrong with the form, field by field; empty when it can be saved. */
export function validateArchiveSettings(f: ArchiveSettingsForm): ArchiveSettingsErrors {
  const errors: ArchiveSettingsErrors = {};
  const days = f.hotDays.trim();
  if (!/^\d{1,5}$/.test(days)) {
    errors.hotDays = "A whole number of days.";
  } else if (Number(days) < MIN_HOT_DAYS) {
    errors.hotDays = `At least ${MIN_HOT_DAYS}: receipts arrive for two days after a message, and the day they land on must still be live.`;
  } else if (Number(days) > MAX_HOT_DAYS) {
    errors.hotDays = `At most ${MAX_HOT_DAYS}. The live tables are meant to be small.`;
  }
  if (!/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/.test(f.time.trim())) {
    errors.time = "A time as HH:MM, 00:00 to 23:59, UTC.";
  }
  return errors;
}

/** One key to write, with the line and the sentence the confirmation shows for it. */
export interface ArchiveSettingChange extends ChangeLine {
  key: string;
  value: string;
}

/** Whole UTC days from `from` (YYYY-MM-DD) to `to`'s day, both counted. */
function daysSpanned(from: string, to: Date): number {
  const start = Date.parse(`${from}T00:00:00Z`);
  const end = Date.UTC(to.getUTCFullYear(), to.getUTCMonth(), to.getUTCDate());
  return Number.isFinite(start) ? Math.max(0, Math.round((end - start) / 86_400_000) + 1) : 0;
}

function plural(n: number, word: string): string {
  return `${n} ${word}${n === 1 ? "" : "s"}`;
}

function at(d: Date): string {
  return `${d.toISOString().slice(0, 16).replace("T", " ")} UTC`;
}

/**
 * The keys a save writes, in order, each with what it does -- e.g. "the next move will archive 4
 * days". Nothing for a field left as it was.
 */
export function archiveSettingChanges(
  current: Pick<CdrStorage, "hotDays" | "schedule" | "enabled" | "export" | "exportDir" | "hot" | "nextMoveAt">,
  f: ArchiveSettingsForm,
  now: Date = new Date()
): ArchiveSettingChange[] {
  const out: ArchiveSettingChange[] = [];
  const nextDays = Number(f.hotDays.trim());
  const schedule = scheduleText({ cadence: f.cadence, weekday: f.weekday, time: f.time.trim() });
  const nextMove = parseSchedule(schedule);
  const when = f.enabled && nextMove ? at(nextRun(nextMove, now)) : null;

  if (nextDays !== current.hotDays) {
    //the days the hot tables hold now, today included; the move archives what is past the window
    const live = current.hot.oldestDay ? daysSpanned(current.hot.oldestDay, now) : 0;
    const willMove = Math.max(0, live - nextDays);
    const wouldHave = Math.max(0, live - current.hotDays);
    const next = `The next move${when ? ` (${when})` : ""}`;
    const note = willMove > 0
      ? `${next} will archive ${plural(willMove, "day")}${willMove !== wouldHave ? ` instead of ${wouldHave}` : ""}, each once it is settled. Readers of those days read the archive with it; nothing is deleted.`
      : nextDays > current.hotDays
        ? `${next} will archive nothing: every day now live stays live for ${plural(nextDays, "day")}, and the live tables grow by ${plural(nextDays - current.hotDays, "day")}.`
        : `${next} keeps ${plural(nextDays, "day")} live. Nothing is deleted.`;
    out.push({ key: CDR_ARCHIVE_KEYS.hotDays, value: String(nextDays), label: "Days kept live",
      from: String(current.hotDays), to: String(nextDays), note });
  }
  if (schedule !== (parseSchedule(current.schedule) ? scheduleText(parseSchedule(current.schedule)!) : current.schedule)) {
    out.push({ key: CDR_ARCHIVE_KEYS.schedule, value: schedule, label: "Schedule",
      from: describeSchedule(current.schedule), to: describeSchedule(schedule),
      note: f.enabled && when ? `The next move runs at ${when}.` : "Takes effect when moves are switched on." });
  }
  if (f.enabled !== current.enabled) {
    out.push({ key: CDR_ARCHIVE_KEYS.enabled, value: String(f.enabled), label: "Moves",
      from: current.enabled ? "on" : "off", to: f.enabled ? "on" : "off",
      note: f.enabled
        ? `Settled days move again from ${when ?? "the next scheduled run"}.`
        : "No day moves until this is switched back on. The live tables keep every day and grow; nothing is lost." });
  }
  if (f.export !== current.export) {
    out.push({ key: CDR_ARCHIVE_KEYS.export, value: String(f.export), label: "CSV copy on each move",
      from: current.export ? "on" : "off", to: f.export ? "on" : "off",
      note: f.export
        ? `Each billing day whose records have all moved is also written as CSV.gz with a SHA-256 manifest to ${current.exportDir || "FIREFLO_ARCHIVE_DIR"} on the node that moves it.`
        : "Days move without a CSV copy. Copies already written stay where they are." });
  }
  return out;
}

/** The confirmation's one sentence, over every change. */
export function archiveSettingsConsequence(changes: readonly ArchiveSettingChange[]): string {
  return changes.length === 1
    ? "This changes one call record archive setting for the whole gateway. The gateway takes it up at its next configuration poll (30 s), or now with Apply now."
    : `This changes ${changes.length} call record archive settings for the whole gateway. The gateway takes them up at its next configuration poll (30 s), or now with Apply now.`;
}

/** Why the settings cannot be edited here, or null when they can. */
export function settingsReadOnlyReason(s: Pick<CdrStorage, "configSource">, configWritable: boolean): string | null {
  if (s.configSource !== "db") {
    return "This gateway reads its settings from smsg.properties (FIREFLO_CONFIG_SOURCE=file), so they are changed in that file on the gateway host, not here.";
  }
  if (!configWritable) {
    return "This panel has no CONFIG_DATABASE_URL, so it can read the settings but not change them.";
  }
  return null;
}

/** The waiting reasons in words for the table's first column. */
export const WAITING_LABEL: Record<string, string> = {
  receipts: "Receipts window open",
  summary: "Not summarised yet",
  earlier: "An earlier day is waiting",
};

/** `moved`, `skipped`, `failed` as a badge. */
export function outcomeTone(outcome: string): "success" | "outline" | "destructive" {
  return outcome === "moved" ? "success" : outcome === "failed" ? "destructive" : "outline";
}

/** `412 ms`, `3.4 s`, `2 min 5 s`. */
export function duration(ms: number | null | undefined): string {
  if (ms == null || !Number.isFinite(ms)) {
    return "—";
  }
  if (ms < 1000) {
    return `${Math.round(ms)} ms`;
  }
  if (ms < 60_000) {
    return `${(ms / 1000).toFixed(ms < 10_000 ? 1 : 0)} s`;
  }
  const s = Math.round(ms / 1000);
  return `${Math.floor(s / 60)} min ${s % 60} s`;
}

/** `2026-10-21 → 2026-10-27, 7 days`, or what is known of it. */
export function daySpan(oldest: string | null, newest: string | null): string {
  if (!oldest || !newest) {
    return "empty";
  }
  if (oldest === newest) {
    return oldest;
  }
  const days = Math.round((Date.parse(`${newest}T00:00:00Z`) - Date.parse(`${oldest}T00:00:00Z`)) / 86_400_000) + 1;
  return `${oldest} → ${newest}, ${plural(days, "day")}`;
}

/** Normalises the gateway's answer: Long scalars may arrive as strings, lists may be absent. */
export function normaliseCdrStorage(raw: unknown): CdrStorage {
  const r = (raw ?? {}) as Record<string, unknown>;
  const num = (v: unknown): number => (v == null || v === "" ? 0 : Number(v));
  const numOrNull = (v: unknown): number | null => (v == null || v === "" ? null : Number(v));
  const str = (v: unknown): string | null => (v == null ? null : String(v));
  const size = (v: unknown): CdrTierSize => {
    const s = (v ?? {}) as Record<string, unknown>;
    return { rowsEstimate: num(s.rowsEstimate), bytes: num(s.bytes), partitions: num(s.partitions),
      oldestDay: str(s.oldestDay), newestDay: str(s.newestDay) };
  };
  const list = <T,>(v: unknown, f: (x: Record<string, unknown>) => T): T[] =>
    Array.isArray(v) ? v.map((x) => f((x ?? {}) as Record<string, unknown>)) : [];
  return {
    tiered: r.tiered === true,
    hotDays: num(r.hotDays) || MIN_HOT_DAYS,
    hotFrom: str(r.hotFrom),
    movingTo: str(r.movingTo),
    tieredFrom: str(r.tieredFrom),
    enabled: r.enabled === true,
    schedule: str(r.schedule) ?? "",
    scheduleValid: r.scheduleValid === true,
    nextMoveAt: str(r.nextMoveAt),
    export: r.export === true,
    exportDir: str(r.exportDir) ?? "",
    purgeKeepDays: num(r.purgeKeepDays),
    purgeCommand: str(r.purgeCommand) ?? "fireflo usage purge",
    configSource: (str(r.configSource) ?? "db").toLowerCase(),
    lastRunAt: str(r.lastRunAt),
    lastMoveAt: str(r.lastMoveAt),
    lastMoveDay: str(r.lastMoveDay),
    lastError: str(r.lastError),
    lastErrorAt: str(r.lastErrorAt),
    hotDefaultRows: num(r.hotDefaultRows),
    refusal: str(r.refusal),
    hot: size(r.hot),
    archive: size(r.archive),
    tables: list(r.tables, (t) => ({ table: String(t.table ?? ""), hot: size(t.hot), archive: size(t.archive),
      hotDefaultRows: num(t.hotDefaultRows) })),
    ready: Array.isArray(r.ready) ? r.ready.map(String) : [],
    waiting: list(r.waiting, (w) => ({ day: String(w.day ?? ""), reason: String(w.reason ?? ""), detail: String(w.detail ?? "") })),
    log: list(r.log, (l) => ({
      runId: str(l.runId), startedAt: str(l.startedAt), finishedAt: str(l.finishedAt), nodeId: str(l.nodeId),
      day: str(l.day), table: String(l.table ?? ""), rowsBefore: numOrNull(l.rowsBefore), rowsAfter: numOrNull(l.rowsAfter),
      ms: num(l.ms), outcome: String(l.outcome ?? ""), reason: str(l.reason), error: str(l.error),
    })),
  };
}
