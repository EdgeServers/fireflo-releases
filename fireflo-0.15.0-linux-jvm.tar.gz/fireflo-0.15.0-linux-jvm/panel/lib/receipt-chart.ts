/**
 * The Receipts page's two charts, from the rows its table already shows.
 *
 * <p>Pure, so the arithmetic is tested without a browser. Shares are of `sent` -- every attempt
 * handed to the vendor -- and split it exactly: delivered, failed (`reported - delivered`), gave up
 * on (`expired`, our sweeper's), still open, and refused (`sent - reported - expired - open`: an
 * attempt the vendor turned away never gets a receipt). The five always add up to the bar.
 */
/** The fields the charts read: the page's own row type and the query's both fit. */
export interface ChartRow {
  vendor: string | null;
  sent: number;
  reported: number;
  expired: number;
  open: number;
  delivered: number;
  medianToOutcome: number | null;
  p90ToOutcome: number | null;
}

/** Vendors drawn one by one; the rest are summed into "Other". */
export const MAX_VENDORS = 8;

export interface OutcomeBar {
  vendor: string;
  sent: number;
  /** Percentages of `sent`, summing to 100 (0 each when nothing was sent). */
  delivered: number;
  failed: number;
  gaveUp: number;
  open: number;
  refused: number;
  /** The counts behind them, for the tooltip. */
  counts: { delivered: number; failed: number; gaveUp: number; open: number; refused: number };
}

export interface TimingBar {
  vendor: string;
  median: number;
  p90: number;
}

function name(vendor: string | null): string {
  return vendor ?? "No vendor";
}

/** The busiest vendors first, the rest folded into one "Other" row. */
function topWithOther(rows: readonly ChartRow[]): { vendor: string; rows: ChartRow[] }[] {
  const sorted = [...rows].sort((a, b) => b.sent - a.sent);
  const shown = sorted.length > MAX_VENDORS ? sorted.slice(0, MAX_VENDORS - 1) : sorted;
  const rest = sorted.slice(shown.length);
  return [
    ...shown.map((r) => ({ vendor: name(r.vendor), rows: [r] })),
    ...(rest.length ? [{ vendor: `Other (${rest.length})`, rows: rest }] : []),
  ];
}

export function outcomeBars(rows: readonly ChartRow[]): OutcomeBar[] {
  return topWithOther(rows).map(({ vendor, rows: group }) => {
    const sum = (f: (r: ChartRow) => number) => group.reduce((n, r) => n + f(r), 0);
    const sent = sum((r) => r.sent);
    const counts = {
      delivered: sum((r) => r.delivered),
      failed: sum((r) => Math.max(0, r.reported - r.delivered)),
      gaveUp: sum((r) => r.expired),
      open: sum((r) => r.open),
      refused: sum((r) => Math.max(0, r.sent - r.reported - r.expired - r.open)),
    };
    const pct = (n: number) => (sent > 0 ? (n / sent) * 100 : 0);
    return {
      vendor,
      sent,
      delivered: pct(counts.delivered),
      failed: pct(counts.failed),
      gaveUp: pct(counts.gaveUp),
      open: pct(counts.open),
      refused: pct(counts.refused),
      counts,
    };
  });
}

/**
 * Median and 90th-percentile seconds to an outcome, for the vendors that have any. "Other" is left
 * out: a median of medians is not a median, and the table has each vendor's own.
 */
export function timingBars(rows: readonly ChartRow[]): TimingBar[] {
  return [...rows]
    .sort((a, b) => b.sent - a.sent)
    .slice(0, MAX_VENDORS)
    .filter((r) => r.medianToOutcome !== null && r.p90ToOutcome !== null)
    .map((r) => ({ vendor: name(r.vendor), median: r.medianToOutcome!, p90: r.p90ToOutcome! }));
}
