import { strict as assert } from "node:assert";
import { test } from "node:test";
import {
  bindTotal, sampleNote, sessionsAreComplete, shareOf, summariseBinds,
} from "./bind-summary.ts";
import type { HealthSession } from "./health-types.ts";

function session(over: Partial<HealthSession> = {}): HealthSession {
  return { bound: true, bind_type: "TRANSCEIVER", ...over };
}

test("a vendor's binds are described by kind, placement and age", () => {
  const summary = summariseBinds(
    [
      session({ bound_seconds: 300_000 }),
      session({ bound_seconds: 200 }),
      session({ bind_type: "RECEIVER", role: "BACKUP", bound_seconds: 60 }),
    ],
    true
  );
  assert.match(summary, /2 transceivers/);
  assert.match(summary, /1 receive-only/);
  assert.match(summary, /1 on a backup host/);
  assert.match(summary, /oldest up 3d/);
});

test("a listener's binds are described by customer, not by kind", () => {
  const summary = summariseBinds(
    [
      session({ account: "acme", submitted: 900 }),
      session({ account: "acme", submitted: 40 }),
      session({ account: "globex", submitted: 10 }),
    ],
    false
  );
  assert.match(summary, /2 accounts/);
  assert.match(summary, /3 binds/);
  assert.match(summary, /busiest is acme/);
  //the vendor vocabulary must not leak across: a customer bind is not "a transceiver"
  assert.doesNotMatch(summary, /transceiver/);
});

test("a session the gateway holds but has not bound is left out of the counts", () => {
  const summary = summariseBinds(
    [session(), session({ bound: false }), session({ bound: false })],
    true
  );
  assert.match(summary, /1 transceiver\b/);
});

test("NORMAL is not reported as a backup, and a missing role is not either", () => {
  const summary = summariseBinds(
    [session({ role: "NORMAL" }), session({ role: undefined })],
    true
  );
  assert.doesNotMatch(summary, /backup/);
});

test("one bind carrying most of the traffic is called out; an even spread is not", () => {
  const lopsided = summariseBinds(
    [
      session({ submitted: 9_000 }),
      session({ submitted: 40 }),
      session({ submitted: 10 }),
    ],
    true
  );
  assert.match(lopsided, /one bind carrying most of it/);

  const even = summariseBinds(
    [session({ submitted: 100 }), session({ submitted: 110 }), session({ submitted: 95 })],
    true
  );
  assert.match(even, /evenly loaded/);
});

test("load shape stays silent when there is nothing to shape", () => {
  //all zero is not "evenly loaded" in any useful sense, and two sessions cannot be lopsided
  assert.doesNotMatch(
    summariseBinds([session({ submitted: 0 }), session({ submitted: 0 })], true),
    /loaded|carrying/
  );
  assert.doesNotMatch(
    summariseBinds([session({ submitted: 500 })], true),
    /loaded|carrying/
  );
});

test("a session that is not counting does not drag the share to zero", () => {
  //`submitted` is null when counters are switched off, which is not the same as having sent nothing
  assert.equal(shareOf(null, 100), null);
  assert.equal(shareOf(undefined, 100), null);
  assert.equal(shareOf(0, 100), 0);
  assert.equal(shareOf(50, 100), 0.5);
});

test("a share of nothing is null rather than a division by zero", () => {
  assert.equal(shareOf(0, 0), null);
  assert.equal(shareOf(10, 0), null);
});

test("shares over the bind total sum to one", () => {
  const sessions = [
    session({ submitted: 30 }),
    session({ submitted: 50 }),
    session({ submitted: 20 }),
  ];
  const total = bindTotal(sessions);
  assert.equal(total, 100);
  const sum = sessions.reduce((n, s) => n + (shareOf(s.submitted, total) ?? 0), 0);
  assert.equal(Math.round(sum * 1000) / 1000, 1);
});

test("the snapshot array is the whole set only when the count agrees", () => {
  assert.equal(sessionsAreComplete(5, 5), true);
  assert.equal(sessionsAreComplete(400, 20), false);
  //an older gateway that does not report sessions_total: the array was the count back then
  assert.equal(sessionsAreComplete(null, 5), true);
  assert.equal(sessionsAreComplete(undefined, 5), true);
});

test("the sample note is silent when nothing was truncated", () => {
  assert.equal(sampleNote(5, 5), "");
  assert.equal(sampleNote(400, 20), "20 of 400 shown");
});
