import { CDR_STORAGE_VIEW, hasCapability } from "./capabilities.ts";
import type { GqlFailure, GqlOutcome } from "./gateway-graphql-core.ts";
import { CDR_STORAGE, HEALTH } from "./gateway-queries.ts";
import { flattenHealth, type HealthField } from "./health-types.ts";
import { CDR_TIERS_RELEASE, normaliseCdrStorage, type CdrStorage } from "./cdr-storage.ts";

/**
 * What `GET /api/control/archives/cdr-storage` does, with the gateway call passed in so it can be
 * tested without one.
 *
 * <p>The capability map first, as the Kafka route does: a gateway older than 0.15 rejects
 * `cdrStorage` by name, so it is asked only of one that declares `cdr_storage`. Without it the
 * answer is `{ data: null, unsupported: true }` and the page says the tiers arrive with 0.15 rather
 * than showing an error.
 */

/** The gateway call: `executeGql` in the route. */
export type GqlExecutor = <T>(call: { query: string; variables?: Record<string, unknown>; timeoutMs?: number }) => Promise<GqlOutcome<T>>;

/** The most log rows a page asks for. */
export const MAX_LOG = 500;

export type CdrStorageRead =
  | { ok: true; body: { data: CdrStorage & { configWritable: boolean } } | { data: null; unsupported: true; release: string } }
  | { ok: false; failure: GqlFailure };

export async function readCdrStorage(
  exec: GqlExecutor,
  o: { first?: number; failuresOnly?: boolean; configWritable: boolean }
): Promise<CdrStorageRead> {
  const health = await exec<HealthField>({ query: HEALTH, timeoutMs: 5_000 });
  if (!health.ok) {
    return { ok: false, failure: health };
  }
  if (!hasCapability(flattenHealth(health.data), CDR_STORAGE_VIEW)) {
    return { ok: true, body: { data: null, unsupported: true, release: CDR_TIERS_RELEASE } };
  }
  const first = Math.min(Math.max(1, Math.trunc(o.first ?? 50) || 50), MAX_LOG);
  //executeGql hands back the root field's value: the CdrStorage itself
  const read = await exec<unknown>({
    query: CDR_STORAGE,
    variables: { first, failuresOnly: o.failuresOnly === true },
    //catalogue reads and a short log: a gateway that has not answered in ten seconds is stuck
    timeoutMs: 10_000,
  });
  if (!read.ok) {
    return { ok: false, failure: read };
  }
  return { ok: true, body: { data: { ...normaliseCdrStorage(read.data), configWritable: o.configWritable } } };
}
