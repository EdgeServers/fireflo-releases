import { test } from "node:test";
import assert from "node:assert/strict";
import { bucketOf, hourUtc, usageHourlySql } from "./usage-summary-sql.ts";

test("the last hour is cut in UTC five-minute buckets and read wholly from the records", () => {
  assert.match(bucketOf("5min", "s.submitted_at"), /date_bin\('5 minutes', s\.submitted_at, timestamptz '2000-01-01 00:00:00\+00'\)/);
  assert.equal(bucketOf("hour", "x"), hourUtc("x"));
  //no hourly row can be split into five minutes: the seam is the window's start, so the rolled half
  //is empty and the whole hour is the live tail
  const sql = usageHourlySql({ bucket: "5min", account: false, vendorAttempt: true });
  assert.match(sql, /w\.since AS seam/);
  assert.match(sql, /date_bin\('5 minutes'/);
  //the hourly window keeps its watermark seam
  assert.match(usageHourlySql({ bucket: "hour", account: false, vendorAttempt: true }), /LEAST\(w\.hwm/);
});

test("the hourly path never reads the summary before its first row", () => {
  //a summary younger than the window counted the hours before it as empty, so 7 and 30 days
  //under-reported Revenue and Usage until someone ran the backfill
  const sql = usageHourlySql({ bucket: "day", account: false, vendorAttempt: true });
  assert.match(sql, /GREATEST\([\s\S]*SELECT min\(uh\.hour\) FROM usage_hourly uh\)\) AS first_hour/);
});
