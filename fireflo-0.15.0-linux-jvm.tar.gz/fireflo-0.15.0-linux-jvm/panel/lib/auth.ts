import { checkClaim } from "@/lib/auth-proof";
import { readPending, secondStepLockKeys, signPending, spendPending, TOTP_CODE_PREFIX } from "@/lib/totp-pending";
import { attemptCode, hasTotpColumns, liveOperator } from "@/lib/totp-store";
import { constantTimeEquals } from "@/lib/constant-time";
import { lockoutKey } from "@/lib/signin-lockout";
import { operatorLockout } from "@/lib/operator-lockout";
import NextAuth, { CredentialsSignin } from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { logAuthFailure, logOperatorEvent } from "@/lib/access-log";
import { isConfigWritable } from "@/lib/config-db";
import { burnVerifyTime, verifyPassword } from "@/lib/password-hash";
import { currentRequestContext, markRequestHandled } from "@/lib/request-context";
import { ADMIN_ROLE, OPERATOR_ROLE } from "@/lib/roles";
import { redeemLoginToken } from "@/lib/login-token";
import { findLoginUser, getUserById, panelUsersExist, touchLastLogin } from "@/lib/users";
import { normaliseEmail } from "@/lib/user-types";

declare module "next-auth" {
  /**
   * Shared by both NextAuth instances. The widening is type-only: which fields a session actually
   * carries is decided by the instance that minted it, and each stamps only its own.
   */
  interface Session {
    user: {
      name?: string | null;
      email?: string | null;
      image?: string | null;
      /** `admin` or `operator` from `lib/auth.ts`; `customer` from `lib/mis-auth.ts`. Never both. */
      role?: string | null;
      /** The `app_user.id` as a string. Null for the deprecated env-fallback operator. */
      userId?: string | null;
      /** Only the portal instance sets this. */
      accountId?: string | null;
      /**
       * `app_user.password_changed_at` as it stood at sign-in, in epoch milliseconds, or null. Both
       * instances stamp it; `requireOperator` and `requireCustomer` compare it against the row on
       * every request -- see lib/session-freshness.ts.
       */
      passwordChangedAt?: number | null;
      /**
       * Sent only to `unstable_update`, never carried in a session: the server's proof that
       * `passwordChangedAt` is the caller's new stamp (lib/auth-proof.ts).
       */
      pwdProof?: string | null;
      /**
       * The operator's `totp_enabled_at` (epoch ms) when this session was verified with a code from
       * that authenticator, else null. `requireOperator` refuses a session whose user has an
       * authenticator and whose stamp does not match it -- see lib/totp-store.ts.
       */
      mfaAt?: number | null;
      /** Sent only to `unstable_update` with a new `mfaAt`: the server's proof (lib/auth-proof.ts). */
      mfaProof?: string | null;
      /**
       * `app_user.totp_changed_at` (epoch ms) as it stood when this session was made or last
       * re-minted by its own two-factor change. A session made before the latest change -- two-factor
       * turned on, off or reset since -- is refused (lib/totp-gate.ts).
       */
      tcAt?: number | null;
      /** Sent only to `unstable_update` with a new `tcAt`: the server's proof. */
      tcProof?: string | null;
    };
  }
}

/** The claims this instance adds to the token. */
interface OperatorToken {
  role?: string;
  userId?: string | null;
  pwdAt?: number | null;
  mfaAt?: number | null;
  tcAt?: number | null;
}

/** What `authorize` hands the jwt callback, beyond next-auth's own fields. */
interface SignedInUser {
  id?: string;
  role?: string;
  passwordChangedAt?: number | null;
  mfaAt?: number | null;
  totpChangedAt?: number | null;
}

/**
 * What a right password (or link) answers for an operator with an authenticator: not a session but
 * a refusal whose `code` carries the second-step token (lib/totp-pending.ts) to the sign-in form,
 * which sends it back with the code to the `operator-totp` provider. next-auth puts `code` in the
 * sign-in response's URL, never in a log line.
 */
class TotpCodeNeeded extends CredentialsSignin {
  constructor(token: string) {
    super("an authenticator code is needed");
    this.code = TOTP_CODE_PREFIX + token;
  }
}

/** The second step's token has lapsed, been spent, or was never ours: back to the first step. */
class TotpStepExpired extends CredentialsSignin {
  code = "totp_expired";
}

/**
 * The first step passed: a session, or -- when this operator has an authenticator -- the second-step
 * token instead. On a gateway before V1.114.0 there are no such columns, and nothing changes.
 *
 * @returns the row's `totp_changed_at` stamp, for the session (null on an older gateway); throws the
 *     second step when one is due. A probe that fails throws as well: never a session on a guess
 */
async function secondStepFor(
  userId: number,
  pwdAt: number | null,
  via: "password" | "link",
  lockKey: string | null = null
): Promise<number | null> {
  if (!(await hasTotpColumns())) {
    return null;
  }
  const live = await liveOperator(userId);
  if (!live || live.totpStamp === null) {
    return live?.totpChanged ?? null;
  }
  //the request is accounted for: the second step is not a refusal before authorize, which is what the
  //route's net would otherwise log it as
  markRequestHandled();
  const token = signPending({ userId, pwdAt, via, lockKey });
  if (!token) {
    //no AUTH_SECRET to sign with: next-auth cannot sign a session either, so this is never reached
    //in a working panel. Refused rather than let the first step stand alone
    throw new CredentialsSignin("AUTH_SECRET is not set");
  }
  throw new TotpCodeNeeded(token);
}

const DEFAULT_USERNAME = "operator";

/** Failed operator sign-ins and codes, counted apart from the portal's -- see lib/operator-lockout.ts. */
const lockout = operatorLockout;

/**
 * `AUTH_URL` must be a bare origin, and saying so early is cheaper than the failure.
 *
 * <p>next-auth does `config.basePath || (config.basePath = pathname)`. A value with a path —
 * `https://panel.example.com/panel` — therefore silently moves this instance's endpoints to
 * `/panel`, and every call to `/api/auth/*` answers "Bad request" with nothing pointing at the
 * cause. The customer instance escapes this only because it sets `basePath` explicitly.
 *
 * <p>Warned, not thrown: a hard failure at module load takes the entire panel down over a trailing
 * slash somebody typed into an environment file, which is a worse outcome than a broken redirect.
 */
function warnIfAuthUrlHasPath(): void {
  const raw = process.env.AUTH_URL?.trim();
  if (!raw) {
    return;
  }
  try {
    const parsed = new URL(raw);
    if (parsed.pathname !== "/" && parsed.pathname !== "") {
      console.error(
        `AUTH_URL is "${raw}", which has a path. next-auth adopts that path as its basePath, so `
          + "every /api/auth call will fail. Set it to the bare origin: "
          + `${parsed.protocol}//${parsed.host}`
      );
    }
  } catch {
    console.error(`AUTH_URL is "${raw}", which is not a URL. Sign-out will redirect to the port this process bound.`);
  }
}

warnIfAuthUrlHasPath();

/**
 * Operator sign-in.
 *
 * <p>This is deliberately NOT a gateway messaging credential. The data behind this panel includes
 * margin and the names of the vendors traffic is bought from; the gateway's own credentials
 * belong to customers, and it has no notion of an admin role. An operator is a different kind of
 * identity, so it gets a different authenticator.
 *
 * <h2>Where the password lives now</h2>
 *
 * <p>In `app_user`, as a hash the gateway's `fireflo user` command and this module both read
 * (`lib/password-hash.ts`). The lookup is {@link findLoginUser} with the `"operator"` surface, whose
 * WHERE clause admits only rows with no account and a panel role — so a customer row can never sign
 * in here whatever its password, and this instance can stamp only {@link ADMIN_ROLE} or
 * {@link OPERATOR_ROLE}.
 *
 * <h2>The env fallback, for one release</h2>
 *
 * <p>Until this release the whole operator account was `OPERATOR_USERNAME` and `OPERATOR_PASSWORD`
 * in `panel.env`. The installer's `update` moves that into an admin row and removes the variables,
 * but a panel upgraded before its gateway ran V1.52.0 has no table yet, and a panel whose installer
 * step failed has an empty one. So: when no admin or operator row exists at all and
 * `OPERATOR_PASSWORD` is set, the old comparison still runs (both halves through
 * `lib/constant-time.ts`, hashed to one width so neither the match nor the length leaks), is logged
 * as `env_fallback`, and warns in the journal once per process. The moment one panel user exists the
 * variables are ignored -- and `requireOperator` re-asks both questions on every request, so a
 * session signed in this way dies with the first real admin row. Remove the whole branch in 0.13.
 *
 * <p>With neither a user row nor `OPERATOR_PASSWORD` there is no way in at all — not "any password
 * works", not "no password required". Missing configuration fails closed.
 */
let warnedEnvFallback = false;

export const { handlers, auth, signIn, signOut, unstable_update: updateSession } = NextAuth({
  providers: [
    Credentials({
      id: "operator",
      name: "Operator",
      credentials: {
        username: { label: "Email", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        //the IP arrives through an async context because this function is handed credentials and
        //nothing else. See lib/request-context.ts for why that beats reading the response.
        const context = currentRequestContext();
        const ip = context?.ip ?? null;
        const record = (
          event: "signin" | "signin_failed",
          actor: string | null,
          userId: number | null,
          reason?: string
        ) => {
          markRequestHandled();
          void logOperatorEvent({
            event,
            actor,
            userId,
            ip,
            userAgent: context?.userAgent ?? null,
            detail: reason ? { reason } : undefined,
          });
          //also to the file fail2ban watches. The operator log stays what it is -- an audit trail
          //of what an operator did, where a success sits beside a failure -- and only the dedicated
          //one is jailed, so a refusal is recorded twice and counted once
          if (event === "signin_failed") {
            void logAuthFailure({ surface: "panel", reason: reason ?? "bad_credentials", triedAs: actor, ip });
          }
        };

        const typed = (credentials?.username as string | undefined)?.trim() ?? "";
        const password = (credentials?.password as string | undefined) ?? "";
        const email = normaliseEmail(typed || DEFAULT_USERNAME) ?? typed;
        const lockKey = lockoutKey(ip, email);

        //checked and counted BEFORE the first await, and given back only by a sign-in that completes:
        //checked first and counted after the password derivation, a burst of parallel guesses all
        //passed the check before any had been counted -- see tryAttempt
        if (!lockout.tryAttempt(lockKey)) {
          record("signin_failed", typed || null, null, "rate_limited");
          return null;
        }

        if (isConfigWritable() && (await panelUsersExist())) {
          const user = await findLoginUser(email, "operator");
          //the derivation runs whether or not a row was found, so an unknown address costs the same
          //third of a second a known one does -- see burnVerifyTime
          const ok = user?.passwordHash
            ? await verifyPassword(password, user.passwordHash)
            : (await burnVerifyTime(password), false);
          if (!user || !ok) {
            //what was TYPED is recorded, not the normalised address, so the log shows the attacker's
            //string; the reason is not broken down, because a log that said which half matched
            //would hand back through disk exactly what the constant-time compare refuses to leak
            record("signin_failed", typed || null, null, "bad_credentials");
            return null;
          }
          //an operator with an authenticator gets the second step here, not a session. The lockout is
          //NOT cleared: the password was right, but whoever typed it has not finished, and clearing it
          //would hand anyone holding the password a fresh set of code guesses with every sign-in
          //the password step's counted attempt rides in the token, given back when the code completes
          const totpChangedAt = await secondStepFor(user.id, user.passwordChangedAt, "password", lockKey);
          lockout.clear(lockKey);
          void touchLastLogin(user.id);
          record("signin", user.email, user.id);
          return {
            id: String(user.id), name: user.email, email: user.email, role: user.role,
            passwordChangedAt: user.passwordChangedAt, totpChangedAt,
          };
        }

        //---- env fallback: no panel user exists yet (or no table) ----
        const expectedPassword = process.env.OPERATOR_PASSWORD;
        if (!expectedPassword) {
          console.error(
            "No admin or operator user exists and OPERATOR_PASSWORD is not set; operator sign-in is "
              + "disabled. Create one with: fireflo user add --email you@example.com --role admin --generate"
          );
          record("signin_failed", null, null, "not_configured");
          return null;
        }
        const expectedUsername = normaliseEmail(process.env.OPERATOR_USERNAME?.trim() || DEFAULT_USERNAME)!;

        //both compared in constant time, and both must pass -- returning early on a username
        //mismatch would leak which half was wrong through timing
        const userOk = constantTimeEquals(email.toLowerCase(), expectedUsername.toLowerCase());
        const passOk = constantTimeEquals(password, expectedPassword);
        if (!userOk || !passOk) {
          record("signin_failed", typed || null, null, "bad_credentials");
          return null;
        }
        lockout.clear(lockKey);

        //once per process, not once per sign-in: a WARN that repeats on every login is one the
        //journal stops showing anybody. The access log still records env_fallback every time
        if (!warnedEnvFallback) {
          warnedEnvFallback = true;
          console.warn(
            "DEPRECATED: an operator signed in with OPERATOR_PASSWORD from panel.env. This fallback is removed in "
              + "0.13: run 'fireflo-panel-install update' to move the account into app_user before upgrading."
          );
        }
        record("signin", expectedUsername, null, "env_fallback");
        return { id: "env", name: expectedUsername, email: expectedUsername, role: ADMIN_ROLE };
      },
    }),

    /**
     * The one-time link, for operators and admins.
     *
     * <p>A second provider on THIS instance, not a use of the portal's: the redeem names the door in
     * its SQL, so a customer's token is not found here and an operator's is not found there, and
     * the session this mints carries only the roles this instance may stamp. The link is also how
     * a new operator sets their first password, and how a forgotten one is replaced.
     */
    Credentials({
      id: "magic-link",
      name: "Sign-in link",
      credentials: { token: { label: "Token", type: "text" } },
      async authorize(credentials) {
        const token = credentials?.token;
        if (typeof token !== "string") {
          return null;
        }
        const context = currentRequestContext();
        const ip = context?.ip ?? null;
        const userAgent = context?.userAgent ?? null;
        markRequestHandled();

        if (!isConfigWritable()) {
          return null;
        }
        //spends the token. Unknown, expired, already used, or issued for the portal: one null,
        //because telling them apart would tell an attacker which of their guesses was close
        const redeemed = await redeemLoginToken(token, "operator");
        if (!redeemed) {
          void logOperatorEvent({ event: "link_rejected", actor: null, userId: null, ip, userAgent });
          void logAuthFailure({ surface: "panel", reason: "link_rejected", triedAs: null, ip });
          return null;
        }
        //the link is spent either way; with an authenticator it buys the second step, not a session
        void logOperatorEvent({ event: "link_redeemed", actor: redeemed.email, userId: redeemed.userId, ip, userAgent });
        const totpChangedAt = await secondStepFor(redeemed.userId, redeemed.passwordChangedAt, "link");
        void touchLastLogin(redeemed.userId);
        return {
          totpChangedAt,
          id: String(redeemed.userId),
          name: redeemed.email,
          email: redeemed.email,
          role: redeemed.role,
          passwordChangedAt: redeemed.passwordChangedAt,
        };
      },
    }),

    /**
     * The second step: the token the first step answered with, and a code from the authenticator.
     *
     * <p>A wrong code counts against the same lockout as a wrong password, under the same key
     * (origin and address), and is written to both logs; the token stays good for the rest of its
     * five minutes, so a typo costs a retry, not the password again. A right code spends the token
     * and the code's step, and the session carries the authenticator's stamp (`mfaAt`). The user is
     * read afresh: disabled, demoted, password changed or authenticator reset since the first step,
     * and the token is worthless.
     */
    Credentials({
      id: "operator-totp",
      name: "Authenticator code",
      credentials: { pendingToken: { label: "Pending", type: "text" }, code: { label: "Code", type: "text" } },
      async authorize(credentials) {
        const context = currentRequestContext();
        const ip = context?.ip ?? null;
        const userAgent = context?.userAgent ?? null;
        markRequestHandled();
        if (!isConfigWritable()) {
          return null;
        }
        const pending = readPending(credentials?.pendingToken);
        if (!pending) {
          throw new TotpStepExpired();
        }
        //the in-memory first line, checked and counted before the first await so a burst cannot all
        //pass it; keyed by origin and user, as the token names no address. The binding limit is the
        //per-user counter in the database (attemptCode), which no burst, restart or second panel
        //instance gets round
        //the email is not known before the first await; the keys it adds are only ever released
        const { counted: lockKey } = secondStepLockKeys(pending, ip, "");
        if (!lockout.tryAttempt(lockKey)) {
          void logOperatorEvent({ event: "signin_failed", actor: null, userId: pending.userId, ip, userAgent, detail: { reason: "rate_limited" } });
          void logAuthFailure({ surface: "panel", reason: "rate_limited", triedAs: null, ip });
          return null;
        }

        const user = await getUserById(pending.userId);
        if (!user || !user.enabled || user.accountId !== null || (user.role !== ADMIN_ROLE && user.role !== OPERATOR_ROLE)) {
          throw new TotpStepExpired();
        }
        const login = await findLoginUser(user.email, "operator");
        if (!login || login.id !== user.id || login.passwordChangedAt !== pending.pwdAt) {
          throw new TotpStepExpired();
        }
        const code = typeof credentials?.code === "string" ? credentials.code : "";
        let attempt: Awaited<ReturnType<typeof attemptCode>>;
        try {
          attempt = await attemptCode(user.id, code, "signin");
        } catch (err) {
          //a sealed secret and no FIREFLO_SECRETS_KEY on this panel: nobody can be verified, and the
          //journal has to say why. Nothing was counted against the user
          console.error("operator two-factor: the authenticator secret could not be read", err);
          return null;
        }
        if (attempt.outcome !== "ok") {
          const locked = attempt.outcome === "locked";
          void logOperatorEvent({
            event: "totp_failed", actor: user.email, userId: user.id, ip, userAgent,
            detail: { via: pending.via, ...(locked ? { reason: "locked" } : {}) },
          });
          void logAuthFailure({ surface: "panel", reason: locked ? "totp_locked" : "totp_failed", triedAs: user.email, ip });
          if (attempt.outcome === "wrong" && attempt.lockedUntil) {
            void logOperatorEvent({
              event: "totp_locked", actor: user.email, userId: user.id, ip, userAgent,
              detail: { failures: attempt.failures, until: attempt.lockedUntil.toISOString() },
            });
          }
          return null;
        }
        spendPending(pending);
        //a completed sign-in gives back every attempt it counted, the password step's included:
        //otherwise ten good sign-ins with a code in a quarter of an hour locked the operator out
        for (const key of secondStepLockKeys(pending, ip, user.email).release) {
          lockout.clear(key);
        }
        void touchLastLogin(user.id);
        void logOperatorEvent({ event: "signin", actor: user.email, userId: user.id, ip, userAgent, detail: { mfa: true, via: pending.via } });
        return {
          id: String(user.id),
          name: user.email,
          email: user.email,
          role: user.role,
          passwordChangedAt: login.passwordChangedAt,
          mfaAt: attempt.stamp,
          totpChangedAt: attempt.changed,
        };
      },
    }),
  ],

  pages: { signIn: "/cp/login" },
  trustHost: true,
  session: { strategy: "jwt" },

  callbacks: {
    //the role is stamped at sign-in and carried in the JWT rather than recomputed. Only this
    //provider can put it there, and this provider only authorises admins and operators; whether
    //the person is STILL one is re-read from the row on every request by requireOperator
    jwt({ token, user, trigger, session }) {
      const t = token as OperatorToken;
      if (user) {
        const u = user as SignedInUser;
        t.role = u.role === ADMIN_ROLE ? ADMIN_ROLE : OPERATOR_ROLE;
        //cast rather than a `next-auth/jwt` module augmentation: v5 does not publish that subpath,
        //so augmenting it is a type error rather than a declaration
        t.userId = u.id && u.id !== "env" ? u.id : null;
        //the row's password_changed_at at sign-in. Compared against the row on every request, so a
        //reset signs this session out -- see lib/session-freshness.ts
        t.pwdAt = u.passwordChangedAt ?? null;
        //verified with an authenticator code at this stamp, or not at all
        t.mfaAt = typeof u.mfaAt === "number" ? u.mfaAt : null;
        //two-factor's last change as this session was made under it
        t.tcAt = typeof u.totpChangedAt === "number" ? u.totpChangedAt : null;
      }
      //the one claim a signed-in session may refresh: /api/control/me/password calls unstable_update
      //after changing the caller's OWN password, so the session that made the change survives while
      //every other one is refused. Nothing else about the token can be changed this way.
      //
      //Only with the server's proof (lib/auth-proof.ts). next-auth hands this callback whatever ANY
      //cookie holder posts to /api/auth/session, so a bare number here let a session stolen before a
      //password reset stamp itself as newer than the reset and survive it
      if (trigger === "update") {
        const u = (session as { user?: { passwordChangedAt?: unknown; pwdProof?: unknown } } | undefined)?.user;
        const fresh = u?.passwordChangedAt;
        if (typeof fresh === "number" && Number.isFinite(fresh) && t.userId
            && checkClaim("pwd", t.userId, fresh, u?.pwdProof)) {
          t.pwdAt = fresh;
        }
        //the operator who has just set up an authenticator keeps this session, verified with it: the
        //enrolment route proves the stamp, as the password route proves its own
        const claims = (session as { user?: { mfaAt?: unknown; mfaProof?: unknown; tcAt?: unknown; tcProof?: unknown } } | undefined)?.user;
        //null is a value here: a disable leaves no authenticator to have been verified with
        if ((claims?.mfaAt === null || (typeof claims?.mfaAt === "number" && Number.isFinite(claims.mfaAt))) && t.userId
            && checkClaim("mfa", t.userId, claims.mfaAt as number | null, claims.mfaProof)) {
          t.mfaAt = claims.mfaAt as number | null;
        }
        //and the change it was re-minted at, after the operator's own enrol or disable
        if (typeof claims?.tcAt === "number" && Number.isFinite(claims.tcAt) && t.userId
            && checkClaim("tc", t.userId, claims.tcAt, claims.tcProof)) {
          t.tcAt = claims.tcAt;
        }
      }
      return token;
    },
    session({ session, token }) {
      const t = token as OperatorToken;
      session.user.role = t.role ?? null;
      session.user.userId = t.userId ?? null;
      session.user.passwordChangedAt = t.pwdAt ?? null;
      session.user.mfaAt = t.mfaAt ?? null;
      session.user.tcAt = t.tcAt ?? null;
      return session;
    },
    authorized({ auth: session }) {
      return session?.user?.role === OPERATOR_ROLE || session?.user?.role === ADMIN_ROLE;
    },
  },

  // no maxAge: the session dies with the browser
  cookies: {
    sessionToken: {
      name: "fireflo-control.session-token",
      options: {
        httpOnly: true,
        sameSite: "lax" as const,
        path: "/",
        //AUTH_COOKIE_SECURE overrides the NODE_ENV guess, and without it a panel served over
        //plain HTTP cannot hold a session at all. `secure` tells the browser to send the cookie
        //only over TLS, so on http:// it is accepted from the server and then silently dropped --
        //sign-in succeeds, the redirect follows, and the next request arrives with no session, so
        //the operator lands back on the login page with nothing anywhere saying why. The server
        //logs a successful signin; the browser shows a failed one.
        //
        //NODE_ENV alone cannot answer this. It says "this is a production build", which is true of
        //every installed panel including the ones reached over http on a private network, and it
        //is not a statement about the scheme. So the deployment states the scheme and the build
        //mode stays the fallback for anyone who has not.
        //
        //Found on an install that had been hand-patched to this exact expression, with
        //AUTH_COOKIE_SECURE already in its panel.env -- the workaround existed and had never
        //reached the repository, so every fresh HTTP install rediscovered the same dead end.
        secure: process.env.AUTH_COOKIE_SECURE
          ? process.env.AUTH_COOKIE_SECURE === "true"
          : process.env.NODE_ENV === "production",
      },
    },
  },
});
