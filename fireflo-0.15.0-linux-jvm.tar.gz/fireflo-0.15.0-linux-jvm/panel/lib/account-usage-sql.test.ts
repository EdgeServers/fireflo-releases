import { strict as assert } from "node:assert";
import { test } from "node:test";

import { accountUsageSql } from "./usage-summary-sql.ts";

const base = { vendorAttempt: true };

test("a day range with a moving watermark reads the hourly summary, records only past it", () => {
  //the daily path read every record from usage_daily's last line on: on production, a week of them
  const sql = accountUsageSql({ ...base, source: "hourly", logins: false, scoped: false });
  assert.match(sql, /FROM cut, usage_hourly h/);
  assert.doesNotMatch(sql, /usage_daily/);
});

test("without a usable summary the day range stays on the daily path", () => {
  const sql = accountUsageSql({ ...base, source: "live", logins: false, scoped: false });
  assert.match(sql, /FROM cut, usage_daily u/);
  assert.doesNotMatch(sql, /usage_hourly/);
});

test("the 24 hours from the hourly summary keeps its logins when the summary has them (V1.113.0)", () => {
  const sql = accountUsageSql({ ...base, source: "hourly", logins: true, scoped: false, hourlyLogin: true });
  assert.match(sql, /FROM cut, usage_hourly h/);
  //the rolled rows by their login, '' (an hour rolled before the column) as none
  assert.match(sql, /NULLIF\(h\.system_id, ''\) AS system_id/);
  //the raw edges by the records' own
  assert.match(sql, /s\.system_id\s+AS system_id/);
});

test("against a gateway before V1.113.0 the hourly 24 hours has no login, and never names the column", () => {
  const sql = accountUsageSql({ ...base, source: "hourly", logins: true, scoped: false });
  assert.match(sql, /FROM cut, usage_hourly h/);
  assert.doesNotMatch(sql, /h\.system_id/);
  assert.doesNotMatch(sql, /s\.system_id\s+AS system_id/, "the edges fold their logins too, or one login would sit beside a no-login row");
});

test("read from the records, the 24 hours keeps its logins", () => {
  const sql = accountUsageSql({ ...base, source: "live", logins: true, scoped: false });
  assert.doesNotMatch(sql, /usage_hourly/);
  assert.match(sql, /s\.system_id\s+AS system_id/);
});

test("one account's page binds the account on every half", () => {
  for (const source of ["hourly", "live"] as const) {
    for (const logins of [true, false]) {
      const sql = accountUsageSql({ ...base, source, logins, scoped: true });
      const where = sql.match(/s\.account_id = \$4/g) ?? [];
      assert.ok(where.length >= 1, `${source}/${logins}: the records are filtered to the account`);
      if (!logins) {
        assert.match(sql, /[hu]\.account_id = \$4/, `${source}: the summary rows are filtered to the account`);
      }
    }
  }
});

test("the whole deployment binds no account", () => {
  const sql = accountUsageSql({ ...base, source: "hourly", logins: false, scoped: false });
  assert.doesNotMatch(sql, /\$4/);
});
