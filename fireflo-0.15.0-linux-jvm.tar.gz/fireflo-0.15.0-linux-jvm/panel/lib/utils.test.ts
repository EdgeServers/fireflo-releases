import { strict as assert } from "node:assert";
import { test } from "node:test";
import { cn } from "./utils.ts";

test("a role size survives a colour beside it", () => {
  //tailwind-merge reads an unknown text-* as a colour; without the extension this dropped the size
  assert.equal(cn("text-title", "text-muted-foreground"), "text-title text-muted-foreground");
  assert.equal(cn("text-figure tabular-nums", "text-destructive"), "text-figure tabular-nums text-destructive");
});

test("a later size replaces an earlier one, role or stock", () => {
  assert.equal(cn("text-page", "text-entity"), "text-entity");
  assert.equal(cn("text-sm", "text-section"), "text-section");
  assert.equal(cn("text-title", "text-xs"), "text-xs");
});
