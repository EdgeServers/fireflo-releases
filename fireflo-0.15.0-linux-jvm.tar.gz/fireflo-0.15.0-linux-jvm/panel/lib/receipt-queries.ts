import { cdrQuery } from "@/lib/cdr-tier";
import { hasInterimTable, hasUsageHourlyAttempts, hasVendorAttempt, hourlyWatermark } from "@/lib/metrics-schema";
import { resolveRange, type Range } from "@/lib/metrics-queries";
import { deadlineHours } from "@/lib/overview-refresher";
import { receiptCountsHourlySql, receiptTimingsSql, sampleDivisor } from "./receipt-sql.ts";

/**
 * How well each vendor reports on the traffic it carries.
 *
 * <p>Separate from `metrics-queries.ts` because it asks a different question about the same rows.
 * Those aggregates ask **what happened** — delivered, failed, what it cost. This asks **whether we
 * were told, and how quickly**, which is a property of the vendor rather than of the traffic and is
 * the one an operator argues with a carrier about.
 *
 * <p>The distinction that makes it worth a module: a vendor with a 95% delivery rate over the
 * messages it reported and a 40% reporting rate is not a good vendor. The first number is computed
 * over a denominator the vendor itself chose, and until now it was the only number the panel showed.
 *
 * <p>The counts come from the gateway's hourly summary and the timings from the messages, sampled
 * on a long range -- see `receipt-sql.ts` for why one statement over every message could not finish.
 *
 * <p>Server-only: importing this pulls `pg`.
 */

export interface ReceiptQualityRow {
  vendor: string | null;
  /**
   * Attempts handed to this vendor in the window — first segment, every vendor attempt.
   *
   * <p>A refusal is real traffic for the vendor that refused it, so it is counted here. It is in
   * none of the columns below: an outcome is credited to the accepted attempt only, and a refused
   * attempt is neither reported, expired nor open — it will never get a receipt. So
   * `sent - reported - expired - open` is the attempts this vendor refused.
   */
  sent: number;
  /**
   * Messages the vendor gave an outcome for.
   *
   * <p><strong>EXPIRED is excluded on purpose.</strong> That state is written by our own sweeper
   * when no receipt arrived within the deadline — counting it as "reported" would let a vendor that
   * never says anything score 100%, which is precisely backwards.
   */
  reported: number;
  /** Messages the sweeper gave up on. The complement of `reported` that has already timed out. */
  expired: number;
  /**
   * Still open: an accepted attempt with no receipt, not yet swept. Not a failure, and not yet a
   * silence. Refused attempts are excluded — they would otherwise sit here for ever.
   */
  open: number;
  /** Of the reported ones, how many said delivered. */
  delivered: number;
  /** Seconds from submit to the outcome, over the messages that got one. Null when none did. */
  medianToOutcome: number | null;
  p90ToOutcome: number | null;
  /**
   * Progress receipts recorded for this vendor's traffic in the window.
   *
   * <p>Zero from a vendor that sends none — which is not a fault, merely a fact about what it will
   * tell you before the end. Null when this gateway has no `cdr_interim` at all, which is a
   * different statement and is rendered differently.
   */
  progressReceipts: number | null;
  /** Messages that got at least one progress receipt. */
  messagesWithProgress: number | null;
  /** Seconds from submit to the first sign of life, progress or outcome, whichever came first. */
  medianToFirstSign: number | null;
  /**
   * Set when the timings and progress figures were read from a sample of this vendor's messages
   * rather than all of them: `size` read of `of`. The counts above are never sampled.
   */
  sampled: { size: number; of: number } | null;
}

/** How old the summary's watermark may be before the counts are read from the records instead. */
const SUMMARY_MAX_AGE_MS = 3 * 3_600_000;

/** A range the summary cannot serve and the records are too large to read within the timeout. */
export class ReceiptSummaryUnavailable extends Error {}

/**
 * Receipt quality per vendor over the range.
 *
 * <p>Counts per vendor from {@link receiptCountsHourlySql}; timings and progress from
 * {@link receiptTimingsSql}, over one message in N where N keeps the read near
 * `SAMPLE_TARGET` messages. Degrades rather than fails against a gateway without `cdr_interim`: the
 * progress columns come back null and the page says the gateway is not recording them.
 *
 * <p>Without a current hourly summary (an older gateway, or a rollup that has stopped) the counts
 * would have to be read from every record; that is done for the 24-hour view only, and a longer
 * range answers {@link ReceiptSummaryUnavailable} instead of running into the timeout.
 */
export async function receiptQuality(range: Range): Promise<ReceiptQualityRow[]> {
  const { since, until } = resolveRange(range);
  const [progress, vendorAttempt, summarised, seam, hours] = await Promise.all([
    hasInterimTable(),
    hasVendorAttempt(),
    hasUsageHourlyAttempts(),
    hourlyWatermark(),
    deadlineHours(),
  ]);
  const settled = new Date(Date.now() - hours * 3_600_000);
  //a missing or stale summary leaves nothing to merge: the "watermark" becomes since, so every
  //instant of the range falls in the records' edges, which is right for 1 h and 24 h and too much beyond
  const usable = summarised && seam !== null && Date.now() - seam.getTime() < SUMMARY_MAX_AGE_MS;
  if (!usable && range !== "24h" && range !== "1h") {
    throw new ReceiptSummaryUnavailable(
      "The gateway's hourly summary is not current, so only the last hour and the 24-hour view can be read here."
    );
  }
  //every record read is from since on: the submits by submitted_at, their receipts from $1 too
  const counts = await cdrQuery<Record<string, string | null>>(
    receiptCountsHourlySql(vendorAttempt),
    [since, until, usable ? seam : since, settled],
    since
  );
  const messages = counts.reduce((n, r) => n + int(r.messages), 0);
  const divisor = sampleDivisor(messages);
  const timings = await cdrQuery<Record<string, string | null>>(
    receiptTimingsSql(progress, vendorAttempt),
    [since, until, divisor],
    since
  );
  const byVendor = new Map(timings.map((t) => [t.vendor ?? "", t]));

  return counts.map((r) => {
    const t = byVendor.get(r.vendor ?? "");
    const failed = int(r.failed);
    const delivered = int(r.delivered);
    const scale = (v: string | null | undefined) => Math.round(int(v ?? null) * divisor);
    return {
      vendor: r.vendor ?? null,
      sent: int(r.attempts),
      reported: delivered + failed,
      expired: int(r.expired),
      open: int(r.pending),
      delivered,
      medianToOutcome: seconds(t?.median_outcome ?? null),
      p90ToOutcome: seconds(t?.p90_outcome ?? null),
      //counted over the sample, so scaled back to the whole: an estimate when divisor > 1
      progressReceipts: progress ? scale(t?.progress_receipts) : null,
      messagesWithProgress: progress ? scale(t?.with_progress) : null,
      medianToFirstSign: seconds(t?.median_first_sign ?? null),
      sampled: divisor > 1 ? { size: int(t?.sampled ?? null), of: int(r.messages) } : null,
    };
  });
}

function int(value: string | null | undefined): number {
  const n = Number(value ?? 0);
  return Number.isFinite(n) ? n : 0;
}

/** Null-preserving: "no message got an outcome" is not "it took zero seconds". */
function seconds(value: string | null | undefined): number | null {
  if (value == null || value === "") {
    return null;
  }
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}
