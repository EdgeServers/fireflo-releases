import { configQuery, inTransaction } from "./config-db.ts";
import { open, seal } from "./secret-box.ts";
import { passwordStamp } from "./session-freshness.ts";
import { generateTotpSecret, verifyTotp } from "./totp.ts";

/**
 * Operator two-factor authentication in `app_user` (gateway V1.114.0): enrolment, the per-sign-in
 * check and turning it off. Server-only.
 *
 * <h2>The columns</h2>
 *
 * <ul>
 *   <li>`totp_secret` -- the authenticator's key, sealed with `FIREFLO_SECRETS_KEY` when the panel
 *       has one (`secret-box.ts`, the same envelope the gateway reads), base32 in the clear when it
 *       does not;</li>
 *   <li>`totp_pending_secret`, `totp_pending_at` -- an enrolment started and not yet confirmed with a
 *       code. It lapses after {@link PENDING_ENROLMENT_MS}; a new start replaces it;</li>
 *   <li>`totp_enabled_at` -- set when a code confirmed the enrolment. Its value is also the session's
 *       two-factor stamp: a session is good for the authenticator it was verified with, and a reset
 *       (`fireflo user totp-reset`) or a re-enrolment refuses every older one;</li>
 *   <li>`totp_last_step` -- the newest 30-second step a code was accepted for. A code at or before
 *       it is refused, so one code cannot complete two sign-ins.</li>
 *   <li>`totp_failed_count`, `totp_locked_until` -- wrong codes, counted per user in the database:
 *       every fifth locks the user's code checks for 15 minutes, doubling with each further five
 *       (capped at a day), and a right code resets both. See {@link attemptCode}.</li>
 *   <li>`totp_changed_at` -- set whenever two-factor is turned on, off or reset. Sessions carry the
 *       value they were made under, and one made before the latest change is refused, whether or not
 *       two-factor is on now (totp-gate.ts).</li>
 * </ul>
 *
 * <h2>Why every code check is one locked transaction</h2>
 *
 * <p>A code check reads the row `FOR UPDATE`, refuses at once while `totp_locked_until` is ahead,
 * verifies, and writes the outcome -- a claimed step and reset counters, or one more failure and
 * perhaps a lock -- before it commits. Concurrent checks for one user therefore run one at a time: a
 * burst of thousands of guesses gets five verified, and the rest find the lock. A limiter that
 * counted after an `await` let every request in a burst pass its check before any had counted.
 *
 * <p>Every function takes the query runner, so the DB test drives the same code on a scratch
 * database; the panel passes `configQuery`.
 */

/** Runs one statement: `configQuery`, or a test's pool. */
export type Db = <T extends Record<string, unknown>>(sql: string, params?: unknown[]) => Promise<T[]>;

/** Runs `work` in one transaction on one connection: `inTransaction`, or a test's. */
export type Tx = <T>(work: (q: Db) => Promise<T>) => Promise<T>;

const panelDb: Db = (sql, params) => configQuery(sql, params ?? []);

const panelTx: Tx = (work) =>
  inTransaction((client) => work(async (sql, params) => (await client.query(sql, params ?? [])).rows));

/** Wrong codes before the first lock; each further this many doubles it. */
export const FAILURES_PER_LOCK = 5;
/** The first lock, in minutes, and the longest. */
export const FIRST_LOCK_MINUTES = 15;
export const LONGEST_LOCK_MINUTES = 24 * 60;

/** An enrolment not confirmed within this lapses. */
export const PENDING_ENROLMENT_MS = 15 * 60_000;

/** The registry key that requires every operator to use an authenticator. */
export const TOTP_REQUIRED_KEY = "smsg.panel.operator.totp.required";

let probe: { present: boolean; at: number } | null = null;

/** Every column two-factor needs (V1.114.0). */
const COLUMNS = ["totp_secret", "totp_pending_secret", "totp_pending_at", "totp_enabled_at", "totp_last_step",
  "totp_failed_count", "totp_locked_until", "totp_changed_at"];

/**
 * Whether `app_user` has the two-factor columns (V1.114.0). False on an older gateway: then nothing
 * here runs, sign-in is a password or a link as before, and the screens hide two-factor.
 *
 * <p>"Absent" is only ever the answer of a query that ran and found them missing, re-asked after a
 * minute so an upgrade is picked up without a restart. A query that FAILED throws and is not
 * remembered: treating a failed probe as "no two-factor" would sign operators in with a password
 * alone and let their sessions through, which is the wrong direction to fail in.
 */
export async function hasTotpColumns(db: Db = panelDb): Promise<boolean> {
  if (probe && (probe.present || Date.now() - probe.at < 60_000)) {
    return probe.present;
  }
  //the schema the panel's queries resolve app_user in, and distinct names: another schema's
  //app_user (a tenant's, a test's) neither adds nor stands in for this one's
  const rows = await db<{ n: string | number }>(
    `SELECT count(DISTINCT column_name) AS n FROM information_schema.columns
      WHERE table_name = 'app_user' AND table_schema = current_schema() AND column_name = ANY($1)`,
    [COLUMNS]
  );
  probe = { present: Number(rows[0]?.n ?? 0) === COLUMNS.length, at: Date.now() };
  return probe.present;
}

/** Test helper. */
export function resetTotpProbe(): void {
  probe = null;
}

/** What `requireOperator` reads per request, two-factor included. */
export interface LiveOperator {
  role: string;
  enabled: boolean;
  passwordChangedAt: Date | string | null;
  /** `totp_enabled_at` as a stamp, or null when this operator has no authenticator. */
  totpStamp: number | null;
  /** `totp_changed_at` as a stamp: the last time two-factor was turned on, off or reset. */
  totpChanged: number | null;
  /** `smsg.panel.operator.totp.required`. */
  totpRequired: boolean;
}

/** One read of the row and the required switch, for a gateway with the columns. */
export async function liveOperator(id: number, db: Db = panelDb): Promise<LiveOperator | null> {
  const rows = await db<{
    role: string; enabled: boolean; password_changed_at: Date | string | null; totp_enabled_at: Date | string | null;
    totp_changed_at: Date | string | null; required: string | null;
  }>(
    `SELECT u.role, u.enabled, u.password_changed_at, u.totp_enabled_at, u.totp_changed_at,
            (SELECT c.value FROM app_config c WHERE c.key = $2 AND c.enabled) AS required
       FROM app_user u WHERE u.id = $1`,
    [id, TOTP_REQUIRED_KEY]
  );
  const r = rows[0];
  if (!r) {
    return null;
  }
  return {
    role: r.role,
    enabled: r.enabled,
    passwordChangedAt: r.password_changed_at,
    totpStamp: passwordStamp(r.totp_enabled_at),
    totpChanged: passwordStamp(r.totp_changed_at),
    totpRequired: (r.required ?? "").trim().toLowerCase() === "true",
  };
}

/** Whether operators must use an authenticator. */
export async function totpRequired(db: Db = panelDb): Promise<boolean> {
  const rows = await db<{ value: string | null }>(
    "SELECT value FROM app_config WHERE key = $1 AND enabled", [TOTP_REQUIRED_KEY]);
  return (rows[0]?.value ?? "").trim().toLowerCase() === "true";
}

/** The operator's own two-factor state, for their screen. */
export interface TotpStatus {
  enabled: boolean;
  enabledAt: string | null;
  /** An enrolment started and still open. */
  pending: boolean;
}

export async function totpStatus(id: number, db: Db = panelDb, now = Date.now()): Promise<TotpStatus | null> {
  const rows = await db<{ totp_enabled_at: Date | string | null; totp_pending_at: Date | string | null }>(
    "SELECT totp_enabled_at, totp_pending_at FROM app_user WHERE id = $1", [id]);
  const r = rows[0];
  if (!r) {
    return null;
  }
  const pendingAt = passwordStamp(r.totp_pending_at);
  return {
    enabled: r.totp_enabled_at != null,
    enabledAt: r.totp_enabled_at ? new Date(r.totp_enabled_at).toISOString() : null,
    pending: r.totp_enabled_at == null && pendingAt !== null && now - pendingAt < PENDING_ENROLMENT_MS,
  };
}

/** Thrown for a request the state does not allow; the message is for the operator. */
export class TotpRefused extends Error {
  constructor(message: string) {
    super(message);
    this.name = "TotpRefused";
  }
}

/**
 * Starts (or restarts) an enrolment: a new secret, kept as pending until a code confirms it.
 *
 * @returns the secret in base32, for the QR code and the key shown beside it -- the one time it
 *     leaves the server
 */
export async function startEnrolment(id: number, db: Db = panelDb): Promise<string> {
  const secret = generateTotpSecret();
  const rows = await db<{ id: number }>(
    `UPDATE app_user SET totp_pending_secret = $2, totp_pending_at = now()
      WHERE id = $1 AND totp_enabled_at IS NULL RETURNING id`,
    [id, seal(secret)]
  );
  if (!rows.length) {
    throw new TotpRefused("Two-factor authentication is already on for this account. Turn it off first to set up a new authenticator.");
  }
  return secret;
}

/** What one code check came to. */
export type CodeAttempt =
  /** Right. `stamp` is `totp_enabled_at` (null after a disable), `changed` is `totp_changed_at`. */
  | { outcome: "ok"; stamp: number | null; changed: number | null }
  /** Wrong (or replayed). `lockedUntil` is set when this failure locked the user's code checks. */
  | { outcome: "wrong"; failures: number; lockedUntil: Date | null }
  /** Refused unchecked: the user's code checks are locked until then. */
  | { outcome: "locked"; lockedUntil: Date }
  /** Nothing to check against: no authenticator (or, for `confirm`, no open set-up). */
  | { outcome: "none" };

/**
 * One code check, counted per user in one locked transaction (see the module doc).
 *
 * <ul>
 *   <li>`signin` -- the second step of a sign-in: a right code claims its step;</li>
 *   <li>`confirm` -- the first code from a new authenticator: the pending secret becomes the secret,
 *       `totp_enabled_at` and `totp_changed_at` are set;</li>
 *   <li>`disable` -- a current code before turning two-factor off (the caller has checked the
 *       password): every column is cleared and `totp_changed_at` set.</li>
 * </ul>
 */
export async function attemptCode(
  id: number,
  code: string,
  purpose: "signin" | "confirm" | "disable",
  o: { tx?: Tx; now?: number } = {}
): Promise<CodeAttempt> {
  const tx = o.tx ?? panelTx;
  const now = o.now ?? Date.now();
  return tx(async (q) => {
    const [r] = await q<{
      totp_secret: string | null; totp_pending_secret: string | null; totp_pending_at: Date | string | null;
      totp_enabled_at: Date | string | null; totp_last_step: string | number | null;
      totp_locked_until: Date | string | null; locked: boolean | null;
    }>(
      `SELECT totp_secret, totp_pending_secret, totp_pending_at, totp_enabled_at, totp_last_step,
              totp_locked_until, (totp_locked_until > now()) AS locked
         FROM app_user WHERE id = $1 FOR UPDATE`,
      [id]
    );
    if (!r) {
      return { outcome: "none" };
    }
    if (r.locked) {
      return { outcome: "locked", lockedUntil: new Date(r.totp_locked_until!) };
    }
    let secret: string | null;
    let lastStep: number | null = null;
    if (purpose === "confirm") {
      const pendingAt = passwordStamp(r.totp_pending_at);
      if (r.totp_enabled_at != null || !r.totp_pending_secret || pendingAt === null || now - pendingAt >= PENDING_ENROLMENT_MS) {
        return { outcome: "none" };
      }
      secret = r.totp_pending_secret;
    } else {
      if (r.totp_enabled_at == null || !r.totp_secret) {
        return { outcome: "none" };
      }
      secret = r.totp_secret;
      lastStep = r.totp_last_step == null ? null : Number(r.totp_last_step);
    }
    //a sealed secret this panel has no key for throws, and the transaction rolls back: nothing is
    //counted against the user for the panel's own misconfiguration
    const step = verifyTotp(open(secret)!, code, { now, lastStep });

    if (step === null) {
      const [f] = await q<{ totp_failed_count: number; totp_locked_until: Date | string | null; locked: boolean | null }>(
        `UPDATE app_user
            SET totp_failed_count = totp_failed_count + 1,
                totp_locked_until = CASE WHEN (totp_failed_count + 1) % $2 = 0
                  THEN now() + make_interval(mins => LEAST($3 * power(2, (totp_failed_count + 1) / $2 - 1), $4)::int)
                  ELSE totp_locked_until END
          WHERE id = $1
          RETURNING totp_failed_count, totp_locked_until, (totp_locked_until > now()) AS locked`,
        [id, FAILURES_PER_LOCK, FIRST_LOCK_MINUTES, LONGEST_LOCK_MINUTES]
      );
      return {
        outcome: "wrong",
        failures: Number(f.totp_failed_count),
        lockedUntil: f.locked ? new Date(f.totp_locked_until!) : null,
      };
    }

    const sql = purpose === "confirm"
      ? `UPDATE app_user
            SET totp_secret = totp_pending_secret, totp_pending_secret = NULL, totp_pending_at = NULL,
                totp_enabled_at = now(), totp_changed_at = now(), totp_last_step = $2,
                totp_failed_count = 0, totp_locked_until = NULL
          WHERE id = $1 RETURNING totp_enabled_at, totp_changed_at`
      : purpose === "disable"
        ? `UPDATE app_user
              SET totp_secret = NULL, totp_pending_secret = NULL, totp_pending_at = NULL, totp_enabled_at = NULL,
                  totp_last_step = NULL, totp_changed_at = now(), totp_failed_count = 0, totp_locked_until = NULL
            WHERE id = $1 AND $2::bigint IS NOT NULL RETURNING totp_enabled_at, totp_changed_at`
        : `UPDATE app_user SET totp_last_step = $2, totp_failed_count = 0, totp_locked_until = NULL
            WHERE id = $1 RETURNING totp_enabled_at, totp_changed_at`;
    const [done] = await q<{ totp_enabled_at: Date | string | null; totp_changed_at: Date | string | null }>(sql, [id, step]);
    return { outcome: "ok", stamp: passwordStamp(done.totp_enabled_at), changed: passwordStamp(done.totp_changed_at) };
  });
}

/**
 * Whether this user's code checks are locked now, without counting anything: for refusing a request
 * before doing work for it. {@link attemptCode} makes the binding check.
 */
export async function codeChecksLocked(id: number, db: Db = panelDb): Promise<Date | null> {
  const [r] = await db<{ totp_locked_until: Date | string | null; locked: boolean | null }>(
    "SELECT totp_locked_until, (totp_locked_until > now()) AS locked FROM app_user WHERE id = $1", [id]);
  return r?.locked ? new Date(r.totp_locked_until!) : null;
}

/** Each operator's `totp_enabled_at`, for the Users page's column. */
export async function totpEnabledByUser(db: Db = panelDb): Promise<Map<number, string>> {
  const rows = await db<{ id: number | string; totp_enabled_at: Date | string }>(
    "SELECT id, totp_enabled_at FROM app_user WHERE totp_enabled_at IS NOT NULL");
  return new Map(rows.map((r) => [Number(r.id), new Date(r.totp_enabled_at).toISOString()]));
}
