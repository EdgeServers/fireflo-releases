import { strict as assert } from "node:assert";
import { after, before, describe, test } from "node:test";

import { accountUsageSql } from "./usage-summary-sql.ts";

/**
 * The Accounts 24 hours read from the hourly summary keeps its split by login (gateway V1.113.0,
 * `usage_hourly.system_id`), and gives the records' own figures per login; against a summary without
 * the column it is one row per account and product, and never names the column.
 *
 * <p>`CDR_TIER_TEST_DATABASE_URL` (or `STATEMENT_TEST_DATABASE_URL`) names a database this test may
 * create and drop two schemas in.
 */
const URL = process.env.CDR_TIER_TEST_DATABASE_URL ?? process.env.STATEMENT_TEST_DATABASE_URL;

type Row = { account_id: string; system_id: string | null; product: string | null; messages: string; billed: string;
  delivered: string; failed: string; pending: string };

describe("the 24 hours by login, from usage_hourly", { skip: URL ? false : "CDR_TIER_TEST_DATABASE_URL is not set" }, () => {
  const WITH = `uh_login_${process.pid}`;
  const WITHOUT = `uh_nologin_${process.pid}`;
  let admin: import("pg").Pool;
  let withLogin: import("pg").Pool;
  let without: import("pg").Pool;
  const run = async <T,>(pool: import("pg").Pool, sql: string, params: unknown[] = []) => (await pool.query(sql, params)).rows as T[];

  //the summary's watermark: two hours ago on the hour. The window is the last 24 hours
  const hwm = new Date(Math.floor(Date.now() / 3_600_000) * 3_600_000 - 2 * 3_600_000);
  const until = new Date();
  const since = new Date(until.getTime() - 24 * 3_600_000);
  const params = [since, until, "UTC"];

  async function schema(pool: import("pg").Pool, login: boolean) {
    await run(pool, `CREATE TABLE cdr_submit (
        id bigserial PRIMARY KEY, gateway_msg_id text NOT NULL, part_no int NOT NULL DEFAULT 1, account_id text,
        system_id text, product text, submitted_at timestamptz NOT NULL, price bigint, cost bigint,
        retry_count int NOT NULL DEFAULT 0, vendor_attempt int NOT NULL DEFAULT 0, vendor text)`);
    await run(pool, `CREATE TABLE cdr_final (id bigserial, gateway_msg_id text NOT NULL, part_no int NOT NULL DEFAULT 1,
        final_state text NOT NULL, final_at timestamptz NOT NULL, dlr_state int, err_code text)`);
    await run(pool, `CREATE TABLE usage_daily (account_id text NOT NULL, day date NOT NULL, product text NOT NULL,
        submitted bigint, delivered bigint, failed bigint, expired bigint, pending_at_rollup bigint,
        price_total bigint, cost_total bigint)`);
    await run(pool, `CREATE TABLE usage_hourly (account_id text NOT NULL, hour timestamptz NOT NULL, product text NOT NULL,
        vendor text NOT NULL DEFAULT ''${login ? ", system_id text NOT NULL DEFAULT ''" : ""},
        submitted bigint NOT NULL, delivered bigint NOT NULL, failed bigint NOT NULL, expired bigint NOT NULL,
        pending_at_rollup bigint NOT NULL, price_total bigint NOT NULL, cost_total bigint NOT NULL,
        refused bigint NOT NULL DEFAULT 0)`);
    await run(pool, "CREATE TABLE usage_rollup_cursor (one boolean PRIMARY KEY DEFAULT TRUE, hourly_hwm timestamptz)");
    await run(pool, "INSERT INTO usage_rollup_cursor (hourly_hwm) VALUES ($1)", [hwm]);

    let n = 0;
    const message = async (login: string, at: Date, outcome: string | null, price = 100) => {
      const id = `m${++n}`;
      await run(pool, `INSERT INTO cdr_submit (gateway_msg_id, account_id, system_id, product, submitted_at, price, cost, vendor)
                       VALUES ($1, 'acme', $2, 'p1', $3, $4, 40, 'v1')`, [id, login, at, price]);
      if (outcome) {
        await run(pool, "INSERT INTO cdr_final (gateway_msg_id, final_state, final_at) VALUES ($1, $2, $3)",
          [id, outcome, new Date(at.getTime() + 60_000)]);
      }
    };
    //one whole hour, both logins: summarised
    const h = new Date(hwm.getTime() - 3 * 3_600_000);
    for (let i = 0; i < 3; i++) await message("L1", new Date(h.getTime() + (i + 1) * 60_000), "DELIVERED");
    await message("L2", new Date(h.getTime() + 10 * 60_000), "DELIVERED");
    await message("L2", new Date(h.getTime() + 11 * 60_000), "FAILED", 250);
    //past the watermark: the raw edge, read from the records
    await message("L1", new Date(hwm.getTime() + 5 * 60_000), null);
    for (let i = 0; i < 4; i++) await message("L2", new Date(hwm.getTime() + (i + 6) * 60_000), "DELIVERED");

    //the gateway's hourly rollup, by login when the column is there
    await run(pool, `INSERT INTO usage_hourly (account_id, hour, product, vendor${login ? ", system_id" : ""}, submitted,
                       delivered, failed, expired, pending_at_rollup, price_total, cost_total)
      SELECT s.account_id, date_trunc('hour', s.submitted_at AT TIME ZONE 'UTC') AT TIME ZONE 'UTC', s.product, s.vendor
             ${login ? ", COALESCE(s.system_id, '')" : ""},
             count(*), count(*) FILTER (WHERE f.final_state = 'DELIVERED'),
             count(*) FILTER (WHERE f.final_state = 'FAILED'), 0, count(*) FILTER (WHERE f.final_state IS NULL),
             SUM(s.price), SUM(s.cost)
        FROM cdr_submit s LEFT JOIN cdr_final f USING (gateway_msg_id)
       WHERE s.submitted_at < $1
       GROUP BY 1, 2, 3, 4${login ? ", 5" : ""}`, [hwm]);
  }

  before(async () => {
    const pg = (await import("pg")).default;
    admin = new pg.Pool({ connectionString: URL, max: 1 });
    await run(admin, `CREATE SCHEMA ${WITH}`);
    await run(admin, `CREATE SCHEMA ${WITHOUT}`);
    withLogin = new pg.Pool({ connectionString: URL, max: 1, options: `-c search_path=${WITH}` });
    without = new pg.Pool({ connectionString: URL, max: 1, options: `-c search_path=${WITHOUT}` });
    await schema(withLogin, true);
    await schema(without, false);
  });

  after(async () => {
    await withLogin?.end();
    await without?.end();
    if (admin) {
      await run(admin, `DROP SCHEMA IF EXISTS ${WITH} CASCADE`).catch(() => undefined);
      await run(admin, `DROP SCHEMA IF EXISTS ${WITHOUT} CASCADE`).catch(() => undefined);
      await admin.end();
    }
  });

  const figures = (rows: Row[]) => rows
    .map((r) => [r.account_id, r.system_id, r.product, Number(r.messages), Number(r.billed), Number(r.delivered),
      Number(r.failed), Number(r.pending)])
    .sort((a, b) => String(a[1]).localeCompare(String(b[1])));

  test("two logins in one hour are two rows, with the records' own totals", async () => {
    const hourly = await run<Row>(withLogin,
      accountUsageSql({ source: "hourly", logins: true, scoped: false, vendorAttempt: true, hourlyLogin: true }), params);
    assert.deepEqual(figures(hourly), [
      //L1: three summarised and delivered, one past the watermark still pending
      ["acme", "L1", "p1", 4, 400, 3, 0, 1],
      //L2: one delivered and one failed in the hour, four delivered past it
      ["acme", "L2", "p1", 6, 750, 5, 1, 0],
    ]);
    const records = await run<Row>(withLogin,
      accountUsageSql({ source: "live", logins: true, scoped: false, vendorAttempt: true }), params);
    assert.deepEqual(figures(hourly), figures(records), "the summary and the records agree login by login");
  });

  test("an hour rolled before the column ('') reads as no login", async () => {
    //one connection (max 1), so the transaction holds across the reads; rolled back after
    await run(withLogin, "BEGIN");
    try {
      await run(withLogin, "UPDATE usage_hourly SET system_id = ''");
      const rows = figures(await run<Row>(withLogin,
        accountUsageSql({ source: "hourly", logins: true, scoped: false, vendorAttempt: true, hourlyLogin: true }), params));
      //the summarised hour folds into one no-login row; the raw edge keeps its logins
      assert.deepEqual(rows.map((r) => [r[1], r[3]]), [["L1", 1], ["L2", 4], [null, 5]]);
    } finally {
      await run(withLogin, "ROLLBACK");
    }
  });

  test("a summary without the column: one row per account and product, the column never named", async () => {
    const rows = await run<Row>(without,
      accountUsageSql({ source: "hourly", logins: true, scoped: false, vendorAttempt: true, hourlyLogin: false }), params);
    assert.deepEqual(figures(rows), [["acme", null, "p1", 10, 1150, 8, 1, 1]]);
    await assert.rejects(
      run(without, accountUsageSql({ source: "hourly", logins: true, scoped: false, vendorAttempt: true, hourlyLogin: true }), params),
      /system_id/, "naming the column on an older gateway is the error the probe exists to avoid");
  });
});
