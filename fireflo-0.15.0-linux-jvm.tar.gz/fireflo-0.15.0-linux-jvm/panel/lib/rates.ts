import type { PoolClient } from "pg";
import { BILLING_KEY } from "@/lib/billing-key";
import { configQuery, inTransaction } from "@/lib/config-db";
import { auditConfigChange } from "@/lib/config-audit";
import type { ConfigSummary } from "@/lib/config-change";
import { assertProductsCatalogued } from "@/lib/products";
import { planProductWrite } from "@/lib/rate-scope-write";
import { isConfigured as metricsConfigured, query as metricsQuery } from "@/lib/metrics-db";
import { cdrSql } from "@/lib/cdr-tier";
import type {
  ConditionInput,
  KnownScopes,
  ManagedRule,
  ProductScopeSummary,
  RateRule,
  RateRuleInput,
  ScopeSummary,
  UnratedPair,
} from "@/lib/rate-types";
import { DEFAULT_SCOPE, unratedPairs } from "@/lib/rate-types";

/**
 * Pricing rules.
 *
 * <p>Server-only: importing this pulls `pg`. Types and validation live in `rate-types.ts`.
 *
 * <p><strong>Rule ids are preserved across a save, and that is not a nicety.</strong>
 * `cdr_submit.cost_rule_id` and `price_rule_id` record which rule charged each message — and
 * `cdr_submit` has no foreign keys at all, so nothing in the database would warn. The
 * delete-and-reinsert idiom `saveWorker` uses would issue fresh `BIGSERIAL` ids and dangle every
 * historical reference silently, turning "which rule charged this?" into an unanswerable question
 * about money.
 */

interface RuleRow {
  id: string;
  scope: string;
  seq: number;
  amount: string;
  product: string | null;
  currency: string | null;
  label: string | null;
  enabled: boolean;
  updated_at: Date | null;
}

interface ConditionRow {
  rule_id: string;
  seq: number;
  field: string;
  operator: string;
  value: string;
  negate: boolean;
}

interface FilterRow {
  rule_id: string;
  filter_name: string;
}

/** Every scope that has rules, with enough to render a list without loading them all. */
export async function listScopes(): Promise<ScopeSummary[]> {
  const rows = await configQuery<{ scope: string; rules: number; enabled: number; products: string[] }>(
    `SELECT scope,
            count(*)::int                                       AS rules,
            count(*) FILTER (WHERE enabled)::int                AS enabled,
            COALESCE(array_agg(DISTINCT product)
                       FILTER (WHERE product IS NOT NULL AND product <> ''),
                     '{}')                                      AS products
       FROM app_rate_rule
      GROUP BY scope
      ORDER BY scope`
  );
  return rows.map((r) => ({
    scope: r.scope,
    rules: r.rules,
    enabled: r.enabled,
    products: r.products ?? [],
  }));
}

/**
 * One scope's rules, in the order the gateway will try them.
 *
 * <p>Three queries stitched in JavaScript rather than one join, the same shape as `listWorkers`: a
 * join here would multiply each rule by its conditions and its filters at once.
 *
 * <p>Note `amount::text`. `node-postgres` already returns NUMERIC as a string, precisely to keep
 * money out of a float — the cast makes that a property of the query rather than a driver default
 * somebody later "fixes" with a type parser.
 */
export async function listRules(scope: string): Promise<RateRule[]> {
  const rules = await configQuery<RuleRow>(
    `SELECT id::text, scope, seq, amount::text AS amount, product, currency, label, enabled, updated_at
       FROM app_rate_rule WHERE scope = $1 AND managed_by IS NULL ORDER BY seq`,
    [scope]
  );
  if (!rules.length) {
    return [];
  }
  const ids = rules.map((r) => r.id);

  const [conditions, filters] = await Promise.all([
    configQuery<ConditionRow>(
      `SELECT rule_id::text, seq, field, operator, value, negate
         FROM app_rate_rule_condition WHERE rule_id = ANY($1::bigint[]) ORDER BY rule_id, seq`,
      [ids]
    ),
    configQuery<FilterRow>(
      `SELECT rule_id::text, filter_name
         FROM app_rate_rule_filter WHERE rule_id = ANY($1::bigint[]) ORDER BY rule_id, seq`,
      [ids]
    ),
  ]);

  const byRule = new Map<string, ConditionInput[]>();
  for (const c of conditions) {
    const list = byRule.get(c.rule_id) ?? [];
    list.push({ field: c.field, operator: c.operator, value: c.value, negate: c.negate });
    byRule.set(c.rule_id, list);
  }
  const filtersByRule = new Map<string, string[]>();
  for (const f of filters) {
    const list = filtersByRule.get(f.rule_id) ?? [];
    list.push(f.filter_name);
    filtersByRule.set(f.rule_id, list);
  }

  return rules.map((r) => ({
    id: Number(r.id),
    scope: r.scope,
    seq: r.seq,
    amount: r.amount,
    product: r.product,
    currency: r.currency,
    label: r.label,
    enabled: r.enabled,
    conditions: byRule.get(r.id) ?? [],
    filters: filtersByRule.get(r.id) ?? [],
    updatedAt: r.updated_at ? r.updated_at.toISOString() : null,
  }));
}

/** A scope with every one of its rules, complete and in order. */
export interface ScopeRules {
  scope: string;
  rules: RateRule[];
}

/**
 * The ceiling on a batch that loads every rule of every scope pricing one product.
 *
 * <p>It was 2,000 and it was named for the inline editor, which used to hold all of it. That editor
 * now loads one scope at a time on demand, so the only callers left are the CSV export and import —
 * and capping those at 2,000 would have disabled the one tool that makes a thousand accounts
 * manageable, in the name of protecting a page that no longer asks.
 *
 * <p>Still a ceiling rather than nothing: both callers build the whole set in memory, so this is
 * where a runaway becomes a sentence instead of an out-of-memory error. A hundred thousand rules is
 * far past any real tariff and far short of anything that hurts.
 */
export const MAX_BATCH_RULES = 100_000;

/**
 * A platform's custom tariff on one scope (gateway V1.101.0): the rules it wrote with
 * `PUT /manage/accounts/{id}/tariff`, priced ahead of the operator's own. Read-only here -- every save
 * on this page leaves them alone -- and shown so an operator can see why an account is charged what
 * it is.
 */
export async function listManagedRules(scope: string): Promise<ManagedRule[]> {
  const rows = await configQuery<{
    id: string; product: string | null; amount: string; enabled: boolean; managed_by: string; prefixes: string | null;
  }>(
    `SELECT r.id::text, r.product, r.amount::text, r.enabled, r.managed_by,
            (SELECT c.value FROM app_rate_rule_condition c
              WHERE c.rule_id = r.id AND c.field = 'to' AND c.operator = 'startsWithAny'
              ORDER BY c.seq LIMIT 1) AS prefixes
       FROM app_rate_rule r
      WHERE r.scope = $1 AND r.managed_by IS NOT NULL
      ORDER BY r.seq`,
    [scope]
  );
  return rows.map((r) => ({
    id: Number(r.id),
    product: r.product,
    amount: r.amount,
    enabled: r.enabled,
    managedBy: r.managed_by,
    //"91,+91" is stored so a destination matches with or without its plus; one spelling reads better
    prefixes: [...new Set((r.prefixes ?? "").split(",").map((p) => p.trim().replace(/^\+/, "")).filter(Boolean))],
  }));
}

/**
 * Every scope that can price this product, each one **complete**.
 *
 * <p>Two things about the shape, both forced rather than chosen.
 *
 * <p><strong>Whole scopes, not filtered rules.</strong> An earlier version returned a flat list
 * filtered to the product and its any-product siblings, which is what the page displays — but that is
 * exactly the list that must never be handed back to {@link saveScope}, because it deletes every rule
 * it is not given. Returning the whole scope and filtering in the component keeps the savable set and
 * the displayed set visibly different things.
 *
 * <p><strong>Scopes that price no product at all are included.</strong> `RateSnapshot.rulesFor`
 * returns the product's own rules followed by the any-product ones, so a scope whose only rules have
 * no product still decides this product's price — usually the catch-all that charges most of it.
 *
 * @throws Error with a sentence when the result would be too large to edit safely
 */
export async function listRulesForProduct(product: string): Promise<ScopeRules[]> {
  const scopes = await configQuery<{ scope: string; rules: number }>(
    `SELECT scope, count(*)::int AS rules
       FROM app_rate_rule
      GROUP BY scope
     HAVING bool_or(product = $1) OR bool_or(product IS NULL OR product = '')
      ORDER BY scope`,
    [product]
  );

  const total = scopes.reduce((sum, s) => sum + s.rules, 0);
  if (total > MAX_BATCH_RULES) {
    throw new Error(
      `'${product}' is priced by ${total} rules across ${scopes.length} scopes — more than one file `
      + "can carry safely. Narrow it, or edit the scopes individually from the account or vendor."
    );
  }

  return Promise.all(
    scopes.map(async (s) => ({ scope: s.scope, rules: await listRules(s.scope) }))
  );
}

/**
 * Every rule of every scope, or of the scopes `wanted` keeps, for the Pricing page's export and
 * import. Under the same ceiling as {@link listRulesForProduct}, and for the same reason: one file
 * has to stay something a spreadsheet and a request body can carry.
 */
export async function listRulesForScopes(wanted: (scope: string) => boolean = () => true): Promise<ScopeRules[]> {
  const scopes = (await listScopes()).filter((s) => wanted(s.scope));
  const total = scopes.reduce((sum, s) => sum + s.rules, 0);
  if (total > MAX_BATCH_RULES) {
    throw new Error(
      `That is ${total} rules across ${scopes.length} scopes, more than one file can carry safely. `
      + "Export accounts and vendors separately, or one scope at a time."
    );
  }
  return Promise.all(scopes.map(async (s) => ({ scope: s.scope, rules: await listRules(s.scope) })));
}

/**
 * What a `scope` is allowed to be.
 *
 * <p>Lives here rather than in its own module despite querying neither rate table: its only purpose
 * is to decide whether a rate scope is a vendor cost or an account price, and a third module for two
 * queries would be worse than one documented misplacement.
 *
 * <p>The account half now leads with `app_account`, so an account somebody catalogued is known
 * whether or not it has a credential yet. Before the catalogue existed this derived entirely from
 * `app_credential`, which comes back **empty while credentials live in a file** — that is why the
 * validator still has a confirm-anyway escape hatch and why the route still widens this with
 * accounts seen in recent traffic. Three sources, none of them alone sufficient.
 */
export async function listKnownScopes(): Promise<KnownScopes> {
  const [vendors, accounts] = await Promise.all([
    configQuery<{ name: string }>(
      `SELECT name FROM app_worker WHERE type = 'smppclient' ORDER BY name`
    ),
    //the catalogue first, then the credentials that imply one. An account catalogued but not yet
    //given a login is a real account with real pricing, and deriving the list from credentials alone
    //made it 'unknown' -- which is the state scopeKind cannot classify and validateScope refuses
    //
    //BILLING_KEY rather than account_id, because a blank account_id does not mean "no account": the
    //gateway falls back to the system id, bills under it and matches rates against it. Reading the
    //column raw called a freshly bootstrapped install's only login an unknown scope while /accounts,
    //which has always used the fallback, listed the same login as an account
    configQuery<{ id: string }>(
      `SELECT id FROM (
         SELECT id FROM app_account
         UNION
         SELECT ${BILLING_KEY} FROM app_credential
       ) t
        WHERE id IS NOT NULL AND btrim(id) <> ''
        ORDER BY id`
    ),
  ]);
  //the products each account's logins actually claim, for the warning about a rule priced for a
  //product nothing carries. Read here rather than per page: both callers already take KnownScopes
  let carriedProducts: Record<string, string[]> | undefined;
  try {
    //keyed by BILLING_KEY for the same reason as the list above, and it has to be the same key or
    //the two disagree: an account the list now knows would have no entry here, and "no entry" is
    //read as "not looked at", so the warning would go quiet on exactly the accounts just made visible
    const rows = await configQuery<{ account_id: string; product: string | null }>(
      `SELECT DISTINCT account_id, product FROM (
         SELECT ${BILLING_KEY} AS account_id, NULLIF(btrim(product), '') AS product
           FROM app_credential
          WHERE enabled
       ) t
        WHERE account_id IS NOT NULL AND btrim(account_id) <> ''
        ORDER BY 1, 2`
    );
    //every account with a login gets a key; one whose logins all carry nothing gets an empty list,
    //which is a finding and not a gap -- it is the account whose product-specific rules price
    //nothing at all. An account absent from this map has not been looked at (a file-based
    //credential, or no login yet), which is the honest reading and stays silent
    carriedProducts = {};
    for (const row of rows) {
      const list = (carriedProducts[row.account_id] ??= []);
      if (row.product) {
        list.push(row.product);
      }
    }
  } catch {
    //a missing map means no opinion, and the warning stays silent rather than guessing
    carriedProducts = undefined;
  }

  return {
    vendors: vendors.map((v) => v.name),
    accounts: accounts.map((a) => a.id),
    carriedProducts,
  };
}

/**
 * {@link listKnownScopes} widened with accounts seen in recent traffic.
 *
 * <p>Two pools in one call, which is unusual and deliberate. `app_credential` is empty on any
 * deployment still keeping credentials in a file, so the configuration side alone reports no accounts
 * at all — and a scope validator with no accounts to compare against rejects every real one. The
 * call-record side knows which accounts have actually sent, which is a different and more useful
 * kind of true.
 *
 * <p>Reading a config table through the metrics pool is established here: `metrics-queries.ts`
 * already selects from `app_credential` that way.
 *
 * @param days how far back to look for accounts that have sent
 */
export async function resolveKnownScopes(days = 90): Promise<KnownScopes> {
  const known = await listKnownScopes();
  if (!metricsConfigured()) {
    return known;
  }
  //a short cache, because this runs on ROUTINE page loads via accountContext and the answer --
  //which accounts have sent recently -- does not change inside a minute (Audit F15)
  const now = Date.now();
  if (seenAccountsCache && now - seenAccountsCache.at < SEEN_ACCOUNTS_TTL_MS) {
    const accounts = new Set([...known.accounts, ...seenAccountsCache.accounts]);
    return { ...known, accounts: [...accounts].sort() };
  }
  try {
    //a skip scan, not a DISTINCT over the window: the plain form reads every row the retention
    //window holds -- at production rate, hundreds of millions -- to answer with a handful of
    //names. This enumerates account_id via one index probe per DISTINCT account (the recursive
    //half rides the (account_id, submitted_at) index), then one EXISTS seek per account for
    //recency. Cost is O(accounts x log rows) instead of O(rows). `account_id > ''` carries both
    //the NOT NULL and the not-empty conditions of the old form
    //routed for the window: past the hot days, the walk runs over the _all view, both sides merged
    const seen = await metricsQuery<{ account_id: string }>(
      await cdrSql(`WITH RECURSIVE walk AS (
           (SELECT account_id FROM cdr_submit WHERE account_id > ''
             ORDER BY account_id LIMIT 1)
           UNION ALL
           SELECT (SELECT account_id FROM cdr_submit
                    WHERE account_id > w.account_id
                    ORDER BY account_id LIMIT 1)
             FROM walk w WHERE w.account_id IS NOT NULL
       )
       SELECT account_id FROM walk w
        WHERE account_id IS NOT NULL
          AND EXISTS (SELECT 1 FROM cdr_submit s
                       WHERE s.account_id = w.account_id
                         AND s.submitted_at > now() - ($1 || ' days')::interval)
        ORDER BY 1`, new Date(now - days * 86_400_000)),
      [String(days)]
    );
    seenAccountsCache = { at: now, accounts: seen.map((r) => r.account_id) };
    const accounts = new Set([...known.accounts, ...seenAccountsCache.accounts]);
    return { ...known, accounts: [...accounts].sort() };
  } catch {
    //a widened list is a convenience; losing it should not stop the page loading
    return known;
  }
}

/** Module state, per server process; a stale minute costs a name on a picker, nothing more. */
let seenAccountsCache: { at: number; accounts: string[] } | null = null;
const SEEN_ACCOUNTS_TTL_MS = 60_000;

/**
 * Account and product pairs that no enabled rule would price.
 *
 * <p>The configuration-side half of the unrated question, and the one the delivery check asks:
 * `/api/control/unrated-preflight` counts traffic that has *already* been sent unpriced, this one
 * names pairs that would be — including for an account onboarded this morning that has not sent yet.
 *
 * <p>The pairs come from `listKnownScopes` rather than from a second credential query, so the
 * `BILLING_KEY` fallback and the "an account absent from the map has not been looked at" reading are
 * shared with the unreachable-product warning instead of re-derived. When the map could not be read
 * at all this returns nothing, which is the same silence that warning keeps: no opinion is not the
 * same answer as no problem, and the caller reports it as a read rather than as a clean result.
 *
 * <p>Coverage is judged by {@link unratedPairs}, which is where the four-bucket rule lives.
 *
 * @param accountId narrows to one account, the way the rest of the delivery check narrows
 */
export async function listUnratedAccountProducts(
  accountId?: string | null
): Promise<UnratedPair[]> {
  const { carriedProducts } = await listKnownScopes();
  if (!carriedProducts) {
    return [];
  }
  const carried = accountId
    ? (carriedProducts[accountId] ? { [accountId]: carriedProducts[accountId] } : {})
    : carriedProducts;

  const scopes = Object.keys(carried);
  if (!scopes.length) {
    return [];
  }

  //only the scopes in play plus the default, so an install with a thousand customers does not read
  //every rule to judge one account. DISTINCT because coverage is a set question -- how many rules
  //price a pair does not change whether it is priced
  const covered = await configQuery<{ scope: string; product: string }>(
    `SELECT DISTINCT scope, COALESCE(btrim(product), '') AS product
       FROM app_rate_rule
      WHERE enabled AND (scope = ANY($1) OR scope = $2)`,
    [scopes, DEFAULT_SCOPE]
  );
  return unratedPairs(carried, covered);
}

/**
 * Copies the default scope's rules for one product onto every account that has none for it.
 *
 * <p><strong>Additive, and that is not a preference.</strong> `saveScope` replaces a scope wholesale
 * -- it deletes every rule it is not given, which is what the CSV import relies on. Reaching for it
 * here would delete each account's entire tariff and leave behind only the copied rule. So this
 * inserts, and touches nothing that is already there.
 *
 * <p>An account that already has a rule in the same product bucket is SKIPPED rather than
 * overwritten, and named in the result. Overwriting a negotiated price with a list price, silently,
 * across every customer at once, is the worst thing this button could do.
 *
 * <p>Appended at the end of each account's rules, which is safe because the copies carry a product:
 * `RateSnapshot.rulesFor` scans a scope's product-specific bucket before its any-product one, so a
 * copy cannot be shadowed by an account's existing catch-all whatever its sequence number.
 *
 * @returns which accounts were written and which were left alone
 */
export async function copyDefaultToAccounts(
  product: string
): Promise<{ applied: string[]; skipped: string[] }> {
  const accounts = (await listKnownScopes()).accounts;
  if (!accounts.length) {
    return { applied: [], skipped: [] };
  }

  return inTransaction(async (client) => {
    const source = await client.query<{
      id: string; amount: string; currency: string | null; label: string | null; enabled: boolean;
    }>(
      `SELECT id::text, amount::text, currency, label, enabled
         FROM app_rate_rule WHERE scope = $1 AND product = $2 ORDER BY seq`,
      [DEFAULT_SCOPE, product]
    );
    if (!source.rows.length) {
      throw new Error(
        `There is no default price for '${product}' to copy. Set one first.`
      );
    }

    const applied: string[] = [];
    const skipped: string[] = [];

    for (const account of accounts) {
      const already = await client.query<{ n: string }>(
        `SELECT count(*)::text AS n FROM app_rate_rule WHERE scope = $1 AND product = $2`,
        [account, product]
      );
      if (Number(already.rows[0]?.n ?? 0) > 0) {
        skipped.push(account);
        continue;
      }

      const tail = await client.query<{ next: number }>(
        `SELECT COALESCE(max(seq), -1) + 1 AS next FROM app_rate_rule WHERE scope = $1`,
        [account]
      );
      let seq = tail.rows[0]?.next ?? 0;

      for (const rule of source.rows) {
        const created = await client.query<{ id: string }>(
          `INSERT INTO app_rate_rule (scope, seq, amount, product, currency, label, enabled, updated_at)
           VALUES ($1, $2, $3::numeric, $4, $5, $6, $7, now())
           RETURNING id::text`,
          [account, seq, rule.amount, product, rule.currency, rule.label, rule.enabled]
        );
        const id = created.rows[0].id;
        seq += 1;

        //conditions and filter references come with it, or the copy prices something else. The
        //India filter on a default is exactly the case that would otherwise be lost
        await client.query(
          `INSERT INTO app_rate_rule_condition (rule_id, seq, field, operator, value, negate)
           SELECT $1, seq, field, operator, value, negate
             FROM app_rate_rule_condition WHERE rule_id = $2`,
          [id, rule.id]
        );
        await client.query(
          `INSERT INTO app_rate_rule_filter (rule_id, filter_name, seq)
           SELECT $1, filter_name, seq FROM app_rate_rule_filter WHERE rule_id = $2`,
          [id, rule.id]
        );
      }
      applied.push(account);
    }

    return { applied, skipped };
  }).then(async (result) => {
    if (result.applied.length) {
      await auditConfigChange({
        domain: "rate_scope",
        name: product,
        action: "action:apply_default",
        after: { applied: result.applied, skipped: result.skipped.length },
      });
    }
    return result;
  });
}

/**
 * Replaces one scope's rules, preserving the id of every rule that survives.
 *
 * <p>The unit of write is the **scope**, not the rule, for three reasons. A reorder is several
 * statements that must not be seen half-done. Rate semantics are ordinal, so a rule has no meaning
 * apart from its neighbours and an endpoint that accepted rule 3 alone would let someone produce an
 * order nobody looked at. And one transaction is the only way the gateway's next poll cannot catch a
 * partial ordering.
 *
 * <h3>The position constraint is deferred</h3>
 *
 * <p>`UNIQUE (scope, seq)` is deferrable since gateway migration V1.75.0, so the transaction opens
 * with `SET CONSTRAINTS uq_app_rate_rule_seq DEFERRED` and each rule's seq is written straight to
 * its new position; the check runs once at commit, so two rules swapping places is fine. Before
 * V1.75.0 the constraint was checked per row and every survivor was parked at a negative seq first.
 *
 * <h3>What this does to `app_rate_rule_filter`</h3>
 *
 * <p>Rewrites it per rule, the same delete-and-reinsert as the conditions. Both are safe for the
 * same reasons: the key is `(rule_id, seq)`, nothing references either table, and the parent id is
 * stable because survivors are UPDATEd rather than deleted — so no cascade fires and a reorder never
 * disturbs them.
 *
 * <p><strong>This was previously a no-op, and the difference is worth stating.</strong> Until the
 * filter library had an editor, a rule's filters survived a save only as a side effect of its id
 * surviving; nothing here could add or remove one. Now that the picker exists, the rewrite is what
 * makes it work — and it must stay a rewrite rather than an append, because losing a filter
 * reference does not make a rule fail. It makes the rule match **more**, at whatever amount it was
 * carrying.
 */
export async function saveScope(scope: string, rules: RateRuleInput[]): Promise<void> {
  const before = await inTransaction(async (client) => {
    await assertProductsCatalogued(rules.map((r) => r.product), client);
    //the position constraint is checked at commit (deferrable since gateway V1.75.0), so each rule's
    //seq is written straight to its new value, swaps included
    await client.query("SET CONSTRAINTS uq_app_rate_rule_seq DEFERRED");
    //locks the rows so two saves of the same scope serialise. An empty result locks nothing, so two
    //simultaneous creations of a NEW scope can still collide on seq 0 -- one gets a duplicate-key
    //error, which is comprehensible and rare enough to leave
    //a platform's custom-tariff rules (managed_by, gateway V1.101.0) are not this form's to keep or
    //drop: they are never listed in it, so "delete what was not sent back" must not reach them
    const existing = await client.query<AuditRuleRow>(
      `SELECT id::text, seq, amount::text, product, enabled FROM app_rate_rule
        WHERE scope = $1 AND managed_by IS NULL ORDER BY seq FOR UPDATE`,
      [scope]
    );

    const live = new Set(existing.rows.map((r) => r.id));
    const keep = rules.map((r) => r.id).filter((id): id is number => id != null).map(String);
    for (const id of keep) {
      if (!live.has(id)) {
        throw new Error(
          `Rule ${id} is not part of '${scope}' any more. Reload the page — someone else has changed `
          + "this scope since it was opened."
        );
      }
    }

    //conditions and filter references cascade with the rules that are genuinely going away
    await client.query(
      `DELETE FROM app_rate_rule WHERE scope = $1 AND managed_by IS NULL AND NOT (id = ANY($2::bigint[]))`,
      [scope, keep]
    );

    for (let i = 0; i < rules.length; i++) {
      await writeRule(client, scope, i, rules[i], rules[i].product?.trim() || null);
    }
    return existing.rows.length ? scopeSummary(existing.rows) : null;
  });
  await auditConfigChange({
    domain: "rate_scope",
    name: scope,
    action: before ? "update" : "create",
    account: scopeAccount(scope),
    before,
    after: scopeSummary(rules),
  });
}

interface AuditRuleRow {
  id: string;
  seq: number;
  amount: string;
  product: string | null;
  enabled: boolean;
}

/**
 * A scope's rules for the audit line, in order, each as `product=amount` with a `-` when disabled.
 * The amount is the decimal string as stored, never a float, for the same reason the rest of this
 * module keeps it one.
 */
function scopeSummary(rules: readonly { amount: string; product: string | null; enabled: boolean }[]): ConfigSummary {
  return {
    count: rules.length,
    rules: rules.map((r) => `${r.enabled ? "" : "-"}${r.product?.trim() || "*"}=${r.amount}`),
  };
}

/**
 * The account a scope prices, so its pricing changes show in that account's activity.
 *
 * <p>A vendor's cost scope is the vendor's name and cannot be told from an account id without the
 * catalogues, so it is tagged too; the activity query joins on a real account id and a vendor name
 * matches nothing. The default scope prices everyone and is nobody's.
 */
function scopeAccount(scope: string): string | null {
  return scope === DEFAULT_SCOPE ? null : scope;
}

/**
 * One rule at one position, with its conditions and filter references rewritten.
 *
 * <p>Shared by the two save paths so a product-scoped write cannot drift from a whole-scope one in
 * what it does to the child tables — the filter rewrite in particular, where the failure mode is
 * silent: losing a filter reference does not make a rule fail, it makes the rule match **more**, at
 * whatever amount it was carrying.
 *
 * @param product written as given rather than taken from the rule, so the product-scoped path can
 *     assert the bucket a rule lands in instead of trusting a field the browser sent
 */
async function writeRule(
  client: PoolClient,
  scope: string,
  seq: number,
  rule: RateRuleInput,
  product: string | null
): Promise<void> {
  const values = [
    seq,
    rule.amount,
    product,
    rule.currency?.trim() || null,
    rule.label?.trim() || null,
    rule.enabled,
  ];

  let id: string;
  if (rule.id != null) {
    const updated = await client.query<{ id: string }>(
      `UPDATE app_rate_rule
          SET seq = $3, amount = $4::numeric, product = $5, currency = $6,
              label = $7, enabled = $8, updated_at = now()
        WHERE id = $2 AND scope = $1 AND managed_by IS NULL
        RETURNING id::text`,
      [scope, rule.id, ...values]
    );
    id = updated.rows[0].id;
    await client.query(`DELETE FROM app_rate_rule_condition WHERE rule_id = $1`, [id]);
    //filters too, now that they are editable. Before the filter library had an editor this
    //table was never touched here, and a rule's filters survived only because its id did
    await client.query(`DELETE FROM app_rate_rule_filter WHERE rule_id = $1`, [id]);
  } else {
    const created = await client.query<{ id: string }>(
      `INSERT INTO app_rate_rule (scope, seq, amount, product, currency, label, enabled, updated_at)
       VALUES ($1, $2, $3::numeric, $4, $5, $6, $7, now())
       RETURNING id::text`,
      [scope, ...values]
    );
    id = created.rows[0].id;
  }

  for (let c = 0; c < rule.conditions.length; c++) {
    const condition = rule.conditions[c];
    await client.query(
      `INSERT INTO app_rate_rule_condition (rule_id, seq, field, operator, value, negate)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [id, c, condition.field, condition.operator, condition.value ?? "", condition.negate]
    );
  }

  //deduplicated: the join table is keyed on (rule_id, seq), so the same filter twice would
  //insert cleanly and then apply its conditions twice -- harmless to matching, but it would
  //read as two references and inflate every usage count the filter library shows
  const names = [...new Set(rule.filters.map((f) => f.trim()).filter(Boolean))];
  for (let f = 0; f < names.length; f++) {
    await client.query(
      `INSERT INTO app_rate_rule_filter (rule_id, filter_name, seq) VALUES ($1, $2, $3)`,
      [id, names[f], f]
    );
  }
}

/**
 * Replaces what one scope charges for **one product**, and touches nothing else in the scope.
 *
 * <p>{@link saveScope} is the wrong tool wherever the operator is looking at a single product: it
 * deletes every rule it is not given. That is correct on `/cp/pricing`, whose form holds and displays
 * the whole scope before replacing it. On the product page it would mean that setting a `*` default
 * for one product deleted `*` for every other product on the platform — from a screen that never
 * named them, with a 200 in reply.
 *
 * <p>The arithmetic — what goes, what stays, and the position everything lands at — is
 * {@link planProductWrite}, which is pure and tested. This runs it inside one transaction, which is
 * what makes the reorder safe, with `UNIQUE (scope, seq)` deferred to commit exactly as `saveScope`
 * does and for the same reason.
 *
 * <p><strong>The product is written from the argument, not from each rule.</strong> A rule arriving
 * with some other product in its body lands in this product's bucket regardless, because the bucket
 * is what this endpoint is addressed to. Trusting the field instead would let a form on the `promo`
 * page write `transactional` prices that the page it was sent from would never show.
 */
export async function saveScopeForProduct(
  scope: string,
  product: string,
  rules: RateRuleInput[]
): Promise<void> {
  const target = product.trim();
  const before = await inTransaction(async (client) => {
    await assertProductsCatalogued([target, ...rules.map((r) => r.product)], client);
    await client.query("SET CONSTRAINTS uq_app_rate_rule_seq DEFERRED");
    //FOR UPDATE so two saves of the same scope serialise -- including a whole-scope save from
    ///cp/pricing running against a product-scoped one from here, which is the collision that
    //renumbers the same positions twice. A platform's tariff rules (managed_by) are neither kept nor
    //dropped here: they are not this page's
    const existing = await client.query<AuditRuleRow>(
      `SELECT id::text, seq, amount::text, product, enabled FROM app_rate_rule
        WHERE scope = $1 AND managed_by IS NULL ORDER BY seq FOR UPDATE`,
      [scope]
    );

    const plan = planProductWrite(
      existing.rows.map((r) => ({ id: Number(r.id), seq: r.seq, product: r.product })),
      target,
      rules
    );

    if (plan.deleteIds.length) {
      //conditions and filter references cascade with the rules that are genuinely going away
      await client.query(`DELETE FROM app_rate_rule WHERE id = ANY($1::bigint[])`, [
        plan.deleteIds.map(String),
      ]);
    }

    //the rules this save is not touching, back where they were relative to each other. Their
    //updated_at is deliberately left alone: nothing about them changed
    for (const placement of plan.keep) {
      await client.query(`UPDATE app_rate_rule SET seq = $2 WHERE id = $1`, [
        placement.id,
        placement.seq,
      ]);
    }

    for (const { rule, seq } of plan.writes) {
      await writeRule(client, scope, seq, rule, target);
    }
    //only this product's rules: the others in the scope are untouched and would only pad the line
    const mine = existing.rows.filter((r) => (r.product?.trim() || null) === target);
    return mine.length ? scopeSummary(mine) : null;
  });
  await auditConfigChange({
    domain: "rate_scope",
    name: `${scope} ${target}`,
    action: before ? "update" : "create",
    account: scopeAccount(scope),
    before,
    after: scopeSummary(rules.map((r) => ({ ...r, product: target }))),
  });
}

/**
 * Turns one rule off without moving anything.
 *
 * <p>No renumber is needed: `DbRateLoader` selects `WHERE enabled` and `RateSnapshot` sorts by `seq`,
 * so a gap changes nothing — only relative order matters.
 *
 * <p><strong>This should be the default way to stop a rule.</strong> The row and its id survive, so
 * every message it ever charged can still be traced back to it. Deleting is the rare path.
 *
 * @returns false when there is no such rule in this scope
 */
export async function setRuleEnabled(scope: string, id: number, enabled: boolean): Promise<boolean> {
  const rows = await configQuery<{ id: string; product: string | null; amount: string }>(
    `UPDATE app_rate_rule SET enabled = $3, updated_at = now()
      WHERE id = $2 AND scope = $1 AND managed_by IS NULL RETURNING id::text, product, amount::text`,
    [scope, id, enabled]
  );
  if (!rows.length) {
    return false;
  }
  await auditConfigChange({
    domain: "rate_scope",
    name: scope,
    action: enabled ? "enable" : "disable",
    account: scopeAccount(scope),
    after: { ruleId: id, product: rows[0].product, amount: rows[0].amount, enabled },
  });
  return true;
}

/**
 * @returns how many rules went, or null when the scope did not exist
 */
export async function deleteScope(scope: string): Promise<number | null> {
  const rows = await configQuery<AuditRuleRow>(
    `DELETE FROM app_rate_rule WHERE scope = $1 AND managed_by IS NULL
     RETURNING id::text, seq, amount::text, product, enabled`,
    [scope]
  );
  if (!rows.length) {
    return null;
  }
  rows.sort((a, b) => a.seq - b.seq);
  await auditConfigChange({
    domain: "rate_scope",
    name: scope,
    action: "delete",
    account: scopeAccount(scope),
    before: scopeSummary(rows),
  });
  return rows.length;
}

/**
 * Names for a set of rule ids, for anywhere that has an id and wants a sentence.
 *
 * <p>Best effort by design, and the caller is expected to catch. These ids come out of `cdr_submit`
 * on the metrics database and are looked up in `app_rate_rule` on the config database — possibly a
 * different server, possibly one this panel has no route to. A missing name renders as the id, which
 * is what the record itself holds.
 */
export async function ruleLabels(ids: string[]): Promise<Record<string, string>> {
  if (!ids.length) {
    return {};
  }
  const rows = await configQuery<{ id: string; scope: string; label: string | null; product: string | null }>(
    "SELECT id::text, scope, label, product FROM app_rate_rule WHERE id = ANY($1::bigint[])",
    [ids]
  );
  return Object.fromEntries(
    rows.map((r) => [r.id, r.label?.trim() || `${r.scope}${r.product ? ` · ${r.product}` : ""}`])
  );
}

/**
 * Which scopes price one product, as counts rather than as rules.
 *
 * <p>The replacement for {@link listRulesForProduct} on the product page. That function loads every
 * rule of every scope — it had to, because the editor it fed held a whole scope to save one — and at
 * a thousand customers the page stopped loading altogether. This is one aggregate with no ceiling;
 * the rules for a scope arrive when somebody opens that row. `listRulesForProduct` survives for the
 * CSV export and import, which genuinely do need everything.
 *
 * <p><strong>Both counts, and the difference between them is load bearing.</strong> `rules` is what
 * prices this product — its own rules plus the catch-alls, matching what `RateSnapshot.rulesFor`
 * assembles. `scopeRules` is everything in the scope. The editor shows the first and saves the
 * second, so their difference is exactly the "and N more that a save here also rewrites" warning,
 * which is the only thing standing between a filtered edit and a wholesale delete. It used to be
 * derived from having loaded everything; now it has to come from here.
 */
export async function listScopesForProduct(product: string): Promise<ProductScopeSummary[]> {
  return configQuery<{
    scope: string;
    rules: number;
    scope_rules: number;
    enabled_rules: number;
    specific: number;
    min_amount: string | null;
    max_amount: string | null;
  }>(
    `SELECT scope,
            count(*) FILTER (WHERE product = $1 OR product IS NULL OR product = '')::int AS rules,
            count(*)::int AS scope_rules,
            count(*) FILTER (WHERE enabled
                               AND (product = $1 OR product IS NULL OR product = ''))::int
              AS enabled_rules,
            count(*) FILTER (WHERE product = $1)::int AS specific,
            min(amount) FILTER (WHERE product = $1 OR product IS NULL OR product = '')::text
              AS min_amount,
            max(amount) FILTER (WHERE product = $1 OR product IS NULL OR product = '')::text
              AS max_amount
       FROM app_rate_rule
      GROUP BY scope
     HAVING count(*) FILTER (WHERE product = $1 OR product IS NULL OR product = '') > 0
      ORDER BY scope`,
    [product]
  ).then((rows) =>
    rows.map((r) => ({
      scope: r.scope,
      rules: r.rules,
      scopeRules: r.scope_rules,
      enabledRules: r.enabled_rules,
      //a scope reaching this product only through a catch-all prices everything, which is a
      //different statement from having priced this product deliberately
      specificToProduct: r.specific > 0,
      minAmount: r.min_amount,
      maxAmount: r.max_amount,
    }))
  );
}
