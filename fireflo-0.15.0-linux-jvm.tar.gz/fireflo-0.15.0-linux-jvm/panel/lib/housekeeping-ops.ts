import type { NextResponse } from "next/server";
import { gql } from "@/lib/gateway-graphql";
import { HOUSEKEEPING, REPUSH_CANCEL, REPUSH_JOB, REPUSH_START } from "@/lib/gateway-queries";
import type { CleanStore, HousekeepingRequest } from "@/lib/queue-clean";
import type { RepushRequest } from "@/lib/receipt-repush";

/**
 * The gateway calls behind queue cleaning and receipt re-push — and only those.
 *
 * <p>Server-only (the admin token is read from the environment). Kept apart from the routes so the
 * documents, tokens and timeouts the gateway's housekeeping fields need are in one small file: the
 * routes decide who may ask, these decide how the gateway is asked.
 *
 * <p>`passErrors` on all of them: the gateway's refusals here are sentences addressed to the operator
 * — UNSCOPED, "broker-backed", RUNNING when a re-push is already going for this login, DATABASE
 * (503) when the archive could not be written and everything was put back — and flattening them to
 * "could not reach the gateway" would hide the one thing that says what to do next. The status each
 * carries is the one the `/ops` route answered, so the dialogs keep their branches.
 */

/** `housekeeping(store, input)`, admin token. A dry run claims nothing. */
export function runHousekeeping(store: CleanStore, body: HousekeepingRequest): Promise<NextResponse> {
  return gql({
    query: HOUSEKEEPING,
    variables: { store, input: body },
    auth: "admin",
    //a batch of ten thousand is archived in one transaction and then closed out one by one
    timeoutMs: 120_000,
    passErrors: true,
  });
}

/** What `repushStart`, `repushJob` and `repushCancel` answer, camelCase as the dialog reads it. */
interface RepushJob {
  jobId: string | null;
  dryRun: boolean;
  preview: Record<string, unknown> | null;
  [key: string]: unknown;
}

/**
 * `repushStart(input)`, admin token: a dry run's counts, or the job as started (`{jobId, ...}`).
 *
 * <p>The REST route answered three shapes -- the preview object itself for a dry run, the job for
 * a start -- and the dialog reads them as such (`readRepushDryRun`, `readJobId`). The field answers
 * one `RepushJob` with `dryRun` and `preview`, so a dry run is unwrapped here to the preview the
 * dialog expects and a start is handed over as the job.
 */
export function startRepush(body: RepushRequest): Promise<NextResponse> {
  return gql<RepushJob>({
    query: REPUSH_START,
    variables: { input: body },
    auth: "admin",
    timeoutMs: 60_000,
    passErrors: true,
    select: (job) => (job.dryRun ? (job.preview ?? {}) : job),
  });
}

/** `repushJob(jobId)`, read token. */
export function repushStatus(jobId: string): Promise<NextResponse> {
  return gql({ query: REPUSH_JOB, variables: { jobId }, timeoutMs: 10_000, passErrors: true });
}

/** `repushCancel(jobId)`, admin token. */
export function cancelRepush(jobId: string): Promise<NextResponse> {
  return gql({ query: REPUSH_CANCEL, variables: { jobId }, auth: "admin", timeoutMs: 10_000, passErrors: true });
}
