/**
 * The period a page opens on: the one its user last chose, while it is still one of the page's
 * options, else the page's default -- the last hour on every traffic page.
 *
 * <p>Pure, so the rule is tested without a browser; `components/usePeriod.ts` reads and writes the
 * choice in `localStorage` under {@link periodKey}. A stored value no longer offered (an option
 * removed in a later release) is ignored rather than trusted.
 */
export function pickPeriod<T extends string>(stored: string | null, options: readonly T[], fallback: T): T {
  return stored !== null && (options as readonly string[]).includes(stored) ? (stored as T) : fallback;
}

/** Where a page keeps its period: one key per page, so Vendors at 7d leaves Receipts at 1h. */
export function periodKey(page: string): string {
  return `fireflo.period.${page}`;
}
