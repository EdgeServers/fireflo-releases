//with the extension, because `node --test` runs this module directly and does not resolve
//extensionless specifiers. Everything imported is pure data, so this stays importable by a client
//component and by the seed script alike
import { GATEWAY_SETTING_FIELDS } from "./gateway-setting-fields.ts";
import { SETTING_FIELDS, type SettingWidget } from "./setting-fields.ts";
import { settingLabel, type SettingKey } from "./labels.ts";

/**
 * What every gateway configuration key is -- the one list both the gateway and this panel read.
 *
 * <h2>Why it is a table</h2>
 *
 * <p>Whether a key is a credential, whether the panel may show or edit it, and what shape its value
 * has used to be written down five times: the gateway's `SensitiveLogSanitizer`, this panel's
 * `DENIED` map and substring list, its separate `SECRET_KEYS` for worker settings, the `secret`
 * widget kind in the setting catalogues, and the gateway's lenient value parsers. Two of those
 * disagreeing is how `smsg.ops.token` once reached the browser. Since gateway migration V1.61.0 the
 * facts live in `app_config_key`, the gateway masks what it says is secret, and this panel reads it
 * on the server and hands the verdicts to its screens.
 *
 * <h2>What stays in code, and why</h2>
 *
 * <ul>
 *   <li>{@link BUILTIN_REGISTRY}, below: what `app_config_key` was seeded from, and what this panel
 *       falls back to when it cannot read the table -- a gateway in file mode, or a role without the
 *       grant. It is generated from the same catalogues the forms render, so the two cannot drift;
 *       `scripts/config-key-registry-sql.ts` prints it as the migration's seed.</li>
 *   <li>The substring rule in `gateway-key-policy.ts` and the gateway's `isSensitiveKey`. A list
 *       only covers the keys somebody listed; a key nobody listed must still be caught by its name,
 *       the day it is added.</li>
 *   <li>Labels, hints and form layout. Those are this panel's presentation, not facts about the
 *       gateway; the registry carries a label only so a database reader can tell keys apart.</li>
 * </ul>
 */

/**
 * Why the panel will not write a key. The same reasons `gateway-key-policy.ts` has always given, plus
 * `retired` (gateway V1.88.0): the gateway no longer reads the key, so writing it changes nothing.
 */
export type DenialReason = "secret" | "config-source" | "wiring" | "elsewhere" | "licensing" | "prefix" | "retired";

/**
 * Whether the gateway still reads a key (`app_config_key.status`, gateway V1.88.0).
 *
 * <p>`current` is the default. `deprecated` is still read, but a better key exists and
 * `replacedBy` names it. `retired` is never read any more: setting it does nothing, and the panel
 * neither edits nor offers it. A registry read from a gateway older than V1.88.0 has no such
 * column, and every row then reads as `current` -- see {@link rowFromRecord}.
 */
export type KeyStatus = "current" | "deprecated" | "retired";

/** Where the key lives: `app_config` (platform), or a worker property (`app_worker_property`, and `outSms.default.<key>`). */
export type KeyScope = "platform" | "worker";

/** What the panel may do with it. */
export type KeyAccess = "editable" | "read-only" | "hidden";

export type KeyKind = SettingWidget["kind"];

export interface ConfigKeyRow {
  scope: KeyScope;
  key: string;
  kind: KeyKind;
  /** The values an `enum` accepts; null otherwise. */
  choices: string[] | null;
  /** `ms`, `s` or `min` for a number that is a duration; null otherwise. */
  unit: string | null;
  /** The literal the gateway parses when the key is absent; null when it has not been verified. */
  codedDefault: string | null;
  secret: boolean;
  access: KeyAccess;
  /** Why it is not editable; null when it is. */
  reason: DenialReason | null;
  label: string | null;
  /** Whether the gateway still reads it. `current` on every row from before V1.88.0. */
  status: KeyStatus;
  /** The key to use instead of a deprecated or retired one, when there is one. */
  replacedBy: string | null;
}

/**
 * Keys denied by name, with the reason. Moved here from `gateway-key-policy.ts` so the code holds one
 * list, and that list is the registry's seed; every entry is one `gateway-setting-fields.ts` argues
 * for in its header, and the key literals were read from the gateway source.
 */
const DENIED_PLATFORM: readonly {
  key: string;
  reason: DenialReason;
  label: string;
  /** For a key whose value is one of a few: the choices, and the first is the coded default. */
  choices?: string[];
}[] = [
  //the two secrets guarding the endpoint the panel authenticates to
  { key: "smsg.ops.token", reason: "secret", label: "Ops API token" },
  { key: "smsg.ops.admin.token", reason: "secret", label: "Ops API admin token" },

  { key: "smsg.config.source", reason: "config-source", label: "Where configuration is read from" },
  { key: "smsg.properties.file.path", reason: "config-source", label: "Properties file" },
  { key: "smsg.credentials.file.path", reason: "config-source", label: "Credentials file" },
  { key: "smsg.rates.file.path", reason: "config-source", label: "Rates file" },
  { key: "smsg.routing.file.path", reason: "config-source", label: "Routing file" },

  //set on the Queues page since V1.67.0, which also made it a checked choice; rabbitmq left the list
  //in gateway 0.14, which refuses to start on it
  { key: "smsg.queue.provider", reason: "elsewhere", label: "Queue backbone", choices: ["memory", "kafka"] },
  { key: "smsg.cdr.sink", reason: "wiring", label: "Where call records go" },
  //loosening an SSRF guard from a web form is not an operator convenience
  { key: "smsg.webhook.private.targets", reason: "wiring", label: "Webhooks to private addresses" },
  { key: "smsg.webhook.schemes", reason: "wiring", label: "Webhook URL schemes" },

  { key: "smsg.rates.currency", reason: "elsewhere", label: "Platform currency" },
  { key: "smsg.money.scale", reason: "elsewhere", label: "Decimal places shown" },
  { key: "smsg.billing.zone", reason: "elsewhere", label: "Billing time zone" },

  //the licensing namespace is denied as a prefix in gateway-key-policy.ts; these are the two keys in
  //it today, listed so a database reader sees them
  { key: "smsg.license.server.url", reason: "licensing", label: "Licence server" },
  { key: "smsg.license.directory", reason: "licensing", label: "Licence directory" },
];

/**
 * The Kafka backbone and cluster keys (gateway 0.14). Every one is owned by the Queues page's broker
 * card, which is why none is editable from the Gateway page: `elsewhere` for the card's own fields,
 * `wiring` for the two host paths, `secret` for the three passwords. Defaults are the gateway's
 * (`KafkaBackboneConfig`, `ClusterConfig`); `lib/broker-config.ts` carries the same values for the
 * form's placeholders, and the test holds the two together.
 */
const BACKBONE_PLATFORM: readonly {
  key: string; kind: KeyKind; choices?: string[]; unit?: string; codedDefault: string | null; reason: DenialReason; label: string;
}[] = [
  { key: "smsg.kafka.bootstrap.servers", kind: "text", codedDefault: null, reason: "elsewhere", label: "Kafka bootstrap servers" },
  { key: "smsg.kafka.security.protocol", kind: "enum", choices: ["PLAINTEXT", "SSL", "SASL_PLAINTEXT", "SASL_SSL"], codedDefault: "PLAINTEXT", reason: "elsewhere", label: "Kafka security protocol" },
  { key: "smsg.kafka.sasl.mechanism", kind: "enum", choices: ["PLAIN", "SCRAM-SHA-256", "SCRAM-SHA-512"], codedDefault: "SCRAM-SHA-512", reason: "elsewhere", label: "Kafka SASL mechanism" },
  { key: "smsg.kafka.sasl.username", kind: "text", codedDefault: null, reason: "elsewhere", label: "Kafka SASL user name" },
  { key: "smsg.kafka.sasl.password", kind: "secret", codedDefault: null, reason: "secret", label: "Kafka SASL password" },
  { key: "smsg.kafka.ssl.truststore.path", kind: "text", codedDefault: null, reason: "wiring", label: "Kafka TLS truststore" },
  { key: "smsg.kafka.ssl.truststore.password", kind: "secret", codedDefault: null, reason: "secret", label: "Kafka TLS truststore password" },
  { key: "smsg.kafka.ssl.keystore.path", kind: "text", codedDefault: null, reason: "wiring", label: "Kafka TLS keystore" },
  { key: "smsg.kafka.ssl.keystore.password", kind: "secret", codedDefault: null, reason: "secret", label: "Kafka TLS keystore password" },
  { key: "smsg.kafka.topic.prefix", kind: "text", codedDefault: "fireflo.", reason: "elsewhere", label: "Kafka topic prefix" },
  { key: "smsg.kafka.group.prefix", kind: "text", codedDefault: "fireflo-", reason: "elsewhere", label: "Kafka consumer group prefix" },
  { key: "smsg.kafka.topics.create", kind: "boolean", codedDefault: "true", reason: "elsewhere", label: "Create Kafka topics at startup" },
  { key: "smsg.kafka.partitions.router", kind: "number", codedDefault: "24", reason: "elsewhere", label: "Router topic partitions" },
  { key: "smsg.kafka.partitions.vendor", kind: "number", codedDefault: "6", reason: "elsewhere", label: "Vendor topic partitions" },
  { key: "smsg.kafka.partitions.retry", kind: "number", codedDefault: "6", reason: "elsewhere", label: "Retry topic partitions" },
  { key: "smsg.kafka.partitions.webhook", kind: "number", codedDefault: "12", reason: "elsewhere", label: "Webhook topic partitions" },
  { key: "smsg.kafka.replication.factor", kind: "number", codedDefault: "-1", reason: "elsewhere", label: "Topic replication factor (-1 = broker default)" },
  { key: "smsg.kafka.retention.hours", kind: "number", codedDefault: "168", reason: "elsewhere", label: "Topic retention (hours)" },
  { key: "smsg.kafka.compression", kind: "enum", choices: ["none", "lz4", "gzip"], codedDefault: "lz4", reason: "elsewhere", label: "Kafka compression" },
  { key: "smsg.kafka.produce.timeout.ms", kind: "number", unit: "ms", codedDefault: "5000", reason: "elsewhere", label: "Produce timeout" },
  { key: "smsg.kafka.produce.block.ms", kind: "number", unit: "ms", codedDefault: "500", reason: "elsewhere", label: "Produce block time" },
  { key: "smsg.kafka.router.inflight", kind: "number", codedDefault: "1000", reason: "elsewhere", label: "Router messages in flight" },
  { key: "smsg.kafka.router.transactions", kind: "boolean", codedDefault: "true", reason: "elsewhere", label: "Router transactions (exactly once)" },
  { key: "smsg.kafka.router.txn.interval.ms", kind: "number", unit: "ms", codedDefault: "100", reason: "elsewhere", label: "Router transaction interval" },
  { key: "smsg.kafka.router.txn.max.records", kind: "number", codedDefault: "200", reason: "elsewhere", label: "Router records per transaction" },
  { key: "smsg.kafka.router.txn.timeout.ms", kind: "number", unit: "ms", codedDefault: "30000", reason: "elsewhere", label: "Router transaction timeout" },
  { key: "smsg.kafka.router.producer.buffer.bytes", kind: "number", codedDefault: "8388608", reason: "elsewhere", label: "Router producer buffer (bytes)" },
  { key: "smsg.kafka.vendor.inflight", kind: "number", codedDefault: "200", reason: "elsewhere", label: "Vendor messages in flight" },
  { key: "smsg.kafka.vendor.settle", kind: "enum", choices: ["on-submit", "on-response"], codedDefault: "on-submit", reason: "elsewhere", label: "When a message counts as handed over" },
  { key: "smsg.webhook.inflight", kind: "number", codedDefault: "1000", reason: "elsewhere", label: "Webhook calls in flight (Kafka mode)" },
  { key: "smsg.kafka.ingress.lag.highwater", kind: "number", codedDefault: "100000", reason: "elsewhere", label: "Ingress pauses above this router lag" },
  { key: "smsg.cluster.heartbeat.seconds", kind: "number", unit: "s", codedDefault: "5", reason: "elsewhere", label: "Cluster heartbeat" },
  { key: "smsg.cluster.node.timeout.seconds", kind: "number", unit: "s", codedDefault: "30", reason: "elsewhere", label: "Node considered dead after" },
  { key: "smsg.cluster.lease.ttl.seconds", kind: "number", unit: "s", codedDefault: "30", reason: "elsewhere", label: "Vendor lease TTL" },
  { key: "smsg.cluster.lease.renew.seconds", kind: "number", unit: "s", codedDefault: "10", reason: "elsewhere", label: "Vendor lease renewal" },
  { key: "smsg.cluster.rebalance.grace.seconds", kind: "number", unit: "s", codedDefault: "60", reason: "elsewhere", label: "Rebalance grace" },
];

/**
 * Platform keys gateway 0.14 stopped reading: the RabbitMQ bridge's, the receipt forwarder's own
 * queue and the REST batch queue, all of which the Kafka backbone replaced. A row is kept so a
 * database reader sees the key, with its successor where one key took over one job; the rest have
 * no counterpart -- their work is a topic the gateway names itself. `smsg.restapi.batch.queue.highwater`
 * is not here: the gateway still reads it (since 0.14.2 it paces a batch against the backlog), so it
 * is a REST field in gateway-setting-fields.ts.
 */
const RETIRED_PLATFORM: readonly { key: string; kind: KeyKind; label: string; replacedBy: string | null; secret?: true }[] = [
  //carried a password in its userinfo, and is still masked for the sake of any row left behind
  { key: "smsg.queue.amqp.uri", kind: "text", label: "Message broker address (RabbitMQ, retired)", replacedBy: "smsg.kafka.bootstrap.servers", secret: true },
  { key: "smsg.queue.amqp.queue", kind: "text", label: "Broker queue name (retired)", replacedBy: "smsg.kafka.topic.prefix" },
  { key: "smsg.queue.amqp.prefetch", kind: "number", label: "Broker prefetch (retired)", replacedBy: null },
  { key: "smsg.queue.amqp.channels", kind: "number", label: "Broker publish channels (retired)", replacedBy: null },
  { key: "smsg.queue.amqp.highwater", kind: "number", label: "Broker high-water mark (retired)", replacedBy: "smsg.kafka.ingress.lag.highwater" },
  { key: "smsg.queue.amqp.dedup.size", kind: "number", label: "Broker de-duplication window (retired)", replacedBy: null },
  { key: "smsg.queue.amqp.publish.confirm.ms", kind: "number", label: "Broker publish confirm timeout (retired)", replacedBy: null },
  { key: "smsg.queue.amqp.ack.batch", kind: "number", label: "Broker ack batch (retired)", replacedBy: null },
  { key: "smsg.queue.amqp.ack.linger.ms", kind: "number", label: "Broker ack linger (retired)", replacedBy: null },
  { key: "smsg.dlr.forward.queue", kind: "text", label: "Receipt forwarder queue (retired)", replacedBy: null },
  { key: "smsg.dlr.forward.channels", kind: "number", label: "Receipt forwarder channels (retired)", replacedBy: null },
  { key: "smsg.restapi.batch.queue", kind: "text", label: "REST batch queue (retired)", replacedBy: null },
  { key: "smsg.restapi.batch.prefetch", kind: "number", label: "REST batch prefetch (retired)", replacedBy: null },
];

/** Settable despite carrying neither writable prefix -- see `LEGACY_WRITABLE` in gateway-key-policy.ts. */
const LEGACY_PLATFORM: readonly { key: string; label: string; kind: KeyKind; choices: string[] | null; codedDefault: string | null }[] = [
  { key: "message.trace.mode", label: "Message trace", kind: "text", choices: null, codedDefault: null },
];

/**
 * The rows gateway migration V1.88.0 added: keys the gateway warns about and never (or no longer)
 * reads. Carried here so a panel talking to a database from before that migration still knows them
 * -- they are the same three `DEAD_KEYS` the worker form has refused for years, plus the one switch
 * V1.38.0 translated into `whitelist.tlvs.mode`.
 */
const STATUS_WORKER: readonly {
  key: string; kind: KeyKind; codedDefault: string | null; label: string; status: KeyStatus; replacedBy: string | null;
}[] = [
  { key: "srv.host", kind: "text", codedDefault: null, label: "Listener bind address (never had an effect)", status: "retired", replacedBy: null },
  { key: "srv.tls.host", kind: "text", codedDefault: null, label: "TLS listener bind address (never had an effect)", status: "retired", replacedBy: null },
  { key: "conf.sleepWindow", kind: "number", codedDefault: null, label: "Sleep window (never had an effect)", status: "retired", replacedBy: null },
  { key: "whitelist.tlvs.replace", kind: "boolean", codedDefault: "false", label: "Replace approved TLVs (old switch)", status: "deprecated", replacedBy: "whitelist.tlvs.mode" },
];

function shape(widget: SettingWidget): Pick<ConfigKeyRow, "kind" | "choices" | "unit"> {
  return {
    kind: widget.kind,
    choices: widget.kind === "enum" ? widget.options.map((o) => o.value) : null,
    unit: widget.kind === "number" ? widget.unit ?? null : null,
  };
}

function build(): ConfigKeyRow[] {
  const rows: ConfigKeyRow[] = [];
  for (const d of DENIED_PLATFORM) {
    rows.push({
      scope: "platform", key: d.key, kind: d.choices ? "enum" : "text", choices: d.choices ?? null, unit: null,
      codedDefault: d.choices?.[0] ?? null,
      secret: d.reason === "secret",
      //a secret is withheld in both directions; every other denial is shown and not written
      access: d.reason === "secret" ? "hidden" : "read-only",
      reason: d.reason, label: d.label, status: "current", replacedBy: null,
    });
  }
  for (const b of BACKBONE_PLATFORM) {
    const secret = b.reason === "secret";
    rows.push({
      scope: "platform", key: b.key, kind: b.kind, choices: b.choices ?? null, unit: b.unit ?? null,
      codedDefault: b.codedDefault, secret, access: secret ? "hidden" : "read-only",
      reason: b.reason, label: b.label, status: "current", replacedBy: null,
    });
  }
  for (const r of RETIRED_PLATFORM) {
    //a retired secret stays hidden: the gateway no longer reads it, but a row left behind still
    //holds what it held
    const secret = r.secret === true;
    rows.push({
      scope: "platform", key: r.key, kind: r.kind, choices: null, unit: null, codedDefault: null,
      secret, access: secret ? "hidden" : "read-only", reason: secret ? "secret" : "retired",
      label: r.label, status: "retired", replacedBy: r.replacedBy,
    });
  }
  for (const f of GATEWAY_SETTING_FIELDS) {
    rows.push({
      scope: "platform", key: f.key, ...shape(f.widget), codedDefault: f.codedDefault,
      secret: f.widget.kind === "secret", access: f.widget.kind === "secret" ? "hidden" : "editable",
      reason: f.widget.kind === "secret" ? "secret" : null, label: f.label, status: "current", replacedBy: null,
    });
  }
  for (const l of LEGACY_PLATFORM) {
    rows.push({
      scope: "platform", key: l.key, kind: l.kind, choices: l.choices, unit: null, codedDefault: l.codedDefault,
      secret: false, access: "editable", reason: null, label: l.label, status: "current", replacedBy: null,
    });
  }
  for (const key of Object.keys(SETTING_FIELDS) as SettingKey[]) {
    const f = SETTING_FIELDS[key];
    const secret = f.widget.kind === "secret";
    rows.push({
      scope: "worker", key, ...shape(f.widget), codedDefault: f.codedDefault ?? null,
      secret,
      //a worker secret is written through the worker form's own kept/set protocol and never shown;
      //a key another screen owns is still editable -- that is the screen's business, not a denial
      access: secret ? "hidden" : "editable",
      reason: secret ? "secret" : null,
      label: settingLabel(key).label,
      status: "current", replacedBy: null,
    });
  }
  for (const w of STATUS_WORKER) {
    //a retired key is shown and not offered (read-only, reason retired); a deprecated one still
    //works and stays editable, exactly as the migration seeds them
    const retired = w.status === "retired";
    rows.push({
      scope: "worker", key: w.key, kind: w.kind, choices: null, unit: null, codedDefault: w.codedDefault,
      secret: false, access: retired ? "read-only" : "editable", reason: retired ? "retired" : null,
      label: w.label, status: w.status, replacedBy: w.replacedBy,
    });
  }
  return rows;
}

/**
 * One `app_config_key` row as the database returns it, in either shape the table has had.
 *
 * <p>Before gateway V1.88.0 the table had no `status` or `replaced_by`; a panel reading such a table
 * sees neither column, and every key is then `current` with no successor. Tolerating the absence
 * here, rather than failing the whole read, is what keeps the registry (and so the secret masking it
 * drives) working across a gateway update that has not happened yet.
 */
export function rowFromRecord(r: Record<string, unknown>): ConfigKeyRow {
  const status = r.status;
  return {
    scope: r.scope as KeyScope,
    key: String(r.key),
    kind: r.kind as KeyKind,
    choices: Array.isArray(r.choices) ? (r.choices as string[]) : null,
    unit: typeof r.unit === "string" ? r.unit : null,
    codedDefault: typeof r.coded_default === "string" ? r.coded_default : null,
    secret: r.secret === true,
    access: r.access as KeyAccess,
    reason: (r.reason as DenialReason | null | undefined) ?? null,
    label: typeof r.label === "string" ? r.label : null,
    status: status === "deprecated" || status === "retired" ? status : "current",
    replacedBy: typeof r.replaced_by === "string" && r.replaced_by.trim() !== "" ? r.replaced_by : null,
  };
}

/** What a screen does about a key's status: the chip to show, and whether an editor may be offered. */
export interface StatusVerdict {
  status: KeyStatus;
  replacedBy: string | null;
  /** False only for a retired key: the gateway no longer reads it, so an editor would be a lie. */
  editable: boolean;
  /** The sentence beside the key, or null for a current key, which says nothing. */
  notice: string | null;
}

const CURRENT: StatusVerdict = { status: "current", replacedBy: null, editable: true, notice: null };

/**
 * The status verdict for a key, by scope.
 *
 * <p>A worker key may be asked for by its bare name (`srv.host`) or as its gateway-wide default
 * (`outSms.default.srv.host`); both answer the same. A key the registry has never heard of is
 * current: the registry says when a key is retired, never that an unknown one is.
 */
export function statusOf(registry: ConfigKeyRegistry, scope: KeyScope, key: string): StatusVerdict {
  const bare = scope === "worker" && key.startsWith("outSms.default.") ? key.slice("outSms.default.".length) : key;
  const row = (scope === "platform" ? registry.platform : registry.worker).get(bare.trim());
  return row ? statusVerdict(row) : CURRENT;
}

/** The verdict for one row. Pure, so the sentence is decided once for every screen. */
export function statusVerdict(row: Pick<ConfigKeyRow, "status" | "replacedBy">): StatusVerdict {
  switch (row.status) {
    case "retired":
      return {
        status: "retired", replacedBy: row.replacedBy, editable: false,
        notice: row.replacedBy ? `Retired — has no effect. Use ${row.replacedBy}.` : "Retired — has no effect",
      };
    case "deprecated":
      return {
        status: "deprecated", replacedBy: row.replacedBy, editable: true,
        notice: row.replacedBy ? `Deprecated: use ${row.replacedBy}` : "Deprecated",
      };
    default:
      return CURRENT;
  }
}

/** The registry as an index, which is the shape every reader wants. */
export interface ConfigKeyRegistry {
  rows: readonly ConfigKeyRow[];
  platform: ReadonlyMap<string, ConfigKeyRow>;
  worker: ReadonlyMap<string, ConfigKeyRow>;
  /** Where these rows came from, so a screen can say when it is showing the fallback. */
  source: "database" | "builtin";
}

export function registryFrom(rows: readonly ConfigKeyRow[], source: ConfigKeyRegistry["source"]): ConfigKeyRegistry {
  return {
    rows,
    platform: new Map(rows.filter((r) => r.scope === "platform").map((r) => [r.key, r])),
    worker: new Map(rows.filter((r) => r.scope === "worker").map((r) => [r.key, r])),
    source,
  };
}

/** What `app_config_key` was seeded from, and the fallback when it cannot be read. */
export const BUILTIN_REGISTRY: ConfigKeyRegistry = registryFrom(build(), "builtin");

/** Whether a worker setting key holds a credential, by the registry -- the replacement for `SECRET_KEYS`. */
export function isSecretWorkerKey(registry: ConfigKeyRegistry, key: string): boolean {
  return registry.worker.get(key)?.secret ?? false;
}
