import { strict as assert } from "node:assert";
import { after, before, describe, test } from "node:test";

import { carriesMoney, messageRows, partOne } from "./cdr-grain.ts";
import {
  HOURLY_SETTLE_MINUTES,
  STATEMENT_CUT_SQL,
  STATEMENT_HOURLY_CUT_SQL,
  statementSummarySql,
  summariseStatement,
  summaryParams,
  type StatementCut,
  type StatementDayProductRow,
} from "./statement-sql.ts";
import { OUTCOME_LATERAL } from "./usage-summary-sql.ts";

const norm = (sql: string) => sql.replace(/\s+/g, " ").trim();

test("the summary never probes the call records for each usage_daily line", () => {
  //the NOT EXISTS on a function of submitted_at was what no index served and what defeated
  //partition pruning: the statement that timed out on every production account
  const sql = norm(statementSummarySql({ vendorAttempt: true }));
  assert.doesNotMatch(sql, /NOT EXISTS/);
  assert.doesNotMatch(sql, /AT TIME ZONE \$4\)::date = u\.day/);
});

test("both live ranges are bare bounds on submitted_at, from plain binds", () => {
  const sql = norm(statementSummarySql({ vendorAttempt: true }));
  assert.match(sql, /s\.account_id = \$1 AND s\.submitted_at >= \$2 AND s\.submitted_at < \$3/);
  assert.match(sql, /s\.account_id = \$1 AND s\.submitted_at >= \$5 AND s\.submitted_at < \$6/);
  //the summary days between them, by their own key and nothing else
  assert.match(sql, /u\.account_id = \$1 AND u\.day >= \$7::date AND u\.day < \$8::date/);
});

test("the outcome rule and the counts are the ones every reader uses", () => {
  const sql = norm(statementSummarySql({ vendorAttempt: true }));
  assert.ok(sql.includes(norm(OUTCOME_LATERAL)), "the shared outcome LATERAL, unchanged");
  assert.match(sql, /DISTINCT ON \(s\.gateway_msg_id\)/);
  assert.match(sql, /o\.final_state IN \('FAILED', 'REJECTED', 'DROPPED'\)\) AS failed/);
  //no body or TLVs through the sort
  assert.doesNotMatch(sql, /s\.\*\s+FROM cdr_submit/);
  //a gateway before V1.40.0 has no vendor_attempt, and naming it there is a hard error
  assert.doesNotMatch(norm(statementSummarySql({ vendorAttempt: false })), /vendor_attempt/);
});

test("the cut falls back from the cursor to the account's newest line, then to the whole window live", () => {
  const sql = norm(STATEMENT_CUT_SQL);
  assert.match(sql, /COALESCE\(GREATEST\(\$5::date, \(SELECT max\(u\.day\) FROM usage_daily u WHERE u\.account_id = \$1\)\), '-infinity'::date\)/);
  assert.match(sql, /make_interval\(hours => \$6::int\)/);
  assert.match(sql, /GREATEST\(w\.first_full, LEAST\(w\.end_day, w\.rolled_to, w\.settling_from\)\)/);
});

test("summaryParams hands the cut's values over in bind order", () => {
  const since = new Date("2026-01-01T00:00:00Z");
  const until = new Date("2026-02-01T00:00:00Z");
  const cut: StatementCut = { first_full: "2026-01-01", boundary: "2026-01-25", head_until: since, tail_from: "x" };
  assert.deepEqual(summaryParams("acme", since, until, "UTC", cut),
    ["acme", since, since, "UTC", "x", until, "2026-01-01", "2026-01-25"]);
});

test("usage_hourly is named only when the hourly half is asked for", () => {
  //a gateway before V1.91.0 has no such table, and naming it there is a hard error
  assert.doesNotMatch(statementSummarySql({ vendorAttempt: true }), /usage_hourly/);
  const sql = norm(statementSummarySql({ vendorAttempt: true }, { hourly: true }));
  assert.match(sql, /h\.account_id = \$1 AND h\.hour >= \$9::timestamptz AND h\.hour < \$5::timestamptz/);
  //the live tail opens at the seam the hourly half closes at
  assert.match(sql, /s\.submitted_at >= \$5 AND s\.submitted_at < \$6/);
});

test("summaryParams puts the seam where the tail starts, and B ninth", () => {
  const since = new Date("2026-01-01T00:00:00Z");
  const until = new Date("2026-02-01T00:00:00Z");
  const cut: StatementCut = { first_full: "2026-01-01", boundary: "2026-01-25", head_until: since, tail_from: "B" };
  assert.deepEqual(summaryParams("acme", since, until, "UTC", cut, "S"),
    ["acme", since, since, "UTC", "S", until, "2026-01-01", "2026-01-25", "B"]);
});

test("an hour is trusted only once its rows were computed whole well after it ended", () => {
  const sql = norm(STATEMENT_HOURLY_CUT_SQL);
  assert.match(sql, /g\.h \+ interval '1 hour' > w\.hwm OR x\.computed < g\.h \+ interval '1 hour' \+ make_interval\(mins => \$5::int\)/);
  //rows of refusals or attempts alone are never re-stamped by a restate, so they are not asked
  assert.match(sql, /u\.submitted > 0/);
  assert.match(sql, /% 3600 <> 0/);
});

function row(over: Partial<StatementDayProductRow>): StatementDayProductRow {
  return {
    day: "2026-01-02", product: "p1", submitted: "10", delivered: "7", failed: "1", expired: "1",
    pending: "1", unrated: "0", amount: "5000", from_summary: "0", ...over,
  };
}

test("lines, days and totals all come from the same rows", () => {
  const { lines, days, daysFromSummary } = summariseStatement([
    row({ day: "2026-01-02", product: "p1", from_summary: "1" }),
    row({ day: "2026-01-02", product: "", amount: "9000", unrated: "2", from_summary: "1" }),
    row({ day: "2026-01-03", product: "p1", submitted: "4", delivered: "4", failed: "0", expired: "0", pending: "0", amount: "2000" }),
  ]);
  //the biggest bill first
  assert.deepEqual(lines.map((l) => [l.product, l.submitted, l.amount]), [["", 10, 9000], ["p1", 14, 7000]]);
  assert.deepEqual(days.map((d) => d.day), ["2026-01-02", "2026-01-03"]);
  //failed on a day is failed and expired together, as /cp/usage draws it
  assert.equal(days[0].failed, 4);
  assert.equal(days[0].price, 14_000);
  assert.equal(daysFromSummary, 1, "one day from the summary, however many products it had");
  const total = (k: "submitted" | "amount") => lines.reduce((n, l) => n + l[k], 0);
  assert.equal(total("amount"), days.reduce((n, d) => n + d.price, 0));
  assert.equal(total("submitted"), days.reduce((n, d) => n + d.submitted, 0));
});

/**
 * Against a real PostgreSQL, when one is given: the split gives the same bill as the statement it
 * replaced, on a month spanning the rollup boundary with a purged day in it.
 *
 * <p>`STATEMENT_TEST_DATABASE_URL` names a database this test may create and drop a schema in. It
 * builds the few columns the statement reads, not the gateway's schema; nothing else is touched.
 */
const URL = process.env.STATEMENT_TEST_DATABASE_URL;

/** The statement this replaced, verbatim but for the helpers it was built from. */
function oldSummarySql(): string {
  const one = partOne();
  const money = carriesMoney();
  return `WITH live AS (
         SELECT COALESCE(s.product, '') AS product,
                count(*) FILTER (WHERE ${one}) AS submitted,
                count(*) FILTER (WHERE ${one} AND o.final_state = 'DELIVERED') AS delivered,
                count(*) FILTER (WHERE ${one} AND o.final_state IN ('FAILED', 'REJECTED', 'DROPPED')) AS failed,
                count(*) FILTER (WHERE ${one} AND o.final_state = 'EXPIRED') AS expired,
                count(*) FILTER (WHERE ${one} AND o.final_state IS NULL) AS pending,
                count(*) FILTER (WHERE ${one} AND s.price IS NULL) AS unrated,
                COALESCE(SUM(s.price) FILTER (WHERE ${money}), 0) AS amount,
                0 AS from_summary
           FROM ${messageRows("s.account_id = $1 AND s.submitted_at >= $2 AND s.submitted_at < $3", { vendorAttempt: true })}${OUTCOME_LATERAL}
          GROUP BY COALESCE(s.product, '')
     ),
     purged AS (
         SELECT u.product, SUM(u.submitted) AS submitted, SUM(u.delivered) AS delivered,
                SUM(u.failed) AS failed, SUM(u.expired) AS expired, SUM(u.pending_at_rollup) AS pending,
                SUM(u.unrated_messages) AS unrated, SUM(u.price_total) AS amount,
                count(DISTINCT u.day) AS from_summary
           FROM usage_daily u
          WHERE u.account_id = $1
            AND u.day >= ($2 AT TIME ZONE $4)::date
            AND u.day <= ($3 AT TIME ZONE $4)::date
            AND NOT EXISTS (
                    SELECT 1 FROM cdr_submit s2
                     WHERE s2.account_id = u.account_id
                       AND (s2.submitted_at AT TIME ZONE $4)::date = u.day)
          GROUP BY u.product
     )
     SELECT product, SUM(submitted) AS submitted, SUM(delivered) AS delivered, SUM(failed) AS failed,
            SUM(expired) AS expired, SUM(pending) AS pending, SUM(unrated) AS unrated,
            SUM(amount) AS amount
       FROM (SELECT * FROM live UNION ALL SELECT * FROM purged) sources
      GROUP BY product
      ORDER BY 8 DESC, 1`;
}

/** `UsageRollup.ROLLUP_SQL`'s counting, over the fixture's columns, for days [$2, $3] in zone $1. */
const ROLLUP = `
  INSERT INTO usage_daily (account_id, day, product, submitted, delivered, failed, expired,
                           pending_at_rollup, unrated_messages, price_total)
  SELECT COALESCE(s.account_id, ''), (s.submitted_at AT TIME ZONE $1)::date, COALESCE(s.product, ''),
         count(*),
         count(*) FILTER (WHERE o.final_state = 'DELIVERED'),
         count(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED')),
         count(*) FILTER (WHERE o.final_state = 'EXPIRED'),
         count(*) FILTER (WHERE o.final_state IS NULL),
         count(*) FILTER (WHERE s.price IS NULL),
         COALESCE(SUM(s.price), 0)
    FROM (SELECT DISTINCT ON (c.gateway_msg_id) c.*
            FROM cdr_submit c
           WHERE c.part_no = 1
             AND (c.submitted_at AT TIME ZONE $1)::date >= $2::date
             AND (c.submitted_at AT TIME ZONE $1)::date <= $3::date
           ORDER BY c.gateway_msg_id, (c.price IS NULL), c.retry_count DESC, c.vendor_attempt DESC) s
    LEFT JOIN LATERAL (
         SELECT f.final_state FROM cdr_final f
          WHERE f.gateway_msg_id = s.gateway_msg_id AND f.part_no = s.part_no
          ORDER BY (f.final_state = 'EXPIRED'), f.final_at LIMIT 1) o ON TRUE
   GROUP BY 1, 2, 3`;

describe("the split against PostgreSQL", { skip: URL ? false : "STATEMENT_TEST_DATABASE_URL is not set" }, () => {
  const ZONE = "Asia/Kolkata";
  const SCHEMA = `stmt_split_${process.pid}`;
  let pool: import("pg").Pool;

  async function run<T>(sql: string, params: unknown[] = []): Promise<T[]> {
    return (await pool.query(sql, params)).rows as T[];
  }

  /** The new path, as `statementSummary` runs it: the cut, then the summary over its binds. */
  async function newSummary(since: Date, until: Date, lastDaily: string | null) {
    const [cut] = await run<StatementCut>(STATEMENT_CUT_SQL, ["acme", since, until, ZONE, lastDaily, 24]);
    const rows = await run<StatementDayProductRow>(statementSummarySql({ vendorAttempt: true }),
      summaryParams("acme", since, until, ZONE, cut));
    return { cut, ...summariseStatement(rows) };
  }

  async function oldSummary(since: Date, until: Date) {
    const rows = await run<Record<string, string>>(oldSummarySql(), ["acme", since, until, ZONE]);
    return rows.map((r) => ({
      product: r.product, submitted: Number(r.submitted), delivered: Number(r.delivered),
      failed: Number(r.failed), expired: Number(r.expired), pending: Number(r.pending),
      unrated: Number(r.unrated), amount: Number(r.amount),
    }));
  }

  /** A billing-zone instant: `2026-01-10 23:50` in Kolkata. */
  const at = (local: string) => new Date(`${local}:00+05:30`);

  before(async () => {
    const pg = (await import("pg")).default;
    pool = new pg.Pool({ connectionString: URL, max: 1, options: `-c search_path=${SCHEMA}` });
    await run(`CREATE SCHEMA ${SCHEMA}`);
    await run(`CREATE TABLE cdr_submit (
                 id bigserial PRIMARY KEY, gateway_msg_id text NOT NULL, part_no int NOT NULL DEFAULT 1,
                 account_id text, product text, submitted_at timestamptz NOT NULL, price bigint, cost bigint,
                 retry_count int NOT NULL DEFAULT 0, vendor_attempt int NOT NULL DEFAULT 0)`);
    await run(`CREATE TABLE cdr_final (
                 gateway_msg_id text NOT NULL, part_no int NOT NULL DEFAULT 1, final_state text NOT NULL,
                 final_at timestamptz NOT NULL, dlr_state int, err_code text)`);
    await run(`CREATE TABLE usage_daily (
                 account_id text NOT NULL, day date NOT NULL, product text NOT NULL,
                 submitted bigint NOT NULL, delivered bigint NOT NULL, failed bigint NOT NULL,
                 expired bigint NOT NULL, pending_at_rollup bigint NOT NULL,
                 unrated_messages bigint NOT NULL, price_total bigint NOT NULL,
                 PRIMARY KEY (account_id, day, product))`);

    let n = 0;
    async function message(o: { at: Date; product?: string | null; price?: number | null; outcome?: string[];
      failover?: boolean; account?: string }) {
      const id = `m${++n}`;
      const product = o.product === undefined ? "p1" : o.product;
      const account = o.account ?? "acme";
      if (o.failover) {
        //a refused first attempt, no price, then the accepted one that carries the money
        await run("INSERT INTO cdr_submit (gateway_msg_id, account_id, product, submitted_at, price, vendor_attempt) VALUES ($1, $2, $3, $4, NULL, 0)",
          [id, account, product, o.at]);
      }
      await run("INSERT INTO cdr_submit (gateway_msg_id, account_id, product, submitted_at, price, vendor_attempt) VALUES ($1, $2, $3, $4, $5, $6)",
        [id, account, product, o.at, o.price === undefined ? 500 : o.price, o.failover ? 1 : 0]);
      for (const [i, state] of (o.outcome ?? []).entries()) {
        await run("INSERT INTO cdr_final (gateway_msg_id, final_state, final_at) VALUES ($1, $2, $3)",
          [id, state, new Date(o.at.getTime() + (i + 1) * 60_000)]);
      }
    }

    for (let d = 1; d <= 28; d++) {
      const day = `2026-01-${String(d).padStart(2, "0")}`;
      await message({ at: at(`${day} 09:00`), outcome: ["DELIVERED"] });
      await message({ at: at(`${day} 10:00`), product: null, price: 1200, outcome: ["FAILED"], failover: d % 3 === 0 });
      if (d % 4 === 0) {
        //a swept EXPIRED and then the real receipt: the real one wins
        await message({ at: at(`${day} 11:00`), product: "p2", price: 800, outcome: ["EXPIRED", "DELIVERED"] });
      }
      if (d % 5 === 0) {
        await message({ at: at(`${day} 12:00`), product: "p2", price: null, outcome: ["EXPIRED"] });
      }
      if (d % 7 === 0) {
        await message({ at: at(`${day} 13:00`), product: "p1", price: 500 });
      }
    }
    //late on the 10th in Kolkata, which is still the 10th's line though it is 18:20 UTC
    await message({ at: at("2026-01-10 23:50"), outcome: ["DELIVERED"] });
    //early on the 1st, before 05:30: inside a Kolkata month, outside a UTC-midnight window
    await message({ at: at("2026-01-01 02:00"), product: "p2", price: 300, outcome: ["DELIVERED"] });
    //another account and the next month, which must count nowhere
    await message({ at: at("2026-01-12 09:00"), account: "other", price: 99_999 });
    await message({ at: at("2026-02-01 00:00"), price: 77_777, outcome: ["DELIVERED"] });

    //the nightly rollup has run through the 24th; then the 5th's records are purged
    await run(ROLLUP, [ZONE, "2026-01-01", "2026-01-24"]);
    await run("DELETE FROM cdr_final f USING cdr_submit s WHERE s.gateway_msg_id = f.gateway_msg_id AND (s.submitted_at AT TIME ZONE $1)::date = '2026-01-05'", [ZONE]);
    await run("DELETE FROM cdr_submit WHERE (submitted_at AT TIME ZONE $1)::date = '2026-01-05'", [ZONE]);
  });

  after(async () => {
    if (pool) {
      await run(`DROP SCHEMA IF EXISTS ${SCHEMA} CASCADE`).catch(() => undefined);
      await pool.end();
    }
  });

  const month = { since: at("2026-01-01 00:00"), until: at("2026-02-01 00:00") };

  test("a month spanning the rollup boundary and a purged day: the same bill as before", async () => {
    const before = await oldSummary(month.since, month.until);
    const now = await newSummary(month.since, month.until, "2026-01-25");
    assert.equal(now.cut.boundary, "2026-01-25", "the cursor's day: everything before it is rolled");
    assert.deepEqual(now.lines, before);
    assert.equal(now.daysFromSummary, 24, "the 1st to the 24th, the purged 5th among them");
    assert.ok(before.some((l) => l.expired > 0) && before.some((l) => l.unrated > 0), "the fixture covers every outcome");
  });

  test("the days add up to the lines, and cut the 10th in the billing zone", async () => {
    const now = await newSummary(month.since, month.until, "2026-01-25");
    assert.equal(now.days.length, 31 - 3, "the 29th to the 31st carried nothing");
    const tenth = now.days.find((d) => d.day === "2026-01-10")!;
    assert.equal(tenth.submitted, 4, "09:00, 10:00, 12:00 and the 23:50 message");
    assert.equal(now.days.reduce((n, d) => n + d.price, 0), now.lines.reduce((n, l) => n + l.amount, 0));
    assert.equal(now.days.reduce((n, d) => n + d.submitted, 0), now.lines.reduce((n, l) => n + l.submitted, 0));
  });

  test("no cursor: the account's newest line sets the boundary, and the bill is unchanged", async () => {
    const now = await newSummary(month.since, month.until, null);
    assert.equal(now.cut.boundary, "2026-01-24", "the newest line's own day is read live, one day of margin");
    assert.deepEqual(now.lines, await oldSummary(month.since, month.until));
  });

  test("a cursor behind the lines does not hide them", async () => {
    //a CLI rollup moved the lines on without the cursor: the newest line still counts
    const now = await newSummary(month.since, month.until, "2026-01-03");
    assert.equal(now.cut.boundary, "2026-01-24");
    assert.deepEqual(now.lines, await oldSummary(month.since, month.until));
  });

  test("a window that does not start on a billing-day boundary reads its partial first day live", async () => {
    //UTC midnight is 05:30 in Kolkata: the 02:00 message on the 1st is outside, the rest inside
    const since = new Date("2026-01-01T00:00:00Z");
    const until = new Date("2026-01-20T00:00:00Z");
    const now = await newSummary(since, until, "2026-01-25");
    assert.equal(now.cut.first_full, "2026-01-02");
    //the old statement took whole purged days from the summary and live records from `since`, which
    //agree here because the purged 5th lies wholly inside the window
    assert.deepEqual(now.lines, await oldSummary(since, until));
  });

  test("an account with no lines and no cursor is read live end to end", async () => {
    const now = await (async () => {
      //"other" has a line (the rollup covers every account); "nobody" has none
      const [cut] = await run<StatementCut>(STATEMENT_CUT_SQL, ["nobody", month.since, month.until, ZONE, null, 24]);
      return cut;
    })();
    assert.equal(now.boundary, "2026-01-01", "the start of the window");
  });

  test("a month still inside the deadline stays live from the day the deadline reaches back to", async () => {
    const today = new Date();
    const since = new Date(today.getTime() - 3 * 86_400_000);
    const [cut] = await run<StatementCut>(STATEMENT_CUT_SQL, ["acme", since, today, ZONE, "2099-01-01", 24]);
    const [expected] = await run<{ d: string }>(
      "SELECT to_char(((now() - interval '24 hours') AT TIME ZONE $1)::date, 'YYYY-MM-DD') AS d", [ZONE]);
    assert.equal(cut.boundary, expected.d);
  });
});

/**
 * The tail's hourly half against PostgreSQL: trusted hours from `usage_hourly`, the rest from the
 * records, and the same bill as the records alone. `usage_hourly` is filled here the way the
 * gateway fills it -- a restate per hour, or two additive ticks for an hour not yet restated.
 */
describe("the hourly tail against PostgreSQL", { skip: URL ? false : "STATEMENT_TEST_DATABASE_URL is not set" }, () => {
  const SCHEMA = `stmt_hourly_${process.pid}`;
  let pool: import("pg").Pool;

  async function run<T>(sql: string, params: unknown[] = []): Promise<T[]> {
    return (await pool.query(sql, params)).rows as T[];
  }

  /** `WINDOW_SELECT` over `[lo, hi)`, added to what is there; `rolled_up_at` is the hour plus `stamp`. */
  async function rollHours(lo: Date, hi: Date, stamp: string) {
    await run(`
      INSERT INTO usage_hourly (account_id, hour, product, vendor, submitted, delivered, failed, expired,
                                pending_at_rollup, billed_messages, unrated_messages, price_total, rolled_up_at)
      SELECT COALESCE(s.account_id, ''), date_trunc('hour', s.submitted_at AT TIME ZONE 'UTC') AT TIME ZONE 'UTC',
             COALESCE(s.product, ''), COALESCE(s.vendor, ''), count(*),
             count(*) FILTER (WHERE o.final_state = 'DELIVERED'),
             count(*) FILTER (WHERE o.final_state IN ('FAILED','REJECTED','DROPPED')),
             count(*) FILTER (WHERE o.final_state = 'EXPIRED'),
             count(*) FILTER (WHERE o.final_state IS NULL),
             count(*) FILTER (WHERE s.price IS NOT NULL), count(*) FILTER (WHERE s.price IS NULL),
             COALESCE(SUM(s.price), 0),
             (date_trunc('hour', s.submitted_at AT TIME ZONE 'UTC') AT TIME ZONE 'UTC') + $3::interval
        FROM (SELECT DISTINCT ON (c.gateway_msg_id) c.* FROM cdr_submit c
               WHERE c.part_no = 1 AND c.submitted_at >= $1 AND c.submitted_at < $2
               ORDER BY c.gateway_msg_id, (c.price IS NULL), c.retry_count DESC, c.vendor_attempt DESC) s
        LEFT JOIN LATERAL (SELECT f.final_state FROM cdr_final f
                            WHERE f.gateway_msg_id = s.gateway_msg_id AND f.part_no = s.part_no
                            ORDER BY (f.final_state = 'EXPIRED'), f.final_at LIMIT 1) o ON TRUE
       GROUP BY 1, 2, 3, 4, 13
      ON CONFLICT (account_id, hour, product, vendor) DO UPDATE SET
        submitted = usage_hourly.submitted + EXCLUDED.submitted, delivered = usage_hourly.delivered + EXCLUDED.delivered,
        failed = usage_hourly.failed + EXCLUDED.failed, expired = usage_hourly.expired + EXCLUDED.expired,
        pending_at_rollup = usage_hourly.pending_at_rollup + EXCLUDED.pending_at_rollup,
        billed_messages = usage_hourly.billed_messages + EXCLUDED.billed_messages,
        unrated_messages = usage_hourly.unrated_messages + EXCLUDED.unrated_messages,
        price_total = usage_hourly.price_total + EXCLUDED.price_total`, [lo, hi, stamp]);
  }

  /** A restate of every hour in `[lo, hi)`, each stamped 20 minutes after it ended. */
  async function restateAll(lo: Date, hi: Date) {
    for (let h = lo.getTime(); h < hi.getTime(); h += 3_600_000) {
      await run("DELETE FROM usage_hourly WHERE hour = $1", [new Date(h)]);
      await rollHours(new Date(h), new Date(h + 3_600_000), "80 minutes");
    }
  }

  /**
   * The statement over `[since, until)` with the tail from `since` (no daily half), through the
   * hourly cut when `hourly`, else the records alone -- the reference every figure is checked against.
   */
  async function summary(account: string, since: Date, until: Date, zone: string, hourly: boolean) {
    const first = await run<{ d: string }>("SELECT to_char(($1::timestamptz AT TIME ZONE $2)::date, 'YYYY-MM-DD') AS d", [since, zone]);
    const cut: StatementCut = { first_full: first[0].d, boundary: first[0].d, head_until: since, tail_from: since };
    let seam: Date | undefined;
    if (hourly) {
      const [h] = await run<{ seam: Date }>(STATEMENT_HOURLY_CUT_SQL, [account, since, until, zone, HOURLY_SETTLE_MINUTES]);
      seam = h.seam;
    }
    const rows = await run<StatementDayProductRow>(statementSummarySql({ vendorAttempt: true }, { hourly }),
      summaryParams(account, since, until, zone, cut, seam));
    return { seam, ...summariseStatement(rows) };
  }

  async function oldLines(account: string, since: Date, until: Date, zone: string) {
    const rows = await run<Record<string, string>>(oldSummarySql(), [account, since, until, zone]);
    return rows.map((r) => ({
      product: r.product, submitted: Number(r.submitted), delivered: Number(r.delivered),
      failed: Number(r.failed), expired: Number(r.expired), pending: Number(r.pending),
      unrated: Number(r.unrated), amount: Number(r.amount),
    }));
  }

  const setHwm = (at: string) => run("UPDATE usage_rollup_cursor SET hourly_hwm = $1", [new Date(at)]);
  const utc = { since: new Date("2026-01-25T00:00:00Z"), until: new Date("2026-02-01T00:00:00Z") };
  //DST ends in Sydney at 03:00 on 5 April 2026: +11 before, +10 after. Both whole hours
  const sydney = { since: new Date("2026-04-04T00:00:00+11:00"), until: new Date("2026-04-08T00:00:00+10:00") };

  before(async () => {
    const pg = (await import("pg")).default;
    pool = new pg.Pool({ connectionString: URL, max: 1, options: `-c search_path=${SCHEMA}` });
    await run(`CREATE SCHEMA ${SCHEMA}`);
    await run(`CREATE TABLE cdr_submit (
                 id bigserial PRIMARY KEY, gateway_msg_id text NOT NULL, part_no int NOT NULL DEFAULT 1,
                 account_id text, product text, vendor text, submitted_at timestamptz NOT NULL, price bigint,
                 cost bigint, retry_count int NOT NULL DEFAULT 0, vendor_attempt int NOT NULL DEFAULT 0)`);
    await run(`CREATE TABLE cdr_final (gateway_msg_id text NOT NULL, part_no int NOT NULL DEFAULT 1,
                 final_state text NOT NULL, final_at timestamptz NOT NULL, dlr_state int, err_code text)`);
    await run(`CREATE TABLE usage_daily (account_id text NOT NULL, day date NOT NULL, product text NOT NULL,
                 submitted bigint NOT NULL, delivered bigint NOT NULL, failed bigint NOT NULL, expired bigint NOT NULL,
                 pending_at_rollup bigint NOT NULL, unrated_messages bigint NOT NULL, price_total bigint NOT NULL,
                 PRIMARY KEY (account_id, day, product))`);
    await run(`CREATE TABLE usage_hourly (account_id text NOT NULL, hour timestamptz NOT NULL, product text NOT NULL,
                 vendor text NOT NULL DEFAULT '', submitted bigint NOT NULL DEFAULT 0, delivered bigint NOT NULL DEFAULT 0,
                 failed bigint NOT NULL DEFAULT 0, expired bigint NOT NULL DEFAULT 0,
                 pending_at_rollup bigint NOT NULL DEFAULT 0, billed_messages bigint NOT NULL DEFAULT 0,
                 unrated_messages bigint NOT NULL DEFAULT 0, price_total bigint NOT NULL DEFAULT 0,
                 refused bigint NOT NULL DEFAULT 0, rolled_up_at timestamptz NOT NULL DEFAULT now(),
                 PRIMARY KEY (account_id, hour, product, vendor))`);
    await run(`CREATE TABLE usage_rollup_cursor (one boolean PRIMARY KEY, hourly_hwm timestamptz,
                 last_restate_at timestamptz, last_daily_day date)`);
    await run("INSERT INTO usage_rollup_cursor (one, hourly_hwm) VALUES (TRUE, NULL)");

    let n = 0;
    async function message(o: { at: string; account?: string; product?: string | null; price?: number | null;
      vendor?: string; outcome?: string; refusedAt?: string }) {
      const id = `h${++n}`;
      const account = o.account ?? "acme";
      const product = o.product === undefined ? "p1" : o.product;
      if (o.refusedAt) {
        //the refused first attempt, stamped when the vendor answered: a retry has its own time
        await run("INSERT INTO cdr_submit (gateway_msg_id, account_id, product, vendor, submitted_at, price, vendor_attempt) VALUES ($1,$2,$3,'v-refuse',$4,NULL,0)",
          [id, account, product, new Date(o.refusedAt)]);
      }
      await run("INSERT INTO cdr_submit (gateway_msg_id, account_id, product, vendor, submitted_at, price, vendor_attempt) VALUES ($1,$2,$3,$4,$5,$6,$7)",
        [id, account, product, o.vendor ?? "v1", new Date(o.at), o.price === undefined ? 500 : o.price, o.refusedAt ? 1 : 0]);
      if (o.outcome) {
        await run("INSERT INTO cdr_final (gateway_msg_id, final_state, final_at) VALUES ($1,$2,$3)",
          [id, o.outcome, new Date(new Date(o.at).getTime() + 60_000)]);
      }
    }

    //UTC: four days of traffic over two vendors and three products, with every outcome
    for (let d = 25; d <= 28; d++) {
      for (const hh of ["03", "09", "10", "17", "23"]) {
        await message({ at: `2026-01-${d}T${hh}:15:00Z`, outcome: "DELIVERED" });
        await message({ at: `2026-01-${d}T${hh}:40:00Z`, product: null, price: 1200, vendor: "v2", outcome: "FAILED" });
      }
      await message({ at: `2026-01-${d}T11:05:00Z`, product: "p2", price: null, outcome: "EXPIRED" });
      await message({ at: `2026-01-${d}T12:05:00Z`, product: "p2", price: 800 });
    }
    //a retry across a tick boundary inside one hour: the ticks count it twice, the restate once
    await message({ at: "2026-01-27T10:30:50Z", refusedAt: "2026-01-27T10:30:10Z", price: 900, outcome: "DELIVERED" });
    //a retry across the top of an hour, for another account: counted in each hour, priced once
    await message({ account: "straddle", at: "2026-01-26T11:00:10Z", refusedAt: "2026-01-26T10:59:50Z", price: 700, outcome: "DELIVERED" });
    await message({ account: "straddle", at: "2026-01-26T15:00:00Z", price: 700, outcome: "DELIVERED" });
    //Sydney, either side of the DST change, and late on a day in each offset
    for (const at of ["2026-04-04T09:00:00+11:00", "2026-04-04T23:30:00+11:00", "2026-04-05T01:30:00+11:00",
      "2026-04-05T02:30:00+10:00", "2026-04-05T23:30:00+10:00", "2026-04-06T00:10:00+10:00", "2026-04-07T23:50:00+10:00"]) {
      await message({ account: "syd", at, price: 300, outcome: "DELIVERED" });
    }

    //the summary's first row, days before the tail, as a gateway's retention leaves it: the floor
    //the hourly cut will not read past
    await message({ account: "other", at: "2026-01-22T05:00:00Z", outcome: "DELIVERED" });
    await restateAll(new Date("2026-01-22T05:00:00Z"), new Date("2026-01-22T06:00:00Z"));

    //every hour restated whole after it ended, except 10:00 on the 27th: two additive ticks either
    //side of 10:30:30, never restated -- the retry inside it counted twice, as the gateway would
    await restateAll(utc.since, new Date("2026-01-27T10:00:00Z"));
    await rollHours(new Date("2026-01-27T10:00:00Z"), new Date("2026-01-27T10:30:30Z"), "5 minutes");
    await rollHours(new Date("2026-01-27T10:30:30Z"), new Date("2026-01-27T11:00:00Z"), "5 minutes");
    await restateAll(new Date("2026-01-27T11:00:00Z"), utc.until);
    await restateAll(sydney.since, sydney.until);
  });

  after(async () => {
    if (pool) {
      await run(`DROP SCHEMA IF EXISTS ${SCHEMA} CASCADE`).catch(() => undefined);
      await pool.end();
    }
  });

  test("the ticked hour is double-counted in usage_hourly, so the fixture tests what it means to", async () => {
    const [h] = await run<{ submitted: string }>(
      "SELECT sum(submitted)::text AS submitted FROM usage_hourly WHERE account_id = 'acme' AND hour = '2026-01-27T10:00:00Z'");
    //10:15, 10:40 and the retried message, which the two ticks each counted
    assert.equal(h.submitted, "4");
  });

  test("the seam stops at the first hour not restated, and the bill equals the records'", async () => {
    await setHwm("2026-01-28T09:30:00Z");
    const now = await summary("acme", utc.since, utc.until, "UTC", true);
    assert.equal(new Date(now.seam!).toISOString(), "2026-01-27T10:00:00.000Z");
    assert.deepEqual(now.lines, await oldLines("acme", utc.since, utc.until, "UTC"));
    const raw = await summary("acme", utc.since, utc.until, "UTC", false);
    assert.deepEqual(now.days, raw.days);
  });

  test("restated, the hour is read from the summary, up to the watermark's hour", async () => {
    await run("DELETE FROM usage_hourly WHERE hour = '2026-01-27T10:00:00Z'");
    await rollHours(new Date("2026-01-27T10:00:00Z"), new Date("2026-01-27T11:00:00Z"), "80 minutes");
    await setHwm("2026-01-28T09:30:00Z");
    const now = await summary("acme", utc.since, utc.until, "UTC", true);
    assert.equal(new Date(now.seam!).toISOString(), "2026-01-28T09:00:00.000Z", "the hour the watermark is in, and after");
    assert.deepEqual(now.lines, await oldLines("acme", utc.since, utc.until, "UTC"));
    //the money of the hours read from usage_hourly is the records' to the unit
    const [m] = await run<{ hourly: string; raw: string }>(`
      SELECT (SELECT sum(price_total) FROM usage_hourly WHERE account_id = 'acme' AND hour < '2026-01-28T09:00:00Z')::text AS hourly,
             (SELECT sum(price) FROM cdr_submit WHERE account_id = 'acme' AND submitted_at < '2026-01-28T09:00:00Z')::text AS raw`);
    assert.equal(m.hourly, m.raw);
  });

  test("with the watermark past the window, every whole hour is the summary's", async () => {
    await setHwm("2026-03-01T00:00:00Z");
    const now = await summary("acme", utc.since, utc.until, "UTC", true);
    assert.equal(new Date(now.seam!).toISOString(), utc.until.toISOString());
    assert.deepEqual(now.lines, await oldLines("acme", utc.since, utc.until, "UTC"));
  });

  test("a row stamped too soon after its hour keeps the hour live", async () => {
    await setHwm("2026-03-01T00:00:00Z");
    await run("UPDATE usage_hourly SET rolled_up_at = hour + interval '1 hour' + make_interval(mins => $1) WHERE account_id = 'acme' AND hour = '2026-01-26T17:00:00Z'",
      [HOURLY_SETTLE_MINUTES - 1]);
    const now = await summary("acme", utc.since, utc.until, "UTC", true);
    assert.equal(new Date(now.seam!).toISOString(), "2026-01-26T17:00:00.000Z");
    await run("UPDATE usage_hourly SET rolled_up_at = hour + interval '80 minutes' WHERE hour = '2026-01-26T17:00:00Z'");
  });

  test("a retry across the top of an hour: the money is exact, the hours count the message on each side", async () => {
    await setHwm("2026-03-01T00:00:00Z");
    const now = await summary("straddle", utc.since, utc.until, "UTC", true);
    const old = await oldLines("straddle", utc.since, utc.until, "UTC");
    const sum = (ls: { submitted: number; amount: number; unrated: number }[], k: "submitted" | "amount" | "unrated") =>
      ls.reduce((n, l) => n + l[k], 0);
    assert.equal(sum(now.lines, "amount"), sum(old, "amount"));
    //the documented difference, as usage_daily has at midnight: the refused attempt's hour counts it
    assert.equal(sum(now.lines, "submitted"), sum(old, "submitted") + 1);
    assert.equal(sum(now.lines, "unrated"), sum(old, "unrated") + 1);
  });

  test("Sydney across its DST change: hours tile the days in both offsets", async () => {
    await setHwm("2026-05-01T00:00:00Z");
    const now = await summary("syd", sydney.since, sydney.until, "Australia/Sydney", true);
    assert.ok(new Date(now.seam!).getTime() > sydney.since.getTime(), "the hourly half is used");
    const raw = await summary("syd", sydney.since, sydney.until, "Australia/Sydney", false);
    assert.deepEqual(now.days, raw.days, "every message in the billing day the records put it in");
    assert.deepEqual(now.days.map((d) => [d.day, d.submitted]),
      [["2026-04-04", 2], ["2026-04-05", 3], ["2026-04-06", 1], ["2026-04-07", 1]]);
    assert.deepEqual(now.lines, await oldLines("syd", sydney.since, sydney.until, "Australia/Sydney"));
  });

  test("a half-hour zone keeps the whole tail live", async () => {
    await setHwm("2026-05-01T00:00:00Z");
    //Kolkata midnight is :30 UTC, so the tail does not even start on an hour
    const kolkata = { since: new Date("2026-01-25T00:00:00+05:30"), until: new Date("2026-02-01T00:00:00+05:30") };
    const [h] = await run<{ seam: Date }>(STATEMENT_HOURLY_CUT_SQL, ["acme", kolkata.since, kolkata.until, "Asia/Kolkata", HOURLY_SETTLE_MINUTES]);
    assert.equal(new Date(h.seam).toISOString(), kolkata.since.toISOString());
    //and a half-hour offset that does start on an hour is refused by the offset test itself
    const [k] = await run<{ seam: Date }>(STATEMENT_HOURLY_CUT_SQL,
      ["acme", new Date("2026-01-25T00:00:00Z"), new Date("2026-02-01T00:00:00Z"), "Asia/Kolkata", HOURLY_SETTLE_MINUTES]);
    assert.equal(new Date(k.seam).toISOString(), "2026-01-25T00:00:00.000Z");
    //Lord Howe moves by half an hour at DST: +11 to +10:30 on 5 April 2026
    const [l] = await run<{ seam: Date }>(STATEMENT_HOURLY_CUT_SQL,
      ["syd", new Date("2026-04-03T13:00:00Z"), new Date("2026-04-07T13:30:00Z"), "Australia/Lord_Howe", HOURLY_SETTLE_MINUTES]);
    assert.equal(new Date(l.seam).toISOString(), "2026-04-03T13:00:00.000Z");
  });

  test("no watermark, or a tail older than the summary's first hour: all live", async () => {
    await run("UPDATE usage_rollup_cursor SET hourly_hwm = NULL");
    const [a] = await run<{ seam: Date }>(STATEMENT_HOURLY_CUT_SQL, ["acme", utc.since, utc.until, "UTC", HOURLY_SETTLE_MINUTES]);
    assert.equal(new Date(a.seam).toISOString(), utc.since.toISOString());
    await setHwm("2026-03-01T00:00:00Z");
    const early = new Date("2026-01-20T00:00:00Z");
    const [b] = await run<{ seam: Date }>(STATEMENT_HOURLY_CUT_SQL, ["acme", early, utc.until, "UTC", HOURLY_SETTLE_MINUTES]);
    assert.equal(new Date(b.seam).toISOString(), early.toISOString());
  });
});
