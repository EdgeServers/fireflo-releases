import { test } from "node:test";
import assert from "node:assert/strict";
import { SERVER_TRAFFIC_RANGES, serverTrafficSql } from "./server-traffic-sql.ts";

test("one listener, bounded by time, one row per message, outcome by the shared rule", () => {
  const sql = serverTrafficSql(true);
  assert.match(sql, /s\.in_gateway = \$3 AND s\.submitted_at >= \$1 AND s\.submitted_at < \$2/);
  assert.match(sql, /DISTINCT ON \(s\.gateway_msg_id\)/, "a retried message counts once");
  assert.match(sql, /ORDER BY \(f\.final_state = 'EXPIRED'\), f\.final_at/, "a real receipt outranks a swept EXPIRED");
  assert.doesNotMatch(sql, /s\.body|s\.\*/, "the sort never carries the message text");
  assert.match(sql, /LIMIT 50/);
});

test("the picker stops at 24 hours: no summary holds a listener", () => {
  assert.deepEqual([...SERVER_TRAFFIC_RANGES], ["1h", "24h"]);
});
