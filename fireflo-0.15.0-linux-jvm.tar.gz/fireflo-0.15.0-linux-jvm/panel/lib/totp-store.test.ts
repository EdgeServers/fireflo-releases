import { strict as assert } from "node:assert";
import { test } from "node:test";

import { hasTotpColumns, resetTotpProbe, type Db } from "./totp-store.ts";

test("a probe that fails throws and is not remembered: never 'no two-factor' on a guess", async () => {
  resetTotpProbe();
  let calls = 0;
  const failing: Db = async () => {
    calls++;
    throw new Error("connection refused");
  };
  await assert.rejects(hasTotpColumns(failing), /connection refused/);
  await assert.rejects(hasTotpColumns(failing), /connection refused/, "asked again, not answered from a cache");
  assert.equal(calls, 2);
  //a probe that ran: absent only when it found fewer than every column
  const answering = (n: number): Db => (async () => [{ n }]) as unknown as Db;
  resetTotpProbe();
  assert.equal(await hasTotpColumns(answering(5)), false, "V1.114.0 without the lockout columns is not enough");
  resetTotpProbe();
  assert.equal(await hasTotpColumns(answering(8)), true);
  resetTotpProbe();
});
