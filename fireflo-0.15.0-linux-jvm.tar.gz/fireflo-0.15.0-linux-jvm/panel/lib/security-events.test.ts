import { test } from "node:test";
import assert from "node:assert/strict";
import {
  currentlyBlocked,
  hourlyCounts,
  parseBanEntries,
  parseGatewayRefusals,
  parsePanelRefusals,
  parseLiveBans,
  reasonLabel,
} from "./security-events.ts";

/**
 * What the Security page is allowed to claim.
 *
 * <p>Two of these matter more than the rest. A parser that reads the wrong address out of a log
 * line would show, and offer to unban, somebody the attacker chose — so the injection cases are
 * written from the attacker's side. And a blocked list folded the wrong way would offer to release
 * an address that is not blocked, which reads as the unban having failed.
 */

const LINE =
  "2026-09-07 19:04:11,204 WARN  auth.refused surface=smpp reason=badPassword " +
  'identity="acme" ip=45.148.10.87';

test("a gateway refusal is read whole", () => {
  const [event] = parseGatewayRefusals([LINE]);
  assert.equal(event.surface, "smpp");
  assert.equal(event.reason, "badPassword");
  assert.equal(event.triedAs, "acme");
  assert.equal(event.ip, "45.148.10.87");
  assert.equal(event.at, "2026-09-07T19:04:11");
});

test("a system id carrying an address cannot make the page name the wrong one", () => {
  //the attack: bind as `victim ip=8.8.8.8`, hope the page reads that ip= and an operator blocks it
  const forged =
    "2026-09-07 19:04:11,204 WARN  auth.refused surface=smpp reason=badPassword " +
    'identity="victim ip=8.8.8.8" ip=45.148.10.87';
  const [event] = parseGatewayRefusals([forged]);
  assert.equal(event.ip, "45.148.10.87");
  assert.notEqual(event.ip, "8.8.8.8");
});

test("a line that does not parse is dropped rather than guessed at", () => {
  const events = parseGatewayRefusals([
    "2026-09-07 19:04:11,204 INFO  something else entirely",
    "",
    "auth.refused but not really",
    LINE,
  ]);
  assert.equal(events.length, 1);
});

test("both surfaces the gateway reports are recognised", () => {
  const rest =
    "2026-09-07 18:52:40,000 WARN  auth.refused surface=rest reason=wrongPassword " +
    'identity="bulkmail" ip=203.0.113.9';
  assert.equal(parseGatewayRefusals([rest])[0].surface, "rest");
});

test("an absent identity reads as nothing rather than as a customer called dash", () => {
  const line =
    "2026-09-07 18:30:55,001 WARN  auth.refused surface=smpp reason=missingCredential " +
    'identity="-" ip=198.51.100.4';
  assert.equal(parseGatewayRefusals([line])[0].triedAs, null);
});

test("ipv6 and its mapped form both survive", () => {
  const six =
    "2026-09-07 18:51:02,912 WARN  auth.refused surface=rest reason=addressNotAllowed " +
    'identity="x" ip=2001:db8::5';
  const mapped =
    "2026-09-07 18:51:02,912 WARN  auth.refused surface=smpp reason=badPassword " +
    'identity="x" ip=::ffff:198.51.100.4';
  assert.equal(parseGatewayRefusals([six])[0].ip, "2001:db8::5");
  assert.equal(parseGatewayRefusals([mapped])[0].ip, "::ffff:198.51.100.4");
});

test("an audit-log entry that is not a refusal never appears", () => {
  //the anti-vacuity half: a successful sign-in is in the same file, and putting a colleague on a
  //page beside a blocked list is how somebody gets blocked by mistake
  const lines = [
    '{"ts":"2026-08-20T08:18:18.414Z","event":"signin_failed","actor":"operator","ip":"::1",'
      + '"detail":{"reason":"bad_credentials"}}',
    '{"ts":"2026-08-20T08:23:39.798Z","event":"signin","actor":"operator","ip":"::1"}',
    '{"ts":"2026-08-20T09:00:00.000Z","event":"download","actor":"operator","ip":"::1"}',
  ];
  const events = parsePanelRefusals(lines);
  assert.equal(events.length, 1);
  assert.equal(events[0].surface, "panel");
  assert.equal(events[0].reason, "bad_credentials");
  assert.equal(events[0].ip, "::1");
});

test("a truncated or non-JSON line in the access log is skipped", () => {
  const events = parsePanelRefusals(['{"ts":"2026-08-20T08:18:18.414Z","event":"sign', "", "x"]);
  assert.equal(events.length, 0);
});

test("a failed sign-in with no address is not shown, since there is nothing to act on", () => {
  const events = parsePanelRefusals([
    '{"ts":"2026-08-20T08:18:18.414Z","event":"signin_failed","actor":"operator","ip":null}',
  ]);
  assert.equal(events.length, 0);
});

const NOW = new Date("2026-09-07T20:00:00Z");

function ban(ip: string, at: string, bantime = 3600, jail = "fireflo-gateway"): string {
  return JSON.stringify({ ts: at, action: "ban", jail, ip, failures: 12, bantime });
}

function unban(ip: string, at: string, jail = "fireflo-gateway"): string {
  return JSON.stringify({ ts: at, action: "unban", jail, ip, failures: 0, bantime: 0 });
}

test("an address banned and then released is not listed as blocked", () => {
  //without both directions in the file this is the case that goes wrong, and the page would offer
  //to unban something that is already free
  const entries = parseBanEntries([
    ban("45.148.10.87", "2026-09-07T19:00:00Z"),
    unban("45.148.10.87", "2026-09-07T19:30:00Z"),
  ]);
  assert.deepEqual(currentlyBlocked(entries, NOW), []);
});

test("a re-ban after a release is blocked again", () => {
  const entries = parseBanEntries([
    ban("45.148.10.87", "2026-09-07T18:00:00Z"),
    unban("45.148.10.87", "2026-09-07T18:30:00Z"),
    ban("45.148.10.87", "2026-09-07T19:45:00Z"),
  ]);
  const blocked = currentlyBlocked(entries, NOW);
  assert.equal(blocked.length, 1);
  assert.equal(blocked[0].since, "2026-09-07T19:45:00Z");
});

test("the same address in two jails is two blocks, released independently", () => {
  const entries = parseBanEntries([
    ban("45.148.10.87", "2026-09-07T19:00:00Z", 3600, "fireflo-gateway"),
    ban("45.148.10.87", "2026-09-07T19:05:00Z", 3600, "fireflo-panel"),
    unban("45.148.10.87", "2026-09-07T19:30:00Z", "fireflo-gateway"),
  ]);
  const blocked = currentlyBlocked(entries, NOW);
  assert.equal(blocked.length, 1);
  assert.equal(blocked[0].jail, "fireflo-panel");
});

test("a ban whose own bantime has elapsed drops off even with no unban recorded", () => {
  //a restart or a manual fail2ban-client would otherwise leave it listed for ever
  const entries = parseBanEntries([ban("45.148.10.87", "2026-09-07T17:00:00Z", 3600)]);
  assert.deepEqual(currentlyBlocked(entries, NOW), []);
});

test("a permanent ban has no expiry and stays listed", () => {
  const entries = parseBanEntries([ban("45.148.10.87", "2026-09-01T00:00:00Z", 0)]);
  const blocked = currentlyBlocked(entries, NOW);
  assert.equal(blocked.length, 1);
  assert.equal(blocked[0].until, null);
});

test("when a ban lifts is computed from the ban's own bantime", () => {
  const entries = parseBanEntries([ban("45.148.10.87", "2026-09-07T19:45:00Z", 3600)]);
  assert.equal(currentlyBlocked(entries, NOW)[0].until, "2026-09-07T20:45:00.000Z");
});

test("hourly buckets include the quiet hours between busy ones", () => {
  //a skipped empty hour would draw a shorter chart, which reads as less traffic rather than none
  const events = parseGatewayRefusals([
    '2026-09-07 10:00:00,000 WARN  auth.refused surface=smpp reason=badPassword identity="a" ip=1.1.1.1',
    ' 2026-09-07 13:30:00,000 WARN  auth.refused surface=smpp reason=badPassword identity="a" ip=1.1.1.1',
  ]);
  const buckets = hourlyCounts(events);
  assert.equal(buckets.length, 4);
  assert.deepEqual(
    buckets.map((b) => b.count),
    [1, 0, 0, 1]
  );
});

test("the chart's bars sum to the number of rows it was given", () => {
  const events = parseGatewayRefusals([
    '2026-09-07 10:00:00,000 WARN  auth.refused surface=smpp reason=badPassword identity="a" ip=1.1.1.1',
    '2026-09-07 10:05:00,000 WARN  auth.refused surface=rest reason=badPassword identity="a" ip=1.1.1.1',
    '2026-09-07 11:05:00,000 WARN  auth.refused surface=smpp reason=badPassword identity="a" ip=1.1.1.1',
  ]);
  const total = hourlyCounts(events).reduce((sum, b) => sum + b.count, 0);
  assert.equal(total, events.length);
});

test("no events is an empty chart rather than a thrown error", () => {
  assert.deepEqual(hourlyCounts([]), []);
});

test("an unknown reason shows its own token rather than an empty cell", () => {
  assert.equal(reasonLabel("badPassword"), "Wrong password");
  assert.equal(reasonLabel("somethingNew"), "somethingNew");
});

test("fail2ban's own live list is read, with the expiry it reports", () => {
  //fail2ban 0.11: `get <jail> banip --with-time`. Preferred over the derived file because it cannot
  //drift from what is actually blocking traffic
  const out = "45.148.10.87 \t2026-09-07 19:00:00 + 3600 = 2026-09-07 20:00:00\n"
    + "2001:db8::5 \t2026-09-07 19:30:00 + 3600 = 2026-09-07 20:30:00\n";
  const rows = parseLiveBans(out, "fireflo-gateway");
  assert.equal(rows.length, 2);
  assert.equal(rows[0].ip, "45.148.10.87");
  assert.equal(rows[0].jail, "fireflo-gateway");
  assert.ok(rows[0].until?.startsWith("2026-09-07T"));
  assert.equal(rows[1].ip, "2001:db8::5");
});

test("a bare list with no times still yields the addresses", () => {
  //the part that matters is who is blocked; a version that words the times differently, or omits
  //them, must not cost the whole list
  const rows = parseLiveBans("45.148.10.87\n203.0.113.9\n", "fireflo-panel");
  assert.deepEqual(rows.map((r) => r.ip), ["45.148.10.87", "203.0.113.9"]);
  assert.equal(rows[0].until, null);
});

test("an empty jail is an empty list, not a row", () => {
  assert.deepEqual(parseLiveBans("", "fireflo-gateway"), []);
  assert.deepEqual(parseLiveBans("\n  \n", "fireflo-gateway"), []);
});

test("nothing that is not an address reaches a row with an Unban button on it", () => {
  //fail2ban's own error text, or a header line, must not become something an operator can click
  const rows = parseLiveBans("Status for the jail: fireflo-gateway\nERROR  no such jail\n", "x");
  assert.deepEqual(rows, []);
});

test("the customer portal is covered, not just the operator door", () => {
  //the panel is one application with two front doors, and an actor who tries one tries the other
  const lines = [
    '{"ts":"2026-09-07T19:00:00.000Z","surface":"portal","reason":"unknown_address",'
      + '"triedAs":"nobody@example.com","ip":"45.148.10.87"}',
    '{"ts":"2026-09-07T19:01:00.000Z","surface":"panel","reason":"bad_credentials",'
      + '"triedAs":"operator","ip":"45.148.10.87"}',
  ];
  const events = parsePanelRefusals(lines);
  assert.deepEqual(events.map((e) => e.surface), ["portal", "panel"]);
  assert.equal(events[0].triedAs, "nobody@example.com");
});

test("a line written before the portal was covered still reads as the operator door", () => {
  //no surface field: that is what this file held until portal coverage landed, and dropping those
  //would quietly lose every refusal recorded before the upgrade
  const events = parsePanelRefusals([
    '{"ts":"2026-09-07T19:00:00.000Z","reason":"bad_credentials","triedAs":"admin","ip":"::1"}',
  ]);
  assert.equal(events.length, 1);
  assert.equal(events[0].surface, "panel");
});

test("the 0.13 line names the listener and port it arrived on", () => {
  const [event] = parseGatewayRefusals([
    "2026-10-22 09:15:02,118 WARN  auth.refused surface=smpp reason=badPassword " +
      'identity="acme" listener=smppserver.main port=22775 ip=203.0.113.9',
  ]);
  assert.equal(event.ip, "203.0.113.9");
  assert.equal(event.listener, "smppserver.main");
  assert.equal(event.port, 22775);
  assert.equal(event.triedAs, "acme");
});

test("the older line, and a REST line, still parse and say nothing about a listener", () => {
  const [old, rest] = parseGatewayRefusals([
    LINE,
    '2026-10-22 09:15:02,118 WARN  auth.refused surface=rest reason=badPassword identity="acme" ip=203.0.113.9',
  ]);
  assert.equal(old.ip, "45.148.10.87");
  assert.equal("listener" in old, false, "absent, not null: an older gateway said nothing");
  assert.equal("port" in old, false);
  assert.equal(rest.listener, undefined);
});

test("a listener alone, without a port, is still a refusal", () => {
  const [event] = parseGatewayRefusals([
    '2026-10-22 09:15:02 WARN  auth.refused surface=smpp reason=unknownIdentity identity="-" listener=edge ip=10.0.0.9',
  ]);
  assert.equal(event.listener, "edge");
  assert.equal(event.port, undefined);
  assert.equal(event.ip, "10.0.0.9");
});

test("a listener token carrying an equals sign cannot smuggle an address", () => {
  //the gateway replaces '=' in a worker name before writing; if one ever got through, the line
  //must fail to parse rather than name 8.8.8.8
  const events = parseGatewayRefusals([
    '2026-10-22 09:15:02 WARN  auth.refused surface=smpp reason=badPassword identity="a" listener=x ip=8.8.8.8 port=1 ip=10.0.0.9',
  ]);
  assert.equal(events.length, 0);
});

test("the post-credential refusals have operator words", () => {
  for (const reason of ["ipLimit", "accountLimit", "loginLimit", "backoff", "productNotAllowed"]) {
    assert.notEqual(reasonLabel(reason), reason, reason);
  }
});
