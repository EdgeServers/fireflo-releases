/** Seconds as the footer prints them: two decimals under ten seconds, one above -- "0.42", "12.4". */
export function formatSeconds(seconds: number): string {
  return seconds < 10 ? seconds.toFixed(2) : seconds.toFixed(1);
}
