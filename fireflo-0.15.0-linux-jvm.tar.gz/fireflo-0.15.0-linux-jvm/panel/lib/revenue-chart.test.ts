import { test } from "node:test";
import assert from "node:assert/strict";
import { TOP_ACCOUNTS, bucketLabel, seriesBars, topAccounts } from "./revenue-chart.ts";

test("each bar is cost with margin on top, together the revenue; a loss is never a negative segment", () => {
  const [gain, loss] = seriesBars([
    { bucket: "2026-10-22", revenue: 500, cost: 310 },
    { bucket: "2026-10-23", revenue: 100, cost: 140 },
  ]);
  assert.deepEqual([gain.cost, gain.margin, gain.cost + gain.margin], [310, 190, 500]);
  assert.equal(gain.loss, false);
  assert.deepEqual([loss.cost, loss.margin, loss.loss], [140, 0, true]);
});

test("labels: a day by date, an hour or five minutes by clock", () => {
  assert.equal(bucketLabel("2026-10-23"), "23 Oct");
  assert.equal(bucketLabel("2026-10-23T14:05:00Z"), "14:05");
});

test("accounts summed across products, busiest first, the rest as Other, nothing billed left out", () => {
  const rows = [
    { accountId: "acme", revenue: 100 }, { accountId: "acme", revenue: 50 },
    { accountId: "zero", revenue: 0 },
    ...Array.from({ length: 8 }, (_, i) => ({ accountId: `a${i}`, revenue: 80 - i })),
  ];
  const bars = topAccounts(rows);
  assert.equal(bars.length, TOP_ACCOUNTS);
  assert.deepEqual(bars[0], { account: "acme", revenue: 150 });
  assert.equal(bars.at(-1)!.account, "Other (3)");
  assert.equal(bars.at(-1)!.revenue, 75 + 74 + 73);
  assert.ok(!bars.some((b) => b.account === "zero"));
});
