import { strict as assert } from "node:assert";
import { test } from "node:test";

import { totpGate } from "./totp-gate.ts";

const g = (o: Partial<Parameters<typeof totpGate>[0]>) =>
  totpGate({ rowStamp: null, sessionStamp: null, required: false, rowChanged: null, sessionChanged: null, ...o });

test("an operator with an authenticator needs a session verified with that one", () => {
  assert.equal(g({ rowStamp: 100, sessionStamp: 100, rowChanged: 100, sessionChanged: 100 }), "ok");
  assert.equal(g({ rowStamp: 100, sessionStamp: null, rowChanged: 100, sessionChanged: 100 }), "refuse",
    "made under the right change but never verified with a code");
  assert.equal(g({ rowStamp: 200, sessionStamp: 100, rowChanged: 200, sessionChanged: 200, required: true }), "refuse");
});

test("a session made before two-factor last changed is refused, whatever it is now", () => {
  //turned off (or reset) since: the authenticator is gone, and so is every session from before
  assert.equal(g({ rowStamp: null, sessionStamp: 100, rowChanged: 300, sessionChanged: 100 }), "refuse");
  assert.equal(g({ rowStamp: null, rowChanged: 300, sessionChanged: null }), "refuse",
    "a session from before the column was ever written");
  assert.equal(g({ rowStamp: null, rowChanged: 300, sessionChanged: 300 }), "ok", "re-minted at the change");
  assert.equal(g({ rowChanged: null, sessionChanged: null }), "ok", "never changed");
});

test("no authenticator: through, or the set-up only when two-factor is required", () => {
  assert.equal(g({}), "ok");
  assert.equal(g({ required: true }), "enrol");
});
