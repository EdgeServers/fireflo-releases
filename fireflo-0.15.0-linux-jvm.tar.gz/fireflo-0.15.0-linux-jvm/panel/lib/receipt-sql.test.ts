import { strict as assert } from "node:assert";
import { test } from "node:test";
import { receiptCountsHourlySql, receiptTimingsSql, sampleDivisor, SAMPLE_TARGET } from "./receipt-sql.ts";

test("a range at or under the target is read whole; above it, one message in N", () => {
  assert.equal(sampleDivisor(0), 1);
  assert.equal(sampleDivisor(SAMPLE_TARGET), 1);
  assert.equal(sampleDivisor(SAMPLE_TARGET + 1), 2);
  //.101's 7 days: 1,158,329 messages -> 1 in 58, about 20k read
  assert.equal(sampleDivisor(1_158_329), 58);
  assert.ok(1_158_329 / sampleDivisor(1_158_329) <= SAMPLE_TARGET);
  assert.equal(sampleDivisor(Number.NaN), 1);
});

test("the timing statement samples by message id and looks each sampled receipt up by its id", () => {
  const sql = receiptTimingsSql(true, true);
  assert.match(sql, /abs\(hashtext\(s\.gateway_msg_id\)\) % \$3::int = 0/);
  assert.match(sql, /\$3::int = 1 OR/, "a divisor of 1 reads every message");
  assert.match(sql, /WHERE s\.represents/, "timings are credited to the representative attempt");
  //a lookup per sampled message (idx_cdr_final_msg_part), never a scan of the window's receipts:
  //that scan was 3.7M rows for 30 days on .101, and timed out
  assert.match(sql, /LEFT JOIN LATERAL \(\s*SELECT CASE WHEN f\.final_state/);
  assert.match(sql, /f\.gateway_msg_id = s\.gateway_msg_id AND f\.part_no = 1 AND f\.final_at >= \$1/);
  assert.match(sql, /i\.gateway_msg_id = s\.gateway_msg_id AND i\.part_no = 1 AND i\.received_at >= \$1/);
  assert.doesNotMatch(sql, /IN \(SELECT gateway_msg_id FROM s\)/, "no semi-join over the window");
  //the real-receipt-before-EXPIRED rule every other reader uses
  assert.match(sql, /ORDER BY \(f\.final_state = 'EXPIRED'\), f\.final_at\s+LIMIT 1/);
});

test("without cdr_interim the progress columns are null and the table is not read", () => {
  const sql = receiptTimingsSql(false, true);
  assert.doesNotMatch(sql, /cdr_interim/);
  assert.match(sql, /NULL::bigint AS progress_receipts/);
});

test("the counts keep EXPIRED apart, and settle an old hour's pending as expired", () => {
  const sql = receiptCountsHourlySql(true);
  assert.match(sql, /final_state IN \('FAILED','REJECTED','DROPPED'\)\) AS failed/);
  assert.match(sql, /final_state = 'EXPIRED'\) AS expired/);
  assert.match(sql, /h\.hour \+ interval '1 hour' <= \$4::timestamptz\s+THEN h\.pending_at_rollup ELSE 0 END\) AS expired/);
  assert.match(sql, /THEN 0 ELSE h\.pending_at_rollup END\) AS pending/);
});
