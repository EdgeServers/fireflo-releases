import { test } from "node:test";
import assert from "node:assert/strict";
import type { BanRunEntry } from "./ban-rules-db.ts";
import { banDuration, firstFew, lastRun, lastRunSentence, ruleSentence, short, when } from "./security-format.ts";

test("when() renders a moment and passes an unparseable value through", () => {
  assert.equal(when(null), "—");
  assert.equal(when("not a date"), "not a date");
  assert.equal(when("2026-10-22T09:41:00Z"), new Date("2026-10-22T09:41:00Z").toLocaleString());
});

test("short() is the time on the day of `now` and the date otherwise, without reading the clock", () => {
  const now = Date.parse("2026-10-22T12:00:00");
  const sameDay = "2026-10-22T09:41:00";
  const other = "2026-10-20T09:41:00";
  assert.equal(short(sameDay, now), new Date(sameDay).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" }));
  assert.equal(
    short(other, now),
    new Date(other).toLocaleString(undefined, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })
  );
  //the same value, a day later: the rendering follows `now`, not the wall clock
  assert.notEqual(short(sameDay, now + 86_400_000), short(sameDay, now));
  assert.equal(short(null, now), "—");
  assert.equal(short("garbage", now), "garbage");
});

test("banDuration picks the largest whole unit", () => {
  assert.equal(banDuration(600), "10 minutes");
  assert.equal(banDuration(3600), "1 hour");
  assert.equal(banDuration(7200), "2 hours");
  assert.equal(banDuration(86400), "1 day");
  assert.equal(banDuration(604800), "7 days");
  assert.equal(banDuration(90), "90 seconds");
  assert.equal(banDuration(0), "the jail's default");
});

test("ruleSentence says the rule in one line", () => {
  assert.equal(
    ruleSentence({ threshold: 20, reasons: ["badPassword"], windowMinutes: 10, listener: "smppserver.main", banSeconds: 3600, jail: "fireflo-gateway" }),
    "20 badPassword refusals from one address in 10 minutes on smppserver.main → ban 1 hour in fireflo-gateway"
  );
  assert.equal(
    ruleSentence({ threshold: 10, reasons: [], windowMinutes: 30, listener: "any", banSeconds: 86400, jail: "fireflo-gateway" }),
    "10 bannable refusals from one address in 30 minutes on any listener → ban 1 day in fireflo-gateway"
  );
  assert.equal(
    ruleSentence({ threshold: 1, reasons: ["unknownIdentity", "badPassword"], windowMinutes: 1, listener: "", banSeconds: 60, jail: "fireflo-panel" }),
    "1 unknownIdentity or badPassword refusals from one address in 1 minute on any listener → ban 1 minute in fireflo-panel"
  );
});

const RUNS: BanRunEntry[] = [
  { at: "2026-10-22T09:41:02Z", rule: "rule-1", ip: "203.0.113.9", jail: "fireflo-gateway", dryRun: true, banned: false, error: null, reason: "x" },
  { at: "2026-10-22T09:41:01Z", rule: "rule-2", ip: "198.51.100.4", jail: "fireflo-gateway", dryRun: false, banned: true, error: null, reason: "y" },
  { at: "2026-10-22T09:41:01Z", rule: "rule-2", ip: "198.51.100.5", jail: "fireflo-gateway", dryRun: false, banned: false, error: "wrapper failed", reason: "z" },
  //the run before: outside the minute, not counted
  { at: "2026-10-22T09:40:01Z", rule: "rule-2", ip: "198.51.100.6", jail: "fireflo-gateway", dryRun: false, banned: true, error: null, reason: "w" },
];

test("lastRun folds the newest minute of the run log", () => {
  assert.deepEqual(lastRun(RUNS), { at: "2026-10-22T09:41:02Z", banned: 1, wouldBan: 1, notBanned: 1 });
  assert.equal(lastRun([]), null);
  assert.equal(lastRun([{ ...RUNS[0], at: "garbage" }]), null);
});

test("lastRunSentence reads as the header's summary", () => {
  const now = Date.parse("2026-10-22T10:00:00Z");
  const sentence = lastRunSentence(lastRun(RUNS), now);
  assert.ok(sentence.startsWith("last run "));
  assert.ok(sentence.endsWith(", 1 banned · 1 would ban · 1 not banned"));
  assert.equal(lastRunSentence(lastRun(RUNS.slice(0, 2)), now).endsWith(", 1 banned · 1 would ban"), true);
  assert.equal(lastRunSentence(null, now), "no run recorded yet");
});

test("firstFew keeps three and counts the rest", () => {
  assert.equal(firstFew([]), "—");
  assert.equal(firstFew(["a", "b"]), "a, b");
  assert.equal(firstFew(["a", "b", "c", "d", "e"]), "a, b, c +2");
});
