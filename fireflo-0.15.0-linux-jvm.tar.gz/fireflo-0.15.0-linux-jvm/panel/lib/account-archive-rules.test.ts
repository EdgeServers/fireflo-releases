import { test } from "node:test";
import assert from "node:assert/strict";
import {
  archiveRefusal,
  archivedReadOnly,
  moveRefusal,
  scopedLoginRefusal,
  scopedRowsRefusal,
  unarchiveRefusal,
} from "./account-archive-rules.ts";

const live = { exists: true, archived: false, activeChildren: 0 };

test("an ordinary account may be archived, held credit or not", () => {
  //held credit is a block the gateway pre-authorised; archiving hands it back rather than waiting
  assert.equal(archiveRefusal("acme", live), null);
});

test("archiving is refused for a missing, already archived, or still-reselling account", () => {
  assert.match(archiveRefusal("ghost", { ...live, exists: false }) ?? "", /no account 'ghost'/);
  assert.match(archiveRefusal("acme", { ...live, archived: true }) ?? "", /already archived/);
  assert.match(archiveRefusal("rs", { ...live, activeChildren: 2 }) ?? "", /2 active customer accounts/);
  assert.match(archiveRefusal("rs", { ...live, activeChildren: 1 }) ?? "", /1 active customer account of/);
});

test("only an archived account can be unarchived", () => {
  assert.equal(unarchiveRefusal("acme", { exists: true, archived: true }), null);
  assert.match(unarchiveRefusal("acme", { exists: true, archived: false }) ?? "", /not archived/);
  assert.match(unarchiveRefusal("ghost", { exists: false, archived: false }) ?? "", /no account/);
});

test("a move needs a real, live target that is not where it already is", () => {
  const from = { id: "a", exists: true, archived: false };
  assert.equal(moveRefusal("login", from, { id: "b", exists: true, archived: false }), null);
  assert.match(moveRefusal("login", from, { id: " ", exists: false, archived: false }) ?? "", /Choose/);
  assert.match(moveRefusal("login", from, { id: "a", exists: true, archived: false }) ?? "", /already belongs to 'a'/);
  assert.match(moveRefusal("login", from, { id: "c", exists: false, archived: false }) ?? "", /no account 'c'/);
  assert.match(moveRefusal("login", from, { id: "d", exists: true, archived: true }) ?? "", /'d' is archived/);
  assert.equal(
    moveRefusal("template", { ...from, archived: true }, { id: "b", exists: true, archived: false }),
    archivedReadOnly("a")
  );
});

test("a login moves alone: rows scoped to it hold it back, and are named", () => {
  assert.equal(scopedRowsRefusal("acme1", []), null);
  const one = scopedRowsRefusal("acme1", [{ kind: "sender ID", id: 1, name: "ACME" }]) ?? "";
  assert.match(one, /1 sender ID\/template on this account is scoped to the login 'acme1': sender ID ACME\./);
  const many = scopedRowsRefusal("acme1", Array.from({ length: 7 }, (_, i) => ({ kind: "template" as const, id: i, name: `t${i}` }))) ?? "";
  assert.match(many, /7 sender IDs\/templates/);
  assert.match(many, /and 2 more/);
});

test("a scoped row may move only to an account owning its login", () => {
  assert.equal(scopedLoginRefusal(null, false, "b"), null);
  assert.equal(scopedLoginRefusal("acme1", true, "b"), null);
  assert.match(scopedLoginRefusal("acme1", false, "b") ?? "", /'acme1', which does not belong to 'b'/);
});
