import { test } from "node:test";
import assert from "node:assert/strict";
import { formatMs, isSlowWindow, shapeHeadline, slowChipSentence, windowSince } from "./slow-queries.ts";

test("a window is an instant before now, and 'all' is no instant", () => {
  const now = new Date("2026-10-22T12:00:00Z");
  assert.equal(windowSince("1h", now), "2026-10-22T11:00:00.000Z");
  assert.equal(windowSince("6h", now), "2026-10-22T06:00:00.000Z");
  assert.equal(windowSince("24h", now), "2026-10-21T12:00:00.000Z");
  assert.equal(windowSince("all", now), null);
  assert.ok(isSlowWindow("24h"));
  assert.ok(!isSlowWindow("2d"));
});

test("the status chip names the count, singular and plural, and is absent when quiet", () => {
  assert.equal(slowChipSentence(null), null);
  assert.equal(slowChipSentence({ slowLastHour: 0 }), null);
  assert.equal(slowChipSentence({ slowLastHour: 1 }), "1 slow query in the last hour");
  assert.equal(slowChipSentence({ slowLastHour: 1200 }), "1,200 slow queries in the last hour");
});

test("milliseconds read as a person would say them", () => {
  assert.equal(formatMs(850), "850 ms");
  assert.equal(formatMs(2_400), "2.4 s");
  assert.equal(formatMs(12_000), "12 s");
  assert.equal(formatMs(72_000), "1 min 12 s");
  assert.equal(formatMs(120_000), "2 min");
  assert.equal(formatMs(-1), "—");
});

test("a shape headline is one line and bounded", () => {
  assert.equal(shapeHeadline("select *\n  from cdr\n where id = ?"), "select * from cdr where id = ?");
  assert.equal(shapeHeadline("x".repeat(200)).length, 88);
});
