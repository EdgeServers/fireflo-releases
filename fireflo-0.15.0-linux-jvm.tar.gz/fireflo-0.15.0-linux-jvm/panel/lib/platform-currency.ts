import { configQuery } from "@/lib/config-db";
import { chooseCurrency, type InheritedCurrency } from "@/lib/balance-types";
import { gqlData } from "@/lib/gateway-graphql-core";
import { HEALTH_CURRENCY } from "@/lib/gateway-queries";

/** The property the gateway reads. There is exactly one, and it is not per account. */
export const CURRENCY_KEY = "smsg.rates.currency";

/**
 * The one currency this platform has.
 *
 * <p>FireFlo never converts. `smsg.rates.currency` is stamped onto every rated message, and the
 * per-rule `currency` column is an override that `ConfigImportWriter` deliberately writes as NULL
 * so that changing the global still applies. So a currency typed into a form somewhere else is not
 * a second currency — it is a chance to disagree with the only one that counts, on a row nothing
 * reconciles.
 *
 * <p>Two readings of the same key. `app_config` first, the row this panel can read itself; failing
 * that, the gateway is asked (`health.currency` on the management port, gateway 0.13.1+), because
 * in file mode the value lives in `smsg.properties`, which only the gateway can see. Null means
 * neither could answer -- an older gateway, an unreachable one, or no currency set at all -- which
 * is not the same as "no currency", so callers must tell the two apart rather than presenting an
 * empty string as the answer.
 *
 * <p>The gateway's answer is held for {@link CURRENCY_TTL_MS}: statements, reconciliations and the
 * account context all ask, and the value changes when an operator reconfigures the platform, not
 * between two page loads. A failed ask is not held, so the next caller tries again.
 */
export async function platformCurrency(): Promise<string | null> {
  const rows = await configQuery<{ value: string | null }>(
    `SELECT value FROM app_config WHERE key = $1 AND enabled`,
    [CURRENCY_KEY]
  );
  const value = rows[0]?.value?.trim();
  if (value) {
    return value.toUpperCase();
  }
  return gatewayCurrency();
}

const CURRENCY_TTL_MS = 30_000;
let currencyCache: { at: number; code: string | null } | null = null;

/** The currency the gateway itself reports, or null when it cannot or does not. */
async function gatewayCurrency(): Promise<string | null> {
  if (currencyCache && Date.now() - currencyCache.at < CURRENCY_TTL_MS) {
    return currencyCache.code;
  }
  try {
    const health = await gqlData<{ currency?: string | null }>({ query: HEALTH_CURRENCY, auth: "read", timeoutMs: 5_000 });
    const code = health?.currency?.trim();
    const answer = code ? code.toUpperCase() : null;
    //a null from a gateway that answered is a fact (no currency set) and is held; a gateway that
    //could not answer is the catch below, and is asked again next time
    currencyCache = { at: Date.now(), code: answer };
    return answer;
  } catch {
    return null;
  }
}

/** For tests, and for nothing else. */
export function resetPlatformCurrencyCache(): void {
  currencyCache = null;
}

/**
 * What a balance about to be opened for this account should be denominated in.
 *
 * <p>The gateway's `smsg.rates.currency` first; failing that, the currency already on the **parent
 * account's** balance. The rule and the reasoning are in `chooseCurrency` — this is the two lookups
 * it decides between, kept here because they need `pg` and it does not.
 *
 * <p><strong>The parent query runs only when the gateway gave nothing</strong>, which on a
 * database-mode deployment is never. So the ordinary case is one query, unchanged from before this
 * existed.
 *
 * <p>Only the *parent's* balance is consulted, never a sibling's and never the account's own: an
 * account with its own balance row has nothing left to open, and a sibling's code is a fact about a
 * different account that happens to be nearby.
 *
 * <p><strong>Then what the gateway already holds.</strong> With neither, the gateway's own
 * `explicit_currencies` view is read: the currencies on every balance and rate rule, the set its
 * trigger refuses to let grow past one. One code there is the platform's currency by the
 * gateway's own rule -- on a file-mode gateway, where the key lives in `smsg.properties`, it is
 * the only place the panel can read it from. Nothing there means nothing has been priced or
 * funded yet, and the form then asks.
 */
export async function currencyForNewBalance(accountId: string): Promise<InheritedCurrency> {
  const gateway = await platformCurrency();
  if (gateway) {
    return chooseCurrency(gateway, null);
  }

  const id = (accountId ?? "").trim();
  if (!id) {
    return chooseCurrency(null, null);
  }
  //one join from the account to its parent's balance. An account with no parent, a parent with no
  //balance row, and a balance row with no currency all fall out as no row here -- which is the same
  //answer, and correctly so: none of them is evidence of anything
  const rows = await configQuery<{ currency: string | null }>(
    `SELECT b.currency
       FROM app_account a
       JOIN account_balance b ON b.account_id = a.parent_account_id
      WHERE a.id = $1 AND a.parent_account_id IS NOT NULL`,
    [id]
  );
  const parent = rows[0]?.currency;
  if ((parent ?? "").trim()) {
    return chooseCurrency(null, parent);
  }
  const held = await configQuery<{ currency: string | null }>(
    `SELECT DISTINCT currency FROM explicit_currencies WHERE currency IS NOT NULL AND currency <> ''`
  );
  return chooseCurrency(null, null, held.map((r) => r.currency));
}

/** The key both the gateway's rollup and this panel cut billing days on. */
export const BILLING_ZONE_KEY = "smsg.billing.zone";

/**
 * The time zone a billing day starts in.
 *
 * <p><strong>Read from `app_config`, not from an environment variable, because two readers need the
 * same answer.</strong> `UsageCommand` slices `usage_daily` on this zone and the reconciliation
 * slices the live tail on it; if they disagree, a sliver of one day is counted twice or not at all
 * and the discrepancy is exactly as large as the traffic in that sliver. An env var on the gateway
 * host is invisible to this panel, so it could not be that.
 *
 * <p>UTC when unset, matching the gateway's own fallback. A deployment that never sets it is
 * consistent, which is what matters — the wrong zone consistently applied is a reporting choice,
 * whereas two different zones is a bug.
 *
 * <p><strong>Held for {@link ZONE_TTL_MS}</strong>, the same way `config-key-registry-db.ts` holds
 * the key registry. Every windowed aggregate asks for the zone, and the home page used to ask three
 * times per poll per open tab for a value that changes when an operator reconfigures the platform,
 * not between two polls. A failed read is not cached: the UTC fallback is for one answer, and the
 * next caller asks again rather than cutting days in the wrong zone for half a minute.
 */
export async function billingZone(): Promise<string> {
  if (zoneCache && Date.now() - zoneCache.at < ZONE_TTL_MS) {
    return zoneCache.zone;
  }
  try {
    const rows = await configQuery<{ value: string | null }>(
      "SELECT value FROM app_config WHERE key = $1",
      [BILLING_ZONE_KEY]
    );
    const set = rows[0]?.value?.trim();
    const zone = set ? set : "UTC";
    zoneCache = { at: Date.now(), zone };
    return zone;
  } catch {
    //a diagnostic must not fail because a configuration row could not be read
    return "UTC";
  }
}

const ZONE_TTL_MS = 30_000;
let zoneCache: { at: number; zone: string } | null = null;

/** For tests, and for nothing else. */
export function resetBillingZoneCache(): void {
  zoneCache = null;
}
