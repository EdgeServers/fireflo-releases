import { strict as assert } from "node:assert";
import { test } from "node:test";

process.env.AUTH_SECRET = "test-secret-for-totp-pending";
const { PENDING_TTL_MS, readPending, signPending, spendPending } = await import("./totp-pending.ts");

test("a second-step token says who, under which password, until when", () => {
  const now = 1_000_000;
  const token = signPending({ userId: 4, pwdAt: 123, via: "password" }, now)!;
  const p = readPending(token, now + 1000)!;
  assert.equal(p.userId, 4);
  assert.equal(p.pwdAt, 123);
  assert.equal(p.via, "password");
  assert.equal(p.expiresAt, now + PENDING_TTL_MS);
  assert.equal(readPending(token, now + PENDING_TTL_MS), null, "five minutes and no more");
});

test("a token that is not ours, or was changed, reads as nothing", () => {
  const token = signPending({ userId: 4, pwdAt: null, via: "link" })!;
  const [payload, sig] = token.split(".");
  const forged = Buffer.from(JSON.stringify({ ...JSON.parse(Buffer.from(payload, "base64url").toString()), userId: 1 }))
    .toString("base64url");
  assert.equal(readPending(`${forged}.${sig}`), null, "another user under the same signature");
  assert.equal(readPending(`${payload}.${sig.slice(0, -2)}xx`), null);
  assert.equal(readPending("garbage"), null);
  assert.equal(readPending(undefined), null);
  assert.equal(readPending("a".repeat(5000)), null);
});

test("a token is spent by the sign-in it completes", () => {
  const token = signPending({ userId: 9, pwdAt: null, via: "password" })!;
  const p = readPending(token)!;
  spendPending(p);
  assert.equal(readPending(token), null);
});

test("twelve good sign-ins with a code in a row never lock the operator's password step", async () => {
  const { signinLockout, lockoutKey } = await import("./signin-lockout.ts");
  const { secondStepLockKeys } = await import("./totp-pending.ts");
  const lockout = signinLockout();
  const ip = "203.0.113.7";
  const email = "ops@example.com";
  for (let i = 0; i < 12; i++) {
    //the password step, as lib/auth.ts runs it: counted up front, not given back, a token instead
    const passwordKey = lockoutKey(ip, email);
    assert.equal(lockout.tryAttempt(passwordKey), true, `sign-in ${i + 1}: the password step is not locked`);
    const token = signPending({ userId: 4, pwdAt: null, via: "password", lockKey: passwordKey })!;
    //the code step: counted under its own key, then a right code gives every key back
    const pending = readPending(token)!;
    assert.equal(pending.lockKey, passwordKey, "the first step's key rides in the signed token");
    const keys = secondStepLockKeys(pending, ip, email);
    assert.equal(lockout.tryAttempt(keys.counted), true, `sign-in ${i + 1}: the code step is not locked`);
    spendPending(pending);
    for (const key of keys.release) {
      lockout.clear(key);
    }
  }
  assert.equal(lockout.lockedOut(lockoutKey(ip, email)), false);
});

test("the code step from another origin gives back the first step's key as well", async () => {
  const { lockoutKey } = await import("./signin-lockout.ts");
  const { secondStepLockKeys } = await import("./totp-pending.ts");
  const first = lockoutKey("198.51.100.1", "ops@example.com");
  const p = readPending(signPending({ userId: 4, pwdAt: null, via: "password", lockKey: first })!)!;
  const { release } = secondStepLockKeys(p, "198.51.100.2", "ops@example.com");
  assert.ok(release.includes(first));
  assert.ok(release.includes(lockoutKey("198.51.100.2", "ops@example.com")));
  assert.equal(new Set(release).size, release.length);
  //a link sign-in counted nothing at its first step
  const link = readPending(signPending({ userId: 4, pwdAt: null, via: "link" })!)!;
  assert.equal(secondStepLockKeys(link, "198.51.100.2", "ops@example.com").release.length, 2);
});
