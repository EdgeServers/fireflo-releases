import { strict as assert } from "node:assert";
import { test } from "node:test";

import { formatTps } from "./tps-format.ts";

test("a measured rate shows at most two decimal places", () => {
  assert.equal(formatTps(12.333333333333334), (12.33).toLocaleString());
  assert.equal(formatTps(0.006), "0.01");
  assert.equal(formatTps(40), "40", "a whole number stays whole");
  assert.equal(formatTps(0), "0");
});
