import { test } from "node:test";
import assert from "node:assert/strict";
import {
  chooseCurrency,
  isBillingMode,
  parseAmount,
  validateBillingChange,
} from "./balance-types.ts";

/**
 * The one conversion between what somebody types and what the ledger stores.
 *
 * <p>Untested until a transfer route shipped a second copy of it with no ceiling, which is the
 * failure mode `lib/credential-types.ts` names about a different rule: *"a second implementation
 * drifting means the panel and the gateway disagree … and the disagreement is silent"*. Both money
 * paths — the operator's top-up and a reseller's transfer — now come through here, so it is worth
 * pinning rather than trusting.
 */

test("a plain amount scales by ten thousand without arithmetic", () => {
  assert.equal(parseAmount("1"), 10_000);
  assert.equal(parseAmount("100.5"), 1_005_000);
  assert.equal(parseAmount("0.0001"), 1);
});

test("the float trap this exists to avoid", () => {
  //0.0035 * 10000 is 34.999999999999996 in a JavaScript float. Padding and concatenating cannot be
  //inexact, because no arithmetic happens at all
  assert.equal(parseAmount("0.0035"), 35);
  assert.equal(parseAmount("12462.2795"), 124_622_795);
});

test("whitespace is not significant, but anything else in the string is", () => {
  assert.equal(parseAmount("  42  "), 420_000);
  assert.equal(parseAmount(""), null);
  assert.equal(parseAmount("abc"), null);
  assert.equal(parseAmount("1,000"), null, "a thousands separator is not a number here");
  assert.equal(parseAmount("1e4"), null, "exponent notation would be exact and is still refused");
  assert.equal(parseAmount("-5"), null, "the sign is the caller's decision, not this function's");
});

test("a fifth decimal place is refused rather than rounded", () => {
  //the column stores ten-thousandths. Rounding here would accept an amount and store a different
  //one, which is the class of bug the string manipulation exists to prevent
  assert.equal(parseAmount("1.00001"), null);
  assert.equal(parseAmount("1.0000"), 10_000);
});

test("an amount too large to survive JSON is refused, not silently rounded", () => {
  //Number.MAX_SAFE_INTEGER is 9.007e15 and the column is a BIGINT, so a large enough amount loses
  //precision on its way through the request body before Postgres ever sees it. This is also the
  //ceiling that stops a 40-digit amount reaching balance_ledger.delta and failing in the driver.
  //
  //The practical limit is LOWER than it looks, and worth stating: everything is scaled by ten
  //thousand first, so the largest whole amount that survives is about 900 billion — not 9
  //quadrillion. 999,999,999,999 is already past it
  assert.equal(parseAmount("900000000000"), 9_000_000_000_000_000);
  assert.equal(parseAmount("999999999999"), null, "9.99e15 scaled is past MAX_SAFE_INTEGER");
  assert.equal(parseAmount("99999999999999999999999999999999999999"), null);
  assert.equal(parseAmount("9".repeat(400)), null, "and an absurd one is refused the same way");
});

test("zero parses, and rejecting it is the caller's job", () => {
  //both callers check `<= 0` themselves, and they should: 0 is a well-formed amount and a
  //meaningless transfer, which are different failures deserving different messages
  assert.equal(parseAmount("0"), 0);
  assert.equal(parseAmount("0.0000"), 0);
});

test("a postpaid account cannot be saved with a zero credit limit", () => {
  //the expensive misreading. Zero is not unlimited anywhere in this system -- not in the column
  //comment, not in the gateway, not here -- so a form that accepted it would be saving an account
  //that silently cannot send. The refusal lives in the validator rather than the form so the route
  //enforces it too
  assert.notEqual(validateBillingChange("POSTPAID", "0"), null);
  assert.match(validateBillingChange("POSTPAID", "0") ?? "", /not unlimited/);
  assert.match(validateBillingChange("POSTPAID", "0.0000") ?? "", /not unlimited/);
});

test("a postpaid limit is an amount, on the same rules as every other amount", () => {
  assert.equal(validateBillingChange("POSTPAID", "500.0000"), null);
  assert.equal(validateBillingChange("POSTPAID", "0.0001"), null);
  assert.match(validateBillingChange("POSTPAID", "-5") ?? "", /not an amount/);
  assert.match(validateBillingChange("POSTPAID", "1.00001") ?? "", /not an amount/);
  assert.match(validateBillingChange("POSTPAID", "1e3") ?? "", /not an amount/);
});

test("prepaid needs no limit, and an unknown mode is refused", () => {
  //switching back to prepaid clears the limit, so whatever is in the box is irrelevant
  assert.equal(validateBillingChange("PREPAID", ""), null);
  assert.equal(validateBillingChange("PREPAID", "nonsense"), null);
  assert.match(validateBillingChange("postpaid", "5") ?? "", /prepaid or postpaid/);
  assert.match(validateBillingChange(undefined, "5") ?? "", /prepaid or postpaid/);
});

test("isBillingMode refuses anything the constraint would", () => {
  assert.equal(isBillingMode("PREPAID"), true);
  assert.equal(isBillingMode("POSTPAID"), true);
  assert.equal(isBillingMode("prepaid"), false);
  assert.equal(isBillingMode(null), false);
});

/**
 * The currency inheritance rule.
 *
 * <p>Pinned because getting it wrong is unrecoverable rather than merely wrong: `openBalance` is
 * `ON CONFLICT DO NOTHING`, so a balance opened in the wrong code cannot be corrected by opening the
 * account again, and every price it is spent against is expressed in a different unit.
 */

test("the gateway wins, whatever the parent says", () => {
  assert.deepEqual(chooseCurrency("AUD", "USD"), { code: "AUD", from: "gateway" });
  assert.deepEqual(chooseCurrency("AUD", null), { code: "AUD", from: "gateway" });
});

test("the parent is used only when the gateway is silent", () => {
  assert.deepEqual(chooseCurrency(null, "AUD"), { code: "AUD", from: "parent" });
  //the file-mode case: `smsg.rates.currency` lives in smsg.properties, which the panel cannot read,
  //so `platformCurrency()` answers null and the parent is the only evidence there is
  assert.deepEqual(chooseCurrency(undefined, "aud"), { code: "AUD", from: "parent" });
});

test("neither is null, and null carries no source", () => {
  //the answer the two surfaces then treat differently: /cp asks, the portal refuses
  assert.deepEqual(chooseCurrency(null, null), { code: null, from: null });
  assert.deepEqual(chooseCurrency(undefined, undefined), { code: null, from: null });
});

test("a parent with no balance row does not inherit anything", () => {
  //the case that matters. `currencyForNewBalance` passes null for a parent that has no balance row,
  //no currency on it, or no parent at all -- there is deliberately no third step that would reach
  //for some other account's code and present a guess as an inherited fact
  assert.deepEqual(chooseCurrency(null, null), { code: null, from: null });
  assert.deepEqual(chooseCurrency("", ""), { code: null, from: null });
});

test("what the gateway already holds is used when the key and the parent are both silent", () => {
  //the file-mode case: the key is in smsg.properties, there is no parent, but four balances
  //already carry AUD and the gateway's trigger would refuse anything else
  assert.deepEqual(chooseCurrency(null, null, ["AUD", "aud", " AUD "]), { code: "AUD", from: "held" });
  //the key still wins, and so does the parent, over what is held
  assert.deepEqual(chooseCurrency("INR", null, ["AUD"]), { code: "INR", from: "gateway" });
  assert.deepEqual(chooseCurrency(null, "INR", ["AUD"]), { code: "INR", from: "parent" });
  //two codes held is a state the trigger does not allow; nothing is guessed from it
  assert.deepEqual(chooseCurrency(null, null, ["AUD", "INR"]), { code: null, from: null });
  //blanks are not codes; nothing held is the empty platform, and that still asks
  assert.deepEqual(chooseCurrency(null, null, ["", null, undefined]), { code: null, from: null });
  assert.deepEqual(chooseCurrency(null, null, []), { code: null, from: null });
});

test("whitespace and case are not a currency", () => {
  assert.deepEqual(chooseCurrency("   ", "  aud  "), { code: "AUD", from: "parent" });
  assert.deepEqual(chooseCurrency(" aud ", null), { code: "AUD", from: "gateway" });
});
