/**
 * What a confirmation modal says before a change is sent. Database-free and tested.
 *
 * <p>Every change on the vendor, server, account, pricing and routing screens is confirmed in a modal
 * before it reaches the gateway, and every delete asks for the word {@link DELETE_WORD} typed out.
 * These are the pieces of that which are worth getting exactly right: what counts as typing the
 * word, and how a list of changes is described.
 */

/** The word a delete asks for. Exact: case-sensitive, no surrounding space. */
export const DELETE_WORD = "DELETE";

/** One line of a change list: what moved, from what to what. */
export interface ChangeLine {
  label: string;
  from?: string;
  to?: string;
  /** What this one change does, in a sentence under it -- "the next move will archive 4 days". */
  note?: string;
}

/**
 * Whether what was typed is the word asked for.
 *
 * <p>Exact on purpose. Accepting `delete` or a trailing space would make the field a formality, and
 * the point of typing a word is that it cannot be done by reflex.
 */
export function typedMatches(typed: string, word: string = DELETE_WORD): boolean {
  return typed === word;
}

/**
 * The settings a worker save changes, as change lines.
 *
 * <p>Only keys whose value differs are listed. A secret is never shown, either side -- it reads
 * "changed" -- because the modal is on screen and a password is not something to display to confirm.
 * A key cleared to empty reads "(default)", which is what the gateway falls back to.
 */
export function workerChanges(
  original: Record<string, string>,
  next: Record<string, string>,
  secretKeys: ReadonlySet<string> = new Set()
): ChangeLine[] {
  const keys = [...new Set([...Object.keys(original), ...Object.keys(next)])].sort();
  const lines: ChangeLine[] = [];
  for (const key of keys) {
    const before = (original[key] ?? "").trim();
    const after = (next[key] ?? "").trim();
    if (before === after) {
      continue;
    }
    if (secretKeys.has(key)) {
      lines.push({ label: key, to: "changed" });
      continue;
    }
    lines.push({ label: key, from: before === "" ? "(default)" : before, to: after === "" ? "(default)" : after });
  }
  return lines;
}

/**
 * A staged table's changes in one sentence: "2 rules edited, 1 moved, 1 removed, 1 added".
 *
 * <p>Items are matched by `key`; an item in both lists is edited when its `fingerprint` differs and
 * moved when its position among the surviving items differs. Nothing listed means nothing changed.
 */
export function stagedSummary<T>(
  before: readonly T[],
  after: readonly T[],
  key: (item: T) => string,
  fingerprint: (item: T) => string,
  noun: [singular: string, plural: string] = ["rule", "rules"]
): string {
  const beforeKeys = before.map(key);
  const afterKeys = after.map(key);
  const beforeSet = new Set(beforeKeys);
  const afterSet = new Set(afterKeys);
  const added = afterKeys.filter((k) => !beforeSet.has(k)).length;
  const removed = beforeKeys.filter((k) => !afterSet.has(k)).length;
  const prints = new Map(before.map((item) => [key(item), fingerprint(item)]));
  const edited = after.filter((item) => prints.has(key(item)) && prints.get(key(item)) !== fingerprint(item)).length;
  const keptBefore = beforeKeys.filter((k) => afterSet.has(k));
  const keptAfter = afterKeys.filter((k) => beforeSet.has(k));
  const moved = keptAfter.filter((k, i) => keptBefore[i] !== k).length;

  const parts: string[] = [];
  const first = (n: number, verb: string) => `${n} ${n === 1 ? noun[0] : noun[1]} ${verb}`;
  for (const [n, verb] of [[edited, "edited"], [moved, "moved"], [removed, "removed"], [added, "added"]] as const) {
    if (n > 0) {
      parts.push(parts.length === 0 ? first(n, verb) : `${n} ${verb}`);
    }
  }
  return parts.join(", ");
}
