/**
 * What `/api/control/me/totp` answers, for the operator's two-factor screen. Client-safe: types and
 * words only.
 */
export type TotpView =
  | {
      available: false;
      /**
       * `noConfig`: no CONFIG_DATABASE_URL, so the panel can neither read nor keep an authenticator.
       * `olderGateway`: the database has not run V1.114.0. `envOperator`: the deprecated panel.env
       * sign-in, which has no user row to keep one in.
       */
      reason: "noConfig" | "olderGateway" | "envOperator";
    }
  | {
      available: true;
      email: string;
      enabled: boolean;
      enabledAt: string | null;
      pending: boolean;
      /** `smsg.panel.operator.totp.required`. */
      required: boolean;
      /** Required and not set up: this session reaches the set-up and nothing else. */
      enrolmentDue: boolean;
      /** No FIREFLO_SECRETS_KEY on this panel: authenticator secrets are stored unencrypted. */
      unsealed: boolean;
    };

/** The warning shown while authenticator secrets are stored unencrypted. Not a block. */
export const TOTP_UNSEALED =
  "Authenticator secrets are stored unencrypted in the database. Set FIREFLO_SECRETS_KEY on the panel (and the gateway) to seal them.";

/** A started set-up, answered once. */
export interface TotpSetup {
  /** The QR code as an SVG data URI, drawn on the server. */
  qr: string;
  /** The key in groups of four, for an app that cannot scan. */
  key: string;
  uri: string;
}

/** Why two-factor is not offered here, in a sentence. */
export const TOTP_UNAVAILABLE: Record<Extract<TotpView, { available: false }>["reason"], string> = {
  noConfig:
    "This panel has no CONFIG_DATABASE_URL, so it cannot keep an authenticator for anyone: sign-in stays a password or a link.",
  olderGateway:
    "Two-factor authentication arrives with the gateway's 0.15 database update (V1.114.0), which this database has not run yet.",
  envOperator:
    "You are signed in with the panel.env operator account, which has no user record to keep an authenticator in. Sign in as a real user.",
};
