import { strict as assert } from "node:assert";
import { test } from "node:test";

process.env.AUTH_SECRET = "test-secret-for-auth-proof";
const { checkClaim, signClaim } = await import("./auth-proof.ts");

test("a claim proof holds for its user, value and purpose only", () => {
  const proof = signClaim("pwd", 7, 1_700_000_000_000);
  assert.ok(proof);
  assert.equal(checkClaim("pwd", 7, 1_700_000_000_000, proof), true);
  assert.equal(checkClaim("pwd", "7", 1_700_000_000_000, proof), true, "the token carries the id as a string");
  assert.equal(checkClaim("pwd", 8, 1_700_000_000_000, proof), false, "another user");
  assert.equal(checkClaim("pwd", 7, 1_700_000_000_001, proof), false, "another stamp: a stale cookie cannot pick its own");
  assert.equal(checkClaim("mfa", 7, 1_700_000_000_000, proof), false, "another purpose");
  assert.equal(checkClaim("pwd", 7, 1_700_000_000_000, undefined), false, "no proof, no refresh");
  assert.equal(checkClaim("pwd", 7, 1_700_000_000_000, "x".repeat(43)), false);
});

test("without AUTH_SECRET nothing is signed and nothing checks", () => {
  const saved = process.env.AUTH_SECRET;
  delete process.env.AUTH_SECRET;
  try {
    assert.equal(signClaim("pwd", 7, 1), null);
    assert.equal(checkClaim("pwd", 7, 1, "anything"), false);
  } finally {
    process.env.AUTH_SECRET = saved;
  }
});
