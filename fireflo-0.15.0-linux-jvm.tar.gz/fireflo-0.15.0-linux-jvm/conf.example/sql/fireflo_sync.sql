-- The read-only role the gateway's platform sync feeds run as (V1.102.0).
--
-- Migration V1.102.0 creates this role and grants these reads when the migrating role may create
-- roles. Where it may not -- a managed PostgreSQL, a locked-down role -- run this file as the
-- owner of the tables (or a superuser), then set the password and point the gateway at it:
--
--   FIREFLO_SYNC_DB_URL=jdbc:postgresql://...           (defaults to FIREFLO_DB_URL)
--   FIREFLO_SYNC_DB_USER=fireflo_sync
--   FIREFLO_SYNC_DB_PASSWORD=...
--
-- What the role may read: outcomes, usage, the ledger, balances, accounts, products, price rules,
-- sender IDs and templates in full; cdr_submit WITHOUT the message body; app_credential WITHOUT
-- password and api_key. Nothing it reads is a secret or a customer's words. It writes nothing.
-- Partitions of cdr_submit and cdr_final created later by the gateway are read through the
-- parent table, which is where these privileges are checked.
--
-- Since V1.112.0 (0.15) the call records are in two tables each: cdr_submit / cdr_final for the
-- last few days, cdr_submit_archive / cdr_final_archive for history, and the cdr_submit_all /
-- cdr_final_all views over both, which the feeds read for old windows. All six get the same reads.

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'fireflo_sync') THEN
        CREATE ROLE fireflo_sync NOLOGIN;
    END IF;
END $$;

GRANT USAGE ON SCHEMA public TO fireflo_sync;
GRANT SELECT ON cdr_final, usage_hourly, usage_daily, balance_ledger, account_balance,
                app_account, app_product, app_rate_rule, app_rate_rule_condition,
                app_header, app_template TO fireflo_sync;

-- cdr_submit, every column but the message body
DO $$
DECLARE
    cols text;
BEGIN
    SELECT string_agg(quote_ident(column_name), ', ' ORDER BY ordinal_position) INTO cols
      FROM information_schema.columns
     WHERE table_schema = 'public' AND table_name = 'cdr_submit' AND column_name <> 'body';
    EXECUTE format('GRANT SELECT (%s) ON cdr_submit TO fireflo_sync', cols);

    -- the archive and the views over both (V1.112.0), the same columns
    IF to_regclass('cdr_submit_archive') IS NOT NULL THEN
        EXECUTE format('GRANT SELECT (%s) ON cdr_submit_archive TO fireflo_sync', cols);
        EXECUTE format('GRANT SELECT (%s) ON cdr_submit_all TO fireflo_sync', cols);
        GRANT SELECT ON cdr_final_archive, cdr_final_all TO fireflo_sync;
    END IF;

    SELECT string_agg(quote_ident(column_name), ', ' ORDER BY ordinal_position) INTO cols
      FROM information_schema.columns
     WHERE table_schema = 'public' AND table_name = 'app_credential'
       AND column_name NOT IN ('password', 'api_key');
    EXECUTE format('GRANT SELECT (%s) ON app_credential TO fireflo_sync', cols);
END $$;

-- Then, by hand, with a password of your own:
--   ALTER ROLE fireflo_sync LOGIN PASSWORD 'change-me';
