import { oneRowPerMessage } from "./cdr-grain";
import { query } from "@/lib/metrics-db";
import {
  hasBodyColumn,
  hasEventTable,
  hasInterimTable,
  hasReassembledParts,
  hasRegisteredDelivery,
  hasSubmitStatus,
  hasVendorErrCode,
  hasRouteRule,
} from "@/lib/metrics-schema";
import { decodeReceiptRequest, receiptForwards } from "@/lib/receipt-request";
import {
  messageIdClause,
  type CdrCursor,
  type CdrFilters,
  type CdrRow,
  type CustomerEvent,
  type MessageReceipt,
} from "@/lib/cdr-request";

/**
 * Row-level access to the gateway's call records, for the "what happened to this message" question
 * that no aggregate in `metrics-queries.ts` can answer.
 *
 * <p>Two decisions here are load bearing and easy to undo by accident:
 *
 * <ol>
 *   <li><b>Paging is keyset, not OFFSET.</b> `submitted_at` is not unique -- messages accepted in
 *       the same instant are ordinary -- so the sort key is the pair `(submitted_at, id)` and a page
 *       asks for rows strictly before the last pair it saw. OFFSET on a table that is being written
 *       to continuously silently repeats and drops rows at page boundaries, and the rows that vanish
 *       are the ones nobody saw, so nobody reports it.</li>
 *   <li><b>Every filter value is a bind parameter.</b> The WHERE clause is assembled from a fixed
 *       set of fragments; no caller string ever reaches the SQL text. `metrics-db.ts` states that
 *       this module never interpolates a value or an identifier, and dynamic filtering is exactly
 *       where that promise usually breaks.</li>
 * </ol>
 *
 * <p>PENDING is a real state, not a missing one. At the time of writing 93% of rows have no receipt
 * yet; a UI that renders those as blanks looks broken when it is merely accurate.
 */

/**
 * Note on where {@link CdrFilters} and the outcome list live: `cdr-request.ts`, not here.
 *
 * <p>This module opens a database pool, so importing anything from it -- even a string constant --
 * drags `pg` into whatever bundle the importer lands in. A client component that wants the list of
 * outcomes for a dropdown would pull a Postgres driver into the browser, and the failure is not a
 * clear one: the bundler cannot resolve `dns`, the shared client chunk fails to build, and *every*
 * page in the app starts returning 500 rather than the one that made the mistake.
 */

export type { CdrCursor, CdrRow, CustomerEvent, MessageReceipt } from "@/lib/cdr-request";

export interface CdrPage {
  rows: CdrRow[];
  /** null when this was the last page. */
  nextCursor: CdrCursor | null;
}

/**
 * A page bigger than this is a report, and reports go through the export path.
 *
 * <p>Enforced by the HTTP route rather than here, because the export worker is a legitimate caller
 * asking for far more than a browser ever should — clamping in `searchCdrs` would silently reduce
 * its 5,000-row batches to 200 and turn one export into twenty-five times as many round trips.
 */
export const MAX_PAGE = 200;
export const DEFAULT_PAGE = 50;

/** The hard ceiling, for any caller. Beyond this a single result set stops fitting comfortably in memory. */
export const MAX_BATCH = 5_000;

/**
 * The outcome of a message, deduplicated.
 *
 * <p>The same LATERAL `metrics-queries.ts` uses, and for the same reason: `cdr_final` has no
 * uniqueness constraint, so concurrent receipts append two rows by design and a plain LEFT JOIN
 * would return the message twice. `final_at` is carried here as well, which the aggregates do not
 * need -- on a single record, when the receipt arrived is half the question.
 */
const OUTCOME_LATERAL = `
  LEFT JOIN LATERAL (
    SELECT f.final_state, f.dlr_state, f.err_code, f.final_at
      FROM cdr_final f
     WHERE f.gateway_msg_id = s.gateway_msg_id AND f.part_no = s.part_no
     --A real receipt outranks a swept EXPIRED, whichever landed first: EXPIRED is synthetic,
     --written by the gateway's expiry sweep, and a genuine receipt can still arrive after it
     --because the correlation index outlives the deadline. false sorts before true.
     --SAME RULE IN UsageRollup.java AND THREE OTHER lib/ QUERIES. Change one, change all five.
     ORDER BY (f.final_state = 'EXPIRED'), f.final_at
     LIMIT 1
  ) o ON TRUE`;

/**
 * Every scalar of `cdr_submit`, plus the receipt.
 *
 * <p>These are all fixed-width or short identifiers, so selecting the lot costs essentially nothing
 * over selecting half and lets the column chooser be a client-side decision rather than a round trip
 * per preference change.
 */
const SCALARS = `
  s.id, s.gateway_msg_id, s.part_no, s.part_count, s.retry_count,
  s.submitted_at, s.accepted_at,
  s.account_id, s.system_id, s.product, s.ingress, s.in_gateway, s.vendor,
  s.source_addr, s.dest_addr, s.mcc, s.mnc, s.dcs, s.msg_type, s.operator_msg_id,
  s.cost_rate, s.cost_units, s.cost,
  s.price_rate, s.billed_units, s.price,
  s.margin, s.margin_pct, s.margin_status, s.cost_rule_id, s.price_rule_id,
  COALESCE(s.price_currency, s.cost_currency) AS currency,
  o.final_state, o.dlr_state, o.err_code, o.final_at`;

/**
 * The carrier's own failure code, beside the one we translated it into.
 *
 * <p>Gated like `registered_delivery` and `submit_status` above, and for the same reason: naming a
 * column an older gateway does not have is a hard error, not a null.
 *
 * <p><strong>Absent is not "the same as err_code".</strong> The gateway's own column comment is
 * explicit — NULL means the carrier reported nothing, or the row predates the column, and it was
 * deliberately not backfilled because copying `err_code` across would manufacture evidence. Every
 * surface that renders this has to say "not recorded" rather than repeating the translated value.
 */
const VENDOR_ERR_CODE = "o.vendor_err_code";

/**
 * `OUTCOME_LATERAL`, plus the carrier's code when the schema has it.
 *
 * <p>The shared lateral in `metrics-queries.ts` is used by seven other queries that have no
 * business selecting this and no `SchemaSupport` to gate it with, so it stays as it is and this
 * wraps it. A string replace rather than a second copy of the join: the ordering rule inside it
 * ("a real receipt outranks a swept EXPIRED") is stated there as being shared by five call sites,
 * and duplicating the join would make that comment false.
 */
function outcomeLateral(have: SchemaSupport): string {
  return have.vendorErrCode
    ? OUTCOME_LATERAL.replace(
        "SELECT f.final_state, f.dlr_state, f.err_code, f.final_at",
        "SELECT f.final_state, f.dlr_state, f.err_code, f.final_at, f.vendor_err_code"
      )
    : OUTCOME_LATERAL;
}

/**
 * What the customer asked to be told, as the raw octet.
 *
 * <p>A `smallint`, so it belongs with the scalars above on cost — it is separated only because it
 * arrives in the gateway's V1.33.0 and naming a column that does not exist is a hard error, not a
 * null. See {@link columns}.
 */
const REGISTERED_DELIVERY = "s.registered_delivery";

/**
 * The vendor's `submit_sm_resp` status for this attempt, or null when nothing recorded one.
 *
 * <p>Arrives in the gateway's V1.40.0, so it is gated the same way as `registered_delivery` above
 * -- naming a column an older gateway does not have is a hard error, not a null.
 */
const SUBMIT_STATUS = "s.submit_status";

/**
 * Which routing rule sent this ATTEMPT where it went — the gateway's V1.47.0.
 *
 * <p>Gated like its neighbours: naming a column an older gateway lacks is a hard error, not a
 * null. NULL on a row that has it means unrecorded — written before the migration, or an attempt
 * that reached a vendor without matching a rule — and never "no rule".
 */
const ROUTE_RULE = "s.route_rule";

/**
 * What a query selects.
 *
 * <p>`tlvs` is the only difference and the only reason this switch exists: it is unbounded TEXT, and
 * two hundred of them a page is a real cost paid by every operator browsing traffic, for a column
 * the table cannot usefully render anyway. The export and the detail view ask for `"full"`.
 */
export type CdrColumnSet =
  | "list" | "full" | "list+received" | "list+sent" | "list+tlvs"
  //the body variants: `+body` is the operator's truncated one, `+bodyfull` the customer's whole
  | "list+body" | "list+bodyfull" | "list+tlvs+body" | "list+received+bodyfull";

/**
 * The three unbounded TLV columns, and why they are not all in every set.
 *
 * <p>`full` takes all three: the detail view compares them and the export is the complete record.
 * `list+received` takes only what the customer sent, for the portal — which has no detail view, so
 * the only way to show a customer their own TLVs is a column in the list. Selecting all three there
 * would put three unbounded fields on a fifty-row page to display one of them.
 *
 * <p>`list+sent` and `list+tlvs` are the operator's equivalents. The operator list used to select no
 * TLV column at all, so ticking one in the chooser produced a column of empty cells — the data was
 * never asked for. Each set fetches exactly what has been ticked and nothing else, which is the
 * whole point: these are unbounded TEXT and a page is two hundred rows.
 */
const TLV_ALL = "s.tlvs, s.tlvs_received, s.tlvs_sent";
const TLV_RECEIVED = "s.tlvs_received";
const TLV_SENT = "s.tlvs_sent";

/**
 * The message text, in the two shapes the two audiences get.
 *
 * <p>The customer sees their own message whole; the operator's list gets the first 160 characters —
 * the same length the gateway calls an excerpt — with the whole thing on the detail view. That is
 * not a security boundary, since an operator who wants the rest can open one row; it keeps routine
 * staff browsing from being a wall of other people's content, and keeps a 1,600 character body out
 * of a fifty-row table.
 *
 * <p>Null on every row unless the gateway's `smsg.cdr.body` is on, which it is not by default.
 */
const BODY_FULL = "s.body";
const BODY_EXCERPT = "left(s.body, 160) AS body";

/** Which optional columns this gateway's schema actually has. See `metrics-schema.ts`. */
export interface SchemaSupport {
  /** `cdr_submit.body`, from V1.31.0. */
  body: boolean;
  /** `cdr_submit.registered_delivery`, from V1.33.0. */
  registeredDelivery: boolean;
  /** `cdr_submit.reassembled_parts`, from V1.34.0. */
  reassembledParts: boolean;
  /** `cdr_submit.submit_status`, from V1.40.0. */
  submitStatus: boolean;
  /** `cdr_submit.route_rule`, from V1.47.0. */
  routeRule: boolean;
  /**
   * `cdr_final.vendor_err_code`, from the 0.9.0 baseline.
   *
   * <p>The only optional column on `cdr_final` rather than `cdr_submit`, which is why it is gated
   * at the lateral join below rather than in {@link columns}.
   */
  vendorErrCode: boolean;
}

/**
 * @param have what the schema in front of us has. Each optional column is dropped on its own rather
 *     than the whole projection being downgraded to a narrower set — the TLV columns in the same set
 *     are unrelated and must survive, which is the trap in mapping one set onto another. The two
 *     flags are independent for the same reason: a gateway can be past V1.31.0 and short of V1.33.0
 */
function columns(set: CdrColumnSet, have: SchemaSupport): string {
  const full = have.body ? `, ${BODY_FULL}` : "";
  const excerpt = have.body ? `, ${BODY_EXCERPT}` : "";
  const withRegisteredDelivery =
    have.registeredDelivery ? `${SCALARS}, ${REGISTERED_DELIVERY}` : SCALARS;
  const withSubmitStatus =
    have.submitStatus ? `${withRegisteredDelivery}, ${SUBMIT_STATUS}` : withRegisteredDelivery;
  const withRouteRule =
    have.routeRule ? `${withSubmitStatus}, ${ROUTE_RULE}` : withSubmitStatus;
  const scalars =
    have.vendorErrCode ? `${withRouteRule}, ${VENDOR_ERR_CODE}` : withRouteRule;
  switch (set) {
    case "full":
      return `${scalars}, ${TLV_ALL}${full}`;
    case "list+tlvs":
      return `${scalars}, ${TLV_RECEIVED}, ${TLV_SENT}`;
    case "list+tlvs+body":
      return `${scalars}, ${TLV_RECEIVED}, ${TLV_SENT}${excerpt}`;
    case "list+received":
      return `${scalars}, ${TLV_RECEIVED}`;
    case "list+received+bodyfull":
      return `${scalars}, ${TLV_RECEIVED}${full}`;
    case "list+sent":
      return `${scalars}, ${TLV_SENT}`;
    case "list+body":
      return `${scalars}${excerpt}`;
    case "list+bodyfull":
      return `${scalars}${full}`;
    default:
      return scalars;
  }
}

/** Every probe at once, since the queries here need them together and none depends on another. */
async function schemaSupport(): Promise<SchemaSupport> {
  const [body, registeredDelivery, reassembledParts, submitStatus, vendorErrCode, routeRule] =
    await Promise.all([
      hasBodyColumn(),
      hasRegisteredDelivery(),
      hasReassembledParts(),
      hasSubmitStatus(),
      hasVendorErrCode(),
      hasRouteRule(),
    ]);
  return { body, registeredDelivery, reassembledParts, submitStatus, vendorErrCode, routeRule };
}

/**
 * The narrowest set that covers the columns a caller has ticked.
 *
 * <p>Shared by both list endpoints so they cannot drift on which column implies which projection —
 * the portal's own allow-list still decides what a customer may tick before this is reached.
 */
export function columnSetFor(
  wanted: Iterable<string>,
  audience: "operator" | "customer" = "operator"
): CdrColumnSet {
  const ticked = new Set(wanted);
  const received = ticked.has("tlvsReceived");
  const sent = ticked.has("tlvsSent");
  const body = ticked.has("body");

  //the portal: it may ask for its own content whole, and never for the sent TLV set. Its allow-list
  //has already refused anything else by the time this runs; this decides projection, not permission
  if (audience === "customer") {
    if (received && body) {
      return "list+received+bodyfull";
    }
    if (body) {
      return "list+bodyfull";
    }
    return received ? "list+received" : "list";
  }

  if (received && sent) {
    return body ? "list+tlvs+body" : "list+tlvs";
  }
  if (sent) {
    return "list+sent";
  }
  if (received) {
    return "list+received";
  }
  return body ? "list+body" : "list";
}

/**
 * Builds the WHERE clause and its parameter list together, so the two cannot drift.
 *
 * <p>Returns fragments only -- the `$n` placeholders are produced here from the length of the array
 * being filled, never from a caller-supplied index, which is how off-by-one binding turns into a
 * filter that silently matches everything.
 */
function buildWhere(filters: CdrFilters, have: SchemaSupport): { sql: string; params: unknown[] } {
  const params: unknown[] = [];
  const clauses: string[] = [];

  const bind = (value: unknown): string => {
    params.push(value);
    return `$${params.length}`;
  };

  //the default view, and the one the (submitted_at DESC, id DESC) index serves without a sort
  if (filters.firstAttemptOnly !== false) {
    clauses.push(oneRowPerMessage());
  }
  if (filters.since) {
    clauses.push(`s.submitted_at >= ${bind(filters.since)}`);
  }
  if (filters.until) {
    clauses.push(`s.submitted_at < ${bind(filters.until)}`);
  }

  //the portal's boundary, and it is applied before anything a caller supplied. An empty array
  //would mean "no accounts" rather than "all", which is the safe reading and also what a reseller
  //with no children should never produce -- scopeFor always includes the session's own account
  if (filters.accountIn) {
    clauses.push(`s.account_id = ANY(${bind(filters.accountIn)})`);
  }

  //exact match, not ILIKE: these are identifiers the operator copies from somewhere else, and a
  //prefix match on account_id would quietly mix two customers' traffic into one view
  const exact: [keyof CdrFilters, string][] = [
    ["accountId", "s.account_id"],
    ["systemId", "s.system_id"],
    ["vendor", "s.vendor"],
    ["product", "s.product"],
    ["ingress", "s.ingress"],
  ];
  for (const [key, column] of exact) {
    const value = filters[key];
    if (typeof value === "string" && value.trim()) {
      clauses.push(`${column} = ${bind(value.trim())}`);
    }
  }

  //The message id is the one identifier with more than one right answer. A concatenated message was
  //acknowledged with one id per segment, so the customer holds several and quotes whichever is on
  //the receipt they are chasing; only the first is gateway_msg_id. The array half is served by the
  //GIN index the gateway creates in V1.34.0, and is skipped entirely against a gateway that has not
  //applied it -- where naming the column is a hard error that would take out id search altogether.
  //the bracketing this depends on is a security boundary, which is why it is a named function in
  //`cdr-request.ts` with a test rather than a ternary here. See messageIdClause.
  if (typeof filters.gatewayMsgId === "string" && filters.gatewayMsgId.trim()) {
    clauses.push(messageIdClause(bind(filters.gatewayMsgId.trim()), have.reassembledParts));
  }

  //the message text is the one substring search, and the only filter here that is not an identifier
  //somebody pasted. It is safe to run because it can only ever be reached with the date range above
  //already in the same WHERE -- an unbounded ILIKE over this table is a sequential scan of every
  //message ever sent. The trigram index the gateway creates is what makes the bounded one a lookup
  if (typeof filters.body === "string" && filters.body.trim()) {
    clauses.push(`s.body ILIKE ${bind(`%${filters.body.trim()}%`)}`);
  }

  //phone numbers are the exception. They arrive with and without a leading +, with and without the
  //country code, so a prefix match is what someone actually means by "messages to 6141..."
  for (const [key, column] of [
    ["destAddr", "s.dest_addr"],
    ["sourceAddr", "s.source_addr"],
  ] as [keyof CdrFilters, string][]) {
    const value = filters[key];
    if (typeof value === "string" && value.trim()) {
      //the pattern is a parameter; only the LIKE operator is in the SQL text
      clauses.push(`${column} LIKE ${bind(`${escapeLike(value.trim())}%`)}`);
    }
  }

  if (filters.outcome === "PENDING") {
    clauses.push("o.final_state IS NULL");
  } else if (filters.outcome) {
    clauses.push(`o.final_state = ${bind(filters.outcome)}`);
  }

  return { sql: clauses.length ? `WHERE ${clauses.join(" AND ")}` : "", params };
}

/**
 * Neutralises the wildcards in a LIKE pattern.
 *
 * <p>Without this a destination of `%` matches every message in the table -- not an injection, but
 * the same surprise: a filter that appears to be typed text turning out to be syntax.
 */
function escapeLike(value: string): string {
  return value.replace(/[\\%_]/g, (c) => `\\${c}`);
}

/**
 * One page of call records, newest first.
 *
 * @param cursor the last row of the previous page, or null/undefined for the first page
 * @param limit clamped to {@link MAX_BATCH}; a caller asking for more gets the cap, not an error
 */
export async function searchCdrs(
  filters: CdrFilters,
  cursor?: CdrCursor | null,
  limit: number = DEFAULT_PAGE,
  set: CdrColumnSet = "list"
): Promise<CdrPage> {
  const size = Math.min(Math.max(Math.trunc(limit) || DEFAULT_PAGE, 1), MAX_BATCH);
  //asked once per process, not per row: against a gateway that has not applied the migration there
  //is no `body` column, and both selecting it and filtering on it are errors. Degrading here rather
  //than at the four call sites means neither list can forget -- and a ticked column that comes back
  //empty is a far better failure than a page that will not load
  const have = await schemaSupport();
  const { sql: where, params } = buildWhere(have.body ? filters : { ...filters, body: null }, have);

  let keyset = "";
  if (cursor) {
    //row-wise comparison, which matches the compound index exactly. Written as a tuple rather than
    //`ts < $1 OR (ts = $1 AND id < $2)` because the expanded form is where the boundary bugs live
    params.push(cursor.submittedAt, cursor.id);
    const ts = `$${params.length - 1}`;
    const id = `$${params.length}`;
    keyset = `${where ? " AND" : "WHERE"} (s.submitted_at, s.id) < (${ts}::timestamptz, ${id}::bigint)`;
  }

  //one extra row, purely to learn whether another page exists without a second COUNT query over a
  //table that could hold millions
  params.push(size + 1);
  const rows = await query<Record<string, string | null>>(
    `SELECT ${columns(set, have)}
       FROM cdr_submit s${outcomeLateral(have)}
     ${where}${keyset}
      ORDER BY s.submitted_at DESC, s.id DESC
      LIMIT $${params.length}`,
    params
  );

  const hasMore = rows.length > size;
  const page = hasMore ? rows.slice(0, size) : rows;
  const mapped = page.map(toCdrRow);
  const last = mapped[mapped.length - 1];
  return {
    rows: mapped,
    nextCursor: hasMore && last ? { submittedAt: last.submittedAt, id: last.id } : null,
  };
}

/**
 * Note on what is deliberately absent: there is no facet query behind the filter inputs.
 *
 * <p>Every dimensional column in this deployment currently has cardinality one -- one account, one
 * vendor, one product, one system id. A dropdown built from `SELECT DISTINCT` would show a
 * single-item list and imply that is the only value that exists, which is a stronger and wronger
 * claim than a text box makes. Free text it is, until there is enough variety for a list to inform
 * rather than mislead.
 */

/**
 * `id` and `submitted_at` stay strings.
 *
 * <p>`id` is a BIGINT and `Number` would start losing digits past 2^53 -- a cursor that rounds is a
 * page boundary that skips rows. The timestamp stays as the driver's ISO string so it can be handed
 * straight back as a cursor without a Date round trip losing sub-millisecond precision.
 */
function toCdrRow(r: Record<string, string | null>): CdrRow {
  return {
    id: String(r.id),
    gatewayMsgId: String(r.gateway_msg_id),
    partNo: int(r.part_no) ?? 1,
    partCount: int(r.part_count) ?? 1,
    retryCount: int(r.retry_count) ?? 0,
    submittedAt: iso(r.submitted_at)!,
    acceptedAt: iso(r.accepted_at),
    accountId: r.account_id ?? null,
    systemId: r.system_id ?? null,
    product: r.product ?? null,
    ingress: String(r.ingress ?? ""),
    inGateway: r.in_gateway ?? null,
    vendor: r.vendor ?? null,
    sourceAddr: r.source_addr ?? null,
    destAddr: r.dest_addr ?? null,
    mcc: int(r.mcc),
    mnc: int(r.mnc),
    dcs: int(r.dcs),
    msgType: int(r.msg_type),
    operatorMsgId: r.operator_msg_id ?? null,
    costRate: int(r.cost_rate),
    costUnits: int(r.cost_units),
    cost: int(r.cost),
    priceRate: int(r.price_rate),
    billedUnits: int(r.billed_units),
    price: int(r.price),
    margin: int(r.margin),
    marginPct: int(r.margin_pct),
    marginStatus: r.margin_status ?? null,
    //BIGINT ids stay strings for the same reason `id` does
    costRuleId: r.cost_rule_id == null ? null : String(r.cost_rule_id),
    priceRuleId: r.price_rule_id == null ? null : String(r.price_rule_id),
    currency: r.currency ?? null,
    finalState: r.final_state ?? null,
    dlrState: int(r.dlr_state),
    errCode: r.err_code ?? null,
    //see the field doc: absent column and "the carrier said nothing" are different answers
    ...("vendor_err_code" in r ? { vendorErrCode: r.vendor_err_code ?? null } : {}),
    finalAt: iso(r.final_at),
    //absent rather than null when the query did not ask for it: "not selected" and "no TLVs" are
    //different answers, and only one of them means the message carried none. The same distinction
    //carries through to tlvs_sent, where null additionally means "no vendor recorded it"
    ...("tlvs" in r ? { tlvs: r.tlvs ?? null } : {}),
    ...("tlvs_received" in r ? { tlvsReceived: r.tlvs_received ?? null } : {}),
    ...("tlvs_sent" in r ? { tlvsSent: r.tlvs_sent ?? null } : {}),
    //same absent-versus-null rule: the column chooser decides the first, smsg.cdr.body the second
    ...("body" in r ? { body: r.body ?? null } : {}),
    //and again, with the sharpest version of the distinction in this file: absent means the gateway
    //is behind V1.33.0, null means the row predates the column. Neither is 0, which would be a claim
    //that the customer asked for no receipt
    ...("registered_delivery" in r
      ? { registeredDelivery: int(r.registered_delivery) }
      : {}),
    //same rule again: absent means this gateway predates V1.40.0, null means the row predates the
    //column (or the vendor is not SMPP and has no such field) -- neither is 0, which is ESME_ROK
    ...("submit_status" in r ? { submitStatus: int(r.submit_status) } : {}),
    //text, so no numeric coercion: null stays null, and null is "unrecorded" rather than "no rule"
    ...("route_rule" in r
      ? { routeRule: r.route_rule == null ? null : String(r.route_rule) }
      : {}),
  };
}

/** Null-preserving, unlike `metrics-queries.ts`'s `num()`: here a missing cost is not a cost of 0. */
function int(value: unknown): number | null {
  if (value == null || value === "") {
    return null;
  }
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function iso(value: unknown): string | null {
  if (value == null) {
    return null;
  }
  return value instanceof Date ? value.toISOString() : String(value);
}

/**
 * Every attempt and every receipt for one message, from both receipt tables.
 *
 * <p>The queries run together because a page that renders attempts before receipts would show a
 * message as pending for a moment after it was delivered.
 *
 * <p><strong>Not the LATERAL.</strong> Every other view in this panel takes one receipt per part —
 * the earliest `cdr_final` row — because that table has no uniqueness constraint and a plain join
 * would double the rows. Here the duplicates are the point: this is the one place two receipts for
 * the same part should be visible rather than silently collapsed, because the panel's own aggregates
 * disagree with each other when that happens.
 *
 * <p><strong>And it is the one place `cdr_interim` is read.</strong> The two tables are kept apart so
 * that every aggregate reading `cdr_final` still gets the outcome rather than the first sign of
 * life; merging them is a decision made once, here, for the page whose whole job is the sequence.
 *
 * @param limit attempts to return, plus one, so the caller can say "there are more". Not decoration:
 *     `maxRetries = 0` means retry forever, and a message can have thousands of rows
 */
export async function messageRecord(
  askedFor: string,
  limit = 500
): Promise<{
  gatewayMsgId: string;
  askedFor: string;
  segmentNo: number | null;
  attempts: CdrRow[];
  more: boolean;
  receipts: MessageReceipt[];
  progressRecorded: boolean;
  events: CustomerEvent[];
  /** False on a gateway older than V1.46.0 — the card is not rendered rather than shown empty. */
  eventsRecorded: boolean;
}> {
  const [have, progressRecorded, eventsRecorded] = await Promise.all([
    schemaSupport(), hasInterimTable(), hasEventTable(),
  ]);
  //Resolved before anything else runs, and not merely as a convenience: `cdr_final` and
  //`cdr_interim` are keyed on the message's own id and have no segment list of their own, so a
  //query for a segment id would find the attempts and none of the receipts -- a detail page saying
  //the message was sent and never heard from again, which is exactly the failure it exists to
  //diagnose.
  const { gatewayMsgId, segmentNo } = await resolveMessageId(askedFor, have.reassembledParts);
  const [attempts, finals, interims] = await Promise.all([
    query<Record<string, string | null>>(
      `SELECT ${columns("full", have)}
         FROM cdr_submit s${outcomeLateral(have)}
        WHERE s.gateway_msg_id = $1
        ORDER BY s.part_no, s.retry_count
        LIMIT $2`,
      [gatewayMsgId, limit + 1]
    ),
    query<Record<string, string | null>>(
      //the id tiebreaker is required, not tidiness: two receipts can carry the same final_at, and
      //without it the order they appear in changes between page loads
      //`vendor_err_code` is on cdr_final ONLY -- cdr_interim has no such column, so a progress
      //receipt can never carry the carrier's own code and the detail view must not imply it might
      `SELECT id, part_no, operator_msg_id, final_state, dlr_state, err_code, final_at${
        have.vendorErrCode ? ", vendor_err_code" : ""
      }
         FROM cdr_final
        WHERE gateway_msg_id = $1
        ORDER BY part_no, final_at, id
        LIMIT 500`,
      [gatewayMsgId]
    ),
    //skipped entirely against a gateway that has not applied V1.33.0, where naming the table is a
    //hard error rather than an empty result
    progressRecorded
      ? query<Record<string, string | null>>(
        `SELECT id, part_no, operator_msg_id, dlr_state, err_code, vendor, received_at
             FROM cdr_interim
            WHERE gateway_msg_id = $1
            ORDER BY part_no, received_at, id
            LIMIT 500`,
        [gatewayMsgId]
      )
      : Promise.resolve([]),
  ]);

  const more = attempts.length > limit;
  const rows = (more ? attempts.slice(0, limit) : attempts).map(toCdrRow);
  //what the customer asked for, per part. Read from the submit rows because that is where the octet
  //is stored; a receipt carries no memory of the request that produced it
  const asked = new Map<number, number | null>();
  for (const row of rows) {
    if (!asked.has(row.partNo) || asked.get(row.partNo) == null) {
      asked.set(row.partNo, row.registeredDelivery ?? null);
    }
  }

  const merged = [
    ...finals.map((r) => toReceipt(r, "outcome")),
    ...interims.map((r) => toReceipt(r, "progress")),
  ]
    .map((r) => ({ ...r, forwarded: forwardedFor(asked.get(r.partNo) ?? null, r) }))
    //part, then arrival. A progress receipt sorts before an outcome that shares its timestamp,
    //because the two ids come from different sequences and cannot be compared against each other
    .sort((a, b) =>
      a.partNo - b.partNo ||
      a.receivedAt.localeCompare(b.receivedAt) ||
      Number(a.kind === "outcome") - Number(b.kind === "outcome") ||
      a.id.localeCompare(b.id));

  //after the id is resolved, and only when the table exists: querying cdr_event on an older gateway
  //is an error, not an empty result
  const events = eventsRecorded
    ? (await query<Record<string, string | null>>(
        `SELECT at, kind, channel, status, attempt, duration_ms, endpoint, detail
           FROM cdr_event
          WHERE gateway_msg_id = $1
          ORDER BY at ASC, id ASC
          LIMIT 200`,
        [gatewayMsgId]
      )).map((r) => ({
        at: String(r.at),
        kind: String(r.kind),
        channel: String(r.channel),
        status: r.status === null ? null : Number(r.status),
        attempt: r.attempt === null ? null : Number(r.attempt),
        durationMs: r.duration_ms === null ? null : Number(r.duration_ms),
        endpoint: r.endpoint,
        detail: r.detail,
      }))
    : [];

  return {
    gatewayMsgId, askedFor, segmentNo, attempts: rows, more, receipts: merged, progressRecorded,
    events, eventsRecorded,
  };
}

/**
 * The id a message is actually filed under, given any id we ever handed out for it.
 *
 * <p>One query, not "try the obvious one and fall back": the exact-key match is ordered first, so a
 * message can never be shadowed by another message's segment list, and the caller does not pay a
 * round trip on the common path to learn that nothing was concatenated.
 *
 * @param canSearchSegments false against a gateway short of V1.34.0, where the column does not
 *     exist. Then this is the identity function, and the panel behaves exactly as it did before.
 * @returns the message's own id — or {@code askedFor} unchanged when nothing matches, so the caller
 *     reports the id the operator actually typed rather than something inferred from it. {@code
 *     segmentNo} is which segment of the message that id was, 1-based, or null when the id is not
 *     in a segment list at all
 */
async function resolveMessageId(
  askedFor: string,
  canSearchSegments: boolean
): Promise<{ gatewayMsgId: string; segmentNo: number | null }> {
  if (!canSearchSegments) {
    return { gatewayMsgId: askedFor, segmentNo: null };
  }
  const rows = await query<{ gateway_msg_id: string; segment_no: number | null }>(
    `SELECT gateway_msg_id, array_position(reassembled_parts, $1) AS segment_no
       FROM cdr_submit
      WHERE gateway_msg_id = $1 OR reassembled_parts @> ARRAY[$1]::text[]
      ORDER BY (gateway_msg_id = $1) DESC
      LIMIT 1`,
    [askedFor]
  );
  const hit = rows[0];
  return hit
    ? { gatewayMsgId: hit.gateway_msg_id, segmentNo: int(hit.segment_no) }
    : { gatewayMsgId: askedFor, segmentNo: null };
}

/** One row of either receipt table. `final_state` and `vendor` exist on exactly one of them. */
function toReceipt(
  r: Record<string, string | null>,
  kind: "outcome" | "progress"
): Omit<MessageReceipt, "forwarded"> {
  return {
    id: String(r.id),
    partNo: int(r.part_no) ?? 1,
    kind,
    operatorMsgId: r.operator_msg_id ?? null,
    finalState: r.final_state ?? null,
    dlrState: int(r.dlr_state),
    errCode: r.err_code ?? null,
    //undefined, not null, when the column is absent: null is a real answer meaning "the carrier
    //said nothing", and the two must stay distinguishable -- see MessageReceipt.vendorErrCode
    ...("vendor_err_code" in r ? { vendorErrCode: r.vendor_err_code ?? null } : {}),
    receivedAt: iso(r.final_at ?? r.received_at)!,
    vendor: r.vendor ?? null,
  };
}

/**
 * Whether this receipt reached the customer.
 *
 * <p>Null rather than false when the request was never recorded. Guessing would answer the one
 * question a receipt dispute turns on with a number nobody stored.
 */
function forwardedFor(
  registeredDelivery: number | null,
  receipt: Omit<MessageReceipt, "forwarded">
): boolean | null {
  if (registeredDelivery == null) {
    return null;
  }
  return receiptForwards(
    decodeReceiptRequest(registeredDelivery),
    receipt.dlrState,
    receipt.kind === "outcome"
  );
}
