import { NextRequest, NextResponse } from "next/server";
import { NotOperatorError, requireOperator } from "@/lib/require-operator";
import { isConfigured } from "@/lib/metrics-db";
import { isRange, type Range } from "@/lib/metrics-queries";

/**
 * The shape every control route shares: prove the caller is an operator, read the range, run the
 * query, and turn anything that goes wrong into a response that gives nothing away.
 *
 * <p>The authorisation check runs before the range is even parsed, so an anonymous caller cannot
 * learn which parameters are valid.
 */
export function controlRoute<T>(handler: (range: Range, params: URLSearchParams) => Promise<T>) {
  return async function GET(req: NextRequest): Promise<NextResponse> {
    try {
      await requireOperator();
    } catch (err) {
      if (err instanceof NotOperatorError) {
        //404, not 403: a 403 confirms there is something here to be forbidden from
        return NextResponse.json({ error: "Not found" }, { status: 404 });
      }
      throw err;
    }

    if (!isConfigured()) {
      return NextResponse.json(
        { error: "METRICS_DATABASE_URL is not set; this panel has no data source." },
        { status: 503 }
      );
    }

    const params = new URL(req.url).searchParams;
    const raw = params.get("range");
    const range: Range = isRange(raw) ? raw : "24h";

    try {
      return NextResponse.json({ range, data: await handler(range, params) });
    } catch (err) {
      //the message can name a missing table or a permission failure, which is exactly what an
      //operator needs to see and no one else can reach anyway
      console.error("control query failed", err);
      return NextResponse.json(
        { error: err instanceof Error ? err.message : "Query failed" },
        { status: 500 }
      );
    }
  };
}
