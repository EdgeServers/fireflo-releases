/**
 * Worker shapes, constants and validation.
 *
 * <p>Deliberately free of any database import so that a client component can use the types and the
 * field list without dragging `pg` into the browser bundle — which is exactly what happened when
 * these lived beside the queries.
 *
 * <p>A worker is a row in `app_worker` plus its settings in `app_worker_property`. The gateway
 * projects them back onto `outSms.instance.<name>.<key>` when it loads them, so a row here is the
 * same thing as a block of properties in `smsg.properties` — just addressable as a unit.
 *
 * <p><strong>These only take effect when the gateway runs with `smsg.config.source=db`.</strong>
 * Nothing here can detect that: the source switch is a bootstrap setting that has to be read before
 * the database is consulted, so it lives in the environment and never in a table. Saying so in the
 * UI is the only honest option.
 */
import { settingLabel } from "./labels.ts";
import { MILLISECOND_KEYS } from "./setting-fields.ts";

export type WorkerType = "smppclient" | "smppserver";

/**
 * The two words this product uses, and the config values behind them.
 *
 * <p>A **vendor** is a connection out to someone who carries our traffic. A **server** is a listener
 * customers bind in to. `smppclient` and `smppserver` are the gateway's own values and stay in the
 * database, but they never reach the interface — this map is the only place the two vocabularies
 * meet.
 *
 * <p>The data layer already agreed: `cdr_submit.vendor` and the delivery-receipt payload have always
 * said vendor.
 */
export const KIND = { vendor: "smppclient", server: "smppserver" } as const;

export const KIND_LABEL: Record<WorkerType, string> = {
  smppclient: "Vendor",
  smppserver: "Server",
};

/** Lower case, for mid-sentence use: "Add a vendor", "No servers configured yet". */
export const KIND_NOUN: Record<WorkerType, string> = {
  smppclient: "vendor",
  smppserver: "server",
};

export interface WorkerProperty {
  key: string;
  value: string;
}

export interface Worker {
  name: string;
  type: WorkerType;
  enabled: boolean;
  label: string | null;
  properties: WorkerProperty[];
}

export interface WorkerInput {
  name: string;
  type: WorkerType;
  enabled: boolean;
  label?: string | null;
  properties: WorkerProperty[];
}

/*
 * Which property keys hold a secret is no longer a list here: it is app_config_key (gateway
 * V1.61.0), read by lib/workers.ts through loadConfigKeyRegistry, plus the gateway's name rule
 * (looksSensitive). The two-entry list that lived here was a third copy of that fact.
 */

export const REDACTED = "********";

/**
 * The name a vendor's traffic is recorded under.
 *
 * <p>Call detail records store the worker's <em>full</em> name — `smppclient.vendor1` — while
 * `app_worker.name` holds the instance name alone. Matching the two on `name` returns nothing, and
 * the failure is silent: every vendor reads zero traffic, which looks like an idle gateway rather
 * than a bug. This function is the only place that mapping is written.
 */
export function trafficKey(worker: Pick<Worker, "name" | "type">): string {
  return `${worker.type}.${worker.name}`;
}

/**
 * A stored on/off setting; absent means off, which is how the gateway reads it too.
 *
 * <p>Lives here because the same three lines were copied into `VendorsClient`, `ServersClient` and
 * `WorkerCard`, and the rail and the summary would have made five. The `trim().toLowerCase()` is
 * load-bearing: these values are typed by hand into a settings form, so ` True` is a real value that
 * a stricter comparison would read as off — silently, in the direction of "this vendor is sending".
 */
export function isOn(worker: Pick<Worker, "properties">, key: string): boolean {
  return worker.properties.some((p) => p.key === key && p.value.trim().toLowerCase() === "true");
}

/**
 * A worker name becomes part of `outSms.instance.<name>.<key>`, and the gateway finds instances
 * with a regex whose name segment is `[^.]*` — so a dot in a name means the worker is never
 * discovered and it silently does not exist. Hence the character restriction, which is tighter than
 * the column's.
 */
const NAME_PATTERN = /^[A-Za-z0-9_-]{1,64}$/;

const KEY_PATTERN = /^[A-Za-z0-9_.-]{1,120}$/;

export function validate(input: WorkerInput): string | null {
  if (!NAME_PATTERN.test(input.name)) {
    return "Name must be 1-64 characters of letters, digits, hyphen or underscore. "
      + "A dot would break the property name the gateway looks it up by.";
  }
  if (input.type !== "smppclient" && input.type !== "smppserver") {
    return "Unknown connection type.";
  }
  const seen = new Set<string>();
  for (const property of input.properties) {
    const key = property.key.trim();
    if (!KEY_PATTERN.test(key)) {
      return `'${key || "(empty)"}' is not a usable setting name.`;
    }
    if (key.startsWith("outSms.")) {
      return `Use '${key.replace(/^outSms\.instance\.[^.]+\./, "")}' rather than the full property `
        + "name; the gateway adds the outSms.instance.<name>. prefix itself.";
    }
    if (seen.has(key)) {
      return `'${key}' is set twice.`;
    }
    seen.add(key);
    if (key === "srv.public.host") {
      const problem = publicHostProblem(property.value);
      if (problem) {
        return problem;
      }
    }
  }
  return null;
}

/**
 * Why a listener's Public IP cannot be what a customer connects to, or null when it can.
 *
 * <p>Blank is fine: the setting is optional, and an empty one is never stored. Otherwise it must be
 * a host name or an IPv4 or IPv6 address, written bare -- no scheme, no port, no path -- because it
 * goes into connection instructions as the address line exactly as typed. A wildcard or loopback
 * address is refused too: it is a bind address, not one anybody else can reach.
 */
export function publicHostProblem(raw: string): string | null {
  const host = raw.trim();
  if (host === "") {
    return null;
  }
  if (/^(0\.0\.0\.0|::|\[::\]|\*|localhost|127\.\d+\.\d+\.\d+|::1)$/i.test(host)) {
    return `Public IP '${host}' is not an address customers can reach. Use the listener's public address.`;
  }
  const ipv4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
  if (ipv4) {
    return ipv4.slice(1).every((octet) => Number(octet) <= 255)
      ? null
      : `Public IP '${host}' is not a valid IPv4 address.`;
  }
  //an IPv6 address: hex groups and colons, with at most one "::"
  if (host.includes(":")) {
    return /^[0-9a-f:]+$/i.test(host) && (host.match(/::/g) ?? []).length <= 1 && host.split(":").length <= 8
      ? null
      : `Public IP '${host}' is not a valid IPv6 address. Write it without brackets or a port.`;
  }
  //a host name: dot-separated labels of letters, digits and hyphens, not all digits
  const label = /^(?!-)[a-z0-9-]{1,63}(?<!-)$/i;
  if (host.length <= 253 && host.split(".").every((part) => label.test(part)) && !/^[\d.]+$/.test(host)) {
    return null;
  }
  return `Public IP '${host}' is not a host name or an IP address. Write it bare, without http:// or a port.`;
}

/**
 * Values that are almost certainly seconds typed into a milliseconds field.
 *
 * <p>A warning rather than a rejection: a sub-second interval is legal and someone testing a
 * reconnect loop may genuinely want one. Refusing it would be this page deciding it knows better
 * than the operator, which it does not — it only knows the value is unusual.
 */
export function millisecondWarnings(properties: WorkerProperty[]): string[] {
  const warnings: string[] = [];
  for (const property of properties) {
    const floor = MILLISECOND_KEYS[property.key];
    if (floor == null) {
      continue;
    }
    const value = Number(property.value);
    if (Number.isFinite(value) && value > 0 && value < floor) {
      warnings.push(
        `${settingLabel(property.key).label} is ${value} ms — under ${floor / 1000} second. `
          + `If you meant ${value} seconds, enter ${value * 1000}.`
      );
    }
  }
  return warnings;
}
