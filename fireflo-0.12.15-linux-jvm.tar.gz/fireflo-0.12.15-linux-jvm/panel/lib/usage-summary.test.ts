import { strict as assert } from "node:assert";
import { test } from "node:test";

import { toAccountRows, toSeries, usageTotals } from "./usage-summary.ts";
import type { UsageDay } from "./metrics-queries.ts";

function row(over: Partial<UsageDay> = {}): UsageDay {
  return {
    day: "2026-08-14",
    accountId: "acct-1001",
    submitted: 10,
    delivered: 9,
    failed: 1,
    pending: 0,
    price: 20_000,
    ...over,
  };
}

test("a day with nothing settled has no delivery rate, rather than zero", () => {
  //the distinction the whole chart rests on. A quiet day drawn as 0% puts a cliff in the line that
  //never happened, and an operator reads a cliff as an outage
  const [point] = toSeries([row({ submitted: 4, delivered: 0, failed: 0, pending: 4 })]);
  assert.equal(point.rate, null);
  assert.notEqual(point.rate, 0);
});

test("the rate divides by what settled, not by what was sent", () => {
  //dividing by submitted counts in-flight traffic as failure, so the rate dips whenever volume
  //rises and recovers overnight on its own -- an alarm that fires on traffic rather than trouble
  const [point] = toSeries([row({ submitted: 100, delivered: 45, failed: 5, pending: 50 })]);
  assert.equal(point.rate, 90, "45 of the 50 that settled");
});

test("pending is counted and reported, but is not drawn as a bar", () => {
  const rows = [row({ submitted: 50, delivered: 10, failed: 0, pending: 40 })];
  const [point] = toSeries(rows);
  assert.equal(point.delivered + point.failed, 10, "today's bar is what settled");
  assert.equal(usageTotals(rows).pending, 40, "and the 40 in flight are still reported");
});

test("accounts collapse into one series per day, in date order", () => {
  const series = toSeries([
    row({ day: "2026-08-15", accountId: "acct-b", delivered: 3, failed: 0 }),
    row({ day: "2026-08-14", accountId: "acct-a", delivered: 5, failed: 1 }),
    row({ day: "2026-08-14", accountId: "acct-b", delivered: 2, failed: 0 }),
  ]);
  assert.deepEqual(series.map((p) => p.day), ["2026-08-14", "2026-08-15"]);
  assert.equal(series[0].delivered, 7, "both accounts on the 14th");
});

test("an account called nothing does not merge with traffic that named no account", () => {
  //an id is free text on the wire. Keying a map on `accountId ?? ""` would fold a real account
  //called "" -- or "null", depending on the sentinel -- into the unattributed bucket, and the
  //symptom is one customer's traffic silently appearing under somebody else's row
  const rows = toAccountRows([
    row({ accountId: null, submitted: 5 }),
    row({ accountId: "", submitted: 7 }),
    row({ accountId: "null", submitted: 3 }),
  ]);
  assert.equal(rows.length, 3, "three distinct rows");
  assert.equal(rows.find((r) => r.accountId === null)?.submitted, 5);
  assert.equal(rows.find((r) => r.accountId === "")?.submitted, 7);
  assert.equal(rows.find((r) => r.accountId === "null")?.submitted, 3);
});

test("an account's figures sum across every day in the window", () => {
  const rows = toAccountRows([
    row({ day: "2026-08-14", submitted: 10, delivered: 9, failed: 1, price: 20_000 }),
    row({ day: "2026-08-15", submitted: 20, delivered: 18, failed: 2, price: 40_000 }),
  ]);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].submitted, 30);
  assert.equal(rows[0].price, 60_000, "money stays scaled -- dividing is money()'s job");
  assert.equal(rows[0].rate, 90);
});

test("the table is ordered by volume, heaviest first", () => {
  const rows = toAccountRows([
    row({ accountId: "small", submitted: 5 }),
    row({ accountId: "large", submitted: 500 }),
    row({ accountId: "middle", submitted: 50 }),
  ]);
  assert.deepEqual(rows.map((r) => r.accountId), ["large", "middle", "small"]);
});

test("an unrated message is traffic with no money against it", () => {
  //price is summed, not counted, so a message the rating engine never priced contributes to volume
  //and nothing to revenue. That is the correct reading: it was sent, and nobody was charged
  const rows = [row({ submitted: 10, delivered: 10, failed: 0, price: 0 })];
  assert.equal(usageTotals(rows).submitted, 10);
  assert.equal(usageTotals(rows).price, 0);
});

test("totals agree with the sum of the account rows", () => {
  //the two are rendered side by side, and an operator who adds the column up must get the tile
  const rows = [
    row({ accountId: "a", submitted: 10, delivered: 8, failed: 2, pending: 0, price: 1_000 }),
    row({ accountId: "b", submitted: 30, delivered: 20, failed: 5, pending: 5, price: 3_000 }),
  ];
  const totals = usageTotals(rows);
  const table = toAccountRows(rows);
  assert.equal(totals.submitted, table.reduce((n, r) => n + r.submitted, 0));
  assert.equal(totals.price, table.reduce((n, r) => n + r.price, 0));
  assert.equal(totals.rate, 80, "28 delivered of the 35 that settled");
});

test("no rows at all is an empty page, not a crash or a zero rate", () => {
  assert.deepEqual(toSeries([]), []);
  assert.deepEqual(toAccountRows([]), []);
  assert.equal(usageTotals([]).rate, null);
  assert.equal(usageTotals([]).submitted, 0);
});

//---- the seam: usage_daily for finished days, cdr_submit for the live tail (Audit CP-P1) ----

import {
  FAILURE_WINDOW_SINCE,
  LIVE_COLUMNS,
  USAGE_ROW_COLUMNS,
  usageWindowSql,
} from "./usage-summary-sql.ts";

const norm = (sql: string) => sql.replace(/\s+/g, " ").trim();
const dashboard = norm(usageWindowSql({ vendorAttempt: true, bucket: "day", account: false, wholeDays: true }));

test("CP-P1 the window is split into whole billing days and a live tail", () => {
  //days [first_day, end_day) lie wholly inside [since, until): the first billing day starting at
  //or after since, and the day until falls in. Both cut in the billing zone, as UsageRollup cuts
  assert.match(dashboard, /\(\(b\.since AT TIME ZONE \$3\) - interval '1 microsecond'\)::date \+ 1 AS first_day/);
  assert.match(dashboard, /\(b\.until AT TIME ZONE \$3\)::date AS end_day/);
  //rolled reads exactly those days from the summary
  assert.match(dashboard, /FROM cut, usage_daily u WHERE u\.day >= cut\.first_day AND u\.day < cut\.end_day/);
  //the tail starts at the seam -- midnight of the day before the rollup's newest line -- or at the
  //end of the last full day, whichever is earlier, and never before since. ONE index range
  assert.match(dashboard,
    /s\.submitted_at >= GREATEST\(cut\.since, cut\.first_full_at, LEAST\(cut\.tail_from, cut\.end_full_at\)\) AND s\.submitted_at < cut\.until/);
  assert.match(dashboard, /COALESCE\(\(\(max\(u\.day\) - 1\)::timestamp AT TIME ZONE \$3\), '-infinity'::timestamptz\) FROM usage_daily u\) AS tail_from/);
});

test("CP-P1 the two halves are disjoint: a rolled line's rows are skipped, today's never are", () => {
  //the anti-join is at the summary's grain, with the rollup's COALESCE so unattributed traffic
  //matches the '' line it was summarised under -- and it applies only below the end of the last
  //full day. Today's line, when the rollup has written one mid-day, must not hide today's traffic
  assert.match(dashboard, /\(s\.submitted_at >= cut\.end_full_at OR NOT EXISTS \( SELECT 1 FROM usage_daily u WHERE u\.account_id = COALESCE\(s\.account_id, ''\) AND u\.day = \(s\.submitted_at AT TIME ZONE \$3\)::date AND u\.product = COALESCE\(s\.product, ''\)\)\)/);
});

test("CP-P1 the live half carries a narrow projection, never s.*", () => {
  assert.doesNotMatch(dashboard, /s\.\*/, "DISTINCT ON sorts every column it carries; body and the TLVs stay out");
  assert.match(dashboard, /SELECT DISTINCT ON \(s\.gateway_msg_id\) s\.gateway_msg_id, s\.part_no, s\.account_id, s\.system_id, s\.product, s\.submitted_at, s\.price, s\.cost FROM cdr_submit s/);
  for (const wide of ["body", "tlvs", "tlvs_received", "tlvs_sent", "reassembled_parts"]) {
    assert.ok(!LIVE_COLUMNS.includes(wide as never), `${wide} has no place in an aggregate's sort`);
  }
  assert.ok(LIVE_COLUMNS.includes("gateway_msg_id") && LIVE_COLUMNS.includes("part_no"),
    "the outcome LATERAL correlates on these two");
});

test("CP-P1 whole days floor since to the billing day; a caller's own window keeps a live head", () => {
  //the named ranges start mid-day; flooring makes the leading day a full one so it comes from the
  //summary rather than a day's scan for a sliver
  assert.match(dashboard, /SELECT \(\(\$1::timestamptz AT TIME ZONE \$3\)::date::timestamp AT TIME ZONE \$3\) AS since, \$2::timestamptz AS until/);
  assert.equal((dashboard.match(/SELECT DISTINCT ON/g) ?? []).length, 1, "one live arm");

  //a statement passes its own boundaries: the partial day in front is read live, with no
  //anti-join, because rolled never includes it
  const own = norm(usageWindowSql({ vendorAttempt: true, bucket: "day", account: false, wholeDays: false }));
  assert.match(own, /SELECT \$1::timestamptz AS since/);
  assert.equal((own.match(/SELECT DISTINCT ON/g) ?? []).length, 2, "head and tail");
  assert.match(own, /s\.submitted_at >= cut\.since AND s\.submitted_at < LEAST\(cut\.until, cut\.first_full_at\) ORDER BY/);
});

test("CP-P2 an account's window takes its own horizon and filters both halves on $4", () => {
  const one = norm(usageWindowSql({ vendorAttempt: true, bucket: "day", account: true, wholeDays: false }));
  assert.match(one, /FROM usage_daily u WHERE u\.account_id = \$4\) AS tail_from/, "the horizon is the account's newest line");
  assert.match(one, /u\.day < cut\.end_day AND u\.account_id = \$4/);
  assert.match(one, /AND s\.account_id = \$4 AND \(s\.submitted_at >= cut\.end_full_at/);
  //the deployment-wide variant binds no account anywhere
  assert.doesNotMatch(dashboard, /\$4/);
});

test("CP-P1 both halves present the same columns in the same order", () => {
  //UNION ALL matches by position; a column added to one half and not the other would shift
  //money into a count without an error
  const cols = USAGE_ROW_COLUMNS.join(", ");
  assert.match(dashboard, new RegExp(`SELECT ${cols} FROM rolled UNION ALL SELECT ${cols} FROM live`));
  //rolled rows carry the line's figures under the live half's names
  assert.match(dashboard, /u\.pending_at_rollup AS pending, u\.price_total AS price, u\.cost_total AS cost, 0::bigint AS pending_price, 0::bigint AS refused/);
});

test("CP-P1 logins and the refusal probe are opt-in, and only on live rows", () => {
  assert.match(dashboard, /NULL::text AS system_id, s\.product/, "no login unless asked");
  assert.match(dashboard, /0::bigint AS refused, max\(s\.submitted_at\)/, "no cdr_rejected probe unless asked");
  const full = norm(usageWindowSql({ vendorAttempt: true, bucket: "hour", account: false, wholeDays: false, logins: true, refused: true }));
  assert.match(full, /s\.system_id AS system_id/);
  assert.match(full, /EXISTS \(SELECT 1 FROM cdr_rejected r WHERE r\.gateway_msg_id = s\.gateway_msg_id AND r\.reason = 'vendorRejected'\)/);
  assert.match(full, /date_trunc\('hour', s\.submitted_at\) AS bucket/);
  //and a gateway before V1.40.0 is never asked for vendor_attempt
  assert.doesNotMatch(usageWindowSql({ vendorAttempt: false, bucket: "day", account: false, wholeDays: true }), /vendor_attempt/);
});

test("CP-P1 the failure breakdown is cut to today or the last 24 hours, whichever is longer", () => {
  //usage_daily has no failure reason, so this view is the records or nothing -- and never less
  //than the 24h range shows, or a longer range would show fewer failures
  assert.equal(FAILURE_WINDOW_SINCE,
    "GREATEST($1::timestamptz, LEAST(((now() AT TIME ZONE $3)::date::timestamp AT TIME ZONE $3), $2::timestamptz - interval '24 hours'))");
});
