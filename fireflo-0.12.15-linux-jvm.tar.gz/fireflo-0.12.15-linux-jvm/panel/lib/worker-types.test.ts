import { strict as assert } from "node:assert";
import { test } from "node:test";
import { publicHostProblem, validate } from "./worker-types.ts";

test("a listener's Public IP may be blank, an address or a host name", () => {
  for (const ok of ["", "  ", "203.0.113.10", "smpp.example.com", "gw-1", "2001:db8::10"]) {
    assert.equal(publicHostProblem(ok), null, ok);
  }
});

test("anything else is refused in words", () => {
  for (const bad of ["0.0.0.0", "127.0.0.1", "localhost", "::", "256.1.1.1", "1.2.3", "http://smpp.example.com",
    "smpp.example.com:2775", "[2001:db8::10]", "-bad.example.com", "a b"]) {
    assert.match(publicHostProblem(bad) ?? "", /Public IP/, bad);
  }
});

test("validate refuses a bad Public IP on save", () => {
  const input = { name: "smpp", type: "smppserver" as const, properties: [{ key: "srv.public.host", value: "1.2.3" }] };
  assert.match(validate(input as Parameters<typeof validate>[0]) ?? "", /Public IP/);
});
