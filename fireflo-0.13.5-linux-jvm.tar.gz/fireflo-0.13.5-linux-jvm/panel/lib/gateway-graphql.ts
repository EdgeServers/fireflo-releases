import { NextResponse } from "next/server";
import {
  decodeFileResult,
  executeGql,
  fetchMetricsText,
  type FileResult,
  type GqlCall,
  type GqlFailure,
} from "./gateway-graphql-core";

/**
 * Calling the gateway's GraphQL operator API from a route.
 *
 * <p>Server-only: the tokens are read from the process environment and must never reach a browser.
 * Every `/api/control` route that talks to the management port goes through here, so the base URL,
 * the token choice and the wording of a refusal exist once. The logic is in
 * `lib/gateway-graphql-core.ts` (pure, unit tested); this file only shapes `NextResponse`s.
 *
 * <p><strong>Two ports now.</strong> The GraphQL endpoint is on the gateway's management interface
 * (`GATEWAY_OPS_URL`, 9000 by default). `/q/metrics` moved in 0.13 to the gateway's MAIN port
 * (`GATEWAY_BASE_URL`) behind the same read token -- see {@link callMetricsText}. Pointing
 * `GATEWAY_OPS_URL` at the message port gets 404s that look exactly like a wrong token.
 *
 * <p>Successor to the REST `/ops/*` client (`lib/gateway-ops.ts`, removed), whose targets a 0.13
 * gateway no longer serves. The envelope a route answers is unchanged: `{ data }` on success,
 * `{ error }` otherwise.
 */

export type { GqlAuth, GqlCall, FileResult } from "./gateway-graphql-core";
export { GatewayError, gqlData, GATEWAY_TOO_OLD } from "./gateway-graphql-core";

/** A call whose root value is reshaped before it is enveloped, e.g. to keep a REST-era field name. */
export interface GqlRouteCall<T> extends GqlCall {
  /** Applied to the root field's value on success; the result is what `data` carries. */
  select?: (root: T) => unknown;
}

/**
 * Proxies one document and answers `{ data: <root field value> }`, or an error response.
 *
 * <p>The same envelope `callOps` answered, so no page changes: a route that returned
 * `{ data: <the /ops/health object> }` returns `{ data: <the health field> }`.
 */
export async function gql<T = unknown>(call: GqlRouteCall<T>): Promise<NextResponse> {
  const outcome = await executeGql<T>(call);
  if (!outcome.ok) {
    return failed(outcome);
  }
  return NextResponse.json({ data: call.select ? call.select(outcome.data) : outcome.data });
}

/**
 * A root field that answers a `FileResult`, decoded into an attachment.
 *
 * <p>`no-store` because a capture is customer message content: it must not sit in a shared cache or
 * come back from the browser's history after the gateway has expired it.
 */
export async function gqlFile(call: GqlCall): Promise<NextResponse> {
  const outcome = await executeGql<FileResult | null>({ auth: "admin", timeoutMs: 30_000, ...call });
  if (!outcome.ok) {
    return failed(outcome);
  }
  if (!outcome.data || typeof outcome.data.bytesBase64 !== "string") {
    return NextResponse.json({ error: "The gateway has no such file." }, { status: 404 });
  }
  const { bytes, filename, contentType } = decodeFileResult(outcome.data);
  //a fresh, exactly-sized copy: the decoded view may sit inside a larger pooled buffer
  return new NextResponse(bytes.slice().buffer as ArrayBuffer, {
    status: 200,
    headers: {
      "Content-Type": contentType,
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "private, no-store",
    },
  });
}

/**
 * The gateway's `/q/metrics`, as text.
 *
 * <p>Read from `GATEWAY_BASE_URL` -- the main port -- with `GATEWAY_OPS_TOKEN`. Until 0.12 the
 * metrics were beside `/ops` on the management port and needed no token; 0.13 moved them to the
 * main port and put them behind the ops read token, so the variable that names the port changed
 * and the one that names the secret did not.
 *
 * @returns the body, or the error response to return as-is
 */
export async function callMetricsText({
  timeoutMs = 10_000,
}: { timeoutMs?: number } = {}): Promise<{ text: string } | { failed: NextResponse }> {
  const result = await fetchMetricsText(timeoutMs);
  if ("failed" in result) {
    return { failed: failed(result.failed) };
  }
  return result;
}

function failed(outcome: GqlFailure): NextResponse {
  return NextResponse.json({ error: outcome.error, code: outcome.code }, { status: outcome.status });
}
